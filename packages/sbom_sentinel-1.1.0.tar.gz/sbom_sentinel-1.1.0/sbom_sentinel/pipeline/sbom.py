import json
import shutil
import subprocess
import tempfile
import time
from datetime import UTC, datetime
from pathlib import Path

from sbom_sentinel.support import target as target_mod
from sbom_sentinel.support.log import get_logger, strip_ansi

log = get_logger(__name__)

# Conservative timeouts for external tools. Large images or repos can be slow.
_GIT_CLONE_TIMEOUT = 120   # seconds — shallow clone should complete well within this
_SYFT_TIMEOUT = 600        # seconds — large container images can take several minutes


def _check_prereqs(target_type: str) -> None:
    if shutil.which("syft") is None:
        raise OSError(
            "syft not found in PATH. "
            "Install from: https://github.com/anchore/syft#installation"
        )
    if target_type == "git" and shutil.which("git") is None:
        raise OSError(
            "git not found in PATH. "
            "Required for remote git URL targets. Install from: https://git-scm.com"
        )


def generate(target: str, name: str, output_dir: Path) -> Path:
    """
    Run Syft on target and write SBOM to output_dir/<name>_<timestamp>.spdx.json.

    Git targets are cloned to a temporary directory first (Syft has no native remote
    git URL support). The clone is removed in a finally block regardless of outcome.

    Returns the path to the written SBOM file.
    """
    target_type, resolved = target_mod.resolve(target)
    log.debug(f"Resolved target: type={target_type}, value={resolved}")
    _check_prereqs(target_type)
    log.debug(f"syft location: {shutil.which('syft')}")
    log.info(f"syft version: {_syft_version()}")

    output_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(tz=UTC).strftime("%Y%m%d_%H%M%S")
    output_path = output_dir / f"{name}_{ts}.spdx.json"

    if target_type == "git":
        _generate_from_git(resolved, output_path)
    else:
        _run_syft(resolved, output_path)

    pkg_count = _count_spdx_packages(output_path)
    log.info(f"SBOM written to {output_path} ({pkg_count} packages)")
    return output_path


def _syft_version() -> str:
    """Return the syft version string. Returns 'unknown' on any failure so a
    version-probe error never blocks an actual scan."""
    try:
        result = subprocess.run(
            ["syft", "--version"], capture_output=True, text=True,
            encoding="utf-8", timeout=10,
        )
        return result.stdout.strip() or "unknown"
    except Exception:
        return "unknown"


def _count_spdx_packages(spdx_file: Path) -> int:
    """Count packages in an SPDX-JSON SBOM. Returns -1 on parse error so the
    caller can still report the file path without the extra context."""
    try:
        data = json.loads(spdx_file.read_text(encoding="utf-8"))
        return len(data.get("packages", []))
    except Exception as exc:
        log.debug(f"Could not count packages in {spdx_file}: {exc}")
        return -1


def _generate_from_git(url: str, output_path: Path) -> None:
    tmp_dir = tempfile.mkdtemp(prefix="sbom_sentinel_git_")
    try:
        log.info(f"Cloning {url} ...")
        cmd = ["git", "clone", "--depth", "1", url, tmp_dir]
        t0 = time.monotonic()
        result = subprocess.run(
            cmd, capture_output=True, text=True, encoding="utf-8",
            timeout=_GIT_CLONE_TIMEOUT,
        )
        log.info(f"git clone completed in {time.monotonic() - t0:.1f}s")
        if result.returncode != 0:
            if result.stderr:
                log.error(strip_ansi(result.stderr).strip())
            raise subprocess.CalledProcessError(result.returncode, cmd)
        _run_syft(tmp_dir, output_path)
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


def _run_syft(source: str, output_path: Path) -> None:
    log.info(f"Running syft on {source} ...")
    cmd = ["syft", source, "-o", f"spdx-json={output_path}", "-q"]
    t0 = time.monotonic()
    result = subprocess.run(
        cmd, capture_output=True, text=True, encoding="utf-8", timeout=_SYFT_TIMEOUT
    )
    log.info(f"syft completed in {time.monotonic() - t0:.1f}s")
    if result.returncode != 0:
        if result.stderr:
            log.error(result.stderr.strip())
        raise subprocess.CalledProcessError(result.returncode, cmd)
