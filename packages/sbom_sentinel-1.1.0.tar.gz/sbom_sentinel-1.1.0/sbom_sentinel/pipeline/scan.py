import json
import re
import shutil
import subprocess
import time
from datetime import UTC, datetime
from pathlib import Path

from sbom_sentinel.support.log import get_logger, strip_ansi

log = get_logger(__name__)

# Grype JSON v1.0 schema redesign is in progress:
# https://github.com/anchore/grype/issues/3144
# Minimum tested version: v0.79.x (spdx-json input, pre-v1.0 output schema).

_VALID_SEVERITIES = {"critical", "high", "medium", "low", "negligible"}
_VALID_FORMATS = {"json", "sarif"}

# Grype can be slow on large SBOMs. 5 minutes is generous for typical use.
_GRYPE_TIMEOUT = 300  # seconds

# Warn when Grype's vulnerability DB is older than this. Grype auto-updates the
# DB on each run unless --no-db-update is set, so a stale DB usually means the
# auto-update silently failed and findings will under-report.
_GRYPE_DB_STALE_DAYS = 14

# Grype emits the DB build time like "Built:  2026-03-09 00:31:20 +0000 UTC".
# Capture the date+time, parse as UTC (the trailing "+0000 UTC" makes it explicit).
_GRYPE_DB_BUILT_RE = re.compile(
    r"Built:\s*(\d{4}-\d{2}-\d{2}[\sT]\d{2}:\d{2}:\d{2})", re.IGNORECASE,
)


class ThresholdTriggered(Exception):
    """Raised when grype exits non-zero because the --fail-on threshold was met.

    The scan file is still written — the non-zero exit is an expected signal,
    not a scan failure. Callers can still use `path` for downstream processing
    (e.g. generating a report) while exiting with an error code afterwards.
    """

    def __init__(self, path: Path, returncode: int) -> None:
        self.path = path
        self.returncode = returncode
        super().__init__(f"grype threshold met (exit {returncode})")


def _check_prereqs() -> None:
    if shutil.which("grype") is None:
        raise OSError(
            "grype not found in PATH. "
            "Install from: https://github.com/anchore/grype#installation"
        )


def run(
    sbom_file: Path,
    name: str,
    output_dir: Path,
    fail_on: str | None,
    fmt: str = "json",
    vex: Path | None = None,
) -> Path:
    """
    Run Grype against sbom_file and write results to output_dir/<name>_<timestamp>.<ext>.

    fmt: "json" (default) or "sarif". SARIF enables GitHub Code Scanning integration.

    vex: optional path to an OpenVEX or CSAF document. Passed to Grype via --vex.
    Grype will suppress any finding where the VEX statement status is "not_affected".

    --fail-on maps directly to Grype's --fail-on flag. When the severity threshold is
    met, Grype exits non-zero. This function writes the scan output first, then raises
    ThresholdTriggered (with the path attached) so callers can still generate a report
    before exiting non-zero. Real Grype failures raise subprocess.CalledProcessError.

    Returns the path to the written results file.
    """
    _check_prereqs()
    log.debug(f"grype location: {shutil.which('grype')}")
    log.debug(f"Scan config: fmt={fmt}, fail_on={fail_on}, vex={vex}")
    log.info(f"grype version: {_grype_version()}")
    _log_grype_db_status()

    if fmt not in _VALID_FORMATS:
        raise ValueError(f"Invalid format '{fmt}'. Valid values: {', '.join(_VALID_FORMATS)}")

    if fail_on is not None and fail_on.lower() not in _VALID_SEVERITIES:
        raise ValueError(
            f"Invalid --fail-on severity '{fail_on}'. "
            f"Valid values: {', '.join(sorted(_VALID_SEVERITIES))}"
        )

    output_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(tz=UTC).strftime("%Y%m%d_%H%M%S")
    ext = "sarif" if fmt == "sarif" else "json"
    output_path = output_dir / f"{name}_{ts}.{ext}"

    cmd = ["grype", f"sbom:{sbom_file}", "--by-cve", "-o", fmt]
    if fail_on:
        cmd += ["--fail-on", fail_on.lower()]
    if vex:
        cmd += ["--vex", str(vex)]

    log.info(f"Running grype on {sbom_file} ...")
    t0 = time.monotonic()
    result = subprocess.run(
        cmd, capture_output=True, text=True, encoding="utf-8", timeout=_GRYPE_TIMEOUT
    )
    log.info(f"grype completed in {time.monotonic() - t0:.1f}s (exit={result.returncode})")

    if result.stdout:
        output_path.write_text(result.stdout, encoding="utf-8")
        finding_count = _count_findings(output_path, fmt)
        log.info(f"Scan results written to {output_path} ({finding_count} findings)")

    if result.returncode != 0:
        # When --fail-on is set and grype produced output, the non-zero exit
        # is the threshold signal — log grype's stderr at INFO so it doesn't
        # trigger false alarms in monitoring. Real failures stay at ERROR.
        stderr = strip_ansi(result.stderr).strip() if result.stderr else ""
        if fail_on and output_path.exists():
            if stderr:
                log.info(f"grype: {stderr}")
            raise ThresholdTriggered(output_path, result.returncode)
        if stderr:
            log.error(stderr)
        raise subprocess.CalledProcessError(result.returncode, cmd)

    if not output_path.exists():
        raise OSError("grype produced no output on stdout; scan results not written")

    return output_path


def _grype_version() -> str:
    """Return the grype version string. Returns 'unknown' on failure."""
    try:
        result = subprocess.run(
            ["grype", "--version"], capture_output=True, text=True,
            encoding="utf-8", timeout=10,
        )
        return result.stdout.strip() or "unknown"
    except Exception:
        return "unknown"


def _grype_db_age_days() -> int | None:
    """Return the age of Grype's vulnerability DB in days, or None if it
    can't be determined. Parses the 'Built:' field from `grype db status`."""
    try:
        result = subprocess.run(
            ["grype", "db", "status"], capture_output=True, text=True,
            encoding="utf-8", timeout=10,
        )
        match = _GRYPE_DB_BUILT_RE.search(result.stdout)
        if not match:
            return None
        built = datetime.strptime(match.group(1).replace("T", " "), "%Y-%m-%d %H:%M:%S")
        built = built.replace(tzinfo=UTC)
        return (datetime.now(tz=UTC) - built).days
    except Exception:
        return None


def _log_grype_db_status() -> None:
    age = _grype_db_age_days()
    if age is None:
        log.debug("Could not determine Grype DB age")
        return
    msg = f"Grype vulnerability DB built {age} days ago"
    if age > _GRYPE_DB_STALE_DAYS:
        log.warning(f"{msg} — findings may be stale; run 'grype db update'")
    else:
        log.info(msg)


def _count_findings(scan_file: Path, fmt: str) -> int:
    """Quick finding count for log context. Returns -1 on parse error."""
    try:
        data = json.loads(scan_file.read_text(encoding="utf-8"))
        if fmt == "sarif":
            runs = data.get("runs") or [{}]
            return len(runs[0].get("results", []))
        return len(data.get("matches", []))
    except Exception as exc:
        log.debug(f"Could not count findings in {scan_file}: {exc}")
        return -1
