from sbom_sentinel.cli import cli

cli()
