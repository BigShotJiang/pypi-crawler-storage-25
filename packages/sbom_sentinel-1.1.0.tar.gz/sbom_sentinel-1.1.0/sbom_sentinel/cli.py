import json
import subprocess
import sys
from pathlib import Path

import click
from rich.console import Console

from sbom_sentinel.pipeline import diff, pdf, report, sbom, scan
from sbom_sentinel.support import kev
from sbom_sentinel.support.log import setup_logging

console = Console(stderr=True)


@click.group()
@click.version_option(package_name="sbom-sentinel")
@click.option("-v", "--verbose", count=True, help="Increase verbosity (-v info, -vv debug).")
@click.option(
    "--log-dir",
    default="logs",
    show_default=True,
    help="Directory for log files.",
)
def cli(verbose: int, log_dir: str) -> None:
    """SBOM generation and vulnerability intelligence pipeline."""
    setup_logging(verbose, Path(log_dir))


@cli.command("sbom")
@click.option("--target", required=True, help="Target: local dir, container image, or git URL.")
@click.option("--name", required=True, help="Name used to label output files.")
@click.option(
    "--output-dir",
    default="sbom_output",
    show_default=True,
    help="Directory for SBOM output.",
)
def sbom_cmd(target: str, name: str, output_dir: str) -> None:
    """Stage 1: Generate an SBOM from a target using Syft."""
    try:
        path = sbom.generate(target, name, Path(output_dir))
        console.print(f"[green][+][/green] SBOM: {path}")
    except (OSError, ValueError) as exc:
        console.print(f"[red][-][/red] {exc}")
        sys.exit(1)
    except subprocess.CalledProcessError:
        console.print("[yellow][!][/yellow] Syft exited with a non-zero status.")
        sys.exit(1)
    except subprocess.TimeoutExpired:
        console.print("[red][-][/red] SBOM generation timed out.")
        sys.exit(1)


@cli.command("scan")
@click.option(
    "--sbom", "sbom_file", required=True, type=click.Path(exists=True, path_type=Path)
)
@click.option("--name", required=True, help="Name used to label output files.")
@click.option(
    "--fail-on",
    type=click.Choice(
        ["critical", "high", "medium", "low", "negligible"], case_sensitive=False
    ),
    default=None,
    help="Exit with code 1 if vulnerabilities at this severity or above are found.",
)
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["json", "sarif"], case_sensitive=False),
    default="json",
    show_default=True,
    help="Output format. 'sarif' enables GitHub Code Scanning integration.",
)
@click.option(
    "--output-dir",
    default="artifacts/json",
    show_default=True,
    help="Directory for scan result output.",
)
@click.option(
    "--vex",
    "vex_file",
    default=None,
    type=click.Path(exists=True, path_type=Path),
    help="OpenVEX or CSAF document. Suppresses findings marked not_affected.",
)
def scan_cmd(
    sbom_file: Path,
    name: str,
    fail_on: str | None,
    fmt: str,
    output_dir: str,
    vex_file: Path | None,
) -> None:
    """Stage 2: Scan an SBOM for vulnerabilities using Grype."""
    try:
        path = scan.run(sbom_file, name, Path(output_dir), fail_on, fmt=fmt, vex=vex_file)
        console.print(f"[green][+][/green] Scan results: {path}")
    except scan.ThresholdTriggered as exc:
        console.print(f"[green][+][/green] Scan results: {exc.path}")
        console.print("[yellow][!][/yellow] --fail-on threshold met.")
        sys.exit(1)
    except OSError as exc:
        console.print(f"[red][-][/red] {exc}")
        sys.exit(1)
    except subprocess.CalledProcessError:
        console.print("[red][-][/red] Grype scan failed.")
        sys.exit(1)
    except subprocess.TimeoutExpired:
        console.print("[red][-][/red] Scan timed out.")
        sys.exit(1)


@cli.command("report")
@click.option(
    "--scan", "scan_file", required=True, type=click.Path(exists=True, path_type=Path)
)
@click.option("--name", required=True, help="Name used to label output files.")
@click.option("--no-kev", is_flag=True, default=False, help="Skip CISA KEV enrichment.")
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["markdown", "html"], case_sensitive=False),
    default="markdown",
    show_default=True,
    help="Report output format.",
)
@click.option(
    "--cache-dir",
    default="cache",
    show_default=True,
    help="Directory for KEV cache.",
)
@click.option(
    "--output-dir",
    default="artifacts/reports/markdown",
    show_default=True,
    help="Directory for report output.",
)
@click.option(
    "--vex",
    "vex_file",
    default=None,
    type=click.Path(exists=True, path_type=Path),
    help="VEX document used during scan. Flags any suppressed findings that are in CISA KEV.",
)
@click.option(
    "--sbom",
    "sbom_file",
    default=None,
    type=click.Path(exists=True, path_type=Path),
    help="Source SBOM. Adds package count, format, and Syft version to the report header.",
)
def report_cmd(
    scan_file: Path,
    name: str,
    no_kev: bool,
    fmt: str,
    cache_dir: str,
    output_dir: str,
    vex_file: Path | None,
    sbom_file: Path | None,
) -> None:
    """Stage 3: Generate a vulnerability report from scan results."""
    kev_set: set[str] = set()
    if not no_kev:
        kev_set = kev.load(Path(cache_dir))

    try:
        path = report.generate(
            scan_file, name, Path(output_dir), kev_set,
            vex=vex_file, fmt=fmt, sbom=sbom_file,
        )
        console.print(f"[green][+][/green] Report: {path}")
    except (ValueError, json.JSONDecodeError) as exc:
        console.print(f"[red][-][/red] {exc}")
        sys.exit(1)


@cli.command("diff")
@click.option(
    "--old", "old_scan", required=True, type=click.Path(exists=True, path_type=Path),
    help="Previous Grype JSON scan result.",
)
@click.option(
    "--new", "new_scan", required=True, type=click.Path(exists=True, path_type=Path),
    help="Current Grype JSON scan result.",
)
@click.option("--name", required=True, help="Name used to label output files.")
@click.option("--no-kev", is_flag=True, default=False, help="Skip CISA KEV enrichment.")
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["markdown", "html"], case_sensitive=False),
    default="markdown",
    show_default=True,
    help="Report output format.",
)
@click.option(
    "--cache-dir", default="cache", show_default=True, help="Directory for KEV cache.",
)
@click.option(
    "--output-dir",
    default="artifacts/reports/markdown",
    show_default=True,
    help="Directory for diff report output.",
)
def diff_cmd(
    old_scan: Path,
    new_scan: Path,
    name: str,
    no_kev: bool,
    fmt: str,
    cache_dir: str,
    output_dir: str,
) -> None:
    """Compare two Grype scans and report new / resolved vulnerabilities."""
    kev_set: set[str] = set()
    if not no_kev:
        kev_set = kev.load(Path(cache_dir))

    try:
        path = diff.generate(old_scan, new_scan, name, Path(output_dir), kev_set, fmt=fmt)
        console.print(f"[green][+][/green] Diff report: {path}")
    except (ValueError, json.JSONDecodeError) as exc:
        console.print(f"[red][-][/red] {exc}")
        sys.exit(1)


@cli.command("pdf")
@click.option(
    "--input",
    "input_file",
    default=None,
    type=click.Path(exists=True, path_type=Path),
    help="Markdown report. Defaults to the latest in --markdown-dir.",
)
@click.option(
    "--markdown-dir",
    default="artifacts/reports/markdown",
    show_default=True,
    help="Directory to search for the latest markdown report.",
)
@click.option(
    "--output-dir",
    default="artifacts/reports/pdf",
    show_default=True,
    help="Directory for PDF output.",
)
def pdf_cmd(
    input_file: Path | None,
    markdown_dir: str,
    output_dir: str,
) -> None:
    """Stage 4 (standalone): Convert a user-edited markdown report to PDF."""
    try:
        if input_file is None:
            input_file = pdf.find_latest_markdown(Path(markdown_dir))
            console.print(f"[i] Using latest markdown: {input_file}")
        path = pdf.generate(input_file, Path(output_dir))
        console.print(f"[green][+][/green] PDF: {path}")
    except FileNotFoundError as exc:
        console.print(f"[red][-][/red] {exc}")
        sys.exit(1)
    except RuntimeError as exc:
        # Raised when the optional 'pdf' extra isn't installed.
        console.print(f"[red][-][/red] {exc}")
        sys.exit(1)


@cli.command("run")
@click.option(
    "--sbom",
    "sbom_file",
    default=None,
    type=click.Path(exists=True, path_type=Path),
    help="Path to an existing SPDX-JSON SBOM. Mutually exclusive with --target.",
)
@click.option(
    "--target",
    default=None,
    help="Target (local dir, container image, or git URL). Mutually exclusive with --sbom.",
)
@click.option("--name", required=True, help="Name used to label output files.")
@click.option(
    "--fail-on",
    type=click.Choice(
        ["critical", "high", "medium", "low", "negligible"], case_sensitive=False
    ),
    default=None,
    help="Exit with code 1 if vulnerabilities at this severity or above are found.",
)
@click.option("--no-kev", is_flag=True, default=False, help="Skip CISA KEV enrichment.")
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["json", "sarif"], case_sensitive=False),
    default="json",
    show_default=True,
    help="Scan output format. 'sarif' enables GitHub Code Scanning integration.",
)
@click.option(
    "--report-format",
    type=click.Choice(["markdown", "html"], case_sensitive=False),
    default="markdown",
    show_default=True,
    help="Report output format.",
)
@click.option(
    "--sbom-dir",
    default="sbom_output",
    show_default=True,
    help="Directory for SBOM output (when using --target).",
)
@click.option(
    "--scan-dir",
    default="artifacts/json",
    show_default=True,
    help="Directory for scan result output.",
)
@click.option(
    "--report-dir",
    default="artifacts/reports/markdown",
    show_default=True,
    help="Directory for report output.",
)
@click.option(
    "--cache-dir",
    default="cache",
    show_default=True,
    help="Directory for KEV cache.",
)
@click.option(
    "--vex",
    "vex_file",
    default=None,
    type=click.Path(exists=True, path_type=Path),
    help="OpenVEX or CSAF document. Passed to Grype; suppressed KEV findings flagged in report.",
)
def run_cmd(
    sbom_file: Path | None,
    target: str | None,
    name: str,
    fail_on: str | None,
    no_kev: bool,
    fmt: str,
    report_format: str,
    sbom_dir: str,
    scan_dir: str,
    report_dir: str,
    cache_dir: str,
    vex_file: Path | None,
) -> None:
    """Run the full pipeline (sbom when --target, scan, report)."""
    if bool(sbom_file) == bool(target):
        raise click.UsageError("Provide exactly one of --sbom or --target.")

    # Stage 1: sbom (only when --target given)
    if target:
        try:
            sbom_file = sbom.generate(target, name, Path(sbom_dir))
            console.print(f"[green][+][/green] SBOM: {sbom_file}")
        except (OSError, ValueError) as exc:
            console.print(f"[red][-][/red] {exc}")
            sys.exit(1)
        except subprocess.CalledProcessError:
            console.print("[yellow][!][/yellow] Syft exited with a non-zero status.")
            sys.exit(1)
        except subprocess.TimeoutExpired:
            console.print("[red][-][/red] SBOM generation timed out.")
            sys.exit(1)

    assert sbom_file is not None  # guaranteed by validation above

    # Stage 2: scan. A --fail-on threshold hit is not a scan failure — we still
    # want to produce the report, then exit 1 afterwards.
    threshold_triggered = False
    try:
        scan_path = scan.run(
            sbom_file, name, Path(scan_dir), fail_on, fmt=fmt, vex=vex_file
        )
        console.print(f"[green][+][/green] Scan results: {scan_path}")
    except scan.ThresholdTriggered as exc:
        scan_path = exc.path
        threshold_triggered = True
        console.print(f"[green][+][/green] Scan results: {scan_path}")
        console.print("[yellow][!][/yellow] --fail-on threshold met; continuing to report.")
    except OSError as exc:
        console.print(f"[red][-][/red] {exc}")
        sys.exit(1)
    except subprocess.CalledProcessError:
        console.print("[red][-][/red] Grype scan failed.")
        sys.exit(1)
    except subprocess.TimeoutExpired:
        console.print("[red][-][/red] Scan timed out.")
        sys.exit(1)

    # Stage 3: report
    kev_set: set[str] = set()
    if not no_kev:
        kev_set = kev.load(Path(cache_dir))

    try:
        report_path = report.generate(
            scan_path, name, Path(report_dir), kev_set,
            vex=vex_file, fmt=report_format, sbom=sbom_file,
        )
        console.print(f"[green][+][/green] Report: {report_path}")
    except (ValueError, json.JSONDecodeError) as exc:
        console.print(f"[red][-][/red] {exc}")
        sys.exit(1)

    if threshold_triggered:
        sys.exit(1)

