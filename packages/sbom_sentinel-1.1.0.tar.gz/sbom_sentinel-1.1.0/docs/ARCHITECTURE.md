# Architecture

## Pipeline Overview

```
target --[sbom]--> *.spdx.json --[scan]--> *.json --[report]--> *.md / *.html
         Syft                     Grype                CISA KEV
                                  VEX (opt)            VEX (opt)
```

Each stage has a dedicated command. The `run` command orchestrates the pipeline end-to-end:

- `run --target <target>` runs all three stages (sbom + scan + report)
- `run --sbom <path>` runs stages 2 and 3 against an existing SBOM

## Package Structure

```
sbom_sentinel/
    __init__.py
    __main__.py          # python -m sbom_sentinel
    cli.py               # Click commands and error handling
    pipeline/
        sbom.py          # Stage 1: SBOM generation (Syft)
        scan.py          # Stage 2: vulnerability scan (Grype)
        report.py        # Stage 3: Markdown or HTML report with KEV/VEX
    support/
        kev.py           # CISA KEV catalog download and cache
        target.py        # Resolve target strings to typed values
        log.py           # Shared logger with ASCII prefixes
```

## Module Reference

| Module | Responsibility | External dependency |
|--------|---------------|---------------------|
| `cli.py` | Click command definitions and user-facing error handling | — |
| `pipeline/sbom.py` | SBOM generation; clones remote Git URLs to a temporary directory | Syft, git |
| `pipeline/scan.py` | Vulnerability scan; writes JSON or SARIF output from Grype stdout | Grype |
| `pipeline/report.py` | Parse Grype JSON, apply KEV and VEX annotations, render Markdown or HTML | — |
| `support/kev.py` | Download and date-stamp-cache the CISA KEV catalog | CISA feed (HTTPS) |
| `support/target.py` | Resolve a target string to a typed value (dir, file, image, git) | — |
| `support/log.py` | Shared logger factory (`logging.getLogger`) | — |

## Data Flow

| Stage | Input | Output | Default location |
|-------|-------|--------|-----------------|
| `sbom` | Target path or URL | `<name>_<timestamp>.spdx.json` | `sbom_output/` |
| `scan` | SPDX-JSON file | `<name>_<timestamp>.json` or `.sarif` | `artifacts/json/` |
| `report` | Grype JSON file | `<name>_<timestamp>.md` or `.html` | `artifacts/reports/` |

## Design Decisions

**SPDX-JSON as the interchange format.** Both Syft and Grype support SPDX-JSON natively. It is an open standard with broad toolchain support, making the SBOM artifact reusable outside of sbom-sentinel.

**SBOM generation is opt-in for `run`.** The `run` command accepts either `--target` (runs all three stages) or `--sbom` (runs scan + report against an existing SBOM). SBOM generation is the most expensive stage and the output rarely changes between scans, so users can reuse an SBOM across multiple scans when vulnerability data changes but the code does not.

**Date-stamped KEV cache.** The cache file is named `kev_YYYYMMDD.json`. This avoids TTL drift during long-running workflows while ensuring the catalog is refreshed at most once per calendar day. On download failure with no usable cache the pipeline continues with an empty KEV set and logs a warning.

**Subprocess timeouts enforced.** Syft (600 s), Grype (300 s), and git clone (120 s) all have explicit `timeout=` arguments. Security scanners can hang indefinitely on large dependency graphs or slow network conditions; a timeout surfaces the failure clearly rather than blocking a CI job.

**VEX conflict reporting.** When a VEX document suppresses a CVE that also appears in CISA KEV, the report adds a dedicated warning section. Suppressing an actively-exploited vulnerability warrants explicit human review, not silent omission.

**UTC timestamps everywhere.** All file timestamps and report headers use `datetime.now(tz=UTC)`. This avoids ambiguity when artifacts are generated across time zones or in CI environments.
