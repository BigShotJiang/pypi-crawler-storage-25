# Backlog

Open items and future work. Completed items are pruned — check git history for the original build plan.

---

## Known Upstream Issues

### CycloneDX Distro Group Bug — Fix Merged, Awaiting Release

Syft's CycloneDX decoder prepends `component.group` to the package name for all non-Java
types, producing names like `debian/wget` instead of `wget`. Grype's vuln DB lookup then
silently returns zero matches — a Syft -> CycloneDX -> Grype pipeline yields empty results
with no error for Debian/RPM/Alpine container packages.

Tracking:
- Grype issue: https://github.com/anchore/grype/issues/2967
- Syft PR: https://github.com/anchore/syft/pull/4791 (merged, awaiting release)

Blocked on dependency chain:
1. Syft release containing the fix (next cut after v1.42.4)
2. Grype bumps its syft dep to that version
3. Grype release ships
4. Update the `syft` and `grype` binaries on PATH

SBOM format is pinned to `spdx-json` as a hard constraint until the full chain lands. When
it does, run a direct comparison test before flipping the default: scan the same target
with both formats and diff the CVE lists. They should match; if they don't, stay on
SPDX-JSON and file a bug.

Known narrow gaps that remain after this fix (likely not relevant to container scanning):
- syft#3961 — Swift packages missing group field on encode
- grype#2418 — `metadata.component.version` stripped on Grype's CycloneDX pass-through
  output (cosmetic)

### Grype JSON v1.0 Redesign (In Progress)

Grype is restructuring its JSON output schema for v1.0:
https://github.com/anchore/grype/issues/3144

`pipeline/report.py` parses all fields defensively (`.get()` everywhere). When v1.0 ships,
`scan.py` and `report.py` will need updating to handle the new schema.

---

## Features

_No open feature work. Future ideas can be added here as they come up._
