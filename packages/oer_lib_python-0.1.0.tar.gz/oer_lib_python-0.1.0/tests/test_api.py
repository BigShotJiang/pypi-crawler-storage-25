import json

from oer_lib import C_Controller, CatalogConfig, SearchOptions


def test_default_options_returns_dataclass() -> None:
    options = C_Controller.default_options()

    assert isinstance(options, SearchOptions)
    assert 0.0 <= options.fuzzy_threshold <= 1.0
    assert 0.0 <= options.single_word_threshold <= 1.0


def test_search_returns_structured_results() -> None:
    organizations = ["OpenAI", "Google"]
    events = [("OpenAI", "DevDay"), ("Google", "I/O")]

    with C_Controller.from_records(organizations, events, CatalogConfig.empty()) as controller:
        results = controller.search("OpenAI проведет DevDay в ноябре")

    assert len(results) == 1
    assert results[0].organization.name == "OpenAI"
    assert results[0].event is not None
    assert results[0].event.name == "DevDay"


def test_search_json_returns_native_payload() -> None:
    with C_Controller.from_records(["OpenAI"], [("OpenAI", "DevDay")]) as controller:
        payload = json.loads(controller.search_json("DevDay от OpenAI"))

    assert payload
    assert payload[0]["organization"]["name"] == "OpenAI"
