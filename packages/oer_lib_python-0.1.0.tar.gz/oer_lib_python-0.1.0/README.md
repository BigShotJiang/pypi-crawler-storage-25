# oer-lib-python

`oer-lib-python` is a small Python wrapper around the native `oer_lib` shared library.
It lets you build an in-memory catalog of organizations and events, search text against it,
and receive structured Python objects or raw JSON results.

## Features

- Thin `ctypes`-based binding with no runtime Python dependencies.
- Structured dataclass results for organizations, events, and text spans.
- Configurable search options and catalog token filtering.
- Bundled Linux shared library for immediate local use.

## Installation

```bash
pip install oer-lib-python
```

This package currently bundles a prebuilt `liboer_lib.so` for Linux `x86_64`.
If you target another platform, build and ship a compatible shared library first.

## Quick Start

```python
from oer_lib import C_Controller, CatalogConfig

organizations = ["OpenAI", "Google"]
events = [
    ("OpenAI", "DevDay"),
    ("Google", "I/O"),
]

with C_Controller.from_records(
    organizations=organizations,
    events=events,
    config=CatalogConfig.empty(),
) as controller:
    results = controller.search("OpenAI проведет DevDay в ноябре")
    print(results)
```

## API Overview

Main exports:

- `C_Controller`
- `CatalogConfig`
- `SearchOptions`
- `SearchResult`
- `ResolvedOrganization`
- `ResolvedEvent`
- `TextSpan`

`C_Controller.search()` returns parsed dataclasses.
`C_Controller.search_json()` returns the raw JSON produced by the native library.

## Development

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .[dev]
pytest
python -m build
```

## Publishing Notes

- The wheel includes `src/oer_lib/liboer_lib.so`.
- The source distribution includes the same binary via `MANIFEST.in`.
- Before publishing, verify that the bundled shared library matches your supported target platform.
