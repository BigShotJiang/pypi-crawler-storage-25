import json
from ctypes import CDLL, Structure, c_bool, c_char_p, c_double, c_void_p, cast
from dataclasses import dataclass
from pathlib import Path

__all__ = [
    "CatalogConfig",
    "C_Controller",
    "ResolvedEvent",
    "ResolvedOrganization",
    "SearchOptions",
    "SearchResult",
    "TextSpan",
]


@dataclass(slots=True)
class SearchOptions:
    allow_fuzzy: bool = True
    fuzzy_threshold: float = 0.93
    single_word_threshold: float = 0.97


@dataclass(slots=True)
class CatalogConfig:
    stopwords: list[str]
    stopword_prefixes: list[str]
    generic_event_tokens: list[str]

    @classmethod
    def empty(cls) -> "CatalogConfig":
        return cls(stopwords=[], stopword_prefixes=[], generic_event_tokens=[])


@dataclass(slots=True)
class TextSpan:
    start: int
    end: int
    text: str


@dataclass(slots=True)
class ResolvedOrganization:
    name: str
    matched: bool
    span: TextSpan | None


@dataclass(slots=True)
class ResolvedEvent:
    name: str
    organization_name: str
    matched: bool
    inferred: bool
    score: float
    matched_tokens: int
    span: TextSpan | None


@dataclass(slots=True)
class SearchResult:
    source: str
    organization: ResolvedOrganization
    event: ResolvedEvent | None


class _CSearchOptions(Structure):
    _fields_ = [
        ("allow_fuzzy", c_bool),
        ("fuzzy_threshold", c_double),
        ("single_word_threshold", c_double),
    ]


class _Bindings:
    def __init__(self, library_path: Path) -> None:
        self._lib = CDLL(str(library_path))
        self._configure_signatures()

    def _configure_signatures(self) -> None:
        self._lib.oer_lib_search_options_default.argtypes = []
        self._lib.oer_lib_search_options_default.restype = _CSearchOptions

        self._lib.oer_lib_last_error_message.argtypes = []
        self._lib.oer_lib_last_error_message.restype = c_char_p

        self._lib.oer_lib_catalog_create_from_json_with_config.argtypes = [
            c_char_p,
            c_char_p,
            c_char_p,
            c_char_p,
            c_char_p,
        ]
        self._lib.oer_lib_catalog_create_from_json_with_config.restype = c_void_p

        self._lib.oer_lib_catalog_free.argtypes = [c_void_p]
        self._lib.oer_lib_catalog_free.restype = None

        self._lib.oer_lib_catalog_search_json.argtypes = [c_void_p, c_char_p, _CSearchOptions]
        self._lib.oer_lib_catalog_search_json.restype = c_void_p

        self._lib.oer_lib_string_free.argtypes = [c_void_p]
        self._lib.oer_lib_string_free.restype = None

    def default_options(self) -> SearchOptions:
        raw = self._lib.oer_lib_search_options_default()
        return SearchOptions(
            allow_fuzzy=raw.allow_fuzzy,
            fuzzy_threshold=raw.fuzzy_threshold,
            single_word_threshold=raw.single_word_threshold,
        )

    def create_catalog(
        self,
        organizations: list[str],
        events: list[tuple[str, str]],
        config: CatalogConfig | None = None,
    ) -> c_void_p:
        config = config or CatalogConfig.empty()
        organizations_json = json.dumps(organizations, ensure_ascii=False).encode("utf-8")
        events_json = json.dumps(
            [{"organization": organization, "name": event_name} for organization, event_name in events],
            ensure_ascii=False,
        ).encode("utf-8")
        stopwords_json = json.dumps(config.stopwords, ensure_ascii=False).encode("utf-8")
        stopword_prefixes_json = json.dumps(
            config.stopword_prefixes,
            ensure_ascii=False,
        ).encode("utf-8")
        generic_event_tokens_json = json.dumps(
            config.generic_event_tokens,
            ensure_ascii=False,
        ).encode("utf-8")

        catalog = self._lib.oer_lib_catalog_create_from_json_with_config(
            organizations_json,
            events_json,
            stopwords_json,
            stopword_prefixes_json,
            generic_event_tokens_json,
        )
        if not catalog:
            raise RuntimeError(self.last_error())
        return catalog

    def search_json(self, catalog: c_void_p, text: str, options: SearchOptions) -> str:
        raw_options = _CSearchOptions(
            allow_fuzzy=options.allow_fuzzy,
            fuzzy_threshold=options.fuzzy_threshold,
            single_word_threshold=options.single_word_threshold,
        )
        raw_result = self._lib.oer_lib_catalog_search_json(
            catalog,
            text.encode("utf-8"),
            raw_options,
        )
        if not raw_result:
            raise RuntimeError(self.last_error())

        try:
            value = cast(raw_result, c_char_p).value
            if value is None:
                raise RuntimeError("oer_lib returned an empty result pointer")
            return value.decode("utf-8")
        finally:
            self._lib.oer_lib_string_free(raw_result)

    def free_catalog(self, catalog: c_void_p) -> None:
        self._lib.oer_lib_catalog_free(catalog)

    def last_error(self) -> str:
        message = self._lib.oer_lib_last_error_message()
        if not message:
            return "unknown oer_lib error"
        return message.decode("utf-8", errors="replace")


class C_Controller:
    def __init__(self, bindings: _Bindings, catalog: c_void_p) -> None:
        self._bindings = bindings
        self._catalog = catalog
        self._closed = False

    @classmethod
    def from_records(
        cls,
        organizations: list[str],
        events: list[tuple[str, str]],
        config: CatalogConfig | None = None,
        library_path: str | Path | None = None,
    ) -> "C_Controller":
        bindings = _Bindings(_resolve_library_path(library_path))
        catalog = bindings.create_catalog(organizations, events, config)
        return cls(bindings, catalog)

    @staticmethod
    def default_options(library_path: str | Path | None = None) -> SearchOptions:
        return _Bindings(_resolve_library_path(library_path)).default_options()

    def search(self, text: str, options: SearchOptions | None = None) -> list[SearchResult]:
        payload = json.loads(self.search_json(text, options))
        return [parse_search_result(item) for item in payload]

    def search_json(self, text: str, options: SearchOptions | None = None) -> str:
        if self._closed:
            raise RuntimeError("oer_lib is already closed")
        return self._bindings.search_json(
            self._catalog,
            text,
            options or self._bindings.default_options(),
        )

    def close(self) -> None:
        if not self._closed:
            self._bindings.free_catalog(self._catalog)
            self._closed = True

    def __enter__(self) -> "C_Controller":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()


def _resolve_library_path(explicit_path: str | Path | None) -> Path:
    if explicit_path is None:
        path = Path(__file__).resolve().with_name("liboer_lib.so")
    else:
        path = Path(explicit_path).expanduser().resolve()

    if not path.is_file():
        raise FileNotFoundError(f"Shared library not found: {path}")
    return path


def parse_search_result(payload: dict) -> SearchResult:
    return SearchResult(
        source=payload["source"],
        organization=ResolvedOrganization(
            name=payload["organization"]["name"],
            matched=payload["organization"]["matched"],
            span=parse_span(payload["organization"]["span"]),
        ),
        event=(
            None
            if payload["event"] is None
            else ResolvedEvent(
                name=payload["event"]["name"],
                organization_name=payload["event"]["organization_name"],
                matched=payload["event"]["matched"],
                inferred=payload["event"]["inferred"],
                score=payload["event"]["score"],
                matched_tokens=payload["event"]["matched_tokens"],
                span=parse_span(payload["event"]["span"]),
            )
        ),
    )


def parse_span(payload: dict | None) -> TextSpan | None:
    if payload is None:
        return None
    return TextSpan(
        start=payload["start"],
        end=payload["end"],
        text=payload["text"],
    )
