"""Python bindings for the ``oer_lib`` shared library."""

from .controller import (
    C_Controller,
    CatalogConfig,
    ResolvedEvent,
    ResolvedOrganization,
    SearchOptions,
    SearchResult,
    TextSpan,
)

__version__ = "0.1.0"

__all__ = [
    "CatalogConfig",
    "C_Controller",
    "ResolvedEvent",
    "ResolvedOrganization",
    "SearchOptions",
    "SearchResult",
    "TextSpan",
    "__version__",
]
