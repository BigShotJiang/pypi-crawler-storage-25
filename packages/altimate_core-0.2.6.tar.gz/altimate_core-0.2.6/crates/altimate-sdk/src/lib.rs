//! Shared SDK: telemetry, PII masking, credit gating, failure reporting.
//!
//! Used by both `altimate-core-python` (PyO3) and `altimate-core-node` (napi-rs).
//! All telemetry flows through a single background worker thread — fire-and-forget,
//! bounded channel (capacity 64), 10s HTTP timeout. Callers never block.
//!
//! App Insights telemetry fires WITHOUT `init()`. Only backend API calls need credentials.
//! Disable via env vars (`ALTIMATE_TELEMETRY=0`, `ALTIMATE_TELEMETRY_DISABLED=true`)
//! or `init(..., telemetry=false)`.

use regex::Regex;
use std::sync::mpsc::Sender as StdSender;
use std::sync::mpsc::{SyncSender, sync_channel};
use std::sync::{LazyLock, Mutex, OnceLock};
use uuid::Uuid;

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

struct SdkConfig {
    api_key: String,
    tenant: String,
    backend_url: String,
    report_failures: bool,
    telemetry: bool,
}

static SDK_CONFIG: Mutex<Option<SdkConfig>> = Mutex::new(None);

/// Which binding layer is using this SDK.
static BINDING: OnceLock<String> = OnceLock::new();

/// Set the binding type. Call once at crate init (e.g. "python", "node").
pub fn set_binding(binding: &str) {
    let _ = BINDING.set(binding.to_owned());
}

fn binding() -> &'static str {
    BINDING.get().map(|s| s.as_str()).unwrap_or("unknown")
}

// ---------------------------------------------------------------------------
// Machine ID — persistent anonymous device identifier
// ---------------------------------------------------------------------------

/// Cached machine ID, loaded once on first use.
static MACHINE_ID: OnceLock<String> = OnceLock::new();

/// Returns the persistent machine ID from `~/.altimate/machine-id`.
/// Creates the file with a new UUID v4 if it doesn't exist.
/// Falls back to a per-process random UUID if the file cannot be read or written.
fn machine_id() -> &'static str {
    MACHINE_ID.get_or_init(|| {
        if let Some(home) = std::env::var_os("HOME") {
            let dir = std::path::Path::new(&home).join(".altimate");
            let path = dir.join("machine-id");
            if let Ok(id) = std::fs::read_to_string(&path) {
                let id = id.trim().to_owned();
                if !id.is_empty() {
                    return id;
                }
            }
            let id = Uuid::new_v4().to_string();
            let _ = std::fs::create_dir_all(&dir);
            let _ = std::fs::write(&path, &id);
            return id;
        }
        Uuid::new_v4().to_string()
    })
}

// ---------------------------------------------------------------------------
// Azure App Insights
// ---------------------------------------------------------------------------

const APPINSIGHTS_IKEY: &str = "da5d7672-66ee-4c3c-9be9-29468d9cac6b";
const APPINSIGHTS_ENDPOINT: &str = "https://westus2-2.in.applicationinsights.azure.com/v2/track";

// ---------------------------------------------------------------------------
// Background worker
// ---------------------------------------------------------------------------

enum BgTask {
    CountCredit {
        api_key: String,
        tenant: String,
        backend_url: String,
        dataset_type: String,
        count: usize,
    },
    ReportFailure {
        api_key: String,
        tenant: String,
        backend_url: String,
        operation: String,
        args: serde_json::Map<String, serde_json::Value>,
        duration_ms: u64,
        reason: String,
    },
    Telemetry {
        event_name: String,
        tenant: String,
        properties: serde_json::Map<String, serde_json::Value>,
        measurements: serde_json::Map<String, serde_json::Value>,
    },
    Flush {
        reply: StdSender<()>,
    },
}

// ---------------------------------------------------------------------------
// PII masking
// ---------------------------------------------------------------------------

// Matches single-quoted SQL string literals. Handles both escape conventions:
// - Backslash escaping: 'it\'s'
// - SQL-standard double-quote escaping: 'it''s'
static RE_STRING: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"'(?:[^'\\]|\\.|'')*'").unwrap());
static RE_WHITESPACE: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"\s+").unwrap());

/// Keys whose values are always fully redacted to `"****"`.
/// Case-insensitive match against JSON object keys.
const SENSITIVE_KEYS: &[&str] = &[
    "key",
    "api_key",
    "apikey",
    "token",
    "access_token",
    "refresh_token",
    "secret",
    "secret_key",
    "password",
    "passwd",
    "pwd",
    "credential",
    "credentials",
    "authorization",
    "auth",
    "signature",
    "sig",
    "private_key",
    "connection_string",
];

/// Check if a JSON key name is sensitive (case-insensitive).
fn is_sensitive_key(key: &str) -> bool {
    let lower = key.to_lowercase();
    SENSITIVE_KEYS.iter().any(|&k| {
        lower == k || lower.ends_with(&format!("_{k}")) || lower.starts_with(&format!("{k}_"))
    })
}

/// Truncate a string to at most `max_bytes` bytes without splitting a UTF-8 character.
fn truncate_to_char_boundary(s: &str, max_bytes: usize) -> &str {
    if s.len() <= max_bytes {
        return s;
    }
    let mut boundary = max_bytes;
    while !s.is_char_boundary(boundary) {
        boundary -= 1;
    }
    &s[..boundary]
}

/// Mask string literals (`'...'` → `?`) and collapse whitespace. Generic — works on any string.
fn mask_string(s: &str) -> String {
    let s = RE_STRING.replace_all(s, "?");
    let s = RE_WHITESPACE.replace_all(&s, " ");
    s.trim().to_owned()
}

/// Recursively mask PII from a JSON value.
///
/// - Sensitive keys (`key`, `token`, `secret`, `password`, etc.) → value replaced with `"****"`
/// - All other strings → single-quoted literals replaced with `?`, whitespace collapsed
/// - Numbers, booleans, nulls pass through unchanged
fn mask_value(v: &serde_json::Value) -> serde_json::Value {
    mask_value_inner(v, None)
}

fn mask_value_inner(v: &serde_json::Value, key: Option<&str>) -> serde_json::Value {
    // If this value lives under a sensitive key, redact entirely
    if let Some(k) = key
        && is_sensitive_key(k)
    {
        return serde_json::Value::String("****".into());
    }
    match v {
        serde_json::Value::String(s) => serde_json::Value::String(mask_string(s)),
        serde_json::Value::Object(map) => {
            let masked: serde_json::Map<String, serde_json::Value> = map
                .iter()
                .map(|(k, v)| (k.clone(), mask_value_inner(v, Some(k))))
                .collect();
            serde_json::Value::Object(masked)
        }
        serde_json::Value::Array(arr) => {
            serde_json::Value::Array(arr.iter().map(|v| mask_value_inner(v, key)).collect())
        }
        _ => v.clone(),
    }
}

/// Classify a failure reason into a category.
fn classify_reason(reason: &str) -> &'static str {
    let lower = reason.to_lowercase();
    if lower.contains("parse") || lower.contains("syntax") || lower.contains("unexpected token") {
        "parse_error"
    } else if lower.contains("connection") || lower.contains("socket") {
        "connection"
    } else if lower.contains("timeout") {
        "timeout"
    } else if lower.contains("permission") || lower.contains("denied") {
        "permission"
    } else if lower.contains("emptylineage") {
        "empty_result"
    } else {
        "unknown"
    }
}

// ---------------------------------------------------------------------------
// Worker thread
// ---------------------------------------------------------------------------

/// Try to get (or create) the background sender. Returns `None` if the worker
/// thread couldn't be spawned — telemetry is silently disabled, never crashes.
fn try_bg_sender() -> Option<&'static SyncSender<BgTask>> {
    // Two-phase init: OnceLock stores Option<SyncSender> so we can represent
    // "tried to init but thread spawn failed" as None without panicking.
    static SENDER: OnceLock<Option<SyncSender<BgTask>>> = OnceLock::new();
    SENDER
        .get_or_init(|| {
            let (tx, rx) = sync_channel::<BgTask>(64);
            match std::thread::Builder::new()
                .name("sdk-bg".into())
                .spawn(move || run_worker(rx))
            {
                Ok(_) => Some(tx),
                Err(_) => None, // Thread spawn failed — degrade gracefully
            }
        })
        .as_ref()
}

/// Background worker loop. Processes tasks sequentially, never panics.
fn run_worker(rx: std::sync::mpsc::Receiver<BgTask>) {
    let agent = ureq::AgentBuilder::new()
        .timeout(std::time::Duration::from_secs(10))
        .build();

    while let Ok(task) = rx.recv() {
        match task {
            BgTask::CountCredit {
                api_key,
                tenant,
                backend_url,
                dataset_type,
                count,
            } => {
                let url = format!("{backend_url}/sdk/count_credits");
                let _ = agent
                    .post(&url)
                    .set("Authorization", &format!("Bearer {api_key}"))
                    .set("x-tenant", &tenant)
                    .send_json(serde_json::json!({
                        "dataset_type": dataset_type,
                        "count": count,
                    }));
            }
            BgTask::ReportFailure {
                api_key,
                tenant,
                backend_url,
                operation,
                args,
                duration_ms,
                reason,
            } => {
                let url = format!("{backend_url}/sdk/failures");
                let mut body = serde_json::Map::new();
                body.insert("operation".into(), serde_json::json!(operation));
                body.insert("args".into(), serde_json::Value::Object(args));
                body.insert("duration_ms".into(), serde_json::json!(duration_ms));
                body.insert("reason".into(), serde_json::json!(reason));
                body.insert(
                    "sdk_version".into(),
                    serde_json::json!(env!("CARGO_PKG_VERSION")),
                );
                body.insert("binding".into(), serde_json::json!(binding()));
                let _ = agent
                    .post(&url)
                    .set("Authorization", &format!("Bearer {api_key}"))
                    .set("x-tenant", &tenant)
                    .send_json(serde_json::Value::Object(body));
            }
            BgTask::Telemetry {
                event_name,
                tenant,
                properties,
                measurements,
            } => {
                let now = chrono_now();
                let mut props = properties;
                props.insert("tenant".into(), serde_json::json!(tenant));
                props.insert(
                    "sdk_version".into(),
                    serde_json::json!(env!("CARGO_PKG_VERSION")),
                );
                props.insert("binding".into(), serde_json::json!(binding()));
                props.insert("machine_id".into(), serde_json::json!(machine_id()));
                let envelope = serde_json::json!({
                    "name": "Microsoft.ApplicationInsights.Event",
                    "time": now,
                    "iKey": APPINSIGHTS_IKEY,
                    "data": {
                        "baseType": "EventData",
                        "baseData": {
                            "ver": 2,
                            "name": event_name,
                            "properties": props,
                            "measurements": measurements,
                        }
                    }
                });
                let _ = agent
                    .post(APPINSIGHTS_ENDPOINT)
                    .set("Content-Type", "application/json")
                    .send_json(envelope);
            }
            BgTask::Flush { reply } => {
                let _ = reply.send(());
            }
        }
    }
}

fn chrono_now() -> String {
    use std::time::{SystemTime, UNIX_EPOCH};
    let d = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default();
    let secs = d.as_secs();
    let (days, rem) = (secs / 86400, secs % 86400);
    let (h, rem) = (rem / 3600, rem % 3600);
    let (m, s) = (rem / 60, rem % 60);
    let (y, mo, d) = days_to_ymd(days);
    format!("{y:04}-{mo:02}-{d:02}T{h:02}:{m:02}:{s:02}Z")
}

fn days_to_ymd(mut days: u64) -> (u64, u64, u64) {
    let mut y = 1970;
    loop {
        let dy = if y % 4 == 0 && (y % 100 != 0 || y % 400 == 0) {
            366
        } else {
            365
        };
        if days < dy {
            break;
        }
        days -= dy;
        y += 1;
    }
    let leap = y % 4 == 0 && (y % 100 != 0 || y % 400 == 0);
    let mdays = [
        31,
        if leap { 29 } else { 28 },
        31,
        30,
        31,
        30,
        31,
        31,
        30,
        31,
        30,
        31,
    ];
    let mut mo = 0;
    for md in &mdays {
        if days < *md {
            break;
        }
        days -= md;
        mo += 1;
    }
    (y, mo + 1, days + 1)
}

// ---------------------------------------------------------------------------
// Public API: init / reset / flush / is_initialized
// ---------------------------------------------------------------------------

/// Initialize the SDK with credentials.
pub fn init(
    api_key: String,
    tenant: String,
    backend_url: String,
    report_failures: bool,
    telemetry: bool,
) -> Result<(), String> {
    let mut config = SDK_CONFIG
        .lock()
        .map_err(|_| "SDK config lock poisoned".to_owned())?;
    *config = Some(SdkConfig {
        api_key,
        tenant,
        backend_url,
        report_failures,
        telemetry,
    });
    Ok(())
}

/// Reset SDK state. For testing only.
pub fn reset() -> Result<(), String> {
    let mut config = SDK_CONFIG
        .lock()
        .map_err(|_| "SDK config lock poisoned".to_owned())?;
    *config = None;
    Ok(())
}

/// Drain the queue. The worker thread stays alive so subsequent events
/// are still delivered. The thread exits naturally when the process ends
/// (all `SyncSender` clones drop → `rx.recv()` returns `Err`).
pub fn flush() {
    if let Some(sender) = try_bg_sender() {
        let (tx, rx) = std::sync::mpsc::channel();
        if sender.try_send(BgTask::Flush { reply: tx }).is_ok() {
            let _ = rx.recv_timeout(std::time::Duration::from_secs(5));
        }
    }
}

/// Check if SDK has been initialized (non-failing).
pub fn is_initialized() -> bool {
    SDK_CONFIG
        .lock()
        .map(|config| config.is_some())
        .unwrap_or(false)
}

// ---------------------------------------------------------------------------
// Credit check (synchronous — gates the operation)
// ---------------------------------------------------------------------------

/// Check if credits are available. Returns `Err` with a human-readable message on failure.
pub fn check_credits(dataset_type: &str) -> Result<(), String> {
    let (api_key, tenant, backend_url) = {
        let config = SDK_CONFIG
            .lock()
            .map_err(|_| "SDK config lock poisoned".to_owned())?;
        let c = config.as_ref().ok_or("SDK not initialized")?;
        (c.api_key.clone(), c.tenant.clone(), c.backend_url.clone())
    };

    let url = format!("{backend_url}/sdk/available_credits");
    let agent = ureq::AgentBuilder::new()
        .timeout(std::time::Duration::from_secs(10))
        .build();
    let result = agent
        .post(&url)
        .set("Authorization", &format!("Bearer {api_key}"))
        .set("x-tenant", &tenant)
        .send_json(serde_json::json!({"dataset_type": dataset_type}));

    match result {
        Ok(_) => Ok(()),
        Err(ureq::Error::Status(402, _)) => Err("No credits remaining".into()),
        Err(ureq::Error::Status(401, _)) | Err(ureq::Error::Status(403, _)) => {
            Err("Invalid credentials".into())
        }
        Err(e) => Err(format!("Failed to verify credits: {e}")),
    }
}

// ---------------------------------------------------------------------------
// Background: credit deduction, failure reporting, telemetry
// ---------------------------------------------------------------------------

/// Deduct credits for a successful operation. Fire-and-forget.
pub fn count_credit(dataset_type: &str, count: usize) {
    let (api_key, tenant, backend_url) = match SDK_CONFIG.lock() {
        Ok(guard) => match guard.as_ref() {
            Some(c) => (c.api_key.clone(), c.tenant.clone(), c.backend_url.clone()),
            None => return,
        },
        Err(_) => return,
    };
    if let Some(s) = try_bg_sender() {
        let _ = s.try_send(BgTask::CountCredit {
            api_key,
            tenant,
            backend_url,
            dataset_type: dataset_type.to_owned(),
            count,
        });
    }
}

/// Report a failure with all args, PII-masked. Generic — works for any operation.
///
/// Two paths:
/// 1. Backend `/sdk/failures` — gated behind `init()` + `report_failures` flag
/// 2. App Insights `sdk/core_failure` — ALWAYS fires (no init required)
pub fn report_failure(
    operation: &str,
    args: serde_json::Map<String, serde_json::Value>,
    duration_ms: u64,
    reason: &str,
) {
    let error_class = classify_reason(reason);
    let masked_args: serde_json::Map<String, serde_json::Value> = args
        .iter()
        .map(|(k, v)| (k.clone(), mask_value(v)))
        .collect();
    // Mask reason once — used by both backend and App Insights paths.
    let masked_reason = mask_string(reason);
    let masked_reason = truncate_to_char_boundary(&masked_reason, 500);

    // 1. Backend — needs init + credentials
    if let Ok(guard) = SDK_CONFIG.lock()
        && let Some(c) = guard.as_ref()
        && should_report(c)
        && let Some(s) = try_bg_sender()
    {
        let _ = s.try_send(BgTask::ReportFailure {
            api_key: c.api_key.clone(),
            tenant: c.tenant.clone(),
            backend_url: c.backend_url.clone(),
            operation: operation.to_owned(),
            args: masked_args.clone(),
            duration_ms,
            reason: masked_reason.to_owned(),
        });
    }

    // 2. App Insights — ALWAYS fires (ungated)
    let mut props = serde_json::Map::new();
    props.insert("operation".into(), serde_json::json!(operation));
    props.insert("error_class".into(), serde_json::json!(error_class));
    props.insert("error_message".into(), serde_json::json!(masked_reason));
    // App Insights properties must be flat strings — serialize args as JSON string
    props.insert(
        "args".into(),
        serde_json::json!(
            serde_json::to_string(&serde_json::Value::Object(masked_args)).unwrap_or_default()
        ),
    );
    let mut measurements = serde_json::Map::new();
    measurements.insert("duration_ms".into(), serde_json::json!(duration_ms as f64));
    emit_event("sdk/core_failure", props, measurements);
}

/// Convenience: report failure from key-value pairs.
pub fn report_failure_kv(
    operation: &str,
    kvs: &[(&str, serde_json::Value)],
    duration_ms: u64,
    reason: &str,
) {
    let mut args = serde_json::Map::new();
    for (k, v) in kvs {
        args.insert((*k).into(), v.clone());
    }
    report_failure(operation, args, duration_ms, reason);
}

/// Emit a telemetry event to Azure App Insights. No `init()` required.
/// Respects opt-out via env vars or config.
pub fn emit_event(
    event_name: &str,
    properties: serde_json::Map<String, serde_json::Value>,
    measurements: serde_json::Map<String, serde_json::Value>,
) {
    if let Ok(v) = std::env::var("ALTIMATE_TELEMETRY")
        && ["0", "false", "no", "off"].contains(&v.to_lowercase().as_str())
    {
        return;
    }
    if let Ok(v) = std::env::var("ALTIMATE_TELEMETRY_DISABLED")
        && v.eq_ignore_ascii_case("true")
    {
        return;
    }
    // Single lock acquisition: check telemetry flag and read tenant together.
    let tenant = match SDK_CONFIG.lock() {
        Ok(guard) => match guard.as_ref() {
            Some(c) if !c.telemetry => return,
            Some(c) => c.tenant.clone(),
            None => String::new(),
        },
        Err(_) => String::new(),
    };

    if let Some(s) = try_bg_sender() {
        let _ = s.try_send(BgTask::Telemetry {
            event_name: event_name.to_owned(),
            tenant,
            properties,
            measurements,
        });
    }
}

/// Emit a timing event for an operation.
pub fn timed_emit(operation: &str, start: std::time::Instant) {
    let duration_ms = start.elapsed().as_millis() as f64;
    let mut props = serde_json::Map::new();
    props.insert("operation".into(), serde_json::json!(operation));
    let mut measurements = serde_json::Map::new();
    measurements.insert("duration_ms".into(), serde_json::json!(duration_ms));
    emit_event(&format!("sdk/{operation}"), props, measurements);
}

/// Emit a timing event with dialect.
pub fn timed_emit_with_dialect(operation: &str, dialect: &str, start: std::time::Instant) {
    let duration_ms = start.elapsed().as_millis() as f64;
    let mut props = serde_json::Map::new();
    props.insert("operation".into(), serde_json::json!(operation));
    props.insert("dialect".into(), serde_json::json!(dialect));
    let mut measurements = serde_json::Map::new();
    measurements.insert("duration_ms".into(), serde_json::json!(duration_ms));
    emit_event(&format!("sdk/{operation}"), props, measurements);
}

fn should_report(config: &SdkConfig) -> bool {
    if !config.report_failures {
        return false;
    }
    // Respect the same opt-out env vars as emit_event — users expect one variable to silence everything.
    if let Ok(v) = std::env::var("ALTIMATE_TELEMETRY_DISABLED")
        && v.eq_ignore_ascii_case("true")
    {
        return false;
    }
    if let Ok(v) = std::env::var("ALTIMATE_TELEMETRY")
        && ["0", "false", "no", "off"].contains(&v.to_lowercase().as_str())
    {
        return false;
    }
    match std::env::var("ALTIMATE_REPORT_FAILURES") {
        Ok(v) => !["0", "false", "no", "off"].contains(&v.to_lowercase().as_str()),
        Err(_) => true,
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    // ── mask_string ──────────────────────────────────────────────────

    #[test]
    fn mask_string_replaces_single_quoted_literals() {
        assert_eq!(
            mask_string("SELECT * FROM users WHERE name = 'Alice'"),
            "SELECT * FROM users WHERE name = ?"
        );
    }

    #[test]
    fn mask_string_replaces_multiple_literals() {
        assert_eq!(
            mask_string("INSERT INTO t VALUES ('a', 'b', 'c')"),
            "INSERT INTO t VALUES (?, ?, ?)"
        );
    }

    #[test]
    fn mask_string_handles_escaped_quotes() {
        assert_eq!(
            mask_string("SELECT * WHERE name = 'O\\'Brien'"),
            "SELECT * WHERE name = ?"
        );
    }

    #[test]
    fn mask_string_collapses_whitespace() {
        assert_eq!(
            mask_string("SELECT  *   FROM\n\tusers"),
            "SELECT * FROM users"
        );
    }

    #[test]
    fn mask_string_no_op_on_plain_string() {
        assert_eq!(mask_string("snowflake"), "snowflake");
    }

    #[test]
    fn mask_string_empty() {
        assert_eq!(mask_string(""), "");
    }

    #[test]
    fn mask_string_masks_connection_strings() {
        let conn = "host='prod.db.com' user='admin' password='s3cret!'";
        let masked = mask_string(conn);
        assert_eq!(masked, "host=? user=? password=?");
        assert!(!masked.contains("prod.db.com"));
        assert!(!masked.contains("admin"));
        assert!(!masked.contains("s3cret!"));
    }

    #[test]
    fn mask_string_masks_arbitrary_pii() {
        // email-like data inside quotes
        assert_eq!(
            mask_string("email = 'alice@example.com' AND ssn = '123-45-6789'"),
            "email = ? AND ssn = ?"
        );
    }

    // ── mask_value ───────────────────────────────────────────────────

    #[test]
    fn mask_value_string() {
        let v = json!("SELECT * FROM t WHERE id = 'secret'");
        let masked = mask_value(&v);
        assert_eq!(masked, json!("SELECT * FROM t WHERE id = ?"));
    }

    #[test]
    fn mask_value_number_passthrough() {
        let v = json!(42);
        assert_eq!(mask_value(&v), json!(42));
    }

    #[test]
    fn mask_value_bool_passthrough() {
        assert_eq!(mask_value(&json!(true)), json!(true));
    }

    #[test]
    fn mask_value_null_passthrough() {
        assert_eq!(mask_value(&json!(null)), json!(null));
    }

    #[test]
    fn mask_value_nested_object() {
        let v = json!({
            "sql": "SELECT 'pii_data' FROM t",
            "dialect": "snowflake",
            "config": {
                "host": "prod.db.com"
            }
        });
        let masked = mask_value(&v);
        assert_eq!(masked["sql"], json!("SELECT ? FROM t"));
        assert_eq!(masked["dialect"], json!("snowflake"));
        assert_eq!(masked["config"]["host"], json!("prod.db.com"));
    }

    #[test]
    fn mask_value_array() {
        let v = json!(["SELECT 'a'", "plain", 42]);
        let masked = mask_value(&v);
        assert_eq!(masked, json!(["SELECT ?", "plain", 42]));
    }

    #[test]
    fn mask_value_deeply_nested() {
        let v = json!({
            "a": [{"b": [{"c": "val = 'deep_secret'"}]}]
        });
        let masked = mask_value(&v);
        let inner = &masked["a"][0]["b"][0]["c"];
        assert_eq!(inner, &json!("val = ?"));
    }

    // ── sensitive key redaction ─────────────────────────────────────

    #[test]
    fn is_sensitive_key_exact_matches() {
        assert!(is_sensitive_key("key"));
        assert!(is_sensitive_key("token"));
        assert!(is_sensitive_key("secret"));
        assert!(is_sensitive_key("password"));
        assert!(is_sensitive_key("api_key"));
        assert!(is_sensitive_key("access_token"));
        assert!(is_sensitive_key("private_key"));
        assert!(is_sensitive_key("connection_string"));
        assert!(is_sensitive_key("credential"));
        assert!(is_sensitive_key("authorization"));
        assert!(is_sensitive_key("signature"));
    }

    #[test]
    fn is_sensitive_key_case_insensitive() {
        assert!(is_sensitive_key("PASSWORD"));
        assert!(is_sensitive_key("Api_Key"));
        assert!(is_sensitive_key("SECRET"));
        assert!(is_sensitive_key("Token"));
    }

    #[test]
    fn is_sensitive_key_prefix_suffix() {
        assert!(is_sensitive_key("auth_header")); // starts with auth_
        assert!(is_sensitive_key("db_password")); // ends with _password
        assert!(is_sensitive_key("aws_secret")); // ends with _secret
    }

    #[test]
    fn is_sensitive_key_non_sensitive() {
        assert!(!is_sensitive_key("sql"));
        assert!(!is_sensitive_key("dialect"));
        assert!(!is_sensitive_key("host"));
        assert!(!is_sensitive_key("username"));
        assert!(!is_sensitive_key("query"));
    }

    #[test]
    fn mask_value_redacts_sensitive_keys() {
        let v = json!({
            "sql": "SELECT 'data' FROM t",
            "password": "s3cret!",
            "api_key": "sk-1234567890abcdef",
            "token": "eyJhbGciOiJIUzI1NiJ9",
            "secret": "my-secret-value",
            "dialect": "snowflake"
        });
        let masked = mask_value(&v);
        assert_eq!(masked["sql"], json!("SELECT ? FROM t"));
        assert_eq!(masked["password"], json!("****"));
        assert_eq!(masked["api_key"], json!("****"));
        assert_eq!(masked["token"], json!("****"));
        assert_eq!(masked["secret"], json!("****"));
        assert_eq!(masked["dialect"], json!("snowflake"));
    }

    #[test]
    fn mask_value_redacts_sensitive_keys_nested() {
        let v = json!({
            "config": {
                "connection_string": "Server=prod;Password=abc",
                "private_key": "-----BEGIN RSA PRIVATE KEY-----",
                "host": "prod.db.com"
            }
        });
        let masked = mask_value(&v);
        assert_eq!(masked["config"]["connection_string"], json!("****"));
        assert_eq!(masked["config"]["private_key"], json!("****"));
        assert_eq!(masked["config"]["host"], json!("prod.db.com"));
    }

    #[test]
    fn mask_value_redacts_sensitive_numbers_and_bools() {
        // Even non-string values under sensitive keys get redacted
        let v = json!({
            "token": 12345,
            "secret": true,
            "key": null
        });
        let masked = mask_value(&v);
        assert_eq!(masked["token"], json!("****"));
        assert_eq!(masked["secret"], json!("****"));
        assert_eq!(masked["key"], json!("****"));
    }

    #[test]
    fn mask_value_redacts_sensitive_arrays() {
        let v = json!({
            "credentials": ["user1:pass1", "user2:pass2"]
        });
        let masked = mask_value(&v);
        assert_eq!(masked["credentials"], json!("****"));
    }

    // ── classify_reason ──────────────────────────────────────────────

    #[test]
    fn classify_parse_error() {
        assert_eq!(classify_reason("Parse error near SELECT"), "parse_error");
        assert_eq!(classify_reason("syntax error at line 5"), "parse_error");
        assert_eq!(classify_reason("unexpected token '}'"), "parse_error");
    }

    #[test]
    fn classify_connection() {
        assert_eq!(classify_reason("Connection refused"), "connection");
        assert_eq!(classify_reason("socket hangup"), "connection");
    }

    #[test]
    fn classify_timeout() {
        assert_eq!(classify_reason("request timeout after 30s"), "timeout");
    }

    #[test]
    fn classify_permission() {
        assert_eq!(classify_reason("Permission denied"), "permission");
        assert_eq!(classify_reason("Access denied for user"), "permission");
    }

    #[test]
    fn classify_empty_result() {
        assert_eq!(classify_reason("EmptyLineage: no edges"), "empty_result");
    }

    #[test]
    fn classify_unknown_fallback() {
        assert_eq!(classify_reason("something went wrong"), "unknown");
        assert_eq!(classify_reason(""), "unknown");
    }

    // ── chrono_now / days_to_ymd ─────────────────────────────────────

    #[test]
    fn days_to_ymd_epoch() {
        assert_eq!(days_to_ymd(0), (1970, 1, 1));
    }

    #[test]
    fn days_to_ymd_known_date() {
        // 2024-01-01 is 19723 days from epoch
        let (y, m, d) = days_to_ymd(19723);
        assert_eq!((y, m, d), (2024, 1, 1));
    }

    #[test]
    fn days_to_ymd_leap_year() {
        // 2024-02-29 is 19723 + 59 = 19782 days from epoch
        let (y, m, d) = days_to_ymd(19782);
        assert_eq!((y, m, d), (2024, 2, 29));
    }

    #[test]
    fn chrono_now_format() {
        let ts = chrono_now();
        // Should match ISO 8601 format: YYYY-MM-DDTHH:MM:SSZ
        assert!(ts.ends_with('Z'));
        assert_eq!(ts.len(), 20);
        assert_eq!(&ts[4..5], "-");
        assert_eq!(&ts[7..8], "-");
        assert_eq!(&ts[10..11], "T");
    }

    // ── binding ──────────────────────────────────────────────────────

    #[test]
    fn binding_default_is_unknown() {
        // OnceLock may already be set by another test, but if not it's "unknown"
        let b = binding();
        assert!(b == "unknown" || b == "python" || b == "node" || b == "test");
    }

    // ── report_failure_kv builds args correctly ──────────────────────

    #[test]
    fn report_failure_kv_masks_all_string_args() {
        // We can't easily test the full pipeline without a mock server,
        // but we can verify the masking path by calling mask_value directly
        // on the same args that report_failure_kv would build.
        let kvs: Vec<(&str, serde_json::Value)> = vec![
            ("sql", json!("SELECT * FROM t WHERE name = 'Alice'")),
            ("dialect", json!("snowflake")),
            ("count", json!(10)),
        ];
        let mut args = serde_json::Map::new();
        for (k, v) in &kvs {
            args.insert((*k).into(), v.clone());
        }
        let masked: serde_json::Map<String, serde_json::Value> = args
            .iter()
            .map(|(k, v)| (k.clone(), mask_value(v)))
            .collect();

        assert_eq!(masked["sql"], json!("SELECT * FROM t WHERE name = ?"));
        assert_eq!(masked["dialect"], json!("snowflake")); // no quotes to mask
        assert_eq!(masked["count"], json!(10)); // numbers pass through
    }

    // ── init / reset / is_initialized ────────────────────────────────

    #[test]
    fn init_and_reset_lifecycle() {
        // Note: these tests share process state, so we can't guarantee
        // is_initialized starts false. But we can test the round-trip.
        let _ = init(
            "test-key".into(),
            "test-tenant".into(),
            "http://localhost:9999".into(),
            false,
            false,
        );
        assert!(is_initialized());

        let _ = reset();
        assert!(!is_initialized());
    }
}
