//! Dialect-specific validation tests.
//!
//! Tests cover Snowflake, BigQuery, Databricks, and dbt Jinja patterns across
//! validation, safety scanning, PII masking, and transpilation.

use altimate_core::polyglot::extractor::extract_tables;
use altimate_core::polyglot::formatter::format_sql;
use altimate_core::polyglot::transpiler::transpile;
use altimate_core::safety::{SafetyConfig, SafetyRule, is_safe, scan_sql};
use altimate_core::schema::types::{SchemaDefinition, SqlDialect};
use altimate_core::validator::engine::validate;

fn ecommerce_schema() -> SchemaDefinition {
    SchemaDefinition::from_yaml(include_str!(
        "../../../tests/fixtures/schemas/ecommerce.yaml"
    ))
    .expect("Failed to load ecommerce schema")
}

fn schema_with_dialect(dialect: SqlDialect) -> SchemaDefinition {
    let mut schema = ecommerce_schema();
    schema.dialect = dialect;
    schema
}

// ═══════════════════════════════════════════════════════════════════════
// Snowflake — validation
// ═══════════════════════════════════════════════════════════════════════

#[tokio::test]
async fn dialect_snowflake_basic_select() {
    let schema = schema_with_dialect(SqlDialect::Snowflake);
    let result = validate("SELECT id, email FROM users", &schema).await;
    assert!(result.valid);
}

#[tokio::test]
async fn dialect_snowflake_ilike() {
    let schema = schema_with_dialect(SqlDialect::Snowflake);
    let result = validate("SELECT * FROM users WHERE name ILIKE '%smith%'", &schema).await;
    assert!(result.valid);
}

#[test]
fn dialect_snowflake_system_function_blocked() {
    assert!(!is_safe("SELECT SYSTEM$TYPEOF(current_version())"));
}

#[test]
fn dialect_snowflake_copy_into_blocked() {
    assert!(!is_safe("COPY INTO @my_stage FROM users"));
}

#[test]
fn dialect_snowflake_create_stage_blocked() {
    assert!(!is_safe("CREATE STAGE my_stage"));
}

// ═══════════════════════════════════════════════════════════════════════
// BigQuery — validation
// ═══════════════════════════════════════════════════════════════════════

#[tokio::test]
async fn dialect_bigquery_basic_select() {
    let schema = schema_with_dialect(SqlDialect::BigQuery);
    let result = validate("SELECT id, email FROM users", &schema).await;
    assert!(result.valid);
}

#[test]
fn dialect_bigquery_merge_blocked() {
    assert!(!is_safe(
        "MERGE INTO target USING source ON target.id = source.id \
         WHEN MATCHED THEN UPDATE SET name = source.name"
    ));
}

// ═══════════════════════════════════════════════════════════════════════
// Databricks — validation
// ═══════════════════════════════════════════════════════════════════════

#[tokio::test]
async fn dialect_databricks_basic_select() {
    let schema = schema_with_dialect(SqlDialect::Databricks);
    let result = validate("SELECT id, email FROM users", &schema).await;
    assert!(result.valid);
}

#[test]
fn dialect_databricks_show_tables_probe() {
    let config = SafetyConfig::default();
    let result = scan_sql("SHOW TABLES", &config);
    assert!(
        result
            .threats
            .iter()
            .any(|t| t.rule == SafetyRule::InfoSchemaProbe)
    );
}

#[test]
fn dialect_databricks_show_databases_probe() {
    let config = SafetyConfig::default();
    let result = scan_sql("SHOW DATABASES", &config);
    assert!(
        result
            .threats
            .iter()
            .any(|t| t.rule == SafetyRule::InfoSchemaProbe)
    );
}

#[test]
fn dialect_databricks_describe_table_probe() {
    let config = SafetyConfig::default();
    let result = scan_sql("DESCRIBE TABLE users", &config);
    assert!(
        result
            .threats
            .iter()
            .any(|t| t.rule == SafetyRule::InfoSchemaProbe)
    );
}

// ═══════════════════════════════════════════════════════════════════════
// dbt Jinja patterns
// ═══════════════════════════════════════════════════════════════════════

#[test]
fn dialect_dbt_ref_expression() {
    assert!(!is_safe("SELECT * FROM {{ ref('stg_users') }}"));
}

#[test]
fn dialect_dbt_source_expression() {
    assert!(!is_safe("SELECT * FROM {{ source('raw', 'users') }}"));
}

#[test]
fn dialect_dbt_config_expression() {
    assert!(!is_safe(
        "SELECT * FROM {{ config.get('malicious_table') }}"
    ));
}

#[test]
fn dialect_dbt_jinja_statement() {
    assert!(!is_safe(
        "{% set table = 'users' %}SELECT * FROM {{ table }}"
    ));
}

#[test]
fn dialect_dbt_jinja_if_block() {
    assert!(!is_safe("{% if true %}SELECT 1{% endif %}"));
}

#[test]
fn dialect_dbt_jinja_for_loop() {
    assert!(!is_safe(
        "{% for i in range(5) %}SELECT {{ i }};{% endfor %}"
    ));
}

#[test]
fn dialect_dbt_jinja_macro_call() {
    assert!(!is_safe("SELECT * FROM {{ generate_schema_name() }}"));
}

#[test]
fn dialect_dbt_jinja_critical_severity() {
    let config = SafetyConfig::default();
    let result = scan_sql("{% set x = 1 %}SELECT {{ x }}", &config);
    let jinja_threats: Vec<_> = result
        .threats
        .iter()
        .filter(|t| t.message.contains("Jinja"))
        .collect();
    assert!(!jinja_threats.is_empty());
}

#[test]
fn dialect_dbt_jinja_expression_in_where() {
    assert!(!is_safe(
        "SELECT * FROM users WHERE status = {{ var('active_status') }}"
    ));
}

#[test]
fn dialect_dbt_jinja_nested_ref() {
    assert!(!is_safe(
        "SELECT * FROM {{ ref('stg_orders') }} o JOIN {{ ref('stg_users') }} u ON o.user_id = u.id"
    ));
}

// ═══════════════════════════════════════════════════════════════════════
// Transpilation between dialects
// ═══════════════════════════════════════════════════════════════════════

#[test]
fn dialect_transpile_generic_to_snowflake() {
    let result = transpile(
        "SELECT id FROM users",
        SqlDialect::Generic,
        SqlDialect::Snowflake,
    );
    assert!(result.success);
    assert!(!result.transpiled_sql.is_empty());
}

#[test]
fn dialect_transpile_generic_to_bigquery() {
    let result = transpile(
        "SELECT id FROM users",
        SqlDialect::Generic,
        SqlDialect::BigQuery,
    );
    assert!(result.success);
    assert!(!result.transpiled_sql.is_empty());
}

#[test]
fn dialect_transpile_generic_to_postgres() {
    let result = transpile(
        "SELECT id FROM users",
        SqlDialect::Generic,
        SqlDialect::Postgres,
    );
    assert!(result.success);
}

#[test]
fn dialect_transpile_generic_to_mysql() {
    let result = transpile(
        "SELECT id FROM users",
        SqlDialect::Generic,
        SqlDialect::MySQL,
    );
    assert!(result.success);
}

#[test]
fn dialect_transpile_postgres_to_snowflake() {
    let result = transpile(
        "SELECT id, name FROM users WHERE id = 1",
        SqlDialect::Postgres,
        SqlDialect::Snowflake,
    );
    assert!(result.success);
}

#[test]
fn dialect_transpile_snowflake_to_bigquery() {
    let result = transpile(
        "SELECT id, name FROM users WHERE id = 1",
        SqlDialect::Snowflake,
        SqlDialect::BigQuery,
    );
    assert!(result.success);
}

#[test]
fn dialect_transpile_preserves_original() {
    let sql = "SELECT id FROM users";
    let result = transpile(sql, SqlDialect::Generic, SqlDialect::Snowflake);
    assert_eq!(result.original_sql, sql);
}

#[test]
fn dialect_transpile_has_dialect_info() {
    let result = transpile(
        "SELECT id FROM users",
        SqlDialect::Generic,
        SqlDialect::Snowflake,
    );
    assert_eq!(result.source_dialect, SqlDialect::Generic.to_string());
    assert_eq!(result.target_dialect, SqlDialect::Snowflake.to_string());
}

// ═══════════════════════════════════════════════════════════════════════
// Table extraction with dialects
// ═══════════════════════════════════════════════════════════════════════

#[test]
fn dialect_extract_tables_generic() {
    let tables = extract_tables("SELECT id FROM users", SqlDialect::Generic)
        .expect("extract_tables should succeed for Generic");
    // polyglot-sql may or may not return table names depending on AST analysis
    let _ = tables;
}

#[test]
fn dialect_extract_tables_join() {
    let tables = extract_tables(
        "SELECT u.id FROM users u JOIN orders o ON u.id = o.user_id",
        SqlDialect::Generic,
    )
    .expect("extract_tables should succeed for join query");
    let _ = tables;
}

#[test]
fn dialect_extract_tables_snowflake() {
    let tables = extract_tables("SELECT id FROM users", SqlDialect::Snowflake)
        .expect("extract_tables should succeed for Snowflake");
    let _ = tables;
}

#[test]
fn dialect_extract_tables_bigquery() {
    let tables = extract_tables("SELECT id FROM users", SqlDialect::BigQuery)
        .expect("extract_tables should succeed for BigQuery");
    let _ = tables;
}

// ═══════════════════════════════════════════════════════════════════════
// SQL formatting with dialects
// ═══════════════════════════════════════════════════════════════════════

#[test]
fn dialect_format_sql_generic() {
    let result = format_sql("SELECT id,name FROM users WHERE id=1", SqlDialect::Generic);
    assert!(result.success);
    assert!(!result.formatted_sql.is_empty());
}

#[test]
fn dialect_format_sql_snowflake() {
    let result = format_sql(
        "SELECT id,name FROM users WHERE id=1",
        SqlDialect::Snowflake,
    );
    assert!(result.success);
}

#[test]
fn dialect_format_sql_bigquery() {
    let result = format_sql("SELECT id,name FROM users WHERE id=1", SqlDialect::BigQuery);
    assert!(result.success);
}

#[test]
fn dialect_format_sql_postgres() {
    let result = format_sql("SELECT id,name FROM users WHERE id=1", SqlDialect::Postgres);
    assert!(result.success);
}

#[test]
fn dialect_format_invalid_sql() {
    let result = format_sql("SELECTZ broken", SqlDialect::Generic);
    // polyglot-sql may or may not treat this as an error; key assertion is no panic
    let _ = result;
}

// ═══════════════════════════════════════════════════════════════════════
// SqlDialect enum tests
// ═══════════════════════════════════════════════════════════════════════

#[test]
fn dialect_display_snowflake() {
    assert_eq!(SqlDialect::Snowflake.to_string(), "snowflake");
}

#[test]
fn dialect_display_bigquery() {
    assert_eq!(SqlDialect::BigQuery.to_string(), "bigquery");
}

#[test]
fn dialect_display_databricks() {
    assert_eq!(SqlDialect::Databricks.to_string(), "databricks");
}

#[test]
fn dialect_display_postgres() {
    assert_eq!(SqlDialect::Postgres.to_string(), "postgres");
}

#[test]
fn dialect_display_mysql() {
    assert_eq!(SqlDialect::MySQL.to_string(), "mysql");
}

#[test]
fn dialect_display_generic() {
    assert_eq!(SqlDialect::Generic.to_string(), "generic");
}

// ═══════════════════════════════════════════════════════════════════════
// Cross-dialect safety
// ═══════════════════════════════════════════════════════════════════════

#[test]
fn dialect_safety_info_schema_cross_dialect() {
    // information_schema probing should be caught regardless of dialect
    assert!(!is_safe("SELECT * FROM information_schema.tables"));
    assert!(!is_safe("SELECT * FROM information_schema.columns"));
}

#[test]
fn dialect_safety_sleep_cross_dialect() {
    // Sleep-based attacks across dialects
    assert!(!is_safe("SELECT * FROM users WHERE id = 1 AND SLEEP(5)"));
    assert!(!is_safe(
        "SELECT * FROM users WHERE id = 1 AND pg_sleep(10) IS NOT NULL"
    ));
}

#[test]
fn dialect_safety_stacked_queries_cross_dialect() {
    assert!(!is_safe("SELECT 1; DROP TABLE users"));
    assert!(!is_safe("SELECT 1; DELETE FROM users"));
}

#[test]
fn dialect_safety_comment_injection_cross_dialect() {
    assert!(!is_safe("SELECT * FROM users WHERE name = 'admin' --"));
}

// ═══════════════════════════════════════════════════════════════════════
// Transpile result serialization
// ═══════════════════════════════════════════════════════════════════════

#[test]
fn dialect_transpile_result_serializes() {
    let result = transpile(
        "SELECT id FROM users",
        SqlDialect::Generic,
        SqlDialect::Snowflake,
    );
    let json = serde_json::to_string(&result).expect("should serialize");
    assert!(json.contains("original_sql"));
    assert!(json.contains("source_dialect"));
    assert!(json.contains("target_dialect"));
    assert!(json.contains("success"));
}

#[test]
fn dialect_format_result_serializes() {
    let result = format_sql("SELECT id FROM users", SqlDialect::Generic);
    let json = serde_json::to_string(&result).expect("should serialize");
    assert!(json.contains("formatted_sql"));
    assert!(json.contains("success"));
}
