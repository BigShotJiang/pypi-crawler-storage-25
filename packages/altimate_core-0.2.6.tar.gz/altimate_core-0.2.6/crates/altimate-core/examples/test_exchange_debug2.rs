use altimate_core::lineage::column_lineage;
use altimate_core::schema::types::SqlDialect;
use std::collections::HashMap;

fn main() {
    // Simpler test: just the core issue
    let sql = r#"select REPLACE(SUBSTRING(EXCHANGE_DATE,1,10),'-','') AS exchange_date_id, usd_exchange_rate
FROM (SELECT * FROM currency_exchange_rate) sq"#;

    let schema: HashMap<String, serde_json::Value> = serde_json::from_str(
        r#"{
        "CURRENCY_EXCHANGE_RATE": {"EXCHANGE_DATE": "VARCHAR", "USD_EXCHANGE_RATE": "VARCHAR"}
    }"#,
    )
    .unwrap();

    let result = column_lineage(sql, SqlDialect::Snowflake, &schema, None).unwrap();
    eprintln!("=== Test 1: SELECT * subquery ===");
    for (k, v) in &result.column_dict {
        let mut srcs: Vec<_> = v.iter().collect();
        srcs.sort();
        eprintln!("  {}: {:?}", k, srcs);
    }

    // Test 2: same but without subquery
    let sql2 = r#"select REPLACE(SUBSTRING(EXCHANGE_DATE,1,10),'-','') AS exchange_date_id, usd_exchange_rate
FROM currency_exchange_rate"#;
    let result2 = column_lineage(sql2, SqlDialect::Snowflake, &schema, None).unwrap();
    eprintln!("\n=== Test 2: Direct table ===");
    for (k, v) in &result2.column_dict {
        let mut srcs: Vec<_> = v.iter().collect();
        srcs.sort();
        eprintln!("  {}: {:?}", k, srcs);
    }

    // Test 3: subquery with explicit columns
    let sql3 = r#"select REPLACE(SUBSTRING(EXCHANGE_DATE,1,10),'-','') AS exchange_date_id, usd_exchange_rate
FROM (SELECT EXCHANGE_DATE, USD_EXCHANGE_RATE FROM currency_exchange_rate) sq"#;
    let result3 = column_lineage(sql3, SqlDialect::Snowflake, &schema, None).unwrap();
    eprintln!("\n=== Test 3: Subquery explicit cols ===");
    for (k, v) in &result3.column_dict {
        let mut srcs: Vec<_> = v.iter().collect();
        srcs.sort();
        eprintln!("  {}: {:?}", k, srcs);
    }
}
