use altimate_core::lineage::column_lineage;
use altimate_core::schema::types::SqlDialect;
use std::collections::HashMap;

fn main() {
    // Test with SUBSTRING only (polyglot produces 0 edges for this)
    let sql =
        r#"select SUBSTRING(EXCHANGE_DATE,1,10) AS exchange_date_id FROM currency_exchange_rate"#;
    let schema: HashMap<String, serde_json::Value> = serde_json::from_str(
        r#"{
        "CURRENCY_EXCHANGE_RATE": {"EXCHANGE_DATE": "VARCHAR", "USD_EXCHANGE_RATE": "VARCHAR"}
    }"#,
    )
    .unwrap();
    let result = column_lineage(sql, SqlDialect::Snowflake, &schema, None).unwrap();
    eprintln!("=== SUBSTRING only ===");
    for (k, v) in &result.column_dict {
        let mut srcs: Vec<_> = v.iter().collect();
        srcs.sort();
        eprintln!("  {}: {:?}", k, srcs);
    }
    if result.column_dict.is_empty() {
        eprintln!("  (empty!)");
    }

    // Test with REPLACE(SUBSTRING(...))
    let sql2 = r#"select REPLACE(SUBSTRING(EXCHANGE_DATE,1,10),'-','') AS exchange_date_id FROM currency_exchange_rate"#;
    let result2 = column_lineage(sql2, SqlDialect::Snowflake, &schema, None).unwrap();
    eprintln!("\n=== REPLACE(SUBSTRING(...)) ===");
    for (k, v) in &result2.column_dict {
        let mut srcs: Vec<_> = v.iter().collect();
        srcs.sort();
        eprintln!("  {}: {:?}", k, srcs);
    }
    if result2.column_dict.is_empty() {
        eprintln!("  (empty!)");
    }
}
