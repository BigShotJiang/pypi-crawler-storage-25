//! SQL query rewriter and optimizer.
//!
//! Suggests and applies query optimizations: rewrite correlated subqueries
//! as JOINs, push filters down, suggest indexes, etc.

pub mod engine;
pub mod types;

pub use engine::rewrite;
pub use types::*;
