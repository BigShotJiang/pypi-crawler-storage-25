//! Configurable policy guardrails for SQL queries.
//!
//! The guardrails module evaluates SQL queries against configurable policy
//! rules, covering cost control, data protection, query pattern restrictions,
//! and tag-based access control.
//!
//! # Usage
//!
//! ```rust,no_run
//! use altimate_core::guardrails::{check_policy, PolicyConfig, PolicyResult};
//! use altimate_core::SchemaDefinition;
//!
//! # async fn example() {
//! let schema = SchemaDefinition::from_yaml_file("schema.yaml").unwrap();
//! let policy = PolicyConfig::from_yaml("cost_control:\n  max_joins: 3\n").unwrap();
//! let result = check_policy("SELECT * FROM users", &schema, &policy).await;
//! println!("Allowed: {}", result.allowed);
//! for v in &result.violations {
//!     println!("  Violation: {} - {}", v.rule, v.message);
//! }
//! # }
//! ```

pub mod audit;
pub mod engine;
pub mod policy;
pub mod rules;
pub mod types;

// Re-export primary types for convenience
pub use engine::check_policy;
pub use policy::PolicyConfig;
pub use types::{AuditEntry, PolicyResult, PolicyViolation, PolicyWarning};
