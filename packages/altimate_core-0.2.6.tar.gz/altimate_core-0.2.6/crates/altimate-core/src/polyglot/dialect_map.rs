//! Bidirectional mapping between altimate-core's `SqlDialect` and polyglot's `DialectType`.

use crate::schema::types::SqlDialect;
use polyglot_sql::DialectType;

/// Convert a altimate-core `SqlDialect` to a polyglot `DialectType`.
pub fn to_polyglot_dialect(dialect: SqlDialect) -> DialectType {
    match dialect {
        SqlDialect::Generic => DialectType::Generic,
        SqlDialect::Snowflake => DialectType::Snowflake,
        SqlDialect::Postgres => DialectType::PostgreSQL,
        SqlDialect::BigQuery => DialectType::BigQuery,
        SqlDialect::Databricks => DialectType::Databricks,
        SqlDialect::DuckDB => DialectType::DuckDB,
        SqlDialect::Athena => DialectType::Athena,
        SqlDialect::ClickHouse => DialectType::ClickHouse,
        SqlDialect::CockroachDB => DialectType::CockroachDB,
        SqlDialect::DataFusion => DialectType::DataFusion,
        SqlDialect::Doris => DialectType::Doris,
        SqlDialect::Dremio => DialectType::Dremio,
        SqlDialect::Drill => DialectType::Drill,
        SqlDialect::Druid => DialectType::Druid,
        SqlDialect::Dune => DialectType::Dune,
        SqlDialect::Exasol => DialectType::Exasol,
        SqlDialect::Fabric => DialectType::Fabric,
        SqlDialect::Hive => DialectType::Hive,
        SqlDialect::Materialize => DialectType::Materialize,
        SqlDialect::MySQL => DialectType::MySQL,
        SqlDialect::Oracle => DialectType::Oracle,
        SqlDialect::Presto => DialectType::Presto,
        SqlDialect::Redshift => DialectType::Redshift,
        SqlDialect::RisingWave => DialectType::RisingWave,
        SqlDialect::SingleStore => DialectType::SingleStore,
        SqlDialect::Solr => DialectType::Solr,
        SqlDialect::Spark => DialectType::Spark,
        SqlDialect::SQLite => DialectType::SQLite,
        SqlDialect::StarRocks => DialectType::StarRocks,
        SqlDialect::Tableau => DialectType::Tableau,
        SqlDialect::Teradata => DialectType::Teradata,
        SqlDialect::TiDB => DialectType::TiDB,
        SqlDialect::Trino => DialectType::Trino,
        SqlDialect::TSQL => DialectType::TSQL,
    }
}

/// Convert a polyglot `DialectType` to a altimate-core `SqlDialect`.
pub fn from_polyglot_dialect(dialect: DialectType) -> SqlDialect {
    match dialect {
        DialectType::Generic => SqlDialect::Generic,
        DialectType::Snowflake => SqlDialect::Snowflake,
        DialectType::PostgreSQL => SqlDialect::Postgres,
        DialectType::BigQuery => SqlDialect::BigQuery,
        DialectType::Databricks => SqlDialect::Databricks,
        DialectType::DuckDB => SqlDialect::DuckDB,
        DialectType::Athena => SqlDialect::Athena,
        DialectType::ClickHouse => SqlDialect::ClickHouse,
        DialectType::CockroachDB => SqlDialect::CockroachDB,
        DialectType::DataFusion => SqlDialect::DataFusion,
        DialectType::Doris => SqlDialect::Doris,
        DialectType::Dremio => SqlDialect::Dremio,
        DialectType::Drill => SqlDialect::Drill,
        DialectType::Druid => SqlDialect::Druid,
        DialectType::Dune => SqlDialect::Dune,
        DialectType::Exasol => SqlDialect::Exasol,
        DialectType::Fabric => SqlDialect::Fabric,
        DialectType::Hive => SqlDialect::Hive,
        DialectType::Materialize => SqlDialect::Materialize,
        DialectType::MySQL => SqlDialect::MySQL,
        DialectType::Oracle => SqlDialect::Oracle,
        DialectType::Presto => SqlDialect::Presto,
        DialectType::Redshift => SqlDialect::Redshift,
        DialectType::RisingWave => SqlDialect::RisingWave,
        DialectType::SingleStore => SqlDialect::SingleStore,
        DialectType::Solr => SqlDialect::Solr,
        DialectType::Spark => SqlDialect::Spark,
        DialectType::SQLite => SqlDialect::SQLite,
        DialectType::StarRocks => SqlDialect::StarRocks,
        DialectType::Tableau => SqlDialect::Tableau,
        DialectType::Teradata => SqlDialect::Teradata,
        DialectType::TiDB => SqlDialect::TiDB,
        DialectType::Trino => SqlDialect::Trino,
        DialectType::TSQL => SqlDialect::TSQL,
    }
}
