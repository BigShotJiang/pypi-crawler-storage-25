#[cfg(test)]
mod parse_tests {
    use crate::SqlDialect;
    use crate::polyglot::extractor::extract_metadata;
    #[test]
    fn test_this_specific_thing_12345() {
        let r = extract_metadata(
            "SELECT my_func(name), COALESCE(a,b), UPPER(c) FROM users",
            SqlDialect::Generic,
        )
        .unwrap();
        println!("EXTRACTED FUNCTIONS: {:?}", r.functions);
        // UPPER is parsed as a typed Expression::Upper variant, not Expression::Function,
        // so it's not included in the functions list. Only generic Function nodes and
        // aggregate-typed nodes are captured. This is a known gap — expanding to all
        // typed scalar variants (Upper, Lower, Trim, DateTrunc, etc.) is a separate task.
        assert_eq!(r.functions.len(), 2);
        assert!(r.functions.contains(&"COALESCE".to_string()));
        assert!(r.functions.contains(&"my_func".to_string()));
    }
}
