//! Core data types for tag analysis results.

use serde::Serialize;

/// A single report item within a tag result.
#[derive(Debug, Clone, Serialize)]
pub struct TagReport {
    pub query_span: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub functions: Option<Vec<String>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub description: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub metadata: Option<serde_json::Value>,
}

/// The result of running a single tag check.
#[derive(Debug, Clone, Serialize)]
pub struct TagResult {
    pub tag_name: String,
    pub triggered: bool,
    pub reports: Vec<TagReport>,
}

impl TagResult {
    /// Convenience constructor for a not-triggered result.
    pub fn not_triggered(name: &str) -> Self {
        Self {
            tag_name: name.to_string(),
            triggered: false,
            reports: Vec::new(),
        }
    }
}

/// The complete output of a tag analysis run.
#[derive(Debug, Clone, Default, Serialize)]
pub struct AnalysisOutput {
    /// Whether the SQL was parsed successfully by polyglot-sql.
    /// When `false`, AST-based tags are all not_triggered and callers
    /// should fall back to an alternative analyzer (e.g. sqlglot).
    pub parse_ok: bool,
    /// Per-tag results.
    pub results: Vec<TagResult>,
}

/// Configuration for tag analysis.
#[derive(Debug, Clone, Default)]
pub struct AnalysisConfig {
    /// Tags to skip (empty = run all).
    pub skip_tags: Vec<String>,
}
