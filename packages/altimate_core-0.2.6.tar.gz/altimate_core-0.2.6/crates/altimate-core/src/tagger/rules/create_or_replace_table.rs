//! Detect CREATE OR REPLACE TABLE pattern (string-based, no parsing needed).

use crate::tagger::types::{TagReport, TagResult};

pub const TAG_NAME: &str = "create_or_replace_table";

/// Check if raw SQL contains "create or replace table" (case-insensitive, whitespace-normalized).
pub fn check(sql: &str) -> TagResult {
    let normalized: String = sql
        .split_whitespace()
        .collect::<Vec<_>>()
        .join(" ")
        .to_lowercase();

    if normalized.contains("create or replace table") {
        TagResult {
            tag_name: TAG_NAME.to_string(),
            triggered: true,
            reports: vec![TagReport {
                query_span: sql.to_string(),
                functions: None,
                description: None,
                metadata: None,
            }],
        }
    } else {
        TagResult::not_triggered(TAG_NAME)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn triggered_on_create_or_replace() {
        let r = check("CREATE OR REPLACE TABLE x AS SELECT 1");
        assert!(r.triggered);
        assert_eq!(r.reports.len(), 1);
    }

    #[test]
    fn not_triggered_on_create_table() {
        let r = check("CREATE TABLE x AS SELECT 1");
        assert!(!r.triggered);
    }

    #[test]
    fn case_insensitive() {
        let r = check("create or replace table x as select 1");
        assert!(r.triggered);
    }

    #[test]
    fn handles_extra_whitespace() {
        let r = check("CREATE   OR\n  REPLACE\tTABLE  x  AS  SELECT 1");
        assert!(r.triggered);
    }
}
