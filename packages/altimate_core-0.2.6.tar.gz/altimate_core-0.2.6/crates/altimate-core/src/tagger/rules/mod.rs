//! Individual tag rule implementations.

pub mod agg_before_join;
pub mod create_or_replace_table;
pub mod filter_has_func;
pub mod join_has_func;
pub mod select_star;
pub mod select_without_limit;
