//! Shared predicates for tag analysis.
//!
//! Uses JSON serialization for exhaustive subtree traversal,
//! mirroring sqlglot's `.find_all()` approach. Since `Expression`
//! derives `Serialize`, we can search ANY expression's entire subtree
//! without manually enumerating every variant.

use polyglot_sql::expressions::Expression;

/// Returns `true` if the expression is any function-like AST node.
///
/// This list is maintained explicitly because we need to distinguish
/// function nodes (which trigger tags) from operators and literals
/// (which don't). This mirrors sqlglot's `exp.Func` base class.
pub fn is_any_function(expr: &Expression) -> bool {
    // Anything that's NOT a column, literal, identifier, operator,
    // or structural node is likely a function. But we maintain an
    // explicit list for precision.
    matches!(
        expr,
        Expression::Function(_)
            | Expression::AggregateFunction(_)
            | Expression::WindowFunction(_)
            | Expression::Upper(_)
            | Expression::Lower(_)
            | Expression::Length(_)
            | Expression::Trim(_)
            | Expression::LTrim(_)
            | Expression::RTrim(_)
            | Expression::Replace(_)
            | Expression::Reverse(_)
            | Expression::Left(_)
            | Expression::Right(_)
            | Expression::Repeat(_)
            | Expression::Lpad(_)
            | Expression::Rpad(_)
            | Expression::Split(_)
            | Expression::RegexpLike(_)
            | Expression::RegexpReplace(_)
            | Expression::RegexpExtract(_)
            | Expression::Overlay(_)
            | Expression::ConcatWs(_)
            | Expression::Substring(_)
            | Expression::Contains(_)
            | Expression::StartsWith(_)
            | Expression::EndsWith(_)
            | Expression::Position(_)
            | Expression::Initcap(_)
            | Expression::Ascii(_)
            | Expression::Chr(_)
            | Expression::CharFunc(_)
            | Expression::Soundex(_)
            | Expression::Levenshtein(_)
            | Expression::ByteLength(_)
            | Expression::Hex(_)
            | Expression::LowerHex(_)
            | Expression::Unicode(_)
            | Expression::Abs(_)
            | Expression::Round(_)
            | Expression::Floor(_)
            | Expression::Ceil(_)
            | Expression::Power(_)
            | Expression::Sqrt(_)
            | Expression::Cbrt(_)
            | Expression::Ln(_)
            | Expression::Log(_)
            | Expression::Exp(_)
            | Expression::Sign(_)
            | Expression::Greatest(_)
            | Expression::Least(_)
            | Expression::ModFunc(_)
            | Expression::Random(_)
            | Expression::Rand(_)
            | Expression::TruncFunc(_)
            | Expression::Pi(_)
            | Expression::Radians(_)
            | Expression::Degrees(_)
            | Expression::Sin(_)
            | Expression::Cos(_)
            | Expression::Tan(_)
            | Expression::Asin(_)
            | Expression::Acos(_)
            | Expression::Atan(_)
            | Expression::Atan2(_)
            | Expression::IsNan(_)
            | Expression::IsInf(_)
            | Expression::IntDiv(_)
            | Expression::Cast(_)
            | Expression::TryCast(_)
            | Expression::SafeCast(_)
            | Expression::Coalesce(_)
            | Expression::NullIf(_)
            | Expression::IfFunc(_)
            | Expression::IfNull(_)
            | Expression::Nvl(_)
            | Expression::Nvl2(_)
            | Expression::Decode(_)
            // Note: Expression::Case is NOT a function — it's a control-flow
            // construct. We recurse into its branches in collect_column_functions_json.
            | Expression::Count(_)
            | Expression::Sum(_)
            | Expression::Avg(_)
            | Expression::Min(_)
            | Expression::Max(_)
            | Expression::GroupConcat(_)
            | Expression::StringAgg(_)
            | Expression::ListAgg(_)
            | Expression::ArrayAgg(_)
            | Expression::CountIf(_)
            | Expression::SumIf(_)
            | Expression::Stddev(_)
            | Expression::StddevPop(_)
            | Expression::StddevSamp(_)
            | Expression::Variance(_)
            | Expression::VarPop(_)
            | Expression::VarSamp(_)
            | Expression::Median(_)
            | Expression::Mode(_)
            | Expression::First(_)
            | Expression::Last(_)
            | Expression::AnyValue(_)
            | Expression::ApproxDistinct(_)
            | Expression::ApproxCountDistinct(_)
            | Expression::ApproxPercentile(_)
            | Expression::Percentile(_)
            | Expression::LogicalAnd(_)
            | Expression::LogicalOr(_)
            | Expression::Skewness(_)
            | Expression::BitwiseCount(_)
            | Expression::ArrayConcatAgg(_)
            | Expression::ArrayUniqueAgg(_)
            | Expression::BoolXorAgg(_)
            | Expression::BitwiseAndAgg(_)
            | Expression::BitwiseOrAgg(_)
            | Expression::BitwiseXorAgg(_)
            | Expression::RowNumber(_)
            | Expression::Rank(_)
            | Expression::DenseRank(_)
            | Expression::NTile(_)
            | Expression::Lead(_)
            | Expression::Lag(_)
            | Expression::FirstValue(_)
            | Expression::LastValue(_)
            | Expression::NthValue(_)
            | Expression::PercentRank(_)
            | Expression::CumeDist(_)
            | Expression::PercentileCont(_)
            | Expression::PercentileDisc(_)
            | Expression::CurrentDate(_)
            | Expression::CurrentTime(_)
            | Expression::CurrentTimestamp(_)
            | Expression::CurrentTimestampLTZ(_)
            | Expression::AtTimeZone(_)
            | Expression::DateAdd(_)
            | Expression::DateSub(_)
            | Expression::DateDiff(_)
            | Expression::DateTrunc(_)
            | Expression::Extract(_)
            | Expression::ToDate(_)
            | Expression::ToTimestamp(_)
            | Expression::Date(_)
            | Expression::Time(_)
            | Expression::DateFromUnixDate(_)
            | Expression::UnixDate(_)
            | Expression::UnixSeconds(_)
            | Expression::UnixMillis(_)
            | Expression::UnixMicros(_)
            | Expression::UnixToTimeStr(_)
            | Expression::TimeStrToDate(_)
            | Expression::DateToDi(_)
            | Expression::DiToDate(_)
            | Expression::TsOrDiToDi(_)
            | Expression::TsOrDsToDatetime(_)
            | Expression::TsOrDsToTimestamp(_)
            | Expression::YearOfWeek(_)
            | Expression::YearOfWeekIso(_)
            | Expression::DateFormat(_)
            | Expression::FormatDate(_)
            | Expression::Year(_)
            | Expression::Month(_)
            | Expression::Day(_)
            | Expression::Hour(_)
            | Expression::Minute(_)
            | Expression::Second(_)
            | Expression::DayOfWeek(_)
            | Expression::DayOfWeekIso(_)
            | Expression::DayOfMonth(_)
            | Expression::DayOfYear(_)
            | Expression::WeekOfYear(_)
            | Expression::Quarter(_)
            | Expression::AddMonths(_)
            | Expression::MonthsBetween(_)
            | Expression::LastDay(_)
            | Expression::NextDay(_)
            | Expression::Epoch(_)
            | Expression::EpochMs(_)
            | Expression::FromUnixtime(_)
            | Expression::UnixTimestamp(_)
            | Expression::MakeDate(_)
            | Expression::MakeTimestamp(_)
            | Expression::TimestampTrunc(_)
            | Expression::TimeStrToUnix(_)
            | Expression::SessionUser(_)
            | Expression::SHA(_)
            | Expression::SHA1Digest(_)
            | Expression::TimeToUnix(_)
            | Expression::ArrayFunc(_)
            | Expression::ArrayLength(_)
            | Expression::ArraySize(_)
            | Expression::Cardinality(_)
            | Expression::ArrayContains(_)
            | Expression::ArrayPosition(_)
            | Expression::ArrayAppend(_)
            | Expression::ArrayPrepend(_)
            | Expression::ArrayConcat(_)
            | Expression::ArraySort(_)
            | Expression::ArrayReverse(_)
            | Expression::ArrayDistinct(_)
            | Expression::ArrayJoin(_)
            | Expression::ArrayToString(_)
            | Expression::Unnest(_)
            | Expression::Explode(_)
            | Expression::ExplodeOuter(_)
            | Expression::ArrayFilter(_)
            | Expression::ArrayTransform(_)
            | Expression::ArrayFlatten(_)
            | Expression::ArrayCompact(_)
            | Expression::ArrayIntersect(_)
            | Expression::ArrayUnion(_)
            | Expression::ArrayExcept(_)
            | Expression::ArrayRemove(_)
            | Expression::ArrayZip(_)
            | Expression::Sequence(_)
            | Expression::Generate(_)
            | Expression::ExplodingGenerateSeries(_)
            | Expression::ToArray(_)
            | Expression::StarMap(_)
            | Expression::StructFunc(_)
            | Expression::StructExtract(_)
            | Expression::NamedStruct(_)
            | Expression::MapFunc(_)
            | Expression::MapFromEntries(_)
            | Expression::MapFromArrays(_)
            | Expression::MapKeys(_)
            | Expression::MapValues(_)
            | Expression::MapContainsKey(_)
            | Expression::MapConcat(_)
            | Expression::ElementAt(_)
            | Expression::TransformKeys(_)
            | Expression::TransformValues(_)
            | Expression::JsonExtract(_)
            | Expression::JsonExtractScalar(_)
            | Expression::JsonExtractPath(_)
            | Expression::JsonArray(_)
            | Expression::JsonObject(_)
            | Expression::JsonQuery(_)
            | Expression::JsonValue(_)
            | Expression::JsonArrayLength(_)
            | Expression::JsonKeys(_)
            | Expression::JsonType(_)
            | Expression::ParseJson(_)
            | Expression::ToJson(_)
            | Expression::JsonSet(_)
            | Expression::JsonInsert(_)
            | Expression::JsonRemove(_)
            | Expression::JsonMergePatch(_)
            | Expression::JsonArrayAgg(_)
            | Expression::JsonObjectAgg(_)
            | Expression::Convert(_)
            | Expression::Typeof(_)
            | Expression::Filter(_)
            | Expression::Anonymous(_)
            | Expression::AnonymousAggFunc(_)
            | Expression::CombinedAggFunc(_)
            | Expression::CombinedParameterizedAgg(_)
            | Expression::ParameterizedAgg(_)
            | Expression::UserDefinedFunction(_)
            | Expression::Transform(_)
            | Expression::Translate(_)
            | Expression::Grouping(_)
            | Expression::GroupingId(_)
            | Expression::HashAgg(_)
            | Expression::Hll(_)
            | Expression::ToBoolean(_)
            | Expression::ToMap(_)
            | Expression::Pad(_)
            | Expression::ToChar(_)
            | Expression::ToNumber(_)
            | Expression::ToDouble(_)
            | Expression::Int64(_)
            | Expression::StringFunc(_)
            | Expression::ToDecfloat(_)
            | Expression::TryToDecfloat(_)
            | Expression::ToFile(_)
            | Expression::ConvertToCharset(_)
            | Expression::ConvertTimezone(_)
            | Expression::GenerateSeries(_)
            | Expression::CosineDistance(_)
            | Expression::DotProduct(_)
            | Expression::EuclideanDistance(_)
            | Expression::ManhattanDistance(_)
            | Expression::JarowinklerSimilarity(_)
            | Expression::Booland(_)
            | Expression::Boolor(_)
            | Expression::ArgMax(_)
            | Expression::ArgMin(_)
            | Expression::ApproxTopK(_)
            | Expression::ApproxTopKAccumulate(_)
            | Expression::ApproxTopKCombine(_)
            | Expression::ApproxTopKEstimate(_)
            | Expression::ApproxTopSum(_)
            | Expression::ApproxQuantiles(_)
            | Expression::Minhash(_)
            | Expression::FarmFingerprint(_)
            | Expression::Float64(_)
            | Expression::Corr(_)
            | Expression::WidthBucket(_)
            | Expression::CovarSamp(_)
            | Expression::CovarPop(_)
            | Expression::ObjectAgg(_)
            | Expression::CastToStrType(_)
            | Expression::CheckJson(_)
            | Expression::CheckXml(_)
            | Expression::TranslateCharacters(_)
            | Expression::CurrentSchemas(_)
            | Expression::CurrentDatetime(_)
            | Expression::Localtime(_)
            | Expression::Localtimestamp(_)
            | Expression::Systimestamp(_)
            | Expression::CurrentSchema(_)
            | Expression::CurrentUser(_)
            | Expression::UtcTime(_)
            | Expression::UtcTimestamp(_)
            | Expression::Timestamp(_)
            | Expression::DateBin(_)
            | Expression::Datetime(_)
            | Expression::DatetimeAdd(_)
            | Expression::DatetimeSub(_)
            | Expression::DatetimeDiff(_)
            | Expression::DatetimeTrunc(_)
            | Expression::Dayname(_)
            | Expression::MakeInterval(_)
            | Expression::PreviousDay(_)
            | Expression::Elt(_)
            | Expression::TimestampAdd(_)
            | Expression::TimestampSub(_)
            | Expression::TimestampDiff(_)
            | Expression::TimeSlice(_)
            | Expression::TimeAdd(_)
            | Expression::TimeSub(_)
            | Expression::TimeDiff(_)
            | Expression::TimeTrunc(_)
            | Expression::DateFromParts(_)
            | Expression::TimeFromParts(_)
            | Expression::DecodeCase(_)
            | Expression::Decrypt(_)
            | Expression::DecryptRaw(_)
            | Expression::Encode(_)
            | Expression::Encrypt(_)
            | Expression::EncryptRaw(_)
            | Expression::EqualNull(_)
            | Expression::ToBinary(_)
            | Expression::Base64DecodeBinary(_)
            | Expression::Base64DecodeString(_)
            | Expression::Base64Encode(_)
            | Expression::TryBase64DecodeBinary(_)
            | Expression::TryBase64DecodeString(_)
            | Expression::GapFill(_)
            | Expression::GenerateDateArray(_)
            | Expression::GenerateTimestampArray(_)
            | Expression::GetExtract(_)
            | Expression::Getbit(_)
            | Expression::HexEncode(_)
            | Expression::Compress(_)
            | Expression::DecompressBinary(_)
            | Expression::DecompressString(_)
            | Expression::Xor(_)
            | Expression::Nullif(_)
            | Expression::Format(_)
            | Expression::MD5Digest(_)
            | Expression::MD5NumberLower64(_)
            | Expression::MD5NumberUpper64(_)
            | Expression::Monthname(_)
            | Expression::Ntile(_)
            | Expression::Normalize(_)
            | Expression::Normal(_)
            | Expression::Predict(_)
            | Expression::MLTranslate(_)
            | Expression::FeaturesAtTime(_)
            | Expression::GenerateEmbedding(_)
            | Expression::MLForecast(_)
            | Expression::ModelAttribute(_)
            | Expression::VectorSearch(_)
            | Expression::Quantile(_)
            | Expression::ApproxQuantile(_)
            | Expression::ApproxPercentileEstimate(_)
            | Expression::Randn(_)
            | Expression::Randstr(_)
            | Expression::RangeN(_)
            | Expression::RangeBucket(_)
            | Expression::ReadCSV(_)
            | Expression::ReadParquet(_)
            | Expression::Reduce(_)
            | Expression::RegexpExtractAll(_)
            | Expression::RegexpILike(_)
            | Expression::RegexpFullMatch(_)
            | Expression::RegexpInstr(_)
            | Expression::RegexpSplit(_)
            | Expression::RegexpCount(_)
            | Expression::RegrValx(_)
            | Expression::RegrValy(_)
            | Expression::RegrAvgy(_)
            | Expression::RegrAvgx(_)
            | Expression::RegrCount(_)
            | Expression::RegrIntercept(_)
            | Expression::RegrR2(_)
            | Expression::RegrSxx(_)
            | Expression::RegrSxy(_)
            | Expression::RegrSyy(_)
            | Expression::RegrSlope(_)
            | Expression::SafeAdd(_)
            | Expression::SafeDivide(_)
            | Expression::SafeMultiply(_)
            | Expression::SafeSubtract(_)
            | Expression::SHA2(_)
            | Expression::SHA2Digest(_)
            | Expression::SortArray(_)
            | Expression::SplitPart(_)
            | Expression::SubstringIndex(_)
            | Expression::StandardHash(_)
            | Expression::StrPosition(_)
            | Expression::Search(_)
            | Expression::SearchIp(_)
            | Expression::StrToDate(_)
            | Expression::DateStrToDate(_)
            | Expression::DateToDateStr(_)
            | Expression::StrToTime(_)
            | Expression::StrToUnix(_)
            | Expression::StrToMap(_)
            | Expression::NumberToStr(_)
            | Expression::FromBase(_)
            | Expression::Stuff(_)
            | Expression::TimeToStr(_)
            | Expression::TimeStrToTime(_)
            | Expression::TsOrDsAdd(_)
            | Expression::TsOrDsDiff(_)
            | Expression::TsOrDsToDate(_)
            | Expression::TsOrDsToTime(_)
            | Expression::Unhex(_)
            | Expression::Uniform(_)
            | Expression::UnixToStr(_)
            | Expression::UnixToTime(_)
            | Expression::Uuid(_)
            | Expression::TimestampFromParts(_)
            | Expression::TimestampTzFromParts(_)
            | Expression::Week(_)
            | Expression::AIAgg(_)
            | Expression::AIClassify(_)
            | Expression::ArrayAll(_)
            | Expression::ArrayAny(_)
            | Expression::ArrayConstructCompact(_)
            | Expression::StPoint(_)
            | Expression::StDistance(_)
            | Expression::StringToArray(_)
            | Expression::ArraySum(_)
            | Expression::JSONBContains(_)
            | Expression::JSONBExtract(_)
            | Expression::JSONBool(_)
            | Expression::JSONExtract(_)
            | Expression::JSONExtractQuote(_)
            | Expression::JSONExtractArray(_)
            | Expression::JSONExtractScalar(_)
            | Expression::JSONBExtractScalar(_)
            | Expression::JSONFormat(_)
            | Expression::JSONArrayAppend(_)
            | Expression::JSONArrayContains(_)
            | Expression::JSONArrayInsert(_)
            | Expression::ParseJSON(_)
            | Expression::ParseUrl(_)
            | Expression::ParseIp(_)
            | Expression::ParseTime(_)
            | Expression::ParseDatetime(_)
            | Expression::MapCat(_)
            | Expression::MapDelete(_)
            | Expression::MapInsert(_)
            | Expression::MapPick(_)
            | Expression::MatchAgainst(_)
            | Expression::ObjectInsert(_)
            | Expression::JSONBExists(_)
            | Expression::Apply(_)
            | Expression::Zipf(_)
            | Expression::XMLElement(_)
            | Expression::XMLGet(_)
            | Expression::Exists(_)
    )
}

// ── JSON-based exhaustive traversal ──────────────────────────────────
//
// sqlglot's `.find_all(exp.Column)` does automatic depth-first traversal
// of ALL child nodes. We mirror this by serializing to JSON and searching
// recursively. This is comprehensive by construction — any new Expression
// variant that derives Serialize is automatically covered.

/// Check if the expression subtree contains a real Column reference.
///
/// Uses JSON serialization for exhaustive traversal, mirroring
/// sqlglot's `func.find_all(exp.Column)` approach.
///
/// Filters out bare identifiers that are actually interval unit keywords
/// (DAY, MONTH, YEAR, etc.) which polyglot-sql's generic function parser
/// sometimes misparses as Column nodes.
pub fn has_column(expr: &Expression) -> bool {
    if is_real_column(expr) {
        return true;
    }
    match serde_json::to_value(expr) {
        Ok(json) => json_has_real_column(&json),
        Err(_) => false,
    }
}

/// Returns true if this Column expression is a real column reference,
/// not an interval unit keyword misparsed as a column.
fn is_real_column(expr: &Expression) -> bool {
    match expr {
        Expression::Column(col) => !is_interval_unit_keyword(&col.name.name),
        _ => false,
    }
}

/// Interval unit keywords that polyglot-sql may misparse as Column nodes
/// when they appear as arguments in generic function calls like DATEADD(DAY, ...).
fn is_interval_unit_keyword(name: &str) -> bool {
    matches!(
        name.to_uppercase().as_str(),
        "YEAR"
            | "YEARS"
            | "QUARTER"
            | "QUARTERS"
            | "MONTH"
            | "MONTHS"
            | "WEEK"
            | "WEEKS"
            | "DAY"
            | "DAYS"
            | "HOUR"
            | "HOURS"
            | "MINUTE"
            | "MINUTES"
            | "SECOND"
            | "SECONDS"
            | "MILLISECOND"
            | "MILLISECONDS"
            | "MICROSECOND"
            | "MICROSECONDS"
            | "NANOSECOND"
            | "NANOSECONDS"
    )
}

/// Recursively search JSON for column nodes that are real columns
/// (not interval unit keywords).
fn json_has_real_column(value: &serde_json::Value) -> bool {
    match value {
        serde_json::Value::Object(map) => {
            if let Some(col_val) = map.get("column") {
                // Found a column node — check if it's a real column
                if let Some(name_obj) = col_val.as_object().and_then(|c| c.get("name")) {
                    if let Some(name_str) = name_obj
                        .as_object()
                        .and_then(|n| n.get("name"))
                        .and_then(|n| n.as_str())
                    {
                        if !is_interval_unit_keyword(name_str) {
                            return true;
                        }
                    } else {
                        // Can't determine name — conservatively treat as real column
                        return true;
                    }
                } else {
                    return true;
                }
            }
            map.values().any(json_has_real_column)
        }
        serde_json::Value::Array(arr) => arr.iter().any(json_has_real_column),
        _ => false,
    }
}

/// Check if the expression subtree contains a Star reference.
///
/// Uses JSON traversal to find `Expression::Star` nodes. Checks that the
/// `"star"` key maps to an object (the Star variant), not a bool (e.g.
/// `Count { star: true }`) to avoid false positives.
pub fn has_star(expr: &Expression) -> bool {
    if matches!(expr, Expression::Star(_)) {
        return true;
    }
    match serde_json::to_value(expr) {
        Ok(json) => json_has_star_node(&json),
        Err(_) => false,
    }
}

/// Check if the JSON tree contains a Star expression node.
///
/// Distinguishes `"star": { ... }` (an Expression::Star) from
/// `"star": true` (the bool field on Count/Sum aggregates).
fn json_has_star_node(value: &serde_json::Value) -> bool {
    match value {
        serde_json::Value::Object(map) => {
            if let Some(star_val) = map.get("star") {
                // Expression::Star serializes as an object, not a bool
                if star_val.is_object() {
                    return true;
                }
            }
            map.values().any(json_has_star_node)
        }
        serde_json::Value::Array(arr) => arr.iter().any(json_has_star_node),
        _ => false,
    }
}

/// Find all function nodes in `expr` whose subtree contains a Column.
///
/// This mirrors sqlglot's two-stage approach:
/// 1. Find all functions: `expression.find_all(exp.Func)`
/// 2. Filter to those containing columns: `[f for f in funcs if f.find_all(exp.Column)]`
///
/// Uses JSON serialization for the column-containment check (stage 2)
/// to ensure exhaustive traversal regardless of expression type.
pub fn find_column_functions(expr: &Expression) -> Vec<&Expression> {
    let mut result = Vec::new();
    collect_column_functions_json(expr, &mut result);
    result
}

/// Collect function nodes containing columns using JSON-based traversal.
///
/// The outer traversal (finding function nodes within operators) still uses
/// pattern matching for the structural types (And, Or, Between, etc.)
/// but falls through to JSON-based search for any unrecognized type.
/// The inner check (does this function contain a column?) always uses JSON.
fn collect_column_functions_json<'a>(expr: &'a Expression, result: &mut Vec<&'a Expression>) {
    // Stage 2: if this is a function, check if it contains a column
    if is_any_function(expr) && has_column(expr) {
        result.push(expr);
        return; // don't recurse into children — we already found the outermost function
    }

    // Stage 1: recurse through structural/operator nodes to find functions
    // For known structural types, do targeted recursion.
    // For anything else, use JSON to find all function subtrees.
    match expr {
        // Binary operators
        Expression::And(op)
        | Expression::Or(op)
        | Expression::Eq(op)
        | Expression::Neq(op)
        | Expression::Lt(op)
        | Expression::Lte(op)
        | Expression::Gt(op)
        | Expression::Gte(op)
        | Expression::Add(op)
        | Expression::Sub(op)
        | Expression::Mul(op)
        | Expression::Div(op)
        | Expression::Mod(op)
        | Expression::BitwiseAnd(op)
        | Expression::BitwiseOr(op)
        | Expression::BitwiseXor(op)
        | Expression::Concat(op)
        | Expression::Is(op) => {
            collect_column_functions_json(&op.left, result);
            collect_column_functions_json(&op.right, result);
        }
        // Unary operators
        Expression::Not(u) | Expression::Neg(u) | Expression::BitwiseNot(u) => {
            collect_column_functions_json(&u.this, result);
        }
        // Like operators
        Expression::Like(op) | Expression::ILike(op) => {
            collect_column_functions_json(&op.left, result);
            collect_column_functions_json(&op.right, result);
        }
        // Between
        Expression::Between(b) => {
            collect_column_functions_json(&b.this, result);
            collect_column_functions_json(&b.low, result);
            collect_column_functions_json(&b.high, result);
        }
        // IN
        Expression::In(i) => {
            collect_column_functions_json(&i.this, result);
            for e in &i.expressions {
                collect_column_functions_json(e, result);
            }
            if let Some(ref query) = i.query {
                collect_column_functions_json(query, result);
            }
        }
        // IS NULL
        Expression::IsNull(i) => {
            collect_column_functions_json(&i.this, result);
        }
        // Parenthesized expressions
        Expression::Paren(p) => {
            collect_column_functions_json(&p.this, result);
        }
        // Aliases
        Expression::Alias(a) => {
            collect_column_functions_json(&a.this, result);
        }
        // Dot access (e.g. t1.col — recurse into the base expression)
        Expression::Dot(d) => {
            collect_column_functions_json(&d.this, result);
        }
        // CASE is control flow, not a function — recurse into branches
        // to find actual functions like UPPER(col) inside WHEN/THEN/ELSE.
        Expression::Case(c) => {
            if let Some(ref operand) = c.operand {
                collect_column_functions_json(operand, result);
            }
            for (when_expr, then_expr) in &c.whens {
                collect_column_functions_json(when_expr, result);
                collect_column_functions_json(then_expr, result);
            }
            if let Some(ref else_expr) = c.else_ {
                collect_column_functions_json(else_expr, result);
            }
        }
        // Subqueries (don't recurse — functions in subqueries are
        // part of that subquery's WHERE, not the outer one)
        Expression::Subquery(_) => {}
        // Exists (same — the inner query is a separate scope)
        Expression::Exists(_) => {}
        // Leaf nodes — nothing to recurse into
        Expression::Column(_)
        | Expression::Literal(_)
        | Expression::Star(_)
        | Expression::Identifier(_)
        | Expression::Placeholder(_)
        | Expression::Parameter(_)
        | Expression::Null(_) => {}
        // For any other expression type (including functions that didn't
        // match is_any_function, or structural types we haven't enumerated),
        // we skip. The function detection is handled by the is_any_function
        // check at the top of this function.
        _ => {}
    }
}
