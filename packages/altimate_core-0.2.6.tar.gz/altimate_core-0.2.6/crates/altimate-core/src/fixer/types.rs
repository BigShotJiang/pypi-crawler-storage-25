//! Types for the SQL auto-fixer.
//!
//! These types represent the result of attempting to fix a SQL query,
//! including what fixes were applied, what couldn't be fixed, and the
//! resulting corrected SQL.

use serde::{Deserialize, Serialize};

/// Result of attempting to fix a SQL query.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FixResult {
    /// The original SQL query
    pub original_sql: String,

    /// Whether any fixes were applied
    pub fixed: bool,

    /// The fixed SQL (same as original if no fixes)
    pub fixed_sql: String,

    /// List of fixes that were applied
    pub fixes_applied: Vec<FixAction>,

    /// Errors that could not be fixed
    pub unfixable_errors: Vec<UnfixableError>,

    /// Whether the fixed SQL passes validation
    pub post_fix_valid: bool,

    /// Number of fix iterations performed
    pub iterations: usize,

    /// Time taken in milliseconds
    pub fix_time_ms: u64,
}

/// A single fix action applied to the SQL.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FixAction {
    /// What kind of fix was applied
    pub action: FixActionType,

    /// The original text that was replaced
    pub original: String,

    /// The replacement text
    pub replacement: String,

    /// Confidence score (0.0 - 1.0)
    pub confidence: f64,

    /// Human-readable explanation
    pub explanation: String,

    /// Location in the SQL where the fix was applied
    #[serde(skip_serializing_if = "Option::is_none")]
    pub location: Option<crate::errors::types::SourceLocation>,
}

/// Types of fix actions.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum FixActionType {
    /// Replace a misspelled table name
    ReplaceTable,
    /// Replace a misspelled column name
    ReplaceColumn,
    /// Qualify an ambiguous column with a table name
    QualifyColumn,
    /// Remove an incorrect alias
    RemoveAlias,
    /// Add a missing alias
    AddAlias,
    /// Use an alternative expression
    UseAlternative,
}

/// An error that could not be automatically fixed.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UnfixableError {
    /// The original validation error
    pub error: crate::errors::types::ValidationError,

    /// Why it couldn't be fixed
    pub reason: String,
}

/// Configuration for the fix engine.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FixConfig {
    /// Minimum confidence threshold for applying a fix (default: 0.8)
    pub min_confidence: f64,

    /// Maximum number of fix iterations (default: 3)
    pub max_iterations: usize,

    /// Whether to re-validate after fixing (default: true)
    pub revalidate: bool,
}

impl Default for FixConfig {
    fn default() -> Self {
        Self {
            min_confidence: 0.8,
            max_iterations: 3,
            revalidate: true,
        }
    }
}
