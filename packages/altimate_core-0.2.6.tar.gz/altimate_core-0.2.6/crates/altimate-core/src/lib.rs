//! # altimate-core
//!
//! SQL validation engine powered by Apache DataFusion.
//! Validates SQL queries against a schema definition WITHOUT requiring a live database.
//!
//! ## Quick Start
//!
//! ```rust,no_run
//! use altimate_core::{validate, SchemaDefinition};
//!
//! #[tokio::main]
//! async fn main() {
//!     let schema = SchemaDefinition::from_yaml_file("schema.yaml").unwrap();
//!     let result = validate("SELECT id FROM users", &schema).await;
//!     println!("Valid: {}", result.valid);
//!     for error in &result.errors {
//!         println!("  Error: {}", error.message);
//!     }
//! }
//! ```

pub mod agent;
pub mod completer;
pub mod context;
pub mod correction;
pub mod dag;
pub mod dbt;
pub mod equivalence;
pub mod errors;
pub mod explainer;
pub mod fixer;
pub mod glossary;
pub mod guardrails;
pub mod introspect;
pub mod lineage;
pub mod linter;
pub mod migration;
pub mod observability;
pub mod output;
pub mod pii;
pub mod polyglot;
pub mod pruner;
pub mod rewriter;
pub mod safety;
pub mod schema;
pub mod semantic;
pub mod tagger;
pub mod testgen;
pub mod validator;

// Re-export primary types for convenience
pub use errors::types::{
    ErrorCode, ErrorKind, Suggestion, SuggestionKind, ValidationError, ValidationResult,
    ValidationWarning,
};
pub use explainer::engine::explain;
pub use explainer::types::{ExplanationResult, QueryExplanation};
pub use fixer::engine::fix;
pub use fixer::types::FixResult;
pub use guardrails::engine::check_policy;
pub use guardrails::policy::PolicyConfig;
pub use guardrails::types::PolicyResult;
pub use schema::types::{ColumnDef, SchemaDefinition, SqlDialect, TableDef};
pub use validator::engine::validate;

// Re-export agent types for convenience
pub use agent::{
    AgentError, AgentMetadata, AgentResponse, BatchRequest, BatchResponse, SuggestedAction,
};
