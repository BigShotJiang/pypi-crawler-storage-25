//! JSON output formatter for agent consumption.

use crate::errors::types::ValidationResult;

/// Format a ValidationResult as pretty-printed JSON.
pub fn format_json(result: &ValidationResult) -> String {
    serde_json::to_string_pretty(result)
        .unwrap_or_else(|e| format!("{{\"error\": \"Failed to serialize result: {e}\"}}"))
}

/// Format a ValidationResult as compact JSON (single line).
pub fn format_json_compact(result: &ValidationResult) -> String {
    serde_json::to_string(result)
        .unwrap_or_else(|e| format!("{{\"error\": \"Failed to serialize result: {e}\"}}"))
}
