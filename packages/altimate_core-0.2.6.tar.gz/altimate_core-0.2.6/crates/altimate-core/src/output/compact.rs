//! Compact output formatter for agent consumption.
//!
//! Produces minimal-token output optimized for LLM context windows.
//! Default format for CLI — agents get concise structured output.
//! Use `--human-mode` for verbose, colored terminal output.

use crate::errors::types::ValidationResult;
use crate::explainer::types::ExplanationResult;
use crate::fixer::types::FixResult;
use crate::guardrails::types::PolicyResult;
use crate::lineage::{CompleteLineageResult, LineageDepth, TieredLineage};

/// Format validation result as compact single-line output.
///
/// `OK` for valid queries, or `FAIL | N errors, M warnings` with
/// one compact line per error.
pub fn format_compact_validation(result: &ValidationResult) -> String {
    if result.valid {
        return "OK".to_string();
    }

    let mut lines = Vec::new();
    lines.push(format!(
        "FAIL | {} error{}, {} warning{}",
        result.errors.len(),
        if result.errors.len() == 1 { "" } else { "s" },
        result.warnings.len(),
        if result.warnings.len() == 1 { "" } else { "s" },
    ));

    for error in &result.errors {
        let loc = error
            .location
            .as_ref()
            .map(|l| format!("L{}:{} ", l.line, l.column))
            .unwrap_or_default();
        let fix = if let Some(s) = error.suggestions.first() {
            format!(" — {}", s.message)
        } else {
            String::new()
        };
        lines.push(format!("{loc}ERR {} {}{fix}", error.code, error.message));
    }

    for warning in &result.warnings {
        let loc = warning
            .location
            .as_ref()
            .map(|l| format!("L{}:{} ", l.line, l.column))
            .unwrap_or_default();
        lines.push(format!("{loc}WARN {} {}", warning.code, warning.message));
    }

    lines.join("\n")
}

/// Format explanation result as compact output.
pub fn format_compact_explanation(result: &ExplanationResult) -> String {
    if !result.valid {
        return format_compact_validation(&ValidationResult::with_errors(
            result.validation.errors.clone(),
        ));
    }

    let Some(ref explanation) = result.explanation else {
        return "OK | no explanation available".to_string();
    };

    let mut lines = Vec::new();
    lines.push(explanation.summary.clone());

    // Plan steps count
    if !explanation.plan_steps.is_empty() {
        lines.push(format!("plan: {}", explanation.plan_steps.len()));
    }

    // Lineage summary
    if !explanation.lineage.tables.is_empty() {
        lines.push(format!("tables: {}", explanation.lineage.tables.join(",")));
    }

    // Cost
    let c = &explanation.cost_signals;
    lines.push(format!(
        "cost: complexity={} tables={} joins={} filters={}",
        c.complexity_score, c.table_count, c.join_count, c.filter_count
    ));

    // Risk flags
    for flag in &explanation.cost_signals.risk_flags {
        lines.push(format!("risk: {:?} {}", flag.severity, flag.detail));
    }

    lines.join("\n")
}

/// Format fix result as compact output.
pub fn format_compact_fix(result: &FixResult) -> String {
    if !result.fixed {
        let reasons: Vec<&str> = result
            .unfixable_errors
            .iter()
            .map(|u| u.error.message.as_str())
            .collect();
        return format!("UNFIXABLE | {}", reasons.join("; "));
    }

    let mut lines = Vec::new();
    lines.push(format!("FIXED | {} fixes", result.fixes_applied.len()));
    for fix in &result.fixes_applied {
        lines.push(format!(
            "'{}' -> '{}' ({:.0}%)",
            fix.original,
            fix.replacement,
            fix.confidence * 100.0,
        ));
    }
    if result.post_fix_valid {
        lines.push("post-fix: OK".to_string());
    } else {
        lines.push("post-fix: FAIL".to_string());
    }
    lines.push(result.fixed_sql.trim().to_string());

    lines.join("\n")
}

/// Format policy result as compact output.
pub fn format_compact_policy(result: &PolicyResult) -> String {
    let status = if result.allowed { "ALLOW" } else { "BLOCK" };
    let mut lines = Vec::new();
    lines.push(format!(
        "{status} | {} violations, {} warnings",
        result.violations.len(),
        result.warnings.len(),
    ));

    for v in &result.violations {
        lines.push(format!("VIOL [{:?}] {}", v.category, v.message));
    }
    for w in &result.warnings {
        lines.push(format!("WARN [{:?}] {}", w.category, w.message));
    }

    lines.join("\n")
}

/// Format lineage result as compact output.
pub fn format_compact_lineage(result: &CompleteLineageResult) -> String {
    let mut lines = Vec::new();

    if result.column_dict.is_empty() {
        return "LINEAGE | 0 columns".to_string();
    }

    let depth_str = serde_json::to_string(&result.depth)
        .unwrap_or_else(|_| format!("{:?}", LineageDepth::Full).to_ascii_lowercase());

    lines.push(format!(
        "LINEAGE | {} cols, {} tables, depth={}",
        result.column_dict.len(),
        result.source_tables.len(),
        depth_str,
    ));

    // Compact column dict
    let mut cols: Vec<(&String, &Vec<String>)> = result.column_dict.iter().collect();
    cols.sort_by_key(|(k, _)| *k);
    for (col, sources) in cols {
        lines.push(format!("{col} <- {}", sources.join(", ")));
    }

    if !result.source_tables.is_empty() {
        lines.push(format!("src: {}", result.source_tables.join(", ")));
    }

    lines.join("\n")
}

/// Format tiered lineage result as compact output (used when `--depth basic|deep` is specified).
///
/// Uses only the filtered tier data so the output reflects the requested depth level.
pub fn format_compact_tiered_lineage(tiered: &TieredLineage, depth: LineageDepth) -> String {
    let mut lines = Vec::new();

    if tiered.basic.column_dict.is_empty() {
        return "LINEAGE | 0 columns".to_string();
    }

    let depth_str =
        serde_json::to_string(&depth).unwrap_or_else(|_| format!("{depth:?}").to_ascii_lowercase());

    lines.push(format!(
        "LINEAGE | {} cols, {} tables, depth={}",
        tiered.basic.column_dict.len(),
        tiered.basic.source_tables.len(),
        depth_str,
    ));

    let mut cols: Vec<(&String, &Vec<String>)> = tiered.basic.column_dict.iter().collect();
    cols.sort_by_key(|(k, _)| *k);
    for (col, sources) in cols {
        lines.push(format!("{col} <- {}", sources.join(", ")));
    }

    if !tiered.basic.source_tables.is_empty() {
        lines.push(format!("src: {}", tiered.basic.source_tables.join(", ")));
    }

    lines.join("\n")
}
