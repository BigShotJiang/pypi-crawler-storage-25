//! SQL test case generator.
//!
//! Given a query and schema, generates test cases: boundary values,
//! NULL handling, empty tables, type edge cases.

pub mod engine;
pub mod types;

pub use engine::generate_tests;
pub use types::*;
