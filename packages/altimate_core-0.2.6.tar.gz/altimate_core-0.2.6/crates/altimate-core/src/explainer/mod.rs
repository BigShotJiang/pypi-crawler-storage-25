//! Query explanation engine.
//!
//! Walks DataFusion LogicalPlan trees and extracts structured intelligence
//! about query behavior: plan steps, column lineage, cost signals, and
//! optimization suggestions.

pub mod cost;
pub mod engine;
pub mod lineage;
pub mod plan_walker;
pub mod suggestions;
pub mod types;
