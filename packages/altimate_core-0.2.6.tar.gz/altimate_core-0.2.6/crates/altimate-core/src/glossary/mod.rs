//! Semantic Layer / Business Glossary module.
//!
//! Maps business terms (e.g., "revenue", "active customers") to schema elements
//! (tables, columns, SQL expressions), enabling natural-language lookups and
//! fuzzy matching against the schema definition.
//!
//! # Usage
//!
//! ```rust,no_run
//! use altimate_core::glossary::{resolve_term, resolve_all_terms, suggest_terms};
//! use altimate_core::SchemaDefinition;
//!
//! let schema = SchemaDefinition::from_yaml_file("schema.yaml").unwrap();
//! let matches = resolve_term("revenue", &schema);
//! for m in &matches {
//!     println!("{} -> confidence {:.2}", m.term, m.confidence);
//! }
//! ```

pub mod engine;
pub mod types;

pub use engine::{resolve_all_terms, resolve_term, suggest_terms};
pub use types::{GlossaryMatch, MatchSource, TermResolutionResult, TermSuggestion};
