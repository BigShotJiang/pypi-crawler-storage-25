//! Multi-query data lineage tracking.
//!
//! Traces column-level data flow through SQL queries:
//! which tables/columns feed into which outputs.
//!
//! Use [`column_lineage()`] as the single entry point for column lineage.
//! Pass `None` for options to get projection-only lineage (the common case).

pub mod bridge;
pub mod column_lineage;
pub mod complete;
pub mod tracker;
pub mod types;

pub use column_lineage::polyglot_column_lineage;
pub use complete::{
    BasicLineage, ColumnLineageOptions, CompleteLineageResult, DeepLineage, DiffLineageResult,
    ExtendedLineage, LensClassification, LensStep, LineageDepth, LineageEntry, LineageType,
    TieredLineage, column_lineage, diff_lineage,
};
pub use tracker::track_lineage;
pub use types::*;
