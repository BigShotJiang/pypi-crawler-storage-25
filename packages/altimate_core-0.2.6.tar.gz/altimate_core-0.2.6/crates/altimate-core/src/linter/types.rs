//! Types for SQL linting.

use serde::{Deserialize, Serialize};

/// Severity of a lint finding.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum LintSeverity {
    Error,
    Warning,
    Info,
}

/// A single lint finding.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LintFinding {
    /// Lint rule code (e.g., "L001")
    pub code: String,
    /// Rule name
    pub rule: String,
    /// Severity
    pub severity: LintSeverity,
    /// Human-readable message
    pub message: String,
    /// Suggested fix
    #[serde(skip_serializing_if = "Option::is_none")]
    pub suggestion: Option<String>,
    /// Line number (1-based) if available
    #[serde(skip_serializing_if = "Option::is_none")]
    pub line: Option<usize>,
    /// Column number (1-based) if available
    #[serde(skip_serializing_if = "Option::is_none")]
    pub column: Option<usize>,
}

/// Result of SQL linting.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LintResult {
    /// Original SQL
    pub sql: String,
    /// Lint findings
    pub findings: Vec<LintFinding>,
    /// Number of errors
    pub error_count: usize,
    /// Number of warnings
    pub warning_count: usize,
    /// Whether the SQL passes all lint rules
    pub clean: bool,
}
