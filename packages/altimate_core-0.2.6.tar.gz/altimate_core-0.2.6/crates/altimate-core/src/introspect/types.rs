//! Types for schema introspection.

use serde::{Deserialize, Serialize};

/// Supported database types for introspection.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum DatabaseType {
    Postgres,
    MySQL,
    SQLite,
    Snowflake,
    BigQuery,
    Redshift,
    DuckDB,
}

/// Raw column info from INFORMATION_SCHEMA.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RawColumnInfo {
    pub table_name: String,
    pub column_name: String,
    pub data_type: String,
    pub is_nullable: bool,
    pub ordinal_position: usize,
    #[serde(default)]
    pub column_default: Option<String>,
    #[serde(default)]
    pub character_maximum_length: Option<i64>,
    #[serde(default)]
    pub numeric_precision: Option<i64>,
    #[serde(default)]
    pub numeric_scale: Option<i64>,
}

/// Raw primary key info.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RawPrimaryKeyInfo {
    pub table_name: String,
    pub column_name: String,
}

/// Raw foreign key info.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RawForeignKeyInfo {
    pub table_name: String,
    pub column_name: String,
    pub referenced_table: String,
    pub referenced_column: String,
}

/// Complete introspection output from a database.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IntrospectionOutput {
    pub columns: Vec<RawColumnInfo>,
    #[serde(default)]
    pub primary_keys: Vec<RawPrimaryKeyInfo>,
    #[serde(default)]
    pub foreign_keys: Vec<RawForeignKeyInfo>,
}

/// Result of introspection SQL generation.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IntrospectionSql {
    pub database_type: String,
    pub columns_query: String,
    pub primary_keys_query: String,
    pub foreign_keys_query: String,
}
