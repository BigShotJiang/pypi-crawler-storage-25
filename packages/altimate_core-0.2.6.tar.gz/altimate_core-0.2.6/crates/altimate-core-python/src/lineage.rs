//! Lineage bindings: column_lineage, track_lineage, diff_lineage.
//!
//! These functions work without SDK initialization (pure local computation).
//! When `init()` has been called with valid credentials, usage is logged
//! via credit deduction, failure reporting, and telemetry.

use crate::schema::Schema;
use pyo3::prelude::*;
use std::collections::HashMap;

/// Parse a depth string into LineageDepth, returning a Python error for invalid values.
fn parse_depth(depth: &str) -> PyResult<altimate_core::lineage::LineageDepth> {
    depth
        .parse()
        .map_err(|e: String| pyo3::exceptions::PyValueError::new_err(e))
}

/// Compute column-level lineage for a SQL query.
///
/// Returns a dict with `column_dict` (output->sources mapping),
/// `column_lineage` (detailed edge list), `tier`, and `depth`.
///
/// Works without `init()`. When initialized with API keys, logs usage
/// via credits and telemetry.
///
/// Pass `default_database` and `default_schema` to qualify unqualified table
/// references (important for Snowflake lineage matching).
///
/// The `depth` parameter controls how much detail is returned:
/// - `"basic"`: direct source→target edges only
/// - `"deep"`: includes transformation metadata (lens_type, lens_code)
/// - `"full"` (default): everything including indirect edges
#[pyfunction]
#[pyo3(signature = (sql, *, dialect="generic", schema=None, default_database=None, default_schema=None, depth="full"))]
pub fn column_lineage(
    py: Python<'_>,
    sql: &str,
    dialect: &str,
    schema: Option<&Schema>,
    default_database: Option<String>,
    default_schema: Option<String>,
    depth: &str,
) -> PyResult<PyObject> {
    let sdk_active = crate::sdk::is_initialized();

    // Only check credits when SDK is initialized.
    if sdk_active {
        py.allow_threads(|| crate::sdk::check_credits("column_lineage"))?;
    }

    let d = crate::convert::parse_dialect(dialect)?;

    // The lineage engine expects schema as { "table": { "col": "type", ... }, ... }
    let schema_map = match schema {
        Some(s) => schema_def_to_lineage_map(&s.inner),
        None => HashMap::new(),
    };

    let options = Some(altimate_core::lineage::ColumnLineageOptions {
        default_database,
        default_schema,
        inject_shared: false,
        depth: parse_depth(depth)?,
    });

    let start = std::time::Instant::now();
    let result = altimate_core::lineage::column_lineage(sql, d, &schema_map, options.as_ref())
        .map_err(|e| {
            crate::sdk::report_failure_kv(
                "columnLineage",
                &[
                    ("sql", serde_json::json!(sql)),
                    ("dialect", serde_json::json!(dialect)),
                    ("depth", serde_json::json!(depth)),
                ],
                start.elapsed().as_millis() as u64,
                &e,
            );
            pyo3::exceptions::PyRuntimeError::new_err(e)
        })?;
    let duration_ms = start.elapsed().as_millis() as u64;

    let has_lineage = !result.column_dict.is_empty() || !result.column_lineage.is_empty();

    // Soft failure: valid SQL but empty lineage — report with all args for reproducibility.
    if !has_lineage && sql.trim().len() > 5 {
        let reason = if result.errors.is_empty() {
            "EmptyLineage".to_owned()
        } else {
            format!("ParseError: {}", result.errors.join("; "))
        };
        crate::sdk::report_failure_kv(
            "columnLineage",
            &[
                ("sql", serde_json::json!(sql)),
                ("dialect", serde_json::json!(dialect)),
                ("depth", serde_json::json!(depth)),
                ("schema_tables", serde_json::json!(schema_map.len())),
            ],
            duration_ms,
            &reason,
        );
    }

    // Credit deduction — only when SDK is initialized.
    if sdk_active && has_lineage {
        crate::sdk::count_credit("column_lineage", 1);
    }

    // Success telemetry — ALWAYS fires (emit_event handles opt-out internally).
    let mut props = serde_json::Map::new();
    props.insert("operation".into(), serde_json::json!("columnLineage"));
    props.insert("dialect".into(), serde_json::json!(dialect));
    props.insert("success".into(), serde_json::json!(has_lineage));
    props.insert("error_count".into(), serde_json::json!(result.errors.len()));
    let mut measurements = serde_json::Map::new();
    measurements.insert("duration_ms".into(), serde_json::json!(duration_ms as f64));
    crate::sdk::emit_event("sdk/columnLineage", props, measurements);

    crate::convert::to_py_result(py, &result)
}

/// Compute diff-aware column lineage between two SQL queries.
///
/// Returns a dict with `added_columns`, `removed_columns`,
/// `modified_columns`, `affected_downstream`, `before`, and `after`.
///
/// Works without `init()`. When initialized with API keys, logs usage
/// via credits and telemetry.
#[pyfunction]
#[pyo3(signature = (before_sql, after_sql, *, dialect="generic", schema=None, default_database=None, default_schema=None, depth="full"))]
pub fn diff_lineage(
    py: Python<'_>,
    before_sql: &str,
    after_sql: &str,
    dialect: &str,
    schema: Option<&Schema>,
    default_database: Option<String>,
    default_schema: Option<String>,
    depth: &str,
) -> PyResult<PyObject> {
    let sdk_active = crate::sdk::is_initialized();

    if sdk_active {
        py.allow_threads(|| crate::sdk::check_credits("diff_lineage"))?;
    }

    let d = crate::convert::parse_dialect(dialect)?;
    let schema_map = match schema {
        Some(s) => schema_def_to_lineage_map(&s.inner),
        None => HashMap::new(),
    };

    let options = Some(altimate_core::lineage::ColumnLineageOptions {
        default_database,
        default_schema,
        inject_shared: false,
        depth: parse_depth(depth)?,
    });

    let start = std::time::Instant::now();
    let result = altimate_core::lineage::diff_lineage(
        before_sql,
        after_sql,
        d,
        &schema_map,
        options.as_ref(),
    )
    .map_err(|e| {
        crate::sdk::report_failure_kv(
            "diffLineage",
            &[
                ("before_sql", serde_json::json!(before_sql)),
                ("after_sql", serde_json::json!(after_sql)),
                ("dialect", serde_json::json!(dialect)),
                ("depth", serde_json::json!(depth)),
            ],
            start.elapsed().as_millis() as u64,
            &e,
        );
        pyo3::exceptions::PyRuntimeError::new_err(e)
    })?;

    if sdk_active {
        let has_diff = !result.added_columns.is_empty()
            || !result.removed_columns.is_empty()
            || !result.modified_columns.is_empty();
        if has_diff {
            crate::sdk::count_credit("diff_lineage", 2);
        }
    }

    // Success telemetry — ALWAYS fires.
    crate::sdk::timed_emit_with_dialect("diffLineage", dialect, start);

    crate::convert::to_py_result(py, &result)
}

/// Track column-level lineage across multiple queries.
///
/// Works without `init()`. When initialized with API keys, logs usage
/// via credits and telemetry.
///
/// The `depth` parameter mirrors `column_lineage`: `"basic"`, `"deep"`, or `"full"` (default).
#[pyfunction]
#[pyo3(signature = (queries, schema, *, depth="full"))]
pub fn track_lineage(
    py: Python<'_>,
    queries: Vec<String>,
    schema: &Schema,
    depth: &str,
) -> PyResult<PyObject> {
    let sdk_active = crate::sdk::is_initialized();

    if sdk_active {
        py.allow_threads(|| crate::sdk::check_credits("track_lineage"))?;
    }

    let _depth = parse_depth(depth)?;
    let refs: Vec<&str> = queries.iter().map(|s| s.as_str()).collect();

    let start = std::time::Instant::now();
    let result = altimate_core::lineage::track_lineage(&refs, &schema.inner).map_err(|e| {
        crate::sdk::report_failure_kv(
            "trackLineage",
            &[
                ("query_count", serde_json::json!(queries.len())),
                ("depth", serde_json::json!(depth)),
            ],
            start.elapsed().as_millis() as u64,
            &e,
        );
        pyo3::exceptions::PyRuntimeError::new_err(e)
    })?;

    if sdk_active {
        crate::sdk::count_credit("track_lineage", queries.len());
    }

    // Success telemetry — ALWAYS fires.
    let mut props = serde_json::Map::new();
    props.insert("operation".into(), serde_json::json!("trackLineage"));
    props.insert("query_count".into(), serde_json::json!(queries.len()));
    crate::sdk::emit_event("sdk/trackLineage", props, serde_json::Map::new());

    crate::convert::to_py_result(py, &result)
}

/// Convert SchemaDefinition to the flat `{ table: { col: type } }` format
/// that the polyglot-sql lineage engine expects.
fn schema_def_to_lineage_map(
    schema: &altimate_core::SchemaDefinition,
) -> HashMap<String, serde_json::Value> {
    schema
        .tables
        .iter()
        .map(|(table_name, table_def)| {
            let cols: serde_json::Map<String, serde_json::Value> = table_def
                .columns
                .iter()
                .map(|col| {
                    (
                        col.name.clone(),
                        serde_json::Value::String(col.data_type.clone()),
                    )
                })
                .collect();
            (table_name.clone(), serde_json::Value::Object(cols))
        })
        .collect()
}
