//! Python bindings for altimate-core — SQL validation engine.
//!
//! ## Usage
//!
//! ```python
//! import altimate_core
//!
//! schema = altimate_core.Schema.from_file("schema.yaml")
//! result = altimate_core.validate("SELECT * FROM users", schema)
//! print(result["valid"])
//! for error in result["errors"]:
//!     print(f"  {error['code']}: {error['message']}")
//! ```

use pyo3::prelude::*;

mod context;
mod convert;
mod intelligence;
mod lineage;
mod polyglot;
mod runtime;
mod safety;
mod schema;
pub(crate) mod sdk;
mod tools;
mod validate;

/// altimate-core Python module — type-check your SQL, no database required.
#[pymodule(name = "_core")]
fn _core(m: &Bound<'_, PyModule>) -> PyResult<()> {
    altimate_sdk::set_binding("python");

    // Schema class
    m.add_class::<schema::Schema>()?;

    // Core validation
    m.add_function(wrap_pyfunction!(validate::validate, m)?)?;
    m.add_function(wrap_pyfunction!(validate::explain, m)?)?;
    m.add_function(wrap_pyfunction!(validate::fix, m)?)?;
    m.add_function(wrap_pyfunction!(validate::check_policy, m)?)?;

    // Polyglot (cross-dialect)
    m.add_function(wrap_pyfunction!(polyglot::transpile, m)?)?;
    m.add_function(wrap_pyfunction!(polyglot::format_sql, m)?)?;
    m.add_function(wrap_pyfunction!(polyglot::extract_metadata, m)?)?;
    m.add_function(wrap_pyfunction!(polyglot::extract_output_columns, m)?)?;
    m.add_function(wrap_pyfunction!(polyglot::compare_queries, m)?)?;

    // Safety & linting
    m.add_function(wrap_pyfunction!(safety::lint, m)?)?;
    m.add_function(wrap_pyfunction!(safety::scan_sql, m)?)?;
    m.add_function(wrap_pyfunction!(safety::is_safe, m)?)?;
    m.add_function(wrap_pyfunction!(safety::classify_pii, m)?)?;
    m.add_function(wrap_pyfunction!(safety::check_query_pii, m)?)?;
    m.add_function(wrap_pyfunction!(safety::check_semantics, m)?)?;
    m.add_function(wrap_pyfunction!(safety::resolve_term, m)?)?;
    m.add_function(wrap_pyfunction!(safety::analyze_tags, m)?)?;

    // Lineage
    m.add_function(wrap_pyfunction!(lineage::column_lineage, m)?)?;
    m.add_function(wrap_pyfunction!(lineage::track_lineage, m)?)?;
    m.add_function(wrap_pyfunction!(lineage::diff_lineage, m)?)?;

    // Intelligence
    m.add_function(wrap_pyfunction!(intelligence::check_equivalence, m)?)?;
    m.add_function(wrap_pyfunction!(intelligence::correct, m)?)?;
    m.add_function(wrap_pyfunction!(intelligence::evaluate, m)?)?;

    // Tools
    m.add_function(wrap_pyfunction!(tools::complete, m)?)?;
    m.add_function(wrap_pyfunction!(tools::rewrite, m)?)?;
    m.add_function(wrap_pyfunction!(tools::generate_tests, m)?)?;
    m.add_function(wrap_pyfunction!(tools::analyze_migration, m)?)?;
    m.add_function(wrap_pyfunction!(tools::parse_dbt_project, m)?)?;

    // Context & schema ops
    m.add_function(wrap_pyfunction!(context::optimize_context, m)?)?;
    m.add_function(wrap_pyfunction!(context::optimize_for_query, m)?)?;
    m.add_function(wrap_pyfunction!(context::prune_schema, m)?)?;
    m.add_function(wrap_pyfunction!(context::diff_schemas, m)?)?;
    m.add_function(wrap_pyfunction!(context::import_ddl, m)?)?;
    m.add_function(wrap_pyfunction!(context::export_ddl, m)?)?;
    m.add_function(wrap_pyfunction!(context::schema_fingerprint, m)?)?;
    m.add_function(wrap_pyfunction!(context::introspection_sql, m)?)?;

    // SDK init gate and credit enforcement
    m.add_function(wrap_pyfunction!(sdk::_init_sdk, m)?)?;
    m.add_function(wrap_pyfunction!(sdk::_reset_sdk, m)?)?;
    m.add_function(wrap_pyfunction!(sdk::_flush_sdk, m)?)?;

    Ok(())
}
