//! Tool bindings: complete, rewrite, generate_tests, analyze_migration, parse_dbt_project.

use crate::schema::Schema;
use pyo3::prelude::*;

/// SQL completion engine: suggest tables, columns, functions, keywords at cursor position.
#[pyfunction]
pub fn complete(
    py: Python<'_>,
    sql: &str,
    cursor_pos: usize,
    schema: &Schema,
) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let result = altimate_core::completer::complete(sql, cursor_pos, &schema.inner);
    match crate::convert::to_py_result(py, &result) {
        Ok(obj) => {
            crate::sdk::timed_emit("complete", start);
            Ok(obj)
        }
        Err(e) => {
            crate::sdk::report_failure_kv(
                "complete",
                &[
                    ("sql", serde_json::json!(sql)),
                    ("cursor_pos", serde_json::json!(cursor_pos)),
                ],
                start.elapsed().as_millis() as u64,
                &e.to_string(),
            );
            Err(e)
        }
    }
}

/// Suggest query rewrites and optimizations.
#[pyfunction]
pub fn rewrite(py: Python<'_>, sql: &str, schema: &Schema) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let result = altimate_core::rewriter::rewrite(sql, &schema.inner);
    match crate::convert::to_py_result(py, &result) {
        Ok(obj) => {
            crate::sdk::timed_emit("rewrite", start);
            Ok(obj)
        }
        Err(e) => {
            crate::sdk::report_failure_kv(
                "rewrite",
                &[("sql", serde_json::json!(sql))],
                start.elapsed().as_millis() as u64,
                &e.to_string(),
            );
            Err(e)
        }
    }
}

/// Generate test cases for a SQL query (boundary values, NULLs, edge cases).
#[pyfunction]
pub fn generate_tests(py: Python<'_>, sql: &str, schema: &Schema) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let result = altimate_core::testgen::generate_tests(sql, &schema.inner);
    match crate::convert::to_py_result(py, &result) {
        Ok(obj) => {
            crate::sdk::timed_emit("generateTests", start);
            Ok(obj)
        }
        Err(e) => {
            crate::sdk::report_failure_kv(
                "generateTests",
                &[("sql", serde_json::json!(sql))],
                start.elapsed().as_millis() as u64,
                &e.to_string(),
            );
            Err(e)
        }
    }
}

/// Analyze migration safety (data loss, type narrowing, missing defaults).
#[pyfunction]
pub fn analyze_migration(py: Python<'_>, sql: &str, schema: &Schema) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let result = altimate_core::migration::analyze_migration(sql, &schema.inner);
    match crate::convert::to_py_result(py, &result) {
        Ok(obj) => {
            crate::sdk::timed_emit("analyzeMigration", start);
            Ok(obj)
        }
        Err(e) => {
            crate::sdk::report_failure_kv(
                "analyzeMigration",
                &[("sql", serde_json::json!(sql))],
                start.elapsed().as_millis() as u64,
                &e.to_string(),
            );
            Err(e)
        }
    }
}

/// Parse a dbt project directory.
#[pyfunction]
pub fn parse_dbt_project(py: Python<'_>, project_dir: &str) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let result =
        altimate_core::dbt::parse_dbt_project(std::path::Path::new(project_dir)).map_err(|e| {
            crate::sdk::report_failure_kv(
                "parseDbtProject",
                &[("project_dir", serde_json::json!(project_dir))],
                start.elapsed().as_millis() as u64,
                &e,
            );
            pyo3::exceptions::PyRuntimeError::new_err(e)
        })?;
    crate::sdk::timed_emit("parseDbtProject", start);
    crate::convert::to_py_result(py, &result)
}
