//! Core validation bindings: validate, explain, fix, check_policy.

use crate::schema::Schema;
use pyo3::prelude::*;

/// Validate SQL against a schema. Returns a dict with `valid`, `errors`, `warnings`.
#[pyfunction]
pub fn validate(py: Python<'_>, sql: &str, schema: &Schema) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let result = crate::runtime::runtime().block_on(altimate_core::validate(sql, &schema.inner));
    match crate::convert::to_py_result(py, &result) {
        Ok(obj) => {
            crate::sdk::timed_emit("validate", start);
            Ok(obj)
        }
        Err(e) => {
            crate::sdk::report_failure_kv(
                "validate",
                &[("sql", serde_json::json!(sql))],
                start.elapsed().as_millis() as u64,
                &e.to_string(),
            );
            Err(e)
        }
    }
}

/// Explain a SQL query: plan steps, column lineage, cost signals.
#[pyfunction]
pub fn explain(py: Python<'_>, sql: &str, schema: &Schema) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let result = crate::runtime::runtime().block_on(altimate_core::explain(sql, &schema.inner));
    match crate::convert::to_py_result(py, &result) {
        Ok(obj) => {
            crate::sdk::timed_emit("explain", start);
            Ok(obj)
        }
        Err(e) => {
            crate::sdk::report_failure_kv(
                "explain",
                &[("sql", serde_json::json!(sql))],
                start.elapsed().as_millis() as u64,
                &e.to_string(),
            );
            Err(e)
        }
    }
}

/// Auto-fix SQL errors using fuzzy matching and iterative re-validation.
#[pyfunction]
#[pyo3(signature = (sql, schema, max_iterations=5))]
pub fn fix(
    py: Python<'_>,
    sql: &str,
    schema: &Schema,
    max_iterations: usize,
) -> PyResult<PyObject> {
    let config = altimate_core::fixer::types::FixConfig {
        max_iterations,
        ..Default::default()
    };
    let start = std::time::Instant::now();
    let result =
        crate::runtime::runtime().block_on(altimate_core::fix(sql, &schema.inner, &config));
    match crate::convert::to_py_result(py, &result) {
        Ok(obj) => {
            crate::sdk::timed_emit("fix", start);
            Ok(obj)
        }
        Err(e) => {
            crate::sdk::report_failure_kv(
                "fix",
                &[
                    ("sql", serde_json::json!(sql)),
                    ("max_iterations", serde_json::json!(max_iterations)),
                ],
                start.elapsed().as_millis() as u64,
                &e.to_string(),
            );
            Err(e)
        }
    }
}

/// Check SQL against policy guardrails. `policy_json` is a JSON string of PolicyConfig.
#[pyfunction]
pub fn check_policy(
    py: Python<'_>,
    sql: &str,
    schema: &Schema,
    policy_json: &str,
) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let policy: altimate_core::PolicyConfig = serde_json::from_str(policy_json).map_err(|e| {
        let err_msg = format!("invalid policy JSON: {e}");
        crate::sdk::report_failure_kv(
            "checkPolicy",
            &[
                ("sql", serde_json::json!(sql)),
                ("policy_json", serde_json::json!(policy_json)),
            ],
            start.elapsed().as_millis() as u64,
            &err_msg,
        );
        pyo3::exceptions::PyValueError::new_err(err_msg)
    })?;
    let result = crate::runtime::runtime().block_on(altimate_core::check_policy(
        sql,
        &schema.inner,
        &policy,
    ));
    match crate::convert::to_py_result(py, &result) {
        Ok(obj) => {
            crate::sdk::timed_emit("checkPolicy", start);
            Ok(obj)
        }
        Err(e) => {
            crate::sdk::report_failure_kv(
                "checkPolicy",
                &[
                    ("sql", serde_json::json!(sql)),
                    ("policy_json", serde_json::json!(policy_json)),
                ],
                start.elapsed().as_millis() as u64,
                &e.to_string(),
            );
            Err(e)
        }
    }
}
