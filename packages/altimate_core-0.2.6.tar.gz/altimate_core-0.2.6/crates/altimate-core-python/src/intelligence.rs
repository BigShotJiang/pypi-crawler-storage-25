//! Intelligence bindings: check_equivalence, correct, evaluate.

use crate::schema::Schema;
use pyo3::prelude::*;

/// Check two SQL queries for semantic equivalence.
#[pyfunction]
pub fn check_equivalence(
    py: Python<'_>,
    sql_a: &str,
    sql_b: &str,
    schema: &Schema,
) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let result = crate::runtime::runtime().block_on(
        altimate_core::equivalence::engine::check_equivalence(sql_a, sql_b, &schema.inner),
    );
    match crate::convert::to_py_result(py, &result) {
        Ok(obj) => {
            crate::sdk::timed_emit("checkEquivalence", start);
            Ok(obj)
        }
        Err(e) => {
            crate::sdk::report_failure_kv(
                "checkEquivalence",
                &[
                    ("sql_a", serde_json::json!(sql_a)),
                    ("sql_b", serde_json::json!(sql_b)),
                ],
                start.elapsed().as_millis() as u64,
                &e.to_string(),
            );
            Err(e)
        }
    }
}

/// Iterative correction protocol: propose-verify-refine loop.
#[pyfunction]
pub fn correct(py: Python<'_>, sql: &str, schema: &Schema) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let config = Default::default();
    let result = crate::runtime::runtime().block_on(altimate_core::correction::engine::correct(
        sql,
        &schema.inner,
        &config,
    ));
    match crate::convert::to_py_result(py, &result) {
        Ok(obj) => {
            crate::sdk::timed_emit("correct", start);
            Ok(obj)
        }
        Err(e) => {
            crate::sdk::report_failure_kv(
                "correct",
                &[("sql", serde_json::json!(sql))],
                start.elapsed().as_millis() as u64,
                &e.to_string(),
            );
            Err(e)
        }
    }
}

/// SQL quality scoring and grading (A-F scale).
#[pyfunction]
pub fn evaluate(py: Python<'_>, sql: &str, schema: &Schema) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let config = Default::default();
    let result = crate::runtime::runtime().block_on(
        altimate_core::observability::engine::evaluate(sql, &schema.inner, &config),
    );
    match crate::convert::to_py_result(py, &result) {
        Ok(obj) => {
            crate::sdk::timed_emit("evaluate", start);
            Ok(obj)
        }
        Err(e) => {
            crate::sdk::report_failure_kv(
                "evaluate",
                &[("sql", serde_json::json!(sql))],
                start.elapsed().as_millis() as u64,
                &e.to_string(),
            );
            Err(e)
        }
    }
}
