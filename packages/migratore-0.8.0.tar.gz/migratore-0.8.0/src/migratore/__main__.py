#!/usr/bin/python
# -*- coding: utf-8 -*-

from .cli import main

if __name__ == "__main__":
    main()
