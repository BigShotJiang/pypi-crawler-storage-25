"""Tool definitions and executor for the chat engine's tool-use loop.

The LLM can invoke these tools by outputting a JSON block with a ``tool``
key.  The tool executor runs the request, captures the result, and returns
it as a string to be fed back to the model.
"""

from __future__ import annotations

import ast
import difflib
import hashlib
import json
import logging
import os
import re as _re
import shlex
import subprocess
import sys
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Maximum bytes of stdout/stderr captured from shell commands.
_MAX_OUTPUT = 50_000

# Shell commands that are always blocked (case-insensitive first token).
_BLOCKED_COMMANDS = frozenset({
    "rm", "rmdir", "del", "format", "mkfs", "dd",
    "shutdown", "reboot", "poweroff", "halt",
})

# Fuzzy matching threshold for edit_file fallback
_FUZZY_MATCH_THRESHOLD = 0.85

# Max lines to show as context when edit fails
_EDIT_ERROR_CONTEXT_LINES = 15


# ── Tool schemas (for the system prompt) ─────────────────────────────────

TOOL_DESCRIPTIONS = """\
You have access to the following tools. To use a tool, you MUST output a JSON
block wrapped in <tool_call> tags EXACTLY like this:

<tool_call>
{"tool": "tool_name", "args": {"arg1": "value1"}}
</tool_call>

You can call MULTIPLE tools in one response by including multiple <tool_call> blocks.
After each round of tool calls, you will receive ALL results and can continue.

EXAMPLES — follow these EXACTLY:

Example 1 — Reading a file:
<tool_call>
{"tool": "read_file", "args": {"path": "src/main.py"}}
</tool_call>

Example 2 — Running a command:
<tool_call>
{"tool": "run_command", "args": {"command": "python -m mypy src/ --ignore-missing-imports"}}
</tool_call>

Example 3 — Editing a file:
<tool_call>
{"tool": "edit_file", "args": {
  "path": "src/main.py",
  "old_string": "def old_func():",
  "new_string": "def new_func()"
}}
</tool_call>

Example 4 — Multiple tools in one response:
I'll read both files now.
<tool_call>
{"tool": "read_file", "args": {"path": "src/a.py"}}
</tool_call>
<tool_call>
{"tool": "read_file", "args": {"path": "src/b.py"}}
</tool_call>

Available tools:

1. **read_file** — Read the contents of a file.
   args: {"path": "relative/path/to/file", "start_line": 1, "end_line": 50}
   (start_line and end_line are optional; omit to read the full file)

2. **write_file** — Write content to a file (creates or overwrites).
   args: {"path": "relative/path/to/file", "content": "file content here"}

3. **edit_file** — Replace a specific string in a file.
   args: {"path": "relative/path/to/file",
          "old_string": "text to find",
          "new_string": "replacement text"}

4. **list_directory** — List files and folders in a directory (with file sizes).
   args: {"path": "relative/path"} (omit path or use "." for repo root)

5. **run_command** — Run a shell command and get the output.
   args: {"command": "pytest tests/ -q", "timeout": 120, "cwd": "../my_project"}
   (Destructive commands like rm, del, format are blocked for safety.)
   (timeout is optional, default 120 seconds. Use higher for long builds.)
   (cwd is optional — set it to run commands in a different directory, e.g., a newly created project.)

6. **search_code** — Search the codebase for a text pattern.
   args: {"pattern": "search string", "file_glob": "*.py"}
   (file_glob is optional)

7. **find_symbols** — Find function/class/variable definitions by name.
   args: {"name": "symbol_name", "kind": "function"}
   (kind is optional: function, class, variable, constant, interface)

8. **get_project_overview** — Get a high-level overview of the project structure,
   key files, and architecture. No args needed.
   args: {}

9. **grep_codebase** — Powerful recursive grep across the entire codebase.
   args: {"pattern": "regex_or_string", "file_glob": "*.py", "is_regex": true}
   (file_glob and is_regex are optional. Defaults: all files, literal search)
   Returns matching lines with file paths and line numbers.

10. **verify_changes** — Run the project's test suite, linter, and type checker
    to verify your changes work correctly.
    args: {"command": "pytest tests/ -v"}
    (command is optional — if omitted, auto-detects and runs all checks)

11. **batch_edit** — Make multiple edits across one or more files at once.
    args: {"edits": [{"path": "file.py", "old_string": "old", "new_string": "new"}, ...]}
    Returns results for each edit.

12. **edit_lines** — Replace lines by line number range (avoids string matching issues).
    args: {"path": "file.py", "start_line": 10, "end_line": 15, "new_content": "replacement code"}
    start_line/end_line are 1-based inclusive. Use this when you know exact line numbers.

13. **apply_diff** — Apply a unified diff to a file.
    args: {"path": "file.py", "diff": "--- a/file.py\n+++ b/file.py\n@@ -10,3 +10,4 @@\n..."}
    Use standard unified diff format. Useful for complex multi-hunk changes.

14. **create_directory** — Create a directory (including nested directories).
    args: {"path": "relative/path/to/dir"}
    Creates all parent directories automatically. Can create directories outside
    the repo root for new project scaffolding (e.g., "../my_new_app/src").

15. **create_project** — Create an entire project with multiple files at once.
    args: {"base_path": "../my_project", "files": {
      "src/main.py": "content",
      "src/utils.py": "content",
      "requirements.txt": "content",
      "README.md": "content"
    }}
    Creates the base_path directory and all files inside it in one call.
    Can create projects OUTSIDE the current repo (e.g., "../new_app").
    This is the PREFERRED tool for building new applications from scratch.
    It handles all directory creation and file writing in a single operation.

ABSOLUTE RULES — YOU MUST FOLLOW THESE:
- NEVER describe steps for the user to do. YOU do everything yourself using tools.
- If the user asks you to run mypy, YOU run it with run_command. DO NOT tell the user to run it.
- If the user asks you to fix a bug, YOU find the code, fix it, and verify. DO NOT give instructions.
- YOU are the agent. YOU execute. YOU do not delegate to the human.
- ALWAYS use <tool_call> tags to invoke tools. NEVER just mention a tool without calling it.
- After making code changes, run tests or build commands to verify correctness.
- Only run linters (ruff, mypy, eslint, etc.) when the user explicitly asks for linting or style checks.
- If tests fail, analyze the error, fix it with edit_file, and re-run tests. KEEP GOING.
- For every user request: ACT first, EXPLAIN after.
- You can run ANY command: pytest, mypy, ruff, npm, pip, cargo, make, go, dotnet, mvn, gradle, etc.
- On Windows, if a tool fails with "not recognized", try `python -m <tool>` or `npx <tool>` instead.
- Only truly destructive commands (rm, del, format, mkfs) are blocked.
- When building new projects OUTSIDE the current repo, use create_project to scaffold all files at once.
- On Windows: use `dir` instead of `ls`, `cd` instead of `pwd`, `type` instead of `cat`. Use `;` or `&` to chain commands, NOT `&&`.
- On Linux/macOS: standard Unix commands work fine.
- ALWAYS use create_project for multi-file project creation — it's faster and more reliable than individual write_file calls.
- Use MULTIPLE tool calls in ONE response for efficiency — do not waste rounds.
- Prefer batch_edit when making multiple edits across files.
"""

# ── Native Ollama tool schemas (JSON format for tool calling API) ─────────

TOOL_SCHEMAS = [
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read file contents. Always read before editing.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Relative path to the file"},
                    "start_line": {"type": "integer", "description": "Start line (1-based, optional)"},
                    "end_line": {"type": "integer", "description": "End line (1-based, optional)"},
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Create or overwrite a file. Parent directories are created automatically.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Relative path to the file"},
                    "content": {"type": "string", "description": "The content to write"},
                },
                "required": ["path", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "edit_file",
            "description": "Replace a specific string in a file. Read file first to get exact content.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Relative path to the file"},
                    "old_string": {"type": "string", "description": "Exact text to find and replace"},
                    "new_string": {"type": "string", "description": "Replacement text"},
                },
                "required": ["path", "old_string", "new_string"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_directory",
            "description": "List files and folders in a directory with sizes.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Relative directory path (default: repo root)"},
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_command",
            "description": "Run a shell command (pytest, mypy, ruff, npm, pip, make, etc). "
            "Destructive commands blocked. Use cwd to run in a different directory.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "The shell command to run"},
                    "timeout": {"type": "integer", "description": "Timeout in seconds (default 120, max 600)"},
                    "cwd": {"type": "string", "description": "Working directory (optional, for external projects)"},
                },
                "required": ["command"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "search_code",
            "description": "Search the codebase index for a text pattern.",
            "parameters": {
                "type": "object",
                "properties": {
                    "pattern": {"type": "string", "description": "Search string"},
                    "file_glob": {"type": "string", "description": "Optional file pattern like *.py"},
                },
                "required": ["pattern"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "find_symbols",
            "description": "Find function/class/variable definitions by name.",
            "parameters": {
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "Symbol name to search for"},
                    "kind": {
                        "type": "string",
                        "description": "Optional: function, class, variable, constant, interface",
                    },
                },
                "required": ["name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_project_overview",
            "description": "Get a high-level overview of the project structure, key files, and architecture.",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "grep_codebase",
            "description": "Recursive grep across entire codebase with optional regex.",
            "parameters": {
                "type": "object",
                "properties": {
                    "pattern": {"type": "string", "description": "Search pattern"},
                    "file_glob": {"type": "string", "description": "Optional file pattern"},
                    "is_regex": {"type": "boolean", "description": "Whether pattern is regex (default false)"},
                },
                "required": ["pattern"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "verify_changes",
            "description": "Run project test suite and syntax checks. Auto-detects if no command given. "
            "Set include_lint=true only when the user asks for linting.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "Optional specific command to run"},
                    "include_lint": {"type": "boolean", "description": "Include linters (ruff, mypy) in checks. Default false."},
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "batch_edit",
            "description": "Make multiple edits across files at once.",
            "parameters": {
                "type": "object",
                "properties": {
                    "edits": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "path": {"type": "string"},
                                "old_string": {"type": "string"},
                                "new_string": {"type": "string"},
                            },
                            "required": ["path", "old_string", "new_string"],
                        },
                        "description": "List of edits to apply",
                    },
                },
                "required": ["edits"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "edit_lines",
            "description": "Replace lines by line number range. Use when you know exact line numbers from read_file.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Relative path to the file"},
                    "start_line": {"type": "integer", "description": "Start line number (1-based, inclusive)"},
                    "end_line": {"type": "integer", "description": "End line number (1-based, inclusive)"},
                    "new_content": {"type": "string", "description": "Replacement content for those lines"},
                },
                "required": ["path", "start_line", "end_line", "new_content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "apply_diff",
            "description": "Apply a unified diff to a file. Use standard unified diff format.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Relative path to the file"},
                    "diff": {"type": "string", "description": "Unified diff content"},
                },
                "required": ["path", "diff"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "create_directory",
            "description": "Create a directory (and parents). Supports paths outside repo for new projects.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Path to directory (relative or ../outside)"},
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "create_project",
            "description": "Create an entire project with multiple files at once. "
            "Use for scaffolding new applications outside the repo.",
            "parameters": {
                "type": "object",
                "properties": {
                    "base_path": {
                        "type": "string",
                        "description": "Base directory for the project (e.g., '../my_app')",
                    },
                    "files": {
                        "type": "object",
                        "description": "Map of relative file paths to their content",
                        "additionalProperties": {"type": "string"},
                    },
                },
                "required": ["base_path", "files"],
            },
        },
    },
]

# Lean tool set for fast-action prompts (run command, read/edit/write files).
# Sending fewer schemas drastically reduces prompt-processing time in Ollama.
TOOL_SCHEMAS_FAST = [
    s for s in TOOL_SCHEMAS
    if s["function"]["name"] in {
        "run_command", "read_file", "edit_file", "write_file", "batch_edit",
        "edit_lines", "apply_diff", "list_directory", "create_directory",
        "create_project",
    }
]


# ── Robust JSON cleaning ──────────────────────────────────────────────────

def _clean_json_string(raw: str) -> str:
    """Best-effort cleanup of malformed JSON from local models.

    Handles: trailing commas, single quotes used as string delimiters,
    // comments, unquoted keys, missing closing braces, and Python-style
    triple-quoted strings.
    """
    s = raw.strip()

    # Convert Python triple-quoted strings (""" or ''') to JSON strings.
    # Models sometimes output: "new_content": """some\ncontent"""
    def _triple_to_json(m: _re.Match) -> str:
        inner = m.group(1)
        # Escape embedded double quotes and newlines for valid JSON
        escaped = (
            inner.replace('\\', '\\\\')
            .replace('"', '\\"')
            .replace('\n', '\\n')
            .replace('\r', '\\r')
            .replace('\t', '\\t')
        )
        return f'"{escaped}"'

    s = _re.sub(r'"""(.*?)"""', _triple_to_json, s, flags=_re.DOTALL)
    s = _re.sub(r"'''(.*?)'''", _triple_to_json, s, flags=_re.DOTALL)

    # Remove // and # line comments (but not inside strings — heuristic)
    s = _re.sub(r'(?m)^\s*//.*$', '', s)
    s = _re.sub(r'(?m)^\s*#.*$', '', s)

    # Remove trailing commas before } or ]
    s = _re.sub(r',\s*([}\]])', r'\1', s)

    # Replace single-quoted strings with double-quoted (crude but effective)
    # Only do this if there are no double-quoted strings (avoid mixing)
    if "'" in s and '"' not in s:
        s = s.replace("'", '"')

    # Try to fix unquoted keys: word: -> "word":
    s = _re.sub(r'(?<=[\{,\n])\s*(\w+)\s*:', r' "\1":', s)

    # Balance braces — append missing closing braces
    open_count = s.count('{') - s.count('}')
    if open_count > 0:
        s += '}' * open_count
    open_count = s.count('[') - s.count(']')
    if open_count > 0:
        s += ']' * open_count

    return s.strip()


def _try_parse_json(raw: str) -> Any | None:
    """Try parsing JSON with fallback to cleaned JSON."""
    # First try raw
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        pass

    # Try cleaning it up
    cleaned = _clean_json_string(raw)
    try:
        return json.loads(cleaned)
    except (json.JSONDecodeError, ValueError):
        pass

    return None


# ── Multiple tool call extraction ─────────────────────────────────────────

def extract_all_tool_calls(text: str) -> tuple[str, list[dict[str, Any]]]:
    """Extract ALL tool calls from a response.

    Returns ``(text_without_tools, [tool_dicts])``.
    """
    start_tag = "<tool_call>"
    end_tag = "</tool_call>"

    tools: list[dict[str, Any]] = []
    clean_parts: list[str] = []
    remaining = text

    while True:
        idx = remaining.find(start_tag)
        if idx == -1:
            clean_parts.append(remaining)
            break

        clean_parts.append(remaining[:idx])
        end_idx = remaining.find(end_tag, idx)
        if end_idx == -1:
            # No closing tag — try to parse everything after start_tag
            json_str = remaining[idx + len(start_tag):].strip()
            parsed = _try_parse_json(json_str)
            if isinstance(parsed, dict):
                tc = _normalize_tool_call(parsed)
                if tc is not None:
                    tools.append(tc)
            clean_parts.append(remaining[idx:])
            break

        json_str = remaining[idx + len(start_tag):end_idx].strip()
        parsed = _try_parse_json(json_str)
        if isinstance(parsed, dict):
            tc = _normalize_tool_call(parsed)
            if tc is not None:
                tools.append(tc)

        remaining = remaining[end_idx + len(end_tag):]

    clean_text = "".join(clean_parts).strip()
    return clean_text, tools


def _normalize_tool_call(obj: Any) -> dict[str, Any] | None:
    """Normalize any tool call format to internal ``{tool, args}`` shape.

    Supports:
    - ``{"tool": "name", "args": {...}}`` (internal)
    - ``{"name": "name", "arguments": {...}}`` (OpenAI)
    - ``{"function": {"name": "name", "arguments": {...}}}`` (Anthropic)
    - ``{"tool_name": "name", "parameters": {...}}`` (misc)
    - ``{"name": "batch_edit", "arguments": [...]}`` (list args → auto-wrap)
    """
    if not isinstance(obj, dict):
        return None

    def _coerce_args(tool_name: str, args: Any) -> dict[str, Any] | None:
        """Coerce args to dict, handling common model mistakes."""
        if isinstance(args, str):
            args = _try_parse_json(args) or {}
        if isinstance(args, dict):
            return args
        # Model sometimes passes a list directly for batch_edit
        if isinstance(args, list) and tool_name in ("batch_edit",):
            return {"edits": args}
        # For edit_file, model sometimes passes [old_string, new_string]
        if isinstance(args, list):
            return None
        return None

    # Already normalized
    if "tool" in obj and isinstance(obj.get("tool"), str):
        tool_name = obj["tool"]
        args = obj.get("args", obj.get("arguments", obj.get("parameters", {})))
        result = _coerce_args(tool_name, args)
        if result is not None:
            return {"tool": tool_name, "args": result}

    # OpenAI-style: {"name": "tool", "arguments": {...}}
    if "name" in obj and isinstance(obj.get("name"), str):
        tool_name = obj["name"]
        args = obj.get("arguments", obj.get("args", obj.get("parameters", {})))
        result = _coerce_args(tool_name, args)
        if result is not None:
            return {"tool": tool_name, "args": result}

    # Anthropic/nested: {"function": {"name": "tool", "arguments": {...}}}
    func = obj.get("function")
    if isinstance(func, dict) and "name" in func:
        tool_name = func["name"]
        args = func.get("arguments", func.get("args", func.get("parameters", {})))
        result = _coerce_args(tool_name, args)
        if result is not None:
            return {"tool": tool_name, "args": result}

    # Misc: {"tool_name": "...", "parameters": {...}}
    if "tool_name" in obj and isinstance(obj.get("tool_name"), str):
        tool_name = obj["tool_name"]
        args = obj.get("parameters", obj.get("args", obj.get("arguments", {})))
        result = _coerce_args(tool_name, args)
        if result is not None:
            return {"tool": tool_name, "args": result}

    return None


def extract_json_tool_calls(text: str) -> tuple[str, list[dict[str, Any]]]:
    """Extract JSON-style tool calls from model output.

    Supports plain-text function-call objects often emitted by local models,
    for example::

        {"name": "verify_changes", "arguments": {"command": "mypy ."}}

    Returns ``(clean_text, [tool_dicts])`` where each tool dict matches the
    internal shape ``{"tool": name, "args": {...}}``.
    """

    tools: list[dict[str, Any]] = []
    clean_text = text

    # First, inspect fenced JSON blocks.
    block_pattern = _re.compile(r"```(?:json)?\s*(\{[\s\S]*?\}|\[[\s\S]*?\])\s*```", _re.IGNORECASE)
    for match in block_pattern.finditer(text):
        candidate = match.group(1).strip()
        parsed = _try_parse_json(candidate)
        if parsed is None:
            continue

        if isinstance(parsed, list):
            for item in parsed:
                tc = _normalize_tool_call(item)
                if tc is not None:
                    tools.append(tc)
        else:
            tc = _normalize_tool_call(parsed)
            if tc is not None:
                tools.append(tc)

        clean_text = clean_text.replace(match.group(0), "").strip()

    # If nothing found, try parsing the whole response as one JSON object/list.
    if not tools:
        candidate = text.strip()
        if candidate.startswith("{") or candidate.startswith("["):
            parsed = _try_parse_json(candidate)
            if parsed is not None:
                if isinstance(parsed, list):
                    for item in parsed:
                        tc = _normalize_tool_call(item)
                        if tc is not None:
                            tools.append(tc)
                else:
                    tc = _normalize_tool_call(parsed)
                    if tc is not None:
                        tools.append(tc)
                if tools:
                    clean_text = ""

    # Last resort: find balanced JSON objects in the text using brace matching
    if not tools:
        for json_str in _extract_balanced_json(text):
            parsed = _try_parse_json(json_str)
            if parsed is not None:
                tc = _normalize_tool_call(parsed)
                if tc is not None:
                    tools.append(tc)
                    clean_text = clean_text.replace(json_str, "").strip()

    return clean_text, tools


def _extract_balanced_json(text: str) -> list[str]:
    """Extract balanced JSON objects from text using brace counting.

    Finds top-level { ... } blocks that contain tool-call keys and
    returns them as strings for JSON parsing.
    """
    results: list[str] = []
    _tool_keys = ('"tool"', '"name"', '"function"', '"tool_name"')

    i = 0
    while i < len(text):
        if text[i] == '{':
            # Try to find the matching closing brace
            depth = 0
            in_string = False
            escape_next = False
            start = i

            for j in range(i, len(text)):
                ch = text[j]
                if escape_next:
                    escape_next = False
                    continue
                if ch == '\\' and in_string:
                    escape_next = True
                    continue
                if ch == '"' and not escape_next:
                    in_string = not in_string
                    continue
                if in_string:
                    continue
                if ch == '{':
                    depth += 1
                elif ch == '}':
                    depth -= 1
                    if depth == 0:
                        candidate = text[start:j + 1]
                        # Only consider if it looks like a tool call
                        if any(key in candidate for key in _tool_keys):
                            results.append(candidate)
                        i = j + 1
                        break
            else:
                # Unbalanced — skip this opening brace
                i += 1
        else:
            i += 1

    return results


# ── Tool call validation ──────────────────────────────────────────────────

# Required args for each tool
_TOOL_REQUIRED_ARGS: dict[str, list[str]] = {
    "read_file": ["path"],
    "write_file": ["path", "content"],
    "edit_file": ["path", "old_string", "new_string"],
    "edit_lines": ["path", "start_line", "end_line", "new_content"],
    "apply_diff": ["path", "diff"],
    "list_directory": [],
    "run_command": ["command"],
    "search_code": ["pattern"],
    "find_symbols": ["name"],
    "get_project_overview": [],
    "grep_codebase": ["pattern"],
    "verify_changes": [],
    "batch_edit": ["edits"],
    "create_directory": ["path"],
    "create_project": ["base_path", "files"],
}


def validate_tool_call(tool_call: dict[str, Any]) -> str | None:
    """Validate a tool call dict. Returns error message or None if valid."""
    tool_name = tool_call.get("tool", "")
    args = tool_call.get("args", {})

    if tool_name not in _TOOL_REQUIRED_ARGS:
        from difflib import get_close_matches
        valid = list(_TOOL_REQUIRED_ARGS.keys())
        close = get_close_matches(tool_name, valid, n=2, cutoff=0.5)
        suggestion = f" Did you mean: {', '.join(close)}?" if close else ""
        return f"Unknown tool '{tool_name}'.{suggestion} Valid tools: {', '.join(valid)}"

    required = _TOOL_REQUIRED_ARGS[tool_name]
    missing = [arg for arg in required if arg not in args]
    if missing:
        return (
            f"Tool '{tool_name}' missing required args: {', '.join(missing)}. "
            f"Required: {', '.join(required)}"
        )

    return None


# ── Tool call hashing for loop detection ──────────────────────────────────

def hash_tool_call(tool_name: str, args: dict[str, Any]) -> str:
    """Create a deterministic hash of a tool call for deduplication."""
    key = json.dumps({"tool": tool_name, "args": args}, sort_keys=True, default=str)
    return hashlib.md5(key.encode()).hexdigest()[:12]


# ── Tool executor ────────────────────────────────────────────────────────

class ToolExecutor:
    """Executes tool calls requested by the LLM within a repo sandbox."""

    def __init__(self, repo_path: Path) -> None:
        self.repo_path = repo_path.resolve()
        self.focus_paths: list[str] = []

    def _matches_focus(self, rel_path: str) -> bool:
        """Return True if *rel_path* falls within the current focus scope."""
        if not self.focus_paths:
            return True
        normalised = rel_path.replace("\\", "/").strip("/")
        for fp in self.focus_paths:
            fp_clean = fp.replace("\\", "/").strip("/")
            if normalised == fp_clean or normalised.startswith(fp_clean.rstrip("/") + "/"):
                return True
        return False

    # -- public API --------------------------------------------------------

    def extract_tool_call(self, text: str) -> tuple[str, dict[str, Any] | None]:
        """Extract a tool call from the LLM response text.

        Returns ``(text_before_tool, tool_dict)`` or ``(full_text, None)``
        if no tool call is found.
        """
        start_tag = "<tool_call>"
        end_tag = "</tool_call>"

        idx = text.find(start_tag)
        if idx == -1:
            return text, None

        end_idx = text.find(end_tag, idx)
        if end_idx == -1:
            return text, None

        before = text[:idx]
        json_str = text[idx + len(start_tag):end_idx].strip()

        try:
            tool_data = json.loads(json_str)
            if isinstance(tool_data, dict) and "tool" in tool_data:
                return before, tool_data
        except json.JSONDecodeError:
            pass

        return text, None

    def execute(self, tool_name: str, args: dict[str, Any]) -> str:
        """Dispatch and run a tool, returning the result as a string."""
        dispatch = {
            "read_file": self._read_file,
            "write_file": self._write_file,
            "edit_file": self._edit_file,
            "edit_lines": self._edit_lines,
            "apply_diff": self._apply_diff,
            "list_directory": self._list_directory,
            "run_command": self._run_command,
            "search_code": self._search_code,
            "find_symbols": self._find_symbols,
            "get_project_overview": self._get_project_overview,
            "grep_codebase": self._grep_codebase,
            "verify_changes": self._verify_changes,
            "batch_edit": self._batch_edit,
            "create_directory": self._create_directory,
            "create_project": self._create_project,
        }

        handler = dispatch.get(tool_name)
        if handler is None:
            # Suggest closest match
            from difflib import get_close_matches
            close = get_close_matches(tool_name, list(dispatch.keys()), n=2, cutoff=0.5)
            suggestion = f" Did you mean: {', '.join(close)}?" if close else ""
            return f"Error: Unknown tool '{tool_name}'.{suggestion}"

        try:
            return handler(args)
        except Exception as exc:
            return f"Error: {exc}"

    # -- tool implementations ----------------------------------------------

    def _resolve_path(self, rel_path: str) -> Path:
        """Resolve a relative path safely within or near the repo.

        Allows paths within the repo and in nearby sibling directories
        (for reading/editing files in externally-created projects).
        If the exact path doesn't exist, tries stripping common prefixes
        (src/, lib/, app/) that models often hallucinate.
        """
        target = (self.repo_path / rel_path).resolve()

        # Allow paths within the repo
        if target.is_relative_to(self.repo_path):
            if target.exists():
                return target
            # Fall through to prefix stripping / filename search below
        else:
            # Allow paths in sibling directories (parent's children) and
            # grandparent's children — needed for reading/editing files in
            # externally-created projects (e.g., ../taskmaster_app/main.py)
            repo_parent = self.repo_path.parent
            repo_grandparent = repo_parent.parent
            if target.is_relative_to(repo_parent) or target.is_relative_to(repo_grandparent):
                if target.exists():
                    return target
                # External path that doesn't exist — return directly so caller
                # gets a clear "File not found" error instead of ValueError
                return target
            raise ValueError(f"Path traversal blocked: {rel_path!r}")

        # If file exists, return it directly
        if target.exists():
            return target

        # Try stripping common hallucinated prefixes
        stripped = rel_path
        common_prefixes = ("src/", "lib/", "app/", "source/", "code/", "./")
        for prefix in common_prefixes:
            if stripped.lower().startswith(prefix):
                stripped = stripped[len(prefix):]
                candidate = (self.repo_path / stripped).resolve()
                if candidate.is_relative_to(self.repo_path) and candidate.exists():
                    return candidate

        # Try just the filename — but ONLY within project source files,
        # never in .venv, site-packages, node_modules, etc.
        filename = Path(rel_path).name
        _skip_dirs = {
            ".git", ".venv", "venv", "env", ".env",
            "node_modules", "__pycache__", ".mypy_cache", ".pytest_cache",
            "dist", "build", ".tox", ".nox", ".eggs",
            "site-packages", ".localforge",
        }
        candidates: list[Path] = []
        for dirpath, dirnames, filenames in os.walk(self.repo_path):
            # Prune directories we should never search
            dirnames[:] = [
                d for d in dirnames
                if d not in _skip_dirs and not d.startswith(".")
            ]
            if filename in filenames:
                candidate = (Path(dirpath) / filename).resolve()
                if candidate.is_relative_to(self.repo_path):
                    candidates.append(candidate)
        if len(candidates) == 1:
            return candidates[0]

        return target  # Return original (will fail with "not found")

    def _read_file(self, args: dict[str, Any]) -> str:
        path = self._resolve_path(args.get("path", ""))
        if not path.is_file():
            suggestion = self._suggest_path(args.get("path", ""))
            req_path = args.get("path", "")
            # Extract the stem (e.g., "validation" from "src/validation.py")
            # to help the model search for the right thing
            stem = Path(req_path).stem if req_path else ""
            search_hint = ""
            if stem and stem not in ("__init__",):
                search_hint = (
                    f' Try: search_code with pattern "{stem}" to find where '
                    f"this code actually lives."
                )
            return (
                f"Error: File not found: {req_path}{suggestion}\n"
                f"This file does NOT exist in this project.{search_hint}\n"
                "Look at the test file imports or pytest error tracebacks for correct paths."
            )

        text = path.read_text(encoding="utf-8", errors="replace")
        # Strip UTF-8 BOM so the model never sees it
        if text.startswith("\ufeff"):
            text = text[1:]
        all_lines = text.splitlines(keepends=True)
        total_lines = len(all_lines)

        start = args.get("start_line")
        end = args.get("end_line")
        if start is not None or end is not None:
            s = max(0, (int(start) - 1)) if start else 0
            e = int(end) if end else total_lines
            # Detect out-of-range requests
            if s >= total_lines:
                return (
                    f"Error: start_line {s + 1} exceeds file length ({total_lines} lines). "
                    f"Use start_line between 1 and {total_lines}."
                )
            e = min(e, total_lines)
            lines = all_lines[s:e]
            line_offset = s  # 0-based offset for numbering
        else:
            lines = all_lines
            line_offset = 0

        # Add line numbers so the LLM knows exact positions for edit_lines
        numbered_lines = []
        for i, line in enumerate(lines):
            line_num = line_offset + i + 1  # 1-based
            # Strip the keepend newline for clean formatting, re-add after
            numbered_lines.append(f"L{line_num}: {line}")
        content = "".join(numbered_lines)

        if len(content) > _MAX_OUTPUT:
            content = content[:_MAX_OUTPUT] + (
                f"\n... (truncated — file has {total_lines} total lines)\n"
                "WARNING: This file was truncated. Do NOT copy truncated text into edit_file old_string. "
                "Use edit_lines with start_line/end_line instead, or read_file with start_line/end_line to get exact content."
            )

        # Add a header with file metadata
        rel = args.get("path", "")
        if start is not None or end is not None:
            header = f"[{rel} — lines {line_offset + 1}-{line_offset + len(lines)} of {total_lines}]\n"
        else:
            header = f"[{rel} — {total_lines} lines]\n"
        return header + content

    def _write_file(self, args: dict[str, Any]) -> str:
        rel = args.get("path", "")
        content = args.get("content", "")

        # Try repo-internal path first, then external path for project scaffolding
        try:
            path = self._resolve_path(rel)
        except ValueError:
            # Path traversal outside repo — try external resolution for scaffolding
            try:
                path = self._resolve_external_path(rel)
            except ValueError as e:
                return f"Error: {e}"

        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return f"Successfully wrote {len(content)} bytes to {rel}"

    def _edit_file(self, args: dict[str, Any]) -> str:
        rel = args.get("path", "")
        path = self._resolve_path(rel)
        if not path.is_file():
            suggestion = self._suggest_path(rel)
            return f"Error: File not found: {rel}{suggestion}"

        old_string = args.get("old_string", "")
        new_string = args.get("new_string", "")
        if not old_string:
            return "Error: old_string is required"

        # Strip line-number prefixes (L123: ) that the LLM may copy from read_file output
        import re as _re_mod
        _line_prefix_re = _re_mod.compile(r"^L\d+: ", _re_mod.MULTILINE)
        if _line_prefix_re.search(old_string):
            old_string = _line_prefix_re.sub("", old_string)
            new_string = _line_prefix_re.sub("", new_string)

        # Detect truncated text being used as old_string
        _truncation_markers = ("... (truncated)", "characters omitted)", "[truncated]")
        if any(marker in old_string for marker in _truncation_markers):
            return (
                "Error: old_string contains truncated text — this will NEVER match the file. "
                "The file content was truncated when you read it. "
                "Use edit_lines with start_line and end_line instead, "
                "or re-read the file with start_line/end_line to get the exact text you need."
            )

        # Phase 1: No-op detection — reject edits where old == new
        if old_string == new_string:
            return "Error: old_string and new_string are identical (no-op edit). Skipping."

        text = path.read_text(encoding="utf-8")

        # Strip UTF-8 BOM if present — models never include it in old_string
        if text.startswith("\ufeff"):
            text = text[1:]
            # Rewrite without BOM immediately so future reads are clean
            path.write_text(text, encoding="utf-8")

        # Phase 3: Try exact match first
        count = text.count(old_string)
        if count == 1:
            new_text = text.replace(old_string, new_string, 1)
            # Phase 7: Syntax validation for Python files
            syntax_err = self._validate_syntax_if_python(path, new_text)
            if syntax_err:
                return f"Error: Edit would create a syntax error: {syntax_err}. Edit reverted."
            path.write_text(new_text, encoding="utf-8")
            return f"Successfully edited {rel}"

        if count > 1:
            # Auto-provide context so model doesn't need another round trip
            context_info = self._get_match_context(text, old_string, max_matches=3)
            return (
                f"Error: old_string matches {count} locations — be more specific. "
                f"Include more surrounding lines to disambiguate.\n{context_info}"
            )

        # Phase 3: Exact match failed — try whitespace-normalized match
        normalized_text = self._normalize_whitespace(text)
        normalized_old = self._normalize_whitespace(old_string)
        if normalized_old and normalized_text.count(normalized_old) == 1:
            # Find actual position in original text via line-by-line matching
            result = self._apply_normalized_edit(text, old_string, new_string)
            if result is not None:
                syntax_err = self._validate_syntax_if_python(path, result)
                if syntax_err:
                    return f"Error: Edit would create a syntax error: {syntax_err}. Edit reverted."
                path.write_text(result, encoding="utf-8")
                return f"Successfully edited {rel} (whitespace-normalized match)"

        # Phase 3: Try fuzzy matching as last resort
        match_result = self._fuzzy_find(text, old_string)
        if match_result is not None:
            start, end, ratio = match_result
            new_text = text[:start] + new_string + text[end:]
            syntax_err = self._validate_syntax_if_python(path, new_text)
            if syntax_err:
                return f"Error: Edit would create a syntax error: {syntax_err}. Edit reverted."
            path.write_text(new_text, encoding="utf-8")
            return f"Successfully edited {rel} (fuzzy match, {ratio:.0%} confidence)"

        # All match strategies failed — provide helpful context
        context = self._get_nearby_context(text, old_string)
        return (
            f"Error: old_string not found in file (exact, normalized, and fuzzy match all failed). "
            f"HINT: Use edit_lines with start_line/end_line instead — "
            f"read_file first to find the correct line numbers.\n{context}"
        )

    def _fuzzy_find(
        self, text: str, search: str,
    ) -> tuple[int, int, float] | None:
        """Find the best fuzzy match for *search* in *text*.

        Returns ``(start, end, ratio)`` or ``None`` if no match above threshold.
        Uses line-level difflib matching for efficiency.
        """
        search_lines = search.splitlines(keepends=True)
        text_lines = text.splitlines(keepends=True)

        if not search_lines or not text_lines:
            return None

        search_len = len(search_lines)
        best_ratio = 0.0
        best_start_line = 0

        # Sliding window over text lines
        window_min = max(1, search_len - max(3, search_len // 5))
        window_max = search_len + max(3, search_len // 5)

        for win_size in range(search_len, window_max + 1):
            for i in range(len(text_lines) - win_size + 1):
                candidate = text_lines[i:i + win_size]
                ratio = difflib.SequenceMatcher(
                    None, search_lines, candidate,
                ).ratio()
                if ratio > best_ratio:
                    best_ratio = ratio
                    best_start_line = i
                    best_win_size = win_size
                    if ratio > 0.98:  # Close enough, stop early
                        break
            if best_ratio > 0.98:
                break

        # Also try smaller windows
        for win_size in range(window_min, search_len):
            for i in range(len(text_lines) - win_size + 1):
                candidate = text_lines[i:i + win_size]
                ratio = difflib.SequenceMatcher(
                    None, search_lines, candidate,
                ).ratio()
                if ratio > best_ratio:
                    best_ratio = ratio
                    best_start_line = i
                    best_win_size = win_size

        if best_ratio < _FUZZY_MATCH_THRESHOLD:
            return None

        # Convert line range to character offsets
        start = sum(len(ln) for ln in text_lines[:best_start_line])
        end = sum(len(ln) for ln in text_lines[:best_start_line + best_win_size])
        return start, end, best_ratio

    @staticmethod
    def _normalize_whitespace(text: str) -> str:
        """Normalize whitespace for matching: tabs→spaces, strip trailing."""
        lines = text.splitlines()
        return "\n".join(line.expandtabs(4).rstrip() for line in lines)

    def _apply_normalized_edit(
        self, text: str, old_string: str, new_string: str,
    ) -> str | None:
        """Apply edit using whitespace-normalized matching."""
        norm_text_lines = self._normalize_whitespace(text).splitlines()
        norm_old_lines = self._normalize_whitespace(old_string).splitlines()

        if not norm_old_lines:
            return None

        # Find where normalized old_string starts in normalized text
        target = "\n".join(norm_old_lines)
        full_norm = "\n".join(norm_text_lines)

        idx = full_norm.find(target)
        if idx == -1:
            return None

        # Find the line number range
        start_line = full_norm[:idx].count("\n")
        end_line = start_line + len(norm_old_lines)

        # Replace in original text
        original_lines = text.splitlines(keepends=True)
        before = original_lines[:start_line]
        after = original_lines[end_line:]

        # Ensure new_string ends with newline if replacing whole lines
        replacement = new_string
        if not replacement.endswith("\n") and after:
            replacement += "\n"

        return "".join(before) + replacement + "".join(after)

    @staticmethod
    def _validate_syntax_if_python(path: Path, content: str) -> str | None:
        """Validate syntax for any supported language. Returns error string or None."""
        return ToolExecutor._validate_syntax(path, content)

    @staticmethod
    def _validate_syntax(path: Path, content: str) -> str | None:
        """Language-agnostic syntax validation.

        Supports Python (ast.parse), JSON, YAML, and external validators
        for JavaScript/TypeScript, Go, Rust, Java, C/C++, Ruby, etc.
        """
        suffix = path.suffix.lower()

        # ── Python ───────────────────────────────────────────────
        if suffix == ".py":
            try:
                ast.parse(content, filename=str(path))
                return None
            except SyntaxError as e:
                hint = ""
                msg = e.msg or ""
                if "expected an indented block" in msg:
                    hint = (
                        " Hint: you removed the only statement in a block (for/if/def/class). "
                        "Include the ENTIRE block (for-loop, function, etc.) in old_string "
                        "and rewrite it completely in new_string, or use `pass` as a placeholder."
                    )
                elif "unexpected indent" in msg:
                    hint = " Hint: check indentation in new_string matches the surrounding code."
                return f"line {e.lineno}: {msg}.{hint}"

        # ── JSON ─────────────────────────────────────────────────
        if suffix == ".json":
            try:
                json.loads(content)
                return None
            except json.JSONDecodeError as e:
                return f"JSON syntax error at line {e.lineno}: {e.msg}"

        # ── YAML ─────────────────────────────────────────────────
        if suffix in (".yaml", ".yml"):
            try:
                import yaml
                yaml.safe_load(content)
                return None
            except Exception as e:
                return f"YAML syntax error: {e}"

        # ── JavaScript / TypeScript (Node.js --check) ────────────
        if suffix in (".js", ".mjs", ".cjs"):
            return ToolExecutor._validate_with_external(
                content, path, ["node", "--check"], "JavaScript"
            )
        if suffix in (".ts", ".tsx", ".mts"):
            # Try npx tsc --noEmit for TypeScript
            return ToolExecutor._validate_with_external(
                content, path, ["npx", "tsc", "--noEmit", "--allowJs"], "TypeScript"
            )

        # ── Go ───────────────────────────────────────────────────
        if suffix == ".go":
            return ToolExecutor._validate_with_external(
                content, path, ["gofmt", "-e"], "Go"
            )

        # ── Rust ─────────────────────────────────────────────────
        if suffix == ".rs":
            # Basic brace/bracket balance check for Rust
            return ToolExecutor._validate_brace_balance(content, "Rust")

        # ── Java ─────────────────────────────────────────────────
        if suffix == ".java":
            return ToolExecutor._validate_brace_balance(content, "Java")

        # ── C / C++ ──────────────────────────────────────────────
        if suffix in (".c", ".h", ".cpp", ".hpp", ".cc", ".cxx"):
            return ToolExecutor._validate_brace_balance(content, "C/C++")

        # ── Ruby ─────────────────────────────────────────────────
        if suffix == ".rb":
            return ToolExecutor._validate_with_external(
                content, path, ["ruby", "-c"], "Ruby"
            )

        # ── PHP ──────────────────────────────────────────────────
        if suffix == ".php":
            return ToolExecutor._validate_with_external(
                content, path, ["php", "-l"], "PHP"
            )

        # ── Kotlin ───────────────────────────────────────────────
        if suffix in (".kt", ".kts"):
            return ToolExecutor._validate_brace_balance(content, "Kotlin")

        # ── Swift ────────────────────────────────────────────────
        if suffix == ".swift":
            return ToolExecutor._validate_brace_balance(content, "Swift")

        # ── XML / HTML ───────────────────────────────────────────
        if suffix in (".xml", ".html", ".htm", ".xhtml", ".svg"):
            return ToolExecutor._validate_xml_basic(content)

        # ── CSS / SCSS ───────────────────────────────────────────
        if suffix in (".css", ".scss", ".less"):
            return ToolExecutor._validate_brace_balance(content, "CSS")

        # No validator for this file type — allow the edit
        return None

    @staticmethod
    def _validate_with_external(
        content: str, path: Path, cmd_prefix: list[str], lang: str,
    ) -> str | None:
        """Try to validate syntax using an external tool.

        Writes content to a temp file, runs the validator, returns error or None.
        Falls back to brace-balance check if the tool isn't available.
        """
        import shutil
        import tempfile

        if not shutil.which(cmd_prefix[0]):
            # Tool not available — fall back to basic structural check
            return ToolExecutor._validate_brace_balance(content, lang)

        try:
            with tempfile.NamedTemporaryFile(
                mode="w", suffix=path.suffix, delete=False, encoding="utf-8",
            ) as tmp:
                tmp.write(content)
                tmp_path = tmp.name

            result = subprocess.run(
                cmd_prefix + [tmp_path],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode != 0:
                err = (result.stderr or result.stdout or "").strip()
                # Take first 200 chars of error
                return f"{lang} syntax error: {err[:200]}"
            return None
        except (subprocess.TimeoutExpired, OSError):
            return None  # Can't validate — allow the edit
        finally:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass

    @staticmethod
    def _validate_brace_balance(content: str, lang: str) -> str | None:
        """Check that braces, brackets, and parens are balanced.

        This is a fast structural check for compiled languages where we
        can't easily run a syntax checker.
        """
        stack: list[tuple[str, int]] = []
        openers = {"(": ")", "[": "]", "{": "}"}
        closers = {")": "(", "]": "[", "}": "{"}
        in_string = False
        string_char = ""
        escape_next = False
        in_line_comment = False
        in_block_comment = False
        line_num = 1

        for i, ch in enumerate(content):
            if ch == "\n":
                line_num += 1
                in_line_comment = False
                continue

            if escape_next:
                escape_next = False
                continue

            if in_block_comment:
                if ch == "*" and i + 1 < len(content) and content[i + 1] == "/":
                    in_block_comment = False
                continue

            if in_line_comment:
                continue

            if in_string:
                if ch == "\\":
                    escape_next = True
                elif ch == string_char:
                    in_string = False
                continue

            # Detect comments
            if ch == "/" and i + 1 < len(content):
                next_ch = content[i + 1]
                if next_ch == "/":
                    in_line_comment = True
                    continue
                elif next_ch == "*":
                    in_block_comment = True
                    continue

            # Detect strings
            if ch in ('"', "'", "`"):
                in_string = True
                string_char = ch
                continue

            if ch in openers:
                stack.append((ch, line_num))
            elif ch in closers:
                if not stack:
                    return f"{lang} syntax error: unexpected '{ch}' at line {line_num}"
                top, _ = stack[-1]
                if closers[ch] != top:
                    return (
                        f"{lang} syntax error: mismatched '{ch}' at line {line_num}, "
                        f"expected closing for '{top}'"
                    )
                stack.pop()

        if stack:
            unclosed = stack[-1]
            return (
                f"{lang} syntax error: unclosed '{unclosed[0]}' "
                f"opened at line {unclosed[1]}"
            )
        return None

    @staticmethod
    def _validate_xml_basic(content: str) -> str | None:
        """Basic XML/HTML well-formedness check."""
        try:
            import xml.etree.ElementTree as ET
            ET.fromstring(content)
            return None
        except ET.ParseError as e:
            return f"XML/HTML syntax error: {e}"
        except Exception:
            return None  # Don't block on parse issues for HTML

    def _suggest_path(self, rel_path: str) -> str:
        """Suggest similar file paths when a file is not found.

        Only suggests when the match is very strong (>0.85) to avoid
        misleading the model.  Weak fuzzy matches like 'hashing.py' →
        'ranking.py' cause the model to waste rounds reading wrong files.
        """
        if not rel_path:
            return ""
        target_name = Path(rel_path).name.lower()
        candidates: list[str] = []
        _skip = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build", ".localforge"}
        for dirpath, dirnames, filenames in os.walk(self.repo_path):
            dirnames[:] = [d for d in dirnames if d not in _skip and not d.startswith(".")]
            for fname in filenames:
                ratio = difflib.SequenceMatcher(None, target_name, fname.lower()).ratio()
                # Only suggest for very strong matches (exact name, minor typo)
                if ratio > 0.85:
                    try:
                        fp = Path(dirpath) / fname
                        candidates.append(str(fp.relative_to(self.repo_path)))
                    except ValueError:
                        pass
                if len(candidates) >= 5:
                    break
            if len(candidates) >= 5:
                break
        if candidates:
            return "\nDid you mean: " + ", ".join(candidates[:3]) + "?"
        return ""

    def _get_match_context(self, text: str, pattern: str, max_matches: int = 3) -> str:
        """Return context lines around each match location for disambiguation."""
        lines = text.splitlines()
        positions: list[int] = []
        start = 0
        while True:
            idx = text.find(pattern, start)
            if idx == -1 or len(positions) >= max_matches:
                break
            positions.append(idx)
            start = idx + 1

        if not positions:
            return ""

        parts = ["Matches found at:"]
        for pos in positions:
            line_num = text[:pos].count("\n") + 1
            start_l = max(0, line_num - 3)
            end_l = min(len(lines), line_num + 3)
            context_lines = lines[start_l:end_l]
            numbered = [f"  L{start_l + i + 1}: {ln}" for i, ln in enumerate(context_lines)]
            parts.append(f"\n--- Match at line {line_num} ---")
            parts.extend(numbered)

        return "\n".join(parts)

    def _get_nearby_context(self, text: str, search: str) -> str:
        """When edit fails completely, show relevant portions of the file."""
        lines = text.splitlines()
        total = len(lines)
        if total == 0:
            return "File is empty."

        # Try to find the most similar region in the file
        search_lines = search.splitlines()
        if not search_lines:
            return f"File has {total} lines."

        first_search_line = search_lines[0].strip()
        best_line = 0
        best_score = 0.0
        for i, line in enumerate(lines):
            score = difflib.SequenceMatcher(None, first_search_line, line.strip()).ratio()
            if score > best_score:
                best_score = score
                best_line = i

        if best_score < 0.3:
            # Show first/last lines of file as reference
            preview_lines = min(_EDIT_ERROR_CONTEXT_LINES, total)
            sample = lines[:preview_lines]
            numbered = [f"  L{i + 1}: {ln}" for i, ln in enumerate(sample)]
            return f"File has {total} lines. First {preview_lines} lines:\n" + "\n".join(numbered)

        # Show context around best match
        start = max(0, best_line - 5)
        end = min(total, best_line + _EDIT_ERROR_CONTEXT_LINES)
        sample = lines[start:end]
        numbered = [f"  L{start + i + 1}: {ln}" for i, ln in enumerate(sample)]
        return (
            f"Closest matching region (L{start + 1}-{end}, {best_score:.0%} similar to first line):\n"
            + "\n".join(numbered)
        )

    def _edit_lines(self, args: dict[str, Any]) -> str:
        """Replace a range of lines by line number."""
        rel = args.get("path", "")
        path = self._resolve_path(rel)
        if not path.is_file():
            suggestion = self._suggest_path(rel)
            return f"Error: File not found: {rel}{suggestion}"

        start_line = int(args.get("start_line", 0))
        end_line = int(args.get("end_line", 0))
        new_content = args.get("new_content", "")

        if start_line < 1 or end_line < start_line:
            return f"Error: Invalid line range ({start_line}-{end_line}). Lines are 1-based inclusive."

        text = path.read_text(encoding="utf-8")
        # Strip UTF-8 BOM
        if text.startswith("\ufeff"):
            text = text[1:]
        lines = text.splitlines(keepends=True)
        total = len(lines)

        if start_line > total:
            return (
                f"Error: start_line {start_line} exceeds file length ({total} lines). "
                f"Use read_file with start_line/end_line to find the correct line numbers first. "
                f"Valid range: 1-{total}."
            )

        # Clamp end_line to file length
        end_line = min(end_line, total)

        before = lines[:start_line - 1]
        after = lines[end_line:]

        # Ensure new content ends with newline if there's content after
        replacement = new_content
        if replacement and not replacement.endswith("\n") and after:
            replacement += "\n"

        new_text = "".join(before) + replacement + "".join(after)

        # Syntax validation
        syntax_err = self._validate_syntax_if_python(path, new_text)
        if syntax_err:
            return f"Error: Edit would create a syntax error: {syntax_err}. Edit reverted."

        path.write_text(new_text, encoding="utf-8")
        return f"Successfully replaced lines {start_line}-{end_line} in {rel}"

    def _apply_diff(self, args: dict[str, Any]) -> str:
        """Apply a unified diff to a file."""
        rel = args.get("path", "")
        path = self._resolve_path(rel)
        if not path.is_file():
            suggestion = self._suggest_path(rel)
            return f"Error: File not found: {rel}{suggestion}"

        diff_text = args.get("diff", "")
        if not diff_text:
            return "Error: diff content is required"

        text = path.read_text(encoding="utf-8")
        original_lines = text.splitlines(keepends=True)
        # Ensure all lines have line endings for consistent matching
        if original_lines and not original_lines[-1].endswith("\n"):
            original_lines[-1] += "\n"

        try:
            patched_lines = self._apply_unified_diff(original_lines, diff_text)
        except ValueError as e:
            return f"Error: Failed to apply diff: {e}"

        new_text = "".join(patched_lines)
        syntax_err = self._validate_syntax_if_python(path, new_text)
        if syntax_err:
            return f"Error: Diff would create a syntax error: {syntax_err}. Diff not applied."

        path.write_text(new_text, encoding="utf-8")
        return f"Successfully applied diff to {rel}"

    @staticmethod
    def _apply_unified_diff(
        original_lines: list[str], diff_text: str,
    ) -> list[str]:
        """Parse and apply a unified diff to a list of lines.

        This is a simple unified-diff applier that handles basic hunks.
        """
        result = list(original_lines)
        offset = 0  # Track line number shifts from previous hunks

        hunk_header = _re.compile(r'^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@')
        diff_lines = diff_text.splitlines(keepends=True)

        i = 0
        while i < len(diff_lines):
            line = diff_lines[i]
            match = hunk_header.match(line.rstrip())
            if match:
                orig_start = int(match.group(1)) - 1 + offset
                # Collect hunk lines
                i += 1
                removals = 0
                additions: list[str] = []
                hunk_pos = orig_start

                while i < len(diff_lines):
                    hl = diff_lines[i]
                    if hl.startswith("@@") or hl.startswith("---") or hl.startswith("+++"):
                        break
                    if hl.startswith("-"):
                        removals += 1
                        i += 1
                    elif hl.startswith("+"):
                        add_content = hl[1:]
                        if not add_content.endswith("\n"):
                            add_content += "\n"
                        additions.append(add_content)
                        i += 1
                    elif hl.startswith(" ") or hl.startswith("\n") or hl.strip() == "":
                        # Context line — flush pending changes at current position
                        if removals or additions:
                            # Apply the pending change
                            result[hunk_pos:hunk_pos + removals] = additions
                            offset += len(additions) - removals
                            hunk_pos += len(additions)
                            removals = 0
                            additions = []
                        else:
                            hunk_pos += 1
                        i += 1
                    elif hl.startswith("\\"):
                        i += 1  # "\ No newline at end of file"
                    else:
                        break

                # Flush any remaining pending changes
                if removals or additions:
                    result[hunk_pos:hunk_pos + removals] = additions
                    offset += len(additions) - removals
            else:
                i += 1

        return result

    def _list_directory(self, args: dict[str, Any]) -> str:
        rel = args.get("path", ".")
        path = self._resolve_path(rel)
        if not path.is_dir():
            return f"Error: Directory not found: {rel}"

        entries: list[str] = []
        for child in sorted(path.iterdir()):
            if child.name.startswith("."):
                continue
            if child.is_dir():
                entries.append(f"  {child.name}/")
            else:
                try:
                    size = child.stat().st_size
                    if size < 1024:
                        size_str = f"{size}B"
                    elif size < 1024 * 1024:
                        size_str = f"{size // 1024}KB"
                    else:
                        size_str = f"{size // (1024 * 1024)}MB"
                    entries.append(f"  {child.name}  ({size_str})")
                except OSError:
                    entries.append(f"  {child.name}")

        if not entries:
            return "(empty directory)"
        return "\n".join(entries)

    def _run_command(self, args: dict[str, Any]) -> str:
        command = args.get("command", "").strip()
        if not command:
            return "Error: No command provided"

        command = self._normalize_command(command)

        # Support custom working directory (for running commands in external projects)
        cwd = args.get("cwd", "").strip()
        if cwd:
            try:
                cwd_path = self._resolve_external_path(cwd)
                if not cwd_path.is_dir():
                    return f"Error: cwd directory not found: {cwd}"
                work_dir = str(cwd_path)
            except ValueError as e:
                return f"Error: {e}"
        else:
            work_dir = str(self.repo_path)

        # Auto-optimize pytest commands: append --tb=short if no --tb flag
        # is already present.  This reduces output size significantly and
        # saves context tokens for the model in subsequent rounds.
        lower_cmd = command.lower()
        if ("pytest" in lower_cmd or "py.test" in lower_cmd) and "--tb" not in lower_cmd:
            command += " --tb=short"

        timeout = int(args.get("timeout", 120))
        # Clamp timeout to a safe range
        timeout = max(5, min(timeout, 600))

        # Safety check: block destructive commands
        first_token = command.split()[0].lower() if command.split() else ""
        # Strip path prefixes (e.g., /usr/bin/rm → rm)
        first_token = first_token.rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
        if first_token in _BLOCKED_COMMANDS:
            return f"Error: Command '{first_token}' is blocked for safety"

        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=work_dir,
                env=None,  # inherit parent env
            )
        except subprocess.TimeoutExpired:
            return f"Error: Command timed out after {timeout} seconds"

        output_parts: list[str] = []
        if result.stdout:
            output_parts.append(result.stdout)
        if result.stderr:
            output_parts.append(f"STDERR:\n{result.stderr}")
        if result.returncode != 0:
            output_parts.append(f"(exit code: {result.returncode})")

        output = "\n".join(output_parts) if output_parts else "(no output)"

        # Auto-retry: if a Python tool isn't in PATH, try `python -m <tool>`
        if result.returncode != 0 and self._is_tool_not_found(output, command):
            python_m_cmd = self._try_python_m_fallback(command)
            if python_m_cmd:
                try:
                    retry = subprocess.run(
                        python_m_cmd,
                        shell=True,
                        capture_output=True,
                        text=True,
                        timeout=timeout,
                        cwd=work_dir,
                        env=None,
                    )
                    retry_parts: list[str] = [
                        f"(auto-corrected: {python_m_cmd})",
                    ]
                    if retry.stdout:
                        retry_parts.append(retry.stdout)
                    if retry.stderr:
                        retry_parts.append(f"STDERR:\n{retry.stderr}")
                    if retry.returncode != 0:
                        retry_parts.append(f"(exit code: {retry.returncode})")
                    return "\n".join(retry_parts) if retry_parts else "(no output)"
                except subprocess.TimeoutExpired:
                    pass  # Fall through to original output

        # Retry once with corrected Ruff syntax for common model mistakes.
        if result.returncode != 0 and self._looks_like_ruff_usage_error(output):
            corrected = self._normalize_ruff_command(command)
            if corrected != command:
                try:
                    retry = subprocess.run(
                        corrected,
                        shell=True,
                        capture_output=True,
                        text=True,
                        timeout=timeout,
                        cwd=work_dir,
                        env=None,
                    )
                    retry_parts: list[str] = [
                        f"Auto-corrected command: {corrected}",
                    ]
                    if retry.stdout:
                        retry_parts.append(retry.stdout)
                    if retry.stderr:
                        retry_parts.append(f"STDERR:\n{retry.stderr}")
                    if retry.returncode != 0:
                        retry_parts.append(f"(exit code: {retry.returncode})")
                    output = "\n".join(retry_parts)
                except subprocess.TimeoutExpired:
                    output = (
                        output
                        + "\nAuto-corrected Ruff command timed out."
                    )

        if len(output) > _MAX_OUTPUT:
            output = output[:_MAX_OUTPUT] + "\n... (truncated)"

        # Phase 6: Compress large linter/test output to save tokens
        output = self._compress_tool_output(output, command, self.repo_path)

        # Phase 7: Auto-detect common errors and add hints
        output = self._add_error_hints(output, command, work_dir)

        return output

    @staticmethod
    def _add_error_hints(output: str, command: str, work_dir: str) -> str:
        """Append actionable hints for common error patterns."""
        hints: list[str] = []
        lower = output.lower()

        # ModuleNotFoundError → suggest pip install
        if "modulenotfounderror" in lower or "no module named" in lower:
            # Extract module name
            import re as _re_local
            m = _re_local.search(r"no module named ['\"]?(\w+)", lower)
            if m:
                mod = m.group(1)
                hints.append(
                    f"HINT: Module '{mod}' is not installed. "
                    f"Run: pip install {mod} (or check requirements.txt for the correct package name)"
                )

        # npm ERR! → suggest npm install
        if "npm err!" in lower and "missing" in lower:
            hints.append("HINT: Dependencies may not be installed. Run: npm install")

        # Permission denied on Windows
        if "permission denied" in lower or "access is denied" in lower:
            hints.append("HINT: Permission denied. Try running from a different directory or check file locks.")

        # File not found for executables
        if ("is not recognized" in lower or "command not found" in lower) and "python" not in lower:
            hints.append("HINT: Command not found. Check that the tool is installed and in PATH.")

        # ImportError with relative imports → project structure issue
        if "attempted relative import" in lower:
            hints.append(
                "HINT: Relative import error. Make sure __init__.py files exist "
                "and you're running from the correct directory."
            )

        # Common pytest collection errors
        if "collected 0 items" in lower and "error" in lower:
            hints.append(
                "HINT: No tests collected. Check that test files start with 'test_' "
                "and test functions start with 'test_'."
            )

        if hints:
            output += "\n\n" + "\n".join(hints)

        return output

    @staticmethod
    def _compress_pytest_output(output: str, repo_path: Path | None = None, command: str = "") -> str:
        """Compress pytest output to only failure-relevant information.

        Strips passing test lines, keeps only failed test names, short
        tracebacks, and the summary line.  Also extracts source file paths
        mentioned in tracebacks to help the model find the right files.
        This can reduce a ~11K char pytest output to ~2-3K chars.
        """
        lines = output.splitlines()
        compressed: list[str] = []
        in_failure_block = False
        failure_lines: list[str] = []
        source_files: set[str] = set()

        # Pattern: catches both forward-slash and backslash paths with .py
        import re as _re_local
        file_pattern = _re_local.compile(r'([\w][\w\\/.\-]+\.py)(?::(\d+))?')

        # Detect the repo root from common patterns in the output so we can
        # convert absolute paths to relative ones for the model.
        repo_root = ""
        for line in lines:
            # pytest shows rootdir in its header
            if "rootdir:" in line:
                repo_root = line.split("rootdir:")[-1].strip().rstrip(",")
                break

        for line in lines:
            stripped = line.strip()

            # Extract file paths from traceback lines for the summary header
            for m in file_pattern.finditer(line):
                fpath = m.group(1)
                # Normalize Windows backslashes to forward slashes
                fpath = fpath.replace("\\", "/")
                # Strip absolute path prefix if we know the repo root
                if repo_root:
                    norm_root = repo_root.replace("\\", "/")
                    if fpath.startswith(norm_root):
                        fpath = fpath[len(norm_root):].lstrip("/")
                # Only keep project source files, not stdlib/venv
                if any(marker in fpath for marker in (
                    "localforge/", "tests/", "test_",
                )) and "__pycache__" not in fpath and "site-packages" not in fpath:
                    source_files.add(fpath)

            # Always keep header/summary lines
            if any(marker in line for marker in (
                "test session starts", "platform ",
                "short test summary", "FAILED",
                " passed", " failed", " error",
                "============", "no tests ran",
            )):
                if in_failure_block and failure_lines:
                    compressed.extend(failure_lines[-10:])
                    failure_lines.clear()
                    in_failure_block = False
                compressed.append(line)
                continue

            # Detect start of a failure traceback
            if stripped.startswith("FAILED") or stripped.startswith("___"):
                in_failure_block = True
                failure_lines.append(line)
                continue

            # Inside failure block — collect traceback lines
            if in_failure_block:
                failure_lines.append(line)
                continue

            # Skip PASSED lines entirely
            if "PASSED" in line:
                continue

            # Keep lines with assertion errors or important errors
            if any(kw in line for kw in (
                "AssertionError", "AssertionError", "assert ",
                "TypeError", "ValueError", "AttributeError",
                "KeyError", "ImportError", "NameError",
                "E       ", "> ",
            )):
                compressed.append(line)

        # Flush any remaining failure block
        if failure_lines:
            compressed.extend(failure_lines[-10:])

        # Prepend a summary of source files mentioned in errors
        if source_files:
            file_summary = "SOURCE FILES IN ERRORS: " + ", ".join(sorted(source_files))
            compressed.insert(0, file_summary)

        # Auto-extract imports from the test file so the model knows the
        # REAL source file paths instead of guessing (e.g., src/validation.py).
        # This is the single biggest fix for path hallucination: the model
        # sees "from localforge.chat.tools import validate_tool_call" and
        # knows to read localforge/chat/tools.py instead of inventing paths.
        if repo_path and command:
            test_file_imports = ToolExecutor._extract_test_file_imports(
                command, repo_path,
            )
            if test_file_imports:
                compressed.insert(0, test_file_imports)

        result = "\n".join(compressed)
        if len(result) < len(output) * 0.85:
            return result
        return output

    @staticmethod
    def _extract_test_file_imports(command: str, repo_path: Path) -> str:
        """Extract import lines from the test file mentioned in a pytest command.

        Parses 'pytest tests/test_foo.py' to find the test file, reads it,
        and returns all import/from-import lines.  This tells the model
        exactly which source files contain the functions under test.
        """

        # Extract test file path(s) from the command
        # Matches: pytest tests/test_foo.py, python -m pytest tests/test_foo.py
        test_files: list[str] = []
        for token in command.split():
            token = token.strip()
            if token.endswith(".py") and ("test" in token.lower() or "spec" in token.lower()):
                test_files.append(token)

        if not test_files:
            return ""

        all_imports: list[str] = []
        for tf in test_files[:2]:  # Cap at 2 test files to avoid bloat
            tf_path = repo_path / tf
            if not tf_path.is_file():
                # Try with backslash normalization
                tf_path = repo_path / tf.replace("/", os.sep)
            if not tf_path.is_file():
                continue
            try:
                content = tf_path.read_text(encoding="utf-8", errors="replace")
                for line in content.splitlines():
                    stripped = line.strip()
                    if stripped.startswith("import ") or stripped.startswith("from "):
                        # Skip stdlib/test framework imports
                        if any(mod in stripped for mod in (
                            "import unittest", "import pytest", "import os",
                            "import sys", "import json", "import re",
                            "import hashlib", "import tempfile", "import pathlib",
                            "from unittest", "from pytest", "from pathlib",
                            "from unittest.mock",
                        )):
                            continue
                        all_imports.append(stripped)
            except (OSError, UnicodeDecodeError):
                continue

        if not all_imports:
            return ""

        # Deduplicate while preserving order
        seen: set[str] = set()
        unique_imports: list[str] = []
        for imp in all_imports:
            if imp not in seen:
                seen.add(imp)
                unique_imports.append(imp)

        return (
            "TEST FILE IMPORTS (these show the REAL source file paths):\n"
            + "\n".join(unique_imports)
            + "\nUse these import paths to find the source files to fix."
        )

    @staticmethod
    def _compress_tool_output(output: str, command: str, repo_path: Path | None = None) -> str:
        """Compress large tool outputs by summarizing repetitive errors.

        Groups errors by type for linter/compiler outputs across ALL languages,
        keeping only first few examples of each error type to save context tokens.
        """
        lines = output.splitlines()
        if len(lines) < 20:
            return output  # Not big enough to compress

        lower_cmd = command.lower()

        # Compress pytest / test runner output specifically
        is_pytest = any(kw in lower_cmd for kw in ("pytest", "python -m pytest", "py.test"))
        if is_pytest or "test session starts" in output[:500]:
            return ToolExecutor._compress_pytest_output(output, repo_path, command)

        # Detect linter/compiler output across all stacks
        is_linter = any(kw in lower_cmd for kw in (
            # Python
            "ruff", "flake8", "pylint", "mypy",
            # JavaScript/TypeScript
            "eslint", "tsc", "biome", "oxlint",
            # Go
            "golangci-lint", "go vet",
            # Rust
            "cargo clippy",
            # Java
            "checkstyle", "spotbugs",
            # .NET
            "dotnet build",
            # Ruby
            "rubocop",
            # PHP
            "phpstan", "psalm",
            # General
            "lint", "check",
        ))
        if not is_linter:
            return output

        # Group errors by error code/type (works for most linters)
        error_groups: dict[str, list[str]] = {}
        other_lines: list[str] = []

        # Multi-language error patterns
        error_patterns = [
            _re.compile(r'(\w+[\\/][\w.\\/]+:\d+:\d+:\s*)(\w+\d*)\s'),  # ruff/flake8/eslint
            _re.compile(r'(\w+[\\/][\w.\\/]+:\d+:\s*error:\s*)(.+)'),     # mypy/tsc
            _re.compile(r'(\w+[\\/][\w.\\/]+\(\d+,\d+\):\s*error\s+)(\w+)'),  # tsc/dotnet
            _re.compile(r'(warning\[|error\[)(\w+\d*)\]'),                # Rust
        ]

        for line in lines:
            matched = False
            for pattern in error_patterns:
                m = pattern.search(line)
                if m:
                    code = m.group(2).strip()[:50]  # Cap code length
                    error_groups.setdefault(code, []).append(line)
                    matched = True
                    break
            if not matched:
                other_lines.append(line)

        if not error_groups or len(error_groups) < 2:
            return output  # Not grouped enough to compress

        # Build compressed output
        compressed: list[str] = []
        total_errors = sum(len(v) for v in error_groups.values())
        compressed.append(f"=== {total_errors} issues grouped by type ===\n")

        for code, group_lines in sorted(error_groups.items(), key=lambda x: -len(x[1])):
            compressed.append(f"\n[{code}] — {len(group_lines)} occurrence(s):")
            # Show first 3 examples
            for line in group_lines[:3]:
                compressed.append(f"  {line}")
            if len(group_lines) > 3:
                compressed.append(f"  ... and {len(group_lines) - 3} more")

        # Add summary lines (exit code, etc.)
        for line in other_lines[-5:]:
            if line.strip():
                compressed.append(line)

        result = "\n".join(compressed)
        # Only use compressed if it's actually shorter
        if len(result) < len(output) * 0.8:
            return result
        return output

    # Python tools that can be invoked via `python -m <tool>` when not in PATH
    _PYTHON_M_TOOLS = {
        "ruff", "pytest", "mypy", "black", "isort", "flake8", "pylint",
        "coverage", "pip", "poetry", "pdm", "hatch", "nox", "tox",
        "pre_commit", "pre-commit", "autopep8", "pyflakes", "pycodestyle",
        "bandit", "pydocstyle", "vulture",
    }

    # npx-runnable tools for JS/TS ecosystem
    _NPX_TOOLS = {
        "eslint", "prettier", "tsc", "tsx", "vitest", "jest", "mocha",
        "webpack", "vite", "next", "nuxt", "astro", "svelte-check",
        "tailwindcss", "postcss", "ts-node", "tsup", "esbuild",
        "biome", "oxlint", "stylelint",
    }

    @staticmethod
    def _is_tool_not_found(output: str, command: str) -> bool:
        """Detect if a command failed because the executable wasn't found."""
        lower = output.lower()
        not_found_signals = (
            "is not recognized",  # Windows
            "not found",          # Linux/macOS
            "no such file or directory",
            "command not found",
            "not operable",
        )
        return any(sig in lower for sig in not_found_signals)

    @classmethod
    def _try_python_m_fallback(cls, command: str) -> str | None:
        """Try converting a command to `python -m <tool>` form.

        Returns the corrected command or None if not applicable.
        """
        parts = command.strip().split()
        if not parts:
            return None

        tool = parts[0].lower().rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
        # Strip .exe suffix on Windows
        if tool.endswith(".exe"):
            tool = tool[:-4]

        if tool in cls._PYTHON_M_TOOLS:
            rest = parts[1:]
            return f"python -m {tool} {' '.join(rest)}".strip()

        return None

    @staticmethod
    def _looks_like_ruff_usage_error(output: str) -> bool:
        lower = output.lower()
        return (
            "usage: ruff" in lower
            and (
                "unexpected argument '--fix'" in lower
                or "unrecognized subcommand '.'" in lower
            )
        )

    @staticmethod
    def _normalize_ruff_command(command: str) -> str:
        """Normalize common Ruff invocation mistakes to modern CLI syntax."""
        stripped = command.strip()
        if not stripped.lower().startswith("ruff"):
            return command

        try:
            parts = shlex.split(stripped, posix=False)
        except ValueError:
            # Fall back to simple split when quoting is malformed
            parts = stripped.split()

        if len(parts) <= 1:
            return "ruff check ."

        # Drop leading executable token
        args = parts[1:]
        lower_args = [a.lower() for a in args]

        # Already modern form
        if args and args[0].lower() in {"check", "format", "rule", "config", "clean", "server", "analyze"}:
            return command

        fix_flag = "--fix" in lower_args
        other_flags = [a for a in args if a.lower() != "--fix"]

        # Case: "ruff ." -> "ruff check ."
        if other_flags == ["."] and not fix_flag:
            return "ruff check ."

        # Case: "ruff --fix ." or "ruff . --fix" -> "ruff check . --fix"
        if other_flags == ["."] and fix_flag:
            return "ruff check . --fix"

        # Generic fallback: preserve user args under "check"
        rebuilt = ["ruff", "check", *other_flags]
        if fix_flag:
            rebuilt.append("--fix")
        return " ".join(rebuilt)

    def _normalize_command(self, command: str) -> str:
        """Normalize known command pitfalls before execution.

        - Normalizes ruff CLI syntax
        - On Windows: auto-corrects Unix commands to Windows equivalents
        - On Windows, preemptively uses `python -m <tool>` for Python tools
          that aren't in PATH (avoids "not recognized" errors)
        - Falls back to npx for Node.js tools not in PATH
        """
        command = self._normalize_ruff_command(command)

        # Windows-specific command corrections
        if sys.platform == "win32":
            command = self._fix_windows_command(command)

        import shutil
        parts = command.strip().split()
        if not parts:
            return command

        tool = parts[0].lower().rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
        if tool.endswith(".exe"):
            tool = tool[:-4]

        # Python tool fallback
        if tool in self._PYTHON_M_TOOLS and not shutil.which(tool):
            rest = parts[1:]
            command = f"python -m {tool} {' '.join(rest)}".strip()

        # Node.js / npx tool fallback
        elif tool in self._NPX_TOOLS and not shutil.which(tool):
            rest = parts[1:]
            command = f"npx {tool} {' '.join(rest)}".strip()

        # Cargo subcommand normalization
        elif tool == "cargo" and len(parts) > 1:
            sub = parts[1].lower()
            if sub in ("clippy", "fmt", "test", "build", "check", "run"):
                pass  # already correct form

        # Go tool normalization
        elif tool == "go" and len(parts) > 1:
            sub = parts[1].lower()
            if sub == "vet" or sub == "test":
                pass  # already correct form

        return command

    # Unix→Windows command translation table
    _UNIX_TO_WINDOWS = {
        "ls": "dir",
        "ls -la": "dir /a",
        "ls -l": "dir",
        "ls -a": "dir /a",
        "ls -al": "dir /a",
        "pwd": "cd",
        "cat": "type",
        "cp": "copy",
        "mv": "move",
        "mkdir -p": "mkdir",
        "touch": "type nul >",
        "which": "where",
        "clear": "cls",
        "chmod": "echo (chmod not available on Windows, skipping)",
        "ln -s": "mklink",
        "head": "more",
        "tail": "more",
        "grep": "findstr /I",
        "wc -l": "find /c /v \"\"",
    }

    @classmethod
    def _fix_windows_command(cls, command: str) -> str:
        """Auto-correct common Unix commands to their Windows equivalents.

        Handles command chaining (&&, ||, ;) and pipe operations.
        """
        # Fix command chaining: && works on Windows cmd but not always in subprocess
        # Replace ; with & for Windows command chaining
        # But preserve semicolons inside quoted strings
        parts = command.split()
        if not parts:
            return command

        # Direct single-command translations
        first = parts[0].lower().strip()

        # Full multi-word command match first (e.g., "ls -la")
        for unix_cmd, win_cmd in cls._UNIX_TO_WINDOWS.items():
            prefix = unix_cmd.split()
            if len(parts) >= len(prefix):
                if [p.lower() for p in parts[:len(prefix)]] == prefix:
                    rest = parts[len(prefix):]
                    return f"{win_cmd} {' '.join(rest)}".strip()

        # Single command match
        if first in cls._UNIX_TO_WINDOWS:
            rest = parts[1:]
            win_cmd = cls._UNIX_TO_WINDOWS[first]
            return f"{win_cmd} {' '.join(rest)}".strip()

        # Fix 'pwd && ls -la' style chained commands
        if "&&" in command or "||" in command or ";" in command:
            # Split on chain operators, translate each part, rejoin
            import re as _re_local
            chain_parts = _re_local.split(r'(&&|\|\||;)', command)
            fixed_parts = []
            for part in chain_parts:
                stripped = part.strip()
                if stripped in ("&&", "||", ";"):
                    fixed_parts.append("&" if stripped == ";" else stripped)
                else:
                    fixed_parts.append(cls._fix_windows_command(stripped))
            return " ".join(fixed_parts)

        return command

    def _search_code(self, args: dict[str, Any]) -> str:
        pattern = args.get("pattern", "")
        if not pattern:
            return "Error: No search pattern provided"

        file_glob = args.get("file_glob", "")

        # Use the index searcher if available, otherwise fall back to grep
        try:
            from localforge.index import IndexSearcher

            db_path = self.repo_path / ".localforge" / "index.db"
            if db_path.is_file():
                searcher = IndexSearcher(db_path)
                try:
                    results = searcher.search_lexical(pattern, limit=15)
                    # Filter by focus paths when set
                    if self.focus_paths:
                        results = [r for r in results if self._matches_focus(r.file_path)]
                    if results:
                        parts: list[str] = []
                        for r in results:
                            parts.append(
                                f"{r.file_path}:"
                                f"{r.start_line} — "
                                f"{r.content[:120]}"
                            )
                        return "\n".join(parts)
                finally:
                    searcher.close()
        except Exception:
            pass

        # Fallback: simple grep via subprocess
        if sys.platform == "win32":
            cmd = ["findstr", "/S", "/I", "/N", pattern]
            if file_glob:
                cmd.append(file_glob)
            else:
                # Search all common source files, not just Python
                cmd.append("*.*")
        else:
            include = file_glob or "*"
            cmd = ["grep", "-r", "-n", "-i", "--include", include, pattern, "."]

        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=30,
                cwd=str(self.repo_path),
            )
            output = result.stdout or "(no matches)"
            if len(output) > _MAX_OUTPUT:
                output = output[:_MAX_OUTPUT] + "\n... (truncated)"
            return output
        except subprocess.TimeoutExpired:
            return "Error: Search timed out"

    def _find_symbols(self, args: dict[str, Any]) -> str:
        name = args.get("name", "")
        kind = args.get("kind")
        if not name:
            return "Error: No symbol name provided"

        # Try the index first (works well for Python)
        try:
            from localforge.index import IndexSearcher

            db_path = self.repo_path / ".localforge" / "index.db"
            if db_path.is_file():
                searcher = IndexSearcher(db_path)
                try:
                    results = searcher.search_symbols(name, kind=kind)
                    # Filter by focus paths when set
                    if self.focus_paths:
                        results = [r for r in results if self._matches_focus(r["file_path"])]
                    if results:
                        parts: list[str] = []
                        for r in results[:30]:
                            parts.append(
                                f"  {r['kind']:12s} {r['name']:30s} "
                                f"{r['file_path']}:L{r['line']}"
                            )
                        return f"Found {len(results)} symbol(s):\n" + "\n".join(parts)
                finally:
                    searcher.close()
        except Exception:
            pass

        # Fallback: multi-language grep-based symbol search
        return self._grep_symbols(name, kind)

    def _grep_symbols(self, name: str, kind: str | None = None) -> str:
        """Find symbols across any language using regex patterns."""
        # Build language-specific patterns for function/class/variable definitions
        patterns: list[str] = []

        if kind in (None, "function"):
            patterns.extend([
                rf"def\s+{_re.escape(name)}\s*\(",                      # Python
                rf"function\s+{_re.escape(name)}\s*\(",                 # JavaScript
                rf"(?:const|let|var)\s+{_re.escape(name)}\s*=\s*(?:async\s*)?\(",  # JS arrow
                rf"(?:const|let|var)\s+{_re.escape(name)}\s*=\s*(?:async\s*)?function",
                rf"func\s+{_re.escape(name)}\s*\(",                     # Go
                rf"fn\s+{_re.escape(name)}\s*[<(]",                     # Rust
                rf"(?:public|private|protected|static)\s+\w+\s+{_re.escape(name)}\s*\(", # Java/C#
                rf"def\s+{_re.escape(name)}\s*[(\[]",                   # Ruby
                rf"function\s+{_re.escape(name)}\s*\(",                 # PHP
                rf"fun\s+{_re.escape(name)}\s*\(",                      # Kotlin
            ])

        if kind in (None, "class"):
            patterns.extend([
                rf"class\s+{_re.escape(name)}\b",                       # Python/JS/TS/Java/C#
                rf"struct\s+{_re.escape(name)}\b",                      # Go/Rust/C
                rf"interface\s+{_re.escape(name)}\b",                   # Java/TS/Go
                rf"enum\s+{_re.escape(name)}\b",                        # Java/Rust/TS
                rf"trait\s+{_re.escape(name)}\b",                       # Rust
                rf"module\s+{_re.escape(name)}\b",                      # Ruby
            ])

        if kind in (None, "variable", "constant"):
            patterns.extend([
                rf"{_re.escape(name)}\s*=",                             # Python/Ruby
                rf"(?:const|let|var)\s+{_re.escape(name)}\b",          # JS/TS
                rf"(?:val|var)\s+{_re.escape(name)}\b",                # Kotlin/Scala
            ])

        if not patterns:
            patterns = [rf"\b{_re.escape(name)}\b"]

        combined = "|".join(f"(?:{p})" for p in patterns)
        return self._grep_codebase({
            "pattern": combined,
            "is_regex": True,
        })

    def _get_project_overview(self, args: dict[str, Any]) -> str:
        import os

        skip_dirs = {
            ".git", "node_modules", "__pycache__", ".venv", "venv",
            "dist", "build", ".localforge", ".tox", ".mypy_cache",
            ".pytest_cache", ".next", ".nuxt", ".svelte-kit",
            "coverage", ".cache", ".parcel-cache", "target",
            "out", "bin", "obj",
        }

        lines: list[str] = ["PROJECT STRUCTURE:"]

        # ── Read all documentation files ─────────────────────────
        doc_content_parts: list[str] = []
        doc_budget = 6000  # characters budget across all doc files

        # Priority-ordered doc files: README first, then build/contributing docs
        doc_candidates = [
            "README.md", "README.rst", "README.txt", "README",
            "CONTRIBUTING.md", "CONTRIBUTING.rst",
            "BUILD.md", "BUILDING.md",
            "DEVELOPMENT.md", "DEVELOPING.md", "DEV.md",
            "SETUP.md", "INSTALL.md", "INSTALLATION.md",
            "docs/README.md", "docs/getting-started.md",
            "docs/development.md", "docs/setup.md",
            ".github/CONTRIBUTING.md",
        ]

        doc_chars_used = 0
        for doc_name in doc_candidates:
            doc_path = self.repo_path / doc_name
            if doc_path.is_file() and doc_chars_used < doc_budget:
                try:
                    content = doc_path.read_text(encoding="utf-8", errors="replace")
                    remaining = doc_budget - doc_chars_used
                    if len(content) > remaining:
                        content = content[:remaining] + "\n... (truncated)"
                    doc_content_parts.append(f"\n--- {doc_name} ---\n{content}")
                    doc_chars_used += len(content)
                except OSError:
                    pass

        # Build tree
        file_count = 0
        for dirpath, dirnames, filenames in os.walk(self.repo_path):
            dirnames[:] = [
                d for d in sorted(dirnames)
                if d not in skip_dirs and not d.startswith(".")
            ]
            try:
                rel = Path(dirpath).relative_to(self.repo_path)
            except ValueError:
                continue
            depth = len(rel.parts)
            if depth > 4:
                continue

            indent = "  " * depth
            dir_name = rel.name if depth > 0 else "."
            lines.append(f"{indent}{dir_name}/")

            for fname in sorted(filenames):
                if fname.startswith(".") or fname.endswith((".pyc", ".pyo")):
                    continue
                file_count += 1
                if file_count > 150:
                    lines.append(f"{indent}  ... (more files)")
                    break
                lines.append(f"{indent}  {fname}")
            if file_count > 150:
                break

        # ── Detect tech stack & frameworks ────────────────────────
        stack_info: list[str] = []
        stack_info.append("\nDETECTED TECH STACK:")

        # package.json — read scripts and dependencies for frontend detection
        pkg_json_scripts = ""
        if (self.repo_path / "package.json").is_file():
            try:
                pkg_raw = (self.repo_path / "package.json").read_text(encoding="utf-8")
                import json as _json
                pkg_data = _json.loads(pkg_raw)

                # Detect framework from dependencies
                all_deps = {}
                all_deps.update(pkg_data.get("dependencies", {}))
                all_deps.update(pkg_data.get("devDependencies", {}))

                frameworks: list[str] = []
                if "react" in all_deps:
                    frameworks.append("React")
                if "next" in all_deps:
                    frameworks.append("Next.js")
                if "vue" in all_deps:
                    frameworks.append("Vue.js")
                if "nuxt" in all_deps:
                    frameworks.append("Nuxt")
                if "@angular/core" in all_deps:
                    frameworks.append("Angular")
                if "svelte" in all_deps:
                    frameworks.append("Svelte")
                if "@sveltejs/kit" in all_deps:
                    frameworks.append("SvelteKit")
                if "astro" in all_deps:
                    frameworks.append("Astro")
                if "express" in all_deps:
                    frameworks.append("Express.js")
                if "fastify" in all_deps:
                    frameworks.append("Fastify")
                if "nestjs" in all_deps or "@nestjs/core" in all_deps:
                    frameworks.append("NestJS")
                if "electron" in all_deps:
                    frameworks.append("Electron")
                if "react-native" in all_deps:
                    frameworks.append("React Native")
                if "expo" in all_deps:
                    frameworks.append("Expo")
                if "tailwindcss" in all_deps:
                    frameworks.append("Tailwind CSS")
                if "vite" in all_deps:
                    frameworks.append("Vite")
                if "webpack" in all_deps:
                    frameworks.append("Webpack")

                if frameworks:
                    stack_info.append(f"  Frontend/JS frameworks: {', '.join(frameworks)}")

                # Show available scripts (crucial for knowing how to build/test/run)
                scripts = pkg_data.get("scripts", {})
                if scripts:
                    pkg_json_scripts = "\nAvailable npm scripts (from package.json):"
                    for script_name, script_cmd in sorted(scripts.items()):
                        pkg_json_scripts += f"\n  npm run {script_name}: {script_cmd}"
                    stack_info.append(pkg_json_scripts)

            except (OSError, ValueError):
                pass

        # Add package/config info
        pkg_info = []
        config_files = [
            "pyproject.toml", "package.json", "Cargo.toml", "go.mod",
            "pom.xml", "build.gradle", "build.gradle.kts",
            "Gemfile", "composer.json", "CMakeLists.txt",
            "Package.swift", "Makefile",
            "tsconfig.json", "vite.config.ts", "vite.config.js",
            "next.config.js", "next.config.mjs", "next.config.ts",
            "angular.json", "svelte.config.js",
            "webpack.config.js", "webpack.config.ts",
            ".eslintrc.json", ".eslintrc.js", "eslint.config.js",
            "Dockerfile", "docker-compose.yml", "docker-compose.yaml",
        ]
        for cfg_file in config_files:
            cfg_path = self.repo_path / cfg_file
            if cfg_path.is_file():
                try:
                    content = cfg_path.read_text(encoding="utf-8")
                    if len(content) > 2000:
                        content = content[:2000] + "\n... (truncated)"
                    pkg_info.append(f"\n{cfg_file}:\n{content}")
                except OSError:
                    pass

        # Detect other tech stacks
        if (self.repo_path / "pyproject.toml").is_file() or (self.repo_path / "setup.py").is_file():
            stack_info.append("  Backend: Python")
        if (self.repo_path / "go.mod").is_file():
            stack_info.append("  Backend: Go")
        if (self.repo_path / "Cargo.toml").is_file():
            stack_info.append("  Language: Rust")
        if (self.repo_path / "pom.xml").is_file():
            stack_info.append("  Backend: Java (Maven)")
        if (self.repo_path / "build.gradle").is_file() or (self.repo_path / "build.gradle.kts").is_file():
            stack_info.append("  Backend: Java/Kotlin (Gradle)")
        if any(self.repo_path.glob("*.csproj")) or any(self.repo_path.glob("*.sln")):
            stack_info.append("  Backend: .NET / C#")
        if (self.repo_path / "Gemfile").is_file():
            stack_info.append("  Backend: Ruby")
        if (self.repo_path / "composer.json").is_file():
            stack_info.append("  Backend: PHP")

        # Add symbols from index
        symbols_info = ""
        try:
            from localforge.index import IndexSearcher

            db_path = self.repo_path / ".localforge" / "index.db"
            if db_path.is_file():
                searcher = IndexSearcher(db_path)
                try:
                    conn = searcher._get_conn()
                    rows = conn.execute(
                        """
                        SELECT s.name, s.kind, s.line, f.relative_path
                          FROM symbols s
                          JOIN files f ON f.id = s.file_id
                         WHERE s.kind IN ('class', 'function', 'interface')
                           AND (s.scope = 'module' OR s.kind = 'class')
                         ORDER BY f.relative_path, s.line
                         LIMIT 100
                        """
                    ).fetchall()

                    if rows:
                        sym_lines = ["\nKEY DEFINITIONS:"]
                        by_file: dict[str, list[str]] = {}
                        for row in rows:
                            fp = row["relative_path"]
                            entry = f"    {row['kind']}: {row['name']} (L{row['line']})"
                            by_file.setdefault(fp, []).append(entry)
                        for fp, entries in sorted(by_file.items()):
                            sym_lines.append(f"  {fp}")
                            sym_lines.extend(entries[:8])
                        symbols_info = "\n".join(sym_lines)
                finally:
                    searcher.close()
        except Exception:
            pass

        result = "\n".join(lines)
        if len(stack_info) > 1:
            result += "\n".join(stack_info)
        if doc_content_parts:
            result += "\n\nPROJECT DOCUMENTATION:" + "".join(doc_content_parts)
        if pkg_info:
            result += "\n" + "\n".join(pkg_info)
        if symbols_info:
            result += symbols_info

        return result

    # -- new tools: grep_codebase, verify_changes, batch_edit ---------------

    def _grep_codebase(self, args: dict[str, Any]) -> str:
        """Recursive grep across the entire codebase."""
        pattern = args.get("pattern", "")
        if not pattern:
            return "Error: No search pattern provided"

        file_glob = args.get("file_glob", "")
        is_regex = args.get("is_regex", False)

        skip_dirs_grep = {
            ".git", "node_modules", "__pycache__", ".venv", "venv",
            "dist", "build", ".localforge", ".tox", ".mypy_cache",
            ".pytest_cache", ".eggs",
        }

        matches: list[str] = []
        max_matches = 100

        if is_regex:
            try:
                compiled = _re.compile(pattern, _re.IGNORECASE)
            except _re.error as e:
                return f"Error: Invalid regex: {e}"
        else:
            compiled = None

        for dirpath, dirnames, filenames in os.walk(self.repo_path):
            dirnames[:] = [
                d for d in dirnames
                if d not in skip_dirs_grep and not d.startswith(".")
            ]

            # Skip directories outside focus scope
            if self.focus_paths:
                try:
                    dir_rel = Path(dirpath).relative_to(self.repo_path).as_posix()
                except ValueError:
                    continue
                # Root directory (".") is always an ancestor of every focus path
                if dir_rel not in (".", "") and not self._matches_focus(dir_rel):
                    # Check if any focus path is a child of this directory
                    is_ancestor = any(
                        fp.startswith(dir_rel.rstrip("/") + "/")
                        for fp in self.focus_paths
                    )
                    if not is_ancestor:
                        dirnames.clear()
                        continue

            for fname in filenames:
                if fname.startswith(".") or fname.endswith((".pyc", ".pyo", ".exe", ".dll", ".so")):
                    continue
                if file_glob and not Path(fname).match(file_glob):
                    continue
                fpath = Path(dirpath) / fname
                try:
                    # Skip binary files
                    if fpath.stat().st_size > 500_000:
                        continue
                    text = fpath.read_text(encoding="utf-8", errors="replace")
                except (OSError, UnicodeDecodeError):
                    continue

                try:
                    rel = fpath.relative_to(self.repo_path)
                except ValueError:
                    continue

                # Skip files outside focus scope
                if self.focus_paths and not self._matches_focus(rel.as_posix()):
                    continue

                for i, line in enumerate(text.splitlines(), 1):
                    found = bool(compiled.search(line)) if compiled else pattern.lower() in line.lower()
                    if found:
                        matches.append(f"{rel}:{i}: {line.rstrip()[:200]}")
                        if len(matches) >= max_matches:
                            break
                if len(matches) >= max_matches:
                    break

        if not matches:
            return f"No matches found for '{pattern}'"

        result = f"Found {len(matches)} match(es):\n" + "\n".join(matches)
        if len(matches) >= max_matches:
            result += "\n... (results capped at 100)"
        return result

    def _verify_changes(self, args: dict[str, Any]) -> str:
        """Run project verification (tests, lint, type checks).

        By default only syntax checks and tests are run.  Linters are
        included only when the caller passes ``include_lint=True`` or a
        custom command that explicitly invokes a linter.
        """
        custom_command = args.get("command", "").strip()
        include_lint = args.get("include_lint", False)

        if custom_command:
            # Run a specific verification command
            return self._run_command({"command": custom_command, "timeout": 300})

        # Auto-detect and run all verification.
        # We reuse the VerificationRunner when available.
        results_parts: list[str] = []

        try:
            from localforge.core.config import LocalForgeConfig
            from localforge.verifier.runner import VerificationRunner

            config = LocalForgeConfig(repo_path=str(self.repo_path))
            runner = VerificationRunner(self.repo_path, config)
            vresults = runner.run_verification(
                include_lint=include_lint,
            )

            if not vresults:
                return "No verification commands detected for this project."

            all_passed = True
            for vr in vresults:
                status = "PASS" if vr.success else "FAIL"
                if not vr.success:
                    all_passed = False
                results_parts.append(f"[{status}] {vr.command}")
                if vr.stdout:
                    out_text = vr.stdout[:5000]
                    results_parts.append(out_text)
                if vr.stderr and not vr.success:
                    err_text = vr.stderr[:3000]
                    results_parts.append(f"STDERR: {err_text}")

            summary = "ALL CHECKS PASSED" if all_passed else "SOME CHECKS FAILED"
            results_parts.insert(0, f"=== VERIFICATION SUMMARY: {summary} ===\n")
            return "\n".join(results_parts)

        except ImportError:
            # Fallback: try pytest directly
            return self._run_command({"command": "python -m pytest --tb=short -q", "timeout": 300})

    def _batch_edit(self, args: dict[str, Any]) -> str:
        """Apply multiple edits across files."""
        edits = args.get("edits", [])
        if not edits or not isinstance(edits, list):
            return "Error: 'edits' must be a non-empty list of {path, old_string, new_string}"

        results: list[str] = []
        for i, edit in enumerate(edits, 1):
            path = edit.get("path", "")
            old_string = edit.get("old_string", "")
            new_string = edit.get("new_string", "")
            result = self._edit_file({
                "path": path,
                "old_string": old_string,
                "new_string": new_string,
            })
            results.append(f"  Edit {i} ({path}): {result}")

        return "\n".join(results)

    # -- new tools: create_directory, create_project -----------------------

    def _resolve_external_path(self, rel_path: str) -> Path:
        """Resolve a path that may be outside the repo (e.g., ../new_project).

        Allows creation of files/dirs in sibling directories of the repo,
        but blocks dangerous traversals (going more than 2 levels up).
        """
        target = (self.repo_path / rel_path).resolve()

        # Allow paths within the repo
        if target.is_relative_to(self.repo_path):
            return target

        # Allow paths in sibling directories (parent's children)
        repo_parent = self.repo_path.parent
        if target.is_relative_to(repo_parent):
            return target

        # Allow one more level up (grandparent's children) for flexibility
        repo_grandparent = repo_parent.parent
        if target.is_relative_to(repo_grandparent):
            return target

        raise ValueError(
            f"Path too far outside repo: {rel_path!r}. "
            "Can only create in repo, parent, or grandparent directories."
        )

    def _create_directory(self, args: dict[str, Any]) -> str:
        """Create a directory (and all parent directories)."""
        rel = args.get("path", "")
        if not rel:
            return "Error: path is required"

        try:
            target = self._resolve_external_path(rel)
        except ValueError as e:
            return f"Error: {e}"

        try:
            target.mkdir(parents=True, exist_ok=True)
            return f"Successfully created directory: {rel}"
        except OSError as e:
            return f"Error creating directory: {e}"

    def _create_project(self, args: dict[str, Any]) -> str:
        """Create an entire project with multiple files at once.

        This is the primary tool for scaffolding new applications.
        It creates the base directory and all specified files in one call.
        Returns a detailed summary with project tree and next-step suggestions.
        """
        base_path = args.get("base_path", "")
        files = args.get("files", {})

        if not base_path:
            return "Error: base_path is required"
        if not files or not isinstance(files, dict):
            return "Error: files must be a non-empty dict of {path: content}"

        try:
            base = self._resolve_external_path(base_path)
        except ValueError as e:
            return f"Error: {e}"

        # Create base directory
        try:
            base.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            return f"Error creating base directory: {e}"

        results: list[str] = []
        success_count = 0
        error_count = 0
        total_bytes = 0

        for file_rel, content in files.items():
            file_path = base / file_rel
            try:
                file_path.parent.mkdir(parents=True, exist_ok=True)
                # Ensure content is a string
                if not isinstance(content, str):
                    content = str(content)
                file_path.write_text(content, encoding="utf-8")
                success_count += 1
                total_bytes += len(content)
                results.append(f"  ✓ {file_rel} ({len(content)} bytes)")
            except OSError as e:
                error_count += 1
                results.append(f"  ✗ {file_rel}: {e}")

        # Build a project tree for the model to reference
        tree_lines = [f"\nPROJECT TREE ({base_path}):"]
        dirs_seen: set[str] = set()
        for file_rel in sorted(files.keys()):
            parts = file_rel.replace("\\", "/").split("/")
            # Add directory entries
            for i in range(len(parts) - 1):
                dir_path = "/".join(parts[:i + 1])
                if dir_path not in dirs_seen:
                    dirs_seen.add(dir_path)
                    indent = "  " * (i + 1)
                    tree_lines.append(f"{indent}{parts[i]}/")
            # Add file entry
            indent = "  " * len(parts)
            tree_lines.append(f"{indent}{parts[-1]}")
        tree_str = "\n".join(tree_lines)

        # Detect project type and suggest next steps
        next_steps: list[str] = ["\nNEXT STEPS:"]
        file_names = {Path(f).name.lower() for f in files}

        if "requirements.txt" in file_names or "setup.py" in file_names or "pyproject.toml" in file_names:
            if "requirements.txt" in file_names:
                next_steps.append(f"  1. cd {base_path} && pip install -r requirements.txt")
            elif "pyproject.toml" in file_names:
                next_steps.append(f"  1. cd {base_path} && pip install -e .")
            has_tests = any("test" in f.lower() for f in files)
            if has_tests:
                next_steps.append(f"  2. cd {base_path} && pytest tests/ -v")
            next_steps.append("  3. Run the application")
        elif "package.json" in file_names:
            next_steps.append(f"  1. cd {base_path} && npm install")
            next_steps.append("  2. npm test")
            next_steps.append("  3. npm start")
        elif "go.mod" in file_names:
            next_steps.append(f"  1. cd {base_path} && go mod tidy")
            next_steps.append("  2. go test ./...")
            next_steps.append("  3. go run .")
        elif "Cargo.toml" in file_names:
            next_steps.append(f"  1. cd {base_path} && cargo build")
            next_steps.append("  2. cargo test")
            next_steps.append("  3. cargo run")
        elif "pom.xml" in file_names:
            next_steps.append(f"  1. cd {base_path} && mvn install")
            next_steps.append("  2. mvn test")
        else:
            next_steps.append(f"  1. cd {base_path}")
            next_steps.append("  2. Install dependencies")
            next_steps.append("  3. Run tests")

        next_steps_str = "\n".join(next_steps)

        summary = f"Created project at {base_path}: {success_count} files written ({total_bytes:,} bytes total)"
        if error_count:
            summary += f", {error_count} errors"
        return summary + "\n" + "\n".join(results) + tree_str + "\n" + next_steps_str
