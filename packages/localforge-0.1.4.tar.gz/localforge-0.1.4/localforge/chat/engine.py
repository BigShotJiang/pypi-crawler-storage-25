"""Chat engine — provides an interactive REPL for conversing with the codebase."""

from __future__ import annotations

import ast
import contextlib
import hashlib
import json
import logging
import os
import subprocess
import time
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.spinner import Spinner

from localforge.chat.session import ChatSession
from localforge.chat.tools import (
    TOOL_DESCRIPTIONS,
    TOOL_SCHEMAS,
    TOOL_SCHEMAS_FAST,
    ToolExecutor,
    extract_all_tool_calls,
    extract_json_tool_calls,
    hash_tool_call,
    validate_tool_call,
)
from localforge.core.config import LocalForgeConfig
from localforge.core.ollama_client import OllamaClient

logger = logging.getLogger(__name__)

console = Console()

# Short, focused system prompt — tool descriptions are sent via the native
# tools API parameter so they don't burn context tokens.
_SYSTEM_PROMPT = """\
You are LocalForge, an autonomous AI coding agent. You EXECUTE tasks directly.
You have access to tools that let you read files, edit files, run shell commands,
and search the codebase. USE THEM for every task.

CRITICAL RULES — you MUST follow these:
1. ACT immediately. Call tools to read files, run commands, edit code.
2. NEVER tell the user to do something manually. YOU do it with tools.
3. NEVER say "please review" or "let me know". YOU review and YOU decide.
4. When a command shows errors/warnings, YOU fix them by editing the files.
5. ITERATE: run command → read errors → edit files to fix → re-run to verify.
   Keep going until the command passes cleanly or you've fixed all issues.
6. Read the relevant files BEFORE editing so you have exact content to match.
7. Only give a brief summary AFTER all work is done and verified.
8. After making code changes, verify by running tests (pytest) or the
   application itself to confirm correctness. Only run linters (ruff, mypy)
   when the user explicitly asks for linting or style checks.

SPEED RULES — be FAST and EFFICIENT:
- Call MULTIPLE tools in a SINGLE response when possible (batch reads, etc.)
- Do NOT read a file if you already have its content from a previous tool call
- Skip unnecessary exploration — use grep/search to go directly to the issue
- When fixing a clear issue, edit it immediately without extra reads
- Prefer batch_edit for multiple changes in the same or different files
- Do NOT run verify_changes after every tiny edit — batch your edits first

EDITING STRATEGY — avoid failures:
- ALWAYS read a file before editing it to get exact current content
- Include 3+ surrounding context lines in old_string for unique matching
- If edit_file fails with "matches N locations", add more context lines
- If edit_file fails with "not found", re-read the file — it may have changed
- Use edit_lines (line numbers) when you know exact line numbers from read_file
- For large changes, prefer apply_diff with unified diff format
- NEVER make a no-op edit where old_string equals new_string
- If stuck on the same error 2+ times, try a completely different approach

MULTI-LANGUAGE SUPPORT:
- You work with ANY language: Python, JavaScript, TypeScript, Go, Rust, Java,
  C#, C/C++, Ruby, PHP, Kotlin, Swift, and more.
- Use the appropriate build/test commands for each stack:
  Python: pytest, ruff, mypy | JS/TS: npm test, tsc, eslint, vitest/jest
  Go: go test, go build | Rust: cargo test, cargo clippy
  Java: mvn test, gradle test | .NET: dotnet test
  Ruby: bundle exec rspec | PHP: phpunit
- run_command can execute ANY CLI tool for ANY language.
"""

# System prompt for analysis-only queries (no tool calling expected)
_ANALYSIS_SYSTEM_PROMPT = """\
You are LocalForge, an intelligent code analysis assistant. You provide insights about code.

RULES:
1. Answer questions directly and concisely.
2. If asked to explain code, provide clear explanations.
3. For analysis questions, give direct answers without excessive preamble.
4. Be helpful but brief.
"""

# Longer XML-format fallback prompt, used only when native tool calling fails.
_XML_FALLBACK_PROMPT = TOOL_DESCRIPTIONS

# Maximum characters of tool output to send back to the model.
# Larger outputs (e.g. linter diagnostics for 75+ issues) overwhelm the
# context window and cause timeouts — especially on CPU-only machines.
# We keep head + tail so the model sees the beginning and summary lines.
_MAX_TOOL_RESULT_CHARS = 8000


def _truncate_tool_result(text: str, max_chars: int = _MAX_TOOL_RESULT_CHARS) -> str:
    """Truncate a tool result to *max_chars*, keeping head + tail."""
    if len(text) <= max_chars:
        return text
    head_size = int(max_chars * 0.6)
    tail_size = int(max_chars * 0.3)
    omitted = len(text) - head_size - tail_size
    return (
        text[:head_size]
        + f"\n\n... ({omitted} characters omitted) ...\n"
        "WARNING: This output was truncated. Do NOT copy any part of this truncated text "
        "into edit_file old_string — it will never match. Use edit_lines with line numbers, "
        "or re-read the specific line range with read_file start_line/end_line.\n\n"
        + text[-tail_size:]
    )


# Keywords that indicate action-oriented queries (need tool execution)
_ACTION_KEYWORDS = {
    "run", "execute", "fix", "edit", "delete", "create", "write",
    "add", "remove", "change", "modify", "refactor", "optimize",
    "install", "apply", "patch", "generate", "autofix", "implement",
    "make", "do", "build", "test", "setup", "configure",
}

# Keywords that indicate analysis-only queries (no tool execution needed)
_ANALYSIS_KEYWORDS = {
    "what", "how", "why", "when", "where", "explain", "describe",
    "analyze", "check", "find", "search", "list", "show", "tell",
    "count", "summarize", "review", "understand", "compare", "is",
    "could", "would", "can", "should", "does", "has", "get",
}

# Phrases that indicate the model is being lazy (giving instructions instead of acting)
_LAZY_INDICATORS = [
    "you can run",
    "you should run",
    "you could run",
    "try running",
    "you can use",
    "you should use",
    "run the following",
    "execute the following",
    "you need to",
    "you'll need to",
    "follow these steps",
    "here are the steps",
    "here's what you need to do",
    "here is what you need",
    "steps to fix",
    "to fix this, you",
    "to resolve this",
    "you can fix this by",
    "i recommend",
    "i suggest",
    "i would suggest",
    "i would recommend",
]


class ChatEngine:
    """Interactive chat engine backed by Ollama + codebase context + tools."""

    _MAX_TOOL_ROUNDS = 50  # allow extensive autonomous exploration & iteration
    _MAX_ANALYSIS_LENGTH = 2000  # max response length for analysis queries

    # Prompts that are usually direct terminal tasks and do not need expensive
    # repo-map/context retrieval before the first tool call.
    _FAST_ACTION_PREFIXES = (
        "run ",
        "execute ",
    )

    def __init__(
        self,
        config: LocalForgeConfig,
        ollama: OllamaClient,
        repo_path: Path,
    ) -> None:
        self.config = config
        self.ollama = ollama
        self.repo_path = repo_path
        self.session = ChatSession(
            session_id=hashlib.sha256(str(repo_path).encode()).hexdigest()[:12],
            repo_path=str(repo_path),
            model=config.model_name,
        )
        self._context_cache: str = ""
        self._repo_map_cache: str = ""
        self.tools = ToolExecutor(repo_path)
        self._token_count: int = 0  # rough token counter for session
        self._tool_calls_count: int = 0  # total tool calls executed
        self._rounds_count: int = 0  # total inference rounds

    # ------------------------------------------------------------------
    # Focus path helpers
    # ------------------------------------------------------------------

    def _matches_focus(self, rel_path: str) -> bool:
        """Return True if *rel_path* is within the current focus scope.

        When no focus paths are set, everything matches (full-codebase mode).
        """
        if not self.session.has_focus():
            return True
        normalised = rel_path.replace("\\", "/").strip("/")
        for fp in self.session.focus_paths:
            if normalised == fp or normalised.startswith(fp.rstrip("/") + "/"):
                return True
            # fp might be a file path that matches exactly
            if fp == normalised:
                return True
        return False

    def _sync_focus_to_tools(self) -> None:
        """Push the current focus paths to the ToolExecutor."""
        self.tools.focus_paths = list(self.session.focus_paths)

    def _invalidate_repo_map(self) -> None:
        """Clear the repo map cache so it rebuilds with current focus."""
        self._repo_map_cache = ""

    def _enrich_with_focus(self, user_input: str) -> str:
        """Prepend explicit focus-path references to the user's message.

        Local models treat "this file" as ambiguous — they often latch on to
        file names mentioned earlier in the conversation history instead of
        the files in the system-prompt context.  By rewriting the message
        we eliminate the ambiguity.
        """
        if not self.session.has_focus():
            return user_input

        paths = self.session.focus_paths
        if len(paths) == 1:
            full = self.repo_path / paths[0]
            kind = "folder" if full.is_dir() else "file"
            prefix = f"[Focused {kind}: {paths[0]}]\n"
        else:
            listing = ", ".join(paths)
            prefix = f"[Focused paths: {listing}]\n"
        return prefix + user_input

    def _recent_messages_for_focus(
        self, max_messages: int = 6,
    ) -> list[dict[str, Any]]:
        """Return recent messages with the *last* user message rewritten.

        When focus is active the most recent user message is enriched with
        explicit file references so the model knows exactly what 'this file'
        or 'this folder' means.  Older messages are included but capped
        more aggressively to avoid stale references confusing the model.
        """
        msgs = self.session.messages
        if not msgs:
            return []

        # Take only the last few messages — stale history about unrelated
        # files is the #1 source of model confusion when focus is active.
        tail = msgs[-max_messages:] if len(msgs) > max_messages else list(msgs)

        result: list[dict[str, Any]] = []
        for i, m in enumerate(tail):
            content = m.content
            # Enrich the very last user message
            if i == len(tail) - 1 and m.role == "user":
                content = self._enrich_with_focus(content)
            result.append({"role": m.role, "content": content})
        return result

    def _build_focus_context(self, max_chars: int = 16000) -> str:
        """Read the actual content of all focused files and return as context.

        When the user adds files/folders via ``/add``, we need to provide
        their content directly to the LLM — search-based retrieval alone
        won't surface them for vague queries like "explain this file".

        Parameters
        ----------
        max_chars:
            Approximate character budget. Files are added until the budget is
            exhausted.  Oversized single files are truncated.
        """
        if not self.session.has_focus():
            return ""

        _skip_dirs = {
            ".git", "node_modules", "__pycache__", ".venv", "venv",
            "dist", "build", ".localforge", ".tox", ".mypy_cache",
            ".pytest_cache", ".eggs",
        }
        _skip_ext = {".pyc", ".pyo", ".exe", ".dll", ".so", ".bin", ".png",
                     ".jpg", ".jpeg", ".gif", ".ico", ".woff", ".woff2"}

        # Collect all files to read
        files_to_read: list[Path] = []
        for fp in self.session.focus_paths:
            full = self.repo_path / fp
            if full.is_file():
                files_to_read.append(full)
            elif full.is_dir():
                for child in sorted(full.rglob("*")):
                    if not child.is_file():
                        continue
                    if any(part in _skip_dirs for part in child.parts):
                        continue
                    if child.suffix.lower() in _skip_ext:
                        continue
                    if child.stat().st_size > 500_000:
                        continue
                    files_to_read.append(child)

        if not files_to_read:
            return ""

        # Sort by size (smallest first) so we fit more files in the budget
        files_to_read.sort(key=lambda p: p.stat().st_size)

        parts: list[str] = []
        chars_used = 0
        skipped_files: list[str] = []

        for fpath in files_to_read:
            try:
                rel = fpath.relative_to(self.repo_path).as_posix()
            except ValueError:
                continue
            try:
                content = fpath.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue

            line_count = content.count("\n") + 1
            remaining = max_chars - chars_used

            if remaining <= 200:
                # Not enough room — record as skipped
                skipped_files.append(rel)
                continue

            if len(content) > remaining:
                # Truncate but include what we can
                content = content[:remaining] + "\n... [truncated]"

            parts.append(
                f"--- {rel} (L1-L{line_count}) ---\n{content}"
            )
            chars_used += len(content) + len(rel) + 30  # overhead

        if not parts:
            return ""

        result = (
            "=== FOCUSED FILES ===\n"
            + "\n\n".join(parts)
            + "\n=== END FOCUSED FILES ==="
        )
        if skipped_files:
            result += (
                "\n\n(These files exceeded the context budget and were not included: "
                + ", ".join(skipped_files)
                + ". Use read_file to view them if needed.)"
            )
        return result

    @staticmethod
    def _classify_query(user_input: str) -> str:
        """Classify query as 'action' (needs tool execution) or 'analysis' (just answer).

        Returns: 'action' or 'analysis'
        """
        lower = user_input.lower().strip()

        # ── Priority 1: Question phrases always → analysis ──────────
        # These indicate the user is asking a question, even if the
        # sentence contains action words like "run" or "create".
        question_phrases = (
            "how to ", "how do ", "how can ", "how does ", "how should ",
            "what is ", "what are ", "what does ", "what do ",
            "why is ", "why does ", "why do ",
            "when should ", "when do ", "when does ",
            "where is ", "where do ", "where does ",
            "can i ", "can you ", "could i ", "could you ",
            "should i ", "would you ", "is there ", "is it ",
            "show me how", "tell me how", "explain how",
            "steps to ", "guide ", "tutorial ", "instructions ",
            "what's the ", "whats the ",
        )
        if any(lower.startswith(p) or p in lower for p in question_phrases):
            # Exception: imperative commands embedded in questions like
            # "can you fix the bug" or "can you create a file" are actions.
            imperative_overrides = (
                "can you fix", "can you edit", "can you create",
                "can you write", "can you add", "can you remove",
                "can you delete", "can you change", "can you modify",
                "can you refactor", "can you run", "can you execute",
                "could you fix", "could you edit", "could you create",
                "could you run", "would you fix", "would you create",
            )
            if any(imp in lower for imp in imperative_overrides):
                return "action"
            return "analysis"

        # Question words at the start of the sentence → analysis
        question_starts = ("what", "how", "why", "when", "where", "can", "could", "would", "should", "is ", "are ", "does ", "do ")
        if lower.startswith(question_starts):
            return "analysis"

        # ── Priority 2: Imperative action commands → action ─────────
        # These are direct commands: "run ruff", "fix the bug", "create a file"
        if any(phrase in lower for phrase in ["run ", "execute ", "fix ", "edit ", "create "]):
            return "action"

        # ── Priority 3: Keyword counting heuristic ──────────────────
        action_count = sum(1 for kw in _ACTION_KEYWORDS if kw in lower)
        analysis_count = sum(1 for kw in _ANALYSIS_KEYWORDS if kw in lower)

        if action_count > analysis_count:
            return "action"
        elif analysis_count > action_count:
            return "analysis"

        # Default to action for ambiguous queries (safer to have tool loop available)
        return "action"

    def _get_session_path(self) -> Path:
        return self.repo_path / ".localforge" / "chat_history.json"

    def _recent_messages(
        self, max_messages: int = 16,
    ) -> list[dict[str, Any]]:
        """Return the last *max_messages* from the session as dicts.

        Keeps the most recent messages so the model has immediate context
        without paying the prompt-eval cost of the entire conversation.
        """
        msgs = self.session.messages
        if len(msgs) <= max_messages:
            return [{"role": m.role, "content": m.content} for m in msgs]
        return [
            {"role": m.role, "content": m.content}
            for m in msgs[-max_messages:]
        ]

    def _append_project_rules(self, system_parts: list[str]) -> None:
        """Append .localforge/rules.md content to *system_parts[0]* in-place."""
        rules_path = self.repo_path / ".localforge" / "rules.md"
        if rules_path.is_file():
            try:
                rules_content = rules_path.read_text(encoding="utf-8").strip()
                lines = [
                    ln for ln in rules_content.splitlines()
                    if ln.strip() and not ln.strip().startswith("#")
                ]
                if lines:
                    system_parts[0] += f"\n\nPROJECT RULES:\n{rules_content}"
            except OSError:
                pass

    def _ensure_index(self) -> None:
        """Auto-index the repository if no index exists yet."""
        try:
            from localforge.index import RepositoryIndexer

            db_path = self.repo_path / self.config.index_db_path
            indexer = RepositoryIndexer(self.repo_path, db_path, self.config)
            try:
                if not indexer.is_initialized():
                    console.print("[yellow]No index found — indexing repository…[/yellow]")
                    stats = indexer.index_repository()
                    console.print(
                        f"[green]Indexed {stats['indexed']} files "
                        f"in {stats['duration_seconds']}s[/green]"
                    )
            finally:
                indexer.close()
        except Exception:
            logger.debug("Auto-index failed", exc_info=True)

    def _build_repo_map(self) -> str:
        """Build an intelligent repo map showing project structure and key definitions."""
        if self._repo_map_cache:
            return self._repo_map_cache

        _skip_dirs = {
            ".git", "node_modules", "__pycache__", ".venv", "venv",
            "dist", "build", ".localforge", ".tox", ".mypy_cache",
            ".pytest_cache", ".eggs", "*.egg-info",
        }

        has_focus = self.session.has_focus()
        if has_focus:
            lines: list[str] = [
                "PROJECT STRUCTURE (focused on: "
                + ", ".join(self.session.focus_paths) + "):"
            ]
        else:
            lines: list[str] = ["PROJECT STRUCTURE:"]
        file_count = 0
        max_files = 200

        for dirpath, dirnames, filenames in os.walk(self.repo_path):
            dirnames[:] = [
                d for d in sorted(dirnames)
                if d not in _skip_dirs and not d.startswith(".")
            ]
            try:
                rel = Path(dirpath).relative_to(self.repo_path)
            except ValueError:
                continue

            rel_posix = rel.as_posix() if rel.parts else ""

            # When focus is set, skip directories outside focus scope
            if has_focus and rel_posix:
                if not self._matches_focus(rel_posix):
                    # Check if any focus path is a child of this directory
                    is_ancestor = any(
                        fp.startswith(rel_posix.rstrip("/") + "/")
                        for fp in self.session.focus_paths
                    )
                    if not is_ancestor:
                        dirnames.clear()
                        continue

            depth = len(rel.parts)
            if depth > 5:
                continue

            indent = "  " * depth
            dir_name = rel.name if depth > 0 else str(self.repo_path.name)
            lines.append(f"{indent}{dir_name}/")

            for fname in sorted(filenames):
                if fname.startswith(".") or fname.endswith((".pyc", ".pyo")):
                    continue
                # When focused, only include files that match focus
                if has_focus:
                    file_rel = f"{rel_posix}/{fname}" if rel_posix else fname
                    if not self._matches_focus(file_rel):
                        continue
                file_count += 1
                if file_count > max_files:
                    lines.append(f"{indent}  ... (more files)")
                    break
                lines.append(f"{indent}  {fname}")

            if file_count > max_files:
                break

        # Add symbol overview from index if available
        try:
            from localforge.index import IndexSearcher

            db_path = self.repo_path / self.config.index_db_path
            if db_path.is_file():
                searcher = IndexSearcher(db_path)
                try:
                    conn = searcher._get_conn()
                    # Get top-level classes and functions
                    rows = conn.execute(
                        """
                        SELECT s.name, s.kind, s.line, f.relative_path
                          FROM symbols s
                          JOIN files f ON f.id = s.file_id
                         WHERE s.scope = 'module' OR s.kind IN ('class', 'interface')
                         ORDER BY f.relative_path, s.line
                         LIMIT 150
                        """
                    ).fetchall()

                    if rows:
                        lines.append("\nKEY DEFINITIONS:")
                        by_file: dict[str, list[str]] = {}
                        for row in rows:
                            fp = row["relative_path"]
                            # Filter symbols by focus paths
                            if has_focus and not self._matches_focus(fp):
                                continue
                            entry = f"  {row['kind']}: {row['name']} (L{row['line']})"
                            by_file.setdefault(fp, []).append(entry)
                        for fp, entries in sorted(by_file.items()):
                            lines.append(f"  {fp}")
                            lines.extend(entries[:10])
                finally:
                    searcher.close()
        except Exception:
            logger.debug("Could not load symbols for repo map", exc_info=True)

        # ── Inject tech stack + build/run intelligence ───────────
        stack_lines = self._detect_tech_stack()
        if stack_lines:
            lines.append("")
            lines.extend(stack_lines)

        self._repo_map_cache = "\n".join(lines)
        return self._repo_map_cache

    def _detect_tech_stack(self) -> list[str]:
        """Auto-detect the project's tech stack and useful commands.

        Reads config files (package.json, pyproject.toml, etc.) to figure
        out what frameworks/tools are used and what scripts are available.
        This gives the LLM the intelligence to know exactly which commands
        to run without guessing.
        """
        info: list[str] = ["PROJECT TECH STACK:"]
        has_any = False

        # ── package.json: scripts + frameworks ───────────────────
        pkg_path = self.repo_path / "package.json"
        if pkg_path.is_file():
            try:
                import json as _json
                pkg = _json.loads(pkg_path.read_text(encoding="utf-8"))

                # Detect frameworks
                all_deps = {}
                all_deps.update(pkg.get("dependencies", {}))
                all_deps.update(pkg.get("devDependencies", {}))

                fw: list[str] = []
                _fw_map = {
                    "react": "React", "next": "Next.js", "vue": "Vue.js",
                    "nuxt": "Nuxt", "@angular/core": "Angular",
                    "svelte": "Svelte", "@sveltejs/kit": "SvelteKit",
                    "astro": "Astro", "express": "Express.js",
                    "fastify": "Fastify", "@nestjs/core": "NestJS",
                    "electron": "Electron", "react-native": "React Native",
                    "expo": "Expo", "remix": "Remix",
                    "gatsby": "Gatsby", "solid-js": "Solid.js",
                    "ember-source": "Ember.js", "lit": "Lit",
                    "storybook": "Storybook", "vite": "Vite",
                    "webpack": "Webpack", "tailwindcss": "Tailwind CSS",
                    "three": "Three.js", "socket.io": "Socket.io",
                    "prisma": "Prisma", "drizzle-orm": "Drizzle ORM",
                    "mongoose": "Mongoose", "sequelize": "Sequelize",
                    "typeorm": "TypeORM",
                }
                for dep_key, fw_name in _fw_map.items():
                    if dep_key in all_deps:
                        fw.append(fw_name)
                if fw:
                    info.append(f"  JS/TS frameworks: {', '.join(fw)}")
                    has_any = True

                # Package manager
                if (self.repo_path / "pnpm-lock.yaml").is_file():
                    info.append("  Package manager: pnpm")
                elif (self.repo_path / "yarn.lock").is_file():
                    info.append("  Package manager: yarn")
                elif (self.repo_path / "bun.lockb").is_file():
                    info.append("  Package manager: bun")
                else:
                    info.append("  Package manager: npm")

                # Scripts (most important for knowing how to build/test/run)
                scripts = pkg.get("scripts", {})
                if scripts:
                    info.append("  Available scripts:")
                    for name, cmd in sorted(scripts.items()):
                        info.append(f"    npm run {name} → {cmd}")
                    has_any = True

            except (OSError, ValueError):
                pass

        # ── Python ───────────────────────────────────────────────
        if (self.repo_path / "pyproject.toml").is_file():
            info.append("  Python project (pyproject.toml)")
            has_any = True
            try:
                toml_text = (self.repo_path / "pyproject.toml").read_text(encoding="utf-8")
                if "django" in toml_text.lower():
                    info.append("    Framework: Django")
                elif "flask" in toml_text.lower():
                    info.append("    Framework: Flask")
                elif "fastapi" in toml_text.lower():
                    info.append("    Framework: FastAPI")
            except OSError:
                pass
        elif (self.repo_path / "setup.py").is_file() or (self.repo_path / "setup.cfg").is_file():
            info.append("  Python project (setup.py/setup.cfg)")
            has_any = True
        elif (self.repo_path / "requirements.txt").is_file():
            info.append("  Python project (requirements.txt)")
            has_any = True

        # ── Go ───────────────────────────────────────────────────
        if (self.repo_path / "go.mod").is_file():
            info.append("  Go project (go.mod)")
            info.append("    Build: go build ./... | Test: go test ./...")
            has_any = True

        # ── Rust ─────────────────────────────────────────────────
        if (self.repo_path / "Cargo.toml").is_file():
            info.append("  Rust project (Cargo.toml)")
            info.append("    Build: cargo build | Test: cargo test | Lint: cargo clippy")
            has_any = True

        # ── Java ─────────────────────────────────────────────────
        if (self.repo_path / "pom.xml").is_file():
            info.append("  Java project (Maven)")
            info.append("    Build: mvn compile | Test: mvn test")
            has_any = True
        elif (self.repo_path / "build.gradle").is_file() or (self.repo_path / "build.gradle.kts").is_file():
            gradle_cmd = "gradle"
            if (self.repo_path / "gradlew").is_file():
                gradle_cmd = "./gradlew"
            elif (self.repo_path / "gradlew.bat").is_file():
                gradle_cmd = "gradlew.bat"
            info.append("  Java/Kotlin project (Gradle)")
            info.append(f"    Build: {gradle_cmd} build | Test: {gradle_cmd} test")
            has_any = True

        # ── .NET ─────────────────────────────────────────────────
        if any(self.repo_path.glob("*.sln")) or any(self.repo_path.glob("*.csproj")):
            info.append("  .NET / C# project")
            info.append("    Build: dotnet build | Test: dotnet test")
            has_any = True

        # ── Ruby ─────────────────────────────────────────────────
        if (self.repo_path / "Gemfile").is_file():
            info.append("  Ruby project")
            if (self.repo_path / "config" / "routes.rb").is_file():
                info.append("    Framework: Ruby on Rails")
                info.append("    Test: bundle exec rails test")
            has_any = True

        # ── PHP ──────────────────────────────────────────────────
        if (self.repo_path / "composer.json").is_file():
            info.append("  PHP project (Composer)")
            has_any = True
            try:
                cj = (self.repo_path / "composer.json").read_text(encoding="utf-8")
                if "laravel" in cj.lower():
                    info.append("    Framework: Laravel")
                    info.append("    Test: php artisan test")
                elif "symfony" in cj.lower():
                    info.append("    Framework: Symfony")
            except OSError:
                pass

        # ── Makefile ─────────────────────────────────────────────
        if (self.repo_path / "Makefile").is_file():
            try:
                makefile = (self.repo_path / "Makefile").read_text(encoding="utf-8", errors="replace")
                import re as _re
                targets = _re.findall(r'^([a-zA-Z_][\w-]*)\s*:', makefile, _re.MULTILINE)
                if targets:
                    info.append(f"  Makefile targets: {', '.join(targets[:15])}")
                    has_any = True
            except OSError:
                pass

        # ── Docker ───────────────────────────────────────────────
        if (self.repo_path / "Dockerfile").is_file():
            info.append("  Containerized (Dockerfile)")
            has_any = True
        if (self.repo_path / "docker-compose.yml").is_file() or (self.repo_path / "docker-compose.yaml").is_file():
            info.append("  Docker Compose available")
            has_any = True

        return info if has_any else []

    def load_session(self) -> bool:
        """Try to load a previous chat session. Returns True if loaded."""
        path = self._get_session_path()
        if path.is_file():
            try:
                self.session = ChatSession.load(path)
                return True
            except Exception:
                logger.debug("Could not load chat session", exc_info=True)
        return False

    def save_session(self) -> None:
        self.session.save(self._get_session_path())

    def _build_context(self, query: str, limit: int = 8) -> str:
        """Retrieve relevant codebase context for the user's query."""
        try:
            from localforge.index import IndexSearcher, RepositoryIndexer
            from localforge.retrieval import ContextRetriever

            db_path = self.repo_path / self.config.index_db_path
            if not db_path.is_file():
                # Try auto-indexing first
                self._ensure_index()
                if not db_path.is_file():
                    return ""

            indexer = RepositoryIndexer(self.repo_path, db_path, self.config)
            searcher = IndexSearcher(db_path)
            try:
                retriever = ContextRetriever(indexer, searcher, self.config)
                # Pass focus paths so retrieval is scoped when set.
                focus = self.session.focus_paths if self.session.has_focus() else None
                result = retriever.retrieve(query, limit=max(1, limit), focus_paths=focus)
                if not result.chunks:
                    return ""

                parts: list[str] = []
                for chunk in result.chunks:
                    parts.append(
                        f"--- {chunk.file_path} (L{chunk.start_line}-{chunk.end_line}) ---\n"
                        f"{chunk.content}"
                    )
                return "\n\n".join(parts)
            finally:
                searcher.close()
                indexer.close()
        except Exception:
            logger.debug("Context retrieval failed", exc_info=True)
            return ""

    @classmethod
    def _is_fast_action_query(cls, user_input: str) -> bool:
        """Return True when query is likely a SIMPLE, single-step command.

        Returns False when the user clearly asks for follow-up work (fix,
        edit, change, refactor…) because those need the full tool set,
        repo map, and more context.
        """
        lower = user_input.lower().strip()
        if not lower.startswith(cls._FAST_ACTION_PREFIXES):
            return False

        # If the prompt also requests edits / fixes, it's a multi-step task
        # and must NOT be treated as a fast action.
        complex_signals = (
            "fix", "edit", "change", "modify", "refactor", "update",
            "rewrite", "add", "remove", "delete", "replace", "apply",
            "resolve", "correct", "patch", "all issues", "all errors",
            "and then", "after that",
        )
        if any(sig in lower for sig in complex_signals):
            return False

        # Typical verification/lint/test commands should not pay the cost of
        # loading repo map + retrieved chunks before first tool call.
        command_hints = (
            # Python
            "ruff", "pytest", "mypy", "black", "isort", "flake8",
            "pip ", "poetry ", "pdm ",
            # JavaScript/TypeScript
            "npm ", "pnpm ", "yarn ", "npx ", "node ",
            "eslint", "prettier", "tsc", "jest", "vitest",
            # Go
            "go test", "go build", "go run", "go vet",
            # Rust
            "cargo", "rustc",
            # Java
            "mvn", "gradle", "gradlew",
            # .NET
            "dotnet",
            # Ruby
            "bundle", "rake", "rails", "rspec", "rubocop",
            # PHP
            "php ", "composer", "phpunit",
            # General
            "make", "cmake",
        )
        return any(h in lower for h in command_hints)

    @classmethod
    def _is_tool_driven_query(cls, user_input: str) -> bool:
        """Return True when query is tool-driven and doesn't need upfront context.

        For queries like 'run ruff check . and fix all issues', the model
        discovers what to fix through tool output (errors), not through
        repo context. Loading repo map + context just wastes tokens and
        slows prompt eval on small models.
        """
        lower = user_input.lower().strip()

        # Pattern: "run X and fix" / "check and fix" type queries
        tool_driven_patterns = (
            # Python
            "ruff", "lint", "flake8", "pylint", "mypy", "pytest", "test", "check",
            # JavaScript/TypeScript
            "eslint", "tsc", "jest", "vitest", "mocha", "prettier", "biome",
            "npm test", "npm run", "yarn test", "pnpm test",
            # Go
            "go test", "go vet", "golangci-lint",
            # Rust
            "cargo test", "cargo check", "cargo clippy",
            # Java
            "mvn test", "mvn compile", "gradle test", "gradle build",
            # .NET
            "dotnet test", "dotnet build",
            # Ruby
            "rspec", "rubocop", "bundle exec",
            # PHP
            "phpunit", "phpstan",
            # General
            "build", "compile",
        )
        action_patterns = ("fix", "resolve", "correct", "repair")

        has_tool = any(t in lower for t in tool_driven_patterns)
        has_fix = any(a in lower for a in action_patterns)

        # "run ruff check . and fix all issues" → tool-driven
        if has_tool and has_fix:
            return True

        # "fix all ruff issues" → tool-driven
        return lower.startswith(("fix ", "resolve ", "correct ")) and has_tool

    @classmethod
    def _is_scaffolding_query(cls, user_input: str) -> bool:
        """Return True when the user wants to build/create an entire project.

        For queries like 'build me a Flask todo app' or 'create a REST API',
        the model doesn't need repo context — it needs to scaffold from scratch.
        """
        lower = user_input.lower().strip()

        # Must have a creation intent
        creation_signals = (
            "build ", "create ", "make ", "scaffold ", "generate ",
            "set up ", "setup ", "initialize ", "init ", "bootstrap ",
            "start ", "new ", "from scratch",
        )
        has_creation = any(s in lower for s in creation_signals)
        if not has_creation:
            return False

        # Must mention an app/project/thing to build
        project_signals = (
            "app", "application", "project", "api", "website", "site",
            "server", "service", "bot", "cli", "tool", "library",
            "package", "module", "game", "dashboard", "frontend",
            "backend", "fullstack", "full-stack", "microservice",
            "crud", "rest", "graphql", "todo", "blog", "chat",
        )
        return any(s in lower for s in project_signals)

    @classmethod
    def _is_large_scaffolding_query(cls, user_input: str) -> bool:
        """Return True when the scaffolding request describes a large / multi-feature app.

        Signals: long prompts, multiple features mentioned, explicit
        comprehensiveness keywords, or enumerated feature lists.
        """
        lower = user_input.lower().strip()

        # Long prompt with many details → large app
        if len(lower) > 200:
            return True

        # Explicit comprehensiveness signals
        large_signals = (
            "complete ", "comprehensive ", "production", "full-featured",
            "full featured", "multiple feature", "multi-feature",
            "with authentication", "with auth", "with database",
            "with api", "with admin", "with dashboard",
            "with search", "with pagination", "with logging",
            "with tests", "with deployment",
        )
        if any(s in lower for s in large_signals):
            return True

        # Comma-separated or "and"-joined feature list (e.g., "users, posts, and comments")
        import re
        # Count commas and "and" in the prompt — 2+ features is a multi-feature app
        feature_list_pattern = re.findall(r',\s*(?:and\s+)?|\band\b', lower)
        if len(feature_list_pattern) >= 2:
            return True

        return False

    @classmethod
    def _is_debugging_query(cls, user_input: str) -> bool:
        """Return True when the user is describing a bug to fix.

        For queries like 'users can\'t login' or 'the app crashes when...',
        the model needs repo context to find the bug.
        """
        lower = user_input.lower().strip()

        bug_signals = (
            "bug", "crash", "error", "broken", "doesn't work",
            "doesnt work", "not working", "fails", "failing",
            "issue", "problem", "wrong", "unexpected",
            "can't", "cant", "cannot", "won't", "wont",
            "exception", "traceback", "stack trace", "segfault",
        )
        return any(s in lower for s in bug_signals)

    @classmethod
    def _is_check_and_fix_query(cls, user_input: str) -> bool:
        """Return True when user wants to check for issues and fix them.

        Matches patterns like:
        - "check if there are any issues in this file and fix it"
        - "find and fix problems"
        - "review this file for errors and correct them"
        - "look for issues and fix them"
        """
        lower = user_input.lower().strip()

        check_signals = (
            "check", "review", "look for", "find", "scan", "inspect",
            "examine", "analyze", "analyse", "audit", "diagnose",
            "any issues", "any problems", "any errors", "any bugs",
        )
        fix_signals = (
            "fix", "correct", "repair", "resolve", "patch",
            "and fix", "then fix", "and correct", "and resolve",
        )
        has_check = any(s in lower for s in check_signals)
        has_fix = any(s in lower for s in fix_signals)
        return has_check and has_fix

    @classmethod
    def _is_test_fix_query(cls, user_input: str) -> bool:
        """Return True when the user wants to run tests and fix failures.

        For queries like "pytest tests/ fails, fix it" or "5 tests fail in
        test_enhancements.py, investigate and fix", the LLM should run the
        tests FIRST (lean context, fast start) instead of loading the full
        repo map and context upfront.  The test output itself tells the
        model exactly what is broken, making pre-loaded context wasteful.

        This dramatically reduces first-token latency for test-driven
        debugging — from minutes (heavy context) to seconds (lean start).
        """
        lower = user_input.lower().strip()

        # Must mention tests / test tooling
        test_signals = (
            "test", "pytest", "unittest", "jest", "vitest", "mocha",
            "rspec", "phpunit", "go test", "cargo test", "dotnet test",
            "mvn test", "gradle test", "npm test", "yarn test", "pnpm test",
            "test_", "_test.py", "test.py", "spec.js", "spec.ts",
        )
        has_test = any(s in lower for s in test_signals)
        if not has_test:
            return False

        # Must mention failures / fixing
        failure_signals = (
            "fail", "failing", "broken", "error", "issue", "fix",
            "investigate", "debug", "resolve", "broken", "wrong",
            "not passing", "doesn't pass", "doesnt pass",
        )
        return any(s in lower for s in failure_signals)

    def _run_preflight_diagnostics(self, focused_files: list[Path]) -> str:
        """Run fast syntax/compile checks on focused files BEFORE the LLM.

        Also validates import chains to catch multi-file dependency bugs.
        Returns a diagnostic string to inject into the system prompt.
        This lets the LLM skip the "find the error" phase and go straight
        to fixing, which is the #1 speed improvement for simple bugs.
        """
        diagnostics: list[str] = []
        _EXT_CHECKERS: dict[str, list[list[str]]] = {
            ".py": [],   # handled via ast.parse (no subprocess needed)
            ".js": [["node", "--check"]],
            ".ts": [["npx", "tsc", "--noEmit", "--pretty"]],
            ".jsx": [["node", "--check"]],
            ".tsx": [["npx", "tsc", "--noEmit", "--pretty"]],
            ".rb": [["ruby", "-c"]],
            ".php": [["php", "-l"]],
            ".go": [["gofmt", "-e"]],
        }

        py_files_checked: list[Path] = []

        for fpath in focused_files:
            if not fpath.is_file():
                continue
            suffix = fpath.suffix.lower()
            rel = fpath.relative_to(self.repo_path).as_posix()

            # Python: use ast.parse (fast, no subprocess)
            if suffix == ".py":
                try:
                    source = fpath.read_text(encoding="utf-8", errors="replace")
                    ast.parse(source, filename=rel)
                    py_files_checked.append(fpath)
                except SyntaxError as e:
                    line_info = f" (line {e.lineno})" if e.lineno else ""
                    text_info = ""
                    if e.text:
                        text_info = f"\n    Code: {e.text.rstrip()}"
                    diagnostics.append(
                        f"SYNTAX ERROR in {rel}{line_info}: {e.msg}{text_info}"
                    )
                except Exception:
                    pass
                continue

            # JSON validation
            if suffix == ".json":
                try:
                    source = fpath.read_text(encoding="utf-8", errors="replace")
                    json.loads(source)
                except json.JSONDecodeError as e:
                    diagnostics.append(
                        f"JSON ERROR in {rel} (line {e.lineno}): {e.msg}"
                    )
                continue

            # External tool checks (best-effort, skip if tool not found)
            checkers = _EXT_CHECKERS.get(suffix, [])
            for cmd_parts in checkers:
                try:
                    result = subprocess.run(
                        [*cmd_parts, str(fpath)],
                        capture_output=True, text=True, timeout=10,
                        cwd=str(self.repo_path),
                    )
                    if result.returncode != 0:
                        stderr = (result.stderr or result.stdout or "").strip()
                        if stderr:
                            # Take first 3 lines of error output
                            error_lines = stderr.splitlines()[:3]
                            diagnostics.append(
                                f"COMPILE ERROR in {rel}:\n    "
                                + "\n    ".join(error_lines)
                            )
                except (FileNotFoundError, subprocess.TimeoutExpired):
                    pass  # Tool not installed, skip silently

        # ── Python import chain validation ───────────────────────
        # For Python files that parse OK, check if their imports resolve.
        # This catches the common multi-file bug: "ImportError: cannot import
        # name 'Foo' from 'bar'" which means a dependency file changed.
        for fpath in py_files_checked:
            self._check_python_imports(fpath, diagnostics)

        # ── JS/TS import validation ──────────────────────────────
        js_ts_files = [
            f for f in focused_files
            if f.is_file() and f.suffix.lower() in (".js", ".ts", ".jsx", ".tsx", ".mjs", ".mts")
        ]
        for fpath in js_ts_files:
            self._check_js_ts_imports(fpath, diagnostics)

        # ── Quick test collect checks (all stacks) ───────────────
        # Python: pytest --collect-only
        test_files = [
            f for f in py_files_checked
            if f.name.startswith("test_") or f.name.endswith("_test.py")
        ]
        if test_files and not diagnostics:
            self._check_pytest_collect(test_files, diagnostics)

        # Go: go build (fast compile check)
        go_files = [f for f in focused_files if f.is_file() and f.suffix.lower() == ".go"]
        if go_files and not diagnostics:
            self._check_go_build(diagnostics)

        # Rust: cargo check (fast compile check)
        rs_files = [f for f in focused_files if f.is_file() and f.suffix.lower() == ".rs"]
        if rs_files and not diagnostics:
            self._check_cargo(diagnostics)

        # Java: mvn compile / gradle build
        java_files = [f for f in focused_files if f.is_file() and f.suffix.lower() == ".java"]
        if java_files and not diagnostics:
            self._check_java_build(diagnostics)

        # .NET: dotnet build
        cs_files = [f for f in focused_files if f.is_file() and f.suffix.lower() == ".cs"]
        if cs_files and not diagnostics:
            self._check_dotnet_build(diagnostics)

        if not diagnostics:
            return ""

        header = "PRE-FLIGHT DIAGNOSTICS — ERRORS FOUND:"
        return header + "\n" + "\n".join(diagnostics)

    def _check_python_imports(self, fpath: Path, diagnostics: list[str]) -> None:
        """Validate that imports in a Python file resolve to existing names.

        Checks:
        1. 'from X import Y' — does module X exist and does it export Y?
        2. 'import X' — does module X resolve to a file in the repo?
        """
        try:
            source = fpath.read_text(encoding="utf-8", errors="replace")
            tree = ast.parse(source, filename=str(fpath))
        except Exception:
            return

        rel = fpath.relative_to(self.repo_path).as_posix()

        for node in ast.walk(tree):
            if not isinstance(node, ast.ImportFrom) or not node.module:
                continue

            # Only check local (repo) imports
            resolved_file = self._resolve_import_to_file(node.module)
            if not resolved_file:
                continue  # External/third-party import — skip

            # Check if the resolved file actually exports the requested names
            resolved_path = self.repo_path / resolved_file
            try:
                dep_source = resolved_path.read_text(encoding="utf-8", errors="replace")
                dep_tree = ast.parse(dep_source, filename=resolved_file)
            except SyntaxError as e:
                # The dependency file itself has a syntax error!
                line_info = f" (line {e.lineno})" if e.lineno else ""
                diagnostics.append(
                    f"DEPENDENCY SYNTAX ERROR: {rel} imports from {resolved_file}, "
                    f"but {resolved_file} has a syntax error{line_info}: {e.msg}"
                )
                continue
            except Exception:
                continue

            # Get all top-level names defined in the dependency
            exported_names = set()
            for dep_node in ast.iter_child_nodes(dep_tree):
                if isinstance(dep_node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    exported_names.add(dep_node.name)
                elif isinstance(dep_node, ast.ClassDef):
                    exported_names.add(dep_node.name)
                elif isinstance(dep_node, ast.Assign):
                    for target in dep_node.targets:
                        if isinstance(target, ast.Name):
                            exported_names.add(target.id)
                elif isinstance(dep_node, ast.AnnAssign) and isinstance(dep_node.target, ast.Name):
                    exported_names.add(dep_node.target.id)
                elif isinstance(dep_node, ast.ImportFrom):
                    # Re-exported names: from x import Y -> Y is available
                    for alias in (dep_node.names or []):
                        name = alias.asname if alias.asname else alias.name
                        exported_names.add(name)
                elif isinstance(dep_node, ast.Import):
                    for alias in dep_node.names:
                        name = alias.asname if alias.asname else alias.name
                        exported_names.add(name)

            # Check if __init__.py might re-export from submodules
            if resolved_file.endswith("__init__.py"):
                # __init__.py files may use __all__ or re-export
                for dep_node in ast.walk(dep_tree):
                    if isinstance(dep_node, ast.Assign):
                        for t in dep_node.targets:
                            if isinstance(t, ast.Name) and t.id == "__all__":
                                if isinstance(dep_node.value, (ast.List, ast.Tuple)):
                                    for elt in dep_node.value.elts:
                                        if isinstance(elt, ast.Constant):
                                            exported_names.add(elt.value)

            # Now check each name that the focused file imports
            for alias in (node.names or []):
                if alias.name == "*":
                    continue  # Can't validate star imports
                if alias.name not in exported_names:
                    diagnostics.append(
                        f"IMPORT ERROR in {rel} (line {node.lineno}): "
                        f"'{alias.name}' is not defined in {resolved_file}. "
                        f"Available names: {', '.join(sorted(exported_names)[:15])}"
                    )

    def _check_pytest_collect(self, test_files: list[Path], diagnostics: list[str]) -> None:
        """Run 'pytest --collect-only' on test files to catch import errors.

        This is fast (no actual test execution) and catches dependency
        chain errors that ast.parse alone cannot detect.
        """
        rel_paths = []
        for f in test_files[:5]:  # Limit to 5 files for speed
            try:
                rel_paths.append(str(f.relative_to(self.repo_path)))
            except ValueError:
                continue

        if not rel_paths:
            return

        try:
            result = subprocess.run(
                ["python", "-m", "pytest", "--collect-only", "-q", *rel_paths],
                capture_output=True, text=True, timeout=15,
                cwd=str(self.repo_path),
            )
            if result.returncode != 0:
                stderr = (result.stderr or "").strip()
                stdout = (result.stdout or "").strip()
                error_output = stderr or stdout
                if error_output and ("Error" in error_output or "error" in error_output):
                    # Extract the most relevant error lines
                    error_lines = error_output.splitlines()
                    # Find lines with ImportError, ModuleNotFoundError, etc.
                    key_errors = [
                        ln for ln in error_lines
                        if any(e in ln for e in (
                            "ImportError", "ModuleNotFoundError",
                            "SyntaxError", "NameError", "AttributeError",
                        ))
                    ]
                    if key_errors:
                        diagnostics.append(
                            "IMPORT CHAIN ERROR (from pytest --collect-only):\n    "
                            + "\n    ".join(key_errors[:5])
                        )
                    elif len(error_lines) <= 5:
                        diagnostics.append(
                            "TEST COLLECT ERROR:\n    "
                            + "\n    ".join(error_lines)
                        )
                    else:
                        # Show first and last few lines
                        diagnostics.append(
                            "TEST COLLECT ERROR:\n    "
                            + "\n    ".join(error_lines[:3])
                            + "\n    ..."
                            + "\n    ".join(error_lines[-2:])
                        )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass  # pytest not installed or too slow, skip

    def _check_js_ts_imports(self, fpath: Path, diagnostics: list[str]) -> None:
        """Validate JS/TS imports resolve to existing files.

        Checks import/require statements and verifies the referenced
        file exists in the repo. Catches broken imports fast.
        """
        import re as _re
        try:
            source = fpath.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return

        rel = fpath.relative_to(self.repo_path).as_posix()
        fdir = fpath.parent

        # Match: import X from './path', import './path', require('./path')
        # Only check relative imports (starting with ./ or ../)
        import_patterns = [
            _re.compile(r'''import\s+.*?from\s+['"](\.\.?/[^'"]+)['"]'''),
            _re.compile(r'''import\s+['"](\.\.?/[^'"]+)['"]'''),
            _re.compile(r'''require\s*\(\s*['"](\.\.?/[^'"]+)['"]\s*\)'''),
            _re.compile(r'''export\s+.*?from\s+['"](\.\.?/[^'"]+)['"]'''),
        ]

        checked: set[str] = set()
        for line_no, line in enumerate(source.splitlines(), 1):
            for pattern in import_patterns:
                for match in pattern.finditer(line):
                    import_path = match.group(1)
                    if import_path in checked:
                        continue
                    checked.add(import_path)

                    # Resolve relative to current file
                    resolved = fdir / import_path
                    # Try common extensions
                    candidates = [
                        resolved,
                        resolved.with_suffix(".js"),
                        resolved.with_suffix(".ts"),
                        resolved.with_suffix(".jsx"),
                        resolved.with_suffix(".tsx"),
                        resolved.with_suffix(".mjs"),
                        resolved / "index.js",
                        resolved / "index.ts",
                        resolved / "index.tsx",
                    ]
                    found = any(c.is_file() for c in candidates)
                    if not found:
                        diagnostics.append(
                            f"IMPORT ERROR in {rel} (line {line_no}): "
                            f"'{import_path}' does not resolve to any file. "
                            f"Checked: {import_path}[.js|.ts|.jsx|.tsx|/index.*]"
                        )

    def _check_go_build(self, diagnostics: list[str]) -> None:
        """Run 'go build ./...' for fast Go compile check."""
        if not (self.repo_path / "go.mod").is_file():
            return
        try:
            result = subprocess.run(
                ["go", "build", "./..."],
                capture_output=True, text=True, timeout=30,
                cwd=str(self.repo_path),
            )
            if result.returncode != 0:
                stderr = (result.stderr or "").strip()
                if stderr:
                    error_lines = stderr.splitlines()[:5]
                    diagnostics.append(
                        "GO BUILD ERROR:\n    " + "\n    ".join(error_lines)
                    )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

    def _check_cargo(self, diagnostics: list[str]) -> None:
        """Run 'cargo check' for fast Rust compile check."""
        if not (self.repo_path / "Cargo.toml").is_file():
            return
        try:
            result = subprocess.run(
                ["cargo", "check", "--message-format=short"],
                capture_output=True, text=True, timeout=60,
                cwd=str(self.repo_path),
            )
            if result.returncode != 0:
                stderr = (result.stderr or "").strip()
                if stderr:
                    # Filter to actual error lines (skip warnings for speed)
                    error_lines = [
                        ln for ln in stderr.splitlines()
                        if "error" in ln.lower()
                    ][:5]
                    if not error_lines:
                        error_lines = stderr.splitlines()[:5]
                    diagnostics.append(
                        "RUST CHECK ERROR:\n    " + "\n    ".join(error_lines)
                    )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

    def _check_java_build(self, diagnostics: list[str]) -> None:
        """Run Maven or Gradle compile check for Java."""
        if (self.repo_path / "pom.xml").is_file():
            try:
                result = subprocess.run(
                    ["mvn", "compile", "-q", "-T", "1C"],
                    capture_output=True, text=True, timeout=60,
                    cwd=str(self.repo_path),
                )
                if result.returncode != 0:
                    output = (result.stderr or result.stdout or "").strip()
                    if output:
                        error_lines = [
                            ln for ln in output.splitlines()
                            if "ERROR" in ln or "error:" in ln.lower()
                        ][:5]
                        if not error_lines:
                            error_lines = output.splitlines()[:5]
                        diagnostics.append(
                            "JAVA COMPILE ERROR:\n    " + "\n    ".join(error_lines)
                        )
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass
        elif (self.repo_path / "build.gradle").is_file() or (self.repo_path / "build.gradle.kts").is_file():
            gradle_cmd = "gradle"
            if (self.repo_path / "gradlew").is_file():
                gradle_cmd = "./gradlew"
            elif (self.repo_path / "gradlew.bat").is_file():
                gradle_cmd = "gradlew.bat"
            try:
                result = subprocess.run(
                    [gradle_cmd, "compileJava", "-q"],
                    capture_output=True, text=True, timeout=60,
                    cwd=str(self.repo_path),
                )
                if result.returncode != 0:
                    output = (result.stderr or result.stdout or "").strip()
                    if output:
                        error_lines = output.splitlines()[:5]
                        diagnostics.append(
                            "JAVA BUILD ERROR:\n    " + "\n    ".join(error_lines)
                        )
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass

    def _check_dotnet_build(self, diagnostics: list[str]) -> None:
        """Run 'dotnet build' for .NET/C# compile check."""
        try:
            result = subprocess.run(
                ["dotnet", "build", "--no-restore", "-v", "q"],
                capture_output=True, text=True, timeout=60,
                cwd=str(self.repo_path),
            )
            if result.returncode != 0:
                output = (result.stderr or result.stdout or "").strip()
                if output:
                    error_lines = [
                        ln for ln in output.splitlines()
                        if "error " in ln.lower()
                    ][:5]
                    if not error_lines:
                        error_lines = output.splitlines()[:5]
                    diagnostics.append(
                        ".NET BUILD ERROR:\n    " + "\n    ".join(error_lines)
                    )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

    def _run_project_quick_check(self) -> str:
        """Run a fast project-wide check to find errors without focus.

        Uses 'pytest --collect-only' (Python) or similar quick checks
        for other stacks to surface import/syntax errors across the codebase.
        """
        diagnostics: list[str] = []

        # Try pytest --collect-only for Python projects
        if (self.repo_path / "pyproject.toml").is_file() or any(
            self.repo_path.glob("tests/*.py")
        ):
            try:
                result = subprocess.run(
                    ["python", "-m", "pytest", "--collect-only", "-q",
                     "--no-header", "--tb=line"],
                    capture_output=True, text=True, timeout=20,
                    cwd=str(self.repo_path),
                )
                if result.returncode != 0:
                    stderr = (result.stderr or "").strip()
                    stdout = (result.stdout or "").strip()
                    error_output = stderr or stdout
                    if error_output:
                        error_lines = error_output.splitlines()
                        key_errors = [
                            ln for ln in error_lines
                            if any(e in ln for e in (
                                "ImportError", "ModuleNotFoundError",
                                "SyntaxError", "NameError", "AttributeError",
                                "ERRORS", "ERROR",
                            ))
                        ]
                        if key_errors:
                            diagnostics.append(
                                "PROJECT-WIDE ERRORS (from pytest --collect-only):\n  "
                                + "\n  ".join(key_errors[:8])
                            )
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass

        # For Node.js projects, try tsc --noEmit (quick type check)
        if not diagnostics and (self.repo_path / "tsconfig.json").is_file():
            try:
                result = subprocess.run(
                    ["npx", "tsc", "--noEmit", "--pretty", "false"],
                    capture_output=True, text=True, timeout=30,
                    cwd=str(self.repo_path),
                )
                if result.returncode != 0:
                    stdout = (result.stdout or "").strip()
                    if stdout:
                        error_lines = stdout.splitlines()[:8]
                        diagnostics.append(
                            "TYPESCRIPT ERRORS (from tsc --noEmit):\n  "
                            + "\n  ".join(error_lines)
                        )
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass

        # Go: go build ./...
        if not diagnostics and (self.repo_path / "go.mod").is_file():
            try:
                result = subprocess.run(
                    ["go", "build", "./..."],
                    capture_output=True, text=True, timeout=30,
                    cwd=str(self.repo_path),
                )
                if result.returncode != 0:
                    stderr = (result.stderr or "").strip()
                    if stderr:
                        diagnostics.append(
                            "GO BUILD ERRORS:\n  "
                            + "\n  ".join(stderr.splitlines()[:8])
                        )
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass

        # Rust: cargo check
        if not diagnostics and (self.repo_path / "Cargo.toml").is_file():
            try:
                result = subprocess.run(
                    ["cargo", "check", "--message-format=short"],
                    capture_output=True, text=True, timeout=60,
                    cwd=str(self.repo_path),
                )
                if result.returncode != 0:
                    stderr = (result.stderr or "").strip()
                    if stderr:
                        error_lines = [
                            ln for ln in stderr.splitlines()
                            if "error" in ln.lower()
                        ][:8]
                        if error_lines:
                            diagnostics.append(
                                "RUST ERRORS:\n  " + "\n  ".join(error_lines)
                            )
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass

        # Java: mvn compile or gradle compileJava
        if not diagnostics:
            if (self.repo_path / "pom.xml").is_file():
                try:
                    result = subprocess.run(
                        ["mvn", "compile", "-q"],
                        capture_output=True, text=True, timeout=60,
                        cwd=str(self.repo_path),
                    )
                    if result.returncode != 0:
                        output = (result.stderr or result.stdout or "").strip()
                        if output:
                            error_lines = [
                                ln for ln in output.splitlines()
                                if "ERROR" in ln or "error:" in ln.lower()
                            ][:8]
                            if error_lines:
                                diagnostics.append(
                                    "JAVA COMPILE ERRORS:\n  " + "\n  ".join(error_lines)
                                )
                except (FileNotFoundError, subprocess.TimeoutExpired):
                    pass

        # .NET: dotnet build
        if not diagnostics and (
            any(self.repo_path.glob("*.csproj")) or any(self.repo_path.glob("*.sln"))
        ):
            try:
                result = subprocess.run(
                    ["dotnet", "build", "--no-restore", "-v", "q"],
                    capture_output=True, text=True, timeout=60,
                    cwd=str(self.repo_path),
                )
                if result.returncode != 0:
                    output = (result.stderr or result.stdout or "").strip()
                    if output:
                        error_lines = [
                            ln for ln in output.splitlines()
                            if "error " in ln.lower()
                        ][:8]
                        if error_lines:
                            diagnostics.append(
                                ".NET BUILD ERRORS:\n  " + "\n  ".join(error_lines)
                            )
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass

        if not diagnostics:
            return ""

        return "PRE-FLIGHT DIAGNOSTICS — ERRORS FOUND:\n" + "\n".join(diagnostics)

    def _analyze_imports_and_dependencies(self, focused_files: list[Path]) -> str:
        """Analyze import chains for focused files — both forward and reverse.

        Forward deps: what focused files import (so the LLM checks those too).
        Reverse deps: what OTHER files in the repo import from focused files
        (critical for multi-file bugs — a change in file A breaks file B).
        Also tracks specific imported names for precise error diagnosis.

        Returns a dependency summary the LLM uses to fix cross-file bugs fast.
        """
        dep_info: list[str] = []
        focused_rel_paths = set()

        # Map focused files to their module paths for reverse-dep matching
        focused_modules: dict[str, str] = {}  # module_path -> rel_path
        for fpath in focused_files:
            if fpath.suffix != ".py" or not fpath.is_file():
                continue
            rel = fpath.relative_to(self.repo_path).as_posix()
            focused_rel_paths.add(rel)
            # Convert file path to Python module path
            # e.g. localforge/chat/tools.py -> localforge.chat.tools
            mod_path = rel.replace("/", ".").removesuffix(".py")
            if mod_path.endswith(".__init__"):
                mod_path = mod_path.removesuffix(".__init__")
            focused_modules[mod_path] = rel

        # ── Forward deps: what focused files import ──────────────
        for fpath in focused_files:
            if fpath.suffix != ".py" or not fpath.is_file():
                continue
            try:
                source = fpath.read_text(encoding="utf-8", errors="replace")
                tree = ast.parse(source, filename=str(fpath))
            except (SyntaxError, Exception):
                continue

            rel = fpath.relative_to(self.repo_path).as_posix()
            local_imports: list[str] = []
            named_imports: list[str] = []

            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        resolved = self._resolve_import_to_file(alias.name)
                        if resolved:
                            local_imports.append(resolved)
                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        resolved = self._resolve_import_to_file(node.module)
                        if resolved:
                            local_imports.append(resolved)
                            # Track specific names imported
                            names = [a.name for a in (node.names or [])]
                            if names:
                                named_imports.append(
                                    f"from {node.module} imports: {', '.join(names)}"
                                )

            if local_imports:
                dep_info.append(
                    f"  {rel} depends on: {', '.join(sorted(set(local_imports)))}"
                )
            if named_imports:
                for ni in sorted(set(named_imports)):
                    dep_info.append(f"    {ni}")

        # ── Reverse deps: what imports focused files ─────────────
        if focused_modules:
            reverse_deps = self._find_reverse_dependencies(focused_modules)
            if reverse_deps:
                dep_info.append("")
                dep_info.append("  FILES THAT IMPORT FROM FOCUSED FILES (may be affected):")
                # Deduplicate: merge imports from the same file+module
                seen: dict[tuple[str, str], set[str]] = {}
                for importer_rel, imported_module, names in reverse_deps:
                    key = (importer_rel, imported_module)
                    if key not in seen:
                        seen[key] = set()
                    seen[key].update(names)
                for (importer_rel, imported_module), names in sorted(seen.items()):
                    if names:
                        dep_info.append(
                            f"    {importer_rel} imports {', '.join(sorted(names))} from {imported_module}"
                        )
                    else:
                        dep_info.append(
                            f"    {importer_rel} imports {imported_module}"
                        )

        # ── JS/TS forward dependency analysis ────────────────────
        js_ts_exts = {".js", ".ts", ".jsx", ".tsx", ".mjs", ".mts"}
        focused_js_ts = [
            f for f in focused_files
            if f.is_file() and f.suffix.lower() in js_ts_exts
        ]
        for fpath in focused_js_ts:
            js_deps = self._analyze_js_ts_file_deps(fpath)
            if js_deps:
                rel = fpath.relative_to(self.repo_path).as_posix()
                dep_info.append(f"  {rel} depends on: {', '.join(js_deps)}")

        # ── JS/TS reverse dependency analysis ────────────────────
        if focused_js_ts:
            js_reverse = self._find_js_ts_reverse_dependencies(focused_js_ts)
            if js_reverse:
                if not any("FILES THAT IMPORT" in d for d in dep_info):
                    dep_info.append("")
                    dep_info.append("  FILES THAT IMPORT FROM FOCUSED FILES (may be affected):")
                for importer_rel, imported_file in js_reverse:
                    dep_info.append(
                        f"    {importer_rel} imports from {imported_file}"
                    )

        if not dep_info:
            return ""
        return "FILE DEPENDENCIES:\n" + "\n".join(dep_info)

    def _resolve_import_to_file(self, module_path: str) -> str | None:
        """Resolve a Python module path to a relative file path in the repo."""
        parts = module_path.replace(".", "/")
        candidates = [
            self.repo_path / f"{parts}.py",
            self.repo_path / parts / "__init__.py",
        ]
        for c in candidates:
            if c.is_file():
                return c.relative_to(self.repo_path).as_posix()
        return None

    def _find_reverse_dependencies(
        self,
        focused_modules: dict[str, str],
        max_files: int = 500,
    ) -> list[tuple[str, str, list[str]]]:
        """Find repo files that import from focused modules.

        Returns list of (importer_rel_path, imported_module, [imported_names]).
        Scans .py files in the repo quickly using AST parsing.
        """
        _skip_dirs = {
            ".git", "node_modules", "__pycache__", ".venv", "venv",
            "dist", "build", ".localforge", ".tox", ".mypy_cache",
            ".pytest_cache", ".eggs",
        }
        results: list[tuple[str, str, list[str]]] = []
        file_count = 0

        for dirpath, dirnames, filenames in os.walk(self.repo_path):
            dirnames[:] = [
                d for d in dirnames
                if d not in _skip_dirs and not d.startswith(".")
            ]
            for fname in filenames:
                if not fname.endswith(".py"):
                    continue
                fpath = Path(dirpath) / fname
                file_count += 1
                if file_count > max_files:
                    return results

                try:
                    rel = fpath.relative_to(self.repo_path).as_posix()
                except ValueError:
                    continue

                # Skip focused files themselves
                if rel in {v for v in focused_modules.values()}:
                    continue

                try:
                    source = fpath.read_text(encoding="utf-8", errors="replace")
                    tree = ast.parse(source, filename=rel)
                except (SyntaxError, UnicodeDecodeError, Exception):
                    continue

                for node in ast.walk(tree):
                    if isinstance(node, ast.Import):
                        for alias in node.names:
                            if alias.name in focused_modules:
                                results.append((rel, alias.name, []))
                    elif isinstance(node, ast.ImportFrom):
                        if node.module and node.module in focused_modules:
                            names = [a.name for a in (node.names or [])]
                            results.append((rel, node.module, names))
                        # Also check partial module matches
                        # e.g. "from localforge.chat import tools" matches "localforge.chat.tools"
                        elif node.module:
                            for fm in focused_modules:
                                if fm.startswith(node.module + "."):
                                    suffix = fm[len(node.module) + 1:]
                                    imported_names = [a.name for a in (node.names or [])]
                                    if suffix in imported_names:
                                        results.append((rel, fm, [suffix]))

        return results

    def _analyze_js_ts_file_deps(self, fpath: Path) -> list[str]:
        """Extract local file dependencies from a JS/TS file.

        Returns list of relative file paths that the file imports from.
        """
        import re as _re
        try:
            source = fpath.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return []

        fdir = fpath.parent
        deps: list[str] = []

        import_patterns = [
            _re.compile(r'''import\s+.*?from\s+['"](\.\.?/[^'"]+)['"]'''),
            _re.compile(r'''import\s+['"](\.\.?/[^'"]+)['"]'''),
            _re.compile(r'''require\s*\(\s*['"](\.\.?/[^'"]+)['"]\s*\)'''),
            _re.compile(r'''export\s+.*?from\s+['"](\.\.?/[^'"]+)['"]'''),
        ]

        seen: set[str] = set()
        for line in source.splitlines():
            for pattern in import_patterns:
                for match in pattern.finditer(line):
                    import_path = match.group(1)
                    if import_path in seen:
                        continue
                    seen.add(import_path)

                    resolved = fdir / import_path
                    for candidate in [
                        resolved, resolved.with_suffix(".js"),
                        resolved.with_suffix(".ts"), resolved.with_suffix(".tsx"),
                        resolved.with_suffix(".jsx"),
                        resolved / "index.js", resolved / "index.ts",
                        resolved / "index.tsx",
                    ]:
                        if candidate.is_file():
                            try:
                                deps.append(
                                    candidate.relative_to(self.repo_path).as_posix()
                                )
                            except ValueError:
                                pass
                            break
        return deps

    def _find_js_ts_reverse_dependencies(
        self,
        focused_files: list[Path],
        max_files: int = 500,
    ) -> list[tuple[str, str]]:
        """Find repo JS/TS files that import from focused JS/TS files.

        Returns list of (importer_rel_path, imported_focused_file_rel).
        """
        import re as _re
        _skip_dirs = {
            ".git", "node_modules", "__pycache__", ".venv", "venv",
            "dist", "build", ".localforge", ".next", ".nuxt",
            ".svelte-kit", "coverage", ".turbo",
        }
        js_ts_exts = {".js", ".ts", ".jsx", ".tsx", ".mjs", ".mts"}

        focused_paths = set()
        for f in focused_files:
            try:
                focused_paths.add(f.resolve())
            except (OSError, ValueError):
                pass

        import_patterns = [
            _re.compile(r'''import\s+.*?from\s+['"](\.\.?/[^'"]+)['"]'''),
            _re.compile(r'''import\s+['"](\.\.?/[^'"]+)['"]'''),
            _re.compile(r'''require\s*\(\s*['"](\.\.?/[^'"]+)['"]\s*\)'''),
            _re.compile(r'''export\s+.*?from\s+['"](\.\.?/[^'"]+)['"]'''),
        ]

        results: list[tuple[str, str]] = []
        file_count = 0

        for dirpath, dirnames, filenames in os.walk(self.repo_path):
            dirnames[:] = [
                d for d in dirnames
                if d not in _skip_dirs and not d.startswith(".")
            ]
            for fname in filenames:
                fpath = Path(dirpath) / fname
                if fpath.suffix.lower() not in js_ts_exts:
                    continue
                if fpath.resolve() in focused_paths:
                    continue
                file_count += 1
                if file_count > max_files:
                    return results

                try:
                    rel = fpath.relative_to(self.repo_path).as_posix()
                    source = fpath.read_text(encoding="utf-8", errors="replace")
                except (OSError, ValueError):
                    continue

                fdir = fpath.parent
                for line in source.splitlines():
                    for pattern in import_patterns:
                        for match in pattern.finditer(line):
                            import_path = match.group(1)
                            resolved = fdir / import_path
                            for candidate in [
                                resolved, resolved.with_suffix(".js"),
                                resolved.with_suffix(".ts"),
                                resolved.with_suffix(".tsx"),
                                resolved.with_suffix(".jsx"),
                                resolved / "index.js",
                                resolved / "index.ts",
                                resolved / "index.tsx",
                            ]:
                                try:
                                    if candidate.resolve() in focused_paths:
                                        focused_rel = candidate.resolve().relative_to(
                                            self.repo_path.resolve()
                                        ).as_posix()
                                        results.append((rel, focused_rel))
                                        break
                                except (OSError, ValueError):
                                    pass

        return results

    async def send_message(self, user_input: str) -> str:
        """Send a message and get response optimized for query type.

        - ANALYSIS queries (what/how/why/explain) bypass tool loop for speed
        - ACTION queries use tool-calling with optimized retry logic
        - Uses Ollama's native tool calling API, falls back to XML if needed
        """
        self.session.add_user_message(user_input)

        # Classify query type to optimize routing
        query_type = self._classify_query(user_input)

        # For ANALYSIS queries, skip tool loop entirely
        if query_type == "analysis":
            return await self._handle_analysis_query(user_input)

        # For ACTION queries, use optimized tool loop
        return await self._handle_action_query(user_input)

    async def _handle_analysis_query(self, user_input: str) -> str:
        """Handle analysis/Q&A queries directly without tool loop."""

        # When focus is set, always provide context — the user explicitly
        # told us which files they want to discuss.
        has_focus = self.session.has_focus()

        # Only fetch expensive context when the query seems to reference code.
        # Simple greetings / generic questions skip retrieval entirely.
        _code_signals = (
            ".", "/", "file", "class", "function", "method", "module",
            "import", "error", "bug", "test", "code", "variable", "def ",
            "src", "lib", "config", "index", "model", "schema",
        )
        needs_context = has_focus or any(s in user_input.lower() for s in _code_signals)

        repo_map = self._build_repo_map() if needs_context else ""
        context = self._build_context(user_input, limit=5) if needs_context else ""

        # When focus is active, directly read the focused files so the model
        # has their full content regardless of search-term quality.
        # Analysis queries get a bigger budget since the model has no tools to
        # read_file itself.
        focus_context = self._build_focus_context(max_chars=24000) if has_focus else ""

        # Use simpler system prompt for analysis
        system = _ANALYSIS_SYSTEM_PROMPT
        if repo_map:
            system += f"\n\n{repo_map}"
        if focus_context:
            system += f"\n\n{focus_context}"
        if context:
            system += f"\n\nADDITIONAL CONTEXT:\n{context}"

        # Load project rules
        self._append_project_rules(system_parts := [system])
        system = system_parts[0]

        # Inject focus scope awareness
        if has_focus:
            focus_list = ", ".join(self.session.focus_paths)
            system += (
                f"\n\nFOCUS SCOPE: The user is specifically working with: {focus_list}\n"
                "The FULL content of these files is provided above in the FOCUSED FILES section.\n"
                "You HAVE the content — do NOT say you don't have access.\n"
                "When the user says 'this file', 'this folder', 'this code', or 'these files', "
                f"they mean: {focus_list}\n"
                "Answer questions about them directly using the provided content."
            )

        # When focus is active, use enriched messages with explicit file
        # references and shorter history to avoid stale-reference confusion.
        if has_focus:
            working_messages = self._recent_messages_for_focus(max_messages=6)
        else:
            working_messages = self._recent_messages(max_messages=10)

        try:
            # Simple streaming call without tool loop
            spinner_live = Live(
                Spinner("dots", text="[bold cyan]localforge[/bold cyan] analyzing…"),
                refresh_per_second=10,
                transient=True,
                console=console,
            )
            spinner_live.start()

            parts: list[str] = []
            first_token_received = False

            try:
                stream = self.ollama.chat_stream_tokens(
                    working_messages,
                    system=system,
                    temperature=0.2,  # Lower temp for better analysis
                )
                async for token in stream:
                    if not first_token_received:
                        first_token_received = True
                        spinner_live.stop()
                        console.print("[bold green]localforge[/bold green] ", end="")
                    parts.append(token)
                    console.print(token, end="", highlight=False)

                if not first_token_received:
                    spinner_live.stop()
                    console.print()

            finally:
                with contextlib.suppress(Exception):
                    spinner_live.stop()
                if parts and first_token_received:
                        console.print()

            response = "".join(parts)
            self._token_count += len(parts)

        except Exception as exc:
            console.print()
            console.print(
                f"[bold red]Error:[/bold red] {exc}\n"
                "[yellow]Tip: Make sure Ollama is running.[/yellow]"
            )
            response = "Error — please check Ollama is running."

        self.session.add_assistant_message(response)
        self.save_session()
        return response

    async def _handle_action_query(self, user_input: str) -> str:
        """Handle action-oriented queries with tool calling and retry logic."""
        # Build contextual system prompt. For direct command prompts, skip
        # expensive context assembly for faster first-token latency.
        has_focus = self.session.has_focus()
        fast_action = self._is_fast_action_query(user_input)
        tool_driven = self._is_tool_driven_query(user_input)
        scaffolding = self._is_scaffolding_query(user_input)
        large_scaffolding = scaffolding and self._is_large_scaffolding_query(user_input)
        debugging = self._is_debugging_query(user_input)
        check_and_fix = self._is_check_and_fix_query(user_input)
        test_fix = self._is_test_fix_query(user_input)
        # Skip heavy context for test-fix queries too — the test output
        # itself provides all the information the model needs. Loading the
        # full repo map + context burns 10+ minutes of prompt eval on local
        # models for zero benefit when the user said "run pytest and fix".
        skip_context = (fast_action or tool_driven or scaffolding or test_fix) and not has_focus
        repo_map = "" if skip_context else self._build_repo_map()
        context = "" if skip_context else self._build_context(user_input, limit=6)
        system = _SYSTEM_PROMPT

        # ── Pre-flight diagnostics on focused files ──────────────
        # Run fast syntax/compile checks BEFORE the LLM starts so we can
        # inject errors directly into the prompt. This is the biggest speed
        # win: the LLM skips "find the error" and goes straight to "fix it".
        preflight_diagnostics = ""
        dep_analysis = ""
        if has_focus:
            focused_files: list[Path] = []
            for fp in self.session.focus_paths:
                full = self.repo_path / fp
                if full.is_file():
                    focused_files.append(full)
                elif full.is_dir():
                    for child in sorted(full.rglob("*")):
                        if child.is_file() and child.suffix in (
                            ".py", ".js", ".ts", ".jsx", ".tsx", ".json",
                            ".rb", ".php", ".go", ".java", ".rs",
                        ):
                            focused_files.append(child)
            if focused_files:
                preflight_diagnostics = self._run_preflight_diagnostics(focused_files)
                dep_analysis = self._analyze_imports_and_dependencies(focused_files)
                if preflight_diagnostics:
                    console.print(
                        f"  [bold yellow]⚡ Pre-flight:[/bold yellow] "
                        f"Found errors before LLM starts — injecting into prompt",
                    )

        # If pre-flight found errors, treat it like debugging + check_and_fix
        if preflight_diagnostics:
            check_and_fix = True

        # For debugging queries WITHOUT focus, try a quick pytest collect
        # to surface errors across the codebase.
        # Skip this for test_fix queries — the model will run the full tests itself,
        # and the collect-only overhead just delays first-token latency.
        if debugging and not test_fix and not has_focus and not preflight_diagnostics:
            preflight_diagnostics = self._run_project_quick_check()
            if preflight_diagnostics:
                console.print(
                    f"  [bold yellow]⚡ Pre-flight:[/bold yellow] "
                    f"Found errors in project — injecting into prompt",
                )

        if fast_action:
            system += (
                "\n\nTASK MODE: FAST_COMMAND"
                "\n- Run the requested command immediately."
                "\n- If the output is clean (no errors), report success briefly."
                "\n- If the output shows errors/warnings, do NOT stop."
                "\n  Read the affected files, fix the issues, then re-run to verify."
            )
        elif scaffolding:
            system += (
                "\n\nTASK MODE: SCAFFOLDING"
                "\n- You are building a project FROM SCRATCH."
                "\n- Use write_file to create each file. Parent directories are created automatically."
                "\n- Create a COMPLETE, working project — not just stubs."
                "\n- Include: source code, config files (pyproject.toml, package.json, etc.), README, tests."
                "\n- Generate production-quality code with proper error handling."
                "\n- Use write_file for EVERY file — do NOT tell the user to create files."
                "\n- Do NOT run linters unless the user specifically asked for linting."
            )
            if large_scaffolding:
                system += (
                    "\n\nLARGE PROJECT WORKFLOW — follow this phased approach:"
                    "\n  Phase 1 — PLAN: Before writing ANY code, list every file you will create"
                    "\n    (paths + one-line description). Think about the full architecture:"
                    "\n    models, routes/controllers, services/business logic, utilities,"
                    "\n    configuration, tests, and documentation."
                    "\n  Phase 2 — FOUNDATION: Create config, models/schemas, and base utilities first."
                    "\n  Phase 3 — FEATURES: Create each feature module with COMPLETE implementation."
                    "\n    Do NOT create minimal stubs — every function must have real logic."
                    "\n    Implement ALL features the user asked for, not just a subset."
                    "\n  Phase 4 — TESTS: Create comprehensive test files covering all features."
                    "\n  Phase 5 — VERIFY: Run pytest to verify all tests pass. Fix any failures."
                    "\n- You MUST create ALL files listed in your plan. Do not stop early."
                    "\n- If the user described N features, implement ALL N features completely."
                    "\n- Each file should be substantial with real, working code."
                )
            else:
                system += (
                    "\n\nWORKFLOW: plan ALL files → create each with write_file → run tests → fix issues."
                    "\n- After creating all files, run tests (pytest) or the app to verify."
                    "\n- If tests fail, read the error, fix the code, and re-run."
                )
        elif tool_driven:
            system += (
                "\n\nTASK MODE: TOOL_DRIVEN_FIX"
                "\n- Run the linter/checker command FIRST to discover issues."
                "\n- For auto-fixable issues, try running with --fix flag first."
                "\n- Then read affected files and fix remaining issues manually."
                "\n- WORKFLOW: run command → read errors → read affected files → "
                "\n  edit files to fix → re-run command to verify → repeat until clean."
                "\n- Fix ALL issues, not just the first few."
                "\n- After fixing, re-run the check to verify everything is clean."
            )
        elif test_fix:
            system += (
                "\n\nTASK MODE: TEST_FIX"
                "\n- The user is reporting test failures and wants them fixed."
                "\n- Run the test command FIRST to see exact errors and stack traces."
                "\n  IMPORTANT: Use `--tb=short -q` flags with pytest for concise output."
                "\n  Example: `pytest tests/test_foo.py --tb=short -q`"
                "\n- After running tests, the output will show a 'SOURCE FILES IN ERRORS:' line"
                "\n  listing the exact source file paths. Use those paths for read_file."
                "\n  If no SOURCE FILES line, read the TEST file first — its imports show the source files."
                "\n  Example: `from localforge.chat.tools import validate_tool_call` → read `localforge/chat/tools.py`."
                "\n- NEVER guess file paths like `src/validation.py`. ALWAYS get them from test output or imports."
                "\n- Execute ONE tool call at a time. Do NOT plan all steps upfront."
                "\n  Run tests → read ONE file → understand → fix → re-test. Repeat."
                "\n- Fix the source code, NOT the test (unless the test itself is wrong)."
                "\n- Use batch_edit to fix multiple issues across files at once."
                "\n- Keep running tests until ALL pass cleanly."
            )
        elif debugging:
            system += (
                "\n\nTASK MODE: DEBUGGING"
                "\n- The user has described a bug or issue."
                "\n- IMPORTANT: Be FAST. The file content may already be provided in context."
                "\n  If you can see the file content, identify the issue and fix it DIRECTLY."
                "\n  Do NOT waste rounds reading files you already have in context."
                "\n- WORKFLOW: Look at provided context first → if issue is visible, fix immediately"
                "\n  → if not visible, search/grep for relevant code → read affected files → "
                "\n  understand the root cause → edit to fix → run tests to verify."
                "\n- MULTI-FILE BUGS: When FILE DEPENDENCIES section is provided:"
                "\n  1. Check the dependency graph to understand which files affect each other"
                "\n  2. Fix the ROOT CAUSE first (the file where the bug originates)"
                "\n  3. Then fix any files that import from the broken file"
                "\n  4. Use batch_edit to fix ALL affected files in ONE tool call"
                "\n- Use batch_edit to fix multiple issues at once instead of one-by-one."
                "\n- After fixing, run tests or the app to verify the fix works."
                "\n- If tests don't exist, create a minimal test to verify the fix."
            )

        # check_and_fix can overlap with debugging — it's additive
        if check_and_fix:
            system += (
                "\n\nTASK MODE: CHECK_AND_FIX"
                "\n- The user wants you to find and fix issues in the focused files."
                "\n- CRITICAL SPEED RULE: The file content is ALREADY in your context above."
                "\n  Do NOT call read_file on files that are in FOCUSED FILES section."
                "\n  Go straight to identifying the issue and using edit_file to fix it."
                "\n- If PRE-FLIGHT DIAGNOSTICS are shown above, those are CONFIRMED errors."
                "\n  Fix them IMMEDIATELY in your FIRST tool call — do not re-read, re-check,"
                "\n  or explore. Just fix them."
                "\n- For syntax errors: look at the reported line number, find the issue in"
                "\n  the file content above, and call edit_file to fix it. ONE round."
                "\n- MULTI-FILE STRATEGY:"
                "\n  1. Check FILE DEPENDENCIES to see what imports what"
                "\n  2. If IMPORT ERROR diagnostics show missing names, the fix may be in the"
                "\n     dependency file (add the missing export) or in the importing file (fix the name)"
                "\n  3. If DEPENDENCY SYNTAX ERROR is reported, fix the dependency file FIRST,"
                "\n     then the importing file should work automatically"
                "\n  4. Use batch_edit to fix multiple files in ONE tool call — do not fix one at a time"
                "\n  5. Check 'FILES THAT IMPORT FROM FOCUSED FILES' — changes you make to a"
                "\n     focused file may break those other files. Read them and fix too."
                "\n- After fixing, run verify_changes to confirm."
            )

        # Inject pre-flight diagnostics and dependency analysis
        if preflight_diagnostics:
            system += f"\n\n{preflight_diagnostics}"
        if dep_analysis:
            system += f"\n\n{dep_analysis}"

        if repo_map:
            system += f"\n\n{repo_map}"
        if context:
            system += f"\n\nRELEVANT CODE CONTEXT:\n{context}"

        # When focus is active, directly read the focused files so the model
        # has their full content — can edit immediately without read_file first.
        if has_focus:
            focus_context = self._build_focus_context()
            if focus_context:
                system += f"\n\n{focus_context}"

        # Load project rules
        if not skip_context:
            self._append_project_rules(system_parts := [system])
            system = system_parts[0]

        # Inject focus scope awareness
        if has_focus:
            focus_list = ", ".join(self.session.focus_paths)
            system += (
                f"\n\nFOCUS SCOPE: The user is specifically working with: {focus_list}\n"
                "The FULL content of these files is provided above in the FOCUSED FILES section.\n"
                "You HAVE the content — do NOT say you don't have access.\n"
                "When the user says 'this file', 'this folder', 'this code', or 'these files', "
                f"they mean: {focus_list}\n"
                "You can edit them directly using edit_file or write_file.\n"
                "All search_code, grep_codebase, and find_symbols results are already filtered to this scope.\n"
                "You may also create new files within this scope as needed."
            )

        # Cap session messages to keep payload small → much faster prompt eval.
        # When focus is active, use enriched messages with explicit file
        # references and shorter history to avoid stale-reference confusion.
        if has_focus:
            working_messages: list[dict[str, Any]] = self._recent_messages_for_focus(
                max_messages=8,
            )
        else:
            if fast_action:
                msg_cap = 4
            elif large_scaffolding:
                msg_cap = 24
            elif scaffolding:
                msg_cap = 20
            elif tool_driven or test_fix:
                msg_cap = 8
            else:
                msg_cap = 16
            working_messages: list[dict[str, Any]] = self._recent_messages(
                max_messages=msg_cap,
            )

        # Choose tool set: lean for fast/tool-driven/scaffolding/test-fix, full for complex tasks
        # When focus is active, always use full tool set so the model can search/navigate
        use_lean = (fast_action or tool_driven or scaffolding or test_fix) and not has_focus
        active_tool_schemas = TOOL_SCHEMAS_FAST if use_lean else TOOL_SCHEMAS

        final_response = ""
        nudge_count = 0
        max_nudges = 3  # Allow multiple nudges so the model stays on-task
        native_tools_supported = True
        if fast_action:
            max_rounds = 12
        elif test_fix:
            max_rounds = 25  # enough to run tests, read files, fix, and re-verify
        elif check_and_fix and preflight_diagnostics:
            # Pre-flight found clear errors — should fix in very few rounds
            max_rounds = 15
        elif large_scaffolding:
            max_rounds = 80
        else:
            max_rounds = 50

        # ── Phase 1: Loop progress tracking ──────────────────────
        tool_call_history: dict[str, int] = {}  # hash → count of identical calls
        consecutive_error_rounds = 0  # Rounds with only errors, no successful edits
        consecutive_no_tool_rounds = 0  # Rounds where model didn't use tools
        successful_actions_count = 0  # Total successful tool calls
        parse_repair_used = False  # Only allow 1 parse repair per query
        task_verified_clean = False  # Set when verify/ruff passes clean

        for _round in range(max_rounds):
            # ── Spinner with round indicator ─────────────────────
            if _round == 0:
                # Show approximate prompt size on first round to set expectations
                prompt_chars = len(system) + sum(len(m.get("content", "")) for m in working_messages)
                prompt_k = prompt_chars // 1000
                mode_label = (
                    "test-fix" if test_fix else
                    "fast" if fast_action else
                    "tool-driven" if tool_driven else
                    "scaffolding" if scaffolding else
                    "debugging" if debugging else
                    "action"
                )
                spinner_text = (
                    f"[bold cyan]localforge[/bold cyan] thinking… "
                    f"[dim](~{prompt_k}K chars, {mode_label} mode)[/dim]"
                )
            else:
                # Estimate context size for rounds > 0 so user sees growth
                ctx_chars = sum(len(m.get("content", "")) for m in working_messages)
                ctx_k = ctx_chars // 1000
                spinner_text = (
                    f"[bold cyan]localforge[/bold cyan] working… "
                    f"(step {_round + 1}, ~{ctx_k}K ctx)"
                )
            spinner_live = Live(
                Spinner("dots", text=spinner_text),
                refresh_per_second=10,
                transient=True,
                console=console,
            )
            spinner_live.start()

            # ── Stream from model ────────────────────────────────
            content = ""  # will be set below or by partial-recovery
            parts: list[str] = []
            tool_calls_out: list[dict[str, Any]] = []
            first_token_received = False
            console_prefix_printed = False

            try:
                if native_tools_supported:
                    stream = self.ollama.chat_with_tools_stream(
                        working_messages,
                        tools=active_tool_schemas,
                        system=system,
                        temperature=0.4,
                        tool_calls_out=tool_calls_out,
                        # For fast actions (run ruff, etc.) the model mostly
                        # emits a tool call JSON — cap output to avoid stalls.
                        # Cap output tokens: fast actions use short cap, others
                        # get generous limit. Scaffolding gets extra for large files.
                        num_predict=2048 if fast_action else (8192 if scaffolding else 4096),
                    )
                else:
                    stream = self.ollama.chat_stream_tokens(
                        working_messages,
                        system=system + "\n\n" + _XML_FALLBACK_PROMPT,
                        temperature=0.4,
                    )

                async for token in stream:
                    if not first_token_received:
                        first_token_received = True
                        spinner_live.stop()
                        console.print(
                            "[bold green]localforge[/bold green] ", end="",
                        )
                        console_prefix_printed = True
                    parts.append(token)
                    console.print(token, end="", highlight=False)

                if not first_token_received:
                    spinner_live.stop()
                if console_prefix_printed:
                    console.print()

            except Exception as exc:
                with contextlib.suppress(Exception):
                    spinner_live.stop()
                # If native tool calling failed with 400, fall back
                if native_tools_supported and "400" in str(exc):
                    native_tools_supported = False
                    logger.info("Native tool calling not supported, using fallback.")
                    continue

                # ── Connection error recovery ─────────────────────
                # If we got partial content with tool calls, try to use it.
                partial_content = "".join(parts)
                if partial_content.strip():
                    console.print()
                    console.print(
                        "  [yellow]⚠ Connection interrupted — using partial response[/yellow]",
                    )
                    # Fall through to process whatever we got
                    content = partial_content
                    self._token_count += len(parts)
                    self._rounds_count += 1
                else:
                    # No useful content — try to recover by trimming context
                    # so the next prompt-eval is smaller and less likely to OOM.
                    if _round == 0 and len(working_messages) > 2:
                        console.print()
                        console.print(
                            "  [yellow]⚠ Connection error — retrying with reduced context…[/yellow]",
                        )
                        # Aggressively truncate any large tool results in history
                        for msg in working_messages:
                            c = msg.get("content", "")
                            if len(c) > 4000:
                                msg["content"] = _truncate_tool_result(c, 4000)
                        continue
                    console.print()
                    console.print(
                        f"[bold red]Connection error:[/bold red] {exc}\n"
                        "[yellow]Tip: Make sure Ollama is running and the model "
                        "is loaded. Try 'ollama run <model>' first.[/yellow]"
                    )
                    self.session.add_assistant_message(
                        "Connection error — please check Ollama is running."
                    )
                    return "Connection error — please check Ollama."

            # If partial-recovery already set content, skip
            if not content:
                content = "".join(parts)
                self._token_count += len(parts)
                self._rounds_count += 1

            # ── Process tool calls from all paths ────────────────
            tool_calls: list[dict[str, Any]] = []
            is_native = False

            # Path 1: Native tool calls
            if tool_calls_out:
                is_native = True
                for tc in tool_calls_out:
                    func = tc.get("function", {})
                    tool_name = func.get("name", "unknown")
                    tool_args = func.get("arguments", {})
                    if isinstance(tool_args, str):
                        try:
                            tool_args = json.loads(tool_args)
                        except json.JSONDecodeError:
                            tool_args = {}
                    tool_calls.append({"tool": tool_name, "args": tool_args})

            # Path 2: XML fallback
            if not tool_calls:
                _, xml_calls = extract_all_tool_calls(content)
                tool_calls = xml_calls

            # Path 3: JSON fallback — skip when task is verified clean to avoid
            # picking up JSON-like text from the model's natural-language summary
            if not tool_calls and not task_verified_clean:
                _, json_calls = extract_json_tool_calls(content)
                tool_calls = json_calls

            # ── Execute tool calls if any ────────────────────────
            if tool_calls:
                # Cap tool calls per round for test_fix mode.
                # The model tends to plan ALL reads upfront (e.g., 5 read_file
                # calls to guessed paths) when it should investigate one file at
                # a time, process the result, then decide what to read next.
                if test_fix and len(tool_calls) > 2:
                    logger.info(
                        "test_fix cap: reducing %d tool calls to 2",
                        len(tool_calls),
                    )
                    tool_calls = tool_calls[:2]
                # Extra safety: also cap in non-test_fix mode when model
                # tries to batch too many reads (often hallucinated paths).
                elif len(tool_calls) > 5:
                    logger.info(
                        "General cap: reducing %d tool calls to 5",
                        len(tool_calls),
                    )
                    tool_calls = tool_calls[:5]

                nudge_count = 0
                consecutive_no_tool_rounds = 0
                round_had_error = True  # Assume error until proven otherwise
                round_had_success = False

                if not is_native and native_tools_supported:
                    native_tools_supported = False
                    logger.info("Using fallback text-based tool calls.")

                all_results: list[tuple[str, str]] = []

                for i, tc in enumerate(tool_calls, 1):
                    tool_name = tc.get("tool", "unknown")
                    tool_args = tc.get("args", {})

                    # Phase 2: Validate tool call before executing
                    validation_err = validate_tool_call(tc)
                    if validation_err:
                        console.print(
                            f"  [dim]⚡ Tool {tool_name}[/dim]",
                        )
                        console.print(
                            f"  [dim]   ✗ Validation: {validation_err}[/dim]",
                        )
                        all_results.append((tool_name, f"Error: {validation_err}"))
                        continue

                    # Phase 1: Check for repeated identical tool calls
                    call_hash = hash_tool_call(tool_name, tool_args)
                    tool_call_history[call_hash] = tool_call_history.get(call_hash, 0) + 1

                    if tool_call_history[call_hash] > 2:
                        console.print(
                            f"  [yellow]⚠ Skipping repeated tool call: "
                            f"{tool_name} (called {tool_call_history[call_hash]}x with same args)[/yellow]",
                        )
                        # Forceful redirect based on what tool is repeating
                        if tool_name == "edit_file":
                            redirect = (
                                f"BLOCKED: edit_file has been called {tool_call_history[call_hash]} times "
                                "with the SAME arguments and keeps failing. "
                                "You MUST switch to edit_lines with start_line and end_line. "
                                "Steps: 1) read_file to find the line numbers, "
                                "2) edit_lines with start_line, end_line, and new_content. "
                                "Do NOT call edit_file again with the same old_string."
                            )
                        else:
                            redirect = (
                                f"BLOCKED: {tool_name} has been called {tool_call_history[call_hash]} times "
                                "with identical arguments. The result will be the same each time. "
                                "You MUST try a completely different approach."
                            )
                        all_results.append((tool_name, f"Error: {redirect}"))
                        continue

                    label = (
                        f"[{i}/{len(tool_calls)}]"
                        if len(tool_calls) > 1
                        else ""
                    )
                    console.print(
                        f"  [dim]⚡ Tool {label} {tool_name}[/dim]", end="",
                    )
                    self._print_tool_arg_preview(tool_name, tool_args)

                    start_t = time.monotonic()
                    result = self.tools.execute(tool_name, tool_args)
                    elapsed = time.monotonic() - start_t

                    # Track success/error for the round
                    if not result.startswith("Error:"):
                        round_had_success = True
                        round_had_error = False
                        successful_actions_count += 1
                        self._tool_calls_count += 1

                        # If an edit/write succeeded, the project state changed.
                        # Reset dedup counts for run_command/verify_changes so
                        # the model can re-run linters/tests to verify its edits.
                        edit_tools = {"edit_file", "edit_lines", "write_file", "batch_edit", "apply_diff"}
                        if tool_name in edit_tools:
                            stale = [h for h, _cnt in tool_call_history.items()
                                     if _cnt > 1]
                            for h in stale:
                                tool_call_history[h] = 1

                        # Detect when verification passes clean — task is done
                        _clean_markers = (
                            "all checks passed", "all_checks_passed",
                            "no issues", "found 0 error",
                            "0 error(s)",  # msbuild / dotnet
                        )
                        result_lower = result.lower()
                        is_clean = any(m in result_lower for m in _clean_markers)
                        # pytest: "4 passed in 0.10s" with successful exit
                        if not is_clean and " passed" in result_lower and "(exit code:" not in result_lower:
                            is_clean = True
                        if tool_name in ("verify_changes", "run_command") and is_clean:
                            task_verified_clean = True

                    preview = result[:150].replace("\n", " ")
                    if len(result) > 150:
                        preview += "…"
                    status_icon = "✓" if not result.startswith("Error:") else "✗"
                    console.print(
                        f"  [dim]   {status_icon} ({elapsed:.1f}s) {preview}[/dim]",
                    )
                    all_results.append((tool_name, result))

                console.print()

                # Phase 1: Track consecutive error rounds
                if round_had_error and not round_had_success:
                    consecutive_error_rounds += 1
                else:
                    consecutive_error_rounds = 0

                # Phase 1: Stuck detection
                if consecutive_error_rounds >= 3:
                    console.print(
                        "\n  [bold yellow]⚠ Stuck detected:[/bold yellow] "
                        "3 consecutive rounds with only errors. "
                        "Injecting recovery prompt…\n",
                    )
                    consecutive_error_rounds = 0  # Reset to give it another chance
                    working_messages.append(
                        {"role": "assistant", "content": content},
                    )
                    # Add all results (truncated for context budget)
                    result_text = "\n\n".join(
                        f"Tool result for {name}:\n```\n{_truncate_tool_result(res)}\n```"
                        for name, res in all_results
                    )
                    # Analyze what tool keeps failing to give specific guidance
                    _failing_tools = [name for name, res in all_results if res.startswith("Error:")]
                    _edit_file_failing = _failing_tools.count("edit_file") >= 2
                    if _edit_file_failing:
                        recovery_guidance = (
                            f"{result_text}\n\n"
                            "CRITICAL: edit_file keeps failing because old_string doesn't match the file content. "
                            "This usually happens when the text you're trying to match was truncated or modified. "
                            "You MUST switch strategy NOW:\n"
                            "1. Use read_file with start_line and end_line to get the EXACT lines you want to change\n"
                            "2. Use edit_lines with start_line, end_line, and new_content to replace those lines\n"
                            "3. Do NOT call edit_file again until you have verified the exact text exists in the file\n"
                            "NEVER use text containing '...', '(truncated)', or '(omitted)' as old_string."
                        )
                    else:
                        recovery_guidance = (
                            f"{result_text}\n\n"
                            "IMPORTANT: You have been stuck for multiple rounds making the same errors. "
                            "STOP and reconsider your approach:\n"
                            "1. Re-read the target file(s) with read_file to get EXACT current content\n"
                            "2. Use edit_lines with line numbers instead of edit_file if string matching fails\n"
                            "3. Try a completely different strategy to achieve the goal\n"
                            "4. If you truly cannot proceed, explain what's blocking you\n"
                            "Do NOT repeat the same failed operations."
                        )
                    working_messages.append({
                        "role": "user",
                        "content": recovery_guidance,
                    })
                    continue

                # Build messages for next round
                if is_native:
                    assistant_msg: dict[str, Any] = {
                        "role": "assistant",
                        "content": content,
                        "tool_calls": tool_calls_out,
                    }
                    working_messages.append(assistant_msg)
                    for _tool_name, result in all_results:
                        working_messages.append({
                            "role": "tool",
                            "content": _truncate_tool_result(result),
                        })
                else:
                    working_messages.append(
                        {"role": "assistant", "content": content},
                    )
                    result_text = "\n\n".join(
                        f"Tool result for {name}:\n```\n{_truncate_tool_result(res)}\n```"
                        for name, res in all_results
                    )
                    working_messages.append({
                        "role": "user",
                        "content": result_text + "\n\nContinue. Keep using tools until done.",
                    })
                continue

            # ── No tool calls extracted ─────────────────────────
            consecutive_no_tool_rounds += 1

            # Phase 2: Parse repair — try once if all extraction failed
            # Skip parse repair when the task has already been verified clean
            if (
                not parse_repair_used
                and not task_verified_clean
                and content.strip()
                and (
                    "{" in content
                    or "tool" in content.lower()
                    or "edit" in content.lower()
                    or "read" in content.lower()
                    or "run" in content.lower()
                )
            ):
                parse_repair_used = True
                console.print(
                    "\n  [yellow]↻ Could not parse tool calls. Asking model to reformat…[/yellow]",
                )
                working_messages.append(
                    {"role": "assistant", "content": content},
                )
                working_messages.append({
                    "role": "user",
                    "content": (
                        "Your previous response could not be parsed as tool calls. "
                        "You MUST wrap each tool call in <tool_call> tags like this:\n\n"
                        "<tool_call>\n"
                        '{"tool": "tool_name", "args": {"arg1": "value"}}\n'
                        "</tool_call>\n\n"
                        "Reformat your intended action using the exact format above. "
                        "Do NOT explain — just output the <tool_call> tags."
                    ),
                })
                continue

            # ── Lazy / premature-stop detection ────────────────────
            # Skip these checks when the task has been verified clean —
            # the model is giving a legitimate summary, not being lazy.
            if (
                not task_verified_clean
                and self._is_lazy_response(content)
                and nudge_count < max_nudges
            ):
                nudge_count += 1
                console.print(
                    "\n  [yellow]↻ Agent not using tools. Nudging to act…[/yellow]",
                )
                working_messages.append(
                    {"role": "assistant", "content": content},
                )
                working_messages.append({
                    "role": "user",
                    "content": (
                        "STOP. You must NOT give instructions to the user. "
                        "You are an autonomous agent — use your tools NOW. "
                        "Read the relevant files with read_file, then fix "
                        "the issues with edit_file. Keep going until done."
                    ),
                })
                continue

            # Even if the response isn't obviously lazy, catch the "please
            # review" / "let me know" hand-off that local models love to do.
            if (
                not task_verified_clean
                and nudge_count < max_nudges
                and self._is_premature_handoff(content)
            ):
                nudge_count += 1
                console.print(
                    "\n  [yellow]↻ Agent tried to hand off. Continuing…[/yellow]",
                )
                working_messages.append(
                    {"role": "assistant", "content": content},
                )
                working_messages.append({
                    "role": "user",
                    "content": (
                        "Do NOT ask me to review. YOU must continue working. "
                        "If there are errors or issues, use edit_file to fix "
                        "them, then run the command again to verify."
                    ),
                })
                continue

            # ── Scaffolding early-exit prevention ────────────────────
            # When building a project and the model has only created a few
            # files, don't let it declare "done" prematurely.
            if (
                scaffolding
                and successful_actions_count < 3
                and nudge_count < max_nudges
                and not task_verified_clean
            ):
                nudge_count += 1
                min_files = "many more" if large_scaffolding else "more"
                console.print(
                    "\n  [yellow]↻ Scaffolding incomplete — nudging to continue…[/yellow]",
                )
                working_messages.append(
                    {"role": "assistant", "content": content},
                )
                working_messages.append({
                    "role": "user",
                    "content": (
                        f"You have only completed {successful_actions_count} actions so far. "
                        f"The project needs {min_files} files. "
                        "Continue creating ALL the remaining project files with write_file. "
                        "Do NOT stop until every file is created and tests pass."
                    ),
                })
                continue

            # ── Done — final response ────────────────────────────────
            final_response = content
            break
        else:
            # Max rounds reached — provide diagnostic
            console.print(
                f"[yellow]Maximum tool rounds ({max_rounds}) reached. "
                f"Completed {successful_actions_count} successful actions.[/yellow]",
            )
            final_response = content if content else "(no response)"

        # Persist to session
        self.session.add_assistant_message(final_response)
        self.save_session()
        return final_response

    @staticmethod
    def _print_tool_arg_preview(
        tool_name: str, tool_args: dict[str, Any],
    ) -> None:
        """Print a short preview of tool arguments."""
        _arg_preview = ""
        if tool_name in ("read_file", "edit_file", "write_file", "edit_lines", "apply_diff"):
            _arg_preview = tool_args.get("path", "")
            if tool_name == "edit_lines":
                sl = tool_args.get("start_line", "?")
                el = tool_args.get("end_line", "?")
                _arg_preview += f" L{sl}-{el}"
        elif tool_name == "run_command":
            _arg_preview = tool_args.get("command", "")[:80]
        elif tool_name in ("search_code", "grep_codebase"):
            _arg_preview = tool_args.get("pattern", "")[:60]
        elif tool_name == "verify_changes":
            _arg_preview = tool_args.get("command", "auto-detect")
        elif tool_name == "find_symbols":
            _arg_preview = tool_args.get("name", "")
        if _arg_preview:
            console.print(f" [dim]({_arg_preview})[/dim]")
        else:
            console.print()

    @staticmethod
    def _is_lazy_response(response: str) -> bool:
        """Detect if model gave instructions instead of using tools.

        Only flags very obvious cases - no nuance about analysis responses.
        """
        lower = response.lower()

        # If response is short, probably a direct answer (not lazy)
        if len(response.strip()) < 100:
            return False

        # Very strong signal: numbered steps with imperative verbs
        import re
        step_pattern = re.findall(
            r'^\s*\d+\.\s+(?:run|execute|install|create|edit|delete|modify|open|use)\b',
            lower, re.MULTILINE,
        )
        if len(step_pattern) >= 2:
            return True

        # Shell code blocks with no tool calls is lazy
        has_code_block = "```bash" in lower or "```shell" in lower
        if has_code_block and len(step_pattern) >= 1:
            return True

        # Check for strong lazy phrases (but require multiple)
        lazy_phrases = sum(1 for phrase in [
            "you can run", "you should run", "you should also run",
            "try running",
            "you can use", "you should use",
            "you need to", "you'll need to",
            "follow these steps", "here are the steps",
            "please review", "let me know",
            "you might want", "you may want",
            "here's how", "here is how",
            "manually",
        ] if phrase in lower)

        # A code block combined with any lazy phrase is a strong signal
        if has_code_block and lazy_phrases >= 1:
            return True

        # Single strong delegation phrase is lazy if the response is long
        if lazy_phrases >= 1 and len(response.strip()) > 300:
            return True

        return lazy_phrases >= 2

    @staticmethod
    def _is_premature_handoff(response: str) -> bool:
        """Detect when the model tries to hand control back to the user.

        This catches the very common local-model pattern of running one
        command and then saying "Please review the output" or "Let me know
        if you need anything else" instead of continuing to work.
        """
        lower = response.lower()

        handoff_phrases = (
            "please review",
            "let me know",
            "if you need",
            "if you want me to",
            "if you'd like me to",
            "would you like me to",
            "do you want me to",
            "i can help",
            "i can assist",
            "feel free to",
            "want me to",
            "need any help",
            "need further",
            "need additional",
            "any questions",
            "anything else",
            "specific issues",
            "manual attention",
            "provide more details",
        )
        return any(phrase in lower for phrase in handoff_phrases)

    async def run_repl(self) -> None:
        """Run the interactive chat REPL."""
        # Auto-index the repository if needed
        self._ensure_index()

        # Auto-detect context window from Ollama and keep models loaded.
        # detect_context_window now stores the value inside OllamaClient so
        # every subsequent payload automatically gets the correct num_ctx.
        try:
            detected = await self.ollama.detect_context_window()
            console.print(
                f"[dim]Model context window: {detected:,} tokens[/dim]"
            )
        except Exception:
            pass

        # Detect model capabilities (tool calling, JSON mode, family)
        try:
            caps = await self.ollama.detect_capabilities()
            console.print(
                f"[dim]Model family: {caps.get('family', 'unknown')} | "
                f"Tools: {'yes' if caps.get('supports_tools') else 'no'} | "
                f"JSON mode: {'yes' if caps.get('supports_json_mode') else 'no'}[/dim]"
            )
        except Exception:
            pass

        # Pre-load the model into Ollama VRAM/RAM so the first user prompt
        # doesn't stall while the model is being loaded from disk.
        try:
            with contextlib.suppress(Exception):
                await self.ollama.preload_model()
        except Exception:
            pass

        # Build and cache the repo map
        self._build_repo_map()

        # Try to load previous session
        loaded = self.load_session()
        if loaded and self.session.messages:
            n = len(self.session.messages)
            console.print(
                f"[dim]Resumed session with {n} message(s). "
                f"Type /clear to start fresh.[/dim]"
            )

        # Sync focus paths from loaded session to tools
        if self.session.has_focus():
            self._sync_focus_to_tools()
            self._invalidate_repo_map()
            console.print(
                f"[dim]Focus: {', '.join(self.session.focus_paths)} "
                f"(/focus to view, /clear-focus to reset)[/dim]"
            )

        console.print(
            Panel(
                "[bold]LocalForge Chat[/bold] — autonomous coding agent\n"
                f"Model: [cyan]{self.config.model_name}[/cyan]  "
                f"Repo: [cyan]{self.repo_path}[/cyan]\n\n"
                "[dim]I can read/write/edit files, run any command, search code, and verify changes.\n"
                "Just tell me what to do and I'll execute it autonomously.\n"
                "Use /add <path> to focus on specific files/folders.\n"
                "Commands: /add, /remove, /focus, /clear-focus, /clear, /help, /quit[/dim]",
                border_style="cyan",
                expand=False,
            )
        )

        while True:
            try:
                if self.session.has_focus():
                    n_focus = len(self.session.focus_paths)
                    prompt = f"\n[bold cyan]you[/bold cyan] [dim]({n_focus} focused)[/dim] [bold cyan]>[/bold cyan] "
                else:
                    prompt = "\n[bold cyan]you >[/bold cyan] "
                user_input = console.input(prompt).strip()
            except (EOFError, KeyboardInterrupt):
                console.print("\n[dim]Goodbye![/dim]")
                break

            if not user_input:
                continue

            # Handle slash commands
            if user_input.startswith("/"):
                if await self._handle_command(user_input):
                    continue
                else:
                    break

            await self.send_message(user_input)

    async def _handle_command(self, cmd: str) -> bool:
        """Handle a slash command. Returns False if the REPL should exit."""
        parts = cmd.split(maxsplit=1)
        command = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""

        if command in ("/quit", "/exit", "/q"):
            console.print("[dim]Goodbye![/dim]")
            return False

        elif command == "/clear":
            self.session.clear()
            self.save_session()
            console.print("[green]Chat history cleared.[/green]")

        elif command == "/history":
            if not self.session.messages:
                console.print("[dim]No messages yet.[/dim]")
            else:
                for i, msg in enumerate(self.session.messages, 1):
                    role_style = "cyan" if msg.role == "user" else "green"
                    label = "you" if msg.role == "user" else "localforge"
                    preview = msg.content[:120].replace("\n", " ")
                    console.print(
                        f"  [{role_style}]{i}. {label}:[/{role_style}] {preview}…"
                        if len(msg.content) > 120
                        else f"  [{role_style}]{i}. {label}:[/{role_style}] {msg.content}"
                    )

        elif command == "/context":
            if not arg:
                console.print("[yellow]Usage: /context <search query>[/yellow]")
            else:
                context = self._build_context(arg)
                if context:
                    console.print(Panel(
                        context[:3000],
                        title="Retrieved Context",
                        border_style="blue",
                    ))
                else:
                    console.print("[dim]No relevant context found.[/dim]")

        elif command == "/run":
            if not arg:
                console.print("[yellow]Usage: /run <command>[/yellow]")
            else:
                result = self.tools.execute("run_command", {"command": arg})
                console.print(Panel(result[:3000], title=f"$ {arg}", border_style="green"))

        elif command == "/read":
            if not arg:
                console.print("[yellow]Usage: /read <file path>[/yellow]")
            else:
                result = self.tools.execute("read_file", {"path": arg})
                console.print(Panel(result[:3000], title=arg, border_style="blue"))

        elif command == "/add":
            if not arg:
                console.print("[yellow]Usage: /add <file_or_folder> ...[/yellow]")
            else:
                added = 0
                for token in arg.split():
                    # Support globs
                    expanded = list(self.repo_path.glob(token))
                    if not expanded:
                        # Try as literal path
                        literal = self.repo_path / token
                        if literal.exists():
                            expanded = [literal]
                        else:
                            console.print(f"  [yellow]Not found: {token}[/yellow]")
                            continue
                    for p in expanded:
                        try:
                            rel = p.relative_to(self.repo_path).as_posix()
                        except ValueError:
                            continue
                        if self.session.add_focus_path(rel):
                            added += 1
                if added:
                    self._invalidate_repo_map()
                    self._sync_focus_to_tools()
                    self.save_session()
                    console.print(f"  [green]Added {added} path(s) to focus.[/green]")
                self._print_focus_status()

        elif command == "/remove":
            if not arg:
                console.print("[yellow]Usage: /remove <path_or_substring> ...[/yellow]")
            else:
                total_removed = 0
                for token in arg.split():
                    total_removed += self.session.remove_focus_path(token)
                if total_removed:
                    self._invalidate_repo_map()
                    self._sync_focus_to_tools()
                    self.save_session()
                    console.print(f"  [green]Removed {total_removed} path(s) from focus.[/green]")
                else:
                    console.print("  [yellow]No matching focus paths found.[/yellow]")
                self._print_focus_status()

        elif command == "/focus":
            self._print_focus_status()

        elif command == "/clear-focus":
            if self.session.has_focus():
                self.session.clear_focus_paths()
                self._invalidate_repo_map()
                self._sync_focus_to_tools()
                self.save_session()
            console.print("[green]Focus cleared — searching entire codebase.[/green]")

        elif command == "/help":
            console.print(
                Panel(
                    "[bold cyan]Focus commands:[/bold cyan]\n"
                    "[bold]/add <path>[/bold]  — Add file/folder to focus scope\n"
                    "[bold]/remove <path>[/bold] — Remove path from focus scope\n"
                    "[bold]/focus[/bold]     — Show current focus paths\n"
                    "[bold]/clear-focus[/bold] — Remove all focus paths\n\n"
                    "[bold cyan]General commands:[/bold cyan]\n"
                    "[bold]/clear[/bold]     — Clear chat history\n"
                    "[bold]/context[/bold]   — Search codebase for context\n"
                    "[bold]/history[/bold]   — Show conversation history\n"
                    "[bold]/run <cmd>[/bold] — Run a shell command directly\n"
                    "[bold]/read <path>[/bold] — Read a file\n"
                    "[bold]/tokens[/bold]    — Show token usage for this session\n"
                    "[bold]/help[/bold]      — Show this help\n"
                    "[bold]/quit[/bold]      — Exit chat\n\n"
                    "[dim]The AI can also use tools autonomously: read files,\n"
                    "edit code, run commands, and search the codebase.\n"
                    "When focus paths are set, searches & context are scoped\n"
                    "to those paths only.[/dim]",
                    title="Chat Commands",
                    border_style="cyan",
                    expand=False,
                )
            )

        elif command == "/tokens":
            n_msgs = len(self.session.messages)
            ctx_used_pct = (
                (self._token_count / self.config.max_context_tokens * 100)
                if self.config.max_context_tokens
                else 0
            )
            console.print(
                f"  [bold]Messages:[/bold] {n_msgs}  |  "
                f"[bold]Tokens (approx):[/bold] {self._token_count:,}  |  "
                f"[bold]Context window:[/bold] {self.config.max_context_tokens:,}  |  "
                f"[bold]Utilization:[/bold] {ctx_used_pct:.0f}%\n"
                f"  [bold]Tool calls:[/bold] {self._tool_calls_count}  |  "
                f"[bold]Inference rounds:[/bold] {self._rounds_count}"
            )

        else:
            console.print(f"[yellow]Unknown command: {command}. Type /help for options.[/yellow]")

        return True

    def _print_focus_status(self) -> None:
        """Print the current focus paths to the console."""
        if not self.session.has_focus():
            console.print("  [dim]No focus set — searching entire codebase.[/dim]")
            return
        console.print("  [bold]Focus paths:[/bold]")
        for fp in self.session.focus_paths:
            full = self.repo_path / fp
            if full.is_dir():
                # Count files in directory
                count = sum(1 for _ in full.rglob("*") if _.is_file())
                console.print(f"    [cyan]{fp}/[/cyan]  ({count} files)")
            elif full.is_file():
                console.print(f"    [cyan]{fp}[/cyan]")
            else:
                console.print(f"    [yellow]{fp}[/yellow] (missing)")
