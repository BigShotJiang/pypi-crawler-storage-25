# Plan: click-docs v1.0

> Source PRD: prd.md

## Architectural decisions

- **CLI entry point**: `click-docs [OPTIONS] MODULE_PATH` registered as a console script in `pyproject.toml`
- **Modules**: `click_docs/cli.py`, `click_docs/loader.py`, `click_docs/config.py`, `click_docs/generator.py`, `click_docs/formatters.py`
- **Config**: `[tool.click-docs]` table in `pyproject.toml`; CLI flags always take precedence over config file values
- **Output**: stdout by default; file path via `--output` (silently overwritten if exists)
- **Error handling**: single-line human-readable message on stderr, exit code 1 — no tracebacks shown
- **Testing**: snapshot tests against a fixture Click app (following the pattern in `mkdocs-click-click/tests/`)
- **Reference material**: `mkdocs-click-click/` is for inspiration only — do not import from it

---

## Phase 1: Basic end-to-end pipeline

**User stories**: 1, 2, 3, 4, 19, 20, 22

### What to build

A working `click-docs` command that accepts a file system path to a Python module, loads it via `importlib`, resolves a dotted attribute path to a Click command object (defaulting to `cli`), generates minimal Markdown for that single command (name, description, and options in plain style), and writes the result to stdout or a file. Errors (bad path, missing attribute, non-Click object, unwritable output directory) produce a single-line stderr message and exit code 1.

The pipeline at this phase: `cli.py` → `loader.py` → `generator.py` (root command only) → output.

### Acceptance criteria

- [ ] `click-docs src/myapp/cli.py` prints Markdown to stdout
- [ ] `click-docs --output docs/cli.md src/myapp/cli.py` writes to the file (overwrites silently if it exists)
- [ ] `--command-name` defaults to `cli`; a dotted path like `commands.root` resolves correctly
- [ ] A bad module path exits with code 1 and a descriptive stderr message
- [ ] A missing or non-Click attribute exits with code 1 and a descriptive stderr message
- [ ] An `--output` path whose parent directory does not exist exits with code 1 and a descriptive message
- [ ] Python 3.9–3.15 CI passes (tox or equivalent)
- [ ] Unit tests for `loader.py` cover all four cases: valid, bad path, missing attribute, non-Click object
