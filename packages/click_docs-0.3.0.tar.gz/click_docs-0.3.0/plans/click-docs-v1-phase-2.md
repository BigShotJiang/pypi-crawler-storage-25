# Plan: click-docs v1.0

> Source PRD: prd.md

## Architectural decisions

- **CLI entry point**: `click-docs [OPTIONS] MODULE_PATH` registered as a console script in `pyproject.toml`
- **Modules**: `click_docs/cli.py`, `click_docs/loader.py`, `click_docs/config.py`, `click_docs/generator.py`, `click_docs/formatters.py`
- **Config**: `[tool.click-docs]` table in `pyproject.toml`; CLI flags always take precedence over config file values
- **Output**: stdout by default; file path via `--output` (silently overwritten if exists)
- **Error handling**: single-line human-readable message on stderr, exit code 1 — no tracebacks shown
- **Testing**: snapshot tests against a fixture Click app (following the pattern in `mkdocs-click-click/tests/`)
- **Reference material**: `mkdocs-click-click/` is for inspiration only — do not import from it

---

## Phase 2: Formatting control

**User stories**: 5, 6, 7, 24, 25

### What to build

Extend the generator with formatting options. `--program-name` controls the display name in headers independent of the Python attribute. `--header-depth` (1–6, default 1) sets the starting Markdown header level. `--style plain` (default) renders options as a preformatted block extracted from Click's own formatter; `--style table` renders a Markdown table with Name, Type, and Description columns. The table style renders constraints for special Click types: `Choice` (list of values), `IntRange`/`FloatRange` (bounds), `DateTime` (format strings), `File` (mode). The `\f` escape is always honoured — text after `\f` is never included in output.

### Acceptance criteria

- [ ] `--program-name myapp` appears as the command name in all generated headers and usage lines
- [ ] `--header-depth 2` produces `##` as the top-level header; depth 3 produces `###`, etc.
- [ ] `--style plain` produces a fenced code block matching Click's own `--help` options section
- [ ] `--style table` produces a Markdown table with Name, Type, Description columns
- [ ] Table style shows Choice constraints (e.g. `one of: a, b, c`)
- [ ] Table style shows IntRange/FloatRange bounds (e.g. `0<=x<=100`)
- [ ] Table style shows DateTime format string and File mode
- [ ] Help text containing `\f` is truncated at `\f` in all styles
- [ ] Snapshot tests cover plain and table output for a fixture command with all special types
