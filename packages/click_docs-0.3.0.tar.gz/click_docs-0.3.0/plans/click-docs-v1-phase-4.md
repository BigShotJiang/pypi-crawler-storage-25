# Plan: click-docs v1.0

> Source PRD: prd.md

## Architectural decisions

- **CLI entry point**: `click-docs [OPTIONS] MODULE_PATH` registered as a console script in `pyproject.toml`
- **Modules**: `click_docs/cli.py`, `click_docs/loader.py`, `click_docs/config.py`, `click_docs/generator.py`, `click_docs/formatters.py`
- **Config**: `[tool.click-docs]` table in `pyproject.toml`; CLI flags always take precedence over config file values
- **Output**: stdout by default; file path via `--output` (silently overwritten if exists)
- **Error handling**: single-line human-readable message on stderr, exit code 1 — no tracebacks shown
- **Testing**: snapshot tests against a fixture Click app (following the pattern in `mkdocs-click-click/tests/`)
- **Reference material**: `mkdocs-click-click/` is for inspiration only — do not import from it


## Phase 4: Config file integration

**User stories**: 17, 18, 21, 23

### What to build

Add `config.py`, which walks up from the current working directory to find `pyproject.toml` and reads the `[tool.click-docs]` table. The returned dict of defaults is merged with CLI flag values before the pipeline runs; CLI flags always win. If no `pyproject.toml` is found, an empty dict is used and the tool continues normally. Output is deterministic: same inputs always produce identical Markdown with no timestamps or environment-dependent content.

### Acceptance criteria

- [ ] `[tool.click-docs]` values in `pyproject.toml` are used as defaults when CLI flags are not provided
- [ ] A CLI flag always overrides the corresponding `pyproject.toml` value
- [ ] Config is found when `pyproject.toml` is in a parent directory of cwd
- [ ] Tool runs normally (no error) when no `pyproject.toml` is found anywhere
- [ ] Running the tool twice with identical inputs produces byte-for-byte identical output
- [ ] Unit tests for `config.py`: found and parsed, not found (returns empty dict), found in parent directory
- [ ] Integration test: a `pyproject.toml` fixture with `[tool.click-docs]` values is overridden by CLI flags
