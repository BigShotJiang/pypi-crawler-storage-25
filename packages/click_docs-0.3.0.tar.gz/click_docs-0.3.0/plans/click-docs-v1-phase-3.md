# Plan: click-docs v1.0

> Source PRD: prd.md

## Architectural decisions

- **CLI entry point**: `click-docs [OPTIONS] MODULE_PATH` registered as a console script in `pyproject.toml`
- **Modules**: `click_docs/cli.py`, `click_docs/loader.py`, `click_docs/config.py`, `click_docs/generator.py`, `click_docs/formatters.py`
- **Config**: `[tool.click-docs]` table in `pyproject.toml`; CLI flags always take precedence over config file values
- **Output**: stdout by default; file path via `--output` (silently overwritten if exists)
- **Error handling**: single-line human-readable message on stderr, exit code 1 — no tracebacks shown
- **Testing**: snapshot tests against a fixture Click app (following the pattern in `mkdocs-click-click/tests/`)
- **Reference material**: `mkdocs-click-click/` is for inspiration only — do not import from it


## Phase 3: Subcommand tree navigation

**User stories**: 8, 9, 10, 11, 12, 13, 14, 15, 16

### What to build

Make the generator recursive. It walks the Click command tree depth-first, documenting each subcommand at the appropriate header level. `--depth N` limits recursion (0 = root only, omitted = unlimited). `--exclude` accepts a dotted command path (e.g. `admin.reset`) and can be passed multiple times; excluded commands and their subtrees are skipped entirely. `--show-hidden` includes commands and options marked `hidden=True`; by default they are omitted. `--list-subcommands` prepends a bulleted table of contents whose links use anchor IDs that match the generated command headers. `--remove-ascii-art` strips all text from a `\b` character up to the next blank line before including docstring content.

### Acceptance criteria

- [ ] A `Group` command generates documentation for all subcommands recursively
- [ ] `--depth 0` documents only the root command, no subcommands
- [ ] `--depth 1` documents the root and its direct children only
- [ ] Omitting `--depth` documents all levels
- [ ] `--exclude admin.reset` omits the `reset` subcommand under `admin` and its children
- [ ] `--exclude` can be passed multiple times to exclude several commands
- [ ] Hidden commands and options are omitted by default; `--show-hidden` includes them
- [ ] `--list-subcommands` prepends a bulleted TOC; each entry links to the corresponding section anchor
- [ ] TOC anchors resolve correctly in GitHub Markdown and standard renderers
- [ ] `--remove-ascii-art` strips `\b`-prefixed content up to the next blank line
- [ ] Without `--remove-ascii-art`, `\b` content is preserved
- [ ] Snapshot tests cover: group with subcommands, depth limiting, exclusion, hidden commands, TOC, `\b` removal
