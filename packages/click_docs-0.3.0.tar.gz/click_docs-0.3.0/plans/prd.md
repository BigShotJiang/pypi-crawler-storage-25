# click-docs v1.0 PRD

## Problem Statement

Python developers who build CLI tools with Click have no easy way to generate documentation for their tools without adopting MkDocs or another specific documentation framework. The existing `mkdocs-click` extension solves this within the MkDocs ecosystem, but forces developers into that toolchain even when they only need a Markdown file. There is no standalone tool that takes a Click application and produces ready-to-use Markdown documentation compatible with any doc platform.

## Solution

A standalone CLI tool (`click-docs`) that introspects a Click application and generates well-formatted Markdown documentation. The tool accepts a file system path to a Python module and a dotted attribute path to the Click command object, then produces Markdown output to stdout or a file. The output is compatible with any documentation platform that accepts Markdown (GitHub wikis, Sphinx via MyST, Hugo, plain files, etc.).

## User Stories

1. As a Python developer, I want to run `click-docs src/myapp/cli.py` and get Markdown documentation printed to my terminal, so that I can preview what the generated docs look like.
2. As a Python developer, I want to specify `--output docs/cli.md` so that the generated Markdown is written directly to a file without manual redirection.
3. As a Python developer, I want to specify `--command-name app.commands.root` using a dotted path so that I can document a command object that is not at the top level of a module.
4. As a Python developer, I want `--command-name` to default to `cli` so that I don't have to type it for the common case.
5. As a Python developer, I want to set `--program-name` to control the display name of my command in the generated docs, independent of the Python attribute name.
6. As a Python developer, I want to control the starting header depth with `--header-depth` so that I can embed the generated documentation within existing Markdown content without header level conflicts.
7. As a Python developer, I want to choose between `--style plain` and `--style table` for the options section so that I can match the formatting conventions of my documentation platform.
8. As a Python developer, I want to use `--remove-ascii-art` to strip content prefixed with `\b` from docstrings so that decorative ASCII art in my CLI help text does not appear in written documentation.
9. As a Python developer, I want to use `--show-hidden` to include commands and options marked as hidden so that I can generate internal or developer-facing documentation.
10. As a Python developer, I want to use `--list-subcommands` to generate a bulleted table of contents at the top of the document so that readers can navigate a large CLI reference quickly.
11. As a Python developer, I want the table of contents to link to anchor IDs that match the generated command headers so that the links actually work in any standard Markdown renderer.
12. As a Python developer, I want to use `--exclude admin.reset` to omit specific subcommands (by dotted path) from the generated documentation so that internal or dangerous commands are not published.
13. As a Python developer, I want to pass `--exclude` multiple times to exclude several commands at once.
14. As a Python developer, I want to use `--depth` to limit how many levels of subcommands are documented so that I can produce a high-level reference without expanding every leaf command.
15. As a Python developer, I want `--depth 0` to document only the root command so that I have fine-grained control over scope.
16. As a Python developer, I want omitting `--depth` to document all levels so that I don't have to guess the right number.
17. As a Python developer, I want to store default options under `[tool.click-docs]` in `pyproject.toml` so that I don't have to repeat flags on every run.
18. As a Python developer, I want CLI flags to always override `pyproject.toml` values so that I can do one-off runs without editing config.
19. As a CI/CD engineer, I want the tool to exit with a non-zero status code when it encounters an error so that documentation generation failures break the build.
20. As a Python developer, I want clear, human-readable error messages when I provide a bad module path, a missing command name, or a non-Click object so that I can fix the problem quickly.
21. As a Python developer, I want the output file to be silently overwritten if it already exists so that I can re-run the tool without prompts in automated pipelines.
22. As a Python developer, I want the tool to support Python 3.9 through 3.15 so that it works with my existing project regardless of which version I target.
23. As a documentation maintainer, I want the generated Markdown to be deterministic given the same inputs so that re-running the tool in CI does not produce spurious diffs.
24. As a Python developer, I want option types (Choice, DateTime, IntRange, FloatRange, File) to be rendered with their constraints in the table style so that readers understand the valid values.
25. As a Python developer, I want the `\f` Click escape to truncate help text (as Click itself does) so that content intended only for terminal help is not leaked into written docs.

## Implementation Decisions

### Modules

- **`click_docs/cli.py`** — Click-based entry point. Declares all CLI options, reads and merges `pyproject.toml` config (CLI flags take precedence), validates inputs, and orchestrates the loader → generator → output pipeline.
- **`click_docs/loader.py`** — Loads a Python module from a file system path using `importlib`. Resolves a dotted attribute path on the loaded module to retrieve the Click command object. Raises descriptive errors for import failures, missing attributes, and non-Click objects.
- **`click_docs/config.py`** — Locates and parses `pyproject.toml` by walking up from the current working directory. Reads the `[tool.click-docs]` table and returns a dict of option defaults. Returns an empty dict if no config file is found.
- **`click_docs/generator.py`** — Core recursive documentation generator. Walks the Click command tree respecting `--depth`, `--exclude` (dotted paths), `--show-hidden`, and `--remove-ascii-art`. Produces a table of contents when `--list-subcommands` is set. Delegates option section rendering to `formatters.py`.
- **`click_docs/formatters.py`** — Renders a command's options section in either plain (preformatted code block extracted from Click's own formatter) or table (Markdown table with Name, Type, Description columns) style. Handles special Click types: `Choice`, `DateTime`, `IntRange`, `FloatRange`, `File`.

### CLI Interface

```
click-docs [OPTIONS] MODULE_PATH
```

| Option               | Type                     | Default                  | Description                                       |
|----------------------|--------------------------|--------------------------|---------------------------------------------------|
| `--command-name`     | dotted string            | `cli`                    | Dotted attribute path to the Click command        |
| `--program-name`     | string                   | same as `--command-name` | Display name in generated docs                    |
| `--header-depth`     | int (1–6)                | `1`                      | Starting Markdown header level                    |
| `--style`            | choice: `plain`, `table` | `plain`                  | Options section format                            |
| `--remove-ascii-art` | flag                     | `False`                  | Strip `\b`-prefixed content from docstrings       |
| `--show-hidden`      | flag                     | `False`                  | Include hidden commands and options               |
| `--list-subcommands` | flag                     | `False`                  | Prepend a bulleted TOC of all documented commands |
| `--exclude`          | dotted string (multiple) | —                        | Dotted command path(s) to omit                    |
| `--depth`            | int ≥ 0                  | unlimited                | Maximum subcommand recursion depth                |
| `--output`           | file path                | stdout                   | Output file (silently overwritten if exists)      |

### Config File

`pyproject.toml` under `[tool.click-docs]` accepts all of the above options using the same names (with hyphens or underscores). Example:

```toml
[tool.click-docs]
command-name = "main.app"
style = "table"
header-depth = 2
exclude = ["admin.reset", "debug"]
```

CLI flags always override config file values.

### Module Loading

- `MODULE_PATH` is a file system path (absolute or relative to cwd), e.g. `src/myapp/cli.py`.
- `--command-name` is a dotted attribute path resolved against the loaded module, e.g. `commands.root` resolves as `module.commands.root`.
- If any segment of the dotted path does not exist, a clear error names the missing segment.

### Subcommand Exclusion

`--exclude` accepts a dotted command name path relative to the root command, e.g. `--exclude admin.reset` excludes the `reset` subcommand under `admin`. The root command itself cannot be excluded.

### Output

- If `--output` is not set, write to stdout.
- If `--output` is set and the file exists, overwrite silently.
- If the output directory does not exist, raise a friendly error and exit non-zero.

### Error Handling

All errors produce a single-line human-readable message on stderr and exit with code 1. No tracebacks are shown to end users.

### Special Escape Handling

- `\b` at the start of a docstring section: when `--remove-ascii-art` is set, all text from `\b` up to the next blank line is stripped.
- `\f` in help text: always truncated (matching Click's own behavior). Text after `\f` is never included in output.

## Testing Decisions

**What makes a good test:** Tests should verify observable output (the generated Markdown string or file contents) given a known Click command structure. Tests should not assert on internal data structures or call private functions directly — only on what a caller of the public API would observe.

### Modules to test

- **`loader.py`** — Unit tests: valid file path + valid dotted command name returns correct Click object; invalid file path raises friendly error; missing attribute raises friendly error; attribute resolves to non-Click object raises friendly error.
- **`config.py`** — Unit tests: finds and parses `pyproject.toml` correctly; returns empty dict when no file found; walking up directories finds parent config.
- **`generator.py`** — Snapshot tests against a fixture Click app covering: simple command, group with subcommands, depth limiting, exclusions, hidden commands, `\b` removal, `--list-subcommands` TOC output.
- **`formatters.py`** — Unit tests: plain style output for a known set of options; table style output including special types (Choice, IntRange, etc.).
- **Integration (CLI)** — End-to-end tests using Click's `CliRunner`: full invocation against the fixture app with various option combinations; verify stdout and file output; verify non-zero exit and stderr message for error cases.

### Prior art

The `mkdocs-click` submodule at `mkdocs-click-click/tests/` demonstrates the snapshot testing pattern: a fixture CLI app with known structure, expected output files stored alongside tests, and pytest assertions comparing generated output against stored snapshots. The same pattern should be used here.

## Out of Scope

- Output formats other than Markdown (RST, HTML, plain text).
- Documenting multiple modules or multiple commands in a single run.
- Watching files for changes and regenerating automatically.
- MkDocs plugin or extension integration.
- Generating documentation for non-Click CLI frameworks (argparse, Typer, etc.).
- Interactive prompts on output file overwrite.
- A programmatic Python API (the public interface is the CLI only for v1.0).

## Further Notes

- The `mkdocs-click` submodule (`mkdocs-click-click/`) is reference material only. No code should be imported from it; it exists in the repo for inspiration.
- The tool should be registered as a console script entry point in `pyproject.toml` so that `click-docs` is available on `PATH` after installation.
- Generated Markdown should be deterministic: same inputs always produce identical output, with no timestamps or environment-dependent content.
