::: click_docs.generator
