"""Unit test package for click_docs."""
