---
name: release
description: Cut a release by bumping version, generating changelog, committing, and tagging
disable-model-invocation: true
---

Run the release process for click-docs:

1. Ask the user what version bump type they want: `patch`, `minor`, or `major` (if not provided as args)
2. Run `uv run bump-my-version bump {{args}}` to bump the version
3. Run `uv run generate-changelog` to update CHANGELOG.md
4. Show the user the resulting diff with `git diff`
5. Ask the user to confirm before proceeding
6. Stage and commit: `git add CHANGELOG.md click_docs/__init__.py && git commit -m "Version updated from ... to ..."`
7. Push with tags: `git push && git push --tags`
8. Remind the user the GitHub Actions release workflow will now trigger
