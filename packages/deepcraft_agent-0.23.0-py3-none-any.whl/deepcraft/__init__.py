"""DeepCraft — DeepSeek-powered AI coding agent."""

__version__ = "0.23.0"
