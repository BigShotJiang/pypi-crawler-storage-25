"""GitHub PR workflow — create, list, monitor, and merge pull requests.

Architecture:
    PRWorkflow
    ├── create_pr()  → create Pull Request via GitHub REST API
    ├── list_prs()   → list open/closed PRs
    ├── get_pr()     → get PR details by number
    ├── pr_status()  → CI check status for a PR
    ├── merge_pr()   → merge PR (squash/merge/rebase)
    └── close_pr()   → close PR without merging

Zero external dependencies — uses urllib + json from stdlib.
Requires a GitHub token with repo scope.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from deepcraft.agent.github_client import GitHubClient


def _read_token() -> str | None:
    """Read GitHub token from secrets file or environment."""
    # Try env var first
    token = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
    if token:
        return token

    # Try secrets file
    secret_paths = [
        Path.home() / ".hermes/secrets/github-token",
        Path.home() / ".hermes/secrets/github_token",
    ]
    for p in secret_paths:
        if p.exists():
            token = p.read_text().strip()
            if token:
                return token
    return None


@dataclass
class PRInfo:
    """Pull request metadata."""

    number: int
    title: str
    state: str  # open, closed, merged
    head_branch: str
    base_branch: str
    author: str
    created_at: str
    updated_at: str
    url: str
    draft: bool = False
    mergeable: bool | None = None
    body: str = ""
    labels: list[str] = field(default_factory=list)


@dataclass
class PRStatus:
    """CI status for a pull request."""

    pr_number: int
    state: str  # success, failure, pending, error
    total_checks: int = 0
    passed: int = 0
    failed: int = 0
    pending: int = 0
    checks: list[dict[str, str]] = field(default_factory=list)

    @property
    def summary(self) -> str:
        return (
            f"PR #{self.pr_number}: {self.state} "
            f"({self.passed}/{self.total_checks} passed"
            + (f", {self.failed} failed" if self.failed else "")
            + (f", {self.pending} pending" if self.pending else "")
            + ")"
        )


class PRWorkflow:
    """GitHub Pull Request workflow manager.

    Usage:
        pr = PRWorkflow(owner="liyuan1161", repo="deepcraft")
        info = pr.create_pr("feat: add login", "## Summary\\n...", "feat/login")
        print(pr.list_prs())
        status = pr.pr_status(42)
        pr.merge_pr(42)
    """

    def __init__(
        self,
        owner: str,
        repo: str,
        token: str | None = None,
    ) -> None:
        self.owner = owner
        self.repo = repo
        self.token = token or _read_token()
        if not self.token:
            raise ValueError(
                "GitHub token not found. Set GITHUB_TOKEN env var "
                "or create ~/.hermes/secrets/github-token"
            )
        self._client = GitHubClient(self.token, owner, repo)

    # ── API helpers ────────────────────────────────────────────

    def _api(
        self,
        method: str,
        path: str,
        data: dict | None = None,
    ) -> dict[str, Any]:
        """Call GitHub REST API and return parsed JSON — delegates to GitHubClient."""
        return self._client._request(method, path, data=data)

    def _detect_owner_repo(self) -> tuple[str, str] | None:
        """Detect owner/repo from git remote in current directory."""
        import subprocess

        try:
            url = subprocess.check_output(
                ["git", "remote", "get-url", "origin"],
                text=True,
                stderr=subprocess.DEVNULL,
            ).strip()
        except (subprocess.CalledProcessError, FileNotFoundError):
            return None

        # Parse GitHub URL: https://.../owner/repo.git or git@...:owner/repo.git
        for pattern in [
            r"github\.com[:/]([^/]+)/([^/\s]+?)(?:\.git)?$",
        ]:
            import re

            m = re.search(pattern, url)
            if m:
                return m.group(1), m.group(2)
        return None

    @classmethod
    def auto(cls, token: str | None = None) -> PRWorkflow:
        """Auto-detect owner/repo from git remote.

        Raises RuntimeError if not in a git repo with a GitHub remote.
        """
        inst = cls("", "", token)
        detected = inst._detect_owner_repo()
        if not detected:
            raise RuntimeError(
                "Cannot detect GitHub owner/repo. "
                "Run from a git repo with a GitHub remote, "
                "or use PRWorkflow(owner, repo) directly."
            )
        owner, repo = detected
        inst.owner = owner
        inst.repo = repo
        inst._api_base = f"https://api.github.com/repos/{owner}/{repo}"
        return inst

    # ── PR operations ─────────────────────────────────────────

    def create_pr(
        self,
        title: str,
        body: str = "",
        head_branch: str | None = None,
        base_branch: str = "main",
        draft: bool = False,
    ) -> PRInfo:
        """Create a new pull request.

        Args:
            title: PR title (conventional commit format recommended).
            body: PR description (markdown).
            head_branch: Source branch. If omitted, uses current git branch.
            base_branch: Target branch (default: main).
            draft: Create as draft PR.

        Returns:
            PRInfo with the new PR's metadata.

        Raises:
            RuntimeError: API call failed.
            ValueError: Could not determine head branch.
        """
        if head_branch is None:
            import subprocess

            try:
                head_branch = subprocess.check_output(
                    ["git", "branch", "--show-current"],
                    text=True,
                    stderr=subprocess.DEVNULL,
                ).strip()
            except (subprocess.CalledProcessError, FileNotFoundError):
                raise ValueError(
                    "Cannot determine branch. Specify head_branch explicitly."
                ) from None

        payload: dict[str, Any] = {
            "title": title,
            "head": head_branch,
            "base": base_branch,
        }
        if body:
            payload["body"] = body
        if draft:
            payload["draft"] = True

        data = self._api("POST", "/pulls", payload)

        labels_list = [lb["name"] for lb in data.get("labels", [])]

        return PRInfo(
            number=data["number"],
            title=data["title"],
            state=data["state"],
            head_branch=data["head"]["ref"],
            base_branch=data["base"]["ref"],
            author=data["user"]["login"],
            created_at=data["created_at"],
            updated_at=data["updated_at"],
            url=data["html_url"],
            draft=data.get("draft", False),
            body=data.get("body", ""),
            labels=labels_list,
        )

    def list_prs(self, state: str = "open") -> list[PRInfo]:
        """List pull requests.

        Args:
            state: 'open', 'closed', or 'all'.
        """
        data = self._api("GET", f"/pulls?state={state}&per_page=30")
        results = []
        for pr in data:
            results.append(
                PRInfo(
                    number=pr["number"],
                    title=pr["title"],
                    state=pr["state"],
                    head_branch=pr["head"]["ref"],
                    base_branch=pr["base"]["ref"],
                    author=pr["user"]["login"],
                    created_at=pr["created_at"],
                    updated_at=pr["updated_at"],
                    url=pr["html_url"],
                    draft=pr.get("draft", False),
                )
            )
        return results

    def get_pr(self, pr_number: int) -> PRInfo:
        """Get details for a specific PR."""
        data = self._api("GET", f"/pulls/{pr_number}")
        labels_list = [lb["name"] for lb in data.get("labels", [])]

        # Check mergeable via separate endpoint
        mergeable = None
        try:
            self._api("GET", f"/pulls/{pr_number}/merge")
            mergeable = True
        except RuntimeError:
            mergeable = None  # 404 or merge conflict — will be None

        return PRInfo(
            number=data["number"],
            title=data["title"],
            state=data["state"],
            head_branch=data["head"]["ref"],
            base_branch=data["base"]["ref"],
            author=data["user"]["login"],
            created_at=data["created_at"],
            updated_at=data["updated_at"],
            url=data["html_url"],
            draft=data.get("draft", False),
            mergeable=mergeable,
            body=data.get("body", ""),
            labels=labels_list,
        )

    def pr_status(self, pr_number: int) -> PRStatus:
        """Check CI status for a pull request.

        Combines status checks and check runs for the PR's head commit.
        """
        pr_data = self._api("GET", f"/pulls/{pr_number}")
        head_sha = pr_data["head"]["sha"]

        status = PRStatus(pr_number=pr_number, state="pending")

        # Combined status checks
        try:
            status_data = self._api(
                "GET", f"/commits/{head_sha}/status"
            )
            for s in status_data.get("statuses", []):
                status.checks.append({
                    "name": s.get("context", "unknown"),
                    "state": s.get("state", "unknown"),
                    "url": s.get("target_url", ""),
                })
        except Exception:
            pass

        # Check runs (GitHub Actions)
        try:
            runs_data = self._api(
                "GET", f"/commits/{head_sha}/check-runs"
            )
            for cr in runs_data.get("check_runs", []):
                conclusion = cr.get("conclusion") or "pending"
                status.checks.append({
                    "name": cr.get("name", "unknown"),
                    "state": conclusion,
                    "url": cr.get("html_url", ""),
                })
        except Exception:
            pass

        # Aggregate
        for c in status.checks:
            status.total_checks += 1
            s = c["state"]
            if s == "success":
                status.passed += 1
            elif s in ("failure", "error", "timed_out", "action_required"):
                status.failed += 1
            else:
                status.pending += 1

        if status.failed > 0:
            status.state = "failure"
        elif status.total_checks == 0 or status.pending > 0:
            status.state = "pending"
        elif status.passed == status.total_checks:
            status.state = "success"

        # Use combined state if available
        try:
            combined = self._api("GET", f"/commits/{head_sha}/status")
            cstate = combined.get("state", "pending")
            if cstate in ("success", "failure", "error", "pending"):
                status.state = cstate
        except Exception:
            pass

        return status

    def merge_pr(
        self,
        pr_number: int,
        method: str = "squash",
        commit_title: str | None = None,
    ) -> dict[str, Any]:
        """Merge a pull request.

        Args:
            pr_number: PR number to merge.
            method: Merge method — 'merge', 'squash', or 'rebase'.
            commit_title: Custom merge commit title.

        Returns:
            API response dict with 'merged' and 'message'.
        """
        payload: dict[str, Any] = {"merge_method": method}
        if commit_title:
            payload["commit_title"] = commit_title

        return self._api("PUT", f"/pulls/{pr_number}/merge", payload)

    def close_pr(self, pr_number: int) -> dict[str, Any]:
        """Close a pull request without merging."""
        return self._api(
            "PATCH", f"/pulls/{pr_number}", {"state": "closed"}
        )

    def get_branch_sha(self, branch: str) -> str:
        """Get the latest commit SHA for a branch."""
        data = self._api("GET", f"/git/refs/heads/{branch}")
        return data["object"]["sha"]

    def branch_exists(self, branch: str) -> bool:
        """Check if a branch exists on the remote."""
        try:
            self.get_branch_sha(branch)
            return True
        except RuntimeError:
            return False

    # ── Formatting helpers ─────────────────────────────────────

    def format_pr(self, pr: PRInfo) -> str:
        """Format a PR as a readable string."""
        lines = [
            f"#{pr.number} {pr.title}",
            f"  State:  {pr.state}{' (draft)' if pr.draft else ''}",
            f"  Branch: {pr.head_branch} → {pr.base_branch}",
            f"  Author: {pr.author}",
            f"  URL:    {pr.url}",
        ]
        if pr.labels:
            lines.append(f"  Labels: {', '.join(pr.labels)}")
        return "\n".join(lines)

    def format_status(self, status: PRStatus) -> str:
        """Format PR status as a readable string."""
        lines = [status.summary]
        for c in status.checks:
            icon = {
                "success": "✅",
                "failure": "❌",
                "error": "❌",
                "timed_out": "⏰",
                "action_required": "⚠️",
            }.get(c["state"], "⏳")
            lines.append(f"  {icon} {c['name']}: {c['state']}")
        return "\n".join(lines)

    def format_list(self, prs: list[PRInfo]) -> str:
        """Format a list of PRs as a table."""
        if not prs:
            return "No PRs found."

        lines = []
        for pr in prs:
            draft_mark = " [DRAFT]" if pr.draft else ""
            lines.append(
                f"#{pr.number} {pr.title}{draft_mark} "
                f"({pr.head_branch} → {pr.base_branch}) "
                f"— {pr.author}"
            )
        return "\n".join(lines)
