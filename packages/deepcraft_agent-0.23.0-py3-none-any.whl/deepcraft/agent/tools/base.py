"""Tool base class and registry — pluggable tool system."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from deepcraft.agent.types import ToolDefinition


@dataclass
class ToolResult:
    """Result of executing a tool.

    Attributes:
        content: String output from the tool.
        is_error: Whether the execution failed.
        tool_call_id: Optional ID for mapping responses to calls (used in SSE streaming).
    """

    content: str
    is_error: bool = False
    tool_call_id: str = ""


class BaseTool(ABC):
    """Base class for all tools.

    Subclasses must define: name, description, parameters, and execute().
    """

    name: str
    description: str
    parameters: dict[str, Any] = field(default_factory=dict)

    def to_definition(self) -> ToolDefinition:
        """Convert to ToolDefinition for LLM function calling."""
        return ToolDefinition(
            name=self.name,
            description=self.description,
            parameters=self.parameters,
        )

    @abstractmethod
    async def execute(self, **kwargs: Any) -> ToolResult:
        """Execute the tool with given arguments."""
        ...

    @property
    def definition(self) -> ToolDefinition:
        return self.to_definition()


class ToolRegistry:
    """Registry for managing and discovering tools."""

    def __init__(self) -> None:
        self._tools: dict[str, BaseTool] = {}

    def register(self, tool: BaseTool) -> None:
        """Register a tool instance."""
        self._tools[tool.name] = tool

    def unregister(self, name: str) -> None:
        """Remove a tool by name."""
        self._tools.pop(name, None)

    def get(self, name: str) -> BaseTool | None:
        """Get a tool by name."""
        return self._tools.get(name)

    def list_definitions(self) -> list[ToolDefinition]:
        """Get all tool definitions for LLM context."""
        return [t.definition for t in self._tools.values()]

    async def execute(self, name: str, arguments: dict[str, Any]) -> ToolResult:
        """Execute a tool by name with arguments."""
        tool = self._tools.get(name)
        if tool is None:
            return ToolResult(content=f"Error: unknown tool '{name}'", is_error=True)
        try:
            return await tool.execute(**arguments)
        except Exception as e:
            return ToolResult(content=f"Error executing {name}: {e}", is_error=True)

    def __len__(self) -> int:
        return len(self._tools)

    def __contains__(self, name: str) -> bool:
        return name in self._tools
