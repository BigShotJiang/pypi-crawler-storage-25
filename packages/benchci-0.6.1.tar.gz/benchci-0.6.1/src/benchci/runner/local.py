from __future__ import annotations

import json
import platform
import subprocess
import tempfile
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

import typer

from benchci.config.bench import BenchConfig, NodeConfig, load_bench_config
from benchci.config.suite import (
    SuiteConfig,
    load_suite_config,
)
from benchci.gpio.factory import GpioManager, create_gpio_manager
from benchci.power.power import PowerManager, create_power_manager
from benchci.measurement.measurement import MeasurementManager, create_measurement_manager
from benchci.runner.failure import BenchCIFailure, build_failure, failure_summary_text
from benchci.runner.evidence import (
    build_evidence_report,
    copy_input_snapshots,
    finalize_evidence_report,
    write_evidence_files,
)
from benchci.runner.transport_logging import (
    print_bench_transport_summary,
    print_transport_config_summary,
)
from benchci.transport.factory import create_transport, get_transport_config


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _echo_info(message: str) -> None:
    typer.echo(f"[INFO] {message}")


def _echo_ok(message: str) -> None:
    typer.echo(f"[ OK ] {message}")


def _echo_warn(message: str) -> None:
    typer.echo(f"[WARN] {message}")


def _echo_fail(message: str) -> None:
    typer.echo(f"[FAIL] {message}")


def _echo_section(title: str) -> None:
    typer.echo("")
    typer.echo("=" * 72)
    typer.echo(title)
    typer.echo("=" * 72)


def _echo_detail(label: str, value: Any) -> None:
    typer.echo(f"       {label}: {value}")


def _echo_failure_context(title: str, details: dict[str, Any]) -> None:
    typer.echo(f"       {title}")
    for key, value in details.items():
        if value is None or value == "":
            continue
        typer.echo(f"         - {key}: {value}")


def _render_command(cmd: list[str]) -> str:
    return " ".join(str(x) for x in cmd)


def _write_log(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def _write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _artifact_label(artifact_path: Path) -> str:
    try:
        size = artifact_path.stat().st_size
        return f"{artifact_path} ({size} bytes)"
    except Exception:
        return str(artifact_path)


def _step_artifacts_for_failure(
    runtimes: dict[str, "NodeRuntime"],
    power_runtimes: dict[str, "PowerRuntime"],
    measurement_runtimes: dict[str, "MeasurementRuntime"] | None = None,
    *,
    step_type: str | None,
    node_name: str | None,
    transport_name: str | None = None,
    power_resource_name: str | None = None,
    measurement_resource_name: str | None = None,
) -> dict[str, str]:
    artifacts: dict[str, str] = {}
    if node_name and node_name in runtimes:
        runtime = runtimes[node_name]
        if step_type in {"flash", "reset"} and runtime.flash_log_path:
            artifacts["flash_log"] = str(runtime.flash_log_path.resolve())
        if step_type and step_type.startswith("gpio") and runtime.gpio_log_path:
            artifacts["gpio_log"] = str(runtime.gpio_log_path.resolve())
        if transport_name and transport_name in runtime.transport_log_paths:
            artifacts["transport_log"] = str(runtime.transport_log_paths[transport_name].resolve())
        elif step_type in {"send_uart", "expect_uart", "send_can", "expect_can"} or (step_type or "").startswith("modbus"):
            if len(runtime.transport_log_paths) == 1:
                artifacts["transport_log"] = str(next(iter(runtime.transport_log_paths.values())).resolve())
    if power_resource_name and power_resource_name in power_runtimes:
        artifacts["power_log"] = str(power_runtimes[power_resource_name].log_path.resolve())
    if measurement_resource_name and measurement_runtimes and measurement_resource_name in measurement_runtimes:
        artifacts["measurement_log"] = str(measurement_runtimes[measurement_resource_name].log_path.resolve())
    return artifacts


def _echo_structured_failure(failure: dict[str, Any]) -> None:
    _echo_fail(failure_summary_text(failure))
    explanation = failure.get("explanation")
    if explanation:
        typer.echo(f"       explanation: {explanation}")
    failed_step = failure.get("failed_step") or {}
    if failed_step:
        typer.echo("       failed step:")
        for key, value in failed_step.items():
            typer.echo(f"         - {key}: {value}")
    suggestions = list(failure.get("suggestions") or [])
    if suggestions:
        typer.echo("       suggested fixes:")
        for suggestion in suggestions:
            typer.echo(f"         - {suggestion}")
    artifacts = failure.get("artifacts") or {}
    if artifacts:
        typer.echo("       useful artifacts:")
        for key, value in artifacts.items():
            typer.echo(f"         - {key}: {value}")


def _emit_event(
    event_cb: Callable[[dict], None] | None,
    event_type: str,
    message: str | None = None,
    data: dict[str, Any] | None = None,
) -> None:
    if event_cb is None:
        return

    payload = {
        "timestamp": _utc_now(),
        "event_type": event_type,
        "message": message,
        "data": data or {},
    }

    try:
        event_cb(payload)
    except Exception:
        # Event emission must never break the runner.
        pass


def _require_node(bench: BenchConfig, node_name: str) -> NodeConfig:
    node = bench.nodes.get(node_name)
    if node is None:
        known = ", ".join(sorted(bench.nodes.keys())) or "<none>"
        raise RuntimeError(f"Unknown node '{node_name}'. Known nodes: {known}")
    return node


def _resolve_node_name(bench: BenchConfig, explicit_node: str | None) -> str:
    if explicit_node:
        _require_node(bench, explicit_node)
        return explicit_node

    default_node = bench.defaults.node if bench.defaults else None
    if default_node:
        _require_node(bench, default_node)
        return default_node

    raise RuntimeError(
        "Step does not define a node and bench.defaults.node is not set"
    )


def _resolve_timeout(bench: BenchConfig, explicit_ms: int | None) -> int:
    if explicit_ms is not None:
        return explicit_ms

    default_ms = None
    if bench.defaults and bench.defaults.timeouts:
        default_ms = bench.defaults.timeouts.within_ms

    if default_ms is not None:
        return default_ms

    raise RuntimeError(
        "Step requires within_ms, but no step timeout and no bench.defaults.timeouts.within_ms were provided"
    )


def _safe_suite_name(suite: SuiteConfig) -> str:
    return suite.suite.name


def _safe_bench_name(bench: BenchConfig) -> str:
    return bench.bench.name


def _step_type(step: Any) -> str:
    if hasattr(step, "sleep_ms"):
        return "sleep_ms"
    if hasattr(step, "flash"):
        return "flash"
    if hasattr(step, "reset"):
        return "reset"
    if hasattr(step, "send_uart"):
        return "send_uart"
    if hasattr(step, "expect_uart"):
        return "expect_uart"
    if hasattr(step, "modbus_read_holding_registers"):
        return "modbus_read_holding_registers"
    if hasattr(step, "modbus_write_single_register"):
        return "modbus_write_single_register"
    if hasattr(step, "modbus_read_coils"):
        return "modbus_read_coils"
    if hasattr(step, "modbus_write_single_coil"):
        return "modbus_write_single_coil"
    if hasattr(step, "gpio_set"):
        return "gpio_set"
    if hasattr(step, "gpio_get"):
        return "gpio_get"
    if hasattr(step, "gpio_expect"):
        return "gpio_expect"
    if hasattr(step, "gpio_wait_edge"):
        return "gpio_wait_edge"
    if hasattr(step, "power_set"):
        return "power_set"
    if hasattr(step, "power_cycle"):
        return "power_cycle"
    if hasattr(step, "power_expect"):
        return "power_expect"
    if hasattr(step, "measure"):
        return "measure"
    if hasattr(step, "assert_metric"):
        return "assert_metric"
    if hasattr(step, "send_can"):
        return "send_can"
    if hasattr(step, "expect_can"):
        return "expect_can"
    return type(step).__name__


def _step_node(bench: BenchConfig, step: Any) -> str | None:
    if hasattr(step, "sleep_ms"):
        return None
    if hasattr(step, "flash"):
        return _resolve_node_name(bench, step.flash.node)
    if hasattr(step, "reset"):
        return _resolve_node_name(bench, step.reset.node)
    if hasattr(step, "send_uart"):
        return _resolve_node_name(bench, step.send_uart.node)
    if hasattr(step, "expect_uart"):
        return _resolve_node_name(bench, step.expect_uart.node)
    if hasattr(step, "modbus_read_holding_registers"):
        return _resolve_node_name(bench, step.modbus_read_holding_registers.node)
    if hasattr(step, "modbus_write_single_register"):
        return _resolve_node_name(bench, step.modbus_write_single_register.node)
    if hasattr(step, "modbus_read_coils"):
        return _resolve_node_name(bench, step.modbus_read_coils.node)
    if hasattr(step, "modbus_write_single_coil"):
        return _resolve_node_name(bench, step.modbus_write_single_coil.node)
    if hasattr(step, "gpio_set"):
        return _resolve_node_name(bench, step.gpio_set.node)
    if hasattr(step, "gpio_get"):
        return _resolve_node_name(bench, step.gpio_get.node)
    if hasattr(step, "gpio_expect"):
        return _resolve_node_name(bench, step.gpio_expect.node)
    if hasattr(step, "gpio_wait_edge"):
        return _resolve_node_name(bench, step.gpio_wait_edge.node)
    if hasattr(step, "power_set"):
        return None
    if hasattr(step, "power_cycle"):
        return None
    if hasattr(step, "power_expect"):
        return None
    if hasattr(step, "measure"):
        return None
    if hasattr(step, "assert_metric"):
        return None
    if hasattr(step, "send_can"):
        return _resolve_node_name(bench, step.send_can.node)
    if hasattr(step, "expect_can"):
        return _resolve_node_name(bench, step.expect_can.node)
    return None


@dataclass
class NodeRuntime:
    node_name: str
    node_cfg: NodeConfig
    node_dir: Path
    flash_log_path: Path
    gpio_log_path: Path
    transport_log_paths: dict[str, Path]
    transports: dict[str, Any]
    gpio: GpioManager | None = None


@dataclass
class PowerRuntime:
    resource_name: str
    log_path: Path
    manager: PowerManager


@dataclass
class MeasurementRuntime:
    resource_name: str
    log_path: Path
    manager: MeasurementManager


def _node_artifact_dir(out_dir: Path, node_name: str) -> Path:
    return out_dir / "nodes" / node_name


def _transport_log_path(out_dir: Path, node_name: str, transport_name: str) -> Path:
    return _node_artifact_dir(out_dir, node_name) / f"transport-{transport_name}.log"


def _flash_log_path(out_dir: Path, node_name: str) -> Path:
    return _node_artifact_dir(out_dir, node_name) / "flash.log"


def _gpio_log_path(out_dir: Path, node_name: str) -> Path:
    return _node_artifact_dir(out_dir, node_name) / "gpio.log"


def _power_log_path(out_dir: Path, resource_name: str) -> Path:
    return out_dir / "resources" / resource_name / "power.log"


def _measurement_log_path(out_dir: Path, resource_name: str) -> Path:
    return out_dir / "resources" / resource_name / "measurement.log"


def _collect_required_nodes(bench: BenchConfig, suite: SuiteConfig) -> set[str]:
    required: set[str] = set()

    for test in suite.tests:
        for step in test.steps:
            if hasattr(step, "sleep_ms"):
                continue

            if hasattr(step, "flash"):
                required.add(_resolve_node_name(bench, step.flash.node))
            elif hasattr(step, "reset"):
                required.add(_resolve_node_name(bench, step.reset.node))
            elif hasattr(step, "send_uart"):
                required.add(_resolve_node_name(bench, step.send_uart.node))
            elif hasattr(step, "expect_uart"):
                required.add(_resolve_node_name(bench, step.expect_uart.node))
            elif hasattr(step, "modbus_read_holding_registers"):
                required.add(_resolve_node_name(bench, step.modbus_read_holding_registers.node))
            elif hasattr(step, "modbus_write_single_register"):
                required.add(_resolve_node_name(bench, step.modbus_write_single_register.node))
            elif hasattr(step, "modbus_read_coils"):
                required.add(_resolve_node_name(bench, step.modbus_read_coils.node))
            elif hasattr(step, "modbus_write_single_coil"):
                required.add(_resolve_node_name(bench, step.modbus_write_single_coil.node))
            elif hasattr(step, "gpio_set"):
                required.add(_resolve_node_name(bench, step.gpio_set.node))
            elif hasattr(step, "gpio_get"):
                required.add(_resolve_node_name(bench, step.gpio_get.node))
            elif hasattr(step, "gpio_expect"):
                required.add(_resolve_node_name(bench, step.gpio_expect.node))
            elif hasattr(step, "gpio_wait_edge"):
                required.add(_resolve_node_name(bench, step.gpio_wait_edge.node))
            elif hasattr(step, "power_set"):
                continue
            elif hasattr(step, "power_cycle"):
                continue
            elif hasattr(step, "power_expect"):
                continue
            elif hasattr(step, "measure"):
                if step.measure.resource not in bench.resources:
                    known = ", ".join(sorted(bench.resources.keys())) or "<none>"
                    raise RuntimeError(
                        f"Test '{test.name}' uses measure on resource '{step.measure.resource}', "
                        f"but bench.resources defines: {known}"
                    )

            elif hasattr(step, "assert_metric"):
                continue

            elif hasattr(step, "send_can"):
                required.add(_resolve_node_name(bench, step.send_can.node))
            elif hasattr(step, "expect_can"):
                required.add(_resolve_node_name(bench, step.expect_can.node))
            else:
                raise RuntimeError(
                    f"Unsupported step model in suite parsing: {type(step).__name__}"
                )

    return required


def _collect_required_transports(bench: BenchConfig, suite: SuiteConfig) -> dict[str, set[str]]:
    required: dict[str, set[str]] = {}

    def add(node: str, transport: str) -> None:
        required.setdefault(node, set()).add(transport)

    for test in suite.tests:
        for step in test.steps:
            if hasattr(step, "send_uart"):
                node = _resolve_node_name(bench, step.send_uart.node)
                add(node, step.send_uart.transport)
            elif hasattr(step, "expect_uart"):
                node = _resolve_node_name(bench, step.expect_uart.node)
                add(node, step.expect_uart.transport)
            elif hasattr(step, "modbus_read_holding_registers"):
                node = _resolve_node_name(bench, step.modbus_read_holding_registers.node)
                add(node, step.modbus_read_holding_registers.transport)
            elif hasattr(step, "modbus_write_single_register"):
                node = _resolve_node_name(bench, step.modbus_write_single_register.node)
                add(node, step.modbus_write_single_register.transport)
            elif hasattr(step, "modbus_read_coils"):
                node = _resolve_node_name(bench, step.modbus_read_coils.node)
                add(node, step.modbus_read_coils.transport)
            elif hasattr(step, "modbus_write_single_coil"):
                node = _resolve_node_name(bench, step.modbus_write_single_coil.node)
                add(node, step.modbus_write_single_coil.transport)
            elif hasattr(step, "send_can"):
                node = _resolve_node_name(bench, step.send_can.node)
                add(node, step.send_can.transport)
            elif hasattr(step, "expect_can"):
                node = _resolve_node_name(bench, step.expect_can.node)
                add(node, step.expect_can.transport)

    return required


def _cross_validate_suite_against_bench(bench: BenchConfig, suite: SuiteConfig) -> None:
    for test in suite.tests:
        for step in test.steps:
            if hasattr(step, "sleep_ms"):
                continue

            if hasattr(step, "flash"):
                node_name = _resolve_node_name(bench, step.flash.node)
                node_cfg = _require_node(bench, node_name)
                if node_cfg.flash is None:
                    raise RuntimeError(
                        f"Test '{test.name}' uses flash on node '{node_name}', "
                        "but that node does not define a flash backend"
                    )

            elif hasattr(step, "reset"):
                node_name = _resolve_node_name(bench, step.reset.node)
                _require_node(bench, node_name)

            elif hasattr(step, "send_uart"):
                node_name = _resolve_node_name(bench, step.send_uart.node)
                cfg = get_transport_config(bench, node_name, step.send_uart.transport)
                if cfg.backend != "uart":
                    raise RuntimeError(
                        f"Test '{test.name}' uses send_uart on '{node_name}.{step.send_uart.transport}', "
                        f"but that transport backend is '{cfg.backend}', not 'uart'"
                    )

            elif hasattr(step, "expect_uart"):
                node_name = _resolve_node_name(bench, step.expect_uart.node)
                cfg = get_transport_config(bench, node_name, step.expect_uart.transport)
                if cfg.backend != "uart":
                    raise RuntimeError(
                        f"Test '{test.name}' uses expect_uart on '{node_name}.{step.expect_uart.transport}', "
                        f"but that transport backend is '{cfg.backend}', not 'uart'"
                    )

            elif hasattr(step, "modbus_read_holding_registers"):
                node_name = _resolve_node_name(bench, step.modbus_read_holding_registers.node)
                cfg = get_transport_config(bench, node_name, step.modbus_read_holding_registers.transport)
                if cfg.backend not in {"modbus_rtu", "modbus_tcp"}:
                    raise RuntimeError(
                        f"Test '{test.name}' uses modbus_read_holding_registers on "
                        f"'{node_name}.{step.modbus_read_holding_registers.transport}', "
                        f"but that transport backend is '{cfg.backend}'"
                    )

            elif hasattr(step, "modbus_write_single_register"):
                node_name = _resolve_node_name(bench, step.modbus_write_single_register.node)
                cfg = get_transport_config(bench, node_name, step.modbus_write_single_register.transport)
                if cfg.backend not in {"modbus_rtu", "modbus_tcp"}:
                    raise RuntimeError(
                        f"Test '{test.name}' uses modbus_write_single_register on "
                        f"'{node_name}.{step.modbus_write_single_register.transport}', "
                        f"but that transport backend is '{cfg.backend}'"
                    )

            elif hasattr(step, "modbus_read_coils"):
                node_name = _resolve_node_name(bench, step.modbus_read_coils.node)
                cfg = get_transport_config(bench, node_name, step.modbus_read_coils.transport)
                if cfg.backend not in {"modbus_rtu", "modbus_tcp"}:
                    raise RuntimeError(
                        f"Test '{test.name}' uses modbus_read_coils on "
                        f"'{node_name}.{step.modbus_read_coils.transport}', "
                        f"but that transport backend is '{cfg.backend}'"
                    )

            elif hasattr(step, "modbus_write_single_coil"):
                node_name = _resolve_node_name(bench, step.modbus_write_single_coil.node)
                cfg = get_transport_config(bench, node_name, step.modbus_write_single_coil.transport)
                if cfg.backend not in {"modbus_rtu", "modbus_tcp"}:
                    raise RuntimeError(
                        f"Test '{test.name}' uses modbus_write_single_coil on "
                        f"'{node_name}.{step.modbus_write_single_coil.transport}', "
                        f"but that transport backend is '{cfg.backend}'"
                    )

            elif hasattr(step, "gpio_set"):
                node_name = _resolve_node_name(bench, step.gpio_set.node)
                node_cfg = _require_node(bench, node_name)
                if step.gpio_set.line not in node_cfg.gpio:
                    known = ", ".join(sorted(node_cfg.gpio.keys())) or "<none>"
                    raise RuntimeError(
                        f"Test '{test.name}' uses gpio_set on line '{step.gpio_set.line}' for node '{node_name}', "
                        f"but that node defines lines: {known}"
                    )

            elif hasattr(step, "gpio_get"):
                node_name = _resolve_node_name(bench, step.gpio_get.node)
                node_cfg = _require_node(bench, node_name)
                if step.gpio_get.line not in node_cfg.gpio:
                    known = ", ".join(sorted(node_cfg.gpio.keys())) or "<none>"
                    raise RuntimeError(
                        f"Test '{test.name}' uses gpio_get on line '{step.gpio_get.line}' for node '{node_name}', "
                        f"but that node defines lines: {known}"
                    )

            elif hasattr(step, "gpio_expect"):
                node_name = _resolve_node_name(bench, step.gpio_expect.node)
                node_cfg = _require_node(bench, node_name)
                if step.gpio_expect.line not in node_cfg.gpio:
                    known = ", ".join(sorted(node_cfg.gpio.keys())) or "<none>"
                    raise RuntimeError(
                        f"Test '{test.name}' uses gpio_expect on line '{step.gpio_expect.line}' for node '{node_name}', "
                        f"but that node defines lines: {known}"
                    )

            elif hasattr(step, "gpio_wait_edge"):
                node_name = _resolve_node_name(bench, step.gpio_wait_edge.node)
                node_cfg = _require_node(bench, node_name)
                if step.gpio_wait_edge.line not in node_cfg.gpio:
                    known = ", ".join(sorted(node_cfg.gpio.keys())) or "<none>"
                    raise RuntimeError(
                        f"Test '{test.name}' uses gpio_wait_edge on line '{step.gpio_wait_edge.line}' for node '{node_name}', "
                        f"but that node defines lines: {known}"
                    )

            elif hasattr(step, "power_set"):
                if step.power_set.resource not in bench.resources:
                    known = ", ".join(sorted(bench.resources.keys())) or "<none>"
                    raise RuntimeError(
                        f"Test '{test.name}' uses power_set on resource '{step.power_set.resource}', "
                        f"but bench.resources defines: {known}"
                    )

            elif hasattr(step, "power_cycle"):
                if step.power_cycle.resource not in bench.resources:
                    known = ", ".join(sorted(bench.resources.keys())) or "<none>"
                    raise RuntimeError(
                        f"Test '{test.name}' uses power_cycle on resource '{step.power_cycle.resource}', "
                        f"but bench.resources defines: {known}"
                    )

            elif hasattr(step, "power_expect"):
                if step.power_expect.resource not in bench.resources:
                    known = ", ".join(sorted(bench.resources.keys())) or "<none>"
                    raise RuntimeError(
                        f"Test '{test.name}' uses power_expect on resource '{step.power_expect.resource}', "
                        f"but bench.resources defines: {known}"
                    )

            elif hasattr(step, "measure"):
                resource = bench.resources.get(step.measure.resource)
                if resource is None:
                    known = ", ".join(sorted(bench.resources.keys())) or "<none>"
                    raise RuntimeError(
                        f"Test '{test.name}' uses measure on resource '{step.measure.resource}', "
                        f"but bench.resources defines: {known}"
                    )
                if getattr(resource, "kind", None) != "measurement":
                    raise RuntimeError(
                        f"Test '{test.name}' uses measure on resource '{step.measure.resource}', "
                        f"but that resource kind is '{getattr(resource, 'kind', None)}', not 'measurement'"
                    )

            elif hasattr(step, "assert_metric"):
                continue

            elif hasattr(step, "send_can"):
                node_name = _resolve_node_name(bench, step.send_can.node)
                cfg = get_transport_config(bench, node_name, step.send_can.transport)
                if cfg.backend != "can":
                    raise RuntimeError(
                        f"Test '{test.name}' uses send_can on '{node_name}.{step.send_can.transport}', "
                        f"but that transport backend is '{cfg.backend}', not 'can'"
                    )

            elif hasattr(step, "expect_can"):
                node_name = _resolve_node_name(bench, step.expect_can.node)
                cfg = get_transport_config(bench, node_name, step.expect_can.transport)
                if cfg.backend != "can":
                    raise RuntimeError(
                        f"Test '{test.name}' uses expect_can on '{node_name}.{step.expect_can.transport}', "
                        f"but that transport backend is '{cfg.backend}', not 'can'"
                    )

            else:
                raise RuntimeError(
                    f"Unsupported step model in suite parsing: {type(step).__name__}"
                )


def _openocd_base_cmd(node: NodeConfig) -> list[str]:
    flash = node.flash
    if flash is None:
        raise RuntimeError("Node does not define a flash backend")
    cmd = [
        "openocd",
        "-f",
        flash.interface_cfg,
        "-f",
        flash.target_cfg,
    ]
    cmd += list(getattr(flash, "extra_args", []) or [])
    return cmd


def _openocd_common_init_cmds(node: NodeConfig) -> list[str]:
    flash = node.flash
    if flash is None:
        return []

    cmds: list[str] = []

    serial_cmd = getattr(flash, "probe_serial_cmd", None)
    if serial_cmd:
        cmds.append(serial_cmd)
    else:
        serial = getattr(flash, "probe_serial", None)
        if serial:
            cmds.append(f"hla_serial {serial}")

    speed = getattr(flash, "adapter_speed_khz", None)
    if speed:
        cmds.append(f"adapter speed {int(speed)}")

    return cmds


def _openocd_run_cmd(node: NodeConfig, commands: list[str]) -> str:
    cmd = _openocd_base_cmd(node)
    for c in _openocd_common_init_cmds(node):
        cmd += ["-c", c]
    for c in commands:
        cmd += ["-c", c]

    started_at = time.strftime("%Y-%m-%d %H:%M:%S")
    p = subprocess.run(
        cmd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    output = p.stdout or ""

    log_text = "\n".join(
        [
            "BenchCI flash backend: OpenOCD",
            f"Started at: {started_at}",
            f"CWD: {Path.cwd()}",
            f"Command: {_render_command(cmd)}",
            f"Exit code: {p.returncode}",
            "",
            "Tool output:",
            output,
        ]
    )

    if p.returncode != 0:
        raise RuntimeError("Hardware tool command failed. See the saved run logs for details.")

    return log_text


def _openocd_flash(node: NodeConfig, artifact_path: Path) -> str:
    artifact_path = artifact_path.expanduser().resolve()

    if artifact_path.suffix.lower() not in (".elf", ".hex"):
        raise RuntimeError(f"Unsupported artifact type: {artifact_path} (need .elf or .hex)")

    cmds = [
        "init",
        "reset halt",
        f"program {artifact_path} verify",
        "reset run",
        "shutdown",
    ]
    return _openocd_run_cmd(node, cmds)


def _openocd_reset_run(node: NodeConfig) -> str:
    cmds = [
        "init",
        "reset halt",
        "reset run",
        "shutdown",
    ]
    return _openocd_run_cmd(node, cmds)


def _cubeprog_flash(node: NodeConfig, artifact_path: Path) -> str:
    flash = node.flash
    if flash is None:
        raise RuntimeError("Node does not define a flash backend")

    artifact_path = artifact_path.expanduser().resolve()

    if artifact_path.suffix.lower() not in (".elf", ".hex"):
        raise RuntimeError(f"Unsupported artifact type: {artifact_path} (need .elf or .hex)")

    cmd = ["STM32_Programmer_CLI"]
    port = flash.port

    if getattr(flash, "serial", None):
        cmd += ["-c", f"port={port} sn={flash.serial}"]
    else:
        cmd += ["-c", f"port={port}"]

    cmd += ["-w", str(artifact_path), "-v", "-rst"]

    started_at = time.strftime("%Y-%m-%d %H:%M:%S")
    p = subprocess.run(
        cmd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    output = p.stdout or ""

    log_text = "\n".join(
        [
            "BenchCI flash backend: STM32CubeProgrammer",
            f"Started at: {started_at}",
            f"CWD: {Path.cwd()}",
            f"Artifact: {artifact_path}",
            f"Command: {_render_command(cmd)}",
            f"Exit code: {p.returncode}",
            "",
            "Tool output:",
            output,
        ]
    )

    if p.returncode != 0:
        raise RuntimeError("Hardware tool command failed. See the saved run logs for details.")

    return log_text


def _cubeprog_reset_run(node: NodeConfig) -> str:
    flash = node.flash
    if flash is None:
        raise RuntimeError("Node does not define a flash backend")

    cmd = ["STM32_Programmer_CLI"]
    port = flash.port

    if getattr(flash, "serial", None):
        cmd += ["-c", f"port={port} sn={flash.serial}"]
    else:
        cmd += ["-c", f"port={port}"]

    cmd += ["-rst"]

    started_at = time.strftime("%Y-%m-%d %H:%M:%S")
    p = subprocess.run(
        cmd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    output = p.stdout or ""

    log_text = "\n".join(
        [
            "BenchCI reset backend: STM32CubeProgrammer",
            f"Started at: {started_at}",
            f"CWD: {Path.cwd()}",
            f"Command: {_render_command(cmd)}",
            f"Exit code: {p.returncode}",
            "",
            "Tool output:",
            output,
        ]
    )

    if p.returncode != 0:
        raise RuntimeError("Hardware tool command failed. See the saved run logs for details.")

    return log_text


def _jlink_cmd() -> str:
    if platform.system().lower() == "windows":
        return "JLink.exe"
    return "JLinkExe"


def _jlink_base_cmd(node: NodeConfig, script_path: Path) -> list[str]:
    flash = node.flash
    if flash is None:
        raise RuntimeError("Node does not define a flash backend")

    cmd = [
        _jlink_cmd(),
        "-device",
        flash.device,
        "-if",
        flash.interface,
        "-speed",
        str(flash.speed_khz),
        "-CommanderScript",
        str(script_path),
    ]

    serial = getattr(flash, "serial", None)
    if serial:
        cmd += ["-SelectEmuBySN", str(serial)]

    return cmd


def _jlink_run_script(node: NodeConfig, script_lines: list[str], log_title: str) -> str:
    started_at = time.strftime("%Y-%m-%d %H:%M:%S")

    with tempfile.NamedTemporaryFile("w", suffix=".jlink", delete=False, encoding="utf-8") as tf:
        script_path = Path(tf.name)
        tf.write("\n".join(script_lines) + "\n")

    try:
        cmd = _jlink_base_cmd(node, script_path)
        p = subprocess.run(
            cmd,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
        )
        output = p.stdout or ""

        log_text = "\n".join(
            [
                f"BenchCI backend: {log_title}",
                f"Started at: {started_at}",
                f"CWD: {Path.cwd()}",
                f"Script path: {script_path}",
                "Commander script:",
                "\n".join(script_lines),
                "",
                f"Command: {_render_command(cmd)}",
                f"Exit code: {p.returncode}",
                "",
                "Tool output:",
                output,
            ]
        )

        if p.returncode != 0:
            raise RuntimeError("Hardware tool command failed. See the saved run logs for details.")

        return log_text
    finally:
        try:
            script_path.unlink(missing_ok=True)
        except Exception:
            pass


def _jlink_flash(node: NodeConfig, artifact_path: Path) -> str:
    artifact_path = artifact_path.expanduser().resolve()

    if artifact_path.suffix.lower() not in (".elf", ".hex", ".bin"):
        raise RuntimeError(f"Unsupported artifact type: {artifact_path} (need .elf, .hex, or .bin)")

    if artifact_path.suffix.lower() == ".bin":
        raise RuntimeError(
            "J-Link .bin flashing is not yet supported in BenchCI because it requires an explicit load address."
        )

    script_lines = [
        "r",
        "h",
        f'loadfile "{artifact_path}"',
        "r",
        "g",
        "exit",
    ]
    return _jlink_run_script(node, script_lines, "J-Link flash")


def _jlink_reset_run(node: NodeConfig) -> str:
    script_lines = [
        "r",
        "g",
        "exit",
    ]
    return _jlink_run_script(node, script_lines, "J-Link reset")


def _esptool_flash(node: NodeConfig, artifact_path: Path) -> str:
    flash = node.flash
    if flash is None:
        raise RuntimeError("Node does not define a flash backend")

    artifact_path = artifact_path.expanduser().resolve()
    if artifact_path.suffix.lower() not in (".bin", ".elf", ".hex"):
        raise RuntimeError(
            f"Unsupported artifact type for esptool: {artifact_path} (need .bin, .elf, or .hex)"
        )

    cmd = [
        "esptool.py",
        "--port",
        flash.port,
        "--baud",
        str(flash.baud),
    ]

    if getattr(flash, "chip", None):
        cmd += ["--chip", flash.chip]

    cmd += list(getattr(flash, "extra_args", []) or [])
    cmd += ["write_flash", flash.offset, str(artifact_path)]

    started_at = time.strftime("%Y-%m-%d %H:%M:%S")
    p = subprocess.run(
        cmd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    output = p.stdout or ""

    log_text = "\n".join(
        [
            "BenchCI flash backend: esptool",
            f"Started at: {started_at}",
            f"CWD: {Path.cwd()}",
            f"Artifact: {artifact_path}",
            f"Command: {_render_command(cmd)}",
            f"Exit code: {p.returncode}",
            "",
            "Tool output:",
            output,
        ]
    )

    if p.returncode != 0:
        raise RuntimeError("Hardware tool command failed. See the saved run logs for details.")

    return log_text


def _esptool_reset_run(node: NodeConfig) -> str:
    return "\n".join(
        [
            "BenchCI reset backend: esptool",
            "esptool reset.method requested, but a dedicated reset command is not implemented.",
            "Skipping explicit reset step.",
        ]
    )


def _run_reset(
    node_name: str,
    node: NodeConfig,
    event_cb: Callable[[dict], None] | None = None,
) -> str:
    _emit_event(
        event_cb,
        "reset.started",
        f"Resetting node '{node_name}'",
        {"node_name": node_name, "reset_method": node.reset.method},
    )

    if node.reset.method == "openocd":
        _echo_info(f"Resetting node '{node_name}' via OpenOCD...")
        log_text = _openocd_reset_run(node)
        time.sleep(0.6)
        _echo_ok("Reset complete")
        _emit_event(
            event_cb,
            "reset.finished",
            "Reset complete",
            {"node_name": node_name, "reset_method": node.reset.method},
        )
        return log_text

    if node.reset.method == "cubeprog":
        _echo_info(f"Resetting node '{node_name}' via STM32CubeProgrammer...")
        log_text = _cubeprog_reset_run(node)
        time.sleep(0.6)
        _echo_ok("Reset complete")
        _emit_event(
            event_cb,
            "reset.finished",
            "Reset complete",
            {"node_name": node_name, "reset_method": node.reset.method},
        )
        return log_text

    if node.reset.method == "jlink":
        _echo_info(f"Resetting node '{node_name}' via Segger J-Link...")
        log_text = _jlink_reset_run(node)
        time.sleep(0.6)
        _echo_ok("Reset complete")
        _emit_event(
            event_cb,
            "reset.finished",
            "Reset complete",
            {"node_name": node_name, "reset_method": node.reset.method},
        )
        return log_text

    if node.reset.method == "esptool":
        _echo_info(f"Resetting node '{node_name}' via esptool...")
        log_text = _esptool_reset_run(node)
        time.sleep(0.2)
        _echo_ok("Reset step completed")
        _emit_event(
            event_cb,
            "reset.finished",
            "Reset step completed",
            {"node_name": node_name, "reset_method": node.reset.method},
        )
        return log_text

    _echo_info(
        f"Reset step requested for node '{node_name}', but reset.method is 'none'; skipping hardware reset"
    )
    time.sleep(0.2)
    _emit_event(
        event_cb,
        "reset.skipped",
        "Reset skipped because reset.method is 'none'",
        {"node_name": node_name, "reset_method": node.reset.method},
    )
    return "BenchCI reset backend: none\nReset skipped.\n"


def _run_flash(
    node_name: str,
    node: NodeConfig,
    artifact: Path,
    flash_log_path: Path,
    event_cb: Callable[[dict], None] | None = None,
) -> None:
    if node.flash is None:
        raise RuntimeError(f"Node '{node_name}' does not define a flash backend")

    flash_backend = getattr(node.flash, "backend", "openocd")

    _emit_event(
        event_cb,
        "flash.started",
        f"Flashing node '{node_name}'",
        {
            "node_name": node_name,
            "flash_backend": flash_backend,
            "artifact": str(artifact),
        },
    )

    _echo_section(f"FLASH: {node_name}")
    _echo_info(f"Backend: {flash_backend}")
    _echo_info(f"Artifact: {_artifact_label(artifact)}")

    try:
        started = time.time()

        if flash_backend == "openocd":
            log_text = _openocd_flash(node, artifact)
        elif flash_backend == "cubeprog":
            log_text = _cubeprog_flash(node, artifact)
        elif flash_backend == "jlink":
            log_text = _jlink_flash(node, artifact)
        elif flash_backend == "esptool":
            log_text = _esptool_flash(node, artifact)
        else:
            raise RuntimeError(f"Unsupported flash backend: {flash_backend}")

        _write_log(flash_log_path, log_text)
        elapsed = time.time() - started

        _echo_ok(f"Flash completed in {elapsed:.2f}s")
        _echo_info(f"Flash log saved to: {flash_log_path}")

        _emit_event(
            event_cb,
            "flash.finished",
            "Flash completed",
            {
                "node_name": node_name,
                "flash_backend": flash_backend,
                "artifact": str(artifact),
                "duration_s": round(elapsed, 3),
                "flash_log_path": str(flash_log_path),
            },
        )

        time.sleep(1.0)

    except Exception as e:
        raw_error = f"{type(e).__name__}: {e}"
        _write_log(
            flash_log_path,
            f"BenchCI flash failure\n\n{raw_error}\n",
        )
        failure = build_failure(
            message="Flash failed. See the flash log for hardware-tool details.",
            category="FLASH_FAILED",
            title="Flashing failed",
            step_type="flash",
            node_name=node_name,
            artifacts={"flash_log": str(flash_log_path.resolve())},
            details={
                "flash_backend": flash_backend,
                "artifact": str(artifact),
            },
            raw_error=raw_error,
        )
        _echo_structured_failure(failure)
        _echo_info(f"Flash log saved to: {flash_log_path}")
        _emit_event(
            event_cb,
            "flash.failed",
            failure_summary_text(failure),
            {
                "node_name": node_name,
                "flash_backend": flash_backend,
                "artifact": str(artifact),
                "flash_log_path": str(flash_log_path),
                "failure": failure,
            },
        )
        raise BenchCIFailure(failure)


def _node_default_artifact(node: NodeConfig) -> Path | None:
    if node.flash is None:
        return None
    artifact = getattr(node.flash, "artifact", None)
    if not artifact:
        return None
    return Path(artifact).expanduser().resolve()


def _resolve_flash_artifact(
    explicit_artifact_path: str | Path | None,
    node: NodeConfig,
    step_artifact_override: str | None = None,
) -> Path:
    if step_artifact_override:
        return Path(step_artifact_override).expanduser().resolve()

    if explicit_artifact_path is not None:
        return Path(explicit_artifact_path).expanduser().resolve()

    node_default = _node_default_artifact(node)
    if node_default is not None:
        return node_default

    raise RuntimeError(
        "Flash requested, but no artifact was provided via --artifact, step override, or node.flash.artifact"
    )


def _collect_required_power_resources(suite: SuiteConfig) -> set[str]:
    required: set[str] = set()
    for test in suite.tests:
        for step in test.steps:
            if hasattr(step, "power_set"):
                required.add(step.power_set.resource)
            elif hasattr(step, "power_cycle"):
                required.add(step.power_cycle.resource)
            elif hasattr(step, "power_expect"):
                required.add(step.power_expect.resource)
    return required


def _collect_required_measurement_resources(suite: SuiteConfig) -> set[str]:
    required: set[str] = set()
    for test in suite.tests:
        for step in test.steps:
            if hasattr(step, "measure"):
                required.add(step.measure.resource)
    return required


def _runtime_node_contexts(
    bench: BenchConfig,
    suite: SuiteConfig,
    out_dir: Path,
) -> dict[str, NodeRuntime]:
    required_nodes = _collect_required_nodes(bench, suite)
    required_transports = _collect_required_transports(bench, suite)

    runtimes: dict[str, NodeRuntime] = {}

    for node_name in sorted(required_nodes):
        node_cfg = _require_node(bench, node_name)
        node_dir = _node_artifact_dir(out_dir, node_name)
        node_dir.mkdir(parents=True, exist_ok=True)

        transport_log_paths = {
            transport_name: _transport_log_path(out_dir, node_name, transport_name)
            for transport_name in sorted(required_transports.get(node_name, set()))
        }

        runtimes[node_name] = NodeRuntime(
            node_name=node_name,
            node_cfg=node_cfg,
            node_dir=node_dir,
            flash_log_path=_flash_log_path(out_dir, node_name),
            gpio_log_path=_gpio_log_path(out_dir, node_name),
            transport_log_paths=transport_log_paths,
            transports={},
            gpio=None,
        )

    return runtimes


def _runtime_power_contexts(
    bench: BenchConfig,
    suite: SuiteConfig,
    out_dir: Path,
) -> dict[str, PowerRuntime]:
    runtimes: dict[str, PowerRuntime] = {}
    for resource_name in sorted(_collect_required_power_resources(suite)):
        runtimes[resource_name] = PowerRuntime(
            resource_name=resource_name,
            log_path=_power_log_path(out_dir, resource_name),
            manager=create_power_manager(bench, resource_name, log_path=_power_log_path(out_dir, resource_name)),
        )
    return runtimes


def _runtime_measurement_contexts(
    bench: BenchConfig,
    suite: SuiteConfig,
    out_dir: Path,
) -> dict[str, MeasurementRuntime]:
    runtimes: dict[str, MeasurementRuntime] = {}
    for resource_name in sorted(_collect_required_measurement_resources(suite)):
        log_path = _measurement_log_path(out_dir, resource_name)
        runtimes[resource_name] = MeasurementRuntime(
            resource_name=resource_name,
            log_path=log_path,
            manager=create_measurement_manager(bench, resource_name, log_path=log_path),
        )
    return runtimes


def _start_runtime_contexts(
    bench: BenchConfig,
    suite: SuiteConfig,
    runtimes: dict[str, NodeRuntime],
    power_runtimes: dict[str, PowerRuntime],
    measurement_runtimes: dict[str, MeasurementRuntime] | None = None,
    event_cb: Callable[[dict], None] | None = None,
) -> None:
    required_transports = _collect_required_transports(bench, suite)

    for node_name, runtime in runtimes.items():
        node_cfg = runtime.node_cfg

        needed_transport_names = sorted(required_transports.get(node_name, set()))
        for transport_name in needed_transport_names:
            log_path = runtime.transport_log_paths[transport_name]
            transport_cfg = get_transport_config(bench, node_name, transport_name)

            _echo_section(f"TRANSPORT: {node_name}.{transport_name}")
            print_transport_config_summary(node_name, transport_name, transport_cfg)

            _emit_event(
                event_cb,
                "transport.starting",
                f"Starting transport '{transport_name}' for node '{node_name}'",
                {
                    "node_name": node_name,
                    "transport_name": transport_name,
                    "transport_backend": transport_cfg.backend,
                    "log_path": str(log_path),
                },
            )

            transport = create_transport(
                bench=bench,
                node_name=node_name,
                transport_name=transport_name,
                log_path=log_path,
            )
            transport.start()
            runtime.transports[transport_name] = transport

            _echo_ok("Transport opened successfully")
            _echo_info(f"Transport log path: {log_path}")

            _emit_event(
                event_cb,
                "transport.started",
                "Transport opened successfully",
                {
                    "node_name": node_name,
                    "transport_name": transport_name,
                    "transport_backend": transport_cfg.backend,
                    "log_path": str(log_path),
                },
            )

        if node_cfg.gpio:
            runtime.gpio = create_gpio_manager(
                bench=bench,
                node_name=node_name,
                log_path=runtime.gpio_log_path,
            )
            if runtime.gpio is not None:
                _echo_section(f"GPIO: {node_name}")
                _emit_event(
                    event_cb,
                    "gpio.starting",
                    f"Starting GPIO for node '{node_name}'",
                    {
                        "node_name": node_name,
                        "gpio_log_path": str(runtime.gpio_log_path),
                    },
                )
                runtime.gpio.start()
                _echo_ok("GPIO manager initialized")
                _echo_info(f"GPIO log path: {runtime.gpio_log_path}")
                _emit_event(
                    event_cb,
                    "gpio.started",
                    "GPIO manager initialized",
                    {
                        "node_name": node_name,
                        "gpio_log_path": str(runtime.gpio_log_path),
                    },
                )

    for resource_name, runtime in power_runtimes.items():
        _echo_section(f"POWER: {resource_name}")
        runtime.manager.start()
        _echo_ok("Power controller initialized")
        _echo_info(f"Power log path: {runtime.log_path}")
        _emit_event(
            event_cb,
            "power.started",
            "Power controller initialized",
            {
                "resource_name": resource_name,
                "power_log_path": str(runtime.log_path),
            },
        )

    for resource_name, runtime in (measurement_runtimes or {}).items():
        _echo_section(f"MEASUREMENT: {resource_name}")
        runtime.manager.start()
        _echo_ok("Measurement controller initialized")
        _echo_info(f"Measurement log path: {runtime.log_path}")
        _emit_event(
            event_cb,
            "measurement.started",
            "Measurement controller initialized",
            {
                "resource_name": resource_name,
                "measurement_log_path": str(runtime.log_path),
            },
        )


def _stop_runtime_contexts(
    runtimes: dict[str, NodeRuntime],
    power_runtimes: dict[str, PowerRuntime],
    measurement_runtimes: dict[str, MeasurementRuntime] | None = None,
    event_cb: Callable[[dict], None] | None = None,
) -> None:
    for runtime in runtimes.values():
        for transport_name, transport in runtime.transports.items():
            try:
                transport.stop()
                _emit_event(
                    event_cb,
                    "transport.stopped",
                    "Transport stopped",
                    {
                        "node_name": runtime.node_name,
                        "transport_name": transport_name,
                    },
                )
            except Exception:
                pass

        if runtime.gpio is not None:
            try:
                runtime.gpio.stop()
                _emit_event(
                    event_cb,
                    "gpio.stopped",
                    "GPIO manager stopped",
                    {
                        "node_name": runtime.node_name,
                    },
                )
            except Exception:
                pass

    for runtime in power_runtimes.values():
        try:
            runtime.manager.stop()
            _emit_event(
                event_cb,
                "power.stopped",
                "Power controller stopped",
                {"resource_name": runtime.resource_name},
            )
        except Exception:
            pass

    for runtime in (measurement_runtimes or {}).values():
        try:
            runtime.manager.stop()
            _emit_event(
                event_cb,
                "measurement.stopped",
                "Measurement controller stopped",
                {"resource_name": runtime.resource_name},
            )
        except Exception:
            pass


def _require_transport_runtime(
    runtimes: dict[str, NodeRuntime],
    node_name: str,
    transport_name: str,
):
    runtime = runtimes.get(node_name)
    if runtime is None:
        raise RuntimeError(f"No runtime context found for node '{node_name}'")

    transport = runtime.transports.get(transport_name)
    if transport is None:
        known = ", ".join(sorted(runtime.transports.keys())) or "<none>"
        raise RuntimeError(
            f"Transport '{transport_name}' is not active for node '{node_name}'. "
            f"Known active transports: {known}"
        )
    return transport


def _require_gpio_runtime(
    runtimes: dict[str, NodeRuntime],
    node_name: str,
) -> GpioManager:
    runtime = runtimes.get(node_name)
    if runtime is None:
        raise RuntimeError(f"No runtime context found for node '{node_name}'")

    if runtime.gpio is None:
        raise RuntimeError(f"Node '{node_name}' does not have an active GPIO manager")

    return runtime.gpio


def _require_power_runtime(
    runtimes: dict[str, PowerRuntime],
    resource_name: str,
) -> PowerRuntime:
    runtime = runtimes.get(resource_name)
    if runtime is None:
        known = ", ".join(sorted(runtimes.keys())) or "<none>"
        raise RuntimeError(
            f"Power resource '{resource_name}' is not active. Known active power resources: {known}"
        )
    return runtime


def _require_measurement_runtime(
    runtimes: dict[str, MeasurementRuntime],
    resource_name: str,
) -> MeasurementRuntime:
    runtime = runtimes.get(resource_name)
    if runtime is None:
        known = ", ".join(sorted(runtimes.keys())) or "<none>"
        raise RuntimeError(
            f"Measurement resource '{resource_name}' is not active. Known active measurement resources: {known}"
        )
    return runtime


def _assert_numeric_value(value: float, rule: Any) -> None:
    if getattr(rule, "expect_less_than", None) is not None and not (value < float(rule.expect_less_than)):
        raise RuntimeError(f"Expected value < {rule.expect_less_than}, observed {value}")
    if getattr(rule, "expect_less_than_or_equal", None) is not None and not (value <= float(rule.expect_less_than_or_equal)):
        raise RuntimeError(f"Expected value <= {rule.expect_less_than_or_equal}, observed {value}")
    if getattr(rule, "expect_greater_than", None) is not None and not (value > float(rule.expect_greater_than)):
        raise RuntimeError(f"Expected value > {rule.expect_greater_than}, observed {value}")
    if getattr(rule, "expect_greater_than_or_equal", None) is not None and not (value >= float(rule.expect_greater_than_or_equal)):
        raise RuntimeError(f"Expected value >= {rule.expect_greater_than_or_equal}, observed {value}")
    if getattr(rule, "expect_equal", None) is not None:
        target = float(rule.expect_equal)
        tolerance = float(getattr(rule, "tolerance", 0.0) or 0.0)
        if abs(value - target) > tolerance:
            raise RuntimeError(f"Expected value == {target} ± {tolerance}, observed {value}")


def run_local(
    bench_path: str | Path,
    suite_path: str | Path,
    artifact_path: str | Path | None,
    skip_flash: bool = False,
    out_dir: str | Path | None = None,
    event_cb: Callable[[dict], None] | None = None,
    verbose: bool = False,
) -> int:
    """Run a suite on a bench locally (on the machine connected to the hardware)."""
    bench = load_bench_config(bench_path)
    suite = load_suite_config(suite_path)
    cli_artifact = Path(artifact_path).expanduser().resolve() if artifact_path else None

    out = Path(out_dir) if out_dir else (Path("benchci-results") / time.strftime("%Y%m%d-%H%M%S"))
    out.mkdir(parents=True, exist_ok=True)

    results_json_path = out / "results.json"
    evidence_json_path = out / "evidence.json"
    metadata_json_path = out / "metadata.json"
    suite_started = time.time()
    suite_started_at = _utc_now()
    passed_tests = 0
    failed_tests = 0

    _cross_validate_suite_against_bench(bench, suite)

    runtimes = _runtime_node_contexts(bench, suite, out)
    power_runtimes = _runtime_power_contexts(bench, suite, out)
    measurement_runtimes = _runtime_measurement_contexts(bench, suite, out)

    input_snapshots = copy_input_snapshots(
        out_dir=out,
        bench_path=bench_path,
        suite_path=suite_path,
    )
    evidence_payload = build_evidence_report(
        bench_path=bench_path,
        suite_path=suite_path,
        artifact_path=cli_artifact,
        out_dir=out,
        bench_name=_safe_bench_name(bench),
        suite_name=_safe_suite_name(suite),
        run_mode="local",
        status="running",
        started_at=suite_started_at,
        summary={"total": len(suite.tests), "passed": 0, "failed": 0},
        snapshots=input_snapshots,
        suite_cfg=suite,
    )

    results_payload: dict[str, Any] = {
        "tool": "benchci",
        "command": "run_local",
        "bench": _safe_bench_name(bench),
        "suite": _safe_suite_name(suite),
        "status": "running",
        "skip_flash": skip_flash,
        "verbose": verbose,
        "artifact": str(cli_artifact) if cli_artifact is not None else None,
        "results_dir": str(out.resolve()),
        "started_at": suite_started_at,
        "finished_at": None,
        "duration_s": None,
        "summary": {
            "total": len(suite.tests),
            "passed": 0,
            "failed": 0,
        },
        "artifacts": {
            "results_json": str(results_json_path.resolve()),
            "evidence_json": str(evidence_json_path.resolve()),
            "metadata_json": str(metadata_json_path.resolve()),
            "evidence_html": str((out / "evidence.html").resolve()),
            "manifest_json": str((out / "manifest.json").resolve()),
        },
        "evidence": evidence_payload,
        "failure": None,
        "nodes": {},
        "resources": {},
        "measurements": [],
        "metrics": {},
        "tests": [],
    }
    write_evidence_files(out, evidence_payload)

    for node_name, runtime in runtimes.items():
        results_payload["nodes"][node_name] = {
            "flash_log": str(runtime.flash_log_path.resolve()) if runtime.node_cfg.flash else None,
            "gpio_log": str(runtime.gpio_log_path.resolve()) if runtime.node_cfg.gpio else None,
            "transport_logs": {
                name: str(path.resolve())
                for name, path in runtime.transport_log_paths.items()
            },
        }

    if power_runtimes or measurement_runtimes:
        resources: dict[str, Any] = {}
        for resource_name, runtime in power_runtimes.items():
            resources.setdefault(resource_name, {})["power_log"] = str(runtime.log_path.resolve())
        for resource_name, runtime in measurement_runtimes.items():
            resources.setdefault(resource_name, {})["measurement_log"] = str(runtime.log_path.resolve())
        results_payload["resources"] = resources

    try:
        _emit_event(
            event_cb,
            "run.started",
            f"Run started for bench '{_safe_bench_name(bench)}'",
            {
                "bench_name": _safe_bench_name(bench),
                "suite_name": _safe_suite_name(suite),
                "results_dir": str(out.resolve()),
                "tests_total": len(suite.tests),
                "skip_flash": skip_flash,
                "verbose": verbose,
                "artifact": str(cli_artifact) if cli_artifact is not None else None,
            },
        )

        _echo_section("BENCHCI RUN")
        _echo_info(f"Bench: {_safe_bench_name(bench)}")
        _echo_info(f"Suite: {_safe_suite_name(suite)}")
        _echo_info(f"Results directory: {out}")
        _echo_info(f"Tests in suite: {len(suite.tests)}")
        if cli_artifact is not None:
            _echo_info(f"CLI artifact override: {_artifact_label(cli_artifact)}")
        else:
            _echo_info("CLI artifact override: <none>")
        _echo_info(f"Verbose logging: {'enabled' if verbose else 'disabled'}")

        _echo_section("BENCH TRANSPORTS")
        print_bench_transport_summary(bench)

        _start_runtime_contexts(bench, suite, runtimes, power_runtimes, measurement_runtimes, event_cb=event_cb)

        if skip_flash:
            _echo_warn("Skipping flash steps because --skip-flash is enabled")
            _emit_event(
                event_cb,
                "run.skip_flash_enabled",
                "--skip-flash is enabled",
                {},
            )

        _echo_section(f"SUITE: {_safe_suite_name(suite)}")

        for index, test in enumerate(suite.tests, start=1):
            typer.echo("")
            typer.echo("-" * 72)
            typer.echo(f"Test {index}/{len(suite.tests)}: {test.name}")
            typer.echo("-" * 72)

            test_pass = True
            test_started = time.time()
            test_failure_reason: str | None = None
            test_failure_detail: dict[str, Any] | None = None
            test_metrics: dict[str, Any] = {}
            test_measurements: list[dict[str, Any]] = []

            _emit_event(
                event_cb,
                "test.started",
                f"Test '{test.name}' started",
                {
                    "test_name": test.name,
                    "test_index": index,
                    "tests_total": len(suite.tests),
                },
            )

            for step_idx, step in enumerate(test.steps, start=1):
                step_name = _step_type(step)
                step_node_name = _step_node(bench, step)

                _emit_event(
                    event_cb,
                    "step.started",
                    f"Step {step_idx} started: {step_name}",
                    {
                        "test_name": test.name,
                        "test_index": index,
                        "tests_total": len(suite.tests),
                        "step_index": step_idx,
                        "steps_total": len(test.steps),
                        "step_type": step_name,
                        "node_name": step_node_name,
                    },
                )

                step_started = time.time()

                if verbose:
                    _echo_info(
                        f"Starting step {step_idx}/{len(test.steps)}: {step_name}"
                        + (f" on node '{step_node_name}'" if step_node_name else "")
                    )

                if hasattr(step, "sleep_ms"):
                    ms = step.sleep_ms
                    _echo_info(f"Step {step_idx}: sleep for {ms} ms")
                    time.sleep(ms / 1000.0)
                    _emit_event(
                        event_cb,
                        "step.finished",
                        "Sleep completed",
                        {
                            "test_name": test.name,
                            "step_index": step_idx,
                            "step_type": "sleep_ms",
                            "duration_ms": ms,
                        },
                    )
                    if verbose:
                        _echo_detail("step_duration_s", f"{time.time() - step_started:.3f}")

                elif hasattr(step, "flash"):
                    rule = step.flash
                    node_name = _resolve_node_name(bench, rule.node)
                    runtime = runtimes[node_name]
                    artifact = _resolve_flash_artifact(
                        explicit_artifact_path=cli_artifact,
                        node=runtime.node_cfg,
                        step_artifact_override=rule.artifact,
                    )

                    if skip_flash:
                        _echo_warn(
                            f"Step {step_idx}: flash requested for node '{node_name}' but skipped due to --skip-flash"
                        )
                        _emit_event(
                            event_cb,
                            "step.skipped",
                            "Flash skipped due to --skip-flash",
                            {
                                "test_name": test.name,
                                "step_index": step_idx,
                                "step_type": "flash",
                                "node_name": node_name,
                                "artifact": str(artifact),
                            },
                        )
                        if verbose:
                            _echo_detail("artifact", artifact)
                            _echo_detail("flash_log_path", runtime.flash_log_path)
                            _echo_detail("step_duration_s", f"{time.time() - step_started:.3f}")
                    else:
                        try:
                            _run_flash(
                                node_name=node_name,
                                node=runtime.node_cfg,
                                artifact=artifact,
                                flash_log_path=runtime.flash_log_path,
                                event_cb=event_cb,
                            )
                        except BenchCIFailure as exc:
                            exc.failure.setdefault("failed_step", {})
                            exc.failure["failed_step"].update(
                                {
                                    "test_name": test.name,
                                    "test_index": index,
                                    "step_index": step_idx,
                                    "steps_total": len(test.steps),
                                    "step_type": "flash",
                                    "node_name": node_name,
                                }
                            )
                            raise
                        _emit_event(
                            event_cb,
                            "step.finished",
                            "Flash step completed",
                            {
                                "test_name": test.name,
                                "step_index": step_idx,
                                "step_type": "flash",
                                "node_name": node_name,
                                "artifact": str(artifact),
                            },
                        )
                        if verbose:
                            _echo_detail("artifact", artifact)
                            _echo_detail("flash_log_path", runtime.flash_log_path)
                            _echo_detail("step_duration_s", f"{time.time() - step_started:.3f}")

                elif hasattr(step, "reset"):
                    rule = step.reset
                    node_name = _resolve_node_name(bench, rule.node)
                    runtime = runtimes[node_name]
                    _echo_info(f"Step {step_idx}: reset node '{node_name}'")
                    reset_log = _run_reset(node_name, runtime.node_cfg, event_cb=event_cb)

                    existing = ""
                    if runtime.flash_log_path.exists():
                        existing = runtime.flash_log_path.read_text(encoding="utf-8")
                        if existing and not existing.endswith("\n"):
                            existing += "\n"
                    _write_log(runtime.flash_log_path, existing + "\n" + reset_log + "\n")

                    _emit_event(
                        event_cb,
                        "step.finished",
                        "Reset step completed",
                        {
                            "test_name": test.name,
                            "step_index": step_idx,
                            "step_type": "reset",
                            "node_name": node_name,
                        },
                    )
                    if verbose:
                        _echo_detail("flash_log_path", runtime.flash_log_path)
                        _echo_detail("step_duration_s", f"{time.time() - step_started:.3f}")

                elif hasattr(step, "send_uart"):
                    rule = step.send_uart
                    node_name = _resolve_node_name(bench, rule.node)
                    transport = _require_transport_runtime(runtimes, node_name, rule.transport)
                    _echo_info(
                        f"Step {step_idx}: send UART text to {node_name}.{rule.transport}: {rule.data!r}"
                    )
                    transport.send_text(rule.data)
                    _echo_ok("Text sent")
                    _emit_event(
                        event_cb,
                        "step.finished",
                        "UART text sent",
                        {
                            "test_name": test.name,
                            "step_index": step_idx,
                            "step_type": "send_uart",
                            "node_name": node_name,
                            "transport_name": rule.transport,
                            "data": rule.data,
                        },
                    )
                    if verbose:
                        _echo_detail("transport_log_path", runtimes[node_name].transport_log_paths.get(rule.transport))
                        _echo_detail("step_duration_s", f"{time.time() - step_started:.3f}")

                elif hasattr(step, "expect_uart"):
                    rule = step.expect_uart
                    node_name = _resolve_node_name(bench, rule.node)
                    transport = _require_transport_runtime(runtimes, node_name, rule.transport)
                    within_ms = _resolve_timeout(bench, rule.within_ms)

                    if rule.contains is not None:
                        _echo_info(
                            f"Step {step_idx}: expect text on {node_name}.{rule.transport} "
                            f"containing {rule.contains!r} within {within_ms} ms"
                        )
                        ok, _ = transport.expect_contains(rule.contains, within_ms)
                    else:
                        _echo_info(
                            f"Step {step_idx}: expect regex on {node_name}.{rule.transport} "
                            f"{rule.regex!r} within {within_ms} ms"
                        )
                        ok, _ = transport.expect_regex(rule.regex or "", within_ms)

                    if not ok:
                        _echo_fail("Expectation not met")
                        tail = transport.tail(800).replace("\r", "\\r") if hasattr(transport, "tail") else ""
                        transport_log_path = runtimes[node_name].transport_log_paths.get(rule.transport)
                        if tail:
                            typer.echo(f"       Recent transport tail: {tail!r}")
                            test_failure_reason = (
                                f"Expectation not met on {node_name}.{rule.transport}. "
                                f"Recent transport tail: {tail!r}"
                            )
                        else:
                            test_failure_reason = (
                                f"Expectation not met on {node_name}.{rule.transport}."
                            )

                        _echo_failure_context(
                            "Failure context",
                            {
                                "node": node_name,
                                "transport": rule.transport,
                                "within_ms": within_ms,
                                "expect_contains": rule.contains,
                                "expect_regex": rule.regex,
                                "transport_log_path": transport_log_path,
                            },
                        )

                        _emit_event(
                            event_cb,
                            "step.failed",
                            test_failure_reason,
                            {
                                "test_name": test.name,
                                "step_index": step_idx,
                                "step_type": "expect_uart",
                                "node_name": node_name,
                                "transport_name": rule.transport,
                                "within_ms": within_ms,
                            },
                        )
                        test_pass = False
                        break

                    _echo_ok("Expectation satisfied")
                    if verbose:
                        _echo_detail("transport_log_path", runtimes[node_name].transport_log_paths.get(rule.transport))
                        _echo_detail("within_ms", within_ms)
                        _echo_detail("step_duration_s", f"{time.time() - step_started:.3f}")
                    _emit_event(
                        event_cb,
                        "step.finished",
                        "UART expectation satisfied",
                        {
                            "test_name": test.name,
                            "step_index": step_idx,
                            "step_type": "expect_uart",
                            "node_name": node_name,
                            "transport_name": rule.transport,
                            "within_ms": within_ms,
                        },
                    )

                elif hasattr(step, "modbus_read_holding_registers"):
                    rule = step.modbus_read_holding_registers
                    node_name = _resolve_node_name(bench, rule.node)
                    transport = _require_transport_runtime(runtimes, node_name, rule.transport)

                    _echo_info(
                        f"Step {step_idx}: read holding registers on {node_name}.{rule.transport} "
                        f"(slave={rule.slave}, address={rule.address}, count={rule.count})"
                    )
                    values = transport.read_holding_registers(
                        address=rule.address,
                        count=rule.count,
                        slave=rule.slave,
                    )
                    if values != rule.expect:
                        message = (
                            f"Holding register mismatch on {node_name}.{rule.transport}: "
                            f"expected {rule.expect}, got {values}"
                        )
                        _echo_fail(message)
                        _echo_failure_context(
                            "Failure context",
                            {
                                "node": node_name,
                                "transport": rule.transport,
                                "slave": rule.slave,
                                "address": rule.address,
                                "count": rule.count,
                                "transport_log_path": runtimes[node_name].transport_log_paths.get(rule.transport),
                            },
                        )
                        test_failure_reason = message
                        _emit_event(
                            event_cb,
                            "step.failed",
                            message,
                            {
                                "test_name": test.name,
                                "step_index": step_idx,
                                "step_type": "modbus_read_holding_registers",
                                "node_name": node_name,
                                "transport_name": rule.transport,
                            },
                        )
                        test_pass = False
                        break

                    _echo_ok(f"Holding registers matched: {values}")
                    if verbose:
                        _echo_detail("transport_log_path", runtimes[node_name].transport_log_paths.get(rule.transport))
                        _echo_detail("step_duration_s", f"{time.time() - step_started:.3f}")
                    _emit_event(
                        event_cb,
                        "step.finished",
                        "Holding registers matched",
                        {
                            "test_name": test.name,
                            "step_index": step_idx,
                            "step_type": "modbus_read_holding_registers",
                            "node_name": node_name,
                            "transport_name": rule.transport,
                            "values": values,
                        },
                    )

                elif hasattr(step, "modbus_write_single_register"):
                    rule = step.modbus_write_single_register
                    node_name = _resolve_node_name(bench, rule.node)
                    transport = _require_transport_runtime(runtimes, node_name, rule.transport)

                    _echo_info(
                        f"Step {step_idx}: write single register on {node_name}.{rule.transport} "
                        f"(slave={rule.slave}, address={rule.address}, value={rule.value})"
                    )
                    transport.write_single_register(
                        address=rule.address,
                        value=rule.value,
                        slave=rule.slave,
                    )
                    _echo_ok("Register written")
                    if verbose:
                        _echo_detail("transport_log_path", runtimes[node_name].transport_log_paths.get(rule.transport))
                        _echo_detail("step_duration_s", f"{time.time() - step_started:.3f}")
                    _emit_event(
                        event_cb,
                        "step.finished",
                        "Single register written",
                        {
                            "test_name": test.name,
                            "step_index": step_idx,
                            "step_type": "modbus_write_single_register",
                            "node_name": node_name,
                            "transport_name": rule.transport,
                            "address": rule.address,
                            "value": rule.value,
                        },
                    )

                elif hasattr(step, "modbus_read_coils"):
                    rule = step.modbus_read_coils
                    node_name = _resolve_node_name(bench, rule.node)
                    transport = _require_transport_runtime(runtimes, node_name, rule.transport)

                    _echo_info(
                        f"Step {step_idx}: read coils on {node_name}.{rule.transport} "
                        f"(slave={rule.slave}, address={rule.address}, count={rule.count})"
                    )
                    values = transport.read_coils(
                        address=rule.address,
                        count=rule.count,
                        slave=rule.slave,
                    )
                    if values != rule.expect:
                        message = (
                            f"Coil mismatch on {node_name}.{rule.transport}: "
                            f"expected {rule.expect}, got {values}"
                        )
                        _echo_fail(message)
                        _echo_failure_context(
                            "Failure context",
                            {
                                "node": node_name,
                                "transport": rule.transport,
                                "slave": rule.slave,
                                "address": rule.address,
                                "count": rule.count,
                                "transport_log_path": runtimes[node_name].transport_log_paths.get(rule.transport),
                            },
                        )
                        test_failure_reason = message
                        _emit_event(
                            event_cb,
                            "step.failed",
                            message,
                            {
                                "test_name": test.name,
                                "step_index": step_idx,
                                "step_type": "modbus_read_coils",
                                "node_name": node_name,
                                "transport_name": rule.transport,
                            },
                        )
                        test_pass = False
                        break

                    _echo_ok(f"Coils matched: {values}")
                    if verbose:
                        _echo_detail("transport_log_path", runtimes[node_name].transport_log_paths.get(rule.transport))
                        _echo_detail("step_duration_s", f"{time.time() - step_started:.3f}")
                    _emit_event(
                        event_cb,
                        "step.finished",
                        "Coils matched",
                        {
                            "test_name": test.name,
                            "step_index": step_idx,
                            "step_type": "modbus_read_coils",
                            "node_name": node_name,
                            "transport_name": rule.transport,
                            "values": values,
                        },
                    )

                elif hasattr(step, "modbus_write_single_coil"):
                    rule = step.modbus_write_single_coil
                    node_name = _resolve_node_name(bench, rule.node)
                    transport = _require_transport_runtime(runtimes, node_name, rule.transport)

                    _echo_info(
                        f"Step {step_idx}: write single coil on {node_name}.{rule.transport} "
                        f"(slave={rule.slave}, address={rule.address}, value={rule.value})"
                    )
                    transport.write_single_coil(
                        address=rule.address,
                        value=rule.value,
                        slave=rule.slave,
                    )
                    _echo_ok("Coil written")
                    if verbose:
                        _echo_detail("transport_log_path", runtimes[node_name].transport_log_paths.get(rule.transport))
                        _echo_detail("step_duration_s", f"{time.time() - step_started:.3f}")
                    _emit_event(
                        event_cb,
                        "step.finished",
                        "Single coil written",
                        {
                            "test_name": test.name,
                            "step_index": step_idx,
                            "step_type": "modbus_write_single_coil",
                            "node_name": node_name,
                            "transport_name": rule.transport,
                            "address": rule.address,
                            "value": rule.value,
                        },
                    )

                elif hasattr(step, "gpio_set"):
                    rule = step.gpio_set
                    node_name = _resolve_node_name(bench, rule.node)
                    gpio = _require_gpio_runtime(runtimes, node_name)

                    _echo_info(
                        f"Step {step_idx}: set GPIO {node_name}.{rule.line} to logical value {rule.value}"
                    )
                    gpio.set_logical_value(rule.line, rule.value)
                    _echo_ok("GPIO set")
                    if verbose:
                        _echo_detail("gpio_log_path", runtimes[node_name].gpio_log_path)
                        _echo_detail("step_duration_s", f"{time.time() - step_started:.3f}")
                    _emit_event(
                        event_cb,
                        "step.finished",
                        "GPIO set completed",
                        {
                            "test_name": test.name,
                            "step_index": step_idx,
                            "step_type": "gpio_set",
                            "node_name": node_name,
                            "line": rule.line,
                            "value": rule.value,
                        },
                    )

                elif hasattr(step, "gpio_get"):
                    rule = step.gpio_get
                    node_name = _resolve_node_name(bench, rule.node)
                    gpio = _require_gpio_runtime(runtimes, node_name)

                    _echo_info(f"Step {step_idx}: read GPIO {node_name}.{rule.line}")
                    value = gpio.get_logical_value(rule.line)
                    _echo_info(f"Observed logical GPIO value: {value}")

                    if rule.expect is not None and value != rule.expect:
                        message = (
                            f"GPIO value mismatch on {node_name}.{rule.line}: "
                            f"expected {rule.expect}, got {value}"
                        )
                        _echo_fail(message)
                        _echo_failure_context(
                            "Failure context",
                            {
                                "node": node_name,
                                "line": rule.line,
                                "observed": value,
                                "expected": rule.expect,
                                "gpio_log_path": runtimes[node_name].gpio_log_path,
                            },
                        )
                        test_failure_reason = message
                        _emit_event(
                            event_cb,
                            "step.failed",
                            message,
                            {
                                "test_name": test.name,
                                "step_index": step_idx,
                                "step_type": "gpio_get",
                                "node_name": node_name,
                                "line": rule.line,
                                "observed": value,
                                "expected": rule.expect,
                            },
                        )
                        test_pass = False
                        break

                    _echo_ok("GPIO read matched expectation" if rule.expect is not None else "GPIO read complete")
                    if verbose:
                        _echo_detail("gpio_log_path", runtimes[node_name].gpio_log_path)
                        _echo_detail("step_duration_s", f"{time.time() - step_started:.3f}")
                    _emit_event(
                        event_cb,
                        "step.finished",
                        "GPIO read completed",
                        {
                            "test_name": test.name,
                            "step_index": step_idx,
                            "step_type": "gpio_get",
                            "node_name": node_name,
                            "line": rule.line,
                            "observed": value,
                            "expected": rule.expect,
                        },
                    )

                elif hasattr(step, "gpio_expect"):
                    rule = step.gpio_expect
                    node_name = _resolve_node_name(bench, rule.node)
                    gpio = _require_gpio_runtime(runtimes, node_name)
                    within_ms = _resolve_timeout(bench, rule.within_ms)

                    _echo_info(
                        f"Step {step_idx}: expect GPIO {node_name}.{rule.line} to become "
                        f"{rule.value} within {within_ms} ms"
                    )
                    ok = gpio.wait_for_logical_value(rule.line, rule.value, within_ms)
                    if not ok:
                        message = (
                            f"GPIO expectation timed out on {node_name}.{rule.line}: "
                            f"expected {rule.value} within {within_ms} ms"
                        )
                        _echo_fail(message)
                        _echo_failure_context(
                            "Failure context",
                            {
                                "node": node_name,
                                "line": rule.line,
                                "expected": rule.value,
                                "within_ms": within_ms,
                                "gpio_log_path": runtimes[node_name].gpio_log_path,
                            },
                        )
                        test_failure_reason = message
                        _emit_event(
                            event_cb,
                            "step.failed",
                            message,
                            {
                                "test_name": test.name,
                                "step_index": step_idx,
                                "step_type": "gpio_expect",
                                "node_name": node_name,
                                "line": rule.line,
                                "within_ms": within_ms,
                            },
                        )
                        test_pass = False
                        break

                    _echo_ok("GPIO expectation satisfied")
                    if verbose:
                        _echo_detail("gpio_log_path", runtimes[node_name].gpio_log_path)
                        _echo_detail("within_ms", within_ms)
                        _echo_detail("step_duration_s", f"{time.time() - step_started:.3f}")
                    _emit_event(
                        event_cb,
                        "step.finished",
                        "GPIO expectation satisfied",
                        {
                            "test_name": test.name,
                            "step_index": step_idx,
                            "step_type": "gpio_expect",
                            "node_name": node_name,
                            "line": rule.line,
                            "within_ms": within_ms,
                        },
                    )

                elif hasattr(step, "gpio_wait_edge"):
                    rule = step.gpio_wait_edge
                    node_name = _resolve_node_name(bench, rule.node)
                    gpio = _require_gpio_runtime(runtimes, node_name)
                    within_ms = _resolve_timeout(bench, rule.within_ms)

                    _echo_info(
                        f"Step {step_idx}: wait for GPIO edge on {node_name}.{rule.line} "
                        f"(edge={rule.edge}, within_ms={within_ms})"
                    )
                    ok = gpio.wait_for_logical_edge(rule.line, rule.edge, within_ms)
                    if not ok:
                        message = (
                            f"GPIO edge wait timed out on {node_name}.{rule.line}: "
                            f"edge={rule.edge} within {within_ms} ms"
                        )
                        _echo_fail(message)
                        _echo_failure_context(
                            "Failure context",
                            {
                                "node": node_name,
                                "line": rule.line,
                                "edge": rule.edge,
                                "within_ms": within_ms,
                                "gpio_log_path": runtimes[node_name].gpio_log_path,
                            },
                        )
                        test_failure_reason = message
                        _emit_event(
                            event_cb,
                            "step.failed",
                            message,
                            {
                                "test_name": test.name,
                                "step_index": step_idx,
                                "step_type": "gpio_wait_edge",
                                "node_name": node_name,
                                "line": rule.line,
                                "edge": rule.edge,
                                "within_ms": within_ms,
                            },
                        )
                        test_pass = False
                        break

                    _echo_ok("GPIO edge observed")
                    if verbose:
                        _echo_detail("gpio_log_path", runtimes[node_name].gpio_log_path)
                        _echo_detail("within_ms", within_ms)
                        _echo_detail("step_duration_s", f"{time.time() - step_started:.3f}")
                    _emit_event(
                        event_cb,
                        "step.finished",
                        "GPIO edge observed",
                        {
                            "test_name": test.name,
                            "step_index": step_idx,
                            "step_type": "gpio_wait_edge",
                            "node_name": node_name,
                            "line": rule.line,
                            "edge": rule.edge,
                            "within_ms": within_ms,
                        },
                    )

                elif hasattr(step, "power_set"):
                    rule = step.power_set
                    runtime = _require_power_runtime(power_runtimes, rule.resource)

                    _echo_info(
                        f"Step {step_idx}: set power {rule.resource}.{rule.outlet} to {rule.state}"
                    )
                    runtime.manager.set_state(rule.outlet, rule.state)
                    observed = runtime.manager.get_state(rule.outlet)
                    _echo_ok("Power state updated")
                    if verbose:
                        _echo_detail("power_log_path", runtime.log_path)
                        _echo_detail("observed_state", observed)
                        _echo_detail("step_duration_s", f"{time.time() - step_started:.3f}")
                    _emit_event(
                        event_cb,
                        "step.finished",
                        "Power state updated",
                        {
                            "test_name": test.name,
                            "step_index": step_idx,
                            "step_type": "power_set",
                            "resource_name": rule.resource,
                            "outlet": rule.outlet,
                            "state": rule.state,
                            "observed_state": observed,
                        },
                    )

                elif hasattr(step, "power_cycle"):
                    rule = step.power_cycle
                    runtime = _require_power_runtime(power_runtimes, rule.resource)

                    _echo_info(
                        f"Step {step_idx}: power-cycle {rule.resource}.{rule.outlet} off_ms={rule.off_ms} on_settle_ms={rule.on_settle_ms}"
                    )
                    runtime.manager.cycle(rule.outlet, rule.off_ms, rule.on_settle_ms)
                    observed = runtime.manager.get_state(rule.outlet)
                    _echo_ok("Power cycle completed")
                    if verbose:
                        _echo_detail("power_log_path", runtime.log_path)
                        _echo_detail("observed_state", observed)
                        _echo_detail("step_duration_s", f"{time.time() - step_started:.3f}")
                    _emit_event(
                        event_cb,
                        "step.finished",
                        "Power cycle completed",
                        {
                            "test_name": test.name,
                            "step_index": step_idx,
                            "step_type": "power_cycle",
                            "resource_name": rule.resource,
                            "outlet": rule.outlet,
                            "off_ms": rule.off_ms,
                            "on_settle_ms": rule.on_settle_ms,
                            "observed_state": observed,
                        },
                    )

                elif hasattr(step, "power_expect"):
                    rule = step.power_expect
                    runtime = _require_power_runtime(power_runtimes, rule.resource)

                    _echo_info(
                        f"Step {step_idx}: expect power {rule.resource}.{rule.outlet} to be {rule.state}"
                    )
                    observed = runtime.manager.expect_state(rule.outlet, rule.state)
                    _echo_ok("Power state matched expectation")
                    if verbose:
                        _echo_detail("power_log_path", runtime.log_path)
                        _echo_detail("observed_state", observed)
                        _echo_detail("step_duration_s", f"{time.time() - step_started:.3f}")
                    _emit_event(
                        event_cb,
                        "step.finished",
                        "Power state matched expectation",
                        {
                            "test_name": test.name,
                            "step_index": step_idx,
                            "step_type": "power_expect",
                            "resource_name": rule.resource,
                            "outlet": rule.outlet,
                            "expected_state": rule.state,
                            "observed_state": observed,
                        },
                    )

                elif hasattr(step, "measure"):
                    rule = step.measure
                    runtime = _require_measurement_runtime(measurement_runtimes, rule.resource)

                    _echo_info(f"Step {step_idx}: measure resource {rule.resource}")
                    measurement = runtime.manager.measure()
                    value = float(measurement["value"])
                    unit = measurement.get("unit") or rule.unit
                    if rule.unit and unit and str(unit) != str(rule.unit):
                        raise RuntimeError(
                            f"Measurement unit mismatch for resource '{rule.resource}': expected {rule.unit}, observed {unit}"
                        )
                    _assert_numeric_value(value, rule)

                    metric_name = rule.record_as or rule.resource
                    metric_payload = {
                        "name": metric_name,
                        "resource": rule.resource,
                        "value": value,
                        "unit": unit,
                        "quantity": measurement.get("quantity"),
                        "timestamp": measurement.get("timestamp"),
                    }
                    results_payload["metrics"][metric_name] = metric_payload
                    results_payload["measurements"].append(metric_payload)
                    test_metrics[metric_name] = metric_payload
                    test_measurements.append(metric_payload)

                    _echo_ok(f"Measured {metric_name}={value}{(' ' + str(unit)) if unit else ''}")
                    if verbose:
                        _echo_detail("measurement_log_path", runtime.log_path)
                        _echo_detail("step_duration_s", f"{time.time() - step_started:.3f}")
                    _emit_event(
                        event_cb,
                        "step.finished",
                        "Measurement completed",
                        {
                            "test_name": test.name,
                            "step_index": step_idx,
                            "step_type": "measure",
                            "resource_name": rule.resource,
                            "metric_name": metric_name,
                            "value": value,
                            "unit": unit,
                        },
                    )

                elif hasattr(step, "assert_metric"):
                    rule = step.assert_metric
                    metric = results_payload["metrics"].get(rule.name)
                    if not metric:
                        raise RuntimeError(f"Metric '{rule.name}' has not been recorded yet")
                    value = float(metric["value"])
                    _echo_info(f"Step {step_idx}: assert metric {rule.name}={value}")
                    _assert_numeric_value(value, rule)
                    _echo_ok("Metric assertion passed")
                    _emit_event(
                        event_cb,
                        "step.finished",
                        "Metric assertion passed",
                        {
                            "test_name": test.name,
                            "step_index": step_idx,
                            "step_type": "assert_metric",
                            "metric_name": rule.name,
                            "value": value,
                        },
                    )

                elif hasattr(step, "send_can"):
                    rule = step.send_can
                    node_name = _resolve_node_name(bench, rule.node)
                    transport = _require_transport_runtime(runtimes, node_name, rule.transport)

                    _echo_info(
                        f"Step {step_idx}: send CAN frame on {node_name}.{rule.transport} "
                        f"(id=0x{rule.frame.id:X}, extended={rule.frame.extended}, data={rule.frame.data})"
                    )
                    transport.send_frame(
                        frame_id=rule.frame.id,
                        data=rule.frame.data,
                        extended=rule.frame.extended,
                    )
                    _echo_ok("CAN frame sent")
                    if verbose:
                        _echo_detail("transport_log_path", runtimes[node_name].transport_log_paths.get(rule.transport))
                        _echo_detail("step_duration_s", f"{time.time() - step_started:.3f}")
                    _emit_event(
                        event_cb,
                        "step.finished",
                        "CAN frame sent",
                        {
                            "test_name": test.name,
                            "step_index": step_idx,
                            "step_type": "send_can",
                            "node_name": node_name,
                            "transport_name": rule.transport,
                            "frame_id": rule.frame.id,
                            "extended": rule.frame.extended,
                            "data": rule.frame.data,
                        },
                    )

                elif hasattr(step, "expect_can"):
                    rule = step.expect_can
                    node_name = _resolve_node_name(bench, rule.node)
                    transport = _require_transport_runtime(runtimes, node_name, rule.transport)
                    within_ms = _resolve_timeout(bench, rule.within_ms)

                    _echo_info(
                        f"Step {step_idx}: expect CAN frame on {node_name}.{rule.transport} "
                        f"(id=0x{rule.frame.id:X}, extended={rule.frame.extended}, data={rule.frame.data}) "
                        f"within {within_ms} ms"
                    )
                    ok, last_seen = transport.expect_frame(
                        frame_id=rule.frame.id,
                        data=rule.frame.data,
                        within_ms=within_ms,
                        extended=rule.frame.extended,
                    )

                    if not ok:
                        message = (
                            f"CAN expectation timed out on {node_name}.{rule.transport}: "
                            f"id=0x{rule.frame.id:X}, extended={rule.frame.extended}, data={rule.frame.data}"
                        )
                        if last_seen:
                            message += f"; last seen: {last_seen}"
                        _echo_fail(message)
                        _echo_failure_context(
                            "Failure context",
                            {
                                "node": node_name,
                                "transport": rule.transport,
                                "frame_id": f"0x{rule.frame.id:X}",
                                "extended": rule.frame.extended,
                                "data": rule.frame.data,
                                "within_ms": within_ms,
                                "last_seen": last_seen,
                                "transport_log_path": runtimes[node_name].transport_log_paths.get(rule.transport),
                            },
                        )
                        test_failure_reason = message
                        _emit_event(
                            event_cb,
                            "step.failed",
                            message,
                            {
                                "test_name": test.name,
                                "step_index": step_idx,
                                "step_type": "expect_can",
                                "node_name": node_name,
                                "transport_name": rule.transport,
                                "frame_id": rule.frame.id,
                                "extended": rule.frame.extended,
                                "data": rule.frame.data,
                                "within_ms": within_ms,
                                "last_seen": last_seen,
                            },
                        )
                        test_pass = False
                        break

                    _echo_ok("CAN expectation satisfied")
                    if verbose:
                        _echo_detail("transport_log_path", runtimes[node_name].transport_log_paths.get(rule.transport))
                        _echo_detail("within_ms", within_ms)
                        _echo_detail("step_duration_s", f"{time.time() - step_started:.3f}")
                    _emit_event(
                        event_cb,
                        "step.finished",
                        "CAN expectation satisfied",
                        {
                            "test_name": test.name,
                            "step_index": step_idx,
                            "step_type": "expect_can",
                            "node_name": node_name,
                            "transport_name": rule.transport,
                            "frame_id": rule.frame.id,
                            "extended": rule.frame.extended,
                            "data": rule.frame.data,
                            "within_ms": within_ms,
                        },
                    )

                else:
                    raise RuntimeError(
                        f"Unsupported step model in suite parsing: {type(step).__name__}"
                    )

            test_elapsed = time.time() - test_started

            if not test_pass and test_failure_reason and test_failure_detail is None:
                failed_transport_name = None
                failed_power_resource_name = None
                failed_measurement_resource_name = None
                try:
                    if hasattr(step, "send_uart"):
                        failed_transport_name = step.send_uart.transport
                    elif hasattr(step, "expect_uart"):
                        failed_transport_name = step.expect_uart.transport
                    elif hasattr(step, "modbus_read_holding_registers"):
                        failed_transport_name = step.modbus_read_holding_registers.transport
                    elif hasattr(step, "modbus_write_single_register"):
                        failed_transport_name = step.modbus_write_single_register.transport
                    elif hasattr(step, "modbus_read_coils"):
                        failed_transport_name = step.modbus_read_coils.transport
                    elif hasattr(step, "modbus_write_single_coil"):
                        failed_transport_name = step.modbus_write_single_coil.transport
                    elif hasattr(step, "send_can"):
                        failed_transport_name = step.send_can.transport
                    elif hasattr(step, "expect_can"):
                        failed_transport_name = step.expect_can.transport
                    elif hasattr(step, "power_set"):
                        failed_power_resource_name = step.power_set.resource
                    elif hasattr(step, "power_cycle"):
                        failed_power_resource_name = step.power_cycle.resource
                    elif hasattr(step, "power_expect"):
                        failed_power_resource_name = step.power_expect.resource
                    elif hasattr(step, "measure"):
                        failed_measurement_resource_name = step.measure.resource
                except Exception:
                    pass

                test_failure_detail = build_failure(
                    message=test_failure_reason,
                    test_name=test.name,
                    test_index=index,
                    step_index=step_idx,
                    steps_total=len(test.steps),
                    step_type=step_name,
                    node_name=step_node_name,
                    transport_name=failed_transport_name,
                    artifacts=_step_artifacts_for_failure(
                        runtimes,
                        power_runtimes,
                        measurement_runtimes,
                        step_type=step_name,
                        node_name=step_node_name,
                        transport_name=failed_transport_name,
                        power_resource_name=failed_power_resource_name,
                        measurement_resource_name=failed_measurement_resource_name,
                    ),
                )

            if not test_pass and test_failure_detail and results_payload.get("failure") is None:
                results_payload["failure"] = test_failure_detail

            if test_pass:
                passed_tests += 1
                _echo_ok(f"Test passed in {test_elapsed:.2f}s")
                _emit_event(
                    event_cb,
                    "test.finished",
                    f"Test '{test.name}' passed",
                    {
                        "test_name": test.name,
                        "test_index": index,
                        "passed": True,
                        "duration_s": round(test_elapsed, 3),
                    },
                )
            else:
                failed_tests += 1
                _echo_fail(f"Test failed in {test_elapsed:.2f}s")
                _emit_event(
                    event_cb,
                    "test.finished",
                    f"Test '{test.name}' failed",
                    {
                        "test_name": test.name,
                        "test_index": index,
                        "passed": False,
                        "duration_s": round(test_elapsed, 3),
                        "failure_reason": test_failure_reason,
                        "failure": test_failure_detail,
                    },
                )

            results_payload["tests"].append(
                {
                    "name": test.name,
                    "test_case_id": getattr(test, "test_case_id", None),
                    "requirement_ids": list(getattr(test, "requirement_ids", []) or []),
                    "risk_ids": list(getattr(test, "risk_ids", []) or []),
                    "tags": list(getattr(test, "tags", []) or []),
                    "passed": test_pass,
                    "duration_s": round(test_elapsed, 3),
                    "failure_reason": test_failure_reason,
                    "failure": test_failure_detail,
                    "metrics": test_metrics,
                    "measurements": test_measurements,
                }
            )

        suite_elapsed = time.time() - suite_started
        results_payload["summary"]["passed"] = passed_tests
        results_payload["summary"]["failed"] = failed_tests
        results_payload["status"] = "passed" if failed_tests == 0 else "failed"
        results_payload["finished_at"] = _utc_now()
        results_payload["duration_s"] = round(suite_elapsed, 3)
        evidence_payload = finalize_evidence_report(
            evidence_payload,
            out_dir=out,
            status=results_payload["status"],
            finished_at=results_payload["finished_at"],
            duration_s=results_payload["duration_s"],
            summary=results_payload["summary"],
            failure=results_payload.get("failure"),
            suite_cfg=suite,
            test_results=results_payload.get("tests", []),
            metrics=results_payload.get("metrics", {}),
            measurements=results_payload.get("measurements", []),
        )
        results_payload["evidence"] = evidence_payload
        evidence_paths = write_evidence_files(out, evidence_payload)
        results_payload["artifacts"].update(evidence_paths)

        _write_json(results_json_path, results_payload)

        _echo_section("RESULT")
        if failed_tests == 0:
            _echo_ok(f"All tests passed ({passed_tests}/{len(suite.tests)})")
        else:
            _echo_fail(
                f"Suite finished with failures: {passed_tests} passed, {failed_tests} failed"
            )

        _echo_info(f"Results JSON saved to: {results_json_path}")
        _echo_info(f"Evidence JSON saved to: {evidence_json_path}")
        _echo_info(f"Evidence HTML saved to: {out / 'evidence.html'}")
        firmware_sha = (((evidence_payload.get("firmware") or {}).get("sha256")) or "—")
        git_commit = (((evidence_payload.get("source") or {}).get("git_commit")) or "—")
        _echo_info(f"Evidence: firmware_sha256={firmware_sha} git_commit={git_commit}")

        if failed_tests > 0:
            typer.echo("")
            typer.echo("Failed tests summary:")
            for test_result in results_payload["tests"]:
                if test_result["passed"]:
                    continue
                typer.echo(f"  - {test_result['name']}")
                if test_result.get("failure_reason"):
                    typer.echo(f"    reason: {test_result['failure_reason']}")
                failure = test_result.get("failure") or {}
                if failure.get("explanation"):
                    typer.echo(f"    explanation: {failure['explanation']}")
                suggestions = list(failure.get("suggestions") or [])
                if suggestions:
                    typer.echo("    suggested fixes:")
                    for suggestion in suggestions[:4]:
                        typer.echo(f"      - {suggestion}")

        _emit_event(
            event_cb,
            "run.finished",
            "Run finished",
            {
                "status": results_payload["status"],
                "passed": passed_tests,
                "failed": failed_tests,
                "tests_total": len(suite.tests),
                "duration_s": round(suite_elapsed, 3),
                "results_json_path": str(results_json_path.resolve()),
                "evidence_json_path": str(evidence_json_path.resolve()),
                "failure": results_payload.get("failure"),
                "evidence": evidence_payload,
            },
        )

        return 0 if failed_tests == 0 else 1

    except Exception as e:
        raw_error = f"{type(e).__name__}: {e}"
        if isinstance(e, BenchCIFailure):
            failure = e.failure
        else:
            failure = build_failure(
                message=str(e) or raw_error,
                raw_error=raw_error,
                artifacts={"results_json": str(results_json_path.resolve())},
            )

        results_payload["summary"]["passed"] = passed_tests
        results_payload["summary"]["failed"] = failed_tests
        results_payload["status"] = "error"
        results_payload["finished_at"] = _utc_now()
        results_payload["duration_s"] = round(time.time() - suite_started, 3)
        results_payload["error"] = failure_summary_text(failure)
        results_payload["failure"] = failure
        evidence_payload = finalize_evidence_report(
            evidence_payload,
            out_dir=out,
            status=results_payload["status"],
            finished_at=results_payload["finished_at"],
            duration_s=results_payload["duration_s"],
            summary=results_payload["summary"],
            failure=failure,
            suite_cfg=suite,
            test_results=results_payload.get("tests", []),
            metrics=results_payload.get("metrics", {}),
            measurements=results_payload.get("measurements", []),
        )
        results_payload["evidence"] = evidence_payload
        evidence_paths = write_evidence_files(out, evidence_payload)
        results_payload["artifacts"].update(evidence_paths)
        _write_json(results_json_path, results_payload)

        _echo_section("ERROR")
        _echo_structured_failure(failure)
        _echo_info(f"Partial results JSON saved to: {results_json_path}")
        _echo_info(f"Evidence JSON saved to: {evidence_json_path}")
        _echo_info(f"Evidence HTML saved to: {out / 'evidence.html'}")

        _emit_event(
            event_cb,
            "run.failed",
            failure_summary_text(failure),
            {
                "error": failure_summary_text(failure),
                "failure": failure,
                "results_json_path": str(results_json_path.resolve()),
                "evidence_json_path": str(evidence_json_path.resolve()),
                "evidence": evidence_payload,
            },
        )

        return 1

    finally:
        _stop_runtime_contexts(runtimes, power_runtimes, measurement_runtimes, event_cb=event_cb)