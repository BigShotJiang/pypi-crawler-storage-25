from __future__ import annotations

import json
import os
import platform
import re
import shutil
import socket
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import typer


@dataclass
class CheckResult:
    """Represents the result of a single diagnostic check."""

    name: str
    ok: bool
    details: str = ""
    required: bool = True
    hint: str | None = None
    section: str = "General"

    def to_dict(self) -> dict:
        """Convert to a JSON-serializable dictionary."""
        return {
            "section": self.section,
            "name": self.name,
            "ok": self.ok,
            "details": self.details,
            "required": self.required,
            "hint": self.hint,
        }


@dataclass
class SerialPortInfo:
    device: str
    description: str = ""
    hwid: str = ""
    manufacturer: str = ""
    product: str = ""
    serial_number: str = ""
    vid: str | None = None
    pid: str | None = None
    source: str = "pyserial"

    def to_dict(self) -> dict[str, Any]:
        return {
            "device": self.device,
            "description": self.description,
            "hwid": self.hwid,
            "manufacturer": self.manufacturer,
            "product": self.product,
            "serial_number": self.serial_number,
            "vid": self.vid,
            "pid": self.pid,
            "source": self.source,
            "classification": _classify_serial_port(self),
            "bench_yaml_hint": f"port: {self.device}",
        }


def _run_cmd(cmd: list[str], timeout_s: int = 5) -> tuple[int, str]:
    """Run a command and return (exit_code, combined_output)."""
    try:
        p = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=timeout_s,
            check=False,
        )
        return p.returncode, (p.stdout or "").strip()
    except FileNotFoundError:
        return 127, "not found"
    except subprocess.TimeoutExpired:
        return 124, "timeout"


def _check_python(min_major: int = 3, min_minor: int = 11) -> CheckResult:
    v = sys.version_info
    ok = (v.major, v.minor) >= (min_major, min_minor)
    return CheckResult(
        section="System",
        name="Python",
        ok=ok,
        details=f"{v.major}.{v.minor}.{v.micro} (need >= {min_major}.{min_minor})",
        required=True,
        hint="Install Python 3.11+ and ensure your environment uses it.",
    )


def _check_os() -> CheckResult:
    return CheckResult(
        section="System",
        name="OS",
        ok=True,
        details=f"{platform.system()} {platform.release()} ({platform.machine()})",
        required=False,
    )


def _check_tool(
    exe_name: str,
    version_args: list[str] | None = None,
    required: bool = False,
    hint: str | None = None,
) -> CheckResult:
    path = shutil.which(exe_name)
    if not path:
        return CheckResult(
            section="Tools",
            name=exe_name,
            ok=False,
            details="not found in PATH",
            required=required,
            hint=hint,
        )

    details = f"found at {path}"
    if version_args:
        code, out = _run_cmd([exe_name, *version_args], timeout_s=5)
        if out:
            details += f" | {out.splitlines()[0][:200]}"
        elif code == 124:
            details += " | version check timeout"
        else:
            details += " | version check failed"
    return CheckResult(section="Tools", name=exe_name, ok=True, details=details, required=required)


def _check_python_module(
    module_name: str,
    required: bool = False,
    hint: str | None = None,
) -> CheckResult:
    try:
        __import__(module_name)
        return CheckResult(
            section="Python modules",
            name=module_name,
            ok=True,
            details="import successful",
            required=required,
            hint=hint,
        )
    except Exception as e:
        return CheckResult(
            section="Python modules",
            name=module_name,
            ok=False,
            details=f"import failed: {e}",
            required=required,
            hint=hint,
        )


def _serial_port_infos() -> list[SerialPortInfo]:
    """Return detected serial ports with best-effort metadata."""
    try:
        from serial.tools import list_ports  # type: ignore

        infos: list[SerialPortInfo] = []
        for p in list_ports.comports():
            dev = p.device or ""
            if not dev:
                continue
            vid = f"{int(p.vid):04X}" if getattr(p, "vid", None) is not None else None
            pid = f"{int(p.pid):04X}" if getattr(p, "pid", None) is not None else None
            infos.append(
                SerialPortInfo(
                    device=dev,
                    description=p.description or "",
                    hwid=p.hwid or "",
                    manufacturer=getattr(p, "manufacturer", "") or "",
                    product=getattr(p, "product", "") or "",
                    serial_number=getattr(p, "serial_number", "") or "",
                    vid=vid,
                    pid=pid,
                    source="pyserial",
                )
            )
        if infos:
            return infos
    except Exception:
        pass

    sysname = platform.system().lower()
    dev = Path("/dev")
    patterns: list[str] = []
    if sysname == "darwin":
        patterns = ["cu.usb*", "tty.usb*", "cu.*", "tty.*"]
    elif sysname != "windows":
        patterns = ["ttyUSB*", "ttyACM*", "serial/by-id/*"]

    seen: set[str] = set()
    infos = []
    for pattern in patterns:
        for p in sorted(dev.glob(pattern)):
            try:
                device = str(p.resolve()) if "serial/by-id" in str(p) else str(p)
            except Exception:
                device = str(p)
            if device in seen:
                continue
            seen.add(device)
            infos.append(SerialPortInfo(device=device, description=p.name, source="/dev scan"))
    return infos


def _classify_serial_port(info: SerialPortInfo) -> str:
    text = " ".join(
        [
            info.device,
            info.description,
            info.hwid,
            info.manufacturer,
            info.product,
        ]
    ).lower()

    if "bluetooth" in text:
        return "Bluetooth virtual serial port — usually not useful for BenchCI hardware tests."
    if "stlink" in text or "st-link" in text or "stmicro" in text or "stm32" in text:
        return "Likely ST-Link virtual COM port — useful for STM32/Nucleo UART logs."
    if "j-link" in text or "jlink" in text or "segger" in text:
        return "Likely J-Link serial/debug interface."
    if "ch340" in text or "ch341" in text or "wch" in text or "qin" in text:
        return "Likely CH340/CH341 USB serial adapter — UART, RS485, or relay control."
    if "ftdi" in text or "ft232" in text:
        return "Likely FTDI USB serial adapter — UART, RS485, or relay control."
    if "cp210" in text or "silicon labs" in text:
        return "Likely CP210x USB serial adapter — UART, RS485, or relay control."
    if "usb serial" in text or "usb-serial" in text or "uart" in text:
        return "Likely USB serial adapter — can be used for UART, RS485, or relay control."
    if "ttyacm" in text or "usbmodem" in text:
        return "Likely USB CDC ACM device — often board UART or debug probe VCP."
    if "ttyusb" in text or "usbserial" in text:
        return "Likely USB serial adapter — can be used for UART, RS485, or relay control."
    return "Serial-like device — verify whether it is UART, RS485, relay, or another interface."


def _format_serial_ports(infos: list[SerialPortInfo]) -> str:
    if not infos:
        return "No serial ports detected. Connect your board/probe/adapter and run doctor again."

    lines: list[str] = [f"Detected {len(infos)} serial-like device(s):"]
    for idx, info in enumerate(infos, start=1):
        lines.append(f"")
        lines.append(f"{idx}. {info.device}")
        if info.description:
            lines.append(f"   Description: {info.description}")
        if info.manufacturer:
            lines.append(f"   Manufacturer: {info.manufacturer}")
        if info.product:
            lines.append(f"   Product: {info.product}")
        if info.vid or info.pid:
            lines.append(f"   USB ID: {info.vid or '????'}:{info.pid or '????'}")
        if info.serial_number:
            lines.append(f"   Serial: {info.serial_number}")
        if info.hwid:
            lines.append(f"   HWID: {info.hwid}")
        lines.append(f"   Likely use: {_classify_serial_port(info)}")
        lines.append(f"   bench.yaml: port: {info.device}")
    return "\n".join(lines)


def _check_serial_list(infos: list[SerialPortInfo]) -> CheckResult:
    return CheckResult(
        section="Ports",
        name="Serial ports",
        ok=bool(infos),
        details=_format_serial_ports(infos),
        required=False,
        hint="Connect the board/probe/adapter and run 'benchci doctor --ports' again." if not infos else None,
    )


def _test_uart_open(port: str, baud: int) -> CheckResult:
    try:
        import serial  # type: ignore
    except Exception as e:
        return CheckResult(
            section="Ports",
            name="UART open test",
            ok=False,
            details=f"pyserial import failed: {e}",
            required=True,
            hint="Install pyserial: pip install pyserial",
        )

    try:
        s = serial.Serial(port=port, baudrate=baud, timeout=0.2)
        s.close()
        return CheckResult(
            section="Ports",
            name="UART open test",
            ok=True,
            details=f"opened and closed {port} @ {baud}",
            required=True,
        )
    except Exception as e:
        return CheckResult(
            section="Ports",
            name="UART open test",
            ok=False,
            details=f"failed to open {port}: {e}",
            required=True,
            hint="Close programs using the port (screen/minicom/CubeIDE), check permissions, and verify the port in bench.yaml.",
        )


def _serial_device_exists(port: str, infos: list[SerialPortInfo]) -> bool:
    if any(info.device == port for info in infos):
        return True
    p = Path(port)
    return p.exists()


def _check_configured_serial_port(label: str, port: str, infos: list[SerialPortInfo]) -> CheckResult:
    ok = _serial_device_exists(port, infos)
    matches = [info for info in infos if info.device == port]
    if matches:
        detail = f"configured port exists: {port}\n{_classify_serial_port(matches[0])}"
    elif ok:
        detail = f"configured port path exists: {port}"
    else:
        detail = f"configured port was not detected: {port}"
    return CheckResult(
        section="Bench hardware",
        name=label,
        ok=ok,
        details=detail,
        required=True,
        hint="Run 'benchci doctor --ports' and copy the correct port into bench.yaml." if not ok else None,
    )


def _list_usb_devices() -> tuple[bool, str]:
    sysname = platform.system().lower()
    if sysname == "darwin":
        code, out = _run_cmd(["system_profiler", "SPUSBDataType"], timeout_s=10)
        if code == 0 and out:
            lines = []
            for raw in out.splitlines():
                line = raw.rstrip()
                stripped = line.strip()
                if not stripped:
                    continue
                if stripped.endswith(":") or any(k in stripped for k in ["Product ID:", "Vendor ID:", "Serial Number:", "Manufacturer:"]):
                    lines.append(line)
            return True, "\n".join(lines[:120]) or out[:4000]
        return False, out or "system_profiler SPUSBDataType failed"

    if sysname == "linux":
        code, out = _run_cmd(["lsusb"], timeout_s=5)
        if code == 0 and out:
            return True, out
        usb_root = Path("/sys/bus/usb/devices")
        if usb_root.exists():
            lines = []
            for dev in sorted(usb_root.iterdir()):
                product = _read_text(dev / "product")
                manufacturer = _read_text(dev / "manufacturer")
                serial = _read_text(dev / "serial")
                vid = _read_text(dev / "idVendor")
                pid = _read_text(dev / "idProduct")
                if product or manufacturer or (vid and pid):
                    lines.append(
                        f"{dev.name}: {manufacturer or 'unknown'} {product or ''} "
                        f"id={vid or '????'}:{pid or '????'} serial={serial or '—'}".strip()
                    )
            return True, "\n".join(lines) if lines else "No USB device metadata found in /sys/bus/usb/devices."
        return False, "lsusb not found and /sys/bus/usb/devices is unavailable"

    if sysname == "windows":
        cmd = [
            "powershell",
            "-NoProfile",
            "-Command",
            "Get-PnpDevice -PresentOnly | Where-Object { $_.InstanceId -like 'USB*' } | Select-Object -First 80 -Property FriendlyName,InstanceId | Format-Table -AutoSize",
        ]
        code, out = _run_cmd(cmd, timeout_s=10)
        return code == 0, out or "PowerShell USB query failed"

    return False, "USB listing is not implemented for this OS."


def _check_usb_devices() -> CheckResult:
    ok, details = _list_usb_devices()
    return CheckResult(
        section="USB",
        name="USB devices",
        ok=ok,
        details=details or "No USB details available.",
        required=False,
        hint="Install lsusb or check OS USB permissions if USB devices are missing." if not ok else None,
    )


def _read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace").strip()
    except Exception:
        return ""


def _list_gpiochips() -> list[str]:
    if platform.system().lower() == "windows":
        return []
    return [str(p) for p in sorted(Path("/dev").glob("gpiochip*"))]


def _check_gpiochip_list(chips: list[str]) -> CheckResult:
    if not chips:
        return CheckResult(
            section="GPIO",
            name="GPIO chips",
            ok=False,
            details="No /dev/gpiochip* devices detected. This is normal on non-Linux machines and many laptops.",
            required=False,
        )
    return CheckResult(
        section="GPIO",
        name="GPIO chips",
        ok=True,
        details="\n".join(f"- {chip}" for chip in chips),
        required=False,
    )


def _check_gpiochip_device(path_str: str) -> CheckResult:
    p = Path(path_str)
    if not p.exists():
        return CheckResult(
            section="Bench hardware",
            name=f"GPIO chip: {path_str}",
            ok=False,
            details="device path does not exist",
            required=True,
            hint="Verify the gpiochip path in bench.yaml and check that the kernel exposes the GPIO controller.",
        )

    if not p.is_char_device():
        return CheckResult(
            section="Bench hardware",
            name=f"GPIO chip: {path_str}",
            ok=False,
            details="path exists but is not a character device",
            required=True,
            hint="Verify that this is a Linux gpiochip device such as /dev/gpiochip0.",
        )

    try:
        import gpiod  # type: ignore
        if hasattr(gpiod, "is_gpiochip_device"):
            try:
                is_chip = bool(gpiod.is_gpiochip_device(path_str))
            except Exception:
                is_chip = True
        else:
            is_chip = True
    except Exception:
        is_chip = True

    if not is_chip:
        return CheckResult(
            section="Bench hardware",
            name=f"GPIO chip: {path_str}",
            ok=False,
            details="device exists but does not appear to be a gpiochip device",
            required=True,
            hint="Use a Linux GPIO character device such as /dev/gpiochip0.",
        )

    return CheckResult(
        section="Bench hardware",
        name=f"GPIO chip: {path_str}",
        ok=True,
        details="available",
        required=True,
    )


def _check_can_interface(interface: str) -> CheckResult:
    sys_path = Path("/sys/class/net") / interface
    ok = sys_path.exists() if platform.system().lower() == "linux" else True
    return CheckResult(
        section="Bench hardware",
        name=f"CAN interface: {interface}",
        ok=ok,
        details="detected" if ok else "interface not found under /sys/class/net",
        required=True,
        hint="Create/configure the SocketCAN interface, e.g. 'sudo ip link set can0 up type can bitrate 500000'." if not ok else None,
    )


def _check_modbus_tcp(host: str, port: int, timeout_s: float = 1.0) -> CheckResult:
    try:
        with socket.create_connection((host, int(port)), timeout=timeout_s):
            pass
        return CheckResult(
            section="Bench hardware",
            name=f"Modbus TCP endpoint: {host}:{port}",
            ok=True,
            details="TCP connection succeeded",
            required=True,
        )
    except Exception as e:
        return CheckResult(
            section="Bench hardware",
            name=f"Modbus TCP endpoint: {host}:{port}",
            ok=False,
            details=f"TCP connection failed: {e}",
            required=False,
            hint="If this endpoint is expected to be reachable from this machine, check network, IP address, and firewall.",
        )


def _check_agent_health(agent_url: str, token: str | None = None) -> CheckResult:
    try:
        import httpx
    except Exception as e:
        return CheckResult(
            section="Agent",
            name="Agent health",
            ok=False,
            details=f"httpx missing: {e}",
            required=True,
            hint="Install httpx: pip install httpx",
        )

    url = agent_url.rstrip("/") + "/health"
    try:
        headers = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        with httpx.Client(timeout=3.0) as client:
            r = client.get(url, headers=headers)
        if r.status_code == 200:
            details = f"OK: {url}"
            try:
                body = r.json()
                details += f"\nagent_id: {body.get('agent_id', '—')}\nregistered_benches: {body.get('registered_benches', '—')}\nqueue_depth: {body.get('queue_depth', '—')}"
            except Exception:
                pass
            return CheckResult(section="Agent", name="Agent health", ok=True, details=details, required=True)
        return CheckResult(
            section="Agent",
            name="Agent health",
            ok=False,
            details=f"{url} returned HTTP {r.status_code}",
            required=True,
            hint="Check agent URL, network, firewall, token, and that agent is running.",
        )
    except Exception as e:
        return CheckResult(
            section="Agent",
            name="Agent health",
            ok=False,
            details=f"failed to reach {url}: {e}",
            required=True,
            hint="Check agent URL, network connectivity, and firewall.",
        )


def _bench_hardware_checks(bench_cfg: Any, serial_infos: list[SerialPortInfo]) -> tuple[list[CheckResult], dict[str, Any]]:
    results: list[CheckResult] = []
    facts: dict[str, Any] = {
        "required_flash_backends": [],
        "required_reset_backends": [],
        "serial_ports": [],
        "gpio_chips": [],
        "can_interfaces": [],
        "needs_pyserial": False,
        "needs_gpiod": False,
        "needs_python_can": False,
        "needs_pymodbus": False,
        "needs_httpx": False,
    }

    required_flash_backends: set[str] = set()
    required_reset_backends: set[str] = set()
    local_gpio_chip_paths: set[str] = set()
    can_interfaces: set[str] = set()

    for node_name, node_cfg in bench_cfg.nodes.items():
        if node_cfg.flash is not None:
            backend = str(getattr(node_cfg.flash, "backend", "")).strip()
            if backend:
                required_flash_backends.add(backend)
            flash_port = getattr(node_cfg.flash, "port", None)
            if backend == "esptool" and flash_port:
                facts["needs_pyserial"] = True
                facts["serial_ports"].append({"kind": "flash.esptool", "node": node_name, "port": flash_port})
                results.append(_check_configured_serial_port(f"{node_name} flash port", str(flash_port), serial_infos))

        reset_method = str(getattr(getattr(node_cfg, "reset", None), "method", "none") or "none")
        if reset_method and reset_method != "none":
            required_reset_backends.add(reset_method)

        for transport_name, transport_cfg in node_cfg.transports.items():
            backend = getattr(transport_cfg, "backend", None)
            if backend in {"uart", "modbus_rtu"}:
                facts["needs_pyserial"] = True
                port = getattr(transport_cfg, "port", None)
                if port:
                    facts["serial_ports"].append(
                        {"kind": str(backend), "node": node_name, "transport": transport_name, "port": port}
                    )
                    results.append(
                        _check_configured_serial_port(
                            f"{node_name}.{transport_name} {backend} port",
                            str(port),
                            serial_infos,
                        )
                    )
                if backend == "modbus_rtu":
                    facts["needs_pymodbus"] = True
            elif backend == "modbus_tcp":
                facts["needs_pymodbus"] = True
                host = getattr(transport_cfg, "host", None)
                port = getattr(transport_cfg, "port", None)
                if host and port:
                    results.append(_check_modbus_tcp(str(host), int(port)))
            elif backend == "can":
                facts["needs_python_can"] = True
                interface = getattr(transport_cfg, "interface", None)
                if interface:
                    can_interfaces.add(str(interface))
                    results.append(_check_can_interface(str(interface)))

        for line_name, gpio_cfg in node_cfg.gpio.items():
            if getattr(gpio_cfg, "backend", None) == "local_gpio":
                facts["needs_gpiod"] = True
                chip = getattr(gpio_cfg, "chip", None)
                if chip:
                    local_gpio_chip_paths.add(str(chip))

    for resource_name, resource_cfg in getattr(bench_cfg, "resources", {}).items():
        driver = getattr(resource_cfg, "driver", None)
        driver_type = getattr(driver, "type", None)
        if driver_type == "usb_relay_serial":
            facts["needs_pyserial"] = True
            port = getattr(driver, "port", None)
            if port:
                facts["serial_ports"].append({"kind": "usb_relay_serial", "resource": resource_name, "port": port})
                results.append(_check_configured_serial_port(f"{resource_name} USB relay serial port", str(port), serial_infos))
        elif driver_type in {"gpio", "gpio_power"}:
            chip = getattr(driver, "chip", None)
            if chip:
                facts["needs_gpiod"] = True
                local_gpio_chip_paths.add(str(chip))
        elif driver_type in {"http_relay", "http_measurement"}:
            facts["needs_httpx"] = True
            url = getattr(driver, "url", None) or getattr(driver, "get_url", None) or getattr(driver, "on_url", None)
            if url:
                results.append(CheckResult(
                    section="Bench hardware",
                    name=f"{resource_name} {driver_type} endpoint",
                    ok=True,
                    details=f"configured endpoint: {url}",
                    required=False,
                    hint="Verify this endpoint is reachable from the agent machine before running hardware tests.",
                ))

    for chip_path in sorted(local_gpio_chip_paths):
        facts["gpio_chips"].append(chip_path)
        results.append(_check_gpiochip_device(chip_path))

    facts["required_flash_backends"] = sorted(required_flash_backends)
    facts["required_reset_backends"] = sorted(required_reset_backends)
    facts["can_interfaces"] = sorted(can_interfaces)

    if required_flash_backends:
        results.append(
            CheckResult(
                section="Bench config",
                name="Flash backends used by bench.yaml",
                ok=True,
                details=", ".join(sorted(required_flash_backends)),
                required=False,
            )
        )
    if required_reset_backends:
        results.append(
            CheckResult(
                section="Bench config",
                name="Reset backends used by bench.yaml",
                ok=True,
                details=", ".join(sorted(required_reset_backends)),
                required=False,
            )
        )

    return results, facts


def _render_human(results: list[CheckResult]) -> str:
    lines: list[str] = []
    lines.append("BenchCI Doctor")
    lines.append("=" * 72)

    section_order = ["System", "Bench config", "Ports", "USB", "GPIO", "Tools", "Python modules", "Bench hardware", "Agent", "General"]
    grouped: dict[str, list[CheckResult]] = {}
    for r in results:
        grouped.setdefault(r.section or "General", []).append(r)

    for section in section_order + [s for s in grouped if s not in section_order]:
        items = grouped.get(section)
        if not items:
            continue
        lines.append("")
        lines.append(section)
        lines.append("-" * 72)
        for r in items:
            status = "[ OK ]" if r.ok else ("[WARN]" if not r.required else "[FAIL]")
            req = "" if r.required else " (optional)"
            lines.append(f"{status} {r.name}{req}")
            if r.details:
                for detail_line in str(r.details).splitlines():
                    lines.append(f"       {detail_line}")

    failed_required = [r for r in results if r.required and not r.ok]
    hints: list[str] = []
    seen: set[str] = set()
    for r in failed_required:
        if r.hint and r.hint not in seen:
            seen.add(r.hint)
            hints.append(r.hint)

    if hints:
        lines.append("")
        lines.append("Recommended actions")
        lines.append("-" * 72)
        for hint in hints:
            lines.append(f"- {hint}")

    return "\n".join(lines)


def _maybe_pip_freeze() -> str:
    code, out = _run_cmd([sys.executable, "-m", "pip", "freeze"], timeout_s=10)
    if code == 0 and out:
        return out
    return "(pip freeze unavailable)"


def _write_export_zip(
    export_path: Path,
    payload: dict,
    human_text: str,
    bench_path: str | None,
    tool_outputs: dict[str, str],
) -> Path:
    export_path = export_path.expanduser().resolve()
    if export_path.suffix.lower() != ".zip":
        export_path = export_path.with_suffix(".zip")

    with tempfile.TemporaryDirectory(prefix="benchci-doctor-") as td:
        d = Path(td)
        (d / "doctor.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
        (d / "doctor.txt").write_text(human_text + "\n", encoding="utf-8")
        env_text = "\n".join(
            [
                f"python: {sys.version.replace(chr(10), ' ')}",
                f"platform: {platform.platform()}",
                f"cwd: {Path.cwd()}",
                f"time_utc: {payload.get('timestamp')}",
            ]
        )
        (d / "env.txt").write_text(env_text + "\n", encoding="utf-8")
        (d / "pip_freeze.txt").write_text(_maybe_pip_freeze() + "\n", encoding="utf-8")
        tools_lines = [f"{k}:\n{v}\n" for k, v in tool_outputs.items()]
        (d / "tools.txt").write_text("\n".join(tools_lines), encoding="utf-8")
        if bench_path:
            bp = Path(bench_path)
            if bp.exists():
                shutil.copy2(bp, d / "bench.yaml")
        shutil.make_archive(str(export_path.with_suffix("")), "zip", root_dir=str(d))
    return export_path


def run_doctor(
    port: Optional[str] = None,
    baud: int = 115200,
    bench: Optional[str] = None,
    agent: Optional[str] = None,
    agent_token: Optional[str] = None,
    json_output: bool = False,
    export: Optional[str] = None,
    ports: bool = False,
    usb: bool = False,
    tools: bool = False,
) -> int:
    """Run BenchCI environment, port, USB, bench, and agent diagnostics."""
    del ports, usb, tools  # Detailed ports/USB/tools are useful enough to include by default.

    results: list[CheckResult] = [_check_python(), _check_os()]
    bench_cfg = None
    bench_path = bench
    serial_infos = _serial_port_infos()
    gpio_chips = _list_gpiochips()

    if bench_path:
        try:
            from benchci.config.bench import get_bench_warnings, load_bench_config

            bench_cfg = load_bench_config(bench_path)
            results.append(
                CheckResult(
                    section="Bench config",
                    name="bench.yaml",
                    ok=True,
                    details=f"loaded '{bench_cfg.bench.name}' ({len(bench_cfg.nodes)} nodes)",
                    required=True,
                )
            )
            if bench_cfg.defaults and bench_cfg.defaults.node:
                results.append(
                    CheckResult(
                        section="Bench config",
                        name="Default node",
                        ok=True,
                        details=str(bench_cfg.defaults.node),
                        required=False,
                    )
                )
            for node_name, node_cfg in bench_cfg.nodes.items():
                results.append(
                    CheckResult(
                        section="Bench config",
                        name=f"Node: {node_name}",
                        ok=True,
                        details=(
                            f"kind={getattr(node_cfg, 'kind', 'node')} "
                            f"transports={len(node_cfg.transports)} gpio={len(node_cfg.gpio)} "
                            f"flash={'yes' if node_cfg.flash else 'no'}"
                        ),
                        required=False,
                    )
                )
            for warning in get_bench_warnings(bench_cfg):
                results.append(CheckResult(section="Bench config", name="Bench warning", ok=True, details=warning, required=False))
        except Exception as e:
            results.append(
                CheckResult(
                    section="Bench config",
                    name="bench.yaml",
                    ok=False,
                    details=f"failed to load: {e}",
                    required=True,
                    hint="Fix bench.yaml syntax/schema errors before running tests.",
                )
            )
            bench_cfg = None

    openocd_hint = "Install OpenOCD and ensure it is in PATH."
    cube_hint = "Install STM32CubeProgrammer and ensure STM32_Programmer_CLI is in PATH."
    jlink_hint = "Install SEGGER J-Link tools and ensure JLinkExe/JLink.exe is in PATH."
    esptool_hint = "Install esptool.py and ensure it is available in PATH."
    gpiod_hint = "Install Python gpiod bindings and ensure Linux gpiochip devices are accessible."

    if platform.system().lower() == "windows":
        jlink_tool_name = "JLink.exe"
    else:
        jlink_tool_name = "JLinkExe"

    openocd = _check_tool("openocd", ["-v"], required=False, hint=openocd_hint)
    cubeprog = _check_tool("STM32_Programmer_CLI", ["--version"], required=False, hint=cube_hint)
    jlink = _check_tool(jlink_tool_name, ["-?"], required=False, hint=jlink_hint)
    esptool = _check_tool("esptool.py", ["version"], required=False, hint=esptool_hint)
    results.extend([openocd, cubeprog, jlink, esptool])

    tool_outputs: dict[str, str] = {
        "openocd -v": _run_cmd(["openocd", "-v"], timeout_s=5)[1] if openocd.ok else "not found",
        "STM32_Programmer_CLI --version": _run_cmd(["STM32_Programmer_CLI", "--version"], timeout_s=5)[1] if cubeprog.ok else "not found",
        f"{jlink_tool_name} -?": _run_cmd([jlink_tool_name, "-?"], timeout_s=5)[1] if jlink.ok else "not found",
        "esptool.py version": _run_cmd(["esptool.py", "version"], timeout_s=5)[1] if esptool.ok else "not found",
    }

    results.append(_check_serial_list(serial_infos))
    results.append(_check_usb_devices())
    results.append(_check_gpiochip_list(gpio_chips))

    if port:
        results.append(_test_uart_open(port=port, baud=baud))

    bench_facts: dict[str, Any] = {}
    if bench_cfg is not None:
        hardware_results, bench_facts = _bench_hardware_checks(bench_cfg, serial_infos)
        results.extend(hardware_results)

        tool_requirements = set(bench_facts.get("required_flash_backends", [])) | set(bench_facts.get("required_reset_backends", []))
        for backend in sorted(tool_requirements):
            if backend == "openocd":
                results.append(CheckResult(section="Tools", name="Required by bench: openocd", ok=openocd.ok, details="used by flash/reset backend", required=True, hint=openocd_hint))
            elif backend in {"cubeprog", "stm32cubeprogrammer"}:
                results.append(CheckResult(section="Tools", name="Required by bench: STM32_Programmer_CLI", ok=cubeprog.ok, details="used by flash/reset backend", required=True, hint=cube_hint))
            elif backend == "jlink":
                results.append(CheckResult(section="Tools", name=f"Required by bench: {jlink_tool_name}", ok=jlink.ok, details="used by flash/reset backend", required=True, hint=jlink_hint))
            elif backend == "esptool":
                results.append(CheckResult(section="Tools", name="Required by bench: esptool.py", ok=esptool.ok, details="used by flash/reset backend", required=True, hint=esptool_hint))
            elif backend != "none":
                results.append(CheckResult(section="Tools", name=f"Required by bench: {backend}", ok=False, details="unknown backend", required=True, hint="Check flash.backend/reset.method in bench.yaml."))

        if bench_facts.get("needs_pyserial"):
            results.append(_check_python_module("serial", required=True, hint="Install pyserial: pip install pyserial"))
        if bench_facts.get("needs_pymodbus"):
            results.append(_check_python_module("pymodbus", required=True, hint="Install pymodbus: pip install pymodbus"))
        if bench_facts.get("needs_gpiod"):
            results.append(_check_python_module("gpiod", required=True, hint=gpiod_hint))
        if bench_facts.get("needs_httpx"):
            results.append(_check_python_module("httpx", required=True, hint="Install httpx: pip install httpx"))
        if bench_facts.get("needs_python_can"):
            results.append(_check_python_module("can", required=True, hint="Install python-can: pip install python-can"))

    if agent:
        results.append(_check_agent_health(agent, token=agent_token))

    all_ok = all(r.ok or not r.required for r in results)
    payload = {
        "tool": "benchci",
        "command": "doctor",
        "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "ok": all_ok,
        "inputs": {
            "port": port,
            "baud": baud,
            "bench": bench_path,
            "agent": agent,
            "agent_token_provided": bool(agent_token),
        },
        "serial_ports": [info.to_dict() for info in serial_infos],
        "gpio_chips": gpio_chips,
        "bench_facts": bench_facts,
        "checks": [r.to_dict() for r in results],
    }

    human_text = _render_human(results)

    if export:
        out_zip = _write_export_zip(
            export_path=Path(export),
            payload=payload,
            human_text=human_text,
            bench_path=bench_path,
            tool_outputs=tool_outputs,
        )
        typer.echo(f"[ OK ] Diagnostics exported to: {out_zip}")

    if json_output:
        typer.echo(json.dumps(payload, indent=2))
        return 0 if all_ok else 1

    typer.echo(human_text.rstrip("\n"))
    passed = sum(1 for r in results if r.ok)
    failed = sum(1 for r in results if not r.ok and r.required)
    warnings = sum(1 for r in results if not r.ok and not r.required)
    summary = f"\nSummary: {passed} checks passed"
    if warnings:
        summary += f", {warnings} optional warnings"
    if failed:
        summary += f", {failed} required checks failed"
    typer.echo(summary)
    return 0 if all_ok else 1
