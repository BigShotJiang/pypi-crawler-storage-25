from __future__ import annotations

import json
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib import request as urlrequest

from benchci.config.bench import (
    BenchConfig,
    ResourceConfig,
    ResourceDriverGpioPower,
    ResourceDriverHttpRelay,
    ResourceDriverMockPower,
    ResourceDriverUsbRelaySerialCommandMap,
)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _hex_bytes(data: bytes) -> str:
    return " ".join(f"{b:02X}" for b in data)


def _sleep_ms(ms: int) -> None:
    if ms > 0:
        time.sleep(ms / 1000.0)


class PowerController:
    """Abstract bench-level power controller.

    BenchCI suite files use vendor-neutral operations: set power, read power,
    and power-cycle. Concrete controllers translate those operations into GPIO,
    HTTP, serial relay, SCPI, or custom lab-controller commands.
    """

    def start(self) -> None:
        pass

    def stop(self) -> None:
        pass

    def set_state(self, outlet: str, state: bool) -> None:
        raise NotImplementedError

    def get_state(self, outlet: str) -> bool | None:
        return None

    def cycle(self, outlet: str, off_ms: int, on_settle_ms: int) -> None:
        self.set_state(outlet, False)
        _sleep_ms(off_ms)
        self.set_state(outlet, True)
        _sleep_ms(on_settle_ms)


class _LogMixin:
    _log_path: Path | None

    def _log(self, message: str) -> None:
        if self._log_path is None:
            return
        self._log_path.parent.mkdir(parents=True, exist_ok=True)
        with self._log_path.open("a", encoding="utf-8") as f:
            f.write(f"{_utc_now()} {message}\n")


class MockPowerController(_LogMixin, PowerController):
    """In-memory power controller used for demos, dry runs, and tests."""

    def __init__(self, resource_name: str, cfg: ResourceConfig, log_path: Path | None = None):
        if not isinstance(cfg.driver, ResourceDriverMockPower):
            raise RuntimeError("MockPowerController requires ResourceDriverMockPower")
        self._resource_name = resource_name
        self._driver = cfg.driver
        self._states = dict(cfg.driver.outlets)
        self._log_path = log_path

    def start(self) -> None:
        self._log(f"MOCK_START resource={self._resource_name} outlets={sorted(self._states.keys())}")

    def stop(self) -> None:
        self._log(f"MOCK_STOP resource={self._resource_name}")

    def _require_outlet(self, outlet: str) -> None:
        if outlet not in self._states:
            known = ", ".join(sorted(self._states.keys())) or "<none>"
            raise RuntimeError(f"Unknown outlet '{outlet}' for mock power resource '{self._resource_name}'. Known outlets: {known}")

    def set_state(self, outlet: str, state: bool) -> None:
        self._require_outlet(outlet)
        self._states[outlet] = bool(state)
        self._log(f"MOCK_SET resource={self._resource_name} outlet={outlet} state={bool(state)}")
        _sleep_ms(self._driver.on_settle_ms if state else self._driver.off_settle_ms)

    def get_state(self, outlet: str) -> bool | None:
        self._require_outlet(outlet)
        state = self._states[outlet]
        self._log(f"MOCK_GET resource={self._resource_name} outlet={outlet} state={state}")
        return state


class GpioPowerController(_LogMixin, PowerController):
    """Power controller backed by Linux GPIO character devices."""

    def __init__(self, resource_name: str, cfg: ResourceConfig, log_path: Path | None = None):
        if not isinstance(cfg.driver, ResourceDriverGpioPower):
            raise RuntimeError("GpioPowerController requires ResourceDriverGpioPower")
        self._resource_name = resource_name
        self._driver = cfg.driver
        self._log_path = log_path
        self._chip = None
        self._lines: dict[str, Any] = {}
        self._states: dict[str, bool] = {}

    def start(self) -> None:
        try:
            import gpiod  # type: ignore
        except Exception:
            raise RuntimeError("python gpiod is required for gpio_power resources.")

        if self._chip is not None:
            return

        try:
            self._chip = gpiod.Chip(self._driver.chip)
        except Exception:
            raise RuntimeError(f"Failed to open GPIO chip '{self._driver.chip}' for power control.")

        for outlet, line_no in self._driver.outlets.items():
            try:
                line = self._chip.get_line(int(line_no))
                initial_logical = bool(self._driver.initial_state) if self._driver.initial_state is not None else False
                initial_physical = initial_logical if self._driver.active_high else (not initial_logical)
                line.request(
                    consumer=f"benchci-{self._resource_name}-{outlet}",
                    type=gpiod.LINE_REQ_DIR_OUT,
                    default_vals=[1 if initial_physical else 0],
                )
                self._lines[outlet] = line
                if self._driver.initial_state is not None:
                    self._states[outlet] = bool(self._driver.initial_state)
            except Exception:
                self.stop()
                raise RuntimeError(f"Failed to request GPIO line {line_no} for power outlet '{outlet}'.")

        self._log(
            f"GPIO_START resource={self._resource_name} chip={self._driver.chip} "
            f"outlets={dict(self._driver.outlets)} active_high={self._driver.active_high}"
        )

    def stop(self) -> None:
        for outlet, line in list(self._lines.items()):
            try:
                line.release()
                self._log(f"GPIO_RELEASE resource={self._resource_name} outlet={outlet}")
            except Exception:
                self._log(f"GPIO_RELEASE_ERROR resource={self._resource_name} outlet={outlet}")
        self._lines.clear()
        if self._chip is not None:
            try:
                self._chip.close()
            except Exception:
                pass
            self._chip = None

    def _line(self, outlet: str):
        line = self._lines.get(outlet)
        if line is None:
            known = ", ".join(sorted(self._lines.keys())) or "<none>"
            raise RuntimeError(f"Unknown GPIO power outlet '{outlet}'. Known outlets: {known}")
        return line

    def set_state(self, outlet: str, state: bool) -> None:
        line = self._line(outlet)
        physical = bool(state) if self._driver.active_high else (not bool(state))
        try:
            line.set_value(1 if physical else 0)
        except Exception:
            raise RuntimeError(f"Failed to set GPIO power outlet '{outlet}'.")
        self._states[outlet] = bool(state)
        self._log(
            f"GPIO_SET resource={self._resource_name} outlet={outlet} "
            f"line={self._driver.outlets[outlet]} logical={bool(state)} physical={physical}"
        )
        _sleep_ms(self._driver.on_settle_ms if state else self._driver.off_settle_ms)

    def get_state(self, outlet: str) -> bool | None:
        line = self._line(outlet)
        try:
            physical = bool(line.get_value())
            logical = physical if self._driver.active_high else (not physical)
        except Exception:
            logical = self._states.get(outlet)
        self._log(f"GPIO_GET resource={self._resource_name} outlet={outlet} state={logical}")
        return logical


class HttpRelayPowerController(_LogMixin, PowerController):
    """Power controller for HTTP relay boards and simple lab-controller APIs."""

    def __init__(self, resource_name: str, cfg: ResourceConfig, log_path: Path | None = None):
        if not isinstance(cfg.driver, ResourceDriverHttpRelay):
            raise RuntimeError("HttpRelayPowerController requires ResourceDriverHttpRelay")
        self._resource_name = resource_name
        self._driver = cfg.driver
        self._log_path = log_path
        self._states: dict[str, bool] = {}

    def _channel(self, outlet: str) -> str:
        channel = self._driver.outlets.get(outlet)
        if channel is None:
            known = ", ".join(sorted(self._driver.outlets.keys())) or "<none>"
            raise RuntimeError(f"Unknown HTTP relay outlet '{outlet}'. Known outlets: {known}")
        return channel

    def _render_url(self, template: str, outlet: str, state: bool | None = None) -> str:
        channel = self._channel(outlet)
        value = "1" if state else "0" if state is not None else ""
        return template.format(outlet=outlet, channel=channel, state=str(state).lower() if state is not None else "", value=value)

    def _request(self, url: str, *, method: str) -> str:
        req = urlrequest.Request(url, method=method)
        for key, value in self._driver.headers.items():
            req.add_header(key, value)
        self._log(f"HTTP_TX resource={self._resource_name} method={method} url={url}")
        try:
            with urlrequest.urlopen(req, timeout=self._driver.timeout_ms / 1000.0) as resp:
                payload = resp.read(4096).decode("utf-8", errors="replace")
                self._log(f"HTTP_RX status={getattr(resp, 'status', None)} body={payload[:200]!r}")
                return payload
        except Exception:
            raise RuntimeError("HTTP relay command failed.")

    def set_state(self, outlet: str, state: bool) -> None:
        url = self._render_url(self._driver.on_url if state else self._driver.off_url, outlet, state)
        self._request(url, method=self._driver.method)
        self._states[outlet] = bool(state)
        _sleep_ms(self._driver.on_settle_ms if state else self._driver.off_settle_ms)

    def get_state(self, outlet: str) -> bool | None:
        if not self._driver.get_url:
            return self._states.get(outlet)
        body = self._request(self._render_url(self._driver.get_url, outlet), method="GET").strip().lower()
        values = [body]
        try:
            parsed = json.loads(body)
            if isinstance(parsed, dict):
                values.extend(str(v).strip().lower() for v in parsed.values())
            else:
                values.append(str(parsed).strip().lower())
        except Exception:
            pass
        on_values = {v.strip().lower() for v in self._driver.on_values}
        off_values = {v.strip().lower() for v in self._driver.off_values}
        if any(v in on_values for v in values):
            return True
        if any(v in off_values for v in values):
            return False
        return self._states.get(outlet)


@dataclass
class _OutletBinding:
    logical_name: str
    driver_channel: str


class UsbRelayProtocol:
    """Abstract protocol for vendor-specific USB relay modules."""

    def set_state_command(self, channel: str, state: bool) -> bytes:
        raise NotImplementedError

    def get_state_command(self, channel: str) -> bytes | None:
        return None

    def parse_state_response(self, channel: str, payload: bytes) -> bool | None:
        return None



class CommandMapRelayProtocol(UsbRelayProtocol):
    """Generic serial protocol defined by hex command maps in bench.yaml."""

    def __init__(self, driver: ResourceDriverUsbRelaySerialCommandMap):
        self._driver = driver

    def _command(self, mapping: dict[str, str], channel: str, label: str) -> bytes:
        text = mapping.get(channel)
        if not text:
            raise RuntimeError(f"No {label} command configured for relay channel '{channel}'.")
        try:
            return bytes.fromhex(text)
        except ValueError:
            raise RuntimeError(f"Invalid hex bytes for relay channel '{channel}' {label} command.")

    def set_state_command(self, channel: str, state: bool) -> bytes:
        return self._command(self._driver.on_commands if state else self._driver.off_commands, channel, "ON" if state else "OFF")

    def get_state_command(self, channel: str) -> bytes | None:
        text = self._driver.get_commands.get(channel)
        if not text:
            return None
        return self._command(self._driver.get_commands, channel, "GET")

    def parse_state_response(self, channel: str, payload: bytes) -> bool | None:
        if not payload:
            return None
        candidates = {
            payload.hex().lower(),
            _hex_bytes(payload).lower(),
            payload.decode("utf-8", errors="ignore").strip().lower(),
        }
        on_values = {v.strip().lower() for v in self._driver.on_response_values}
        off_values = {v.strip().lower() for v in self._driver.off_response_values}
        if candidates & on_values:
            return True
        if candidates & off_values:
            return False
        return None


class UsbRelaySerialPowerController(_LogMixin, PowerController):
    """Serial USB relay power controller using a vendor-specific protocol."""

    def __init__(self, resource_name: str, cfg: ResourceConfig, protocol: UsbRelayProtocol, log_path: Path | None = None):
        self._resource_name = resource_name
        self._cfg = cfg
        self._driver = cfg.driver
        self._protocol = protocol
        self._log_path = log_path
        self._ser = None
        self._states: dict[str, bool] = {}

    def _require_serial(self):
        if self._ser is None:
            raise RuntimeError(f"Power controller for resource '{self._resource_name}' is not started")
        return self._ser

    def _resolve_channel(self, outlet: str) -> str:
        channel = self._driver.outlets.get(outlet)
        if channel is None:
            known = ", ".join(sorted(self._driver.outlets.keys())) or "<none>"
            raise RuntimeError(f"Unknown outlet '{outlet}' for power resource '{self._resource_name}'. Known outlets: {known}")
        return channel

    def start(self) -> None:
        if self._ser is not None:
            return
        try:
            import serial  # type: ignore
        except Exception:
            raise RuntimeError("pyserial is required for USB relay power control.")
        try:
            self._ser = serial.Serial(
                port=self._driver.port,
                baudrate=self._driver.baud,
                timeout=self._driver.timeout_ms / 1000.0,
                write_timeout=self._driver.timeout_ms / 1000.0,
            )
        except Exception:
            raise RuntimeError("Failed to open USB relay serial port.")
        self._log(
            f"SERIAL_START resource={self._resource_name} vendor={self._driver.vendor} model={self._driver.model} "
            f"port={self._driver.port} baud={self._driver.baud} timeout_ms={self._driver.timeout_ms}"
        )

    def stop(self) -> None:
        if self._ser is None:
            return
        try:
            self._ser.close()
            self._log(f"SERIAL_STOP resource={self._resource_name} port={self._driver.port}")
        except Exception:
            self._log(f"SERIAL_STOP_ERROR resource={self._resource_name} port={self._driver.port}")
        finally:
            self._ser = None

    def _write_command(self, payload: bytes, *, action: str, outlet: str, channel: str) -> None:
        ser = self._require_serial()
        self._log(f"TX action={action} outlet={outlet} channel={channel} bytes={_hex_bytes(payload)}")
        try:
            reset_input_buffer = getattr(ser, "reset_input_buffer", None)
            if callable(reset_input_buffer):
                reset_input_buffer()
        except Exception:
            pass
        try:
            ser.write(payload)
            ser.flush()
        except Exception:
            raise RuntimeError("Failed to send USB relay command.")

    def _read_response(self, max_bytes: int = 64) -> bytes:
        ser = self._require_serial()
        try:
            data = ser.read(max_bytes)
        except Exception:
            raise RuntimeError("Failed to read USB relay response.")
        self._log(f"RX bytes={_hex_bytes(data) if data else '<none>'}")
        return bytes(data)

    def set_state(self, outlet: str, state: bool) -> None:
        channel = self._resolve_channel(outlet)
        payload = self._protocol.set_state_command(channel, state)
        action = "on" if state else "off"
        self._write_command(payload, action=action, outlet=outlet, channel=channel)
        self._states[outlet] = bool(state)
        _sleep_ms(self._driver.on_settle_ms if state else self._driver.off_settle_ms)

    def get_state(self, outlet: str) -> bool | None:
        channel = self._resolve_channel(outlet)
        cmd = self._protocol.get_state_command(channel)
        if cmd is None:
            return self._states.get(outlet)
        self._write_command(cmd, action="get", outlet=outlet, channel=channel)
        reply = self._read_response()
        parsed = self._protocol.parse_state_response(channel, reply)
        return parsed if parsed is not None else self._states.get(outlet)



class CommandMapSerialRelayPowerController(UsbRelaySerialPowerController):
    """Generic serial relay controller configured through command maps."""

    def __init__(self, resource_name: str, cfg: ResourceConfig, log_path: Path | None = None):
        if not isinstance(cfg.driver, ResourceDriverUsbRelaySerialCommandMap):
            raise RuntimeError("CommandMapSerialRelayPowerController requires ResourceDriverUsbRelaySerialCommandMap")
        super().__init__(resource_name=resource_name, cfg=cfg, protocol=CommandMapRelayProtocol(cfg.driver), log_path=log_path)


class PowerManager:
    def __init__(self, controller: PowerController, outlets: dict[str, Any]):
        self._controller = controller
        self._outlets = outlets

    def start(self) -> None:
        self._controller.start()

    def stop(self) -> None:
        self._controller.stop()

    def outlet_names(self) -> list[str]:
        return sorted(self._outlets.keys())

    def _require_outlet(self, outlet: str) -> None:
        if outlet not in self._outlets:
            known = ", ".join(sorted(self._outlets.keys())) or "<none>"
            raise RuntimeError(f"Unknown power outlet '{outlet}'. Known outlets: {known}")

    def set_state(self, outlet: str, state: bool) -> None:
        self._require_outlet(outlet)
        self._controller.set_state(outlet, state)

    def get_state(self, outlet: str) -> bool | None:
        self._require_outlet(outlet)
        return self._controller.get_state(outlet)

    def expect_state(self, outlet: str, expected: bool) -> bool:
        observed = self.get_state(outlet)
        if observed is None:
            raise RuntimeError(
                f"Power outlet '{outlet}' does not support state readback. "
                "Use a backend with get_state support or remove the power_expect step."
            )
        if observed != expected:
            raise RuntimeError(f"Power outlet '{outlet}' expected state {expected}, observed {observed}.")
        return observed

    def cycle(self, outlet: str, off_ms: int, on_settle_ms: int) -> None:
        self._require_outlet(outlet)
        self._controller.cycle(outlet, off_ms, on_settle_ms)


def create_power_manager(bench: BenchConfig, resource_name: str, log_path: Path | None = None) -> PowerManager:
    cfg = bench.resources.get(resource_name)
    if cfg is None:
        known = ", ".join(sorted(bench.resources.keys())) or "<none>"
        raise RuntimeError(f"Unknown bench resource '{resource_name}'. Known resources: {known}")

    driver = cfg.driver

    if isinstance(driver, ResourceDriverMockPower):
        return PowerManager(controller=MockPowerController(resource_name, cfg, log_path), outlets=dict(driver.outlets))

    if isinstance(driver, ResourceDriverGpioPower):
        return PowerManager(controller=GpioPowerController(resource_name, cfg, log_path), outlets=dict(driver.outlets))

    if isinstance(driver, ResourceDriverHttpRelay):
        return PowerManager(controller=HttpRelayPowerController(resource_name, cfg, log_path), outlets=dict(driver.outlets))

    if isinstance(driver, ResourceDriverUsbRelaySerialCommandMap):
        return PowerManager(controller=CommandMapSerialRelayPowerController(resource_name, cfg, log_path), outlets=dict(driver.outlets))

    raise RuntimeError(
        f"Resource '{resource_name}' is not a supported power controller driver. "
        "Supported power driver types are mock_power, gpio_power, http_relay, and usb_relay_serial."
    )
