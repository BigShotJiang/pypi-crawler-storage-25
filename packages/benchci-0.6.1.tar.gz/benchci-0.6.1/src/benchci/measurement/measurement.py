from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib import request as urlrequest

from benchci.config.bench import (
    BenchConfig,
    ResourceConfig,
    ResourceDriverHttpMeasurement,
    ResourceDriverMockMeasurement,
)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


class _LogMixin:
    _log_path: Path | None

    def _log(self, message: str) -> None:
        if self._log_path is None:
            return
        self._log_path.parent.mkdir(parents=True, exist_ok=True)
        with self._log_path.open("a", encoding="utf-8") as f:
            f.write(f"{_utc_now()} {message}\n")


class MeasurementController:
    """Abstract bench-level measurement controller.

    Suite files ask BenchCI to measure a named resource. Concrete controllers
    hide whether the value comes from a mock, HTTP lab controller, SCPI supply,
    USB meter, oscilloscope, or another vendor-specific instrument.
    """

    def start(self) -> None:
        pass

    def stop(self) -> None:
        pass

    def measure(self) -> dict[str, Any]:
        raise NotImplementedError


class MockMeasurementController(_LogMixin, MeasurementController):
    """Deterministic measurement backend for tests, demos, and CI dry-runs."""

    def __init__(self, resource_name: str, cfg: ResourceConfig, log_path: Path | None = None):
        if not isinstance(cfg.driver, ResourceDriverMockMeasurement):
            raise RuntimeError("MockMeasurementController requires ResourceDriverMockMeasurement")
        self._resource_name = resource_name
        self._driver = cfg.driver
        self._log_path = log_path

    def start(self) -> None:
        self._log(
            f"MOCK_MEASUREMENT_START resource={self._resource_name} "
            f"value={self._driver.value} unit={self._driver.unit}"
        )

    def stop(self) -> None:
        self._log(f"MOCK_MEASUREMENT_STOP resource={self._resource_name}")

    def measure(self) -> dict[str, Any]:
        payload = {
            "resource": self._resource_name,
            "value": float(self._driver.value),
            "unit": self._driver.unit,
            "quantity": self._driver.quantity,
            "timestamp": _utc_now(),
            "backend": self._driver.type,
        }
        self._log(f"MOCK_MEASURE payload={json.dumps(payload, sort_keys=True)}")
        return payload


class HttpMeasurementController(_LogMixin, MeasurementController):
    """Measurement backend for simple HTTP lab controllers.

    The endpoint may return a plain number, or JSON such as:
      {"value": 0.042, "unit": "A"}
    """

    def __init__(self, resource_name: str, cfg: ResourceConfig, log_path: Path | None = None):
        if not isinstance(cfg.driver, ResourceDriverHttpMeasurement):
            raise RuntimeError("HttpMeasurementController requires ResourceDriverHttpMeasurement")
        self._resource_name = resource_name
        self._driver = cfg.driver
        self._log_path = log_path

    def _request(self) -> str:
        req = urlrequest.Request(self._driver.url, method="GET")
        for key, value in self._driver.headers.items():
            req.add_header(key, value)
        self._log(f"HTTP_MEASURE_TX resource={self._resource_name} url={self._driver.url}")
        try:
            with urlrequest.urlopen(req, timeout=self._driver.timeout_ms / 1000.0) as resp:
                body = resp.read(4096).decode("utf-8", errors="replace")
                self._log(f"HTTP_MEASURE_RX status={getattr(resp, 'status', None)} body={body[:200]!r}")
                return body
        except Exception:
            raise RuntimeError("HTTP measurement request failed.")

    def _extract_value(self, body: str) -> tuple[float, str | None]:
        text = body.strip()
        try:
            parsed = json.loads(text)
        except Exception:
            return float(text), None

        if isinstance(parsed, (int, float)):
            return float(parsed), None

        if isinstance(parsed, dict):
            raw_value = parsed.get(self._driver.value_field)
            raw_unit = parsed.get(self._driver.unit_field) if self._driver.unit_field else None
            if raw_value is None:
                raise RuntimeError(
                    f"HTTP measurement response did not contain value field '{self._driver.value_field}'."
                )
            return float(raw_value), str(raw_unit) if raw_unit is not None else None

        raise RuntimeError("HTTP measurement response must be a number or JSON object.")

    def measure(self) -> dict[str, Any]:
        value, observed_unit = self._extract_value(self._request())
        payload = {
            "resource": self._resource_name,
            "value": value,
            "unit": observed_unit or self._driver.unit,
            "quantity": self._driver.quantity,
            "timestamp": _utc_now(),
            "backend": self._driver.type,
        }
        self._log(f"HTTP_MEASURE payload={json.dumps(payload, sort_keys=True)}")
        return payload


class MeasurementManager:
    def __init__(self, controller: MeasurementController):
        self._controller = controller

    def start(self) -> None:
        self._controller.start()

    def stop(self) -> None:
        self._controller.stop()

    def measure(self) -> dict[str, Any]:
        return self._controller.measure()


def create_measurement_manager(bench: BenchConfig, resource_name: str, log_path: Path | None = None) -> MeasurementManager:
    cfg = bench.resources.get(resource_name)
    if cfg is None:
        known = ", ".join(sorted(bench.resources.keys())) or "<none>"
        raise RuntimeError(f"Unknown bench resource '{resource_name}'. Known resources: {known}")

    driver = cfg.driver
    if isinstance(driver, ResourceDriverMockMeasurement):
        return MeasurementManager(MockMeasurementController(resource_name, cfg, log_path))
    if isinstance(driver, ResourceDriverHttpMeasurement):
        return MeasurementManager(HttpMeasurementController(resource_name, cfg, log_path))

    raise RuntimeError(
        f"Resource '{resource_name}' is not a supported measurement driver. "
        "Supported measurement driver types are mock_measurement and http_measurement."
    )
