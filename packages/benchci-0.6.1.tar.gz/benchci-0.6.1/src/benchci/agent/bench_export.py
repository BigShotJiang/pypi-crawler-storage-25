from __future__ import annotations

from pathlib import Path
import re

from benchci.config.bench import BenchConfig, load_bench_config


def _slugify(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    value = value.strip("-")
    return value or "bench"


def bench_to_cloud_summary(
    bench_cfg: BenchConfig,
    *,
    bench_id: str | None = None,
    tags: list[str] | None = None,
    status: str = "idle",
    current_run_id: str | None = None,
) -> dict:
    transports: set[str] = set()
    flash_backends: set[str] = set()
    has_gpio = False
    power_backends: set[str] = set()
    measurement_backends: set[str] = set()

    for node_cfg in bench_cfg.nodes.values():
        for transport_cfg in node_cfg.transports.values():
            transports.add(transport_cfg.backend)

        if node_cfg.flash is not None:
            flash_backends.add(node_cfg.flash.backend)

        if node_cfg.gpio:
            has_gpio = True

    for resource_cfg in getattr(bench_cfg, "resources", {}).values():
        driver = getattr(resource_cfg, "driver", None)
        driver_type = str(getattr(driver, "type", "") or "")
        kind = str(getattr(resource_cfg, "kind", "") or "")
        if kind == "measurement" or driver_type in {"mock_measurement", "http_measurement"}:
            if driver_type:
                measurement_backends.add(driver_type)
        elif kind == "power_controller" or driver_type in {"mock_power", "gpio_power", "http_relay", "usb_relay_serial"}:
            if driver_type:
                power_backends.add(driver_type)

    has_power = bool(power_backends)
    has_measurements = bool(measurement_backends)

    resolved_tags = [t.strip() for t in (tags or []) if t and t.strip()]
    if not resolved_tags:
        node_tags: set[str] = set()
        for node_cfg in bench_cfg.nodes.values():
            for tag in node_cfg.tags:
                if tag and tag.strip():
                    node_tags.add(tag.strip())
        resolved_tags = sorted(node_tags)

    return {
        "bench_id": bench_id or _slugify(bench_cfg.bench.name),
        "name": bench_cfg.bench.name,
        "description": bench_cfg.bench.description,
        "tags": resolved_tags,
        "status": "busy" if status == "busy" else "idle",
        "current_run_id": current_run_id,
        "capabilities": {
            "transports": sorted(transports),
            "flash_backends": sorted(flash_backends),
            "has_gpio": has_gpio,
            "has_power": has_power,
            "has_measurements": has_measurements,
            "power_backends": sorted(power_backends),
            "measurement_backends": sorted(measurement_backends),
            "node_count": len(bench_cfg.nodes),
        },
        "node_names": sorted(bench_cfg.nodes.keys()),
    }


def load_bench_for_cloud(
    path: str | Path,
    *,
    bench_id: str | None = None,
    tags: list[str] | None = None,
    status: str = "idle",
    current_run_id: str | None = None,
) -> dict:
    bench_cfg = load_bench_config(path)
    return bench_to_cloud_summary(
        bench_cfg,
        bench_id=bench_id,
        tags=tags,
        status=status,
        current_run_id=current_run_id,
    )
