"""
Shared API handler functions for the admin dashboard.

Pure functions that take a Runtime and return a dict (or list).
handle_approval_resolve returns a (status_code, body_dict) tuple.
Used by both:
  - WebServer (FastAPI endpoints in server.py)
  - CloudChannel admin relay (_handle_admin_endpoint in cloud.py)
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING, Any

from workpilot import __version__
from workpilot.config.schema import ChannelType

if TYPE_CHECKING:
    from workpilot.agent.tools.base import Tool
    from workpilot.runtime import Runtime


def _score_to_tier(score: int) -> dict[str, Any]:
    """Map a risk score to display info."""
    if score <= 2:
        tier = "safe"
    elif score <= 4:
        tier = "moderate"
    elif score <= 6:
        tier = "elevated"
    elif score <= 8:
        tier = "high"
    else:
        tier = "critical"
    return {"mode": "fixed", "base_score": score, "tier": tier}


def _tool_risk_info(tool: Tool) -> dict[str, Any]:
    """Get a tool's risk display info from ``risk_range``.

    Range span ≤ 1 → treat as fixed (show single score).
    Range span > 1 → dynamic (show range).
    """
    try:
        lo, hi = tool.risk_range
    except (TypeError, ValueError):
        lo, hi = 0, 10
    if hi - lo <= 1:
        score = (lo + hi) // 2 if lo != hi else lo
        info = _score_to_tier(score)
        info["range"] = [lo, hi]
        return info
    return {"mode": "dynamic", "base_score": None, "tier": "dynamic", "range": [lo, hi]}


def _skills_summary(rt: Runtime) -> dict[str, int]:
    """Skills count for the status endpoint."""
    loader = getattr(rt, "skill_loader", None)
    if not loader:
        return {"count": 0, "active": 0}
    registry = getattr(rt, "tool_registry", None)
    skills = loader.list_loaded()
    active = sum(
        1
        for s in skills
        if s.is_platform_eligible()
        and not s.is_superseded(registry)
        and not s.disable_model_invocation
        and not s.check_requirements(registry)
    )
    return {"count": len(skills), "active": active}


def handle_status(
    rt: Runtime,
    *,
    uptime_seconds: int | None = None,
    started_at: str | None = None,
    channels: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """GET /api/status — comprehensive runtime snapshot.

    Optional kwargs are added by the local web server which tracks
    uptime and channel state; the cloud relay omits them.
    """
    tools = rt.tool_registry.list_tools()
    by_tier: dict[str, int] = {
        "safe": 0,
        "moderate": 0,
        "elevated": 0,
        "high": 0,
        "critical": 0,
        "dynamic": 0,
    }
    for t in tools:
        by_tier[_tool_risk_info(t)["tier"]] += 1

    try:
        session_count = len(rt.session_manager.list_sessions())
    except Exception:
        session_count = 0

    sched_health = rt.scheduler.health() if rt.scheduler else {}

    result: dict[str, Any] = {
        "version": __version__,
        "status": "halted" if rt.estop.is_halted else "ok",
        "estop": rt.estop.status(),
        "bus": {
            "inbound_qsize": rt.bus.inbound_qsize,
            "outbound_qsize": rt.bus.outbound_qsize,
        },
        "provider": {"model": rt.config.agents.default.model},
        "sessions": {"count": session_count},
        "tools": {"count": len(tools), "by_tier": by_tier},
        "skills": _skills_summary(rt),
        "scheduler": {
            "enabled": sched_health.get("running", False),
            "job_count": sched_health.get("total_jobs", 0),
            "active_jobs": sched_health.get("active_jobs", 0),
        },
        "workspace": str(rt.workspace),
        "agent": {
            "name": rt.config.agents.default.name,
            "max_iterations": rt.config.agents.default.max_iterations,
        },
        "security": {
            "profile": rt.config.security.profile.value,
            "audit_enabled": rt.config.security.audit.enabled,
            "audit_redact": rt.config.security.audit.redact_secrets,
            "estop_on_leak": rt.config.security.estop.trigger_on_leak,
            "require_auth": rt.config.security.require_auth,
        },
    }
    if uptime_seconds is not None:
        result["uptime_seconds"] = uptime_seconds
    if started_at is not None:
        result["started_at"] = started_at
    if channels is not None:
        result["channels"] = channels
    return result


def handle_health(rt: Runtime) -> dict[str, Any]:
    """GET /api/health — basic health with E-stop and bus state."""
    return {
        "status": "halted" if rt.estop.is_halted else "ok",
        "version": __version__,
        "estop": rt.estop.status(),
        "bus": {
            "inbound_qsize": rt.bus.inbound_qsize,
            "outbound_qsize": rt.bus.outbound_qsize,
        },
    }


def handle_models(rt: Runtime) -> dict[str, Any]:
    """GET /api/models — list all configured models with context window and input token limits."""
    from workpilot.providers.model_catalog import get_context_window, get_max_input_tokens
    from workpilot.providers.resolver import resolve_model_chain

    providers = rt.config.providers
    agents_cfg = rt.config.agents

    def _chain_with_limits(chain: list[str]) -> list[dict[str, Any]]:
        return [
            {
                "model": m,
                "context_window": get_context_window(m),
                "max_input_tokens": get_max_input_tokens(m),
            }
            for m in chain
        ]

    # Collect all agent models (builtin + user-defined)
    agents: dict[str, Any] = {}
    all_agents = dict(getattr(rt, "_all_agents", {}))
    if "default" not in all_agents:
        all_agents["default"] = agents_cfg.default
    for name, cfg in all_agents.items():
        model = cfg.model
        chain = resolve_model_chain(model, providers)
        entry: dict[str, Any] = {
            "alias": model,
            "chain": _chain_with_limits(chain),
        }
        if cfg.metadata.get("internal"):
            entry["internal"] = True
        agents[name] = entry

    # Collect alias mappings
    aliases: dict[str, Any] = {}
    for alias in ("auto", "fast", "reasoning", "coding"):
        chain = resolve_model_chain(alias, providers)
        aliases[alias] = {"chain": _chain_with_limits(chain)}

    return {"agents": agents, "aliases": aliases}


def handle_sessions(rt: Runtime) -> list[dict[str, Any]]:
    """GET /api/sessions — list all sessions."""
    return rt.session_manager.list_sessions()


def _normalize_content(msg: dict[str, Any]) -> dict[str, Any]:
    """Normalize native Responses API items to Chat-like format for web display.

    - ``content: [{type: "output_text", text}]`` → plain string
    - ``function_call_output`` → ``{role: "tool", content: output, tool_call_id: call_id}``
    - ``function_call`` → ``{role: "assistant", tool_calls: [{id, function}]}``
    """
    item_type = msg.get("type", "")

    if item_type == "function_call_output":
        output = msg.get("output", "")
        if not isinstance(output, str):
            output = json.dumps(output, ensure_ascii=False)
        call_id = msg.get("call_id") or ""
        return {**msg, "role": "tool", "content": output, "tool_call_id": call_id}

    if item_type == "function_call":
        call_id = msg.get("call_id") or msg.get("id") or ""
        name = msg.get("name", "?")
        arguments = msg.get("arguments", "{}")
        return {
            **msg,
            "role": "assistant",
            "content": "",
            "tool_calls": [
                {
                    "id": call_id,
                    "function": {"name": name, "arguments": arguments},
                }
            ],
        }

    content = msg.get("content")
    if isinstance(content, list):
        text = "".join(
            p.get("text", "") or p.get("refusal", "") for p in content if isinstance(p, dict)
        )
        return {**msg, "content": text}
    return msg


def handle_session_detail(rt: Runtime, session_id: str) -> dict[str, Any] | None:
    """GET /api/sessions/{id} — session messages. Returns None if not found."""
    messages = rt.session_manager.get_messages(session_id)
    if not messages:
        return None
    return {
        "session_id": session_id,
        "messages": [_normalize_content(m) for m in messages],
    }


def handle_session_recent(
    rt: Runtime,
    channel: ChannelType | str = "web",
    sender_id: str = "ws-user",
    limit: int = 10,
) -> list[dict[str, Any]]:
    """GET /api/session/recent — last N visible messages for a channel/sender.

    Returns user, assistant, and approval_request turns (tool messages excluded).
    """
    session_id = rt.session_manager.get_or_create_id(ChannelType.of(channel), sender_id)
    messages = rt.session_manager.get_messages(session_id)
    visible = [
        m
        for m in messages
        if m.get("role") in ("user", "assistant", "approval_request", "approval_resolved")
    ]
    return [_normalize_content(m) for m in visible[-limit:]]


def handle_skills(rt: Runtime) -> list[dict[str, Any]]:
    """GET /api/skills — list all loaded skills with eligibility status."""
    loader = getattr(rt, "skill_loader", None)
    if not loader:
        return []

    registry = getattr(rt, "tool_registry", None)
    result: list[dict[str, Any]] = []
    for s in loader.list_loaded():
        # Compute status — cheap checks first, expensive last
        missing: list[str] = []
        if not s.is_platform_eligible():
            status = "platform-ineligible"
        elif s.is_superseded(registry):
            status = "superseded"
        elif s.disable_model_invocation:
            status = "disabled"
        else:
            missing = s.check_requirements(registry)
            status = "ineligible" if missing else "active"

        result.append(
            {
                "name": s.name,
                "description": s.description,
                "mode": s.mode,
                "source_tier": s.source_tier,
                "source_path": s.source_path,
                "status": status,
                "keywords": s.keywords,
                "missing_requirements": missing,
                "superseded_by": s.superseded_by_tools,
                "os_filter": s.os_filter,
            }
        )
    return result


def handle_tools(rt: Runtime) -> list[dict[str, Any]]:
    """GET /api/tools — list all registered tools and MCP servers with status."""
    active_names = {t.name for t in rt.tool_registry.get_active_tools()}
    result: list[dict[str, Any]] = []

    for t in rt.tool_registry.list_tools_sorted():
        category = t.metadata.category if t.metadata else "builtin"
        is_mcp_tool = category == "mcp"
        ri = _tool_risk_info(t)
        result.append(
            {
                "name": t.name,
                "description": t.description,
                "tier": "mcp" if is_mcp_tool else (t.metadata.tier if t.metadata else "core"),
                "active": t.name in active_names,
                "type": "mcp_tool" if is_mcp_tool else "builtin",
                "risk_mode": ri["mode"],
                "risk_score": ri["base_score"],
                "risk_tier": ri["tier"],
                "risk_range": ri.get("range"),
            }
        )

    # MCP servers (connection-level entries)
    mcp_mgr = getattr(rt, "_mcp_manager", None)
    risk_policy = rt.config.tools.mcp_risk_policy or {}
    if mcp_mgr:
        for s in mcp_mgr.list_servers():
            if not s.enabled:
                continue
            # Resolve server-level risk from policy.
            # If server has per-tool overrides or _rules, risk varies per tool → dynamic.
            server_policy = risk_policy.get(s.name, {})
            has_per_tool = False
            default_risk = None
            if isinstance(server_policy, dict):
                has_per_tool = any(k for k in server_policy if not k.startswith("_")) or bool(
                    server_policy.get("_rules")
                )
                default_risk = server_policy.get("_default_risk")
            else:
                default_risk = server_policy  # bare int or str
            if default_risk is None:
                default_risk = risk_policy.get("_default_risk")
            if has_per_tool:
                # Compute range from all configured int values
                scores: list[int] = []
                if isinstance(server_policy, dict):
                    for k, v in server_policy.items():
                        if not k.startswith("_") and isinstance(v, int):
                            scores.append(v)
                    if isinstance(default_risk, int):
                        scores.append(default_risk)
                if scores and max(scores) - min(scores) <= 1:
                    # Narrow range — treat as fixed
                    score = (min(scores) + max(scores)) // 2
                    ri = _score_to_tier(score)
                    ri["range"] = [min(scores), max(scores)]
                elif scores:
                    ri = {
                        "mode": "dynamic",
                        "base_score": None,
                        "tier": "dynamic",
                        "range": [min(scores), max(scores)],
                    }
                else:
                    ri = {
                        "mode": "dynamic",
                        "base_score": None,
                        "tier": "dynamic",
                        "range": [0, 10],
                    }
            elif isinstance(default_risk, int):
                ri = _score_to_tier(default_risk)
                ri["range"] = [default_risk, default_risk]
            else:
                ri = {"mode": "dynamic", "base_score": None, "tier": "dynamic", "range": [0, 10]}
            result.append(
                {
                    "name": f"MCP_{s.name}",
                    "description": s.description or "",
                    "tier": "mcp",
                    "active": s.state.value == "connected",
                    "type": "mcp_server",
                    "state": s.state.value,
                    "tool_count": s.tool_count,
                    "risk_mode": ri["mode"],
                    "risk_score": ri["base_score"],
                    "risk_tier": ri["tier"],
                    "risk_range": ri.get("range"),
                }
            )

    return result


def handle_memory(rt: Runtime) -> dict[str, Any]:
    """GET /api/memory — MEMORY.md content + knowledge store entries."""
    result: dict[str, Any] = {"memory_md": "", "knowledge": []}

    mem = getattr(rt, "_memory", None)
    if mem:
        try:
            result["memory_md"] = mem.read_memory() or ""
        except Exception:
            result["memory_md"] = "(error reading MEMORY.md)"
    else:
        memory_path = Path.home() / ".workpilot" / "MEMORY.md"
        if memory_path.exists():
            try:
                result["memory_md"] = memory_path.read_text(encoding="utf-8")
            except Exception:
                result["memory_md"] = "(error reading MEMORY.md)"

    try:
        if mem and hasattr(mem, "history"):
            entries = mem.history.list_recent(top_k=50)
            result["knowledge"] = [
                {
                    "id": e.get("id"),
                    "content": e.get("content", ""),
                    "category": e.get("category", ""),
                    "source": e.get("source", ""),
                    "created_at": e.get("created_at", ""),
                }
                for e in entries
            ]
    except Exception:
        pass

    return result


def handle_audit(rt: Runtime) -> dict[str, Any]:
    """GET /api/audit — recent audit log entries (last 200, newest first)."""
    return {"entries": rt.audit.recent_entries(200)}


def handle_cost(rt: Runtime) -> dict[str, Any]:
    """GET /api/cost — token usage stats."""
    return rt.usage_tracker.stats()


def handle_config(rt: Runtime) -> dict[str, Any] | None:
    """GET /api/config — read-only config snapshot. Returns None on error."""
    try:
        config_dict = rt.config.model_dump(mode="json")
        _redact_secrets(config_dict)
        return config_dict
    except Exception:
        return None


def handle_approvals(rt: Runtime) -> dict[str, Any]:
    """GET /api/approvals — pending + recently resolved approval queue."""
    pending: list[dict[str, Any]] = []
    resolved: list[dict[str, Any]] = []
    if hasattr(rt, "approval_manager") and rt.approval_manager:
        mgr = rt.approval_manager
        try:
            for req in mgr.get_pending():
                pending.append(
                    {
                        "id": req.id,
                        "tool_name": req.tool_name,
                        "args": req.args,
                        "agent_name": req.agent_name,
                        "score": req.score,
                        "reason": req.reason,
                        "status": req.status.value if hasattr(req.status, "value") else req.status,
                        "created_at": req.created_at.isoformat() if req.created_at else None,
                    }
                )
        except (AttributeError, Exception):
            pass
        # Include recently resolved requests (kept for 60s in _resolved)
        try:
            for req in mgr._resolved.values():
                resolved.append(
                    {
                        "id": req.id,
                        "tool_name": req.tool_name,
                        "status": req.status.value if hasattr(req.status, "value") else req.status,
                        "resolver": req.resolver,
                        "resolved_at": req.resolved_at.isoformat() if req.resolved_at else None,
                    }
                )
        except (AttributeError, Exception):
            pass
    return {"pending": pending, "resolved": resolved}


def handle_estop(rt: Runtime, reason: str = "admin dashboard") -> dict[str, Any]:
    """POST /api/estop — trigger emergency stop."""
    rt.estop.trigger(reason, actor="admin")
    return rt.estop.status()


def handle_reset(rt: Runtime, actor: str = "admin") -> dict[str, Any]:
    """POST /api/reset — reset emergency stop."""
    rt.estop.reset(actor=actor)
    return rt.estop.status()


def handle_approval_resolve(
    rt: Runtime,
    request_id: str,
    approved: bool,
    resolver: str = "admin",
    always: bool = False,
) -> tuple[int, dict[str, Any]]:
    """POST /api/approvals/{id}/resolve — returns (status_code, body)."""
    if not hasattr(rt, "approval_manager") or not rt.approval_manager:
        return 503, {"error": "Approval manager not available."}
    try:
        req = rt.approval_manager.get_request(request_id)
        _action = "always" if (always and approved) else ("approve" if approved else "deny")
        rt.approval_manager.resolve(
            request_id, approved=approved, resolver=resolver, action=_action
        )
        allowlist = getattr(rt, "_allowlist", None)
        if always and approved and req and allowlist:
            allowlist.add(
                req.tool_name, req.args, added_by=resolver, note="Added via web UI 'Always Allow'"
            )

        # Persist resolution to session history directly
        # (Don't emit APPROVAL_RESOLVED — that handler also calls
        # approval_manager.resolve() which would fail with "already resolved")
        import json as _json

        status = "approved" if approved else "denied"
        for sid, msgs in rt.session_manager._sessions.items():
            for m in msgs:
                if m.get("role") != "approval_request":
                    continue
                try:
                    data = _json.loads(m.get("content", "{}"))
                except Exception:  # noqa: S112
                    continue
                if data.get("request_id") != request_id:
                    continue
                rt.session_manager.add_message(
                    sid,
                    {
                        "role": "approval_resolved",
                        "content": _json.dumps(
                            {
                                "request_id": request_id,
                                "status": status,
                                "resolver": resolver,
                            }
                        ),
                    },
                )
                break  # unique request_id

        return 200, {"status": "resolved", "approved": approved, "always": always}
    except KeyError:
        # resolve() raises KeyError when request_id not in _pending — but it
        # may exist in _resolved.  Return 409 (not 404) for already-resolved.
        if req and req.status.value != "pending":
            return 409, {
                "error": f"Approval request already resolved as {req.status.value}: {request_id}",
                "request_id": request_id,
                "resolved_status": req.status.value,
            }
        return 404, {
            "error": f"Approval request not found: {request_id}",
            "request_id": request_id,
        }
    except ValueError:
        status = req.status.value if req else "unknown"
        return 409, {
            "error": f"Approval request already resolved as {status}: {request_id}",
            "request_id": request_id,
            "resolved_status": status,
        }
    except Exception as exc:
        return 500, {"error": f"Internal error: {type(exc).__name__}"}


def handle_system_prompts(rt: Runtime) -> dict[str, Any]:
    """GET /api/system-prompts — return the assembled system prompt and its individual sections.

    Uses the runtime's ContextBuilder for the full prompt, and reads the
    individual identity files via the same resolution logic as ContextBuilder:

    - ``_load_identity_or_builtin``: config path (if file exists) →
      ``~/.workpilot/<name>`` override → bundled default.
    - ``USER.md``: only included if a real file exists (no bundled fallback).
    - ``TOOLS.md``: wrapped with ``## Guidelines`` header when not markdown.
    - ``MEMORY.md``: prefixed with section headers and capped at 8 KB.
    """
    from workpilot.agent.compaction import count_tokens
    from workpilot.agent.context import MEMORY_CAP
    from workpilot.utils.defaults import load_default

    sections: list[dict[str, Any]] = []
    errors: list[str] = []

    # Prefer the active AgentLoop's config/workspace so sections match the
    # same agent used to build the full prompt (entrypoint may not be "default").
    agent = getattr(rt, "agent", None)
    agent_cfg = getattr(agent, "_config", None) if agent is not None else None
    if agent_cfg is None:
        agent_cfg = rt.config.agents.default
    workspace = getattr(agent, "_workspace", None) if agent is not None else None
    if workspace is None:
        workspace = rt.workspace

    def _resolve_and_read(config_path: str | None, default_name: str) -> str:
        """Resolve an identity file using the same precedence as ContextBuilder.

        config path → load_default (checks ~/.workpilot/ then bundled).
        When no config path: ~/.workpilot/<name> → bundled default.
        """
        if config_path:
            p = Path(config_path).expanduser()
            if not p.is_absolute():
                p = workspace / p
            if p.is_file():
                return p.read_text(encoding="utf-8").strip()
            # Config path set but file missing — fall through to load_default
            # which checks ~/.workpilot/ then bundled (same as ContextBuilder).
            return load_default(default_name)
        candidate = Path.home() / ".workpilot" / default_name
        if candidate.is_file():
            return candidate.read_text(encoding="utf-8").strip()
        return load_default(default_name)

    def _section(name: str, content: str) -> dict[str, Any]:
        return {
            "name": name,
            "content": content,
            "tokens": count_tokens(content),
            "bytes": len(content.encode("utf-8")),
        }

    # 1. SOUL.md
    soul = _resolve_and_read(agent_cfg.soul_file, "SOUL.md")
    if soul:
        sections.append(_section("SOUL.md", soul))

    # 2. Config instructions
    if agent_cfg.instructions:
        sections.append(_section("Config Instructions", agent_cfg.instructions))

    # 3. AGENTS.md
    agents = _resolve_and_read(agent_cfg.agents_file, "AGENTS.md")
    if agents:
        sections.append(_section("AGENTS.md", agents))

    # 4. TOOLS.md — match ContextBuilder._load_tools_md() wrapping
    tools_content = load_default("TOOLS.md", allow_empty_override=True)
    if tools_content:
        if not tools_content.lstrip().startswith("#"):
            tools_content = f"## Guidelines\n\n{tools_content}"
        sections.append(_section("TOOLS.md", tools_content))

    # 5. USER.md — only include if a real file exists (no bundled fallback)
    user_path: Path | None = None
    if agent_cfg.user_file:
        p = Path(agent_cfg.user_file).expanduser()
        if not p.is_absolute():
            p = workspace / p
        if p.is_file():
            user_path = p
    else:
        candidate = Path.home() / ".workpilot" / "USER.md"
        if candidate.is_file():
            user_path = candidate
    if user_path is not None:
        user_content = user_path.read_text(encoding="utf-8").strip()
        if user_content:
            sections.append(_section("USER.md", user_content))

    # 6. MEMORY.md — add headers and cap at 8 KB to match ContextBuilder
    mem = getattr(rt, "_memory", None)
    if mem:
        try:
            shared = mem.read_shared("MEMORY.md").strip()
            if shared:
                sections.append(
                    _section("MEMORY.md (Shared)", f"## Shared Memory\n\n{shared[:MEMORY_CAP]}")
                )
        except Exception:
            errors.append("Error reading shared MEMORY.md")
        try:
            personal = mem.read_memory().strip()
            if personal:
                sections.append(
                    _section("MEMORY.md (Personal)", f"## Memory\n\n{personal[:MEMORY_CAP]}")
                )
        except Exception:
            errors.append("Error reading personal MEMORY.md")
    else:
        memory_path = Path.home() / ".workpilot" / "MEMORY.md"
        if memory_path.is_file():
            try:
                mc = memory_path.read_text(encoding="utf-8").strip()
                if mc:
                    sections.append(_section("MEMORY.md", mc[:MEMORY_CAP]))
            except Exception:
                errors.append("Error reading MEMORY.md")

    # Build the full assembled system prompt from the agent loop's ContextBuilder
    full_prompt = ""
    ctx = getattr(agent, "_context", None) if agent is not None else None
    if ctx:
        try:
            full_prompt = ctx.build_system_prompt(mode="full")
        except Exception as exc:
            errors.append(f"Error building system prompt: {type(exc).__name__}")
            full_prompt = ""

    result: dict[str, Any] = {
        "sections": sections,
        "full_prompt": full_prompt,
        "full_prompt_length": len(full_prompt.encode("utf-8")),
        "full_prompt_tokens": count_tokens(full_prompt),
    }
    if errors:
        result["errors"] = errors
    return result


# ── Helpers ──────────────────────────────────────────────────────────────────


def _redact_secrets(d: dict[str, Any], _secret_keys: set[str] | None = None) -> None:
    """Recursively redact values for keys that look like secrets."""
    if _secret_keys is None:
        _secret_keys = {
            "api_key",
            "secret",
            "token",
            "password",
            "client_secret",
            "connection_string",
        }
    for key in list(d.keys()):
        if isinstance(d[key], dict):
            _redact_secrets(d[key], _secret_keys)
        elif isinstance(d[key], str) and any(s in key.lower() for s in _secret_keys):
            if d[key]:
                d[key] = "***REDACTED***"
