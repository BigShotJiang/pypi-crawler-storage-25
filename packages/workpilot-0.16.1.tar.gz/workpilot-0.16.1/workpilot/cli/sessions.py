"""Sessions CLI subcommands — workpilot sessions list|show|delete|export."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

import typer
from rich.table import Table

from workpilot.cli.commands import (
    console,
    sessions_app,
)


@sessions_app.command("list")
def sessions_list(
    archive: bool = typer.Option(False, "--archive", "-a", help="Include archived sessions"),
) -> None:
    """List all saved sessions."""
    from workpilot.utils.helpers import get_sessions_dir

    sessions_dir = get_sessions_dir()
    # Skip date-suffixed split archives (e.g. cli_local_2026-03-14.jsonl)
    import re as _re

    session_files = sorted(
        p for p in sessions_dir.glob("*.jsonl") if not _re.search(r"_\d{4}-\d{2}-\d{2}$", p.stem)
    )
    if archive:
        archive_dir = sessions_dir / "archive"
        if archive_dir.exists():
            session_files.extend(sorted(archive_dir.glob("*.jsonl")))

    if not session_files:
        console.print("[dim]No sessions found.[/dim]")
        return

    table = Table(title="Sessions")
    table.add_column("Session ID", style="bold")
    table.add_column("Size")
    table.add_column("Messages")
    table.add_column("Modified")
    if archive:
        table.add_column("Status")

    for path in session_files:
        session_id = path.stem
        size_bytes = path.stat().st_size
        mod_time = datetime.fromtimestamp(path.stat().st_mtime, tz=UTC)
        mod_str = mod_time.strftime("%Y-%m-%d %H:%M:%S UTC")

        # Count lines (each line = one message)
        try:
            line_count = sum(
                1 for line in path.read_text(encoding="utf-8").splitlines() if line.strip()
            )
        except Exception:
            line_count = 0

        if size_bytes < 1024:
            size_str = f"{size_bytes} B"
        elif size_bytes < 1024 * 1024:
            size_str = f"{size_bytes / 1024:.1f} KB"
        else:
            size_str = f"{size_bytes / (1024 * 1024):.1f} MB"

        if archive:
            status = "archived" if path.parent.name == "archive" else "active"
            table.add_row(session_id, size_str, str(line_count), mod_str, status)
        else:
            table.add_row(session_id, size_str, str(line_count), mod_str)

    console.print(table)


@sessions_app.command("show")
def sessions_show(
    session_id: str = typer.Argument(..., help="Session ID to show"),
    lines: int = typer.Option(20, "--lines", "-n", help="Number of recent messages to show"),
) -> None:
    """Show details for a specific session."""
    import json

    from workpilot.utils.helpers import get_sessions_dir

    sessions_dir = get_sessions_dir()

    # Try direct match, sanitized match, and archive directory
    safe_id = session_id.replace(":", "_").replace("/", "_")
    candidates = [
        sessions_dir / f"{session_id}.jsonl",
        sessions_dir / f"{safe_id}.jsonl",
    ]
    # Also search archive directory (newest first by filename)
    archive_dir = sessions_dir / "archive"
    if archive_dir.exists():
        candidates.extend(sorted(archive_dir.glob(f"{safe_id}_*.jsonl"), reverse=True))

    session_path = None
    for c in candidates:
        if c.exists():
            session_path = c
            break

    if session_path is None:
        console.print(f"[red]Session not found:[/red] {session_id}")
        raise typer.Exit(1)

    messages: list[dict] = []
    for line in session_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            try:
                messages.append(json.loads(line))
            except json.JSONDecodeError:
                continue

    console.print(f"\n[bold]Session:[/bold] {session_path.stem}")
    console.print(f"[bold]Messages:[/bold] {len(messages)}\n")

    # Show last N messages
    tail = messages[-lines:] if len(messages) > lines else messages
    for msg in tail:
        # Display native Responses API items with their type instead of "unknown"
        item_type = msg.get("type", "")
        role = msg.get("role") or item_type or "unknown"
        raw_content = msg.get("content") or msg.get("output", "")
        if isinstance(raw_content, list):
            raw_content = " ".join(p.get("text", "") for p in raw_content if isinstance(p, dict))
        # Escape rich markup and non-printable chars for safe terminal output
        snippet = str(raw_content)[:200].encode("ascii", errors="replace").decode("ascii")
        ts = msg.get("_ts", msg.get("timestamp", ""))

        if role == "user":
            console.print(f"  [cyan]{role}[/cyan] ({ts}): {snippet}")
        elif role == "assistant":
            console.print(f"  [green]{role}[/green] ({ts}): {snippet}")
        else:
            console.print(f"  [dim]{role}[/dim] ({ts}): {snippet}")


@sessions_app.command("delete")
def sessions_delete(
    session_id: str = typer.Argument(..., help="Session ID to delete"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Delete a session and its message history."""
    from workpilot.utils.helpers import get_sessions_dir

    sessions_dir = get_sessions_dir()
    safe_id = session_id.replace(":", "_").replace("/", "_")
    candidates = [
        sessions_dir / f"{session_id}.jsonl",
        sessions_dir / f"{safe_id}.jsonl",
    ]
    # Also check archive directory
    archive_dir = sessions_dir / "archive"
    if archive_dir.exists():
        for p in archive_dir.glob(f"{safe_id}_*.jsonl"):
            candidates.append(p)
    path = next((p for p in candidates if p.exists()), None)
    if path is None:
        console.print(f"[red]Session not found:[/red] {session_id}")
        raise typer.Exit(1)

    if not yes:
        typer.confirm(f"Delete session '{session_id}'?", abort=True)

    from workpilot.session.manager import SessionManager

    mgr = SessionManager(data_dir=sessions_dir)
    mgr.delete(safe_id)
    console.print(f"  [green]\u2713[/green] Deleted session [bold]{session_id}[/bold]")


@sessions_app.command("export")
def sessions_export(
    session_id: str = typer.Argument(..., help="Session ID to export"),
    output: str = typer.Option("", "--output", "-o", help="Output file (default: <id>.md)"),
    fmt: str = typer.Option("md", "--format", "-f", help="Format: md or json"),
) -> None:
    """Export a session to markdown or JSON."""
    import json as _json

    from workpilot.utils.helpers import get_sessions_dir

    sessions_dir = get_sessions_dir()
    safe_id = session_id.replace(":", "_").replace("/", "_")
    candidates = [
        sessions_dir / f"{session_id}.jsonl",
        sessions_dir / f"{safe_id}.jsonl",
    ]
    path = next((p for p in candidates if p.exists()), None)
    if path is None:
        console.print(f"[red]Session not found:[/red] {session_id}")
        raise typer.Exit(1)

    messages = [
        _json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()
    ]

    out_path = Path(output) if output else Path(f"{safe_id}.{fmt}")

    if fmt == "json":
        out_path.write_text(_json.dumps(messages, indent=2, ensure_ascii=False), encoding="utf-8")
    else:
        lines_out = [f"# Session: {session_id}\n"]
        for msg in messages:
            role = msg.get("role", "?")
            content = msg.get("content") or ""
            if isinstance(content, list):
                content = " ".join(p.get("text", "") for p in content if isinstance(p, dict))
            if role == "user":
                lines_out.append(f"**You:** {content}\n")
            elif role == "assistant":
                lines_out.append(f"**WorkPilot:** {content}\n")
        out_path.write_text("\n".join(lines_out), encoding="utf-8")

    console.print(f"  [green]\u2713[/green] Exported to [cyan]{out_path}[/cyan]")
