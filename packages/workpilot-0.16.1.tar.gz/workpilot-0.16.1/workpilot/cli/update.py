"""Update CLI command — workpilot update.

Detects install mode automatically:
  - Git (editable install)  → git pull + pip install -e ".[all]"
  - uv tool install         → uv tool upgrade workpilot
  - PyPI (pip install)      → pip install --upgrade workpilot

uv tool upgrades work on all platforms (including Windows) without
file-lock issues.  The pip path still prints a manual command on Windows.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import typer

from workpilot import __version__
from workpilot.cli.commands import app, console

_WIN_MSG = (
    "[yellow]On Windows the running exe cannot be replaced automatically.[/yellow]\n"
    "  Please run this command in a new terminal to complete the update:\n\n"
    "  [bold]python -m {cmd}[/bold]\n"
)


def _is_git_install() -> Path | None:
    from workpilot.utils.update import is_git_install

    return is_git_install()


def _is_uv_install() -> bool:
    from workpilot.utils.update import is_uv_install

    return is_uv_install()


def _run(
    cmd: list[str], cwd: Path | str | None = None, timeout: int = 120
) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=cwd)
    except subprocess.TimeoutExpired:
        console.print(f"[red]Command timed out ({timeout}s):[/red] {' '.join(cmd)}")
        raise typer.Exit(1)
    except FileNotFoundError:
        console.print(f"[red]Command not found:[/red] {cmd[0]}")
        raise typer.Exit(1)


def _git_update(repo: Path, check_only: bool) -> bool:
    """Update from git: fetch, compare, pull, reinstall deps if needed.

    Returns True if the update is fully complete (code pulled and deps up-to-date).
    Returns False if there is nothing to update, or if a manual step is still
    required (e.g. Windows: pip must be run manually after closing this process).
    """
    # Check for dirty working tree
    status_result = _run(["git", "status", "--porcelain"], cwd=repo)
    if status_result.returncode != 0:
        console.print(f"[red]git status failed:[/red]\n{status_result.stderr.strip()}")
        raise typer.Exit(1)
    if status_result.stdout.strip():
        console.print(
            "[yellow]Working tree has uncommitted changes.[/yellow]\n"
            "  Commit or stash them before updating."
        )
        raise typer.Exit(1)

    # Fetch latest
    result = _run(["git", "fetch"], cwd=repo)
    if result.returncode != 0:
        console.print(f"[red]git fetch failed:[/red]\n{result.stderr.strip()}")
        raise typer.Exit(1)

    # Check for upstream changes
    local_result = _run(["git", "rev-parse", "HEAD"], cwd=repo)
    if local_result.returncode != 0:
        console.print(f"[red]git rev-parse HEAD failed:[/red]\n{local_result.stderr.strip()}")
        raise typer.Exit(1)
    local = local_result.stdout.strip()

    remote_result = _run(["git", "rev-parse", "@{u}"], cwd=repo)
    if remote_result.returncode != 0:
        console.print(
            "[red]No upstream tracking branch set.[/red]\n"
            "  Set one with: [bold]git branch --set-upstream-to origin/<branch>[/bold]"
        )
        raise typer.Exit(1)
    remote = remote_result.stdout.strip()

    if local == remote:
        console.print("[green]Already up to date![/green]  (no new commits)")
        return False

    # Detect ahead/behind/diverged state
    count_result = _run(["git", "rev-list", "--left-right", "--count", "HEAD...@{u}"], cwd=repo)
    if count_result.returncode != 0:
        console.print(f"[red]git rev-list failed:[/red]\n{count_result.stderr.strip()}")
        raise typer.Exit(1)
    parts = count_result.stdout.strip().split()
    if len(parts) != 2:
        console.print(f"[red]Unexpected git rev-list output:[/red] {count_result.stdout.strip()}")
        raise typer.Exit(1)
    ahead, behind = int(parts[0]), int(parts[1])

    if behind == 0 and ahead > 0:
        console.print(
            f"[yellow]Local branch is {ahead} commit(s) ahead of upstream.[/yellow]\n"
            "  Nothing to pull. Push your changes or reset to upstream."
        )
        return False

    if ahead > 0 and behind > 0:
        console.print(
            f"[yellow]Branch has diverged:[/yellow] {ahead} ahead, {behind} behind.\n"
            "  Resolve manually (rebase or merge) before updating."
        )
        raise typer.Exit(1)

    # Show what's new (behind > 0, ahead == 0)
    log_result = _run(["git", "log", "--oneline", f"{local}..{remote}"], cwd=repo)
    new_commits = log_result.stdout.strip()
    commit_count = len(new_commits.splitlines()) if new_commits else 0
    console.print(f"[cyan]{commit_count}[/cyan] new commit(s) available:")
    for line in new_commits.splitlines()[:10]:
        console.print(f"  {line}")
    if commit_count > 10:
        console.print(f"  [dim]... and {commit_count - 10} more[/dim]")

    if check_only:
        console.print("\n  Run [bold]wp update[/bold] to pull and install.")
        return False

    # Pull
    console.print("\n[dim]Pulling...[/dim]")
    result = _run(["git", "pull"], cwd=repo)
    if result.returncode != 0:
        console.print(f"[red]git pull failed:[/red]\n{result.stderr.strip()}")
        raise typer.Exit(1)
    console.print("[green]Pull complete.[/green]")

    # For editable installs, Python sources are used directly from the repo —
    # git pull alone is sufficient for pure code changes.  Only re-run pip if
    # pyproject.toml changed in the pulled commits (new deps or entry points).
    toml_changed_result = _run(
        ["git", "diff", "--name-only", f"{local}..{remote}", "--", "pyproject.toml"],
        cwd=repo,
    )
    # If the diff command fails (e.g. SHA no longer resolvable), err on the
    # side of caution and assume pyproject.toml may have changed.
    if toml_changed_result.returncode != 0:
        needs_pip = True
    else:
        needs_pip = bool(toml_changed_result.stdout.strip())

    if needs_pip:
        console.print("[dim]pyproject.toml changed — dependencies need reinstalling.[/dim]")
        if sys.platform == "win32":
            from rich.markup import escape as _escape

            console.print(_WIN_MSG.format(cmd=_escape('pip install -e ".[all]"')))
            # Dependencies not updated — don't claim update is complete
            return False
        pip_result = _run(
            [sys.executable, "-m", "pip", "install", "-e", ".[all]"],
            cwd=repo,
            timeout=300,
        )
        if pip_result.returncode != 0:
            console.print(f"[red]pip install failed:[/red]\n{pip_result.stderr.strip()}")
            raise typer.Exit(1)
        console.print("[green]Dependencies updated![/green]")

    return True


def _uv_update(check_only: bool) -> bool:
    """Update via ``uv tool upgrade workpilot``.

    Works on all platforms — no Windows file-lock workaround needed.
    Returns True if an update was performed.
    """
    from workpilot.utils.update import check_uv

    console.print("[dim]Checking for updates...[/dim]")
    status = check_uv()

    if status.error:
        console.print(
            "[yellow]Could not check for updates.[/yellow]\n"
            "  Update manually: [bold]uv tool upgrade workpilot[/bold]"
        )
        raise typer.Exit(1)

    if status.up_to_date:
        console.print(f"[green]Already up to date![/green]  (latest: v{status.latest})")
        return False

    latest = status.latest
    console.print(f"New version available: [cyan]v{latest}[/cyan]")

    if check_only:
        console.print("  Run [bold]wp update[/bold] to install it.")
        return False

    console.print("[dim]Upgrading via uv tool...[/dim]")
    result = _run(["uv", "tool", "upgrade", "workpilot"], timeout=120)
    if result.returncode == 0:
        console.print(f"[green]Updated to v{latest}![/green]")
        return True
    else:
        console.print(f"[red]Update failed:[/red]\n{result.stderr.strip()}")
        raise typer.Exit(1)


def _pypi_update(check_only: bool) -> bool:
    """Update from PyPI: check latest version, pip install --upgrade.

    Returns True if an update was performed.
    """
    from workpilot.utils.update import check_pypi

    console.print("[dim]Checking PyPI...[/dim]")
    status = check_pypi()

    if status.error:
        console.print(
            "[yellow]Could not check for updates.[/yellow]\n"
            "  Update manually: [bold]pip install --upgrade workpilot[/bold]"
        )
        raise typer.Exit(1)

    if status.up_to_date:
        console.print(f"[green]Already up to date![/green]  (latest: v{status.latest})")
        return False

    latest = status.latest
    console.print(f"New version available: [cyan]v{latest}[/cyan]")

    if check_only:
        console.print("  Run [bold]wp update[/bold] to install it.")
        return False

    console.print("[dim]Upgrading...[/dim]")

    if sys.platform == "win32":
        console.print(_WIN_MSG.format(cmd=f"pip install --upgrade workpilot=={latest}"))
        return False

    pip_result = _run(
        [sys.executable, "-m", "pip", "install", "--upgrade", f"workpilot=={latest}"],
        timeout=120,
    )
    if pip_result.returncode == 0:
        console.print(f"[green]Updated to v{latest}![/green]")
        return True
    else:
        console.print(f"[red]Update failed:[/red]\n{pip_result.stderr.strip()}")
        raise typer.Exit(1)


@app.command(name="update")
def update(
    check: bool = typer.Option(False, "--check", help="Only check for updates, don't install"),
) -> None:
    """Update WorkPilot to the latest version."""
    console.print(f"Current version: [bold]v{__version__}[/bold]")

    repo = _is_git_install()
    if repo:
        console.print(f"Install mode:    [cyan]git[/cyan]  ({repo})")
        updated = _git_update(repo, check)
    elif _is_uv_install():
        console.print("Install mode:    [cyan]uv[/cyan]")
        updated = _uv_update(check)
    else:
        console.print("Install mode:    [cyan]pypi[/cyan]")
        updated = _pypi_update(check)

    # Remind to restart if web server is running and we actually updated
    if updated:
        from workpilot.cli.commands import _check_web_running

        running = _check_web_running()
        if running:
            pid, port = running
            console.print(
                f"\n[yellow]Web server is running (PID {pid}, port {port}).[/yellow]\n"
                "  Restart it to use the new version."
            )


# "upgrade" is a hidden alias — keeps the same convention as other aliases in commands.py
app.command("upgrade", hidden=True)(update)
