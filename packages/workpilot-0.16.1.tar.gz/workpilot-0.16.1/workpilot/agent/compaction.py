"""
Context compaction — topic-aware context window management.

Two check points prevent context overflow:
- Post-completion (80%): topic-aware — clear old tool results (same topic)
  or full LLM summarization (topic switch)
- Pre-completion (95%): emergency LLM summarization

Disk session (JSONL) is never modified by compaction — all changes are
in-memory only. Consolidation reads from disk independently.

IMPORTANT: Split points must never break tool-call groups. An assistant
message with ``tool_calls`` and its corresponding ``tool`` result messages
must always stay together — OpenAI rejects orphaned tool messages.
"""

from __future__ import annotations

import re
from datetime import datetime
from typing import Any

from loguru import logger

from workpilot.utils.defaults import load_default

# Token estimation: max of two heuristics to avoid under-counting code.
# ── Token estimation ──────────────────────────────────────────────────────────
# Use tiktoken (OpenAI's tokenizer, Rust-based, ~0.01ms/call) for precise
# counts.  Falls back to a character-class heuristic if tiktoken is unavailable.

_tiktoken_enc: Any = None
_tiktoken_loaded = False


def _get_tiktoken() -> Any:
    """Lazily load tiktoken encoder (o200k_base for GPT-4o/5.x family)."""
    global _tiktoken_enc, _tiktoken_loaded  # noqa: PLW0603
    if not _tiktoken_loaded:
        _tiktoken_loaded = True
        try:
            import tiktoken

            _tiktoken_enc = tiktoken.get_encoding("o200k_base")
        except Exception:
            _tiktoken_enc = None
    return _tiktoken_enc


# Per-message overhead: role, name, formatting tokens
_MSG_OVERHEAD = 4


def estimate_msg_tokens(msg: dict[str, Any]) -> int:
    """Estimate token count for a single message or native item."""
    total = _MSG_OVERHEAD
    item_type = msg.get("type", "")

    # Native Responses API items
    if item_type == "function_call":
        total += count_tokens(msg.get("name", "")) + 4
        args = msg.get("arguments", "")
        total += count_tokens(args if isinstance(args, str) else str(args))
        return total
    if item_type == "function_call_output":
        output = msg.get("output", "")
        total += count_tokens(output if isinstance(output, str) else str(output))
        return total
    if item_type == "reasoning":
        # encrypted_content is opaque; estimate from summary text if available
        for part in msg.get("summary", []):
            total += count_tokens(part.get("text", ""))
        ec = msg.get("encrypted_content", "")
        if ec and not msg.get("summary"):
            total += len(ec) // 4  # rough estimate for base64 blob
        return total
    if item_type == "compaction":
        ec = msg.get("encrypted_content", "")
        return total + len(ec) // 4 if ec else total

    # Chat Completions format OR native message items
    content = msg.get("content") or ""
    if isinstance(content, str):
        total += count_tokens(content)
    elif isinstance(content, list):
        # Array content: [{type: "output_text", text: "..."}, ...]
        for part in content:
            if isinstance(part, dict):
                total += count_tokens(part.get("text", "") or part.get("refusal", ""))
    for tc in msg.get("tool_calls", []):
        fn = tc.get("function", {})
        name = fn.get("name", "")
        args = fn.get("arguments", "")
        if isinstance(args, dict):
            args = str(args)
        total += count_tokens(name) + 4
        total += count_tokens(args)
    return total


def estimate_tokens(messages: list[dict[str, Any]]) -> int:
    """Estimate token count from messages.

    Uses tiktoken (o200k_base) when available for precise BPE counting.
    Falls back to character-class heuristic if tiktoken is not installed.
    """
    return sum(estimate_msg_tokens(msg) for msg in messages)


def count_tokens(text: str) -> int:
    """Count tokens using tiktoken or fallback heuristic."""
    if not text:
        return 0
    enc = _get_tiktoken()
    if enc is not None:
        return len(enc.encode(text))
    # Fallback: CJK-aware character heuristic
    cjk_chars = len(re.findall(r"[\u4e00-\u9fff\u3400-\u4dbf]", text))
    latin_chars = len(text) - cjk_chars
    return int(cjk_chars / 1.5) + latin_chars // 4


# ── Topic switch detection ──────────────────────────────────────────────────

# Common stopwords to exclude from keyword extraction
_STOPWORDS = frozenset(
    "a an the is are was were be been being have has had do does did "
    "will would shall should may might can could and or but not no nor "
    "for to of in on at by with from as into about it its this that "
    "these those i me my we our you your he she they them what which "
    "who how when where why all any each every some few more most "
    "again also just now very too please hi hello hey thanks ok yes no".split()
)


def _extract_keywords(text: str) -> set[str]:
    """Extract meaningful keywords from text, excluding stopwords.

    Handles both Latin tokens (≥3 chars) and CJK bigrams so that Chinese /
    Japanese / Korean conversations produce comparable keyword sets.
    """
    # Latin / numeric tokens
    latin = re.findall(r"[a-zA-Z0-9_./\\-]{3,}", text.lower())
    keywords = {w for w in latin if w not in _STOPWORDS}
    # CJK bigrams — slide a 2-char window over CJK runs for overlap matching.
    # Cap at 200 distinct CJK bigrams to keep topic detection cheap on long conversations.
    _CJK_BIGRAM_CAP = 200
    cjk_added = 0
    cjk_chars = re.findall(r"[\u4e00-\u9fff\u3400-\u4dbf\u3040-\u30ff\uac00-\ud7af]+", text)
    for run in cjk_chars:
        for i in range(len(run) - 1):
            bigram = run[i : i + 2]
            if bigram not in keywords:
                keywords.add(bigram)
                cjk_added += 1
                if cjk_added >= _CJK_BIGRAM_CAP:
                    return keywords
    return keywords


def _strip_injected_context(content: str) -> str:
    """Strip all context injected by ``build_messages()`` from a user message.

    ``build_messages()`` prepends runtime context, skill ``<context>`` blocks,
    and history context to the *current* user message but never persists them
    to the session.  This asymmetry pollutes keyword extraction: injected
    keywords appear only in the newest message, causing overlap ≈ 0 and a
    false topic switch on every turn.

    Handles three cases (most specific first):
    1. ``---\\n[User Message]`` separator present → return text after it
    2. Only ``[Runtime Context …]`` prefix → strip up to first blank line
    3. Plain text → return as-is
    """
    from workpilot.agent.context import USER_MSG_SEPARATOR

    # Case 1: full injection with separator (preceded by blank line)
    marker = "\n\n" + USER_MSG_SEPARATOR
    idx = content.find(marker)
    if idx != -1:
        return content[idx + len(marker) :].lstrip("\n")

    # Case 2: runtime context only (no skill/history → no separator)
    if content.startswith("[Runtime Context"):
        idx = content.find("\n\n")
        if idx != -1:
            return content[idx + 2 :]

    # Case 3: raw text
    return content


def detect_topic_switch(messages: list[dict[str, Any]], threshold: float = 0.3) -> bool:
    """Detect whether the conversation topic has switched.

    Compares keyword overlap between the last 3 user messages and all
    earlier user messages. Returns True if overlap < threshold (topic changed).

    Pre-checks:
    - No user messages -> False (no topic switch)
    - Fewer than 2 keywords in recent messages -> False (too ambiguous)
    - Slash commands in recent messages -> True (new intent)
    """
    user_msgs = [m for m in messages if m.get("role") == "user"]
    if len(user_msgs) < 4:
        return False  # Not enough history to detect a switch

    recent = user_msgs[-3:]
    earlier = user_msgs[:-3]

    # Slash commands = always topic switch
    for m in recent:
        content = m.get("content", "")
        if isinstance(content, str) and content.strip().startswith("/"):
            return True

    recent_text = " ".join(
        _strip_injected_context(m.get("content", ""))
        for m in recent
        if isinstance(m.get("content"), str)
    )
    earlier_text = " ".join(
        _strip_injected_context(m.get("content", ""))
        for m in earlier
        if isinstance(m.get("content"), str)
    )

    recent_kw = _extract_keywords(recent_text)
    earlier_kw = _extract_keywords(earlier_text)

    if len(recent_kw) < 2:
        return False  # Too ambiguous

    if not earlier_kw:
        return False

    overlap = len(recent_kw & earlier_kw) / max(len(recent_kw), 1)
    return overlap < threshold


# ── Clear old tool results ──────────────────────────────────────────────────


def _build_tool_placeholder(
    tool_name: str,
    content: str,
    *,
    is_error: bool = False,
) -> str:
    """Build a concise placeholder that preserves outcome context.

    Format: ``[tool result cleared: <name> | <status> | <preview>]``

    Examples::

        [tool result cleared: read_file | ok | 245 lines read]
        [tool result cleared: shell | error | Exit code 1: command not found]
        [tool result cleared: web_fetch | ok | 200 OK, 12KB]
        [tool result cleared: search_files | ok | 3 matches]
    """
    status = "error" if is_error else "ok"

    # Extract a short preview from the first non-empty line
    preview = ""
    for line in content.splitlines():
        line = line.strip()
        if line:
            preview = line[:120]
            break

    # Enrich with size/line-count info for common large results
    line_count = content.count("\n")
    char_count = len(content)
    if char_count > 500:
        size_hint = f"{line_count} lines, {char_count} chars"
    else:
        size_hint = ""

    parts = [f"tool result cleared: {tool_name}", status]
    if size_hint:
        parts.append(size_hint)
    if preview:
        # Truncate preview so the total placeholder stays compact
        max_preview = 120
        if len(preview) > max_preview:
            preview = preview[:max_preview] + "..."
        parts.append(preview)

    return f"[{' | '.join(parts)}]"


def clear_old_tool_results(messages: list[dict[str, Any]], keep_turns: int = 3) -> int:
    """Clear tool result content from messages older than the last N user turns.

    Replaces tool message content with a compact placeholder that preserves
    the tool name, success/error status, and a brief outcome preview.
    The ``tool_calls`` structure in assistant messages is untouched.

    Handles both Chat format (``role: "tool"``) and native Responses API
    format (``type: "function_call_output"``).

    Returns the number of tool results cleared.
    Modifies ``messages`` in-place.
    """
    # Find positions of user messages (counting from the end)
    user_positions: list[int] = []
    for i, msg in enumerate(messages):
        if msg.get("role") == "user":
            user_positions.append(i)

    if len(user_positions) <= keep_turns:
        return 0  # Not enough history

    # The cutoff: messages before this position are "old"
    cutoff = user_positions[-keep_turns]

    cleared = 0
    for i in range(cutoff):
        msg = messages[i]

        # Native format: function_call_output
        if msg.get("type") == "function_call_output":
            output = msg.get("output", "")
            if (
                isinstance(output, str)
                and output
                and not output.startswith("[tool result cleared:")
            ):
                is_error = msg.get("is_error", False) or output.startswith(("Error", "BLOCKED"))
                # Find tool name from preceding function_call item
                tool_name = "?"
                call_id = msg.get("call_id", "")
                for j in range(i - 1, -1, -1):
                    if (
                        messages[j].get("type") == "function_call"
                        and messages[j].get("call_id") == call_id
                    ):
                        tool_name = messages[j].get("name", "?")
                        break
                msg["output"] = _build_tool_placeholder(tool_name, output, is_error=is_error)
                cleared += 1
            continue

        # Legacy format: role=tool
        if (
            msg.get("role") == "tool"
            and msg.get("content")
            and not msg["content"].startswith("[tool result cleared:")
        ):
            content = msg["content"]
            is_error = msg.get("is_error", False) or content.startswith(("Error", "BLOCKED"))

            # Extract tool name from the preceding assistant's tool_calls
            tool_name = "?"
            tc_id = msg.get("tool_call_id", "")
            for j in range(i - 1, -1, -1):
                if messages[j].get("role") == "assistant":
                    for tc in messages[j].get("tool_calls", []):
                        if tc.get("id") == tc_id:
                            tool_name = tc.get("function", {}).get("name", "?")
                            break
                    break

            msg["content"] = _build_tool_placeholder(tool_name, content, is_error=is_error)
            cleared += 1

    if cleared:
        logger.info(
            "Cleared {} old tool results (kept last {} user turns)",
            cleared,
            keep_turns,
        )
    return cleared


# ── Split point selection ───────────────────────────────────────────────────


def find_split_point(
    messages: list[dict[str, Any]],
    *,
    keep_min_turns: int = 5,
    keep_min_msgs: int = 15,
    context_limit: int = 128_000,
    topic_threshold: float = 0.3,
) -> int:
    """Find the optimal split point for compaction.

    Searches backward from the newest message for a natural boundary:
    1. Time gap > 30 min between consecutive messages
    2. Topic boundary (keyword overlap < 0.3)
    3. Minimum (keep_min_turns user turns / keep_min_msgs messages)

    Returns the index where the "kept" portion starts (everything before
    is "old" and should be summarized).

    Enforces:
    - At least keep_min_turns user turns in kept portion
    - At least keep_min_msgs non-system messages in kept portion
    - 50% token cap on kept portion
    - Never breaks tool-call groups
    """
    non_system = [m for m in messages if m.get("role") != "system"]
    if len(non_system) <= keep_min_msgs:
        return 0  # Nothing to compact

    # Calculate minimum keep index based on user turns
    user_count = 0
    turn_idx = len(non_system)
    for i in range(len(non_system) - 1, -1, -1):
        if non_system[i].get("role") == "user":
            user_count += 1
            if user_count >= keep_min_turns:
                turn_idx = i
                break

    # Minimum keep index based on message count
    msg_idx = max(0, len(non_system) - keep_min_msgs)

    # Use whichever retains MORE
    min_keep_idx = min(turn_idx, msg_idx)

    # Strategy 1: Time gap > 30 min
    # Search backward from min_keep_idx toward the oldest message.  Pick
    # the NEAREST qualifying gap so that we maximise how much old content
    # gets summarised.  (The previous "largest gap" approach often found a
    # gap near the very start of the conversation, keeping almost
    # everything and making compaction ineffective.)
    best_gap_idx = None
    for i in range(min_keep_idx - 1, -1, -1):
        ts_a = non_system[i].get("_ts", "")
        ts_b = non_system[i + 1].get("_ts", "") if i + 1 < len(non_system) else ""
        if ts_a and ts_b:
            try:
                dt_a = datetime.fromisoformat(ts_a)
                dt_b = datetime.fromisoformat(ts_b)
                gap = (dt_b - dt_a).total_seconds()
                if gap > 1800:  # 30 min
                    best_gap_idx = i + 1
                    break  # nearest gap found — stop
            except (ValueError, TypeError):
                continue

    if best_gap_idx is not None:
        split = best_gap_idx
    else:
        # Strategy 2: Topic boundary
        # Try to find a point where topic changes
        best_topic_idx = None
        best_topic_score = 1.0
        for i in range(1, min_keep_idx + 1):
            before = non_system[:i]
            after = non_system[i:]
            before_user = [m for m in before if m.get("role") == "user"]
            after_user = [m for m in after if m.get("role") == "user"]
            if not before_user or not after_user:
                continue
            before_kw = _extract_keywords(
                " ".join(_strip_injected_context(m.get("content", "")) for m in before_user[-3:])
            )
            after_kw = _extract_keywords(
                " ".join(_strip_injected_context(m.get("content", "")) for m in after_user[:3])
            )
            if not before_kw or not after_kw:
                continue
            overlap = len(before_kw & after_kw) / max(len(after_kw), 1)
            if overlap < best_topic_score:
                best_topic_score = overlap
                best_topic_idx = i

        if best_topic_idx is not None and best_topic_score < topic_threshold:
            split = best_topic_idx
        else:
            # Strategy 3: Fall back to minimum
            split = min_keep_idx

    # Ensure we don't keep more than 50% of context in tokens
    kept = non_system[split:]
    kept_tokens = estimate_tokens(kept)
    half_limit = context_limit // 2
    if kept_tokens > half_limit and len(kept) > keep_min_msgs:
        # Trim oldest kept messages until under 50%
        while kept_tokens > half_limit and len(kept) > keep_min_msgs:
            kept = kept[1:]
            kept_tokens = estimate_tokens(kept)
        split = len(non_system) - len(kept)

    # Adjust to not break tool-call groups
    while split > 0 and non_system[split].get("role") == "tool":
        split -= 1

    return split


# ── Compaction prompt ───────────────────────────────────────────────────────


def _format_messages_for_prompt(messages_to_compress: list[dict[str, Any]]) -> str:
    """Format messages into a text block for compaction prompts."""
    lines = []
    for msg in messages_to_compress:
        role = msg.get("role", "unknown")
        content = msg.get("content") or ""
        if isinstance(content, str) and content:
            preview = content[:500] + ("..." if len(content) > 500 else "")
            lines.append(f"[{role}] {preview}")
        tool_calls = msg.get("tool_calls", [])
        if tool_calls:
            names = [tc.get("function", {}).get("name", "?") for tc in tool_calls]
            lines.append(f"[{role}] called tools: {', '.join(names)}")
    return "\n".join(lines)


def _load_template(name: str) -> str:
    """Load a prompt template, preferring user override at ~/.workpilot/."""
    return load_default(name)


def load_compaction_messages(
    messages_to_compress: list[dict[str, Any]],
) -> list[dict[str, str]]:
    """Load COMPACTION.md and return [system, user] messages for the LLM call.

    User-overridable at ~/.workpilot/COMPACTION.md.
    """
    return [
        {"role": "system", "content": _load_template("COMPACTION.md")},
        {"role": "user", "content": _format_messages_for_prompt(messages_to_compress)},
    ]


def _load_merge_messages(summary_a: str, summary_b: str) -> list[dict[str, str]]:
    """Load MERGE_SUMMARY.md and return [system, user] messages.

    User-overridable at ~/.workpilot/MERGE_SUMMARY.md.
    """
    return [
        {"role": "system", "content": _load_template("MERGE_SUMMARY.md")},
        {
            "role": "user",
            "content": f"## Summary A (earlier)\n\n{summary_a}\n\n---\n\n## Summary B (more recent)\n\n{summary_b}",
        },
    ]


# ── Fallback compaction ─────────────────────────────────────────────────────


def compact_fallback(messages: list[dict[str, Any]], keep_recent: int = 3) -> list[dict[str, Any]]:
    """Emergency fallback: truncate oldest messages, no LLM call.

    Keeps system messages + last N user turns (respecting tool-call groups).
    """
    system_msgs = [m for m in messages if m.get("role") == "system"]
    non_system = [m for m in messages if m.get("role") != "system"]

    if len(non_system) <= keep_recent:
        return messages

    # Count user turns from the end to find the split
    user_count = 0
    split = len(non_system)
    for i in range(len(non_system) - 1, -1, -1):
        if non_system[i].get("role") == "user":
            user_count += 1
            if user_count >= keep_recent:
                split = i
                break

    # Adjust: don't start on a tool message
    while split > 0 and non_system[split].get("role") == "tool":
        split -= 1

    kept = non_system[split:]
    removed = len(non_system) - len(kept)
    logger.info(
        "Compaction fallback: truncated {} messages, kept {} recent",
        removed,
        len(kept),
    )
    return (
        system_msgs
        + [
            {
                "role": "system",
                "content": f"[Context compacted: {removed} older messages removed]",
            }
        ]
        + kept
    )


# ── Full compaction (LLM summarization) ─────────────────────────────────────


async def compact_messages(
    messages: list[dict[str, Any]],
    provider: Any,
    config: Any,
    *,
    context_limit: int = 128_000,
    focus: str = "",
) -> list[dict[str, Any]]:
    """New compaction orchestrator — topic-aware smart split + LLM summary.

    1. Calls find_split_point() to determine old vs kept
    2. Summarizes old portion + any prior compaction summaries (main model
       — design prefers fast but compaction quality benefits from depth)
    3. Chunked if old > 40% context
    4. Returns system_prompt_msgs + [new summary] + kept_msgs (prior
       summaries are folded into the new summary, not accumulated)
    5. On failure: compact_fallback() (keep 3 user turns)
    """
    # Separate old compaction summaries from other system messages so they
    # can be folded into the new summary instead of accumulating forever.
    _SUMMARY_MARKER = "[Conversation summary"
    old_summaries = [
        m
        for m in messages
        if m.get("role") == "system" and _SUMMARY_MARKER in (m.get("content") or "")
    ]
    system_prompt_msgs = [
        m
        for m in messages
        if m.get("role") == "system" and _SUMMARY_MARKER not in (m.get("content") or "")
    ]
    non_system = [m for m in messages if m.get("role") != "system"]

    if len(non_system) <= 15:
        return messages  # Nothing meaningful to compact

    split = find_split_point(
        messages,
        keep_min_turns=config.compaction_keep_min_turns,
        keep_min_msgs=config.compaction_keep_min_msgs,
        context_limit=context_limit,
        topic_threshold=config.compaction_topic_threshold,
    )

    # Map the non_system split index back to the full messages list
    ns_idx = 0
    full_split = 0
    for i, m in enumerate(messages):
        if m.get("role") != "system":
            if ns_idx == split:
                full_split = i
                break
            ns_idx += 1
    else:
        full_split = len(messages)

    to_summarize = [m for m in messages[:full_split] if m.get("role") != "system"]
    to_keep = [m for m in messages[full_split:] if m.get("role") != "system"]

    if not to_summarize:
        return messages

    # Include old summaries in material to summarize so the new summary
    # subsumes them — prevents unbounded summary accumulation.
    to_summarize = old_summaries + to_summarize

    # Check if chunked summarization is needed (old > 40% context)
    old_tokens = estimate_tokens(to_summarize)
    chunk_threshold = int(context_limit * 0.4)

    try:
        if old_tokens > chunk_threshold:
            summary = await _chunked_summarize(to_summarize, provider, config, context_limit, focus)
        else:
            summary = await _single_summarize(to_summarize, provider, config, focus)

        logger.info(
            "Compaction: summarized {} messages ({} tokens) into {} chars, kept {}",
            len(to_summarize),
            old_tokens,
            len(summary),
            len(to_keep),
        )
    except Exception as exc:
        logger.error("Compaction LLM call failed: {}, falling back to truncation", exc)
        return compact_fallback(messages, keep_recent=3)

    return (
        system_prompt_msgs
        + [
            {
                "role": "system",
                "content": (
                    f"[Conversation summary — {len(to_summarize)} messages compacted]\n{summary}"
                ),
            }
        ]
        + to_keep
    )


async def _single_summarize(
    messages: list[dict[str, Any]],
    provider: Any,
    config: Any,
    focus: str = "",
) -> str:
    """Single-pass LLM summarization."""
    llm_msgs = load_compaction_messages(messages)
    if focus:
        # Append focus hint to the user message
        llm_msgs[-1]["content"] += f"\n\nAdditional focus: {focus}"

    response = await provider.complete(
        model=config.model,
        messages=llm_msgs,
        temperature=0.1,
        max_tokens=2048,
    )
    return str(response.content)


async def _chunked_summarize(
    messages: list[dict[str, Any]],
    provider: Any,
    config: Any,
    context_limit: int,
    focus: str = "",
) -> str:
    """Chunked summarization for large message sets.

    Splits into chunks of ~context_limit/4 tokens each, summarizes
    independently, then merges iteratively.
    """
    chunk_size = context_limit // 4
    chunks: list[list[dict[str, Any]]] = []
    current_chunk: list[dict[str, Any]] = []
    current_tokens = 0

    for msg in messages:
        msg_tokens = estimate_tokens([msg])
        if current_tokens + msg_tokens > chunk_size and current_chunk:
            chunks.append(current_chunk)
            current_chunk = []
            current_tokens = 0
        current_chunk.append(msg)
        current_tokens += msg_tokens

    if current_chunk:
        chunks.append(current_chunk)

    if len(chunks) <= 1:
        return await _single_summarize(messages, provider, config, focus)

    # Summarize each chunk
    summaries: list[str] = []
    for chunk in chunks:
        summary = await _single_summarize(chunk, provider, config, focus)
        summaries.append(summary)

    # Merge iteratively
    merged = summaries[0]
    for s in summaries[1:]:
        llm_msgs = _load_merge_messages(merged, s)
        response = await provider.complete(
            model=config.model,
            messages=llm_msgs,
            temperature=0.1,
            max_tokens=2048,
        )
        merged = str(response.content)

    return merged


# ── Threshold checks (used by loop.py) ──────────────────────────────────────


def should_post_compact(
    prompt_tokens: int,
    context_limit: int,
    message_count: int,
) -> bool:
    """Check if post-completion compaction should be considered.

    Returns True if prompt_tokens > 80% of context_limit OR message_count >= 100.
    """
    if context_limit <= 0:
        return False
    return (prompt_tokens / context_limit) > 0.80 or message_count >= 100


def should_pre_compact(
    prompt_tokens: int,
    completion_tokens: int,
    new_messages: list[dict[str, Any]],
    context_limit: int,
) -> bool:
    """Check if pre-completion emergency compaction is needed.

    Returns True if estimated current tokens > 95% of context_limit.
    """
    if context_limit <= 0:
        return False
    estimated = prompt_tokens + completion_tokens + estimate_tokens(new_messages)
    return (estimated / context_limit) > 0.95
