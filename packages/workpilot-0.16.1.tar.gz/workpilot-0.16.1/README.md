<p align="center">
  <img src="docs/images/logo.svg" alt="WorkPilot" width="80" />
</p>

<h1 align="center">WorkPilot</h1>

<p align="center">
  <strong>An autonomous AI assistant that codes, communicates, and ships across your entire Microsoft stack — proactively and securely.</strong>
</p>

<p align="center">
  <a href="https://github.com/gim-home/WorkPilot/actions/workflows/workpilot-ci.yml"><img src="https://github.com/gim-home/WorkPilot/actions/workflows/workpilot-ci.yml/badge.svg" alt="CI" /></a>
  <a href="https://www.python.org/"><img src="https://img.shields.io/badge/python-3.11+-blue.svg" alt="Python 3.11+" /></a>
  <a href="https://aka.ms/workpilot/docs"><img src="https://img.shields.io/badge/docs-aka.ms%2Fworkpilot%2Fdocs-green" alt="Docs" /></a>
</p>

<p align="center">
  <a href="https://aka.ms/workpilot">Website</a> ·
  <a href="https://aka.ms/workpilot/docs">Documentation</a> ·
  <a href="docs/CHANGELOG.md">Changelog</a> ·
  <a href="https://teams.microsoft.com/l/chat/0/0?users=28:80a9478e-6cc7-4e7a-84bc-37abbd81f5f6">Add to Teams</a>
</p>

---

WorkPilot runs entirely on your machine. Your source code, credentials, and conversations never leave your infrastructure — yet your team can reach it directly from Microsoft Teams, a browser, or the terminal.

<p align="center">
  <img src="docs/images/screenshot/terminal.png" alt="Terminal" width="32%" />
  <img src="docs/images/screenshot/webchat.jpeg" alt="Web Chat" width="32%" />
  <img src="docs/images/screenshot/teams.png" alt="Teams" width="32%" />
</p>

## Why WorkPilot?

| Principle | Details |
|-----------|---------|
| **Your infra, your data** | Runs on your machine or VM — nothing persisted outside your network |
| **Your identity provider** | Entra ID (Azure AD) SSO — no separate accounts or API keys to manage |
| **Your compliance posture** | Four security profiles (`open` → `standard` → `controlled` → `restricted`) |
| **Your Microsoft stack** | Native Teams bot, Outlook, Graph API, Azure DevOps integration |

## Install

With [uv](https://docs.astral.sh/uv/) (recommended), pip, or the bootstrap script below:

```bash
uv tool install workpilot
workpilot init          # guided setup
workpilot               # smart start — init if needed, then launch
```

<details>
<summary><strong>One-click bootstrap</strong> (auto-installs uv + Python if needed)</summary>

**Windows (PowerShell):**
```powershell
irm https://aka.ms/workpilot/install.ps1 | iex
```

**macOS / Linux:**
```bash
curl -fsSL https://aka.ms/workpilot/install.sh | bash
```

The bootstrap scripts install `uv` and ensure a compatible Python runtime is available if needed, then install WorkPilot via `uv tool`. Existing pip installs are migrated automatically.
</details>

<details>
<summary><strong>Alternative: pip install</strong></summary>

```bash
pip install workpilot
```

> **Note:** `uv tool install` is recommended over pip because it creates an isolated
> environment and avoids Windows file-lock issues during upgrades. To migrate an
> existing pip install to uv: re-run the bootstrap script or manually:
> ```bash
> pip uninstall workpilot -y
> uv tool install workpilot
> ```
</details>

<details>
<summary><strong>Platform notes</strong></summary>

| Platform | Notes |
|----------|-------|
| **Windows** | If `workpilot` isn't found after install, ensure the install location is on your PATH: `%USERPROFILE%\.local\bin` for uv, or `%APPDATA%\Python\Python3x\Scripts` for pip. Or use the bootstrap script. |
| **macOS** | You may need `python3` instead of `python`. Homebrew: `brew install python@3.11` |
| **Linux** | `sudo apt install python3.11 python3.11-venv` if Python 3.11+ isn't available. |
</details>

## Three ways to use it

### Terminal
```bash
workpilot chat               # interactive REPL
workpilot run "write tests"  # one-shot
```

### Self-hosted web server
```bash
workpilot serve              # http://localhost:3003
```
Chat UI, REST API, WebSocket, and OpenAI-compatible `/v1/chat/completions` — all on your own server.

### Microsoft Teams + Web Chat
```bash
workpilot cloud              # authenticate with Entra ID
```
A stateless [Cloud Gateway](cloud_gateway/) relays messages between Teams and your machine over outbound WSS. Nothing is stored in the cloud.

> **Teams user?** [Add WorkPilot to Teams](https://teams.microsoft.com/l/chat/0/0?users=28:80a9478e-6cc7-4e7a-84bc-37abbd81f5f6) *(Preview)* then run `workpilot s` to bring it online.

## What it does

| Capability | Details |
|--|--|
| **Code** | Read, write, edit, refactor, and debug across your entire codebase |
| **Shell** | Run commands, git, tests, build tools — sandboxed with deny-pattern controls |
| **Browse** | Web search, HTTP requests, Playwright browser automation (36 actions) |
| **Microsoft 365** | Teams messages, Outlook email, calendar, Graph API, Azure DevOps |
| **Delegate** | Spawn sub-agents; delegate to GitHub Copilot or Claude Code in background |
| **Skills** | Markdown prompt overlays with auto-activation — 7 bundled, create your own |
| **MCP** | Connect external tool servers — namespaced tools, progressive loading, auto-reconnect |
| **Schedule** | Cron jobs, event triggers, heartbeat tasks, recurring automation |

## Built-in agents

| Agent | Model | Purpose |
|-------|-------|---------|
| `default` | auto | Full-capability orchestrator — user-facing, spawns sub-agents |
| `explorer` | fast | Read-only codebase search — 10× cheaper, spawned automatically |
| `security` | fast | Internal Security Classifier — evaluates tool calls (not user-facing) |

5 templates (`coder`, `reviewer`, `tester`, `researcher`, `communicator`) can be enabled per-project in `workpilot.yaml`.

## Security

WorkPilot implements defense-in-depth at every layer:

| Layer | Mechanisms |
|-------|-----------|
| **Access control** | Entra ID SSO · 4 security profiles · per-agent permissions · RBAC roles |
| **Runtime protection** | 3-phase tool hook pipeline · Security Classifier (fast LLM) · command sandbox · path sandbox · SSRF protection |
| **Incident response** | Append-only audit log · secret redaction · credential leak detection · E-stop (auto or manual) |

## Architecture

```
Terminal / Web UI / Teams
        │
   Message Bus (bounded queues + typed events)
        │
   Agent Loop ──── Tool Registry ──── Skills (auto-inject)
   │    │               │
   │    │          MCP Servers
   │    │
   │   LLM Provider (OpenAI SDK + circuit breaker + cost tracking)
   │
   Security Pipeline (preflight → execute → postflight)
```

See [design/core-infra.md](design/core-infra.md) for the full architecture spec.

## Development

```bash
git clone https://github.com/gim-home/WorkPilot.git
cd WorkPilot
pip install -e ".[dev]"        # editable install with dev dependencies
pip install -e ".[all]"        # all optional deps (browser, scheduler, etc.)
pytest tests/ -v               # 1500+ tests
python -m ruff check && python -m ruff format
```

All changes via pull request. Never push directly to `main`.

## Links

- [Official Website](https://aka.ms/workpilot)
- [Documentation](https://aka.ms/workpilot/docs)
- [Changelog](docs/CHANGELOG.md)
- [Add to Microsoft Teams](https://teams.microsoft.com/l/chat/0/0?users=28:80a9478e-6cc7-4e7a-84bc-37abbd81f5f6) *(Preview)*
- [Architecture docs](design/core-infra.md)
- [Cloud Gateway (.NET)](cloud_gateway/)
