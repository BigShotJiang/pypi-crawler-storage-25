"""
S09 Decide — 루프 계속/완료 판단 (v0.14.0 번호 시프트: s10_decide → s09_decide)

Strategy 에 전적 위임 — Stage 내부에 분기 로직 없음.
각 DecideStrategy 구현체가 자기 판단 규칙을 전부 들고 있다.

기본 Strategy:
  threshold (ThresholdDecide): Guard 체인 + 도구 호출 + 점수 + 응답 기반
  always_pass (AlwaysPassDecide): 항상 complete

v0.11.1 리팩토링: 기존 execute() 안 if/else 하드코딩을 ThresholdDecide.decide() 로 이관.
"""

import logging

from ...core.stage import Stage, StrategyInfo
from ...core.state import PipelineState
from ..strategies._decide import (
    LOOP_CONTINUE,
    LOOP_COMPLETE,
    LOOP_RETRY,
    LOOP_ERROR,
    LOOP_ESCALATE,
)

logger = logging.getLogger("harness.stage.decide")

# geny 패턴: loop decision 상수 재노출 (하위 호환 — 외부 import 하는 코드 보호)
__all__ = [
    "DecideStage",
    "LOOP_CONTINUE",
    "LOOP_COMPLETE",
    "LOOP_RETRY",
    "LOOP_ERROR",
    "LOOP_ESCALATE",
]


class DecideStage(Stage):
    """루프 계속/완료 판단 — 전적으로 DecideStrategy 에 위임."""

    @property
    def stage_id(self) -> str:
        return "s09_decide"

    @property
    def order(self) -> int:
        return 9

    async def execute(self, state: PipelineState) -> dict:
        # s07_act 의 strict_no_error 변형이 도구 실패를 감지하면 즉시 stop.
        # 박은 측: stages/s07_act/stage.py · 키 prefix 's07_strict_*'.
        # 폴리시: 부분 성공 위에서 LLM 이 추측 답변하느니 명시 에러로 종료.
        if state.metadata.get("s07_strict_failed"):
            failures = state.metadata.get("s07_strict_failures") or []
            reason = (
                f"strict_no_error: {len(failures)}개 도구 실패 — "
                f"후속 LLM 합성 차단"
            )
            logger.warning("[Decide] %s · failures=%s", reason, failures[:3])
            state.loop_decision = LOOP_COMPLETE
            return {
                "decision": LOOP_COMPLETE,
                "reason": reason,
                "strict_failures": failures,
            }

        strategy = self.resolve_strategy("decide", state, "threshold")
        if strategy is None:
            state.loop_decision = LOOP_ERROR
            reason = "Decide strategy 미등록 — threshold 를 찾지 못함"
            logger.error("[Decide] %s", reason)
            return {"decision": LOOP_ERROR, "reason": reason}

        # v0.29.2 — guards / cost_budget_usd / token_budget / content_* dead read 제거.
        # ThresholdDecide (v0.17.0+) 가 이 params 를 더 이상 소비하지 않음 — Policy Gate
        # (s05_policy) 가 LOOP_BOUNDARY 훅에서 Guard 체인을 직접 실행한 결과를
        # state.policy_block_reason / loop_decision 으로 전달받아 그 결정을 존중.
        # max_retries 만 retry 카운트 비교용으로 의미.
        params = {
            "max_retries": self.get_param("max_retries", state, 3),
        }

        try:
            result = await strategy.decide(state, params)
        except Exception as e:
            logger.exception("[Decide] Strategy '%s' 실행 실패", strategy.name)
            state.loop_decision = LOOP_ERROR
            return {"decision": LOOP_ERROR, "reason": f"{strategy.name} 실패: {e}"}

        decision = result.get("decision", LOOP_CONTINUE)
        state.loop_decision = decision
        return result

    def list_strategies(self) -> list[StrategyInfo]:
        return [
            StrategyInfo("threshold", "Guard 체인 + 점수 기반 판단", is_default=True),
            StrategyInfo("always_pass", "항상 완료 (루프 없음)"),
        ]
