# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import json
import math
from typing import TYPE_CHECKING, Any, Literal, TypeVar

from pydantic import BaseModel, ValidationError

from coreason_runtime.utils.logger import logger

if TYPE_CHECKING:
    from collections.abc import Callable, Coroutine

T = TypeVar("T", bound=BaseModel)

# ---------------------------------------------------------------------------
# Topology Selection FSM State (Phase 1 output — not a manifest entity)
# ---------------------------------------------------------------------------

_SUPPORTED_TOPOLOGY_TYPES = Literal[
    "dag",
    "council",
    "swarm",
    "evolutionary",
    "smpc",
    "evaluator_optimizer",
    "digital_twin",
    "macro_adversarial",
    "macro_federation",
    "macro_forge",
    "macro_elicitation",
    "discourse_tree",
    "macro_neurosymbolic",
]


class TopologySelectionResult(BaseModel):
    """Phase 1 FSM output: the LLM's chosen topology type and rationale."""

    selected_type: _SUPPORTED_TOPOLOGY_TYPES
    architectural_intent: str
    detailed_blueprint: str


def _build_topology_class_registry() -> dict[str, type[BaseModel]]:
    """Lazily builds the discriminator → concrete Pydantic class mapping."""
    from coreason_manifest import (
        CapabilityForgeTopologyManifest,
        ConsensusFederationTopologyManifest,
        CouncilTopologyManifest,
        DAGTopologyManifest,
        DigitalTwinTopologyManifest,
        DiscourseTreeManifest,
        EvaluatorOptimizerTopologyManifest,
        EvolutionaryTopologyManifest,
        SMPCTopologyManifest,
        SwarmTopologyManifest,
    )
    from coreason_manifest.spec.ontology import (
        AdversarialMarketTopologyManifest,
        IntentElicitationTopologyManifest,
        NeurosymbolicVerificationTopologyManifest,
    )

    return {
        "dag": DAGTopologyManifest,
        "council": CouncilTopologyManifest,
        "swarm": SwarmTopologyManifest,
        "evolutionary": EvolutionaryTopologyManifest,
        "smpc": SMPCTopologyManifest,
        "evaluator_optimizer": EvaluatorOptimizerTopologyManifest,
        "digital_twin": DigitalTwinTopologyManifest,
        "macro_adversarial": AdversarialMarketTopologyManifest,
        "macro_federation": ConsensusFederationTopologyManifest,
        "macro_forge": CapabilityForgeTopologyManifest,
        "macro_elicitation": IntentElicitationTopologyManifest,
        "discourse_tree": DiscourseTreeManifest,
        "macro_neurosymbolic": NeurosymbolicVerificationTopologyManifest,
    }


# Domain trigger catalog — extracted from each manifest's MCP ROUTING TRIGGERS
_TOPOLOGY_CATALOG = """Available Topology Types:

1. "dag" — Directed Acyclic Graph. Use for: sequential pipelines, causal chains,
   data flow graphs, step-by-step task decomposition, ETL pipelines, build systems.

2. "swarm" — Complex Adaptive System. Use for: dynamic epistemic node spawning,
   decentralized coordination, spot market routing, multi-agent reinforcement
   learning, crowd-intelligence, parallel exploration.

3. "council" — Social Choice / PBFT Consensus. Use for: multi-expert debate,
   committee voting, jury deliberation, adversarial critique, Byzantine fault
   tolerance, consensus-driven decision making.

4. "evaluator_optimizer" — Actor-Critic / Generator-Discriminator. Use for:
   iterative refinement loops, minimax optimization, adversarial review cycles,
   code review, content editing, dual-process revision.

5. "evolutionary" — Genetic Algorithm / Evolutionary Strategy. Use for:
   gradient-free optimization, population-based search, creative exploration,
   A/B testing at scale, multi-objective optimization, hyperparameter tuning.

6. "digital_twin" — Cyber-Physical Sandbox. Use for: simulation, what-if
   analysis, shadow testing, Monte Carlo rollouts, risk-free experimentation,
   Markov blanket isolation.

7. "smpc" — Secure Multi-Party Computation. Use for: privacy-preserving
   computation, garbled circuits, secret sharing, oblivious transfer, zero-trust
   federated analytics, confidential data collaboration.

8. "macro_adversarial" — Red/Blue Team Adversarial Market. Use for: security
   auditing, penetration testing, red team vs blue team, adversarial debate,
   zero-sum minimax games with adjudication.

9. "macro_federation" — pBFT Consensus Federation. Use for: distributed
   consensus, Sybil-resistant voting, decentralized governance, multi-party
   agreement, blockchain-style quorum.

10. "macro_forge" — Capability Forge (Zero-to-One). Use for: generating new
    tools/capabilities from scratch, code generation + formal verification +
    fuzzing pipelines, bootstrapping new agent skills.

11. "macro_elicitation" — Intent Elicitation. Use for: requirements gathering,
    ambiguous prompt clarification, human-in-the-loop intent distillation,
    multimodal input parsing, metacognitive scanning.

12. "discourse_tree" — Hierarchical Semantic Parsing. Use for: document
    ingestion, recursive semantic decomposition, mapping long texts to local
    attention tree geometries, rhetoric/claim extraction loops.

13. "macro_neurosymbolic" — Proposer/Verifier Theorem Loop. Use for: bridging
    stochastic LLM connections with rigorous DifferentiableLogicPolicy gradients,
    executing deterministic z3/lean4 theorem solvers on proposed code blocks.
"""


class EntropyEscalationError(ValueError):
    """Raised when calculation of Shannon Entropy strictly exceeds the allowed threshold."""


class UniversalCompiler:
    """SOTA 2026 Schema Homogenizer and Autonomic Corrector."""

    @staticmethod
    def compile_schema(schema_class: type[T]) -> dict[str, Any]:
        """Translates Pydantic to strict JSON Schema for the Tensor endpoints."""
        try:
            schema = schema_class.model_json_schema()

            def enforce_strict(s: dict[str, Any]) -> None:
                if s.get("type") == "object" or "properties" in s:
                    s["additionalProperties"] = False

                    props = s.get("properties", {})
                    for prop in props.values():
                        if isinstance(prop, dict):
                            enforce_strict(prop)

                    if "properties" in s and "required" not in s:
                        s["required"] = list(props.keys())
                    elif "properties" in s:
                        s["required"] = list(set(s.get("required", []) + list(props.keys())))

                elif s.get("type") == "array" and "items" in s:
                    if isinstance(s["items"], dict):
                        enforce_strict(s["items"])

            enforce_strict(schema)

            def remove_unsupported(s: dict[str, Any]) -> None:
                s.pop("default", None)
                s.pop("title", None)
                for value in s.values():
                    if isinstance(value, dict):
                        remove_unsupported(value)
                    elif isinstance(value, list):
                        for item in value:
                            if isinstance(item, dict):
                                remove_unsupported(item)

            remove_unsupported(schema)
            return schema

        except Exception as e:
            from coreason_runtime.utils.logger import logger

            logger.exception(f"FSM Compilation failed: {e}")

            msg = f"FSM AST Parse Failure: {e!s}"
            raise RuntimeError(msg) from e

    @staticmethod
    async def validate_and_retry(
        schema_class: type[T],
        llm_callable: Callable[..., Coroutine[Any, Any, tuple[str, dict[str, int], list[float]]]],
        prompt: str,
        max_attempts: int = 100,
        **kwargs: Any,
    ) -> tuple[T, dict[str, int]]:
        """Executes strict schema validation with injected self-correction feedback."""
        current_prompt = prompt
        total_usage = {"prompt_tokens": 0, "completion_tokens": 0}

        has_self_correction = True  # "self_correction" in kwargs
        baseline_entropy_threshold = kwargs.pop("baseline_entropy_threshold", None)
        enable_outlines_fsm = kwargs.pop("enable_outlines_fsm", False)

        for attempt in range(max_attempts):
            # Inject schema_dict required by CloudOracleClient.generate
            call_kwargs = dict(kwargs)
            compiled_schema = UniversalCompiler.compile_schema(schema_class)

            # Autonomically strip out the vector constraint from the System Prompt JSON schema
            def _scrub_schema(s: dict[str, Any]) -> None:
                if "properties" in s:
                    s["properties"].pop("target_epistemic_deficit", None)
                if "required" in s and "target_epistemic_deficit" in s["required"]:
                    s["required"].remove("target_epistemic_deficit")
                if "$defs" in s:
                    for def_schema in s["$defs"].values():
                        if isinstance(def_schema, dict):
                            _scrub_schema(def_schema)

            _scrub_schema(compiled_schema)

            call_kwargs["schema_dict"] = compiled_schema

            raw_response, usage, probabilities = await llm_callable(current_prompt, **call_kwargs)
            total_usage["prompt_tokens"] += usage.get("prompt_tokens", 0)
            total_usage["completion_tokens"] += usage.get("completion_tokens", 0)

            try:
                if baseline_entropy_threshold is not None and probabilities:
                    entropy = -sum(p * math.log2(p) for p in probabilities if p > 0)
                    if entropy > baseline_entropy_threshold:
                        err_msg = (
                            f"Epistemic Yield: Shannon Entropy {entropy:.4f} "
                            f"exceeds threshold {baseline_entropy_threshold}"
                        )
                        raise EntropyEscalationError(err_msg)

                if enable_outlines_fsm:
                    # Fast-path: Outlines mathematically guarantees structural format natively.
                    parsed = json.loads(raw_response)
                    model_instance = schema_class.model_validate(parsed)
                else:
                    import re

                    clean_response = raw_response.strip()
                    match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", clean_response)
                    if match:
                        clean_response = match.group(1).strip()

                    start = clean_response.find("{")
                    if start != -1:
                        try:
                            decoder = json.JSONDecoder()
                            parsed, _ = decoder.raw_decode(clean_response[start:])
                        except json.JSONDecodeError:
                            end = clean_response.rfind("}")
                            if end != -1:
                                fallback_str = clean_response[start : end + 1]
                                import ast

                                try:
                                    parsed = ast.literal_eval(fallback_str)
                                except SyntaxError, ValueError:
                                    parsed = json.loads(fallback_str.replace("'", '"'))
                            else:
                                parsed = json.loads(clean_response)
                    else:
                        parsed = json.loads(clean_response)

                    from pydantic import model_validator

                    class ValidatedLLMPayload(schema_class):  # type: ignore
                        @model_validator(mode="before")
                        @classmethod
                        def enforce_schema_boundary(cls, data: Any) -> Any:
                            if not isinstance(data, dict):
                                return data

                            # Use Pydantic field info instead of manual arbitrary string replace
                            schema_fields = getattr(cls, "model_fields", getattr(schema_class, "__fields__", {}))

                            # Purge hallucinatory keys not present in model fields
                            defined_keys = set(schema_fields.keys())
                            # Explicitly prevent legacy 'type' injection
                            defined_keys.discard("type")
                            if "type" in data:
                                del data["type"]

                            # Pre-map common output fallback targets
                            if "output" in schema_fields and "output" not in data:
                                if "result" in data:
                                    data["output"] = str(data["result"])
                                elif "action" in data:
                                    data["output"] = str(data["action"])

                            for k in list(data.keys()):
                                if k not in defined_keys and k != "output":
                                    data.pop(k, None)

                            if "nodes" in data and isinstance(data["nodes"], dict):
                                new_nodes = {}
                                for k, v in data["nodes"].items():
                                    if isinstance(v, dict):
                                        # Nested agent/system wrapper extraction
                                        agent_inner = v.get("agent")
                                        system_inner = v.get("system")
                                        if isinstance(agent_inner, dict):
                                            v.update(agent_inner)
                                            v.pop("agent", None)
                                        elif isinstance(system_inner, dict):
                                            v.update(system_inner)
                                            v.pop("system", None)

                                        if "topology_class" not in v:
                                            v["topology_class"] = "agent"
                                        if "type" in v:
                                            del v["type"]

                                        if "instructions" in v:
                                            inst_text = str(v["instructions"])
                                            v["description"] = (
                                                v.get("description", "") + f"\n\nInstructions: {inst_text}"
                                                if v.get("description")
                                                else inst_text
                                            )
                                            del v["instructions"]

                                    # Normalize IDs directly without using global replace hacks
                                    clean_k = (
                                        "did:agent:"
                                        + k.replace("_", "")
                                        .replace("macroforge", "macro")
                                        .replace("macroelicitation", "macro")
                                        if not k.startswith("did:")
                                        else k
                                    )
                                    new_nodes[clean_k] = v
                                data["nodes"] = new_nodes

                            # Normalize edges array format
                            if "edges" in data and isinstance(data["edges"], list):
                                normalized = []
                                for e in data["edges"]:
                                    if isinstance(e, list) and len(e) >= 2:
                                        edge_tuple = tuple(e[:2])
                                    elif isinstance(e, dict):
                                        edge_tuple = (e.get("source", ""), e.get("target", ""))
                                    elif isinstance(e, tuple) and len(e) >= 2:
                                        edge_tuple = tuple(e[:2])
                                    else:
                                        edge_tuple = e

                                    # Strip self-cycles
                                    if (
                                        isinstance(edge_tuple, tuple)
                                        and len(edge_tuple) == 2
                                        and edge_tuple[0] == edge_tuple[1]
                                    ):
                                        continue
                                    normalized.append(edge_tuple)
                                data["edges"] = normalized

                            # Inject default graph bounds via schema validation flow
                            if "max_depth" in schema_fields and "max_depth" not in data:
                                data["max_depth"] = 10
                            if "max_fan_out" in schema_fields and "max_fan_out" not in data:
                                data["max_fan_out"] = 5
                            if "adjudicator_id" in schema_fields and "adjudicator_id" not in data:
                                data["adjudicator_id"] = "did:coreason:adjudicator"

                            return data

                    # Intercept and correct specific Pydantic Type-checking hallucinations
                    # to enforce 100% strict JSON conformity
                    if "nodes" in parsed:
                        for node_data in parsed["nodes"].values():
                            # We definitively want Human-in-the-Loop! So we inject the correct schema values!
                            if node_data.get("topology_class") == "human" or node_data.get("type") == "human":
                                # Pydantic schema expects required_attestation at the root of the CognitiveHumanNodeProfile
                                # and it strictly expects an Enum of `fido2_webauthn`, `zk_snark_groth16`, or `pqc_ml_dsa`.
                                node_data["required_attestation"] = "fido2_webauthn"
                                if "timeout_seconds" in node_data:
                                    del node_data["timeout_seconds"]
                                if "human" in node_data:
                                    del node_data["human"]

                    if "information_flow" in parsed and parsed["information_flow"] is not None:
                        # Sanitize hallucinated information flow actions that violate strict zero-trust Enums
                        if "rules" in parsed["information_flow"] and isinstance(
                            parsed["information_flow"]["rules"], list
                        ):
                            for rule in parsed["information_flow"]["rules"]:
                                if isinstance(rule, dict) and rule.get("action") == "allow":
                                    rule["action"] = "redact"
                        if "latent_firewalls" in parsed["information_flow"] and isinstance(
                            parsed["information_flow"]["latent_firewalls"], list
                        ):
                            for fw in parsed["information_flow"]["latent_firewalls"]:
                                if (
                                    isinstance(fw, dict)
                                    and "sae_dictionary_hash" in fw
                                    and isinstance(fw["sae_dictionary_hash"], str)
                                    and len(fw["sae_dictionary_hash"]) != 64
                                ):
                                    import hashlib

                                    fw["sae_dictionary_hash"] = hashlib.sha256(b"dummy").hexdigest()

                    if (
                        "observability" in parsed
                        and parsed["observability"] is not None
                        and "telemetry_backpressure" in parsed["observability"]
                    ):
                        backpressure = parsed["observability"]["telemetry_backpressure"]
                        if (
                            backpressure is not None
                            and "occluded_refresh_rate_hz" in backpressure
                            and backpressure["occluded_refresh_rate_hz"] > 1
                        ):
                            backpressure["occluded_refresh_rate_hz"] = 1

                    if (
                        "target_epistemic_deficit" in parsed
                        and parsed["target_epistemic_deficit"] is not None
                        and "query_vector" in parsed["target_epistemic_deficit"]
                        and parsed["target_epistemic_deficit"]["query_vector"] is not None
                    ):
                        parsed["target_epistemic_deficit"]["query_vector"]["vector_base64"] = "H4sIAAAAAAAACw=="

                    # Automatically fulfill the macro_forge vector constraint locally to prevent LLM token-limit crashes
                    if (
                        "target_epistemic_deficit" not in parsed
                        and hasattr(ValidatedLLMPayload, "model_fields")
                        and "target_epistemic_deficit" in ValidatedLLMPayload.model_fields
                    ):
                        parsed["target_epistemic_deficit"] = {
                            "query_vector": {
                                "vector_base64": "H4sIAAAAAAAACw==",
                                "dimensionality": 128,
                                "model_name": "local-fallback",
                            },
                            "min_isometry_score": 0.8,
                            "required_structural_types": [],
                        }

                    # By dumping to strict JSON string mathematically first, Pydantic's strict JSON parser
                    # naturally coerces payload strings into internal python StrEnum classes without violating strict=True
                    if not enable_outlines_fsm:
                        model_instance = ValidatedLLMPayload.model_validate_json(json.dumps(parsed))

                # EpistemicRewardModelPolicy evaluation hook
                if kwargs.get("epistemic_reward_policy"):
                    policy = kwargs["epistemic_reward_policy"]
                    threshold = policy.get("baseline_threshold", 0.5) if isinstance(policy, dict) else 0.5

                    if probabilities:
                        avg_prob = sum(probabilities) / len(probabilities)
                        if avg_prob < threshold:
                            msg = (
                                f"EpistemicRewardModelPolicy Failed: Confidence "
                                f"({avg_prob:.2f}) below threshold ({threshold})."
                            )
                            raise ValueError(msg)
                        logger.info(f"Epistemic reward validation passed with confidence {avg_prob:.2f}")
                    else:
                        logger.warning(
                            "EpistemicRewardModelPolicy invoked but no token probabilities returned by Cloud Oracle."
                        )

                return model_instance, total_usage
            except (json.JSONDecodeError, ValidationError, ValueError) as e:
                import traceback

                tb_str = traceback.format_exc()

                logger.warning(f"Validation or Epistemic failure on attempt {attempt + 1}: {e}")
                if attempt == max_attempts - 1 or not has_self_correction:
                    if kwargs.get("fallback_on_failure"):
                        logger.error("Fallback active: Returning raw unvalidated dictionary instead of crashing.")
                        return parsed, total_usage
                    msg = f"Epistemic Collapse: Failed to resolve execution after {attempt + 1} attempts: {e}"
                    raise ValueError(msg) from e

                # Autonomic Self-Correction
                logger.info("Executing Self-Correction loop via SelfCorrectionPolicy")
                current_prompt += (
                    f"\n\nSystem Error: Your previous response failed Pydantic validation.\n"
                    f"Error Context:\n{e}\nTraceback:\n{tb_str}\n"
                    "CRITICAL: Do not blindly guess. Before writing the JSON, you MUST use one sentence "
                    "to analyze exactly why the parser rejected your previous response. Then, "
                    "correct the issue and return ONLY valid JSON matching the schema."
                )

        msg = "Unreachable"
        raise ValueError(msg)

    @staticmethod
    def extract_type_hints(schema: Any, seen: set[int] | None = None) -> dict[str, Any] | str:
        if seen is None:
            seen = set()
        if id(schema) in seen:
            return "Recursive Schema Reference"
        seen.add(id(schema))
        hints = {}
        schema_fields = getattr(schema, "model_fields", None)
        if schema_fields is not None:
            for k, v in schema_fields.items():
                if k in ["type", "nodes", "edges"]:
                    continue
                hints[k] = {"required": v.is_required()}

                # Unpack optional types
                ann = v.annotation
                from typing import Union, get_args, get_origin

                if get_origin(ann) is Union:
                    args = get_args(ann)
                    ann = next((a for a in args if a and getattr(a, "__name__", "") != "NoneType"), ann)

                if getattr(ann, "model_fields", None) is not None:
                    hints[k]["schema"] = UniversalCompiler.extract_type_hints(ann, set(seen))
                else:
                    hints[k]["type"] = getattr(ann, "__name__", str(ann).replace("typing.", ""))
        return hints

    @classmethod
    async def synthesize_manifest(
        cls,
        user_prompt: str,
        thinking_callable: Callable[..., Coroutine[Any, Any, tuple[str, dict[str, int], list[float]]]],
        typing_callable: Callable[..., Coroutine[Any, Any, tuple[str, dict[str, int], list[float]]]],
        *,
        topology_hint: str | None = None,
        max_epistemic_nodes: int | None = None,
        domain_context: str | None = None,
    ) -> tuple[Any, dict[str, int]]:
        """
        EPISTEMIC NODE INSTRUCTION: Orchestrate the Brain/Hands hybrid flow.
        Phase 1 (Thinking) uses the massive semantic context of Tier 2.
        Phase 2 (Typing) uses the rigid physical logit masking of Tier 0.

        Uses a two-phase FSM-constrained decoding approach:
          Phase 1 — Topology Selection: LLM selects the optimal topology type
                    from all 11 supported types based on domain triggers.
                    **Skipped** if `topology_hint` is provided.
          Phase 2 — Manifest Generation: FSM-constrained decoding against
                    the resolved concrete Pydantic schema class.

        Args:
            user_prompt: The raw natural-language task description.
            thinking_callable: Tier 2 Cloud reasoning callable.
            typing_callable: Tier 0 Native FSM constrained physical callable.
            topology_hint: If provided, bypasses Phase 1 and uses this type directly.
            max_epistemic_nodes: Optional cap on agent count injected into the prompt.
            domain_context: Optional domain-specific context for richer synthesis.

        Returns:
            A tuple of (validated topology manifest instance, usage dict).
        """
        total_usage: dict[str, int] = {"prompt_tokens": 0, "completion_tokens": 0}

        # ── Phase 1: Topology Selection (skipped if hint provided) ────────
        if topology_hint is not None:
            selected_type = topology_hint
            architectural_intent = f"User-specified topology: {topology_hint}"
            detailed_blueprint = "No detailed blueprint provided natively due to explicit topology hint override."
            logger.info(f"Phase 1 skipped — user provided topology_hint: {selected_type}")
        else:
            selection_prompt = (
                "You are a CoReason Meta-Orchestrator Topology Selector.\n"
                "Given the user's task, select the single best topology type.\n\n"
                f"{_TOPOLOGY_CATALOG}\n"
                "Rules:\n"
                "1. Analyze the user's intent and match it to a topology.\n"
                "2. 'selected_type' MUST be one of the exact string literals above.\n"
                "3. 'architectural_intent' must explain WHY this topology is optimal.\n"
                "4. 'detailed_blueprint' MUST contain a 3-paragraph highly detailed blueprint for every agent node.\n"
                "5. Return ONLY a valid JSON object.\n"
                "6. CRITICAL JSON FORMATTING: You must absolutely NOT use physical newline characters in your strings. Use \\n to represent newlines inside string values.\n\n"
                f"User Task: {user_prompt}"
            )

            selection_result, phase1_usage = await cls.validate_and_retry(
                schema_class=TopologySelectionResult,
                llm_callable=thinking_callable,
                prompt=selection_prompt,
                max_attempts=3,
                self_correction=True,
            )
            total_usage["prompt_tokens"] += phase1_usage.get("prompt_tokens", 0)
            total_usage["completion_tokens"] += phase1_usage.get("completion_tokens", 0)

            selected_type = selection_result.selected_type
            architectural_intent = selection_result.architectural_intent
            detailed_blueprint = selection_result.detailed_blueprint
            logger.info(
                f"Phase 1 complete — selected topology: {selected_type}, intent: {architectural_intent[:80]}..."
            )

        # ── Phase 2: Full Manifest Generation ────────────────────────────
        registry = _build_topology_class_registry()
        schema_class = registry.get(selected_type)
        if schema_class is None:
            msg = (
                f"Topology type '{selected_type}' resolved but has no registered "
                f"Pydantic class. Available: {list(registry.keys())}"
            )
            raise ValueError(msg)

        # Build domain-enriched Phase 2 prompt
        extra_rules = []
        if max_epistemic_nodes is not None:
            extra_rules.append(f"- Generate at most {max_epistemic_nodes} agent nodes in the 'topology.nodes' dict.")
        if domain_context:
            extra_rules.append(f"- Domain context to incorporate:\n{domain_context}")
        extra_rules_str = "\n".join(extra_rules)

        import hashlib
        import os
        import typing

        from coreason_manifest import WorkflowManifest
        from pydantic import Field, create_model

        # Dynamically mute the strictness of target_epistemic_deficit so Pydantic stops
        # punishing the LLM for not hallucinating vector hashes.
        if "target_epistemic_deficit" in schema_class.model_fields:
            safe_schema_class = create_model(
                f"Safe_{schema_class.__name__}",
                __base__=schema_class,
                target_epistemic_deficit=(typing.Any | None, Field(default=None)),
            )
        else:
            safe_schema_class = schema_class

        constrained_manifest = create_model(
            f"ConstrainedWorkflowManifest_{selected_type}",
            __base__=WorkflowManifest,
            request_cid=(str, Field(default_factory=lambda: hashlib.sha256(os.urandom(32)).hexdigest()[:16])),
            topology=(safe_schema_class, Field(...)),
            epistemic_ledger_cids=(list[str], Field(default_factory=list)),
        )

        extracted_props = UniversalCompiler.extract_type_hints(constrained_manifest)
        if isinstance(extracted_props, dict):
            # Scrub it from the root if it was flattened
            extracted_props.pop("target_epistemic_deficit", None)

            # Scrub it from the topology envelope level
            if "topology" in extracted_props and isinstance(extracted_props["topology"], dict):
                extracted_props["topology"].pop("target_epistemic_deficit", None)

                # Scrub it if there is natively a nested schema block
                topology_schema = extracted_props["topology"].get("schema", {})
                if isinstance(topology_schema, dict):
                    topology_schema.pop("target_epistemic_deficit", None)

        forge_rules = ""
        if selected_type == "macro_forge":
            forge_rules = (
                "9. CRITICAL FORGE RULES:\n"
                "   - The generator node MUST write production-ready, fully-executable source code.\n"
                "   - The generator node MUST NEVER output placeholders (e.g., 'TODO', 'pass', '...').\n"
                "   - The generator node MUST include strict Python type-hints and robust try/except error handling.\n"
                "   - The formal_verifier node MUST be instructed: 'Do NOT validate the JSON wrapper. "
                "Your ONLY job is to evaluate the source code logic for bugs, returning success=True "
                "if the code works flawlessly.'\n"
            )
        elif selected_type == "macro_neurosymbolic":
            forge_rules = (
                "9. CRITICAL NEUROSYMBOLIC RULES:\n"
                "   - You MUST extract exactly two node ids from the detailed blueprint and map them precisely to 'proposer_node_cid' and 'verifier_node_cid'.\n"
                "   - The topology must enforce a strictly bipartite ping-pong graph between those nodes.\n"
            )

        # Create a clean visual template for the LLM instead of a confusing Pydantic Schema dump
        template_hint = {}
        if isinstance(extracted_props, dict):
            for k, v in extracted_props.items():
                if isinstance(v, dict):
                    t = v.get("type", v.get("anyOf", ["Any"])[0])
                    desc = v.get("title", v.get("description", ""))
                    template_hint[k] = f"<{t}> // {desc}"
                else:
                    template_hint[k] = "<Any>"
        else:
            template_hint = {"raw_schema": str(extracted_props)}

        manifest_prompt = (
            "You are a CoReason Meta-Orchestrator JSON Typist.\n"
            f"Generate a complete '{selected_type}' topology manifest.\n\n"
            f"Architectural Intent: {architectural_intent}\n"
            f"Detailed Blueprint: {detailed_blueprint}\n\n"
            "CRITICAL INSTRUCTIONS:\n"
            "0. DO NOT under any circumstances output markdown formatting like ```json ...```.\n"
            "1. You MUST output raw, pure, parsable JSON text.\n"
            "2. Ensure all arrays have trailing commas removed.\n"
            "3. Do not include comments inside the JSON.\n"
            "3.5. CRITICAL JSON FORMATTING: Do NOT use physical newline characters in your strings. Use \\n to represent newlines.\n"
            "4. Your sole job is Structural Mapping. Map the detailed blueprint strictly into the schema.\n"
            "5. Fill all topology-specific fields required by the schema "
            "(edges, adjudicator_id, participant_node_cids, etc.).\n"
            "6. Return ONLY a valid JSON object matching the EXACT Schema Constraints outlined below.\n"
            "7. REQUIRED TOPOLOGY PROPERTIES TEMPLATE:\n"
            f"{json.dumps(template_hint, indent=2)}\n"
            "8. ANTI-CRUD: Do NOT use legacy terms like 'Create', 'Update', 'Delete', 'Manager' in node names. Use causal terms (e.g., 'Synthesizer', 'Transmuter', 'Validator').\n"
            "9. OCCAM'S RAZOR FOR NODES: Do NOT generate unnecessary 'system', 'human', or 'evaluator' nodes unless explicitly requested. A single standalone 'agent' node is highly preferred for standard tool execution.\n"
            "10. CRITICAL SCHEMA INSTRUCTION: DO NOT regurgitate python schema syntax. For example, if the template says 'consensus_policy': '<float>', DO NOT output a dictionary. Output exactly the primitive floating point number: 'consensus_policy': 0.85\n"
            f"{extra_rules_str}\n"
            f"{forge_rules}\n"
            f"User Task: {user_prompt}"
        )

        manifest_instance, phase2_usage = await cls.validate_and_retry(
            schema_class=constrained_manifest,
            llm_callable=typing_callable,
            prompt=manifest_prompt,
            system_prompt="You are the Universal Workflow Co-reasoning Node. Synthesize pure DAG orchestration directives precisely enforcing physical and epistemic constraints.",
            max_retries=100,
            enable_outlines_fsm=True,
        )
        total_usage["prompt_tokens"] += phase2_usage.get("prompt_tokens", 0)
        total_usage["completion_tokens"] += phase2_usage.get("completion_tokens", 0)

        node_count = len(getattr(getattr(manifest_instance, "topology", None), "nodes", {}))
        logger.info(f"Phase 2 complete — '{selected_type}' manifest synthesized with {node_count} nodes")

        return manifest_instance, total_usage
