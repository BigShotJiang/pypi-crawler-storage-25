# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: https://github.com/CoReason-AI/coreason-runtime

"""Edge Native WASM/GGUF Client.

Facilitates zero-trust, offline-capable tensor inference using heavily quantized
micro-models (GGUF). Runs natively on edge devices leveraging WebAssembly (WasmEdge/TVM)
or llama.cpp bindings.

Features robust offline buffering for Epistemic Ledgers using local CRDT-sync structures
to handle `asyncio.TimeoutError` when the P2P Gossip network is unreachable.
"""

import asyncio
import json
import sqlite3
import time
from contextlib import closing
from typing import Any

from loguru import logger


class EdgeKineticClient:
    """Offline-capable WASM inference backend for edge nodes."""

    def __init__(self, model_uri: str, max_vram_buffer_bytes: int = 4 * 1024**3) -> None:
        """Initialize local WASM/llama.cpp inference runtime.

        Args:
            model_uri: The local file path or URI to the GGUF model.
            max_vram_buffer_bytes: The strict memory limit for the edge hardware.
        """
        self.model_uri = model_uri
        self.max_vram_buffer_bytes = max_vram_buffer_bytes
        self._local_db_path = "/tmp/coreason_edge_buffer.sqlite"  # noqa: S108  # nosec B108

        logger.info(f"[EdgeRuntime] Initializing WASM Inference Client with model: {model_uri}")
        logger.debug(f"[EdgeRuntime] Hardware VRAM limit strictly enforced to {max_vram_buffer_bytes / 1024**3:.2f}GB")

        self._init_local_buffer()
        # Simulate loading the GGUF into memory
        self._load_model_into_wasm()

    def _init_local_buffer(self) -> None:
        """Initialize the local SQLite database for offline buffering (CRDT simulation)."""
        with closing(sqlite3.connect(self._local_db_path)) as conn, conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS local_ledger (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT,
                    payload TEXT,
                    timestamp REAL,
                    synced INTEGER DEFAULT 0
                )
                """
            )

    def _load_model_into_wasm(self) -> None:
        """Loads the weights into the WASM runtime. Mocked for this phase."""
        logger.debug("[EdgeRuntime] Loading GGUF weights into WASM sandbox context...")
        # Simulating llama_model_load_from_file

    async def buffer_offline_event(self, event_type: str, payload: dict[str, Any]) -> None:
        """Stores disconnected events when the mainnet is unreachable."""
        logger.warning(f"[EdgeRuntime] Gossip network unreachable! Buffering {event_type} locally.")
        with closing(sqlite3.connect(self._local_db_path)) as conn, conn:
            conn.execute(
                "INSERT INTO local_ledger (event_type, payload, timestamp) VALUES (?, ?, ?)",
                (event_type, json.dumps(payload), time.time()),
            )

    async def execute_local_inference(
        self, _prompt: str, _schema_requirement: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Execute inference purely locally on the edge hardware.

        Applies a local C++ compiled XGrammar if `schema_requirement` is present
        to ensure Output-Constraint compliance natively.
        """
        logger.info("[EdgeRuntime] Executing offline tensor iteration (WASM)...")

        try:
            # Simulate local processing delay
            await asyncio.sleep(0.5)

            # Simulated output
            result_payload = {"status": "success", "text": "edge_native_response", "reasoning_steps": []}

            # Emit telemetry for the burn
            burn_receipt = {"tokens": 120, "cost": 0.0, "node": "edge-kinetic-wasm"}

            # Attempt to emit observation to network, but simulate timeout occasionally
            # In Phase 15 we are testing offline capabilities. We will trigger the buffer manually for demonstration.
            try:
                # Mock temporal networking attempt
                msg = "Offline mode activated"
                raise TimeoutError(msg)
            except TimeoutError:
                await self.buffer_offline_event("TokenBurnReceipt", burn_receipt)
                await self.buffer_offline_event("ObservationEvent", result_payload)

            return result_payload

        except Exception as e:
            logger.error(f"[EdgeRuntime] Fatal fault in WASM execution execution: {e}")
            raise
