# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>


from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from coreason_manifest.spec.ontology import (
        ActivationSteeringContract,
    )

from coreason_runtime.utils.exceptions import ManifestConformanceError


class MechanisticSteeringEngine:
    """Translates macro topological constraints directly to mathematical physical tensor interventions."""

    @staticmethod
    def construct_tensor_payload(
        contract: ActivationSteeringContract, hardware_supports_latent: bool
    ) -> dict[str, Any]:
        """Translates the semantic contract mathematically mapping bounds to the execution fabric natively.

        Args:
            contract: The AST-verified activation steering payload organically.
            hardware_supports_latent: Represents whether physical backend supports latent manipulation securely.

        Raises:
            ManifestConformanceError: If hardware does not mathematically support deep manipulation natively.

        Returns:
            The raw backend injection payload mapping dimensions perfectly.
        """
        if not hardware_supports_latent:
            msg = "Hardware framework failure: Cloud API layer does not expose native forward pass interventions."
            raise ManifestConformanceError(msg)

        injection_layers = getattr(contract, "target_layers", getattr(contract, "injection_layers", []))
        scaling_factor = getattr(contract, "scaling_factor", 1.0)
        sae_hash = getattr(contract, "sae_dictionary_hash", "default-hash")

        return {
            "mechanistic_backend": "physical_sglang_intercept",
            "injection_layers": injection_layers,
            "scaling_factor": scaling_factor,
            "sae_dictionary_hash": sae_hash,
            "latent_clamp_bounds": [-10.0, 10.0],
        }
