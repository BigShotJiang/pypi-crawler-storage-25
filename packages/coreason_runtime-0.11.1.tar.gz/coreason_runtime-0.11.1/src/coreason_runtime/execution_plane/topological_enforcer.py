# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from typing import TYPE_CHECKING

from temporalio.exceptions import ApplicationError

if TYPE_CHECKING:
    from coreason_manifest import CognitiveActionSpaceManifest


class TopologicalEnforcer:
    """Enforces kinetic separation policies on action spaces."""

    def __init__(self, manifest: CognitiveActionSpaceManifest) -> None:
        """Initialize the enforcer with a hydrated manifest."""
        self.manifest = manifest

    def validate_kinetic_separation(self, requested_tool: str, kinetic_trace: list[str]) -> None:
        """Validate that the requested tool does not violate kinetic separation policies."""
        if not self.manifest.kinetic_separation:
            return

        clusters = self.manifest.kinetic_separation.mutually_exclusive_clusters
        if not clusters:
            return

        for cluster in clusters:
            if requested_tool in cluster:
                # Find the intersection between the cluster and the kinetic trace
                trace_set = set(kinetic_trace)
                cluster_set = set(cluster)
                intersection = trace_set.intersection(cluster_set)

                if intersection:
                    msg = (
                        f"Bipartite violation: Tool '{requested_tool}' cannot be executed "
                        f"because mutually exclusive capabilities "
                        f"{list(intersection)} have already been utilized in this execution trace."
                    )
                    raise ApplicationError(
                        msg,
                        type="SemanticFirewallPolicyError",
                        non_retryable=True,
                    )

    def validate_mdp_transition(self, requested_tool: str, kinetic_trace: list[str], current_budget: float) -> float:
        """Validate MDP transitions and calculate the new thermodynamic budget."""
        # Step A: Validate capabilities exist
        if not self.manifest.capabilities or requested_tool not in self.manifest.capabilities:
            msg = f"Capability violation: Tool '{requested_tool}' is missing from action space capabilities."
            raise ApplicationError(
                msg,
                type="SemanticFirewallPolicyError",
                non_retryable=True,
            )

        # Step B: Genesis State
        if not kinetic_trace:
            if requested_tool != self.manifest.entry_point_cid:
                msg = (
                    f"Genesis violation: Requested tool '{requested_tool}' does not match "
                    f"entry_point_cid '{self.manifest.entry_point_cid}'."
                )
                raise ApplicationError(
                    msg,
                    type="SemanticFirewallPolicyError",
                    non_retryable=True,
                )
            return current_budget

        # Step C: Edge Traversal
        previous_tool = kinetic_trace[-1]
        transitions = self.manifest.transition_matrix.get(previous_tool, []) if self.manifest.transition_matrix else []

        target_edge = None
        for edge in transitions:
            if getattr(edge, "target_node_cid", None) == requested_tool:
                target_edge = edge
                break

        if not target_edge:
            msg = f"Ghost Path violation: No edge exists between '{previous_tool}' and '{requested_tool}'."
            raise ApplicationError(
                msg,
                type="SemanticFirewallPolicyError",
                non_retryable=True,
            )

        # Step D: Thermodynamics
        compute_weight = float(getattr(target_edge, "compute_weight_magnitude", 0.0))
        discount = getattr(target_edge, "discount_factor", None)
        if discount is not None:
            new_budget = float((current_budget * float(discount)) - compute_weight)
        else:
            new_budget = float(current_budget - compute_weight)

        # Step E: Halting Problem
        if new_budget < 0:
            msg = f"Thermodynamic exhaustion: New budget {new_budget} is below zero."
            raise ApplicationError(
                msg,
                type="BudgetExceededError",
                non_retryable=True,
            )

        return new_budget
