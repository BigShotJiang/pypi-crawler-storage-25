# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import asyncio
from typing import Any

from coreason_runtime.utils.logger import logger

from .mcp_transport_client import MCPTransportClient


class RetryingMCPClient(MCPTransportClient):
    """Decorator pattern to add standard exponential backoff retries."""

    def __init__(self, client: MCPTransportClient, max_retries: int = 3, base_delay: float = 1.0):
        self.client = client
        self.max_retries = max_retries
        self.base_delay = base_delay

    async def request(self, method: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        for attempt in range(self.max_retries + 1):
            try:
                return await self.client.request(method, params)
            except Exception as e:
                if attempt == self.max_retries:
                    logger.exception(f"MCP request failed after {self.max_retries} retries: {e}")
                    raise
                delay = self.base_delay * (2**attempt)
                logger.warning(f"MCP request failed, retrying in {delay}s: {e}")
                await asyncio.sleep(delay)
        msg = "Unreachable"
        raise RuntimeError(msg)
