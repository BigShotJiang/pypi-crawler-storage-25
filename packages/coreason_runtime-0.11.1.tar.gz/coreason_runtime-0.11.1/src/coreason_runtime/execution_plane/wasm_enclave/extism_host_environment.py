# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import json
from typing import TYPE_CHECKING, Any

import extism  # type: ignore[import-untyped]
from loguru import logger

from coreason_runtime.execution_plane.wasm_enclave.bell_lapadula_monitor import (  # pyre-ignore[21]
    LatticeReferenceMonitor,
    TaintLevel,
)
from coreason_runtime.utils.exceptions import ManifestConformanceError, SecurityViolationError  # pyre-ignore[21]

if TYPE_CHECKING:
    from pathlib import Path

MAX_ALLOCATION_BYTES = 10485760
SecurityClearanceViolation = SecurityViolationError


class ExtismWasmEnclave:
    """AGENT INSTRUCTION: Instantiates a zero-trust Extism WebAssembly boundary for untrusted exogenous tools.

    CAUSAL AFFORDANCE: Executes physical third-party binaries without compromising host system variables.

    EPISTEMIC BOUNDS: Enforces a strict 10MB allocation memory trap and Bell-LaPadula LBAC taint tracking.

    MCP ROUTING TRIGGERS: wasm_sandbox, extism_enclave, zero_trust_execution, lattice_based_access_control
    """

    def __init__(self) -> None:
        """Initialize the Enclave structure."""
        self.plugin: extism.Plugin | None = None

    def initialize_plugin(self, wasm_path: Path, manifest: dict[str, Any] | None = None) -> None:
        """Scaffold and initialize the extism plugin natively."""
        try:
            with open(wasm_path, "rb") as f:
                wasm_bytes = f.read()

            self.initialize_from_bytes(wasm_bytes, manifest)
        except Exception as e:
            msg = f"Plugin initialization trap: {e}"
            raise ManifestConformanceError(msg) from e

    def initialize_from_bytes(self, wasm_bytes: bytes, manifest: dict[str, Any] | None = None) -> None:
        """Scaffold and initialize the extism plugin natively directly from bytes."""
        try:
            plugin_manifest = {"wasm": [{"data": wasm_bytes}]}
            if manifest:
                plugin_manifest.update(manifest)

            self.plugin = extism.Plugin(plugin_manifest)
            logger.info("Initialized Extism plugin from bytes")
        except extism.Error as e:
            logger.error(f"Failed to initialize extism plugin: {e}")
            msg = f"Plugin initialization trap: {e}"
            raise ManifestConformanceError(msg) from e

    def execute_intent(
        self, function_name: str, intent: dict[str, Any], sink_clearance: TaintLevel = TaintLevel.PUBLIC
    ) -> dict[str, Any]:
        """Execute intent mappings bridging zero-trust execution bounds."""
        if not self.plugin:
            msg = "Extism plugin not initialized."
            raise ManifestConformanceError(msg)

        # LBAC: Dynamic Taint Ingestion from native dictionary
        clearance_val = None
        state_vector = intent.get("state_vector")
        governance = intent.get("governance")

        if isinstance(state_vector, dict):
            clearance_val = state_vector.get("clearance")
        elif isinstance(governance, dict):
            clearance_val = governance.get("clearance")

        try:
            if isinstance(clearance_val, str):
                thread_taint = getattr(TaintLevel, clearance_val)
            elif isinstance(clearance_val, int):
                thread_taint = TaintLevel(clearance_val)
            else:
                thread_taint = TaintLevel.CONFIDENTIAL
        except ValueError, AttributeError:
            thread_taint = TaintLevel.CONFIDENTIAL

        try:
            intent_json = json.dumps(intent)
            logger.debug(f"Executing intent across Wasm boundary into function {function_name}")
            output_bytes = self.plugin.call(function_name, intent_json.encode("utf-8"))

            if len(output_bytes) > MAX_ALLOCATION_BYTES:
                msg = f"Memory Trap: output payload {len(output_bytes)} exceeds {MAX_ALLOCATION_BYTES} bytes."
                raise ManifestConformanceError(msg)

            LatticeReferenceMonitor.verify_write_down(thread_taint, sink_clearance)

            import typing

            return typing.cast("dict[str, Any]", json.loads(output_bytes.decode("utf-8")))

        except extism.Error as e:
            logger.error(f"Wasm guest trapped or panicked: {e}")
            msg = f"Extism execution trap: {e}"
            raise ManifestConformanceError(msg) from e
        except SecurityClearanceViolation:
            raise
        except json.JSONDecodeError as e:
            logger.error(f"Wasm guest returned invalid JSON payload: {e}")
            msg = f"JSON violation returning from Wasm: {e}"
            raise ManifestConformanceError(msg) from e
        except Exception as e:
            logger.error(f"Unexpected execution wrapper violation: {e}")
            msg = f"Execution wrapped failure: {e}"
            raise ManifestConformanceError(msg) from e
