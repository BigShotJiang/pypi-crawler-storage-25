# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import asyncio
import contextlib
import datetime
import time
import uuid
from typing import TYPE_CHECKING, Any, Literal, TypeVar

import httpx
from coreason_manifest import EpistemicTelemetryEvent, ExecutionSpanReceipt, TraceContextState, TraceExportManifest
from temporalio import workflow

from coreason_runtime.utils.logger import logger
from coreason_runtime.utils.settings import COREASON_KEEPALIVE_CONNECTIONS, COREASON_MAX_CONNECTIONS

if TYPE_CHECKING:
    from collections.abc import Callable, Coroutine

T = TypeVar("T")


class TelemetryEmitter:
    """
    SOTA 2026 Telemetry Matrix.
    Provides a multiplexed, thermodynamically bounded conduit for Swarm observability.
    """

    def __init__(self, broker_url: str) -> None:
        if not broker_url:
            logger.warning("TELEMETRY_BROKER_URL is empty. Telemetry will be routed to localhost fallback.")
            broker_url = "http://localhost:8000"

        self.push_endpoint = f"{broker_url.rstrip('/')}/api/v1/telemetry/push"

        # 1. The Persistent Multiplexed Conduit (Socket Bounding)
        limits = httpx.Limits(
            max_keepalive_connections=COREASON_KEEPALIVE_CONNECTIONS, max_connections=COREASON_MAX_CONNECTIONS
        )
        self.client = httpx.AsyncClient(limits=limits, timeout=10.0)

        # 2. Thermodynamic Backpressure (The Ring-Buffer)
        self.queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue(maxsize=1000)
        self._flush_task: asyncio.Task[None] | None = None

    async def start(self) -> None:
        """Ignite the background flusher daemon."""
        if self._flush_task is None:
            self._flush_task = asyncio.create_task(self._flush_queue())
            logger.info(f"Telemetry Matrix engaged. Routing to: {self.push_endpoint}")

    async def close(self) -> None:
        """Gracefully terminate the matrix, flushing remaining events."""
        if self._flush_task:
            self._flush_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._flush_task
        await self.client.aclose()
        logger.info("Telemetry Matrix safely terminated.")

    async def _flush_queue(self) -> None:
        """Background daemon to multiplex telemetry payloads over the network."""
        while True:
            try:
                payload = await self.queue.get()
                try:
                    await self.client.post(self.push_endpoint, json=payload)
                except Exception as e:
                    # Fail silently to avoid blocking kinetic execution (Sensory yield)
                    logger.exception(f"Silently ignored error during matrix flush: {e}")
                finally:
                    self.queue.task_done()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception(f"Matrix flush error: {e}")

    def _enqueue_payload(self, payload: dict[str, Any]) -> None:
        """Ring-buffer enqueue mechanism with Autonomic Load Shedding."""
        try:
            self.queue.put_nowait(payload)
        except asyncio.QueueFull:
            # Shed load: violently drop the oldest sensory frame to prevent OOM
            try:
                self.queue.get_nowait()
                self.queue.task_done()
                self.queue.put_nowait(payload)
                logger.warning("Telemetry Matrix saturated. Executing Autonomic Load Shedding (dropping frame).")
            except asyncio.QueueEmpty, asyncio.QueueFull:
                pass  # Absolute failure absorption

    def emit_event(self, event_payload: dict[str, Any]) -> None:
        """Public conduit for routing arbitrary telemetry.events into the matrix."""
        self._enqueue_payload(event_payload)

    def emit_suspension(
        self,
        workflow_id: str,
        agent_name: str,
        reason: Literal["schema_violation", "oracle_required", "budget_exceeded", "execution_panic"],
        latent_state: dict[str, Any],
        failed_intent: dict[str, Any] | None = None,
    ) -> None:
        """Emit a signal indicating an agent has yielded execution."""
        event = {
            "type": "AgentSuspendedEvent",
            "workflow_id": workflow_id,
            "agent_name": agent_name,
            "suspension_reason": reason,
            "latent_state": latent_state,
            "failed_intent": failed_intent,
        }
        self._enqueue_payload(event)

    def emit_resumption(self, workflow_id: str, agent_name: str) -> None:
        """Emit a signal indicating an agent has resumed execution."""
        event = {
            "type": "AgentResumedEvent",
            "workflow_id": workflow_id,
            "agent_name": agent_name,
            "timestamp": datetime.datetime.now(datetime.UTC).isoformat(),
        }
        self._enqueue_payload(event)

    def emit_span(self, span: ExecutionSpanReceipt) -> None:
        """Emit a fully validated OpenTelemetry execution span receipt."""
        self._enqueue_payload({"type": "ExecutionSpanReceipt", "span": span.model_dump(mode="json")})

    def emit_epistemic_telemetry(self, event: EpistemicTelemetryEvent) -> None:
        """Emit an EpistemicTelemetryEvent to capture verifiable state changes from agent circuits."""
        self._enqueue_payload({"type": "EpistemicTelemetryEvent", "event": event.model_dump(mode="json")})

    def export_traces(self, batch_id: str, spans: list[ExecutionSpanReceipt]) -> None:
        """Export a batch of spans using the TraceExportManifest so causality propagates across federated sub-swarms."""
        manifest = TraceExportManifest(batch_cid=batch_id, spans=spans)
        self._enqueue_payload({"type": "TraceExportManifest", "manifest": manifest.model_dump(mode="json")})

    async def wrap_execution_block(
        self,
        name: str,
        kind: Literal["internal", "server", "client", "producer", "consumer"],
        block: Callable[[], Coroutine[Any, Any, T]],
        trace_context: TraceContextState | None = None,
    ) -> T:
        """Wrap an execution block (activity/workflow step) in an OTLP-parity span."""
        is_workflow = False
        with contextlib.suppress(Exception):
            is_workflow = workflow.in_workflow()

        def _get_time_ns() -> int:
            if is_workflow:
                try:
                    return workflow.time_ns()
                except Exception:  # noqa: S110  # nosec B110
                    pass
            return time.time_ns()

        def _get_uuid() -> str:
            if is_workflow:
                # Temporal workflows must maintain deterministic generation
                # Fallback to standard v4 determinism if workflow doesn't support v7 natively
                return str(workflow.uuid4())
            return str(uuid.uuid7())

        if trace_context:
            trace_id = trace_context.trace_cid
            parent_span_id = trace_context.span_cid
        else:
            # Fallback if trace context is missing
            trace_id = _get_uuid()
            parent_span_id = None

        span_id = _get_uuid()

        start_time = _get_time_ns()
        span = ExecutionSpanReceipt(
            trace_cid=trace_id,
            span_cid=span_id,
            parent_span_cid=parent_span_id,
            name=name,
            kind=kind,
            start_time_unix_nano=start_time,
            status="unset",
        )

        status_val: Literal["ok", "error", "unset"] = "unset"
        try:
            result = await block()
            status_val = "ok"
            return result
        except asyncio.CancelledError:
            status_val = "error"
            raise
        except Exception as e:
            logger.exception(f"Error wrapping execution block '{name}': {e}")
            status_val = "error"
            from coreason_manifest.spec.ontology import SpanEvent

            span.events.append(
                SpanEvent(
                    name="exception",
                    timestamp_unix_nano=_get_time_ns(),
                    attributes={"exception.message": str(e), "exception.type": type(e).__name__},
                )
            )
            raise
        finally:
            final_span = ExecutionSpanReceipt(
                trace_cid=span.trace_cid,
                span_cid=span.span_cid,
                parent_span_cid=span.parent_span_cid,
                name=span.name,
                kind=span.kind,
                start_time_unix_nano=span.start_time_unix_nano,
                end_time_unix_nano=_get_time_ns(),
                status=status_val,
                events=span.events,
            )
            self.emit_span(final_span)
