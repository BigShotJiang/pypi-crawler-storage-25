# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import concurrent.futures
import dataclasses
import os

os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["ARROW_DEFAULT_MEMORY_POOL"] = "system"
os.environ["OBJC_DISABLE_INITIALIZE_FORK_SAFETY"] = "YES"
import faulthandler

faulthandler.enable()

import contextlib  # noqa: E402
from typing import Any  # noqa: E402

from temporalio.client import Client  # noqa: E402
from temporalio.worker import UnsandboxedWorkflowRunner, Worker  # noqa: E402
from temporalio.worker.workflow_sandbox import SandboxRestrictions  # noqa: E402

from coreason_runtime.orchestration.activities import KineticActivities  # noqa: E402
from coreason_runtime.orchestration.workflows import (  # noqa: E402
    ActiveInferenceExecutionWorkflow,
    AdversarialMarketExecutionWorkflow,
    CapabilityForgeExecutionWorkflow,
    ConsensusFederationExecutionWorkflow,
    CouncilExecutionWorkflow,
    DAGExecutionWorkflow,
    DigitalTwinExecutionWorkflow,
    DiscourseTreeExecutionWorkflow,
    DocumentKnowledgeGraphExecutionWorkflow,
    DynamicRoutingExecutionWorkflow,
    EpistemicSOPExecutionWorkflow,
    EvaluatorOptimizerExecutionWorkflow,
    EvolutionaryExecutionWorkflow,
    HierarchicalDOMExecutionWorkflow,
    HollowPlaneBridgeWorkflow,
    IntentElicitationExecutionWorkflow,
    IntentRenegotiationExecutionWorkflow,
    NeurosymbolicVerificationExecutionWorkflow,
    SMPCExecutionWorkflow,
    SwarmExecutionWorkflow,
    System2RemediationWorkflow,
)
from coreason_runtime.utils.logger import logger  # noqa: E402

TASK_QUEUE = os.getenv("TEMPORAL_TASK_QUEUE", "coreason-kinetic-queue")

invalid_members = dict(SandboxRestrictions.default.invalid_module_members.children)

invalid_members.pop("datetime", None)
invalid_members.pop("uuid", None)
invalid_members.pop("pathlib", None)
invalid_members.pop("glob", None)
invalid_members.pop("pathlib", None)

new_matcher = dataclasses.replace(SandboxRestrictions.default.invalid_module_members, children=invalid_members)

PydanticSafeRestrictions = dataclasses.replace(
    SandboxRestrictions.default, invalid_module_members=new_matcher
).with_passthrough_modules(
    "pydantic",
    "pydantic_core",
    "coreason_manifest",
    "coreason_manifest.spec.events",
    "coreason_runtime.telemetry.events",
    "coreason_runtime.utils.logger",
    "numpy",
    "pyarrow",
    "lancedb",
    "polars",
    "dlt",
    "extism",
    "httpx",
    "loguru",
    "tenacity",
    "tornado",
    "urllib3",
    "urllib",
    "concurrent",
    "prometheus_client",
)


async def _vram_watchdog(limit_bytes: int, cancel_event: asyncio.Event) -> None:
    """Async background watchdog that monitors physical RAM/VRAM and triggers circuit breaker.

    Args:
        limit_bytes: The maximum allowed memory usage in bytes.
        cancel_event: An asyncio.Event that will be set if the limit is breached.
    """
    import asyncio

    import psutil

    gpu_available = False
    try:
        import pynvml

        pynvml.nvmlInit()
        gpu_available = True
    except Exception:
        logger.debug("pynvml not available; GPU monitoring disabled.")

    while not cancel_event.is_set():
        try:
            process = psutil.Process()
            cpu_mem = process.memory_info().rss

            gpu_mem = 0
            if gpu_available:
                try:
                    handle = await asyncio.to_thread(pynvml.nvmlDeviceGetHandleByIndex, 0)
                    info = await asyncio.to_thread(pynvml.nvmlDeviceGetMemoryInfo, handle)
                    gpu_mem = info.used
                except Exception:
                    logger.debug("GPU memory polling failed; skipping GPU metrics.")

            total_usage = cpu_mem + gpu_mem

            if total_usage > limit_bytes:
                logger.critical(
                    f"CircuitBreakerEvent: Memory usage {total_usage / (1024**2):.1f}MB "
                    f"exceeds limit {limit_bytes / (1024**2):.1f}MB. Severing execution."
                )
                cancel_event.set()
                return
        except Exception as e:
            logger.warning(f"VRAM watchdog polling error: {e}")

        await asyncio.sleep(1.0)


class PartitionedActivityExecutor(concurrent.futures.Executor):
    def __init__(self, max_workers: int = 16):
        self.executors = [
            concurrent.futures.ThreadPoolExecutor(max_workers=1, thread_name_prefix=f"coreason_worker_{i}")
            for i in range(max_workers)
        ]
        self._default_executor = concurrent.futures.ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="coreason_worker_default"
        )

    def submit(self, fn: Any, /, *args: Any, **kwargs: Any) -> Any:
        import temporalio.activity as activity

        try:
            info = activity.info()
            workflow_id = info.workflow_id
            idx = hash(workflow_id) % len(self.executors)
            return self.executors[idx].submit(fn, *args, **kwargs)
        except Exception:
            return self._default_executor.submit(fn, *args, **kwargs)


async def _shutdown_handler(worker: Any, kinetic_activities: Any) -> None:
    from coreason_runtime.utils.logger import logger

    logger.critical(
        "Received SIGTERM or BargeInInterruptEvent. Initiating graceful shutdown and parking state in MedallionStateEngine..."
    )
    try:
        await worker.shutdown()
        # Ensure state is synced natively before completely dropping
        if hasattr(kinetic_activities.store, "close"):
            await kinetic_activities.store.close()
    except Exception as e:
        logger.error(f"Error during graceful shutdown: {e}")


async def start_worker(temporal_host: str) -> None:
    """Start the Temporal worker for the Coreason Runtime.

    Args:
        temporal_host: The host and port of the Temporal cluster.

        AGENT INSTRUCTION: Eradicate the traps triggered by Pydantic's Rust core
    """
    logger.info(f"Connecting to Temporal cluster at {temporal_host}")
    client = await Client.connect(temporal_host)

    sglang_url = os.getenv("SGLANG_URL", "")
    lancedb_uri = os.getenv("LANCEDB_URI", "")
    plugins_dir = os.getenv("PLUGINS_DIR", "")
    telemetry_broker_url = os.getenv("TELEMETRY_BROKER_URL", "")

    kinetic_activities = KineticActivities(
        sglang_url=sglang_url,
        memory_path=lancedb_uri,
        plugins_dir=plugins_dir,
        telemetry_url=telemetry_broker_url,
    )

    await kinetic_activities.ledger.bootstrap()
    await kinetic_activities.latent.bootstrap()

    from coreason_runtime.execution_plane.dom_simulator import execute_browser_intent_activity
    from coreason_runtime.execution_plane.kinematic_simulator import verify_spatial_bounds_activity
    from coreason_runtime.orchestration.activities import (
        forge_formal_verifier_compute_activity,
        forge_generator_compute_activity,
        forge_wasm_compiler_compute_activity,
        mcp_catalog_interrogation_io_activity,
    )
    from coreason_runtime.orchestration.workflows.active_inference_execution_workflow import (
        evaluate_surprise_compute_activity,
        update_latent_belief_activity,
    )
    from coreason_runtime.orchestration.workflows.hollow_plane_bridge_workflow import (
        cross_dimensional_state_projector_activity,
        verify_tensor_boundary_activity,
    )
    from coreason_runtime.orchestration.workflows.intent_renegotiation_workflow import (
        parse_rejection_parameters_activity,
        synthesize_compromise_intent_activity,
    )

    worker = Worker(
        client,
        task_queue=TASK_QUEUE,
        workflows=[
            ActiveInferenceExecutionWorkflow,
            AdversarialMarketExecutionWorkflow,
            CapabilityForgeExecutionWorkflow,
            ConsensusFederationExecutionWorkflow,
            CouncilExecutionWorkflow,
            DAGExecutionWorkflow,
            DigitalTwinExecutionWorkflow,
            DiscourseTreeExecutionWorkflow,
            DocumentKnowledgeGraphExecutionWorkflow,
            EvaluatorOptimizerExecutionWorkflow,
            EvolutionaryExecutionWorkflow,
            HierarchicalDOMExecutionWorkflow,
            HollowPlaneBridgeWorkflow,
            IntentElicitationExecutionWorkflow,
            IntentRenegotiationExecutionWorkflow,
            NeurosymbolicVerificationExecutionWorkflow,
            SMPCExecutionWorkflow,
            SwarmExecutionWorkflow,
            EpistemicSOPExecutionWorkflow,
            DynamicRoutingExecutionWorkflow,
            System2RemediationWorkflow,
        ],
        activities=[
            kinetic_activities.execute_tensor_inference_compute_activity,
            kinetic_activities.execute_mcp_tool_io_activity,
            kinetic_activities.store_epistemic_state_io_activity,
            kinetic_activities.announce_task_io_activity,
            kinetic_activities.execute_resolve_auction_compute_activity,
            kinetic_activities.execute_settle_prediction_market_compute_activity,
            kinetic_activities.execute_market_contract_compute_activity,
            kinetic_activities.request_oracle_intervention_io_activity,
            kinetic_activities.broadcast_state_echo_io_activity,
            kinetic_activities.emit_resumed_event_io_activity,
            kinetic_activities.record_token_burn_io_activity,
            kinetic_activities.execute_system_function_compute_activity,
            mcp_catalog_interrogation_io_activity,
            forge_generator_compute_activity,
            forge_formal_verifier_compute_activity,
            forge_wasm_compiler_compute_activity,
            execute_browser_intent_activity,
            verify_spatial_bounds_activity,
            verify_tensor_boundary_activity,
            cross_dimensional_state_projector_activity,
            parse_rejection_parameters_activity,
            synthesize_compromise_intent_activity,
            evaluate_surprise_compute_activity,
            update_latent_belief_activity,
        ],
        workflow_runner=UnsandboxedWorkflowRunner(),
        activity_executor=concurrent.futures.ThreadPoolExecutor(max_workers=int(os.getenv("MAX_WORKERS", "16"))),
    )

    import asyncio
    import signal

    loop = asyncio.get_running_loop()

    # Listen for explicit SIGTERM or custom BargeInInterruptEvent (mapped to SIGUSR1)
    for sig in (signal.SIGTERM, getattr(signal, "SIGUSR1", None)):
        if sig is not None:
            with contextlib.suppress(NotImplementedError):
                loop.add_signal_handler(sig, lambda: asyncio.create_task(_shutdown_handler(worker, kinetic_activities)))

    try:
        await kinetic_activities.telemetry.start()
        logger.info(f"Starting Temporal worker on task queue '{TASK_QUEUE}'")
        await worker.run()
    finally:
        await kinetic_activities.telemetry.close()


if __name__ == "__main__":
    import asyncio

    asyncio.run(start_worker("localhost:7233"))
