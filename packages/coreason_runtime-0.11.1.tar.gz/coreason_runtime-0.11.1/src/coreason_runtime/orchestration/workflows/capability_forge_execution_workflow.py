# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from datetime import timedelta

    from coreason_manifest import ExecutionEnvelopeState
    from temporalio.common import RetryPolicy

    from coreason_runtime.telemetry.emitter import TelemetryEmitter

from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class CapabilityForgeExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow that represents the Zero-to-One capability generation loop."""

    def __init__(self) -> None:
        """Initialize CapabilityForgeExecutionWorkflow."""
        super().__init__()
        self._human_approval_attestation: str | None = None

    @workflow.signal(name="approve_forge")
    def approve_forge(self, attestation: str) -> None:
        """Signal handler to receive human approval attestation string."""
        self._human_approval_attestation = attestation

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run the Capability Forge workflow.

        Args:
            payload: The dictionary representing an ExecutionEnvelopeState
                     containing the CapabilityForgeTopologyManifest (or its unrolled base).

        Returns:
            A dictionary containing the final execution status and results.
        """
        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        emitter = TelemetryEmitter("")
        trace_context_state = self._current_state_envelope.trace_context

        workflow.logger.info("Starting CapabilityForgeExecutionWorkflow")

        results: list[dict[str, Any]] = []

        workflow_start_time = workflow.now()

        with workflow.unsafe.sandbox_unrestricted():
            import json

            from coreason_manifest import CapabilityForgeTopologyManifest

            forge_macro = CapabilityForgeTopologyManifest.model_validate_json(json.dumps(manifest_payload))
            manifest = forge_macro.compile_to_base_topology()

            # Rehydrate the LLM-generated node intelligence that was wiped by the base compiler
            for n_id in manifest.nodes:
                if n_id in forge_macro.nodes:
                    manifest.nodes[n_id] = forge_macro.nodes[n_id]

        governance = manifest_payload.get("governance")
        allowed_classifications = manifest_payload.get("allowed_information_classifications")

        generator_node = None
        verifier_node = None

        for node_cid, node_profile in manifest.nodes.items():
            if "generator" in node_cid or getattr(node_profile, "type", "") == "generator":
                generator_node = node_profile
                gen_id = node_cid
            elif "verifier" in node_cid or getattr(node_profile, "type", "") == "formal_verifier":
                verifier_node = node_profile
                ver_id = node_cid

        if not generator_node:
            gen_id = next(iter(manifest.nodes.keys()))
            generator_node = manifest.nodes.get(gen_id)

        success = False

        workflow.logger.info("Forge Generation Strategy: Bipartite Proposer-Verifier")
        await workflow.sleep(timedelta(seconds=0.1))

        self.enforce_governance_limits(governance, workflow_start_time)
        self.enforce_lbac_clearance(allowed_classifications, "public")

        with workflow.unsafe.sandbox_unrestricted():
            gen_payload = manifest_payload.get(
                "generator", generator_node.model_dump(mode="json") if generator_node else {}
            )

        gen_segregated_payload = {
            "immutable_matrix": self._current_state_envelope.state_vector.immutable_matrix,
            "mutable_matrix": self._current_state_envelope.state_vector.mutable_matrix,
            "node_profile": gen_payload,
        }

        gen_result = await emitter.wrap_execution_block(
            name="ExecuteTensorInferenceComputeActivity:generator",
            kind="internal",
            trace_context=trace_context_state,
            block=lambda gen_segregated_payload=gen_segregated_payload: workflow.execute_activity(  # type: ignore[misc]
                "ExecuteTensorInferenceComputeActivity",
                args=[
                    workflow.info().workflow_id,
                    gen_segregated_payload,
                    "AgentResponse",
                ],
                schedule_to_close_timeout=timedelta(minutes=5),
                retry_policy=RetryPolicy(maximum_attempts=5),
            ),
        )
        usage = gen_result.get("usage", {})
        self._accumulated_tokens += usage.get("total_tokens", 0)
        self._accumulated_cost += gen_result.get("cost", 0.0)
        await self.record_thermodynamic_burn("gen", usage, gen_result.get("cost", 0.0))

        results.append({"node": gen_id, "type": "generation", "result": gen_result})

        self.enforce_governance_limits(governance, workflow_start_time)
        self.enforce_lbac_clearance(allowed_classifications, "public")

        ver_result = {}
        if verifier_node:
            with workflow.unsafe.sandbox_unrestricted():
                ver_payload = manifest_payload.get("verifier", verifier_node.model_dump(mode="json"))
                ver_payload["artifact"] = gen_result

            ver_segregated_payload = {
                "immutable_matrix": self._current_state_envelope.state_vector.immutable_matrix,
                "mutable_matrix": self._current_state_envelope.state_vector.mutable_matrix,
                "node_profile": ver_payload,
            }

            ver_result = await emitter.wrap_execution_block(
                name="ExecuteTensorInferenceComputeActivity:verifier",
                kind="internal",
                trace_context=trace_context_state,
                block=lambda ver_segregated_payload=ver_segregated_payload: workflow.execute_activity(  # type: ignore[misc]
                    "ExecuteTensorInferenceComputeActivity",
                    args=[
                        workflow.info().workflow_id,
                        ver_segregated_payload,
                        "VerificationYield",
                    ],
                    schedule_to_close_timeout=timedelta(minutes=5),
                    retry_policy=RetryPolicy(maximum_attempts=5),
                ),
            )
            ver_usage = ver_result.get("usage", {})
            self._accumulated_tokens += ver_usage.get("total_tokens", 0)
            self._accumulated_cost += ver_result.get("cost", 0.0)
            await self.record_thermodynamic_burn("verifier", ver_usage, ver_result.get("cost", 0.0))

            results.append({"node": ver_id, "type": "verification", "result": ver_result})
            ver_success = ver_result.get("success", False)
        else:
            ver_success = True

        mcp_result = {}
        if ver_success:
            workflow.logger.info("Verification succeeded! Proxying target to Universal Asset Forge via MCP.")

            target_schema = gen_result.get("output", "{}")
            with workflow.unsafe.sandbox_unrestricted():
                import json

                try:
                    schema_dict = json.loads(target_schema) if isinstance(target_schema, str) else target_schema
                    if not isinstance(schema_dict, dict):  # pragma: no cover
                        schema_dict = {"raw": target_schema}
                except Exception:  # pragma: no cover
                    schema_dict = {"raw": target_schema}

                schema_type = schema_dict.get("scaffold_type", "scaffold_logic_actuator")
                scaffold_tools = ["scaffold_manifest_state", "scaffold_logic_actuator", "scaffold_epistemic_node"]
                target_tool = schema_type if schema_type in scaffold_tools else "scaffold_logic_actuator"

                target_file = schema_dict.get("target_file", "./src/generated_capabilities.py")
                action_space_id = schema_dict.get("action_space_id", "urn:coreason:actionspace:dynamic:v1")

                name_param_key = "actuator_name"
                if target_tool == "scaffold_manifest_state":  # pragma: no cover
                    name_param_key = "state_name"
                elif target_tool == "scaffold_epistemic_node":  # pragma: no cover
                    name_param_key = "node_name"

                asset_name = schema_dict.get("asset_name", "dynamic_actuator")

                mcp_arguments = {
                    name_param_key: asset_name,
                    "geometric_schema": json.dumps(schema_dict.get("schema_definition", schema_dict)),
                    "target_file": target_file,
                    "action_space_id": action_space_id,
                }

            mcp_result = await emitter.wrap_execution_block(
                name="ExecuteMCPToolIOActivity:forge",
                kind="internal",
                trace_context=trace_context_state,
                block=lambda: workflow.execute_activity(
                    "ExecuteMCPToolIOActivity",
                    args=[
                        f"coreason-meta-engineering:{target_tool}",
                        {"params": {"arguments": mcp_arguments}},
                        None,
                    ],
                    schedule_to_close_timeout=timedelta(minutes=5),
                    retry_policy=RetryPolicy(maximum_attempts=5),
                ),
            )

            results.append({"node": "meta-engineering-mcp", "type": "forge_proxy", "result": mcp_result})
            success = mcp_result.get("success", False)

        final_receipt = mcp_result if success else (ver_result if verifier_node else gen_result)
        intent_hash = final_receipt.get("intent_hash")
        if not intent_hash or intent_hash == "UNKNOWN_HASH":  # pragma: no cover
            with workflow.unsafe.sandbox_unrestricted():
                import hashlib
                import json

                intent_hash = hashlib.sha256(json.dumps(final_receipt, sort_keys=True).encode("utf-8")).hexdigest()

        await workflow.execute_activity(
            "StoreEpistemicStateIOActivity",
            args=[workflow.info().workflow_id, intent_hash, success, final_receipt, None],
            schedule_to_close_timeout=timedelta(minutes=1),
        )

        workflow.logger.info("Completed CapabilityForgeExecutionWorkflow")
        return {"status": "success" if success else "failed", "results": results}
