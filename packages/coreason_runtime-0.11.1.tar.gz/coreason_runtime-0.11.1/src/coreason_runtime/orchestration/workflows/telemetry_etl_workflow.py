# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>


from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from datetime import timedelta


@workflow.defn
class TelemetryETLWorkflow:
    """A deterministic workflow that represents the Epistemic ETL Pipeline."""

    @workflow.run
    async def run(self) -> dict[str, str]:
        """Run the Medallion ETL Pipeline."""
        import typing

        workflow.logger.info("Starting Epistemic ETL Pipeline")
        result = await workflow.execute_activity(
            "ExecuteMedallionETLComputeActivity", schedule_to_close_timeout=timedelta(minutes=10)
        )
        return typing.cast("dict[str, str]", result)
