# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from coreason_manifest import ExecutionEnvelopeState


from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class AdversarialMarketExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow that represents an Adversarial Market Topology manifest.

    AGENT INSTRUCTION: Zero-Cost Macro that unrolls into a CouncilTopologyManifest
    via compile_to_base_topology(), maintaining algorithmic separation between
    attacker vs defender sub-graphs before council adjudication.
    """

    def __init__(self) -> None:
        """Initialize AdversarialMarketExecutionWorkflow."""
        super().__init__()

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run the Adversarial Market workflow.

        AGENT INSTRUCTION: This macro topology deterministically compiles into a
        CouncilTopologyManifest and delegates to CouncilExecutionWorkflow.

        Args:
            payload: The ExecutionEnvelopeState containing an AdversarialMarketTopologyManifest.

        Returns:
            A dictionary containing the results from the delegated Council workflow.
        """
        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        workflow.logger.info("Starting AdversarialMarketExecutionWorkflow")

        with workflow.unsafe.sandbox_unrestricted():
            import json

            from coreason_manifest import AdversarialMarketTopologyManifest

            market_manifest = AdversarialMarketTopologyManifest.model_validate_json(json.dumps(manifest_payload))
            council_manifest = market_manifest.compile_to_base_topology()
            council_payload = council_manifest.model_dump(mode="json", exclude_none=True)

        governance = manifest_payload.get("governance")
        allowed_classifications = manifest_payload.get("allowed_information_classifications")

        if governance:
            council_payload["governance"] = governance
        if allowed_classifications:
            council_payload["allowed_information_classifications"] = allowed_classifications

        import copy

        child_envelope_data = copy.deepcopy(payload)
        child_envelope_data["payload"] = council_payload

        result = await workflow.execute_child_workflow(
            "CouncilExecutionWorkflow",
            args=[child_envelope_data],
            id=f"{workflow.info().workflow_id}-adversarial-delegate",
        )

        workflow.logger.info("Completed AdversarialMarketExecutionWorkflow")
        import typing

        return typing.cast("dict[str, Any]", result)
