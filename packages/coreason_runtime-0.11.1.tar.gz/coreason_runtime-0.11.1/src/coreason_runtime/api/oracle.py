# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import os

from coreason_manifest import InterventionReceipt
from fastapi import APIRouter, HTTPException
from temporalio.client import Client

from coreason_runtime.utils.logger import logger
from coreason_runtime.utils.security import verify_wetware_attestation

router = APIRouter(prefix="/api/v1/oracle", tags=["Epistemic Oracle"])


def _enforce_wetware_attestation(payload: InterventionReceipt) -> None:
    """Enforce WetwareAttestationContract verification on an InterventionReceipt.

    Raises HTTPException(401) if attestation is missing, incomplete, or cryptographically invalid.
    """
    attestation = getattr(payload, "attestation", None)
    if attestation is None:
        raise HTTPException(status_code=401, detail="Missing strict WetwareAttestationContract authorization")

    crypto_payload = getattr(attestation, "cryptographic_payload", "")
    if not crypto_payload:
        raise HTTPException(status_code=401, detail="WetwareAttestationContract requires cryptographic_payload")

    try:
        if not verify_wetware_attestation(attestation):
            raise HTTPException(status_code=401, detail="WetwareAttestationContract verification failed")
    except HTTPException:
        raise
    except (ValueError, TypeError) as e:
        logger.exception("WetwareAttestationContract validation encountered an unexpected fault")
        raise HTTPException(status_code=401, detail="WetwareAttestationContract is structurally invalid") from e


@router.post("/resume/{workflow_id}")
async def resume_oracle(workflow_id: str, payload: InterventionReceipt) -> dict[str, str]:
    """Inject an absolute epistemic correction to bypass standard execution.

    Args:
        workflow_id: The Temporal workflow ID.
        payload: The strictly validated InterventionReceipt.

    Returns:
        Status indicating whether the signal was dispatched.
    """
    _enforce_wetware_attestation(payload)

    temporal_host = os.getenv("TEMPORAL_HOST", "localhost:7233")
    try:
        client = await Client.connect(temporal_host)
        handle = client.get_workflow_handle(workflow_id)

        # Fire the gRPC signal to unpause the Temporal workflow with the strictly validated receipt
        await handle.signal("receive_oracle_override", payload.model_dump(mode="json"))
        return {"status": "success", "message": "Epistemic injection dispatched"}
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Temporal swarm connection failed for workflow {workflow_id}")
        raise HTTPException(status_code=500, detail=f"Failed to reach Temporal Swarm: {e!s}") from e


@router.post("/resolve/{workflow_id}")
async def resolve_oracle(workflow_id: str, payload: InterventionReceipt) -> dict[str, str]:
    """Inject resolving priors to a suspended active inference swarm.

    Args:
        workflow_id: The Temporal workflow ID.
        payload: The strictly validated InterventionReceipt.

    Returns:
        Status indicating whether the signal was accepted.
    """
    _enforce_wetware_attestation(payload)

    temporal_host = os.getenv("TEMPORAL_HOST", "localhost:7233")
    try:
        client = await Client.connect(temporal_host)
        handle = client.get_workflow_handle(workflow_id)

        # Fire the gRPC signal to unpause the Temporal workflow with the strictly validated receipt
        await handle.signal("inject_oracle_resolution", payload.model_dump(mode="json"))
        return {"status": "resolution_injected", "workflow_id": workflow_id}
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Temporal swarm resolution injection failed for workflow {workflow_id}")
        raise HTTPException(status_code=500, detail=f"Failed to reach Temporal Swarm: {e!s}") from e
