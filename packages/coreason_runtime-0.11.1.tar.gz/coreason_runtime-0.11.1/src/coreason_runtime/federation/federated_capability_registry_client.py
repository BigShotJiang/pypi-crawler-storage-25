# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import os
import typing

import httpx
from loguru import logger

from coreason_runtime.utils.exceptions import ManifestConformanceError

MAX_ALLOCATION_BYTES = 10485760  # 10 MB limit


class FederatedCapabilityRegistryClient:
    """Client for securely resolving WASM capabilities and publishing MCPs to the coreason-ecosystem."""

    def __init__(self, transport: httpx.AsyncBaseTransport | None = None) -> None:
        self.base_url = os.getenv("ECOSYSTEM_REGISTRY_URL", "http://ecosystem:8080").rstrip("/")
        self.transport = transport

    async def fetch_capability_binary(self, urn: str) -> bytes:
        """Securely stream WASM binary and enforce MAX_ALLOCATION_BYTES."""
        url = f"{self.base_url}/api/v1/registry/capabilities/{urn}/download"
        downloaded = bytearray()

        # Mypy strictly requires transport to be explicitly handled if present
        async with httpx.AsyncClient(transport=self.transport) as client:
            try:
                async with client.stream("GET", url, timeout=10.0) as response:
                    response.raise_for_status()
                    async for chunk in response.aiter_bytes(chunk_size=65536):
                        if len(downloaded) + len(chunk) > MAX_ALLOCATION_BYTES:
                            msg = f"Memory Trap: capability '{urn}' payload exceeds {MAX_ALLOCATION_BYTES} bytes."
                            logger.error(msg)
                            raise ManifestConformanceError(msg)
                        downloaded.extend(chunk)
            except httpx.RequestError as e:
                msg = f"Network or capability resolution failed for '{urn}': {e}"
                logger.error(msg)
                raise ManifestConformanceError(msg) from e
            except httpx.HTTPStatusError as e:
                msg = f"Capability registry returned HTTP error: {e}"
                logger.error(msg)
                raise ManifestConformanceError(msg) from e

        return bytes(downloaded)

    async def publish_master_mcp(self, promotion_event: dict[str, typing.Any]) -> str:
        """Post the crystallized EpistemicPromotionEvent to the registry to acquire a URN."""
        url = f"{self.base_url}/api/v1/registry/capabilities/publish"
        payload = promotion_event

        async with httpx.AsyncClient(transport=self.transport) as client:
            response = await client.post(url, json=payload, timeout=5.0)
            response.raise_for_status()
            data = response.json()

        return str(data.get("urn", ""))
