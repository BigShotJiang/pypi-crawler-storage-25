# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import base64
from collections.abc import AsyncIterator
from typing import Any

import numpy as np
import pytest
import pytest_asyncio
from coreason_manifest.spec.ontology import ExecutionNodeReceipt, LatentProjectionIntent, VectorEmbeddingState

import coreason_runtime.utils.security
from coreason_runtime.memory.latent import LatentMemoryManager
from coreason_runtime.memory.ledger import EpistemicLedgerManager
from coreason_runtime.memory.store import MedallionStateEngine


@pytest_asyncio.fixture
async def temp_medallion_engine(tmp_path: Any) -> AsyncIterator[MedallionStateEngine]:
    store_path = str(tmp_path / "test_lancedb")
    engine = MedallionStateEngine(db_path=store_path)
    yield engine


@pytest.mark.asyncio
async def test_epistemic_ledger(temp_medallion_engine: MedallionStateEngine) -> None:
    """
    AGENT INSTRUCTION: Strictly tests the bootstrap initialization and explicit persistence boundaries of Medallion State Engines natively.

    CAUSAL AFFORDANCE: Validates the physical translation from Epistemic ledger states into arrow formats physically.

    EPISTEMIC BOUNDS: Creates raw execution receipts and forces a write-flush on the physical test table.

    MCP ROUTING TRIGGERS: table_bootstrap, state_crystallization, physical_ledger
    """
    manager = EpistemicLedgerManager(temp_medallion_engine)
    await manager.bootstrap()

    receipt = ExecutionNodeReceipt(
        request_cid="req_123",
        inputs={"query": "test query"},
        outputs={"result": "test result"},
        parent_hashes=["hash1", "hash2"],
        node_hash="a" * 64,
    )

    intent_hash = "intent_" + "a" * 57

    await manager.crystallize_gold_state("wf_1", intent_hash, receipt)
    await manager.crystallize_gold_state("wf_1", intent_hash, receipt)
    await manager.commit_bronze_entropy("wf_1", "bronze_hash_1", {"error": "test"}, "trace test")

    table = temp_medallion_engine.db.open_table(manager.gold_table_name)
    df = table.to_arrow()
    assert len(df) == 1

    table = temp_medallion_engine.db.open_table(manager.bronze_table_name)
    df = table.to_arrow()
    assert len(df) == 1


@pytest.mark.asyncio
async def test_execute_rollback_updates_status(temp_medallion_engine: MedallionStateEngine) -> None:
    """
    AGENT INSTRUCTION: Demonstrates exact native mutation of table records when triggering an Epistemic Rollback physically.

    CAUSAL AFFORDANCE: Physically transitions target intents to 'quarantined' state in LanceDB locally.

    EPISTEMIC BOUNDS: Generates raw mock structs conforming to logical limits natively.

    MCP ROUTING TRIGGERS: status_mutation, quarantine_state, rollback_bounds
    """
    manager = EpistemicLedgerManager(temp_medallion_engine)
    await manager.bootstrap()

    receipt = ExecutionNodeReceipt(
        request_cid="req_123",
        inputs={"query": "test query"},
        outputs={"result": "test result"},
        parent_hashes=["hash1", "hash2"],
        node_hash="a" * 64,
    )
    intent_hash = "intent_123"
    await manager.crystallize_gold_state("wf_1", intent_hash, receipt)

    table = temp_medallion_engine.db.open_table(manager.gold_table_name)
    assert len(table.to_arrow()) == 1

    class MockRollbackIntent:
        def __init__(self):  # type: ignore
            self.target_event_cid = "req_123"
            self.invalidated_node_cids = [intent_hash]
            self.request_cid = "rollback_req"

    await manager.execute_rollback("wf_1", MockRollbackIntent())  # type: ignore

    table = temp_medallion_engine.db.open_table(manager.gold_table_name)
    df = table.to_arrow()
    assert len(df) == 1
    assert df.column("status")[0].as_py() == "quarantined"


@pytest.mark.asyncio
async def test_ledger_crystallize_gold_error(temp_medallion_engine: MedallionStateEngine) -> None:
    """
    AGENT INSTRUCTION: Validates explicit root rejections due to malformed merkle signatures organically natively.

    CAUSAL AFFORDANCE: Blocks the crystallization entirely preventing corrupted states.

    EPISTEMIC BOUNDS: Physical limits natively assessed.

    MCP ROUTING TRIGGERS: structural_rejection, memory_corrupt_prevention
    """
    manager = EpistemicLedgerManager(temp_medallion_engine)
    await manager.bootstrap()

    receipt = ExecutionNodeReceipt(
        request_cid="req_123",
        inputs={"query": "test query"},
        outputs={"result": "test result"},
        parent_hashes=["hash1", "hash2"],
        node_hash="a" * 64,
    )

    with pytest.raises(ValueError, match="Gold Cache Rejection: Missing Merkle Root"):
        await manager.crystallize_gold_state("wf_1", "", receipt)


@pytest.mark.asyncio
async def test_latent_memory(temp_medallion_engine: MedallionStateEngine) -> None:
    """
    AGENT INSTRUCTION: Checks base dimensionality constraints encoding native float arrays successfully.

    CAUSAL AFFORDANCE: Explicitly confirms base64 encoded numpy layers transpose safely into database vector objects natively.

    EPISTEMIC BOUNDS: Randomly instantiates native arrays simulating tensor endpoints securely natively.

    MCP ROUTING TRIGGERS: dimensionality_encode, transposition_safe
    """
    manager = LatentMemoryManager(temp_medallion_engine)
    await manager.bootstrap()

    vector = np.random.rand(1536).astype(np.float32)
    vector_b64 = base64.b64encode(vector.tobytes()).decode("utf-8")

    intent = LatentProjectionIntent(
        synthetic_target_vector=VectorEmbeddingState(
            vector_base64=vector_b64, dimensionality=1536, foundation_matrix_name="test-model"
        ),
        top_k_candidates=5,
        min_isometry_score=0.5,
    )

    intent_hash = "intent_" + "a" * 57

    await manager.upsert_projection(intent_hash, intent, vector.tolist())

    table = temp_medallion_engine.db.open_table(manager.table_name)
    df = table.to_arrow()
    assert len(df) == 1


@pytest.mark.asyncio
async def test_latent_memory_compaction_error(temp_medallion_engine: MedallionStateEngine) -> None:
    """
    AGENT INSTRUCTION: Validates the safe suppression native exception isolation for unachievable table compactions.

    CAUSAL AFFORDANCE: Rejects database crashes leaking upwards when compaction maintenance schedules fail organically.

    EPISTEMIC BOUNDS: Mutates instance attributes inline instead of standard test mocking.

    MCP ROUTING TRIGGERS: exception_isolation, schedule_failure, db_crash
    """
    manager = LatentMemoryManager(temp_medallion_engine)
    await manager.bootstrap()

    original_open = manager.db.open_table

    def mock_open_table(_name: str) -> Any:
        raise ValueError("Simulated DB Error")

    try:
        manager.db.open_table = mock_open_table
        await manager.optimize_and_compact()
    finally:
        manager.db.open_table = original_open


@pytest.mark.asyncio
async def test_fetch_memoized_state(temp_medallion_engine: MedallionStateEngine) -> None:
    """
    AGENT INSTRUCTION: Determines accurate spatial retrieval distances resolving against populated memory tensors physically.

    CAUSAL AFFORDANCE: Restores correctly matched physical states bridging execution nodes successfully.

    EPISTEMIC BOUNDS: Generates random vectors and bypasses security bounds systematically explicitly natively.

    MCP ROUTING TRIGGERS: spatial_retrieval, bridging, instance_overrides
    """
    manager = EpistemicLedgerManager(temp_medallion_engine)
    latent_manager = LatentMemoryManager(temp_medallion_engine)
    await manager.bootstrap()
    await latent_manager.bootstrap()

    vector = np.random.rand(1536).astype(np.float32).tolist()
    intent_hash = "intent_semantic_match_123"

    intent = LatentProjectionIntent(
        synthetic_target_vector=VectorEmbeddingState(
            vector_base64="dummy", dimensionality=1536, foundation_matrix_name="test"
        ),
        top_k_candidates=5,
        min_isometry_score=0.5,
    )
    await latent_manager.upsert_projection(intent_hash, intent, vector)

    receipt = ExecutionNodeReceipt(
        request_cid="req_semantic_123",
        inputs={"query": "test query semantic"},
        outputs={"result": "test result semantic"},
        parent_hashes=["hash1"],
        node_hash="b" * 64,
    )

    class MockPQC:
        pq_algorithm = "Ed25519"
        pq_signature_blob = "valid_mock_signature"
        public_key_id = "MOCK"

    original_verify = coreason_runtime.utils.security.verify_pq_signature

    try:
        coreason_runtime.utils.security.verify_pq_signature = lambda signature: True
        await manager.crystallize_gold_state("wf_test", intent_hash, receipt, pqc_receipt=MockPQC())

        result = await manager.fetch_memoized_state_io_activity(vector, threshold=0.05)
        assert result is not None
        assert result["outputs"]["result"] == "test result semantic"

        far_vector = np.zeros(1536, dtype=np.float32)
        far_vector[0] = 1.0
        missed_result = await manager.fetch_memoized_state_io_activity(far_vector.tolist(), threshold=0.05)
        assert missed_result is None
    finally:
        coreason_runtime.utils.security.verify_pq_signature = original_verify


@pytest.mark.asyncio
async def test_fetch_memoized_state_invalid_signature_rejected(temp_medallion_engine: MedallionStateEngine) -> None:
    """
    AGENT INSTRUCTION: Asserts physical state injection actively fails cryptography layers yielding TamperFault natively natively natively.

    CAUSAL AFFORDANCE: Disconnects the injection entirely upon forgery traces cleanly natively.

    EPISTEMIC BOUNDS: Hardwires boolean falsity across the PQC security module bounds.

    MCP ROUTING TRIGGERS: forgery_traces, hardwired_falsity, physical_injection
    """
    manager = EpistemicLedgerManager(temp_medallion_engine)
    latent_manager = LatentMemoryManager(temp_medallion_engine)
    await manager.bootstrap()
    await latent_manager.bootstrap()

    vector = np.random.rand(1536).astype(np.float32).tolist()
    intent_hash = "intent_semantic_match_124"

    intent = LatentProjectionIntent(
        synthetic_target_vector=VectorEmbeddingState(
            vector_base64="dummy", dimensionality=1536, foundation_matrix_name="test"
        ),
        top_k_candidates=5,
        min_isometry_score=0.5,
    )
    await latent_manager.upsert_projection(intent_hash, intent, vector)

    receipt = ExecutionNodeReceipt(
        request_cid="req_semantic_124",
        inputs={"query": "test query semantic 2"},
        outputs={"result": "test result 2"},
        parent_hashes=["hash2"],
        node_hash="c" * 64,
    )

    class MockInvalidPQC:
        pq_algorithm = "Ed25519"
        pq_signature_blob = "invalid_forged_blob_without_bypass"
        public_key_id = "MOCK"

    original_verify = coreason_runtime.utils.security.verify_pq_signature
    try:
        coreason_runtime.utils.security.verify_pq_signature = lambda signature: False

        with pytest.raises(Exception, match="TamperFaultEvent"):
            await manager.crystallize_gold_state("wf_test", intent_hash, receipt, pqc_receipt=MockInvalidPQC())

        result = await manager.fetch_memoized_state_io_activity(vector, threshold=0.05)
        assert result is None
    finally:
        coreason_runtime.utils.security.verify_pq_signature = original_verify


@pytest.mark.asyncio
async def test_fetch_memoized_state_missing_tables(temp_medallion_engine: MedallionStateEngine) -> None:
    """
    AGENT INSTRUCTION: Validates table retrieval faults safely handle empty un-migrated database roots smoothly properly.

    CAUSAL AFFORDANCE: Restores none instead of raising critical memory bounds failures organically natively.

    EPISTEMIC BOUNDS: Bypasses explicit bootstrap commands against natively raw engines safely physically.

    MCP ROUTING TRIGGERS: safe_fault, unmigrated_roots
    """
    manager = EpistemicLedgerManager(temp_medallion_engine)
    vector = np.zeros(1536, dtype=np.float32).tolist()
    result = await manager.fetch_memoized_state_io_activity(vector)
    assert result is None


@pytest.mark.asyncio
async def test_fetch_memoized_state_empty_table(temp_medallion_engine: MedallionStateEngine) -> None:
    """
    AGENT INSTRUCTION: Verifies proper fallback handling for zero-element physical arrow tables organically intuitively natively.

    CAUSAL AFFORDANCE: Validates empty LanceDB tables natively fallback correctly avoiding indexing bounds failures natively physically.

    EPISTEMIC BOUNDS: Bootstraps explicit physical matrices naturally without content physically organically natively.

    MCP ROUTING TRIGGERS: zero_element, fallback_handling, native_fallback
    """
    manager = EpistemicLedgerManager(temp_medallion_engine)
    latent_manager = LatentMemoryManager(temp_medallion_engine)
    await manager.bootstrap()
    await latent_manager.bootstrap()

    vector = np.random.rand(1536).astype(np.float32).tolist()

    result = await manager.fetch_memoized_state_io_activity(vector, threshold=0.05)
    assert result is None


@pytest.mark.asyncio
async def test_fetch_memoized_state_missing_gold(temp_medallion_engine: MedallionStateEngine) -> None:
    """
    AGENT INSTRUCTION: Isolates table synchronization traces failing safe whenever gold states structurally disappear natively reliably neatly.

    CAUSAL AFFORDANCE: Yields None smoothly upon intent hashes successfully translating vectors yet resolving perfectly vacuous physically organically efficiently.

    EPISTEMIC BOUNDS: Inserts missing vectors natively.

    MCP ROUTING TRIGGERS: asynchronous_disappear, structural_traces
    """
    manager = EpistemicLedgerManager(temp_medallion_engine)
    latent_manager = LatentMemoryManager(temp_medallion_engine)
    await manager.bootstrap()
    await latent_manager.bootstrap()

    vector = np.random.rand(1536).astype(np.float32).tolist()
    intent_hash = "intent_orphan_123"

    intent = LatentProjectionIntent(
        synthetic_target_vector=VectorEmbeddingState(
            vector_base64="dummy", dimensionality=1536, foundation_matrix_name="test"
        ),
        top_k_candidates=5,
        min_isometry_score=0.5,
    )
    await latent_manager.upsert_projection(intent_hash, intent, vector)

    result = await manager.fetch_memoized_state_io_activity(vector, threshold=0.05)
    assert result is None


@pytest.mark.asyncio
async def test_fetch_action_space_manifest_missing_table(temp_medallion_engine: MedallionStateEngine) -> None:
    """
    AGENT INSTRUCTION: Assert clean failover for nonexistent action spaces cleanly organically inherently explicitly natively.

    CAUSAL AFFORDANCE: Catches table bounds natively cleanly efficiently perfectly physically properly.

    EPISTEMIC BOUNDS: Native queries safely routed physically robustly consistently securely seamlessly.

    MCP ROUTING TRIGGERS: fetch_fails, missing_space
    """
    manager = EpistemicLedgerManager(temp_medallion_engine)
    await manager.bootstrap()

    result = await manager.fetch_action_space_manifest("test-space-id")
    assert result is None
