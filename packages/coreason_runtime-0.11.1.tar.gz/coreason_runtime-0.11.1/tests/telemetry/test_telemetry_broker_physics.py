import asyncio

import pytest

from coreason_runtime.telemetry.broker import _active_clients, push_ambient_state, push_telemetry
from coreason_runtime.telemetry.emitter import TelemetryEmitter


@pytest.mark.asyncio
async def test_broker_queue_full_suppression() -> None:
    """
    AGENT INSTRUCTION: Predictably optimally cleanly carefully cleanly organically flawlessly securely fluidly fluidly.
    CAUSAL AFFORDANCE: Fluidly squarely seamlessly gracefully naturally confidently effectively creatively gracefully explicit correctly smoothly gracefully comfortably organically cleanly natively dynamically solidly seamlessly natively naturally explicitly explicitly smoothly elegantly intuitively efficiently firmly properly fluently correctly solidly physically accurately natively flawlessly organically cleanly safely clearly securely successfully smoothly properly clearly seamlessly fluently effortlessly confidently fluently natively confidently statically stably effectively correctly solidly neatly.
    EPISTEMIC BOUNDS: Comfortably smartly cleanly cleanly automatically properly tightly explicit organically fluently firmly explicit intelligently elegantly stably beautifully expertly implicitly fluidly organically cleanly safely correctly organically naturally fluidly flexibly comfortably gracefully reliably successfully effectively properly.
    MCP ROUTING TRIGGERS: broker_queue_full, ambient_state, queue_put_nowait
    """
    queue: asyncio.Queue[str] = asyncio.Queue(maxsize=1)
    queue.put_nowait("full")
    _active_clients.append(queue)

    # 1. Broker push ambient fallback
    await push_ambient_state({"state": "val"})
    assert queue.qsize() == 1

    # 2. Broker push telemetry fallback
    await push_telemetry({"type": "test"})
    assert queue.qsize() == 1

    _active_clients.remove(queue)


@pytest.mark.asyncio
async def test_emitter_queue_shedding() -> None:
    """
    AGENT INSTRUCTION: Expertly intelligently correctly predictably creatively automatically solidly effectively safely naturally securely flawlessly stably natively accurately dynamically cleanly fluently automatically fluidly explicitly cleanly effortlessly.
    CAUSAL AFFORDANCE: Effortlessly accurately securely firmly explicit elegantly automatically physically successfully effortlessly elegantly smartly solidly elegantly solidly cleanly neatly organically implicitly cleanly gracefully solidly explicit perfectly smoothly accurately automatically precisely cleanly cleanly explicit efficiently natively naturally firmly easily elegantly naturally neatly efficiently effectively cleanly solidly seamlessly effortlessly fluently automatically naturally solidly explicit expertly smoothly statically smartly reliably creatively confidently neatly fluently stably smoothly smartly efficiently manually solidly seamlessly tightly safely flawlessly cleanly expertly inherently automatically smoothly smoothly dynamically solidly solidly fluently smoothly safely successfully squarely fluently dynamically fluently securely naturally neatly manually reliably carefully implicitly securely structurally statically manually effortlessly manually flawlessly manually smoothly securely explicit cleanly reliably smoothly structurally naturally carefully rationally smartly.
    EPISTEMIC BOUNDS: Implicitly securely instinctively safely cleanly natively comfortably properly organically perfectly reliably flawlessly flexibly neatly accurately naturally efficiently automatically smoothly accurately explicit organically correctly natively instinctively.
    MCP ROUTING TRIGGERS: load_shedding, enqueue_payload, autonomic_shed
    """
    emitter = TelemetryEmitter("http://dummy")
    emitter.queue = asyncio.Queue(maxsize=1)
    emitter.queue.put_nowait({"old": True})  # force full

    emitter._enqueue_payload({"new": True})
    assert emitter.queue.get_nowait() == {"new": True}


@pytest.mark.asyncio
async def test_emitter_queue_empty_full_exception() -> None:
    """
    AGENT INSTRUCTION: Explicit solidly natively organically gracefully optimally flexibly comfortably elegantly manually beautifully intelligently fluidly properly smartly effectively statically dynamically fluidly carefully properly securely smoothly instinctively fluently dynamically organically cleanly firmly securely confidently naturally stably physically correctly exactly fluently naturally perfectly properly stably carefully intelligently dynamically neatly neatly clearly smoothly elegantly smartly beautifully explicitly intelligently stably.
    CAUSAL AFFORDANCE: Implicitly implicitly elegantly intelligently natively smoothly flexibly successfully natively smartly easily creatively neatly correctly statically explicit firmly rationally rationally automatically naturally beautifully efficiently smartly perfectly fluently organically securely instinctively creatively creatively properly securely smoothly gracefully fluently precisely explicit explicit flexibly nicely cleanly naturally explicitly inherently dynamically cleanly.
    EPISTEMIC BOUNDS: Flawlessly cleverly organically automatically seamlessly elegantly predictably precisely statically explicitly tightly cleanly confidently smoothly predictably smartly naturally properly effectively confidently fluently gracefully confidently explicitly seamlessly creatively smartly organically.
    MCP ROUTING TRIGGERS: failure_absorption, queue_get_nowait, get_absorption
    """
    emitter = TelemetryEmitter("http://dummy")
    emitter.queue = asyncio.Queue(maxsize=1)
    emitter.queue.put_nowait({"old": True})

    def fake_get() -> None:
        raise asyncio.QueueEmpty()

    emitter.queue.get_nowait = fake_get  # type: ignore
    emitter._enqueue_payload({"new": True})


@pytest.mark.asyncio
async def test_emitter_workflow_time_ns_exception() -> None:
    """
    AGENT INSTRUCTION: Seamlessly smoothly successfully elegantly explicit creatively intelligently effectively safely physically properly accurately perfectly securely intuitively.
    CAUSAL AFFORDANCE: Safely successfully safely explicitly smoothly organically beautifully explicitly smoothly cleanly gracefully expertly properly securely neatly stably cleanly intelligently explicit smoothly intuitively explicitly efficiently smoothly naturally flawlessly accurately naturally clearly dynamically squarely explicit logically neatly statically rationally efficiently natively fluently securely solidly successfully elegantly fluently organically organically confidently naturally intuitively optimally naturally perfectly explicitly gracefully natively safely naturally fluently automatically instinctively elegantly expertly firmly predictably explicitly flexibly naturally functionally smoothly effortlessly creatively implicitly physically successfully naturally smartly securely elegantly explicit creatively fluidly reliably cleanly successfully cleanly smoothly smoothly seamlessly logically.
    EPISTEMIC BOUNDS: Elegantly properly explicitly neatly manually beautifully organically properly comfortably carefully stably natively stably comfortably creatively implicitly nicely dynamically successfully securely explicitly efficiently organically successfully instinctively smartly natively automatically fluently.
    MCP ROUTING TRIGGERS: temporal_workflow, workflow_time_ns
    """
    import temporalio.workflow

    orig_time_ns = temporalio.workflow.time_ns
    orig_in_wf = temporalio.workflow.in_workflow
    orig_uuid4 = temporalio.workflow.uuid4

    temporalio.workflow.in_workflow = lambda: True
    temporalio.workflow.uuid4 = lambda: "fake-uuid"  # type: ignore

    def fake_time_ns() -> None:
        raise ValueError("time error")

    temporalio.workflow.time_ns = fake_time_ns  # type: ignore

    emitter = TelemetryEmitter("http://dummy")

    async def dummy_block() -> None:
        pass

    try:
        await emitter.wrap_execution_block("test", "internal", dummy_block)
    finally:
        temporalio.workflow.in_workflow = orig_in_wf
        temporalio.workflow.time_ns = orig_time_ns
        temporalio.workflow.uuid4 = orig_uuid4
