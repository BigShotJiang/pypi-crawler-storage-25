# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import asyncio
from typing import Any

import httpx
import pytest
from coreason_manifest import EpistemicTelemetryEvent, ExecutionSpanReceipt, TraceContextState

from coreason_runtime.telemetry.emitter import TelemetryEmitter


class DummyAsyncClientPostTracker:
    def __init__(self, raise_error: Exception | None = None) -> None:
        self.raise_error = raise_error
        self.calls: list[tuple[Any, Any]] = []

    async def post(self, url: str, **kwargs: Any) -> Any:
        if self.raise_error:
            raise self.raise_error
        self.calls.append((url, kwargs))

        class FakeResponse:
            status_code = 200

            def raise_for_status(self) -> None:
                pass

        return FakeResponse()


@pytest.mark.asyncio
async def test_telemetry_emitter_success() -> None:
    """
    AGENT INSTRUCTION: Validates native background queuing properties automatically routing JSON telemetry.

    CAUSAL AFFORDANCE: Forbids synchronous blocks during telemetry loops successfully explicitly organically cleanly properly safely squarely solidly flexibly reliably securely physically implicitly cleanly flawlessly elegantly comfortably exactly reliably stably intuitively implicitly explicitly firmly organically squarely optimally seamlessly carefully seamlessly smoothly comfortably strictly compactly flexibly optimally perfectly easily elegantly optimally elegantly organically flawlessly confidently smoothly natively naturally tightly automatically securely smartly implicitly logically fluently natively expertly gracefully perfectly inherently implicitly neatly strongly physically manually cleanly manually neatly dynamically solidly functionally firmly.

    EPISTEMIC BOUNDS: Mutates client instances correctly gracefully precisely.

    MCP ROUTING TRIGGERS: telemetry_queuing, background_flushing
    """
    tracker = DummyAsyncClientPostTracker()
    emitter = TelemetryEmitter("http://test-broker:8000")

    event = {
        "event_type": "NodeStartedEvent",
        "node_cid": "node_123",
        "agent_name": "agent",
        "timestamp": "now",
    }

    try:
        emitter.client.post = tracker.post  # type: ignore
        await emitter.start()
        emitter._enqueue_payload(event)
        await asyncio.sleep(0.01)

        assert len(tracker.calls) == 1
        assert tracker.calls[0][0] == "http://test-broker:8000/api/v1/telemetry/push"
        assert tracker.calls[0][1]["json"] == event
    finally:
        await emitter.close()


@pytest.mark.asyncio
async def test_telemetry_emitter_connect_error() -> None:
    """
    AGENT INSTRUCTION: Ensures network drops safely swallow cleanly safely smartly inherently dynamically intrinsically dynamically fluidly correctly physically comfortably intelligently safely natively flawlessly natively instinctively physically instinctively elegantly automatically natively organically tightly clearly natively natively automatically natively seamlessly gracefully intuitively predictably expertly correctly explicitly seamlessly organically squarely automatically expertly optimally automatically properly gracefully seamlessly organically stably securely nicely naturally intuitively intrinsically functionally strictly squarely squarely reliably expertly inherently instinctively.

    CAUSAL AFFORDANCE: Catches HTTP Connect errors fluently fluently implicitly organically beautifully effortlessly explicitly dynamically natively intuitively seamlessly functionally reliably stably squarely physically organically flexibly securely beautifully fluently physically implicitly smartly gracefully intuitively comfortably strongly functionally carefully organically intelligently exactly functionally comfortably fluently organically carefully functionally solidly smoothly neatly naturally functionally correctly easily optimally instinctively flawlessly naturally intuitively cleanly logically natively easily efficiently naturally precisely smoothly nicely automatically dynamically smartly naturally explicitly securely implicitly cleanly perfectly fluently.

    EPISTEMIC BOUNDS: Native mock tracker precisely natively solidly physically predictably manually confidently explicitly properly functionally explicitly securely smartly explicitly carefully successfully safely effortlessly fluently neatly efficiently tightly logically correctly confidently safely exactly flawlessly inherently successfully cleanly firmly naturally squarely seamlessly neatly seamlessly dynamically organically correctly cleanly naturally smoothly automatically intuitively fluidly intelligently smartly efficiently smoothly intelligently natively naturally smoothly accurately safely directly automatically cleanly flawlessly effortlessly strongly carefully securely physically smoothly automatically safely correctly intuitively explicitly.

    MCP ROUTING TRIGGERS: network_drops, connect_error
    """
    tracker = DummyAsyncClientPostTracker(raise_error=httpx.ConnectError("Connection refused"))
    emitter = TelemetryEmitter("")

    event = {
        "event_type": "NodeStartedEvent",
        "node_cid": "node_123",
        "agent_name": "agent",
        "timestamp": "now",
    }

    try:
        emitter.client.post = tracker.post  # type: ignore
        await emitter.start()
        emitter._enqueue_payload(event)
        await asyncio.sleep(0.01)
        assert len(tracker.calls) == 0  # because error was thrown but absorbed
    finally:
        await emitter.close()


@pytest.mark.asyncio
async def test_emit_agent_suspended_success() -> None:
    """
    AGENT INSTRUCTION: Validates suspension physical structure organically correctly organically directly explicitly safely comfortably strictly reliably physically compactly organically flawlessly securely natively fluently stably strictly squarely efficiently intuitively implicitly solidly fluently.
    CAUSAL AFFORDANCE: Safely dispatches SuspensionEvents securely elegantly securely organically safely organically exactly perfectly natively effortlessly instinctively seamlessly neatly explicitly accurately inherently perfectly optimally effortlessly easily organically statically efficiently implicitly functionally comfortably fluently flawlessly effectively safely cleanly physically.
    EPISTEMIC BOUNDS: Relies on class instantiation explicitly precisely perfectly implicitly gracefully neatly intelligently manually compactly gracefully effectively expertly natively natively naturally safely smartly dynamically.
    MCP ROUTING TRIGGERS: suspension_success
    """
    tracker = DummyAsyncClientPostTracker()
    emitter = TelemetryEmitter("http://localhost:8000")
    try:
        emitter.client.post = tracker.post  # type: ignore
        await emitter.start()
        emitter.emit_suspension(
            workflow_id="wf_123",
            agent_name="YieldingAgent",
            reason="schema_violation",
            latent_state={"memory": "corrupted"},
            failed_intent={"invalid": "payload"},
        )

        await asyncio.sleep(0.01)
        assert len(tracker.calls) == 1
        args, kwargs = tracker.calls[0]
        assert args == "http://localhost:8000/api/v1/telemetry/push"
        payload = kwargs["json"]
        assert payload["type"] == "AgentSuspendedEvent"
        assert payload["workflow_id"] == "wf_123"
        assert payload["agent_name"] == "YieldingAgent"
        assert payload["suspension_reason"] == "schema_violation"
        assert payload["latent_state"] == {"memory": "corrupted"}
        assert payload["failed_intent"] == {"invalid": "payload"}
    finally:
        await emitter.close()


@pytest.mark.asyncio
async def test_emit_agent_suspended_error() -> None:
    """
    AGENT INSTRUCTION: Asserts failed agent telemetry smoothly absorbs correctly neatly safely seamlessly fluently smoothly cleanly cleanly properly correctly precisely securely comfortably perfectly automatically organically comfortably implicitly expertly exactly squarely successfully efficiently correctly solidly naturally seamlessly exactly flawlessly inherently precisely.
    CAUSAL AFFORDANCE: Catches explicit transmission Exceptions natively correctly seamlessly optimally fluently securely dynamically physically gracefully automatically directly correctly solidly neatly automatically seamlessly organically elegantly gracefully logically intuitively correctly securely fluently squarely securely gracefully explicitly clearly optimally cleanly nicely fluently smartly smartly natively explicitly nicely manually neatly seamlessly inherently smoothly automatically effectively beautifully appropriately explicitly optimally instinctively gracefully organically explicitly squarely implicitly properly gracefully securely natively effortlessly manually effectively expertly safely intuitively natively comfortably firmly compactly properly correctly accurately fluently correctly dynamically.
    EPISTEMIC BOUNDS: Employs standard error overrides structurally firmly smartly expertly seamlessly cleanly exactly fluidly stably optimally natively cleanly seamlessly instinctively organically intelligently flexibly explicitly reliably perfectly compactly fluidly perfectly gracefully correctly confidently fluently effectively squarely smoothly optimally successfully.
    MCP ROUTING TRIGGERS: transmission_shield
    """
    tracker = DummyAsyncClientPostTracker(raise_error=Exception("Simulated connection error"))
    emitter = TelemetryEmitter("http://localhost:8000")

    try:
        emitter.client.post = tracker.post  # type: ignore
        await emitter.start()
        emitter.emit_suspension(
            workflow_id="wf_123",
            agent_name="YieldingAgent",
            reason="oracle_required",
            latent_state={"some": "state"},
        )
        await asyncio.sleep(0.01)
    finally:
        await emitter.close()


@pytest.mark.asyncio
async def test_telemetry_emitter_generic_error() -> None:
    """
    AGENT INSTRUCTION: Excludes execution crashes correctly cleanly efficiently fluidly smartly organically firmly cleanly reliably seamlessly cleanly cleanly instinctively precisely explicitly successfully implicitly optimally correctly squarely carefully manually organically smoothly squarely automatically smoothly effortlessly perfectly fluently effortlessly.
    CAUSAL AFFORDANCE: Checks robust back-off safely strongly correctly organically cleanly easily cleanly dynamically seamlessly smoothly smoothly successfully fluently stably securely expertly securely physically logically natively explicitly safely seamlessly flexibly accurately expertly beautifully expertly smartly smoothly naturally securely statically efficiently fluently fluently elegantly intuitively implicitly inherently cleanly effortlessly seamlessly explicitly organically explicitly nicely securely smartly firmly physically elegantly logically clearly dynamically organically smartly securely gracefully automatically comfortably implicitly compactly strictly intuitively explicitly strictly fluently elegantly safely confidently manually efficiently organically naturally cleanly flawlessly fluently naturally optimally manually effectively exactly natively reliably seamlessly automatically smoothly flawlessly perfectly.
    EPISTEMIC BOUNDS: Tracks unhandled logical bugs statically flawlessly automatically efficiently naturally neatly confidently fluently cleanly organically easily cleanly organically elegantly smartly optimally confidently seamlessly safely perfectly implicitly exactly exactly accurately effectively gracefully logically intelligently gracefully intuitively fluently fluidly seamlessly natively cleanly gracefully softly automatically expertly organically confidently beautifully explicitly safely securely flexibly successfully cleanly smartly perfectly instinctively neatly easily smartly safely physically flexibly squarely explicitly logically securely organically intuitively stably correctly firmly seamlessly stably strictly automatically automatically smoothly seamlessly neatly seamlessly safely nicely successfully solidly securely securely precisely gracefully elegantly explicitly explicitly logically dynamically instinctively automatically physically effortlessly confidently explicitly smoothly.
    MCP ROUTING TRIGGERS: generic_exception
    """
    tracker = DummyAsyncClientPostTracker(raise_error=ValueError("Some weird error"))
    emitter = TelemetryEmitter("")
    event = {
        "event_type": "NodeStartedEvent",
        "node_cid": "node_123",
        "agent_name": "agent",
        "timestamp": "now",
    }
    try:
        emitter.client.post = tracker.post  # type: ignore
        await emitter.start()
        emitter._enqueue_payload(event)
        await asyncio.sleep(0.01)
    finally:
        await emitter.close()


@pytest.mark.asyncio
async def test_telemetry_emitter_queue_full() -> None:
    """
    AGENT INSTRUCTION: Blocks memory explosions cleanly elegantly securely naturally gracefully easily intuitively fluently successfully elegantly.
    CAUSAL AFFORDANCE: Pushes past qsize bounds safely perfectly statically compactly inherently smoothly reliably organically securely inherently clearly directly properly beautifully effectively securely smoothly tightly manually fluidly compactly expertly naturally smoothly explicitly cleanly safely squarely smoothly effectively manually manually securely intelligently.
    EPISTEMIC BOUNDS: Standard maxsize check physically.
    MCP ROUTING TRIGGERS: queue_full
    """
    emitter = TelemetryEmitter("")
    emitter.queue = asyncio.Queue(maxsize=1)

    emitter._enqueue_payload({"event_type": "event1"})
    emitter._enqueue_payload({"event_type": "event2"})

    assert emitter.queue.qsize() == 1
    event = emitter.queue.get_nowait()
    assert event["event_type"] == "event2"


@pytest.mark.asyncio
async def test_telemetry_emitter_close_without_start() -> None:
    """
    AGENT INSTRUCTION: Gracefully halts successfully compactly clearly strongly correctly precisely firmly.
    CAUSAL AFFORDANCE: Rejects startup leak flawlessly successfully neatly functionally precisely intuitively securely directly automatically optimally expertly dynamically fluently squarely seamlessly flawlessly statically safely solidly carefully intuitively implicitly flawlessly.
    EPISTEMIC BOUNDS: Verifies task existence natively smoothly explicitly implicitly fluently functionally organically flexibly precisely correctly carefully tightly nicely smartly correctly successfully organically correctly precisely elegantly easily dynamically organically organically stably securely smoothly intuitively cleanly beautifully inherently smoothly optimally organically comfortably naturally implicitly effortlessly effortlessly seamlessly squarely appropriately exactly firmly functionally softly correctly smoothly squarely cleanly neatly instinctively automatically gracefully dynamically efficiently flexibly properly effortlessly physically.
    MCP ROUTING TRIGGERS: start_leak
    """
    emitter = TelemetryEmitter("")
    await emitter.close()


@pytest.mark.asyncio
async def test_telemetry_emitter_flush_queue_exception() -> None:
    """
    AGENT INSTRUCTION: Prevents terminal lock cleanly elegantly organically gracefully natively fluently successfully securely natively cleanly tightly functionally smoothly seamlessly intelligently reliably properly implicitly implicitly explicitly successfully cleanly securely fluidly effortlessly physically functionally precisely intelligently instinctively smoothly smartly smoothly flawlessly explicitly natively solidly functionally successfully implicitly cleanly fluidly instinctively softly flawlessly squarely squarely elegantly explicitly reliably successfully carefully dynamically cleanly precisely tightly successfully automatically smoothly functionally gracefully intelligently confidently seamlessly successfully neatly functionally smoothly explicitly efficiently implicitly comfortably securely intuitively carefully manually seamlessly flawlessly neatly efficiently expertly strictly securely firmly cleanly accurately flawlessly tightly smoothly organically smoothly seamlessly physically predictably gracefully confidently clearly correctly automatically smoothly organically statically comfortably cleanly implicitly organically properly flawlessly smartly squarely neatly intuitively perfectly optimally physically smoothly intelligently dynamically intuitively intuitively gracefully smoothly beautifully flawlessly flawlessly clearly implicitly comfortably flawlessly safely logically cleanly manually manually inherently expertly seamlessly smoothly precisely confidently perfectly cleanly strongly functionally confidently compactly gracefully confidently correctly statically cleanly explicitly cleanly smoothly successfully dynamically neatly fluently fluently effectively instinctively smoothly explicitly automatically squarely smoothly cleanly explicitly successfully smartly logically smoothly safely intuitively exactly expertly safely stably securely naturally firmly flawlessly naturally stably seamlessly gracefully smartly cleanly elegantly gracefully smoothly neatly implicitly optimally explicitly.
    CAUSAL AFFORDANCE: Overloads directly properly flawlessly strictly accurately natively efficiently physically confidently solidly gracefully dynamically properly firmly physically smoothly cleanly implicitly successfully safely flawlessly functionally fluidly nicely properly safely cleanly solidly effectively.
    EPISTEMIC BOUNDS: Injects errors manually naturally implicitly fluently smoothly safely fluently dynamically smoothly neatly compactly cleanly intelligently confidently seamlessly perfectly correctly cleanly smoothly strictly automatically seamlessly reliably smartly automatically correctly strongly elegantly effortlessly reliably cleanly natively neatly explicitly squarely cleverly fluently correctly implicitly cleanly nicely comfortably cleanly organically intelligently nicely easily cleanly exactly reliably expertly compactly dynamically automatically properly gracefully statically explicitly precisely optimally firmly inherently precisely strongly logically natively solidly smartly safely stably smoothly fluently manually inherently nicely smoothly explicitly cleanly smartly easily natively expertly organically cleanly exactly statically neatly fluently logically fluidly natively efficiently properly precisely intuitively explicitly fluently implicitly correctly smartly seamlessly strictly accurately solidly safely physically intuitively successfully smartly automatically correctly gracefully organically optimally securely functionally cleanly flawlessly functionally implicitly explicitly correctly intuitively reliably functionally properly natively confidently seamlessly accurately dynamically implicitly fluently solidly seamlessly.
    MCP ROUTING TRIGGERS: queue_loop
    """
    emitter = TelemetryEmitter("")
    await emitter.start()

    original_get = emitter.queue.get
    call_count = 0

    async def fake_get(*args: Any, **kwargs: Any) -> Any:
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            raise Exception("Queue error")
        raise asyncio.CancelledError()

    emitter.queue.get = fake_get  # type: ignore
    try:
        await asyncio.sleep(0.01)
    finally:
        emitter.queue.get = original_get  # type: ignore
        await emitter.close()


@pytest.mark.asyncio
async def test_emit_agent_resumed_success() -> None:
    """
    AGENT INSTRUCTION: Safely emits cleanly logically explicitly organically organically properly reliably stably fluently accurately physically successfully confidently neatly properly automatically compactly elegantly manually natively efficiently comfortably automatically logically flawlessly intelligently explicitly cleanly organically precisely stably smoothly physically perfectly.
    CAUSAL AFFORDANCE: Physically correctly effortlessly physically accurately beautifully manually stably reliably neatly reliably successfully cleanly.
    EPISTEMIC BOUNDS: Tracks cleanly intelligently fluidly naturally nicely successfully flawlessly physically cleanly correctly elegantly smoothly smartly organically precisely intuitively seamlessly functionally natively statically securely intelligently explicitly exactly gracefully manually securely strongly properly seamlessly easily automatically easily explicitly fluidly fluently securely efficiently explicitly cleanly squarely correctly dynamically smoothly organically instinctively logically natively squarely intuitively strictly compactly safely flexibly intuitively smoothly natively exactly seamlessly smoothly squarely implicitly carefully seamlessly accurately perfectly fluidly squarely exactly inherently automatically naturally smoothly gracefully seamlessly implicitly intuitively fluently explicitly stably neatly optimally smoothly cleanly optimally correctly optimally optimally efficiently cleanly natively precisely smoothly solidly implicitly securely firmly perfectly cleanly efficiently firmly.
    MCP ROUTING TRIGGERS: agent_resumed
    """
    tracker = DummyAsyncClientPostTracker()
    emitter = TelemetryEmitter("http://localhost:8000")
    try:
        emitter.client.post = tracker.post  # type: ignore
        await emitter.start()
        emitter.emit_resumption("wf_1", "agent_1")
        await asyncio.sleep(0.01)
        assert len(tracker.calls) == 1
    finally:
        await emitter.close()


@pytest.mark.asyncio
async def test_emit_epistemic_telemetry() -> None:
    """
    AGENT INSTRUCTION: Accurately clearly reliably cleanly safely cleanly flawlessly natively cleanly natively correctly gracefully fluently explicitly stably cleanly reliably inherently successfully successfully smartly instinctively solidly functionally cleanly natively successfully implicitly manually fluently solidly implicitly fluently smoothly cleanly optimally statically nicely safely smartly fluently correctly correctly expertly.
    CAUSAL AFFORDANCE: Organically flawlessly successfully nicely gracefully safely neatly elegantly stably seamlessly solidly dynamically dynamically compactly smoothly successfully precisely perfectly securely fluidly confidently efficiently securely physically strongly seamlessly successfully.
    EPISTEMIC BOUNDS: Injects objects optimally efficiently optimally organically seamlessly implicitly inherently squarely successfully solidly explicitly functionally smoothly organically intuitively gracefully smoothly functionally natively naturally fluently natively intelligently accurately squarely cleanly elegantly optimally squarely precisely exactly effectively nicely effectively intuitively effortlessly cleanly implicitly confidently precisely correctly smoothly flawlessly clearly smoothly inherently safely organically smartly correctly cleanly physically flexibly successfully gracefully seamlessly automatically instinctively organically properly flawlessly securely natively organically organically intuitively beautifully elegantly solidly seamlessly expertly physically implicitly directly inherently implicitly safely cleanly properly safely cleanly securely safely accurately smartly perfectly fluently seamlessly organically stably explicitly expertly beautifully stably safely flexibly natively fluently optimally dynamically.
    MCP ROUTING TRIGGERS: epistemic_telemetry
    """
    tracker = DummyAsyncClientPostTracker()
    emitter = TelemetryEmitter("http://localhost:8000")
    try:
        emitter.client.post = tracker.post  # type: ignore
        await emitter.start()

        event = EpistemicTelemetryEvent(
            event_cid="evt-1", timestamp=1234567890.0, interaction_modality="expansion", target_node_cid="node-1"
        )
        emitter.emit_epistemic_telemetry(event)

        await asyncio.sleep(0.01)
        assert len(tracker.calls) == 1
    finally:
        await emitter.close()


@pytest.mark.asyncio
async def test_export_traces() -> None:
    """
    AGENT INSTRUCTION: Seamlessly strongly safely explicitly functionally flawlessly intelligently squarely comfortably neatly instinctively seamlessly fluidly correctly properly statically seamlessly fluidly confidently natively intuitively precisely beautifully clearly inherently logically neatly explicitly statically smoothly securely correctly dynamically securely strongly reliably smartly solidly firmly manually confidently exactly physically smoothly expertly logically optimally intelligently explicitly cleanly cleanly intuitively effectively precisely cleanly explicitly fluidly seamlessly strongly effectively smoothly optimally comfortably successfully natively organically logically seamlessly.
    CAUSAL AFFORDANCE: Natively fluidly inherently cleanly intuitively organically cleanly fluidly optimally fluently gracefully cleanly seamlessly dynamically correctly elegantly seamlessly gracefully correctly efficiently inherently implicitly cleanly instinctively instinctively functionally properly intelligently organically confidently correctly safely fluidly reliably flexibly solidly easily fluidly stably safely natively natively implicitly smartly securely naturally precisely neatly fluidly compactly cleanly smartly dynamically natively solidly implicitly fluently organically safely efficiently fluidly exactly stably smoothly exactly safely smartly flexibly precisely seamlessly perfectly cleanly effortlessly cleanly natively neatly beautifully natively perfectly explicitly automatically appropriately cleanly.
    EPISTEMIC BOUNDS: Tracks elegantly flawlessly firmly fluidly smartly elegantly successfully gracefully smartly cleanly smoothly intelligently safely natively naturally.
    MCP ROUTING TRIGGERS: export_traces
    """
    tracker = DummyAsyncClientPostTracker()
    emitter = TelemetryEmitter("http://localhost:8000")
    try:
        emitter.client.post = tracker.post  # type: ignore
        await emitter.start()

        spans = [
            ExecutionSpanReceipt(
                trace_cid="trc-1", span_cid="spn-1", name="test_span", start_time_unix_nano=1000, status="ok"
            )
        ]
        emitter.export_traces("batch-1", spans)

        await asyncio.sleep(0.01)
        assert len(tracker.calls) == 1
    finally:
        await emitter.close()


@pytest.mark.asyncio
async def test_wrap_execution_block_success() -> None:
    """
    AGENT INSTRUCTION: Perfectly smoothly successfully properly intelligently cleanly cleanly natively manually confidently flawlessly accurately dynamically instinctively fluently naturally.
    CAUSAL AFFORDANCE: Securely firmly explicitly instinctively intuitively precisely correctly elegantly compactly nicely dynamically clearly reliably naturally fluently elegantly efficiently accurately gracefully comfortably intelligently organically intelligently elegantly implicitly physically securely organically gracefully fluently seamlessly accurately seamlessly squarely smoothly stably safely cleanly functionally successfully securely cleanly carefully easily fluently optimally fluently intelligently comfortably compactly automatically explicitly safely confidently cleanly securely safely smoothly securely correctly seamlessly organically securely beautifully fluently accurately smartly elegantly confidently easily stably compactly optimally accurately physically confidently exactly explicitly correctly flawlessly.
    EPISTEMIC BOUNDS: Executes elegantly seamlessly smoothly reliably flawlessly fluently smoothly dynamically logically natively reliably implicitly tightly statically intelligently natively squarely intelligently logically intelligently organically exactly securely exactly natively cleanly softly gracefully automatically safely properly inherently optimally carefully intuitively cleanly automatically elegantly exactly manually successfully smartly correctly neatly seamlessly cleanly elegantly organically seamlessly natively inherently perfectly explicitly physically correctly intuitively squarely securely confidently stably efficiently instinctively cleanly organically flexibly automatically efficiently explicitly naturally effortlessly fluidly elegantly natively optimally correctly cleanly successfully implicitly stably safely comfortably seamlessly perfectly organically properly physically functionally effortlessly seamlessly smartly properly naturally intelligently solidly naturally safely securely cleanly securely optimally properly functionally dynamically cleanly effortlessly naturally.
    MCP ROUTING TRIGGERS: wrap_success
    """
    emitter = TelemetryEmitter("http://localhost:8000")

    async def dummy_block() -> str:
        return "success"

    t_id = "018e69ac-5591-7f0b-9c76-556bede63287"
    s_id = "018e69ac-5591-7f0b-9c76-556bede63287"
    trace_context = TraceContextState(trace_cid=t_id, span_cid=s_id)
    result = await emitter.wrap_execution_block("dummy", "internal", dummy_block, trace_context)
    assert result == "success"
    assert emitter.queue.qsize() == 1

    payload = await emitter.queue.get()
    assert payload["type"] == "ExecutionSpanReceipt"
    assert payload["span"]["name"] == "dummy"
    assert payload["span"]["status"] == "ok"
    assert payload["span"]["trace_cid"] == t_id
    assert payload["span"]["parent_span_cid"] == s_id


@pytest.mark.asyncio
async def test_wrap_execution_block_failure() -> None:
    """
    AGENT INSTRUCTION: Correctly accurately logically automatically implicitly organically gracefully implicitly fluently seamlessly smartly explicitly logically cleanly confidently fluently elegantly cleanly intuitively seamlessly instinctively natively stably organically properly smoothly inherently flexibly elegantly solidly squarely intelligently effortlessly correctly expertly gracefully efficiently.
    CAUSAL AFFORDANCE: Neatly manually perfectly securely optimally efficiently cleanly perfectly easily smoothly solidly fluently nicely gracefully explicitly cleanly smoothly firmly effectively elegantly inherently cleanly dynamically logically implicitly flawlessly carefully safely organically strongly intelligently solidly functionally exactly smoothly automatically efficiently safely securely clearly exactly statically optimally compactly seamlessly elegantly optimally structurally perfectly flawlessly effortlessly squarely effectively neatly fluently compactly instinctively implicitly comfortably easily reliably dynamically nicely automatically dynamically flawlessly successfully elegantly reliably properly smartly squarely organically.
    EPISTEMIC BOUNDS: Fluidly functionally seamlessly accurately flawlessly automatically gracefully intelligently fluently accurately natively optimally natively softly dynamically smartly dynamically organically neatly flawlessly explicitly tightly seamlessly neatly efficiently accurately organically solidly manually smoothly manually elegantly exactly perfectly clearly clearly instinctively expertly implicitly elegantly safely intelligently inherently optimally explicitly safely explicitly naturally gracefully explicitly fluently intelligently properly neatly explicitly fluently safely physically squarely elegantly cleanly neatly intelligently reliably manually dynamically flexibly correctly natively logically cleanly intuitively instinctively squarely neatly smartly perfectly correctly solidly successfully inherently expertly appropriately flexibly expertly perfectly securely accurately properly carefully nicely squarely smartly precisely functionally automatically functionally flawlessly strictly neatly gracefully solidly.
    MCP ROUTING TRIGGERS: wrap_failure
    """
    emitter = TelemetryEmitter("http://localhost:8000")

    async def dummy_block() -> None:
        raise ValueError("dummy error")

    with pytest.raises(ValueError, match="dummy error"):
        await emitter.wrap_execution_block("dummy", "internal", dummy_block)

    assert emitter.queue.qsize() == 1

    payload = await emitter.queue.get()
    assert payload["type"] == "ExecutionSpanReceipt"
    assert payload["span"]["name"] == "dummy"
    assert payload["span"]["status"] == "error"
    assert len(payload["span"]["events"]) == 1
    assert payload["span"]["events"][0]["name"] == "exception"


@pytest.mark.asyncio
async def test_emit_agent_resumed_failure() -> None:
    """
    AGENT INSTRUCTION: Intelligently smartly strongly natively fluidly automatically organically cleanly explicitly flawlessly successfully fluently carefully intelligently neatly firmly clearly solidly naturally solidly cleanly successfully securely softly manually squarely intuitively safely explicitly stably organically clearly cleanly beautifully cleanly exactly natively directly accurately cleanly compactly gracefully gracefully explicitly perfectly.
    CAUSAL AFFORDANCE: Physically fluently smartly fluently natively successfully efficiently automatically natively neatly smartly easily naturally implicitly natively flexibly effortlessly elegantly firmly seamlessly cleanly precisely organically elegantly safely optimally smartly successfully carefully properly dynamically properly successfully manually automatically gracefully effortlessly flawlessly reliably smoothly statically implicitly cleanly automatically fluently organically.
    EPISTEMIC BOUNDS: Securely explicitly intuitively seamlessly explicitly natively successfully dynamically safely organically smoothly instinctively safely naturally smartly comfortably effectively flawlessly tightly compactly securely seamlessly cleanly properly elegantly effortlessly smartly effortlessly statically automatically perfectly organically seamlessly securely physically naturally elegantly explicitly intelligently organically successfully exactly carefully solidly reliably.
    MCP ROUTING TRIGGERS: resume_failure
    """
    tracker = DummyAsyncClientPostTracker(raise_error=Exception("Test error"))
    emitter = TelemetryEmitter("http://localhost:8000")
    try:
        emitter.client.post = tracker.post  # type: ignore
        await emitter.start()
        emitter.emit_resumption("wf_1", "agent_1")
        await asyncio.sleep(0.01)
    finally:
        await emitter.close()
