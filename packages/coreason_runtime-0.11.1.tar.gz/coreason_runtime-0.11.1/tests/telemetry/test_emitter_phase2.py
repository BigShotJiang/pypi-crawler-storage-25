# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Phase 2 coverage tests for TelemetryEmitter queue saturation.

Targets: emitter.py L97-98 (QueueEmpty/QueueFull during load shedding),
L162-163 (CancelledError in wrap_execution_block),
L200-201 (Exception in wrap_execution_block).

All tests use physically instantiated values — zero unittest.mock.
"""

import asyncio

import pytest

from coreason_runtime.telemetry.emitter import TelemetryEmitter


class TestTelemetryEmitterSaturation:
    """Cover the ring-buffer load shedding path in _enqueue_payload."""

    def test_queue_saturation_triggers_load_shedding(self) -> None:
        """Saturating the queue beyond maxsize=1000 triggers get_nowait/put_nowait."""
        emitter = TelemetryEmitter("http://localhost:9999")
        # Override queue to a small maxsize for deterministic testing
        emitter.queue = asyncio.Queue(maxsize=2)

        # Fill to capacity
        emitter._enqueue_payload({"event": 1})
        emitter._enqueue_payload({"event": 2})

        # This should trigger load shedding — drop oldest, insert new
        emitter._enqueue_payload({"event": 3})

        # Queue should have event 2 and event 3 (event 1 was shed)
        assert emitter.queue.qsize() == 2
        item1 = emitter.queue.get_nowait()
        assert item1["event"] == 2
        item2 = emitter.queue.get_nowait()
        assert item2["event"] == 3

    def test_emit_event_routes_through_enqueue(self) -> None:
        """emit_event calls _enqueue_payload."""
        emitter = TelemetryEmitter("http://localhost:9999")
        emitter.emit_event({"type": "test"})
        assert emitter.queue.qsize() == 1

    def test_emit_suspension_event(self) -> None:
        """emit_suspension creates proper event structure."""
        emitter = TelemetryEmitter("http://localhost:9999")
        emitter.emit_suspension(
            workflow_id="wf-1",
            agent_name="agent-1",
            reason="budget_exceeded",
            latent_state={"tokens": 9999},
        )
        assert emitter.queue.qsize() == 1
        event = emitter.queue.get_nowait()
        assert event["type"] == "AgentSuspendedEvent"
        assert event["workflow_id"] == "wf-1"

    def test_emit_resumption_event(self) -> None:
        """emit_resumption creates proper event structure."""
        emitter = TelemetryEmitter("http://localhost:9999")
        emitter.emit_resumption(workflow_id="wf-1", agent_name="agent-1")
        assert emitter.queue.qsize() == 1
        event = emitter.queue.get_nowait()
        assert event["type"] == "AgentResumedEvent"


class TestTelemetryEmitterWrapBlock:
    """Cover wrap_execution_block exception paths."""

    @pytest.mark.asyncio
    async def test_wrap_execution_block_exception(self) -> None:
        """Exception in block is caught, span emitted with error status."""
        emitter = TelemetryEmitter("http://localhost:9999")

        async def failing_block() -> None:
            msg = "test failure"
            raise RuntimeError(msg)

        with pytest.raises(RuntimeError, match="test failure"):
            await emitter.wrap_execution_block(
                name="test_block",
                kind="internal",
                block=failing_block,
            )
        # Span should have been emitted
        assert emitter.queue.qsize() >= 1

    @pytest.mark.asyncio
    async def test_wrap_execution_block_cancelled(self) -> None:
        """CancelledError propagates and emits span with error status."""
        emitter = TelemetryEmitter("http://localhost:9999")

        async def cancelled_block() -> None:
            raise asyncio.CancelledError

        with pytest.raises(asyncio.CancelledError):
            await emitter.wrap_execution_block(
                name="cancelled_block",
                kind="internal",
                block=cancelled_block,
            )
        # Span should have been emitted in the finally block
        assert emitter.queue.qsize() >= 1

    @pytest.mark.asyncio
    async def test_wrap_execution_block_success(self) -> None:
        """Successful block emits span with ok status."""
        emitter = TelemetryEmitter("http://localhost:9999")

        async def ok_block() -> str:
            return "result"

        result = await emitter.wrap_execution_block(
            name="ok_block",
            kind="server",
            block=ok_block,
        )
        assert result == "result"
        assert emitter.queue.qsize() == 1


class TestTelemetryEmitterLifecycle:
    """Cover start/close lifecycle."""

    @pytest.mark.asyncio
    async def test_start_and_close(self) -> None:
        """Starting and closing the emitter cleanly."""
        emitter = TelemetryEmitter("http://localhost:9999")
        await emitter.start()
        assert emitter._flush_task is not None
        await emitter.close()

    @pytest.mark.asyncio
    async def test_close_without_start(self) -> None:
        """Closing without starting doesn't error."""
        emitter = TelemetryEmitter("http://localhost:9999")
        await emitter.close()

    @pytest.mark.asyncio
    async def test_empty_broker_url_fallback(self) -> None:
        """Empty broker URL falls back to localhost."""
        emitter = TelemetryEmitter("")
        assert "localhost" in emitter.push_endpoint
        await emitter.close()
