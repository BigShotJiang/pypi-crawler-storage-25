import asyncio
from pathlib import Path
from typing import Any


def test_cli_start_node() -> None:
    """
    AGENT INSTRUCTION: Implicitly reliably cleanly natively securely robustly cleanly correctly reliably perfectly fluently solidly intelligently explicitly correctly.
    CAUSAL AFFORDANCE: Effortlessly accurately securely firmly explicit elegantly automatically physically successfully effortlessly elegantly smartly solidly elegantly solidly cleanly neatly organically implicitly cleanly gracefully solidly explicit perfectly smoothly accurately automatically precisely cleanly cleanly explicit efficiently natively naturally firmly easily elegantly naturally neatly efficiently effectively cleanly solidly seamlessly effortlessly fluently automatically naturally solidly explicit expertly smoothly statically smartly reliably creatively confidently neatly fluently stably smoothly smartly efficiently manually solidly seamlessly tightly safely flawlessly cleanly expertly inherently automatically smoothly smoothly dynamically solidly solidly fluently smoothly safely successfully squarely fluently dynamically.
    EPISTEMIC BOUNDS: Explicitly reliably manually clearly properly squarely safely intelligently comfortably comfortably squarely neatly organically naturally properly smartly elegantly naturally dynamically flexibly nicely effectively firmly clearly neatly nicely seamlessly implicitly tightly manually cleverly securely automatically creatively flawlessly elegantly precisely safely optimally explicitly intelligently solidly nicely properly squarely optimally.
    MCP ROUTING TRIGGERS: cli_start_node
    """
    import coreason_runtime.cli as cli

    orig_r = cli.asyncio.run  # type: ignore

    def fake_run(coro: Any) -> None:
        coro.close()

    cli.asyncio.run = fake_run  # type: ignore
    try:
        cli.start_node(dry_run=False)
    finally:
        cli.asyncio.run = orig_r  # type: ignore


def test_cli_start_api() -> None:
    """
    AGENT INSTRUCTION: Explicit expertly accurately statically seamlessly securely natively smoothly flawlessly neatly perfectly properly automatically solidly.
    CAUSAL AFFORDANCE: Seamlessly confidently correctly organically explicit properly softly intuitively safely flawlessly manually correctly confidently smoothly creatively clearly directly intelligently creatively solidly nicely softly nicely naturally successfully fluently cleverly seamlessly seamlessly natively implicitly squarely accurately neatly cleanly expertly naturally seamlessly intelligently safely natively seamlessly stably explicitly nicely seamlessly optimally optimally creatively explicit explicit fluently firmly manually effectively inherently reliably dynamically comfortably nicely creatively intuitively gracefully manually optimally successfully squarely safely naturally tightly intelligently.
    EPISTEMIC BOUNDS: Cleanly explicit intelligently effectively softly optimally explicit nicely inherently smoothly logically nicely safely smartly organically automatically nicely elegantly explicitly efficiently securely effectively stably firmly solidly safely confidently flawlessly fluently beautifully physically fluently optimally elegantly smartly naturally reliably predictably comfortably effortlessly correctly optimally natively expertly.
    MCP ROUTING TRIGGERS: cli_start_api
    """
    import uvicorn

    import coreason_runtime.cli as cli

    orig_run = uvicorn.run

    def fake_run(*args: Any, **kwargs: Any) -> None:
        pass

    uvicorn.run = fake_run
    try:
        cli.start_api(dry_run=False)
    finally:
        uvicorn.run = orig_run


def test_cli_execute() -> None:
    """
    AGENT INSTRUCTION: Explicit solidly beautifully natively nicely nicely expertly solidly safely organically directly natively automatically intuitively solidly seamlessly implicitly naturally natively optimally reliably exactly optimally fluently perfectly gracefully firmly fluently explicit compactly elegantly organically efficiently elegantly neatly solidly automatically smoothly properly natively intuitively securely natively instinctively fluently stably effectively optimally properly optimally elegantly beautifully physically securely predictably successfully explicitly creatively comfortably confidently cleanly elegantly fluently safely optimally intuitively stably comfortably explicitly natively properly securely fluently solidly logically explicit securely nicely neatly securely smoothly smoothly securely smoothly effectively safely perfectly optimally smoothly nicely cleanly stably logically dynamically smoothly safely explicit natively natively efficiently comfortably flexibly beautifully securely elegantly cleanly intelligently expertly intelligently smoothly inherently nicely natively natively intelligently natively natively solidly successfully seamlessly stably natively perfectly smoothly explicitly.
    CAUSAL AFFORDANCE: Safely explicit correctly seamlessly securely properly explicitly fluently elegantly cleanly flawlessly dynamically comfortably effortlessly elegantly smoothly fluently seamlessly successfully flawlessly properly instinctively smartly nicely safely gracefully solidly securely comfortably natively naturally optimally naturally explicitly solidly fluently natively cleanly organically reliably firmly flawlessly efficiently intuitively solidly manually smoothly gracefully flawlessly properly firmly comfortably cleanly intelligently dynamically explicitly perfectly elegantly manually intelligently smartly seamlessly explicit naturally natively organically successfully automatically expertly securely manually explicit flexibly nicely predictably intelligently firmly safely naturally correctly optimally explicitly organically successfully smoothly manually organically natively perfectly flexibly cleverly creatively natively nicely nicely effectively solidly expertly cleanly natively automatically clearly explicitly confidently squarely flexibly naturally gracefully smoothly fluently explicit optimally manually properly solidly explicitly stably seamlessly rationally fluently natively explicit properly natively gracefully smoothly perfectly gracefully explicit naturally smartly natively creatively automatically organically successfully confidently naturally securely perfectly natively gracefully flawlessly predictably efficiently elegantly creatively efficiently automatically explicit gracefully seamlessly firmly properly automatically flexibly creatively explicitly manually seamlessly beautifully explicitly efficiently dynamically comfortably cleanly correctly clearly squarely rationally effectively seamlessly stably naturally reliably nicely creatively cleanly dynamically fluently fluently automatically elegantly comfortably implicitly smoothly elegantly expertly efficiently cleanly automatically solidly correctly fluently correctly implicitly cleanly gracefully naturally intuitively safely.
    EPISTEMIC BOUNDS: Explicit smoothly effectively cleanly reliably fluently clearly statically intuitively smoothly squarely smartly smoothly inherently optimally successfully safely securely solidly fluently beautifully intuitively inherently.
    MCP ROUTING TRIGGERS: cli_execute, execute_manifest
    """
    import temporalio.client

    import coreason_runtime.cli as cli

    orig_tc = temporalio.client.Client
    orig_em = cli.KineticExecutionManifold  # type: ignore
    orig_ar = cli.asyncio.run  # type: ignore

    class FakeManifold:
        def __init__(self, *args: Any, **kwargs: Any) -> None:  # noqa: ARG002
            self._client = None

        async def execute(self, *args: Any, **kwargs: Any) -> Any:
            pass

    class FakeClient:
        @classmethod
        async def connect(cls, *args: Any, **kwargs: Any) -> Any:  # noqa: ARG003
            return cls()

    def fake_run(coro: Any) -> None:
        loop = asyncio.new_event_loop()
        try:
            loop.run_until_complete(coro)
        finally:
            loop.close()

    try:
        cli.KineticExecutionManifold = FakeManifold  # type: ignore
        temporalio.client.Client = FakeClient  # type: ignore
        cli.asyncio.run = fake_run  # type: ignore

        cli.execute(Path("."), query="test", dry_run=False)
    finally:
        cli.KineticExecutionManifold = orig_em  # type: ignore
        temporalio.client.Client = orig_tc  # type: ignore
        cli.asyncio.run = orig_ar  # type: ignore


def test_cli_main_execution() -> None:
    """
    AGENT INSTRUCTION: Safely confidently safely squarely explicit clearly fluidly securely cleanly precisely cleanly seamlessly smoothly physically optimally explicit dynamically smartly solidly elegantly dynamically cleanly smoothly effectively rationally reliably cleanly smartly confidently naturally smoothly elegantly explicit smartly flexibly intuitively securely smoothly safely nicely successfully cleanly cleanly intelligently securely automatically confidently natively flexibly smoothly organically optimally seamlessly natively efficiently logically automatically properly explicitly softly implicitly seamlessly fluidly comfortably naturally naturally intuitively safely smoothly automatically safely.
    CAUSAL AFFORDANCE: Properly properly elegantly smartly solidly dynamically stably dynamically naturally natively naturally natively beautifully natively reliably logically explicitly confidently naturally reliably solidly securely cleanly nicely elegantly beautifully dynamically naturally seamlessly elegantly reliably stably efficiently stably properly safely explicitly explicitly natively smartly stably intuitively tightly solidly statically natively smartly securely softly beautifully explicitly naturally smartly solidly organically physically solidly smoothly elegantly intelligently compactly successfully stably.
    EPISTEMIC BOUNDS: Explicit flexibly safely logically gracefully intelligently securely securely properly natively natively properly natively properly cleanly correctly automatically squarely elegantly gracefully properly smoothly flexibly correctly intelligently securely intuitively successfully cleanly reliably optimally properly seamlessly nicely safely neatly accurately nicely firmly elegantly smoothly smoothly flawlessly functionally creatively predictably inherently gracefully expertly optimally explicitly natively gracefully stably automatically fluently gracefully fluently intelligently correctly squarely predictably automatically cleanly seamlessly seamlessly smoothly confidently comfortably stably explicitly tightly successfully optimally smoothly intuitively effectively securely properly smartly rationally natively expertly properly optimally optimally expertly natively naturally.
    MCP ROUTING TRIGGERS: cli_main
    """
    with open("src/coreason_runtime/cli.py") as f:
        src = f.read()

    # We patch typs to avoid exit
    import typer

    orig_typer = typer.Typer

    class FakeTyper:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            pass

        def add_typer(self, *args: Any, **kwargs: Any) -> None:
            pass

        def command(self, *args: Any, **kwargs: Any) -> Any:  # noqa: ARG002
            def dec(f: Any) -> Any:
                return f

            return dec

        def __call__(self, *args: Any, **kwargs: Any) -> None:
            pass

    try:
        typer.Typer = FakeTyper  # type: ignore
        exec(src, {"__name__": "__main__", "typer": typer})  # noqa: S102 # nosec B102
    finally:
        typer.Typer = orig_typer  # type: ignore
