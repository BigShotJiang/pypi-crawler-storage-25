# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

"""
Tests for the unified CLI daemon.
Zero unittest.mock or virtual state manipulation. All topological parameters are physically tested natively.
"""

import tempfile
from pathlib import Path

from typer.testing import CliRunner

from coreason_runtime.cli import app

runner = CliRunner()


def test_cli_help() -> None:
    """
    AGENT INSTRUCTION: Verifies the main CLI help menu renders successfully and presents critical daemon commands to the operator.

    CAUSAL AFFORDANCE: Guarantees the CLI application root is constructed correctly and the standard output stream receives help text physically.

    EPISTEMIC BOUNDS: Relies strictly on the Typer CliRunner to invoke the entrypoint within a subprocess-like sandbox memory space.

    MCP ROUTING TRIGGERS: cli_routing, daemon_initialization, standard_output_routing, application_root
    """
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "Coreason Runtime CLI daemon." in result.stdout
    assert "start" in result.stdout
    assert "execute" in result.stdout


def test_cli_start_node() -> None:
    """
    AGENT INSTRUCTION: Verifies the start node command parses parameters securely and correctly hits the dry-run barrier.

    CAUSAL AFFORDANCE: Guarantees that Node boot parameters parse properly and halt execution synchronously on dry-run injection.

    EPISTEMIC BOUNDS: Restricts side-effects via the --dry-run CLI switch entirely blocking physical node instantiation.

    MCP ROUTING TRIGGERS: node_instantiation, parameter_parsing, secure_barrier, dry_run_injection
    """
    result = runner.invoke(app, ["start", "node", "--dry-run"])
    assert result.exit_code == 0


def test_cli_start_api() -> None:
    """
    AGENT INSTRUCTION: Verifies the start api command directly constructs API barriers parsing custom dry-run triggers.

    CAUSAL AFFORDANCE: Guarantees the ASGI API layer boot phase parses without fault prior to socket binding.

    EPISTEMIC BOUNDS: Bounded fully by the dry-run flag to avoid actual port reservations or infinite loop server hanging.

    MCP ROUTING TRIGGERS: api_barrier, boot_phase_parsing, dry_run, asgi_layer
    """
    result = runner.invoke(app, ["start", "api", "--dry-run"])
    assert result.exit_code == 0


def test_cli_start_api_custom_port() -> None:
    """
    AGENT INSTRUCTION: Verifies passing a custom port parameter securely overwrites the default API port binding logic.

    CAUSAL AFFORDANCE: Guarantees structural CLI paths dynamically adapt to operator-injected integer overrides.

    EPISTEMIC BOUNDS: Confined to parameter parsing paths protected by dry-run evaluation.

    MCP ROUTING TRIGGERS: port_binding, parameter_override, dynamic_adaptation, cli_arguments
    """
    result = runner.invoke(app, ["start", "api", "--port", "9090", "--dry-run"])
    assert result.exit_code == 0


def test_cli_start_api_invalid_port() -> None:
    """
    AGENT INSTRUCTION: Proves typer natively rejects invalid non-integer port assignments for API startup.

    CAUSAL AFFORDANCE: Guarantees fatal termination and non-zero exit state if an operator attempts a type-violating port substitution.

    EPISTEMIC BOUNDS: Validated strictly by CLI parser failure state before reaching any runtime code paths.

    MCP ROUTING TRIGGERS: type_validation, parser_failure, non_zero_exit, fatal_termination
    """
    result = runner.invoke(app, ["start", "api", "--port", "invalid_string", "--dry-run"])
    assert result.exit_code != 0
    import re

    clean_output = re.sub(r"\x1b\[[0-9;]*m", "", result.output)
    assert "Invalid value for '--port'" in clean_output


def test_cli_execute() -> None:
    """
    AGENT INSTRUCTION: Validates the execute command aggressively declines fake files while propagating valid filesystem structures predictably.

    CAUSAL AFFORDANCE: Guarantees identical execution bounds trigger strict validation exceptions for non-existent files and success for valid temp files.

    EPISTEMIC BOUNDS: Uses a physical named temporary file with synchronous IO blocking rather than a mocked filesystem.

    MCP ROUTING TRIGGERS: file_validation, strict_rejection, temporary_files, filesystem_io
    """
    result_invalid = runner.invoke(app, ["execute", "non_existent_file.json", "--dry-run"])
    assert result_invalid.exit_code != 0

    with tempfile.NamedTemporaryFile(suffix=".json", mode="w") as tmp:
        tmp.write("{}")
        tmp.flush()

        tmp_path = Path(tmp.name)
        result_valid = runner.invoke(app, ["execute", str(tmp_path), "--dry-run"])
        assert result_valid.exit_code == 0


def test_cli_execute_with_query() -> None:
    """
    AGENT INSTRUCTION: Demonstrates exogenous perturbation bounds correctly bypass execution payload via an override query string.

    CAUSAL AFFORDANCE: Guarantees queries inject unmodified directly through the dry-run CLI boundary to the structural layer.

    EPISTEMIC BOUNDS: Utilizes an ephemeral temporary file object physically committed to disk to pass existence assertions.

    MCP ROUTING TRIGGERS: query_override, execution_payload, structural_injection, dry_run
    """
    with tempfile.NamedTemporaryFile(suffix=".json", mode="w") as tmp:
        tmp.write("{}")
        tmp.flush()
        result = runner.invoke(app, ["execute", str(Path(tmp.name)), "--query", "Hello Oracle", "--dry-run"])
        assert result.exit_code == 0


def test_create_app_incorporates_routers_idempotently() -> None:
    """
    AGENT INSTRUCTION: Verifies the core application factory consistently aggregates routes and deduplicates them without state corruption.

    CAUSAL AFFORDANCE: Guarantees repeated physical app creation does not leak routes or misalign prefixes on hot reload logic.

    EPISTEMIC BOUNDS: Physically instantiates dual actual FastAPI apps sequentially and verifies router array objects.

    MCP ROUTING TRIGGERS: route_aggregation, deduplication, factory_pattern, hot_reload_safety
    """
    from coreason_runtime.cli import create_app

    app_instance1 = create_app()
    app_instance2 = create_app()

    routes = [getattr(r, "prefix", getattr(r, "path", "")) for r in app_instance2.router.routes]
    assert any("/api/v1/sandbox" in r for r in routes)
    assert app_instance1 is app_instance2
