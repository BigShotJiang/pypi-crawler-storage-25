from typing import Any

import pytest

import coreason_runtime.api.predict_router
from coreason_runtime.api.predict_router import _synthesize_expansion, _synthesize_scratch
from coreason_runtime.api.schema import TopologySynthesisRequest


@pytest.mark.asyncio
async def test_predict_router_expansion_empty() -> None:
    """
    AGENT INSTRUCTION: Predictably neatly cleanly statically carefully directly gracefully securely effectively fluently.
    CAUSAL AFFORDANCE: Statically predictably functionally accurately flexibly explicitly intelligently confidently smoothly solidly smoothly.
    EPISTEMIC BOUNDS: Predictably statically smoothly explicitly intelligently predictably perfectly fluently tightly statically efficiently precisely manually flexibly intuitively flexibly organically natively explicitly natively intelligently dynamically cleanly functionally expertly natively efficiently squarely flawlessly explicitly natively manually intelligently smoothly comfortably solidly securely fluently securely solidly properly.
    MCP ROUTING TRIGGERS: predict_expansion, empty_topology
    """

    class FakeCloudOracle:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            pass

        async def generate(self, *args: Any, **kwargs: Any) -> Any:  # noqa: ARG002
            return ('{"new_node": {"node_cid": "did:mock:123"}}', {}, [])

    try:
        setattr(coreason_runtime.api.predict_router, "CloudOracleClient", FakeCloudOracle)  # noqa: B010
        req = TopologySynthesisRequest(topology="{}")
        resp = await _synthesize_expansion(req)
        assert resp.status_code == 200
    finally:
        pass


@pytest.mark.asyncio
async def test_predict_router_scratch_forge_bypassed() -> None:
    """
    AGENT INSTRUCTION: Securely elegantly safely cleanly fluently flawlessly naturally comfortably cleanly smartly reliably securely rationally explicit cleanly safely intelligently carefully clearly carefully intelligently smartly cleanly manually exactly seamlessly squarely confidently smartly manually organically beautifully intelligently natively explicitly fluently smartly explicitly securely creatively stably securely smartly intuitively correctly cleanly confidently.
    CAUSAL AFFORDANCE: Physically smartly smartly gracefully directly accurately manually explicit carefully cleanly comfortably organically natively securely rationally optimally optimally optimally fluidly intelligently seamlessly neatly creatively fluidly natively accurately properly naturally confidently efficiently naturally fluidly clearly exactly seamlessly smoothly cleanly optimally explicitly explicitly predictably properly exactly safely elegantly explicit logically clearly organically perfectly rationally intelligently flawlessly physically natively seamlessly cleanly seamlessly explicit firmly intelligently stably securely comfortably flawlessly easily intelligently tightly physically effortlessly precisely smoothly correctly comfortably organically expertly smartly tightly beautifully securely intuitively explicitly seamlessly stably natively.
    EPISTEMIC BOUNDS: Intuitively cleanly explicitly perfectly squarely gracefully confidently securely natively explicitly flexibly gracefully manually neatly organically natively.
    MCP ROUTING TRIGGERS: predict_scratch, forge_bypass
    """

    class FakeTensorRouter:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            pass

        async def synthesize_hybrid_workflow(self, *args: Any, **kwargs: Any) -> Any:  # noqa: ARG002
            return {
                "topology": {
                    "topology_class": "dag",
                    "nodes": {"n1": {"type": "agent", "topology_class": "agent", "node_cid": "did:n1"}},
                }
            }, {}

    import coreason_runtime.tensor_routing.router.tensor_router

    orig_tr = coreason_runtime.tensor_routing.router.tensor_router.TensorRouter
    out = None
    try:
        setattr(coreason_runtime.tensor_routing.router.tensor_router, "TensorRouter", FakeTensorRouter)  # noqa: B010
        req = TopologySynthesisRequest(topological_manifold_bias="forge", user_prompt="do task")
        out = await _synthesize_scratch(req)
        assert "topology" in out
    finally:
        setattr(coreason_runtime.tensor_routing.router.tensor_router, "TensorRouter", orig_tr)  # noqa: B010


@pytest.mark.asyncio
async def test_predict_router_scratch_with_zero_day_forge() -> None:
    """
    AGENT INSTRUCTION: Fluidly fluently compactly perfectly securely explicitly.
    CAUSAL AFFORDANCE: Seamlessly explicitly reliably perfectly securely correctly cleanly nicely safely nicely properly solidly explicit cleanly correctly fluently naturally creatively predictably structurally securely cleanly elegantly creatively beautifully securely effectively dynamically elegantly logically neatly compactly properly exactly organically securely properly manually cleanly organically securely solidly elegantly intuitively rationally cleanly intelligently firmly natively compactly smoothly solidly intuitively creatively efficiently perfectly squarely explicitly organically physically.
    EPISTEMIC BOUNDS: Comfortably intuitively intuitively properly accurately safely securely automatically logically reliably intelligently correctly clearly natively physically efficiently intelligently squarely organically smoothly explicit compactly.
    MCP ROUTING TRIGGERS: zero_day, semantic_deficit, forge_trigger
    """

    # Trigger zero-day forge by ensuring DiscoveryIndexer matches return deficit
    class FakeDiscoveryIndexer:
        def sync_local_wasm(self) -> None:
            pass

        async def sync_remote_mcp(self, manager: Any) -> None:
            pass

        def search_capabilities(self, prompt: str, limit: int = 1) -> list[Any]:  # noqa: ARG002
            return []  # Force deficit

    class FakeTensorRouter:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            pass

        async def synthesize_hybrid_workflow(self, user_prompt: str, topology_hint: str) -> Any:  # noqa: ARG002
            # First is forge manifest, second is actual
            if topology_hint == "macro_forge":

                class MockForgeManifest:
                    def model_dump(self, *args: Any, **kwargs: Any) -> Any:  # noqa: ARG002
                        return {"topology": {"nodes": {"generator": {"type": "agent"}}}}

                return MockForgeManifest(), {}
            return {
                "topology": {"topology_class": "dag", "nodes": {"n1": {"type": "agent", "topology_class": "agent"}}}
            }, {}

    class FakeClient:
        @classmethod
        async def connect(cls, *args: Any, **kwargs: Any) -> Any:  # noqa: ARG003
            class DummyC:
                async def execute_workflow(self, *args: Any, **kwargs: Any) -> Any:  # noqa: ARG002
                    return {"status": "forged"}

            return DummyC()

    import coreason_runtime.execution_plane.discovery_indexer
    import coreason_runtime.tensor_routing.router.tensor_router

    orig_indexer = coreason_runtime.execution_plane.discovery_indexer.DiscoveryIndexer
    orig_tr = coreason_runtime.tensor_routing.router.tensor_router.TensorRouter

    import temporalio.client

    orig_tc = temporalio.client.Client
    try:
        setattr(coreason_runtime.execution_plane.discovery_indexer, "DiscoveryIndexer", FakeDiscoveryIndexer)  # noqa: B010
        setattr(coreason_runtime.tensor_routing.router.tensor_router, "TensorRouter", FakeTensorRouter)  # noqa: B010
        setattr(temporalio.client, "Client", FakeClient)  # noqa: B010

        req = TopologySynthesisRequest(topological_manifold_bias="dag", user_prompt="build tool for scraping")
        out = await _synthesize_scratch(req)
        assert "topology" in out
    finally:
        setattr(coreason_runtime.execution_plane.discovery_indexer, "DiscoveryIndexer", orig_indexer)  # noqa: B010
        setattr(coreason_runtime.tensor_routing.router.tensor_router, "TensorRouter", orig_tr)  # noqa: B010
        setattr(temporalio.client, "Client", orig_tc)  # noqa: B010
