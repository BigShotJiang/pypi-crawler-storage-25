# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from temporalio.client import WorkflowExecutionStatus

from coreason_runtime.api.sandbox_router import state_router as router

mock_app = FastAPI()
mock_app.include_router(router)
client = TestClient(mock_app)


@pytest.mark.asyncio
async def test_sync_state_invalid_payload() -> None:
    # Do not mock validate_python to test the ValidationError path
    response = client.post("/api/v1/state/sync/wf-1", json={"invalid": "payload"})
    assert response.status_code == 422
    assert "Invalid state delta payload" in response.json()["detail"]


@pytest.mark.asyncio
async def test_sync_state_not_running() -> None:
    with (
        patch("coreason_runtime.api.sandbox_router.Client.connect", new_callable=AsyncMock) as mock_connect,
        patch("coreason_runtime.api.sandbox_router.AnyTopologyManifestAdapter.validate_python"),
    ):
        mock_client = MagicMock()
        mock_connect.return_value = mock_client
        mock_handle = MagicMock()
        mock_client.get_workflow_handle.return_value = mock_handle

        mock_desc = MagicMock()
        mock_desc.status = WorkflowExecutionStatus.COMPLETED
        mock_handle.describe = AsyncMock(return_value=mock_desc)

        response = client.post("/api/v1/state/sync/wf-1", json={"topology_class": "dag"})
        assert response.status_code == 410
        assert "Workflow has already finished" in response.json()["detail"]


@pytest.mark.asyncio
async def test_sync_state_success() -> None:
    with (
        patch("coreason_runtime.api.sandbox_router.Client.connect", new_callable=AsyncMock) as mock_connect,
        patch("coreason_runtime.api.sandbox_router.AnyTopologyManifestAdapter.validate_python"),
    ):
        mock_client = MagicMock()
        mock_connect.return_value = mock_client
        mock_handle = MagicMock()
        mock_client.get_workflow_handle.return_value = mock_handle

        mock_desc = MagicMock()
        mock_desc.status = WorkflowExecutionStatus.RUNNING
        mock_handle.describe = AsyncMock(return_value=mock_desc)
        mock_handle.signal = AsyncMock()

        payload = {"topology_class": "dag"}
        response = client.post("/api/v1/state/sync/wf-1", json=payload)
        assert response.status_code == 200
        assert response.json() == {"status": "signal_accepted"}
        mock_handle.signal.assert_called_once_with("apply_state_delta", payload)


@pytest.mark.asyncio
async def test_sync_state_temporal_exception() -> None:
    with (
        patch("coreason_runtime.api.sandbox_router.Client.connect", new_callable=AsyncMock) as mock_connect,
        patch("coreason_runtime.api.sandbox_router.AnyTopologyManifestAdapter.validate_python"),
    ):
        mock_connect.side_effect = Exception("Temporal is down")

        response = client.post("/api/v1/state/sync/wf-1", json={"topology_class": "dag"})
        assert response.status_code == 500
        assert "Temporal is down" in response.json()["detail"]


@pytest.mark.asyncio
async def test_read_state_success() -> None:
    with patch("coreason_runtime.api.sandbox_router.Client.connect", new_callable=AsyncMock) as mock_connect:
        mock_client = MagicMock()
        mock_connect.return_value = mock_client
        mock_handle = MagicMock()
        mock_client.get_workflow_handle.return_value = mock_handle
        mock_handle.query = AsyncMock(return_value={"some": "state"})

        response = client.get("/api/v1/state/sync/wf-1")
        assert response.status_code == 200
        assert response.json() == {"workflow_id": "wf-1", "state": {"some": "state"}}
        mock_handle.query.assert_called_once_with("get_current_state")


@pytest.mark.asyncio
async def test_read_state_error() -> None:
    with patch("coreason_runtime.api.sandbox_router.Client.connect", new_callable=AsyncMock) as mock_connect:
        mock_connect.side_effect = Exception("Workflow not found")

        response = client.get("/api/v1/state/sync/wf-1")
        assert response.status_code == 404
        assert "Workflow not found or query failed" in response.json()["detail"]
