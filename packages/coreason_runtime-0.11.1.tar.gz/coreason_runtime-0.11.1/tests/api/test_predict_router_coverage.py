import importlib
import sys
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient

from coreason_runtime.api.predict_router import _synthesize_expansion, _synthesize_scratch, predict_router
from coreason_runtime.api.schema import TopologySynthesisRequest
from coreason_runtime.orchestration.temporal_workflow_dispatcher import _WORKFLOW_REGISTRY

app = FastAPI()
app.include_router(predict_router)

client = TestClient(app)


def test_predict_router_import_error(monkeypatch: pytest.MonkeyPatch) -> None:
    """Coverage for lines 25-26: `except ImportError: pass` inside predict_router initialization."""
    monkeypatch.setitem(sys.modules, "dotenv", None)
    import coreason_runtime.api.predict_router

    importlib.reload(coreason_runtime.api.predict_router)
    # Restore safe state
    monkeypatch.delitem(sys.modules, "dotenv", raising=False)
    importlib.reload(coreason_runtime.api.predict_router)


@pytest.mark.asyncio
async def test_predict_router_raw_fallback(monkeypatch: pytest.MonkeyPatch) -> None:
    """Coverage for line 106: raw = '{}' when request.topology is not structurally valid."""
    req = TopologySynthesisRequest(user_prompt="x")
    req.topology = 42  # type: ignore

    monkeypatch.setattr("coreason_runtime.api.predict_router._generate_cached_schema", lambda x: {})

    class FakeOracle:
        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            pass

        async def generate(self, *_args: Any, **_kwargs: Any) -> tuple[str, int, None]:
            return (
                '{"new_node": {"node_cid": "did:mock", "topology_class": "agent", "type": "agent", "description": "mock node"}}',
                0,
                None,
            )

    monkeypatch.setattr("coreason_runtime.api.predict_router.CloudOracleClient", FakeOracle)

    res = await _synthesize_expansion(req)
    assert res is not None


@pytest.mark.asyncio
async def test_predict_router_yaml_safeload_none(monkeypatch: pytest.MonkeyPatch) -> None:
    """Coverage for line 316: if topology_dict is None fallback block natively."""
    req = TopologySynthesisRequest(user_prompt="x")
    req.topology = " "  # yaml.safe_load returns None natively

    monkeypatch.setattr("coreason_runtime.api.predict_router._generate_cached_schema", lambda x: {})

    class FakeOracle:
        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            pass

        async def generate(self, *_args: Any, **_kwargs: Any) -> tuple[str, int, None]:
            return '{"new_node": {"node_cid": "did:mock"}}', 0, None

    monkeypatch.setattr("coreason_runtime.api.predict_router.CloudOracleClient", FakeOracle)

    res = await _synthesize_expansion(req)
    assert res is not None


@pytest.mark.asyncio
async def test_predict_router_synthesize_scratch_discovery(monkeypatch: pytest.MonkeyPatch) -> None:
    """Coverage for lines 487-497: semantic discovery populated pipeline explicitly."""
    req = TopologySynthesisRequest(user_prompt="matchable tool")

    class FakeIndexer:
        def sync_local_wasm(self) -> None:
            pass

        async def sync_remote_mcp(self, *args: Any) -> None:
            pass

        def search_capabilities(self, prompt: str, limit: int = 1) -> list[dict[str, Any]]:  # noqa: ARG002
            return [{"capability_id": "test_tool", "description": "mock tool", "distance": 1.0}]

    monkeypatch.setattr("coreason_runtime.execution_plane.discovery_indexer.DiscoveryIndexer", FakeIndexer)

    class FakeRouter:
        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            pass

        async def synthesize_hybrid_workflow(self, user_prompt: str, topology_hint: str) -> tuple[dict[str, Any], int]:  # noqa: ARG002
            return {"topology": {"type": "dag", "nodes": {}}}, 0

    monkeypatch.setattr("coreason_runtime.tensor_routing.router.tensor_router.TensorRouter", FakeRouter)

    # We must patch Client so it doesn't actually connect to temporal
    class FakeClient:
        @classmethod
        async def connect(cls, *_args: Any, **_kwargs: Any) -> Any:
            obj = MagicMock()
            obj.start_workflow = AsyncMock()
            return obj

    monkeypatch.setattr("temporalio.client.Client", FakeClient)
    # Ensure Dag executes correctly out
    monkeypatch.setitem(_WORKFLOW_REGISTRY, "dag", MagicMock())

    await _synthesize_scratch(req)


@pytest.mark.asyncio
async def test_predict_router_synthesize_scratch_router_failure(monkeypatch: pytest.MonkeyPatch) -> None:
    """Coverage for lines 510-512: TensorRouter failure native loop fallback."""
    req = TopologySynthesisRequest(user_prompt="x")

    class FakeRouterFail:
        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            pass

        async def synthesize_hybrid_workflow(self, *_args: Any, **_kwargs: Any) -> tuple[dict[str, Any], int]:
            raise ValueError("Router crashed")

    monkeypatch.setattr("coreason_runtime.tensor_routing.router.tensor_router.TensorRouter", FakeRouterFail)
    monkeypatch.setattr("coreason_runtime.execution_plane.discovery_indexer.DiscoveryIndexer", MagicMock())

    with pytest.raises(HTTPException, match="Router crashed"):
        await _synthesize_scratch(req)


@pytest.mark.asyncio
async def test_predict_router_synthesize_scratch_invalid_manifest(monkeypatch: pytest.MonkeyPatch) -> None:
    """Coverage for line 535: non-valid schema payloads natively returning correctly."""
    req = TopologySynthesisRequest(user_prompt="x")

    class FakeRouterInvalid:
        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            pass

        async def synthesize_hybrid_workflow(self, *_args: Any, **_kwargs: Any) -> tuple[dict[str, Any], int]:
            # Return dict directly without model_dump
            return {"bad": "yes"}, 0

    monkeypatch.setattr("coreason_runtime.tensor_routing.router.tensor_router.TensorRouter", FakeRouterInvalid)
    monkeypatch.setattr("coreason_runtime.execution_plane.discovery_indexer.DiscoveryIndexer", MagicMock())

    res = await _synthesize_scratch(req)
    assert res == {"bad": "yes"}


@pytest.mark.asyncio
async def test_predict_router_synthesize_scratch_missing_class(monkeypatch: pytest.MonkeyPatch) -> None:
    """Coverage for lines 546: force inject topology_class explicitly, 551-560: self-cycle removal cleanly."""
    req = TopologySynthesisRequest(user_prompt="x")

    class FakeManifest:
        def model_dump(self, *_args: Any, **_kwargs: Any) -> dict[str, Any]:
            return {
                "topology": {
                    "type": "dag",
                    "nodes": {"agent1": {}},  # No topology_class
                    "edges": [
                        {"source": "agent1", "target": "agent1"},
                        ["agent2", "agent2"],
                        ["agent1", "agent2"],
                    ],
                }
            }

    class FakeRouterMissing:
        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            pass

        async def synthesize_hybrid_workflow(self, *_args: Any, **_kwargs: Any) -> tuple[Any, int]:
            return FakeManifest(), 0

    monkeypatch.setattr("coreason_runtime.tensor_routing.router.tensor_router.TensorRouter", FakeRouterMissing)
    monkeypatch.setattr("coreason_runtime.execution_plane.discovery_indexer.DiscoveryIndexer", MagicMock())

    class FakeClient:
        @classmethod
        async def connect(cls, *_args: Any, **_kwargs: Any) -> Any:
            obj = MagicMock()
            obj.start_workflow = AsyncMock()
            return obj

    monkeypatch.setattr("temporalio.client.Client", FakeClient)
    monkeypatch.setitem(_WORKFLOW_REGISTRY, "dag", MagicMock())

    res = await _synthesize_scratch(req)
    assert res["topology"]["nodes"]["agent1"]["topology_class"] == "agent"
    assert len(res["topology"]["edges"]) == 1


@pytest.mark.asyncio
async def test_predict_router_synthesize_scratch_unregistered_workflow(monkeypatch: pytest.MonkeyPatch) -> None:
    """Coverage for lines 599-632: unregistered workflow exceptions flawlessly."""
    req = TopologySynthesisRequest(user_prompt="x")

    class FakeManifest:
        def model_dump(self, *_args: Any, **_kwargs: Any) -> dict[str, Any]:
            return {"topology": {"type": "unknown_manifest"}}

    class FakeRouterUnknown:
        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            pass

        async def synthesize_hybrid_workflow(self, *_args: Any, **_kwargs: Any) -> tuple[Any, int]:
            return FakeManifest(), 0

    monkeypatch.setattr("coreason_runtime.tensor_routing.router.tensor_router.TensorRouter", FakeRouterUnknown)
    monkeypatch.setattr("coreason_runtime.execution_plane.discovery_indexer.DiscoveryIndexer", MagicMock())

    with pytest.raises(HTTPException, match="has no registered workflow"):
        await _synthesize_scratch(req)
