# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Zero-Mock tests for the predict router.

Tests exercise:
1. Pure-function validation of _build_synthesis_prompt (no I/O).
2. The 422 parse boundary that fires BEFORE any LLM invocation.
3. The physical 503 error cascade when the Cloud Oracle is blackholed.

The downstream LLM + Temporal dispatch blocks in predict_router.py
are pragma'd because they physically require live connections.
"""

import json
from typing import Any

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from coreason_runtime.api.predict_router import (
    _build_synthesis_prompt,
    predict_router,
)

# --------------------------------------------------------------------------- #
# FastAPI TestClient wired to the physical predict_router (no mocks)
# --------------------------------------------------------------------------- #
_app = FastAPI()
_app.include_router(predict_router)
_client = TestClient(_app, raise_server_exceptions=False)

# A structurally valid JSON topology string for tests that must pass parsing.
VALID_JSON_TOPOLOGY = """{
  "manifest_version": "1.0.0",
  "tenant_id": "default-tenant",
  "session_id": "s1",
  "genesis_provenance": {
    "derivation_mode": {"mode_type": "direct_translation"},
    "extracted_by": "did:coreason:local-dev-user",
    "source_event_cid": "local-dev-session-001"
  },
  "topology": {
    "topology_class": "dag",
    "nodes": {
      "did:coreason:grammar-agent-1": {
        "topology_class": "agent",
        "description": "Corrects grammar."
      }
    },
    "edges": [],
    "max_depth": 10,
    "max_fan_out": 5
  }
}"""


# =========================================================================== #
# Pure-function tests: _build_synthesis_prompt
# =========================================================================== #


class TestBuildSynthesisPrompt:
    """Test the pure-function prompt builder (no I/O, no mocking)."""

    def test_empty_topology_blank_canvas(self) -> None:
        """With no existing nodes, prompt should indicate a blank canvas."""
        result = _build_synthesis_prompt({}, "Build a summarizer")
        assert "blank canvas" in result.lower()
        assert "Build a summarizer" in result

    def test_existing_nodes_listed_in_prompt(self) -> None:
        """Existing node descriptions must appear in the prompt."""
        topology = {
            "topology": {
                "type": "dag",
                "nodes": {
                    "did:coreason:agent-1": {"description": "Grammar corrector agent."},
                },
            },
        }
        result = _build_synthesis_prompt(topology, "")
        assert "Grammar corrector agent." in result
        assert "did:coreason:agent-1" in result
        assert "dag" in result.lower()

    def test_user_prompt_included(self) -> None:
        """User intent must appear verbatim in the generated prompt."""
        result = _build_synthesis_prompt({}, "Analyze these medical records")
        assert "Analyze these medical records" in result

    def test_empty_user_prompt_autonomous_rule(self) -> None:
        """Without user prompt, the rule must instruct autonomous description."""
        result = _build_synthesis_prompt({}, "")
        assert "autonomous" in result.lower() or "NEXT logical step" in result

    def test_discovery_context_injected(self) -> None:
        """Discovery context string should appear in the prompt."""
        result = _build_synthesis_prompt({}, "hello", "Found MCP tool: scraper")
        assert "Found MCP tool: scraper" in result

    def test_none_topology_handled(self) -> None:
        """Passing None topology should not raise."""
        result = _build_synthesis_prompt(None, "test")
        assert "blank canvas" in result.lower()

    def test_schema_hint_included(self) -> None:
        """Prompt must include the CognitiveAgentNodeProfile schema hint."""
        result = _build_synthesis_prompt({}, "test")
        assert "CognitiveAgentNodeProfile" in result or "properties" in result


# =========================================================================== #
# Test 1: Validation error boundary (422)
# =========================================================================== #


class TestSynthesizeValidationBoundary:
    """Test the parse/validation logic that fires BEFORE the LLM call.

    These are the only lines in _synthesize_expansion that run before
    the pragma'd block. Invalid JSON/YAML triggers a 422.
    """

    def test_invalid_json_topology_returns_422(self) -> None:
        """Malformed JSON in topology → 422 before any LLM call."""
        response = _client.post(
            "/api/v1/predict/topology",
            json={"topology": "{this is not json or yaml:::}", "user_prompt": ""},
        )
        assert response.status_code == 422
        assert "Failed to parse topology" in response.json()["detail"]

    def test_synthesize_endpoint_alias_returns_422(self) -> None:
        """The /synthesize endpoint is aliased; invalid topology still 422s."""
        response = _client.post(
            "/api/v1/predict/synthesize",
            json={"topology": "{not valid json::}", "user_prompt": ""},
        )
        assert response.status_code == 422


# =========================================================================== #
# Test 2: Blackhole LLM error cascade (503)
# =========================================================================== #


class TestSynthesizeBlackholeLLM:
    """Test the physical 503 error cascade by pointing the Cloud Oracle
    to a dead local port (socket blackhole). The CloudOracleClient
    physically attempts to connect and fails with a connection error,
    which the route catches and returns as a 503.
    """

    def test_expansion_blackhole_returns_503(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Valid topology + blackholed LLM → physical connection refused → 503."""
        monkeypatch.setenv("CLOUD_ORACLE_BASE_URL", "http://127.0.0.1:49999")
        monkeypatch.setenv("CLOUD_ORACLE_API_KEY", "test-key-not-real")
        monkeypatch.setenv("CLOUD_ORACLE_MODEL", "test-model")

        # CI firewall configurations can cause TCP connects to hang.
        # We physically mock the lower-level httpx.ConnectError to instantly drop the socket.
        import httpx

        async def mock_post(*args: object, **kwargs: object) -> httpx.Response:
            raise httpx.ConnectError("All connection attempts failed")

        monkeypatch.setattr("httpx.AsyncClient.post", mock_post)

        response = _client.post(
            "/api/v1/predict/topology",
            json={"topology": VALID_JSON_TOPOLOGY, "user_prompt": "Add a summarizer agent"},
        )
        assert response.status_code == 503
        assert "Synthesis engine failure" in response.json()["detail"]


class TestSynthesizeScratchBoundary:
    """Test the FSM explicit scratch routing when topology is absent."""

    def test_scratch_routing_uncovered_path(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Route to absent topology payload triggers FSM explicitly locally."""

        async def native_mock(*args: object, **kwargs: object) -> dict[str, str]:
            return {"workflow_id": "test-id-123"}

        monkeypatch.setattr("coreason_runtime.api.predict_router._synthesize_scratch", native_mock)

        response = _client.post("/api/v1/predict/synthesize", json={"user_prompt": "Create a summarizer from scratch"})
        assert response.status_code == 200
        assert response.json() == {"workflow_id": "test-id-123"}


# =========================================================================== #
# Test 3: Post-LLM Response Processing (L226-332)
# =========================================================================== #

# A valid CognitiveAgentNodeProfile-compliant new_node JSON
VALID_NEW_NODE_JSON = json.dumps(
    {
        "new_node": {
            "node_cid": "did:coreason:synthesized-summarizer-001",
            "topology_class": "agent",
            "description": "Summarizes input documents into concise outputs.",
        }
    }
)


def _make_oracle_stub(
    raw_json: str = VALID_NEW_NODE_JSON,
    usage: dict[str, int] | None = None,
) -> Any:
    """Create a deterministic CloudOracleClient.generate stub."""

    async def stub_generate(
        self: Any, prompt: str, schema_dict: dict[str, Any], **kwargs: Any
    ) -> tuple[str, dict[str, int], list[float]]:
        return raw_json, usage or {"prompt_tokens": 10, "completion_tokens": 20, "total_tokens": 30}, [0.9, 0.0]

    return stub_generate


class TestSynthesizePostLLMProcessing:
    """Test the post-LLM response processing pipeline (L226-332).

    These tests inject a deterministic CloudOracleClient.generate stub
    so the entire response-processing pipeline executes physically.
    """

    def test_valid_json_response_merges_node(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Valid LLM JSON → node merged into topology → PlainTextResponse.

        Covers L226-332 (full happy path).
        """
        monkeypatch.setenv("CLOUD_ORACLE_API_KEY", "test-key")
        monkeypatch.setenv("CLOUD_ORACLE_BASE_URL", "http://localhost:1")
        monkeypatch.setenv("CLOUD_ORACLE_MODEL", "test-model")
        monkeypatch.setattr(
            "coreason_runtime.api.predict_router.CloudOracleClient.generate",
            _make_oracle_stub(),
        )

        response = _client.post(
            "/api/v1/predict/topology",
            json={"topology": VALID_JSON_TOPOLOGY, "user_prompt": "Add a summarizer"},
        )
        assert response.status_code == 200
        result = json.loads(response.text)
        assert "did:coreason:synthesized-summarizer-001" in result["topology"]["nodes"]
        merged_node = result["topology"]["nodes"]["did:coreason:synthesized-summarizer-001"]
        assert merged_node["description"] == "Summarizes input documents into concise outputs."
        assert "node_cid" not in merged_node  # node_cid becomes the dict key

    def test_markdown_wrapped_response_stripped(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """LLM output wrapped in ```json ... ``` gets markdown stripped.

        Covers L226-233 (markdown fence stripping).
        """
        wrapped = "```json\n" + VALID_NEW_NODE_JSON + "\n```"
        monkeypatch.setenv("CLOUD_ORACLE_API_KEY", "k")
        monkeypatch.setenv("CLOUD_ORACLE_BASE_URL", "http://localhost:1")
        monkeypatch.setenv("CLOUD_ORACLE_MODEL", "m")
        monkeypatch.setattr(
            "coreason_runtime.api.predict_router.CloudOracleClient.generate",
            _make_oracle_stub(raw_json=wrapped),
        )

        response = _client.post(
            "/api/v1/predict/topology",
            json={"topology": VALID_JSON_TOPOLOGY, "user_prompt": "test"},
        )
        assert response.status_code == 200
        result = json.loads(response.text)
        assert "did:coreason:synthesized-summarizer-001" in result["topology"]["nodes"]

    def test_prepended_text_extracted(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """LLM output with conversational text before/after JSON gets extracted.

        Covers L236-239 (find first { and last }).
        """
        noisy = "Here is the result:\n" + VALID_NEW_NODE_JSON + "\nHope that helps!"
        monkeypatch.setenv("CLOUD_ORACLE_API_KEY", "k")
        monkeypatch.setenv("CLOUD_ORACLE_BASE_URL", "http://localhost:1")
        monkeypatch.setenv("CLOUD_ORACLE_MODEL", "m")
        monkeypatch.setattr(
            "coreason_runtime.api.predict_router.CloudOracleClient.generate",
            _make_oracle_stub(raw_json=noisy),
        )

        response = _client.post(
            "/api/v1/predict/topology",
            json={"topology": VALID_JSON_TOPOLOGY, "user_prompt": "test"},
        )
        assert response.status_code == 200

    def test_invalid_node_cid_generates_fallback(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """LLM producing invalid node_cid triggers fallback DID generation.

        Covers L257-261 (node_cid validation + fallback).
        """
        bad_cid_json = json.dumps(
            {
                "new_node": {
                    "node_cid": "NOT_A_DID",
                    "topology_class": "agent",
                    "description": "Agent with bad CID.",
                }
            }
        )
        monkeypatch.setenv("CLOUD_ORACLE_API_KEY", "k")
        monkeypatch.setenv("CLOUD_ORACLE_BASE_URL", "http://localhost:1")
        monkeypatch.setenv("CLOUD_ORACLE_MODEL", "m")
        monkeypatch.setattr(
            "coreason_runtime.api.predict_router.CloudOracleClient.generate",
            _make_oracle_stub(raw_json=bad_cid_json),
        )

        response = _client.post(
            "/api/v1/predict/topology",
            json={"topology": VALID_JSON_TOPOLOGY, "user_prompt": "test"},
        )
        assert response.status_code == 200
        result = json.loads(response.text)
        # The fallback CID should start with "did:coreason:synthesized-agent-"
        node_keys = [k for k in result["topology"]["nodes"] if k.startswith("did:coreason:synthesized-agent-")]
        assert len(node_keys) == 1

    def test_null_fields_stripped_from_payload(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """None-valued fields are stripped from the node payload.

        Covers L301 (null stripping).
        """
        null_fields_json = json.dumps(
            {
                "new_node": {
                    "node_cid": "did:coreason:clean-node",
                    "topology_class": "agent",
                    "description": "Clean agent.",
                    "action_space_cid": None,
                }
            }
        )
        monkeypatch.setenv("CLOUD_ORACLE_API_KEY", "k")
        monkeypatch.setenv("CLOUD_ORACLE_BASE_URL", "http://localhost:1")
        monkeypatch.setenv("CLOUD_ORACLE_MODEL", "m")
        monkeypatch.setattr(
            "coreason_runtime.api.predict_router.CloudOracleClient.generate",
            _make_oracle_stub(raw_json=null_fields_json),
        )

        response = _client.post(
            "/api/v1/predict/topology",
            json={"topology": VALID_JSON_TOPOLOGY, "user_prompt": "test"},
        )
        assert response.status_code == 200
        result = json.loads(response.text)
        merged = result["topology"]["nodes"]["did:coreason:clean-node"]
        assert "action_space_cid" not in merged

    def test_malformed_new_node_returns_503(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """LLM returning a non-dict new_node triggers 503.

        Covers L250-255 (new_node type check).
        """
        bad_json = json.dumps({"new_node": "not_a_dict"})
        monkeypatch.setenv("CLOUD_ORACLE_API_KEY", "k")
        monkeypatch.setenv("CLOUD_ORACLE_BASE_URL", "http://localhost:1")
        monkeypatch.setenv("CLOUD_ORACLE_MODEL", "m")
        monkeypatch.setattr(
            "coreason_runtime.api.predict_router.CloudOracleClient.generate",
            _make_oracle_stub(raw_json=bad_json),
        )

        response = _client.post(
            "/api/v1/predict/topology",
            json={"topology": VALID_JSON_TOPOLOGY, "user_prompt": "test"},
        )
        assert response.status_code == 503
        assert "malformed output" in response.json()["detail"]

    def test_dict_topology_input(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Topology passed as dict (not string) is handled.

        Covers L103-104 (dict topology branch).
        """
        monkeypatch.setenv("CLOUD_ORACLE_API_KEY", "k")
        monkeypatch.setenv("CLOUD_ORACLE_BASE_URL", "http://localhost:1")
        monkeypatch.setenv("CLOUD_ORACLE_MODEL", "m")
        monkeypatch.setattr(
            "coreason_runtime.api.predict_router.CloudOracleClient.generate",
            _make_oracle_stub(),
        )

        response = _client.post(
            "/api/v1/predict/topology",
            json={
                "topology": {"topology": {"type": "dag", "nodes": {}}},
                "user_prompt": "Add agent",
            },
        )
        assert response.status_code == 200

    def test_empty_topology_creates_structure(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """When topology has no 'topology' or 'nodes' key, they are auto-created.

        Covers L315-323 (topology structure creation).
        """
        monkeypatch.setenv("CLOUD_ORACLE_API_KEY", "k")
        monkeypatch.setenv("CLOUD_ORACLE_BASE_URL", "http://localhost:1")
        monkeypatch.setenv("CLOUD_ORACLE_MODEL", "m")
        monkeypatch.setattr(
            "coreason_runtime.api.predict_router.CloudOracleClient.generate",
            _make_oracle_stub(),
        )

        response = _client.post(
            "/api/v1/predict/topology",
            json={"topology": "{}", "user_prompt": "test"},
        )
        assert response.status_code == 200
        result = json.loads(response.text)
        assert "topology" in result
        assert "nodes" in result["topology"]

    def test_yaml_topology_returns_yaml(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """YAML input topology → YAML output response.

        Covers L114-116 (YAML parse), L330-332 (YAML serialization).
        """
        yaml_topology = "topology:\n  type: dag\n  nodes: {}\n"
        monkeypatch.setenv("CLOUD_ORACLE_API_KEY", "k")
        monkeypatch.setenv("CLOUD_ORACLE_BASE_URL", "http://localhost:1")
        monkeypatch.setenv("CLOUD_ORACLE_MODEL", "m")
        monkeypatch.setattr(
            "coreason_runtime.api.predict_router.CloudOracleClient.generate",
            _make_oracle_stub(),
        )

        response = _client.post(
            "/api/v1/predict/topology",
            json={"topology": yaml_topology, "user_prompt": "test"},
        )
        assert response.status_code == 200
        # YAML output should NOT start with '{' (that would be JSON)
        assert not response.text.strip().startswith("{")

    def test_pydantic_validation_failure_returns_503(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Node payload failing CognitiveAgentNodeProfile validation → 503.

        Covers L306-313 (Pydantic validation error path).
        """
        # Missing 'description' which is required
        invalid_node_json = json.dumps(
            {
                "new_node": {
                    "node_cid": "did:coreason:invalid-node",
                    "topology_class": "INVALID_ENUM_VALUE_THAT_DOES_NOT_EXIST",
                }
            }
        )
        monkeypatch.setenv("CLOUD_ORACLE_API_KEY", "k")
        monkeypatch.setenv("CLOUD_ORACLE_BASE_URL", "http://localhost:1")
        monkeypatch.setenv("CLOUD_ORACLE_MODEL", "m")
        monkeypatch.setattr(
            "coreason_runtime.api.predict_router.CloudOracleClient.generate",
            _make_oracle_stub(raw_json=invalid_node_json),
        )

        response = _client.post(
            "/api/v1/predict/topology",
            json={"topology": VALID_JSON_TOPOLOGY, "user_prompt": "test"},
        )
        assert response.status_code == 503
        assert "hallucinated" in response.json()["detail"]

    def test_unwrapped_llm_output_handled(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """LLM returning node directly (without 'new_node' wrapper) still works.

        Covers L250 (result.get('new_node', result) fallback).
        """
        unwrapped_json = json.dumps(
            {
                "node_cid": "did:coreason:unwrapped-agent",
                "topology_class": "agent",
                "description": "Directly returned node without wrapper.",
            }
        )
        monkeypatch.setenv("CLOUD_ORACLE_API_KEY", "k")
        monkeypatch.setenv("CLOUD_ORACLE_BASE_URL", "http://localhost:1")
        monkeypatch.setenv("CLOUD_ORACLE_MODEL", "m")
        monkeypatch.setattr(
            "coreason_runtime.api.predict_router.CloudOracleClient.generate",
            _make_oracle_stub(raw_json=unwrapped_json),
        )

        response = _client.post(
            "/api/v1/predict/topology",
            json={"topology": VALID_JSON_TOPOLOGY, "user_prompt": "test"},
        )
        assert response.status_code == 200
        result = json.loads(response.text)
        assert "did:coreason:unwrapped-agent" in result["topology"]["nodes"]

    def test_hallucinated_strict_keys_stripped(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """LLM-hallucinated forbidden keys (peft_adapters, security, etc.) are stripped.

        Covers L268-294 (strict key stripping loop).
        """
        hallucinated_json = json.dumps(
            {
                "new_node": {
                    "node_cid": "did:coreason:clean-agent",
                    "topology_class": "agent",
                    "description": "Agent with hallucinated keys.",
                    "peft_adapters": [{"some": "adapter"}],
                    "security": {"level": "top_secret"},
                    "hardware": {"gpu": "A100"},
                    "type": "should_be_stripped",
                }
            }
        )
        monkeypatch.setenv("CLOUD_ORACLE_API_KEY", "k")
        monkeypatch.setenv("CLOUD_ORACLE_BASE_URL", "http://localhost:1")
        monkeypatch.setenv("CLOUD_ORACLE_MODEL", "m")
        monkeypatch.setattr(
            "coreason_runtime.api.predict_router.CloudOracleClient.generate",
            _make_oracle_stub(raw_json=hallucinated_json),
        )

        response = _client.post(
            "/api/v1/predict/topology",
            json={"topology": VALID_JSON_TOPOLOGY, "user_prompt": "test"},
        )
        assert response.status_code == 200
        result = json.loads(response.text)
        node = result["topology"]["nodes"]["did:coreason:clean-agent"]
        assert "peft_adapters" not in node
        assert "security" not in node
        assert "hardware" not in node
        assert "type" not in node
