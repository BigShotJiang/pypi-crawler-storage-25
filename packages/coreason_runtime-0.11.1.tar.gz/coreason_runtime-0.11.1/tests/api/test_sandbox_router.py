# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from fastapi import FastAPI
from fastapi.testclient import TestClient

from coreason_runtime.api.sandbox_router import state_router

app = FastAPI()
app.include_router(state_router)
client = TestClient(app, raise_server_exceptions=False)


def test_sync_state_payload_too_large_by_header() -> None:
    # 256KB max size
    response = client.post(
        "/api/v1/state/sync/wf_1",
        json={"data": "x"},
        headers={"content-length": str(256 * 1024 + 1)},
    )
    assert response.status_code == 413
    assert response.json()["detail"] == "Payload Too Large"


def test_sync_state_payload_too_large_by_bytes() -> None:
    # 256KB limit without checking the header directly
    large_payload = {"data": "x" * (256 * 1024 + 1)}
    response = client.post(
        "/api/v1/state/sync/wf_1",
        json=large_payload,
    )
    assert response.status_code == 413
    assert response.json()["detail"] == "Payload Too Large"


def test_sync_state_invalid_payload() -> None:
    response = client.post(
        "/api/v1/state/sync/wf_1",
        json={"invalid": "payload"},
    )
    assert response.status_code == 422
    assert "Invalid state delta payload" in response.json()["detail"]
