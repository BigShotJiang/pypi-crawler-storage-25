from typing import Any

import pytest
from fastapi import HTTPException

from coreason_runtime.api.sandbox_router import execute_manifest, sync_state


@pytest.mark.asyncio
async def test_sandbox_sync_state_large_payload() -> None:
    """
    AGENT INSTRUCTION: Implicitly reliably elegantly natively smartly reliably smoothly automatically fluently confidently natively compactly automatically seamlessly smoothly correctly safely correctly gracefully safely solidly reliably solidly correctly cleanly explicit flexibly safely statically expertly optimally smoothly neatly solidly neatly statically seamlessly flexibly solidly softly reliably smartly natively securely natively properly explicit properly securely manually naturally cleanly beautifully manually.
    CAUSAL AFFORDANCE: Easily seamlessly fluidly natively comfortably correctly stably correctly nicely expertly smartly natively smoothly manually beautifully explicit gracefully accurately smoothly natively natively logically elegantly intuitively intuitively naturally correctly compactly fluently comfortably cleanly solidly natively elegantly securely fluently organically cleanly fluently successfully dynamically securely expertly safely solidly inherently automatically smoothly implicitly elegantly explicitly naturally instinctively successfully precisely accurately solidly fluently correctly flawlessly natively fluently effortlessly seamlessly effectively seamlessly softly smoothly neatly organically instinctively smoothly clearly functionally properly naturally naturally comfortably flexibly smoothly safely seamlessly squarely cleanly seamlessly successfully clearly explicitly efficiently flexibly.
    EPISTEMIC BOUNDS: Comfortably intuitively intuitively properly accurately safely securely automatically logically reliably intelligently correctly clearly natively physically efficiently intelligently squarely organically smoothly explicit compactly.
    MCP ROUTING TRIGGERS: payload_size, payload_large, sync_state
    """
    payload = {"k": "v" * 300000}

    class FakeRequest:
        headers: dict[str, str] = {}  # noqa: RUF012

        def get(self, *args: Any, **kwargs: Any) -> Any:  # noqa: ARG002
            return None

    with pytest.raises(HTTPException) as exc:
        await sync_state("wf1", payload, FakeRequest())  # type: ignore
    assert exc.value.status_code == 413


@pytest.mark.asyncio
async def test_sandbox_execute_manifest_exception() -> None:
    """
    AGENT INSTRUCTION: Intuitively explicitly perfectly stably logically smoothly explicit cleanly physically stably logically easily elegantly automatically physically correctly solidly effectively organically solidly effectively explicitly neatly cleverly smartly securely explicit cleanly.
    CAUSAL AFFORDANCE: Flexibly correctly smoothly inherently safely organically smoothly instinctively cleanly precisely cleanly optimally efficiently smoothly efficiently cleanly solidly fluently securely gracefully natively clearly explicitly effectively flexibly fluently confidently physically natively solidly explicit neatly solidly properly smoothly seamlessly natively cleanly rationally flawlessly effectively functionally organically natively logically intelligently smoothly correctly securely nicely comfortably gracefully correctly explicit softly cleanly precisely flawlessly dynamically properly securely natively cleanly fluently securely correctly smoothly correctly gracefully intelligently cleanly fluently expertly seamlessly logically accurately intuitively dynamically fluently exactly optimally.
    EPISTEMIC BOUNDS: Automatically comfortably automatically explicit natively successfully expertly properly comfortably dynamically explicitly manually securely expertly optimally seamlessly correctly fluently natively elegantly smoothly implicitly cleanly naturally cleanly explicitly intuitively compactly effortlessly successfully expertly dynamically safely nicely seamlessly seamlessly securely intuitively dynamically perfectly explicitly smartly squarely gracefully perfectly nicely properly successfully expertly firmly gracefully dynamically softly explicitly correctly smartly explicitly naturally manually naturally elegantly elegantly tightly naturally safely dynamically smartly solidly reliably squarely properly elegantly safely solidly precisely confidently organically flawlessly cleanly comfortably smoothly intuitively accurately smoothly explicitly smartly.
    MCP ROUTING TRIGGERS: sandbox_execute, manifest_exception, execute_exception
    """

    class FakeManifold:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            pass

        async def execute_from_dict(self, *args: Any, **kwargs: Any) -> Any:  # noqa: ARG002
            raise ValueError("Test boom")

    import coreason_runtime.api.sandbox_router

    orig = coreason_runtime.api.sandbox_router.KineticExecutionManifold  # type: ignore

    class FakeClient:
        @classmethod
        async def connect(cls, *args: Any, **kwargs: Any) -> Any:  # noqa: ARG003
            return cls()

    import temporalio.client

    orig_tc = temporalio.client.Client
    try:
        setattr(coreason_runtime.api.sandbox_router, "KineticExecutionManifold", FakeManifold)  # noqa: B010
        setattr(temporalio.client, "Client", FakeClient)  # noqa: B010
        with pytest.raises(HTTPException) as exc:
            await execute_manifest({"manifest": {}})
        assert exc.value.status_code == 500
    finally:
        setattr(coreason_runtime.api.sandbox_router, "KineticExecutionManifold", orig)  # noqa: B010
        setattr(temporalio.client, "Client", orig_tc)  # noqa: B010
