# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import asyncio
import sys
from typing import Any
from unittest.mock import MagicMock

import pytest
from pydantic import Field

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())  # type: ignore[attr-defined]

# Optimize memory usage during testing and circumvent upstream HuggingFace 503 errors
# by preventing LanceDB from eager-loading a local SentenceTransformer.


class FakeModel:
    def ndims(self) -> int:
        return 384

    def VectorField(self) -> Any:
        return Field(default=None)

    def SourceField(self) -> Any:
        return Field(default=None)


try:
    import lancedb.embeddings  # type: ignore[import-untyped]

    mock_registry_func = MagicMock()
    mock_registry_func.return_value.get.return_value.create.return_value = FakeModel()
    lancedb.embeddings.get_registry = mock_registry_func
except ImportError:
    pass


# ── Physical Hardware Substrate Probe ─────────────────────────────────


def _probe_physical_gpu() -> bool:
    """Mechanically probes the PCIe bus for an active NVIDIA driver.

    Returns True only if pynvml is installed AND at least one GPU device
    is detected on the physical PCIe bus. This allows hardware-dependent
    tests to be quarantined in CI environments lacking GPU drivers.
    """
    try:
        import pynvml

        pynvml.nvmlInit()
        device_count = pynvml.nvmlDeviceGetCount()
        pynvml.nvmlShutdown()
        return int(device_count) > 0
    except Exception:
        return False


# Export the marker for use across the test suite
requires_physical_gpu = pytest.mark.skipif(
    not _probe_physical_gpu(),
    reason="TEST QUARANTINED: Requires a physical NVIDIA GPU and pynvml drivers.",
)
