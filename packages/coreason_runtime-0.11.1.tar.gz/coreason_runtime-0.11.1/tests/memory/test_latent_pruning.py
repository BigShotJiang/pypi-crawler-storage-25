# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import time
from unittest.mock import MagicMock

import polars as pl
import pytest

from coreason_runtime.memory.latent import LatentMemoryManager


@pytest.fixture
def mock_medallion_engine():  # type: ignore
    """Build structurally sound engine boundaries natively avoiding database limits securely."""

    class MockEngine:
        def __init__(self):  # type: ignore
            self.db = MagicMock()
            self.mock_table = MagicMock()
            self.db.open_table.return_value = self.mock_table

            self.deleted_conditions = []  # type: ignore

            def mock_delete(condition):  # type: ignore
                self.deleted_conditions.append(condition)

            self.mock_table.delete.side_effect = mock_delete

    return MockEngine()  # type: ignore


@pytest.mark.asyncio
async def test_epistemic_pruning_retains_active_memory(mock_medallion_engine) -> None:  # type: ignore
    """Prove that exactly robust active vectors safely survive decay algorithms gracefully."""
    manager = LatentMemoryManager(mock_medallion_engine)

    now = time.time()

    # Mathematical setup:
    # Vec 1: New (0 age), frequency 1 -> utility 1
    # Vec 2: Old (100 age), frequency 1 -> utility ~0.000045 (decay=0.1) -> Pruned
    # Vec 3: Old (10 age), frequency 50 -> utility 50 * exp(-1) = 18.39 -> Kept
    mock_df = pl.DataFrame(
        {
            "intent_hash": ["active_new", "stale_forget", "active_frequent"],
            "timestamp": [now, now - 100, now - 10],
            "access_frequency": [1, 1, 50],
        }
    )

    mock_medallion_engine.mock_table.to_polars.return_value = mock_df

    decay_rate = 0.1
    utility_threshold = 0.5

    pruned = await manager.prune_stale_vectors(decay_rate=decay_rate, threshold=utility_threshold, protected_cids=[])

    assert pruned == 1
    assert len(mock_medallion_engine.deleted_conditions) == 1
    assert "stale_forget" in mock_medallion_engine.deleted_conditions[0]
    assert "active_new" not in mock_medallion_engine.deleted_conditions[0]
    assert "active_frequent" not in mock_medallion_engine.deleted_conditions[0]


@pytest.mark.asyncio
async def test_epistemic_pruning_empty_database(mock_medallion_engine) -> None:  # type: ignore
    """Prove exact handling bounds correctly handle structurally unbounded null topologies."""
    manager = LatentMemoryManager(mock_medallion_engine)

    mock_df = pl.DataFrame({"intent_hash": [], "timestamp": [], "access_frequency": []})
    mock_medallion_engine.mock_table.to_polars.return_value = mock_df

    pruned = await manager.prune_stale_vectors(decay_rate=0.1, threshold=0.5, protected_cids=[])

    assert pruned == 0
    assert len(mock_medallion_engine.deleted_conditions) == 0


@pytest.mark.asyncio
async def test_latent_manager_bootstrap(mock_medallion_engine) -> None:  # type: ignore
    """Verify idempotent creation of LanceDB table boundaries explicitly."""
    manager = LatentMemoryManager(mock_medallion_engine)
    mock_medallion_engine.db.table_names.return_value = []

    # Mock to prevent infinite optimization loop side effects natively
    async def block_opt(*args: object, **kwargs: object) -> None:
        pass

    manager.optimize_and_compact = block_opt  # type: ignore
    await manager.bootstrap()

    mock_medallion_engine.db.create_table.assert_called_once()
    assert mock_medallion_engine.db.create_table.call_args[0][0] == "latent_space"


@pytest.mark.asyncio
async def test_latent_manager_optimize(mock_medallion_engine) -> None:  # type: ignore
    """Validates structural Arrow compaction executing correctly."""
    manager = LatentMemoryManager(mock_medallion_engine)
    await manager.optimize_and_compact()

    mock_medallion_engine.mock_table.optimize.assert_called_once()

    # Test Exception bounds
    mock_medallion_engine.mock_table.optimize.side_effect = Exception("Compaction Fault")
    # Will safely catch and log warning natively
    await manager.optimize_and_compact()


@pytest.mark.asyncio
async def test_latent_manager_upsert(mock_medallion_engine) -> None:  # type: ignore
    """Verify matrix operations mapping securely without DB failure natively."""
    manager = LatentMemoryManager(mock_medallion_engine)
    mock_intent = MagicMock()
    mock_intent.model_dump_json.return_value = "{}"

    await manager.upsert_projection("abc-123", mock_intent, [0.1] * 1536)
    mock_medallion_engine.mock_table.merge_insert.assert_called_once_with("intent_hash")


@pytest.mark.asyncio
async def test_prune_exception(mock_medallion_engine) -> None:  # type: ignore
    """Verify exception catches across dataframe processing bounds natively."""
    manager = LatentMemoryManager(mock_medallion_engine)
    mock_medallion_engine.mock_table.to_polars.side_effect = Exception("Dataframe failure bounds")

    val = await manager.prune_stale_vectors(decay_rate=0.1, threshold=0.5, protected_cids=[])
    assert val == 0


@pytest.mark.asyncio
async def test_prune_no_stale_vectors(mock_medallion_engine) -> None:  # type: ignore
    """Hit line 118 explicitly by returning vectors that all exceed the threshold safely."""
    manager = LatentMemoryManager(mock_medallion_engine)

    now = time.time()
    mock_df = pl.DataFrame(
        {
            "intent_hash": ["active_1", "active_2"],
            "timestamp": [now, now],
            "access_frequency": [100, 100],
        }
    )

    mock_medallion_engine.mock_table.to_polars.return_value = mock_df

    pruned = await manager.prune_stale_vectors(decay_rate=0.1, threshold=0.5, protected_cids=[])
    assert pruned == 0
