from unittest.mock import MagicMock, patch

import pyarrow as pa  # type: ignore[import-untyped]
import pytest

from coreason_runtime.memory.ledger import EpistemicLedgerManager


@pytest.fixture
def mock_medallion_engine():  # type: ignore
    class MockEngine:
        def __init__(self):  # type: ignore
            self.db = MagicMock()
            self.mock_table = MagicMock()
            self.db.open_table.return_value = self.mock_table
            self.db.table_names.return_value = [
                "gold_ledger",
                "silver_standardized",
                "bronze_entropy",
                "retracted_nodes",
                "active_cascades",
                "latent_space",
            ]
            import sys

            if "polars" not in sys.modules:
                pass  # keep reference
            # Allow mock responses for where().to_arrow().to_pylist()
            self.mock_table.search().where().to_arrow().to_pylist.return_value = [
                {"entity_uuid": "abc", "payload": "{}"}
            ]
            self.mock_table.search().to_arrow().to_pylist.return_value = []

    return MockEngine()  # type: ignore


@pytest.mark.asyncio
async def test_ledger_bootstrap(mock_medallion_engine) -> None:  # type: ignore
    manager = EpistemicLedgerManager(mock_medallion_engine)
    mock_medallion_engine.db.table_names.return_value = []
    await manager.bootstrap()
    assert mock_medallion_engine.db.create_table.call_count >= 5


@pytest.mark.asyncio
async def test_ledger_commit_bronze_entropy(mock_medallion_engine) -> None:  # type: ignore
    manager = EpistemicLedgerManager(mock_medallion_engine)
    await manager.commit_bronze_entropy("wf_1", "hash_1", {"key": "val"}, "error tracing")
    mock_medallion_engine.mock_table.merge_insert.assert_called_with("intent_hash")


@pytest.mark.asyncio
async def test_ledger_commit_silver_standardized_state(mock_medallion_engine) -> None:  # type: ignore
    manager = EpistemicLedgerManager(mock_medallion_engine)
    dummy_df = pa.Table.from_pylist([{"entity_uuid": "test"}])
    await manager.commit_silver_standardized_state("wf_1", dummy_df)
    mock_medallion_engine.db.table_names.return_value = []
    await manager.commit_silver_standardized_state("wf_1", dummy_df)


@pytest.mark.asyncio
async def test_ledger_promote_silver_to_gold(mock_medallion_engine) -> None:  # type: ignore
    manager = EpistemicLedgerManager(mock_medallion_engine)
    mock_medallion_engine.db.table_names.return_value = []
    await manager.promote_silver_to_gold("wf_1", "hash_abcd")
    mock_medallion_engine.db.table_names.return_value = ["silver_standardized", "gold_ledger"]
    mock_medallion_engine.mock_table.search().where().to_arrow().to_pylist.return_value = []
    await manager.promote_silver_to_gold("wf_1", "hash_empty")
    mock_medallion_engine.mock_table.search().where().to_arrow().to_pylist.return_value = [
        {"entity_uuid": "hash_abcd", "payload": '{"variational_free_energy": 2.0}'}
    ]

    class MockPolicy:
        min_observations_required = 2
        aleatoric_entropy_threshold = 1.0

    await manager.promote_silver_to_gold("wf_1", "hash_abcd", MockPolicy())

    class MockPolicyValid:
        min_observations_required = 1
        aleatoric_entropy_threshold = 1.0

    with pytest.raises(Exception, match="EpistemicYieldError: Variational Free"):
        await manager.promote_silver_to_gold("wf_1", "hash_abcd", MockPolicyValid())
    mock_medallion_engine.mock_table.search().where().to_arrow().to_pylist.return_value = [
        {"entity_uuid": "hash_abcd", "payload": '{"test": 1}'}
    ]
    await manager.promote_silver_to_gold("wf_1", "hash_abcd", MockPolicyValid())


@pytest.mark.asyncio
async def test_ledger_commit_gold_crystallization(mock_medallion_engine) -> None:  # type: ignore
    manager = EpistemicLedgerManager(mock_medallion_engine)

    class MockReceipt:
        def model_dump_json(self) -> str:
            return "{}"

    class MockPQC:
        pq_algorithm = "dilithium"
        pq_signature_blob = "fake_mock_signature"
        public_key_id = "pub"

    with pytest.raises(ValueError):
        await manager.commit_gold_crystallization("wf", "", None)

    with patch("coreason_runtime.utils.security.verify_pq_signature", return_value=True):
        await manager.commit_gold_crystallization("wf", "hash_int", MockReceipt(), MockPQC())

    class InvalidPQC:
        pq_algorithm = "bad"
        pq_signature_blob = "bad"
        public_key_id = "bad"

    with patch("coreason_runtime.utils.security.verify_pq_signature", return_value=False):
        with pytest.raises(Exception, match="TamperFaultEvent"):
            await manager.commit_gold_crystallization("wf", "hash_int", MockReceipt(), InvalidPQC())

    # Map the exception boundary securely natively ensuring it falls back logically
    with patch("coreason_runtime.utils.security.verify_pq_signature", side_effect=Exception("PQC Collapse")):
        with pytest.raises(Exception, match="TamperFaultEvent"):
            await manager.commit_gold_crystallization("wf", "hash_int", MockReceipt(), MockPQC())


@pytest.mark.asyncio
async def test_ledger_fetch_memoized_state(mock_medallion_engine) -> None:  # type: ignore
    manager = EpistemicLedgerManager(mock_medallion_engine)
    mock_medallion_engine.db.table_names.return_value = []
    assert await manager.fetch_memoized_state_io_activity([0.0]) is None

    mock_medallion_engine.db.table_names.return_value = ["latent_space", "gold_ledger"]

    class MockArrowResult:
        def to_pylist(self) -> list[dict[str, object]]:
            return [
                {
                    "intent_hash": "hash_123",
                    "_distance": 0.01,
                    "receipt_payload": '{"test": 1}',
                    "pq_signature_blob": "mock",
                }
            ]

        def __bool__(self) -> bool:
            return True

    class MockArrowResultFail:
        def __bool__(self) -> bool:
            return False

    mock_medallion_engine.mock_table.search().metric().limit().to_arrow.return_value = MockArrowResult()
    mock_medallion_engine.mock_table.search().where().to_arrow.return_value = MockArrowResult()

    with patch("coreason_runtime.utils.security.verify_pq_signature", return_value=True):
        val = await manager.fetch_memoized_state_io_activity([0.0] * 1536)
        assert getattr(val, "get", False)

    class MockArrowDistance:
        def to_pylist(self) -> list[dict[str, object]]:
            return [{"intent_hash": "hash_123", "_distance": 0.99}]

        def __bool__(self) -> bool:
            return True

    mock_medallion_engine.mock_table.search().metric().limit().to_arrow.return_value = MockArrowDistance()
    assert await manager.fetch_memoized_state_io_activity([0.0] * 1536) is None

    mock_medallion_engine.mock_table.search().metric().limit().to_arrow.return_value = MockArrowResultFail()
    assert await manager.fetch_memoized_state_io_activity([0.0] * 1536) is None

    mock_medallion_engine.mock_table.search().metric().limit().to_arrow.return_value = MockArrowResult()
    mock_medallion_engine.mock_table.search().where().to_arrow.return_value = MockArrowResultFail()
    assert await manager.fetch_memoized_state_io_activity([0.0] * 1536) is None

    # Test signature rejection explicitly natively
    mock_medallion_engine.mock_table.search().where().to_arrow.return_value = MockArrowResult()
    with patch("coreason_runtime.utils.security.verify_pq_signature", return_value=False):
        assert await manager.fetch_memoized_state_io_activity([0.0] * 1536) is None


@pytest.mark.asyncio
async def test_ledger_commit_cascade_event(mock_medallion_engine) -> None:  # type: ignore
    manager = EpistemicLedgerManager(mock_medallion_engine)

    class DummyEvent:
        cascade_cid = "123"

        def model_dump_json(self) -> str:
            return "{}"

    await manager.commit_cascade_event("wf", DummyEvent())


@pytest.mark.asyncio
async def test_ledger_retracted_empty(mock_medallion_engine) -> None:  # type: ignore
    manager = EpistemicLedgerManager(mock_medallion_engine)
    await manager.commit_retracted_nodes("wf_1", [])
    await manager.commit_retracted_nodes("wf_1", ["abc"])


@pytest.mark.asyncio
async def test_ledger_state_fetching(mock_medallion_engine) -> None:  # type: ignore
    manager = EpistemicLedgerManager(mock_medallion_engine)
    mock_medallion_engine.db.table_names.return_value = ["gold_ledger", "retracted_nodes", "active_cascades"]
    mock_medallion_engine.mock_table.search().where().to_arrow().to_pylist.return_value = []

    with patch("coreason_manifest.spec.ontology.EpistemicLedgerState.model_validate") as mock_val:
        await manager.fetch_epistemic_ledger_state("wf_1")
        mock_val.assert_called_once()


@pytest.mark.asyncio
async def test_ledger_apply_cascade(mock_medallion_engine) -> None:  # type: ignore
    manager = EpistemicLedgerManager(mock_medallion_engine)
    mock_medallion_engine.db.table_names.return_value = []
    await manager.apply_defeasible_cascade("root_1")
    mock_medallion_engine.db.table_names.return_value = ["gold_ledger"]
    mock_medallion_engine.mock_table.search().to_arrow().to_pylist.return_value = [
        {"intent_hash": "root_1", "receipt_payload": '{"parent_hashes": []}', "workflow_id": "wf_1"},
        {"intent_hash": "child_1", "receipt_payload": '{"parent_hashes": ["root_1"]}', "workflow_id": "wf_1"},
    ]
    await manager.apply_defeasible_cascade("root_1")
    mock_medallion_engine.mock_table.search().to_arrow().to_pylist.return_value = [
        {"intent_hash": "child_1", "receipt_payload": "invalid json", "workflow_id": "wf"}
    ]
    await manager.apply_defeasible_cascade("root_1")


@pytest.mark.asyncio
async def test_ledger_fetch_action_space_manifest(mock_medallion_engine) -> None:  # type: ignore
    manager = EpistemicLedgerManager(mock_medallion_engine)
    mock_medallion_engine.db.table_names.return_value = []
    assert await manager.fetch_action_space_manifest("action_1") is None

    mock_medallion_engine.db.table_names.return_value = ["action_spaces"]

    class MockArrowResult:
        def to_pylist(self) -> list[dict[str, object]]:
            return [{"payload": "{}"}]

        def __bool__(self) -> bool:
            return True

    mock_medallion_engine.mock_table.search().where().to_arrow.return_value = MockArrowResult()
    with patch("coreason_manifest.spec.ontology.CognitiveActionSpaceManifest.model_validate") as mock_val:
        mock_val.return_value = True
        assert await manager.fetch_action_space_manifest("action_1") is not None

    class MockArrowResultFail:
        def __bool__(self) -> bool:
            return False

    mock_medallion_engine.mock_table.search().where().to_arrow.return_value = MockArrowResultFail()
    assert await manager.fetch_action_space_manifest("action_1") is None


@pytest.mark.asyncio
async def test_ledger_execute_rollback_target_cid(mock_medallion_engine) -> None:  # type: ignore
    manager = EpistemicLedgerManager(mock_medallion_engine)

    class DummyIntent:
        invalidated_node_cids = ()
        target_event_cid = "abc_123"
        request_cid = "req_1"

    with patch("coreason_manifest.spec.ontology.DefeasibleCascadeEvent") as mock_event:
        mock_event.return_value.cascade_cid = "cascade_req_1"
        mock_event.return_value.model_dump_json.return_value = "{}"

        # Enable all structures to hit 425-469 actively
        mock_medallion_engine.db.table_names.return_value = ["retracted_nodes", "gold_ledger", "active_cascades"]
        await manager.execute_rollback("wf_1", DummyIntent())

    mock_medallion_engine.mock_table.merge_insert.assert_called_with("cascade_cid")
