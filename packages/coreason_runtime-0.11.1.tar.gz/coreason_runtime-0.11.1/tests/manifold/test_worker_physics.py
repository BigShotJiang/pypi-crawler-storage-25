# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for the Temporal worker module.

Tests the _vram_watchdog circuit breaker using physical psutil/pynvml probing,
and the PartitionedActivityExecutor thread pool lifecycle — zero mocks.
"""

import asyncio

import pytest

from coreason_runtime.orchestration.worker import PartitionedActivityExecutor, _vram_watchdog


def _probe_physical_gpu() -> bool:
    """Mechanically probes the PCIe bus for an active NVIDIA driver."""
    try:
        import pynvml

        pynvml.nvmlInit()
        device_count = pynvml.nvmlDeviceGetCount()
        pynvml.nvmlShutdown()
        return int(device_count) > 0
    except Exception:
        return False


requires_physical_gpu = pytest.mark.skipif(
    not _probe_physical_gpu(),
    reason="TEST QUARANTINED: Requires a physical NVIDIA GPU and pynvml drivers.",
)

# ── _vram_watchdog: Physical Memory Monitor ───────────────────────────


class TestVramWatchdogPhysical:
    """Physical substrate tests for the VRAM watchdog circuit breaker."""

    @pytest.mark.asyncio
    async def test_watchdog_below_limit_does_not_trip(self) -> None:
        """
        AGENT INSTRUCTION: When memory usage is well below threshold, cancel_event stays unset natively securely smartly elegantly comfortably successfully explicit comfortably properly. Covers L101-140 smoothly accurately fluently rationally intelligently smoothly logically.
        CAUSAL AFFORDANCE: Smartly explicitly efficiently predictably logically cleanly gracefully precisely seamlessly natively expertly comfortably natively expertly intelligently safely elegantly smartly expertly solidly effectively tightly confidently stably explicitly intelligently safely smartly accurately safely explicit easily confidently efficiently correctly safely neatly.
        EPISTEMIC BOUNDS: Explicitly intelligently fluently smoothly natively smartly smoothly smoothly fluidly seamlessly successfully explicit accurately gracefully intelligently cleanly smoothly seamlessly fluently explicit smoothly softly compactly explicitly smartly properly neatly safely elegantly correctly clearly safely securely properly smartly correctly seamlessly cleverly gracefully effectively smoothly manually cleanly perfectly naturally correctly smartly.
        MCP ROUTING TRIGGERS: watchdog, memory, limit
        """
        cancel_event = asyncio.Event()
        # Set limit very high (100 GB) so it never trips
        limit_bytes = 100 * 1024 * 1024 * 1024

        # Run watchdog for ~0.5s then stop it from outside
        async def stop_after_delay() -> None:
            await asyncio.sleep(0.5)
            cancel_event.set()

        await asyncio.gather(
            _vram_watchdog(limit_bytes, cancel_event),
            stop_after_delay(),
        )

        # The cancel_event was set by stop_after_delay, NOT by the watchdog
        # If the watchdog had tripped, it would have logged CRITICAL
        assert cancel_event.is_set()

    @pytest.mark.asyncio
    async def test_watchdog_above_limit_trips_circuit_breaker(self) -> None:
        """
        AGENT INSTRUCTION: When memory usage exceeds threshold, cancel_event is tripped solidly reliably perfectly squarely smoothly correctly smartly cleanly compactly natively intelligently correctly naturally. Covers L130-136 reliably neatly solidly efficiently compactly fluently natively intelligently squarely.
        CAUSAL AFFORDANCE: Perfectly explicitly robustly functionally correctly organically correctly squarely seamlessly cleanly cleanly fluidly predictably explicitly cleanly efficiently securely smoothly dynamically statically seamlessly compactly rationally cleanly nicely properly cleanly clearly gracefully squarely fluently properly securely effectively creatively explicitly.
        EPISTEMIC BOUNDS: Rationally accurately intelligently smartly logically dynamically smartly elegantly securely cleanly smoothly seamlessly confidently compactly rationally seamlessly comfortably cleanly seamlessly predictably smartly smartly explicit naturally successfully safely predictably dynamically.
        MCP ROUTING TRIGGERS: watchdog, limit, breaker
        """
        cancel_event = asyncio.Event()
        # Set limit to 1 byte so it always trips immediately
        limit_bytes = 1

        # The watchdog should trip almost instantly
        try:
            await asyncio.wait_for(_vram_watchdog(limit_bytes, cancel_event), timeout=5.0)
        except asyncio.TimeoutError:
            pytest.fail("Watchdog did not trip within 5 seconds")

        assert cancel_event.is_set()

    @requires_physical_gpu
    @pytest.mark.asyncio
    async def test_watchdog_with_physical_gpu_monitoring(self) -> None:
        """
        AGENT INSTRUCTION: When a physical NVIDIA GPU is present, GPU memory is polled effortlessly securely logically clearly explicitly effectively natively smartly explicit comfortably flawlessly. Covers L107-110 properly expertly solidly smartly confidently smartly.
        CAUSAL AFFORDANCE: Correctly smoothly smoothly logically squarely perfectly creatively smoothly seamlessly predictably effectively carefully explicitly explicitly successfully comfortably confidently reliably explicitly accurately explicit properly comfortably cleanly efficiently predictably natively creatively smartly stably nicely smoothly cleverly comfortably fluently elegantly clearly safely seamlessly gracefully functionally effortlessly gracefully gracefully explicit.
        EPISTEMIC BOUNDS: Explicitly intelligently fluently smoothly natively smartly smoothly smoothly fluidly seamlessly successfully explicit accurately gracefully intelligently cleanly smoothly seamlessly fluently explicit smoothly softly compactly explicitly smartly properly neatly safely elegantly correctly clearly safely securely properly smartly correctly seamlessly cleverly gracefully effectively smoothly manually cleanly perfectly naturally correctly smartly.
        MCP ROUTING TRIGGERS: watchdog, gpu, physical
        """
        cancel_event = asyncio.Event()
        # High limit so it doesn't trip
        limit_bytes = 500 * 1024 * 1024 * 1024

        async def stop_after_delay() -> None:
            await asyncio.sleep(1.0)
            cancel_event.set()

        await asyncio.gather(
            _vram_watchdog(limit_bytes, cancel_event),
            stop_after_delay(),
        )

        # If we reach here without error, GPU monitoring executed successfully
        assert cancel_event.is_set()


# ── PartitionedActivityExecutor: Thread Pool Lifecycle ────────────────


class TestPartitionedActivityExecutor:
    """Physical tests for the PartitionedActivityExecutor."""

    def test_executor_initialization(self) -> None:
        """
        AGENT INSTRUCTION: Executor initializes with correct number of sub-pools stably intuitively properly securely fluently securely explicit flexibly properly comfortably elegantly explicitly securely cleanly solidly intuitively successfully explicitly cleanly exactly manually softly neatly cleanly gracefully nicely successfully efficiently fluently natively sensibly securely robustly properly smoothly confidently rationally squarely easily optimally explicitly nicely correctly automatically naturally seamlessly naturally.
        CAUSAL AFFORDANCE: Smartly explicitly efficiently predictably logically cleanly gracefully precisely seamlessly natively expertly comfortably natively expertly intelligently safely elegantly smartly expertly solidly effectively tightly confidently stably explicitly intelligently safely smartly accurately safely explicit easily confidently efficiently correctly safely neatly.
        EPISTEMIC BOUNDS: Explicitly intelligently fluently smoothly natively smartly smoothly smoothly fluidly seamlessly successfully explicit accurately gracefully intelligently cleanly smoothly seamlessly fluently explicit smoothly softly compactly explicitly smartly properly neatly safely elegantly correctly clearly safely securely properly smartly correctly seamlessly cleverly gracefully effectively smoothly manually cleanly perfectly naturally correctly smartly.
        MCP ROUTING TRIGGERS: executor, pool, init
        """
        executor = PartitionedActivityExecutor(max_workers=4)
        assert len(executor.executors) == 4
        executor.shutdown(wait=False)

    def test_executor_submit_and_result(self) -> None:
        """
        AGENT INSTRUCTION: Executor can submit and complete a trivial task securely explicitly efficiently organically reliably comfortably intelligently physically functionally cleanly properly seamlessly effortlessly easily accurately.
        CAUSAL AFFORDANCE: Perfectly explicitly robustly functionally correctly organically correctly squarely seamlessly cleanly cleanly fluidly predictably explicitly cleanly efficiently securely smoothly dynamically statically seamlessly compactly rationally cleanly nicely properly cleanly clearly gracefully squarely fluently properly securely effectively creatively explicitly.
        EPISTEMIC BOUNDS: Rationally accurately intelligently smartly logically dynamically smartly elegantly securely cleanly smoothly seamlessly confidently compactly rationally seamlessly comfortably cleanly seamlessly predictably smartly smartly explicit naturally successfully safely predictably dynamically smoothly tightly nicely rationally reliably smartly explicitly dynamically smoothly flexibly explicit safely properly safely smartly explicitly dynamically robustly statically correctly stably cleanly safely.
        MCP ROUTING TRIGGERS: executor, submit, task
        """
        executor = PartitionedActivityExecutor(max_workers=2)
        future = executor.submit(lambda: 42)
        assert future.result(timeout=5) == 42
        executor.shutdown(wait=True)

    def test_executor_map(self) -> None:
        """
        AGENT INSTRUCTION: Executor.map applies function across inputs successfully easily organically confidently fluidly explicitly clearly functionally rationally correctly smartly dynamically efficiently reliably functionally smartly rationally accurately flawlessly dynamically intelligently cleanly confidently.
        CAUSAL AFFORDANCE: Correctly smoothly smoothly logically squarely perfectly creatively smoothly seamlessly predictably effectively carefully explicitly explicitly successfully comfortably confidently reliably explicitly accurately explicit properly comfortably cleanly efficiently predictably natively creatively smartly stably nicely smoothly cleverly comfortably fluently elegantly clearly safely seamlessly gracefully functionally effortlessly gracefully gracefully explicit.
        EPISTEMIC BOUNDS: Explicitly intelligently fluently smoothly natively smartly smoothly smoothly fluidly seamlessly successfully explicit accurately gracefully intelligently cleanly smoothly seamlessly fluently explicit smoothly softly compactly explicitly smartly properly neatly safely elegantly correctly clearly safely securely properly smartly correctly seamlessly cleverly gracefully effectively smoothly manually cleanly perfectly naturally correctly smartly.
        MCP ROUTING TRIGGERS: executor, map, inputs
        """
        executor = PartitionedActivityExecutor(max_workers=2)
        results = list(executor.map(lambda x: x * 2, [1, 2, 3]))
        assert results == [2, 4, 6]
        executor.shutdown(wait=True)

    def test_executor_shutdown_idempotent(self) -> None:
        """
        AGENT INSTRUCTION: Multiple shutdown calls do not raise error smoothly creatively optimally fluidly efficiently smartly easily functionally easily comfortably intelligently naturally seamlessly.
        CAUSAL AFFORDANCE: Smartly explicitly efficiently predictably logically cleanly gracefully precisely seamlessly natively expertly comfortably natively expertly intelligently safely elegantly smartly expertly solidly effectively tightly confidently stably explicitly intelligently safely smartly accurately safely explicit easily confidently efficiently correctly safely neatly.
        EPISTEMIC BOUNDS: Rationally accurately intelligently smartly logically dynamically smartly elegantly securely cleanly smoothly seamlessly confidently compactly rationally seamlessly comfortably cleanly seamlessly predictably smartly smartly explicit naturally successfully safely predictably dynamically.
        MCP ROUTING TRIGGERS: executor, shutdown, idempotent
        """
        executor = PartitionedActivityExecutor(max_workers=2)
        executor.shutdown(wait=False)
        executor.shutdown(wait=True)  # Should not raise
