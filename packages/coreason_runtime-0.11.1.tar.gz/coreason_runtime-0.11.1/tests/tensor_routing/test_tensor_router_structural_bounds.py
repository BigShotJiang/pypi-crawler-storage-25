import os
from typing import Any
from unittest.mock import MagicMock

import pytest
from coreason_manifest.spec.ontology import (
    CognitiveAgentNodeProfile,
    EscalationContract,
    System1ReflexPolicy,
)
from pydantic import BaseModel

from coreason_runtime.tensor_routing.router.budget_exceeded_error import BudgetExceededError
from coreason_runtime.tensor_routing.router.epistemic_yield_error import EpistemicYieldError
from coreason_runtime.tensor_routing.router.tensor_router import TensorRouter


class DummySchema(BaseModel):
    name: str


@pytest.fixture
def mock_router() -> TensorRouter:
    return TensorRouter("http://localhost:1111")


def test_deduct_budget_coverage(mock_router: TensorRouter) -> None:
    # Trigger line 51-59, 62-64 by destroying cache
    mock_router._pricing_cache = None  # type: ignore

    os.environ["CLOUD_ORACLE_MODEL"] = "fake-model"
    # Ensure resources/pricing.json does not crash it
    mock_router._deduct_budget("wf-1", {"total_tokens": 10}, 1000)

    # Try budget exceeded
    mock_router.budgets["wf-2"] = 995
    with pytest.raises(BudgetExceededError):
        mock_router._deduct_budget("wf-2", {"total_tokens": 10}, 1000)


def test_calculate_latent_smoothing(mock_router: TensorRouter) -> None:
    # "linear", "exponential", "cosine_annealing"
    assert mock_router._calculate_latent_smoothing(5.0, 10.0, 0.1, "linear") == 0.5
    assert mock_router._calculate_latent_smoothing(5.0, 10.0, 0.1, "exponential") > 0
    assert mock_router._calculate_latent_smoothing(5.0, 10.0, 0.1, "cosine_annealing") == 0.5


@pytest.mark.asyncio
async def test_route_inference_direct_oracle(monkeypatch: pytest.MonkeyPatch, mock_router: TensorRouter) -> None:
    # No Tier 0 -> triggers lines 397-429
    profile = CognitiveAgentNodeProfile(description="Analyst")

    # Monkeypatch UniversalCompiler to just return dummy
    async def mock_retry(*args: Any, **kwargs: Any) -> Any:
        return DummySchema(name="done"), {"total_tokens": 10}

    from coreason_runtime.tensor_routing.compiler import UniversalCompiler

    monkeypatch.setattr(UniversalCompiler, "validate_and_retry", mock_retry)

    res, _usage, _cost, _tokens, _blob = await mock_router.route_inference("wf", "prompt", DummySchema, profile)
    assert res.name == "done"


@pytest.mark.asyncio
async def test_route_inference_tier0_success(monkeypatch: pytest.MonkeyPatch, mock_router: TensorRouter) -> None:
    # Requires reflex policy for Tier 0 -> triggers lines 338-359
    profile = CognitiveAgentNodeProfile(
        description="Analyst", reflex_policy=System1ReflexPolicy(confidence_threshold=0.9, allowed_passive_tools=[])
    )

    async def mock_retry(*args: Any, **kwargs: Any) -> Any:
        return DummySchema(name="done"), {"total_tokens": 10}

    from coreason_runtime.tensor_routing.compiler import UniversalCompiler

    monkeypatch.setattr(UniversalCompiler, "validate_and_retry", mock_retry)

    res, _usage, _cost, _tokens, _blob = await mock_router.route_inference("wf", "prompt", DummySchema, profile)
    assert res.name == "done"


@pytest.mark.asyncio
async def test_route_inference_tier0_fallback_to_tier2(
    monkeypatch: pytest.MonkeyPatch, mock_router: TensorRouter
) -> None:
    # Throws exception in Tier 0, uses Escalation to fallback Tier 2 -> 372-385
    profile = CognitiveAgentNodeProfile(
        description="Analyst",
        reflex_policy=System1ReflexPolicy(confidence_threshold=0.9, allowed_passive_tools=[]),
        escalation_policy=EscalationContract(
            uncertainty_escalation_threshold=0.8, max_latent_tokens_budget=5000, max_test_time_compute_ms=1000
        ),
    )
    call_count = 0

    async def mock_retry(*args: Any, **kwargs: Any) -> Any:
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            raise Exception("Tier 0 failed")
        return DummySchema(name="done"), {"total_tokens": 10}

    from coreason_runtime.tensor_routing.compiler import UniversalCompiler

    monkeypatch.setattr(UniversalCompiler, "validate_and_retry", mock_retry)

    res, _usage, _cost, _tokens, _blob = await mock_router.route_inference("wf", "prompt", DummySchema, profile)
    assert res.name == "done"


@pytest.mark.asyncio
async def test_route_inference_full_policies(monkeypatch: pytest.MonkeyPatch, mock_router: TensorRouter) -> None:
    profile = MagicMock()
    profile.compute_frontier = MagicMock(max_cost_magnitude_per_token=100.0)
    profile.baseline_cognitive_state = MagicMock()
    profile.baseline_cognitive_state.model_dump.return_value = {"state": True}
    profile.logit_steganography = MagicMock()
    profile.logit_steganography.model_dump.return_value = {"steg": True}

    adapter = MagicMock()
    adapter.model_dump.return_value = {
        "vram_footprint_bytes": 1000,
        "adapter_cid": "lora-1",
        "lora_rank": 8,
        "target_modules": ["q_proj"],
    }
    profile.peft_adapters = [adapter]

    profile.prm_policy = True
    profile.analogical_policy = True
    profile.symbolic_handoff_policy = MagicMock()
    profile.audit_policy = True
    profile.anchoring_policy = True

    profile.correction_policy = MagicMock()
    profile.correction_policy.model_dump.return_value = {"correct": True}

    profile.grpo_reward_policy = MagicMock()
    profile.grpo_reward_policy.model_dump.return_value = {"grpo": True}
    profile.grpo_reward_policy.format_contract = MagicMock()
    profile.grpo_reward_policy.format_contract.decoding_policy = MagicMock()
    profile.grpo_reward_policy.format_contract.decoding_policy.model_dump.return_value = {"constrained": True}

    profile.activation_steering = MagicMock()
    profile.activation_steering.sae_dictionary_hash = "dict-1"

    profile.latent_firewalls = MagicMock()
    profile.latent_firewalls.model_dump.return_value = {"policies": []}

    profile.mechanistic_audit = MagicMock()
    profile.mechanistic_audit.model_dump.return_value = {"audit": True}

    profile.reflex_policy = None
    profile.escalation_policy = None

    # Mock httpx for LoRA
    class FakeResponse:
        def raise_for_status(self) -> None:
            pass

        text = '{"name": "math_solver_result"}'

    class FakeAsyncClient:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            pass

        async def __aenter__(self) -> Any:
            return self

        async def __aexit__(self, *args: Any, **kwargs: Any) -> None:
            pass

        async def post(self, url: str, json: dict[str, Any]) -> Any:  # noqa: ARG002
            return FakeResponse()

    import httpx

    monkeypatch.setattr(httpx, "AsyncClient", FakeAsyncClient)

    # Since symbolic_handoff returns directly logic, we don't need mock_retry!
    res, _usage, _cost, _tokens, _blob = await mock_router.route_inference("wf", "prompt", DummySchema, profile)
    assert res.name == "math_solver_result"

    # Run second time without symbolic bypass AND without hardware steering
    profile.symbolic_handoff_policy = None
    profile.activation_steering = None

    async def mock_retry2(*args: Any, **kwargs: Any) -> Any:
        return DummySchema(name="manual"), {"total_tokens": 10}

    from coreason_runtime.tensor_routing.compiler import UniversalCompiler

    monkeypatch.setattr(UniversalCompiler, "validate_and_retry", mock_retry2)

    res2, _usage2, _cost2, _tokens2, _blob2 = await mock_router.route_inference("wf2", "prompt", DummySchema, profile)
    assert res2.name == "manual"


@pytest.mark.asyncio
async def test_mechanistic_firewalls(monkeypatch: pytest.MonkeyPatch, mock_router: TensorRouter) -> None:
    # Trigger 132-137
    CognitiveAgentNodeProfile(description="Analyst")

    class FakeFirewall(BaseModel):
        policies: list[Any]

    class FakeRule(BaseModel):
        target_layer: int = 1
        target_feature_index: int = 100
        max_activation_threshold: float = 0.5
        violation_action: str = "halt"

    firewall = FakeFirewall(policies=[FakeRule()])

    layer_activations = {"layer_1": [{"feature_index": 100, "magnitude": 0.9}]}

    with pytest.raises(EpistemicYieldError, match="mechanistic_firewall_trip"):
        mock_router._evaluate_mechanistic_firewalls(layer_activations, firewall)


@pytest.mark.asyncio
async def test_route_inference_entropy_escalation(monkeypatch: pytest.MonkeyPatch, mock_router: TensorRouter) -> None:
    # Throws EntropyEscalationError -> 360-365
    from coreason_runtime.tensor_routing.compiler import EntropyEscalationError

    profile = CognitiveAgentNodeProfile(
        description="Analyst", reflex_policy=System1ReflexPolicy(confidence_threshold=0.9, allowed_passive_tools=[])
    )

    async def mock_retry(*args: Any, **kwargs: Any) -> Any:
        raise EntropyEscalationError("high entropy")

    from coreason_runtime.tensor_routing.compiler import UniversalCompiler

    monkeypatch.setattr(UniversalCompiler, "validate_and_retry", mock_retry)

    with pytest.raises(EpistemicYieldError, match="Manual Oracle required"):
        await mock_router.route_inference("wf", "prompt", DummySchema, profile)


@pytest.mark.asyncio
async def test_synthesize_hybrid_workflow(monkeypatch: pytest.MonkeyPatch, mock_router: TensorRouter) -> None:
    async def mock_synth(*args: Any, **kwargs: Any) -> Any:
        return DummySchema(name="hybrid"), {"total_tokens": 2}

    from coreason_runtime.tensor_routing.compiler import UniversalCompiler

    monkeypatch.setattr(UniversalCompiler, "synthesize_manifest", mock_synth)

    res, _usage = await mock_router.synthesize_hybrid_workflow("test")
    assert res.name == "hybrid"
