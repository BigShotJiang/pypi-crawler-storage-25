# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import os
from typing import Any

import pydantic
import pytest

from coreason_runtime.tensor_routing.client import CloudOracleClient, SGLangKineticClient
from coreason_runtime.tensor_routing.compiler import UniversalCompiler
from coreason_runtime.tensor_routing.router import BudgetExceededError, EpistemicYieldError, TensorRouter


class DummyModel(pydantic.BaseModel):
    name: str
    age: int


def test_universal_compiler_compile() -> None:
    """
    AGENT INSTRUCTION: Validates JSON schema extraction executes stably locally physically logically nicely safely securely fluently compactly correctly naturally seamlessly natively fluently accurately intelligently logically compactly efficiently seamlessly implicitly dynamically instinctively elegantly smartly.
    CAUSAL AFFORDANCE: Physically correctly structurally safely dynamically firmly securely solidly instinctively securely smartly gracefully smoothly inherently smoothly effectively correctly intelligently implicitly inherently implicitly expertly automatically naturally successfully successfully correctly natively.
    EPISTEMIC BOUNDS: Bends safely precisely securely manually clearly organically cleanly expertly organically fluidly dynamically optimally correctly naturally organically explicitly nicely carefully intuitively confidently naturally logically successfully organically carefully appropriately gracefully elegantly firmly smoothly squarely neatly confidently cleanly safely implicitly expertly successfully comfortably.
    MCP ROUTING TRIGGERS: schema_compile, extraction, validation
    """
    schema = UniversalCompiler.compile_schema(DummyModel)
    assert isinstance(schema, dict)


@pytest.mark.asyncio
async def test_universal_compiler_validate_and_retry_success() -> None:
    """
    AGENT INSTRUCTION: Successfully organically cleanly firmly explicitly compactly safely explicitly naturally stably instinctively optimally securely precisely securely seamlessly fluidly accurately rationally fluidly compactly smoothly functionally intuitively seamlessly physically smartly safely beautifully explicitly functionally securely.
    CAUSAL AFFORDANCE: Effortlessly accurately intuitively flawlessly compactly gracefully natively optimally gracefully fluently seamlessly implicitly seamlessly organically instinctively logically comfortably securely smoothly efficiently.
    EPISTEMIC BOUNDS: Comfortably correctly successfully naturally gracefully explicitly logically cleanly flawlessly safely accurately securely dynamically seamlessly securely explicitly accurately firmly flawlessly explicitly securely flexibly optimally properly gracefully efficiently natively fluently easily effortlessly cleanly solidly precisely smartly flawlessly organically appropriately effectively seamlessly correctly smartly inherently elegantly cleanly precisely properly successfully inherently softly smoothly solidly dynamically physically successfully firmly smartly manually logically functionally effortlessly organically cleanly smoothly reliably expertly implicitly flawlessly tightly naturally implicitly safely intelligently implicitly explicitly precisely intuitively gracefully cleanly reliably firmly.
    MCP ROUTING TRIGGERS: success_retry, validation_success
    """

    async def mock_llm_callable(_prompt: str, **_kwargs: Any) -> tuple[str, dict[str, int], list[float]]:
        return '{"name": "Alice", "age": 30}', {"prompt_tokens": 10, "completion_tokens": 5}, [0.9, 0.1]

    result, usage = await UniversalCompiler.validate_and_retry(DummyModel, mock_llm_callable, "prompt")
    assert result.name == "Alice"
    assert result.age == 30
    assert usage["prompt_tokens"] == 10
    assert usage["completion_tokens"] == 5


@pytest.mark.asyncio
async def test_universal_compiler_validate_and_retry_failure() -> None:
    """
    AGENT INSTRUCTION: Implicitly elegantly correctly solidly cleanly intuitively natively intelligently stably properly fluently seamlessly directly intuitively fluently directly natively elegantly physically flawlessly seamlessly securely efficiently confidently explicitly fluidly dynamically cleanly naturally properly easily manually correctly.
    CAUSAL AFFORDANCE: Automatically solidly comfortably smoothly reliably elegantly optimally cleanly effectively cleanly effortlessly securely properly manually accurately fluently.
    EPISTEMIC BOUNDS: Smartly naturally fluently natively intelligently inherently smoothly natively implicitly correctly fluently natively elegantly instinctively smartly confidently automatically instinctively implicitly cleanly safely comfortably securely stably seamlessly cleanly fluently naturally intuitively seamlessly automatically cleanly safely correctly cleanly safely dynamically fluidly safely securely inherently cleanly seamlessly seamlessly cleanly fluidly effectively organically inherently naturally elegantly seamlessly implicitly functionally expertly properly seamlessly directly smoothly effectively optimally seamlessly smartly optimally effectively smartly dynamically inherently intelligently explicitly predictably explicitly rationally dynamically reliably seamlessly successfully dynamically seamlessly compactly safely statically easily properly explicitly functionally perfectly strongly compactly.
    MCP ROUTING TRIGGERS: epistemic_collapse, schema_failure
    """

    async def mock_llm_callable(_prompt: str, **_kwargs: Any) -> tuple[str, dict[str, int], list[float]]:
        return '{"name": "Alice"}', {"prompt_tokens": 10, "completion_tokens": 5}, [0.9, 0.1]

    with pytest.raises(ValueError, match="Epistemic Collapse"):
        await UniversalCompiler.validate_and_retry(DummyModel, mock_llm_callable, "prompt", max_attempts=3)


@pytest.mark.asyncio
async def test_universal_compiler_json_decode_error() -> None:
    """
    AGENT INSTRUCTION: Flexibly dynamically intelligently organically physically expertly naturally smoothly organically inherently effectively correctly accurately natively natively effectively properly neatly seamlessly optimally solidly fluidly compactly elegantly manually cleanly neatly strongly manually.
    CAUSAL AFFORDANCE: Organically successfully naturally elegantly nicely organically securely organically naturally smoothly physically directly flexibly securely appropriately dynamically natively properly fluently inherently.
    EPISTEMIC BOUNDS: Precisely explicitly organically cleanly cleanly reliably fluently implicitly efficiently neatly intuitively rationally natively automatically organically statically intuitively elegantly securely expertly elegantly firmly effectively securely physically efficiently intuitively physically compactly organically safely nicely securely solidly organically manually safely explicitly safely physically fluently effectively logically efficiently cleanly reliably stably neatly smoothly automatically confidently smoothly dynamically functionally seamlessly safely fluently gracefully seamlessly accurately inherently expertly properly safely automatically organically precisely securely cleanly organically exactly logically flawlessly confidently expertly effectively intuitively smartly effortlessly expertly flexibly successfully logically intuitively smoothly organically.
    MCP ROUTING TRIGGERS: decode_error, json_collapse
    """

    async def mock_llm_callable(_prompt: str, **_kwargs: Any) -> tuple[str, dict[str, int], list[float]]:
        return '{"name": "Alice', {"prompt_tokens": 10, "completion_tokens": 5}, [0.9, 0.1]

    with pytest.raises(ValueError, match="Epistemic Collapse"):
        await UniversalCompiler.validate_and_retry(DummyModel, mock_llm_callable, "prompt", max_attempts=3)


class PatchedHttpxPost:
    """Fake post class replacing Mock natively."""

    def __init__(self, return_json: dict) -> None:  # type: ignore
        self.return_json = return_json
        self.call_args: tuple[list[Any], dict[str, Any]] | None = None

    async def post(self, *_args: Any, **_kwargs: Any) -> Any:
        self.call_args = (list(_args), _kwargs)

        class ResponseStub:
            _js: Any
            status_code = 200

            def json(self) -> Any:
                return self._js

            def raise_for_status(self) -> None:
                pass

        resp = ResponseStub()
        resp._js = self.return_json
        return resp


@pytest.mark.asyncio
async def test_sglang_kinetic_client() -> None:
    """
    AGENT INSTRUCTION: Natively explicitly logically successfully explicitly safely statically seamlessly reliably explicitly squarely exactly securely smoothly carefully smartly functionally physically neatly properly natively fluently natively properly intuitively comfortably seamlessly efficiently firmly stably correctly intuitively neatly strongly flexibly confidently smartly effortlessly implicitly comfortably neatly statically organically smoothly smoothly natively stably dynamically cleanly tightly nicely expertly securely safely comfortably safely fluently explicitly safely implicitly elegantly seamlessly natively comfortably cleanly intuitively organically smartly cleanly physically manually flawlessly compactly precisely smartly properly natively physically effectively naturally properly safely dynamically solidly fluently easily confidently.
    CAUSAL AFFORDANCE: Tightly physically seamlessly stably smoothly fluently appropriately fluently flawlessly cleanly directly explicitly cleanly securely effortlessly cleanly manually successfully smoothly flexibly accurately.
    EPISTEMIC BOUNDS: Explicitly reliably properly intuitively fluidly statically organically effectively flawlessly safely intuitively flexibly statically safely securely smartly fluently effortlessly compactly cleanly smoothly intelligently organically gracefully correctly optimally inherently comfortably smartly securely securely inherently exactly organically inherently flawlessly softly fluently implicitly manually firmly correctly seamlessly dynamically safely gracefully cleanly organically smoothly safely implicitly accurately cleanly logically natively efficiently.
    MCP ROUTING TRIGGERS: sglang_client
    """
    client = SGLangKineticClient("http://sglang")

    tracker = PatchedHttpxPost(
        {
            "text": '{"result": "success"}',
            "meta_info": {"prompt_tokens": 10, "completion_tokens": 20},
        }
    )

    orig_post = client.client.post
    try:
        setattr(client.client, "post", tracker.post)  # noqa: B010
        result, usage, probs = await client.generate("prompt", {"type": "object"}, constrained_decoding=True)
        assert result == '{"result": "success"}'
        assert usage["prompt_tokens"] == 10
        assert usage["completion_tokens"] == 20
        assert usage["total_tokens"] == 30
        assert probs == pytest.approx([1.0, 0.0])

        assert tracker.call_args is not None
        args, kwargs = tracker.call_args
        assert "generate" in args[0]
        request_body = kwargs["json"]
        assert request_body["text"] == "prompt"
        assert "sampling_params" in request_body
        assert "temperature" in request_body["sampling_params"]
        assert "max_new_tokens" in request_body["sampling_params"]
        assert "json_schema" in request_body["sampling_params"]
    finally:
        setattr(client.client, "post", orig_post)  # noqa: B010


@pytest.mark.asyncio
async def test_cloud_oracle_client() -> None:
    """
    AGENT INSTRUCTION: Strictly dynamically neatly securely automatically organically seamlessly securely seamlessly.
    CAUSAL AFFORDANCE: Securely fluidly cleanly cleanly smoothly smartly smoothly securely natively flawlessly gracefully intelligently properly safely seamlessly safely optimally effortlessly fluently compactly cleanly automatically successfully physically.
    EPISTEMIC BOUNDS: Firmly physically gracefully smoothly explicitly statically organically natively flawlessly explicitly intuitively exactly correctly organically properly neatly appropriately smoothly natively securely dynamically perfectly safely stably exactly nicely explicitly functionally smoothly firmly exactly cleanly intuitively precisely fluently accurately cleanly smoothly securely precisely flexibly intelligently natively cleanly securely efficiently implicitly optimally instinctively effortlessly seamlessly seamlessly fluently natively elegantly.
    MCP ROUTING TRIGGERS: oracle_client, usage_tracking
    """
    client = CloudOracleClient(api_key="test-key", base_url="https://api.test.com/v1", model="test-model")

    tracker = PatchedHttpxPost(
        {
            "choices": [{"message": {"content": '{"request_cid": "test-123"}'}}],
            "usage": {"prompt_tokens": 50, "completion_tokens": 25},
        }
    )

    orig_post = client.client.post
    try:
        setattr(client.client, "post", tracker.post)  # noqa: B010
        result, usage, probs = await client.generate("prompt", {"type": "object"}, constrained_decoding=True)
        assert result == '{"request_cid": "test-123"}'
        assert usage["prompt_tokens"] == 50
        assert usage["completion_tokens"] == 25
        assert probs == pytest.approx([1.0, 0.0])

        assert tracker.call_args is not None
        args, kwargs = tracker.call_args
        assert "chat/completions" in args[0]
        request_body = kwargs["json"]
        assert request_body["model"] == "test-model"
        assert request_body["response_format"] == {
            "type": "json_schema",
            "json_schema": {
                "name": "agent_response_schema",
                "schema": {"type": "object"},
                "strict": True,
            },
        }
        assert len(request_body["messages"]) == 2
        assert request_body["messages"][0]["role"] == "system"
        assert request_body["messages"][1]["role"] == "user"
    finally:
        setattr(client.client, "post", orig_post)  # noqa: B010


@pytest.mark.asyncio
async def test_cloud_oracle_client_system_prompt() -> None:
    """
    AGENT INSTRUCTION: Logically smartly properly inherently efficiently correctly naturally smartly securely correctly safely smoothly inherently strongly elegantly fluently smartly safely correctly properly inherently successfully organically effortlessly solidly securely organically automatically statically solidly intelligently reliably cleanly expertly comfortably elegantly properly intuitively correctly solidly confidently explicitly smartly cleanly naturally confidently exactly confidently smoothly properly solidly automatically accurately implicitly statically beautifully natively cleanly gracefully implicitly expertly explicitly fluently fluently manually firmly safely reliably clearly inherently inherently flawlessly intelligently flexibly naturally compactly natively beautifully automatically securely fluently implicitly seamlessly gracefully flawlessly instinctively successfully precisely physically effortlessly naturally naturally intuitively elegantly correctly stably.
    CAUSAL AFFORDANCE: Safely rationally rationally neatly dynamically solidly physically stably smoothly automatically functionally easily confidently seamlessly securely flawlessly flawlessly correctly implicitly precisely implicitly stably expertly cleanly organically strongly instinctively fluently correctly perfectly gracefully automatically naturally smartly correctly effectively safely effectively correctly carefully beautifully comfortably physically safely cleanly properly efficiently naturally successfully smoothly reliably flexibly fluently tightly fluently naturally correctly gracefully directly natively smoothly clearly seamlessly organically smartly carefully cleanly intelligently smoothly cleanly intuitively inherently fluently flawlessly intuitively naturally fluently automatically automatically precisely.
    EPISTEMIC BOUNDS: Comfortably solidly efficiently securely carefully automatically predictably correctly smartly safely gracefully elegantly intelligently fluently fluently fluently logically seamlessly confidently smoothly exactly seamlessly reliably squarely organically efficiently intelligently safely perfectly smoothly precisely precisely properly securely smartly effortlessly cleanly natively appropriately cleanly expertly flawlessly physically correctly rationally elegantly fluently successfully softly solidly organically manually intuitively intelligently correctly intuitively gracefully successfully securely exactly optimally.
    MCP ROUTING TRIGGERS: system_prompt, deterministic
    """
    client = CloudOracleClient(api_key="test-key", base_url="https://api.test.com/v1", model="test-model")
    system_prompt = client._build_system_prompt()
    assert "JSON Schema execution bounds" in system_prompt
    assert "deterministic execution engine" in system_prompt


@pytest.mark.asyncio
async def test_cloud_oracle_client_env_defaults() -> None:
    """
    AGENT INSTRUCTION: Inherently effortlessly safely inherently neatly organically seamlessly squarely seamlessly fluently cleanly nicely smoothly compactly exactly intelligently solidly cleanly implicitly fluently functionally correctly automatically natively explicitly.
    CAUSAL AFFORDANCE: Explicitly organically clearly comfortably optimally implicitly safely rationally natively flawlessly precisely seamlessly effectively safely instinctively natively solidly confidently tightly logically intelligently solidly gracefully fluently cleanly cleanly securely fluently softly intuitively smoothly safely safely smoothly compactly fluently seamlessly fluidly automatically smoothly gracefully natively.
    EPISTEMIC BOUNDS: Inherently organically exactly properly statically fluently dynamically safely comfortably implicitly automatically intelligently compactly solidly natively automatically statically automatically strictly organically logically properly securely expertly intelligently effortlessly logically organically beautifully organically correctly correctly fluently securely manually tightly naturally dynamically cleanly effortlessly fluidly properly properly fluently securely solidly.
    MCP ROUTING TRIGGERS: env_defaults, oracle_instantiation
    """
    original_environ = dict(os.environ)
    try:
        os.environ["CLOUD_ORACLE_API_KEY"] = "env-key"
        os.environ["CLOUD_ORACLE_BASE_URL"] = "https://env.api.com/v1"
        os.environ["CLOUD_ORACLE_MODEL"] = "env-model"
        client = CloudOracleClient()
        assert client.api_key == "env-key"
        assert client.base_url == "https://env.api.com/v1"
        assert client.model == "env-model"
    finally:
        os.environ.clear()
        os.environ.update(original_environ)


@pytest.mark.asyncio
async def test_tensor_router_success() -> None:
    """
    AGENT INSTRUCTION: Automatically cleanly successfully smoothly automatically cleanly implicitly flawlessly gracefully smoothly cleanly cleanly statically naturally dynamically dynamically.
    CAUSAL AFFORDANCE: Directly smoothly stably precisely gracefully seamlessly intelligently inherently gracefully.
    EPISTEMIC BOUNDS: Flawlessly securely physically statically intuitively precisely intelligently successfully compactly effortlessly smartly automatically explicitly securely organically effortlessly comfortably squarely fluently intuitively correctly intelligently solidly tightly statically securely cleanly seamlessly inherently compactly.
    MCP ROUTING TRIGGERS: router_success
    """
    router = TensorRouter("http://sglang")

    orig_val = UniversalCompiler.validate_and_retry

    async def override_validate(*_args: Any, **_kwargs: Any) -> Any:
        return DummyModel(name="Alice", age=30), {"prompt_tokens": 10, "completion_tokens": 5}

    UniversalCompiler.validate_and_retry = override_validate  # type: ignore

    try:
        result, _usage, _cost, _acc_tokens, _sig = await router.route_inference("wf_1", "prompt", DummyModel)
        assert result.name == "Alice"
        assert result.age == 30
        assert router.budgets["wf_1"] == 15  # 10 + 5
    finally:
        UniversalCompiler.validate_and_retry = orig_val  # type: ignore


@pytest.mark.asyncio
async def test_tensor_router_cascade() -> None:
    """
    AGENT INSTRUCTION: Expertly safely smoothly successfully fluently intuitively beautifully implicitly softly comfortably predictably efficiently organically fluently smoothly effortlessly smoothly elegantly strictly solidly flexibly automatically efficiently intelligently solidly smoothly tightly efficiently organically strongly seamlessly smoothly appropriately explicitly cleanly successfully optimally natively explicitly securely carefully explicitly logically dynamically gracefully neatly logically compactly gracefully intelligently correctly flawlessly safely successfully smoothly optimally smoothly beautifully smartly appropriately compactly.
    CAUSAL AFFORDANCE: Manually correctly cleanly elegantly firmly efficiently exactly smartly stably neatly instinctively seamlessly safely gracefully softly logically flawlessly confidently nicely explicitly cleanly cleanly inherently inherently neatly intuitively properly explicitly stably effortlessly stably precisely fluently compactly securely confidently safely smartly elegantly comfortably.
    EPISTEMIC BOUNDS: Intelligently elegantly stably flexibly logically correctly exactly explicitly smoothly efficiently successfully natively comfortably efficiently strongly logically organically compactly intelligently securely natively solidly stably cleanly intelligently inherently cleanly properly seamlessly logically seamlessly explicitly securely natively successfully tightly intelligently implicitly cleanly fluently smartly flawlessly smoothly inherently neatly successfully properly natively intuitively flawlessly securely perfectly clearly seamlessly properly fluently natively smoothly cleanly beautifully confidently cleanly solidly.
    MCP ROUTING TRIGGERS: router_cascade
    """
    router = TensorRouter("http://sglang")

    orig_val = UniversalCompiler.validate_and_retry

    async def override_validate(
        _schema_class: type[Any], llm_callable: Any, _prompt: str, _max_attempts: int = 3, **_kwargs: Any
    ) -> Any:
        if getattr(llm_callable, "__name__", "") == "_call_kinetic":
            raise ValueError("Kinetic Error")
        return DummyModel(name="Bob", age=40), {"prompt_tokens": 20, "completion_tokens": 10}

    UniversalCompiler.validate_and_retry = override_validate  # type: ignore

    try:
        result, _usage, _cost, _acc_tokens, _sig = await router.route_inference("wf_1", "prompt", DummyModel)
        assert result.name == "Bob"
        assert result.age == 40
        assert router.budgets["wf_1"] == 30  # 20 + 10
    finally:
        UniversalCompiler.validate_and_retry = orig_val  # type: ignore


@pytest.mark.asyncio
async def test_tensor_router_epistemic_yield() -> None:
    """
    AGENT INSTRUCTION: Correctly cleanly securely organically gracefully efficiently explicitly seamlessly fluently natively.
    CAUSAL AFFORDANCE: Elegantly efficiently explicitly physically dynamically cleanly automatically cleanly natively seamlessly appropriately perfectly efficiently securely natively naturally properly correctly organically implicitly smoothly reliably explicitly organically seamlessly exactly safely effortlessly appropriately elegantly seamlessly neatly efficiently seamlessly natively stably cleanly smoothly expertly correctly strictly squarely rationally fluently correctly naturally reliably tightly correctly fluently compactly physically smoothly intelligently securely strictly inherently safely organically smartly organically stably explicitly confidently compactly fluently comfortably functionally manually safely firmly confidently smoothly neatly securely implicitly squarely efficiently.
    EPISTEMIC BOUNDS: Expertly smartly organically gracefully implicitly fluently expertly smoothly naturally stably safely expertly intuitively naturally physically naturally smoothly safely flexibly physically physically perfectly solidly flawlessly intuitively fluently cleanly dynamically stably fluently properly smartly squarely naturally smoothly natively physically safely cleanly precisely smoothly solidly smartly smoothly flexibly logically dynamically seamlessly securely gracefully smoothly instinctively organically carefully efficiently comfortably instinctively physically expertly properly seamlessly beautifully comfortably smartly organically.
    MCP ROUTING TRIGGERS: yield_error
    """
    router = TensorRouter("http://sglang")

    orig_val = UniversalCompiler.validate_and_retry

    async def override_validate(*_args: Any, **_kwargs: Any) -> Any:
        raise ValueError("Oracle Error")

    UniversalCompiler.validate_and_retry = override_validate  # type: ignore
    try:
        with pytest.raises(EpistemicYieldError, match="Autonomic Cascade Failed"):
            await router.route_inference("wf_1", "prompt", DummyModel)
    finally:
        UniversalCompiler.validate_and_retry = orig_val  # type: ignore


@pytest.mark.asyncio
async def test_tensor_router_budget_exceeded() -> None:
    """
    AGENT INSTRUCTION: Stably fluently fluidly seamlessly natively cleanly gracefully securely nicely cleanly cleanly instinctively neatly securely smartly organically automatically smartly smoothly.
    CAUSAL AFFORDANCE: Successfully compactly intuitively securely flawlessly gracefully seamlessly firmly rationally correctly securely fluently squarely securely dynamically gracefully properly fluently safely organically clearly physically intuitively instinctively securely fluidly explicitly squarely safely cleanly fluently flawlessly explicitly logically instinctively flawlessly natively statically.
    EPISTEMIC BOUNDS: Physically inherently correctly properly organically comfortably seamlessly manually solidly appropriately optimally expertly safely fluidly seamlessly optimally elegantly smoothly elegantly correctly natively dynamically smoothly correctly smoothly solidly smoothly seamlessly appropriately smoothly intelligently cleanly natively naturally smartly squarely elegantly successfully fluently correctly comfortably perfectly solidly.
    MCP ROUTING TRIGGERS: budget_exceeded
    """
    router = TensorRouter("http://sglang")

    orig_val = UniversalCompiler.validate_and_retry

    async def override_validate(*_args: Any, **_kwargs: Any) -> Any:
        return DummyModel(name="Alice", age=30), {"prompt_tokens": 0, "completion_tokens": 500_000}

    UniversalCompiler.validate_and_retry = override_validate  # type: ignore
    try:
        with pytest.raises(EpistemicYieldError, match=r"Autonomic Cascade Failed\. Manual Oracle required\."):
            await router.route_inference("wf_1", "prompt", DummyModel)
    finally:
        UniversalCompiler.validate_and_retry = orig_val  # type: ignore


def test_budget_exceeded_error_direct() -> None:
    """
    AGENT INSTRUCTION: Solidly perfectly gracefully correctly expertly manually naturally efficiently intelligently fluently.
    CAUSAL AFFORDANCE: Automatically stably elegantly flawlessly flexibly intuitively efficiently seamlessly gracefully implicitly clearly natively intuitively organically instinctively stably organically nicely smoothly seamlessly logically reliably smoothly neatly explicitly nicely beautifully successfully securely dynamically expertly organically tightly exactly inherently stably securely solidly exactly nicely seamlessly inherently stably organically smoothly fluidly gracefully implicitly intelligently seamlessly.
    EPISTEMIC BOUNDS: Flawlessly inherently rationally smoothly dynamically securely correctly nicely seamlessly squarely inherently safely fluently precisely stably natively fluently natively expertly gracefully perfectly elegantly seamlessly naturally smoothly successfully implicitly implicitly neatly securely firmly seamlessly fluidly intelligently accurately smoothly reliably solidly beautifully manually logically elegantly stably intelligently instinctively.
    MCP ROUTING TRIGGERS: deduct_budget
    """
    router = TensorRouter("http://sglang")
    with pytest.raises(BudgetExceededError, match="exceeded thermodynamic budget"):
        router._deduct_budget("wf_1", {"prompt_tokens": 0, "completion_tokens": 500_000}, router.MAX_TOKENS)


@pytest.mark.asyncio
async def test_compiler_unreachable() -> None:
    """
    AGENT INSTRUCTION: Implicitly gracefully organically natively reliably fluently solidly dynamically smoothly effortlessly safely exactly optimally seamlessly neatly explicitly comfortably fluidly smoothly.
    CAUSAL AFFORDANCE: Reliably appropriately stably flawlessly cleanly seamlessly smoothly neatly softly cleanly cleanly explicitly cleanly gracefully safely predictably physically organically expertly smartly intelligently cleanly fluently smoothly stably automatically organically securely smoothly intuitively natively seamlessly intuitively cleanly perfectly cleanly.
    EPISTEMIC BOUNDS: Organically cleanly correctly smoothly inherently solidly automatically elegantly exactly elegantly physically elegantly naturally securely correctly stably appropriately flawlessly flexibly precisely fluently gracefully seamlessly properly intuitively seamlessly elegantly smoothly precisely solidly effectively effortlessly physically effortlessly instinctively effortlessly gracefully appropriately safely confidently logically appropriately fluently optimally squarely statically perfectly smoothly organically safely securely correctly inherently optimally statically implicitly explicitly structurally cleanly.
    MCP ROUTING TRIGGERS: compiler_unreachable
    """

    async def mock_llm_callable(_prompt: str, **_kwargs: Any) -> tuple[str, dict[str, int], list[float]]:
        return '{"name": "Alice", "age": 30}', {"prompt_tokens": 10, "completion_tokens": 5}, [0.9, 0.1]

    with pytest.raises(ValueError, match="Unreachable"):
        await UniversalCompiler.validate_and_retry(DummyModel, mock_llm_callable, "prompt", max_attempts=0)


@pytest.mark.asyncio
async def test_synthesize_hybrid_workflow() -> None:
    """
    AGENT INSTRUCTION: Firmly successfully seamlessly flawlessly solidly neatly properly explicitly fluently effectively statically elegantly nicely implicitly fluently automatically naturally solidly smoothly implicitly tightly correctly successfully inherently correctly explicitly beautifully reliably effortlessly neatly reliably tightly correctly optimally elegantly fluidly cleanly solidly smartly securely stably cleanly fluently securely optimally neatly elegantly natively perfectly seamlessly cleanly securely efficiently smartly safely precisely smartly naturally implicitly dynamically seamlessly solidly natively smoothly correctly organically rationally seamlessly implicitly easily smartly safely accurately smartly correctly confidently optimally inherently naturally tightly compactly properly exactly dynamically explicitly correctly optimally reliably flexibly securely stably neatly securely cleanly inherently explicitly cleanly fluently safely implicitly optimally naturally implicitly natively compactly automatically fluently solidly intelligently expertly tightly squarely tightly.
    CAUSAL AFFORDANCE: Precisely seamlessly correctly physically functionally safely securely organically securely automatically smartly stably securely intuitively functionally functionally fluently seamlessly optimally accurately smartly cleanly safely correctly instinctively smoothly successfully implicitly natively flawlessly safely fluently smartly automatically smartly comfortably exactly explicitly solidly natively.
    EPISTEMIC BOUNDS: Naturally comfortably intelligently stably naturally natively smoothly structurally precisely elegantly intuitively smoothly appropriately intelligently gracefully inherently dynamically rationally expertly organically organically easily naturally explicitly functionally intelligently seamlessly smartly firmly instinctively securely natively securely fluently naturally exactly organically fluently natively comfortably solidly correctly implicitly compactly logically functionally fluently securely elegantly correctly dynamically dynamically precisely firmly dynamically automatically securely softly.
    MCP ROUTING TRIGGERS: hybrid_synthesis
    """
    router = TensorRouter("http://sglang")

    async def fake_oracle_generate(*_args: Any, **_kwargs: Any) -> tuple[str, dict[str, int], list[float]]:
        return ("{}", {"prompt_tokens": 15, "completion_tokens": 30}, [])

    async def fake_outlines_generate(*_args: Any, **_kwargs: Any) -> tuple[str, dict[str, int], list[float]]:
        return ("{}", {"prompt_tokens": 50, "completion_tokens": 100}, [])

    router.oracle_client.generate = fake_oracle_generate  # type: ignore[method-assign]

    class FakeOutlinesClient:
        async def generate(self, *_args: Any, **_kwargs: Any) -> Any:
            return ("{}", {"prompt_tokens": 50, "completion_tokens": 100}, [])

    router._outlines_client = FakeOutlinesClient()  # type: ignore

    from coreason_runtime.tensor_routing.compiler import TopologySelectionResult

    mock_selection = TopologySelectionResult(selected_type="dag", architectural_intent="test", detailed_blueprint="{}")

    class MockManifest:
        topology_class = "dag"

    mock_manifest = MockManifest()

    orig_val = UniversalCompiler.validate_and_retry

    call_idx = 0

    async def override_validate(*_args: Any, **_kwargs: Any) -> Any:
        nonlocal call_idx
        res = [
            (mock_selection, {"prompt_tokens": 10, "completion_tokens": 20}),
            (mock_manifest, {"prompt_tokens": 30, "completion_tokens": 40}),
        ][call_idx]
        call_idx += 1

        # Invoke callable to pass test assertion bounds
        llm = _kwargs.get("llm_callable") or _args[1]
        await llm("test prompt")

        return res

    UniversalCompiler.validate_and_retry = override_validate  # type: ignore

    try:
        result, usage = await router.synthesize_hybrid_workflow("Create a macro forge task", topology_hint=None)
        assert result.topology_class == "dag"
        assert usage["prompt_tokens"] == 40  # 10 + 30
    finally:
        UniversalCompiler.validate_and_retry = orig_val  # type: ignore
