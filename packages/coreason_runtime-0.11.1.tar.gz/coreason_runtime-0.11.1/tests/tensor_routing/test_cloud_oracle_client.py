# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Phase 3 tests for CloudOracleClient kwargs branches and generate() path.

Uses httpx.ASGITransport with a FastAPI stub to physically intercept HTTP calls — zero mocks.
"""

import pytest
from fastapi import FastAPI
from fastapi.responses import JSONResponse

from coreason_runtime.tensor_routing.client.cloud_oracle_client import CloudOracleClient

# ── Physical Stub API ─────────────────────────────────────────────────

_stub_app = FastAPI()


@_stub_app.post("/chat/completions")
async def stub_completions() -> JSONResponse:
    """Return a minimal OpenAI-compatible chat completion response."""
    return JSONResponse(
        content={
            "choices": [{"message": {"content": '{"result": "ok"}'}}],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5},
        }
    )


# ── Tests ─────────────────────────────────────────────────────────────


class TestCloudOracleClient:
    """Physical substrate tests for CloudOracleClient."""

    @pytest.mark.asyncio
    async def test_generate_with_all_kwargs(self) -> None:
        """Call generate() with baseline_cognitive_state, logit_steganography,
        peft_adapters, and constrained_decoding kwargs to cover L72-80 debug logs.
        """
        import httpx

        transport = httpx.ASGITransport(app=_stub_app)

        client = CloudOracleClient(
            api_key="test-key",
            base_url="http://testserver",
            model="test-model",
        )
        # Replace the internal httpx client with our transport
        client.client = httpx.AsyncClient(transport=transport, base_url="http://testserver")

        raw_content, usage, probabilities = await client.generate(
            prompt="Test prompt",
            schema_dict={"type": "object"},
            baseline_cognitive_state={"vector": [0.1, 0.2]},
            logit_steganography={"enabled": True},
            peft_adapters=["adapter-1"],
            constrained_decoding={"schema": {"type": "object"}},
        )

        assert raw_content == '{"result": "ok"}'
        assert usage["prompt_tokens"] == 10
        assert usage["completion_tokens"] == 5
        assert usage["total_tokens"] == 15
        assert len(probabilities) == 2

        await client.client.aclose()

    @pytest.mark.asyncio
    async def test_generate_minimal_kwargs(self) -> None:
        """Call generate() with no optional kwargs — baseline coverage."""
        import httpx

        transport = httpx.ASGITransport(app=_stub_app)

        client = CloudOracleClient(
            api_key="test-key",
            base_url="http://testserver",
            model="test-model",
        )
        client.client = httpx.AsyncClient(transport=transport, base_url="http://testserver")

        raw_content, usage, _probabilities = await client.generate(
            prompt="Minimal test",
            schema_dict={"type": "object"},
        )

        assert raw_content == '{"result": "ok"}'
        assert usage["total_tokens"] == 15

        await client.client.aclose()

    @pytest.mark.asyncio
    async def test_generate_server_error(self) -> None:
        """HTTP error from cloud oracle raises httpx.HTTPStatusError."""
        import httpx

        error_app = FastAPI()

        @error_app.post("/chat/completions")
        async def _error_endpoint() -> JSONResponse:
            return JSONResponse(content={"error": "boom"}, status_code=500)

        transport = httpx.ASGITransport(app=error_app)

        client = CloudOracleClient(
            api_key="test-key",
            base_url="http://testserver",
            model="test-model",
        )
        client.client = httpx.AsyncClient(transport=transport, base_url="http://testserver")

        with pytest.raises(httpx.HTTPStatusError):
            await client.generate(
                prompt="Should fail",
                schema_dict={"type": "object"},
            )

        await client.client.aclose()

    def test_system_prompt_with_schema(self) -> None:
        """_build_system_prompt includes schema when provided."""
        client = CloudOracleClient(api_key="k", base_url="http://x", model="m")
        prompt = client._build_system_prompt({"type": "object", "properties": {}})
        assert "REQUIRED JSON SCHEMA" in prompt

    def test_system_prompt_without_schema(self) -> None:
        """_build_system_prompt omits schema when None."""
        client = CloudOracleClient(api_key="k", base_url="http://x", model="m")
        prompt = client._build_system_prompt(None)
        assert "REQUIRED JSON SCHEMA" not in prompt
