# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for SGLangKineticClient.

Uses httpx.ASGITransport with a FastAPI stub to physically test the SGLang client
without requiring a live SGLang server. The `test_live_sglang_tensor_compilation`
test requires a physical GPU and running SGLang container — it auto-skips otherwise.
"""

import os
from typing import Any

import httpx
import pytest
from fastapi import FastAPI
from fastapi.responses import JSONResponse

from coreason_runtime.tensor_routing.client.sglang_kinetic_client import SGLangKineticClient


def _probe_physical_gpu() -> bool:
    """Mechanically probes the PCIe bus for an active NVIDIA driver."""
    try:
        import pynvml

        pynvml.nvmlInit()
        device_count = pynvml.nvmlDeviceGetCount()
        pynvml.nvmlShutdown()
        return int(device_count) > 0
    except Exception:
        return False


requires_physical_gpu = pytest.mark.skipif(
    not _probe_physical_gpu(),
    reason="TEST QUARANTINED: Requires a physical NVIDIA GPU and pynvml drivers.",
)


# ── Physical Stub API (simulates SGLang /generate endpoint) ──────────

_sglang_stub = FastAPI()


@_sglang_stub.post("/generate")
async def stub_generate(request: dict[str, Any]) -> JSONResponse:
    """Return a minimal SGLang-compatible generate response."""
    return JSONResponse(
        content={
            "text": '{"output": "ACKNOWLEDGED"}',
            "meta_info": {
                "prompt_tokens": 15,
                "completion_tokens": 8,
            },
        }
    )


@_sglang_stub.post("/generate_with_activations")
async def stub_generate_with_activations(request: dict[str, Any]) -> JSONResponse:
    """Return a response with SAE layer activations for mechanistic audit tests."""
    return JSONResponse(
        content={
            "text": '{"output": "audited"}',
            "meta_info": {"prompt_tokens": 10, "completion_tokens": 5},
            "layer_activations": [[0.1, 0.2], [0.3, 0.4]],
        }
    )


# ── Tests ─────────────────────────────────────────────────────────────


class TestSGLangKineticClientStub:
    """Physical substrate tests using a FastAPI stub — zero mocks."""

    @pytest.mark.asyncio
    async def test_generate_basic(self) -> None:
        """Basic generate() call returns text + usage + probabilities.

        Covers L27-103 (full generate path without kwargs).
        """
        transport = httpx.ASGITransport(app=_sglang_stub)
        client = SGLangKineticClient(base_url="http://testserver")
        client.client = httpx.AsyncClient(transport=transport, base_url="http://testserver")

        raw_content, usage, probabilities = await client.generate(
            prompt="Return ACKNOWLEDGED",
            schema_dict={"type": "object"},
        )

        assert raw_content == '{"output": "ACKNOWLEDGED"}'
        assert usage["prompt_tokens"] == 15
        assert usage["completion_tokens"] == 8
        assert usage["total_tokens"] == 23
        assert len(probabilities) == 2

        await client.client.aclose()

    @pytest.mark.asyncio
    async def test_generate_with_all_kwargs(self) -> None:
        """Generate with cognitive steering, steganography, PEFT, and constrained decoding.

        Covers L30-39 (kwargs debug log branches) and L46-47 (constrained_decoding JSON schema),
        L55-63 (logit steganography injection).
        """
        transport = httpx.ASGITransport(app=_sglang_stub)
        client = SGLangKineticClient(base_url="http://testserver")
        client.client = httpx.AsyncClient(transport=transport, base_url="http://testserver")

        raw_content, usage, _probs = await client.generate(
            prompt="Constrained test",
            schema_dict={"type": "object", "properties": {"output": {"type": "string"}}},
            baseline_cognitive_state={"vector": [0.1, 0.2, 0.3]},
            logit_steganography={
                "watermark_entropy_key": "test-key-123",
                "gumbel_temperature": 0.3,
                "residual_stream_layer_target": 12,
            },
            peft_adapters=["adapter-lora-1", "adapter-lora-2"],
            constrained_decoding={"schema": {"type": "object"}},
        )

        assert raw_content == '{"output": "ACKNOWLEDGED"}'
        assert usage["total_tokens"] == 23

        await client.client.aclose()

    @pytest.mark.asyncio
    async def test_generate_with_mechanistic_audit(self) -> None:
        """Generate with mechanistic interpretability audit extraction.

        Covers L66-73 (mechanistic_audit SAE dump injection),
        L92-94 (layer_activations capture from response).
        """
        # Use a custom stub that returns layer_activations
        activations_app = FastAPI()

        @activations_app.post("/generate")
        async def _gen(request: dict[str, Any]) -> JSONResponse:
            return JSONResponse(
                content={
                    "text": '{"output": "audited"}',
                    "meta_info": {"prompt_tokens": 10, "completion_tokens": 5},
                    "layer_activations": [[0.1, 0.2], [0.3, 0.4]],
                }
            )

        transport = httpx.ASGITransport(app=activations_app)
        client = SGLangKineticClient(base_url="http://testserver")
        client.client = httpx.AsyncClient(transport=transport, base_url="http://testserver")

        raw_content, usage, _probs = await client.generate(
            prompt="Audit test",
            schema_dict={"type": "object"},
            mechanistic_audit={
                "target_layers": [6, 12, 18],
                "top_k_features": 32,
                "halt_on_anomaly": True,
            },
        )

        assert raw_content == '{"output": "audited"}'
        assert "layer_activations" in usage
        assert usage["layer_activations"] == [[0.1, 0.2], [0.3, 0.4]]  # type: ignore[comparison-overlap]

        await client.client.aclose()

    @pytest.mark.asyncio
    async def test_generate_server_error(self) -> None:
        """HTTP error from SGLang raises httpx.HTTPStatusError."""
        error_app = FastAPI()

        @error_app.post("/generate")
        async def _err(request: dict[str, Any]) -> JSONResponse:
            return JSONResponse(content={"error": "OOM"}, status_code=500)

        transport = httpx.ASGITransport(app=error_app)
        client = SGLangKineticClient(base_url="http://testserver")
        client.client = httpx.AsyncClient(transport=transport, base_url="http://testserver")

        with pytest.raises(httpx.HTTPStatusError):
            await client.generate(prompt="Should fail", schema_dict={"type": "object"})

        await client.client.aclose()


# ── Live Physical GPU Test (Auto-Skipped in CI) ──────────────────────


async def _is_sglang_booted(url: str) -> bool:
    """Mechanically probe the SGLang health endpoint."""
    try:
        async with httpx.AsyncClient() as hc:
            res = await hc.get(f"{url}/health", timeout=1.0)
            return res.status_code == 200
    except Exception:
        return False


@requires_physical_gpu
@pytest.mark.asyncio
async def test_live_sglang_tensor_compilation() -> None:
    """Execute a live tensor routing pass against the physical SGLang API.

    This test is quarantined behind the `requires_physical_gpu` marker.
    It will only execute on machines with an NVIDIA GPU and a running
    SGLang container (default: http://127.0.0.1:30000).
    """
    sglang_url = os.getenv("SGLANG_URL", "http://127.0.0.1:30000")

    if not await _is_sglang_booted(sglang_url):
        pytest.skip("SGLang container is offline. Skipping live tensor test.")

    client = SGLangKineticClient(base_url=sglang_url)

    raw_content, usage, probabilities = await client.generate(
        prompt="Return the exact word 'ACKNOWLEDGED'.",
        schema_dict={"type": "object"},
        temperature=0.0,
        max_tokens=10,
    )

    assert isinstance(raw_content, str)
    assert usage["total_tokens"] > 0
    assert len(probabilities) == 2
