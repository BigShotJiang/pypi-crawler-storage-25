# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import pytest
from coreason_manifest.spec.ontology import ActivationSteeringContract

from coreason_runtime.tensor_routing.steering import MechanisticSteeringEngine
from coreason_runtime.utils.exceptions import ManifestConformanceError


def test_mechanistic_steering_success_bound() -> None:
    """Verifies that native mathematically mapped injections translate perfectly."""
    contract = ActivationSteeringContract(
        scaling_factor=0.8, steering_vector_hash="0" * 64, injection_layers=[4, 8, 12], vector_modality="additive"
    )

    payload = MechanisticSteeringEngine.construct_tensor_payload(contract, hardware_supports_latent=True)

    assert payload["mechanistic_backend"] == "physical_sglang_intercept"
    assert payload["scaling_factor"] == 0.8
    assert payload["sae_dictionary_hash"] == "default-hash"


def test_mechanistic_steering_hardware_exclusion() -> None:
    """Verifies Cloud API frameworks physically safely reject deep injection endpoints natively."""
    contract = ActivationSteeringContract(
        scaling_factor=1.0, steering_vector_hash="1" * 64, injection_layers=[4, 8, 12], vector_modality="additive"
    )

    with pytest.raises(ManifestConformanceError):
        MechanisticSteeringEngine.construct_tensor_payload(contract, hardware_supports_latent=False)
