# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import json
from typing import Any

import pytest
from pydantic import BaseModel, ConfigDict

from coreason_runtime.tensor_routing.compiler import UniversalCompiler


class DummyAgent(BaseModel):
    model_config = ConfigDict(extra="forbid")
    topology_class: str = "agent"
    description: str


class DummyManifest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    type: str = "dummy"
    nodes: dict[str, DummyAgent]
    edges: list[tuple[str, str]] | None = None


class DummyMacroManifest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    type: str = "macro"
    nodes: dict[str, Any]
    max_depth: int
    max_fan_out: int
    adjudicator_id: str


async def dummy_llm(*_args: Any, **_kwargs: Any) -> tuple[str, dict[str, int], list[float]]:
    return {"genesis_provenance": {"derivation_mode": "direct_translation"}}, {"prompt_tokens": 10}, []  # type: ignore


@pytest.mark.asyncio
async def test_entropy_escalation_error() -> None:
    """
    AGENT INSTRUCTION: Validates that high baseline entropy triggers deterministic Epistemic Collapse natively.

    CAUSAL AFFORDANCE: Guarantees compiler halts execution and throws ValueError natively for unacceptably high entropy outputs.

    EPISTEMIC BOUNDS: Tested using a strictly typed async inline literal override without standard unittest mocks.

    MCP ROUTING TRIGGERS: deterministic_collapse, entropy_validation, strict_typing
    """

    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return {"genesis_provenance": {"derivation_mode": "direct_translation"}}, {}, [0.5, 0.5]  # type: ignore

    with pytest.raises(ValueError, match="Epistemic Collapse"):
        await UniversalCompiler.validate_and_retry(
            DummyManifest, mock_llm, "test", max_attempts=1, baseline_entropy_threshold=0.1
        )


@pytest.mark.asyncio
async def test_regex_matching_ticks() -> None:
    """
    AGENT INSTRUCTION: Proves JSON parsing safely extracts payloads hidden behind markdown codeblock formatting.

    CAUSAL AFFORDANCE: Ensures physical regex bounds strictly sanitize generated markdown block text into loadable JSON strings.

    EPISTEMIC BOUNDS: Bends parsing paths with static string manipulation injected through an inline coroutine.

    MCP ROUTING TRIGGERS: codeblock_parsing, markdown_sanitization, json_extraction
    """

    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return (
            '```json\n{ "topology_class": "dummy", "genesis_provenance": {"derivation_mode": "direct_translation"}, "adjudicator_cid": "mock-cid", "nodes": {} }\n```',
            {},
            [],
        )

    res, _ = await UniversalCompiler.validate_and_retry(DummyManifest, mock_llm, "test", max_attempts=1)
    assert res.type == "dummy"


@pytest.mark.asyncio
async def test_agent_hallucination_unpacking() -> None:
    """
    AGENT INSTRUCTION: Demonstrates fatal rejection bounds against schema violation payloads embedded deep in node graphs.

    CAUSAL AFFORDANCE: Ensures deeply hallucinated keys fail Pydantic bounds immediately before returning to workflow execution blocks.

    EPISTEMIC BOUNDS: Executed physically with raw dict dumps bypassing mock limits.

    MCP ROUTING TRIGGERS: schema_violation, pydantic_rejection, deep_validation
    """
    payload = {
        "topology_class": "dummy",
        "genesis_provenance": {"derivation_mode": "direct_translation"},
        "adjudicator_cid": "mock-cid",
        "target_epistemic_deficit": {"query_vector": {}},
        "nodes": {
            "node_1": {"agent": {"instructions": "do task", "task": "mission1", "description": "existing desc"}},
            "did:agent:node_2": {"system": {"instructions": "do system", "type": "fake_agent"}},
        },
        "edges": [{"source": "node1", "target": "did:agent:node2"}, ["node1", "did:agent:node2"]],
    }

    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return json.dumps(payload), {}, []

    with pytest.raises(ValueError, match=r".*"):
        await UniversalCompiler.validate_and_retry(DummyManifest, mock_llm, "test", max_attempts=1)


@pytest.mark.asyncio
async def test_epistemic_contradiction_mock() -> None:
    """
    AGENT INSTRUCTION: Verifies syntax failure parsing directly yields termination without endless retry spins.

    CAUSAL AFFORDANCE: Prevents thermodynamic waste by natively aborting parsing layers failing basic syntax mapping.

    EPISTEMIC BOUNDS: Leverages inline raw text payloads with unclosed brackets for physical exception triggers.

    MCP ROUTING TRIGGERS: syntax_failure, loop_avoidance, parsing_termination
    """

    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return (
            '{"topology_class": "dummy", "genesis_provenance": {"derivation_mode": "direct_translation"}, "adjudicator_cid": "mock-cid", "nodes": {  contradictory_mock_token }',
            {},
            [],
        )

    with pytest.raises(ValueError, match=r".*"):
        await UniversalCompiler.validate_and_retry(
            DummyManifest, mock_llm, "test", max_attempts=1, self_correction=True
        )


@pytest.mark.asyncio
async def test_epistemic_reward_policy_mock() -> None:
    """
    AGENT INSTRUCTION: Asserts that low token probability scores correctly trigger the Epistemic Reward policy fail state.

    CAUSAL AFFORDANCE: Guarantees rejection of technically valid JSON that fundamentally correlates with low likelihood probabilities.

    EPISTEMIC BOUNDS: Feeds [0.1, 0.2] directly into probability arrays native to the routing layer logic.

    MCP ROUTING TRIGGERS: reward_policy, probability_rejection, generation_confidence
    """

    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return (
            '{"topology_class": "dummy", "genesis_provenance": {"derivation_mode": "direct_translation"}, "adjudicator_cid": "mock-cid", "nodes": {}}',
            {},
            [0.1, 0.2],
        )

    with pytest.raises(ValueError, match="EpistemicRewardModelPolicy Failed"):
        await UniversalCompiler.validate_and_retry(
            DummyManifest, mock_llm, "test", max_attempts=1, epistemic_reward_policy=True
        )


@pytest.mark.asyncio
async def test_epistemic_reward_policy_empty_probabilities() -> None:
    """
    AGENT INSTRUCTION: Guarantees null probabilities bypass reward policy logic without crashing the validation loop.

    CAUSAL AFFORDANCE: Ensures API endpoints lacking token probability features silently downgrade to pure structural schema checks.

    EPISTEMIC BOUNDS: Physically returns an empty array to simulate third-party unconstrained providers.

    MCP ROUTING TRIGGERS: null_probability, silent_downgrade, validation_bypass
    """

    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return (
            '{"topology_class": "dummy", "genesis_provenance": {"derivation_mode": "direct_translation"}, "adjudicator_cid": "mock-cid", "nodes": {}}',
            {},
            [],
        )

    res, _ = await UniversalCompiler.validate_and_retry(
        DummyManifest, mock_llm, "test", max_attempts=1, epistemic_reward_policy=True
    )
    assert res.type == "dummy"


@pytest.mark.asyncio
async def test_epistemic_reward_policy_success() -> None:
    """
    AGENT INSTRUCTION: Validates high-confidence probabilities actively pass the reward policy check.

    CAUSAL AFFORDANCE: Ensures physical execution paths successfully parse top probability chunks retaining valid schema shapes.

    EPISTEMIC BOUNDS: Simulates optimal logit confidence natively.

    MCP ROUTING TRIGGERS: reward_policy_pass, high_confidence
    """

    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return (
            '{"topology_class": "dummy", "genesis_provenance": {"derivation_mode": "direct_translation"}, "adjudicator_cid": "mock-cid", "nodes": {}}',
            {},
            [0.9, 0.8],
        )

    res, _ = await UniversalCompiler.validate_and_retry(
        DummyManifest, mock_llm, "test", max_attempts=1, epistemic_reward_policy=True
    )
    assert res.type == "dummy"


@pytest.mark.asyncio
async def test_self_correction_payload() -> None:
    """
    AGENT INSTRUCTION: Ensures the fallback compiler loop dynamically modifies the prompt for subsequent calls upon schema errors.

    CAUSAL AFFORDANCE: Mutates the physical execution bounds using deterministic loop unrolling when error traces are found.

    EPISTEMIC BOUNDS: Examines string parameters sequentially via prompt interception logic without test framework injection.

    MCP ROUTING TRIGGERS: self_correction, fallback_loop, dynamic_prompting
    """

    async def mock_llm(prompt: str, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        if "System Error" in prompt:
            return (
                '{"topology_class": "dummy", "genesis_provenance": {"derivation_mode": "direct_translation"}, "adjudicator_cid": "mock-cid", "nodes": {"did:agent:n1": {"description": "hello"}}}',
                {},
                [],
            )
        return "invalid", {}, []

    res, _ = await UniversalCompiler.validate_and_retry(
        DummyManifest, mock_llm, "test", max_attempts=2, self_correction=True
    )
    assert res.type == "dummy"


@pytest.mark.asyncio
async def test_pydantic_unregistered_type() -> None:
    """
    AGENT INSTRUCTION: Proves the compiler inherently rejects topological hints lacking physical registered schema classes.

    CAUSAL AFFORDANCE: Restricts execution explicitly to registered models and rejects hallucinated hints securely.

    EPISTEMIC BOUNDS: Simulates illegal type inference routing without touching the filesystem.

    MCP ROUTING TRIGGERS: unregistered_type, explicit_restriction, type_inference
    """

    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return {"genesis_provenance": {"derivation_mode": "direct_translation"}}, {}, []  # type: ignore

    with pytest.raises(ValueError, match=r".*"):
        await UniversalCompiler.synthesize_manifest(
            "test", mock_llm, mock_llm, topology_hint="unregistered", max_epistemic_nodes=5
        )


def test_recursive_type_hints() -> None:
    """
    AGENT INSTRUCTION: Asserts proper parsing mechanics over infinite cyclical Pydantic classes natively.

    CAUSAL AFFORDANCE: Validates the type-extraction utility cleanly avoids stack overflows on recursive definitions.

    EPISTEMIC BOUNDS: Executes pure Python structural typing analysis.

    MCP ROUTING TRIGGERS: static_analysis, recursive_types, extraction_bounds
    """

    class RecursiveNode(BaseModel):
        type: str
        parent: Any | None = None

    hints = UniversalCompiler.extract_type_hints(RecursiveNode)
    assert "parent" in (hints if isinstance(hints, dict) else {})

    class CircNode(BaseModel):
        type: str
        node: Any | None = None

    CircNode.model_rebuild()
    UniversalCompiler.extract_type_hints(CircNode)


def test_enforce_strict_array() -> None:
    """
    AGENT INSTRUCTION: Proves pure list wrapping behavior operates perfectly under validation extraction paths.

    CAUSAL AFFORDANCE: Ensures strict schema adherence during list construction directly into JSON bounds natively.

    EPISTEMIC BOUNDS: Synchronous type evaluation against memory directly.

    MCP ROUTING TRIGGERS: array_wrapping, bounds_adherence, synchronous_typing
    """

    class DummyArray(BaseModel):
        arr: list[dict[str, str]]

    UniversalCompiler.compile_schema(DummyArray)


def test_remove_unsupported_exception_catch() -> None:
    """
    AGENT INSTRUCTION: Validates deterministic failures correctly propagate out of extraction loops without catching internal memory faults silently.

    CAUSAL AFFORDANCE: Tests absolute failure states on object property evaluations.

    EPISTEMIC BOUNDS: Injects pure dictionary class failures statically to test type reflection logic.

    MCP ROUTING TRIGGERS: failure_propagation, reflection_bounds
    """

    class EvilDict(dict[str, Any]):
        def values(self) -> Any:
            raise Exception("Simulated DB boom")

    UniversalCompiler.extract_type_hints(EvilDict())

    with pytest.raises(RuntimeError):
        UniversalCompiler.compile_schema(EvilDict())  # type: ignore


@pytest.mark.asyncio
async def test_compile_no_required_properties() -> None:
    """
    AGENT INSTRUCTION: Ascertains the compiler properly processes and compiles schema models perfectly omitting explicit requirements.

    CAUSAL AFFORDANCE: Grants resilience parsing for flexible output payloads.

    EPISTEMIC BOUNDS: Static evaluation natively via type reflection rules.

    MCP ROUTING TRIGGERS: requirement_omission, flexible_payloads, evaluation_resilience
    """

    class DummyNoRequired(BaseModel):
        prop: str | None = None

    assert UniversalCompiler.compile_schema(DummyNoRequired) is not None


@pytest.mark.asyncio
async def test_validate_and_retry_type_fallback() -> None:
    """
    AGENT INSTRUCTION: Confirms type inference naturally collapses into defined structures when the source explicitly ignores fields.

    CAUSAL AFFORDANCE: Forbids empty topology overrides structurally returning to valid target schemas.

    EPISTEMIC BOUNDS: Inline explicit return block injection.

    MCP ROUTING TRIGGERS: type_collapse, defined_structures, inference_override
    """

    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return '{"topology_class": "none", "nodes": {}}', {}, []

    res, _ = await UniversalCompiler.validate_and_retry(DummyManifest, mock_llm, "test", max_attempts=1)
    assert res.type == "dummy"


@pytest.mark.asyncio
async def test_validate_and_retry_extra_forbidden_fields() -> None:
    """
    AGENT INSTRUCTION: Proves generation errors containing unknown payload keys properly delete the forbidden keys physically.

    CAUSAL AFFORDANCE: Sanitizes incoming logic gates to strictly defined model attributes.

    EPISTEMIC BOUNDS: Native dictionary parsing mutations.

    MCP ROUTING TRIGGERS: physical_sanitization, unknown_key_deletion
    """

    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return (
            json.dumps(
                {
                    "topology_class": "dummy",
                    "genesis_provenance": {"derivation_mode": "direct_translation"},
                    "adjudicator_cid": "mock-cid",
                    "nodes": {},
                    "hallucinated_field": "fake",
                }
            ),
            {},
            [],
        )

    res, _ = await UniversalCompiler.validate_and_retry(DummyManifest, mock_llm, "test", max_attempts=1)
    assert res.type == "dummy"


@pytest.mark.asyncio
async def test_validate_and_retry_macro_fallbacks() -> None:
    """
    AGENT INSTRUCTION: Ascertains the physical fallback instantiation uses correctly injected macro limits directly absent in generation.

    CAUSAL AFFORDANCE: Implements hard limits statically when the generated target is missing vital boundaries.

    EPISTEMIC BOUNDS: Analyzes strict boundary generation fields synchronously.

    MCP ROUTING TRIGGERS: macro_fallback, boundary_limits
    """

    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return (
            '{"topology_class": "macro", "genesis_provenance": {"derivation_mode": "direct_translation"}, "nodes": {}}',
            {},
            [],
        )

    res, _ = await UniversalCompiler.validate_and_retry(DummyMacroManifest, mock_llm, "test", max_attempts=1)
    assert res.adjudicator_id == "did:coreason:adjudicator"
    assert res.max_depth == 10
    assert res.max_fan_out == 5


@pytest.mark.asyncio
async def test_validate_and_retry_remove_hallucinated_macro_fields() -> None:
    """
    AGENT INSTRUCTION: Proves forbidden macro payload boundaries are safely excluded from standard dictionary schemas structurally.

    CAUSAL AFFORDANCE: Enforces complete physical separation between topology schema parameters natively.

    EPISTEMIC BOUNDS: Uses memory dumps strictly verified without file IO modifications.

    MCP ROUTING TRIGGERS: macro_redaction, topology_separation
    """

    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        mock_payload = {
            "topology_class": "dummy",
            "genesis_provenance": {"derivation_mode": "direct_translation"},
            "adjudicator_cid": "mock-cid",
            "nodes": {},
            "adjudicator_id": "fake",
            "max_depth": 999,
            "max_fan_out": 55,
            "participant_node_ids": [],
        }
        return json.dumps(mock_payload), {}, []

    res, _ = await UniversalCompiler.validate_and_retry(DummyManifest, mock_llm, "test", max_attempts=1)
    assert res.type == "dummy"


@pytest.mark.asyncio
async def test_validate_and_retry_strict_manifest_edges_deletion() -> None:
    """
    AGENT INSTRUCTION: Validates deletion protocols correctly destroy edges parameters on strict models natively.

    CAUSAL AFFORDANCE: Rejects parameter leakage between swarm nodes entirely if model strictness bounds exclude them.

    EPISTEMIC BOUNDS: Physically tests generic dictionary schema reduction.

    MCP ROUTING TRIGGERS: edge_deletion, parameter_leakage, strictness_bounds
    """

    class EdgeForbiddingManifest(BaseModel):
        model_config = ConfigDict(extra="forbid")
        type: str = "swarm"
        nodes: dict[str, Any]

    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return json.dumps({"topology_class": "swarm", "nodes": {}, "edges": ["foo", "bar"]}), {}, []

    res, _ = await UniversalCompiler.validate_and_retry(EdgeForbiddingManifest, mock_llm, "test", max_attempts=1)
    assert res.type == "swarm"


@pytest.mark.asyncio
async def test_compiler_zero_shot_alignment_and_casting() -> None:
    """
    AGENT INSTRUCTION: Guarantees casting properly intercepts outputs to structural validation patterns before crash routing.

    CAUSAL AFFORDANCE: Safely processes generation loops that bypass exact schema structures but provide structurally typed answers.

    EPISTEMIC BOUNDS: Synchronously verifies object dictionaries inside memory execution scopes.

    MCP ROUTING TRIGGERS: zero_shot_casting, structural_patterns, error_loops
    """

    class DummyAgentResponse(BaseModel):
        output: str
        other_field: str

    async def mock_llm_keys_to_delete(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        payload = {"extra_key1": "hello", "other_field": {"some_nested": "value"}}
        return json.dumps(payload), {}, []

    with pytest.raises(ValueError, match=r".*"):
        await UniversalCompiler.validate_and_retry(DummyAgentResponse, mock_llm_keys_to_delete, "test", max_attempts=1)

    class OutputOnlyResponse(BaseModel):
        output: str

    async def mock_llm_result(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return json.dumps({"result": "my_result_value"}), {}, []

    res_out: OutputOnlyResponse
    res_out, _ = await UniversalCompiler.validate_and_retry(
        OutputOnlyResponse,
        mock_llm_result,
        "test",
        max_attempts=1,
    )
    assert res_out.output == "my_result_value"

    async def mock_llm_action(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return json.dumps({"action": "my_action_value"}), {}, []

    res_out, _ = await UniversalCompiler.validate_and_retry(
        OutputOnlyResponse,
        mock_llm_action,
        "test",
        max_attempts=1,
    )
    assert res_out.output == "my_action_value"

    async def mock_llm_empty(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return json.dumps({}), {}, []

    with pytest.raises(ValueError, match=r".*"):
        await UniversalCompiler.validate_and_retry(
            OutputOnlyResponse,
            mock_llm_empty,
            "test",
            max_attempts=1,
        )


@pytest.mark.asyncio
async def test_compiler_deep_schema_sanitization() -> None:
    """
    AGENT INSTRUCTION: Validates deep schema tree mutations strictly redact unknown elements cleanly natively.

    CAUSAL AFFORDANCE: Prevents cascading vulnerabilities related to nested schema injection bypasses.

    EPISTEMIC BOUNDS: Physically mutates deeply nested structures and tests dictionary hashes successfully.

    MCP ROUTING TRIGGERS: tree_mutations, deep_sanitization, schema_injection
    """

    class DeepSchemaManifest(BaseModel):
        type: str = "deep"
        nodes: dict[str, Any]
        information_flow: dict[str, Any]
        observability: dict[str, Any]
        target_epistemic_deficit: dict[str, Any]

    async def mock_llm_deep(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        payload = {
            "topology_class": "deep",
            "nodes": {
                "did:agent:n1": {
                    "topology_class": "human",
                    "timeout_seconds": 10,
                    "required_attestation": "fido2_webauthn",
                    "human": {},
                }
            },
            "information_flow": {
                "rules": [{"action": "allow"}],
                "latent_firewalls": [{"sae_dictionary_hash": "short"}],
            },
            "observability": {"telemetry_backpressure": {"occluded_refresh_rate_hz": 20}},
        }
        return json.dumps(payload), {}, []

    res, _ = await UniversalCompiler.validate_and_retry(DeepSchemaManifest, mock_llm_deep, "test", max_attempts=1)

    assert res.nodes["did:agent:n1"]["required_attestation"] == "fido2_webauthn"
    assert "timeout_seconds" not in res.nodes["did:agent:n1"]
    assert "human" not in res.nodes["did:agent:n1"]
    assert res.information_flow["rules"][0]["action"] == "redact"
    assert len(res.information_flow["latent_firewalls"][0]["sae_dictionary_hash"]) == 64
    assert res.observability["telemetry_backpressure"]["occluded_refresh_rate_hz"] == 1
    assert res.target_epistemic_deficit["query_vector"]["vector_base64"] == "H4sIAAAAAAAACw=="


@pytest.mark.asyncio
async def test_compiler_macro_forge_generation() -> None:
    """
    AGENT INSTRUCTION: Confirms macro generation limits aggressively drop the parse layer down statically.

    CAUSAL AFFORDANCE: Synthesizes deterministic manifest constraints before reaching raw extraction logic natively.

    EPISTEMIC BOUNDS: Returns directly failing topologies.

    MCP ROUTING TRIGGERS: macro_forge, static_constraints, synthesis_rejection
    """

    async def mock_llm_macro(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return '{"genesis_provenance": {"derivation_mode": "direct_translation"}}', {}, []

    with pytest.raises(ValueError, match=r".*"):
        await UniversalCompiler.synthesize_manifest(
            "test", mock_llm_macro, mock_llm_macro, topology_hint="macro_forge", max_epistemic_nodes=3
        )


@pytest.mark.asyncio
async def test_fsm_schema_scrubbing_epistemic_deficit() -> None:
    """
    AGENT INSTRUCTION: Proves explicit structural bounds are scrubbed preceding logit token constraints natively.

    CAUSAL AFFORDANCE: Guarantees complex FSM representations securely remove epistemic payloads to save computational overhead.

    EPISTEMIC BOUNDS: Analyzes string lengths inside the isolated execution layer accurately without patches.

    MCP ROUTING TRIGGERS: fsm_scrubbing, logit_constraints, computational_overhead
    """

    async def mock_thinking(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return '{"selected_type": "macro_forge", "architectural_intent": "test", "detailed_blueprint": "test"}', {}, []

    async def mock_typing(*_a: Any, **kwargs: Any) -> tuple[str, dict[str, Any], list[float]]:
        _ = kwargs.get("schema_dict", {})
        return '{"invalid": "json"}', {}, []

    with pytest.raises(ValueError, match=r"Epistemic Collapse"):
        await UniversalCompiler.synthesize_manifest(
            "test_prompt", mock_thinking, mock_typing, topology_hint="macro_forge"
        )


@pytest.mark.asyncio
async def test_compiler_edge_parsing_unconventional() -> None:
    """
    AGENT INSTRUCTION: Safely checks irregular structure routing edges into dictionary representations cleanly natively.

    CAUSAL AFFORDANCE: Excludes recursive or cyclic array lists safely within generation routing blocks.

    EPISTEMIC BOUNDS: Native validation tests.

    MCP ROUTING TRIGGERS: edge_parsing, recursion_exclusion
    """

    class StrangeEdges(BaseModel):
        edges: Any

    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        payload = {
            "edges": [
                ["node1", "node2", "extra_weight"],
                ("nodeA", "nodeB", 0.5),
                "unsupported_string",
                ["cycle", "cycle"],
            ]
        }
        return json.dumps(payload), {}, []

    res, _ = await UniversalCompiler.validate_and_retry(StrangeEdges, mock_llm, "test", max_attempts=1)

    assert ("node1", "node2") in res.edges
    assert ("nodeA", "nodeB") in res.edges
    assert "unsupported_string" in res.edges
    assert ("cycle", "cycle") not in res.edges


@pytest.mark.asyncio
async def test_compiler_type_deletion() -> None:
    """
    AGENT INSTRUCTION: Proves pure type erasure natively works upon explicit type override triggers.

    CAUSAL AFFORDANCE: Safely processes generation loops parsing out native model schemas securely natively.

    EPISTEMIC BOUNDS: Explicit override without patching natively applied.

    MCP ROUTING TRIGGERS: type_erasure, explicit_override
    """

    class TypelessData(BaseModel):
        output: str

    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        payload = {"type": "should_be_deleted", "output": "valid_output"}
        return json.dumps(payload), {}, []

    res, _ = await UniversalCompiler.validate_and_retry(TypelessData, mock_llm, "test", max_attempts=1)
    assert not hasattr(res, "type")


@pytest.mark.asyncio
async def test_compiler_fallback_on_failure() -> None:
    """
    AGENT INSTRUCTION: Confirms pure python object translation safely isolates data blocks internally upon failure fallback mode.

    CAUSAL AFFORDANCE: Allows parsing loops to abandon schemas safely returning dictionary structures natively.

    EPISTEMIC BOUNDS: Structural isolation verification.

    MCP ROUTING TRIGGERS: parsing_loop_abandonment, structural_isolation
    """

    class StrictModel(BaseModel):
        must_have: str

    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return '{"missing_must_have": true}', {}, []

    res, _ = await UniversalCompiler.validate_and_retry(
        StrictModel, mock_llm, "test", max_attempts=1, fallback_on_failure=True, self_correction=False
    )
    assert isinstance(res, dict)
    assert res["missing_must_have"] is True


@pytest.mark.asyncio
async def test_compiler_macro_neurosymbolic_rules() -> None:
    """
    AGENT INSTRUCTION: Proves symbolic macro failures successfully propagate out natively.

    CAUSAL AFFORDANCE: Forbids nested neurosymbolic processing if fundamental structure bounds fail constraints.

    EPISTEMIC BOUNDS: Evaluates the topology hint natively.

    MCP ROUTING TRIGGERS: neurosymbolic_failure, constraint_propagation
    """

    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return '{"genesis_provenance": {"derivation_mode": "direct_translation"}}', {}, []

    with pytest.raises(ValueError, match=r".*"):
        await UniversalCompiler.synthesize_manifest("test", mock_llm, mock_llm, topology_hint="macro_neurosymbolic")


@pytest.mark.asyncio
async def test_compiler_template_hint_non_dict() -> None:
    """
    AGENT INSTRUCTION: Proves inline monkeypatch replacement bounds behave properly rejecting non-dict types organically natively.

    CAUSAL AFFORDANCE: Limits edge case injection securely natively inside bounds generation.

    EPISTEMIC BOUNDS: Natively reassigns Python properties.

    MCP ROUTING TRIGGERS: strict_typing, rejection_bounds
    """

    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return '{"genesis_provenance": {"derivation_mode": "direct_translation"}}', {}, []

    original_extract = UniversalCompiler.extract_type_hints
    try:
        UniversalCompiler.extract_type_hints = staticmethod(lambda *a, **k: "string_prop")  # type: ignore
        with pytest.raises(ValueError):
            await UniversalCompiler.synthesize_manifest("test", mock_llm, mock_llm, topology_hint="macro_forge")

        UniversalCompiler.extract_type_hints = staticmethod(lambda *a, **k: {"key1": "string_val"})  # type: ignore
        with pytest.raises(ValueError):
            await UniversalCompiler.synthesize_manifest("test", mock_llm, mock_llm, topology_hint="macro_forge")
    finally:
        UniversalCompiler.extract_type_hints = staticmethod(original_extract)  # type: ignore


@pytest.mark.asyncio
async def test_compiler_unreachable_and_literal_eval_tuple() -> None:
    """
    AGENT INSTRUCTION: Corrects json decode traces into literal extraction routines reliably naturally.

    CAUSAL AFFORDANCE: Replaces strictly json payloads failing gracefully into ast tuple parsing logic gracefully bounds.

    EPISTEMIC BOUNDS: Explicit literal string checks natively.

    MCP ROUTING TRIGGERS: ast_extraction, gracefully_parsing, decode_bounds
    """

    async def mock_llm(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return "{}", {}, []

    with pytest.raises(ValueError, match="Unreachable"):
        await UniversalCompiler.validate_and_retry(DummyManifest, mock_llm, "test", max_attempts=0)

    async def mock_llm_tuple(*_a: Any, **_kw: Any) -> tuple[str, dict[str, Any], list[float]]:
        return "```json\n{'topology_class': 'dummy', 'nodes': {}, 'edges': [('nodeA', 'nodeB', 0.5)]}\n```", {}, []

    res, _ = await UniversalCompiler.validate_and_retry(DummyManifest, mock_llm_tuple, "test", max_attempts=1)
    assert res.edges is not None
    assert ("nodeA", "nodeB") in res.edges
