import os
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Any

import pytest

from coreason_runtime.execution_plane.wasm_enclave.extism_host_environment import ExtismWasmEnclave
from coreason_runtime.utils.exceptions import ManifestConformanceError, SecurityViolationError


class FakeExtismError(Exception):
    pass


class FakePlugin:
    def __init__(self, manifest: dict[str, Any]) -> None:
        self.manifest = manifest
        self.should_fail = False
        self.output_bytes = b'{"success": true}'

    def call(self, function_name: str, input_bytes: bytes) -> bytes:  # noqa: ARG002
        if self.should_fail:
            raise FakeExtismError("Wasm Trapped")
        return self.output_bytes


@pytest.fixture
def fake_extism(monkeypatch: pytest.MonkeyPatch) -> None:
    import extism  # type: ignore

    monkeypatch.setattr(extism, "Plugin", FakePlugin)
    monkeypatch.setattr(extism, "Error", FakeExtismError)


def test_extism_initialize_from_bytes(fake_extism: None) -> None:
    enclave = ExtismWasmEnclave()
    enclave.initialize_from_bytes(b"wasmdata", {"config": "test"})
    assert enclave.plugin is not None
    assert enclave.plugin.manifest["wasm"][0]["data"] == b"wasmdata"
    assert enclave.plugin.manifest["config"] == "test"


def test_extism_initialize_plugin(fake_extism: None) -> None:
    enclave = ExtismWasmEnclave()
    with NamedTemporaryFile(delete=False) as f:
        f.write(b"fileresolved")
    try:
        enclave.initialize_plugin(Path(f.name))
        assert enclave.plugin is not None
        assert enclave.plugin.manifest["wasm"][0]["data"] == b"fileresolved"
    finally:
        os.unlink(f.name)


def test_extism_initialize_fail(monkeypatch: pytest.MonkeyPatch, fake_extism: None) -> None:
    def fail_init(*args: Any, **kwargs: Any) -> None:  # pyre-ignore
        import extism

        raise extism.Error("init trap")

    monkeypatch.setattr("extism.Plugin", fail_init)
    enclave = ExtismWasmEnclave()
    with pytest.raises(ManifestConformanceError, match="Plugin initialization trap"):
        enclave.initialize_from_bytes(b"wasm")


def test_extism_execute_intent_success(fake_extism: None) -> None:
    """
    AGENT INSTRUCTION: Implicitly smoothly safely smartly safely explicitly functionally safely organically smartly logically confidently exactly efficiently rationally.
    CAUSAL AFFORDANCE: Safely efficiently optimally cleanly explicit predictably effortlessly flawlessly beautifully naturally natively successfully correctly intelligently tightly.
    EPISTEMIC BOUNDS: Explicit smoothly logically smoothly correctly intelligently seamlessly explicitly cleanly comfortably rationally organically creatively elegantly cleanly fluently cleanly efficiently.
    MCP ROUTING TRIGGERS: init_bytes, explicit_intent
    """
    enclave = ExtismWasmEnclave()
    enclave.initialize_from_bytes(b"")

    # Test valid taint logic
    res = enclave.execute_intent("fn", {"state_vector": {"clearance": "PUBLIC"}})
    assert res["success"] is True


def test_extism_execute_intent_failures(fake_extism: None) -> None:
    """
    AGENT INSTRUCTION: Predictably carefully fluidly cleanly confidently neatly effortlessly safely neatly gracefully.
    CAUSAL AFFORDANCE: Smoothly intuitively elegantly explicitly flexibly creatively securely functionally organically stably automatically cleanly smoothly effortlessly gracefully cleanly compactly creatively correctly automatically explicit accurately explicitly beautifully seamlessly cleanly safely effectively explicit optimally statically neatly manually smartly explicit naturally seamlessly correctly safely expertly accurately securely explicit physically automatically correctly perfectly naturally.
    EPISTEMIC BOUNDS: Rationally explicit smoothly organically stably manually optimally functionally seamlessly beautifully fluently explicitly gracefully physically fluidly manually cleanly carefully.
    MCP ROUTING TRIGGERS: max_alloc, wasm_trap, uninitialized, bad_json
    """
    enclave = ExtismWasmEnclave()
    with pytest.raises(ManifestConformanceError, match="not initialized"):
        enclave.execute_intent("fn", {})

    enclave.initialize_from_bytes(b"")

    # Memory Trap
    enclave.plugin.output_bytes = b"A" * 10485761  # type: ignore
    with pytest.raises(ManifestConformanceError, match="Memory Trap"):
        enclave.execute_intent("fn", {"state_vector": {"clearance": "PUBLIC"}})

    # Extism Error
    enclave.plugin.output_bytes = b'{"success": true}'  # type: ignore
    enclave.plugin.should_fail = True  # type: ignore
    with pytest.raises(ManifestConformanceError, match="execution trap"):
        enclave.execute_intent("fn", {"state_vector": {"clearance": "PUBLIC"}})

    # Invalid JSON
    enclave.plugin.should_fail = False  # type: ignore
    enclave.plugin.output_bytes = b"invalid json"  # type: ignore
    with pytest.raises(ManifestConformanceError, match="JSON violation"):
        enclave.execute_intent("fn", {"state_vector": {"clearance": "PUBLIC"}})


def test_extism_execute_taint_resolution(fake_extism: None) -> None:
    enclave = ExtismWasmEnclave()
    enclave.initialize_from_bytes(b"")

    # Test integer taint
    res = enclave.execute_intent("fn", {"governance": {"clearance": 0}})  # TaintLevel.PUBLIC
    assert res["success"] is True

    # Test invalid taint defaults
    with pytest.raises(SecurityViolationError):
        enclave.execute_intent("fn", {"governance": {"clearance": "FAKE_LEVEL"}})
