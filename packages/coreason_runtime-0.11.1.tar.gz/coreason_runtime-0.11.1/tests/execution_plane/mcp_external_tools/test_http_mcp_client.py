# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from coreason_runtime.execution_plane.mcp_external_tools.http_mcp_client import HttpMCPClient


@pytest.fixture
def test_manifest() -> None:
    manifest_mock = MagicMock()
    manifest_mock.transport.uri = "http://127.0.0.1:8080/mcp"
    manifest_mock.transport.headers = {}
    manifest_mock.capability_whitelist = None
    return manifest_mock  # type: ignore


@pytest.mark.asyncio
async def test_ssrf_blocks_localhost(test_manifest) -> None:  # type: ignore
    client = HttpMCPClient(test_manifest)

    with patch("socket.gethostbyname", return_value="127.0.0.1"):
        with pytest.raises(RuntimeError, match="SSRF Protection: Invalid target URI."):
            await client.request("test_method")


@pytest.mark.asyncio
async def test_ssrf_blocks_aws_metadata(test_manifest) -> None:  # type: ignore
    test_manifest.transport.uri = "http://169.254.169.254/latest/meta-data/"
    client = HttpMCPClient(test_manifest)

    with patch("socket.gethostbyname", return_value="169.254.169.254"):
        with pytest.raises(RuntimeError, match="SSRF Protection: Invalid target URI."):
            await client.request("test_method")


@pytest.mark.asyncio
async def test_ssrf_allows_public_internet(test_manifest) -> None:  # type: ignore
    test_manifest.transport.uri = "https://api.openai.com/v1"
    client = HttpMCPClient(test_manifest)

    with patch("socket.gethostbyname", return_value="8.8.8.8"):
        with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
            mock_response = MagicMock()
            mock_response.json.return_value = {"result": {"success": True}}
            mock_post.return_value = mock_response

            res = await client.request("test_method")
            assert res == {"success": True}
