# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from coreason_runtime.execution_plane.discovery_indexer import DiscoveryIndexer


def test_discovery_no_model() -> None:
    with patch("lancedb.embeddings.get_registry", side_effect=Exception("mocked err")):
        with pytest.raises(RuntimeError, match="Missing LanceDB"):
            import importlib

            import coreason_runtime.execution_plane.discovery_indexer

            importlib.reload(coreason_runtime.execution_plane.discovery_indexer)


def test_discovery_indexer_sync_wasm() -> None:
    with patch("coreason_runtime.execution_plane.discovery_indexer.lancedb.connect") as mock_conn:
        mock_db = MagicMock()
        mock_conn.return_value = mock_db
        mock_db.table_names.return_value = ["capabilities"]
        mock_table = MagicMock()
        mock_db.open_table.return_value = mock_table

        indexer = DiscoveryIndexer("/tmp/mock_db")

        with patch.object(indexer, "_create_document", side_effect=Exception("Doc fail")):
            with patch("coreason_runtime.execution_plane.discovery_indexer.Path.rglob") as mock_rglob:
                from pathlib import Path

                m_path = MagicMock(spec=Path)
                m_path.exists.return_value = True

                m_json = MagicMock()
                m_json.stem = "test"
                mock_rglob.return_value = [m_json]

                with patch("builtins.open"), patch("json.load", return_value={"name": "test"}):
                    with patch(
                        "coreason_runtime.execution_plane.discovery_indexer.Path.exists",
                        side_effect=[False, True, True, True],
                    ):
                        indexer.sync_local_wasm()


@pytest.mark.asyncio
async def test_discovery_indexer_sync_mcp() -> None:
    with patch("coreason_runtime.execution_plane.discovery_indexer.lancedb.connect") as mock_conn:
        mock_db = MagicMock()
        mock_conn.return_value = mock_db
        mock_db.table_names.return_value = []
        mock_table = MagicMock()
        mock_db.create_table.return_value = mock_table

        indexer = DiscoveryIndexer()

        class MockMgr:
            def __init__(self):  # type: ignore
                mock_c = AsyncMock()
                mock_c.request.return_value = {"tools": [{"name": "fake", "description": "d", "inputSchema": {}}]}
                self.clients = {"server1": mock_c}

        await indexer.sync_remote_mcp(MockMgr())  # type: ignore
        mock_table.add.assert_called()

        class MockMgrNoLookup:
            pass

        assert await indexer.sync_remote_mcp(MockMgrNoLookup()) == 0

        class MockMgrErr:
            def __init__(self):  # type: ignore
                mock_c = AsyncMock()
                mock_c.request.side_effect = Exception("failed net")
                self.clients = {"server1": mock_c}

        await indexer.sync_remote_mcp(MockMgrErr())  # type: ignore


def test_search_capabilities() -> None:
    with patch("coreason_runtime.execution_plane.discovery_indexer.lancedb.connect") as mock_conn:
        mock_db = MagicMock()
        mock_conn.return_value = mock_db
        mock_db.table_names.return_value = ["capabilities"]
        mock_table = MagicMock()
        mock_db.open_table.return_value = mock_table

        mock_search = MagicMock()
        mock_limit = MagicMock()
        mock_table.search.return_value = mock_search
        mock_search.limit.return_value = mock_limit
        mock_limit.to_list.return_value = [
            {
                "capability_id": "test_cap",
                "description": "test_desc",
                "input_schema": '{"type": "object"}',
                "_distance": 0.5,
            }
        ]

        indexer = DiscoveryIndexer("/tmp/mock_db")
        results = indexer.search_capabilities("test_query", limit=1)

        assert len(results) == 1
        assert results[0]["name"] == "test_cap"
        assert results[0]["distance"] == 0.5
        assert results[0]["inputSchema"] == {"type": "object"}
