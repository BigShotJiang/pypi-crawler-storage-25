# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from typing import Any, cast

import pytest
from coreason_manifest.spec.ontology import (
    CognitiveActionSpaceManifest,
    DynamicManifoldProjectionManifest,
    GrammarPanelProfile,
    KineticSeparationPolicy,
    MCPClientIntent,
    MCPServerManifest,
    PermissionBoundaryPolicy,
    SemanticZoomProfile,
    SideEffectProfile,
    SpatialToolManifest,
    TransitionEdgeProfile,
)
from hypothesis import given
from hypothesis import strategies as st
from temporalio.exceptions import ApplicationError

from coreason_runtime.execution_plane.capability_allocator import build_extism_manifest
from coreason_runtime.execution_plane.topological_enforcer import TopologicalEnforcer

# Use explicit instantiations mapped from hypothesis primitive values
# to avoid Pydantic 2 deep constraint bugs in hypothesis builds()


@st.composite
def dynamic_projection_generator(draw: Any) -> DynamicManifoldProjectionManifest:
    return DynamicManifoldProjectionManifest(
        manifest_cid=draw(st.text(min_size=1, max_size=12, alphabet="abcdefghijklmnopqrstuvwxyz_-")),
        active_forge_cid=draw(st.text(min_size=1, max_size=12, alphabet="abcdefghijklmnopqrstuvwxyz_-")),
        ast_gradient_visual_mapping=GrammarPanelProfile(
            panel_cid="p1", title="t1", ledger_source_cid="l1", mark="bar", encodings=[]
        ),
        thermodynamic_burn_mapping=GrammarPanelProfile(
            panel_cid="p2", title="t2", ledger_source_cid="l2", mark="line", encodings=[]
        ),
        viewport_zoom_profile=SemanticZoomProfile(
            micro_distance_threshold=0.5,
            meso_distance_threshold=2.0,
            macro_distance_threshold=10.0,
        ),
    )


def dummy_spatial_tool(name: str) -> SpatialToolManifest:
    return SpatialToolManifest(
        tool_name=name,
        description="A deterministic spatial capability test.",
        input_schema={},
        side_effects=SideEffectProfile(is_idempotent=True, mutates_state=False),
        permissions=PermissionBoundaryPolicy(network_access=False, file_system_mutation_forbidden=True),
    )


@given(projection=dynamic_projection_generator())
def test_build_extism_manifest_default_posture(projection: DynamicManifoldProjectionManifest) -> None:
    intent = MCPClientIntent(
        jsonrpc="2.0", method="mcp.ui.emit_intent", id="123", params=None, holographic_projection=projection
    )
    manifest = build_extism_manifest(intent)

    assert manifest["allowed_hosts"] == []
    assert manifest["allowed_paths"] == {}


def test_build_extism_manifest_dict_input() -> None:
    intent = {"params": {"allowed_hosts": ["test.com"]}}
    manifest = build_extism_manifest(intent)
    assert manifest["allowed_hosts"] == ["test.com"]


def test_build_extism_manifest_none_input() -> None:
    intent = None
    manifest = build_extism_manifest(intent)
    assert manifest["allowed_hosts"] == []


@given(projection=dynamic_projection_generator())
def test_build_extism_manifest_with_params(projection: DynamicManifoldProjectionManifest) -> None:
    intent = MCPClientIntent(
        jsonrpc="2.0",
        method="mcp.ui.emit_intent",
        id="123",
        params={
            "allowed_hosts": ["api.example.com", "api.github.com"],
            "allowed_paths": {"/opt/coreason/foo": "/data"},
        },
        holographic_projection=projection,
    )
    manifest = build_extism_manifest(intent)

    assert manifest["allowed_hosts"] == ["api.example.com", "api.github.com"]
    assert manifest["allowed_paths"] == {"/opt/coreason/foo": "/data"}


@given(projection=dynamic_projection_generator())
def test_build_extism_manifest_with_invalid_params(projection: DynamicManifoldProjectionManifest) -> None:
    intent = MCPClientIntent(
        jsonrpc="2.0",
        method="mcp.ui.emit_intent",
        id="123",
        params={
            "allowed_hosts": "api.example.com",  # Should be list
            "allowed_paths": ["/opt/coreason/foo"],  # Should be dict
        },
        holographic_projection=projection,
    )
    manifest = build_extism_manifest(intent)

    # Should safely fallback to empty due to type checks
    assert manifest["allowed_hosts"] == []
    assert manifest["allowed_paths"] == {}


@given(action_cid=st.text(min_size=1, max_size=12, alphabet="abcdefghijklmnopqrstuvwxyz_-.0123456789"))
def test_topological_enforcer_validate_kinetic_separation(action_cid: str) -> None:
    policy = KineticSeparationPolicy(
        policy_cid="strict", mutually_exclusive_clusters=[["toolB", "toolC"]], enforcement_action="halt_and_quarantine"
    )
    manifest = CognitiveActionSpaceManifest(
        action_space_cid=action_cid,
        entry_point_cid="toolA",
        capabilities={"toolA": dummy_spatial_tool("toolA")},
        transition_matrix={"toolA": []},
        kinetic_separation=policy,
    )
    enforcer = TopologicalEnforcer(manifest)

    enforcer.validate_kinetic_separation("toolB", ["toolA"])

    with pytest.raises(ApplicationError, match="Bipartite violation"):
        enforcer.validate_kinetic_separation("toolC", ["toolA", "toolB"])


def test_topological_enforcer_validate_mdp_transition() -> None:
    edge1 = TransitionEdgeProfile(target_node_cid="toolB", compute_weight_magnitude=10, probability_weight=1.0)
    edge2 = TransitionEdgeProfile(target_node_cid="toolB", compute_weight_magnitude=5, probability_weight=1.0)

    manifest = CognitiveActionSpaceManifest(
        action_space_cid="test_space",
        entry_point_cid="toolA",
        capabilities={"toolA": dummy_spatial_tool("toolA"), "toolB": dummy_spatial_tool("toolB")},
        transition_matrix={"toolA": [edge1]},
    )
    enforcer = TopologicalEnforcer(manifest)

    # Test Missing Capability
    with pytest.raises(ApplicationError, match="Capability violation"):
        enforcer.validate_mdp_transition("toolC", [], 100.0)

    # Test Genesis
    with pytest.raises(ApplicationError, match="Genesis violation"):
        enforcer.validate_mdp_transition("toolB", [], 100.0)
    assert enforcer.validate_mdp_transition("toolA", [], 100.0) == 100.0

    # Test Edge Traversal Happy Path
    assert enforcer.validate_mdp_transition("toolB", ["toolA"], 100.0) == 90.0

    # Test Ghost Path
    with pytest.raises(ApplicationError, match="Ghost Path violation"):
        enforcer.validate_mdp_transition("toolA", ["toolB"], 100.0)

    # Test Thermodynamic Exhaustion
    with pytest.raises(ApplicationError, match="Thermodynamic exhaustion"):
        enforcer.validate_mdp_transition("toolB", ["toolA"], 5.0)

    manifest.transition_matrix["toolA"] = [edge2]
    enforcer = TopologicalEnforcer(manifest)
    assert enforcer.validate_mdp_transition("toolB", ["toolA"], 100.0) == 95.0

    # Test Thermodynamic Discounting (Covers Line 101 natively)
    edge3 = TransitionEdgeProfile(target_node_cid="toolB", compute_weight_magnitude=10, probability_weight=1.0)
    edge3.__dict__["discount_factor"] = 0.9
    manifest.transition_matrix["toolA"] = [edge3]
    enforcer = TopologicalEnforcer(manifest)
    assert enforcer.validate_mdp_transition("toolB", ["toolA"], 100.0) == 80.0


@given(projection=dynamic_projection_generator())
def test_build_extism_manifest_missing_capabilities(projection: DynamicManifoldProjectionManifest) -> None:
    intent = MCPClientIntent(
        jsonrpc="2.0",
        method="mcp.ui.emit_intent",
        id="123",
        params={
            "allowed_hosts": ["missing_capabilities_test"],
        },
        holographic_projection=projection,
    )
    manifest = build_extism_manifest(intent)
    assert "missing_capabilities_test" in manifest["allowed_hosts"]


def test_build_extism_manifest_payload_attack() -> None:
    from coreason_runtime.utils.exceptions import PayloadTooLargeError

    with pytest.raises(PayloadTooLargeError):
        build_extism_manifest({"params": {"allowed_hosts": ["A" * 2000000]}})

    with pytest.raises(PayloadTooLargeError):
        build_extism_manifest({"params": {"allowed_paths": {"/a": "A" * 2000000}}})


def test_dynamic_capability_injection() -> None:
    from coreason_runtime.execution_plane.capability_allocator import dynamic_capability_injection

    action_space = CognitiveActionSpaceManifest(
        action_space_cid="test_space",
        entry_point_cid="test",
        capabilities={"test": dummy_spatial_tool("test")},
        transition_matrix={"test": []},
    )
    updated_space = dynamic_capability_injection(action_space, {"name": "test_cap", "binary_hash": "a" * 64})
    assert "test_cap" in updated_space.capabilities
    assert cast("MCPServerManifest", updated_space.capabilities["test_cap"]).server_cid == "dynamic_mcp_pool"
