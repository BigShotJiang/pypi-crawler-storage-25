import asyncio
import json
from typing import Any
from unittest.mock import MagicMock

import pytest

from coreason_runtime.execution_plane.mcp_external_tools.sse_mcp_client import SSEMCPClient


class DummyTransport:
    uri = "http://fake"
    headers = {"X": "Y"}  # noqa: RUF012


class DummyWhitelist:
    allowed_tools = ["allowed_tool"]  # noqa: RUF012


class DummyManifest:
    transport = DummyTransport()
    capability_whitelist = DummyWhitelist()


@pytest.mark.asyncio
async def test_sse_mcp_client_happy_path(monkeypatch: pytest.MonkeyPatch) -> None:
    """Validates the standard execution path of the SSEMCPClient including SSE network streaming and payload exchange."""
    manifest = DummyManifest()
    client = SSEMCPClient(manifest)  # type: ignore

    class FakeResponse:
        def raise_for_status(self) -> None:
            pass

        async def aiter_lines(self):  # type: ignore
            # stream SSE events
            yield "event: endpoint"
            yield "data: /post_here"
            yield ""
            while 1 not in client._pending_requests:
                await asyncio.sleep(0.01)
            yield "event: message"
            yield "data: " + json.dumps({"id": 1, "result": {"success": 42}})
            yield ""
            while True:
                await asyncio.sleep(1)

    class FakeStream:
        async def __aenter__(self) -> Any:
            return FakeResponse()

        async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
            pass

    class FakeAsyncClient:
        def stream(self, method: str, url: str, headers: dict[str, Any]) -> FakeStream:  # noqa: ARG002
            return FakeStream()

        async def post(self, url: str, json: dict[str, Any], headers: dict[str, Any]) -> Any:  # noqa: ARG002
            resp = MagicMock()
            resp.raise_for_status = lambda: None
            return resp

        async def aclose(self) -> None:
            pass

    monkeypatch.setattr("httpx.AsyncClient", lambda: FakeAsyncClient())

    res = await client.request("tools/call", {"name": "allowed_tool"})
    assert res["success"] == 42


@pytest.mark.asyncio
async def test_sse_mcp_client_ocap_violation() -> None:
    """Validates that capability whitelists strictly block unauthorized external tool invocations over HTTP."""
    manifest = DummyManifest()
    client = SSEMCPClient(manifest)  # type: ignore
    with pytest.raises(RuntimeError, match="OCap Violation"):
        await client.request("tools/call", {"name": "evil_tool"})


@pytest.mark.asyncio
async def test_sse_mcp_client_connection_error(monkeypatch: pytest.MonkeyPatch) -> None:
    """Validates endpoint resolution failures gracefully fallback over uninitialized streams."""

    class FailClient:
        def stream(self, *_args: Any, **_kwargs: Any) -> Any:
            raise ValueError("Network Down")

        async def aclose(self) -> None:
            pass

    monkeypatch.setattr("httpx.AsyncClient", lambda: FailClient())
    manifest = DummyManifest()
    client = SSEMCPClient(manifest)  # type: ignore

    with pytest.raises(RuntimeError, match="Failed to receive POST endpoint from SSE stream."):
        await client.request("method")


@pytest.mark.asyncio
async def test_sse_mcp_client_jsonrpc_error(monkeypatch: pytest.MonkeyPatch) -> None:
    """Validates mapping of JSON-RPC protocol errors inside SSE event streams (Lines 112-114)."""
    manifest = DummyManifest()
    client = SSEMCPClient(manifest)  # type: ignore

    class FakeResponse:
        def raise_for_status(self) -> None:
            pass

        async def aiter_lines(self) -> Any:
            yield "event: endpoint"
            yield "data: /post_here"
            yield ""
            while 1 not in client._pending_requests:
                await asyncio.sleep(0.01)
            yield "event: message"
            yield "data: " + json.dumps({"id": 1, "error": "Internal Error"})
            yield ""
            while True:
                await asyncio.sleep(1)

    class FakeStream:
        async def __aenter__(self) -> Any:
            return FakeResponse()

        async def __aexit__(self, *args: Any) -> None:
            pass

    class FakeAsyncClient:
        def stream(self, *_args: Any, **_kwargs: Any) -> Any:
            return FakeStream()

        async def post(self, *_args: Any, **_kwargs: Any) -> Any:
            resp = MagicMock()
            resp.raise_for_status = lambda: None
            return resp

        async def aclose(self) -> None:
            pass

    monkeypatch.setattr("httpx.AsyncClient", lambda: FakeAsyncClient())

    with pytest.raises(RuntimeError, match="JSON-RPC Error: Internal Error"):
        await client.request("tools/call", {"name": "allowed_tool"})


@pytest.mark.asyncio
async def test_sse_mcp_client_decode_error(monkeypatch: pytest.MonkeyPatch) -> None:
    """Validates that malformed JSON payloads in SSE events trigger silent continuation (Lines 119-120)."""
    manifest = DummyManifest()
    client = SSEMCPClient(manifest)  # type: ignore

    class FakeResponse:
        def raise_for_status(self) -> None:
            pass

        async def aiter_lines(self) -> Any:
            yield "event: endpoint"
            yield "data: /post_here"
            yield ""
            while 1 not in client._pending_requests:
                await asyncio.sleep(0.01)
            yield "event: message"
            yield "data: {definitely-not-valid-json"
            yield ""
            yield "event: message"
            yield "data: " + json.dumps({"id": 1, "result": {"success": 42}})
            yield ""
            while True:
                await asyncio.sleep(1)

    class FakeStream:
        async def __aenter__(self) -> Any:
            return FakeResponse()

        async def __aexit__(self, *args: Any) -> None:
            pass

    class FakeAsyncClient:
        def stream(self, *_args: Any, **_kwargs: Any) -> Any:
            return FakeStream()

        async def post(self, *_args: Any, **_kwargs: Any) -> Any:
            resp = MagicMock()
            resp.raise_for_status = lambda: None
            return resp

        async def aclose(self) -> None:
            pass

    monkeypatch.setattr("httpx.AsyncClient", lambda: FakeAsyncClient())

    res = await client.request("tools/call", {"name": "allowed_tool"})
    assert res["success"] == 42


@pytest.mark.asyncio
async def test_sse_mcp_client_post_failure(monkeypatch: pytest.MonkeyPatch) -> None:
    """Validates HTTP resolution propagation when POST requests fail (Lines 155-159)."""
    manifest = DummyManifest()
    client = SSEMCPClient(manifest)  # type: ignore

    class FakeResponse:
        def raise_for_status(self) -> None:
            pass

        async def aiter_lines(self) -> Any:
            yield "event: endpoint"
            yield "data: post_here_relative"
            yield ""
            while True:
                await asyncio.sleep(1)

    class FakeStream:
        async def __aenter__(self) -> Any:
            return FakeResponse()

        async def __aexit__(self, *args: Any) -> None:
            pass

    class FakeAsyncClient:
        def stream(self, *_args: Any, **_kwargs: Any) -> Any:
            return FakeStream()

        async def post(self, *_args: Any, **_kwargs: Any) -> Any:
            raise ValueError("HTTP Down")

        async def aclose(self) -> None:
            pass

    monkeypatch.setattr("httpx.AsyncClient", lambda: FakeAsyncClient())

    with pytest.raises(RuntimeError, match="Failed to post JSON-RPC request to SSE endpoint: HTTP Down"):
        await client.request("tools/call", {"name": "allowed_tool"})


@pytest.mark.asyncio
async def test_sse_mcp_client_read_loop_termination(monkeypatch: pytest.MonkeyPatch) -> None:
    """Validates automatic pending request rejection when the SSE loop disconnects inherently (Line 92)."""
    manifest = DummyManifest()
    client = SSEMCPClient(manifest)  # type: ignore

    class FakeResponse:
        def raise_for_status(self) -> None:
            pass

        async def aiter_lines(self) -> Any:
            yield "event: endpoint"
            yield "data: http://post_here"
            yield ""
            while 1 not in client._pending_requests:
                await asyncio.sleep(0.01)
            # End the stream immediately
            return

    class FakeStream:
        async def __aenter__(self) -> Any:
            return FakeResponse()

        async def __aexit__(self, *args: Any) -> None:
            pass

    class FakeAsyncClient:
        def stream(self, *_args: Any, **_kwargs: Any) -> Any:
            return FakeStream()

        async def post(self, *_args: Any, **_kwargs: Any) -> Any:
            resp = MagicMock()
            resp.raise_for_status = lambda: None
            return resp

        async def aclose(self) -> None:
            pass

    monkeypatch.setattr("httpx.AsyncClient", lambda: FakeAsyncClient())

    with pytest.raises(RuntimeError, match="SSE connection closed"):
        await client.request("tools/call", {"name": "allowed_tool"})
