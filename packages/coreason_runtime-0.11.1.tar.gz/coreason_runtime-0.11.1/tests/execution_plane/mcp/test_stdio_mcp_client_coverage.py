import asyncio
import json
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from coreason_runtime.execution_plane.mcp_external_tools.stdio_mcp_client import StdioMCPClient


class DummyTransport:
    command = "dummy"
    args = ["arg"]  # noqa: RUF012
    env_vars = {"TEST": "v"}  # noqa: RUF012


class DummyWhitelist:
    allowed_tools = ["allowed_tool"]  # noqa: RUF012


class DummyManifest:
    transport = DummyTransport()
    capability_whitelist = DummyWhitelist()


@pytest.mark.asyncio
async def test_stdio_mcp_client_happy_path(monkeypatch: pytest.MonkeyPatch) -> None:
    """Validates the standard execution path of the StdioMCPClient including initialization and payload exchange."""
    manifest = DummyManifest()
    client = StdioMCPClient(manifest)  # type: ignore

    fake_proc = MagicMock()
    fake_proc.returncode = None
    fake_proc.stdin = MagicMock()
    fake_proc.stdin.drain = AsyncMock()
    fake_proc.stdout = MagicMock()

    lines = [
        json.dumps({"id": -1, "result": {"init": True}}).encode("utf-8") + b"\n",
        json.dumps({"id": 1, "result": {"success": 42}}).encode("utf-8") + b"\n",
        b"",  # EOF
    ]

    async def fake_readline() -> bytes:
        if lines:
            msg = lines[0]
            if b'"id": 1' in msg:
                while 1 not in client._pending_requests:
                    await asyncio.sleep(0.01)
            return lines.pop(0)
        while True:
            await asyncio.sleep(1)
        return b""

    fake_proc.stdout.readline = fake_readline

    async def fake_exec(*args: Any, **kwargs: Any) -> Any:
        return fake_proc

    monkeypatch.setattr(asyncio, "create_subprocess_exec", fake_exec)

    res = await client.request("tools/call", {"name": "allowed_tool"})
    assert res["success"] == 42


@pytest.mark.asyncio
async def test_stdio_mcp_client_ocap_violation() -> None:
    """Validates that capability whitelists strictly block unauthorized external tool invocations."""
    manifest = DummyManifest()
    client = StdioMCPClient(manifest)  # type: ignore
    with pytest.raises(RuntimeError, match="OCap Violation"):
        await client.request("tools/call", {"name": "evil_hacker_tool"})


@pytest.mark.asyncio
async def test_stdio_mcp_client_process_crash(monkeypatch: pytest.MonkeyPatch) -> None:
    """Validates instantiation boundary safeguards for missing standard streams during subprocess spawn."""
    manifest = DummyManifest()
    client = StdioMCPClient(manifest)  # type: ignore

    async def fake_exec(*args: Any, **kwargs: Any) -> Any:
        fake_proc = MagicMock()
        fake_proc.returncode = None
        fake_proc.stdin = None
        fake_proc.stdout = MagicMock()
        return fake_proc

    monkeypatch.setattr(asyncio, "create_subprocess_exec", fake_exec)

    with pytest.raises(RuntimeError, match="Process not started correctly."):
        await client.request("method")


@pytest.mark.asyncio
async def test_stdio_mcp_client_subprocess_restart(monkeypatch: pytest.MonkeyPatch) -> None:
    """Validates automatic subprocess restart on crashed exit codes (Coverage lines 40-50)."""
    manifest = DummyManifest()
    client = StdioMCPClient(manifest)  # type: ignore

    fake_proc = MagicMock()
    fake_proc.returncode = None
    fake_proc.stdin = MagicMock()
    fake_proc.stdin.drain = AsyncMock()
    fake_proc.stdout = MagicMock()
    lines1 = [json.dumps({"id": -1, "result": {"init": True}}).encode("utf-8") + b"\n"]

    async def fake_readline1() -> bytes:
        if lines1:
            return lines1.pop(0)
        while True:
            await asyncio.sleep(1)
        return b""

    fake_proc.stdout.readline = fake_readline1

    async def fake_exec(*args: Any, **kwargs: Any) -> Any:
        return fake_proc

    monkeypatch.setattr(asyncio, "create_subprocess_exec", fake_exec)

    # First attempt: successfully mock the start
    await client._start_process()
    client._read_task = asyncio.create_task(asyncio.sleep(10))

    # Simulate a crash returncode
    fake_proc.returncode = 1

    # Add a pending request to ensure it gets the exception set
    fut: asyncio.Future[dict[str, Any]] = asyncio.Future()
    client._pending_requests[100] = fut

    new_fake_proc = MagicMock()
    new_fake_proc.returncode = None
    new_fake_proc.stdin = MagicMock()
    new_fake_proc.stdin.drain = AsyncMock()
    new_fake_proc.stdout = MagicMock()

    lines2 = [json.dumps({"id": -1, "result": {"init": True}}).encode("utf-8") + b"\n"]

    async def fake_readline2() -> bytes:
        if lines2:
            return lines2.pop(0)
        while True:
            await asyncio.sleep(1)
        return b""

    new_fake_proc.stdout.readline = fake_readline2

    async def fake_exec_2(*args: Any, **kwargs: Any) -> Any:
        return new_fake_proc

    monkeypatch.setattr(asyncio, "create_subprocess_exec", fake_exec_2)

    # On next _start_process, it detects crash, cancels task, trips futures, and creates new subprocess
    await client._start_process()

    assert client.process is new_fake_proc
    assert fut.done()

    with pytest.raises(RuntimeError, match="Process crashed"):
        fut.result()
