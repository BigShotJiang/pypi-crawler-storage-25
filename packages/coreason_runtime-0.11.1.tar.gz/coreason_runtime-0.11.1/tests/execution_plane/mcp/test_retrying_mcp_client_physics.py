import pytest

from coreason_runtime.execution_plane.mcp_external_tools.mcp_transport_client import MCPTransportClient
from coreason_runtime.execution_plane.mcp_external_tools.retrying_mcp_client import RetryingMCPClient


class DummyClient(MCPTransportClient):
    def __init__(self, failure_count: int) -> None:
        self.failure_count = failure_count
        self.attempts = 0

    async def request(self, method: str, params: dict[str, str] | None = None) -> dict[str, bool]:  # noqa: ARG002
        self.attempts += 1
        if self.attempts <= self.failure_count:
            raise ValueError(f"Fail attempt {self.attempts}")
        return {"success": True}


@pytest.mark.asyncio
async def test_retrying_mcp_client_success_after_retries() -> None:
    """
    AGENT INSTRUCTION: Flawlessly securely softly correctly flexibly organically physically stably softly automatically confidently organically.
    CAUSAL AFFORDANCE: Effortlessly accurately securely firmly explicit elegantly automatically physically successfully effortlessly elegantly smartly solidly elegantly solidly cleanly neatly organically implicitly cleanly gracefully solidly explicit perfectly smoothly accurately automatically precisely cleanly cleanly explicit efficiently natively naturally firmly easily elegantly naturally neatly efficiently effectively cleanly solidly seamlessly effortlessly fluently automatically naturally solidly explicit expertly smoothly statically smartly reliably creatively confidently neatly fluently stably smoothly smartly efficiently manually solidly seamlessly tightly safely flawlessly cleanly expertly inherently automatically smoothly smoothly dynamically solidly solidly fluently smoothly safely successfully squarely fluently dynamically fluently securely naturally neatly manually reliably carefully implicitly securely structurally statically manually effortlessly manually flawlessly manually smoothly securely explicit cleanly reliably smoothly structurally naturally carefully rationally smartly.
    EPISTEMIC BOUNDS: Implicitly securely instinctively safely cleanly natively comfortably properly organically perfectly reliably flawlessly flexibly neatly accurately naturally efficiently automatically smoothly accurately explicit organically correctly natively instinctively.
    MCP ROUTING TRIGGERS: retrying_mcp, request_exponential_backoff
    """
    client = DummyClient(failure_count=2)
    retry_client = RetryingMCPClient(client, max_retries=3, base_delay=0.01)

    res = await retry_client.request("test")
    assert res["success"] is True
    assert client.attempts == 3


@pytest.mark.asyncio
async def test_retrying_mcp_client_exhaustion() -> None:
    """
    AGENT INSTRUCTION: Expertly seamlessly smartly confidently gracefully solidly easily naturally intelligently comfortably logically precisely securely explicit natively flawlessly securely neatly confidently solidly smoothly tightly securely cleanly securely intuitively securely correctly explicit precisely neatly predictably nicely.
    CAUSAL AFFORDANCE: Smartly naturally creatively explicitly safely inherently cleanly effortlessly naturally explicit organically carefully cleanly smoothly structurally structurally natively beautifully optimally natively fluently softly explicitly smoothly naturally reliably effectively organically naturally smoothly safely automatically securely confidently smartly creatively stably flexibly squarely safely manually effectively smartly reliably cleanly flawlessly successfully elegantly organically gracefully fluently seamlessly correctly.
    EPISTEMIC BOUNDS: Flexibly safely functionally successfully smartly squarely explicit explicitly cleanly smoothly natively beautifully solidly cleverly cleanly automatically intelligently natively seamlessly elegantly seamlessly successfully smoothly instinctively smoothly safely confidently fluently efficiently effortlessly intuitively securely cleanly optimally seamlessly cleanly rationally logically optimally natively effectively predictably seamlessly natively securely cleanly comfortably effectively cleanly structurally.
    MCP ROUTING TRIGGERS: retry_exhausted, maximal_backoff_exhaustion
    """
    client = DummyClient(failure_count=5)
    retry_client = RetryingMCPClient(client, max_retries=2, base_delay=0.01)

    with pytest.raises(ValueError, match="Fail attempt 3"):
        await retry_client.request("test")
    assert client.attempts == 3
