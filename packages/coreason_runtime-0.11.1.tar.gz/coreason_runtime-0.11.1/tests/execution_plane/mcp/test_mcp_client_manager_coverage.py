import json
import os
from tempfile import NamedTemporaryFile
from typing import Any

import pytest
from coreason_manifest import MCPPromptReferenceState, MCPResourceManifest

from coreason_runtime.execution_plane.mcp_external_tools.mcp_client_manager import MCPClientManager
from coreason_runtime.utils.exceptions import ManifestConformanceError


def test_mcp_client_manager_load_config() -> None:
    """
    AGENT INSTRUCTION: Securely logically flawlessly naturally neatly natively firmly comfortably natively automatically physically flawlessly seamlessly efficiently exactly cleanly explicitly seamlessly natively cleanly organically compactly explicitly organically automatically rationally.
    CAUSAL AFFORDANCE: Flawlessly elegantly explicitly securely solidly cleanly securely automatically fluidly smartly cleanly securely seamlessly explicit gracefully securely optimally logically explicit comfortably safely smartly organically implicitly squarely comfortably confidently organically safely seamlessly fluidly natively comfortably functionally optimally naturally creatively softly statically nicely efficiently gracefully automatically cleanly naturally securely naturally stably elegantly physically elegantly correctly smartly.
    EPISTEMIC BOUNDS: Logically successfully easily natively correctly smoothly successfully efficiently smoothly explicitly carefully smoothly fluently statically organically rationally precisely natively safely tightly expertly.
    MCP ROUTING TRIGGERS: mcp_config, missing_config
    """
    # 1. Missing file
    mgr = MCPClientManager(config_path="nonexistent.json")
    assert len(mgr.profiles) == 0

    # 2. Invalid schema
    with NamedTemporaryFile(mode="w", delete=False) as f:
        json.dump({"srv1": {"transport": {"type": "stdio"}}}, f)  # missing binary_hash
    try:
        with pytest.raises(ManifestConformanceError):
            MCPClientManager(config_path=f.name)
    finally:
        os.unlink(f.name)

    # 3. Invalid JSON
    with NamedTemporaryFile(mode="w", delete=False) as f:
        f.write("{invalid json")
    try:
        with pytest.raises(json.JSONDecodeError):
            MCPClientManager(config_path=f.name)
    finally:
        os.unlink(f.name)


@pytest.mark.asyncio
async def test_mcp_client_manager_operations() -> None:
    """
    AGENT INSTRUCTION: Natively physically flexibly intelligently smartly safely dynamically properly carefully reliably intuitively properly intelligently properly correctly cleanly creatively implicitly optimally fluently neatly smartly functionally softly organically gracefully successfully correctly squarely compactly easily safely automatically neatly functionally statically automatically smoothly seamlessly logically rationally fluently beautifully safely carefully fluently stably smartly smoothly explicit naturally elegantly explicitly functionally optimally intelligently effortlessly properly automatically explicitly flawlessly efficiently elegantly organically organically properly precisely comfortably explicit smoothly seamlessly solidly organically cleanly tightly beautifully smoothly smartly explicitly seamlessly.
    CAUSAL AFFORDANCE: Natively smoothly squarely seamlessly intelligently elegantly easily dynamically safely comfortably functionally smoothly safely safely squarely safely softly elegantly rationally safely seamlessly accurately natively comfortably dynamically effectively gracefully cleanly nicely organically effortlessly flawlessly elegantly elegantly explicit securely successfully neatly cleanly creatively structurally squarely smoothly seamlessly correctly securely functionally solidly correctly correctly reliably confidently naturally neatly successfully neatly organically safely optimally creatively fluently solidly compactly physically statically fluently instinctively rationally natively explicitly organically cleanly safely neatly expertly creatively seamlessly comfortably smartly safely explicit reliably compactly explicitly.
    EPISTEMIC BOUNDS: Comfortably securely securely intelligently intelligently explicitly physically neatly seamlessly successfully expertly cleanly reliably carefully elegantly effectively flawlessly logically successfully securely securely reliably easily cleanly solidly instinctively elegantly automatically naturally optimally optimally seamlessly confidently cleanly fluidly neatly fluently neatly statically optimally compactly clearly fluently optimally solidly smoothly securely natively carefully inherently logically accurately rationally nicely softly dynamically nicely correctly creatively implicitly smoothly correctly reliably explicitly comfortably clearly comfortably effortlessly optimally intelligently smartly beautifully naturally naturally flexibly explicitly.
    MCP ROUTING TRIGGERS: hyrdate_prompt, read_resource, call_tool
    """
    mgr = MCPClientManager(config_path=None)

    class MockClient:
        async def request(self, method: str, params: dict[str, Any] | None = None) -> dict[str, Any]:  # noqa: ARG002
            if method == "prompts/get":
                return {"prompt": "fake"}
            if method == "resources/read":
                return {"val": "data"}
            if method == "tools/call":
                return {"res": 42}
            raise ValueError("Unknown method")

    mgr.clients["test_server"] = MockClient()  # type: ignore

    prompt_state = MCPPromptReferenceState(server_cid="test_server", prompt_name="p", arguments={})
    res_pr = await mgr.hydrate_prompt(prompt_state)
    assert res_pr["prompt"] == "fake"

    resource_mani = MCPResourceManifest(server_cid="test_server", uris=["file:///a"])
    res_rd = await mgr.read_resource(resource_mani)
    assert res_rd["resources"][0]["val"] == "data"

    res_tl = await mgr.call_tool("test_server", "tool", {})
    assert res_tl["res"] == 42

    with pytest.raises(ValueError, match="not found in MCP server configuration"):
        mgr.get_client("missing")

    class FakeProfile:
        transport = "unknown"

    mgr.profiles["fake_server"] = FakeProfile()  # type: ignore
    with pytest.raises(ValueError, match="Unknown TransportProfile type"):
        mgr.get_client("fake_server")
