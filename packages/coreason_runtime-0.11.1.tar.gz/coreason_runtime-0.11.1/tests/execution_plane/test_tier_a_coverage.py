# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Phase 3 Tier A coverage tests — trivial edge-case branches.

Targets files with 1-5 missing lines each. All tests use physical substrate — zero mocks.
"""

import pytest
from coreason_manifest.spec.ontology import (
    CognitiveActionSpaceManifest,
    KineticSeparationPolicy,
    PermissionBoundaryPolicy,
    SideEffectProfile,
    SpatialToolManifest,
)

from coreason_runtime.execution_plane.io_broker import serialize_intent
from coreason_runtime.execution_plane.topological_enforcer import TopologicalEnforcer
from coreason_runtime.utils.exceptions import PayloadTooLargeError


def _dummy_tool(name: str) -> SpatialToolManifest:
    return SpatialToolManifest(
        tool_name=name,
        description="Test tool",
        input_schema={},
        side_effects=SideEffectProfile(is_idempotent=True, mutates_state=False),
        permissions=PermissionBoundaryPolicy(network_access=False, file_system_mutation_forbidden=True),
    )


# ── TopologicalEnforcer: kinetic_separation=None (L29) ────────────────


class TestTopologicalEnforcerNullSeparation:
    """Cover the early return when kinetic_separation is None."""

    def test_no_kinetic_separation_allows_all(self) -> None:
        """When kinetic_separation is None, validate_kinetic_separation returns immediately.

        Covers L29 (early return branch).
        """
        manifest = CognitiveActionSpaceManifest(
            action_space_cid="test_space",
            entry_point_cid="toolA",
            capabilities={"toolA": _dummy_tool("toolA"), "toolB": _dummy_tool("toolB")},
            transition_matrix={"toolA": []},
            kinetic_separation=None,
        )
        enforcer = TopologicalEnforcer(manifest)
        # Should not raise — no kinetic separation enforced
        enforcer.validate_kinetic_separation("toolB", ["toolA"])

    def test_empty_clusters_allows_all(self) -> None:
        """When clusters list is empty, validate_kinetic_separation returns immediately.

        Covers L33 (empty clusters early return).
        """
        policy = KineticSeparationPolicy(
            policy_cid="permissive",
            mutually_exclusive_clusters=[],
            enforcement_action="halt_and_quarantine",
        )
        manifest = CognitiveActionSpaceManifest(
            action_space_cid="test_space",
            entry_point_cid="toolA",
            capabilities={"toolA": _dummy_tool("toolA"), "toolB": _dummy_tool("toolB")},
            transition_matrix={"toolA": []},
            kinetic_separation=policy,
        )
        enforcer = TopologicalEnforcer(manifest)
        # Should not raise — empty cluster list
        enforcer.validate_kinetic_separation("toolB", ["toolA", "toolC"])


# ── IO Broker: PayloadTooLargeError (L36-39) ─────────────────────────


class TestIOBrokerPayloadLimit:
    """Cover the 1MB payload size guard."""

    def test_oversized_payload_raises(self) -> None:
        """Payload exceeding 1MB triggers PayloadTooLargeError.

        Covers L36-39 (size check branch).
        """
        # Build a dict that serializes to >1MB
        large_intent = {"data": "x" * (1048576 + 100)}
        with pytest.raises(PayloadTooLargeError, match="WebAssembly lattice cap"):
            serialize_intent(large_intent)

    def test_intent_with_no_model_dump_no_dict(self) -> None:
        """Non-dict, non-model intent falls back to empty dict.

        Covers L30 (else branch).
        """
        result = serialize_intent(42)
        assert result == b"{}"

    def test_intent_with_model_dump(self) -> None:
        """Intent with model_dump() attribute uses that path.

        Covers L25-26 (hasattr model_dump branch).
        """

        class FakeModel:
            def model_dump(self) -> dict[str, str]:
                return {"key": "value"}

        result = serialize_intent(FakeModel())
        assert b'"key"' in result
        assert b'"value"' in result
