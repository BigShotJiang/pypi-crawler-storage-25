# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from pathlib import Path

import pytest  # pyre-ignore[21]

from coreason_runtime.execution_plane.wasm_enclave.extism_host_environment import ExtismWasmEnclave  # pyre-ignore[21]
from coreason_runtime.utils.exceptions import ManifestConformanceError  # pyre-ignore[21]

WASM_DIR = Path("tests/assets/wasm")


@pytest.fixture
def enclave() -> ExtismWasmEnclave:
    return ExtismWasmEnclave()


@pytest.mark.asyncio
async def test_temporal_fuel_bounds_infinite_loop(enclave: ExtismWasmEnclave) -> None:
    """AGENTS.md: Temporal Bounds (Instruction Metering) with Uncatchable Traps."""
    file_path = WASM_DIR / "infinite_loop.wasm"

    # We restrict execution strongly to 50ms (or fuel limits if exposed)
    enclave.initialize_plugin(file_path, {"timeout_ms": 50})

    intent = {"jsonrpc": "2.0", "id": "temporal-test", "method": "run", "params": {}}

    with pytest.raises(ManifestConformanceError) as exc_info:
        enclave.execute_intent("infinite_loop", intent)

    assert "Extism execution trap" in str(exc_info.value)
    assert getattr(exc_info.value, "__cause__", None) is not None
    assert "timeout" in str(exc_info.value.__cause__).lower()


@pytest.mark.asyncio
async def test_spatial_memory_bounds_memory_grow(enclave: ExtismWasmEnclave) -> None:
    """AGENTS.md: Spatial Bounds (RAM/VRAM) strict memory.grow bounding."""
    file_path = WASM_DIR / "memory_leak.wasm"

    # We restrict to strictly 10 memory pages (640 KB total)
    enclave.initialize_plugin(file_path, {"memory": {"max_pages": 10}})

    intent = {"jsonrpc": "2.0", "id": "spatial-test", "method": "run", "params": {}}

    with pytest.raises(ManifestConformanceError) as exc_info:
        enclave.execute_intent("run", intent)

    assert "Extism execution trap" in str(exc_info.value)
    cause = getattr(exc_info.value, "__cause__", None)
    assert cause is not None
    assert "oom" in str(cause).lower()


@pytest.mark.asyncio
async def test_ipc_bounds_verification() -> None:
    """AGENTS.md: Out-of-Bounds IPC verification. FlatBuffers/Cap'n Proto zero-copy bounds safety.
    Test trapped maliciously spoofed memory offset/pointer throwing ManifestConformanceError."""
    enclave = ExtismWasmEnclave()
    intent = {"jsonrpc": "2.0", "id": "ipc-test", "method": "run", "params": {}}
    enclave.initialize_plugin(WASM_DIR / "malicious_memory.wasm")

    with pytest.raises(ManifestConformanceError) as exc_info:
        enclave.execute_intent("malicious_memory", intent)

    assert "Extism execution trap" in str(exc_info.value)
    cause = getattr(exc_info.value, "__cause__", None)
    assert cause is not None
    assert "error while executing" in str(cause).lower()


@pytest.mark.asyncio
async def test_host_boundary_initialization_failure() -> None:
    """Verify that loading invalid WASM gracefully handles execution without panicking the C host."""
    enclave = ExtismWasmEnclave()
    with pytest.raises(ManifestConformanceError) as exc_info:
        # Load an invalid file acting as malicious bytecode
        enclave.initialize_plugin(Path(__file__))  # We use a python file which is not a valid WASM binary

    assert "Plugin initialization trap" in str(exc_info.value)


@pytest.mark.asyncio
async def test_unitialized_enclave_call(enclave: ExtismWasmEnclave) -> None:
    """Verify state initialization safety borders."""
    intent = {"jsonrpc": "2.0", "id": "fail-test", "method": "run", "params": {}}

    with pytest.raises(ManifestConformanceError, match="Extism plugin not initialized"):
        enclave.execute_intent("run", intent)
