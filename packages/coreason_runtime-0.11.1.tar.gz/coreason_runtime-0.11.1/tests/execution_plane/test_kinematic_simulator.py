# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import pytest

from coreason_runtime.execution_plane.kinematic_simulator import SpatialBoundsPayload, verify_spatial_bounds_activity
from coreason_runtime.utils.exceptions import ManifestConformanceError


@pytest.mark.asyncio
async def test_kinematic_safe_bounds() -> None:
    """AGENTS.md: Validate strictly O(1) spatial coordinate transformations within bounds."""
    payload: SpatialBoundsPayload = {
        "kinematics": {"target_coordinate": [0.5, 0.5]},
        "observer": {"optical_center_x": 0.0},
        "bounding_volume": {"collision_radius": 1.0},
        "security_taint": "Public",  # type: ignore
    }

    # 0.5^2 + 0.5^2 = 0.5 => magnitude = sqrt(0.5) ~ 0.707 < 1.0 -> SAFE
    result = await verify_spatial_bounds_activity(payload)
    assert result["verified"] is True
    assert result["kinematic_clearance"] is True


@pytest.mark.asyncio
async def test_kinematic_unsafe_bounds_throws_manifest_conformance() -> None:
    """AGENTS.md: Assert that attempting to actuate coordinates past safe_bounds throws ManifestConformanceError."""
    payload: SpatialBoundsPayload = {
        "kinematics": {"target_coordinate": [1.0, 1.0]},
        "observer": {"optical_center_x": 0.0},
        "bounding_volume": {"collision_radius": 1.0},
    }

    # 1.0^2 + 1.0^2 = 2.0 => magnitude = sqrt(2.0) ~ 1.414 > 1.0 -> UNSAFE
    with pytest.raises(ManifestConformanceError) as exc_info:
        await verify_spatial_bounds_activity(payload)

    assert "Trajectory exceeds bounding physics" in str(exc_info.value)


@pytest.mark.asyncio
async def test_invalid_spatial_matrices() -> None:
    """Validate invalid matrices correctly fail mapping schemas."""
    # Bad payload shapes
    payload: SpatialBoundsPayload = {
        "kinematics": {"target_coordinate": ["invalid", "string"]},
        "observer": {"optical_center_x": 0.0},
        "bounding_volume": {"collision_radius": 1.0},
    }

    with pytest.raises(ManifestConformanceError) as exc_info:
        await verify_spatial_bounds_activity(payload)

    assert "Invalid coordinate vectors" in str(exc_info.value)


@pytest.mark.asyncio
async def test_invalid_schema_structure() -> None:
    """Missing target_coordinate array should fail schema validation."""
    payload: SpatialBoundsPayload = {
        "observer": {"optical_center_x": 0.0},
        "bounding_volume": {"collision_radius": 1.0},
    }

    with pytest.raises(ManifestConformanceError):
        await verify_spatial_bounds_activity(payload)


@pytest.mark.asyncio
async def test_lbac_confidential_taint() -> None:
    """Assert Loguru records LBAC Reference Monitor No-Write-Down lattice constraint."""
    payload: SpatialBoundsPayload = {
        "kinematics": {"target_coordinate": [0.0, 0.0]},
        "observer": {"optical_center_x": 0.0},
        "bounding_volume": {"collision_radius": 1.0},
        "security_taint": "Confidential",  # type: ignore
    }

    result = await verify_spatial_bounds_activity(payload)
    assert result["verified"] is True
