from typing import Any

import pytest

from coreason_runtime.execution_plane.dom_simulator import execute_browser_intent_activity
from coreason_runtime.utils.exceptions import ManifestConformanceError


@pytest.mark.asyncio
async def test_execute_browser_intent_activity() -> None:
    """
    AGENT INSTRUCTION: Validates headless execution bounds natively.
    CAUSAL AFFORDANCE: Proves successful playwright DOM resolution triggers SUCCESS logic cleanly.
    EPISTEMIC BOUNDS: Mocks the async_playwright context manager inline completely.
    MCP ROUTING TRIGGERS: dom_simulator, headless_execution
    """
    # 1. Missing payload boundaries
    with pytest.raises(ManifestConformanceError, match="Missing layout boundaries"):
        await execute_browser_intent_activity({})

    # 2. Restricted domains
    with pytest.raises(ManifestConformanceError, match="restricted DOM enclave topologies"):
        await execute_browser_intent_activity(
            {"browser_state": {}, "document_layout": {"source_uri": "restricted/admin"}}
        )

    # 3. Successful resolution and playback using a mocked playwright natively!
    import coreason_runtime.execution_plane.dom_simulator

    orig_pw = coreason_runtime.execution_plane.dom_simulator.async_playwright  # type: ignore

    class FakePage:
        async def goto(self, url: str, **kwargs: Any) -> None:  # noqa: ARG002
            if "fail" in url:
                raise ValueError("DOM crash")

        async def content(self) -> str:
            return "<html></html>"

    class FakeContext:
        async def new_page(self) -> FakePage:
            return FakePage()

    class FakeBrowser:
        async def new_context(self) -> FakeContext:
            return FakeContext()

        async def close(self) -> None:
            pass

    class FakePlaywrightManager:
        async def __aenter__(self) -> Any:
            class Chromium:
                async def launch(self, **kwargs: Any) -> FakeBrowser:  # noqa: ARG002
                    return FakeBrowser()

            class PW:
                chromium = Chromium()

            return PW()

        async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
            pass

    def fake_async_pw() -> FakePlaywrightManager:
        return FakePlaywrightManager()

    coreason_runtime.execution_plane.dom_simulator.async_playwright = fake_async_pw  # type: ignore

    try:
        # Success
        result = await execute_browser_intent_activity(
            {"browser_state": {"navigation_depth": 1}, "document_layout": {"source_uri": "http://example.com"}}
        )
        assert result["execution_status"] == "SUCCESS"
        assert "<html>" in result["rendered_html"]

        # Failure
        with pytest.raises(ManifestConformanceError, match="DOM Topological Access Denied"):
            await execute_browser_intent_activity(
                {"browser_state": {"navigation_depth": 1}, "document_layout": {"source_uri": "http://fail.com"}}
            )
    finally:
        coreason_runtime.execution_plane.dom_simulator.async_playwright = orig_pw  # type: ignore
