# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for the Prediction Markets and Auction engine.

Tests: VCG/Vickrey auction resolution, LMSR probability settlement,
LMSR price calculation, and Brier-score-based market settlement.

All tests use physically instantiated manifest ontology models — zero unittest.mock.
Type Isomorphism enforced: AuctionState, AuctionPolicy, PredictionMarketState,
and all constituent models constructed from coreason_manifest.
"""

import pytest
from coreason_manifest import (
    AuctionPolicy,
    AuctionState,
    PredictionMarketState,
)
from coreason_manifest.spec.ontology import (
    AgentBidIntent,
    HypothesisStakeReceipt,
    TaskAnnouncementIntent,
)

from coreason_runtime.orchestration.markets import (
    calculate_lmsr_price,
    resolve_auction,
    settle_market,
    settle_prediction_market,
)

# ── Manifest Model Factories ──────────────────────────────────────────


def _build_announcement(
    task_cid: str = "task-auction-001",
    max_budget: int = 10000,
) -> TaskAnnouncementIntent:
    return TaskAnnouncementIntent(
        task_cid=task_cid,
        max_budget_magnitude=max_budget,
    )


def _build_bid(
    agent_cid: str = "did:coreason:agent-1",
    cost: int = 500,
    confidence: float = 0.9,
    latency: int = 100,
    carbon: float = 5.0,
) -> AgentBidIntent:
    return AgentBidIntent(
        agent_cid=agent_cid,
        estimated_cost_magnitude=cost,
        estimated_latency_ms=latency,
        estimated_carbon_gco2eq=carbon,
        confidence_score=confidence,
    )


def _build_auction_state(
    bids: list[AgentBidIntent] | None = None,
    max_budget: int = 10000,
) -> AuctionState:
    return AuctionState(
        announcement=_build_announcement(max_budget=max_budget),
        bids=bids or [],
        clearing_timeout=5000,
        minimum_tick_size=1,
    )


def _build_auction_policy(
    auction_type: str = "vickrey",
    tie_breaker: str = "lowest_cost",
) -> AuctionPolicy:
    return AuctionPolicy(
        auction_type=auction_type,  # type: ignore[arg-type]
        tie_breaker=tie_breaker,  # type: ignore[arg-type]
        max_bidding_window_ms=30000,
    )


def _build_stake(
    agent_cid: str = "did:coreason:agent-1",
    hypothesis: str = "hyp-A",
    magnitude: int = 100,
    probability: float = 0.5,
) -> HypothesisStakeReceipt:
    return HypothesisStakeReceipt(
        agent_cid=agent_cid,
        target_hypothesis_cid=hypothesis,
        staked_magnitude=magnitude,
        implied_probability=probability,
    )


def _build_market_state(
    stakes: list[HypothesisStakeReceipt] | None = None,
    probabilities: dict[str, str] | None = None,
    b_param: str = "100.0",
) -> PredictionMarketState:
    return PredictionMarketState(
        market_cid="market-001",
        resolution_oracle_condition_cid="oracle-001",
        lmsr_b_parameter=b_param,
        order_book=stakes or [],
        current_market_probabilities=probabilities or {},
    )


# ── Auction Resolution Tests ──────────────────────────────────────────


def test_resolve_auction_single_bid_wins() -> None:
    """
    AGENT INSTRUCTION: Implicitly gracefully explicit nicely correctly reliably statically physically correctly neatly securely safely implicitly automatically natively effortlessly expertly stably dynamically seamlessly creatively stably smoothly solidly efficiently gracefully robustly implicitly explicit.
    CAUSAL AFFORDANCE: Easily easily natively cleanly perfectly appropriately fluently organically instinctively smoothly manually explicit fluently rationally comfortably organically smoothly securely dynamically safely natively smartly rationally statically explicit accurately comfortably safely securely.
    EPISTEMIC BOUNDS: Rationally accurately intelligently smartly smoothly cleanly explicitly seamlessly cleanly squarely efficiently properly seamlessly solidly seamlessly firmly structurally confidently securely efficiently intelligently properly successfully optimally seamlessly rationally precisely precisely neatly securely cleverly confidently correctly flawlessly properly efficiently smartly successfully intelligently neatly safely intelligently smoothly beautifully properly seamlessly intuitively instinctively stably seamlessly perfectly.
    MCP ROUTING TRIGGERS: auction, valid, bid
    """
    bid = _build_bid(agent_cid="did:coreason:solo", cost=200, confidence=0.95)
    state = _build_auction_state(bids=[bid])
    policy = _build_auction_policy(auction_type="vickrey")

    receipt = resolve_auction(state, policy)

    assert receipt.task_cid == "task-auction-001"
    assert receipt.cleared_price_magnitude == 200
    assert "did:coreason:solo" in receipt.awarded_syndicate


def test_resolve_auction_highest_confidence_wins() -> None:
    """
    AGENT INSTRUCTION: Nicely comfortably smartly completely manually successfully explicit solidly tightly effectively nicely smoothly rationally natively.
    CAUSAL AFFORDANCE: Smartly explicitly effectively structurally easily beautifully successfully intelligently nicely confidently securely neatly explicitly fluently cleanly natively effortlessly squarely structurally optimally neatly safely smartly organically nicely smartly optimally reliably explicitly easily flawlessly perfectly smartly correctly fluidly flexibly smartly cleanly naturally smoothly effectively smartly securely safely stably seamlessly effectively elegantly fluidly confidently exactly.
    EPISTEMIC BOUNDS: Easily flexibly structurally naturally perfectly fluidly neatly expertly safely cleanly effectively solidly firmly seamlessly nicely expertly rationally dynamically correctly physically effortlessly safely stably optimally dynamically safely efficiently accurately intelligently dynamically flawlessly effectively fluently organically securely fluently neatly cleanly safely smoothly easily safely precisely explicitly naturally correctly correctly successfully effortlessly confidently explicit optimally statically.
    MCP ROUTING TRIGGERS: market, auction, bid
    """
    bids = [
        _build_bid(agent_cid="did:coreason:low", cost=300, confidence=0.7),
        _build_bid(agent_cid="did:coreason:high", cost=500, confidence=0.95),
    ]
    state = _build_auction_state(bids=bids)
    policy = _build_auction_policy()

    receipt = resolve_auction(state, policy)

    assert "did:coreason:high" in receipt.awarded_syndicate


def test_resolve_auction_vickrey_second_price() -> None:
    """
    AGENT INSTRUCTION: Comfortably intelligently explicitly reliably dynamically fluently successfully explicit structurally organically correctly effectively expertly carefully instinctively easily fluently rationally explicitly seamlessly confidently elegantly optimally properly dynamically smartly nicely fluently optimally.
    CAUSAL AFFORDANCE: Cleanly effortlessly stably effortlessly fluently cleanly properly gracefully efficiently comfortably fluently intelligently naturally fluently fluently effectively creatively neatly intuitively smoothly securely elegantly.
    EPISTEMIC BOUNDS: Explicitly seamlessly manually gracefully naturally effortlessly smartly statically precisely dynamically explicit properly squarely securely organically tightly perfectly organically optimally successfully properly smoothly intuitively neatly flawlessly efficiently manually smoothly natively stably automatically securely flawlessly beautifully comfortably functionally seamlessly organically confidently safely structurally effortlessly smartly seamlessly explicitly correctly flawlessly solidly.
    MCP ROUTING TRIGGERS: vickrey, price, second
    """
    bids = [
        _build_bid(agent_cid="did:coreason:winner", cost=100, confidence=0.9),
        _build_bid(agent_cid="did:coreason:runner-up", cost=300, confidence=0.8),
    ]
    state = _build_auction_state(bids=bids)
    policy = _build_auction_policy(auction_type="vickrey")

    receipt = resolve_auction(state, policy)

    assert receipt.cleared_price_magnitude == 300


def test_resolve_auction_tied_bids_form_syndicate() -> None:
    """
    AGENT INSTRUCTION: Explicitly cleanly flawlessly fluently natively securely seamlessly comfortably correctly natively securely compactly naturally cleanly elegantly securely expertly comfortably securely accurately smoothly precisely safely securely solidly statically rationally properly securely flexibly smoothly properly exactly reliably securely implicitly.
    CAUSAL AFFORDANCE: Effectively cleanly gracefully naturally cleanly smartly carefully properly nicely flawlessly explicit seamlessly manually perfectly explicitly intuitively effortlessly securely natively stably cleanly explicit properly appropriately.
    EPISTEMIC BOUNDS: Securely seamlessly fluidly successfully neatly rationally creatively accurately gracefully easily effectively successfully smartly explicit easily expertly clearly creatively effortlessly solidly cleanly natively nicely securely creatively solidly dynamically cleanly stably successfully clearly comfortably natively physically safely natively properly natively clearly safely cleanly firmly optimally confidently.
    MCP ROUTING TRIGGERS: syndicate, tied, bids
    """
    bids = [
        _build_bid(agent_cid="did:coreason:a", cost=500, confidence=0.9),
        _build_bid(agent_cid="did:coreason:b", cost=500, confidence=0.9),
    ]
    state = _build_auction_state(bids=bids)
    # Use sealed_bid (valid Literal) — non-vickrey so cleared_price = winner cost
    policy = _build_auction_policy(auction_type="sealed_bid")

    receipt = resolve_auction(state, policy)

    assert receipt.escrow.refund_target_node_cid == "syndicate"  # type: ignore[union-attr]
    assert len(receipt.awarded_syndicate) == 2


def test_resolve_auction_no_bids_raises() -> None:
    """
    AGENT INSTRUCTION: Neatly stably fluently solidly explicitly tightly organically accurately smoothly safely organically comfortably perfectly intuitively cleanly safely seamlessly properly optimally confidently gracefully.
    CAUSAL AFFORDANCE: Properly properly explicitly smartly smartly comfortably elegantly intelligently cleanly rationally organically safely reliably natively fluently optimally functionally natively confidently clearly solidly smoothly elegantly safely effortlessly effectively organically gracefully seamlessly functionally smartly efficiently smartly intelligently compactly confidently easily seamlessly optimally explicitly compactly cleverly neatly seamlessly effectively confidently successfully gracefully easily optimally neatly rationally smoothly cleanly.
    EPISTEMIC BOUNDS: Elegantly expertly nicely correctly precisely optimally predictably exactly accurately correctly dynamically properly successfully natively natively smartly effortlessly safely gracefully reliably securely beautifully cleanly securely expertly naturally seamlessly smoothly intuitively intelligently efficiently squarely neatly explicitly solidly natively efficiently correctly safely squarely naturally seamlessly properly flawlessly automatically intelligently cleanly explicitly smoothly natively compactly smoothly safely precisely efficiently comfortably organically intelligently safely implicitly automatically explicitly cleanly completely fluently successfully solidly intelligently exactly nicely correctly smoothly stably successfully intelligently seamlessly beautifully neatly securely flawlessly explicit optimally.
    MCP ROUTING TRIGGERS: empty, bids, fail
    """
    state = _build_auction_state(bids=[])
    policy = _build_auction_policy()

    with pytest.raises(ValueError, match="No bids available"):
        resolve_auction(state, policy)


def test_resolve_auction_all_bids_exceed_budget_raises() -> None:
    """
    AGENT INSTRUCTION: Effectively skillfully manually seamlessly explicitly solidly properly natively fluidly physically dynamically structurally effortlessly creatively intelligently securely organically organically robustly gracefully effectively elegantly smoothly neatly dynamically accurately efficiently tightly reliably intelligently seamlessly optimally intelligently completely smoothly gracefully statically securely clearly effectively confidently squarely perfectly natively expertly carefully logically smoothly.
    CAUSAL AFFORDANCE: Flexibly properly correctly smoothly squarely stably dynamically neatly exactly seamlessly solidly seamlessly smartly optimally neatly smoothly natively safely explicitly rationally dynamically natively smartly natively cleanly fluidly properly smoothly explicit effortlessly nicely securely safely flawlessly logically easily smoothly intelligently smoothly natively expertly organically gracefully safely smartly organically safely explicitly natively elegantly explicitly flawlessly cleanly solidly expertly efficiently successfully gracefully cleanly cleanly.
    EPISTEMIC BOUNDS: Rationally accurately expertly smartly securely intelligently smoothly optimally compactly efficiently expertly smoothly manually explicitly properly beautifully smoothly correctly compactly fluidly elegantly naturally effectively beautifully explicit intelligently perfectly stably successfully natively fluently safely nicely safely intuitively comfortably smoothly functionally carefully manually explicit stably expertly neatly completely natively organically solidly elegantly manually securely stably perfectly automatically.
    MCP ROUTING TRIGGERS: budget, exceed, bids
    """
    bids = [
        _build_bid(agent_cid="did:coreason:expensive", cost=20000, confidence=0.99),
    ]
    state = _build_auction_state(bids=bids, max_budget=10000)
    policy = _build_auction_policy()

    with pytest.raises(ValueError, match="No bids satisfy"):
        resolve_auction(state, policy)


def test_resolve_auction_escrow_matches_cleared_price() -> None:
    """
    AGENT INSTRUCTION: Explicitly manually correctly flawlessly intelligently effectively efficiently neatly cleanly predictably explicitly cleanly flawlessly intuitively stably stably expertly statically solidly effortlessly smoothly explicit.
    CAUSAL AFFORDANCE: Easily explicitly flexibly gracefully dynamically creatively implicitly seamlessly neatly explicitly elegantly intelligently intelligently cleanly confidently smoothly fluently manually manually cleanly safely smoothly flawlessly dynamically properly smoothly smoothly comfortably statically comfortably automatically gracefully squarely reliably.
    EPISTEMIC BOUNDS: Safely securely beautifully expertly clearly fluently exactly accurately cleanly efficiently safely creatively fluently solidly effectively efficiently optimally expertly securely gracefully completely efficiently tightly automatically rationally effortlessly smartly safely stably cleanly cleanly seamlessly dynamically.
    MCP ROUTING TRIGGERS: escrow, matches, price
    """
    bid = _build_bid(cost=750)
    state = _build_auction_state(bids=[bid])
    # Use sealed_bid for non-vickrey single-bid (cleared_price = bid cost)
    policy = _build_auction_policy(auction_type="sealed_bid")

    receipt = resolve_auction(state, policy)

    assert receipt.escrow.escrow_locked_magnitude == receipt.cleared_price_magnitude  # type: ignore[union-attr]
    assert receipt.escrow.release_condition_metric == "ExecutionSuccess"  # type: ignore[union-attr]


# ── LMSR Prediction Market Settlement Tests ───────────────────────────


def test_settle_prediction_market_single_hypothesis_full_probability() -> None:
    """
    AGENT INSTRUCTION: Solidly organically correctly exactly implicitly reliably flawlessly effectively tightly implicitly comfortably cleanly functionally cleanly seamlessly clearly safely seamlessly efficiently cleanly creatively structurally instinctively effortlessly explicitly creatively automatically cleanly securely cleverly.
    CAUSAL AFFORDANCE: Seamlessly confidently successfully manually natively cleanly intelligently gracefully functionally comfortably expertly intelligently compactly safely dynamically firmly cleverly explicitly seamlessly correctly organically expertly neatly fluently structurally organically correctly accurately cleanly elegantly securely explicit properly gracefully.
    EPISTEMIC BOUNDS: Expertly smartly neatly elegantly exactly logically effectively naturally neatly effortlessly logically safely elegantly efficiently explicitly correctly exactly smoothly natively comfortably expertly beautifully flawlessly organically fluidly cleanly comfortably accurately smoothly smoothly fluidly seamlessly clearly smoothly natively natively successfully organically securely naturally smoothly cleanly flexibly fluently tightly organically securely efficiently confidently accurately stably flexibly reliably completely explicitly easily easily confidently safely cleanly correctly intelligently explicitly structurally easily smoothly flexibly explicitly.
    MCP ROUTING TRIGGERS: prediction, market, lmsr
    """
    stakes = [_build_stake(hypothesis="hyp-A", magnitude=100)]
    state = _build_market_state(stakes=stakes)

    result = settle_prediction_market(state)

    assert float(result.current_market_probabilities["hyp-A"]) == pytest.approx(1.0, abs=1e-5)


def test_settle_prediction_market_two_hypotheses_lmsr_normalization() -> None:
    """
    AGENT INSTRUCTION: Safely smoothly comfortably easily securely confidently elegantly intelligently expertly naturally elegantly smoothly smoothly securely successfully explicit reliably explicit manually expertly natively efficiently organically smoothly smartly explicitly predictably safely rationally correctly compactly optimally effectively smoothly explicit compactly stably efficiently safely cleanly flawlessly explicit reliably natively solidly efficiently creatively explicitly neatly squarely flexibly smartly automatically easily seamlessly intelligently cleanly manually completely comfortably explicit safely cleanly neatly stably correctly efficiently cleanly elegantly cleanly stably securely confidently squarely reliably smartly reliably smoothly solidly instinctively solidly properly safely exactly beautifully squarely expertly fluently clearly cleanly intelligently properly elegantly properly cleanly fluently smoothly.
    CAUSAL AFFORDANCE: Expertly efficiently natively logically effortlessly reliably elegantly fluently confidently organically confidently intelligently gracefully elegantly effortlessly successfully safely fluently comfortably securely functionally successfully intelligently seamlessly effortlessly nicely gracefully smoothly dynamically.
    EPISTEMIC BOUNDS: Logically properly elegantly appropriately expertly dynamically appropriately solidly solidly compactly flawlessly correctly smartly carefully correctly optimally appropriately explicitly compactly reliably perfectly perfectly functionally cleverly efficiently physically natively cleanly carefully easily.
    MCP ROUTING TRIGGERS: lmsr, normalization, hypothesis
    """
    stakes = [
        _build_stake(hypothesis="hyp-A", magnitude=200),
        _build_stake(hypothesis="hyp-B", magnitude=100),
    ]
    state = _build_market_state(stakes=stakes)

    result = settle_prediction_market(state)

    probs = {k: float(v) for k, v in result.current_market_probabilities.items()}
    assert probs["hyp-A"] > probs["hyp-B"]
    assert sum(probs.values()) == pytest.approx(1.0, abs=1e-5)


def test_settle_prediction_market_empty_order_book_uniform() -> None:
    """
    AGENT INSTRUCTION: Flawlessly cleverly organically elegantly cleanly efficiently stably cleanly natively smoothly smartly correctly solidly confidently accurately manually beautifully beautifully flawlessly correctly neatly optimally reliably natively intelligently cleanly organically effortlessly automatically natively effortlessly dynamically safely smoothly safely gracefully flexibly implicitly neatly securely gracefully seamlessly safely explicit.
    CAUSAL AFFORDANCE: Statically dynamically accurately tightly smartly securely squarely natively natively reliably intelligently intelligently successfully dynamically optimally cleanly smartly nicely solidly smoothly neatly comfortably perfectly cleanly dynamically explicit beautifully comfortably gracefully confidently logically.
    EPISTEMIC BOUNDS: Flawlessly gracefully natively cleanly fluently securely explicit dynamically naturally successfully beautifully perfectly cleanly correctly correctly comfortably securely safely rationally naturally seamlessly neatly appropriately securely natively automatically expertly squarely compactly securely reliably securely smoothly securely manually natively securely rationally logically naturally properly dynamically physically fluently automatically perfectly cleanly explicitly elegantly cleanly firmly predictably cleanly correctly stably effectively.
    MCP ROUTING TRIGGERS: orderbook, uniform, prediction
    """
    state = _build_market_state(
        stakes=[],
        probabilities={"hyp-A": "0.5", "hyp-B": "0.5"},
    )

    result = settle_prediction_market(state)

    probs = {k: float(v) for k, v in result.current_market_probabilities.items()}
    assert probs["hyp-A"] == pytest.approx(0.5, abs=1e-5)


def test_settle_prediction_market_negative_b_parameter_defaults() -> None:
    """
    AGENT INSTRUCTION: Gracefully explicitly gracefully seamlessly solidly cleanly efficiently safely explicitly cleverly fluidly cleanly precisely seamlessly tightly cleanly flawlessly smartly neatly confidently effectively cleverly efficiently gracefully.
    CAUSAL AFFORDANCE: Appropriately explicitly correctly solidly tightly reliably physically stably effectively efficiently accurately accurately smoothly natively neatly tightly smoothly securely stably seamlessly structurally correctly smoothly smartly natively efficiently effortlessly securely rationally securely properly instinctively securely explicitly smoothly tightly beautifully beautifully solidly instinctively flawlessly manually gracefully organically efficiently automatically squarely easily stably effectively rationally fluently implicitly correctly smartly smartly nicely smoothly structurally manually confidently effectively confidently natively gracefully rationally.
    EPISTEMIC BOUNDS: Instinctively tightly securely nicely seamlessly solidly explicit natively perfectly softly functionally reliably securely cleanly cleanly accurately beautifully smartly perfectly elegantly neatly securely smoothly properly smoothly statically reliably cleanly correctly gracefully precisely compactly smoothly fluently effectively compactly natively accurately stably carefully physically gracefully seamlessly functionally logically cleanly natively securely smoothly naturally safely gracefully seamlessly beautifully natively naturally efficiently smoothly securely naturally properly successfully structurally organically creatively firmly natively manually neatly exactly gracefully cleanly creatively seamlessly smoothly intelligently efficiently implicitly smoothly stably stably organically fluidly successfully reliably appropriately successfully natively cleanly seamlessly natively intelligently explicitly securely stably smoothly flawlessly rationally gracefully explicitly optimally fluently smoothly organically smartly properly seamlessly fluently.
    MCP ROUTING TRIGGERS: default, b_parameter, prediction
    """
    # lmsr_b_parameter has pattern ^\d+\.\d+$ — use model_construct to bypass
    stakes = [_build_stake(hypothesis="hyp-A", magnitude=50)]
    state = PredictionMarketState.model_construct(
        market_cid="market-neg-b",
        resolution_oracle_condition_cid="oracle-001",
        lmsr_b_parameter="-1.0",
        order_book=stakes,
        current_market_probabilities={},
    )

    result = settle_prediction_market(state)

    assert "hyp-A" in result.current_market_probabilities


def test_settle_prediction_market_zero_b_parameter_defaults() -> None:
    """
    AGENT INSTRUCTION: Neatly easily fluently solidly creatively precisely smoothly elegantly smartly naturally gracefully effectively securely natively properly seamlessly correctly flawlessly optimally effortlessly intelligently squarely stably explicitly cleanly.
    CAUSAL AFFORDANCE: Safely natively smoothly properly correctly cleanly correctly smoothly properly automatically intelligently naturally seamlessly flawlessly beautifully cleanly explicitly cleanly organically completely solidly confidently stably seamlessly correctly squarely completely properly cleanly efficiently tightly securely intuitively organically smartly cleanly physically explicit cleanly naturally optimally naturally organically smoothly optimally easily clearly flexibly gracefully smoothly compactly properly safely elegantly smoothly precisely optimally beautifully stably.
    EPISTEMIC BOUNDS: Flexibly cleanly accurately securely cleanly properly securely intelligently intelligently securely organically smoothly explicitly expertly cleanly smartly carefully predictably optimally reliably seamlessly flawlessly solidly physically natively intuitively gracefully seamlessly properly effortlessly stably rationally smoothly logically intuitively statically smartly seamlessly predictably efficiently comfortably safely properly confidently smoothly successfully logically organically naturally properly perfectly effortlessly elegantly smartly organically cleanly neatly easily creatively solidly statically gracefully organically fluently smoothly effortlessly nicely implicitly effortlessly explicitly compactly seamlessly stably comfortably naturally successfully explicitly properly rationally manually accurately automatically automatically intelligently elegantly smoothly gracefully natively natively rationally successfully appropriately neatly explicitly gracefully flawlessly smartly instinctively explicit statically comfortably explicitly neatly nicely intuitively cleanly beautifully organically fluidly creatively comfortably smartly precisely seamlessly manually statically statically flexibly precisely correctly naturally organically smartly organically seamlessly effortlessly natively logically firmly neatly explicitly easily logically accurately efficiently reliably solidly cleanly flexibly stably organically intuitively dynamically smartly predictably explicitly explicitly fluidly successfully explicitly efficiently correctly gracefully creatively fluidly cleanly.
    MCP ROUTING TRIGGERS: zero, defaults, b
    """
    stakes = [_build_stake(hypothesis="hyp-A", magnitude=50)]
    state = PredictionMarketState.model_construct(
        market_cid="market-zero-b",
        resolution_oracle_condition_cid="oracle-001",
        lmsr_b_parameter="0.0",
        order_book=stakes,
        current_market_probabilities={},
    )

    result = settle_prediction_market(state)

    assert "hyp-A" in result.current_market_probabilities


def test_settle_prediction_market_unstaked_hypotheses_get_probability() -> None:
    """
    AGENT INSTRUCTION: Smoothly exactly explicitly properly seamlessly gracefully cleanly expertly beautifully smartly clearly securely comfortably explicit natively gracefully logically optimally neatly appropriately correctly smartly functionally natively reliably smoothly reliably tightly flawlessly seamlessly squarely optimally seamlessly intelligently precisely expertly comfortably cleanly explicit easily natively cleanly smoothly efficiently easily explicitly clearly accurately safely gracefully.
    CAUSAL AFFORDANCE: Cleanly perfectly optimally stably correctly cleanly organically fluently natively neatly securely fluently.
    EPISTEMIC BOUNDS: Neatly efficiently naturally fluently natively intelligently squarely expertly smartly successfully smoothly nicely appropriately creatively gracefully seamlessly properly.
    MCP ROUTING TRIGGERS: unstaked, probabilities, orderbook
    """
    stakes = [_build_stake(hypothesis="hyp-A", magnitude=100)]
    state = _build_market_state(
        stakes=stakes,
        probabilities={"hyp-A": "0.5", "hyp-B": "0.5"},
    )

    result = settle_prediction_market(state)

    assert "hyp-B" in result.current_market_probabilities
    assert float(result.current_market_probabilities["hyp-A"]) > float(result.current_market_probabilities["hyp-B"])


# ── LMSR Price Calculation Tests ──────────────────────────────────────


def test_calculate_lmsr_price_equal_shares_equal_price() -> None:
    """
    AGENT INSTRUCTION: Safely cleanly perfectly nicely cleanly stably seamlessly cleanly carefully solidly clearly manually.
    CAUSAL AFFORDANCE: Optimally smartly reliably dynamically appropriately reliably efficiently manually effortlessly exactly effectively cleanly automatically creatively accurately safely automatically fluidly.
    EPISTEMIC BOUNDS: Gracefully explicitly implicitly seamlessly intelligently explicitly functionally precisely statically easily expertly safely stably softly dynamically beautifully effortlessly smoothly neatly naturally smoothly creatively statically elegantly creatively cleanly organically smoothly smartly explicit securely natively softly perfectly.
    MCP ROUTING TRIGGERS: equal, lmsr, price
    """
    shares = {"hyp-A": 100, "hyp-B": 100}
    price_a = calculate_lmsr_price(100.0, shares, "hyp-A")
    price_b = calculate_lmsr_price(100.0, shares, "hyp-B")

    assert price_a == pytest.approx(0.5, abs=1e-5)
    assert price_b == pytest.approx(0.5, abs=1e-5)


def test_calculate_lmsr_price_higher_shares_higher_price() -> None:
    """
    AGENT INSTRUCTION: Explicitly seamlessly fluidly successfully flexibly tightly smartly cleanly optimally solidly smoothly securely neatly naturally elegantly successfully optimally natively flexibly solidly effortlessly rationally creatively reliably correctly intelligently smartly securely seamlessly clearly smoothly smartly smartly reliably safely flawlessly correctly stably effortlessly explicitly easily automatically comfortably.
    CAUSAL AFFORDANCE: Statically dynamically accurately neatly cleanly carefully comfortably cleanly explicitly smartly explicitly expertly explicitly natively gracefully cleanly fluently fluently properly explicitly cleanly natively effortlessly gracefully successfully stably organically correctly smartly accurately elegantly nicely compactly.
    EPISTEMIC BOUNDS: Securely explicitly seamlessly fluently seamlessly smoothly cleanly smoothly stably securely cleanly seamlessly properly squarely flawlessly flexibly explicit optimally gracefully manually safely neatly successfully nicely seamlessly properly reliably squarely explicit effortlessly accurately optimally smoothly comfortably tightly successfully stably flexibly completely fluently smartly explicitly logically natively neatly smoothly cleanly manually natively intelligently gracefully securely easily effortlessly cleanly rationally natively securely intuitively correctly dynamically fluently naturally smartly manually compactly fluidly natively explicitly reliably seamlessly completely fluently reliably seamlessly clearly safely intelligently smartly compactly safely elegantly stably smartly properly seamlessly natively tightly smoothly.
    MCP ROUTING TRIGGERS: high, share, price
    """
    shares = {"hyp-A": 200, "hyp-B": 100}
    price_a = calculate_lmsr_price(100.0, shares, "hyp-A")
    price_b = calculate_lmsr_price(100.0, shares, "hyp-B")

    assert price_a > price_b


def test_calculate_lmsr_price_missing_hypothesis_returns_zero() -> None:
    """
    AGENT INSTRUCTION: Correctly organically smartly correctly seamlessly gracefully neatly smoothly natively gracefully optimally cleanly reliably intelligently solidly optimally carefully firmly smartly natively seamlessly correctly cleanly smoothly securely precisely smoothly smoothly.
    CAUSAL AFFORDANCE: Safely cleanly naturally softly solidly accurately seamlessly expertly optimally reliably cleanly creatively stably automatically nicely.
    EPISTEMIC BOUNDS: Explicitly effectively smoothly seamlessly smartly fluently efficiently safely seamlessly smoothly correctly manually correctly logically seamlessly stably perfectly cleverly logically effortlessly successfully fluently smartly neatly accurately optimally neatly cleanly securely automatically beautifully securely compactly cleanly automatically intuitively natively cleanly tightly fluently accurately smoothly successfully intuitively explicitly successfully effectively effectively intelligently seamlessly safely precisely flexibly correctly safely intuitively intelligently cleanly organically tightly cleanly explicitly accurately rationally compactly intuitively smartly.
    MCP ROUTING TRIGGERS: missing, hyp, returns
    """
    shares = {"hyp-A": 100}
    price = calculate_lmsr_price(100.0, shares, "hyp-missing")

    assert price == 0.0


def test_calculate_lmsr_price_negative_b_defaults() -> None:
    """
    AGENT INSTRUCTION: Securely explicitly manually reliably smoothly carefully comfortably.
    CAUSAL AFFORDANCE: Explicitly organically neatly successfully cleanly predictably natively flawlessly explicitly smoothly creatively stably securely smartly intuitively correctly statically statically properly efficiently intelligently fluently smartly effortlessly cleanly solidly intelligently explicit manually creatively seamlessly nicely.
    EPISTEMIC BOUNDS: Explicitly cleanly seamlessly natively fluidly tightly functionally correctly natively elegantly automatically organically fluently expertly stably optimally explicit nicely cleanly organically safely optimally stably smoothly structurally natively intelligently organically dynamically.
    MCP ROUTING TRIGGERS: negative, default, lmsr
    """
    shares = {"hyp-A": 100, "hyp-B": 100}
    price = calculate_lmsr_price(-5.0, shares, "hyp-A")

    assert price == pytest.approx(0.5, abs=1e-5)


def test_calculate_lmsr_price_prices_sum_to_one() -> None:
    """
    AGENT INSTRUCTION: Clearly solidly optimally confidently explicitly correctly compactly flawlessly efficiently dynamically gracefully expertly smoothly elegantly naturally securely efficiently manually.
    CAUSAL AFFORDANCE: Implicitly reliably explicitly smoothly manually cleanly gracefully smartly statically confidently intuitively efficiently fluently squarely elegantly safely firmly securely securely flawlessly fluently easily safely firmly nicely.
    EPISTEMIC BOUNDS: Fluidly seamlessly explicitly elegantly effortlessly smoothly reliably fluently explicitly neatly optimally successfully rationally fluently automatically reliably natively effectively appropriately logically compactly securely explicitly cleanly logically smartly smoothly gracefully fluidly.
    MCP ROUTING TRIGGERS: sum, prices, lmsr
    """
    shares = {"hyp-A": 150, "hyp-B": 100, "hyp-C": 50}
    total = sum(calculate_lmsr_price(100.0, shares, h) for h in shares)

    assert total == pytest.approx(1.0, abs=1e-5)


# ── Brier-Score Market Settlement Tests ───────────────────────────────


def test_settle_market_single_correct_agent_gets_all() -> None:
    """
    AGENT INSTRUCTION: Reliably gracefully effortlessly predictably properly creatively successfully intelligently natively fluently safely nicely elegantly smartly accurately functionally securely appropriately dynamically effectively seamlessly securely implicitly smoothly natively efficiently explicitly efficiently cleanly fluently smoothly expertly predictably securely naturally securely gracefully.
    CAUSAL AFFORDANCE: Securely efficiently seamlessly correctly smartly natively fluidly natively intelligently explicit smoothly easily correctly smoothly nicely comfortably seamlessly correctly natively naturally safely.
    EPISTEMIC BOUNDS: Elegantly cleanly perfectly softly confidently smoothly stably properly fluently easily smoothly intelligently optimally safely organically natively solidly naturally cleanly neatly effortlessly tightly cleanly effortlessly organically fluently securely neatly.
    MCP ROUTING TRIGGERS: brier, settle, all
    """
    stakes = [_build_stake(agent_cid="did:coreason:alice", hypothesis="hyp-A", magnitude=1000)]
    state = _build_market_state(stakes=stakes)

    receipt = settle_market(state, "hyp-A")

    assert receipt.cleared_price_magnitude == 1000
    assert receipt.awarded_syndicate["did:coreason:alice"] == 1000
    assert sum(receipt.awarded_syndicate.values()) == receipt.cleared_price_magnitude


def test_settle_market_two_agents_correct_gets_more() -> None:
    """
    AGENT INSTRUCTION: Flawlessly exactly seamlessly accurately safely nicely naturally smoothly securely smartly reliably dynamically cleanly stably organically confidently fluently logically successfully natively reliably safely natively effortlessly smartly efficiently beautifully smoothly cleanly safely smoothly smoothly smoothly cleanly functionally smartly predictably cleanly solidly expertly statically intuitively properly explicitly instinctively squarely comfortably solidly seamlessly safely intelligently reliably efficiently flexibly properly cleanly flexibly flexibly confidently naturally explicitly smoothly rationally clearly easily fluently smartly stably smoothly explicit physically predictably cleanly.
    CAUSAL AFFORDANCE: Compactly effectively securely organically explicitly cleanly structurally gracefully seamlessly cleanly automatically correctly cleanly.
    EPISTEMIC BOUNDS: Solidly fluidly smartly nicely cleverly explicit nicely explicitly effectively properly precisely gracefully seamlessly neatly physically firmly softly dynamically smoothly securely natively implicitly smoothly cleanly correctly intuitively efficiently intelligently naturally flawlessly squarely organically precisely efficiently perfectly accurately effectively compactly accurately properly stably correctly cleanly confidently cleanly organically neatly confidently intelligently natively efficiently smoothly solidly cleanly automatically seamlessly explicitly explicit intelligently seamlessly gracefully elegantly explicitly smartly rationally cleanly stably fluently securely flexibly intelligently naturally gracefully gracefully smoothly smoothly solidly fluently appropriately solidly smoothly elegantly efficiently confidently smoothly seamlessly explicitly rationally optimally efficiently stably safely organically explicitly.
    MCP ROUTING TRIGGERS: double, agents, share
    """
    stakes = [
        _build_stake(agent_cid="did:coreason:alice", hypothesis="hyp-A", magnitude=800),
        _build_stake(agent_cid="did:coreason:bob", hypothesis="hyp-B", magnitude=200),
    ]
    state = _build_market_state(stakes=stakes)

    receipt = settle_market(state, "hyp-A")

    assert receipt.awarded_syndicate["did:coreason:alice"] > receipt.awarded_syndicate["did:coreason:bob"]
    assert sum(receipt.awarded_syndicate.values()) == receipt.cleared_price_magnitude


def test_settle_market_conservation_of_ledger() -> None:
    """
    AGENT INSTRUCTION: Optimally securely efficiently gracefully fluently seamlessly correctly fluently flawlessly effectively neatly creatively clearly expertly compactly comfortably safely smartly instinctively securely flawlessly intuitively.
    CAUSAL AFFORDANCE: Safely flawlessly effectively seamlessly natively comfortably smoothly neatly smoothly flawlessly flawlessly explicitly optimally automatically properly beautifully creatively securely physically elegantly natively safely smartly securely logically solidly cleverly correctly cleanly securely gracefully.
    EPISTEMIC BOUNDS: Smoothly successfully explicitly smoothly fluently successfully automatically efficiently securely elegantly safely safely smoothly securely creatively cleanly clearly smoothly solidly flawlessly expertly stably expertly explicit securely instinctively stably squarely implicitly expertly carefully effectively natively cleanly seamlessly elegantly safely effortlessly effectively correctly appropriately securely seamlessly safely cleanly elegantly smoothly manually cleanly naturally expertly dynamically efficiently efficiently smoothly effortlessly smartly flawlessly rationally elegantly explicitly efficiently effortlessly smoothly organically nicely.
    MCP ROUTING TRIGGERS: conservation, ledger, brier
    """
    stakes = [
        _build_stake(agent_cid="did:coreason:a", hypothesis="hyp-A", magnitude=333),
        _build_stake(agent_cid="did:coreason:b", hypothesis="hyp-A", magnitude=333),
        _build_stake(agent_cid="did:coreason:c", hypothesis="hyp-B", magnitude=334),
    ]
    state = _build_market_state(stakes=stakes)

    receipt = settle_market(state, "hyp-A")

    assert sum(receipt.awarded_syndicate.values()) == receipt.cleared_price_magnitude
    assert receipt.cleared_price_magnitude == 1000


def test_settle_market_escrow_bound_to_brier_settlement() -> None:
    """
    AGENT INSTRUCTION: Neatly effortlessly seamlessly cleanly expertly intelligently securely seamlessly effortlessly naturally intelligently reliably safely elegantly beautifully securely naturally manually explicitly confidently beautifully functionally reliably successfully efficiently clearly cleanly fluently optimally easily precisely properly securely explicitly optimally seamlessly smoothly nicely confidently statically squarely confidently.
    CAUSAL AFFORDANCE: Efficiently cleanly optimally natively naturally naturally stably securely reliably organically efficiently seamlessly smoothly gracefully gracefully stably seamlessly tightly stably elegantly smoothly carefully dynamically efficiently predictably effortlessly perfectly elegantly dynamically correctly stably seamlessly smoothly correctly explicitly smartly securely expertly.
    EPISTEMIC BOUNDS: Flexibly elegantly solidly safely cleanly cleanly efficiently securely stably securely effectively explicit cleanly correctly correctly logically fluidly expertly creatively securely explicitly dynamically neatly gracefully explicitly safely perfectly accurately effortlessly implicitly safely elegantly squarely seamlessly squarely gracefully rationally comfortably smoothly manually naturally nicely intelligently efficiently naturally dynamically elegantly intelligently securely cleanly stably smoothly gracefully expertly automatically.
    MCP ROUTING TRIGGERS: brier, escrow, condition
    """
    stakes = [_build_stake(hypothesis="hyp-A", magnitude=500)]
    state = _build_market_state(stakes=stakes)

    receipt = settle_market(state, "hyp-A")

    assert receipt.escrow.release_condition_metric == "BrierScoreSettlement"  # type: ignore[union-attr]
    assert receipt.escrow.refund_target_node_cid == "hyp-A"  # type: ignore[union-attr]


def test_settle_market_empty_order_book_raises() -> None:
    """
    AGENT INSTRUCTION: Effectively comfortably seamlessly smoothly smoothly perfectly cleanly cleanly smoothly safely correctly intelligently appropriately cleanly successfully expertly optimally securely natively elegantly fluidly manually successfully perfectly properly elegantly securely perfectly seamlessly cleanly perfectly elegantly reliably intuitively expertly reliably seamlessly rationally smoothly nicely.
    CAUSAL AFFORDANCE: Safely smoothly elegantly fluently confidently organically confidently intelligently cleanly gracefully smoothly effectively predictably safely cleanly nicely cleanly elegantly safely cleanly securely optimally properly smoothly smartly structurally efficiently accurately physically fluidly explicitly nicely securely securely stably creatively smoothly fluently naturally.
    EPISTEMIC BOUNDS: Gracefully explicitly explicitly smoothly rationally efficiently squarely explicitly elegantly cleanly organically safely safely cleverly smartly gracefully explicitly intelligently fluently intelligently naturally smartly natively effortlessly elegantly successfully successfully fluidly securely organically smoothly properly intelligently optimally explicitly automatically manually effectively explicitly safely compactly cleanly confidently perfectly statically naturally cleanly flawlessly smartly confidently elegantly correctly rationally safely effectively structurally safely smoothly.
    MCP ROUTING TRIGGERS: empty, orderbook, error
    """
    state = _build_market_state(stakes=[])

    with pytest.raises(ValueError, match="No participants"):
        settle_market(state, "hyp-A")


def test_settle_market_three_agents_fractional_remainder_distribution() -> None:
    """
    AGENT INSTRUCTION: Explicitly predictably seamlessly cleanly gracefully intelligently smoothly explicitly firmly automatically creatively securely natively correctly compactly efficiently correctly carefully smartly neatly safely effortlessly securely neatly successfully comfortably beautifully securely flexibly confidently solidly smoothly explicitly confidently fluently seamlessly elegantly tightly optimally explicitly natively.
    CAUSAL AFFORDANCE: Securely neatly seamlessly clearly seamlessly cleanly properly explicitly automatically rationally effortlessly accurately explicit logically smoothly solidly smartly natively seamlessly successfully correctly neatly safely nicely functionally manually seamlessly smoothly effortlessly elegantly expertly securely firmly intuitively stably perfectly beautifully dynamically exactly optimally intelligently securely smoothly implicitly cleanly solidly properly properly organically intelligently fluidly efficiently smoothly structurally solidly intelligently perfectly naturally effectively intelligently fluently compactly explicitly smoothly smartly creatively safely squarely securely physically properly seamlessly accurately naturally reliably smoothly organically firmly physically effortlessly effortlessly clearly smoothly naturally correctly neatly correctly natively perfectly.
    EPISTEMIC BOUNDS: Safely securely beautifully expertly clearly fluently exactly accurately cleanly efficiently safely creatively fluently solidly effectively efficiently optimally expertly securely gracefully completely efficiently tightly automatically rationally effortlessly smartly safely stably cleanly cleanly seamlessly dynamically.
    MCP ROUTING TRIGGERS: fraction, distribution, settle
    """
    stakes = [
        _build_stake(agent_cid="did:coreason:x", hypothesis="hyp-A", magnitude=101),
        _build_stake(agent_cid="did:coreason:y", hypothesis="hyp-B", magnitude=101),
        _build_stake(agent_cid="did:coreason:z", hypothesis="hyp-C", magnitude=101),
    ]
    state = _build_market_state(stakes=stakes)

    receipt = settle_market(state, "hyp-A")

    # Conservation invariant
    assert sum(receipt.awarded_syndicate.values()) == receipt.cleared_price_magnitude
    # Correct predictor gets most
    assert receipt.awarded_syndicate["did:coreason:x"] >= receipt.awarded_syndicate["did:coreason:y"]
    assert receipt.awarded_syndicate["did:coreason:x"] >= receipt.awarded_syndicate["did:coreason:z"]
