import asyncio
from typing import Any

import pytest
from temporalio.testing import WorkflowEnvironment

from coreason_runtime.orchestration.worker import (
    PartitionedActivityExecutor,
    _shutdown_handler,
    _vram_watchdog,
    start_worker,
)


@pytest.mark.asyncio
async def test_vram_watchdog_breach() -> None:
    """Verifies the VRAM watchdog cleanly triggers circuit beaker flags organically."""
    cancel_event = asyncio.Event()
    # Enforcing a 0 bytes physical limit immediately breaches the standard bounds natively
    await _vram_watchdog(0, cancel_event)
    assert cancel_event.is_set(), "Watchdog failed to mutate process termination flag."


@pytest.mark.asyncio
async def test_vram_watchdog_within_bounds() -> None:
    """Verifies VRAM watchdog stays asleep within physical constraints natively."""
    cancel_event = asyncio.Event()
    # 1 Petabyte limit prevents breaches locally
    task = asyncio.create_task(_vram_watchdog(1024**5, cancel_event))
    await asyncio.sleep(0.1)
    assert not cancel_event.is_set()
    cancel_event.set()
    await task


def test_partitioned_activity_executor_success() -> None:
    """Tests the partition framework locally without temporal execution context."""
    executor = PartitionedActivityExecutor(max_workers=2)

    def dummy_func() -> int:
        return 42

    res = executor.submit(dummy_func)
    assert res.result(timeout=1.0) == 42


def test_partitioned_activity_executor_temporal_context() -> None:
    """Tests the partition executor successfully binding to temporal activity hashes."""
    import dataclasses
    from unittest.mock import patch

    @dataclasses.dataclass
    class MockInfo:
        workflow_id: str = "test-temporal-hash-wf"

    executor = PartitionedActivityExecutor(max_workers=4)

    def compute_val() -> str:
        return "success"

    with patch("temporalio.activity.info", return_value=MockInfo()):
        res = executor.submit(compute_val)
        assert res.result(timeout=1.0) == "success"


@pytest.mark.asyncio
async def test_shutdown_handler_organically() -> None:
    """Validates _shutdown_handler mapping structure without invoking underlying C extensions natively."""

    class StubKineticActivities:
        def __init__(self) -> None:
            self.store = self

        async def close(self) -> None:
            self.closed = True

    class StubWorker:
        def __init__(self) -> None:
            self.shutdown_invoked = False

        async def shutdown(self) -> None:
            self.shutdown_invoked = True

    worker = StubWorker()
    activities = StubKineticActivities()

    await _shutdown_handler(worker, activities)

    assert worker.shutdown_invoked is True
    assert getattr(activities, "closed", False) is True


@pytest.mark.asyncio
async def test_shutdown_handler_swallows_exception() -> None:
    """Validates _shutdown_handler absorbs failures natively keeping the engine alive safely."""

    class ExceptionWorker:
        async def shutdown(self) -> None:
            raise RuntimeError("Simulated temporal destruction limit reached.")

    class EmptyActivities:
        pass

    worker = ExceptionWorker()
    activities = EmptyActivities()

    # The handler natively suppresses crashes under logger blocks
    await _shutdown_handler(worker, activities)


@pytest.mark.asyncio
async def test_vram_watchdog_gpu_logic() -> None:
    import asyncio
    import sys
    import types

    pynvml = types.ModuleType("pynvml")

    def nvmlInit() -> None:
        return None

    def nvmlDeviceGetHandleByIndex(idx: int) -> int:
        return 42

    class Info:
        used = 1000

    def nvmlDeviceGetMemoryInfo(handle: int) -> Info:
        return Info()

    pynvml.nvmlInit = nvmlInit  # type: ignore
    pynvml.nvmlDeviceGetHandleByIndex = nvmlDeviceGetHandleByIndex  # type: ignore
    pynvml.nvmlDeviceGetMemoryInfo = nvmlDeviceGetMemoryInfo  # type: ignore

    sys.modules["pynvml"] = pynvml

    cancel_event = asyncio.Event()
    try:
        await _vram_watchdog(0, cancel_event)
        assert cancel_event.is_set()
    finally:
        if "pynvml" in sys.modules:
            del sys.modules["pynvml"]


@pytest.mark.asyncio
async def test_vram_watchdog_gpu_exception_logic() -> None:
    import sys
    import types

    pynvml = types.ModuleType("pynvml")

    def nvmlInit() -> None:
        return None

    def nvmlDeviceGetHandleByIndex(idx: int) -> int:
        return 42

    def nvmlDeviceGetMemoryInfo(handle: int) -> Any:
        raise RuntimeError("GPU Polling Failure")

    pynvml.nvmlInit = nvmlInit  # type: ignore
    pynvml.nvmlDeviceGetHandleByIndex = nvmlDeviceGetHandleByIndex  # type: ignore
    pynvml.nvmlDeviceGetMemoryInfo = nvmlDeviceGetMemoryInfo  # type: ignore

    sys.modules["pynvml"] = pynvml

    cancel_event = asyncio.Event()
    try:
        task = asyncio.create_task(_vram_watchdog(1024**5, cancel_event))
        await asyncio.sleep(0.5)
        cancel_event.set()
        await task
    finally:
        if "pynvml" in sys.modules:
            del sys.modules["pynvml"]


@pytest.mark.asyncio
async def test_vram_watchdog_polling_error() -> None:
    import asyncio
    from unittest.mock import patch

    cancel_event = asyncio.Event()

    # Throw Exception from psutil natively reaching the logger warning boundary natively
    with patch("psutil.Process", side_effect=RuntimeError("Physical memory access exception spoofed")):
        task = asyncio.create_task(_vram_watchdog(20000000, cancel_event))
        await asyncio.sleep(1.5)
        # Assuming logger warning logged successfully gracefully!
        cancel_event.set()
        await task


def test_worker_main_execution() -> None:
    import runpy
    from unittest.mock import patch

    with patch("coreason_runtime.orchestration.worker.start_worker"):
        with patch("asyncio.run") as mock_run:
            runpy.run_module("coreason_runtime.orchestration.worker", run_name="__main__", alter_sys=True)
            assert mock_run.called


@pytest.mark.asyncio
async def test_start_worker_lifecycle(monkeypatch: Any, tmp_path: Any) -> None:
    """Evaluates the fully isolated worker deployment sequence mapped entirely natively.
    Signals the running framework using SIGUSR1 reproducing physical interrupt thresholds.
    """
    async with await WorkflowEnvironment.start_time_skipping() as env:
        lancedb_uri = str(tmp_path / "mock_latent_memory")
        monkeypatch.setenv("LANCEDB_URI", lancedb_uri)

        class MockClientConnect:
            async def __call__(self, *_args: Any, **_kwargs: Any) -> Any:
                return env.client

        monkeypatch.setattr("coreason_runtime.orchestration.worker.Client.connect", MockClientConnect())

        # Start the worker organically bridging physical process blocks
        task = asyncio.create_task(start_worker("dummy:7233"))

        # Wait for activity schemas and workflow dispatchers to lock safely
        await asyncio.sleep(1.0)

        # Trigger temporal graceful teardown without exception masking
        task.cancel()

        try:
            await task
        except asyncio.CancelledError:
            pass
