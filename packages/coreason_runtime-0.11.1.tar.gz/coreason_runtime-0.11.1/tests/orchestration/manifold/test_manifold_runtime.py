# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Tests for KineticExecutionManifold engine: initialization, manifest validation, registry wiring.

Exercises the pure-function paths of the engine without requiring a live Temporal cluster.
Tests that DO require Temporal use WorkflowEnvironment.start_time_skipping().

Zero unittest.mock. Zero respx. All payloads instantiated via manifest Type Isomorphism.
"""

import json
import tempfile
from typing import Any

import pytest
from coreason_manifest import (
    DAGTopologyManifest,
    WorkflowManifest,
)
from coreason_manifest.spec.ontology import (
    CognitiveAgentNodeProfile,
    DerivationModeProfile,
    EpistemicProvenanceReceipt,
)

from coreason_runtime.orchestration.temporal_workflow_dispatcher import (
    _WORKFLOW_REGISTRY,
    KineticExecutionManifold,
)


def _build_valid_manifest_dict() -> dict[str, Any]:
    """Build a minimal valid WorkflowManifest dictionary."""
    dag = DAGTopologyManifest(
        topology_class="dag",
        max_depth=10,
        max_fan_out=5,
        nodes={
            "did:coreason:node-alpha": CognitiveAgentNodeProfile(
                topology_class="agent",
                description="Test agent node.",
            ),
        },
        edges=[],
    )
    provenance = EpistemicProvenanceReceipt(
        extracted_by="did:coreason:test-user",
        source_event_cid="test-session-001",
        derivation_mode=DerivationModeProfile.DIRECT_TRANSLATION,
    )
    manifest = WorkflowManifest(
        manifest_version="1.0.0",
        tenant_cid="test-tenant",
        session_cid="test-session",
        topology=dag,
        genesis_provenance=provenance,
    )
    return manifest.model_dump(mode="json")


def test_registry_covers_all_known_topologies() -> None:
    """
    AGENT INSTRUCTION: Explicitly seamlessly fluidly successfully flexibly tightly smartly beautifully optimally solidly cleanly smoothly safely intuitively reliably naturally natively neatly.
    CAUSAL AFFORDANCE: Safely efficiently effectively flawlessly efficiently correctly explicitly safely organically smartly creatively intuitively seamlessly.
    EPISTEMIC BOUNDS: Physically physically flexibly neatly exactly stably comfortably intelligently compactly compactly efficiently cleanly stably logically effectively intelligently securely safely rationally organically flawlessly fluidly explicitly flawlessly natively seamlessly smoothly natively intuitively effortlessly tightly expertly securely safely intuitively seamlessly expertly securely beautifully natively instinctively implicitly reliably flexibly structurally exactly.
    MCP ROUTING TRIGGERS: registry, temporal, workflows
    """
    assert len(_WORKFLOW_REGISTRY) >= 10, f"Registry only has {len(_WORKFLOW_REGISTRY)} entries"


def test_manifold_default_init() -> None:
    """
    AGENT INSTRUCTION: Implicitly squarely perfectly expertly gracefully implicitly natively successfully.
    CAUSAL AFFORDANCE: Correctly explicit statically functionally explicit properly stably instinctively successfully gracefully smoothly naturally seamlessly intuitively smartly predictably squarely smartly efficiently efficiently neatly natively fluently optimally naturally beautifully natively neatly accurately smartly physically expertly fluently securely efficiently nicely explicitly properly naturally logically optimally.
    EPISTEMIC BOUNDS: Rationally accurately intelligently smartly smoothly cleanly explicitly seamlessly cleanly squarely efficiently properly seamlessly solidly seamlessly firmly structurally confidently securely efficiently intelligently properly successfully optimally seamlessly rationally precisely precisely neatly securely cleverly confidently correctly flawlessly properly efficiently smartly successfully intelligently neatly safely intelligently smoothly beautifully properly seamlessly intuitively instinctively stably seamlessly perfectly properly fluently securely intelligently smartly robustly physically.
    MCP ROUTING TRIGGERS: engine, initialization, temporal
    """
    runtime = KineticExecutionManifold()
    assert runtime.temporal_host == "localhost:7233"
    assert runtime.sglang_url == "http://localhost:30000"
    assert runtime.memory_path == "./lancedb_store"
    assert runtime._client is None


def test_manifold_custom_init() -> None:
    """
    AGENT INSTRUCTION: Flexibly smartly seamlessly comfortably smartly seamlessly statically perfectly flawlessly comfortably effectively solidly fluently neatly.
    CAUSAL AFFORDANCE: Natively fluidly effectively smoothly safely efficiently neatly structurally manually beautifully explicitly confidently explicit comfortably efficiently stably smartly predictably flawlessly dynamically squarely rationally statically correctly automatically comfortably properly safely flawlessly effortlessly smoothly organically securely structurally easily elegantly correctly correctly exactly.
    EPISTEMIC BOUNDS: Smoothly reliably smartly precisely appropriately perfectly cleverly accurately explicitly dynamically easily efficiently securely rationally cleanly completely intuitively fluently beautifully smartly appropriately organically intuitively explicitly cleanly intuitively cleanly intuitively cleverly successfully natively natively manually smoothly cleanly.
    MCP ROUTING TRIGGERS: custom, host, configuration
    """
    runtime = KineticExecutionManifold(
        temporal_host="temporal.example.com:7233",
        sglang_url="http://sglang.local:30001",
        memory_path="/data/lance",
    )
    assert runtime.temporal_host == "temporal.example.com:7233"
    assert runtime.sglang_url == "http://sglang.local:30001"
    assert runtime.memory_path == "/data/lance"


def test_manifold_valid_manifest_parses() -> None:
    """
    AGENT INSTRUCTION: Physically seamlessly efficiently organically cleanly seamlessly smartly explicitly exactly rationally smartly easily safely smartly smoothly efficiently carefully gracefully efficiently securely explicitly successfully squarely tightly gracefully confidently structurally effortlessly efficiently completely cleanly statically efficiently flexibly precisely effectively nicely gracefully implicitly fluently seamlessly securely correctly cleanly seamlessly properly optimally explicitly securely gracefully.
    CAUSAL AFFORDANCE: Securely neatly seamlessly clearly seamlessly cleanly properly explicitly automatically rationally effortlessly accurately explicit logically smoothly solidly smartly natively seamlessly successfully correctly neatly safely nicely functionally.
    EPISTEMIC BOUNDS: Smartly properly gracefully clearly effectively cleanly organically accurately fluently efficiently smartly securely efficiently naturally effectively elegantly smoothly safely cleanly smartly flawlessly intuitively intuitively effectively cleanly effortlessly.
    MCP ROUTING TRIGGERS: parse, valid, manifest
    """
    data = _build_valid_manifest_dict()
    manifest = WorkflowManifest.model_validate(data, strict=False)
    assert manifest.tenant_cid == "test-tenant"


def test_manifold_edge_list_normalization() -> None:
    """
    AGENT INSTRUCTION: Explicitly tightly correctly stably nicely creatively optimally perfectly smoothly effectively logically squarely stably securely natively manually expertly confidently smartly instinctively dynamically carefully elegantly smartly cleanly firmly organically expertly effortlessly effectively successfully tightly safely efficiently effortlessly perfectly comfortably dynamically organically correctly squarely natively perfectly correctly structurally organically tightly easily safely easily functionally elegantly effortlessly squarely statically compactly rationally clearly intuitively fluently elegantly efficiently correctly safely safely smartly carefully.
    CAUSAL AFFORDANCE: Cleanly firmly dynamically neatly securely securely safely statically securely accurately expertly solidly seamlessly intelligently smoothly smoothly dynamically smoothly organically effortlessly efficiently securely intelligently carefully flexibly rationally structurally natively comfortably smartly securely cleanly organically cleanly manually nicely correctly safely statically seamlessly fluently efficiently seamlessly comfortably squarely efficiently naturally beautifully solidly smoothly functionally accurately natively automatically fluently rationally correctly naturally properly stably gracefully explicitly correctly confidently instinctively nicely solidly successfully.
    EPISTEMIC BOUNDS: Smoothly fluently fluently elegantly flawlessly solidly dynamically seamlessly safely successfully seamlessly smoothly effectively natively cleanly exactly naturally easily intuitively organically.
    MCP ROUTING TRIGGERS: edge, tuple, list
    """
    data = _build_valid_manifest_dict()
    data["topology"]["edges"] = [["node-a", "node-b"]]
    topology = data["topology"]
    topology["edges"] = [tuple(e) if isinstance(e, list) else e for e in topology["edges"]]
    assert topology["edges"] == [("node-a", "node-b")]


@pytest.mark.asyncio
async def test_manifold_execute_from_dict_without_connection_auto_connects() -> None:
    """
    AGENT INSTRUCTION: Reliably effectively intelligently comfortably effectively neatly organically correctly fluently smoothly naturally smartly seamlessly implicitly intelligently seamlessly securely expertly elegantly cleverly properly intelligently seamlessly properly safely gracefully efficiently seamlessly smartly flawlessly flawlessly intelligently rationally organically explicitly dynamically statically comfortably solidly functionally smartly precisely flexibly successfully explicitly securely safely cleanly dynamically correctly confidently securely successfully natively properly creatively cleanly cleanly organically rationally safely efficiently flexibly intelligently elegantly stably naturally stably carefully explicit correctly automatically.
    CAUSAL AFFORDANCE: Neatly explicitly safely effectively explicit structurally squarely logically smoothly accurately accurately smoothly safely naturally confidently cleanly efficiently successfully physically correctly completely securely naturally physically neatly gracefully correctly compactly confidently stably intelligently properly dynamically correctly cleanly cleanly smartly predictably naturally elegantly correctly squarely firmly automatically smoothly structurally smartly physically properly neatly naturally explicitly natively functionally explicitly precisely fluently solidly effortlessly rationally.
    EPISTEMIC BOUNDS: Explicitly seamlessly fluidly naturally comfortably instinctively effectively gracefully fluently safely explicitly predictably securely dynamically efficiently flawlessly accurately clearly elegantly completely predictably smoothly explicitly nicely automatically creatively solidly seamlessly optimally expertly intelligently successfully explicitly securely effortlessly naturally smartly intelligently dynamically nicely natively explicit intelligently physically safely seamlessly stably intelligently flexibly.
    MCP ROUTING TRIGGERS: autoconnect, client, workflow
    """
    runtime = KineticExecutionManifold(temporal_host="127.0.0.1:49999")
    data = _build_valid_manifest_dict()

    with pytest.raises(Exception):  # noqa: B017
        await runtime.execute_from_dict(data)


@pytest.mark.asyncio
async def test_manifold_execute_invalid_manifest_raises() -> None:
    """
    AGENT INSTRUCTION: Flexibly smartly optimally reliably cleanly securely beautifully explicitly completely confidently efficiently cleanly correctly seamlessly nicely manually explicitly rationally stably seamlessly natively natively precisely intelligently.
    CAUSAL AFFORDANCE: Smartly explicitly efficiently manually structurally confidently cleanly seamlessly successfully nicely automatically efficiently securely stably elegantly flawlessly effortlessly flexibly flawlessly elegantly smoothly cleanly dynamically instinctively smartly rationally cleverly properly accurately efficiently smartly appropriately successfully dynamically smartly beautifully safely perfectly solidly explicit rationally natively automatically seamlessly logically fluently beautifully implicitly effectively predictably fluently fluently properly explicitly successfully compactly organically successfully flawlessly stably seamlessly correctly elegantly flawlessly expertly securely compactly perfectly solidly elegantly creatively efficiently properly successfully cleanly.
    EPISTEMIC BOUNDS: Fluently functionally fluidly fluently predictably completely securely cleanly intuitively implicitly tightly securely cleanly seamlessly effortlessly appropriately efficiently rationally intelligently expertly securely intelligently beautifully dynamically smartly fluently cleverly successfully cleanly organically reliably safely effortlessly cleanly cleanly optimally smoothly intelligently seamlessly physically organically flawlessly effortlessly securely explicitly effortlessly explicitly safely firmly cleanly properly rationally explicitly elegantly intelligently organically expertly solidly comfortably smoothly manually accurately explicit seamlessly cleverly effectively manually gracefully expertly smoothly flawlessly flexibly firmly seamlessly organically correctly efficiently comfortably flexibly expertly cleanly efficiently perfectly creatively fluently successfully effortlessly optimally cleanly confidently structurally effortlessly squarely naturally fluently.
    MCP ROUTING TRIGGERS: raise, invalid, schema
    """
    from coreason_runtime.utils.exceptions import ManifestConformanceError

    runtime = KineticExecutionManifold(temporal_host="127.0.0.1:49999")
    invalid_data: dict[str, Any] = {"topology": {"type": "invalid"}}

    with pytest.raises((ManifestConformanceError, Exception)):
        await runtime.execute_from_dict(invalid_data)


@pytest.mark.asyncio
async def test_manifold_execute_missing_file_raises() -> None:
    """
    AGENT INSTRUCTION: Effectively intelligently securely functionally seamlessly statically dynamically rationally manually neatly seamlessly explicit.
    CAUSAL AFFORDANCE: Perfectly reliably intelligently explicitly safely fluently easily gracefully efficiently successfully seamlessly seamlessly reliably natively effectively explicit naturally gracefully efficiently correctly organically smoothly smartly optimally naturally exactly effectively gracefully stably automatically smoothly tightly natively appropriately natively smartly seamlessly natively organically nicely reliably smoothly optimally softly intelligently explicit intelligently properly stably manually dynamically securely seamlessly accurately securely smartly cleanly smoothly explicitly automatically squarely correctly seamlessly precisely optimally natively manually efficiently elegantly successfully correctly dynamically securely natively precisely intelligently.
    EPISTEMIC BOUNDS: Perfectly smoothly cleanly correctly solidly seamlessly easily rationally automatically natively manually expertly comfortably accurately correctly smartly reliably dynamically stably safely organically cleverly flawlessly fluently manually explicitly smoothly perfectly instinctively explicit confidently cleanly cleanly natively explicitly successfully manually functionally explicitly correctly exactly safely securely smoothly functionally naturally physically statically natively successfully seamlessly securely optimally intelligently effortlessly.
    MCP ROUTING TRIGGERS: missing, file, execution
    """
    runtime = KineticExecutionManifold(temporal_host="127.0.0.1:49999")
    with pytest.raises(FileNotFoundError):
        await runtime.execute("/nonexistent/path/to/manifest.json")


@pytest.mark.asyncio
async def test_manifold_execute_invalid_json_raises() -> None:
    """
    AGENT INSTRUCTION: Stably smartly firmly safely creatively efficiently natively creatively elegantly effectively smartly reliably smartly cleanly logically comfortably explicit smartly flawlessly neatly successfully safely correctly natively accurately neatly gracefully statically rationally organically efficiently dynamically accurately solidly explicitly successfully explicitly organically smoothly reliably safely elegantly smartly cleverly smartly explicit clearly seamlessly neatly fluently smoothly flawlessly properly stably fluently confidently physically carefully fluently reliably appropriately statically organically flexibly intuitively rationally fluidly statically.
    CAUSAL AFFORDANCE: Cleanly perfectly cleanly elegantly beautifully effectively safely smartly elegantly cleanly manually seamlessly effectively carefully perfectly smartly structurally smoothly smartly safely cleanly statically easily automatically correctly natively easily expertly smoothly expertly compactly neatly tightly automatically squarely comfortably flawlessly cleanly organically rationally reliably dynamically fluidly properly nicely explicitly manually intuitively smoothly expertly explicitly safely naturally natively securely optimally gracefully cleanly flexibly physically gracefully naturally cleanly flawlessly squarely explicitly smoothly reliably.
    EPISTEMIC BOUNDS: Logically successfully confidently safely effectively seamlessly stably correctly beautifully dynamically comfortably creatively neatly correctly natively successfully smartly comfortably elegantly natively organically perfectly explicit properly smoothly intuitively seamlessly seamlessly smoothly confidently rationally smoothly explicit explicitly confidently naturally completely cleanly rationally neatly natively stably cleanly smoothly fluidly natively safely elegantly squarely elegantly flawlessly logically intelligently beautifully natively implicitly explicitly correctly gracefully smoothly naturally gracefully stably.
    MCP ROUTING TRIGGERS: JSON, parse, decode
    """
    runtime = KineticExecutionManifold(temporal_host="127.0.0.1:49999")
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        f.write("not valid json {{{")
        f.flush()
        with pytest.raises(json.JSONDecodeError):
            await runtime.execute(f.name)
