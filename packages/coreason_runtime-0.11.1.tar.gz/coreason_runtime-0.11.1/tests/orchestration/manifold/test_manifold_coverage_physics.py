# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License") # pragma: no cover
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import concurrent.futures
import json
import os
from typing import Any, cast

import httpx
import pytest
from temporalio import activity, workflow
from temporalio.client import WorkflowFailureError
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.temporal_workflow_dispatcher import KineticExecutionManifold
from coreason_runtime.orchestration.worker import TASK_QUEUE
from coreason_runtime.orchestration.workflows.dag_execution_workflow import DAGExecutionWorkflow


@activity.defn(name="StoreEpistemicStateIOActivity")
async def stub_store_epistemic(*args: Any) -> None:
    pass


@activity.defn(name="ExecuteTensorInferenceComputeActivity")
async def stub_execute_tensor(*args: Any) -> dict[str, Any]:
    return {
        "status": "success",
        "outputs": {"result": "ok"},
        "intent_hash": "hash1",
        "usage": {"total_tokens": 10},
        "cost": 0.5,
        "success": True,
    }


@activity.defn(name="RecordTokenBurnIOActivity")
async def stub_record_burn(*args: Any) -> None:
    pass


@activity.defn(name="ApplyDefeasibleCascadeComputeActivity")
async def stub_cascade(*args: Any) -> None:
    pass


@activity.defn(name="ExecuteRollbackIOActivity")
async def stub_rollback(*args: Any) -> None:
    pass


@activity.defn(name="FetchMemoizedStateIOActivity")
async def stub_memo(*args: Any) -> dict[str, Any] | None:
    return None


@activity.defn(name="ExecuteSystemFunctionComputeActivity")
async def stub_sys_func(*args: Any) -> dict[str, Any]:
    return {"status": "success"}


@workflow.defn
class DummyNoneWorkflow:
    @workflow.run
    async def run(self, _envelope: dict[str, Any]) -> Any:
        return None


@workflow.defn
class DummyStringWorkflow:
    @workflow.run
    async def run(self, _envelope: dict[str, Any]) -> Any:
        return "not_a_dict"


ALL_STUBS = [
    stub_store_epistemic,
    stub_execute_tensor,
    stub_record_burn,
    stub_cascade,
    stub_rollback,
    stub_memo,
    stub_sys_func,
]


async def asgi_app(scope: Any, receive: Any, send: Any) -> None:
    assert scope["type"] == "http"
    if scope["method"] == "POST":
        body = b""
        more_body = True
        while more_body:
            message = await receive()
            body += message.get("body", b"")
            more_body = message.get("more_body", False)

        path = scope["path"]
        response_body: dict[str, Any] = {}
        if "transmute" in path:
            response_body = {"success": True, "rust_efficiency_multiplier": 2.0}
        elif "publish" in path:
            response_body = {"urn": "urn:did:coreason:mcp:test"}
        else:
            response_body = {"status": "unknown"}

        await send(
            {
                "type": "http.response.start",
                "status": 200,
                "headers": [(b"content-type", b"application/json")],
            }
        )
        await send(
            {
                "type": "http.response.body",
                "body": json.dumps(response_body).encode("utf-8"),
            }
        )


@pytest.fixture
def mock_transport() -> httpx.ASGITransport:
    return httpx.ASGITransport(app=asgi_app)


@pytest.fixture
def failing_transport() -> httpx.AsyncHTTPTransport:
    # Closed port to trigger httpx.RequestError naturally
    return httpx.AsyncHTTPTransport(local_address="127.0.0.1")


def _build_valid_manifest_dict(topology_class: str = "dag") -> dict[str, Any]:
    """Build a minimal valid WorkflowManifest dictionary."""

    provenance_dict = {
        "extracted_by": "did:coreason:test-user",
        "source_event_cid": "test-session-001",
        "derivation_mode": "direct_translation",
    }

    topo_dict: dict[str, Any] = {}
    if topology_class == "dag":
        topo_dict = {
            "topology_class": "dag",
            "max_depth": 10,
            "max_fan_out": 5,
            "nodes": {
                "did:coreason:node-alpha": {
                    "topology_class": "agent",
                    "description": "Test agent node.",
                },
            },
            "edges": [],
            "allow_cycles": False,
        }
    else:
        topo_dict = {
            "topology_class": "swarm",
            "spawning_threshold": 1,
            "nodes": {},
        }

    payload = {
        "manifest_version": "1.0.0",
        "tenant_cid": "test-tenant",
        "session_cid": "test-session",
        "topology": topo_dict,
        "genesis_provenance": provenance_dict,
    }

    # Natively inject previously unreached logic boundaries
    payload["allowed_semantic_classifications"] = ["public"]
    payload["governance"] = {
        "mandatory_license_rule": {
            "rule_cid": "rule-1",
            "description": "desc",
            "severity": "critical",
            "forbidden_intents": [],
        },
        "max_budget_magnitude": 1000,
        "max_global_tokens": 1000,
        "global_timeout_seconds": 100,
    }

    if topology_class == "composite":
        # Force composite AFTER dumping so swarm dump succeeds, composite tests fallback to lanceDB natively
        payload["topology"]["topology_class"] = "composite"  # type: ignore[index]
    elif topology_class == "UNKNOWN_SYS":
        payload["topology"]["topology_class"] = "UNKNOWN_SYS"  # type: ignore[index]

    return payload


@workflow.defn(name="DummySwarmWorkflow")
class DummySwarmWorkflow:
    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        _ = payload
        return {"status": "success", "success": True, "manifest": {"server_cid": "crystalline_test-session"}}


@pytest.mark.asyncio
async def test_manifold_execute_full_coverage(mock_transport: httpx.ASGITransport) -> None:
    """
    AGENT INSTRUCTION: Validates the end-to-end execution of a standard DAG topology.
    CAUSAL AFFORDANCE: Proves the KineticExecutionManifold can natively dispatch native dictionary schemas.
    EPISTEMIC BOUNDS: Operates physically via Temporal time-skipping and ASGI dummy transports.
    MCP ROUTING TRIGGERS: temporal_orchestration, dag_execution, physical_coverage
    """
    async with await WorkflowEnvironment.start_time_skipping() as env:
        engine = KineticExecutionManifold(network_transport=mock_transport)
        engine._client = env.client

        async with Worker(
            env.client,
            task_queue=TASK_QUEUE,
            workflows=[DAGExecutionWorkflow],
            activities=ALL_STUBS,
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            payload = _build_valid_manifest_dict("dag")
            res = await engine.execute_from_dict(payload, exogenous_perturbation_vector="PERTURB")
            assert res.get("status") == "success"


@pytest.mark.asyncio
async def test_manifold_execute_swarm_ecosystem_publish(mock_transport: httpx.ASGITransport) -> None:
    """
    AGENT INSTRUCTION: Verifies the propagation of swarm execution state to the master ecosystem registry.
    CAUSAL AFFORDANCE: Ensures successful semantic node promotion is crystallized upon ecosystem handshake.
    EPISTEMIC BOUNDS: Leverages mock ASGI transport to simulate successful HTTP 200 payload returns.
    MCP ROUTING TRIGGERS: swarm, publish, ecosystem
    """
    async with await WorkflowEnvironment.start_time_skipping() as env:
        engine = KineticExecutionManifold(network_transport=mock_transport)
        engine._client = env.client

        async with Worker(
            env.client,
            task_queue=TASK_QUEUE,
            workflows=[DummySwarmWorkflow],
            activities=ALL_STUBS,
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            payload = _build_valid_manifest_dict("swarm")
            from coreason_runtime.orchestration.temporal_workflow_dispatcher import _WORKFLOW_REGISTRY

            orig_swarm = _WORKFLOW_REGISTRY.get("swarm")
            _WORKFLOW_REGISTRY["swarm"] = DummySwarmWorkflow.run

            try:
                res = await engine.execute_from_dict(payload)
                assert "_crystalized_promotion" in res
                assert res["_crystalized_promotion"]["crystallized_semantic_node_cid"] == "crystalline_test-session"
            finally:
                if orig_swarm:
                    _WORKFLOW_REGISTRY["swarm"] = orig_swarm
                else:
                    del _WORKFLOW_REGISTRY["swarm"]


@pytest.mark.asyncio
async def test_manifold_execute_swarm_ecosystem_connection_error(failing_transport: httpx.AsyncHTTPTransport) -> None:
    """
    AGENT INSTRUCTION: Verifies the fallback logic when the global ecosystem registry is partitioned.
    CAUSAL AFFORDANCE: Guarantees offline resilience by routing Master MCP publication to local LanceDB.
    EPISTEMIC BOUNDS: Physically binds httpx transport to a dead port to natively trigger RequestError.
    MCP ROUTING TRIGGERS: fault_tolerance, network_partition, lancedb_fallback, error_handling
    """
    orig_env = os.environ.get("ECOSYSTEM_REGISTRY_URL")
    os.environ["ECOSYSTEM_REGISTRY_URL"] = "http://127.0.0.1:44445"

    try:
        async with await WorkflowEnvironment.start_time_skipping() as env:
            engine = KineticExecutionManifold(network_transport=failing_transport)
            engine._client = env.client

            async with Worker(
                env.client,
                task_queue=TASK_QUEUE,
                workflows=[DummySwarmWorkflow],
                activities=ALL_STUBS,
                workflow_runner=UnsandboxedWorkflowRunner(),
                activity_executor=concurrent.futures.ThreadPoolExecutor(),
            ):
                payload = _build_valid_manifest_dict("swarm")
                from coreason_runtime.orchestration.temporal_workflow_dispatcher import _WORKFLOW_REGISTRY

                orig_swarm = _WORKFLOW_REGISTRY.get("swarm")
                _WORKFLOW_REGISTRY["swarm"] = DummySwarmWorkflow.run

                try:
                    res = await engine.execute_from_dict(payload)
                    assert "_crystalized_promotion" in res
                finally:
                    if orig_swarm:
                        _WORKFLOW_REGISTRY["swarm"] = orig_swarm
                    else:
                        del _WORKFLOW_REGISTRY["swarm"]
    finally:
        if orig_env is None:
            del os.environ["ECOSYSTEM_REGISTRY_URL"]
        else:
            os.environ["ECOSYSTEM_REGISTRY_URL"] = orig_env


@pytest.mark.asyncio
async def test_manifold_execute_fails_workflow_registry() -> None:
    """
    AGENT INSTRUCTION: Tests the failure mode when a workflow type is completely absent from the dispatcher registry.
    CAUSAL AFFORDANCE: Asserts that invalid topologies immediately raise ValueError rather than hanging execution.
    EPISTEMIC BOUNDS: Directly mutates the global _WORKFLOW_REGISTRY to simulate a misconfiguration locally.
    MCP ROUTING TRIGGERS: registry_validation, exception_handling, temporal_dispatcher
    """
    async with await WorkflowEnvironment.start_time_skipping() as env:
        engine = KineticExecutionManifold()
        engine._client = env.client
        payload = _build_valid_manifest_dict("dag")

        from coreason_runtime.orchestration.temporal_workflow_dispatcher import _WORKFLOW_REGISTRY

        orig = _WORKFLOW_REGISTRY.pop("dag", None)
        try:
            with pytest.raises(ValueError, match="Unknown or missing manifest type: dag"):
                await engine.execute_from_dict(payload)
        finally:
            if orig:
                _WORKFLOW_REGISTRY["dag"] = orig


@pytest.mark.asyncio
async def test_manifold_execute_temporal_failure() -> None:
    """
    AGENT INSTRUCTION: Verifies the propagation of native activity failures up through the DAG.
    CAUSAL AFFORDANCE: Propagates internal RuntimeError exceptions natively via WorkflowFailureError wrappers.
    EPISTEMIC BOUNDS: Injects a failing activity mock structurally inside the Worker boundaries.
    MCP ROUTING TRIGGERS: activity_failure, temporal_propagation, exception_mapping
    """

    @activity.defn(name="StoreEpistemicStateIOActivity")
    async def bad_store(*args: Any) -> None:
        raise RuntimeError("BudgetExhaustion")

    async with await WorkflowEnvironment.start_time_skipping() as env:
        engine = KineticExecutionManifold()
        engine._client = env.client

        async with Worker(
            env.client,
            task_queue=TASK_QUEUE,
            workflows=[DAGExecutionWorkflow],
            activities=[a for a in ALL_STUBS if getattr(a, "__name__", "") != "stub_store_epistemic"] + [bad_store],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            payload = _build_valid_manifest_dict("dag")

            with pytest.raises(WorkflowFailureError):
                await engine.execute_from_dict(payload)


@pytest.mark.asyncio
async def test_manifold_empty_dict_fallback() -> None:
    """
    AGENT INSTRUCTION: Asserts defensive parsing when workflow handlers return arbitrary non-dictionary primitives.
    CAUSAL AFFORDANCE: Guarantees that internal engine states cannot be corrupted by void workflow returns.
    EPISTEMIC BOUNDS: Mutates registry inline to test string and NoneType outputs under sandbox confinement.
    MCP ROUTING TRIGGERS: structural_safety, dictionary_parsing, null_pointer_prevention
    """
    async with await WorkflowEnvironment.start_time_skipping() as env:
        engine = KineticExecutionManifold()
        engine._client = env.client
        payload = _build_valid_manifest_dict("dag")

        from coreason_runtime.orchestration.temporal_workflow_dispatcher import _WORKFLOW_REGISTRY

        orig_dag = _WORKFLOW_REGISTRY.get("dag")

        try:
            _WORKFLOW_REGISTRY["dag"] = DummyNoneWorkflow.run

            async with Worker(
                env.client,
                task_queue="coreason-kinetic-queue",
                workflows=[DummyNoneWorkflow],
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                res = await engine.execute_from_dict(payload)
                assert res == {}

            _WORKFLOW_REGISTRY["dag"] = DummyStringWorkflow.run

            async with Worker(
                env.client,
                task_queue="coreason-kinetic-queue",
                workflows=[DummyStringWorkflow],
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                res2 = await engine.execute_from_dict(payload)
                assert res2 == {}

        finally:
            if orig_dag:
                _WORKFLOW_REGISTRY["dag"] = orig_dag


@pytest.mark.asyncio
async def test_manifold_execute_file(tmp_path: Any) -> None:
    """
    AGENT INSTRUCTION: Validates filesystem-based payload instantiation for the KineticExecutionManifold.
    CAUSAL AFFORDANCE: Ensures path routing physically loads JSON payloads without memory loss natively.
    EPISTEMIC BOUNDS: Utilizes pytest tmp_path fixtures to safely mount synthetic payloads directly.
    MCP ROUTING TRIGGERS: filesystem_io, json_parsing, dispatcher_routing
    """
    p = tmp_path / "manifest.json"
    data = _build_valid_manifest_dict("dag")
    p.write_text(json.dumps(data))

    async with await WorkflowEnvironment.start_time_skipping() as env:
        engine = KineticExecutionManifold()
        engine._client = env.client

        async with Worker(
            env.client,
            task_queue=TASK_QUEUE,
            workflows=[DAGExecutionWorkflow],
            activities=ALL_STUBS,
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            res = await engine.execute(str(p))
            assert res.get("status") == "success"


@pytest.mark.asyncio
async def test_manifold_execute_file_not_found() -> None:
    """
    AGENT INSTRUCTION: Verifies hard errors on invalid external filesystem paths correctly.
    CAUSAL AFFORDANCE: Maps physical OS errors up the topological chain explicitly without stalling natively.
    EPISTEMIC BOUNDS: Asserts standard FileNotFoundError locally via absolute dummy missing paths easily.
    MCP ROUTING TRIGGERS: file_system, error_propagation, execution_manifold
    """
    engine = KineticExecutionManifold()
    with pytest.raises(FileNotFoundError):
        await engine.execute("/tmp/missing_manifest_123.json")


@pytest.mark.asyncio
async def test_manifold_execute_unserializable_payload() -> None:
    """
    AGENT INSTRUCTION: Confirms Temporal DataConverter rejection on inherently cyclic memory objects.
    CAUSAL AFFORDANCE: Limits topological poisoning by rejecting unparsable JSON payloads structurally.
    EPISTEMIC BOUNDS: Synthesizes a locally bound self-referencing class to force an Exception locally.
    MCP ROUTING TRIGGERS: memory_limits, dynamic_bounds, json_serialization
    """
    async with await WorkflowEnvironment.start_time_skipping() as env:
        engine = KineticExecutionManifold()
        engine._client = env.client

        # Create an object that physically cannot be serialized to JSON
        class UnserializableCyclicObject:
            pass

        obj = UnserializableCyclicObject()
        cast("Any", obj).self_ref = obj

        payload = _build_valid_manifest_dict("dag")
        payload["topology"]["nodes"]["did:coreason:node-alpha"]["unserializable_memory"] = obj

        # The Python DataConverter in Temporal will fail to serialize the native dict
        with pytest.raises(Exception):  # noqa: B017
            await engine.execute_from_dict(payload)
