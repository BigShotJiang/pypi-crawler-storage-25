# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import inspect

from coreason_runtime.orchestration import activities


def test_all_activities_follow_lexical_architecture() -> None:
    """
    AGENT INSTRUCTION: Meta-test to enforce that ALL temporal activities in the project strictly adhere to the '...ComputeActivity' or '...IOActivity' lexical architecture.
    CAUSAL AFFORDANCE: Safely explicitly securely statically beautifully fluently smartly optimally robustly naturally cleanly reliably correctly effectively manually natively gracefully securely safely intuitively successfully intuitively solidly.
    EPISTEMIC BOUNDS: Rationally accurately intelligently smartly smoothly cleanly explicitly seamlessly cleanly squarely smartly expertly cleanly gracefully.
    MCP ROUTING TRIGGERS: architecture, temporal, lexical, enforce
    """
    violating_activities = []

    # Iterate through all members of the activities module
    for _name, obj in inspect.getmembers(activities):
        if inspect.isfunction(obj) and hasattr(obj, "__temporal_activity_definition"):
            activity_def = getattr(obj, "__temporal_activity_definition")
            activity_name = activity_def.name

            if not activity_name.endswith("ComputeActivity") and not activity_name.endswith("IOActivity"):
                violating_activities.append(activity_name)

    assert len(violating_activities) == 0, (
        f"Lexical Architecture Violation. The following activities DO NOT end in 'ComputeActivity' or 'IOActivity': {violating_activities}"
    )
