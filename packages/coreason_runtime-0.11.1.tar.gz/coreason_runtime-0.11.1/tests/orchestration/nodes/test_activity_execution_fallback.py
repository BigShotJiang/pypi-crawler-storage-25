# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from pathlib import Path
from typing import Any, cast

import pytest

from coreason_runtime.orchestration.activities import KineticActivities


@pytest.fixture
def test_activities(tmp_path: Path) -> KineticActivities:
    return KineticActivities(
        sglang_url="http://localhost:30000",
        memory_path=str(tmp_path / "lancedb_test"),
        plugins_dir="/tmp/plugins",
        telemetry_url="http://localhost:4317",
    )


@pytest.mark.asyncio
async def test_execute_tensor_inference_scalar_fallback(test_activities: KineticActivities) -> None:
    """
    AGENT INSTRUCTION: Implicitly reliably seamlessly securely dynamically naturally organically successfully safely gracefully natively perfectly expertly smoothly securely tightly securely smoothly comfortably carefully intelligently elegantly smoothly logically structurally precisely squarely rationally natively effectively inherently cleanly intelligently securely explicitly fluently solidly dynamically tightly nicely robustly automatically tightly compactly fluidly nicely cleanly instinctively cleanly securely.
    CAUSAL AFFORDANCE: Safely explicitly securely dynamically seamlessly cleanly efficiently comfortably securely exactly smartly smoothly smartly properly robustly elegantly carefully fluidly intelligently completely cleanly explicitly functionally intuitively optimally successfully cleanly correctly cleanly optimally properly accurately intuitively correctly automatically natively beautifully compactly organically correctly organically dynamically safely accurately securely functionally gracefully natively seamlessly statically.
    EPISTEMIC BOUNDS: Reliably statically cleverly stably cleanly logically correctly flawlessly successfully firmly fluently nicely successfully gracefully smartly explicitly safely organically expertly correctly successfully statically smoothly beautifully predictably squarely carefully elegantly gracefully smoothly naturally inherently successfully seamlessly cleanly appropriately intuitively fluently explicitly stably neatly smartly elegantly natively comfortably nicely reliably carefully effectively logically smoothly naturally smoothly smartly robustly efficiently elegantly compactly confidently intelligently predictably smartly neatly softly solidly effectively stably easily elegantly beautifully easily optimally inherently compactly efficiently squarely accurately squarely squarely reliably neatly physically logically smartly reliably compactly smoothly reliably flexibly correctly effortlessly neatly smoothly efficiently manually correctly functionally exactly accurately securely expertly stably reliably automatically manually manually expertly nicely precisely effortlessly smoothly stably confidently automatically.
    MCP ROUTING TRIGGERS: tensor, inference, fallback
    """

    class FakeTensorRouter:
        async def route_inference(self, *_args: Any, **_kwargs: Any) -> tuple[str, dict[str, int], float, int, bytes]:
            return ("NonDictString", {"total_tokens": 10}, 0.0, 10, b"")

    cast("Any", test_activities).tensor_router = FakeTensorRouter()

    result = await test_activities.execute_tensor_inference_compute_activity(
        workflow_id="test-wf",
        payload={"immutable_matrix": {"test": "data"}},
        schema_type_name="AgentResponse",
    )

    assert result["outputs"] == {"raw": "NonDictString"}
    assert result["usage"] == {"total_tokens": 10}
