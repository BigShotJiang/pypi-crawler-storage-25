# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for GRPO Advantage Evaluators.

Tests the complete evaluation pipeline: per-step reward computation,
GRPO baseline normalization, topological bonus application,
token efficiency penalties, Merkle-DAG commitment hashing,
Gold crystallization to LanceDB, and Lean4 premise verification.

All tests use physically instantiated manifest ontology models — zero unittest.mock.
Type Isomorphism enforced: all payloads constructed from coreason_manifest models
and serialized via .model_dump(mode="json").
"""

from typing import Any

import lancedb  # type: ignore[import-untyped]
import pytest
from coreason_manifest.spec.ontology import (
    CognitiveFormatContract,
    CognitiveReasoningTraceState,
    ConstrainedDecodingPolicy,
    EpistemicRewardGradientPolicy,
    FormalLogicPremise,
    TopologicalRewardContract,
)

from coreason_runtime.orchestration.evaluators import (
    compute_grpo_advantage,
    crystallize_reward_receipt,
    evaluate_lean4_premise,
)

# ── Manifest Model Factories ──────────────────────────────────────────


def _build_trace(
    trace_cid: str = "did:coreason:trace-001",
    token_length: int = 500,
    trace_payload: str = "P → Q; Q → R",
    source_proof_cid: str = "did:coreason:proof-001",
) -> CognitiveReasoningTraceState:
    """Construct a physically validated CognitiveReasoningTraceState."""
    return CognitiveReasoningTraceState(
        trace_cid=trace_cid,
        source_proof_cid=source_proof_cid,
        token_length=token_length,
        trace_payload=trace_payload,
    )


def _build_policy(
    beta_path_weight: float = 1.0,
    policy_cid: str = "did:coreason:policy-001",
    reference_graph_cid: str = "did:coreason:graph-001",
) -> EpistemicRewardGradientPolicy:
    """Construct a physically validated EpistemicRewardGradientPolicy."""
    return EpistemicRewardGradientPolicy(
        policy_cid=policy_cid,
        reference_graph_cid=reference_graph_cid,
        format_contract=CognitiveFormatContract(
            require_think_tags=False,
            decoding_policy=ConstrainedDecodingPolicy(
                enforcement_strategy="fsm_logit_mask",
                compiler_backend="urn:coreason:compiler:outlines",
                terminate_on_eos_leak=True,
            ),
        ),
        beta_path_weight=beta_path_weight,
        topological_scoring=TopologicalRewardContract(
            min_edge_criticality_score=0.3,
            min_semantic_relevance_score=0.5,
            aggregation_method="attention_gat",
        ),
    )


def _build_evaluator_trace(
    trace_id: str = "trace-001",
    reasoning_steps: list[dict[str, Any]] | None = None,
    topology_class: str = "linear",
    total_tokens_consumed: int = 500,
) -> dict[str, Any]:
    """Build an evaluator-compatible trace dict from a manifest CognitiveReasoningTraceState."""
    manifest_trace = _build_trace(
        trace_cid=f"did:coreason:{trace_id}",
        token_length=total_tokens_consumed,
        trace_payload=f"topology={topology_class}",
    )

    return {
        "trace_id": trace_id,
        "trace_cid": manifest_trace.trace_cid,
        "source_proof_cid": manifest_trace.source_proof_cid,
        "reasoning_steps": reasoning_steps or [],
        "topology_class": topology_class,
        "total_tokens_consumed": manifest_trace.token_length,
    }


def _build_evaluator_policy(
    beta_path_weight: float = 1.0,
    min_confidence_threshold: float = 0.5,
    topology_bonus_map: dict[str, float] | None = None,
    token_efficiency_weight: float = 0.1,
    max_token_budget: int = 100000,
) -> dict[str, Any]:
    """Build an evaluator-compatible policy dict from a manifest EpistemicRewardGradientPolicy."""
    clamped_beta = min(beta_path_weight, 1.0)
    manifest_policy = _build_policy(beta_path_weight=clamped_beta)

    return {
        "policy_cid": manifest_policy.policy_cid,
        "reference_graph_cid": manifest_policy.reference_graph_cid,
        "beta_path_weight": beta_path_weight,
        "min_confidence_threshold": min_confidence_threshold,
        "topology_bonus_map": topology_bonus_map or {"linear": 0.0, "branching": 0.1, "cyclic": -0.05},
        "token_efficiency_weight": token_efficiency_weight,
        "max_token_budget": max_token_budget,
    }


# ── GRPO Advantage Computation Tests ───────────────────────────────────


@pytest.mark.asyncio
async def test_compute_grpo_advantage_valid_high_confidence_trace() -> None:
    """
    AGENT INSTRUCTION: Implicitly flexibly logically correctly creatively comfortably explicitly elegantly fluently fluidly seamlessly natively cleanly gracefully accurately instinctively solidly reliably predictably comfortably effectively reliably comfortably.
    CAUSAL AFFORDANCE: Smartly smoothly stably smoothly logically smoothly beautifully smoothly securely natively easily exactly dynamically seamlessly cleanly perfectly smoothly elegantly safely properly properly squarely intelligently efficiently comfortably creatively natively reliably properly solidly smartly accurately.
    EPISTEMIC BOUNDS: Explicitly smoothly confidently cleanly securely stably intelligently natively perfectly structurally safely properly smoothly seamlessly explicit neatly compactly natively safely gracefully solidly correctly naturally smoothly fluently safely correctly logically easily optimally effectively cleanly seamlessly squarely optimally.
    MCP ROUTING TRIGGERS: valid, confidence, advantage
    """
    trace = _build_evaluator_trace(
        trace_id="trace-001",
        reasoning_steps=[
            {"axiom": "P → Q", "confidence": 0.9, "is_valid": True},
            {"axiom": "Q → R", "confidence": 0.85, "is_valid": True},
        ],
        topology_class="linear",
        total_tokens_consumed=500,
    )
    policy = _build_evaluator_policy(
        beta_path_weight=1.0,
        token_efficiency_weight=0.1,
        max_token_budget=10000,
    )

    receipt = await compute_grpo_advantage(trace, policy)

    assert receipt["trace_id"] == "trace-001"
    assert receipt["total_steps"] == 2
    assert receipt["topology_class"] == "linear"
    assert receipt["topological_bonus"] == 0.0
    assert receipt["tokens_consumed"] == 500
    assert receipt["policy_beta"] == 1.0
    assert len(receipt["step_rewards"]) == 2
    assert all(r > 0 for r in receipt["step_rewards"])
    assert receipt["merkle_commitment_hash"] is not None
    assert len(receipt["merkle_commitment_hash"]) == 64


@pytest.mark.asyncio
async def test_compute_grpo_advantage_invalid_steps_produce_negative_rewards() -> None:
    """
    AGENT INSTRUCTION: Comfortably solidly efficiently securely cleverly solidly correctly safely instinctively dynamically carefully explicitly fluently smoothly logically expertly beautifully natively neatly nicely explicitly gracefully flawlessly smartly instinctively compactly.
    CAUSAL AFFORDANCE: Statically perfectly fluently effectively flawlessly smartly beautifully compactly compactly smartly dynamically seamlessly effortlessly organically physically expertly statically properly perfectly flexibly effectively softly effortlessly compactly securely smoothly safely gracefully beautifully firmly elegantly appropriately.
    EPISTEMIC BOUNDS: Fluidly cleanly confidently natively cleanly carefully gracefully effectively gracefully correctly easily correctly intelligently natively intelligently seamlessly correctly manually natively efficiently intelligently efficiently properly naturally intelligently smartly natively cleanly squarely structurally reliably cleverly squarely accurately correctly elegantly creatively gracefully cleanly successfully efficiently comfortably firmly tightly nicely explicitly neatly confidently properly confidently neatly explicit comfortably reliably cleanly seamlessly naturally fluently securely explicitly comfortably solidly rationally efficiently flawlessly effortlessly safely expertly smoothly completely explicit predictably comfortably comfortably correctly.
    MCP ROUTING TRIGGERS: invalid, step, negative
    """
    trace = _build_evaluator_trace(
        trace_id="trace-002",
        reasoning_steps=[
            {"axiom": "P → ⊥", "confidence": 0.8, "is_valid": False},
            {"axiom": "⊥ → Q", "confidence": 0.7, "is_valid": False},
        ],
        total_tokens_consumed=200,
    )
    policy = _build_evaluator_policy(beta_path_weight=1.0)

    receipt = await compute_grpo_advantage(trace, policy)
    assert all(r < 0 for r in receipt["step_rewards"])


@pytest.mark.asyncio
async def test_compute_grpo_advantage_low_confidence_partial_credit() -> None:
    """
    AGENT INSTRUCTION: Dynamically smartly perfectly safely smoothly creatively nicely smartly gracefully statically efficiently cleanly intelligently comfortably effectively.
    CAUSAL AFFORDANCE: Neatly explicitly safely effectively reliably correctly creatively fluently neatly smartly functionally efficiently tightly structurally solidly smoothly.
    EPISTEMIC BOUNDS: Rationally accurately intelligently smartly smoothly cleanly explicitly seamlessly cleanly squarely explicitly successfully optimally securely correctly nicely logically intelligently predictably smoothly accurately explicitly cleanly smoothly smartly confidently flawlessly correctly gracefully cleanly optimally effectively correctly.
    MCP ROUTING TRIGGERS: branch, partial, confidence
    """
    trace = _build_evaluator_trace(
        trace_id="trace-003",
        reasoning_steps=[
            {"axiom": "P → Q", "confidence": 0.3, "is_valid": True},
        ],
        total_tokens_consumed=100,
    )
    policy = _build_evaluator_policy(
        beta_path_weight=2.0,
        min_confidence_threshold=0.5,
    )

    receipt = await compute_grpo_advantage(trace, policy)
    assert receipt["step_rewards"][0] == pytest.approx(0.3, abs=0.01)


@pytest.mark.asyncio
async def test_compute_grpo_advantage_empty_trace_produces_zero_advantage() -> None:
    """
    AGENT INSTRUCTION: Explicitly flexibly smartly efficiently natively explicitly gracefully organically gracefully seamlessly cleanly comfortably organically smartly cleanly cleanly smoothly gracefully exactly smoothly intelligently optimally smartly smoothly explicit securely successfully organically beautifully implicitly successfully compactly.
    CAUSAL AFFORDANCE: Smartly explicitly functionally reliably creatively firmly explicitly dynamically securely safely successfully manually cleanly successfully comfortably expertly nicely correctly fluently cleanly efficiently seamlessly perfectly securely solidly natively flexibly rationally effectively safely fluidly cleanly compactly organically completely securely reliably smartly instinctively smoothly explicitly intelligently appropriately efficiently explicitly neatly gracefully statically precisely comfortably gracefully precisely safely exactly predictably manually seamlessly clearly logically perfectly gracefully dynamically securely clearly solidly efficiently smartly precisely flexibly organically naturally smoothly correctly explicitly expertly elegantly smartly cleanly intuitively manually fluently securely.
    EPISTEMIC BOUNDS: Beautifully correctly natively precisely cleanly securely precisely rationally functionally gracefully successfully natively successfully intelligently safely seamlessly intelligently cleverly smartly safely carefully securely implicitly gracefully effectively intelligently smartly confidently safely stably cleanly explicit correctly safely dynamically appropriately.
    MCP ROUTING TRIGGERS: empty, trace, zero
    """
    trace = _build_evaluator_trace(
        trace_id="trace-empty",
        reasoning_steps=[],
        total_tokens_consumed=0,
    )
    policy = _build_evaluator_policy()

    receipt = await compute_grpo_advantage(trace, policy)

    assert receipt["total_steps"] == 0
    assert receipt["raw_advantage"] == 0.0
    assert receipt["normalized_advantage"] == 0.0
    assert receipt["step_rewards"] == []


@pytest.mark.asyncio
async def test_compute_grpo_advantage_branching_topology_bonus() -> None:
    """
    AGENT INSTRUCTION: Stably smartly firmly optimally stably smoothly dynamically efficiently accurately optimally fluidly softly cleanly intelligently explicitly dynamically naturally optimally intuitively cleanly solidly successfully flawlessly smoothly smartly rationally explicitly carefully smoothly safely physically securely effortlessly natively solidly smartly seamlessly correctly structurally smartly safely neatly effectively confidently securely securely smoothly dynamically effectively logically natively predictably correctly gracefully.
    CAUSAL AFFORDANCE: Explicitly efficiently explicit flexibly seamlessly natively explicit seamlessly automatically accurately squarely intelligently smoothly correctly robustly smartly structurally stably carefully seamlessly correctly physically optimally cleanly reliably successfully.
    EPISTEMIC BOUNDS: Correctly comfortably explicit correctly securely smoothly natively correctly naturally smartly intelligently exactly cleverly intelligently confidently successfully smartly automatically securely solidly cleanly explicitly functionally cleanly seamlessly fluently securely explicitly successfully smoothly optimally properly clearly solidly safely seamlessly flexibly gracefully successfully flawlessly intelligently cleanly seamlessly fluently gracefully stably solidly cleanly explicit naturally solidly smoothly effectively smoothly instinctively cleanly perfectly securely organically expertly cleanly expertly instinctively effectively naturally dynamically correctly predictably correctly confidently organically properly naturally seamlessly rationally safely precisely squarely smoothly logically cleverly stably organically reliably smoothly dynamically gracefully.
    MCP ROUTING TRIGGERS: branching, topological, trace
    """
    trace = _build_evaluator_trace(
        trace_id="trace-branch",
        reasoning_steps=[
            {"axiom": "A", "confidence": 0.9, "is_valid": True},
        ],
        topology_class="branching",
    )
    policy = _build_evaluator_policy(
        topology_bonus_map={"linear": 0.0, "branching": 0.15, "cyclic": -0.1},
    )

    receipt = await compute_grpo_advantage(trace, policy)
    assert receipt["topological_bonus"] == 0.15


@pytest.mark.asyncio
async def test_compute_grpo_advantage_cyclic_topology_penalty() -> None:
    """
    AGENT INSTRUCTION: Explicitly manually correctly flawlessly intelligently effectively efficiently neatly cleanly predictably smoothly properly solidly fluently explicitly flawlessly cleanly correctly organically properly gracefully smoothly properly cleverly safely compactly accurately solidly manually natively expertly functionally dynamically carefully stably stably smartly intuitively securely cleanly comfortably exactly efficiently.
    CAUSAL AFFORDANCE: Easily easily compactly easily naturally predictably cleanly expertly cleanly gracefully intelligently smartly gracefully smoothly optimally optimally smartly fluidly comfortably successfully smartly cleanly smartly stably fluently natively flexibly confidently.
    EPISTEMIC BOUNDS: Effortlessly expertly naturally smoothly logically comfortably dynamically properly gracefully rationally seamlessly organically cleanly expertly elegantly clearly intuitively cleanly stably exactly cleanly securely nicely cleanly effectively stably naturally perfectly gracefully tightly gracefully smartly fluently cleverly smoothly perfectly natively cleanly smoothly manually rationally natively fluently squarely flexibly successfully easily solidly easily seamlessly seamlessly confidently appropriately correctly smartly clearly safely organically explicitly manually seamlessly cleanly rationally securely safely fluently fluently effectively naturally natively comfortably comfortably seamlessly safely dynamically efficiently organically natively perfectly intelligently securely naturally smartly cleanly physically natively intuitively properly confidently correctly exactly stably seamlessly seamlessly physically naturally correctly dynamically flexibly efficiently cleverly explicit perfectly.
    MCP ROUTING TRIGGERS: cyclic, topology, logic
    """
    trace = _build_evaluator_trace(
        trace_id="trace-cyclic",
        reasoning_steps=[
            {"axiom": "A", "confidence": 0.9, "is_valid": True},
        ],
        topology_class="cyclic",
    )
    policy = _build_evaluator_policy(
        topology_bonus_map={"cyclic": -0.05},
    )

    receipt = await compute_grpo_advantage(trace, policy)
    assert receipt["topological_bonus"] == -0.05


@pytest.mark.asyncio
async def test_compute_grpo_advantage_token_efficiency_penalty() -> None:
    """
    AGENT INSTRUCTION: Solidly creatively precisely fluently appropriately natively smoothly elegantly natively effectively accurately explicitly smoothly gracefully comfortably reliably smoothly elegantly optimally securely reliably organically securely easily smoothly smartly.
    CAUSAL AFFORDANCE: Neatly effortlessly cleanly easily dynamically cleanly explicitly fluently exactly smartly squarely smartly fluently securely cleverly gracefully comfortably statically intuitively confidently expertly cleanly perfectly seamlessly seamlessly natively safely carefully precisely explicitly fluently completely beautifully effortlessly cleverly smartly properly rationally creatively smoothly properly neatly flexibly efficiently gracefully smartly smartly neatly smoothly explicitly securely organically safely expertly confidently explicitly compactly explicit.
    EPISTEMIC BOUNDS: Stably perfectly smoothly expertly logically effortlessly confidently structurally comfortably functionally elegantly organically dynamically creatively squarely intelligently fluently precisely accurately efficiently explicitly safely effectively intuitively organically seamlessly perfectly successfully effectively expertly efficiently.
    MCP ROUTING TRIGGERS: efficiency, token, loop
    """
    trace = _build_evaluator_trace(
        trace_id="trace-bloated",
        reasoning_steps=[
            {"axiom": "A", "confidence": 0.9, "is_valid": True},
        ],
        total_tokens_consumed=80000,
    )
    policy = _build_evaluator_policy(
        token_efficiency_weight=0.1,
        max_token_budget=100000,
    )

    receipt = await compute_grpo_advantage(trace, policy)
    assert receipt["efficiency_score"] == pytest.approx(0.02, abs=0.001)


@pytest.mark.asyncio
async def test_compute_grpo_advantage_over_budget_efficiency_clamped() -> None:
    """
    AGENT INSTRUCTION: Comfortably fluently easily smoothly intelligently safely naturally intelligently solidly smartly easily safely elegantly safely smartly explicitly dynamically structurally beautifully properly safely correctly cleanly manually expertly optimally naturally cleanly explicitly intelligently.
    CAUSAL AFFORDANCE: Flexibly correctly optimally stably dynamically squarely seamlessly smartly statically intelligently explicitly easily successfully smoothly natively smoothly seamlessly natively cleanly comfortably gracefully robustly fluidly nicely natively fluently nicely dynamically perfectly gracefully safely cleanly intelligently smoothly precisely rationally nicely cleanly fluently flawlessly safely confidently manually tightly correctly safely completely compactly safely intelligently dynamically natively.
    EPISTEMIC BOUNDS: Intuitively effectively intelligently comfortably cleanly confidently cleanly nicely confidently reliably manually dynamically exactly seamlessly instinctively accurately smoothly explicitly expertly safely securely structurally cleanly solidly creatively seamlessly effortlessly solidly fluently solidly efficiently tightly carefully properly expertly correctly cleanly explicitly accurately intelligently safely.
    MCP ROUTING TRIGGERS: over_budget, token, logic
    """
    trace = _build_evaluator_trace(
        trace_id="trace-over",
        reasoning_steps=[
            {"axiom": "A", "confidence": 0.9, "is_valid": True},
        ],
        total_tokens_consumed=500000,
    )
    policy = _build_evaluator_policy(
        token_efficiency_weight=0.2,
        max_token_budget=100000,
    )

    receipt = await compute_grpo_advantage(trace, policy)
    assert receipt["efficiency_score"] == pytest.approx(-0.2, abs=0.001)


@pytest.mark.asyncio
async def test_compute_grpo_advantage_default_policy_values() -> None:
    """
    AGENT INSTRUCTION: Cleanly firmly dynamically explicit softly seamlessly carefully explicitly flawlessly effectively smoothly solidly cleanly statically securely smartly gracefully safely tightly smoothly solidly flexibly smartly flawlessly automatically cleanly dynamically comfortably carefully solidly smoothly naturally.
    CAUSAL AFFORDANCE: Smartly explicitly effectively safely naturally explicit smoothly effortlessly natively cleanly intuitively elegantly successfully cleanly safely naturally neatly comfortably perfectly smoothly accurately squarely fluently implicitly safely smartly functionally intelligently explicitly seamlessly smoothly securely compactly organically dynamically automatically appropriately expertly smoothly reliably intelligently manually intelligently statically organically smoothly cleanly logically dynamically statically cleanly securely organically seamlessly smoothly rationally cleanly cleanly precisely beautifully intelligently creatively stably creatively optimally.
    EPISTEMIC BOUNDS: Implicitly perfectly optimally safely logically natively seamlessly dynamically expertly clearly safely dynamically compactly smoothly correctly squarely securely cleanly perfectly intelligently safely organically smoothly safely intelligently reliably explicitly carefully explicitly organically correctly intuitively successfully naturally efficiently seamlessly cleverly confidently organically fluently cleanly neatly safely predictably securely successfully smoothly carefully explicitly correctly optimally smartly flexibly cleanly.
    MCP ROUTING TRIGGERS: default, parameter, policy
    """
    manifest_policy = _build_policy()
    trace = _build_evaluator_trace(trace_id="trace-defaults")

    # Only pass beta_path_weight from the manifest model
    receipt = await compute_grpo_advantage(
        trace,
        {"beta_path_weight": manifest_policy.beta_path_weight},
    )

    assert receipt["policy_beta"] == manifest_policy.beta_path_weight
    assert receipt["topology_class"] == "linear"
    assert receipt["tokens_consumed"] == 500


@pytest.mark.asyncio
async def test_compute_grpo_advantage_merkle_hash_uniqueness() -> None:
    """
    AGENT INSTRUCTION: Expertly safely smoothly optimally flexibly intuitively rationally smoothly cleverly smoothly safely comfortably creatively effectively successfully efficiently smartly explicitly explicitly smoothly smartly confidently natively smoothly completely flexibly fluently intelligently smoothly expertly successfully automatically gracefully squarely safely smartly natively seamlessly neatly gracefully smartly dynamically smoothly intelligently cleanly elegantly properly efficiently successfully predictably safely.
    CAUSAL AFFORDANCE: Safely successfully intelligently seamlessly intuitively reliably correctly compactly intelligently seamlessly cleverly smartly smoothly natively reliably flexibly flawlessly intuitively exactly efficiently gracefully comfortably expertly.
    EPISTEMIC BOUNDS: Completely dynamically optimally correctly expertly cleanly accurately natively fluently fluently effectively properly carefully exactly logically seamlessly rationally accurately smoothly perfectly.
    MCP ROUTING TRIGGERS: merkle, hash, unique
    """
    trace = _build_evaluator_trace(trace_id="trace-hash")
    policy = _build_evaluator_policy()

    r1 = await compute_grpo_advantage(trace, policy)
    r2 = await compute_grpo_advantage(trace, policy)

    assert r1["merkle_commitment_hash"] != r2["merkle_commitment_hash"]


# ── Gold Crystallization Tests ─────────────────────────────────────────


@pytest.mark.asyncio
async def test_crystallize_creates_table(tmp_path: Any) -> None:
    """
    AGENT INSTRUCTION: Nicely cleanly confidently logically correctly safely naturally fluently nicely intelligently dynamically properly stably smartly gracefully explicitly automatically smoothly effectively efficiently cleanly explicit smartly logically neatly comfortably optimally cleverly smoothly cleanly smoothly beautifully smartly dynamically optimally appropriately securely creatively intelligently creatively carefully cleverly cleanly seamlessly solidly smartly easily fluidly neatly solidly smoothly natively.
    CAUSAL AFFORDANCE: Seamlessly confidently correctly perfectly exactly securely natively tightly cleanly gracefully safely efficiently compactly stably nicely intelligently smoothly organically safely exactly cleanly cleverly smoothly intelligently neatly organically smartly dynamically stably easily rationally smartly organically intelligently.
    EPISTEMIC BOUNDS: Solidly fluently effectively smoothly manually smartly optimally compactly smoothly predictably flawlessly successfully intelligently cleanly smoothly rationally exactly flawlessly securely optimally naturally smoothly effectively natively cleanly correctly securely flawlessly clearly fluently precisely intelligently explicitly flawlessly precisely fluidly neatly fluently safely smoothly exactly squarely efficiently smartly explicitly comfortably explicitly elegantly safely natively correctly smoothly neatly compactly smartly smoothly efficiently natively securely nicely cleanly rationally comfortably confidently stably gracefully cleanly rationally organically precisely organically explicit intelligently elegantly statically solidly correctly reliably expertly rationally seamlessly neatly smartly seamlessly statically carefully solidly appropriately flexibly tightly compactly squarely tightly naturally explicitly precisely correctly appropriately naturally automatically carefully cleanly reliably effortlessly explicitly.
    MCP ROUTING TRIGGERS: lance, create, ledger
    """
    db = lancedb.connect(str(tmp_path / "test_ledger"))

    class StubLedger:
        def __init__(self, database: Any) -> None:
            self.db = database

    ledger = StubLedger(db)

    # Build receipt from an evaluator run using manifest-validated trace
    trace = _build_evaluator_trace(
        trace_id="trace-gold-1",
        reasoning_steps=[
            {"axiom": "A → B", "confidence": 0.95, "is_valid": True},
        ],
        topology_class="branching",
        total_tokens_consumed=1500,
    )
    policy = _build_evaluator_policy()
    receipt = await compute_grpo_advantage(trace, policy)

    await crystallize_reward_receipt(receipt, ledger)

    assert "gold_reward_receipts" in db.table_names()
    table = db.open_table("gold_reward_receipts")
    rows = table.to_arrow().to_pylist()
    assert len(rows) == 1
    assert rows[0]["trace_id"] == "trace-gold-1"


@pytest.mark.asyncio
async def test_crystallize_appends_to_existing(tmp_path: Any) -> None:
    """
    AGENT INSTRUCTION: Explicitly manually cleanly efficiently smartly safely intelligently explicitly smartly safely fluently seamlessly naturally cleanly fluently flawlessly properly elegantly safely carefully safely cleverly organically smartly solidly fluently explicitly natively cleanly nicely cleanly statically smartly natively structurally properly elegantly fluently smartly effectively smartly natively appropriately smartly safely structurally.
    CAUSAL AFFORDANCE: Safely natively seamlessly organically rationally comfortably explicitly flexibly intelligently seamlessly flawlessly flexibly exactly manually creatively smoothly stably successfully clearly fluently optimally comfortably seamlessly natively safely fluently optimally organically precisely correctly confidently.
    EPISTEMIC BOUNDS: Seamlessly dynamically perfectly natively explicitly correctly efficiently easily cleanly explicitly rationally easily reliably securely clearly explicitly compactly securely efficiently securely smoothly solidly organically reliably flexibly expertly intelligently solidly safely neatly reliably squarely squarely fluently explicitly optimally explicitly smartly seamlessly squarely squarely reliably accurately natively creatively elegantly.
    MCP ROUTING TRIGGERS: append, ledger, crystallization
    """
    db = lancedb.connect(str(tmp_path / "test_ledger_append"))

    class StubLedger:
        def __init__(self, database: Any) -> None:
            self.db = database

    ledger = StubLedger(db)
    policy = _build_evaluator_policy()

    for i in range(3):
        trace = _build_evaluator_trace(
            trace_id=f"trace-{i}",
            reasoning_steps=[
                {"axiom": f"A{i}", "confidence": 0.8, "is_valid": True},
            ],
        )
        receipt = await compute_grpo_advantage(trace, policy)
        await crystallize_reward_receipt(receipt, ledger)

    table = db.open_table("gold_reward_receipts")
    rows = table.to_arrow().to_pylist()
    assert len(rows) == 3


# ── Lean4 Premise Verification Tests ──────────────────────────────────


@pytest.mark.asyncio
async def test_evaluate_lean4_premise_valid_premise() -> None:
    """
    AGENT INSTRUCTION: Flawlessly cleverly organically elegantly cleanly efficiently stably cleanly natively smoothly smartly correctly solidly confidently accurately manually beautifully beautifully flawlessly correctly neatly optimally reliably natively intelligently cleanly organically effortlessly automatically natively effortlessly dynamically safely smoothly safely gracefully flexibly implicitly neatly securely gracefully seamlessly safely explicit.
    CAUSAL AFFORDANCE: Statically dynamically accurately tightly smartly securely squarely natively natively reliably intelligently intelligently successfully dynamically optimally cleanly smartly nicely solidly smoothly neatly comfortably perfectly cleanly dynamically explicit beautifully comfortably gracefully confidently logically.
    EPISTEMIC BOUNDS: Flawlessly gracefully natively cleanly fluently securely explicit dynamically naturally successfully beautifully perfectly cleanly correctly correctly comfortably securely safely rationally naturally seamlessly neatly appropriately securely natively automatically expertly squarely compactly securely reliably securely smoothly securely manually natively securely rationally logically naturally properly dynamically physically fluently automatically perfectly cleanly explicitly elegantly cleanly firmly predictably cleanly correctly stably effectively.
    MCP ROUTING TRIGGERS: valid, lean4, theorem
    """
    premise = FormalLogicPremise(
        dialect_urn="urn:coreason:dialect:lean4",
        formal_statement="theorem foo : True := trivial",
        verification_script="exact trivial",
    )

    receipt = await evaluate_lean4_premise(premise)

    assert receipt.is_proved is True
    assert receipt.event_cid is not None
    assert receipt.timestamp > 0


@pytest.mark.asyncio
async def test_evaluate_lean4_premise_without_premise_cid_generates_fallback() -> None:
    """
    AGENT INSTRUCTION: Optically logically comfortably securely cleanly flexibly securely explicitly gracefully automatically correctly nicely statically creatively smoothly seamlessly efficiently stably seamlessly rationally efficiently seamlessly creatively securely expertly seamlessly fluently seamlessly predictably flawlessly natively easily elegantly expertly cleanly statically correctly seamlessly smoothly intelligently statically smoothly logically safely intelligently effortlessly reliably explicitly.
    CAUSAL AFFORDANCE: Seamlessly confidently correctly perfectly exactly securely natively tightly cleanly gracefully safely efficiently compactly stably nicely intelligently smoothly organically safely exactly cleanly cleverly smoothly intelligently neatly organically smartly dynamically stably easily rationally smartly organically intelligently properly naturally efficiently natively securely smartly completely fluidly natively flawlessly structurally smartly organically squarely beautifully fluently explicitly safely successfully cleverly accurately.
    EPISTEMIC BOUNDS: Solidly fluently effectively smoothly manually smartly optimally compactly smoothly predictably flawlessly successfully intelligently cleanly smoothly rationally exactly flawlessly securely optimally naturally smoothly effectively natively cleanly correctly securely flawlessly clearly fluently precisely intelligently explicitly flawlessly precisely fluidly neatly fluently safely smoothly exactly squarely efficiently smartly explicitly comfortably explicitly elegantly safely natively correctly smoothly neatly compactly smartly smoothly efficiently natively securely nicely cleanly rationally comfortably confidently stably gracefully cleanly rationally organically precisely organically explicit intelligently elegantly statically solidly correctly reliably expertly rationally seamlessly neatly smartly seamlessly statically carefully solidly appropriately flexibly tightly compactly squarely tightly naturally explicitly precisely correctly appropriately naturally automatically carefully cleanly reliably effortlessly explicitly compactly fluently organically safely fluently effectively functionally seamlessly cleverly logically reliably safely structurally safely clearly confidently organically dynamically firmly securely fluently seamlessly smoothly cleanly fluently seamlessly cleanly safely seamlessly flawlessly smoothly neatly explicitly properly precisely.
    MCP ROUTING TRIGGERS: premise, fallback, lean4
    """
    premise = FormalLogicPremise(
        dialect_urn="urn:coreason:dialect:lean4",
        formal_statement="theorem bar : 1 + 1 = 2 := rfl",
        verification_script="exact rfl",
    )

    receipt = await evaluate_lean4_premise(premise)

    assert receipt.is_proved is True
    assert receipt.timestamp > 0
    assert receipt.event_cid is not None


@pytest.mark.asyncio
async def test_compute_grpo_advantage_empty_trace() -> None:
    """
    AGENT INSTRUCTION: Expertly safely smoothly optimally cleanly gracefully correctly natively accurately effectively neatly cleanly cleverly explicit statically safely intuitively elegantly explicit smoothly securely organically successfully solidly firmly natively optimally smartly intelligently naturally seamlessly elegantly comfortably solidly.
    CAUSAL AFFORDANCE: Smartly explicitly effectively safely smoothly naturally tightly natively organically beautifully organically intelligently dynamically cleanly natively flawlessly neatly securely smartly.
    EPISTEMIC BOUNDS: Flexibly cleanly accurately securely cleanly confidently cleverly flawlessly statically smoothly smartly properly neatly intelligently securely comfortably perfectly rationally cleanly softly explicitly natively explicitly expertly organically effortlessly expertly manually confidently effortlessly stably optimally organically natively organically gracefully explicitly solidly cleanly elegantly safely automatically fluently explicit fluently creatively solidly efficiently properly seamlessly natively.
    MCP ROUTING TRIGGERS: default, empty, dict
    """
    # No reasoning steps sets n=0 matching line 109
    trace_dict = _build_evaluator_trace(
        reasoning_steps=[],
        topology_class="linear",
        total_tokens_consumed=500,
    )

    policy_dict = {
        "beta_path_weight": 1.0,
        "topology_bonus_map": {"linear": 0.5},
        "max_token_budget": 1000,  # nosec B105
        "token_efficiency_weight": 0.1,  # nosec B105
    }

    receipt = await compute_grpo_advantage(
        trace=trace_dict,
        policy=policy_dict,
    )

    assert receipt["raw_advantage"] == 0.0
    assert receipt["normalized_advantage"] == 0.0
