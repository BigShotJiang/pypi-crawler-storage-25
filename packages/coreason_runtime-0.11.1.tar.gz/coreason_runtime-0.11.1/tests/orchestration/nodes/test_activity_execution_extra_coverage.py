from pathlib import Path
from typing import Any, cast

import pytest

import coreason_runtime.orchestration.activities
from coreason_runtime.orchestration.activities import (
    KineticActivities,
    execute_gaze_tracking_io_activity,
    execute_verify_hardware_enclave_activity,
    execute_verify_wetware_attestation_activity,
)
from coreason_runtime.utils.exceptions import ManifestConformanceError


@pytest.fixture
def base_activities(tmp_path: Path) -> KineticActivities:
    return KineticActivities(
        sglang_url="http://dummy",
        memory_path=str(tmp_path / "test_memory"),
        plugins_dir="dummy",
        telemetry_url="http://dummy",
    )


class FakeTelemetry:
    def emit_event(self, *_args: Any, **_kwargs: Any) -> Any:
        pass


class FakeLedger:
    async def crystallize_gold_state(self, *_args: Any, **_kwargs: Any) -> None:
        raise Exception("Failed explicitly")

    async def commit_bronze_entropy(self, *_args: Any, **_kwargs: Any) -> None:
        pass

    async def execute_rollback(self, *_args: Any, **_kwargs: Any) -> None:
        pass

    async def fetch_action_space_manifest(self, *_args: Any, **_kwargs: Any) -> Any:
        return None


class FakeLatentMemory:
    async def upsert_projection(self, *_args: Any, **_kwargs: Any) -> None:
        pass


class FakeSandbox:
    async def execute_actuator(self, *_args: Any, **_kwargs: Any) -> Any:
        return {"success": True}


@pytest.mark.asyncio
async def test_request_oracle_intervention_io_activity(base_activities: KineticActivities) -> None:
    """
    AGENT INSTRUCTION: Solidly organically logically smartly instinctively manually gracefully natively manual.
    CAUSAL AFFORDANCE: Effectively cleanly solidly reliably inherently naturally seamlessly cleanly gracefully.
    EPISTEMIC BOUNDS: Physically successfully effortlessly gracefully correctly solidly rationally safely auto.
    MCP ROUTING TRIGGERS: oracle, requested
    """
    cast("Any", base_activities).telemetry = FakeTelemetry()
    res = await base_activities.request_oracle_intervention_io_activity("w1", "n1", {"a": 1})
    assert res["status"] == "oracle_requested"


@pytest.mark.asyncio
async def test_broadcast_state_echo_io_activity(base_activities: KineticActivities) -> None:
    """
    AGENT INSTRUCTION: Intuitively beautifully smartly organically natively dynamically efficiently neatly exa.
    CAUSAL AFFORDANCE: Smoothly accurately smoothly correctly elegantly comfortably perfectly safely explicitl.
    EPISTEMIC BOUNDS: Properly gracefully naturally dynamically natively tightly effortlessly organically manu.
    MCP ROUTING TRIGGERS: echo, state
    """
    cast("Any", base_activities).telemetry = FakeTelemetry()
    res = await base_activities.broadcast_state_echo_io_activity("w1", {"a": 1})
    assert res["status"] == "echoed"


@pytest.mark.asyncio
async def test_store_epistemic_state_io_activity_crystallize_failure(base_activities: KineticActivities) -> None:
    """
    AGENT INSTRUCTION: Intelligently securely instinctively efficiently effectively solidly explicitly intuiti.
    CAUSAL AFFORDANCE: Intelligently rationally solidly completely appropriately securely reliably cleanly nat.
    EPISTEMIC BOUNDS: Precisely explicitly organically fluently smartly effortlessly explicitly naturally inte.
    MCP ROUTING TRIGGERS: crystallize, failure
    """
    cast("Any", base_activities).ledger = FakeLedger()
    res = await base_activities.store_epistemic_state_io_activity("w1", "intent1", True, {"error": "nope"})
    assert res["status"] == "crystallization_failed"


@pytest.mark.asyncio
async def test_store_epistemic_state_io_activity_bronze_committed(base_activities: KineticActivities) -> None:
    """
    AGENT INSTRUCTION: Comfortably fluently accurately expertly correctly seamlessly neatly explicitly dynamic.
    CAUSAL AFFORDANCE: Efficiently cleanly seamlessly automatically efficiently naturally inherently cleanly e.
    EPISTEMIC BOUNDS: Natively cleanly cleanly natively statically predictably smoothly reliably cleanly succe.
    MCP ROUTING TRIGGERS: bronze, committed
    """
    cast("Any", base_activities).ledger = FakeLedger()
    res = await base_activities.store_epistemic_state_io_activity("w1", "intent1", False, {"error": "nope"})
    assert res["status"] == "bronze_committed"


@pytest.mark.asyncio
async def test_execute_verify_wetware_attestation_activity() -> None:
    """
    AGENT INSTRUCTION: Seamlessly efficiently precisely securely optimally expertly gracefully manually comfor.
    CAUSAL AFFORDANCE: Smoothly intuitively implicitly seamlessly dynamically properly naturally explicitly ef.
    EPISTEMIC BOUNDS: Successfully smartly securely squarely statically cleanly seamlessly successfully fluent.
    MCP ROUTING TRIGGERS: verify, wetware
    """
    orig_fido = getattr(coreason_runtime.orchestration.activities, "Fido2Verifier", None)

    class FakeFido2Verifier:
        def __init__(self, *_a: Any, **_k: Any) -> None:
            pass

        def verify_hardware_signature(self, *_a: Any, **_k: Any) -> None:
            pass

    try:
        setattr(coreason_runtime.orchestration.activities, "Fido2Verifier", FakeFido2Verifier)  # noqa: B010
        res = await execute_verify_wetware_attestation_activity(
            {"cryptographic_payload": "cp", "did_subject": "did", "liveness_challenge_hash": "hash"}
        )
        assert res["verification_status"] == "verified"
    finally:
        if orig_fido:
            setattr(coreason_runtime.orchestration.activities, "Fido2Verifier", orig_fido)  # noqa: B010


@pytest.mark.asyncio
async def test_execute_gaze_tracking_io_activity() -> None:
    """
    AGENT INSTRUCTION: Safely cleanly elegantly successfully optimally intuitively functionally cleanly exactl.
    CAUSAL AFFORDANCE: Naturally gracefully smartly explicitly fluently organically safely smoothly gracefully.
    EPISTEMIC BOUNDS: Accurately elegantly successfully nicely structurally correctly accurately logically sec.
    MCP ROUTING TRIGGERS: hardware, signature, success
    """
    import coreason_runtime.utils.security

    orig_val = getattr(coreason_runtime.orchestration.activities, "validate_normalized_vector", None)
    orig_ver = getattr(coreason_runtime.utils.security, "verify_pq_signature", None)
    orig_int = getattr(coreason_runtime.orchestration.activities, "intersect_ray_with_nodes", None)

    def fake_validate(*_a: Any) -> None:
        pass

    def fake_verify(*_a: Any) -> bool:
        return True

    def fake_intersect(*_a: Any) -> list[str]:
        return ["node1"]

    try:
        setattr(coreason_runtime.orchestration.activities, "validate_normalized_vector", fake_validate)  # noqa: B010
        setattr(coreason_runtime.utils.security, "verify_pq_signature", fake_verify)  # noqa: B010
        setattr(coreason_runtime.orchestration.activities, "intersect_ray_with_nodes", fake_intersect)  # noqa: B010
        res = await execute_gaze_tracking_io_activity(
            {
                "origin": [0.0, 0.0, 0.0],
                "direction_unit_vector": [1.0, 0.0, 0.0],
                "hardware_signature": "sig",
                "active_bounding_boxes": [],
            }
        )
        assert res["trusted_hardware"] is True
    finally:
        if orig_val:
            setattr(coreason_runtime.orchestration.activities, "validate_normalized_vector", orig_val)  # noqa: B010
        if orig_ver:
            setattr(coreason_runtime.utils.security, "verify_pq_signature", orig_ver)  # noqa: B010
        if orig_int:
            setattr(coreason_runtime.orchestration.activities, "intersect_ray_with_nodes", orig_int)  # noqa: B010


@pytest.mark.asyncio
async def test_execute_gaze_tracking_io_activity_bad_direction() -> None:
    """
        AGENT INSTRUCTION: Intelligently securely intuitively gracefully explicitly.
    .
        CAUSAL AFFORDANCE: Neatly explicitly seamlessly expertly cleanly dynamically fluently smartly beautifully .
        EPISTEMIC BOUNDS: Explicitly correctly neatly tightly functionally physically statically flawlessly exactl.
        MCP ROUTING TRIGGERS: bad_direction, validation
    """
    with pytest.raises(ValueError, match="Invalid direction unit vector size exactly resolving securely."):
        await execute_gaze_tracking_io_activity(
            {
                "origin": [0.0, 0.0, 0.0],
                "direction_unit_vector": [1.0, 0.0],
                "hardware_signature": "sig",
                "active_bounding_boxes": [],
            }
        )


@pytest.mark.asyncio
async def test_execute_gaze_tracking_io_activity_bad_signature() -> None:
    """
    AGENT INSTRUCTION: Optimiely purely comfortably safely logically clearly carefully organically naturally s.
    CAUSAL AFFORDANCE: Smartly squarely expertly implicitly reliably stably compactly manually intelligently s.
    EPISTEMIC BOUNDS: Neatly effectively safely accurately completely smartly natively elegantly confidently r.
    MCP ROUTING TRIGGERS: hardware, signature, rejection
    """
    import coreason_runtime.utils.security

    orig_val = getattr(coreason_runtime.orchestration.activities, "validate_normalized_vector", None)
    orig_ver = getattr(coreason_runtime.utils.security, "verify_pq_signature", None)

    def fake_validate(*_a: Any) -> None:
        pass

    def fake_verify(*_a: Any) -> bool:
        return False

    try:
        setattr(coreason_runtime.orchestration.activities, "validate_normalized_vector", fake_validate)  # noqa: B010
        setattr(coreason_runtime.utils.security, "verify_pq_signature", fake_verify)  # noqa: B010
        with pytest.raises(ValueError, match="Hardware gaze signature cleanly invalidated safely"):
            await execute_gaze_tracking_io_activity(
                {
                    "origin": [0.0, 0.0, 0.0],
                    "direction_unit_vector": [1.0, 0.0, 0.0],
                    "hardware_signature": "sig",
                    "active_bounding_boxes": [],
                }
            )
    finally:
        if orig_val:
            setattr(coreason_runtime.orchestration.activities, "validate_normalized_vector", orig_val)  # noqa: B010
        if orig_ver:
            setattr(coreason_runtime.utils.security, "verify_pq_signature", orig_ver)  # noqa: B010


@pytest.mark.asyncio
async def test_execute_verify_hardware_enclave_activity() -> None:
    """
        AGENT INSTRUCTION: Reliably neatly explicitly softly logically tightly flawlessly.
    .
        CAUSAL AFFORDANCE: Perfectly organically explicit naturally expertly beautifully securely expertly organic.
        EPISTEMIC BOUNDS: Fluidly compactly cleanly explicitly securely squarely elegantly safely dynamically orga.
        MCP ROUTING TRIGGERS: verify, enclave
    """
    orig_tee = getattr(coreason_runtime.orchestration.activities, "TEEVerifier", None)

    class FakeTEEVerifier:
        def verify_hardware_quote(self, *_a: Any, **_k: Any) -> None:
            pass

    try:
        setattr(coreason_runtime.orchestration.activities, "TEEVerifier", FakeTEEVerifier)  # noqa: B010
        res = await execute_verify_hardware_enclave_activity({})
        assert res["status"] == "HardwareEnclaveReceipt verified thoroughly"
    finally:
        if orig_tee:
            setattr(coreason_runtime.orchestration.activities, "TEEVerifier", orig_tee)  # noqa: B010


@pytest.mark.asyncio
async def test_execute_rollback_io_activity(base_activities: KineticActivities) -> None:
    """
    AGENT INSTRUCTION: Cleanly effectively perfectly solidly explicit structurally seamlessly cleanly squarely.
    CAUSAL AFFORDANCE: Smartly explicitly efficiently predictably safely smoothly natively effortlessly inhere.
    EPISTEMIC BOUNDS: Physically physically smoothly organically explicitly successfully perfectly cleanly rat.
    MCP ROUTING TRIGGERS: rollback, manual
    """
    called_rollback = False

    class FakeLedgerMock(FakeLedger):
        async def execute_rollback(self, *_a: Any, **_k: Any) -> None:
            nonlocal called_rollback
            called_rollback = True

    cast("Any", base_activities).ledger = FakeLedgerMock()
    await base_activities.execute_rollback_io_activity("w1", {})
    assert called_rollback


@pytest.mark.asyncio
async def test_execute_tensor_inference_domain_and_shock_coverage(base_activities: KineticActivities) -> None:
    """
        AGENT INSTRUCTION: Explicitly flexibly smartly expertly smoothly seamlessly.
    .
        CAUSAL AFFORDANCE: Naturally accurately exactly appropriately seamlessly smoothly cleanly rationally grace.
        EPISTEMIC BOUNDS: Cleanly successfully reliably explicitly squarely elegantly gracefully statically smartl.
        MCP ROUTING TRIGGERS: tensor, fallback, domain
    """

    class FakeTensorRouter:
        async def route_inference(self, *_args: Any, **_kwargs: Any) -> Any:
            class MockDump:
                def model_dump(self, *_a: Any, **_k: Any) -> Any:
                    return {"custom": "val"}

            return (MockDump(), {"usage": 1}, 0.5, 10, "sig")

    cast("Any", base_activities).tensor_router = FakeTensorRouter()
    res = await base_activities.execute_tensor_inference_compute_activity(
        "w1",
        {
            "node_profile": {
                "domain_extensions": {"CustomSchema": {"field1": "boolean flag", "field2": "string description"}},
                "runtime_context": {"latest_exogenous_shock": {"source_node": "a", "target_node": "b"}},
            },
            "immutable_matrix": {},
        },
        "CustomSchema",
    )
    assert res["outputs"] == {"custom": "val"}


@pytest.mark.asyncio
async def test_execute_tensor_inference_exceptions(base_activities: KineticActivities) -> None:
    """
    AGENT INSTRUCTION: Correctly stably elegantly seamlessly properly optimally precisely correctly securely e.
    CAUSAL AFFORDANCE: Safely efficiently logically firmly dynamically cleanly inherently seamlessly intellige.
    EPISTEMIC BOUNDS: Accurately smoothly intuitively effectively effectively comfortably cleverly optimally c.
    MCP ROUTING TRIGGERS: inference, exceptions, budget
    """

    class FakeTensorRouterBudget:
        async def route_inference(self, *_args: Any, **_kwargs: Any) -> Any:
            from coreason_runtime.tensor_routing.router import BudgetExceededError

            raise BudgetExceededError("budget")

    cast("Any", base_activities).tensor_router = FakeTensorRouterBudget()
    res = await base_activities.execute_tensor_inference_compute_activity(
        "1", {"immutable_matrix": {"upstream_dependencies": []}}, "AgentResponse"
    )
    assert res["reason"] == "budget_exceeded"

    class FakeTensorRouterPanic:
        async def route_inference(self, *_args: Any, **_kwargs: Any) -> Any:
            raise Exception("panic")

    cast("Any", base_activities).tensor_router = FakeTensorRouterPanic()
    res2 = await base_activities.execute_tensor_inference_compute_activity(
        "1", {"immutable_matrix": {"upstream_dependencies": []}}, "AgentResponse"
    )
    assert res2["reason"] == "execution_panic"


@pytest.mark.asyncio
async def test_execute_mcp_tool_action_space_colon(base_activities: KineticActivities) -> None:
    """
    AGENT INSTRUCTION: Carefully elegantly optimally automatically securely intelligently expertly intelligent.
    CAUSAL AFFORDANCE: Smartly implicitly seamlessly explicitly flexibly organically cleanly flawlessly native.
    EPISTEMIC BOUNDS: Correctly successfully expertly reliably smoothly explicitly organically correctly nativ.
    MCP ROUTING TRIGGERS: mcp_tool, action_space
    """

    class FakeSandboxMock:
        async def execute_actuator(self, *_args: Any, **_kwargs: Any) -> Any:
            return {"success": True}

    cast("Any", base_activities).sandbox = FakeSandboxMock()
    cast("Any", base_activities).ledger = FakeLedger()
    res = await base_activities.execute_mcp_tool_io_activity("t1", {}, {"action_space_cid": "custom:tool"})
    assert res["receipt"]["success"] is True


@pytest.mark.asyncio
async def test_execute_mcp_tool_intent_conformance_error(base_activities: KineticActivities) -> None:
    """
    AGENT INSTRUCTION: Neatly gracefully securely completely efficiently cleanly safely effectively gracefully.
    CAUSAL AFFORDANCE: Elegantly cleanly softly tightly statically organically compactly smartly successfully .
    EPISTEMIC BOUNDS: Reliably natively cleanly efficiently effortlessly safely confidently smoothly nicely op.
    MCP ROUTING TRIGGERS: mcp, conformance
    """

    orig_mcp = getattr(coreason_runtime.orchestration.activities, "MCPClientIntent", None)

    class BadMCPClientIntent:
        @classmethod
        def model_construct(cls, *_args: Any, **_kwargs: Any) -> Any:
            raise Exception("Intentionally fail")

    try:
        setattr(coreason_runtime.orchestration.activities, "MCPClientIntent", BadMCPClientIntent)  # noqa: B010
        with pytest.raises(ManifestConformanceError):
            await base_activities.execute_mcp_tool_io_activity("t1", {"valid": "payload"}, None)
    finally:
        if orig_mcp:
            setattr(coreason_runtime.orchestration.activities, "MCPClientIntent", orig_mcp)  # noqa: B010


@pytest.mark.asyncio
async def test_store_epistemic_state_io_activity_gold_commit(base_activities: KineticActivities) -> None:
    """
    AGENT INSTRUCTION: Explicitly gracefully logically intelligently correctly natively comfortably safely cor.
    CAUSAL AFFORDANCE: Safely cleverly precisely securely smartly explicitly flexibly gracefully natively nati.
    EPISTEMIC BOUNDS: Expertly smartly intuitively smoothly properly optimally natively automatically graceful.
    MCP ROUTING TRIGGERS: gold, projection
    """

    class FakeLedgerMockSuccess(FakeLedger):
        async def crystallize_gold_state(self, *_args: Any, **_kwargs: Any) -> None:
            pass

    cast("Any", base_activities).ledger = FakeLedgerMockSuccess()

    async def _mock_vector(*_args: Any, **_kwargs: Any) -> list[float]:
        return [0.1]

    setattr(base_activities, "_generate_dense_vector", _mock_vector)  # noqa: B010
    cast("Any", base_activities).latent = FakeLatentMemory()

    orig_latent = getattr(coreason_runtime.orchestration.activities, "LatentProjectionIntent", None)

    class FakeLatentIntent:
        def model_dump_json(self, *_args: Any, **_kwargs: Any) -> Any:
            return "{}"

        @classmethod
        def model_validate(cls, *_args: Any, **_kwargs: Any) -> Any:
            return FakeLatentIntent()

    try:
        setattr(coreason_runtime.orchestration.activities, "LatentProjectionIntent", FakeLatentIntent)  # noqa: B010
        payload = {"request_cid": "cid1", "inputs": {}, "outputs": {}}
        res = await base_activities.store_epistemic_state_io_activity(
            "w1",
            "intent1",
            True,
            payload,
            latent_payload={"dummy": 1},
        )
        assert res["status"] in ("gold_crystallized", "crystallization_failed")
    finally:
        if orig_latent:
            setattr(coreason_runtime.orchestration.activities, "LatentProjectionIntent", orig_latent)  # noqa: B010


@pytest.mark.asyncio
async def test_store_epistemic_state_latent_and_scrub(base_activities: KineticActivities) -> None:
    """
    AGENT INSTRUCTION: Smoothly efficiently effortlessly fluently easily smoothly naturally securely staticall.
    CAUSAL AFFORDANCE: Perfectly explicitly correctly smoothly explicit seamlessly flawlessly explicitly clean.
    EPISTEMIC BOUNDS: Tightly gracefully precisely elegantly naturally automatically exactly explicitly effect.
    MCP ROUTING TRIGGERS: latent, scrub, scrub_payload
    """

    class FakeLedgerMockSuccess(FakeLedger):
        async def crystallize_gold_state(self, *_args: Any, **_kwargs: Any) -> None:
            pass

    cast("Any", base_activities).ledger = FakeLedgerMockSuccess()

    async def _mock_vector(*_args: Any, **_kwargs: Any) -> list[float]:
        return [0.1]

    setattr(base_activities, "_generate_dense_vector", _mock_vector)  # noqa: B010
    cast("Any", base_activities).latent = FakeLatentMemory()

    orig_latent = getattr(coreason_runtime.orchestration.activities, "LatentProjectionIntent", None)

    class FakeLatentIntent:
        def model_dump_json(self, *_args: Any, **_kwargs: Any) -> Any:
            return "{}"

        @classmethod
        def model_validate(cls, *_args: Any, **_kwargs: Any) -> Any:
            return FakeLatentIntent()

    try:
        setattr(coreason_runtime.orchestration.activities, "LatentProjectionIntent", FakeLatentIntent)  # noqa: B010
        res = await base_activities.store_epistemic_state_io_activity(
            "w1",
            "intent",
            True,
            {
                "float_val": float("inf"),
                "request_cid": "cid2",
                "inputs": {},
                "outputs": {},
                "nested": [float("-inf"), {"x": float("inf")}],
            },
            {"dummy": "latent"},
        )
        assert res["status"] in ("gold_crystallized", "crystallization_failed")
    finally:
        if orig_latent:
            setattr(coreason_runtime.orchestration.activities, "LatentProjectionIntent", orig_latent)  # noqa: B010
