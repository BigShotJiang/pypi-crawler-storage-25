from typing import Any
from unittest.mock import MagicMock

import pytest

from coreason_runtime.orchestration.activities import KineticActivities


@pytest.fixture
def activities() -> KineticActivities:
    return KineticActivities(
        sglang_url="http://local", memory_path="/tmp/mem", plugins_dir="/tmp/plugins", telemetry_url="ws://local"
    )


@pytest.mark.asyncio
async def test_retrieve_latent_projection(monkeypatch: pytest.MonkeyPatch, activities: KineticActivities) -> None:
    # 287-363: RetrieveLatentProjectionComputeActivity
    import base64
    import json
    import struct

    b64_vec = base64.b64encode(struct.pack("3f", 0.1, 0.2, 0.3)).decode()
    mock_intent = MagicMock()
    mock_intent.synthetic_target_vector.dimensionality = 3
    mock_intent.synthetic_target_vector.vector_base64 = b64_vec
    mock_intent.top_k_candidates = 5
    mock_intent.min_isometry_score = 0.5
    mock_intent.topological_bounds.max_hop_depth = 2

    mock_cls = MagicMock()
    mock_cls.model_validate.return_value = mock_intent
    monkeypatch.setattr("coreason_manifest.spec.ontology.LatentProjectionIntent", mock_cls)

    payload = {"intent": "placeholder"}

    # Mock self.db and self.gold_table_name
    activities.gold_table_name = "gold_tier"  # type: ignore
    activities.db = MagicMock()  # type: ignore
    activities.db.table_names.return_value = ["latent_space", "gold_tier"]  # type: ignore

    latent_table = MagicMock()
    latent_search = MagicMock()
    latent_search.metric.return_value = latent_search
    latent_search.limit.return_value = latent_search
    latent_search.to_arrow.return_value.to_pylist.return_value = [
        {"_distance": 0.1, "intent_hash": "hash_1"},
        {"_distance": 0.8, "intent_hash": "hash_2"},  # Should be pruned
    ]
    latent_table.search.return_value = latent_search

    gold_table = MagicMock()
    gold_search = MagicMock()
    gold_search.where.return_value = gold_search
    gold_search.to_arrow.return_value.to_pylist.return_value = [
        {"intent_hash": "hash_1", "receipt_payload": json.dumps({"parent_hashes": ["hash_parent"]})},
        {"intent_hash": "hash_parent", "receipt_payload": json.dumps({"info": "parent"})},
    ]
    gold_table.search.return_value = gold_search

    def open_table_mock(name: str) -> Any:
        if name == "latent_space":
            return latent_table
        if name == "gold_tier":
            return gold_table
        return None

    activities.db.open_table.side_effect = open_table_mock  # type: ignore

    results = await activities.retrieve_latent_projection_compute_activity(payload)
    assert len(results) >= 2


@pytest.mark.asyncio
async def test_execute_exogenous_shock(monkeypatch: pytest.MonkeyPatch, activities: KineticActivities) -> None:
    # 368-378: ExecuteExogenousShockComputeActivity
    mock_intent = MagicMock()
    mock_intent.bayesian_surprise_score = 0.95
    mock_intent.target_node_hash = "target"
    mock_intent.shock_cid = "shock-1"
    mock_intent.synthetic_payload = {"key": "value"}
    mock_intent.escrow.locked_magnitude = 100.0

    mock_cls = MagicMock()
    mock_cls.model_validate.return_value = mock_intent
    monkeypatch.setattr("coreason_manifest.spec.ontology.ExogenousEpistemicEvent", mock_cls)

    payload = {"intent": "placeholder"}

    res = await activities.execute_exogenous_shock_compute_activity(payload)
    assert res["status"] == "success"
    assert res["target_hash_injected"] == "target"


@pytest.mark.asyncio
async def test_execute_ontology_discovery(monkeypatch: pytest.MonkeyPatch, activities: KineticActivities) -> None:
    # 390-424: ExecuteOntologyDiscoveryComputeActivity
    mock_intent = MagicMock()
    mock_intent.query_concept_cid = "concept-123"
    mock_intent.target_registry_uri = "http://ontology.fake/schema"
    mock_cls = MagicMock()
    mock_cls.model_validate.return_value = mock_intent
    monkeypatch.setattr("coreason_manifest.spec.ontology.OntologyDiscoveryIntent", mock_cls)

    payload = {"intent": "placeholder"}

    class FakeResp:
        def raise_for_status(self) -> None:
            pass

        headers = {"content-type": "application/json"}  # noqa: RUF012
        text = '{"foo": "bar"}'

        def json(self) -> dict[str, Any]:
            return {"foo": "bar"}

    class FakeClient:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            pass

        async def __aenter__(self) -> Any:
            return self

        async def __aexit__(self, *args: Any, **kwargs: Any) -> None:
            pass

        async def get(self, *args: Any, **kwargs: Any) -> Any:  # noqa: ARG002
            return FakeResp()

    import httpx

    monkeypatch.setattr(httpx, "AsyncClient", FakeClient)

    res = await activities.execute_ontology_discovery_compute_activity(payload)
    assert len(res) == 1
    assert res[0]["status"] == "success"
    assert "isometry_score" in res[0]


@pytest.mark.asyncio
async def test_execute_system_function_wasm(monkeypatch: pytest.MonkeyPatch, activities: KineticActivities) -> None:
    # 465-490: ExecuteSystemFunctionComputeActivity
    payload = {
        "domain_extensions": {"execution_type": "wasm", "wasm_tool": "test-plugin", "arguments": {"input": "data"}}
    }

    async def mock_execute(*args: Any, **kwargs: Any) -> Any:
        return {"success": True, "output": "wasm-output", "error": ""}

    from coreason_runtime.execution_plane.wasm_guest_dispatcher import WasmGuestDispatcher

    monkeypatch.setattr(WasmGuestDispatcher, "execute_actuator", mock_execute)
    monkeypatch.setattr("coreason_manifest.MCPClientIntent", MagicMock)

    res = await activities.execute_system_function_compute_activity(payload)
    assert res["success"] is True
    assert res["data"] == "wasm-output"


@pytest.mark.asyncio
async def test_hydrate_mcp_prompt(monkeypatch: pytest.MonkeyPatch, activities: KineticActivities) -> None:
    # 535-543: HydrateMCPPromptIOActivity
    payload = {"intent": "placeholder"}
    mock_mgr = MagicMock()

    async def mock_hydrate(*args: Any, **kwargs: Any) -> Any:
        return "hydrated"

    mock_mgr.hydrate_prompt = mock_hydrate
    activities.mcp_manager = mock_mgr

    mock_intent = MagicMock()
    mock_cls = MagicMock()
    mock_cls.model_validate.return_value = mock_intent
    monkeypatch.setattr("coreason_runtime.orchestration.activities.MCPPromptReferenceState", mock_cls)

    res = await activities.hydrate_mcp_prompt_io_activity(payload)
    assert res["status"] == "success"

    async def mock_hydrate_err(*args: Any, **kwargs: Any) -> Any:
        raise Exception("failed")

    mock_mgr.hydrate_prompt = mock_hydrate_err
    res_err = await activities.hydrate_mcp_prompt_io_activity(payload)
    assert res_err["status"] == "error"


@pytest.mark.asyncio
async def test_fetch_mcp_resources(monkeypatch: pytest.MonkeyPatch, activities: KineticActivities) -> None:
    # 555-563: FetchMCPResourcesIOActivity
    payload = {"intent": "placeholder"}
    mock_mgr = MagicMock()

    async def mock_read(*args: Any, **kwargs: Any) -> Any:
        return "resource"

    mock_mgr.read_resource = mock_read
    activities.mcp_manager = mock_mgr

    mock_intent = MagicMock()
    mock_cls = MagicMock()
    mock_cls.model_validate.return_value = mock_intent
    monkeypatch.setattr("coreason_runtime.orchestration.activities.MCPResourceManifest", mock_cls)

    res = await activities.fetch_mcp_resources_io_activity(payload)
    assert res["status"] == "success"

    async def mock_read_err(*args: Any, **kwargs: Any) -> Any:
        raise Exception("failed")

    mock_mgr.read_resource = mock_read_err
    res_err = await activities.fetch_mcp_resources_io_activity(payload)
    assert res_err["status"] == "error"
