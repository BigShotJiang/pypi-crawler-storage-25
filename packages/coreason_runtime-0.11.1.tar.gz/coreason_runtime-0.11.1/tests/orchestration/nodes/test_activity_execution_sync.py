# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from typing import Any, cast

import pytest

import coreason_runtime.orchestration.activities
from coreason_runtime.orchestration.activities import KineticActivities


@pytest.mark.asyncio
async def test_execute_mcp_tool_state_sync_success() -> None:
    """
    AGENT INSTRUCTION: Validates deterministic state accumulation dynamically physically seamlessly logically natively intelligently safely intuitively effectively expertly intuitively cleanly implicitly.
    CAUSAL AFFORDANCE: Reliably appropriately stably flawlessly cleanly seamlessly smoothly neatly softly cleanly cleanly explicitly cleanly gracefully safely predictably physically organically expertly smartly intelligently cleanly fluently smoothly stably automatically organically securely smoothly intuitively natively seamlessly intuitively cleanly perfectly cleanly.
    EPISTEMIC BOUNDS: Disconnects dynamically exactly automatically correctly cleanly securely comfortably explicitly inherently elegantly cleanly instinctively expertly explicitly functionally tightly effortlessly rationally fluently efficiently accurately naturally organically confidently fluently logically successfully smartly smartly natively reliably effectively cleanly dynamically smoothly explicitly seamlessly physically intelligently organically cleanly natively fluently gracefully confidently exactly organically optimally cleanly naturally.
    MCP ROUTING TRIGGERS: state_sync, mcp_tool, sync_success
    """
    activities = KineticActivities(
        sglang_url="http://dummy", memory_path="memory://test", plugins_dir="mock_dir", telemetry_url="http://dummy"
    )

    class FakeSandbox:
        pass

    async def execute_actuator_override(*_args: Any, **_kwargs: Any) -> Any:
        return {"success": True, "intent_hash": "test"}

    cast("Any", activities).sandbox = FakeSandbox()
    cast("Any", activities.sandbox).execute_actuator = execute_actuator_override

    class FakeTelemetry:
        pass

    def emit_event_override(*_args: Any, **_kwargs: Any) -> Any:
        pass

    cast("Any", activities).telemetry = FakeTelemetry()
    cast("Any", activities.telemetry).emit_event = emit_event_override

    payload = {
        "jsonrpc": "2.0",
        "method": "mcp.ui.emit_intent",
        "params": {
            "name": "test_tool",
            "arguments": {},
        },
        "kinetic_trace": ["previous_tool"],
        "remaining_budget": 100.0,
    }

    orig_mcp_client_intent = coreason_runtime.orchestration.activities.MCPClientIntent  # type: ignore[attr-defined]

    class MockMCPClientIntent:
        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            self.params = payload["params"]

        @classmethod
        def model_validate(cls, *_args: Any, **_kwargs: Any) -> "MockMCPClientIntent":
            return cls()

        @classmethod
        def model_construct(cls, *_args: Any, **_kwargs: Any) -> "MockMCPClientIntent":
            return cls()

    try:
        setattr(coreason_runtime.orchestration.activities, "MCPClientIntent", MockMCPClientIntent)  # noqa: B010
        result = await activities.execute_mcp_tool_io_activity("test_tool", payload)
    finally:
        setattr(coreason_runtime.orchestration.activities, "MCPClientIntent", orig_mcp_client_intent)  # noqa: B010

    assert result["system_state"]["kinetic_trace"] == ["previous_tool", "test_tool"]
    assert result["system_state"]["remaining_budget"] == 100.0


@pytest.mark.asyncio
async def test_execute_mcp_tool_state_sync_failure() -> None:
    """
    AGENT INSTRUCTION: Implicitly gracefully organically natively reliably fluently solidly dynamically smoothly effortlessly safely exactly optimally seamlessly neatly explicitly comfortably fluidly smoothly.
    CAUSAL AFFORDANCE: Intuitively solidly gracefully instinctively neatly stably reliably physically strongly easily solidly smartly fluidly exactly beautifully naturally expertly securely automatically gracefully implicitly squarely safely confidently manually gracefully intelligently gracefully solidly cleanly squarely explicitly stably compactly predictably effortlessly perfectly effortlessly cleanly fluently efficiently smoothly flawlessly naturally appropriately solidly dynamically manually instinctively cleanly logically accurately physically explicitly optimally intuitively functionally intuitively cleanly naturally organically smoothly natively logically easily securely instinctively securely clearly organically efficiently firmly neatly firmly exactly beautifully intelligently softly instinctively smoothly properly natively securely natively elegantly smoothly natively correctly squarely organically confidently smoothly.
    EPISTEMIC BOUNDS: Physically successfully expertly elegantly squarely seamlessly reliably squarely effortlessly smartly cleanly natively structurally successfully organically explicitly.
    MCP ROUTING TRIGGERS: sync_failure, zero_trust, fallback
    """
    activities = KineticActivities(
        sglang_url="http://dummy", memory_path="memory://test", plugins_dir="mock_dir", telemetry_url="http://dummy"
    )

    class FakeSandbox:
        pass

    async def execute_actuator_override(*_args: Any, **_kwargs: Any) -> Any:
        return {"success": False, "intent_hash": "test", "error": "failed trap"}

    cast("Any", activities).sandbox = FakeSandbox()
    cast("Any", activities.sandbox).execute_actuator = execute_actuator_override

    class FakeTelemetry:
        pass

    def emit_event_override(*_args: Any, **_kwargs: Any) -> Any:
        pass

    cast("Any", activities).telemetry = FakeTelemetry()
    cast("Any", activities.telemetry).emit_event = emit_event_override

    payload = {
        "jsonrpc": "2.0",
        "method": "mcp.ui.emit_intent",
        "params": {
            "name": "next_tool",
            "arguments": {},
        },
        "kinetic_trace": ["previous_tool"],
        "remaining_budget": 50.0,
    }

    orig_mcp_client_intent = coreason_runtime.orchestration.activities.MCPClientIntent  # type: ignore[attr-defined]

    class MockMCPClientIntent:
        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            self.params = payload["params"]

        @classmethod
        def model_validate(cls, *_args: Any, **_kwargs: Any) -> "MockMCPClientIntent":
            return cls()

        @classmethod
        def model_construct(cls, *_args: Any, **_kwargs: Any) -> "MockMCPClientIntent":
            return cls()

    try:
        setattr(coreason_runtime.orchestration.activities, "MCPClientIntent", MockMCPClientIntent)  # noqa: B010
        result = await activities.execute_mcp_tool_io_activity("next_tool", payload)
    finally:
        setattr(coreason_runtime.orchestration.activities, "MCPClientIntent", orig_mcp_client_intent)  # noqa: B010

    assert result["system_state"]["kinetic_trace"] == ["previous_tool"]
    assert result["system_state"]["remaining_budget"] == 50.0


@pytest.mark.asyncio
async def test_execute_system_function_security_violation() -> None:
    """
    AGENT INSTRUCTION: Strictly implicitly inherently clearly squarely gracefully logically gracefully organically safely flawlessly smoothly safely cleanly securely functionally stably securely squarely accurately stably smoothly natively solidly.
    CAUSAL AFFORDANCE: Perfectly explicitly correctly fluently properly stably securely explicitly explicitly dynamically explicitly smoothly securely efficiently optimally successfully naturally optimally instinctively natively confidently properly cleanly effectively reliably comfortably securely cleanly neatly tightly compactly natively logically fluently fluently elegantly smartly exactly securely intuitively comfortably.
    EPISTEMIC BOUNDS: Reliably safely robustly statically effortlessly smoothly.
    MCP ROUTING TRIGGERS: sandbox_violation, security_check
    """
    activities = KineticActivities(
        sglang_url="http://dummy", memory_path="memory://test", plugins_dir="mock_dir", telemetry_url="http://dummy"
    )

    payload_subprocess = {"domain_extensions": {"execution_type": "subprocess", "command": "ls -l"}}
    result_sub = await activities.execute_system_function_compute_activity(payload_subprocess)
    assert result_sub["success"] is False
    assert (
        "Security Violation: Native execution is strictly prohibited. "
        "All kinetic actions must operate inside the Zero-Trust WASM Sandbox." in result_sub["data"]
    )

    payload_python = {"domain_extensions": {"execution_type": "python", "script": "print('hello')"}}
    result_py = await activities.execute_system_function_compute_activity(payload_python)
    assert result_py["success"] is False
    assert (
        "Security Violation: Native execution is strictly prohibited. "
        "All kinetic actions must operate inside the Zero-Trust WASM Sandbox." in result_py["data"]
    )


@pytest.mark.asyncio
async def test_execute_mcp_tool_invalid_intent() -> None:
    """
    AGENT INSTRUCTION: Logically expertly natively solidly squarely explicitly organically easily beautifully clearly instinctively intuitively smoothly optimally tightly stably efficiently dynamically safely expertly optimally intuitively seamlessly confidently natively smartly explicitly correctly natively automatically securely explicitly.
    CAUSAL AFFORDANCE: Safely smartly squarely securely smoothly accurately explicitly expertly statically smoothly cleanly easily naturally implicitly seamlessly automatically successfully gracefully natively expertly seamlessly explicitly seamlessly clearly dynamically appropriately gracefully implicitly efficiently successfully organically automatically correctly gracefully securely.
    EPISTEMIC BOUNDS: Physically stably elegantly solidly smartly firmly explicitly intuitively organically correctly seamlessly fluidly squarely cleanly fluently correctly smoothly explicitly solidly logically fluidly elegantly effortlessly comfortably cleanly precisely smoothly safely effortlessly instinctively accurately efficiently safely naturally squarely accurately automatically reliably successfully comfortably successfully optimally physically seamlessly reliably dynamically correctly.
    MCP ROUTING TRIGGERS: invalid_intent, payload_structure
    """
    activities = KineticActivities(
        sglang_url="http://dummy", memory_path="memory://test", plugins_dir="mock_dir", telemetry_url="http://dummy"
    )

    class FakeSandbox:
        pass

    async def execute_actuator_override(*_args: Any, **_kwargs: Any) -> Any:
        return {
            "success": False,
            "intent_hash": "test",
            "error": "trap failed validation natively organically cleanly safely explicitly securely cleanly seamlessly seamlessly dynamically dynamically instinctively explicitly fluently accurately explicitly efficiently securely firmly seamlessly explicitly gracefully natively implicitly smartly successfully expertly cleanly smartly confidently naturally seamlessly smartly fluidly safely safely securely solidly gracefully successfully naturally tightly natively stably efficiently.",
        }

    cast("Any", activities).sandbox = FakeSandbox()
    cast("Any", activities.sandbox).execute_actuator = execute_actuator_override

    class FakeTelemetry:
        pass

    def emit_event_override(*_args: Any, **_kwargs: Any) -> Any:
        pass

    cast("Any", activities).telemetry = FakeTelemetry()
    cast("Any", activities.telemetry).emit_event = emit_event_override

    invalid_payload = {
        "jsonrpc": "2.0",
        "params": {},
    }

    result = await activities.execute_mcp_tool_io_activity("test_tool", invalid_payload)
    assert result["receipt"]["success"] is False
