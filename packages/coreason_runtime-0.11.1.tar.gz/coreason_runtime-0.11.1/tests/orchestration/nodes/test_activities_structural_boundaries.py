import time
from unittest.mock import AsyncMock, MagicMock

import pytest

from coreason_runtime.orchestration.activities import KineticActivities, calculate_cosine_similarity


@pytest.fixture
def activities() -> KineticActivities:
    act = KineticActivities(
        sglang_url="http://local", memory_path="/tmp/mem", plugins_dir="/tmp/plugins", telemetry_url="ws://local"
    )
    act.ledger = AsyncMock()
    act.telemetry = MagicMock()
    return act


@pytest.mark.asyncio
async def test_hydrate_action_space_caching(activities: KineticActivities) -> None:
    activities.ledger.fetch_action_space_manifest.return_value = {"cached": False}  # type: ignore
    # 1. Fresh fetch
    res1 = await activities._hydrate_action_space("cid")
    assert res1 == {"cached": False}  # type: ignore
    # 2. Cached fetch
    activities.ledger.fetch_action_space_manifest.return_value = {"cached": "NEW"}  # type: ignore
    res2 = await activities._hydrate_action_space("cid")
    assert res2 == {"cached": False}  # type: ignore
    # 3. Cache expiration
    activities._action_space_cache["cid"] = ({"cached": False}, time.time() - 400)  # type: ignore
    res3 = await activities._hydrate_action_space("cid")
    assert res3 == {"cached": "NEW"}  # type: ignore
    # 4. Cache flush threshold
    for i in range(1005):
        activities._action_space_cache[f"c_{i}"] = (None, 0)  # type: ignore
    await activities._hydrate_action_space("overflow")
    assert len(activities._action_space_cache) == 1


@pytest.mark.asyncio
async def test_generate_dense_vector(monkeypatch: pytest.MonkeyPatch, activities: KineticActivities) -> None:
    monkeypatch.setenv("CLOUD_ORACLE_API_KEY", "key")
    monkeypatch.setenv("CLOUD_ORACLE_BASE_URL", "url")
    monkeypatch.setenv("CLOUD_ORACLE_EMBEDDING_MODEL", "model")
    mock_post = AsyncMock()
    mock_post.return_value.raise_for_status = MagicMock()
    mock_post.return_value.json = MagicMock(return_value={"data": [{"embedding": [1.0, 2.0]}]})
    mock_client = MagicMock()
    mock_client.__aenter__.return_value.post = mock_post
    monkeypatch.setattr("httpx.AsyncClient", MagicMock(return_value=mock_client))

    res = await activities._generate_dense_vector("hello")
    assert res == [1.0, 2.0]

    mock_post.side_effect = Exception("failed net")
    try:
        await activities._generate_dense_vector("hello")
    except BaseException as e:
        assert "Embedding" in str(e)  # noqa: PT017


@pytest.mark.asyncio
async def test_execute_defeasible_cascade(activities: KineticActivities) -> None:
    cascade = {
        "cascade_cid": "c1",
        "root_falsified_event_cid": "evt_0",
        "propagated_decay_factor": 0.5,
        "quarantined_event_cids": ["q1"],
    }
    ledger = {
        "history": [
            {
                "topology_class": "epistemic_log",
                "event_cid": "evt_0",
                "message": "hello",
                "level": "INFO",
                "timestamp": 123.0,
            }
        ]
    }
    res = await activities.execute_defeasible_cascade_compute_activity(cascade, ledger)
    assert res["status"] == "success"


@pytest.mark.asyncio
async def test_simple_io_activities(monkeypatch: pytest.MonkeyPatch, activities: KineticActivities) -> None:
    mock_t = MagicMock()
    mock_t.model_dump.return_value = {"announcement": "ok"}
    mock_tc = MagicMock()
    mock_tc.model_validate.return_value = mock_t
    monkeypatch.setattr("coreason_runtime.orchestration.activities.TaskAnnouncementIntent", mock_tc)

    res2 = await activities.announce_task_io_activity({"payload": "val"})
    assert res2["announcement"] == "ok"

    res = await activities.emit_resumed_event_io_activity("wf", "ag")
    assert res["status"] == "resumed"


@pytest.mark.asyncio
async def test_calculate_cosine_similarity() -> None:
    res = await calculate_cosine_similarity([1.0, 0.0], [1.0, 0.0])
    assert res == 1.0
    res2 = await calculate_cosine_similarity([], [])
    assert res2 == 0.0
    res3 = await calculate_cosine_similarity([0.0], [0.0])
    assert res3 == 0.0
