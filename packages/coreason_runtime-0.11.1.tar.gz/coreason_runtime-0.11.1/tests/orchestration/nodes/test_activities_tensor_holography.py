from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from coreason_runtime.orchestration.activities import KineticActivities
from coreason_runtime.tensor_routing.router import BudgetExceededError, EpistemicYieldError


@pytest.fixture
def activities() -> KineticActivities:
    act = KineticActivities(
        sglang_url="http://local", memory_path="/tmp/mem", plugins_dir="/tmp/plugins", telemetry_url="ws://local"
    )
    act.tensor_router = MagicMock()
    act.telemetry = MagicMock()
    return act


@pytest.mark.asyncio
async def test_tensor_schema_resolution_standard(activities: KineticActivities) -> None:
    # 565-850: standard schema resolution
    payload = {
        "node_profile": {"node_cid": "test-cid", "domain_extensions": {}},
        "immutable_matrix": {"tenant_cid": "tenant-1"},
    }

    mock_model = MagicMock()
    mock_model.model_dump.return_value = {"output": "standard_done"}
    activities.tensor_router.route_inference = AsyncMock(return_value=(mock_model, {"tokens": 10}, 0.0, 100, b"sig"))  # type: ignore

    res = await activities.execute_tensor_inference_compute_activity("wf_1", payload, "ExecutionNodeReceipt")
    assert res["outputs"]["output"] == "standard_done"


@pytest.mark.asyncio
async def test_tensor_schema_resolution_agent(activities: KineticActivities) -> None:
    # 613-632: AgentResponse & VerificationYield
    payload: Any = {"node_profile": {}}

    # 1. AgentResponse
    mock_model_1 = MagicMock()
    mock_model_1.model_dump.return_value = {"output": "agent_data"}
    activities.tensor_router.route_inference = AsyncMock(return_value=(mock_model_1, {}, 0.0, 0, b""))  # type: ignore
    res_1 = await activities.execute_tensor_inference_compute_activity("wf_1", payload, "AgentResponse")
    assert res_1["outputs"]["output"] == "agent_data"

    # 2. VerificationYield
    mock_model_2 = MagicMock()
    mock_model_2.model_dump.return_value = {"success": True, "justification": "verified"}
    activities.tensor_router.route_inference = AsyncMock(return_value=(mock_model_2, {}, 0.0, 0, b""))  # type: ignore
    res_2 = await activities.execute_tensor_inference_compute_activity("wf_1", payload, "VerificationYield")
    assert res_2["outputs"]["success"] is True


@pytest.mark.asyncio
async def test_tensor_schema_resolution_domain_exp(activities: KineticActivities) -> None:
    payload = {"node_profile": {"domain_extensions": {"CustomSchema": {"f1": "boolean flag", "f2": "string flag"}}}}
    mock_model = MagicMock()
    mock_model.model_dump.return_value = {"f1": True, "f2": "custom"}
    activities.tensor_router.route_inference = AsyncMock(return_value=(mock_model, {}, 0.0, 0, b""))  # type: ignore
    res = await activities.execute_tensor_inference_compute_activity("wf_1", payload, "CustomSchema")
    assert res["outputs"]["f1"] is True


@pytest.mark.asyncio
async def test_tensor_schema_resolution_autonomous(
    monkeypatch: pytest.MonkeyPatch, activities: KineticActivities
) -> None:
    # 633-846: AutonomousAgentResponse complex logic
    payload = {"node_profile": {"action_space_cid": "space_1"}}

    mock_space = MagicMock()

    mock_cap1 = MagicMock()
    mock_cap1.__class__.__name__ = "SpatialToolManifest"
    mock_cap1.tool_name = "spatial_drill"
    mock_cap1.description = "drills spatially"

    mock_cap2 = MagicMock()
    mock_cap2.__class__.__name__ = "MCPServerManifest"
    mock_cap2.server_cid = "mcp_server_1"
    mock_cap2.description = "remote server"

    mock_cap3 = MagicMock()
    mock_cap3.tool_name = "opaque_feature"
    mock_cap3.description = "opaque"
    mock_cap3.input_schema = {"type": "object"}

    mock_space.capabilities = {"cap1": mock_cap1, "cap2": mock_cap2, "cap3": mock_cap3}

    async def mock_hydrate(cid: str) -> Any:
        return mock_space

    activities._hydrate_action_space = mock_hydrate  # type: ignore

    # Mock MCP Manager inside activities
    mock_mgr = MagicMock()
    mock_mgr.profiles = {"mcp_server_1": True}

    class FakeClient:
        async def request(self, req_type: str) -> dict[str, Any]:  # noqa: ARG002
            return {"tools": [{"name": "mcp_drill", "description": "drills mcp", "inputSchema": {}}]}

    mock_mgr.get_client.return_value = FakeClient()
    activities.mcp_manager = mock_mgr

    mock_model = MagicMock()
    mock_model.model_dump.return_value = {"output": "autonomous_ok"}
    activities.tensor_router.route_inference = AsyncMock(return_value=(mock_model, {}, 0.0, 0, b""))  # type: ignore

    res = await activities.execute_tensor_inference_compute_activity("wf_1", payload, "AutonomousAgentResponse")
    assert res["outputs"]["output"] == "autonomous_ok"

    # Virtual Namespace Fallback
    payload_virtual = {"node_profile": {"action_space_cid": "missing_space"}}

    async def mock_hydrate_missing(cid: str) -> Any:
        return None

    activities._hydrate_action_space = mock_hydrate_missing  # type: ignore

    class FakeIndexer:
        def __init__(self) -> None:
            self.table = MagicMock()
            self.table.search().where().to_list.return_value = [{"description": "desc", "input_schema": {"k": "v"}}]

    monkeypatch.setattr("coreason_runtime.execution_plane.discovery_indexer.DiscoveryIndexer", FakeIndexer)
    res_v = await activities.execute_tensor_inference_compute_activity(
        "wf_1", payload_virtual, "AutonomousAgentResponse"
    )
    assert res_v["outputs"]["output"] == "autonomous_ok"


@pytest.mark.asyncio
async def test_tensor_exogenous_shock_mutation(activities: KineticActivities) -> None:
    # 851-915: payload mutations and exogenous shock
    payload = {
        "node_profile": {"runtime_context": {"latest_exogenous_shock": {"source_node": "a", "target_node": "b"}}},
        "immutable_matrix": {
            "upstream_dependencies": [],
            "tool_history": [{"observation": {"receipt": {"output": {"huge": "data" * 1000}}}}],
        },
        "compute_budget": float("inf"),
    }

    mock_model = MagicMock()
    mock_model.model_dump.return_value = {"status": "mutated"}
    activities.tensor_router.route_inference = AsyncMock(return_value=(mock_model, {}, 0.0, 0, b""))  # type: ignore

    res = await activities.execute_tensor_inference_compute_activity("wf_1", payload, "AgentResponse")
    assert res["outputs"]["status"] == "mutated"


@pytest.mark.asyncio
async def test_tensor_router_exceptions(activities: KineticActivities) -> None:
    # 946-955: exception mapping
    payload: Any = {"node_profile": {}}

    activities.tensor_router.route_inference = AsyncMock(side_effect=BudgetExceededError("broke"))  # type: ignore
    res_1 = await activities.execute_tensor_inference_compute_activity("wf_1", payload, "AgentResponse")
    assert res_1["reason"] == "budget_exceeded"

    activities.tensor_router.route_inference = AsyncMock(side_effect=EpistemicYieldError("yield"))  # type: ignore
    res_2 = await activities.execute_tensor_inference_compute_activity("wf_1", payload, "AgentResponse")
    assert res_2["reason"] == "oracle_required"

    activities.tensor_router.route_inference = AsyncMock(side_effect=ValueError("panic"))  # type: ignore
    res_3 = await activities.execute_tensor_inference_compute_activity("wf_1", payload, "AgentResponse")
    assert res_3["reason"] == "execution_panic"
