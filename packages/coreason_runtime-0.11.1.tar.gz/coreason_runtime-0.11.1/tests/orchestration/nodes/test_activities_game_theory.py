from unittest.mock import AsyncMock, MagicMock

import pytest

from coreason_runtime.orchestration.activities import (
    KineticActivities,
    execute_collective_intelligence_activity,
    execute_market_settlement_io_activity,
    execute_shapley_attribution_compute_activity,
)


@pytest.fixture
def activities() -> KineticActivities:
    act = KineticActivities(
        sglang_url="http://local", memory_path="/tmp/mem", plugins_dir="/tmp/plugins", telemetry_url="ws://local"
    )
    act.ledger = AsyncMock()
    return act


@pytest.mark.asyncio
async def test_record_token_burn(monkeypatch: pytest.MonkeyPatch, activities: KineticActivities) -> None:
    payload = {"event_cid": "evt_1"}

    mock_cls = MagicMock()
    mock_burn = MagicMock()
    mock_burn.event_cid = "hash"
    mock_cls.model_validate.return_value = mock_burn
    monkeypatch.setattr("coreason_manifest.TokenBurnReceipt", mock_cls)

    # Success
    res1 = await activities.record_token_burn_io_activity("wf_1", payload)
    assert res1["status"] == "token_burn_recorded"

    # Failure via empty dict
    await activities.record_token_burn_io_activity("wf_1", {})


@pytest.mark.asyncio
async def test_execute_resolve_auction(monkeypatch: pytest.MonkeyPatch, activities: KineticActivities) -> None:
    # 1335-1353
    mock_resolve = MagicMock()
    mock_award = MagicMock()
    mock_award.model_dump.return_value = {"award": "done"}
    mock_resolve.return_value = mock_award
    monkeypatch.setattr("coreason_runtime.orchestration.activities.resolve_auction", mock_resolve)

    # Instead of fighting Pydantic validation of AuctionState without knowing its fields,
    # we patch the validation
    mock_state_cls = MagicMock()
    mock_state_cls.model_validate.return_value = MagicMock()
    monkeypatch.setattr("coreason_runtime.orchestration.activities.AuctionState", mock_state_cls)

    mock_policy_cls = MagicMock()
    mock_policy_cls.model_validate.return_value = MagicMock()
    monkeypatch.setattr("coreason_runtime.orchestration.activities.AuctionPolicy", mock_policy_cls)

    res = await activities.execute_resolve_auction_compute_activity({}, {})
    assert res["award"] == "done"


@pytest.mark.asyncio
async def test_execute_settle_prediction_market(monkeypatch: pytest.MonkeyPatch, activities: KineticActivities) -> None:
    # 1354-1367
    mock_settle = MagicMock()
    mock_state = MagicMock()
    mock_state.model_dump.return_value = {"settled": True}
    mock_settle.return_value = mock_state
    monkeypatch.setattr("coreason_runtime.orchestration.activities.settle_prediction_market", mock_settle)

    mock_cls = MagicMock()
    monkeypatch.setattr("coreason_runtime.orchestration.activities.PredictionMarketState", mock_cls)

    res = await activities.execute_settle_prediction_market_compute_activity({})
    assert res["settled"] is True


@pytest.mark.asyncio
async def test_execute_market_contract(monkeypatch: pytest.MonkeyPatch, activities: KineticActivities) -> None:
    # 1368-1384
    mock_contract = MagicMock()
    mock_contract.slashing_penalty = 100.0
    mock_cls = MagicMock()
    mock_cls.model_validate.return_value = mock_contract
    monkeypatch.setattr("coreason_runtime.orchestration.activities.MarketContract", mock_cls)

    res1 = await activities.execute_market_contract_compute_activity({}, success=True)
    assert res1["penalty_amount"] == 0

    res2 = await activities.execute_market_contract_compute_activity({}, success=False)
    assert res2["penalty_amount"] == 100.0


@pytest.mark.asyncio
async def test_mint_neural_audit_attestation(monkeypatch: pytest.MonkeyPatch, activities: KineticActivities) -> None:
    # 1385-1420+
    payload = {"target_layers": [1, 2], "max_features_per_layer": 2}

    mock_contract = MagicMock()
    mock_contract.target_layers = [1, 2]
    mock_contract.max_features_per_layer = 1
    mock_cls = MagicMock()
    mock_cls.model_validate.return_value = mock_contract
    monkeypatch.setattr("coreason_manifest.spec.ontology.MechanisticAuditContract", mock_cls)

    mock_receipt = MagicMock()
    mock_receipt.model_dump.return_value = {"attestation": "minted"}

    mock_rc_cls = MagicMock(return_value=mock_receipt)
    monkeypatch.setattr("coreason_manifest.spec.ontology.NeuralAuditAttestationReceipt", mock_rc_cls)
    monkeypatch.setattr("coreason_manifest.spec.ontology.SaeFeatureActivationState", MagicMock())

    activations = {
        "layer_1": [{"feature_index": "100", "magnitude": "5.5"}, {"feature_index": "101", "magnitude": "1.0"}]
    }

    res = await activities.mint_neural_audit_attestation_compute_activity(payload, layer_activations_raw=activations)
    assert res["attestation"] == "minted"


@pytest.mark.asyncio
async def test_execute_market_settlement(monkeypatch: pytest.MonkeyPatch, activities: KineticActivities) -> None:
    # 1835-1898
    class BidMock:
        def __init__(self, agent_cid: str, ip: str, target: str) -> None:
            self.agent_cid = agent_cid
            self.implied_probability = ip
            self.target_hypothesis_cid = target

    mock_auction = MagicMock()
    mock_auction.order_book = [
        BidMock("agent_A", "0.8", "hyp_win"),
        BidMock("agent_B", "0.4", "hyp_lose"),
        BidMock("agent_C", "0.0", "hyp_lose"),  # Brier score handles sum = 0 checks safely
    ]
    mock_auction.market_cid = "market_1"

    mock_cls = MagicMock()
    mock_cls.model_validate.return_value = mock_auction
    monkeypatch.setattr("coreason_manifest.spec.ontology.PredictionMarketState", mock_cls)

    mock_resol = MagicMock()
    mock_resol.model_construct.return_value.model_dump.return_value = {"dumped": True}
    monkeypatch.setattr("coreason_manifest.spec.ontology.MarketResolutionState", mock_resol)

    # Normal execution finding payouts
    res = await execute_market_settlement_io_activity({}, "hyp_win")
    assert res["settlement_status"] == "cleared"
    assert "brier_scores" in res
    assert "agent_A" in res["brier_scores"]

    # Exception execution
    mock_cls.model_validate.side_effect = Exception("failed validate")
    res_err = await execute_market_settlement_io_activity({}, "hyp_win")
    assert res_err["status"] == "failed"


@pytest.mark.asyncio
async def test_shapley_attribution() -> None:
    # 1900-1994
    # Test Exact Path: len <= 10
    agent_cids = ["did:agent:agent_a", "did:agent:agent_b", "did:agent:agent_c"]
    res1 = await execute_shapley_attribution_compute_activity("100.0", agent_cids)
    assert len(res1) == 3
    assert res1[0]["target_node_cid"] == "did:agent:agent_a"

    # Test Monte Carlo Path: len > 10
    agent_cids_large = [f"did:agent:node_{i}" for i in range(12)]
    res2 = await execute_shapley_attribution_compute_activity("100.0", agent_cids_large)
    assert len(res2) == 12

    # Characteristic Value Override Path
    res3 = await execute_shapley_attribution_compute_activity("100.0", ["did:agent:node_x"], {"did:agent:node_x": 50.0})
    assert len(res3) == 1

    # Empty agent path
    res4 = await execute_shapley_attribution_compute_activity("100.0", [])
    assert res4 == []

    # Zero Sum Fallback Path natively enforcing lines 1976-1978 egalitarian fallback natively cleanly
    res_zero = await execute_shapley_attribution_compute_activity("0.0", ["did:agent:node_x", "did:agent:node_y"])
    assert len(res_zero) == 2


@pytest.mark.asyncio
async def test_calculate_collective_intelligence() -> None:
    res1 = await execute_collective_intelligence_activity(100.0, 5)
    assert res1["synergy_index"] == 1.15
    res2 = await execute_collective_intelligence_activity(100.0, 1)
    assert res2["synergy_index"] == 1.0
