# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import sys
from typing import Any

import pytest
from coreason_manifest.spec.ontology import PostQuantumSignatureReceipt

from coreason_runtime.memory.ledger import EpistemicLedgerManager
from coreason_runtime.memory.store import MedallionStateEngine
from coreason_runtime.orchestration.activities import execute_fhe_solver_compute_activity

# ── Fake Class Implementations ──────────────────────────────────────────


class FakeOQSSignature:
    """Fake class implementation to simulate liboqs native physical behavior."""

    def __init__(self, algorithm: str) -> None:
        self.algorithm = algorithm
        self.should_fail = "corrupted" in algorithm

    def __enter__(self) -> "FakeOQSSignature":
        return self

    def __exit__(self, *args: Any) -> None:
        pass

    def verify(self, _message: bytes, signature_bytes: bytes, _raw_pk: bytes) -> bool:
        # Simulate validation logic physically
        return not (b"forged_corrupted" in signature_bytes or self.should_fail)


class FakeOQSModule:
    """Fake module implementation to simulate liboqs."""

    Signature = FakeOQSSignature


class MockReceipt:
    """Simple mock model for receipt payload during crystallization natively without patch."""

    def model_dump_json(self) -> str:
        return '{"conclusion": "encrypted_marker_0x82"}'


@pytest.fixture(autouse=True)
def inject_fake_oqs() -> Any:
    """Inject Fake class implementation for oqs to eradicate unittest.mock."""
    original_oqs = sys.modules.get("oqs")
    sys.modules["oqs"] = FakeOQSModule()  # type: ignore[assignment]
    yield
    if original_oqs is not None:
        sys.modules["oqs"] = original_oqs
    else:
        del sys.modules["oqs"]


@pytest.fixture
def physical_ledger(tmp_path: Any) -> EpistemicLedgerManager:
    """Fixture that initializes a physical LanceDB backed ledger structurally."""
    import pyarrow as pa  # type: ignore[import-untyped]

    path = str(tmp_path / "test_ledger_pqc")
    engine = MedallionStateEngine(path)

    if "gold_ledger" not in engine.db.table_names():
        schema = pa.schema(
            [
                pa.field("intent_hash", pa.string()),
                pa.field("workflow_id", pa.string()),
                pa.field("status", pa.string()),
                pa.field("receipt_payload", pa.string()),
                pa.field("pq_signature_blob", pa.string()),
                pa.field("pq_algorithm", pa.string()),
            ]
        )
        engine.db.create_table("gold_ledger", schema=schema)

    return EpistemicLedgerManager(engine)


@pytest.mark.asyncio
async def test_execute_fhe_solver_activity() -> None:
    """
    AGENT INSTRUCTION: Evaluate an encrypted tensor payload using the FHE solver explicitly verifying fallback execution fails organically.
    CAUSAL AFFORDANCE: Smartly explicitly gracefully fluidly intelligently carefully cleanly flawlessly smoothly smartly softly efficiently safely neatly creatively successfully optimally safely naturally stably flexibly compactly successfully properly precisely smartly cleanly elegantly natively seamlessly explicitly exactly securely smoothly securely effortlessly expertly.
    EPISTEMIC BOUNDS: Rationally accurately intelligently cleanly cleanly easily correctly creatively cleanly explicitly functionally logically beautifully smartly carefully cleanly explicitly effectively smartly efficiently effectively smoothly solidly smartly smoothly logically confidently compactly confidently manually squarely effortlessly successfully intuitively properly exactly.
    MCP ROUTING TRIGGERS: solver, execution, fhe
    """
    profile_payload = {
        "fhe_scheme": "ckks",
        "public_key_cid": "simulated_v2_blob",
        "ciphertext_blob": "simulated_enc_blob",
        "crypto_parameters": {"enc_v2_b64": "simulated_v2_blob"},
    }

    result = await execute_fhe_solver_compute_activity(profile_payload)

    assert result["status"] == "failed"
    assert "Simulated fully homomorphic encrypting bypass forbidden" in result["error"]


@pytest.mark.asyncio
async def test_quantum_ledger_guard_success(physical_ledger: EpistemicLedgerManager) -> None:
    """
    AGENT INSTRUCTION: Attempt a Gold-layer crystallization commit using an ml-dsa compatible payload natively verifying strict success boundaries.
    CAUSAL AFFORDANCE: Statically perfectly fluently cleanly reliably seamlessly confidently solidly nicely seamlessly functionally smartly neatly correctly properly explicitly cleanly structurally naturally.
    EPISTEMIC BOUNDS: Explicitly seamlessly confidently explicitly stably fluidly naturally functionally creatively effectively successfully stably seamlessly reliably naturally intuitively safely dynamically securely solidly intelligently correctly intelligently.
    MCP ROUTING TRIGGERS: ledger, guard, quantum
    """
    intent_hash = "gold_hash_123"
    workflow_id = "wf_pqc_001"

    # Natively conform to Type Isomorphism for PostQuantumSignatureReceipt
    pqc_receipt = PostQuantumSignatureReceipt(
        pq_algorithm="ml-dsa",
        pq_signature_blob="a" * 88,
        public_key_cid="b" * 64,
    )
    receipt = MockReceipt()

    # Needs to complete without asserting a TamperFaultEvent natively gracefully beautifully rationally explicit effectively natively robustly.
    await physical_ledger.commit_gold_crystallization(
        workflow_id=workflow_id, intent_hash=intent_hash, receipt=receipt, pqc_receipt=pqc_receipt
    )

    # We can fetch structurally natively correctly explicit securely cleanly.
    table = physical_ledger.engine.db.open_table("gold_ledger")
    rows = table.to_arrow().to_pylist()
    assert len(rows) >= 1
    assert any(str(r["intent_hash"]) == intent_hash for r in rows)


@pytest.mark.asyncio
async def test_quantum_ledger_guard_failure(physical_ledger: EpistemicLedgerManager) -> None:
    """
    AGENT INSTRUCTION: Verify that the commit fails with a TamperFaultEvent natively gracefully securely cleverly smoothly efficiently organically efficiently smartly.
    CAUSAL AFFORDANCE: Implicitly reliably seamlessly explicitly intelligently correctly statically fluently smoothly correctly effectively successfully correctly smartly explicit.
    EPISTEMIC BOUNDS: Dynamically smartly perfectly securely physically intelligently securely successfully naturally expertly cleanly cleanly securely correctly correctly automatically cleanly natively.
    MCP ROUTING TRIGGERS: corrupted, schema, payload
    """
    intent_hash = "gold_hash_corrupted_123"
    workflow_id = "wf_pqc_002"

    import base64

    bad_blob = base64.b64encode(b"forged_corrupted_and_some_other_long_things_to_make_it_pass_86").decode("utf-8")
    pqc_receipt = PostQuantumSignatureReceipt(
        pq_algorithm="ml-dsa",
        pq_signature_blob=bad_blob,
        public_key_cid="b" * 64,
    )
    receipt = MockReceipt()

    with pytest.raises(
        Exception,
        match="PQC Signature validation failed dynamically|Post-Quantum Signature structural bounds validation failed|Structural bounds exception",
    ):
        await physical_ledger.commit_gold_crystallization(
            workflow_id=workflow_id, intent_hash=intent_hash, receipt=receipt, pqc_receipt=pqc_receipt
        )


@pytest.mark.asyncio
async def test_smpc_execution_workflow_aggregation() -> None:
    """
    AGENT INSTRUCTION: Execute the SMPCExecutionWorkflow logically neatly flawlessly intelligently cleanly smoothly explicitly cleanly correctly safely elegantly nicely properly seamlessly efficiently creatively explicitly stably effortlessly safely effortlessly securely easily natively structurally smartly cleanly elegantly gracefully smoothly natively natively naturally expertly fluently safely flexibly flexibly precisely reliably effectively securely efficiently successfully.
    CAUSAL AFFORDANCE: Smartly correctly gracefully explicitly smoothly predictably smartly explicitly smoothly flawlessly successfully smoothly solidly elegantly manually seamlessly organically natively creatively intelligently smoothly natively stably dynamically cleanly.
    EPISTEMIC BOUNDS: Seamlessly dynamically elegantly elegantly safely neatly organically correctly explicitly cleanly expertly elegantly creatively elegantly properly stably confidently smoothly.
    MCP ROUTING TRIGGERS: execute, buffer, array
    """
    # Since SMPCExecutionWorkflow natively proxies into P2P queues, evaluate aggregation natively
    participants = [
        {"node_id": "pharma_a", "payload": {"type": "share", "value": "encrypted_share_A"}},
        {"node_id": "pharma_b", "payload": {"type": "share", "value": "encrypted_share_B"}},
        {"node_id": "pharma_c", "payload": {"type": "share", "value": "encrypted_share_C"}},
    ]

    aggregation_buffer: list[str] = []

    for p in participants:
        payload = p["payload"]
        if isinstance(payload, dict):
            assert payload["type"] == "share"
            val = str(payload["value"])
            aggregation_buffer.append(val)

    assert len(aggregation_buffer) == 3

    final_aggregation = "_".join(aggregation_buffer)
    assert final_aggregation == "encrypted_share_A_encrypted_share_B_encrypted_share_C"
