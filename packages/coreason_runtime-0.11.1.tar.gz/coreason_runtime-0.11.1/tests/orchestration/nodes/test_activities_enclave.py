import sys
from unittest.mock import MagicMock

import pytest

from coreason_runtime.orchestration.activities import (
    execute_fhe_solver_compute_activity,
    execute_gaze_tracking_io_activity,
    execute_verify_hardware_enclave_activity,
    execute_verify_wetware_attestation_activity,
)


@pytest.mark.asyncio
async def test_wetware_attestation(monkeypatch: pytest.MonkeyPatch) -> None:
    mock_fido = MagicMock()
    monkeypatch.setattr("coreason_runtime.orchestration.activities.Fido2Verifier", MagicMock(return_value=mock_fido))

    mock_resolve = MagicMock(return_value=b"key")
    monkeypatch.setattr("coreason_runtime.utils.security.resolve_did_public_key", mock_resolve)

    res = await execute_verify_wetware_attestation_activity(
        {"cryptographic_payload": "sig", "did_subject": "did:human:1", "liveness_challenge_hash": "hash1"}
    )

    assert res["verification_status"] == "verified"


@pytest.mark.asyncio
async def test_gaze_tracking(monkeypatch: pytest.MonkeyPatch) -> None:
    # Invalid vector size
    try:
        await execute_gaze_tracking_io_activity({"direction_unit_vector": [1.0, 0.0]})
        pytest.fail("Should have raised ValueError")
    except ValueError as e:
        assert "vector size" in str(e)  # noqa: PT017

    # Valid vector size but Signature invalid
    monkeypatch.setattr("coreason_runtime.orchestration.activities.validate_normalized_vector", MagicMock())
    monkeypatch.setattr("coreason_runtime.utils.security.verify_pq_signature", MagicMock(return_value=False))

    try:
        await execute_gaze_tracking_io_activity({"direction_unit_vector": [1.0, 0.0, 0.0], "signature": "sig"})
        pytest.fail("Should have raised ValueError")
    except ValueError as e:
        assert "invalidated" in str(e)  # noqa: PT017

    # Valid Signature
    monkeypatch.setattr("coreason_runtime.utils.security.verify_pq_signature", MagicMock(return_value=True))
    monkeypatch.setattr(
        "coreason_runtime.orchestration.activities.intersect_ray_with_nodes", MagicMock(return_value=["node1"])
    )

    res = await execute_gaze_tracking_io_activity(
        {
            "direction_unit_vector": [1.0, 0.0, 0.0],
            "signature": "sig",
            "origin": [0.0, 0.0, 0.0],
            "active_bounding_boxes": [],
        }
    )

    assert res["trusted_hardware"] is True
    assert res["intersected_node_cids"] == ["node1"]


@pytest.mark.asyncio
async def test_hardware_enclave_attestation(monkeypatch: pytest.MonkeyPatch) -> None:
    mock_tee = MagicMock()
    monkeypatch.setattr("coreason_runtime.orchestration.activities.TEEVerifier", MagicMock(return_value=mock_tee))

    res = await execute_verify_hardware_enclave_activity(
        {"hardware_signature_blob": "blob", "enclave_class": "aws_nitro", "platform_measurement_hash": "pcr"}
    )
    assert res["isolation_status"] == "enclave_sealed"


@pytest.mark.asyncio
async def test_fhe_solver_no_tenseal_and_tenseal(monkeypatch: pytest.MonkeyPatch) -> None:
    # 1. No TenSEAL (simulated locally because it's not installed, which raises RuntimeError caught organically)
    res = await execute_fhe_solver_compute_activity(
        {"public_key_cid": "cid1", "fhe_scheme": "ckks", "ciphertext_blob": "YmxvYjEK"}
    )
    assert res["status"] == "failed"
    assert (
        "TenSEAL" in res["error"]
        or "missing" in res["error"].lower()
        or "missing" in res["error"]
        or "base64" in res["error"]
    )

    # 2. Mock TenSEAL to test operations natively
    mock_ts = MagicMock()
    mock_ts.SCHEME_TYPE.CKKS = "ckks"
    mock_ctx = MagicMock()
    mock_ts.context_from.return_value = mock_ctx
    mock_ts.context.return_value = mock_ctx

    vec1 = MagicMock()
    vec2 = MagicMock()
    mock_ts.ckks_vector_from.side_effect = [vec1, vec2]

    vec1.dot.return_value.serialize.return_value = b"dotres"
    vec1.__add__.return_value.serialize.return_value = b"add_res"
    diff_mock = MagicMock()
    diff_mock.dot.return_value.serialize.return_value = b"distres"
    vec1.__sub__.return_value = diff_mock

    monkeypatch.setitem(sys.modules, "tenseal", mock_ts)

    # Missing ciphertext blob
    try:
        await execute_fhe_solver_compute_activity({"public_key_cid": "c1", "fhe_scheme": "ckks"})
    except ValueError as e:
        assert "ciphertext_blob" in str(e)  # noqa: PT017

    # Operation: dot_product
    res_dot = await execute_fhe_solver_compute_activity(
        {
            "public_key_cid": "c1",
            "fhe_scheme": "ckks",
            "ciphertext_blob": "YmxvYjE=",
            "crypto_parameters": {"enc_v2_b64": "YmxvYjI="},
            "operation": "dot_product",
        }
    )
    assert res_dot.get("status") != "failed"

    # Operation: add
    mock_ts.ckks_vector_from.side_effect = [vec1, vec2]
    res_add = await execute_fhe_solver_compute_activity(
        {
            "public_key_cid": "c1",
            "fhe_scheme": "ckks",
            "ciphertext_blob": "YmxvYjE=",
            "crypto_parameters": {"enc_v2_b64": "YmxvYjI="},
            "operation": "add",
        }
    )
    assert res_add.get("status") != "failed"

    # Operation: distance
    mock_ts.ckks_vector_from.side_effect = [vec1, vec2]
    res_dist = await execute_fhe_solver_compute_activity(
        {
            "public_key_cid": "c1",
            "fhe_scheme": "ckks",
            "ciphertext_blob": "YmxvYjE=",
            "crypto_parameters": {"enc_v2_b64": "YmxvYjI="},
            "operation": "distance",
        }
    )
    assert res_dist.get("status") != "failed"

    # Context encoding check & invalid op
    mock_ts.ckks_vector_from.side_effect = [vec1, vec2]
    res_inv = await execute_fhe_solver_compute_activity(
        {
            "public_key_cid": "c1",
            "fhe_scheme": "ckks",
            "ciphertext_blob": "YmxvYjE=",
            "crypto_parameters": {"enc_v2_b64": "YmxvYjI=", "context_b64": "Y3R4"},
            "operation": "unknown",
        }
    )
    assert res_inv["status"] == "failed"
