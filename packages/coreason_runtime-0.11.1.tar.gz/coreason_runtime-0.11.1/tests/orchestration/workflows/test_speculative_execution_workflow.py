# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical tests for SpeculativeExecutionWorkflow.

Tests the speculative branch-forking, barge-in interrupt, and rollback
signal pathways using Temporal time-skipping environments.

All tests use physically instantiated manifest ontology models — zero unittest.mock.

NOTE: The SpeculativeExecutionWorkflow uses `asyncio.wait` with `asyncio.create_task`
which exercises the Temporal task selector. On Windows, the `asyncio.wait` selector
may flake due to proactor event loop differences. Tests that exercise the `asyncio.wait`
path are gated with `@pytest.mark.skipif(sys.platform == "win32", ...)`.
"""

import concurrent.futures
import sys
from datetime import timedelta
from typing import Any

import pytest
from temporalio import activity, workflow
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import Worker

with workflow.unsafe.imports_passed_through():
    # Defeat Temporal sandbox UserWarning by statically mapping loguru internals natively
    from coreason_manifest import (
        DAGTopologyManifest,
        ExecutionEnvelopeState,
        StateVectorProfile,
        TraceContextState,
    )

from coreason_runtime.orchestration.workflows.speculative_execution_workflow import SpeculativeExecutionWorkflow

# ── Stub Activities ──────────────────────────────────────────────────


@activity.defn(name="ExecuteTensorInferenceComputeActivity")
async def stub_tensor_activity(*args: Any) -> dict[str, Any]:
    """Stub agent inference returning a successful result."""
    return {"success": True, "outputs": {"result": "shadow_result"}, "intent_hash": "stub-hash", "usage": {}}


@activity.defn(name="StoreEpistemicStateIOActivity")
async def stub_store_activity(*args: Any) -> None:
    pass


@activity.defn(name="RecordTokenBurnIOActivity")
async def stub_burn_activity(*args: Any) -> None:
    pass


# ── Stub DAG Child Workflow ──────────────────────────────────────────


@workflow.defn(name="DAGExecutionWorkflow", sandboxed=False)
class StubDAGWorkflow:
    """Stub DAG workflow that returns immediately with success."""

    @workflow.run
    async def run(self, _payload: dict[str, Any]) -> dict[str, Any]:
        return {"status": "success", "results": [{"outputs": {"stub": True}}]}


@workflow.defn(name="DAGExecutionWorkflow", sandboxed=False)
class StubDAGWorkflowSlow:
    """Stub DAG workflow that waits 60 seconds (to be interrupted)."""

    @workflow.run
    async def run(self, _payload: dict[str, Any]) -> dict[str, Any]:
        # Sleep long enough to be interrupted by barge-in or rollback signals
        await workflow.sleep(timedelta(seconds=60))
        return {"status": "success", "results": []}


# ── Envelope Factory ─────────────────────────────────────────────────


def _build_speculative_envelope(
    commit_probability: float = 0.9,
    speculative_cid: str = "branch-alpha",
    rollback_pointers: list[str] | None = None,
) -> dict[str, Any]:
    """Build a minimal ExecutionEnvelopeState for the speculative workflow."""
    dag_manifest = DAGTopologyManifest(
        topology_class="dag",
        max_depth=10,
        max_fan_out=5,
        nodes={
            "did:coreason:node01": {  # type: ignore[dict-item]
                "topology_class": "agent",
                "description": "test description",
            },
        },
        edges=[],
    )

    envelope = ExecutionEnvelopeState(
        payload=dag_manifest.model_dump(mode="json"),
        state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}),
        trace_context=TraceContextState(
            trace_cid="01ARZ3NDEKTSV4RRFFQ69G5FAV",
            span_cid="01ARZ3NDEKTSV4RRFFQ69G5FAX",
            causal_clock=0,
        ),
    )

    # The speculative workflow reads from payload.payload for its policy
    dump = envelope.model_dump(mode="json")
    dump["payload"]["payload"] = {
        "speculative_cid": speculative_cid,
        "commit_probability": commit_probability,
        "rollback_pointers": rollback_pointers or [],
    }

    return dump


# ── Tests ────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_speculative_high_commit_merges() -> None:
    """High commit_probability (>= 0.8) merges the shadow branch, committed=True."""
    payload = _build_speculative_envelope(commit_probability=0.9)

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="spec-merge-queue",
            workflows=[SpeculativeExecutionWorkflow, StubDAGWorkflow],
            activities=[stub_tensor_activity, stub_store_activity, stub_burn_activity],
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
            debug_mode=sys.platform == "win32",
        ):
            result = await env.client.execute_workflow(
                SpeculativeExecutionWorkflow.run,
                payload,
                id="spec-merge-test",
                task_queue="spec-merge-queue",
            )

    assert result["status"] == "success"
    assert result["committed"] is True
    assert result["result"]["status"] == "success"


@pytest.mark.asyncio
async def test_speculative_low_commit_stays_isolated() -> None:
    """Low commit_probability (< 0.8) keeps the branch in shadow isolation."""
    payload = _build_speculative_envelope(commit_probability=0.2)

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="spec-isolate-queue",
            workflows=[SpeculativeExecutionWorkflow, StubDAGWorkflow],
            activities=[stub_tensor_activity, stub_store_activity, stub_burn_activity],
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
            debug_mode=sys.platform == "win32",
        ):
            result = await env.client.execute_workflow(
                SpeculativeExecutionWorkflow.run,
                payload,
                id="spec-isolate-test",
                task_queue="spec-isolate-queue",
            )

    assert result["status"] == "success"
    assert result["committed"] is False


@pytest.mark.asyncio
async def test_speculative_barge_in_halts_execution() -> None:
    """Barge-in signal halts the speculative branch mid-execution."""
    payload = _build_speculative_envelope(commit_probability=0.9)

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="spec-barge-queue",
            workflows=[SpeculativeExecutionWorkflow, StubDAGWorkflowSlow],
            activities=[stub_tensor_activity, stub_store_activity, stub_burn_activity],
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
            debug_mode=sys.platform == "win32",
        ):
            handle = await env.client.start_workflow(
                SpeculativeExecutionWorkflow.run,
                payload,
                id="spec-barge-test",
                task_queue="spec-barge-queue",
            )

            # Give the workflow time to start the child
            import asyncio

            await asyncio.sleep(0.5)

            # Send barge-in signal
            await handle.signal(
                SpeculativeExecutionWorkflow.receive_barge_in,
                {"target_event_cid": "evt-123", "reason": "user_abort"},
            )

            result = await handle.result()

    assert result["status"] == "barge_in_halted"
    assert result["event"]["reason"] == "user_abort"


@pytest.mark.asyncio
async def test_speculative_rollback_falsifies_branch() -> None:
    """Rollback intent signal falsifies the speculative branch and restores rewind anchors."""
    payload = _build_speculative_envelope(
        commit_probability=0.9,
        speculative_cid="branch-beta",
        rollback_pointers=["checkpoint-1", "checkpoint-2"],
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="spec-rollback-queue",
            workflows=[SpeculativeExecutionWorkflow, StubDAGWorkflowSlow],
            activities=[stub_tensor_activity, stub_store_activity, stub_burn_activity],
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
            debug_mode=sys.platform == "win32",
        ):
            handle = await env.client.start_workflow(
                SpeculativeExecutionWorkflow.run,
                payload,
                id="spec-rollback-test",
                task_queue="spec-rollback-queue",
            )

            import asyncio

            await asyncio.sleep(0.5)

            # Send rollback intent
            await handle.signal(
                SpeculativeExecutionWorkflow.receive_rollback_intent,
                {"cascade_cid": "cascade-1", "reason": "formal_verification_failed"},
            )

            result = await handle.result()

    assert result["status"] == "rolled_back"
    assert result["falsified_subgraph"] == "branch-beta"
    assert result["rewind_anchors"] == ["checkpoint-1", "checkpoint-2"]
    assert result["rollback_intent"]["reason"] == "formal_verification_failed"


@pytest.mark.asyncio
async def test_speculative_child_workflow_id_format() -> None:
    """Child workflow ID follows the shadow naming convention."""
    payload = _build_speculative_envelope(speculative_cid="test-cid-123")

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="spec-id-queue",
            workflows=[SpeculativeExecutionWorkflow, StubDAGWorkflow],
            activities=[stub_tensor_activity, stub_store_activity, stub_burn_activity],
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
            debug_mode=sys.platform == "win32",
        ):
            result = await env.client.execute_workflow(
                SpeculativeExecutionWorkflow.run,
                payload,
                id="spec-id-test",
                task_queue="spec-id-queue",
            )

    # The workflow completes successfully — child ID format is
    # f"{workflow_id}-shadow-{speculative_cid}" validated by Temporal
    assert result["status"] == "success"


@pytest.mark.asyncio
async def test_speculative_workflow_cancellation() -> None:
    """Test standard asyncio.CancelledError paths."""
    payload = _build_speculative_envelope(speculative_cid="test-cancel-cid")
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="spec-can-queue",
            workflows=[SpeculativeExecutionWorkflow, StubDAGWorkflow],
            activities=[stub_tensor_activity, stub_store_activity, stub_burn_activity],
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
            debug_mode=sys.platform == "win32",
        ):
            handle = await env.client.start_workflow(
                SpeculativeExecutionWorkflow.run,
                payload,
                id="spec-can-test",
                task_queue="spec-can-queue",
            )
            import asyncio

            await asyncio.sleep(0.5)
            await handle.cancel()
            from temporalio.client import WorkflowFailureError

            with pytest.raises(WorkflowFailureError) as exc_info:
                await handle.result()
            assert hasattr(exc_info.value, "cause")
            assert "CancelledError" in str(type(exc_info.value.cause))
            await asyncio.sleep(0.5)
