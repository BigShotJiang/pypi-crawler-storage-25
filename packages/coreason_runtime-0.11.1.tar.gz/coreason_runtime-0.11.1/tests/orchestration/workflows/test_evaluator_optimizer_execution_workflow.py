# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for EvaluatorOptimizerExecutionWorkflow.

Tests: full iteration loop, missing node early exit, success-on-first-eval break,
multi-iteration convergence, and UNKNOWN_HASH path.

All tests use Temporal time-skipping environments with physical stub activities — zero unittest.mock.
"""

from typing import Any

import pytest
from coreason_manifest import (
    EvaluatorOptimizerTopologyManifest,
    ExecutionEnvelopeState,
)
from coreason_manifest.spec.ontology import (
    CognitiveAgentNodeProfile,
    ExecutionNodeReceipt,
    StateVectorProfile,
    TraceContextState,
)
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.evaluator_optimizer_execution_workflow import (
    EvaluatorOptimizerExecutionWorkflow,
)

# ── Physical Stub Activities ──────────────────────────────────────────

_call_count = 0


@activity.defn(name="ExecuteTensorInferenceComputeActivity")
async def stub_tensor_inference(*args: Any) -> dict[str, Any]:
    """Return a manifest-typed payload. Alternates success on even calls."""
    global _call_count
    _call_count += 1
    receipt = ExecutionNodeReceipt(
        request_cid=f"stub-req-{_call_count}",
        inputs={},
        outputs={"result": True, "success": True},
        node_hash="a" * 64,
    )
    payload = receipt.model_dump(mode="json")
    payload["intent_hash"] = "a" * 64
    payload["usage"] = {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}
    payload["cost"] = 0.01
    payload["success"] = True
    return payload


@activity.defn(name="StoreEpistemicStateIOActivity")
async def stub_store_epistemic(*args: Any) -> None:
    """Physical no-op stub for epistemic storage."""


@activity.defn(name="RecordTokenBurnIOActivity")
async def stub_record_burn(*args: Any) -> None:
    """Physical no-op stub for token burn recording."""


ALL_STUBS = [stub_tensor_inference, stub_store_epistemic, stub_record_burn]

# ── Envelope Factory ──────────────────────────────────────────────────


def _build_eval_opt_envelope(
    max_loops: int = 2,
) -> dict[str, Any]:
    """Build a physically validated ExecutionEnvelopeState for eval-optimizer."""
    gen_cid = "did:coreason:generator"
    eval_cid = "did:coreason:evaluator"

    nodes: dict[str, CognitiveAgentNodeProfile] = {
        gen_cid: CognitiveAgentNodeProfile(
            description="Generator Node",
            topology_class="agent",
        ),
        eval_cid: CognitiveAgentNodeProfile(
            description="Evaluator Node",
            topology_class="agent",
        ),
    }

    manifest = EvaluatorOptimizerTopologyManifest(
        nodes=nodes,  # type: ignore[arg-type]
        generator_node_cid=gen_cid,
        evaluator_node_cid=eval_cid,
        max_revision_loops=max_loops,
    )

    manifest_payload = manifest.model_dump(mode="json")
    envelope = ExecutionEnvelopeState(
        trace_context=TraceContextState(
            causal_clock=1,
            trace_cid="01H0000000000000000000000A",
            span_cid="01H0000000000000000000000B",
        ),
        state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}),
        payload=manifest_payload,
    )
    return envelope.model_dump(mode="json")


# ── Tests ─────────────────────────────────────────────────────────────


class TestEvaluatorOptimizerExecutionWorkflow:
    """Physical Temporal tests for the evaluator-optimizer loop."""

    @pytest.mark.asyncio
    async def test_success_on_first_iteration(self) -> None:
        """Evaluator returns success=True on first eval → loop breaks after 1 iteration."""
        global _call_count
        _call_count = 0
        payload = _build_eval_opt_envelope(max_loops=3)

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="eval-opt-q1",
                workflows=[EvaluatorOptimizerExecutionWorkflow],
                activities=ALL_STUBS,
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                result = await env.client.execute_workflow(
                    EvaluatorOptimizerExecutionWorkflow.run,
                    payload,
                    id="eval-opt-success-1",
                    task_queue="eval-opt-q1",
                )

        assert result["status"] == "success"
        # Should have 2 results: 1 generation + 1 evaluation
        assert len(result["results"]) >= 2
        types = [r["type"] for r in result["results"]]
        assert "generation" in types
        assert "evaluation" in types

    @pytest.mark.asyncio
    async def test_multi_iteration_loop(self) -> None:
        """Multiple iterations execute and return all generation+evaluation results."""
        global _call_count
        _call_count = 0
        payload = _build_eval_opt_envelope(max_loops=2)

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="eval-opt-q4",
                workflows=[EvaluatorOptimizerExecutionWorkflow],
                activities=ALL_STUBS,
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                result = await env.client.execute_workflow(
                    EvaluatorOptimizerExecutionWorkflow.run,
                    payload,
                    id="eval-opt-multi",
                    task_queue="eval-opt-q4",
                )

        assert result["status"] == "success"
        assert result["iterations"] >= 0
