# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any
from unittest.mock import AsyncMock, patch

import pytest
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import Worker

from coreason_runtime.orchestration.workflows.epistemic_pruning_workflow import (
    EpistemicPruningWorkflow,
    evaluate_and_decay_salience_activity,
)


@pytest.mark.asyncio
async def test_epistemic_pruning_evaluates_correct_protected_bounds() -> None:
    """Verifies that mathematical decay ignores perfectly matched protected CIDs natively."""
    async with await WorkflowEnvironment.start_time_skipping() as env:
        with (
            patch(
                "coreason_runtime.memory.latent.LatentMemoryManager.prune_stale_vectors", new_callable=AsyncMock
            ) as mocked_prune,
            patch("coreason_runtime.orchestration.workflows.epistemic_pruning_workflow.MedallionStateEngine"),
        ):
            mocked_prune.return_value = 50

            async with Worker(
                env.client,
                task_queue="epistemic-pruning-tasks",
                workflows=[EpistemicPruningWorkflow],
                activities=[evaluate_and_decay_salience_activity],
            ):
                from coreason_runtime.orchestration.workflows.epistemic_pruning_workflow import (
                    EpistemicPruningPayloadDict,
                )

                payload: EpistemicPruningPayloadDict = {
                    "eviction_policy": {
                        "strategy": "salience_decay",
                        "max_retained_tokens": 5000,
                        "protected_event_cids": ["cid-alpha-99", "cid-beta-77"],
                    },
                    "salience": {"baseline_importance": 1.0, "decay_rate": 0.05},
                }

                result = await env.client.execute_workflow(
                    EpistemicPruningWorkflow.run,
                    payload,
                    id="epistemic-pruning-run-001",
                    task_queue="epistemic-pruning-tasks",
                )

                assert result["status"] == "epistemic_pruning_complete"
                assert result["purged_vector_count"] == 50
                assert result["pruned_dimensions"] == 50 * 1536

                # Verify exactly parsed payload parameters into target functions
                mocked_prune.assert_called_once_with(0.05, 0.5, ["cid-alpha-99", "cid-beta-77"])


import asyncio
from datetime import timedelta

from temporalio import activity
from temporalio.client import WorkflowFailureError


@activity.defn(name="evaluate_and_decay_salience_activity")
async def chaos_timeout_activity(payload: dict[str, Any]) -> dict[str, Any]:
    raise asyncio.TimeoutError("Simulated Chaos Engineering network partition.")


@pytest.mark.asyncio
async def test_epistemic_pruning_chaos_timeout_injection() -> None:
    """Verifies that an asyncio.TimeoutError during activity execution propagates as a WorkflowFailureError."""
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="epistemic-pruning-tasks",
            workflows=[EpistemicPruningWorkflow],
            activities=[chaos_timeout_activity],
        ):
            from coreason_runtime.orchestration.workflows.epistemic_pruning_workflow import EpistemicPruningPayloadDict

            payload: EpistemicPruningPayloadDict = {
                "eviction_policy": {
                    "strategy": "salience_decay",
                    "max_retained_tokens": 5000,
                    "protected_event_cids": [],
                },
                "salience": {"baseline_importance": 1.0, "decay_rate": 0.05},
            }

            with pytest.raises(WorkflowFailureError) as exc_info:
                await env.client.execute_workflow(
                    EpistemicPruningWorkflow.run,
                    payload,
                    id="epistemic-pruning-chaos-run",
                    task_queue="epistemic-pruning-tasks",
                    execution_timeout=timedelta(seconds=1),
                    task_timeout=timedelta(seconds=1),
                )

            assert "Timeout" in str(exc_info.value.cause.cause) or "Timeout" in str(exc_info.value.cause)  # type: ignore[attr-defined]


@pytest.mark.asyncio
async def test_epistemic_pruning_evaluates_empty_payload() -> None:
    """Verifies that an empty payload leverages the internal default instantiation limits."""

    @activity.defn(name="evaluate_and_decay_salience_activity")
    async def mock_evaluate_activity(payload: dict[str, Any]) -> int:
        # Validate that the defaults were natively injected inside the workflow bounds
        assert "eviction_policy" in payload
        assert "salience" in payload
        assert payload["eviction_policy"]["strategy"] == "salience_decay"
        assert payload["salience"]["baseline_importance"] == 1.0
        return 10

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="epistemic-pruning-empty",
            workflows=[EpistemicPruningWorkflow],
            activities=[mock_evaluate_activity],
        ):
            from coreason_runtime.orchestration.workflows.epistemic_pruning_workflow import (
                EpistemicPruningPayloadDict,
            )

            payload: EpistemicPruningPayloadDict = {}

            result = await env.client.execute_workflow(
                EpistemicPruningWorkflow.run,
                payload,
                id="epistemic-pruning-run-empty",
                task_queue="epistemic-pruning-empty",
            )

            assert result["status"] == "epistemic_pruning_complete"
            assert result["purged_vector_count"] == 10
            assert result["pruned_dimensions"] == 10 * 1536
