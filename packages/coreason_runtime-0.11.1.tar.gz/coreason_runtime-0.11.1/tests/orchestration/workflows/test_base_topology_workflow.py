# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Tests for BaseTopologyWorkflow: state management, governance, LBAC, and signal handlers.

These tests exercise the pure-function methods of the base workflow class directly,
without Temporal. Signal handlers and activity-dispatching methods are tested via
physical Temporal time-skipping environments.

Zero unittest.mock. Zero respx. All payloads instantiated via manifest Type Isomorphism.
"""

from typing import Any

import pytest
from coreason_manifest import ExecutionEnvelopeState, StateVectorProfile, TraceContextState

from coreason_runtime.orchestration.workflows.base_topology_workflow import BaseTopologyWorkflow

# ── Fixtures ───────────────────────────────────────────────────────


def _build_envelope() -> ExecutionEnvelopeState[dict[str, Any]]:
    """Build a minimal ExecutionEnvelopeState for testing."""
    import uuid

    trace_id = str(uuid.uuid7())  # pyre-ignore[16]
    span_id = str(uuid.uuid7())  # pyre-ignore[16]
    return ExecutionEnvelopeState(
        trace_context=TraceContextState(
            trace_cid=trace_id,
            span_cid=span_id,
            causal_clock=0,
        ),
        state_vector=StateVectorProfile(
            immutable_matrix={"tenant_cid": "test-tenant", "session_cid": "test-session"},
            mutable_matrix={"accumulated_tokens": 0, "accumulated_cost": 0.0},
            is_delta=False,
        ),
        payload={"type": "dag", "nodes": {}},
    )


# ── Init Tests ─────────────────────────────────────────────────────


class TestBaseTopologyInit:
    """Verify default initialization state."""

    def test_default_init(self) -> None:
        wf = BaseTopologyWorkflow()
        assert wf._current_state_envelope is None
        assert wf._pending_oracle_override is None
        assert wf._current_oracle_resolution is None
        assert wf._accumulated_tokens == 0
        assert wf._accumulated_cost == 0.0
        assert wf._is_interrupted is False
        assert wf._interrupt_disposition is None
        assert wf._interrupt_event is None


# ── State Reconciliation Tests ─────────────────────────────────────


class TestReconcileState:
    """Exercise the CRDT-style reconcile_state method."""

    def test_reconcile_updates_mutable_matrix(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._current_state_envelope = _build_envelope()

        wf.reconcile_state({"new_key": "new_value"})

        matrix = wf._current_state_envelope.state_vector.mutable_matrix
        assert matrix["new_key"] == "new_value"  # type: ignore[index]
        # Original keys preserved
        assert matrix["accumulated_tokens"] == 0  # type: ignore[index]

    def test_reconcile_increments_causal_clock(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._current_state_envelope = _build_envelope()
        assert wf._current_state_envelope.trace_context.causal_clock == 0

        wf.reconcile_state({"delta": True})
        assert wf._current_state_envelope.trace_context.causal_clock == 1

        wf.reconcile_state({"delta_2": True})
        assert wf._current_state_envelope.trace_context.causal_clock == 2

    def test_reconcile_immutable_key_raises(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._current_state_envelope = _build_envelope()

        with pytest.raises(ValueError, match="read-only context key"):
            wf.reconcile_state({"tenant_cid": "evil_override"})

    def test_reconcile_no_envelope_raises(self) -> None:
        wf = BaseTopologyWorkflow()
        with pytest.raises(ValueError, match="No current state envelope"):
            wf.reconcile_state({"key": "value"})


# ── Governance Enforcement Tests ───────────────────────────────────


class TestEnforceGovernanceLimits:
    """Exercise the economic constraint enforcement."""

    def test_no_governance_is_noop(self) -> None:
        wf = BaseTopologyWorkflow()
        wf.enforce_governance_limits(None, None)  # Should not raise

    def test_token_budget_breach(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._accumulated_tokens = 5000
        governance = {"max_global_tokens": 4000}

        with pytest.raises(ValueError, match="Global token budget breached"):
            wf.enforce_governance_limits(governance, None)

    def test_token_budget_within_limits(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._accumulated_tokens = 3000
        governance = {"max_global_tokens": 4000}
        wf.enforce_governance_limits(governance, None)  # Should not raise

    def test_cost_budget_breach(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._accumulated_cost = 50.0
        governance = {"max_budget_magnitude": 25.0}

        with pytest.raises(ValueError, match="Global budget magnitude breached"):
            wf.enforce_governance_limits(governance, None)

    def test_cost_budget_within_limits(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._accumulated_cost = 10.0
        governance = {"max_budget_magnitude": 25.0}
        wf.enforce_governance_limits(governance, None)  # Should not raise


# ── LBAC Clearance Tests ──────────────────────────────────────────


class TestEnforceLBACClearance:
    """Exercise the Lattice-Based Access Control clearance hierarchy."""

    def test_public_tool_allowed_by_public_clearance(self) -> None:
        wf = BaseTopologyWorkflow()
        wf.enforce_lbac_clearance(["public"], tool_classification="public")

    def test_confidential_tool_blocked_by_public_clearance(self) -> None:
        wf = BaseTopologyWorkflow()
        with pytest.raises(PermissionError, match="LBAC clearance breached"):
            wf.enforce_lbac_clearance(["public"], tool_classification="confidential")

    def test_restricted_tool_allowed_by_restricted_clearance(self) -> None:
        wf = BaseTopologyWorkflow()
        wf.enforce_lbac_clearance(["restricted"], tool_classification="restricted")

    def test_internal_tool_allowed_by_confidential_clearance(self) -> None:
        wf = BaseTopologyWorkflow()
        wf.enforce_lbac_clearance(["confidential"], tool_classification="internal")

    def test_no_classifications_defaults_to_max_clearance(self) -> None:
        wf = BaseTopologyWorkflow()
        # None allowed_classifications defaults max_allowed to 3 (restricted)
        wf.enforce_lbac_clearance(None, tool_classification="restricted")

    def test_no_tool_classification_defaults_to_restricted(self) -> None:
        wf = BaseTopologyWorkflow()
        # tool_classification=None defaults to "restricted", allowed only if max is restricted
        wf.enforce_lbac_clearance(["restricted"], tool_classification=None)

    def test_internal_tool_blocked_by_public_only(self) -> None:
        wf = BaseTopologyWorkflow()
        with pytest.raises(PermissionError, match="LBAC clearance breached"):
            wf.enforce_lbac_clearance(["public"], tool_classification="internal")

    def test_highest_of_multiple_classifications_wins(self) -> None:
        wf = BaseTopologyWorkflow()
        # ["public", "confidential"] → max is confidential (2), so "confidential" tool passes
        wf.enforce_lbac_clearance(["public", "confidential"], tool_classification="confidential")

        # But "restricted" (3) should still fail
        with pytest.raises(PermissionError, match="LBAC clearance breached"):
            wf.enforce_lbac_clearance(["public", "confidential"], tool_classification="restricted")


# ── Query Tests ────────────────────────────────────────────────────


class TestGetCurrentState:
    """Test the query handler for current state."""

    def test_no_envelope_returns_empty_dict(self) -> None:
        wf = BaseTopologyWorkflow()
        assert wf.get_current_state() == {}

    def test_with_envelope_returns_serialized(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._current_state_envelope = _build_envelope()
        state = wf.get_current_state()
        assert "trace_context" in state
        assert "state_vector" in state
        assert "payload" in state
        assert state["trace_context"]["trace_cid"] is not None
        assert len(state["trace_context"]["trace_cid"]) >= 26


# Note: Signal handlers (receive_oracle_override, barge_in_interrupt, inject_oracle_resolution)
# and methods using workflow.logger (intercept_kinematic_intent, emit_mcp_ui_intent) require
# running inside a Temporal workflow context. They are tested via the DAG/speculative
# execution workflow integration tests with WorkflowEnvironment.start_time_skipping().

import concurrent.futures

from temporalio import activity, workflow
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker


@activity.defn(name="StoreEpistemicStateIOActivity")
async def stub_store_activity_topology(*args: Any) -> None:
    pass


@workflow.defn
class StubBaseTopologyWorkflow(BaseTopologyWorkflow):
    @workflow.run
    async def run(self, _payload: dict[str, Any]) -> dict[str, Any]:
        self._current_state_envelope = _build_envelope()
        await workflow.wait_condition(lambda: self._is_interrupted)
        from datetime import timedelta

        await workflow.sleep(timedelta(milliseconds=500))
        await workflow.wait_condition(lambda: workflow.all_handlers_finished())
        return {"status": "success"}


@pytest.mark.asyncio
async def test_base_topology_signals_natively() -> None:
    """Test BaseTopologyWorkflow signal logic mapped dynamically directly."""
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="base-signals-queue",
            workflows=[StubBaseTopologyWorkflow],
            activities=[stub_store_activity_topology],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            handle = await env.client.start_workflow(
                StubBaseTopologyWorkflow.run, {}, id="base-signals-test", task_queue="base-signals-queue"
            )
            import asyncio

            await asyncio.sleep(0.1)

            assert not await handle.query("is_interrupted")

            await handle.signal(
                BaseTopologyWorkflow.barge_in_interrupt,
                {
                    "event_cid": "barge-in-1",
                    "timestamp": 123456789.0,
                    "target_event_cid": "stub-cid",
                    "epistemic_disposition": "discard",
                },
            )

            await handle.signal(BaseTopologyWorkflow.receive_oracle_override, {"injected": True})

            # Cancel to safely avoid strictly typed Pydantic deadlocking
            await handle.cancel()
            from temporalio.client import WorkflowFailureError

            with pytest.raises(WorkflowFailureError):
                await handle.result()
            await asyncio.sleep(0.5)


# ── Stub Activities for Signal Tests ──────────────────────────────────


@activity.defn(name="BroadcastStateEchoIOActivity")
async def stub_broadcast_activity(*args: Any) -> None:
    pass


# ── apply_state_delta Signal Test ─────────────────────────────────────


@workflow.defn
class ApplyDeltaWorkflow(BaseTopologyWorkflow):
    """Stub workflow that waits for apply_state_delta signal."""

    @workflow.run
    async def run(self, _payload: dict[str, Any]) -> dict[str, Any]:
        self._current_state_envelope = _build_envelope()
        # Wait until state_delta has been applied via signal
        await workflow.wait_condition(
            lambda: (
                (self._current_state_envelope.state_vector.mutable_matrix or {}).get("signal_applied")  # type: ignore[union-attr]
                is not None
            ),
        )
        from datetime import timedelta

        await workflow.sleep(timedelta(milliseconds=100))
        mm = self._current_state_envelope.state_vector.mutable_matrix or {}
        return {
            "signal_applied": mm.get("signal_applied"),
            "causal_clock": self._current_state_envelope.trace_context.causal_clock,
        }


@pytest.mark.asyncio
async def test_apply_state_delta_signal() -> None:
    """apply_state_delta signal updates mutable matrix and dispatches broadcast.

    Covers L205-212 (apply_state_delta signal handler + BroadcastStateEchoIOActivity).
    """
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="delta-queue",
            workflows=[ApplyDeltaWorkflow],
            activities=[stub_store_activity_topology, stub_broadcast_activity],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            handle = await env.client.start_workflow(
                ApplyDeltaWorkflow.run, {}, id="delta-test", task_queue="delta-queue"
            )

            import asyncio

            await asyncio.sleep(0.1)

            await handle.signal(
                BaseTopologyWorkflow.apply_state_delta,
                {"signal_applied": True},
            )

            result = await handle.result()
            assert result["signal_applied"] is True
            assert result["causal_clock"] >= 1


# ── inject_oracle_resolution Signal Test ──────────────────────────────


@workflow.defn
class OracleResolutionWorkflow(BaseTopologyWorkflow):
    """Stub workflow that waits for inject_oracle_resolution signal."""

    @workflow.run
    async def run(self, _payload: dict[str, Any]) -> dict[str, Any]:
        self._current_state_envelope = _build_envelope()
        await workflow.wait_condition(lambda: self._current_oracle_resolution is not None)
        from datetime import timedelta

        await workflow.sleep(timedelta(milliseconds=100))
        return {"resolution": self._current_oracle_resolution}


@pytest.mark.asyncio
async def test_inject_oracle_resolution_signal() -> None:
    """inject_oracle_resolution signal stores the payload.

    Covers L227-228 (inject_oracle_resolution signal handler).
    """
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="oracle-res-queue",
            workflows=[OracleResolutionWorkflow],
            activities=[stub_store_activity_topology],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            handle = await env.client.start_workflow(
                OracleResolutionWorkflow.run, {}, id="oracle-res-test", task_queue="oracle-res-queue"
            )

            import asyncio

            await asyncio.sleep(0.1)

            await handle.signal(
                BaseTopologyWorkflow.inject_oracle_resolution,
                {"attestation": "biometric_verified", "operator_id": "dr_smith"},
            )

            result = await handle.result()
            assert result["resolution"]["attestation"] == "biometric_verified"


# ── emit_mcp_ui_intent Test ───────────────────────────────────────────


@workflow.defn
class EmitMCPIntentWorkflow(BaseTopologyWorkflow):
    """Stub workflow that exercises emit_mcp_ui_intent."""

    @workflow.run
    async def run(self, _payload: dict[str, Any]) -> dict[str, Any]:
        self._current_state_envelope = _build_envelope()
        await self.emit_mcp_ui_intent(
            intent_type="diagnostic_probe",
            context={"tool_name": "test_tool", "safety_level": "LOW"},
        )
        return {"emitted": True}


@pytest.mark.asyncio
async def test_emit_mcp_ui_intent() -> None:
    """emit_mcp_ui_intent dispatches BroadcastStateEchoIOActivity.

    Covers L239-253 (emit_mcp_ui_intent method + activity dispatch).
    """
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="mcp-intent-queue",
            workflows=[EmitMCPIntentWorkflow],
            activities=[stub_store_activity_topology, stub_broadcast_activity],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            result = await env.client.execute_workflow(
                EmitMCPIntentWorkflow.run, {}, id="mcp-intent-test", task_queue="mcp-intent-queue"
            )
            assert result["emitted"] is True


@activity.defn(name="RecordTokenBurnIOActivity")
async def stub_record_token_burn_activity(*args: Any) -> None:
    pass


@workflow.defn
class CoverageSweepWorkflow(BaseTopologyWorkflow):
    """Stub workflow to sweep remaining native line coverage dynamically."""

    @workflow.run
    async def run(self, _payload: dict[str, Any]) -> dict[str, Any]:
        from datetime import timedelta

        # 1. record_thermodynamic_burn fallback (non-dictionary)
        await self.record_thermodynamic_burn("dummy-node-id", "not-a-dict", 15.0)  # type: ignore

        # 2. enforce_governance_limits timeout breach
        start_time = workflow.now() - timedelta(seconds=10)
        import pytest

        with pytest.raises(ValueError, match="Global TTL breached"):
            self.enforce_governance_limits({"global_timeout_seconds": 5}, start_time)

        # 3. apply_state_delta without envelope
        self._current_state_envelope = None
        import pytest

        with pytest.raises(ValueError, match="active envelope"):
            await self.apply_state_delta({"testing": "value"})

        # 4. intercept_kinematic_intent timeout (Physical Safety Guillotine)
        import pytest

        with pytest.raises(PermissionError, match="Actuation blocked"):
            await self.intercept_kinematic_intent("ros2_bridge_move", {"target": "x"})

        return {"sweep": True}


@pytest.mark.asyncio
async def test_base_topology_coverage_sweep() -> None:
    """Validate timeout breaches, native exceptions, and physical safety limits inherently mapping to 100% coverage."""
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="sweep-queue",
            workflows=[CoverageSweepWorkflow],
            activities=[stub_store_activity_topology, stub_broadcast_activity, stub_record_token_burn_activity],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            res = await env.client.execute_workflow(
                CoverageSweepWorkflow.run, {}, id="sweep-test", task_queue="sweep-queue"
            )
            assert res["sweep"] is True


@workflow.defn
class KinematicSuccessWorkflow(BaseTopologyWorkflow):
    """Ensures Physical safety guillotine can be unblocked actively via oracle resolutions."""

    @workflow.run
    async def run(self, _payload: dict[str, Any]) -> dict[str, Any]:
        return await self.intercept_kinematic_intent("execute_se3_arm", {"target": "y", "tool_id": 123})


@pytest.mark.asyncio
async def test_base_topology_kinematic_success() -> None:
    """Confirms biometric intervention fulfills the contract accurately unblocking the wait condition cleanly."""
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="sweep-queue-2",
            workflows=[KinematicSuccessWorkflow],
            activities=[stub_store_activity_topology, stub_broadcast_activity],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            handle = await env.client.start_workflow(
                KinematicSuccessWorkflow.run, {}, id="sweep-test-2", task_queue="sweep-queue-2"
            )

            import asyncio

            await asyncio.sleep(0.1)

            # Send the Biometric Attestation Signal!
            await handle.signal(
                BaseTopologyWorkflow.inject_oracle_resolution, {"operator_id": "sysadmin-1", "biometric_verified": True}
            )

            res = await handle.result()
            assert res["safety_guillotine_passed"] is True
