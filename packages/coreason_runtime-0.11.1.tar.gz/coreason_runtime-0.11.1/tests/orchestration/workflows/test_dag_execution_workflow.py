import concurrent.futures
from typing import Any

import pytest
from temporalio import activity
from temporalio.client import WorkflowFailureError
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.dag_execution_workflow import DAGExecutionWorkflow


@activity.defn(name="StoreEpistemicStateIOActivity")
async def stub_store_epistemic(*args: Any, **kwargs: Any) -> None:
    pass


@activity.defn(name="ExecuteTensorInferenceComputeActivity")
async def stub_execute_tensor(*args: Any, **kwargs: Any) -> dict[str, Any]:
    if len(args) > 1 and isinstance(args[1], dict) and "node_profile" in args[1]:
        desc = args[1]["node_profile"].get("description", "")
        if "12" in desc:
            return {
                "status": "success",
                "outputs": {"tool_name": "test_mcp", "target_tool_name": "test_mcp", "tool_arguments": {}},
            }
        if "13" in desc:
            return {"status": "degraded", "raw": {}}
        if "firewall" in desc:
            return {
                "status": "epistemic_yield",
                "error": "mechanistic_firewall_trip: unsafe payload",
                "node_cid": "did:agent:firewall",
            }
        if "hologram" in desc:
            return {
                "status": "success",
                "outputs": {"tool_name": "test_mcp", "tool_arguments": {}, "holographic_projection": "fake-holo"},
            }
    return {
        "status": "epistemic_yield",
        "error": "yielded",
        "nested_activity": True,
        "outputs": {"result": "ok", "tool_name": "test_tool", "holographic_projection": "xyz"},
        "intent_hash": "hash1",
        "accumulated_tokens": 100,
    }


@activity.defn(name="FetchMemoizedStateIOActivity")
async def stub_fetch_memoized(*args: Any, **kwargs: Any) -> Any:
    return None


@activity.defn(name="ApplyDefeasibleCascadeComputeActivity")
async def stub_apply_cascade(*args: Any, **kwargs: Any) -> None:
    pass


@activity.defn(name="ExecuteRollbackIOActivity")
async def stub_execute_rollback(*args: Any, **kwargs: Any) -> None:
    pass


@activity.defn(name="ExecuteMCPToolIOActivity")
async def stub_mcp_tool(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {"status": "success"}


sys_calls = [0]


@activity.defn(name="ExecuteSystemFunctionComputeActivity")
async def stub_system_function(*args: Any, **kwargs: Any) -> dict[str, Any]:
    from temporalio.exceptions import ApplicationError

    sys_calls[0] += 1
    if sys_calls[0] >= 2:
        raise ApplicationError("Stop infinite loop", non_retryable=True)
    return {"status": "success"}


@activity.defn(name="RecordTokenBurnIOActivity")
async def stub_record_token_burn(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {"status": "success"}


@activity.defn(name="ExecuteOracleResolutionActivity")
async def stub_execute_oracle(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {"status": "success"}


def _build(manifest: dict[str, Any], env: bool = True) -> dict[str, Any]:
    return {
        "state_vector": {"immutable_matrix": {}, "mutable_matrix": {}} if env else None,
        "payload": manifest,
        "trace_context": {"trace_cid": "0123456789ABCDEFGHJKMNPQRS", "span_cid": "0123456789ABCDEFGHJKMNPQRS"},
    }


@pytest.mark.asyncio
async def test_dag_fault_geometries() -> None:
    async with await WorkflowEnvironment.start_time_skipping() as env:
        executor = concurrent.futures.ThreadPoolExecutor()
        async with Worker(
            env.client,
            task_queue="dag-queue",
            workflows=[DAGExecutionWorkflow],
            activities=[
                stub_store_epistemic,
                stub_execute_tensor,
                stub_fetch_memoized,
                stub_mcp_tool,
                stub_system_function,
                stub_record_token_burn,
                stub_execute_oracle,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=executor,
        ):
            # Test 1: Cycle with allow_cycles=False -> ValueError
            manifest_cycle = {
                "max_depth": 10,
                "max_fan_out": 10,
                "allow_cycles": False,
                "nodes": {
                    "did:agent:root": {
                        "topology_class": "agent",
                        "description": "root",
                        "action_space_cid": "0123456789ABCDEFGHJKMNPQRS",
                    },
                    "did:agent:nodeaaa": {
                        "topology_class": "agent",
                        "description": "test",
                        "action_space_cid": "0123456789ABCDEFGHJKMNPQRS",
                    },
                    "did:agent:nodebbb": {
                        "topology_class": "agent",
                        "description": "test",
                        "action_space_cid": "0123456789ABCDEFGHJKMNPQRS",
                    },
                },
                "edges": [
                    ("did:agent:root", "did:agent:nodeaaa"),
                    ("did:agent:nodeaaa", "did:agent:nodebbb"),
                    ("did:agent:nodebbb", "did:agent:nodeaaa"),
                ],
            }
            with pytest.raises(WorkflowFailureError) as exc:
                await env.client.execute_workflow(
                    DAGExecutionWorkflow.run, _build(manifest_cycle), id="t1", task_queue="dag-queue"
                )
            assert "ValidationError" in str(exc.value.cause)

            # Test 2: Max Depth Exceeded -> ValueError
            manifest_depth = {
                "max_depth": 0,
                "max_fan_out": 10,
                "allow_cycles": False,
                "nodes": {
                    "did:agent:nodeaaa": {
                        "topology_class": "agent",
                        "description": "test",
                        "action_space_cid": "0123456789ABCDEFGHJKMNPQRS",
                    }
                },
                "edges": [],
            }
            with pytest.raises(WorkflowFailureError) as exc:
                await env.client.execute_workflow(
                    DAGExecutionWorkflow.run, _build(manifest_depth), id="t2", task_queue="dag-queue"
                )
            assert "ValidationError" in str(exc.value.cause)

            # Test 3: Max Fan out exceeded -> ValueError
            manifest_fan = {
                "max_depth": 10,
                "max_fan_out": 0,
                "allow_cycles": False,
                "nodes": {
                    "did:agent:nodeaaa": {
                        "topology_class": "agent",
                        "description": "test",
                        "action_space_cid": "0123456789ABCDEFGHJKMNPQRS",
                    },
                    "did:agent:nodebbb": {
                        "topology_class": "agent",
                        "description": "test",
                        "action_space_cid": "0123456789ABCDEFGHJKMNPQRS",
                    },
                },
                "edges": [("did:agent:nodeaaa", "did:agent:nodebbb")],
            }
            with pytest.raises(WorkflowFailureError) as exc:
                await env.client.execute_workflow(
                    DAGExecutionWorkflow.run, _build(manifest_fan), id="t3", task_queue="dag-queue"
                )
            assert "ValidationError" in str(exc.value.cause)

            # Test 4: No cycle, allow_cycles=False -> Success
            manifest_acyclic = {
                "max_depth": 10,
                "max_fan_out": 10,
                "allow_cycles": False,
                "nodes": {
                    "did:agent:root": {
                        "topology_class": "agent",
                        "description": "root",
                        "action_space_cid": "0123456789ABCDEFGHJKMNPQRS",
                    },
                    "did:agent:nodeaaa": {
                        "topology_class": "agent",
                        "description": "test",
                        "action_space_cid": "0123456789ABCDEFGHJKMNPQRS",
                    },
                },
                "edges": [("did:agent:root", "did:agent:nodeaaa")],
            }
            res_acyclic = await env.client.execute_workflow(
                DAGExecutionWorkflow.run, _build(manifest_acyclic), id="t4", task_queue="dag-queue"
            )
            assert res_acyclic is not None
        executor.shutdown(wait=False)


@pytest.mark.asyncio
async def test_dag_edge_cases_and_types() -> None:
    async with await WorkflowEnvironment.start_time_skipping() as env:
        executor = concurrent.futures.ThreadPoolExecutor()
        async with Worker(
            env.client,
            task_queue="dag-q2",
            workflows=[DAGExecutionWorkflow],
            activities=[
                stub_store_epistemic,
                stub_execute_tensor,
                stub_fetch_memoized,
                stub_mcp_tool,
                stub_system_function,
                stub_record_token_burn,
                stub_execute_oracle,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=executor,
        ):
            manifest_human = {
                "max_depth": 10,
                "max_fan_out": 10,
                "allow_cycles": False,
                "nodes": {
                    "did:agent:nodeaaa": {
                        "topology_class": "human",
                        "description": "test",
                        "required_attestation": "urn:coreason:test",
                    }
                },
                "edges": [],
            }
            with pytest.raises(WorkflowFailureError) as exc_human:
                await env.client.execute_workflow(
                    DAGExecutionWorkflow.run, _build(manifest_human), id="t-human", task_queue="dag-q2"
                )
            assert "OracleSLAError" in str(exc_human.value.cause)

            manifest_sys_mem = {
                "max_depth": 10,
                "max_fan_out": 10,
                "allow_cycles": False,
                "nodes": {
                    "did:agent:nodebbb": {
                        "topology_class": "memoized",
                        "description": "test",
                        "target_topology_hash": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
                        "expected_output_schema": {},
                    },
                    "did:agent:nodeddd": {"topology_class": "system", "description": "test"},
                    "did:agent:thunktarget": {
                        "topology_class": "agent",
                        "description": "test",
                        "action_space_cid": "0123456789ABCDEFGHJKMNPQRS",
                    },
                },
                "edges": [("did:agent:thunktarget", "did:agent:nodebbb"), ("did:agent:nodebbb", "did:agent:nodeddd")],
            }
            res_sys_mem = await env.client.execute_workflow(
                DAGExecutionWorkflow.run, _build(manifest_sys_mem), id="t-sys-mem", task_queue="dag-q2"
            )
            assert res_sys_mem is not None

            manifest_speculative = {
                "max_depth": 10,
                "max_fan_out": 10,
                "allow_cycles": False,
                "speculative_boundaries": [{"boundary_cid": "did:agent:nodebbb", "commit_probability": 0.5}],
                "nodes": {
                    "did:agent:nodeaaa": {
                        "topology_class": "agent",
                        "description": "test",
                        "action_space_cid": "0123456789ABCDEFGHJKMNPQRS",
                    },
                    "did:agent:nodebbb": {
                        "topology_class": "agent",
                        "description": "test",
                        "action_space_cid": "0123456789ABCDEFGHJKMNPQRS",
                    },
                },
                "edges": [],
            }
            res_speculative = await env.client.execute_workflow(
                DAGExecutionWorkflow.run, _build(manifest_speculative), id="t-spec", task_queue="dag-q2"
            )
            assert res_speculative is not None

            manifest_comp = {
                "max_depth": 10,
                "max_fan_out": 10,
                "allow_cycles": False,
                "nodes": {
                    "did:comp": {
                        "topology_class": "composite",
                        "description": "test",
                        "topology": {"nodes": {}, "edges": [], "allow_cycles": False},
                    }
                },
                "edges": [],
            }
            with pytest.raises(WorkflowFailureError):
                await env.client.execute_workflow(
                    DAGExecutionWorkflow.run, _build(manifest_comp), id="t-comp", task_queue="dag-q2"
                )

            manifest_unit12_13 = {
                "max_depth": 10,
                "max_fan_out": 10,
                "allow_cycles": False,
                "nodes": {
                    "did:agent:toolnode": {"topology_class": "agent", "description": "12", "action_space_cid": "0123"},
                    "did:agent:quarantinenode": {"topology_class": "agent", "description": "13"},
                },
                "edges": [],
            }
            res_12_13 = await env.client.execute_workflow(
                DAGExecutionWorkflow.run, _build(manifest_unit12_13), id="t-12-13", task_queue="dag-q2"
            )
            assert res_12_13 is not None
        executor.shutdown(wait=False)


@pytest.mark.asyncio
async def test_dag_extended_coverage() -> None:
    """Appends physical mappings targeting edge envelopes natively."""
    async with await WorkflowEnvironment.start_time_skipping() as env:
        executor = concurrent.futures.ThreadPoolExecutor()
        async with Worker(
            env.client,
            task_queue="dag-ext-1",
            workflows=[DAGExecutionWorkflow],
            activities=[
                stub_store_epistemic,
                stub_execute_tensor,
                stub_fetch_memoized,
                stub_mcp_tool,
                stub_system_function,
                stub_record_token_burn,
                stub_execute_oracle,
                stub_apply_cascade,
                stub_execute_rollback,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=executor,
        ):
            # Test Envelope failure
            with pytest.raises(WorkflowFailureError) as exc_env:
                await env.client.execute_workflow(
                    DAGExecutionWorkflow.run, {"bad": "yes"}, id="t-env", task_queue="dag-ext-1"
                )
            assert "ValidationError" in str(exc_env.value.cause)

            # Test Manifest failure
            bad_env = _build({})
            bad_env["payload"] = {"unknown": True}
            with pytest.raises(WorkflowFailureError) as exc_man:
                await env.client.execute_workflow(DAGExecutionWorkflow.run, bad_env, id="t-man", task_queue="dag-ext-1")
            assert "ValidationError" in str(exc_man.value.cause)

            manifest_mega = {
                "max_depth": 10,
                "max_fan_out": 10,
                "allow_cycles": False,
                "backpressure": {"max_queue_depth": 2},
                "nodes": {
                    "did:agent:firewall": {
                        "topology_class": "agent",
                        "description": "firewall",
                        "action_space_cid": "123",
                    },
                    "did:agent:hologram": {
                        "topology_class": "agent",
                        "description": "hologram",
                        "action_space_cid": "123",
                    },
                    "did:agent:thunkednode": {
                        "topology_class": "agent",
                        "description": "12",
                        "action_space_cid": "123",
                        "status": "THUNKED",
                    },
                    "did:agent:human_ok": {
                        "topology_class": "human",
                        "description": "wait_for_signal",
                        "required_attestation": "urn:coreason:test",
                    },
                },
                "edges": [("did:agent:thunkednode", "did:agent:human_ok")],
            }

            import json

            import coreason_manifest

            orig_val = coreason_manifest.DAGTopologyManifest.model_validate_json

            def _fake_val(json_str: str, *args: Any, **kwargs: Any) -> Any:
                d = json.loads(json_str)
                if d.get("nodes", {}).get("did:agent:thunkednode"):
                    d["nodes"]["did:agent:thunkednode"].pop("status", None)
                    json_str = json.dumps(d)
                return orig_val(json_str, *args, **kwargs)

            coreason_manifest.DAGTopologyManifest.model_validate_json = _fake_val  # type: ignore

            try:
                handle = await env.client.start_workflow(
                    DAGExecutionWorkflow.run, _build(manifest_mega), id="mega-test", task_queue="dag-ext-1"
                )
                await handle.signal("inject_oracle_resolution", {"status": "resolved"})
                try:
                    res_mega = await handle.result()
                except Exception as inner_e:
                    with open("err.txt", "w") as fw:
                        fw.write(str(getattr(inner_e, "cause", inner_e)))
                    raise inner_e
            finally:
                coreason_manifest.DAGTopologyManifest.model_validate_json = orig_val  # type: ignore

            assert res_mega["status"] == "success"

        executor.shutdown(wait=False)
