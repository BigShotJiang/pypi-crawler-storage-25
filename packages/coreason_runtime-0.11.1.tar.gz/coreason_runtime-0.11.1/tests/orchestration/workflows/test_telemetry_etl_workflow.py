# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for TelemetryETLWorkflow.

Tests: successful ETL pipeline execution, activity result propagation.

All tests use Temporal time-skipping environments — zero unittest.mock.
"""

from typing import Any

import pytest
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.telemetry_etl_workflow import (
    TelemetryETLWorkflow,
)

# ── Physical Stub Activities ──────────────────────────────────────────


@activity.defn(name="ExecuteMedallionETLComputeActivity")
async def stub_medallion_etl(*args: Any) -> dict[str, str]:
    """Return a physical ETL result payload."""
    return {"status": "success", "rows_processed": "1024", "layer": "silver"}


# ── Tests ─────────────────────────────────────────────────────────────


class TestTelemetryETLWorkflow:
    """Physical Temporal tests for the Medallion ETL pipeline workflow."""

    @pytest.mark.asyncio
    async def test_etl_pipeline_success(self) -> None:
        """ETL pipeline executes activity and returns result."""
        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="etl-test-queue",
                workflows=[TelemetryETLWorkflow],
                activities=[stub_medallion_etl],
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                result = await env.client.execute_workflow(
                    TelemetryETLWorkflow.run,
                    id="etl-test-1",
                    task_queue="etl-test-queue",
                )

        assert result["status"] == "success"
        assert result["rows_processed"] == "1024"
        assert result["layer"] == "silver"
