import concurrent.futures
from typing import Any

# Preload C-extensions
import pytest
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.epistemic_sop_execution_workflow import (
    EpistemicSOPExecutionWorkflow,
    evaluate_prm_contract_activity,
)


def _build_manifest() -> dict[str, Any]:
    return {
        "sop_cid": "test_sop",
        "target_persona": "default_assistant",
        "cognitive_steps": {
            "step_1": {"urgency_index": 0.5, "caution_index": 0.5, "divergence_tolerance": 0.5},
            "step_2": {"urgency_index": 0.5, "caution_index": 0.5, "divergence_tolerance": 0.5},
        },
        "structural_grammar_hashes": {"step_1": "hash1", "step_2": "hash2"},
        "chronological_flow_edges": [["step_1", "step_2"]],
        "prm_evaluations": [{"pruning_threshold": 0.5, "max_backtracks_allowed": 3}],
    }


def _build_envelope(manifest: dict[str, Any]) -> dict[str, Any]:
    return {"payload": manifest, "trace_context": {"trace_cid": "trace1", "span_cid": "span1"}}


@pytest.mark.asyncio
async def test_epistemic_sop_workflow_valid_graph() -> None:
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="sop-test-queue",
            workflows=[EpistemicSOPExecutionWorkflow],
            activities=[evaluate_prm_contract_activity],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            payload = _build_envelope(_build_manifest())
            try:
                result = await env.client.execute_workflow(
                    EpistemicSOPExecutionWorkflow.run, payload, id="sop-val-test", task_queue="sop-test-queue"
                )
                assert result["status"] == "sop_execution_completed"
                assert result["executed_nodes"] == ["step_1", "step_2"]
            except Exception as e:
                print(e.cause if hasattr(e, "cause") else e)
                raise


@pytest.mark.asyncio
async def test_epistemic_sop_workflow_empty_edges() -> None:
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="sop-test-queue",
            workflows=[EpistemicSOPExecutionWorkflow],
            activities=[evaluate_prm_contract_activity],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            manifest = _build_manifest()
            manifest["chronological_flow_edges"] = []

            try:
                result = await env.client.execute_workflow(
                    EpistemicSOPExecutionWorkflow.run,
                    manifest,  # Test unpack envelope fallback
                    id="sop-val-test-no-edges",
                    task_queue="sop-test-queue",
                )
                assert result["status"] == "sop_execution_completed"
            except Exception as e:
                print(e.cause if hasattr(e, "cause") else e)
                raise


@pytest.mark.asyncio
async def test_epistemic_sop_workflow_prm_fail() -> None:
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="sop-test-fail-queue",
            workflows=[EpistemicSOPExecutionWorkflow],
            activities=[evaluate_prm_contract_activity],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            manifest = _build_manifest()
            manifest["cognitive_steps"]["malicious_step"] = {
                "urgency_index": 0.9,
                "caution_index": 0.1,
                "divergence_tolerance": 0.0,
            }
            manifest["structural_grammar_hashes"]["malicious_step"] = "hash3"
            manifest["chronological_flow_edges"] = [("malicious_step", "step_1")]

            payload = _build_envelope(manifest)

            from temporalio.client import WorkflowFailureError

            with pytest.raises(WorkflowFailureError) as exc_info:
                await env.client.execute_workflow(
                    EpistemicSOPExecutionWorkflow.run, payload, id="sop-fail-test", task_queue="sop-test-fail-queue"
                )

            assert "failed Process Reward Model" in str(exc_info.value.cause)


@pytest.mark.asyncio
async def test_epistemic_sop_workflow_validation_error() -> None:
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="sop-test-val-err-queue",
            workflows=[EpistemicSOPExecutionWorkflow],
            activities=[evaluate_prm_contract_activity],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            # Send completely invalid payload triggering Pydantic ValidationError natively
            invalid_payload = {"malformed": "data completely bypassing ontology bounds"}

            from temporalio.client import WorkflowFailureError

            with pytest.raises(WorkflowFailureError) as exc_info:
                await env.client.execute_workflow(
                    EpistemicSOPExecutionWorkflow.run,
                    invalid_payload,
                    id="sop-invalid-test",
                    task_queue="sop-test-val-err-queue",
                )

            assert "Manifest validation failed" in str(exc_info.value.cause)
