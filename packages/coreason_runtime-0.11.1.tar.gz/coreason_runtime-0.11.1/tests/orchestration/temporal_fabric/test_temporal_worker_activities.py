import asyncio
import sys
from unittest.mock import AsyncMock, MagicMock

import pytest

from coreason_runtime.orchestration.worker import (
    PartitionedActivityExecutor,
    _shutdown_handler,
    _vram_watchdog,
    start_worker,
)


@pytest.mark.asyncio
async def test_vram_watchdog_cpu_exceed(monkeypatch: pytest.MonkeyPatch) -> None:
    # 1. Mock psutil
    mock_psutil = MagicMock()
    mock_process = MagicMock()
    mock_mem = MagicMock()
    mock_mem.rss = 1000  # 1000 bytes
    mock_process.memory_info.return_value = mock_mem
    mock_psutil.Process.return_value = mock_process
    monkeypatch.setitem(sys.modules, "psutil", mock_psutil)

    # 2. Mock pynvml failure (no GPU)
    monkeypatch.setitem(sys.modules, "pynvml", None)

    event = asyncio.Event()
    # limit_bytes = 500, CPU mem = 1000. It should trip immediately and return.
    await _vram_watchdog(limit_bytes=500, cancel_event=event)
    assert event.is_set()


@pytest.mark.asyncio
async def test_vram_watchdog_gpu_poll_success(monkeypatch: pytest.MonkeyPatch) -> None:
    # Mock psutil
    mock_psutil = MagicMock()
    mock_process = MagicMock()
    mock_mem = MagicMock()
    mock_mem.rss = 200  # CPU mem
    mock_process.memory_info.return_value = mock_mem
    mock_psutil.Process.return_value = mock_process
    monkeypatch.setitem(sys.modules, "psutil", mock_psutil)

    # Mock pynvml
    mock_pynvml = MagicMock()
    mock_pynvml.nvmlInit = MagicMock()
    mock_pynvml.nvmlDeviceGetHandleByIndex = MagicMock(return_value="handle")
    info = MagicMock()
    info.used = 800  # GPU mem
    mock_pynvml.nvmlDeviceGetMemoryInfo = MagicMock(return_value=info)
    monkeypatch.setitem(sys.modules, "pynvml", mock_pynvml)

    event = asyncio.Event()
    # Total = 1000. Limit = 900.
    await _vram_watchdog(limit_bytes=900, cancel_event=event)
    assert event.is_set()


@pytest.mark.asyncio
async def test_vram_watchdog_polling_error(monkeypatch: pytest.MonkeyPatch) -> None:
    # Test that exception in polling loop doesn't crash the watchdog but continues
    mock_psutil = MagicMock()
    mock_psutil.Process.side_effect = Exception("Psutil crashed")
    monkeypatch.setitem(sys.modules, "psutil", mock_psutil)

    event = asyncio.Event()

    async def cancel_later() -> None:
        await asyncio.sleep(1.1)
        event.set()

    # Launch watchdog and an auto-cancel task so it doesn't run forever
    await asyncio.gather(_vram_watchdog(limit_bytes=500, cancel_event=event), cancel_later())
    # Should exit cleanly when event is set by cancel_later


def test_partitioned_activity_executor(monkeypatch: pytest.MonkeyPatch) -> None:
    executor = PartitionedActivityExecutor(max_workers=2)

    mock_activity = MagicMock()
    info = MagicMock()
    info.workflow_id = "wf_1"
    mock_activity.info.return_value = info
    monkeypatch.setitem(sys.modules, "temporalio.activity", mock_activity)

    # Normal submit with hash
    def dummy_func() -> int:
        return 1

    future = executor.submit(dummy_func)
    assert future.result() == 1

    # Exception fallback to default executor
    mock_activity.info.side_effect = Exception("Not in activity")
    future2 = executor.submit(dummy_func)
    assert future2.result() == 1


@pytest.mark.asyncio
async def test_shutdown_handler() -> None:
    worker = MagicMock()
    worker.shutdown = AsyncMock()
    activities = MagicMock()
    activities.store.close = AsyncMock()

    await _shutdown_handler(worker, activities)
    worker.shutdown.assert_called_once()
    activities.store.close.assert_called_once()


@pytest.mark.asyncio
async def test_start_worker(monkeypatch: pytest.MonkeyPatch) -> None:
    # Start worker starts whole machinery. Let's mock the heavy parts.
    mock_client = MagicMock()
    mock_client.connect = AsyncMock(return_value="TemporalClient")
    monkeypatch.setattr("coreason_runtime.orchestration.worker.Client", mock_client)

    mock_kinetic = MagicMock()
    mock_activities = MagicMock()
    mock_activities.ledger.bootstrap = AsyncMock()
    mock_activities.latent.bootstrap = AsyncMock()
    mock_activities.telemetry.start = AsyncMock()
    mock_activities.telemetry.close = AsyncMock()
    mock_kinetic.return_value = mock_activities
    monkeypatch.setattr("coreason_runtime.orchestration.worker.KineticActivities", mock_kinetic)

    mock_worker_cls = MagicMock()
    mock_worker_inst = MagicMock()
    mock_worker_inst.run = AsyncMock()
    mock_worker_cls.return_value = mock_worker_inst
    monkeypatch.setattr("coreason_runtime.orchestration.worker.Worker", mock_worker_cls)

    # Stub signal to avoid messing with test env
    monkeypatch.setattr("asyncio.get_running_loop", MagicMock(return_value=MagicMock()))

    # We must patch all local imports from worker to avoid resolving actual complex workflows
    # Or just let them resolve? The file imports execution_plane bindings natively, which is fine!

    await start_worker("localhost:7233")

    mock_client.connect.assert_called_once_with("localhost:7233")
    mock_activities.ledger.bootstrap.assert_called_once()
    mock_activities.telemetry.start.assert_called_once()
    mock_worker_inst.run.assert_called_once()
    mock_activities.telemetry.close.assert_called_once()
