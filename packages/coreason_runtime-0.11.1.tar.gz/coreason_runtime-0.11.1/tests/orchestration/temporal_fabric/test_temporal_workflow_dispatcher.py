import json
import typing
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest
import temporalio.client
import temporalio.exceptions
from pydantic import ValidationError

from coreason_runtime.orchestration.temporal_workflow_dispatcher import KineticExecutionManifold
from coreason_runtime.utils.exceptions import ManifestConformanceError


@pytest.fixture
def manifold() -> KineticExecutionManifold:
    man = KineticExecutionManifold()
    man._client = MagicMock()
    # By default, mock client.start_workflow to return a handle that resolves to {}
    handle_mock = MagicMock()
    handle_mock.result = AsyncMock(return_value={"success": True})
    handle_mock.cancel = AsyncMock()
    man._client.start_workflow = AsyncMock(return_value=handle_mock)
    man._client.execute_workflow = AsyncMock(return_value={"inference_result": "ok"})
    man._client.get_workflow_handle.return_value = handle_mock
    return man


@pytest.fixture
def base_manifest_mock(monkeypatch: pytest.MonkeyPatch) -> MagicMock:
    mock_manifest = MagicMock()
    mock_manifest.genesis_provenance.model_dump.return_value = {}
    mock_manifest.pq_signature = None
    mock_manifest.topology.compile_to_base_topology = None
    mock_manifest.topology.model_dump.return_value = {
        "topology_class": "swarm",
        "type": "swarm",
        "nodes": {
            "n1": {"type": "agent", "description": "base desc"},
            "n2": {"type": "composite", "eval_strategy": "lazy"},
        },
    }
    mock_manifest.tenant_cid = "tenant"
    mock_manifest.session_cid = "sess"
    mock_manifest.allowed_semantic_classifications = ["tier1"]
    mock_manifest.governance.max_budget_magnitude = 1000

    monkeypatch.setattr(
        "coreason_runtime.orchestration.temporal_workflow_dispatcher.WorkflowManifest.model_validate",
        MagicMock(return_value=mock_manifest),
    )
    monkeypatch.setattr(
        "coreason_runtime.orchestration.temporal_workflow_dispatcher.verify_genesis_provenance",
        MagicMock(return_value=True),
    )
    monkeypatch.setattr(
        "coreason_runtime.orchestration.temporal_workflow_dispatcher.verify_pq_signature", MagicMock(return_value=True)
    )
    monkeypatch.setattr(
        "coreason_runtime.orchestration.temporal_workflow_dispatcher._WORKFLOW_REGISTRY",
        {"swarm": MagicMock(), "architectural_transmutation": MagicMock()},
    )
    return mock_manifest


@pytest.mark.asyncio
async def test_execute_invalid_json(tmp_path: typing.Any) -> None:
    man = KineticExecutionManifold()
    bad_file = tmp_path / "manifest.json"
    bad_file.write_text("{bad_json")

    with pytest.raises(json.JSONDecodeError):
        await man.execute(str(bad_file))

    fake_file = tmp_path / "not_there.json"
    with pytest.raises(FileNotFoundError):
        await man.execute(str(fake_file))


@pytest.mark.asyncio
async def test_execute_from_dict_validation_errors(
    manifold: KineticExecutionManifold, monkeypatch: pytest.MonkeyPatch
) -> None:
    # 1. Invalid Manifest schema
    monkeypatch.setattr(
        "coreason_runtime.orchestration.temporal_workflow_dispatcher.WorkflowManifest.model_validate",
        MagicMock(side_effect=ValidationError("err", [])),
    )
    with pytest.raises(ManifestConformanceError):
        await manifold.execute_from_dict({"topology": {}})

    # 2. Invalid Genesis Provenance
    mock_man = MagicMock()
    mock_man.genesis_provenance.model_dump.return_value = {}
    mock_man.pq_signature = None
    monkeypatch.setattr(
        "coreason_runtime.orchestration.temporal_workflow_dispatcher.WorkflowManifest.model_validate",
        MagicMock(return_value=mock_man),
    )
    monkeypatch.setattr(
        "coreason_runtime.orchestration.temporal_workflow_dispatcher.verify_genesis_provenance",
        MagicMock(return_value=False),
    )

    with pytest.raises(ValueError, match="Invalid genesis provenance"):
        await manifold.execute_from_dict({})

    # 3. Invalid PQ Signature
    mock_man.pq_signature = MagicMock()
    monkeypatch.setattr(
        "coreason_runtime.orchestration.temporal_workflow_dispatcher.verify_genesis_provenance",
        MagicMock(return_value=True),
    )
    monkeypatch.setattr(
        "coreason_runtime.orchestration.temporal_workflow_dispatcher.verify_pq_signature", MagicMock(return_value=False)
    )

    with pytest.raises(ValueError, match="Post-quantum signature"):
        await manifold.execute_from_dict({})


@pytest.mark.asyncio
async def test_execute_compile_to_base_topology_and_perturbation(
    manifold: KineticExecutionManifold, base_manifest_mock: MagicMock
) -> None:
    # Set up compile_to_base_topology
    base_top = MagicMock()
    base_top.model_dump.return_value = {
        "topology_class": "swarm",
        "nodes": {
            "a1": {"topology_class": "agent", "description": "base"},
            "c1": {"topology_class": "composite", "eval_strategy": "lazy"},
        },
    }
    base_top.topology_class = "swarm"
    base_manifest_mock.topology.compile_to_base_topology = MagicMock(return_value=base_top)

    res = await manifold.execute_from_dict(
        {"topology": {"edges": [["a1", "c1"]], "dag": {"edges": [["a1", "c1"]]}}},
        exogenous_perturbation_vector="add chaos",
    )
    assert res.get("success") is True


@pytest.mark.asyncio
async def test_execute_unknown_workflow(
    manifold: KineticExecutionManifold, base_manifest_mock: MagicMock, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr("coreason_runtime.orchestration.temporal_workflow_dispatcher._WORKFLOW_REGISTRY", {})
    with pytest.raises(ValueError, match="Unknown or missing manifest type"):
        await manifold.execute_from_dict({})


@pytest.mark.asyncio
async def test_execute_workflow_failure(manifold: KineticExecutionManifold, base_manifest_mock: MagicMock) -> None:
    handle_mock = MagicMock()
    err = temporalio.exceptions.ApplicationError("BudgetExhaustion!")
    handle_mock.result = AsyncMock(side_effect=temporalio.client.WorkflowFailureError(cause=err))
    manifold._client.start_workflow = AsyncMock(return_value=handle_mock)  # type: ignore

    with pytest.raises(temporalio.client.WorkflowFailureError):
        await manifold.execute_from_dict({})


@pytest.mark.asyncio
async def test_execute_architectural_transmutation(
    manifold: KineticExecutionManifold, base_manifest_mock: MagicMock, monkeypatch: pytest.MonkeyPatch
) -> None:
    base_manifest_mock.topology.model_dump.return_value["topology_class"] = "architectural_transmutation"

    mock_bridge = MagicMock()
    mock_bridge.publish_crystallized_topology = AsyncMock()
    monkeypatch.setattr(
        "coreason_runtime.federation.substrate_bridge_client.SubstrateBridgeClient", MagicMock(return_value=mock_bridge)
    )

    await manifold.execute_from_dict({})
    mock_bridge.publish_crystallized_topology.assert_called_once()

    # Test bridge failure
    mock_bridge.publish_crystallized_topology.side_effect = Exception("bridge down")
    res = await manifold.execute_from_dict({})
    assert res == {"success": True}


@pytest.mark.asyncio
async def test_execute_mcp_promotion(
    manifold: KineticExecutionManifold, base_manifest_mock: MagicMock, monkeypatch: pytest.MonkeyPatch
) -> None:
    mock_registry = MagicMock()
    mock_registry.publish_master_mcp = AsyncMock(return_value="urn:coreason:mcp:123")
    monkeypatch.setattr(
        "coreason_runtime.orchestration.temporal_workflow_dispatcher.FederatedCapabilityRegistryClient",
        MagicMock(return_value=mock_registry),
    )

    res = await manifold.execute_from_dict({})
    mock_registry.publish_master_mcp.assert_called_once()
    assert "_crystalized_promotion" in res

    # Test registry fallback (httpx RequestError)
    mock_registry.publish_master_mcp.side_effect = httpx.RequestError("Network error")
    res2 = await manifold.execute_from_dict({})
    assert "_crystalized_promotion" in res2


@pytest.mark.asyncio
async def test_execute_active_inference(manifold: KineticExecutionManifold) -> None:
    mock_contract = MagicMock()
    mock_contract.model_dump.return_value = {}
    mock_epoch = MagicMock()
    mock_epoch.model_dump.return_value = {}

    res = await manifold.execute_active_inference(mock_contract, mock_epoch, 2)
    assert res == {"inference_result": "ok"}

    # Without client
    manifold._client = None
    with pytest.raises(RuntimeError, match="Temporal Client not initialized"):
        await manifold.execute_active_inference(mock_contract, mock_epoch, 2)
