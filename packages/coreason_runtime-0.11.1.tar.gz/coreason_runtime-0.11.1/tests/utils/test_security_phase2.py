# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Phase 2 coverage tests for security.py edge cases.

Targets: verify_genesis_provenance (L25, L30), verify_pq_signature failure paths (L45-123),
verify_wetware_attestation full decode path, DataRedactor nested list with dict items.

All tests use physically instantiated values — zero unittest.mock.
"""

import base64
import json
from typing import Any

import pytest
from coreason_manifest import WetwareAttestationContract

from coreason_runtime.utils.security import (
    DataRedactor,
    compute_homomorphic_cosine_similarity,
    verify_genesis_provenance,
    verify_pq_signature,
    verify_wetware_attestation,
)


def _oqs_available() -> bool:
    """Check if liboqs shared libraries are physically available.

    Note: The oqs module calls SystemExit(1) when liboqs is missing,
    which inherits from BaseException, not Exception.
    """
    try:
        import oqs

        oqs.Signature("Dilithium2")
        return True
    except BaseException:
        return False


# ── verify_genesis_provenance Tests ───────────────────────────────────


class TestVerifyGenesisProvenanceEdgeCases:
    """Cover uncovered branches in verify_genesis_provenance."""

    def test_empty_provenance_bypasses(self) -> None:
        """Empty dict returns True (debug bypass on L25)."""
        assert verify_genesis_provenance({}) is True

    def test_none_like_provenance_bypasses(self) -> None:
        """None-like falsy provenance returns True."""
        assert verify_genesis_provenance({}) is True

    def test_missing_source_event_id(self) -> None:
        """Missing source_event_cid returns False (L30)."""
        assert verify_genesis_provenance({"extracted_by": "agent"}) is False

    def test_missing_extracted_by(self) -> None:
        """Missing extracted_by returns False (L30)."""
        assert verify_genesis_provenance({"source_event_cid": "abcdefghijklmnop"}) is False

    def test_short_source_event_id(self) -> None:
        """Source event ID shorter than 8 chars returns False (L33)."""
        assert verify_genesis_provenance({"source_event_cid": "short", "extracted_by": "agent"}) is False

    def test_valid_provenance(self) -> None:
        """Valid provenance with all fields passes."""
        assert verify_genesis_provenance({"source_event_cid": "abcdefghijklmnop", "extracted_by": "agent-001"}) is True

    def test_legacy_source_event_id_key(self) -> None:
        """Falls back to source_event_id if source_event_cid is missing."""
        assert verify_genesis_provenance({"source_event_id": "abcdefghijklmnop", "extracted_by": "agent-001"}) is True


# ── verify_pq_signature Tests (Failure Paths) ────────────────────────


class TestVerifyPqSignatureFailurePaths:
    """Cover the failure branches in verify_pq_signature.

    The success path requires live liboqs/oqs — we test the FAILURE paths which
    are pure Python exception handling.
    """

    def test_empty_signature_returns_false(self) -> None:
        """Empty dict returns False (L46)."""
        assert verify_pq_signature({}) is False

    def test_none_signature_returns_false(self) -> None:
        """None returns False."""
        assert verify_pq_signature(None) is False  # type: ignore[arg-type]

    def test_missing_algorithm(self) -> None:
        """Missing pq_algorithm returns False (L54)."""
        assert verify_pq_signature({"public_key_id": "key", "pq_signature_blob": "blob"}) is False

    def test_missing_public_key_id(self) -> None:
        """Missing public_key_id returns False (L54)."""
        assert verify_pq_signature({"pq_algorithm": "Ed25519", "pq_signature_blob": "blob"}) is False

    def test_missing_blob(self) -> None:
        """Missing pq_signature_blob returns False (L54)."""
        assert verify_pq_signature({"pq_algorithm": "Ed25519", "public_key_id": "key"}) is False

    @pytest.mark.skipif(
        not _oqs_available(),
        reason="liboqs shared libraries not installed — PQ crypto paths require physical hardware",
    )
    def test_malformed_key_triggers_exception_path(self) -> None:
        """Malformed key material triggers the broad except on L119-123.

        Note: This imports `oqs` which may attempt to auto-install liboqs.
        The test validates the exception path regardless of oqs availability.
        """
        result = verify_pq_signature(
            {
                "pq_algorithm": "Unknown_PQC_Algo",
                "public_key_id": base64.b64encode(b"x" * 32).decode(),
                "pq_signature_blob": base64.b64encode(b"y" * 64).decode(),
            }
        )
        # The function should return False via one of the exception handlers
        assert result is False

    @pytest.mark.skipif(
        not _oqs_available(),
        reason="liboqs shared libraries not installed — PQ crypto paths require physical hardware",
    )
    def test_valid_ed25519_format_but_wrong_signature(self) -> None:
        """Valid-looking Ed25519 key but cryptographically invalid signature returns False."""
        # 32-byte hex public key (64 hex chars) — looks like Ed25519 format
        fake_pk = "a" * 64
        fake_blob = base64.b64encode(b"x" * 64).decode()
        result = verify_pq_signature(
            {
                "pq_algorithm": "Ed25519",
                "public_key_id": fake_pk,
                "pq_signature_blob": fake_blob,
            }
        )
        # Cryptographic verification will fail -> False
        assert result is False

    @pytest.mark.skipif(
        not _oqs_available(),
        reason="liboqs shared libraries not installed — PQ crypto paths require physical hardware",
    )
    def test_pem_format_key_triggers_parse_branch(self) -> None:
        """PEM-formatted key triggers the `-----BEGIN` parsing branch (L70-71)."""
        # This will fail to load as a real PEM, but it exercises the code path
        result = verify_pq_signature(
            {
                "pq_algorithm": "Ed25519",
                "public_key_id": "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEA\n-----END PUBLIC KEY-----",
                "pq_signature_blob": base64.b64encode(b"x" * 64).decode(),
            }
        )
        assert result is False


# ── verify_wetware_attestation Tests ──────────────────────────────────


class TestVerifyWetwareAttestationEdgeCases:
    """Cover additional branches in verify_wetware_attestation."""

    def test_missing_mechanism(self) -> None:
        """No mechanism returns False (L192)."""
        attestation = WetwareAttestationContract.model_construct(
            mechanism=None,  # type: ignore[arg-type]
            did_subject="did:coreason:test",
            liveness_challenge_hash="abcd",
            dag_node_nonce="12345",
            cryptographic_payload="payload",
        )
        assert verify_wetware_attestation(attestation) is False

    def test_invalid_mechanism(self) -> None:
        """Mechanism not in ACCEPTED_MECHANISMS returns False."""
        attestation = WetwareAttestationContract.model_construct(
            mechanism="password_auth",
            did_subject="did:coreason:test",
            liveness_challenge_hash="abcd",
            dag_node_nonce="12345",
            cryptographic_payload="payload",
        )
        assert verify_wetware_attestation(attestation) is False

    def test_short_nonce(self) -> None:
        """Nonce shorter than 4 chars returns False (L197)."""
        attestation = WetwareAttestationContract.model_construct(
            mechanism="webauthn",
            did_subject="did:coreason:test",
            liveness_challenge_hash="abcd",
            dag_node_nonce="ab",
            cryptographic_payload="payload",
        )
        assert verify_wetware_attestation(attestation) is False

    def test_empty_crypto_payload(self) -> None:
        """Empty cryptographic_payload returns False (L202)."""
        attestation = WetwareAttestationContract.model_construct(
            mechanism="webauthn",
            did_subject="did:coreason:test",
            liveness_challenge_hash="abcd",
            dag_node_nonce="12345",
            cryptographic_payload="",
        )
        assert verify_wetware_attestation(attestation) is False

    @pytest.mark.skipif(
        not _oqs_available(),
        reason="liboqs shared libraries not installed — PQ crypto paths require physical hardware",
    )
    def test_valid_structure_delegates_to_pq(self) -> None:
        """Valid structure with real base64 JSON payload exercises full decode path."""
        sig_dict = {"pq_algorithm": "Ed25519", "public_key_id": "a" * 64, "pq_signature_blob": "YQ=="}
        encoded_payload = base64.b64encode(json.dumps(sig_dict).encode()).decode()
        attestation = WetwareAttestationContract.model_construct(
            mechanism="fido2_webauthn",
            did_subject="did:coreason:test",
            liveness_challenge_hash="abcdef",
            dag_node_nonce="123456",
            cryptographic_payload=encoded_payload,
        )
        # Delegates to verify_pq_signature which will return False (no real crypto)
        result = verify_wetware_attestation(attestation)
        assert result is False

    def test_non_dict_json_payload(self) -> None:
        """JSON payload that decodes to a non-dict returns False (L209-210)."""
        encoded_payload = base64.b64encode(json.dumps([1, 2, 3]).encode()).decode()
        attestation = WetwareAttestationContract.model_construct(
            mechanism="webauthn",
            did_subject="did:coreason:test",
            liveness_challenge_hash="abcdef",
            dag_node_nonce="123456",
            cryptographic_payload=encoded_payload,
        )
        assert verify_wetware_attestation(attestation) is False


# ── DataRedactor Edge Cases ───────────────────────────────────────────


class TestDataRedactorEdgeCases:
    """Cover nested list+dict redaction branch (L260-270)."""

    def test_redact_dict_with_nested_list_of_dicts(self) -> None:
        """Lists containing dicts inside a parent dict are recursively redacted."""
        data: dict[str, Any] = {
            "records": [
                {"ssn": "123-45-6789", "name": "John"},
                {"ssn": "987-65-4321", "name": "Jane"},
            ]
        }
        result = DataRedactor.redact_dict(data)
        assert "[PHI_REDACTED]" in result["records"][0]["ssn"]
        assert "[PHI_REDACTED]" in result["records"][1]["ssn"]
        assert result["records"][0]["name"] == "John"

    def test_redact_dict_with_nested_list_of_lists(self) -> None:
        """Lists containing lists are recursively redacted."""
        data: dict[str, Any] = {"matrix": [["SSN: 123-45-6789", "clean"], ["also clean"]]}
        result = DataRedactor.redact_dict(data)
        assert "[PHI_REDACTED]" in result["matrix"][0][0]
        assert result["matrix"][0][1] == "clean"

    def test_redact_dict_with_non_string_values(self) -> None:
        """Non-string, non-dict, non-list values are excluded from redacted output.

        DataRedactor.redact_dict only processes str, dict, and list values.
        Non-matching types are silently dropped (not included in output).
        """
        data: dict[str, Any] = {"count": 42, "active": True, "ratio": 3.14}
        result = DataRedactor.redact_dict(data)
        # redact_dict skips non-string/dict/list values
        assert result == {}


# ── compute_homomorphic_cosine_similarity edge ────────────────────────


class TestHomomorphicEdgeCases:
    """Cover the norm_a/norm_b == 0 branch L158."""

    def test_zero_norm_returns_zero(self) -> None:
        """Zero-byte strings produce zero norm -> 0.0."""
        # Strings shorter than 20 chars are .encode()'d, not base64-decoded
        # b"\x00" bytes produce zero magnitude
        result = compute_homomorphic_cosine_similarity("\x00\x00\x00", "\x00\x00\x00")
        assert result == 0.0

    def test_long_base64_valid_strings(self) -> None:
        """Strings >= 20 chars are base64-decoded; exercise that branch."""
        a = base64.b64encode(b"hello world test data").decode()
        b = base64.b64encode(b"hello world test data").decode()
        result = compute_homomorphic_cosine_similarity(a, b)
        assert result == pytest.approx(1.0, abs=1e-5)
