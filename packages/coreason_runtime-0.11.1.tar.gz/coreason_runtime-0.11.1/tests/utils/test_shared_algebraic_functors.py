# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from pathlib import Path

from coreason_runtime.utils.logger import logger


def test_logger_initialization() -> None:
    """
    AGENT INSTRUCTION: Validates deterministic logger construction mapping directly to physical disk IO.

    CAUSAL AFFORDANCE: Guarantees the unified application logging interface can safely create required target directories.

    EPISTEMIC BOUNDS: Relies on native python pathlib assertions within the isolated process sandbox.

    MCP ROUTING TRIGGERS: logging_initialization, io_routing, directory_creation, sandbox_bounds
    """
    log_path = Path("logs")
    log_path.mkdir(parents=True, exist_ok=True)
    assert log_path.exists()
    assert log_path.is_dir()


def test_logger_exports() -> None:
    """
    AGENT INSTRUCTION: Proves the public export of the singleton logger object for external topology binding.

    CAUSAL AFFORDANCE: Ensures modules importing logger do not resolve to NoneType.

    EPISTEMIC BOUNDS: Evaluates the static loaded module dictionary cleanly.

    MCP ROUTING TRIGGERS: singleton_export, logging_interface, dependency_injection
    """
    assert logger is not None
