from typing import Any

import httpx
import pytest
from fastapi import FastAPI, HTTPException
from fastapi.responses import Response

from coreason_runtime.federation.federated_capability_registry_client import FederatedCapabilityRegistryClient
from coreason_runtime.utils.exceptions import ManifestConformanceError

app = FastAPI()

# Mock endpoints for FederatedCapabilityRegistryClient


@app.get("/api/v1/registry/capabilities/{urn}/download")
async def get_wasm(urn: str) -> Response:
    if urn == "not_found":
        raise HTTPException(status_code=404, detail="Not Found")

    if urn == "too_big":
        # Return 11MB of zero bytes to trigger the 10MB trap
        return Response(content=b"\x00" * 11000000, media_type="application/wasm")

    # Regular valid returning
    return Response(content=b"VALID_WASM_BYTES", media_type="application/wasm")


@app.post("/api/v1/registry/capabilities/publish")
async def publish_mcp(event: dict[str, Any]) -> dict[str, Any]:
    # Mock publishing logic, returning urn
    if event.get("compression_ratio") is None:
        raise HTTPException(status_code=400, detail="Bad Request")
    return {"urn": f"urn:coreason:capability:{event.get('crystallized_semantic_node_cid')}"}


@pytest.fixture
def registry_client(monkeypatch: Any) -> FederatedCapabilityRegistryClient:
    monkeypatch.setenv("ECOSYSTEM_REGISTRY_URL", "http://mockserver")
    transport = httpx.ASGITransport(app=app)
    # The new __init__ accepts transport
    return FederatedCapabilityRegistryClient(transport=transport)


@pytest.mark.asyncio
async def test_fetch_capability_binary_valid(registry_client: FederatedCapabilityRegistryClient) -> None:
    data = await registry_client.fetch_capability_binary("urn:coreason:capability:valid")
    assert data == b"VALID_WASM_BYTES"


@pytest.mark.asyncio
async def test_fetch_capability_binary_not_found(registry_client: FederatedCapabilityRegistryClient) -> None:
    with pytest.raises(ManifestConformanceError, match="Client error '404 Not Found'"):
        await registry_client.fetch_capability_binary("not_found")


@pytest.mark.asyncio
async def test_fetch_capability_binary_too_big(registry_client: FederatedCapabilityRegistryClient) -> None:
    with pytest.raises(ManifestConformanceError, match="payload exceeds"):
        await registry_client.fetch_capability_binary("too_big")


@pytest.mark.asyncio
async def test_publish_master_mcp_success(registry_client: FederatedCapabilityRegistryClient) -> None:
    event = {
        "event_cid": "promotion-123",
        "crystallized_semantic_node_cid": "crystal-456",
        "compression_ratio": 1.0,
        "timestamp": 1234567890.0,
        "source_episodic_event_cids": ["Dynamic Intent Execution"],
    }
    urn = await registry_client.publish_master_mcp(event)
    assert urn == "urn:coreason:capability:crystal-456"
