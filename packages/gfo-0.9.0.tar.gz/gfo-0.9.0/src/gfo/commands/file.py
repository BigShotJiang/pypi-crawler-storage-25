"""gfo file サブコマンドのハンドラ。"""

from __future__ import annotations

import argparse
import json
import sys

from gfo.commands import get_adapter
from gfo.exceptions import NotFoundError
from gfo.i18n import _
from gfo.output import apply_jq_filter


def handle_get(args: argparse.Namespace, *, fmt: str, jq: str | None = None) -> None:
    """gfo file get <path> [--ref REF] のハンドラ。"""
    adapter = get_adapter()
    content, sha = adapter.get_file_content(args.path, ref=args.ref)
    if fmt == "json":
        json_str = json.dumps(
            {"path": args.path, "content": content, "sha": sha}, ensure_ascii=False
        )
        if jq is not None:
            print(apply_jq_filter(json_str, jq))
        else:
            print(json_str)
    else:
        print(content)


def handle_put(args: argparse.Namespace, *, fmt: str, jq: str | None = None) -> None:
    """gfo file put <path> --message TEXT のハンドラ。stdin からファイル内容を読み込む。"""
    adapter = get_adapter()
    content = sys.stdin.read()
    # SHA が必要な場合は既存ファイルから取得
    sha: str | None = None
    try:
        _content, sha = adapter.get_file_content(args.path, ref=args.branch)
    except NotFoundError:
        sha = None
    commit_sha = adapter.create_or_update_file(
        args.path,
        content=content,
        message=args.message,
        sha=sha,
        branch=args.branch,
    )
    if commit_sha:
        print(_("Updated file '{path}' (commit: {sha}).").format(path=args.path, sha=commit_sha))
    else:
        print(_("Updated file '{path}'.").format(path=args.path))


def handle_delete(args: argparse.Namespace, *, fmt: str, jq: str | None = None) -> None:
    """gfo file delete <path> --message TEXT のハンドラ。"""
    adapter = get_adapter()
    _content, sha = adapter.get_file_content(args.path, ref=args.branch)
    adapter.delete_file(args.path, sha=sha, message=args.message, branch=args.branch)
    print(_("Deleted file '{path}'.").format(path=args.path))
