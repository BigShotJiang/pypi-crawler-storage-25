from django.apps import AppConfig


class DjangoldpGlcdiPointBlueConfig(AppConfig):
    name = "djangoldp_glcdi_pointblue"
