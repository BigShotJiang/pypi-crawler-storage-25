from django.db import models
from django.utils.translation import gettext_lazy as _
from djangoldp import fields

from djangoldp_glcdi_common.models.__base_model import baseModel


class FieldLevel(baseModel):
    from_csv = fields.BooleanField(default=False, verbose_name=_("From CSV"))
    farm = fields.ForeignKey(
        "djangoldp_glcdi_pointblue.Farm",
        on_delete=models.CASCADE,
        related_name="field_levels",
        verbose_name=_("Farm"),
    )
    project_id = fields.CharField(max_length=50, verbose_name=_("Project ID"))
    protocol = fields.CharField(
        max_length=20, blank=True, null=True, verbose_name=_("Protocol")
    )
    submission_date = fields.DateField(
        blank=True, null=True, verbose_name=_("Submission Date")
    )
    cons_practice = fields.CharField(
        max_length=255, blank=True, null=True, verbose_name=_("Conservation Practice")
    )
    practice_year = fields.IntegerField(
        blank=True, null=True, verbose_name=_("Practice Year")
    )
    hist_currentlu_yrs = fields.CharField(
        max_length=100, blank=True, null=True, verbose_name=_("Current Land Use Years")
    )
    hist_currentman_yrs = fields.CharField(
        max_length=100,
        blank=True,
        null=True,
        verbose_name=_("Current Management Years"),
    )
    hist_flood_yr = fields.IntegerField(
        blank=True, null=True, verbose_name=_("Last Flood Year")
    )
    hist_fire_yr = fields.IntegerField(
        blank=True, null=True, verbose_name=_("Last Fire Year")
    )
    hist_irr_yn = fields.CharField(
        max_length=10, blank=True, null=True, verbose_name=_("Historical Irrigation")
    )
    hist_pest_yn = fields.CharField(
        max_length=10, blank=True, null=True, verbose_name=_("Historical Pesticides")
    )
    hist_herb_yn = fields.CharField(
        max_length=10, blank=True, null=True, verbose_name=_("Historical Herbicides")
    )
    hist_crop_yrs = fields.CharField(
        max_length=255,
        blank=True,
        null=True,
        verbose_name=_("Historical Crop Years"),
    )
    hist_ls_type = fields.CharField(
        max_length=255,
        blank=True,
        null=True,
        verbose_name=_("Historical Livestock Type"),
    )
    hist_ls_utilization = fields.CharField(
        max_length=50,
        blank=True,
        null=True,
        verbose_name=_("Historical Livestock Utilization"),
    )
    hist_ls_season_start = fields.CharField(
        max_length=50,
        blank=True,
        null=True,
        verbose_name=_("Historical Grazing Season Start"),
    )
    hist_ls_season_end = fields.CharField(
        max_length=50,
        blank=True,
        null=True,
        verbose_name=_("Historical Grazing Season End"),
    )
    hist_ls_paddocks = fields.CharField(
        max_length=50,
        blank=True,
        null=True,
        verbose_name=_("Historical Paddocks"),
    )
    hist_ls_resttime = fields.CharField(
        max_length=50,
        blank=True,
        null=True,
        verbose_name=_("Historical Rest Time"),
    )
    hist_ls_ada = fields.CharField(
        max_length=50,
        blank=True,
        null=True,
        verbose_name=_("Historical Animal Days/Acre"),
    )
    hist_crop_details = fields.TextField(
        blank=True, null=True, verbose_name=_("Historical Crop Details")
    )
    till_hist_yr0 = fields.TextField(
        blank=True, null=True, verbose_name=_("Tillage Year 0")
    )
    till_hist_yr1 = fields.TextField(
        blank=True, null=True, verbose_name=_("Tillage Year -1")
    )
    till_hist_yr2 = fields.TextField(
        blank=True, null=True, verbose_name=_("Tillage Year -2")
    )
    till_hist_yr3 = fields.TextField(
        blank=True, null=True, verbose_name=_("Tillage Year -3")
    )
    till_hist_yr4 = fields.TextField(
        blank=True, null=True, verbose_name=_("Tillage Year -4")
    )
    hist_notes = fields.TextField(
        blank=True, null=True, verbose_name=_("Historical Notes")
    )
    cr_desc = fields.TextField(
        blank=True, null=True, verbose_name=_("Crop Rotation Description")
    )
    cr_list = fields.TextField(
        blank=True, null=True, verbose_name=_("Crop Rotation List")
    )
    ls_type = fields.CharField(
        max_length=255, blank=True, null=True, verbose_name=_("Livestock Type")
    )
    ls_utilization = fields.CharField(
        max_length=50,
        blank=True,
        null=True,
        verbose_name=_("Livestock Utilization"),
    )
    ls_season_start = fields.CharField(
        max_length=50,
        blank=True,
        null=True,
        verbose_name=_("Grazing Season Start"),
    )
    ls_season_end = fields.CharField(
        max_length=50,
        blank=True,
        null=True,
        verbose_name=_("Grazing Season End"),
    )
    ls_paddocks = fields.CharField(
        max_length=50, blank=True, null=True, verbose_name=_("Paddocks")
    )
    ls_rest_time = fields.CharField(
        max_length=50, blank=True, null=True, verbose_name=_("Rest Time")
    )
    ls_ada = fields.CharField(
        max_length=50, blank=True, null=True, verbose_name=_("Animal Days/Acre")
    )
    ls_notes = fields.TextField(
        blank=True, null=True, verbose_name=_("Livestock Notes")
    )
    conv_plan_notes = fields.TextField(
        blank=True, null=True, verbose_name=_("Conversion Plan Notes")
    )
    mulch_ret_app = fields.CharField(
        max_length=255, blank=True, null=True, verbose_name=_("Mulch Retention")
    )
    mulch_type = fields.CharField(
        max_length=255, blank=True, null=True, verbose_name=_("Mulch Type")
    )
    mulch_perc_ret = fields.CharField(
        max_length=50, blank=True, null=True, verbose_name=_("Mulch Percent Retained")
    )
    mulch_incorp = fields.CharField(
        max_length=50, blank=True, null=True, verbose_name=_("Mulch Incorporated")
    )
    mulch_freq = fields.CharField(
        max_length=50, blank=True, null=True, verbose_name=_("Mulch Frequency")
    )
    mulch_rate = fields.CharField(
        max_length=50, blank=True, null=True, verbose_name=_("Mulch Rate")
    )
    oa_type = fields.CharField(
        max_length=255,
        blank=True,
        null=True,
        verbose_name=_("Organic Amendment Type"),
    )
    oa_freq = fields.CharField(
        max_length=50,
        blank=True,
        null=True,
        verbose_name=_("Organic Amendment Frequency"),
    )
    oa_incorp = fields.CharField(
        max_length=50,
        blank=True,
        null=True,
        verbose_name=_("Organic Amendment Incorporated"),
    )
    oa_c_conc = fields.FloatField(
        blank=True, null=True, verbose_name=_("Organic Amendment C Concentration")
    )
    oa_n_conc = fields.FloatField(
        blank=True, null=True, verbose_name=_("Organic Amendment N Concentration")
    )
    oa_rate = fields.CharField(
        max_length=50,
        blank=True,
        null=True,
        verbose_name=_("Organic Amendment Rate"),
    )
    cons_till_yr1 = fields.TextField(
        blank=True, null=True, verbose_name=_("Conservation Tillage Year 1")
    )
    cons_till_yr2 = fields.TextField(
        blank=True, null=True, verbose_name=_("Conservation Tillage Year 2")
    )
    cons_till_yr3 = fields.TextField(
        blank=True, null=True, verbose_name=_("Conservation Tillage Year 3")
    )
    cons_till_yr4 = fields.TextField(
        blank=True, null=True, verbose_name=_("Conservation Tillage Year 4")
    )
    cons_till_yr5 = fields.TextField(
        blank=True, null=True, verbose_name=_("Conservation Tillage Year 5")
    )
    ripar_method = fields.CharField(
        max_length=255,
        blank=True,
        null=True,
        verbose_name=_("Riparian Method"),
    )
    wood_species_list = fields.TextField(
        blank=True, null=True, verbose_name=_("Wood Species List")
    )
    wood_replant_notes = fields.TextField(
        blank=True, null=True, verbose_name=_("Wood Replant Notes")
    )
    wood_pruning_notes = fields.TextField(
        blank=True, null=True, verbose_name=_("Wood Pruning Notes")
    )
    herb_type = fields.CharField(
        max_length=255, blank=True, null=True, verbose_name=_("Herbaceous Type")
    )
    herb_species_list = fields.TextField(
        blank=True, null=True, verbose_name=_("Herbaceous Species List")
    )
    herb_replant_notes = fields.TextField(
        blank=True, null=True, verbose_name=_("Herbaceous Replant Notes")
    )

    @property
    def related_farm(self):
        return {"@id": self.farm.urlid, "@type": self.farm._meta.rdf_type}

    class Meta(baseModel.Meta):
        verbose_name = _("Field Level")
        verbose_name_plural = _("Field Levels")
        container_path = "field-levels"
        rdf_type = "glcdi:FieldLevel"
        serializer_fields = baseModel.Meta.serializer_fields + [
            "related_farm",
            "project_id",
            "protocol",
            "submission_date",
            "cons_practice",
            "practice_year",
        ]
        unique_together = [["farm", "project_id"]]
