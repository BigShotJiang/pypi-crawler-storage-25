from djangoldp.models import DynamicNestedField

from .biomass_plot import *
from .biomass_point import *
from .farm import *
from .field_level import *
from .metric import *
from .plot import *
from .soil_sample import *

setattr(Farm, "metrics", lambda self: Metric.objects.filter(plot__farm=self))
getattr(Farm, "metrics").field = DynamicNestedField(Metric, "metrics")
