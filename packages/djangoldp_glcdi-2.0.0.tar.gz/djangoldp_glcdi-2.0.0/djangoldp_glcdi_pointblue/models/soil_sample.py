from django.db import models
from django.utils.translation import gettext_lazy as _
from djangoldp import fields

from djangoldp_glcdi_common.models.__base_model import baseModel


class SoilSample(baseModel):
    from_csv = fields.BooleanField(default=False, verbose_name=_("From CSV"))
    plot = fields.ForeignKey(
        "djangoldp_glcdi_pointblue.Plot",
        on_delete=models.CASCADE,
        related_name="soil_samples",
        verbose_name=_("Plot"),
    )
    timepoint = fields.CharField(
        max_length=10, blank=True, null=True, verbose_name=_("Timepoint")
    )
    sample_date = fields.DateField(
        blank=True, null=True, verbose_name=_("Sample Date")
    )
    target_depth = fields.CharField(
        max_length=50, blank=True, null=True, verbose_name=_("Target Depth")
    )
    b_depth = fields.FloatField(
        blank=True, null=True, verbose_name=_("Beginning Depth")
    )
    e_depth = fields.FloatField(
        blank=True, null=True, verbose_name=_("End Depth")
    )
    b_depth_mic_c = fields.FloatField(
        blank=True, null=True, verbose_name=_("Microbial C Beginning Depth")
    )
    e_depth_mic_c = fields.FloatField(
        blank=True, null=True, verbose_name=_("Microbial C End Depth")
    )
    b_depth_plfa = fields.FloatField(
        blank=True, null=True, verbose_name=_("PLFA Beginning Depth")
    )
    e_depth_plfa = fields.FloatField(
        blank=True, null=True, verbose_name=_("PLFA End Depth")
    )
    position = fields.CharField(
        max_length=50, blank=True, null=True, verbose_name=_("Sample Position")
    )
    lab_name = fields.CharField(
        max_length=100, blank=True, null=True, verbose_name=_("Lab Name")
    )
    c_method = fields.CharField(
        max_length=100, blank=True, null=True, verbose_name=_("C Method")
    )
    texture_name = fields.CharField(
        max_length=100, blank=True, null=True, verbose_name=_("Texture Name")
    )
    ph_method = fields.CharField(
        max_length=50, blank=True, null=True, verbose_name=_("pH Method")
    )
    bd_method = fields.CharField(
        max_length=50, blank=True, null=True, verbose_name=_("Bulk Density Method")
    )

    @property
    def related_plot(self):
        return {"@id": self.plot.urlid, "@type": self.plot._meta.rdf_type}

    class Meta(baseModel.Meta):
        verbose_name = _("Soil Sample")
        verbose_name_plural = _("Soil Samples")
        container_path = "soil-samples"
        rdf_type = "glcdi:SoilSample"
        serializer_fields = baseModel.Meta.serializer_fields + [
            "related_plot",
            "timepoint",
            "sample_date",
            "target_depth",
            "position",
            "lab_name",
            "c_method",
            "texture_name",
        ]
        nested_fields = baseModel.Meta.nested_fields + [
            "metrics",
        ]
        unique_together = [["plot", "timepoint", "target_depth"]]
