from django.db import models
from django.utils.translation import gettext_lazy as _
from djangoldp import fields

from djangoldp_glcdi_common.models.__base_model import baseModel


class Metric(baseModel):
    from_csv = fields.BooleanField(default=False, verbose_name=_("From CSV"))
    plot = fields.ForeignKey(
        "djangoldp_glcdi_pointblue.Plot",
        on_delete=models.CASCADE,
        related_name="metrics",
        verbose_name=_("Plot"),
        blank=True,
        null=True,
    )
    farm = fields.ForeignKey(
        "djangoldp_glcdi_pointblue.Farm",
        on_delete=models.CASCADE,
        related_name="farm_metrics",
        verbose_name=_("Farm"),
        blank=True,
        null=True,
    )
    soil_sample = fields.ForeignKey(
        "djangoldp_glcdi_pointblue.SoilSample",
        on_delete=models.CASCADE,
        related_name="metrics",
        verbose_name=_("Soil Sample"),
        blank=True,
        null=True,
    )
    biomass_plot = fields.ForeignKey(
        "djangoldp_glcdi_pointblue.BiomassPlot",
        on_delete=models.CASCADE,
        related_name="metrics",
        verbose_name=_("Biomass Plot"),
        blank=True,
        null=True,
    )
    biomass_point = fields.ForeignKey(
        "djangoldp_glcdi_pointblue.BiomassPoint",
        on_delete=models.CASCADE,
        related_name="metrics",
        verbose_name=_("Biomass Point"),
        blank=True,
        null=True,
    )
    metric_type = fields.CharField(max_length=50, verbose_name=_("Metric Type"))
    year = fields.IntegerField(
        verbose_name=_("Year"), blank=True, null=True
    )
    timepoint = fields.CharField(
        max_length=10, blank=True, null=True, verbose_name=_("Timepoint")
    )
    depth = fields.CharField(
        max_length=50, blank=True, null=True, verbose_name=_("Depth")
    )
    value = fields.FloatField(verbose_name=_("Value"), blank=True, null=True)

    @property
    def related_plot(self):
        if self.plot:
            return {"@id": self.plot.urlid, "@type": self.plot._meta.rdf_type}
        return None

    @property
    def related_farm(self):
        if self.farm:
            return {"@id": self.farm.urlid, "@type": self.farm._meta.rdf_type}
        return None

    @property
    def related_source(self):
        if self.soil_sample:
            return {"@id": self.soil_sample.urlid, "@type": self.soil_sample._meta.rdf_type}
        if self.biomass_plot:
            return {"@id": self.biomass_plot.urlid, "@type": self.biomass_plot._meta.rdf_type}
        if self.biomass_point:
            return {"@id": self.biomass_point.urlid, "@type": self.biomass_point._meta.rdf_type}
        return None

    class Meta(baseModel.Meta):
        verbose_name = _("Metric")
        verbose_name_plural = _("Metrics")
        container_path = "metrics"
        rdf_type = "glcdi:Metric"
        serializer_fields = baseModel.Meta.serializer_fields + [
            "related_plot",
            "related_farm",
            "related_source",
            "metric_type",
            "year",
            "timepoint",
            "depth",
            "value",
        ]
        unique_together = [
            [
                "plot",
                "farm",
                "soil_sample",
                "biomass_plot",
                "biomass_point",
                "metric_type",
                "year",
                "timepoint",
                "depth",
            ]
        ]
