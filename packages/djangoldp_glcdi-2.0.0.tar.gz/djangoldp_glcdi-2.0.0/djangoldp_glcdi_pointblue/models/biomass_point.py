from django.db import models
from django.utils.translation import gettext_lazy as _
from djangoldp import fields

from djangoldp_glcdi_common.models.__base_model import baseModel


class BiomassPoint(baseModel):
    from_csv = fields.BooleanField(default=False, verbose_name=_("From CSV"))
    plot = fields.ForeignKey(
        "djangoldp_glcdi_pointblue.Plot",
        on_delete=models.CASCADE,
        related_name="biomass_points",
        verbose_name=_("Plot"),
    )
    timepoint = fields.CharField(
        max_length=10, blank=True, null=True, verbose_name=_("Timepoint")
    )
    sample_date_ahb = fields.DateField(
        blank=True, null=True, verbose_name=_("AHB Sample Date")
    )
    ahb_plot_area = fields.FloatField(
        blank=True, null=True, verbose_name=_("AHB Plot Area")
    )
    sample_date_hrb = fields.DateField(
        blank=True, null=True, verbose_name=_("HRB Sample Date")
    )
    e_depth_hrb = fields.FloatField(
        blank=True, null=True, verbose_name=_("HRB End Depth")
    )
    awb_method = fields.CharField(
        max_length=50, blank=True, null=True, verbose_name=_("AWB Method")
    )
    sample_date_awb = fields.DateField(
        blank=True, null=True, verbose_name=_("AWB Sample Date")
    )
    tree_id = fields.CharField(
        max_length=500, blank=True, null=True, verbose_name=_("Tree Species")
    )
    avg_dist = fields.FloatField(
        blank=True, null=True, verbose_name=_("Average Tree Distance")
    )
    tree_presence = fields.FloatField(
        blank=True, null=True, verbose_name=_("Tree Presence")
    )

    @property
    def related_plot(self):
        return {"@id": self.plot.urlid, "@type": self.plot._meta.rdf_type}

    class Meta(baseModel.Meta):
        verbose_name = _("Point Biomass")
        verbose_name_plural = _("Point Biomass")
        container_path = "biomass-points"
        rdf_type = "glcdi:BiomassPoint"
        serializer_fields = baseModel.Meta.serializer_fields + [
            "related_plot",
            "timepoint",
            "sample_date_ahb",
            "sample_date_hrb",
            "awb_method",
            "tree_id",
        ]
        nested_fields = baseModel.Meta.nested_fields + [
            "metrics",
        ]
        unique_together = [["plot", "timepoint"]]
