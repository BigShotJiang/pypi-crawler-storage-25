from django.db import models
from django.utils.translation import gettext_lazy as _
from djangoldp import fields

from djangoldp_glcdi_common.models.__base_model import baseModel


class BiomassPlot(baseModel):
    from_csv = fields.BooleanField(default=False, verbose_name=_("From CSV"))
    farm = fields.ForeignKey(
        "djangoldp_glcdi_pointblue.Farm",
        on_delete=models.CASCADE,
        related_name="biomass_plots",
        verbose_name=_("Farm"),
    )
    timepoint = fields.CharField(
        max_length=10, blank=True, null=True, verbose_name=_("Timepoint")
    )
    plot_type = fields.CharField(
        max_length=10, blank=True, null=True, verbose_name=_("Plot Type")
    )
    sample_date_awb = fields.DateField(
        blank=True, null=True, verbose_name=_("AWB Sample Date")
    )
    awb_method = fields.CharField(
        max_length=50, blank=True, null=True, verbose_name=_("AWB Method")
    )
    awb_plot_area = fields.FloatField(
        blank=True, null=True, verbose_name=_("AWB Plot Area")
    )
    awb_radius = fields.FloatField(
        blank=True, null=True, verbose_name=_("AWB Radius")
    )
    hedge_area = fields.FloatField(
        blank=True, null=True, verbose_name=_("Hedge Area")
    )
    tree_id = fields.CharField(
        max_length=500, blank=True, null=True, verbose_name=_("Tree Species")
    )
    tree_density = fields.FloatField(
        blank=True, null=True, verbose_name=_("Tree Density")
    )

    @property
    def related_farm(self):
        return {"@id": self.farm.urlid, "@type": self.farm._meta.rdf_type}

    class Meta(baseModel.Meta):
        verbose_name = _("Field Biomass")
        verbose_name_plural = _("Field Biomass")
        container_path = "biomass-plots"
        rdf_type = "glcdi:BiomassPlot"
        serializer_fields = baseModel.Meta.serializer_fields + [
            "related_farm",
            "timepoint",
            "plot_type",
            "sample_date_awb",
            "awb_method",
            "tree_id",
        ]
        nested_fields = baseModel.Meta.nested_fields + [
            "metrics",
        ]
        unique_together = [["farm", "timepoint", "plot_type"]]
