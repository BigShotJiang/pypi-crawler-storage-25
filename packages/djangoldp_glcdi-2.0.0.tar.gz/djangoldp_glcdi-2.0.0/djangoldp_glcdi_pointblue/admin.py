from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from djangoldp.admin import DjangoLDPAdmin

from djangoldp_glcdi_pointblue.models import (
    BiomassPlot,
    BiomassPoint,
    Farm,
    FieldLevel,
    Metric,
    Plot,
    SoilSample,
)


class PlotInline(admin.TabularInline):
    model = Plot
    extra = 0
    fields = (
        "name",
        "latitude",
        "longitude",
        "land_cover",
        "grazing",
        "agroforest",
        "from_csv",
    )
    readonly_fields = ("from_csv",)


class MetricInline(admin.TabularInline):
    model = Metric
    extra = 0
    fields = ("metric_type", "year", "timepoint", "depth", "value", "from_csv")
    readonly_fields = ("created_at", "updated_at", "from_csv")


class SoilSampleInline(admin.TabularInline):
    model = SoilSample
    extra = 0
    fields = (
        "timepoint",
        "target_depth",
        "lab_name",
        "c_method",
        "texture_name",
        "from_csv",
    )
    readonly_fields = ("from_csv",)


class BiomassPointInline(admin.TabularInline):
    model = BiomassPoint
    extra = 0
    fields = ("timepoint", "awb_method", "tree_id", "from_csv")
    readonly_fields = ("from_csv",)


class PlotLandCoverFilter(admin.SimpleListFilter):
    title = _("Plot Land Cover")
    parameter_name = "plot_land_cover"

    def lookups(self, request, model_admin):
        land_covers = (
            Plot.objects.values_list("land_cover", flat=True)
            .filter(land_cover__isnull=False)
            .distinct()
        )
        return [(lc, lc) for lc in land_covers]

    def queryset(self, request, queryset):
        value = self.value()
        if value:
            return queryset.filter(plots__land_cover=value).distinct()
        return queryset


class PlotGrazingFilter(admin.SimpleListFilter):
    title = _("Plot Grazing")
    parameter_name = "plot_grazing"

    def lookups(self, request, model_admin):
        grazing_types = (
            Plot.objects.values_list("grazing", flat=True)
            .filter(grazing__isnull=False)
            .distinct()
        )
        return [(g, g) for g in grazing_types]

    def queryset(self, request, queryset):
        value = self.value()
        if value:
            return queryset.filter(plots__grazing=value).distinct()
        return queryset


class PlotAgroforestFilter(admin.SimpleListFilter):
    title = _("Plot Agroforest")
    parameter_name = "plot_agroforest"

    def lookups(self, request, model_admin):
        agroforest_types = (
            Plot.objects.values_list("agroforest", flat=True)
            .filter(agroforest__isnull=False)
            .distinct()
        )
        return [(af, af) for af in agroforest_types]

    def queryset(self, request, queryset):
        value = self.value()
        if value:
            return queryset.filter(plots__agroforest=value).distinct()
        return queryset


@admin.register(Farm)
class FarmAdmin(DjangoLDPAdmin):
    list_display = (
        "name",
        "urlid",
        "plot_count",
        "from_csv",
        "created_at",
        "updated_at",
    )
    list_filter = (
        "created_at",
        "updated_at",
        "from_csv",
        PlotLandCoverFilter,
        PlotGrazingFilter,
        PlotAgroforestFilter,
    )
    search_fields = ("name", "urlid")
    readonly_fields = ("created_at", "updated_at", "from_csv")
    exclude = ("is_backlink", "allow_create_backlink")
    inlines = [PlotInline]
    fieldsets = (
        (None, {"fields": ("name", "from_csv")}),
        ("Timestamps", {"fields": ("created_at", "updated_at")}),
    )

    def plot_count(self, obj):
        return obj.plots.count()

    plot_count.short_description = _("Number of Plots")


@admin.register(Plot)
class PlotAdmin(DjangoLDPAdmin):
    list_display = (
        "name",
        "farm",
        "latitude",
        "longitude",
        "land_cover",
        "from_csv",
        "created_at",
    )
    list_filter = (
        "farm",
        "land_cover",
        "grazing",
        "agroforest",
        "from_csv",
        "created_at",
    )
    search_fields = ("name", "urlid", "farm__name")
    readonly_fields = ("created_at", "updated_at", "from_csv")
    exclude = ("is_backlink", "allow_create_backlink")
    inlines = [MetricInline, SoilSampleInline, BiomassPointInline]
    fieldsets = (
        (None, {"fields": ("name", "farm")}),
        ("Location", {"fields": ("latitude", "longitude")}),
        ("Properties", {"fields": ("land_cover", "grazing", "agroforest", "from_csv")}),
        ("Timestamps", {"fields": ("created_at", "updated_at")}),
    )


@admin.register(Metric)
class MetricAdmin(DjangoLDPAdmin):
    list_display = (
        "plot",
        "farm",
        "metric_type",
        "year",
        "timepoint",
        "depth",
        "value",
        "from_csv",
        "created_at",
    )
    list_filter = (
        "metric_type",
        "year",
        "timepoint",
        "plot__farm",
        "farm",
        "from_csv",
        "created_at",
    )
    search_fields = ("metric_type", "plot__name", "plot__farm__name", "farm__name")
    readonly_fields = ("created_at", "updated_at", "from_csv")
    exclude = ("is_backlink", "allow_create_backlink")
    fieldsets = (
        (
            None,
            {
                "fields": (
                    "plot",
                    "farm",
                    "metric_type",
                    "year",
                    "timepoint",
                    "depth",
                    "value",
                    "from_csv",
                )
            },
        ),
        ("Timestamps", {"fields": ("created_at", "updated_at")}),
    )


@admin.register(SoilSample)
class SoilSampleAdmin(DjangoLDPAdmin):
    list_display = (
        "plot",
        "timepoint",
        "target_depth",
        "lab_name",
        "c_method",
        "from_csv",
        "created_at",
    )
    list_filter = ("timepoint", "lab_name", "c_method", "from_csv", "created_at")
    search_fields = ("plot__name", "plot__farm__name", "lab_name")
    readonly_fields = ("created_at", "updated_at", "from_csv")
    exclude = ("is_backlink", "allow_create_backlink")
    fieldsets = (
        (None, {"fields": ("plot", "timepoint", "sample_date", "target_depth")}),
        (
            "Depth Info",
            {
                "fields": (
                    "b_depth",
                    "e_depth",
                    "b_depth_mic_c",
                    "e_depth_mic_c",
                    "b_depth_plfa",
                    "e_depth_plfa",
                )
            },
        ),
        (
            "Lab Info",
            {
                "fields": (
                    "position",
                    "lab_name",
                    "c_method",
                    "texture_name",
                    "ph_method",
                    "bd_method",
                )
            },
        ),
        ("Meta", {"fields": ("from_csv",)}),
        ("Timestamps", {"fields": ("created_at", "updated_at")}),
    )


@admin.register(FieldLevel)
class FieldLevelAdmin(DjangoLDPAdmin):
    list_display = (
        "farm",
        "project_id",
        "protocol",
        "cons_practice",
        "practice_year",
        "from_csv",
        "created_at",
    )
    list_filter = ("protocol", "practice_year", "from_csv", "created_at")
    search_fields = ("farm__name", "project_id", "cons_practice")
    readonly_fields = ("created_at", "updated_at", "from_csv")
    exclude = ("is_backlink", "allow_create_backlink")
    fieldsets = (
        (
            None,
            {
                "fields": (
                    "farm",
                    "project_id",
                    "protocol",
                    "submission_date",
                    "cons_practice",
                    "practice_year",
                    "from_csv",
                )
            },
        ),
        (
            "Historical Management",
            {
                "fields": (
                    "hist_currentlu_yrs",
                    "hist_currentman_yrs",
                    "hist_flood_yr",
                    "hist_fire_yr",
                    "hist_irr_yn",
                    "hist_pest_yn",
                    "hist_herb_yn",
                    "hist_crop_yrs",
                )
            },
        ),
        (
            "Historical Livestock",
            {
                "fields": (
                    "hist_ls_type",
                    "hist_ls_utilization",
                    "hist_ls_season_start",
                    "hist_ls_season_end",
                    "hist_ls_paddocks",
                    "hist_ls_resttime",
                    "hist_ls_ada",
                    "hist_crop_details",
                )
            },
        ),
        (
            "Historical Tillage",
            {
                "fields": (
                    "till_hist_yr0",
                    "till_hist_yr1",
                    "till_hist_yr2",
                    "till_hist_yr3",
                    "till_hist_yr4",
                    "hist_notes",
                )
            },
        ),
        ("Planned Crop Rotation", {"fields": ("cr_desc", "cr_list")}),
        (
            "Planned Livestock",
            {
                "fields": (
                    "ls_type",
                    "ls_utilization",
                    "ls_season_start",
                    "ls_season_end",
                    "ls_paddocks",
                    "ls_rest_time",
                    "ls_ada",
                    "ls_notes",
                )
            },
        ),
        ("Conversion Plan", {"fields": ("conv_plan_notes",)}),
        (
            "Mulch",
            {
                "fields": (
                    "mulch_ret_app",
                    "mulch_type",
                    "mulch_perc_ret",
                    "mulch_incorp",
                    "mulch_freq",
                    "mulch_rate",
                )
            },
        ),
        (
            "Organic Amendment",
            {
                "fields": (
                    "oa_type",
                    "oa_freq",
                    "oa_incorp",
                    "oa_c_conc",
                    "oa_n_conc",
                    "oa_rate",
                )
            },
        ),
        (
            "Conservation Tillage",
            {
                "fields": (
                    "cons_till_yr1",
                    "cons_till_yr2",
                    "cons_till_yr3",
                    "cons_till_yr4",
                    "cons_till_yr5",
                )
            },
        ),
        (
            "Riparian",
            {
                "fields": (
                    "ripar_method",
                    "wood_species_list",
                    "wood_replant_notes",
                    "wood_pruning_notes",
                )
            },
        ),
        (
            "Herbaceous",
            {"fields": ("herb_type", "herb_species_list", "herb_replant_notes")},
        ),
        ("Timestamps", {"fields": ("created_at", "updated_at")}),
    )


@admin.register(BiomassPlot)
class BiomassPlotAdmin(DjangoLDPAdmin):
    list_display = (
        "farm",
        "timepoint",
        "plot_type",
        "awb_method",
        "from_csv",
        "created_at",
    )
    list_filter = ("timepoint", "plot_type", "awb_method", "from_csv", "created_at")
    search_fields = ("farm__name", "tree_id")
    readonly_fields = ("created_at", "updated_at", "from_csv")
    exclude = ("is_backlink", "allow_create_backlink")
    fieldsets = (
        (None, {"fields": ("farm", "timepoint", "plot_type", "from_csv")}),
        (
            "Woody Biomass",
            {
                "fields": (
                    "sample_date_awb",
                    "awb_method",
                    "awb_plot_area",
                    "awb_radius",
                    "hedge_area",
                    "tree_id",
                    "tree_density",
                )
            },
        ),
        ("Timestamps", {"fields": ("created_at", "updated_at")}),
    )


@admin.register(BiomassPoint)
class BiomassPointAdmin(DjangoLDPAdmin):
    list_display = ("plot", "timepoint", "awb_method", "from_csv", "created_at")
    list_filter = ("timepoint", "awb_method", "from_csv", "created_at")
    search_fields = ("plot__name", "plot__farm__name", "tree_id")
    readonly_fields = ("created_at", "updated_at", "from_csv")
    exclude = ("is_backlink", "allow_create_backlink")
    fieldsets = (
        (None, {"fields": ("plot", "timepoint", "from_csv")}),
        ("Herbaceous Biomass", {"fields": ("sample_date_ahb", "ahb_plot_area")}),
        ("Root Biomass", {"fields": ("sample_date_hrb", "e_depth_hrb")}),
        (
            "Woody Biomass",
            {
                "fields": (
                    "sample_date_awb",
                    "awb_method",
                    "tree_id",
                    "avg_dist",
                    "tree_presence",
                )
            },
        ),
        ("Timestamps", {"fields": ("created_at", "updated_at")}),
    )
