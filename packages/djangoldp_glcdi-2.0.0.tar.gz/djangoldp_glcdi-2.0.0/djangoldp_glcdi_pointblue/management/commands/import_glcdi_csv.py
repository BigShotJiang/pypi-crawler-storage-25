import csv
import os
import re
from datetime import datetime

from django.core.management.base import BaseCommand
from django.db import models, transaction

from djangoldp_glcdi_pointblue.models import (
    BiomassPlot,
    BiomassPoint,
    Farm,
    FieldLevel,
    Metric,
    Plot,
    SoilSample,
)

POINT_LEVEL_METRIC_COLUMNS = [
    "total_c",
    "total_n",
    "org_c",
    "inorg_c",
    "pom",
    "poc",
    "pon",
    "maom",
    "maoc",
    "maon",
    "co2_resp_ppm",
    "microbial_c",
    "sand",
    "silt",
    "clay",
    "ph",
    "buffer_ph",
    "bulk_density",
    "rocks_g",
    "no3_ppm",
    "p_ppm",
    "k_ppm",
    "s_ppm",
    "ca_ppm",
    "mg_ppm",
    "na_ppm",
    "zn_ppm",
    "fe_ppm",
    "mn_ppm",
    "cu_ppm",
    "soil_moisture",
    "sol_salts",
    "cec",
    "cec_h_perc",
    "cec_k_perc",
    "cec_ca_perc",
    "cec_mg_perc",
    "cec_na_perc",
]

POINT_BIOMASS_METRIC_COLUMNS = [
    "ahb_bio",
    "hrb_fine",
    "hrb_coarse",
    "hrb_total",
    "awb_mean",
    "bwb_mean",
]

FIELD_BIOMASS_METRIC_COLUMNS = [
    "awb",
    "bwb",
]

FIELD_LEVEL_DATE_COLUMNS = [
    "submission_date",
]

POINT_LEVEL_DATE_COLUMNS = [
    "sample_date",
]

POINT_BIOMASS_DATE_COLUMNS = [
    "sample_date_ahb",
    "sample_date_hrb",
    "sample_date_awb",
]

FIELD_BIOMASS_DATE_COLUMNS = [
    "sample_date_awb",
]


class Command(BaseCommand):
    help = "Import GLCDI Point Blue data from CSV file"

    def add_arguments(self, parser):
        parser.add_argument(
            "csv_file",
            type=str,
            help="Path to CSV file to import",
        )

    def handle(self, *args, **options):
        csv_file = options["csv_file"]

        if not os.path.exists(csv_file):
            self.stderr.write(self.style.ERROR(f"File not found: {csv_file}"))
            return

        csv_type = self._detect_csv_type(csv_file)

        if csv_type == "pointlevel":
            self._handle_pointlevel(csv_file)
        elif csv_type == "fieldlevel":
            self._handle_fieldlevel(csv_file)
        elif csv_type == "fieldbiomass":
            self._handle_fieldbiomass(csv_file)
        elif csv_type == "pointbiomass":
            self._handle_pointbiomass(csv_file)
        else:
            self._handle_legacy(csv_file)

    def _detect_csv_type(self, csv_file):
        filename = os.path.basename(csv_file).upper()
        if "POINTLEVEL" in filename:
            return "pointlevel"
        if "FIELDLEVEL" in filename:
            return "fieldlevel"
        if "FIELDBIOMASS" in filename:
            return "fieldbiomass"
        if "POINTBIOMASS" in filename:
            return "pointbiomass"
        return None

    def _get_farm(self, project_id):
        farm, created = Farm.objects.get_or_create(
            name=project_id,
            defaults={"from_csv": True},
        )
        return farm, created

    def _get_plot(self, farm, sample_id, lat, long):
        defaults = {"from_csv": True}
        if lat is not None:
            defaults["latitude"] = lat
        if long is not None:
            defaults["longitude"] = long

        plot, created = Plot.objects.get_or_create(
            farm=farm,
            name=sample_id,
            defaults=defaults,
        )
        return plot, created

    def _parse_float(self, value):
        if value is None or value == "":
            return None
        value = str(value).strip()
        if value.upper() == "NA":
            return None
        try:
            return float(value)
        except (ValueError, TypeError):
            return None

    def _parse_int(self, value):
        f = self._parse_float(value)
        if f is not None:
            try:
                return int(f)
            except (ValueError, OverflowError):
                return None
        return None

    def _parse_date(self, value):
        if value is None or value == "":
            return None
        value = str(value).strip()
        if value.upper() == "NA":
            return None
        for fmt in ["%m/%d/%Y %H:%M", "%m/%d/%Y", "%Y-%m-%d", "%Y-%m-%d %H:%M:%S"]:
            try:
                return datetime.strptime(value, fmt).date()
            except ValueError:
                continue
        return None

    def _extract_year(self, date_val):
        if date_val and hasattr(date_val, "year"):
            return date_val.year
        return None

    def _create_metric(
        self,
        plot=None,
        farm=None,
        soil_sample=None,
        biomass_plot=None,
        biomass_point=None,
        metric_type="",
        year=None,
        timepoint=None,
        depth=None,
        value=None,
    ):
        if value is None:
            return None, False
        metric, created = Metric.objects.get_or_create(
            plot=plot,
            farm=farm,
            soil_sample=soil_sample,
            biomass_plot=biomass_plot,
            biomass_point=biomass_point,
            metric_type=metric_type,
            year=year,
            timepoint=timepoint,
            depth=depth,
            defaults={"value": value, "from_csv": True},
        )
        if not created and value is not None:
            metric.value = value
            metric.save()
        return metric, created

    def _open_csv(self, csv_file):
        f = open(csv_file, "r", encoding="utf-8-sig")
        sample = f.read(8192)
        f.seek(0)
        sniffer = csv.Sniffer()
        try:
            dialect = sniffer.sniff(sample)
        except csv.Error:
            dialect = csv.excel
        reader = csv.DictReader(f, dialect=dialect)
        if not reader.fieldnames:
            self.stderr.write(self.style.ERROR("CSV file has no headers"))
            f.close()
            return None, None
        return f, reader

    def _handle_pointlevel(self, csv_file):
        self.stdout.write(f"Importing PointLevel data from {csv_file}...")

        f, reader = self._open_csv(csv_file)
        if reader is None:
            return

        headers = reader.fieldnames
        self.stdout.write(f"Found columns: {', '.join(headers)}")

        with transaction.atomic():
            created_farms = 0
            created_plots = 0
            created_samples = 0
            created_metrics = 0
            skipped_rows = 0

            for row_num, row in enumerate(reader, start=2):
                try:
                    project_id = (row.get("project_id") or "").strip()
                    sample_id = (row.get("sample_id") or "").strip()
                    timepoint = (row.get("timepoint") or "").strip() or None
                    lat = self._parse_float(row.get("lat"))
                    long = self._parse_float(row.get("long"))
                    sample_date = self._parse_date(row.get("sample_date"))
                    target_depth = (row.get("target_depth") or "").strip() or None

                    if not project_id or not sample_id:
                        skipped_rows += 1
                        continue

                    farm, farm_created = self._get_farm(project_id)
                    if farm_created:
                        created_farms += 1

                    plot, plot_created = self._get_plot(farm, sample_id, lat, long)
                    if plot_created:
                        created_plots += 1

                    sample, sample_created = SoilSample.objects.get_or_create(
                        plot=plot,
                        timepoint=timepoint,
                        target_depth=target_depth,
                        defaults={
                            "from_csv": True,
                            "sample_date": sample_date,
                            "b_depth": self._parse_float(row.get("b_depth")),
                            "e_depth": self._parse_float(row.get("e_depth")),
                            "b_depth_mic_c": self._parse_float(
                                row.get("b_depth_mic_c")
                            ),
                            "e_depth_mic_c": self._parse_float(
                                row.get("e_depth_mic_c")
                            ),
                            "b_depth_plfa": self._parse_float(row.get("b_depth_plfa")),
                            "e_depth_plfa": self._parse_float(row.get("e_depth_plfa")),
                            "position": (row.get("position") or "").strip() or None,
                            "lab_name": (row.get("lab_name") or "").strip() or None,
                            "c_method": (row.get("c_method") or "").strip() or None,
                            "texture_name": (row.get("texture_name") or "").strip()
                            or None,
                            "ph_method": (row.get("ph_method") or "").strip() or None,
                            "bd_method": (row.get("bd_method") or "").strip() or None,
                        },
                    )
                    if sample_created:
                        created_samples += 1

                    year = self._extract_year(sample_date)

                    for col in POINT_LEVEL_METRIC_COLUMNS:
                        val = self._parse_float(row.get(col))
                        _, mc = self._create_metric(
                            plot=plot,
                            farm=farm,
                            soil_sample=sample,
                            metric_type=col,
                            year=year,
                            timepoint=timepoint,
                            depth=target_depth,
                            value=val,
                        )
                        if mc:
                            created_metrics += 1

                except Exception as e:
                    self.stderr.write(
                        self.style.WARNING(f"PointLevel row {row_num} error: {e}")
                    )

        self.stdout.write(self.style.SUCCESS("\nPointLevel import summary:"))
        self.stdout.write(f"  Farms created: {created_farms}")
        self.stdout.write(f"  Plots created: {created_plots}")
        self.stdout.write(f"  Soil samples created: {created_samples}")
        self.stdout.write(f"  Metrics created: {created_metrics}")
        self.stdout.write(f"  Rows skipped: {skipped_rows}")
        f.close()

    def _handle_fieldlevel(self, csv_file):
        self.stdout.write(f"Importing FieldLevel data from {csv_file}...")

        f, reader = self._open_csv(csv_file)
        if reader is None:
            return

        headers = reader.fieldnames
        self.stdout.write(f"Found columns: {', '.join(headers)}")

        field_names = [
            f.name
            for f in FieldLevel._meta.get_fields()
            if f.name
            not in (
                "id",
                "urlid",
                "created_at",
                "updated_at",
                "from_csv",
                "is_backlink",
                "allow_create_backlink",
                "farm",
            )
        ]

        with transaction.atomic():
            created_farms = 0
            created_records = 0
            skipped_rows = 0

            for row_num, row in enumerate(reader, start=2):
                try:
                    project_id = (row.get("project_id") or "").strip()
                    if not project_id:
                        skipped_rows += 1
                        continue

                    farm, farm_created = self._get_farm(project_id)
                    if farm_created:
                        created_farms += 1

                    defaults = {"from_csv": True}
                    for fname in field_names:
                        if fname in row:
                            val = row[fname]
                            if val is not None:
                                val = str(val).strip()
                                if val == "" or val.upper() == "NA":
                                    val = None
                            field = FieldLevel._meta.get_field(fname)
                            if val is not None:
                                if isinstance(field, models.DateField):
                                    val = self._parse_date(val)
                                elif isinstance(field, models.IntegerField):
                                    val = self._parse_int(val)
                                elif isinstance(field, models.FloatField):
                                    val = self._parse_float(val)
                            defaults[fname] = val

                    record, created = FieldLevel.objects.get_or_create(
                        farm=farm,
                        project_id=project_id,
                        defaults=defaults,
                    )
                    if created:
                        created_records += 1
                    else:
                        for fname in field_names:
                            setattr(record, fname, defaults.get(fname))
                        record.save()

                except Exception as e:
                    self.stderr.write(
                        self.style.WARNING(f"FieldLevel row {row_num} error: {e}")
                    )

        self.stdout.write(self.style.SUCCESS("\nFieldLevel import summary:"))
        self.stdout.write(f"  Farms created: {created_farms}")
        self.stdout.write(f"  FieldLevel records created: {created_records}")
        self.stdout.write(f"  Rows skipped: {skipped_rows}")
        f.close()

    def _handle_fieldbiomass(self, csv_file):
        self.stdout.write(f"Importing FieldBiomass data from {csv_file}...")

        f, reader = self._open_csv(csv_file)
        if reader is None:
            return

        headers = reader.fieldnames
        self.stdout.write(f"Found columns: {', '.join(headers)}")

        with transaction.atomic():
            created_farms = 0
            created_records = 0
            created_metrics = 0
            skipped_rows = 0

            for row_num, row in enumerate(reader, start=2):
                try:
                    project_id = (row.get("project_id") or "").strip()
                    timepoint = (row.get("timepoint") or "").strip() or None
                    plot_type = (row.get("plot_type") or "").strip() or None
                    sample_date_awb = self._parse_date(row.get("sample_date_awb"))

                    if not project_id:
                        skipped_rows += 1
                        continue

                    farm, farm_created = self._get_farm(project_id)
                    if farm_created:
                        created_farms += 1

                    record, created = BiomassPlot.objects.get_or_create(
                        farm=farm,
                        timepoint=timepoint,
                        plot_type=plot_type,
                        defaults={
                            "from_csv": True,
                            "sample_date_awb": sample_date_awb,
                            "awb_method": (row.get("awb_method") or "").strip() or None,
                            "awb_plot_area": self._parse_float(
                                row.get("awb_plot_area")
                            ),
                            "awb_radius": self._parse_float(row.get("awb_radius")),
                            "hedge_area": self._parse_float(row.get("hedge_area")),
                            "tree_id": (row.get("tree_id") or "").strip() or None,
                            "tree_density": self._parse_float(row.get("tree_density")),
                        },
                    )
                    if created:
                        created_records += 1
                    else:
                        record.sample_date_awb = sample_date_awb
                        record.awb_method = (
                            row.get("awb_method") or ""
                        ).strip() or None
                        record.awb_plot_area = self._parse_float(
                            row.get("awb_plot_area")
                        )
                        record.awb_radius = self._parse_float(row.get("awb_radius"))
                        record.hedge_area = self._parse_float(row.get("hedge_area"))
                        record.tree_id = (row.get("tree_id") or "").strip() or None
                        record.tree_density = self._parse_float(row.get("tree_density"))
                        record.save()

                    year = self._extract_year(sample_date_awb)

                    for col in FIELD_BIOMASS_METRIC_COLUMNS:
                        metric_type = f"{col}_{plot_type}" if plot_type else col
                        val = self._parse_float(row.get(col))
                        _, mc = self._create_metric(
                            farm=farm,
                            biomass_plot=record,
                            metric_type=metric_type,
                            year=year,
                            timepoint=timepoint,
                            value=val,
                        )
                        if mc:
                            created_metrics += 1

                except Exception as e:
                    self.stderr.write(
                        self.style.WARNING(f"FieldBiomass row {row_num} error: {e}")
                    )

        self.stdout.write(self.style.SUCCESS("\nFieldBiomass import summary:"))
        self.stdout.write(f"  Farms created: {created_farms}")
        self.stdout.write(f"  BiomassPlot records created: {created_records}")
        self.stdout.write(f"  Metrics created: {created_metrics}")
        self.stdout.write(f"  Rows skipped: {skipped_rows}")
        f.close()

    def _handle_pointbiomass(self, csv_file):
        self.stdout.write(f"Importing PointBiomass data from {csv_file}...")

        f, reader = self._open_csv(csv_file)
        if reader is None:
            return

        headers = reader.fieldnames

        self.stdout.write(f"Found columns: {', '.join(headers)}")

        with transaction.atomic():
            created_farms = 0
            created_plots = 0
            created_records = 0
            created_metrics = 0
            skipped_rows = 0

            for row_num, row in enumerate(reader, start=2):
                try:
                    project_id = (row.get("project_id") or "").strip()
                    sample_id = (row.get("sample_id") or "").strip()
                    timepoint = (row.get("timepoint") or "").strip() or None

                    if not project_id or not sample_id:
                        skipped_rows += 1
                        continue

                    farm, farm_created = self._get_farm(project_id)
                    if farm_created:
                        created_farms += 1

                    plot, plot_created = self._get_plot(farm, sample_id, None, None)
                    if plot_created:
                        created_plots += 1

                    sample_date_ahb = self._parse_date(row.get("sample_date_ahb"))
                    sample_date_hrb = self._parse_date(row.get("sample_date_hrb"))
                    sample_date_awb = self._parse_date(row.get("sample_date_awb"))
                    e_depth_hrb = self._parse_float(row.get("e_depth_hrb"))

                    record, created = BiomassPoint.objects.get_or_create(
                        plot=plot,
                        timepoint=timepoint,
                        defaults={
                            "from_csv": True,
                            "sample_date_ahb": sample_date_ahb,
                            "ahb_plot_area": self._parse_float(
                                row.get("ahb_plot_area")
                            ),
                            "sample_date_hrb": sample_date_hrb,
                            "e_depth_hrb": e_depth_hrb,
                            "awb_method": (row.get("awb_method") or "").strip() or None,
                            "sample_date_awb": sample_date_awb,
                            "tree_id": (row.get("tree_id") or "").strip() or None,
                            "avg_dist": self._parse_float(row.get("avg_dist")),
                            "tree_presence": self._parse_float(
                                row.get("tree_presence")
                            ),
                        },
                    )
                    if created:
                        created_records += 1
                    else:
                        record.sample_date_ahb = sample_date_ahb
                        record.ahb_plot_area = self._parse_float(
                            row.get("ahb_plot_area")
                        )
                        record.sample_date_hrb = sample_date_hrb
                        record.e_depth_hrb = e_depth_hrb
                        record.awb_method = (
                            row.get("awb_method") or ""
                        ).strip() or None
                        record.sample_date_awb = sample_date_awb
                        record.tree_id = (row.get("tree_id") or "").strip() or None
                        record.avg_dist = self._parse_float(row.get("avg_dist"))
                        record.tree_presence = self._parse_float(
                            row.get("tree_presence")
                        )
                        record.save()

                    year = self._extract_year(sample_date_hrb or sample_date_ahb)

                    for col in POINT_BIOMASS_METRIC_COLUMNS:
                        val = self._parse_float(row.get(col))
                        depth = None
                        if col.startswith("hrb") and e_depth_hrb is not None:
                            depth = f"0-{int(e_depth_hrb)}"
                        _, mc = self._create_metric(
                            plot=plot,
                            farm=farm,
                            biomass_point=record,
                            metric_type=col,
                            year=year,
                            timepoint=timepoint,
                            depth=depth,
                            value=val,
                        )
                        if mc:
                            created_metrics += 1

                except Exception as e:
                    self.stderr.write(
                        self.style.WARNING(f"PointBiomass row {row_num} error: {e}")
                    )

        self.stdout.write(self.style.SUCCESS("\nPointBiomass import summary:"))
        self.stdout.write(f"  Farms created: {created_farms}")
        self.stdout.write(f"  Plots created: {created_plots}")
        self.stdout.write(f"  BiomassPoint records created: {created_records}")
        self.stdout.write(f"  Metrics created: {created_metrics}")
        self.stdout.write(f"  Rows skipped: {skipped_rows}")
        f.close()

    def _handle_legacy(self, csv_file):
        self.stdout.write(f"Importing legacy GLCDI data from {csv_file}...")

        try:
            with open(csv_file, "r", encoding="utf-8-sig") as f:
                reader = csv.DictReader(f, delimiter=";")

                if not reader.fieldnames:
                    self.stderr.write(self.style.ERROR("CSV file has no headers"))
                    return

                headers = reader.fieldnames
                self.stdout.write(f"Found columns: {', '.join(headers)}")

                static_columns = [
                    "latitude",
                    "longitude",
                    "farm",
                    "Name",
                    "Land_Cover",
                    "Grazing",
                    "Agroforest",
                ]

                metric_pattern = re.compile(
                    r"^(?P<type>[A-Za-z_]+(?:_[A-Za-z0-9]+)*)_(?P<year>\d{4})$"
                )

                with transaction.atomic():
                    created_farms = 0
                    created_plots = 0
                    updated_plots = 0
                    created_metrics = 0
                    updated_metrics = 0
                    skipped_rows = 0

                    for row_num, row in enumerate(reader, start=2):
                        try:
                            latitude = self._parse_float(row.get("latitude"))
                            longitude = self._parse_float(row.get("longitude"))

                            if latitude is None or longitude is None:
                                skipped_rows += 1
                                continue

                            farm_name = row.get("farm") or ""
                            plot_name = row.get("Name") or ""
                            land_cover = row.get("Land_Cover") or ""
                            grazing = row.get("Grazing") or ""
                            agroforest = row.get("Agroforest") or ""

                            if not farm_name:
                                skipped_rows += 1
                                continue

                            farm, farm_created = Farm.objects.get_or_create(
                                name=farm_name,
                                defaults={"from_csv": True},
                            )

                            if farm_created:
                                created_farms += 1

                            plot, plot_created = Plot.objects.get_or_create(
                                farm=farm,
                                name=plot_name,
                                latitude=latitude,
                                longitude=longitude,
                                defaults={
                                    "land_cover": land_cover,
                                    "grazing": grazing,
                                    "agroforest": agroforest,
                                    "from_csv": True,
                                },
                            )

                            if plot_created:
                                created_plots += 1
                            else:
                                plot.land_cover = land_cover
                                plot.grazing = grazing
                                plot.agroforest = agroforest
                                plot.save()
                                updated_plots += 1

                            for key, value in row.items():
                                if key in static_columns:
                                    continue

                                match = metric_pattern.match(key)
                                if match:
                                    metric_type = match.group("type")
                                    year_str = match.group("year")

                                    try:
                                        year = int(year_str)
                                        metric_value = self._parse_float(value)

                                        if metric_value is not None:
                                            metric, metric_created = (
                                                Metric.objects.get_or_create(
                                                    plot=plot,
                                                    metric_type=metric_type,
                                                    year=year,
                                                    defaults={
                                                        "value": metric_value,
                                                        "from_csv": True,
                                                    },
                                                )
                                            )

                                            if metric_created:
                                                created_metrics += 1
                                            else:
                                                metric.value = metric_value
                                                metric.save()
                                                updated_metrics += 1
                                    except ValueError:
                                        continue

                        except Exception as e:
                            self.stderr.write(
                                self.style.WARNING(f"Row {row_num} error: {e}")
                            )

        except Exception as e:
            self.stderr.write(self.style.ERROR(f"Error reading CSV: {e}"))
            return

        self.stdout.write(self.style.SUCCESS("\nImport summary:"))
        self.stdout.write(f"  Farms created: {created_farms}")
        self.stdout.write(f"  Plots created: {created_plots}")
        self.stdout.write(f"  Plots updated: {updated_plots}")
        self.stdout.write(f"  Metrics created: {created_metrics}")
        self.stdout.write(f"  Metrics updated: {updated_metrics}")
        self.stdout.write(f"  Rows skipped: {skipped_rows}")
