# DjangoLDP GLCDI

This is a Django package for the GLCDI ecosystem, providing models and tools for GLCDI applications.

## Packages

This project is split into multiple packages:

### `djangoldp_glcdi_common` (required)

Base package that every participant must use. It provides shared abstract base models used across all GLCDI implementations.

### `djangoldp_glcdi` (Caney Fork Farm)

Generic approach that can import data from Caney Fork Farm CSV files. It provides models for farms, plots, and metrics.

### `djangoldp_glcdi_pointblue` (Point Blue)

Specific data structure for Point Blue. It includes dedicated models for biomass (plots and points), soil samples, field levels, and handles the timepoint concept.

## Configuration

Every participant must first add `djangoldp_glcdi_common` to their `INSTALLED_APPS`, then choose the appropriate data package:

```yaml
dependencies:
  - djangoldp-account
  - django-webidoidc-provider
  - djangoldp-glcdi
  # ...

ldppackages:
  - rest_framework
  - oidc_provider
  - djangoldp_account
  - djangoldp_glcdi_common
  - djangoldp_glcdi          # or djangoldp_glcdi_pointblue
  # ...

# [...]
```

### Importing Caney Farm CSV Data (djangoldp_glcdi)

Import data from a Caney Fork Farm CSV file using the management command:

```bash
python manage.py import_glcdi_csv path/to/file.csv
```

This command parses CSV to create or update farms and importing their metadata and metrics.

### Importing Point Blue CSV Data (djangoldp_glcdi_pointblue)

Import data from Point Blue CSV files using the management command:

```bash
python manage.py import_glcdi_csv path/to/FieldBiomass_file.csv
python manage.py import_glcdi_csv path/to/FieldLevel_file.csv
python manage.py import_glcdi_csv path/to/PointBiomass_file.csv
python manage.py import_glcdi_csv path/to/PointLevel_file.csv
```

This command parses CSV to create or update farms and importing their metadata and metrics.

This import process does require `FieldBiomass`, `FieldLevel`, `PointBiomass`, and `PointLevel` CSV files to be provided. The order of the files does not matter.

### Filter metrics of a farm

You can filter metrics of a farm using the `search-fields`, `search-terms`, and `search-method` query parameters. For example:

```bash
http://localhost:8000/farms/1/metrics/?search-fields=metric_type&search-terms=TC_30&search-method=exact
```

This will return all metrics of the farm `1` with the metric type `TC_30`.
