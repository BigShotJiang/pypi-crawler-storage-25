from django.apps import AppConfig


class DjangoldpGlcdiConfig(AppConfig):
    name = "djangoldp_glcdi"
