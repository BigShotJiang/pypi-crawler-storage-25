import csv
import os
import re

from django.core.management.base import BaseCommand
from django.db import transaction

from djangoldp_glcdi.models import Farm, Metric, Plot


class Command(BaseCommand):
    help = "Import GLCDI data from CSV file"

    def add_arguments(self, parser):
        parser.add_argument(
            "csv_file",
            type=str,
            help="Path to CSV file to import",
        )

    def handle(self, *args, **options):
        csv_file = options["csv_file"]

        if not os.path.exists(csv_file):
            self.stderr.write(self.style.ERROR(f"File not found: {csv_file}"))
            return

        self.stdout.write(f"Importing data from {csv_file}...")

        try:
            with open(csv_file, "r", encoding="utf-8-sig") as f:
                reader = csv.DictReader(f, delimiter=";")

                if not reader.fieldnames:
                    self.stderr.write(self.style.ERROR("CSV file has no headers"))
                    return

                headers = reader.fieldnames
                self.stdout.write(f"Found columns: {', '.join(headers)}")

                static_columns = [
                    "latitude",
                    "longitude",
                    "farm",
                    "Name",
                    "Land_Cover",
                    "Grazing",
                    "Agroforest",
                ]

                metric_pattern = re.compile(
                    r"^(?P<type>[A-Za-z_]+(?:_[A-Za-z0-9]+)*)_(?P<year>\d{4})$"
                )

                with transaction.atomic():
                    created_farms = 0
                    created_plots = 0
                    updated_plots = 0
                    created_metrics = 0
                    updated_metrics = 0
                    skipped_rows = 0

                    for row_num, row in enumerate(reader, start=2):
                        try:
                            latitude = self._parse_float(row.get("latitude"))
                            longitude = self._parse_float(row.get("longitude"))

                            if latitude is None or longitude is None:
                                skipped_rows += 1
                                continue

                            farm_name = row.get("farm") or ""
                            plot_name = row.get("Name") or ""
                            land_cover = row.get("Land_Cover") or ""
                            grazing = row.get("Grazing") or ""
                            agroforest = row.get("Agroforest") or ""

                            if not farm_name:
                                skipped_rows += 1
                                continue

                            farm, farm_created = Farm.objects.get_or_create(
                                name=farm_name,
                                defaults={"from_csv": True},
                            )

                            if farm_created:
                                created_farms += 1

                            plot, plot_created = Plot.objects.get_or_create(
                                farm=farm,
                                name=plot_name,
                                latitude=latitude,
                                longitude=longitude,
                                defaults={
                                    "land_cover": land_cover,
                                    "grazing": grazing,
                                    "agroforest": agroforest,
                                    "from_csv": True,
                                },
                            )

                            if plot_created:
                                created_plots += 1
                            else:
                                plot.land_cover = land_cover
                                plot.grazing = grazing
                                plot.agroforest = agroforest
                                plot.save()
                                updated_plots += 1

                            for key, value in row.items():
                                if key in static_columns:
                                    continue

                                match = metric_pattern.match(key)
                                if match:
                                    metric_type = match.group("type")
                                    year_str = match.group("year")

                                    try:
                                        year = int(year_str)
                                        metric_value = self._parse_float(value)

                                        if metric_value is not None:
                                            metric, metric_created = (
                                                Metric.objects.get_or_create(
                                                    plot=plot,
                                                    metric_type=metric_type,
                                                    year=year,
                                                    defaults={"value": metric_value, "from_csv": True},
                                                )
                                            )

                                            if metric_created:
                                                created_metrics += 1
                                            else:
                                                metric.value = metric_value
                                                metric.save()
                                                updated_metrics += 1
                                    except ValueError:
                                        continue

                        except Exception as e:
                            self.stderr.write(
                                self.style.WARNING(f"Row {row_num} error: {e}")
                            )

        except Exception as e:
            self.stderr.write(self.style.ERROR(f"Error reading CSV: {e}"))
            return

        self.stdout.write(self.style.SUCCESS("\nImport summary:"))
        self.stdout.write(f"  Farms created: {created_farms}")
        self.stdout.write(f"  Plots created: {created_plots}")
        self.stdout.write(f"  Plots updated: {updated_plots}")
        self.stdout.write(f"  Metrics created: {created_metrics}")
        self.stdout.write(f"  Metrics updated: {updated_metrics}")
        self.stdout.write(f"  Rows skipped: {skipped_rows}")

    def _parse_float(self, value):
        if value is None or value == "":
            return None
        value = str(value).strip()
        if value.upper() == "NA":
            return None
        try:
            return float(value)
        except (ValueError, TypeError):
            return None
