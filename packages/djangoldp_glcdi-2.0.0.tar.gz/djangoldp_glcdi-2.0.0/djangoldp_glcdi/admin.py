from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from djangoldp.admin import DjangoLDPAdmin

from djangoldp_glcdi.models import Farm, Metric, Plot


class PlotInline(admin.TabularInline):
    model = Plot
    extra = 0
    fields = ("name", "latitude", "longitude", "land_cover", "grazing", "agroforest", "from_csv")
    readonly_fields = ("from_csv",)


class MetricInline(admin.TabularInline):
    model = Metric
    extra = 0
    fields = ("metric_type", "year", "value", "from_csv")
    readonly_fields = ("created_at", "updated_at", "from_csv")


class PlotLandCoverFilter(admin.SimpleListFilter):
    title = _("Plot Land Cover")
    parameter_name = "plot_land_cover"

    def lookups(self, request, model_admin):
        land_covers = (
            Plot.objects.values_list("land_cover", flat=True)
            .filter(land_cover__isnull=False)
            .distinct()
        )
        return [(lc, lc) for lc in land_covers]

    def queryset(self, request, queryset):
        value = self.value()
        if value:
            return queryset.filter(plots__land_cover=value).distinct()
        return queryset


class PlotGrazingFilter(admin.SimpleListFilter):
    title = _("Plot Grazing")
    parameter_name = "plot_grazing"

    def lookups(self, request, model_admin):
        grazing_types = (
            Plot.objects.values_list("grazing", flat=True)
            .filter(grazing__isnull=False)
            .distinct()
        )
        return [(g, g) for g in grazing_types]

    def queryset(self, request, queryset):
        value = self.value()
        if value:
            return queryset.filter(plots__grazing=value).distinct()
        return queryset


class PlotAgroforestFilter(admin.SimpleListFilter):
    title = _("Plot Agroforest")
    parameter_name = "plot_agroforest"

    def lookups(self, request, model_admin):
        agroforest_types = (
            Plot.objects.values_list("agroforest", flat=True)
            .filter(agroforest__isnull=False)
            .distinct()
        )
        return [(af, af) for af in agroforest_types]

    def queryset(self, request, queryset):
        value = self.value()
        if value:
            return queryset.filter(plots__agroforest=value).distinct()
        return queryset


@admin.register(Farm)
class FarmAdmin(DjangoLDPAdmin):
    list_display = ("name", "urlid", "plot_count", "from_csv", "created_at", "updated_at")
    list_filter = (
        "created_at",
        "updated_at",
        "from_csv",
        PlotLandCoverFilter,
        PlotGrazingFilter,
        PlotAgroforestFilter,
    )
    search_fields = ("name", "urlid")
    readonly_fields = ("created_at", "updated_at", "from_csv")
    exclude = ("is_backlink", "allow_create_backlink")
    inlines = [PlotInline]
    fieldsets = (
        (None, {"fields": ("name", "from_csv")}),
        ("Timestamps", {"fields": ("created_at", "updated_at")}),
    )

    def plot_count(self, obj):
        return obj.plots.count()

    plot_count.short_description = _("Number of Plots")


@admin.register(Plot)
class PlotAdmin(DjangoLDPAdmin):
    list_display = ("name", "farm", "latitude", "longitude", "land_cover", "from_csv", "created_at")
    list_filter = ("farm", "land_cover", "grazing", "agroforest", "from_csv", "created_at")
    search_fields = ("name", "urlid", "farm__name")
    readonly_fields = ("created_at", "updated_at", "from_csv")
    exclude = ("is_backlink", "allow_create_backlink")
    inlines = [MetricInline]
    fieldsets = (
        (None, {"fields": ("name", "farm")}),
        ("Location", {"fields": ("latitude", "longitude")}),
        ("Properties", {"fields": ("land_cover", "grazing", "agroforest", "from_csv")}),
        ("Timestamps", {"fields": ("created_at", "updated_at")}),
    )


@admin.register(Metric)
class MetricAdmin(DjangoLDPAdmin):
    list_display = ("plot", "metric_type", "year", "value", "from_csv", "created_at")
    list_filter = ("metric_type", "year", "plot__farm", "from_csv", "created_at")
    search_fields = ("metric_type", "plot__name", "plot__farm__name")
    readonly_fields = ("created_at", "updated_at", "from_csv")
    exclude = ("is_backlink", "allow_create_backlink")
    fieldsets = (
        (None, {"fields": ("plot", "metric_type", "year", "value", "from_csv")}),
        ("Timestamps", {"fields": ("created_at", "updated_at")}),
    )
