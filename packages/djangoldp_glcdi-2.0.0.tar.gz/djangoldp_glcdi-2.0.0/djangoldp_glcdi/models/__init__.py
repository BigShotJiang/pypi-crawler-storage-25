from djangoldp.models import DynamicNestedField

from .farm import *
from .metric import *
from .plot import *

setattr(Farm, "metrics", lambda self: Metric.objects.filter(plot__farm=self))
getattr(Farm, "metrics").field = DynamicNestedField(Metric, "metrics")
