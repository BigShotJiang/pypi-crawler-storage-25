from django.db import models
from django.utils.translation import gettext_lazy as _
from djangoldp import fields

from djangoldp_glcdi_common.models.__base_model import baseModel


class Metric(baseModel):
    from_csv = fields.BooleanField(default=False, verbose_name=_("From CSV"))
    plot = fields.ForeignKey(
        "djangoldp_glcdi.Plot",
        on_delete=models.CASCADE,
        related_name="metrics",
        verbose_name=_("Plot"),
    )
    metric_type = fields.CharField(max_length=50, verbose_name=_("Metric Type"))
    year = fields.IntegerField(verbose_name=_("Year"))
    value = fields.FloatField(verbose_name=_("Value"), blank=True, null=True)

    @property
    def related_plot(self):
        return {"@id": self.plot.urlid, "@type": self.plot._meta.rdf_type}

    class Meta(baseModel.Meta):
        verbose_name = _("Metric")
        verbose_name_plural = _("Metrics")
        container_path = "metrics"
        rdf_type = "glcdi:Metric"
        serializer_fields = baseModel.Meta.serializer_fields + [
            "related_plot",
            "metric_type",
            "year",
            "value",
        ]
        unique_together = [["plot", "metric_type", "year"]]
