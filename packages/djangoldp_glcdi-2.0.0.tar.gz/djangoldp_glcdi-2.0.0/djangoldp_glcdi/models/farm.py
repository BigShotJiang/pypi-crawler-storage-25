from django.utils.translation import gettext_lazy as _
from djangoldp import fields

from djangoldp_glcdi_common.models.__base_named_model import baseNamedModel


class Farm(baseNamedModel):
    from_csv = fields.BooleanField(default=False, verbose_name=_("From CSV"))
    class Meta(baseNamedModel.Meta):
        verbose_name = _("Farm")
        verbose_name_plural = _("Farms")
        container_path = "farms"
        rdf_type = "glcdi:Farm"
        depth = 2
        serializer_fields = baseNamedModel.Meta.serializer_fields + [
            "plots",
            "metrics",
        ]
        nested_fields = baseNamedModel.Meta.nested_fields + [
            "plots",
            "metrics",
        ]
