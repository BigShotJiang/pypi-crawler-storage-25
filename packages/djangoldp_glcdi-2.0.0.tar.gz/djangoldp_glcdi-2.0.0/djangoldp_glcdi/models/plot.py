from django.db import models
from django.utils.translation import gettext_lazy as _
from djangoldp import fields

from djangoldp_glcdi_common.models.__base_named_model import baseNamedModel


class Plot(baseNamedModel):
    from_csv = fields.BooleanField(default=False, verbose_name=_("From CSV"))
    farm = fields.ForeignKey(
        "djangoldp_glcdi.Farm",
        on_delete=models.CASCADE,
        related_name="plots",
        verbose_name=_("Farm"),
    )
    latitude = fields.FloatField(verbose_name=_("Latitude"))
    longitude = fields.FloatField(verbose_name=_("Longitude"))
    land_cover = fields.CharField(
        max_length=100, verbose_name=_("Land Cover"), blank=True, null=True
    )
    grazing = fields.CharField(
        max_length=100, verbose_name=_("Grazing"), blank=True, null=True
    )
    agroforest = fields.CharField(
        max_length=100, verbose_name=_("Agroforest"), blank=True, null=True
    )

    @property
    def related_farm(self):
        return {"@id": self.farm.urlid, "@type": self.farm._meta.rdf_type}

    @property
    def related_metrics(self):
        return {"@id": self.urlid + "metrics/", "@type": "ldp:Container"}

    class Meta(baseNamedModel.Meta):
        verbose_name = _("Plot")
        verbose_name_plural = _("Plots")
        container_path = "plots"
        rdf_type = "glcdi:Plot"
        serializer_fields = baseNamedModel.Meta.serializer_fields + [
            "related_farm",
            "latitude",
            "longitude",
            "land_cover",
            "grazing",
            "agroforest",
            "related_metrics",
        ]
        nested_fields = (
            baseNamedModel.Meta.nested_fields
            + [
                "metrics",
            ]
        )
