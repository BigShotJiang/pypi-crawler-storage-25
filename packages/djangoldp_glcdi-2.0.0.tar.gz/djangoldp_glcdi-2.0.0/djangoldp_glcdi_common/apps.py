from django.apps import AppConfig


class DjangoldpGlcdiCommonConfig(AppConfig):
    name = "djangoldp_glcdi_common"
