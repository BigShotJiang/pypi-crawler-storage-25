# Copyright 2026 Justin Ibarra (br0k3ns0und)
# Licensed under the Apache License, Version 2.0
# See LICENSE for details

"""Tests for phonemenal.fallback — fast phonetic key encoder."""

from phonemenal import fallback


class TestPhoneticKey:
    def test_basic_encoding(self):
        key = fallback.phonetic_key("numpy")
        assert key != ""
        assert isinstance(key, str)

    def test_sound_alikes_match(self):
        # click / klik should produce similar keys
        k1 = fallback.phonetic_key("click")
        k2 = fallback.phonetic_key("klik")
        assert fallback.similarity(k1, k2) > 0.7

    def test_digraph_replacement(self):
        # "phone" preserves leading 'p', so ph→f only applies after position 0
        # Use "alpha" vs "alfa" which has f/ph replacement mid-word
        k1 = fallback.phonetic_key("alphabet")
        k2 = fallback.phonetic_key("alfabet")
        assert fallback.similarity(k1, k2) > 0.8

    def test_empty_input(self):
        assert fallback.phonetic_key("") == ""

    def test_separators_stripped(self):
        k1 = fallback.phonetic_key("my-package")
        k2 = fallback.phonetic_key("my_package")
        k3 = fallback.phonetic_key("my.package")
        assert k1 == k2 == k3

    def test_double_letters_collapsed(self):
        k1 = fallback.phonetic_key("comm")
        k2 = fallback.phonetic_key("com")
        assert k1 == k2


class TestSimilarity:
    def test_identical(self):
        assert fallback.similarity("abc", "abc") == 1.0

    def test_empty(self):
        assert fallback.similarity("", "abc") == 0.0

    def test_range(self):
        score = fallback.similarity("hello", "hallo")
        assert 0.0 <= score <= 1.0


class TestCompare:
    def test_returns_dict(self):
        result = fallback.compare("numpy", "numpie")
        assert "key1" in result
        assert "key2" in result
        assert "score" in result
        assert "exact_match" in result
        assert 0.0 <= result["score"] <= 1.0
