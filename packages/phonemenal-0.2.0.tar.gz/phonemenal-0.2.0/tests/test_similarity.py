# Copyright 2026 Justin Ibarra (br0k3ns0und)
# Licensed under the Apache License, Version 2.0
# See LICENSE for details

"""Tests for phonemenal.similarity — PPC-A, PLD, LCS, and composite scoring."""

from phonemenal import similarity


class TestPPC:
    def test_identical_words(self):
        score = similarity.ppc("crowd", "crowd")
        assert score == 1.0

    def test_similar_words(self):
        # crowd / crown share 3 of 4 phonemes at same positions
        score = similarity.ppc("crowd", "crown")
        assert 0.3 < score < 0.9

    def test_dissimilar_words(self):
        score = similarity.ppc("cat", "elephant")
        assert score < 0.3

    def test_unknown_word_returns_zero(self):
        score = similarity.ppc("xyzzyplugh", "hello")
        assert score == 0.0

    def test_raw_mode(self):
        score, details = similarity.ppc("crowd", "crown", raw=True)
        assert isinstance(details, dict)
        assert "shared" in details
        assert "p1" in details

    def test_normalized_range(self):
        score = similarity.ppc("test", "best")
        assert 0.0 <= score <= 1.0


class TestPLD:
    def test_identical_words(self):
        score = similarity.pld("hello", "hello")
        assert score == 1.0

    def test_similar_words(self):
        # PLD is syllable-level; single-syllable words that differ = distance 1
        # Use multi-syllable words to show partial similarity
        score = similarity.pld("elastic", "fantastic")
        assert 0.0 < score < 1.0

    def test_different_syllable_count(self):
        score = similarity.pld("cat", "catalog")
        assert 0.0 <= score <= 1.0

    def test_unknown_word(self):
        score = similarity.pld("xyzzyplugh", "hello")
        assert score == 0.0

    def test_raw_mode(self):
        score, details = similarity.pld("elastic", "fantastic", raw=True)
        assert "distance" in details
        assert "syllables1" in details

    def test_normalized_range(self):
        score = similarity.pld("elastic", "fantastic")
        assert 0.0 <= score <= 1.0


class TestPED:
    def test_identical_words(self):
        score = similarity.ped("hello", "hello")
        assert score == 1.0

    def test_monosyllable_near_match_scores_above_pld(self):
        assert similarity.pld("cat", "bat") == 0.0
        assert similarity.ped("cat", "bat") > 0.6

    def test_unknown_word(self):
        score = similarity.ped("xyzzyplugh", "hello")
        assert score == 0.0

    def test_raw_mode(self):
        score, details = similarity.ped("cat", "bat", raw=True)
        assert "distance" in details
        assert "phonemes1" in details

    def test_multi_syllable_range(self):
        score = similarity.ped("elastic", "fantastic")
        assert 0.0 <= score <= 1.0

    def test_multiple_pronunciations(self):
        score = similarity.ped("read", "reed")
        assert score == 1.0


class TestLCS:
    def test_identical_words(self):
        score = similarity.lcs("hello", "hello")
        assert score == 1.0

    def test_similar_words(self):
        score = similarity.lcs("packaging", "packages")
        assert score > 0.5

    def test_character_mode(self):
        score = similarity.lcs("hello", "hallo", use_phonemes=False)
        assert score > 0.5

    def test_unknown_word_phoneme_mode(self):
        score = similarity.lcs("xyzzyplugh", "hello")
        assert score == 0.0

    def test_unknown_word_character_mode(self):
        score = similarity.lcs("xyzzyplugh", "hello", use_phonemes=False)
        assert 0.0 <= score <= 1.0

    def test_normalized_range(self):
        score = similarity.lcs("crowd", "crown")
        assert 0.0 <= score <= 1.0


class TestComposite:
    def test_identical_words(self):
        score = similarity.composite("hello", "hello")
        assert score == 1.0

    def test_default_weights(self):
        score = similarity.composite("crowd", "crown")
        assert 0.0 <= score <= 1.0

    def test_uses_edit_channel_for_monosyllables(self):
        report = similarity.compare("cat", "bat")
        assert report["pld"]["score"] == 0.0
        assert report["ped"]["score"] > report["pld"]["score"]
        assert report["edit"] == report["ped"]["score"]
        assert report["edit_source"] == "ped"
        assert report["composite"] > 0.5

    def test_length_edit_mode_prefers_pld_for_multi_syllable_words(self):
        report = similarity.compare("elastic", "fantastic", edit_mode="length")
        assert report["edit_mode"] == "length"
        assert report["edit_source"] == "pld"
        assert report["edit"] == report["pld"]["score"]

    def test_raw_mode_includes_edit_metadata(self):
        score, details = similarity.composite("cat", "bat", raw=True)
        assert "edit_mode" in details
        assert "edit_source" in details

    def test_custom_weights(self):
        score1 = similarity.composite("crowd", "crown", weights=(1.0, 0.0, 0.0))
        score2 = similarity.composite("crowd", "crown", weights=(0.0, 1.0, 0.0))
        # Different weights should give different scores (unless algorithms agree exactly)
        # Just verify they're both valid
        assert 0.0 <= score1 <= 1.0
        assert 0.0 <= score2 <= 1.0

    def test_zero_weights(self):
        score = similarity.composite("crowd", "crown", weights=(0.0, 0.0, 0.0))
        assert score == 0.0

    def test_raw_mode(self):
        score, details = similarity.composite("crowd", "crown", raw=True)
        assert "ppc" in details
        assert "pld" in details
        assert "ped" in details
        assert "edit" in details
        assert "lcs" in details

    def test_invalid_edit_mode_raises(self):
        try:
            similarity.composite("cat", "bat", edit_mode="bogus")
        except ValueError as exc:
            assert "unsupported edit_mode" in str(exc)
        else:
            raise AssertionError("expected ValueError")


class TestCompare:
    def test_returns_full_report(self):
        report = similarity.compare("crowd", "crown")
        assert report["word1"] == "crowd"
        assert report["word2"] == "crown"
        assert "ppc" in report
        assert "pld" in report
        assert "ped" in report
        assert "edit" in report
        assert "edit_mode" in report
        assert "edit_source" in report
        assert "lcs" in report
        assert "composite" in report
        assert 0.0 <= report["composite"] <= 1.0

    def test_all_scores_normalized(self):
        report = similarity.compare("test", "best")
        for alg in ["ppc", "pld", "ped", "lcs"]:
            assert 0.0 <= report[alg]["score"] <= 1.0
        assert 0.0 <= report["edit"] <= 1.0
        assert 0.0 <= report["composite"] <= 1.0
