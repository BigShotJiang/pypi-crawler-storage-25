# Copyright 2026 Justin Ibarra (br0k3ns0und)
# Licensed under the Apache License, Version 2.0
# See LICENSE for details

"""Tests for phonemenal.homophones — exact and near-homophone discovery."""

from phonemenal import homophones, similarity


class TestFind:
    def test_blue_has_blew(self):
        results = homophones.find("blue")
        assert "blew" in results

    def test_excludes_self_by_default(self):
        results = homophones.find("blue")
        assert "blue" not in results

    def test_include_self(self):
        results = homophones.find("blue", include_self=True)
        assert "blue" in results

    def test_unknown_word(self):
        results = homophones.find("xyzzyplugh")
        assert results == []

    def test_results_sorted(self):
        results = homophones.find("right")
        assert results == sorted(results)


class TestFindSimilar:
    def test_without_candidates(self):
        # Without candidates, just returns exact homophones
        results = homophones.find_similar("blue")
        assert any(r["word"] == "blew" for r in results)
        assert all(r["is_exact_homophone"] for r in results)

    def test_with_candidates(self):
        results = homophones.find_similar(
            "crowd",
            candidates=["crown", "crowed", "crud", "elephant"],
            min_score=0.3,
        )
        assert len(results) > 0
        # Results should be sorted by score descending
        scores = [r["score"] for r in results]
        assert scores == sorted(scores, reverse=True)

    def test_max_results(self):
        results = homophones.find_similar(
            "test",
            candidates=["best", "rest", "west", "nest", "jest", "pest", "fest"],
            min_score=0.3,
            max_results=3,
        )
        assert len(results) <= 3

    def test_scores_normalized(self):
        results = homophones.find_similar(
            "crowd",
            candidates=["crown", "crowed"],
            min_score=0.0,
        )
        for r in results:
            assert 0.0 <= r["score"] <= 1.0

    def test_default_weights_match_similarity_defaults(self):
        results = homophones.find_similar("cat", candidates=["bat"], min_score=0.0)
        assert len(results) == 1
        assert results[0]["score"] == round(similarity.composite("cat", "bat"), 4)

    def test_edit_mode_length_matches_composite_for_monosyllable_pair(self):
        results = homophones.find_similar(
            "cat",
            candidates=["bat"],
            min_score=0.0,
            edit_mode="length",
        )
        assert len(results) == 1
        assert results[0]["score"] == round(
            similarity.composite("cat", "bat", edit_mode="length"),
            4,
        )

    def test_edit_mode_length_changes_multisyllable_score(self):
        max_results = homophones.find_similar(
            "elastic",
            candidates=["fantastic"],
            min_score=0.0,
            edit_mode="max",
        )
        length_results = homophones.find_similar(
            "elastic",
            candidates=["fantastic"],
            min_score=0.0,
            edit_mode="length",
        )
        assert len(max_results) == 1
        assert len(length_results) == 1
        assert max_results[0]["score"] != length_results[0]["score"]
        assert length_results[0]["score"] == round(
            similarity.composite("elastic", "fantastic", edit_mode="length"),
            4,
        )
