# Copyright 2026 Justin Ibarra (br0k3ns0und)
# Licensed under the Apache License, Version 2.0
# See LICENSE for details

"""Tests for phonemenal.variants — sound-alike variant generation."""

from phonemenal import variants


class TestGenerate:
    def test_phonetic_substitutions(self):
        result = variants.generate("flask")
        assert "phlask" in result  # f → ph

    def test_double_letter(self):
        result = variants.generate("click")
        assert "cclick" in result or "cliick" in result

    def test_excludes_original(self):
        result = variants.generate("numpy")
        assert "numpy" not in result

    def test_returns_set(self):
        result = variants.generate("packaging")
        assert isinstance(result, set)
        assert len(result) > 0

    def test_no_separators(self):
        result = variants.generate("numpy", include_separators=False)
        for v in result:
            assert "-" not in v
            assert "_" not in v


class TestMorphological:
    def test_ing_variants(self):
        result = variants.generate_morphological("packaging")
        assert "packaged" in result
        assert "packager" in result

    def test_suffix_addition(self):
        result = variants.generate_morphological("numpy")
        assert "numpys" in result
        assert "numpylib" in result

    def test_suffix_removal(self):
        result = variants.generate_morphological("numpypy")
        assert "numpy" in result

    def test_excludes_original(self):
        result = variants.generate_morphological("packaging")
        assert "packaging" not in result
