# Copyright 2026 Justin Ibarra (br0k3ns0und)
# Licensed under the Apache License, Version 2.0
# See LICENSE for details

"""Smoke test — verifies core functionality from an installed package."""

import phonemenal
from phonemenal import fallback, homophones, scanning, similarity

print("version:", phonemenal.__version__)

# Similarity scoring
score = similarity.composite("crowd", "crown")
assert 0.0 <= score <= 1.0, f"bad score: {score}"
print("similarity: OK")

# Homophones
results = homophones.find("blue")
assert "blew" in results, f"missing homophone: {results}"
print("homophones: OK")

# Fallback encoder
k1 = fallback.phonetic_key("phone")
k2 = fallback.phonetic_key("fone")
assert k1 == k2, f"keys differ: {k1} != {k2}"
print("fallback:   OK")

# Scanning
matches = scanning.scan(["numpie"], ["numpy"])
assert len(matches) > 0, "no matches found"
print("scanning:   OK")

print("All smoke tests passed")
