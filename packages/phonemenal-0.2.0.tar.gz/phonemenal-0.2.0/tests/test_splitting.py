# Copyright 2026 Justin Ibarra (br0k3ns0und)
# Licensed under the Apache License, Version 2.0
# See LICENSE for details

"""Tests for phonemenal.splitting — compound word splitting and recombination."""

from phonemenal import splitting


class TestSplit:
    def test_single_word(self):
        result = splitting.split("hello")
        assert result == ["hello"]

    def test_compound_word(self):
        result = splitting.split("bluevoyage")
        assert len(result) >= 2

    def test_lowercase(self):
        result = splitting.split("BlueVoyage")
        for part in result:
            assert part == part.lower()


class TestComponentHomophones:
    def test_returns_dict(self):
        result = splitting.component_homophones("bluevoyage")
        assert isinstance(result, dict)

    def test_components_have_homophones(self):
        result = splitting.component_homophones("bluevoyage")
        # "blue" should have homophones like "blew"
        for part, homos in result.items():
            assert isinstance(homos, list)
            assert len(homos) >= 1


class TestHomophonePermutations:
    def test_returns_list(self):
        result = splitting.homophone_permutations("bluevoyage")
        assert isinstance(result, list)

    def test_includes_original(self):
        result = splitting.homophone_permutations("bluevoyage", include_original=True)
        # Should include at least the recombined original
        assert len(result) >= 1

    def test_excludes_original(self):
        result = splitting.homophone_permutations("bluevoyage", include_original=False)
        assert "bluevoyage" not in result

    def test_max_permutations(self):
        result = splitting.homophone_permutations("bluevoyage", max_permutations=5)
        assert len(result) <= 5

    def test_single_word_no_permutations(self):
        result = splitting.homophone_permutations("hello", include_original=False)
        assert result == []
