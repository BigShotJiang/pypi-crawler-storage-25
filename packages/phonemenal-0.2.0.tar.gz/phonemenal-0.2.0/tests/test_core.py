# Copyright 2026 Justin Ibarra (br0k3ns0und)
# Licensed under the Apache License, Version 2.0
# See LICENSE for details

"""Tests for phonemenal.core — CMU dict loading and phoneme utilities."""

from phonemenal import core


class TestCMUDict:
    def test_get_dict_returns_dict(self):
        d = core.get_dict()
        assert isinstance(d, dict)
        assert "hello" in d

    def test_get_phonemes_known_word(self):
        phonemes = core.get_phonemes("hello")
        assert len(phonemes) >= 1
        assert isinstance(phonemes[0], list)
        assert all(isinstance(p, str) for p in phonemes[0])

    def test_get_phonemes_unknown_word(self):
        phonemes = core.get_phonemes("xyzzyplugh")
        assert phonemes == []

    def test_get_phonemes_case_insensitive(self):
        assert core.get_phonemes("Hello") == core.get_phonemes("hello")


class TestInvertedIndex:
    def test_inverted_returns_dict(self):
        inv = core.get_inverted()
        assert isinstance(inv, dict)

    def test_find_words_by_pronunciation(self):
        # "blue" and "blew" should share a pronunciation
        phonemes = core.get_phonemes("blue")
        assert phonemes
        words = core.find_words_by_pronunciation(phonemes[0])
        assert "blue" in words
        assert "blew" in words


class TestLeaderTrailer:
    def test_leader_trailer_returns_tuple(self):
        leader, trailer = core.get_leader_trailer()
        assert isinstance(leader, dict)
        assert isinstance(trailer, dict)

    def test_find_words_by_leader(self):
        words = core.find_words_by_leader("K")
        assert len(words) > 0
        # All results should start with K phoneme
        for w in list(words)[:5]:
            phonemes = core.get_phonemes(w)
            assert any(p[0] == "K" for p in phonemes)


class TestSyllables:
    def test_split_empty(self):
        assert core.split_phonemes_by_syllables([]) == []

    def test_split_single_syllable(self):
        # "cat" = K AE1 T
        result = core.split_phonemes_by_syllables(["K", "AE1", "T"])
        assert len(result) == 1
        assert result[0] == ["K", "AE1", "T"]

    def test_split_multi_syllable(self):
        # "retraction" = R IY0 T R AE1 K SH AH0 N
        phonemes = ["R", "IY0", "T", "R", "AE1", "K", "SH", "AH0", "N"]
        result = core.split_phonemes_by_syllables(phonemes)
        assert len(result) == 3
        assert result[0] == ["R", "IY0"]
        assert result[1] == ["T", "R", "AE1"]
        assert result[2] == ["K", "SH", "AH0", "N"]

    def test_trailing_consonants_attach_to_last(self):
        # If the last phoneme is a consonant, it attaches to the last syllable
        phonemes = ["K", "AE1", "T", "S"]
        result = core.split_phonemes_by_syllables(phonemes)
        assert len(result) == 1
        assert result[0] == ["K", "AE1", "T", "S"]

    def test_syllable_count(self):
        # "hello" has 2 syllables
        phonemes = core.get_phonemes("hello")
        assert phonemes
        count = core.syllable_count(phonemes[0])
        assert count == 2


class TestHelpers:
    def test_is_vowel(self):
        assert core.is_vowel("AE1") is True
        assert core.is_vowel("IY0") is True
        assert core.is_vowel("K") is False
        assert core.is_vowel("S") is False

    def test_strip_stress(self):
        assert core.strip_stress("AE1") == "AE"
        assert core.strip_stress("K") == "K"
        assert core.strip_stress("IY0") == "IY"

    def test_normalize_name(self):
        assert core.normalize_name("my-package") == "mypackage"
        assert core.normalize_name("my_package") == "mypackage"
        assert core.normalize_name("My.Package") == "mypackage"
