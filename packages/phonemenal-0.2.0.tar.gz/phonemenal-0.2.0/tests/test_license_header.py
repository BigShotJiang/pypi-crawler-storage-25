# Copyright 2026 Justin Ibarra (br0k3ns0und)
# Licensed under the Apache License, Version 2.0
# See LICENSE for details

"""Ensure all Python source files include the Apache 2.0 license header."""

from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
EXPECTED_HEADER = (
    "# Copyright 2026 Justin Ibarra (br0k3ns0und)\n"
    "# Licensed under the Apache License, Version 2.0\n"
    "# See LICENSE for details\n"
)
DIRS = [REPO_ROOT / "phonemenal", REPO_ROOT / "tests"]


def _collect_py_files():
    files = []
    for d in DIRS:
        files.extend(d.rglob("*.py"))
    return sorted(files)


def test_all_python_files_have_license_header():
    missing = []
    for path in _collect_py_files():
        content = path.read_text()
        if not content.startswith(EXPECTED_HEADER):
            missing.append(str(path.relative_to(REPO_ROOT)))
    assert not missing, "The following files are missing the license header:\n" + "\n".join(
        f"  - {f}" for f in missing
    )
