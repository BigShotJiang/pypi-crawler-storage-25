# Copyright 2026 Justin Ibarra (br0k3ns0und)
# Licensed under the Apache License, Version 2.0
# See LICENSE for details

"""Ensures pyproject.toml and phonemenal.__version__ stay in sync."""

import tomllib
from pathlib import Path

import phonemenal


def test_version_matches_pyproject():
    pyproject = tomllib.loads((Path(__file__).parent.parent / "pyproject.toml").read_text())
    assert phonemenal.__version__ == pyproject["project"]["version"]
