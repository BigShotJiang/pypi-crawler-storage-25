# Copyright 2026 Justin Ibarra (br0k3ns0und)
# Licensed under the Apache License, Version 2.0
# See LICENSE for details

"""Tests for phonemenal.cli — Click CLI commands."""

from click.testing import CliRunner

from phonemenal.cli import main

runner = CliRunner()


class TestSimilarityCmd:
    def test_all_algorithms(self):
        result = runner.invoke(main, ["similarity", "crowd", "crown"])
        assert result.exit_code == 0
        assert "PPC" in result.output
        assert "PLD" in result.output
        assert "PED" in result.output
        assert "EDIT" in result.output
        assert "LCS" in result.output

    def test_json_output(self):
        result = runner.invoke(main, ["similarity", "crowd", "crown", "-j"])
        assert result.exit_code == 0
        import json

        data = json.loads(result.output)
        assert "ppc" in data
        assert "ped" in data
        assert "edit" in data
        assert "composite" in data

    def test_single_algorithm(self):
        result = runner.invoke(main, ["similarity", "crowd", "crown", "-a", "ppc"])
        assert result.exit_code == 0
        assert "PPC" in result.output

    def test_ped_algorithm(self):
        result = runner.invoke(main, ["similarity", "cat", "bat", "-a", "ped"])
        assert result.exit_code == 0
        assert "PED" in result.output

    def test_length_edit_mode(self):
        result = runner.invoke(main, ["similarity", "cat", "bat", "--edit-mode", "length", "-j"])
        assert result.exit_code == 0
        import json

        data = json.loads(result.output)
        assert data["edit_mode"] == "length"


class TestHomophonesCmd:
    def test_finds_homophones(self):
        result = runner.invoke(main, ["homophones", "blue"])
        assert result.exit_code == 0
        assert "blew" in result.output

    def test_unknown_word(self):
        result = runner.invoke(main, ["homophones", "xyzzyplugh"])
        assert result.exit_code == 0
        assert "No homophones" in result.output


class TestVariantsCmd:
    def test_generates_variants(self):
        result = runner.invoke(main, ["variants", "flask"])
        assert result.exit_code == 0
        assert "variants" in result.output.lower()

    def test_morphological(self):
        result = runner.invoke(main, ["variants", "packaging", "-m"])
        assert result.exit_code == 0
        assert "packaged" in result.output


class TestSplitCmd:
    def test_basic_split(self):
        result = runner.invoke(main, ["split", "bluevoyage"])
        assert result.exit_code == 0
        assert "Split" in result.output

    def test_permutations(self):
        result = runner.invoke(main, ["split", "bluevoyage", "-p"])
        assert result.exit_code == 0
        assert "permutations" in result.output.lower()


class TestCompareCmd:
    def test_full_report(self):
        result = runner.invoke(main, ["compare", "crowd", "crown"])
        assert result.exit_code == 0
        assert "PPC" in result.output
        assert "PED" in result.output
        assert "EDIT" in result.output
        assert "Composite" in result.output

    def test_json(self):
        result = runner.invoke(main, ["compare", "crowd", "crown", "-j"])
        assert result.exit_code == 0
        import json

        data = json.loads(result.output)
        assert "ped" in data
        assert "edit_mode" in data
        assert "composite" in data


class TestPromptCmd:
    def test_prints_prompt(self):
        result = runner.invoke(main, ["prompt", "numpy"])
        assert result.exit_code == 0
        assert "numpy" in result.output
        assert "phonetic" in result.output.lower()
