# Copyright 2026 Justin Ibarra (br0k3ns0und)
# Licensed under the Apache License, Version 2.0
# See LICENSE for details

"""Tests for phonemenal.scanning — collision scanning pipeline."""

from phonemenal import scanning, similarity

KNOWN_NAMES = ["numpy", "requests", "flask", "click", "django", "packaging", "setuptools"]


class TestBuildPhoneticIndex:
    def test_returns_dict(self):
        index = scanning.build_phonetic_index(KNOWN_NAMES)
        assert isinstance(index, dict)
        assert len(index) > 0

    def test_all_names_indexed(self):
        index = scanning.build_phonetic_index(KNOWN_NAMES)
        all_indexed = []
        for names in index.values():
            all_indexed.extend(names)
        for name in KNOWN_NAMES:
            assert name in all_indexed


class TestCheckCollision:
    def test_exact_phonetic_match(self):
        """Two names with the same phonetic key should match."""
        index = scanning.build_phonetic_index(KNOWN_NAMES)
        # "klik" should match "click" via phonetic key
        matches = scanning.check_collision("klik", KNOWN_NAMES, index, threshold=0.5)
        matched_names = [m["matched_name"] for m in matches]
        assert "click" in matched_names

    def test_no_self_match(self):
        index = scanning.build_phonetic_index(KNOWN_NAMES)
        matches = scanning.check_collision("numpy", KNOWN_NAMES, index)
        matched_names = [m["matched_name"] for m in matches]
        assert "numpy" not in matched_names

    def test_threshold_filtering(self):
        index = scanning.build_phonetic_index(KNOWN_NAMES)
        high = scanning.check_collision("numpyy", KNOWN_NAMES, index, threshold=0.9)
        low = scanning.check_collision("numpyy", KNOWN_NAMES, index, threshold=0.5)
        assert len(low) >= len(high)

    def test_match_dict_structure(self):
        index = scanning.build_phonetic_index(KNOWN_NAMES)
        matches = scanning.check_collision("klik", KNOWN_NAMES, index, threshold=0.5)
        if matches:
            m = matches[0]
            assert "candidate" in m
            assert "matched_name" in m
            assert "similarity" in m
            assert "candidate_key" in m
            assert "matched_key" in m
            assert "collision_type" in m
            assert 0.0 <= m["similarity"] <= 1.0

    def test_sorted_by_similarity(self):
        index = scanning.build_phonetic_index(KNOWN_NAMES)
        matches = scanning.check_collision("numpyy", KNOWN_NAMES, index, threshold=0.3)
        scores = [m["similarity"] for m in matches]
        assert scores == sorted(scores, reverse=True)

    def test_use_composite(self):
        """Composite scoring uses CMU-dict-backed algorithms."""
        index = scanning.build_phonetic_index(KNOWN_NAMES)
        matches = scanning.check_collision(
            "klik", KNOWN_NAMES, index, threshold=0.3, use_composite=True
        )
        # Should still find click as a match (or at least not crash)
        assert isinstance(matches, list)

    def test_default_composite_weights_match_similarity_defaults(self):
        index = scanning.build_phonetic_index(["bat"])
        matches = scanning.check_collision("cat", ["bat"], index, threshold=0.0, use_composite=True)
        assert len(matches) == 1
        assert matches[0]["similarity"] == round(similarity.composite("cat", "bat"), 4)

    def test_composite_mode_does_not_fallback_for_dissimilar_cmu_words(self):
        index = scanning.build_phonetic_index(["dog"])
        matches = scanning.check_collision("cat", ["dog"], index, threshold=0.1, use_composite=True)
        assert matches == []

    def test_edit_mode_length_matches_similarity_for_monosyllable_pair(self):
        index = scanning.build_phonetic_index(["bat"])
        matches = scanning.check_collision(
            "cat",
            ["bat"],
            index,
            threshold=0.0,
            use_composite=True,
            edit_mode="length",
        )
        assert len(matches) == 1
        assert matches[0]["similarity"] == round(
            similarity.composite("cat", "bat", edit_mode="length"),
            4,
        )

    def test_edit_mode_length_changes_multisyllable_score(self):
        index = scanning.build_phonetic_index(["fantastic"])
        max_matches = scanning.check_collision(
            "elastic",
            ["fantastic"],
            index,
            threshold=0.0,
            use_composite=True,
            edit_mode="max",
        )
        length_matches = scanning.check_collision(
            "elastic",
            ["fantastic"],
            index,
            threshold=0.0,
            use_composite=True,
            edit_mode="length",
        )
        assert len(max_matches) == 1
        assert len(length_matches) == 1
        assert max_matches[0]["similarity"] != length_matches[0]["similarity"]
        assert length_matches[0]["similarity"] == round(
            similarity.composite("elastic", "fantastic", edit_mode="length"),
            4,
        )


class TestScan:
    def test_finds_collisions(self):
        matches = scanning.scan(["klik", "numpyy"], KNOWN_NAMES, threshold=0.5)
        assert len(matches) > 0

    def test_no_collisions_for_unrelated(self):
        matches = scanning.scan(["xyzzyplugh"], KNOWN_NAMES, threshold=0.9)
        assert len(matches) == 0

    def test_multiple_candidates(self):
        matches = scanning.scan(["klik", "flaask", "reqests"], KNOWN_NAMES, threshold=0.5)
        candidates_found = {m["candidate"] for m in matches}
        # At least one candidate should have matches
        assert len(candidates_found) >= 1


class TestScanWithReverse:
    def test_without_exists_fn(self):
        """Without exists_fn, reverse scanning is skipped — same as forward scan."""
        forward = scanning.scan(["numpyy"], KNOWN_NAMES, threshold=0.5)
        reverse = scanning.scan_with_reverse(["numpyy"], KNOWN_NAMES, threshold=0.5)
        assert len(reverse) == len(forward)

    def test_with_exists_fn(self):
        """With exists_fn, reverse scan checks generated variants."""

        # Mock: pretend "numpys" exists
        def mock_exists(name: str) -> bool:
            return name in {"numpys", "numpie"}

        matches = scanning.scan_with_reverse(
            ["numpy"], KNOWN_NAMES, exists_fn=mock_exists, threshold=0.3
        )
        # Should find reverse-verified matches if variants pass threshold
        assert isinstance(matches, list)
        assert any(m.get("reverse_verified") for m in matches) or len(matches) >= 0

    def test_reverse_match_structure(self):
        def mock_exists(name: str) -> bool:
            return name == "numpys"

        matches = scanning.scan_with_reverse(
            ["numpy"], KNOWN_NAMES, exists_fn=mock_exists, threshold=0.3
        )
        reverse = [m for m in matches if m.get("reverse_verified")]
        for m in reverse:
            assert "candidate" in m
            assert "matched_name" in m
            assert "reverse_verified" in m
            assert m["reverse_verified"] is True

    def test_deduplication(self):
        """Forward and reverse matches for the same pair should not duplicate."""

        def mock_exists(name: str) -> bool:
            return True

        matches = scanning.scan_with_reverse(
            ["klik"], KNOWN_NAMES, exists_fn=mock_exists, threshold=0.5
        )
        pairs = [(m["candidate"], m["matched_name"]) for m in matches]
        assert len(pairs) == len(set(pairs))

    def test_composite_reverse_uses_fallback_for_non_cmu_variants(self):
        def mock_exists(name: str) -> bool:
            return name == "numpie"

        matches = scanning.scan_with_reverse(
            ["numpy"],
            ["numpy"],
            exists_fn=mock_exists,
            threshold=0.3,
            use_composite=True,
        )
        assert any(m["matched_name"] == "numpie" and m.get("reverse_verified") for m in matches)

    def test_composite_reverse_respects_edit_mode(self):
        def mock_exists(name: str) -> bool:
            return name == "packages"

        max_matches = scanning.scan_with_reverse(
            ["packaging"],
            ["packaging"],
            exists_fn=mock_exists,
            threshold=0.0,
            use_composite=True,
            edit_mode="max",
        )
        length_matches = scanning.scan_with_reverse(
            ["packaging"],
            ["packaging"],
            exists_fn=mock_exists,
            threshold=0.0,
            use_composite=True,
            edit_mode="length",
        )
        max_reverse = [
            m for m in max_matches if m.get("reverse_verified") and m["matched_name"] == "packages"
        ]
        length_reverse = [
            m
            for m in length_matches
            if m.get("reverse_verified") and m["matched_name"] == "packages"
        ]
        assert len(max_reverse) == 1
        assert len(length_reverse) == 1
        assert max_reverse[0]["similarity"] != length_reverse[0]["similarity"]
        assert length_reverse[0]["similarity"] == round(
            similarity.composite("packaging", "packages", edit_mode="length"),
            4,
        )


class TestFormatMatches:
    def test_no_matches(self):
        result = scanning.format_matches([])
        assert "No phonetic collisions" in result

    def test_with_matches(self):
        matches = scanning.scan(["klik"], KNOWN_NAMES, threshold=0.5)
        if matches:
            result = scanning.format_matches(matches)
            assert "match" in result.lower()
            assert "klik" in result

    def test_reverse_tag(self):
        match = {
            "candidate": "test",
            "matched_name": "tset",
            "similarity": 0.85,
            "candidate_key": "tAst",
            "matched_key": "tsAt",
            "collision_type": "near_phonetic",
            "reverse_verified": True,
        }
        result = scanning.format_matches([match])
        assert "reverse-verified" in result


class TestDefaultThreshold:
    def test_constant_value(self):
        assert scanning.DEFAULT_THRESHOLD == 0.75
