# Documentation Process

## How It Works

- Documentation lives in `docs/` as Markdown files
- API reference pages auto-generate from docstrings via [mkdocstrings](https://mkdocstrings.github.io/)
- The site builds with MkDocs Material and deploys to GitHub Pages via CI

## When to Update Docs

| Change | What to update |
|--------|---------------|
| New public function | Add it to the relevant `docs/api/*.md` members list |
| New module | Create `docs/api/<module>.md`, add to `nav` in `mkdocs.yml` |
| New CLI command | Add section in `docs/cli.md` |
| Changed function signature or behavior | Update the docstring (API ref updates automatically) |
| New feature or concept | Add or update a page in `docs/guide/` |
| New dependency or install step | Update `docs/getting-started/installation.md` |

## Local Preview

```bash
make docs-serve
```

Opens a dev server at `http://127.0.0.1:8000` with live reload — edits to `docs/` and docstrings appear instantly.

## Build Check

```bash
make docs
```

Runs `mkdocs build --strict`, which fails on warnings (broken links, malformed docstrings, missing members). Always run this before pushing.

## Docstring Format

mkdocstrings parses **Google-style** docstrings. List parameters individually — don't group them:

```python
def score(word1: str, word2: str, *, raw: bool = False) -> float:
    """One-line summary.

    Longer description if needed.

    Args:
        word1: First word to compare.
        word2: Second word to compare.
        raw: If True, return (score, details) tuple.

    Returns:
        Similarity score between 0.0 and 1.0.
    """
```

## Adding a New Page

1. Create the `.md` file under `docs/`
2. Add it to the `nav` section in `mkdocs.yml`
3. Run `make docs` to verify

## Math Notation

LaTeX math is supported via MathJax. Use `$$` for display math and `\(` / `\)` for inline:

```markdown
$$\text{composite} = \frac{w_1 \cdot \text{PPC}}{w_1 + w_2 + w_3}$$

The score is \(\geq 0\).
```

## Deployment

Docs deploy automatically on push to `main` via `.github/workflows/docs.yml`. The workflow:

1. Checks out the repo
2. Installs dependencies with `uv`
3. Builds with `mkdocs build --strict`
4. Deploys to GitHub Pages

No manual steps required. If the build fails in CI, check the workflow logs — it's usually a docstring warning that `--strict` caught.

## First-Time GitHub Pages Setup

Before the first deploy, enable Pages in the repo settings:

1. Go to **Settings > Pages**
2. Under **Source**, select **GitHub Actions**
3. Push to `main` — the workflow handles the rest
