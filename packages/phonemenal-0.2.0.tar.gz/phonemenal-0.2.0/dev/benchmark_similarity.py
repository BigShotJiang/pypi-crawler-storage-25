#!/usr/bin/env python3
# Copyright 2026 Justin Ibarra (br0k3ns0und)
# Licensed under the Apache License, Version 2.0
# See LICENSE for details

from __future__ import annotations

import argparse
import hashlib
import json
import re
from collections import defaultdict
from dataclasses import dataclass, asdict
from statistics import mean

from phonemenal import similarity
from phonemenal.core import get_dict, strip_stress

VOWELS = {
    "AA",
    "AE",
    "AH",
    "AO",
    "AW",
    "AY",
    "EH",
    "ER",
    "EY",
    "IH",
    "IY",
    "OW",
    "OY",
    "UH",
    "UW",
}

CATEGORY_TARGETS = {
    "exact_homophone": 1.00,
    "consonant_substitution": 0.85,
    "vowel_substitution": 0.78,
    "single_insertion_or_deletion": 0.72,
}


@dataclass(frozen=True)
class WordPronunciation:
    word: str
    phonemes: tuple[str, ...]
    stripped: tuple[str, ...]


@dataclass(frozen=True)
class BenchmarkPair:
    word1: str
    word2: str
    category: str
    reference_score: float


def is_alpha_word(word: str) -> bool:
    return re.fullmatch(r"[a-z]+", word) is not None and 3 <= len(word) <= 12


def is_vowel_base(phoneme: str) -> bool:
    return strip_stress(phoneme) in VOWELS


def normalize_pair(word1: str, word2: str) -> tuple[str, str]:
    return tuple(sorted((word1, word2)))


def load_words() -> list[WordPronunciation]:
    words: list[WordPronunciation] = []
    for word, pronunciations in get_dict().items():
        if not is_alpha_word(word):
            continue
        phonemes = tuple(pronunciations[0])
        stripped = tuple(strip_stress(p) for p in phonemes)
        words.append(WordPronunciation(word=word, phonemes=phonemes, stripped=stripped))
    return words


def collect_exact_homophones(words: list[WordPronunciation]) -> list[BenchmarkPair]:
    grouped: dict[tuple[str, ...], list[str]] = defaultdict(list)
    for item in words:
        grouped[item.stripped].append(item.word)

    pairs: list[BenchmarkPair] = []
    for group in grouped.values():
        unique = sorted(set(group))
        if len(unique) < 2:
            continue
        for i in range(len(unique) - 1):
            pairs.append(
                BenchmarkPair(
                    word1=unique[i],
                    word2=unique[i + 1],
                    category="exact_homophone",
                    reference_score=CATEGORY_TARGETS["exact_homophone"],
                )
            )
    return pairs


def collect_substitutions(
    words: list[WordPronunciation],
    *,
    vowel_substitution: bool,
) -> list[BenchmarkPair]:
    grouped_by_length: dict[int, list[WordPronunciation]] = defaultdict(list)
    for item in words:
        grouped_by_length[len(item.stripped)].append(item)

    pairs: list[BenchmarkPair] = []
    seen: set[tuple[str, str]] = set()

    for length, items in grouped_by_length.items():
        if length < 2:
            continue

        buckets: dict[tuple[int, tuple[str, ...]], list[WordPronunciation]] = defaultdict(list)
        for item in items:
            for index in range(length):
                pattern = item.stripped[:index] + ("*",) + item.stripped[index + 1 :]
                buckets[(index, pattern)].append(item)

        for (index, _), bucket in buckets.items():
            if len(bucket) < 2:
                continue

            bucket = sorted(bucket, key=lambda item: item.word)
            for i in range(len(bucket) - 1):
                for j in range(i + 1, len(bucket)):
                    left = bucket[i]
                    right = bucket[j]
                    if left.stripped[index] == right.stripped[index]:
                        continue

                    left_is_vowel = is_vowel_base(left.phonemes[index])
                    right_is_vowel = is_vowel_base(right.phonemes[index])

                    if vowel_substitution != (left_is_vowel and right_is_vowel):
                        continue
                    if not vowel_substitution and (left_is_vowel or right_is_vowel):
                        continue

                    pair_key = normalize_pair(left.word, right.word)
                    if pair_key in seen:
                        continue
                    seen.add(pair_key)

                    category = (
                        "vowel_substitution"
                        if vowel_substitution
                        else "consonant_substitution"
                    )
                    pairs.append(
                        BenchmarkPair(
                            word1=left.word,
                            word2=right.word,
                            category=category,
                            reference_score=CATEGORY_TARGETS[category],
                        )
                    )
    return pairs


def collect_insertions(words: list[WordPronunciation]) -> list[BenchmarkPair]:
    grouped_by_sequence: dict[tuple[str, ...], list[str]] = defaultdict(list)
    grouped_by_length: dict[int, list[WordPronunciation]] = defaultdict(list)

    for item in words:
        grouped_by_sequence[item.stripped].append(item.word)
        grouped_by_length[len(item.stripped)].append(item)

    pairs: list[BenchmarkPair] = []
    seen: set[tuple[str, str]] = set()

    for length, longer_items in grouped_by_length.items():
        shorter_words = grouped_by_sequence
        if length < 2:
            continue
        for item in longer_items:
            for index in range(length):
                reduced = item.stripped[:index] + item.stripped[index + 1 :]
                if reduced not in shorter_words:
                    continue
                for shorter in shorter_words[reduced]:
                    pair_key = normalize_pair(item.word, shorter)
                    if pair_key in seen or item.word == shorter:
                        continue
                    seen.add(pair_key)
                    pairs.append(
                        BenchmarkPair(
                            word1=shorter,
                            word2=item.word,
                            category="single_insertion_or_deletion",
                            reference_score=CATEGORY_TARGETS["single_insertion_or_deletion"],
                        )
                    )
    return pairs


def take_deterministic(items: list[BenchmarkPair], count: int) -> list[BenchmarkPair]:
    unique = {
        (item.category, *normalize_pair(item.word1, item.word2)): item for item in items
    }
    ordered = sorted(
        unique.values(),
        key=lambda item: hashlib.sha256(
            f"{item.category}:{item.word1}:{item.word2}".encode("utf-8")
        ).hexdigest(),
    )
    return ordered[:count]


def build_benchmark() -> list[BenchmarkPair]:
    words = load_words()
    exact = take_deterministic(collect_exact_homophones(words), 250)
    consonant = take_deterministic(
        collect_substitutions(words, vowel_substitution=False),
        300,
    )
    vowel = take_deterministic(collect_substitutions(words, vowel_substitution=True), 250)
    insertion = take_deterministic(collect_insertions(words), 200)

    benchmark = exact + consonant + vowel + insertion
    if len(benchmark) != 1000:
        raise RuntimeError(f"expected 1000 pairs, got {len(benchmark)}")
    return benchmark


def evaluate_pair(pair: BenchmarkPair) -> dict:
    report = similarity.compare(pair.word1, pair.word2)
    composite_score = report["composite"]
    absolute_error = abs(composite_score - pair.reference_score)

    return {
        **asdict(pair),
        "ppc": report["ppc"]["score"],
        "pld": report["pld"]["score"],
        "ped": report["ped"]["score"],
        "edit": report["edit"],
        "lcs": report["lcs"]["score"],
        "composite": composite_score,
        "absolute_error": round(absolute_error, 4),
    }


def summarize(rows: list[dict]) -> dict:
    category_summary: dict[str, dict] = {}
    for category in CATEGORY_TARGETS:
        bucket = [row for row in rows if row["category"] == category]
        category_summary[category] = {
            "count": len(bucket),
            "reference_score": CATEGORY_TARGETS[category],
            "avg_ppc": round(mean(row["ppc"] for row in bucket), 4),
            "avg_pld": round(mean(row["pld"] for row in bucket), 4),
            "avg_ped": round(mean(row["ped"] for row in bucket), 4),
            "avg_edit": round(mean(row["edit"] for row in bucket), 4),
            "avg_lcs": round(mean(row["lcs"] for row in bucket), 4),
            "avg_composite": round(mean(row["composite"] for row in bucket), 4),
            "avg_absolute_error": round(mean(row["absolute_error"] for row in bucket), 4),
        }

    worst = sorted(rows, key=lambda row: row["absolute_error"], reverse=True)[:20]
    return {
        "count": len(rows),
        "category_summary": category_summary,
        "overall_average_error": round(mean(row["absolute_error"] for row in rows), 4),
        "worst_mismatches": worst,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--json", action="store_true", help="emit full JSON payload")
    args = parser.parse_args()

    benchmark = build_benchmark()
    rows = [evaluate_pair(pair) for pair in benchmark]
    summary = summarize(rows)

    if args.json:
        print(json.dumps({"summary": summary, "rows": rows}, indent=2, sort_keys=True))
        return

    print(f"Benchmark pairs: {summary['count']}")
    print(f"Overall average absolute error: {summary['overall_average_error']:.4f}")
    print()
    for category, stats in summary["category_summary"].items():
        print(
            f"{category}: count={stats['count']} ref={stats['reference_score']:.2f} "
            f"ppc={stats['avg_ppc']:.4f} pld={stats['avg_pld']:.4f} "
            f"ped={stats['avg_ped']:.4f} edit={stats['avg_edit']:.4f} "
            f"lcs={stats['avg_lcs']:.4f} composite={stats['avg_composite']:.4f} "
            f"error={stats['avg_absolute_error']:.4f}"
        )
    print()
    print("Worst mismatches:")
    for row in summary["worst_mismatches"][:10]:
        print(
            f"  {row['word1']}/{row['word2']} [{row['category']}] "
            f"ref={row['reference_score']:.2f} composite={row['composite']:.4f} "
            f"ppc={row['ppc']:.4f} pld={row['pld']:.4f} ped={row['ped']:.4f} "
            f"lcs={row['lcs']:.4f}"
        )


if __name__ == "__main__":
    main()
