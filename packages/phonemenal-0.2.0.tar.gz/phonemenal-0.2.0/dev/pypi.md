# PyPI Publishing

phonemenal publishes to PyPI via [Trusted Publishers (OIDC)](https://docs.pypi.org/trusted-publishers/) — no API tokens needed. GitHub Actions authenticates directly with PyPI using OpenID Connect.


## How It Works

The workflow (`.github/workflows/publish.yml`) triggers on tag push (`v*`) and runs five sequential jobs:

```
git tag v0.2.0 && git push origin v0.2.0
  → verify (tag matches pyproject.toml version)
  → build (uv build → sdist + wheel)
  → publish-testpypi (upload via OIDC)
  → smoke-test (install from wheel, run imports + core checks)
  → publish-pypi (upload via OIDC, requires environment approval)
```

## Release Checklist

1. **Update the version** in `pyproject.toml`:
   ```
   version = "0.2.0"
   ```

2. **Update `__version__`** in `phonemenal/__init__.py` to match.

3. **Commit and push** to `main`.

4. **Tag and push** (or use `make release VERSION=0.2.0`):
   ```bash
   git tag v0.2.0
   git push origin v0.2.0
   ```

5. The workflow runs automatically. Monitor progress in the **Actions** tab.

6. The smoke test installs the wheel and verifies core imports and functionality.

7. If the `pypi` environment has required reviewers, approve the deployment when prompted.

## Troubleshooting

### "publisher not found" error

The OIDC claim must match exactly. Verify:

- Workflow filename is `publish.yml` (not `release.yml`, etc.)
- Environment name matches (`pypi` or `testpypi`)
- Owner and repo name match the trusted publisher registration

### "file already exists" error

PyPI doesn't allow re-uploading the same version. Bump the version number and create a new release.

### Testing the build locally

```bash
uv build
ls dist/
# phonemenal-0.1.0.tar.gz  phonemenal-0.1.0-py3-none-any.whl
```
