# Installation

## Requirements

- Python 3.11 or later

## Install from PyPI

```bash
pip install phonemenal
```

Or with [uv](https://docs.astral.sh/uv/):

```bash
uv add phonemenal
```

## Optional Extras

### LLM Support

For deep phonetic analysis powered by Anthropic Claude or OpenAI GPT:

```bash
pip install phonemenal[llm]
```

This adds the `anthropic` and `openai` SDKs. You'll need an API key set in your environment:

```bash
export ANTHROPIC_API_KEY="sk-ant-..."
# or
export OPENAI_API_KEY="sk-..."
```

!!! tip
    If you use a local agent (e.g. `phonemenal analyze numpy --agent claude`), you don't need the `llm` extra — agents are invoked as subprocesses and have no Python SDK dependency.

### Grapheme-to-Phoneme

For G2P-based pronunciation of out-of-dictionary words:

```bash
pip install phonemenal[g2p]
```

### All Extras

```bash
pip install phonemenal[llm,g2p]
```

## NLTK Data

phonemenal uses the CMU Pronouncing Dictionary from NLTK. It is downloaded automatically on first use, but you can pre-fetch it:

```bash
python -c "import nltk; nltk.download('cmudict', quiet=True)"
```

Or via the Makefile:

```bash
make setup
```

## Development Install

```bash
git clone https://github.com/brokensound77/phonemenal.git
cd phonemenal
uv sync --all-extras
make setup  # download NLTK data
make test   # run the test suite
```

## Verify Installation

```bash
phonemenal --version
phonemenal similarity crowd crown
```
