# Quick Start

## Python API

### Compare Two Words

```python
from phonemenal import similarity

# Individual algorithms (all return 0.0–1.0)
similarity.ppc("crowd", "crown")        # Positional Phoneme Correlation
similarity.pld("elastic", "fantastic")   # Phoneme Levenshtein Distance
similarity.ped("cat", "bat")             # Phoneme Edit Distance
similarity.lcs("packaging", "packages")  # Longest Common Subsequence

# Weighted composite of PPC, Edit, and LCS
similarity.composite("crowd", "crown")

# Optional edit selection strategy
similarity.composite("cat", "bat", edit_mode="length")

# Full comparison report with all details
report = similarity.compare("crowd", "crown")
```

### Find Homophones

```python
from phonemenal import homophones

# Exact homophones (identical pronunciation)
homophones.find("blue")   # → ["blew"]
homophones.find("write")  # → ["right", "rite", "wright"]

# Near-homophones (above a similarity threshold)
homophones.find_similar("crowd", min_score=0.7)
```

### Generate Variants

```python
from phonemenal import variants

# Phonetic substitution variants
variants.generate("flask")  # → {"phlask", "flazk", ...}

# Include morphological variants (suffix/prefix swaps)
variants.generate_morphological("packaging")
# → {"packaged", "packager", "packages", ...}
```

### Split Compound Words

```python
from phonemenal import splitting

# ML-based segmentation
splitting.split("bluevoyage")  # → ["blue", "voyage"]

# Homophone permutations of each component
splitting.homophone_permutations("bluevoyage")
# → ["bluevoyage", "blewvoyage", "bleuvoyage", ...]
```

### Fallback Encoder

For words not in the CMU Pronouncing Dictionary (brand names, neologisms):

```python
from phonemenal import fallback

# Phonetic keys — sound-alike names produce the same key
fallback.phonetic_key("numpy")   # → "nAmpY"
fallback.phonetic_key("numpie")  # → "nAmpY"

# Key-based similarity
k1 = fallback.phonetic_key("pytorch")
k2 = fallback.phonetic_key("pytorche")
fallback.similarity(k1, k2)  # → 1.0
```

### Scan for Collisions

```python
from phonemenal import scanning

candidates = ["numpie", "requests2", "phlask"]
known_packages = ["numpy", "requests", "flask"]

# Forward scan
matches = scanning.scan(candidates, known_packages, threshold=0.75)

# Composite scan tuning for CMU-backed names
matches = scanning.scan(
    candidates,
    known_packages,
    threshold=0.75,
    use_composite=True,
    edit_mode="length",
)

# Forward + reverse (generates variants and checks existence)
matches = scanning.scan_with_reverse(
    candidates,
    known_packages,
    exists_fn=lambda name: name in known_packages,
)

# Pretty-print results
print(scanning.format_matches(matches))
```

### LLM-Powered Analysis

```python
from phonemenal import llm

# Deep analysis via Anthropic Claude
result = llm.analyze("numpy", provider="anthropic")

# Or via OpenAI
result = llm.analyze("numpy", provider="openai")

# Or via a local agent
result = llm.analyze("numpy", agent="claude")

# Get the raw prompt (for piping to your own LLM)
prompt = llm.get_prompt("numpy")
```

---

## CLI

phonemenal ships with a full command-line interface.

### Compare words

```bash
# All algorithms at once
phonemenal similarity crowd crown

# Specific algorithm
phonemenal similarity crowd crown -a ppc

# PED directly
phonemenal similarity cat bat -a ped

# Length-based edit channel selection
phonemenal similarity cat bat --edit-mode length

# JSON output
phonemenal similarity crowd crown -j
```

### Find homophones

```bash
phonemenal homophones blue
phonemenal homophones write
```

### Generate variants

```bash
phonemenal variants flask
phonemenal variants flask --morphological
```

### Split compound words

```bash
phonemenal split bluevoyage
phonemenal split bluevoyage --permutations
```

### Full comparison report

```bash
phonemenal compare crowd crown
phonemenal compare crowd crown --json-output
```

### LLM analysis

```bash
phonemenal analyze numpy --provider anthropic
phonemenal analyze numpy --agent claude

# Get the prompt for manual use
phonemenal prompt numpy | pbcopy
```
