# CLI Reference

phonemenal ships a full command-line interface built on [Click](https://click.palletsprojects.com/) with [Rich](https://rich.readthedocs.io/) formatting.

## Global Options

```
phonemenal --version    Show version and exit
phonemenal --help       Show help and exit
```

---

## `similarity`

Compare two words using phonetic similarity algorithms.

```bash
phonemenal similarity WORD1 WORD2 [OPTIONS]
```

| Option | Short | Default | Description |
|--------|-------|---------|-------------|
| `--algorithm` | `-a` | `all` | Algorithm to use: `ppc`, `pld`, `ped`, `lcs`, `composite`, or `all` |
| `--weights` | `-w` | `1.0 2.0 1.0` | PPC, Edit, LCS weights for composite scoring |
| `--edit-mode` | — | `max` | Edit channel selector: `max` or `length` |
| `--json-output` | `-j` | — | Output as JSON |

### Examples

```bash
# All algorithms
phonemenal similarity crowd crown

# Specific algorithm
phonemenal similarity crowd crown -a ppc

# Custom weights
phonemenal similarity crowd crown -a composite -w 0.5 2.0 0.5

# Use length-based edit selection
phonemenal similarity cat bat --edit-mode length

# JSON output
phonemenal similarity crowd crown -j
```

---

## `homophones`

Find exact homophones for a word.

```bash
phonemenal homophones WORD [OPTIONS]
```

| Option | Default | Description |
|--------|---------|-------------|
| `--include-self` | off | Include the input word in results |

### Examples

```bash
phonemenal homophones blue
phonemenal homophones write --include-self
```

---

## `variants`

Generate sound-alike spelling variants.

```bash
phonemenal variants NAME [OPTIONS]
```

| Option | Short | Default | Description |
|--------|-------|---------|-------------|
| `--morphological` | `-m` | off | Include morphological variants (suffix/prefix swaps) |
| `--no-separators` | — | off | Skip separator permutations |

### Examples

```bash
phonemenal variants flask
phonemenal variants flask --morphological
phonemenal variants my-package --no-separators
```

---

## `split`

Split a compound word and optionally show homophone permutations.

```bash
phonemenal split WORD [OPTIONS]
```

| Option | Short | Default | Description |
|--------|-------|---------|-------------|
| `--permutations` | `-p` | off | Show homophone permutations |
| `--max` | — | `50` | Maximum permutations to display |

### Examples

```bash
phonemenal split bluevoyage
phonemenal split bluevoyage -p
phonemenal split bluevoyage -p --max 20
```

---

## `compare`

Full comparison report between two words.

```bash
phonemenal compare WORD1 WORD2 [OPTIONS]
```

| Option | Short | Default | Description |
|--------|-------|---------|-------------|
| `--weights` | `-w` | `1.0 2.0 1.0` | PPC, Edit, LCS weights |
| `--edit-mode` | — | `max` | Edit channel selector: `max` or `length` |
| `--json-output` | `-j` | — | Output as JSON |

### Examples

```bash
phonemenal compare crowd crown
phonemenal compare crowd crown -j
phonemenal compare crowd crown -w 0.5 2.0 0.5
phonemenal compare cat bat --edit-mode length
```

---

## `analyze`

Deep LLM-powered phonetic analysis.

```bash
phonemenal analyze WORD [OPTIONS]
```

| Option | Short | Default | Description |
|--------|-------|---------|-------------|
| `--provider` | `-p` | `anthropic` | API provider: `anthropic` or `openai` |
| `--model` | `-m` | — | Override default model |
| `--agent` | `-a` | — | Use local agent: `claude`, `codex`, or path to executable |
| `--gateway` | `-g` | — | OpenAI-compatible gateway URL |

### Examples

```bash
phonemenal analyze numpy
phonemenal analyze numpy --provider openai
phonemenal analyze numpy --model claude-opus-4-20250514
phonemenal analyze numpy --agent claude
phonemenal analyze numpy --gateway https://my-gateway.example.com/v1/chat/completions
```

---

## `prompt`

Print the raw LLM analysis prompt for a word.

```bash
phonemenal prompt WORD
```

Useful for piping to other tools:

```bash
phonemenal prompt numpy | pbcopy
phonemenal prompt numpy | claude --print
```
