# similarity

Phonetic similarity scoring with four complementary algorithms.

All public functions return normalized scores between 0.0 (completely different) and 1.0 (identical). Pass `raw=True` to get a `(score, details)` tuple with intermediate computation data.

::: phonemenal.similarity
    options:
      members:
        - ppc
        - pld
        - ped
        - lcs
        - composite
        - compare
