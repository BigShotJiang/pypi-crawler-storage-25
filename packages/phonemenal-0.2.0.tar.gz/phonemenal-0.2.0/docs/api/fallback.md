# fallback

Fast phonetic key encoder that works on any string without CMU dict lookup. Simplified Metaphone-inspired encoding tuned for package names.

::: phonemenal.fallback
    options:
      members:
        - phonetic_key
        - similarity
        - compare
