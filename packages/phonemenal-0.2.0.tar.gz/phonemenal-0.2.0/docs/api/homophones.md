# homophones

Exact and near-homophone discovery using the CMU Pronouncing Dictionary.

`find_similar()` supports composite-score tuning via `weights` and `edit_mode`.

::: phonemenal.homophones
    options:
      members:
        - find
        - find_similar
