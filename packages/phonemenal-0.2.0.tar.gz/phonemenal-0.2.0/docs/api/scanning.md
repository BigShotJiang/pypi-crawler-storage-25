# scanning

High-level collision detection pipeline combining the fallback encoder, similarity scoring, and variant generation.

When `use_composite=True`, the scanning APIs support composite tuning via `composite_weights` and `edit_mode`.

::: phonemenal.scanning
    options:
      members:
        - build_phonetic_index
        - check_collision
        - scan
        - scan_with_reverse
        - format_matches
