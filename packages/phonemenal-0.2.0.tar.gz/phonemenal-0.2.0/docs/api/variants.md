# variants

Phonetic and morphological variant generation for proactive typosquatting detection.

::: phonemenal.variants
    options:
      members:
        - generate
        - generate_morphological
