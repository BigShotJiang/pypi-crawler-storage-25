# llm

LLM-powered deep phonetic analysis via Anthropic, OpenAI, compatible gateways, or local agents.

Requires the `llm` extra: `pip install phonemenal[llm]`

::: phonemenal.llm
    options:
      members:
        - get_prompt
        - analyze
