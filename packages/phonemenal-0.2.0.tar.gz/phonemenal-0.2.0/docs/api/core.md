# core

Core phoneme infrastructure — CMU dict access, phoneme utilities, and inverted indices.

::: phonemenal.core
    options:
      members:
        - get_dict
        - get_entries
        - get_inverted
        - get_leader_trailer
        - get_phonemes
        - strip_stress
        - is_vowel
        - split_phonemes_by_syllables
        - syllable_count
        - phonemes_to_str
        - find_words_by_pronunciation
        - find_words_by_leader
        - find_words_by_trailer
        - normalize_name
        - get_phonemes_or_fallback
