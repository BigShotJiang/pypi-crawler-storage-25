# splitting

Compound word splitting and homophone permutation recombination.

::: phonemenal.splitting
    options:
      members:
        - split
        - component_homophones
        - homophone_permutations
