# Copyright 2026 Justin Ibarra (br0k3ns0und)
# Licensed under the Apache License, Version 2.0
# See LICENSE for details

"""
LLM-powered deep phonetic analysis.

Three modes:
1. API: Direct call to Anthropic or OpenAI
2. Agent: Pipe prompt to a local CLI agent (claude, codex, or custom executable)
3. Gateway: OpenAI-compatible API endpoint (self-hosted models)

The LLM module is complementary to algorithmic scoring — it can serve as
a standalone analysis tool or as a tiebreaker when algorithmic scores are
ambiguous (mid-range).
"""

from __future__ import annotations

import logging
import os
import shutil
import subprocess
from pathlib import Path
from typing import Optional

log = logging.getLogger(__name__)

PROMPT_PATH = Path(__file__).parent / "prompts" / "homophone_analysis.txt"

# Known agent commands
KNOWN_AGENTS: dict[str, list[str]] = {
    "claude": ["claude", "--print"],
    "codex": ["codex", "exec"],
}


def get_prompt(word: str) -> str:
    """Get the analysis prompt template filled with the word."""
    template = PROMPT_PATH.read_text()
    return template.replace("{word}", word)


def analyze(
    word: str,
    *,
    provider: str = "anthropic",
    model: Optional[str] = None,
    agent: Optional[str] = None,
    gateway_url: Optional[str] = None,
    timeout: int = 120,
) -> str:
    """Run deep phonetic analysis via LLM.

    Args:
        word: Word or phrase to analyze.
        provider: "anthropic" or "openai" (for API mode).
        model: Override the default model.
        agent: Agent name ("claude", "codex") or path to executable (for agent mode).
        gateway_url: OpenAI-compatible API endpoint URL (for gateway mode).
        timeout: Timeout in seconds for agent subprocess.

    Returns the LLM's analysis as a string.

    Mode selection:
    - If agent is set → agent mode (subprocess)
    - If gateway_url is set → gateway mode (OpenAI SDK with custom base_url)
    - Otherwise → API mode (direct SDK call)
    """
    prompt = get_prompt(word)

    if agent:
        return _analyze_via_agent(prompt, agent=agent, timeout=timeout)
    elif gateway_url:
        return _analyze_via_gateway(prompt, gateway_url=gateway_url, model=model)
    else:
        return _analyze_via_api(prompt, provider=provider, model=model)


def _analyze_via_api(prompt: str, *, provider: str, model: Optional[str]) -> str:
    """Call Anthropic or OpenAI API directly."""
    if provider == "anthropic":
        return _call_anthropic(prompt, model=model)
    elif provider == "openai":
        return _call_openai(prompt, model=model)
    else:
        raise ValueError(f"Unknown provider: {provider!r}. Use 'anthropic' or 'openai'.")


def _call_anthropic(prompt: str, *, model: Optional[str]) -> str:
    """Call Anthropic API."""
    try:
        import anthropic
    except ImportError:
        raise ImportError(
            "anthropic package not installed. Install with: pip install phonemenal[llm]"
        )

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise ValueError("ANTHROPIC_API_KEY environment variable not set")

    model = model or os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-20250514")
    client = anthropic.Anthropic(api_key=api_key)
    response = client.messages.create(
        model=model,
        max_tokens=4096,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.content[0].text


def _call_openai(prompt: str, *, model: Optional[str]) -> str:
    """Call OpenAI API."""
    try:
        import openai
    except ImportError:
        raise ImportError("openai package not installed. Install with: pip install phonemenal[llm]")

    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("OPENAI_API_KEY environment variable not set")

    model = model or os.environ.get("OPENAI_MODEL", "gpt-4o")
    client = openai.OpenAI(api_key=api_key)
    response = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.choices[0].message.content


def _analyze_via_gateway(prompt: str, *, gateway_url: str, model: Optional[str]) -> str:
    """Call an OpenAI-compatible gateway endpoint."""
    try:
        import openai
    except ImportError:
        raise ImportError("openai package not installed. Install with: pip install phonemenal[llm]")

    model = model or "default"
    client = openai.OpenAI(base_url=gateway_url, api_key=os.environ.get("LLM_API_KEY", "none"))
    response = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.choices[0].message.content


def _analyze_via_agent(prompt: str, *, agent: str, timeout: int) -> str:
    """Pipe prompt to a local CLI agent via stdin."""
    if agent in KNOWN_AGENTS:
        cmd = KNOWN_AGENTS[agent]
    else:
        # Treat as executable path or command
        parts = agent.split()
        cmd = parts

    # Validate the executable exists
    exe = cmd[0]
    if not shutil.which(exe):
        raise FileNotFoundError(f"Agent executable not found: {exe!r}")

    result = subprocess.run(
        cmd,
        input=prompt,
        capture_output=True,
        text=True,
        timeout=timeout,
    )

    if result.returncode != 0:
        log.error("Agent %s failed (exit %d): %s", agent, result.returncode, result.stderr)
        raise RuntimeError(f"Agent {agent!r} exited with code {result.returncode}")

    return result.stdout
