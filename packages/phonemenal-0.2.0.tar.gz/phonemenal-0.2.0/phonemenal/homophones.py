# Copyright 2026 Justin Ibarra (br0k3ns0und)
# Licensed under the Apache License, Version 2.0
# See LICENSE for details

"""
Exact and near-homophone discovery via CMU pronunciation dictionary inversion.

- find(): exact homophones (identical pronunciation)
- find_similar(): near-homophones above a similarity threshold
"""

from __future__ import annotations

from .core import (
    find_words_by_pronunciation,
    get_phonemes,
    normalize_name,
)
from .similarity import composite


def find(word: str, *, include_self: bool = False) -> list[str]:
    """Find exact homophones — words with identical pronunciation.

    Args:
        word: Word to look up (case-insensitive).
        include_self: If True, include the input word in results.

    Returns list of homophones sorted alphabetically.
    """
    pronunciations = get_phonemes(word)
    if not pronunciations:
        return []

    homophones: set[str] = set()
    for pron in pronunciations:
        matches = find_words_by_pronunciation(pron)
        homophones.update(matches)

    if not include_self:
        homophones.discard(word.lower())

    return sorted(homophones)


def find_similar(
    word: str,
    *,
    candidates: list[str] | None = None,
    min_score: float = 0.75,
    weights: tuple[float, float, float] = (1.0, 2.0, 1.0),
    edit_mode: str = "max",
    max_results: int = 20,
) -> list[dict]:
    """Find near-homophones above a similarity threshold.

    Args:
        word: Word to compare against.
        candidates: List of words to check. If None, checks exact homophones
                   only (use with a candidate list for broader scanning).
        min_score: Minimum composite similarity score (0.0–1.0).
        weights: (ppc_weight, edit_weight, lcs_weight) for composite scoring.
        edit_mode: Composite edit-channel selector passed to similarity.composite().
        max_results: Maximum results to return.

    Returns list of dicts with 'word', 'score', and 'is_exact_homophone' keys,
    sorted by score descending.
    """
    results: list[dict] = []
    exact = set(find(word))

    if candidates is None:
        # Without candidates, just return exact homophones with score 1.0
        for h in sorted(exact):
            results.append({"word": h, "score": 1.0, "is_exact_homophone": True})
        return results[:max_results]

    word_lower = word.lower()

    for candidate in candidates:
        if normalize_name(candidate) == normalize_name(word_lower):
            continue

        score = composite(word, candidate, weights=weights, edit_mode=edit_mode)
        if score >= min_score:
            results.append(
                {
                    "word": candidate,
                    "score": round(score, 4),
                    "is_exact_homophone": candidate.lower() in exact,
                }
            )

    results.sort(key=lambda r: r["score"], reverse=True)
    return results[:max_results]
