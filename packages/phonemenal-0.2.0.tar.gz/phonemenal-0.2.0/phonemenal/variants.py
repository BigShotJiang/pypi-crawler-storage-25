# Copyright 2026 Justin Ibarra (br0k3ns0und)
# Licensed under the Apache License, Version 2.0
# See LICENSE for details

"""
Generate sound-alike spelling variants of a word.

Used for reverse scanning: given a known name, what sound-alike alternatives
exist? Generates candidates by applying common phonetic substitutions,
double/single letter swaps, and separator permutations.
"""

from __future__ import annotations

import re

# Common phonetic substitutions that produce sound-alike spellings
SUBSTITUTIONS: list[tuple[str, str]] = [
    ("ph", "f"),
    ("f", "ph"),
    ("ck", "k"),
    ("k", "ck"),
    ("s", "z"),
    ("z", "s"),
    ("i", "y"),
    ("y", "i"),
    ("er", "or"),
    ("or", "er"),
    ("le", "el"),
    ("el", "le"),
    ("tion", "sion"),
    ("sion", "tion"),
    ("x", "ks"),
    ("ks", "x"),
    ("c", "k"),
    ("k", "c"),
    ("qu", "kw"),
    ("kw", "qu"),
    ("igh", "y"),
    ("ough", "off"),
    ("ough", "ow"),
    ("ee", "ea"),
    ("ea", "ee"),
    ("ai", "ay"),
    ("ay", "ai"),
    ("oo", "u"),
    ("u", "oo"),
    ("ie", "y"),
    ("y", "ie"),
]


def generate(name: str, *, include_separators: bool = True) -> set[str]:
    """Generate phonetically similar variant spellings of a name.

    Args:
        name: Input name (separators stripped internally).
        include_separators: If True, also generate hyphen/underscore variants.

    Returns set of variant strings (excludes the input itself).
    """
    clean = re.sub(r"[-_.]+", "", name.lower())
    results: set[str] = set()

    # Phonetic substitutions
    for old, new in SUBSTITUTIONS:
        if old in clean:
            results.add(clean.replace(old, new, 1))

    # Double/single letter variants
    prev = ""
    for i, ch in enumerate(clean):
        if ch == prev:
            # Drop one of a double letter
            results.add(clean[:i] + clean[i + 1 :])
        else:
            # Double a single letter
            results.add(clean[:i] + ch + clean[i:])
        prev = ch

    # Separator permutations (common in multi-word names)
    if include_separators and len(clean) > 2:
        # Try inserting separators at word boundaries detected by case or length
        for sep in ["-", "_"]:
            for i in range(2, len(clean) - 1):
                results.add(clean[:i] + sep + clean[i:])

    results.discard(clean)
    return results


def generate_morphological(name: str) -> set[str]:
    """Generate morphological variants (suffix/prefix swaps).

    These aren't phonetic but are common morphological near-misses:
    packaging → packages, packaged, packager, etc.
    """
    clean = re.sub(r"[-_.]+", "", name.lower())
    results: set[str] = set()

    suffixes_to_try = [
        ("ing", ["ed", "er", "es", "tion", "ment"]),
        ("ed", ["ing", "er", "es"]),
        ("er", ["ing", "ed", "or"]),
        ("es", ["ed", "ing", "er"]),
        ("tion", ["sion", "ment", "ting"]),
        ("sion", ["tion", "ment"]),
        ("ment", ["tion", "ments"]),
        ("ly", ["ful", "less", "ness"]),
        ("ful", ["ly", "less"]),
        ("less", ["ly", "ful"]),
        ("ness", ["ly"]),
        ("py", ["pie", "pi"]),
        ("pi", ["py", "pie"]),
    ]

    for existing, replacements in suffixes_to_try:
        if clean.endswith(existing):
            base = clean[: -len(existing)]
            for replacement in replacements:
                results.add(base + replacement)

    # Also try just adding common suffixes
    for suffix in ["s", "py", "lib", "2", "3", "x", "js", "io"]:
        results.add(clean + suffix)

    # And removing trailing digits/common suffixes
    if clean[-1].isdigit():
        results.add(clean[:-1])
    for suffix in ["py", "lib", "2", "3", "x", "js", "io", "s"]:
        if clean.endswith(suffix) and len(clean) > len(suffix) + 1:
            results.add(clean[: -len(suffix)])

    results.discard(clean)
    return results
