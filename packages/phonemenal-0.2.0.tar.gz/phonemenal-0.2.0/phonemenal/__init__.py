# Copyright 2026 Justin Ibarra (br0k3ns0und)
# Licensed under the Apache License, Version 2.0
# See LICENSE for details

"""
phonemenal — General-purpose phonetic similarity detection and analysis.

Four scoring algorithms (all normalized 0.0–1.0):
  - PPC-A: Positional Phoneme Correlation (Absolute)
  - PLD: Phoneme Levenshtein Distance at syllable level
  - PED: Phoneme edit distance at phoneme level
  - LCS: Longest Common Subsequence ratio

Usage:
    from phonemenal import similarity, homophones, variants, splitting, fallback

    # Similarity scoring
    score = similarity.ppc("crowd", "crown")
    score = similarity.composite("crowd", "crown")

    # Exact homophones
    matches = homophones.find("blue")  # ["blew", ...]

    # Variant generation
    names = variants.generate("packaging")

    # Compound word splitting
    parts = splitting.split("bluevoyage")

    # Fallback (no CMU dict needed)
    key = fallback.phonetic_key("numpyy")

    # LLM analysis
    from phonemenal import llm
    result = llm.analyze("numpy", provider="anthropic")
"""

from . import fallback, homophones, scanning, similarity, splitting, variants

__all__ = [
    "similarity",
    "homophones",
    "variants",
    "splitting",
    "fallback",
    "scanning",
]

__version__ = "0.2.0"
