# Copyright 2026 Justin Ibarra (br0k3ns0und)
# Licensed under the Apache License, Version 2.0
# See LICENSE for details

"""
Scan candidate names against a set of known names for phonetic collisions.

This is the high-level scanning pipeline that combines the fallback phonetic
encoder, similarity scoring, and variant generation into a complete workflow.

Two scan modes:
  - Forward: check candidates against known names (fast, daemon pipeline)
  - Reverse: also generate variants of candidates and check if they exist
             in a provided lookup function (e.g. a registry check such as a PyPI HEAD request)
"""

from __future__ import annotations

import logging
from typing import Callable, Optional

from .core import get_phonemes_or_fallback
from .fallback import phonetic_key
from .fallback import similarity as fallback_similarity
from .similarity import composite as composite_score

log = logging.getLogger(__name__)

# Default threshold for flagging a phonetic near-match
DEFAULT_THRESHOLD = 0.75


def _word_has_cmu(word: str, cache: dict[str, bool]) -> bool:
    """Check CMU availability with a normalized per-call cache."""
    key = word.lower()
    cached = cache.get(key)
    if cached is not None:
        return cached

    present = get_phonemes_or_fallback(key) is not None
    cache[key] = present
    return present


def _needs_fallback_similarity(word1: str, word2: str, cache: dict[str, bool]) -> bool:
    """Return True when either word lacks CMU pronunciations."""
    return not _word_has_cmu(word1, cache) or not _word_has_cmu(word2, cache)


def _check_collision_impl(
    candidate: str,
    known_names: list[str],
    phonetic_index: dict[str, list[str]],
    *,
    threshold: float,
    use_composite: bool,
    composite_weights: tuple[float, float, float],
    edit_mode: str,
    cmu_cache: dict[str, bool],
) -> list[dict]:
    """Internal collision checker with shared CMU-availability cache."""
    candidate_lower = candidate.lower()
    candidate_key = phonetic_key(candidate)
    matches: list[dict] = []
    seen: set[str] = set()

    for name in phonetic_index.get(candidate_key, []):
        if name.lower() == candidate_lower:
            continue
        if name not in seen:
            matches.append(
                {
                    "candidate": candidate,
                    "matched_name": name,
                    "similarity": 1.0,
                    "candidate_key": candidate_key,
                    "matched_key": candidate_key,
                    "collision_type": "exact_phonetic",
                }
            )
            seen.add(name)

    if use_composite:
        for name in known_names:
            if name.lower() == candidate_lower or name in seen:
                continue
            if _needs_fallback_similarity(candidate, name, cmu_cache):
                score = fallback_similarity(candidate_key, phonetic_key(name))
            else:
                score = composite_score(
                    candidate,
                    name,
                    weights=composite_weights,
                    edit_mode=edit_mode,
                )
            if score >= threshold:
                matches.append(
                    {
                        "candidate": candidate,
                        "matched_name": name,
                        "similarity": round(score, 4),
                        "candidate_key": candidate_key,
                        "matched_key": phonetic_key(name),
                        "collision_type": "near_phonetic",
                    }
                )
                seen.add(name)
    else:
        for key, names in phonetic_index.items():
            if key == candidate_key:
                continue
            ratio = fallback_similarity(candidate_key, key)
            if ratio >= threshold:
                for name in names:
                    if name.lower() == candidate_lower or name in seen:
                        continue
                    matches.append(
                        {
                            "candidate": candidate,
                            "matched_name": name,
                            "similarity": round(ratio, 4),
                            "candidate_key": candidate_key,
                            "matched_key": key,
                            "collision_type": "near_phonetic",
                        }
                    )
                    seen.add(name)

    matches.sort(key=lambda m: m["similarity"], reverse=True)
    return matches


def _scan_impl(
    candidates: list[str],
    known_names: list[str],
    *,
    threshold: float,
    use_composite: bool,
    composite_weights: tuple[float, float, float],
    edit_mode: str,
    cmu_cache: dict[str, bool],
) -> list[dict]:
    """Internal scan implementation with shared CMU-availability cache."""
    index = build_phonetic_index(known_names)
    all_matches: list[dict] = []

    for candidate in candidates:
        hits = _check_collision_impl(
            candidate,
            known_names,
            index,
            threshold=threshold,
            use_composite=use_composite,
            composite_weights=composite_weights,
            edit_mode=edit_mode,
            cmu_cache=cmu_cache,
        )
        if hits:
            log.warning(
                "Phonetic collision: %s → %s",
                candidate,
                [(h["matched_name"], h["similarity"]) for h in hits],
            )
        all_matches.extend(hits)

    return all_matches


def build_phonetic_index(names: list[str]) -> dict[str, list[str]]:
    """Build a mapping from phonetic key → list of names.

    Used for fast exact-key lookups before falling back to pairwise scoring.
    """
    index: dict[str, list[str]] = {}
    for name in names:
        key = phonetic_key(name)
        if key not in index:
            index[key] = []
        index[key].append(name)
    return index


def check_collision(
    candidate: str,
    known_names: list[str],
    phonetic_index: dict[str, list[str]],
    *,
    threshold: float = DEFAULT_THRESHOLD,
    use_composite: bool = False,
    composite_weights: tuple[float, float, float] = (1.0, 2.0, 1.0),
    edit_mode: str = "max",
) -> list[dict]:
    """Check a candidate name for phonetic collisions against known names.

    Args:
        candidate: Name to check.
        known_names: List of known/legitimate names.
        phonetic_index: Pre-built index from build_phonetic_index().
        threshold: Minimum similarity score to flag (0.0–1.0).
        use_composite: If True, use CMU-dict-backed composite scoring
                      (PPC + Edit + LCS)
                      instead of fallback key similarity. Slower but more accurate.
        composite_weights: Weights for composite scoring (ppc, edit, lcs).
        edit_mode: Composite edit-channel selector passed to similarity.composite().

    Returns list of match dicts sorted by similarity descending:
        - candidate: input name
        - matched_name: the known name
        - similarity: 0.0–1.0 score
        - candidate_key: phonetic key of candidate
        - matched_key: phonetic key of match
        - collision_type: "exact_phonetic" | "near_phonetic"
    """
    return _check_collision_impl(
        candidate,
        known_names,
        phonetic_index,
        threshold=threshold,
        use_composite=use_composite,
        composite_weights=composite_weights,
        edit_mode=edit_mode,
        cmu_cache={},
    )


def scan(
    candidates: list[str],
    known_names: list[str],
    *,
    threshold: float = DEFAULT_THRESHOLD,
    use_composite: bool = False,
    composite_weights: tuple[float, float, float] = (1.0, 2.0, 1.0),
    edit_mode: str = "max",
) -> list[dict]:
    """Scan candidate names for phonetic collisions with known names.

    Forward scan only — checks each candidate against the known set.

    Args:
        candidates: Names to check.
        known_names: Known/legitimate names to compare against.
        threshold: Minimum similarity score to flag.
        use_composite: Use CMU-dict-backed composite scoring.
        composite_weights: Weights for composite scoring.
        edit_mode: Composite edit-channel selector passed to similarity.composite().

    Returns list of all matches across all candidates.
    """
    return _scan_impl(
        candidates,
        known_names,
        threshold=threshold,
        use_composite=use_composite,
        composite_weights=composite_weights,
        edit_mode=edit_mode,
        cmu_cache={},
    )


def scan_with_reverse(
    candidates: list[str],
    known_names: list[str],
    *,
    exists_fn: Optional[Callable[[str], bool]] = None,
    threshold: float = DEFAULT_THRESHOLD,
    use_composite: bool = False,
    composite_weights: tuple[float, float, float] = (1.0, 2.0, 1.0),
    edit_mode: str = "max",
    include_morphological: bool = True,
) -> list[dict]:
    """Scan candidates with forward AND reverse checking.

    Forward: candidate vs known names (same as scan()).
    Reverse: generate variants of each candidate, check if they exist via
             exists_fn, and score any that do against the candidate.

    Args:
        candidates: Names to check.
        known_names: Known/legitimate names.
        exists_fn: Callable that returns True if a name exists in an external system
                  (e.g. a PyPI HEAD request). If None, reverse scanning is skipped.
        threshold: Minimum similarity score.
        use_composite: Use CMU-dict composite scoring.
        composite_weights: Weights for composite scoring.
        edit_mode: Composite edit-channel selector passed to similarity.composite().
        include_morphological: Include morphological variants in reverse scan.

    Returns all matches (forward + reverse).
    """
    from .variants import generate, generate_morphological

    cmu_cache: dict[str, bool] = {}

    # Forward scan
    all_matches = _scan_impl(
        candidates,
        known_names,
        threshold=threshold,
        use_composite=use_composite,
        composite_weights=composite_weights,
        edit_mode=edit_mode,
        cmu_cache=cmu_cache,
    )
    seen = {(m["candidate"], m["matched_name"]) for m in all_matches}

    if exists_fn is None:
        return all_matches

    # Reverse scan
    for candidate in candidates:
        candidate_key = phonetic_key(candidate)

        variants = generate(candidate)
        if include_morphological:
            variants.update(generate_morphological(candidate))

        for variant in variants:
            if (candidate, variant) in seen or (variant, candidate) in seen:
                continue
            if not exists_fn(variant):
                continue

            # Score the variant against the candidate
            if use_composite:
                if _needs_fallback_similarity(candidate, variant, cmu_cache):
                    ratio = fallback_similarity(candidate_key, phonetic_key(variant))
                else:
                    ratio = composite_score(
                        candidate,
                        variant,
                        weights=composite_weights,
                        edit_mode=edit_mode,
                    )
            else:
                variant_key = phonetic_key(variant)
                ratio = fallback_similarity(candidate_key, variant_key)

            if ratio >= threshold:
                collision_type = "exact_phonetic" if ratio == 1.0 else "near_phonetic"
                match = {
                    "candidate": candidate,
                    "matched_name": variant,
                    "similarity": round(ratio, 4),
                    "candidate_key": candidate_key,
                    "matched_key": phonetic_key(variant),
                    "collision_type": collision_type,
                    "reverse_verified": True,
                }
                all_matches.append(match)
                seen.add((candidate, variant))
                log.warning(
                    "Reverse phonetic collision: %s ~ %s (score: %.2f, exists)",
                    candidate,
                    variant,
                    ratio,
                )

    all_matches.sort(key=lambda m: m.get("similarity", 0), reverse=True)
    return all_matches


def format_matches(matches: list[dict]) -> str:
    """Format collision results for display.

    Returns a human-readable string summarizing all matches.
    """
    if not matches:
        return "No phonetic collisions detected."

    lines = [f"Found {len(matches)} phonetic match(es):\n"]
    for m in matches:
        score = m["similarity"]
        icon = "!!!" if score >= 0.95 else "!!" if score >= 0.80 else "!"
        reverse_tag = " [reverse-verified]" if m.get("reverse_verified") else ""
        lines.append(
            f"  [{icon}] {m['candidate']!r} ~ {m['matched_name']!r}  "
            f"(score: {score:.2f}, type: {m['collision_type']}, "
            f"keys: {m['candidate_key']} / {m['matched_key']}){reverse_tag}"
        )
    return "\n".join(lines)
