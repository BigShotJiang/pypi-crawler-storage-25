# Copyright 2026 Justin Ibarra (br0k3ns0und)
# Licensed under the Apache License, Version 2.0
# See LICENSE for details

"""
Click CLI for phonemenal.

Commands:
  similarity  — Compare two words with PPC-A, PLD, PED, LCS, and composite scoring
  homophones  — Find exact homophones for a word
  variants    — Generate sound-alike spelling variants
  split       — Split a compound word and show homophone permutations
  compare     — Full comparison report (all algorithms)
  analyze     — Deep LLM-powered phonetic analysis
  prompt      — Print the LLM analysis prompt for a word
"""

from __future__ import annotations

import json

import click
from rich.console import Console
from rich.table import Table

console = Console()


@click.group()
@click.version_option()
def main() -> None:
    """phonemenal — General-purpose phonetic similarity detection and analysis."""


@main.command("similarity")
@click.argument("word1")
@click.argument("word2")
@click.option(
    "--algorithm",
    "-a",
    type=click.Choice(["ppc", "pld", "ped", "lcs", "composite", "all"]),
    default="all",
    help="Which algorithm to use.",
)
@click.option(
    "--weights",
    "-w",
    type=(float, float, float),
    default=(1.0, 2.0, 1.0),
    help="Weights for composite: PPC Edit LCS.",
)
@click.option(
    "--edit-mode",
    type=click.Choice(["max", "length"]),
    default="max",
    show_default=True,
    help=(
        'Edit channel mode: "max" uses the stronger of PLD/PED, '
        '"length" uses PED for monosyllables and PLD otherwise.'
    ),
)
@click.option("--json-output", "-j", is_flag=True, help="Output as JSON.")
def similarity_cmd(
    word1: str,
    word2: str,
    algorithm: str,
    weights: tuple[float, float, float],
    edit_mode: str,
    json_output: bool,
) -> None:
    """Compare two words using phonetic similarity algorithms."""
    from . import similarity

    if algorithm == "all" or json_output:
        report = similarity.compare(word1, word2, weights=weights, edit_mode=edit_mode)
        if json_output:
            # Clean non-serializable items
            clean = {
                "word1": report["word1"],
                "word2": report["word2"],
                "ppc": report["ppc"]["score"],
                "pld": report["pld"]["score"],
                "ped": report["ped"]["score"],
                "edit": report["edit"],
                "edit_mode": report["edit_mode"],
                "edit_source": report["edit_source"],
                "lcs": report["lcs"]["score"],
                "composite": report["composite"],
                "weights": list(report["weights"]),
            }
            click.echo(json.dumps(clean, indent=2))
            return

        table = Table(title=f"Similarity: {word1} vs {word2}")
        table.add_column("Algorithm", style="cyan")
        table.add_column("Score", style="bold")
        table.add_column("Bar", style="green")

        for alg in ["ppc", "pld", "ped", "lcs"]:
            score = report[alg]["score"]
            bar = _score_bar(score)
            table.add_row(alg.upper(), f"{score:.4f}", bar)

        table.add_row("EDIT", f"{report['edit']:.4f}", _score_bar(report["edit"]))
        table.add_row(
            "Composite", f"{report['composite']:.4f}", _score_bar(report["composite"]), style="bold"
        )
        console.print(table)
        console.print(
            f"[dim]Weights: PPC={weights[0]}, Edit={weights[1]}, LCS={weights[2]} | "
            f"edit_mode={report['edit_mode']} ({report['edit_source']})[/dim]"
        )
        return

    score_fn = getattr(similarity, algorithm)
    if algorithm == "composite":
        score = score_fn(word1, word2, weights=weights, edit_mode=edit_mode)
    else:
        score = score_fn(word1, word2)

    console.print(f"[cyan]{algorithm.upper()}[/cyan]: {score:.4f}  {_score_bar(score)}")


@main.command("homophones")
@click.argument("word")
@click.option("--include-self", is_flag=True, help="Include the input word in results.")
def homophones_cmd(word: str, include_self: bool) -> None:
    """Find exact homophones for a word."""
    from . import homophones

    results = homophones.find(word, include_self=include_self)
    if not results:
        console.print(f"[yellow]No homophones found for '{word}' in CMU dict.[/yellow]")
        return

    console.print(f"[bold]Homophones of '{word}':[/bold]")
    for h in results:
        console.print(f"  {h}")


@main.command("variants")
@click.argument("name")
@click.option("--morphological", "-m", is_flag=True, help="Include morphological variants.")
@click.option("--no-separators", is_flag=True, help="Skip separator permutations.")
def variants_cmd(name: str, morphological: bool, no_separators: bool) -> None:
    """Generate sound-alike spelling variants of a name."""
    from . import variants as v

    results = v.generate(name, include_separators=not no_separators)
    if morphological:
        results.update(v.generate_morphological(name))

    if not results:
        console.print(f"[yellow]No variants generated for '{name}'.[/yellow]")
        return

    console.print(f"[bold]{len(results)} variants of '{name}':[/bold]")
    for variant in sorted(results):
        console.print(f"  {variant}")


@main.command("split")
@click.argument("word")
@click.option("--permutations", "-p", is_flag=True, help="Show homophone permutations.")
@click.option("--max", "max_perms", type=int, default=50, help="Max permutations to show.")
def split_cmd(word: str, permutations: bool, max_perms: int) -> None:
    """Split a compound word and optionally show homophone permutations."""
    from . import splitting

    parts = splitting.split(word)
    console.print(f"[bold]Split:[/bold] {word} → {parts}")

    if permutations:
        comp = splitting.component_homophones(word)
        for part, homos in comp.items():
            console.print(f"  [cyan]{part}[/cyan] → {homos}")

        perms = splitting.homophone_permutations(word, max_permutations=max_perms)
        console.print(f"\n[bold]{len(perms)} permutations:[/bold]")
        for p in perms:
            console.print(f"  {p}")


@main.command("compare")
@click.argument("word1")
@click.argument("word2")
@click.option("--weights", "-w", type=(float, float, float), default=(1.0, 2.0, 1.0))
@click.option(
    "--edit-mode",
    type=click.Choice(["max", "length"]),
    default="max",
    show_default=True,
)
@click.option("--json-output", "-j", is_flag=True)
def compare_cmd(
    word1: str,
    word2: str,
    weights: tuple[float, float, float],
    edit_mode: str,
    json_output: bool,
) -> None:
    """Full comparison report between two words."""
    from . import similarity

    report = similarity.compare(word1, word2, weights=weights, edit_mode=edit_mode)

    if json_output:
        click.echo(json.dumps(report, indent=2, default=str))
        return

    console.print(f"\n[bold]Comparison: {word1} vs {word2}[/bold]\n")

    for alg in ["ppc", "pld", "ped", "lcs"]:
        data = report[alg]
        score = data["score"]
        console.print(f"  [cyan]{alg.upper()}[/cyan]: {score:.4f}  {_score_bar(score)}")
        if "p1" in data:
            console.print(f"    {word1}: {' '.join(data['p1'])}")
        if "p2" in data:
            console.print(f"    {word2}: {' '.join(data['p2'])}")
        if "syllables1" in data:
            console.print(f"    syllables: {data['syllables1']} vs {data['syllables2']}")
            console.print(f"    distance: {data.get('distance', '?')}")
        if "phonemes1" in data:
            console.print(f"    phonemes: {data['phonemes1']} vs {data['phonemes2']}")
            console.print(f"    distance: {data.get('distance', '?')}")

    console.print(f"  [cyan]EDIT[/cyan]: {report['edit']:.4f}  {_score_bar(report['edit'])}")
    console.print(f"    source: {report['edit_source']} ({report['edit_mode']})")

    console.print(
        f"\n  [bold]Composite[/bold]: {report['composite']:.4f}  {_score_bar(report['composite'])}"
    )
    console.print(f"  Weights: PPC={weights[0]}, Edit={weights[1]}, LCS={weights[2]}")


@main.command("analyze")
@click.argument("word")
@click.option("--provider", "-p", type=click.Choice(["anthropic", "openai"]), default="anthropic")
@click.option("--model", "-m", default=None, help="Override the default model.")
@click.option(
    "--agent",
    "-a",
    default=None,
    help="Use local agent instead of API (claude, codex, or path to executable).",
)
@click.option(
    "--gateway", "-g", default=None, help="OpenAI-compatible gateway URL for self-hosted models."
)
def analyze_cmd(
    word: str,
    provider: str,
    model: str | None,
    agent: str | None,
    gateway: str | None,
) -> None:
    """Deep LLM-powered phonetic analysis of a word."""
    from . import llm

    try:
        result = llm.analyze(
            word,
            provider=provider,
            model=model,
            agent=agent,
            gateway_url=gateway,
        )
        from rich.markdown import Markdown

        console.print(Markdown(result))
    except (ImportError, ValueError, FileNotFoundError, RuntimeError) as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


@main.command("prompt")
@click.argument("word")
def prompt_cmd(word: str) -> None:
    """Print the LLM analysis prompt for a word (for piping to an LLM)."""
    from . import llm

    click.echo(llm.get_prompt(word))


def _score_bar(score: float, width: int = 20) -> str:
    """Render a score as a visual bar."""
    filled = int(score * width)
    if score >= 0.90:
        color = "red"
    elif score >= 0.75:
        color = "yellow"
    elif score >= 0.60:
        color = "blue"
    else:
        color = "dim"
    bar = "█" * filled + "░" * (width - filled)
    return f"[{color}]{bar}[/{color}]"
