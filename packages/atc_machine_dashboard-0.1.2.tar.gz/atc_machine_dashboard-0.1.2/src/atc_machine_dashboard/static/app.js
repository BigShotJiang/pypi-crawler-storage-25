function byId(id) {
    return document.getElementById(id);
}

const lockDialog = byId("lockDialog");
const releaseDialog = byId("releaseDialog");
const detailsDialog = byId("detailsDialog");
const detailsContent = byId("detailsContent");

detailsDialog.addEventListener("click", async (event) => {
    const button = event.target.closest(".details-live-refresh");
    if (!button) {
        return;
    }
    event.preventDefault();
    const machineName = button.getAttribute("data-machine");
    if (machineName) {
        await showDetails(machineName, true);
    }
});

document.querySelectorAll("tr[data-machine]").forEach((row) => {
    const machineName = row.dataset.machine;
    row.querySelector(".lock-btn").addEventListener("click", () => {
        byId("lockMachineName").value = machineName;
        lockDialog.showModal();
    });
    row.querySelector(".release-btn").addEventListener("click", () => {
        byId("releaseMachineName").value = machineName;
        releaseDialog.showModal();
    });
    row.querySelector(".details-btn").addEventListener("click", async () => {
        await showDetails(machineName, false);
    });
});

byId("lockForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const machineName = byId("lockMachineName").value;
    const payload = {
        requested_by: byId("lockRequestedBy").value.trim(),
        lock_user: byId("lockUser").value.trim(),
        reason: byId("lockReason").value.trim(),
    };
    await postJson(`/api/machines/${machineName}/lock`, payload);
    lockDialog.close();
    window.location.reload();
});

byId("releaseForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const machineName = byId("releaseMachineName").value;
    const payload = {
        requested_by: byId("releaseRequestedBy").value.trim(),
        reason: byId("releaseReason").value.trim(),
    };
    await postJson(`/api/machines/${machineName}/release`, payload);
    releaseDialog.close();
    window.location.reload();
});

async function postJson(url, payload) {
    const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
    });
    if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        const message = data.detail || "Request failed.";
        alert(message);
        throw new Error(message);
    }
}

async function showDetails(machineName, live) {
    detailsContent.innerHTML = "<p>Loading details...</p>";
    detailsDialog.showModal();
    const query = live ? "?live=1" : "";
    const response = await fetch(`/api/machines/${machineName}/details${query}`);
    if (!response.ok) {
        detailsContent.innerHTML = "<p>Failed to fetch details.</p>";
        return;
    }
    const data = await response.json();
    detailsContent.innerHTML = renderDetails(data);
}

function renderDetails(data) {
    const netSessions = (data.network_sessions || []).slice(0, 30);
    const sections = [
        ["Active Sessions", data.active_sessions],
        ["Tracked App Usage (ETGui / MobaXterm / etc.)", data.app_usage.tracked_processes || []],
        ["Camera Related Usage", data.camera_usage],
        ["Active COM Ports", data.active_com_ports],
        ["Established Network Sessions", netSessions],
    ];
    const blocks = sections
        .map(([title, items]) => `<h4>${title}</h4><pre>${JSON.stringify(items, null, 2)}</pre>`)
        .join("");
    const errors = (data.raw_errors || []).length
        ? `<h4>Probe Errors</h4><pre>${JSON.stringify(data.raw_errors, null, 2)}</pre>`
        : "";
    const pollHint =
        data.poll_interval_seconds != null
            ? `<p><strong>Background poll:</strong> every ${data.poll_interval_seconds}s (${data.source})</p>`
            : `<p><strong>Data source:</strong> ${data.source}</p>`;
    return `
        <h3>${data.machine.name} (${data.machine.hostname})</h3>
        <p><strong>IP:</strong> ${data.machine.ip_address || "-"}</p>
        <p><strong>Lock status:</strong> ${data.lock_state.is_locked ? `Locked by ${data.lock_state.lock_user}` : "Released"}</p>
        <p><strong>Snapshot time:</strong> ${data.collected_at || "—"}</p>
        ${pollHint}
        <p><button type="button" class="details-live-refresh" data-machine="${data.machine.name}">Refresh now (live probe)</button></p>
        ${blocks}
        ${errors}
    `;
}

