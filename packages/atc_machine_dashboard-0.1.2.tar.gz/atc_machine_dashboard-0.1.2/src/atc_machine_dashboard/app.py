from __future__ import annotations

import asyncio
import json
import logging
import os
import sqlite3
import subprocess
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager, suppress
from datetime import datetime, timezone
from importlib import resources
from io import StringIO
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse, HTMLResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field
from starlette.requests import Request

from atc_machine_dashboard import __version__

class Machine(BaseModel):
    name: str
    hostname: str
    ip_address: str | None = None
    rdp_port: int = 3389
    tags: list[str] = Field(default_factory=list)


class LockRequest(BaseModel):
    requested_by: str = Field(min_length=2, max_length=100)
    lock_user: str = Field(min_length=2, max_length=100)
    reason: str = Field(min_length=5, max_length=500)


class ReleaseRequest(BaseModel):
    requested_by: str = Field(min_length=2, max_length=100)
    reason: str = Field(min_length=5, max_length=500)


PACKAGE_DIR = Path(__file__).resolve().parent


def _data_dir() -> Path:
    return Path(os.environ.get("MACHINE_DASHBOARD_DATA_DIR", Path.cwd()))


DATA_DIR = _data_dir()
INVENTORY_PATH = Path(os.environ.get("MACHINE_DASHBOARD_INVENTORY", DATA_DIR / "machines.json"))
DB_PATH = Path(os.environ.get("MACHINE_DASHBOARD_DB", DATA_DIR / "machine_dashboard.db"))
LOCK_SCRIPT = os.environ.get("MACHINE_DASHBOARD_LOCK_SCRIPT")
RELEASE_SCRIPT = os.environ.get("MACHINE_DASHBOARD_RELEASE_SCRIPT")

# Background polling: probe all machines every N seconds (set to 0 to disable).
_POLL_SECONDS_RAW = os.environ.get("MACHINE_DASHBOARD_POLL_SECONDS", "60")
POLL_SECONDS = float(_POLL_SECONDS_RAW) if _POLL_SECONDS_RAW.strip() else 0.0
POLL_ENABLED = os.environ.get("MACHINE_DASHBOARD_POLL_ENABLED", "1").strip().lower() not in (
    "0",
    "false",
    "no",
    "off",
)

_logger = logging.getLogger("atc_machine_dashboard")


def _ensure_default_inventory() -> None:
    """If default machines.json is missing, copy machines.example.json once."""
    if os.environ.get("MACHINE_DASHBOARD_INVENTORY"):
        return
    default_path = DATA_DIR / "machines.json"
    local_example = PACKAGE_DIR / "machines.example.json"
    if default_path.exists():
        return
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    try:
        text = resources.files("atc_machine_dashboard").joinpath("machines.example.json").read_text(encoding="utf-8")
    except (OSError, FileNotFoundError, TypeError, ValueError):
        if local_example.exists():
            text = local_example.read_text(encoding="utf-8")
        else:
            _logger.warning("Bundled machines.example.json not found; create %s manually.", default_path)
            return
    default_path.write_text(text, encoding="utf-8")
    _logger.warning(
        "Created %s from machines.example.json — edit hostnames and IPs for your network.",
        default_path,
    )


@asynccontextmanager
async def lifespan(_app: FastAPI) -> AsyncIterator[None]:
    init_db()
    _ensure_default_inventory()
    poll_task: asyncio.Task[None] | None = None
    if POLL_ENABLED and POLL_SECONDS > 0:
        poll_task = asyncio.create_task(_poll_loop(), name="machine_dashboard_poll")
    try:
        yield
    finally:
        if poll_task is not None:
            poll_task.cancel()
            with suppress(asyncio.CancelledError):
                await poll_task


app = FastAPI(title="ATC Machine Dashboard", version=__version__, lifespan=lifespan)
app.mount("/static", StaticFiles(directory=PACKAGE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=str(PACKAGE_DIR / "templates"))

_FAVICON_PATH = PACKAGE_DIR / "static" / "favicon.svg"


@app.get("/favicon.ico", include_in_schema=False)
def favicon() -> FileResponse:
    """Browsers request /favicon.ico by default; serve bundled SVG to avoid 404 noise."""
    return FileResponse(_FAVICON_PATH, media_type="image/svg+xml")


def load_machines() -> list[Machine]:
    if not INVENTORY_PATH.exists():
        hint = (
            f"Missing inventory: {INVENTORY_PATH}. "
            "Set MACHINE_DASHBOARD_INVENTORY, or place machines.json under MACHINE_DASHBOARD_DATA_DIR "
            f"(default: current directory, currently {DATA_DIR}). "
            "Run once so auto-seed can create machines.json from the bundled example."
        )
        raise FileNotFoundError(hint)
    payload = json.loads(INVENTORY_PATH.read_text(encoding="utf-8"))
    return [Machine.model_validate(item) for item in payload["machines"]]


def connect_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with connect_db() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS machine_locks (
                machine_name TEXT PRIMARY KEY,
                is_locked INTEGER NOT NULL,
                lock_user TEXT,
                reason TEXT,
                requested_by TEXT,
                updated_at TEXT
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS lock_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                machine_name TEXT NOT NULL,
                action TEXT NOT NULL,
                lock_user TEXT,
                reason TEXT NOT NULL,
                requested_by TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS machine_snapshots (
                machine_name TEXT PRIMARY KEY,
                collected_at TEXT NOT NULL,
                payload_json TEXT NOT NULL
            )
            """
        )


def get_lock_state(machine_name: str) -> dict[str, Any]:
    with connect_db() as conn:
        row = conn.execute("SELECT * FROM machine_locks WHERE machine_name = ?", (machine_name,)).fetchone()
    if row is None:
        return {"machine_name": machine_name, "is_locked": False, "lock_user": None, "reason": None}
    return dict(row)


def write_lock(machine_name: str, lock_user: str, reason: str, requested_by: str) -> dict[str, Any]:
    now = datetime.now(timezone.utc).isoformat()
    with connect_db() as conn:
        conn.execute(
            """
            INSERT INTO machine_locks(machine_name, is_locked, lock_user, reason, requested_by, updated_at)
            VALUES (?, 1, ?, ?, ?, ?)
            ON CONFLICT(machine_name)
            DO UPDATE SET is_locked=1, lock_user=excluded.lock_user, reason=excluded.reason,
                          requested_by=excluded.requested_by, updated_at=excluded.updated_at
            """,
            (machine_name, lock_user, reason, requested_by, now),
        )
        conn.execute(
            """
            INSERT INTO lock_history(machine_name, action, lock_user, reason, requested_by, created_at)
            VALUES (?, 'lock', ?, ?, ?, ?)
            """,
            (machine_name, lock_user, reason, requested_by, now),
        )
    return get_lock_state(machine_name)


def write_release(machine_name: str, reason: str, requested_by: str) -> dict[str, Any]:
    now = datetime.now(timezone.utc).isoformat()
    with connect_db() as conn:
        prev = conn.execute("SELECT lock_user FROM machine_locks WHERE machine_name = ?", (machine_name,)).fetchone()
        prior_lock_user = prev["lock_user"] if prev else None
        conn.execute(
            """
            INSERT INTO machine_locks(machine_name, is_locked, lock_user, reason, requested_by, updated_at)
            VALUES (?, 0, NULL, ?, ?, ?)
            ON CONFLICT(machine_name)
            DO UPDATE SET is_locked=0, lock_user=NULL, reason=excluded.reason,
                          requested_by=excluded.requested_by, updated_at=excluded.updated_at
            """,
            (machine_name, reason, requested_by, now),
        )
        conn.execute(
            """
            INSERT INTO lock_history(machine_name, action, lock_user, reason, requested_by, created_at)
            VALUES (?, 'release', ?, ?, ?, ?)
            """,
            (machine_name, prior_lock_user, reason, requested_by, now),
        )
    return get_lock_state(machine_name)


def run_script(command: str) -> str | None:
    out = subprocess.run(["powershell", "-NoProfile", "-Command", command], capture_output=True, text=True, timeout=25)
    if out.returncode != 0:
        return out.stderr.strip() or "policy script failed"
    return None


def run_probe(hostname: str, script_block: str) -> tuple[Any, str | None]:
    cmd = [
        "powershell",
        "-NoProfile",
        "-Command",
        f"Invoke-Command -ComputerName '{hostname}' -ScriptBlock {{ {script_block} }} | ConvertTo-Json -Depth 5",
    ]
    out = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
    if out.returncode != 0:
        return None, out.stderr.strip() or "probe failed"
    if not out.stdout.strip():
        return [], None
    try:
        return json.loads(out.stdout), None
    except json.JSONDecodeError as exc:
        return None, str(exc)


def normalize(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if isinstance(payload, dict):
        return [payload]
    return []


def collect_machine_details_payload(machine: Machine) -> dict[str, Any]:
    errors: list[str] = []
    sessions, err = run_probe(
        machine.hostname,
        """
        $sessions = query user 2>$null | Select-Object -Skip 1 | ForEach-Object {
          $line = $_.Trim(); if (-not $line) { return }
          $parts = ($line -replace '\\s{2,}', ',').Split(',')
          [pscustomobject]@{ userName=$parts[0]; sessionName=$parts[1]; id=$parts[2]; state=$parts[3] }
        }; $sessions
        """,
    )
    if err:
        errors.append(f"sessions: {err}")

    tracked, err = run_probe(
        machine.hostname,
        """
        $apps = @('ETGui.exe', 'MobaXterm.exe', 'mstsc.exe', 'putty.exe')
        Get-CimInstance Win32_Process | Where-Object { $apps -contains $_.Name } |
        Select-Object Name, ProcessId, CommandLine
        """,
    )
    if err:
        errors.append(f"apps: {err}")

    camera, err = run_probe(
        machine.hostname,
        """
        $cameraProcs = @('WindowsCamera.exe', 'python.exe', 'pythonw.exe', 'opencv_videoio_ffmpeg.dll')
        Get-CimInstance Win32_Process | Where-Object { $cameraProcs -contains $_.Name } |
        Select-Object Name, ProcessId, CommandLine
        """,
    )
    if err:
        errors.append(f"camera: {err}")

    com_ports, err = run_probe(
        machine.hostname,
        "Get-CimInstance Win32_SerialPort | Select-Object DeviceID, Description, Status, PNPDeviceID",
    )
    if err:
        errors.append(f"comports: {err}")

    net_sessions, err = run_probe(
        machine.hostname,
        "Get-NetTCPConnection -State Established | Select-Object LocalAddress, LocalPort, RemoteAddress, RemotePort, OwningProcess",
    )
    if err:
        errors.append(f"network: {err}")

    return {
        "active_sessions": normalize(sessions),
        "app_usage": {"tracked_processes": normalize(tracked)},
        "camera_usage": normalize(camera),
        "active_com_ports": normalize(com_ports),
        "network_sessions": normalize(net_sessions),
        "raw_errors": errors,
    }


def save_snapshot(machine_name: str, payload: dict[str, Any]) -> str:
    collected_at = datetime.now(timezone.utc).isoformat()
    with connect_db() as conn:
        conn.execute(
            """
            INSERT INTO machine_snapshots(machine_name, collected_at, payload_json)
            VALUES (?, ?, ?)
            ON CONFLICT(machine_name)
            DO UPDATE SET collected_at=excluded.collected_at, payload_json=excluded.payload_json
            """,
            (machine_name, collected_at, json.dumps(payload)),
        )
    return collected_at


def get_cached_snapshot(machine_name: str) -> tuple[str | None, dict[str, Any] | None]:
    with connect_db() as conn:
        row = conn.execute(
            "SELECT collected_at, payload_json FROM machine_snapshots WHERE machine_name = ?",
            (machine_name,),
        ).fetchone()
    if row is None:
        return None, None
    return row["collected_at"], json.loads(row["payload_json"])


def snapshot_times_all() -> dict[str, str]:
    with connect_db() as conn:
        rows = conn.execute("SELECT machine_name, collected_at FROM machine_snapshots").fetchall()
    return {str(r["machine_name"]): str(r["collected_at"]) for r in rows}


def _poll_round() -> None:
    try:
        machines = load_machines()
    except FileNotFoundError as exc:
        _logger.warning("Poll skipped: %s", exc)
        return
    for machine in machines:
        try:
            payload = collect_machine_details_payload(machine)
            save_snapshot(machine.name, payload)
        except Exception:
            _logger.exception("Background probe failed for %s", machine.name)


async def _poll_loop() -> None:
    _logger.info(
        "Background polling every %.1f s (set MACHINE_DASHBOARD_POLL_SECONDS=0 to disable).",
        POLL_SECONDS,
    )
    while True:
        await asyncio.to_thread(_poll_round)
        await asyncio.sleep(POLL_SECONDS)


@app.get("/", response_class=HTMLResponse)
def index(request: Request) -> HTMLResponse:
    machines = load_machines()
    times = snapshot_times_all()
    rows = [
        {
            "machine": m,
            "lock_state": get_lock_state(m.name),
            "last_collected_at": times.get(m.name),
        }
        for m in machines
    ]
    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "rows": rows,
            "poll_enabled": POLL_ENABLED and POLL_SECONDS > 0,
            "poll_seconds": POLL_SECONDS,
        },
    )


@app.get("/api/machines")
def list_machines():
    machines = load_machines()
    return [{"machine": m.model_dump(), "lock_state": get_lock_state(m.name)} for m in machines]


@app.post("/api/machines/{machine_name}/lock")
def lock_machine(machine_name: str, body: LockRequest):
    machines = {m.name: m for m in load_machines()}
    machine = machines.get(machine_name)
    if not machine:
        raise HTTPException(status_code=404, detail="Machine not found")
    if LOCK_SCRIPT:
        err = run_script(
            LOCK_SCRIPT.format(
                hostname=machine.hostname,
                machine_name=machine.name,
                lock_user=body.lock_user,
                reason=body.reason.replace('"', "'"),
            )
        )
        if err:
            raise HTTPException(status_code=500, detail=err)
    return write_lock(machine_name, body.lock_user, body.reason, body.requested_by)


@app.post("/api/machines/{machine_name}/release")
def release_machine(machine_name: str, body: ReleaseRequest):
    machines = {m.name: m for m in load_machines()}
    machine = machines.get(machine_name)
    if not machine:
        raise HTTPException(status_code=404, detail="Machine not found")
    if RELEASE_SCRIPT:
        err = run_script(
            RELEASE_SCRIPT.format(
                hostname=machine.hostname,
                machine_name=machine.name,
                reason=body.reason.replace('"', "'"),
            )
        )
        if err:
            raise HTTPException(status_code=500, detail=err)
    return write_release(machine_name, body.reason, body.requested_by)


@app.get("/api/machines/{machine_name}/details")
def machine_details(machine_name: str, live: bool = Query(False, description="Force immediate probe (slower).")):
    machines = {m.name: m for m in load_machines()}
    machine = machines.get(machine_name)
    if not machine:
        raise HTTPException(status_code=404, detail="Machine not found")

    if live:
        payload = collect_machine_details_payload(machine)
        collected_at = save_snapshot(machine.name, payload)
        source = "live"
    else:
        collected_at_cache, cached = get_cached_snapshot(machine_name)
        if cached is None:
            payload = collect_machine_details_payload(machine)
            collected_at = save_snapshot(machine.name, payload)
            source = "live_first"
        else:
            payload = cached
            collected_at = collected_at_cache
            source = "cache"

    return {
        "machine": machine.model_dump(),
        "lock_state": get_lock_state(machine_name),
        **payload,
        "collected_at": collected_at,
        "source": source,
        "poll_interval_seconds": POLL_SECONDS if POLL_ENABLED and POLL_SECONDS > 0 else None,
    }


@app.get("/api/poll/status")
def poll_status():
    return {
        "poll_enabled": POLL_ENABLED and POLL_SECONDS > 0,
        "poll_interval_seconds": POLL_SECONDS if POLL_ENABLED else None,
        "inventory_path": str(INVENTORY_PATH),
        "database_path": str(DB_PATH),
        "data_dir": str(DATA_DIR),
    }


@app.get("/api/machines/{machine_name}/rdp", response_class=PlainTextResponse)
def rdp(machine_name: str):
    machines = {m.name: m for m in load_machines()}
    machine = machines.get(machine_name)
    if not machine:
        raise HTTPException(status_code=404, detail="Machine not found")
    host = machine.ip_address or machine.hostname
    buff = StringIO()
    buff.write("screen mode id:i:2\n")
    buff.write("use multimon:i:0\n")
    buff.write("desktopwidth:i:1920\n")
    buff.write("desktopheight:i:1080\n")
    buff.write("session bpp:i:32\n")
    buff.write(f"full address:s:{host}:{machine.rdp_port}\n")
    buff.write("prompt for credentials on client:i:1\n")
    return PlainTextResponse(
        content=buff.getvalue(),
        media_type="application/rdp",
        headers={"Content-Disposition": f'attachment; filename="{machine.name}.rdp"'},
    )

