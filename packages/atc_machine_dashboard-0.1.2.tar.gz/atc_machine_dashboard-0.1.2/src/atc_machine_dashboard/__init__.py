"""ATC Machine Dashboard — browser UI for lab Windows hosts."""

__version__ = "0.1.2"
