# webcom

[![PyPI - Version](https://img.shields.io/pypi/v/webcom.svg)](https://pypi.org/project/webcom)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/webcom.svg)](https://pypi.org/project/webcom)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install webcom
```

## License

`webcom` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
