"""opalib.units - unit conversion helpers for length and custom measures."""

from typing import Dict

STUD_TO_METER = 0.28
"""Conversion factor from studs to meters."""

_UNIT_FACTORS: Dict[str, float] = {
    "meter": 1.0,
    "meters": 1.0,
    "m": 1.0,
    "stud": STUD_TO_METER,
    "studs": STUD_TO_METER,
    "st": STUD_TO_METER,
    "foot": 0.3048,
    "feet": 0.3048,
    "ft": 0.3048,
    "inch": 0.0254,
    "inches": 0.0254,
    "in": 0.0254,
    "kilometer": 1000.0,
    "kilometers": 1000.0,
    "km": 1000.0,
}

__all__ = [
    "STUD_TO_METER",
    "to_meters",
    "from_meters",
    "convert",
    "register_unit",
    "list_units",
]


def _normalize_unit(unit: str) -> str:
    return unit.strip().lower()


def to_meters(value: float, unit: str) -> float:
    """Convert a value from a supported unit to meters."""
    unit_key = _normalize_unit(unit)
    if unit_key not in _UNIT_FACTORS:
        raise ValueError(f"Unsupported unit: {unit}")
    return value * _UNIT_FACTORS[unit_key]


def from_meters(value: float, unit: str) -> float:
    """Convert a value in meters to a supported unit."""
    unit_key = _normalize_unit(unit)
    if unit_key not in _UNIT_FACTORS:
        raise ValueError(f"Unsupported unit: {unit}")
    return value / _UNIT_FACTORS[unit_key]


def convert(value: float, from_unit: str, to_unit: str) -> float:
    """Convert a value between two supported units."""
    meters = to_meters(value, from_unit)
    return from_meters(meters, to_unit)


def register_unit(name: str, factor_to_meters: float) -> None:
    """Register a custom unit conversion factor to meters."""
    unit_key = _normalize_unit(name)
    if factor_to_meters <= 0:
        raise ValueError("Conversion factor must be positive")
    _UNIT_FACTORS[unit_key] = factor_to_meters


def list_units() -> Dict[str, float]:
    """Return all registered unit conversion factors."""
    return dict(_UNIT_FACTORS)
