"""format - serialization format helpers for opalib."""

from __future__ import annotations

from types import SimpleNamespace
from typing import Any, Callable, Dict, List, Optional, Sequence, Union

from . import util


class RefType:
    def __init__(self) -> None:
        self._cache: Dict[str, Dict[str, Any]] = {}

    def __getattr__(self, name: str) -> Dict[str, Any]:
        if name not in self._cache:
            self._cache[name] = {"type": "ref", "of": name}
        return self._cache[name]


F = SimpleNamespace(
    _VERSION=3,
    ID={},
    V3={},
    Byte={},
    Double={},
    Int={},
    Int64={},
    String={},
    Any={},
    Bool={},
    Ref=RefType(),
)


def map_(k_format: Any, v_format: Any) -> Dict[str, Any]:
    return {"type": "map", "k_format": k_format, "v_format": v_format}


def list_(v_format: Any, key: Optional[str] = None) -> Dict[str, Any]:
    return {"type": "list", "v_format": v_format, "key": key}


def array(len_: int, v_format: Any, key: Optional[str] = None) -> Dict[str, Any]:
    return {"type": "array", "v_format": v_format, "len": len_, "key": key}


def union(*args: Any) -> Dict[str, Any]:
    return {"type": "union", "formats": list(args)}


def struct(fields: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    return {"type": "struct", "fields": list(fields)}


def konst(value: Any, v_format: Any, is_serialized: bool) -> Dict[str, Any]:
    return {
        "type": "konst",
        "value": value,
        "v_format": v_format,
        "is_serialized": is_serialized,
    }


def save(name: str, v_format: Any) -> Dict[str, Any]:
    return {"type": "save", "name": name, "v_format": v_format}


def compat(func: Callable[[Any], Any]) -> Dict[str, Any]:
    return {"type": "compat", "func": func}


def enable_if(cond: Callable[[bytes, int, Any], bool], v_format: Any) -> Dict[str, Any]:
    return {"type": "enable_if", "cond": cond, "v_format": v_format}


def format_(name: str, t: Dict[str, Any]) -> Dict[str, Any]:
    t["name"] = name
    setattr(F, name, t)
    return t


def new(name: str, t: Dict[str, Any]) -> Dict[str, Any]:
    t["name"] = name
    setattr(F, name, t)
    return t


def GE_VER(ver: int, on_true: Any, on_false: Any) -> Dict[str, Any]:
    return compat(lambda ctx: on_true if getattr(ctx, "version", 0) >= ver else on_false)


F.map = map_
F.list = list_
F.array = array
F.union = union
F.struct = struct
F.konst = konst
F.save = save
F.compat = compat
F.enable_if = enable_if
F.format = format_
F.new = new
F.GE_VER = GE_VER


def _load_string(data: bytes, i: int) -> tuple[str, int]:
    return util.read_s(data, i)


def _load_bool(data: bytes, i: int) -> tuple[bool, int]:
    b = data[i]
    return b == 1, i + 1


def _load_v3(data: bytes, i: int) -> tuple[util.Vector3, int]:
    return util.read_v(data, i)


def _load_byte(data: bytes, i: int) -> tuple[int, int]:
    return data[i], i + 1


def _load_double(data: bytes, i: int) -> tuple[float, int]:
    return util.read_d(data, i)


def _load_int(data: bytes, i: int) -> tuple[int, int]:
    return util.read_i(data, i)


def _load_int64(data: bytes, i: int) -> tuple[int, int]:
    return util.read_i64(data, i)


def _load_any(data: bytes, i: int) -> tuple[Any, int]:
    return util.read_a(data, i)


def _save_string(data: List[bytes], value: str) -> None:
    util.a(data, util.s2b(value))


def _save_bool(data: List[bytes], value: bool) -> None:
    util.a(data, b"\x01" if value else b"\x00")


def _save_v3(data: List[bytes], value: util.Vector3) -> None:
    util.a(data, util.v2b(value))


def _save_byte(data: List[bytes], value: int) -> None:
    util.a(data, bytes([value]))


def _save_double(data: List[bytes], value: float) -> None:
    util.a(data, util.d2b(value))


def _save_int(data: List[bytes], value: int) -> None:
    util.a(data, util.i2b(value))


def _save_int64(data: List[bytes], value: int) -> None:
    util.a(data, util.i642b(value))


def _save_any(data: List[bytes], value: Any) -> None:
    util.a(data, util.a2b(value))


F.String["load"] = _load_string
F.Bool["load"] = _load_bool
F.V3["load"] = _load_v3
F.Byte["load"] = _load_byte
F.Double["load"] = _load_double
F.Int["load"] = _load_int
F.Int64["load"] = _load_int64
F.Any["load"] = _load_any

F.String["save"] = _save_string
F.Bool["save"] = _save_bool
F.V3["save"] = _save_v3
F.Byte["save"] = _save_byte
F.Double["save"] = _save_double
F.Int["save"] = _save_int
F.Int64["save"] = _save_int64
F.Any["save"] = _save_any


F.new(
    "Challenge",
    F.struct(
        [
            {"signature": F.array(16, F.Byte)},
            {"issued": F.Int64},
            {"difficulty": F.Byte},
            {"K00": F.Int},
            {"K01": F.Int},
            {"K10": F.Int},
            {"K11": F.Int},
        ]
    ),
)

F.new(
    "Solution",
    F.struct(
        [
            {"x": F.Int},
            {"y": F.Int},
        ]
    ),
)

__all__ = ["F", "RefType"]
