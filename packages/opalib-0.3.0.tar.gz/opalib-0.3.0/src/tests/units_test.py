"""Unit tests for opalib.units."""

import unittest
from src import convert, STUD_TO_METER, list_units, register_unit


class TestUnits(unittest.TestCase):
    def test_convert_studs_to_meters(self):
        self.assertAlmostEqual(convert(1, "studs", "meters"), STUD_TO_METER)

    def test_convert_meters_to_studs(self):
        self.assertAlmostEqual(convert(0.28, "meters", "studs"), 1.0, places=6)

    def test_convert_feet_to_studs(self):
        self.assertAlmostEqual(convert(1, "feet", "studs"), 0.3048 / STUD_TO_METER, places=6)

    def test_register_custom_unit(self):
        register_unit("test-unit", 2.5)
        self.assertAlmostEqual(convert(2, "test-unit", "meters"), 5.0)
        self.assertIn("test-unit", list_units())

    def test_unsupported_unit(self):
        with self.assertRaises(ValueError):
            convert(1, "unknown", "meters")
