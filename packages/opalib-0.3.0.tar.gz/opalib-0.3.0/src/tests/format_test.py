"""Tests for the format module."""

import unittest
from src import format, util


class TestFormat(unittest.TestCase):
    def test_bool_save_load(self):
        data = []
        format.F.Bool["save"](data, True)
        result, _ = util.read_a(b"".join(data), 0)
        self.assertTrue(result)

    def test_string_save_and_read(self):
        data = []
        format.F.String["save"](data, "hello")
        result, _ = util.read_s(b"".join(data), 0)
        self.assertEqual(result, "hello")

    def test_challenge_format_defined(self):
        self.assertTrue(hasattr(format.F, "Challenge"))
        self.assertTrue(isinstance(format.F.Challenge, dict))
