# Drive Reorganizer

A CLI tool that reads your Google Drive folder structure and uses Claude AI to suggest a smarter reorganization.

## How it works

1. Authenticates with Google Drive via OAuth (read-only access)
2. Fetches your entire folder structure and file metadata in a single API sweep
3. Sends the structure to Claude, which analyzes it and suggests improvements
4. Displays the current structure and AI suggestions in the terminal

No file contents are ever read — only names, types, and modification dates.

## Installation

```bash
pip install drive-reorganizer
```

## Setup

Run the interactive setup wizard:

```bash
drive-reorganizer setup
```

The wizard will guide you through:

1. **Anthropic API key** — enter your key when prompted; it's saved to `~/.config/drive-reorganizer/config.json`
2. **Google Drive authentication** — a browser window opens for sign-in; your token is cached automatically

All configuration is stored in `~/.config/drive-reorganizer/` — nothing is written to the project directory.

## Usage

```bash
drive-reorganizer analyze
```

On subsequent runs, authentication is skipped (cached token is reused automatically).

### Options

```
--no-browser    Use console-based OAuth (for headless/SSH environments)
--no-color      Disable colored output (useful for piping to a file)
```

### Other commands

```bash
# Check that all configuration is in place
drive-reorganizer doctor

# Re-authenticate with Google (replaces saved token)
drive-reorganizer reauth

# Show version
drive-reorganizer --version
```

## Privacy

- OAuth scope: `drive.metadata.readonly` — cannot read file contents
- File contents are never fetched or sent to Claude
- Suggestions are read-only; nothing in your Drive is modified
