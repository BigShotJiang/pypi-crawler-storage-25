from src.drive_reorganizer.drive.models import DriveTree


def test_build_tree_structure(drive_tree):
    assert isinstance(drive_tree, DriveTree)
    assert drive_tree.root.name == "My Drive"
    assert drive_tree.root.is_folder


def test_build_tree_children_attached(drive_tree):
    root_child_names = {c.name for c in drive_tree.root.children}
    assert "Projects" in root_child_names
    assert "Downloads" in root_child_names
    assert "Random stuff" in root_child_names


def test_build_tree_nested_folders(drive_tree):
    projects = next(c for c in drive_tree.root.children if c.name == "Projects")
    project_child_names = {c.name for c in projects.children}
    assert "OldWebsite" in project_child_names
    assert "CurrentApp" in project_child_names


def test_build_tree_folders_sorted_first(drive_tree):
    # Folders should come before files in children list
    children = drive_tree.root.children
    folder_indices = [i for i, c in enumerate(children) if c.is_folder]
    file_indices = [i for i, c in enumerate(children) if not c.is_folder]
    if folder_indices and file_indices:
        assert max(folder_indices) < min(file_indices)


def test_build_tree_total_items(drive_tree, fixture_data):
    _, items = fixture_data
    # total_items counts all items indexed by id (root + 7 items in fixture)
    assert drive_tree.total_items == len(items)
