from datetime import datetime, timezone

import pytest

from src.drive_reorganizer.ai.prompts import build_prompt, _serialize_tree


def test_build_prompt_contains_structure(drive_tree):
    prompt = build_prompt(drive_tree)
    assert "My Drive" in prompt
    assert "Projects" in prompt
    assert "Downloads" in prompt


def test_build_prompt_contains_date(drive_tree):
    prompt = build_prompt(drive_tree)
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    assert today in prompt


def test_build_prompt_contains_total_items(drive_tree):
    prompt = build_prompt(drive_tree)
    assert str(drive_tree.total_items) in prompt


def test_serialize_tree_depth_limit(drive_tree):
    serialized = _serialize_tree(drive_tree.root, depth=0)
    # Should not recurse beyond TREE_DEPTH
    lines = serialized.splitlines()
    max_indent = max(len(line) - len(line.lstrip()) for line in lines if line.strip())
    assert max_indent <= 10  # TREE_DEPTH=4, 2 spaces each = 8, some buffer
