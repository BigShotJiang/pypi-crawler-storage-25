"""Tests for AgentProbingPatternDetector — Feature 2."""

from insa_its.detectors.agent_probing import AgentProbingPatternDetector


def _make_calls(paths):
    """Helper: create tool_call_sequence from list of paths."""
    return [{"tool_input": {"file_path": p}} for p in paths]


class TestAgentProbingDetector:
    """Test probing pattern detection."""

    def setup_method(self):
        self.detector = AgentProbingPatternDetector()

    def test_sequential_semantic_paths_no_anomaly(self):
        """Sequential paths in same directory should NOT trigger."""
        paths = [
            "utils/auth.py", "utils/auth_helper.py", "utils/auth_token.py",
            "utils/auth_middleware.py", "utils/auth_config.py",
            "utils/auth_session.py", "utils/auth_validator.py",
            "utils/auth_factory.py", "utils/auth_service.py",
            "utils/auth_handler.py", "utils/auth_provider.py",
            "utils/auth_manager.py", "utils/auth_context.py",
            "utils/auth_decorator.py", "utils/auth_utils.py",
        ]
        result = self.detector.detect(_make_calls(paths))
        assert result is None, f"Should not fire on semantic paths, got: {result}"

    def test_alphabetical_enumeration_fires(self):
        """Alphabetical single-letter files should trigger."""
        paths = [f"{chr(c)}.py" for c in range(ord("a"), ord("p"))]  # a.py to o.py
        result = self.detector.detect(_make_calls(paths))
        assert result is not None, "Should detect alphabetical enumeration"
        assert result["severity"] == "HIGH"
        assert result["type"] == "agent_probing_pattern"

    def test_grid_exploration_high_confidence(self):
        """Grid pattern (row/col) should trigger with confidence > 0.6."""
        paths = []
        for row in range(1, 6):
            for col in range(1, 4):
                paths.append(f"row{row}/col{col}")
        result = self.detector.detect(_make_calls(paths))
        assert result is not None, "Should detect grid exploration"
        assert result["confidence"] > 0.6, f"Confidence should be > 0.6, got {result['confidence']}"

    def test_short_sequence_returns_none(self):
        """Fewer than WINDOW calls should return None without crash."""
        paths = [f"file{i}.py" for i in range(8)]
        result = self.detector.detect(_make_calls(paths))
        assert result is None

    def test_empty_tool_input_returns_none(self):
        """Empty tool_input dicts should return None without crash."""
        calls = [{"tool_input": {}} for _ in range(20)]
        result = self.detector.detect(calls)
        assert result is None
