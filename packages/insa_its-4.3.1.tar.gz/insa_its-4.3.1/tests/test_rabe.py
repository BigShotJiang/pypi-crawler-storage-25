"""Tests for RABE (Rogue Agent Behavioral Exporter) — Feature 3."""

import json
from pathlib import Path

from insa_its.exporters.rabe import export_rabe, EXCLUDED_TYPES


def _write_audit(entries, path):
    """Write JSONL audit file from list of dicts."""
    with open(path, "w", encoding="utf-8") as f:
        for e in entries:
            f.write(json.dumps(e) + "\n")


class TestRABEExport:
    """Test RABE behavioral export."""

    def test_valid_export_with_anomalies(self, tmp_path):
        """Full export with pre-catch window and anomaly progression."""
        sid = "test-session-001"
        entries = [
            {"session_id": sid, "tool": "Read", "tool_input": {"file_path": "src/main.py"}, "ts": "2026-04-01T10:00:00Z"},
            {"session_id": sid, "tool": "Edit", "tool_input": {"file_path": "src/main.py"}, "ts": "2026-04-01T10:00:05Z"},
            {"session_id": sid, "tool": "Bash", "tool_input": {"command": "pytest"}, "ts": "2026-04-01T10:00:10Z"},
            {"session_id": sid, "tool": "Read", "tool_input": {"file_path": ".env"}, "ts": "2026-04-01T10:00:15Z",
             "anomalies": [{"type": "behavioral_fingerprint", "severity": "HIGH"}]},
            {"session_id": sid, "tool": "Read", "tool_input": {"file_path": "secrets.json"}, "ts": "2026-04-01T10:00:20Z",
             "anomalies": [{"type": "tool_call_frequency_anomaly", "severity": "MEDIUM"}]},
        ]
        audit_path = str(tmp_path / "audit.jsonl")
        out_path = str(tmp_path / "rabe_out.json")
        _write_audit(entries, audit_path)

        result = export_rabe(sid, audit_path, out_path)

        assert result["rabe_version"] == "1.0"
        assert result["session_id"] == sid
        assert result["catch_confirmed"] is True
        assert result["pre_catch_window"]["message_count"] == 3
        assert result["pre_catch_window"]["tool_call_count"] == 3
        assert result["pre_catch_window"]["first_anomaly_fired"] == "behavioral_fingerprint"
        assert result["anomaly_count_total"] == 2
        assert result["estimated_objective"] in ("credential_harvest", "code_exfiltration", "lateral_movement", "unknown")
        assert 0.0 <= result["threat_score"] <= 1.0
        assert Path(out_path).exists()
        saved = json.loads(Path(out_path).read_text(encoding="utf-8"))
        assert saved["session_id"] == sid

    def test_no_anomalies_returns_error(self, tmp_path):
        """Session with no real anomalies should return error dict."""
        sid = "clean-session"
        entries = [
            {"session_id": sid, "tool": "Read", "tool_input": {"file_path": "a.py"}, "ts": "2026-04-01T10:00:00Z"},
            {"session_id": sid, "tool": "Edit", "tool_input": {"file_path": "b.py"}, "ts": "2026-04-01T10:00:05Z"},
            {"session_id": sid, "tool": "Read", "anomalies": [{"type": "context_compression"}]},
        ]
        audit_path = str(tmp_path / "audit.jsonl")
        out_path = str(tmp_path / "rabe_out.json")
        _write_audit(entries, audit_path)

        result = export_rabe(sid, audit_path, out_path)
        assert result["error"] == "no_real_anomalies_found"
        assert result["total_entries"] == 3

    def test_excluded_types_filtered(self, tmp_path):
        """Meta-events in EXCLUDED_TYPES should not count as first anomaly."""
        sid = "meta-session"
        entries = [
            {"session_id": sid, "tool": "Read", "anomalies": [{"type": "replay_detected"}]},
            {"session_id": sid, "tool": "Read", "anomalies": [{"type": "context_compression"}]},
            {"session_id": sid, "tool": "Read", "anomalies": [{"type": "milestone"}]},
            {"session_id": sid, "tool": "Read", "anomalies": [{"type": "chain_tampering", "severity": "CRITICAL"}]},
        ]
        audit_path = str(tmp_path / "audit.jsonl")
        out_path = str(tmp_path / "rabe_out.json")
        _write_audit(entries, audit_path)

        result = export_rabe(sid, audit_path, out_path)
        assert "error" not in result
        assert result["pre_catch_window"]["first_anomaly_fired"] == "chain_tampering"
        assert result["pre_catch_window"]["messages_before_first_anomaly"] == 3

    def test_missing_session_returns_error(self, tmp_path):
        """Non-existent session ID should return session_not_found error."""
        sid = "nonexistent"
        entries = [
            {"session_id": "other-session", "tool": "Read"},
        ]
        audit_path = str(tmp_path / "audit.jsonl")
        out_path = str(tmp_path / "rabe_out.json")
        _write_audit(entries, audit_path)

        result = export_rabe(sid, audit_path, out_path)
        assert result["error"] == "session_not_found"

    def test_missing_audit_file_returns_error(self, tmp_path):
        """Non-existent audit file should return audit_file_not_found error."""
        result = export_rabe("any-sid", str(tmp_path / "missing.jsonl"), str(tmp_path / "out.json"))
        assert result["error"] == "audit_file_not_found"

    def test_credential_objective_detection(self, tmp_path):
        """Sessions probing credential files should detect credential_harvest."""
        sid = "cred-probe"
        entries = [
            {"session_id": sid, "tool": "Read", "tool_input": {"file_path": ".env"}, "ts": "2026-04-01T10:00:00Z"},
            {"session_id": sid, "tool": "Read", "tool_input": {"file_path": "secrets.json"}, "ts": "2026-04-01T10:00:02Z"},
            {"session_id": sid, "tool": "Read", "tool_input": {"file_path": "api_key.txt"}, "ts": "2026-04-01T10:00:04Z"},
            {"session_id": sid, "tool": "Read", "tool_input": {"file_path": "token.pem"}, "ts": "2026-04-01T10:00:06Z"},
            {"session_id": sid, "tool": "Read", "tool_input": {"file_path": "password.txt"}, "ts": "2026-04-01T10:00:08Z",
             "anomalies": [{"type": "behavioral_fingerprint", "severity": "HIGH"}]},
        ]
        audit_path = str(tmp_path / "audit.jsonl")
        out_path = str(tmp_path / "rabe_out.json")
        _write_audit(entries, audit_path)

        result = export_rabe(sid, audit_path, out_path)
        assert result["estimated_objective"] == "credential_harvest"
        assert result["objective_signals"]["credential_harvest"] > 0
