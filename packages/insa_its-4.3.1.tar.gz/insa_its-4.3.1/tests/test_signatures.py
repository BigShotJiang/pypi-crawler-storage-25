"""Tests for InsAIts Learning — Session Signatures."""

import json
from pathlib import Path

import pytest

from insa_its.learning.signatures import (
    build_signature,
    load_signatures,
    append_signature,
    compare_session,
    _compute_tool_sequence_hash,
    _compute_anomaly_distribution,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def sample_session():
    return {
        "session_id": "test-session-001",
        "tool_calls": ["Read", "Grep", "Edit", "Bash", "Read"],
        "anomalies": [
            {"type": "shadow_server", "severity": "MEDIUM"},
            {"type": "hallucination_chain", "severity": "HIGH"},
            {"type": "shadow_server", "severity": "MEDIUM"},
        ],
        "duration_seconds": 600,
        "files_touched": ["foo.py", "bar.py", "baz.py", "foo.py"],
        "label": "good",
    }


@pytest.fixture
def tmp_sig_dir(tmp_path):
    sig_dir = tmp_path / "signatures"
    sig_dir.mkdir()
    return sig_dir


# ---------------------------------------------------------------------------
# Test build_signature
# ---------------------------------------------------------------------------

class TestBuildSignature:
    def test_basic_structure(self, sample_session):
        sig = build_signature(sample_session)
        assert sig["session_id"] == "test-session-001"
        assert sig["tool_count"] == 5
        assert sig["anomaly_count"] == 3
        assert sig["file_diversity"] == 3  # foo, bar, baz (deduped)
        assert sig["duration_seconds"] == 600
        assert sig["label"] == "good"
        assert "tool_sequence_hash" in sig
        assert "calls_per_minute" in sig
        assert "created_at" in sig

    def test_anomaly_distribution(self, sample_session):
        sig = build_signature(sample_session)
        assert sig["anomaly_distribution"] == {
            "shadow_server": 2,
            "hallucination_chain": 1,
        }

    def test_calls_per_minute(self, sample_session):
        sig = build_signature(sample_session)
        # 5 calls / 10 minutes = 0.5
        assert sig["calls_per_minute"] == 0.5

    def test_empty_session(self):
        sig = build_signature({})
        assert sig["tool_count"] == 0
        assert sig["anomaly_count"] == 0
        assert sig["file_diversity"] == 0
        assert sig["calls_per_minute"] == 0.0


# ---------------------------------------------------------------------------
# Test load_signatures / append_signature
# ---------------------------------------------------------------------------

class TestSignatureIO:
    def test_load_empty_dir(self, tmp_sig_dir):
        sigs = load_signatures(tmp_sig_dir)
        assert sigs == []

    def test_append_and_load(self, tmp_sig_dir, sample_session):
        sig = build_signature(sample_session)
        assert append_signature(sig, tmp_sig_dir) is True

        loaded = load_signatures(tmp_sig_dir)
        assert len(loaded) == 1
        assert loaded[0]["session_id"] == "test-session-001"

    def test_append_multiple(self, tmp_sig_dir):
        for i in range(3):
            sig = build_signature({
                "session_id": f"session-{i}",
                "tool_calls": ["Read"] * (i + 1),
                "anomalies": [],
                "duration_seconds": 100,
                "files_touched": [],
            })
            append_signature(sig, tmp_sig_dir)

        loaded = load_signatures(tmp_sig_dir)
        assert len(loaded) == 3

    def test_load_with_corrupt_line(self, tmp_sig_dir):
        sig_file = tmp_sig_dir / "signature_library.jsonl"
        sig_file.write_text(
            '{"session_id": "good"}\n'
            'NOT JSON\n'
            '{"session_id": "also-good"}\n'
        )
        loaded = load_signatures(tmp_sig_dir)
        assert len(loaded) == 2


# ---------------------------------------------------------------------------
# Test compare_session
# ---------------------------------------------------------------------------

class TestCompareSession:
    def test_no_signatures_returns_insufficient(self, sample_session):
        result = compare_session(sample_session, [])
        assert result["verdict"] == "insufficient_data"
        assert result["closest_match"] is None
        assert result["similarity_score"] == 0.0

    def test_exact_match(self, sample_session):
        lib_sig = build_signature(sample_session)
        lib_sig["label"] = "good"

        result = compare_session(sample_session, [lib_sig])
        assert result["similarity_score"] >= 0.8
        assert result["verdict"] == "known_good"
        assert "tool_sequence" in result["matching_dimensions"]

    def test_known_bad_match(self, sample_session):
        lib_sig = build_signature(sample_session)
        lib_sig["label"] = "bad"

        result = compare_session(sample_session, [lib_sig])
        assert result["verdict"] == "known_bad"

    def test_novel_session(self):
        current = {
            "session_id": "new-session",
            "tool_calls": ["Write", "Write", "Write"],
            "anomalies": [{"type": "prompt_injection", "severity": "CRITICAL"}],
            "duration_seconds": 30,
            "files_touched": ["x.py"],
        }
        lib_sig = build_signature({
            "session_id": "old-session",
            "tool_calls": ["Read", "Grep", "Read", "Grep"],
            "anomalies": [],
            "duration_seconds": 3600,
            "files_touched": ["a.py", "b.py", "c.py", "d.py", "e.py"],
            "label": "good",
        })

        result = compare_session(current, [lib_sig])
        # Very different sessions — should be novel or low score
        assert result["similarity_score"] < 0.6 or result["verdict"] == "novel"


# ---------------------------------------------------------------------------
# Test helpers
# ---------------------------------------------------------------------------

class TestHelpers:
    def test_tool_sequence_hash_deterministic(self):
        h1 = _compute_tool_sequence_hash(["Read", "Edit", "Bash"])
        h2 = _compute_tool_sequence_hash(["Read", "Edit", "Bash"])
        assert h1 == h2

    def test_tool_sequence_hash_order_matters(self):
        h1 = _compute_tool_sequence_hash(["Read", "Edit"])
        h2 = _compute_tool_sequence_hash(["Edit", "Read"])
        assert h1 != h2

    def test_anomaly_distribution_empty(self):
        assert _compute_anomaly_distribution([]) == {}

    def test_anomaly_distribution_counts(self):
        anomalies = [
            {"type": "a"}, {"type": "b"}, {"type": "a"}, {"type": "a"},
        ]
        dist = _compute_anomaly_distribution(anomalies)
        assert dist == {"a": 3, "b": 1}
