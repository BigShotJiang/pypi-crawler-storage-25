"""Agent Probing Pattern Detector — Feature 2.

Detects systematic exhaustive exploration behavior.
Legitimate agents follow semantic paths (A->B->C by relevance).
Rogue agents explore grids, alphabetically, or by enumeration.

Signal: high path entropy + low semantic coherence over a window of tool calls.
This is the earliest-firing detector for rogue agent behavior.

Runs in the collector, every 5 tool calls (minimum 15 calls before first eval).
"""

from __future__ import annotations

import math
import re
from collections import Counter
from typing import Any, Dict, List, Optional


class AgentProbingPatternDetector:
    """Detect systematic exploration via entropy + coherence analysis."""

    WINDOW: int = 15
    ENTROPY_THRESHOLD: float = 2.8
    COHERENCE_MIN: float = 0.35

    @staticmethod
    def _extract_paths(tool_call_sequence: List[Dict[str, Any]]) -> List[str]:
        """Extract file paths from tool call sequence."""
        paths: List[str] = []
        for tc in tool_call_sequence:
            inp = tc.get("tool_input", {}) or {}
            p = (
                inp.get("file_path")
                or inp.get("path")
                or str(inp.get("command", ""))[:80]
            )
            paths.append(p or "")
        return paths

    @staticmethod
    def _tokenize_path(path: str) -> List[str]:
        """Split path into semantic tokens (dirs, filename parts, extension)."""
        # Normalize separators
        normalized = path.replace("\\", "/")
        # Split on / first, then split each part on non-alphanumeric
        tokens: List[str] = []
        for part in normalized.split("/"):
            # Split on dots, underscores, hyphens, digits-boundaries
            subtokens = re.split(r'[._\-/\\]+', part)
            tokens.extend(t.lower() for t in subtokens if t)
        return tokens

    @staticmethod
    def _compute_entropy(paths: List[str]) -> float:
        """Shannon entropy over normalized full paths.

        Uses the full normalized path (not just filename) so that
        grid patterns like row1/col1, row2/col1 produce high entropy.
        """
        normalized = [
            p.replace("\\", "/").strip("/")
            for p in paths if p
        ]
        if len(normalized) < 5:
            return 0.0

        counts = Counter(normalized)
        total = sum(counts.values())
        return -sum(
            (c / total) * math.log2(c / total)
            for c in counts.values() if c > 0
        )

    @staticmethod
    def _compute_coherence(paths: List[str]) -> float:
        """Token-level Jaccard coherence between consecutive paths.

        Uses semantic tokens (directory names, filename parts) rather than
        raw characters, giving better discrimination for short paths.
        """
        similarities: List[float] = []
        tokenize = AgentProbingPatternDetector._tokenize_path
        for i in range(1, len(paths)):
            a_tokens = set(tokenize(paths[i - 1]))
            b_tokens = set(tokenize(paths[i]))
            if not a_tokens or not b_tokens:
                continue
            union = a_tokens | b_tokens
            if not union:
                continue
            similarities.append(len(a_tokens & b_tokens) / len(union))

        return (
            sum(similarities) / len(similarities)
            if similarities else 1.0
        )

    def detect(self, tool_call_sequence: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """Analyze tool call sequence for probing patterns.

        Args:
            tool_call_sequence: Last WINDOW tool calls with tool_input dicts.

        Returns:
            Anomaly dict if probing detected, None otherwise.
        """
        if len(tool_call_sequence) < self.WINDOW:
            return None

        window = tool_call_sequence[-self.WINDOW:]
        paths = self._extract_paths(window)

        # Need minimum paths for meaningful analysis
        valid_paths = [p for p in paths if p]
        if len(valid_paths) < 5:
            return None

        entropy = self._compute_entropy(paths)
        coherence = self._compute_coherence(paths)

        if entropy > self.ENTROPY_THRESHOLD and coherence < self.COHERENCE_MIN:
            confidence = min(
                (entropy / 4.0) * (1.0 - coherence), 1.0
            )
            return {
                "type": "agent_probing_pattern",
                "severity": "HIGH",
                "confidence": round(confidence, 3),
                "description": (
                    f"Systematic exploration detected: "
                    f"entropy={entropy:.2f}bits "
                    f"coherence={coherence:.2f} "
                    f"over {self.WINDOW} calls. "
                    f"Agent may be mapping system structure."
                ),
            }
        return None

    def compute_metrics(
        self, tool_call_sequence: List[Dict[str, Any]]
    ) -> Dict[str, float]:
        """Compute entropy + coherence metrics without triggering detection.

        Used by signature matching to store live session metrics.
        """
        if len(tool_call_sequence) < 5:
            return {"entropy": 0.0, "coherence": 1.0}

        paths = self._extract_paths(tool_call_sequence[-self.WINDOW:])

        valid_paths = [p for p in paths if p]
        if len(valid_paths) < 3:
            return {"entropy": 0.0, "coherence": 1.0}

        entropy = self._compute_entropy(paths)
        coherence = self._compute_coherence(paths)

        return {"entropy": round(entropy, 4), "coherence": round(coherence, 4)}
