"""InsAIts Collector — Central event stream hub.

Usage:
    python -m insa_its.collector          # start on default port 5003
    python -m insa_its.collector --port 5010
    insaits-collector                     # console script entry point

This module uses lazy imports so that ``insaits-collector`` starts in <1s
without loading torch / sentence-transformers.
"""


def main():
    """Entry point — imports server.py directly, bypasses heavy SDK init."""
    import importlib.util
    import os
    spec = importlib.util.spec_from_file_location(
        "insa_its.collector.server",
        os.path.join(os.path.dirname(__file__), "server.py"),
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    mod.main()


__all__ = ["main"]
