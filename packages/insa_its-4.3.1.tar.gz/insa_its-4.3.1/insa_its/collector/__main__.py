"""Allow ``python -m insa_its.collector``.

Uses importlib to load server.py directly, bypassing the heavy
insa_its/__init__.py (which loads torch/sentence-transformers ~44s).
"""
import importlib.util
import os


def main():
    spec = importlib.util.spec_from_file_location(
        "insa_its.collector.server",
        os.path.join(os.path.dirname(__file__), "server.py"),
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    mod.main()


if __name__ == "__main__":
    main()
