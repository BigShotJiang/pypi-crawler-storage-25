"""
InsAIts SDK - Base Types
========================
Shared enums and data classes used across the SDK.
Extracted so both ai_monitor.py and premium/_ai_monitor_core.py
can import without circular dependencies.
"""

from dataclasses import dataclass, field
from typing import Any, List, Optional
from enum import Enum


# -------------------------------------------
# ENUMS & DATA MODELS
# -------------------------------------------
# Note: AISeverity uses UPPERCASE values for display in interventions.
# This is distinct from insa_its.models.Severity which uses lowercase.

class AnomalyType(str, Enum):
    """Types of anomalies detected in LLM responses."""
    BLANK_RESPONSE = "blank_response"
    WAITING_FOR_DESCRIPTION = "waiting_for_description"
    INCOMPLETE_CODE = "incomplete_code"
    CONTEXT_COLLAPSE = "context_collapse"
    SEMANTIC_DRIFT = "semantic_drift"
    REPETITION_LOOP = "repetition_loop"
    REFUSAL_DRIFT = "refusal_drift"
    TOOL_CALL_HANG = "tool_call_hang"
    TRUNCATED_OUTPUT = "truncated_output"
    CONFIDENCE_COLLAPSE = "confidence_collapse"
    # OWASP V3.1.2 security anomaly types
    CREDENTIAL_EXPOSURE = "credential_exposure"
    PROMPT_INJECTION = "prompt_injection"
    # OWASP V3.1.4 — wired detectors
    TOOL_POISONING = "tool_poisoning"
    DATA_EXFILTRATION = "data_exfiltration"
    ROGUE_AGENT = "rogue_agent"
    UNAUTHORIZED_ACCESS = "unauthorized_access"
    HALLUCINATION_CHAIN = "hallucination_chain"
    SHORTHAND_EMERGENCE = "shorthand_emergence"
    UNCERTAINTY_PROPAGATION = "uncertainty_propagation"
    SHADOW_SERVER = "shadow_server"
    PHANTOM_CITATION = "phantom_citation"
    PROMPT_MANIPULATION = "prompt_manipulation"
    MEMORY_POISONING = "memory_poisoning"
    GOVERNANCE_GAP = "governance_gap"
    # V3.2.0 — advanced security detectors
    EXFILTRATION_PATTERN = "exfiltration_pattern"
    ENTROPY_COVERT_CHANNEL = "entropy_covert_channel"


class AISeverity(str, Enum):
    """Severity levels for AI response anomalies (UPPERCASE display values)."""
    INFO = "INFO"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class InterventionAction(str, Enum):
    """Actions the intervention engine can take."""
    LOG = "log"
    INJECT_HINT = "inject_hint"
    RETRY = "retry"
    ESCALATE = "escalate"
    ABORT = "abort"


@dataclass
class AIAnomaly:
    """An anomaly detected in an LLM response, with corrective intervention text."""
    anomaly_type: AnomalyType
    severity: AISeverity
    description: str
    confidence: float
    action: InterventionAction
    intervention: str
    metadata: dict = field(default_factory=dict)


@dataclass
class AIMonitorResult:
    """Result of monitoring an LLM response, including retry information."""
    original_response: str
    final_response: str
    anomalies: List[AIAnomaly]
    retries: int
    latency_ms: float
    session_id: str
    message_id: str
    timestamp: str
    resolved: bool
    timestamp_us: int = 0

    @property
    def clean(self) -> bool:
        """True if no anomalies were detected."""
        return len(self.anomalies) == 0

    @property
    def critical(self) -> bool:
        """True if any anomaly is CRITICAL severity."""
        return any(a.severity == AISeverity.CRITICAL for a in self.anomalies)


__all__ = [
    "AnomalyType",
    "AISeverity",
    "InterventionAction",
    "AIAnomaly",
    "AIMonitorResult",
]
