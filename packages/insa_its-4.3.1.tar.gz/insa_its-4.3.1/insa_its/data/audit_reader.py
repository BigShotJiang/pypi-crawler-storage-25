"""
InsAIts API - Audit Log Reader (Shared)
========================================
Single JSONL audit-log reader used by both ``insaits_web_dashboard.py``
and ``routers/export.py``.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List


def read_audit_entries(log_path: str) -> List[Dict[str, Any]]:
    """Read all entries from a JSONL audit log.

    Skips blank lines and lines that are not valid JSON.
    Returns an empty list when the file does not exist or cannot be read.
    """
    entries: List[Dict[str, Any]] = []
    path = Path(log_path)
    if not path.exists():
        return entries
    try:
        with open(path, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    except (IOError, OSError):
        pass
    return entries
