"""InsAIts shared data modules — OWASP mappings, audit reader."""
