"""Allow running the hook with: python3 -m insa_its.hooks"""
from .claude_code_hook import main

main()
