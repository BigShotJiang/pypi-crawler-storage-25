"""
InsAIts Adaptive Context Manager (ACM)
========================================
Reduces cache read token consumption by 60-70% without degrading
reasoning quality. Classifies context as HOT (load-bearing) or
COLD (settled, safe to compress). Never deletes — only compresses.

Modules:
  settlement_detector       — detects when a tool result has been acted on
  adaptive_context_manager  — classifies and compresses context items
  quality_guard             — safety layer that vetoes unsafe compressions
"""

from insa_its.context.settlement_detector import SettlementDetector
from insa_its.context.adaptive_context_manager import (
    AdaptiveContextManager,
    ContextState,
)
from insa_its.context.quality_guard import QualityGuard, ApprovalResult

__all__ = [
    "SettlementDetector",
    "AdaptiveContextManager",
    "ContextState",
    "QualityGuard",
    "ApprovalResult",
]
