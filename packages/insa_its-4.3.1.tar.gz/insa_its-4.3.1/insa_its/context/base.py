"""
InsAIts Context Module - Base Types
====================================
Shared enums and data classes for the ACM (Adaptive Context Manager).
Extracted so both public stubs and premium implementations can import
without circular dependencies.
"""

from __future__ import annotations

from enum import Enum
from typing import List


class ApprovalResult(Enum):
    APPROVED = "approved"
    PARTIAL = "partial"
    VETOED = "vetoed"


class VetoReason:
    """Describes why a compression was vetoed."""

    def __init__(self, condition: str, detail: str) -> None:
        self.condition = condition
        self.detail = detail

    def __repr__(self) -> str:
        return f"VetoReason({self.condition}: {self.detail})"


class CompressionApproval:
    """Result of a quality guard review."""

    def __init__(
        self,
        result: ApprovalResult,
        approved_indices: List[int],
        vetoed_indices: List[int],
        reasons: List[VetoReason],
    ) -> None:
        self.result = result
        self.approved_indices = approved_indices
        self.vetoed_indices = vetoed_indices
        self.reasons = reasons

    @property
    def approved(self) -> bool:
        return self.result in (ApprovalResult.APPROVED, ApprovalResult.PARTIAL)


class ContextState(Enum):
    HOT = "hot"
    COLD = "cold"


__all__ = [
    "ApprovalResult",
    "VetoReason",
    "CompressionApproval",
    "ContextState",
]
