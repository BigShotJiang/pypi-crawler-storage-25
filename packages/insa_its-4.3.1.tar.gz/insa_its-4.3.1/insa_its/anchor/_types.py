"""
Shared types for the anchor injection system.
Separated to avoid circular imports between facade and premium modules.
"""

from enum import Enum


class TriggerType(Enum):
    SESSION_START = "session_start"
    AGENT_SPAWN = "agent_spawn"
    SUBAGENT_SPAWN = "subagent_spawn"
    SUBAGENT_PERIODIC = "subagent_periodic"
    ANOMALY_THRESHOLD = "anomaly_threshold"
    OPUS_PERIODIC = "opus_periodic"
    CRITICAL_EVENT = "critical_event"
