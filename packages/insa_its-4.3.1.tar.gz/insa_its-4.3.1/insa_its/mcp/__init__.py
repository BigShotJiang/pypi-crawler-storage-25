"""
InsAIts MCP Package
===================
Model Context Protocol server for InsAIts AI Monitor.

Provides 4 tools for Claude Code:
- insaits_check: Quality gate (call after every response)
- insaits_preflight: Task ambiguity check (call before starting)
- insaits_session_stats: Session monitoring statistics
- insaits_alert: Manual alert logging
"""

MCP_AVAILABLE = False
try:
    from .server import TOOLS, run_server, demo_mode
    MCP_AVAILABLE = True
except ImportError:
    TOOLS = None
    run_server = None
    demo_mode = None

__all__ = ["TOOLS", "run_server", "demo_mode", "MCP_AVAILABLE"]
