"""Allow running: python -m insa_its.learning.pattern_miner"""
from insa_its.learning.pattern_miner import main

main()
