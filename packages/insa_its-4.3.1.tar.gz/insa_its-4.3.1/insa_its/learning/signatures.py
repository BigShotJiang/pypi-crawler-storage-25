"""InsAIts Learning — Session Signatures.

Signature = fingerprint of a session's behavioral pattern:
  - tool sequence hash
  - anomaly type distribution
  - temporal pattern (calls/minute)
  - file touch diversity

Used to compare new sessions against a library of known-good/known-bad patterns.
Stored in ~/.insaits/signatures/ as append-only JSONL.
"""

from __future__ import annotations

import hashlib
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger("insaits.signatures")

DEFAULT_SIGNATURES_DIR = Path.home() / ".insaits" / "signatures"
SIGNATURES_FILE = "signature_library.jsonl"


def _compute_tool_sequence_hash(tool_calls: List[str]) -> str:
    """Hash the ordered tool sequence to a compact fingerprint."""
    joined = "|".join(tool_calls[-50:])  # Last 50 tools
    return hashlib.md5(joined.encode("utf-8")).hexdigest()[:12]


def _compute_anomaly_distribution(anomalies: List[Dict[str, Any]]) -> Dict[str, int]:
    """Count anomaly types in a session."""
    dist: Dict[str, int] = {}
    for a in anomalies:
        atype = a.get("type", "unknown")
        dist[atype] = dist.get(atype, 0) + 1
    return dist


def build_signature(session_data: Dict[str, Any]) -> Dict[str, Any]:
    """Build a signature from session data.

    Args:
        session_data: Dict with keys like tool_calls, anomalies,
                      session_id, duration_seconds, files_touched.

    Returns:
        Signature dict ready for storage.
    """
    tool_calls = session_data.get("tool_calls", [])
    anomalies = session_data.get("anomalies", [])
    duration = session_data.get("duration_seconds", 0)
    files = session_data.get("files_touched", [])

    # Calls per minute (avoid division by zero)
    cpm = (len(tool_calls) / max(duration / 60.0, 1.0)) if duration > 0 else 0.0

    return {
        "session_id": session_data.get("session_id", "unknown"),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "tool_count": len(tool_calls),
        "tool_sequence_hash": _compute_tool_sequence_hash(tool_calls),
        "anomaly_count": len(anomalies),
        "anomaly_distribution": _compute_anomaly_distribution(anomalies),
        "calls_per_minute": round(cpm, 2),
        "file_diversity": len(set(files)),
        "duration_seconds": duration,
        "label": session_data.get("label", "unlabeled"),
    }


def load_signatures(path: Optional[Path] = None) -> List[Dict[str, Any]]:
    """Load all signatures from the library file.

    Args:
        path: Directory containing signature_library.jsonl.
              Defaults to ~/.insaits/signatures/.

    Returns:
        List of signature dicts, newest last.
    """
    sig_dir = path or DEFAULT_SIGNATURES_DIR
    sig_file = sig_dir / SIGNATURES_FILE
    if not sig_file.exists():
        return []

    signatures: List[Dict[str, Any]] = []
    try:
        with open(sig_file, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    signatures.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    except (IOError, OSError) as exc:
        logger.error("Failed to load signatures: %s", exc)
    return signatures


def append_signature(sig: Dict[str, Any], path: Optional[Path] = None) -> bool:
    """Append a signature to the library file.

    Args:
        sig: Signature dict (from build_signature()).
        path: Directory for signature_library.jsonl.

    Returns:
        True on success, False on failure.
    """
    sig_dir = path or DEFAULT_SIGNATURES_DIR
    sig_dir.mkdir(parents=True, exist_ok=True)
    sig_file = sig_dir / SIGNATURES_FILE
    try:
        with open(sig_file, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(sig, default=str) + "\n")
        logger.info("Signature appended: session=%s label=%s",
                     sig.get("session_id", "?")[:16], sig.get("label", "?"))
        return True
    except (IOError, OSError) as exc:
        logger.error("Failed to append signature: %s", exc)
        return False


def compare_session(
    session_data: Dict[str, Any],
    signatures: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """Compare current session against signature library.

    Returns a match result dict with:
      - closest_match: session_id of closest signature (or None)
      - similarity_score: 0.0-1.0 (1.0 = identical pattern)
      - matching_dimensions: which dimensions matched
      - verdict: "known_good", "known_bad", "novel", "insufficient_data"
    """
    if not signatures:
        return {
            "closest_match": None,
            "similarity_score": 0.0,
            "matching_dimensions": [],
            "verdict": "insufficient_data",
        }

    current_sig = build_signature(session_data)
    best_score = 0.0
    best_match = None
    best_dims: List[str] = []

    for lib_sig in signatures:
        score = 0.0
        dims: List[str] = []

        # Dimension 1: Tool sequence hash match (exact = 0.4, else 0)
        if current_sig["tool_sequence_hash"] == lib_sig.get("tool_sequence_hash"):
            score += 0.4
            dims.append("tool_sequence")

        # Dimension 2: Anomaly distribution similarity (up to 0.3)
        cur_dist = current_sig["anomaly_distribution"]
        lib_dist = lib_sig.get("anomaly_distribution", {})
        all_types = set(cur_dist.keys()) | set(lib_dist.keys())
        if all_types:
            matches = sum(
                1 for t in all_types
                if cur_dist.get(t, 0) == lib_dist.get(t, 0)
            )
            score += 0.3 * (matches / len(all_types))
            if matches > 0:
                dims.append("anomaly_pattern")

        # Dimension 3: Calls per minute similarity (up to 0.15)
        cur_cpm = current_sig["calls_per_minute"]
        lib_cpm = lib_sig.get("calls_per_minute", 0)
        if lib_cpm > 0:
            ratio = min(cur_cpm, lib_cpm) / max(cur_cpm, lib_cpm) if max(cur_cpm, lib_cpm) > 0 else 1.0
            score += 0.15 * ratio
            if ratio > 0.7:
                dims.append("temporal_pattern")

        # Dimension 4: File diversity similarity (up to 0.15)
        cur_fd = current_sig["file_diversity"]
        lib_fd = lib_sig.get("file_diversity", 0)
        if lib_fd > 0:
            ratio = min(cur_fd, lib_fd) / max(cur_fd, lib_fd) if max(cur_fd, lib_fd) > 0 else 1.0
            score += 0.15 * ratio
            if ratio > 0.7:
                dims.append("file_diversity")

        if score > best_score:
            best_score = score
            best_match = lib_sig
            best_dims = dims

    # Verdict based on score and label
    verdict = "novel"
    if best_match and best_score >= 0.6:
        label = best_match.get("label", "unlabeled")
        if label in ("good", "known_good", "safe"):
            verdict = "known_good"
        elif label in ("bad", "known_bad", "malicious", "suspicious"):
            verdict = "known_bad"
        else:
            verdict = "novel"

    return {
        "closest_match": best_match.get("session_id") if best_match else None,
        "similarity_score": round(best_score, 3),
        "matching_dimensions": best_dims,
        "verdict": verdict,
    }
