"""
InsAIts Dashboard Package
=========================
Live TUI dashboard for InsAIts runtime monitoring.

Usage:
    python3 -m insa_its.dashboard.tui          # Watch audit log
    python3 -m insa_its.dashboard.tui --demo   # Demo mode with synthetic data
"""

DASHBOARD_AVAILABLE = False

try:
    from .tui import InsAItsDashboard
    DASHBOARD_AVAILABLE = True
except ImportError:
    InsAItsDashboard = None

__all__ = ["InsAItsDashboard", "DASHBOARD_AVAILABLE"]
