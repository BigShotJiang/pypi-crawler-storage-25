"""InsAIts Web Dashboard — Real-time security monitoring UI.

Usage:
    python -m insa_its.web               # start on default port 5001
    python -m insa_its.web --port 8080
    insaits-dashboard                    # console script entry point

This module uses lazy imports so that ``insaits-dashboard`` starts in <1s
without loading torch / sentence-transformers.
"""


def main():
    """Entry point — imports server.py directly, bypasses heavy SDK init."""
    import importlib.util
    import os
    spec = importlib.util.spec_from_file_location(
        "insa_its.web.server",
        os.path.join(os.path.dirname(__file__), "server.py"),
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    mod.main()


__all__ = ["main"]
