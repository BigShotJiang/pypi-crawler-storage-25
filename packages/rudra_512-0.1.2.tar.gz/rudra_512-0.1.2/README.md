# Rudra-512

**Rudra-512** is a high-performance 512-bit cryptographic hash function with configurable rounds, exposed as a simple Python module.

It is designed for strong diffusion, near-ideal avalanche behavior (~50%), and flexible computational cost.

---

# 🚀 Installation

```bash
pip install rudra-512
```

---

# 🧑‍💻 Quick Start

```python
import rudra512

# Basic hash (default 32 rounds)
print(rudra512.hash_string("hello"))

# Custom rounds
print(rudra512.hash_string("hello", 64))
```

---

# 📌 Features

* 🔐 512-bit hash output (hex)
* ⚡ High performance (C++ backend)
* 🔁 Configurable rounds (default: 32)
* 🎯 Avalanche effect ≈ 50%
* 🧠 Deterministic output
* 🐍 Easy Python interface

---

# ⚙️ API

## `hash_string(input: str, rounds: int = 32) -> str`

### Parameters

* `input` → Input string to hash
* `rounds` → Number of rounds (default = 32)

### Returns

* 512-bit hash as hexadecimal string

---

# 🧪 Example

```python
import rudra512

data = "secure data"

h1 = rudra512.hash_string(data)
h2 = rudra512.hash_string(data, 64)

print("Default:", h1)
print("Custom rounds:", h2)
```

---

# 📂 Hashing Files

```python
import rudra512

with open("file.txt", "rb") as f:
    data = f.read()

print(rudra512.hash_bytes(data))
```

---

# 🧠 Design

Rudra-512 is a **general-purpose cryptographic hash function**, similar in concept to:

* SHA-2
* SHA-3

### Key Properties

* Deterministic (same input → same output)
* High diffusion and randomness
* Configurable work factor via rounds

---

# 🔐 Security Notes

* Rudra-512 does **not include salting internally**
* For password hashing, use:

```python
salt = "random_salt"
hash_value = rudra512.hash_string(password + salt, 64)
```

* Increasing rounds increases resistance to brute-force attacks

---

# ⚡ Performance

Rudra-512 is implemented in C++ and exposed to Python using bindings, providing:

* Fast execution
* Low overhead
* Efficient hashing for large inputs

---

# 📦 Requirements

* Python 3.8+
* No additional dependencies

---

# 👨‍💻 Author

Ayush Anand

---

# 📜 License

Apache License 2.0

---

# 💥 Note

Rudra-512 is an experimental cryptographic design.
Evaluate thoroughly before using in production security systems.
