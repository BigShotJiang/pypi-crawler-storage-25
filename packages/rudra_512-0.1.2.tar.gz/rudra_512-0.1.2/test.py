import rudra512
import hashlib
import time
import random
import string
import math

# -------------------------
# CONFIG
# -------------------------
NUM_TESTS = 512   # 👈 CHANGE HERE (512 for README, 10000 for validation)
ROUNDS = 32

# -------------------------
# HELPERS
# -------------------------

def random_string(length=64):
    return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(length))


def to_bits(hex_str):
    return bin(int(hex_str, 16))[2:].zfill(512)


# -------------------------
# METRICS
# -------------------------

def bit_diff(h1, h2):
    b1, b2 = to_bits(h1), to_bits(h2)
    return sum(c1 != c2 for c1, c2 in zip(b1, b2)) / 512 * 100


def entropy(hex_str):
    bits = to_bits(hex_str)
    p = bits.count('1') / 512
    if p == 0 or p == 1:
        return 0
    return -(p * math.log2(p) + (1 - p) * math.log2(1 - p))


def bit_balance(hashes):
    bits = ''.join(to_bits(h) for h in hashes)
    ones = bits.count('1')
    total = len(bits)
    return (ones / total) * 100


def chi_square(hashes):
    bits = ''.join(to_bits(h) for h in hashes)
    ones = bits.count('1')
    zeros = len(bits) - ones
    expected = len(bits) / 2
    return ((ones - expected) ** 2 + (zeros - expected) ** 2) / expected


def runs_test(hashes):
    bits = ''.join(to_bits(h) for h in hashes)
    runs = 1
    for i in range(1, len(bits)):
        if bits[i] != bits[i - 1]:
            runs += 1
    return runs / len(bits)


def collision_test(hash_func):
    seen = set()
    for _ in range(NUM_TESTS):
        h = hash_func(random_string())
        if h in seen:
            return 1
        seen.add(h)
    return 0


# -------------------------
# HASH FUNCTIONS
# -------------------------

def rudra_hash(s):
    return rudra512.hash_string(s, ROUNDS)


def sha512_hash(s):
    return hashlib.sha512(s.encode()).hexdigest()


def sha3_hash(s):
    return hashlib.sha3_512(s.encode()).hexdigest()


# -------------------------
# CORE TEST
# -------------------------

def run_tests(hash_func):
    start = time.time()

    avalanche_scores = []
    entropy_scores = []
    hashes = []

    for _ in range(NUM_TESTS):
        s = random_string()

        h1 = hash_func(s)
        hashes.append(h1)

        # Flip one character
        i = random.randint(0, len(s) - 1)
        s2 = list(s)
        s2[i] = chr((ord(s2[i]) + 1) % 127)
        s2 = ''.join(s2)

        h2 = hash_func(s2)

        avalanche_scores.append(bit_diff(h1, h2))
        entropy_scores.append(entropy(h1))

    end = time.time()

    return {
        "time": (end - start) / NUM_TESTS,
        "avalanche": sum(avalanche_scores) / len(avalanche_scores),
        "entropy": sum(entropy_scores) / len(entropy_scores),
        "bit_balance": bit_balance(hashes),
        "chi_square": chi_square(hashes),
        "runs": runs_test(hashes),
        "collisions": collision_test(hash_func)
    }


# -------------------------
# PRINT TABLE
# -------------------------

def print_header():
    print("\n===== RUDRA-512 BENCHMARK =====\n")
    print(f"{'Algorithm':<12} {'Time':<12} {'Avalanche':<10} {'Entropy':<10} "
          f"{'BitBal':<10} {'ChiSq':<10} {'Runs':<10} {'Coll'}")
    print("-" * 90)


def print_row(name, r):
    print(f"{name:<12} "
          f"{r['time']:<12.8f} "
          f"{r['avalanche']:<10.4f} "
          f"{r['entropy']:<10.4f} "
          f"{r['bit_balance']:<10.2f} "
          f"{r['chi_square']:<10.4f} "
          f"{r['runs']:<10.6f} "
          f"{r['collisions']}")


# -------------------------
# MAIN
# -------------------------

if __name__ == "__main__":

    print_header()

    rudra = run_tests(rudra_hash)
    sha2 = run_tests(sha512_hash)
    sha3 = run_tests(sha3_hash)

    print_row("Rudra-512", rudra)
    print_row("SHA-512", sha2)
    print_row("SHA3-512", sha3)
