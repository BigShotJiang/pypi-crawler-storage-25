#ifndef RUDRA512_H
#define RUDRA512_H

#include <cstdint>
#include <vector>
#include <string>

namespace rudra {

std::string hash(const std::vector<uint8_t>& input, int rounds = 32);
std::string hash_string(const std::string& input, int rounds = 32);
std::string hash_file(const std::string& filename, int rounds = 32);

}

#endif
