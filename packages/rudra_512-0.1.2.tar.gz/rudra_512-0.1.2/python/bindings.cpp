#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include "rudra512.h"

namespace py = pybind11;

PYBIND11_MODULE(rudra512, m) {
    m.doc() = "Rudra-512 Hash";

    m.def("hash_string", &rudra::hash_string,
          py::arg("input"), py::arg("rounds") = 32);

    m.def("hash_file", &rudra::hash_file,
          py::arg("filename"), py::arg("rounds") = 32);
}
