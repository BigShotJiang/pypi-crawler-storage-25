#include "rudra512.h"

#include <iostream>
#include <string>

int main(int argc, char* argv[]) {

    if (argc < 2) {
        std::cout << "Usage:\n";
        std::cout << "  rudra <string> [rounds]\n";
        std::cout << "  rudra -f <file> [rounds]\n";
        return 0;
    }

    int rounds = 32;

    if (argc >= 3) {
        try {
            rounds = std::stoi(argv[argc - 1]);
        } catch (...) {
            rounds = 32;
        }
    }

    try {

        std::string arg1 = argv[1];

        if (arg1 == "-f") {

            if (argc < 3) {
                std::cerr << "Error: file not provided\n";
                return 1;
            }

            std::string filename = argv[2];
            std::cout << rudra::hash_file(filename, rounds) << "\n";

        } else {

            std::string input = arg1;
            std::cout << rudra::hash_string(input, rounds) << "\n";
        }

    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
        return 1;
    }

    return 0;
}
