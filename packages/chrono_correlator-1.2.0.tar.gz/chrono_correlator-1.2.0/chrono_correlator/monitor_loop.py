# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Raúl Gallardo (g3v3r)

import time
from collections.abc import Callable
from datetime import datetime
from typing import Optional

from .engine import monitor
from .models import AlertReport, Metric


def loop(
    metrics_fn: Callable[[], list[Metric]],
    interval_seconds: int = 3600,
    lookback_hours: int = 48,
    baseline_days: int = 28,
    provider: str = "groq",
    narrate: bool = True,
    on_alert: Optional[Callable[[AlertReport], None]] = None,
    on_tick: Optional[Callable[[AlertReport], None]] = None,
) -> None:
    """Run monitor() on a fixed interval forever.

    Args:
        metrics_fn:        callable that returns fresh metrics each tick
        interval_seconds:  seconds between evaluations (default: 1 hour)
        on_alert:          called when level is yellow or red
        on_tick:           called on every tick regardless of level
    """
    while True:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        metrics = metrics_fn()
        report = monitor(
            metrics,
            lookback_hours=lookback_hours,
            baseline_days=baseline_days,
            provider=provider,
            narrate=narrate,
        )

        print(
            f"[{now}] level={report.level.upper()} "
            f"signals={report.active_signals}/{report.total_signals}"
        )

        if on_tick:
            on_tick(report)

        if report.level != "green" and on_alert:
            on_alert(report)

        time.sleep(interval_seconds)