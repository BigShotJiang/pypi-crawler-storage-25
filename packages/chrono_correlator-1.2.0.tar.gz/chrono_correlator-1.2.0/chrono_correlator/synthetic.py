# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Raúl Gallardo (g3v3r)

"""Realistic synthetic data generator for testing and demos."""
from __future__ import annotations

from datetime import datetime, timedelta

import numpy as np

from .models import Event, Metric


def generate_metric(
    name: str,
    start: datetime | None = None,
    days: int = 30,
    base_value: float = 55.0,
    noise_std: float = 3.0,
    circadian_amplitude: float = 6.0,
    seed: int | None = None,
) -> Metric:
    """Generate a realistic hourly metric with circadian rhythm and noise.

    The signal peaks around 4 AM (recovery phase) and is lowest at 2 PM,
    mimicking real HRV patterns.
    """
    rng = np.random.default_rng(seed)
    n_hours = days * 24
    hours = np.arange(n_hours)

    # Circadian component: peak at hour 4 (4 AM)
    circadian = circadian_amplitude * np.sin(2 * np.pi * (hours % 24 - 4) / 24 - np.pi / 2)

    # Slow day-to-day drift (random walk, ±5 over the whole period)
    daily_drift = np.cumsum(rng.normal(0, 0.3, n_hours))
    daily_drift -= daily_drift.mean()

    # Measurement noise
    noise = rng.normal(0, noise_std, n_hours)

    values = base_value + circadian + daily_drift + noise
    values = np.clip(values, base_value * 0.3, base_value * 1.8)

    base = start or datetime(2024, 1, 1)
    timestamps = [base + timedelta(hours=int(h)) for h in hours]

    return Metric(name=name, timestamps=timestamps, values=values.tolist())


def inject_pattern(
    metric: Metric,
    events: list[Event],
    lookback_hours: int = 72,
    drop_fraction: float = 0.35,
) -> Metric:
    """Inject a gradual pre-event dip into the metric.

    The drop is gradual (not a cliff): starts at lookback_hours before the
    event and reaches its maximum at 12h before, then recovers after.
    This mimics real physiological stress responses.
    """
    ts = np.array([t.timestamp() for t in metric.timestamps])
    values = np.array(metric.values)

    for event in events:
        t_event = event.timestamp.timestamp()
        t_start = t_event - lookback_hours * 3600

        for i, t in enumerate(ts):
            if t_start <= t < t_event:
                # Linear ramp: 0 at t_start → drop_fraction at 12h before event
                progress = (t - t_start) / (t_event - t_start)
                dip = drop_fraction * min(progress * 2, 1.0)
                values[i] *= 1 - dip

    return Metric(
        name=metric.name,
        timestamps=metric.timestamps,
        values=values.tolist(),
    )


def generate_events(
    start: datetime | None = None,
    days: int = 30,
    n_events: int = 7,
    min_gap_days: int = 3,
    label: str = "event",
    seed: int | None = None,
) -> list[Event]:
    """Generate events spaced at least min_gap_days apart within the window."""
    rng = np.random.default_rng(seed)
    base = start or datetime(2024, 1, 1)

    events: list[Event] = []
    last_day = -min_gap_days

    candidate_days = rng.permutation(range(min_gap_days, days - 1)).tolist()

    for day in sorted(candidate_days):
        if day - last_day >= min_gap_days and len(events) < n_events:
            hour = int(rng.integers(6, 22))
            events.append(
                Event(
                    timestamp=base + timedelta(days=int(day), hours=hour),
                    label=label,
                )
            )
            last_day = day

    return events[:n_events]


def shuffle_metric(metric: Metric, seed: int | None = None) -> Metric:
    """Return a copy of the metric with values randomly shuffled.

    Used to build a null-hypothesis control: same distribution,
    no temporal structure.
    """
    rng = np.random.default_rng(seed)
    shuffled = rng.permutation(metric.values).tolist()
    return Metric(name=metric.name, timestamps=metric.timestamps, values=shuffled)


def shift_events(events: list[Event], days: int = 7) -> list[Event]:
    """Shift all event timestamps by a fixed offset.

    Used to misalign events from the pre-injected pattern,
    producing a control where the metric has a pattern but
    the events don't match it.
    """
    return [
        Event(
            timestamp=e.timestamp + timedelta(days=days),
            label=e.label,
            notes=e.notes,
        )
        for e in events
    ]