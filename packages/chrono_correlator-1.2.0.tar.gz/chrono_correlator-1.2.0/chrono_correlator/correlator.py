# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Raúl Gallardo (g3v3r)

from datetime import datetime as _dt

import numpy as np
from scipy import stats

from .models import CorrelationResult, Event, Metric, SignificanceConfig

_DEFAULT_CONFIG = SignificanceConfig()
_VALID_STRATEGIES = ("rolling", "same_weekday", "same_hour")


def _classify_strength(abs_effect: float, consistency: float, cfg: SignificanceConfig) -> str:
    if abs_effect > cfg.strong_effect and consistency > cfg.strong_consistency:
        return "strong"
    if abs_effect > cfg.moderate_effect and consistency > cfg.moderate_consistency:
        return "moderate"
    if abs_effect > cfg.weak_effect:
        return "weak"
    return "none"


def _bootstrap_effect_ci(
    pre: list[float],
    baseline: list[float],
    n_resamples: int = 999,
    confidence: float = 0.95,
    seed: int = 42,
) -> tuple[float, float]:
    """Percentile bootstrap CI for rank-biserial effect size."""
    rng = np.random.default_rng(seed)
    pre_arr = np.array(pre)
    base_arr = np.array(baseline)
    n1, n2 = len(pre_arr), len(base_arr)

    effects = np.empty(n_resamples)
    for i in range(n_resamples):
        pre_boot = rng.choice(pre_arr, size=n1, replace=True)
        base_boot = rng.choice(base_arr, size=n2, replace=True)
        s, _ = stats.mannwhitneyu(pre_boot, base_boot, alternative="two-sided")
        effects[i] = 1 - (2 * s) / (n1 * n2)

    alpha = (1 - confidence) / 2
    return float(np.percentile(effects, alpha * 100)), float(np.percentile(effects, (1 - alpha) * 100))


def analyze(
    events: list[Event],
    metric: Metric,
    lookback_hours: int = 48,
    baseline_days: int = 28,
    lag_hours: int = 0,
    direction: str = "two-sided",
    config: SignificanceConfig | None = None,
    bootstrap_ci: bool = False,
    bootstrap_resamples: int = 999,
    baseline_strategy: str = "rolling",
) -> CorrelationResult:
    """Analyze correlation between a metric and events using Mann-Whitney U.

    direction: "two-sided" | "increase" | "decrease"
    baseline_strategy: "rolling" | "same_weekday" | "same_hour"
        "same_weekday" compares only baseline points on the same day-of-week as each event.
        "same_hour"    compares only baseline points at the same hour as each event.
    bootstrap_ci: adds 95% percentile bootstrap CI to effect_ci (~1s per metric)
    """
    if direction not in ("two-sided", "increase", "decrease"):
        raise ValueError(
            f"Invalid direction '{direction}'. Use 'two-sided', 'increase', or 'decrease'."
        )
    if baseline_strategy not in _VALID_STRATEGIES:
        raise ValueError(
            f"Invalid baseline_strategy '{baseline_strategy}'. Use {_VALID_STRATEGIES}."
        )
    cfg = config or _DEFAULT_CONFIG
    alternative = {"two-sided": "two-sided", "increase": "greater", "decrease": "less"}[direction]

    ts = np.array([t.timestamp() for t in metric.timestamps])
    vals = np.array(metric.values)

    # Pre-compute seasonal arrays once — avoids repeated per-event conversion
    ts_weekdays = (
        np.array([_dt.fromtimestamp(t).weekday() for t in ts])
        if baseline_strategy == "same_weekday" else None
    )
    ts_hours = (
        np.array([_dt.fromtimestamp(t).hour for t in ts])
        if baseline_strategy == "same_hour" else None
    )

    pre_event_values: list[float] = []
    baseline_values: list[float] = []
    per_event_pre_medians: list[float] = []

    for event in events:
        t_event = event.timestamp.timestamp()
        t_pre_end = t_event - lag_hours * 3600
        t_pre_start = t_pre_end - lookback_hours * 3600
        t_baseline_start = t_event - baseline_days * 86400

        mask_pre = (ts >= t_pre_start) & (ts < t_pre_end)
        mask_baseline = (ts >= t_baseline_start) & (ts < t_pre_start)

        if baseline_strategy == "same_weekday":
            mask_baseline = mask_baseline & (ts_weekdays == event.timestamp.weekday())
        elif baseline_strategy == "same_hour":
            mask_baseline = mask_baseline & (ts_hours == event.timestamp.hour)

        pre_vals = vals[mask_pre]
        pre_event_values.extend(pre_vals.tolist())
        baseline_values.extend(vals[mask_baseline].tolist())

        if len(pre_vals) >= 1:
            per_event_pre_medians.append(float(np.median(pre_vals)))

    n1, n2 = len(pre_event_values), len(baseline_values)

    if n1 < 3 or n2 < 3:
        raise ValueError(
            f"Datos insuficientes para '{metric.name}'. "
            f"Pre-evento: {n1}, Baseline: {n2}"
        )

    stat, p_value = stats.mannwhitneyu(
        pre_event_values, baseline_values, alternative=alternative
    )
    effect_size = float(1 - (2 * stat) / (n1 * n2))

    overall_pre_median = float(np.median(pre_event_values))
    overall_baseline_median = float(np.median(baseline_values))

    if per_event_pre_medians and overall_pre_median != overall_baseline_median:
        trend = 1 if overall_pre_median > overall_baseline_median else -1
        consistent = sum(
            1 for m in per_event_pre_medians
            if (m - overall_baseline_median) * trend > 0
        )
        consistency = consistent / len(per_event_pre_medians)
    else:
        consistency = 0.0

    abs_effect = abs(effect_size)
    signal_strength = _classify_strength(abs_effect, consistency, cfg)
    # rank-biserial — measures association strength, NOT causality
    association_strength = round(0.5 * min(abs_effect, 1.0) + 0.5 * consistency, 4)
    significant = bool(p_value < cfg.alpha and signal_strength in ("strong", "moderate"))

    effect_ci = (
        _bootstrap_effect_ci(pre_event_values, baseline_values, n_resamples=bootstrap_resamples)
        if bootstrap_ci
        else None
    )

    return CorrelationResult(
        metric_name=metric.name,
        p_value=float(p_value),
        significant=significant,
        effect_size=effect_size,
        baseline_median=overall_baseline_median,
        pre_event_median=overall_pre_median,
        consistency=round(consistency, 4),
        signal_strength=signal_strength,
        association_strength=association_strength,
        effect_ci=effect_ci,
        narrative=None,
    )