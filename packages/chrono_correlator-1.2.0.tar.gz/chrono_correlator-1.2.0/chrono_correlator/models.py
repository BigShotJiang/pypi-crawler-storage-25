# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Raúl Gallardo (g3v3r)

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    import pandas as pd


@dataclass
class SignificanceConfig:
    """Configurable thresholds for significance and signal classification."""
    alpha: float = 0.05
    strong_effect: float = 0.25
    strong_consistency: float = 0.6
    moderate_effect: float = 0.15
    moderate_consistency: float = 0.4
    weak_effect: float = 0.10


@dataclass
class Event:
    timestamp: datetime
    label: str
    notes: Optional[str] = None


@dataclass
class Metric:
    name: str
    timestamps: list[datetime]
    values: list[float]

    @classmethod
    def from_dataframe(
        cls,
        df: pd.DataFrame,
        name: str,
        timestamp_col: str = "timestamp",
        value_col: str = "value",
    ) -> Metric:
        try:
            import pandas  # noqa: F401
        except ImportError:
            raise ImportError("pandas is not installed. Run: pip install pandas")
        return cls(
            name=name,
            timestamps=df[timestamp_col].tolist(),
            values=df[value_col].tolist(),
        )


@dataclass
class CorrelationResult:
    metric_name: str
    p_value: float
    significant: bool          # p < 0.05 AND signal_strength in (strong, moderate)
    effect_size: float         # rank-biserial: 1 - 2*stat/(n1*n2)
    baseline_median: float
    pre_event_median: float
    consistency: float         # fraction of events individually showing the pattern
    signal_strength: str       # "strong" / "moderate" / "weak" / "none"
    association_strength: float  # 0-1 composite: 0.5*|effect| + 0.5*consistency
    adjusted_p_value: Optional[float] = None
    effect_ci: Optional[tuple[float, float]] = None  # (low, high) bootstrap 95% CI
    narrative: Optional[str] = None


@dataclass
class AlertReport:
    level: str
    active_signals: int        # count of strong + moderate signals
    total_signals: int
    results: list[CorrelationResult]
    narrative: Optional[str] = None