# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Raúl Gallardo (g3v3r)

import warnings
from datetime import datetime

import numpy as np

from .correlator import analyze
from .models import AlertReport, CorrelationResult, Event, Metric, SignificanceConfig

THRESHOLDS = {"green": (0, 2), "yellow": (3, 4), "red": (5, 7)}


def _apply_correction(
    results: list[CorrelationResult], method: str, cfg: SignificanceConfig
) -> None:
    p_values = np.array([r.p_value for r in results])

    if method == "bonferroni":
        adjusted = np.minimum(p_values * len(p_values), 1.0)
    elif method == "fdr":
        from scipy.stats import false_discovery_control
        adjusted = false_discovery_control(p_values, method="bh")
    else:
        raise ValueError(f"Unknown correction method '{method}'. Use 'bonferroni' or 'fdr'.")

    for r, p_adj in zip(results, adjusted):
        r.adjusted_p_value = float(p_adj)
        r.significant = bool(
            p_adj < cfg.alpha and r.signal_strength in ("strong", "moderate")
        )


def _warn_overlapping_events(events: list[Event], lookback_hours: int) -> None:
    """Emit UserWarning for any pair of events whose pre-event windows overlap."""
    sorted_events = sorted(events, key=lambda e: e.timestamp)
    for a, b in zip(sorted_events, sorted_events[1:]):
        gap_hours = (b.timestamp - a.timestamp).total_seconds() / 3600
        if gap_hours < lookback_hours:
            warnings.warn(
                f"Events '{a.label}' ({a.timestamp.date()}) and '{b.label}' "
                f"({b.timestamp.date()}) are {gap_hours:.0f}h apart — "
                f"pre-event windows overlap (lookback={lookback_hours}h). "
                "Pooled results may be inflated.",
                UserWarning,
                stacklevel=4,
            )


def evaluate(
    events: list[Event],
    metrics: list[Metric],
    lookback_hours: int = 48,
    baseline_days: int = 28,
    lag_hours: int = 0,
    correction: str | None = "fdr",
    direction: str = "two-sided",
    config: SignificanceConfig | None = None,
    bootstrap_ci: bool = False,
    bootstrap_resamples: int = 999,
    baseline_strategy: str = "rolling",
) -> AlertReport:
    """Run Mann-Whitney U analysis for all metrics and return an AlertReport.

    Applies multiple comparison correction across metrics (FDR by default).
    Emits a UserWarning when event pre-event windows overlap.
    Metrics with insufficient data are silently skipped.

    Args:
        events: List of discrete events to correlate against.
        metrics: List of time-series metrics to analyze.
        lookback_hours: Size of the pre-event window in hours.
        baseline_days: Length of the baseline window in days.
        lag_hours: Shift the pre-event window back in time.
        correction: Multiple comparison correction — ``"fdr"``, ``"bonferroni"``, or ``None``.
        direction: Hypothesis direction — ``"two-sided"``, ``"increase"``, or ``"decrease"``.
        config: Custom significance thresholds via :class:`SignificanceConfig`.
        bootstrap_ci: Compute 95% percentile bootstrap CI for effect size.
        bootstrap_resamples: Number of bootstrap resamples (default 999).
        baseline_strategy: Baseline selection — ``"rolling"``, ``"same_weekday"``, or ``"same_hour"``.

    Returns:
        :class:`AlertReport` with level (green/yellow/red), signal counts, and per-metric results.
    """
    cfg = config or SignificanceConfig()
    _warn_overlapping_events(events, lookback_hours)
    results: list[CorrelationResult] = []

    for metric in metrics:
        try:
            results.append(
                analyze(
                    events, metric, lookback_hours, baseline_days, lag_hours,
                    direction, cfg, bootstrap_ci, bootstrap_resamples, baseline_strategy,
                )
            )
        except ValueError:
            continue

    if correction and results:
        _apply_correction(results, correction, cfg)

    active = sum(1 for r in results if r.significant)

    if active <= 2:
        level = "green"
    elif active <= 4:
        level = "yellow"
    else:
        level = "red"

    return AlertReport(
        level=level,
        active_signals=active,
        total_signals=len(results),
        results=results,
        narrative=None,
    )


def find_best_lag(
    events: list[Event],
    metric: Metric,
    lag_range: range | list[int] = range(0, 72, 6),
    lookback_hours: int = 48,
    baseline_days: int = 28,
    direction: str = "two-sided",
    config: SignificanceConfig | None = None,
    baseline_strategy: str = "rolling",
) -> dict[int, CorrelationResult]:
    """Sweep lag values and return a CorrelationResult per lag.

    Example:
        results = find_best_lag(events, hrv_metric)
        best = max(results, key=lambda k: results[k].association_strength)
        print(f"Strongest signal at lag={best}h  association={results[best].association_strength:.2f}")
    """
    cfg = config or SignificanceConfig()
    out: dict[int, CorrelationResult] = {}
    for lag in lag_range:
        try:
            out[lag] = analyze(
                events, metric, lookback_hours, baseline_days, lag,
                direction, cfg, False, 999, baseline_strategy,
            )
        except ValueError:
            continue
    return out


def monitor(
    metrics: list[Metric],
    lookback_hours: int = 48,
    baseline_days: int = 28,
    lag_hours: int = 0,
    correction: str | None = "fdr",
    direction: str = "two-sided",
    config: SignificanceConfig | None = None,
    bootstrap_ci: bool = False,
    baseline_strategy: str = "rolling",
    provider: str = "groq",
    narrate: bool = True,
) -> AlertReport:
    """Evaluate the current state of metrics without requiring discrete past events.

    Instead of anchoring on known events, monitor() creates a single synthetic
    event at ``now()`` and compares the most recent ``lookback_hours`` of data
    against the preceding ``baseline_days`` rolling window.

    **What it compares:**
    The current window (last ``lookback_hours``) vs. the rolling baseline
    (the ``baseline_days`` period ending at the start of that window).
    There is no discrete event anchor — the "event" is always "now".

    **Statistical assumptions vs evaluate():**
    - evaluate() pools pre-event windows from multiple real events, giving a
      robust estimate of the pre-event distribution. monitor() uses a single
      synthetic event, so results reflect *distributional drift* from the
      recent baseline — not a pattern anchored to known events.
    - With a single event, consistency is always 0.0 or 1.0 (binary).
      The association_strength score is dominated by effect size.
    - False positive rate is higher than with evaluate() over multiple events.
      Use monitor() for anomaly detection, not for pattern confirmation.

    **Calibration warning:**
    Call evaluate() with real historical events first to establish whether
    a metric shows pre-event patterns and at what effect size. Relying on
    monitor() alerts without prior calibration may produce spurious alerts
    during normal distributional drift (e.g. circadian rhythms, weekday effects).

    Args:
        metrics: List of time-series metrics to evaluate.
        lookback_hours: Size of the current window in hours (default 48).
        baseline_days: Length of the rolling baseline in days (default 28).
        lag_hours: Shift the current window back in time.
        correction: Multiple comparison correction across metrics.
        direction: ``"two-sided"``, ``"increase"``, or ``"decrease"``.
        config: Custom significance thresholds via :class:`SignificanceConfig`.
        bootstrap_ci: Compute 95% bootstrap CI for effect size.
        baseline_strategy: ``"rolling"``, ``"same_weekday"``, or ``"same_hour"``.
        provider: LLM provider for narration (``"groq"``, ``"anthropic"``, ``"ollama"``).
        narrate: If True, narrate yellow/red reports via the selected provider.

    Returns:
        :class:`AlertReport` reflecting distributional drift in the current window.

    .. warning::
        Calibrate with :func:`evaluate` using real events before deploying
        monitor() in production. Uncalibrated alerts may be misleading.
    """
    from .narrator import narrate as _narrate

    now = datetime.now()
    synthetic_event = [Event(timestamp=now, label="monitor")]

    report = evaluate(
        synthetic_event, metrics, lookback_hours, baseline_days, lag_hours,
        correction, direction, config, bootstrap_ci, 999, baseline_strategy,
    )

    if narrate and report.level != "green":
        report = _narrate(report, provider=provider)

    return report