# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Raúl Gallardo (g3v3r)

from .correlator import analyze
from .engine import evaluate, find_best_lag, monitor
from .exports import export_html, export_markdown
from .models import AlertReport, CorrelationResult, Event, Metric, SignificanceConfig
from .monitor_loop import loop
from .narrator import AnthropicNarrator, BaseNarrator, GroqNarrator, OllamaNarrator, PROMPT_TEMPLATES, narrate
from .storage import load_reports, save_report
from .synthetic import generate_events, generate_metric, inject_pattern, shift_events, shuffle_metric

__version__ = "1.2.0"

__all__ = [
    "analyze",
    "evaluate",
    "find_best_lag",
    "monitor",
    "loop",
    "narrate",
    "PROMPT_TEMPLATES",
    "BaseNarrator",
    "GroqNarrator",
    "AnthropicNarrator",
    "OllamaNarrator",
    "save_report",
    "load_reports",
    "export_html",
    "export_markdown",
    "generate_metric",
    "generate_events",
    "inject_pattern",
    "shuffle_metric",
    "shift_events",
    "Event",
    "Metric",
    "CorrelationResult",
    "AlertReport",
    "SignificanceConfig",
    "__version__",
]