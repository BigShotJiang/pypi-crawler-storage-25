from datetime import datetime, timedelta

from chrono_correlator.models import AlertReport, CorrelationResult
from chrono_correlator.storage import load_reports, save_report


def _make_result(significant: bool = True) -> CorrelationResult:
    return CorrelationResult(
        metric_name="hrv",
        p_value=0.01 if significant else 0.9,
        significant=significant,
        effect_size=-0.45 if significant else 0.0,
        baseline_median=55.0,
        pre_event_median=30.0 if significant else 55.0,
        consistency=0.9 if significant else 0.1,
        signal_strength="strong" if significant else "none",
        association_strength=0.7 if significant else 0.05,
    )


def _make_report(level: str = "green") -> AlertReport:
    sig = level != "green"
    return AlertReport(
        level=level,
        active_signals=1 if sig else 0,
        total_signals=1,
        results=[_make_result(sig)],
    )


def test_save_and_load_roundtrip(tmp_path):
    db = str(tmp_path / "chrono.db")
    row_id = save_report(_make_report("yellow"), db)
    assert isinstance(row_id, int) and row_id >= 1

    reports = load_reports(db)
    assert len(reports) == 1
    r = reports[0]
    assert r.level == "yellow"
    assert r.results[0].metric_name == "hrv"
    assert r.results[0].significant is True


def test_load_empty_db_returns_empty_list(tmp_path):
    assert load_reports(str(tmp_path / "empty.db")) == []


def test_multiple_reports_ordered_newest_first(tmp_path):
    db = str(tmp_path / "chrono.db")
    save_report(_make_report("green"), db)
    save_report(_make_report("red"), db)
    reports = load_reports(db)
    assert len(reports) == 2
    assert reports[0].level == "red"   # newest first


def test_filter_by_level(tmp_path):
    db = str(tmp_path / "chrono.db")
    for level in ("green", "yellow", "red", "yellow"):
        save_report(_make_report(level), db)

    yellows = load_reports(db, level="yellow")
    assert len(yellows) == 2
    assert all(r.level == "yellow" for r in yellows)


def test_filter_by_since_excludes_old(tmp_path):
    db = str(tmp_path / "chrono.db")
    save_report(_make_report("red"), db)
    future = datetime.now() + timedelta(hours=1)
    assert load_reports(db, since=future) == []


def test_effect_ci_roundtrip(tmp_path):
    db = str(tmp_path / "chrono.db")
    r = _make_result(True)
    r.effect_ci = (-0.65, -0.25)
    report = AlertReport(level="red", active_signals=1, total_signals=1, results=[r])
    save_report(report, db)

    loaded = load_reports(db)[0].results[0]
    assert loaded.effect_ci == (-0.65, -0.25)


def test_narrative_roundtrip(tmp_path):
    db = str(tmp_path / "chrono.db")
    report = _make_report("yellow")
    report.narrative = "Patron detectado."
    report.results[0].narrative = "HRV reducido antes del evento."
    save_report(report, db)

    loaded = load_reports(db)[0]
    assert loaded.narrative == "Patron detectado."
    assert loaded.results[0].narrative == "HRV reducido antes del evento."
