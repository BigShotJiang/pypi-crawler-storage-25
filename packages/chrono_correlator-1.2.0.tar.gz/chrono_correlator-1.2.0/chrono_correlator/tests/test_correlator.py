import pytest
from datetime import datetime, timedelta

from chrono_correlator.models import Event, Metric, SignificanceConfig
from chrono_correlator.correlator import analyze, _classify_strength

BASE = datetime(2024, 1, 1)


def _make_flat_metric(name: str, hours: int, value: float = 55.0) -> Metric:
    timestamps = [BASE + timedelta(hours=h) for h in range(hours)]
    return Metric(name=name, timestamps=timestamps, values=[value] * hours)


def test_detects_real_pattern():
    hours = 700
    timestamps = [BASE + timedelta(hours=h) for h in range(hours)]
    values = [55.0] * hours
    event_days = [10, 20, 30]
    for day in event_days:
        for h in range(48):
            idx = day * 24 - 48 + h
            if 0 <= idx < hours:
                values[idx] = 30.0
    metric = Metric(name="hrv", timestamps=timestamps, values=values)
    events = [Event(timestamp=BASE + timedelta(days=d), label="test") for d in event_days]

    result = analyze(events, metric)

    assert result.significant is True
    assert result.pre_event_median < result.baseline_median
    assert result.signal_strength in ("strong", "moderate")
    assert result.consistency > 0.6
    assert result.association_strength > 0.5
    assert result.narrative is None


def test_no_false_positive():
    metric = _make_flat_metric("hrv", hours=700, value=55.0)
    events = [Event(timestamp=BASE + timedelta(days=d), label="test") for d in [10, 20, 30]]

    result = analyze(events, metric)

    assert result.significant is False
    assert result.signal_strength in ("weak", "none")
    assert result.association_strength < 0.5


def test_insufficient_data():
    timestamps = [BASE + timedelta(hours=h) for h in range(2)]
    metric = Metric(name="hrv", timestamps=timestamps, values=[55.0, 55.0])
    events = [Event(timestamp=BASE + timedelta(days=1), label="test")]

    with pytest.raises(ValueError, match="Datos insuficientes"):
        analyze(events, metric)


def test_consistency_all_events_consistent():
    hours = 700
    timestamps = [BASE + timedelta(hours=h) for h in range(hours)]
    values = [55.0] * hours
    event_days = [10, 20, 30]
    for day in event_days:
        for h in range(48):
            idx = day * 24 - 48 + h
            if 0 <= idx < hours:
                values[idx] = 30.0
    metric = Metric(name="hrv", timestamps=timestamps, values=values)
    events = [Event(timestamp=BASE + timedelta(days=d), label="test") for d in event_days]

    result = analyze(events, metric)

    assert result.consistency == 1.0


def test_association_strength_range():
    hours = 700
    timestamps = [BASE + timedelta(hours=h) for h in range(hours)]
    values = [55.0] * hours
    metric = Metric(name="hrv", timestamps=timestamps, values=values)
    events = [Event(timestamp=BASE + timedelta(days=d), label="test") for d in [10, 20, 30]]

    result = analyze(events, metric)

    assert 0.0 <= result.association_strength <= 1.0


def test_classify_strength():
    cfg = SignificanceConfig()
    assert _classify_strength(0.30, 0.70, cfg) == "strong"
    assert _classify_strength(0.20, 0.50, cfg) == "moderate"
    assert _classify_strength(0.12, 0.30, cfg) == "weak"
    assert _classify_strength(0.05, 0.20, cfg) == "none"
    # Effect strong but low consistency → not strong
    assert _classify_strength(0.30, 0.30, cfg) == "weak"


def _make_pattern_metric(event_days, hours=700, low=30.0, high=55.0):
    timestamps = [BASE + timedelta(hours=h) for h in range(hours)]
    values = [high] * hours
    for day in event_days:
        for h in range(48):
            idx = day * 24 - 48 + h
            if 0 <= idx < hours:
                values[idx] = low
    return Metric(name="hrv", timestamps=timestamps, values=values)


def test_direction_decrease_detects_drop():
    event_days = [10, 20, 30]
    metric = _make_pattern_metric(event_days, low=30.0, high=55.0)
    events = [Event(timestamp=BASE + timedelta(days=d), label="test") for d in event_days]

    result = analyze(events, metric, direction="decrease")

    assert result.significant is True
    assert result.pre_event_median < result.baseline_median


def test_direction_increase_misses_drop():
    event_days = [10, 20, 30]
    metric = _make_pattern_metric(event_days, low=30.0, high=55.0)
    events = [Event(timestamp=BASE + timedelta(days=d), label="test") for d in event_days]

    result = analyze(events, metric, direction="increase")

    assert result.significant is False


def test_direction_invalid_raises():
    metric = _make_flat_metric("hrv", hours=700)
    events = [Event(timestamp=BASE + timedelta(days=10), label="test")]
    with pytest.raises(ValueError, match="Invalid direction"):
        analyze(events, metric, direction="upward")


def test_significance_config_strict_alpha_blocks_weak_signal():
    event_days = [10, 20, 30]
    metric = _make_pattern_metric(event_days, low=30.0, high=55.0)
    events = [Event(timestamp=BASE + timedelta(days=d), label="test") for d in event_days]

    result_default = analyze(events, metric)
    assert result_default.significant is True

    # alpha=0 means nothing is ever significant
    cfg_impossible = SignificanceConfig(alpha=0.0)
    result_impossible = analyze(events, metric, config=cfg_impossible)
    assert result_impossible.significant is False


def test_significance_config_high_thresholds_downgrades_strength():
    event_days = [10, 20, 30]
    metric = _make_pattern_metric(event_days, low=48.0, high=55.0)  # small drop
    events = [Event(timestamp=BASE + timedelta(days=d), label="test") for d in event_days]

    cfg_strict = SignificanceConfig(strong_effect=0.9, strong_consistency=0.99)
    result = analyze(events, metric, config=cfg_strict)

    assert result.signal_strength not in ("strong",)


def test_bootstrap_ci_none_by_default():
    event_days = [10, 20, 30]
    metric = _make_pattern_metric(event_days)
    events = [Event(timestamp=BASE + timedelta(days=d), label="test") for d in event_days]

    result = analyze(events, metric)
    assert result.effect_ci is None


def test_bootstrap_ci_returns_valid_interval():
    event_days = [10, 20, 30]
    metric = _make_pattern_metric(event_days)
    events = [Event(timestamp=BASE + timedelta(days=d), label="test") for d in event_days]

    result = analyze(events, metric, bootstrap_ci=True, bootstrap_resamples=199)

    assert result.effect_ci is not None
    low, high = result.effect_ci
    assert low <= result.effect_size <= high
    assert low < high


def test_baseline_strategy_invalid_raises():
    metric = _make_flat_metric("hrv", hours=700)
    events = [Event(timestamp=BASE + timedelta(days=10), label="test")]
    with pytest.raises(ValueError, match="Invalid baseline_strategy"):
        analyze(events, metric, baseline_strategy="monthly")


def test_baseline_strategy_same_weekday_runs():
    event_days = [10, 20, 30]
    metric = _make_pattern_metric(event_days)
    events = [Event(timestamp=BASE + timedelta(days=d), label="test") for d in event_days]
    result = analyze(events, metric, baseline_strategy="same_weekday")
    assert isinstance(result.significant, bool)


def test_baseline_strategy_same_hour_runs():
    event_days = [10, 20, 30]
    metric = _make_pattern_metric(event_days)
    events = [Event(timestamp=BASE + timedelta(days=d), label="test") for d in event_days]
    result = analyze(events, metric, baseline_strategy="same_hour")
    assert isinstance(result.significant, bool)


def test_same_weekday_reduces_baseline_to_matching_days():
    """Same-weekday baseline should only contain same day-of-week as each event."""
    from datetime import datetime as _dt
    event_days = [10, 20, 30]
    metric = _make_pattern_metric(event_days)
    events = [Event(timestamp=BASE + timedelta(days=d), label="test") for d in event_days]

    result_rolling = analyze(events, metric, baseline_strategy="rolling")
    result_weekday = analyze(events, metric, baseline_strategy="same_weekday")
    # Both must return valid results; weekday baseline may differ in median
    assert isinstance(result_rolling.baseline_median, float)
    assert isinstance(result_weekday.baseline_median, float)


def test_bootstrap_ci_excludes_zero_for_strong_pattern():
    event_days = [10, 20, 30]
    metric = _make_pattern_metric(event_days, low=30.0, high=55.0)
    events = [Event(timestamp=BASE + timedelta(days=d), label="test") for d in event_days]

    result = analyze(events, metric, bootstrap_ci=True, bootstrap_resamples=199)

    low, high = result.effect_ci
    # Strong drop → CI should not include 0
    assert high < 0 or low > 0
