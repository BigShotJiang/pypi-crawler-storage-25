from chrono_correlator.exports import export_html, export_markdown
from chrono_correlator.models import AlertReport, CorrelationResult


def _make_report(with_narrative: bool = True) -> AlertReport:
    r = CorrelationResult(
        metric_name="hrv",
        p_value=0.01,
        significant=True,
        effect_size=-0.45,
        baseline_median=55.0,
        pre_event_median=30.0,
        consistency=0.9,
        signal_strength="strong",
        association_strength=0.7,
        effect_ci=(-0.65, -0.25),
        narrative="Patron detectado en HRV." if with_narrative else None,
    )
    return AlertReport(
        level="yellow",
        active_signals=1,
        total_signals=1,
        results=[r],
        narrative="[hrv] Patron detectado en HRV." if with_narrative else None,
    )


def test_export_html_creates_file(tmp_path):
    path = str(tmp_path / "report.html")
    export_html(_make_report(), path)
    content = open(path, encoding="utf-8").read()
    assert "hrv" in content
    assert "YELLOW" in content
    assert "0.0100" in content


def test_export_html_contains_ci(tmp_path):
    path = str(tmp_path / "report.html")
    export_html(_make_report(), path)
    content = open(path, encoding="utf-8").read()
    assert "-0.650" in content
    assert "-0.250" in content


def test_export_html_includes_narrative(tmp_path):
    path = str(tmp_path / "report.html")
    export_html(_make_report(), path)
    assert "Patron detectado" in open(path, encoding="utf-8").read()


def test_export_html_no_narrative(tmp_path):
    path = str(tmp_path / "report.html")
    export_html(_make_report(with_narrative=False), path)
    content = open(path, encoding="utf-8").read()
    assert "hrv" in content  # still renders table


def test_export_markdown_creates_file(tmp_path):
    path = str(tmp_path / "report.md")
    export_markdown(_make_report(), path)
    content = open(path, encoding="utf-8").read()
    assert "YELLOW" in content
    assert "|" in content
    assert "hrv" in content


def test_export_markdown_includes_ci(tmp_path):
    path = str(tmp_path / "report.md")
    export_markdown(_make_report(), path)
    assert "-0.650" in open(path, encoding="utf-8").read()


def test_export_markdown_includes_narrative(tmp_path):
    path = str(tmp_path / "report.md")
    export_markdown(_make_report(), path)
    assert "Patron detectado" in open(path, encoding="utf-8").read()
