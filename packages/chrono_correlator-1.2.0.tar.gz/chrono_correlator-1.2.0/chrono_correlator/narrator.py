# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Raúl Gallardo (g3v3r)

import json
import os
from abc import ABC, abstractmethod
from datetime import datetime

from .models import AlertReport, CorrelationResult

# ---------------------------------------------------------------------------
# Prompt templates — named presets for common domains
# Pass the key ("finance", "it", "science") or a raw format string.
# Available placeholders: {metric_name} {baseline_median} {pre_event_median}
#   {p_value} {effect_size} {consistency} {association_strength} {signal_strength}
# ---------------------------------------------------------------------------
PROMPT_TEMPLATES: dict[str, str] = {
    "default": (
        "Datos estadísticos CALCULADOS (no los inventes ni los modifiques):\n"
        "Variable: {metric_name}\n"
        "Mediana baseline: {baseline_median}\n"
        "Mediana pre-evento: {pre_event_median}\n"
        "p-valor Mann-Whitney U: {p_value}\n"
        "Tamaño del efecto (rank-biserial): {effect_size}\n"
        "Consistencia: {consistency}\n"
        "Escribe UNA frase en español. Máximo 20 palabras.\n"
        "Usa: patrón detectado, asociación observada.\n"
        "Prohibido: diagnóstico, causa, predice, confirma."
    ),
    "finance": (
        "Verified statistical data (do not invent or modify):\n"
        "Metric: {metric_name}\n"
        "Baseline median: {baseline_median:.4f}\n"
        "Pre-event median: {pre_event_median:.4f}\n"
        "Mann-Whitney p-value: {p_value:.4f}\n"
        "Rank-biserial effect: {effect_size:.3f}\n"
        "Consistency: {consistency:.2f}\n"
        "Write ONE sentence in English. Max 20 words.\n"
        "Use: correlation observed, pre-event pattern detected.\n"
        "Forbidden: predicts, causes, confirms, buy, sell."
    ),
    "it": (
        "Verified statistical data (do not invent or modify):\n"
        "Metric: {metric_name}\n"
        "Baseline median: {baseline_median:.4f}\n"
        "Pre-event median: {pre_event_median:.4f}\n"
        "Mann-Whitney p-value: {p_value:.4f}\n"
        "Rank-biserial effect: {effect_size:.3f}\n"
        "Consistency: {consistency:.2f}\n"
        "Write ONE sentence in English. Max 20 words.\n"
        "Use: anomaly detected, pre-incident signal, pattern observed.\n"
        "Forbidden: will fail, causes, confirms, predicts outage."
    ),
    "science": (
        "Verified statistical data (do not invent or modify):\n"
        "Variable: {metric_name}\n"
        "Baseline median: {baseline_median:.4f}\n"
        "Pre-event median: {pre_event_median:.4f}\n"
        "Mann-Whitney U p-value: {p_value:.4f}\n"
        "Rank-biserial effect size: {effect_size:.3f}\n"
        "Event consistency: {consistency:.2f}\n"
        "Write ONE declarative sentence in English. Max 20 words.\n"
        "Use: association observed, temporal correlation detected.\n"
        "Forbidden: causes, proves, confirms, diagnoses."
    ),
}


def _build_prompt(r: CorrelationResult, template: str | None = None) -> str:
    """Build the LLM prompt for a significant result.

    template: None → "default" preset
              preset key ("finance", "it", "science", "default")
              raw format string with {metric_name}, {p_value}, etc.
    """
    tpl = template or "default"
    if tpl in PROMPT_TEMPLATES:
        tpl = PROMPT_TEMPLATES[tpl]
    return tpl.format(
        metric_name=r.metric_name,
        baseline_median=r.baseline_median,
        pre_event_median=r.pre_event_median,
        p_value=r.p_value,
        effect_size=r.effect_size,
        consistency=r.consistency,
        association_strength=r.association_strength,
        signal_strength=r.signal_strength,
    )


def _write_audit(path: str, result: CorrelationResult, prompt: str) -> None:
    """Append one JSONL entry: stats + prompt + LLM response."""
    entry = {
        "ts": datetime.now().isoformat(),
        "metric": result.metric_name,
        "stats": {
            "p_value": result.p_value,
            "effect_size": result.effect_size,
            "association_strength": result.association_strength,
            "signal_strength": result.signal_strength,
            "baseline_median": result.baseline_median,
            "pre_event_median": result.pre_event_median,
        },
        "prompt": prompt,
        "response": result.narrative,
    }
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


class BaseNarrator(ABC):
    """Abstract base for LLM narrator providers.

    prompt_template: preset key or raw format string applied to every narrate() call.
                     Can be overridden per-call in narrate(prompt_template=...).
    """

    def __init__(self, prompt_template: str | None = None):
        self._prompt_template = prompt_template

    @abstractmethod
    def generate(self, prompt: str) -> str:
        """Return a single narration sentence for the given prompt."""

    def narrate(
        self,
        report: AlertReport,
        audit_log: str | None = None,
        prompt_template: str | None = None,
    ) -> AlertReport:
        if report.level == "green":
            return report

        # Resolution order: call-time > instance default > built-in "default"
        tpl = prompt_template or getattr(self, "_prompt_template", None)

        individual_narratives: list[str] = []
        for result in report.results:
            if result.significant:
                prompt = _build_prompt(result, tpl)
                result.narrative = self.generate(prompt)
                if audit_log:
                    _write_audit(audit_log, result, prompt)
                individual_narratives.append(f"[{result.metric_name}] {result.narrative}")

        report.narrative = "\n".join(individual_narratives) if individual_narratives else None
        return report


class GroqNarrator(BaseNarrator):
    def __init__(
        self,
        api_key: str | None = None,
        model: str = "llama3-8b-8192",
        prompt_template: str | None = None,
    ):
        super().__init__(prompt_template)
        try:
            from groq import Groq
        except ImportError:
            raise ImportError(
                "groq is not installed. Run: pip install chrono-correlator[groq]"
            )
        key = api_key or os.environ.get("GROQ_API_KEY")
        if not key:
            raise RuntimeError(
                "GROQ_API_KEY not set. Export it or pass api_key=... to GroqNarrator()."
            )
        self._client = Groq(api_key=key)
        self._model = model

    def generate(self, prompt: str) -> str:
        response = self._client.chat.completions.create(
            model=self._model,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=80,
        )
        return response.choices[0].message.content.strip()


class AnthropicNarrator(BaseNarrator):
    def __init__(
        self,
        api_key: str | None = None,
        model: str = "claude-haiku-4-5-20251001",
        prompt_template: str | None = None,
    ):
        super().__init__(prompt_template)
        try:
            import anthropic as _anthropic
        except ImportError:
            raise ImportError(
                "anthropic is not installed. Run: pip install chrono-correlator[anthropic]"
            )
        key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not key:
            raise RuntimeError(
                "ANTHROPIC_API_KEY not set. Export it or pass api_key=... to AnthropicNarrator()."
            )
        self._client = _anthropic.Anthropic(api_key=key)
        self._model = model

    def generate(self, prompt: str) -> str:
        response = self._client.messages.create(
            model=self._model,
            max_tokens=80,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.content[0].text.strip()


class OllamaNarrator(BaseNarrator):
    """Local LLM narrator via Ollama — no API key, full privacy."""

    def __init__(
        self,
        model: str = "llama3",
        host: str = "http://localhost:11434",
        prompt_template: str | None = None,
    ):
        super().__init__(prompt_template)
        try:
            import ollama as _ollama  # noqa: F401
        except ImportError:
            raise ImportError(
                "ollama is not installed. Run: pip install ollama"
            )
        self._model = model
        self._host = host

    def generate(self, prompt: str) -> str:
        import ollama
        client = ollama.Client(host=self._host)
        response = client.chat(
            model=self._model,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.message.content.strip()


def narrate(
    report: AlertReport,
    provider: str = "groq",
    audit_log: str | None = None,
    prompt_template: str | None = None,
) -> AlertReport:
    """Convenience wrapper — picks narrator by provider name string.

    prompt_template: preset key ("default", "finance", "it", "science")
                     or a raw format string. None uses "default".
    audit_log: path to a JSONL file logging each LLM call (stats + prompt + response).
    """
    narrator: BaseNarrator
    if provider == "groq":
        narrator = GroqNarrator()
    elif provider == "anthropic":
        narrator = AnthropicNarrator()
    elif provider == "ollama":
        narrator = OllamaNarrator()
    else:
        raise ValueError(
            f"Unknown provider '{provider}'. Use 'groq', 'anthropic', 'ollama', "
            "or instantiate a BaseNarrator subclass directly."
        )
    return narrator.narrate(report, audit_log=audit_log, prompt_template=prompt_template)