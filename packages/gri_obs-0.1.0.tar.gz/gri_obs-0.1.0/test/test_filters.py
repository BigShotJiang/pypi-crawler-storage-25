import numpy as np
from gri_pos import Pos
from scipy.spatial.transform import Rotation

from gri_obs import (
    AoaObs,
    FdoaObs,
    RangeObs,
    TdoaObs,
    filter_aoa,
    filter_by_emitter,
    filter_by_sensor,
    filter_fdoa,
    filter_range,
    filter_tdoa,
)


def _make_tdoa(sensor_id="s1", emitter_id=None) -> TdoaObs:
    return TdoaObs(
        time=0.0,
        value=1e-6,
        std_dev=1e-9,
        collector1=Pos.LLA(0.0, 0.0, 0.0),
        collector2=Pos.LLA(1.0, 1.0, 0.0),
        sensor_id=sensor_id,
        emitter_id=emitter_id,
    )


def _make_fdoa(sensor_id="s2", emitter_id=None) -> FdoaObs:
    return FdoaObs(
        time=0.0,
        value=0.5,
        std_dev=0.1,
        collector1=Pos.LLA(0.0, 0.0, 0.0),
        collector2=Pos.LLA(1.0, 1.0, 0.0),
        collector1_vel=np.array([0.0, 7500.0, 0.0]),
        collector2_vel=np.array([0.0, 7500.0, 0.0]),
        frequency_hz=1e9,
        sensor_id=sensor_id,
        emitter_id=emitter_id,
    )


def _make_aoa(sensor_id="s3", emitter_id=None) -> AoaObs:
    return AoaObs(
        time=0.0,
        u=0.1,
        v=0.2,
        covariance=np.eye(2) * 1e-6,
        collector=Pos.LLA(0.0, 0.0, 0.0),
        collector_rotation=Rotation.identity(),
        sensor_id=sensor_id,
        emitter_id=emitter_id,
    )


def _make_range(sensor_id="s4", emitter_id=None) -> RangeObs:
    return RangeObs(
        time=0.0,
        value=1000.0,
        std_dev=10.0,
        collector=Pos.LLA(0.0, 0.0, 0.0),
        sensor_id=sensor_id,
        emitter_id=emitter_id,
    )


def test_filter_tdoa():
    obs = [_make_tdoa(), _make_fdoa(), _make_aoa(), _make_range()]
    result = filter_tdoa(obs)
    assert len(result) == 1
    assert isinstance(result[0], TdoaObs)


def test_filter_fdoa():
    obs = [_make_tdoa(), _make_fdoa(), _make_aoa(), _make_range()]
    result = filter_fdoa(obs)
    assert len(result) == 1
    assert isinstance(result[0], FdoaObs)


def test_filter_aoa():
    obs = [_make_tdoa(), _make_fdoa(), _make_aoa(), _make_range()]
    result = filter_aoa(obs)
    assert len(result) == 1
    assert isinstance(result[0], AoaObs)


def test_filter_range():
    obs = [_make_tdoa(), _make_fdoa(), _make_aoa(), _make_range()]
    result = filter_range(obs)
    assert len(result) == 1
    assert isinstance(result[0], RangeObs)


def test_filter_by_sensor():
    obs = [_make_tdoa("s1"), _make_fdoa("s2"), _make_tdoa("s1")]
    result = filter_by_sensor(obs, "s1")
    assert len(result) == 2


def test_filter_by_emitter():
    obs = [
        _make_tdoa(emitter_id="e1"),
        _make_fdoa(emitter_id="e2"),
        _make_aoa(emitter_id="e1"),
    ]
    result = filter_by_emitter(obs, "e1")
    assert len(result) == 2


def test_filter_empty_list():
    assert filter_tdoa([]) == []
    assert filter_fdoa([]) == []
    assert filter_aoa([]) == []
    assert filter_range([]) == []
    assert filter_by_sensor([], "s1") == []
    assert filter_by_emitter([], "e1") == []
