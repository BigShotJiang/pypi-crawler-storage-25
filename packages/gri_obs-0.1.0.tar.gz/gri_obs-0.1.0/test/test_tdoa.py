import numpy as np
import pytest
from gri_pos import Pos
from gri_utils.observables import get_tdoa

from gri_obs import TdoaObs


@pytest.fixture
def sample_tdoa():
    return TdoaObs(
        time=100.0,
        value=1.5e-6,
        std_dev=1e-9,
        collector1=Pos.LLA(38.0, -77.0, 100.0),
        collector2=Pos.LLA(39.0, -76.0, 100.0),
        sensor_id="tdoa_12",
        emitter_id="emitter_1",
    )


def test_properties(sample_tdoa):
    assert sample_tdoa.time == 100.0
    assert sample_tdoa.value == pytest.approx(1.5e-6)
    assert sample_tdoa.std_dev == pytest.approx(1e-9)
    assert sample_tdoa.variance == pytest.approx(1e-18)
    assert sample_tdoa.obs_type == "TDOA"
    assert sample_tdoa.sensor_id == "tdoa_12"
    assert sample_tdoa.emitter_id == "emitter_1"
    assert isinstance(sample_tdoa.collector1, Pos)
    assert isinstance(sample_tdoa.collector2, Pos)


def test_emitter_id_default():
    obs = TdoaObs(
        time=0.0,
        value=0.0,
        std_dev=1e-9,
        collector1=Pos.LLA(0.0, 0.0, 0.0),
        collector2=Pos.LLA(1.0, 1.0, 0.0),
        sensor_id="s1",
    )
    assert obs.emitter_id is None


def test_is_valid(sample_tdoa):
    assert sample_tdoa.is_valid()


def test_is_valid_nan():
    obs = TdoaObs(
        time=0.0,
        value=float("nan"),
        std_dev=1e-9,
        collector1=Pos.LLA(0.0, 0.0, 0.0),
        collector2=Pos.LLA(1.0, 1.0, 0.0),
        sensor_id="s1",
    )
    assert not obs.is_valid()


def test_equality(sample_tdoa):
    other = TdoaObs(
        time=100.0,
        value=1.5e-6,
        std_dev=1e-9,
        collector1=Pos.LLA(38.0, -77.0, 100.0),
        collector2=Pos.LLA(39.0, -76.0, 100.0),
        sensor_id="tdoa_12",
        emitter_id="emitter_1",
    )
    assert sample_tdoa == other
    assert hash(sample_tdoa) == hash(other)


def test_inequality_different_value(sample_tdoa):
    other = TdoaObs(
        time=100.0,
        value=2.0e-6,
        std_dev=1e-9,
        collector1=Pos.LLA(38.0, -77.0, 100.0),
        collector2=Pos.LLA(39.0, -76.0, 100.0),
        sensor_id="tdoa_12",
    )
    assert sample_tdoa != other


def test_equality_not_implemented(sample_tdoa):
    assert sample_tdoa != "not an observation"


def test_repr(sample_tdoa):
    r = repr(sample_tdoa)
    assert "TdoaObs" in r
    assert "tdoa_12" in r


@pytest.mark.parametrize(
    ("value", "expected_unit"),
    [
        (1e-8, "ns"),
        (1.5e-6, "us"),
        (5e-3, "ms"),
        (2.5, "s"),
    ],
)
def test_str_auto_scaling(value, expected_unit):
    obs = TdoaObs(
        time=0.0,
        value=value,
        std_dev=1e-9,
        collector1=Pos.LLA(0.0, 0.0, 0.0),
        collector2=Pos.LLA(1.0, 1.0, 0.0),
        sensor_id="s1",
    )
    assert expected_unit in str(obs)


def test_noise_covariance(sample_tdoa):
    r = sample_tdoa.noise_covariance
    assert r.shape == (1, 1)
    assert r[0, 0] == pytest.approx(1e-18)


def test_predicted():
    c1 = Pos.LLA(38.0, -77.0, 400_000.0)
    c2 = Pos.LLA(39.0, -76.0, 400_000.0)
    emitter = Pos.LLA(40.0, -75.0, 0.0)
    obs = TdoaObs(
        time=0.0,
        value=0.0,
        std_dev=1e-9,
        collector1=c1,
        collector2=c2,
        sensor_id="s1",
    )
    state = np.zeros(6)
    state[:3] = emitter.xyz
    pred = obs.predicted(state)
    assert pred.shape == (1,)
    expected = get_tdoa(
        np.asarray(emitter.xyz, dtype=np.float64),
        np.asarray(c1.xyz, dtype=np.float64),
        np.asarray(c2.xyz, dtype=np.float64),
    )
    np.testing.assert_allclose(pred[0], expected, atol=1e-15)


def test_jacobian_shape_and_finite_diff():
    c1 = Pos.LLA(38.0, -77.0, 400_000.0)
    c2 = Pos.LLA(39.0, -76.0, 400_000.0)
    emitter = Pos.LLA(40.0, -75.0, 0.0)
    obs = TdoaObs(
        time=0.0,
        value=0.0,
        std_dev=1e-9,
        collector1=c1,
        collector2=c2,
        sensor_id="s1",
    )
    state = np.zeros(6)
    state[:3] = emitter.xyz
    h = obs.jacobian(state)
    assert h.shape == (1, 6)
    # Velocity columns should be zero for TDOA
    np.testing.assert_array_equal(h[0, 3:6], 0.0)
    # Finite difference check on position columns
    dx = 1.0  # 1 meter perturbation
    for i in range(3):
        state_p = state.copy()
        state_p[i] += dx
        state_m = state.copy()
        state_m[i] -= dx
        fd = (obs.predicted(state_p)[0] - obs.predicted(state_m)[0]) / (2 * dx)
        np.testing.assert_allclose(h[0, i], fd, rtol=1e-5)


def test_jacobian_wider_state():
    obs = TdoaObs(
        time=0.0,
        value=0.0,
        std_dev=1e-9,
        collector1=Pos.LLA(38.0, -77.0, 400_000.0),
        collector2=Pos.LLA(39.0, -76.0, 400_000.0),
        sensor_id="s1",
    )
    state = np.zeros(9)
    state[:3] = Pos.LLA(40.0, -75.0, 0.0).xyz
    h = obs.jacobian(state)
    assert h.shape == (1, 9)
    np.testing.assert_array_equal(h[0, 3:], 0.0)


def test_value_coerced_to_float():
    obs = TdoaObs(
        time=0.0,
        value=np.float64(1.5e-6),
        std_dev=np.float64(1e-9),
        collector1=Pos.LLA(0.0, 0.0, 0.0),
        collector2=Pos.LLA(1.0, 1.0, 0.0),
        sensor_id="s1",
    )
    assert isinstance(obs.value, float)
    assert isinstance(obs.std_dev, float)
