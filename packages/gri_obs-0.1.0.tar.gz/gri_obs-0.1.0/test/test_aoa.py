import math

import numpy as np
import pytest
from gri_pos import Pos
from gri_utils.observables import get_aoa_quat
from scipy.spatial.transform import Rotation

from gri_obs import AoaObs


@pytest.fixture
def sample_aoa():
    return AoaObs(
        time=100.0,
        u=0.1,
        v=0.2,
        covariance=np.array([[1e-6, 0], [0, 1e-6]]),
        collector=Pos.LLA(38.0, -77.0, 100.0),
        collector_rotation=Rotation.identity(),
        sensor_id="aoa_1",
        emitter_id="emitter_1",
    )


def test_properties(sample_aoa):
    assert sample_aoa.time == 100.0
    assert sample_aoa.u == pytest.approx(0.1)
    assert sample_aoa.v == pytest.approx(0.2)
    assert sample_aoa.z_positive is True
    assert sample_aoa.obs_type == "AOA"
    assert sample_aoa.sensor_id == "aoa_1"
    assert sample_aoa.emitter_id == "emitter_1"
    assert isinstance(sample_aoa.collector, Pos)
    assert isinstance(sample_aoa.collector_rotation, Rotation)


def test_direction_cosines(sample_aoa):
    dc = sample_aoa.direction_cosines
    assert dc.shape == (2,)
    np.testing.assert_allclose(dc, [0.1, 0.2])


def test_value_is_direction_cosines(sample_aoa):
    np.testing.assert_array_equal(sample_aoa.value, sample_aoa.direction_cosines)


def test_covariance_shape_and_readonly(sample_aoa):
    assert sample_aoa.covariance.shape == (2, 2)
    with pytest.raises(ValueError, match="read-only"):
        sample_aoa.covariance[0, 0] = 999.0


def test_std_dev(sample_aoa):
    sd = sample_aoa.std_dev
    assert sd.shape == (2,)
    np.testing.assert_allclose(sd, [1e-3, 1e-3])


def test_invalid_direction_cosines():
    with pytest.raises(ValueError, match="direction cosines"):
        AoaObs(
            time=0.0,
            u=0.9,
            v=0.9,
            covariance=np.eye(2) * 1e-6,
            collector=Pos.LLA(0.0, 0.0, 0.0),
            collector_rotation=Rotation.identity(),
            sensor_id="s1",
        )


def test_invalid_covariance_shape():
    with pytest.raises(ValueError, match="covariance shape"):
        AoaObs(
            time=0.0,
            u=0.1,
            v=0.1,
            covariance=np.eye(3),
            collector=Pos.LLA(0.0, 0.0, 0.0),
            collector_rotation=Rotation.identity(),
            sensor_id="s1",
        )


def test_from_azel():
    az_rad = math.radians(45.0)
    el_rad = math.radians(30.0)
    obs = AoaObs.from_azel(
        time=100.0,
        azimuth_rad=az_rad,
        elevation_rad=el_rad,
        std_dev_az_rad=0.001,
        std_dev_el_rad=0.001,
        collector=Pos.LLA(38.0, -77.0, 100.0),
        sensor_id="aoa_1",
    )
    assert obs.is_valid()
    expected_u = math.cos(el_rad) * math.sin(az_rad)
    expected_v = math.cos(el_rad) * math.cos(az_rad)
    assert obs.u == pytest.approx(expected_u, abs=1e-10)
    assert obs.v == pytest.approx(expected_v, abs=1e-10)
    assert obs.z_positive is True


def test_from_azel_roundtrip():
    az_rad = math.radians(120.0)
    el_rad = math.radians(45.0)
    obs = AoaObs.from_azel(
        time=0.0,
        azimuth_rad=az_rad,
        elevation_rad=el_rad,
        std_dev_az_rad=0.001,
        std_dev_el_rad=0.001,
        collector=Pos.LLA(38.0, -77.0, 100.0),
        sensor_id="s1",
    )
    assert obs.azimuth == pytest.approx(az_rad, abs=1e-8)
    assert obs.elevation == pytest.approx(el_rad, abs=1e-8)


def test_is_valid(sample_aoa):
    assert sample_aoa.is_valid()


def test_is_valid_nan():
    obs = AoaObs(
        time=0.0,
        u=float("nan"),
        v=0.1,
        covariance=np.eye(2) * 1e-6,
        collector=Pos.LLA(0.0, 0.0, 0.0),
        collector_rotation=Rotation.identity(),
        sensor_id="s1",
    )
    assert not obs.is_valid()


def test_equality(sample_aoa):
    other = AoaObs(
        time=100.0,
        u=0.1,
        v=0.2,
        covariance=np.array([[1e-6, 0], [0, 1e-6]]),
        collector=Pos.LLA(38.0, -77.0, 100.0),
        collector_rotation=Rotation.identity(),
        sensor_id="aoa_1",
        emitter_id="emitter_1",
    )
    assert sample_aoa == other
    assert hash(sample_aoa) == hash(other)


def test_equality_not_implemented(sample_aoa):
    assert sample_aoa != "not an observation"


def test_repr(sample_aoa):
    r = repr(sample_aoa)
    assert "AoaObs" in r
    assert "aoa_1" in r


def test_str_before_azel_access(sample_aoa):
    s = str(sample_aoa)
    assert "u=" in s
    assert "v=" in s


def test_str_after_azel_access(sample_aoa):
    _ = sample_aoa.azimuth
    s = str(sample_aoa)
    assert "az=" in s
    assert "deg" in s


def test_noise_covariance(sample_aoa):
    r = sample_aoa.noise_covariance
    assert r.shape == (2, 2)
    np.testing.assert_allclose(r, np.array([[1e-6, 0], [0, 1e-6]]))


def test_predicted():
    obs = AoaObs.from_azel(
        time=0.0,
        azimuth_rad=math.radians(45.0),
        elevation_rad=math.radians(30.0),
        std_dev_az_rad=0.001,
        std_dev_el_rad=0.001,
        collector=Pos.LLA(38.0, -77.0, 100.0),
        sensor_id="s1",
    )
    emitter = Pos.LLA(38.5, -76.5, 10_000.0)
    state = np.zeros(6)
    state[:3] = emitter.xyz
    pred = obs.predicted(state)
    assert pred.shape == (2,)
    expected = get_aoa_quat(
        np.asarray(obs.collector.xyz, dtype=np.float64),
        np.asarray(emitter.xyz, dtype=np.float64),
        obs.collector_rotation,
    )
    np.testing.assert_allclose(pred, expected, atol=1e-12)


def test_jacobian_shape_and_finite_diff():
    obs = AoaObs.from_azel(
        time=0.0,
        azimuth_rad=math.radians(45.0),
        elevation_rad=math.radians(30.0),
        std_dev_az_rad=0.001,
        std_dev_el_rad=0.001,
        collector=Pos.LLA(38.0, -77.0, 100.0),
        sensor_id="s1",
    )
    emitter = Pos.LLA(38.5, -76.5, 10_000.0)
    state = np.zeros(6)
    state[:3] = emitter.xyz
    h = obs.jacobian(state)
    assert h.shape == (2, 6)
    # Velocity columns should be zero for AOA
    np.testing.assert_array_equal(h[:, 3:6], 0.0)
    # Finite difference check on position columns
    dx = 1.0
    for i in range(3):
        state_p = state.copy()
        state_p[i] += dx
        state_m = state.copy()
        state_m[i] -= dx
        fd = (obs.predicted(state_p) - obs.predicted(state_m)) / (2 * dx)
        np.testing.assert_allclose(h[:, i], fd, rtol=1e-4)
