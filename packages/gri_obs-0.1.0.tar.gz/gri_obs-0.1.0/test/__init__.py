"""Tests for gri_obs package."""
