import numpy as np
import pytest
from gri_pos import Pos
from gri_utils.observables import get_range

from gri_obs import RangeObs


@pytest.fixture
def sample_range():
    return RangeObs(
        time=100.0,
        value=500_000.0,
        std_dev=100.0,
        collector=Pos.LLA(38.0, -77.0, 400_000.0),
        sensor_id="range_1",
        emitter_id="emitter_1",
    )


def test_properties(sample_range):
    assert sample_range.time == 100.0
    assert sample_range.value == pytest.approx(500_000.0)
    assert sample_range.std_dev == pytest.approx(100.0)
    assert sample_range.variance == pytest.approx(10_000.0)
    assert sample_range.obs_type == "RANGE"
    assert sample_range.sensor_id == "range_1"
    assert sample_range.emitter_id == "emitter_1"
    assert isinstance(sample_range.collector, Pos)


def test_emitter_id_default():
    obs = RangeObs(
        time=0.0,
        value=1000.0,
        std_dev=10.0,
        collector=Pos.LLA(0.0, 0.0, 0.0),
        sensor_id="s1",
    )
    assert obs.emitter_id is None


def test_is_valid(sample_range):
    assert sample_range.is_valid()


def test_is_valid_nan():
    obs = RangeObs(
        time=0.0,
        value=float("nan"),
        std_dev=10.0,
        collector=Pos.LLA(0.0, 0.0, 0.0),
        sensor_id="s1",
    )
    assert not obs.is_valid()


def test_equality(sample_range):
    other = RangeObs(
        time=100.0,
        value=500_000.0,
        std_dev=100.0,
        collector=Pos.LLA(38.0, -77.0, 400_000.0),
        sensor_id="range_1",
        emitter_id="emitter_1",
    )
    assert sample_range == other
    assert hash(sample_range) == hash(other)


def test_inequality(sample_range):
    other = RangeObs(
        time=100.0,
        value=600_000.0,
        std_dev=100.0,
        collector=Pos.LLA(38.0, -77.0, 400_000.0),
        sensor_id="range_1",
    )
    assert sample_range != other


def test_equality_not_implemented(sample_range):
    assert sample_range != "not an observation"


def test_repr(sample_range):
    r = repr(sample_range)
    assert "RangeObs" in r
    assert "range_1" in r


@pytest.mark.parametrize(
    ("value", "expected_unit"),
    [
        (500.0, "m"),
        (5000.0, "km"),
        (5_000_000.0, "Mm"),
    ],
)
def test_str_auto_scaling(value, expected_unit):
    obs = RangeObs(
        time=0.0,
        value=value,
        std_dev=10.0,
        collector=Pos.LLA(0.0, 0.0, 0.0),
        sensor_id="s1",
    )
    assert expected_unit in str(obs)


def test_noise_covariance(sample_range):
    r = sample_range.noise_covariance
    assert r.shape == (1, 1)
    assert r[0, 0] == pytest.approx(10_000.0)


def test_predicted():
    c = Pos.LLA(38.0, -77.0, 400_000.0)
    emitter = Pos.LLA(40.0, -75.0, 0.0)
    obs = RangeObs(
        time=0.0,
        value=0.0,
        std_dev=100.0,
        collector=c,
        sensor_id="s1",
    )
    state = np.zeros(6)
    state[:3] = emitter.xyz
    pred = obs.predicted(state)
    assert pred.shape == (1,)
    expected = get_range(
        np.asarray(c.xyz, dtype=np.float64),
        np.asarray(emitter.xyz, dtype=np.float64),
    )
    np.testing.assert_allclose(pred[0], expected, atol=1e-10)


def test_jacobian_shape_and_finite_diff():
    c = Pos.LLA(38.0, -77.0, 400_000.0)
    emitter = Pos.LLA(40.0, -75.0, 0.0)
    obs = RangeObs(
        time=0.0,
        value=0.0,
        std_dev=100.0,
        collector=c,
        sensor_id="s1",
    )
    state = np.zeros(6)
    state[:3] = emitter.xyz
    h = obs.jacobian(state)
    assert h.shape == (1, 6)
    # Velocity columns should be zero
    np.testing.assert_array_equal(h[0, 3:6], 0.0)
    # Jacobian row should be a unit vector (||grad|| = 1)
    np.testing.assert_allclose(np.linalg.norm(h[0, :3]), 1.0, atol=1e-12)
    # Finite difference check
    dx = 1.0
    for i in range(3):
        state_p = state.copy()
        state_p[i] += dx
        state_m = state.copy()
        state_m[i] -= dx
        fd = (obs.predicted(state_p)[0] - obs.predicted(state_m)[0]) / (2 * dx)
        np.testing.assert_allclose(h[0, i], fd, rtol=1e-5)
