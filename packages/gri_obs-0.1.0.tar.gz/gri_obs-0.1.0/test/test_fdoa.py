import numpy as np
import pytest
from gri_pos import Pos
from gri_utils.observables import get_fdoa

from gri_obs import FdoaObs


@pytest.fixture
def sample_fdoa():
    return FdoaObs(
        time=100.0,
        value=0.5,
        std_dev=0.1,
        collector1=Pos.LLA(38.0, -77.0, 400_000.0),
        collector2=Pos.LLA(39.0, -76.0, 400_000.0),
        collector1_vel=np.array([0.0, 7500.0, 0.0]),
        collector2_vel=np.array([0.0, 7500.0, 0.0]),
        frequency_hz=1e9,
        sensor_id="fdoa_12",
        emitter_id="emitter_1",
    )


def test_properties(sample_fdoa):
    assert sample_fdoa.time == 100.0
    assert sample_fdoa.value == pytest.approx(0.5)
    assert sample_fdoa.std_dev == pytest.approx(0.1)
    assert sample_fdoa.variance == pytest.approx(0.01)
    assert sample_fdoa.obs_type == "FDOA"
    assert sample_fdoa.frequency_hz == pytest.approx(1e9)
    assert sample_fdoa.sensor_id == "fdoa_12"
    assert sample_fdoa.emitter_id == "emitter_1"
    assert isinstance(sample_fdoa.collector1, Pos)
    assert isinstance(sample_fdoa.collector2, Pos)
    np.testing.assert_array_equal(sample_fdoa.collector1_vel, [0.0, 7500.0, 0.0])
    np.testing.assert_array_equal(sample_fdoa.collector2_vel, [0.0, 7500.0, 0.0])


def test_velocity_read_only(sample_fdoa):
    with pytest.raises(ValueError, match="read-only"):
        sample_fdoa.collector1_vel[0] = 999.0


def test_velocity_shape_validation():
    with pytest.raises(ValueError, match="shape"):
        FdoaObs(
            time=0.0,
            value=0.0,
            std_dev=0.1,
            collector1=Pos.LLA(0.0, 0.0, 0.0),
            collector2=Pos.LLA(1.0, 1.0, 0.0),
            collector1_vel=np.array([0.0, 0.0]),
            collector2_vel=np.array([0.0, 0.0, 0.0]),
            frequency_hz=1e9,
            sensor_id="s1",
        )


def test_is_valid(sample_fdoa):
    assert sample_fdoa.is_valid()


def test_is_valid_nan():
    obs = FdoaObs(
        time=0.0,
        value=float("nan"),
        std_dev=0.1,
        collector1=Pos.LLA(0.0, 0.0, 0.0),
        collector2=Pos.LLA(1.0, 1.0, 0.0),
        collector1_vel=np.array([0.0, 0.0, 0.0]),
        collector2_vel=np.array([0.0, 0.0, 0.0]),
        frequency_hz=1e9,
        sensor_id="s1",
    )
    assert not obs.is_valid()


def test_equality(sample_fdoa):
    other = FdoaObs(
        time=100.0,
        value=0.5,
        std_dev=0.1,
        collector1=Pos.LLA(38.0, -77.0, 400_000.0),
        collector2=Pos.LLA(39.0, -76.0, 400_000.0),
        collector1_vel=np.array([0.0, 7500.0, 0.0]),
        collector2_vel=np.array([0.0, 7500.0, 0.0]),
        frequency_hz=1e9,
        sensor_id="fdoa_12",
        emitter_id="emitter_1",
    )
    assert sample_fdoa == other
    assert hash(sample_fdoa) == hash(other)


def test_inequality_different_velocity(sample_fdoa):
    other = FdoaObs(
        time=100.0,
        value=0.5,
        std_dev=0.1,
        collector1=Pos.LLA(38.0, -77.0, 400_000.0),
        collector2=Pos.LLA(39.0, -76.0, 400_000.0),
        collector1_vel=np.array([100.0, 7500.0, 0.0]),
        collector2_vel=np.array([0.0, 7500.0, 0.0]),
        frequency_hz=1e9,
        sensor_id="fdoa_12",
    )
    assert sample_fdoa != other


def test_equality_not_implemented(sample_fdoa):
    assert sample_fdoa != "not an observation"


def test_repr(sample_fdoa):
    r = repr(sample_fdoa)
    assert "FdoaObs" in r
    assert "fdoa_12" in r


@pytest.mark.parametrize(
    ("value", "expected_unit"),
    [
        (50.0, "Hz"),
        (5000.0, "kHz"),
        (5_000_000.0, "MHz"),
    ],
)
def test_str_auto_scaling(value, expected_unit):
    obs = FdoaObs(
        time=0.0,
        value=value,
        std_dev=0.1,
        collector1=Pos.LLA(0.0, 0.0, 0.0),
        collector2=Pos.LLA(1.0, 1.0, 0.0),
        collector1_vel=np.array([0.0, 0.0, 0.0]),
        collector2_vel=np.array([0.0, 0.0, 0.0]),
        frequency_hz=1e9,
        sensor_id="s1",
    )
    assert expected_unit in str(obs)


def test_noise_covariance(sample_fdoa):
    r = sample_fdoa.noise_covariance
    assert r.shape == (1, 1)
    assert r[0, 0] == pytest.approx(0.01)


def _make_fdoa_obs() -> FdoaObs:
    """Create an FDOA obs with realistic satellite geometry."""
    c1 = Pos.LLA(38.0, -77.0, 400_000.0)
    c2 = Pos.LLA(39.0, -76.0, 400_000.0)
    c1_vel = np.array([100.0, 7500.0, 0.0])
    c2_vel = np.array([-100.0, 7500.0, 0.0])
    return FdoaObs(
        time=0.0,
        value=0.0,
        std_dev=0.1,
        collector1=c1,
        collector2=c2,
        collector1_vel=c1_vel,
        collector2_vel=c2_vel,
        frequency_hz=1e9,
        sensor_id="s1",
    )


def test_predicted():
    obs = _make_fdoa_obs()
    emitter = Pos.LLA(40.0, -75.0, 0.0)
    emit_vel = np.array([10.0, 5.0, 0.0])
    state = np.zeros(6)
    state[:3] = emitter.xyz
    state[3:6] = emit_vel
    pred = obs.predicted(state)
    assert pred.shape == (1,)
    expected = get_fdoa(
        np.asarray(emitter.xyz, dtype=np.float64),
        emit_vel,
        np.asarray(obs.collector1.xyz, dtype=np.float64),
        np.asarray(obs.collector2.xyz, dtype=np.float64),
        obs.frequency_hz,
        collector1_vel=obs.collector1_vel,
        collector2_vel=obs.collector2_vel,
    )
    np.testing.assert_allclose(pred[0], expected, atol=1e-12)


def test_jacobian_shape_and_finite_diff():
    obs = _make_fdoa_obs()
    emitter = Pos.LLA(40.0, -75.0, 0.0)
    state = np.zeros(6)
    state[:3] = emitter.xyz
    state[3:6] = [10.0, 5.0, 0.0]
    h = obs.jacobian(state)
    assert h.shape == (1, 6)
    # Finite difference check on all 6 state columns
    dx = 1.0
    for i in range(6):
        state_p = state.copy()
        state_p[i] += dx
        state_m = state.copy()
        state_m[i] -= dx
        fd = (obs.predicted(state_p)[0] - obs.predicted(state_m)[0]) / (2 * dx)
        np.testing.assert_allclose(h[0, i], fd, rtol=1e-4)


def test_jacobian_velocity_columns_nonzero():
    obs = _make_fdoa_obs()
    state = np.zeros(6)
    state[:3] = Pos.LLA(40.0, -75.0, 0.0).xyz
    h = obs.jacobian(state)
    # FDOA depends on velocity -- velocity gradient should be nonzero
    assert np.any(h[0, 3:6] != 0.0)
