[![GeoSol Research Logo](https://geosolresearch.com/logos/foss_logo.png "GeoSol Research")](https://geosolresearch.com)

# GRI Obs

Typed observation objects for geolocation measurements.

## Overview

`gri-obs` provides self-contained observation objects that carry measurement
data, noise characterization, and sensor geometry for geolocation systems.
Each observation embeds everything needed to evaluate measurement functions
against an emitter state vector.

## Observation Types

| Type | Measurement | Units | Collectors |
|------|------------|-------|------------|
| `TdoaObs` | Time Difference of Arrival | seconds | 2 positions |
| `FdoaObs` | Frequency Difference of Arrival | Hz | 2 positions + velocities |
| `AoaObs` | Angle of Arrival (direction cosines) | unitless | 1 position + rotation |
| `RangeObs` | Distance | meters | 1 position |

## Installation

```bash
pip install gri-obs
```

Or for local development:

```bash
git clone https://gitlab.com/geosol-foss/python/gri-obs.git
cd gri-obs
. .init_venv.sh
```

## Usage

```python
from gri_obs import TdoaObs, FdoaObs, AoaObs, RangeObs
from gri_pos import Pos
import numpy as np

# TDOA observation
tdoa = TdoaObs(
    time=100.0,
    value=1.5e-6,           # 1.5 microseconds
    std_dev=1e-9,            # 1 nanosecond
    collector1=Pos.LLA(38.0, -77.0, 400_000.0),
    collector2=Pos.LLA(39.0, -76.0, 400_000.0),
    sensor_id="tdoa_12",
)

# AOA observation from azimuth/elevation
aoa = AoaObs.from_azel(
    time=100.0,
    azimuth_rad=0.785,       # 45 degrees
    elevation_rad=0.524,     # 30 degrees
    std_dev_az_rad=0.001,
    std_dev_el_rad=0.001,
    collector=Pos.LLA(38.0, -77.0, 100.0),
    sensor_id="aoa_1",
)

# Filter mixed observation lists
from gri_obs import filter_tdoa, filter_aoa
all_obs = [tdoa, aoa]
tdoa_only = filter_tdoa(all_obs)
```

## Timestamps

Observations accept any timestamp type -- float seconds, datetime objects, or
`gri_nsepoch.Time` for nanosecond precision. The observation carries the
timestamp but does not interpret it.

## Dependencies

- [gri-utils](https://gitlab.com/geosol-foss/python/gri-utils) -- coordinate
  conversions
- [gri-pos](https://gitlab.com/geosol-foss/python/gri-pos) -- position objects
- [gri-memoize](https://gitlab.com/geosol-foss/python/gri-memoize) -- AOA
  memoized properties

## License

MIT -- see [LICENSE](LICENSE).
