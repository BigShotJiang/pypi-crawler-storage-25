"""Range (distance) observation."""

from __future__ import annotations

from typing import Any

import numpy as np
from gri_pos import Pos
from gri_utils.observables import get_range


class RangeObs:
    """Range observation measuring distance from a collector to an emitter.

    A range observation measures the one-way distance between a single
    collector and an emitter. The measurement is a scalar in meters.

    Attributes:
        time: Timestamp of the observation (float seconds or any time object).
        value: Range measurement in meters.
        std_dev: Standard deviation of measurement in meters.
        collector: Collector position.
        sensor_id: ID of the sensor that generated this observation.
        emitter_id: ID of the emitter being observed (if known).

    Example:
        >>> obs = RangeObs(
        ...     time=100.0,
        ...     value=500_000.0,  # 500 km
        ...     std_dev=100.0,  # 100 m
        ...     collector=Pos.LLA(38.0, -77.0, 400_000.0),
        ...     sensor_id="range_1",
        ... )
    """

    __slots__ = (
        "_collector",
        "_emitter_id",
        "_sensor_id",
        "_std_dev",
        "_time",
        "_value",
    )

    def __init__(  # noqa: PLR0913
        self,
        time: Any,  # noqa: ANN401
        value: float,
        std_dev: float,
        collector: Pos,
        sensor_id: str,
        emitter_id: str | None = None,
    ) -> None:
        """Initialize a range observation.

        Args:
            time: Timestamp of the observation (float seconds or any time
                object). The observation carries this value but does not
                interpret it.
            value: Range measurement in meters.
            std_dev: Standard deviation of measurement in meters.
            collector: Collector position.
            sensor_id: ID of the sensor that generated this observation.
            emitter_id: ID of the emitter being observed (if known).
        """
        self._time = time
        self._value = float(value)
        self._std_dev = float(std_dev)
        self._sensor_id = sensor_id
        self._emitter_id = emitter_id
        self._collector = Pos(collector)

    @property
    def time(self) -> Any:  # noqa: ANN401
        """Timestamp of the observation."""
        return self._time

    @property
    def value(self) -> float:
        """Range measurement in meters."""
        return self._value

    @property
    def std_dev(self) -> float:
        """Standard deviation of measurement in meters."""
        return self._std_dev

    @property
    def variance(self) -> float:
        """Measurement variance in meters**2."""
        return self._std_dev**2

    @property
    def obs_type(self) -> str:
        """Observation type identifier."""
        return "RANGE"

    @property
    def collector(self) -> Pos:
        """Collector position."""
        return self._collector

    @property
    def sensor_id(self) -> str:
        """ID of the sensor that generated this observation."""
        return self._sensor_id

    @property
    def emitter_id(self) -> str | None:
        """ID of the emitter being observed (if known)."""
        return self._emitter_id

    # =========================================================================
    # Measurement math
    # =========================================================================

    @property
    def noise_covariance(self) -> np.ndarray:
        """Measurement noise covariance R, shape (1, 1)."""
        return np.array([[self._std_dev**2]])

    def predicted(self, state: np.ndarray) -> np.ndarray:
        """Compute predicted range measurement h(x) given emitter state.

        Args:
            state: Emitter state vector. state[:3] is position (XYZ ECEF
                meters). state[3:6] is velocity if present (unused by Range).

        Returns:
            Predicted range in meters, shape (1,).
        """
        emit_xyz = state[:3]
        r = get_range(
            np.asarray(self._collector.xyz, dtype=np.float64),
            emit_xyz,
        )
        return np.atleast_1d(r)

    def jacobian(self, state: np.ndarray) -> np.ndarray:
        """Compute Jacobian H of range w.r.t. emitter state.

        The gradient of range w.r.t. emitter position is the unit vector
        from collector to emitter: d(range)/d(emit) = (emit - coll) / range.

        Args:
            state: Emitter state vector. state[:3] is position (XYZ ECEF
                meters).

        Returns:
            Jacobian matrix, shape (1, state_dim). Velocity columns are
            zero since range depends only on position.
        """
        emit_xyz = state[:3]
        coll_xyz = np.asarray(self._collector.xyz, dtype=np.float64)
        state_dim = len(state)
        diff = emit_xyz - coll_xyz
        r = np.linalg.norm(diff)
        h = np.zeros((1, state_dim))
        if r > 0:
            h[0, :3] = diff / r
        return h

    def is_valid(self) -> bool:
        """Check if observation values are valid (finite)."""
        return bool(
            np.isfinite(self._value)
            and np.isfinite(self._std_dev)
            and np.isfinite(self._collector.xyz).all(),
        )

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"RangeObs(sensor='{self._sensor_id}', "
            f"time={self._time}, value={self._value:.6g}m)"
        )

    def __str__(self) -> str:
        """Return human-readable string with auto-scaled units."""
        time_str = self._time.iso if hasattr(self._time, "iso") else str(self._time)
        abs_val = abs(self._value)
        if abs_val < 1e3:  # noqa: PLR2004
            scaled = self._value
            unit = "m"
        elif abs_val < 1e6:  # noqa: PLR2004
            scaled = self._value / 1e3
            unit = "km"
        else:
            scaled = self._value / 1e6
            unit = "Mm"
        return f"Range @ {time_str}: {scaled:.3f} {unit}"

    def __eq__(self, other: object) -> bool:
        """Check equality with another RangeObs."""
        if not isinstance(other, RangeObs):
            return NotImplemented
        return (
            self._time == other._time
            and self._value == other._value
            and self._std_dev == other._std_dev
            and self._sensor_id == other._sensor_id
            and self._emitter_id == other._emitter_id
            and self._collector == other._collector
        )

    def __hash__(self) -> int:
        """Return hash value."""
        return hash(
            (
                self._time,
                self._value,
                self._std_dev,
                self._sensor_id,
                self._emitter_id,
                self._collector.xyz.tobytes(),
            ),
        )
