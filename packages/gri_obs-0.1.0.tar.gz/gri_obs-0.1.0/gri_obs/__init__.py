"""Typed observation objects for geolocation measurements.

Each observation type carries all the collector state needed for geolocation,
making observations self-contained. Observation types are data containers
with measurement metadata, sensor geometry, and noise characterization.

Observation Types:
    - TdoaObs: Time Difference of Arrival (seconds)
    - FdoaObs: Frequency Difference of Arrival (Hz)
    - AoaObs: Angle of Arrival (direction cosines)
    - RangeObs: Range / distance (meters)

The Observation type alias is a union of all observation types.

Example:
    >>> from gri_obs import TdoaObs, Observation
    >>> obs: Observation = TdoaObs(...)
"""

from .aoa import AoaObs
from .fdoa import FdoaObs
from .filters import (
    filter_aoa,
    filter_by_emitter,
    filter_by_sensor,
    filter_fdoa,
    filter_range,
    filter_tdoa,
)
from .range_obs import RangeObs
from .tdoa import TdoaObs

Observation = TdoaObs | FdoaObs | AoaObs | RangeObs

__all__ = [
    "AoaObs",
    "FdoaObs",
    "Observation",
    "RangeObs",
    "TdoaObs",
    "filter_aoa",
    "filter_by_emitter",
    "filter_by_sensor",
    "filter_fdoa",
    "filter_range",
    "filter_tdoa",
]
