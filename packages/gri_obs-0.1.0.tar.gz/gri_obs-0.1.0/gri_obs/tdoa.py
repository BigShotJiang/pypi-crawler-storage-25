"""Time Difference of Arrival observation."""

from __future__ import annotations

from typing import Any

import numpy as np
from gri_pos import Pos
from gri_utils.observables import get_tdoa, tdoa_with_gradient


class TdoaObs:
    """Time Difference of Arrival observation.

    A TDOA observation measures the difference in signal arrival time between
    two collectors. The measurement is a scalar in seconds.

    Attributes:
        time: Timestamp of the observation (float seconds or any time object).
        value: TDOA measurement in seconds.
        std_dev: Standard deviation of measurement in seconds.
        collector1: First collector position.
        collector2: Second collector position.
        sensor_id: ID of the sensor that generated this observation.
        emitter_id: ID of the emitter being observed (if known).

    Example:
        >>> obs = TdoaObs(
        ...     time=100.0,
        ...     value=1.5e-6,  # 1.5 microseconds
        ...     std_dev=1e-9,  # 1 nanosecond
        ...     collector1=Pos.LLA(38.0, -77.0, 100.0),
        ...     collector2=Pos.LLA(39.0, -76.0, 100.0),
        ...     sensor_id="tdoa_12",
        ... )
    """

    __slots__ = (
        "_collector1",
        "_collector2",
        "_emitter_id",
        "_sensor_id",
        "_std_dev",
        "_time",
        "_value",
    )

    def __init__(  # noqa: PLR0913
        self,
        time: Any,  # noqa: ANN401
        value: float,
        std_dev: float,
        collector1: Pos,
        collector2: Pos,
        sensor_id: str,
        emitter_id: str | None = None,
    ) -> None:
        """Initialize a TDOA observation.

        Args:
            time: Timestamp of the observation (float seconds or any time
                object). The observation carries this value but does not
                interpret it.
            value: TDOA measurement in seconds.
            std_dev: Standard deviation of measurement in seconds.
            collector1: First collector position.
            collector2: Second collector position.
            sensor_id: ID of the sensor that generated this observation.
            emitter_id: ID of the emitter being observed (if known).
        """
        self._time = time
        self._value = float(value)
        self._std_dev = float(std_dev)
        self._sensor_id = sensor_id
        self._emitter_id = emitter_id
        self._collector1 = Pos(collector1)
        self._collector2 = Pos(collector2)

    @property
    def time(self) -> Any:  # noqa: ANN401
        """Timestamp of the observation."""
        return self._time

    @property
    def value(self) -> float:
        """TDOA measurement in seconds."""
        return self._value

    @property
    def std_dev(self) -> float:
        """Standard deviation of measurement in seconds."""
        return self._std_dev

    @property
    def variance(self) -> float:
        """Measurement variance in seconds**2."""
        return self._std_dev**2

    @property
    def obs_type(self) -> str:
        """Observation type identifier."""
        return "TDOA"

    @property
    def collector1(self) -> Pos:
        """First collector position."""
        return self._collector1

    @property
    def collector2(self) -> Pos:
        """Second collector position."""
        return self._collector2

    @property
    def sensor_id(self) -> str:
        """ID of the sensor that generated this observation."""
        return self._sensor_id

    @property
    def emitter_id(self) -> str | None:
        """ID of the emitter being observed (if known)."""
        return self._emitter_id

    # =========================================================================
    # Measurement math
    # =========================================================================

    @property
    def noise_covariance(self) -> np.ndarray:
        """Measurement noise covariance R, shape (1, 1)."""
        return np.array([[self._std_dev**2]])

    def predicted(self, state: np.ndarray) -> np.ndarray:
        """Compute predicted TDOA measurement h(x) given emitter state.

        Args:
            state: Emitter state vector. state[:3] is position (XYZ ECEF
                meters). state[3:6] is velocity if present (unused by TDOA).

        Returns:
            Predicted TDOA in seconds, shape (1,).
        """
        emit_xyz = state[:3]
        tdoa = get_tdoa(
            emit_xyz,
            np.asarray(self._collector1.xyz, dtype=np.float64),
            np.asarray(self._collector2.xyz, dtype=np.float64),
        )
        return np.atleast_1d(tdoa)

    def jacobian(self, state: np.ndarray) -> np.ndarray:
        """Compute Jacobian H of TDOA w.r.t. emitter state.

        Args:
            state: Emitter state vector. state[:3] is position (XYZ ECEF
                meters).

        Returns:
            Jacobian matrix, shape (1, state_dim). Velocity columns are
            zero since TDOA depends only on position.
        """
        emit_xyz = state[:3]
        state_dim = len(state)
        _tdoa, grad = tdoa_with_gradient(
            emit_xyz,
            np.asarray(self._collector1.xyz, dtype=np.float64),
            np.asarray(self._collector2.xyz, dtype=np.float64),
        )
        h = np.zeros((1, state_dim))
        h[0, :3] = grad
        return h

    def is_valid(self) -> bool:
        """Check if observation values are valid (finite)."""
        return bool(
            np.isfinite(self._value)
            and np.isfinite(self._std_dev)
            and np.isfinite(self._collector1.xyz).all()
            and np.isfinite(self._collector2.xyz).all(),
        )

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"TdoaObs(sensor='{self._sensor_id}', "
            f"time={self._time}, value={self._value:.6g}s)"
        )

    def __str__(self) -> str:
        """Return human-readable string with auto-scaled units."""
        time_str = self._time.iso if hasattr(self._time, "iso") else str(self._time)
        abs_val = abs(self._value)
        if abs_val < 1e-6:  # noqa: PLR2004
            scaled = self._value * 1e9
            unit = "ns"
        elif abs_val < 1e-3:  # noqa: PLR2004
            scaled = self._value * 1e6
            unit = "us"
        elif abs_val < 1.0:
            scaled = self._value * 1e3
            unit = "ms"
        else:
            scaled = self._value
            unit = "s"
        return f"TDOA @ {time_str}: {scaled:+.3f} {unit}"

    def __eq__(self, other: object) -> bool:
        """Check equality with another TdoaObs."""
        if not isinstance(other, TdoaObs):
            return NotImplemented
        return (
            self._time == other._time
            and self._value == other._value
            and self._std_dev == other._std_dev
            and self._sensor_id == other._sensor_id
            and self._emitter_id == other._emitter_id
            and self._collector1 == other._collector1
            and self._collector2 == other._collector2
        )

    def __hash__(self) -> int:
        """Return hash value."""
        return hash(
            (
                self._time,
                self._value,
                self._std_dev,
                self._sensor_id,
                self._emitter_id,
                self._collector1.xyz.tobytes(),
                self._collector2.xyz.tobytes(),
            ),
        )
