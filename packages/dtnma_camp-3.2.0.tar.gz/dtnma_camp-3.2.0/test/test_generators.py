#
# Copyright (c) 2020-2026 The Johns Hopkins University Applied Physics
# Laboratory LLC.
#
# This file is part of the C code generator for AMP (CAMP) under the
# DTN Management Architecture (DTNMA) reference implementaton set from APL.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Portions of this work were performed for the Jet Propulsion Laboratory,
# California Institute of Technology, sponsored by the United States Government
# under the prime contract 80NM0018D0004 between the Caltech and NASA under
# subcontract 1658085.
#
''' Verify behavior of the "camp" command tool.
'''
import logging
import os
import shutil
import unittest
from ace import AdmSet, Checker
from camp.generators import (
    create_sql,
    create_impl_h,
    create_impl_c,
)
from .util import TmpDir

LOGGER = logging.getLogger(__name__)
''' Logger for this module '''
SELFDIR = os.path.dirname(__file__)
''' Directory containing this file '''
logging.getLogger('ace').setLevel(logging.ERROR)

ADMS = AdmSet(cache_dir=False)
''' ADM handling outside of test classes '''
# Allow external ADM in `ADM_PATH`
ADMS.load_default_dirs()


class BaseTest(unittest.TestCase):
    ''' Abstract base for generators
    '''

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def setUp(self):
        self.maxDiff = None
        logging.getLogger('sqlalchemy.engine').setLevel(logging.WARNING)
        self._dir = TmpDir()
        LOGGER.info('Working in %s', self._dir)

    def _get_adm(self, file_name):
        ''' Read an ADM file from the 'tests/data' directory.
        '''
        admfile = os.path.join(SELFDIR, 'data', file_name)
        LOGGER.info("Loading %s ... ", admfile)
        adm = ADMS.load_from_file(admfile)
        errs = Checker(ADMS.db_session()).check(adm)
        self.assertEqual([], errs)
        return adm


class TestCreateSql(BaseTest):

    def test_create_sql(self):
        adm = self._get_adm('example-test.yang')
        outdir = os.path.join(os.environ['XDG_DATA_HOME'], 'out')
        os.makedirs(outdir)

        writer = create_sql.Writer(ADMS, adm, outdir, dialect='pgsql')
        out_path = writer.file_path()
        self.assertEqual(
            os.path.join(outdir, 'example_test.sql'),
            out_path
        )

        buf = open(out_path, 'w+')
        writer.write(buf)
        self.assertLess(0, buf.tell())
        buf.seek(0)

        with open(os.path.join(SELFDIR, 'data', 'pgsql', 'example_test.sql'), 'r') as infile:
            content = infile.read()
        self.assertMultiLineEqual(content, buf.read())


class TestCreateCH(BaseTest):

    def test_create_impl_noscrape(self):
        adm = self._get_adm('example-test.yang')
        outdir = os.path.join(os.environ['XDG_DATA_HOME'], 'out')
        os.makedirs(outdir)

        FILES = (
            ('example_test.h', create_impl_h.Writer),
            ('example_test.c', create_impl_c.Writer),
        )
        for filename, Writer in FILES:
            with self.subTest(filename):
                writer = Writer(ADMS, adm, outdir, scrape=False)
                out_path = writer.file_path()
                self.assertEqual(
                    os.path.join(outdir, filename),
                    out_path
                )

                buf = open(out_path, 'w+')
                writer.write(buf)
                self.assertLess(0, buf.tell())
                buf.seek(0)

                with open(os.path.join(SELFDIR, 'data', 'gen_ch', filename), 'r') as infile:
                    content = infile.read()
                self.assertMultiLineEqual(content, buf.read())

    def test_create_impl_scrape(self):
        adm = self._get_adm('example-test.yang')
        outdir = os.path.join(os.environ['XDG_DATA_HOME'], 'out')
        LOGGER.info('Writing to %s', outdir)
        os.makedirs(outdir)

        FILES = (
            ('example_test.h', create_impl_h.Writer),
            ('example_test.c', create_impl_c.Writer),
        )
        for filename, Writer in FILES:
            with self.subTest(filename):
                # pre-place original files
                shutil.rmtree(outdir)
                shutil.copytree(
                    os.path.join(SELFDIR, 'data', 'scrape_ch_same'),
                    outdir
                )

                writer = Writer(ADMS, adm, outdir, scrape=True)
                out_path = writer.file_path()
                self.assertEqual(
                    os.path.join(outdir, filename),
                    out_path
                )

                buf = open(out_path, 'w+')
                writer.write(buf)
                self.assertLess(0, buf.tell())
                buf.seek(0)

                with open(os.path.join(SELFDIR, 'data', 'scrape_ch_same', filename), 'r') as infile:
                    content = infile.read()
                self.assertMultiLineEqual(content, buf.read())
