/* Some extra top C content */

/*  START GENERATED SOURCE HERE */
/** @file
 * This is the compilation unit for the implementation of the
 * ADM module "example-test" for the C-language reference DA.
 * This contains definitions of every AMM object instance in the ADM and
 * file-local callback functions for all EDDs, CTRLs, and OPERs.
 */

#include "example_test.h"
#include "refda/agent.h"
#include "refda/register.h"
#include "refda/edd_prod_ctx.h"
#include "refda/ctrl_exec_ctx.h"
#include "refda/oper_eval_ctx.h"
#include <cace/amm/semtype.h>
#include <cace/ari/text.h>
#include <cace/util/logging.h>
#include <cace/util/defs.h>

/*   START CUSTOM INCLUDES HERE */
#include <this/that/other.h>
#include <order/is/preserved.h>
/*   STOP CUSTOM INCLUDES HERE  */

/*   START CUSTOM FUNCTIONS HERE */
static void something_special()
{
    goes_here();
}
/*   STOP CUSTOM FUNCTIONS HERE  */

/*   START CALLBACK FUNCTIONS HERE */

/* Name: edd_uvast
 * Description:
 *   Example UVAST EDD.
 *
 * Parameters: none
 *
 * Produced type: use of ari:/ARITYPE/UVAST
 */
static void refda_adm_example_test_edd_edd__uvast(refda_edd_prod_ctx_t *ctx)
{
    /*
     * +-------------------------------------------------------------------------+
     * |START CUSTOM FUNCTION refda_adm_example_test_edd_edd__uvast BODY
     * +-------------------------------------------------------------------------+
     */
    // keep comment
    do_some_thing_uvast(ctx);
    /*
     * +-------------------------------------------------------------------------+
     * |STOP CUSTOM FUNCTION refda_adm_example_test_edd_edd__uvast BODY
     * +-------------------------------------------------------------------------+
     */
}

/* Name: edd_uvast_param
 * Description:
 *   Example UVAST EDD with parameters.
 *
 * Parameters list:
 *   - Index 0, name "other", type use of ari:/ARITYPE/UVAST
 *
 * Produced type: use of ari:/ARITYPE/UVAST
 */
static void refda_adm_example_test_edd_edd__uvast__param(refda_edd_prod_ctx_t *ctx)
{
    /*
     * +-------------------------------------------------------------------------+
     * |START CUSTOM FUNCTION refda_adm_example_test_edd_edd__uvast__param BODY
     * +-------------------------------------------------------------------------+
     */
    do_other_thing(ctx);
    /*
     * +-------------------------------------------------------------------------+
     * |STOP CUSTOM FUNCTION refda_adm_example_test_edd_edd__uvast__param BODY
     * +-------------------------------------------------------------------------+
     */
}

/* Name: edd_ac_param
 * Description:
 *   Example UVAST EDD with parameters.
 *
 * Parameters list:
 *   - Index 0, name "other", type ulist of use of ari:/ARITYPE/INT
 *
 * Produced type: use of ari:/ARITYPE/UVAST
 */
static void refda_adm_example_test_edd_edd__ac__param(refda_edd_prod_ctx_t *ctx)
{
    /*
     * +-------------------------------------------------------------------------+
     * |START CUSTOM FUNCTION refda_adm_example_test_edd_edd__ac__param BODY
     * +-------------------------------------------------------------------------+
     */
    do_real_thing(ctx);
    /*
     * +-------------------------------------------------------------------------+
     * |STOP CUSTOM FUNCTION refda_adm_example_test_edd_edd__ac__param BODY
     * +-------------------------------------------------------------------------+
     */
}

/* Name: edd_am_param
 * Description:
 *   Example UVAST EDD with parameters.
 *
 * Parameters list:
 *   - Index 0, name "other", type umap with:
 *       - Keys as use of ari:/ARITYPE/INT
 *       - Values as use of ari:/ARITYPE/TEXTSTR
 *
 * Produced type: use of ari:/ARITYPE/UVAST
 */
static void refda_adm_example_test_edd_edd__am__param(refda_edd_prod_ctx_t *ctx)
{
    /*
     * +-------------------------------------------------------------------------+
     * |START CUSTOM FUNCTION refda_adm_example_test_edd_edd__am__param BODY
     * +-------------------------------------------------------------------------+
     */
    // keep comment
    do_some_thing_am(ctx);
    /*
     * +-------------------------------------------------------------------------+
     * |STOP CUSTOM FUNCTION refda_adm_example_test_edd_edd__am__param BODY
     * +-------------------------------------------------------------------------+
     */
}

/* Name: edd_tbl_param
 * Description:
 *   Example UVAST EDD with parameters.
 *
 * Parameters list:
 *   - Index 0, name "other", type TBLT with 2 columns:
 *       - Index 0, name "one", type use of ari:/ARITYPE/INT
 *       - Index 1, name "two", type use of ari:/ARITYPE/TEXTSTR
 *
 * Produced type: use of ari:/ARITYPE/UVAST
 */
static void refda_adm_example_test_edd_edd__tbl__param(refda_edd_prod_ctx_t *ctx)
{
    /*
     * +-------------------------------------------------------------------------+
     * |START CUSTOM FUNCTION refda_adm_example_test_edd_edd__tbl__param BODY
     * +-------------------------------------------------------------------------+
     */
    // keep comment
    do_some_thing_tbl(ctx);
    /*
     * +-------------------------------------------------------------------------+
     * |STOP CUSTOM FUNCTION refda_adm_example_test_edd_edd__tbl__param BODY
     * +-------------------------------------------------------------------------+
     */
}

/* Name: edd_tp
 * Description:
 *   Example TP EDD: current system time.
 *
 * Parameters: none
 *
 * Produced type: use of ari:/ARITYPE/TP
 */
static void refda_adm_example_test_edd_edd__tp(refda_edd_prod_ctx_t *ctx)
{
    /*
     * +-------------------------------------------------------------------------+
     * |START CUSTOM FUNCTION refda_adm_example_test_edd_edd__tp BODY
     * +-------------------------------------------------------------------------+
     */
    // keep comment
    do_some_thing_tp(ctx);
    /*
     * +-------------------------------------------------------------------------+
     * |STOP CUSTOM FUNCTION refda_adm_example_test_edd_edd__tp BODY
     * +-------------------------------------------------------------------------+
     */
}

/* Name: endpoint_active
 * Description:
 *   Is the given endpoint active? (0=no)
 *
 * Parameters list:
 *   - Index 0, name "endpoint_name", type use of ari:/ARITYPE/TEXTSTR
 *
 * Produced type: use of ari:/ARITYPE/UVAST
 */
static void refda_adm_example_test_edd_endpoint__active(refda_edd_prod_ctx_t *ctx)
{
    /*
     * +-------------------------------------------------------------------------+
     * |START CUSTOM FUNCTION refda_adm_example_test_edd_endpoint__active BODY
     * +-------------------------------------------------------------------------+
     */
    /*
     * +-------------------------------------------------------------------------+
     * |STOP CUSTOM FUNCTION refda_adm_example_test_edd_endpoint__active BODY
     * +-------------------------------------------------------------------------+
     */
}

/* Name: get
 * Description:
 *   Get a single MIB value from the agent.
 *
 * Parameters list:
 *   - Index 0, name "object", type use of ari:/ARITYPE/OBJECT
 *
 * Result name "data", type use of ari:/ARITYPE/BYTESTR
 */
static void refda_adm_example_test_ctrl_get(refda_ctrl_exec_ctx_t *ctx)
{
    /*
     * +-------------------------------------------------------------------------+
     * |START CUSTOM FUNCTION refda_adm_example_test_ctrl_get BODY
     * +-------------------------------------------------------------------------+
     */
    // keep comment
    do_some_thing_ctrl_get(ctx);
    /*
     * +-------------------------------------------------------------------------+
     * |STOP CUSTOM FUNCTION refda_adm_example_test_ctrl_get BODY
     * +-------------------------------------------------------------------------+
     */
}

/* Name: set
 * Description:
 *   Set a single MIB value in the agent.
 *
 * Parameters list:
 *   - Index 0, name "object", type use of ari:/ARITYPE/OBJECT
 *   - Index 1, name "data", type use of ari:/ARITYPE/BYTESTR
 *
 * Result name "errorcode", type use of ari:/ARITYPE/BYTE
 */
static void refda_adm_example_test_ctrl_set(refda_ctrl_exec_ctx_t *ctx)
{
    /*
     * +-------------------------------------------------------------------------+
     * |START CUSTOM FUNCTION refda_adm_example_test_ctrl_set BODY
     * +-------------------------------------------------------------------------+
     */
    // keep comment
    do_some_thing_ctrl_set(ctx);
    /*
     * +-------------------------------------------------------------------------+
     * |STOP CUSTOM FUNCTION refda_adm_example_test_ctrl_set BODY
     * +-------------------------------------------------------------------------+
     */
}

/* Name: add
 * Description:
 *   Add two uvast values. The operands are cast to the least compatible
 *   numeric type before the arithmetic.
 *
 * Parameters: none
 *
 * Operand list:
 *   - Index 0, name "left", type use of ari:/ARITYPE/UVAST
 *   - Index 1, name "right", type use of ari:/ARITYPE/UVAST
 *
 * Result name "result", type use of ari:/ARITYPE/UVAST
 */
static void refda_adm_example_test_oper_add(refda_oper_eval_ctx_t *ctx)
{
    /*
     * +-------------------------------------------------------------------------+
     * |START CUSTOM FUNCTION refda_adm_example_test_oper_add BODY
     * +-------------------------------------------------------------------------+
     */
    // keep comment
    do_some_thing_oper_add(ctx);
    /*
     * +-------------------------------------------------------------------------+
     * |STOP CUSTOM FUNCTION refda_adm_example_test_oper_add BODY
     * +-------------------------------------------------------------------------+
     */
}

/* Name: compare-lt
 * Description:
 *   Compare values for less-than predicate. The operands are cast to the
 *   least compatible numeric type before the comparison.
 *
 * Parameters: none
 *
 * Operand list:
 *   - Index 0, name "left", type use of ari:/ARITYPE/UVAST
 *   - Index 1, name "right", type use of ari:/ARITYPE/UVAST
 *
 * Result name "result", type use of ari:/ARITYPE/BOOL
 */
static void refda_adm_example_test_oper_compare_lt(refda_oper_eval_ctx_t *ctx)
{
    /*
     * +-------------------------------------------------------------------------+
     * |START CUSTOM FUNCTION refda_adm_example_test_oper_compare_lt BODY
     * +-------------------------------------------------------------------------+
     */
    // keep comment
    do_some_thing_compare_lt(ctx);
    /*
     * +-------------------------------------------------------------------------+
     * |STOP CUSTOM FUNCTION refda_adm_example_test_oper_compare_lt BODY
     * +-------------------------------------------------------------------------+
     */
}

/*   STOP CALLBACK FUNCTIONS HERE  */

int refda_adm_example_test_init(refda_agent_t *agent)
{
    CHKERR1(agent);
    CACE_LOG_DEBUG("Registering ADM: " "example-test");
    REFDA_AGENT_LOCK(agent, REFDA_AGENT_ERR_LOCK_FAILED);

    /*   START CUSTOM PRE-INIT HERE */
    // keep comment
    do_my_pre_init(agent);
    /*   STOP CUSTOM PRE-INIT HERE  */

    cace_amm_obj_ns_t *adm = cace_amm_obj_store_add_ns(
        &(agent->objs), cace_amm_idseg_ref_withenum("example", 65535),
        cace_amm_idseg_ref_withenum("test", REFDA_ADM_EXAMPLE_TEST_ENUM_ADM), "2024-11-21");
    if (adm)
    {
        cace_amm_obj_desc_t *obj;
        (void)obj;

        /**
         * Register TYPEDEF objects
         */
        { // For ./TYPEDEF/counter32
            refda_amm_typedef_desc_t *objdata = CACE_MALLOC(sizeof(refda_amm_typedef_desc_t));
            refda_amm_typedef_desc_init(objdata);
            // named semantic type:
            {
                cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                // use of ari:/ARITYPE/UINT
                cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_UINT);
                cace_amm_type_set_use_ref_move(&(objdata->typeobj), &typeref);
            }

            obj = refda_register_typedef(adm, cace_amm_idseg_ref_withenum("counter32", REFDA_ADM_EXAMPLE_TEST_ENUM_OBJID_TYPEDEF_COUNTER32), objdata);
            // no parameters possible
        }
        { // For ./TYPEDEF/gauge32
            refda_amm_typedef_desc_t *objdata = CACE_MALLOC(sizeof(refda_amm_typedef_desc_t));
            refda_amm_typedef_desc_init(objdata);
            // named semantic type:
            {
                cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                // use of ari:/ARITYPE/INT
                cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_INT);
                cace_amm_type_set_use_ref_move(&(objdata->typeobj), &typeref);
            }

            obj = refda_register_typedef(adm, cace_amm_idseg_ref_withenum("gauge32", REFDA_ADM_EXAMPLE_TEST_ENUM_OBJID_TYPEDEF_GAUGE32), objdata);
            // no parameters possible
        }
        { // For ./TYPEDEF/counter64
            refda_amm_typedef_desc_t *objdata = CACE_MALLOC(sizeof(refda_amm_typedef_desc_t));
            refda_amm_typedef_desc_init(objdata);
            // named semantic type:
            {
                cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                // use of ari:/ARITYPE/UVAST
                cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_UVAST);
                cace_amm_type_set_use_ref_move(&(objdata->typeobj), &typeref);
            }

            obj = refda_register_typedef(adm, cace_amm_idseg_ref_withenum("counter64", REFDA_ADM_EXAMPLE_TEST_ENUM_OBJID_TYPEDEF_COUNTER64), objdata);
            // no parameters possible
        }
        { // For ./TYPEDEF/gauge64
            refda_amm_typedef_desc_t *objdata = CACE_MALLOC(sizeof(refda_amm_typedef_desc_t));
            refda_amm_typedef_desc_init(objdata);
            // named semantic type:
            {
                cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                // use of ari:/ARITYPE/VAST
                cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_VAST);
                cace_amm_type_set_use_ref_move(&(objdata->typeobj), &typeref);
            }

            obj = refda_register_typedef(adm, cace_amm_idseg_ref_withenum("gauge64", REFDA_ADM_EXAMPLE_TEST_ENUM_OBJID_TYPEDEF_GAUGE64), objdata);
            // no parameters possible
        }

        /**
         * Register CONST objects
         */
        { // For ./CONST/const1
            refda_amm_const_desc_t *objdata = CACE_MALLOC(sizeof(refda_amm_const_desc_t));
            refda_amm_const_desc_init(objdata);
            // constant value:
            cace_ari_set_int(&(objdata->value), 31);

            obj = refda_register_const(adm, cace_amm_idseg_ref_withenum("const1", REFDA_ADM_EXAMPLE_TEST_ENUM_OBJID_CONST_CONST1), objdata);
            // no parameters
        }
        { // For ./CONST/showall
            refda_amm_const_desc_t *objdata = CACE_MALLOC(sizeof(refda_amm_const_desc_t));
            refda_amm_const_desc_init(objdata);
            // constant value:
            {
                cace_ari_ac_t *acinit = cace_ari_set_ac(&(objdata->value), NULL);
                {
                    cace_ari_t *item = cace_ari_list_push_back_new(acinit->items);
                    // reference to ari://example/test/CONST/const1
                    cace_ari_set_objref_path_intid(item, 65535, 9999, CACE_ARI_TYPE_CONST, 0);
                }
                {
                    cace_ari_t *item = cace_ari_list_push_back_new(acinit->items);
                    cace_ari_set_tp(item, (struct timespec) {-361, 800000000});
                }
                {
                    cace_ari_t *item = cace_ari_list_push_back_new(acinit->items);
                    cace_ari_set_td(item, (struct timespec) {3600, 200000000});
                }
                {
                    cace_ari_t *item = cace_ari_list_push_back_new(acinit->items);
                    cace_ari_set_td(item, (struct timespec) {-3601, 800000000});
                }
                {
                    cace_ari_t *item = cace_ari_list_push_back_new(acinit->items);
                    cace_ari_set_tstr(item, "need \\esc\t", true);
                }
            }

            obj = refda_register_const(adm, cace_amm_idseg_ref_withenum("showall", REFDA_ADM_EXAMPLE_TEST_ENUM_OBJID_CONST_SHOWALL), objdata);
            // no parameters
        }

        /**
         * Register VAR objects
         */
        { // For ./VAR/var_uvast_val
            refda_amm_var_desc_t *objdata = CACE_MALLOC(sizeof(refda_amm_var_desc_t));
            refda_amm_var_desc_init(objdata);
            // stored value type:
            {
                cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                // use of ari:/ARITYPE/UVAST
                cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_UVAST);
                cace_amm_type_set_use_ref_move(&(objdata->val_type), &typeref);
            }
            // initial value:
            cace_ari_set_int(&(objdata->value), 34);

            obj = refda_register_var(adm, cace_amm_idseg_ref_withenum("var_uvast_val", REFDA_ADM_EXAMPLE_TEST_ENUM_OBJID_VAR_VAR__UVAST__VAL), objdata);
            // no parameters
        }

        /**
         * Register EDD objects
         */
        { // For ./EDD/edd_uvast
            refda_amm_edd_desc_t *objdata = CACE_MALLOC(sizeof(refda_amm_edd_desc_t));
            refda_amm_edd_desc_init(objdata);
            // produced type
            {
                cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                // use of ari:/ARITYPE/UVAST
                cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_UVAST);
                cace_amm_type_set_use_ref_move(&(objdata->prod_type), &typeref);
            }
            // callback:
            objdata->produce = refda_adm_example_test_edd_edd__uvast;

            obj = refda_register_edd(adm, cace_amm_idseg_ref_withenum("edd_uvast", REFDA_ADM_EXAMPLE_TEST_ENUM_OBJID_EDD_EDD__UVAST), objdata);
            // no parameters
        }
        { // For ./EDD/edd_uvast_param
            refda_amm_edd_desc_t *objdata = CACE_MALLOC(sizeof(refda_amm_edd_desc_t));
            refda_amm_edd_desc_init(objdata);
            // produced type
            {
                cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                // use of ari:/ARITYPE/UVAST
                cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_UVAST);
                cace_amm_type_set_use_ref_move(&(objdata->prod_type), &typeref);
            }
            // callback:
            objdata->produce = refda_adm_example_test_edd_edd__uvast__param;

            obj = refda_register_edd(adm, cace_amm_idseg_ref_withenum("edd_uvast_param", REFDA_ADM_EXAMPLE_TEST_ENUM_OBJID_EDD_EDD__UVAST__PARAM), objdata);
            // parameters:
            {
                cace_amm_formal_param_t *fparam = refda_register_add_param(obj, "other");
                {
                    cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                    // use of ari:/ARITYPE/UVAST
                    cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_UVAST);
                    cace_amm_type_set_use_ref_move(&(fparam->typeobj), &typeref);
                }
            }
        }
        { // For ./EDD/edd_ac_param
            refda_amm_edd_desc_t *objdata = CACE_MALLOC(sizeof(refda_amm_edd_desc_t));
            refda_amm_edd_desc_init(objdata);
            // produced type
            {
                cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                // use of ari:/ARITYPE/UVAST
                cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_UVAST);
                cace_amm_type_set_use_ref_move(&(objdata->prod_type), &typeref);
            }
            // callback:
            objdata->produce = refda_adm_example_test_edd_edd__ac__param;

            obj = refda_register_edd(adm, cace_amm_idseg_ref_withenum("edd_ac_param", REFDA_ADM_EXAMPLE_TEST_ENUM_OBJID_EDD_EDD__AC__PARAM), objdata);
            // parameters:
            {
                cace_amm_formal_param_t *fparam = refda_register_add_param(obj, "other");
                {
                    // uniform list
                    cace_amm_semtype_ulist_t *semtype = cace_amm_type_set_ulist(&(fparam->typeobj));
                    {
                        cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                        // use of ari:/ARITYPE/INT
                        cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_INT);
                        cace_amm_type_set_use_ref_move(&(semtype->item_type), &typeref);
                    }
                }
                {
                    cace_ari_ac_t *acinit = cace_ari_set_ac(&(fparam->defval), NULL);
                    {
                        cace_ari_t *item = cace_ari_list_push_back_new(acinit->items);
                        cace_ari_set_int(item, 1);
                    }
                    {
                        cace_ari_t *item = cace_ari_list_push_back_new(acinit->items);
                        cace_ari_set_int(item, 2);
                    }
                    {
                        cace_ari_t *item = cace_ari_list_push_back_new(acinit->items);
                        cace_ari_set_int(item, 3);
                    }
                }
            }
        }
        { // For ./EDD/edd_am_param
            refda_amm_edd_desc_t *objdata = CACE_MALLOC(sizeof(refda_amm_edd_desc_t));
            refda_amm_edd_desc_init(objdata);
            // produced type
            {
                cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                // use of ari:/ARITYPE/UVAST
                cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_UVAST);
                cace_amm_type_set_use_ref_move(&(objdata->prod_type), &typeref);
            }
            // callback:
            objdata->produce = refda_adm_example_test_edd_edd__am__param;

            obj = refda_register_edd(adm, cace_amm_idseg_ref_withenum("edd_am_param", REFDA_ADM_EXAMPLE_TEST_ENUM_OBJID_EDD_EDD__AM__PARAM), objdata);
            // parameters:
            {
                cace_amm_formal_param_t *fparam = refda_register_add_param(obj, "other");
                {
                    // uniform map
                    cace_amm_semtype_umap_t *semtype = cace_amm_type_set_umap(&(fparam->typeobj));
                    {
                        cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                        // use of ari:/ARITYPE/INT
                        cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_INT);
                        cace_amm_type_set_use_ref_move(&(semtype->key_type), &typeref);
                    }
                    {
                        cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                        // use of ari:/ARITYPE/TEXTSTR
                        cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_TEXTSTR);
                        cace_amm_type_set_use_ref_move(&(semtype->val_type), &typeref);
                    }
                }
                {
                    cace_ari_am_t *aminit = cace_ari_set_am(&(fparam->defval), NULL);
                    {
                        cace_ari_t *item = cace_ari_tree_safe_get(aminit->items, key)
                        cace_ari_set_tstr(item, "one", true);
                    }
                    {
                        cace_ari_t *item = cace_ari_tree_safe_get(aminit->items, key)
                        cace_ari_set_tstr(item, "three", true);
                    }
                }
            }
        }
        { // For ./EDD/edd_tbl_param
            refda_amm_edd_desc_t *objdata = CACE_MALLOC(sizeof(refda_amm_edd_desc_t));
            refda_amm_edd_desc_init(objdata);
            // produced type
            {
                cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                // use of ari:/ARITYPE/UVAST
                cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_UVAST);
                cace_amm_type_set_use_ref_move(&(objdata->prod_type), &typeref);
            }
            // callback:
            objdata->produce = refda_adm_example_test_edd_edd__tbl__param;

            obj = refda_register_edd(adm, cace_amm_idseg_ref_withenum("edd_tbl_param", REFDA_ADM_EXAMPLE_TEST_ENUM_OBJID_EDD_EDD__TBL__PARAM), objdata);
            // parameters:
            {
                cace_amm_formal_param_t *fparam = refda_register_add_param(obj, "other");
                {
                    // table template
                    cace_amm_semtype_tblt_t *semtype = cace_amm_type_set_tblt_size(&(fparam->typeobj), 2);
                    {
                        cace_amm_named_type_t *col = cace_amm_named_type_array_get(semtype->columns, 0);
                        m_string_set_cstr(col->name, "one");
                        {
                            cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                            // use of ari:/ARITYPE/INT
                            cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_INT);
                            cace_amm_type_set_use_ref_move(&(col->typeobj), &typeref);
                        }
                    }
                    {
                        cace_amm_named_type_t *col = cace_amm_named_type_array_get(semtype->columns, 1);
                        m_string_set_cstr(col->name, "two");
                        {
                            cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                            // use of ari:/ARITYPE/TEXTSTR
                            cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_TEXTSTR);
                            cace_amm_type_set_use_ref_move(&(col->typeobj), &typeref);
                        }
                    }
                }
                {
                    cace_ari_tbl_t *tblinit = cace_ari_set_tbl(&(fparam->defval), NULL);
                    cace_ari_tbl_reset(tblinit, 2, 2);
                    // Row 0 items:
                    {
                        cace_ari_t *item = cace_ari_array_get(tblinit->items, 0);
                        cace_ari_set_int(item, 10);
                    }
                    {
                        cace_ari_t *item = cace_ari_array_get(tblinit->items, 1);
                        cace_ari_set_tstr(item, "ten", true);
                    }
                    // Row 1 items:
                    {
                        cace_ari_t *item = cace_ari_array_get(tblinit->items, 2);
                        cace_ari_set_int(item, 15);
                    }
                    {
                        cace_ari_t *item = cace_ari_array_get(tblinit->items, 3);
                        cace_ari_set_tstr(item, "fifteen", true);
                    }
                }
            }
        }
        { // For ./EDD/edd_tp
            refda_amm_edd_desc_t *objdata = CACE_MALLOC(sizeof(refda_amm_edd_desc_t));
            refda_amm_edd_desc_init(objdata);
            // produced type
            {
                cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                // use of ari:/ARITYPE/TP
                cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_TP);
                cace_amm_type_set_use_ref_move(&(objdata->prod_type), &typeref);
            }
            // callback:
            objdata->produce = refda_adm_example_test_edd_edd__tp;

            obj = refda_register_edd(adm, cace_amm_idseg_ref_withenum("edd_tp", REFDA_ADM_EXAMPLE_TEST_ENUM_OBJID_EDD_EDD__TP), objdata);
            // no parameters
        }
        { // For ./EDD/endpoint_active
            refda_amm_edd_desc_t *objdata = CACE_MALLOC(sizeof(refda_amm_edd_desc_t));
            refda_amm_edd_desc_init(objdata);
            // produced type
            {
                cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                // use of ari:/ARITYPE/UVAST
                cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_UVAST);
                cace_amm_type_set_use_ref_move(&(objdata->prod_type), &typeref);
            }
            // callback:
            objdata->produce = refda_adm_example_test_edd_endpoint__active;

            obj = refda_register_edd(adm, cace_amm_idseg_ref_withenum("endpoint_active", REFDA_ADM_EXAMPLE_TEST_ENUM_OBJID_EDD_ENDPOINT__ACTIVE), objdata);
            // parameters:
            {
                cace_amm_formal_param_t *fparam = refda_register_add_param(obj, "endpoint_name");
                {
                    cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                    // use of ari:/ARITYPE/TEXTSTR
                    cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_TEXTSTR);
                    cace_amm_type_set_use_ref_move(&(fparam->typeobj), &typeref);
                }
            }
        }

        /**
         * Register CTRL objects
         */
        { // For ./CTRL/get
            refda_amm_ctrl_desc_t *objdata = CACE_MALLOC(sizeof(refda_amm_ctrl_desc_t));
            refda_amm_ctrl_desc_init(objdata);
            // result type
            {
                cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                // use of ari:/ARITYPE/BYTESTR
                cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_BYTESTR);
                cace_amm_type_set_use_ref_move(&(objdata->res_type), &typeref);
            }
            // callback:
            objdata->execute = refda_adm_example_test_ctrl_get;

            obj = refda_register_ctrl(adm, cace_amm_idseg_ref_withenum("get", REFDA_ADM_EXAMPLE_TEST_ENUM_OBJID_CTRL_GET), objdata);
            // parameters:
            {
                cace_amm_formal_param_t *fparam = refda_register_add_param(obj, "object");
                {
                    cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                    // use of ari:/ARITYPE/OBJECT
                    cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_OBJECT);
                    cace_amm_type_set_use_ref_move(&(fparam->typeobj), &typeref);
                }
            }
        }
        { // For ./CTRL/set
            refda_amm_ctrl_desc_t *objdata = CACE_MALLOC(sizeof(refda_amm_ctrl_desc_t));
            refda_amm_ctrl_desc_init(objdata);
            // result type
            {
                cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                // use of ari:/ARITYPE/BYTE
                cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_BYTE);
                cace_amm_type_set_use_ref_move(&(objdata->res_type), &typeref);
            }
            // callback:
            objdata->execute = refda_adm_example_test_ctrl_set;

            obj = refda_register_ctrl(adm, cace_amm_idseg_ref_withenum("set", REFDA_ADM_EXAMPLE_TEST_ENUM_OBJID_CTRL_SET), objdata);
            // parameters:
            {
                cace_amm_formal_param_t *fparam = refda_register_add_param(obj, "object");
                {
                    cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                    // use of ari:/ARITYPE/OBJECT
                    cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_OBJECT);
                    cace_amm_type_set_use_ref_move(&(fparam->typeobj), &typeref);
                }
            }
            {
                cace_amm_formal_param_t *fparam = refda_register_add_param(obj, "data");
                {
                    cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                    // use of ari:/ARITYPE/BYTESTR
                    cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_BYTESTR);
                    cace_amm_type_set_use_ref_move(&(fparam->typeobj), &typeref);
                }
            }
        }

        /**
         * Register OPER objects
         */
        { // For ./OPER/add
            refda_amm_oper_desc_t *objdata = CACE_MALLOC(sizeof(refda_amm_oper_desc_t));
            refda_amm_oper_desc_init(objdata);
            // operands:
            cace_amm_named_type_array_resize(objdata->operand_types, 2);
            {
                cace_amm_named_type_t *operand = cace_amm_named_type_array_get(objdata->operand_types, 0);
                m_string_set_cstr(operand->name, "left");
                {
                    cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                    // use of ari:/ARITYPE/UVAST
                    cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_UVAST);
                    cace_amm_type_set_use_ref_move(&(operand->typeobj), &typeref);
                }
            }
            {
                cace_amm_named_type_t *operand = cace_amm_named_type_array_get(objdata->operand_types, 1);
                m_string_set_cstr(operand->name, "right");
                {
                    cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                    // use of ari:/ARITYPE/UVAST
                    cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_UVAST);
                    cace_amm_type_set_use_ref_move(&(operand->typeobj), &typeref);
                }
            }
            // result type:
            {
                cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                // use of ari:/ARITYPE/UVAST
                cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_UVAST);
                cace_amm_type_set_use_ref_move(&(objdata->res_type), &typeref);
            }
            // callback:
            objdata->evaluate = refda_adm_example_test_oper_add;

            obj = refda_register_oper(adm, cace_amm_idseg_ref_withenum("add", REFDA_ADM_EXAMPLE_TEST_ENUM_OBJID_OPER_ADD), objdata);
            // no parameters
        }
        { // For ./OPER/compare-lt
            refda_amm_oper_desc_t *objdata = CACE_MALLOC(sizeof(refda_amm_oper_desc_t));
            refda_amm_oper_desc_init(objdata);
            // operands:
            cace_amm_named_type_array_resize(objdata->operand_types, 2);
            {
                cace_amm_named_type_t *operand = cace_amm_named_type_array_get(objdata->operand_types, 0);
                m_string_set_cstr(operand->name, "left");
                {
                    cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                    // use of ari:/ARITYPE/UVAST
                    cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_UVAST);
                    cace_amm_type_set_use_ref_move(&(operand->typeobj), &typeref);
                }
            }
            {
                cace_amm_named_type_t *operand = cace_amm_named_type_array_get(objdata->operand_types, 1);
                m_string_set_cstr(operand->name, "right");
                {
                    cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                    // use of ari:/ARITYPE/UVAST
                    cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_UVAST);
                    cace_amm_type_set_use_ref_move(&(operand->typeobj), &typeref);
                }
            }
            // result type:
            {
                cace_ari_t typeref = CACE_ARI_INIT_UNDEFINED;
                // use of ari:/ARITYPE/BOOL
                cace_ari_set_aritype(&typeref, CACE_ARI_TYPE_BOOL);
                cace_amm_type_set_use_ref_move(&(objdata->res_type), &typeref);
            }
            // callback:
            objdata->evaluate = refda_adm_example_test_oper_compare_lt;

            obj = refda_register_oper(adm, cace_amm_idseg_ref_withenum("compare-lt", REFDA_ADM_EXAMPLE_TEST_ENUM_OBJID_OPER_COMPARE_LT), objdata);
            // no parameters
        }

        /**
         * Register SBR objects
         */
        { // For ./SBR/sbr1
            refda_amm_sbr_desc_t *objdata = CACE_MALLOC(sizeof(refda_amm_sbr_desc_t));
            refda_amm_sbr_desc_init(objdata);
            // action
            {
                cace_ari_ac_t *acinit = cace_ari_set_ac(&(objdata->action), NULL);
                {
                    cace_ari_t *item = cace_ari_list_push_back_new(acinit->items);
                    // reference to ari://example/test/CTRL/get
                    cace_ari_set_objref_path_intid(item, 65535, 9999, CACE_ARI_TYPE_CTRL, 2);
                }
                {
                    cace_ari_t *item = cace_ari_list_push_back_new(acinit->items);
                    // reference to ari://example/test/CTRL/set
                    cace_ari_set_objref_path_intid(item, 65535, 9999, CACE_ARI_TYPE_CTRL, 3);
                }
            }
            // condition
            {
                cace_ari_ac_t *acinit = cace_ari_set_ac(&(objdata->condition), NULL);
                {
                    cace_ari_t *item = cace_ari_list_push_back_new(acinit->items);
                    // reference to ari://example/test/EDD/edd_uvast
                    cace_ari_set_objref_path_intid(item, 65535, 9999, CACE_ARI_TYPE_EDD, 0);
                }
                {
                    cace_ari_t *item = cace_ari_list_push_back_new(acinit->items);
                    // reference to ari://example/test/VAR/var_uvast_val
                    cace_ari_set_objref_path_intid(item, 65535, 9999, CACE_ARI_TYPE_VAR, 0);
                }
                {
                    cace_ari_t *item = cace_ari_list_push_back_new(acinit->items);
                    // reference to ari://example/test/OPER/compare-lt
                    cace_ari_set_objref_path_intid(item, 65535, 9999, CACE_ARI_TYPE_OPER, 1);
                }
            }
            // min_interval
            cace_ari_set_td(&(objdata->min_interval), (struct timespec) {30, 0});
            // init_enabled
            objdata->init_enabled = false;
            // max_exec_count
            objdata->max_exec_count = 10;

            obj = refda_register_sbr(adm, cace_amm_idseg_ref_withenum("sbr1", REFDA_ADM_EXAMPLE_TEST_ENUM_OBJID_SBR_SBR1), objdata);
        }
        { // For ./SBR/sbr2
            refda_amm_sbr_desc_t *objdata = CACE_MALLOC(sizeof(refda_amm_sbr_desc_t));
            refda_amm_sbr_desc_init(objdata);
            // action
            {
                cace_ari_ac_t *acinit = cace_ari_set_ac(&(objdata->action), NULL);
                {
                    cace_ari_t *item = cace_ari_list_push_back_new(acinit->items);
                    // reference to ari://example/test/CTRL/get
                    cace_ari_set_objref_path_intid(item, 65535, 9999, CACE_ARI_TYPE_CTRL, 2);
                }
                {
                    cace_ari_t *item = cace_ari_list_push_back_new(acinit->items);
                    // reference to ari://example/test/CTRL/set
                    cace_ari_set_objref_path_intid(item, 65535, 9999, CACE_ARI_TYPE_CTRL, 3);
                }
            }
            // condition
            {
                cace_ari_ac_t *acinit = cace_ari_set_ac(&(objdata->condition), NULL);
                {
                    cace_ari_t *item = cace_ari_list_push_back_new(acinit->items);
                    // reference to ari://example/test/EDD/edd_uvast
                    cace_ari_set_objref_path_intid(item, 65535, 9999, CACE_ARI_TYPE_EDD, 0);
                }
                {
                    cace_ari_t *item = cace_ari_list_push_back_new(acinit->items);
                    // reference to ari://example/test/VAR/var_uvast_val
                    cace_ari_set_objref_path_intid(item, 65535, 9999, CACE_ARI_TYPE_VAR, 0);
                }
                {
                    cace_ari_t *item = cace_ari_list_push_back_new(acinit->items);
                    // reference to ari://example/test/OPER/compare-lt
                    cace_ari_set_objref_path_intid(item, 65535, 9999, CACE_ARI_TYPE_OPER, 1);
                }
            }
            // min_interval
            cace_ari_set_td(&(objdata->min_interval), (struct timespec) {0, 0});
            // init_enabled
            objdata->init_enabled = true;
            // max_exec_count
            objdata->max_exec_count = 0;

            obj = refda_register_sbr(adm, cace_amm_idseg_ref_withenum("sbr2", REFDA_ADM_EXAMPLE_TEST_ENUM_OBJID_SBR_SBR2), objdata);
        }

        /**
         * Register TBR objects
         */
        { // For ./TBR/tbr_rule
            refda_amm_tbr_desc_t *objdata = CACE_MALLOC(sizeof(refda_amm_tbr_desc_t));
            refda_amm_tbr_desc_init(objdata);
            // action
            {
                cace_ari_ac_t *acinit = cace_ari_set_ac(&(objdata->action), NULL);
                {
                    cace_ari_t *item = cace_ari_list_push_back_new(acinit->items);
                    // reference to ari://example/test/CTRL/get
                    cace_ari_set_objref_path_intid(item, 65535, 9999, CACE_ARI_TYPE_CTRL, 2);
                }
                {
                    cace_ari_t *item = cace_ari_list_push_back_new(acinit->items);
                    // reference to ari://example/test/CTRL/set
                    cace_ari_set_objref_path_intid(item, 65535, 9999, CACE_ARI_TYPE_CTRL, 3);
                }
            }
            // period
            cace_ari_set_td(&(objdata->period), (struct timespec) {30, 0});
            // start_time
            cace_ari_set_tp(&(objdata->start_time), (struct timespec) {20, 500000000});
            // init_enabled
            objdata->init_enabled = true;
            // max_exec_count
            objdata->max_exec_count = 0;

            obj = refda_register_tbr(adm, cace_amm_idseg_ref_withenum("tbr_rule", REFDA_ADM_EXAMPLE_TEST_ENUM_OBJID_TBR_TBR__RULE), objdata);
        }
    }

    /*   START CUSTOM POST-INIT HERE */
    // keep comment
    do_my_post_init(agent);
    /*   STOP CUSTOM POST-INIT HERE  */

    REFDA_AGENT_UNLOCK(agent, REFDA_AGENT_ERR_LOCK_FAILED);
    return 0;
}
/*  STOP GENERATED SOURCE HERE */

/* some extra bottom C content */
