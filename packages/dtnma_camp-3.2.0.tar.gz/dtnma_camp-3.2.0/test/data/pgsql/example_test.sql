
-- -------------------------------------------------------------------
--
-- File Name: example-test.sql
--
-- Description: auto generated postgressql for module "example-test" 
--
-- Notes: TODO
--
-- Assumptions: TODO
--
-- Modification History:
-- YYYY-MM-DD    AUTHOR          DESCRIPTION
-- ----------    --------------  ------------------------------------
--     AUTO            Auto-generated SQL file
--
-- ------------------------------------------------------------------

DO
$do$
DECLARE
ap_spec_id INTEGER;
fp_spec_id INTEGER;
r_data_model_id INTEGER;

const_const1_oid INTEGER;
const_const1_fid INTEGER;
const_const1_aid INTEGER;
const_showall_oid INTEGER;
const_showall_fid INTEGER;
const_showall_aid INTEGER;

ctrl_get_oid INTEGER;
ctrl_get_fid INTEGER;
ctrl_get_aid INTEGER;
ctrl_set_oid INTEGER;
ctrl_set_fid INTEGER;
ctrl_set_aid INTEGER;

edd_edd_uvast_oid INTEGER;
edd_edd_uvast_fid INTEGER;
edd_edd_uvast_aid INTEGER;
edd_edd_uvast_param_oid INTEGER;
edd_edd_uvast_param_fid INTEGER;
edd_edd_uvast_param_aid INTEGER;
edd_edd_ac_param_oid INTEGER;
edd_edd_ac_param_fid INTEGER;
edd_edd_ac_param_aid INTEGER;
edd_edd_am_param_oid INTEGER;
edd_edd_am_param_fid INTEGER;
edd_edd_am_param_aid INTEGER;
edd_edd_tbl_param_oid INTEGER;
edd_edd_tbl_param_fid INTEGER;
edd_edd_tbl_param_aid INTEGER;
edd_edd_tp_oid INTEGER;
edd_edd_tp_fid INTEGER;
edd_edd_tp_aid INTEGER;
edd_endpoint_active_oid INTEGER;
edd_endpoint_active_fid INTEGER;
edd_endpoint_active_aid INTEGER;

oper_add_oid INTEGER;
oper_add_fid INTEGER;
oper_add_aid INTEGER;
oper_compare_lt_oid INTEGER;
oper_compare_lt_fid INTEGER;
oper_compare_lt_aid INTEGER;

sbr_sbr1_oid INTEGER;
sbr_sbr1_fid INTEGER;
sbr_sbr1_aid INTEGER;
sbr_sbr2_oid INTEGER;
sbr_sbr2_fid INTEGER;
sbr_sbr2_aid INTEGER;

tbr_tbr_rule_oid INTEGER;
tbr_tbr_rule_fid INTEGER;
tbr_tbr_rule_aid INTEGER;

var_var_uvast_val_oid INTEGER;
var_var_uvast_val_fid INTEGER;
var_var_uvast_val_aid INTEGER;

typedef_counter32_oid INTEGER;
typedef_counter32_fid INTEGER;
typedef_counter32_aid INTEGER;
typedef_gauge32_oid INTEGER;
typedef_gauge32_fid INTEGER;
typedef_gauge32_aid INTEGER;
typedef_counter64_oid INTEGER;
typedef_counter64_fid INTEGER;
typedef_counter64_aid INTEGER;
typedef_gauge64_oid INTEGER;
typedef_gauge64_fid INTEGER;
typedef_gauge64_aid INTEGER;
BEGIN
--namespace 
--9999
CALL SP__insert_data_model('ADM', 'test', 9999, 'example', '2024-11-21' , 'First YANG test ADM', r_data_model_id);

-- const

CALL SP__insert_obj_metadata(-2, 'const1', r_data_model_id, 0, null, null, 'Example value.', const_const1_oid);
CALL SP__insert_const_actual_definition(const_const1_oid, 'Example value.', 'ari://ietf/amm-semtype/IDENT/use(name=/ARITYPE/UVAST)', '31', const_const1_aid);

CALL SP__insert_obj_metadata(-2, 'showall', r_data_model_id, 1, null, null, 'Some constant list', const_showall_oid);
CALL SP__insert_const_actual_definition(const_showall_oid, 'Some constant list', 'ari://ietf/amm-semtype/IDENT/use(name=/ARITYPE/AC)', '/AC/(./CONST/const1,/TP/-360.2,/TD/PT1H0.2S,/TD/-PT1H0.2S,%22need%20%5C%5Cesc%09%22)', const_showall_aid);

-- ctrl

CALL SP__insert_obj_metadata(-3, 'get', r_data_model_id, 2, null, null, 'Get a single MIB value from the agent.', ctrl_get_oid);




CALL SP__insert_formal_parmspec( 1, 'formal parameters for get', '/ARITYPE/OBJECT/object', fp_spec_id);
CALL SP__insert_control_formal_definition(ctrl_get_oid, 'Get a single MIB value from the agent.', fp_spec_id, '/ARITYPE/BYTESTR.data', ctrl_get_fid);

CALL SP__insert_obj_metadata(-3, 'set', r_data_model_id, 3, null, null, 'Set a single MIB value in the agent.', ctrl_set_oid);




CALL SP__insert_formal_parmspec( 2, 'formal parameters for set', '/ARITYPE/OBJECT/object,/ARITYPE/BYTESTR/data', fp_spec_id);
CALL SP__insert_control_formal_definition(ctrl_set_oid, 'Set a single MIB value in the agent.', fp_spec_id, '/ARITYPE/BYTE.errorcode', ctrl_set_fid);

-- edd

CALL SP__insert_obj_metadata(-4, 'edd_uvast', r_data_model_id, 0, null, null, 'Example UVAST EDD.', edd_edd_uvast_oid);
CALL SP__insert_edd_formal_definition(edd_edd_uvast_oid, 'Example UVAST EDD.', null, 'ari://ietf/amm-semtype/IDENT/use(name=/ARITYPE/UVAST)', edd_edd_uvast_fid);
CALL SP__insert_edd_actual_definition(edd_edd_uvast_oid, 'The singleton value for edd_uvast', null, edd_edd_uvast_aid);

CALL SP__insert_obj_metadata(-4, 'edd_uvast_param', r_data_model_id, 1, null, null, 'Example UVAST EDD with parameters.', edd_edd_uvast_param_oid);

CALL SP__insert_formal_parmspec( 1, 'formal parameters for edd_uvast_param', '/ARITYPE/UVAST/other', fp_spec_id);
CALL SP__insert_edd_formal_definition(edd_edd_uvast_param_oid, 'Example UVAST EDD with parameters.', fp_spec_id, 'ari://ietf/amm-semtype/IDENT/use(name=/ARITYPE/UVAST)', edd_edd_uvast_param_fid);

CALL SP__insert_obj_metadata(-4, 'edd_ac_param', r_data_model_id, 4, null, null, 'Example UVAST EDD with parameters.', edd_edd_ac_param_oid);

CALL SP__insert_formal_parmspec( 1, 'formal parameters for edd_ac_param', '/aritype/int/other', fp_spec_id);
CALL SP__insert_edd_formal_definition(edd_edd_ac_param_oid, 'Example UVAST EDD with parameters.', fp_spec_id, 'ari://ietf/amm-semtype/IDENT/use(name=/ARITYPE/UVAST)', edd_edd_ac_param_fid);

CALL SP__insert_obj_metadata(-4, 'edd_am_param', r_data_model_id, 5, null, null, 'Example UVAST EDD with parameters.', edd_edd_am_param_oid);

CALL SP__insert_formal_parmspec( 1, 'formal parameters for edd_am_param', 'unhandledType/other', fp_spec_id);
CALL SP__insert_edd_formal_definition(edd_edd_am_param_oid, 'Example UVAST EDD with parameters.', fp_spec_id, 'ari://ietf/amm-semtype/IDENT/use(name=/ARITYPE/UVAST)', edd_edd_am_param_fid);

CALL SP__insert_obj_metadata(-4, 'edd_tbl_param', r_data_model_id, 6, null, null, 'Example UVAST EDD with parameters.', edd_edd_tbl_param_oid);

CALL SP__insert_formal_parmspec( 1, 'formal parameters for edd_tbl_param', 'unhandledType/other', fp_spec_id);
CALL SP__insert_edd_formal_definition(edd_edd_tbl_param_oid, 'Example UVAST EDD with parameters.', fp_spec_id, 'ari://ietf/amm-semtype/IDENT/use(name=/ARITYPE/UVAST)', edd_edd_tbl_param_fid);

CALL SP__insert_obj_metadata(-4, 'edd_tp', r_data_model_id, 2, null, null, 'Example TP EDD: current system time.', edd_edd_tp_oid);
CALL SP__insert_edd_formal_definition(edd_edd_tp_oid, 'Example TP EDD: current system time.', null, 'ari://ietf/amm-semtype/IDENT/use(name=/ARITYPE/TP)', edd_edd_tp_fid);
CALL SP__insert_edd_actual_definition(edd_edd_tp_oid, 'The singleton value for edd_tp', null, edd_edd_tp_aid);

CALL SP__insert_obj_metadata(-4, 'endpoint_active', r_data_model_id, 3, null, null, 'Is the given endpoint active? (0=no)', edd_endpoint_active_oid);

CALL SP__insert_formal_parmspec( 1, 'formal parameters for endpoint_active', '/ARITYPE/TEXTSTR/endpoint_name', fp_spec_id);
CALL SP__insert_edd_formal_definition(edd_endpoint_active_oid, 'Is the given endpoint active? (0=no)', fp_spec_id, 'ari://ietf/amm-semtype/IDENT/use(name=/ARITYPE/UVAST)', edd_endpoint_active_fid);

-- oper

CALL SP__insert_obj_metadata(-6, 'add', r_data_model_id, 0, null, null, 'Add two uvast values. The operands are cast to the least compatible numeric type before the arithmetic.', oper_add_oid);


CALL SP__insert_operator_formal_definition(oper_add_oid, 'Add two uvast values. The operands are cast to the least compatible numeric type before the arithmetic.', null, 2, '.left, .right', 'result', '', oper_add_fid);
CALL SP__insert_operator_actual_definition(oper_add_oid, 'The singleton value for add', null, oper_add_aid);

CALL SP__insert_obj_metadata(-6, 'compare-lt', r_data_model_id, 1, null, null, 'Compare values for less-than predicate. The operands are cast to the least compatible numeric type before the comparison.', oper_compare_lt_oid);


CALL SP__insert_operator_formal_definition(oper_compare_lt_oid, 'Compare values for less-than predicate. The operands are cast to the least compatible numeric type before the comparison.', null, 2, '.left, .right', 'result', '', oper_compare_lt_fid);
CALL SP__insert_operator_actual_definition(oper_compare_lt_oid, 'The singleton value for compare-lt', null, oper_compare_lt_aid);



-- var

CALL SP__insert_obj_metadata(-11, 'var_uvast_val', r_data_model_id, 0, null, null, 'Example UVAST VAR with initialized value.', var_var_uvast_val_oid);

CALL SP__insert_variable_formal_definition(var_var_uvast_val_oid, 'Example UVAST VAR with initialized value.', null, 'NULL', 'expr to do', '34', var_var_uvast_val_fid);
CALL SP__insert_variable_actual_definition(var_var_uvast_val_oid, 'The singleton value for var_uvast_val', null, var_var_uvast_val_aid);
end
$do$



