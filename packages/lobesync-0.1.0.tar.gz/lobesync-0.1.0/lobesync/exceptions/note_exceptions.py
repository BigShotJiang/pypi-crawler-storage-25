class NoteNotFoundError(Exception):
    pass
