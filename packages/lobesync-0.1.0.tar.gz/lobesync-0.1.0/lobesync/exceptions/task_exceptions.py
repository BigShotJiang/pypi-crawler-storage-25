class TaskNotFoundError(Exception):
    pass
