class MemoryNotFoundError(Exception):
    pass
