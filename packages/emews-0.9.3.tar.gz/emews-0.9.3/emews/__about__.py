"""eMews metadata."""
# TODO: get this information from pyproject.toml

__version__ = "0.9.3"

__title__ = "eMews"
__summary__ = "Network traffic automation and prototyping."

__author__ = "Brian Ricks"
__email__ = "absolutefunk@utdallas.edu"

__license__ = "GNU General Public License, Version 3"
__copyright__ = "2017-2026 eMews Project"

_documentation_url = "https://mews.sv.cmu.edu/research/emews/"
