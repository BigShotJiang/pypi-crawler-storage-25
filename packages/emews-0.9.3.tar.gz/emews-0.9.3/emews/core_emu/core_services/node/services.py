"""eMews node CORE Services."""
from typing import Any, Dict, List

import os, pathlib

from core.config import Configuration, ConfigString
from core.services.base import CoreService, ServiceMode

GROUP_NAME: str = "eMews"


class EmewsNodeHub(CoreService):
    """eMews Hub Node."""

    name: str = "HubNode"
    group: str = GROUP_NAME
    directories: List[str] = []
    files: List[str] = ["emews_node_hub.sh"]
    executables: List[str] = ["python3"]
    dependencies: List[str] = []
    startup: List[str] = ["sh emews_node_hub.sh"]
    validate: List[str] = []
    shutdown: List[str] = []
    validation_mode: ServiceMode = ServiceMode.NON_BLOCKING
    default_configs: List[Configuration] = []
    modes: Dict[str, Dict[str, str]] = {}

    def data(self) -> Dict[str, Any]:
        # pkg root path is one level up from the emews package
        emews_pkg_path = pathlib.Path(__file__).parent.parent.parent.parent.parent.resolve()

        if not os.path.exists(f"{emews_pkg_path}/.venv"):
            raise Exception(f"[eMews] {emews_pkg_path}/.venv does not exist - eMews virtual environment should be named '.venv'."
                            f"  No eMews nodes will be able to start as we will not be able to find the package path.\n"
                            f" To fix this, make sure eMews resides in a virtual environment created by venv called .venv.\n"
                            f" IDEs like PyCharm will create a virtual environment with this constraint by default.")

        if not os.path.exists(f"{emews_pkg_path}/.venv/lib"):
            raise Exception(f"[eMews] eMews virtual environment missing the 'lib' directory.  Make sure that the virtual "
                            f"environment was created by venv.")

        if len([pathlib.Path(f"{emews_pkg_path}/.venv/lib").iterdir()]) != 1:
            raise Exception(f"[eMews] {emews_pkg_path}/.venv/lib contains more than one directory.  Make sure that the"
                            f" virtual environment only has packages for one Python version.")

        pkg_python_version = ""
        for item in pathlib.Path(f'{emews_pkg_path}/.venv/lib').iterdir():
            # assume there is only one entry which is a directory (checked above)
            pkg_python_version = item.name

        emews_site_pkg_path = f"{emews_pkg_path}/.venv/lib/{pkg_python_version}/site-packages"

        if not os.path.exists(emews_site_pkg_path):
            raise Exception(f"[eMews] eMews virtual environment missing the 'site_packages' directory.  Make sure that "
                            f"the virtual environment was created by venv.")

        return {
            'emews_pkg_path': emews_pkg_path,
            'emews_site_pkg_path': emews_site_pkg_path,
        }


class EmewsNodeHost(CoreService):
    """eMews Host Node."""

    name: str = "HostNode"
    group: str = GROUP_NAME
    directories: List[str] = []
    files: List[str] = ["emews_node_host.sh"]
    executables: List[str] = ["python3"]
    dependencies: List[str] = []
    startup: List[str] = ["sh emews_node_host.sh"]
    validate: List[str] = []
    shutdown: List[str] = []
    validation_mode: ServiceMode = ServiceMode.NON_BLOCKING
    default_configs: List[Configuration] = []
    modes: Dict[str, Dict[str, str]] = {}

    def data(self) -> Dict[str, Any]:
        # pkg root path is one level up from the emews package
        emews_pkg_path = pathlib.Path(__file__).parent.parent.parent.parent.parent.resolve()

        emews_site_pkg_path = ""

        # do not throw exceptions here, rather let the hub node throw them
        if os.path.exists(f"{emews_pkg_path}/.venv/lib") and len(
                [pathlib.Path(f"{emews_pkg_path}/.venv/lib").iterdir()]) == 1:
            pkg_python_version = ""
            for item in pathlib.Path(f'{emews_pkg_path}/.venv/lib').iterdir():
                # assume there is only one entry which is a directory (checked above)
                pkg_python_version = item.name

            emews_site_pkg_path = f"{emews_pkg_path}/.venv/lib/{pkg_python_version}/site-packages"

        return {
            'emews_pkg_path': emews_pkg_path,
            'emews_site_pkg_path': emews_site_pkg_path,
        }


class EmewsNodeMonitor(CoreService):
    """eMews Monitor Node."""

    name: str = "MonitorNode"
    group: str = GROUP_NAME
    directories: List[str] = []
    files: List[str] = ["emews_node_monitor.sh"]
    executables: List[str] = ["python3"]
    dependencies: List[str] = []
    startup: List[str] = ["sh emews_node_monitor.sh"]
    validate: List[str] = []
    shutdown: List[str] = []
    validation_mode: ServiceMode = ServiceMode.NON_BLOCKING
    default_configs: List[Configuration] = [
        ConfigString(id="emews_start_delay", label="Start Delay", default="2"),
    ]
    modes: Dict[str, Dict[str, str]] = {}

    def data(self) -> Dict[str, Any]:
        # pkg root path is one level up from the emews package
        emews_pkg_path = pathlib.Path(__file__).parent.parent.parent.parent.parent.resolve()

        emews_site_pkg_path = ""

        # do not throw exceptions here, rather let the hub node throw them
        if os.path.exists(f"{emews_pkg_path}/.venv/lib") and len([pathlib.Path(f"{emews_pkg_path}/.venv/lib").iterdir()]) == 1:
            pkg_python_version = ""
            for item in pathlib.Path(f'{emews_pkg_path}/.venv/lib').iterdir():
                # assume there is only one entry which is a directory (checked above)
                pkg_python_version = item.name

            emews_site_pkg_path = f"{emews_pkg_path}/.venv/lib/{pkg_python_version}/site-packages"

        return {
            'emews_pkg_path': emews_pkg_path,
            'emews_site_pkg_path': emews_site_pkg_path,
        }

