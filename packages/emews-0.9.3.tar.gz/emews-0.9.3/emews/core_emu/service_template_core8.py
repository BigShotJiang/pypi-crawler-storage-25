"""eMews service CORE 8 interface."""
import os
from typing import Any, Dict, List

import pathlib

from core.config import Configuration, ConfigString
from core.configservice.base import ConfigService, ConfigServiceMode

SERVICE_NAME: str = "__EMEWS_SERVICE_NAME__"
SERVICE_DISPLAY_NAME: str = "__EMEWS_SERVICE_DISPLAY_NAME__"


class EmewsService__EMEWS_CLASS_NAME__(ConfigService):
    """eMews service class template.  CORE 8 ConfigService paradigm."""

    name: str = SERVICE_DISPLAY_NAME
    group: str = "eMews"
    directories: List[str] = []
    files: List[str] = [f"emews_service_{SERVICE_NAME}.sh"]
    executables: List[str] = ["python3"]
    dependencies: List[str] = ["HostNode"]
    startup: List[str] = [f"sh emews_service_{SERVICE_NAME}.sh"]
    validate: List[str] = []
    shutdown: List[str] = []
    validation_mode: ConfigServiceMode = ConfigServiceMode.NON_BLOCKING
    default_configs: List[Configuration] = [
        ConfigString(id="emews_service_config", label="Service Configuration",
                     options=["default__EMEWS_SERVICE_CONFIGS__"], default="default"),
    ]
    modes: Dict[str, Dict[str, str]] = {}

    def data(self) -> Dict[str, Any]:
        emews_pkg_path = pathlib.Path(__file__).parent.parent.parent.parent.resolve()

        emews_site_pkg_path = ""

        # do not throw exceptions here, rather let the hub node throw them
        if os.path.exists(f"{emews_pkg_path}/.venv/lib") and len(
                [pathlib.Path(f"{emews_pkg_path}/.venv/lib").iterdir()]) == 1:
            pkg_python_version = ""
            for item in pathlib.Path(f'{emews_pkg_path}/.venv/lib').iterdir():
                # assume there is only one entry which is a directory (checked above)
                pkg_python_version = item.name

            emews_site_pkg_path = f"{emews_pkg_path}/.venv/lib/{pkg_python_version}/site-packages"

        return {
            'emews_pkg_path': emews_pkg_path,
            'emews_site_pkg_path': emews_site_pkg_path,
            'emews_service_name': SERVICE_NAME,
        }

    def get_text_template(self, name: str) -> str:
        assert name == f"emews_service_{SERVICE_NAME}.sh"
        return """
        #!/bin/sh
        export PYTHONPATH=${emews_pkg_path}:${emews_site_pkg_path}
        python3 -m emews -n ${node.name} servspawn ${emews_service_name} ${config['emews_service_config']} 1>> emews_servspawn.log 2>&1
        """