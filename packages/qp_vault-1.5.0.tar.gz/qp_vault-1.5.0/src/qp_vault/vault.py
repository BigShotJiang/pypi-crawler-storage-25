"""Main Vault classes: sync and async interfaces.

The primary entry point for qp-vault. Vault (sync) wraps AsyncVault.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from qp_vault.audit.log_auditor import LogAuditor
from qp_vault.config import VaultConfig
from qp_vault.core.chunker import ChunkerConfig
from qp_vault.core.hasher import compute_merkle_root
from qp_vault.core.resource_manager import ResourceManager
from qp_vault.core.search_engine import apply_trust_weighting
from qp_vault.enums import (
    DataClassification,
    EventType,
    Lifecycle,
    MemoryLayer,
    ResourceStatus,
    TrustTier,
)
from qp_vault.exceptions import VaultError
from qp_vault.models import (
    Chunk,
    HealthScore,
    MerkleProof,
    Resource,
    SearchResult,
    VaultEvent,
    VaultVerificationResult,
    VerificationResult,
)
from qp_vault.protocols import (
    AuditProvider,
    EmbeddingProvider,
    LLMScreener,
    ParserProvider,
    PolicyProvider,
    SearchQuery,
    StorageBackend,
)
from qp_vault.storage.sqlite import SQLiteBackend

if TYPE_CHECKING:
    from collections.abc import Callable
    from datetime import date

    from qp_vault.core.layer_manager import LayerView

# Type alias for subscriber callbacks (sync or async).
VaultCallback = "Callable[[VaultEvent], Any]"

# --- Input Sanitization ---

_MAX_SUBSCRIBERS = 100
_MAX_NAME_LENGTH = 255
_MAX_TAG_LENGTH = 100
_MAX_TAGS = 50
_MAX_METADATA_KEYS = 100
_MAX_METADATA_KEY_LENGTH = 100
_MAX_METADATA_VALUE_SIZE = 10_000
_MAX_PATH_STRING_LENGTH = 4096
_BYTES_PER_MB = 1024 * 1024
_LIST_HARD_CAP = 50_000
_LIST_BATCH_SIZE = 1000


def _sanitize_name(name: str) -> str:
    """Sanitize a resource name for safe storage.

    Applies Unicode NFC normalization, strips path components, null bytes,
    control characters, backslashes. Caps length at 255.
    """
    import re
    import unicodedata
    # Unicode NFC normalization (prevents homograph collisions)
    name = unicodedata.normalize("NFC", name)
    # Replace backslashes with forward slashes for cross-platform path stripping
    name = name.replace("\\", "/")
    # Strip path components (takes last segment after /)
    name = Path(name).name
    # Remove null bytes and control characters
    name = re.sub(r"[\x00-\x1f\x7f]", "", name)
    # Strip leading/trailing dots and spaces
    name = name.strip(". ")
    if not name or name in (".", ".."):
        return "untitled"
    return name[:_MAX_NAME_LENGTH]


def _sanitize_tags(tags: list[str]) -> list[str]:
    """Validate and sanitize tag list."""
    import re
    if len(tags) > _MAX_TAGS:
        raise VaultError(f"Too many tags ({len(tags)}), maximum {_MAX_TAGS}")
    clean: list[str] = []
    for tag in tags:
        if not isinstance(tag, str):
            continue
        tag = tag.strip()
        if not tag:
            continue
        if len(tag) > _MAX_TAG_LENGTH:
            raise VaultError(f"Tag exceeds {_MAX_TAG_LENGTH} chars: {tag[:20]}...")
        # Remove control characters
        tag = re.sub(r"[\x00-\x1f\x7f]", "", tag)
        clean.append(tag)
    return clean


def _validate_metadata(metadata: dict[str, Any]) -> None:
    """Validate metadata keys and values for size and safety."""
    import re
    if len(metadata) > _MAX_METADATA_KEYS:
        raise VaultError(f"Too many metadata keys ({len(metadata)}), maximum {_MAX_METADATA_KEYS}")
    for key, value in metadata.items():
        if not isinstance(key, str):
            raise VaultError(f"Metadata key must be a string, got {type(key).__name__}")
        if len(key) > _MAX_METADATA_KEY_LENGTH:
            raise VaultError(f"Metadata key exceeds {_MAX_METADATA_KEY_LENGTH} chars")
        # Keys must be alphanumeric + underscore + dash
        if not re.match(r"^[a-zA-Z0-9_\-\.]+$", key):
            raise VaultError(f"Metadata key contains invalid characters: {key}")
        # Value size check (serialized)
        import json
        val_size = len(json.dumps(value, default=str))
        if val_size > _MAX_METADATA_VALUE_SIZE:
            raise VaultError(f"Metadata value for '{key}' exceeds {_MAX_METADATA_VALUE_SIZE} bytes")


class AsyncVault:
    """Governed knowledge store (async interface).

    Args:
        path: Directory path for vault storage.
        storage: Custom storage backend (default: SQLite).
        embedder: Custom embedding provider (default: None).
        auditor: Custom audit provider (default: JSON logging).
        parsers: Custom file parsers.
        policies: Governance policy providers.
        config: Vault configuration.
        plugins_dir: Directory for local plugin discovery (air-gap mode).
    """

    def __init__(
        self,
        path: str | Path,
        *,
        storage: StorageBackend | None = None,
        embedder: EmbeddingProvider | None = None,
        auditor: AuditProvider | None = None,
        parsers: list[ParserProvider] | None = None,
        policies: list[PolicyProvider] | None = None,
        config: VaultConfig | None = None,
        plugins_dir: str | Path | None = None,
        tenant_id: str | None = None,
        role: str | None = None,
        llm_screener: LLMScreener | None = None,
    ) -> None:
        self.path = Path(path)
        self.path.mkdir(parents=True, exist_ok=True)
        self.config = config or VaultConfig()
        self._locked_tenant_id = tenant_id
        self._role = role  # RBAC: None = no enforcement, "reader"/"writer"/"admin"

        # Storage backend
        if storage is not None:
            self._storage = storage
        else:
            self._storage = SQLiteBackend(self.path / "vault.db")

        # Embedding provider
        self._embedder = embedder

        # Audit provider (auto-detect qp-capsule if installed)
        if auditor is not None:
            self._auditor = auditor
        else:
            try:
                from qp_vault.audit.capsule_auditor import HAS_CAPSULE, CapsuleAuditor
                if HAS_CAPSULE:
                    self._auditor = CapsuleAuditor()
                else:
                    self._auditor = LogAuditor(self.path / "audit.jsonl")
            except ImportError:
                self._auditor = LogAuditor(self.path / "audit.jsonl")

        # Parsers and policies
        self._parsers = parsers or []
        self._policies = policies or []
        self._plugins_dir = Path(plugins_dir) if plugins_dir else None

        # Core components
        chunker_config = ChunkerConfig(
            target_tokens=self.config.chunk_target_tokens,
            min_tokens=self.config.chunk_min_tokens,
            max_tokens=self.config.chunk_max_tokens,
            overlap_tokens=self.config.chunk_overlap_tokens,
        )
        self._resource_manager = ResourceManager(
            storage=self._storage,
            embedder=self._embedder,
            auditor=self._auditor,
            chunker_config=chunker_config,
        )

        # Lifecycle engine
        from qp_vault.core.lifecycle_engine import LifecycleEngine
        self._lifecycle = LifecycleEngine(
            storage=self._storage,
            auditor=self._auditor,
        )

        # Layer manager
        from qp_vault.core.layer_manager import LayerManager
        self._layer_manager = LayerManager(config=self.config)

        # Membrane pipeline (with optional LLM-based adaptive scan)
        from qp_vault.membrane.adaptive_scan import AdaptiveScanConfig
        from qp_vault.membrane.correlate import CorrelateConfig
        from qp_vault.membrane.pipeline import MembranePipeline
        from qp_vault.membrane.remember import get_attack_registry
        adaptive_config = AdaptiveScanConfig(screener=llm_screener) if llm_screener else None
        correlate_config = CorrelateConfig(
            screener=llm_screener, vault=self, tenant_id=tenant_id,
        ) if llm_screener else None
        self._membrane_pipeline: MembranePipeline | None = MembranePipeline(
            adaptive_config=adaptive_config,
            correlate_config=correlate_config,
            attack_registry=get_attack_registry(),
        )

        self._initialized = False
        self._search_count = 0

        # Subscriber callbacks for mutation events
        self._subscribers: list[tuple[Callable[..., Any], bool]] = []

        # Telemetry: operation tracking
        from qp_vault.telemetry import VaultTelemetry
        self._telemetry = VaultTelemetry()

        # TTL cache for expensive operations (health, status)
        self._cache: dict[str, tuple[float, Any]] = {}

    async def _ensure_initialized(self) -> None:
        """Initialize storage backend on first use (lazy init)."""
        if not self._initialized:
            await self._storage.initialize()

            # Check embedding dimension consistency
            if self._embedder and self._embedder.dimensions > 0:
                existing_dim = await self._storage.get_embedding_dimension()
                if existing_dim is not None and existing_dim != self._embedder.dimensions:
                    raise VaultError(
                        f"Embedding dimension mismatch: existing={existing_dim}, "
                        f"new={self._embedder.dimensions}. Cannot mix embedders. "
                        "Re-embed all resources or use a compatible model."
                    )

            self._initialized = True

    def _check_permission(self, operation: str) -> None:
        """Check RBAC permission for an operation."""
        from qp_vault.rbac import check_permission
        check_permission(self._role, operation)

    def _cache_get(self, key: str) -> Any | None:
        """Get a cached value if TTL has not expired."""
        import time
        entry = self._cache.get(key)
        if entry is None:
            return None
        cached_at, value = entry
        if time.monotonic() - cached_at > self.config.health_cache_ttl_seconds:
            del self._cache[key]
            return None
        return value

    def _cache_set(self, key: str, value: Any) -> None:
        """Cache a value with current timestamp."""
        import time
        self._cache[key] = (time.monotonic(), value)

    def _cache_invalidate(self) -> None:
        """Invalidate all cached values (after writes)."""
        self._cache.clear()

    def subscribe(self, callback: Callable[..., Any]) -> Callable[[], None]:
        """Subscribe to vault mutation events.

        The callback receives a VaultEvent on every mutation (add, update,
        delete, transition, trust change). Callbacks can be sync or async;
        async callbacks are scheduled as tasks and never block the caller.

        Args:
            callback: Function accepting a single VaultEvent argument.

        Returns:
            An unsubscribe function. Call it to stop receiving events.
        """
        if len(self._subscribers) >= _MAX_SUBSCRIBERS:
            raise VaultError(f"Maximum subscriber limit reached ({_MAX_SUBSCRIBERS})")
        import inspect
        is_async = inspect.iscoroutinefunction(callback)
        entry = (callback, is_async)
        self._subscribers.append(entry)

        def unsubscribe() -> None:
            import contextlib
            with contextlib.suppress(ValueError):
                self._subscribers.remove(entry)

        return unsubscribe

    async def _notify_subscribers(self, event: Any) -> None:
        """Broadcast a VaultEvent to all registered subscribers.

        Errors in subscriber callbacks are logged and never propagated.
        Async callbacks are awaited with a timeout to prevent blocking
        the event loop. The subscriber list is snapshot-copied before
        iteration so callbacks can safely subscribe/unsubscribe.
        """
        import logging
        logger = logging.getLogger("qp_vault.subscribe")
        # Snapshot: safe against subscribe/unsubscribe during iteration
        snapshot = list(self._subscribers)
        for callback, is_async in snapshot:
            try:
                if is_async:
                    await asyncio.wait_for(callback(event), timeout=5.0)
                else:
                    callback(event)
            except TimeoutError:
                logger.warning("Subscriber callback timed out after 5s")
            except Exception:
                logger.exception("Subscriber callback failed")

    async def _with_timeout(self, coro: Any) -> Any:
        """Wrap a coroutine with the configured query timeout.

        Uses asyncio.create_task + cancel for proper cleanup. When the
        timeout fires, the underlying task is cancelled (not left running).
        """
        timeout_s = self.config.query_timeout_ms / 1000.0
        task = asyncio.ensure_future(coro)
        try:
            return await asyncio.wait_for(asyncio.shield(task), timeout=timeout_s)
        except TimeoutError:
            task.cancel()
            import contextlib
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await task
            raise VaultError(
                f"Operation timed out after {self.config.query_timeout_ms}ms"
            ) from None

    def _resolve_tenant(self, tenant_id: str | None) -> str | None:
        """Resolve effective tenant_id, enforcing lock if set.

        When the vault is locked to a tenant (via __init__ tenant_id):
        - If caller provides no tenant_id, auto-inject the locked tenant.
        - If caller provides a matching tenant_id, allow it.
        - If caller provides a different tenant_id, reject.
        """
        if self._locked_tenant_id is None:
            return tenant_id
        if tenant_id is None:
            return self._locked_tenant_id
        if tenant_id != self._locked_tenant_id:
            raise VaultError(
                f"Tenant mismatch: vault is locked to '{self._locked_tenant_id}' "
                f"but operation specified '{tenant_id}'"
            )
        return tenant_id

    async def _tracked(self, operation: str, coro: Any) -> Any:
        """Run a coroutine with telemetry tracking."""
        import time as _time
        start = _time.monotonic()
        error = False
        try:
            return await coro
        except Exception:
            error = True
            raise
        finally:
            duration = (_time.monotonic() - start) * 1000
            self._telemetry.record(operation, duration, error=error)

    # --- Resource Operations ---

    async def add(
        self,
        source: str | Path | bytes,
        *,
        name: str | None = None,
        trust_tier: TrustTier | str = TrustTier.WORKING,
        classification: DataClassification | str = DataClassification.INTERNAL,
        layer: MemoryLayer | str | None = None,
        collection: str | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        lifecycle: Lifecycle | str = Lifecycle.ACTIVE,
        valid_from: date | None = None,
        valid_until: date | None = None,
        tenant_id: str | None = None,
    ) -> Resource:
        """Add a resource to the vault.

        Args:
            source: File path, text string, or bytes content.
            name: Display name (auto-detected from path if not provided).
            trust_tier: Trust tier (canonical, working, ephemeral, archived).
            classification: Data classification level.
            layer: Memory layer (operational, strategic, compliance).
            collection: Collection ID to add resource to.
            tags: List of tags.
            metadata: Arbitrary key-value metadata.
            lifecycle: Initial lifecycle state.
            valid_from: Start of temporal validity window.
            valid_until: End of temporal validity window.

        Returns:
            The created Resource.
        """
        await self._ensure_initialized()
        self._check_permission("add")
        tenant_id = self._resolve_tenant(tenant_id)

        # Validate enum values early (before they reach storage layer)
        try:
            if isinstance(trust_tier, str):
                trust_tier = TrustTier(trust_tier)
            if isinstance(classification, str):
                classification = DataClassification(classification)
            if isinstance(lifecycle, str):
                lifecycle = Lifecycle(lifecycle)
            if isinstance(layer, str):
                layer = MemoryLayer(layer)
        except ValueError as e:
            raise VaultError(f"Invalid parameter: {e}") from e

        # Input validation: name
        if name is not None:
            name = _sanitize_name(name)

        # Input validation: tags
        if tags is not None:
            tags = _sanitize_tags(tags)

        # Input validation: metadata
        if metadata is not None:
            _validate_metadata(metadata)

        # Resolve source to text
        # Guard against Path() on very long strings (OSError: filename too long)
        _is_path = isinstance(source, Path)
        if not _is_path and isinstance(source, str) and len(source) < _MAX_PATH_STRING_LENGTH:
            try:
                _is_path = Path(source).exists()
            except OSError:
                _is_path = False
        if _is_path:
            if isinstance(source, bytes):
                raise VaultError("bytes source cannot be a path")
            path = Path(source).resolve()
            # Security: reject path traversal attempts
            if ".." in path.parts:
                raise VaultError("Path traversal detected in source path")
            if name is None:
                name = path.name
            # Try parsers first
            text = None
            for parser in self._parsers:
                if path.suffix.lower() in parser.supported_extensions:
                    result = await parser.parse(path)
                    text = result.text
                    break
            if text is None:
                # Default: read as text
                try:
                    text = path.read_text(encoding="utf-8")
                except UnicodeDecodeError:
                    text = path.read_text(encoding="latin-1")
                except Exception:
                    if isinstance(source, str):
                        # It was a string, not a file path
                        text = source
                        if name is None:
                            name = "untitled.md"
                    else:
                        raise
        elif isinstance(source, bytes):
            text = source.decode("utf-8", errors="replace")
            if name is None:
                name = "untitled"
        else:
            text = str(source)
            if name is None:
                name = "untitled.md"

        # Enforce max file size
        if self.config.max_file_size_mb is not None:
            size_mb = len(text.encode("utf-8")) / _BYTES_PER_MB
            if size_mb > self.config.max_file_size_mb:
                raise VaultError(
                    f"Content exceeds max size of {self.config.max_file_size_mb}MB "
                    f"({size_mb:.1f}MB provided)"
                )

        # Per-tenant quota check (atomic count, no TOCTOU window)
        if tenant_id and self.config.max_resources_per_tenant is not None:
            count = await self._storage.count_resources(tenant_id)
            if count >= self.config.max_resources_per_tenant:
                raise VaultError(
                    f"Tenant {tenant_id} has reached the resource limit "
                    f"({self.config.max_resources_per_tenant})"
                )

        # Strip null bytes from content (prevents storage/search corruption)
        text = text.replace("\x00", "")

        # Membrane screening (if pipeline configured)
        _quarantine = False
        if self._membrane_pipeline:
            from qp_vault.enums import MembraneResult
            membrane_result = await self._membrane_pipeline.screen(text)
            if membrane_result.overall_result == MembraneResult.FAIL:
                raise VaultError("Content rejected by Membrane screening")
            if membrane_result.recommended_status.value == "quarantined":
                _quarantine = True

        resource: Resource = await self._tracked("add", self._resource_manager.add(
            text,
            name=name,
            trust_tier=trust_tier,
            classification=classification,
            layer=layer,
            collection=collection,
            tags=tags,
            metadata=metadata,
            lifecycle=lifecycle,
            valid_from=valid_from,
            valid_until=valid_until,
            tenant_id=tenant_id,
        ))

        # If Membrane flagged content, mark as quarantined + suspicious
        if _quarantine:
            from qp_vault.protocols import ResourceUpdate
            await self._storage.update_resource(
                resource.id,
                ResourceUpdate(adversarial_status="suspicious"),
            )
            resource = resource.model_copy(
                update={"status": ResourceStatus.QUARANTINED, "adversarial_status": "suspicious"}
            )

        self._cache_invalidate()
        await self._fire_hook("post_add", resource=resource)
        await self._notify_subscribers(VaultEvent(
            event_type=EventType.CREATE,
            resource_id=resource.id,
            resource_name=resource.name,
            resource_hash=resource.content_hash,
            details={"trust_tier": resource.trust_tier.value},
        ))
        return resource

    async def _fire_hook(self, event: str, **kwargs: Any) -> None:
        """Fire plugin hooks (silent on failure)."""
        from qp_vault.plugins.registry import get_registry
        await get_registry().fire_hooks(event, **kwargs)

    async def get(self, resource_id: str) -> Resource:
        """Get a single resource by ID."""
        await self._ensure_initialized()
        resource = await self._resource_manager.get(resource_id)

        # Audit reads on RESTRICTED resources
        if resource.data_classification == DataClassification.RESTRICTED:
            from qp_vault.enums import EventType
            from qp_vault.models import VaultEvent
            await self._auditor.record(VaultEvent(
                event_type=EventType.SEARCH,
                resource_id=resource_id,
                resource_name=resource.name,
                resource_hash=resource.content_hash,
                details={"classification": "restricted", "operation": "get"},
            ))

        return resource

    async def get_multiple(self, resource_ids: list[str]) -> list[Resource]:
        """Get multiple resources by ID in a single query.

        Args:
            resource_ids: List of resource IDs to retrieve.

        Returns:
            List of found Resources (missing IDs silently omitted).
        """
        await self._ensure_initialized()
        return await self._storage.get_resources(resource_ids)

    async def list(
        self,
        *,
        tenant_id: str | None = None,
        trust_tier: TrustTier | str | None = None,
        classification: DataClassification | str | None = None,
        layer: MemoryLayer | str | None = None,
        collection: str | None = None,
        lifecycle: Lifecycle | str | None = None,
        status: ResourceStatus | str | None = None,
        tags: list[str] | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Resource]:
        """List resources with optional filters."""
        await self._ensure_initialized()
        tenant_id = self._resolve_tenant(tenant_id)
        return await self._resource_manager.list(
            tenant_id=tenant_id,
            trust_tier=trust_tier,
            classification=classification,
            layer=layer,
            collection=collection,
            lifecycle=lifecycle,
            status=status,
            tags=tags,
            limit=limit,
            offset=offset,
        )

    async def find_by_name(
        self,
        name: str,
        *,
        tenant_id: str | None = None,
        collection_id: str | None = None,
    ) -> Resource | None:
        """Find a resource by name (case-insensitive).

        Returns the first matching non-deleted resource, or None.

        Args:
            name: Resource name to search for.
            tenant_id: Optional tenant scope.
            collection_id: Optional collection scope.

        Returns:
            Matching Resource or None.
        """
        await self._ensure_initialized()
        self._check_permission("search")
        tenant_id = self._resolve_tenant(tenant_id)

        from qp_vault.protocols import ResourceFilter
        resources = await self._storage.list_resources(
            ResourceFilter(
                tenant_id=tenant_id,
                collection_id=collection_id,
                limit=500,
            )
        )
        name_lower = name.lower()
        for r in resources:
            if r.name.lower() == name_lower:
                return r
        return None

    async def update(
        self,
        resource_id: str,
        *,
        name: str | None = None,
        trust_tier: TrustTier | str | None = None,
        classification: DataClassification | str | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Resource:
        """Update resource metadata."""
        await self._ensure_initialized()
        self._check_permission("update")
        result = await self._resource_manager.update(
            resource_id,
            name=name,
            trust_tier=trust_tier,
            classification=classification,
            tags=tags,
            metadata=metadata,
        )
        self._cache_invalidate()
        await self._fire_hook("post_update", resource=result)
        await self._notify_subscribers(VaultEvent(
            event_type=EventType.UPDATE,
            resource_id=result.id,
            resource_name=result.name,
            resource_hash=result.content_hash,
        ))
        return result

    async def delete(self, resource_id: str, *, hard: bool = False) -> None:
        """Delete a resource (soft by default)."""
        await self._ensure_initialized()
        self._check_permission("delete")
        # Fetch name before deletion for the event
        resource = await self._resource_manager.get(resource_id)
        await self._resource_manager.delete(resource_id, hard=hard)
        self._cache_invalidate()
        await self._fire_hook("post_delete", resource_id=resource_id)
        await self._notify_subscribers(VaultEvent(
            event_type=EventType.DELETE,
            resource_id=resource_id,
            resource_name=resource.name,
            resource_hash=resource.content_hash,
            details={"hard": hard},
        ))

    async def get_content(self, resource_id: str) -> str:
        """Retrieve the full text content of a resource.

        Reassembles chunks in order to reconstruct the original text.

        Args:
            resource_id: The resource to retrieve content for.

        Returns:
            The full text content, with chunks joined by newlines.
        """
        await self._ensure_initialized()
        self._check_permission("get_content")

        # Block content retrieval for quarantined resources
        resource = await self._resource_manager.get(resource_id)
        if resource.status == ResourceStatus.QUARANTINED:
            raise VaultError(
                f"Resource {resource_id} is quarantined by Membrane screening"
            )

        chunks = await self._storage.get_chunks_for_resource(resource_id)
        if not chunks:
            raise VaultError(f"No content found for resource {resource_id}")
        sorted_chunks = sorted(chunks, key=lambda c: c.chunk_index)
        return "\n\n".join(c.content for c in sorted_chunks)

    async def reprocess(self, resource_id: str) -> Resource:
        """Re-chunk and re-embed an existing resource.

        Retrieves the resource content from stored chunks, then runs the
        full ingest pipeline again (chunk, CID, embed). Useful when the
        embedding model changes or chunking parameters are updated.

        Args:
            resource_id: The resource to reprocess.

        Returns:
            The updated Resource with new chunk_count and INDEXED status.
        """
        await self._ensure_initialized()
        self._check_permission("update")

        # Verify resource exists and get content
        await self._resource_manager.get(resource_id)
        chunks = await self._storage.get_chunks_for_resource(resource_id)
        if not chunks:
            raise VaultError(f"No content found for resource {resource_id}")
        sorted_chunks = sorted(chunks, key=lambda c: c.chunk_index)
        text = "\n\n".join(c.content for c in sorted_chunks)

        # Re-chunk
        import uuid

        from qp_vault.core.chunker import chunk_text
        from qp_vault.core.hasher import compute_cid
        chunk_results = chunk_text(text, self._resource_manager._chunker_config)

        new_chunks: list[Chunk] = []
        for cr in chunk_results:
            chunk_id = str(uuid.uuid4())
            cid = compute_cid(cr.content)
            new_chunks.append(
                Chunk(
                    id=chunk_id,
                    resource_id=resource_id,
                    content=cr.content,
                    cid=cid,
                    chunk_index=cr.chunk_index,
                    page_number=cr.page_number,
                    section_title=cr.section_title,
                    token_count=cr.token_count,
                )
            )

        # Re-embed if provider available
        if self._embedder and new_chunks:
            texts = [c.content for c in new_chunks]
            embeddings = await self._embedder.embed(texts)
            for chunk, emb in zip(new_chunks, embeddings, strict=False):
                chunk.embedding = emb

        # Store (replaces existing chunks, updates status to INDEXED)
        await self._storage.store_chunks(resource_id, new_chunks)

        self._cache_invalidate()
        updated = await self._resource_manager.get(resource_id)
        await self._notify_subscribers(VaultEvent(
            event_type=EventType.UPDATE,
            resource_id=resource_id,
            resource_name=updated.name,
            resource_hash=updated.content_hash,
            details={"reprocessed": True, "chunk_count": len(new_chunks)},
        ))
        return updated

    async def upsert(
        self,
        source: str | Path | bytes,
        *,
        name: str | None = None,
        trust_tier: TrustTier | str = TrustTier.WORKING,
        tenant_id: str | None = None,
        **kwargs: Any,
    ) -> Resource:
        """Add or replace a resource atomically.

        If a resource with the same name (and tenant_id) exists, replaces it.
        Otherwise, creates a new resource. The old version is superseded.

        Args:
            source: File path, text string, or bytes content.
            name: Resource name to match on (required for upsert semantics).
            trust_tier: Trust tier for the resource.
            tenant_id: Tenant scope.
            **kwargs: Additional args passed to add().

        Returns:
            The created or updated Resource.
        """
        await self._ensure_initialized()
        self._check_permission("add")
        tenant_id = self._resolve_tenant(tenant_id)

        # Resolve name for matching
        if name is None and isinstance(source, Path):
            name = source.name
        if name is None and isinstance(source, str) and len(source) < _MAX_PATH_STRING_LENGTH:
            try:
                p = Path(source)
                if p.exists():
                    name = p.name
            except OSError:
                pass

        # Find existing resource with same name + tenant
        if name:
            from qp_vault.protocols import ResourceFilter
            existing = await self._storage.list_resources(
                ResourceFilter(tenant_id=tenant_id, limit=1)
            )
            for r in existing:
                if r.name == name:
                    return (await self.replace(r.id, source if isinstance(source, str) else str(source)))[1]

        return await self.add(source, name=name, trust_tier=trust_tier, tenant_id=tenant_id, **kwargs)

    async def replace(
        self,
        resource_id: str,
        new_content: str,
        *,
        reason: str | None = None,
    ) -> tuple[Resource, Resource]:
        """Replace a resource's content atomically.

        Creates a new resource with the new content and supersedes the old one.
        The old resource transitions to SUPERSEDED.

        Args:
            resource_id: The resource to replace.
            new_content: The new text content.
            reason: Optional reason for the replacement.

        Returns:
            Tuple of (old_resource, new_resource).
        """
        await self._ensure_initialized()
        self._check_permission("replace")
        old_resource = await self.get(resource_id)

        # Create new version with same metadata
        new_resource = await self.add(
            new_content,
            name=old_resource.name,
            trust_tier=old_resource.trust_tier,
            classification=old_resource.data_classification,
            layer=old_resource.layer,
            collection=old_resource.collection_id,
            tags=old_resource.tags,
            metadata=old_resource.metadata,
        )

        # Supersede old with new
        return await self.supersede(resource_id, new_resource.id)

    async def add_batch(
        self,
        sources: list[str | Path | bytes],
        *,
        trust_tier: TrustTier | str = TrustTier.WORKING,
        tenant_id: str | None = None,
        **kwargs: Any,
    ) -> list[Resource]:
        """Add multiple resources in a batch.

        Args:
            sources: List of file paths, text strings, or bytes.
            trust_tier: Default trust tier for all resources.
            tenant_id: Optional tenant scope.
            **kwargs: Additional args passed to each add() call.

        Returns:
            List of created Resources.
        """
        await self._ensure_initialized()
        self._check_permission("add_batch")
        tenant_id = self._resolve_tenant(tenant_id)
        if sources is None:
            raise VaultError("sources must not be None")
        results: list[Resource] = []
        src: str | Path | bytes
        for src in sources:
            r = await self.add(src, trust_tier=trust_tier, tenant_id=tenant_id, **kwargs)
            results.append(r)
        return results

    async def get_provenance(self, resource_id: str) -> list[dict[str, Any]]:
        """Get all provenance records for a resource.

        Returns:
            List of provenance records in chronological order.
        """
        await self._ensure_initialized()
        self._check_permission("get_provenance")
        return await self._storage.get_provenance(resource_id)

    async def set_adversarial_status(self, resource_id: str, status: str) -> Resource:
        """Set the adversarial verification status of a resource.

        Args:
            resource_id: The resource to update.
            status: One of 'unverified', 'verified', 'suspicious'.

        Returns:
            Updated resource.
        """
        await self._ensure_initialized()
        self._check_permission("set_adversarial_status")
        from qp_vault.protocols import ResourceUpdate
        return await self._storage.update_resource(
            resource_id, ResourceUpdate(adversarial_status=status)
        )

    # --- Lifecycle ---

    async def transition(
        self,
        resource_id: str,
        target: Lifecycle | str,
        *,
        reason: str | None = None,
    ) -> Resource:
        """Transition a resource's lifecycle state.

        Valid transitions:
            DRAFT -> REVIEW, ACTIVE, ARCHIVED
            REVIEW -> ACTIVE, DRAFT, ARCHIVED
            ACTIVE -> SUPERSEDED, EXPIRED, ARCHIVED
            SUPERSEDED -> ARCHIVED
            EXPIRED -> ACTIVE, ARCHIVED
            ARCHIVED -> (terminal, no transitions)
        """
        await self._ensure_initialized()
        self._check_permission("transition")
        result = await self._lifecycle.transition(resource_id, target, reason=reason)
        await self._fire_hook("post_transition", resource=result, target=target)
        await self._notify_subscribers(VaultEvent(
            event_type=EventType.LIFECYCLE_TRANSITION,
            resource_id=result.id,
            resource_name=result.name,
            resource_hash=result.content_hash,
            details={"target": target, "reason": reason or ""},
        ))
        return result

    async def supersede(
        self, old_id: str, new_id: str
    ) -> tuple[Resource, Resource]:
        """Mark old resource as superseded by new resource."""
        await self._ensure_initialized()
        self._check_permission("supersede")
        return await self._lifecycle.supersede(old_id, new_id)

    async def expiring(self, *, days: int = 90) -> list[Resource]:
        """Find resources expiring within N days."""
        await self._ensure_initialized()
        return await self._lifecycle.expiring(days=days)

    async def chain(self, resource_id: str) -> list[Resource]:
        """Get the full supersession chain for a resource."""
        await self._ensure_initialized()
        return await self._lifecycle.chain(resource_id)

    async def diff(self, old_id: str, new_id: str) -> dict[str, Any]:
        """Compare two resource versions (unified diff).

        Args:
            old_id: The older resource ID.
            new_id: The newer resource ID.

        Returns:
            Dict with old_id, new_id, additions, deletions, and diff text.
        """
        await self._ensure_initialized()
        import difflib

        old_content = await self.get_content(old_id)
        new_content = await self.get_content(new_id)

        old_resource = await self.get(old_id)
        new_resource = await self.get(new_id)

        diff_lines = list(difflib.unified_diff(
            old_content.splitlines(keepends=True),
            new_content.splitlines(keepends=True),
            fromfile=old_resource.name,
            tofile=new_resource.name,
        ))

        return {
            "old_id": old_id,
            "new_id": new_id,
            "old_name": old_resource.name,
            "new_name": new_resource.name,
            "additions": sum(1 for line in diff_lines if line.startswith("+") and not line.startswith("+++")),
            "deletions": sum(1 for line in diff_lines if line.startswith("-") and not line.startswith("---")),
            "diff": "".join(diff_lines),
        }

    # --- Search ---

    async def search(
        self,
        query: str,
        *,
        tenant_id: str | None = None,
        top_k: int = 10,
        offset: int = 0,
        threshold: float = 0.0,
        min_trust_tier: TrustTier | str | None = None,
        layer: MemoryLayer | str | None = None,
        collection: str | None = None,
        as_of: date | None = None,
        deduplicate: bool = True,
        explain: bool = False,
        _layer_boost: float = 1.0,
    ) -> list[SearchResult]:
        """Trust-weighted hybrid search.

        Args:
            query: Search query text.
            top_k: Maximum number of results.
            threshold: Minimum relevance score.
            min_trust_tier: Minimum trust tier for results.
            layer: Filter to specific memory layer.
            collection: Filter to specific collection.
            as_of: Point-in-time search (returns resources active at that date).

        Returns:
            List of SearchResult sorted by trust-weighted relevance.
        """
        await self._ensure_initialized()
        self._check_permission("search")
        tenant_id = self._resolve_tenant(tenant_id)

        # Lazy expiration: check every 100 searches
        self._search_count += 1
        if self.config.auto_expire and self._search_count % 100 == 0:
            import contextlib
            with contextlib.suppress(Exception):
                await self._lifecycle.check_expirations()

        # Generate query embedding if embedder available
        query_embedding = None
        if self._embedder:
            embeddings = await self._embedder.embed([query])
            query_embedding = embeddings[0]

        # Fallback to text-only search when no embeddings available
        if query_embedding is None:
            v_weight = 0.0
            t_weight = 1.0
        else:
            v_weight = self.config.vector_weight
            t_weight = self.config.text_weight

        from qp_vault.protocols import ResourceFilter

        search_query = SearchQuery(
            query_embedding=query_embedding,
            query_text=query,
            top_k=top_k * 3,  # Over-fetch for trust re-ranking
            threshold=0.0,  # Apply threshold after trust weighting
            vector_weight=v_weight,
            text_weight=t_weight,
            filters=ResourceFilter(
                tenant_id=tenant_id,
                trust_tier=min_trust_tier.value if min_trust_tier is not None and hasattr(min_trust_tier, "value") else min_trust_tier,
                layer=layer.value if layer is not None and hasattr(layer, "value") else layer,
                collection_id=collection,
            ) if any([tenant_id, min_trust_tier, layer, collection]) else None,
            as_of=str(as_of) if as_of else None,
        )

        # Get raw results from storage (with timeout protection)
        raw_results = await self._tracked("search", self._with_timeout(self._storage.search(search_query)))

        # Apply trust weighting with optional layer boost
        weighted = apply_trust_weighting(raw_results, self.config, layer_boost=_layer_boost)

        # Apply threshold after trust weighting
        filtered = [r for r in weighted if r.relevance >= threshold]

        # Deduplicate by resource_id (keep best chunk per resource)
        if deduplicate:
            seen: dict[str, SearchResult] = {}
            for r in filtered:
                if r.resource_id not in seen or r.relevance > seen[r.resource_id].relevance:
                    seen[r.resource_id] = r
            filtered = sorted(seen.values(), key=lambda x: x.relevance, reverse=True)

        # Apply pagination
        paginated = filtered[offset : offset + top_k]

        # Add explain metadata if requested
        if explain:
            for r in paginated:
                r.explain_metadata = {
                    "explain": {
                        "vector_similarity": r.vector_similarity,
                        "text_rank": r.text_rank,
                        "trust_weight": r.trust_weight,
                        "freshness": r.freshness,
                        "layer_boost": _layer_boost,
                        "composite_relevance": r.relevance,
                    }
                }

        # SURVEIL: query-time re-evaluation
        from qp_vault.membrane.surveil import apply_surveil
        paginated = apply_surveil(paginated)

        await self._fire_hook("post_search", query=query, results=paginated)
        return paginated

    async def grep(
        self,
        keywords: list[str],
        *,
        tenant_id: str | None = None,
        top_k: int = 20,
        max_keywords: int = 20,
    ) -> list[SearchResult]:
        """Multi-keyword OR search with three-signal blended scoring.

        Single-pass FTS5 (SQLite) or ILIKE+trigram (Postgres) query,
        scored by keyword coverage (coord factor), native text rank,
        and term proximity. Trust-weighted and deduplicated.

        Scoring formula:
            base = rank_weight * text_rank + proximity_weight * proximity
            blended = coverage * base
            final = blended * trust_weight * adversarial * freshness

        Args:
            keywords: List of keyword strings to search for.
            tenant_id: Optional tenant scope.
            top_k: Maximum results to return.
            max_keywords: Maximum keywords allowed (default 20).

        Returns:
            List of SearchResult sorted by blended relevance.
        """
        await self._ensure_initialized()
        self._check_permission("search")
        tenant_id = self._resolve_tenant(tenant_id)

        if not keywords:
            return []

        from qp_vault.protocols import ResourceFilter
        from qp_vault.storage.grep_utils import (
            compute_proximity,
            generate_snippet,
            normalize_keywords,
        )

        clean_keywords = normalize_keywords(keywords, max_keywords)
        if not clean_keywords:
            return []

        # Single storage query (not N+1), with timeout protection
        filters = ResourceFilter(tenant_id=tenant_id) if tenant_id else None
        raw_matches = await self._tracked(
            "grep",
            self._with_timeout(
                self._storage.grep(clean_keywords, filters=filters, top_k=top_k * 3)
            ),
        )

        # Three-signal blended scoring
        rank_w = self.config.grep_rank_weight
        prox_w = self.config.grep_proximity_weight

        scored: list[SearchResult] = []
        for match in raw_matches:
            # Signal 1: coverage (Lucene coord factor, acts as multiplier)
            coverage = match.hit_density

            # Signal 2: native text rank (FTS5 bm25 or pg_trgm similarity)
            text_rank = match.text_rank

            # Signal 3: term proximity (cover density ranking)
            proximity = compute_proximity(match.content, match.matched_keywords)

            # Composite: coverage multiplies the weighted base score
            base = rank_w * text_rank + prox_w * proximity
            blended = coverage * base

            snippet = generate_snippet(match.content, match.matched_keywords)

            scored.append(SearchResult(
                chunk_id=match.chunk_id,
                resource_id=match.resource_id,
                resource_name=match.resource_name,
                content=match.content,
                page_number=match.page_number,
                section_title=match.section_title,
                text_rank=text_rank,
                trust_tier=TrustTier(match.trust_tier),
                cid=match.cid,
                lifecycle=match.lifecycle,
                updated_at=match.updated_at,
                resource_type=match.resource_type,
                data_classification=match.data_classification,
                relevance=blended,
                explain_metadata={
                    "matched_keywords": match.matched_keywords,
                    "hit_density": match.hit_density,
                    "text_rank": text_rank,
                    "proximity": proximity,
                    "snippet": snippet,
                },
            ))

        # Apply trust weighting (same as search)
        weighted = apply_trust_weighting(scored, self.config)

        # Deduplicate by resource_id (keep best chunk per resource)
        seen: dict[str, SearchResult] = {}
        for r in weighted:
            if r.resource_id not in seen or r.relevance > seen[r.resource_id].relevance:
                seen[r.resource_id] = r

        results = sorted(seen.values(), key=lambda r: r.relevance, reverse=True)
        final = results[:top_k]

        # SURVEIL: query-time adversarial re-evaluation (same as search)
        from qp_vault.membrane.surveil import apply_surveil
        final = apply_surveil(final)

        await self._fire_hook("post_grep", keywords=clean_keywords, results=final)
        return final

    async def search_with_facets(
        self,
        query: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Search with faceted results.

        Returns results plus facet counts by trust tier, resource type,
        and data classification.
        """
        results: list[SearchResult] = await self.search(query, **kwargs)

        facets: dict[str, dict[str, int]] = {
            "trust_tier": {},
            "resource_type": {},
            "data_classification": {},
        }
        for r in results:
            tier = r.trust_tier.value if hasattr(r.trust_tier, "value") else str(r.trust_tier)
            facets["trust_tier"][tier] = facets["trust_tier"].get(tier, 0) + 1
            if r.resource_type:
                facets["resource_type"][r.resource_type] = facets["resource_type"].get(r.resource_type, 0) + 1
            if r.data_classification:
                facets["data_classification"][r.data_classification] = facets["data_classification"].get(r.data_classification, 0) + 1

        return {
            "results": results,
            "total": len(results),
            "facets": facets,
        }

    # --- Verification ---

    async def verify(self, resource_id: str | None = None) -> VerificationResult | VaultVerificationResult:
        """Verify integrity of a resource or the entire vault.

        Args:
            resource_id: If provided, verify single resource. Otherwise verify all.

        Returns:
            VerificationResult for single resource, VaultVerificationResult for all.
        """
        await self._ensure_initialized()
        self._check_permission("verify")

        if resource_id:
            return await self._verify_resource(resource_id)
        return await self._verify_all()

    async def _verify_resource(self, resource_id: str) -> VerificationResult:
        """Verify a single resource's integrity."""
        from qp_vault.core.hasher import compute_cid, compute_resource_hash

        resource = await self.get(resource_id)
        chunks = await self._storage.get_chunks_for_resource(resource_id)

        # Recompute chunk CIDs
        failed_chunks = []
        chunk_cids = []
        for chunk in chunks:
            expected_cid = compute_cid(chunk.content)
            chunk_cids.append(expected_cid)
            if expected_cid != chunk.cid:
                failed_chunks.append(chunk.cid)

        # Recompute resource hash
        computed_hash = compute_resource_hash(chunk_cids) if chunk_cids else ""

        return VerificationResult(
            resource_id=resource_id,
            passed=computed_hash == resource.content_hash and not failed_chunks,
            stored_hash=resource.content_hash,
            computed_hash=computed_hash,
            chunk_count=len(chunks),
            failed_chunks=failed_chunks,
        )

    async def _verify_all(self) -> VaultVerificationResult:
        """Verify entire vault via Merkle tree."""
        import time

        start = time.monotonic()
        all_hashes = await self._storage.get_all_hashes()

        if not all_hashes:
            return VaultVerificationResult(
                passed=True,
                merkle_root="",
                resource_count=0,
                verified_count=0,
                duration_ms=0,
            )

        hashes = [h for _, h in all_hashes]
        merkle_root = compute_merkle_root(hashes)

        duration_ms = int((time.monotonic() - start) * 1000)

        return VaultVerificationResult(
            passed=True,  # Full per-resource verification would be separate
            merkle_root=merkle_root,
            resource_count=len(all_hashes),
            verified_count=len(all_hashes),
            duration_ms=duration_ms,
        )

    async def export_proof(self, resource_id: str) -> MerkleProof:
        """Export a Merkle proof for a specific resource.

        The proof allows an auditor to verify that a resource belongs
        to the vault's Merkle tree without downloading the entire vault.
        """
        await self._ensure_initialized()
        from qp_vault.core.hasher import compute_merkle_proof, compute_merkle_root
        from qp_vault.models import MerkleProof

        all_hashes = await self._storage.get_all_hashes()
        if not all_hashes:
            raise VaultError("Cannot export proof from empty vault")

        ids = [h[0] for h in all_hashes]
        hashes = [h[1] for h in all_hashes]

        if resource_id not in ids:
            raise VaultError(f"Resource {resource_id} not found in vault")

        leaf_index = ids.index(resource_id)
        root = compute_merkle_root(hashes)
        proof_path = compute_merkle_proof(hashes, leaf_index)

        return MerkleProof(
            resource_id=resource_id,
            resource_hash=hashes[leaf_index],
            merkle_root=root,
            path=proof_path,
            leaf_index=leaf_index,
            tree_size=len(hashes),
        )

    # --- Status ---

    # --- Memory Layers ---

    def layer(self, name: MemoryLayer | str) -> LayerView:
        """Get a scoped view of a memory layer.

        Example:
            ops = vault.layer(MemoryLayer.OPERATIONAL)
            ops.add("runbook.md")  # Auto-applies layer defaults
            ops.search("deploy")   # Scoped to operational layer
        """
        from qp_vault.core.layer_manager import LayerView
        layer_enum = MemoryLayer(name) if isinstance(name, str) else name
        return LayerView(layer_enum, self, self._layer_manager)

    # --- Collections ---

    async def create_collection(
        self,
        name: str,
        *,
        description: str = "",
        tenant_id: str | None = None,
    ) -> dict[str, Any]:
        """Create a new collection."""
        await self._ensure_initialized()
        self._check_permission("create_collection")
        tenant_id = self._resolve_tenant(tenant_id)
        import uuid
        from datetime import UTC, datetime
        collection_id = str(uuid.uuid4())
        now = datetime.now(tz=UTC).isoformat()
        await self._storage.store_collection(collection_id, name, description, now)
        return {"id": collection_id, "name": name, "description": description}

    async def list_collections(self, *, tenant_id: str | None = None) -> list[dict[str, Any]]:
        """List all collections."""
        await self._ensure_initialized()
        return await self._storage.list_collections()

    # --- Integrity ---

    async def health(self, resource_id: str | None = None) -> HealthScore:
        """Compute health score (0-100).

        Args:
            resource_id: If provided, compute health for a single resource.
                        If None, compute vault-wide health.

        Returns:
            HealthScore with component scores.
        """
        await self._ensure_initialized()
        self._check_permission("health")
        from qp_vault.integrity.detector import compute_health_score

        if resource_id:
            resource = await self.get(resource_id)
            return compute_health_score([resource])

        # Use cached result if available
        cache_key = "health:vault"
        cached: HealthScore | None = self._cache_get(cache_key)
        if cached is not None:
            return cached

        all_resources = await self._list_all_bounded()
        result = compute_health_score(all_resources)
        self._cache_set(cache_key, result)
        return result

    async def export_vault(self, path: str | Path) -> dict[str, Any]:
        """Export the vault to a JSON file for portability.

        Args:
            path: Output file path.

        Returns:
            Summary with resource count and export path.
        """
        import json as _json
        await self._ensure_initialized()
        self._check_permission("export_vault")
        resources: list[Resource] = await self._list_all_bounded()
        export_resources = []
        for r in resources:
            r_dict = r.model_dump(mode="json")
            # Include chunk content for lossless roundtrip
            chunks = await self._storage.get_chunks_for_resource(r.id)
            sorted_chunks = sorted(chunks, key=lambda c: c.chunk_index)
            r_dict["_chunks"] = [{"content": c.content, "cid": c.cid} for c in sorted_chunks]
            export_resources.append(r_dict)
        data = {
            "version": "1.1.0",
            "resource_count": len(resources),
            "resources": export_resources,
        }
        out = Path(path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(_json.dumps(data, default=str, indent=2))
        return {"path": str(out), "resource_count": len(resources)}

    async def import_vault(self, path: str | Path) -> list[Resource]:
        """Import resources from an exported vault JSON file.

        Args:
            path: Path to the exported JSON file.

        Returns:
            List of imported resources.
        """
        import json as _json
        await self._ensure_initialized()
        self._check_permission("import_vault")
        data = _json.loads(Path(path).read_text())
        imported = []
        for r_data in data.get("resources", []):
            # Reconstruct content from chunks (lossless) or fall back to name
            chunks_data = r_data.get("_chunks", [])
            if chunks_data:
                content = "\n\n".join(c["content"] for c in chunks_data)
            else:
                content = r_data.get("name", "imported")
            resource = await self.add(
                content,
                name=r_data.get("name", "imported"),
                trust_tier=r_data.get("trust_tier", "working"),
                classification=r_data.get("data_classification", "internal"),
                tags=r_data.get("tags", []),
                metadata=r_data.get("metadata", {}),
            )
            imported.append(resource)
        return imported

    async def _list_all_bounded(self, *, hard_cap: int = _LIST_HARD_CAP, batch_size: int = _LIST_BATCH_SIZE) -> list[Resource]:
        """Load all resources with pagination and a hard cap to prevent OOM."""
        all_resources: list[Resource] = []
        offset = 0
        while offset < hard_cap:
            batch = await self._resource_manager.list(limit=batch_size, offset=offset)
            if not batch:
                break
            all_resources.extend(batch)
            offset += batch_size
        return all_resources

    # --- Status ---

    async def status(self) -> dict[str, Any]:
        """Get vault status summary."""
        await self._ensure_initialized()
        self._check_permission("status")

        # Use cached result if available
        cache_key = "status:vault"
        cached_status: dict[str, Any] | None = self._cache_get(cache_key)
        if cached_status is not None:
            return cached_status

        all_resources: list[Resource] = await self._list_all_bounded()

        by_status: dict[str, int] = {}
        by_trust: dict[str, int] = {}
        by_layer: dict[str, int] = {}

        for r in all_resources:
            s = r.status.value if hasattr(r.status, "value") else r.status
            by_status[s] = by_status.get(s, 0) + 1
            t = r.trust_tier.value if hasattr(r.trust_tier, "value") else r.trust_tier
            by_trust[t] = by_trust.get(t, 0) + 1
            if r.layer:
                lyr = r.layer.value if hasattr(r.layer, "value") else r.layer
                by_layer[lyr] = by_layer.get(lyr, 0) + 1

        layer_stats = self._layer_manager.get_stats(all_resources)

        result = {
            "total_resources": len(all_resources),
            "by_status": by_status,
            "by_trust_tier": by_trust,
            "by_layer": by_layer,
            "layer_details": layer_stats,
            "vault_path": str(self.path),
            "backend": "sqlite",
            "telemetry": self._telemetry.summary(),
        }
        self._cache_set(cache_key, result)
        return result

    # --- Plugin Registration ---

    def register_embedder(self, embedder: EmbeddingProvider) -> None:
        """Register a custom embedding provider."""
        self._embedder = embedder
        self._resource_manager._embedder = embedder

    def register_parser(self, parser: ParserProvider) -> None:
        """Register a custom file parser."""
        self._parsers.append(parser)

    def register_policy(self, policy: PolicyProvider) -> None:
        """Register a governance policy."""
        self._policies.append(policy)

    async def start_expiration_monitor(self, interval_seconds: int = 3600) -> None:
        """Start a background task to auto-expire resources.

        Checks for expired resources (past valid_until) and transitions
        them to ARCHIVED. Runs every interval_seconds (default: 1 hour).

        Call this once after initialization for long-running services.
        """
        async def _monitor() -> None:
            while True:
                await asyncio.sleep(interval_seconds)
                import contextlib
                with contextlib.suppress(Exception):
                    await self._lifecycle.check_expirations()

        self._expiration_task = asyncio.create_task(_monitor())


def _run_async(coro: Any) -> Any:
    """Run an async coroutine synchronously.

    Note: Returns Any because Coroutine[Any, Any, T] is not easily
    parameterized at the call site. Callers use typed local variables
    to maintain type safety.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        # We're inside an existing event loop; create a new thread
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor() as pool:
            return pool.submit(asyncio.run, coro).result()
    else:
        return asyncio.run(coro)


class Vault:
    """Governed knowledge store (sync interface).

    Wraps AsyncVault with synchronous methods.
    All parameters are identical to AsyncVault.
    """

    def __init__(
        self,
        path: str | Path,
        *,
        storage: StorageBackend | None = None,
        embedder: EmbeddingProvider | None = None,
        auditor: AuditProvider | None = None,
        parsers: list[ParserProvider] | None = None,
        policies: list[PolicyProvider] | None = None,
        config: VaultConfig | None = None,
        plugins_dir: str | Path | None = None,
        tenant_id: str | None = None,
        role: str | None = None,
        llm_screener: LLMScreener | None = None,
    ) -> None:
        """Create a synchronous Vault instance.

        Args:
            path: Directory path for vault storage.
            storage: Custom storage backend (default: SQLite).
            embedder: Custom embedding provider.
            auditor: Custom audit provider (default: auto-detect Capsule or JSON log).
            parsers: Custom file parsers.
            policies: Governance policy providers.
            config: Vault configuration overrides.
            plugins_dir: Directory for local plugin discovery (air-gap mode).
            tenant_id: Lock vault to a single tenant (enforced on all operations).
            role: RBAC role ("reader", "writer", "admin", or None for no enforcement).
            llm_screener: LLM screener for Membrane ADAPTIVE_SCAN (optional).
        """
        self._async = AsyncVault(
            path,
            storage=storage,
            embedder=embedder,
            auditor=auditor,
            parsers=parsers,
            policies=policies,
            config=config,
            plugins_dir=plugins_dir,
            tenant_id=tenant_id,
            role=role,
            llm_screener=llm_screener,
        )

    def add(self, source: str | Path | bytes, **kwargs: Any) -> Resource:
        """Add a resource to the vault."""
        return cast("Resource", _run_async(self._async.add(source, **kwargs)))

    def add_batch(self, sources: list[str | Path | bytes], **kwargs: Any) -> list[Resource]:
        """Add multiple resources in a batch."""
        result: list[Resource] = _run_async(self._async.add_batch(sources, **kwargs))
        return result

    def get(self, resource_id: str) -> Resource:
        """Get a resource by ID."""
        return cast("Resource", _run_async(self._async.get(resource_id)))

    def get_multiple(self, resource_ids: list[str]) -> list[Resource]:
        """Get multiple resources by ID in a single query."""
        return cast("list[Resource]", _run_async(self._async.get_multiple(resource_ids)))

    def list(self, **kwargs: Any) -> list[Resource]:
        """List resources with optional filters."""
        return cast("list[Resource]", _run_async(self._async.list(**kwargs)))

    def update(self, resource_id: str, **kwargs: Any) -> Resource:
        """Update resource metadata."""
        return cast("Resource", _run_async(self._async.update(resource_id, **kwargs)))

    def delete(self, resource_id: str, *, hard: bool = False) -> None:
        """Delete a resource."""
        _run_async(self._async.delete(resource_id, hard=hard))

    def get_content(self, resource_id: str) -> str:
        """Retrieve the full text content of a resource."""
        result: str = _run_async(self._async.get_content(resource_id))
        return result

    def replace(self, resource_id: str, new_content: str, *, reason: str | None = None) -> tuple[Resource, Resource]:
        """Replace a resource's content atomically. Returns (old, new)."""
        result: tuple[Resource, Resource] = _run_async(self._async.replace(resource_id, new_content, reason=reason))
        return result

    def upsert(self, source: str | Path | bytes, **kwargs: Any) -> Resource:
        """Add or replace a resource atomically."""
        return cast("Resource", _run_async(self._async.upsert(source, **kwargs)))

    def get_provenance(self, resource_id: str) -> list[dict[str, Any]]:
        """Get provenance records for a resource."""
        result: list[dict[str, Any]] = _run_async(self._async.get_provenance(resource_id))
        return result

    def set_adversarial_status(self, resource_id: str, status: str) -> Resource:
        """Set adversarial verification status."""
        result: Resource = _run_async(self._async.set_adversarial_status(resource_id, status))
        return result

    def transition(self, resource_id: str, target: Lifecycle | str, *, reason: str | None = None) -> Resource:
        """Transition lifecycle state."""
        return cast("Resource", _run_async(self._async.transition(resource_id, target, reason=reason)))

    def supersede(self, old_id: str, new_id: str) -> tuple[Resource, Resource]:
        """Supersede a resource with a newer version."""
        return cast("tuple[Resource, Resource]", _run_async(self._async.supersede(old_id, new_id)))

    def expiring(self, *, days: int = 90) -> list[Resource]:
        """Find resources expiring within N days."""
        return cast("list[Resource]", _run_async(self._async.expiring(days=days)))

    def chain(self, resource_id: str) -> list[Resource]:
        """Get supersession chain."""
        return cast("list[Resource]", _run_async(self._async.chain(resource_id)))

    def diff(self, old_id: str, new_id: str) -> dict[str, Any]:
        """Compare two resource versions."""
        result: dict[str, Any] = _run_async(self._async.diff(old_id, new_id))
        return result

    def export_proof(self, resource_id: str) -> MerkleProof:
        """Export Merkle proof for auditors."""
        result: MerkleProof = _run_async(self._async.export_proof(resource_id))
        return result

    def search(self, query: str, **kwargs: Any) -> list[SearchResult]:
        """Trust-weighted hybrid search."""
        result: list[SearchResult] = _run_async(self._async.search(query, **kwargs))
        return result

    def verify(self, resource_id: str | None = None) -> VerificationResult | VaultVerificationResult:
        """Verify integrity."""
        result: VerificationResult | VaultVerificationResult = _run_async(self._async.verify(resource_id))
        return result

    def layer(self, name: MemoryLayer | str) -> LayerView:
        """Get a scoped view of a memory layer."""
        return self._async.layer(name)

    def create_collection(self, name: str, **kwargs: Any) -> dict[str, Any]:
        """Create a new collection."""
        result: dict[str, Any] = _run_async(self._async.create_collection(name, **kwargs))
        return result

    def list_collections(self, **kwargs: Any) -> list[dict[str, Any]]:
        """List all collections."""
        result: list[dict[str, Any]] = _run_async(self._async.list_collections(**kwargs))
        return result

    def health(self, resource_id: str | None = None) -> HealthScore:
        """Compute vault or per-resource health score."""
        result: HealthScore = _run_async(self._async.health(resource_id))
        return result

    def status(self) -> dict[str, Any]:
        """Get vault status."""
        result: dict[str, Any] = _run_async(self._async.status())
        return result

    def export_vault(self, path: str | Path) -> dict[str, Any]:
        """Export the vault to a JSON file."""
        result: dict[str, Any] = _run_async(self._async.export_vault(path))
        return result

    def import_vault(self, path: str | Path) -> list[Resource]:
        """Import resources from an exported vault JSON file."""
        return cast("list[Resource]", _run_async(self._async.import_vault(path)))

    def register_embedder(self, embedder: EmbeddingProvider) -> None:
        """Register a custom embedding provider."""
        self._async.register_embedder(embedder)

    def register_parser(self, parser: ParserProvider) -> None:
        """Register a custom file parser."""
        self._async.register_parser(parser)

    def register_policy(self, policy: PolicyProvider) -> None:
        """Register a governance policy."""
        self._async.register_policy(policy)

    @classmethod
    def from_config(cls, config_path: str | Path) -> Vault:
        """Create a Vault from a TOML configuration file."""
        config = VaultConfig.from_toml(config_path)
        return cls(path=".", config=config)

    @classmethod
    def from_postgres(cls, dsn: str, **kwargs: Any) -> Vault:
        """Create a Vault with PostgreSQL backend."""
        config = VaultConfig(backend="postgres", postgres_dsn=dsn)
        return cls(path=".", config=config, **kwargs)
