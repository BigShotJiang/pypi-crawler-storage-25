# Made by a Solo Developer - ???
import asyncio 
import time
from telegram import Bot 
from telegram import InlineKeyboardButton as kb, InlineKeyboardMarkup as km


async def message(message, id, token):
    bot = Bot(token=token)
    async with bot:
        await bot.send_message(chat_id=id, text=message,  protect_content=True, disable_notification=True )
 
async def button_message(message, id, token,button1_cmd, button1_text, button2_cmd, button2_text, button3_url_text, button3_url, button_pos ):
    bot = Bot(token=token)
    b1 = kb(button1_text, callback_data=button1_cmd)
    b2 = kb(button2_text, callback_data=button2_cmd)
    b3 = kb(button3_url_text, url=button3_url)
    keyboard_y = km([
        [b1],
        [b2],
        [b3]
    ])
    buttons_1 = [b1,b2, b3]
    keyboard_x = km(
        [buttons_1]
    )
    if button_pos.lower() in ["y", "vertical"]:
        async with bot:
            await bot.send_message(
                chat_id=id,
                text=message,
                reply_markup=keyboard_y
            )
    elif button_pos == "x" or "X" or "Horizontal" or "horizontal":
        async with bot:
            await bot.send_message(
                chat_id=id,
                text=message,
                reply_markup=keyboard_x
            )
    else: 
        print("Error - 'button_pos' variable incorrect input")
        time(5)
        exit()


 