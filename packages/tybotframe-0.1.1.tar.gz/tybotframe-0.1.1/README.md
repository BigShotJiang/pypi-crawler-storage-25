# How To install 

### Step 1:
```pip install tybotframe```

# How to Import and use 

### Step 1:
import tybotframe module
```from tybotframe import message, button_message```

### Step 2: 
import asyncio module
```import asyncio```

# Fuctions

### Basic Messaging

```async.run(message())```

### Button and command messaging

```async.run(button_message())```

# REQUIRMENTS

### updated python
### Your Group ID
### Your @BotFather API 
### Message Content 