"""
PredaCore Subsystem Factory — Single source of truth for initializing all subsystems.

ToolExecutor and other consumers need the same subsystems
(desktop, memory, MCTS, voice, OpenClaw, LLM). This factory creates them
once, consistently, eliminating the duplicate init code.

Usage:
    from .subsystem_init import SubsystemFactory, SubsystemBundle
    bundle = SubsystemFactory.create_all(config)
    # bundle.desktop_operator, bundle.unified_memory, etc.
"""
from __future__ import annotations

import copy
import logging
import os
import sqlite3
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

# CLI-based providers that can't be used recursively from within sub-agents
# (nested CLI processes deadlock waiting for stdin).
_CLI_PROVIDERS = {"gemini-cli"}


@dataclass
class SubsystemBundle:
    """Container for all initialized subsystems.

    Every field starts as None and gets populated by SubsystemFactory.
    Subsystems that fail to initialize remain None — callers should
    handle gracefully.
    """
    db_adapter: Any = None
    desktop_operator: Any = None
    unified_memory: Any = None
    memory_healer: Any = None  # Background self-healing daemon (audit/sweep/snapshot/integrity)
    memory_service: Any = None
    mcts_planner: Any = None
    llm_for_collab: Any = None
    voice: Any = None
    openclaw_runtime: Any = None
    openclaw_enabled: bool = False
    sandbox: Any = None
    docker_sandbox: Any = None
    sandbox_pool: Any = None
    # Identity-wiring (PR1): pre-hoc safety + autonomous skill evolution.
    # critic_gate fires before high-stakes tool dispatch (W2).
    # skill_crystallizer observes the dispatcher's execution stream and
    # crystallizes recurring patterns into Flame skill genomes (W1).
    critic_gate: Any = None
    skill_crystallizer: Any = None
    # Track what's available for logging
    available: list[str] = field(default_factory=list)


class _LazyMCTSPlanner:
    """Defers MCTS planner import+construction until first attribute access.

    Importing `predacore._vendor.core_strategic_engine.planner_mcts` pulls
    spaCy → thinc → PyTorch (~2GB) into the process — too expensive to do
    eagerly at boot. This proxy keeps `bundle.mcts_planner` truthy so
    `available` reporting and feature gates work, but the heavy import only
    happens on the first real call (e.g. when the `strategic_plan` tool runs).
    """

    __slots__ = ("_real",)

    def __init__(self) -> None:
        self._real: Any = None

    def _resolve(self) -> Any:
        if self._real is None:
            from predacore._vendor.core_strategic_engine.planner_mcts import (
                ABMCTSPlanner,
            )
            self._real = ABMCTSPlanner(kn_stub=None, egm_stub=None)
            logger.info("MCTS strategic planner loaded on first use")
        return self._real

    def __getattr__(self, name: str) -> Any:
        # Called only for attributes not in __slots__ — i.e. real planner API.
        return getattr(self._resolve(), name)

    def __bool__(self) -> bool:  # truthy without forcing import
        return True


class SubsystemFactory:
    """Single place to initialize all PredaCore subsystems from config.

    Each init method is independent — failures are logged but don't
    block other subsystems from initializing.
    """

    @classmethod
    def create_all(
        cls,
        config: Any,
        *,
        skip_cli_providers: bool = False,
        home_dir: str | None = None,
    ) -> SubsystemBundle:
        """Initialize all subsystems and return a bundle.

        Args:
            config: PredaCoreConfig instance.
            skip_cli_providers: If True, exclude CLI-based LLM providers
                (currently just gemini-cli) from the collaboration LLM chain.
                Set to True when running inside a sub-agent context where a
                nested CLI process would deadlock on stdin.
            home_dir: Override home directory (defaults to config.home_dir or ~/.predacore).
        """
        bundle = SubsystemBundle()
        _home = home_dir or getattr(config, "home_dir", os.path.expanduser("~/.predacore"))

        # DB adapter first — stores use it if available
        cls._init_db_adapter(bundle, config, _home)

        # Order doesn't matter — each is independent
        cls._init_desktop(bundle, config)
        cls._init_unified_memory(bundle, config, _home)
        cls._init_mcts(bundle)
        cls._init_voice(bundle)
        cls._init_llm_collab(bundle, config, skip_cli_providers)
        cls._init_openclaw(bundle, config)
        cls._init_sandbox(bundle, config)
        # PR1 (W2 + W1): pre-hoc safety + autonomous skill evolution.
        # Both depend on llm_for_collab (critic) or are llm-free (crystallizer),
        # so they run AFTER _init_llm_collab.
        cls._init_critic_and_crystallizer(bundle, _home)

        logger.info(
            "SubsystemFactory: initialized [%s] (%d/%d)",
            ", ".join(bundle.available),
            len(bundle.available),
            10,
        )
        return bundle

    @staticmethod
    def _init_critic_and_crystallizer(bundle: SubsystemBundle, home_dir: str) -> None:
        """PR1: wire pre-hoc CriticGate + SkillCrystallizer.

        CriticGate (W2): a separate LLM judges high-stakes tool calls BEFORE
        execution. Refuses or revises actions that would violate SOUL_SEED
        invariants — programmatic enforcement, not prompt-level request.

        SkillCrystallizer (W1): observes the dispatcher's execution stream;
        crystallizes recurring patterns (≥3 occurrences across distinct
        contexts, ≥80% success rate) into HMAC-signed Flame skill genomes
        that can be shared across instances. The autonomous-evolution
        machinery already exists; this wires it into the live loop.
        """
        # CriticGate — needs an LLM to judge, so skip if collab LLM didn't init.
        if bundle.llm_for_collab is not None:
            try:
                try:
                    from predacore.agents.critic import CriticGate
                except ImportError:
                    from src.predacore.agents.critic import CriticGate  # type: ignore
                bundle.critic_gate = CriticGate(llm=bundle.llm_for_collab)
                bundle.available.append("critic_gate")
                logger.info("CriticGate active (pre-hoc safety on high-stakes tools)")
            except (ImportError, RuntimeError) as exc:
                logger.warning("CriticGate init failed: %s", exc)
        else:
            logger.info("CriticGate skipped (no llm_for_collab)")

        # SkillCrystallizer — no LLM dependency; always wire if vendor available.
        try:
            try:
                from predacore._vendor.common.skill_evolution import SkillCrystallizer
            except ImportError:
                from src.predacore._vendor.common.skill_evolution import (  # type: ignore
                    SkillCrystallizer,
                )
            bundle.skill_crystallizer = SkillCrystallizer(
                user=os.environ.get("PREDACORE_MEMORY_USER")
                or os.environ.get("USER")
                or "default",
                data_dir=Path(home_dir) / "skills" / "evolved",
            )
            bundle.available.append("skill_crystallizer")
            logger.info("SkillCrystallizer active (auto-observing tool patterns)")
        except (ImportError, OSError, RuntimeError) as exc:
            logger.warning("SkillCrystallizer init failed: %s", exc)

    # ── Individual Initializers ──────────────────────────────────

    @staticmethod
    def _init_db_adapter(bundle: SubsystemBundle, config: Any, home_dir: str) -> None:
        """DB adapter placeholder — disabled for now.

        SQLite in-process (WAL + 5s busy_timeout) is sufficient for current
        workloads. The socket server infrastructure (db_server.py, db_client.py,
        db_adapter.py) is available if future daemon architectures need it.
        """
        return

    @staticmethod
    def _init_desktop(bundle: SubsystemBundle, config: Any) -> None:
        desktop_enabled = str(
            os.getenv("PREDACORE_ENABLE_DESKTOP_CONTROL", "1")
        ).strip().lower() not in {"0", "false", "no", "off"}
        if not desktop_enabled:
            return

        try:
            try:
                from predacore.operators.desktop import MacDesktopOperator
            except ImportError:
                from src.predacore.operators.desktop import (
                    MacDesktopOperator,  # type: ignore
                )

            ops_cfg = getattr(config, "operators", None)
            op = MacDesktopOperator(log=logger, operators_config=ops_cfg)
            if op.available:
                bundle.desktop_operator = op
                bundle.available.append("desktop")
                logger.info("Desktop operator active")
            else:
                logger.info("Desktop operator initialized (inactive on non-macOS)")
        except (ImportError, OSError, RuntimeError) as exc:
            logger.warning("Desktop control initialization failed: %s", exc)

    @staticmethod
    def _init_unified_memory(bundle: SubsystemBundle, config: Any, home_dir: str) -> None:
        try:
            try:
                from predacore.memory import UnifiedMemoryStore
            except ImportError:
                from src.predacore.memory import UnifiedMemoryStore  # type: ignore

            try:
                from predacore.services.embedding import get_default_embedding_client
            except ImportError:
                from src.predacore.services.embedding import (
                    get_default_embedding_client,  # type: ignore
                )

            um_db = str(Path(home_dir) / "memory" / "unified_memory.db")
            bundle.unified_memory = UnifiedMemoryStore(
                db_path=um_db,
                embedding_client=get_default_embedding_client(),
                db_adapter=bundle.db_adapter,
            )
            bundle.available.append("memory")
            logger.info("Unified memory enabled (db=%s)", um_db)

            # D14 — eagerly warm the BGE embedder so the first recall
            # doesn't pay the 1–2s cold-start latency. bootstrap.py:
            # _check_bge_model already does this, but bootstrap only
            # runs once per install (gated by a marker file); every
            # subsequent process start benefits from this re-warmup.
            # Sync call into predacore_core (NOT the async
            # store.warmup_embedder) because _init_unified_memory runs
            # in sync context. Skip when already loaded — cheap.
            memory_cfg = getattr(config, "memory", None)
            if memory_cfg is not None and getattr(memory_cfg, "eager_warmup", True):
                try:
                    import predacore_core as _pc
                    if not _pc.is_model_loaded():
                        import time as _time
                        _t0 = _time.time()
                        _pc.embed(["warmup"])
                        logger.info(
                            "BGE embedder warmed (%.2fs)",
                            _time.time() - _t0,
                        )
                except (ImportError, AttributeError, RuntimeError) as _warm_exc:
                    logger.debug("BGE warmup skipped: %s", _warm_exc)

            # Start the self-healing daemon (gated on memory.enable_healer).
            # Mirrors the lab mcp_server.py:McpServerState behavior — same
            # Healer class, background thread, lifecycle owned by the bundle.
            # Caller is responsible for `bundle.memory_healer.stop()` at
            # daemon shutdown.
            if memory_cfg is not None and getattr(memory_cfg, "enable_healer", True):
                try:
                    try:
                        from predacore.memory import Healer
                    except ImportError:
                        from src.predacore.memory import Healer  # type: ignore
                    healer_user = (
                        os.environ.get("PREDACORE_MEMORY_USER")
                        or os.environ.get("USER")
                        or "default"
                    )
                    bundle.memory_healer = Healer(bundle.unified_memory, user=healer_user)
                    bundle.memory_healer.start()
                    bundle.available.append("memory_healer")
                    # M2 (Wave 7): register an atexit hook so the healer's
                    # background thread is joined on process exit even when
                    # no caller wires `bundle.memory_healer.stop()` into a
                    # graceful shutdown path. Belt-and-suspenders — gateway
                    # cleanup should still call stop() explicitly when it
                    # owns the bundle, but pytest runs and ad-hoc scripts
                    # that drop the bundle on the floor get clean exit too.
                    import atexit
                    _healer_ref = bundle.memory_healer
                    def _stop_healer_on_exit() -> None:
                        try:
                            if _healer_ref is not None:
                                _healer_ref.stop()
                        except Exception:  # pragma: no cover — best-effort
                            pass
                    atexit.register(_stop_healer_on_exit)
                    logger.info("Memory healer enabled (user=%s)", healer_user)
                except (ImportError, OSError, RuntimeError) as heal_exc:
                    logger.warning(
                        "Memory healer init failed (non-fatal — store still works): %s",
                        heal_exc,
                    )
        except (ImportError, OSError, ValueError, RuntimeError, sqlite3.OperationalError) as exc:
            if "database is locked" in str(exc).lower():
                logger.info("Unified memory busy (db lock) — will use session memory only.")
            else:
                logger.warning("Unified memory init failed (non-fatal): %s", exc)

    @staticmethod
    def _init_mcts(bundle: SubsystemBundle) -> None:
        # MCTS strategic planner is enabled by default but **lazy-loaded**: the
        # actual import + instantiation only happens on first call to the
        # `strategic_plan` tool. The planner transitively pulls
        # spaCy → thinc → PyTorch (~2GB) via _vendor/core_strategic_engine/
        # planner.py's top-level `import spacy`, so eager init would cost ~10s
        # on every process start (and break test collection).
        #
        # Opt out entirely with PREDACORE_DISABLE_MCTS_PLANNER=1 (smaller
        # install, planner unavailable).
        disabled = str(
            os.getenv("PREDACORE_DISABLE_MCTS_PLANNER", "")
        ).strip().lower() in {"1", "true", "yes", "on"}
        if disabled:
            logger.info(
                "MCTS planner disabled (PREDACORE_DISABLE_MCTS_PLANNER set). "
                "The strategic_plan tool will error until re-enabled."
            )
            return

        bundle.mcts_planner = _LazyMCTSPlanner()
        bundle.available.append("mcts_planner")
        logger.info("MCTS strategic planner registered (lazy-load on first use)")

    @staticmethod
    def _init_voice(bundle: SubsystemBundle) -> None:
        try:
            try:
                from predacore.services.voice import VoiceInterface
            except ImportError:
                from src.predacore.services.voice import VoiceInterface  # type: ignore

            bundle.voice = VoiceInterface()
            bundle.available.append("voice")
            logger.info("Voice interface enabled (TTS/STT)")
        except (ImportError, OSError, RuntimeError) as exc:
            logger.debug("Voice interface unavailable: %s", exc)

    @staticmethod
    def _init_llm_collab(
        bundle: SubsystemBundle, config: Any, skip_cli: bool
    ) -> None:
        try:
            try:
                from predacore.llm_providers.router import LLMInterface
            except ImportError:
                from src.predacore.llm_providers.router import (
                    LLMInterface,  # type: ignore
                )

            collab_config = copy.deepcopy(config)
            agent_llm = getattr(config, "agent_llm", None)
            if getattr(agent_llm, "provider", "").strip():
                collab_config.llm = copy.deepcopy(agent_llm)

            if skip_cli:
                # Build a config that skips CLI-based providers to avoid recursion
                all_providers = [collab_config.llm.provider] + list(
                    collab_config.llm.fallback_providers or []
                )
                direct_providers = [
                    p for p in all_providers if p and p not in _CLI_PROVIDERS
                ]

                if direct_providers:
                    collab_config.llm.provider = direct_providers[0]
                    collab_config.llm.fallback_providers = direct_providers[1:]
                    if collab_config.llm.provider != all_providers[0]:
                        collab_config.llm.model = ""
                else:
                    # Try common fallbacks with available API keys
                    for fallback in ["sambanova", "groq", "openai", "anthropic"]:
                        key_map = {
                            "sambanova": "SAMBANOVA_API_KEY",
                            "groq": "GROQ_API_KEY",
                            "openai": "OPENAI_API_KEY",
                            "anthropic": "ANTHROPIC_API_KEY",
                        }
                        if os.environ.get(key_map.get(fallback, "")):
                            collab_config.llm.provider = fallback
                            collab_config.llm.fallback_providers = []
                            collab_config.llm.model = ""
                            break
                    else:
                        logger.warning(
                            "No direct-API providers available for collaboration"
                        )
                        return

                bundle.llm_for_collab = LLMInterface(collab_config)
            else:
                bundle.llm_for_collab = LLMInterface(collab_config)

            bundle.available.append("multi_agent")
            logger.info(
                "LLM for collaboration enabled (provider=%s)",
                collab_config.llm.provider,
            )
        except (ImportError, OSError, ValueError, RuntimeError, AttributeError) as exc:
            logger.warning("LLM for collaboration init failed (non-fatal): %s", exc)

    @staticmethod
    def _init_openclaw(bundle: SubsystemBundle, config: Any) -> None:
        openclaw_enabled = os.environ.get("PREDACORE_ENABLE_OPENCLAW_BRIDGE", "0") == "1" or bool(
            getattr(getattr(config, "launch", None), "enable_openclaw_bridge", False)
        )
        bundle.openclaw_enabled = openclaw_enabled
        if not openclaw_enabled:
            return

        try:
            try:
                from predacore.agents.autonomy import OpenClawBridgeRuntime
            except ImportError:
                from src.predacore.agents.autonomy import (
                    OpenClawBridgeRuntime,  # type: ignore
                )

            bundle.openclaw_runtime = OpenClawBridgeRuntime(config)
            bundle.available.append("openclaw")
            logger.info("OpenClaw bridge runtime enabled")
        except (ImportError, OSError, RuntimeError, AttributeError, sqlite3.OperationalError) as exc:
            logger.warning("OpenClaw bridge init failed (non-fatal): %s", exc)

    @staticmethod
    def _init_sandbox(bundle: SubsystemBundle, config: Any) -> None:
        try:
            try:
                from predacore.auth.sandbox import (
                    DockerSandboxManager,
                    SubprocessSandboxManager,
                )
            except ImportError:
                from src.predacore.auth.sandbox import (  # type: ignore
                    DockerSandboxManager,
                    SubprocessSandboxManager,
                )

            bundle.sandbox = SubprocessSandboxManager(logger=logger)
            if getattr(config.security, "docker_sandbox", False):
                try:
                    bundle.docker_sandbox = DockerSandboxManager(logger=logger)
                    logger.info("Docker sandbox enabled")
                except (OSError, ConnectionError, RuntimeError) as e:
                    logger.warning("Docker sandbox unavailable (%s) — using subprocess", e)
            bundle.available.append("sandbox")
        except ImportError:
            logger.warning("Sandbox module not available — raw subprocess fallback")

        # Sandbox pool
        try:
            from predacore.auth.sandbox import SessionSandboxPool
            bundle.sandbox_pool = SessionSandboxPool(max_sessions=50)
        except (ImportError, OSError, RuntimeError, sqlite3.OperationalError):
            pass
