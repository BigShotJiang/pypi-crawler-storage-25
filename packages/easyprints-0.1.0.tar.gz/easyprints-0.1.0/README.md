# easyprints

tons of good prints

## Installation

```bash
pip install easyprints
```

## Usage

```python
# Add usage examples here
```

## License

MIT
