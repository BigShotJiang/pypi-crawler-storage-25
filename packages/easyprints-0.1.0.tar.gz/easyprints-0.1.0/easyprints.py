global debug
debug = False

def warn(msg):
    msg = msg.title()
    print("WARNING: ", msg)
def error(msg):
    msg = msg.upper()
    print("ERROR: ", msg)
def close_error(msg, silent=False):
    error(msg)
    if not silent:
        print("NOW CLOSING PROJECT")
    exit()
def set_debug(toggle):
    global debug
    if toggle == True:
        debug = True
    else:
        debug = False
def debug_print(msg):
    if debug == True:
        print(msg)