from setuptools import setup, find_packages

setup(
    name="easyprints",
    version="0.1.0",
    description="tons of good prints",
    author="lampshade_laj",
    py_modules=["easyprints"],
    install_requires=[],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)
