"""
Mnesis — Lossless Context Management for LLM agentic tasks.

Primary entry point::

    from mnesis import MnesisSession, MnesisConfig

    async with MnesisSession.open(model="anthropic/claude-opus-4-6") as session:
        result = await session.send("Hello!")
        print(result.text)
"""

from importlib.metadata import version as _version

from mnesis.events.bus import EventBus, MnesisEvent
from mnesis.models import (
    CompactionConfig,
    CompactionResult,
    ContextBreakdown,
    FileConfig,
    FileRefPart,
    FinishReason,
    MessagePart,
    MessageWithParts,
    MnesisConfig,
    OperatorConfig,
    RecordResult,
    SessionConfig,
    StoreConfig,
    TextDelta,
    TextPart,
    TokenUsage,
    ToolPart,
    TurnComplete,
    TurnResult,
    TurnSnapshot,
)
from mnesis.operators.agentic_map import AgenticMap, AgentMapBatch, AgentMapResult
from mnesis.operators.llm_map import LLMMap, MapBatch, MapResult
from mnesis.session import MnesisSession
from mnesis.store.immutable import MnesisStoreError, SessionNotFoundError
from mnesis.tokens.estimator import TokenEstimator

__version__ = _version("mnesis")

__all__ = [
    "AgentMapBatch",
    "AgentMapResult",
    "AgenticMap",
    "CompactionConfig",
    "CompactionResult",
    "ContextBreakdown",
    "EventBus",
    "FileConfig",
    "FileRefPart",
    "FinishReason",
    "LLMMap",
    "MapBatch",
    "MapResult",
    "MessagePart",
    "MessageWithParts",
    "MnesisConfig",
    "MnesisEvent",
    "MnesisSession",
    "MnesisStoreError",
    "OperatorConfig",
    "RecordResult",
    "SessionConfig",
    "SessionNotFoundError",
    "StoreConfig",
    "TextDelta",
    "TextPart",
    "TokenEstimator",
    "TokenUsage",
    "ToolPart",
    "TurnComplete",
    "TurnResult",
    "TurnSnapshot",
]
