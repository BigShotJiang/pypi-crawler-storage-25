from mlfoldergen.cli import main

if __name__ == "__main__":
    main()
