"""mlfoldergen: MLOps scaffold generator CLI."""

__version__ = "0.1.1"
