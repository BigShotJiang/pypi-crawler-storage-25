# mlops-project

A CLI tool that scaffolds a production-ready MLOps project structure in seconds.

## Installation

```bash
pip install mlops-project
```

## Usage

```bash
# Scaffold in the current directory
mlops-project init

# Scaffold into a specific directory
mlops-project init my-new-project
```

## Generated Structure

```
├── artifacts/
│   ├── data_ingestion/
│   ├── data_transformation/
│   ├── data_validation/
│   ├── model_evaluation/
│   └── model_trainer/
├── config/
│   └── config.yaml
├── logs/
│   └── logging.log
├── research/
│   ├── 01_data_ingestion.ipynb
│   ├── 02_data_validation.ipynb
│   ├── 03_data_transformation.ipynb
│   ├── 04_model_trainer.ipynb
│   └── 05_model_evaluation.ipynb
├── src/
│   ├── __init__.py
│   ├── components/
│   │   ├── __init__.py
│   │   ├── data_ingestion.py
│   │   ├── data_transformation.py
│   │   ├── data_validation.py
│   │   ├── model_evaluation.py
│   │   └── model_trainer.py
│   ├── config/
│   │   ├── __init__.py
│   │   └── configuration.py
│   ├── constants/
│   │   └── __init__.py
│   ├── entity/
│   │   ├── __init__.py
│   │   └── config_entity.py
│   ├── pipeline/
│   │   ├── __init__.py
│   │   ├── data_ingestion_pipeline.py
│   │   ├── data_validation_pipeline.py
│   │   ├── data_transformation_pipeline.py
│   │   ├── model_trainer_pipeline.py
│   │   ├── model_evaluation_pipeline.py
│   │   └── prediction_pipeline.py
│   └── utils/
│       ├── __init__.py
│       └── common.py
├── app.py
├── main.py
├── setup.py
├── Dockerfile
├── params.yaml
├── schema.yaml
├── requirements.txt
├── README.md
└── .gitignore
```

## License

MIT
