class LanguageModel:
    pass
