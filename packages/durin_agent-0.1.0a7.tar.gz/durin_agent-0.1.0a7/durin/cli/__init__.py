"""CLI module for durin."""
