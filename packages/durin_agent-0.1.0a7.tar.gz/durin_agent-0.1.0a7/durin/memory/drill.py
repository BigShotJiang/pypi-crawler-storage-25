"""Resolve a markdown URI (``path.md#anchor``) to the addressed section.

Used by the ``memory_drill`` tool to fetch a single turn from a session,
a single section from an ingested document, or a whole memory entry —
the same URI scheme that appears in :class:`MemoryEntry.source_refs`.

A section is everything from a header line ``## <anchor>`` up to (but
excluding) the next header at the same or higher level. ``memory_drill``
is read-only and free of any LLM call; it's just a structured ``Read``.
"""

from __future__ import annotations

import re
from pathlib import Path

__all__ = ["DrillError", "drill", "extract_section"]


class DrillError(ValueError):
    """Raised when a drill URI cannot be resolved."""


_HEADER_RE = re.compile(r"^(#{1,6})\s+(.*?)\s*$")


def drill(workspace: Path, uri: str) -> str:
    """Return the markdown section addressed by ``uri``.

    URIs accepted:

    - ``sessions/<key>.md#turn-N`` — one turn of a rendered session view.
    - ``ingested/<id>/source.md#section`` — one section of an ingested doc.
    - ``memory/<class>/<id>`` (no extension, no anchor) — the full memory
      entry file. The ``.md`` suffix is appended automatically.
    - Any absolute or workspace-relative path with optional ``#anchor``.

    Returns the section text (or full file content when no anchor is
    present), with a trailing newline.
    """
    if not uri or not uri.strip():
        raise DrillError("uri is required")

    if "#" in uri:
        path_part, anchor = uri.rsplit("#", 1)
    else:
        path_part, anchor = uri, ""

    raw = Path(path_part).expanduser()
    full_path = raw if raw.is_absolute() else (workspace / raw)

    # Memory entries are addressed without an extension (memory/<class>/<id>);
    # the on-disk file is .md.
    if not full_path.suffix and full_path.parent.name and not full_path.is_file():
        candidate = full_path.with_suffix(".md")
        if candidate.is_file():
            full_path = candidate

    if not full_path.is_file():
        raise DrillError(f"file not found: {full_path}")

    text = full_path.read_text(encoding="utf-8")
    if not anchor:
        return text if text.endswith("\n") else text + "\n"

    return extract_section(text, anchor)


def extract_section(text: str, anchor: str) -> str:
    """Pull the markdown section under the header ``## <anchor>``.

    Header level is determined from the actual header line. The section
    ends at the next header at the same or higher (smaller number of
    ``#``) level, or at end of file.
    """
    lines = text.splitlines()
    start = -1
    start_level = 0
    for i, line in enumerate(lines):
        m = _HEADER_RE.match(line)
        if m and m.group(2).strip() == anchor:
            start = i
            start_level = len(m.group(1))
            break

    if start == -1:
        raise DrillError(f"anchor not found: {anchor}")

    end = len(lines)
    for i in range(start + 1, len(lines)):
        m = _HEADER_RE.match(lines[i])
        if m and len(m.group(1)) <= start_level:
            end = i
            break

    return "\n".join(lines[start:end]).rstrip() + "\n"
