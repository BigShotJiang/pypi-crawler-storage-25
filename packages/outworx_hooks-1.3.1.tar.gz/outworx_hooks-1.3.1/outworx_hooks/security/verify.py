"""Provider dispatcher for signature verification."""

from typing import Dict, Optional

from .providers import (
    verify_stripe_signature,
    verify_github_signature,
    verify_shopify_signature,
    verify_svix_signature,
    verify_slack_signature,
)

SUPPORTED_PROVIDERS = ("stripe", "github", "shopify", "svix", "clerk", "slack")


def is_supported_provider(provider: str) -> bool:
    return provider.lower() in SUPPORTED_PROVIDERS


def _get_header(headers: Dict[str, str], name: str) -> Optional[str]:
    lower = name.lower()
    for k, v in headers.items():
        if k.lower() == lower:
            return v
    return None


def verify_by_provider(
    provider: str,
    raw_body: str,
    headers: Dict[str, str],
    secret: str,
    tolerance: Optional[int] = None,
) -> bool:
    """Dispatch signature verification to the correct provider.

    Returns ``False`` for unknown providers — callers should use a custom
    ``signature_verifier`` function instead.
    """
    p = provider.lower()
    if p == "stripe":
        return verify_stripe_signature(
            raw_body=raw_body,
            header=_get_header(headers, "stripe-signature"),
            secret=secret,
            tolerance=tolerance,
        )
    if p == "github":
        return verify_github_signature(
            raw_body=raw_body,
            header=_get_header(headers, "x-hub-signature-256"),
            secret=secret,
        )
    if p == "shopify":
        return verify_shopify_signature(
            raw_body=raw_body,
            header=_get_header(headers, "x-shopify-hmac-sha256"),
            secret=secret,
        )
    if p in ("svix", "clerk"):
        return verify_svix_signature(
            raw_body=raw_body,
            headers=headers,
            secret=secret,
            tolerance=tolerance,
        )
    if p == "slack":
        return verify_slack_signature(
            raw_body=raw_body,
            headers=headers,
            secret=secret,
            tolerance=tolerance,
        )
    return False
