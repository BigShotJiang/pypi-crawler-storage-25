"""Signature verification helpers.

Exposes per-provider verifiers plus a dispatcher. Can be imported
standalone:

    from outworx_hooks.security import verify_stripe_signature

Or used automatically via ``signature_secret`` on ``TrackOptions``.
"""

from .providers import (
    verify_stripe_signature,
    verify_github_signature,
    verify_shopify_signature,
    verify_svix_signature,
    verify_slack_signature,
)
from .verify import (
    verify_by_provider,
    is_supported_provider,
    SUPPORTED_PROVIDERS,
)
from .hmac import hmac_sha256_hex, hmac_sha256_base64, timing_safe_equal

__all__ = [
    "verify_stripe_signature",
    "verify_github_signature",
    "verify_shopify_signature",
    "verify_svix_signature",
    "verify_slack_signature",
    "verify_by_provider",
    "is_supported_provider",
    "SUPPORTED_PROVIDERS",
    "hmac_sha256_hex",
    "hmac_sha256_base64",
    "timing_safe_equal",
]
