"""Per-provider webhook signature verifiers.

Each function returns ``True`` when the signature is valid and fresh (within
``tolerance`` seconds for timestamp-based providers) and ``False`` otherwise.
All comparisons are timing-safe.
"""

import base64
import time
from typing import Dict, Optional

from .hmac import hmac_sha256_hex, hmac_sha256_base64, timing_safe_equal

DEFAULT_TOLERANCE_SECONDS = 300


def _lower_keys(headers: Dict[str, str]) -> Dict[str, str]:
    return {k.lower(): v for k, v in headers.items()}


def _within_tolerance(unix_seconds: int, tolerance: int) -> bool:
    now = int(time.time())
    return abs(now - unix_seconds) <= tolerance


# ─── Stripe ─────────────────────────────────────────────────
# Header: Stripe-Signature: t=<unix>,v1=<hex>,v1=<hex>
# Signed content: "{timestamp}.{raw body}"

def verify_stripe_signature(
    *,
    raw_body: str,
    header: Optional[str],
    secret: str,
    tolerance: Optional[int] = None,
) -> bool:
    if not header or not secret:
        return False
    tol = tolerance if tolerance is not None else DEFAULT_TOLERANCE_SECONDS

    timestamp: Optional[str] = None
    signatures: list = []
    for part in header.split(","):
        if "=" not in part:
            continue
        k, v = part.split("=", 1)
        if k == "t":
            timestamp = v
        elif k == "v1":
            signatures.append(v)

    if not timestamp or not signatures:
        return False
    try:
        ts = int(timestamp)
    except ValueError:
        return False
    if not _within_tolerance(ts, tol):
        return False

    expected = hmac_sha256_hex(secret, f"{timestamp}.{raw_body}")
    return any(timing_safe_equal(s, expected) for s in signatures)


# ─── GitHub ─────────────────────────────────────────────────
# Header: X-Hub-Signature-256: sha256=<hex>
# Signed content: raw body

def verify_github_signature(
    *,
    raw_body: str,
    header: Optional[str],
    secret: str,
) -> bool:
    if not header or not secret:
        return False
    if not header.startswith("sha256="):
        return False
    received = header[7:]
    expected = hmac_sha256_hex(secret, raw_body)
    return timing_safe_equal(received, expected)


# ─── Shopify ────────────────────────────────────────────────
# Header: X-Shopify-Hmac-Sha256: <base64>
# Signed content: raw body

def verify_shopify_signature(
    *,
    raw_body: str,
    header: Optional[str],
    secret: str,
) -> bool:
    if not header or not secret:
        return False
    expected = hmac_sha256_base64(secret, raw_body)
    return timing_safe_equal(header, expected)


# ─── Svix / Clerk ───────────────────────────────────────────
# Headers: svix-id, svix-timestamp, svix-signature
# svix-signature format: "v1,<base64> v1,<base64> ..."
# Signed content: "{id}.{timestamp}.{raw body}"
# Secret: "whsec_<base64>" — strip prefix and decode to raw bytes.

def verify_svix_signature(
    *,
    raw_body: str,
    headers: Dict[str, str],
    secret: str,
    tolerance: Optional[int] = None,
) -> bool:
    if not secret:
        return False
    tol = tolerance if tolerance is not None else DEFAULT_TOLERANCE_SECONDS
    h = _lower_keys(headers)

    msg_id = h.get("svix-id")
    timestamp = h.get("svix-timestamp")
    signature_header = h.get("svix-signature")
    if not msg_id or not timestamp or not signature_header:
        return False

    try:
        ts = int(timestamp)
    except ValueError:
        return False
    if not _within_tolerance(ts, tol):
        return False

    raw_secret = secret[6:] if secret.startswith("whsec_") else secret
    try:
        secret_bytes = base64.b64decode(raw_secret)
    except Exception:
        return False

    signed_payload = f"{msg_id}.{timestamp}.{raw_body}"
    expected = hmac_sha256_base64(secret_bytes, signed_payload)

    for entry in signature_header.split(" "):
        if "," not in entry:
            continue
        version, sig = entry.split(",", 1)
        if version != "v1" or not sig:
            continue
        if timing_safe_equal(sig, expected):
            return True
    return False


# ─── Slack ──────────────────────────────────────────────────
# Headers:
#   X-Slack-Request-Timestamp: <unix seconds>
#   X-Slack-Signature: v0=<hex>
# Signed content: "v0:{timestamp}:{raw body}"

def verify_slack_signature(
    *,
    raw_body: str,
    headers: Dict[str, str],
    secret: str,
    tolerance: Optional[int] = None,
) -> bool:
    if not secret:
        return False
    tol = tolerance if tolerance is not None else DEFAULT_TOLERANCE_SECONDS
    h = _lower_keys(headers)

    timestamp = h.get("x-slack-request-timestamp")
    signature_header = h.get("x-slack-signature")
    if not timestamp or not signature_header:
        return False
    if not signature_header.startswith("v0="):
        return False

    try:
        ts = int(timestamp)
    except ValueError:
        return False
    if not _within_tolerance(ts, tol):
        return False

    signed_payload = f"v0:{timestamp}:{raw_body}"
    expected = "v0=" + hmac_sha256_hex(secret, signed_payload)
    return timing_safe_equal(signature_header, expected)
