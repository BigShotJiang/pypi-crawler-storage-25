"""HMAC-SHA256 helpers for webhook signature verification.

Accepts both ``bytes`` and ``str`` inputs — strings are UTF-8 encoded before
hashing. Svix-style providers can pass a pre-decoded ``bytes`` secret
directly (see providers.py).
"""

import base64
import hashlib
import hmac as _hmac
from typing import Union

BytesLike = Union[bytes, str]


def _to_bytes(value: BytesLike) -> bytes:
    if isinstance(value, bytes):
        return value
    return value.encode("utf-8")


def hmac_sha256_hex(secret: BytesLike, data: BytesLike) -> str:
    """Return lowercase hex digest of HMAC-SHA256(secret, data)."""
    return _hmac.new(
        _to_bytes(secret), _to_bytes(data), hashlib.sha256
    ).hexdigest()


def hmac_sha256_base64(secret: BytesLike, data: BytesLike) -> str:
    """Return base64 digest of HMAC-SHA256(secret, data)."""
    return base64.b64encode(
        _hmac.new(_to_bytes(secret), _to_bytes(data), hashlib.sha256).digest()
    ).decode("ascii")


def timing_safe_equal(a: str, b: str) -> bool:
    """Timing-safe string comparison wrapping ``hmac.compare_digest``."""
    if len(a) != len(b):
        return False
    try:
        return _hmac.compare_digest(a, b)
    except (TypeError, ValueError):
        return False
