"""Internal helper for running signature verification from integrations.

Shared by FastAPI/Flask/Django middlewares so that each one doesn't
duplicate the precedence logic (explicit > custom fn > secret).
"""

import inspect
from typing import Dict, Optional

from .types import TrackOptions
from .security.verify import verify_by_provider, is_supported_provider


async def run_signature_verification(
    options: TrackOptions,
    raw_body: str,
    headers: Dict[str, str],
) -> Optional[bool]:
    """Run signature verification according to ``options``.

    Precedence: ``signature_valid`` (explicit) > ``signature_verifier`` >
    ``signature_secret``. Returns ``None`` if no verification is configured.
    Never raises — returns ``False`` on any exception from a user-supplied
    verifier.
    """
    if isinstance(options.signature_valid, bool):
        return options.signature_valid

    if options.signature_verifier is not None:
        try:
            result = options.signature_verifier(raw_body, headers)
            if inspect.isawaitable(result):
                result = await result
            return bool(result)
        except Exception:
            return False

    if options.signature_secret:
        if not is_supported_provider(options.provider):
            return False
        try:
            return verify_by_provider(
                options.provider,
                raw_body,
                headers,
                options.signature_secret,
                options.signature_tolerance,
            )
        except Exception:
            return False

    return None


def run_signature_verification_sync(
    options: TrackOptions,
    raw_body: str,
    headers: Dict[str, str],
) -> Optional[bool]:
    """Sync variant for Flask/Django. Raises if the user supplies an async
    verifier (which is a configuration error in sync frameworks)."""
    if isinstance(options.signature_valid, bool):
        return options.signature_valid

    if options.signature_verifier is not None:
        try:
            result = options.signature_verifier(raw_body, headers)
            if inspect.isawaitable(result):
                # Async verifier in a sync integration — user error.
                raise RuntimeError(
                    "signature_verifier returned a coroutine, but this "
                    "integration is synchronous. Use a sync function or "
                    "move to FastAPI."
                )
            return bool(result)
        except RuntimeError:
            raise
        except Exception:
            return False

    if options.signature_secret:
        if not is_supported_provider(options.provider):
            return False
        try:
            return verify_by_provider(
                options.provider,
                raw_body,
                headers,
                options.signature_secret,
                options.signature_tolerance,
            )
        except Exception:
            return False

    return None
