import time
from datetime import datetime
from typing import Any, Dict, Optional, Callable
from .types import TrackOptions, WebhookEventPayload
from .transport import send
from .utils import sanitize_headers, get_payload_size, extract_event_type, truncate

def capture_webhook_event(
    options: TrackOptions,
    request_headers: Dict[str, str],
    request_body: Any,
    status_code: int,
    duration_ms: int,
    response_body: Optional[str] = None,
    error_message: Optional[str] = None,
    source_url: Optional[str] = None,
    signature_valid: Optional[bool] = None,
    raw_request_body: Optional[str] = None,
):
    capture_headers = options.capture_headers is not False

    payload = WebhookEventPayload(
        provider=options.provider,
        event_type=extract_event_type(request_headers, request_body, options),
        status_code=status_code,
        success=200 <= status_code < 400,
        duration_ms=duration_ms,
        payload_size=get_payload_size(request_body),
        metadata=options.metadata,
        source_url=source_url,
        timestamp=datetime.utcnow().isoformat() + "Z",
        signature_valid=signature_valid if signature_valid is not None else options.signature_valid,
        error_message=error_message
    )

    if capture_headers:
        payload.request_headers = sanitize_headers(request_headers)

    if options.capture_body:
        # Prefer the raw text from the integration (exact bytes). Fall back
        # to serializing the parsed body if only that was available.
        body_text = raw_request_body
        if not body_text and request_body is not None:
            try:
                import json as _json
                body_text = (
                    request_body
                    if isinstance(request_body, str)
                    else _json.dumps(request_body)
                )
            except Exception:
                body_text = None
        if body_text:
            payload.request_body = truncate(body_text)
        if response_body:
            payload.response_body = truncate(response_body)

    send(payload)
