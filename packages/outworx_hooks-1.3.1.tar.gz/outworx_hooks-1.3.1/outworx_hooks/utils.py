import json
import sys
from typing import Dict, Any, Optional, Union
from .types import TrackOptions

SENSITIVE_HEADERS = {
    "authorization",
    "cookie",
    "set-cookie",
    "x-api-key",
    "x-auth-token",
    "proxy-authorization",
}

def sanitize_headers(headers: Dict[str, str]) -> Dict[str, str]:
    sanitized = {}
    for key, value in headers.items():
        if key.lower() in SENSITIVE_HEADERS:
            sanitized[key] = "[REDACTED]"
        else:
            sanitized[key] = value
    return sanitized

def get_payload_size(body: Any) -> int:
    if body is None:
        return 0
    if isinstance(body, str):
        return len(body.encode("utf-8"))
    if isinstance(body, bytes):
        return len(body)
    try:
        if isinstance(body, (dict, list)):
            return len(json.dumps(body).encode("utf-8"))
        return sys.getsizeof(body)
    except:
        return 0

def extract_event_type(
    headers: Dict[str, str],
    body: Any,
    options: TrackOptions
) -> Optional[str]:
    if options.event_type_header:
        header_name = options.event_type_header
        # Try exact and lower case
        value = headers.get(header_name) or headers.get(header_name.lower())
        if value:
            return value

    if options.event_type_field and isinstance(body, dict):
        value = body.get(options.event_type_field)
        if isinstance(value, str):
            return value

    return None

# Default cap for captured request/response bodies. Real-world webhook
# payloads (Stripe subscription events, GitHub PR events, Shopify order
# events) routinely exceed a few KB, so the old 4KB default was cutting
# off the fields you most need when debugging. PostgreSQL `text` has no
# practical size limit; 64KB covers ~99% of real payloads.
DEFAULT_MAX_LEN = 65536

def truncate(text: str, max_len: int = DEFAULT_MAX_LEN) -> str:
    if len(text) <= max_len:
        return text
    return text[:max_len] + "...[truncated]"
