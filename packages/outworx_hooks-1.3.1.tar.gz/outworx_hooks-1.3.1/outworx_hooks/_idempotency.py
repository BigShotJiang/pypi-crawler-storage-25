"""SDK-side helpers that talk to /api/sdk/idempotency/* on the backend.

Failure modes (network error, 5xx, timeout, SDK not configured) all fail
open — the caller should invoke the handler normally. Idempotency is a
best-effort feature that must never block webhook delivery.
"""

from typing import Optional, Tuple
from urllib.parse import urlparse, urlunparse

import httpx

from .config import get_config

TIMEOUT_S = 5.0
MAX_BODY_LENGTH = 4096


def _derive_sdk_url(ingest_endpoint: str, path: str) -> str:
    """Derive an /api/sdk/<path> URL from the configured ingest endpoint."""
    try:
        parsed = urlparse(ingest_endpoint)
        current = parsed.path
        if current.rstrip("/").endswith("/api/ingest"):
            base = current.rstrip("/").rsplit("/api/ingest", 1)[0]
        else:
            base = ""
        new_path = base + path
        return urlunparse(parsed._replace(path=new_path))
    except Exception:
        return f"https://hooks.outworx.io{path}"


def check_idempotency(
    key: str, ttl: Optional[int] = None
) -> Optional[dict]:
    """POST /api/sdk/idempotency/check. Returns the response dict or None on failure."""
    try:
        config = get_config()
    except RuntimeError:
        return None

    url = _derive_sdk_url(config.endpoint, "/api/sdk/idempotency/check")
    headers = {"Authorization": f"Bearer {config.api_key}"}
    payload: dict = {"key": key}
    if ttl is not None:
        payload["ttl"] = ttl

    try:
        with httpx.Client(timeout=TIMEOUT_S) as client:
            response = client.post(url, json=payload, headers=headers)
            if response.status_code != 200:
                if config.debug:
                    print(
                        f"[outworx-hooks] idempotency check failed: "
                        f"{response.status_code}"
                    )
                return None
            return response.json()
    except Exception as e:
        if config.debug:
            print(f"[outworx-hooks] idempotency check error: {e}")
        return None


def complete_idempotency(
    key: str,
    response_status_code: int,
    response_body: Optional[str] = None,
) -> None:
    """POST /api/sdk/idempotency/complete. Fire-and-forget — swallows errors."""
    try:
        config = get_config()
    except RuntimeError:
        return

    body = response_body
    if body and len(body) > MAX_BODY_LENGTH:
        body = body[:MAX_BODY_LENGTH]

    url = _derive_sdk_url(config.endpoint, "/api/sdk/idempotency/complete")
    headers = {"Authorization": f"Bearer {config.api_key}"}
    payload = {
        "key": key,
        "response_status_code": response_status_code,
        "response_body": body,
    }

    try:
        with httpx.Client(timeout=TIMEOUT_S) as client:
            response = client.post(url, json=payload, headers=headers)
            if response.status_code != 200 and config.debug:
                print(
                    f"[outworx-hooks] idempotency complete failed: "
                    f"{response.status_code}"
                )
    except Exception as e:
        if config.debug:
            print(f"[outworx-hooks] idempotency complete error: {e}")


def extract_cached_response(check_result: dict) -> Optional[Tuple[int, Optional[str]]]:
    """If the check returned a duplicate, extract (status_code, body)."""
    if check_result.get("status") != "duplicate":
        return None
    status_code = check_result.get("cached_status_code")
    body = check_result.get("cached_body")
    if not isinstance(status_code, int):
        status_code = 200
    return (status_code, body)
