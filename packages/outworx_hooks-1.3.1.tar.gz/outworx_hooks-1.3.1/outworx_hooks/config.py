import os
import re
from typing import Optional
from .types import OutworxHooksConfig

_config: Optional[OutworxHooksConfig] = None

API_KEY_REGEX = re.compile(r"^ohk_[a-f0-9]{32}$")


def _validate_api_key(key: Optional[str]) -> None:
    if not key:
        raise ValueError(
            "Outworx Hooks: api_key is required. "
            "Register at https://hooks.outworx.io to get a key."
        )
    if not API_KEY_REGEX.match(key):
        raise ValueError(
            "Outworx Hooks: invalid api_key format. "
            "Expected 'ohk_' followed by 32 hex characters. "
            "Register at https://hooks.outworx.io."
        )


def init(
    api_key: Optional[str] = None,
    endpoint: Optional[str] = None,
    debug: bool = False,
    timeout: int = 3000,
    on_error: Optional[callable] = None
) -> OutworxHooksConfig:
    global _config

    key = api_key or os.environ.get("OUTWORX_HOOKS_API_KEY")
    _validate_api_key(key)

    _config = OutworxHooksConfig(
        api_key=key,
        endpoint=endpoint or os.environ.get("OUTWORX_HOOKS_ENDPOINT", "https://hooks.outworx.io/api/ingest"),
        debug=debug or os.environ.get("OUTWORX_HOOKS_DEBUG") == "true",
        timeout=timeout,
        on_error=on_error
    )
    return _config


def get_config() -> OutworxHooksConfig:
    global _config
    if _config is None:
        # Try to initialize from env
        try:
            return init()
        except ValueError as e:
            raise RuntimeError(
                "Outworx Hooks SDK not initialized. Call outworx_hooks.init() first."
            ) from e
    return _config
