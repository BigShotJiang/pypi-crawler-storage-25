import time
import threading
import queue
import httpx
from typing import List, Optional
from urllib.parse import urlparse, urlunparse
from .types import WebhookEventPayload, OutworxHooksConfig
from .config import get_config

BATCH_DEBOUNCE_S = 0.1
MAX_BATCH_SIZE = 25
VERIFY_TIMEOUT_S = 5.0

# ── API key verification state (per-process cache) ──────────

# Possible states:
#   "pending"  — not yet verified; will verify on first send
#   "verified" — backend confirmed key exists
#   "invalid"  — backend rejected key; stop sending
#   "offline"  — could not reach backend; fall back to trusting format check
_verify_state: str = "pending"
_verify_lock = threading.Lock()


def _get_verify_url(ingest_endpoint: str) -> str:
    """Derive the /api/sdk/verify URL from the ingest endpoint."""
    try:
        parsed = urlparse(ingest_endpoint)
        path = parsed.path
        if path.rstrip("/").endswith("/api/ingest"):
            new_path = path.rstrip("/").rsplit("/api/ingest", 1)[0] + "/api/sdk/verify"
        else:
            new_path = "/api/sdk/verify"
        return urlunparse(parsed._replace(path=new_path))
    except Exception:
        return "https://hooks.outworx.io/api/sdk/verify"


def _verify_once(config: OutworxHooksConfig) -> None:
    """Call /api/sdk/verify to confirm the API key exists in the DB."""
    global _verify_state

    headers = {"Authorization": f"Bearer {config.api_key}"}
    try:
        with httpx.Client(timeout=VERIFY_TIMEOUT_S) as client:
            response = client.post(_get_verify_url(config.endpoint), headers=headers)
            if response.status_code in (401, 403):
                _verify_state = "invalid"
                # Intentional user-facing stderr message (not debug-gated)
                print(
                    "[outworx-hooks] API key rejected by server. "
                    "Register at https://hooks.outworx.io to get a valid key."
                )
            elif 200 <= response.status_code < 300:
                _verify_state = "verified"
                if config.debug:
                    print("[outworx-hooks] API key verified")
            else:
                _verify_state = "offline"
    except Exception:
        _verify_state = "offline"
        if config.debug:
            print(
                "[outworx-hooks] Could not reach verify endpoint; "
                "proceeding without verification"
            )


class EventTransport:
    def __init__(self):
        self.queue = queue.Queue()
        self.thread = threading.Thread(target=self._worker, daemon=True)
        self.stop_event = threading.Event()
        self.thread.start()

    def send(self, event: WebhookEventPayload):
        # Don't queue new events if the key was rejected
        if _verify_state == "invalid":
            return
        self.queue.put(event)

    def flush(self):
        pass

    def _worker(self):
        buffer = []
        last_flush = time.time()

        while not self.stop_event.is_set():
            try:
                event = self.queue.get(timeout=BATCH_DEBOUNCE_S)
                buffer.append(event)
                self.queue.task_done()
            except queue.Empty:
                pass

            now = time.time()
            if buffer and (len(buffer) >= MAX_BATCH_SIZE or (now - last_flush) >= BATCH_DEBOUNCE_S):
                self._send_batch(buffer)
                buffer = []
                last_flush = now

    def _send_batch(self, batch: List[WebhookEventPayload]):
        global _verify_state

        try:
            config = get_config()
        except RuntimeError:
            return

        # Run verification once per process
        if _verify_state == "pending":
            with _verify_lock:
                if _verify_state == "pending":
                    _verify_once(config)

        # Hard stop if the server rejected the key
        if _verify_state == "invalid":
            return

        payload = {
            "events": [self._payload_to_dict(e) for e in batch]
        }

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {config.api_key}"
        }

        try:
            with httpx.Client(timeout=config.timeout / 1000.0) as client:
                response = client.post(
                    config.endpoint,
                    json=payload,
                    headers=headers
                )
                if config.debug:
                    print(f"[outworx-hooks] Sent {len(batch)} event(s) — {response.status_code}")

                if response.status_code >= 400 and config.on_error:
                    config.on_error(Exception(f"Failed to send events: {response.status_code} {response.text}"))
        except Exception as e:
            if config.debug:
                print(f"[outworx-hooks] Failed to send events: {str(e)}")
            if config.on_error:
                config.on_error(e)

    def _payload_to_dict(self, event: WebhookEventPayload) -> dict:
        d = {
            "provider": event.provider,
            "status_code": event.status_code,
            "success": event.success,
            "duration_ms": event.duration_ms,
            "payload_size": event.payload_size,
            "timestamp": event.timestamp,
        }
        if event.event_type: d["event_type"] = event.event_type
        if event.request_headers: d["request_headers"] = event.request_headers
        if event.request_body: d["request_body"] = event.request_body
        if event.response_body: d["response_body"] = event.response_body
        if event.signature_valid is not None: d["signature_valid"] = event.signature_valid
        if event.error_message: d["error_message"] = event.error_message
        if event.metadata: d["metadata"] = event.metadata
        if event.source_url: d["source_url"] = event.source_url
        return d

_transport: Optional[EventTransport] = None
_lock = threading.Lock()

def get_transport() -> EventTransport:
    global _transport
    with _lock:
        if _transport is None:
            _transport = EventTransport()
    return _transport

def send(event: WebhookEventPayload):
    get_transport().send(event)
