from dataclasses import dataclass, field
from typing import Optional, Dict, Any, Callable

@dataclass
class WebhookEventPayload:
    provider: str
    status_code: int
    success: bool
    duration_ms: int
    payload_size: int
    timestamp: str  # ISO 8601
    event_type: Optional[str] = None
    request_headers: Optional[Dict[str, str]] = None
    request_body: Optional[str] = None
    response_body: Optional[str] = None
    signature_valid: Optional[bool] = None
    error_message: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    source_url: Optional[str] = None

@dataclass
class OutworxHooksConfig:
    api_key: str
    endpoint: str = "https://hooks.outworx.io/api/ingest"
    debug: bool = False
    timeout: int = 3000
    on_error: Optional[Callable[[Exception], None]] = None

@dataclass
class TrackOptions:
    provider: str
    event_type_header: Optional[str] = None
    event_type_field: Optional[str] = None
    capture_body: bool = False
    capture_headers: bool = True
    metadata: Optional[Dict[str, Any]] = None

    # Pre-computed signature verification result. If set, takes precedence
    # over signature_secret / signature_verifier.
    signature_valid: Optional[bool] = None

    # Auto-verify the incoming request using the built-in verifier for
    # `provider`. Supported: stripe, github, shopify, svix, clerk, slack.
    signature_secret: Optional[str] = None

    # Custom verifier. Called with raw body text and headers, returns bool.
    # Overrides signature_secret.
    signature_verifier: Optional[
        Callable[[str, Dict[str, str]], bool]
    ] = None

    # When verification fails, short-circuit with 401 before the handler.
    reject_invalid_signatures: bool = True

    # Replay-attack window in seconds for timestamp-based providers.
    signature_tolerance: int = 300

    # Extract an idempotency key from the incoming request. Duplicate
    # deliveries of the same key (within idempotency_ttl) short-circuit
    # with the cached response — the handler is not invoked again.
    # Return None to skip idempotency for a given event.
    idempotency_key: Optional[
        Callable[[Any, Any, Dict[str, str]], Optional[str]]
    ] = None

    # TTL for idempotency keys in seconds. Default 86400 (24h).
    # Server clamps to [60, 604800].
    idempotency_ttl: int = 86400
