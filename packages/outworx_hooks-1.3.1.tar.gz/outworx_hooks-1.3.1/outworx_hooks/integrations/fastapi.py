import inspect
import time
from typing import Optional

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response as StarletteResponse

from ..core import capture_webhook_event
from ..types import TrackOptions
from .._signature import run_signature_verification
from .._idempotency import (
    check_idempotency,
    complete_idempotency,
    extract_cached_response,
)


class OutworxHooksMiddleware(BaseHTTPMiddleware):
    """Starlette / FastAPI middleware.

    Runs signature verification (if configured) and idempotency checks (if
    configured) before the route handler. On an invalid signature, responds
    with 401 directly. On a duplicate idempotency key, returns the cached
    response without invoking the handler.

    The raw body is buffered and re-injected into the request stream so
    route handlers can still ``await request.json()`` / ``request.body()``.
    """

    def __init__(self, app, options: TrackOptions):
        super().__init__(app)
        self.options = options

    async def _extract_idempotency_key(
        self, request: Request, body_parsed, headers
    ) -> Optional[str]:
        fn = self.options.idempotency_key
        if fn is None:
            return None
        try:
            result = fn(request, body_parsed, headers)
            if inspect.isawaitable(result):
                result = await result
            if isinstance(result, str) and len(result) > 0:
                return result
        except Exception:
            pass
        return None

    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        request_headers = dict(request.headers)
        request_body_parsed = None
        raw_body_text = ""

        needs_raw_body = (
            self.options.signature_secret is not None
            or self.options.signature_verifier is not None
            or self.options.idempotency_key is not None
            or self.options.capture_body
        )

        if needs_raw_body:
            try:
                body_bytes = await request.body()
                raw_body_text = body_bytes.decode("utf-8", errors="replace")

                async def receive():
                    return {
                        "type": "http.request",
                        "body": body_bytes,
                        "more_body": False,
                    }

                request._receive = receive  # type: ignore[attr-defined]

                # Always try to parse as JSON when we have the body — callers
                # of idempotency_key typically reach into body fields like `id`.
                try:
                    import json as _json
                    request_body_parsed = _json.loads(raw_body_text)
                except Exception:
                    request_body_parsed = raw_body_text
            except Exception:
                pass

        # ── Signature verification ──────────────────────────
        signature_valid = await run_signature_verification(
            self.options, raw_body_text, request_headers
        )

        if (
            signature_valid is False
            and self.options.reject_invalid_signatures
        ):
            duration_ms = int((time.time() - start_time) * 1000)
            capture_webhook_event(
                options=self.options,
                request_headers=request_headers,
                request_body=request_body_parsed,
                status_code=401,
                duration_ms=duration_ms,
                error_message="Invalid webhook signature",
                source_url=str(request.url),
                signature_valid=False,
                raw_request_body=raw_body_text,
            )
            return StarletteResponse(
                "Invalid webhook signature", status_code=401
            )

        # ── Idempotency check ───────────────────────────────
        idempotency_key = await self._extract_idempotency_key(
            request, request_body_parsed, request_headers
        )

        if idempotency_key:
            check = check_idempotency(
                idempotency_key, self.options.idempotency_ttl
            )
            if check is not None:
                cached = extract_cached_response(check)
                if cached is not None:
                    duration_ms = int((time.time() - start_time) * 1000)
                    cached_status, cached_body = cached
                    dup_metadata = dict(self.options.metadata or {})
                    dup_metadata["duplicate"] = True
                    # Capture a tracking event tagged as duplicate, preserving
                    # the shared options but swapping in the enriched metadata.
                    dup_options = TrackOptions(**{
                        **self.options.__dict__,
                        "metadata": dup_metadata,
                    })
                    capture_webhook_event(
                        options=dup_options,
                        request_headers=request_headers,
                        request_body=request_body_parsed,
                        status_code=cached_status,
                        duration_ms=duration_ms,
                        source_url=str(request.url),
                        signature_valid=signature_valid,
                        raw_request_body=raw_body_text,
                    )
                    return StarletteResponse(
                        cached_body or "", status_code=cached_status
                    )

        # ── Normal flow ─────────────────────────────────────
        try:
            response: Response = await call_next(request)
            duration_ms = int((time.time() - start_time) * 1000)

            capture_webhook_event(
                options=self.options,
                request_headers=request_headers,
                request_body=request_body_parsed,
                status_code=response.status_code,
                duration_ms=duration_ms,
                source_url=str(request.url),
                signature_valid=signature_valid,
                raw_request_body=raw_body_text,
            )

            # Commit the idempotency reservation on a successful response.
            if idempotency_key and 200 <= response.status_code < 300:
                try:
                    body_bytes = b""
                    async for chunk in response.body_iterator:
                        body_bytes += chunk
                    response_body_text = body_bytes.decode(
                        "utf-8", errors="replace"
                    )
                    complete_idempotency(
                        idempotency_key,
                        response.status_code,
                        response_body_text,
                    )
                    # Rebuild the response since we drained its iterator.
                    return StarletteResponse(
                        content=body_bytes,
                        status_code=response.status_code,
                        headers=dict(response.headers),
                        media_type=response.media_type,
                    )
                except Exception:
                    # If body draining fails, still complete with status only.
                    complete_idempotency(
                        idempotency_key, response.status_code, None
                    )

            return response
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            capture_webhook_event(
                options=self.options,
                request_headers=request_headers,
                request_body=request_body_parsed,
                status_code=500,
                duration_ms=duration_ms,
                error_message=str(e),
                source_url=str(request.url),
                signature_valid=signature_valid,
                raw_request_body=raw_body_text,
            )
            raise
