import functools
import time

from flask import jsonify, make_response, request

from ..core import capture_webhook_event
from ..types import TrackOptions
from .._signature import run_signature_verification_sync
from .._idempotency import (
    check_idempotency,
    complete_idempotency,
    extract_cached_response,
)


def with_webhook_monitoring(options: TrackOptions):
    """Decorator for Flask routes.

    Runs signature verification and idempotency checks before the route
    handler. Invalid signatures return 401, duplicate idempotency keys
    return the cached response without invoking the handler.
    """
    def decorator(f):
        @functools.wraps(f)
        def decorated_function(*args, **kwargs):
            start_time = time.time()
            request_headers = dict(request.headers)
            request_body_parsed = None

            raw_body_text = ""
            try:
                raw_body_text = request.get_data(cache=True, as_text=True)
            except Exception:
                pass

            needs_parsed_body = (
                options.capture_body or options.idempotency_key is not None
            )
            if needs_parsed_body:
                try:
                    request_body_parsed = (
                        request.get_json(silent=True) or raw_body_text
                    )
                except Exception:
                    request_body_parsed = raw_body_text

            # ── Signature verification ──────────────────────
            signature_valid = run_signature_verification_sync(
                options, raw_body_text, request_headers
            )

            if (
                signature_valid is False
                and options.reject_invalid_signatures
            ):
                duration_ms = int((time.time() - start_time) * 1000)
                capture_webhook_event(
                    options=options,
                    request_headers=request_headers,
                    request_body=request_body_parsed,
                    status_code=401,
                    duration_ms=duration_ms,
                    error_message="Invalid webhook signature",
                    source_url=request.url,
                    signature_valid=False,
                    raw_request_body=raw_body_text,
                )
                return (
                    jsonify({"error": "Invalid webhook signature"}),
                    401,
                )

            # ── Idempotency check ───────────────────────────
            idempotency_key = None
            if options.idempotency_key is not None:
                try:
                    candidate = options.idempotency_key(
                        request, request_body_parsed, request_headers
                    )
                    if isinstance(candidate, str) and len(candidate) > 0:
                        idempotency_key = candidate
                except Exception:
                    idempotency_key = None

            if idempotency_key:
                check = check_idempotency(
                    idempotency_key, options.idempotency_ttl
                )
                if check is not None:
                    cached = extract_cached_response(check)
                    if cached is not None:
                        duration_ms = int((time.time() - start_time) * 1000)
                        cached_status, cached_body = cached
                        dup_metadata = dict(options.metadata or {})
                        dup_metadata["duplicate"] = True
                        dup_options = TrackOptions(**{
                            **options.__dict__,
                            "metadata": dup_metadata,
                        })
                        capture_webhook_event(
                            options=dup_options,
                            request_headers=request_headers,
                            request_body=request_body_parsed,
                            status_code=cached_status,
                            duration_ms=duration_ms,
                            source_url=request.url,
                            signature_valid=signature_valid,
                            raw_request_body=raw_body_text,
                        )
                        return make_response(
                            cached_body or "", cached_status
                        )

            # ── Normal flow ─────────────────────────────────
            try:
                raw_response = f(*args, **kwargs)
                duration_ms = int((time.time() - start_time) * 1000)

                # Normalize tuple / dict / Response returns into a single
                # Flask Response object so we can read status_code + body
                # reliably. `make_response` is idempotent for Response inputs.
                need_response_obj = (
                    options.capture_body or idempotency_key is not None
                )
                if need_response_obj:
                    response = make_response(raw_response)
                    status_code = response.status_code
                    try:
                        response_body = response.get_data(as_text=True)
                    except Exception:
                        response_body = None
                else:
                    response = raw_response
                    status_code = 200
                    if isinstance(raw_response, tuple) and len(raw_response) > 1:
                        status_code = raw_response[1]
                    elif hasattr(raw_response, "status_code"):
                        status_code = raw_response.status_code
                    response_body = None

                capture_webhook_event(
                    options=options,
                    request_headers=request_headers,
                    request_body=request_body_parsed,
                    status_code=status_code,
                    duration_ms=duration_ms,
                    response_body=response_body if options.capture_body else None,
                    source_url=request.url,
                    signature_valid=signature_valid,
                    raw_request_body=raw_body_text,
                )

                if idempotency_key and 200 <= status_code < 300:
                    complete_idempotency(
                        idempotency_key, status_code, response_body
                    )

                return response
            except Exception as e:
                duration_ms = int((time.time() - start_time) * 1000)
                capture_webhook_event(
                    options=options,
                    request_headers=request_headers,
                    request_body=request_body_parsed,
                    status_code=500,
                    duration_ms=duration_ms,
                    error_message=str(e),
                    source_url=request.url,
                    signature_valid=signature_valid,
                    raw_request_body=raw_body_text,
                )
                raise
        return decorated_function
    return decorator
