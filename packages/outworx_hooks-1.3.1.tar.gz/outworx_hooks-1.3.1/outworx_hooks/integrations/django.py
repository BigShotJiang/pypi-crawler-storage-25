import json
import time

from django.conf import settings
from django.http import HttpResponse, JsonResponse

from ..core import capture_webhook_event
from ..types import TrackOptions
from .._signature import run_signature_verification_sync
from .._idempotency import (
    check_idempotency,
    complete_idempotency,
    extract_cached_response,
)


class OutworxHooksMiddleware:
    """Django middleware.

    Reads ``OUTWORX_HOOKS_OPTIONS`` from Django settings. Runs signature
    verification and idempotency checks before passing to downstream views.
    Invalid signatures return 401, duplicate idempotency keys return the
    cached response without invoking the view.
    """

    def __init__(self, get_response):
        self.get_response = get_response
        raw_options = getattr(settings, "OUTWORX_HOOKS_OPTIONS", None)
        self.options = (
            TrackOptions(**raw_options)
            if isinstance(raw_options, dict)
            else raw_options
        )

    def __call__(self, request):
        if not self.options:
            return self.get_response(request)

        start_time = time.time()
        request_headers = {k: v for k, v in request.headers.items()}

        raw_body_text = ""
        try:
            raw_body_text = request.body.decode("utf-8", errors="replace")
        except Exception:
            pass

        request_body_parsed = None
        needs_parsed_body = (
            self.options.capture_body or self.options.idempotency_key is not None
        )
        if needs_parsed_body:
            try:
                if request.content_type == "application/json":
                    request_body_parsed = json.loads(raw_body_text)
                else:
                    request_body_parsed = raw_body_text
            except Exception:
                request_body_parsed = raw_body_text

        # ── Signature verification ──────────────────────────
        signature_valid = run_signature_verification_sync(
            self.options, raw_body_text, request_headers
        )

        if (
            signature_valid is False
            and self.options.reject_invalid_signatures
        ):
            duration_ms = int((time.time() - start_time) * 1000)
            capture_webhook_event(
                options=self.options,
                request_headers=request_headers,
                request_body=request_body_parsed,
                status_code=401,
                duration_ms=duration_ms,
                error_message="Invalid webhook signature",
                source_url=request.build_absolute_uri(),
                signature_valid=False,
                raw_request_body=raw_body_text,
            )
            return JsonResponse(
                {"error": "Invalid webhook signature"}, status=401
            )

        # ── Idempotency check ───────────────────────────────
        idempotency_key = None
        if self.options.idempotency_key is not None:
            try:
                candidate = self.options.idempotency_key(
                    request, request_body_parsed, request_headers
                )
                if isinstance(candidate, str) and len(candidate) > 0:
                    idempotency_key = candidate
            except Exception:
                idempotency_key = None

        if idempotency_key:
            check = check_idempotency(
                idempotency_key, self.options.idempotency_ttl
            )
            if check is not None:
                cached = extract_cached_response(check)
                if cached is not None:
                    duration_ms = int((time.time() - start_time) * 1000)
                    cached_status, cached_body = cached
                    dup_metadata = dict(self.options.metadata or {})
                    dup_metadata["duplicate"] = True
                    dup_options = TrackOptions(**{
                        **self.options.__dict__,
                        "metadata": dup_metadata,
                    })
                    capture_webhook_event(
                        options=dup_options,
                        request_headers=request_headers,
                        request_body=request_body_parsed,
                        status_code=cached_status,
                        duration_ms=duration_ms,
                        source_url=request.build_absolute_uri(),
                        signature_valid=signature_valid,
                        raw_request_body=raw_body_text,
                    )
                    return HttpResponse(
                        cached_body or "", status=cached_status
                    )

        # ── Normal flow ─────────────────────────────────────
        try:
            response = self.get_response(request)
            duration_ms = int((time.time() - start_time) * 1000)

            capture_webhook_event(
                options=self.options,
                request_headers=request_headers,
                request_body=request_body_parsed,
                status_code=response.status_code,
                duration_ms=duration_ms,
                source_url=request.build_absolute_uri(),
                signature_valid=signature_valid,
                raw_request_body=raw_body_text,
            )

            if idempotency_key and 200 <= response.status_code < 300:
                try:
                    body_text = response.content.decode(
                        "utf-8", errors="replace"
                    )
                except Exception:
                    body_text = None
                complete_idempotency(
                    idempotency_key, response.status_code, body_text
                )

            return response
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            capture_webhook_event(
                options=self.options,
                request_headers=request_headers,
                request_body=request_body_parsed,
                status_code=500,
                duration_ms=duration_ms,
                error_message=str(e),
                source_url=request.build_absolute_uri(),
                signature_valid=signature_valid,
                raw_request_body=raw_body_text,
            )
            raise
