import unittest
from outworx_hooks.utils import sanitize_headers, get_payload_size, extract_event_type, truncate
from outworx_hooks.types import TrackOptions

class TestUtils(unittest.TestCase):
    def test_sanitize_headers(self):
        headers = {
            "Content-Type": "application/json",
            "Authorization": "Bearer secret-token",
            "X-API-Key": "my-key"
        }
        sanitized = sanitize_headers(headers)
        self.assertEqual(sanitized["Content-Type"], "application/json")
        self.assertEqual(sanitized["Authorization"], "[REDACTED]")
        self.assertEqual(sanitized["X-API-Key"], "[REDACTED]")

    def test_get_payload_size(self):
        self.assertEqual(get_payload_size(None), 0)
        self.assertEqual(get_payload_size("hello"), 5)
        self.assertEqual(get_payload_size({"a": 1}), 8) # '{"a": 1}' is 8 bytes

    def test_extract_event_type(self):
        options = TrackOptions(provider="test", event_type_header="X-Event")
        headers = {"X-Event": "user.created"}
        self.assertEqual(extract_event_type(headers, {}, options), "user.created")

        options = TrackOptions(provider="test", event_type_field="type")
        body = {"type": "order.placed", "id": 123}
        self.assertEqual(extract_event_type({}, body, options), "order.placed")

    def test_truncate(self):
        text = "a" * 5000
        truncated = truncate(text, max_len=10)
        self.assertEqual(len(truncated), 10 + len("...[truncated]"))
        self.assertTrue(truncated.endswith("...[truncated]"))

if __name__ == "__main__":
    unittest.main()
