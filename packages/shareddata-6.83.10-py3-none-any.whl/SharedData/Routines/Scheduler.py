import faulthandler
import os
import sys
import time
from datetime import datetime
import pytz
from tzlocal import get_localzone
local_tz = pytz.timezone(str(get_localzone()))

# Capture a Python-level traceback if a C extension (pandas_parser, numpy,
# pyarrow, ...) crashes the interpreter with SIGSEGV/SIGABRT/SIGFPE/SIGBUS.
# Without this, a crash leaves only a kernel segfault line with a raw IP.
faulthandler.enable()

# PROPRIETARY LIBS
from SharedData.Routines.Schedule import Schedule
from SharedData.Logger import Logger
from SharedData.SharedData import SharedData
shdata = SharedData('SharedData.Routines.Scheduler', user='master')


def _safe(desc, fn, *args, **kwargs):
    """Run fn(*args, **kwargs), log any exception, never propagate."""
    try:
        return fn(*args, **kwargs)
    except Exception as e:
        Logger.log.error('Scheduler %s failed: %s' % (desc, e))
        return None


if len(sys.argv) >= 2:
    ARGS = str(sys.argv[1])
else:
    Logger.log.error('Schedules not provided, please specify!')
    raise SystemExit(2)

Logger.log.info(
    'SharedData Routines Scheduler starting for %s...' % (ARGS))

schedule_names = ARGS.split(',')

lastheartbeat = time.time()
Logger.log.info('ROUTINE STARTED!')

# Boot each schedule independently — one bad SCHEDULES/<name> must not
# prevent the others from running.
schedules = {}
for schedule_name in schedule_names:
    try:
        sched = Schedule(schedule_name)
        sched.update()
        sched.save()
        schedules[schedule_name] = sched
    except Exception as e:
        Logger.log.error(
            'Scheduler failed to load schedule %s: %s' % (schedule_name, e))

if not schedules:
    Logger.log.error('Scheduler has no loadable schedules — retrying in main loop')

while True:
    try:
        if time.time() - lastheartbeat > 15:
            lastheartbeat = time.time()
            Logger.log.debug('#heartbeat#schedule:%s' % (ARGS))

        # Retry failed schedule loads every tick so a transient MongoDB / metadata
        # outage doesn't leave a schedule permanently dark.
        for schedule_name in schedule_names:
            if schedule_name not in schedules:
                try:
                    sched = Schedule(schedule_name)
                    sched.update()
                    sched.save()
                    schedules[schedule_name] = sched
                    Logger.log.info(
                        'Scheduler recovered schedule %s' % (schedule_name))
                except Exception as e:
                    Logger.log.error(
                        'Scheduler still cannot load %s: %s' % (schedule_name, e))

        now = datetime.now().astimezone(tz=local_tz)
        for s in list(schedules.keys()):
            sched = schedules[s]
            try:
                if (
                    sched.schedule is not None
                    and len(sched.schedule) > 0
                    and 'runtimes' in sched.schedule.columns
                    and len(sched.schedule['runtimes']) > 0
                    and now.date() > sched.schedule['runtimes'][0].date()
                ):
                    Logger.log.info(
                        'Reloading Schedule %s %s' % (s, str(datetime.now())))
                    _safe('%s.load' % s, sched.load)

                _safe('%s.update' % s, sched.update)
                _safe('%s.run' % s, sched.run)
                _safe('%s.save' % s, sched.save)
            except Exception as e:
                # Belt-and-suspenders: even with per-stage _safe above, one
                # bad schedule cannot stop others from running this tick.
                Logger.log.error(
                    'Scheduler schedule %s tick failed: %s' % (s, e))

        time.sleep(5)
    except Exception as e:
        Logger.log.error('Scheduler Loop Exception: %s' % (str(e)))
        time.sleep(60)