from modict import modict
from .utils import timestamp, type_hierarchy


class AssistantInterrupted(Exception):
    """Raised internally when the current assistant turn is interrupted."""


class Event(modict):
    """Base runtime event."""

    timestamp = modict.factory(lambda: timestamp())
    types = modict.factory(list)

    def __init__(self, *args, **kwargs):
        args, kwargs, legacy_type = self.prepare_init_types(args, kwargs)
        super().__init__(*args, **kwargs)
        if not self.get('types'):
            self.types = self.default_types(legacy_type=legacy_type)

    @classmethod
    def prepare_init_types(cls, args, kwargs):
        kwargs = dict(kwargs)
        legacy_type = kwargs.pop('type', None)
        if args and isinstance(args[0], dict):
            data = dict(args[0])
            legacy_type = data.pop('type', legacy_type)
            args = (data, *args[1:])
        return args, kwargs, legacy_type

    @classmethod
    def default_types(cls, legacy_type=None):
        types = type_hierarchy(cls, Event)
        if legacy_type and legacy_type not in types:
            types.append(legacy_type)
        return types

    @modict.computed(deps=["types"])
    def type(self):
        return (self.get('types') or self.default_types())[-1]


class AssistantTurnStartEvent(Event):
    prompt = None
    message = None


class AssistantTurnEndEvent(Event):
    prompt = None
    message = None
    reason = ""


class AssistantTurnErrorEvent(Event):
    prompt = None
    message = None
    error = ''


class AssistantStepStartEvent(Event):
    message = None


class AssistantStepEndEvent(Event):
    message = None
    called_tools = False
    require_next_step = False
    stop_agentic_loop = False


class ResponseStartEvent(Event):
    message = None


class ResponseContentDeltaEvent(Event):
    delta = ''


class ResponseReasoningDeltaEvent(Event):
    delta = ''


class ResponseToolCallsDeltaEvent(Event):
    tool_calls = None


class ResponseOutputItemEvent(Event):
    item = None
    chunk = None
    message = None


class ResponseMessageDeltaEvent(Event):
    delta = None


class ResponseDoneEvent(Event):
    message = None


class MessageAddedEvent(Event):
    message = None


class MessageSubmittedEvent(Event):
    message = None
    turn_id = None


class SlashCommandStartEvent(Event):
    prompt = ''
    name = ''
    args = ''


class SlashCommandDoneEvent(Event):
    prompt = ''
    name = ''
    args = ''
    status = ''
    result = None
    error = ''


class CompactionRequestedEvent(Event):
    compacted_message_count = 0
    compacted_token_count = 0
    context_message_count = 0
    total_session_messages = 0


class CompactionCompletedEvent(Event):
    message = None
    compacted_message_count = 0
    compacted_token_count = 0
    post_compaction_message_count = 0
    total_session_messages = 0


class CompactionFailedEvent(Event):
    error = ''
    reason = ''
    compacted_message_count = 0
    compacted_token_count = 0
    context_message_count = 0
    total_session_messages = 0


class SessionLoadedEvent(Event):
    session = None
    session_id = ''


class SessionDeletedEvent(Event):
    session_id = ''


class AssistantInterruptRequestedEvent(Event):
    reason = ''
    interrupted = True
    error = ''

class WakeupScheduledEvent(Event):
    job = None

class WakeupTriggeredEvent(Event):
    job = None
    turn_id = None
    future = None

class WakeupCancelledEvent(Event):
    job = None

class MemoryArchiveErrorEvent(Event):
    error = ''
    end_message_id = ''

class ToolCallStartEvent(Event):
    tool_call = None
    tool = None

class ToolCallDoneEvent(Event):
    tool_call = None
    tool = None
    content = ''

class ServerToolCallEvent(Event):
    item = None
    tool = None
    name = ''
    call_id = ''
    status = ''

class AssistantInterruptedEvent(Event):
    reason = ''

class SubagentEvent(Event):
    subagent = ''
    event = None
    session_id = ''

class AudioPlaybackEvent(Event):
    audio = None


class RealtimeStartingEvent(Event):
    session_id = ''
    model = ''
    voice = ''
    audio_enabled = False


class RealtimeStartedEvent(Event):
    session_id = ''
    model = ''
    voice = ''
    audio_enabled = False


class RealtimeStoppedEvent(Event):
    session_id = ''
    reason = ''


class RealtimeErrorEvent(Event):
    session_id = ''
    error = ''


class RealtimeApiEvent(Event):
    session_id = ''
    api_event = None
    event_type = ''


class RealtimeSessionRefreshEvent(Event):
    session_id = ''
    reason = ''
    session = None


class RuntimeStateChangedEvent(Event):
    reason = ''
    namespace = ''
    name = ''
    owner = ''
    details = None


class EventBus:
    """Small synchronous event bus with decorator registration."""

    def __init__(self):
        self.handlers = {}
        self.owners = {}

    def event_types(self, event):
        if event == '*':
            return ['*']
        if isinstance(event, type) and issubclass(event, Event):
            return event.default_types()
        if isinstance(event, Event):
            return list(event.types or event.default_types())
        raise TypeError(f"Expected Event subclass, Event instance, or '*', got {type(event).__name__}")

    def event_type(self, event):
        return self.event_types(event)[-1]

    def on(self, event, handler=None, owner=None):
        event_type = self.event_type(event)
        if handler is None:
            def decorator(func):
                self.handlers.setdefault(event_type, []).append(func)
                if owner is not None:
                    self.owners.setdefault(event_type, {})[func] = owner
                return func
            return decorator

        self.handlers.setdefault(event_type, []).append(handler)
        if owner is not None:
            self.owners.setdefault(event_type, {})[handler] = owner
        return handler

    def off(self, event, handler):
        event_type = self.event_type(event)
        handlers = self.handlers.get(event_type)
        if handlers and handler in handlers:
            handlers.remove(handler)
        owners = self.owners.get(event_type)
        if owners:
            owners.pop(handler, None)
            if not owners:
                self.owners.pop(event_type, None)
        return handler

    def remove_by_owner(self, owner):
        removed = {}
        for event_type, handlers in list(self.handlers.items()):
            owners = self.owners.get(event_type, {})
            kept = []
            for handler in handlers:
                if owners.get(handler) == owner:
                    removed.setdefault(event_type, []).append(handler)
                    owners.pop(handler, None)
                else:
                    kept.append(handler)
            if kept:
                self.handlers[event_type] = kept
            else:
                self.handlers.pop(event_type, None)
                self.owners.pop(event_type, None)
        return removed

    def has_handlers(self, event, include_wildcard=True):
        event_type = self.event_type(event)
        return bool(self.handlers.get(event_type) or (include_wildcard and self.handlers.get('*')))

    def emit(self, event, **data):
        if isinstance(event, type) and issubclass(event, Event):
            event = event(**data)
        elif not isinstance(event, Event):
            raise TypeError(f"Expected Event subclass or Event instance, got {type(event).__name__}")

        seen_handlers = set()
        for event_type in event.types:
            for handler in self.handlers.get(event_type, ()):
                if handler in seen_handlers:
                    continue
                seen_handlers.add(handler)
                handler(event)
        for handler in self.handlers.get('*', ()):
            if handler in seen_handlers:
                continue
            seen_handlers.add(handler)
            handler(event)
        return event
