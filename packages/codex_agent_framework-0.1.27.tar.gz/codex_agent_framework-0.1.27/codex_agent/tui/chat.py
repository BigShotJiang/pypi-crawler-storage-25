from bisect import bisect_left, bisect_right
import os
import sys

from rich.text import Text
from textual.app import ComposeResult
from textual.containers import VerticalScroll
from textual.strip import Strip
from textual.widgets import Static

from ..client import AgentClient
from ..event import (
    AssistantStepEndEvent,
    AssistantStepStartEvent,
    AssistantTurnEndEvent,
    AssistantTurnErrorEvent,
    AssistantTurnStartEvent,
    CompactionCompletedEvent,
    MessageAddedEvent,
    ResponseContentDeltaEvent,
    ResponseDoneEvent,
    ServerToolCallEvent,
    SlashCommandDoneEvent,
    SlashCommandStartEvent,
    ToolCallDoneEvent,
    ToolCallStartEvent,
)
from .lifecycle import clear_tui, install_tui_cleanup_handlers, register_tui


TUI_MOUSE_ENV = "CODEX_AGENT_TUI_MOUSE"
TRUE_ENV_VALUES = {"1", "true", "yes", "on"}
FALSE_ENV_VALUES = {"0", "false", "no", "off"}


def tui_mouse_enabled(value=None, default=True):
    value = os.environ.get(TUI_MOUSE_ENV) if value is None else value
    if value is None:
        return default
    normalized = str(value).strip().lower()
    if normalized in TRUE_ENV_VALUES:
        return True
    if normalized in FALSE_ENV_VALUES:
        return False
    return default


class SelectableRichLog(VerticalScroll):
    """Scrollable rich text area backed by Static so Textual selection works."""

    ALLOW_SELECT = True
    DEFAULT_WINDOW_OVERSCAN_LINES = 80

    def __init__(self, *args, on_scroll_top=None, **kwargs):
        for rich_log_arg in ["max_lines", "min_width", "wrap", "highlight", "markup", "auto_scroll"]:
            kwargs.pop(rich_log_arg, None)
        super().__init__(*args, **kwargs)
        self.on_scroll_top = on_scroll_top
        self._content = Text()
        self._content_lines = None
        self._content_line_metrics = None
        self._window_overscan_lines = self.DEFAULT_WINDOW_OVERSCAN_LINES
        self._suspend_content_sync = False
        self._content_sync_pending = False

    def compose(self) -> ComposeResult:
        yield WindowedStatic(self._content, id="conversation-content", markup=False)

    @property
    def content_widget(self):
        return self.query_one("#conversation-content", Static)

    def clear(self):
        self._content = Text()
        self._content_lines = None
        self._content_line_metrics = None
        if self.is_attached:
            self._sync_content_window()
        return self

    def write(self, content="", *args, **kwargs):
        if len(self._content):
            self._content.append("\n")
        if isinstance(content, Text):
            self._content.append_text(content.copy())
        else:
            self._content.append(str(content))
        self._content_lines = None
        self._content_line_metrics = None
        if self.is_attached:
            self._sync_content_window()
        return self

    def begin_content_update(self):
        self._suspend_content_sync = True
        self._content_sync_pending = False

    def end_content_update(self):
        self._suspend_content_sync = False
        if self._content_sync_pending:
            self._content_sync_pending = False
            self._sync_content_window()

    def on_resize(self):
        self._content_line_metrics = None
        self._sync_content_window()

    def scroll_to_synced(self, *, y, animate=False):
        self.scroll_to(y=y, animate=animate, immediate=True)
        self._sync_content_window(layout=False)

    def scroll_end_synced(self, *, animate=False):
        self.scroll_end(animate=animate, immediate=True)
        self._sync_content_window(layout=False)

    def watch_scroll_y(self, old_value, new_value):
        super().watch_scroll_y(old_value, new_value)
        self._sync_content_window(layout=False)
        if new_value <= 0 and self.on_scroll_top is not None:
            self.on_scroll_top()

    def _logical_lines(self):
        if self._content_lines is None:
            self._content_lines = [] if not len(self._content) else list(self._content.split("\n", allow_blank=True))
        return self._content_lines

    def _sync_content_window(self, *, layout=True):
        if self._suspend_content_sync:
            self._content_sync_pending = True
            return
        if not self.is_attached:
            return
        lines = self._logical_lines()
        starts, heights, visual_line_count = self._line_metrics(lines)
        start, end, visible_start, visible_end = self._content_window_bounds(starts, visual_line_count)
        content_start = starts[start] if start < len(starts) else 0
        visible_line_count = visible_end - visible_start
        window = Text("\n").join(lines[start:end]) if start < end else Text()
        self.content_widget.set_window(
            content_start,
            window,
            visual_line_count,
            visible_start,
            visible_line_count,
            layout=layout,
        )

    def _line_metrics(self, lines):
        width = self._content_width()
        if self._content_line_metrics is not None and self._content_line_metrics[0] == width:
            return self._content_line_metrics[1:]
        starts = []
        heights = []
        total = 0
        for line in lines:
            starts.append(total)
            height = max(1, (max(0, line.cell_len) + width - 1) // width)
            heights.append(height)
            total += height
        self._content_line_metrics = (width, starts, heights, total)
        return starts, heights, total

    def _content_width(self):
        try:
            width = self.content_widget.size.width
        except Exception:
            width = 0
        return max(1, int(width or self.size.width or 80))

    def _content_window_bounds(self, line_starts, visual_line_count):
        if visual_line_count <= 0:
            return 0, 0, 0, 0
        overscan = max(0, int(self._window_overscan_lines or 0))
        height = max(1, int(self.size.height or 1))
        scroll_y = max(0, int(self.scroll_y or 0))
        visual_start = max(0, scroll_y - overscan)
        visual_end = min(visual_line_count, scroll_y + height + overscan)
        start = max(0, bisect_right(line_starts, visual_start) - 1)
        end = bisect_left(line_starts, visual_end)
        if start == end and start < len(line_starts):
            end += 1
        return start, max(start, end), visual_start, max(visual_start, visual_end)


class WindowedStatic(Static):
    """Static content with a large virtual height and a small rendered line window."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._content_start_line = 0
        self._window_start_line = 0
        self._window_line_count = 0

    def set_window(self, content_start_line, content, total_lines, window_start_line=None, window_line_count=None, *, layout=True):
        self._content_start_line = max(0, int(content_start_line or 0))
        self._window_start_line = max(0, int(window_start_line if window_start_line is not None else content_start_line or 0))
        if window_line_count is None:
            content_line_count = len(content.split("\n", allow_blank=True)) if len(content) else 0
            window_line_count = content_line_count
        self._window_line_count = max(0, int(window_line_count or 0))
        self.styles.height = max(1, int(total_lines or 0))
        self.update(content, layout=layout)

    def render_line(self, y):
        if y < self._window_start_line or y >= self._window_start_line + self._window_line_count:
            return Strip.blank(self.size.width, self.visual_style.rich_style)
        local_y = y - self._content_start_line
        return super().render_line(local_y)


class Chat:
    """Textual-based chat UI client for a codex-agent server."""

    CSS = """
    Screen {
        background: #000000;
        color: #aeb0aa;
    }
    Screen > .screen--selection {
        background: #6f98bd;
        color: #000000;
    }
    #main {
        height: 100%;
        padding: 0 1;
        background: #000000;
    }
    #conversation {
        height: 1fr;
        padding: 1 1;
        background: #000000;
        scrollbar-background: #000000;
        scrollbar-background-hover: #000000;
        scrollbar-background-active: #000000;
        scrollbar-color: #202020;
        scrollbar-color-hover: #2a2a2a;
        scrollbar-color-active: #343434;
    }
    #status {
        height: 1;
        color: #8b949e;
        background: #161b22;
        padding: 0 1;
    }
    #input {
        height: 3;
        margin-top: 0;
        padding: 0 1;
        background: #000000;
        color: #aeb0aa;
        border: blank #000000;
        scrollbar-size-vertical: 1;
        scrollbar-size-horizontal: 0;
        scrollbar-background: #000000;
        scrollbar-background-hover: #000000;
        scrollbar-background-active: #000000;
        scrollbar-color: #202020;
        scrollbar-color-hover: #2a2a2a;
        scrollbar-color-active: #343434;
    }
    TextArea > .text-area--cursor {
        background: #6f98bd;
        color: #0d1117;
    }
    Footer {
        background: #000000;
        color: #7d8590;
    }
    """

    def __init__(self, client=None, base_url="http://127.0.0.1:8765"):
        self.client = client or AgentClient(base_url=base_url)
        self.app = None
        self._seen_tool_calls = set()
        self._seen_slash_commands = set()
        self._agent_buffer = ""
        self._step_had_content = False
        self._transcript = []
        self._last_role = None
        self._visible_transcript_entries = 240
        self._default_visible_transcript_entries = 240
        self._transcript_load_chunk_entries = 160
        self._display_text_max_chars = 80_000
        self._display_text_max_lines = 1_600
        self._loading_older_transcript = False
        self._seen_event_ids = set()
        self._server_connected = False
        self._server_error = ""
        self._replaying_events = False
        self._replay_delta_buffer = ""

    @property
    def agent(self):
        # Compatibility shim for tests/older call sites that only read config/status.
        return self.client

    def attach(self):
        self.client.on(AssistantTurnStartEvent, self._once(self._on_assistant_turn_start))
        self.client.on(AssistantStepStartEvent, self._once(self._on_assistant_step_start))
        self.client.on(AssistantStepEndEvent, self._once(self._on_assistant_step_end))
        self.client.on(AssistantTurnEndEvent, self._once(self._on_assistant_turn_end))
        self.client.on(AssistantTurnErrorEvent, self._once(self._on_assistant_turn_error))
        self.client.on(CompactionCompletedEvent, self._once(self._on_compaction_completed))
        self.client.on(MessageAddedEvent, self._once(self._on_message_added))
        self.client.on(ResponseContentDeltaEvent, self._once(self._on_content_delta))
        self.client.on(ResponseDoneEvent, self._once(self._on_response_done))
        self.client.on(ToolCallStartEvent, self._once(self._on_tool_call_start))
        self.client.on(ToolCallDoneEvent, self._once(self._on_tool_call_done))
        self.client.on(ServerToolCallEvent, self._once(self._on_server_tool_call))
        self.client.on(SlashCommandStartEvent, self._once(self._on_slash_command_start))
        self.client.on(SlashCommandDoneEvent, self._once(self._on_slash_command_done))
        self.client.on("server_connected", self._on_server_connected)
        self.client.on("server_offline", self._on_server_offline)
        self.client.on("server_subscribed", self._on_server_subscribed)
        self.client.on("turn_error", self._on_turn_error)
        self.client.on("client_event_error", self._on_client_event_error)
        return self

    def _on_server_connected(self, event):
        self._mark_server_connected(announce=True)
        self._call_app("refresh_status")

    def _mark_server_connected(self, announce=False):
        was_offline = not self._server_connected
        self._server_connected = True
        self._server_error = ""
        if announce and was_offline:
            self._call_app("write_info", "server connected")

    def _on_server_offline(self, event):
        was_connected = self._server_connected
        self._server_connected = False
        self._server_error = event.get("error", "")
        if was_connected:
            self._call_app("write_info", "server offline")
        self._call_app("refresh_status")

    def _on_server_subscribed(self, event):
        self._mark_server_connected(announce=event.get("after_sequence") is not None)
        register_tui(base_url=self.client.base_url)
        self.replay_startup_events(event.get("replay_before_sequence"), session_id=event.get("session_id"))

    def replay_startup_events(self, before_sequence=None, session_id=None):
        try:
            replay = self.client.replay_events(before_sequence=before_sequence, session_id=session_id)
        except Exception as exc:
            self._call_app("write_error", f"failed to replay session events: {exc}")
            return
        self._replaying_events = True
        self._replay_delta_buffer = ""
        self._call_app("begin_transcript_batch")
        try:
            for event in replay.get("events") or []:
                self.client.remember_event_sequence(event)
                self.client.emit_local(event)
        finally:
            self._flush_replay_delta_buffer()
            self._replaying_events = False
            self._call_app("end_transcript_batch")

    def _on_compaction_completed(self, event):
        self._mark_server_connected()
        self._call_app("refresh_status")

    def run(self):
        from textual.app import App, ComposeResult
        from textual.containers import Vertical
        from textual.widgets import Footer, Static, TextArea

        chat = self
        mouse_enabled = tui_mouse_enabled()
        mouse_mode_hint = "mouse scroll on · drag chat text then Ctrl+C to copy"

        class AgentTextualApp(App):
            CSS = chat.CSS
            TITLE = "Codex Agent"
            BINDINGS = [
                ("ctrl+c", "interrupt", "Interrupt"),
                ("ctrl+l", "clear", "Clear"),
                ("ctrl+q", "quit", "Quit"),
                ("ctrl+s", "submit", "Submit"),
                ("alt+enter", "submit", "Submit"),
                ("ctrl+enter", "submit", "Submit"),
                ("f2", "submit", "Submit"),
            ]

            def compose(self) -> ComposeResult:
                with Vertical(id="main"):
                    yield SelectableRichLog(
                        id="conversation",
                        wrap=True,
                        highlight=False,
                        markup=True,
                        on_scroll_top=self.load_older_transcript,
                    )
                    yield Static("", id="status")
                    yield TextArea(
                        "",
                        placeholder=f"› message  ·  Enter = newline  ·  Ctrl+S/F2 = send  ·  {mouse_mode_hint}",
                        id="input",
                        show_line_numbers=False,
                        soft_wrap=True,
                    )
                yield Footer()

            def on_mount(self):
                chat.app = self
                self._suspend_transcript_render = False
                self._transcript_render_pending = False
                install_tui_cleanup_handlers()
                chat.attach()
                chat.client.start_events()
                self.refresh_status()
                self.resize_input()
                self.query_one("#input", TextArea).focus()
                self.write_info(f"Codex Agent client ready · {mouse_mode_hint}")

            def action_quit(self):
                clear_tui(pid=os.getpid())
                chat.client.stop(timeout=0.2)
                self.exit()

            def on_unmount(self):
                clear_tui(pid=os.getpid())

            def action_submit(self):
                input_widget = self.query_one("#input", TextArea)
                prompt = input_widget.text
                command = prompt.strip().lower()
                if not command:
                    return
                if command in ["exit", "quit", "/exit", "/quit"]:
                    self.exit()
                    return
                if command == "/clear":
                    input_widget.load_text("")
                    self.action_clear()
                    return
                input_widget.load_text("")
                self.refresh_status()
                self.run_worker(lambda: self._submit_prompt(prompt), thread=True)

            def on_text_area_changed(self, event: TextArea.Changed):
                if event.text_area.id == "input":
                    self.resize_input()

            def resize_input(self):
                input_widget = self.query_one("#input", TextArea)
                input_widget.styles.height = chat.composer_height(input_widget.text)

            def _submit_prompt(self, prompt):
                try:
                    chat.client.submit_prompt(prompt)
                except Exception as exc:
                    self.call_from_thread(self.write_error, str(exc))
                finally:
                    self.call_from_thread(self.refresh_status)

            def action_clear(self):
                chat._transcript.clear()
                chat._last_role = None
                chat.reset_visible_transcript_entries()
                self.query_one("#conversation", SelectableRichLog).clear()
                self.write_info("screen cleared · session history preserved")
                self.refresh_status()

            def action_interrupt(self):
                if self.screen.get_selected_text():
                    self.screen.action_copy_text()
                    return
                result = chat.client.interrupt("keyboard_interrupt")
                if result.get("error"):
                    self.write_error(f"interrupt requested · {result.error}")
                else:
                    self.write_error("interrupt requested")

            def log_width(self):
                raw_width = self.query_one("#conversation", SelectableRichLog).size.width or 80
                return max(32, raw_width - 6)

            def speaker_rule(self, name, style):
                width = self.log_width()
                label = f" {name} "
                available = max(2, width - len(label))
                left = available // 2
                right = available - left
                line = "─" * left + label + "─" * right
                return Text(line, style=style)

            def qed_marker(self, style="#6f98bd"):
                return Text(" " * max(0, self.log_width() - 1) + "▪", style=style)

            def render_transcript(self, *, keep_scroll=False):
                if self._suspend_transcript_render:
                    self._transcript_render_pending = True
                    return
                log = self.query_one("#conversation", SelectableRichLog)
                was_at_end = self.conversation_at_end(log)
                previous_scroll_y = log.scroll_y
                log.begin_content_update()
                try:
                    log.clear()
                    hidden = chat.hidden_transcript_entry_count()
                    if hidden:
                        log.write(Text(f"⋯ {hidden} older transcript entries hidden · scroll to top to load more", style="italic #6e7681"))
                        log.write("")
                    for entry in chat.visible_transcript_entries():
                        kind = entry[0]
                        if kind == "speaker":
                            _, name, style = entry
                            log.write(self.speaker_rule(name, style))
                            log.write("")
                        elif kind == "user":
                            log.write(chat.display_text_window(entry[1], style="#aeb0aa"))
                        elif kind == "agent":
                            log.write(chat.display_text_window(entry[1], style="#aeb0aa"))
                        elif kind == "tool":
                            _, name, call_id, status = entry
                            log.write(chat.tool_call_renderable(name, call_id=call_id, status=status))
                        elif kind == "slash_command":
                            _, name, args, status = entry
                            log.write(chat.slash_command_renderable(name, args=args, status=status))
                        elif kind == "step_end":
                            log.write(self.qed_marker())
                        elif kind == "user_end":
                            log.write(self.qed_marker("#88b38a"))
                        elif kind == "info":
                            log.write(Text("info › ", style="bold #7d8590") + Text(str(entry[1]), style="#8b949e"))
                        elif kind == "error":
                            log.write(Text("error › ", style="bold #ff7b72") + Text(str(entry[1]), style="#ff7b72"))
                finally:
                    log.end_content_update()
                if keep_scroll:
                    log.call_after_refresh(
                        lambda: log.scroll_to_synced(y=previous_scroll_y)
                    )
                elif not was_at_end:
                    log.call_after_refresh(
                        lambda: log.scroll_to_synced(y=previous_scroll_y)
                    )
                elif was_at_end:
                    log.call_after_refresh(log.scroll_end_synced)

            def begin_transcript_batch(self):
                self._suspend_transcript_render = True
                self._transcript_render_pending = False

            def end_transcript_batch(self):
                self._suspend_transcript_render = False
                if self._transcript_render_pending:
                    self._transcript_render_pending = False
                    self.render_transcript()

            def conversation_at_end(self, log=None):
                log = log or self.query_one("#conversation", SelectableRichLog)
                try:
                    return bool(log.is_vertical_scroll_end) or log.scroll_y >= log.max_scroll_y - 1
                except Exception:
                    return True

            def load_older_transcript(self):
                if chat._loading_older_transcript:
                    return
                chat._loading_older_transcript = True
                try:
                    if chat.load_older_transcript_entries():
                        self.render_transcript(keep_scroll=True)
                finally:
                    chat._loading_older_transcript = False

            def write_user(self, prompt):
                chat.append_user_transcript(prompt)
                self.render_transcript()

            def ensure_agent_role(self, name=None):
                if chat.ensure_agent_transcript(name):
                    self.render_transcript()

            def write_agent_start(self, name):
                chat._agent_buffer = ""
                chat._step_had_content = False
                chat._seen_tool_calls.clear()
                chat._seen_slash_commands.clear()

            def start_agent_step(self):
                chat._step_had_content = False
                self.render_transcript()

            def write_agent_delta(self, delta):
                self.ensure_agent_role()
                chat.apply_agent_delta(delta)
                chat._step_had_content = True
                self.render_transcript()

            def write_tool(self, name, call_id=None, status=None):
                chat.append_tool_transcript(name, call_id=call_id, status=status)
                self.render_transcript()

            def write_slash_command(self, name, args="", status=None):
                chat.append_slash_command_transcript(name, args=args, status=status)
                self.render_transcript()

            def end_agent_step(self):
                had_content = bool(chat._agent_buffer or chat._step_had_content)
                if chat._transcript and chat._transcript[-1][0] == "agent":
                    if chat._agent_buffer:
                        chat._transcript[-1] = ("agent", chat._agent_buffer)
                    else:
                        chat._transcript.pop()
                if had_content and (not chat._transcript or chat._transcript[-1][0] != "step_end"):
                    chat._transcript.append(("step_end",))
                self.render_transcript()

            def write_info(self, text):
                chat._transcript.append(("info", str(text)))
                self.render_transcript()

            def write_error(self, text):
                chat._transcript.append(("error", str(text)))
                self.render_transcript()

            def refresh_status(self):
                self.query_one("#status", Static).update(chat.status_renderable())

        AgentTextualApp().run(mouse=mouse_enabled)

    def username(self):
        try:
            return self.client.config.get("username") or "You"
        except Exception:
            return "You"

    def agent_name(self):
        try:
            return self.client.config.get("name") or "Pandora"
        except Exception:
            return "Pandora"

    def reset_visible_transcript_entries(self):
        self._visible_transcript_entries = self._default_visible_transcript_entries

    def visible_transcript_entries(self):
        count = max(0, int(self._visible_transcript_entries or 0))
        if count <= 0 or len(self._transcript) <= count:
            return list(self._transcript)
        return self._transcript[-count:]

    def hidden_transcript_entry_count(self):
        return max(0, len(self._transcript) - max(0, int(self._visible_transcript_entries or 0)))

    def has_hidden_transcript_entries(self):
        return self.hidden_transcript_entry_count() > 0

    def load_older_transcript_entries(self):
        before = self.hidden_transcript_entry_count()
        if before <= 0:
            return False
        self._visible_transcript_entries = min(
            len(self._transcript),
            max(0, int(self._visible_transcript_entries or 0)) + self._transcript_load_chunk_entries,
        )
        return self.hidden_transcript_entry_count() != before

    def display_text_window(self, text, *, style):
        text = str(text or "")
        visible_text = text
        omitted_chars = 0

        max_chars = max(0, int(self._display_text_max_chars or 0))
        if max_chars and len(visible_text) > max_chars:
            omitted_chars += len(visible_text) - max_chars
            visible_text = visible_text[-max_chars:]

        max_lines = max(0, int(self._display_text_max_lines or 0))
        if max_lines:
            lines = visible_text.splitlines(keepends=True)
            if len(lines) > max_lines:
                omitted_chars += sum(len(line) for line in lines[:-max_lines])
                visible_text = "".join(lines[-max_lines:])

        if omitted_chars <= 0:
            return Text(visible_text, style=style)

        return (
            Text(f"⋯ {omitted_chars} earlier output chars hidden in UI window\n", style="italic #6e7681")
            + Text(visible_text, style=style)
        )

    def append_user_transcript(self, prompt):
        self._agent_buffer = ""
        self._transcript.append(("speaker", self.username(), "#88b38a"))
        self._transcript.append(("user", prompt))
        self._transcript.append(("user_end",))
        self._last_role = "user"

    def ensure_agent_transcript(self, name=None):
        if self._last_role == "assistant":
            return False
        self._transcript.append(("speaker", name or self.agent_name(), "#789fbe"))
        self._last_role = "assistant"
        return True

    def append_tool_transcript(self, name, call_id=None, status=None):
        self.ensure_agent_transcript()
        self._transcript.append(("tool", name, call_id, status))
        self._step_had_content = True

    def append_slash_command_transcript(self, name, args="", status=None):
        self.ensure_agent_transcript()
        self._transcript.append(("slash_command", name, args, status))
        self._step_had_content = True

    @staticmethod
    def normalized_tool_status(status):
        if status in {"done", "completed", "success"}:
            return "done"
        if status in {"failed", "failure", "error"}:
            return "failed"
        if status in {None, "", "running"}:
            return "running"
        return str(status)

    @staticmethod
    def tool_status_badge(status):
        status = Chat.normalized_tool_status(status)
        if status == "done":
            return "✓", "bold #3fb950"
        if status == "failed":
            return "✕", "bold #ff7b72"
        return "→", "bold #58a6ff"

    @staticmethod
    def short_tool_call_id(call_id, *, max_length=16):
        if not call_id:
            return ""
        call_id = str(call_id)
        if len(call_id) <= max_length:
            return call_id
        keep = max(4, max_length - 2)
        head = max(4, keep // 2)
        tail = max(4, keep - head)
        return f"{call_id[:head]}…{call_id[-tail:]}"

    @staticmethod
    def tool_call_renderable(name, call_id=None, status=None):
        icon, style = Chat.tool_status_badge(status)
        text = Text("  ", style="#4b5563")
        text += Text(f"{icon} ", style=style)
        text += Text(name or "tool", style="bold white")
        short_id = Chat.short_tool_call_id(call_id)
        if short_id:
            text += Text(f"  #{short_id}", style="#6e7681")
        return text

    @staticmethod
    def tool_status_prefix(status):
        icon, style = Chat.tool_status_badge(status)
        return f"{icon} ", style

    @staticmethod
    def tool_status_label(status):
        return f" · {Chat.normalized_tool_status(status)}"

    @staticmethod
    def slash_command_renderable(name, args="", status=None):
        icon, style = Chat.tool_status_badge(status)
        command = f"/{name}" if name else "/"
        text = Text("  ", style="#4b5563")
        text += Text(f"{icon} ", style=style)
        text += Text(command, style="bold white")
        if args:
            text += Text(f" {args}", style="#8b949e")
        return text

    @staticmethod
    def slash_command_result_text(result):
        if result is None:
            return ""
        if isinstance(result, str):
            return result
        return str(result)

    def status_renderable(self):
        if not self._server_connected:
            suffix = f" · {self._server_error}" if self._server_error else ""
            return f"server offline · reconnecting{suffix}"
        try:
            return self.format_status(self.client.get_status())
        except Exception as exc:
            self._server_error = str(exc)
            return f"status unavailable · {exc}"

    @staticmethod
    def composer_height(text):
        useful_lines = max(1, min(10, str(text or "").count("\n") + 1))
        return useful_lines + 2

    @classmethod
    def format_status(cls, status):
        percent = float(status.get("context_percent") or 0)
        context_style = cls._percent_style(percent)
        used = cls._format_ktok(status.get("context_current_tokens") or 0)
        limit = cls._format_ktok(status.get("context_limit_tokens") or 0)
        context_segments = cls._context_token_status_segments(status, used, limit)
        quota_5h = cls._format_percent(status.get("quota_5h_percent"))
        quota_7d = cls._format_percent(status.get("quota_7d_percent"))
        sent_messages = int(status.get("sent_session_messages") or 0)
        persistent_messages = status.get("persistent_session_messages")
        temporary_messages = status.get("temporary_session_messages")
        active_wrapper_messages = status.get("active_wrapper_messages")
        vanished_wrapper_messages = status.get("vanished_wrapper_messages")
        total_messages = int(status.get("total_session_messages") or 0)
        compactable_turns = int(status.get("compactable_turns") or 0)
        model = status.get("model") or "-"
        message_segments = cls._message_status_segments(
            sent_messages,
            persistent_messages,
            temporary_messages,
            total_messages,
            active_wrapper_messages=active_wrapper_messages,
            vanished_wrapper_messages=vanished_wrapper_messages,
        )
        return Text.assemble(
            (" ctx ", "bold #c9d1d9 on #161b22"),
            *context_segments,
            (" ", "#8b949e on #161b22"),
            (f"{percent:.1f}%", f"{context_style} on #161b22"),
            ("  msg ", "#6e7681 on #161b22"),
            *message_segments,
            ("  cmp ", "#6e7681 on #161b22"),
            (str(compactable_turns), "#c9d1d9 on #161b22"),
            ("  5h ", "#6e7681 on #161b22"),
            (quota_5h, f"{cls._percent_style(status.get('quota_5h_percent'))} on #161b22"),
            ("  7d ", "#6e7681 on #161b22"),
            (quota_7d, f"{cls._percent_style(status.get('quota_7d_percent'))} on #161b22"),
            ("  model ", "#6e7681 on #161b22"),
            (str(model), "#c9d1d9 on #161b22"),
        )

    @classmethod
    def _context_token_status_segments(cls, status, used, limit):
        if "base_context_tokens" not in status and "active_wrapper_tokens" not in status and "vanished_wrapper_tokens" not in status:
            return ((f"{used}/{limit} ktok", "#8b949e on #161b22"),)
        base = cls._format_ktok(status.get("base_context_tokens") or 0)
        active_wrappers = cls._format_ktok(status.get("active_wrapper_tokens") or 0)
        vanished_wrappers = cls._format_ktok(status.get("vanished_wrapper_tokens") or 0)
        return (
            (base, "#c9d1d9 on #161b22"),
            (f"+{active_wrappers}", "italic #f0883e on #161b22"),
            (f"+{vanished_wrappers}", "italic #6e7681 on #161b22"),
            (f"/{limit} ktok", "#8b949e on #161b22"),
        )

    @staticmethod
    def _message_status_segments(sent_messages, persistent_messages, temporary_messages, total_messages, *, active_wrapper_messages=None, vanished_wrapper_messages=None):
        if persistent_messages is None and temporary_messages is None and active_wrapper_messages is None and vanished_wrapper_messages is None:
            return ((f"{sent_messages}/{total_messages}", "#c9d1d9 on #161b22"),)
        try:
            persistent = int(persistent_messages or 0)
            if active_wrapper_messages is None and vanished_wrapper_messages is None:
                temporary = int(temporary_messages or 0)
                return (
                    (str(persistent), "#c9d1d9 on #161b22"),
                    (f"+{temporary}", "italic #f0883e on #161b22"),
                    (f"/{total_messages}", "#c9d1d9 on #161b22"),
                )
            active_wrappers = int(active_wrapper_messages or 0)
            vanished_wrappers = int(vanished_wrapper_messages or 0)
        except Exception:
            return ((f"{sent_messages}/{total_messages}", "#c9d1d9 on #161b22"),)
        return (
            (str(persistent), "#c9d1d9 on #161b22"),
            (f"+{active_wrappers}", "italic #f0883e on #161b22"),
            (f"+{vanished_wrappers}", "italic #6e7681 on #161b22"),
            (f"/{total_messages}", "#c9d1d9 on #161b22"),
        )

    @staticmethod
    def _format_ktok(value):
        try:
            return f"{float(value) / 1000:.1f}"
        except Exception:
            return str(value)

    @staticmethod
    def _format_percent(value):
        if value is None:
            return "-"
        try:
            return f"{float(value):.0f}%"
        except Exception:
            return str(value)

    @staticmethod
    def _percent_style(value):
        try:
            percent = float(value)
        except Exception:
            return "#6e7681"
        if percent >= 90:
            return "bold #ff7b72"
        if percent >= 75:
            return "#f0883e"
        if percent >= 50:
            return "#d29922"
        return "#3fb950"

    def apply_agent_delta(self, delta):
        self._agent_buffer += delta
        if self._transcript and self._transcript[-1][0] == "agent":
            self._transcript[-1] = ("agent", self._agent_buffer)
        else:
            self._transcript.append(("agent", self._agent_buffer))

    def _call_app(self, method, *args):
        if self.app is None:
            return
        callback = getattr(self.app, method)
        try:
            self.app.call_from_thread(callback, *args)
        except RuntimeError:
            callback(*args)

    def _once(self, handler):
        def wrapped(event):
            event_id = event.get("id")
            if event_id:
                if event_id in self._seen_event_ids:
                    return
                self._seen_event_ids.add(event_id)
            return handler(event)
        return wrapped

    def _on_message_added(self, event):
        self._mark_server_connected()
        message = event.get("message") or {}
        if message.get("type") == "user_message":
            self._call_app("write_user", str(message.get("content") or ""))
            self._call_app("refresh_status")

    def _on_assistant_turn_start(self, event):
        self._mark_server_connected()
        self._call_app("write_agent_start", self.agent_name())
        self._call_app("refresh_status")

    def _on_assistant_step_start(self, event):
        self._mark_server_connected()
        self._agent_buffer = ""
        self._call_app("start_agent_step")

    def _on_assistant_step_end(self, event):
        self._mark_server_connected()
        self._flush_replay_delta_buffer()
        self._call_app("end_agent_step")
        self._call_app("refresh_status")

    def _on_assistant_turn_end(self, event):
        self._mark_server_connected()
        self._flush_replay_delta_buffer()
        result = event.get("result")
        if result not in (None, True, False):
            self._call_app("write_info", result)
        self._call_app("refresh_status")

    def _on_assistant_turn_error(self, event):
        self._mark_server_connected()
        self._call_app("write_error", event.get("error", "turn error"))
        self._call_app("refresh_status")

    def _on_content_delta(self, event):
        self._mark_server_connected()
        delta = event.get("delta", "")
        if self._replaying_events:
            self._replay_delta_buffer += delta
            return
        self._call_app("write_agent_delta", delta)

    def _on_response_done(self, event):
        self._mark_server_connected()
        self._flush_replay_delta_buffer()

    def _flush_replay_delta_buffer(self):
        if not self._replay_delta_buffer:
            return
        delta = self._replay_delta_buffer
        self._replay_delta_buffer = ""
        self._call_app("write_agent_delta", delta)

    def _on_tool_call_start(self, event):
        self._mark_server_connected()
        tool_call = event.get("tool_call") or {}
        name = tool_call.get("name") or "unknown"
        call_id = tool_call.get("call_id") or name
        self._print_tool_call(name, call_id, status="running")

    def _on_tool_call_done(self, event):
        self._mark_server_connected()
        tool_call = event.get("tool_call") or {}
        name = tool_call.get("name") or "unknown"
        call_id = tool_call.get("call_id") or name
        self._print_tool_call(name, call_id, status="done")

    def _on_server_tool_call(self, event):
        self._mark_server_connected()
        name = event.get("name") or "unknown"
        call_id = event.get("call_id") or name
        status = event.get("status") or ""
        self._print_tool_call(name, call_id, status=status)

    def _print_tool_call(self, name, call_id, status=None):
        key = (call_id, status or "running")
        if key in self._seen_tool_calls:
            return
        self._seen_tool_calls.add(key)
        self._call_app("write_tool", name, call_id, status or "running")

    def _on_slash_command_start(self, event):
        self._mark_server_connected()
        self._print_slash_command(event.get("name") or "", event.get("args") or "", status="running")

    def _on_slash_command_done(self, event):
        self._mark_server_connected()
        status = event.get("status") or ("failed" if event.get("error") else "done")
        self._print_slash_command(event.get("name") or "", event.get("args") or "", status=status)
        result = self.slash_command_result_text(event.get("result"))
        if result:
            self._call_app("write_agent_delta", result)
        if event.get("error"):
            self._call_app("write_error", event.get("error"))
        self._call_app("refresh_status")

    def _print_slash_command(self, name, args="", status=None):
        key = (name, args, status or "running")
        if key in self._seen_slash_commands:
            return
        self._seen_slash_commands.add(key)
        self._call_app("write_slash_command", name, args, status or "running")

    def _on_turn_error(self, event):
        self._call_app("write_error", event.get("error", "turn error"))
        self._call_app("refresh_status")

    def _on_client_event_error(self, event):
        message = event.get("detail") or event.get("error", "event stream error")
        if event.get("status_code") == 409:
            print(f"warning: {message}", file=sys.stderr)
            if self.app is not None:
                self._call_app("exit")
            return
        if event.get("source") == "event_stream":
            was_connected = self._server_connected
            self._server_connected = False
            self._server_error = message
            if was_connected:
                self._call_app("write_info", "server offline")
            self._call_app("refresh_status")
            return
        self._call_app("write_error", message)
