from rich.text import Text
from textual.app import App
from textual.events import MouseMove
from textual.geometry import Offset
from textual.widgets import Static
import pytest
from modict import modict

from codex_agent import Agent
from codex_agent.tui.chat import Chat, SelectableRichLog
from codex_agent.message import AssistantMessage, CompactionMessage, DeveloperMessage, ToolResultWrapper, UserMessage


def test_selectable_rich_log_accumulates_rich_text():
    log = SelectableRichLog()

    log.write(Text("alpha", style="bold red"))
    log.write("beta")

    assert log._content.plain == "alpha\nbeta"
    assert log._content.spans[0].style == "bold red"


def test_selectable_rich_log_scroll_top_callback():
    calls = []
    log = SelectableRichLog(on_scroll_top=lambda: calls.append(True))

    log.watch_scroll_y(12, 0)

    assert calls == [True]


@pytest.mark.asyncio
async def test_selectable_rich_log_rendered_text_has_selection_offsets():
    class TestApp(App):
        def compose(self):
            yield SelectableRichLog(id="log")

    async with TestApp().run_test(size=(20, 10)) as pilot:
        log = pilot.app.query_one("#log", SelectableRichLog)
        log.write("alpha")
        await pilot.pause()

        content = log.content_widget
        line = content.render_line(0)
        first_segment = next(iter(line))
        assert first_segment.style.meta["offset"] == (0, 0)
        widget, offset = pilot.app.screen.get_widget_and_offset_at(2, 0)
        assert widget is content
        assert offset == Offset(2, 0)


@pytest.mark.asyncio
async def test_selectable_rich_log_mouse_drag_selects_text():
    class TestApp(App):
        def compose(self):
            yield SelectableRichLog(id="log")

    async with TestApp().run_test(size=(30, 10)) as pilot:
        log = pilot.app.query_one("#log", SelectableRichLog)
        log.write("alpha beta gamma")
        await pilot.pause()

        await pilot.mouse_down("#log", offset=(1, 0))
        await pilot._post_mouse_events([MouseMove], widget="#log", offset=(8, 0), button=1)
        await pilot.mouse_up("#log", offset=(8, 0))

        assert pilot.app.screen.get_selected_text() == "lpha bet"


@pytest.mark.asyncio
async def test_selectable_rich_log_mouse_drag_handles_buttonless_move():
    class TestApp(App):
        def compose(self):
            yield SelectableRichLog(id="log")

    async with TestApp().run_test(size=(30, 10)) as pilot:
        log = pilot.app.query_one("#log", SelectableRichLog)
        log.write("alpha beta gamma")
        await pilot.pause()

        await pilot.mouse_down("#log", offset=(1, 0))
        await pilot._post_mouse_events([MouseMove], widget="#log", offset=(8, 0), button=0)
        await pilot.mouse_up("#log", offset=(8, 0))

        assert pilot.app.screen.get_selected_text() == "lpha bet"


@pytest.mark.asyncio
async def test_selectable_rich_log_mouse_drag_with_padding_selects_content():
    class TestApp(App):
        CSS = "SelectableRichLog { padding: 1 1; }"

        def compose(self):
            yield SelectableRichLog(id="log")

    async with TestApp().run_test(size=(30, 10)) as pilot:
        log = pilot.app.query_one("#log", SelectableRichLog)
        log.write("alpha beta gamma")
        await pilot.pause()

        await pilot.mouse_down("#log", offset=(1, 1))
        await pilot._post_mouse_events([MouseMove], widget="#log", offset=(8, 1), button=0)
        await pilot.mouse_up("#log", offset=(8, 1))

        assert pilot.app.screen.get_selected_text() == "alpha be"


@pytest.mark.asyncio
async def test_selectable_rich_log_deferred_scroll_end_follows_new_content():
    class TestApp(App):
        def compose(self):
            yield SelectableRichLog(id="log")

    async with TestApp().run_test(size=(30, 5)) as pilot:
        log = pilot.app.query_one("#log", SelectableRichLog)
        for index in range(12):
            log.write(f"line {index}")
        await pilot.pause()
        log.scroll_end(animate=False, immediate=False)
        await pilot.pause()
        assert log.is_vertical_scroll_end

        log.write("line 12")
        log.scroll_end(animate=False, immediate=False)
        await pilot.pause()

        assert log.is_vertical_scroll_end


@pytest.mark.asyncio
async def test_selectable_rich_log_windows_rendered_lines_around_scroll():
    class TestApp(App):
        def compose(self):
            yield SelectableRichLog(id="log")

    async with TestApp().run_test(size=(30, 8)) as pilot:
        log = pilot.app.query_one("#log", SelectableRichLog)
        log._window_overscan_lines = 2
        for index in range(60):
            log.write(f"line {index}")
        await pilot.pause()

        content = log.content_widget
        assert content._window_line_count < 60
        assert content._window_start_line == 0

        log.scroll_to(y=30, animate=False, immediate=True)
        await pilot.pause()

        assert content._window_start_line == 28
        assert content._window_line_count <= 12
        rendered = "".join(segment.text for segment in content.render_line(30))
        assert "line 30" in rendered
        blank = "".join(segment.text for segment in content.render_line(2)).strip()
        assert blank == ""


@pytest.mark.asyncio
async def test_selectable_rich_log_scroll_end_synced_renders_tail_after_wrap_growth():
    class TestApp(App):
        def compose(self):
            yield SelectableRichLog(id="log")

    async with TestApp().run_test(size=(12, 3)) as pilot:
        log = pilot.app.query_one("#log", SelectableRichLog)
        log._window_overscan_lines = 0
        log.write("prefix 0")
        log.write("prefix 1")
        log.write("prefix 2")
        log.write("0123456789abcdefghijABCDEFGHIJ")
        await pilot.pause()

        log.call_after_refresh(log.scroll_end_synced)
        await pilot.pause()

        content = log.content_widget
        assert content._window_start_line == log.max_scroll_y
        rendered = "".join(segment.text for segment in content.render_line(log.max_scroll_y + log.size.height - 1)).strip()
        assert rendered == "ABCDEFGHIJ"


def test_agent_context_status_is_lightweight_and_does_not_call_providers():
    agent = Agent(session="new", input_token_limit=10_000)
    agent.session.messages.append(DeveloperMessage(content="hello context"))
    called = []

    @agent.add_provider
    def expensive_provider():
        called.append(True)
        return "expensive"

    status = agent.status_manager.context_status()

    assert called == []
    assert status.used_tokens > 0
    assert status.input_token_limit == 10_000
    assert 0 <= status.percent <= 100
    assert status.total_session_messages == len(agent.session.messages)
    assert status.visible_history_messages <= status.total_history_messages
    assert status.sent_session_messages <= status.total_session_messages


def test_agent_context_status_counts_only_effective_context_messages():
    agent = Agent(session="new", input_token_limit=10_000)
    old = DeveloperMessage(content="old hidden context")
    compaction = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "cs_123"}])
    expired = DeveloperMessage(content="expired hidden context", turns_left=0)
    visible = DeveloperMessage(content="visible context")
    agent.session.messages = [old, compaction, expired, visible]

    status = agent.status_manager.context_status()

    assert status.context_session_messages == 2
    assert status.total_history_messages == 2
    assert status.sent_session_messages == 2
    assert status.persistent_session_messages == 2
    assert status.temporary_session_messages == 0


def test_agent_context_status_counts_persistent_and_temporary_messages():
    agent = Agent(session="new", input_token_limit=10_000)
    compaction = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "cs_123"}])
    persistent = DeveloperMessage(content="persistent")
    temporary = DeveloperMessage(content="temporary", turns_left=2)
    expired = DeveloperMessage(content="expired", turns_left=0)
    agent.session.messages = [compaction, persistent, temporary, expired]

    status = agent.status_manager.context_status()

    assert status.context_session_messages == 3
    assert status.persistent_session_messages == 2
    assert status.temporary_session_messages == 1


def test_agent_context_status_counts_active_and_vanished_wrappers():
    agent = Agent(session="new", input_token_limit=10_000)
    persistent = DeveloperMessage(content="persistent")
    active_wrapper = ToolResultWrapper(content="active wrapper payload", turns_left=2, tool_name="read", call_id="call_active")
    vanished_wrapper = ToolResultWrapper(content="vanished wrapper payload", turns_left=0, tool_name="read", call_id="call_vanished")
    agent.session.messages = [persistent, active_wrapper, vanished_wrapper]

    status = agent.status_manager.context_status()

    assert status.active_wrapper_messages == 1
    assert status.vanished_wrapper_messages == 1
    assert status.total_wrapper_messages == 2
    assert status.active_wrapper_tokens > 0
    assert status.vanished_wrapper_tokens > 0
    assert status.base_context_tokens >= status.fixed_tokens
    assert status.used_tokens == status.base_context_tokens + status.active_wrapper_tokens


def test_agent_status_preserves_persistent_and_temporary_message_counts():
    agent = Agent(session="new", input_token_limit=10_000)
    agent.session.messages.append(DeveloperMessage(content="persistent"))
    agent.session.messages.append(DeveloperMessage(content="temporary", turns_left=2))

    status = agent.get_status()

    assert status.persistent_session_messages == 2
    assert status.temporary_session_messages == 1


def test_agent_api_status_uses_precached_persistent_and_temporary_counts(monkeypatch):
    agent = Agent(session="new", input_token_limit=10_000)
    agent.session.messages.append(DeveloperMessage(content="persistent"))
    agent.session.messages.append(DeveloperMessage(content="temporary", turns_left=2))

    agent.context_manager.get_context()
    monkeypatch.setattr(agent.status_manager, "context_status", lambda: (_ for _ in ()).throw(AssertionError("should use cache")))
    agent.status_manager.cache_api_status(usage=modict(input_tokens=1000), model="gpt-test")

    status = agent.get_status()
    assert status.persistent_session_messages == 2
    assert status.temporary_session_messages == 1


def test_agent_context_status_counts_compactable_turns():
    agent = Agent(session="new", input_token_limit=10_000)
    agent.session.messages = [
        UserMessage(content="first request"),
        AssistantMessage(content="first answer"),
        UserMessage(content="second request"),
        AssistantMessage(content="second answer"),
        UserMessage(content="current unfinished request"),
    ]

    status = agent.status_manager.context_status()

    assert status.compactable_turns == 2
    assert status.compactable_messages == 4
    assert status.compactable_tokens > 0


def test_agent_status_preserves_compactable_counts():
    agent = Agent(session="new", input_token_limit=10_000)
    agent.session.messages = [
        UserMessage(content="first request"),
        AssistantMessage(content="first answer"),
        UserMessage(content="current unfinished request"),
    ]

    status = agent.get_status()

    assert status.compactable_turns == 1
    assert status.compactable_messages == 2
    assert status.compactable_tokens > 0


def test_agent_context_status_counts_response_tool_specs():
    agent = Agent(session="new", input_token_limit=10_000)

    @agent.add_tool
    def verbose_tool(query: str):
        """
        description: Search a deliberately verbose external index with a long schema description.
        parameters:
          query:
            type: string
            description: A rich query string that can include names, dates, references, and constraints.
        """
        return query

    status = agent.status_manager.context_status()

    assert status.tool_spec_tokens == agent.context_manager.response_tools_token_count()
    assert status.tool_spec_tokens > 0
    assert status.fixed_tokens >= status.tool_spec_tokens
    assert status.token_count_source == "local_estimate"


def test_agent_get_status_uses_cached_last_api_call_status():
    agent = Agent(session="new", input_token_limit=10_000)
    agent.session.messages.append(DeveloperMessage(content="hello context"))
    agent.status_manager.cache_api_status(
        usage=modict(input_tokens=2500),
        model="gpt-test",
        quota={
            "rate_limit": {
                "primary_window": {"used_percent": 12},
                "secondary_window": {"used_percent": 34},
            },
        },
    )

    status = agent.get_status()

    assert status.context_current_tokens == 2500
    assert status.context_limit_tokens == 10_000
    assert status.context_percent == 25
    assert status.sent_session_messages == len(agent.session.messages)
    assert status.total_session_messages == len(agent.session.messages)
    assert status.sent_session_message_percent == 100
    assert status.quota_5h_percent == 12
    assert status.quota_7d_percent == 34
    assert status.model == "gpt-test"


def test_agent_api_status_uses_precached_context_message_ratio(monkeypatch):
    agent = Agent(session="new", input_token_limit=10_000)
    agent.session.messages.append(DeveloperMessage(content="first"))
    agent.session.messages.append(DeveloperMessage(content="second"))

    agent.context_manager.get_context()
    monkeypatch.setattr(agent.status_manager, "context_status", lambda: (_ for _ in ()).throw(AssertionError("should use cache")))
    agent.status_manager.cache_api_status(usage=modict(input_tokens=1000), model="gpt-test")

    status = agent.get_status()
    assert status.sent_session_messages == len(agent.session.messages)
    assert status.total_session_messages == len(agent.session.messages)
    assert status.sent_session_message_percent == 100


def test_agent_get_status_preloads_wham_once_before_first_api_call():
    agent = Agent(session="new", input_token_limit=10_000)
    calls = []

    class Client:
        @property
        def codex(self):
            return self

        def usage(self):
            calls.append("usage")
            return {
                "rate_limit": {
                    "primary_window": {"used_percent": 12},
                    "secondary_window": {"used_percent": 34},
                },
            }

    agent.ai._codex_client = Client()

    first = agent.get_status()
    second = agent.get_status()

    assert calls == ["usage"]
    assert first.quota_5h_percent == 12
    assert first.quota_7d_percent == 34
    assert second.quota_5h_percent == 12
    assert second.quota_7d_percent == 34


def test_agent_wham_status_normalizes_quota_windows():
    agent = Agent(session="new")

    status = agent.status_manager.wham_status({
        "plan_type": "plus",
        "rate_limit": {
            "allowed": True,
            "limit_reached": False,
            "primary_window": {"used_percent": 12, "limit_window_seconds": 18_000},
            "secondary_window": {"used_percent": 34, "limit_window_seconds": 604_800},
        },
        "credits": {"used": 1},
        "additional_rate_limits": [{"name": "extra"}],
        "rate_limit_reached_type": None,
    })

    assert status.plan_type == "plus"
    assert status.allowed is True
    assert status.limit_reached is False
    assert status.primary_window.used_percent == 12
    assert status.secondary_window.used_percent == 34
    assert status.credits == {"used": 1}
    assert status.additional_rate_limits == [{"name": "extra"}]
    assert status.rate_limit_reached_type is None
    assert status.quota_5h_percent == 12
    assert status.quota_7d_percent == 34


def test_chat_status_bar_formats_compact_status():
    status = modict(
        context_current_tokens=12_300,
        context_limit_tokens=128_000,
        context_percent=9.609,
        sent_session_messages=8,
        total_session_messages=25,
        compactable_turns=6,
        quota_5h_percent=42,
        quota_7d_percent=13,
        model="gpt-5.4",
    )

    rendered = Chat.format_status(status)
    output = rendered.plain

    assert "ctx" in output
    assert "12.3/128.0 ktok" in output
    assert "9.6%" in output
    assert "msg 8/25" in output
    assert "cmp 6" in output
    assert "5h 42%" in output
    assert "7d 13%" in output
    assert "gpt-5.4" in output
    assert any("#161b22" in str(span.style) for span in rendered.spans)


def test_chat_status_bar_formats_context_and_message_wrapper_splits():
    status = modict(
        context_current_tokens=12_300,
        context_limit_tokens=128_000,
        context_percent=9.609,
        base_context_tokens=10_000,
        active_wrapper_tokens=2_000,
        vanished_wrapper_tokens=4_000,
        sent_session_messages=43,
        persistent_session_messages=33,
        temporary_session_messages=10,
        active_wrapper_messages=7,
        vanished_wrapper_messages=12,
        total_session_messages=93,
        compactable_turns=17,
        quota_5h_percent=42,
        quota_7d_percent=13,
        model="gpt-5.4",
    )

    rendered = Chat.format_status(status)
    output = rendered.plain

    assert "ctx 10.0+2.0+4.0/128.0 ktok" in output
    assert "msg 33+7+12/93" in output
    assert "cmp 17" in output
    assert any(
        "#f0883e" in str(span.style) and output[span.start:span.end] in {"+2.0", "+7"}
        for span in rendered.spans
    )
    assert any(
        "#6e7681" in str(span.style) and output[span.start:span.end] in {"+4.0", "+12"}
        for span in rendered.spans
    )


def test_chat_status_bar_formats_persistent_plus_temporary_messages():
    status = modict(
        context_current_tokens=12_300,
        context_limit_tokens=128_000,
        context_percent=9.609,
        sent_session_messages=43,
        persistent_session_messages=33,
        temporary_session_messages=10,
        total_session_messages=93,
        quota_5h_percent=42,
        quota_7d_percent=13,
        model="gpt-5.4",
    )

    rendered = Chat.format_status(status)
    output = rendered.plain

    assert "msg 33+10/93" in output
    assert any(
        "#f0883e" in str(span.style) and output[span.start:span.end] == "+10"
        for span in rendered.spans
    )


def test_chat_refresh_status_keeps_rich_text_styles():
    chat = Chat(client=modict(
        get_status=lambda: modict(
            context_current_tokens=10_000,
            context_limit_tokens=100_000,
            context_percent=80,
            sent_session_messages=8,
            total_session_messages=25,
            quota_5h_percent=55,
            quota_7d_percent=91,
            model="gpt-5.4",
        )
    ))
    chat._server_connected = True
    rendered = chat.status_renderable()

    assert hasattr(rendered, "spans")
    assert any("#f0883e" in str(span.style) for span in rendered.spans)


def test_chat_status_percent_styles_use_green_yellow_orange_red_scale():
    assert Chat._percent_style(10) == "#3fb950"
    assert Chat._percent_style(50) == "#d29922"
    assert Chat._percent_style(75) == "#f0883e"
    assert Chat._percent_style(90) == "bold #ff7b72"
    assert Chat._percent_style(None) == "#6e7681"


def test_chat_composer_height_expands_between_one_and_ten_useful_lines():
    assert Chat.composer_height("") == 3
    assert Chat.composer_height("one\ntwo") == 4
    assert Chat.composer_height("\n".join(str(i) for i in range(10))) == 12
    assert Chat.composer_height("\n".join(str(i) for i in range(20))) == 12


def test_chat_replays_startup_events_after_subscription(monkeypatch):
    chat = Chat()
    calls = []

    class App:
        def call_from_thread(self, callback, *args):
            callback(*args)

        def write_user(self, prompt):
            calls.append(("user", prompt))

        def write_agent_start(self, name):
            calls.append(("agent_start", name))

        def write_agent_delta(self, delta):
            calls.append(("delta", delta))

        def refresh_status(self):
            calls.append(("status",))

        def begin_transcript_batch(self):
            calls.append(("begin_batch",))

        def end_transcript_batch(self):
            calls.append(("end_batch",))

    chat.app = App()
    chat.attach()
    monkeypatch.setattr("codex_agent.tui.chat.register_tui", lambda base_url: None)
    monkeypatch.setattr(
        chat.client,
        "replay_events",
        lambda before_sequence=None, session_id=None: calls.append(("replay", before_sequence, session_id)) or modict(events=[
            modict(id="evt_1", type="assistant_turn_start_event", prompt="hello", sequence=5),
            modict(id="evt_2", type="message_added_event", message=UserMessage(content="hello"), sequence=6),
            modict(id="evt_3", type="assistant_turn_start_event", sequence=7),
            modict(id="evt_4", type="response_content_delta_event", delta="he", sequence=8),
            modict(id="evt_5", type="response_content_delta_event", delta="llo", sequence=9),
        ]),
    )

    chat._on_server_subscribed(modict(replay_before_sequence=9, session_id="session_1"))

    assert chat._server_connected is True
    assert chat.client._last_event_sequence == 9
    assert ("replay", 9, "session_1") in calls
    assert ("begin_batch",) in calls
    assert ("end_batch",) in calls
    assert ("user", "hello") in calls
    assert ("agent_start", chat.agent_name()) in calls
    assert [call for call in calls if call[0] == "delta"] == [("delta", "hello")]


def test_chat_displays_user_message_added_events(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))
    message = UserMessage(content="hello from session")

    chat._on_message_added(modict(type="message_added_event", message=message))

    assert calls == [
        ("write_user", ("hello from session",)),
        ("refresh_status", ()),
    ]


def test_chat_uses_message_added_event_as_user_message_display_source(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))
    message = UserMessage(content="hello submitted")

    chat.attach()
    chat.client.emit_local(modict(type="message_submitted_event", message=message, turn_id="turn_1"))
    assert calls == []

    chat.client.emit_local(modict(type="message_added_event", message=message))

    assert calls == [
        ("write_user", ("hello submitted",)),
        ("refresh_status", ()),
    ]


def test_chat_attach_dispatches_assistant_turn_and_step_events(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))

    chat.attach()
    chat.client.emit_local(modict(type="assistant_turn_start_event"))
    chat.client.emit_local(modict(type="assistant_step_start_event"))
    chat.client.emit_local(modict(type="response_content_delta_event", delta="hi"))
    chat.client.emit_local(modict(type="assistant_step_end_event"))
    chat.client.emit_local(modict(type="assistant_turn_end_event", reason="completed"))
    chat.client.emit_local(modict(type="assistant_turn_error_event", error="boom"))

    assert ("write_agent_start", (chat.agent_name(),)) in calls
    assert ("start_agent_step", ()) in calls
    assert ("write_agent_delta", ("hi",)) in calls
    assert ("end_agent_step", ()) in calls
    assert ("write_error", ("boom",)) in calls
    assert not any("agent_turn" in str(call) for call in calls)


def test_chat_displays_tool_start_and_done_as_distinct_lines(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))

    chat.attach()
    tool_call = modict(name="read", call_id="call_read")
    chat.client.emit_local(modict(type="assistant_turn_start_event"))
    chat.client.emit_local(modict(type="tool_call_start_event", tool_call=tool_call))
    chat.client.emit_local(modict(type="tool_call_done_event", tool_call=tool_call, content="ok"))

    assert calls.count(("write_tool", ("read", "call_read", "running"))) == 1
    assert calls.count(("write_tool", ("read", "call_read", "done"))) == 1
    assert calls.index(("write_tool", ("read", "call_read", "running"))) < calls.index(("write_tool", ("read", "call_read", "done")))


def test_chat_displays_slash_command_start_and_done_as_distinct_lines(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))

    chat.attach()
    chat.client.emit_local(modict(type="assistant_turn_start_event"))
    chat.client.emit_local(modict(type="slash_command_start_event", name="compact", args="--force"))
    chat.client.emit_local(modict(type="slash_command_done_event", name="compact", args="--force", status="done"))

    assert calls.count(("write_slash_command", ("compact", "--force", "running"))) == 1
    assert calls.count(("write_slash_command", ("compact", "--force", "done"))) == 1
    assert calls.index(("write_slash_command", ("compact", "--force", "running"))) < calls.index(("write_slash_command", ("compact", "--force", "done")))


def test_chat_slash_command_done_displays_result(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))

    chat.attach()
    chat.client.emit_local(modict(type="slash_command_done_event", name="help", status="done", result="Available commands: /help"))

    assert ("write_slash_command", ("help", "", "done")) in calls
    assert ("write_agent_delta", ("Available commands: /help",)) in calls
    assert calls[-1] == ("refresh_status", ())


def test_chat_slash_command_done_displays_errors(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))

    chat.attach()
    chat.client.emit_local(modict(type="slash_command_done_event", name="missing", status="failed", error="Unknown command: /missing"))

    assert ("write_slash_command", ("missing", "", "failed")) in calls
    assert ("write_error", ("Unknown command: /missing",)) in calls
    assert calls[-1] == ("refresh_status", ())


def test_chat_tool_status_helpers_are_compact_and_consistent():
    assert Chat.normalized_tool_status("success") == "done"
    assert Chat.normalized_tool_status("error") == "failed"
    assert Chat.normalized_tool_status(None) == "running"

    assert Chat.tool_status_badge("running") == ("→", "bold #58a6ff")
    assert Chat.tool_status_badge("done") == ("✓", "bold #3fb950")
    assert Chat.tool_status_badge("failed") == ("✕", "bold #ff7b72")
    assert Chat.tool_status_label("running") == " · running"
    assert Chat.tool_status_label("done") == " · done"


def test_chat_shortens_long_tool_call_ids():
    assert Chat.short_tool_call_id("call_123") == "call_123"
    shortened = Chat.short_tool_call_id("call_abcdefghijklmnopqrstuvwxyz", max_length=14)
    assert shortened.startswith("call_")
    assert shortened.endswith("wxyz")
    assert "…" in shortened
    assert len(shortened) <= 14


def test_chat_tool_call_renderable_is_discreet_and_readable():
    rendered = Chat.tool_call_renderable("bash", call_id="call_abcdefghijklmnopqrstuvwxyz", status="done")
    plain = rendered.plain

    assert plain.startswith("  ✓ bash")
    assert "#call_" in plain
    assert "tool ›" not in plain
    assert "done" not in plain
    assert "running" not in plain
    assert "failed" not in plain
    assert "abcdefghijklmnopqrstuvwxyz" not in plain


def test_chat_appends_tool_lines_immediately_without_waiting_for_step_end():
    chat = Chat()

    chat.append_tool_transcript("bash", call_id="call_sleep", status="running")

    assert chat._transcript[-1] == ("tool", "bash", "call_sleep", "running")
    assert chat._step_had_content is True


def test_chat_transcript_tracks_user_and_assistant_role_boundaries(monkeypatch):
    chat = Chat()
    monkeypatch.setattr(chat, "username", lambda: "You")

    assert chat.ensure_agent_transcript("Pandora") is True
    assert chat.ensure_agent_transcript("Pandora") is False

    chat._agent_buffer = "already streamed"
    chat.append_user_transcript("new direction")
    assert chat._agent_buffer == ""
    assert chat.ensure_agent_transcript("Pandora") is True

    assert chat._transcript == [
        ("speaker", "Pandora", "#789fbe"),
        ("speaker", "You", "#88b38a"),
        ("user", "new direction"),
        ("user_end",),
        ("speaker", "Pandora", "#789fbe"),
    ]


def test_chat_display_text_window_limits_large_outputs_by_chars():
    chat = Chat()
    chat._display_text_max_chars = 10
    chat._display_text_max_lines = 0

    rendered = chat.display_text_window("abcdefghijklmnopqrstuvwxyz", style="#fff")

    assert "earlier output chars hidden" in rendered.plain
    assert rendered.plain.endswith("qrstuvwxyz")
    assert "abcdefghijklmnop" not in rendered.plain


def test_chat_display_text_window_limits_large_outputs_by_lines():
    chat = Chat()
    chat._display_text_max_chars = 0
    chat._display_text_max_lines = 3

    rendered = chat.display_text_window("one\ntwo\nthree\nfour\nfive", style="#fff")

    assert "earlier output chars hidden" in rendered.plain
    assert rendered.plain.endswith("three\nfour\nfive")
    assert "\none\n" not in rendered.plain


def test_chat_tracks_server_connection_state(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))

    chat._server_connected = True
    chat._on_server_offline({"type": "server_offline", "error": "server down"})
    assert chat._server_connected is False
    assert chat._server_error == "server down"
    assert ("write_info", ("server offline",)) in calls
    assert calls[-1] == ("refresh_status", ())

    chat._on_server_connected({"type": "server_connected"})
    assert chat._server_connected is True
    assert chat._server_error == ""
    assert ("write_info", ("server connected",)) in calls
    assert calls[-1] == ("refresh_status", ())


def test_chat_event_stream_error_marks_server_offline_once(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))

    chat._server_connected = True
    chat._on_client_event_error({"type": "client_event_error", "source": "event_stream", "error": "connection lost"})
    chat._on_client_event_error({"type": "client_event_error", "source": "event_stream", "error": "still down"})

    assert chat._server_connected is False
    assert chat._server_error == "still down"
    assert calls == [
        ("write_info", ("server offline",)),
        ("refresh_status", ()),
        ("refresh_status", ()),
    ]


def test_chat_local_client_error_does_not_mark_server_offline(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))

    chat._server_connected = True
    chat._on_client_event_error({"type": "client_event_error", "error": "handler failed"})

    assert chat._server_connected is True
    assert chat._server_error == ""
    assert calls == [("write_error", ("handler failed",))]


def test_chat_status_error_does_not_mark_connected_stream_offline():
    chat = Chat(client=modict(get_status=lambda: (_ for _ in ()).throw(RuntimeError("status timeout"))))
    chat._server_connected = True

    rendered = chat.status_renderable()

    assert chat._server_connected is True
    assert "status unavailable" in rendered


def test_chat_stream_event_restores_connected_state(monkeypatch):
    chat = Chat()
    calls = []
    monkeypatch.setattr(chat, "_call_app", lambda method, *args: calls.append((method, args)))

    chat._server_connected = False
    chat._server_error = "stale status error"
    chat._on_content_delta(modict(type="response_content_delta_event", delta="hi"))

    assert chat._server_connected is True
    assert chat._server_error == ""
    assert ("write_agent_delta", ("hi",)) in calls


def test_chat_renders_each_live_stream_delta():
    chat = Chat()
    calls = []

    class App:
        def call_from_thread(self, callback, *args):
            callback(*args)

        def write_agent_delta(self, delta):
            calls.append(("delta", delta))

    chat.app = App()

    chat._on_content_delta(modict(type="response_content_delta_event", delta="he"))
    chat._on_content_delta(modict(type="response_content_delta_event", delta="llo"))

    assert calls == [("delta", "he"), ("delta", "llo")]


def test_chat_live_deltas_render_before_tool_start(monkeypatch):
    chat = Chat()
    calls = []

    def call_app(method, *args):
        calls.append((method, args))

    class App:
        def call_from_thread(self, callback, *args):
            callback(*args)

        def write_agent_delta(self, delta):
            calls.append(("write_agent_delta", (delta,)))

    chat.app = App()
    monkeypatch.setattr(chat, "_call_app", call_app)

    chat._on_content_delta(modict(type="response_content_delta_event", delta="I will "))
    chat._on_content_delta(modict(type="response_content_delta_event", delta="inspect."))
    chat._on_response_done(modict(type="response_done_event"))
    chat._on_tool_call_start(modict(type="tool_call_start_event", tool_call=modict(name="bash", call_id="call_1")))

    assert ("write_agent_delta", ("I will ",)) in calls
    assert ("write_agent_delta", ("inspect.",)) in calls
    assert ("write_tool", ("bash", "call_1", "running")) in calls
    assert calls.index(("write_agent_delta", ("inspect.",))) < calls.index(("write_tool", ("bash", "call_1", "running")))


def test_chat_flushes_replay_deltas_before_live_deltas(monkeypatch):
    chat = Chat()
    calls = []

    class App:
        def call_from_thread(self, callback, *args):
            callback(*args)

        def write_agent_delta(self, delta):
            calls.append(("delta", delta))

        def write_agent_start(self, name):
            calls.append(("start", name))

        def refresh_status(self):
            calls.append(("status",))

        def begin_transcript_batch(self):
            calls.append(("begin_batch",))

        def end_transcript_batch(self):
            calls.append(("end_batch",))

    chat.app = App()
    chat.attach()
    monkeypatch.setattr("codex_agent.tui.chat.register_tui", lambda base_url: None)
    monkeypatch.setattr(
        chat.client,
        "replay_events",
        lambda before_sequence=None, session_id=None: modict(events=[
            modict(id="evt_1", type="assistant_turn_start_event", sequence=1),
            modict(id="evt_2", type="response_content_delta_event", delta="old", sequence=2),
        ]),
    )

    chat._on_server_subscribed(modict(replay_before_sequence=2, session_id="session_1"))
    chat._on_content_delta(modict(type="response_content_delta_event", delta="new"))

    assert ("delta", "old") in calls
    assert [call for call in calls if call[0] == "delta"] == [("delta", "old"), ("delta", "new")]


def test_chat_replay_batches_transcript_rendering_until_end(monkeypatch):
    chat = Chat()
    calls = []

    class App:
        def __init__(self):
            self._suspend_transcript_render = False
            self._transcript_render_pending = False

        def call_from_thread(self, callback, *args):
            callback(*args)

        def begin_transcript_batch(self):
            self._suspend_transcript_render = True
            self._transcript_render_pending = False
            calls.append(("begin_batch",))

        def end_transcript_batch(self):
            self._suspend_transcript_render = False
            calls.append(("end_batch",))
            if self._transcript_render_pending:
                self.render_transcript()

        def render_transcript(self):
            if self._suspend_transcript_render:
                self._transcript_render_pending = True
                return
            calls.append(("render",))

        def write_agent_start(self, name):
            calls.append(("start", name))
            self.render_transcript()

        def write_agent_delta(self, delta):
            calls.append(("delta", delta))
            self.render_transcript()

        def write_tool(self, name, call_id=None, status=None):
            calls.append(("tool", name, call_id, status))
            self.render_transcript()

        def refresh_status(self):
            calls.append(("status",))

    chat.app = App()
    chat.attach()
    monkeypatch.setattr("codex_agent.tui.chat.register_tui", lambda base_url: None)
    monkeypatch.setattr(
        chat.client,
        "replay_events",
        lambda before_sequence=None, session_id=None: modict(events=[
            modict(id="evt_1", type="assistant_turn_start_event", sequence=1),
            modict(id="evt_2", type="response_content_delta_event", delta="a", sequence=2),
            modict(id="evt_3", type="assistant_step_end_event", sequence=3),
            modict(id="evt_4", type="tool_call_start_event", tool_call=modict(name="bash", call_id="call_1"), sequence=4),
            modict(id="evt_5", type="response_content_delta_event", delta="b", sequence=5),
        ]),
    )

    chat._on_server_subscribed(modict(replay_before_sequence=5, session_id="session_1"))

    assert calls.count(("render",)) == 1
    assert calls.index(("begin_batch",)) < calls.index(("end_batch",)) < calls.index(("render",))
