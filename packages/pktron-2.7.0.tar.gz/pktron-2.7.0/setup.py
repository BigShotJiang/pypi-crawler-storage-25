from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="pktron",
    version="2.7.0",
    description="PKTron - Pakistan's 1st Quantum AI Powered Simulation Framework with 200+ Professional Features",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="CETQAP",
    author_email="info@thecetqap.com",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.21",
        "scipy>=1.7",
        "matplotlib>=3.4",
        "networkx>=2.6",
    ],
    extras_require={
        "gpu":  ["cupy-cuda12x"],
        "ml":   ["torch>=1.12"],
        "full": ["cupy-cuda12x", "torch>=1.12"],
    },
)
