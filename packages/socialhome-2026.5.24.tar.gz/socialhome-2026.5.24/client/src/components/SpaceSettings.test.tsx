import { describe, it, expect, vi, beforeEach } from 'vitest'
import { render, fireEvent } from '@testing-library/preact'

vi.mock('@/i18n/i18n', () => ({
  t: (key: string) => key,
  locale: { value: 'en' },
  setLocale: vi.fn(),
}))
vi.mock('@/api', () => {
  const m = { get: vi.fn(), put: vi.fn(), post: vi.fn(), patch: vi.fn(), delete: vi.fn() }
  return { api: m }
})
vi.mock('./Toast', () => ({ showToast: vi.fn() }))

import { SpaceSettings } from './SpaceSettings'
import { api } from '@/api'

const apiMock = api as unknown as {
  get: ReturnType<typeof vi.fn>
  patch: ReturnType<typeof vi.fn>
  delete: ReturnType<typeof vi.fn>
}

function makeSpace(overrides: Partial<{
  retention_days: number | null
  features: object
}> = {}) {
  return {
    id: 's-1',
    name: 'Trip group',
    description: '',
    emoji: null,
    space_type: 'private' as const,
    join_mode: 'invite_only' as const,
    features: overrides.features ?? {
      calendar: true, todo: true, location: false,
      stickies: false, pages: true, gallery: true,
      posts_access: 'open', pages_access: 'open',
      stickies_access: 'open', calendar_access: 'open',
      tasks_access: 'open',
      allowed_post_types: ['text'],
    },
    retention_days: overrides.retention_days ?? null,
  } as never
}

describe('SpaceSettings', () => {
  beforeEach(() => {
    apiMock.get.mockResolvedValue([])
    apiMock.patch.mockReset()
  })

  it('module exports exist', async () => {
    const mod = await import('./SpaceSettings')
    expect(mod).toBeTruthy()
    expect(typeof mod.SpaceSettings).toBe('function')
  })

  it('renders the retention input prefilled with the space value', () => {
    const space = makeSpace({ retention_days: 30 })
    const { container } = render(
      <SpaceSettings space={space} onUpdate={() => {}} />,
    )
    const input = container.querySelector(
      'input[type="number"]',
    ) as HTMLInputElement | null
    expect(input).toBeTruthy()
    expect(input!.value).toBe('30')
  })

  it('sends retention_days in the PATCH on save', async () => {
    apiMock.patch.mockResolvedValueOnce({})
    const space = makeSpace({ retention_days: null })
    const { container, getByText } = render(
      <SpaceSettings space={space} onUpdate={() => {}} />,
    )
    const input = container.querySelector(
      'input[type="number"]',
    ) as HTMLInputElement
    fireEvent.input(input, { target: { value: '90' } })
    fireEvent.click(getByText('Save changes'))
    await new Promise(r => setTimeout(r, 0))
    expect(apiMock.patch).toHaveBeenCalledOnce()
    const [, body] = apiMock.patch.mock.calls[0]
    expect(body.retention_days).toBe(90)
  })

  it('sends 0 for retention_days when the field is cleared (= forever)', async () => {
    apiMock.patch.mockResolvedValueOnce({})
    const space = makeSpace({ retention_days: 90 })
    const { container, getByText } = render(
      <SpaceSettings space={space} onUpdate={() => {}} />,
    )
    const input = container.querySelector(
      'input[type="number"]',
    ) as HTMLInputElement
    fireEvent.input(input, { target: { value: '' } })
    fireEvent.click(getByText('Save changes'))
    await new Promise(r => setTimeout(r, 0))
    const [, body] = apiMock.patch.mock.calls[0]
    expect(body.retention_days).toBe(0)
  })

  it('renders the Features fieldset with five toggle checkboxes', () => {
    const space = makeSpace()
    const { getByTestId } = render(
      <SpaceSettings space={space} onUpdate={() => {}} />,
    )
    const fieldset = getByTestId('space-features')
    const checkboxes = fieldset.querySelectorAll('input[type="checkbox"]')
    expect(checkboxes.length).toBe(5)
  })

  it('mirrors the space features in the Features fieldset', () => {
    const space = makeSpace({
      features: {
        calendar: false, todo: true, location: false,
        stickies: true, pages: false, gallery: true,
        posts_access: 'open', pages_access: 'open',
        stickies_access: 'open', calendar_access: 'open',
        tasks_access: 'open',
      },
    })
    const { getByTestId } = render(
      <SpaceSettings space={space} onUpdate={() => {}} />,
    )
    const fieldset = getByTestId('space-features')
    const checkboxes = Array.from(
      fieldset.querySelectorAll('input[type="checkbox"]'),
    ) as HTMLInputElement[]
    // Order matches the JSX: pages, calendar, tasks, stickies, gallery.
    expect(checkboxes.map((c) => c.checked)).toEqual([
      false, false, true, true, true,
    ])
  })

  it('defaults Features toggles ON for a space whose features payload omits the keys', () => {
    const space = makeSpace({
      features: {
        // Empty-ish payload — simulates an upstream that doesn't
        // surface the per-space feature flags. The SpaceFeatures
        // dataclass default on the backend is all-on (except
        // location, which is an opt-in privacy contract); the SPA
        // mirrors that.
        location: false,
        posts_access: 'open', pages_access: 'open',
        stickies_access: 'open', calendar_access: 'open',
        tasks_access: 'open',
      },
    })
    const { getByTestId } = render(
      <SpaceSettings space={space} onUpdate={() => {}} />,
    )
    const fieldset = getByTestId('space-features')
    const checkboxes = Array.from(
      fieldset.querySelectorAll('input[type="checkbox"]'),
    ) as HTMLInputElement[]
    // pages, calendar, tasks, stickies, gallery — all on.
    expect(checkboxes.map((c) => c.checked)).toEqual([true, true, true, true, true])
  })

  it('sends all five feature toggles in the PATCH body on save', async () => {
    apiMock.patch.mockResolvedValueOnce({})
    const space = makeSpace()
    const { getByTestId, getByText } = render(
      <SpaceSettings space={space} onUpdate={() => {}} />,
    )
    const fieldset = getByTestId('space-features')
    const checkboxes = Array.from(
      fieldset.querySelectorAll('input[type="checkbox"]'),
    ) as HTMLInputElement[]
    // Flip pages OFF (was true) and gallery OFF (was true).
    fireEvent.change(checkboxes[0], { target: { checked: false } })
    fireEvent.change(checkboxes[4], { target: { checked: false } })
    fireEvent.click(getByText('Save changes'))
    await new Promise(r => setTimeout(r, 0))
    expect(apiMock.patch).toHaveBeenCalledOnce()
    const [, body] = apiMock.patch.mock.calls[0]
    expect(body.features.pages).toBe(false)
    expect(body.features.calendar).toBe(true)
    expect(body.features.todo).toBe(true)
    expect(body.features.stickies).toBe(false)
    expect(body.features.gallery).toBe(false)
  })

  it('defaults gallery=true for a pre-migration space whose features lack the key', async () => {
    apiMock.patch.mockResolvedValueOnce({})
    const space = makeSpace({
      features: {
        // No ``gallery`` key — simulates a row that pre-dates the
        // 0008 migration. The dataclass default on the backend is
        // True; the SPA mirrors that so existing spaces still expose
        // the gallery toggle as on.
        calendar: false, todo: true, location: false,
        stickies: false, pages: true,
        posts_access: 'open', pages_access: 'open',
        stickies_access: 'open', calendar_access: 'open',
        tasks_access: 'open',
      },
    })
    const { getByTestId, getByText } = render(
      <SpaceSettings space={space} onUpdate={() => {}} />,
    )
    const fieldset = getByTestId('space-features')
    const checkboxes = Array.from(
      fieldset.querySelectorAll('input[type="checkbox"]'),
    ) as HTMLInputElement[]
    // Gallery is the 5th checkbox — should default to checked.
    expect(checkboxes[4].checked).toBe(true)
    fireEvent.click(getByText('Save changes'))
    await new Promise(r => setTimeout(r, 0))
    const [, body] = apiMock.patch.mock.calls[0]
    expect(body.features.gallery).toBe(true)
  })

  it('preserves typed name across re-renders triggered by sibling state', async () => {
    // Regression for the signal-in-render footgun: previously the
    // form rebuilt fresh ``signal()`` instances on every render, so
    // typing into ``name`` and then triggering a render via a sibling
    // change (e.g. toggling location-sharing) silently dropped the
    // typed value back to the prop default. ``useSignal`` keeps the
    // instance stable; this test guards that invariant.
    apiMock.patch.mockResolvedValueOnce({})
    const space = makeSpace()
    const { container, getByText } = render(
      <SpaceSettings space={space} onUpdate={() => {}} />,
    )
    // Name input is the first ``<input>`` in the form (no ``type``
    // attribute — defaults to ``text``).
    const nameInput = container.querySelector(
      '.sh-form input',
    ) as HTMLInputElement
    expect(nameInput).toBeTruthy()
    fireEvent.input(nameInput, { target: { value: 'New name' } })
    // Trigger a re-render by toggling the location checkbox.
    const checkbox = container.querySelector(
      'input[type="checkbox"]',
    ) as HTMLInputElement
    fireEvent.change(checkbox, { target: { checked: true } })
    fireEvent.click(getByText('Save changes'))
    await new Promise(r => setTimeout(r, 0))
    const [, body] = apiMock.patch.mock.calls[0]
    expect(body.name).toBe('New name')
  })
})
