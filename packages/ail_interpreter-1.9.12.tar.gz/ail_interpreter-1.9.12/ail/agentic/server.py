"""Minimal HTTP server for an agentic AIL project.

POST /  with raw text body  →  runs entry main(input=body), returns the value.
GET  /healthz                →  200 ok.

Uses Python's stdlib `http.server`. Not production-grade; v0 is meant
for local development and small-traffic demos. Production hardening
(concurrency, timeouts, auth) is L2 v1+ work.
"""
from __future__ import annotations

import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Optional

from .. import run as ail_run
from .agent import _looks_like_error
from .project import Project


def _render_value(value):
    """Format an entry main() return value for HTTP response.

    AIL programs that signal success-or-error with Result return a dict
    shape; collapse it to the inner value (or error message) so HTTP
    clients see plain text instead of language internals.
    """
    if isinstance(value, dict) and value.get("_result"):
        if value.get("ok"):
            return value.get("value", "")
        return value.get("error", "error")
    if isinstance(value, str) and value.startswith("UNWRAP_ERROR:"):
        # Surface the inner message without the runtime sentinel prefix.
        return value[len("UNWRAP_ERROR:"):].strip()
    return value


def _looks_like_html(value) -> bool:
    """True if the rendered value opens with an HTML document or fragment.

    Used to decide between `text/plain` and `text/html` on the response.
    Keep the check cheap and precise: the first non-whitespace characters
    must be `<!doctype` (case-insensitive), `<html`, or a tag-like token
    `<word`. Anything else — JSON, numbers, prose that happens to contain
    `<3` — stays plain text.
    """
    if not isinstance(value, str):
        return False
    s = value.lstrip()
    if not s.startswith("<"):
        return False
    head = s[:16].lower()
    if head.startswith("<!doctype") or head.startswith("<html"):
        return True
    # Bare fragment like "<div>..." or "<ul>..." — first char after `<`
    # must start a tag name (letter). Rules out `<3`, `< 5`, `<-- ...`.
    return len(s) >= 2 and s[1].isalpha()


def _make_handler(project: Project):
    """Build a request handler closed over a specific Project. Done as
    a factory so each project can have its own handler without globals."""

    class _Handler(BaseHTTPRequestHandler):
        # Suppress default per-request stderr logging — we record to ledger.
        def log_message(self, fmt, *args):  # noqa: N802 — stdlib name
            return

        def do_GET(self):  # noqa: N802 — stdlib name
            if self.path in ("/healthz", "/health"):
                body = b"ok\n"
                self.send_response(200)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            if self.path in ("/", ""):
                # Render the browser UI so a non-developer can type
                # into a textarea instead of running curl.
                from .web_ui import render_page, extract_preamble, entry_uses_input
                try:
                    intent_text = project.intent_path.read_text(encoding="utf-8")
                except Exception:
                    intent_text = ""
                try:
                    app_source = project.app_path.read_text(encoding="utf-8")
                except Exception:
                    app_source = ""
                html = render_page(
                    project_name=project.root.name,
                    intent_preamble=extract_preamble(intent_text),
                    host=self.server.server_address[0],
                    port=self.server.server_address[1],
                    input_used=entry_uses_input(app_source),
                )
                body = html.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                # Don't cache — INTENT.md edits should show on next load.
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)
                return
            self._send_text(404, "POST / with the input as the body, "
                                 "or open / in a browser.\n")

        def do_POST(self):  # noqa: N802 — stdlib name
            if self.path != "/":
                self._send_text(404, "POST / only\n")
                return
            length = int(self.headers.get("Content-Length", "0") or "0")
            body = self.rfile.read(length).decode("utf-8") if length else ""

            try:
                result, _trace = ail_run(str(project.app_path), input=body)
                value = result.value
                if _looks_like_error(value):
                    rendered = _render_value(value)
                    project.append_ledger({
                        "event": "request",
                        "path": "/",
                        "input_chars": len(body),
                        "ok": False,
                        "value_preview": str(rendered)[:200],
                    })
                    self._send_text(500, str(rendered) + "\n")
                    return
                rendered = _render_value(value)
                is_html = _looks_like_html(rendered)
                # HTML responses go out byte-exact (no trailing newline)
                # so the browser doesn't see stray whitespace before
                # <!doctype>. Plain text keeps the terminal-friendly \n.
                if is_html:
                    response = str(rendered).encode("utf-8")
                    content_type = "text/html; charset=utf-8"
                else:
                    response = (str(rendered) + "\n").encode("utf-8")
                    content_type = "text/plain; charset=utf-8"
                project.append_ledger({
                    "event": "request",
                    "path": "/",
                    "input_chars": len(body),
                    "ok": True,
                    "output_mode": "html" if is_html else "text",
                    "value_preview": str(value)[:200],
                })
                self.send_response(200)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(response)))
                self.end_headers()
                self.wfile.write(response)
            except Exception as e:
                err = f"{type(e).__name__}: {e}"
                project.append_ledger({
                    "event": "request",
                    "path": "/",
                    "input_chars": len(body),
                    "ok": False,
                    "error": err,
                })
                self._send_text(500, err + "\n")

        def _send_text(self, code: int, text: str) -> None:
            body = text.encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    return _Handler


def serve_project(
    project: Project, *, port: int, host: str = "127.0.0.1",
    watch: bool = True, logger=None,
) -> int:
    # Make `perform state.read/write/has/delete` resolve to this
    # project's .ail/state/keyval/ — outside an agentic context the
    # state effects return an explanatory error instead of crashing.
    import os as _os
    keyval_dir = project.state_dir / "state" / "keyval"
    keyval_dir.mkdir(parents=True, exist_ok=True)
    _os.environ.setdefault("AIL_STATE_DIR", str(keyval_dir))
    # `perform schedule.every(N)` writes to this file; the Scheduler
    # below polls it and drives recurring entry invocations.
    schedule_file = project.state_dir / "schedule.json"
    _os.environ.setdefault("AIL_SCHEDULE_FILE", str(schedule_file))
    """Block, serving the project until SIGINT. Returns exit code.

    If `watch` is True (default), a background thread polls INTENT.md
    and app.ail for edits and re-runs the declared tests on change.
    The HTTP server reads app.ail fresh on every request so the swap
    is automatic; the watcher's job is just to revalidate and warn.
    """
    from .ui import make_logger
    logger = logger or make_logger("friendly")
    handler = _make_handler(project)
    try:
        server = HTTPServer((host, port), handler)
    except OSError as e:
        logger.port_bind_failed(host, port, str(e))
        return 3

    watcher = None
    if watch:
        from .watcher import Watcher
        watcher = Watcher(project, logger=logger)
        watcher.start()
        logger.watcher_watching()

    # Start the scheduler unconditionally — if the program never calls
    # `perform schedule.every(...)`, the file stays absent and the
    # scheduler thread idles at ~0.5s polls, cheap enough to ignore.
    from .scheduler import Scheduler

    def _invoke_scheduled_tick():
        try:
            result, _trace = ail_run(str(project.app_path), input="")
            value = result.value
            if _looks_like_error(value):
                project.append_ledger({
                    "event": "schedule_tick",
                    "ok": False,
                    "value_preview": str(_render_value(value))[:200],
                })
            else:
                project.append_ledger({
                    "event": "schedule_tick",
                    "ok": True,
                    "value_preview": str(value)[:200],
                })
        except Exception as e:
            project.append_ledger({
                "event": "schedule_tick",
                "ok": False,
                "error": f"{type(e).__name__}: {e}",
            })

    scheduler = Scheduler(
        schedule_file=schedule_file,
        invoke=_invoke_scheduled_tick,
        logger=logger,
    )
    scheduler.start()

    project.append_ledger({
        "event": "serve_start", "host": host, "port": port, "watch": watch,
    })
    logger.serving(host, port)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        logger.shutting_down()
    finally:
        scheduler.stop()
        if watcher is not None:
            watcher.stop()
        server.server_close()
        project.append_ledger({"event": "serve_stop"})
    return 0
