import time
from typing import Optional

import keyring
import pyperclip

KEYRING_SERVICE = "prosperity4submitter"
KEYRING_USERNAME = "prosperity-id-token"


def validate_token(token: str) -> bool:
    if len(token) != 1132:
        print(f"ERROR: Token has invalid length ({len(token)}), expected 1132.")
        return False

    bad_chars = [ch for ch in token if ord(ch) not in range(256)]

    if len(bad_chars) > 0:
        print(f"ERROR: Token contains invalid character(s): {', '.join(bad_chars)}")
        return False

    return True


def retrieve_token(retries: int = 3) -> Optional[str]:
    try:
        # keyring.get_password() occasionally fails for no apparent reason, retrying usually fixes it
        token = keyring.get_password(KEYRING_SERVICE, KEYRING_USERNAME)

        if token is not None and not validate_token(token):
            return None

        return token
    except Exception:
        if retries <= 0:
            raise

        time.sleep(1)
        return retrieve_token(retries - 1)


def refresh_token_from_clipboard() -> bool:
    token = str(pyperclip.paste())
    if not validate_token(token):
        return False

    keyring.set_password(KEYRING_SERVICE, KEYRING_USERNAME, token)
    return True
