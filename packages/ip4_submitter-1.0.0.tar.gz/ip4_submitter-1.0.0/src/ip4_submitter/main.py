from datetime import datetime, timezone
from pathlib import Path
from typing import Annotated, Any

import typer
from rich.console import Console
from rich.table import Table
from typer import Argument, Option, Typer

from ip4_submitter.api import (
    MaintenanceError,
    NoOpenRoundError,
    RateLimitError,
    TokenExpiredError,
    TokenMissingError,
    format_path,
    get_open_round,
    get_submission_status,
    get_submissions_per_round,
    monitor_status,
    post_algorithm,
    save_logs,
)
from ip4_submitter.credentials import refresh_token_from_clipboard

app = Typer(
    help="CLI tool for submitting and backtesting algorithms for the IMC Prosperity 4 competition.",
    rich_markup_mode="rich",
)
console = Console()


def handle_api_error(e: Exception) -> None:
    """Print a styled error message for known API exceptions and exit."""
    if isinstance(e, TokenMissingError):
        console.print(
            "[bold red]No token found.[/bold red] Run [green]ip4submitter auth[/green] to authenticate."
        )
    elif isinstance(e, TokenExpiredError):
        console.print(
            "[bold red]Token expired or invalid.[/bold red] Run [green]ip4submitter auth[/green] to refresh."
        )
    elif isinstance(e, RateLimitError):
        console.print(
            "[bold red]Rate limited (429):[/bold red] another algorithm is currently simulating, "
            "or you must wait 10 minutes between submissions."
        )
    elif isinstance(e, MaintenanceError):
        console.print(
            "[bold red]Prosperity is in maintenance mode.[/bold red] Please try again later."
        )
    elif isinstance(e, NoOpenRoundError):
        console.print("[bold red]No round is currently accepting submissions.")
    else:
        console.print(f"[bold red]Unexpected error:[/bold red] {e}")
    raise typer.Exit(1)


GUIDE_TEXT = """\
[bold cyan]ip4submitter[/bold cyan] — CLI for IMC Prosperity 4 submissions

[bold]Getting Started[/bold]
[dim]────────────────────────────────────────────────[/dim]

  [bold]1.[/bold] Authenticate — copy your token to the clipboard, then run:

     [green]ip4submitter auth[/green]

     Your token is stored securely in the system keyring.

  [bold]2.[/bold] Submit an algorithm:

     [green]ip4submitter submit algo.py[/green]

     This uploads your file, waits for the backtest to finish,
     and saves the result log to [cyan]submissions/<id>.log[/cyan].

[bold]Commands[/bold]
[dim]────────────────────────────────────────────────[/dim]

  [green]auth[/green]                          Save your session token
  [green]submit[/green] [dim]<filepath>[/dim]             Submit an algorithm and download results
  [green]history[/green]                       List all submissions for the current round
  [green]download[/green]                      Download logs for a past submission
  [green]guide[/green]                         Show this guide

[bold]Examples[/bold]
[dim]────────────────────────────────────────────────[/dim]

  [dim]# Authenticate (token must be on clipboard)[/dim]
  [green]ip4submitter auth[/green]

  [dim]# Submit and wait for results[/dim]
  [green]ip4submitter submit my_algo.py[/green]

  [dim]# Submit and save logs to a custom directory[/dim]
  [green]ip4submitter submit my_algo.py --output results/[/green]

  [dim]# View submission history[/dim]
  [green]ip4submitter history[/green]

  [dim]# Download the most recent submission's logs[/dim]
  [green]ip4submitter download[/green]

  [dim]# Download a specific submission by ID[/dim]
  [green]ip4submitter download --id 46284[/green]

  [dim]# Download to a custom directory[/dim]
  [green]ip4submitter download --filepath results/[/green]

[bold]Authentication[/bold]
[dim]────────────────────────────────────────────────[/dim]

  [bold]Option A — Bookmarklet (recommended):[/bold]

    1. Create a browser bookmark with the bookmarklet URL
       (see the project README for the full snippet)
    2. Go to [bold]prosperity.imc.com[/bold] and log in
    3. Click the bookmark — your token is copied automatically
    4. Run [green]ip4submitter auth[/green]

  [bold]Option B — Manual extraction:[/bold]

    1. Go to [bold]prosperity.imc.com[/bold] and log in
    2. Press [bold]F12[/bold] to open developer tools
    3. Open the [italic]Application[/italic] tab (Chrome) or [italic]Storage[/italic] tab (Firefox)
    4. Select [italic]Local Storage[/italic] -> the Prosperity site
    5. Copy the value for key
       [dim italic]CognitoIdentityServiceProvider.<id>.<email>.idToken[/dim italic]
    6. Run [green]ip4submitter auth[/green]

[bold]Troubleshooting[/bold]
[dim]────────────────────────────────────────────────[/dim]

  [bold red]Token expired or invalid[/bold red]
    Re-run [green]ip4submitter auth[/green] with a fresh token.

  [bold red]Rate limited (429)[/bold red]
    Another algorithm is simulating, or you need to wait
    10 minutes between submissions.

  [bold red]Prosperity is in maintenance mode[/bold red]
    The platform is temporarily down. Try again later.
"""


@app.command()
def guide():
    """Prints a detailed usage guide."""
    console.print(GUIDE_TEXT)


@app.command()
def auth() -> None:
    """Save your Prosperity session [bold cyan]id_token[/bold cyan].

    Reads your token from the clipboard and stores it in your system keyring
    for use in all future commands.

    [bold]Option A — Bookmarklet (recommended):[/bold]

    [dim]1.[/dim] Create a browser bookmark with the bookmarklet URL
       [dim](see the project README for the full snippet)[/dim]
    [dim]2.[/dim] Go to [bold]prosperity.imc.com[/bold] and log in
    [dim]3.[/dim] Click the bookmark — your token is copied automatically
    [dim]4.[/dim] Run [green]ip4submitter auth[/green]

    [bold]Option B — Manual extraction:[/bold]

    [dim]1.[/dim] Go to [bold]prosperity.imc.com[/bold] and log in
    [dim]2.[/dim] Press [bold]F12[/bold] to open developer tools
    [dim]3.[/dim] Open the [italic]Application[/italic] tab (Chrome) or [italic]Storage[/italic] tab (Firefox)
    [dim]4.[/dim] Select [italic]Local Storage[/italic] → the Prosperity site
    [dim]5.[/dim] Copy the value for key
       [dim italic]CognitoIdentityServiceProvider.<id>.<email>.idToken[/dim italic]
    [dim]6.[/dim] Run [green]ip4submitter auth[/green]
    """
    if refresh_token_from_clipboard():
        console.print("[bold green]Token saved successfully.")
    else:
        console.print("[bold red]Failed to save token.")
        raise typer.Exit(1)


@app.command()
def submit(
    filepath: Annotated[Path, Argument(help="The algorithm to submit")],
    output: Annotated[
        Path | None,
        Option(
            help="Directory to save the log file. Defaults to the submissions folder."
        ),
    ] = None,
):
    """Submit your algorithm to the Prosperity backtester.

    Submits the algorithm at FILEPATH to the Prosperity platform and streams back results.
    Requires a saved token — run `ip4submitter auth` first if you haven't already.
    """
    if not filepath.exists():
        console.print(f"[bold red]File not found: {filepath}")
        raise typer.Exit(1)

    try:
        with console.status("[bold cyan]Retrieving current round..."):
            round_id = get_open_round()
        console.print(f"[green]Round [bold]{round_id}[/bold] is open")

        known_ids = {s["id"] for s in get_submissions_per_round(round_id)}

        console.print(f"[cyan]Submitting [bold]{format_path(filepath)}")
        post_algorithm(filepath)

        with console.status("[bold cyan]Waiting for submission...") as spinner:
            data = monitor_status(
                round_id,
                known_ids,
                on_status_change=lambda s: spinner.update(f"[bold cyan]Status: {s}"),
            )

        if data["status"] == "FINISHED":
            console.print("[bold green]Submission finished")
        else:
            console.print(f"[bold red]Submission failed: {data['status']}")

        output_dir = output if output is not None else Path("submissions")
        output_file = output_dir / f"{data['id']}.log"

        with console.status("[bold cyan]Downloading logs..."):
            save_logs(data, output_file)
        console.print(f"[green]Saved to [bold]{format_path(output_file)}")
    except (
        TokenMissingError,
        TokenExpiredError,
        RateLimitError,
        MaintenanceError,
        NoOpenRoundError,
    ) as e:
        handle_api_error(e)


@app.command()
def history():
    """List all previous algorithm submissions in a table."""
    try:
        with console.status("[bold cyan]Retrieving current round..."):
            round_id = get_open_round()
        console.print(f"[green]Round [bold]{round_id}[/bold] is open")

        submissions = get_submissions_per_round(round_id)
    except (
        TokenMissingError,
        TokenExpiredError,
        RateLimitError,
        MaintenanceError,
        NoOpenRoundError,
    ) as e:
        handle_api_error(e)

    if not submissions:
        console.print("[dim]No submissions found for the current round.")
        return

    table = Table(title="Submission History", title_style="bold cyan")
    table.add_column("ID", style="dim", justify="right")
    table.add_column("File")
    table.add_column("Submitted (UTC)")
    table.add_column("Status")

    for sub in submissions:
        submitted_at = datetime.fromisoformat(sub["submittedAt"].replace("Z", "+00:00"))
        submitted_str = submitted_at.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M")

        status = get_submission_status(sub)
        if sub["status"] == "FINISHED":
            status_markup = f"[green]{status}[/green]"
        elif "ERROR" in sub["status"]:
            status_markup = f"[red]{status}[/red]"
        else:
            status_markup = f"[yellow]{status}[/yellow]"

        table.add_row(str(sub["id"]), sub["filename"], submitted_str, status_markup)

    console.print(table)


@app.command()
def download(
    id: Annotated[
        str | None,
        Option(
            help="ID of the submission to download. Defaults to the most recent submission."
        ),
    ] = None,
    filepath: Annotated[
        Path | None,
        Option(
            help="Directory to save the log file. Defaults to the current directory."
        ),
    ] = None,
):
    """Download a previous submission by ID.

    If ID is provided, downloads that specific submission.
    If no ID is provided, downloads the most recent submission.
    """
    try:
        with console.status("[bold cyan]Retrieving current round..."):
            round_id = get_open_round()
        console.print(f"[green]Round [bold]{round_id}[/bold] is open")

        submissions = get_submissions_per_round(round_id)
    except (
        TokenMissingError,
        TokenExpiredError,
        RateLimitError,
        MaintenanceError,
        NoOpenRoundError,
    ) as e:
        handle_api_error(e)

    if not submissions:
        console.print("[bold red]No submissions found for the current round.")
        raise typer.Exit(1)

    if id is not None:
        data = next((s for s in submissions if str(s["id"]) == id), None)
        if data is None:
            console.print(f"[bold red]No submission found with ID {id}.")
            raise typer.Exit(1)
    else:
        data = submissions[0]

    output_dir = filepath if filepath is not None else Path("submissions")
    output_file = output_dir / f"{data['id']}.log"

    try:
        with console.status("[bold cyan]Downloading logs..."):
            save_logs(data, output_file)
        console.print(f"[green]Saved to [bold]{format_path(output_file)}")
    except (
        TokenMissingError,
        TokenExpiredError,
        RateLimitError,
        MaintenanceError,
    ) as e:
        handle_api_error(e)


if __name__ == "__main__":
    app()
