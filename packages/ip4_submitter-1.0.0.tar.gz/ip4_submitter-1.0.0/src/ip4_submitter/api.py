import io
import time
import zipfile
from pathlib import Path
from typing import Any, Callable, Optional

import requests
from requests_toolbelt import MultipartEncoder

from ip4_submitter.credentials import retrieve_token

BASE_URL = "https://3dzqiahkw1.execute-api.eu-west-1.amazonaws.com/prod"


# Exceptions
class TokenMissingError(Exception):
    """No token found in keyring."""


class TokenExpiredError(Exception):
    """Token is expired or invalid (401/403)."""


class RateLimitError(Exception):
    """Rate limited by the API (429)."""


class MaintenanceError(Exception):
    """Prosperity is in maintenance mode (503)."""


class NoOpenRoundError(Exception):
    """No round is currently accepting submissions."""


# Low-level HTTP
def request_with_token(
    method: str, url: str, form_data: Optional[dict[str, Any]] = None, attempt: int = 0
) -> requests.Response:
    token = retrieve_token()

    if token is None:
        raise TokenMissingError()

    data = None
    headers: dict[str, str] = {"Authorization": f"Bearer {token}"}

    if form_data is not None:
        encoder = MultipartEncoder(form_data)
        data = encoder
        headers["content-type"] = encoder.content_type

    response = requests.request(method, url, data=data, headers=headers)

    if response.status_code == 429:
        raise RateLimitError()

    if response.status_code in [401, 403]:
        raise TokenExpiredError()

    if response.status_code == 503:
        raise MaintenanceError()

    if 500 <= response.status_code < 600:
        if attempt < 3:
            time.sleep(5)
            return request_with_token(method, url, form_data, attempt + 1)
        response.raise_for_status()

    response.raise_for_status()
    return response


# API access functions
def get_round_data() -> list[dict[str, Any]]:
    """Get all available rounds."""
    data: Any = request_with_token("GET", f"{BASE_URL}/rounds").json()
    return data.get("data", {}).get("rounds", data if isinstance(data, list) else [])


def get_submissions_per_round(round_id: str) -> list[dict[str, Any]]:
    """Get all submissions for a given round."""
    data: Any = request_with_token(
        "GET", f"{BASE_URL}/submissions/algo/{round_id}"
    ).json()
    return data.get("data", {}).get("items", data if isinstance(data, list) else [])


def get_log_url(submission_id: str) -> str:
    """Get presigned download URL for a submission's logs."""
    data: Any = request_with_token(
        "GET", f"{BASE_URL}/submissions/algo/{submission_id}/zip"
    ).json()
    return data.get("data", {}).get("url", data if isinstance(data, list) else [])


def download_zip(url: str, output_path: Path) -> None:
    """Download a zip file from a URL and extract the .log file to output_path."""
    response = requests.get(url, timeout=60)
    response.raise_for_status()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(io.BytesIO(response.content)) as zf:
        log_name = next(n for n in zf.namelist() if n.endswith(".log"))
        output_path.write_bytes(zf.read(log_name))


def post_algorithm(algorithm_file: Path) -> None:
    """Submit an algorithm file to the Prosperity backtester."""
    request_with_token(
        "POST",
        f"{BASE_URL}/submission/algo",
        {"file": (algorithm_file.name, algorithm_file.read_bytes(), "text/x-python")},
    )


# Higher-level functions
def get_open_round() -> str:
    """Return the ID of the currently open round."""
    rounds = get_round_data()
    open_round = next((r for r in rounds if r["isActive"]), None)
    if open_round is None:
        raise NoOpenRoundError()
    return open_round["id"]


def get_submission_status(data: dict[str, Any]) -> str:
    """Format a submission's status string."""
    status = data["status"]
    if data.get("active"):
        status += " (active)"
    return status


def monitor_status(
    round_id: str,
    known_ids: set[int],
    on_status_change: Optional[Callable[[str], None]] = None,
) -> dict[str, Any]:
    """Poll until a new submission reaches FINISHED or ERROR status."""
    while True:
        algorithms = get_submissions_per_round(round_id)
        new = [a for a in algorithms if a["id"] not in known_ids]
        if new:
            data = new[0]
            break
        time.sleep(2)

    status = get_submission_status(data)
    if on_status_change:
        on_status_change(status)

    while data["status"] != "FINISHED" and "ERROR" not in data["status"]:
        time.sleep(0 if data.get("active") else 5)
        algorithms = get_submissions_per_round(round_id)
        data = next(a for a in algorithms if a["id"] == data["id"])

        new_status = get_submission_status(data)
        if new_status != status:
            status = new_status
            if on_status_change:
                on_status_change(status)

    return data


def save_logs(submission: dict[str, Any], output_file: Path) -> None:
    """Download and extract logs for a submission."""
    url = get_log_url(submission["id"])
    download_zip(url, output_file)


# Helper functions
def format_path(path: Path) -> str:
    cwd = Path.cwd()
    return str(path.relative_to(cwd)) if path.is_relative_to(cwd) else str(path)
