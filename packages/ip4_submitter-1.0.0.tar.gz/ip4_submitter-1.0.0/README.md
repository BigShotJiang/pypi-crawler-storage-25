# ip4-submitter
CLI submitter tool for prosperity

## Getting your ID token

Copy your Prosperity ID token to your clipboard, then run `ip4submitter auth`. The token will be read from your clipboard automatically and saved to your system's credentials store (macOS Keychain, Windows Credential Manager, or Linux secret store) for use in future commands.

**Bookmarklet (easiest method):** Create a new browser bookmark and set its URL to:

```
javascript:void function(){if("prosperity.imc.com"!==window.location.hostname)alert("This bookmarklet should only be used on prosperity.imc.com");else{const c=document.cookie.split(";").map(c=>c.trim()).find(c=>/\.idToken=/.test(c));c===undefined?alert("ID token not found, are you sure you are logged in?"):(navigator.clipboard.writeText(c.split("=").slice(1).join("=")),alert("Successfully copied ID token to clipboard!"))}}();
```

Navigate to [prosperity.imc.com](https://prosperity.imc.com) while logged in, click the bookmark, and your token will be copied to your clipboard automatically.

**Manual method:** Press F12 on prosperity.imc.com to open developer tools, go to the Application (Chrome) or Storage (Firefox) tab, click Local Storage in the sidebar, and find the key matching `CognitoIdentityServiceProvider.<id>.<email>.idToken`.
