"""Agent manager for coordinating multiple AI agents with shared message history."""

import base64
import json
import logging
from collections.abc import AsyncIterable, Sequence
from dataclasses import dataclass, field, is_dataclass, replace
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

import logfire
from pydantic_ai import (
    BinaryContent,
    RunContext,
    UsageLimits,
)
from pydantic_ai.agent import AgentRunResult
from pydantic_ai.messages import (
    AgentStreamEvent,
    FinalResultEvent,
    FunctionToolCallEvent,
    FunctionToolResultEvent,
    ModelMessage,
    ModelRequest,
    ModelRequestPart,
    ModelResponse,
    ModelResponsePart,
    PartDeltaEvent,
    PartStartEvent,
    SystemPromptPart,
    TextPartDelta,
    ToolCallPart,
    ToolCallPartDelta,
    UserContent,
    UserPromptPart,
)
from tenacity import (
    before_sleep_log,
    retry,
    retry_if_exception,
    stop_after_attempt,
    wait_exponential,
)
from textual.message import Message
from textual.widget import Widget

from shotgun.agents.cancellation import CancellableStreamIterator
from shotgun.agents.common import add_system_prompt_message, add_system_status_message
from shotgun.agents.config.models import (
    KeyProvider,
    ModelConfig,
    ModelName,
    ProviderType,
)
from shotgun.agents.config.tier_detection import (
    AnthropicTier,
    get_configured_anthropic_tier,
)
from shotgun.agents.constants import (
    IMAGE_EXTENSIONS,
    MAX_BINARY_FILE_SIZE_BYTES,
    MAX_TEXT_FILE_SIZE_BYTES,
    FileContent,
    get_mime_type,
    is_binary_extension,
    is_text_extension,
)
from shotgun.agents.context_analyzer import (
    ContextAnalysis,
    ContextAnalyzer,
    ContextCompositionTelemetry,
    ContextFormatter,
)
from shotgun.agents.conversation.filters import (
    filter_incomplete_messages,
    filter_orphaned_tool_responses,
)
from shotgun.agents.models import (
    AgentResponse,
    AgentType,
    AnyAgent,
    FileOperation,
    FileOperationTracker,
    RouterAgent,
    ShotgunAgent,
)
from shotgun.attachments import FileAttachment
from shotgun.exceptions import IncompleteToolCallError
from shotgun.posthog_telemetry import flush as flush_telemetry
from shotgun.posthog_telemetry import track_event
from shotgun.tui.screens.chat_screen.hint_message import HintMessage
from shotgun.tui.screens.chat_screen.welcome_message import WelcomeMessage
from shotgun.utils.source_detection import detect_source

from .conversation.history.compaction import apply_persistent_compaction
from .conversation.history.constants import MAX_UI_HISTORY_MESSAGES
from .export import create_export_agent
from .messages import AgentSystemPrompt, InternalPromptPart
from .models import AgentDeps, AgentRuntimeOptions
from .plan import create_plan_agent
from .research import create_research_agent
from .router import create_router_agent
from .router.models import RouterDeps, RouterMode
from .specify import create_specify_agent
from .tasks import create_tasks_agent

if TYPE_CHECKING:
    from shotgun.agents.conversation import ConversationState

logger = logging.getLogger(__name__)


def _is_retryable_error(exception: BaseException) -> bool:
    """Check if exception should trigger a retry.

    Args:
        exception: The exception to check.

    Returns:
        True if the exception is a transient error that should be retried.
    """
    # ValueError for truncated/incomplete JSON
    if isinstance(exception, ValueError):
        error_str = str(exception)
        return "EOF while parsing" in error_str or (
            "JSON" in error_str and "parsing" in error_str
        )

    # API errors (overload, rate limits)
    exception_name = type(exception).__name__
    if "APIStatusError" in exception_name:
        error_str = str(exception)
        return "overload" in error_str.lower() or "rate" in error_str.lower()

    # Network errors
    if "ConnectionError" in exception_name or "TimeoutError" in exception_name:
        return True

    return False


class MessageHistoryUpdated(Message):
    """Event posted when the message history is updated."""

    def __init__(
        self,
        messages: list[ModelMessage | HintMessage | WelcomeMessage],
        agent_type: AgentType,
        file_operations: list[FileOperation] | None = None,
    ) -> None:
        """Initialize the message history updated event.

        Args:
            messages: The updated message history.
            agent_type: The type of agent that triggered the update.
            file_operations: List of file operations from this run.
        """
        super().__init__()
        self.messages = messages
        self.agent_type = agent_type
        self.file_operations = file_operations or []


class PartialResponseMessage(Message):
    """Event posted when a partial response is received."""

    def __init__(
        self,
        message: ModelResponse | None,
        messages: list[ModelMessage],
        is_last: bool,
    ) -> None:
        """Initialize the partial response message."""
        super().__init__()
        self.message = message
        self.messages = messages
        self.is_last = is_last


class ClarifyingQuestionsMessage(Message):
    """Event posted when agent returns clarifying questions."""

    def __init__(
        self,
        questions: list[str],
        response_text: str,
    ) -> None:
        """Initialize the clarifying questions message.

        Args:
            questions: List of clarifying questions from the agent
            response_text: The agent's response text before asking questions
        """
        super().__init__()
        self.questions = questions
        self.response_text = response_text


class FileRequestPendingMessage(Message):
    """Event posted when agent requests files to be loaded.

    This triggers the TUI to load the requested files and resume
    the agent with the file contents in the next prompt.
    """

    def __init__(
        self,
        file_paths: list[str],
        response_text: str,
    ) -> None:
        """Initialize the file request pending message.

        Args:
            file_paths: List of file paths the agent wants to read
            response_text: The agent's response text before requesting files
        """
        super().__init__()
        self.file_paths = file_paths
        self.response_text = response_text


class CompactionStartedMessage(Message):
    """Event posted when conversation compaction starts."""


class CompactionCompletedMessage(Message):
    """Event posted when conversation compaction completes."""


class ToolExecutionStartedMessage(Message):
    """Event posted when a tool starts executing.

    This allows the UI to update the spinner text to provide feedback
    during long-running tool executions.
    """

    def __init__(self, spinner_text: str = "Processing...") -> None:
        """Initialize the tool execution started message.

        Args:
            spinner_text: The spinner message to display
        """
        super().__init__()
        self.spinner_text = spinner_text


class ToolStreamingProgressMessage(Message):
    """Event posted during tool call streaming to show progress.

    This provides visual feedback while tool arguments are streaming,
    especially useful for long-running writes like file content.
    """

    def __init__(self, streamed_tokens: int, spinner_text: str) -> None:
        """Initialize the tool streaming progress message.

        Args:
            streamed_tokens: Approximate number of tokens streamed so far
            spinner_text: The current spinner message to preserve
        """
        super().__init__()
        self.streamed_tokens = streamed_tokens
        self.spinner_text = spinner_text


# Fun spinner messages to show during tool execution
SPINNER_MESSAGES = [
    "Pontificating...",
    "Ruminating...",
    "Cogitating...",
    "Deliberating...",
    "Contemplating...",
    "Reticulating splines...",
    "Consulting the oracle...",
    "Gathering thoughts...",
    "Processing neurons...",
    "Summoning wisdom...",
    "Brewing ideas...",
    "Polishing pixels...",
    "Herding electrons...",
    "Warming up the flux capacitor...",
    "Consulting ancient tomes...",
    "Channeling the muses...",
    "Percolating possibilities...",
    "Untangling complexity...",
    "Shuffling priorities...",
    "Aligning the stars...",
]


class AgentStreamingStarted(Message):
    """Event posted when agent starts streaming responses."""


class AgentStreamingCompleted(Message):
    """Event posted when agent finishes streaming responses."""


@dataclass(frozen=True)
class ModelConfigUpdated:
    """Data returned when AI model configuration changes.

    Used as a return value from ModelPickerScreen to communicate model
    selection back to the calling screen.

    Attributes:
        old_model: Previous model name (None if first selection)
        new_model: New model name (ModelName enum or string for OpenAI-compatible)
        provider: LLM provider (OpenAI, Anthropic, Google, OpenAI-compatible)
        key_provider: Authentication method (BYOK or Shotgun)
        model_config: Complete model configuration
    """

    old_model: ModelName | str | None  # String for Ollama/OpenAI-compatible models
    new_model: ModelName | str  # String for Ollama/OpenAI-compatible models
    provider: ProviderType
    key_provider: KeyProvider
    model_config: ModelConfig


@dataclass(slots=True)
class _PartialStreamState:
    """Tracks streamed messages while handling a single agent run."""

    messages: list[ModelRequest | ModelResponse] = field(default_factory=list)
    current_response: ModelResponse | None = None
    # Token counting for tool call streaming progress
    streamed_tokens: int = 0
    current_spinner_text: str = "Processing..."
    # Track last reported tokens to throttle UI updates
    last_reported_tokens: int = 0


class AgentManager(Widget):
    """Manages multiple agents with shared message history."""

    def __init__(
        self,
        deps: AgentDeps | None = None,
        initial_type: AgentType = AgentType.RESEARCH,
    ) -> None:
        """Initialize the agent manager.

        Args:
            deps: Optional agent dependencies. If not provided, defaults to interactive mode.
        """
        super().__init__()
        self.display = False

        if deps is None:
            raise ValueError("AgentDeps must be provided to AgentManager")

        # Use provided deps or create default with interactive mode
        self.deps = deps

        # Create AgentRuntimeOptions from deps for agent creation
        self._agent_runtime_options = AgentRuntimeOptions(
            interactive_mode=self.deps.interactive_mode,
            working_directory=self.deps.working_directory,
            is_tui_context=self.deps.is_tui_context,
            max_iterations=self.deps.max_iterations,
            queue=self.deps.queue,
            tasks=self.deps.tasks,
        )

        # Lazy initialization - agents created on first access
        self._research_agent: ShotgunAgent | None = None
        self._research_deps: AgentDeps | None = None
        self._plan_agent: ShotgunAgent | None = None
        self._plan_deps: AgentDeps | None = None
        self._tasks_agent: ShotgunAgent | None = None
        self._tasks_deps: AgentDeps | None = None
        self._specify_agent: ShotgunAgent | None = None
        self._specify_deps: AgentDeps | None = None
        self._export_agent: ShotgunAgent | None = None
        self._export_deps: AgentDeps | None = None
        self._router_agent: RouterAgent | None = None
        self._router_deps: RouterDeps | None = None
        self._agents_initialized = False

        # Track current active agent
        self._current_agent_type: AgentType = initial_type

        # Maintain shared message history
        self.ui_message_history: list[ModelMessage | HintMessage | WelcomeMessage] = []
        self.message_history: list[ModelMessage] = []
        self.recently_change_files: list[FileOperation] = []
        self._stream_state: _PartialStreamState | None = None

        # Q&A mode state for structured output questions
        self._qa_questions: list[str] | None = None
        self._qa_mode_active: bool = False

        # File request state for structured output file loading
        self._file_request_pending: bool = False
        self._pending_file_requests: list[str] = []

        # Sub-agent streaming responses to persist in UI history
        self._sub_agent_messages: list[ModelResponse] = []

        # Last backup path from pre-agent backup (displayed alongside file changes)
        self._last_backup_path: Path | None = None

    async def _ensure_agents_initialized(self) -> None:
        """Ensure all agents are initialized (lazy initialization)."""
        if self._agents_initialized:
            return

        # Initialize all agents asynchronously
        self._research_agent, self._research_deps = await create_research_agent(
            agent_runtime_options=self._agent_runtime_options
        )
        self._plan_agent, self._plan_deps = await create_plan_agent(
            agent_runtime_options=self._agent_runtime_options
        )
        self._tasks_agent, self._tasks_deps = await create_tasks_agent(
            agent_runtime_options=self._agent_runtime_options
        )
        self._specify_agent, self._specify_deps = await create_specify_agent(
            agent_runtime_options=self._agent_runtime_options
        )
        self._export_agent, self._export_deps = await create_export_agent(
            agent_runtime_options=self._agent_runtime_options
        )
        self._router_agent, self._router_deps = await create_router_agent(
            agent_runtime_options=self._agent_runtime_options
        )
        self._agents_initialized = True

    async def cleanup_agents(self) -> None:
        """Release all agent instances and their held resources."""
        if self._router_deps is not None:
            self._router_deps.sub_agent_cache.clear()
            self._router_deps.parent_stream_handler = None
            self._router_deps.on_plan_changed = None

        self._research_agent = None
        self._research_deps = None
        self._plan_agent = None
        self._plan_deps = None
        self._tasks_agent = None
        self._tasks_deps = None
        self._specify_agent = None
        self._specify_deps = None
        self._export_agent = None
        self._export_deps = None
        self._router_agent = None
        self._router_deps = None
        self._agents_initialized = False

    @property
    def research_agent(self) -> ShotgunAgent:
        """Get research agent (must call _ensure_agents_initialized first)."""
        if self._research_agent is None:
            raise RuntimeError(
                "Agents not initialized. Call _ensure_agents_initialized() first."
            )
        return self._research_agent

    @property
    def research_deps(self) -> AgentDeps:
        """Get research deps (must call _ensure_agents_initialized first)."""
        if self._research_deps is None:
            raise RuntimeError(
                "Agents not initialized. Call _ensure_agents_initialized() first."
            )
        return self._research_deps

    @property
    def plan_agent(self) -> ShotgunAgent:
        """Get plan agent (must call _ensure_agents_initialized first)."""
        if self._plan_agent is None:
            raise RuntimeError(
                "Agents not initialized. Call _ensure_agents_initialized() first."
            )
        return self._plan_agent

    @property
    def plan_deps(self) -> AgentDeps:
        """Get plan deps (must call _ensure_agents_initialized first)."""
        if self._plan_deps is None:
            raise RuntimeError(
                "Agents not initialized. Call _ensure_agents_initialized() first."
            )
        return self._plan_deps

    @property
    def tasks_agent(self) -> ShotgunAgent:
        """Get tasks agent (must call _ensure_agents_initialized first)."""
        if self._tasks_agent is None:
            raise RuntimeError(
                "Agents not initialized. Call _ensure_agents_initialized() first."
            )
        return self._tasks_agent

    @property
    def tasks_deps(self) -> AgentDeps:
        """Get tasks deps (must call _ensure_agents_initialized first)."""
        if self._tasks_deps is None:
            raise RuntimeError(
                "Agents not initialized. Call _ensure_agents_initialized() first."
            )
        return self._tasks_deps

    @property
    def specify_agent(self) -> ShotgunAgent:
        """Get specify agent (must call _ensure_agents_initialized first)."""
        if self._specify_agent is None:
            raise RuntimeError(
                "Agents not initialized. Call _ensure_agents_initialized() first."
            )
        return self._specify_agent

    @property
    def specify_deps(self) -> AgentDeps:
        """Get specify deps (must call _ensure_agents_initialized first)."""
        if self._specify_deps is None:
            raise RuntimeError(
                "Agents not initialized. Call _ensure_agents_initialized() first."
            )
        return self._specify_deps

    @property
    def export_agent(self) -> ShotgunAgent:
        """Get export agent (must call _ensure_agents_initialized first)."""
        if self._export_agent is None:
            raise RuntimeError(
                "Agents not initialized. Call _ensure_agents_initialized() first."
            )
        return self._export_agent

    @property
    def export_deps(self) -> AgentDeps:
        """Get export deps (must call _ensure_agents_initialized first)."""
        if self._export_deps is None:
            raise RuntimeError(
                "Agents not initialized. Call _ensure_agents_initialized() first."
            )
        return self._export_deps

    @property
    def router_agent(self) -> RouterAgent:
        """Get router agent (must call _ensure_agents_initialized first)."""
        if self._router_agent is None:
            raise RuntimeError(
                "Agents not initialized. Call _ensure_agents_initialized() first."
            )
        return self._router_agent

    @property
    def router_deps(self) -> RouterDeps:
        """Get router deps (must call _ensure_agents_initialized first)."""
        if self._router_deps is None:
            raise RuntimeError(
                "Agents not initialized. Call _ensure_agents_initialized() first."
            )
        return self._router_deps

    @property
    def current_agent(self) -> AnyAgent:
        """Get the currently active agent.

        Returns:
            The currently selected agent instance (ShotgunAgent or RouterAgent).
        """
        return self._get_agent(self._current_agent_type)

    @property
    def file_request_pending(self) -> bool:
        """Check if there's a pending file request."""
        return self._file_request_pending

    @property
    def pending_file_requests(self) -> list[str]:
        """Get the list of pending file requests."""
        return self._pending_file_requests

    def process_file_requests(self) -> list[tuple[str, FileContent]]:
        """Process pending file requests and return loaded content.

        This method is called by the TUI after FileRequestPendingMessage is received.
        It loads the requested files as BinaryContent (for PDFs/images) or strings
        (for text files) and clears the pending state.
        Files that are unsupported by the current model are filtered out.

        Returns:
            List of (file_path, FileContent) tuples for files that were successfully loaded.
            FileContent is either BinaryContent (for binary files) or str (for text files).
        """
        if not self._file_request_pending:
            return []

        # Get model capabilities
        model_config = self.deps.llm_model if self.deps else None
        supports_pdf = model_config.supports_pdf if model_config else True
        supports_images = model_config.supports_images if model_config else True

        loaded_files: list[tuple[str, FileContent]] = []
        total_requested = len(self._pending_file_requests)

        for file_path_str in self._pending_file_requests:
            try:
                path = Path(file_path_str).expanduser().resolve()
                suffix = path.suffix.lower()

                # Filter out unsupported file types based on model capabilities
                if suffix == ".pdf" and not supports_pdf:
                    logger.warning(f"Skipping PDF {path} - not supported by model")
                    continue
                if suffix in IMAGE_EXTENSIONS and not supports_images:
                    logger.warning(f"Skipping image {path} - not supported by model")
                    continue

                if not path.exists():
                    logger.warning(f"Requested file not found: {path}")
                    continue

                file_size = path.stat().st_size

                # Handle binary files (PDF, images)
                if is_binary_extension(suffix):
                    mime_type = get_mime_type(suffix)
                    if mime_type is None:
                        logger.warning(f"No MIME type for binary extension: {suffix}")
                        continue

                    # Check size limit for binary files
                    if file_size > MAX_BINARY_FILE_SIZE_BYTES:
                        logger.warning(
                            f"Binary file too large: {path} ({file_size} bytes, "
                            f"max {MAX_BINARY_FILE_SIZE_BYTES})"
                        )
                        continue

                    data = path.read_bytes()
                    loaded_files.append(
                        (str(path), BinaryContent(data=data, media_type=mime_type))
                    )
                    logger.debug(f"Loaded binary file: {path} ({len(data)} bytes)")

                # Handle text files
                elif is_text_extension(suffix):
                    # Check size limit for text files
                    if file_size > MAX_TEXT_FILE_SIZE_BYTES:
                        logger.warning(
                            f"Text file too large: {path} ({file_size} bytes, "
                            f"max {MAX_TEXT_FILE_SIZE_BYTES})"
                        )
                        continue

                    # Try UTF-8 first, fall back to latin-1
                    try:
                        content = path.read_text(encoding="utf-8")
                    except UnicodeDecodeError:
                        content = path.read_text(encoding="latin-1")

                    loaded_files.append((str(path), content))
                    logger.debug(f"Loaded text file: {path} ({len(content)} chars)")

                else:
                    logger.warning(f"Unsupported file type: {suffix} for {path}")
                    continue

            except Exception as e:
                logger.error(f"Error loading file {file_path_str}: {e}")

        # Clear pending state
        self._file_request_pending = False
        self._pending_file_requests = []

        logger.info(f"Loaded {len(loaded_files)} of {total_requested} requested files")
        return loaded_files

    def _get_agent(self, agent_type: AgentType) -> AnyAgent:
        """Get agent by type.

        Args:
            agent_type: The type of agent to retrieve.

        Returns:
            The requested agent instance (ShotgunAgent or RouterAgent).
        """
        agent_map: dict[AgentType, AnyAgent] = {
            AgentType.RESEARCH: self.research_agent,
            AgentType.PLAN: self.plan_agent,
            AgentType.TASKS: self.tasks_agent,
            AgentType.SPECIFY: self.specify_agent,
            AgentType.EXPORT: self.export_agent,
            AgentType.ROUTER: self.router_agent,
        }
        return agent_map[agent_type]

    def _get_agent_deps(self, agent_type: AgentType) -> AgentDeps:
        """Get agent-specific deps by type.

        Args:
            agent_type: The type of agent to retrieve deps for.

        Returns:
            The agent-specific dependencies.
        """
        deps_map: dict[AgentType, AgentDeps] = {
            AgentType.RESEARCH: self.research_deps,
            AgentType.PLAN: self.plan_deps,
            AgentType.TASKS: self.tasks_deps,
            AgentType.SPECIFY: self.specify_deps,
            AgentType.EXPORT: self.export_deps,
            AgentType.ROUTER: self.router_deps,
        }
        return deps_map[agent_type]

    async def _get_configured_mcp_servers(self) -> dict[str, bool]:
        """Get which MCP servers are configured.

        Returns a dict mapping MCP server names to their availability status.
        Extensible for future MCP integrations beyond Context7.

        Returns:
            Dict of MCP server names to boolean availability.
        """
        from shotgun.agents.config import get_config_manager

        config_manager = get_config_manager()
        context7_key = await config_manager.get_context7_api_key()
        user_mcp_servers = await config_manager.get_mcp_servers()

        result: dict[str, bool] = {
            "context7": context7_key is not None,
        }
        for server in user_mcp_servers:
            result[server.name] = True
        return result

    def _create_merged_deps(self, agent_type: AgentType) -> AgentDeps:
        """Create merged dependencies combining shared and agent-specific deps.

        This preserves the agent's system_prompt_fn while using shared runtime state.

        For Router agent, returns the shared deps directly (not a copy) because
        Router state (pending_approval, current_plan, etc.) must be shared with
        the TUI for features like plan approval widgets.

        Args:
            agent_type: The type of agent to create merged deps for.

        Returns:
            Merged AgentDeps with agent-specific system_prompt_fn.
        """
        agent_deps = self._get_agent_deps(agent_type)

        # Ensure shared deps is not None (should be guaranteed by __init__)
        if self.deps is None:
            raise ValueError("Shared deps is None - this should not happen")

        # For Router, use shared deps directly so state mutations are visible to TUI
        # (e.g., pending_approval, current_plan need to be seen by ChatScreen)
        if agent_type == AgentType.ROUTER:
            # Update system_prompt_fn on shared deps in place
            self.deps.system_prompt_fn = agent_deps.system_prompt_fn
            return self.deps

        # For other agents, create a copy with agent-specific system_prompt_fn
        merged_deps = self.deps.model_copy(
            update={"system_prompt_fn": agent_deps.system_prompt_fn}
        )

        return merged_deps

    def set_agent(self, agent_type: AgentType) -> None:
        """Set the current active agent.

        Args:
            agent_type: The agent type to activate (AgentType enum or string).

        Raises:
            ValueError: If invalid agent type is provided.
        """
        try:
            self._current_agent_type = AgentType(agent_type)
        except ValueError:
            raise ValueError(
                f"Invalid agent type: {agent_type}. Must be one of: {', '.join(e.value for e in AgentType)}"
            ) from None

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=8),
        retry=retry_if_exception(_is_retryable_error),
        before_sleep=before_sleep_log(logger, logging.WARNING),
        reraise=True,
    )
    async def _run_agent_with_retry(
        self,
        agent: AnyAgent,
        prompt: str | Sequence[UserContent] | None,
        deps: AgentDeps,
        usage_limits: UsageLimits | None,
        message_history: list[ModelMessage],
        event_stream_handler: Any,
        **kwargs: Any,
    ) -> AgentRunResult[AgentResponse]:
        """Run agent with automatic retry on transient errors.

        Args:
            agent: The agent to run (ShotgunAgent or RouterAgent).
            prompt: Optional prompt to send to the agent. Can be a string,
                a sequence of UserContent (for multimodal), or None.
            deps: Agent dependencies (AgentDeps or RouterDeps).
            usage_limits: Optional usage limits.
            message_history: Message history to provide to agent.
            event_stream_handler: Event handler for streaming.
            **kwargs: Additional keyword arguments.

        Returns:
            The agent run result.

        Raises:
            Various exceptions if all retries fail.

        Note:
            Type safety for agent/deps pairing is maintained by AgentManager's
            _get_agent_deps which ensures the correct deps type is used for each
            agent type. The cast is needed because Agent is contravariant in deps.
        """
        # Cast needed because Agent is contravariant in deps type parameter.
        # The agent/deps pairing is ensured by _get_agent_deps returning the
        # correct deps type for each agent type.
        return await cast(ShotgunAgent, agent).run(
            prompt,
            deps=deps,
            usage_limits=usage_limits,
            message_history=message_history,
            event_stream_handler=event_stream_handler,
            **kwargs,
        )

    async def run(
        self,
        prompt: str | None = None,
        *,
        attachment: FileAttachment | None = None,
        file_contents: list[tuple[str, FileContent]] | None = None,
        deps: AgentDeps | None = None,
        usage_limits: UsageLimits | None = None,
        **kwargs: Any,
    ) -> AgentRunResult[AgentResponse]:
        """Run the current agent with automatic message history management.

        This method wraps the agent's run method, automatically injecting the
        shared message history and updating it after each run.

        Args:
            prompt: Optional prompt to send to the agent.
            attachment: Optional file attachment to include as multimodal content.
            file_contents: Optional list of (file_path, FileContent) tuples to include
                          as multimodal content. FileContent is str for text files or
                          BinaryContent for binary files. Used when resuming after file_requests.
            deps: Optional dependencies override (defaults to manager's deps).
            usage_limits: Optional usage limits for the agent run.
            **kwargs: Additional keyword arguments to pass to the agent.

        Returns:
            The agent run result.
        """
        # Ensure agents are initialized before running
        await self._ensure_agents_initialized()

        logger.info(f"Running agent {self._current_agent_type.value}")
        # Use merged deps (shared state + agent-specific system prompt) if not provided
        if deps is None:
            deps = self._create_merged_deps(self._current_agent_type)

        # Ensure deps is not None
        if deps is None:
            raise ValueError("AgentDeps must be provided")

        # Back up .shotgun/ artifacts before each agent run
        from shotgun.agents.backup import backup_artifacts, cleanup_old_backups
        from shotgun.utils.file_system_utils import get_shotgun_base_path

        self._last_backup_path = backup_artifacts(get_shotgun_base_path())
        cleanup_old_backups()

        # Clear file tracker before each run to track only this run's operations
        deps.file_tracker.clear()

        # Don't manually add the user prompt - Pydantic AI will include it in result.new_messages()
        # This prevents duplicates and confusion with incremental mounting

        # Save current message history before the run
        original_messages = self.ui_message_history.copy()

        # Clear sub-agent messages from any previous run
        self._sub_agent_messages = []

        # Start with persistent message history
        message_history = self.message_history

        deps.agent_mode = self._current_agent_type

        # For router agent, set up the parent stream handler so sub-agents can stream
        if self._current_agent_type == AgentType.ROUTER:
            if isinstance(deps, RouterDeps):
                deps.parent_stream_handler = self._handle_event_stream  # type: ignore[assignment]

        # Filter out system prompts from other agent types
        from pydantic_ai.messages import ModelRequestPart

        filtered_history: list[ModelMessage] = []
        for message in message_history:
            # Keep all non-ModelRequest messages as-is
            if not isinstance(message, ModelRequest):
                filtered_history.append(message)
                continue

            # Filter out AgentSystemPrompts from other agent types
            filtered_parts: list[ModelRequestPart] = []
            for part in message.parts:
                # Keep non-AgentSystemPrompt parts
                if not isinstance(part, AgentSystemPrompt):
                    filtered_parts.append(part)
                    continue

                # Only keep system prompts from the same agent type
                if part.agent_mode == deps.agent_mode:
                    filtered_parts.append(part)

            # Only add the message if it has parts remaining
            if filtered_parts:
                filtered_history.append(ModelRequest(parts=filtered_parts))

        message_history = filtered_history

        # Sanitize message history: remove incomplete tool calls and orphaned returns.
        # This prevents ValueError crashes from stale/loaded history with truncated JSON.
        message_history = filter_incomplete_messages(message_history)
        message_history = filter_orphaned_tool_responses(message_history)

        # Add a system status message so the agent knows whats going on
        message_history = await add_system_status_message(deps, message_history)

        # Determine if codebase is indexed before rendering prompts
        if deps.codebase_service:
            codebase_graphs = await deps.codebase_service.list_graphs_for_directory()
            deps.has_codebase_indexed = len(codebase_graphs) > 0

        # Check if the message history already has a system prompt from the same agent type
        has_system_prompt = False
        for message in message_history:
            if not isinstance(message, ModelRequest):
                continue

            for part in message.parts:
                if not isinstance(part, AgentSystemPrompt):
                    continue

                # Check if it's from the same agent type
                if part.agent_mode == deps.agent_mode:
                    has_system_prompt = True
                    break

        # Always ensure we have a system prompt for the agent
        # (compaction may remove it from persistent history, but agent needs it)
        if not has_system_prompt:
            message_history = await add_system_prompt_message(deps, message_history)

        # Run the agent with streaming support (from origin/main)
        self._stream_state = _PartialStreamState()

        model_name = ""
        supports_streaming = True  # Default to streaming enabled

        if hasattr(deps, "llm_model") and deps.llm_model is not None:
            model_name = deps.llm_model.name
            supports_streaming = deps.llm_model.supports_streaming

            # Add hint message if streaming is disabled for BYOK GPT-5 models
            if (
                not supports_streaming
                and deps.llm_model.key_provider == KeyProvider.BYOK
            ):
                self.ui_message_history.append(
                    HintMessage(
                        message=(
                            "⚠️ **Streaming not available for GPT-5**\n\n"
                            "Your OpenAI organization doesn't have streaming enabled for this model.\n\n"
                            "**Options:**\n"
                            "- Get a [Shotgun Account](https://shotgun.sh) - streaming works out of the box\n"
                            "- Complete [Biometric Verification](https://platform.openai.com/settings/organization/general) with OpenAI, then:\n"
                            "  1. Press `/` → Open Provider Setup\n"
                            "  2. Select OpenAI → Clear key\n"
                            "  3. Re-add your OpenAI API key\n\n"
                            "Continuing without streaming (responses will appear all at once)."
                        )
                    )
                )
                self._post_messages_updated()

        # Track message send event
        event_name = f"message_send_{self._current_agent_type.value}"
        event_properties: dict[str, Any] = {
            "has_prompt": prompt is not None,
            "model_name": model_name,
            "has_attachment": attachment is not None,
            "key_provider": (
                deps.llm_model.key_provider.value if deps.llm_model else None
            ),
            "provider": deps.llm_model.provider.value if deps.llm_model else None,
        }

        # Add Tier 1 Anthropic flag for routing agent telemetry
        if (
            self._current_agent_type == AgentType.ROUTER
            and deps.llm_model is not None
            and deps.llm_model.provider == ProviderType.ANTHROPIC
        ):
            anthropic_tier = await get_configured_anthropic_tier()
            if anthropic_tier is not None:
                event_properties["is_tier1_anthropic"] = (
                    anthropic_tier == AnthropicTier.TIER_1
                )
                event_properties["anthropic_tier"] = anthropic_tier

        # Track which MCP servers are configured (extensible for future MCP integrations)
        if self._current_agent_type == AgentType.ROUTER:
            mcp_servers = await self._get_configured_mcp_servers()
            event_properties["mcp_servers"] = mcp_servers

        track_event(event_name, event_properties)

        # Construct multimodal prompt if attachment or file_contents is provided
        user_prompt: str | Sequence[UserContent] | None = prompt

        if file_contents:
            # File contents from file_requests - construct multimodal prompt with files
            # FileContent can be str (text files) or BinaryContent (binary files)
            content_parts: list[UserContent] = [
                prompt or "Here are the files you requested:"
            ]
            for file_path, content in file_contents:
                content_parts.append(f"\n\n--- File: {file_path} ---")
                if isinstance(content, str):
                    # Text file - append content directly as string
                    content_parts.append(f"\n{content}")
                else:
                    # Binary file - append as BinaryContent
                    content_parts.append(content)
            user_prompt = content_parts
            logger.debug(
                "Constructed multimodal prompt with requested files",
                extra={"num_files": len(file_contents)},
            )
        elif attachment and attachment.content_base64:
            # Use BinaryContent which is supported by all providers (OpenAI, Anthropic, Google)
            binary_data = base64.b64decode(attachment.content_base64)
            binary_content = BinaryContent(
                data=binary_data,
                media_type=attachment.mime_type,
            )
            user_prompt = [prompt or "", binary_content]
            logger.debug(
                "Constructed multimodal prompt with attachment",
                extra={
                    "attachment_type": attachment.file_type.value,
                    "attachment_size": attachment.file_size_bytes,
                },
            )

        try:
            result: AgentRunResult[AgentResponse] = await self._run_agent_with_retry(
                agent=self.current_agent,
                prompt=user_prompt,
                deps=deps,
                usage_limits=usage_limits,
                message_history=message_history,
                event_stream_handler=self._handle_event_stream
                if supports_streaming
                else None,
                **kwargs,
            )
        except ValueError as e:
            # Handle truncated/incomplete JSON in tool calls specifically
            error_str = str(e)
            if "EOF while parsing" in error_str or (
                "JSON" in error_str and "parsing" in error_str
            ):
                # Try to extract the tool name from the stream state
                failed_tool_name: str | None = None
                if self._stream_state and self._stream_state.current_response:
                    for response_part in reversed(
                        self._stream_state.current_response.parts
                    ):
                        if isinstance(response_part, ToolCallPart):
                            failed_tool_name = response_part.tool_name
                            break

                logger.error(
                    "Tool call with truncated/incomplete JSON arguments detected",
                    extra={
                        "agent_mode": self._current_agent_type.value,
                        "model_name": model_name,
                        "error": error_str,
                        "tool_name": failed_tool_name,
                    },
                )
                logfire.error(
                    "Tool call with truncated JSON arguments",
                    agent_mode=self._current_agent_type.value,
                    model_name=model_name,
                    error=error_str,
                    tool_name=failed_tool_name,
                )
                # Add hint message so the failure shows in conversation history
                tool_info = f" (`{failed_tool_name}`)" if failed_tool_name else ""
                self.ui_message_history.append(
                    HintMessage(
                        message=f"⚠️ A tool call{tool_info} failed — the model's output "
                        "was cut off before completing the tool arguments. "
                        "Try again — this is usually a transient issue."
                    )
                )
                self._post_messages_updated()
                # Raise user-friendly exception instead of raw ValueError
                raise IncompleteToolCallError(tool_name=failed_tool_name) from e
            # Re-raise non-JSON ValueErrors as-is
            raise
        except Exception as e:
            # Log the error with full stack trace to shotgun.log and Logfire
            logger.exception(
                "Agent execution failed",
                extra={
                    "agent_mode": self._current_agent_type.value,
                    "model_name": model_name,
                    "error_type": type(e).__name__,
                },
            )
            logfire.exception(
                "Agent execution failed",
                agent_mode=self._current_agent_type.value,
                model_name=model_name,
                error_type=type(e).__name__,
            )
            # Re-raise to let TUI handle user messaging
            raise
        finally:
            self._stream_state = None
            # Flush PostHog events between agent runs to prevent
            # unbounded queue growth during long-running sessions
            flush_telemetry()

        # Agent ALWAYS returns AgentResponse with structured output
        agent_response = result.output
        logger.debug(
            "Agent returned structured AgentResponse",
            extra={
                "has_response": agent_response.response is not None,
                "response_length": len(agent_response.response)
                if agent_response.response
                else 0,
                "response_preview": agent_response.response[:100] + "..."
                if agent_response.response and len(agent_response.response) > 100
                else agent_response.response or "(empty)",
                "has_clarifying_questions": bool(agent_response.clarifying_questions),
                "num_clarifying_questions": len(agent_response.clarifying_questions)
                if agent_response.clarifying_questions
                else 0,
            },
        )

        # Merge agent's response messages, avoiding duplicates
        # The TUI may have already added the user prompt, so check for it
        new_messages = cast(
            list[ModelRequest | ModelResponse | HintMessage], result.new_messages()
        )

        # Deduplicate: skip user prompts that are already in original_messages
        # Note: We compare content only, not timestamps, since UserPromptPart
        # has a timestamp field that differs between instances
        def get_user_prompt_text(
            request: ModelRequest,
        ) -> str | None:
            """Extract just the text content from a ModelRequest for deduplication.

            When content is multimodal (list with text + binary), extract just the text.
            This ensures text-only and multimodal versions of the same prompt match.
            """
            for part in request.parts:
                if isinstance(part, UserPromptPart):
                    content = part.content
                    if isinstance(content, str):
                        return content
                    elif isinstance(content, list):
                        # Multimodal content - extract text strings only
                        text_parts = [item for item in content if isinstance(item, str)]
                        return text_parts[0] if text_parts else None
            return None

        deduplicated_new_messages: list[
            ModelMessage | HintMessage | WelcomeMessage
        ] = []
        for msg in new_messages:
            # Check if this is a user prompt that's already in original_messages
            if isinstance(msg, ModelRequest) and any(
                isinstance(part, UserPromptPart) for part in msg.parts
            ):
                msg_text = get_user_prompt_text(msg)
                # Check if an identical user prompt is already in original_messages
                already_exists = any(
                    isinstance(existing, ModelRequest)
                    and get_user_prompt_text(existing) == msg_text
                    for existing in original_messages[
                        -5:
                    ]  # Check last 5 messages for efficiency
                )
                if already_exists:
                    continue  # Skip this duplicate user prompt

            deduplicated_new_messages.append(msg)

        # Mark file resume prompts as internal (hidden from UI)
        # When file_contents is provided, the prompt is system-generated, not user input
        if file_contents:
            deduplicated_new_messages = self._mark_as_internal_prompts(
                deduplicated_new_messages
            )

        self.ui_message_history = original_messages + deduplicated_new_messages

        # Persist sub-agent streaming responses into UI history so they survive
        # the MessageHistoryUpdated rebuild.
        self._interleave_sub_agent_messages(len(original_messages))

        # Get file operations early so we can use them for contextual messages
        file_operations = deps.file_tracker.operations.copy()
        self.recently_change_files = file_operations

        logger.debug(
            "File operations tracked",
            extra={
                "num_file_operations": len(file_operations),
                "operation_files": [Path(op.file_path).name for op in file_operations],
            },
        )

        # Check if there are file requests (takes priority over clarifying questions)
        # But ignore file_requests if we just provided file_contents (prevents infinite loops)
        if agent_response.file_requests and not file_contents:
            logger.info(
                f"Agent requested {len(agent_response.file_requests)} files to be loaded"
            )

            # Set pending state
            self._file_request_pending = True
            self._pending_file_requests = agent_response.file_requests

            # Add agent's response as hint if present
            if agent_response.response:
                self.ui_message_history.append(
                    HintMessage(message=agent_response.response)
                )

            # Add file loading indicator
            files_list = "\n".join(f"- `{p}`" for p in agent_response.file_requests)
            self.ui_message_history.append(
                HintMessage(message=f"📁 Loading requested files:\n{files_list}")
            )

            # Post UI update with hint messages
            self._post_messages_updated([])

            # Post event to TUI to load files and resume
            self.post_message(
                FileRequestPendingMessage(
                    file_paths=agent_response.file_requests,
                    response_text=agent_response.response,
                )
            )

            return result
        elif agent_response.file_requests and file_contents:
            # We just provided files, ignore any new file_requests to prevent loops
            logger.debug(
                "Ignoring file_requests (files were just provided): %s",
                agent_response.file_requests,
            )

        # Check if there are clarifying questions
        if agent_response.clarifying_questions:
            logger.info(
                f"Agent has {len(agent_response.clarifying_questions)} clarifying questions"
            )

            # Add agent's response first if present
            if agent_response.response:
                self.ui_message_history.append(
                    HintMessage(message=agent_response.response)
                )

            # Add file operation hints before questions (so they appear first in UI)
            if file_operations:
                file_hint = self._create_file_operation_hint(file_operations)
                if file_hint:
                    self.ui_message_history.append(HintMessage(message=file_hint))

            if len(agent_response.clarifying_questions) == 1:
                # Single question - treat as non-blocking suggestion, DON'T enter Q&A mode
                self.ui_message_history.append(
                    HintMessage(message=f"💡 {agent_response.clarifying_questions[0]}")
                )
                # Add plan hint for Drafting mode (Planning mode uses PlanPanelWidget)
                self._maybe_add_plan_hint_drafting_mode(deps)
            else:
                # Multiple questions (2+) - enter Q&A mode
                self._qa_questions = agent_response.clarifying_questions
                self._qa_mode_active = True

                # In Drafting mode, show plan BEFORE Q&A questions (without "Shall I continue?")
                self._maybe_add_plan_hint_drafting_mode(deps, in_qa_mode=True)

                # Show intro with list, then first question
                questions_list_with_intro = (
                    f"I have {len(agent_response.clarifying_questions)} questions:\n\n"
                    + "\n".join(
                        f"{i + 1}. {q}"
                        for i, q in enumerate(agent_response.clarifying_questions)
                    )
                )
                self.ui_message_history.append(
                    HintMessage(message=questions_list_with_intro)
                )
                self.ui_message_history.append(
                    HintMessage(
                        message=f"**Q1:** {agent_response.clarifying_questions[0]}"
                    )
                )

                # Post event to TUI to update Q&A mode state (only for multiple questions)
                self.post_message(
                    ClarifyingQuestionsMessage(
                        questions=agent_response.clarifying_questions,
                        response_text=agent_response.response,
                    )
                )

            # Post UI update with hint messages (file operations will be posted after compaction)
            logger.debug("Posting UI update for Q&A mode with hint messages")
            self._post_messages_updated([])
        else:
            # No clarifying questions - show the response or a default success message
            if agent_response.response and agent_response.response.strip():
                logger.debug(
                    "Adding agent response as hint",
                    extra={
                        "response_preview": agent_response.response[:100] + "..."
                        if len(agent_response.response) > 100
                        else agent_response.response,
                        "has_file_operations": len(file_operations) > 0,
                    },
                )
                self.ui_message_history.append(
                    HintMessage(message=agent_response.response)
                )
            else:
                # Fallback: response is empty or whitespace
                logger.debug(
                    "Agent response was empty, using fallback completion message",
                    extra={"has_file_operations": len(file_operations) > 0},
                )
                # Show contextual message based on whether files were modified
                if file_operations:
                    self.ui_message_history.append(
                        HintMessage(
                            message="✅ Task completed - files have been modified"
                        )
                    )
                else:
                    self.ui_message_history.append(
                        HintMessage(message="✅ Task completed")
                    )

            # Add plan hint for Drafting mode (Planning mode uses PlanPanelWidget)
            self._maybe_add_plan_hint_drafting_mode(deps)

            # Post UI update immediately so user sees the response without delay
            # (file operations will be posted after compaction to avoid duplicates)
            logger.debug("Posting immediate UI update with hint message")
            self._post_messages_updated([])

        # Apply compaction to persistent message history to prevent cascading growth
        all_messages = result.all_messages()
        messages_before_compaction = len(all_messages)
        compaction_occurred = False

        try:
            logger.debug(
                "Starting message history compaction",
                extra={"message_count": len(all_messages)},
            )
            # Notify UI that compaction is starting
            self.post_message(CompactionStartedMessage())

            self.message_history = await apply_persistent_compaction(all_messages, deps)

            # Track if compaction actually modified the history
            compaction_occurred = len(self.message_history) != len(all_messages)

            # Notify UI that compaction is complete
            self.post_message(CompactionCompletedMessage())

            logger.debug(
                "Completed message history compaction",
                extra={
                    "original_count": len(all_messages),
                    "compacted_count": len(self.message_history),
                },
            )
        except Exception as e:
            # If compaction fails, log full error with stack trace and use uncompacted messages
            logger.error(
                "Failed to compact message history - using uncompacted messages",
                exc_info=True,
                extra={
                    "error": str(e),
                    "message_count": len(all_messages),
                    "agent_mode": self._current_agent_type.value,
                },
            )
            # Fallback: use uncompacted messages to prevent data loss
            self.message_history = all_messages

        # Track context composition telemetry
        await self._track_context_analysis(
            compaction_occurred=compaction_occurred,
            messages_before_compaction=messages_before_compaction
            if compaction_occurred
            else None,
        )

        usage = result.usage()
        if hasattr(deps, "llm_model") and deps.llm_model is not None:
            await deps.usage_manager.add_usage(
                usage, model_name=deps.llm_model.name, provider=deps.llm_model.provider
            )
        else:
            logger.warning(
                "llm_model is None, skipping usage tracking",
                extra={"agent_mode": self._current_agent_type.value},
            )

        # Prune old hint/welcome messages to prevent unbounded UI history growth
        self._prune_ui_message_history()

        # Show backup path hint after the run completes
        if self._last_backup_path:
            self.ui_message_history.append(
                HintMessage(
                    message=f"The original specs were backed up to `{self._last_backup_path}`",
                    compact=True,
                )
            )

        # Post final UI update after compaction completes
        # This ensures widgets that depend on message_history (like context indicator)
        # receive the updated history after compaction
        logger.debug(
            "Posting final UI update after compaction with updated message_history"
        )
        self._post_messages_updated(file_operations)

        return result

    async def _handle_event_stream(
        self,
        _ctx: RunContext[AgentDeps],
        stream: AsyncIterable[AgentStreamEvent],
    ) -> None:
        """Process streamed events and forward partial updates to the UI."""

        # Notify UI that streaming has started
        self.post_message(AgentStreamingStarted())

        state = self._stream_state
        if state is None:
            state = self._stream_state = _PartialStreamState()

        if state.current_response is not None:
            partial_parts: list[ModelResponsePart | ToolCallPartDelta] = list(
                state.current_response.parts
                # cast(Sequence[ModelResponsePart], state.current_response.parts)
            )
        else:
            partial_parts = []

        # Wrap stream with cancellable iterator for responsive ESC handling
        deps = _ctx.deps
        if deps.cancellation_event:
            stream = CancellableStreamIterator(stream, deps.cancellation_event)

        async for event in stream:
            try:
                if isinstance(event, PartStartEvent):
                    index = event.index
                    if index < len(partial_parts):
                        partial_parts[index] = event.part
                    elif index == len(partial_parts):
                        partial_parts.append(event.part)
                    else:
                        logger.warning(
                            "Received PartStartEvent with out-of-bounds index",
                            extra={"index": index, "current_len": len(partial_parts)},
                        )
                        partial_parts.append(event.part)

                    partial_message = self._build_partial_response(partial_parts)
                    if partial_message is not None:
                        state.current_response = partial_message
                        self._post_partial_message(False)

                elif isinstance(event, PartDeltaEvent):
                    index = event.index
                    if index >= len(partial_parts):
                        logger.warning(
                            "Received PartDeltaEvent before corresponding start event",
                            extra={"index": index, "current_len": len(partial_parts)},
                        )
                        continue

                    # Count tokens from the delta for progress indication
                    delta_len = 0
                    is_tool_call_delta = False
                    if isinstance(event.delta, ToolCallPartDelta):
                        is_tool_call_delta = True
                        # args_delta can be str or dict depending on provider
                        args_delta = event.delta.args_delta
                        if isinstance(args_delta, str):
                            delta_len = len(args_delta)
                        elif isinstance(args_delta, dict):
                            # For dict deltas, estimate from JSON representation
                            delta_len = len(json.dumps(args_delta))
                        # Pick a spinner message when tool streaming starts
                        if state.current_spinner_text == "Processing...":
                            import random

                            state.current_spinner_text = random.choice(  # noqa: S311
                                SPINNER_MESSAGES
                            )
                    elif isinstance(event.delta, TextPartDelta):
                        delta_len = len(event.delta.content_delta)

                    if delta_len > 0:
                        # Approximate tokens: len / 4 is a rough estimate
                        state.streamed_tokens += delta_len // 4 + 1
                        # Send progress update for tool call streaming
                        # Throttle updates to every ~75 tokens to avoid flooding UI
                        if is_tool_call_delta and (
                            state.streamed_tokens - state.last_reported_tokens >= 75
                        ):
                            state.last_reported_tokens = state.streamed_tokens
                            self.post_message(
                                ToolStreamingProgressMessage(
                                    state.streamed_tokens,
                                    state.current_spinner_text,
                                )
                            )

                    try:
                        updated_part = event.delta.apply(
                            cast(ModelResponsePart, partial_parts[index])
                        )
                    except Exception:  # pragma: no cover - defensive logging
                        logger.exception(
                            "Failed to apply part delta", extra={"event": event}
                        )
                        continue

                    partial_parts[index] = updated_part

                    partial_message = self._build_partial_response(partial_parts)
                    if partial_message is not None:
                        state.current_response = partial_message
                        self._post_partial_message(False)

                elif isinstance(event, FunctionToolCallEvent):
                    # Track tool call event

                    # Detect source from call stack
                    source = detect_source()

                    # Log if tool call has incomplete args (for debugging truncated JSON)
                    if isinstance(event.part.args, str):
                        try:
                            json.loads(event.part.args)
                        except (json.JSONDecodeError, ValueError):
                            args_preview = (
                                event.part.args[:100] + "..."
                                if len(event.part.args) > 100
                                else event.part.args
                            )
                            logger.warning(
                                "FunctionToolCallEvent received with incomplete JSON args",
                                extra={
                                    "tool_name": event.part.tool_name,
                                    "tool_call_id": event.part.tool_call_id,
                                    "args_preview": args_preview,
                                    "args_length": len(event.part.args)
                                    if event.part.args
                                    else 0,
                                    "agent_mode": self._current_agent_type.value,
                                },
                            )
                            logfire.warn(
                                "FunctionToolCallEvent received with incomplete JSON args",
                                tool_name=event.part.tool_name,
                                tool_call_id=event.part.tool_call_id,
                                args_preview=args_preview,
                                args_length=len(event.part.args)
                                if event.part.args
                                else 0,
                                agent_mode=self._current_agent_type.value,
                            )

                    track_event(
                        "tool_called",
                        {
                            "tool_name": event.part.tool_name,
                            "agent_mode": self._current_agent_type.value
                            if self._current_agent_type
                            else "unknown",
                            "source": source,
                        },
                    )

                    existing_call_idx = next(
                        (
                            i
                            for i, part in enumerate(partial_parts)
                            if isinstance(part, ToolCallPart)
                            and part.tool_call_id == event.part.tool_call_id
                        ),
                        None,
                    )

                    if existing_call_idx is not None:
                        partial_parts[existing_call_idx] = event.part
                    elif state.messages:
                        existing_call_idx = next(
                            (
                                i
                                for i, part in enumerate(state.messages[-1].parts)
                                if isinstance(part, ToolCallPart)
                                and part.tool_call_id == event.part.tool_call_id
                            ),
                            None,
                        )
                    else:
                        partial_parts.append(event.part)
                    partial_message = self._build_partial_response(partial_parts)
                    if partial_message is not None:
                        state.current_response = partial_message
                        self._post_partial_message(False)

                    # Notify UI that a tool is about to execute
                    # This updates the spinner with a fun message during tool execution
                    # Pick a random spinner message and store it for progress updates
                    import random

                    spinner_text = random.choice(SPINNER_MESSAGES)  # noqa: S311
                    state.current_spinner_text = spinner_text
                    state.streamed_tokens = 0  # Reset token count for new tool
                    self.post_message(ToolExecutionStartedMessage(spinner_text))

                elif isinstance(event, FunctionToolResultEvent):
                    # Track tool completion event

                    # Detect source from call stack
                    source = detect_source()

                    track_event(
                        "tool_completed",
                        {
                            "tool_name": event.result.tool_name
                            if hasattr(event.result, "tool_name")
                            else "unknown",
                            "agent_mode": self._current_agent_type.value
                            if self._current_agent_type
                            else "unknown",
                            "source": source,
                        },
                    )

                    request_message = ModelRequest(parts=[event.result])
                    state.messages.append(request_message)
                    ## this is what the user responded with
                    self._post_partial_message(is_last=False)

                elif isinstance(event, FinalResultEvent):
                    pass
            except Exception:  # pragma: no cover - defensive logging
                logger.exception(
                    "Error while handling agent stream event", extra={"event": event}
                )

        final_message = state.current_response or self._build_partial_response(
            partial_parts
        )
        if final_message is not None:
            state.current_response = final_message
            if final_message not in state.messages:
                state.messages.append(final_message)
            state.current_response = None
            self._post_partial_message(True)

            # Persist sub-agent responses so they survive MessageHistoryUpdated rebuild.
            # Sub-agent turns have a different agent_mode than the current (router) agent.
            # Sub-agent turns contain ToolCallPart (tool calls like read_file, list_directory)
            # which render as "Reading file: X", "Listing directory: Y" in the UI.
            agent_mode = _ctx.deps.agent_mode
            if agent_mode is not None and agent_mode != self._current_agent_type:
                # Mark as sub-agent response for rendering with ↳ prefix
                final_message._shotgun_is_sub_agent = True  # type: ignore[attr-defined]
                self._sub_agent_messages.append(final_message)
                if len(self._sub_agent_messages) > 200:
                    logger.warning(
                        "_sub_agent_messages exceeded 200 entries, truncating to most recent 100"
                    )
                    self._sub_agent_messages = self._sub_agent_messages[-100:]

        state.current_response = None

        # Notify UI that streaming has completed
        self.post_message(AgentStreamingCompleted())

    def _interleave_sub_agent_messages(self, original_count: int) -> None:
        """Insert captured sub-agent messages into ui_message_history.

        Sub-agent streaming responses are captured during _handle_event_stream
        but lost during the MessageHistoryUpdated rebuild. This method inserts
        them before the router's final ModelResponse so the chat shows:
        user -> router delegation -> sub-agent tools -> router summary.

        Args:
            original_count: Number of messages from before the current run,
                used as a lower bound when searching for the insertion point.
        """
        if not self._sub_agent_messages:
            return
        insert_idx = len(self.ui_message_history)
        for i in range(
            len(self.ui_message_history) - 1,
            original_count - 1,
            -1,
        ):
            if isinstance(self.ui_message_history[i], ModelResponse):
                insert_idx = i
                break
        for j, msg in enumerate(self._sub_agent_messages):
            self.ui_message_history.insert(insert_idx + j, msg)
        self._sub_agent_messages = []

    def _prune_ui_message_history(self) -> None:
        """Keep only the last MAX_UI_HISTORY_MESSAGES items in ui_message_history.

        Acts as a circular buffer — oldest messages of any type are dropped.
        """
        if len(self.ui_message_history) <= MAX_UI_HISTORY_MESSAGES:
            return

        self.ui_message_history = self.ui_message_history[-MAX_UI_HISTORY_MESSAGES:]

    def _build_partial_response(
        self, parts: list[ModelResponsePart | ToolCallPartDelta]
    ) -> ModelResponse | None:
        """Create a `ModelResponse` from the currently streamed parts."""

        completed_parts = [
            part for part in parts if not isinstance(part, ToolCallPartDelta)
        ]
        if not completed_parts:
            return None
        return ModelResponse(parts=list(completed_parts))

    def _post_partial_message(self, is_last: bool) -> None:
        """Post a partial message to the UI."""
        if self._stream_state is None:
            return
        self.post_message(
            PartialResponseMessage(
                self._stream_state.current_response
                if self._stream_state.current_response
                not in self._stream_state.messages
                else None,
                self._stream_state.messages,
                is_last,
            )
        )

    def _create_file_operation_hint(
        self, file_operations: list[FileOperation]
    ) -> str | None:
        """Create a hint message for file operations.

        Args:
            file_operations: List of file operations to create a hint for

        Returns:
            Hint message string or None if no operations
        """
        if not file_operations:
            return None

        tracker = FileOperationTracker(operations=file_operations)
        display_path = tracker.get_display_path()

        if not display_path:
            return None

        path_obj = Path(display_path)

        if len(file_operations) == 1:
            return f"📝 Modified: `{display_path}`"
        else:
            num_files = len({op.file_path for op in file_operations})
            if path_obj.is_dir():
                return f"📁 Modified {num_files} files in: `{display_path}`"
            else:
                # Common path is a file, show parent directory
                return f"📁 Modified {num_files} files in: `{path_obj.parent}`"

    def _maybe_add_plan_hint_drafting_mode(
        self, deps: AgentDeps, in_qa_mode: bool = False
    ) -> None:
        """Add execution plan hint for router agent in Drafting mode only.

        In Drafting mode, there's no PlanPanelWidget, so we show the plan
        in the chat history with a "Shall I continue?" prompt (unless in Q&A mode).

        In Planning mode, the PlanPanelWidget handles plan display.

        Args:
            deps: Agent dependencies (may be RouterDeps for router agent)
            in_qa_mode: If True, skip the "Shall I continue?" prompt since user
                       needs to answer Q&A questions first.
        """
        if self._current_agent_type != AgentType.ROUTER:
            return

        if not isinstance(deps, RouterDeps):
            return

        # Only show plan hints in Drafting mode
        # Planning mode uses PlanPanelWidget instead
        if deps.router_mode != RouterMode.DRAFTING:
            return

        if deps.current_plan is None:
            return

        plan_display = deps.current_plan.format_for_display()

        # In drafting mode, if plan is not complete and NOT in Q&A mode,
        # prompt user to continue
        if not deps.current_plan.is_complete() and not in_qa_mode:
            plan_display += "\n\n**Shall I continue?**"

        logger.debug("Adding plan hint to UI history (Drafting mode)")
        self.ui_message_history.append(
            HintMessage(message=f"**Current Plan**\n\n{plan_display}")
        )

    def _post_messages_updated(
        self, file_operations: list[FileOperation] | None = None
    ) -> None:
        # Post event to notify listeners of the message history update
        self.post_message(
            MessageHistoryUpdated(
                messages=self.ui_message_history.copy(),
                agent_type=self._current_agent_type,
                file_operations=file_operations,
            )
        )

    def _mark_as_internal_prompts(
        self,
        messages: list[ModelMessage | HintMessage | WelcomeMessage],
    ) -> list[ModelMessage | HintMessage | WelcomeMessage]:
        """Mark UserPromptPart as InternalPromptPart for system-generated prompts.

        Used when file_contents is provided - the resume prompt is system-generated,
        not actual user input, and should be hidden from the UI.

        Args:
            messages: List of messages that may contain user prompts to mark as internal

        Returns:
            List of messages with UserPromptPart converted to InternalPromptPart
        """
        result: list[ModelMessage | HintMessage | WelcomeMessage] = []
        for msg in messages:
            if isinstance(msg, ModelRequest):
                new_parts: list[ModelRequestPart] = []
                for part in msg.parts:
                    if isinstance(part, UserPromptPart) and not isinstance(
                        part, InternalPromptPart
                    ):
                        # Convert to InternalPromptPart
                        new_parts.append(
                            InternalPromptPart(
                                content=part.content,
                                timestamp=part.timestamp,
                            )
                        )
                    else:
                        new_parts.append(part)
                result.append(ModelRequest(parts=new_parts))
            else:
                result.append(msg)
        return result

    def _filter_system_prompts(
        self, messages: list[ModelMessage | HintMessage | WelcomeMessage]
    ) -> list[ModelMessage | HintMessage | WelcomeMessage]:
        """Filter out system prompts from messages for UI display.

        Args:
            messages: List of messages that may contain system prompts

        Returns:
            List of messages without system prompt parts
        """
        filtered_messages: list[ModelMessage | HintMessage | WelcomeMessage] = []
        for msg in messages:
            if isinstance(msg, (HintMessage, WelcomeMessage)):
                filtered_messages.append(msg)
                continue

            parts: Sequence[ModelRequestPart] | Sequence[ModelResponsePart] | None = (
                msg.parts if hasattr(msg, "parts") else None
            )
            if not parts:
                filtered_messages.append(msg)
                continue

            non_system_parts = [
                part for part in parts if not isinstance(part, SystemPromptPart)
            ]

            if not non_system_parts:
                # Skip messages made up entirely of system prompt parts (e.g. system message)
                continue

            if len(non_system_parts) == len(parts):
                # Nothing was filtered – keep original message
                filtered_messages.append(msg)
                continue

            if is_dataclass(msg):
                filtered_messages.append(
                    # ignore types because of the convoluted Request | Response types
                    replace(msg, parts=cast(Any, non_system_parts))
                )
            else:
                filtered_messages.append(msg)
        return filtered_messages

    def get_usage_hint(self) -> str | None:
        return self.deps.usage_manager.build_usage_hint()

    async def get_context_hint(self) -> str | None:
        """Get conversation context analysis as a formatted hint.

        Returns:
            Markdown-formatted string with context composition statistics, or None if unavailable
        """
        analysis = await self.get_context_analysis()
        if analysis:
            return ContextFormatter.format_markdown(analysis)
        return None

    async def get_context_analysis(self) -> ContextAnalysis | None:
        """Get conversation context analysis as structured data.

        Returns:
            ContextAnalysis object with token usage data, or None if unavailable
        """

        try:
            analyzer = ContextAnalyzer(self.deps.llm_model)
            return await analyzer.analyze_conversation(
                self.message_history, self.ui_message_history
            )
        except Exception as e:
            logger.error(f"Failed to generate context analysis: {e}", exc_info=True)
            return None

    async def _track_context_analysis(
        self,
        compaction_occurred: bool = False,
        messages_before_compaction: int | None = None,
    ) -> None:
        """Track context composition telemetry to PostHog.

        Args:
            compaction_occurred: Whether compaction was applied
            messages_before_compaction: Message count before compaction, if it occurred
        """
        try:
            analyzer = ContextAnalyzer(self.deps.llm_model)
            analysis = await analyzer.analyze_conversation(
                self.message_history, self.ui_message_history
            )

            # Create telemetry model from analysis
            telemetry = ContextCompositionTelemetry.from_analysis(
                analysis,
                compaction_occurred=compaction_occurred,
                messages_before_compaction=messages_before_compaction,
            )

            # Send to PostHog using model_dump() for dict conversion
            track_event("agent_context_composition", telemetry.model_dump())
        except Exception as e:
            logger.warning(f"Failed to track context analysis: {e}")

    def get_conversation_state(self) -> "ConversationState":
        """Get the current conversation state.

        Returns:
            ConversationState object containing UI and agent messages and current type
        """
        from shotgun.agents.conversation import ConversationState

        return ConversationState(
            agent_messages=self.message_history.copy(),
            ui_messages=self.ui_message_history.copy(),
            agent_type=self._current_agent_type.value,
        )

    def restore_conversation_state(self, state: "ConversationState") -> None:
        """Restore conversation state from a saved state.

        Args:
            state: ConversationState object to restore
        """
        # Restore message history for agents (includes system prompts)
        non_hint_messages = [
            msg for msg in state.agent_messages if not isinstance(msg, HintMessage)
        ]
        self.message_history = non_hint_messages

        # Filter out system prompts for UI display while keeping hints
        ui_source = state.ui_messages or cast(
            list[ModelMessage | HintMessage | WelcomeMessage], state.agent_messages
        )
        self.ui_message_history = self._filter_system_prompts(ui_source)

        # Restore agent type
        self._current_agent_type = AgentType(state.agent_type)

        # Notify listeners about the restored messages
        self._post_messages_updated()

    def add_hint_message(self, message: HintMessage | WelcomeMessage) -> None:
        self.ui_message_history.append(message)
        self._post_messages_updated()


# Re-export AgentType for backward compatibility
__all__ = [
    "AgentManager",
    "AgentType",
    "ClarifyingQuestionsMessage",
    "CompactionCompletedMessage",
    "CompactionStartedMessage",
    "MessageHistoryUpdated",
    "PartialResponseMessage",
]
