from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterator, List

import pandas as pd

from .engines import PartitionEngineMetadata
from .planning import SimulationPlan
from .reporting import (
    SimulationChartData,
    SimulationSummary,
    build_simulation_summary,
)
from .splitters import TemporalBacktestSplitter
from .splits import TimeSplit
from .types import TemporalPartitionSpec, TemporalSemanticsSpec


@dataclass(frozen=True)
class SimulationResult:
    """Materialized result of running a temporal simulation over a dataset.

    Attributes:
        frame: Source dataset used to build the simulation.
        splits: Materialized fold objects.
        summary: Structured report for the simulation.
        engine_metadata: Internal partition engine selected for the simulation.
    """

    frame: pd.DataFrame
    splits: List[TimeSplit]
    summary: SimulationSummary
    engine_metadata: PartitionEngineMetadata

    @property
    def total_folds(self) -> int:
        """Return the number of materialized folds."""
        return len(self.splits)

    @property
    def chart_data(self) -> SimulationChartData:
        """Return plot-ready chart data for the simulation."""
        return self.summary.chart_data

    @property
    def html(self) -> str:
        """Return the rendered HTML report."""
        return self.summary.html

    def to_frame(self) -> pd.DataFrame:
        """Return fold-level simulation metadata as a pandas DataFrame."""
        return self.summary.to_frame()

    def to_dict(self) -> dict[str, object]:
        """Return a serializable dictionary representation."""
        return {
            **self.summary.to_dict(),
            "engine": self.engine_metadata.to_dict(),
        }

    def write_html(self, path: str | Path) -> Path:
        """Write the rendered HTML report to disk."""
        return self.summary.write_html(path)

    def iter_splits(self) -> Iterator[TimeSplit]:
        """Iterate over materialized fold objects."""
        return iter(self.splits)


class TemporalSimulation:
    """High-level interface for executing a complete temporal simulation.

    Args:
        time_col: Timeline column name, column position or ``TemporalSemanticsSpec``
            describing the timeline, ordering column and per-segment eligibility columns.
        partition: High-level definition of the train/test or train/validation/test layout.
        step: Amount by which the simulation advances after each fold.
        strategy: Simulation policy. Use ``"single"``, ``"rolling"`` or ``"expanding"``.
        allow_partial: Whether to keep the last fold when the final evaluation segment
            would otherwise run past the end of the dataset.
        engine: Internal partition engine preference. Use ``"auto"`` to let Jano choose
            the safest native backend, or force ``"pandas"``, ``"polars"`` or ``"numpy"``.
        start_at: Optional lower bound for the simulation timeline. Rows strictly before
            this timestamp are excluded before folds are generated.
        end_at: Optional upper bound for the simulation timeline. Rows strictly after
            this timestamp are excluded before folds are generated.
        max_folds: Optional maximum number of folds to materialize.
    """

    def __init__(
        self,
        time_col: str | int | TemporalSemanticsSpec,
        partition: TemporalPartitionSpec,
        step,
        strategy: str = "rolling",
        allow_partial: bool = False,
        engine: str = "auto",
        start_at: object | None = None,
        end_at: object | None = None,
        max_folds: int | None = None,
    ) -> None:
        self.splitter = TemporalBacktestSplitter(
            time_col=time_col,
            partition=partition,
            step=step,
            strategy=strategy,
            allow_partial=allow_partial,
            engine=engine,
        )
        self.start_at = pd.Timestamp(start_at) if start_at is not None else None
        self.end_at = pd.Timestamp(end_at) if end_at is not None else None
        if max_folds is not None and max_folds <= 0:
            raise ValueError("max_folds must be greater than zero")
        self.max_folds = max_folds

    @property
    def time_col(self):
        """Return the timeline column configured for the simulation."""
        return self.splitter.time_col

    @property
    def partition(self):
        """Return the validated partition configuration used by the simulation."""
        return self.splitter.partition

    @property
    def temporal_semantics(self) -> TemporalSemanticsSpec:
        """Return the temporal semantics used by the simulation."""
        return self.splitter.temporal_semantics

    def as_splitter(self) -> TemporalBacktestSplitter:
        """Return the underlying low-level splitter."""
        return self.splitter

    def run(
        self,
        X: pd.DataFrame,
        output_path: str | Path | None = None,
        title: str | None = None,
    ) -> SimulationResult:
        """Execute the configured simulation over ``X`` and materialize its folds.

        Args:
            X: Input dataset as ``pandas.DataFrame``, ``numpy.ndarray`` or
                ``polars.DataFrame``.
            output_path: Optional filesystem path where the rendered HTML report should
                be written.
            title: Optional title used in the returned report outputs.

        Returns:
            A ``SimulationResult`` containing the materialized folds and their summary.
        """
        selected = self._select_input(X)
        splits = list(self.splitter.iter_splits(selected))
        if self.max_folds is not None:
            splits = splits[: self.max_folds]
        if not splits:
            raise ValueError("The current configuration did not produce any valid folds")
        engine = self.splitter._build_engine(selected)
        frame = engine.to_pandas()
        summary = build_simulation_summary(
            splits=splits,
            frame=frame,
            time_col=self.time_col,
            title=title or "Jano simulation summary",
        )
        if output_path is not None:
            summary.write_html(output_path)
        return SimulationResult(
            frame=frame,
            splits=splits,
            summary=summary,
            engine_metadata=engine.metadata,
        )

    def plan(
        self,
        X: pd.DataFrame,
        title: str | None = None,
    ) -> SimulationPlan:
        """Precompute the simulation geometry before materializing any folds.

        Args:
            X: Input dataset as ``pandas.DataFrame``, ``numpy.ndarray`` or
                ``polars.DataFrame``.
            title: Optional title used when the plan is later described or rendered.

        Returns:
            A ``SimulationPlan`` with fold boundaries and row counts.
        """
        selected = self._select_input(X)
        plan = self.splitter.plan(selected)
        if self.max_folds is not None:
            plan = plan.select_until_iteration(self.max_folds - 1)
        if plan.total_folds == 0:
            raise ValueError("The current configuration did not produce any valid folds")
        return SimulationPlan(partition_plan=plan, title=title or "Jano simulation summary")

    def _select_input(self, X):
        engine = self.splitter._build_engine(X)
        if self.start_at is None and self.end_at is None:
            return X

        frame = engine.to_pandas()
        timestamps = pd.to_datetime(frame[self._timeline_column_name(frame)])
        mask = pd.Series(True, index=frame.index)
        if self.start_at is not None:
            mask &= timestamps >= self.start_at
        if self.end_at is not None:
            mask &= timestamps <= self.end_at

        filtered = frame.loc[mask].copy()
        if filtered.empty:
            raise ValueError("The configured simulation window does not contain any rows")
        return filtered

    def _timeline_column_name(self, frame: pd.DataFrame):
        column = self.temporal_semantics.timeline_col
        if isinstance(column, int):
            return frame.columns[column]
        return column
