from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterator, List, Tuple

import numpy as np
import pandas as pd

from .engines import PartitionEngine
from .planning import PartitionPlan, PlannedFold
from .reporting import SimulationChartData, SimulationSummary, build_simulation_summary
from .slicing import TimeIndexer
from .splits import TimeSplit
from .types import SegmentBoundaries, SizeSpec, TemporalPartitionSpec, TemporalSemanticsSpec
from .validation import (
    ValidatedPartitionSpec,
    validate_partition_spec,
    validate_strategy,
    validate_temporal_semantics,
)


@dataclass(frozen=True)
class _SegmentOffsets:
    name: str
    start: object
    end: object


class TemporalBacktestSplitter:
    """Flexible temporal splitter for single or repeated temporal backtests.

    Args:
        time_col: Timeline column name, column position or ``TemporalSemanticsSpec``
            describing the timeline, ordering column and per-segment eligibility columns.
        partition: High-level definition of the train/test or train/validation/test layout.
        step: Amount by which the simulation advances after each fold. It must use the
            same unit family as the partition sizes.
        strategy: Simulation policy. Use ``"single"`` for one split, ``"rolling"`` for
            fixed-size windows or ``"expanding"`` for growing training history.
        allow_partial: Whether to keep the last fold when the final evaluation segment
            would otherwise run past the end of the dataset.
        engine: Internal partition engine preference. Use ``"auto"`` to let Jano choose
            the safest native backend, or force ``"pandas"``, ``"polars"`` or ``"numpy"``.
    """

    def __init__(
        self,
        time_col: str | int | TemporalSemanticsSpec,
        partition: TemporalPartitionSpec,
        step,
        strategy: str = "rolling",
        allow_partial: bool = False,
        engine: str = "auto",
    ) -> None:
        if isinstance(time_col, TemporalSemanticsSpec):
            self.temporal_semantics = validate_temporal_semantics(time_col)
        else:
            self.temporal_semantics = validate_temporal_semantics(
                TemporalSemanticsSpec(timeline_col=time_col)
            )
        self.time_col = self.temporal_semantics.timeline_col
        self.partition = validate_partition_spec(partition)
        self.step = SizeSpec.from_value(step)
        self.strategy = validate_strategy(strategy)
        self.allow_partial = allow_partial
        if engine not in {"auto", "pandas", "polars", "numpy"}:
            raise ValueError("engine must be one of 'auto', 'pandas', 'polars' or 'numpy'")
        self.engine = engine

        if self.partition.size_kind != self.step.kind:
            raise ValueError("step must use the same unit family as the partition sizes")
        if self.partition.size_kind != "duration" and self._uses_custom_segment_times:
            raise ValueError(
                "Per-segment temporal semantics currently require duration-based sizes and steps"
            )

    @property
    def _uses_custom_segment_times(self) -> bool:
        return any(
            self.temporal_semantics.column_for_segment(name) != self.time_col
            for name in self.partition.segments
        )

    def split(self, X, y=None, groups=None) -> Iterator[Tuple[np.ndarray, ...]]:
        """Yield each fold as a plain tuple of positional index arrays.

        Args:
            X: Input dataset as ``pandas.DataFrame``, ``numpy.ndarray`` or
                ``polars.DataFrame``.
            y: Unused placeholder for scikit-learn compatibility.
            groups: Unused placeholder for scikit-learn compatibility.

        Yields:
            Tuples of NumPy arrays ordered by the configured segment names.
        """
        for split in self.iter_splits(X, y=y, groups=groups):
            ordered_names = list(split.segments.keys())
            yield tuple(split.segments[name] for name in ordered_names)

    def iter_splits(self, X, y=None, groups=None) -> Iterator[TimeSplit]:
        """Yield rich ``TimeSplit`` objects for each fold in the simulation.

        Args:
            X: Input dataset as ``pandas.DataFrame``, ``numpy.ndarray`` or
                ``polars.DataFrame``.
            y: Unused placeholder for scikit-learn compatibility.
            groups: Unused placeholder for scikit-learn compatibility.

        Yields:
            ``TimeSplit`` instances containing segment indices, boundaries and metadata.
        """
        engine = self._build_engine(X)
        indexer = TimeIndexer(engine=engine, semantics=self.temporal_semantics)

        if self.partition.size_kind == "duration":
            yield from self._iter_duration_splits(indexer)
        else:
            yield from self._iter_positional_splits(indexer)

    def get_n_splits(self, X=None, y=None, groups=None) -> int:
        """Return the number of valid folds generated for ``X``.

        Args:
            X: Input dataset as ``pandas.DataFrame``, ``numpy.ndarray`` or
                ``polars.DataFrame``.
            y: Unused placeholder for scikit-learn compatibility.
            groups: Unused placeholder for scikit-learn compatibility.

        Returns:
            Total number of folds that would be produced by ``iter_splits``.
        """
        if X is None:
            raise ValueError("X is required to compute the number of splits")
        return sum(1 for _ in self.iter_splits(X, y=y, groups=groups))

    def plan(self, X) -> PartitionPlan:
        """Precompute the temporal geometry without materializing train/test slices.

        Args:
            X: Input dataset as ``pandas.DataFrame``, ``numpy.ndarray`` or
                ``polars.DataFrame``.

        Returns:
            A ``PartitionPlan`` containing fold boundaries and row counts.
        """
        engine = self._build_engine(X)
        indexer = TimeIndexer(engine=engine, semantics=self.temporal_semantics)
        if self.partition.size_kind == "duration":
            folds = list(self._plan_duration_splits(indexer))
        else:
            folds = list(self._plan_positional_splits(indexer))
        if not folds:
            raise ValueError("The current configuration did not produce any valid folds")
        return PartitionPlan(
            frame=X,
            temporal_semantics=self.temporal_semantics,
            strategy=self.strategy,
            size_kind=self.partition.size_kind,
            folds=folds,
            engine=engine,
        )

    def describe_simulation(
        self,
        X: pd.DataFrame,
        output_path: str | Path | None = None,
        title: str | None = None,
        output: str = "summary",
    ) -> SimulationSummary | SimulationChartData | str:
        """Describe a simulation over a concrete dataset.

        Args:
            X: Input dataset as ``pandas.DataFrame``, ``numpy.ndarray`` or
                ``polars.DataFrame``.
            output_path: Optional filesystem path where the rendered HTML report should
                be written.
            title: Optional title used in the returned report outputs.
            output: Output mode. Use ``"summary"`` for ``SimulationSummary``,
                ``"html"`` for a rendered HTML string or ``"chart_data"`` for
                plot-ready Python data.

        Returns:
            A ``SimulationSummary``, raw HTML string or ``SimulationChartData``
            depending on ``output``.
        """
        engine = self._build_engine(X)
        frame = engine.to_pandas()
        splits = list(self.iter_splits(X))
        if not splits:
            raise ValueError("The current configuration did not produce any valid folds")

        summary = build_simulation_summary(
            splits=splits,
            frame=frame,
            time_col=self.time_col,
            title=title or "Jano simulation summary",
        )

        if output_path is not None:
            summary.write_html(output_path)

        if output == "summary":
            return summary
        if output == "html":
            return summary.html
        if output == "chart_data":
            return summary.chart_data
        raise ValueError("output must be one of 'summary', 'html' or 'chart_data'")

    def _build_engine(self, X) -> PartitionEngine:
        engine = PartitionEngine.from_input(X, prefer=self.engine)
        if engine.empty:
            raise ValueError("X must contain at least one row")
        return engine

    def _iter_duration_splits(self, indexer: TimeIndexer) -> Iterator[TimeSplit]:
        for planned in self._plan_duration_splits(indexer):
            segments = {
                name: indexer.slice_between_for_segment(name, boundary.start, boundary.end)
                for name, boundary in planned.boundaries.items()
            }
            yield TimeSplit(
                fold=planned.iteration,
                segments=segments,
                boundaries=planned.boundaries,
                metadata={**planned.metadata, "strategy": self.strategy, "size_kind": self.partition.size_kind},
            )

    def _plan_duration_splits(self, indexer: TimeIndexer) -> Iterator[PlannedFold]:
        segment_names = list(self.partition.segments.keys())
        segment_sizes = self.partition.segments
        gap_sizes = self.partition.gaps
        tail_gap = self.partition.tail_gap

        start = self._initial_duration_start(indexer)
        fold = 0

        while True:
            cursor = start
            train_start = indexer.min_time if self.strategy == "expanding" else start
            boundaries: Dict[str, SegmentBoundaries] = {}
            is_partial = False

            for name in segment_names:
                gap = gap_sizes.get(name)
                if gap is not None:
                    cursor = cursor + gap.value

                if name == "train":
                    segment_start = train_start + gap.value if gap is not None else train_start
                    if self.strategy == "expanding":
                        segment_end = start + segment_sizes[name].value
                        if segment_end <= segment_start:
                            segment_end = segment_start + segment_sizes[name].value
                    else:
                        segment_end = segment_start + segment_sizes[name].value
                else:
                    segment_start = cursor
                    segment_end = segment_start + segment_sizes[name].value
                boundaries[name] = SegmentBoundaries(start=segment_start, end=segment_end)
                cursor = segment_end

            last_end = boundaries[segment_names[-1]].end
            if tail_gap is not None:
                last_end = last_end + tail_gap.value
            if last_end > indexer.max_time:
                if self.allow_partial and boundaries[segment_names[-1]].start < indexer.max_time:
                    boundaries[segment_names[-1]] = SegmentBoundaries(
                        start=boundaries[segment_names[-1]].start,
                        end=indexer.max_time + pd.Timedelta(microseconds=1),
                    )
                    is_partial = True
                else:
                    break

            counts = {
                name: int(len(indexer.slice_between_for_segment(name, boundary.start, boundary.end)))
                for name, boundary in boundaries.items()
            }
            if not self._is_valid_count_map(counts):
                break

            yield PlannedFold(
                iteration=fold,
                boundaries=boundaries,
                counts=counts,
                metadata={"is_partial": is_partial},
            )

            fold += 1
            if self.strategy == "single":
                break
            start = start + self.step.value

    def _initial_duration_start(self, indexer: TimeIndexer) -> pd.Timestamp:
        if self.partition.calendar_frequency is None:
            return indexer.min_time
        return indexer.min_time.floor(self.partition.calendar_frequency)

    def _iter_positional_splits(self, indexer: TimeIndexer) -> Iterator[TimeSplit]:
        for planned in self._plan_positional_splits(indexer):
            segments = {
                name: indexer.slice_between_for_segment(name, boundary.start, boundary.end)
                if self.partition.size_kind == "duration"
                else indexer.slice_positional(*planned.metadata["positions"][name])
                for name, boundary in planned.boundaries.items()
            }
            metadata = {k: v for k, v in planned.metadata.items() if k != "positions"}
            yield TimeSplit(
                fold=planned.iteration,
                segments=segments,
                boundaries=planned.boundaries,
                metadata={**metadata, "strategy": self.strategy, "size_kind": self.partition.size_kind},
            )

    def _plan_positional_splits(self, indexer: TimeIndexer) -> Iterator[PlannedFold]:
        total_rows = indexer.total_rows
        sizes = {
            name: self._resolve_position_size(spec, total_rows)
            for name, spec in self.partition.segments.items()
        }
        gaps = {
            name: self._resolve_position_size(spec, total_rows)
            for name, spec in self.partition.gaps.items()
        }
        step = self._resolve_position_size(self.step, total_rows)
        tail_gap = self._resolve_position_size(self.partition.tail_gap, total_rows) if self.partition.tail_gap is not None else 0
        fold = 0
        start = 0
        segment_names = list(self.partition.segments.keys())

        while True:
            cursor = 0 if self.strategy == "expanding" else start
            boundaries: Dict[str, SegmentBoundaries] = {}
            positions: Dict[str, Tuple[int, int]] = {}
            is_partial = False

            for name in segment_names:
                if name == "train" and self.strategy == "expanding":
                    segment_start = gaps.get("train", 0)
                    segment_end = sizes[name] + (fold * step)
                else:
                    cursor += gaps.get(name, 0)
                    segment_start = cursor
                    segment_end = segment_start + sizes[name]
                positions[name] = (segment_start, segment_end)
                boundaries[name] = SegmentBoundaries(
                    start=indexer.timestamp_at(min(segment_start, total_rows - 1)),
                    end=indexer.timestamp_at(min(segment_end - 1, total_rows - 1)),
                )
                cursor = segment_end

            if positions[segment_names[-1]][1] + tail_gap > total_rows:
                if self.allow_partial:
                    last_name = segment_names[-1]
                    segment_start, _ = positions[last_name]
                    if segment_start >= total_rows:
                        break
                    positions[last_name] = (segment_start, total_rows)
                    boundaries[last_name] = SegmentBoundaries(
                        start=indexer.timestamp_at(segment_start),
                        end=indexer.max_time,
                    )
                    is_partial = True
                else:
                    break

            counts = {name: int(pos[1] - pos[0]) for name, pos in positions.items()}
            if not self._is_valid_count_map(counts):
                break

            yield PlannedFold(
                iteration=fold,
                boundaries=boundaries,
                counts=counts,
                metadata={"is_partial": is_partial, "positions": positions},
            )

            fold += 1
            if self.strategy == "single":
                break
            start += step

    @staticmethod
    def _is_valid_segments(segments: Dict[str, np.ndarray]) -> bool:
        return all(len(index) > 0 for index in segments.values())

    @staticmethod
    def _is_valid_count_map(counts: Dict[str, int]) -> bool:
        return all(count > 0 for count in counts.values())

    @staticmethod
    def _resolve_position_size(spec: SizeSpec, total_rows: int) -> int:
        if spec.kind == "rows":
            return int(spec.value)
        resolved = int(round(total_rows * float(spec.value)))
        if resolved <= 0:
            raise ValueError("Fractional sizes resolved to zero rows; choose larger fractions")
        return resolved
