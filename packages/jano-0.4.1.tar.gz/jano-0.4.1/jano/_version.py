"""Package version metadata."""

__version__ = "0.4.1"
