# mcparmory-atlassian-confluence

MCP server for The Confluence Cloud REST API.

Full version coming soon. See [mcparmory.com](https://mcparmory.com)
