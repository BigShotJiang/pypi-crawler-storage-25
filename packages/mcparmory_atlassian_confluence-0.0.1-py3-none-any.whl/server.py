"""MCP server for The Confluence Cloud REST API — placeholder."""

def main() -> None:
    print("mcparmory-atlassian-confluence: full server coming soon. See https://mcparmory.com")

if __name__ == "__main__":
    main()
