import os
import sys
from typing import Any, Dict, Optional


def _load_toml(path: str) -> Dict[str, Any]:
    if sys.version_info >= (3, 11):
        import tomllib
        with open(path, "rb") as f:
            return tomllib.load(f)
    try:
        import tomli
    except ImportError as exc:
        raise RuntimeError(
            "Reading TOML config on Python < 3.11 requires 'tomli'. "
            "Install with: pip install tomli"
        ) from exc
    with open(path, "rb") as f:
        return tomli.load(f)


def find_config(start: Optional[str] = None) -> Optional[str]:
    """Walk up from `start` (or CWD) looking for pyproject.toml."""
    cur = os.path.abspath(start or os.getcwd())
    while True:
        candidate = os.path.join(cur, "pyproject.toml")
        if os.path.isfile(candidate):
            return candidate
        parent = os.path.dirname(cur)
        if parent == cur:
            return None
        cur = parent


def load_config(path: Optional[str] = None) -> Dict[str, Any]:
    """Read [tool.autolog] from pyproject.toml.

    Returns an empty dict if no config or section is found, so callers can
    treat all keys as optional with `cfg.get(...)`.
    """
    if path is None:
        path = find_config()
    if path is None or not os.path.isfile(path):
        return {}
    try:
        data = _load_toml(path)
    except Exception:
        return {}
    return data.get("tool", {}).get("autolog", {}) or {}
