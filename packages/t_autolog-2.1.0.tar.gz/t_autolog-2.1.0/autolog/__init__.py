import logging as _logging
from typing import List, Mapping, Optional, Sequence, Union

from autolog._context import (
    bind,
    get_bound_fields,
    get_trace_id,
    new_trace_id,
    set_trace_id,
    unbind,
)
from autolog._decorator import log, log_class, log_function
from autolog._logger import get_logger
from autolog._patcher import install_import_hook as _hook
from autolog._patcher import patch_module
from autolog._wrapper import no_log


def start(
    packages: Optional[List[str]] = None,
    *,
    exclude: Optional[Sequence[str]] = None,
    service: Optional[str] = None,
    level: Union[str, Mapping[str, str]] = "INFO",
    format: str = "pretty",
    log_file: Optional[str] = None,
    sample: float = 1.0,
    config: Optional[str] = None,
):
    """Start autolog. The single entry point — replaces install/install_from_config.

    Resolution order (highest priority first):
      1. kwargs to start()
      2. environment variables (AUTOLOG_LEVEL, AUTOLOG_FILE, ...)
      3. [tool.autolog] in pyproject.toml
      4. defaults

    Args:
        packages : list of top-level package names. If None and no config.packages, auto-discovers.
        exclude  : glob patterns to skip (e.g. ["myapp.hot.*", "*.cache.*"]).
        service  : service name shown in logs.
        level    : either a level string ("DEBUG"/"INFO"/...) or a dict mapping
                   package prefix → level, e.g. {"myapp": "DEBUG", "default": "INFO"}.
        format   : "pretty" (default, human-readable) or "json" (one JSON object per line).
        log_file : path to mirror logs to a rotating file.
        sample   : 0.0-1.0. Fraction of calls to log. 1.0 = log everything.
        config   : explicit path to pyproject.toml. None = walk up from CWD.

    Examples:
        autolog.start()                              # auto-discover, defaults
        autolog.start(["myapp"], format="json")      # explicit packages, JSON output
        autolog.start(level={"myapp": "DEBUG", "default": "WARN"})
        autolog.start(exclude=["myapp.hot_path.*"])
    """
    from autolog._config import load_config
    from autolog._discovery import discover_packages

    cfg = load_config(config)

    resolved_packages = packages if packages is not None else cfg.get("packages")
    if not resolved_packages:
        resolved_packages = discover_packages()

    if not resolved_packages:
        _logging.warning(
            "[autolog] No packages to instrument. "
            "Pass packages=[...] or add [tool.autolog] to pyproject.toml."
        )
        return

    resolved_exclude = list(exclude) if exclude is not None else list(cfg.get("exclude", []))
    resolved_service = service or cfg.get("service") or resolved_packages[0]
    resolved_level = level if level != "INFO" else cfg.get("level", "INFO")
    resolved_format = format if format != "pretty" else cfg.get("format", "pretty")
    resolved_log_file = log_file or cfg.get("log_file")
    resolved_sample = sample if sample != 1.0 else float(cfg.get("sample", 1.0))

    _hook(
        resolved_packages,
        service=resolved_service,
        level=resolved_level,
        log_file=resolved_log_file,
        format=resolved_format,
        sample=resolved_sample,
        exclude=resolved_exclude,
    )


def install(packages=None, *, service=None, level="INFO", log_file=None):
    """Deprecated alias for start(). Kept for backward compatibility."""
    return start(packages=packages, service=service, level=level, log_file=log_file)


def install_from_config(path=None):
    """Deprecated alias for start(config=path). Kept for backward compatibility."""
    return start(config=path)


__all__ = [
    "start",
    "install",
    "install_from_config",
    "log",
    "log_function",
    "log_class",
    "no_log",
    "bind",
    "unbind",
    "get_bound_fields",
    "patch_module",
    "get_logger",
    "new_trace_id",
    "get_trace_id",
    "set_trace_id",
]
