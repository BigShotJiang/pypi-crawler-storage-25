import uuid
from contextvars import ContextVar
from typing import Any, Dict

_trace_id_var: ContextVar[str] = ContextVar("trace_id", default="-")
_bound_fields_var: ContextVar[Dict[str, Any]] = ContextVar("bound_fields", default={})


def new_trace_id() -> str:
    tid = str(uuid.uuid4())
    _trace_id_var.set(tid)
    return tid


def get_trace_id() -> str:
    return _trace_id_var.get()


def set_trace_id(trace_id: str) -> None:
    _trace_id_var.set(trace_id)


def bind(**fields: Any) -> None:
    """Attach fields to every log record emitted in this async context."""
    if not fields:
        return
    current = dict(_bound_fields_var.get())
    current.update(fields)
    _bound_fields_var.set(current)


def unbind(*keys: str) -> None:
    """Remove specific bound fields. With no args, clears all bindings."""
    if not keys:
        _bound_fields_var.set({})
        return
    current = dict(_bound_fields_var.get())
    for k in keys:
        current.pop(k, None)
    _bound_fields_var.set(current)


def get_bound_fields() -> Dict[str, Any]:
    return dict(_bound_fields_var.get())
