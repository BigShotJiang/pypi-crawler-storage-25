import json
import logging
import re
import sys
from datetime import datetime

SEPARATOR = "─" * 60

SENSITIVE_KEYS = frozenset([
    "password", "passwd", "token", "secret", "auth",
    "credential", "credentials", "apikey", "jwt", "bearer",
    "api_key", "access_token", "refresh_token", "private_key",
])

_TOKEN_SPLIT = re.compile(r"[_\-.\s]+|(?<=[a-z])(?=[A-Z])")

_ANSI_RESET = "\033[0m"
_LEVEL_COLORS = {
    "DEBUG":   "\033[36m",
    "INFO":    "\033[32m",
    "WARNING": "\033[33m",
    "ERROR":   "\033[31m",
}
_LEVEL_ABBREV = {
    "DEBUG":   "DEBUG",
    "INFO":    "INFO ",
    "WARNING": "WARN ",
    "ERROR":   "ERROR",
}

_MISSING = object()


def _is_sensitive(key: str) -> bool:
    """Match if any whole token in the key (split on _ - . space and camelCase) is sensitive."""
    if not key:
        return False
    tokens = [t.lower() for t in _TOKEN_SPLIT.split(key) if t]
    if any(t in SENSITIVE_KEYS for t in tokens):
        return True
    joined = "_".join(tokens)
    return joined in SENSITIVE_KEYS


def _redact_sensitive(val):
    if isinstance(val, dict):
        return {
            k: "[REDACTED]" if _is_sensitive(str(k)) else _redact_sensitive(v)
            for k, v in val.items()
        }
    if isinstance(val, list):
        return [_redact_sensitive(item) for item in val]
    if isinstance(val, tuple):
        return tuple(_redact_sensitive(item) for item in val)
    return val


def _to_json(val, max_len: int) -> str:
    try:
        s = json.dumps(val, ensure_ascii=False, default=str)
    except Exception:
        try:
            s = repr(val)
        except Exception as e:
            s = f"<unrepresentable: {type(val).__name__}>"
    if len(s) > max_len:
        return s[:max_len] + "..."
    return s


class AutoLogFormatter(logging.Formatter):
    def __init__(self, use_color: bool = False, max_repr_len: int = 300):
        super().__init__()
        self.use_color = use_color
        self.max_repr_len = max_repr_len

    def format(self, record: logging.LogRecord) -> str:
        try:
            return self._format_record(record)
        except Exception as exc:
            return f"[autolog formatter error: {exc}] {record.getMessage()}"

    def _format_record(self, record: logging.LogRecord) -> str:
        ts = (
            datetime.fromtimestamp(record.created).strftime("%Y-%m-%d %H:%M:%S.")
            + f"{int(record.msecs):03d}"
        )
        level_name = record.levelname
        level_abbrev = _LEVEL_ABBREV.get(level_name, level_name[:5].ljust(5))
        location = getattr(record, "func_location", record.name)

        if self.use_color:
            color = _LEVEL_COLORS.get(level_name, "")
            level_str = f"{color}[{level_abbrev}]{_ANSI_RESET}"
        else:
            level_str = f"[{level_abbrev}]"

        lines = [f"[{ts}] {level_str} [{location}]"]

        trace_id = getattr(record, "trace_id", "-")
        lines.append(f"  ▸ trace    : {trace_id}")

        inputs_repr = getattr(record, "func_inputs", _MISSING)
        if inputs_repr is not _MISSING and inputs_repr is not None:
            lines.append(f"  ▸ inputs   : {inputs_repr}")

        result = getattr(record, "func_result", _MISSING)
        if result is not _MISSING:
            lines.append(f"  ▸ result   : {result}")

        error = getattr(record, "func_error", None)
        if error is not None:
            lines.append(f"  ▸ error    : {error}")

        duration = getattr(record, "func_duration", None)
        if duration is not None:
            lines.append(f"  ▸ duration : {duration:.4f} s")

        tb = getattr(record, "func_traceback", None)
        if tb:
            lines.append("  ▸ traceback:")
            for tb_line in tb.rstrip().splitlines():
                lines.append(f"      {tb_line}")

        bound = getattr(record, "func_bound", None)
        if bound:
            for k, v in bound.items():
                lines.append(f"  ▸ {k:<8} : {v}")

        lines.append(SEPARATOR)
        return "\n".join(lines)


class JsonFormatter(logging.Formatter):
    """One JSON object per line — for production log shippers (Datadog, Loki, ELK)."""

    def __init__(self, max_repr_len: int = 300):
        super().__init__()
        self.max_repr_len = max_repr_len

    def format(self, record: logging.LogRecord) -> str:
        try:
            return self._format_record(record)
        except Exception as exc:
            return json.dumps({
                "ts": datetime.fromtimestamp(record.created).isoformat(),
                "level": record.levelname,
                "message": record.getMessage(),
                "formatter_error": str(exc),
            })

    def _format_record(self, record: logging.LogRecord) -> str:
        payload = {
            "ts":        datetime.fromtimestamp(record.created).isoformat(),
            "level":     record.levelname,
            "location":  getattr(record, "func_location", record.name),
            "trace_id":  getattr(record, "trace_id", None),
        }

        inputs_repr = getattr(record, "func_inputs", _MISSING)
        if inputs_repr is not _MISSING and inputs_repr is not None:
            payload["inputs"] = _safe_decode_json(inputs_repr)

        result = getattr(record, "func_result", _MISSING)
        if result is not _MISSING:
            payload["result"] = _safe_decode_json(result)

        error = getattr(record, "func_error", None)
        if error is not None:
            payload["error"] = error

        duration = getattr(record, "func_duration", None)
        if duration is not None:
            payload["duration_s"] = round(duration, 6)

        tb = getattr(record, "func_traceback", None)
        if tb:
            payload["traceback"] = tb.rstrip()

        bound = getattr(record, "func_bound", None)
        if bound:
            payload.update(bound)

        return json.dumps(payload, ensure_ascii=False, default=str)


def _safe_decode_json(s):
    """Try to inline-parse a JSON string field so it nests cleanly in the JSON log line."""
    if not isinstance(s, str):
        return s
    try:
        return json.loads(s)
    except (ValueError, TypeError):
        return s


class CompactFormatter(logging.Formatter):
    """Single line per log entry. Easy to grep, easy to skim."""

    def __init__(self, use_color: bool = False, max_repr_len: int = 300):
        super().__init__()
        self.use_color = use_color
        self.max_repr_len = max_repr_len

    def format(self, record: logging.LogRecord) -> str:
        try:
            return self._format_record(record)
        except Exception as exc:
            return f"[autolog formatter error: {exc}] {record.getMessage()}"

    def _format_record(self, record: logging.LogRecord) -> str:
        ts = (
            datetime.fromtimestamp(record.created).strftime("%Y-%m-%d %H:%M:%S.")
            + f"{int(record.msecs):03d}"
        )
        level_name = record.levelname
        level_abbrev = _LEVEL_ABBREV.get(level_name, level_name[:5].ljust(5))
        location = getattr(record, "func_location", record.name)

        if self.use_color:
            color = _LEVEL_COLORS.get(level_name, "")
            level_str = f"{color}[{level_abbrev}]{_ANSI_RESET}"
        else:
            level_str = f"[{level_abbrev}]"

        parts = [f"[{ts}] {level_str} [{location}]"]

        trace_id = getattr(record, "trace_id", None)
        if trace_id and trace_id != "-":
            parts.append(f"trace={trace_id}")

        inputs_repr = getattr(record, "func_inputs", _MISSING)
        if inputs_repr is not _MISSING and inputs_repr is not None:
            parts.append(f"in={inputs_repr}")

        result = getattr(record, "func_result", _MISSING)
        if result is not _MISSING:
            parts.append(f"out={result}")

        error = getattr(record, "func_error", None)
        if error is not None:
            parts.append(f"err={error}")

        duration = getattr(record, "func_duration", None)
        if duration is not None:
            parts.append(f"{duration*1000:.1f}ms")

        bound = getattr(record, "func_bound", None)
        if bound:
            for k, v in bound.items():
                parts.append(f"{k}={v}")

        return " ".join(parts)


def make_formatter(format_kind: str, *, use_color: bool = False, max_repr_len: int = 300):
    """Factory: 'pretty', 'compact', or 'json'."""
    if format_kind == "json":
        return JsonFormatter(max_repr_len=max_repr_len)
    if format_kind == "compact":
        return CompactFormatter(use_color=use_color, max_repr_len=max_repr_len)
    return AutoLogFormatter(use_color=use_color, max_repr_len=max_repr_len)
