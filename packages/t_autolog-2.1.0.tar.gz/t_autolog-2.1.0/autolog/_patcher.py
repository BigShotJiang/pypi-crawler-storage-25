import fnmatch
import importlib.abc
import importlib.util
import inspect
import logging
import os
import sys
from typing import List, Mapping, Optional, Sequence, Union

from autolog._decorator import log_class, _make_wrapper


def _is_excluded(name: str, patterns: Sequence[str]) -> bool:
    return any(fnmatch.fnmatchcase(name, p) for p in patterns)


def patch_module(
    module,
    *,
    recursive: bool = True,
    exclude: Sequence[str] = (),
    level: Union[str, Mapping[str, str]] = "INFO",
    log_file: Optional[str] = None,
    service: Optional[str] = None,
    format: str = "pretty",
    sample: float = 1.0,
) -> None:
    module_name = module.__name__
    if _is_excluded(module_name, exclude):
        return

    for attr_name in dir(module):
        if attr_name.startswith("_"):
            continue

        try:
            obj = getattr(module, attr_name)
        except AttributeError:
            continue

        if getattr(obj, "__module__", None) != module_name:
            continue

        full_name = f"{module_name}.{attr_name}"
        if _is_excluded(full_name, exclude):
            continue

        if inspect.isfunction(obj):
            try:
                setattr(module, attr_name, _make_wrapper(
                    obj, service=service, level=level, log_file=log_file,
                    format=format, sample=sample,
                ))
            except (AttributeError, TypeError):
                pass
        elif inspect.isclass(obj) and recursive:
            log_class(obj, sample=sample)


class _AutoLogLoader(importlib.abc.Loader):
    def __init__(self, original_loader, *, options: dict):
        self._original_loader = original_loader
        self._options = options

    def create_module(self, spec):
        if hasattr(self._original_loader, "create_module"):
            return self._original_loader.create_module(spec)
        return None

    def exec_module(self, module):
        self._original_loader.exec_module(module)
        try:
            patch_module(module, **self._options)
        except Exception as exc:
            logging.warning(f"[autolog] Failed to patch module {module.__name__!r}: {exc}")


class _AutoLogFinder(importlib.abc.MetaPathFinder):
    def __init__(self, packages: List[str], *, options: dict):
        self._packages = list(packages)
        self._options = options

    def find_spec(self, fullname, path, target=None):
        if not any(
            fullname == p or fullname.startswith(p + ".") for p in self._packages
        ):
            return None
        if _is_excluded(fullname, self._options.get("exclude", ())):
            return None

        for finder in sys.meta_path:
            if finder is self:
                continue
            find_spec_fn = getattr(finder, "find_spec", None)
            if find_spec_fn is None:
                continue
            try:
                spec = find_spec_fn(fullname, path, target)
            except Exception:
                continue
            if spec and spec.loader:
                spec.loader = _AutoLogLoader(spec.loader, options=self._options)
                return spec
        return None


def install_import_hook(
    packages: List[str],
    *,
    service: Optional[str] = None,
    level: Union[str, Mapping[str, str]] = "INFO",
    log_file: Optional[str] = None,
    format: str = "pretty",
    sample: float = 1.0,
    exclude: Sequence[str] = (),
) -> None:
    if os.environ.get("AUTOLOG_DISABLE"):
        logging.info("[autolog] AUTOLOG_DISABLE is set; install() is a no-op.")
        return

    options = {
        "service":  service,
        "level":    level,
        "log_file": log_file,
        "format":   format,
        "sample":   sample,
        "exclude":  tuple(exclude),
    }

    for mod_name, mod in list(sys.modules.items()):
        if mod is None:
            continue
        if any(mod_name == p or mod_name.startswith(p + ".") for p in packages):
            try:
                patch_module(mod, **options)
            except Exception as exc:
                logging.warning(
                    f"[autolog] Failed to retroactively patch {mod_name!r}: {exc}"
                )

    existing = next(
        (f for f in sys.meta_path if isinstance(f, _AutoLogFinder)), None
    )
    if existing is not None:
        for p in packages:
            if p not in existing._packages:
                existing._packages.append(p)
        merged_exclude = tuple(set(existing._options.get("exclude", ())) | set(options["exclude"]))
        existing._options["exclude"] = merged_exclude
        return

    sys.meta_path.insert(0, _AutoLogFinder(packages, options=options))
