import os
from typing import List, Optional, Sequence

_DEFAULT_EXCLUDE = frozenset({
    "tests", "test", "__pycache__", "venv", ".venv", "env", ".env",
    "build", "dist", "node_modules", ".git", ".tox", ".mypy_cache",
    ".pytest_cache", "docs", "doc", "examples", "scripts",
    "site-packages", ".idea", ".vscode", ".github",
})


def discover_packages(
    root: Optional[str] = None,
    *,
    exclude: Sequence[str] = (),
) -> List[str]:
    """Find all top-level Python packages (folders with __init__.py) in `root`.

    Skips hidden, underscore-prefixed, and well-known non-source directories.
    """
    root = os.path.abspath(root or os.getcwd())
    excluded = _DEFAULT_EXCLUDE | set(exclude)

    try:
        entries = os.listdir(root)
    except OSError:
        return []

    packages = []
    for name in sorted(entries):
        if name.startswith(".") or name.startswith("_"):
            continue
        if name in excluded:
            continue
        if name == "autolog":
            continue
        path = os.path.join(root, name)
        if not os.path.isdir(path):
            continue
        if os.path.isfile(os.path.join(path, "__init__.py")):
            packages.append(name)

    return packages
