import json
import logging as _logging
import time
from typing import Optional

from autolog._context import new_trace_id
from autolog._formatter import _redact_sensitive, _to_json
from autolog._logger import get_logger


def _safe_parse_json(text: str):
    try:
        return json.loads(text)
    except (ValueError, TypeError):
        return text


def init_autolog(
    app,
    *,
    service: str = "app",
    level: str = "INFO",
    log_file: Optional[str] = None,
    max_body_len: int = 500,
) -> None:
    try:
        from flask import g, request as flask_request
    except ImportError:
        raise ImportError(
            "Flask is required for autolog.middleware.flask. "
            "Install it with: pip install flask"
        )

    logger = get_logger(name=service, level=level, log_file=log_file, service=service)

    _TRACE_HEADERS = ("X-Request-ID", "X-Trace-ID", "X-Correlation-ID", "traceparent")

    @app.before_request
    def _before():
        upstream = None
        for h in _TRACE_HEADERS:
            v = flask_request.headers.get(h)
            if v:
                upstream = v
                break
        g._autolog_trace_id = upstream or new_trace_id()
        g._autolog_start = time.perf_counter()

    @app.after_request
    def _after(response):
        from flask import g as _g, request as _req
        trace_id = getattr(_g, "_autolog_trace_id", "-")
        start = getattr(_g, "_autolog_start", None)
        duration = (time.perf_counter() - start) if start is not None else 0.0

        body_in_text = _req.get_data(as_text=True) or ""
        body_out_text = response.get_data(as_text=True) or ""

        inputs = _redact_sensitive({
            "method":  _req.method,
            "path":    _req.path,
            "params":  dict(_req.args),
            "body":    _safe_parse_json(body_in_text) if body_in_text else None,
        })
        result = _redact_sensitive({
            "status":  response.status_code,
            "body":    _safe_parse_json(body_out_text) if body_out_text else None,
        })

        record = logger.makeRecord(
            logger.name, _logging.INFO, "(flask-middleware)", 0,
            f"{_req.method} {_req.path} -> {response.status_code}", (), None
        )
        record.func_location = f"{service}.http"
        record.trace_id = trace_id
        record.func_inputs = _to_json(inputs, max_body_len)
        record.func_result = _to_json(result, max_body_len)
        record.func_duration = duration
        logger.handle(record)

        return response
