import json
import logging as _logging
import time
from typing import Optional

from starlette.background import BackgroundTask
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response, StreamingResponse

from autolog._context import new_trace_id
from autolog._formatter import _redact_sensitive, _to_json
from autolog._logger import get_logger


_STREAMING_CONTENT_TYPES = (
    "multipart/",
    "application/octet-stream",
    "text/event-stream",
    "video/",
    "audio/",
    "image/",
    "application/x-ndjson",
)

_TRACE_HEADERS = ("x-request-id", "x-trace-id", "x-correlation-id", "traceparent")


def _safe_parse_json(text: str):
    try:
        return json.loads(text)
    except (ValueError, TypeError):
        return text


def _is_streaming_content_type(content_type: str) -> bool:
    if not content_type:
        return False
    ct = content_type.lower()
    return any(ct.startswith(p) for p in _STREAMING_CONTENT_TYPES)


class AutoLogMiddleware(BaseHTTPMiddleware):
    def __init__(
        self,
        app,
        *,
        service: str = "app",
        level: str = "INFO",
        log_file: Optional[str] = None,
        max_body_len: int = 500,
        max_body_bytes: int = 64 * 1024,
    ):
        super().__init__(app)
        self._service = service
        self._max_body_len = max_body_len
        self._max_body_bytes = max_body_bytes
        self._logger = get_logger(name=service, level=level, log_file=log_file, service=service)

    def _incoming_trace_id(self, request: Request) -> str:
        for header in _TRACE_HEADERS:
            val = request.headers.get(header)
            if val:
                return val
        return new_trace_id()

    async def _capture_request_body(self, request: Request):
        content_type = request.headers.get("content-type", "")
        try:
            content_length = int(request.headers.get("content-length") or 0)
        except (TypeError, ValueError):
            content_length = 0

        if _is_streaming_content_type(content_type):
            return None, f"<skipped: {content_type or 'streaming'}>"

        if content_length and content_length > self._max_body_bytes:
            return None, f"<skipped: {content_length} bytes>"

        body_bytes = await request.body()

        async def _receive():
            return {"type": "http.request", "body": body_bytes, "more_body": False}

        request._receive = _receive

        if len(body_bytes) > self._max_body_bytes:
            return body_bytes, f"<truncated: {len(body_bytes)} bytes>"

        return body_bytes, body_bytes.decode("utf-8", errors="replace")

    async def dispatch(self, request: Request, call_next):
        trace_id = self._incoming_trace_id(request)

        _, body_in_text = await self._capture_request_body(request)

        start = time.perf_counter()
        response = await call_next(request)
        duration = time.perf_counter() - start

        resp_content_type = response.headers.get("content-type", "")
        if _is_streaming_content_type(resp_content_type):
            log_data = {
                "trace_id": trace_id,
                "service": self._service,
                "method": request.method,
                "path": request.url.path,
                "status": response.status_code,
                "duration": duration,
                "params": dict(request.query_params),
                "body_in": _safe_parse_json(body_in_text) if body_in_text else None,
                "body_out": f"<skipped: {resp_content_type}>",
                "max_body_len": self._max_body_len,
            }
            existing_bg = response.background
            new_bg = BackgroundTask(self._log_request, log_data)
            response.background = (
                _chain_background(existing_bg, new_bg) if existing_bg else new_bg
            )
            return response

        response_body = b""
        truncated = False
        async for chunk in response.body_iterator:
            if not truncated:
                response_body += chunk
                if len(response_body) > self._max_body_bytes:
                    response_body = response_body[: self._max_body_bytes]
                    truncated = True

        if truncated:
            body_out_text = f"<truncated: >{self._max_body_bytes} bytes>"
        else:
            body_out_text = response_body.decode("utf-8", errors="replace")

        log_data = {
            "trace_id": trace_id,
            "service": self._service,
            "method": request.method,
            "path": request.url.path,
            "status": response.status_code,
            "duration": duration,
            "params": dict(request.query_params),
            "body_in": _safe_parse_json(body_in_text) if body_in_text else None,
            "body_out": _safe_parse_json(body_out_text) if body_out_text and not truncated else body_out_text,
            "max_body_len": self._max_body_len,
        }

        return Response(
            content=response_body,
            status_code=response.status_code,
            headers=dict(response.headers),
            media_type=response.media_type,
            background=BackgroundTask(self._log_request, log_data),
        )

    def _log_request(self, data: dict) -> None:
        max_body = data["max_body_len"]
        inputs = _redact_sensitive({
            "method":  data["method"],
            "path":    data["path"],
            "params":  data["params"],
            "body":    data["body_in"],
        })
        result = _redact_sensitive({
            "status":  data["status"],
            "body":    data["body_out"],
        })

        record = self._logger.makeRecord(
            self._logger.name, _logging.INFO, "(middleware)", 0,
            f"{data['method']} {data['path']} -> {data['status']}", (), None
        )
        record.func_location = f"{data['service']}.http"
        record.trace_id = data["trace_id"]
        record.func_inputs = _to_json(inputs, max_body)
        record.func_result = _to_json(result, max_body)
        record.func_duration = data["duration"]
        self._logger.handle(record)


def _chain_background(first: BackgroundTask, second: BackgroundTask) -> BackgroundTask:
    async def _run():
        try:
            await first()
        finally:
            await second()
    return BackgroundTask(_run)
