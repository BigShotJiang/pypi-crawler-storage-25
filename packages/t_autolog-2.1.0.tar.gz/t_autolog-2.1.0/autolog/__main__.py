import argparse
import os
import runpy
import sys
from typing import List, Optional

from autolog import start
from autolog._config import find_config, load_config
from autolog._discovery import discover_packages


def _resolve_packages(
    cli_packages: Optional[List[str]],
    cfg: dict,
) -> List[str]:
    if cli_packages:
        return cli_packages
    if cfg.get("packages"):
        return list(cfg["packages"])
    return discover_packages()


def _cmd_run(args: argparse.Namespace) -> int:
    cfg = load_config(args.config)
    packages = _resolve_packages(args.packages, cfg)

    if not packages:
        print(
            "[autolog] no packages found.\n"
            "  fix: pass --packages NAME [NAME ...]\n"
            "       or add [tool.autolog] with `packages = [...]` to pyproject.toml",
            file=sys.stderr,
        )
        return 2

    start(
        packages=packages,
        service=args.service or cfg.get("service"),
        level=args.level or cfg.get("level", "INFO"),
        log_file=args.log_file or cfg.get("log_file"),
        format=args.format or cfg.get("format", "pretty"),
        sample=float(args.sample) if args.sample is not None else float(cfg.get("sample", 1.0)),
        exclude=args.exclude or cfg.get("exclude", []),
    )

    target = args.target
    target_args = list(args.target_args or [])

    is_module = args.module or (
        not target.endswith(".py") and not os.path.isfile(target)
    )

    sys.argv = [target] + target_args

    try:
        if is_module:
            runpy.run_module(target, run_name="__main__", alter_sys=True)
        else:
            runpy.run_path(target, run_name="__main__")
    except SystemExit as exc:
        return int(exc.code) if exc.code is not None else 0
    return 0


def _cmd_show(args: argparse.Namespace) -> int:
    cfg = load_config(args.config)
    cfg_path = args.config or find_config()
    packages = _resolve_packages(None, cfg)

    print("autolog config:")
    print(f"  config file : {cfg_path or '(none found)'}")
    print(f"  packages    : {packages or '(none discovered)'}")
    print(f"  service     : {cfg.get('service', '(default: first package)')}")
    print(f"  level       : {cfg.get('level', 'INFO')}")
    print(f"  log_file    : {cfg.get('log_file', '(stdout only)')}")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="autolog",
        description="Auto-instrumentation logging for Python projects.",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_run = sub.add_parser(
        "run",
        help="Run a script or module with autolog enabled.",
        description=(
            "Example: autolog run myapp.main\n"
            "         autolog run scripts/start.py --packages billing auth"
        ),
    )
    p_run.add_argument("target", help="Module name (e.g. myapp.main) or script path (main.py)")
    p_run.add_argument("target_args", nargs=argparse.REMAINDER, help="Args passed to the target")
    p_run.add_argument("-m", "--module", action="store_true", help="Force target to be treated as a module name")
    p_run.add_argument("--packages", nargs="+", metavar="PKG", help="Override packages to instrument")
    p_run.add_argument("--service", help="Service name shown in logs")
    p_run.add_argument("--level", help="Log level: DEBUG, INFO, WARNING, ERROR")
    p_run.add_argument("--log-file", dest="log_file", help="Mirror logs to this file")
    p_run.add_argument("--format", choices=["pretty", "compact", "json"], help="Output format")
    p_run.add_argument("--sample", help="Sampling rate 0.0-1.0 (default 1.0)")
    p_run.add_argument("--exclude", nargs="+", metavar="GLOB", help="Glob patterns to skip (e.g. myapp.hot.*)")
    p_run.add_argument("--config", help="Path to pyproject.toml (default: walk up from CWD)")
    p_run.set_defaults(func=_cmd_run)

    p_show = sub.add_parser("show", help="Print resolved config & discovered packages.")
    p_show.add_argument("--config", help="Path to pyproject.toml")
    p_show.set_defaults(func=_cmd_show)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
