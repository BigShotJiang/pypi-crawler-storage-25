import asyncio
import pytest

from autolog import log_function, new_trace_id, get_trace_id


@pytest.mark.asyncio
async def test_async_wrapper_preserves_return():
    @log_function
    async def compute(x):
        return x * 2

    result = await compute(21)
    assert result == 42


@pytest.mark.asyncio
async def test_async_wrapper_logs_duration(capsys):
    @log_function
    async def slow():
        await asyncio.sleep(0.01)
        return "done"

    result = await slow()
    assert result == "done"

    out = capsys.readouterr().out
    assert "duration" in out


@pytest.mark.asyncio
async def test_async_exception_propagates():
    @log_function
    async def fail_async():
        raise RuntimeError("async boom")

    with pytest.raises(RuntimeError, match="async boom"):
        await fail_async()


@pytest.mark.asyncio
async def test_context_var_trace_id():
    tid = new_trace_id()

    @log_function
    async def check_trace():
        return get_trace_id()

    result = await check_trace()
    assert result == tid
