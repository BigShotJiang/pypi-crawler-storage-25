"""Tests for Tier 1 features: start(), bind(), JSON output, sampling, exclude, per-pkg level."""
import json
import logging
import sys
import types

import pytest

import autolog
from autolog import bind, get_bound_fields, log, no_log, start, unbind
from autolog._decorator import _resolve_level
from autolog._formatter import (
    AutoLogFormatter,
    JsonFormatter,
    _is_sensitive,
    make_formatter,
)
from autolog._patcher import _AutoLogFinder, _is_excluded


def _remove_finders():
    sys.meta_path[:] = [f for f in sys.meta_path if not isinstance(f, _AutoLogFinder)]


# ---------- bind / unbind ----------

def test_bind_attaches_fields():
    unbind()
    bind(user_id=42, org_id="acme")
    fields = get_bound_fields()
    assert fields == {"user_id": 42, "org_id": "acme"}
    unbind()


def test_bind_merges():
    unbind()
    bind(a=1)
    bind(b=2)
    assert get_bound_fields() == {"a": 1, "b": 2}
    unbind()


def test_unbind_specific_keys():
    unbind()
    bind(a=1, b=2, c=3)
    unbind("a", "c")
    assert get_bound_fields() == {"b": 2}
    unbind()


def test_unbind_clears_all():
    bind(a=1, b=2)
    unbind()
    assert get_bound_fields() == {}


def test_bound_fields_appear_in_output(capsys):
    from autolog import log_function

    @log_function
    def f(x):
        return x * 2

    bind(request_id="req-123")
    f(10)
    unbind()

    captured = capsys.readouterr().out
    assert "request_id" in captured
    assert "req-123" in captured


# ---------- JSON formatter ----------

def test_json_formatter_outputs_valid_json():
    fmt = JsonFormatter()
    record = logging.LogRecord("test", logging.INFO, "(autolog)", 0, "msg", (), None)
    record.func_location = "myapp.foo"
    record.trace_id = "abc-123"
    record.func_inputs = '{"x": 5}'
    record.func_result = '{"y": 10}'
    record.func_duration = 0.0042
    out = fmt.format(record)
    parsed = json.loads(out)
    assert parsed["level"] == "INFO"
    assert parsed["location"] == "myapp.foo"
    assert parsed["trace_id"] == "abc-123"
    assert parsed["inputs"] == {"x": 5}
    assert parsed["result"] == {"y": 10}
    assert parsed["duration_s"] == 0.0042


def test_json_formatter_includes_bound_fields():
    fmt = JsonFormatter()
    record = logging.LogRecord("test", logging.INFO, "(autolog)", 0, "msg", (), None)
    record.func_location = "x"
    record.trace_id = "t"
    record.func_bound = {"user_id": 99, "org_id": "acme"}
    parsed = json.loads(fmt.format(record))
    assert parsed["user_id"] == 99
    assert parsed["org_id"] == "acme"


def test_make_formatter_factory():
    assert isinstance(make_formatter("json"), JsonFormatter)
    assert isinstance(make_formatter("pretty"), AutoLogFormatter)
    assert isinstance(make_formatter("unknown"), AutoLogFormatter)  # falls back


# ---------- Sampling ----------

def test_sample_zero_skips_logging(capsys):
    @log(sample=0.0)
    def f(x):
        return x

    for _ in range(20):
        f(1)

    out = capsys.readouterr().out
    assert "inputs" not in out


def test_sample_one_always_logs(capsys):
    @log(sample=1.0)
    def f(x):
        return x

    f(1)
    f(2)
    f(3)

    out = capsys.readouterr().out
    assert out.count("inputs") == 3


def test_sample_partial_is_probabilistic(capsys):
    @log(sample=0.5)
    def f(x):
        return x

    for _ in range(200):
        f(1)

    out = capsys.readouterr().out
    n = out.count("inputs")
    assert 50 < n < 150


# ---------- Exclude patterns ----------

def test_is_excluded_glob():
    assert _is_excluded("myapp.hot_path", ["myapp.hot_path"])
    assert _is_excluded("myapp.cache.foo", ["myapp.cache.*"])
    assert not _is_excluded("myapp.user", ["myapp.cache.*"])
    assert _is_excluded("foo.bar.baz", ["*.bar.*"])


def test_exclude_skips_module_at_install():
    _remove_finders()

    mod = types.ModuleType("_autolog_excl_test")
    mod.__name__ = "_autolog_excl_test"

    def included(): return "yes"
    def excluded_func(): return "no"
    included.__module__ = "_autolog_excl_test"
    excluded_func.__module__ = "_autolog_excl_test"
    mod.included = included
    mod.excluded_func = excluded_func

    from autolog._patcher import patch_module
    patch_module(mod, exclude=["_autolog_excl_test.excluded_func"])

    assert getattr(mod.included, "_autolog_wrapped", False)
    assert not getattr(mod.excluded_func, "_autolog_wrapped", False)


# ---------- Per-package level ----------

def test_resolve_level_string_passthrough():
    assert _resolve_level("anything", "DEBUG") == "DEBUG"


def test_resolve_level_dict_exact_match():
    assert _resolve_level("billing", {"billing": "DEBUG"}) == "DEBUG"


def test_resolve_level_dict_prefix_match():
    spec = {"myapp": "DEBUG", "myapp.utils": "WARN", "default": "INFO"}
    assert _resolve_level("myapp.utils.helpers", spec) == "WARN"   # longest prefix wins
    assert _resolve_level("myapp.routes", spec) == "DEBUG"
    assert _resolve_level("other", spec) == "INFO"


def test_resolve_level_dict_default_fallback():
    assert _resolve_level("nope", {"foo": "DEBUG"}, default="ERROR") == "ERROR"


# ---------- start() entrypoint ----------

def test_start_no_packages_warns(caplog):
    _remove_finders()
    with caplog.at_level(logging.WARNING):
        start(packages=[])
    msgs = [r.getMessage() for r in caplog.records]
    assert any("No packages" in m for m in msgs)


def test_start_installs_finder():
    _remove_finders()
    start(packages=["_autolog_start_test"])
    finders = [f for f in sys.meta_path if isinstance(f, _AutoLogFinder)]
    assert len(finders) == 1
    assert "_autolog_start_test" in finders[0]._packages
    _remove_finders()


def test_start_propagates_options_to_finder():
    _remove_finders()
    start(
        packages=["_autolog_opts"],
        exclude=["_autolog_opts.skip.*"],
        format="json",
        sample=0.5,
    )
    finder = next(f for f in sys.meta_path if isinstance(f, _AutoLogFinder))
    assert finder._options["format"] == "json"
    assert finder._options["sample"] == 0.5
    assert "_autolog_opts.skip.*" in finder._options["exclude"]
    _remove_finders()


# ---------- Backward compatibility ----------

def test_install_alias_still_works():
    _remove_finders()
    autolog.install(["_autolog_compat_test"])
    finders = [f for f in sys.meta_path if isinstance(f, _AutoLogFinder)]
    assert len(finders) == 1
    _remove_finders()


# ---------- Unified @log decorator ----------

def test_log_on_function():
    @log
    def f(x):
        return x

    assert getattr(f, "_autolog_wrapped", False)


def test_log_on_class():
    @log
    class C:
        def m(self, x):
            return x

    assert getattr(C.m, "_autolog_wrapped", False)


def test_log_with_args():
    @log(sample=0.5)
    def f(x):
        return x

    assert getattr(f, "_autolog_wrapped", False)
