import inspect
import sys
import types

import pytest

from autolog import patch_module
from autolog._patcher import _AutoLogFinder


def _make_module(name: str, code: str) -> types.ModuleType:
    mod = types.ModuleType(name)
    mod.__name__ = name
    exec(compile(code, f"{name}.py", "exec"), mod.__dict__)
    return mod


def _remove_autolog_finders():
    sys.meta_path[:] = [f for f in sys.meta_path if not isinstance(f, _AutoLogFinder)]


def test_patch_module_wraps_functions():
    mod = _make_module(
        "testmod_wrap",
        """
def hello():
    return "hello"

def world():
    return "world"
""",
    )

    patch_module(mod)

    assert getattr(mod.hello, "_autolog_wrapped", False)
    assert getattr(mod.world, "_autolog_wrapped", False)
    assert mod.hello() == "hello"
    assert mod.world() == "world"


def test_patch_module_skips_imports():
    mod = types.ModuleType("testmod_imports")
    mod.__name__ = "testmod_imports"

    import os
    mod.path = os.path

    import autolog._context as ctx
    mod.get_trace_id = ctx.get_trace_id

    patch_module(mod)

    assert not getattr(mod.path, "_autolog_wrapped", False)
    assert not getattr(mod.get_trace_id, "_autolog_wrapped", False)


def test_patch_module_wraps_class_methods():
    mod = _make_module(
        "testmod_class",
        """
class MyService:
    def create(self):
        return "created"
    def fetch(self):
        return "fetched"
    def _internal(self):
        return "internal"
""",
    )

    patch_module(mod)

    svc = mod.MyService()
    assert svc.create() == "created"
    assert svc.fetch() == "fetched"
    assert svc._internal() == "internal"
    assert getattr(mod.MyService.create, "_autolog_wrapped", False)
    assert not getattr(mod.MyService._internal, "_autolog_wrapped", False)


def test_import_hook_patches_on_import():
    pkg_name = "_autolog_test_hook_pkg_xyz"

    for key in list(sys.modules.keys()):
        if key.startswith(pkg_name):
            del sys.modules[key]

    _remove_autolog_finders()

    from autolog import install
    install([pkg_name])

    mod = types.ModuleType(pkg_name)
    mod.__name__ = pkg_name

    def do_work():
        return "done"

    do_work.__module__ = pkg_name
    mod.do_work = do_work

    patch_module(mod)

    assert getattr(mod.do_work, "_autolog_wrapped", False)
    assert mod.do_work() == "done"

    _remove_autolog_finders()


def test_import_hook_skips_unlisted_packages():
    mod = types.ModuleType("untracked_pkg")
    mod.__name__ = "untracked_pkg"

    def sensitive():
        return "untouched"

    sensitive.__module__ = "untracked_pkg"
    mod.sensitive = sensitive

    assert not getattr(mod.sensitive, "_autolog_wrapped", False)
