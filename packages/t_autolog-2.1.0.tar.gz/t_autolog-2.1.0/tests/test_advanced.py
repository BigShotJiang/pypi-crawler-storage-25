"""Tests for the production-readiness fixes."""
import asyncio
import threading
import types
import sys

import pytest

from autolog import log_class, log_function, install, patch_module, get_logger
from autolog._formatter import _redact_sensitive


def test_staticmethod_wrapped():
    @log_class
    class Calc:
        @staticmethod
        def add(a, b):
            return a + b

    assert Calc.add(2, 3) == 5
    assert getattr(Calc.__dict__["add"].__func__, "_autolog_wrapped", False)


def test_classmethod_wrapped():
    @log_class
    class Counter:
        count = 0

        @classmethod
        def increment(cls, by=1):
            cls.count += by
            return cls.count

    assert Counter.increment(5) == 5
    assert getattr(Counter.__dict__["increment"].__func__, "_autolog_wrapped", False)


def test_property_getter_wrapped():
    @log_class
    class User:
        def __init__(self, name):
            self._name = name

        @property
        def name(self):
            return self._name

    u = User("Alice")
    assert u.name == "Alice"


def test_sync_generator_wrapped():
    @log_function
    def numbers(n):
        for i in range(n):
            yield i

    result = list(numbers(3))
    assert result == [0, 1, 2]


def test_sync_generator_exception_propagates():
    @log_function
    def boom_gen():
        yield 1
        raise RuntimeError("boom")

    with pytest.raises(RuntimeError, match="boom"):
        list(boom_gen())


@pytest.mark.asyncio
async def test_async_generator_wrapped():
    @log_function
    async def stream(n):
        for i in range(n):
            yield i

    result = [item async for item in stream(3)]
    assert result == [0, 1, 2]


def test_recursive_redaction_in_result():
    """Sensitive keys nested in returned dicts/lists are redacted."""
    val = {"customer": "C001", "token": "tok_abc", "nested": {"api_key": "xyz"}}
    redacted = _redact_sensitive(val)
    assert redacted["customer"] == "C001"
    assert redacted["token"] == "[REDACTED]"
    assert redacted["nested"]["api_key"] == "[REDACTED]"


def test_recursive_redaction_in_list():
    val = [{"password": "x"}, {"name": "alice"}]
    redacted = _redact_sensitive(val)
    assert redacted[0]["password"] == "[REDACTED]"
    assert redacted[1]["name"] == "alice"


def test_recursive_redaction_in_kwarg_value():
    """Dict passed as a kwarg with sensitive inner keys gets scrubbed."""
    @log_function
    def submit(payload):
        return payload

    out = submit({"username": "alice", "password": "secret"})
    assert out == {"username": "alice", "password": "secret"}


def test_logger_cache_thread_safe():
    """Many threads calling get_logger() concurrently produce a single cached logger."""
    loggers = []
    lock = threading.Lock()

    def worker():
        lg = get_logger("thread_test", level="INFO")
        with lock:
            loggers.append(lg)

    threads = [threading.Thread(target=worker) for _ in range(50)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert all(lg is loggers[0] for lg in loggers)


def test_retroactive_patching_of_imported_modules():
    """install() applies patch_module() to packages already in sys.modules."""
    pkg_name = "_autolog_retro_pkg"

    for key in list(sys.modules.keys()):
        if key.startswith(pkg_name):
            del sys.modules[key]
    from autolog._patcher import _AutoLogFinder
    sys.meta_path[:] = [f for f in sys.meta_path if not isinstance(f, _AutoLogFinder)]

    mod = types.ModuleType(pkg_name)
    mod.__name__ = pkg_name

    def already_loaded():
        return "ok"

    already_loaded.__module__ = pkg_name
    mod.already_loaded = already_loaded
    sys.modules[pkg_name] = mod

    try:
        install([pkg_name])
        assert getattr(mod.already_loaded, "_autolog_wrapped", False)
    finally:
        del sys.modules[pkg_name]
        sys.meta_path[:] = [f for f in sys.meta_path if not isinstance(f, _AutoLogFinder)]
