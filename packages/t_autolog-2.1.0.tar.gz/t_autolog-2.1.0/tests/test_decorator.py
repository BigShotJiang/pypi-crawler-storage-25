import asyncio
import logging
import pytest

from autolog import log_function, log_class
from autolog._wrapper import _scrub_args


def test_sync_function_logged(capsys):
    @log_function
    def add(a, b):
        return a + b

    result = add(2, 3)
    assert result == 5
    out = capsys.readouterr().out
    assert "add" in out or result == 5


def test_async_function_logged():
    @log_function
    async def fetch(url):
        return f"fetched:{url}"

    result = asyncio.get_event_loop().run_until_complete(fetch("http://example.com"))
    assert result == "fetched:http://example.com"


def test_exception_logged_and_reraised(capsys):
    @log_function
    def fail():
        raise ValueError("boom")

    with pytest.raises(ValueError, match="boom"):
        fail()

    out = capsys.readouterr().out
    assert "ERROR" in out or "boom" in out


def test_functools_wraps_preserved():
    def my_func():
        """My docstring."""
        pass

    wrapped = log_function(my_func)
    assert wrapped.__name__ == "my_func"
    assert wrapped.__doc__ == "My docstring."
    assert wrapped.__wrapped__ is my_func


def test_sensitive_args_redacted():
    from autolog._wrapper import _format_inputs

    def login(username, password):
        pass

    scrubbed_args, _ = _scrub_args(login, ("alice", "supersecret"), {})
    assert scrubbed_args[0] == "alice"
    assert scrubbed_args[1] == "[REDACTED]"

    _, scrubbed_kwargs = _scrub_args(login, ("alice",), {"password": "secret"})
    assert scrubbed_kwargs["password"] == "[REDACTED]"

    inputs = _format_inputs(login, ("alice", "[REDACTED]"), {}, 300)
    assert '"username": "alice"' in inputs
    assert '"password": "[REDACTED]"' in inputs


def test_double_wrap_skipped():
    def my_func():
        return 42

    wrapped_once = log_function(my_func)
    wrapped_twice = log_function(wrapped_once)
    assert wrapped_twice is wrapped_once


def test_no_parens_decorator():
    @log_function
    def my_func():
        return 1

    assert my_func() == 1
    assert my_func._autolog_wrapped is True


def test_parens_decorator():
    @log_function()
    def my_func():
        return 2

    assert my_func() == 2
    assert my_func._autolog_wrapped is True


def test_parens_with_args():
    @log_function(service="test_service")
    def my_func():
        return 3

    assert my_func() == 3
    assert my_func._autolog_wrapped is True


def test_log_class_skips_private():
    @log_class
    class MyService:
        def public(self):
            return "public"

        def _private(self):
            return "private"

        def __init__(self):
            pass

    svc = MyService()
    assert svc.public() == "public"
    assert svc._private() == "private"
    assert getattr(MyService.public, "_autolog_wrapped", False)
    assert not getattr(MyService._private, "_autolog_wrapped", False)
    assert getattr(MyService.__init__, "_autolog_wrapped", False)
