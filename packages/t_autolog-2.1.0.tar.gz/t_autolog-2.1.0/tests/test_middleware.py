import pytest


def _make_app():
    try:
        from fastapi import FastAPI, Request as FARequest
        from fastapi.responses import JSONResponse
        from autolog.middleware.fastapi import AutoLogMiddleware
    except ImportError:
        return None

    app = FastAPI()
    app.add_middleware(AutoLogMiddleware, service="test-api")

    @app.get("/hello")
    async def hello():
        return JSONResponse({"hello": "world"})

    @app.post("/echo")
    async def echo(request: FARequest):
        body = await request.body()
        return JSONResponse({"echo": body.decode()})

    return app


@pytest.fixture
def test_app():
    return _make_app()


@pytest.fixture
def async_client(test_app):
    if test_app is None:
        pytest.skip("FastAPI not installed")
    try:
        import httpx  # noqa: F401
    except ImportError:
        pytest.skip("httpx not installed")
    return test_app


@pytest.mark.asyncio
async def test_middleware_logs_request(async_client, capsys):
    try:
        from httpx import AsyncClient, ASGITransport
    except ImportError:
        pytest.skip("httpx not installed")

    async with AsyncClient(
        transport=ASGITransport(app=async_client), base_url="http://test"
    ) as client:
        response = await client.get("/hello")

    assert response.status_code == 200
    assert response.json() == {"hello": "world"}


@pytest.mark.asyncio
async def test_middleware_sets_trace_id(async_client, capsys):
    try:
        from httpx import AsyncClient, ASGITransport
    except ImportError:
        pytest.skip("httpx not installed")

    from autolog import get_trace_id

    async with AsyncClient(
        transport=ASGITransport(app=async_client), base_url="http://test"
    ) as client:
        response = await client.get("/hello")

    assert response.status_code == 200
    trace_id = get_trace_id()
    assert trace_id != "-"


@pytest.mark.asyncio
async def test_middleware_non_blocking(async_client):
    try:
        import time
        from httpx import AsyncClient, ASGITransport
    except ImportError:
        pytest.skip("httpx not installed")

    async with AsyncClient(
        transport=ASGITransport(app=async_client), base_url="http://test"
    ) as client:
        start = time.perf_counter()
        response = await client.get("/hello")
        duration = time.perf_counter() - start

    assert response.status_code == 200
    assert duration < 5.0


@pytest.mark.asyncio
async def test_middleware_handles_body(async_client):
    try:
        from httpx import AsyncClient, ASGITransport
    except ImportError:
        pytest.skip("httpx not installed")

    async with AsyncClient(
        transport=ASGITransport(app=async_client), base_url="http://test"
    ) as client:
        response = await client.post("/echo", content=b"hello body")

    assert response.status_code == 200
    assert response.json() == {"echo": "hello body"}
