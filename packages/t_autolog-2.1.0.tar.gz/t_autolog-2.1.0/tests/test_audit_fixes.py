"""Tests for the audit fixes: idempotent install, NO_COLOR, AUTOLOG_DISABLE, no_log."""
import os
import sys
import types

import pytest

import autolog
from autolog import install, log_function, no_log, patch_module
from autolog._patcher import _AutoLogFinder


def _remove_autolog_finders():
    sys.meta_path[:] = [f for f in sys.meta_path if not isinstance(f, _AutoLogFinder)]


def test_install_is_idempotent():
    pkg = "_autolog_idempotent_test"
    _remove_autolog_finders()
    install([pkg])
    install([pkg])
    install([pkg])
    finders = [f for f in sys.meta_path if isinstance(f, _AutoLogFinder)]
    assert len(finders) == 1
    _remove_autolog_finders()


def test_install_merges_packages():
    _remove_autolog_finders()
    install(["pkg_a"])
    install(["pkg_b"])
    finders = [f for f in sys.meta_path if isinstance(f, _AutoLogFinder)]
    assert len(finders) == 1
    assert "pkg_a" in finders[0]._packages
    assert "pkg_b" in finders[0]._packages
    _remove_autolog_finders()


def test_no_log_decorator_skips_wrapping():
    @no_log
    def silent(x):
        return x

    @log_function
    def normal(x):
        return x

    wrapped_silent = log_function(silent)
    assert wrapped_silent is silent
    assert not getattr(silent, "_autolog_wrapped", False)
    assert getattr(normal, "_autolog_wrapped", False)


def test_no_log_works_in_patch_module():
    mod = types.ModuleType("_autolog_nolog_mod")
    mod.__name__ = "_autolog_nolog_mod"

    def keep_logged():
        return "logged"
    keep_logged.__module__ = "_autolog_nolog_mod"

    @no_log
    def hot_path():
        return "skip"
    hot_path.__module__ = "_autolog_nolog_mod"

    mod.keep_logged = keep_logged
    mod.hot_path = hot_path

    patch_module(mod)

    assert getattr(mod.keep_logged, "_autolog_wrapped", False)
    assert not getattr(mod.hot_path, "_autolog_wrapped", False)


def test_autolog_disable_env(monkeypatch):
    monkeypatch.setenv("AUTOLOG_DISABLE", "1")

    def my_func(x):
        return x * 2

    wrapped = log_function(my_func)
    assert wrapped is my_func
    assert not getattr(wrapped, "_autolog_wrapped", False)


def test_no_color_env_disables_ansi(monkeypatch):
    from autolog import _logger
    _logger._loggers.clear()

    monkeypatch.setenv("NO_COLOR", "1")
    logger = autolog.get_logger("nocolor_test")
    handler = logger.handlers[0]
    assert handler.formatter.use_color is False


def test_logger_name_is_deterministic():
    from autolog import _logger
    _logger._loggers.clear()
    lg1 = autolog.get_logger("stable_module")
    name1 = lg1.name
    _logger._loggers.clear()
    lg2 = autolog.get_logger("stable_module")
    name2 = lg2.name
    assert name1 == name2
    assert name1 == "autolog.stable_module"


def test_no_log_in_public_api():
    assert hasattr(autolog, "no_log")
    assert "no_log" in autolog.__all__
