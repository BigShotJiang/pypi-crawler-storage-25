#!/usr/bin/env python
# -*- coding: utf-8 -*-

from typing import Any, Dict, List, Optional

import ujson
import aiohttp
import asyncio

import clientcentral.query as query
from clientcentral.Exceptions import HTTPError
from clientcentral.model.Account import Account
from clientcentral.model.AccountNote import AccountNote

HEADERS = {"Content-Type": "application/json", "Accept": "application/json"}


class AccountsClient:
    def __init__(
        self,
        base_url: str,
        token: str,
        production: bool,
        session=None,
        event_loop=None,
        run_async: bool = False,
    ) -> None:
        self._base_url = base_url
        self._token = token
        self.production = production
        self.session = session
        self._event_loop = event_loop
        self._net_calls = 0
        self._run_async = run_async

    def _get_event_loop(self):
        """Retrieves the event loop or creates a new one."""
        try:
            return asyncio.get_running_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            return loop

    async def _request(self, http_verb, url, json=None, headers=None):
        """Submit the HTTP request with the running session or a new session."""
        self._net_calls += 1

        if not headers:
            headers = HEADERS

        if self.session and not self.session.closed:
            async with self.session.request(
                http_verb, url, headers=headers, json=json
            ) as resp:
                return {
                    "json": await resp.json(content_type=None),
                    "headers": resp.headers,
                    "status_code": resp.status,
                    "method": resp.method,
                    "url": resp.url,
                }

        async with aiohttp.ClientSession(
            loop=self._event_loop, json_serialize=ujson.dumps
        ) as session:
            self.session = session
            async with self.session.request(
                http_verb, url, headers=headers, json=json
            ) as resp:
                return {
                    "json": await resp.json(content_type=None),
                    "headers": resp.headers,
                    "status_code": resp.status,
                    "method": resp.method,
                    "url": resp.url,
                }

    def _run(self, coro):
        if self._run_async:
            return coro
        if self._event_loop is None:
            self._event_loop = self._get_event_loop()
        future = self._event_loop.create_task(coro)
        return self._event_loop.run_until_complete(future)

    # ==== Accounts ====

    async def _async_list_accounts(
        self,
        page: Optional[int] = None,
        per_page: Optional[int] = None,
        filter: Optional[str] = None,
    ) -> List[Account]:
        url = self._base_url + "/api/v1/accounts.json?" + self._token
        if page is not None:
            url += "&page=" + str(page)
        if per_page is not None:
            url += "&per_page=" + str(per_page)
        if filter:
            url += "&filter=" + filter

        response = await self._request("GET", url)

        if response["status_code"] != 200:
            raise HTTPError("Failed to list accounts", response)

        data = response["json"].get("data", [])
        return [Account.create_account_from_dict(item) for item in data]

    def list_accounts(
        self,
        page: Optional[int] = None,
        per_page: Optional[int] = None,
        filter: Optional[str] = None,
    ) -> List[Account]:
        """Fetch a single page of accounts. Use `get_all_accounts` to paginate."""
        return self._run(self._async_list_accounts(page, per_page, filter))

    async def _async_get_all_accounts(
        self, filter: Optional[str] = None
    ) -> List[Account]:
        accounts: List[Account] = []
        page = 1

        while True:
            url = (
                self._base_url
                + "/api/v1/accounts.json?"
                + self._token
                + "&page="
                + str(page)
            )
            if filter:
                url += "&filter=" + filter

            response = await self._request("GET", url)

            if response["status_code"] != 200:
                raise HTTPError("Failed to list accounts", response)

            body = response["json"]
            batch = body.get("data", []) or []
            accounts += [Account.create_account_from_dict(item) for item in batch]

            if not body.get("more"):
                break
            page += 1

        return accounts

    def get_all_accounts(self, filter: Optional[str] = None) -> List[Account]:
        """Paginate through every account visible to the token."""
        return self._run(self._async_get_all_accounts(filter))

    async def _async_get_account_by_number(self, number: int) -> Account:
        filter_expr = query.comparison("number", "=", str(number))
        url = (
            self._base_url
            + "/api/v1/accounts.json?"
            + self._token
            + "&filter="
            + filter_expr
        )

        response = await self._request("GET", url)

        if response["status_code"] != 200:
            raise HTTPError(
                f"Failed to get account by number: {number}", response
            )

        data = response["json"].get("data", [])
        if not data:
            raise HTTPError(
                f"No account found with number: {number}", response
            )

        return Account.create_account_from_dict(data[0])

    def get_account_by_number(self, number: int) -> Account:
        return self._run(self._async_get_account_by_number(number))

    # ==== Account notes ====

    async def _async_list_account_notes(
        self, account_number: int, important: bool = False
    ) -> List[AccountNote]:
        url = (
            self._base_url
            + "/api/v1/accounts/"
            + str(account_number)
            + "/account_notes.json?"
            + self._token
        )
        if important:
            url += "&important=true"

        response = await self._request("GET", url)

        if response["status_code"] != 200:
            raise HTTPError(
                f"Failed to list account notes for account: {account_number}",
                response,
            )

        data = response["json"]
        if isinstance(data, dict) and "data" in data:
            data = data["data"]
        return [AccountNote.create_account_note_from_dict(item) for item in data]

    def list_account_notes(
        self, account_number: int, important: bool = False
    ) -> List[AccountNote]:
        return self._run(self._async_list_account_notes(account_number, important))

    async def _async_get_account_note(
        self, account_number: int, note_id: int
    ) -> AccountNote:
        url = (
            self._base_url
            + "/api/v1/accounts/"
            + str(account_number)
            + "/account_notes/"
            + str(note_id)
            + ".json?"
            + self._token
        )

        response = await self._request("GET", url)

        if response["status_code"] != 200:
            raise HTTPError(
                f"Failed to get account note: {note_id}", response
            )

        return AccountNote.create_account_note_from_dict(response["json"])

    def get_account_note(
        self, account_number: int, note_id: int
    ) -> AccountNote:
        return self._run(self._async_get_account_note(account_number, note_id))

    async def _async_create_account_note(
        self,
        account_number: int,
        subject: str,
        body: str,
        important: bool = False,
    ) -> AccountNote:
        url = (
            self._base_url
            + "/api/v1/accounts/"
            + str(account_number)
            + "/account_notes.json?"
            + self._token
        )

        payload: Dict[str, Any] = {
            "account_note": {
                "subject": subject,
                "body": body,
                "important": important,
            }
        }

        response = await self._request("POST", url, json=payload)

        if response["status_code"] not in (200, 201):
            raise HTTPError(
                f"Failed to create account note on account: {account_number}",
                response,
            )

        return AccountNote.create_account_note_from_dict(response["json"])

    def create_account_note(
        self,
        account_number: int,
        subject: str,
        body: str,
        important: bool = False,
    ) -> AccountNote:
        return self._run(
            self._async_create_account_note(
                account_number, subject, body, important
            )
        )

    async def _async_update_account_note(
        self,
        account_number: int,
        note_id: int,
        subject: Optional[str] = None,
        body: Optional[str] = None,
        important: Optional[bool] = None,
    ) -> AccountNote:
        url = (
            self._base_url
            + "/api/v1/accounts/"
            + str(account_number)
            + "/account_notes/"
            + str(note_id)
            + ".json?"
            + self._token
        )

        attrs: Dict[str, Any] = {}
        if subject is not None:
            attrs["subject"] = subject
        if body is not None:
            attrs["body"] = body
        if important is not None:
            attrs["important"] = important

        if not attrs:
            raise ValueError(
                "update_account_note requires at least one of subject, body, important"
            )

        response = await self._request(
            "PATCH", url, json={"account_note": attrs}
        )

        if response["status_code"] != 200:
            raise HTTPError(
                f"Failed to update account note: {note_id}", response
            )

        return AccountNote.create_account_note_from_dict(response["json"])

    def update_account_note(
        self,
        account_number: int,
        note_id: int,
        subject: Optional[str] = None,
        body: Optional[str] = None,
        important: Optional[bool] = None,
    ) -> AccountNote:
        return self._run(
            self._async_update_account_note(
                account_number, note_id, subject, body, important
            )
        )

    async def _async_delete_account_note(
        self, account_number: int, note_id: int
    ) -> bool:
        url = (
            self._base_url
            + "/api/v1/accounts/"
            + str(account_number)
            + "/account_notes/"
            + str(note_id)
            + ".json?"
            + self._token
        )

        response = await self._request("DELETE", url)

        if response["status_code"] != 200:
            raise HTTPError(
                f"Failed to delete account note: {note_id}", response
            )

        return True

    def delete_account_note(
        self, account_number: int, note_id: int
    ) -> bool:
        return self._run(self._async_delete_account_note(account_number, note_id))