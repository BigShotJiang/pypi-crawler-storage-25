from typing import Optional


class AccountNote:
    def __init__(
        self,
        note_id: int,
        subject: str,
        body: str,
        important: bool = False,
        account_id: Optional[int] = None,
        created_by: Optional[dict] = None,
        created_at: Optional[str] = None,
        updated_at: Optional[str] = None,
    ) -> None:
        self.note_id = note_id
        self.subject = subject
        self.body = body
        self.important = important
        self.account_id = account_id
        self.created_by = created_by
        self.created_at = created_at
        self.updated_at = updated_at

    @classmethod
    def create_account_note_from_dict(cls, data: dict) -> "AccountNote":
        return cls(
            note_id=data["id"],
            subject=data["subject"],
            body=data["body"],
            important=data.get("important", False),
            account_id=data.get("account_id"),
            created_by=data.get("created_by"),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
        )
