from typing import Optional


class Account:
    def __init__(
        self,
        account_id: Optional[int],
        number: int,
        name: str,
        known_as: Optional[str] = None,
        address: Optional[str] = None,
        locked: Optional[bool] = None,
        region: Optional[dict] = None,
        account_type: Optional[str] = None,
        activities_temporal_count: Optional[int] = None,
        created_at: Optional[str] = None,
        updated_at: Optional[str] = None,
    ) -> None:
        self.account_id = account_id
        self.number = number
        self.name = name
        self.known_as = known_as
        self.address = address
        self.locked = locked
        self.region = region
        self.account_type = account_type
        self.activities_temporal_count = activities_temporal_count
        self.created_at = created_at
        self.updated_at = updated_at

    @classmethod
    def create_account_from_dict(cls, data: dict) -> "Account":
        return cls(
            account_id=data.get("id"),
            number=data["number"],
            name=data["name"],
            known_as=data.get("known_as"),
            address=data.get("address"),
            locked=data.get("locked"),
            region=data.get("region"),
            account_type=data.get("account_type"),
            activities_temporal_count=data.get("activities_temporal_count"),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
        )
