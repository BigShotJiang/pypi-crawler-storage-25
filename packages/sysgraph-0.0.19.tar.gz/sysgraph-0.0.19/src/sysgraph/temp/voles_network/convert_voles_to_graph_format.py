#!/usr/bin/env python3
"""
Convert mammalia-voles-bhp-trapping network data to the graph viewer JSON format.
"""
import json


def parse_edges_file(filename):
    """Parse the voles edges file format."""
    edges = []
    nodes_set = set()
    
    with open(filename, 'r') as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) >= 4:
                source = int(parts[0])
                target = int(parts[1])
                weight = int(parts[2])
                time_period = int(parts[3])
                
                nodes_set.add(source)
                nodes_set.add(target)
                edges.append({
                    'source': source,
                    'target': target,
                    'weight': weight,
                    'time_period': time_period
                })
    
    return sorted(nodes_set), edges

def convert_to_graph_format(edges_file, output_file):
    """Convert voles trapping network to graph viewer format."""
    print(f"Parsing {edges_file}...")
    nodes_ids, edges_data = parse_edges_file(edges_file)
    
    print(f"Found {len(nodes_ids)} nodes and {len(edges_data)} edges")
    
    # Analyze time periods
    time_periods = set(e['time_period'] for e in edges_data)
    print(f"Time periods range: {min(time_periods)} to {max(time_periods)}")
    
    # Create nodes in the format expected by the graph viewer
    nodes = []
    for node_id in nodes_ids:
        nodes.append({
            'id': f'vole_{node_id}',
            'type': 'vole',
            'properties': {
                'node_id': node_id,
                'label': f'Vole {node_id}'
            }
        })
    
    # Create edges in the format expected by the graph viewer
    edges = []
    for idx, edge_data in enumerate(edges_data):
        edges.append({
            'id': f'edge_{idx}',
            'source_id': f'vole_{edge_data["source"]}',
            'target_id': f'vole_{edge_data["target"]}',
            'type': 'trapping_cooccurrence',
            'properties': {
                'weight': edge_data['weight'],
                'time_period': edge_data['time_period']
            }
        })
    
    # Create the final graph structure
    graph_data = {
        'nodes': nodes,
        'edges': edges
    }
    
    # Write to output file
    print(f"Writing to {output_file}...")
    with open(output_file, 'w') as f:
        json.dump(graph_data, f, indent=2)
    
    print("Conversion complete!")
    print(f"Total nodes: {len(nodes)}")
    print(f"Total edges: {len(edges)}")

if __name__ == '__main__':
    convert_to_graph_format(
        'mammalia-voles-bhp-trapping.edges',
        'voles_graph.json'
    )
