#!/usr/bin/env python3
"""
Convert congress network data to the graph viewer JSON format.
"""
import ast
import json


def parse_edgelist(filename):
    """Parse the NetworkX edgelist format."""
    edges = []
    nodes_set = set()
    
    with open(filename, 'r') as f:
        for line in f:
            parts = line.strip().split(' ', 2)
            if len(parts) >= 3:
                source = int(parts[0])
                target = int(parts[1])
                # Parse the dictionary string for weight
                weight_dict = ast.literal_eval(parts[2])
                weight = weight_dict.get('weight', 1.0)
                
                nodes_set.add(source)
                nodes_set.add(target)
                edges.append({
                    'source': source,
                    'target': target,
                    'weight': weight
                })
    
    return sorted(nodes_set), edges

def convert_to_graph_format(edgelist_file, output_file):
    """Convert congress network to graph viewer format."""
    print(f"Parsing {edgelist_file}...")
    nodes_ids, edges_data = parse_edgelist(edgelist_file)
    
    print(f"Found {len(nodes_ids)} nodes and {len(edges_data)} edges")
    
    # Create nodes in the format expected by the graph viewer
    nodes = []
    for node_id in nodes_ids:
        nodes.append({
            'id': f'node_{node_id}',
            'type': 'congress_member',
            'properties': {
                'node_id': node_id,
                'label': f'Member {node_id}'
            }
        })
    
    # Create edges in the format expected by the graph viewer
    edges = []
    for idx, edge_data in enumerate(edges_data):
        edges.append({
            'id': f'edge_{idx}',
            'source_id': f'node_{edge_data["source"]}',
            'target_id': f'node_{edge_data["target"]}',
            'type': 'twitter_connection',
            'properties': {
                'weight': edge_data['weight']
            }
        })
    
    # Create the final graph structure
    graph_data = {
        'nodes': nodes,
        'edges': edges
    }
    
    # Write to output file
    print(f"Writing to {output_file}...")
    with open(output_file, 'w') as f:
        json.dump(graph_data, f, indent=2)
    
    print("Conversion complete!")
    print(f"Total nodes: {len(nodes)}")
    print(f"Total edges: {len(edges)}")

if __name__ == '__main__':
    convert_to_graph_format(
        'congress.edgelist',
        'congress_graph.json'
    )
