"""
SMRITI MCP Server.
Exposes the SMRITI memory system as a Claude Code MCP server via stdio transport.

Usage:
    python -m smriti.integrations.mcp_server

Environment variables:
    SMRITI_STORAGE_PATH   Where to persist data (default: ~/.smriti/global)
    SMRITI_LLM_MODEL      LLM model name — provider inferred from prefix (default: mistral)
    SMRITI_LLM_API_KEY    API key for cloud providers; empty for Ollama
"""
from __future__ import annotations

import atexit
import logging
import os
import sys
from datetime import datetime
from typing import Any, Dict, List, Optional

try:
    import mcp
    from mcp.server.fastmcp import FastMCP
except ImportError:
    raise ImportError(
        "To use the SMRITI MCP server, install the mcp extra:\n"
        "pip install smriti-memory[mcp]"
    )

from smriti.core import SMRITI
from smriti.models import (
    ConsolidationDepth,
    Memory,
    MemorySource,
    MemoryStatus,
    Modality,
    SmritiConfig,
)

logger = logging.getLogger(__name__)

# ── Startup Config ────────────────────────────────────────────────────────────

def build_smriti_config() -> SmritiConfig:
    """
    Build SmritiConfig from environment variables.

    SMRITI_STORAGE_PATH  — storage dir, ~ expanded (default: ~/.smriti/global)
    SMRITI_LLM_MODEL     — model name, provider inferred by prefix (default: mistral)
    SMRITI_LLM_API_KEY   — API key for cloud providers (default: "")
    """
    storage_path = os.path.expanduser(
        os.environ.get("SMRITI_STORAGE_PATH", "~/.smriti/global")
    )
    llm_model = os.environ.get("SMRITI_LLM_MODEL", "mistral")
    api_key = os.environ.get("SMRITI_LLM_API_KEY", "")

    # Infer provider from model name prefix — matches LLMInterface routing in llm_interface.py:61-68
    # IMPORTANT: Pass "" (empty string, not None) for unused provider keys.
    # SmritiConfig.__post_init__ falls back to reading ANTHROPIC_API_KEY/OPENAI_API_KEY/GEMINI_API_KEY
    # env vars only when the field is None. Passing "" prevents that silent inheritance.
    anthropic_key = api_key if llm_model.startswith("claude") else ""
    openai_key = api_key if llm_model.startswith("gpt-") else ""
    gemini_key = api_key if llm_model.startswith("gemini") else ""

    return SmritiConfig(
        storage_path=storage_path,
        llm_model=llm_model,
        anthropic_api_key=anthropic_key,
        openai_api_key=openai_key,
        gemini_api_key=gemini_key,
    )


# Module-level SMRITI instance — initialized at startup, shared across tool calls.
# Tests replace this: `import smriti.integrations.mcp_server as s; s._smriti = test_instance`
_smriti: Optional[SMRITI] = None

mcp_server = FastMCP("smriti-memory")


# ── Serialization ─────────────────────────────────────────────────────────────

def serialize_memory(memory: Memory) -> Dict[str, Any]:
    """Convert a Memory dataclass to a JSON-serializable dict."""
    return {
        "id": memory.id,
        "content": memory.content,
        "strength": memory.strength,
        "confidence": memory.confidence,
        "room_id": memory.room_id,
        "reflection_level": memory.reflection_level,
        "source": memory.source.value,
        "modality": memory.modality.value,
        "status": memory.status.value,
        "creation_time": memory.creation_time.isoformat(),
        "last_accessed": memory.last_accessed.isoformat(),
        "access_count": memory.access_count,
        "salience": memory.salience.to_dict(),
        "hops": memory.hops,
        "retrieval_score": memory.retrieval_score,
    }
# ── Core Memory Tools ─────────────────────────────────────────────────────────

@mcp_server.tool()
def smriti_encode(
    content: str,
    source: str = "direct",
    modality: str = "text",
) -> Dict[str, Any]:
    """
    Encode information into SMRITI long-term memory.

    Returns the memory_id if stored, or {"memory_id": null, "status": "discarded"}
    if the Attention Gate determined the content has insufficient salience.

    source: "direct" (default), "user_stated" (highest trust, confidence=1.0),
            "inferred", or "external"
    modality: "text" (default), "code", "image", "structured"
    """
    try:
        mem_source = MemorySource(source)
    except ValueError:
        return {"error": f"Invalid source '{source}'. Use: direct, user_stated, inferred, external"}
    try:
        mem_modality = Modality(modality)
    except ValueError:
        return {"error": f"Invalid modality '{modality}'. Use: text, code, image, structured"}

    try:
        memory_id = _smriti.encode(content, source=mem_source, modality=mem_modality)
        if memory_id is None:
            return {"memory_id": None, "status": "discarded"}
        _smriti.save()
        return {"memory_id": memory_id}
    except Exception as e:
        logger.error(f"smriti_encode failed: {e}")
        return {"error": str(e)}


@mcp_server.tool()
def smriti_recall(query: str, top_k: int = 10) -> List[Dict[str, Any]]:
    """
    Recall memories relevant to a query.

    Returns a list of memory dicts, strongest first. Every retrieval strengthens
    the recalled memories (testing effect). Returns empty list if nothing found.
    """
    try:
        memories = _smriti.recall(query, top_k=top_k)
        return [serialize_memory(m) for m in memories]
    except Exception as e:
        logger.error(f"smriti_recall failed: {e}")
        return [{"error": str(e)}]


@mcp_server.tool()
def smriti_get_context() -> Dict[str, str]:
    """
    Get formatted working memory context for injection into a prompt.

    Returns the current capacity-bounded working memory (7±2 slots) as a
    formatted string ready to prepend to a system prompt or user message.
    """
    try:
        return {"context": _smriti.get_context()}
    except Exception as e:
        logger.error(f"smriti_get_context failed: {e}")
        return {"error": str(e)}


# ── Confidence & Gap Tools ────────────────────────────────────────────────────

@mcp_server.tool()
def smriti_how_well_do_i_know(topic: str) -> Dict[str, Any]:
    """
    Assess confidence about a topic.

    Returns 5 confidence dimensions (coverage, freshness, strength, depth, overall)
    and a decision: "recall_confidently", "recall_but_verify", or "admit_gap_and_ask".

    Uses two internal calls: confidence_map() for dimensions, should_recall_or_ask()
    for the decision — these are separate MetaMemory methods.
    """
    try:
        conf = _smriti.meta_memory.confidence_map(topic)
        decision = _smriti.meta_memory.should_recall_or_ask(topic)
        return {
            "coverage": conf.coverage,
            "freshness": conf.freshness,
            "strength": conf.strength,
            "depth": conf.depth,
            "overall": conf.overall,
            "decision": decision.value,
        }
    except Exception as e:
        return {"error": str(e)}


@mcp_server.tool()
def smriti_knowledge_gaps() -> List[Dict[str, Any]]:
    """
    List topics SMRITI knows it doesn't know.

    Returns gap dicts with keys: topic, context, discovered_at (ISO string), resolved (bool).
    Gaps are registered when recall returns empty or confidence is below threshold.
    """
    try:
        return _smriti.knowledge_gaps()
    except Exception as e:
        return [{"error": str(e)}]


# ── Memory Management Tools ───────────────────────────────────────────────────

@mcp_server.tool()
def smriti_pin(memory_id: str) -> Dict[str, Any]:
    """
    Mark a memory as permanent — it will never be decayed or forgotten.

    Returns {"status": "pinned", "memory_id": ...} on success,
    or {"error": ...} if the memory_id is not found.
    """
    try:
        mem = _smriti.palace.get_memory(memory_id)
        if mem is None:
            return {"error": f"Memory not found: {memory_id}"}
        _smriti.pin(memory_id)
        # Verify the pin actually took effect
        mem = _smriti.palace.get_memory(memory_id)
        if mem is None or mem.status != MemoryStatus.PINNED:
            return {"error": f"Failed to pin memory: {memory_id}"}
        return {"status": "pinned", "memory_id": memory_id}
    except Exception as e:
        return {"error": str(e)}


@mcp_server.tool()
def smriti_forget(memory_id: str) -> Dict[str, Any]:
    """
    Gracefully forget a memory by archiving it.

    Sets memory status to ARCHIVED (not deleted — a record remains).
    Returns {"status": "archived", "memory_id": ...} on success,
    or {"error": ...} if the memory_id is not found.
    """
    try:
        mem = _smriti.palace.get_memory(memory_id)
        if mem is None:
            return {"error": f"Memory not found: {memory_id}"}
        _smriti.forget(memory_id)
        return {"status": "archived", "memory_id": memory_id}
    except Exception as e:
        return {"error": str(e)}


@mcp_server.tool()
def smriti_consolidate(depth: str = "light") -> Dict[str, Any]:
    """
    Run a consolidation cycle to organize and strengthen memories.

    depth="light": chunking + conflict detection only (fast, safe to call often)
    depth="full": all 8 consolidation processes (thorough, use periodically)

    Note: "defer" is intentionally excluded — it means "let the scheduler decide"
    and is not useful as an explicit call.
    """
    if depth not in ("light", "full"):
        return {"error": "depth must be 'light' or 'full'"}
    try:
        result = _smriti.consolidate(depth=depth)

        # Handle deferred (scheduler decided no consolidation needed)
        if result.get("status") == "deferred":
            return {
                "depth": depth,
                "status": "deferred",
                "processed": 0,
                "summary": result.get("reason", "no consolidation needed"),
                "elapsed_seconds": 0,
            }

        # Normal consolidation result — count successful processes
        processes = result.get("processes", {})
        processed_count = sum(
            1 for p in processes.values()
            if isinstance(p, dict) and "error" not in p
        )
        return {
            "depth": result.get("depth", depth),
            "status": "completed",
            "processed": processed_count,
            "processes": list(processes.keys()),
            "summary": f"{result.get('depth', depth)} consolidation: {processed_count} processes ran",
            "elapsed_seconds": result.get("elapsed_seconds", 0),
        }
    except Exception as e:
        return {"error": str(e)}


# ── Introspection Tools ───────────────────────────────────────────────────────

@mcp_server.tool()
def smriti_stats() -> Dict[str, Any]:
    """
    Get comprehensive SMRITI system statistics.

    Returns a nested dict with 8 top-level keys:
    palace, working_memory, retrieval, consolidation, meta_memory,
    episode_buffer, vector_store, metrics.
    """
    try:
        return _smriti.stats()
    except Exception as e:
        return {"error": str(e)}


@mcp_server.tool()
def smriti_get_suggestions() -> List[Dict[str, Any]]:
    """
    Get proactive suggestions from SMRITI's ambient monitor.

    Returns a list of memory dicts — patterns and insights surfaced from
    background consolidation that may be relevant to the current context.
    """
    try:
        suggestions = _smriti.get_suggestions()
        return [serialize_memory(s) for s in suggestions]
    except Exception as e:
        return [{"error": str(e)}]


# ── Startup ───────────────────────────────────────────────────────────────────

def _startup():
    """Initialize the module-level SMRITI instance from env vars."""
    global _smriti
    config = build_smriti_config()
    logger.info(f"Starting SMRITI MCP server (storage: {config.storage_path}, model: {config.llm_model})")
    _smriti = SMRITI(config=config)
    atexit.register(_smriti.save)
    logger.info("SMRITI MCP server ready — 10 tools registered")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, stream=sys.stderr)
    _startup()
    mcp_server.run(transport="stdio")
