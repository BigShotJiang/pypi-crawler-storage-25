#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
"""Shared Pydantic base models used by all schema classes."""

from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic.alias_generators import to_camel


class _BaseSchema(BaseModel):
    """Strict base for nested config schemas.
    Unknown fields raise ValidationError immediately — typos never pass silently.
    Accepts both snake_case (timeout_sec) and camelCase (timeoutSec) from external config.
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        validate_by_name=True,
        validate_by_alias=True,
        extra="forbid",
    )


class _BaseSchemaAllowExtra(_BaseSchema):
    """Lenient base for top-level user-facing schemas (ModerationConfig, TargetBlock).

    Unknown fields are stored as-is for forward-compatibility with newer YAML keys.
    """

    model_config = ConfigDict(extra="allow")
