#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
"""TargetBlock schema: a named target entity with its own list of guards."""

from pydantic import Field

from datarobot_dome.schema._base import _BaseSchemaAllowExtra
from datarobot_dome.schema.guards import GuardSchema


class TargetBlock(_BaseSchemaAllowExtra):
    """A named target entity (e.g. ``workflow_overall``, ``tool_wikipedia_search``)
    paired with the guards that should be applied to it.
    """

    target: str = Field(min_length=1)
    guards: list[GuardSchema] = Field(default_factory=list)
