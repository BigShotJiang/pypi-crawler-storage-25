#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
"""Nested config schemas embedded inside guard definitions."""

from typing import Annotated
from typing import Any
from typing import Literal
from typing import Optional
from typing import Union

from pydantic import Field

from datarobot_dome.constants import CostCurrency
from datarobot_dome.constants import GuardAction
from datarobot_dome.constants import GuardModelTargetType
from datarobot_dome.constants import GuardOperatorType
from datarobot_dome.schema._base import _BaseSchema
from datarobot_dome.validation_limits import MAX_COLUMN_NAME_LENGTH
from datarobot_dome.validation_limits import MAX_GUARD_MESSAGE_LENGTH
from datarobot_dome.validation_limits import MAX_GUARD_NAME_LENGTH
from datarobot_dome.validation_limits import MAX_GUIDELINE_LENGTH
from datarobot_dome.validation_limits import MAX_REFERENCE_TOPIC_LENGTH
from datarobot_dome.validation_limits import MAX_REGEX_LENGTH
from datarobot_dome.validation_limits import OBJECT_ID_LENGTH


class CostMetricSchema(_BaseSchema):
    currency: Literal[CostCurrency.USD] = CostCurrency.USD
    input_price: float
    input_unit: int
    output_price: float
    output_unit: int


class ModelInfoSchema(_BaseSchema):
    class_names: Optional[list[Annotated[str, Field(max_length=MAX_COLUMN_NAME_LENGTH)]]] = None
    model_id: Optional[str] = Field(default=None, max_length=OBJECT_ID_LENGTH)
    input_column_name: str = Field(max_length=MAX_COLUMN_NAME_LENGTH)
    target_name: str = Field(max_length=MAX_COLUMN_NAME_LENGTH)
    replacement_text_column_name: Optional[str] = Field(
        default=None, max_length=MAX_COLUMN_NAME_LENGTH
    )
    target_type: Literal[
        GuardModelTargetType.BINARY,
        GuardModelTargetType.REGRESSION,
        GuardModelTargetType.MULTICLASS,
        GuardModelTargetType.TEXT_GENERATION,
    ]


class NemoLLMJudgeConfigSchema(_BaseSchema):
    system_prompt: str
    user_prompt: str
    score_parsing_regex: str = Field(max_length=MAX_REGEX_LENGTH)
    custom_metric_directionality: Literal["higherIsBetter", "lowerIsBetter"]


class NemoTopicAdherenceConfigSchema(_BaseSchema):
    metric_mode: Literal["f1", "recall", "precision"]
    reference_topics: list[Annotated[str, Field(max_length=MAX_REFERENCE_TOPIC_LENGTH)]] = Field(
        min_length=1
    )


class NemoResponseRelevancyConfigSchema(_BaseSchema):
    embedding_deployment_id: str = Field(max_length=OBJECT_ID_LENGTH)


class InterventionConditionSchema(_BaseSchema):
    comparand: Union[
        Annotated[str, Field(max_length=MAX_GUARD_NAME_LENGTH)],
        float,
        bool,
        list[Annotated[str, Field(max_length=MAX_GUARD_NAME_LENGTH)]],
        list[float],
    ]
    comparator: Literal[
        GuardOperatorType.GREATER_THAN,
        GuardOperatorType.LESS_THAN,
        GuardOperatorType.EQUALS,
        GuardOperatorType.NOT_EQUALS,
        GuardOperatorType.IS,
        GuardOperatorType.IS_NOT,
        GuardOperatorType.MATCHES,
        GuardOperatorType.DOES_NOT_MATCH,
        GuardOperatorType.CONTAINS,
        GuardOperatorType.DOES_NOT_CONTAIN,
    ]


class InterventionSchema(_BaseSchema):
    action: Literal[GuardAction.BLOCK, GuardAction.REPORT, GuardAction.REPLACE]
    message: Optional[str] = Field(default=None, max_length=MAX_GUARD_MESSAGE_LENGTH)
    conditions: Optional[list[InterventionConditionSchema]] = Field(default=None, max_length=1)
    send_notification: Optional[bool] = None


class AdditionalGuardConfigSchema(_BaseSchema):
    cost: Optional[CostMetricSchema] = None
    tool_call: Optional[dict[str, Any]] = None
    agent_guideline: Optional[str] = Field(default=None, max_length=MAX_GUIDELINE_LENGTH)
