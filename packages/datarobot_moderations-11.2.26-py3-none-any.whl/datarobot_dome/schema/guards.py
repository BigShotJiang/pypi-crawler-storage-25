#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
"""Guard type hierarchy and discriminated union."""

from typing import Annotated
from typing import Literal
from typing import Optional
from typing import Union

from pydantic import Field
from pydantic import model_validator

from datarobot_dome.constants import AwsModel
from datarobot_dome.constants import GoogleModel
from datarobot_dome.constants import GuardLLMType
from datarobot_dome.constants import GuardStage
from datarobot_dome.constants import GuardType
from datarobot_dome.constants import NemoEvaluatorType
from datarobot_dome.constants import OOTBType
from datarobot_dome.schema._base import _BaseSchema
from datarobot_dome.schema.guard_config import AdditionalGuardConfigSchema
from datarobot_dome.schema.guard_config import InterventionSchema
from datarobot_dome.schema.guard_config import ModelInfoSchema
from datarobot_dome.schema.guard_config import NemoLLMJudgeConfigSchema
from datarobot_dome.schema.guard_config import NemoResponseRelevancyConfigSchema
from datarobot_dome.schema.guard_config import NemoTopicAdherenceConfigSchema
from datarobot_dome.validation_limits import MAX_GUARD_DESCRIPTION_LENGTH
from datarobot_dome.validation_limits import MAX_GUARD_NAME_LENGTH
from datarobot_dome.validation_limits import MAX_TOKEN_LENGTH
from datarobot_dome.validation_limits import MAX_URL_LENGTH
from datarobot_dome.validation_limits import OBJECT_ID_LENGTH

_LlmTypeLiteral = Literal[
    GuardLLMType.OPENAI,
    GuardLLMType.AZURE_OPENAI,
    GuardLLMType.GOOGLE,
    GuardLLMType.AMAZON,
    GuardLLMType.DATAROBOT,
    GuardLLMType.NIM,
    GuardLLMType.LLM_GATEWAY,
]


class _LlmProviderMixin(_BaseSchema):
    """LLM provider fields shared by OOTB LLM-backed subtypes and both Nemo guard types.

    Sources:
    - guard_llm_mixin.GuardLLMMixin.get_llm reads all these from config for GuardType.OOTB
    - NemoGuardrailsSchema and NemoEvaluatorSchema also carry these fields
    """

    deployment_id: Optional[str] = Field(default=None, max_length=OBJECT_ID_LENGTH)
    llm_type: Optional[_LlmTypeLiteral] = None
    llm_gateway_model_id: Optional[str] = None
    openai_api_key: Optional[str] = Field(default=None, max_length=MAX_TOKEN_LENGTH)
    openai_deployment_id: Optional[str] = Field(default=None, max_length=OBJECT_ID_LENGTH)
    openai_api_base: Optional[str] = Field(default=None, max_length=MAX_URL_LENGTH)
    google_region: Optional[str] = None
    google_model: Optional[
        Literal[
            GoogleModel.CHAT_BISON,
            GoogleModel.GEMINI_15_FLASH,
            GoogleModel.GEMINI_15_PRO,
        ]
    ] = None
    aws_region: Optional[str] = None
    aws_model: Optional[
        Literal[
            AwsModel.TITAN,
            AwsModel.ANTHROPIC_CLAUDE_2,
            AwsModel.ANTHROPIC_CLAUDE_3_HAIKU,
            AwsModel.ANTHROPIC_CLAUDE_3_SONNET,
            AwsModel.ANTHROPIC_CLAUDE_3_OPUS,
            AwsModel.ANTHROPIC_CLAUDE_3_5_SONNET_V1,
            AwsModel.ANTHROPIC_CLAUDE_3_5_SONNET_V2,
            AwsModel.AMAZON_NOVA_LITE,
            AwsModel.AMAZON_NOVA_MICRO,
            AwsModel.AMAZON_NOVA_PRO,
        ]
    ] = None


class _BaseGuardSchema(_BaseSchema):
    name: str = Field(max_length=MAX_GUARD_NAME_LENGTH)
    description: Optional[str] = Field(default=None, max_length=MAX_GUARD_DESCRIPTION_LENGTH)
    stage: Union[
        Literal[GuardStage.PROMPT, GuardStage.RESPONSE],
        Annotated[list[Literal[GuardStage.PROMPT, GuardStage.RESPONSE]], Field(min_length=1)],
    ]
    intervention: Optional[InterventionSchema] = None
    copy_citations: bool = False
    is_agentic: bool = False
    additional_guard_config: Optional[AdditionalGuardConfigSchema] = None


class OOTBGuardSchema(_BaseGuardSchema, _LlmProviderMixin):
    type: Literal[GuardType.OOTB]
    ootb_type: Literal[
        OOTBType.TOKEN_COUNT,
        OOTBType.ROUGE_1,
        OOTBType.FAITHFULNESS,
        OOTBType.AGENT_GOAL_ACCURACY,
        OOTBType.CUSTOM_METRIC,
        OOTBType.COST,
        OOTBType.TASK_ADHERENCE,
        OOTBType.GUIDELINE_ADHERENCE,
    ]
    faas_url: Optional[str] = Field(default=None, max_length=MAX_URL_LENGTH)


class ModelGuardSchema(_BaseGuardSchema):
    type: Literal[GuardType.MODEL]
    deployment_id: Optional[str] = Field(default=None, max_length=OBJECT_ID_LENGTH)
    model_info: Optional[ModelInfoSchema] = None


class NemoGuardrailsSchema(_BaseGuardSchema, _LlmProviderMixin):
    type: Literal[GuardType.NEMO_GUARDRAILS]


class NemoEvaluatorSchema(_BaseGuardSchema, _LlmProviderMixin):
    type: Literal[GuardType.NEMO_EVALUATOR]
    nemo_evaluator_type: Literal[
        NemoEvaluatorType.LLM_JUDGE,
        NemoEvaluatorType.CONTEXT_RELEVANCE,
        NemoEvaluatorType.RESPONSE_GROUNDEDNESS,
        NemoEvaluatorType.TOPIC_ADHERENCE,
        NemoEvaluatorType.AGENT_GOAL_ACCURACY,
        NemoEvaluatorType.RESPONSE_RELEVANCY,
        NemoEvaluatorType.FAITHFULNESS,
    ]
    llm_type: _LlmTypeLiteral
    nemo_llm_judge_config: Optional[NemoLLMJudgeConfigSchema] = None
    nemo_topic_adherence_config: Optional[NemoTopicAdherenceConfigSchema] = None
    nemo_response_relevancy_config: Optional[NemoResponseRelevancyConfigSchema] = None

    @model_validator(mode="after")
    def _validate_stage(self) -> "NemoEvaluatorSchema":
        """Enforces stage rules:
        - LLM Judge: prompt OR response, not both.
        - All other evaluators: response only.
        """
        stages = self.stage if isinstance(self.stage, list) else [self.stage]

        if self.nemo_evaluator_type == NemoEvaluatorType.LLM_JUDGE:
            if len(stages) > 1:
                raise ValueError("LLM Judge must target 'prompt' OR 'response', not both.")
            if self.nemo_llm_judge_config is None:
                raise ValueError("nemo_llm_judge_config is required for LLM Judge evaluator.")
        elif any(s == GuardStage.PROMPT for s in stages):
            raise ValueError(
                f"NeMo Evaluator type '{self.nemo_evaluator_type}' "
                "only supports the 'response' stage."
            )

        if (
            self.nemo_evaluator_type == NemoEvaluatorType.TOPIC_ADHERENCE
            and self.nemo_topic_adherence_config is None
        ):
            raise ValueError(
                "nemo_topic_adherence_config is required for Topic Adherence evaluator."
            )

        if (
            self.nemo_evaluator_type == NemoEvaluatorType.RESPONSE_RELEVANCY
            and self.nemo_response_relevancy_config is None
        ):
            raise ValueError(
                "nemo_response_relevancy_config is required for Response Relevancy evaluator."
            )

        return self


GuardSchema = Annotated[
    Union[OOTBGuardSchema, ModelGuardSchema, NemoGuardrailsSchema, NemoEvaluatorSchema],
    Field(discriminator="type"),
]
