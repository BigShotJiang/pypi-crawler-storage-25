#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
"""DeepEval LLM adapter — part of the ``llm-eval`` optional extra.

This module is intentionally NOT imported at the top of any other module.
It is loaded lazily at runtime only when a DeepEval-backed guard is instantiated.
"""

from __future__ import annotations

from datarobot_dome._import_utils import require_extra

try:
    from deepeval.models import DeepEvalBaseLLM
except ImportError as _e:
    raise require_extra("deepeval", "llm-eval", _e)


class ModerationDeepEvalLLM(DeepEvalBaseLLM):
    """Thin adapter wrapping a Langchain or LlamaIndex LLM for DeepEval compatibility.

    Uses duck-typing to dispatch between the two LLM frameworks so that neither
    ``langchain`` nor ``llama-index`` needs to be imported at class-definition time.
    """

    def __init__(self, llm) -> None:
        self.llm = llm
        super().__init__()

    def load_model(self, *args, **kwargs):
        """Return the underlying LLM instance."""
        return self.llm

    def generate(self, prompt: str) -> str:
        """Generate a response synchronously.

        Dispatches to the correct framework:
        - Langchain LLMs expose ``.invoke()`` returning an object with ``.content``
        - LlamaIndex LLMs expose ``.complete()`` returning an object with ``.text``
        """
        if hasattr(self.llm, "invoke"):
            return self.llm.invoke(prompt).content
        return self.llm.complete(prompt).text

    async def a_generate(self, prompt: str) -> str:
        """Generate a response asynchronously."""
        if hasattr(self.llm, "ainvoke"):
            res = await self.llm.ainvoke(prompt)
            return res.content
        res = await self.llm.acomplete(prompt)
        return res.text

    def get_model_name(self) -> str:
        """Return a human-readable model name for DeepEval reporting."""
        return "ModerationDeepEvalLLM"
