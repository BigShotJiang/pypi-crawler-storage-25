#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
"""Shared helper for optional-dependency ImportErrors with actionable messages."""


def require_extra(package: str, extra: str, cause: ImportError) -> ImportError:
    """Return an ImportError with a human-readable installation hint.

    Parameters
    ----------
    package
        The package name that failed to import.
    extra
        The Poetry/pip extras group that provides the package.
    cause
        The original ImportError to chain as the exception cause.

    Returns
    -------
    ImportError
        A new ImportError with a clear, actionable message.

    Examples
    --------
    try:
        import nemoguardrails
    except ImportError as e:
        raise require_extra("nemoguardrails", "nemo", e)
    """
    exc = ImportError(
        f"'{package}' is not installed. "
        f"Install it with: pip install 'datarobot-moderations[{extra}]'"
    )
    exc.__cause__ = cause
    return exc
