#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
"""Field-length limits used by both trafaret (guards/validation.py) and
Pydantic (schema/) guard config validation.

This file has no imports so it can be loaded in any execution context without
pulling in trafaret, the datarobot SDK, or any other heavy dependency.
"""

MAX_COLUMN_NAME_LENGTH = 255
MAX_GUARD_COLUMN_NAME_LENGTH = 255
MAX_GUARD_DESCRIPTION_LENGTH = 4096
MAX_GUARD_MESSAGE_LENGTH = 4096
MAX_GUARD_NAME_LENGTH = 255
MAX_GUIDELINE_LENGTH = 4096
MAX_REFERENCE_TOPIC_LENGTH = 4096
MAX_REGEX_LENGTH = 255
MAX_TOKEN_LENGTH = 255
MAX_URL_LENGTH = 255
OBJECT_ID_LENGTH = 24
