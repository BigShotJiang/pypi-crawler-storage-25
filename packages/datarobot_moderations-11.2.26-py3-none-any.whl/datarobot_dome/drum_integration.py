#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
import warnings

from datarobot_moderation_interface.drum_integration import *  # noqa: F401, F403
from datarobot_moderation_interface.drum_integration import (
    moderation_pipeline_factory,  # noqa: F401
)

warnings.warn(
    "datarobot_dome.drum_integration is deprecated. "
    "Use datarobot_moderation_interface.drum_integration instead.",
    DeprecationWarning,
    stacklevel=2,
)
