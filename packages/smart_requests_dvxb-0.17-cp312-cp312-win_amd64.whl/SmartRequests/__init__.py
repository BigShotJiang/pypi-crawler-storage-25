# __init__.py
from .session import SmartSession as smart_session
from ._docs import module_info as info

__version__     = "1.0.0"
__description__ = "Universal caching wrapper for any sync HTTP session"
__author__      = "dharmik.vadher@xbyte.io"
__author_email__      = "dharmik.vadher@xbyte.io"
__maintainer__        = "dharmik.vadher@xbyte.io"
__maintainer_email__  = "dharmik.vadher@xbyte.io"

__doc__ = f"""
smart_session v{__version__}
{__description__}

Wrap any sync HTTP session (curl_cffi, requests, cloudscraper, tls_client,
httpx) with transparent disk caching, response validation, and per-request
mode control.

Quick start:
    from smart_session import smart_session
    sess = smart_session(Session, impersonate="chrome124")
    resp = sess.get(url, mode="r", filepath="cache/page.html")

Full documentation:
    import smart_session; smart_session.info()   # module overview
    sess.docs                                     # instance documentation
"""

__all__ = ["smart_session", "info"]