"""Data models for backgammon positions, moves, and decisions."""

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple


class Player(Enum):
    """Player identifier."""
    X = "X"  # Top player
    O = "O"  # Bottom player


class CubeState(Enum):
    """Doubling cube state."""
    CENTERED = "centered"
    X_OWNS = "x_owns"
    O_OWNS = "o_owns"


class DecisionType(Enum):
    """Type of decision."""
    CHECKER_PLAY = "checker_play"
    CUBE_ACTION = "cube_action"


@dataclass(frozen=True)
class GameRules:
    """Game-rule flags carried by XGID field 7.

    Per the XGID spec, the meaning of the bits depends on match_length:

      Match play (match_length > 0):
          bit 0 = Crawford rule. Higher bits are unused.

      Unlimited (match_length == 0):
          value = Jacoby + 2*Beaver
          bit 0 = Jacoby, bit 1 = Beavers-allowed.

    Encapsulating the polymorphism here means the rest of the code can read
    `rules.crawford` / `rules.jacoby` / `rules.beavers_allowed` without bit-
    twiddling, and impossible combinations (e.g. crawford in unlimited) are
    rejected at construction time.
    """

    match_length: int = 0
    crawford: bool = False
    jacoby: bool = False
    beavers_allowed: bool = False

    def __post_init__(self):
        if self.match_length < 0:
            raise ValueError(f"match_length must be >= 0, got {self.match_length}")
        if self.match_length > 0:
            if self.jacoby or self.beavers_allowed:
                raise ValueError(
                    "jacoby/beavers_allowed only apply to unlimited games "
                    f"(match_length == 0); got match_length={self.match_length}"
                )
        else:  # match_length == 0
            if self.crawford:
                raise ValueError(
                    "crawford only applies to match play; "
                    "got match_length=0 with crawford=True"
                )

    @classmethod
    def from_xgid_field(cls, match_length: int, cj: int) -> "GameRules":
        """Decode XGID field 7 into a GameRules.

        cj is the integer at field 7. In match play only bit 0 is meaningful;
        higher bits are dropped (XG can emit cj=3 in match play and we treat
        bit 1 as a no-op rather than an error).
        """
        if cj < 0 or cj > 3:
            raise ValueError(f"XGID field 7 must be in [0, 3], got {cj}")
        if match_length > 0:
            return cls(match_length=match_length, crawford=bool(cj & 1))
        return cls(
            match_length=0,
            jacoby=bool(cj & 1),
            beavers_allowed=bool(cj & 2),
        )

    def to_xgid_field(self) -> int:
        """Encode this rules set as the XGID field 7 integer."""
        if self.match_length > 0:
            return 1 if self.crawford else 0
        return (1 if self.jacoby else 0) | (2 if self.beavers_allowed else 0)


@dataclass
class Position:
    """
    Represents a backgammon position.

    Board representation:
    - points[0] = bar for X (top player)
    - points[1-24] = board points (point 24 is X's home, point 1 is O's home)
    - points[25] = bar for O (bottom player)

    Positive numbers = X checkers, negative numbers = O checkers
    """
    points: List[int] = field(default_factory=lambda: [0] * 26)
    x_off: int = 0  # Checkers borne off by X
    o_off: int = 0  # Checkers borne off by O

    def __post_init__(self):
        """Validate position."""
        if len(self.points) != 26:
            raise ValueError("Position must have exactly 26 points (0=X bar, 1-24=board, 25=O bar)")

    @classmethod
    def from_xgid(cls, xgid: str) -> 'Position':
        """
        Parse a position from XGID format.
        XGID format: e.g., "XGID=-b----E-C---eE---c-e----B-:1:0:1:63:0:0:0:0:10"
        """
        # Import here to avoid circular dependency
        from ankigammon.utils.xgid import parse_xgid
        position, _ = parse_xgid(xgid)
        return position

    @classmethod
    def from_ogid(cls, ogid: str) -> 'Position':
        """
        Parse a position from OGID format.
        OGID format: e.g., "11jjjjjhhhccccc:ooddddd88866666:N0N::W:IW:0:0:1:0"
        """
        # Import here to avoid circular dependency
        from ankigammon.utils.ogid import parse_ogid
        position, _ = parse_ogid(ogid)
        return position

    @classmethod
    def from_gnuid(cls, gnuid: str) -> 'Position':
        """
        Parse a position from GNUID format.
        GNUID format: e.g., "4HPwATDgc/ABMA:8IhuACAACAAE"
        """
        # Import here to avoid circular dependency
        from ankigammon.utils.gnuid import parse_gnuid
        position, _ = parse_gnuid(gnuid)
        return position

    def to_xgid(
        self,
        cube_value: int = 1,
        cube_owner: 'CubeState' = None,
        dice: Optional[Tuple[int, int]] = None,
        on_roll: 'Player' = None,
        score_x: int = 0,
        score_o: int = 0,
        match_length: int = 0,
        crawford_jacoby: int = 0,
    ) -> str:
        """Convert position to XGID format."""
        # Import here to avoid circular dependency
        from ankigammon.utils.xgid import encode_xgid
        if cube_owner is None:
            cube_owner = CubeState.CENTERED
        if on_roll is None:
            on_roll = Player.O
        return encode_xgid(
            self,
            cube_value=cube_value,
            cube_owner=cube_owner,
            dice=dice,
            on_roll=on_roll,
            score_x=score_x,
            score_o=score_o,
            match_length=match_length,
            crawford_jacoby=crawford_jacoby,
        )

    def to_ogid(
        self,
        cube_value: int = 1,
        cube_owner: 'CubeState' = None,
        cube_action: str = 'N',
        dice: Optional[Tuple[int, int]] = None,
        on_roll: 'Player' = None,
        game_state: str = '',
        score_x: int = 0,
        score_o: int = 0,
        match_length: Optional[int] = None,
        match_modifier: str = '',
        only_position: bool = False,
    ) -> str:
        """Convert position to OGID format."""
        # Import here to avoid circular dependency
        from ankigammon.utils.ogid import encode_ogid
        if cube_owner is None:
            cube_owner = CubeState.CENTERED
        return encode_ogid(
            self,
            cube_value=cube_value,
            cube_owner=cube_owner,
            cube_action=cube_action,
            dice=dice,
            on_roll=on_roll,
            game_state=game_state,
            score_x=score_x,
            score_o=score_o,
            match_length=match_length,
            match_modifier=match_modifier,
            only_position=only_position,
        )

    def to_gnuid(
        self,
        cube_value: int = 1,
        cube_owner: 'CubeState' = None,
        dice: Optional[Tuple[int, int]] = None,
        on_roll: 'Player' = None,
        score_x: int = 0,
        score_o: int = 0,
        match_length: int = 0,
        crawford: bool = False,
        only_position: bool = False,
    ) -> str:
        """Convert position to GNUID format."""
        # Import here to avoid circular dependency
        from ankigammon.utils.gnuid import encode_gnuid
        if cube_owner is None:
            cube_owner = CubeState.CENTERED
        if on_roll is None:
            on_roll = Player.X
        return encode_gnuid(
            self,
            cube_value=cube_value,
            cube_owner=cube_owner,
            dice=dice,
            on_roll=on_roll,
            score_x=score_x,
            score_o=score_o,
            match_length=match_length,
            crawford=crawford,
            only_position=only_position,
        )

    def copy(self) -> 'Position':
        """Create a deep copy of the position."""
        return Position(
            points=self.points.copy(),
            x_off=self.x_off,
            o_off=self.o_off
        )


@dataclass
class Move:
    """
    Represents a candidate move with its analysis.
    """
    notation: str  # Move notation for MCQ and answer display (e.g., "13/9 6/5" or "double/take")
    equity: float  # Equity of this move
    error: float = 0.0  # Error compared to best move (0 for best)
    rank: int = 1  # Rank among all candidates, including synthetic moves (1 = best)
    xg_rank: Optional[int] = None  # Order in XG's "Cubeful Equities:" section (1-3)
    xg_error: Optional[float] = None  # Error relative to first option in XG's Cubeful Equities
    xg_notation: Optional[str] = None  # Original notation from XG (e.g., "No double" vs "No double/Take")
    resulting_position: Optional[Position] = None  # Position after applying this move
    from_xg_analysis: bool = True  # Whether from XG's analysis (True) or synthetically generated (False)
    was_played: bool = False  # Whether this move was actually played in the game
    # Engine-reported analysis tier for this individual move (e.g. "Rollout", "4-ply", "2-ply",
    # "Screening"). XG can analyze different candidate moves at different depths within a single
    # position; capturing per-move tier lets the UI flag moves whose equity is less reliable.
    analysis_level: Optional[str] = None
    # Winning chances percentages
    player_win_pct: Optional[float] = None  # Player winning percentage (e.g., 52.68)
    player_gammon_pct: Optional[float] = None  # Player gammon percentage (e.g., 14.35)
    player_backgammon_pct: Optional[float] = None  # Player backgammon percentage (e.g., 0.69)
    opponent_win_pct: Optional[float] = None  # Opponent winning percentage (e.g., 47.32)
    opponent_gammon_pct: Optional[float] = None  # Opponent gammon percentage (e.g., 12.42)
    opponent_backgammon_pct: Optional[float] = None  # Opponent backgammon percentage (e.g., 0.55)
    # Cubeless equity calculated from probabilities: 2*p(w)-1+2*(p(wg)-p(lg))+3*(p(wbg)-p(lbg))
    cubeless_equity: Optional[float] = None

    def calculate_cubeless_equity(
        self,
        cumulative: bool = False,
        match_length: int = 0,
        player_away: int = 0,
        opponent_away: int = 0,
        cube_value: int = 1,
        crawford: bool = False,
        post_crawford: bool = False
    ) -> Optional[float]:
        """
        Calculate cubeless equity from win/gammon/backgammon probabilities.

        For money games (match_length=0), returns raw equity.
        For match play, returns normalized equity using Match Equity Table.

        Args:
            cumulative: If True, use formula for cumulative gammon % (XG format).
                       If False, use formula for non-cumulative gammon % (GNUBG format).
            match_length: Match length (0 for unlimited/money games).
            player_away: Points player needs to win (for match play).
            opponent_away: Points opponent needs to win (for match play).
            cube_value: Current cube value.
            crawford: Whether this is a Crawford game.
            post_crawford: Whether this is post-Crawford.

        Returns:
            Cubeless equity value, or None if probabilities not available.
        """
        if self.player_win_pct is None:
            return None

        opponent_win = self.opponent_win_pct if self.opponent_win_pct is not None else (100 - self.player_win_pct)

        # Match play: use MET for normalized equity
        if match_length > 0 and player_away > 0 and opponent_away > 0:
            from ankigammon.utils.met import calculate_match_cubeless_equity
            return calculate_match_cubeless_equity(
                player_win_pct=self.player_win_pct,
                player_gammon_pct=self.player_gammon_pct or 0,
                player_backgammon_pct=self.player_backgammon_pct or 0,
                opponent_win_pct=opponent_win,
                opponent_gammon_pct=self.opponent_gammon_pct or 0,
                opponent_backgammon_pct=self.opponent_backgammon_pct or 0,
                player_away=player_away,
                opponent_away=opponent_away,
                cube_value=cube_value,
                crawford=crawford,
                post_crawford=post_crawford,
                cumulative_gammons=cumulative
            )

        # Money game: use simple formula
        from ankigammon.utils.met import calculate_money_cubeless_equity
        return calculate_money_cubeless_equity(
            player_win_pct=self.player_win_pct,
            player_gammon_pct=self.player_gammon_pct or 0,
            player_backgammon_pct=self.player_backgammon_pct or 0,
            opponent_win_pct=opponent_win,
            opponent_gammon_pct=self.opponent_gammon_pct or 0,
            opponent_backgammon_pct=self.opponent_backgammon_pct or 0,
            cumulative_gammons=cumulative
        )

    def __str__(self) -> str:
        """Human-readable representation."""
        if self.rank == 1:
            return f"{self.notation} (Equity: {self.equity:.3f})"
        else:
            return f"{self.notation} (Equity: {self.equity:.3f}, Error: {self.error:.3f})"

    def analysis_tier_rank(self) -> int:
        """Quality rank of this move's analysis tier; higher = better.

        Used to group candidate moves by analysis depth in the back-card
        table so a 1-ply screening eval never sits above a 4-ply eval just
        because its noisy equity happened to look small. Within a tier, the
        caller still sorts by equity/error.

        Ordering (high to low):
            Rollout > Book > XG Roller++ > XG Roller+ > XG Roller >
            N-ply (by N, with "3-ply red" treated as ~3-ply) > unknown.

        Book entries are XG's pre-rolled-out opening-book analyses, so they
        are treated as roughly equivalent to a fresh rollout for ranking.
        """
        label = self.analysis_level
        if not label:
            return -1
        if label == "Rollout":
            return 100
        if label == "Book":
            return 95
        if label == "XG Roller++":
            return 90
        if label == "XG Roller+":
            return 89
        if label == "XG Roller":
            return 88
        if label == "3-ply red":
            # Reduced-search 3-ply (XG's "3-ply red"). Rank alongside full
            # 3-ply; secondary equity-error sort breaks ties between them.
            return 3
        import re as _re
        m = _re.match(r'^(\d+)-ply$', label)
        if m:
            return int(m.group(1))
        # Unknown labels (e.g. "Level 42" raw fallback) sort below known tiers
        # but above completely-unlabeled moves.
        return 0


@dataclass
class Decision:
    """
    Represents a single decision point from XG analysis.
    """
    # Position information
    position: Position
    position_image_path: Optional[str] = None  # Path to board image (from HTML export)
    xgid: Optional[str] = None

    # Game context
    on_roll: Player = Player.O
    dice: Optional[Tuple[int, int]] = None  # Dice roll (None for cube decisions)
    score_x: int = 0
    score_o: int = 0
    match_length: int = 0  # Match length (0 for unlimited games)
    crawford: bool = False  # Whether this is a Crawford game
    cube_value: int = 1
    cube_owner: CubeState = CubeState.CENTERED

    # Decision analysis
    decision_type: DecisionType = DecisionType.CHECKER_PLAY
    candidate_moves: List[Move] = field(default_factory=list)

    # Cube decision errors (only for CUBE_ACTION decisions)
    cube_error: Optional[float] = None  # Doubler's error on double/no double decision (-1000 if not analyzed)
    take_error: Optional[float] = None  # Responder's error on take/pass decision (-1000 if not analyzed)

    # Cubeless equity (for cube decisions) - position value without cube dynamics
    # No Double equity is calculated at current cube value
    # Double equity is calculated at 2x current cube value (different in match play due to MET)
    cubeless_equity: Optional[float] = None  # No Double cubeless equity
    double_cubeless_equity: Optional[float] = None  # Double cubeless equity

    # XG binary error (for checker play from .xg files)
    xg_error_move: Optional[float] = None  # XG's ErrMove field - authoritative error for filtering

    # Winning chances percentages (for cube decisions)
    player_win_pct: Optional[float] = None
    player_gammon_pct: Optional[float] = None
    player_backgammon_pct: Optional[float] = None
    opponent_win_pct: Optional[float] = None
    opponent_gammon_pct: Optional[float] = None
    opponent_backgammon_pct: Optional[float] = None

    # Source metadata
    source_file: Optional[str] = None
    source_description: Optional[str] = None  # Human-readable source description (e.g., "Analyzed with GnuBG from XGID")
    original_position_format: Optional[str] = None  # Original format entered (XGID, GNUID, or OGID)
    game_number: Optional[int] = None
    move_number: Optional[int] = None

    # User annotations
    note: Optional[str] = None  # User's note or explanation for this position

    # Cube-card variant signals (only meaningful for CUBE_ACTION decisions)
    user_player: Optional[Player] = None  # Set during import filtering when only one player is studied; None means full card
    beaverable: bool = False  # True iff analyzer flagged the take as beaverable (used for take card MCQ in unlimited games)
    beavers_allowed: bool = False  # True iff the Beavers rule is enabled for this game (XGID field 7 bit 1, only meaningful for match_length == 0)
    jacoby: bool = False  # True iff the Jacoby rule is enabled for this game (XGID field 7 bit 0, only meaningful for match_length == 0)

    def __post_init__(self):
        """Post-initialization processing."""
        # Sort dice so larger value is first (e.g., (3, 6) -> (6, 3))
        if self.dice is not None:
            self.dice = tuple(sorted(self.dice, reverse=True))
        # Validate the rule flags via GameRules. Constructing one will raise
        # ValueError on impossible combinations (e.g. match_length=5 with
        # jacoby=True, or unlimited with crawford=True).
        GameRules(
            match_length=self.match_length,
            crawford=self.crawford,
            jacoby=self.jacoby,
            beavers_allowed=self.beavers_allowed,
        )

    @property
    def rules(self) -> "GameRules":
        """Read-only view of the rule flags as a single value object."""
        return GameRules(
            match_length=self.match_length,
            crawford=self.crawford,
            jacoby=self.jacoby,
            beavers_allowed=self.beavers_allowed,
        )

    def get_best_move(self) -> Optional[Move]:
        """Get the best move (rank 1)."""
        for move in self.candidate_moves:
            if move.rank == 1:
                return move
        return self.candidate_moves[0] if self.candidate_moves else None

    def get_cube_error_attribution(self) -> dict:
        """
        For cube decisions, identify which player(s) made errors.

        Returns:
            Dictionary with:
            - 'doubler_error': float or None (error made by player on roll)
            - 'responder_error': float or None (error made by opponent)
            - 'doubler': Player or None (who doubled)
            - 'responder': Player or None (who responded)
        """
        if self.decision_type != DecisionType.CUBE_ACTION:
            return {
                'doubler_error': None,
                'responder_error': None,
                'doubler': None,
                'responder': None
            }

        # Determine who doubled and who responded
        doubler = self.on_roll
        responder = Player.X if self.on_roll == Player.O else Player.O

        # Extract errors (-1000 indicates not analyzed)
        doubler_error = self.cube_error if self.cube_error and self.cube_error != -1000 else None
        responder_error = self.take_error if self.take_error and self.take_error != -1000 else None

        return {
            'doubler_error': doubler_error,
            'responder_error': responder_error,
            'doubler': doubler,
            'responder': responder
        }

    def get_short_display_text(self, score_format: str = "absolute") -> str:
        """Get short display text for list views.

        Args:
            score_format: "absolute" or "away"
        """
        # Build score/game type string
        if self.match_length > 0:
            if score_format == "away":
                x_away = self.match_length - self.score_x
                o_away = self.match_length - self.score_o
                score = f"{o_away}a-{x_away}a"
            else:
                score = f"{self.score_o}-{self.score_x} of {self.match_length}"
            if self.crawford:
                score += " Crawford"
        else:
            score = "Unlimited"

        if self.decision_type == DecisionType.CHECKER_PLAY:
            dice_str = f"{self.dice[0]}{self.dice[1]}" if self.dice else "—"
            return f"Checker | {dice_str} | {score}"
        else:
            return f"Cube | {score}"

    def get_metadata_text(self, score_format: str = "absolute") -> str:
        """Get formatted metadata for card display.

        Args:
            score_format: How to display match scores.
                - "absolute": Show current scores
                - "away": Show points needed to win
        """
        dice_str = f"{self.dice[0]}{self.dice[1]}" if self.dice else "N/A"

        # Display em dash for centered cube, otherwise show value
        if self.cube_owner == CubeState.CENTERED:
            cube_str = "—"
        else:
            cube_str = f"{self.cube_value}"

        # "Black" is a sentinel that card_generator.py replaces with a
        # colored circle indicating the on-roll player's checker color.
        player_name = "Black"

        # Build metadata string based on game type
        if self.match_length > 0:
            match_str = f"{self.match_length}pt"
            if self.crawford:
                match_str += " (Crawford)"

            # Score order follows board orientation: bottom player first.
            # The on-roll player is rendered at the bottom of the board.
            if self.on_roll == Player.X:
                bottom_score, top_score = self.score_x, self.score_o
            else:
                bottom_score, top_score = self.score_o, self.score_x

            if score_format == "away":
                bottom_away = self.match_length - bottom_score
                top_away = self.match_length - top_score
                score_str = f"{bottom_away}a-{top_away}a"
            else:  # "absolute" is the default
                score_str = f"{bottom_score}-{top_score}"

            return (
                f"{player_name} | "
                f"Dice: {dice_str} | "
                f"Score: {score_str} | "
                f"Cube: {cube_str} | "
                f"Match: {match_str}"
            )
        else:
            return (
                f"{player_name} | "
                f"Dice: {dice_str} | "
                f"Cube: {cube_str} | "
                f"Unlimited"
            )

    def __str__(self) -> str:
        """Human-readable representation."""
        return f"Decision({self.decision_type.value}, {self.get_metadata_text()})"
