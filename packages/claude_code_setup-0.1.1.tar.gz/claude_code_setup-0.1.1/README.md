# Claude Code Setup

A personal Claude Code configuration toolkit. Each component is self-contained and installs into `~/.claude` with a single command. Currently includes a status line that replaces the default bottom bar with a richer, information-dense display.

---

## Components

| Component | Description |
|---|---|
| `statusline` | 5-row status bar showing git state, context usage, session cost, rate limits, and last message |

---

## Installation

```bash
uvx claude-code-setup
```

Restart Claude Code after installing. The status bar appears at the bottom of the interface.

> **No `uv`?** Install it with `curl -LsSf https://astral.sh/uv/install.sh | sh`

**Install a specific component:**
```bash
uvx claude-code-setup statusline
```

**Uninstall:**
```bash
uvx claude-code-setup --uninstall
```

---

## What's included

### Status line

A 5-row bar at the bottom of Claude Code showing everything useful at a glance.

```
Session  │  Sonnet [my-session]  │  📁 project  │  🔀 main  │  ⚡ high reasoning
Git      │  +3 staged  ·  ~2 modified  ·  ↑1 ahead  ·  📦 1 stashed  ·  "Fix bug · 5m ago"
Context  │  ████░░░░░░ 42% used  ·  84k of 200k tokens  ·  🗄 83% cached  ·  💰 $0.08  ·  ⏱ 5m 30s
Limits   │  5-hour: 23% used, resets in 2h  ·  7-day: 41% used, resets in 3d  ·  v2.1.90
Message  │  💬 last user message…
```

Color coding: green = healthy · amber = needs attention · red = critical.

| Row | Label | Always shown? | Content |
|---|---|---|---|
| 1 | `Session` | Yes | Model, session, directory, git branch, effort, vim mode |
| 2 | `Git` | In git repos | Staged / modified / untracked counts, ahead/behind remote, stash, last commit |
| 3 | `Context` | Yes | Context bar, token count, cache hit rate, cost, duration, API wait, lines changed |
| 4 | `Limits` | Pro/Max only | 5-hour and 7-day rate limit usage with reset countdowns, Claude Code version |
| 5 | `Message` | When available | Last user message (from transcript), truncated to 100 chars |

**See what every field means:**
```bash
uv run ~/.claude/statusline.py --help
```
