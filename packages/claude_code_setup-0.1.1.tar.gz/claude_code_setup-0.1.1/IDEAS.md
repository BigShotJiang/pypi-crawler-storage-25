# Component Ideas

| # | Component | Type | What it does |
|---|---|---|---|
| 1 | `permissions` | Settings patch | Allowlist of safe read-only commands — no script needed, just reduces permission prompts instantly |
| 2 | `session-log` | Stop hook | Appends a line to `~/.claude/session-log.md` on each stop: timestamp, cost, duration, cwd. Audit trail over time. |
| 3 | `git-checkpoint` | PreToolUse hook | Auto-stashes before Claude edits files. One-step rollback if something goes wrong. |
| 4 | `auto-format` | PostToolUse hook | Runs a configurable formatter (prettier, black, gofmt) after file writes. Claude often breaks formatting. |
| 5 | `cost-guard` | Stop hook | Warns (or blocks) when session cost crosses a threshold. Useful for teams with budgets. |
| 6 | `compact-trigger` | Stop hook | Fires a warning notification when context hits ~80%. Prevents mid-task cutoffs. |
| 7 | `env-guard` | PreToolUse hook | Blocks Claude from reading `.env`, `*.pem`, `*secret*` files. Safety net for credentials. |
| 8 | `safe-delete` | PreToolUse hook | Intercepts `rm` commands in shell and moves to trash instead of permanent delete. |
| 9 | `test-watcher` | PostToolUse hook | Runs your test command after file edits. Configurable — `pytest`, `npm test`, `go test ./...`. |
| 10 | `daily-digest` | Stop hook | Rolls up `session-log` entries into a human-readable daily summary. Good for reviewing what Claude did this week. |
