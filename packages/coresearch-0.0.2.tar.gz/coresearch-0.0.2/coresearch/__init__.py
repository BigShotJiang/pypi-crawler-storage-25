"""coresearch"""

__version__ = "0.0.1"

from coresearch.client import guidelines
