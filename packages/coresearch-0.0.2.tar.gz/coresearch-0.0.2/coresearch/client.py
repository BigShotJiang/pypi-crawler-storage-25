from pathlib import Path

_GUIDELINES_PATH = Path(__file__).parent / "guidelines.md"


def guidelines() -> str:
    """Return the contents of the bundled guidelines."""
    return _GUIDELINES_PATH.read_text()
