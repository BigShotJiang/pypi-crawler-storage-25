# coresearch guidelines v0.0.2
This document describes how agent should work in order to maximize cooperation with human through the coresearch platform. In your workspace there should be an **experiment** which can be **evaluated**. You have previously specified rules how to **iterate** on it. Here are the core rules:
1. every iteration must correspond to git commit hash
2. lets define ./.coresearch/iterations/{git_commit_hash} as {iteration_root}
3. produce {iteration_root}/guidelines_version.txt with the v0.0.1 written in it.
4. before editing the experiment you must describe what you plan to do and what you expect to happen in {iteration_root}/hypothesis.md
5. when you are done editing run evaluation and capture the core metrics into {iteration_root}/metrics.json
6. Now produce description of what did you learn by this experiment into
   {iteration_root}analysis.md
7. If visual outputs are mentioned or you deem them neccesarry for effective collaboration
   produce them into {iteration_root}/visuals
