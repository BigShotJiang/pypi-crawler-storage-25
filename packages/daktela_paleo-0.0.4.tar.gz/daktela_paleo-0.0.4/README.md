# daktela-paleo

`daktela-paleo` is a Python 3.12+ Textual application for building a keyboard-first terminal UI around Daktela Contact Center workflows.

## Install

Install the latest published build from PyPI with `pipx`:

```bash
pipx install daktela-paleo
```

Then run:

```bash
daktela-paleo
```

Hit `i` and log in to the instance. You will need a `user_token`. (If you are Daktela's customer ask daktela@daktela.com for creating one)

## Documentation

The project documentation lives under `docs/`.

- `docs/quick-start.md` covers first launch and connecting a Daktela instance.
- `docs/basic-navigation.md` covers the main-screen keyboard workflow.
- `docs/working-with-tickets.md` covers ticket editing and reply actions.
- `docs/index.md` is the overview page for the documentation site.

Contributor workflow and local development commands now live in `CONTRIBUTING.md`.

## Project Snapshot

- Runtime: Python `3.12+`
- Default contributor interpreter: Python `3.14`
- UI framework: `textual`
- Networking client: `httpx`
- Tooling: `uv`, `pytest`, `pyright`, `ruff`

## License

MIT. See `LICENSE`.
