# Interaction Model

`daktela-paleo` is intentionally keyboard-first and terminal-native. The app should feel closer to LazyGit or LazyDocker than to a mouse-oriented admin panel.

For step-by-step operator instructions, use [Quick Start](quick-start.md), [Basic Navigation](basic-navigation.md), and [Working With Tickets](working-with-tickets.md). This page focuses on the shared interaction rules behind those workflows.

## Core navigation rules

- `j` / `k` and the arrow keys are the default list-navigation model.
- `h` / `l` and left/right arrows are the default pane-navigation model when multiple panes are present.
- `Enter` opens, confirms, or focuses the active item.
- `q` quits the app or closes the current top-level context when that behavior makes sense.
- `Esc` backs out of dialogs, overlays, or secondary screens.

These rules come from the repository interaction guidelines in `AGENTS.md` and are already reflected in the Textual widgets and screens in the current app.

## Current top-level app shortcuts

The application shell currently exposes these bindings:

- `q` quits the app
- `v` focuses the views pane
- `h` or left arrow moves focus back to the views pane
- `c` opens the saved-instance manager

## Main screen workflow

The main screen is a two-pane browser:

- The left pane contains ticket views.
- The right pane contains the ticket table for the active view.

The views list supports the shared list navigation model:

- `j` / `k` move between views
- `l` or right arrow opens the highlighted view

The ticket table follows the same pattern and adds a quick way back:

- `j` / `k` move through tickets
- numeric prefixes with `j` / `k` perform vi-style repeated movement
- `/` opens an inline regex prompt scoped to the visible ticket rows
- `n` and `N` move forward and backward through the current search matches
- `l` opens the highlighted ticket
- `h` moves focus back to the views pane
- `r` refreshes the active view

## Ticket detail workflow

The ticket detail screen keeps the keyboard-first model but adds ticket actions:

- `Ctrl+S` saves edits or submits an open inline composer
- `Ctrl+E` opens the active inline comment or email-body draft in the external editor from `$EDITOR`
- `c`, `o`, and `w` set the ticket stage to close, open, and waiting
- `m` assigns the ticket to the current user
- `n` opens a new top-level inline comment composer
- `u` opens a picker for links discovered in ticket activities
- `d` opens a destination-path popup for attachments on the selected activity
- `b` opens the ticket in a browser
- `Tab` and `Shift+Tab` move between the detail panes
- `q` closes the screen
- `Esc` closes the screen or cancels an inline composer first when one is active

New screens should keep aligning to this model so contributors do not have to relearn navigation between contexts.
