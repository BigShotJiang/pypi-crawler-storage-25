# Working With Tickets

This guide covers the current ticket-detail workflow: open a ticket, edit fields, save changes, use the quick actions, and add inline comments or email replies from the activity pane.

## Open a ticket

From the main screen:

1. Open a view from the views pane.
2. Move to the ticket you want in the tickets pane.
3. Press `Enter` or `l`.

The ticket detail screen opens with:

- an editable form on the left
- the activity pane on the right

## Ticket detail shortcuts

| Key | Action |
| --- | --- |
| `Ctrl+S` | Save ticket changes, or submit an open inline composer |
| `c` | Set the ticket stage to close |
| `o` | Set the ticket stage to open |
| `w` | Set the ticket stage to waiting |
| `m` | Assign the ticket to the current user |
| `n` | Open a new inline comment composer |
| `u` | Open the discovered-links picker |
| `d` | Download attachments from the selected activity |
| `b` | Open the ticket in the system browser |
| `Tab` / `Shift+Tab` | Move between left and right panes |
| `q` | Leave the ticket detail screen |
| `Esc` | Cancel an inline composer first, otherwise leave the screen |

## Editable fields

The left pane currently exposes these fields:

- title
- stage
- priority
- category
- user
- status
- description

Use `j` / `k` or the arrow keys to move between rows in the form.

## Edit a field

With the left pane focused:

1. Move to the field you want.
2. Press `Enter`, `l`, or the left arrow to start editing.
3. Change the value.
4. Press `Esc` to leave field editing and return to form navigation if needed.
5. Press `Ctrl+S` to save the ticket.

If nothing changed, the app reports `No changes to save.`

## Working with select fields

Stage, priority, category, user, and status open a select overlay.

Inside the overlay:

- `j` / `k` move through options
- `Enter` or `l` selects the highlighted option
- `h` or the left arrow closes the overlay
- `i` starts filtering the option list
- while filtering, printable keys extend the query and `Backspace` removes characters

The `user` and `status` fields also support clearing the current value from the form with `d`.

## Quick ticket actions

Some common changes have direct shortcuts so you do not need to walk the form first.

### Change the stage quickly

- `c` marks the ticket for close
- `o` marks the ticket for open
- `w` marks the ticket for waiting

These shortcuts change the stage in the form. Press `Ctrl+S` to persist the change.

### Assign the ticket to yourself

Press `m` to set the assignee to the current Daktela user. Press `Ctrl+S` to save the assignment.

### Open the ticket in the browser

Press `b` to open the ticket in the system browser.

If the active connector cannot provide a browser URL, the app shows an error in the status area instead of opening anything.

### Open a discovered activity link

Press `u` from ticket detail to scan the loaded activities for URLs and open a compact picker.

Inside the picker:

- `j` / `k` or the arrow keys move through discovered links
- `Enter`, `l`, or the right arrow opens the highlighted link in the system browser
- `y` copies the highlighted link to the terminal clipboard
- `Esc` or `q` closes the picker without opening anything

If no links are found, the app reports `No links found in ticket activities.` in the status area and keeps the current ticket detail screen in place.

### Download activity attachments

Move to the activities pane and select an activity that exposes `Download (d)`.

Press `d` to open a compact destination popup.

Inside the popup:

- the destination field starts with `~/Downloads`
- edit the path directly if you want a different target
- press `Enter` to save the selected activity attachments into the typed directory
- press `Esc` or `q` to close the popup without downloading anything

Downloaded files are written directly into the chosen directory, not into nested ticket or activity folders.

If a filename already exists, the app keeps the existing file and writes the new one with a numbered suffix such as `report (2).txt`.

After a successful download, the popup closes and the status area reports the target directory.

## Work with comments and replies

Press `n` from ticket detail to open a new top-level comment composer above the activity list.

Inside the inline composer:

- `Enter` inserts a newline
- `Ctrl+A` opens a typed path popup and stages one local file for the current comment
- `Ctrl+D` opens a compact picker to remove one staged file
- `Ctrl+E` opens the current draft in the external editor defined by `$EDITOR`
- `Ctrl+S` submits the current draft
- `Esc` cancels the draft

If the external editor cannot be launched, the current draft stays in place and the inline validation area shows the error.

When you stage attachments:

- the composer shows the currently staged files above the action row
- the path popup validates that the typed path exists, points to a readable file, and is not blank
- duplicate files are rejected without clearing the current draft
- if submit fails, the draft body and staged files stay in place so you can retry

Press `Tab` to move into the right pane.

In the activity pane:

- `j` / `k` move through activities
- activities with downloadable attachments show a `` count in the summary line
- available quick actions depend on the selected activity
- email-style activities can expose `Reply to all (r)` and `Forward (f)`
- comment-style activities can expose `Reply (r)`
- activities with downloadable files can expose `Download (d)`

When you trigger a reply action:

1. an inline composer opens above the activity list
2. comment replies also preselect the ticket `user` from the replied activity when that actor matches an assignable ticket user option
3. if the actor cannot be matched safely, the current ticket `user` stays unchanged and the status bar explains that no assignee match was found
4. email replies load a draft through the connector and expose editable `to`, `subject`, and `body` fields inline
5. focus moves into the active editor
6. `Ctrl+E` opens the current inline draft in `$EDITOR`; for email drafts it edits the `body` field and reloads the saved text back into the inline composer
7. `Enter` inserts a newline in the active editor
8. `Ctrl+S` submits the composer
9. `Esc` cancels the open draft

Comment drafts require a non-empty body. Email drafts require a non-empty recipient list. Connector failures stay visible in the inline validation area and in the status bar so you can retry without losing the draft.

## Leaving the screen with unsaved changes

If you try to close the ticket detail screen after editing fields without saving, the app opens an unsaved-changes confirmation instead of discarding the work immediately.

That flow lets you:

- save and close
- discard changes
- cancel and keep editing

## Typical workflow

1. Open the ticket from the main screen.
2. Change one or more fields in the left pane.
3. Press `Ctrl+S`.
4. Optionally press `n` for a top-level comment, or move to the right pane and add an inline comment reply or email draft.
5. Press `q` when you are done with the ticket.
