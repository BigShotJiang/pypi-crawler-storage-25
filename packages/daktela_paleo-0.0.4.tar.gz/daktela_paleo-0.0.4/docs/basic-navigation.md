# Basic Navigation

`daktela-paleo` is built around a keyboard-first, two-pane workflow. The main screen keeps views on the left and tickets on the right.

## Top-level shortcuts

These bindings are available from the application shell:

| Key | Action |
| --- | --- |
| `q` | Quit the app |
| `v` | Focus the views pane |
| `h` or left arrow | Move focus back to the views pane |
| `c` | Open the saved-instance manager |

## Main screen layout

The main screen is a browser with two panes:

- **Views** on the left
- **Tickets** on the right

The default workflow is:

1. Choose a view in the left pane.
2. Open that view.
3. Move through the tickets in the right pane.
4. Open the selected ticket.

You can also press `b` from either main-screen pane to open the currently selected view in the system browser.

## Move through views

When the views pane is focused:

- `j` / `k` move up and down
- the arrow keys also move up and down
- `Enter` or `l` opens the highlighted view

Opening a different view loads that view's ticket list and moves focus to the tickets pane.

For Daktela-backed views, the ticket list keeps the default Daktela sort order configured for that view, including refreshes and page navigation.

## Move through tickets

When the tickets pane is focused:

- `j` / `k` move up and down
- the arrow keys also move up and down
- `Enter` or `l` opens the highlighted ticket
- `h` moves focus back to the views pane
- `/` opens a regex search prompt for the visible ticket rows
- `n` jumps to the next search match and wraps around
- `N` jumps to the previous search match and wraps around
- `b` opens the selected view in the system browser
- `r` refreshes the active view

The ticket table also supports counted movement in the LazyGit style:

- type digits first, then `j` or `k`
- example: `1`, `3`, `j` jumps thirteen rows down

When search is active, the status bar shows the applied pattern and current match position, for example `/scanner 2/5`. Invalid expressions and zero-match searches also report feedback in the same status area.

## Focus rules

Focus matters because the same keys do different things depending on the active pane.

- use `v` if you want a reliable way to jump back to views
- use `h` or the left arrow to leave the ticket table
- opening a view moves you into tickets automatically

## Status and instance chrome

The bottom chrome has two roles:

- the left side shows transient status such as loading, save success, or error messages
- the right side shows the persistent active-instance context

Examples:

- `Selected view: My Open`
- `Loading tickets: Delivery`
- `Saved ticket: Broken scanner`
- `Instance: https://demo.daktela.com`

## Resizing the panes

The current app also supports dragging the vertical splitter with the mouse. This is optional; the primary model is still keyboard-first navigation.

## Next steps

- Continue with [Working With Tickets](working-with-tickets.md) for the ticket detail workflow.
- See [Interaction Model](interaction-model.md) for the higher-level navigation rules used across the app.
