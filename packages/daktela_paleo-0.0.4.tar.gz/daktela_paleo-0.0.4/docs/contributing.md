# Contributing

## Documentation workflow

Structured project documentation should live under `docs/` and be registered in `mkdocs.yml`. Keep the docs site as the canonical place for project guides that need more structure than the root `README.md`.

Use the root `README.md` as the public repository landing page and PyPI description, and use the root `CONTRIBUTING.md` for contributor workflow that should stay close to the repository root. Prefer adding durable setup, workflow, and architecture guidance to the MkDocs site so new contributors can find it from a predictable location.

## Build or serve the docs locally

Serve the docs site locally with live reload:

```bash
make docs-serve
```

Build the docs site with strict validation:

```bash
make docs-build
```

Both commands expect the project environment to be installed with:

```bash
uv sync --group dev
```

## Quality expectations

Repository changes should continue to pass the standard local checks:

```bash
uv run pytest
uv run pyright
uv run ruff check
make coverage
make pyright
make ruff
```

For TUI behavior changes, prefer updating or adding Textual pilot-driven tests so keyboard flows stay covered.

For live Daktela write tests that send email, keep the recipient locked to `tomas.lysek@daktela.com` only. Do not introduce live outbound email tests that target any other address.

## What to document next

Future project documentation should usually be added under one of these categories:

- operator workflows such as instance connection, navigation, and ticket handling
- onboarding and environment setup
- keyboard shortcuts and screen workflows
- Daktela integration behavior and configuration
- architecture notes for major app subsystems
- contributor workflows that are too large for the root README

If you add a new page, wire it into `mkdocs.yml` so it appears in the site navigation immediately.
