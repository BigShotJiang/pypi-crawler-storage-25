# daktela-paleo

`daktela-paleo` is a Python 3.12+ Textual application for building a keyboard-first terminal UI around Daktela Contact Center workflows. Contributor examples default to Python 3.14.

This site is the canonical home for project documentation. Use it both as the operator guide for the current TUI and as the structured contributor guide for local setup, quality commands, and future project documentation.

## Start Here

### Use the app

- [Quick Start](quick-start.md) walks through first launch, connecting a Daktela instance, and switching between saved instances.
- [Basic Navigation](basic-navigation.md) covers the two-pane main screen, focus movement, and the shared keyboard model.
- [Working With Tickets](working-with-tickets.md) explains how to open a ticket, edit fields, save changes, and add inline replies.

### Contribute to the project

- [Contributor Setup](getting-started.md) covers environment setup, install steps, local run commands, quality gates, and worktree helpers.
- [Interaction Model](interaction-model.md) explains the shared keyboard-first design rules that shape the UI.
- [Contributing](contributing.md) covers documentation workflow and where future project docs should live.

## What This Documentation Covers

- The current connection flow is based on saving and activating a Daktela instance with a base URL and user token.
- The operator guides document only workflows that are wired in the current app.
- Contributor guidance stays in the docs site so the root repository page can stay shorter and easier to scan.

## Project snapshot

- Runtime: Python `3.12+` with Python `3.14` as the default contributor setup
- Package manager and task runner: `uv`
- UI framework: `textual`
- Networking client: `httpx`
- Test stack: `pytest`, `pyright`, `ruff`, and `coverage`

## Documentation convention

Structured project documentation should live under `docs/` and be wired into `mkdocs.yml` so it stays discoverable from the generated site. The root `README.md` remains the first landing page on the repository front page, but this site is the canonical place for structured documentation.
