# Contributor Setup

## Requirements

- `uv`
- Python `3.12` or newer available through `uv`

## Local setup

Create the virtual environment:

```bash
uv venv --python 3.14 .venv
```

Python `3.14` remains the default contributor setup, but the project also supports Python `3.12` with the same workflow:

```bash
uv venv --python 3.12 .venv
```

Install the project and development dependencies:

```bash
uv sync --group dev
```

## Run the application

Start the Textual app locally:

```bash
uv run daktela-paleo
```

If a saved active Daktela instance exists, the app loads it on startup. Use `c` to open the instance manager and switch between saved Daktela instances.

For the operator workflow after the app starts, use [Quick Start](quick-start.md), [Basic Navigation](basic-navigation.md), and [Working With Tickets](working-with-tickets.md).

## Test and quality commands

Run the full test suite:

```bash
uv run pytest
```

`pytest` runs with 8 workers by default via `pytest-xdist`.

Run a single test file:

```bash
uv run pytest tests/test_app.py
```

Run the repository quality gates:

```bash
make ruff
make pyright
make coverage
```

The coverage target runs through the default 8-worker `pytest` setup and writes terminal, XML, and HTML coverage reports.

Run focused coverage for a single test file and a single covered source file:

```bash
make coverage tests/test_app.py src/daktela_paleo/app.py
```

Build and validate the distributable wheel locally:

```bash
make clean build check-wheel check-dist
```

The tag-push GitLab release path runs:

```bash
make clean update-version build check-wheel check-dist RELEASE_TAG="$CI_COMMIT_TAG"
make publish
```

`make update-version` derives the package version from `RELEASE_TAG` or `CI_COMMIT_TAG`, accepting `vX.Y.Z` and `X.Y.Z`, and rewrites `pyproject.toml` in the current workspace. Treat that as CI-oriented automation or run it from a disposable checkout.

For CI publishing to official PyPI, create a PyPI account with 2FA enabled, generate an upload token, and store it in GitLab as a protected masked `PYPI_TOKEN` variable. The release job exports `TWINE_USERNAME=__token__` and `TWINE_PASSWORD=$PYPI_TOKEN` before running `make publish`.

To trigger the GitLab release pipeline:

```bash
git tag v0.0.2
git push origin v0.0.2
```

Install the published release from PyPI with:

```bash
pipx install daktela-paleo
```

## Documentation commands

Serve the documentation locally with live reload:

```bash
make docs-serve
```

Build the documentation site locally with strict link and nav validation:

```bash
make docs-build
```

## Git worktrees

Create a bootstrapped feature worktree from the primary checkout root on `main`:

```bash
make worktree create <branch-name>
```

Remove a worktree from the primary checkout root:

```bash
make worktree delete <branch-name>
```

List all worktrees from any checkout in the repository:

```bash
make worktree list
```
