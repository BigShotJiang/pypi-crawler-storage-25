# Quick Start

This guide is for operators using the current terminal UI. It covers the first-run flow: start the app, connect a Daktela instance, and confirm that the app is ready to work.

## What you need

- a working project checkout with the app installed
- a Daktela base URL such as `https://example.daktela.com`
- a Daktela user token

The current app does not do an interactive username/password login. The connection flow is saving and activating a Daktela instance with a base URL and user token.

## Start the app

Run:

```bash
uv run daktela-paleo
```

If no active saved instance is available, the app starts disconnected. The bottom chrome shows:

```text
Instance: disconnected
```

## Connect a Daktela instance

1. Press `c` to open the saved-instance manager.
2. Press `a` to open the add-instance dialog.
3. Enter the Daktela URL.
4. Press `Tab` to move to the token field.
5. Paste the user token.
6. Press `Ctrl+S` to validate and save the instance.

The dialog is keyboard-first:

- `Tab` moves between fields and buttons.
- `Ctrl+S` submits the dialog.
- `Esc` cancels and returns to the instance manager.

## Validation and error states

The add-instance dialog validates local input first:

- blank URL shows `Daktela URL can't be blank.`
- blank token shows `User token can't be blank.`

After local validation passes, the app validates the credentials against Daktela:

- rejected token: `Daktela rejected the user token.`
- unreachable instance: `Couldn't connect to the Daktela instance.`
- other connector errors: `Couldn't validate the Daktela instance: ...`

When validation fails, the dialog reopens with your previous URL and token still filled in so you can correct them without retyping everything.

## What success looks like

When validation succeeds:

- the instance is saved
- the saved instance becomes active immediately
- the bottom chrome changes to `Instance: https://...`
- the app starts loading views and tickets for that instance

On later launches, the app reuses the active saved instance automatically.

## Switch between saved instances

Press `c` at any time to open the instance manager.

- `j` / `k` or the arrow keys move through saved instances
- `Enter` or `l` activates the highlighted instance
- `a` opens the add-instance dialog
- `Esc` or `q` closes the manager

After switching, the app reloads the main screen against the newly active instance and updates the instance context in the chrome.

## Next steps

- Continue with [Basic Navigation](basic-navigation.md) to learn the main-screen workflow.
- Continue with [Working With Tickets](working-with-tickets.md) to edit tickets and add replies.
