"""Shared splitter widget used across screens."""

from __future__ import annotations

from textual import events
from textual.message import Message
from textual.reactive import reactive
from textual.widgets import Static


class VerticalSplitter(Static):
    """Thin draggable separator between pane columns."""

    class Dragged(Message):
        """Posted while the splitter is being dragged."""

        def __init__(self, splitter: VerticalSplitter, screen_x: int) -> None:
            super().__init__()
            self.splitter = splitter
            self.screen_x = screen_x

        @property
        def control(self) -> VerticalSplitter:
            return self.splitter

    dragging = reactive(False)

    DEFAULT_CSS = """
    VerticalSplitter {
        width: 1;
        min-width: 1;
        height: 1fr;
        content-align: center middle;
        background: $panel;
        color: $text-muted;
    }

    VerticalSplitter.-dragging {
        background: $accent;
        color: $text;
    }
    """

    def __init__(self, id: str | None = None) -> None:
        super().__init__("│", id=id)

    def watch_dragging(self, dragging: bool) -> None:
        self.set_class(dragging, "-dragging")

    async def _on_mouse_down(self, event: events.MouseDown) -> None:
        self.capture_mouse()
        self.dragging = True
        self.post_message(self.Dragged(self, event.screen_x))
        event.stop()

    async def _on_mouse_move(self, event: events.MouseMove) -> None:
        if self.dragging:
            self.post_message(self.Dragged(self, event.screen_x))
        event.stop()

    async def _on_mouse_up(self, event: events.MouseUp) -> None:
        if self.dragging:
            self.release_mouse()
        event.stop()

    def _on_mouse_release(self, event: events.MouseRelease) -> None:
        self.dragging = False
        event.stop()

    async def _on_click(self, event: events.Click) -> None:
        event.stop()
