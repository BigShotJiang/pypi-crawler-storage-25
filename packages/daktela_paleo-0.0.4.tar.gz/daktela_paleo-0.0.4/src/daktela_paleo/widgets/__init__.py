"""Shared widgets for daktela-paleo."""

from daktela_paleo.widgets.chrome import AppChrome

__all__ = ["AppChrome"]
