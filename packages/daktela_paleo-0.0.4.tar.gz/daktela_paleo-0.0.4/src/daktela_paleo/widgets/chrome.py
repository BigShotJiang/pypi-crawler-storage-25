"""Shared bottom chrome for transient status and persistent instance context."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal
from textual.css.query import NoMatches
from textual.reactive import reactive
from textual.widget import Widget
from textual.widgets import Static


class AppChrome(Widget):
    """One-line app chrome with transient status and persistent instance context."""

    DEFAULT_CSS = """
    AppChrome {
        height: 1;
        min-height: 1;
        width: 1fr;
    }

    #app-chrome {
        height: 1;
        width: 1fr;
        background: $surface;
        color: $text-muted;
    }

    #status-bar {
        height: 1;
        width: 1fr;
        min-width: 0;
        padding: 0 1;
        background: $surface;
        color: $text-muted;
    }

    #instance-context {
        height: 1;
        width: auto;
        min-width: 0;
        padding: 0 1;
        background: $surface;
        color: $text-muted;
        text-align: right;
    }
    """

    status_text = reactive("", init=False)
    instance_text = reactive("", init=False)

    def __init__(
        self,
        status_text: str,
        instance_text: str,
        *,
        id: str | None = None,
    ) -> None:
        super().__init__(id=id)
        self.status_text = status_text
        self.instance_text = instance_text

    def compose(self) -> ComposeResult:
        with Horizontal(id="app-chrome"):
            yield Static(self.status_text, id="status-bar")
            yield Static(self.instance_text, id="instance-context")

    def set_status_text(self, status_text: str) -> None:
        """Refresh the transient status segment."""

        self.status_text = status_text

    def set_instance_text(self, instance_text: str) -> None:
        """Refresh the persistent instance context segment."""

        self.instance_text = instance_text

    def watch_status_text(self, status_text: str) -> None:
        if not self.is_mounted:
            return

        try:
            self.query_one("#status-bar", Static).update(status_text)
        except NoMatches:
            pass

    def watch_instance_text(self, instance_text: str) -> None:
        if not self.is_mounted:
            return

        try:
            self.query_one("#instance-context", Static).update(instance_text)
        except NoMatches:
            pass
