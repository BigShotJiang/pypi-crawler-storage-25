"""Main-screen widgets for rendering and selecting ticket views."""

from __future__ import annotations

from textual.binding import Binding
from textual.message import Message
from textual.widgets import ListItem, ListView, Static

from daktela_paleo.models import TicketView


class TicketViewListItem(ListItem):
    """List item that keeps the underlying ticket view attached."""

    def __init__(self, view: TicketView, label: str | None = None) -> None:
        self.view = view
        super().__init__(Static(label or view.title, classes="list-label"))


class TicketViewsList(ListView):
    """List view with vi-style navigation for ticket views."""

    class ViewActivated(Message):
        """Posted when a ticket view is selected."""

        def __init__(self, views_list: TicketViewsList, view: TicketView) -> None:
            super().__init__()
            self.views_list = views_list
            self.view = view

        @property
        def control(self) -> TicketViewsList:
            return self.views_list

    BINDINGS = [
        *ListView.BINDINGS,
        Binding("q", "quit_app", "Quit", show=False),
        Binding("j", "cursor_down", "Down", show=False),
        Binding("k", "cursor_up", "Up", show=False),
        Binding("l", "activate", "Open", show=False),
        Binding("right", "activate", "Open", show=False),
    ]

    def __init__(
        self,
        views: list[TicketView] | None = None,
        active_view: TicketView | None = None,
        id: str | None = None,
    ) -> None:
        self._views = list(views or [])
        self._active_view = active_view
        self._views_signature = self._view_signature(self._views)
        initial_index = self._initial_index(self._views, self._active_view)
        labels = self._view_labels(self._views)
        super().__init__(
            *(TicketViewListItem(view, label) for view, label in zip(self._views, labels, strict=False)),
            initial_index=initial_index,
            id=id,
        )

    def action_activate(self) -> None:
        """Select the currently highlighted item."""

        self.action_select_cursor()

    def action_quit_app(self) -> None:
        """Quit the application from the main views pane."""

        self.app.exit()

    def set_views(self, views: list[TicketView], active_view: TicketView | None) -> None:
        """Render the given views and sync the highlighted index."""

        self._views = list(views)
        self._active_view = active_view

        current_signature = self._view_signature(self._views)
        if current_signature != self._views_signature:
            self._views_signature = current_signature
            self.clear()
            labels = self._view_labels(self._views)
            self.extend(
                TicketViewListItem(view, label)
                for view, label in zip(self._views, labels, strict=False)
            )

        self._sync_index()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Translate the generic list event into a typed ticket-view event."""

        if event.list_view is not self:
            return

        if isinstance(event.item, TicketViewListItem):
            self.post_message(self.ViewActivated(self, event.item.view))

    def _sync_index(self) -> None:
        if not self._views:
            self.index = None
            return

        active_index = self._match_index(self._views, self._active_view)
        if active_index is not None:
            self.index = active_index
            return

        if self.index is None:
            self.index = 0
        else:
            self.index = min(self.index, len(self._views) - 1)

    @staticmethod
    def _view_signature(views: list[TicketView]) -> tuple[tuple[str, str, str, str, str], ...]:
        return tuple(
            (*view.selection_key(), view.title, view.parent_view or "", str(view.ticket_count))
            for view in views
        )

    @staticmethod
    def _match_index(values: list[TicketView], active_value: TicketView | None) -> int | None:
        if active_value is None:
            return None

        active_key = active_value.selection_key()
        for index, value in enumerate(values):
            if value.selection_key() == active_key:
                return index
        return None

    @classmethod
    def _view_labels(cls, views: list[TicketView]) -> list[str]:
        views_by_name = {view.name: view for view in views if view.name is not None}
        children_by_parent: dict[str, list[str]] = {}
        for view in views:
            if view.name is None or view.parent_view is None:
                continue

            if view.parent_view not in views_by_name:
                continue

            children_by_parent.setdefault(view.parent_view, []).append(view.name)

        return [
            cls._format_view_label(view, children_by_parent, views_by_name)
            for view in views
        ]

    @classmethod
    def _format_view_label(
        cls,
        view: TicketView,
        children_by_parent: dict[str, list[str]],
        views_by_name: dict[str, TicketView],
    ) -> str:
        display_title = cls._display_title(view)
        path = cls._hierarchy_path(view, views_by_name)
        if len(path) <= 1:
            return display_title

        prefix_parts: list[str] = []
        for ancestor_name, child_name in zip(path[:-2], path[1:-1], strict=False):
            if cls._is_last_child(ancestor_name, child_name, children_by_parent):
                prefix_parts.append("   ")
            else:
                prefix_parts.append("|  ")

        parent_name = path[-2]
        connector = "`- " if cls._is_last_child(parent_name, path[-1], children_by_parent) else "|- "
        return f"{''.join(prefix_parts)}{connector}{display_title}"

    @staticmethod
    def _display_title(view: TicketView) -> str:
        if view.ticket_count is None:
            return view.title

        return f"{view.title} ({view.ticket_count})"

    @staticmethod
    def _hierarchy_path(view: TicketView, views_by_name: dict[str, TicketView]) -> list[str]:
        if view.name is None:
            return []

        path = [view.name]
        seen = {view.name}
        current = view
        while current.parent_view is not None:
            parent_name = current.parent_view
            if parent_name in seen:
                return [view.name]

            parent = views_by_name.get(parent_name)
            if parent is None:
                return [view.name]

            path.append(parent_name)
            seen.add(parent_name)
            current = parent

        path.reverse()
        return path

    @staticmethod
    def _is_last_child(
        parent_name: str,
        child_name: str,
        children_by_parent: dict[str, list[str]],
    ) -> bool:
        siblings = children_by_parent.get(parent_name)
        return bool(siblings) and siblings[-1] == child_name

    @classmethod
    def _initial_index(cls, views: list[TicketView], active_view: TicketView | None) -> int | None:
        if not views:
            return None

        active_index = cls._match_index(views, active_view)
        if active_index is not None:
            return active_index

        return 0
