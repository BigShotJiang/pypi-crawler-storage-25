"""Keyboard-first modal flow for managing saved Daktela instances."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass

from textual import events
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.message import Message
from textual.screen import ModalScreen
from textual.widgets import Button, Input, ListItem, ListView, Static

from daktela_paleo.instances import DaktelaInstanceRecord


@dataclass(frozen=True)
class InstanceManagementResult:
    """Result returned from the saved-instance manager."""

    action: str
    instance_id: str | None = None


@dataclass(frozen=True)
class AddInstanceResult:
    """Result returned from the add-instance modal."""

    action: str
    base_url: str | None = None
    user_token: str | None = None


class InstanceListItem(ListItem):
    """List item that keeps the underlying saved instance attached."""

    def __init__(self, instance: DaktelaInstanceRecord, label: str) -> None:
        self.instance = instance
        super().__init__(Static(label, classes="list-label"))


class InstanceList(ListView):
    """List view with vi-style navigation for saved Daktela instances."""

    class InstanceActivated(Message):
        """Posted when a saved instance is selected."""

        def __init__(self, instance_list: InstanceList, instance_id: str) -> None:
            super().__init__()
            self.instance_list = instance_list
            self.instance_id = instance_id

        @property
        def control(self) -> InstanceList:
            return self.instance_list

    BINDINGS = [
        *ListView.BINDINGS,
        Binding("j", "cursor_down", "Down", show=False),
        Binding("k", "cursor_up", "Up", show=False),
        Binding("l,right", "activate", "Activate", show=False),
    ]

    def __init__(
        self,
        instances: list[DaktelaInstanceRecord],
        *,
        active_instance_id: str | None,
        id: str | None = None,
    ) -> None:
        self._instances = [instance.model_copy(deep=True) for instance in instances]
        labels = self._labels(self._instances, active_instance_id=active_instance_id)
        super().__init__(
            *(
                InstanceListItem(instance, label)
                for instance, label in zip(self._instances, labels, strict=False)
            ),
            initial_index=self._initial_index(self._instances, active_instance_id),
            id=id,
        )

    def action_activate(self) -> None:
        """Activate the currently highlighted instance."""

        self.action_select_cursor()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Translate the generic selection event into an instance activation event."""

        if event.list_view is not self:
            return

        if isinstance(event.item, InstanceListItem):
            self.post_message(self.InstanceActivated(self, event.item.instance.id))

    @staticmethod
    def _initial_index(
        instances: list[DaktelaInstanceRecord],
        active_instance_id: str | None,
    ) -> int | None:
        if not instances:
            return None

        if active_instance_id is not None:
            for index, instance in enumerate(instances):
                if instance.id == active_instance_id:
                    return index

        return 0

    @staticmethod
    def _labels(
        instances: list[DaktelaInstanceRecord],
        *,
        active_instance_id: str | None,
    ) -> list[str]:
        duplicates = Counter(instance.base_url for instance in instances)
        labels: list[str] = []
        for instance in instances:
            label = instance.base_url
            if duplicates[instance.base_url] > 1:
                label = f"{label} [..{instance.user_token[-4:]}]"
            if instance.id == active_instance_id:
                label = f"{label} (active)"
            labels.append(label)
        return labels


class InstanceManagementModal(ModalScreen[InstanceManagementResult | None]):
    """Show saved instances and allow keyboard-first activation or add."""

    BINDINGS = [
        Binding("a", "add", "Add Instance", show=False, priority=True),
        Binding("d", "toggle_demo_mode", "Toggle Demo Mode", show=False, priority=True),
        Binding("enter", "activate", "Activate", show=False, priority=True),
        Binding("escape,q", "cancel", "Close", show=False, priority=True),
    ]
    DEFAULT_CSS = """
    InstanceManagementModal {
        align: center middle;
        background: $background 60%;
    }

    #instance-management-dialog {
        width: 72;
        height: auto;
        max-height: 24;
        padding: 1;
        border: round $border;
        background: $surface;
    }

    #instance-management-title {
        height: auto;
        color: $text;
        text-style: bold;
    }

    #instance-management-subtitle {
        height: auto;
        margin-top: 1;
        color: $text-muted;
    }

    #instance-management-list {
        width: 1fr;
        height: auto;
        min-height: 8;
        max-height: 12;
        margin-top: 1;
        border: round $border-blurred;
    }

    #instance-management-empty {
        height: auto;
        min-height: 3;
        margin-top: 1;
        padding: 1 0;
        color: $text-muted;
    }

    #instance-management-hint {
        height: auto;
        margin-top: 1;
        color: $text-muted;
    }
    """

    def __init__(
        self,
        instances: list[DaktelaInstanceRecord],
        *,
        active_instance_id: str | None,
    ) -> None:
        super().__init__()
        self.instances = [instance.model_copy(deep=True) for instance in instances]
        self.active_instance_id = active_instance_id

    def compose(self) -> ComposeResult:
        with Vertical(id="instance-management-dialog"):
            yield Static("Manage Daktela Instances", id="instance-management-title")
            yield Static(
                "Pick a saved instance to activate or add a new one.",
                id="instance-management-subtitle",
            )
            if self.instances:
                yield InstanceList(
                    self.instances,
                    active_instance_id=self.active_instance_id,
                    id="instance-management-list",
                )
            else:
                yield Static(
                    "No Daktela instances are configured yet.\nPress [b]a[/b] to add one.",
                    id="instance-management-empty",
                )
            yield Static(
                "Use j/k or arrows to move, Enter/l to activate, a to add, Esc/q to close.",
                id="instance-management-hint",
            )

    def on_mount(self) -> None:
        try:
            self.query_one("#instance-management-list", InstanceList).focus()
        except Exception:
            pass

    def on_instance_list_instance_activated(
        self,
        message: InstanceList.InstanceActivated,
    ) -> None:
        """Activate the selected saved instance."""

        message.stop()
        self.dismiss(
            InstanceManagementResult(
                action="activate",
                instance_id=message.instance_id,
            )
        )

    def action_add(self) -> None:
        """Open the add-instance flow."""

        self.dismiss(InstanceManagementResult(action="add"))

    def action_toggle_demo_mode(self) -> None:
        """Toggle the hidden session-only demo runtime."""

        self.dismiss(InstanceManagementResult(action="toggle_demo_mode"))

    def action_activate(self) -> None:
        """Activate the highlighted instance when a list is available."""

        if not self.instances:
            return
        self.query_one("#instance-management-list", InstanceList).action_activate()

    def action_cancel(self) -> None:
        """Dismiss the manager without changes."""

        self.dismiss(None)


class AddInstanceModal(ModalScreen[AddInstanceResult | None]):
    """Collect a Daktela URL and user token without leaving the keyboard."""

    BINDINGS = [
        Binding("ctrl+s", "submit", "Save", show=False, priority=True),
        Binding("escape", "cancel", "Cancel", show=False, priority=True),
    ]
    DEFAULT_CSS = """
    AddInstanceModal {
        align: center middle;
        background: $background 60%;
    }

    #add-instance-dialog {
        width: 72;
        height: auto;
        padding: 1;
        border: round $border;
        background: $surface;
    }

    #add-instance-title {
        height: auto;
        color: $text;
        text-style: bold;
    }

    .add-instance-field-label {
        height: auto;
        margin-top: 1;
        color: $text-muted;
    }

    .add-instance-input {
        width: 1fr;
        border: round $border-blurred;
    }

    .add-instance-input:focus {
        border: round $accent;
    }

    #add-instance-validation {
        height: auto;
        min-height: 1;
        margin-top: 1;
        color: $error;
    }

    #add-instance-actions {
        width: 1fr;
        height: auto;
        margin-top: 1;
    }

    .add-instance-action {
        min-width: 18;
        margin-right: 1;
    }

    #add-instance-hint {
        height: auto;
        margin-top: 1;
        color: $text-muted;
    }
    """

    def __init__(
        self,
        *,
        base_url: str = "",
        user_token: str = "",
        error_message: str | None = None,
    ) -> None:
        super().__init__()
        self.base_url = base_url
        self.user_token = user_token
        self.error_message = error_message or ""

    def compose(self) -> ComposeResult:
        with Vertical(id="add-instance-dialog"):
            yield Static("Add Daktela Instance", id="add-instance-title")
            yield Static("Daktela URL", classes="add-instance-field-label")
            yield Input(
                value=self.base_url,
                placeholder="https://example.daktela.com",
                id="add-instance-base-url",
                classes="add-instance-input",
            )
            yield Static("User token", classes="add-instance-field-label")
            yield Input(
                value=self.user_token,
                placeholder="Paste the access token",
                password=True,
                id="add-instance-user-token",
                classes="add-instance-input",
            )
            yield Static(self.error_message, id="add-instance-validation")
            with Horizontal(id="add-instance-actions"):
                yield Button(
                    "Save (Ctrl+S)",
                    id="add-instance-submit",
                    classes="add-instance-action",
                )
                yield Button(
                    "Cancel (Esc)",
                    id="add-instance-cancel",
                    classes="add-instance-action",
                )
            yield Static(
                "Use Tab to move between fields and actions.",
                id="add-instance-hint",
            )

    def on_mount(self) -> None:
        self.query_one("#add-instance-base-url", Input).focus()

    def on_key(self, event: events.Key) -> None:
        """Prevent modal shortcuts from leaking into the underlying screen."""

        if event.key == "ctrl+s":
            event.stop()
            self.action_submit()
            return

        if event.key == "escape":
            event.stop()
            self.action_cancel()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Route visible actions to submit and cancel behavior."""

        if event.button.id == "add-instance-submit":
            event.stop()
            self.action_submit()
            return

        if event.button.id == "add-instance-cancel":
            event.stop()
            self.action_cancel()

    def action_submit(self) -> None:
        """Validate local fields before dismissing the modal."""

        base_url = self.query_one("#add-instance-base-url", Input).value.strip()
        user_token = self.query_one("#add-instance-user-token", Input).value.strip()
        validation = self.query_one("#add-instance-validation", Static)
        if not base_url:
            validation.update("Daktela URL can't be blank.")
            self.query_one("#add-instance-base-url", Input).focus()
            return

        if not user_token:
            validation.update("User token can't be blank.")
            self.query_one("#add-instance-user-token", Input).focus()
            return

        validation.update("")
        self.dismiss(
            AddInstanceResult(
                action="submit",
                base_url=base_url,
                user_token=user_token,
            )
        )

    def action_cancel(self) -> None:
        """Dismiss the modal without saving."""

        self.dismiss(AddInstanceResult(action="cancel"))
