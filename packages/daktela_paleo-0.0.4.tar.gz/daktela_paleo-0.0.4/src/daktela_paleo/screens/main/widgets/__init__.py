"""Widgets used only by the main screen."""
