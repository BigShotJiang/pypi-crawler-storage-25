"""Main-screen widgets for rendering and selecting tickets."""

from __future__ import annotations

import re
from collections.abc import Iterable
from typing import Any
from re import Pattern

from rich.text import Text
from textual import events
from textual.binding import Binding
from textual.coordinate import Coordinate
from textual.message import Message
from textual.widgets import DataTable
from textual.widgets._data_table import ColumnKey

from daktela_paleo.models import Ticket, TicketPagination, normalize_ticket_grid_column_keys
from daktela_paleo.themes import TOKYONIGHT_MOON


class TicketTable(DataTable):
    """Ticket table with LazyGit-style keyboard bindings."""

    LINE_NUMBER_COLUMN_KEY = "line-number"
    LINE_NUMBER_STYLE = TOKYONIGHT_MOON.variables["border"]
    CURRENT_LINE_NUMBER_STYLE = TOKYONIGHT_MOON.variables["text-muted"]
    TITLE_TRUNCATE_LIMIT = 75
    TITLE_TRUNCATION_SUFFIX = "..."
    SEARCH_HIGHLIGHT_STYLE = f"bold {TOKYONIGHT_MOON.background} on {TOKYONIGHT_MOON.accent}"

    class TicketActivated(Message):
        """Posted when a ticket row is selected."""

        def __init__(self, ticket_table: TicketTable, ticket: Ticket) -> None:
            super().__init__()
            self.ticket_table = ticket_table
            self.ticket = ticket

        @property
        def control(self) -> TicketTable:
            return self.ticket_table

    class FocusViewsRequested(Message):
        """Posted when navigation should move back to the views pane."""

        def __init__(self, ticket_table: TicketTable) -> None:
            super().__init__()
            self.ticket_table = ticket_table

        @property
        def control(self) -> TicketTable:
            return self.ticket_table

    class PendingCountChanged(Message):
        """Posted when the vi-style movement count changes."""

        def __init__(self, ticket_table: TicketTable, count: int | None) -> None:
            super().__init__()
            self.ticket_table = ticket_table
            self.count = count

        @property
        def control(self) -> TicketTable:
            return self.ticket_table

    class NextPageRequested(Message):
        """Posted when the next ticket page should be loaded."""

        def __init__(self, ticket_table: TicketTable) -> None:
            super().__init__()
            self.ticket_table = ticket_table

        @property
        def control(self) -> TicketTable:
            return self.ticket_table

    class PreviousPageRequested(Message):
        """Posted when the previous ticket page should be loaded."""

        def __init__(self, ticket_table: TicketTable) -> None:
            super().__init__()
            self.ticket_table = ticket_table

        @property
        def control(self) -> TicketTable:
            return self.ticket_table

    class SearchRequested(Message):
        """Posted when the table wants the search prompt opened."""

        def __init__(self, ticket_table: TicketTable) -> None:
            super().__init__()
            self.ticket_table = ticket_table

        @property
        def control(self) -> TicketTable:
            return self.ticket_table

    class SearchStatusChanged(Message):
        """Posted when the applied ticket-table search status changes."""

        def __init__(self, ticket_table: TicketTable, status: str | None) -> None:
            super().__init__()
            self.ticket_table = ticket_table
            self.status = status

        @property
        def control(self) -> TicketTable:
            return self.ticket_table

    BINDINGS = [
        *DataTable.BINDINGS,
        Binding("q", "quit_app", "Quit", show=False),
        Binding("l", "select_cursor", "Open", show=False),
        Binding("h", "focus_views", "Back", show=False),
        Binding("ctrl+b", "previous_ticket_page", "Previous Page"),
        Binding("ctrl+d", "next_ticket_page", "Next Page"),
        Binding("/", "request_search", "Search", show=False),
        Binding("n", "next_search_match", "Next Match", show=False),
        Binding("N", "previous_search_match", "Previous Match", show=False),
    ]
    COLUMN_LABELS_BY_KEY = {
        "name": "#",
        "title": "Title",
        "priority": "Priority",
        "sla_deadtime": "Deadline",
        "category.title": "Category",
        "contact.title": "Contact",
        "user.title": "User",
        "statuses": "Statuses",
        "stage": "Stage",
        "edited": "Edited",
        "edited_by": "Edited By",
    }

    def __init__(
        self,
        tickets: list[Ticket] | None = None,
        active_ticket: Ticket | None = None,
        column_keys: list[str] | None = None,
        pagination: TicketPagination | None = None,
        id: str | None = None,
    ) -> None:
        super().__init__(
            cursor_type="row",
            show_row_labels=False,
            zebra_stripes=True,
            id=id,
        )
        self._tickets = list(tickets or [])
        self._active_ticket = active_ticket
        self._column_keys = normalize_ticket_grid_column_keys(column_keys)
        self._pending_count: int | None = None
        self._tickets_signature = self._ticket_signature(self._tickets)
        self._pagination = pagination.model_copy(deep=True) if pagination is not None else TicketPagination()
        self._requested_cursor_row: int | None = None
        self._search_query: str | None = None
        self._search_regex: Pattern[str] | None = None
        self._search_match_rows: list[int] = []
        self._search_match_spans: dict[tuple[int, str], list[tuple[int, int]]] = {}
        self._search_active_match_index: int | None = None
        self._search_feedback_message: str | None = None
        self._render_rows()

    def on_mount(self) -> None:
        """Configure the table and keep relative ages fresh."""

        self.set_interval(60, self._render_rows)

    def on_blur(self) -> None:
        """Drop any stale count prefix when focus leaves the table."""

        self._clear_pending_count()

    def set_tickets(
        self,
        tickets: list[Ticket],
        active_ticket: Ticket | None,
        column_keys: list[str] | None = None,
        pagination: TicketPagination | None = None,
    ) -> None:
        """Render the given tickets and sync the active row."""

        self._clear_pending_count()
        self._tickets = list(tickets)
        self._active_ticket = active_ticket
        next_pagination = (
            pagination.model_copy(deep=True) if pagination is not None else TicketPagination()
        )
        previous_pagination = self._pagination
        next_column_keys = normalize_ticket_grid_column_keys(column_keys)
        columns_changed = next_column_keys != self._column_keys
        self._column_keys = next_column_keys

        current_signature = self._ticket_signature(self._tickets)
        page_changed = next_pagination != previous_pagination
        self._pagination = next_pagination
        if page_changed:
            self._requested_cursor_row = 0
        if page_changed or previous_pagination.has_multiple_pages != next_pagination.has_multiple_pages:
            self.refresh_bindings()
        search_scope_changed = (
            current_signature != self._tickets_signature or columns_changed or page_changed
        )
        if search_scope_changed:
            self._clear_search()

        if current_signature != self._tickets_signature or columns_changed:
            self._tickets_signature = current_signature
            self._render_rows()
        else:
            self._sync_cursor()

    def action_focus_views(self) -> None:
        """Request focus to move back to the views pane."""

        self.post_message(self.FocusViewsRequested(self))

    def action_quit_app(self) -> None:
        """Quit the application from the main ticket table."""

        self.app.exit()

    def action_request_search(self) -> None:
        """Open the ticket-table regex search prompt."""

        self.post_message(self.SearchRequested(self))

    def action_next_ticket_page(self) -> None:
        """Request the next ticket page."""

        if self._pagination.has_next_page:
            self.post_message(self.NextPageRequested(self))

    def action_previous_ticket_page(self) -> None:
        """Request the previous ticket page."""

        if self._pagination.has_previous_page:
            self.post_message(self.PreviousPageRequested(self))

    def action_next_search_match(self) -> None:
        """Move to the next matching row."""

        self._move_to_search_match(1)

    def action_previous_search_match(self) -> None:
        """Move to the previous matching row."""

        self._move_to_search_match(-1)

    def action_cursor_left(self) -> None:
        """Treat left arrow as pane navigation in row mode."""

        self.action_focus_views()

    def check_action(self, action: str, parameters: tuple[object, ...]) -> bool | None:
        """Dynamically expose pagination bindings only when page navigation exists."""

        if action == "next_ticket_page":
            if not self._pagination.has_multiple_pages:
                return False
            return True if self._pagination.has_next_page else None
        if action == "previous_ticket_page":
            if not self._pagination.has_multiple_pages:
                return False
            return True if self._pagination.has_previous_page else None
        return super().check_action(action, parameters)

    async def handle_key(self, event: events.Key) -> bool:
        """Support vim-style count prefixes for vertical movement."""

        if self._pending_count is not None and self._should_clear_pending_count(event):
            self._clear_pending_count()

        character = event.character
        if character is not None and character.isdigit():
            self._append_count_digit(character)
            event.stop()
            return True

        if event.key == "j":
            self._move_cursor_by_count(1)
            event.stop()
            return True

        if event.key == "k":
            self._move_cursor_by_count(-1)
            event.stop()
            return True

        if event.key == "/":
            self.action_request_search()
            event.stop()
            return True

        if event.character == "n":
            self.action_next_search_match()
            event.stop()
            return True

        if event.character == "N":
            self.action_previous_search_match()
            event.stop()
            return True

        return await super().handle_key(event)

    def apply_search(self, query: str) -> None:
        """Apply a regex search to the currently rendered ticket rows."""

        if query == "":
            self._clear_search()
            self._render_rows()
            return

        try:
            search_regex = re.compile(query)
        except re.error as error:
            self._search_query = None
            self._search_regex = None
            self._search_match_rows = []
            self._search_match_spans = {}
            self._search_active_match_index = None
            self._search_feedback_message = f"Invalid regex: {error}"
            self._render_rows()
            self._post_search_status()
            return

        match_rows, match_spans = self._search_matches(search_regex)
        self._search_query = query
        self._search_regex = search_regex
        self._search_match_rows = match_rows
        self._search_match_spans = match_spans
        self._search_feedback_message = None

        if not match_rows:
            self._search_active_match_index = None
            self._search_feedback_message = f"No matches: /{query}"
            self._render_rows()
            self._post_search_status()
            return

        self._search_active_match_index = self._initial_search_match_index(match_rows)
        self._render_rows()
        if self._search_active_match_index is not None:
            self.move_cursor(
                row=self._search_match_rows[self._search_active_match_index],
                column=0,
            )
        self._post_search_status()

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        """Translate the generic data table event into a typed ticket event."""

        if event.data_table is not self:
            return

        if event.cursor_row < 0 or event.cursor_row >= len(self._tickets):
            return

        self.post_message(self.TicketActivated(self, self._tickets[event.cursor_row]))

    def watch_cursor_coordinate(
        self,
        old_coordinate: Coordinate,
        new_coordinate: Coordinate,
    ) -> None:
        super().watch_cursor_coordinate(old_coordinate, new_coordinate)

        if old_coordinate.row != new_coordinate.row:
            self._refresh_line_number_gutter(new_coordinate.row)
            self._sync_search_match_from_cursor(new_coordinate.row)

    def _configure_columns(self) -> None:
        if self.columns:
            return

        line_number_width = self._line_number_width()
        self.add_column("", key=self.LINE_NUMBER_COLUMN_KEY, width=line_number_width)
        for column_key in self._column_keys:
            self.add_column(
                self.COLUMN_LABELS_BY_KEY[column_key],
                key=column_key,
            )

    def _render_rows(self) -> None:
        self.clear(columns=True)
        self._configure_columns()
        cursor_row = self._resolved_cursor_row()

        for index, ticket in enumerate(self._tickets):
            self.add_row(
                self._line_number_cell(index, cursor_row),
                *self._ticket_cells(ticket, index),
                key=f"ticket-{index}",
            )

        self._sync_cursor()

    def _sync_cursor(self) -> None:
        if not self._tickets:
            self._requested_cursor_row = None
            return

        self.move_cursor(row=self._resolved_cursor_row(), column=0, scroll=False)
        self._requested_cursor_row = None

    @staticmethod
    def _ticket_signature(tickets: list[Ticket]) -> tuple[str, ...]:
        return tuple(ticket.model_dump_json() for ticket in tickets)

    def _ticket_cells(self, ticket: Ticket, row_index: int) -> list[Any]:
        return [
            self._ticket_cell_renderable(ticket, column_key, row_index)
            for column_key in self._column_keys
        ]

    @classmethod
    def _ticket_cell(cls, ticket: Ticket, column_key: str) -> str:
        if column_key == "name":
            return cls._ticket_number(ticket)
        if column_key == "title":
            return cls._ticket_title(ticket)
        if column_key == "priority":
            return str(ticket.priority.table_value)
        if column_key == "sla_deadtime":
            return ticket.sla_deadtime_age()
        if column_key == "category.title":
            return ticket.category
        if column_key == "contact.title":
            return ticket.contact or "-"
        if column_key == "user.title":
            return ticket.user or "-"
        if column_key == "statuses":
            return ticket.statuses_display_label
        if column_key == "stage":
            return ticket.stage.display_label
        if column_key == "edited":
            return ticket.edited_age()
        if column_key == "edited_by":
            return ticket.edited_by or "-"
        raise KeyError(f"Unsupported ticket table column key: {column_key}")

    def _ticket_cell_renderable(
        self,
        ticket: Ticket,
        column_key: str,
        row_index: int,
    ) -> str | Text:
        cell_value = self._ticket_cell(ticket, column_key)
        spans = self._search_match_spans.get((row_index, column_key))
        if not spans:
            return cell_value

        highlighted = Text(cell_value)
        for start, end in spans:
            if start == end:
                continue
            highlighted.stylize(self.SEARCH_HIGHLIGHT_STYLE, start, end)
        return highlighted

    @staticmethod
    def _ticket_number(ticket: Ticket) -> str:
        return str(ticket.name) if ticket.name is not None else "-"

    @classmethod
    def _ticket_title(cls, ticket: Ticket) -> str:
        return cls._display_title(ticket.title)

    @classmethod
    def _display_title(cls, title: str) -> str:
        if len(title) <= cls.TITLE_TRUNCATE_LIMIT:
            return title

        return f"{title[:cls.TITLE_TRUNCATE_LIMIT]}{cls.TITLE_TRUNCATION_SUFFIX}"

    @staticmethod
    def _match_index(values: list[Ticket], active_value: Ticket | None) -> int | None:
        if active_value is None:
            return None

        for index, value in enumerate(values):
            if value == active_value:
                return index
        return None

    def _append_count_digit(self, digit: str) -> None:
        if digit == "0" and self._pending_count is None:
            return

        count = int(digit) if self._pending_count is None else int(f"{self._pending_count}{digit}")
        self._set_pending_count(count)

    def _move_cursor_by_count(self, direction: int) -> None:
        count = self._pending_count or 1
        self._clear_pending_count()

        if not self._tickets:
            return

        max_index = len(self._tickets) - 1
        target_row = min(max(self.cursor_row + (direction * count), 0), max_index)
        self.move_cursor(row=target_row, column=0)

    def _move_to_search_match(self, direction: int) -> None:
        if not self._search_match_rows:
            return

        if self._search_active_match_index is None:
            self._search_active_match_index = self._initial_search_match_index(
                self._search_match_rows
            )
        else:
            self._search_active_match_index = (
                self._search_active_match_index + direction
            ) % len(self._search_match_rows)

        assert self._search_active_match_index is not None

        self.move_cursor(
            row=self._search_match_rows[self._search_active_match_index],
            column=0,
        )
        self._post_search_status()

    def _clear_pending_count(self) -> None:
        self._set_pending_count(None)

    def _set_pending_count(self, count: int | None) -> None:
        if self._pending_count == count:
            return

        self._pending_count = count
        self.post_message(self.PendingCountChanged(self, count))

    @staticmethod
    def _should_clear_pending_count(event: events.Key) -> bool:
        return not (
            event.key in {"j", "k"}
            or (event.character is not None and event.character.isdigit())
        )

    def _resolved_cursor_row(self) -> int:
        if not self._tickets:
            return 0

        if self._requested_cursor_row is not None:
            return min(max(self._requested_cursor_row, 0), len(self._tickets) - 1)

        active_index = self._match_index(self._tickets, self._active_ticket)
        if active_index is not None:
            return active_index

        return min(max(self.cursor_row, 0), len(self._tickets) - 1)

    def _clear_search(self) -> None:
        self._search_query = None
        self._search_regex = None
        self._search_match_rows = []
        self._search_match_spans = {}
        self._search_active_match_index = None
        self._search_feedback_message = None
        self._post_search_status()

    def _search_matches(
        self,
        search_regex: Pattern[str],
    ) -> tuple[list[int], dict[tuple[int, str], list[tuple[int, int]]]]:
        match_rows: list[int] = []
        match_spans: dict[tuple[int, str], list[tuple[int, int]]] = {}

        for row_index, ticket in enumerate(self._tickets):
            row_matches = False
            for column_key in self._column_keys:
                column_text = self._ticket_cell(ticket, column_key)
                spans = self._match_spans(search_regex, column_text)
                if not spans:
                    continue

                row_matches = True
                match_spans[(row_index, column_key)] = spans

            if row_matches:
                match_rows.append(row_index)

        return match_rows, match_spans

    @staticmethod
    def _match_spans(
        search_regex: Pattern[str],
        value: str,
    ) -> list[tuple[int, int]]:
        return [
            (match.start(), match.end())
            for match in search_regex.finditer(value)
        ]

    def _initial_search_match_index(self, match_rows: Iterable[int]) -> int | None:
        rows = list(match_rows)
        if not rows:
            return None

        if self.cursor_row in rows:
            return rows.index(self.cursor_row)

        for index, row in enumerate(rows):
            if row > self.cursor_row:
                return index

        return 0

    def _sync_search_match_from_cursor(self, cursor_row: int) -> None:
        if cursor_row not in self._search_match_rows:
            return

        next_index = self._search_match_rows.index(cursor_row)
        if self._search_active_match_index == next_index:
            return

        self._search_active_match_index = next_index
        self._post_search_status()

    def _search_status_message(self) -> str | None:
        if self._search_feedback_message is not None:
            return self._search_feedback_message

        if (
            self._search_query is None
            or self._search_active_match_index is None
            or not self._search_match_rows
        ):
            return None

        return (
            f"/{self._search_query} "
            f"{self._search_active_match_index + 1}/{len(self._search_match_rows)}"
        )

    def _post_search_status(self) -> None:
        self.post_message(self.SearchStatusChanged(self, self._search_status_message()))

    def _refresh_line_number_gutter(self, cursor_row: int) -> None:
        if not self._tickets or self.LINE_NUMBER_COLUMN_KEY not in self.columns:
            return

        line_number_width = self._line_number_width()
        column = self.columns[ColumnKey(self.LINE_NUMBER_COLUMN_KEY)]
        if column.width != line_number_width:
            column.width = line_number_width
            self._require_update_dimensions = True
            self.check_idle()

        for index in range(len(self._tickets)):
            self.update_cell(
                f"ticket-{index}",
                self.LINE_NUMBER_COLUMN_KEY,
                self._line_number_cell(index, cursor_row),
            )

    def _line_number_cell(self, index: int, cursor_row: int) -> Text:
        number = self._line_number_text(index, cursor_row).rjust(self._line_number_width())
        style = (
            self.CURRENT_LINE_NUMBER_STYLE
            if index == cursor_row
            else self.LINE_NUMBER_STYLE
        )
        return Text(number, style=style)

    def _line_number_text(self, index: int, cursor_row: int) -> str:
        if index == cursor_row:
            return str(index + 1)

        return str(abs(index - cursor_row))

    def _line_number_width(self) -> int:
        return max(1, len(str(len(self._tickets))))
