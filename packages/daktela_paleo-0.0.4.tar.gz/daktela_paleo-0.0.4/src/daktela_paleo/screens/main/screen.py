"""Main screen widget for browsing ticket views and tickets."""

from __future__ import annotations

from textual import on
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.css.query import NoMatches
from textual.message import Message
from textual.reactive import reactive
from textual.widget import Widget
from textual.widgets import Input, Static

from daktela_paleo.models import AppState, TicketView
from daktela_paleo.screens.main.widgets.tickets import TicketTable
from daktela_paleo.screens.main.widgets.views import TicketViewsList
from daktela_paleo.widgets.vertical_splitter import VerticalSplitter


class TicketSearchInput(Input):
    """Compact regex prompt for the main ticket table."""

    class SearchCancelled(Message):
        """Posted when the search prompt should close without applying."""

        def __init__(self, search_input: TicketSearchInput) -> None:
            super().__init__()
            self.search_input = search_input

        @property
        def control(self) -> TicketSearchInput:
            return self.search_input

    BINDINGS = [
        *Input.BINDINGS,
        Binding("escape", "cancel_search", "Cancel Search", show=False),
    ]

    def action_cancel_search(self) -> None:
        """Close the prompt and return focus to the ticket table."""

        self.post_message(self.SearchCancelled(self))


class TicketList(Widget):
    """Two-pane browser for views and tickets."""

    class RefreshRequested(Message):
        """Posted when the current ticket view should be refreshed."""

        def __init__(self, ticket_list: TicketList) -> None:
            super().__init__()
            self.ticket_list = ticket_list

        @property
        def control(self) -> TicketList:
            return self.ticket_list

    class OpenInBrowserRequested(Message):
        """Posted when the selected ticket view should open in a browser."""

        def __init__(self, ticket_list: TicketList, view: TicketView | None) -> None:
            super().__init__()
            self.ticket_list = ticket_list
            self.view = view

        @property
        def control(self) -> TicketList:
            return self.ticket_list

    BINDINGS = [
        Binding("r", "refresh", "Refresh"),
        Binding("b", "open_in_browser", "Open Browser", priority=True),
    ]

    DEFAULT_CSS = """
    TicketList {
        height: 1fr;
        background: $background;
        color: $text;
    }

    #panes {
        height: 1fr;
        width: 1fr;
    }

    .pane {
        height: 1fr;
        border: round $border-blurred;
        background: $background;
    }

    .pane-title {
        height: 1;
        padding: 0 1;
        background: $panel;
        color: $text-muted;
        text-style: bold;
    }

    .pane-title.-focused {
        color: $accent;
    }

    #ticket-search-bar {
        display: none;
        height: 1;
        padding: 0 1;
        background: $surface-active;
        color: $text;
    }

    #ticket-search-bar.-active {
        display: block;
    }

    #ticket-search-prefix {
        width: auto;
        min-width: 1;
        color: $accent;
        padding-right: 1;
    }

    #ticket-search-input {
        width: 1fr;
        min-width: 0;
        background: transparent;
        color: $text;
    }

    #views-list,
    #tickets-table {
        height: 1fr;
        background: $background;
        color: $text;
    }

    .list-label {
        padding: 0 1;
        color: $text;
    }
    """

    split_percent = reactive(20.0)

    def __init__(
        self,
        initial_state: AppState,
        *,
        ticket_loading: bool = False,
        id: str | None = None,
    ) -> None:
        super().__init__(id=id)
        self._app_state = initial_state
        self._ticket_loading = ticket_loading

    def compose(self):
        with Horizontal(id="panes"):
            with Vertical(id="views-pane", classes="pane"):
                yield Static("Views", id="views-title", classes="pane-title")
                yield TicketViewsList(
                    self._app_state.views,
                    self._app_state.active_view,
                    id="views-list",
                )
            yield VerticalSplitter(id="splitter")
            with Vertical(id="tickets-pane", classes="pane"):
                yield Static(
                    self._tickets_title_text(self._app_state),
                    id="tickets-title",
                    classes="pane-title",
                )
                with Horizontal(id="ticket-search-bar"):
                    yield Static("/", id="ticket-search-prefix")
                    yield TicketSearchInput(
                        placeholder="regex",
                        id="ticket-search-input",
                        compact=True,
                    )
                yield TicketTable(
                    self._app_state.tickets,
                    self._app_state.active_ticket,
                    self._app_state.ticket_grid_column_keys,
                    self._app_state.ticket_pagination,
                    id="tickets-table",
                )

    def on_mount(self) -> None:
        """Sync the initial state and set the default focus."""

        self.call_after_refresh(self._sync_initial_state)
        self.call_after_refresh(self._apply_split_layout)
        self.call_after_refresh(self._refresh_focus_styles)
        self.call_after_refresh(self.focus_views)

    def on_resize(self) -> None:
        self._apply_split_layout()

    def on_focus(self) -> None:
        self.call_after_refresh(self._refresh_focus_styles)

    def on_blur(self) -> None:
        self.call_after_refresh(self._refresh_focus_styles)

    def on_descendant_focus(self) -> None:
        self.call_after_refresh(self._refresh_focus_styles)

    def on_descendant_blur(self) -> None:
        self.call_after_refresh(self._refresh_focus_styles)

    def watch_split_percent(self, _: float) -> None:
        if self.is_mounted:
            self.call_after_refresh(self._apply_split_layout)

    def sync_from_state(self, app_state: AppState) -> None:
        """Apply application state to the child widgets."""

        self._app_state = app_state
        if not self.is_mounted:
            return

        self.query_one(TicketViewsList).set_views(app_state.views, app_state.active_view)
        self.query_one("#tickets-title", Static).update(self._tickets_title_text(app_state))
        self.query_one(TicketTable).set_tickets(
            app_state.tickets,
            app_state.active_ticket,
            app_state.ticket_grid_column_keys,
            app_state.ticket_pagination,
        )

    def set_ticket_loading(self, ticket_loading: bool) -> None:
        """Toggle the ticket pane loading overlay."""

        self._ticket_loading = ticket_loading
        if not self.is_mounted:
            return

        self.query_one(TicketTable).loading = ticket_loading

    def focus_views(self) -> None:
        """Focus the ticket views pane."""

        self.app.set_focus(self.query_one(TicketViewsList))
        self.call_after_refresh(self._refresh_focus_styles)

    def focus_tickets(self) -> None:
        """Focus the ticket table pane."""

        self.app.set_focus(self.query_one(TicketTable))
        self.call_after_refresh(self._refresh_focus_styles)

    def open_ticket_search(self) -> None:
        """Show the ticket search prompt and focus its input."""

        search_bar = self.query_one("#ticket-search-bar", Horizontal)
        search_input = self.query_one("#ticket-search-input", TicketSearchInput)
        search_bar.add_class("-active")
        search_input.value = ""
        search_input.focus()
        self.call_after_refresh(self._refresh_focus_styles)

    def close_ticket_search(self) -> None:
        """Hide the ticket search prompt without changing the applied search."""

        search_bar = self.query_one("#ticket-search-bar", Horizontal)
        search_input = self.query_one("#ticket-search-input", TicketSearchInput)
        search_bar.remove_class("-active")
        search_input.value = ""
        self.call_after_refresh(self._refresh_focus_styles)

    def action_refresh(self) -> None:
        """Request a reload of the current ticket view."""

        self.post_message(self.RefreshRequested(self))

    def action_open_in_browser(self) -> None:
        """Request opening the selected ticket view in the system browser."""

        self.post_message(self.OpenInBrowserRequested(self, self._app_state.active_view))

    def on_vertical_splitter_dragged(self, message: VerticalSplitter.Dragged) -> None:
        panes = self.query_one("#panes", Horizontal)
        available_width = max(1, panes.size.width - 1)
        origin_x = panes.region.x
        relative_x = max(0, min(available_width, message.screen_x - origin_x))
        self.split_percent = (relative_x / available_width) * 100

    @on(TicketTable.FocusViewsRequested)
    def handle_focus_views_requested(self, _: TicketTable.FocusViewsRequested) -> None:
        """Move focus back to the views list when the table requests it."""

        self.focus_views()

    @on(TicketTable.SearchRequested)
    def handle_ticket_search_requested(self, _: TicketTable.SearchRequested) -> None:
        """Open the regex search prompt for the ticket table."""

        self.open_ticket_search()

    @on(TicketSearchInput.SearchCancelled)
    def handle_ticket_search_cancelled(
        self,
        _: TicketSearchInput.SearchCancelled,
    ) -> None:
        """Close the search prompt and return to the ticket table."""

        self.close_ticket_search()
        self.focus_tickets()

    def on_input_submitted(self, message: Input.Submitted) -> None:
        """Apply ticket-table search queries from the inline prompt."""

        search_input = self.query_one("#ticket-search-input", TicketSearchInput)
        if message.input is not search_input:
            return

        self.query_one(TicketTable).apply_search(message.value)
        self.close_ticket_search()
        self.focus_tickets()

    def _apply_split_layout(self) -> None:
        panes = self.query_one("#panes", Horizontal)
        available_width = max(1, panes.size.width - 1)
        if available_width <= 1:
            return

        if available_width >= 50:
            min_left = 20
            min_right = 30
        else:
            min_left = 1
            min_right = 1

        left_width = round((self.split_percent / 100) * available_width)
        left_width = max(min_left, min(left_width, available_width - min_right))
        right_width = max(min_right, available_width - left_width)

        self.query_one("#views-pane", Vertical).styles.width = left_width
        self.query_one("#tickets-pane", Vertical).styles.width = right_width

    def _refresh_focus_styles(self) -> None:
        try:
            views_title = self.query_one("#views-title", Static)
            tickets_title = self.query_one("#tickets-title", Static)
            views_pane = self.query_one("#views-pane", Vertical)
            tickets_pane = self.query_one("#tickets-pane", Vertical)
        except NoMatches:
            return

        views_title.set_class(views_pane.has_focus_within, "-focused")
        tickets_title.set_class(tickets_pane.has_focus_within, "-focused")

    def _sync_initial_state(self) -> None:
        self.sync_from_state(self._app_state)
        self.set_ticket_loading(self._ticket_loading)

    @staticmethod
    def _tickets_title_text(app_state: AppState) -> str:
        pagination = app_state.ticket_pagination
        if pagination.has_multiple_pages:
            return f"Tickets {pagination.current_page}/{pagination.total_pages}"
        return "Tickets"
