"""Main screen widgets."""
