"""Ticket detail screen."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Literal

from textual import on
from textual.app import ComposeResult
from textual.binding import Binding, BindingsMap
from textual.containers import Horizontal, Vertical
from textual.css.query import NoMatches
from textual.dom import DOMNode
from textual.message import Message
from textual.reactive import reactive
from textual.screen import Screen
from textual.widget import Widget
from textual.widgets import Footer, Header, Input, Static

from daktela_paleo.models import (
    Ticket,
    TicketActivity,
    TicketCategoryOption,
    TicketEmailAction,
    TicketEmailDraft,
    TicketEmailSendRequest,
    TicketEditPatch,
    TicketStage,
    TicketStatusOption,
    TicketUserOption,
)
from daktela_paleo.screens.ticket_detail.widgets.comment_reply import CommentReplyComposer
from daktela_paleo.screens.ticket_detail.widgets.detail_pane import (
    ActivityLink,
    DetailPaneBody,
    QuickActionSpec,
)
from daktela_paleo.screens.ticket_detail.widgets.email_compose import TicketEmailComposer
from daktela_paleo.screens.ticket_detail.widgets.form import TicketDetailForm
from daktela_paleo.screens.ticket_detail.widgets.modals import (
    ActivityLinkPickerModal,
    AttachmentDestinationPickerModal,
    CommentAttachmentPathPickerModal,
    CommentAttachmentRemovalModal,
    UnsavedChangesModal,
)
from daktela_paleo.widgets import AppChrome
from daktela_paleo.widgets.vertical_splitter import VerticalSplitter


EMAIL_QUICK_ACTIONS = (
    QuickActionSpec(action="reply", label="Reply to all", key="r"),
    QuickActionSpec(action="forward", label="Forward", key="f"),
)
COMMENT_QUICK_ACTIONS = (
    QuickActionSpec(action="reply", label="Reply", key="r"),
)
COPY_QUICK_ACTION = QuickActionSpec(action="copy", label="Copy", key="y")
DOWNLOAD_QUICK_ACTION = QuickActionSpec(action="download", label="Download", key="d")
ACTIVITY_COPY_SUCCESS_STATUS = "Copied activity text to clipboard."
ACTIVITY_COPY_EMPTY_STATUS = "Selected activity has no copyable text."
ACTIVITY_DOWNLOAD_EMPTY_STATUS = "Selected activity has no downloadable attachments."
REPLY_USER_UNMATCHED_STATUS = "Reply user not assigned: no matching ticket assignee for this activity."


class ActivitySearchInput(Input):
    """Compact regex prompt for the ticket detail activities pane."""

    class SearchCancelled(Message):
        """Posted when the search prompt should close without applying."""

        def __init__(self, search_input: ActivitySearchInput) -> None:
            super().__init__()
            self.search_input = search_input

        @property
        def control(self) -> ActivitySearchInput:
            return self.search_input

    BINDINGS = [
        *Input.BINDINGS,
        Binding("escape", "cancel_search", "Cancel Search", show=False),
    ]

    def action_cancel_search(self) -> None:
        """Close the prompt and return focus to the activities pane."""

        self.post_message(self.SearchCancelled(self))


class TicketDetail(Screen[None]):
    """Secondary screen showing the selected ticket."""

    split_percent = reactive(30.0)

    class SaveRequested(Message):
        """Posted when the detail screen requests a ticket save."""

        def __init__(
            self,
            detail_screen: TicketDetail,
            ticket: Ticket,
            patch: TicketEditPatch,
        ) -> None:
            super().__init__()
            self.detail_screen = detail_screen
            self.ticket = ticket
            self.patch = patch

        @property
        def control(self) -> TicketDetail:
            return self.detail_screen

    class StatusRequested(Message):
        """Posted when the screen wants a status-bar update."""

        def __init__(
            self,
            detail_screen: TicketDetail,
            text: str,
            *,
            error: bool = False,
        ) -> None:
            super().__init__()
            self.detail_screen = detail_screen
            self.text = text
            self.error = error

        @property
        def control(self) -> TicketDetail:
            return self.detail_screen

    class OpenInBrowserRequested(Message):
        """Posted when the screen wants to open the ticket in a browser."""

        def __init__(
            self,
            detail_screen: TicketDetail,
            ticket: Ticket,
        ) -> None:
            super().__init__()
            self.detail_screen = detail_screen
            self.ticket = ticket

        @property
        def control(self) -> TicketDetail:
            return self.detail_screen

    class OpenActivityLinkRequested(Message):
        """Posted when the screen wants to open a discovered activity URL."""

        def __init__(
            self,
            detail_screen: TicketDetail,
            url: str,
        ) -> None:
            super().__init__()
            self.detail_screen = detail_screen
            self.url = url

        @property
        def control(self) -> TicketDetail:
            return self.detail_screen

    class CommentRequested(Message):
        """Posted when the screen wants to create a ticket comment."""

        def __init__(
            self,
            detail_screen: TicketDetail,
            ticket: Ticket,
            content: str,
            attachment_paths: tuple[Path, ...],
        ) -> None:
            super().__init__()
            self.detail_screen = detail_screen
            self.ticket = ticket
            self.content = content
            self.attachment_paths = attachment_paths

        @property
        def control(self) -> TicketDetail:
            return self.detail_screen

    class EmailDraftRequested(Message):
        """Posted when the screen wants to load an email draft."""

        def __init__(
            self,
            detail_screen: TicketDetail,
            ticket: Ticket,
            activity: TicketActivity,
            action: TicketEmailAction,
        ) -> None:
            super().__init__()
            self.detail_screen = detail_screen
            self.ticket = ticket
            self.activity = activity
            self.action = action

        @property
        def control(self) -> TicketDetail:
            return self.detail_screen

    class EmailSendRequested(Message):
        """Posted when the screen wants to send an email draft."""

        def __init__(
            self,
            detail_screen: TicketDetail,
            ticket: Ticket,
            request: TicketEmailSendRequest,
        ) -> None:
            super().__init__()
            self.detail_screen = detail_screen
            self.ticket = ticket
            self.request = request

        @property
        def control(self) -> TicketDetail:
            return self.detail_screen

    class ActivityAttachmentDownloadRequested(Message):
        """Posted when the screen wants to download activity attachments."""

        def __init__(
            self,
            detail_screen: TicketDetail,
            ticket: Ticket,
            activity: TicketActivity,
            destination_dir: Path,
        ) -> None:
            super().__init__()
            self.detail_screen = detail_screen
            self.ticket = ticket
            self.activity = activity
            self.destination_dir = destination_dir

        @property
        def control(self) -> TicketDetail:
            return self.detail_screen

    BINDINGS = [
        Binding("ctrl+s", "save_or_submit_comment_reply", "Save", priority=True),
        Binding("c", "set_stage_close", "Close", priority=True),
        Binding("m", "assign_to_me", "Assign Me", priority=True),
        Binding("n", "add_comment", "Comment", priority=True),
        Binding("o", "set_stage_open", "Open", priority=True),
        Binding("u", "open_link_picker", "Links", priority=True),
        Binding("w", "set_stage_waiting", "Waiting", priority=True),
        Binding("b", "open_in_browser", "Open Browser", priority=True),
        Binding("q", "close", "Back", show=False),
        Binding("escape", "cancel_comment_reply_or_close", "Back", show=False),
        Binding("tab", "focus_next_pane", "Next Pane", priority=True),
        Binding("shift+tab", "focus_previous_pane", "Previous Pane", show=False, priority=True),
    ]
    DEFAULT_CSS = """
    TicketDetail {
        layout: vertical;
        background: $background;
        color: $text;
    }

    #ticket-detail-panes {
        height: 1fr;
        width: 1fr;
    }

    .detail-pane {
        height: 1fr;
        border: round $border-blurred;
        background: transparent;
    }

    #ticket-detail-left-pane {
        min-width: 24;
    }

    #ticket-detail-right-pane {
        min-width: 40;
    }

    .detail-pane-title {
        height: 1;
        padding: 0 1;
        background: $panel;
        color: $text-muted;
        text-style: bold;
    }

    .detail-pane-header {
        width: 1fr;
    }

    .detail-pane-title-label {
        width: 1fr;
    }

    .detail-pane-quick-actions {
        width: auto;
        height: 1;
        background: transparent;
    }

    .detail-pane-quick-action {
        width: auto;
        min-width: 0;
        height: 1;
        margin-left: 1;
        padding: 0 1;
        background: $background 30%;
        color: $accent;
        text-style: bold;
    }

    .detail-pane-title.-focused {
        color: $accent;
    }

    #ticket-detail-activity-search-bar {
        display: none;
        height: 1;
        padding: 0 1;
        background: $surface-active;
        color: $text;
    }

    #ticket-detail-activity-search-bar.-active {
        display: block;
    }

    #ticket-detail-activity-search-prefix {
        width: auto;
        min-width: 1;
        color: $accent;
        padding-right: 1;
    }

    #ticket-detail-activity-search-input {
        width: 1fr;
        min-width: 0;
        background: transparent;
        color: $text;
    }
    """

    def __init__(
        self,
        ticket: Ticket,
        status_message: str,
        *,
        instance_context: str = "Instance: disconnected",
        activities_message: str = "no activities yet",
        category_options: list[TicketCategoryOption] | None = None,
        status_options: list[TicketStatusOption] | None = None,
        user_options: list[TicketUserOption] | None = None,
        current_user: TicketUserOption | None = None,
        status_options_category_name: str | None = None,
        resolve_activity_asset_url: Callable[[str], str | None] | None = None,
        load_activity_asset: Callable[[str], Awaitable[bytes]] | None = None,
    ) -> None:
        super().__init__()
        self._ticket = ticket
        self._status_message = status_message
        self._instance_context = instance_context
        self._activities_message = activities_message
        self._category_options = list(category_options or [])
        self._status_options = list(status_options or [])
        self._user_options = list(user_options or [])
        self._current_user = current_user
        self._status_options_category_name = status_options_category_name
        self._close_after_save = False
        self._resolve_activity_asset_url = resolve_activity_asset_url
        self._load_activity_asset = load_activity_asset
        self._pending_attachment_download_activity: TicketActivity | None = None

    @property
    def _binding_chain(self) -> list[tuple[DOMNode, BindingsMap]]:
        """Filter out app-level bindings that should not leak into ticket detail."""

        namespace_bindings = super()._binding_chain
        filtered_bindings: list[tuple[DOMNode, BindingsMap]] = []
        for namespace, bindings in namespace_bindings:
            if namespace is not self.app or "v" not in bindings.key_to_bindings:
                filtered_bindings.append((namespace, bindings))
                continue

            app_bindings = bindings.copy()
            app_bindings.key_to_bindings = app_bindings.key_to_bindings.copy()
            del app_bindings.key_to_bindings["v"]
            filtered_bindings.append((namespace, app_bindings))
        return filtered_bindings

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal(id="ticket-detail-panes"):
            with Vertical(id="ticket-detail-left-pane", classes="detail-pane"):
                yield Static("Ticket Detail", id="ticket-detail-left-title", classes="detail-pane-title")
                yield TicketDetailForm(
                    self._ticket,
                    self._category_options,
                    self._status_options,
                    self._user_options,
                    status_options_category_name=self._status_options_category_name,
                    id="ticket-detail-left-body",
                )
            yield VerticalSplitter(id="ticket-detail-splitter")
            with Vertical(id="ticket-detail-right-pane", classes="detail-pane"):
                with Horizontal(
                    id="ticket-detail-right-title",
                    classes="detail-pane-title detail-pane-header",
                ):
                    yield Static(
                        "Activities",
                        id="ticket-detail-right-title-label",
                        classes="detail-pane-title-label",
                    )
                with Horizontal(id="ticket-detail-activity-search-bar"):
                    yield Static("/", id="ticket-detail-activity-search-prefix")
                    yield ActivitySearchInput(
                        placeholder="regex",
                        id="ticket-detail-activity-search-input",
                        compact=True,
                    )
                yield TicketEmailComposer(id="email-reply-composer")
                yield CommentReplyComposer(id="comment-reply-composer")
                yield DetailPaneBody(
                    self._activities_message,
                    quick_actions_for_activity=self._quick_actions_for_activity,
                    resolve_activity_asset_url=self._resolve_activity_asset_url,
                    load_activity_asset=self._load_activity_asset,
                    id="ticket-detail-right-body",
                )
        yield AppChrome(self._status_message, self._instance_context)
        yield Footer()

    def on_mount(self) -> None:
        self.call_after_refresh(self._apply_pane_layout)
        self.call_after_refresh(self.action_focus_left)
        self.call_after_refresh(self._refresh_focus_styles)

    def on_resize(self) -> None:
        self._apply_pane_layout()

    def watch_split_percent(self, _: float) -> None:
        if self.is_mounted:
            self.call_after_refresh(self._apply_pane_layout)

    def on_focus(self) -> None:
        self.call_after_refresh(self._refresh_focus_styles)

    def on_blur(self) -> None:
        self.call_after_refresh(self._refresh_focus_styles)

    def on_descendant_focus(self) -> None:
        self.call_after_refresh(self._refresh_focus_styles)

    def on_descendant_blur(self) -> None:
        self.call_after_refresh(self._refresh_focus_styles)

    def action_close(self) -> None:
        """Return to the previous screen."""

        if self.query_one("#ticket-detail-left-body", TicketDetailForm).has_unsaved_changes():
            self.app.push_screen(
                UnsavedChangesModal(),
                self._handle_unsaved_changes_decision,
            )
            return

        self.app.pop_screen()
        self.app.call_after_refresh(self._refresh_app_status_message)

    def action_focus_left(self) -> None:
        """Focus the ticket form pane."""

        self.close_activity_search()
        self.app.set_focus(self.query_one("#ticket-detail-left-body", TicketDetailForm))
        self.call_after_refresh(self._refresh_focus_styles)

    def action_focus_right(self) -> None:
        """Focus the activities pane."""

        if self._email_reply_is_open():
            self._email_reply_composer().focus_editor()
        elif self._comment_reply_is_open():
            self._comment_reply_composer().focus_editor()
        else:
            self.app.set_focus(self.query_one("#ticket-detail-right-body", DetailPaneBody))
        self.call_after_refresh(self._refresh_focus_styles)

    def open_activity_search(self) -> None:
        """Show the activities search prompt and focus its input."""

        search_bar = self.query_one("#ticket-detail-activity-search-bar", Horizontal)
        search_input = self.query_one(
            "#ticket-detail-activity-search-input",
            ActivitySearchInput,
        )
        search_bar.add_class("-active")
        search_input.value = ""
        search_input.focus()
        self.call_after_refresh(self._refresh_focus_styles)

    def close_activity_search(self) -> None:
        """Hide the activities search prompt without changing the applied search."""

        search_bar = self.query_one("#ticket-detail-activity-search-bar", Horizontal)
        search_input = self.query_one(
            "#ticket-detail-activity-search-input",
            ActivitySearchInput,
        )
        search_bar.remove_class("-active")
        search_input.value = ""
        self.call_after_refresh(self._refresh_focus_styles)

    def action_focus_next_pane(self) -> None:
        """Move focus to the next detail pane."""

        if self._left_pane_has_focus():
            self._prepare_left_pane_for_blur()
            self.action_focus_right()
            return

        self.action_focus_left()

    def action_focus_previous_pane(self) -> None:
        """Move focus to the previous detail pane."""

        if self._left_pane_has_focus():
            self._prepare_left_pane_for_blur()
            self.action_focus_right()
            return

        self.action_focus_left()

    def action_save(self) -> None:
        """Validate the form and request persistence."""

        self._request_save(close_after_save=False)

    def action_save_or_submit_comment_reply(self) -> None:
        """Submit the open inline composer or save ticket edits when none is open."""

        email_composer = self._email_reply_composer()
        if email_composer.is_open and email_composer.has_focus_within:
            email_composer.action_submit()
            return

        comment_composer = self._comment_reply_composer()
        if comment_composer.is_open and comment_composer.has_focus_within:
            comment_composer.action_submit()
            return
        self.action_save()

    def action_set_stage_close(self) -> None:
        """Set the ticket stage to closed when it changes."""

        self._set_stage(TicketStage.CLOSE)

    def action_set_stage_open(self) -> None:
        """Set the ticket stage to open when it changes."""

        self._set_stage(TicketStage.OPEN)

    def action_set_stage_waiting(self) -> None:
        """Set the ticket stage to waiting when it changes."""

        self._set_stage(TicketStage.WAIT)

    def action_open_link_picker(self) -> None:
        """Open a compact modal with discovered activity links."""

        right_body = self.query_one("#ticket-detail-right-body", DetailPaneBody)
        if not right_body.discovered_links:
            self.post_message(self.StatusRequested(self, "No links found in ticket activities."))
            return

        self.app.push_screen(
            ActivityLinkPickerModal(right_body.discovered_links),
            self._handle_link_picker_result,
        )

    def action_open_in_browser(self) -> None:
        """Request opening the current ticket in the system browser."""

        self.post_message(self.OpenInBrowserRequested(self, self._ticket))

    def action_cancel_comment_reply_or_close(self) -> None:
        """Cancel the inline composer first, then fall back to closing ticket detail."""

        email_composer = self._email_reply_composer()
        if email_composer.is_open and email_composer.has_focus_within:
            email_composer.action_cancel()
            return

        comment_composer = self._comment_reply_composer()
        if comment_composer.is_open and comment_composer.has_focus_within:
            comment_composer.action_cancel()
            return
        self.action_close()

    def action_assign_to_me(self) -> None:
        """Assign the authenticated app user to the ticket."""

        if self._current_user is None:
            self.post_message(
                self.StatusRequested(
                    self,
                    "Current app user is not available.",
                    error=True,
                )
            )
            return

        self.query_one("#ticket-detail-left-body", TicketDetailForm).assign_user(
            self._current_user
        )

    def action_add_comment(self) -> None:
        """Open the inline add-comment flow for the current ticket."""

        try:
            right_body = self.query_one("#ticket-detail-right-body", DetailPaneBody)
        except NoMatches:
            right_body = None

        if (
            right_body is not None
            and self.app.focused is right_body
            and right_body.has_search_state
        ):
            right_body.action_next_search_match()
            return

        self._open_new_comment()

    def request_close_after_save(self) -> None:
        """Validate the form, then close the detail view after a successful save."""

        self._request_save(close_after_save=True)

    def cancel_close_after_save(self) -> None:
        """Clear any pending close request from a previous save attempt."""

        self._close_after_save = False

    def consume_close_after_save(self) -> bool:
        """Return and clear whether the screen should close after save."""

        close_after_save = self._close_after_save
        self._close_after_save = False
        return close_after_save

    def _request_save(self, *, close_after_save: bool) -> bool:
        form = self.query_one("#ticket-detail-left-body", TicketDetailForm)
        try:
            patch = form.build_patch()
        except ValueError as error:
            self._close_after_save = False
            self.post_message(self.StatusRequested(self, str(error), error=True))
            return False

        if not patch.has_changes():
            self._close_after_save = False
            self.post_message(self.StatusRequested(self, "No changes to save."))
            return False

        self._close_after_save = close_after_save
        self.post_message(self.SaveRequested(self, self._ticket, patch))
        return True

    def _set_stage(self, stage: TicketStage) -> None:
        """Update the selected stage only when it changes."""

        form = self.query_one("#ticket-detail-left-body", TicketDetailForm)
        if form.selected_stage() is stage:
            return

        form.set_selected_stage(stage)

    def sync_ticket(self, ticket: Ticket) -> None:
        """Refresh the screen with a saved ticket snapshot."""

        self._ticket = ticket
        self.query_one("#ticket-detail-left-body", TicketDetailForm).sync_ticket(ticket)

    def set_ticket_categories(self, category_options: list[TicketCategoryOption]) -> None:
        """Refresh the detail form with loaded ticket categories."""

        self._category_options = list(category_options)
        self.query_one("#ticket-detail-left-body", TicketDetailForm).set_ticket_categories(
            category_options
        )

    def set_ticket_statuses(
        self,
        category_name: str,
        status_options: list[TicketStatusOption],
    ) -> None:
        """Refresh the detail form with loaded ticket statuses."""

        self._status_options = list(status_options)
        self._status_options_category_name = category_name
        self.query_one("#ticket-detail-left-body", TicketDetailForm).set_ticket_statuses(
            category_name,
            status_options,
        )

    def set_ticket_users(self, user_options: list[TicketUserOption]) -> None:
        """Refresh the detail form with loaded ticket users."""

        self._user_options = list(user_options)
        self.query_one("#ticket-detail-left-body", TicketDetailForm).set_ticket_users(
            user_options
        )

    def set_current_user(self, current_user: TicketUserOption) -> None:
        """Update the authenticated app user available to ticket shortcuts."""

        self._current_user = current_user

    def set_activities_loading(self) -> None:
        """Show the activities loading state."""

        self.query_one("#ticket-detail-right-body", DetailPaneBody).show_loading()

    def set_activities_error(self) -> None:
        """Show the activities error state."""

        self.query_one("#ticket-detail-right-body", DetailPaneBody).show_error()

    def set_ticket_activities(self, activities: list[TicketActivity]) -> None:
        """Render the loaded ticket activities."""

        self.query_one("#ticket-detail-right-body", DetailPaneBody).set_activities(activities)

    def handle_comment_submit_success(self) -> None:
        """Clear the inline composer after a successful submit and reload."""

        if not self._comment_reply_is_open():
            return

        self._comment_reply_composer().close()
        self.query_one("#ticket-detail-right-body", DetailPaneBody).unpin_selection()
        self.query_one("#ticket-detail-right-body", DetailPaneBody).show_loading()
        self.action_focus_right()

    def handle_email_draft_loaded(self, draft: TicketEmailDraft) -> None:
        """Open the inline email composer with a loaded connector draft."""

        self._email_reply_composer().open_draft(draft)
        self.call_after_refresh(self._refresh_focus_styles)

    def handle_email_draft_failure(self) -> None:
        """Restore the activities pane when email draft loading fails."""

        self._close_email_reply(restore_focus=False)
        right_body = self.query_one("#ticket-detail-right-body", DetailPaneBody)
        right_body.unpin_selection()
        self.app.set_focus(right_body)
        self.call_after_refresh(self._refresh_focus_styles)

    def handle_comment_submit_failure(self, error_message: str) -> None:
        """Keep the inline composer open and show the submit failure inline."""

        composer = self._comment_reply_composer()
        if not composer.is_open:
            return

        composer.set_submission_pending(False)
        composer.show_validation(error_message)
        if composer.reply_target is not None:
            self.query_one("#ticket-detail-right-body", DetailPaneBody).pin_selection()
        composer.focus_editor()

    def handle_email_submit_success(self) -> None:
        """Clear the inline email composer after a successful send and reload."""

        if not self._email_reply_is_open():
            return

        self._close_email_reply(restore_focus=False)
        self.query_one("#ticket-detail-right-body", DetailPaneBody).show_loading()
        self.action_focus_right()

    def handle_email_submit_failure(self, error_message: str) -> None:
        """Keep the inline email composer open and show the send failure inline."""

        composer = self._email_reply_composer()
        if not composer.is_open:
            return

        composer.set_submission_pending(False)
        composer.show_validation(error_message)
        self.query_one("#ticket-detail-right-body", DetailPaneBody).pin_selection()
        composer.focus_editor()

    def on_vertical_splitter_dragged(self, message: VerticalSplitter.Dragged) -> None:
        panes = self.query_one("#ticket-detail-panes", Horizontal)
        available_width = max(1, panes.size.width - 1)
        origin_x = panes.region.x
        relative_x = max(0, min(available_width, message.screen_x - origin_x))
        self.split_percent = (relative_x / available_width) * 100

    def _apply_pane_layout(self) -> None:
        panes = self.query_one("#ticket-detail-panes", Horizontal)
        available_width = max(1, panes.size.width - 1)
        if available_width <= 1:
            return

        if available_width >= 80:
            min_left = 24
            min_right = 40
        else:
            min_left = 18
            min_right = 20

        left_width = round((self.split_percent / 100) * available_width)
        left_width = max(min_left, min(left_width, available_width - min_right))
        right_width = max(min_right, available_width - left_width)

        self.query_one("#ticket-detail-left-pane", Vertical).styles.width = left_width
        self.query_one("#ticket-detail-right-pane", Vertical).styles.width = right_width

    def _refresh_focus_styles(self) -> None:
        try:
            left_title = self.query_one("#ticket-detail-left-title", Static)
            right_title = self.query_one("#ticket-detail-right-title", Widget)
            left_body = self.query_one("#ticket-detail-left-body", TicketDetailForm)
            right_body = self.query_one("#ticket-detail-right-body", DetailPaneBody)
            search_input = self.query_one(
                "#ticket-detail-activity-search-input",
                ActivitySearchInput,
            )
            email_composer = self.query_one("#email-reply-composer", TicketEmailComposer)
            composer = self.query_one("#comment-reply-composer", CommentReplyComposer)
        except NoMatches:
            return

        focused = self.app.focused
        left_title.set_class(focused is left_body or left_body.has_focus_within, "-focused")
        right_title.set_class(
            focused is right_body
            or focused is search_input
            or composer.has_focus_within
            or email_composer.has_focus_within,
            "-focused",
        )

    def _left_pane_has_focus(self) -> bool:
        left_body = self.query_one("#ticket-detail-left-body", TicketDetailForm)
        focused = self.app.focused
        return focused is left_body or left_body.has_focus_within

    def _prepare_left_pane_for_blur(self) -> None:
        form = self.query_one("#ticket-detail-left-body", TicketDetailForm)
        form.stop_editing_for_external_focus_change()

    def _refresh_app_status_message(self) -> None:
        """Refresh the app footer when the active screen stack changes."""

        refresh_status_message = getattr(self.app, "_refresh_status_message", None)
        if callable(refresh_status_message):
            refresh_status_message()

    def _handle_unsaved_changes_decision(
        self,
        decision: Literal["save", "discard", "cancel"] | None,
    ) -> None:
        if decision is None:
            return

        if decision == "save":
            self.request_close_after_save()
            return

        if decision == "discard":
            self.app.pop_screen()
            self.app.call_after_refresh(self._refresh_app_status_message)

    def _handle_link_picker_result(self, link: ActivityLink | None) -> None:
        """Restore activity focus and open the selected discovered link."""

        self.action_focus_right()
        if link is None:
            return
        self.post_message(self.OpenActivityLinkRequested(self, link.url))

    def _handle_attachment_destination_result(self, destination: Path | None) -> None:
        """Restore focus and start an attachment download when a directory was chosen."""

        activity = self._pending_attachment_download_activity
        self._pending_attachment_download_activity = None
        self.action_focus_right()
        if destination is None or activity is None:
            return

        self.post_message(
            self.ActivityAttachmentDownloadRequested(
                self,
                self._ticket,
                activity,
                destination,
            )
        )

    def _handle_comment_attachment_path_result(self, path: Path | None) -> None:
        """Restore composer focus and stage the chosen local attachment path."""

        composer = self._comment_reply_composer()
        if path is not None and composer.is_open:
            composer.stage_attachment(path)
        else:
            composer.focus_editor()
        self.call_after_refresh(self._refresh_focus_styles)

    def _handle_comment_attachment_removal_result(self, path: Path | None) -> None:
        """Restore composer focus and remove the selected staged attachment."""

        composer = self._comment_reply_composer()
        if path is not None and composer.is_open:
            composer.unstage_attachment(path)
        else:
            composer.focus_editor()
        self.call_after_refresh(self._refresh_focus_styles)

    @on(DetailPaneBody.QuickActionRequested)
    def handle_detail_pane_quick_action_requested(
        self,
        message: DetailPaneBody.QuickActionRequested,
    ) -> None:
        """Execute a supported quick action requested by the activities pane."""

        self._invoke_quick_action(message.action)

    @on(DetailPaneBody.SearchRequested)
    def handle_detail_pane_search_requested(
        self,
        _: DetailPaneBody.SearchRequested,
    ) -> None:
        """Open the regex search prompt for the activities pane."""

        self.open_activity_search()

    @on(DetailPaneBody.SearchStatusChanged)
    def handle_detail_pane_search_status_changed(
        self,
        message: DetailPaneBody.SearchStatusChanged,
    ) -> None:
        """Forward activity-search status updates to the app-level footer state."""

        setattr(self.app, "ticket_detail_search_status", message.status)

    @on(ActivitySearchInput.SearchCancelled)
    def handle_activity_search_cancelled(
        self,
        _: ActivitySearchInput.SearchCancelled,
    ) -> None:
        """Close the activities search prompt and restore activities focus."""

        self.close_activity_search()
        self.action_focus_right()

    def on_input_submitted(self, message: Input.Submitted) -> None:
        """Apply activity search queries from the inline prompt."""

        search_input = self.query_one(
            "#ticket-detail-activity-search-input",
            ActivitySearchInput,
        )
        if message.input is not search_input:
            return

        self.query_one("#ticket-detail-right-body", DetailPaneBody).apply_search(message.value)
        self.close_activity_search()
        self.action_focus_right()

    @on(CommentReplyComposer.Submitted)
    def handle_comment_reply_submitted(
        self,
        message: CommentReplyComposer.Submitted,
    ) -> None:
        """Submit the validated inline comment draft through the app."""

        composer = message.composer
        composer.set_submission_pending(True)
        if composer.reply_target is not None:
            self.query_one("#ticket-detail-right-body", DetailPaneBody).pin_selection()
        self.post_message(
            self.CommentRequested(
                self,
                self._ticket,
                message.content,
                message.attachment_paths,
            )
        )

    @on(CommentReplyComposer.AttachmentPathRequested)
    def handle_comment_attachment_path_requested(
        self,
        message: CommentReplyComposer.AttachmentPathRequested,
    ) -> None:
        """Open the typed-path picker for a comment attachment."""

        message.stop()
        self.app.push_screen(
            CommentAttachmentPathPickerModal(),
            self._handle_comment_attachment_path_result,
        )

    @on(CommentReplyComposer.AttachmentRemovalRequested)
    def handle_comment_attachment_removal_requested(
        self,
        message: CommentReplyComposer.AttachmentRemovalRequested,
    ) -> None:
        """Open the staged-attachment picker for removing one file."""

        message.stop()
        self.app.push_screen(
            CommentAttachmentRemovalModal(list(message.composer.staged_attachment_paths)),
            self._handle_comment_attachment_removal_result,
        )

    @on(TicketEmailComposer.Submitted)
    def handle_email_reply_submitted(
        self,
        message: TicketEmailComposer.Submitted,
    ) -> None:
        """Submit the validated inline email draft through the app."""

        message.composer.set_submission_pending(True)
        self.query_one("#ticket-detail-right-body", DetailPaneBody).pin_selection()
        self.post_message(self.EmailSendRequested(self, self._ticket, message.request))

    @on(CommentReplyComposer.Cancelled)
    def handle_comment_reply_cancelled(
        self,
        _: CommentReplyComposer.Cancelled,
    ) -> None:
        """Close the inline reply composer without creating a comment."""

        self._cancel_comment_reply()

    @on(TicketEmailComposer.Cancelled)
    def handle_email_reply_cancelled(
        self,
        _: TicketEmailComposer.Cancelled,
    ) -> None:
        """Close the inline email composer without sending."""

        self._cancel_email_reply()

    def _current_quick_actions(self) -> tuple[QuickActionSpec, ...]:
        try:
            right_body = self.query_one("#ticket-detail-right-body", DetailPaneBody)
        except NoMatches:
            return ()

        if self.app.focused is not right_body:
            return ()
        return self._quick_actions_for_activity(right_body.selected_activity)

    @staticmethod
    def _quick_actions_for_activity(activity: TicketActivity | None) -> tuple[QuickActionSpec, ...]:
        if activity is None:
            return ()
        download_actions = (DOWNLOAD_QUICK_ACTION,) if activity.downloadable_attachments() else ()
        copy_actions = (COPY_QUICK_ACTION,) if activity.body_text() is not None else ()
        if activity.type == "EMAIL":
            return (*EMAIL_QUICK_ACTIONS, *download_actions, *copy_actions)
        if activity.display_type == "Comment":
            return (*COMMENT_QUICK_ACTIONS, *download_actions, *copy_actions)
        return (*download_actions, *copy_actions)

    def _invoke_quick_action(self, action: str) -> None:
        if action == "copy":
            self._copy_selected_activity_body()
            return

        supported_actions = {
            quick_action.action: quick_action
            for quick_action in self._current_quick_actions()
        }
        if supported_actions.get(action) is None:
            return

        if action == "reply" and self._selected_activity_is_comment():
            self._open_comment_reply()
            return

        if action == "reply" and self._selected_activity_is_email():
            self._request_email_draft(TicketEmailAction.REPLY)
            return

        if action == "forward" and self._selected_activity_is_email():
            self._request_email_draft(TicketEmailAction.FORWARD)
            return

        if action == "download":
            self._request_attachment_download()

    def _copy_selected_activity_body(self) -> None:
        """Copy the selected activity body text to the clipboard when available."""

        selected_activity = self._selected_activity()
        if selected_activity is None:
            self.post_message(self.StatusRequested(self, ACTIVITY_COPY_EMPTY_STATUS))
            return

        body_text = selected_activity.body_text()
        if body_text is None:
            self.post_message(self.StatusRequested(self, ACTIVITY_COPY_EMPTY_STATUS))
            return

        self.app.copy_to_clipboard(self._clipboard_text(body_text))
        self.post_message(self.StatusRequested(self, ACTIVITY_COPY_SUCCESS_STATUS))

    def _request_attachment_download(self) -> None:
        """Open the attachment destination picker for the selected activity."""

        selected_activity = self._selected_activity()
        if selected_activity is None or not selected_activity.downloadable_attachments():
            self.post_message(self.StatusRequested(self, ACTIVITY_DOWNLOAD_EMPTY_STATUS))
            return

        picker_default_path = "~/Downloads"
        resolve_default_path = getattr(self.app, "attachment_download_default_path", None)
        if callable(resolve_default_path):
            candidate_default_path = resolve_default_path()
            if isinstance(candidate_default_path, str) and candidate_default_path.strip():
                picker_default_path = candidate_default_path

        self._pending_attachment_download_activity = selected_activity
        self.app.push_screen(
            AttachmentDestinationPickerModal(picker_default_path),
            self._handle_attachment_destination_result,
        )

    @staticmethod
    def _clipboard_text(value: str) -> str:
        """Normalize copied text for clipboard consumers that expect CRLF line endings."""

        return value.replace("\r\n", "\n").replace("\r", "\n").replace("\n", "\r\n")

    def _open_comment_reply(self) -> None:
        """Open the inline comment reply composer for the selected comment."""

        right_body = self.query_one("#ticket-detail-right-body", DetailPaneBody)
        selected_activity = right_body.selected_activity
        if selected_activity is None or selected_activity.display_type != "Comment":
            return

        if self._email_reply_is_open():
            self._close_email_reply(restore_focus=False)
        self._assign_reply_user_from_activity(selected_activity)
        right_body.pin_selection()
        self._comment_reply_composer().open_for(selected_activity)
        self.call_after_refresh(self._refresh_focus_styles)

    def _assign_reply_user_from_activity(self, activity: TicketActivity) -> None:
        """Update the ticket assignee from the replied activity when a safe match exists."""

        form = self.query_one("#ticket-detail-left-body", TicketDetailForm)
        matched_user = form.resolve_assignable_user(
            user_name=activity.user_name,
            user_title=activity.user,
        )
        if matched_user is None:
            self.post_message(self.StatusRequested(self, REPLY_USER_UNMATCHED_STATUS))
            return

        form.assign_user(matched_user)

    def _open_new_comment(self) -> None:
        """Open the inline composer for a new top-level comment."""

        right_body = self.query_one("#ticket-detail-right-body", DetailPaneBody)
        if self._email_reply_is_open():
            self._close_email_reply(restore_focus=False)
        right_body.unpin_selection()
        self._comment_reply_composer().open_new_comment()
        self.call_after_refresh(self._refresh_focus_styles)

    def _cancel_comment_reply(self) -> None:
        """Close the inline comment reply composer and restore activities focus."""

        self._close_comment_reply(restore_focus=True)

    def _close_comment_reply(self, *, restore_focus: bool) -> None:
        """Close the inline comment reply composer."""

        composer = self._comment_reply_composer()
        if not composer.is_open:
            return

        composer.close()
        right_body = self.query_one("#ticket-detail-right-body", DetailPaneBody)
        right_body.unpin_selection()
        if restore_focus:
            self.app.set_focus(right_body)
        self.call_after_refresh(self._refresh_focus_styles)

    def _request_email_draft(self, action: TicketEmailAction) -> None:
        """Load and open the inline email composer for the selected email activity."""

        selected_activity = self._selected_activity()
        if selected_activity is None or selected_activity.type != "EMAIL":
            return

        composer = self._email_reply_composer()
        if (
            composer.is_open
            and composer.action is action
            and composer.source_activity_name == selected_activity.name
        ):
            composer.focus_editor()
            self.call_after_refresh(self._refresh_focus_styles)
            return

        if self._comment_reply_is_open():
            self._close_comment_reply(restore_focus=False)
        if self._email_reply_is_open():
            self._close_email_reply(restore_focus=False)

        self.query_one("#ticket-detail-right-body", DetailPaneBody).pin_selection()
        self.post_message(self.EmailDraftRequested(self, self._ticket, selected_activity, action))

    def _cancel_email_reply(self) -> None:
        """Close the inline email composer and restore activities focus."""

        self._close_email_reply(restore_focus=True)

    def _close_email_reply(self, *, restore_focus: bool) -> None:
        """Close the inline email composer."""

        composer = self._email_reply_composer()
        if not composer.is_open:
            return

        composer.close()
        right_body = self.query_one("#ticket-detail-right-body", DetailPaneBody)
        right_body.unpin_selection()
        if restore_focus:
            self.app.set_focus(right_body)
        self.call_after_refresh(self._refresh_focus_styles)

    def _selected_activity(self) -> TicketActivity | None:
        """Return the currently selected activity."""

        try:
            return self.query_one("#ticket-detail-right-body", DetailPaneBody).selected_activity
        except NoMatches:
            return None

    def _selected_activity_is_comment(self) -> bool:
        """Return whether the selected activity is a comment entry."""

        selected_activity = self._selected_activity()
        return selected_activity is not None and selected_activity.display_type == "Comment"

    def _selected_activity_is_email(self) -> bool:
        """Return whether the selected activity is an email entry."""

        selected_activity = self._selected_activity()
        return selected_activity is not None and selected_activity.type == "EMAIL"

    def _comment_reply_composer(self) -> CommentReplyComposer:
        return self.query_one("#comment-reply-composer", CommentReplyComposer)

    def _comment_reply_is_open(self) -> bool:
        return self._comment_reply_composer().is_open

    def _email_reply_composer(self) -> TicketEmailComposer:
        return self.query_one("#email-reply-composer", TicketEmailComposer)

    def _email_reply_is_open(self) -> bool:
        return self._email_reply_composer().is_open
