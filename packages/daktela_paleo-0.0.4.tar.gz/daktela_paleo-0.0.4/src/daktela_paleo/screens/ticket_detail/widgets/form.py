"""Ticket detail widgets for the editable form and its private controls."""

from __future__ import annotations

from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import Any, cast

from rich.text import Text
from textual import events
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.css.query import NoMatches
from textual.message import Message
from textual.reactive import reactive
from textual.visual import VisualType
from textual.widget import Widget
from textual.widgets import Input, Select, Static, TextArea
from textual.widgets.option_list import Option
from textual.widgets._select import SelectCurrent, SelectOverlay
from textual.widgets.select import NoSelection

from daktela_paleo.models import (
    Ticket,
    TicketCategoryOption,
    TicketCustomField,
    TicketEditPatch,
    TicketPriority,
    TicketStatusOption,
    TicketStage,
    TicketUserOption,
    format_editable_datetime,
)

UNASSIGNED_USER_VALUE = "__ticket-user-unassigned__"
NO_STATUS_VALUE = "__ticket-status-none__"


@dataclass(frozen=True)
class SelectOverlayOptionRecord:
    """Metadata used to restore and filter overlay options."""

    prompt: VisualType
    label: str
    source_index: int
    disabled: bool = False


class EditStopped(Message):
    """Posted when a form control exits editing mode."""

    def __init__(self, control: Widget) -> None:
        super().__init__()
        self._control = control

    @property
    def control(self) -> Widget:
        return self._control


class TicketFormInput(Input):
    """Single-line input that can hand focus back to the form."""

    BINDINGS = [
        *Input.BINDINGS,
        Binding("escape", "stop_edit", "Stop Edit", show=False),
    ]

    def action_stop_edit(self) -> None:
        """Leave edit mode and return focus to the parent form."""

        self.post_message(EditStopped(self))


class TicketFormTextArea(TextArea):
    """Multiline text area that can hand focus back to the form."""

    BINDINGS = [
        *TextArea.BINDINGS,
        Binding("escape", "stop_edit", "Stop Edit", show=False),
    ]

    def action_stop_edit(self) -> None:
        """Leave edit mode and return focus to the parent form."""

        self.post_message(EditStopped(self))


class TicketFormSelect(Select[str]):
    """Select control that returns focus to the form after editing."""

    BINDINGS = [
        *Select.BINDINGS,
        Binding("escape", "stop_edit", "Stop Edit", show=False),
    ]

    def __init__(
        self,
        options: list[tuple[str, str]],
        *,
        value: str,
        id: str,
        classes: str,
        clear_value: str | None = None,
    ) -> None:
        super().__init__(
            options,
            allow_blank=False,
            value=value,
            type_to_search=False,
            compact=True,
            id=id,
            classes=classes,
        )
        self._return_focus_after_collapse = False
        self._clear_value = clear_value

    @property
    def is_clearable(self) -> bool:
        """Return whether the select supports clearing to a sentinel value."""

        return self._clear_value is not None

    def begin_overlay_edit(self) -> None:
        """Open the select overlay as an editing session."""

        self._return_focus_after_collapse = True
        self.focus()
        self.action_show_overlay()

    def cancel_overlay_edit(self) -> None:
        """Close the overlay without returning focus to the form."""

        self._return_focus_after_collapse = False
        self.expanded = False

    def action_stop_edit(self) -> None:
        """Leave edit mode and return focus to the parent form."""

        self._return_focus_after_collapse = False
        self.post_message(EditStopped(self))

    def clear_selection(self) -> None:
        """Set the select to its configured cleared value."""

        if self._clear_value is None or self.value == self._clear_value:
            return
        self.value = self._clear_value

    def _watch_expanded(self, expanded: bool) -> None:
        try:
            overlay = self.query_one(TicketFormSelectOverlay)
        except NoMatches:
            return

        self.set_class(expanded, "-expanded")
        if expanded:
            overlay.reset_search()
            overlay.focus(scroll_visible=False)
            overlay.select_source_index(self._current_source_index())
            self.query_one(SelectCurrent).has_value = True
            return

        overlay.reset_search()
        if not expanded and self._return_focus_after_collapse:
            self._return_focus_after_collapse = False
            self.call_after_refresh(lambda: self.post_message(EditStopped(self)))

    def _watch_value(self, value: str | NoSelection) -> None:
        self._value = value
        try:
            select_current = self.query_one(SelectCurrent)
        except NoMatches:
            return

        overlay = self.query_one(TicketFormSelectOverlay)
        if value == self.NULL:
            overlay.select_source_index(None)
            select_current.update(self.NULL)
            changed = cast(Any, self.Changed)
            self.post_message(changed(self, value))
            return

        for index, (prompt, prompt_value) in enumerate(self._options):
            if prompt_value != value:
                continue
            overlay.select_source_index(index)
            select_current.update(prompt)
            break

        changed = cast(Any, self.Changed)
        self.post_message(changed(self, value))

    def _setup_options_renderables(self) -> None:
        options = [Option(prompt) for prompt, _option_value in self._options]
        overlay = self.query_one(TicketFormSelectOverlay)
        overlay.set_source_options(options)

    def action_show_overlay(self) -> None:
        """Show the overlay."""

        self.query_one(SelectCurrent).has_value = True
        self.expanded = True
        overlay = self.query_one(TicketFormSelectOverlay)
        if overlay.highlighted is None:
            overlay.action_first()

    def _current_source_index(self) -> int | None:
        if self.value is self.NULL:
            return None
        value = self.value
        for index, (_prompt, prompt_value) in enumerate(self._options):
            if value == prompt_value:
                return index
        return None

    def compose(self) -> ComposeResult:
        """Compose the select with a vi-friendly overlay."""

        yield SelectCurrent(self.prompt)
        yield TicketFormSelectOverlay(type_to_search=self._type_to_search).data_bind(
            compact=Select.compact
        )


class TicketFormSelectOverlay(SelectOverlay):
    """Select overlay with vi-style navigation."""

    _VI_KEYS = {"h", "j", "k", "l"}

    BINDINGS = [
        *SelectOverlay.BINDINGS,
        Binding("j", "cursor_down", "Down", show=False),
        Binding("k", "cursor_up", "Up", show=False),
        Binding("h,left", "dismiss", "Dismiss menu", show=False),
        Binding("l,right", "select", "Select", show=False),
    ]

    NO_MATCHES_LABEL = "No matches"
    _SIMILARITY_THRESHOLD = 0.60

    def __init__(self, type_to_search: bool = True) -> None:
        super().__init__(type_to_search=type_to_search)
        self.search_active = False
        self.search_query = ""
        self._source_options: list[SelectOverlayOptionRecord] = []
        self._filtered_source_indices: list[int] = []

    def set_source_options(self, options: list[Option]) -> None:
        """Replace the source options and reset any active search state."""

        self._source_options = [
            SelectOverlayOptionRecord(
                prompt=option.prompt,
                label=self._prompt_label(option.prompt),
                source_index=index,
                disabled=option.disabled,
            )
            for index, option in enumerate(options)
        ]
        self.reset_search()

    def reset_search(self) -> None:
        """Leave search mode and show all available options."""

        highlighted_source_index = self._highlighted_source_index()
        self.search_active = False
        self.search_query = ""
        self._render_source_options(preferred_source_index=highlighted_source_index)
        self._update_border_title()

    def start_search(self) -> None:
        """Enter search mode with an empty query."""

        highlighted_source_index = self._highlighted_source_index()
        self.search_active = True
        self.search_query = ""
        self._render_source_options(preferred_source_index=highlighted_source_index)
        self._update_border_title()

    def select_source_index(self, source_index: int | None) -> None:
        """Highlight the row matching the source option index."""

        if source_index is None:
            self.highlighted = None
            return

        try:
            visible_index = self._filtered_source_indices.index(source_index)
        except ValueError:
            self.highlighted = None
            return
        self.select(visible_index)

    def check_consume_key(self, key: str, character: str | None = None) -> bool:
        """Reserve vi keys for navigation instead of type-to-search."""

        if self.search_active:
            return key == "backspace" or (character is not None and character.isprintable())
        if character == "i":
            return True
        if character in self._VI_KEYS:
            return False
        return super().check_consume_key(key, character)

    async def _on_key(self, event: events.Key) -> None:
        """Skip type-to-search handling for vi navigation keys."""

        if self.search_active:
            if event.key == "backspace":
                event.stop()
                event.prevent_default()
                self._set_search_query(self.search_query[:-1])
                return
            if event.character is not None and event.is_printable:
                event.stop()
                event.prevent_default()
                self._set_search_query(f"{self.search_query}{event.character}")
                return
            await super()._on_key(event)
            return

        if event.character == "i":
            event.stop()
            event.prevent_default()
            self.start_search()
            return
        if event.character == "j":
            event.stop()
            event.prevent_default()
            self.action_cursor_down()
            return
        if event.character == "k":
            event.stop()
            event.prevent_default()
            self.action_cursor_up()
            return
        if event.character == "h":
            event.stop()
            event.prevent_default()
            self.action_dismiss()
            return
        if event.character == "l":
            event.stop()
            event.prevent_default()
            self.action_select()
            return
        if event.character in self._VI_KEYS:
            return
        await super()._on_key(event)

    def action_dismiss(self) -> None:
        """Dismiss search mode first, then close the overlay."""

        if self.search_active:
            self.reset_search()
            return
        super().action_dismiss()

    def action_select(self) -> None:
        """Select the highlighted filtered option using its source index."""

        highlighted = self.highlighted
        if highlighted is None:
            return

        option = self.options[highlighted]
        if option.disabled:
            return

        self.post_message(self.UpdateSelection(self._filtered_source_indices[highlighted]))

    def _set_search_query(self, query: str) -> None:
        self.search_query = query
        self._apply_search()
        self._update_border_title()

    def _apply_search(self) -> None:
        if not self.search_query:
            self._render_source_options(preferred_source_index=self._highlighted_source_index())
            return

        matches = [
            (self._match_rank(self.search_query, option), option.source_index)
            for option in self._source_options
        ]
        ranked_matches = [
            (rank, source_index)
            for rank, source_index in matches
            if rank is not None
        ]
        ranked_matches.sort(key=lambda item: item[0])
        self._render_filtered_source_indices([source_index for _, source_index in ranked_matches])

    def _render_source_options(self, preferred_source_index: int | None = None) -> None:
        self._render_filtered_source_indices(
            [option.source_index for option in self._source_options],
            preferred_source_index=preferred_source_index,
        )

    def _render_filtered_source_indices(
        self,
        source_indices: list[int],
        *,
        preferred_source_index: int | None = None,
    ) -> None:
        self._filtered_source_indices = list(source_indices)
        if not self._filtered_source_indices:
            self.set_options([Option(self.NO_MATCHES_LABEL, disabled=True)])
            self.highlighted = None
            return

        self.set_options(
            [
                Option(
                    self._source_options[source_index].prompt,
                    disabled=self._source_options[source_index].disabled,
                )
                for source_index in self._filtered_source_indices
            ]
        )
        self.highlighted = self._preferred_visible_index(preferred_source_index)

    def _preferred_visible_index(self, preferred_source_index: int | None) -> int | None:
        if preferred_source_index is not None:
            try:
                visible_index = self._filtered_source_indices.index(preferred_source_index)
            except ValueError:
                pass
            else:
                if not self._source_options[preferred_source_index].disabled:
                    return visible_index
        return self._next_enabled_index()

    def _next_enabled_index(self) -> int | None:
        for index, source_index in enumerate(self._filtered_source_indices):
            if not self._source_options[source_index].disabled:
                return index
        return None

    def _highlighted_source_index(self) -> int | None:
        if self.highlighted is None:
            return None
        if self.highlighted >= len(self._filtered_source_indices):
            return None
        return self._filtered_source_indices[self.highlighted]

    def _match_rank(
        self,
        query: str,
        option: SelectOverlayOptionRecord,
    ) -> tuple[int, float, int, int, int] | None:
        query_text = query.strip().lower()
        if not query_text:
            return (0, 0.0, 0, len(option.label), option.source_index)

        label_text = option.label.lower()
        if label_text == query_text:
            return (0, 0.0, 0, len(option.label), option.source_index)

        if label_text.startswith(query_text):
            return (1, 0.0, 0, len(option.label), option.source_index)

        substring_index = label_text.find(query_text)
        if substring_index != -1:
            return (2, float(substring_index), 0, len(option.label), option.source_index)

        subsequence = self._subsequence_rank(query_text, label_text)
        if subsequence is not None:
            span, start = subsequence
            return (3, float(span), start, len(option.label), option.source_index)

        similarity = SequenceMatcher(None, query_text, label_text).ratio()
        if similarity >= self._SIMILARITY_THRESHOLD:
            return (4, -similarity, 0, len(option.label), option.source_index)

        return None

    @staticmethod
    def _subsequence_rank(query: str, label: str) -> tuple[int, int] | None:
        positions: list[int] = []
        search_from = 0
        for character in query:
            match_at = label.find(character, search_from)
            if match_at == -1:
                return None
            positions.append(match_at)
            search_from = match_at + 1
        return (positions[-1] - positions[0], positions[0])

    @staticmethod
    def _prompt_label(prompt: VisualType) -> str:
        if isinstance(prompt, Text):
            return prompt.plain
        return str(prompt)

    def _update_border_title(self) -> None:
        self.border_title = f"Search: {self.search_query}" if self.search_active else None


class TicketFormRow(Horizontal):
    """A compact label/control row in the ticket detail form."""

    DEFAULT_CSS = """
    TicketFormRow {
        height: 1;
        min-height: 1;
        padding: 0;
        border: none;
        background: transparent;
    }

    TicketFormRow.-active {
        background: $panel;
    }

    .ticket-detail-form-label {
        height: 1;
        width: 14;
        min-width: 14;
        padding: 0;
        color: $text-muted;
    }

    .ticket-detail-form-control-wrap {
        height: 1;
        width: 1fr;
        padding: 0;
    }

    .ticket-detail-form-control {
        height: 1;
        width: 1fr;
        padding: 0 1;
    }

    TicketFormRow#ticket-description-row {
        height: 3;
        min-height: 3;
    }

    TicketFormRow#ticket-description-row .ticket-detail-form-label {
        height: 3;
    }

    TicketFormRow#ticket-description-row .ticket-detail-form-control-wrap,
    TicketFormRow#ticket-description-row .ticket-detail-form-control {
        height: 3;
    }

    """

    def __init__(self, label: str, control: Widget, *, id: str | None = None) -> None:
        super().__init__(id=id)
        self._label = label
        self._control = control

    def compose(self) -> ComposeResult:
        yield Static(self._label, classes="ticket-detail-form-label")
        with Vertical(classes="ticket-detail-form-control-wrap"):
            yield self._control


@dataclass(frozen=True)
class TicketCustomFieldDisplay:
    """Read-only ticket custom-field content rendered in the left pane."""

    label: str
    value: str


class TicketCustomFieldsSection(Widget):
    """Read-only custom-field section shown below the editable form rows."""

    DEFAULT_CSS = """
    TicketCustomFieldsSection {
        layout: vertical;
        height: auto;
        min-height: 1;
        padding: 0;
        background: transparent;
    }

    #ticket-custom-fields-title {
        height: 1;
        padding: 0;
        color: $text-muted;
        text-style: bold;
    }

    .ticket-custom-field-row {
        height: auto;
        min-height: 1;
        padding: 0;
        background: transparent;
    }

    .ticket-custom-field-label {
        height: auto;
        min-height: 1;
        width: 14;
        min-width: 14;
        padding: 0;
        color: $text-muted;
    }

    .ticket-custom-field-value-wrap {
        layout: vertical;
        height: auto;
        min-height: 1;
        width: 1fr;
        padding: 0;
    }

    .ticket-custom-field-value {
        height: auto;
        min-height: 1;
        width: 1fr;
        padding: 0 1;
        color: $text;
    }
    """

    def __init__(
        self,
        fields: list[TicketCustomFieldDisplay],
        *,
        id: str | None = None,
    ) -> None:
        super().__init__(id=id)
        self._fields = tuple(fields)

    def compose(self) -> ComposeResult:
        yield Static("Custom Fields", id="ticket-custom-fields-title")
        for index, field in enumerate(self._fields):
            with Horizontal(
                id=f"ticket-custom-field-row-{index}",
                classes="ticket-custom-field-row",
            ):
                yield Static(
                    f"{field.label}:",
                    classes="ticket-detail-form-label ticket-custom-field-label",
                )
                with Vertical(classes="ticket-custom-field-value-wrap"):
                    yield Static(
                        field.value,
                        classes="ticket-custom-field-value",
                    )


class TicketDetailForm(Widget):
    """Keyboard-driven form for editable ticket fields."""

    class StatusOptionsRequested(Message):
        """Posted when the selected category needs status options loaded."""

        def __init__(self, form: TicketDetailForm, category_name: str) -> None:
            super().__init__()
            self._form = form
            self.category_name = category_name

        @property
        def control(self) -> TicketDetailForm:
            return self._form

    BINDINGS = [
        Binding("j,down", "cursor_down", "Down", show=False),
        Binding("k,up", "cursor_up", "Up", show=False),
        Binding("enter,l,left", "edit_active_field", "Edit", show=False),
        Binding("d", "clear_active_field", "Delete", show=False),
    ]
    DEFAULT_CSS = """
    TicketDetailForm {
        height: 1fr;
        padding: 0 1;
        background: transparent;
        color: $text;
    }

    TicketDetailForm:focus {
        background: transparent;
    }

    TicketFormInput,
    TicketFormSelect,
    TicketFormTextArea {
        background: transparent;
        border: none;
        color: $text;
        padding: 0;
    }

    TicketFormInput:focus,
    TicketFormSelect:focus,
    TicketFormTextArea:focus {
        background: transparent;
        border: none;
    }

    TicketFormSelect > SelectCurrent {
        padding: 0 1;
        border: none;
        background: transparent;
    }

    TicketFormSelect:focus > SelectCurrent {
        border: none;
        background: transparent;
    }

    TicketFormSelect > SelectOverlay {
        border: round $border;
        background: $surface;
    }

    #ticket-description-input {
        height: 3;
    }
    """

    can_focus = True

    active_index = reactive(0)
    editing = reactive(False)

    def __init__(
        self,
        ticket: Ticket,
        category_options: list[TicketCategoryOption] | None = None,
        status_options: list[TicketStatusOption] | None = None,
        user_options: list[TicketUserOption] | None = None,
        status_options_category_name: str | None = None,
        *,
        id: str | None = None,
    ) -> None:
        super().__init__(id=id)
        self._ticket = ticket
        self._category_options = list(category_options or [])
        self._status_options = list(status_options or [])
        self._status_options_category_name = status_options_category_name
        self._user_options = list(user_options or [])
        self._observed_category_name = self._selected_category_name_fallback()
        self._pending_reloaded_status_name: str | None = None

    def compose(self) -> ComposeResult:
        yield TicketFormRow(
            "Title:",
            TicketFormInput(
                self._ticket.title,
                select_on_focus=False,
                id="ticket-name-input",
                classes="ticket-detail-form-control",
            ),
            id="ticket-name-row",
        )
        yield TicketFormRow(
            "Stage:",
            TicketFormSelect(
                self._stage_select_options(),
                value=self._selected_stage_value_fallback(),
                id="ticket-stage-input",
                classes="ticket-detail-form-control",
            ),
            id="ticket-stage-row",
        )
        yield TicketFormRow(
            "Priority:",
            TicketFormSelect(
                self._priority_select_options(),
                value=self._selected_priority_value_fallback(),
                id="ticket-priority-input",
                classes="ticket-detail-form-control",
            ),
            id="ticket-priority-row",
        )
        yield TicketFormRow(
            "Category:",
            TicketFormSelect(
                self._category_select_options(),
                value=self._selected_category_name_fallback(),
                id="ticket-category-input",
                classes="ticket-detail-form-control",
            ),
            id="ticket-category-row",
        )
        yield TicketFormRow(
            "User:",
            TicketFormSelect(
                self._user_select_options(),
                value=self._selected_user_value_fallback(),
                id="ticket-user-input",
                classes="ticket-detail-form-control",
                clear_value=UNASSIGNED_USER_VALUE,
            ),
            id="ticket-user-row",
        )
        yield TicketFormRow(
            "Status:",
            TicketFormSelect(
                self._status_select_options(),
                value=self._selected_status_value_fallback(),
                id="ticket-status-input",
                classes="ticket-detail-form-control",
                clear_value=NO_STATUS_VALUE,
            ),
            id="ticket-status-row",
        )
        yield TicketFormRow(
            "Reopen:",
            TicketFormInput(
                format_editable_datetime(self._ticket.reopen),
                select_on_focus=False,
                id="ticket-reopen-input",
                classes="ticket-detail-form-control",
            ),
            id="ticket-reopen-row",
        )
        yield TicketFormRow(
            "Description:",
            TicketFormTextArea(
                self._ticket.description or "",
                id="ticket-description-input",
                classes="ticket-detail-form-control",
            ),
            id="ticket-description-row",
        )
        custom_field_rows = self._custom_field_display_rows()
        if custom_field_rows:
            yield TicketCustomFieldsSection(
                custom_field_rows,
                id="ticket-custom-fields-section",
            )

    def on_mount(self) -> None:
        self.call_after_refresh(self._refresh_active_row_styles)

    def watch_active_index(self, _: int) -> None:
        if self.is_mounted:
            self.call_after_refresh(self._refresh_active_row_styles)

    def action_cursor_down(self) -> None:
        """Move the active field down while navigating the form."""

        if not self.editing:
            self._move_active_field(1)

    def action_cursor_up(self) -> None:
        """Move the active field up while navigating the form."""

        if not self.editing:
            self._move_active_field(-1)

    def action_edit_active_field(self) -> None:
        """Focus the currently selected control for editing."""

        if self.editing:
            return

        active_control = self._active_control()
        self.editing = True
        if isinstance(active_control, TicketFormSelect):
            active_control.begin_overlay_edit()
            return

        self.app.set_focus(active_control)

    def action_clear_active_field(self) -> None:
        """Clear the active select when it supports the delete shortcut."""

        if self.editing:
            return

        active_control = self._active_control()
        if not isinstance(active_control, TicketFormSelect):
            return
        self._clear_select(active_control)

    def build_patch(self) -> TicketEditPatch:
        """Return a sparse patch for the current form values."""

        return TicketEditPatch.from_form_values(
            self._ticket,
            title=self.query_one("#ticket-name-input", TicketFormInput).value,
            stage=self._selected_stage(),
            priority=self._selected_priority(),
            category_name=self._selected_category_name(),
            category_title=self._selected_category_title(),
            status_name=self._selected_status_name(),
            status_title=self._selected_status_title(),
            reopen=self.query_one("#ticket-reopen-input", TicketFormInput).value,
            user_name=self._selected_user_name(),
            user_title=self._selected_user_title(),
            description=self.query_one("#ticket-description-input", TicketFormTextArea).text,
        )

    def selected_stage(self) -> TicketStage:
        """Return the currently selected ticket stage."""

        return self._selected_stage()

    def set_selected_stage(self, stage: TicketStage) -> None:
        """Update the stage select to the provided ticket stage."""

        self._refresh_stage_select(stage.value)

    def has_unsaved_changes(self) -> bool:
        """Return whether the form differs from the last saved ticket snapshot."""

        current_title = self.query_one("#ticket-name-input", TicketFormInput).value
        normalized_title = current_title.strip()
        if normalized_title:
            title_changed = normalized_title != self._ticket.title
        else:
            title_changed = current_title != self._ticket.title

        current_description = self.query_one(
            "#ticket-description-input",
            TicketFormTextArea,
        ).text
        original_description = self._ticket.description or ""
        current_stage = self._selected_stage()
        current_priority = self._selected_priority()
        current_category_name = self._selected_category_name()
        current_category_title = self._selected_category_title()
        current_status_name = self._selected_status_name()
        current_status_title = self._selected_status_title()
        current_reopen = self.query_one("#ticket-reopen-input", TicketFormInput).value.strip()
        current_user_name = self._selected_user_name()
        original_category_name = self._ticket.category_name or self._ticket.category
        original_status_name = next(iter(self._ticket.statuses), None) if self._ticket.statuses else None
        original_status_title = (
            next(iter(self._ticket.statuses.values()), None) if self._ticket.statuses else None
        )
        original_reopen = format_editable_datetime(self._ticket.reopen)
        original_user_name = self._ticket.user_name or self._ticket.user
        stage_changed = current_stage is not self._ticket.stage
        priority_changed = current_priority is not self._ticket.priority
        category_changed = (
            current_category_name != original_category_name
            or current_category_title != self._ticket.category
        )
        status_changed = (
            current_status_name != original_status_name
            or current_status_title != original_status_title
        )
        reopen_changed = current_reopen != original_reopen
        user_changed = current_user_name != original_user_name
        return (
            title_changed
            or stage_changed
            or priority_changed
            or category_changed
            or status_changed
            or reopen_changed
            or user_changed
            or current_description != original_description
        )

    def sync_ticket(self, ticket: Ticket) -> None:
        """Replace the form contents with the saved ticket values."""

        self._ticket = ticket
        self._observed_category_name = self._selected_category_name_fallback()
        self._pending_reloaded_status_name = None
        self.query_one("#ticket-name-input", TicketFormInput).value = ticket.title
        self._refresh_stage_select(self._selected_stage_value_fallback())
        self._refresh_priority_select(self._selected_priority_value_fallback())
        self._refresh_category_select(self._selected_category_name_fallback())
        self._refresh_user_select(self._selected_user_value_fallback())
        self._refresh_status_select(self._selected_status_value_fallback())
        self.query_one("#ticket-reopen-input", TicketFormInput).value = format_editable_datetime(
            ticket.reopen
        )
        self.query_one(
            "#ticket-description-input",
            TicketFormTextArea,
        ).load_text(ticket.description or "")
        self.editing = False
        self.app.set_focus(self)
        self.call_after_refresh(self._refresh_active_row_styles)

    def set_ticket_categories(self, category_options: list[TicketCategoryOption]) -> None:
        """Update the selectable ticket category options."""

        self._category_options = list(category_options)
        self._refresh_category_select(self._selected_category_name())

    def set_ticket_statuses(
        self,
        category_name: str,
        status_options: list[TicketStatusOption],
    ) -> None:
        """Update selectable status options for the given category."""

        self._status_options = list(status_options)
        self._status_options_category_name = category_name
        if self._selected_category_name() != category_name:
            return

        current_status_name = self._selected_status_name()
        next_status_value = (
            current_status_name
            if current_status_name is not None
            and any(option.name == current_status_name for option in status_options)
            else self._pending_reloaded_status_name
            if self._pending_reloaded_status_name is not None
            and any(option.name == self._pending_reloaded_status_name for option in status_options)
            else NO_STATUS_VALUE
        )
        self._pending_reloaded_status_name = None
        self._refresh_status_select(next_status_value)

    def set_ticket_users(self, user_options: list[TicketUserOption]) -> None:
        """Update the selectable ticket user options."""

        self._user_options = list(user_options)
        self._refresh_user_select(self._selected_user_value())

    def assign_user(self, user_option: TicketUserOption) -> None:
        """Assign the provided user option without opening the select overlay."""

        if not any(option.name == user_option.name for option in self._user_options):
            self._user_options.append(user_option)
        self._refresh_user_select(user_option.name)

    def resolve_assignable_user(
        self,
        *,
        user_name: str | None,
        user_title: str | None,
    ) -> TicketUserOption | None:
        """Resolve a safe assignable user option from activity actor metadata."""

        if user_name is not None:
            for option in self._user_options:
                if option.name == user_name:
                    return option

        if user_title is None:
            return None

        title_matches = [option for option in self._user_options if option.title == user_title]
        if len(title_matches) == 1:
            return title_matches[0]
        return None

    def on_edit_stopped(self, message: EditStopped) -> None:
        """Return focus to the form when a control exits edit mode."""

        if message.control not in self._controls():
            return

        message.stop()
        self.editing = False
        self.app.set_focus(self)
        self.call_after_refresh(self._refresh_active_row_styles)

    def on_input_submitted(self, message: Input.Submitted) -> None:
        """Leave title editing when Enter submits the input."""

        if message.input not in (
            self.query_one("#ticket-name-input", TicketFormInput),
            self.query_one("#ticket-reopen-input", TicketFormInput),
        ):
            return

        self.editing = False
        self.app.set_focus(self)
        self.call_after_refresh(self._refresh_active_row_styles)

    def on_select_changed(self, message: Select.Changed) -> None:
        """Reload status options when the selected category changes."""

        if message.select is not self.query_one("#ticket-category-input", TicketFormSelect):
            return

        category_name = self._selected_category_name()
        if category_name == self._observed_category_name:
            return

        self._pending_reloaded_status_name = self._selected_status_name()
        self._observed_category_name = category_name
        self._status_options = []
        self._status_options_category_name = category_name
        self._refresh_status_select(NO_STATUS_VALUE)
        self.post_message(self.StatusOptionsRequested(self, category_name))

    def stop_editing_for_external_focus_change(self) -> None:
        """Clear any active edit session before focus leaves the form pane."""

        if not self.editing:
            return

        self.editing = False
        active_control = self._active_control()
        if isinstance(active_control, TicketFormSelect):
            active_control.cancel_overlay_edit()

    def _move_active_field(self, delta: int) -> None:
        field_count = len(self._controls())
        self.active_index = min(max(self.active_index + delta, 0), field_count - 1)

    def _clear_select(self, control: TicketFormSelect) -> None:
        if not control.is_clearable:
            return
        control.clear_selection()

    def _controls(self) -> list[Widget]:
        return [
            self.query_one("#ticket-name-input", TicketFormInput),
            self.query_one("#ticket-stage-input", TicketFormSelect),
            self.query_one("#ticket-priority-input", TicketFormSelect),
            self.query_one("#ticket-category-input", TicketFormSelect),
            self.query_one("#ticket-user-input", TicketFormSelect),
            self.query_one("#ticket-status-input", TicketFormSelect),
            self.query_one("#ticket-reopen-input", TicketFormInput),
            self.query_one("#ticket-description-input", TicketFormTextArea),
        ]

    def _rows(self) -> list[TicketFormRow]:
        return [
            self.query_one("#ticket-name-row", TicketFormRow),
            self.query_one("#ticket-stage-row", TicketFormRow),
            self.query_one("#ticket-priority-row", TicketFormRow),
            self.query_one("#ticket-category-row", TicketFormRow),
            self.query_one("#ticket-user-row", TicketFormRow),
            self.query_one("#ticket-status-row", TicketFormRow),
            self.query_one("#ticket-reopen-row", TicketFormRow),
            self.query_one("#ticket-description-row", TicketFormRow),
        ]

    def _active_control(self) -> Widget:
        return self._controls()[self.active_index]

    def _refresh_active_row_styles(self) -> None:
        for index, row in enumerate(self._rows()):
            row.set_class(index == self.active_index, "-active")

    def _custom_field_display_rows(self) -> list[TicketCustomFieldDisplay]:
        return [
            TicketCustomFieldDisplay(label=field.title, value=rendered_value)
            for field in self._ticket.customFields or []
            if (rendered_value := self._render_custom_field_value(field)) is not None
        ]

    def _render_custom_field_value(self, field: TicketCustomField) -> str | None:
        rendered_values = [
            rendered_value
            for value in field.values
            if (rendered_value := self._render_custom_field_single_value(field, value)) is not None
        ]
        if not rendered_values:
            return None
        return ", ".join(rendered_values)

    def _render_custom_field_single_value(
        self,
        field: TicketCustomField,
        value: object,
    ) -> str | None:
        option_title = self._custom_field_option_title(field, value)
        if option_title is not None:
            return option_title
        if value is None:
            return None
        if isinstance(value, str):
            normalized = value.strip()
            return normalized or None
        normalized = str(value).strip()
        return normalized or None

    @staticmethod
    def _custom_field_option_title(
        field: TicketCustomField,
        value: object,
    ) -> str | None:
        for option in field.options or []:
            if option.value != value:
                continue
            normalized = option.title.strip()
            if normalized:
                return normalized
        return None

    def _category_select_options(self, selected_name: str | None = None) -> list[tuple[str, str]]:
        options = list(self._category_options)
        category_name = selected_name or self._selected_category_name_fallback()
        if not any(option.name == category_name for option in options):
            options.insert(
                0,
                TicketCategoryOption(
                    name=category_name,
                    title=self._category_title_for_name(category_name),
                ),
            )
        return [(option.title, option.name) for option in options]

    def _user_select_options(self, selected_value: str | None = None) -> list[tuple[str, str]]:
        options = list(self._user_options)
        user_value = selected_value or self._selected_user_value_fallback()
        if user_value != UNASSIGNED_USER_VALUE and not any(option.name == user_value for option in options):
            options.insert(
                0,
                TicketUserOption(
                    name=user_value,
                    title=self._user_title_for_name(user_value),
                ),
            )

        rendered_options = [("Unassigned", UNASSIGNED_USER_VALUE)]
        rendered_options.extend((option.title, option.name) for option in options)
        return rendered_options

    def _status_select_options(self, selected_value: str | None = None) -> list[tuple[str, str]]:
        options = list(self._status_options)
        status_value = selected_value or self._selected_status_value_fallback()
        if status_value != NO_STATUS_VALUE and not any(option.name == status_value for option in options):
            options.insert(
                0,
                TicketStatusOption(
                    name=status_value,
                    title=self._status_title_for_name(status_value),
                ),
            )

        rendered_options = [("No status", NO_STATUS_VALUE)]
        rendered_options.extend((option.title, option.name) for option in options)
        return rendered_options

    def _stage_select_options(self) -> list[tuple[str, str]]:
        return [
            (stage.display_label, stage.value)
            for stage in TicketStage
        ]

    def _priority_select_options(self) -> list[tuple[str, str]]:
        return [
            (priority.display_label, priority.value)
            for priority in (
                TicketPriority.HIGH,
                TicketPriority.MEDIUM,
                TicketPriority.LOW,
            )
        ]

    def _selected_stage_value_fallback(self) -> str:
        return self._ticket.stage.value

    def _selected_stage(self) -> TicketStage:
        stage_select = self.query_one("#ticket-stage-input", TicketFormSelect)
        if stage_select.value == Select.NULL:
            return self._ticket.stage
        return TicketStage(str(stage_select.value))

    def _selected_priority_value_fallback(self) -> str:
        return self._ticket.priority.value

    def _selected_priority(self) -> TicketPriority:
        priority_select = self.query_one("#ticket-priority-input", TicketFormSelect)
        if priority_select.value == Select.NULL:
            return self._ticket.priority
        return TicketPriority(str(priority_select.value))

    def _selected_category_name_fallback(self) -> str:
        return self._ticket.category_name or self._ticket.category

    def _selected_category_name(self) -> str:
        category_select = self.query_one("#ticket-category-input", TicketFormSelect)
        if category_select.value == Select.NULL:
            return self._selected_category_name_fallback()
        return str(category_select.value)

    def _selected_category_title(self) -> str:
        return self._category_title_for_name(self._selected_category_name())

    def _selected_user_value_fallback(self) -> str:
        if self._ticket.user_name is not None:
            return self._ticket.user_name
        if self._ticket.user is not None:
            return self._ticket.user
        return UNASSIGNED_USER_VALUE

    def _selected_status_value_fallback(self) -> str:
        if self._ticket.statuses:
            return next(iter(self._ticket.statuses))
        return NO_STATUS_VALUE

    def _selected_user_value(self) -> str:
        user_select = self.query_one("#ticket-user-input", TicketFormSelect)
        if user_select.value == Select.NULL:
            return self._selected_user_value_fallback()
        return str(user_select.value)

    def _selected_user_name(self) -> str | None:
        selected_value = self._selected_user_value()
        if selected_value == UNASSIGNED_USER_VALUE:
            return None
        return selected_value

    def _selected_status_value(self) -> str:
        status_select = self.query_one("#ticket-status-input", TicketFormSelect)
        if status_select.value == Select.NULL:
            return self._selected_status_value_fallback()
        return str(status_select.value)

    def _selected_status_name(self) -> str | None:
        selected_value = self._selected_status_value()
        if selected_value == NO_STATUS_VALUE:
            return None
        return selected_value

    def _selected_status_title(self) -> str | None:
        selected_name = self._selected_status_name()
        if selected_name is None:
            return None
        return self._status_title_for_name(selected_name)

    def _selected_user_title(self) -> str | None:
        selected_name = self._selected_user_name()
        if selected_name is None:
            return None
        return self._user_title_for_name(selected_name)

    def _category_title_for_name(self, category_name: str) -> str:
        for option in self._category_options:
            if option.name == category_name:
                return option.title
        if category_name == (self._ticket.category_name or self._ticket.category):
            return self._ticket.category
        return category_name

    def _user_title_for_name(self, user_name: str) -> str:
        for option in self._user_options:
            if option.name == user_name:
                return option.title
        if user_name == (self._ticket.user_name or self._ticket.user):
            return self._ticket.user or user_name
        return user_name

    def _status_title_for_name(self, status_name: str) -> str:
        for option in self._status_options:
            if option.name == status_name:
                return option.title
        if self._ticket.statuses and status_name in self._ticket.statuses:
            return self._ticket.statuses[status_name]
        return status_name

    def _refresh_category_select(self, selected_name: str) -> None:
        category_select = self.query_one("#ticket-category-input", TicketFormSelect)
        category_select.set_options(self._category_select_options(selected_name))
        category_select.value = selected_name

    def _refresh_priority_select(self, selected_value: str) -> None:
        priority_select = self.query_one("#ticket-priority-input", TicketFormSelect)
        priority_select.set_options(self._priority_select_options())
        priority_select.value = selected_value

    def _refresh_user_select(self, selected_value: str) -> None:
        user_select = self.query_one("#ticket-user-input", TicketFormSelect)
        user_select.set_options(self._user_select_options(selected_value))
        user_select.value = selected_value

    def _refresh_status_select(self, selected_value: str) -> None:
        status_select = self.query_one("#ticket-status-input", TicketFormSelect)
        status_select.set_options(self._status_select_options(selected_value))
        status_select.value = selected_value

    def _refresh_stage_select(self, selected_value: str) -> None:
        stage_select = self.query_one("#ticket-stage-input", TicketFormSelect)
        stage_select.set_options(self._stage_select_options())
        stage_select.value = selected_value
