"""Inline email composer for ticket detail."""

from __future__ import annotations

from typing import Literal

from textual import events
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.message import Message
from textual.widgets import Button, Input, Static, TextArea

from daktela_paleo.models import TicketEmailAction, TicketEmailDraft, TicketEmailSendRequest
from daktela_paleo.screens.ticket_detail.widgets.comment_reply import (
    ExternalEditorError,
    _edit_draft_in_external_editor,
)


class EmailComposeInput(Input):
    """Single-line email field with local submit and cancel shortcuts."""

    BINDINGS = [
        *Input.BINDINGS,
        Binding("ctrl+s", "submit_email", "Send email", show=False, priority=True),
        Binding("ctrl+e", "edit_in_external_editor", "External Editor", show=False, priority=True),
        Binding("escape", "cancel_email", "Cancel email", show=False, priority=True),
    ]

    def action_submit_email(self) -> None:
        parent = self.parent
        if isinstance(parent, TicketEmailComposer):
            parent.action_submit()

    def action_cancel_email(self) -> None:
        parent = self.parent
        if isinstance(parent, TicketEmailComposer):
            parent.action_cancel()

    def action_edit_in_external_editor(self) -> None:
        parent = self.parent
        if isinstance(parent, TicketEmailComposer):
            parent.action_edit_in_external_editor()


class EmailComposeTextArea(TextArea):
    """Body editor with local submit and cancel shortcuts."""

    BINDINGS = [
        *TextArea.BINDINGS,
        Binding("ctrl+s", "submit_email", "Send email", show=False, priority=True),
        Binding("ctrl+e", "edit_in_external_editor", "External Editor", show=False, priority=True),
        Binding("escape", "cancel_email", "Cancel email", show=False, priority=True),
    ]

    def action_submit_email(self) -> None:
        parent = self.parent
        if isinstance(parent, TicketEmailComposer):
            parent.action_submit()

    def action_cancel_email(self) -> None:
        parent = self.parent
        if isinstance(parent, TicketEmailComposer):
            parent.action_cancel()

    def action_edit_in_external_editor(self) -> None:
        parent = self.parent
        if isinstance(parent, TicketEmailComposer):
            parent.action_edit_in_external_editor()


class TicketEmailComposer(Vertical):
    """Inline email composer that keeps ticket activity context visible."""

    class Submitted(Message):
        """Posted when the composer has validated an email send request."""

        def __init__(
            self,
            composer: TicketEmailComposer,
            request: TicketEmailSendRequest,
        ) -> None:
            super().__init__()
            self.composer = composer
            self.request = request

        @property
        def control(self) -> TicketEmailComposer:
            return self.composer

    class Cancelled(Message):
        """Posted when the composer should close without sending."""

        def __init__(self, composer: TicketEmailComposer) -> None:
            super().__init__()
            self.composer = composer

        @property
        def control(self) -> TicketEmailComposer:
            return self.composer

    DEFAULT_CSS = """
    TicketEmailComposer {
        display: none;
        width: 1fr;
        height: auto;
        margin: 1 1 0 1;
        padding: 0 1;
        border: round $border;
        background: $surface;
    }

    TicketEmailComposer.-open {
        display: block;
    }

    #email-reply-title {
        height: auto;
        color: $text;
        text-style: bold;
    }

    .email-reply-label {
        height: auto;
        margin-top: 1;
        color: $text-muted;
    }

    .email-reply-label.-first {
        margin-top: 0;
    }

    .email-reply-input {
        width: 1fr;
        margin: 0;
    }

    #email-reply-body {
        width: 1fr;
        height: 10;
        margin: 0;
        padding: 0;
        border: round $border-blurred;
    }

    #email-reply-body:focus,
    .email-reply-input:focus {
        border: round $accent;
    }

    #email-reply-validation {
        display: none;
        height: auto;
        min-height: 1;
        margin-top: 1;
        color: $error;
    }

    #email-reply-actions {
        width: 1fr;
        height: auto;
        margin-top: 0;
    }

    .email-reply-action {
        min-width: 0;
        margin-right: 1;
    }

    #email-reply-hint {
        height: auto;
        margin-top: 1;
        color: $text-muted;
    }
    """

    def __init__(
        self,
        *,
        id: str | None = None,
        classes: str | None = None,
    ) -> None:
        super().__init__(id=id, classes=classes)
        self._is_open = False
        self._is_submitting = False
        self._action: TicketEmailAction | None = None
        self._source_activity_name: str | None = None
        self._source_email_name: str | None = None
        self._queue_name: str | None = None
        self._focused_field: Literal["to", "subject", "body"] = "body"

    @property
    def is_open(self) -> bool:
        """Return whether the composer is currently visible."""

        return self._is_open

    @property
    def action(self) -> TicketEmailAction | None:
        """Return the active email action."""

        return self._action

    @property
    def source_activity_name(self) -> str | None:
        """Return the selected activity this draft is based on."""

        return self._source_activity_name

    def compose(self) -> ComposeResult:
        yield Static("Reply to all email", id="email-reply-title")
        yield Static("To", id="email-reply-to-label", classes="email-reply-label -first")
        yield EmailComposeInput(id="email-reply-to", classes="email-reply-input")
        yield Static("Subject", id="email-reply-subject-label", classes="email-reply-label")
        yield EmailComposeInput(id="email-reply-subject", classes="email-reply-input")
        yield Static("Body", id="email-reply-body-label", classes="email-reply-label")
        yield EmailComposeTextArea(id="email-reply-body")
        yield Static("", id="email-reply-validation")
        with Horizontal(id="email-reply-actions"):
            yield Button(
                "Send (Ctrl+S)",
                id="email-reply-submit",
                classes="email-reply-action",
            )
            yield Button(
                "Cancel (Esc)",
                id="email-reply-cancel",
                classes="email-reply-action",
            )
        yield Static(
            "Selected activity stays visible while you compose. Ctrl+E opens $EDITOR. Enter inserts a newline.",
            id="email-reply-hint",
        )

    def on_key(self, event: events.Key) -> None:
        """Intercept composer shortcuts before they reach the screen."""

        if not self._is_open or not self.has_focus_within:
            return

        if event.key == "ctrl+s":
            event.stop()
            self.action_submit()
            return

        if event.key == "ctrl+e":
            event.stop()
            self.action_edit_in_external_editor()
            return

        if event.key == "escape":
            event.stop()
            self.action_cancel()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Route button presses to the matching composer actions."""

        if event.button.id == "email-reply-submit":
            event.stop()
            self.action_submit()
            return

        if event.button.id == "email-reply-cancel":
            event.stop()
            self.action_cancel()

    def open_draft(self, draft: TicketEmailDraft) -> None:
        """Show the composer for the given email draft."""

        self._is_open = True
        self._is_submitting = False
        self._action = draft.action
        self._source_activity_name = draft.source_activity_name
        self._source_email_name = draft.source_email_name
        self._queue_name = draft.queue_name
        self._focused_field = "body" if draft.action is TicketEmailAction.REPLY else "to"
        self.set_class(True, "-open")
        self._update_mode_labels()
        self.query_one("#email-reply-to", Input).value = draft.to
        self.query_one("#email-reply-subject", Input).value = draft.subject
        self.query_one("#email-reply-body", TextArea).load_text(draft.body)
        self.show_validation("")
        self._set_submitting(False)
        self.focus_editor()

    def close(self) -> None:
        """Hide the composer and clear its transient state."""

        self._is_open = False
        self._is_submitting = False
        self._action = None
        self._source_activity_name = None
        self._source_email_name = None
        self._queue_name = None
        self._focused_field = "body"
        self.set_class(False, "-open")
        self.query_one("#email-reply-to", Input).value = ""
        self.query_one("#email-reply-subject", Input).value = ""
        self.query_one("#email-reply-body", TextArea).load_text("")
        self._update_mode_labels()
        self.show_validation("")
        self._set_submitting(False)

    def focus_editor(self) -> None:
        """Focus the active editor field."""

        if not self._is_open:
            return

        selector = {
            "to": "#email-reply-to",
            "subject": "#email-reply-subject",
            "body": "#email-reply-body",
        }[self._focused_field]
        self.call_after_refresh(lambda: self.query_one(selector).focus())

    def show_validation(self, message: str) -> None:
        """Update the inline validation or submit error message."""

        validation = self.query_one("#email-reply-validation", Static)
        validation.update(message)
        validation.display = bool(message)

    def set_submission_pending(self, pending: bool) -> None:
        """Update submit controls while a send request is in flight."""

        self._is_submitting = pending
        self._set_submitting(pending)

    def draft_to(self) -> str:
        """Return the current recipient field contents."""

        return self.query_one("#email-reply-to", Input).value

    def draft_subject(self) -> str:
        """Return the current subject field contents."""

        return self.query_one("#email-reply-subject", Input).value

    def draft_body(self) -> str:
        """Return the current body editor contents."""

        return self.query_one("#email-reply-body", TextArea).text

    def action_submit(self) -> None:
        """Validate and emit the email send request."""

        if not self._is_open or self._is_submitting:
            return

        to = self.draft_to().strip()
        subject = self.draft_subject().strip()
        body = self.draft_body().strip()
        if not to:
            self.show_validation("Recipient list can't be blank.")
            self._focused_field = "to"
            self.focus_editor()
            return

        if self._action is None or self._source_email_name is None or self._queue_name is None:
            self.show_validation("Email draft is not ready yet.")
            self.focus_editor()
            return

        self._capture_focused_field()
        self.show_validation("")
        self.post_message(
            self.Submitted(
                self,
                TicketEmailSendRequest(
                    action=self._action,
                    source_email_name=self._source_email_name,
                    to=to,
                    subject=subject,
                    body=body,
                    queue_name=self._queue_name,
                ),
            )
        )

    def action_cancel(self) -> None:
        """Emit a cancel request for the owning screen."""

        if not self._is_open or self._is_submitting:
            return

        self.post_message(self.Cancelled(self))

    def action_edit_in_external_editor(self) -> None:
        """Round-trip the email body through the configured terminal editor."""

        if not self._is_open or self._is_submitting:
            return

        self.show_validation("")
        try:
            updated_body = self._edit_draft_in_external_editor(self.draft_body())
        except ExternalEditorError as error:
            self.show_validation(str(error))
            self._focused_field = "body"
            self.focus_editor()
            return

        self.query_one("#email-reply-body", TextArea).load_text(updated_body)
        self._focused_field = "body"
        self.focus_editor()

    def _capture_focused_field(self) -> None:
        focused_id = getattr(self.app.focused, "id", None)
        if focused_id == "email-reply-to":
            self._focused_field = "to"
        elif focused_id == "email-reply-subject":
            self._focused_field = "subject"
        elif focused_id == "email-reply-body":
            self._focused_field = "body"

    def _set_submitting(self, pending: bool) -> None:
        to_input = self.query_one("#email-reply-to", Input)
        subject_input = self.query_one("#email-reply-subject", Input)
        body_input = self.query_one("#email-reply-body", TextArea)
        submit_button = self.query_one("#email-reply-submit", Button)
        cancel_button = self.query_one("#email-reply-cancel", Button)
        to_input.disabled = pending
        subject_input.disabled = pending
        body_input.read_only = pending
        submit_button.disabled = pending
        cancel_button.disabled = pending

    def _edit_draft_in_external_editor(self, draft: str) -> str:
        """Delegate to the shared external-editor helper."""

        return _edit_draft_in_external_editor(self.app, draft)

    def _update_mode_labels(self) -> None:
        title = (
            "Forward email"
            if self._action is TicketEmailAction.FORWARD
            else "Reply to all email"
        )
        hint = (
            "Forward keeps the selected activity visible while you compose. Ctrl+E opens $EDITOR. Enter inserts a newline."
            if self._action is TicketEmailAction.FORWARD
            else "Reply target stays locked while this draft is open. Ctrl+E opens $EDITOR. Enter inserts a newline."
        )
        self.query_one("#email-reply-title", Static).update(title)
        self.query_one("#email-reply-hint", Static).update(hint)
