"""Widgets used only by the ticket detail screen."""
