"""Ticket detail widgets for modal screens."""

from __future__ import annotations

from pathlib import Path
from typing import Literal

from textual import events
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.message import Message
from textual.screen import ModalScreen
from textual.widgets import Input, ListItem, ListView, Static

from daktela_paleo.screens.ticket_detail.widgets.detail_pane import ActivityLink


class UnsavedChangesModal(ModalScreen[Literal["save", "discard", "cancel"]]):
    """Confirm whether dirty ticket edits should be saved or discarded."""

    BINDINGS = [
        Binding("s", "save", "Save & Close", show=False, priority=True),
        Binding("c", "discard", "Close Without Saving", show=False, priority=True),
        Binding("escape,q", "cancel", "Cancel", show=False, priority=True),
    ]
    DEFAULT_CSS = """
    UnsavedChangesModal {
        align: center middle;
        background: $background 60%;
    }

    #unsaved-changes-dialog {
        width: 44;
        height: auto;
        padding: 1;
        border: round $border;
        background: $surface;
    }

    #unsaved-changes-title {
        height: auto;
        color: $text;
        text-style: bold;
    }

    .unsaved-changes-option {
        height: auto;
        margin-top: 0;
        padding: 0 1;
        background: transparent;
        color: $text;
    }
    """

    _ACTIONS: tuple[tuple[str, str, str], ...] = (
        ("save", "[b]\\[s][/b] Save and close", ""),
        ("discard", "[b]\\[c][/b] Close without saving", ""),
        ("cancel", "Stay here [dim]Esc/q[/dim]", ""),
    )

    def compose(self) -> ComposeResult:
        with Vertical(id="unsaved-changes-dialog"):
            yield Static("Unsaved changes", id="unsaved-changes-title")
            for action_name, label, _ in self._ACTIONS:
                yield Static(
                    label,
                    id=f"unsaved-changes-option-{action_name}",
                    classes="unsaved-changes-option",
                )

    def on_key(self, event: events.Key) -> None:
        """Handle direct action keys without leaking to app-level bindings."""

        if event.key == "s":
            event.stop()
            self.action_save()
            return

        if event.key == "c":
            event.stop()
            self.action_discard()
            return

        if event.key in {"escape", "q"}:
            event.stop()
            self.action_cancel()

    def on_click(self, event: events.Click) -> None:
        """Allow modal actions to be triggered with the mouse."""

        if event.widget is self.query_one("#unsaved-changes-option-save", Static):
            event.stop()
            self.action_save()
            return

        if event.widget is self.query_one("#unsaved-changes-option-discard", Static):
            event.stop()
            self.action_discard()
            return

        if event.widget is self.query_one("#unsaved-changes-option-cancel", Static):
            event.stop()
            self.action_cancel()

    def action_save(self) -> None:
        """Persist changes, then close the detail screen."""

        self.dismiss("save")

    def action_discard(self) -> None:
        """Discard changes and close the detail screen."""

        self.dismiss("discard")

    def action_cancel(self) -> None:
        """Keep editing the current ticket."""

        self.dismiss("cancel")


class ActivityLinkListItem(ListItem):
    """List item that keeps the discovered activity link attached."""

    def __init__(self, link: ActivityLink) -> None:
        self.link = link
        self.display_label = link.display_label
        super().__init__(
            Vertical(
                Static(self.display_label, classes="activity-link-picker-url"),
                classes="activity-link-picker-entry",
            )
        )


class ActivityLinkList(ListView):
    """List view with vi-style navigation for discovered activity links."""

    class LinkActivated(Message):
        """Posted when a discovered link is selected."""

        def __init__(self, activity_link_list: ActivityLinkList, link: ActivityLink) -> None:
            super().__init__()
            self.activity_link_list = activity_link_list
            self.link = link

        @property
        def control(self) -> ActivityLinkList:
            return self.activity_link_list

    BINDINGS = [
        *ListView.BINDINGS,
        Binding("j,down", "cursor_down", "Down", show=False),
        Binding("k,up", "cursor_up", "Up", show=False),
        Binding("l,right", "activate", "Open", show=False),
    ]

    def __init__(self, links: list[ActivityLink], *, id: str | None = None) -> None:
        self._links = list(links)
        super().__init__(
            *(ActivityLinkListItem(link) for link in self._links),
            initial_index=0 if self._links else None,
            id=id,
        )

    def action_activate(self) -> None:
        """Open the currently highlighted link."""

        self.action_select_cursor()

    @property
    def selected_link(self) -> ActivityLink | None:
        """Return the currently highlighted discovered link."""

        if not isinstance(self.highlighted_child, ActivityLinkListItem):
            return None
        return self.highlighted_child.link

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Translate the generic selection event into a typed link event."""

        if event.list_view is not self:
            return

        if isinstance(event.item, ActivityLinkListItem):
            self.post_message(self.LinkActivated(self, event.item.link))


class ActivityLinkPickerModal(ModalScreen[ActivityLink | None]):
    """Show discovered ticket-activity links in a compact keyboard picker."""

    BINDINGS = [
        Binding("enter", "activate", "Open", show=False, priority=True),
        Binding("y", "copy_link", "Copy", show=False, priority=True),
        Binding("escape,q", "cancel", "Close", show=False, priority=True),
    ]
    DEFAULT_CSS = """
    ActivityLinkPickerModal {
        align: center middle;
        background: $background 60%;
    }

    #activity-link-picker-dialog {
        width: 96;
        height: auto;
        max-height: 24;
        padding: 1;
        border: round $border;
        background: $surface;
    }

    #activity-link-picker-title {
        height: auto;
        color: $text;
        text-style: bold;
    }

    #activity-link-picker-subtitle {
        height: auto;
        margin-top: 1;
        color: $text-muted;
    }

    #activity-link-picker-list {
        width: 1fr;
        height: auto;
        min-height: 8;
        max-height: 16;
        margin-top: 1;
        border: round $border-blurred;
    }

    #activity-link-picker-status {
        height: auto;
        margin-top: 1;
        color: $text-muted;
    }

    .activity-link-picker-entry {
        width: 1fr;
        height: auto;
        padding: 0 1;
    }

    .activity-link-picker-url {
        height: auto;
        color: $accent;
        text-style: bold;
    }

    #activity-link-picker-hint {
        height: auto;
        margin-top: 1;
        color: $text-muted;
    }
    """

    def __init__(self, links: list[ActivityLink]) -> None:
        super().__init__()
        self._links = list(links)

    def compose(self) -> ComposeResult:
        with Vertical(id="activity-link-picker-dialog"):
            yield Static("Open Activity Link", id="activity-link-picker-title")
            yield Static(
                "Choose a discovered URL from the current ticket activities.",
                id="activity-link-picker-subtitle",
            )
            yield ActivityLinkList(self._links, id="activity-link-picker-list")
            yield Static("", id="activity-link-picker-status")
            yield Static(
                "Use j/k or arrows to move, Enter/l to open, y to copy, Esc/q to close.",
                id="activity-link-picker-hint",
            )

    def on_mount(self) -> None:
        self.query_one("#activity-link-picker-list", ActivityLinkList).focus()

    def on_key(self, event: events.Key) -> None:
        """Prevent picker shortcuts from leaking into the underlying detail screen."""

        if event.key == "enter":
            event.stop()
            self.action_activate()
            return

        if event.key == "y":
            event.stop()
            self.action_copy_link()
            return

        if event.key in {"escape", "q"}:
            event.stop()
            self.action_cancel()

    def on_activity_link_list_link_activated(
        self,
        message: ActivityLinkList.LinkActivated,
    ) -> None:
        """Dismiss the picker with the selected link."""

        message.stop()
        self.dismiss(message.link)

    def action_activate(self) -> None:
        """Open the currently highlighted link."""

        self.query_one("#activity-link-picker-list", ActivityLinkList).action_activate()

    def action_copy_link(self) -> None:
        """Copy the currently highlighted link to the terminal clipboard."""

        selected_link = self.query_one("#activity-link-picker-list", ActivityLinkList).selected_link
        if selected_link is None:
            return

        self.app.copy_to_clipboard(selected_link.url)
        self.query_one("#activity-link-picker-status", Static).update("Copied link to clipboard.")

    def action_cancel(self) -> None:
        """Dismiss the picker without opening a link."""

        self.dismiss(None)


class CommentAttachmentListItem(ListItem):
    """List item that keeps the staged attachment path attached."""

    def __init__(self, path: Path) -> None:
        self.path = path
        super().__init__(
            Vertical(
                Static(path.name, classes="comment-attachment-picker-name"),
                Static(str(path), classes="comment-attachment-picker-path"),
                classes="comment-attachment-picker-entry",
            )
        )


class CommentAttachmentList(ListView):
    """List view with vi-style navigation for staged comment attachments."""

    class AttachmentActivated(Message):
        """Posted when a staged attachment path is selected."""

        def __init__(self, attachment_list: CommentAttachmentList, path: Path) -> None:
            super().__init__()
            self.attachment_list = attachment_list
            self.path = path

        @property
        def control(self) -> CommentAttachmentList:
            return self.attachment_list

    BINDINGS = [
        *ListView.BINDINGS,
        Binding("j,down", "cursor_down", "Down", show=False),
        Binding("k,up", "cursor_up", "Up", show=False),
        Binding("l,right", "activate", "Select", show=False),
    ]

    def __init__(self, paths: list[Path], *, id: str | None = None) -> None:
        self._paths = list(paths)
        super().__init__(
            *(CommentAttachmentListItem(path) for path in self._paths),
            initial_index=0 if self._paths else None,
            id=id,
        )

    def action_activate(self) -> None:
        """Choose the currently highlighted staged attachment."""

        self.action_select_cursor()

    @property
    def selected_path(self) -> Path | None:
        """Return the currently highlighted staged attachment path."""

        if not isinstance(self.highlighted_child, CommentAttachmentListItem):
            return None
        return self.highlighted_child.path

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Translate the generic selection event into a typed attachment event."""

        if event.list_view is not self:
            return

        if isinstance(event.item, CommentAttachmentListItem):
            self.post_message(self.AttachmentActivated(self, event.item.path))


class CommentAttachmentPathPickerModal(ModalScreen[Path | None]):
    """Prompt for the local file path to stage for a comment."""

    BINDINGS = [
        Binding("escape,q", "cancel", "Close", show=False, priority=True),
    ]
    DEFAULT_CSS = """
    CommentAttachmentPathPickerModal {
        align: center middle;
        background: $background 60%;
    }

    #comment-attachment-path-picker-dialog {
        width: 88;
        height: auto;
        padding: 1;
        border: round $border;
        background: $surface;
    }

    #comment-attachment-path-picker-title {
        height: auto;
        color: $text;
        text-style: bold;
    }

    #comment-attachment-path-picker-subtitle {
        height: auto;
        margin-top: 1;
        color: $text-muted;
    }

    #comment-attachment-path-picker-input {
        width: 1fr;
        height: 3;
        margin-top: 1;
        border: round $border-blurred;
    }

    #comment-attachment-path-picker-status {
        height: auto;
        margin-top: 1;
        color: $text-muted;
    }

    #comment-attachment-path-picker-hint {
        height: auto;
        margin-top: 1;
        color: $text-muted;
    }
    """

    def __init__(self, initial_path: str = "") -> None:
        super().__init__()
        self._initial_path = initial_path

    def compose(self) -> ComposeResult:
        with Vertical(id="comment-attachment-path-picker-dialog"):
            yield Static("Attach File", id="comment-attachment-path-picker-title")
            yield Static(
                "Enter the local file path to stage for this comment.",
                id="comment-attachment-path-picker-subtitle",
            )
            yield Input(
                value=self._initial_path,
                placeholder="~/Downloads/report.pdf",
                id="comment-attachment-path-picker-input",
            )
            yield Static("", id="comment-attachment-path-picker-status")
            yield Static(
                "Edit the path and press Enter to stage the file, or Esc/q to close.",
                id="comment-attachment-path-picker-hint",
            )

    def on_mount(self) -> None:
        self.query_one("#comment-attachment-path-picker-input", Input).focus()

    def on_key(self, event: events.Key) -> None:
        """Prevent picker shortcuts from leaking into the ticket detail screen."""

        if event.key in {"escape", "q"}:
            event.stop()
            self.action_cancel()

    def on_input_submitted(self, message: Input.Submitted) -> None:
        """Confirm the typed attachment path."""

        if message.input is self.query_one("#comment-attachment-path-picker-input", Input):
            self.action_activate()

    def action_activate(self) -> None:
        """Validate and stage the typed attachment path."""

        raw_path = self.query_one("#comment-attachment-path-picker-input", Input).value.strip()
        status = self.query_one("#comment-attachment-path-picker-status", Static)
        if not raw_path:
            status.update("Attachment path is required.")
            return

        candidate = Path(raw_path).expanduser()
        if not candidate.exists():
            status.update("Attachment path does not exist.")
            return
        if not candidate.is_file():
            status.update("Attachment path must point to a file.")
            return

        try:
            resolved = candidate.resolve(strict=True)
            with resolved.open("rb"):
                pass
        except OSError as error:
            status.update(f"Unable to read attachment path: {error}")
            return

        self.dismiss(resolved)

    def action_cancel(self) -> None:
        """Dismiss the picker without selecting a file."""

        self.dismiss(None)


class CommentAttachmentRemovalModal(ModalScreen[Path | None]):
    """Show staged comment attachments in a compact keyboard picker."""

    BINDINGS = [
        Binding("enter", "activate", "Remove", show=False, priority=True),
        Binding("escape,q", "cancel", "Close", show=False, priority=True),
    ]
    DEFAULT_CSS = """
    CommentAttachmentRemovalModal {
        align: center middle;
        background: $background 60%;
    }

    #comment-attachment-removal-dialog {
        width: 96;
        height: auto;
        max-height: 24;
        padding: 1;
        border: round $border;
        background: $surface;
    }

    #comment-attachment-removal-title {
        height: auto;
        color: $text;
        text-style: bold;
    }

    #comment-attachment-removal-subtitle {
        height: auto;
        margin-top: 1;
        color: $text-muted;
    }

    #comment-attachment-removal-list {
        width: 1fr;
        height: auto;
        min-height: 6;
        max-height: 16;
        margin-top: 1;
        border: round $border-blurred;
    }

    .comment-attachment-picker-entry {
        width: 1fr;
        height: auto;
        padding: 0 1;
    }

    .comment-attachment-picker-name {
        height: auto;
        color: $text;
        text-style: bold;
    }

    .comment-attachment-picker-path {
        height: auto;
        color: $text-muted;
    }

    #comment-attachment-removal-hint {
        height: auto;
        margin-top: 1;
        color: $text-muted;
    }
    """

    def __init__(self, paths: list[Path]) -> None:
        super().__init__()
        self._paths = list(paths)

    def compose(self) -> ComposeResult:
        with Vertical(id="comment-attachment-removal-dialog"):
            yield Static("Remove Attachment", id="comment-attachment-removal-title")
            yield Static(
                "Choose a staged file to remove from the current comment draft.",
                id="comment-attachment-removal-subtitle",
            )
            yield CommentAttachmentList(self._paths, id="comment-attachment-removal-list")
            yield Static(
                "Use j/k or arrows to move, Enter/l to remove, Esc/q to close.",
                id="comment-attachment-removal-hint",
            )

    def on_mount(self) -> None:
        self.query_one("#comment-attachment-removal-list", CommentAttachmentList).focus()

    def on_key(self, event: events.Key) -> None:
        """Prevent picker shortcuts from leaking into the ticket detail screen."""

        if event.key == "enter":
            event.stop()
            self.action_activate()
            return

        if event.key in {"escape", "q"}:
            event.stop()
            self.action_cancel()

    def on_comment_attachment_list_attachment_activated(
        self,
        message: CommentAttachmentList.AttachmentActivated,
    ) -> None:
        """Dismiss the picker with the selected staged file path."""

        message.stop()
        self.dismiss(message.path)

    def action_activate(self) -> None:
        """Remove the currently highlighted staged attachment."""

        self.query_one("#comment-attachment-removal-list", CommentAttachmentList).action_activate()

    def action_cancel(self) -> None:
        """Dismiss the picker without removing a file."""

        self.dismiss(None)


class AttachmentDestinationPickerModal(ModalScreen[Path | None]):
    """Prompt for the destination directory used by attachment downloads."""

    BINDINGS = [
        Binding("escape,q", "cancel", "Close", show=False, priority=True),
    ]
    DEFAULT_CSS = """
    AttachmentDestinationPickerModal {
        align: center middle;
        background: $background 60%;
    }

    #attachment-destination-picker-dialog {
        width: 88;
        height: auto;
        padding: 1;
        border: round $border;
        background: $surface;
    }

    #attachment-destination-picker-title {
        height: auto;
        color: $text;
        text-style: bold;
    }

    #attachment-destination-picker-subtitle {
        height: auto;
        margin-top: 1;
        color: $text-muted;
    }

    #attachment-destination-picker-input {
        width: 1fr;
        height: 3;
        margin-top: 1;
        border: round $border-blurred;
    }

    #attachment-destination-picker-status {
        height: auto;
        margin-top: 1;
        color: $text-muted;
    }

    #attachment-destination-picker-hint {
        height: auto;
        margin-top: 1;
        color: $text-muted;
    }
    """

    def __init__(self, initial_path: str = "~/Downloads") -> None:
        super().__init__()
        self._initial_path = initial_path

    def compose(self) -> ComposeResult:
        with Vertical(id="attachment-destination-picker-dialog"):
            yield Static("Download Attachments", id="attachment-destination-picker-title")
            yield Static(
                "Enter the destination directory where the selected activity attachments will be saved.",
                id="attachment-destination-picker-subtitle",
            )
            yield Input(
                value=self._initial_path,
                placeholder="~/Downloads",
                id="attachment-destination-picker-input",
            )
            yield Static("", id="attachment-destination-picker-status")
            yield Static(
                "Edit the path and press Enter to download, or Esc/q to close.",
                id="attachment-destination-picker-hint",
            )

    def on_mount(self) -> None:
        self.query_one("#attachment-destination-picker-input", Input).focus()

    def on_key(self, event: events.Key) -> None:
        """Prevent picker shortcuts from leaking into the ticket detail screen."""

        if event.key in {"escape", "q"}:
            event.stop()
            self.action_cancel()

    def on_input_submitted(
        self,
        message: Input.Submitted,
    ) -> None:
        """Confirm the typed destination directory."""

        if message.input is self.query_one("#attachment-destination-picker-input", Input):
            self.action_activate()

    def action_activate(self) -> None:
        """Choose the typed destination directory."""

        destination = self.query_one("#attachment-destination-picker-input", Input).value.strip()
        if not destination:
            self.query_one("#attachment-destination-picker-status", Static).update(
                "Destination path is required."
            )
            return

        self.dismiss(Path(destination).expanduser())

    def action_cancel(self) -> None:
        """Dismiss the picker without selecting a destination."""

        self.dismiss(None)
