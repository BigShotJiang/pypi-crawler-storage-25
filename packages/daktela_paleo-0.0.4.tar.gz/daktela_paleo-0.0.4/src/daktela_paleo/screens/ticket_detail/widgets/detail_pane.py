"""Ticket detail widgets for the activities pane."""

from __future__ import annotations

import base64
import io
import math
import os
import re
import tempfile
import unicodedata
from collections.abc import Awaitable, Callable, Iterable
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from re import Pattern
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from PIL import Image
from rich.cells import cell_len
from rich.color import Color
from rich.segment import Segment
from rich.style import Style
from textual import events
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.message import Message
from textual.reactive import reactive
from textual.strip import Strip
from textual.widget import Widget
from textual.widgets import Markdown, Static

from daktela_paleo.models import ActivityBodyFragment, TicketActivity

_URL_RE = re.compile(r"https?://[^\s<>'\"`]+")
_URL_TRAILING_PUNCTUATION = ".,;:!?)]}"
_PLACEHOLDER_CHARACTER = "\U0010EEEE"
_MAX_IMAGE_COLUMNS = 64
_MAX_IMAGE_ROWS = 16
_ASSUMED_CELL_WIDTH_PX = 8
_ASSUMED_CELL_HEIGHT_PX = 16
_ATTACHMENT_INDICATOR = ""
_COMBINING_MARK_EXCLUSIONS = {
    0x0300,
    0x0301,
    0x0302,
    0x0303,
    0x0304,
    0x0306,
    0x0307,
    0x0308,
    0x0309,
    0x030A,
    0x030B,
    0x030C,
    0x030F,
    0x0311,
    0x0313,
    0x0314,
    0x0342,
    0x0653,
    0x0654,
}


@dataclass(frozen=True)
class QuickActionSpec:
    """Visible quick action definition for the selected activity."""

    action: str
    label: str
    key: str


@dataclass(frozen=True)
class ActivityLink:
    """A discovered activity URL."""

    url: str
    label: str | None = None

    @property
    def display_label(self) -> str:
        return self.label or self.url


@dataclass(frozen=True)
class _CachedActivityAsset:
    path: Path
    width_px: int
    height_px: int


@lru_cache(maxsize=1)
def _placeholder_diacritics() -> tuple[str, ...]:
    codepoints: list[str] = []
    for codepoint in range(0x0300, 0x110000):
        if codepoint in _COMBINING_MARK_EXCLUSIONS:
            continue
        character = chr(codepoint)
        if unicodedata.category(character) != "Mn":
            continue
        if unicodedata.combining(character) != 230:
            continue
        if unicodedata.decomposition(character):
            continue
        codepoints.append(character)
        if len(codepoints) >= 256:
            break
    return tuple(codepoints)


def _sanitize_activity_link_label(url: str) -> str:
    parsed = urlparse(url)
    query_items = [
        (key, value)
        for key, value in parse_qsl(parsed.query, keep_blank_values=True)
        if key != "accessToken"
    ]
    sanitized = urlunparse(parsed._replace(query=urlencode(query_items)))
    return sanitized or url


def _placeholder_grid(image_id: int, columns: int, rows: int) -> tuple[str, ...]:
    diacritics = _placeholder_diacritics()
    if columns <= 0 or rows <= 0:
        return ()

    lines: list[str] = []
    high_byte = (image_id >> 24) & 0xFF
    high_byte_diacritic = diacritics[high_byte] if high_byte else ""
    for row in range(rows):
        row_diacritic = diacritics[row]
        cells = [
            f"{_PLACEHOLDER_CHARACTER}{row_diacritic}{diacritics[column]}{high_byte_diacritic}"
            for column in range(columns)
        ]
        lines.append("".join(cells))
    return tuple(lines)


def _kitty_virtual_placement_sequence(
    image_path: Path,
    image_id: int,
    columns: int,
    rows: int,
) -> str:
    encoded_path = base64.b64encode(str(image_path).encode()).decode()
    return (
        "\x1b_G"
        f"a=T,q=2,U=1,C=1,i={image_id},c={columns},r={rows},f=100,t=f;"
        f"{encoded_path}"
        "\x1b\\"
    )


class ActivityImageWidget(Widget):
    """Render a kitty inline image or a text fallback for one activity fragment."""

    DEFAULT_CSS = """
    ActivityImageWidget {
        height: auto;
        padding: 0 1;
        background: transparent;
        color: $text;
    }
    """

    def __init__(
        self,
        *,
        resolved_url: str | None,
        label: str,
        image_id: int,
        asset_cache: dict[str, _CachedActivityAsset],
        temp_dir: Path,
        load_activity_asset: Callable[[str], Awaitable[bytes]] | None,
        supports_inline_images: bool,
        classes: str | None = None,
    ) -> None:
        super().__init__(classes=classes)
        self._resolved_url = resolved_url
        self._label = label
        self._image_id = image_id
        self._asset_cache = asset_cache
        self._temp_dir = temp_dir
        self._load_activity_asset = load_activity_asset
        self._supports_inline_images = supports_inline_images
        self._cached_asset: _CachedActivityAsset | None = None
        self._graphic_sequence: str | None = None
        self._placeholder_lines: tuple[str, ...] = ()
        self._image_style = Style(color=Color.from_rgb(
            (image_id >> 16) & 0xFF,
            (image_id >> 8) & 0xFF,
            image_id & 0xFF,
        ))
        self._status = "fallback"

    def on_mount(self) -> None:
        if (
            not self._supports_inline_images
            or self._resolved_url is None
            or self._load_activity_asset is None
        ):
            self._set_fallback()
            return

        cached_asset = self._asset_cache.get(self._resolved_url)
        if cached_asset is not None:
            self._cached_asset = cached_asset
            self._status = "loaded"
            self.call_after_refresh(self._sync_inline_geometry)
            return

        self._status = "loading"
        self.run_worker(self._load_asset(), exclusive=True, exit_on_error=False)

    def on_resize(self) -> None:
        if self._status == "loaded":
            self._sync_inline_geometry()

    def render(self) -> str:
        if self._status == "loaded":
            return self._label
        return self._label

    async def _load_asset(self) -> None:
        assert self._resolved_url is not None
        assert self._load_activity_asset is not None

        try:
            content = await self._load_activity_asset(self._resolved_url)
            cached_asset = self._normalize_asset(content)
        except Exception:
            self.call_after_refresh(self._set_fallback)
            return

        self._asset_cache[self._resolved_url] = cached_asset
        self._cached_asset = cached_asset
        self._status = "loaded"
        self.call_after_refresh(self._sync_inline_geometry)

    def _normalize_asset(self, content: bytes) -> _CachedActivityAsset:
        image_path = self._temp_dir / f"activity-image-{self._image_id}.png"
        with Image.open(io.BytesIO(content)) as image:
            width_px, height_px = image.size
            normalized = image.convert("RGBA")
            normalized.save(image_path, format="PNG")
        return _CachedActivityAsset(path=image_path, width_px=width_px, height_px=height_px)

    def _set_fallback(self) -> None:
        self._status = "fallback"
        self._graphic_sequence = None
        self._placeholder_lines = ()
        self.styles.height = 1
        self.refresh()

    def _sync_inline_geometry(self) -> None:
        if self._cached_asset is None:
            self._set_fallback()
            return

        width = max(1, self.size.width)
        diacritic_count = len(_placeholder_diacritics())
        natural_columns = max(1, math.ceil(self._cached_asset.width_px / _ASSUMED_CELL_WIDTH_PX))
        columns = min(width, natural_columns, _MAX_IMAGE_COLUMNS, diacritic_count)
        rows = max(
            2,
            min(
                math.ceil(
                    self._cached_asset.height_px
                    * columns
                    * _ASSUMED_CELL_WIDTH_PX
                    / max(1, self._cached_asset.width_px * _ASSUMED_CELL_HEIGHT_PX)
                ),
                _MAX_IMAGE_ROWS,
                diacritic_count,
            ),
        )
        self._placeholder_lines = _placeholder_grid(self._image_id, columns, rows)
        self._graphic_sequence = _kitty_virtual_placement_sequence(
            self._cached_asset.path,
            self._image_id,
            columns,
            rows,
        )
        self.styles.height = rows
        self.refresh()

    def render_line(self, y: int) -> Strip:
        base_style = self.rich_style

        if self._status != "loaded" or not self._placeholder_lines:
            if y > 0:
                return Strip.blank(max(1, self.size.width))
            width = max(cell_len(self._label), self.size.width, 1)
            return Strip([Segment(self._label, base_style)], cell_length=width)

        if y < 0 or y >= len(self._placeholder_lines):
            return Strip.blank(max(1, self.size.width))

        segments: list[Segment] = []
        if self._graphic_sequence is not None:
            segments.append(Segment(self._graphic_sequence, base_style))
        segments.append(Segment(self._placeholder_lines[y], self._image_style))
        return Strip(segments, cell_length=cell_len(self._placeholder_lines[y]))


class ActivityQuickActions(Horizontal):
    """Right-aligned quick actions for the selected activity."""

    def __init__(
        self,
        actions: tuple[QuickActionSpec, ...] = (),
        *,
        id: str | None = None,
        classes: str | None = None,
    ) -> None:
        super().__init__(id=id, classes=classes)
        self._actions = tuple(actions)

    def compose(self) -> ComposeResult:
        for action in self._actions:
            yield Static(
                f"{action.label} ({action.key})",
                id=f"ticket-detail-quick-action-{action.action}",
                classes="detail-pane-quick-action",
            )

    def set_actions(self, actions: tuple[QuickActionSpec, ...]) -> None:
        """Replace the visible quick-action buttons."""

        actions = tuple(actions)
        if actions == self._actions:
            return
        self._actions = actions
        self.refresh(recompose=True)


class DetailPaneBody(VerticalScroll):
    """Focusable, scrollable pane body for ticket activities."""

    can_focus = True
    active_index = reactive(0)
    selection_pinned = reactive(False)

    class SelectionChanged(Message):
        """Posted when the selected activity changes."""

        def __init__(
            self,
            detail_pane: DetailPaneBody,
            activity: TicketActivity | None,
        ) -> None:
            super().__init__()
            self.detail_pane = detail_pane
            self.activity = activity

        @property
        def control(self) -> DetailPaneBody:
            return self.detail_pane

    class QuickActionRequested(Message):
        """Posted when the focused activities pane requests a quick action."""

        def __init__(
            self,
            detail_pane: DetailPaneBody,
            action: str,
        ) -> None:
            super().__init__()
            self.detail_pane = detail_pane
            self.action = action

        @property
        def control(self) -> DetailPaneBody:
            return self.detail_pane

    class SearchRequested(Message):
        """Posted when the pane wants the search prompt opened."""

        def __init__(self, detail_pane: DetailPaneBody) -> None:
            super().__init__()
            self.detail_pane = detail_pane

        @property
        def control(self) -> DetailPaneBody:
            return self.detail_pane

    class SearchStatusChanged(Message):
        """Posted when the applied activity search status changes."""

        def __init__(self, detail_pane: DetailPaneBody, status: str | None) -> None:
            super().__init__()
            self.detail_pane = detail_pane
            self.status = status

        @property
        def control(self) -> DetailPaneBody:
            return self.detail_pane

    BINDINGS = [
        Binding("j,down", "cursor_down", "Down", show=False, priority=True),
        Binding("k,up", "cursor_up", "Up", show=False, priority=True),
        Binding("/", "request_search", "Search", show=False, priority=True),
        Binding("n", "next_search_match", "Next Match", show=False, priority=True),
        Binding("N", "previous_search_match", "Previous Match", show=False, priority=True),
        Binding("d", "request_download_quick_action", "Download", show=False, priority=True),
        Binding("y", "request_copy_quick_action", "Copy", show=False, priority=True),
        Binding("r", "request_reply_quick_action", "Reply", show=False, priority=True),
        Binding("f", "request_forward_quick_action", "Forward", show=False, priority=True),
    ]

    DEFAULT_CSS = """
    DetailPaneBody {
        height: 1fr;
        background: transparent;
    }

    .detail-pane-stack {
        height: auto;
        min-height: 1fr;
    }

    .detail-pane-placeholder {
        height: auto;
        min-height: 1fr;
        padding: 0 1;
        background: transparent;
        color: $text;
    }

    .detail-pane-entry {
        height: auto;
        margin-bottom: 1;
        background: transparent;
    }

    .detail-pane-entry-header {
        width: 1fr;
        height: auto;
    }

    .detail-pane-entry-title {
        width: 1fr;
    }

    .detail-pane-entry-title.-active {
        color: $text;
    }

    .detail-pane-entry-body {
        height: auto;
        padding: 0 1;
        background: transparent;
        color: $text;
    }

    .detail-pane-entry-markdown {
        height: auto;
        padding: 0 1;
        background: transparent;
        color: $text;
    }

    .detail-pane-entry-image {
        height: auto;
    }
    """

    def __init__(
        self,
        content: str = "no activities yet",
        quick_actions_for_activity: Callable[[TicketActivity | None], tuple[QuickActionSpec, ...]]
        | None = None,
        resolve_activity_asset_url: Callable[[str], str | None] | None = None,
        load_activity_asset: Callable[[str], Awaitable[bytes]] | None = None,
        *,
        id: str | None = None,
        classes: str | None = None,
    ) -> None:
        super().__init__(id=id, classes=classes)
        self._content = content
        self._activities: list[TicketActivity] = []
        self._quick_actions_for_activity = (
            quick_actions_for_activity if quick_actions_for_activity is not None else lambda _: ()
        )
        self._resolve_activity_asset_url = resolve_activity_asset_url
        self._load_activity_asset = load_activity_asset
        self._search_query: str | None = None
        self._search_regex: Pattern[str] | None = None
        self._search_match_indexes: list[int] = []
        self._search_active_match_index: int | None = None
        self._search_feedback_message: str | None = None
        self._image_id_counter = 1
        self._inline_image_cache: dict[str, _CachedActivityAsset] = {}
        self._image_temp_dir = tempfile.TemporaryDirectory(prefix="daktela-paleo-images-")
        self._image_temp_path = Path(self._image_temp_dir.name)

    def on_mount(self) -> None:
        self.call_after_refresh(self._refresh_activity_entry_styles)

    def on_unmount(self) -> None:
        self._image_temp_dir.cleanup()

    def watch_active_index(self, _: int) -> None:
        self._sync_search_match_from_active_index(self.active_index)
        if self.is_mounted:
            self.call_after_refresh(self._refresh_activity_entry_styles)
            self.call_after_refresh(self._scroll_active_activity_into_view)
            self.call_after_refresh(self._notify_selection_changed)

    def watch_selection_pinned(self, _: bool) -> None:
        if self.is_mounted:
            self.call_after_refresh(self._refresh_activity_entry_styles)

    def on_focus(self) -> None:
        self.call_after_refresh(self._refresh_activity_entry_styles)

    def on_blur(self) -> None:
        self.call_after_refresh(self._refresh_activity_entry_styles)

    def on_click(self, event: events.Click) -> None:
        """Focus the pane and route inline quick-action clicks."""

        action = self._quick_action_from_widget_id(event.widget.id if event.widget is not None else None)
        if action is None:
            return
        self.focus()
        self.post_message(self.QuickActionRequested(self, action))
        event.stop()

    def compose(self) -> ComposeResult:
        with Vertical(id="detail-pane-stack", classes="detail-pane-stack"):
            if self._activities:
                for index, activity in enumerate(self._activities):
                    yield self._activity_widget(activity, index)
            else:
                yield Static(self._content, classes="detail-pane-placeholder")

    def render(self) -> str:
        """Return the current plain-text content for tests and simple queries."""

        return self._content

    def show_loading(self) -> None:
        """Show a loading state while activities are fetched."""

        self._show_placeholder("loading activities...")

    def show_error(self) -> None:
        """Show an error state when activities fail to load."""

        self._show_placeholder("unable to load activities")

    def set_activities(self, activities: list[TicketActivity]) -> None:
        """Render the given list of activities."""

        if not activities:
            self._show_placeholder("no activities yet")
            return

        self._clear_search()
        lines: list[str] = []
        self._activities = list(activities)
        self.active_index = 0
        self.selection_pinned = False
        for index, activity in enumerate(self._activities):
            if index > 0:
                lines.append("")
            lines.append(self._summary_line(activity))
            lines.extend(self._activity_body_lines(activity))

        self._content = "\n".join(lines)
        self.refresh(recompose=True)
        self.scroll_home(animate=False, force=True)
        self.call_after_refresh(self._refresh_activity_entry_styles)
        self.call_after_refresh(self._scroll_active_activity_into_view)
        self.call_after_refresh(self._notify_selection_changed)

    def action_cursor_down(self) -> None:
        """Move the selected activity down one row."""

        if self.selection_pinned:
            return
        self._move_active_activity(1)

    def action_cursor_up(self) -> None:
        """Move the selected activity up one row."""

        if self.selection_pinned:
            return
        self._move_active_activity(-1)

    def action_request_reply_quick_action(self) -> None:
        """Request the reply quick action for the selected activity."""

        self.post_message(self.QuickActionRequested(self, "reply"))

    def action_request_copy_quick_action(self) -> None:
        """Request the copy quick action for the selected activity."""

        self.post_message(self.QuickActionRequested(self, "copy"))

    def action_request_download_quick_action(self) -> None:
        """Request the download quick action for the selected activity."""

        self.post_message(self.QuickActionRequested(self, "download"))

    def action_request_forward_quick_action(self) -> None:
        """Request the forward quick action for the selected activity."""

        self.post_message(self.QuickActionRequested(self, "forward"))

    def action_request_search(self) -> None:
        """Open the activity regex search prompt."""

        self.post_message(self.SearchRequested(self))

    def action_next_search_match(self) -> None:
        """Move to the next matching activity."""

        self._move_to_search_match(1)

    def action_previous_search_match(self) -> None:
        """Move to the previous matching activity."""

        self._move_to_search_match(-1)

    def apply_search(self, query: str) -> None:
        """Apply a regex search to the currently rendered activities."""

        if query == "":
            self._clear_search()
            return

        try:
            search_regex = re.compile(query)
        except re.error as error:
            self._search_query = None
            self._search_regex = None
            self._search_match_indexes = []
            self._search_active_match_index = None
            self._search_feedback_message = f"Invalid regex: {error}"
            self._post_search_status()
            return

        match_indexes = self._search_matches(search_regex)
        self._search_query = query
        self._search_regex = search_regex
        self._search_match_indexes = match_indexes
        self._search_feedback_message = None

        if not match_indexes:
            self._search_active_match_index = None
            self._search_feedback_message = f"No matches: /{query}"
            self._post_search_status()
            return

        self._search_active_match_index = self._initial_search_match_index(match_indexes)
        if self._search_active_match_index is not None:
            self.active_index = match_indexes[self._search_active_match_index]
        self._post_search_status()

    @property
    def selected_activity(self) -> TicketActivity | None:
        """Return the currently selected activity."""

        if not self._activities:
            return None
        if self.active_index < 0 or self.active_index >= len(self._activities):
            return None
        return self._activities[self.active_index]

    @property
    def has_search_state(self) -> bool:
        """Return whether a non-empty search is currently applied or reported."""

        return self._search_query is not None or self._search_feedback_message is not None

    @property
    def discovered_links(self) -> list[ActivityLink]:
        """Return the URLs discovered across the currently loaded activities."""

        return self.discover_links(
            self._activities,
            resolve_activity_asset_url=self._resolve_activity_asset_url,
        )

    def _show_placeholder(self, content: str) -> None:
        self._clear_search()
        self._activities = []
        self.active_index = 0
        self.selection_pinned = False
        self._content = content
        self.refresh(recompose=True)
        self.scroll_home(animate=False, force=True)
        self.call_after_refresh(self._refresh_activity_entry_styles)
        self.call_after_refresh(self._notify_selection_changed)

    def _activity_widget(self, activity: TicketActivity, index: int) -> Vertical:
        headline = activity.headline
        body_text = activity.body_text()
        markdown_body = activity.body_markdown()
        body_fragments = activity.body_fragments()
        render_headline = self._should_render_headline(headline, body_text, markdown_body)
        if body_fragments is not None and body_text is None and headline == "Untitled activity":
            render_headline = False

        children: list[Widget] = [
            Horizontal(
                Static(
                    self._summary_line(activity),
                    classes="detail-pane-title detail-pane-entry-title",
                    id=f"detail-pane-entry-title-{index}",
                ),
                ActivityQuickActions(
                    self._entry_quick_actions(index, activity),
                    classes="detail-pane-quick-actions detail-pane-entry-quick-actions",
                ),
                classes="detail-pane-entry-header",
            ),
        ]

        if render_headline:
            children.append(
                Static(headline, classes="detail-pane-entry-body detail-pane-entry-headline")
            )

        if body_fragments is not None:
            for fragment in body_fragments:
                if fragment.kind == "markdown" and fragment.markdown is not None:
                    children.append(
                        Markdown(
                            fragment.markdown,
                            classes="detail-pane-entry-markdown",
                            open_links=False,
                        )
                    )
                elif fragment.kind == "image" and fragment.source is not None:
                    resolved_url = self._resolve_activity_asset_url(fragment.source) if self._resolve_activity_asset_url is not None else None
                    children.append(
                        ActivityImageWidget(
                            resolved_url=resolved_url,
                            label=self._image_fragment_label(fragment, resolved_url),
                            image_id=self._next_image_id(),
                            asset_cache=self._inline_image_cache,
                            temp_dir=self._image_temp_path,
                            load_activity_asset=self._load_activity_asset,
                            supports_inline_images=self._supports_inline_images(),
                            classes="detail-pane-entry-image",
                        )
                    )
        else:
            if body_text is not None and body_text != headline:
                children.append(
                    Static(
                        body_text,
                        classes="detail-pane-entry-body detail-pane-entry-body-plain",
                    )
                )

        return Vertical(
            *children,
            classes="detail-pane-entry",
            id=f"detail-pane-entry-{index}",
        )

    def _move_active_activity(self, delta: int) -> None:
        if not self._activities:
            return

        last_index = len(self._activities) - 1
        self.active_index = min(max(self.active_index + delta, 0), last_index)

    def _move_to_search_match(self, direction: int) -> None:
        if not self._search_match_indexes:
            return

        if self._search_active_match_index is None:
            self._search_active_match_index = self._initial_search_match_index(
                self._search_match_indexes
            )
        else:
            self._search_active_match_index = (
                self._search_active_match_index + direction
            ) % len(self._search_match_indexes)

        assert self._search_active_match_index is not None
        self.active_index = self._search_match_indexes[self._search_active_match_index]
        self._post_search_status()

    def _refresh_activity_entry_styles(self) -> None:
        is_active_pane = self.app.focused is self
        for index, title in enumerate(self._entry_titles()):
            title.set_class(
                (is_active_pane and index == self.active_index)
                or (self.selection_pinned and index == self.active_index),
                "-active",
            )
        self._refresh_inline_quick_actions()

    def _scroll_active_activity_into_view(self) -> None:
        if not self._activities:
            return

        entries = self._entry_widgets()
        if self.active_index >= len(entries):
            return

        self.scroll_to_widget(entries[self.active_index], animate=False, immediate=True)

    def _entry_titles(self) -> list[Static]:
        return [widget for widget in self.query(".detail-pane-entry-title") if isinstance(widget, Static)]

    def _entry_widgets(self) -> list[Widget]:
        return [widget for widget in self.query(".detail-pane-entry") if isinstance(widget, Widget)]

    def _entry_quick_action_widgets(self) -> list[ActivityQuickActions]:
        return [
            widget
            for widget in self.query(".detail-pane-entry-quick-actions")
            if isinstance(widget, ActivityQuickActions)
        ]

    def _notify_selection_changed(self) -> None:
        self.post_message(self.SelectionChanged(self, self.selected_activity))

    def pin_selection(self) -> None:
        """Keep the current selection highlighted while focus moves elsewhere."""

        if not self._activities:
            return
        self.selection_pinned = True

    def unpin_selection(self) -> None:
        """Restore normal selection styling and movement."""

        self.selection_pinned = False

    def _clear_search(self) -> None:
        self._search_query = None
        self._search_regex = None
        self._search_match_indexes = []
        self._search_active_match_index = None
        self._search_feedback_message = None
        self._post_search_status()

    def _search_matches(self, search_regex: Pattern[str]) -> list[int]:
        return [
            index
            for index, activity in enumerate(self._activities)
            if any(
                self._match_spans(search_regex, value)
                for value in self._activity_search_values(activity)
            )
        ]

    @staticmethod
    def _match_spans(search_regex: Pattern[str], value: str) -> list[tuple[int, int]]:
        return [(match.start(), match.end()) for match in search_regex.finditer(value)]

    @classmethod
    def _activity_search_values(cls, activity: TicketActivity) -> tuple[str, ...]:
        values = [
            cls._summary_line(activity),
            activity.headline,
        ]
        body_text = activity.body_text()
        if body_text is not None:
            values.append(body_text)
        return tuple(values)

    @classmethod
    def discover_links(
        cls,
        activities: list[TicketActivity],
        *,
        resolve_activity_asset_url: Callable[[str], str | None] | None = None,
    ) -> list[ActivityLink]:
        """Collect distinct URLs from the provided activities in first-seen order."""

        discovered_links: list[ActivityLink] = []
        seen_urls: set[str] = set()

        for activity in activities:
            for value in cls._activity_link_values(activity):
                for url in cls._extract_urls(value):
                    if url in seen_urls:
                        continue
                    seen_urls.add(url)
                    discovered_links.append(ActivityLink(url=url))

            body_fragments = activity.body_fragments()
            if body_fragments is None:
                continue
            for fragment in body_fragments:
                if fragment.kind != "image" or fragment.source is None:
                    continue
                resolved_url = (
                    resolve_activity_asset_url(fragment.source)
                    if resolve_activity_asset_url is not None
                    else None
                )
                if resolved_url is None:
                    continue
                if resolved_url in seen_urls:
                    continue
                seen_urls.add(resolved_url)
                discovered_links.append(
                    ActivityLink(
                        url=resolved_url,
                        label=cls._image_fragment_label(fragment, resolved_url),
                    )
                )

        return discovered_links

    @classmethod
    def _activity_link_values(cls, activity: TicketActivity) -> tuple[str, ...]:
        values = [
            cls._summary_line(activity),
            activity.headline,
        ]

        body_text = activity.body_text()
        if body_text is not None:
            values.append(body_text)

        if activity.description is not None:
            values.append(activity.description)

        if activity.item is not None:
            if activity.item.description is not None:
                values.append(activity.item.description)
            if activity.item.body_html is not None:
                values.append(activity.item.body_html)

        return tuple(values)

    @staticmethod
    def _extract_urls(value: str) -> list[str]:
        urls: list[str] = []
        for match in _URL_RE.finditer(value):
            url = match.group(0).rstrip(_URL_TRAILING_PUNCTUATION)
            if url:
                urls.append(url)
        return urls

    def _initial_search_match_index(self, match_indexes: Iterable[int]) -> int | None:
        indexes = list(match_indexes)
        if not indexes:
            return None

        for offset, match_index in enumerate(indexes):
            if match_index >= self.active_index:
                return offset
        return 0

    def _sync_search_match_from_active_index(self, active_index: int) -> None:
        if active_index not in self._search_match_indexes:
            return

        next_index = self._search_match_indexes.index(active_index)
        if self._search_active_match_index == next_index:
            return

        self._search_active_match_index = next_index
        self._post_search_status()

    def _search_status_message(self) -> str | None:
        if self._search_feedback_message is not None:
            return self._search_feedback_message

        if (
            self._search_query is None
            or self._search_active_match_index is None
            or not self._search_match_indexes
        ):
            return None

        return (
            f"/{self._search_query} "
            f"{self._search_active_match_index + 1}/{len(self._search_match_indexes)}"
        )

    def _post_search_status(self) -> None:
        self.post_message(self.SearchStatusChanged(self, self._search_status_message()))

    def _refresh_inline_quick_actions(self) -> None:
        quick_action_widgets = self._entry_quick_action_widgets()
        for widget in quick_action_widgets:
            widget.set_actions(())

        if not quick_action_widgets or self.selected_activity is None:
            return
        if self.app.focused is not self:
            return
        if self.active_index >= len(quick_action_widgets):
            return

        quick_action_widgets[self.active_index].set_actions(
            self._quick_actions_for_activity(self.selected_activity)
        )

    def _entry_quick_actions(
        self,
        index: int,
        activity: TicketActivity,
    ) -> tuple[QuickActionSpec, ...]:
        if self.app.focused is not self or index != self.active_index:
            return ()
        return self._quick_actions_for_activity(activity)

    @staticmethod
    def _quick_action_from_widget_id(widget_id: str | None) -> str | None:
        if widget_id == "ticket-detail-quick-action-copy":
            return "copy"
        if widget_id == "ticket-detail-quick-action-download":
            return "download"
        if widget_id == "ticket-detail-quick-action-reply":
            return "reply"
        if widget_id == "ticket-detail-quick-action-forward":
            return "forward"
        return None

    @staticmethod
    def _activity_body_lines(activity: TicketActivity) -> list[str]:
        body_text = activity.body_text()
        markdown_body = activity.body_markdown()
        headline = activity.headline
        body_fragments = activity.body_fragments()
        render_headline = DetailPaneBody._should_render_headline(headline, body_text, markdown_body)
        if body_fragments is not None and body_text is None and headline == "Untitled activity":
            render_headline = False
        lines: list[str] = []

        if render_headline:
            lines.append(headline)

        if body_fragments is not None:
            for fragment in body_fragments:
                if fragment.kind == "markdown" and fragment.markdown is not None:
                    plain_text = DetailPaneBody._plain_text_from_markdown(fragment.markdown)
                    if plain_text:
                        lines.extend(plain_text.splitlines())
                elif fragment.kind == "image":
                    lines.append(DetailPaneBody._image_fragment_label(fragment, None))
        elif body_text is not None and body_text != headline:
            lines.extend(body_text.splitlines())
        elif not render_headline and body_text is not None:
            lines.extend(body_text.splitlines())
        return lines

    def _supports_inline_images(self) -> bool:
        return bool(os.environ.get("KITTY_WINDOW_ID")) and not self.app.is_headless

    def _next_image_id(self) -> int:
        image_id = self._image_id_counter
        self._image_id_counter = 1 if image_id >= 0xFFFFFF else image_id + 1
        return image_id

    @staticmethod
    def _image_fragment_label(
        fragment: ActivityBodyFragment,
        resolved_url: str | None,
    ) -> str:
        if fragment.alt:
            return f"Image: {fragment.alt}"
        if resolved_url is not None:
            return f"Image attachment: {_sanitize_activity_link_label(resolved_url)}"
        return "Image attachment"

    @staticmethod
    def _plain_text_from_markdown(markdown: str) -> str:
        normalized = markdown.replace("\r\n", "\n").replace("\r", "\n")
        normalized = normalized.replace("  \n", "\n")
        normalized = re.sub(r"!\[([^\]]*)\]\([^)]+\)", r"\1", normalized)
        normalized = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", normalized)
        for marker in ("**", "__", "*", "_", "`"):
            normalized = normalized.replace(marker, "")
        normalized = re.sub(r"\n{2,}", "\n", normalized)
        return normalized.strip()

    @staticmethod
    def _summary_line(activity: TicketActivity) -> str:
        if activity.time is None:
            timestamp = "-"
        else:
            timestamp = activity.time.strftime("%Y-%m-%d %H:%M")
        attachment_count = len(activity.downloadable_attachments())
        attachment_suffix = (
            f" | {_ATTACHMENT_INDICATOR} {attachment_count}"
            if attachment_count > 0
            else ""
        )
        return (
            f"{activity.display_summary_type} | {timestamp} | {activity.display_user}"
            f"{attachment_suffix}"
        )

    @staticmethod
    def _should_render_headline(
        headline: str,
        body_text: str | None,
        markdown_body: str | None,
    ) -> bool:
        return not (
            markdown_body is not None
            and body_text is not None
            and body_text == headline
        )
