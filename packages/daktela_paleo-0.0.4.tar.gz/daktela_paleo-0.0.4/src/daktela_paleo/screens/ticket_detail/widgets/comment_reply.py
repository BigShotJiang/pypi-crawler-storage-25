"""Inline comment composer for ticket detail."""

from __future__ import annotations

import os
import shlex
import subprocess
from contextlib import AbstractContextManager
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Literal, Protocol

from textual import events
from textual.app import ComposeResult, SuspendNotSupported
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.message import Message
from textual.widgets import Button, Static, TextArea

from daktela_paleo.models import TicketActivity


class ExternalEditorError(RuntimeError):
    """Raised when the inline composer can't use the configured external editor."""


class SupportsSuspend(Protocol):
    """Protocol for objects that can temporarily suspend terminal control."""

    def suspend(self) -> AbstractContextManager[None]: ...


def _edit_draft_in_external_editor(app: SupportsSuspend, draft: str) -> str:
    """Open the draft in the external editor configured by `$EDITOR`."""

    editor = os.environ.get("EDITOR", "").strip()
    if not editor:
        raise ExternalEditorError("External editor is unavailable: set $EDITOR first.")

    command = shlex.split(editor)

    draft_path: Path | None = None
    try:
        with NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            delete=False,
            prefix="daktela-paleo-comment-",
            suffix=".tmp",
        ) as temporary_file:
            temporary_file.write(draft)
            temporary_file.flush()
            draft_path = Path(temporary_file.name)

        try:
            with app.suspend():
                subprocess.run([*command, str(draft_path)], check=True)
        except SuspendNotSupported as error:
            raise ExternalEditorError(
                "External editor is unavailable in this environment."
            ) from error
        except FileNotFoundError as error:
            raise ExternalEditorError(
                f"Unable to launch external editor: {error.strerror or error.filename or error}."
            ) from error
        except subprocess.CalledProcessError as error:
            raise ExternalEditorError(
                f"External editor exited with status {error.returncode}."
            ) from error

        return draft_path.read_text(encoding="utf-8")
    finally:
        if draft_path is not None:
            draft_path.unlink(missing_ok=True)


class CommentReplyTextArea(TextArea):
    """Reply editor with local submit and cancel shortcuts."""

    BINDINGS = [
        *TextArea.BINDINGS,
        Binding("ctrl+s", "submit_reply", "Submit", priority=True),
        Binding("ctrl+e", "edit_in_external_editor", "External Editor", priority=True),
        Binding("ctrl+a", "request_attachment_path", "Attach File", priority=True),
        Binding("ctrl+d", "request_attachment_removal", "Remove File", priority=True),
        Binding("escape", "cancel_reply", "Cancel", priority=True),
    ]

    def action_submit_reply(self) -> None:
        parent = self.parent
        if isinstance(parent, CommentReplyComposer):
            parent.action_submit()

    def action_cancel_reply(self) -> None:
        parent = self.parent
        if isinstance(parent, CommentReplyComposer):
            parent.action_cancel()

    def action_edit_in_external_editor(self) -> None:
        parent = self.parent
        if isinstance(parent, CommentReplyComposer):
            parent.action_edit_in_external_editor()

    def action_request_attachment_path(self) -> None:
        parent = self.parent
        if isinstance(parent, CommentReplyComposer):
            parent.action_request_attachment_path()

    def action_request_attachment_removal(self) -> None:
        parent = self.parent
        if isinstance(parent, CommentReplyComposer):
            parent.action_request_attachment_removal()


class CommentReplyComposer(Vertical):
    """Inline composer that keeps ticket activity context visible while drafting."""

    BINDINGS = [
        Binding("ctrl+s", "submit", "Submit", priority=True),
        Binding("ctrl+e", "edit_in_external_editor", "External Editor", priority=True),
        Binding("ctrl+a", "request_attachment_path", "Attach File", priority=True),
        Binding("ctrl+d", "request_attachment_removal", "Remove File", priority=True),
        Binding("escape", "cancel", "Cancel", priority=True),
    ]

    class Submitted(Message):
        """Posted when the composer has validated content ready to submit."""

        def __init__(
            self,
            composer: CommentReplyComposer,
            content: str,
            attachment_paths: tuple[Path, ...],
        ) -> None:
            super().__init__()
            self.composer = composer
            self.content = content
            self.attachment_paths = attachment_paths

        @property
        def control(self) -> CommentReplyComposer:
            return self.composer

    class AttachmentPathRequested(Message):
        """Posted when the composer wants to stage another local file."""

        def __init__(self, composer: CommentReplyComposer) -> None:
            super().__init__()
            self.composer = composer

        @property
        def control(self) -> CommentReplyComposer:
            return self.composer

    class AttachmentRemovalRequested(Message):
        """Posted when the composer wants to remove a staged file."""

        def __init__(self, composer: CommentReplyComposer) -> None:
            super().__init__()
            self.composer = composer

        @property
        def control(self) -> CommentReplyComposer:
            return self.composer

    class Cancelled(Message):
        """Posted when the composer should close without submitting."""

        def __init__(self, composer: CommentReplyComposer) -> None:
            super().__init__()
            self.composer = composer

        @property
        def control(self) -> CommentReplyComposer:
            return self.composer

    DEFAULT_CSS = """
    CommentReplyComposer {
        display: none;
        width: 1fr;
        height: auto;
        margin: 1 1 0 1;
        padding: 0 1;
        border: round $border;
        background: $surface;
    }

    CommentReplyComposer.-open {
        display: block;
    }

    #comment-reply-title {
        height: auto;
        color: $text;
        text-style: bold;
    }

    #comment-reply-input {
        width: 1fr;
        height: 10;
        margin: 0;
        padding: 0;
        border: round $border-blurred;
    }

    #comment-reply-input:focus {
        border: round $accent;
    }

    #comment-reply-attachments-title {
        display: none;
        height: auto;
        margin-top: 1;
        color: $text;
        text-style: bold;
    }

    #comment-reply-attachments {
        display: none;
        height: auto;
        margin-top: 0;
        color: $text-muted;
    }

    #comment-reply-validation {
        display: none;
        height: auto;
        min-height: 1;
        margin-top: 1;
        color: $error;
    }

    #comment-reply-actions {
        width: 1fr;
        height: auto;
        margin-top: 0;
    }

    .comment-reply-action {
        min-width: 0;
        margin-right: 1;
    }

    #comment-reply-hint {
        height: auto;
        margin-top: 1;
        color: $text-muted;
    }
    """

    def __init__(
        self,
        *,
        id: str | None = None,
        classes: str | None = None,
    ) -> None:
        super().__init__(id=id, classes=classes)
        self._is_open = False
        self._is_submitting = False
        self._mode: Literal["new_comment", "reply"] = "new_comment"
        self._reply_target: TicketActivity | None = None
        self._staged_attachment_paths: list[Path] = []

    @property
    def is_open(self) -> bool:
        """Return whether the composer is currently visible."""

        return self._is_open

    @property
    def reply_target(self) -> TicketActivity | None:
        """Return the activity this draft is replying to."""

        return self._reply_target

    @property
    def mode(self) -> Literal["new_comment", "reply"]:
        """Return the current composer mode."""

        return self._mode

    @property
    def staged_attachment_paths(self) -> tuple[Path, ...]:
        """Return the currently staged file paths."""

        return tuple(self._staged_attachment_paths)

    def compose(self) -> ComposeResult:
        yield Static("Add comment", id="comment-reply-title")
        yield CommentReplyTextArea(id="comment-reply-input")
        yield Static("Staged attachments", id="comment-reply-attachments-title")
        yield Static("", id="comment-reply-attachments")
        yield Static("", id="comment-reply-validation")
        with Horizontal(id="comment-reply-actions"):
            yield Button(
                "Attach (Ctrl+A)",
                id="comment-reply-attach",
                classes="comment-reply-action",
            )
            yield Button(
                "Remove (Ctrl+D)",
                id="comment-reply-remove",
                classes="comment-reply-action",
            )
            yield Button(
                "Submit (Ctrl+S)",
                id="comment-reply-submit",
                classes="comment-reply-action",
            )
            yield Button(
                "Cancel (Esc)",
                id="comment-reply-cancel",
                classes="comment-reply-action",
            )
        yield Static(
            "Recent activity stays visible while you compose. Ctrl+A stages a file, Ctrl+D removes one, Ctrl+E opens $EDITOR, and Enter inserts a newline.",
            id="comment-reply-hint",
        )

    def on_key(self, event: events.Key) -> None:
        """Intercept composer shortcuts before they reach the screen."""

        if not self._is_open or not self.has_focus_within:
            return

        if event.key == "ctrl+s":
            event.stop()
            self.action_submit()
            return

        if event.key == "ctrl+e":
            event.stop()
            self.action_edit_in_external_editor()
            return

        if event.key == "ctrl+a":
            event.stop()
            self.action_request_attachment_path()
            return

        if event.key == "ctrl+d":
            event.stop()
            self.action_request_attachment_removal()
            return

        if event.key == "escape":
            event.stop()
            self.action_cancel()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Route button presses to the matching composer actions."""

        if event.button.id == "comment-reply-submit":
            event.stop()
            self.action_submit()
            return

        if event.button.id == "comment-reply-attach":
            event.stop()
            self.action_request_attachment_path()
            return

        if event.button.id == "comment-reply-remove":
            event.stop()
            self.action_request_attachment_removal()
            return

        if event.button.id == "comment-reply-cancel":
            event.stop()
            self.action_cancel()

    def open_for(self, activity: TicketActivity) -> None:
        """Show the composer for the given reply target."""

        same_target = self._reply_target == activity and self._is_open
        self._mode = "reply"
        self._reply_target = activity
        self._is_open = True
        self._is_submitting = False
        self.set_class(True, "-open")
        self._update_mode_labels()
        self.show_validation("")
        self._set_submitting(False)
        if not same_target:
            self.clear_staged_attachments()
            self.query_one("#comment-reply-input", TextArea).load_text("")
        self.focus_editor()

    def open_new_comment(self) -> None:
        """Show the composer for a top-level ticket comment."""

        preserve_draft = self._mode == "new_comment" and self._is_open
        self._mode = "new_comment"
        self._reply_target = None
        self._is_open = True
        self._is_submitting = False
        self.set_class(True, "-open")
        self._update_mode_labels()
        self.show_validation("")
        self._set_submitting(False)
        if not preserve_draft:
            self.clear_staged_attachments()
            self.query_one("#comment-reply-input", TextArea).load_text("")
        self.focus_editor()

    def close(self) -> None:
        """Hide the composer and clear its transient state."""

        self._is_open = False
        self._is_submitting = False
        self._mode = "new_comment"
        self._reply_target = None
        self.set_class(False, "-open")
        self.query_one("#comment-reply-input", TextArea).load_text("")
        self.clear_staged_attachments()
        self._update_mode_labels()
        self.show_validation("")
        self._set_submitting(False)

    def focus_editor(self) -> None:
        """Focus the reply editor."""

        if not self._is_open:
            return
        self.call_after_refresh(lambda: self.query_one("#comment-reply-input", TextArea).focus())

    def show_validation(self, message: str) -> None:
        """Update the inline validation or submit error message."""

        validation = self.query_one("#comment-reply-validation", Static)
        validation.update(message)
        validation.display = bool(message)

    def set_submission_pending(self, pending: bool) -> None:
        """Update the submit controls while a request is in flight."""

        self._is_submitting = pending
        self._set_submitting(pending)

    def draft_text(self) -> str:
        """Return the current editor contents."""

        return self.query_one("#comment-reply-input", TextArea).text

    def action_submit(self) -> None:
        """Validate and emit the submit request."""

        if not self._is_open or self._is_submitting:
            return

        content = self.draft_text().strip()
        if not content:
            self.show_validation("Comment body can't be blank.")
            self.focus_editor()
            return

        self.show_validation("")
        self.post_message(self.Submitted(self, content, self.staged_attachment_paths))

    def action_request_attachment_path(self) -> None:
        """Ask the screen to open the attachment path picker."""

        if not self._is_open or self._is_submitting:
            return

        self.show_validation("")
        self.post_message(self.AttachmentPathRequested(self))

    def action_request_attachment_removal(self) -> None:
        """Ask the screen to remove one staged file."""

        if not self._is_open or self._is_submitting:
            return

        if not self._staged_attachment_paths:
            self.show_validation("No staged attachments to remove.")
            self.focus_editor()
            return

        self.show_validation("")
        self.post_message(self.AttachmentRemovalRequested(self))

    def action_cancel(self) -> None:
        """Emit a cancel request for the owning screen."""

        if not self._is_open or self._is_submitting:
            return

        self.post_message(self.Cancelled(self))

    def action_edit_in_external_editor(self) -> None:
        """Round-trip the draft through the configured terminal editor."""

        if not self._is_open or self._is_submitting:
            return

        self.show_validation("")
        try:
            updated_draft = self._edit_draft_in_external_editor(self.draft_text())
        except ExternalEditorError as error:
            self.show_validation(str(error))
            self.focus_editor()
            return

        self.query_one("#comment-reply-input", TextArea).load_text(updated_draft)
        self.focus_editor()

    def stage_attachment(self, path: Path) -> bool:
        """Add one resolved file path to the staged attachment list."""

        if path in self._staged_attachment_paths:
            self.show_validation(f"File is already staged: {path.name}")
            self.focus_editor()
            return False

        self._staged_attachment_paths.append(path)
        self._refresh_staged_attachments()
        self.show_validation("")
        self.focus_editor()
        return True

    def unstage_attachment(self, path: Path) -> bool:
        """Remove one staged file path when present."""

        try:
            self._staged_attachment_paths.remove(path)
        except ValueError:
            return False

        self._refresh_staged_attachments()
        self.show_validation("")
        self.focus_editor()
        return True

    def clear_staged_attachments(self) -> None:
        """Drop every staged file from the current draft."""

        self._staged_attachment_paths.clear()
        self._refresh_staged_attachments()

    def _set_submitting(self, pending: bool) -> None:
        editor = self.query_one("#comment-reply-input", TextArea)
        attach_button = self.query_one("#comment-reply-attach", Button)
        remove_button = self.query_one("#comment-reply-remove", Button)
        submit_button = self.query_one("#comment-reply-submit", Button)
        cancel_button = self.query_one("#comment-reply-cancel", Button)
        editor.read_only = pending
        attach_button.disabled = pending
        remove_button.disabled = pending or not self._staged_attachment_paths
        submit_button.disabled = pending
        cancel_button.disabled = pending

    def _edit_draft_in_external_editor(self, draft: str) -> str:
        """Delegate to the shared external-editor helper."""

        return _edit_draft_in_external_editor(self.app, draft)

    def _update_mode_labels(self) -> None:
        title = "Add comment" if self._mode == "new_comment" else "Add comment reply"
        hint = (
            "Recent activity stays visible while you compose. Ctrl+A stages a file, Ctrl+D removes one, Ctrl+E opens $EDITOR, and Enter inserts a newline."
            if self._mode == "new_comment"
            else "Reply target stays locked while this draft is open. Ctrl+A stages a file, Ctrl+D removes one, Ctrl+E opens $EDITOR, and Enter inserts a newline."
        )
        self.query_one("#comment-reply-title", Static).update(title)
        self.query_one("#comment-reply-hint", Static).update(hint)

    def _refresh_staged_attachments(self) -> None:
        title = self.query_one("#comment-reply-attachments-title", Static)
        attachments = self.query_one("#comment-reply-attachments", Static)
        if not self._staged_attachment_paths:
            title.display = False
            attachments.update("")
            attachments.display = False
            remove_button = self.query_one("#comment-reply-remove", Button)
            remove_button.disabled = True
            return

        title.display = True
        attachments.update(
            "\n".join(
                f"{path.name} ({path})"
                for path in self._staged_attachment_paths
            )
        )
        attachments.display = True
        remove_button = self.query_one("#comment-reply-remove", Button)
        remove_button.disabled = self._is_submitting
