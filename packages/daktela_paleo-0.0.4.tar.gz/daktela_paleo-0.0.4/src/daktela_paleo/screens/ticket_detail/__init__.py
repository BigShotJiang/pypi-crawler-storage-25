"""Ticket detail screen modules."""
