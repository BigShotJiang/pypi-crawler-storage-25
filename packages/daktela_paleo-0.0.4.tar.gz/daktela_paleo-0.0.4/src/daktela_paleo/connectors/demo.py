"""Demo connector used for local app runtime."""

from __future__ import annotations

import base64
from datetime import datetime
from importlib.resources import files

from daktela_paleo.connectors.mock import MockTicketConnector
from daktela_paleo.models import (
    AppState,
    Ticket,
    TicketActivity,
    TicketActivityItem,
    TicketCategoryOption,
    TicketEmailAction,
    TicketEmailDraft,
    TicketPriority,
    TicketStatusOption,
    TicketStage,
    TicketUserOption,
    TicketView,
)

DEMO_BASE_URL = "https://demo.invalid"
_DEMO_IMAGE_BYTES = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+yF9kAAAAASUVORK5CYII="
)


def _load_demo_asset_bytes(filename: str) -> bytes:
    """Return bytes for packaged demo assets."""

    return files("daktela_paleo").joinpath("assets", filename).read_bytes()


_DEMO_COURIER_TRAIL_IMAGE_BYTES = _load_demo_asset_bytes("courier-trail.png")


class DemoTicketConnector(MockTicketConnector):
    """Static in-memory dataset for local development."""

    def __init__(self) -> None:
        views = self.build_views()
        tickets = self.build_tickets()
        super().__init__(
            views=views,
            tickets=tickets,
            ticket_activities=self.build_ticket_activities(tickets),
            category_options=self.build_ticket_categories(),
            status_options_by_category=self.build_ticket_statuses(),
            user_options=self.build_ticket_users(),
            current_user=self.build_current_user(),
        )

        views_by_name = {view.name: view for view in views if view.name is not None}
        tickets_by_view = self._tickets_by_view_name(tickets)

        for view_name, view_tickets in tickets_by_view.items():
            view = views_by_name.get(view_name)
            if view is None or view_name in self._paginated_view_ticket_names():
                continue
            self.set_tickets_for_view(view, view_tickets)

        for view_name, ticket_names in self._paginated_view_ticket_names().items():
            view = views_by_name[view_name]
            pages = [
                [next(ticket for ticket in tickets if ticket.name == ticket_name)]
                for ticket_name in ticket_names
            ]
            self.set_ticket_pages_for_view(view, pages, total_tickets=len(ticket_names))

        self._seed_activity_attachments()
        self._seed_activity_assets()
        self._seed_email_drafts()

    @classmethod
    def build_state(cls) -> AppState:
        """Return a deterministic state snapshot for tests."""

        return AppState(
            views=cls.build_views(),
            tickets=cls.build_tickets(),
            active_view=None,
            active_ticket=None,
        )

    @staticmethod
    def build_views() -> list[TicketView]:
        """Return the demo ticket view hierarchy."""

        return [
            TicketView(view=401, name="demo", title="Demo"),
            TicketView(view=410, name="hl2", title="Half-Life 2", parent_view="demo"),
            TicketView(view=411, name="hl2_city17", title="City 17 Queue", parent_view="hl2"),
            TicketView(view=412, name="hl2_resistance", title="Resistance Relay", parent_view="hl2"),
            TicketView(view=413, name="hl2_combine", title="Combine Escalations", parent_view="hl2"),
            TicketView(view=420, name="matrix", title="Matrix", parent_view="demo"),
            TicketView(view=421, name="matrix_zion", title="Zion Operations", parent_view="matrix"),
            TicketView(
                view=422,
                name="matrix_nebuchadnezzar",
                title="Nebuchadnezzar Relay",
                parent_view="matrix",
            ),
            TicketView(view=423, name="matrix_machine", title="Machine Pressure", parent_view="matrix"),
            TicketView(view=430, name="star_wars", title="Star Wars", parent_view="demo"),
            TicketView(view=431, name="star_wars_rebel", title="Rebel Dispatch", parent_view="star_wars"),
            TicketView(
                view=432,
                name="star_wars_outer_rim",
                title="Outer Rim Waiting",
                parent_view="star_wars",
            ),
            TicketView(
                view=433,
                name="star_wars_imperial",
                title="Imperial Escalations",
                parent_view="star_wars",
            ),
            TicketView(
                view=440,
                name="lotr",
                title="Lord of the Rings",
                parent_view="demo",
            ),
            TicketView(view=441, name="lotr_shire", title="Shire Requests", parent_view="lotr"),
            TicketView(view=442, name="lotr_rohan", title="Rohan Muster", parent_view="lotr"),
            TicketView(view=443, name="lotr_mordor", title="Mordor Escalations", parent_view="lotr"),
        ]

    @staticmethod
    def build_ticket_categories() -> list[TicketCategoryOption]:
        """Return the selectable demo ticket categories."""

        return [
            TicketCategoryOption(name="Field Ops", title="Field Ops"),
            TicketCategoryOption(name="Citizen Priority", title="Citizen Priority"),
            TicketCategoryOption(name="Red Pill Ops", title="Red Pill Ops"),
            TicketCategoryOption(name="Machine Alert", title="Machine Alert"),
            TicketCategoryOption(name="Rebel Ops", title="Rebel Ops"),
            TicketCategoryOption(name="Imperial Watch", title="Imperial Watch"),
            TicketCategoryOption(name="Free Peoples", title="Free Peoples"),
            TicketCategoryOption(name="Shadow Watch", title="Shadow Watch"),
        ]

    @classmethod
    def build_ticket_users(cls) -> list[TicketUserOption]:
        """Return the selectable demo ticket users."""

        user_names = sorted(
            {
                user_name
                for ticket in cls.build_tickets()
                for user_name in [ticket.user_name or ticket.user]
                if user_name is not None
            }
        )
        return [
            TicketUserOption(name=user_name, title=user_name)
            for user_name in user_names
        ]

    @classmethod
    def build_current_user(cls) -> TicketUserOption | None:
        """Return the simulated authenticated demo operator."""

        user_options = cls.build_ticket_users()
        for option in user_options:
            if option.name == "Trinity":
                return option
        return user_options[0] if user_options else None

    @staticmethod
    def build_ticket_statuses() -> dict[str, list[TicketStatusOption]]:
        """Return selectable demo ticket statuses keyed by category name."""

        return {
            "Field Ops": [
                TicketStatusOption(name="status_hl2_field", title="Field review"),
                TicketStatusOption(name="status_hl2_signal", title="Signal loss"),
                TicketStatusOption(name="status_hl2_checkpoint", title="Checkpoint block"),
            ],
            "Citizen Priority": [
                TicketStatusOption(name="status_hl2_ration", title="Ration queue"),
                TicketStatusOption(name="status_hl2_priority", title="Priority transfer"),
            ],
            "Red Pill Ops": [
                TicketStatusOption(name="status_matrix_hovercraft", title="Hovercraft relay"),
                TicketStatusOption(name="status_matrix_hardline", title="Hardline route"),
            ],
            "Machine Alert": [
                TicketStatusOption(name="status_matrix_sentinel", title="Sentinel watch"),
                TicketStatusOption(name="status_matrix_agent", title="Agent trace"),
            ],
            "Rebel Ops": [
                TicketStatusOption(name="status_sw_dispatch", title="Dispatch"),
                TicketStatusOption(name="status_sw_convoy", title="Convoy watch"),
            ],
            "Imperial Watch": [
                TicketStatusOption(name="status_sw_patrol", title="Patrol breach"),
                TicketStatusOption(name="status_sw_archive", title="Archive handoff"),
            ],
            "Free Peoples": [
                TicketStatusOption(name="status_lotr_courier", title="Courier watch"),
                TicketStatusOption(name="status_lotr_muster", title="Muster hold"),
            ],
            "Shadow Watch": [
                TicketStatusOption(name="status_lotr_gate", title="Gate warning"),
                TicketStatusOption(name="status_lotr_archive", title="Archive return"),
            ],
        }

    @staticmethod
    def build_tickets() -> list[Ticket]:
        """Return the demo ticket collection."""

        return [
            _ticket(
                2001,
                "Strider signal lost",
                "Field Ops",
                "Alyx Vance",
                TicketStage.OPEN,
                TicketPriority.HIGH,
                "Alyx Vance",
                statuses={
                    "status_hl2_field": "Field review",
                    "status_hl2_signal": "Signal loss",
                },
            ),
            _ticket(
                2002,
                "Ration queue stalled",
                "Citizen Priority",
                "Dr. Kleiner",
                TicketStage.WAIT,
                TicketPriority.MEDIUM,
                "Barney Calhoun",
                statuses={"status_hl2_ration": "Ration queue"},
            ),
            _ticket(
                2003,
                "Checkpoint lockout at plaza",
                "Field Ops",
                "Resistance Cell 12",
                TicketStage.WAIT,
                TicketPriority.HIGH,
                "Judith Mossman",
                statuses={"status_hl2_checkpoint": "Checkpoint block"},
            ),
            _ticket(
                2004,
                "Lambda cache mislabeled",
                "Field Ops",
                "Eli Vance",
                TicketStage.CLOSE,
                TicketPriority.LOW,
                "Isaac Kleiner",
                statuses={"status_hl2_field": "Field review"},
            ),
            _ticket(
                2101,
                "Sentinel sweep over Zion",
                "Machine Alert",
                "Morpheus",
                TicketStage.OPEN,
                TicketPriority.HIGH,
                "Trinity",
                statuses={"status_matrix_sentinel": "Sentinel watch"},
            ),
            _ticket(
                2102,
                "Neb log upload loop",
                "Red Pill Ops",
                "Link",
                TicketStage.WAIT,
                TicketPriority.MEDIUM,
                "Niobe",
                statuses={"status_matrix_hovercraft": "Hovercraft relay"},
            ),
            _ticket(
                2103,
                "Construct access drift",
                "Red Pill Ops",
                "The Oracle",
                TicketStage.OPEN,
                TicketPriority.LOW,
                "Tank",
                statuses={"status_matrix_hardline": "Hardline route"},
            ),
            _ticket(
                2104,
                "Agent trace near hardline",
                "Machine Alert",
                "Commander Lock",
                TicketStage.CLOSE,
                TicketPriority.HIGH,
                "Ghost",
                statuses={"status_matrix_agent": "Agent trace"},
            ),
            _ticket(
                2201,
                "Yavin supply route exposed",
                "Rebel Ops",
                "Mon Mothma",
                TicketStage.OPEN,
                TicketPriority.HIGH,
                "Wedge Antilles",
                statuses={"status_sw_dispatch": "Dispatch"},
            ),
            _ticket(
                2202,
                "Outer Rim beacon delayed",
                "Rebel Ops",
                "Lando Calrissian",
                TicketStage.WAIT,
                TicketPriority.MEDIUM,
                "Han Solo",
                statuses={"status_sw_convoy": "Convoy watch"},
            ),
            _ticket(
                2203,
                "TIE patrol on convoy lane",
                "Imperial Watch",
                "General Dodonna",
                TicketStage.WAIT,
                TicketPriority.HIGH,
                "Leia Organa",
                statuses={"status_sw_patrol": "Patrol breach"},
            ),
            _ticket(
                2204,
                "Holonet relay archived",
                "Imperial Watch",
                "Bail Organa",
                TicketStage.CLOSE,
                TicketPriority.LOW,
                "C-3PO",
                statuses={"status_sw_archive": "Archive handoff"},
            ),
            _ticket(
                2301,
                "Ranger reports missing courier",
                "Free Peoples",
                "Elrond",
                TicketStage.OPEN,
                TicketPriority.HIGH,
                "Aragorn",
                statuses={"status_lotr_courier": "Courier watch"},
            ),
            _ticket(
                2302,
                "Muster banner not delivered",
                "Free Peoples",
                "Theoden",
                TicketStage.WAIT,
                TicketPriority.MEDIUM,
                "Eowyn",
                statuses={"status_lotr_muster": "Muster hold"},
            ),
            _ticket(
                2303,
                "Black Gate scout warning",
                "Shadow Watch",
                "Faramir",
                TicketStage.WAIT,
                TicketPriority.HIGH,
                "Gandalf",
                statuses={"status_lotr_gate": "Gate warning"},
            ),
            _ticket(
                2304,
                "Shire ledger restored",
                "Shadow Watch",
                "Frodo Baggins",
                TicketStage.CLOSE,
                TicketPriority.LOW,
                "Samwise Gamgee",
                statuses={"status_lotr_archive": "Archive return"},
            ),
        ]

    @staticmethod
    def build_ticket_activities(tickets: list[Ticket]) -> dict[tuple[str, str], list[TicketActivity]]:
        """Return deterministic demo activities keyed by ticket identity."""

        tickets_by_name = {ticket.name: ticket for ticket in tickets if ticket.name is not None}
        return {
            ("name", "2001"): [
                _activity(
                    "activities_2001_scan",
                    type="",
                    title="Scanner pass from tunnel approach",
                    user=tickets_by_name[2001].user_name,
                    time="2026-03-30 08:15:00",
                    description=(
                        "<p>Forwarding the confirmed silhouette from "
                        "<a href='https://demo.invalid/hl2/city-17/strider'>sector gate</a>.</p>"
                        "<img src='/assets/demo/hl2-strider.png' alt='Strider silhouette' />"
                    ),
                    item_model=None,
                    attachments=[
                        {
                            "file": "hl2-strider-brief",
                            "title": "strider-brief.txt",
                            "type": "text/plain",
                            "size": 88,
                        }
                    ],
                ),
                _activity(
                    "activities_2001_followup",
                    type="",
                    title="Relay staged for rooftop team",
                    user="Barney Calhoun",
                    time="2026-03-30 08:34:00",
                    description="Roof team has the same marker set and is waiting on confirmation.",
                    item_model=None,
                ),
            ],
            ("name", "2101"): [
                _activity(
                    "activities_2101_email",
                    type="EMAIL",
                    title="Sentinel sweep over Zion",
                    user="Morpheus",
                    time="2026-03-30 09:10:00",
                    body_html=(
                        "<p>Visual confirmed near Dock 12. Recommend rerouting the hovercraft corridor.</p>"
                    ),
                    item_model="activitiesEmail",
                    direction="in",
                    address="zion-ops@matrix.invalid",
                    queue_name="zion_ops",
                    item_name="emails_2101",
                ),
                _activity(
                    "activities_2101_checklist",
                    type="",
                    title="Dock rotation checklist",
                    user="Trinity",
                    time="2026-03-30 09:16:00",
                    description=(
                        "<p>Immediate actions for Dock 12:</p>"
                        "<ul>"
                        "<li>Reroute the freight line</li>"
                        "<li>Hold the hardline elevator</li>"
                        "<li>Move the med teams to the inner ring</li>"
                        "</ul>"
                    ),
                    item_model=None,
                ),
                _activity(
                    "activities_2101_sequence",
                    type="",
                    title="Fallback sequence approved",
                    user="Niobe",
                    time="2026-03-30 09:21:00",
                    description=(
                        "<p>Run the fallback in this order:</p>"
                        "<ol>"
                        "<li>Trace sentinel perimeter</li>"
                        "<li>Confirm dock doors are locked</li>"
                        "<li>Open the secondary lane for crews</li>"
                        "</ol>"
                    ),
                    item_model=None,
                ),
                _activity(
                    "activities_2101_table",
                    type="",
                    title="Lane readiness matrix",
                    user="Link",
                    time="2026-03-30 09:28:00",
                    description=(
                        "<table>"
                        "<thead><tr><th>Lane</th><th>Status</th><th>Owner</th></tr></thead>"
                        "<tbody>"
                        "<tr><td>Dock 12</td><td>reroute</td><td>Trinity</td></tr>"
                        "<tr><td>Hardline</td><td>hold</td><td>Link</td></tr>"
                        "<tr><td>Med bay</td><td>ready</td><td>Niobe</td></tr>"
                        "</tbody>"
                        "</table>"
                    ),
                    item_model=None,
                ),
                _activity(
                    "activities_2101_console",
                    type="",
                    title="Operator note from Morpheus",
                    user="Morpheus",
                    time="2026-03-30 09:33:00",
                    description=(
                        "<blockquote><p>There is no spoon. There is only the lane we hold.</p></blockquote>"
                        "<pre><code>trace --dock 12 --confirm hardline</code></pre>"
                    ),
                    item_model=None,
                ),
            ],
            ("name", "2201"): [
                _activity(
                    "activities_2201_comment",
                    type="",
                    title="Leia requests tighter convoy timing",
                    user="Leia Organa",
                    time="2026-03-30 10:05:00",
                    description="Need a tighter departure window before the next patrol rotation.",
                    item_model=None,
                ),
            ],
            ("name", "2301"): [
                _activity(
                    "activities_2301_image",
                    type="",
                    title="Ranger sketch from the Greenway",
                    user=tickets_by_name[2301].user_name,
                    time="2026-03-30 11:05:00",
                    description=(
                        "<p>Aragorn sent a field sketch before dawn to mark the courier trail.</p>"
                        "<img src='/assets/demo/lotr-courier-trail.png' alt='Courier trail sketch' />"
                    ),
                    item_model=None,
                ),
                _activity(
                    "activities_2301_checklist",
                    type="",
                    title="Courier handoff checklist",
                    user="Halbarad",
                    time="2026-03-30 11:18:00",
                    description=(
                        "<p>Before the next rider leaves Bree, confirm these preparations:</p>"
                        "<ul>"
                        "<li>Fresh relay horse waiting beyond the east gate</li>"
                        "<li>Lantern shutters packed for the Weather Hills crossing</li>"
                        "<li>Second seal tucked inside the satchel for Aragorn</li>"
                        "</ul>"
                    ),
                    item_model=None,
                ),
                _activity(
                    "activities_2301_route",
                    type="",
                    title="Fallback route if the ford closes",
                    user="Elrond",
                    time="2026-03-30 11:29:00",
                    description=(
                        "<p>If the direct road is watched, send the courier by this order:</p>"
                        "<ol>"
                        "<li>Cut north through the hedgerows beyond Bree</li>"
                        "<li>Meet the Dunedain at the ruined watchtower</li>"
                        "<li>Rejoin the Greenway only after the second beacon answers</li>"
                        "</ol>"
                    ),
                    item_model=None,
                ),
                _activity(
                    "activities_2301_table",
                    type="",
                    title="Waystation coverage board",
                    user="Arwen",
                    time="2026-03-30 11:44:00",
                    description=(
                        "<p>Known relay points for tonight's run:</p>"
                        "<table>"
                        "<thead><tr><th>Waystation</th><th>Signal</th><th>Keeper</th></tr></thead>"
                        "<tbody>"
                        "<tr><td>Bree gate</td><td>Amber</td><td>Butterbur's watch</td></tr>"
                        "<tr><td>Weather Hills</td><td>Green</td><td>Halbarad</td></tr>"
                        "<tr><td>Sarn Ford</td><td>Red</td><td>Ranger pair delayed</td></tr>"
                        "</tbody>"
                        "</table>"
                    ),
                    item_model=None,
                ),
            ],
            ("name", "2303"): [
                _activity(
                    "activities_2303_comment",
                    type="",
                    title="Forward watch packed the evidence",
                    user=tickets_by_name[2303].user_name,
                    time="2026-03-30 11:40:00",
                    description="Two reports arrived from the eastern ridge and both need review before dusk.",
                    item_model=None,
                    attachments=[
                        {
                            "file": "lotr-scout-route",
                            "title": "scout-route.txt",
                            "type": "text/plain",
                            "size": 64,
                        },
                        {
                            "file": "lotr-black-gate-note",
                            "title": "black-gate-note.txt",
                            "type": "text/plain",
                            "size": 72,
                        },
                    ],
                ),
            ],
        }

    def ticket_browser_url(self, ticket: Ticket) -> str | None:
        """Return a deterministic demo browser URL for ``ticket``."""

        if ticket.name is None:
            return None
        return f"{DEMO_BASE_URL}/tickets/{ticket.name}"

    def view_browser_url(self, view: TicketView) -> str | None:
        """Return a deterministic demo browser URL for ``view``."""

        if view.name is None:
            return None
        return f"{DEMO_BASE_URL}/views/{view.name}"

    @staticmethod
    def _tickets_by_view_name(tickets: list[Ticket]) -> dict[str, list[Ticket]]:
        tickets_by_name = {ticket.name: ticket for ticket in tickets if ticket.name is not None}
        view_ticket_names = {
            "demo": [2001, 2002, 2003, 2004, 2101, 2102, 2103, 2104, 2201, 2202, 2203, 2204, 2301, 2302, 2303, 2304],
            "hl2": [2001, 2002, 2003, 2004],
            "hl2_city17": [2001, 2002],
            "hl2_resistance": [2003],
            "hl2_combine": [2004],
            "matrix": [2101, 2102, 2103, 2104],
            "matrix_zion": [2101, 2102],
            "matrix_nebuchadnezzar": [2103],
            "matrix_machine": [2104],
            "star_wars": [2201, 2202, 2203, 2204],
            "star_wars_rebel": [2201, 2202],
            "star_wars_outer_rim": [2203],
            "star_wars_imperial": [2204],
            "lotr": [2301, 2302, 2303, 2304],
            "lotr_shire": [2301, 2302],
            "lotr_rohan": [2303],
            "lotr_mordor": [2304],
        }
        return {
            view_name: [tickets_by_name[ticket_name] for ticket_name in ticket_names]
            for view_name, ticket_names in view_ticket_names.items()
        }

    @staticmethod
    def _paginated_view_ticket_names() -> dict[str, tuple[int, int]]:
        return {
            "hl2_city17": (2001, 2002),
            "matrix_zion": (2101, 2102),
            "star_wars_rebel": (2201, 2202),
            "lotr_shire": (2301, 2302),
        }

    def _seed_activity_attachments(self) -> None:
        attachment_payloads = {
            "hl2-strider-brief": (
                b"Sector gate feed\n"
                b"Marker: strider\n"
                b"Rooftop relay standing by.\n"
            ),
            "lotr-scout-route": (
                b"Scout path\n"
                b"- East ridge\n"
                b"- Dead marsh turn\n"
                b"- Black Gate sightline\n"
            ),
            "lotr-black-gate-note": (
                b"Gate note\n"
                b"Drums heard after dusk.\n"
                b"Do not move the western watch.\n"
            ),
        }
        for activities in self._ticket_activities.values():
            for activity in activities:
                for attachment in activity.downloadable_attachments():
                    payload = attachment_payloads.get(attachment.file)
                    if payload is None:
                        continue
                    self.set_ticket_activity_attachment(activity, attachment, payload)

    def _seed_activity_assets(self) -> None:
        self.set_activity_asset(
            "/assets/demo/hl2-strider.png",
            f"{DEMO_BASE_URL}/assets/hl2-strider.png?accessToken=demo",
            _DEMO_IMAGE_BYTES,
        )
        self.set_activity_asset(
            "/assets/demo/lotr-courier-trail.png",
            f"{DEMO_BASE_URL}/assets/lotr-courier-trail.png?accessToken=demo",
            _DEMO_COURIER_TRAIL_IMAGE_BYTES,
        )

    def _seed_email_drafts(self) -> None:
        ticket = next(ticket for ticket in self.build_tickets() if ticket.name == 2101)
        activity = self._ticket_activities[("name", "2101")][0]
        self.set_ticket_email_draft(
            ticket,
            activity,
            TicketEmailAction.REPLY,
            TicketEmailDraft(
                action=TicketEmailAction.REPLY,
                source_activity_name=activity.name or "activities_2101_email",
                source_email_name="emails_2101",
                to="zion-ops@matrix.invalid, niobe@matrix.invalid",
                subject="Re: Sentinel sweep over Zion",
                body="Routing Dock 12 traffic around the sweep now.\nHold the hardline until Ghost confirms the lane.",
                queue_name="zion_ops",
            ),
        )
        self.set_ticket_email_draft(
            ticket,
            activity,
            TicketEmailAction.FORWARD,
            TicketEmailDraft(
                action=TicketEmailAction.FORWARD,
                source_activity_name=activity.name or "activities_2101_email",
                source_email_name="emails_2101",
                to="lock@matrix.invalid",
                subject="Fwd: Sentinel sweep over Zion",
                body="Commander, sharing the latest sweep report before we move the dock crews.",
                queue_name="zion_ops",
            ),
        )


def _ticket(
    name: int,
    title: str,
    category: str,
    contact: str,
    stage: TicketStage,
    priority: TicketPriority,
    user: str,
    statuses: dict[str, str] | None = None,
) -> Ticket:
    return Ticket(
        name=name,
        title=title,
        category=category,
        category_name=category,
        contact=contact,
        stage=stage,
        priority=priority,
        user=user,
        user_name=user,
        statuses=statuses,
    )


def _activity(
    name: str,
    *,
    type: str,
    user: str | None,
    time: str,
    title: str | None = None,
    description: str | None = None,
    body_html: str | None = None,
    item_model: str | None = "activitiesEmail",
    direction: str | None = None,
    attachments: list[dict[str, object]] | None = None,
    address: str | None = None,
    queue_name: str | None = None,
    item_name: str | None = None,
) -> TicketActivity:
    item = None
    if any(
        value is not None
        for value in (
            item_model,
            title,
            body_html,
            direction,
            description,
            address,
            queue_name,
            item_name,
        )
    ):
        item = TicketActivityItem.model_validate(
            {
                "name": item_name,
                "model": item_model,
                "title": title,
                "time": datetime.fromisoformat(time),
                "body_html": body_html,
                "direction": direction,
                "description": description if item_model is not None else None,
                "address": address,
                "queue_name": queue_name,
                "attachments": attachments if item_model == "activitiesEmail" else None,
            }
        )

    return TicketActivity.model_validate(
        {
            "name": name,
            "type": type,
            "title": title,
            "time": datetime.fromisoformat(time),
            "user": user,
            "user_name": user,
            "description": description,
            "item": item if item_model is not None else None,
            "attachments": attachments if item_model is None else None,
        }
    )
