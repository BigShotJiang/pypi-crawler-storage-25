"""Configurable in-memory connector for tests."""

from __future__ import annotations

import asyncio
from datetime import datetime

from daktela_paleo.connectors.base import TicketConnector
from daktela_paleo.models import (
    AppState,
    Ticket,
    TicketActivity,
    TicketActivityAttachment,
    TicketCategoryOption,
    TicketCommentCreateRequest,
    TicketEmailAction,
    TicketEmailDraft,
    TicketEmailSendRequest,
    TicketEditPatch,
    TicketPage,
    TicketPagination,
    TicketStatusOption,
    TicketUserOption,
    TicketView,
)

ViewKey = tuple[str, str]
PagedViewKey = ViewKey | None
EmailDraftKey = tuple[ViewKey, str, TicketEmailAction]
AttachmentKey = tuple[str, str]


class MockTicketConnector(TicketConnector):
    """In-memory connector with controllable responses and call tracking."""

    def __init__(
        self,
        *,
        initial_state: AppState | None = None,
        views: list[TicketView] | None = None,
        tickets: list[Ticket] | None = None,
        ticket_activities: dict[ViewKey, list[TicketActivity]] | None = None,
        ticket_email_drafts: dict[EmailDraftKey, TicketEmailDraft] | None = None,
        category_options: list[TicketCategoryOption] | None = None,
        status_options_by_category: dict[str, list[TicketStatusOption]] | None = None,
        user_options: list[TicketUserOption] | None = None,
        current_user: TicketUserOption | None = None,
        ticket_grid_column_keys: list[str] | None = None,
        views_error: Exception | None = None,
        tickets_error: Exception | None = None,
        categories_error: Exception | None = None,
        statuses_error: Exception | None = None,
        users_error: Exception | None = None,
        current_user_error: Exception | None = None,
        ticket_grid_column_keys_error: Exception | None = None,
        activities_error: Exception | None = None,
        views_delay: float = 0.0,
        tickets_delay: float = 0.0,
        categories_delay: float = 0.0,
        statuses_delay: float = 0.0,
        users_delay: float = 0.0,
        current_user_delay: float = 0.0,
        ticket_grid_column_keys_delay: float = 0.0,
        activities_delay: float = 0.0,
        store_error: Exception | None = None,
        store_delay: float = 0.0,
        comment_create_error: Exception | None = None,
        comment_create_delay: float = 0.0,
        email_draft_error: Exception | None = None,
        email_draft_delay: float = 0.0,
        email_send_error: Exception | None = None,
        email_send_delay: float = 0.0,
    ) -> None:
        state = initial_state.model_copy(deep=True) if initial_state is not None else None
        self._initial_state = state
        source_views = state.views if state is not None else views or []
        source_tickets = state.tickets if state is not None else tickets or []
        self._views = self._clone_views(source_views)
        self._default_tickets = self._clone_tickets(source_tickets)
        self._category_options = self._clone_category_options(category_options or [])
        self._status_options_by_category = self._clone_status_options_by_category(
            status_options_by_category or {}
        )
        self._user_options = self._clone_user_options(user_options or [])
        self._current_user = current_user.model_copy(deep=True) if current_user is not None else None
        self._ticket_grid_column_keys = self._clone_ticket_grid_column_keys(ticket_grid_column_keys)
        self._ticket_activities = self._clone_ticket_activities(ticket_activities or {})
        self._ticket_email_drafts = self._clone_ticket_email_drafts(ticket_email_drafts or {})
        self._views_error = views_error
        self._default_tickets_error = tickets_error
        self._category_error = categories_error
        self._status_error = statuses_error
        self._user_error = users_error
        self._current_user_error = current_user_error
        self._ticket_grid_column_keys_error = ticket_grid_column_keys_error
        self._default_activity_error = activities_error
        self._views_delay = views_delay
        self._default_tickets_delay = tickets_delay
        self._category_delay = categories_delay
        self._status_delay = statuses_delay
        self._user_delay = users_delay
        self._current_user_delay = current_user_delay
        self._ticket_grid_column_keys_delay = ticket_grid_column_keys_delay
        self._default_activity_delay = activities_delay
        self._store_error = store_error
        self._store_delay = store_delay
        self._comment_create_error = comment_create_error
        self._comment_create_delay = comment_create_delay
        self._email_draft_error = email_draft_error
        self._email_draft_delay = email_draft_delay
        self._email_send_error = email_send_error
        self._email_send_delay = email_send_delay
        self._tickets_by_view: dict[ViewKey, list[Ticket]] = {}
        self._ticket_pages_by_view: dict[PagedViewKey, list[TicketPage]] = {}
        self._ticket_errors_by_view: dict[ViewKey, Exception] = {}
        self._ticket_delays_by_view: dict[ViewKey, float] = {}
        self._activity_errors_by_ticket: dict[ViewKey, Exception] = {}
        self._activity_delays_by_ticket: dict[ViewKey, float] = {}
        self._ticket_activity_attachments: dict[AttachmentKey, bytes] = {}
        self._activity_asset_urls: dict[str, str] = {}
        self._activity_assets: dict[str, bytes] = {}
        self.load_initial_state_calls = 0
        self.list_views_calls = 0
        self.list_tickets_calls: list[ViewKey | None] = []
        self.list_ticket_page_calls: list[tuple[PagedViewKey, int]] = []
        self.list_ticket_activities_calls: list[ViewKey] = []
        self.load_ticket_activity_attachment_calls: list[AttachmentKey] = []
        self.list_ticket_categories_calls = 0
        self.list_ticket_statuses_calls: list[str] = []
        self.list_ticket_users_calls = 0
        self.get_current_user_calls = 0
        self.get_ticket_grid_column_keys_calls = 0
        self.store_ticket_calls: list[tuple[Ticket, TicketEditPatch]] = []
        self.create_ticket_comment_calls: list[tuple[Ticket, TicketCommentCreateRequest]] = []
        self.get_ticket_email_draft_calls: list[tuple[Ticket, TicketActivity, TicketEmailAction]] = []
        self.send_ticket_email_calls: list[tuple[Ticket, TicketEmailSendRequest]] = []
        self.resolve_activity_asset_url_calls: list[str] = []
        self.load_activity_asset_calls: list[str] = []

    @classmethod
    def from_state(cls, app_state: AppState) -> MockTicketConnector:
        """Create a connector from an application state snapshot."""

        return cls(initial_state=app_state)

    async def load_initial_state(self) -> AppState:
        """Return a configured initial state snapshot when available."""

        self.load_initial_state_calls += 1
        if self._initial_state is not None:
            return self._initial_state.model_copy(deep=True)
        return await super().load_initial_state()

    async def list_views(self) -> list[TicketView]:
        """Return the configured views."""

        self.list_views_calls += 1
        if self._views_delay > 0:
            await asyncio.sleep(self._views_delay)
        if self._views_error is not None:
            raise self._views_error
        return self._clone_views(self._views)

    async def list_tickets(self, view: TicketView | None = None) -> list[Ticket]:
        """Return configured tickets for the requested view."""

        view_key = self._view_key(view)
        self.list_tickets_calls.append(view_key)
        await self._maybe_delay_for_view(view_key)
        self._raise_ticket_error_for_view(view_key)
        return self._clone_tickets(self._tickets_for_view_key(view_key))

    async def list_ticket_page(
        self,
        view: TicketView | None = None,
        *,
        page: int = 1,
    ) -> TicketPage:
        """Return a configured ticket page for the requested view."""

        view_key = self._view_key(view)
        self.list_ticket_page_calls.append((view_key, page))

        configured_pages = self._ticket_pages_by_view.get(view_key)
        if not configured_pages:
            tickets = await self.list_tickets(view)
            return TicketPage(
                tickets=tickets,
                pagination=TicketPagination(
                    current_page=1,
                    total_pages=1,
                    total_tickets=len(tickets),
                ),
            )

        await self._maybe_delay_for_view(view_key)
        self._raise_ticket_error_for_view(view_key)

        total_pages = len(configured_pages)
        current_page = min(max(1, page), total_pages)
        ticket_page = configured_pages[current_page - 1].model_copy(deep=True)
        pagination = ticket_page.pagination.model_copy(
            update={
                "current_page": current_page,
                "total_pages": total_pages,
            }
        )
        return ticket_page.model_copy(update={"pagination": pagination})

    async def list_ticket_categories(self) -> list[TicketCategoryOption]:
        """Return configured ticket category options."""

        self.list_ticket_categories_calls += 1
        if self._category_delay > 0:
            await asyncio.sleep(self._category_delay)
        if self._category_error is not None:
            raise self._category_error
        return self._clone_category_options(self._category_options)

    async def list_ticket_users(self) -> list[TicketUserOption]:
        """Return configured ticket user options."""

        self.list_ticket_users_calls += 1
        if self._user_delay > 0:
            await asyncio.sleep(self._user_delay)
        if self._user_error is not None:
            raise self._user_error
        return self._clone_user_options(self._user_options)

    async def list_ticket_statuses(self, category_name: str) -> list[TicketStatusOption]:
        """Return configured ticket status options for the given category."""

        self.list_ticket_statuses_calls.append(category_name)
        if self._status_delay > 0:
            await asyncio.sleep(self._status_delay)
        if self._status_error is not None:
            raise self._status_error
        return self._clone_status_options(self._status_options_by_category.get(category_name, []))

    async def get_current_user(self) -> TicketUserOption | None:
        """Return the configured authenticated app user."""

        self.get_current_user_calls += 1
        if self._current_user_delay > 0:
            await asyncio.sleep(self._current_user_delay)
        if self._current_user_error is not None:
            raise self._current_user_error
        return self._current_user.model_copy(deep=True) if self._current_user is not None else None

    async def get_ticket_grid_column_keys(self) -> list[str] | None:
        """Return the configured ticket-grid column keys."""

        self.get_ticket_grid_column_keys_calls += 1
        if self._ticket_grid_column_keys_delay > 0:
            await asyncio.sleep(self._ticket_grid_column_keys_delay)
        if self._ticket_grid_column_keys_error is not None:
            raise self._ticket_grid_column_keys_error
        return self._clone_ticket_grid_column_keys(self._ticket_grid_column_keys)

    async def list_ticket_activities(self, ticket: Ticket) -> list[TicketActivity]:
        """Return configured ticket activities for the given ticket."""

        ticket_key = self._require_ticket_key(ticket)
        self.list_ticket_activities_calls.append(ticket_key)

        delay = self._activity_delays_by_ticket.get(ticket_key, self._default_activity_delay)
        if delay > 0:
            await asyncio.sleep(delay)

        error = self._activity_errors_by_ticket.get(ticket_key, self._default_activity_error)
        if error is not None:
            raise error

        return self._clone_activities(self._ticket_activities.get(ticket_key, []))

    async def load_ticket_activity_attachment(
        self,
        activity: TicketActivity,
        attachment: TicketActivityAttachment,
    ) -> bytes:
        """Return configured attachment bytes for one activity attachment."""

        attachment_key = self._activity_attachment_key(activity, attachment)
        self.load_ticket_activity_attachment_calls.append(attachment_key)
        if attachment_key not in self._ticket_activity_attachments:
            raise ValueError(
                f"Attachment {attachment.file!r} for activity {activity.name!r} is not configured."
            )
        return self._ticket_activity_attachments[attachment_key]

    async def store_ticket(self, ticket: Ticket, patch: TicketEditPatch) -> Ticket:
        """Persist editable fields in the in-memory collections."""

        self.store_ticket_calls.append(
            (ticket.model_copy(deep=True), patch.model_copy(deep=True))
        )
        if self._store_delay > 0:
            await asyncio.sleep(self._store_delay)
        if self._store_error is not None:
            raise self._store_error

        ticket_key = self._require_ticket_key(ticket)
        saved_ticket = patch.apply_to(ticket)
        default_tickets, default_replaced = self._replace_ticket(self._default_tickets, ticket_key, saved_ticket)
        tickets_by_view: dict[ViewKey, list[Ticket]] = {}
        view_replaced = False
        for view_key, tickets in self._tickets_by_view.items():
            updated_tickets, replaced = self._replace_ticket(tickets, ticket_key, saved_ticket)
            tickets_by_view[view_key] = updated_tickets
            view_replaced = view_replaced or replaced
        ticket_pages_by_view: dict[PagedViewKey, list[TicketPage]] = {}
        page_replaced = False
        for view_key, ticket_pages in self._ticket_pages_by_view.items():
            updated_pages: list[TicketPage] = []
            for ticket_page in ticket_pages:
                updated_tickets, replaced = self._replace_ticket(
                    ticket_page.tickets,
                    ticket_key,
                    saved_ticket,
                )
                updated_pages.append(ticket_page.model_copy(update={"tickets": updated_tickets}))
                page_replaced = page_replaced or replaced
            ticket_pages_by_view[view_key] = updated_pages

        if not default_replaced and not view_replaced and not page_replaced:
            raise ValueError(f"Ticket {ticket_key[1]} is not present in the mock connector.")

        self._initial_state = None
        self._default_tickets = default_tickets
        self._tickets_by_view = tickets_by_view
        self._ticket_pages_by_view = ticket_pages_by_view
        return saved_ticket.model_copy(deep=True)

    async def create_ticket_comment(
        self,
        ticket: Ticket,
        request: TicketCommentCreateRequest,
    ) -> None:
        """Create a comment activity in the in-memory collections."""

        self.create_ticket_comment_calls.append(
            (ticket.model_copy(deep=True), request.model_copy(deep=True))
        )
        if self._comment_create_delay > 0:
            await asyncio.sleep(self._comment_create_delay)
        if self._comment_create_error is not None:
            raise self._comment_create_error

        ticket_key = self._require_ticket_key(ticket)
        if not self._ticket_exists(ticket_key):
            raise ValueError(f"Ticket {ticket_key[1]} is not present in the mock connector.")

        self._initial_state = None
        current_activities = self._ticket_activities.get(ticket_key, [])
        activity = self._build_comment_activity(ticket_key, request, len(current_activities) + 1)
        self._ticket_activities[ticket_key] = [
            activity,
            *self._clone_activities(current_activities),
        ]
        for attachment, upload in zip(activity.downloadable_attachments(), request.attachments, strict=False):
            self.set_ticket_activity_attachment(activity, attachment, upload.content)

    async def get_ticket_email_draft(
        self,
        ticket: Ticket,
        activity: TicketActivity,
        action: TicketEmailAction,
    ) -> TicketEmailDraft:
        """Return a configured or generated email draft."""

        self.get_ticket_email_draft_calls.append(
            (
                ticket.model_copy(deep=True),
                activity.model_copy(deep=True),
                action,
            )
        )
        if self._email_draft_delay > 0:
            await asyncio.sleep(self._email_draft_delay)
        if self._email_draft_error is not None:
            raise self._email_draft_error

        ticket_key = self._require_ticket_key(ticket)
        if not self._ticket_exists(ticket_key):
            raise ValueError(f"Ticket {ticket_key[1]} is not present in the mock connector.")

        draft_key = self._email_draft_key(ticket_key, activity, action)
        configured_draft = self._ticket_email_drafts.get(draft_key)
        if configured_draft is not None:
            return configured_draft.model_copy(deep=True)

        return self._build_email_draft(ticket_key, activity, action)

    async def send_ticket_email(self, ticket: Ticket, request: TicketEmailSendRequest) -> None:
        """Create an outgoing email activity in the in-memory collections."""

        self.send_ticket_email_calls.append(
            (
                ticket.model_copy(deep=True),
                request.model_copy(deep=True),
            )
        )
        if self._email_send_delay > 0:
            await asyncio.sleep(self._email_send_delay)
        if self._email_send_error is not None:
            raise self._email_send_error

        ticket_key = self._require_ticket_key(ticket)
        if not self._ticket_exists(ticket_key):
            raise ValueError(f"Ticket {ticket_key[1]} is not present in the mock connector.")

        self._initial_state = None
        current_activities = self._ticket_activities.get(ticket_key, [])
        self._ticket_activities[ticket_key] = [
            self._build_email_activity(ticket_key, request, len(current_activities) + 1),
            *self._clone_activities(current_activities),
        ]

    def resolve_activity_asset_url(self, url: str) -> str | None:
        """Resolve a configured activity asset URL for tests."""

        self.resolve_activity_asset_url_calls.append(url)
        if url in self._activity_asset_urls:
            return self._activity_asset_urls[url]
        return super().resolve_activity_asset_url(url)

    async def load_activity_asset(self, url: str) -> bytes:
        """Return configured asset bytes for tests."""

        self.load_activity_asset_calls.append(url)
        if url not in self._activity_assets:
            raise ValueError(f"Activity asset {url!r} is not configured in the mock connector.")
        return self._activity_assets[url]

    def set_views(
        self,
        views: list[TicketView],
        *,
        error: Exception | None = None,
        delay: float = 0.0,
    ) -> None:
        """Replace the configured views response."""

        self._initial_state = None
        self._views = self._clone_views(views)
        self._views_error = error
        self._views_delay = delay

    def set_default_tickets(
        self,
        tickets: list[Ticket],
        *,
        error: Exception | None = None,
        delay: float = 0.0,
    ) -> None:
        """Replace the configured default ticket response."""

        self._initial_state = None
        self._default_tickets = self._clone_tickets(tickets)
        self._ticket_pages_by_view.pop(None, None)
        self._default_tickets_error = error
        self._default_tickets_delay = delay

    def set_activity_asset(self, source_url: str, resolved_url: str, content: bytes) -> None:
        """Configure one resolvable activity asset."""

        self._activity_asset_urls[source_url] = resolved_url
        self._activity_assets[resolved_url] = content

    def set_tickets_for_view(
        self,
        view: TicketView,
        tickets: list[Ticket],
        *,
        error: Exception | None = None,
        delay: float = 0.0,
    ) -> None:
        """Set the ticket response for a specific view."""

        self._initial_state = None
        view_key = self._require_view_key(view)
        self._tickets_by_view[view_key] = self._clone_tickets(tickets)
        self._ticket_pages_by_view.pop(view_key, None)
        if error is None:
            self._ticket_errors_by_view.pop(view_key, None)
        else:
            self._ticket_errors_by_view[view_key] = error
        self._ticket_delays_by_view[view_key] = delay

    def set_ticket_pages_for_view(
        self,
        view: TicketView | None,
        pages: list[list[Ticket]],
        *,
        total_tickets: int | None = None,
        error: Exception | None = None,
        delay: float = 0.0,
    ) -> None:
        """Set the paginated ticket response for a view or the default ticket set."""

        self._initial_state = None
        view_key = self._view_key(view)
        if total_tickets is None:
            total_tickets = sum(len(page_tickets) for page_tickets in pages)

        ticket_pages = [
            TicketPage(
                tickets=self._clone_tickets(page_tickets),
                pagination=TicketPagination(
                    current_page=index + 1,
                    total_pages=max(1, len(pages)),
                    total_tickets=total_tickets,
                ),
            )
            for index, page_tickets in enumerate(pages)
        ]
        if not ticket_pages:
            ticket_pages = [
                TicketPage(
                    tickets=[],
                    pagination=TicketPagination(total_tickets=total_tickets),
                )
            ]

        self._ticket_pages_by_view[view_key] = ticket_pages

        if view_key is None:
            self._default_tickets = self._clone_tickets(ticket_pages[0].tickets)
            self._default_tickets_error = error
            self._default_tickets_delay = delay
            return

        self._tickets_by_view[view_key] = self._clone_tickets(ticket_pages[0].tickets)
        if error is None:
            self._ticket_errors_by_view.pop(view_key, None)
        else:
            self._ticket_errors_by_view[view_key] = error
        self._ticket_delays_by_view[view_key] = delay

    def set_ticket_categories(
        self,
        category_options: list[TicketCategoryOption],
        *,
        error: Exception | None = None,
        delay: float = 0.0,
    ) -> None:
        """Replace the configured ticket category response."""

        self._initial_state = None
        self._category_options = self._clone_category_options(category_options)
        self._category_error = error
        self._category_delay = delay

    def set_ticket_statuses(
        self,
        category_name: str,
        status_options: list[TicketStatusOption],
        *,
        error: Exception | None = None,
        delay: float = 0.0,
    ) -> None:
        """Replace the configured ticket status response for one category."""

        self._initial_state = None
        self._status_options_by_category[category_name] = self._clone_status_options(status_options)
        self._status_error = error
        self._status_delay = delay

    def set_ticket_users(
        self,
        user_options: list[TicketUserOption],
        *,
        error: Exception | None = None,
        delay: float = 0.0,
    ) -> None:
        """Replace the configured ticket user response."""

        self._initial_state = None
        self._user_options = self._clone_user_options(user_options)
        self._user_error = error
        self._user_delay = delay

    def set_current_user(
        self,
        current_user: TicketUserOption | None,
        *,
        error: Exception | None = None,
        delay: float = 0.0,
    ) -> None:
        """Replace the configured authenticated app user response."""

        self._current_user = current_user.model_copy(deep=True) if current_user is not None else None
        self._current_user_error = error
        self._current_user_delay = delay

    def set_ticket_grid_column_keys(
        self,
        ticket_grid_column_keys: list[str] | None,
        *,
        error: Exception | None = None,
        delay: float = 0.0,
    ) -> None:
        """Replace the configured ticket-grid column response."""

        self._ticket_grid_column_keys = self._clone_ticket_grid_column_keys(
            ticket_grid_column_keys
        )
        self._ticket_grid_column_keys_error = error
        self._ticket_grid_column_keys_delay = delay

    def set_ticket_activities(
        self,
        ticket: Ticket,
        activities: list[TicketActivity],
        *,
        error: Exception | None = None,
        delay: float = 0.0,
    ) -> None:
        """Replace the configured activities response for one ticket."""

        self._initial_state = None
        ticket_key = self._require_ticket_key(ticket)
        self._ticket_activities[ticket_key] = self._clone_activities(activities)
        if error is None:
            self._activity_errors_by_ticket.pop(ticket_key, None)
        else:
            self._activity_errors_by_ticket[ticket_key] = error
        self._activity_delays_by_ticket[ticket_key] = delay

    def set_ticket_activity_attachment(
        self,
        activity: TicketActivity,
        attachment: TicketActivityAttachment,
        content: bytes,
    ) -> None:
        """Configure one downloadable activity attachment."""

        self._ticket_activity_attachments[self._activity_attachment_key(activity, attachment)] = (
            content
        )

    def set_store_behavior(
        self,
        *,
        error: Exception | None = None,
        delay: float = 0.0,
    ) -> None:
        """Configure save behavior for subsequent ``store_ticket`` calls."""

        self._store_error = error
        self._store_delay = delay

    def set_comment_create_behavior(
        self,
        *,
        error: Exception | None = None,
        delay: float = 0.0,
    ) -> None:
        """Configure create-comment behavior for subsequent calls."""

        self._comment_create_error = error
        self._comment_create_delay = delay

    def set_ticket_email_draft(
        self,
        ticket: Ticket,
        activity: TicketActivity,
        action: TicketEmailAction,
        draft: TicketEmailDraft,
    ) -> None:
        """Store a configured email draft for one ticket/activity/action tuple."""

        self._initial_state = None
        ticket_key = self._require_ticket_key(ticket)
        self._ticket_email_drafts[self._email_draft_key(ticket_key, activity, action)] = (
            draft.model_copy(deep=True)
        )

    def set_email_draft_behavior(
        self,
        *,
        error: Exception | None = None,
        delay: float = 0.0,
    ) -> None:
        """Configure draft-loading behavior for subsequent calls."""

        self._email_draft_error = error
        self._email_draft_delay = delay

    def set_email_send_behavior(
        self,
        *,
        error: Exception | None = None,
        delay: float = 0.0,
    ) -> None:
        """Configure email-send behavior for subsequent calls."""

        self._email_send_error = error
        self._email_send_delay = delay

    @staticmethod
    def _clone_tickets(tickets: list[Ticket]) -> list[Ticket]:
        return [ticket.model_copy(deep=True) for ticket in tickets]

    @staticmethod
    def _clone_views(views: list[TicketView]) -> list[TicketView]:
        return [view.model_copy(deep=True) for view in views]

    @staticmethod
    def _clone_activities(activities: list[TicketActivity]) -> list[TicketActivity]:
        return [activity.model_copy(deep=True) for activity in activities]

    @staticmethod
    def _clone_category_options(
        category_options: list[TicketCategoryOption],
    ) -> list[TicketCategoryOption]:
        return [option.model_copy(deep=True) for option in category_options]

    @staticmethod
    def _clone_user_options(
        user_options: list[TicketUserOption],
    ) -> list[TicketUserOption]:
        return [option.model_copy(deep=True) for option in user_options]

    @staticmethod
    def _clone_status_options(
        status_options: list[TicketStatusOption],
    ) -> list[TicketStatusOption]:
        return [option.model_copy(deep=True) for option in status_options]

    @classmethod
    def _clone_status_options_by_category(
        cls,
        status_options_by_category: dict[str, list[TicketStatusOption]],
    ) -> dict[str, list[TicketStatusOption]]:
        return {
            category_name: cls._clone_status_options(status_options)
            for category_name, status_options in status_options_by_category.items()
        }

    @staticmethod
    def _clone_ticket_grid_column_keys(
        ticket_grid_column_keys: list[str] | None,
    ) -> list[str] | None:
        if ticket_grid_column_keys is None:
            return None
        return list(ticket_grid_column_keys)

    @classmethod
    def _clone_ticket_activities(
        cls,
        ticket_activities: dict[ViewKey, list[TicketActivity]],
    ) -> dict[ViewKey, list[TicketActivity]]:
        return {
            ticket_key: cls._clone_activities(activities)
            for ticket_key, activities in ticket_activities.items()
        }

    @staticmethod
    def _clone_ticket_email_drafts(
        ticket_email_drafts: dict[EmailDraftKey, TicketEmailDraft],
    ) -> dict[EmailDraftKey, TicketEmailDraft]:
        return {
            key: draft.model_copy(deep=True)
            for key, draft in ticket_email_drafts.items()
        }

    def _tickets_for_view_key(self, view_key: PagedViewKey) -> list[Ticket]:
        if view_key is None:
            return self._default_tickets
        return self._tickets_by_view.get(view_key, self._default_tickets)

    async def _maybe_delay_for_view(self, view_key: PagedViewKey) -> None:
        delay = (
            self._default_tickets_delay
            if view_key is None
            else self._ticket_delays_by_view.get(view_key, 0.0)
        )
        if delay > 0:
            await asyncio.sleep(delay)

    def _raise_ticket_error_for_view(self, view_key: PagedViewKey) -> None:
        error = (
            self._default_tickets_error
            if view_key is None
            else self._ticket_errors_by_view.get(view_key)
        )
        if error is not None:
            raise error

    @staticmethod
    def _view_key(view: TicketView | None) -> ViewKey | None:
        if view is None:
            return None
        return view.selection_key()

    @classmethod
    def _require_view_key(cls, view: TicketView) -> ViewKey:
        return cls._view_key(view)  # type: ignore[return-value]

    @staticmethod
    def _ticket_key(ticket: Ticket) -> ViewKey | None:
        if ticket.ticket is not None:
            return ("ticket", str(ticket.ticket))
        if ticket.name is not None:
            return ("name", str(ticket.name))
        return None

    @classmethod
    def _require_ticket_key(cls, ticket: Ticket) -> ViewKey:
        ticket_key = cls._ticket_key(ticket)
        if ticket_key is None:
            raise ValueError("Ticket must include either ticket or name to be stored.")
        return ticket_key

    @classmethod
    def _replace_ticket(
        cls,
        tickets: list[Ticket],
        ticket_key: ViewKey,
        saved_ticket: Ticket,
    ) -> tuple[list[Ticket], bool]:
        output: list[Ticket] = []
        replaced = False
        for current_ticket in tickets:
            if cls._ticket_key(current_ticket) == ticket_key:
                output.append(saved_ticket.model_copy(deep=True))
                replaced = True
            else:
                output.append(current_ticket.model_copy(deep=True))
        return output, replaced

    def _ticket_exists(self, ticket_key: ViewKey) -> bool:
        if any(self._ticket_key(ticket) == ticket_key for ticket in self._default_tickets):
            return True
        if any(
            self._ticket_key(ticket) == ticket_key
            for tickets in self._tickets_by_view.values()
            for ticket in tickets
        ):
            return True
        return any(
            self._ticket_key(ticket) == ticket_key
            for ticket_pages in self._ticket_pages_by_view.values()
            for ticket_page in ticket_pages
            for ticket in ticket_page.tickets
        )

    @staticmethod
    def _email_draft_key(
        ticket_key: ViewKey,
        activity: TicketActivity,
        action: TicketEmailAction,
    ) -> EmailDraftKey:
        return (ticket_key, activity.name or "", action)

    @staticmethod
    def _activity_attachment_key(
        activity: TicketActivity,
        attachment: TicketActivityAttachment,
    ) -> AttachmentKey:
        if activity.name is None:
            raise ValueError("Activity must include a name to configure attachment bytes.")
        return (activity.name, attachment.file)

    def _build_comment_activity(
        self,
        ticket_key: ViewKey,
        request: TicketCommentCreateRequest,
        sequence: int,
    ) -> TicketActivity:
        current_user_name = self._current_user.name if self._current_user is not None else None
        current_user_title = self._current_user.title if self._current_user is not None else None
        attachments = [
            {
                "file": f"mock_comment_attachment_{ticket_key[1]}_{sequence}_{index}",
                "title": attachment.filename,
                "type": attachment.content_type,
                "size": len(attachment.content),
            }
            for index, attachment in enumerate(request.attachments, start=1)
        ]
        return TicketActivity.model_validate(
            {
                "name": f"mock_comment_{ticket_key[1]}_{sequence}",
                "type": "",
                "time": datetime.now().replace(microsecond=0),
                "description": request.body,
                "user": current_user_title,
                "user_name": current_user_name,
                "created_by": current_user_title,
                "created_by_name": current_user_name,
                "attachments": attachments or None,
                "item": None,
            }
        )

    def _build_email_draft(
        self,
        ticket_key: ViewKey,
        activity: TicketActivity,
        action: TicketEmailAction,
    ) -> TicketEmailDraft:
        subject_source = activity.title or (activity.item.title if activity.item is not None else "") or ""
        if action == TicketEmailAction.REPLY:
            subject = self._prefixed_subject(subject_source, "Re: ", prefixes=("re:",))
            to = activity.item.address if activity.item is not None and activity.item.address else ""
        else:
            subject = self._prefixed_subject(subject_source, "Fwd: ", prefixes=("fwd:", "fw:"))
            to = ""

        source_activity_name = activity.name or f"mock_activity_{ticket_key[1]}"
        source_email_name = (
            activity.item.name
            if activity.item is not None and activity.item.name
            else f"mock_email_{ticket_key[1]}"
        )
        queue_name = (
            activity.item.queue_name
            if activity.item is not None and activity.item.queue_name
            else "mock_queue"
        )
        return TicketEmailDraft(
            action=action,
            source_activity_name=source_activity_name,
            source_email_name=source_email_name,
            to=to,
            subject=subject,
            body="",
            queue_name=queue_name,
        )

    @staticmethod
    def _prefixed_subject(
        subject: str,
        prefix: str,
        *,
        prefixes: tuple[str, ...],
    ) -> str:
        normalized = subject.strip()
        if not normalized:
            return ""
        if normalized.casefold().startswith(prefixes):
            return normalized
        return f"{prefix}{normalized}"

    def _build_email_activity(
        self,
        ticket_key: ViewKey,
        request: TicketEmailSendRequest,
        sequence: int,
    ) -> TicketActivity:
        current_user_name = self._current_user.name if self._current_user is not None else None
        current_user_title = self._current_user.title if self._current_user is not None else None
        activity_time = datetime.now().replace(microsecond=0)
        return TicketActivity.model_validate(
            {
                "name": f"mock_email_{ticket_key[1]}_{sequence}",
                "type": "EMAIL",
                "title": request.subject,
                "time": activity_time,
                "description": request.body,
                "user": current_user_title,
                "user_name": current_user_name,
                "created_by": current_user_title,
                "created_by_name": current_user_name,
                "item": {
                    "name": f"mock_email_item_{ticket_key[1]}_{sequence}",
                    "model": "activitiesEmail",
                    "title": request.subject,
                    "time": activity_time,
                    "description": request.body,
                    "body_html": request.body,
                    "address": request.to,
                    "queue_name": request.queue_name,
                    "direction": "out",
                    "state": "SENT",
                },
            }
        )
