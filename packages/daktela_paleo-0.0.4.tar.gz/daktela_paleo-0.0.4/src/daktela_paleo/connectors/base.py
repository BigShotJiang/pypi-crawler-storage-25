"""Abstract connector interface for ticket data sources."""

from __future__ import annotations

from abc import ABC, abstractmethod
from urllib.parse import urlparse

import httpx

from daktela_paleo.models import (
    AppState,
    Ticket,
    TicketActivity,
    TicketActivityAttachment,
    TicketCategoryOption,
    TicketCommentCreateRequest,
    TicketEmailAction,
    TicketEmailDraft,
    TicketEmailSendRequest,
    TicketEditPatch,
    TicketPage,
    TicketPagination,
    TicketStatusOption,
    TicketUserOption,
    TicketView,
)


class TicketConnector(ABC):
    """Application-facing interface for loading ticket data."""

    @abstractmethod
    async def list_views(self) -> list[TicketView]:
        """Return the available ticket views."""

    @abstractmethod
    async def list_tickets(self, view: TicketView | None = None) -> list[Ticket]:
        """Return tickets for the given view."""

    async def list_ticket_page(
        self,
        view: TicketView | None = None,
        *,
        page: int = 1,
    ) -> TicketPage:
        """Return one ticket page for the given view."""

        del page
        tickets = await self.list_tickets(view)
        return TicketPage(
            tickets=tickets,
            pagination=TicketPagination(
                current_page=1,
                total_pages=1,
                total_tickets=len(tickets),
            ),
        )

    @abstractmethod
    async def list_ticket_categories(self) -> list[TicketCategoryOption]:
        """Return selectable ticket categories."""

    @abstractmethod
    async def list_ticket_users(self) -> list[TicketUserOption]:
        """Return selectable ticket users."""

    async def get_current_user(self) -> TicketUserOption | None:
        """Return the authenticated app user when the connector can resolve it."""

        return None

    async def get_ticket_grid_column_keys(self) -> list[str] | None:
        """Return configured ticket-grid column keys when the connector can resolve them."""

        return None

    @abstractmethod
    async def list_ticket_statuses(self, category_name: str) -> list[TicketStatusOption]:
        """Return selectable ticket statuses for the given category."""

    @abstractmethod
    async def list_ticket_activities(self, ticket: Ticket) -> list[TicketActivity]:
        """Return activities for the given ticket."""

    @abstractmethod
    async def load_ticket_activity_attachment(
        self,
        activity: TicketActivity,
        attachment: TicketActivityAttachment,
    ) -> bytes:
        """Load one ticket-activity attachment binary payload."""

    @abstractmethod
    async def store_ticket(self, ticket: Ticket, patch: TicketEditPatch) -> Ticket:
        """Persist editable ticket fields and return the saved ticket."""

    @abstractmethod
    async def create_ticket_comment(
        self,
        ticket: Ticket,
        request: TicketCommentCreateRequest,
    ) -> None:
        """Create a comment activity for ``ticket``."""

    @abstractmethod
    async def get_ticket_email_draft(
        self,
        ticket: Ticket,
        activity: TicketActivity,
        action: TicketEmailAction,
    ) -> TicketEmailDraft:
        """Return a prefilled email draft for ``ticket`` and ``activity``."""

    @abstractmethod
    async def send_ticket_email(self, ticket: Ticket, request: TicketEmailSendRequest) -> None:
        """Send a ticket email through the backing system."""

    def ticket_browser_url(self, ticket: Ticket) -> str | None:
        """Return a browser URL for ``ticket`` when the connector supports it."""

        return None

    def view_browser_url(self, view: TicketView) -> str | None:
        """Return a browser URL for ``view`` when the connector supports it."""

        return None

    def resolve_activity_asset_url(self, url: str) -> str | None:
        """Resolve an activity asset URL into an absolute, fetchable target."""

        parsed = urlparse(url)
        if parsed.scheme in {"http", "https"}:
            return url
        return None

    async def load_activity_asset(self, url: str) -> bytes:
        """Load an activity asset binary payload."""

        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.get(url)
            response.raise_for_status()
            return response.content

    async def load_initial_state(self) -> AppState:
        """Return the initial application state."""

        views = await self.list_views()
        tickets = await self.list_tickets()
        return AppState(
            tickets=tickets,
            views=views,
            active_view=None,
            active_ticket=None,
        )
