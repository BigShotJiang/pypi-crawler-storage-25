"""Ticket connector implementations."""

from daktela_paleo.connectors.base import TicketConnector
from daktela_paleo.connectors.daktela import DaktelaTicketConnector
from daktela_paleo.connectors.demo import DemoTicketConnector
from daktela_paleo.connectors.mock import MockTicketConnector
from daktela_paleo.models import (
    TicketActivity,
    TicketActivityAttachment,
    TicketCategoryOption,
    TicketCommentAttachmentUpload,
    TicketCommentCreateRequest,
    TicketPage,
    TicketPagination,
    TicketStatusOption,
    TicketUserOption,
)

__all__ = [
    "DaktelaTicketConnector",
    "DemoTicketConnector",
    "MockTicketConnector",
    "TicketActivity",
    "TicketActivityAttachment",
    "TicketCategoryOption",
    "TicketCommentAttachmentUpload",
    "TicketCommentCreateRequest",
    "TicketStatusOption",
    "TicketUserOption",
    "TicketConnector",
    "TicketPage",
    "TicketPagination",
]
