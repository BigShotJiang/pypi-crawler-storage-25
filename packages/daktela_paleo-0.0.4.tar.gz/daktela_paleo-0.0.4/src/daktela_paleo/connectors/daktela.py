"""Daktela connector scaffold derived from the mailbot connector client."""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, MutableMapping
from urllib.parse import parse_qsl, urlencode, urljoin, urlparse, urlunparse

import httpx

from daktela_paleo.connectors.base import TicketConnector
from daktela_paleo.instances import normalize_daktela_base_url
from daktela_paleo.models import (
    Ticket,
    TicketActivity,
    TicketActivityAttachment,
    TicketActivityItem,
    TicketCategoryOption,
    TicketCommentAttachmentUpload,
    TicketCommentCreateRequest,
    TicketEmailAction,
    TicketEmailDraft,
    TicketEmailSendRequest,
    TicketEditPatch,
    TicketPage,
    TicketPagination,
    TicketPriority,
    TicketStatusOption,
    TicketStage,
    TicketUserOption,
    TicketView,
    normalize_ticket_grid_column_keys,
    format_editable_datetime,
)

logger = logging.getLogger(__name__)

DEFAULT_PAGE_SIZE = 100
VIEW_TICKET_QUERY_LIMIT = 200


class DaktelaConnectorError(RuntimeError):
    """Base connector error for Daktela integration."""


class BadTokenDaktelaError(DaktelaConnectorError):
    """Raised when Daktela rejects the configured access token."""


class CantConnectToDaktelaError(DaktelaConnectorError):
    """Raised when the Daktela API cannot be reached."""


@dataclass(frozen=True)
class DaktelaWhoAmI:
    """Subset of the mailbot who-am-i payload used by the connector."""

    title: str
    alias: str | None
    description: str | None
    major_version: int
    minor_version: int


@dataclass(frozen=True)
class DaktelaEmailDetails:
    """Normalized Daktela email payload used for draft and send helpers."""

    activity_name: str | None
    email_name: str
    subject: str
    address: str | None
    queue_name: str
    queue_address: str | None
    header_to_all: tuple[str, ...]
    reply_to_all: tuple[str, ...]


def flatten(
    dictionary: MutableMapping[str, Any],
    parent_key: str | bool = False,
    separator: str = ".",
    separator_suffix: str = "",
) -> dict[str, Any]:
    """Flatten nested params using the mailbot connector strategy."""

    items: list[tuple[str, Any]] = []
    for key, value in dictionary.items():
        new_key = (
            f"{parent_key}{separator}{key}{separator_suffix}"
            if parent_key
            else key
        )
        if isinstance(value, MutableMapping):
            items.extend(flatten(value, new_key, separator, separator_suffix).items())
        elif isinstance(value, list | tuple):
            for child_index, child_value in enumerate(value):
                items.extend(
                    flatten(
                        {str(child_index): child_value},
                        new_key,
                        separator,
                        separator_suffix,
                    ).items()
                )
        else:
            items.append((new_key, value))

    return dict(items)


class DaktelaTicketConnector(TicketConnector):
    """Scaffold for a real Daktela-backed ticket connector."""

    def __init__(self, pbx_name: str, user_token: str) -> None:
        self.pbx_name = self._normalize_pbx_name(pbx_name)
        self.user_token = user_token

    async def list_views(self) -> list[TicketView]:
        """Return ticket views joined with the hierarchy from the who-am-I payload."""

        whoiam_result = await self._get_whoiam_result()
        custom_views = whoiam_result.get("user", {}).get("profile", {}).get("customViews")
        if not isinstance(custom_views, dict):
            logger.warning("Daktela whoim payload is missing user.profile.customViews.")
            return []

        ticket_view_payloads = await self._get_ticket_view_payloads_by_name()
        views = self._build_ticket_views(custom_views, ticket_view_payloads)
        return await self._fill_missing_ticket_view_counts(views)

    async def list_tickets(self, view: TicketView | None = None) -> list[Ticket]:
        """Return tickets for the selected Daktela view."""

        if view is None:
            raise NotImplementedError(
                "Daktela ticket loading is not scaffolded from the mailbot client yet."
            )

        filters = self._ticket_query_params_for_view(view)
        return await self.fetch_filtered_tickets(
            filters,
            max_objects=VIEW_TICKET_QUERY_LIMIT,
        )

    async def list_ticket_page(
        self,
        view: TicketView | None = None,
        *,
        page: int = 1,
    ) -> TicketPage:
        """Return one ticket page for the selected Daktela view."""

        if view is None:
            raise NotImplementedError(
                "Daktela ticket loading is not scaffolded from the mailbot client yet."
            )

        if page <= 1 and (view.ticket_count is None or view.ticket_count <= DEFAULT_PAGE_SIZE):
            tickets = await self.list_tickets(view)
            return TicketPage(
                tickets=tickets,
                pagination=TicketPagination(
                    current_page=1,
                    total_pages=1,
                    total_tickets=view.ticket_count if view.ticket_count is not None else len(tickets),
                ),
            )

        filters = self._ticket_query_params_for_view(view)
        payloads, pagination = await self.get_ticket_page_by_filter(filters, page=page)
        return TicketPage(
            tickets=[self._ticket_from_payload(payload) for payload in payloads],
            pagination=pagination,
        )

    async def list_ticket_categories(self) -> list[TicketCategoryOption]:
        """Return selectable Daktela ticket categories."""

        payloads = await self._get_objects_paged("/api/v6/ticketsCategories.json")
        return [
            TicketCategoryOption.model_validate(
                {
                    "name": payload["name"],
                    "title": payload["title"],
                }
            )
            for payload in payloads
            if isinstance(payload.get("name"), str) and isinstance(payload.get("title"), str)
        ]

    async def list_ticket_users(self) -> list[TicketUserOption]:
        """Return selectable Daktela ticket users."""

        payloads = await self._get_objects_paged("/api/v6/users.json")
        return [
            TicketUserOption.model_validate(
                {
                    "name": payload["name"],
                    "title": payload.get("title") or payload["name"],
                }
            )
            for payload in payloads
            if isinstance(payload.get("name"), str)
        ]

    async def get_current_user(self) -> TicketUserOption | None:
        """Return the authenticated Daktela operator."""

        result = await self._get_whoiam_result()
        user_payload = result.get("user", {})
        if not isinstance(user_payload, Mapping):
            return None

        name = user_payload.get("name")
        title = user_payload.get("title") or name
        if not isinstance(name, str) or not isinstance(title, str):
            return None

        return TicketUserOption(name=name, title=title)

    async def get_ticket_grid_column_keys(self) -> list[str] | None:
        """Return the configured Daktela ticket-grid column order."""

        result = await self._get_whoiam_result()
        return self._ticket_grid_column_keys_from_whoiam_result(result)

    async def list_ticket_statuses(self, category_name: str) -> list[TicketStatusOption]:
        """Return selectable Daktela ticket statuses for the given category."""

        payloads = await self._get_objects_paged(
            f"/api/v6/ticketsCategories/{category_name}/statuses.json"
        )
        return [
            TicketStatusOption.model_validate(
                {
                    "name": payload["name"],
                    "title": payload.get("title") or payload["name"],
                }
            )
            for payload in payloads
            if isinstance(payload.get("name"), str)
        ]

    async def list_ticket_activities(self, ticket: Ticket) -> list[TicketActivity]:
        """Return activities for the given ticket."""

        ticket_id = self._ticket_identifier(ticket)
        payloads = await self._get_objects_paged(f"/api/v6/tickets/{ticket_id}/activities.json")
        return [self._activity_from_payload(payload) for payload in payloads]

    async def load_ticket_activity_attachment(
        self,
        activity: TicketActivity,
        attachment: TicketActivityAttachment,
    ) -> bytes:
        """Load one Daktela activity attachment using private token auth."""

        download_path = self._activity_attachment_download_path(activity, attachment)
        response = await self._send_get_private_request(download_path)
        if response.status_code >= 400:
            raise DaktelaConnectorError(
                f"Daktela activity attachment download failed with status {response.status_code}."
            )
        return response.content

    async def store_ticket(self, ticket: Ticket, patch: TicketEditPatch) -> Ticket:
        """Persist editable ticket fields and return the saved ticket."""

        ticket_id = self._ticket_identifier(ticket)
        payload = self._store_payload_from_patch(patch)
        response = await self._send_request(
            "PUT",
            self._authenticated_url(f"/api/v6/tickets/{ticket_id}.json"),
            json=payload,
        )
        if response.status_code >= 400:
            raise DaktelaConnectorError(
                f"Daktela ticket update failed with status {response.status_code}."
            )
        return self._ticket_from_payload(self._ticket_payload_from_response(response.json()))

    async def create_ticket_comment(
        self,
        ticket: Ticket,
        request: TicketCommentCreateRequest,
    ) -> None:
        """Create a comment activity for the given ticket."""

        ticket_id = self._ticket_identifier(ticket)
        if request.attachments:
            upload_names = [
                await self._upload_comment_attachment(attachment)
                for attachment in request.attachments
            ]
            response = await self._send_request(
                "PUT",
                self._authenticated_url(f"/api/v6/tickets/{ticket_id}.json"),
                json=self._comment_with_attachments_payload(request, upload_names),
            )
        else:
            response = await self._send_request(
                "POST",
                self._authenticated_url("/api/v6/activities.json"),
                json=self._comment_payload(ticket_id, request.body),
            )
        self._validated_response_payload(response, "Daktela comment creation failed")

    async def get_ticket_email_draft(
        self,
        ticket: Ticket,
        activity: TicketActivity,
        action: TicketEmailAction,
    ) -> TicketEmailDraft:
        """Return a connector-provided draft for an email reply or forward."""

        del ticket
        email = await self._get_email_details_for_activity(activity)
        to = ""
        subject = ""
        if action == TicketEmailAction.REPLY:
            to = ", ".join(self._reply_recipients(email))
            subject = self._reply_subject(email.subject)
        elif action == TicketEmailAction.FORWARD:
            subject = self._forward_subject(email.subject)
        else:
            raise ValueError(f"Unsupported ticket email action: {action!r}")

        return TicketEmailDraft(
            action=action,
            source_activity_name=email.activity_name or activity.name,
            source_email_name=email.email_name,
            to=to,
            subject=subject,
            body="",
            queue_name=email.queue_name,
        )

    async def send_ticket_email(self, ticket: Ticket, request: TicketEmailSendRequest) -> None:
        """Send a reply or forward email for the given ticket."""

        if request.action == TicketEmailAction.REPLY:
            await self._send_reply_email(ticket, request)
            return
        if request.action == TicketEmailAction.FORWARD:
            await self._send_forward_email(ticket, request)
            return
        raise ValueError(f"Unsupported ticket email action: {request.action!r}")

    def ticket_browser_url(self, ticket: Ticket) -> str | None:
        """Return the Daktela browser URL for ``ticket``."""

        ticket_id = ticket.name or ticket.ticket
        if ticket_id is None:
            return None
        return f"{self.pbx_name}/tickets/update/{ticket_id}"

    def view_browser_url(self, view: TicketView) -> str | None:
        """Return the Daktela browser URL for ``view``."""

        if view.name is None:
            return None
        return f"{self.pbx_name}/tickets/#{view.name}"

    def resolve_activity_asset_url(self, url: str) -> str | None:
        """Resolve Daktela activity assets to authenticated absolute URLs."""

        parsed = urlparse(url)
        if parsed.scheme in {"http", "https"}:
            return self._append_access_token(url)
        if parsed.scheme:
            return None
        return self._append_access_token(urljoin(f"{self.pbx_name}/", url.lstrip("/")))

    async def load_activity_asset(self, url: str) -> bytes:
        """Load a Daktela activity asset using the configured connector auth."""

        resolved_url = self.resolve_activity_asset_url(url)
        if resolved_url is None:
            raise DaktelaConnectorError(f"Unsupported activity asset URL: {url}")

        response = await self._send_request("GET", resolved_url)
        if response.status_code >= 400:
            raise DaktelaConnectorError(
                f"Daktela activity asset load failed with status {response.status_code}."
            )
        return response.content

    async def get_whoiam(self) -> DaktelaWhoAmI:
        """Return the authenticated Daktela user and parsed version."""

        result = await self._get_whoiam_result()

        try:
            version = result["version"]["current"]
            version_split = version.split(".")
            major_version = int(version_split[0])
            minor_version = int(version_split[1])
        except Exception as error:
            logger.warning("Error while parsing Daktela version from whoim: %s", error)
            major_version = 0
            minor_version = 0

        return DaktelaWhoAmI(
            title=result["user"]["title"],
            alias=result["user"].get("alias"),
            description=result["user"].get("description"),
            major_version=major_version,
            minor_version=minor_version,
        )

    async def get_tickets_by_filter(
        self,
        filters: dict[str, Any],
        *,
        max_objects: int | None = None,
    ) -> list[dict[str, Any]]:
        """Return raw paged tickets for the given Daktela filter."""

        return await self._get_objects_paged(
            "/api/v6/tickets",
            params=filters,
            max_objects=max_objects,
        )

    async def get_ticket_page_by_filter(
        self,
        filters: dict[str, Any],
        *,
        page: int = 1,
    ) -> tuple[list[dict[str, Any]], TicketPagination]:
        """Return raw paged tickets and pagination metadata for the given filter."""

        return await self._get_objects_page(
            "/api/v6/tickets",
            params=filters,
            page=page,
        )

    async def fetch_filtered_tickets(
        self,
        filters: dict[str, Any],
        *,
        max_objects: int | None = None,
    ) -> list[Ticket]:
        """Return validated ticket models for the given Daktela filter."""

        payloads = await self.get_tickets_by_filter(filters, max_objects=max_objects)
        return [self._ticket_from_payload(payload) for payload in payloads]

    async def _get_whoiam_result(self) -> dict[str, Any]:
        response = await self._send_get_request("/api/v6/whoim.json")
        result = response.json().get("result")
        if not isinstance(result, dict):
            logger.warning("Daktela whoim payload did not contain a JSON object result.")
            return {}
        return result

    async def _get_ticket_view_payloads_by_name(self) -> dict[str, dict[str, Any]]:
        payloads = await self._get_objects_paged("/api/v6/ticketsViews.json")
        views_by_name: dict[str, dict[str, Any]] = {}
        for payload in payloads:
            name = payload.get("name")
            if not isinstance(name, str):
                logger.warning("Skipping Daktela ticketsViews payload without a string name: %r", payload)
                continue
            views_by_name[name] = payload
        return views_by_name

    async def _fill_missing_ticket_view_counts(self, views: list[TicketView]) -> list[TicketView]:
        missing_count_views = [view for view in views if view.ticket_count is None]
        if not missing_count_views:
            return views

        resolved_counts = await asyncio.gather(
            *(self._ticket_count_for_view(view) for view in missing_count_views)
        )
        counts_by_key = {
            view.selection_key(): count
            for view, count in zip(missing_count_views, resolved_counts, strict=False)
            if count is not None
        }
        return [
            view.model_copy(update={"ticket_count": counts_by_key[view.selection_key()]})
            if view.selection_key() in counts_by_key
            else view
            for view in views
        ]

    async def _ticket_count_for_view(self, view: TicketView) -> int | None:
        try:
            return await self._get_total_objects(
                "/api/v6/tickets",
                params=self._filters_for_view(view),
            )
        except Exception as error:
            logger.warning(
                "Unable to load ticket count for Daktela view %s: %s",
                view.name or view.title,
                error,
            )
            return None

    async def _send_request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                response = await client.request(method, url, **kwargs)
                if response.status_code == 401:
                    raise BadTokenDaktelaError()
                return response
        except httpx.HTTPError as error:
            logger.exception("Cant connect to Daktela: %s", error)
            raise CantConnectToDaktelaError() from error

    async def _send_get_request(self, url: str, **kwargs: Any) -> httpx.Response:
        final_url = self._authenticated_url(url)
        additional_params = kwargs.pop("additional_params", "")
        if additional_params:
            final_url += f"&{additional_params}"
        return await self._send_request("GET", final_url, **kwargs)

    async def _send_get_private_request(self, url: str, **kwargs: Any) -> httpx.Response:
        final_url = f"{self.pbx_name}{url}"
        additional_params = kwargs.pop("additional_params", "")
        if additional_params:
            final_url += f"?{additional_params}"

        headers = dict(kwargs.pop("headers", {}))
        headers["X-Auth-Token"] = self.user_token
        return await self._send_request("GET", final_url, headers=headers, **kwargs)

    async def _send_get_request_v2(
        self,
        url: str,
        params: dict[str, Any] | None = None,
        *,
        page_size: int = 100,
        page: int = 1,
    ) -> httpx.Response:
        final_params = dict(params or {})
        if "accessToken" not in final_params:
            final_params["accessToken"] = self.user_token

        final_params["pageSize"] = page_size
        final_params["page"] = page
        final_params["take"] = page_size
        final_params["skip"] = (page - 1) * page_size

        query_params = urlencode(flatten(final_params, False, "[", "]"))
        full_url = f"{self.pbx_name}{url}?{query_params}"

        try:
            async with httpx.AsyncClient(timeout=20) as client:
                response = await client.get(full_url)
                if response.status_code == 401:
                    raise BadTokenDaktelaError()
                return response
        except httpx.HTTPError as error:
            logger.exception("Cant connect to Daktela: %s", error)
            raise CantConnectToDaktelaError() from error

    async def _get_objects_paged(
        self,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        max_objects: int | None = None,
    ) -> list[dict[str, Any]]:
        response = await self._send_get_request_v2(url, params, page_size=1)
        result = self._response_result_object(response.json(), url)
        total = self._response_total(result, url)
        if total <= 0:
            return []

        effective_total = total if max_objects is None else min(total, max_objects)
        pages = (effective_total + DEFAULT_PAGE_SIZE - 1) // DEFAULT_PAGE_SIZE

        output: list[dict[str, Any]] = []
        for page in range(1, pages + 1):
            response = await self._send_get_request_v2(
                url,
                params,
                page_size=DEFAULT_PAGE_SIZE,
                page=page,
            )
            output.extend(self._response_data(response.json(), url))
        if max_objects is not None:
            return output[:max_objects]
        return output

    async def _get_objects_page(
        self,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        page: int = 1,
        page_size: int = DEFAULT_PAGE_SIZE,
    ) -> tuple[list[dict[str, Any]], TicketPagination]:
        total = await self._get_total_objects(url, params=params)
        if total <= 0:
            return [], TicketPagination(total_tickets=0)

        total_pages = max(1, (total + page_size - 1) // page_size)
        current_page = min(max(1, page), total_pages)
        response = await self._send_get_request_v2(
            url,
            params,
            page_size=page_size,
            page=current_page,
        )
        return self._response_data(response.json(), url), TicketPagination(
            current_page=current_page,
            total_pages=total_pages,
            total_tickets=total,
        )

    async def _get_total_objects(
        self,
        url: str,
        *,
        params: dict[str, Any] | None = None,
    ) -> int:
        response = await self._send_get_request_v2(url, params, page_size=1)
        return self._response_total(self._response_result_object(response.json(), url), url)

    @staticmethod
    def _response_result_object(payload: dict[str, Any], url: str) -> dict[str, Any]:
        result = payload.get("result")
        if not isinstance(result, dict):
            raise DaktelaConnectorError(f"Daktela {url} payload did not contain an object result.")
        return result

    @staticmethod
    def _response_total(result: dict[str, Any], url: str) -> int:
        total = result.get("total")
        if not isinstance(total, int) or isinstance(total, bool) or total < 0:
            raise DaktelaConnectorError(f"Daktela {url} payload did not contain a valid total.")
        return total

    @staticmethod
    def _response_data(payload: dict[str, Any], url: str) -> list[dict[str, Any]]:
        result = DaktelaTicketConnector._response_result_object(payload, url)
        data = result.get("data")
        if not isinstance(data, list):
            raise DaktelaConnectorError(f"Daktela {url} payload did not contain a data list.")
        if not all(isinstance(item, dict) for item in data):
            raise DaktelaConnectorError(f"Daktela {url} payload did not contain object data items.")
        return data

    @staticmethod
    def _normalize_pbx_name(pbx_name: str) -> str:
        return normalize_daktela_base_url(pbx_name)

    def _authenticated_url(self, url: str) -> str:
        return f"{self.pbx_name}{url}?accessToken={self.user_token}"

    def _append_access_token(self, url: str) -> str:
        parsed = urlparse(url)
        query_params = dict(parse_qsl(parsed.query, keep_blank_values=True))
        if "accessToken" not in query_params:
            query_params["accessToken"] = self.user_token
        query = urlencode(query_params)
        return urlunparse(parsed._replace(query=query))

    @classmethod
    def _build_ticket_views(
        cls,
        hierarchy: dict[str, Any],
        payloads_by_name: dict[str, dict[str, Any]],
        *,
        parent_name: str | None = None,
    ) -> list[TicketView]:
        output: list[TicketView] = []
        for name, node in sorted(hierarchy.items(), key=cls._custom_view_sort_key):
            if not isinstance(node, Mapping):
                logger.warning("Skipping Daktela custom view %s with invalid hierarchy node.", name)
                continue

            payload = payloads_by_name.get(name)
            if payload is None:
                logger.warning(
                    "Skipping Daktela custom view %s because ticketsViews metadata is missing.",
                    name,
                )
                continue

            output.append(cls._ticket_view_from_payload(payload, parent_name=parent_name))

            children = node.get("children")
            if isinstance(children, dict):
                output.extend(
                    cls._build_ticket_views(
                        children,
                        payloads_by_name,
                        parent_name=name,
                    )
                )
        return output

    @staticmethod
    def _custom_view_sort_key(item: tuple[str, Any]) -> tuple[int, str]:
        name, node = item
        if isinstance(node, Mapping) and isinstance(node.get("index"), int):
            return (node["index"], name)
        return (0, name)

    @classmethod
    def _ticket_view_from_payload(
        cls,
        payload: dict[str, Any],
        *,
        parent_name: str | None,
    ) -> TicketView:
        return TicketView.model_validate(
            {
                "name": payload["name"],
                "title": payload["title"],
                "ticket_count": cls._normalize_ticket_view_count(
                    payload.get("count"),
                    view_name=payload["name"],
                ),
                "description": payload.get("description"),
                "parent_view": parent_name,
                "filter": cls._normalize_ticket_view_filter(
                    payload.get("filter"),
                    view_name=payload["name"],
                ),
                "sort": cls._normalize_ticket_view_sort(
                    payload.get("sort"),
                    view_name=payload["name"],
                ),
            }
        )

    @staticmethod
    def _ticket_grid_column_keys_from_whoiam_result(
        result: Mapping[str, Any],
    ) -> list[str] | None:
        custom_grid_columns = result.get("customGridColumns")
        if not isinstance(custom_grid_columns, Mapping):
            user_payload = result.get("user")
            if not isinstance(user_payload, Mapping):
                return None

            profile_payload = user_payload.get("profile")
            if not isinstance(profile_payload, Mapping):
                return None

            custom_grid_columns = profile_payload.get("customGridColumns")
        if not isinstance(custom_grid_columns, Mapping):
            return None

        ticket_grid_columns = custom_grid_columns.get("tickets")
        if not isinstance(ticket_grid_columns, list):
            return None

        configured_column_keys: list[str] = []
        for item in ticket_grid_columns:
            if not isinstance(item, Mapping):
                continue
            if item.get("alias") != "tickets":
                continue

            name = item.get("name")
            if isinstance(name, str):
                configured_column_keys.append(name)

        return normalize_ticket_grid_column_keys(configured_column_keys)

    @staticmethod
    def _normalize_ticket_view_filter(
        raw_filter: Any,
        *,
        view_name: str,
    ) -> dict[str, Any] | None:
        if raw_filter is None:
            return None
        if isinstance(raw_filter, dict):
            return raw_filter
        if raw_filter == []:
            return None

        logger.warning(
            "Ignoring unsupported filter payload for Daktela view %s: %r",
            view_name,
            raw_filter,
        )
        return None

    @staticmethod
    def _normalize_ticket_view_sort(
        raw_sort: Any,
        *,
        view_name: str,
    ) -> dict[str, str] | None:
        if raw_sort is None:
            return None
        if not isinstance(raw_sort, Mapping):
            logger.warning(
                "Ignoring unsupported sort payload for Daktela view %s: %r",
                view_name,
                raw_sort,
            )
            return None

        raw_field = raw_sort.get("field")
        raw_direction = raw_sort.get("dir")
        if not isinstance(raw_field, str) or not raw_field.strip():
            logger.warning(
                "Ignoring unsupported sort payload for Daktela view %s: %r",
                view_name,
                raw_sort,
            )
            return None
        if not isinstance(raw_direction, str):
            logger.warning(
                "Ignoring unsupported sort payload for Daktela view %s: %r",
                view_name,
                raw_sort,
            )
            return None

        normalized_direction = raw_direction.strip().casefold()
        if normalized_direction not in {"asc", "desc"}:
            logger.warning(
                "Ignoring unsupported sort payload for Daktela view %s: %r",
                view_name,
                raw_sort,
            )
            return None

        return {
            "field": raw_field.strip(),
            "dir": normalized_direction,
        }

    @classmethod
    def _ticket_query_params_for_view(cls, view: TicketView) -> dict[str, Any]:
        params = cls._filters_for_view(view)
        normalized_sort = cls._normalize_ticket_view_sort(
            view.sort,
            view_name=view.name or view.title,
        )
        if normalized_sort is None:
            return params

        return {
            **params,
            "sort": normalized_sort,
        }

    @staticmethod
    def _normalize_ticket_view_count(
        raw_count: Any,
        *,
        view_name: str,
    ) -> int | None:
        if raw_count is None:
            return None
        if isinstance(raw_count, bool):
            logger.warning(
                "Ignoring unsupported count payload for Daktela view %s: %r",
                view_name,
                raw_count,
            )
            return None
        if isinstance(raw_count, int):
            return raw_count
        if isinstance(raw_count, float) and raw_count.is_integer():
            return int(raw_count)
        if isinstance(raw_count, str):
            normalized_count = raw_count.strip()
            if normalized_count:
                try:
                    return int(normalized_count)
                except ValueError:
                    pass

        logger.warning(
            "Ignoring unsupported count payload for Daktela view %s: %r",
            view_name,
            raw_count,
        )
        return None

    @staticmethod
    def _ticket_from_payload(payload: dict[str, Any]) -> Ticket:
        normalized_payload = dict(payload)
        normalized_payload["id_merge"] = _ticket_reference_value(payload.get("id_merge"))
        normalized_payload["category"] = _nested_name(
            payload.get("category"),
            fallback_keys=("title", "name"),
        )
        normalized_payload["category_name"] = _nested_name(payload.get("category"))
        normalized_payload["contact"] = _nested_name(
            payload.get("contact"),
            fallback_keys=("title", "name"),
        )
        normalized_payload["user"] = _blank_to_none(
            _nested_name(
                payload.get("user"),
                fallback_keys=("title", "alias", "name"),
            )
        )
        normalized_payload["user_name"] = _blank_to_none(
            _nested_name(
                payload.get("user"),
                fallback_keys=("name", "alias", "title"),
            )
        )
        normalized_payload["created_by"] = _nested_name(payload.get("created_by"))
        normalized_payload["edited_by"] = _blank_to_none(
            _nested_name(
                payload.get("edited_by"),
                fallback_keys=("title", "alias", "name"),
            )
        )
        normalized_payload["parentTicket"] = _nested_name(
            payload.get("parentTicket"),
            fallback_keys=("name", "title"),
        )
        normalized_payload["statuses"] = _nested_named_string_map(
            payload.get("statuses"),
        )
        normalized_payload["followers"] = _nested_string_list(payload.get("followers"))
        normalized_payload["mergeTickets"] = _nested_string_list(
            payload.get("mergeTickets"),
            fallback_keys=("name", "title", "ticket"),
        )
        normalized_payload["children"] = _nested_string_list(
            payload.get("children"),
            fallback_keys=("name", "title", "ticket"),
        )
        normalized_payload["activities"] = _nested_string_list(
            payload.get("activities"),
            fallback_keys=("name", "title", "activity"),
        )
        normalized_payload["records"] = _nested_string_list(
            payload.get("records"),
            fallback_keys=("name", "title", "record"),
        )
        normalized_payload["snapshots"] = _nested_string_list(
            payload.get("snapshots"),
            fallback_keys=("name", "title", "snapshot"),
        )
        normalized_payload["customFields"] = _normalize_custom_fields(
            payload.get("customFields"),
            _custom_field_scheme_map_from_payload(payload),
        )
        return Ticket.model_validate(normalized_payload)

    @staticmethod
    def _activity_from_payload(payload: dict[str, Any]) -> TicketActivity:
        normalized_payload = {
            "name": _nested_name(
                payload.get("name"),
                fallback_keys=("name", "title"),
            ),
            "type": _string_value(payload.get("type")),
            "title": _blank_to_none(_string_value(payload.get("title"))),
            "time": payload.get("time"),
            "action": _blank_to_none(_string_value(payload.get("action"))),
            "description": _blank_to_none(_string_value(payload.get("description"))),
            "user": _blank_to_none(
                _nested_name(
                    payload.get("user"),
                    fallback_keys=("title", "alias", "name"),
                )
            ),
            "user_name": _blank_to_none(
                _nested_name(
                    payload.get("user"),
                    fallback_keys=("name", "alias", "title"),
                )
            ),
            "created_by": _blank_to_none(
                _nested_name(
                    payload.get("created_by"),
                    fallback_keys=("title", "alias", "name"),
                )
            ),
            "created_by_name": _blank_to_none(
                _nested_name(
                    payload.get("created_by"),
                    fallback_keys=("name", "alias", "title"),
                )
            ),
            "attachments": payload.get("attachments"),
            "item": DaktelaTicketConnector._activity_item_from_payload(payload.get("item")),
        }
        return TicketActivity.model_validate(normalized_payload)

    @staticmethod
    def _activity_item_from_payload(payload: Any) -> TicketActivityItem | None:
        if not isinstance(payload, dict):
            return None

        normalized_payload = {
            "name": _blank_to_none(
                _nested_name(
                    payload.get("name"),
                    fallback_keys=("name", "title"),
                )
            ),
            "model": _blank_to_none(_sys_model(payload)),
            "title": _blank_to_none(_string_value(payload.get("title"))),
            "time": payload.get("time"),
            "description": _blank_to_none(
                _string_value(payload.get("description") or payload.get("content"))
            ),
            "body_html": _blank_to_none(_string_value(payload.get("text"))),
            "address": _blank_to_none(_string_value(payload.get("address"))),
            "queue_name": _blank_to_none(
                _nested_name(
                    payload.get("queue"),
                    fallback_keys=("name", "title", "queue"),
                )
            ),
            "direction": _blank_to_none(_string_value(payload.get("direction"))),
            "state": _blank_to_none(_string_value(payload.get("state"))),
            "attachments": payload.get("attachments"),
        }
        return TicketActivityItem.model_validate(normalized_payload)

    @staticmethod
    def _activity_attachment_download_path(
        activity: TicketActivity,
        attachment: TicketActivityAttachment,
    ) -> str:
        if activity.type == "EMAIL":
            mapper = "activitiesEmail"
        elif activity.display_type == "Comment":
            mapper = "activitiesComment"
        else:
            raise DaktelaConnectorError(
                "Selected Daktela activity does not support attachment downloads."
            )

        return f"/file/download.php?mapper={mapper}&name={attachment.file}&download=1"

    @staticmethod
    def _filters_for_view(view: TicketView) -> dict[str, Any]:
        if view.name is not None:
            return {
                "filter": {
                    "logic": "and",
                    "filters": [
                        {
                            "field": "_ticketView",
                            "operator": "eq",
                            "value": view.name,
                        }
                    ],
                }
            }

        if view.filter is not None:
            return {"filter": view.filter}

        raise ValueError("Daktela ticket view must include either a name or filter payload.")

    @staticmethod
    def _ticket_identifier(ticket: Ticket) -> int:
        if ticket.ticket is not None:
            return ticket.ticket
        if ticket.name is not None:
            return ticket.name
        raise ValueError("Ticket must include either ticket or name to be stored.")

    @staticmethod
    def _store_payload_from_patch(patch: TicketEditPatch) -> dict[str, Any]:
        payload = patch.model_dump(exclude_unset=True)
        if "stage" in payload:
            payload["stage"] = TicketStage(payload["stage"]).value
        if "priority" in payload:
            payload["priority"] = TicketPriority(payload["priority"]).value
        if "reopen" in patch.model_fields_set:
            payload["reopen"] = format_editable_datetime(patch.reopen)
        payload.pop("category_title", None)
        if "category_name" in payload:
            payload["category"] = payload.pop("category_name")
        status_name = payload.pop("status_name", None)
        payload.pop("status_title", None)
        if "status_name" in patch.model_fields_set or "status_title" in patch.model_fields_set:
            payload["statuses"] = [] if status_name is None else [status_name]
        payload.pop("user_title", None)
        if "user_name" in payload:
            payload["user"] = payload.pop("user_name") or ""
        if "description" in payload and payload["description"] is None:
            payload["description"] = ""
        return payload

    @staticmethod
    def _comment_payload(ticket_id: int, content: str) -> dict[str, Any]:
        return {
            "ticket": ticket_id,
            "type": "",
            "description": content,
        }

    async def _upload_comment_attachment(
        self,
        attachment: TicketCommentAttachmentUpload,
    ) -> str:
        response = await self._send_request(
            "POST",
            f"{self.pbx_name}/file/upload.php?type=save&accessToken={self.user_token}",
            files={
                "files": (
                    attachment.filename,
                    attachment.content,
                    attachment.content_type or "application/octet-stream",
                )
            },
        )
        if response.status_code >= 400:
            raise DaktelaConnectorError(
                f"Daktela comment attachment upload failed with status {response.status_code}."
            )

        payload = response.json()
        if isinstance(payload, str) and payload.strip():
            return payload
        raise DaktelaConnectorError("Daktela comment attachment upload did not return a file ID.")

    @staticmethod
    def _comment_with_attachments_payload(
        request: TicketCommentCreateRequest,
        upload_names: list[str],
    ) -> dict[str, Any]:
        attachments: dict[str, dict[str, Any]] = {}
        for index, (attachment, upload_name) in enumerate(
            zip(request.attachments, upload_names, strict=True),
            start=1,
        ):
            uid = f"attachment_{index}"
            attachments[uid] = {
                "_uid": uid,
                "name": upload_name,
                "title": attachment.filename,
                "size": len(attachment.content),
                "type": attachment.content_type or "application/octet-stream",
            }

        return {
            "comment": request.body,
            "comment_add_files": attachments,
        }

    @staticmethod
    def _reply_email_payload(ticket_id: int, request: TicketEmailSendRequest) -> dict[str, Any]:
        return {
            "type": "EMAIL",
            "ticket": ticket_id,
            "subject": request.subject,
            "message": request.body,
            "to": request.to,
            "queue": request.queue_name,
            "duration": 0,
            "sendMail": True,
        }

    @staticmethod
    def _forward_open_payload(source_email_name: str) -> dict[str, Any]:
        return {
            "action": "OPEN",
            "options": {
                "item": {
                    "model": "activitiesEmail",
                    "name": source_email_name,
                },
                "replyAction": "forward",
            },
            "type": "EMAIL",
        }

    @staticmethod
    def _forward_close_payload(
        request: TicketEmailSendRequest,
        message: str,
    ) -> dict[str, Any]:
        return {
            "to": request.to,
            "message": message,
            "queue": request.queue_name,
            "subject": request.subject,
            "action": "CLOSE",
            "sendMail": True,
        }

    async def _send_reply_email(self, ticket: Ticket, request: TicketEmailSendRequest) -> None:
        ticket_id = self._ticket_identifier(ticket)
        response = await self._send_request(
            "POST",
            self._authenticated_url("/api/v6/activities.json"),
            json=self._reply_email_payload(ticket_id, request),
        )
        self._validated_response_payload(response, "Daktela email send failed")

    async def _send_forward_email(self, ticket: Ticket, request: TicketEmailSendRequest) -> None:
        del ticket
        forward_activity_name, original_message = await self._open_forward_activity(
            request.source_email_name
        )
        response = await self._send_request(
            "PUT",
            self._authenticated_url(f"/api/v6/activities/{forward_activity_name}.json"),
            json=self._forward_close_payload(
                request,
                self._merge_forward_message(request.body, original_message),
            ),
        )
        self._validated_response_payload(response, "Daktela email forward send failed")

    async def _get_email_details_for_activity(self, activity: TicketActivity) -> DaktelaEmailDetails:
        email_name = self._email_name_from_activity(activity)
        if email_name is None and activity.name is not None:
            activity_payload = await self._get_activity_payload(activity.name)
            email_name = self._email_name_from_activity_payload(activity_payload)

        if email_name is None:
            raise DaktelaConnectorError(
                "Daktela email draft loading failed: selected activity does not reference an email item."
            )

        email_payload = await self._get_email_payload(email_name)
        return self._email_details_from_payload(
            email_payload,
            source_email_name=email_name,
            fallback_activity_name=activity.name,
        )

    async def _get_activity_payload(self, activity_name: str) -> dict[str, Any]:
        response = await self._send_get_request(f"/api/v6/activities/{activity_name}.json")
        payload = self._validated_response_payload(
            response,
            "Daktela email draft loading failed while resolving activity details",
        )
        return self._result_object(
            payload,
            "Daktela email draft loading failed: activity detail payload was missing a result object.",
        )

    async def _get_email_payload(self, email_name: str) -> dict[str, Any]:
        response = await self._send_get_request(
            f"/api/v6/activitiesEmail/{email_name}.json",
            additional_params="",
        )
        payload = self._validated_response_payload(response, "Daktela email draft loading failed")
        return self._result_object(
            payload,
            "Daktela email draft loading failed: email detail payload was missing a result object.",
        )

    async def _open_forward_activity(self, source_email_name: str) -> tuple[str, str]:
        response = await self._send_request(
            "POST",
            self._authenticated_url("/api/v6/activities.json"),
            json=self._forward_open_payload(source_email_name),
        )
        payload = self._validated_response_payload(
            response,
            "Daktela email forward initialization failed",
        )
        result = self._result_object(
            payload,
            "Daktela email forward initialization failed: missing result object.",
        )
        forward_activity_name = _blank_to_none(_string_value(result.get("name")))
        if forward_activity_name is None:
            raise DaktelaConnectorError(
                "Daktela email forward initialization failed: missing forwarded activity name."
            )

        original_message = self._forward_original_message_from_result(result)
        if original_message is None:
            original_message = await self._get_original_email_message(forward_activity_name)
        return forward_activity_name, original_message

    async def _get_original_email_message(self, activity_name: str) -> str:
        try:
            response = await self._send_get_private_request(
                f"/internal/activity/{activity_name}/originalMessage"
            )
        except DaktelaConnectorError:
            logger.warning("Unable to load original Daktela message for forwarded activity %s.", activity_name)
            return ""

        if response.status_code >= 400:
            logger.warning(
                "Original Daktela message request for %s failed with status %s.",
                activity_name,
                response.status_code,
            )
            return ""

        try:
            payload = response.json()
        except ValueError:
            logger.warning("Original Daktela message for %s did not contain JSON.", activity_name)
            return ""

        result = payload.get("result")
        if isinstance(result, str):
            return result
        logger.warning(
            "Original Daktela message for %s did not contain a string result.",
            activity_name,
        )
        return ""

    @classmethod
    def _validated_response_payload(
        cls,
        response: httpx.Response,
        error_prefix: str,
    ) -> dict[str, Any]:
        if response.status_code >= 400:
            try:
                payload = response.json()
            except ValueError:
                payload = None
            error = cls._response_error(payload)
            if error is not None:
                raise DaktelaConnectorError(f"{error_prefix}: {error}")
            raise DaktelaConnectorError(
                f"{error_prefix} with status {response.status_code}."
            )

        payload = response.json()
        error = cls._response_error(payload)
        if error is not None:
            raise DaktelaConnectorError(f"{error_prefix}: {error}")
        return payload

    @staticmethod
    def _result_object(payload: dict[str, Any], error_message: str) -> dict[str, Any]:
        result = payload.get("result")
        if isinstance(result, dict):
            return result
        raise DaktelaConnectorError(error_message)

    @staticmethod
    def _email_name_from_activity(activity: TicketActivity) -> str | None:
        if activity.item is None or activity.item.model != "activitiesEmail":
            return None
        return activity.item.name

    @staticmethod
    def _email_name_from_activity_payload(payload: dict[str, Any]) -> str | None:
        item = payload.get("item")
        if not isinstance(item, dict):
            return None
        if _sys_model(item) != "activitiesEmail":
            return None
        return _blank_to_none(
            _nested_name(
                item.get("name"),
                fallback_keys=("name", "title"),
            )
        )

    @classmethod
    def _email_details_from_payload(
        cls,
        payload: dict[str, Any],
        *,
        source_email_name: str,
        fallback_activity_name: str | None,
    ) -> DaktelaEmailDetails:
        queue_payload = payload.get("queue")
        if isinstance(queue_payload, dict):
            queue_name = _blank_to_none(_string_value(queue_payload.get("name")))
            if queue_name is None:
                queue_name = _blank_to_none(_string_value(queue_payload.get("title")))
            if queue_name is None:
                queue_name = _blank_to_none(_string_value(queue_payload.get("queue")))
        else:
            queue_name = _blank_to_none(
                _nested_name(
                    queue_payload,
                    fallback_keys=("name", "title", "queue"),
                )
            )
        if queue_name is None:
            raise DaktelaConnectorError(
                "Daktela email draft loading failed: email detail payload was missing a queue."
            )

        queue_options = payload.get("queue", {})
        queue_address = None
        if isinstance(queue_options, dict):
            options = queue_options.get("options")
            if isinstance(options, dict):
                queue_address = _blank_to_none(_string_value(options.get("address")))

        headers = payload.get("options", {})
        header_payload = headers.get("headers") if isinstance(headers, dict) else None

        activity_name = fallback_activity_name
        activities = payload.get("activities")
        if isinstance(activities, list) and activities:
            activity_name = _blank_to_none(
                _nested_name(
                    activities[0],
                    fallback_keys=("name", "title"),
                )
            ) or activity_name

        return DaktelaEmailDetails(
            activity_name=activity_name,
            email_name=source_email_name,
            subject=_blank_to_none(_string_value(payload.get("title"))) or "",
            address=_blank_to_none(_string_value(payload.get("address"))),
            queue_name=queue_name,
            queue_address=queue_address,
            header_to_all=cls._header_addresses(header_payload, "to"),
            reply_to_all=cls._header_addresses(header_payload, "reply-to"),
        )

    @staticmethod
    def _header_addresses(payload: Any, header_name: str) -> tuple[str, ...]:
        if not isinstance(payload, dict):
            return ()

        addresses = payload.get(header_name)
        if not isinstance(addresses, list):
            return ()

        output: list[str] = []
        for address in addresses:
            if not isinstance(address, dict):
                continue
            normalized = _blank_to_none(_string_value(address.get("address")))
            if normalized is not None:
                output.append(normalized)
        return tuple(output)

    @staticmethod
    def _reply_recipients(email: DaktelaEmailDetails) -> tuple[str, ...]:
        if email.reply_to_all:
            return email.reply_to_all
        if email.address:
            return (email.address,)
        if email.header_to_all:
            return email.header_to_all
        if email.queue_address:
            return (email.queue_address,)
        return ()

    @staticmethod
    def _reply_subject(subject: str) -> str:
        return DaktelaTicketConnector._prefixed_subject(subject, "Re: ", prefixes=("re:",))

    @staticmethod
    def _forward_subject(subject: str) -> str:
        return DaktelaTicketConnector._prefixed_subject(
            subject,
            "Fwd: ",
            prefixes=("fwd:", "fw:"),
        )

    @staticmethod
    def _prefixed_subject(
        subject: str,
        prefix: str,
        *,
        prefixes: tuple[str, ...],
    ) -> str:
        normalized = subject.strip()
        if not normalized:
            return ""
        if normalized.casefold().startswith(prefixes):
            return normalized
        return f"{prefix}{normalized}"

    @staticmethod
    def _forward_original_message_from_result(result: dict[str, Any]) -> str | None:
        options = result.get("options")
        if not isinstance(options, dict):
            return None
        return _blank_to_none(_string_value(options.get("message")))

    @staticmethod
    def _merge_forward_message(body: str, original_message: str) -> str:
        if body and original_message:
            return f"{body}<br/>{original_message}"
        if original_message:
            return original_message
        return body

    @staticmethod
    def _ticket_payload_from_response(payload: dict[str, Any]) -> dict[str, Any]:
        result = payload.get("result")
        if isinstance(result, dict):
            data = result.get("data")
            if isinstance(data, dict):
                return data
            if isinstance(data, list) and data and isinstance(data[0], dict):
                return data[0]
            return result
        raise DaktelaConnectorError("Daktela ticket update did not return a ticket payload.")

    @staticmethod
    def _response_error(payload: Any) -> str | None:
        if not isinstance(payload, dict):
            return None

        error = payload.get("error")
        if error in (None, [], {}, ""):
            return None

        if isinstance(error, str):
            return error
        if isinstance(error, list):
            return "; ".join(str(item) for item in error)
        if isinstance(error, dict):
            return "; ".join(f"{key}: {value}" for key, value in error.items())
        return str(error)


def _nested_name(
    value: Any,
    *,
    fallback_keys: tuple[str, ...] = ("name",),
) -> str | None:
    if value is None:
        return None
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        for key in fallback_keys:
            nested_value = value.get(key)
            if isinstance(nested_value, str):
                return nested_value
    return None


def _string_value(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, str):
        return value
    if isinstance(value, int | float):
        return str(value)
    return None


def _sys_model(value: Any) -> str | None:
    if not isinstance(value, dict):
        return None
    sys_data = value.get("_sys")
    if not isinstance(sys_data, dict):
        return None
    model = sys_data.get("model")
    if isinstance(model, str):
        return model
    return None


def _ticket_reference_value(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, str):
        return value
    if isinstance(value, int | float):
        return str(value)
    if not isinstance(value, Mapping):
        return None

    for key in ("name", "ticket"):
        nested_value = value.get(key)
        if isinstance(nested_value, str):
            return nested_value
        if isinstance(nested_value, int | float):
            return str(nested_value)

    return None


def _nested_string_list(
    value: Any,
    *,
    fallback_keys: tuple[str, ...] = ("name",),
) -> list[str] | None:
    if value is None:
        return None
    if not isinstance(value, list):
        return None

    normalized: list[str] = []
    for item in value:
        if isinstance(item, str):
            normalized.append(item)
            continue
        if isinstance(item, int):
            normalized.append(str(item))
            continue
        nested_value = _nested_name(item, fallback_keys=fallback_keys)
        if nested_value is not None:
            normalized.append(nested_value)

    return normalized


def _nested_named_string_map(value: Any) -> dict[str, str] | None:
    if value is None:
        return None
    if not isinstance(value, list):
        return None

    normalized: dict[str, str] = {}
    for item in value:
        if isinstance(item, str):
            normalized[item] = item
            continue
        if not isinstance(item, Mapping):
            continue

        key = item.get("name")
        label = item.get("title")
        if isinstance(key, str) and isinstance(label, str):
            normalized[key] = label

    return normalized or None


def _custom_field_scheme_map_from_payload(
    payload: Mapping[str, Any],
) -> dict[str, Mapping[str, Any]]:
    sys_payload = payload.get("_sys")
    if not isinstance(sys_payload, Mapping):
        return {}
    return _normalize_custom_field_scheme_map(sys_payload.get("cfScheme"))


def _normalize_custom_field_scheme_map(value: Any) -> dict[str, Mapping[str, Any]]:
    if isinstance(value, Mapping):
        direct_entries = {
            str(field): entry
            for field, entry in value.items()
            if isinstance(entry, Mapping)
        }
        if direct_entries:
            return direct_entries

        for key in ("fields", "items", "data", "customFields"):
            nested_value = value.get(key)
            if nested_value is None:
                continue
            nested_entries = _normalize_custom_field_scheme_map(nested_value)
            if nested_entries:
                return nested_entries
        return {}

    if not isinstance(value, list):
        return {}

    normalized: dict[str, Mapping[str, Any]] = {}
    for item in value:
        if not isinstance(item, Mapping):
            continue
        field_name = item.get("field", item.get("name", item.get("key", item.get("id"))))
        if isinstance(field_name, str):
            normalized[field_name] = item
    return normalized


def _normalize_custom_fields(
    value: Any,
    scheme_by_field: Mapping[str, Mapping[str, Any]] | None = None,
) -> list[dict[str, Any]] | None:
    if value is None:
        return None
    if isinstance(value, list):
        return value
    if not isinstance(value, dict):
        return None

    scheme_by_field = {} if scheme_by_field is None else dict(scheme_by_field)
    return [
        {
            "field": key,
            "title": _custom_field_title(key, scheme_by_field.get(key)),
            "values": _custom_field_values(field_value),
            "field_type": _custom_field_type(scheme_by_field.get(key)),
            "options": _normalize_custom_field_options(
                _custom_field_option_source(scheme_by_field.get(key))
            ),
        }
        for key, field_value in value.items()
    ]


def _custom_field_title(field_name: str, scheme_entry: Mapping[str, Any] | None) -> str:
    if isinstance(scheme_entry, Mapping):
        for key in ("title", "label", "text"):
            title = scheme_entry.get(key)
            if isinstance(title, str) and title:
                return title
    return field_name


def _custom_field_type(scheme_entry: Mapping[str, Any] | None) -> str | None:
    if not isinstance(scheme_entry, Mapping):
        return None
    for key in ("type", "fieldType", "dataType"):
        field_type = scheme_entry.get(key)
        if isinstance(field_type, str) and field_type:
            return field_type
    return None


def _custom_field_values(value: Any) -> list[Any]:
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    return [value]


def _custom_field_option_source(
    scheme_entry: Mapping[str, Any] | None,
) -> Any:
    if not isinstance(scheme_entry, Mapping):
        return None
    for key in ("options", "items", "choices", "allowedValues"):
        if key in scheme_entry:
            return scheme_entry.get(key)
    return None


def _normalize_custom_field_options(value: Any) -> list[dict[str, Any]] | None:
    if value is None:
        return None

    if isinstance(value, Mapping):
        normalized = [
            {
                "value": option_value,
                "title": option_title if isinstance(option_title, str) else str(option_title),
            }
            for option_value, option_title in value.items()
        ]
        return normalized or None

    if not isinstance(value, list | tuple):
        return None

    normalized: list[dict[str, Any]] = []
    for item in value:
        if isinstance(item, Mapping):
            option_value = item.get("value", item.get("name", item.get("key", item.get("id"))))
            if option_value is None:
                continue
            option_title = item.get(
                "title",
                item.get("label", item.get("text", item.get("name", option_value))),
            )
            normalized.append(
                {
                    "value": option_value,
                    "title": option_title if isinstance(option_title, str) else str(option_title),
                }
            )
            continue
        normalized.append(
            {
                "value": item,
                "title": item if isinstance(item, str) else str(item),
            }
        )

    return normalized or None


def _blank_to_none(value: str | None) -> str | None:
    if value == "":
        return None
    return value
