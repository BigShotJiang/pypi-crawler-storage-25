"""Application theme definitions."""

from textual.theme import Theme


TOKYONIGHT_MOON = Theme(
    name="tokyonight-moon",
    primary="#82AAFF",
    secondary="#C099FF",
    warning="#FFC777",
    error="#FF757F",
    success="#C3E88D",
    accent="#86E1FC",
    foreground="#C8D3F5",
    background="#1E2030",
    surface="#222436",
    panel="#2F334D",
    boost="#2A2D44",
    dark=True,
    variables={
        "text-muted": "#828BB8",
        "foreground-muted": "#828BB8",
        "border": "#3B4261",
        "border-blurred": "#2F334D",
        "block-cursor-background": "#2F334D",
        "block-cursor-foreground": "#C8D3F5",
        "block-cursor-text-style": "none",
        "block-cursor-blurred-background": "#2A2D44",
        "block-cursor-blurred-foreground": "#828BB8",
        "block-cursor-blurred-text-style": "none",
        "block-hover-background": "#2F334D66",
        "surface-active": "#2A2D44",
        "footer-background": "#222436",
        "footer-foreground": "#C8D3F5",
        "footer-key-foreground": "#82AAFF",
        "footer-description-foreground": "#828BB8",
        "input-selection-background": "#3B426166",
        "button-color-foreground": "#222436",
    },
)
