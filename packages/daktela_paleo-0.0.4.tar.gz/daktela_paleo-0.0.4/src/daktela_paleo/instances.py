"""Persistent configuration for saved Daktela instances."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from tempfile import NamedTemporaryFile
from uuid import uuid4

from platformdirs import user_config_path
from pydantic import BaseModel, Field, ValidationError, field_validator, model_validator

APP_NAME = "daktela-paleo"
INSTANCE_CONFIG_FILE_NAME = "instances.json"
INSTANCE_CONFIG_VERSION = 1

logger = logging.getLogger(__name__)


def normalize_daktela_base_url(base_url: str) -> str:
    """Return a normalized Daktela base URL."""

    normalized = base_url.strip().rstrip("/")
    if not normalized.startswith(("http://", "https://")):
        normalized = f"https://{normalized}"
    return normalized


def default_instance_config_path() -> Path:
    """Return the default persisted instance config path."""

    return user_config_path(APP_NAME) / INSTANCE_CONFIG_FILE_NAME


class DaktelaInstanceRecord(BaseModel):
    """A saved Daktela instance definition."""

    id: str = Field(min_length=1)
    base_url: str = Field(min_length=1)
    user_token: str = Field(min_length=1)

    @field_validator("base_url")
    @classmethod
    def normalize_base_url(cls, base_url: str) -> str:
        """Normalize the saved base URL."""

        return normalize_daktela_base_url(base_url)

    @classmethod
    def create(
        cls,
        base_url: str,
        user_token: str,
        *,
        id: str | None = None,
    ) -> DaktelaInstanceRecord:
        """Build a new saved instance record."""

        return cls(
            id=id or uuid4().hex,
            base_url=base_url,
            user_token=user_token,
        )


class DaktelaInstanceConfig(BaseModel):
    """Persisted Daktela instance state."""

    version: int = INSTANCE_CONFIG_VERSION
    active_instance_id: str | None = None
    instances: list[DaktelaInstanceRecord] = Field(default_factory=list)

    @model_validator(mode="after")
    def clear_missing_active_instance(self) -> DaktelaInstanceConfig:
        """Clear active selection when it no longer points at a saved instance."""

        if self.active_instance_id is None:
            return self

        if any(instance.id == self.active_instance_id for instance in self.instances):
            return self

        self.active_instance_id = None
        return self

    def active_instance(self) -> DaktelaInstanceRecord | None:
        """Return the currently selected saved instance."""

        if self.active_instance_id is None:
            return None

        for instance in self.instances:
            if instance.id == self.active_instance_id:
                return instance
        return None

    def with_saved_instance(
        self,
        base_url: str,
        user_token: str,
        *,
        activate: bool = False,
    ) -> tuple[DaktelaInstanceConfig, DaktelaInstanceRecord]:
        """Return a config with a saved instance added or reused."""

        normalized_base_url = normalize_daktela_base_url(base_url)
        existing = self.instance_for_credentials(normalized_base_url, user_token)
        if existing is not None:
            active_instance_id = existing.id if activate else self.active_instance_id
            return (
                DaktelaInstanceConfig(
                    version=self.version,
                    active_instance_id=active_instance_id,
                    instances=[instance.model_copy(deep=True) for instance in self.instances],
                ),
                existing.model_copy(deep=True),
            )

        record = DaktelaInstanceRecord.create(normalized_base_url, user_token)
        active_instance_id = record.id if activate else self.active_instance_id
        return (
            DaktelaInstanceConfig(
                version=self.version,
                active_instance_id=active_instance_id,
                instances=[
                    *(instance.model_copy(deep=True) for instance in self.instances),
                    record,
                ],
            ),
            record.model_copy(deep=True),
        )

    def with_active_instance(self, instance_id: str | None) -> DaktelaInstanceConfig:
        """Return a config with the given saved instance set active."""

        return DaktelaInstanceConfig(
            version=self.version,
            active_instance_id=instance_id,
            instances=[instance.model_copy(deep=True) for instance in self.instances],
        )

    def instance_for_credentials(
        self,
        base_url: str,
        user_token: str,
    ) -> DaktelaInstanceRecord | None:
        """Return the saved instance matching the normalized URL and token."""

        normalized_base_url = normalize_daktela_base_url(base_url)
        for instance in self.instances:
            if (
                instance.base_url == normalized_base_url
                and instance.user_token == user_token
            ):
                return instance
        return None


class DaktelaInstanceStore:
    """Load and save persisted Daktela instance configuration."""

    def __init__(self, path: Path | None = None) -> None:
        self.path = path or default_instance_config_path()

    def load(self) -> DaktelaInstanceConfig:
        """Load the persisted instance config, tolerating malformed files."""

        if not self.path.exists():
            return DaktelaInstanceConfig()

        try:
            raw_text = self.path.read_text(encoding="utf-8")
        except OSError as error:
            logger.warning("Unable to read Daktela instance config %s: %s", self.path, error)
            return DaktelaInstanceConfig()

        if not raw_text.strip():
            return DaktelaInstanceConfig()

        try:
            payload = json.loads(raw_text)
        except json.JSONDecodeError as error:
            logger.warning("Ignoring malformed Daktela instance config %s: %s", self.path, error)
            return DaktelaInstanceConfig()

        if not isinstance(payload, dict):
            logger.warning("Ignoring unexpected Daktela instance config payload: %r", payload)
            return DaktelaInstanceConfig()

        return self._config_from_payload(payload)

    def save(self, config: DaktelaInstanceConfig) -> None:
        """Persist the given instance config atomically."""

        prepared = DaktelaInstanceConfig.model_validate(config.model_dump(mode="python"))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(prepared.model_dump(mode="json"), indent=2)

        temp_path: Path | None = None
        try:
            with NamedTemporaryFile(
                "w",
                encoding="utf-8",
                dir=self.path.parent,
                delete=False,
            ) as handle:
                handle.write(f"{payload}\n")
                temp_path = Path(handle.name)
            temp_path.replace(self.path)
        finally:
            if temp_path is not None and temp_path.exists():
                temp_path.unlink()

    @staticmethod
    def _config_from_payload(payload: dict[str, object]) -> DaktelaInstanceConfig:
        version = payload.get("version")
        active_instance_id = payload.get("active_instance_id")
        raw_instances = payload.get("instances")

        instances: list[DaktelaInstanceRecord] = []
        if isinstance(raw_instances, list):
            for raw_instance in raw_instances:
                try:
                    instances.append(DaktelaInstanceRecord.model_validate(raw_instance))
                except ValidationError as error:
                    logger.warning("Ignoring invalid saved Daktela instance: %s", error)

        return DaktelaInstanceConfig(
            version=version if isinstance(version, int) else INSTANCE_CONFIG_VERSION,
            active_instance_id=active_instance_id if isinstance(active_instance_id, str) else None,
            instances=instances,
        )


__all__ = [
    "APP_NAME",
    "DaktelaInstanceConfig",
    "DaktelaInstanceRecord",
    "DaktelaInstanceStore",
    "INSTANCE_CONFIG_FILE_NAME",
    "INSTANCE_CONFIG_VERSION",
    "default_instance_config_path",
    "normalize_daktela_base_url",
]
