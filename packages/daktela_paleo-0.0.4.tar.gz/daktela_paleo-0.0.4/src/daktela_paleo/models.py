"""Pydantic models for Daktela API payloads."""

from __future__ import annotations

import html
import re
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from html.parser import HTMLParser
from typing import Any, Self

from markdownify import markdownify as html_to_markdown
from pydantic import (
    AliasChoices,
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
)


class TicketStage(str, Enum):
    """Ticket processing stages defined by the Daktela API."""

    OPEN = "OPEN"
    WAIT = "WAIT"
    CLOSE = "CLOSE"
    ARCHIVE = "ARCHIVE"

    @property
    def display_label(self) -> str:
        """Return a human-readable label for the stage."""

        return TICKET_STAGE_DISPLAY_LABELS[self]


class TicketPriority(str, Enum):
    """Ticket priority levels defined by the Daktela API."""

    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"

    @property
    def display_label(self) -> str:
        """Return a human-readable label for the priority."""

        return TICKET_PRIORITY_DISPLAY_LABELS[self]

    @property
    def table_value(self) -> int:
        """Return the numeric priority value used by the ticket table."""

        return TICKET_PRIORITY_TABLE_VALUES[self]


TICKET_STAGE_DISPLAY_LABELS = {
    TicketStage.OPEN: "Open",
    TicketStage.WAIT: "Waiting",
    TicketStage.CLOSE: "Closed",
    TicketStage.ARCHIVE: "Archived",
}

TICKET_PRIORITY_DISPLAY_LABELS = {
    TicketPriority.HIGH: "High",
    TicketPriority.MEDIUM: "Medium",
    TicketPriority.LOW: "Low",
}

TICKET_PRIORITY_TABLE_VALUES = {
    TicketPriority.HIGH: 1,
    TicketPriority.MEDIUM: 2,
    TicketPriority.LOW: 3,
}

TICKET_GRID_REQUIRED_COLUMN_KEYS = (
    "name",
    "title",
)

TICKET_GRID_SUPPORTED_COLUMN_KEYS = (
    "name",
    "title",
    "priority",
    "sla_deadtime",
    "category.title",
    "contact.title",
    "user.title",
    "statuses",
    "stage",
    "edited",
    "edited_by",
)

TICKET_GRID_DEFAULT_COLUMN_KEYS = (
    "name",
    "title",
    "priority",
    "category.title",
    "statuses",
    "contact.title",
    "stage",
    "user.title",
    "edited",
)


def normalize_ticket_grid_column_keys(column_keys: object) -> list[str]:
    """Return a safe ordered ticket-grid column list."""

    if column_keys is None:
        candidates: Iterable[object] = ()
    elif isinstance(column_keys, str):
        candidates = (column_keys,)
    elif isinstance(column_keys, Iterable):
        candidates = column_keys
    else:
        candidates = ()

    normalized: list[str] = list(TICKET_GRID_REQUIRED_COLUMN_KEYS)
    seen = set(normalized)
    has_supported_input = False

    for candidate in candidates:
        if not isinstance(candidate, str):
            continue
        if candidate not in TICKET_GRID_SUPPORTED_COLUMN_KEYS:
            continue

        has_supported_input = True
        if candidate in seen:
            continue
        normalized.append(candidate)
        seen.add(candidate)

    if not has_supported_input:
        return list(TICKET_GRID_DEFAULT_COLUMN_KEYS)
    return normalized


EDITABLE_DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S"
EDITABLE_DATETIME_LABEL = "YYYY-MM-DD HH:MM:SS"


class TicketEmailAction(str, Enum):
    """Supported ticket-detail email actions."""

    REPLY = "reply"
    FORWARD = "forward"


def format_editable_datetime(value: datetime | None) -> str:
    """Return ``value`` in the ticket-detail edit format."""

    if value is None:
        return ""
    return value.strftime(EDITABLE_DATETIME_FORMAT)


def parse_editable_datetime(value: str, *, field_name: str) -> datetime | None:
    """Parse a ticket-detail datetime input or raise a user-facing validation error."""

    normalized = value.strip()
    if not normalized:
        return None

    try:
        return datetime.strptime(normalized, EDITABLE_DATETIME_FORMAT)
    except ValueError as error:
        raise ValueError(
            f"{field_name} must use {EDITABLE_DATETIME_LABEL} with a real date and time."
        ) from error


class Ticket(BaseModel):
    """Superset DTO for the Daktela ``Tickets`` model."""

    model_config = ConfigDict(extra="ignore")

    ticket: int | None = None
    name: int | None = None
    deleted: bool | None = None
    title: str
    id_merge: str | None = None
    category: str
    category_name: str | None = None
    user: str | None = None
    user_name: str | None = None
    email: str | None = None
    contact: str | None = None
    parentTicket: str | None = None
    isParent: bool | None = None
    description: str | None = None
    stage: TicketStage
    priority: TicketPriority
    sla_overdue: int | None = None
    sla_deadtime: datetime | None = None
    sla_close_deadline: datetime | None = None
    sla_change: datetime | None = None
    sla_notify: int | None = None
    sla_duration: int | None = None
    sla_custom: bool | None = None
    interaction_activity_count: int | None = None
    reopen: datetime | None = None
    created: datetime | None = None
    created_by: str | None = None
    edited: datetime | None = None
    edited_by: str | None = None
    first_answer: datetime | None = None
    first_answer_duration: int | None = None
    first_answer_deadline: datetime | None = None
    first_answer_overdue: int | None = None
    closed: datetime | None = None
    unread: bool | None = None
    last_unread_date: datetime | None = None
    has_attachment: bool | None = None
    followers: list[str] | None = None
    statuses: dict[str, str] | None = None
    mergeTickets: list[str] | None = None
    children: list[str] | None = None
    activities: list[str] | None = None
    records: list[str] | None = None
    snapshots: list[str] | None = None
    last_activity: datetime | None = None
    last_activity_operator: datetime | None = None
    last_activity_client: datetime | None = None
    customFields: list[TicketCustomField] | None = None

    @field_validator("customFields", mode="before")
    @classmethod
    def _normalize_custom_fields_input(
        cls,
        value: Any,
    ) -> list[Any] | None:
        if value is None:
            return None
        if isinstance(value, Mapping):
            return [
                {
                    "field": str(field),
                    "values": field_value,
                }
                for field, field_value in value.items()
            ]
        if isinstance(value, list | tuple):
            return list(value)
        return None

    def edited_age(self, now: datetime | None = None) -> str:
        """Return the edited timestamp as a compact relative age."""

        if self.edited is None:
            return "-"

        if now is None:
            if self.edited.tzinfo is None:
                now = datetime.now()
            else:
                now = datetime.now(self.edited.tzinfo)

        total_seconds = max(0, int((now - self.edited).total_seconds()))

        if total_seconds >= 24 * 60 * 60:
            return f"{total_seconds // (24 * 60 * 60)}d"

        if total_seconds >= 60 * 60:
            return f"{total_seconds // (60 * 60)}h"

        return f"{total_seconds // 60}m"

    def sla_deadtime_age(self, now: datetime | None = None) -> str:
        """Return the SLA deadline as a compact relative delta."""

        if self.sla_deadtime is None:
            return "-"

        if now is None:
            if self.sla_deadtime.tzinfo is None:
                now = datetime.now()
            else:
                now = datetime.now(self.sla_deadtime.tzinfo)

        total_seconds = int((self.sla_deadtime - now).total_seconds())
        sign = "-" if total_seconds < 0 else ""
        total_seconds = abs(total_seconds)

        if total_seconds >= 24 * 60 * 60:
            return f"{sign}{total_seconds // (24 * 60 * 60)}d"

        if total_seconds >= 60 * 60:
            return f"{sign}{total_seconds // (60 * 60)}h"

        return f"{sign}{total_seconds // 60}m"

    @property
    def statuses_display_label(self) -> str:
        """Return ticket statuses as a comma-separated list of display titles."""

        if not self.statuses:
            return "-"

        return ", ".join(self.statuses.values())


class TicketEmailDraft(BaseModel):
    """Connector-provided draft data for ticket email workflows."""

    action: TicketEmailAction
    source_activity_name: str | None = None
    source_email_name: str
    to: str = ""
    subject: str = ""
    body: str = ""
    queue_name: str


class TicketEmailSendRequest(BaseModel):
    """Application-provided send request for ticket email workflows."""

    action: TicketEmailAction
    source_email_name: str
    to: str
    subject: str
    body: str
    queue_name: str


class TicketCommentAttachmentUpload(BaseModel):
    """One outbound file staged for ticket-comment creation."""

    filename: str
    content: bytes
    content_type: str | None = None


class TicketCommentCreateRequest(BaseModel):
    """Application-provided create request for ticket comments."""

    body: str
    attachments: list[TicketCommentAttachmentUpload] = Field(default_factory=list)


class TicketEditPatch(BaseModel):
    """Editable ticket fields captured from the ticket detail form."""

    model_config = ConfigDict(extra="forbid")

    title: str | None = None
    stage: TicketStage | None = None
    priority: TicketPriority | None = None
    category_name: str | None = None
    category_title: str | None = None
    status_name: str | None = None
    status_title: str | None = None
    reopen: datetime | None = None
    user_name: str | None = None
    user_title: str | None = None
    description: str | None = None

    @classmethod
    def from_form_values(
        cls,
        ticket: Ticket,
        *,
        title: str,
        stage: TicketStage,
        priority: TicketPriority | None = None,
        category_name: str,
        category_title: str,
        status_name: str | None = None,
        status_title: str | None = None,
        reopen: str = "",
        description: str,
        user_name: str | None = None,
        user_title: str | None = None,
    ) -> TicketEditPatch:
        """Build a sparse patch from the current form values."""

        normalized_title = title.strip()
        if not normalized_title:
            raise ValueError("Ticket name can't be blank.")

        patch_data: dict[str, str | TicketStage | TicketPriority | datetime | None] = {}
        if normalized_title != ticket.title:
            patch_data["title"] = normalized_title

        if stage is not ticket.stage:
            patch_data["stage"] = stage

        resolved_priority = ticket.priority if priority is None else priority
        if resolved_priority is not ticket.priority:
            patch_data["priority"] = resolved_priority

        if (
            category_name != (ticket.category_name or ticket.category)
            or category_title != ticket.category
        ):
            patch_data["category_name"] = category_name
            patch_data["category_title"] = category_title

        original_status_name = next(iter(ticket.statuses), None) if ticket.statuses else None
        original_status_title = next(iter(ticket.statuses.values()), None) if ticket.statuses else None
        if status_name != original_status_name or status_title != original_status_title:
            patch_data["status_name"] = status_name
            patch_data["status_title"] = status_title

        parsed_reopen = parse_editable_datetime(reopen, field_name="Reopen")
        if parsed_reopen != ticket.reopen:
            patch_data["reopen"] = parsed_reopen

        original_user_name = ticket.user_name or ticket.user
        if user_name != original_user_name:
            patch_data["user_name"] = user_name
            patch_data["user_title"] = user_title

        current_description = description
        original_description = ticket.description or ""
        if current_description != original_description:
            patch_data["description"] = current_description or None

        return cls.model_validate(patch_data)

    def has_changes(self) -> bool:
        """Return whether the patch contains any explicit field updates."""

        return bool(self.model_fields_set)

    def apply_to(self, ticket: Ticket) -> Ticket:
        """Return a copy of ``ticket`` with the patch applied."""

        updates = self.model_dump(exclude_unset=True)
        category_name = updates.pop("category_name", ticket.category_name)
        category_title = updates.pop("category_title", ticket.category)
        status_name = updates.pop("status_name", next(iter(ticket.statuses), None) if ticket.statuses else None)
        status_title = updates.pop(
            "status_title",
            next(iter(ticket.statuses.values()), None) if ticket.statuses else None,
        )
        user_name = updates.pop("user_name", ticket.user_name or ticket.user)
        user_title = updates.pop("user_title", ticket.user)

        if "category_name" in self.model_fields_set or "category_title" in self.model_fields_set:
            updates["category_name"] = category_name
            updates["category"] = category_title

        if "status_name" in self.model_fields_set or "status_title" in self.model_fields_set:
            if status_name is None or status_title is None:
                updates["statuses"] = None
            else:
                updates["statuses"] = {status_name: status_title}

        if "user_name" in self.model_fields_set or "user_title" in self.model_fields_set:
            updates["user_name"] = user_name
            updates["user"] = user_title

        return ticket.model_copy(update=updates)


class TicketCategoryOption(BaseModel):
    """Selectable ticket category metadata."""

    model_config = ConfigDict(extra="ignore")

    name: str
    title: str


class TicketUserOption(BaseModel):
    """Selectable ticket user metadata."""

    model_config = ConfigDict(extra="ignore")

    name: str
    title: str


class TicketStatusOption(BaseModel):
    """Selectable ticket status metadata."""

    model_config = ConfigDict(extra="ignore")

    name: str
    title: str


class TicketActivityAttachment(BaseModel):
    """Normalized attachment metadata for one ticket activity file."""

    model_config = ConfigDict(extra="ignore")

    file: str
    title: str
    type: str | None = None
    size: int | None = None
    inline: bool = False

    @model_validator(mode="before")
    @classmethod
    def _coerce_attachment_shape(cls, value: Any) -> Any:
        if not isinstance(value, Mapping):
            return value

        normalized = dict(value)
        file_value = normalized.get("file")
        if isinstance(file_value, int | str) and not isinstance(file_value, bool):
            normalized["file"] = str(file_value)

        title = normalized.get("title")
        if not isinstance(title, str) or not title.strip():
            file_name = normalized.get("file")
            if isinstance(file_name, str) and file_name:
                normalized["title"] = file_name

        return normalized


class TicketView(BaseModel):
    """Superset DTO for the Daktela ``TicketsViews`` model."""

    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    view: int | None = None
    name: str | None = None
    parent_view: str | None = Field(
        default=None,
        validation_alias="parentView",
        serialization_alias="parentView",
    )
    deleted: bool | None = None
    title: str
    ticket_count: int | None = Field(default=None, validation_alias=AliasChoices("count", "ticket_count"))
    description: str | None = None
    filter: dict[str, Any] | None = None
    sort: dict[str, Any] | None = None
    limit: dict[str, Any] | None = None
    default_settings: dict[str, Any] | None = None

    def selection_key(self) -> tuple[str, str]:
        """Return a stable identifier for selection and equality-by-identity checks."""

        if self.view is not None:
            return ("view", str(self.view))

        if self.name is not None:
            return ("name", self.name)

        return ("title", self.title)

class TicketPagination(BaseModel):
    """Pagination metadata for the currently loaded ticket page."""

    current_page: int = 1
    total_pages: int = 1
    total_tickets: int = 0

    @field_validator("current_page", "total_pages", mode="before")
    @classmethod
    def _normalize_positive_page_number(cls, value: object) -> int:
        if isinstance(value, bool):
            return 1
        if isinstance(value, int):
            return max(1, value)
        return 1

    @field_validator("total_tickets", mode="before")
    @classmethod
    def _normalize_total_tickets(cls, value: object) -> int:
        if isinstance(value, bool):
            return 0
        if isinstance(value, int):
            return max(0, value)
        return 0

    @property
    def has_previous_page(self) -> bool:
        """Return whether a previous page is available."""

        return self.current_page > 1

    @property
    def has_next_page(self) -> bool:
        """Return whether a later page is available."""

        return self.current_page < self.total_pages

    @property
    def has_multiple_pages(self) -> bool:
        """Return whether pagination should be exposed in the UI."""

        return self.total_pages > 1


class TicketPage(BaseModel):
    """A single page of tickets plus pagination metadata."""

    tickets: list[Ticket] = Field(default_factory=list)
    pagination: TicketPagination = Field(default_factory=TicketPagination)

class TicketCustomFieldOption(BaseModel):
    """Display-ready custom-field option metadata."""

    model_config = ConfigDict(extra="ignore")

    value: Any
    title: str


class TicketCustomField(BaseModel):
    """Display-ready custom-field metadata for ticket detail rendering."""

    model_config = ConfigDict(extra="ignore")

    field: str
    title: str
    values: list[Any] = Field(default_factory=list)
    field_type: str | None = None
    options: list[TicketCustomFieldOption] | None = None

    @model_validator(mode="before")
    @classmethod
    def _coerce_legacy_shape(cls, value: Any) -> Any:
        if not isinstance(value, Mapping):
            return value

        normalized = dict(value)
        if "values" not in normalized and "value" in normalized:
            normalized["values"] = normalized.pop("value")

        if "field_type" not in normalized:
            raw_type = normalized.get("type")
            if isinstance(raw_type, str):
                normalized["field_type"] = raw_type

        title = normalized.get("title")
        if not isinstance(title, str) or not title:
            field_name = normalized.get("field")
            if isinstance(field_name, str):
                normalized["title"] = field_name

        return normalized

    @field_validator("values", mode="before")
    @classmethod
    def _coerce_values(cls, value: Any) -> list[Any]:
        if value is None:
            return []
        if isinstance(value, list):
            return value
        if isinstance(value, tuple):
            return list(value)
        return [value]

    @field_validator("options", mode="before")
    @classmethod
    def _coerce_options(
        cls,
        value: Any,
    ) -> list[Any] | None:
        if value is None:
            return None
        if isinstance(value, list | tuple):
            normalized_options: list[dict[str, Any] | TicketCustomFieldOption] = []
            for option in value:
                normalized_option = _normalize_custom_field_option_input(option)
                if normalized_option is not None:
                    normalized_options.append(normalized_option)
            return normalized_options or None
        if isinstance(value, Mapping):
            normalized_options = []
            for option_value, option_title in value.items():
                normalized_options.append(
                    {
                        "value": option_value,
                        "title": option_title if isinstance(option_title, str) else str(option_title),
                    }
                )
            return normalized_options or None
        return None


_HTML_BREAK_RE = re.compile(r"<br\s*/?>", re.IGNORECASE)
_HTML_BLOCK_BREAK_RE = re.compile(
    r"</(?:address|article|aside|blockquote|div|dl|fieldset|figcaption|figure|footer|form|h[1-6]"
    r"|header|hr|li|main|nav|ol|p|pre|section|table|tr|ul)>",
    re.IGNORECASE,
)
_HTML_TAG_RE = re.compile(r"<[^>]+>")
_HTML_CONTENT_RE = re.compile(r"<[a-z!/][^>]*>", re.IGNORECASE)
_WHITESPACE_RE = re.compile(r"\s+")
_HORIZONTAL_WHITESPACE_RE = re.compile(r"[^\S\n]+")
_EXCESSIVE_LINE_BREAK_RE = re.compile(r"\n{3,}")
_ACTIVITY_TYPE_DISPLAY_LABELS = {
    "": "Comment",
    "CALL": "Call",
    "EMAIL": "Email",
    "CHAT": "Web chat",
    "SMS": "SMS",
    "FBM": "Messenger",
    "IGDM": "Instagram DM",
    "WAP": "WhatsApp",
    "VBR": "Viber",
    "CUSTOM": "Custom",
    "FBCOMMENT": "FB Comment",
    "IGCOMMENT": "IG Comment",
    "COMMENT": "External Comment",
}
_EMAIL_DIRECTION_GLYPHS = {
    "in": "↓",
    "out": "↑",
}


class TicketActivityItem(BaseModel):
    """Normalized nested activity payload used for type-specific details."""

    model_config = ConfigDict(extra="ignore")

    name: str | None = None
    model: str | None = None
    title: str | None = None
    time: datetime | None = None
    description: str | None = None
    body_html: str | None = None
    address: str | None = None
    queue_name: str | None = None
    direction: str | None = None
    state: str | None = None
    attachments: list[TicketActivityAttachment] | None = None

    @field_validator("attachments", mode="before")
    @classmethod
    def _normalize_attachments_input(
        cls,
        value: Any,
    ) -> list[Any] | None:
        if value is None:
            return None
        if isinstance(value, list | tuple):
            return list(value)
        return None


@dataclass(frozen=True)
class ActivityBodyFragment:
    """One renderable fragment extracted from an activity HTML body."""

    kind: str
    markdown: str | None = None
    source: str | None = None
    alt: str | None = None

    @classmethod
    def from_markdown(cls, markdown: str) -> ActivityBodyFragment:
        return cls(kind="markdown", markdown=markdown)

    @classmethod
    def from_image(cls, source: str, alt: str | None = None) -> ActivityBodyFragment:
        return cls(kind="image", source=source, alt=alt)


class TicketActivity(BaseModel):
    """Normalized ticket activity payload for the detail activities pane."""

    model_config = ConfigDict(extra="ignore")

    name: str | None = None
    type: str | None = None
    title: str | None = None
    time: datetime | None = None
    action: str | None = None
    description: str | None = None
    user: str | None = None
    user_name: str | None = None
    created_by: str | None = None
    created_by_name: str | None = None
    item: TicketActivityItem | None = None
    attachments: list[TicketActivityAttachment] | None = None

    @field_validator("attachments", mode="before")
    @classmethod
    def _normalize_attachments_input(
        cls,
        value: Any,
    ) -> list[Any] | None:
        if value is None:
            return None
        if isinstance(value, list | tuple):
            return list(value)
        return None

    @property
    def display_type(self) -> str:
        """Return the preferred type label for the activity summary."""

        if self.type is not None:
            return _ACTIVITY_TYPE_DISPLAY_LABELS.get(self.type, self.type)
        return "Activity"

    @property
    def display_summary_type(self) -> str:
        """Return the preferred summary label for the activity header."""

        display_type = self.display_type
        if self.type != "EMAIL" or self.item is None or self.item.direction is None:
            return display_type

        glyph = _EMAIL_DIRECTION_GLYPHS.get(self.item.direction.casefold())
        if glyph is None:
            return display_type
        return f"{display_type} {glyph}"

    @property
    def display_user(self) -> str:
        """Return the preferred actor label for the activity summary."""

        if self.user:
            return self.user
        if self.created_by:
            return self.created_by
        return "-"

    @property
    def headline(self) -> str:
        """Return the preferred primary text for the activity."""

        if self.title:
            return self.title
        if self.item is not None and self.item.title:
            return self.item.title
        if self.description:
            normalized = _plain_text(self.description, preserve_line_breaks=True)
            if normalized is not None:
                return normalized
            if not _looks_like_html(self.description):
                return self.description
        if self.item is not None and self.item.description:
            normalized = _plain_text(self.item.description, preserve_line_breaks=True)
            if normalized is not None:
                return normalized
            if not _looks_like_html(self.item.description):
                return self.item.description
        return "Untitled activity"

    def preview_text(self, max_length: int = 160) -> str | None:
        """Return a normalized one-line preview for the activity body."""

        body_source = self._body_source()
        return _plain_text(body_source, max_length=max_length)

    def body_text(self) -> str | None:
        """Return the normalized full plain-text body for the activity."""

        body_source = self._body_source()
        return _plain_text(body_source, preserve_line_breaks=True)

    def body_markdown(self) -> str | None:
        """Return the activity body converted to Markdown when the selected source is HTML."""

        body_source = self._body_source()
        if not _looks_like_html(body_source):
            return None
        return _markdown_from_html(body_source)

    def body_fragments(self) -> tuple[ActivityBodyFragment, ...] | None:
        """Return ordered render fragments for HTML activity bodies."""

        body_source = self._body_source()
        if not _looks_like_html(body_source):
            return None
        return _body_fragments_from_html(body_source)

    def downloadable_attachments(self) -> tuple[TicketActivityAttachment, ...]:
        """Return attachments exposed for the current activity."""

        if self.type == "EMAIL" and self.item is not None and self.item.attachments:
            return tuple(self.item.attachments)
        if self.attachments:
            return tuple(self.attachments)
        return ()

    def _body_candidates(self) -> tuple[str | None, str | None, str | None]:
        return (
            self.item.body_html if self.item is not None else None,
            self.description,
            self.item.description if self.item is not None else None,
        )

    def _body_source(self) -> str | None:
        for candidate in self._body_candidates():
            if candidate is None:
                continue
            if _looks_like_html(candidate):
                return candidate
            if _plain_text(candidate, preserve_line_breaks=True) is not None:
                return candidate
        return None


class AppState(BaseModel):
    """Application state for daktela-paleo."""

    tickets: list[Ticket] = Field(default_factory=list)
    views: list[TicketView] = Field(default_factory=list)
    ticket_grid_column_keys: list[str] = Field(
        default_factory=lambda: list(TICKET_GRID_DEFAULT_COLUMN_KEYS)
    )
    ticket_pagination: TicketPagination = Field(default_factory=TicketPagination)
    active_view: TicketView | None = None
    active_ticket: Ticket | None = None

    @field_validator("ticket_grid_column_keys", mode="before")
    @classmethod
    def _normalize_ticket_grid_column_keys(cls, value: object) -> list[str]:
        return normalize_ticket_grid_column_keys(value)

    def model_copy(
        self,
        *,
        update: Mapping[str, Any] | None = None,
        deep: bool = False,
    ) -> Self:
        copied = super().model_copy(update=update, deep=deep)
        copied.ticket_grid_column_keys = normalize_ticket_grid_column_keys(
            copied.ticket_grid_column_keys
        )
        return copied

__all__ = [
    "ActivityBodyFragment",
    "AppState",
    "Ticket",
    "TicketActivity",
    "TicketActivityAttachment",
    "TicketActivityItem",
    "TicketCategoryOption",
    "TicketCommentAttachmentUpload",
    "TicketCommentCreateRequest",
    "TicketPage",
    "TicketPagination",
    "TicketCustomField",
    "TicketCustomFieldOption",
    "TicketStatusOption",
    "TicketUserOption",
    "TicketEditPatch",
    "TicketPriority",
    "TicketStage",
    "TicketView",
    "TICKET_GRID_DEFAULT_COLUMN_KEYS",
    "TICKET_GRID_REQUIRED_COLUMN_KEYS",
    "TICKET_GRID_SUPPORTED_COLUMN_KEYS",
    "normalize_ticket_grid_column_keys",
]


def _plain_text(
    value: str | None,
    *,
    max_length: int | None = None,
    preserve_line_breaks: bool = False,
) -> str | None:
    if value is None:
        return None

    normalized = html.unescape(value)
    normalized = _HTML_BREAK_RE.sub("\n", normalized)
    normalized = _HTML_BLOCK_BREAK_RE.sub("\n", normalized)
    normalized = _HTML_TAG_RE.sub(" ", normalized)
    if preserve_line_breaks:
        normalized = normalized.replace("\r\n", "\n").replace("\r", "\n")
        normalized = _HORIZONTAL_WHITESPACE_RE.sub(" ", normalized)
        normalized = re.sub(r" *\n *", "\n", normalized)
        normalized = _EXCESSIVE_LINE_BREAK_RE.sub("\n\n", normalized).strip()
    else:
        normalized = _WHITESPACE_RE.sub(" ", normalized).strip()
    if not normalized:
        return None
    if max_length is None or len(normalized) <= max_length:
        return normalized
    return f"{normalized[: max_length - 1].rstrip()}…"


def _preview_text(value: str | None, *, max_length: int) -> str | None:
    return _plain_text(value, max_length=max_length)


def _markdown_from_html(value: str | None) -> str | None:
    if value is None:
        return None

    normalized = html.unescape(value).strip()
    if not normalized:
        return None

    markdown = html_to_markdown(normalized)
    markdown = markdown.replace("\r\n", "\n").replace("\r", "\n").strip()
    markdown = _EXCESSIVE_LINE_BREAK_RE.sub("\n\n", markdown)
    if not markdown:
        return None
    return markdown


class _ActivityBodyHTMLParser(HTMLParser):
    """Collect ordered text/image fragments from an HTML body."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=False)
        self.fragments: list[ActivityBodyFragment] = []
        self._buffer: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.casefold() == "img":
            self._flush_buffer()
            self._append_image_fragment(attrs)
            return
        start_tag = self.get_starttag_text()
        if start_tag:
            self._buffer.append(start_tag)

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.casefold() == "img":
            self._flush_buffer()
            self._append_image_fragment(attrs)
            return
        start_tag = self.get_starttag_text()
        if start_tag:
            self._buffer.append(start_tag)

    def handle_endtag(self, tag: str) -> None:
        if tag.casefold() == "img":
            return
        self._buffer.append(f"</{tag}>")

    def handle_data(self, data: str) -> None:
        self._buffer.append(data)

    def handle_entityref(self, name: str) -> None:
        self._buffer.append(f"&{name};")

    def handle_charref(self, name: str) -> None:
        self._buffer.append(f"&#{name};")

    def handle_comment(self, data: str) -> None:
        self._buffer.append(f"<!--{data}-->")

    def close(self) -> None:
        super().close()
        self._flush_buffer()

    def _append_image_fragment(self, attrs: list[tuple[str, str | None]]) -> None:
        attr_map = {name.casefold(): value for name, value in attrs}
        source = attr_map.get("src")
        if not source:
            return
        alt = attr_map.get("alt")
        self.fragments.append(
            ActivityBodyFragment.from_image(
                html.unescape(source),
                html.unescape(alt) if alt else None,
            )
        )

    def _flush_buffer(self) -> None:
        if not self._buffer:
            return
        markdown = _markdown_from_html("".join(self._buffer))
        self._buffer.clear()
        if markdown is None:
            return
        self.fragments.append(ActivityBodyFragment.from_markdown(markdown))


def _body_fragments_from_html(value: str | None) -> tuple[ActivityBodyFragment, ...] | None:
    if value is None:
        return None

    normalized = html.unescape(value).strip()
    if not normalized:
        return None

    parser = _ActivityBodyHTMLParser()
    parser.feed(normalized)
    parser.close()
    if not parser.fragments:
        markdown = _markdown_from_html(normalized)
        if markdown is None:
            return None
        return (ActivityBodyFragment.from_markdown(markdown),)
    return tuple(parser.fragments)


def _looks_like_html(value: str | None) -> bool:
    if value is None:
        return False
    return _HTML_CONTENT_RE.search(html.unescape(value)) is not None


def _normalize_custom_field_option_input(
    value: Any,
) -> dict[str, Any] | TicketCustomFieldOption | None:
    if isinstance(value, TicketCustomFieldOption):
        return value
    if isinstance(value, Mapping):
        option_value = value.get("value", value.get("name", value.get("key", value.get("id"))))
        if option_value is None:
            return None

        option_title = value.get(
            "title",
            value.get("label", value.get("text", value.get("name", option_value))),
        )
        return {
            "value": option_value,
            "title": option_title if isinstance(option_title, str) else str(option_title),
        }
    return {
        "value": value,
        "title": value if isinstance(value, str) else str(value),
    }
