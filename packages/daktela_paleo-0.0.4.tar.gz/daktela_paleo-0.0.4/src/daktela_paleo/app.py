"""Textual application entrypoint for daktela-paleo."""

from __future__ import annotations

import asyncio
import mimetypes
import webbrowser
from dataclasses import dataclass
from pathlib import Path
from typing import cast

from textual import on
from textual.app import App, ComposeResult, ScreenStackError
from textual.binding import Binding
from textual.css.query import NoMatches
from textual.reactive import Reactive, reactive
from textual.screen import Screen
from textual.widgets import Footer, Header

from daktela_paleo.connectors import (
    DaktelaTicketConnector,
    DemoTicketConnector,
    TicketConnector,
)
from daktela_paleo.connectors.daktela import (
    BadTokenDaktelaError,
    CantConnectToDaktelaError,
    DaktelaConnectorError,
)
from daktela_paleo.instances import (
    DaktelaInstanceConfig,
    DaktelaInstanceRecord,
    DaktelaInstanceStore,
)
from daktela_paleo.models import (
    AppState,
    Ticket,
    TicketActivity,
    TicketEmailAction,
    TicketEmailSendRequest,
    TicketCategoryOption,
    TicketCommentAttachmentUpload,
    TicketCommentCreateRequest,
    TicketEditPatch,
    TicketPage,
    TicketPagination,
    TicketStatusOption,
    TicketUserOption,
    TicketView,
)
from daktela_paleo.screens.main.screen import TicketList
from daktela_paleo.screens.main.widgets.instance_management import (
    AddInstanceModal,
    AddInstanceResult,
    InstanceManagementModal,
    InstanceManagementResult,
)
from daktela_paleo.screens.main.widgets.tickets import TicketTable
from daktela_paleo.screens.main.widgets.views import TicketViewsList
from daktela_paleo.screens.ticket_detail.screen import TicketDetail
from daktela_paleo.screens.ticket_detail.widgets.detail_pane import DetailPaneBody
from daktela_paleo.screens.ticket_detail.widgets.form import TicketDetailForm
from daktela_paleo.themes import TOKYONIGHT_MOON
from daktela_paleo.widgets import AppChrome

ViewKey = tuple[str, str]
DEMO_INSTANCE_CONTEXT = "Instance: demo mode"


@dataclass
class DemoModeRestoreState:
    """Session-only runtime snapshot used when leaving demo mode."""

    connector: TicketConnector | None
    active_instance: DaktelaInstanceRecord | None


class DaktelaPaleoApp(App[None]):
    """Application shell for ticket workflows."""

    TITLE = "Daktela Paleo"
    SUB_TITLE = "Ticket TUI"
    BINDINGS = [
        ("q", "quit", "Quit"),
        ("v", "focus_views", "Views"),
        ("h,left", "focus_views", "Back"),
        Binding("i", "open_instance_manager", "Instances"),
    ]
    app_state = reactive(AppState, init=False)
    pending_ticket_jump_count = reactive(None, init=False)
    ticket_table_loading = reactive(False, init=False)
    loading_message = reactive(None, init=False)
    error_message = reactive(None, init=False)
    notice_message = reactive(None, init=False)
    ticket_table_search_status = reactive(None, init=False)
    ticket_detail_search_status = reactive(None, init=False)
    status_message = reactive("Ready")
    instance_context = reactive("Instance: disconnected")
    CSS = """
    Screen {
        layout: vertical;
        background: $background;
        color: $text;
    }

    Header,
    Footer {
        background: $surface;
        color: $text;
    }
    """

    def __init__(
        self,
        initial_state: AppState | None = None,
        *,
        connector: TicketConnector | None = None,
        instance_store: DaktelaInstanceStore | None = None,
    ) -> None:
        super().__init__()
        self.register_theme(TOKYONIGHT_MOON)
        self.theme = TOKYONIGHT_MOON.name
        self.instance_store = instance_store
        self.instance_config = DaktelaInstanceConfig()
        self.active_instance: DaktelaInstanceRecord | None = None
        self._demo_mode_active = False
        self._demo_mode_restore_state: DemoModeRestoreState | None = None
        if connector is None:
            self.instance_store = instance_store or DaktelaInstanceStore()
            self._reload_instance_config()
            connector = self._create_active_instance_connector()
        elif instance_store is not None:
            self._reload_instance_config()

        self.connector = connector
        self._should_load_initial_state = initial_state is None and self.connector is not None
        self._ticket_load_generation = 0
        self._initial_load_generation = 0
        self._ticket_save_generation = 0
        self._ticket_comment_generation = 0
        self._ticket_email_draft_generation = 0
        self._ticket_email_send_generation = 0
        self._ticket_attachment_download_generation = 0
        self._ticket_category_load_generation = 0
        self._ticket_status_load_generation = 0
        self._ticket_user_load_generation = 0
        self._ticket_current_user_load_generation = 0
        self._ticket_activity_load_generation = 0
        self._ticket_category_options: list[TicketCategoryOption] | None = None
        self._ticket_status_options_by_category: dict[str, list[TicketStatusOption]] = {}
        self._ticket_user_options: list[TicketUserOption] | None = None
        self._current_ticket_user: TicketUserOption | None = None
        self._loading_status_suppressed = False
        app_state = initial_state if initial_state is not None else AppState()
        self._loaded_view_key = self._view_key(app_state.active_view)
        self.set_reactive(
            cast(Reactive[AppState], type(self).__dict__["app_state"]),
            app_state,
        )
        self.pending_ticket_jump_count = None
        self.ticket_table_loading = self._should_load_initial_state
        self.loading_message = (
            "Loading tickets..."
            if self._should_load_initial_state
            else None
        )
        self.error_message = None
        self.notice_message = None
        self.ticket_table_search_status = None
        self.ticket_detail_search_status = None
        self.status_message = self._resolve_status_message()
        self.instance_context = self._resolve_instance_context()

    def compose(self) -> ComposeResult:
        yield Header()
        yield TicketList(
            self.app_state,
            ticket_loading=self.ticket_table_loading,
            id="ticket-list",
        )
        yield AppChrome(self.status_message, self.instance_context)
        yield Footer()

    def on_mount(self) -> None:
        if self._should_load_initial_state:
            self.call_after_refresh(self._begin_initial_load)

    def watch_app_state(self, app_state: AppState) -> None:
        try:
            self.query_one(TicketList).sync_from_state(app_state)
        except NoMatches:
            pass

        self._refresh_status_message()

    def watch_pending_ticket_jump_count(self, _: int | None) -> None:
        self._refresh_status_message()

    def watch_ticket_table_loading(self, ticket_table_loading: bool) -> None:
        try:
            self.query_one(TicketList).set_ticket_loading(ticket_table_loading)
        except (NoMatches, ScreenStackError):
            pass

    def watch_loading_message(self, _: str | None) -> None:
        self._refresh_status_message()

    def watch_error_message(self, _: str | None) -> None:
        self._refresh_status_message()

    def watch_notice_message(self, _: str | None) -> None:
        self._refresh_status_message()

    def watch_ticket_table_search_status(self, _: str | None) -> None:
        self._refresh_status_message()

    def watch_ticket_detail_search_status(self, _: str | None) -> None:
        self._refresh_status_message()

    def watch_status_message(self, status_message: str) -> None:
        if not self.is_mounted:
            return

        try:
            self.screen.query_one(AppChrome).set_status_text(status_message)
        except (NoMatches, ScreenStackError):
            pass

    def watch_instance_context(self, instance_context: str) -> None:
        if not self.is_mounted:
            return

        self._update_instance_context_widgets(instance_context)

    def set_app_state(self, app_state: AppState) -> None:
        """Replace the current application state."""

        self._invalidate_pending_loads()
        self.app_state = app_state
        self._loaded_view_key = self._view_key(app_state.active_view)

    def set_tickets(self, tickets: list[Ticket]) -> None:
        """Replace the current ticket collection."""

        self._invalidate_pending_loads()
        self._set_ticket_collection(
            tickets,
            self.app_state.active_ticket,
            pagination=TicketPagination(
                current_page=1,
                total_pages=1,
                total_tickets=len(tickets),
            ),
        )
        self._loaded_view_key = self._view_key(self.app_state.active_view)

    def set_active_view(self, view: TicketView | None) -> None:
        """Update the currently focused ticket view."""

        self.notice_message = None
        self.app_state = self.app_state.model_copy(update={"active_view": view})

    def set_active_ticket(self, ticket: Ticket | None) -> None:
        """Update the currently focused ticket."""

        self.notice_message = None
        self.app_state = self.app_state.model_copy(update={"active_ticket": ticket})

    def action_focus_views(self) -> None:
        """Focus the ticket views list."""

        try:
            self.query_one(TicketList).focus_views()
        except NoMatches:
            pass

    def action_open_instance_manager(self) -> None:
        """Open the saved-instance manager."""

        self._reload_instance_config()
        self.push_screen(
            InstanceManagementModal(
                self.instance_config.instances,
                active_instance_id=(
                    None if self._demo_mode_active else self.instance_config.active_instance_id
                ),
            ),
            self._handle_instance_management_result,
        )

    def open_add_instance_modal(
        self,
        *,
        base_url: str = "",
        user_token: str = "",
        error_message: str | None = None,
    ) -> None:
        """Open the add-instance modal with optional preserved input."""

        self.push_screen(
            AddInstanceModal(
                base_url=base_url,
                user_token=user_token,
                error_message=error_message,
            ),
            self._handle_add_instance_result,
        )

    def activate_instance(self, instance_id: str) -> None:
        """Persist and activate the selected saved instance."""

        self._reload_instance_config()
        next_config = self.instance_config.with_active_instance(instance_id)
        instance = next_config.active_instance()
        if instance is None:
            self.loading_message = None
            self.notice_message = None
            self.error_message = "Saved Daktela instance is no longer available."
            return

        if (
            self.active_instance is not None
            and self.active_instance.id == instance.id
            and isinstance(self.connector, DaktelaTicketConnector)
            and self.connector.pbx_name == instance.base_url
            and self.connector.user_token == instance.user_token
        ):
            return

        self._activate_saved_instance(instance, next_config=next_config)

    def toggle_demo_mode(self) -> None:
        """Switch the current session between demo mode and the prior runtime."""

        if self._demo_mode_active:
            self._restore_runtime_from_demo_mode()
            return

        self._enter_demo_mode()

    @on(TicketTable.PendingCountChanged)
    def handle_pending_ticket_jump_count_changed(
        self,
        message: TicketTable.PendingCountChanged,
    ) -> None:
        """Reflect the pending ticket jump count in the status bar."""

        self.pending_ticket_jump_count = message.count

    @on(TicketTable.SearchStatusChanged)
    def handle_ticket_table_search_status_changed(
        self,
        message: TicketTable.SearchStatusChanged,
    ) -> None:
        """Reflect the applied ticket-table search state in the status bar."""

        self.ticket_table_search_status = message.status

    @on(DetailPaneBody.SearchStatusChanged)
    def handle_ticket_detail_search_status_changed(
        self,
        message: DetailPaneBody.SearchStatusChanged,
    ) -> None:
        """Reflect the applied ticket-detail activity search state in the status bar."""

        self.ticket_detail_search_status = message.status

    @on(TicketViewsList.ViewActivated)
    def handle_view_activated(self, message: TicketViewsList.ViewActivated) -> None:
        """Store the selected view and move focus to tickets."""

        ticket_list = self.query_one(TicketList)
        if self._current_tickets_match_view(message.view):
            ticket_list.focus_tickets()
            return

        self.set_active_view(message.view)
        self._loaded_view_key = None
        self._set_ticket_collection([], None)
        ticket_list.focus_tickets()
        self._begin_ticket_load(message.view)

    @on(TicketList.RefreshRequested)
    def handle_ticket_list_refresh_requested(
        self,
        _: TicketList.RefreshRequested,
    ) -> None:
        """Reload tickets for the currently selected view."""

        self._refresh_active_view(reload_views_metadata=True)

    @on(TicketList.OpenInBrowserRequested)
    def handle_ticket_list_open_in_browser_requested(
        self,
        message: TicketList.OpenInBrowserRequested,
    ) -> None:
        """Open the selected ticket view in the system browser."""

        view = message.view
        if view is None:
            self.notice_message = None
            self.error_message = "View browser URL is not available without a selected view."
            return

        connector = self.connector
        if connector is None:
            self.notice_message = None
            self.error_message = "View browser URL is not available without an active connector."
            return

        url = connector.view_browser_url(view)
        if url is None:
            self.notice_message = None
            self.error_message = "View browser URL is not available for this connector."
            return

        try:
            opened = webbrowser.open(url)
        except Exception as error:
            self.notice_message = None
            self.error_message = f"Error opening view in browser: {error}"
            return

        if not opened:
            self.notice_message = None
            self.error_message = "Error opening view in browser."
            return

        self.error_message = None
        self.notice_message = f"Opened view in browser: {view.title}"

    @on(TicketTable.NextPageRequested)
    def handle_next_ticket_page_requested(
        self,
        _: TicketTable.NextPageRequested,
    ) -> None:
        """Load the next page of tickets for the active view."""

        self._load_relative_ticket_page(1)

    @on(TicketTable.PreviousPageRequested)
    def handle_previous_ticket_page_requested(
        self,
        _: TicketTable.PreviousPageRequested,
    ) -> None:
        """Load the previous page of tickets for the active view."""

        self._load_relative_ticket_page(-1)

    @on(TicketTable.TicketActivated)
    def handle_ticket_activated(self, message: TicketTable.TicketActivated) -> None:
        """Store the selected ticket and open the detail screen."""

        connector = self.connector
        self.set_active_ticket(message.ticket)
        self.ticket_detail_search_status = None
        detail_screen = TicketDetail(
            message.ticket,
            f"Selected ticket: {message.ticket.title}",
            instance_context=self.instance_context,
            activities_message="loading activities...",
            category_options=self._ticket_category_options,
            status_options=self._ticket_status_options_for_category(
                message.ticket.category_name or message.ticket.category
            ),
            user_options=self._ticket_user_options,
            current_user=self._current_ticket_user,
            status_options_category_name=(
                message.ticket.category_name or message.ticket.category
                if self._ticket_status_options_for_category(
                    message.ticket.category_name or message.ticket.category
                )
                is not None
                else None
            ),
            resolve_activity_asset_url=(
                connector.resolve_activity_asset_url if connector is not None else None
            ),
            load_activity_asset=connector.load_activity_asset if connector is not None else None,
        )
        self.push_screen(detail_screen)
        self.call_after_refresh(self._refresh_status_message)
        if self._current_ticket_user is None:
            self._begin_current_user_load(detail_screen)
        self._begin_ticket_activity_load(detail_screen, message.ticket)
        if self._ticket_category_options is None:
            self._begin_ticket_category_load(detail_screen)
        if self._ticket_status_options_for_category(message.ticket.category_name or message.ticket.category) is None:
            self._begin_ticket_status_load(
                detail_screen,
                message.ticket.category_name or message.ticket.category,
            )
        if self._ticket_user_options is None:
            self._begin_ticket_user_load(detail_screen)

    def _begin_current_user_load(self, detail_screen: TicketDetail | None = None) -> None:
        if not self.is_running:
            return
        if self._current_ticket_user is not None:
            if detail_screen is not None and detail_screen.is_mounted:
                detail_screen.set_current_user(self._current_ticket_user)
            return
        if self.connector is None:
            return

        self._ticket_current_user_load_generation += 1
        generation = self._ticket_current_user_load_generation
        self.run_worker(
            self._load_current_user(detail_screen, generation),
            name="load-current-user",
            group="ticket-current-user-load",
            exit_on_error=False,
            exclusive=True,
        )

    @on(TicketDetailForm.StatusOptionsRequested)
    def handle_ticket_detail_status_options_requested(
        self,
        message: TicketDetailForm.StatusOptionsRequested,
    ) -> None:
        """Load or reuse status options for the newly selected category."""

        if not isinstance(self.screen, TicketDetail):
            return

        cached_status_options = self._ticket_status_options_for_category(message.category_name)
        if cached_status_options is not None:
            self.screen.set_ticket_statuses(message.category_name, cached_status_options)
            return

        self._begin_ticket_status_load(self.screen, message.category_name)

    @on(TicketDetail.StatusRequested)
    def handle_ticket_detail_status_requested(
        self,
        message: TicketDetail.StatusRequested,
    ) -> None:
        """Show form validation or no-op save messages in the status bar."""

        self.loading_message = None
        if message.error:
            self.notice_message = None
            self.error_message = message.text
            return

        self.error_message = None
        self.notice_message = message.text

    @on(TicketDetail.SaveRequested)
    def handle_ticket_detail_save_requested(
        self,
        message: TicketDetail.SaveRequested,
    ) -> None:
        """Persist editable ticket fields through the active connector."""

        self._ticket_save_generation += 1
        generation = self._ticket_save_generation
        self.loading_message = f"Saving ticket: {message.ticket.title}"
        self.error_message = None
        self.notice_message = None
        self.run_worker(
            self._store_ticket(
                message.detail_screen,
                message.ticket,
                message.patch,
                generation,
            ),
            name="store-ticket",
            group="ticket-save",
            exit_on_error=False,
            exclusive=True,
        )

    @on(TicketDetail.CommentRequested)
    def handle_ticket_detail_comment_requested(
        self,
        message: TicketDetail.CommentRequested,
    ) -> None:
        """Create a ticket comment through the active connector."""

        self._ticket_comment_generation += 1
        generation = self._ticket_comment_generation
        self.loading_message = f"Adding comment: {message.ticket.title}"
        self.error_message = None
        self.notice_message = None
        self.run_worker(
            self._create_ticket_comment(
                message.detail_screen,
                message.ticket,
                TicketCommentCreateRequest(body=message.content),
                message.attachment_paths,
                generation,
            ),
            name="create-ticket-comment",
            group="ticket-comment",
            exit_on_error=False,
            exclusive=True,
        )

    @on(TicketDetail.EmailDraftRequested)
    def handle_ticket_detail_email_draft_requested(
        self,
        message: TicketDetail.EmailDraftRequested,
    ) -> None:
        """Load a ticket email draft through the active connector."""

        self._ticket_email_draft_generation += 1
        generation = self._ticket_email_draft_generation
        self.loading_message = f"Loading email draft: {message.ticket.title}"
        self.error_message = None
        self.notice_message = None
        self.run_worker(
            self._load_ticket_email_draft(
                message.detail_screen,
                message.ticket,
                message.activity,
                message.action,
                generation,
            ),
            name="load-ticket-email-draft",
            group="ticket-email-draft",
            exit_on_error=False,
            exclusive=True,
        )

    @on(TicketDetail.EmailSendRequested)
    def handle_ticket_detail_email_send_requested(
        self,
        message: TicketDetail.EmailSendRequested,
    ) -> None:
        """Send a ticket email through the active connector."""

        self._ticket_email_send_generation += 1
        generation = self._ticket_email_send_generation
        self.loading_message = f"Sending email: {message.ticket.title}"
        self.error_message = None
        self.notice_message = None
        self.run_worker(
            self._send_ticket_email(
                message.detail_screen,
                message.ticket,
                message.request,
                generation,
            ),
            name="send-ticket-email",
            group="ticket-email-send",
            exit_on_error=False,
            exclusive=True,
        )

    @on(TicketDetail.ActivityAttachmentDownloadRequested)
    def handle_ticket_detail_activity_attachment_download_requested(
        self,
        message: TicketDetail.ActivityAttachmentDownloadRequested,
    ) -> None:
        """Download the selected activity attachments through the active connector."""

        self._ticket_attachment_download_generation += 1
        generation = self._ticket_attachment_download_generation
        self.loading_message = f"Downloading attachments: {message.ticket.title}"
        self.error_message = None
        self.notice_message = None
        self.run_worker(
            self._download_ticket_activity_attachments(
                message.detail_screen,
                message.ticket,
                message.activity,
                message.destination_dir,
                generation,
            ),
            name="download-ticket-activity-attachments",
            group="ticket-attachment-download",
            exit_on_error=False,
            exclusive=True,
        )

    @on(TicketDetail.OpenInBrowserRequested)
    def handle_ticket_detail_open_in_browser_requested(
        self,
        message: TicketDetail.OpenInBrowserRequested,
    ) -> None:
        """Open the selected ticket in the system browser."""

        connector = self.connector
        if connector is None:
            self.notice_message = None
            self.error_message = "Ticket browser URL is not available without an active connector."
            return

        url = connector.ticket_browser_url(message.ticket)
        if url is None:
            self.notice_message = None
            self.error_message = "Ticket browser URL is not available for this connector."
            return

        try:
            opened = webbrowser.open(url)
        except Exception as error:
            self.notice_message = None
            self.error_message = f"Error opening ticket in browser: {error}"
            return

        if not opened:
            self.notice_message = None
            self.error_message = "Error opening ticket in browser."
            return

        self.error_message = None
        self.notice_message = f"Opened ticket in browser: {message.ticket.title}"

    @on(TicketDetail.OpenActivityLinkRequested)
    def handle_ticket_detail_open_activity_link_requested(
        self,
        message: TicketDetail.OpenActivityLinkRequested,
    ) -> None:
        """Open a discovered ticket-activity link in the system browser."""

        try:
            opened = webbrowser.open(message.url)
        except Exception as error:
            self.notice_message = None
            self.error_message = f"Error opening link in browser: {error}"
            return

        if not opened:
            self.notice_message = None
            self.error_message = "Error opening link in browser."
            return

        self.error_message = None
        self.notice_message = "Opened link in browser."

    def _base_status_message(self) -> str:
        active_ticket = self.app_state.active_ticket
        if active_ticket is not None:
            return f"Selected ticket: {active_ticket.title}"

        active_view = self.app_state.active_view
        if active_view is not None:
            return f"Selected view: {active_view.title}"

        return "Ready"

    def _resolve_status_message(self) -> str:
        try:
            current_screen: Screen[object] | None = self.screen
        except ScreenStackError:
            current_screen = None

        if self.pending_ticket_jump_count is not None:
            return f"Ticket jump: {self.pending_ticket_jump_count}"

        if self.error_message is not None:
            return self.error_message

        if self.loading_message is not None and not self._loading_status_suppressed:
            return self.loading_message

        if self.notice_message is not None:
            return self.notice_message

        if isinstance(current_screen, TicketDetail):
            if self.ticket_detail_search_status is not None:
                return self.ticket_detail_search_status
            return self._base_status_message()

        if self.ticket_table_search_status is not None:
            return self.ticket_table_search_status

        return self._base_status_message()

    def _resolve_instance_context(self) -> str:
        if self._demo_mode_active:
            return DEMO_INSTANCE_CONTEXT
        if self.active_instance is None:
            return "Instance: disconnected"
        return f"Instance: {self.active_instance.base_url}"

    def _refresh_status_message(self) -> None:
        self.status_message = self._resolve_status_message()

    def _refresh_instance_context(self) -> None:
        self.instance_context = self._resolve_instance_context()

    def _handle_instance_management_result(
        self,
        result: InstanceManagementResult | None,
    ) -> None:
        if result is None:
            return

        if result.action == "add":
            self.open_add_instance_modal()
            return

        if result.action == "toggle_demo_mode":
            self.toggle_demo_mode()
            return

        if result.action == "activate" and result.instance_id is not None:
            self.activate_instance(result.instance_id)

    def _handle_add_instance_result(
        self,
        result: AddInstanceResult | None,
    ) -> None:
        if result is None or result.action != "submit":
            return

        assert result.base_url is not None
        assert result.user_token is not None

        self.loading_message = "Validating Daktela instance..."
        self.error_message = None
        self.notice_message = None
        self.run_worker(
            self._validate_and_activate_instance(
                result.base_url,
                result.user_token,
            ),
            name="validate-daktela-instance",
            group="instance-management",
            exit_on_error=False,
            exclusive=True,
        )

    def _begin_initial_load(self) -> None:
        if not self._should_load_initial_state or self.connector is None:
            return

        self._should_load_initial_state = False
        self._initial_load_generation += 1
        generation = self._initial_load_generation
        self.ticket_table_loading = True
        self.watch_ticket_table_loading(True)
        self.loading_message = "Loading tickets..."
        self.error_message = None
        self.run_worker(
            self._load_initial_state(generation),
            name="load-initial-state",
            group="connector-load",
            exit_on_error=False,
            exclusive=True,
        )

    def _begin_ticket_load(
        self,
        view: TicketView,
        *,
        page: int = 1,
        preferred_ticket: Ticket | None = None,
        suppress_loading_status: bool = False,
        reload_views_metadata: bool = False,
    ) -> None:
        self._initial_load_generation += 1
        self._ticket_load_generation += 1
        generation = self._ticket_load_generation
        self.ticket_table_loading = True
        self.watch_ticket_table_loading(True)
        self._loading_status_suppressed = suppress_loading_status
        self.loading_message = f"Loading tickets: {view.title}"
        self.error_message = None
        self.run_worker(
            self._load_tickets_for_view(
                view,
                generation,
                page=page,
                preferred_ticket=preferred_ticket,
                reload_views_metadata=reload_views_metadata,
            ),
            name="load-view-tickets",
            group="connector-load",
            exit_on_error=False,
            exclusive=True,
        )

    async def _load_initial_state(self, generation: int) -> None:
        connector = self.connector
        if connector is None:
            return

        current_user: TicketUserOption | None = None
        ticket_grid_column_keys: list[str] | None = None
        try:
            views = await connector.list_views()
            initial_view = views[0] if views else None
            try:
                ticket_page = await connector.list_ticket_page(initial_view)
            except NotImplementedError:
                try:
                    tickets = await connector.list_tickets(initial_view)
                except NotImplementedError:
                    tickets = []
                ticket_page = TicketPage(
                    tickets=tickets,
                    pagination=TicketPagination(
                        current_page=1,
                        total_pages=1,
                        total_tickets=len(tickets),
                    ),
                )
            try:
                current_user = await connector.get_current_user()
            except Exception:
                current_user = None
            try:
                ticket_grid_column_keys = await connector.get_ticket_grid_column_keys()
            except Exception:
                ticket_grid_column_keys = None

            app_state_data: dict[str, object] = {
                "views": views,
                "tickets": ticket_page.tickets,
                "ticket_pagination": ticket_page.pagination,
                "active_view": initial_view,
                "active_ticket": None,
            }
            if ticket_grid_column_keys is not None:
                app_state_data["ticket_grid_column_keys"] = ticket_grid_column_keys
            app_state = AppState.model_validate(app_state_data)
        except asyncio.CancelledError:
            raise
        except Exception as error:
            if generation != self._initial_load_generation:
                return
            self.ticket_table_loading = False
            self.loading_message = None
            self.error_message = f"Error loading tickets: {error}"
            return

        if generation != self._initial_load_generation:
            return

        self.app_state = app_state
        self._current_ticket_user = current_user
        self._loaded_view_key = self._view_key(app_state.active_view)
        self.ticket_table_loading = False
        self.loading_message = None
        self.error_message = None

    async def _load_tickets_for_view(
        self,
        view: TicketView,
        generation: int,
        *,
        page: int = 1,
        preferred_ticket: Ticket | None = None,
        reload_views_metadata: bool = False,
    ) -> None:
        connector = self.connector
        if connector is None:
            return

        try:
            if reload_views_metadata:
                refreshed_view = self._apply_refreshed_views(
                    await connector.list_views(),
                    view=view,
                )
                if generation != self._ticket_load_generation:
                    return
                if refreshed_view is not None:
                    view = refreshed_view
            try:
                ticket_page = await connector.list_ticket_page(view, page=page)
            except NotImplementedError:
                tickets = await connector.list_tickets(view)
                ticket_page = TicketPage(
                    tickets=tickets,
                    pagination=TicketPagination(
                        current_page=1,
                        total_pages=1,
                        total_tickets=len(tickets),
                    ),
                )
        except asyncio.CancelledError:
            raise
        except Exception as error:
            if generation != self._ticket_load_generation:
                return
            self._loading_status_suppressed = False
            self.ticket_table_loading = False
            self.loading_message = None
            self.error_message = f"Error loading tickets: {error}"
            return

        if generation != self._ticket_load_generation:
            return

        preserve_notice = self._loading_status_suppressed
        self._set_ticket_collection(
            ticket_page.tickets,
            self._match_ticket(ticket_page.tickets, preferred_ticket),
            pagination=ticket_page.pagination,
            clear_notice=not preserve_notice,
        )
        self._loaded_view_key = self._view_key(view)
        self.ticket_table_loading = False
        self.loading_message = None
        self._loading_status_suppressed = False
        self.error_message = None

    def _begin_ticket_category_load(self, detail_screen: TicketDetail) -> None:
        self._ticket_category_load_generation += 1
        generation = self._ticket_category_load_generation
        self.run_worker(
            self._load_ticket_categories(detail_screen, generation),
            name="load-ticket-categories",
            group="ticket-category-load",
            exit_on_error=False,
            exclusive=True,
        )

    def _begin_ticket_user_load(self, detail_screen: TicketDetail) -> None:
        self._ticket_user_load_generation += 1
        generation = self._ticket_user_load_generation
        self.run_worker(
            self._load_ticket_users(detail_screen, generation),
            name="load-ticket-users",
            group="ticket-user-load",
            exit_on_error=False,
            exclusive=True,
        )

    def _begin_ticket_status_load(
        self,
        detail_screen: TicketDetail,
        category_name: str,
    ) -> None:
        self._ticket_status_load_generation += 1
        generation = self._ticket_status_load_generation
        self.run_worker(
            self._load_ticket_statuses(detail_screen, category_name, generation),
            name="load-ticket-statuses",
            group="ticket-status-load",
            exit_on_error=False,
            exclusive=True,
        )

    def _begin_ticket_activity_load(
        self,
        detail_screen: TicketDetail,
        ticket: Ticket,
    ) -> None:
        self._ticket_activity_load_generation += 1
        generation = self._ticket_activity_load_generation
        self.run_worker(
            self._load_ticket_activities(detail_screen, ticket, generation),
            name="load-ticket-activities",
            group="ticket-activity-load",
            exit_on_error=False,
            exclusive=True,
        )

    async def _load_ticket_categories(
        self,
        detail_screen: TicketDetail,
        generation: int,
    ) -> None:
        connector = self.connector
        if connector is None:
            return

        try:
            category_options = await connector.list_ticket_categories()
        except asyncio.CancelledError:
            raise
        except Exception as error:
            if generation != self._ticket_category_load_generation:
                return
            error_message = f"Error loading ticket categories: {error}"
            self.call_after_refresh(
                lambda: (
                    detail_screen.post_message(
                        TicketDetail.StatusRequested(
                            detail_screen,
                            error_message,
                            error=True,
                        )
                    )
                    if detail_screen.is_mounted
                    else None
                )
            )
            return

        if generation != self._ticket_category_load_generation:
            return

        self._ticket_category_options = category_options
        self.call_after_refresh(
            lambda: (
                detail_screen.set_ticket_categories(category_options)
                if detail_screen.is_mounted
                else None
            )
        )

    async def _load_ticket_users(
        self,
        detail_screen: TicketDetail,
        generation: int,
    ) -> None:
        connector = self.connector
        if connector is None:
            return

        try:
            user_options = await connector.list_ticket_users()
        except asyncio.CancelledError:
            raise
        except Exception as error:
            if generation != self._ticket_user_load_generation:
                return
            error_message = f"Error loading ticket users: {error}"
            self.call_after_refresh(
                lambda: (
                    detail_screen.post_message(
                        TicketDetail.StatusRequested(
                            detail_screen,
                            error_message,
                            error=True,
                        )
                    )
                    if detail_screen.is_mounted
                    else None
                )
            )
            return

        if generation != self._ticket_user_load_generation:
            return

        self._ticket_user_options = user_options
        self.call_after_refresh(
            lambda: (
                detail_screen.set_ticket_users(user_options)
                if detail_screen.is_mounted
                else None
            )
        )

    async def _load_current_user(
        self,
        detail_screen: TicketDetail | None,
        generation: int,
    ) -> None:
        connector = self.connector
        if connector is None:
            return

        try:
            current_user = await connector.get_current_user()
        except asyncio.CancelledError:
            raise
        except Exception:
            if generation != self._ticket_current_user_load_generation:
                return
            return

        if generation != self._ticket_current_user_load_generation:
            return

        self._current_ticket_user = current_user
        if detail_screen is None:
            return

        self.call_after_refresh(
            lambda: (
                detail_screen.set_current_user(current_user)
                if detail_screen.is_mounted and current_user is not None
                else None
            )
        )

    async def _load_ticket_activities(
        self,
        detail_screen: TicketDetail,
        ticket: Ticket,
        generation: int,
    ) -> None:
        connector = self.connector
        if connector is None:
            return

        try:
            activities = await connector.list_ticket_activities(ticket)
        except asyncio.CancelledError:
            raise
        except Exception as error:
            if generation != self._ticket_activity_load_generation:
                return
            error_message = f"Error loading ticket activities: {error}"
            self.call_after_refresh(
                lambda: (
                    (
                        detail_screen.set_activities_error(),
                        detail_screen.post_message(
                            TicketDetail.StatusRequested(
                                detail_screen,
                                error_message,
                                error=True,
                            )
                        ),
                    )
                    if detail_screen.is_mounted
                    else None
                )
            )
            return

        if generation != self._ticket_activity_load_generation:
            return

        self.call_after_refresh(
            lambda: (
                detail_screen.set_ticket_activities(activities)
                if detail_screen.is_mounted
                else None
            )
        )

    async def _load_ticket_statuses(
        self,
        detail_screen: TicketDetail,
        category_name: str,
        generation: int,
    ) -> None:
        connector = self.connector
        if connector is None:
            return

        try:
            status_options = await connector.list_ticket_statuses(category_name)
        except asyncio.CancelledError:
            raise
        except Exception as error:
            if generation != self._ticket_status_load_generation:
                return
            error_message = f"Error loading ticket statuses: {error}"
            self.call_after_refresh(
                lambda: (
                    detail_screen.post_message(
                        TicketDetail.StatusRequested(
                            detail_screen,
                            error_message,
                            error=True,
                        )
                    )
                    if detail_screen.is_mounted
                    else None
                )
            )
            return

        if generation != self._ticket_status_load_generation:
            return

        self._ticket_status_options_by_category[category_name] = status_options
        self.call_after_refresh(
            lambda: (
                detail_screen.set_ticket_statuses(category_name, status_options)
                if detail_screen.is_mounted
                else None
            )
        )

    async def _store_ticket(
        self,
        detail_screen: TicketDetail,
        ticket: Ticket,
        patch: TicketEditPatch,
        generation: int,
    ) -> None:
        connector = self.connector
        if connector is None:
            detail_screen.cancel_close_after_save()
            self.loading_message = None
            self.error_message = "No connector is active."
            self.notice_message = None
            return

        try:
            saved_ticket = await connector.store_ticket(ticket, patch)
        except asyncio.CancelledError:
            raise
        except Exception as error:
            if generation != self._ticket_save_generation:
                return
            detail_screen.cancel_close_after_save()
            self.loading_message = None
            self.error_message = f"Error saving ticket: {error}"
            self.notice_message = None
            return

        if generation != self._ticket_save_generation:
            return

        if self.screen is detail_screen:
            detail_screen.sync_ticket(saved_ticket)
        should_close_detail = detail_screen.consume_close_after_save()
        self.loading_message = None
        self.error_message = None
        self.notice_message = f"Saved ticket: {saved_ticket.title}"
        if should_close_detail and self.screen is detail_screen:
            self.pop_screen()
            self.call_after_refresh(self._refresh_status_message)
        if not self._refresh_active_view(
            preferred_ticket=saved_ticket,
            suppress_loading_status=True,
            reload_views_metadata=True,
        ):
            self._apply_saved_ticket(saved_ticket)

    async def _create_ticket_comment(
        self,
        detail_screen: TicketDetail,
        ticket: Ticket,
        request: TicketCommentCreateRequest,
        attachment_paths: tuple[Path, ...],
        generation: int,
    ) -> None:
        connector = self.connector
        if connector is None:
            self.loading_message = None
            self.error_message = "No connector is active."
            self.notice_message = None
            return

        try:
            full_request = request.model_copy(
                update={
                    "attachments": self._load_comment_attachment_uploads(attachment_paths),
                }
            )
            await connector.create_ticket_comment(ticket, full_request)
        except asyncio.CancelledError:
            raise
        except Exception as error:
            if generation != self._ticket_comment_generation:
                return
            error_message = f"Error adding comment: {error}"
            self.call_after_refresh(
                lambda: (
                    detail_screen.handle_comment_submit_failure(error_message)
                    if detail_screen.is_mounted
                    else None
                )
            )
            self.loading_message = None
            self.error_message = error_message
            self.notice_message = None
            return

        if generation != self._ticket_comment_generation:
            return

        self.call_after_refresh(
            lambda: (
                detail_screen.handle_comment_submit_success()
                if detail_screen.is_mounted
                else None
            )
        )
        self.loading_message = None
        self.error_message = None
        self.notice_message = f"Added comment: {ticket.title}"
        self._begin_ticket_activity_load(detail_screen, ticket)

    def _load_comment_attachment_uploads(
        self,
        attachment_paths: tuple[Path, ...],
    ) -> list[TicketCommentAttachmentUpload]:
        uploads: list[TicketCommentAttachmentUpload] = []
        for path in attachment_paths:
            try:
                content = path.read_bytes()
            except OSError as error:
                raise RuntimeError(f"Unable to read attachment '{path.name}': {error}") from error

            content_type, _ = mimetypes.guess_type(path.name)
            uploads.append(
                TicketCommentAttachmentUpload(
                    filename=path.name,
                    content=content,
                    content_type=content_type,
                )
            )
        return uploads

    async def _load_ticket_email_draft(
        self,
        detail_screen: TicketDetail,
        ticket: Ticket,
        activity: TicketActivity,
        action: TicketEmailAction,
        generation: int,
    ) -> None:
        connector = self.connector
        if connector is None:
            self.loading_message = None
            self.error_message = "No connector is active."
            self.notice_message = None
            self.call_after_refresh(
                lambda: (
                    detail_screen.handle_email_draft_failure()
                    if detail_screen.is_mounted
                    else None
                )
            )
            return

        try:
            draft = await connector.get_ticket_email_draft(ticket, activity, action)
        except asyncio.CancelledError:
            raise
        except Exception as error:
            if generation != self._ticket_email_draft_generation:
                return
            self.call_after_refresh(
                lambda: (
                    detail_screen.handle_email_draft_failure()
                    if detail_screen.is_mounted
                    else None
                )
            )
            self.loading_message = None
            self.error_message = f"Error loading email draft: {error}"
            self.notice_message = None
            return

        if generation != self._ticket_email_draft_generation:
            return

        self.call_after_refresh(
            lambda: (
                detail_screen.handle_email_draft_loaded(draft)
                if detail_screen.is_mounted
                else None
            )
        )
        self.loading_message = None
        self.error_message = None
        self.notice_message = None

    async def _send_ticket_email(
        self,
        detail_screen: TicketDetail,
        ticket: Ticket,
        request: TicketEmailSendRequest,
        generation: int,
    ) -> None:
        connector = self.connector
        if connector is None:
            self.loading_message = None
            self.error_message = "No connector is active."
            self.notice_message = None
            self.call_after_refresh(
                lambda: (
                    detail_screen.handle_email_submit_failure("No connector is active.")
                    if detail_screen.is_mounted
                    else None
                )
            )
            return

        try:
            await connector.send_ticket_email(ticket, request)
        except asyncio.CancelledError:
            raise
        except Exception as error:
            if generation != self._ticket_email_send_generation:
                return
            error_message = f"Error sending email: {error}"
            self.call_after_refresh(
                lambda: (
                    detail_screen.handle_email_submit_failure(error_message)
                    if detail_screen.is_mounted
                    else None
                )
            )
            self.loading_message = None
            self.error_message = error_message
            self.notice_message = None
            return

        if generation != self._ticket_email_send_generation:
            return

        self.call_after_refresh(
            lambda: (
                detail_screen.handle_email_submit_success()
                if detail_screen.is_mounted
                else None
            )
        )
        self.loading_message = None
        self.error_message = None
        self.notice_message = f"Sent email: {ticket.title}"
        self._begin_ticket_activity_load(detail_screen, ticket)

    async def _download_ticket_activity_attachments(
        self,
        detail_screen: TicketDetail,
        ticket: Ticket,
        activity: TicketActivity,
        destination_dir: Path,
        generation: int,
    ) -> None:
        connector = self.connector
        if connector is None:
            self.loading_message = None
            self.error_message = "No connector is active."
            self.notice_message = None
            return

        attachments = activity.downloadable_attachments()
        if not attachments:
            self.loading_message = None
            self.error_message = "Selected activity has no downloadable attachments."
            self.notice_message = None
            return

        saved_paths: list[Path] = []
        failures: list[str] = []

        try:
            destination_dir.mkdir(parents=True, exist_ok=True)
            for attachment in attachments:
                try:
                    content = await connector.load_ticket_activity_attachment(activity, attachment)
                    destination_path = self._next_attachment_download_path(
                        destination_dir,
                        attachment.title or f"attachment-{attachment.file}",
                    )
                    destination_path.write_bytes(content)
                    saved_paths.append(destination_path)
                except asyncio.CancelledError:
                    raise
                except Exception as error:
                    failures.append(f"{attachment.title or attachment.file}: {error}")
        except asyncio.CancelledError:
            raise
        except Exception as error:
            if generation != self._ticket_attachment_download_generation:
                return
            self.loading_message = None
            self.error_message = f"Error downloading attachments: {error}"
            self.notice_message = None
            return

        if generation != self._ticket_attachment_download_generation:
            return

        self.loading_message = None
        if failures:
            self.notice_message = None
            downloaded_count = len(saved_paths)
            total_count = len(attachments)
            if downloaded_count > 0:
                self.error_message = (
                    f"Downloaded {downloaded_count} of {total_count} attachment(s) to "
                    f"{destination_dir}: {failures[0]}"
                )
            else:
                self.error_message = f"Error downloading attachments: {failures[0]}"
            return

        self.error_message = None
        self.notice_message = (
            f"Downloaded {len(saved_paths)} attachment(s) to {destination_dir}."
        )

    def _invalidate_pending_loads(self) -> None:
        self._should_load_initial_state = False
        self._initial_load_generation += 1
        self._ticket_load_generation += 1
        self._ticket_save_generation += 1
        self._ticket_comment_generation += 1
        self._ticket_email_draft_generation += 1
        self._ticket_email_send_generation += 1
        self._ticket_attachment_download_generation += 1
        self._ticket_category_load_generation += 1
        self._ticket_status_load_generation += 1
        self._ticket_user_load_generation += 1
        self._ticket_current_user_load_generation += 1
        self._ticket_activity_load_generation += 1
        self._loading_status_suppressed = False
        self._loaded_view_key = None
        self._ticket_category_options = None
        self._ticket_status_options_by_category = {}
        self._ticket_user_options = None
        self._current_ticket_user = None
        self.ticket_table_loading = False
        self.loading_message = None
        self.error_message = None
        self.notice_message = None

    def _set_ticket_collection(
        self,
        tickets: list[Ticket],
        active_ticket: Ticket | None,
        *,
        pagination: TicketPagination | None = None,
        clear_notice: bool = True,
    ) -> None:
        if clear_notice:
            self.notice_message = None
        self.app_state = self.app_state.model_copy(
            update={
                "tickets": tickets,
                "ticket_pagination": (
                    pagination.model_copy(deep=True)
                    if pagination is not None
                    else TicketPagination(
                        current_page=1,
                        total_pages=1,
                        total_tickets=len(tickets),
                    )
                ),
                "active_ticket": active_ticket,
            }
        )

    def _apply_saved_ticket(self, saved_ticket: Ticket) -> None:
        active_ticket = self.app_state.active_ticket
        updated_active_ticket = (
            saved_ticket
            if active_ticket is not None and self._tickets_match(active_ticket, saved_ticket)
            else active_ticket
        )
        updated_tickets = [
            saved_ticket if self._tickets_match(ticket, saved_ticket) else ticket
            for ticket in self.app_state.tickets
        ]
        self.app_state = self.app_state.model_copy(
            update={
                "tickets": updated_tickets,
                "active_ticket": updated_active_ticket,
            }
        )

    def _create_active_instance_connector(self) -> TicketConnector | None:
        self._reload_instance_config()
        if self.active_instance is None:
            return None
        return DaktelaTicketConnector(
            self.active_instance.base_url,
            self.active_instance.user_token,
        )

    def _reload_instance_config(self) -> None:
        if self.instance_store is None:
            self.active_instance = (
                None if self._demo_mode_active else self.instance_config.active_instance()
            )
            self._refresh_instance_context()
            return

        self.instance_config = self.instance_store.load()
        self.active_instance = (
            None if self._demo_mode_active else self.instance_config.active_instance()
        )
        self._refresh_instance_context()

    def _persist_instance_config(self, config: DaktelaInstanceConfig) -> None:
        prepared = DaktelaInstanceConfig.model_validate(config.model_dump(mode="python"))
        if self.instance_store is not None:
            self.instance_store.save(prepared)
        self.instance_config = prepared
        self.active_instance = (
            None if self._demo_mode_active else self.instance_config.active_instance()
        )
        self._refresh_instance_context()

    def _iter_mounted_screens(self) -> list[Screen[object]]:
        try:
            screens = list(self.screen_stack)
        except ScreenStackError:
            return []

        mounted_screens: list[Screen[object]] = []
        for screen in screens:
            if not screen.is_mounted or screen in mounted_screens:
                continue
            mounted_screens.append(screen)
        return mounted_screens

    def _update_instance_context_widgets(self, instance_context: str) -> None:
        for screen in self._iter_mounted_screens():
            try:
                screen.query_one(AppChrome).set_instance_text(instance_context)
            except NoMatches:
                continue

    @staticmethod
    def _copy_active_instance(
        instance: DaktelaInstanceRecord | None,
    ) -> DaktelaInstanceRecord | None:
        if instance is None:
            return None
        return instance.model_copy(deep=True)

    def _activate_runtime(
        self,
        connector: TicketConnector | None,
        *,
        active_instance: DaktelaInstanceRecord | None,
    ) -> None:
        self._invalidate_pending_loads()
        self.connector = connector
        self.active_instance = self._copy_active_instance(active_instance)
        self._refresh_instance_context()
        self.app_state = AppState()
        self._loaded_view_key = None
        self._ticket_category_options = None
        self._ticket_status_options_by_category = {}
        self._ticket_user_options = None
        self._current_ticket_user = None
        self.pending_ticket_jump_count = None
        self.error_message = None
        self.notice_message = None
        self._should_load_initial_state = connector is not None

        try:
            self.query_one(TicketList).focus_views()
        except NoMatches:
            pass

        if connector is not None:
            self._begin_initial_load()

    def _enter_demo_mode(self) -> None:
        self._demo_mode_restore_state = DemoModeRestoreState(
            connector=self.connector,
            active_instance=self._copy_active_instance(self.active_instance),
        )
        self._demo_mode_active = True
        self._activate_runtime(DemoTicketConnector(), active_instance=None)

    def _restore_runtime_from_demo_mode(self) -> None:
        restore_state = self._demo_mode_restore_state
        self._demo_mode_active = False
        self._demo_mode_restore_state = None
        if restore_state is None:
            self._activate_runtime(None, active_instance=None)
            return

        self._activate_runtime(
            restore_state.connector,
            active_instance=restore_state.active_instance,
        )

    def _activate_saved_instance(
        self,
        instance: DaktelaInstanceRecord,
        *,
        next_config: DaktelaInstanceConfig,
    ) -> None:
        self._demo_mode_active = False
        self._demo_mode_restore_state = None
        self._persist_instance_config(next_config)
        self._activate_runtime(
            DaktelaTicketConnector(instance.base_url, instance.user_token),
            active_instance=instance,
        )

    async def _validate_and_activate_instance(
        self,
        base_url: str,
        user_token: str,
    ) -> None:
        connector = DaktelaTicketConnector(base_url, user_token)
        try:
            await connector.get_whoiam()
        except BadTokenDaktelaError:
            validation_error = "Daktela rejected the user token."
        except CantConnectToDaktelaError:
            validation_error = "Couldn't connect to the Daktela instance."
        except DaktelaConnectorError as error:
            validation_error = f"Couldn't validate the Daktela instance: {error}"
        except Exception as error:
            validation_error = f"Couldn't validate the Daktela instance: {error}"
        else:
            validation_error = None

        if validation_error is not None:
            self.loading_message = None
            self.error_message = None
            self.notice_message = None
            self.push_screen(
                AddInstanceModal(
                    base_url=base_url,
                    user_token=user_token,
                    error_message=validation_error,
                ),
                self._handle_add_instance_result,
            )
            return

        next_config, instance = self.instance_config.with_saved_instance(
            base_url,
            user_token,
            activate=True,
        )
        self._activate_saved_instance(instance, next_config=next_config)

    def _ticket_status_options_for_category(
        self,
        category_name: str,
    ) -> list[TicketStatusOption] | None:
        status_options = self._ticket_status_options_by_category.get(category_name)
        if status_options is None:
            return None
        return [option.model_copy(deep=True) for option in status_options]

    @staticmethod
    def _view_key(view: TicketView | None) -> ViewKey | None:
        if view is None:
            return None
        return view.selection_key()

    def _current_tickets_match_view(self, view: TicketView) -> bool:
        view_key = self._view_key(view)
        return (
            view_key is not None
            and self._view_key(self.app_state.active_view) == view_key
            and self._loaded_view_key == view_key
        )

    @staticmethod
    def _ticket_key(ticket: Ticket) -> tuple[str, str] | None:
        if ticket.ticket is not None:
            return ("ticket", str(ticket.ticket))
        if ticket.name is not None:
            return ("name", str(ticket.name))
        return None

    @classmethod
    def _tickets_match(cls, left: Ticket, right: Ticket) -> bool:
        left_key = cls._ticket_key(left)
        right_key = cls._ticket_key(right)
        if left_key is not None and right_key is not None:
            return left_key == right_key
        return left == right

    @classmethod
    def _match_ticket(
        cls,
        tickets: list[Ticket],
        preferred_ticket: Ticket | None,
    ) -> Ticket | None:
        if preferred_ticket is None:
            return None

        for ticket in tickets:
            if cls._tickets_match(ticket, preferred_ticket):
                return ticket
        return None

    def _refresh_active_view(
        self,
        *,
        page: int | None = None,
        preferred_ticket: Ticket | None = None,
        suppress_loading_status: bool = False,
        reload_views_metadata: bool = False,
    ) -> bool:
        view = self.app_state.active_view
        if view is None:
            return False

        self._loaded_view_key = None
        target_page = (
            self.app_state.ticket_pagination.current_page
            if page is None
            else page
        )
        self._begin_ticket_load(
            view,
            page=target_page,
            preferred_ticket=preferred_ticket or self.app_state.active_ticket,
            suppress_loading_status=suppress_loading_status,
            reload_views_metadata=reload_views_metadata,
        )
        return True

    def _load_relative_ticket_page(self, direction: int) -> bool:
        view = self.app_state.active_view
        if view is None:
            return False

        pagination = self.app_state.ticket_pagination
        target_page = pagination.current_page + direction
        if target_page < 1 or target_page > pagination.total_pages:
            return False

        self._loaded_view_key = None
        self._begin_ticket_load(view, page=target_page)
        return True

    def _apply_refreshed_views(
        self,
        refreshed_views: list[TicketView],
        *,
        view: TicketView | None = None,
    ) -> TicketView | None:
        active_view_key = self._view_key(view if view is not None else self.app_state.active_view)
        refreshed_active_view = next(
            (candidate for candidate in refreshed_views if self._view_key(candidate) == active_view_key),
            None,
        )
        self.app_state = self.app_state.model_copy(
            update={
                "views": refreshed_views,
                "active_view": refreshed_active_view,
            }
        )
        return refreshed_active_view

    @staticmethod
    def attachment_download_default_path() -> str:
        """Return the default attachment destination shown in the popup."""

        return "~/Downloads"

    @classmethod
    def _next_attachment_download_path(
        cls,
        destination_dir: Path,
        filename: str,
    ) -> Path:
        """Return a collision-safe destination path for one attachment."""

        sanitized_name = cls._sanitize_attachment_filename(filename)
        candidate = destination_dir / sanitized_name
        if not candidate.exists():
            return candidate

        suffix = "".join(candidate.suffixes) if candidate.suffixes else candidate.suffix
        stem = candidate.name[: -len(suffix)] if suffix else candidate.name
        stem = stem or "attachment"

        index = 2
        while True:
            collision_candidate = destination_dir / f"{stem} ({index}){suffix}"
            if not collision_candidate.exists():
                return collision_candidate
            index += 1

    @staticmethod
    def _sanitize_attachment_filename(filename: str) -> str:
        """Normalize attachment filenames so downloads stay inside the chosen directory."""

        sanitized = filename.replace("\\", "_").replace("/", "_").strip().strip(".")
        return sanitized or "attachment"


def main() -> None:
    """Run the Textual application."""

    DaktelaPaleoApp().run()
