# Repository Guidelines

## What This File Is
- `AGENTS.md` is the repository-specific instruction file for coding agents and contributors working in `daktela-paleo`.
- It defines the local source of truth for project structure, development commands, testing expectations, and product interaction rules that should shape implementation decisions.
- When behavior in this repository is unclear, prefer following this file over generic defaults.

## Project Structure & Tooling
- Application code lives in `src/daktela_paleo/`.
- Tests live in `tests/`.
- Project metadata and dependencies are defined in `pyproject.toml`.
- The project supports Python `3.12+`; use Python `3.14` as the default interpreter with `uv` unless a task is specifically validating compatibility on another supported version.
- Current stack: `textual` for the TUI, `httpx` for the future async Daktela client, and `pytest` for testing.

## Build, Test, and Development Commands
- Create the virtual environment: `uv venv --python 3.14 .venv`
- Install runtime and dev dependencies: `uv sync --group dev`
- Run the TUI locally: `uv run daktela-paleo`
- Run all tests: `uv run pytest`
- Run a single test file: `uv run pytest tests/test_app.py`

## Coding & Testing Expectations
- Keep the app keyboard-first and terminal-native.
- Prefer small, focused changes that keep the Textual app testable through pytest.
- Add or update tests for every new behavior that changes screen rendering, navigation, shortcuts, or app lifecycle.
- Add or update integration tests by default for backend or API-facing changes unless the user explicitly says not to.
- Prefer Textual pilot-driven tests for end-to-end style interaction coverage.
- Never send email tests to any address other than `tomas.lysek@daktela.com`.
- Every change made by the agent must be verified with `uv run pytest`, `uv run pyright`, and `uv run ruff check` before the work is considered complete.

## TUI Interaction Principles
- The application should mimic the control style of LazyGit and LazyDocker.
- Favor fast single-key actions, predictable navigation, and minimal confirmation friction.
- Prefer keyboard-driven workflows over mouse-driven interactions.
- New screens should define shortcuts early so behavior stays consistent as the app grows.
- Avoid deep command menus for common operations when a direct shortcut is clearer.

## Shortcuts
- `q` should quit the app or close the current top-level context when that behavior makes sense.
- Arrow keys and `j` / `k` should be the default model for list navigation.
- `h` / `l` or left/right arrows should be the default model for pane or scope movement when multiple panes exist.
- `Enter` should open, confirm, or focus the active item.
- `Esc` should back out of dialogs, overlays, or secondary screens.
- `?` should be reserved for shortcut help when a help screen is added.
- Only implement shortcuts that are actually wired in code, but keep new shortcut design aligned with this model.

<!-- BACKLOG.MD MCP GUIDELINES START -->

<CRITICAL_INSTRUCTION>

## BACKLOG WORKFLOW INSTRUCTIONS

This project uses Backlog.md MCP for all task and project management activities.

**CRITICAL GUIDANCE**

- If your client supports MCP resources, read `backlog://workflow/overview` to understand when and how to use Backlog for this project.
- If your client only supports tools or the above request fails, call `backlog.get_backlog_instructions()` to load the tool-oriented overview. Use the `instruction` selector when you need `task-creation`, `task-execution`, or `task-finalization`.

- **First time working here?** Read the overview resource IMMEDIATELY to learn the workflow
- **Already familiar?** You should have the overview cached ("## Backlog.md Overview (MCP)")
- **When to read it**: BEFORE creating tasks, or when you're unsure whether to track work

These guides cover:
- Decision framework for when to create tasks
- Search-first workflow to avoid duplicates
- Links to detailed guides for task creation, execution, and finalization
- MCP tools reference

You MUST read the overview resource to understand the complete workflow. The information is NOT summarized here.

</CRITICAL_INSTRUCTION>

<!-- BACKLOG.MD MCP GUIDELINES END -->
