import asyncio
import os
from collections.abc import Callable
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
from typing import Any, cast

import pytest
from rich.text import Text
from textual.color import Color
from textual.containers import Vertical
from textual.css.query import NoMatches
from textual.widgets import DataTable, Footer, Header, Input, ListView, Select, Static, TextArea

from daktela_paleo import app as app_module
from daktela_paleo.app import DaktelaPaleoApp
from daktela_paleo.connectors import (
    DaktelaTicketConnector,
    DemoTicketConnector,
    MockTicketConnector,
    TicketActivity,
    TicketCategoryOption,
    TicketConnector,
    TicketStatusOption,
    TicketUserOption,
)
from daktela_paleo.connectors.daktela import BadTokenDaktelaError
from daktela_paleo.instances import (
    DaktelaInstanceConfig,
    DaktelaInstanceRecord,
    DaktelaInstanceStore,
)
from daktela_paleo.models import (
    AppState,
    Ticket,
    TicketActivityAttachment,
    TicketCommentCreateRequest,
    TicketEmailAction,
    TicketEmailDraft,
    TicketEmailSendRequest,
    TicketEditPatch,
    TicketPage,
    TicketPagination,
    TicketPriority,
    TicketStage,
    TICKET_GRID_DEFAULT_COLUMN_KEYS,
    TicketView,
)
from daktela_paleo.screens.main.widgets.instance_management import (
    AddInstanceModal,
    InstanceManagementModal,
)
from daktela_paleo.screens.main.screen import TicketList
from daktela_paleo.screens.main.widgets.tickets import TicketTable
from daktela_paleo.screens.ticket_detail.widgets.comment_reply import CommentReplyComposer
from daktela_paleo.screens.ticket_detail.widgets.detail_pane import (
    ActivityImageWidget,
    DetailPaneBody,
)
from daktela_paleo.screens.ticket_detail.widgets.email_compose import TicketEmailComposer
from daktela_paleo.screens.ticket_detail.widgets.form import (
    NO_STATUS_VALUE,
    TicketDetailForm,
    UNASSIGNED_USER_VALUE,
)
from daktela_paleo.screens.ticket_detail.widgets.modals import (
    ActivityLinkPickerModal,
    AttachmentDestinationPickerModal,
    UnsavedChangesModal,
)
from daktela_paleo.screens.ticket_detail.screen import (
    ACTIVITY_COPY_EMPTY_STATUS,
    ACTIVITY_COPY_SUCCESS_STATUS,
    REPLY_USER_UNMATCHED_STATUS,
    TicketDetail,
)
from daktela_paleo.themes import TOKYONIGHT_MOON


def make_ticket(
    title: str = "Printer is jammed",
    *,
    name: int | None = None,
    category: str = "category_123456",
    category_name: str | None = None,
    description: str | None = None,
    contact: str | None = None,
    user: str | None = None,
    user_name: str | None = None,
    statuses: dict[str, str] | None = None,
    edited: datetime | None = None,
    reopen: datetime | None = None,
    stage: TicketStage = TicketStage.OPEN,
    priority: TicketPriority = TicketPriority.HIGH,
) -> Ticket:
    return Ticket(
        name=name,
        title=title,
        category=category,
        category_name=category if category_name is None else category_name,
        description=description,
        contact=contact,
        user=user,
        user_name=user if user_name is None else user_name,
        statuses=statuses,
        edited=edited,
        reopen=reopen,
        stage=stage,
        priority=priority,
    )


def make_ticket_view(
    title: str = "Open high priority tickets",
    *,
    view: int | None = None,
    name: str | None = None,
    parent_view: str | None = None,
    ticket_count: int | None = None,
) -> TicketView:
    return TicketView(
        title=title,
        view=view,
        name=name,
        parent_view=parent_view,
        ticket_count=ticket_count,
    )


def make_ticket_batch(count: int, *, start: int = 1000) -> list[Ticket]:
    return [
        make_ticket(title=f"Ticket {index}", name=start + index)
        for index in range(count)
    ]


def make_activity(
    title: str = "Customer replied",
    *,
    name: str | None = None,
    type: str = "EMAIL",
    user: str | None = "Operator One",
    user_name: str | None = None,
    time: str = "2026-03-28 10:30:00",
    body_html: str | None = "<p>Hello<br />world</p>",
    item_model: str | None = "activitiesEmail",
    direction: str | None = None,
    attachments: list[dict[str, object] | TicketActivityAttachment] | None = None,
) -> TicketActivity:
    item = None
    if any(value is not None for value in (item_model, title, body_html, direction)):
        item = {
            "model": item_model,
            "title": title,
            "time": time,
            "body_html": body_html,
            "direction": direction,
        }
        if item_model == "activitiesEmail":
            item["attachments"] = attachments
    activity = {
        "name": name,
        "type": type,
        "title": title,
        "time": time,
        "user": user,
        "user_name": user if user_name is None else user_name,
        "item": item,
    }
    if item_model != "activitiesEmail":
        activity["attachments"] = attachments
    return TicketActivity.model_validate(
        activity
    )


def make_demo_app() -> DaktelaPaleoApp:
    return DaktelaPaleoApp(connector=DemoTicketConnector())


def make_saved_instance(
    *,
    id: str = "primary",
    base_url: str = "demo.daktela.com/",
    user_token: str = "token-123",
) -> DaktelaInstanceRecord:
    return DaktelaInstanceRecord.create(base_url, user_token, id=id)


def make_instance_store(
    tmp_path: Path,
    config: DaktelaInstanceConfig | None = None,
) -> DaktelaInstanceStore:
    store = DaktelaInstanceStore(tmp_path / "instances.json")
    if config is not None:
        store.save(config)
    return store


def rendered_labels(app: DaktelaPaleoApp, selector: str) -> list[str]:
    list_view = app.query_one(selector, ListView)
    return [str(widget.render()) for widget in list_view.query("ListItem Static")]


def modal_labels(screen: InstanceManagementModal, selector: str) -> list[str]:
    list_view = screen.query_one(selector, ListView)
    return [str(widget.render()) for widget in list_view.query("ListItem Static")]


def ticket_headers(app: DaktelaPaleoApp) -> list[str]:
    ticket_table = app.query_one("#tickets-table", DataTable)
    return [column.label.plain for column in ticket_table.ordered_columns]


def ticket_rows(app: DaktelaPaleoApp) -> list[list[str]]:
    ticket_table = app.query_one("#tickets-table", DataTable)
    return [
        [
            cell.plain.strip() if isinstance(cell, Text) else str(cell)
            for cell in ticket_table.get_row_at(index)
        ]
        for index in range(ticket_table.row_count)
    ]


def right_title_label(screen: TicketDetail) -> Static:
    return screen.query_one("#ticket-detail-right-title-label", Static)


def quick_action_labels(screen: TicketDetail) -> list[str]:
    return [
        str(widget.render())
        for widget in screen.query(".detail-pane-quick-action")
        if isinstance(widget, Static)
    ]


def status_text(node: Any) -> str:
    return str(node.query_one("#status-bar", Static).render())


def modal_link_urls(screen: ActivityLinkPickerModal) -> list[str]:
    return [
        str(widget.render())
        for widget in screen.query(".activity-link-picker-url")
        if isinstance(widget, Static)
    ]


def instance_context_text(node: Any) -> str:
    return str(node.query_one("#instance-context", Static).render())


async def wait_until(
    predicate: Callable[[], bool],
    *,
    timeout: float = 3.0,
    interval: float = 0.05,
) -> None:
    deadline = asyncio.get_running_loop().time() + timeout
    while True:
        if predicate():
            return
        if asyncio.get_running_loop().time() >= deadline:
            raise AssertionError("Timed out while waiting for test condition.")
        await asyncio.sleep(interval)


class ViewsOnlyConnector(TicketConnector):
    def __init__(self, views: list[TicketView]) -> None:
        self.views = views
        self.list_views_calls = 0
        self.list_tickets_calls: list[TicketView | None] = []

    async def list_views(self) -> list[TicketView]:
        self.list_views_calls += 1
        return [view.model_copy(deep=True) for view in self.views]

    async def list_tickets(self, view: TicketView | None = None) -> list[Ticket]:
        self.list_tickets_calls.append(view)
        raise NotImplementedError(
            "Daktela ticket loading is not scaffolded from the mailbot client yet."
        )

    async def list_ticket_categories(self) -> list[TicketCategoryOption]:
        return []

    async def list_ticket_statuses(self, category_name: str) -> list[TicketStatusOption]:
        return []

    async def list_ticket_users(self) -> list[TicketUserOption]:
        return []

    async def list_ticket_activities(self, ticket: Ticket) -> list[TicketActivity]:
        return []

    async def load_ticket_activity_attachment(
        self,
        activity: TicketActivity,
        attachment: TicketActivityAttachment,
    ) -> bytes:
        raise AssertionError(
            "load_ticket_activity_attachment should not be called for "
            f"{activity.title}: {attachment.title}"
        )

    async def store_ticket(self, ticket: Ticket, patch: TicketEditPatch) -> Ticket:
        raise AssertionError(f"store_ticket should not be called for {ticket.title}: {patch}")

    async def create_ticket_comment(self, ticket: Ticket, request: TicketCommentCreateRequest) -> None:
        raise AssertionError(
            f"create_ticket_comment should not be called for {ticket.title}: {request}"
        )

    async def get_ticket_email_draft(
        self,
        ticket: Ticket,
        activity: TicketActivity,
        action: TicketEmailAction,
    ) -> TicketEmailDraft:
        raise AssertionError(
            "get_ticket_email_draft should not be called for "
            f"{ticket.title}: {activity.title} {action}"
        )

    async def send_ticket_email(self, ticket: Ticket, request: TicketEmailSendRequest) -> None:
        raise AssertionError(
            f"send_ticket_email should not be called for {ticket.title}: {request}"
        )


def test_app_uses_tokyonight_moon_theme() -> None:
    app = make_demo_app()

    assert app.theme == TOKYONIGHT_MOON.name
    assert app.available_themes[TOKYONIGHT_MOON.name] == TOKYONIGHT_MOON


def test_app_bootstraps_daktela_connector_from_saved_active_instance(tmp_path: Path) -> None:
    saved_instance = make_saved_instance()
    store = make_instance_store(
        tmp_path,
        DaktelaInstanceConfig(
            active_instance_id=saved_instance.id,
            instances=[saved_instance],
        ),
    )
    app = DaktelaPaleoApp(instance_store=store)

    assert isinstance(app.connector, DaktelaTicketConnector)
    assert app.connector.pbx_name == "https://demo.daktela.com"
    assert app.connector.user_token == "token-123"
    assert app.active_instance == saved_instance


def test_app_starts_disconnected_without_saved_active_instance(tmp_path: Path) -> None:
    app = DaktelaPaleoApp(instance_store=make_instance_store(tmp_path))

    assert app.connector is None
    assert app.active_instance is None
    assert app._should_load_initial_state is False


def test_app_loads_saved_instance_metadata_when_connector_is_injected(
    tmp_path: Path,
) -> None:
    saved_instance = make_saved_instance()
    store = make_instance_store(
        tmp_path,
        DaktelaInstanceConfig(
            active_instance_id=saved_instance.id,
            instances=[saved_instance],
        ),
    )

    app = DaktelaPaleoApp(
        connector=DemoTicketConnector(),
        instance_store=store,
    )

    assert app.active_instance == saved_instance


def test_tokyonight_moon_overrides_interaction_palette() -> None:
    colors = TOKYONIGHT_MOON.to_color_system().generate()

    assert colors["primary"] == "#82AAFF"
    assert colors["secondary"] == "#C099FF"
    assert colors["text-muted"] == "#828BB8"
    assert colors["foreground-muted"] == "#828BB8"
    assert colors["border"] == "#3B4261"
    assert colors["border-blurred"] == "#2F334D"
    assert colors["block-cursor-background"] == "#2F334D"
    assert colors["block-cursor-foreground"] == "#C8D3F5"
    assert colors["block-cursor-text-style"] == "none"
    assert colors["block-cursor-blurred-background"] == "#2A2D44"
    assert colors["block-cursor-blurred-foreground"] == "#828BB8"
    assert colors["footer-background"] == "#222436"
    assert colors["footer-key-foreground"] == "#82AAFF"
    assert colors["footer-description-foreground"] == "#828BB8"
    assert colors["input-selection-background"] == "#3B426166"


def test_watch_app_state_ignores_missing_browser(monkeypatch: pytest.MonkeyPatch) -> None:
    app = make_demo_app()

    def raise_no_matches(*args: object, **kwargs: object) -> None:
        raise NoMatches("ticket browser not mounted")

    monkeypatch.setattr(app, "query_one", raise_no_matches)

    app.watch_app_state(AppState())


def test_watch_status_message_returns_early_before_mount(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()

    def fail_if_called(*args: object, **kwargs: object) -> None:
        raise AssertionError("query_one should not be called before mount")

    monkeypatch.setattr(DaktelaPaleoApp, "is_mounted", property(lambda self: False))
    monkeypatch.setattr(app, "query_one", fail_if_called)

    app.watch_status_message("Busy")


def test_watch_instance_context_returns_early_before_mount(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()

    def fail_if_called(*args: object, **kwargs: object) -> None:
        raise AssertionError("_update_instance_context_widgets should not be called before mount")

    monkeypatch.setattr(DaktelaPaleoApp, "is_mounted", property(lambda self: False))
    monkeypatch.setattr(app, "_update_instance_context_widgets", fail_if_called)

    app.watch_instance_context("Instance: https://demo.daktela.com")


def test_main_runs_application(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[str] = []

    def fake_run(self: DaktelaPaleoApp) -> None:
        calls.append(self.title)

    monkeypatch.setattr(DaktelaPaleoApp, "run", fake_run)

    app_module.main()

    assert calls == ["Daktela Paleo"]


def test_demo_ticket_connector_state_includes_three_level_view_hierarchy() -> None:
    state = DemoTicketConnector.build_state()
    views_by_name = {view.name: view for view in state.views if view.name is not None}

    assert len(state.views) == 17
    assert views_by_name["hl2"].parent_view == "demo"
    assert views_by_name["hl2_city17"].parent_view == "hl2"
    assert views_by_name["matrix"].parent_view == "demo"
    assert views_by_name["matrix_zion"].parent_view == "matrix"
    assert views_by_name["star_wars"].parent_view == "demo"
    assert views_by_name["star_wars_rebel"].parent_view == "star_wars"
    assert views_by_name["lotr"].parent_view == "demo"
    assert views_by_name["lotr_shire"].parent_view == "lotr"


@pytest.mark.asyncio
async def test_app_renders_two_pane_layout_with_dummy_data() -> None:
    app = make_demo_app()
    expected_tickets = DemoTicketConnector.build_tickets()

    async with app.run_test() as pilot:
        await pilot.pause()

        assert app.title == "Daktela Paleo"
        assert app.query_one(Header)
        assert app.query_one(Footer)

        assert app.query_one("#status-bar", Static).render() == "Selected view: Demo"
        assert rendered_labels(app, "#views-list")[:6] == [
            "Demo",
            "|- Half-Life 2",
            "|  |- City 17 Queue",
            "|  |- Resistance Relay",
            "|  `- Combine Escalations",
            "|- Matrix",
        ]
        assert len(rendered_labels(app, "#views-list")) == 17
        assert ticket_headers(app) == [
            "",
            "#",
            "Title",
            "Priority",
            "Category",
            "Statuses",
            "Contact",
            "Stage",
            "User",
            "Edited",
        ]
        assert ticket_rows(app)[:3] == [
            ["1", "2001", "Strider signal lost", "1", "Field Ops", "Field review, Signal loss", "Alyx Vance", "Open", "Alyx Vance", "-"],
            ["1", "2002", "Ration queue stalled", "2", "Citizen Priority", "Ration queue", "Dr. Kleiner", "Waiting", "Barney Calhoun", "-"],
            ["2", "2003", "Checkpoint lockout at plaza", "1", "Field Ops", "Checkpoint block", "Resistance Cell 12", "Waiting", "Judith Mossman", "-"],
        ]
        assert len(DemoTicketConnector.build_state().tickets) == 16
        assert app.query_one("#tickets-table", DataTable).row_count == len(expected_tickets)
        assert app.query_one("#status-bar", Static).region.height == 1
        assert (
            app.query_one("#status-bar", Static).region.y
            < app.query_one(Footer).region.y
        )
        assert app.focused is app.query_one("#views-list", ListView)


@pytest.mark.asyncio
async def test_demo_connector_paginated_leaf_navigates_between_pages() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("j", "j", "enter")
        await wait_until(
            lambda: (
                app.app_state.active_view is not None
                and app.app_state.active_view.name == "hl2_city17"
                and ticket_rows(app)[0][1] == "2001"
            )
        )

        assert app.query_one("#tickets-title", Static).render() == "Tickets 1/2"

        await pilot.press("ctrl+d")
        await wait_until(lambda: ticket_rows(app)[0][1] == "2002")

        assert app.query_one("#tickets-title", Static).render() == "Tickets 2/2"


@pytest.mark.asyncio
async def test_demo_connector_link_picker_includes_seeded_link_and_image(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    opened_urls: list[str] = []

    monkeypatch.setattr(
        app_module.webbrowser,
        "open",
        lambda url: opened_urls.append(url) or True,
    )

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("j", "j", "enter", "enter")
        await wait_until(
            lambda: "Scanner pass from tunnel approach"
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        await pilot.press("u")
        await pilot.pause()

        assert isinstance(app.screen, ActivityLinkPickerModal)
        assert modal_link_urls(app.screen) == [
            "https://demo.invalid/hl2/city-17/strider",
            "Image: Strider silhouette",
        ]

        await pilot.press("enter")
        await wait_until(lambda: opened_urls == ["https://demo.invalid/hl2/city-17/strider"])


@pytest.mark.asyncio
async def test_demo_connector_email_quick_actions_use_seeded_drafts() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("j", "j", "j", "j", "j", "j", "enter", "enter")
        await wait_until(
            lambda: "Visual confirmed near Dock 12."
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        detail_screen = cast(TicketDetail, app.screen)
        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        activity_titles = [
            str(widget.render())
            for widget in right_body.query(".detail-pane-entry-headline")
            if isinstance(widget, Static)
        ]
        assert activity_titles == [
            "Sentinel sweep over Zion",
            "Dock rotation checklist",
            "Fallback sequence approved",
            "Lane readiness matrix",
            "Operator note from Morpheus",
        ]

        await pilot.press("tab")
        await pilot.pause()

        assert quick_action_labels(detail_screen) == [
            "Reply to all (r)",
            "Forward (f)",
            "Copy (y)",
        ]

        await pilot.press("r")
        await wait_until(lambda: detail_screen.query_one("#email-reply-composer", TicketEmailComposer).is_open)

        composer = detail_screen.query_one("#email-reply-composer", TicketEmailComposer)
        assert composer.query_one("#email-reply-to", Input).value == (
            "zion-ops@matrix.invalid, niobe@matrix.invalid"
        )
        assert composer.query_one("#email-reply-subject", Input).value == "Re: Sentinel sweep over Zion"
        assert "Dock 12 traffic" in composer.query_one("#email-reply-body", TextArea).text

        await pilot.press("escape")
        await pilot.pause()
        await pilot.press("f")
        await wait_until(lambda: detail_screen.query_one("#email-reply-composer", TicketEmailComposer).is_open)

        composer = detail_screen.query_one("#email-reply-composer", TicketEmailComposer)
        assert composer.query_one("#email-reply-to", Input).value == "lock@matrix.invalid"
        assert composer.query_one("#email-reply-subject", Input).value == "Fwd: Sentinel sweep over Zion"
        assert "dock crews" in composer.query_one("#email-reply-body", TextArea).text


@pytest.mark.asyncio
async def test_demo_connector_lotr_hero_ticket_renders_inline_image_when_supported(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(DetailPaneBody, "_supports_inline_images", lambda self: True)
    app = make_demo_app()

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("j", "j", "j", "j", "j", "j", "j", "j", "j", "j", "j", "j", "j", "j", "enter")
        await wait_until(
            lambda: (
                app.app_state.active_view is not None
                and app.app_state.active_view.name == "lotr_shire"
                and ticket_rows(app)[0][1] == "2301"
            )
        )

        await pilot.press("enter")
        await wait_until(
            lambda: "Ranger sketch from the Greenway"
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )
        await pilot.pause()
        await pilot.pause()

        right_body = cast(TicketDetail, app.screen).query_one("#ticket-detail-right-body", DetailPaneBody)
        activity_titles = [
            str(widget.render())
            for widget in right_body.query(".detail-pane-entry-headline")
            if isinstance(widget, Static)
        ]
        image_widget = right_body.query_one(".detail-pane-entry-image", ActivityImageWidget)
        first_line = image_widget.render_line(0)

        assert activity_titles == [
            "Ranger sketch from the Greenway",
            "Courier handoff checklist",
            "Fallback route if the ford closes",
            "Waystation coverage board",
        ]
        assert any(segment.text.startswith("\x1b_G") for segment in first_line)


@pytest.mark.asyncio
async def test_app_applies_tokyonight_moon_chrome_colors() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        await pilot.pause()

        header = app.query_one(Header)
        footer = app.query_one(Footer)
        status_bar = app.query_one("#status-bar", Static)
        views_title = app.query_one("#views-title", Static)
        tickets_title = app.query_one("#tickets-title", Static)
        views_list = app.query_one("#views-list", ListView)
        tickets_table = app.query_one("#tickets-table", TicketTable)

        assert header.styles.background == Color.parse("#222436")
        assert footer.styles.background == Color.parse("#222436")
        assert status_bar.styles.background == Color.parse("#222436")
        assert status_bar.styles.color == Color.parse("#828BB8")
        assert views_title.styles.background == Color.parse("#2F334D")
        assert tickets_title.styles.background == Color.parse("#2F334D")
        assert views_list.styles.background == Color.parse("#1E2030")
        assert tickets_table.styles.background == Color.parse("#1E2030")


@pytest.mark.asyncio
async def test_app_renders_provided_initial_state() -> None:
    state = AppState(
        tickets=[
            make_ticket(
                title="Broken scanner",
                name=2001,
                contact="vip_client",
                user="operator_1",
            )
        ],
        views=[make_ticket_view(title="Escalated only")],
        active_view=make_ticket_view(title="Escalated only"),
        active_ticket=make_ticket(
            title="Broken scanner",
            name=2001,
            contact="vip_client",
            user="operator_1",
        ),
    )
    app = DaktelaPaleoApp(
        initial_state=state,
        connector=MockTicketConnector.from_state(state),
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        assert rendered_labels(app, "#views-list") == ["Escalated only"]
        assert ticket_rows(app) == [
            ["1", "2001", "Broken scanner", "1", "category_123456", "-", "vip_client", "Open", "operator_1", "-"]
        ]

        views_list = app.query_one("#views-list", ListView)
        tickets_table = app.query_one("#tickets-table", TicketTable)
        assert views_list.index == 0
        assert tickets_table.cursor_row == 0


@pytest.mark.asyncio
async def test_app_renders_ticket_headers_from_initial_state_column_keys() -> None:
    state = AppState(
        tickets=[
            make_ticket(
                title="Broken scanner",
                name=2001,
                user="operator_1",
            )
        ],
        views=[make_ticket_view(title="Escalated only")],
        active_view=make_ticket_view(title="Escalated only"),
        ticket_grid_column_keys=["edited", "user.title"],
    )
    app = DaktelaPaleoApp(
        initial_state=state,
        connector=MockTicketConnector.from_state(state),
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        assert ticket_headers(app) == [
            "",
            "#",
            "Title",
            "Edited",
            "User",
        ]
        assert ticket_rows(app) == [
            ["1", "2001", "Broken scanner", "-", "operator_1"]
        ]


@pytest.mark.asyncio
async def test_app_updates_ticket_headers_when_ticket_grid_columns_change() -> None:
    state = AppState(
        tickets=[
            make_ticket(
                title="Broken scanner",
                name=2001,
                user="operator_1",
            )
        ],
        views=[make_ticket_view(title="Escalated only")],
        active_view=make_ticket_view(title="Escalated only"),
    )
    app = DaktelaPaleoApp(connector=MockTicketConnector.from_state(state))

    async with app.run_test() as pilot:
        await pilot.pause()

        app.set_app_state(
            app.app_state.model_copy(
                update={"ticket_grid_column_keys": ["user.title", "unsupported"]}
            )
        )
        await pilot.pause()

        assert ticket_headers(app) == [
            "",
            "#",
            "Title",
            "User",
        ]
        assert ticket_rows(app) == [
            ["1", "2001", "Broken scanner", "operator_1"]
        ]


@pytest.mark.asyncio
async def test_app_loads_initial_state_from_connector() -> None:
    connector = MockTicketConnector(
        views=[make_ticket_view(title="Connector view")],
        tickets=[
            make_ticket(title="Connector ticket", name=5001, contact="gold", user="agent_1")
        ],
    )
    app = DaktelaPaleoApp(connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        assert rendered_labels(app, "#views-list") == ["Connector view"]
        assert ticket_rows(app) == [
            ["1", "5001", "Connector ticket", "1", "category_123456", "-", "gold", "Open", "agent_1", "-"]
        ]
        assert app.app_state.active_view is not None
        assert app.app_state.active_view.title == "Connector view"
        assert app.query_one("#status-bar", Static).render() == "Selected view: Connector view"
        assert connector.list_views_calls == 1
        assert connector.list_tickets_calls == [("title", "Connector view")]


@pytest.mark.asyncio
async def test_app_renders_view_ticket_counts_from_connector() -> None:
    connector = MockTicketConnector(
        views=[
            TicketView(name="connector_view", title="Connector view", ticket_count=12),
            TicketView(name="uncounted_view", title="Uncounted view"),
        ]
    )
    app = DaktelaPaleoApp(connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        assert rendered_labels(app, "#views-list") == [
            "Connector view (12)",
            "Uncounted view",
        ]


@pytest.mark.asyncio
async def test_app_shows_ticket_table_loader_during_initial_ticket_load() -> None:
    view = make_ticket_view(title="Connector view")
    connector = MockTicketConnector(
        views=[view],
        tickets=[],
    )
    connector.set_tickets_for_view(
        view,
        [make_ticket(title="Connector ticket", name=5001, contact="gold", user="agent_1")],
        delay=0.2,
    )
    app = DaktelaPaleoApp(connector=connector)

    async with app.run_test():
        await wait_until(lambda: connector.list_tickets_calls == [("title", "Connector view")])

        ticket_table = app.query_one("#tickets-table", DataTable)
        assert ticket_table.loading is True
        assert ticket_table.row_count == 0

        await wait_until(lambda: ticket_table.loading is False)

        assert ticket_rows(app) == [
            ["1", "5001", "Connector ticket", "1", "category_123456", "-", "gold", "Open", "agent_1", "-"]
        ]


@pytest.mark.asyncio
async def test_app_loads_default_ticket_list_when_connector_has_no_views() -> None:
    connector = MockTicketConnector(
        views=[],
        tickets=[make_ticket(title="Unscoped ticket", name=5002, contact="bronze")],
    )
    app = DaktelaPaleoApp(connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        assert rendered_labels(app, "#views-list") == []
        assert ticket_rows(app) == [
            ["1", "5002", "Unscoped ticket", "1", "category_123456", "-", "bronze", "Open", "-", "-"]
        ]
        assert app.app_state.active_view is None
        assert app.query_one("#status-bar", Static).render() == "Ready"
        assert connector.list_tickets_calls == [None]


@pytest.mark.asyncio
async def test_i_opens_instance_manager_with_saved_active_instance(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    saved_instance = make_saved_instance()
    store = make_instance_store(
        tmp_path,
        DaktelaInstanceConfig(
            active_instance_id=saved_instance.id,
            instances=[saved_instance],
        ),
    )

    async def fake_list_views(self: DaktelaTicketConnector) -> list[TicketView]:
        return []

    async def fake_list_tickets(
        self: DaktelaTicketConnector,
        view: TicketView | None = None,
    ) -> list[Ticket]:
        return []

    monkeypatch.setattr(DaktelaTicketConnector, "list_views", fake_list_views)
    monkeypatch.setattr(DaktelaTicketConnector, "list_tickets", fake_list_tickets)
    app = DaktelaPaleoApp(instance_store=store)

    async with app.run_test() as pilot:
        await pilot.pause()

        assert instance_context_text(app) == "Instance: https://demo.daktela.com"

        await pilot.press("i")
        await pilot.pause()

        assert isinstance(app.screen, InstanceManagementModal)
        assert modal_labels(app.screen, "#instance-management-list") == [
            "https://demo.daktela.com (active)"
        ]


@pytest.mark.asyncio
async def test_app_starts_disconnected_without_startup_error_when_instance_config_is_missing(
    tmp_path: Path,
) -> None:
    app = DaktelaPaleoApp(instance_store=make_instance_store(tmp_path))

    async with app.run_test() as pilot:
        await pilot.pause()

        assert app.connector is None
        assert rendered_labels(app, "#views-list") == []
        assert ticket_rows(app) == []
        assert status_text(app) == "Ready"
        assert instance_context_text(app) == "Instance: disconnected"


@pytest.mark.asyncio
async def test_c_does_not_open_instance_manager_on_main_screen(
    tmp_path: Path,
) -> None:
    app = DaktelaPaleoApp(instance_store=make_instance_store(tmp_path))

    async with app.run_test() as pilot:
        await pilot.pause()

        focused = app.focused

        await pilot.press("c")
        await pilot.pause()

        assert not isinstance(app.screen, InstanceManagementModal)
        assert app.focused is focused


@pytest.mark.asyncio
async def test_instance_manager_a_opens_add_instance_modal_from_empty_state(
    tmp_path: Path,
) -> None:
    app = DaktelaPaleoApp(instance_store=make_instance_store(tmp_path))

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("i")
        await pilot.pause()

        assert isinstance(app.screen, InstanceManagementModal)
        assert "No Daktela instances are configured yet." in str(
            app.screen.query_one("#instance-management-empty", Static).render()
        )

        await pilot.press("a")
        await pilot.pause()

        assert isinstance(app.screen, AddInstanceModal)
        assert app.screen.query_one("#add-instance-base-url", Input).has_focus


@pytest.mark.asyncio
async def test_instance_manager_escape_keeps_current_connector_and_data() -> None:
    connector = MockTicketConnector(
        views=[make_ticket_view(title="Connector view")],
        tickets=[make_ticket(title="Connector ticket", name=5001)],
    )
    app = DaktelaPaleoApp(connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("i", "escape")
        await pilot.pause()

        assert not isinstance(app.screen, InstanceManagementModal)
        assert app.connector is connector
        assert rendered_labels(app, "#views-list") == ["Connector view"]
        assert ticket_rows(app) == [
            ["1", "5001", "Connector ticket", "1", "category_123456", "-", "-", "Open", "-", "-"]
        ]


@pytest.mark.asyncio
async def test_instance_manager_q_closes_modal_without_quitting(
    tmp_path: Path,
) -> None:
    app = DaktelaPaleoApp(instance_store=make_instance_store(tmp_path))

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("i")
        await pilot.pause()
        assert isinstance(app.screen, InstanceManagementModal)

        await pilot.press("q")
        await pilot.pause()

        assert app.is_running is True
        assert not isinstance(app.screen, InstanceManagementModal)


@pytest.mark.asyncio
async def test_instance_manager_hidden_demo_toggle_round_trips_disconnected_session(
    tmp_path: Path,
) -> None:
    store = make_instance_store(tmp_path)
    app = DaktelaPaleoApp(instance_store=store)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("i")
        await pilot.pause()

        assert isinstance(app.screen, InstanceManagementModal)
        assert app.screen.query_one("#instance-management-hint", Static).render() == (
            "Use j/k or arrows to move, Enter/l to activate, a to add, Esc/q to close."
        )

        await pilot.press("d")
        await wait_until(
            lambda: (
                isinstance(app.connector, DemoTicketConnector)
                and app.app_state.active_view is not None
                and app.app_state.active_view.title == "Demo"
            )
        )

        assert instance_context_text(app) == "Instance: demo mode"
        assert app.active_instance is None
        assert store.load() == DaktelaInstanceConfig()
        assert ticket_rows(app)[0][1] == "2001"

        await pilot.press("i")
        await pilot.pause()

        assert isinstance(app.screen, InstanceManagementModal)
        assert "demo" not in str(
            app.screen.query_one("#instance-management-empty", Static).render()
        ).lower()

        await pilot.press("d")
        await pilot.pause()

        assert app.connector is None
        assert app.app_state.active_view is None
        assert app.app_state.tickets == []
        assert instance_context_text(app) == "Instance: disconnected"
        assert store.load() == DaktelaInstanceConfig()


@pytest.mark.asyncio
async def test_instance_manager_hidden_demo_toggle_restores_saved_runtime(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    saved_instance = make_saved_instance(
        id="primary",
        base_url="primary.daktela.com/",
        user_token="token-1",
    )
    store = make_instance_store(
        tmp_path,
        DaktelaInstanceConfig(
            active_instance_id=saved_instance.id,
            instances=[saved_instance],
        ),
    )

    async def fake_list_views(self: DaktelaTicketConnector) -> list[TicketView]:
        return [TicketView(name="primary_view", title="Primary View")]

    async def fake_list_tickets(
        self: DaktelaTicketConnector,
        view: TicketView | None = None,
    ) -> list[Ticket]:
        return [make_ticket(title="Primary ticket", name=6101)]

    async def fake_get_current_user(self: DaktelaTicketConnector) -> TicketUserOption | None:
        return None

    async def fake_get_ticket_grid_column_keys(
        self: DaktelaTicketConnector,
    ) -> list[str] | None:
        return None

    monkeypatch.setattr(DaktelaTicketConnector, "list_views", fake_list_views)
    monkeypatch.setattr(DaktelaTicketConnector, "list_tickets", fake_list_tickets)
    monkeypatch.setattr(DaktelaTicketConnector, "get_current_user", fake_get_current_user)
    monkeypatch.setattr(
        DaktelaTicketConnector,
        "get_ticket_grid_column_keys",
        fake_get_ticket_grid_column_keys,
    )
    app = DaktelaPaleoApp(instance_store=store)

    async with app.run_test() as pilot:
        await wait_until(
            lambda: app.app_state.active_view is not None and app.app_state.active_view.title == "Primary View"
        )

        original_connector = app.connector
        assert isinstance(original_connector, DaktelaTicketConnector)
        assert instance_context_text(app) == "Instance: https://primary.daktela.com"

        await pilot.press("i")
        await pilot.pause()

        assert isinstance(app.screen, InstanceManagementModal)
        assert modal_labels(app.screen, "#instance-management-list") == [
            "https://primary.daktela.com (active)"
        ]

        await pilot.press("d")
        await wait_until(
            lambda: (
                isinstance(app.connector, DemoTicketConnector)
                and app.app_state.active_view is not None
                and app.app_state.active_view.title == "Demo"
            )
        )

        assert instance_context_text(app) == "Instance: demo mode"
        assert store.load().active_instance_id == saved_instance.id

        await pilot.press("i")
        await pilot.pause()

        assert isinstance(app.screen, InstanceManagementModal)
        assert modal_labels(app.screen, "#instance-management-list") == [
            "https://primary.daktela.com"
        ]

        await pilot.press("d")
        await wait_until(
            lambda: (
                app.connector is original_connector
                and app.app_state.active_view is not None
                and app.app_state.active_view.title == "Primary View"
            )
        )

        assert app.active_instance == saved_instance
        assert instance_context_text(app) == "Instance: https://primary.daktela.com"
        assert ticket_rows(app) == [
            ["1", "6101", "Primary ticket", "1", "category_123456", "-", "-", "Open", "-", "-"]
        ]
        assert store.load() == DaktelaInstanceConfig(
            active_instance_id=saved_instance.id,
            instances=[saved_instance],
        )


@pytest.mark.asyncio
async def test_instance_manager_activation_exits_demo_mode_and_switches_saved_instance(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    first = make_saved_instance(id="primary", base_url="primary.daktela.com/", user_token="token-1")
    second = make_saved_instance(id="secondary", base_url="secondary.daktela.com/", user_token="token-2")
    store = make_instance_store(
        tmp_path,
        DaktelaInstanceConfig(
            active_instance_id=first.id,
            instances=[first, second],
        ),
    )

    async def fake_list_views(self: DaktelaTicketConnector) -> list[TicketView]:
        title = "Primary View" if self.user_token == "token-1" else "Secondary View"
        return [TicketView(name=title.lower().replace(" ", "_"), title=title)]

    async def fake_list_tickets(
        self: DaktelaTicketConnector,
        view: TicketView | None = None,
    ) -> list[Ticket]:
        ticket_name = 6101 if self.user_token == "token-1" else 6102
        ticket_title = "Primary ticket" if self.user_token == "token-1" else "Secondary ticket"
        return [make_ticket(title=ticket_title, name=ticket_name)]

    async def fake_get_current_user(self: DaktelaTicketConnector) -> TicketUserOption | None:
        return None

    async def fake_get_ticket_grid_column_keys(
        self: DaktelaTicketConnector,
    ) -> list[str] | None:
        return None

    monkeypatch.setattr(DaktelaTicketConnector, "list_views", fake_list_views)
    monkeypatch.setattr(DaktelaTicketConnector, "list_tickets", fake_list_tickets)
    monkeypatch.setattr(DaktelaTicketConnector, "get_current_user", fake_get_current_user)
    monkeypatch.setattr(
        DaktelaTicketConnector,
        "get_ticket_grid_column_keys",
        fake_get_ticket_grid_column_keys,
    )
    app = DaktelaPaleoApp(instance_store=store)

    async with app.run_test() as pilot:
        await wait_until(lambda: app.app_state.active_view is not None and app.app_state.active_view.title == "Primary View")

        await pilot.press("i", "d")
        await wait_until(
            lambda: (
                isinstance(app.connector, DemoTicketConnector)
                and app.app_state.active_view is not None
                and app.app_state.active_view.title == "Demo"
            )
        )

        assert instance_context_text(app) == "Instance: demo mode"

        await pilot.press("i")
        await pilot.pause()

        assert isinstance(app.screen, InstanceManagementModal)
        assert modal_labels(app.screen, "#instance-management-list") == [
            "https://primary.daktela.com",
            "https://secondary.daktela.com",
        ]

        await pilot.press("j", "enter")
        await wait_until(
            lambda: (
                isinstance(app.connector, DaktelaTicketConnector)
                and app.connector.user_token == "token-2"
                and app.app_state.active_view is not None
                and app.app_state.active_view.title == "Secondary View"
            )
        )

        assert app.active_instance == second
        assert instance_context_text(app) == "Instance: https://secondary.daktela.com"
        assert app._demo_mode_active is False
        assert app._demo_mode_restore_state is None
        assert store.load().active_instance_id == second.id


@pytest.mark.asyncio
async def test_add_instance_blank_fields_stay_open_and_validate(
    tmp_path: Path,
) -> None:
    app = DaktelaPaleoApp(instance_store=make_instance_store(tmp_path))

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("i", "a", "ctrl+s")
        await pilot.pause()

        assert isinstance(app.screen, AddInstanceModal)
        assert app.screen.query_one("#add-instance-validation", Static).render() == (
            "Daktela URL can't be blank."
        )

        app.screen.query_one("#add-instance-base-url", Input).value = "demo.daktela.com/"
        await pilot.press("ctrl+s")
        await pilot.pause()

        assert app.screen.query_one("#add-instance-validation", Static).render() == (
            "User token can't be blank."
        )


@pytest.mark.asyncio
async def test_add_instance_bad_token_reopens_modal_without_saving(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    store = make_instance_store(tmp_path)
    app = DaktelaPaleoApp(instance_store=store)

    async def fake_get_whoiam(self: DaktelaTicketConnector) -> object:
        raise BadTokenDaktelaError()

    monkeypatch.setattr(DaktelaTicketConnector, "get_whoiam", fake_get_whoiam)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("i", "a")
        await pilot.pause()
        app.screen.query_one("#add-instance-base-url", Input).value = "demo-two.daktela.com/"
        app.screen.query_one("#add-instance-user-token", Input).value = "bad-token"

        await pilot.press("ctrl+s")
        await wait_until(lambda: isinstance(app.screen, AddInstanceModal))

        assert app.screen.query_one("#add-instance-validation", Static).render() == (
            "Daktela rejected the user token."
        )
        assert app.connector is None
        assert store.load() == DaktelaInstanceConfig()


@pytest.mark.asyncio
async def test_add_instance_success_persists_instance_and_loads_app(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    store = make_instance_store(tmp_path)
    app = DaktelaPaleoApp(instance_store=store)

    async def fake_get_whoiam(self: DaktelaTicketConnector) -> object:
        return object()

    async def fake_list_views(self: DaktelaTicketConnector) -> list[TicketView]:
        return [TicketView(name="support", title="Support")]

    async def fake_list_tickets(
        self: DaktelaTicketConnector,
        view: TicketView | None = None,
    ) -> list[Ticket]:
        return [make_ticket(title="Connected ticket", name=6001, contact="gold")]

    monkeypatch.setattr(DaktelaTicketConnector, "get_whoiam", fake_get_whoiam)
    monkeypatch.setattr(DaktelaTicketConnector, "list_views", fake_list_views)
    monkeypatch.setattr(DaktelaTicketConnector, "list_tickets", fake_list_tickets)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("i", "a")
        await pilot.pause()
        app.screen.query_one("#add-instance-base-url", Input).value = "demo-two.daktela.com/"
        app.screen.query_one("#add-instance-user-token", Input).value = "token-456"

        await pilot.press("ctrl+s")
        await wait_until(lambda: app.app_state.active_view is not None, timeout=5.0)

        saved_config = store.load()
        assert len(saved_config.instances) == 1
        assert saved_config.instances[0].base_url == "https://demo-two.daktela.com"
        assert saved_config.active_instance_id == saved_config.instances[0].id
        assert isinstance(app.connector, DaktelaTicketConnector)
        assert app.connector.pbx_name == "https://demo-two.daktela.com"
        assert app.connector.user_token == "token-456"
        assert app.active_instance == saved_config.instances[0]
        assert app.app_state.active_view is not None
        assert app.app_state.active_view.title == "Support"
        assert instance_context_text(app) == "Instance: https://demo-two.daktela.com"
        assert ticket_rows(app) == [
            ["1", "6001", "Connected ticket", "1", "category_123456", "-", "gold", "Open", "-", "-"]
        ]


@pytest.mark.asyncio
async def test_instance_manager_switches_to_another_saved_instance(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    first = make_saved_instance(id="primary", base_url="primary.daktela.com/", user_token="token-1")
    second = make_saved_instance(id="secondary", base_url="secondary.daktela.com/", user_token="token-2")
    store = make_instance_store(
        tmp_path,
        DaktelaInstanceConfig(
            active_instance_id=first.id,
            instances=[first, second],
        ),
    )

    async def fake_list_views(self: DaktelaTicketConnector) -> list[TicketView]:
        title = "Primary View" if self.user_token == "token-1" else "Secondary View"
        return [TicketView(name=title.lower().replace(" ", "_"), title=title)]

    async def fake_list_tickets(
        self: DaktelaTicketConnector,
        view: TicketView | None = None,
    ) -> list[Ticket]:
        ticket_name = 6101 if self.user_token == "token-1" else 6102
        ticket_title = "Primary ticket" if self.user_token == "token-1" else "Secondary ticket"
        return [make_ticket(title=ticket_title, name=ticket_name)]

    async def fake_get_current_user(self: DaktelaTicketConnector) -> TicketUserOption | None:
        return None

    async def fake_get_ticket_grid_column_keys(
        self: DaktelaTicketConnector,
    ) -> list[str] | None:
        return None

    monkeypatch.setattr(DaktelaTicketConnector, "list_views", fake_list_views)
    monkeypatch.setattr(DaktelaTicketConnector, "list_tickets", fake_list_tickets)
    monkeypatch.setattr(DaktelaTicketConnector, "get_current_user", fake_get_current_user)
    monkeypatch.setattr(
        DaktelaTicketConnector,
        "get_ticket_grid_column_keys",
        fake_get_ticket_grid_column_keys,
    )
    app = DaktelaPaleoApp(instance_store=store)

    async with app.run_test() as pilot:
        await wait_until(lambda: app.app_state.active_view is not None)

        assert app.app_state.active_view is not None
        assert app.app_state.active_view.title == "Primary View"
        assert instance_context_text(app) == "Instance: https://primary.daktela.com"

        await pilot.press("i", "j", "enter")
        await wait_until(lambda: app.active_instance is not None and app.active_instance.id == second.id)

        saved_config = store.load()
        assert saved_config.active_instance_id == second.id
        assert isinstance(app.connector, DaktelaTicketConnector)
        assert app.connector.user_token == "token-2"
        assert app.app_state.active_view is not None
        assert app.app_state.active_view.title == "Secondary View"
        assert instance_context_text(app) == "Instance: https://secondary.daktela.com"
        assert ticket_rows(app) == [
            ["1", "6102", "Secondary ticket", "1", "category_123456", "-", "-", "Open", "-", "-"]
        ]


@pytest.mark.asyncio
async def test_main_chrome_keeps_active_instance_context_while_transient_status_changes(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    saved_instance = make_saved_instance()
    store = make_instance_store(
        tmp_path,
        DaktelaInstanceConfig(
            active_instance_id=saved_instance.id,
            instances=[saved_instance],
        ),
    )

    async def exploding_list_views(self: DaktelaTicketConnector) -> list[TicketView]:
        raise RuntimeError("boom")

    monkeypatch.setattr(DaktelaTicketConnector, "list_views", exploding_list_views)
    app = DaktelaPaleoApp(instance_store=store)

    async with app.run_test():
        await wait_until(lambda: status_text(app) == "Error loading tickets: boom")

        assert instance_context_text(app) == "Instance: https://demo.daktela.com"


@pytest.mark.asyncio
async def test_ticket_detail_shows_same_active_instance_context_as_main_screen(
    tmp_path: Path,
) -> None:
    saved_instance = make_saved_instance()
    store = make_instance_store(
        tmp_path,
        DaktelaInstanceConfig(
            active_instance_id=saved_instance.id,
            instances=[saved_instance],
        ),
    )
    view = make_ticket_view("Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    app = DaktelaPaleoApp(
        initial_state=state,
        connector=MockTicketConnector.from_state(state),
        instance_store=store,
    )

    async with app.run_test() as pilot:
        await pilot.pause()
        assert instance_context_text(app) == "Instance: https://demo.daktela.com"

        await pilot.press("l", "l")
        await pilot.pause()

        assert isinstance(app.screen, TicketDetail)
        assert instance_context_text(app.screen) == "Instance: https://demo.daktela.com"


@pytest.mark.asyncio
async def test_detail_screen_instance_context_updates_immediately_after_instance_switch(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    first = make_saved_instance(id="primary", base_url="primary.daktela.com/", user_token="token-1")
    second = make_saved_instance(id="secondary", base_url="secondary.daktela.com/", user_token="token-2")
    store = make_instance_store(
        tmp_path,
        DaktelaInstanceConfig(
            active_instance_id=first.id,
            instances=[first, second],
        ),
    )
    view = make_ticket_view("Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )

    async def fake_list_views(self: DaktelaTicketConnector) -> list[TicketView]:
        return [TicketView(name="support", title="Support")]

    async def fake_list_tickets(
        self: DaktelaTicketConnector,
        view: TicketView | None = None,
    ) -> list[Ticket]:
        return [make_ticket(title="Switched ticket", name=9001)]

    async def fake_get_current_user(self: DaktelaTicketConnector) -> TicketUserOption | None:
        return None

    monkeypatch.setattr(DaktelaTicketConnector, "list_views", fake_list_views)
    monkeypatch.setattr(DaktelaTicketConnector, "list_tickets", fake_list_tickets)
    monkeypatch.setattr(DaktelaTicketConnector, "get_current_user", fake_get_current_user)
    app = DaktelaPaleoApp(
        initial_state=state,
        connector=MockTicketConnector.from_state(state),
        instance_store=store,
    )

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        assert instance_context_text(detail_screen) == "Instance: https://primary.daktela.com"

        app.activate_instance(second.id)
        await wait_until(
            lambda: instance_context_text(detail_screen) == "Instance: https://secondary.daktela.com"
        )

        assert app.active_instance == second


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("error", "expected_message"),
    [
        (app_module.CantConnectToDaktelaError(), "Couldn't connect to the Daktela instance."),
        (
            app_module.DaktelaConnectorError("Permission denied"),
            "Couldn't validate the Daktela instance: Permission denied",
        ),
        (
            RuntimeError("boom"),
            "Couldn't validate the Daktela instance: boom",
        ),
    ],
)
async def test_validate_and_activate_instance_reopens_modal_for_validation_errors(
    monkeypatch: pytest.MonkeyPatch,
    error: Exception,
    expected_message: str,
) -> None:
    app = DaktelaPaleoApp(connector=MockTicketConnector())
    pushed_screens: list[AddInstanceModal] = []

    async def fake_get_whoiam(self: DaktelaTicketConnector) -> object:
        raise error

    def fake_push_screen(
        screen: AddInstanceModal,
        callback: Callable[[object], None],
    ) -> None:
        pushed_screens.append(screen)

    monkeypatch.setattr(DaktelaTicketConnector, "get_whoiam", fake_get_whoiam)
    monkeypatch.setattr(app, "push_screen", fake_push_screen)

    await app._validate_and_activate_instance("demo-three.daktela.com/", "token-789")

    assert len(pushed_screens) == 1
    assert pushed_screens[0].error_message == expected_message
    assert pushed_screens[0].base_url == "demo-three.daktela.com/"
    assert pushed_screens[0].user_token == "token-789"


@pytest.mark.asyncio
async def test_app_view_selection_loads_tickets_from_connector() -> None:
    first_view = TicketView(view=1, name="all", title="All")
    second_view = TicketView(view=2, name="delivery", title="Delivery")
    connector = MockTicketConnector(
        views=[first_view, second_view],
        tickets=[make_ticket(title="Initial queue", name=5101)],
    )
    connector.set_tickets_for_view(
        second_view,
        [make_ticket(title="Delivery queue", name=5102, contact="dock", user="agent_2")],
    )
    app = DaktelaPaleoApp(connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("j", "enter")
        await pilot.pause()

        assert app.app_state.active_view is not None
        assert app.app_state.active_view.title == "Delivery"
        assert ticket_rows(app) == [
            ["1", "5102", "Delivery queue", "1", "category_123456", "-", "dock", "Open", "agent_2", "-"]
        ]
        assert connector.list_tickets_calls == [("view", "1"), ("view", "2")]


@pytest.mark.asyncio
async def test_app_shows_ticket_table_loader_while_switching_views() -> None:
    first_view = TicketView(view=1, name="all", title="All")
    second_view = TicketView(view=2, name="delivery", title="Delivery")
    connector = MockTicketConnector(
        views=[first_view, second_view],
        tickets=[make_ticket(title="Initial queue", name=5101)],
    )
    connector.set_tickets_for_view(
        second_view,
        [make_ticket(title="Delivery queue", name=5102, contact="dock", user="agent_2")],
        delay=0.5,
    )
    app = DaktelaPaleoApp(connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        ticket_table = app.query_one("#tickets-table", DataTable)
        await pilot.press("j", "enter")
        await wait_until(lambda: ticket_table.loading is True, timeout=5.0)

        assert connector.list_tickets_calls == [("view", "1"), ("view", "2")]
        assert ticket_table.loading is True
        assert ticket_table.row_count == 0

        await wait_until(lambda: ticket_table.loading is False)

        assert ticket_rows(app) == [
            ["1", "5102", "Delivery queue", "1", "category_123456", "-", "dock", "Open", "agent_2", "-"]
        ]


@pytest.mark.asyncio
async def test_app_enter_on_startup_loaded_view_focuses_tickets_without_reloading() -> None:
    view = TicketView(view=1, name="all", title="All")
    connector = MockTicketConnector(
        views=[view],
        tickets=[make_ticket(title="Initial queue", name=5101)],
    )
    app = DaktelaPaleoApp(connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        initial_rows = ticket_rows(app)

        await pilot.press("enter")
        await pilot.pause()

        assert connector.list_tickets_calls == [("view", "1")]
        assert ticket_rows(app) == initial_rows
        assert app.focused is app.query_one("#tickets-table", DataTable)


@pytest.mark.asyncio
async def test_app_reselecting_loaded_view_after_returning_to_views_does_not_reload() -> None:
    first_view = TicketView(view=1, name="all", title="All")
    second_view = TicketView(view=2, name="delivery", title="Delivery")
    connector = MockTicketConnector(
        views=[first_view, second_view],
        tickets=[make_ticket(title="All queue", name=5101)],
    )
    connector.set_tickets_for_view(
        second_view,
        [make_ticket(title="Delivery queue", name=5102, contact="dock", user="agent_2")],
    )
    app = DaktelaPaleoApp(connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("j", "enter")
        await pilot.pause()
        loaded_rows = ticket_rows(app)

        await pilot.press("h")
        await pilot.pause()
        await pilot.press("enter")
        await pilot.pause()

        assert connector.list_tickets_calls == [("view", "1"), ("view", "2")]
        assert ticket_rows(app) == loaded_rows
        assert app.focused is app.query_one("#tickets-table", DataTable)


@pytest.mark.asyncio
async def test_app_r_refreshes_current_view_from_connector() -> None:
    view = TicketView(view=1, name="all", title="All", ticket_count=1)
    refreshed_view = TicketView(view=1, name="all", title="All", ticket_count=2)
    connector = MockTicketConnector(
        views=[view],
        tickets=[make_ticket(title="Initial queue", name=5101)],
    )
    app = DaktelaPaleoApp(connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        connector.set_views([refreshed_view])
        connector.set_tickets_for_view(
            refreshed_view,
            [make_ticket(title="Refreshed queue", name=5102, contact="dock", user="agent_2")],
        )

        await pilot.press("r")
        await wait_until(lambda: app.loading_message is None)

        assert connector.list_views_calls == 2
        assert connector.list_tickets_calls == [("view", "1"), ("view", "1")]
        assert rendered_labels(app, "#views-list") == ["All (2)"]
        assert ticket_rows(app) == [
            ["1", "5102", "Refreshed queue", "1", "category_123456", "-", "dock", "Open", "agent_2", "-"]
        ]


@pytest.mark.asyncio
async def test_app_ctrl_d_and_ctrl_b_navigate_ticket_pages() -> None:
    view = TicketView(view=1, name="all", title="All")
    first_page_ticket = make_ticket(title="Page one", name=5101)
    second_page_ticket = make_ticket(title="Page two", name=5102)
    connector = MockTicketConnector(views=[view])
    connector.set_ticket_pages_for_view(
        view,
        [[first_page_ticket], [second_page_ticket]],
        total_tickets=2,
    )
    app = DaktelaPaleoApp(connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("enter")
        await pilot.pause()

        await pilot.press("ctrl+d")
        await wait_until(lambda: ticket_rows(app)[0][1] == "5102")

        assert app.focused is app.query_one("#tickets-table", DataTable)
        assert app.query_one("#tickets-title", Static).render() == "Tickets 2/2"

        await pilot.press("ctrl+b")
        await wait_until(lambda: ticket_rows(app)[0][1] == "5101")

        assert app.query_one("#tickets-title", Static).render() == "Tickets 1/2"
        assert connector.list_ticket_page_calls == [
            (("view", "1"), 1),
            (("view", "1"), 2),
            (("view", "1"), 1),
        ]


@pytest.mark.asyncio
async def test_app_r_refreshes_the_current_ticket_page() -> None:
    view = TicketView(view=1, name="all", title="All", ticket_count=2)
    connector = MockTicketConnector(views=[view])
    connector.set_ticket_pages_for_view(
        view,
        [[make_ticket(title="Page one", name=5101)], [make_ticket(title="Page two", name=5102)]],
        total_tickets=2,
    )
    app = DaktelaPaleoApp(connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("enter", "ctrl+d")
        await wait_until(lambda: ticket_rows(app)[0][1] == "5102")

        connector.set_views([view])
        connector.set_ticket_pages_for_view(
            view,
            [
                [make_ticket(title="Page one refreshed", name=5201)],
                [make_ticket(title="Page two refreshed", name=5202)],
            ],
            total_tickets=2,
        )

        await pilot.press("r")
        await wait_until(lambda: ticket_rows(app)[0][1] == "5202")

        assert app.query_one("#tickets-title", Static).render() == "Tickets 2/2"
        assert connector.list_ticket_page_calls[-1] == (("view", "1"), 2)


@pytest.mark.asyncio
async def test_app_switching_views_resets_ticket_page_to_first_page() -> None:
    first_view = TicketView(view=1, name="all", title="All")
    second_view = TicketView(view=2, name="delivery", title="Delivery")
    connector = MockTicketConnector(views=[first_view, second_view])
    connector.set_ticket_pages_for_view(
        first_view,
        [[make_ticket(title="All page one", name=5101)], [make_ticket(title="All page two", name=5102)]],
        total_tickets=2,
    )
    connector.set_ticket_pages_for_view(
        second_view,
        [
            [make_ticket(title="Delivery page one", name=5201)],
            [make_ticket(title="Delivery page two", name=5202)],
        ],
        total_tickets=2,
    )
    app = DaktelaPaleoApp(connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("enter", "ctrl+d", "h", "j", "enter")
        await wait_until(lambda: app.app_state.active_view == second_view)
        await wait_until(lambda: ticket_rows(app)[0][1] == "5201")

        assert app.query_one("#tickets-title", Static).render() == "Tickets 1/2"
        assert app.app_state.ticket_pagination == TicketPagination(
            current_page=1,
            total_pages=2,
            total_tickets=2,
        )


@pytest.mark.asyncio
async def test_app_r_refresh_clamps_to_last_available_ticket_page() -> None:
    view = TicketView(view=1, name="all", title="All", ticket_count=3)
    connector = MockTicketConnector(views=[view])
    connector.set_ticket_pages_for_view(
        view,
        [
            [make_ticket(title="Page one", name=5101)],
            [make_ticket(title="Page two", name=5102)],
            [make_ticket(title="Page three", name=5103)],
        ],
        total_tickets=3,
    )
    app = DaktelaPaleoApp(connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("enter", "ctrl+d", "ctrl+d")
        await wait_until(lambda: ticket_rows(app)[0][1] == "5103")

        connector.set_views([TicketView(view=1, name="all", title="All", ticket_count=2)])
        connector.set_ticket_pages_for_view(
            view,
            [
                [make_ticket(title="Page one refreshed", name=5201)],
                [make_ticket(title="Page two refreshed", name=5202)],
            ],
            total_tickets=2,
        )

        await pilot.press("r")
        await wait_until(lambda: ticket_rows(app)[0][1] == "5202")

        assert app.query_one("#tickets-title", Static).render() == "Tickets 2/2"
        assert app.app_state.ticket_pagination == TicketPagination(
            current_page=2,
            total_pages=2,
            total_tickets=2,
        )


@pytest.mark.asyncio
async def test_app_main_view_active_bindings_include_refresh_but_detail_does_not() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        await pilot.pause()

        refresh_binding = app.screen.active_bindings["r"].binding
        views_binding = app.screen.active_bindings["v"].binding
        instance_binding = app.screen.active_bindings["i"].binding

        assert refresh_binding.description == "Refresh"
        assert views_binding.description == "Views"
        assert instance_binding.description == "Instances"
        assert instance_binding.show is True
        assert "c" not in app.screen.active_bindings

        await pilot.press("l", "l")
        await pilot.pause()

        assert "r" not in app.screen.active_bindings
        assert "v" not in app.screen.active_bindings


@pytest.mark.asyncio
async def test_app_ticket_table_active_bindings_show_pagination_shortcuts_when_paginated() -> None:
    view = TicketView(view=1, name="all", title="All")
    connector = MockTicketConnector(views=[view])
    connector.set_ticket_pages_for_view(
        view,
        [[make_ticket(title="Page one", name=5101)], [make_ticket(title="Page two", name=5102)]],
        total_tickets=2,
    )
    app = DaktelaPaleoApp(connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("enter")
        await pilot.pause()

        next_page_binding = app.screen.active_bindings["ctrl+d"]
        previous_page_binding = app.screen.active_bindings["ctrl+b"]

        assert next_page_binding.binding.description == "Next Page"
        assert next_page_binding.enabled is True
        assert previous_page_binding.binding.description == "Previous Page"
        assert previous_page_binding.enabled is False

        await pilot.press("ctrl+d")
        await wait_until(lambda: ticket_rows(app)[0][1] == "5102")

        next_page_binding = app.screen.active_bindings["ctrl+d"]
        previous_page_binding = app.screen.active_bindings["ctrl+b"]

        assert next_page_binding.enabled is False
        assert previous_page_binding.enabled is True


@pytest.mark.asyncio
async def test_app_ticket_table_active_bindings_hide_pagination_shortcuts_without_extra_pages() -> None:
    view = TicketView(view=1, name="all", title="All")
    connector = MockTicketConnector(
        views=[view],
        tickets=[make_ticket(title="Single page", name=5101)],
    )
    app = DaktelaPaleoApp(connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("enter")
        await pilot.pause()

        assert "ctrl+d" not in app.screen.active_bindings
        assert "ctrl+b" not in app.screen.active_bindings


@pytest.mark.asyncio
async def test_app_detail_active_bindings_include_visible_save_shortcut() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await pilot.pause()

        save_binding = app.screen.active_bindings["ctrl+s"].binding

        assert save_binding.description == "Save"
        assert save_binding.show is True


@pytest.mark.asyncio
async def test_app_detail_active_bindings_include_visible_links_shortcut() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await pilot.pause()

        links_binding = app.screen.active_bindings["u"].binding

        assert links_binding.description == "Links"
        assert links_binding.show is True


@pytest.mark.asyncio
async def test_app_detail_active_bindings_show_only_tab_for_visible_pane_navigation() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await pilot.pause()

        next_pane_binding = app.screen.active_bindings["tab"].binding
        previous_pane_binding = app.screen.active_bindings["shift+tab"].binding

        assert next_pane_binding.description == "Next Pane"
        assert next_pane_binding.show is True
        assert previous_pane_binding.description == "Previous Pane"
        assert previous_pane_binding.show is False


@pytest.mark.asyncio
async def test_app_detail_active_bindings_show_inline_composer_shortcuts_when_editor_is_focused() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await pilot.pause()
        await pilot.press("n")
        await pilot.pause()

        external_editor_binding = app.screen.active_bindings["ctrl+e"].binding
        submit_binding = app.screen.active_bindings["ctrl+s"].binding
        cancel_binding = app.screen.active_bindings["escape"].binding
        next_pane_binding = app.screen.active_bindings["tab"].binding

        assert external_editor_binding.description == "External Editor"
        assert external_editor_binding.show is True
        assert submit_binding.description == "Submit"
        assert submit_binding.show is True
        assert cancel_binding.description == "Cancel"
        assert cancel_binding.show is True
        assert next_pane_binding.description == "Next Pane"
        assert next_pane_binding.show is True


@pytest.mark.asyncio
async def test_v_does_not_change_ticket_detail_focus_or_screen_state() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await pilot.pause()

        detail_screen = app.screen
        focused = app.focused

        await pilot.press("v")
        await pilot.pause()

        assert app.screen is detail_screen
        assert app.focused is focused


@pytest.mark.asyncio
async def test_app_retries_failed_same_view_load_on_reactivation() -> None:
    first_view = TicketView(view=1, name="all", title="All")
    second_view = TicketView(view=2, name="delivery", title="Delivery")
    connector = MockTicketConnector(
        views=[first_view, second_view],
        tickets=[make_ticket(title="All queue", name=5101)],
    )
    connector.set_tickets_for_view(
        second_view,
        [],
        error=RuntimeError("boom"),
    )
    app = DaktelaPaleoApp(connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("j", "enter")
        await wait_until(
            lambda: app.query_one("#status-bar", Static).render() == "Error loading tickets: boom"
        )

        await pilot.press("h")
        await pilot.pause()
        await pilot.press("enter")
        await wait_until(
            lambda: connector.list_tickets_calls == [("view", "1"), ("view", "2"), ("view", "2")]
        )

        assert ticket_rows(app) == []
        assert app.query_one("#status-bar", Static).render() == "Error loading tickets: boom"


@pytest.mark.daktela_integration
@pytest.mark.asyncio
async def test_app_view_selection_loads_tickets_from_live_daktela_connector() -> None:
    pbx_name = os.environ.get("DAKTELA_PBX_NAME")
    user_token = os.environ.get("DAKTELA_USER_TOKEN")
    if not pbx_name or not user_token:
        pytest.skip("Live Daktela app test requires DAKTELA_PBX_NAME and DAKTELA_USER_TOKEN.")

    app = DaktelaPaleoApp(
        connector=DaktelaTicketConnector(
            pbx_name,
            user_token,
        )
    )

    async with app.run_test() as pilot:
        await wait_until(lambda: len(rendered_labels(app, "#views-list")) > 0)
        first_view_title = rendered_labels(app, "#views-list")[0]
        await wait_until(lambda: len(ticket_rows(app)) > 0)
        await pilot.pause()

        assert app.app_state.active_view is not None
        assert app.app_state.active_view.title == first_view_title
        assert len(ticket_rows(app)) > 0
        assert app.query_one("#status-bar", Static).render() == f"Selected view: {first_view_title}"
        assert app.focused is app.query_one("#views-list", ListView)


@pytest.mark.asyncio
async def test_app_initial_load_error_is_reported_in_status_bar() -> None:
    app = DaktelaPaleoApp(
        connector=MockTicketConnector(views_error=RuntimeError("boom"))
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        assert app.query_one("#status-bar", Static).render() == "Error loading tickets: boom"
        assert rendered_labels(app, "#views-list") == []
        assert ticket_rows(app) == []


@pytest.mark.asyncio
async def test_app_ignores_stale_ticket_load_results() -> None:
    first_view = TicketView(view=1, name="slow", title="Slow")
    second_view = TicketView(view=2, name="fast", title="Fast")
    connector = MockTicketConnector(views=[first_view, second_view], tickets=[])
    connector.set_tickets_for_view(
        first_view,
        [make_ticket(title="Slow ticket", name=5201)],
        delay=0.05,
    )
    connector.set_tickets_for_view(
        second_view,
        [make_ticket(title="Fast ticket", name=5202)],
    )
    app = DaktelaPaleoApp(connector=connector)

    async with app.run_test() as pilot:
        await wait_until(lambda: len(rendered_labels(app, "#views-list")) == 2)

        await pilot.press("enter")
        await pilot.pause()
        await pilot.press("v", "j", "enter")
        await asyncio.sleep(0.1)
        await pilot.pause()

        assert app.app_state.active_view is not None
        assert app.app_state.active_view.title == "Fast"
        assert ticket_rows(app) == [["1", "5202", "Fast ticket", "1", "category_123456", "-", "-", "Open", "-", "-"]]


@pytest.mark.asyncio
async def test_app_reacts_to_state_replacement() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        app.set_app_state(
            AppState(
                tickets=[
                    make_ticket(
                        title="VIP queue",
                        name=3001,
                        contact="gold_customer",
                        user="operator_vip",
                    )
                ],
                views=[make_ticket_view(title="VIP only")],
                active_view=make_ticket_view(title="VIP only"),
                active_ticket=make_ticket(
                    title="VIP queue",
                    name=3001,
                    contact="gold_customer",
                    user="operator_vip",
                ),
            )
        )
        await pilot.pause()

        assert rendered_labels(app, "#views-list") == ["VIP only"]
        assert ticket_rows(app) == [
            ["1", "3001", "VIP queue", "1", "category_123456", "-", "gold_customer", "Open", "operator_vip", "-"]
        ]
        assert app.query_one("#views-list", ListView).index == 0
        assert app.query_one("#tickets-table", DataTable).cursor_row == 0


@pytest.mark.asyncio
async def test_app_reacts_to_ticket_updates() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        app.set_tickets(
            [
                make_ticket(
                    title="Contract review",
                    name=4001,
                    contact="legal_team",
                    user="operator_legal",
                ),
                make_ticket(
                    title="Delivery blocked",
                    name=4002,
                    contact="warehouse_7",
                    user="operator_dispatch",
                    stage=TicketStage.WAIT,
                    priority=TicketPriority.MEDIUM,
                ),
            ]
        )
        await pilot.pause()

        assert ticket_rows(app) == [
            ["1", "4001", "Contract review", "1", "category_123456", "-", "legal_team", "Open", "operator_legal", "-"],
            ["1", "4002", "Delivery blocked", "2", "category_123456", "-", "warehouse_7", "Waiting", "operator_dispatch", "-"],
        ]


@pytest.mark.asyncio
async def test_views_support_keyboard_navigation_and_enter_selection() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        await pilot.pause()
        views_list = app.query_one("#views-list", ListView)
        tickets_table = app.query_one("#tickets-table", TicketTable)

        assert views_list.index == 0

        await pilot.press("down")
        assert views_list.index == 1

        await pilot.press("k")
        assert views_list.index == 0

        await pilot.press("j")
        await pilot.press("enter")
        await pilot.pause()

        assert app.app_state.active_view is not None
        assert app.app_state.active_view.title == "Half-Life 2"
        assert app.query_one("#status-bar", Static).render() == "Selected view: Half-Life 2"
        assert app.focused is tickets_table


@pytest.mark.asyncio
async def test_v_focuses_views_and_l_selects_view() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        await pilot.pause()
        tickets_table = app.query_one("#tickets-table", TicketTable)
        await pilot.press("j", "l")
        await pilot.pause()
        assert app.focused is tickets_table

        await pilot.press("v")
        await pilot.pause()
        assert app.focused is app.query_one("#views-list", ListView)

        await pilot.press("l")
        await pilot.pause()
        assert app.app_state.active_view is not None
        assert app.app_state.active_view.title == "Half-Life 2"
        assert app.focused is tickets_table


@pytest.mark.asyncio
async def test_v_focuses_views_and_right_selects_view() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        await pilot.pause()
        tickets_table = app.query_one("#tickets-table", TicketTable)
        await pilot.press("j", "l")
        await pilot.pause()
        assert app.focused is tickets_table

        await pilot.press("v")
        await pilot.pause()
        assert app.focused is app.query_one("#views-list", ListView)

        await pilot.press("right")
        await pilot.pause()
        assert app.app_state.active_view is not None
        assert app.app_state.active_view.title == "Half-Life 2"
        assert app.focused is tickets_table


@pytest.mark.asyncio
async def test_h_and_left_focus_views_from_tickets() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        await pilot.pause()
        tickets_table = app.query_one("#tickets-table", TicketTable)
        views_list = app.query_one("#views-list", ListView)

        await pilot.press("j", "enter")
        await pilot.pause()
        assert app.focused is tickets_table

        await pilot.press("h")
        await pilot.pause()
        assert app.focused is views_list

        await pilot.press("j", "enter")
        await pilot.pause()
        assert app.focused is tickets_table

        await pilot.press("left")
        await pilot.pause()
        assert app.focused is views_list


@pytest.mark.asyncio
async def test_tickets_support_keyboard_navigation_and_selection_opens_detail_screen() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("j", "enter")
        await pilot.pause()

        tickets_table = app.query_one("#tickets-table", TicketTable)
        assert app.focused is tickets_table
        assert tickets_table.cursor_row == 0

        await pilot.press("down")
        assert tickets_table.cursor_row == 1

        await pilot.press("j")
        assert tickets_table.cursor_row == 2

        await pilot.press("l")
        await pilot.pause()

        assert app.app_state.active_ticket is not None
        assert app.app_state.active_ticket.title == "Checkpoint lockout at plaza"
        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#ticket-name-input", Input).value == "Checkpoint lockout at plaza"
        assert app.screen.query_one("#ticket-description-input", TextArea).text == ""
        assert right_title_label(cast(TicketDetail, app.screen)).render() == "Activities"
        assert app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render() == (
            "no activities yet"
        )
        assert app.screen.query_one("#status-bar", Static).render() == (
            "Selected ticket: Checkpoint lockout at plaza"
        )
        assert app.focused is app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)


@pytest.mark.asyncio
async def test_opening_ticket_detail_loads_ticket_activities_for_current_ticket() -> None:
    view = make_ticket_view("Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_activities(
        ticket,
        [
            make_activity(
                title="Fwd: test",
                body_html="<p>Hello<br />world</p>",
                direction="in",
            )
        ],
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        await wait_until(
            lambda: "Fwd: test"
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        assert right_title_label(cast(TicketDetail, app.screen)).render() == "Activities"
        rendered = str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        assert rendered == "Email ↓ | 2026-03-28 10:30 | Operator One\nFwd: test\nHello\nworld"


@pytest.mark.asyncio
async def test_u_from_ticket_detail_opens_link_picker_and_selected_link_in_browser(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    view = make_ticket_view("Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_activities(
        ticket,
        [
            make_activity(
                title="Docs",
                body_html='<p>Visit <a href="https://example.test/alpha">alpha</a></p>',
            ),
            make_activity(
                title="Runbook",
                body_html="<p>See https://example.test/beta</p>",
            ),
        ],
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)
    opened_urls: list[str] = []

    monkeypatch.setattr(
        app_module.webbrowser,
        "open",
        lambda url: opened_urls.append(url) or True,
    )

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        await wait_until(
            lambda: "Docs"
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        await pilot.press("u")
        await pilot.pause()

        assert isinstance(app.screen, ActivityLinkPickerModal)
        assert modal_link_urls(app.screen) == [
            "https://example.test/alpha",
            "https://example.test/beta",
        ]

        await pilot.press("down", "enter")
        await wait_until(lambda: opened_urls == ["https://example.test/beta"])
        await pilot.pause()

        assert isinstance(app.screen, TicketDetail)
        assert app.focused is app.screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        assert str(app.screen.query_one("#status-bar", Static).render()) == "Opened link in browser."


@pytest.mark.asyncio
async def test_u_from_ticket_detail_includes_resolved_activity_image_links(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    view = make_ticket_view("Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_activities(
        ticket,
        [
            make_activity(
                title="Internal note",
                type="",
                item_model=None,
                body_html='<p>Before</p><img src="/file/image.php?mapper=activities&name=5" alt="Scan" />',
            )
        ],
    )
    connector.set_activity_asset(
        "/file/image.php?mapper=activities&name=5",
        "https://demo.daktela.com/file/image.php?mapper=activities&name=5&accessToken=token-123",
        b"png-bytes",
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)
    opened_urls: list[str] = []

    monkeypatch.setattr(
        app_module.webbrowser,
        "open",
        lambda url: opened_urls.append(url) or True,
    )

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        await wait_until(
            lambda: "Internal note"
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        await pilot.press("u")
        await pilot.pause()

        assert isinstance(app.screen, ActivityLinkPickerModal)
        assert modal_link_urls(app.screen) == ["Image: Scan"]

        await pilot.press("enter")
        await wait_until(
            lambda: opened_urls
            == [
                "https://demo.daktela.com/file/image.php?mapper=activities&name=5&accessToken=token-123"
            ]
        )


@pytest.mark.asyncio
async def test_y_from_link_picker_copies_selected_link_to_clipboard() -> None:
    view = make_ticket_view("Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_activities(
        ticket,
        [
            make_activity(
                title="Docs",
                body_html='<p>Visit <a href="https://example.test/alpha">alpha</a></p>',
            ),
            make_activity(
                title="Runbook",
                body_html="<p>See https://example.test/beta</p>",
            ),
        ],
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        await wait_until(
            lambda: "Docs"
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        await pilot.press("u")
        await pilot.pause()

        assert isinstance(app.screen, ActivityLinkPickerModal)

        await pilot.press("down", "y")
        await pilot.pause()

        assert isinstance(app.screen, ActivityLinkPickerModal)
        assert app.clipboard == "https://example.test/beta"
        assert str(app.screen.query_one("#activity-link-picker-status", Static).render()) == (
            "Copied link to clipboard."
        )


@pytest.mark.asyncio
async def test_y_from_ticket_detail_copies_selected_activity_body_to_clipboard() -> None:
    view = make_ticket_view("Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_activities(
        ticket,
        [
            make_activity(
                title="Internal note",
                type="",
                item_model=None,
                body_html="<p>Hello<br />world</p>",
            )
        ],
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        await wait_until(
            lambda: "Internal note"
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        detail_screen = cast(TicketDetail, app.screen)
        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)

        await pilot.press("tab")
        await pilot.pause()

        selected_activity = right_body.selected_activity
        active_index = right_body.active_index

        await pilot.press("y")
        await pilot.pause()

        assert app.screen is detail_screen
        assert app.clipboard == "Hello\r\nworld"
        assert detail_screen.query_one("#status-bar", Static).render() == ACTIVITY_COPY_SUCCESS_STATUS
        assert app.focused is right_body
        assert right_body.selected_activity == selected_activity
        assert right_body.active_index == active_index


@pytest.mark.asyncio
async def test_d_from_ticket_detail_downloads_selected_activity_attachments(
    tmp_path: Path,
) -> None:
    view = make_ticket_view("Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    activity = make_activity(
        name="activities_1",
        title="Internal note",
        type="",
        item_model=None,
        body_html="<p>Hello</p>",
        attachments=[{"file": "6", "title": "April report.txt"}],
    )
    attachment = activity.downloadable_attachments()[0]
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_activities(ticket, [activity])
    connector.set_ticket_activity_attachment(activity, attachment, b"downloaded-bytes")
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        await wait_until(
            lambda: "Internal note"
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        detail_screen = cast(TicketDetail, app.screen)
        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        assert str(right_body.render()).startswith(
            "Comment | 2026-03-28 10:30 | Operator One |  1"
        )

        await pilot.press("tab")
        await pilot.pause()

        assert quick_action_labels(detail_screen) == ["Reply (r)", "Download (d)", "Copy (y)"]

        await pilot.press("d")
        await pilot.pause()

        assert isinstance(app.screen, AttachmentDestinationPickerModal)

        cast(
            AttachmentDestinationPickerModal,
            app.screen,
        ).query_one("#attachment-destination-picker-input", Input).value = str(tmp_path)
        await pilot.press("enter")
        await pilot.pause()
        await wait_until(lambda: (tmp_path / "April report.txt").exists())
        await pilot.pause()

        assert app.screen is detail_screen
        assert connector.load_ticket_activity_attachment_calls == [("activities_1", "6")]
        assert (tmp_path / "April report.txt").read_bytes() == b"downloaded-bytes"
        assert detail_screen.query_one("#status-bar", Static).render() == (
            f"Downloaded 1 attachment(s) to {tmp_path}."
        )
        assert app.focused is right_body


@pytest.mark.asyncio
async def test_y_from_ticket_detail_without_copyable_text_shows_notice_and_keeps_focus() -> None:
    view = make_ticket_view("Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_activities(
        ticket,
        [
            make_activity(
                title="Phone call",
                type="CALL",
                item_model=None,
                body_html=None,
            )
        ],
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        await wait_until(
            lambda: "Phone call"
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        detail_screen = cast(TicketDetail, app.screen)
        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        initial_clipboard = getattr(app, "clipboard", None)

        await pilot.press("tab")
        await pilot.pause()

        selected_activity = right_body.selected_activity
        active_index = right_body.active_index

        await pilot.press("y")
        await pilot.pause()

        assert app.screen is detail_screen
        assert getattr(app, "clipboard", None) == initial_clipboard
        assert detail_screen.query_one("#status-bar", Static).render() == ACTIVITY_COPY_EMPTY_STATUS
        assert app.focused is right_body
        assert right_body.selected_activity == selected_activity
        assert right_body.active_index == active_index


@pytest.mark.asyncio
async def test_download_ticket_activity_attachments_renames_existing_files(tmp_path: Path) -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    activity = make_activity(
        name="activities_1",
        title="Internal note",
        type="",
        item_model=None,
        attachments=[{"file": "6", "title": "April report.txt"}],
    )
    attachment = activity.downloadable_attachments()[0]
    connector = MockTicketConnector()
    connector.set_ticket_activity_attachment(activity, attachment, b"new-bytes")
    app = DaktelaPaleoApp(initial_state=AppState(), connector=connector)
    detail_screen = TicketDetail(ticket, f"Selected ticket: {ticket.title}")
    existing_file = tmp_path / "April report.txt"
    existing_file.write_bytes(b"old-bytes")
    app._ticket_attachment_download_generation = 1

    await app._download_ticket_activity_attachments(
        detail_screen,
        ticket,
        activity,
        tmp_path,
        generation=1,
    )

    assert existing_file.read_bytes() == b"old-bytes"
    assert (tmp_path / "April report (2).txt").read_bytes() == b"new-bytes"
    assert app.notice_message == f"Downloaded 1 attachment(s) to {tmp_path}."
    assert app.error_message is None


@pytest.mark.asyncio
async def test_download_ticket_activity_attachments_reports_missing_connector(
    tmp_path: Path,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    activity = make_activity(
        name="activities_1",
        title="Internal note",
        type="",
        item_model=None,
        attachments=[{"file": "6", "title": "April report.txt"}],
    )
    app = DaktelaPaleoApp(initial_state=AppState(), connector=MockTicketConnector())
    app.connector = None
    detail_screen = TicketDetail(ticket, f"Selected ticket: {ticket.title}")
    app._ticket_attachment_download_generation = 1

    await app._download_ticket_activity_attachments(
        detail_screen,
        ticket,
        activity,
        tmp_path,
        generation=1,
    )

    assert app.error_message == "No connector is active."
    assert app.notice_message is None


@pytest.mark.asyncio
async def test_download_ticket_activity_attachments_reports_missing_attachments(
    tmp_path: Path,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    activity = make_activity(
        name="activities_1",
        title="Internal note",
        type="",
        item_model=None,
        attachments=None,
    )
    app = DaktelaPaleoApp(initial_state=AppState(), connector=MockTicketConnector())
    detail_screen = TicketDetail(ticket, f"Selected ticket: {ticket.title}")
    app._ticket_attachment_download_generation = 1

    await app._download_ticket_activity_attachments(
        detail_screen,
        ticket,
        activity,
        tmp_path,
        generation=1,
    )

    assert app.error_message == "Selected activity has no downloadable attachments."
    assert app.notice_message is None


@pytest.mark.asyncio
async def test_download_ticket_activity_attachments_reports_partial_failure(
    tmp_path: Path,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    activity = make_activity(
        name="activities_1",
        title="Internal note",
        type="",
        item_model=None,
        attachments=[
            {"file": "6", "title": "April report.txt"},
            {"file": "7", "title": "invoice.pdf"},
        ],
    )
    connector = MockTicketConnector()
    connector.set_ticket_activity_attachment(
        activity,
        activity.downloadable_attachments()[0],
        b"report-bytes",
    )
    app = DaktelaPaleoApp(initial_state=AppState(), connector=connector)
    detail_screen = TicketDetail(ticket, f"Selected ticket: {ticket.title}")
    app._ticket_attachment_download_generation = 1

    await app._download_ticket_activity_attachments(
        detail_screen,
        ticket,
        activity,
        tmp_path,
        generation=1,
    )

    assert (tmp_path / "April report.txt").read_bytes() == b"report-bytes"
    assert connector.load_ticket_activity_attachment_calls == [
        ("activities_1", "6"),
        ("activities_1", "7"),
    ]
    assert app.notice_message is None
    assert app.error_message == (
        f"Downloaded 1 of 2 attachment(s) to {tmp_path}: "
        "invoice.pdf: Attachment '7' for activity 'activities_1' is not configured."
    )


@pytest.mark.asyncio
async def test_download_ticket_activity_attachments_reports_total_failure(
    tmp_path: Path,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    activity = make_activity(
        name="activities_1",
        title="Internal note",
        type="",
        item_model=None,
        attachments=[{"file": "7", "title": "invoice.pdf"}],
    )
    app = DaktelaPaleoApp(initial_state=AppState(), connector=MockTicketConnector())
    detail_screen = TicketDetail(ticket, f"Selected ticket: {ticket.title}")
    app._ticket_attachment_download_generation = 1

    await app._download_ticket_activity_attachments(
        detail_screen,
        ticket,
        activity,
        tmp_path,
        generation=1,
    )

    assert app.notice_message is None
    assert app.error_message == (
        "Error downloading attachments: "
        "invoice.pdf: Attachment '7' for activity 'activities_1' is not configured."
    )


@pytest.mark.asyncio
async def test_download_ticket_activity_attachments_propagates_cancellation(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    activity = make_activity(
        name="activities_1",
        title="Internal note",
        type="",
        item_model=None,
        attachments=[{"file": "6", "title": "April report.txt"}],
    )
    connector = MockTicketConnector()
    app = DaktelaPaleoApp(initial_state=AppState(), connector=connector)
    detail_screen = TicketDetail(ticket, f"Selected ticket: {ticket.title}")
    app._ticket_attachment_download_generation = 1

    async def raise_cancelled(
        _activity: TicketActivity,
        _attachment: TicketActivityAttachment,
    ) -> bytes:
        raise asyncio.CancelledError

    monkeypatch.setattr(connector, "load_ticket_activity_attachment", raise_cancelled)

    with pytest.raises(asyncio.CancelledError):
        await app._download_ticket_activity_attachments(
            detail_screen,
            ticket,
            activity,
            tmp_path,
            generation=1,
        )


@pytest.mark.asyncio
async def test_download_ticket_activity_attachments_reports_destination_error(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    activity = make_activity(
        name="activities_1",
        title="Internal note",
        type="",
        item_model=None,
        attachments=[{"file": "6", "title": "April report.txt"}],
    )
    connector = MockTicketConnector()
    app = DaktelaPaleoApp(initial_state=AppState(), connector=connector)
    detail_screen = TicketDetail(ticket, f"Selected ticket: {ticket.title}")
    app._ticket_attachment_download_generation = 1

    def raise_mkdir(self: Path, parents: bool = False, exist_ok: bool = False) -> None:
        del parents, exist_ok
        raise RuntimeError("mkdir boom")

    monkeypatch.setattr(Path, "mkdir", raise_mkdir)

    await app._download_ticket_activity_attachments(
        detail_screen,
        ticket,
        activity,
        tmp_path,
        generation=1,
    )

    assert app.notice_message is None
    assert app.error_message == "Error downloading attachments: mkdir boom"


@pytest.mark.asyncio
async def test_download_ticket_activity_attachments_ignores_destination_error_for_stale_generation(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    activity = make_activity(
        name="activities_1",
        title="Internal note",
        type="",
        item_model=None,
        attachments=[{"file": "6", "title": "April report.txt"}],
    )
    connector = MockTicketConnector()
    app = DaktelaPaleoApp(initial_state=AppState(), connector=connector)
    detail_screen = TicketDetail(ticket, f"Selected ticket: {ticket.title}")
    app._ticket_attachment_download_generation = 2

    def raise_mkdir(self: Path, parents: bool = False, exist_ok: bool = False) -> None:
        del parents, exist_ok
        raise RuntimeError("mkdir boom")

    monkeypatch.setattr(Path, "mkdir", raise_mkdir)

    await app._download_ticket_activity_attachments(
        detail_screen,
        ticket,
        activity,
        tmp_path,
        generation=1,
    )

    assert app.notice_message is None
    assert app.error_message is None


@pytest.mark.asyncio
async def test_download_ticket_activity_attachments_skips_status_updates_for_stale_generation(
    tmp_path: Path,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    activity = make_activity(
        name="activities_1",
        title="Internal note",
        type="",
        item_model=None,
        attachments=[{"file": "6", "title": "April report.txt"}],
    )
    attachment = activity.downloadable_attachments()[0]
    connector = MockTicketConnector()
    connector.set_ticket_activity_attachment(activity, attachment, b"downloaded-bytes")
    app = DaktelaPaleoApp(initial_state=AppState(), connector=connector)
    detail_screen = TicketDetail(ticket, f"Selected ticket: {ticket.title}")
    app._ticket_attachment_download_generation = 2

    await app._download_ticket_activity_attachments(
        detail_screen,
        ticket,
        activity,
        tmp_path,
        generation=1,
    )

    assert (tmp_path / "April report.txt").read_bytes() == b"downloaded-bytes"
    assert app.loading_message is None
    assert app.notice_message is None
    assert app.error_message is None


def test_attachment_download_default_path_returns_downloads_shortcut() -> None:
    app = DaktelaPaleoApp(initial_state=AppState(), connector=MockTicketConnector())

    assert app.attachment_download_default_path() == "~/Downloads"


def test_next_attachment_download_path_skips_multiple_existing_collisions(tmp_path: Path) -> None:
    (tmp_path / "April report.txt").write_text("1")
    (tmp_path / "April report (2).txt").write_text("2")

    assert DaktelaPaleoApp._next_attachment_download_path(tmp_path, "April report.txt") == (
        tmp_path / "April report (3).txt"
    )


@pytest.mark.asyncio
async def test_u_from_ticket_detail_shows_notice_when_no_activity_links_exist(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    view = make_ticket_view("Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_activities(
        ticket,
        [
            make_activity(
                title="Internal note",
                type="",
                item_model=None,
                body_html=None,
            )
        ],
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)
    opened_urls: list[str] = []

    monkeypatch.setattr(
        app_module.webbrowser,
        "open",
        lambda url: opened_urls.append(url) or True,
    )

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        await wait_until(
            lambda: "Internal note"
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        await pilot.press("u")
        await pilot.pause()

        assert isinstance(app.screen, TicketDetail)
        assert opened_urls == []
        assert str(app.screen.query_one("#status-bar", Static).render()) == (
            "No links found in ticket activities."
        )


@pytest.mark.asyncio
async def test_q_from_ticket_detail_returns_to_ticket_list_without_quitting() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("j", "enter")
        await pilot.pause()

        tickets_table = app.query_one("#tickets-table", TicketTable)
        await pilot.press("j", "j", "l")
        await pilot.pause()

        assert isinstance(app.screen, TicketDetail)
        assert app.is_running is True

        await pilot.press("q")
        await pilot.pause()
        await wait_until(lambda: app.focused is not None)

        assert not isinstance(app.screen, TicketDetail)
        assert app.is_running is True
        assert app.focused is app.query_one("#tickets-table", TicketTable)
        assert tickets_table.cursor_row == 2
        assert app.query_one("#status-bar", Static).render() == (
            "Selected ticket: Checkpoint lockout at plaza"
        )


@pytest.mark.asyncio
async def test_q_from_main_ticket_table_quits_application() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        await pilot.pause()
        app.query_one(TicketList).focus_tickets()
        await pilot.pause()

        assert isinstance(app.focused, DataTable)

        await pilot.press("q")
        await pilot.pause()

        assert app.is_running is False


@pytest.mark.asyncio
async def test_b_from_ticket_detail_opens_ticket_in_browser(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    view = make_ticket_view(title="Returns")
    ticket = make_ticket(title="Return pallet not scanned", name=1010)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    monkeypatch.setattr(
        connector,
        "ticket_browser_url",
        lambda opened_ticket: (
            f"https://demo.daktela.com/tickets/update/{opened_ticket.name}"
        ),
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)
    opened_urls: list[str] = []

    def fake_open(url: str) -> bool:
        opened_urls.append(url)
        return True

    monkeypatch.setattr(app_module.webbrowser, "open", fake_open)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await pilot.pause()

        assert isinstance(app.screen, TicketDetail)

        await pilot.press("b")
        await pilot.pause()

        assert opened_urls == ["https://demo.daktela.com/tickets/update/1010"]
        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#status-bar", Static).render() == (
            "Opened ticket in browser: Return pallet not scanned"
        )


@pytest.mark.asyncio
async def test_b_from_ticket_detail_shows_error_when_connector_has_no_browser_url(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)
    opened_urls: list[str] = []

    def fake_open(url: str) -> bool:
        opened_urls.append(url)
        return True

    monkeypatch.setattr(app_module.webbrowser, "open", fake_open)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await pilot.pause()

        assert isinstance(app.screen, TicketDetail)

        await pilot.press("b")
        await pilot.pause()

        assert opened_urls == []
        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#status-bar", Static).render() == (
            "Ticket browser URL is not available for this connector."
        )


@pytest.mark.asyncio
async def test_b_from_main_screen_views_opens_selected_view_in_browser(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    view = make_ticket_view(title="Returns", name="views_56cb1b3b23717310986148")
    ticket = make_ticket(title="Return pallet not scanned", name=1010)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    monkeypatch.setattr(
        connector,
        "view_browser_url",
        lambda opened_view: f"https://demo.daktela.com/tickets/#{opened_view.name}",
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)
    opened_urls: list[str] = []

    def fake_open(url: str) -> bool:
        opened_urls.append(url)
        return True

    monkeypatch.setattr(app_module.webbrowser, "open", fake_open)

    async with app.run_test() as pilot:
        await pilot.pause()

        assert app.focused is app.query_one("#views-list", ListView)

        await pilot.press("b")
        await pilot.pause()

        assert opened_urls == ["https://demo.daktela.com/tickets/#views_56cb1b3b23717310986148"]
        assert status_text(app) == "Opened view in browser: Returns"


@pytest.mark.asyncio
async def test_b_from_main_screen_tickets_opens_selected_view_in_browser(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    view = make_ticket_view(title="Returns", name="views_56cb1b3b23717310986148")
    ticket = make_ticket(title="Return pallet not scanned", name=1010)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    monkeypatch.setattr(
        connector,
        "view_browser_url",
        lambda opened_view: f"https://demo.daktela.com/tickets/#{opened_view.name}",
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)
    opened_urls: list[str] = []

    def fake_open(url: str) -> bool:
        opened_urls.append(url)
        return True

    monkeypatch.setattr(app_module.webbrowser, "open", fake_open)

    async with app.run_test() as pilot:
        await pilot.pause()

        app.query_one(TicketList).focus_tickets()
        await pilot.pause()

        assert isinstance(app.focused, DataTable)

        await pilot.press("b")
        await pilot.pause()

        assert opened_urls == ["https://demo.daktela.com/tickets/#views_56cb1b3b23717310986148"]
        assert isinstance(app.focused, DataTable)
        assert status_text(app) == "Opened view in browser: Returns"


@pytest.mark.asyncio
async def test_b_from_main_screen_tracks_changed_view_selection(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    first_view = make_ticket_view(title="Delivery", view=1, name="views_delivery")
    second_view = make_ticket_view(title="Returns", view=2, name="views_returns")
    first_ticket = make_ticket(title="Delivery blocked", name=2001)
    second_ticket = make_ticket(title="Return pallet not scanned", name=2002)
    state = AppState(
        tickets=[first_ticket],
        views=[first_view, second_view],
        active_view=first_view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_tickets_for_view(second_view, [second_ticket])
    monkeypatch.setattr(
        connector,
        "view_browser_url",
        lambda opened_view: f"https://demo.daktela.com/tickets/#{opened_view.name}",
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)
    opened_urls: list[str] = []

    def fake_open(url: str) -> bool:
        opened_urls.append(url)
        return True

    monkeypatch.setattr(app_module.webbrowser, "open", fake_open)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("j", "enter")
        await wait_until(lambda: app.app_state.active_view == second_view)
        await pilot.pause()

        assert app.focused is app.query_one("#tickets-table", DataTable)

        await pilot.press("b")
        await pilot.pause()

        assert opened_urls == ["https://demo.daktela.com/tickets/#views_returns"]
        assert status_text(app) == "Opened view in browser: Returns"


@pytest.mark.asyncio
async def test_b_from_main_screen_shows_error_when_connector_has_no_view_browser_url(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    view = make_ticket_view(title="Returns", name="views_56cb1b3b23717310986148")
    state = AppState(
        tickets=[],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)
    opened_urls: list[str] = []

    def fake_open(url: str) -> bool:
        opened_urls.append(url)
        return True

    monkeypatch.setattr(app_module.webbrowser, "open", fake_open)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("b")
        await pilot.pause()

        assert opened_urls == []
        assert status_text(app) == "View browser URL is not available for this connector."


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("shortcut", "initial_stage", "expected_stage"),
    [
        ("c", TicketStage.OPEN, TicketStage.CLOSE),
        ("o", TicketStage.WAIT, TicketStage.OPEN),
        ("w", TicketStage.OPEN, TicketStage.WAIT),
    ],
)
async def test_stage_shortcuts_update_stage_without_saving(
    shortcut: str,
    initial_stage: TicketStage,
    expected_stage: TicketStage,
) -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        stage=initial_stage,
        contact="vip_client",
        user="operator_1",
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await pilot.pause()

        await pilot.press(shortcut)
        await pilot.pause()

        assert connector.store_ticket_calls == []
        assert app.query_one("#tickets-table", DataTable).get_row_at(0)[7] == initial_stage.display_label
        assert app.app_state.active_ticket is not None
        assert app.app_state.active_ticket.stage is initial_stage
        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#ticket-stage-input", Select).value == expected_stage.value
        assert app.screen.query_one("#status-bar", Static).render() == "Selected ticket: Broken scanner"


@pytest.mark.asyncio
async def test_stage_shortcut_updates_stage_while_stage_overlay_is_focused() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        stage=TicketStage.OPEN,
        contact="vip_client",
        user="operator_1",
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l", "down", "enter")
        await pilot.pause()

        assert type(app.focused).__name__ == "TicketFormSelectOverlay"

        await pilot.press("w")
        await pilot.pause()

        assert connector.store_ticket_calls == []
        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#ticket-stage-input", Select).value == "WAIT"
        assert app.screen.query_one("#status-bar", Static).render() == "Selected ticket: Broken scanner"


@pytest.mark.asyncio
async def test_q_after_stage_shortcut_opens_unsaved_changes_modal() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        stage=TicketStage.OPEN,
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await pilot.pause()

        detail_screen = app.screen
        assert isinstance(detail_screen, TicketDetail)

        await pilot.press("w")
        await pilot.pause()

        assert detail_screen.query_one("#ticket-stage-input", Select).value == "WAIT"
        assert connector.store_ticket_calls == []

        await pilot.press("q")
        await pilot.pause()

        modal = app.screen
        assert isinstance(modal, UnsavedChangesModal)
        assert str(modal.query_one("#unsaved-changes-option-save", Static).render()) == (
            "[s] Save and close"
        )
        assert str(modal.query_one("#unsaved-changes-option-discard", Static).render()) == (
            "[c] Close without saving"
        )
        assert str(modal.query_one("#unsaved-changes-option-cancel", Static).render()) == (
            "Stay here Esc/q"
        )


@pytest.mark.asyncio
async def test_q_with_unsaved_ticket_changes_opens_confirmation_modal_without_quitting() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await pilot.pause()

        app.screen.query_one("#ticket-name-input", Input).value = "Unsaved scanner"
        await pilot.press("q")
        await pilot.pause()

        assert app.is_running is True
        assert isinstance(app.screen, UnsavedChangesModal)
        assert connector.store_ticket_calls == []


@pytest.mark.asyncio
async def test_escape_from_ticket_detail_returns_to_ticket_list() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("j", "enter")
        await pilot.pause()

        tickets_table = app.query_one("#tickets-table", TicketTable)
        await pilot.press("j", "l")
        await pilot.pause()

        assert isinstance(app.screen, TicketDetail)

        await pilot.press("escape")
        await pilot.pause()
        await wait_until(lambda: app.focused is not None)

        assert not isinstance(app.screen, TicketDetail)
        assert app.focused is app.query_one("#tickets-table", TicketTable)
        assert tickets_table.cursor_row == 1


@pytest.mark.asyncio
async def test_escape_with_unsaved_ticket_changes_opens_confirmation_modal() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await pilot.pause()

        detail_screen = app.screen
        detail_screen.query_one("#ticket-name-input", Input).value = "Unsaved scanner"
        await pilot.press("escape")
        await pilot.pause()

        assert isinstance(detail_screen, TicketDetail)
        assert isinstance(app.screen, UnsavedChangesModal)
        assert connector.store_ticket_calls == []


@pytest.mark.asyncio
async def test_ticket_detail_tab_and_shift_tab_switch_focus_between_panes() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("j", "enter")
        await pilot.pause()
        await pilot.press("l")
        await pilot.pause()

        left_body = app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        right_body = app.screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        left_title = app.screen.query_one("#ticket-detail-left-title", Static)
        right_title = app.screen.query_one("#ticket-detail-right-title")

        assert left_title.render() == "Ticket Detail"
        assert right_title_label(cast(TicketDetail, app.screen)).render() == "Activities"
        assert app.focused is left_body
        assert left_title.has_class("-focused") is True
        assert right_title.has_class("-focused") is False

        await pilot.press("tab")
        await pilot.pause()

        assert app.focused is right_body
        assert left_title.has_class("-focused") is False
        assert right_title.has_class("-focused") is True

        await pilot.press("shift+tab")
        await pilot.pause()

        assert app.focused is left_body


@pytest.mark.asyncio
async def test_ticket_detail_left_and_l_open_fields_without_switching_panes() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("j", "enter")
        await pilot.pause()
        await pilot.press("l")
        await pilot.pause()

        detail_screen = app.screen
        assert isinstance(detail_screen, TicketDetail)

        left_body = detail_screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        title_input = detail_screen.query_one("#ticket-name-input", Input)
        stage_select = detail_screen.query_one("#ticket-stage-input", Select)
        right_title = detail_screen.query_one("#ticket-detail-right-title")

        assert app.focused is left_body

        await pilot.press("left")
        await pilot.pause()

        assert app.focused is title_input
        assert right_title.has_class("-focused") is False

        await pilot.press("escape")
        await pilot.pause()

        await pilot.press("down", "l")
        await pilot.pause()

        assert app.focused is not right_body
        assert stage_select.expanded is True
        assert right_title.has_class("-focused") is False


@pytest.mark.asyncio
async def test_ticket_detail_email_quick_actions_open_inline_composer_from_keyboard_and_click() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    activity = make_activity(
        title="Fwd: test",
        body_html="<p>Hello<br />world</p>",
        direction="in",
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_activities(ticket, [activity])
    connector.set_ticket_email_draft(
        ticket,
        activity,
        TicketEmailAction.REPLY,
        TicketEmailDraft(
            action=TicketEmailAction.REPLY,
            source_activity_name=activity.name,
            source_email_name="emails_1",
            to="customer@example.com",
            subject="Re: test",
            body="Thanks for the update.",
            queue_name="support",
        ),
    )
    connector.set_ticket_email_draft(
        ticket,
        activity,
        TicketEmailAction.FORWARD,
        TicketEmailDraft(
            action=TicketEmailAction.FORWARD,
            source_activity_name=activity.name,
            source_email_name="emails_1",
            to="",
            subject="Fwd: test",
            body="Can you review?",
            queue_name="support",
        ),
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        await wait_until(
            lambda: "Fwd: test"
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        detail_screen = cast(TicketDetail, app.screen)
        assert quick_action_labels(detail_screen) == []

        await pilot.press("tab")
        await pilot.pause()

        assert quick_action_labels(detail_screen) == [
            "Reply to all (r)",
            "Forward (f)",
            "Copy (y)",
        ]

        await pilot.press("r")
        await wait_until(lambda: len(connector.get_ticket_email_draft_calls) == 1)
        await wait_until(lambda: detail_screen.query_one("#email-reply-composer", TicketEmailComposer).is_open)

        composer = detail_screen.query_one("#email-reply-composer", TicketEmailComposer)
        assert composer.query_one("#email-reply-to", Input).value == "customer@example.com"
        assert composer.query_one("#email-reply-subject", Input).value == "Re: test"
        assert composer.query_one("#email-reply-body", TextArea).text == "Thanks for the update."
        assert app.focused is composer.query_one("#email-reply-body", TextArea)
        assert detail_screen.query_one("#status-bar", Static).render() == (
            "Selected ticket: Broken scanner"
        )

        await pilot.press("escape")
        await pilot.pause()

        await pilot.click("#ticket-detail-quick-action-forward")
        await wait_until(lambda: len(connector.get_ticket_email_draft_calls) == 2)
        await wait_until(lambda: detail_screen.query_one("#email-reply-composer", TicketEmailComposer).is_open)

        composer = detail_screen.query_one("#email-reply-composer", TicketEmailComposer)
        assert composer.query_one("#email-reply-to", Input).value == ""
        assert composer.query_one("#email-reply-subject", Input).value == "Fwd: test"
        assert composer.query_one("#email-reply-body", TextArea).text == "Can you review?"
        assert app.focused is composer.query_one("#email-reply-to", Input)


@pytest.mark.asyncio
async def test_ticket_detail_c_sets_stage_close_without_creating_comment() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001, stage=TicketStage.OPEN)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        await wait_until(
            lambda: isinstance(app.screen, TicketDetail)
            and cast(TicketDetail, app.screen).query_one(
                "#ticket-detail-right-body",
                DetailPaneBody,
            ).render()
            == "no activities yet"
        )

        detail_screen = cast(TicketDetail, app.screen)

        assert detail_screen.query_one("#ticket-stage-input", Select).value == "OPEN"

        await pilot.press("c")
        await pilot.pause()

        assert app.screen is detail_screen
        assert connector.create_ticket_comment_calls == []
        assert connector.list_ticket_activities_calls == [("name", "2001")]
        assert detail_screen.query_one("#ticket-stage-input", Select).value == "CLOSE"
        assert detail_screen.query_one("#status-bar", Static).render() == (
            "Selected ticket: Broken scanner"
        )


@pytest.mark.asyncio
async def test_ticket_detail_n_opens_inline_comment_without_pushing_modal() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_activities(
        ticket,
        [
            make_activity(
                title="Internal note",
                type="",
                body_html="<p>Plain text</p>",
                item_model=None,
            )
        ],
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        await wait_until(
            lambda: "Internal note"
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        detail_screen = cast(TicketDetail, app.screen)

        await pilot.press("n")
        await pilot.pause()

        composer = detail_screen.query_one("#comment-reply-composer", CommentReplyComposer)

        assert app.screen is detail_screen
        assert connector.create_ticket_comment_calls == []
        assert composer.has_class("-open")
        assert composer.mode == "new_comment"
        assert detail_screen.query_one("#comment-reply-title", Static).render() == "Add comment"
        with pytest.raises(NoMatches):
            detail_screen.query_one("#comment-reply-target", Static)
        with pytest.raises(NoMatches):
            detail_screen.query_one("#comment-reply-target-preview", Static)
        assert "Internal note" in str(
            detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody).render()
        )


@pytest.mark.asyncio
async def test_ticket_detail_n_cancel_keeps_detail_state_and_skips_connector() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_activities(
        ticket,
        [
            make_activity(
                title="Internal note",
                type="",
                body_html="<p>Plain text</p>",
                item_model=None,
            )
        ],
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        await wait_until(
            lambda: "Internal note"
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        detail_screen = cast(TicketDetail, app.screen)

        await pilot.press("n")
        await pilot.pause()

        detail_screen.query_one("#comment-reply-input", TextArea).load_text("Draft comment")

        await pilot.press("escape")
        await pilot.pause()

        assert app.screen is detail_screen
        assert connector.create_ticket_comment_calls == []
        assert connector.list_ticket_activities_calls == [("name", "2001")]
        assert detail_screen.query_one("#comment-reply-composer").has_class("-open") is False
        assert detail_screen.query_one("#status-bar", Static).render() == (
            "Selected ticket: Broken scanner"
        )


@pytest.mark.asyncio
async def test_ticket_detail_n_submit_creates_comment_and_refreshes_activities() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_activities(
        ticket,
        [
            make_activity(
                title="Internal note",
                type="",
                body_html="<p>Plain text</p>",
                item_model=None,
            )
        ],
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        await wait_until(
            lambda: "Internal note"
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        detail_screen = cast(TicketDetail, app.screen)

        await pilot.press("n")
        await pilot.pause()

        detail_screen.query_one("#comment-reply-input", TextArea).load_text("Followed up with finance.")

        await pilot.press("ctrl+s")
        await wait_until(lambda: len(connector.create_ticket_comment_calls) == 1)
        await wait_until(lambda: len(connector.list_ticket_activities_calls) == 2)
        await wait_until(
            lambda: "Followed up with finance."
            in str(detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        assert app.screen is detail_screen
        assert connector.create_ticket_comment_calls == [
            (ticket, TicketCommentCreateRequest(body="Followed up with finance."))
        ]
        assert detail_screen.query_one("#status-bar", Static).render() == (
            "Added comment: Broken scanner"
        )
        assert detail_screen.query_one("#comment-reply-composer").has_class("-open") is False
        assert detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody).render().startswith(
            "Comment | "
        )


@pytest.mark.asyncio
async def test_ticket_detail_n_failure_reports_error_without_refresh() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_activities(
        ticket,
        [
            make_activity(
                title="Internal note",
                type="",
                body_html="<p>Plain text</p>",
                item_model=None,
            )
        ],
    )
    connector.set_comment_create_behavior(error=RuntimeError("boom"))
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        await wait_until(
            lambda: "Internal note"
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        detail_screen = cast(TicketDetail, app.screen)

        await pilot.press("n")
        await pilot.pause()

        detail_screen.query_one("#comment-reply-input", TextArea).load_text("Will fail")

        await pilot.press("ctrl+s")
        await wait_until(lambda: len(connector.create_ticket_comment_calls) == 1)
        await wait_until(lambda: app.loading_message is None)

        assert app.screen is detail_screen
        assert connector.create_ticket_comment_calls == [
            (ticket, TicketCommentCreateRequest(body="Will fail"))
        ]
        assert connector.list_ticket_activities_calls == [("name", "2001")]
        assert detail_screen.query_one("#status-bar", Static).render() == (
            "Error adding comment: boom"
        )
        assert detail_screen.query_one("#comment-reply-validation", Static).display is True
        assert detail_screen.query_one("#comment-reply-validation", Static).render() == (
            "Error adding comment: boom"
        )
        assert detail_screen.query_one("#comment-reply-composer").has_class("-open")
        assert detail_screen.query_one("#comment-reply-composer", CommentReplyComposer).mode == "new_comment"
        assert detail_screen.query_one("#comment-reply-input", TextArea).text == "Will fail"
        assert (
            "Internal note"
            in str(detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )


@pytest.mark.asyncio
async def test_ticket_detail_n_submit_with_attachment_creates_comment_and_refreshes_activities(
    tmp_path: Path,
) -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_activities(
        ticket,
        [
            make_activity(
                title="Internal note",
                type="",
                body_html="<p>Plain text</p>",
                item_model=None,
            )
        ],
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)
    attachment_path = (tmp_path / "report.txt").resolve()
    attachment_path.write_text("alpha", encoding="utf-8")

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        detail_screen = cast(TicketDetail, app.screen)

        await pilot.press("n")
        await pilot.pause()

        composer = detail_screen.query_one("#comment-reply-composer", CommentReplyComposer)
        assert composer.stage_attachment(attachment_path) is True
        detail_screen.query_one("#comment-reply-input", TextArea).load_text("Followed up with finance.")

        await pilot.press("ctrl+s")
        await wait_until(lambda: len(connector.create_ticket_comment_calls) == 1)
        await wait_until(lambda: len(connector.list_ticket_activities_calls) == 2)

        request = connector.create_ticket_comment_calls[0][1]
        assert request.body == "Followed up with finance."
        assert len(request.attachments) == 1
        assert request.attachments[0].filename == "report.txt"
        assert request.attachments[0].content == b"alpha"
        assert app.screen is detail_screen
        assert quick_action_labels(detail_screen) == ["Reply (r)", "Download (d)", "Copy (y)"]


@pytest.mark.asyncio
async def test_ticket_detail_n_attachment_read_failure_preserves_draft_and_staged_files(
    tmp_path: Path,
) -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_activities(
        ticket,
        [
            make_activity(
                title="Internal note",
                type="",
                body_html="<p>Plain text</p>",
                item_model=None,
            )
        ],
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)
    attachment_path = (tmp_path / "report.txt").resolve()
    attachment_path.write_text("alpha", encoding="utf-8")

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        detail_screen = cast(TicketDetail, app.screen)

        await pilot.press("n")
        await pilot.pause()

        composer = detail_screen.query_one("#comment-reply-composer", CommentReplyComposer)
        assert composer.stage_attachment(attachment_path) is True
        detail_screen.query_one("#comment-reply-input", TextArea).load_text("Followed up with finance.")
        attachment_path.unlink()

        await pilot.press("ctrl+s")
        await wait_until(lambda: app.loading_message is None)

        assert connector.create_ticket_comment_calls == []
        assert composer.has_class("-open")
        assert composer.staged_attachment_paths == (attachment_path,)
        assert detail_screen.query_one("#comment-reply-input", TextArea).text == "Followed up with finance."
        assert str(detail_screen.query_one("#comment-reply-validation", Static).render()).startswith(
            "Error adding comment: Unable to read attachment 'report.txt':"
        )


@pytest.mark.asyncio
async def test_ticket_detail_comment_quick_action_cancel_keeps_detail_state_and_skips_connector() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_activities(
        ticket,
        [
            make_activity(
                title="Internal note",
                type="",
                body_html="<p>Plain text</p>",
                item_model=None,
            )
        ],
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        await wait_until(
            lambda: "Internal note"
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        detail_screen = cast(TicketDetail, app.screen)

        await pilot.press("tab")
        await pilot.pause()

        assert quick_action_labels(detail_screen) == ["Reply (r)", "Copy (y)"]

        await pilot.press("f")
        await pilot.pause()

        assert detail_screen.query_one("#status-bar", Static).render() == (
            "Selected ticket: Broken scanner"
        )

        await pilot.press("r")
        await pilot.pause()

        composer = detail_screen.query_one("#comment-reply-composer", CommentReplyComposer)
        assert detail_screen.query_one("#comment-reply-title", Static).render() == "Add comment reply"
        with pytest.raises(NoMatches):
            detail_screen.query_one("#comment-reply-target", Static)
        with pytest.raises(NoMatches):
            detail_screen.query_one("#comment-reply-target-preview", Static)
        assert composer.has_class("-open")

        await pilot.press("escape")
        await pilot.pause()

        assert app.screen is detail_screen
        assert connector.create_ticket_comment_calls == []
        assert connector.list_ticket_activities_calls == [("name", "2001")]
        assert detail_screen.query_one("#status-bar", Static).render() == REPLY_USER_UNMATCHED_STATUS


@pytest.mark.asyncio
async def test_ticket_detail_comment_quick_action_submit_creates_comment_and_refreshes_activities() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_activities(
        ticket,
        [
            make_activity(
                title="Internal note",
                type="",
                body_html="<p>Plain text</p>",
                item_model=None,
            )
        ],
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        await wait_until(
            lambda: "Internal note"
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        detail_screen = cast(TicketDetail, app.screen)

        await pilot.press("tab", "r")
        await pilot.pause()

        detail_screen.query_one("#comment-reply-input", TextArea).load_text("Followed up with finance.")

        await pilot.press("ctrl+s")
        await wait_until(lambda: len(connector.create_ticket_comment_calls) == 1)
        await wait_until(lambda: len(connector.list_ticket_activities_calls) == 2)
        await wait_until(
            lambda: "Followed up with finance."
            in str(detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        assert app.screen is detail_screen
        assert connector.create_ticket_comment_calls == [
            (ticket, TicketCommentCreateRequest(body="Followed up with finance."))
        ]
        assert detail_screen.query_one("#status-bar", Static).render() == (
            "Added comment: Broken scanner"
        )
        assert detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody).render().startswith(
            "Comment | "
        )


@pytest.mark.asyncio
async def test_ticket_detail_comment_quick_action_assigns_activity_user_and_save_persists_patch() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        user="Operator One",
        user_name="operator_1",
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_users(
        [
            TicketUserOption(name="operator_1", title="Operator One"),
            TicketUserOption(name="operator_2", title="Operator Two"),
        ]
    )
    connector.set_ticket_activities(
        ticket,
        [
            make_activity(
                title="Internal note",
                type="",
                body_html="<p>Plain text</p>",
                item_model=None,
                user="Operator Two",
                user_name="operator_2",
            )
        ],
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_users_calls == 1)
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        await wait_until(
            lambda: "Internal note"
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        detail_screen = cast(TicketDetail, app.screen)

        await pilot.press("tab", "r")
        await pilot.pause()

        composer = detail_screen.query_one("#comment-reply-composer", CommentReplyComposer)

        assert composer.has_class("-open")
        assert detail_screen.query_one("#ticket-user-input", Select).value == "operator_2"
        assert detail_screen.query_one("#status-bar", Static).render() == (
            "Selected ticket: Broken scanner"
        )

        await pilot.press("escape")
        await pilot.pause()

        assert composer.has_class("-open") is False

        await pilot.press("ctrl+s")
        await wait_until(lambda: app.loading_message is None)

        assert connector.create_ticket_comment_calls == []
        assert connector.store_ticket_calls == [
            (
                ticket,
                TicketEditPatch(
                    user_name="operator_2",
                    user_title="Operator Two",
                ),
            )
        ]
        assert app.app_state.active_ticket is not None
        assert app.app_state.active_ticket.user == "Operator Two"
        assert app.app_state.active_ticket.user_name == "operator_2"
        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#ticket-user-input", Select).value == "operator_2"
        assert app.screen.query_one("#status-bar", Static).render() == "Saved ticket: Broken scanner"


@pytest.mark.asyncio
async def test_ticket_detail_comment_quick_action_unmatched_activity_user_keeps_existing_assignee() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        user="Operator One",
        user_name="operator_1",
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_users(
        [
            TicketUserOption(name="operator_1", title="Operator One"),
            TicketUserOption(name="operator_2", title="Operator Two"),
        ]
    )
    connector.set_ticket_activities(
        ticket,
        [
            make_activity(
                title="Internal note",
                type="",
                body_html="<p>Plain text</p>",
                item_model=None,
                user="Operator Three",
                user_name="operator_3",
            )
        ],
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_users_calls == 1)
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        await wait_until(
            lambda: "Internal note"
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        detail_screen = cast(TicketDetail, app.screen)
        form = detail_screen.query_one("#ticket-detail-left-body", TicketDetailForm)

        await pilot.press("tab", "r")
        await pilot.pause()

        assert detail_screen.query_one("#comment-reply-composer", CommentReplyComposer).has_class("-open")
        assert detail_screen.query_one("#ticket-user-input", Select).value == "operator_1"
        assert form.has_unsaved_changes() is False
        assert detail_screen.query_one("#status-bar", Static).render() == (
            "Reply user not assigned: no matching ticket assignee for this activity."
        )


@pytest.mark.asyncio
async def test_ticket_detail_comment_quick_action_failure_reports_error_without_refresh() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_activities(
        ticket,
        [
            make_activity(
                title="Internal note",
                type="",
                body_html="<p>Plain text</p>",
                item_model=None,
            )
        ],
    )
    connector.set_comment_create_behavior(error=RuntimeError("boom"))
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        await wait_until(
            lambda: "Internal note"
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        detail_screen = cast(TicketDetail, app.screen)

        await pilot.press("tab", "r")
        await pilot.pause()

        detail_screen.query_one("#comment-reply-input", TextArea).load_text("Will fail")

        await pilot.press("ctrl+s")
        await wait_until(lambda: len(connector.create_ticket_comment_calls) == 1)
        await wait_until(lambda: app.loading_message is None)

        assert app.screen is detail_screen
        assert connector.create_ticket_comment_calls == [
            (ticket, TicketCommentCreateRequest(body="Will fail"))
        ]
        assert connector.list_ticket_activities_calls == [("name", "2001")]
        assert detail_screen.query_one("#status-bar", Static).render() == (
            "Error adding comment: boom"
        )
        assert detail_screen.query_one("#comment-reply-validation", Static).display is True
        assert detail_screen.query_one("#comment-reply-validation", Static).render() == (
            "Error adding comment: boom"
        )
        assert detail_screen.query_one("#comment-reply-composer").has_class("-open")
        assert detail_screen.query_one("#comment-reply-input", TextArea).text == "Will fail"
        assert (
            "Internal note"
            in str(detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )


@pytest.mark.asyncio
async def test_ctrl_s_saves_ticket_and_refreshes_detail_and_table() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        description="Old description",
        contact="vip_client",
        user="operator_1",
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("l", "l")
        await pilot.pause()

        name_input = app.screen.query_one("#ticket-name-input", Input)
        description = app.screen.query_one("#ticket-description-input", TextArea)

        await pilot.press("enter")
        await pilot.pause()
        name_input.value = "Saved scanner"
        await pilot.press("escape")
        await pilot.pause()

        await pilot.press("down", "down", "down", "down", "enter")
        await pilot.pause()
        description.load_text("Saved description")
        await pilot.press("escape")
        await pilot.pause()

        await pilot.press("ctrl+s")
        await wait_until(lambda: app.loading_message is None)

        assert connector.store_ticket_calls == [
            (
                ticket,
                TicketEditPatch(title="Saved scanner", description="Saved description"),
            )
        ]
        assert app.query_one("#tickets-table", DataTable).get_row_at(0)[2] == "Saved scanner"
        assert app.app_state.active_ticket is not None
        assert app.app_state.active_ticket.title == "Saved scanner"
        assert app.app_state.active_ticket.description == "Saved description"
        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#ticket-name-input", Input).value == "Saved scanner"
        assert app.screen.query_one("#ticket-description-input", TextArea).text == (
            "Saved description"
        )
        assert app.screen.query_one("#status-bar", Static).render() == "Saved ticket: Saved scanner"


@pytest.mark.asyncio
async def test_ctrl_s_saves_ticket_and_refreshes_view_counts() -> None:
    view = TicketView(view=7, title="Escalated only", ticket_count=1)
    refreshed_view = TicketView(view=7, title="Escalated only", ticket_count=2)
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        description="Old description",
        contact="vip_client",
        user="operator_1",
    )
    extra_ticket = make_ticket(
        title="Second scanner",
        name=2002,
        description="Another description",
        contact="vip_client",
        user="operator_1",
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_views([refreshed_view])
    connector.set_tickets_for_view(refreshed_view, [ticket, extra_ticket])
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("l", "l", "enter")
        await pilot.pause()

        name_input = app.screen.query_one("#ticket-name-input", Input)
        name_input.value = "Saved scanner"
        await pilot.press("escape")
        await pilot.pause()

        await pilot.press("ctrl+s")
        await wait_until(lambda: app.loading_message is None)

        assert connector.list_views_calls == 1
        assert rendered_labels(app, "#views-list") == ["Escalated only (2)"]
        assert app.app_state.active_view is not None
        assert app.app_state.active_view.ticket_count == 2
        assert app.query_one("#tickets-table", DataTable).row_count == 2


@pytest.mark.asyncio
async def test_ctrl_s_saves_reopen_datetime_and_refreshes_detail_and_table() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        reopen=datetime(2026, 3, 30, 8, 0, 0),
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("l", "l")
        await pilot.pause()

        reopen_input = app.screen.query_one("#ticket-reopen-input", Input)

        await pilot.press("down", "down", "down", "down", "down", "down", "enter")
        await pilot.pause()
        reopen_input.value = "2026-03-31 09:15:00"
        await pilot.press("escape")
        await pilot.pause()

        await pilot.press("ctrl+s")
        await wait_until(lambda: app.loading_message is None)

        assert connector.store_ticket_calls == [
            (
                ticket,
                TicketEditPatch(reopen=datetime(2026, 3, 31, 9, 15, 0)),
            )
        ]
        assert app.app_state.active_ticket is not None
        assert app.app_state.active_ticket.reopen == datetime(2026, 3, 31, 9, 15, 0)
        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#ticket-reopen-input", Input).value == "2026-03-31 09:15:00"
        assert app.screen.query_one("#status-bar", Static).render() == "Saved ticket: Broken scanner"


@pytest.mark.asyncio
async def test_ctrl_s_saves_ticket_while_title_input_is_focused() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        description="Old description",
        contact="vip_client",
        user="operator_1",
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("l", "l", "enter")
        await pilot.pause()

        name_input = app.screen.query_one("#ticket-name-input", Input)
        name_input.value = "Saved scanner"

        assert app.focused is name_input

        await pilot.press("ctrl+s")
        await wait_until(lambda: app.loading_message is None)

        assert connector.store_ticket_calls == [
            (
                ticket,
                TicketEditPatch(title="Saved scanner"),
            )
        ]
        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#ticket-name-input", Input).value == "Saved scanner"
        assert app.screen.query_one("#status-bar", Static).render() == "Saved ticket: Saved scanner"


@pytest.mark.asyncio
async def test_ctrl_s_refreshes_current_view_and_clears_active_ticket_when_saved_ticket_leaves_view() -> None:
    view = TicketView(view=7, title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        description="Old description",
        contact="vip_client",
        user="operator_1",
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_tickets_for_view(view, [])
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("l", "l")
        await pilot.pause()

        name_input = app.screen.query_one("#ticket-name-input", Input)
        await pilot.press("enter")
        await pilot.pause()
        name_input.value = "Saved scanner"
        await pilot.press("escape")
        await pilot.pause()

        await pilot.press("ctrl+s")
        await wait_until(lambda: app.loading_message is None)

        assert connector.store_ticket_calls == [
            (
                ticket,
                TicketEditPatch(title="Saved scanner"),
            )
        ]
        assert connector.list_tickets_calls == [("view", "7")]
        assert ticket_rows(app) == []
        assert app.app_state.active_ticket is None
        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#ticket-name-input", Input).value == "Saved scanner"
        assert app.screen.query_one("#status-bar", Static).render() == "Saved ticket: Saved scanner"


@pytest.mark.asyncio
async def test_ctrl_s_saves_stage_and_refreshes_detail_and_table() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        stage=TicketStage.OPEN,
        contact="vip_client",
        user="operator_1",
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("l", "l")
        await pilot.pause()

        stage_select = app.screen.query_one("#ticket-stage-input", Select)
        stage_select.value = "WAIT"
        await pilot.pause()

        await pilot.press("ctrl+s")
        await wait_until(lambda: app.loading_message is None)

        assert connector.store_ticket_calls == [
            (
                ticket,
                TicketEditPatch(stage=TicketStage.WAIT),
            )
        ]
        assert app.query_one("#tickets-table", DataTable).get_row_at(0)[7] == "Waiting"
        assert app.app_state.active_ticket is not None
        assert app.app_state.active_ticket.stage is TicketStage.WAIT
        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#ticket-stage-input", Select).value == "WAIT"
        assert app.screen.query_one("#status-bar", Static).render() == "Saved ticket: Broken scanner"


@pytest.mark.asyncio
async def test_ctrl_s_saves_stage_while_stage_overlay_is_focused() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        stage=TicketStage.OPEN,
        contact="vip_client",
        user="operator_1",
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("l", "l", "down", "enter")
        await pilot.pause()

        stage_select = app.screen.query_one("#ticket-stage-input", Select)
        stage_select.value = "WAIT"
        await pilot.pause()

        assert type(app.focused).__name__ == "TicketFormSelectOverlay"

        await pilot.press("ctrl+s")
        await wait_until(lambda: app.loading_message is None)

        assert connector.store_ticket_calls == [
            (
                ticket,
                TicketEditPatch(stage=TicketStage.WAIT),
            )
        ]
        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#ticket-stage-input", Select).value == "WAIT"
        assert app.screen.query_one("#status-bar", Static).render() == "Saved ticket: Broken scanner"


@pytest.mark.asyncio
async def test_ctrl_s_saves_priority_and_refreshes_detail_and_table() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        priority=TicketPriority.HIGH,
        contact="vip_client",
        user="operator_1",
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("l", "l")
        await pilot.pause()

        priority_select = app.screen.query_one("#ticket-priority-input", Select)
        priority_select.value = "LOW"
        await pilot.pause()

        await pilot.press("ctrl+s")
        await wait_until(lambda: app.loading_message is None)

        assert connector.store_ticket_calls == [
            (
                ticket,
                TicketEditPatch(priority=TicketPriority.LOW),
            )
        ]
        assert app.query_one("#tickets-table", DataTable).get_row_at(0)[3] == "3"
        assert app.app_state.active_ticket is not None
        assert app.app_state.active_ticket.priority is TicketPriority.LOW
        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#ticket-priority-input", Select).value == "LOW"
        assert app.screen.query_one("#status-bar", Static).render() == "Saved ticket: Broken scanner"


@pytest.mark.asyncio
async def test_ctrl_s_saves_priority_while_priority_overlay_is_focused() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        priority=TicketPriority.HIGH,
        contact="vip_client",
        user="operator_1",
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("l", "l", "down", "down", "enter")
        await pilot.pause()

        priority_select = app.screen.query_one("#ticket-priority-input", Select)
        priority_select.value = "LOW"
        await pilot.pause()

        assert type(app.focused).__name__ == "TicketFormSelectOverlay"

        await pilot.press("ctrl+s")
        await wait_until(lambda: app.loading_message is None)

        assert connector.store_ticket_calls == [
            (
                ticket,
                TicketEditPatch(priority=TicketPriority.LOW),
            )
        ]
        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#ticket-priority-input", Select).value == "LOW"
        assert app.screen.query_one("#status-bar", Static).render() == "Saved ticket: Broken scanner"


@pytest.mark.asyncio
async def test_ctrl_s_saves_category_by_daktela_name_and_refreshes_visible_title() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        category="Delivery",
        category_name="categories_delivery",
        contact="vip_client",
        user="operator_1",
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_categories(
        [
            TicketCategoryOption(name="categories_delivery", title="Delivery"),
            TicketCategoryOption(name="categories_returns", title="Returns"),
        ]
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_categories_calls == 1)
        await wait_until(
            lambda: "categories_returns"
            in {
                value
                for _, value in app.screen.query_one("#ticket-category-input", Select)._options
            }
        )

        category_select = app.screen.query_one("#ticket-category-input", Select)
        category_select.value = "categories_returns"
        await pilot.pause()

        await pilot.press("ctrl+s")
        await wait_until(lambda: app.loading_message is None)

        assert connector.store_ticket_calls == [
            (
                ticket,
                TicketEditPatch(
                    category_name="categories_returns",
                    category_title="Returns",
                ),
            )
        ]
        assert app.query_one("#tickets-table", DataTable).get_row_at(0)[4] == "Returns"
        assert app.app_state.active_ticket is not None
        assert app.app_state.active_ticket.category == "Returns"
        assert app.app_state.active_ticket.category_name == "categories_returns"
        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#ticket-category-input", Select).value == (
            "categories_returns"
        )
        assert app.screen.query_one("#status-bar", Static).render() == (
            "Saved ticket: Broken scanner"
        )


@pytest.mark.asyncio
async def test_ctrl_s_saves_user_by_daktela_name_and_refreshes_visible_title() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        contact="vip_client",
        user="Operator One",
        user_name="operator_1",
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_users(
        [
            TicketUserOption(name="operator_1", title="Operator One"),
            TicketUserOption(name="operator_2", title="Operator Two"),
        ]
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_users_calls == 1)
        await wait_until(
            lambda: "operator_2"
            in {
                value
                for _, value in app.screen.query_one("#ticket-user-input", Select)._options
            }
        )

        user_select = app.screen.query_one("#ticket-user-input", Select)
        user_select.value = "operator_2"
        await pilot.pause()

        await pilot.press("ctrl+s")
        await wait_until(lambda: app.loading_message is None)

        assert connector.store_ticket_calls == [
            (
                ticket,
                TicketEditPatch(
                    user_name="operator_2",
                    user_title="Operator Two",
                ),
            )
        ]
        assert app.query_one("#tickets-table", DataTable).get_row_at(0)[8] == "Operator Two"
        assert app.app_state.active_ticket is not None
        assert app.app_state.active_ticket.user == "Operator Two"
        assert app.app_state.active_ticket.user_name == "operator_2"
        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#ticket-user-input", Select).value == "operator_2"
        assert app.screen.query_one("#status-bar", Static).render() == "Saved ticket: Broken scanner"


@pytest.mark.asyncio
async def test_ctrl_s_saves_status_by_daktela_name_and_refreshes_visible_title() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        category="Delivery",
        category_name="categories_delivery",
        contact="vip_client",
        user="operator_1",
        statuses={"status_dispatch": "Dispatch"},
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_statuses(
        "categories_delivery",
        [
            TicketStatusOption(name="status_dispatch", title="Dispatch"),
            TicketStatusOption(name="status_return", title="Return"),
        ],
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_statuses_calls == ["categories_delivery"])
        await wait_until(
            lambda: "status_return"
            in {
                value
                for _, value in app.screen.query_one("#ticket-status-input", Select)._options
            }
        )

        status_select = app.screen.query_one("#ticket-status-input", Select)
        status_select.value = "status_return"
        await pilot.pause()

        await pilot.press("ctrl+s")
        await wait_until(lambda: app.loading_message is None)

        assert connector.store_ticket_calls == [
            (
                ticket,
                TicketEditPatch(
                    status_name="status_return",
                    status_title="Return",
                ),
            )
        ]
        assert app.query_one("#tickets-table", DataTable).get_row_at(0)[5] == "Return"
        assert app.app_state.active_ticket is not None
        assert app.app_state.active_ticket.statuses == {"status_return": "Return"}
        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#ticket-status-input", Select).value == "status_return"
        assert app.screen.query_one("#status-bar", Static).render() == "Saved ticket: Broken scanner"


@pytest.mark.asyncio
async def test_ctrl_s_clears_status_and_refreshes_detail_and_table() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        category="Delivery",
        category_name="categories_delivery",
        contact="vip_client",
        user="operator_1",
        statuses={"status_dispatch": "Dispatch"},
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_statuses(
        "categories_delivery",
        [TicketStatusOption(name="status_dispatch", title="Dispatch")],
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_statuses_calls == ["categories_delivery"])

        status_select = app.screen.query_one("#ticket-status-input", Select)
        status_select.value = NO_STATUS_VALUE
        await pilot.pause()

        await pilot.press("ctrl+s")
        await wait_until(lambda: app.loading_message is None)

        assert connector.store_ticket_calls == [
            (
                ticket,
                TicketEditPatch(
                    status_name=None,
                    status_title=None,
                ),
            )
        ]
        assert app.query_one("#tickets-table", DataTable).get_row_at(0)[5] == "-"
        assert app.app_state.active_ticket is not None
        assert app.app_state.active_ticket.statuses is None
        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#ticket-status-input", Select).value == NO_STATUS_VALUE
        assert app.screen.query_one("#status-bar", Static).render() == "Saved ticket: Broken scanner"


@pytest.mark.asyncio
async def test_ctrl_s_clears_user_and_refreshes_detail_and_table() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        contact="vip_client",
        user="Operator One",
        user_name="operator_1",
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_users(
        [TicketUserOption(name="operator_1", title="Operator One")]
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_users_calls == 1)

        user_select = app.screen.query_one("#ticket-user-input", Select)
        user_select.value = UNASSIGNED_USER_VALUE
        await pilot.pause()

        await pilot.press("ctrl+s")
        await wait_until(lambda: app.loading_message is None)

        assert connector.store_ticket_calls == [
            (
                ticket,
                TicketEditPatch(
                    user_name=None,
                    user_title=None,
                ),
            )
        ]
        assert app.query_one("#tickets-table", DataTable).get_row_at(0)[8] == "-"
        assert app.app_state.active_ticket is not None
        assert app.app_state.active_ticket.user is None
        assert app.app_state.active_ticket.user_name is None
        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#ticket-user-input", Select).value == UNASSIGNED_USER_VALUE
        assert app.screen.query_one("#status-bar", Static).render() == "Saved ticket: Broken scanner"


@pytest.mark.asyncio
async def test_ctrl_s_with_unchanged_category_reports_noop_save() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        category="Delivery",
        category_name="categories_delivery",
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_categories(
        [TicketCategoryOption(name="categories_delivery", title="Delivery")]
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_categories_calls == 1)

        app.screen.query_one("#ticket-category-input", Select).value = "categories_delivery"
        await pilot.pause()

        await pilot.press("ctrl+s")
        await pilot.pause()

        assert connector.store_ticket_calls == []
        assert app.screen.query_one("#status-bar", Static).render() == "No changes to save."


@pytest.mark.asyncio
async def test_ctrl_s_with_unchanged_stage_reports_noop_save() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        stage=TicketStage.OPEN,
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("l", "l")
        await pilot.pause()

        app.screen.query_one("#ticket-stage-input", Select).value = "OPEN"
        await pilot.pause()

        await pilot.press("ctrl+s")
        await pilot.pause()

        assert connector.store_ticket_calls == []
        assert app.screen.query_one("#status-bar", Static).render() == "No changes to save."


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("shortcut", "initial_stage"),
    [
        ("c", TicketStage.CLOSE),
        ("o", TicketStage.OPEN),
        ("w", TicketStage.WAIT),
    ],
)
async def test_stage_shortcut_with_unchanged_stage_is_a_noop(
    shortcut: str,
    initial_stage: TicketStage,
) -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        stage=initial_stage,
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("l", "l")
        await pilot.pause()

        await pilot.press(shortcut)
        await pilot.pause()

        assert connector.store_ticket_calls == []
        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#ticket-stage-input", Select).value == initial_stage.value
        assert app.screen.query_one("#status-bar", Static).render() == (
            "Selected ticket: Broken scanner"
        )


@pytest.mark.asyncio
async def test_unsaved_changes_modal_discard_closes_detail_without_saving() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await pilot.pause()

        tickets_table = app.query_one("#tickets-table", DataTable)
        app.screen.query_one("#ticket-name-input", Input).value = "Unsaved scanner"
        await pilot.press("q")
        await pilot.pause()
        modal = app.screen
        assert isinstance(modal, UnsavedChangesModal)
        assert str(modal.query_one("#unsaved-changes-option-save", Static).render()) == (
            "[s] Save and close"
        )
        assert str(modal.query_one("#unsaved-changes-option-discard", Static).render()) == (
            "[c] Close without saving"
        )
        assert str(modal.query_one("#unsaved-changes-option-cancel", Static).render()) == (
            "Stay here Esc/q"
        )

        await pilot.press("c")
        await pilot.pause()

        assert connector.store_ticket_calls == []
        assert not isinstance(app.screen, TicketDetail)
        assert app.focused is tickets_table
        assert tickets_table.get_row_at(0)[2] == "Broken scanner"


@pytest.mark.asyncio
async def test_unsaved_changes_modal_cancel_keeps_detail_open_with_edited_values() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001, description="Old description")
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await pilot.pause()

        detail_screen = app.screen
        detail_screen.query_one("#ticket-name-input", Input).value = "Unsaved scanner"
        await pilot.press("q")
        await pilot.pause()
        modal = app.screen
        assert isinstance(modal, UnsavedChangesModal)
        assert str(modal.query_one("#unsaved-changes-option-cancel", Static).render()) == (
            "Stay here Esc/q"
        )

        await pilot.press("q")
        await pilot.pause()

        assert app.screen is detail_screen
        assert connector.store_ticket_calls == []
        assert detail_screen.query_one("#ticket-name-input", Input).value == "Unsaved scanner"
        assert detail_screen.query_one("#ticket-description-input", TextArea).text == (
            "Old description"
        )


@pytest.mark.asyncio
async def test_unsaved_changes_modal_escape_cancels_and_keeps_detail_open() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001, description="Old description")
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await pilot.pause()

        detail_screen = app.screen
        detail_screen.query_one("#ticket-name-input", Input).value = "Unsaved scanner"
        await pilot.press("q")
        await pilot.pause()
        assert isinstance(app.screen, UnsavedChangesModal)

        await pilot.press("escape")
        await pilot.pause()

        assert app.screen is detail_screen
        assert connector.store_ticket_calls == []
        assert detail_screen.query_one("#ticket-name-input", Input).value == "Unsaved scanner"
        assert detail_screen.query_one("#ticket-description-input", TextArea).text == (
            "Old description"
        )


@pytest.mark.asyncio
async def test_unsaved_changes_modal_save_persists_then_closes_detail() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        description="Old description",
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await pilot.pause()

        detail_screen = app.screen
        detail_screen.query_one("#ticket-name-input", Input).value = "Saved scanner"
        detail_screen.query_one("#ticket-description-input", TextArea).load_text("Saved description")
        await pilot.press("q")
        await pilot.pause()
        assert isinstance(app.screen, UnsavedChangesModal)

        await pilot.press("s")
        await wait_until(
            lambda: app.loading_message is None and not isinstance(app.screen, TicketDetail)
        )

        assert connector.store_ticket_calls == [
            (
                ticket,
                TicketEditPatch(title="Saved scanner", description="Saved description"),
            )
        ]
        assert detail_screen not in app.screen_stack
        assert app.query_one("#tickets-table", DataTable).get_row_at(0)[2] == "Saved scanner"
        assert app.app_state.active_ticket is not None
        assert app.app_state.active_ticket.title == "Saved scanner"
        assert app.app_state.active_ticket.description == "Saved description"


@pytest.mark.asyncio
async def test_unsaved_changes_modal_save_after_category_edit_persists_then_closes_detail() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        category="Delivery",
        category_name="categories_delivery",
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_categories(
        [
            TicketCategoryOption(name="categories_delivery", title="Delivery"),
            TicketCategoryOption(name="categories_returns", title="Returns"),
        ]
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_categories_calls == 1)
        await wait_until(
            lambda: "categories_returns"
            in {
                value
                for _, value in app.screen.query_one("#ticket-category-input", Select)._options
            }
        )

        detail_screen = app.screen
        assert isinstance(detail_screen, TicketDetail)

        await pilot.press("down", "down", "down", "enter", "j", "l")
        await pilot.pause()

        assert app.screen is detail_screen
        assert detail_screen.query_one("#ticket-category-input", Select).value == (
            "categories_returns"
        )

        await pilot.press("q")
        await pilot.pause()
        assert isinstance(app.screen, UnsavedChangesModal)

        await pilot.press("s")
        await wait_until(
            lambda: app.loading_message is None and not isinstance(app.screen, TicketDetail)
        )

        assert connector.store_ticket_calls == [
            (
                ticket,
                TicketEditPatch(
                    category_name="categories_returns",
                    category_title="Returns",
                ),
            )
        ]
        assert detail_screen not in app.screen_stack
        assert app.app_state.active_ticket is not None
        assert app.app_state.active_ticket.category == "Returns"
        assert app.app_state.active_ticket.category_name == "categories_returns"


@pytest.mark.asyncio
async def test_unsaved_changes_modal_save_after_user_edit_persists_then_closes_detail() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        user="Operator One",
        user_name="operator_1",
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_users(
        [
            TicketUserOption(name="operator_1", title="Operator One"),
            TicketUserOption(name="operator_2", title="Operator Two"),
        ]
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_users_calls == 1)
        await wait_until(
            lambda: "operator_2"
            in {
                value
                for _, value in app.screen.query_one("#ticket-user-input", Select)._options
            }
        )

        detail_screen = app.screen
        assert isinstance(detail_screen, TicketDetail)

        detail_screen.query_one("#ticket-user-input", Select).value = "operator_2"
        await pilot.pause()

        assert app.screen is detail_screen
        assert detail_screen.query_one("#ticket-user-input", Select).value == "operator_2"

        await pilot.press("q")
        await pilot.pause()
        assert isinstance(app.screen, UnsavedChangesModal)

        await pilot.press("s")
        await wait_until(
            lambda: app.loading_message is None and not isinstance(app.screen, TicketDetail)
        )

        assert connector.store_ticket_calls == [
            (
                ticket,
                TicketEditPatch(
                    user_name="operator_2",
                    user_title="Operator Two",
                ),
            )
        ]
        assert detail_screen not in app.screen_stack
        assert app.app_state.active_ticket is not None
        assert app.app_state.active_ticket.user == "Operator Two"
        assert app.app_state.active_ticket.user_name == "operator_2"


@pytest.mark.asyncio
async def test_unsaved_changes_modal_save_after_assign_to_me_persists_then_closes_detail() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        user=None,
        user_name=None,
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_users(
        [
            TicketUserOption(name="operator_1", title="Operator One"),
            TicketUserOption(name="operator_2", title="Operator Two"),
        ]
    )
    connector.set_current_user(
        TicketUserOption(name="operator_2", title="Operator Two")
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_users_calls == 1)
        await wait_until(
            lambda: isinstance(app.screen, TicketDetail)
            and cast(TicketDetail, app.screen)._current_user is not None
        )

        detail_screen = cast(TicketDetail, app.screen)
        assert detail_screen.query_one("#ticket-user-input", Select).value == UNASSIGNED_USER_VALUE

        await pilot.press("m")
        await pilot.pause()

        assert detail_screen.query_one("#ticket-user-input", Select).value == "operator_2"

        await pilot.press("q")
        await pilot.pause()
        assert isinstance(app.screen, UnsavedChangesModal)

        await pilot.press("s")
        await wait_until(
            lambda: app.loading_message is None and not isinstance(app.screen, TicketDetail)
        )

        assert connector.store_ticket_calls == [
            (
                ticket,
                TicketEditPatch(
                    user_name="operator_2",
                    user_title="Operator Two",
                ),
            )
        ]
        assert detail_screen not in app.screen_stack
        assert app.app_state.active_ticket is not None
        assert app.app_state.active_ticket.user == "Operator Two"
        assert app.app_state.active_ticket.user_name == "operator_2"


@pytest.mark.asyncio
async def test_unsaved_changes_modal_save_after_stage_edit_persists_then_closes_detail() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        stage=TicketStage.OPEN,
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await pilot.pause()

        detail_screen = app.screen
        assert isinstance(detail_screen, TicketDetail)

        await pilot.press("down", "enter", "j", "l")
        await pilot.pause()

        assert app.screen is detail_screen
        assert detail_screen.query_one("#ticket-stage-input", Select).value == "WAIT"

        await pilot.press("q")
        await pilot.pause()
        assert isinstance(app.screen, UnsavedChangesModal)

        await pilot.press("s")
        await wait_until(
            lambda: app.loading_message is None and not isinstance(app.screen, TicketDetail)
        )

        assert connector.store_ticket_calls == [
            (
                ticket,
                TicketEditPatch(stage=TicketStage.WAIT),
            )
        ]
        assert detail_screen not in app.screen_stack
        assert app.app_state.active_ticket is not None
        assert app.app_state.active_ticket.stage is TicketStage.WAIT


@pytest.mark.asyncio
async def test_unsaved_changes_modal_save_after_priority_edit_persists_then_closes_detail() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        priority=TicketPriority.HIGH,
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await pilot.pause()

        detail_screen = app.screen
        assert isinstance(detail_screen, TicketDetail)

        detail_screen.query_one("#ticket-priority-input", Select).value = "LOW"
        await pilot.pause()

        assert app.screen is detail_screen
        assert detail_screen.query_one("#ticket-priority-input", Select).value == "LOW"

        await pilot.press("q")
        await pilot.pause()
        assert isinstance(app.screen, UnsavedChangesModal)

        await pilot.press("s")
        await wait_until(
            lambda: app.loading_message is None and not isinstance(app.screen, TicketDetail)
        )

        assert connector.store_ticket_calls == [
            (
                ticket,
                TicketEditPatch(priority=TicketPriority.LOW),
            )
        ]
        assert detail_screen not in app.screen_stack
        assert app.app_state.active_ticket is not None
        assert app.app_state.active_ticket.priority is TicketPriority.LOW


@pytest.mark.asyncio
async def test_unsaved_changes_modal_save_click_after_category_edit_persists_then_closes_detail() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        category="Delivery",
        category_name="categories_delivery",
    )
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_categories(
        [
            TicketCategoryOption(name="categories_delivery", title="Delivery"),
            TicketCategoryOption(name="categories_returns", title="Returns"),
        ]
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await wait_until(lambda: connector.list_ticket_categories_calls == 1)
        await wait_until(
            lambda: "categories_returns"
            in {
                value
                for _, value in app.screen.query_one("#ticket-category-input", Select)._options
            }
        )

        await pilot.press("down", "down", "down", "enter", "j", "l")
        await pilot.pause()
        await pilot.press("q")
        await pilot.pause()

        modal = app.screen
        assert isinstance(modal, UnsavedChangesModal)

        await pilot.click("#unsaved-changes-option-save")
        await wait_until(
            lambda: app.loading_message is None and not isinstance(app.screen, TicketDetail)
        )

        assert connector.store_ticket_calls == [
            (
                ticket,
                TicketEditPatch(
                    category_name="categories_returns",
                    category_title="Returns",
                ),
            )
        ]
        assert app.app_state.active_ticket is not None
        assert app.app_state.active_ticket.category == "Returns"
        assert app.app_state.active_ticket.category_name == "categories_returns"


@pytest.mark.asyncio
async def test_ctrl_s_blocks_blank_ticket_name_before_connector_call() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("l", "l", "enter")
        await pilot.pause()

        app.screen.query_one("#ticket-name-input", Input).value = "   "
        await pilot.press("ctrl+s")
        await pilot.pause()

        assert connector.store_ticket_calls == []
        assert app.screen.query_one("#status-bar", Static).render() == "Ticket name can't be blank."


@pytest.mark.asyncio
async def test_ctrl_s_blocks_invalid_reopen_before_connector_call() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("l", "l")
        await pilot.pause()

        reopen_input = app.screen.query_one("#ticket-reopen-input", Input)
        reopen_input.value = "2026-02-31 09:15:00"

        await pilot.press("ctrl+s")
        await pilot.pause()

        assert connector.store_ticket_calls == []
        assert app.screen.query_one("#status-bar", Static).render() == (
            "Reopen must use YYYY-MM-DD HH:MM:SS with a real date and time."
        )
        assert app.screen.query_one("#ticket-reopen-input", Input).value == "2026-02-31 09:15:00"


@pytest.mark.asyncio
async def test_ctrl_s_without_changes_reports_noop_save() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("l", "l", "ctrl+s")
        await pilot.pause()

        assert connector.store_ticket_calls == []
        assert app.screen.query_one("#status-bar", Static).render() == "No changes to save."


@pytest.mark.asyncio
async def test_ctrl_s_keeps_form_values_when_connector_save_fails() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001, description="Old description")
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_store_behavior(error=RuntimeError("save exploded"))
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("l", "l", "enter")
        await pilot.pause()
        app.screen.query_one("#ticket-name-input", Input).value = "Unsaved scanner"
        await pilot.press("escape")
        await pilot.pause()

        await pilot.press("ctrl+s")
        await wait_until(lambda: app.loading_message is None)

        assert connector.store_ticket_calls == [
            (ticket, TicketEditPatch(title="Unsaved scanner"))
        ]
        assert app.screen.query_one("#status-bar", Static).render() == "Error saving ticket: save exploded"
        assert app.screen.query_one("#ticket-name-input", Input).value == "Unsaved scanner"
        assert app.app_state.active_ticket is not None
        assert app.app_state.active_ticket.title == "Broken scanner"


@pytest.mark.asyncio
async def test_unsaved_changes_modal_save_failure_keeps_detail_open_with_edited_values() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001, description="Old description")
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_store_behavior(error=RuntimeError("save exploded"))
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await pilot.pause()

        detail_screen = app.screen
        detail_screen.query_one("#ticket-name-input", Input).value = "Unsaved scanner"
        await pilot.press("q")
        await pilot.pause()
        assert isinstance(app.screen, UnsavedChangesModal)

        await pilot.press("s")
        await wait_until(lambda: app.loading_message is None)

        assert app.screen is detail_screen
        assert connector.store_ticket_calls == [
            (ticket, TicketEditPatch(title="Unsaved scanner"))
        ]
        assert detail_screen.query_one("#status-bar", Static).render() == (
            "Error saving ticket: save exploded"
        )
        assert detail_screen.query_one("#ticket-name-input", Input).value == "Unsaved scanner"


@pytest.mark.asyncio
async def test_unsaved_changes_modal_save_with_blank_title_shows_validation_error() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await pilot.pause()

        detail_screen = app.screen
        detail_screen.query_one("#ticket-name-input", Input).value = "   "
        await pilot.press("escape")
        await pilot.pause()
        assert isinstance(app.screen, UnsavedChangesModal)

        await pilot.press("s")
        await pilot.pause()

        assert app.screen is detail_screen
        assert connector.store_ticket_calls == []
        assert detail_screen.query_one("#status-bar", Static).render() == "Ticket name can't be blank."
        assert detail_screen.query_one("#ticket-name-input", Input).value == "   "


@pytest.mark.asyncio
async def test_unsaved_changes_modal_save_with_invalid_reopen_shows_validation_error() -> None:
    view = make_ticket_view(title="Escalated only")
    ticket = make_ticket(title="Broken scanner", name=2001)
    state = AppState(
        tickets=[ticket],
        views=[view],
        active_view=view,
        active_ticket=None,
    )
    connector = MockTicketConnector.from_state(state)
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("l", "l")
        await pilot.pause()

        detail_screen = app.screen
        detail_screen.query_one("#ticket-reopen-input", Input).value = "2026-03-31 25:15:00"
        await pilot.press("q")
        await pilot.pause()
        assert isinstance(app.screen, UnsavedChangesModal)

        await pilot.press("s")
        await pilot.pause()

        assert app.screen is detail_screen
        assert connector.store_ticket_calls == []
        assert detail_screen.query_one("#status-bar", Static).render() == (
            "Reopen must use YYYY-MM-DD HH:MM:SS with a real date and time."
        )
        assert detail_screen.query_one("#ticket-reopen-input", Input).value == "2026-03-31 25:15:00"


@pytest.mark.asyncio
async def test_app_status_bar_shows_pending_ticket_jump_and_restores_base_message() -> None:
    # Arrange
    app = make_demo_app()

    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("j", "enter")
        await pilot.pause()

        status_bar = app.query_one("#status-bar", Static)
        assert status_bar.render() == "Selected view: Half-Life 2"

        # Act
        await pilot.press("1", "3")
        await pilot.pause()
        pending_status = status_bar.render()

        await pilot.press("j")
        await pilot.pause()
        restored_status = status_bar.render()

        # Assert
        assert pending_status == "Ticket jump: 13"
        assert restored_status == "Selected view: Half-Life 2"


@pytest.mark.asyncio
async def test_app_ticket_search_updates_status_bar_and_keeps_main_screen_active() -> None:
    view = make_ticket_view("Delivery")
    app = DaktelaPaleoApp(
        initial_state=AppState(
            tickets=[
                make_ticket(title="broken scanner", name=2001),
                make_ticket(title="delivery blocked", name=2002),
                make_ticket(title="scanner offline", name=2003),
            ],
            views=[view],
            active_view=view,
        ),
        connector=MockTicketConnector(),
    )

    async with app.run_test() as pilot:
        await pilot.pause()
        app.query_one(TicketList).focus_tickets()
        await pilot.pause()

        tickets_table = app.query_one("#tickets-table", TicketTable)
        tickets_table.apply_search("scanner")
        await pilot.pause()

        assert not isinstance(app.screen, TicketDetail)
        assert app.focused is tickets_table
        assert tickets_table.cursor_row == 0
        assert status_text(app) == "/scanner 1/2"

        await pilot.press("n")
        await pilot.pause()

        assert tickets_table.cursor_row == 2
        assert status_text(app) == "/scanner 2/2"


@pytest.mark.asyncio
async def test_app_ticket_search_reports_no_matches_and_invalid_regex() -> None:
    view = make_ticket_view("Delivery")
    app = DaktelaPaleoApp(
        initial_state=AppState(
            tickets=[make_ticket(title="broken scanner", name=2001)],
            views=[view],
            active_view=view,
        ),
        connector=MockTicketConnector(),
    )

    async with app.run_test() as pilot:
        await pilot.pause()
        app.query_one(TicketList).focus_tickets()
        await pilot.pause()

        tickets_table = app.query_one("#tickets-table", TicketTable)
        tickets_table.apply_search("missing")
        await pilot.pause()

        assert app.focused is tickets_table
        assert status_text(app) == "No matches: /missing"

        tickets_table.apply_search("[")
        await pilot.pause()

        assert app.focused is tickets_table
        assert status_text(app).startswith("Invalid regex: ")


@pytest.mark.asyncio
async def test_app_ticket_detail_search_updates_status_bar_without_leaking_main_table_search() -> None:
    view = make_ticket_view("Delivery")
    first_ticket = make_ticket(title="broken scanner", name=2001)
    second_ticket = make_ticket(title="scanner offline", name=2002)
    state = AppState(
        tickets=[first_ticket, second_ticket],
        views=[view],
        active_view=view,
    )
    connector = MockTicketConnector.from_state(state)
    connector.set_ticket_activities(
        first_ticket,
        [
            make_activity(title="Scanner follow-up"),
            make_activity(title="Internal note", type="", item_model=None),
            make_activity(title="Scanner replacement"),
        ],
    )
    app = DaktelaPaleoApp(initial_state=state, connector=connector)

    async with app.run_test() as pilot:
        await pilot.pause()
        app.query_one(TicketList).focus_tickets()
        await pilot.pause()

        tickets_table = app.query_one("#tickets-table", TicketTable)
        tickets_table.apply_search("scanner")
        await pilot.pause()

        assert status_text(app) == "/scanner 1/2"

        await pilot.press("l")
        await wait_until(lambda: connector.list_ticket_activities_calls == [("name", "2001")])
        await wait_until(
            lambda: isinstance(app.screen, TicketDetail)
            and "Scanner follow-up"
            in str(app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        )

        assert isinstance(app.screen, TicketDetail)
        assert status_text(app.screen) == "Selected ticket: broken scanner"

        await pilot.press("tab", "/", "S", "c", "a", "n", "n", "e", "r", "enter")
        await pilot.pause()

        right_body = app.screen.query_one("#ticket-detail-right-body", DetailPaneBody)

        assert app.focused is right_body
        assert right_body.active_index == 0
        assert status_text(app.screen) == "/Scanner 1/2"

        await pilot.press("n")
        await pilot.pause()

        assert right_body.active_index == 2
        assert status_text(app.screen) == "/Scanner 2/2"


@pytest.mark.asyncio
async def test_app_ticket_jump_status_temporarily_overrides_active_search_status() -> None:
    view = make_ticket_view("My Open")
    app = DaktelaPaleoApp(
        initial_state=AppState(
            tickets=make_ticket_batch(20),
            views=[view],
            active_view=view,
        ),
        connector=MockTicketConnector(),
    )

    async with app.run_test() as pilot:
        await pilot.pause()
        app.query_one(TicketList).focus_tickets()
        await pilot.pause()

        tickets_table = app.query_one("#tickets-table", TicketTable)
        tickets_table.apply_search("Ticket")
        await pilot.pause()

        assert status_text(app) == "/Ticket 1/20"

        await pilot.press("1", "3")
        await pilot.pause()
        pending_status = status_text(app)

        await pilot.press("j")
        await pilot.pause()
        restored_status = status_text(app)

        assert pending_status == "Ticket jump: 13"
        assert restored_status == "/Ticket 14/20"


@pytest.mark.asyncio
async def test_ticket_table_blur_clears_pending_prefix() -> None:
    # Arrange
    app = DaktelaPaleoApp(
        connector=MockTicketConnector.from_state(
            AppState(
                tickets=make_ticket_batch(20),
                views=[make_ticket_view("My Open")],
                active_view=make_ticket_view("My Open"),
            )
        )
    )

    async with app.run_test() as pilot:
        await pilot.pause()
        tickets_table = app.query_one("#tickets-table", DataTable)
        views_list = app.query_one("#views-list", ListView)

        assert app.focused is views_list

        await pilot.press("enter")
        await pilot.pause()
        assert app.focused is tickets_table

        # Act
        await pilot.press("1", "2", "h")
        await pilot.pause()
        await pilot.press("enter", "j")
        await pilot.pause()

        # Assert
        assert app.focused is tickets_table
        assert tickets_table.cursor_row == 1
        assert app.query_one("#status-bar", Static).render() == "Selected view: My Open"


@pytest.mark.asyncio
async def test_mouse_drag_resizes_panes() -> None:
    app = make_demo_app()

    async with app.run_test(size=(120, 24)) as pilot:
        await pilot.pause()

        views_pane = app.query_one("#views-pane", Vertical)
        tickets_pane = app.query_one("#tickets-pane", Vertical)
        splitter = app.query_one("#splitter", Static)

        initial_views_width = views_pane.region.width
        initial_tickets_width = tickets_pane.region.width

        await pilot.mouse_down(None, offset=(splitter.region.x, splitter.region.y))
        await pilot.hover(None, offset=(110, splitter.region.y))
        await pilot.mouse_up(None, offset=(110, splitter.region.y))
        await pilot.pause()

        assert views_pane.region.width > initial_views_width
        assert tickets_pane.region.width < initial_tickets_width
        assert views_pane.region.width == 89
        assert tickets_pane.region.width == 30


@pytest.mark.asyncio
async def test_app_quits_when_q_is_pressed() -> None:
    app = make_demo_app()

    async with app.run_test() as pilot:
        assert app.is_running is True

        await pilot.press("q")
        await pilot.pause()

        assert app.is_running is False


def test_action_focus_views_ignores_missing_ticket_list(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()

    def raise_no_matches(*args: object, **kwargs: object) -> None:
        raise NoMatches("ticket list not mounted")

    monkeypatch.setattr(app, "query_one", raise_no_matches)

    app.action_focus_views()


def test_activate_instance_returns_early_when_connector_is_unchanged(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    saved_instance = make_saved_instance()
    app = DaktelaPaleoApp(
        connector=DaktelaTicketConnector(saved_instance.base_url, saved_instance.user_token)
    )
    app.instance_config = DaktelaInstanceConfig(
        active_instance_id=saved_instance.id,
        instances=[saved_instance],
    )
    app.active_instance = saved_instance

    def fail_if_called(*args: object, **kwargs: object) -> None:
        raise AssertionError("_activate_saved_instance should not be called")

    monkeypatch.setattr(app, "_activate_saved_instance", fail_if_called)

    app.activate_instance(saved_instance.id)


def test_activate_instance_ignores_missing_ticket_list_when_refocusing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    saved_instance = make_saved_instance()
    app = DaktelaPaleoApp(connector=MockTicketConnector())
    app.instance_config = DaktelaInstanceConfig(
        active_instance_id=saved_instance.id,
        instances=[saved_instance],
    )
    begin_calls: list[str] = []

    def fake_begin_initial_load() -> None:
        begin_calls.append("load")

    def raise_no_matches(*args: object, **kwargs: object) -> None:
        raise NoMatches("ticket list not mounted")

    monkeypatch.setattr(app, "_begin_initial_load", fake_begin_initial_load)
    monkeypatch.setattr(app, "query_one", raise_no_matches)

    app.activate_instance(saved_instance.id)

    assert isinstance(app.connector, DaktelaTicketConnector)
    assert app.connector.pbx_name == saved_instance.base_url
    assert app.connector.user_token == saved_instance.user_token
    assert begin_calls == ["load"]


def test_activate_instance_with_missing_saved_id_sets_error() -> None:
    saved_instance = make_saved_instance()
    app = DaktelaPaleoApp(connector=MockTicketConnector())
    app.instance_config = DaktelaInstanceConfig(
        active_instance_id=saved_instance.id,
        instances=[saved_instance],
    )

    app.activate_instance("missing")

    assert app.error_message == "Saved Daktela instance is no longer available."


def test_restore_runtime_from_demo_mode_without_snapshot_disconnects(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = DaktelaPaleoApp(connector=MockTicketConnector())
    calls: list[tuple[TicketConnector | None, DaktelaInstanceRecord | None]] = []
    app._demo_mode_active = True

    def fake_activate_runtime(
        connector: TicketConnector | None,
        *,
        active_instance: DaktelaInstanceRecord | None,
    ) -> None:
        calls.append((connector, active_instance))

    monkeypatch.setattr(app, "_activate_runtime", fake_activate_runtime)

    app._restore_runtime_from_demo_mode()

    assert calls == [(None, None)]
    assert app._demo_mode_active is False
    assert app._demo_mode_restore_state is None


def test_iter_mounted_screens_returns_empty_on_screen_stack_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()

    def raise_screen_stack_error(_: DaktelaPaleoApp) -> object:
        raise app_module.ScreenStackError("screen stack is unavailable")

    monkeypatch.setattr(DaktelaPaleoApp, "screen_stack", property(raise_screen_stack_error))

    assert app._iter_mounted_screens() == []


def test_iter_mounted_screens_skips_unmounted_and_duplicate_entries(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    mounted_screen = SimpleNamespace(is_mounted=True)
    unmounted_screen = SimpleNamespace(is_mounted=False)

    monkeypatch.setattr(
        DaktelaPaleoApp,
        "screen_stack",
        property(lambda self: [mounted_screen, mounted_screen, unmounted_screen]),
    )

    assert app._iter_mounted_screens() == [mounted_screen]


def test_update_instance_context_widgets_ignores_screens_without_chrome(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    missing_chrome_screen = SimpleNamespace(
        query_one=lambda *args, **kwargs: (_ for _ in ()).throw(NoMatches("chrome missing"))
    )

    monkeypatch.setattr(app, "_iter_mounted_screens", lambda: [missing_chrome_screen])

    app._update_instance_context_widgets("Instance: https://demo.daktela.com")


def test_handle_add_instance_result_ignores_none_and_cancel(tmp_path: Path) -> None:
    app = DaktelaPaleoApp(instance_store=make_instance_store(tmp_path))

    app._handle_add_instance_result(None)
    app._handle_add_instance_result(app_module.AddInstanceResult(action="cancel"))

    assert app.loading_message is None


@pytest.mark.asyncio
async def test_app_load_initial_state_propagates_cancellation(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()

    async def fake_list_views() -> list[TicketView]:
        raise asyncio.CancelledError()

    monkeypatch.setattr(app.connector, "list_views", fake_list_views)
    app._initial_load_generation = 1

    with pytest.raises(asyncio.CancelledError):
        await app._load_initial_state(1)


@pytest.mark.asyncio
async def test_app_load_initial_state_ignores_stale_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()

    async def fake_list_views() -> list[TicketView]:
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "list_views", fake_list_views)
    app._initial_load_generation = 2
    app.ticket_table_loading = True
    cast(Any, app).loading_message = "Loading tickets..."

    await app._load_initial_state(1)

    assert app.ticket_table_loading is True
    assert app.loading_message == "Loading tickets..."
    assert app.error_message is None


@pytest.mark.asyncio
async def test_app_load_initial_state_ignores_stale_success(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    stale_state = app.app_state
    view = TicketView(name="delivery", title="Delivery")

    async def fake_list_views() -> list[TicketView]:
        return [view]

    async def fake_list_tickets(active_view: TicketView | None = None) -> list[Ticket]:
        assert active_view == view
        return [make_ticket(title="Fresh ticket", name=8001)]

    monkeypatch.setattr(app.connector, "list_views", fake_list_views)
    monkeypatch.setattr(app.connector, "list_tickets", fake_list_tickets)
    app._initial_load_generation = 2
    app.ticket_table_loading = True
    cast(Any, app).loading_message = "Loading tickets..."

    await app._load_initial_state(1)

    assert app.app_state == stale_state
    assert app.ticket_table_loading is True
    assert app.loading_message == "Loading tickets..."


@pytest.mark.asyncio
async def test_app_load_tickets_for_view_propagates_cancellation(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    view = TicketView(name="delivery", title="Delivery")

    async def fake_list_tickets(active_view: TicketView | None = None) -> list[Ticket]:
        raise asyncio.CancelledError()

    monkeypatch.setattr(app.connector, "list_tickets", fake_list_tickets)
    app._ticket_load_generation = 1

    with pytest.raises(asyncio.CancelledError):
        await app._load_tickets_for_view(view, 1)


@pytest.mark.asyncio
async def test_app_load_tickets_for_view_ignores_stale_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    view = TicketView(name="delivery", title="Delivery")

    async def fake_list_tickets(active_view: TicketView | None = None) -> list[Ticket]:
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "list_tickets", fake_list_tickets)
    app._ticket_load_generation = 2
    app.ticket_table_loading = True
    cast(Any, app).loading_message = "Loading tickets: Delivery"

    await app._load_tickets_for_view(view, 1)

    assert app.ticket_table_loading is True
    assert app.loading_message == "Loading tickets: Delivery"
    assert app.error_message is None


@pytest.mark.asyncio
async def test_app_load_tickets_for_view_ignores_stale_success(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    view = TicketView(name="delivery", title="Delivery")
    existing_ticket = make_ticket(title="Existing ticket", name=8002)
    app = DaktelaPaleoApp(
        initial_state=AppState(
            views=[view],
            tickets=[existing_ticket],
            active_view=view,
            active_ticket=existing_ticket,
        ),
        connector=MockTicketConnector(),
    )

    async def fake_list_tickets(active_view: TicketView | None = None) -> list[Ticket]:
        return [make_ticket(title="Fresh ticket", name=8003)]

    monkeypatch.setattr(app.connector, "list_tickets", fake_list_tickets)
    app._ticket_load_generation = 2
    app.ticket_table_loading = True
    cast(Any, app).loading_message = "Loading tickets: Delivery"

    await app._load_tickets_for_view(view, 1)

    assert app.app_state.tickets == [existing_ticket]
    assert app.ticket_table_loading is True
    assert app.loading_message == "Loading tickets: Delivery"


@pytest.mark.asyncio
async def test_app_load_tickets_for_view_preserves_matching_active_ticket_from_fresh_results(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    view = TicketView(name="delivery", title="Delivery")
    existing_ticket = make_ticket(title="Existing ticket", name=8002)
    refreshed_ticket = make_ticket(title="Refreshed ticket", name=8002, user="agent_2")
    app = DaktelaPaleoApp(
        initial_state=AppState(
            views=[view],
            tickets=[existing_ticket],
            active_view=view,
            active_ticket=existing_ticket,
        ),
        connector=MockTicketConnector(),
    )

    async def fake_list_tickets(active_view: TicketView | None = None) -> list[Ticket]:
        assert active_view == view
        return [refreshed_ticket]

    monkeypatch.setattr(app.connector, "list_tickets", fake_list_tickets)
    monkeypatch.setattr(
        app,
        "query_one",
        lambda *args, **kwargs: (_ for _ in ()).throw(NoMatches("ticket list not mounted")),
    )
    app._ticket_load_generation = 1
    app.ticket_table_loading = True
    cast(Any, app).loading_message = "Loading tickets: Delivery"

    await app._load_tickets_for_view(view, 1, preferred_ticket=existing_ticket)

    assert app.app_state.tickets == [refreshed_ticket]
    assert app.app_state.active_ticket == refreshed_ticket
    assert app.ticket_table_loading is False
    assert app.loading_message is None


@pytest.mark.asyncio
async def test_app_load_tickets_for_view_falls_back_when_page_loading_is_not_implemented(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    view = TicketView(name="delivery", title="Delivery")
    refreshed_ticket = make_ticket(title="Refreshed ticket", name=8002, user="agent_2")
    app = DaktelaPaleoApp(
        initial_state=AppState(
            views=[view],
            active_view=view,
        ),
        connector=MockTicketConnector(),
    )

    async def fake_list_ticket_page(
        active_view: TicketView | None = None,
        *,
        page: int = 1,
    ) -> TicketPage:
        del active_view
        del page
        raise NotImplementedError()

    async def fake_list_tickets(active_view: TicketView | None = None) -> list[Ticket]:
        assert active_view == view
        return [refreshed_ticket]

    monkeypatch.setattr(app.connector, "list_ticket_page", fake_list_ticket_page)
    monkeypatch.setattr(app.connector, "list_tickets", fake_list_tickets)
    monkeypatch.setattr(
        app,
        "query_one",
        lambda *args, **kwargs: (_ for _ in ()).throw(NoMatches("ticket list not mounted")),
    )
    app._ticket_load_generation = 1
    app.ticket_table_loading = True
    cast(Any, app).loading_message = "Loading tickets: Delivery"

    await app._load_tickets_for_view(view, 1)

    assert app.app_state.tickets == [refreshed_ticket]
    assert app.app_state.ticket_pagination == TicketPagination(
        current_page=1,
        total_pages=1,
        total_tickets=1,
    )


@pytest.mark.asyncio
async def test_app_load_ticket_categories_propagates_cancellation(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(is_mounted=True, post_message=lambda message: None),
    )

    async def fake_list_ticket_categories() -> list[TicketCategoryOption]:
        raise asyncio.CancelledError()

    monkeypatch.setattr(app.connector, "list_ticket_categories", fake_list_ticket_categories)
    app._ticket_category_load_generation = 1

    with pytest.raises(asyncio.CancelledError):
        await app._load_ticket_categories(detail_screen, 1)


@pytest.mark.asyncio
async def test_app_load_ticket_categories_ignores_stale_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    posted_messages: list[object] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            post_message=posted_messages.append,
            set_ticket_categories=lambda options: None,
        ),
    )

    async def fake_list_ticket_categories() -> list[TicketCategoryOption]:
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "list_ticket_categories", fake_list_ticket_categories)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_category_load_generation = 2

    await app._load_ticket_categories(detail_screen, 1)

    assert posted_messages == []


@pytest.mark.asyncio
async def test_app_load_ticket_categories_posts_error_for_mounted_detail_screen(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    posted_messages: list[TicketDetail.StatusRequested] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            post_message=posted_messages.append,
            set_ticket_categories=lambda options: None,
        ),
    )

    async def fake_list_ticket_categories() -> list[TicketCategoryOption]:
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "list_ticket_categories", fake_list_ticket_categories)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_category_load_generation = 1

    await app._load_ticket_categories(detail_screen, 1)

    assert len(posted_messages) == 1
    assert posted_messages[0].text == "Error loading ticket categories: boom"
    assert posted_messages[0].error is True


@pytest.mark.asyncio
async def test_app_load_ticket_categories_ignores_unmounted_detail_screen(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    posted_messages: list[object] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=False,
            post_message=posted_messages.append,
            set_ticket_categories=lambda options: None,
        ),
    )

    async def fake_list_ticket_categories() -> list[TicketCategoryOption]:
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "list_ticket_categories", fake_list_ticket_categories)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_category_load_generation = 1

    await app._load_ticket_categories(detail_screen, 1)

    assert posted_messages == []


@pytest.mark.asyncio
async def test_app_load_ticket_categories_ignores_stale_success(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    updated_categories: list[list[TicketCategoryOption]] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            post_message=lambda message: None,
            set_ticket_categories=updated_categories.append,
        ),
    )
    category_options = [TicketCategoryOption(name="delivery", title="Delivery")]

    async def fake_list_ticket_categories() -> list[TicketCategoryOption]:
        return category_options

    monkeypatch.setattr(app.connector, "list_ticket_categories", fake_list_ticket_categories)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_category_load_generation = 2

    await app._load_ticket_categories(detail_screen, 1)

    assert app._ticket_category_options is None
    assert updated_categories == []


@pytest.mark.asyncio
async def test_app_load_ticket_users_propagates_cancellation(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(is_mounted=True, post_message=lambda message: None),
    )

    async def fake_list_ticket_users() -> list[TicketUserOption]:
        raise asyncio.CancelledError()

    monkeypatch.setattr(app.connector, "list_ticket_users", fake_list_ticket_users)
    app._ticket_user_load_generation = 1

    with pytest.raises(asyncio.CancelledError):
        await app._load_ticket_users(detail_screen, 1)


@pytest.mark.asyncio
async def test_app_load_ticket_users_ignores_stale_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    posted_messages: list[object] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            post_message=posted_messages.append,
            set_ticket_users=lambda options: None,
        ),
    )

    async def fake_list_ticket_users() -> list[TicketUserOption]:
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "list_ticket_users", fake_list_ticket_users)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_user_load_generation = 2

    await app._load_ticket_users(detail_screen, 1)

    assert posted_messages == []


@pytest.mark.asyncio
async def test_app_load_ticket_users_posts_error_for_mounted_detail_screen(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    posted_messages: list[TicketDetail.StatusRequested] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            post_message=posted_messages.append,
            set_ticket_users=lambda options: None,
        ),
    )

    async def fake_list_ticket_users() -> list[TicketUserOption]:
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "list_ticket_users", fake_list_ticket_users)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_user_load_generation = 1

    await app._load_ticket_users(detail_screen, 1)

    assert len(posted_messages) == 1
    assert posted_messages[0].text == "Error loading ticket users: boom"
    assert posted_messages[0].error is True


@pytest.mark.asyncio
async def test_app_load_ticket_users_ignores_stale_success(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    updated_users: list[list[TicketUserOption]] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            post_message=lambda message: None,
            set_ticket_users=updated_users.append,
        ),
    )
    user_options = [TicketUserOption(name="operator_1", title="Operator One")]

    async def fake_list_ticket_users() -> list[TicketUserOption]:
        return user_options

    monkeypatch.setattr(app.connector, "list_ticket_users", fake_list_ticket_users)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_user_load_generation = 2

    await app._load_ticket_users(detail_screen, 1)

    assert app._ticket_user_options is None
    assert updated_users == []


@pytest.mark.asyncio
async def test_app_load_ticket_users_updates_mounted_detail_screen(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    updated_users: list[list[TicketUserOption]] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            post_message=lambda message: None,
            set_ticket_users=updated_users.append,
        ),
    )
    user_options = [TicketUserOption(name="operator_1", title="Operator One")]

    async def fake_list_ticket_users() -> list[TicketUserOption]:
        return user_options

    monkeypatch.setattr(app.connector, "list_ticket_users", fake_list_ticket_users)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_user_load_generation = 1

    await app._load_ticket_users(detail_screen, 1)

    assert app._ticket_user_options == user_options
    assert updated_users == [user_options]


@pytest.mark.asyncio
async def test_app_load_ticket_activities_propagates_cancellation(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    ticket = make_ticket(title="Broken scanner", name=8001)
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(is_mounted=True, post_message=lambda message: None),
    )

    async def fake_list_ticket_activities(current_ticket: Ticket) -> list[TicketActivity]:
        assert current_ticket == ticket
        raise asyncio.CancelledError()

    monkeypatch.setattr(app.connector, "list_ticket_activities", fake_list_ticket_activities)
    app._ticket_activity_load_generation = 1

    with pytest.raises(asyncio.CancelledError):
        await app._load_ticket_activities(detail_screen, ticket, 1)


@pytest.mark.asyncio
async def test_app_load_ticket_activities_ignores_stale_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    ticket = make_ticket(title="Broken scanner", name=8002)
    posted_messages: list[object] = []
    set_error_calls: list[str] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            post_message=posted_messages.append,
            set_activities_error=lambda: set_error_calls.append("error"),
            set_ticket_activities=lambda activities: None,
        ),
    )

    async def fake_list_ticket_activities(current_ticket: Ticket) -> list[TicketActivity]:
        assert current_ticket == ticket
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "list_ticket_activities", fake_list_ticket_activities)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_activity_load_generation = 2

    await app._load_ticket_activities(detail_screen, ticket, 1)

    assert posted_messages == []
    assert set_error_calls == []


@pytest.mark.asyncio
async def test_app_load_ticket_activities_posts_error_for_mounted_detail_screen(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    ticket = make_ticket(title="Broken scanner", name=8003)
    posted_messages: list[TicketDetail.StatusRequested] = []
    set_error_calls: list[str] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            post_message=posted_messages.append,
            set_activities_error=lambda: set_error_calls.append("error"),
            set_ticket_activities=lambda activities: None,
        ),
    )

    async def fake_list_ticket_activities(current_ticket: Ticket) -> list[TicketActivity]:
        assert current_ticket == ticket
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "list_ticket_activities", fake_list_ticket_activities)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_activity_load_generation = 1

    await app._load_ticket_activities(detail_screen, ticket, 1)

    assert set_error_calls == ["error"]
    assert len(posted_messages) == 1
    assert posted_messages[0].text == "Error loading ticket activities: boom"
    assert posted_messages[0].error is True


@pytest.mark.asyncio
async def test_app_load_ticket_activities_updates_mounted_detail_screen(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    ticket = make_ticket(title="Broken scanner", name=8004)
    updated_activities: list[list[TicketActivity]] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            post_message=lambda message: None,
            set_ticket_activities=updated_activities.append,
        ),
    )
    activities = [make_activity(title="Fwd: test")]

    async def fake_list_ticket_activities(current_ticket: Ticket) -> list[TicketActivity]:
        assert current_ticket == ticket
        return activities

    monkeypatch.setattr(app.connector, "list_ticket_activities", fake_list_ticket_activities)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_activity_load_generation = 1

    await app._load_ticket_activities(detail_screen, ticket, 1)

    assert updated_activities == [activities]


@pytest.mark.asyncio
async def test_app_load_ticket_statuses_updates_mounted_detail_screen(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    updated_statuses: list[tuple[str, list[TicketStatusOption]]] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            post_message=lambda message: None,
            set_ticket_statuses=lambda category_name, options: updated_statuses.append(
                (category_name, options)
            ),
        ),
    )
    status_options = [TicketStatusOption(name="status_dispatch", title="Dispatch")]

    async def fake_list_ticket_statuses(category_name: str) -> list[TicketStatusOption]:
        assert category_name == "delivery"
        return status_options

    monkeypatch.setattr(app.connector, "list_ticket_statuses", fake_list_ticket_statuses)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_status_load_generation = 1

    await app._load_ticket_statuses(detail_screen, "delivery", 1)

    assert app._ticket_status_options_by_category == {"delivery": status_options}
    assert updated_statuses == [("delivery", status_options)]


@pytest.mark.asyncio
async def test_app_store_ticket_propagates_cancellation(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=8004)
    app = DaktelaPaleoApp(
        initial_state=AppState(tickets=[ticket], active_ticket=ticket),
        connector=MockTicketConnector(),
    )
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            cancel_close_after_save=lambda: None,
            consume_close_after_save=lambda: False,
            sync_ticket=lambda saved_ticket: None,
        ),
    )

    async def fake_store_ticket(
        current_ticket: Ticket,
        patch: TicketEditPatch,
    ) -> Ticket:
        raise asyncio.CancelledError()

    monkeypatch.setattr(app.connector, "store_ticket", fake_store_ticket)
    app._ticket_save_generation = 1

    with pytest.raises(asyncio.CancelledError):
        await app._store_ticket(detail_screen, ticket, TicketEditPatch(title="Updated"), 1)


@pytest.mark.asyncio
async def test_app_store_ticket_ignores_stale_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=8005)
    app = DaktelaPaleoApp(
        initial_state=AppState(tickets=[ticket], active_ticket=ticket),
        connector=MockTicketConnector(),
    )
    cancel_calls: list[str] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            cancel_close_after_save=lambda: cancel_calls.append("cancel"),
            consume_close_after_save=lambda: False,
            sync_ticket=lambda saved_ticket: None,
        ),
    )

    async def fake_store_ticket(
        current_ticket: Ticket,
        patch: TicketEditPatch,
    ) -> Ticket:
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "store_ticket", fake_store_ticket)
    app._ticket_save_generation = 2
    cast(Any, app).loading_message = "Saving ticket: Broken scanner"

    await app._store_ticket(detail_screen, ticket, TicketEditPatch(title="Updated"), 1)

    assert cancel_calls == []
    assert app.loading_message == "Saving ticket: Broken scanner"
    assert app.error_message is None


@pytest.mark.asyncio
async def test_app_store_ticket_ignores_stale_success(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=8006)
    app = DaktelaPaleoApp(
        initial_state=AppState(tickets=[ticket], active_ticket=ticket),
        connector=MockTicketConnector(),
    )
    sync_calls: list[Ticket] = []
    consume_calls: list[str] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            cancel_close_after_save=lambda: None,
            consume_close_after_save=lambda: consume_calls.append("consume") or False,
            sync_ticket=sync_calls.append,
        ),
    )

    async def fake_store_ticket(
        current_ticket: Ticket,
        patch: TicketEditPatch,
    ) -> Ticket:
        return patch.apply_to(current_ticket)

    monkeypatch.setattr(app.connector, "store_ticket", fake_store_ticket)
    app._ticket_save_generation = 2
    cast(Any, app).loading_message = "Saving ticket: Broken scanner"

    await app._store_ticket(detail_screen, ticket, TicketEditPatch(title="Updated"), 1)

    assert app.app_state.active_ticket == ticket
    assert sync_calls == []
    assert consume_calls == []
    assert app.loading_message == "Saving ticket: Broken scanner"


@pytest.mark.asyncio
async def test_app_load_tickets_for_view_ignores_stale_generation_after_view_reload(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    view = TicketView(title="Original", name="original", ticket_count=1)
    refreshed_view = TicketView(title="Original", name="original", ticket_count=3)
    app = DaktelaPaleoApp(
        initial_state=AppState(views=[view], active_view=view),
        connector=MockTicketConnector(),
    )
    list_tickets_calls: list[TicketView] = []

    async def fake_list_views() -> list[TicketView]:
        app._ticket_load_generation = 2
        return [refreshed_view]

    async def fake_list_tickets(current_view: TicketView | None = None) -> list[Ticket]:
        assert current_view is not None
        list_tickets_calls.append(current_view)
        return []

    monkeypatch.setattr(app.connector, "list_views", fake_list_views)
    monkeypatch.setattr(app.connector, "list_tickets", fake_list_tickets)
    monkeypatch.setattr(DaktelaPaleoApp, "watch_app_state", lambda self, app_state: None)
    app._ticket_load_generation = 1

    await app._load_tickets_for_view(view, 1, reload_views_metadata=True)

    assert list_tickets_calls == []
    assert app.app_state.views == [refreshed_view]
    assert app.app_state.active_view == refreshed_view


@pytest.mark.asyncio
async def test_app_load_tickets_for_view_uses_refreshed_view_metadata_for_ticket_page_load(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    view = TicketView(
        title="Original",
        name="original",
        ticket_count=1,
        sort={"field": "created", "dir": "asc"},
    )
    refreshed_view = TicketView(
        title="Original",
        name="original",
        ticket_count=3,
        sort={"field": "edited", "dir": "desc"},
    )
    refreshed_ticket = make_ticket(title="Refreshed", name=8010)
    app = DaktelaPaleoApp(
        initial_state=AppState(views=[view], active_view=view),
        connector=MockTicketConnector(),
    )
    list_ticket_page_calls: list[tuple[TicketView, int]] = []

    async def fake_list_views() -> list[TicketView]:
        return [refreshed_view]

    async def fake_list_ticket_page(
        current_view: TicketView | None = None,
        *,
        page: int = 1,
    ) -> TicketPage:
        assert current_view is not None
        list_ticket_page_calls.append((current_view, page))
        return TicketPage(
            tickets=[refreshed_ticket],
            pagination=TicketPagination(current_page=2, total_pages=4, total_tickets=7),
        )

    monkeypatch.setattr(app.connector, "list_views", fake_list_views)
    monkeypatch.setattr(app.connector, "list_ticket_page", fake_list_ticket_page)
    monkeypatch.setattr(
        app,
        "query_one",
        lambda *args, **kwargs: (_ for _ in ()).throw(NoMatches("ticket list not mounted")),
    )
    app._ticket_load_generation = 1

    await app._load_tickets_for_view(view, 1, page=2, reload_views_metadata=True)

    assert list_ticket_page_calls == [(refreshed_view, 2)]
    assert app.app_state.views == [refreshed_view]
    assert app.app_state.active_view == refreshed_view
    assert app.app_state.tickets == [refreshed_ticket]
    assert app.app_state.ticket_pagination == TicketPagination(
        current_page=2,
        total_pages=4,
        total_tickets=7,
    )


@pytest.mark.asyncio
async def test_app_create_ticket_comment_propagates_cancellation(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=8007)
    app = DaktelaPaleoApp(
        initial_state=AppState(tickets=[ticket], active_ticket=ticket),
        connector=MockTicketConnector(),
    )
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            handle_comment_submit_success=lambda: None,
            handle_comment_submit_failure=lambda _message: None,
        ),
    )

    async def fake_create_ticket_comment(
        current_ticket: Ticket,
        request: TicketCommentCreateRequest,
    ) -> None:
        assert current_ticket == ticket
        assert request == TicketCommentCreateRequest(body="Internal note")
        raise asyncio.CancelledError()

    monkeypatch.setattr(app.connector, "create_ticket_comment", fake_create_ticket_comment)
    app._ticket_comment_generation = 1

    with pytest.raises(asyncio.CancelledError):
        await app._create_ticket_comment(
            detail_screen,
            ticket,
            TicketCommentCreateRequest(body="Internal note"),
            (),
            1,
        )


@pytest.mark.asyncio
async def test_app_create_ticket_comment_ignores_stale_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=8008)
    app = DaktelaPaleoApp(
        initial_state=AppState(tickets=[ticket], active_ticket=ticket),
        connector=MockTicketConnector(),
    )
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            handle_comment_submit_success=lambda: None,
            handle_comment_submit_failure=lambda _message: None,
        ),
    )

    async def fake_create_ticket_comment(
        current_ticket: Ticket,
        request: TicketCommentCreateRequest,
    ) -> None:
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "create_ticket_comment", fake_create_ticket_comment)
    app._ticket_comment_generation = 2
    cast(Any, app).loading_message = "Adding comment: Broken scanner"

    await app._create_ticket_comment(
        detail_screen,
        ticket,
        TicketCommentCreateRequest(body="Internal note"),
        (),
        1,
    )

    assert app.loading_message == "Adding comment: Broken scanner"
    assert app.error_message is None
    assert app.notice_message is None


@pytest.mark.asyncio
async def test_app_create_ticket_comment_ignores_stale_success(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=8009)
    app = DaktelaPaleoApp(
        initial_state=AppState(tickets=[ticket], active_ticket=ticket),
        connector=MockTicketConnector(),
    )
    success_calls: list[str] = []
    failure_calls: list[str] = []
    begin_reload_calls: list[tuple[object, Ticket]] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            handle_comment_submit_success=lambda: success_calls.append("success"),
            handle_comment_submit_failure=lambda message: failure_calls.append(message),
        ),
    )

    async def fake_create_ticket_comment(
        current_ticket: Ticket,
        request: TicketCommentCreateRequest,
    ) -> None:
        return None

    monkeypatch.setattr(app.connector, "create_ticket_comment", fake_create_ticket_comment)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    monkeypatch.setattr(
        app,
        "_begin_ticket_activity_load",
        lambda current_screen, current_ticket: begin_reload_calls.append((current_screen, current_ticket)),
    )
    app._ticket_comment_generation = 2
    cast(Any, app).loading_message = "Adding comment: Broken scanner"

    await app._create_ticket_comment(
        detail_screen,
        ticket,
        TicketCommentCreateRequest(body="Internal note"),
        (),
        1,
    )

    assert success_calls == []
    assert failure_calls == []
    assert begin_reload_calls == []
    assert app.loading_message == "Adding comment: Broken scanner"
    assert app.notice_message is None


@pytest.mark.asyncio
async def test_app_create_ticket_comment_sets_error_without_refresh(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=8010)
    app = DaktelaPaleoApp(
        initial_state=AppState(tickets=[ticket], active_ticket=ticket),
        connector=MockTicketConnector(),
    )
    success_calls: list[str] = []
    failure_calls: list[str] = []
    begin_reload_calls: list[tuple[object, Ticket]] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            handle_comment_submit_success=lambda: success_calls.append("success"),
            handle_comment_submit_failure=lambda message: failure_calls.append(message),
        ),
    )

    async def fake_create_ticket_comment(
        current_ticket: Ticket,
        request: TicketCommentCreateRequest,
    ) -> None:
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "create_ticket_comment", fake_create_ticket_comment)
    monkeypatch.setattr(
        app,
        "_begin_ticket_activity_load",
        lambda current_screen, current_ticket: begin_reload_calls.append((current_screen, current_ticket)),
    )
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_comment_generation = 1

    await app._create_ticket_comment(
        detail_screen,
        ticket,
        TicketCommentCreateRequest(body="Internal note"),
        (),
        1,
    )

    assert success_calls == []
    assert failure_calls == ["Error adding comment: boom"]
    assert begin_reload_calls == []
    assert app.loading_message is None
    assert app.error_message == "Error adding comment: boom"
    assert app.notice_message is None


@pytest.mark.asyncio
async def test_app_create_ticket_comment_refreshes_activities_on_success(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=8011)
    app = DaktelaPaleoApp(
        initial_state=AppState(tickets=[ticket], active_ticket=ticket),
        connector=MockTicketConnector(),
    )
    success_calls: list[str] = []
    failure_calls: list[str] = []
    begin_reload_calls: list[tuple[object, Ticket]] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            handle_comment_submit_success=lambda: success_calls.append("success"),
            handle_comment_submit_failure=lambda message: failure_calls.append(message),
        ),
    )

    async def fake_create_ticket_comment(
        current_ticket: Ticket,
        request: TicketCommentCreateRequest,
    ) -> None:
        assert current_ticket == ticket
        assert request == TicketCommentCreateRequest(body="Internal note")
        return None

    monkeypatch.setattr(app.connector, "create_ticket_comment", fake_create_ticket_comment)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    monkeypatch.setattr(
        app,
        "_begin_ticket_activity_load",
        lambda current_screen, current_ticket: begin_reload_calls.append((current_screen, current_ticket)),
    )
    app._ticket_comment_generation = 1

    await app._create_ticket_comment(
        detail_screen,
        ticket,
        TicketCommentCreateRequest(body="Internal note"),
        (),
        1,
    )

    assert success_calls == ["success"]
    assert failure_calls == []
    assert begin_reload_calls == [(detail_screen, ticket)]
    assert app.loading_message is None
    assert app.error_message is None
    assert app.notice_message == "Added comment: Broken scanner"


@pytest.mark.asyncio
async def test_app_load_ticket_email_draft_propagates_cancellation(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=8012)
    activity = make_activity(title="Customer replied", direction="in")
    app = DaktelaPaleoApp(
        initial_state=AppState(tickets=[ticket], active_ticket=ticket),
        connector=MockTicketConnector(),
    )
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            handle_email_draft_loaded=lambda _draft: None,
            handle_email_draft_failure=lambda: None,
        ),
    )

    async def fake_get_ticket_email_draft(
        current_ticket: Ticket,
        current_activity: TicketActivity,
        action: TicketEmailAction,
    ) -> TicketEmailDraft:
        assert current_ticket == ticket
        assert current_activity == activity
        assert action is TicketEmailAction.REPLY
        raise asyncio.CancelledError()

    monkeypatch.setattr(app.connector, "get_ticket_email_draft", fake_get_ticket_email_draft)
    app._ticket_email_draft_generation = 1

    with pytest.raises(asyncio.CancelledError):
        await app._load_ticket_email_draft(detail_screen, ticket, activity, TicketEmailAction.REPLY, 1)


@pytest.mark.asyncio
async def test_app_load_ticket_email_draft_ignores_stale_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=8013)
    activity = make_activity(title="Customer replied", direction="in")
    app = DaktelaPaleoApp(
        initial_state=AppState(tickets=[ticket], active_ticket=ticket),
        connector=MockTicketConnector(),
    )
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            handle_email_draft_loaded=lambda _draft: None,
            handle_email_draft_failure=lambda: None,
        ),
    )

    async def fake_get_ticket_email_draft(
        _ticket: Ticket,
        _activity: TicketActivity,
        _action: TicketEmailAction,
    ) -> TicketEmailDraft:
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "get_ticket_email_draft", fake_get_ticket_email_draft)
    app._ticket_email_draft_generation = 2
    cast(Any, app).loading_message = "Loading email draft: Broken scanner"

    await app._load_ticket_email_draft(detail_screen, ticket, activity, TicketEmailAction.REPLY, 1)

    assert app.loading_message == "Loading email draft: Broken scanner"
    assert app.error_message is None
    assert app.notice_message is None


@pytest.mark.asyncio
async def test_app_load_ticket_email_draft_sets_error_and_restores_detail_screen(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=8014)
    activity = make_activity(title="Customer replied", direction="in")
    app = DaktelaPaleoApp(
        initial_state=AppState(tickets=[ticket], active_ticket=ticket),
        connector=MockTicketConnector(),
    )
    loaded_drafts: list[TicketEmailDraft] = []
    failure_calls: list[str] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            handle_email_draft_loaded=lambda draft: loaded_drafts.append(draft),
            handle_email_draft_failure=lambda: failure_calls.append("failure"),
        ),
    )

    async def fake_get_ticket_email_draft(
        _ticket: Ticket,
        _activity: TicketActivity,
        _action: TicketEmailAction,
    ) -> TicketEmailDraft:
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "get_ticket_email_draft", fake_get_ticket_email_draft)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_email_draft_generation = 1

    await app._load_ticket_email_draft(detail_screen, ticket, activity, TicketEmailAction.REPLY, 1)

    assert loaded_drafts == []
    assert failure_calls == ["failure"]
    assert app.loading_message is None
    assert app.error_message == "Error loading email draft: boom"
    assert app.notice_message is None


@pytest.mark.asyncio
async def test_app_load_ticket_email_draft_opens_loaded_draft(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=8015)
    activity = make_activity(title="Customer replied", direction="in")
    draft = TicketEmailDraft(
        action=TicketEmailAction.REPLY,
        source_activity_name=activity.name,
        source_email_name="emails_1",
        to="customer@example.com",
        subject="Re: Broken scanner",
        body="Draft reply",
        queue_name="support",
    )
    app = DaktelaPaleoApp(
        initial_state=AppState(tickets=[ticket], active_ticket=ticket),
        connector=MockTicketConnector(),
    )
    loaded_drafts: list[TicketEmailDraft] = []
    failure_calls: list[str] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            handle_email_draft_loaded=lambda current_draft: loaded_drafts.append(current_draft),
            handle_email_draft_failure=lambda: failure_calls.append("failure"),
        ),
    )

    async def fake_get_ticket_email_draft(
        current_ticket: Ticket,
        current_activity: TicketActivity,
        action: TicketEmailAction,
    ) -> TicketEmailDraft:
        assert current_ticket == ticket
        assert current_activity == activity
        assert action is TicketEmailAction.REPLY
        return draft

    monkeypatch.setattr(app.connector, "get_ticket_email_draft", fake_get_ticket_email_draft)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_email_draft_generation = 1

    await app._load_ticket_email_draft(detail_screen, ticket, activity, TicketEmailAction.REPLY, 1)

    assert loaded_drafts == [draft]
    assert failure_calls == []
    assert app.loading_message is None
    assert app.error_message is None
    assert app.notice_message is None


def test_app_handle_ticket_detail_email_send_requested_starts_worker(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=8015)
    request = TicketEmailSendRequest(
        action=TicketEmailAction.REPLY,
        source_email_name="emails_1",
        to="customer@example.com",
        subject="Re: Broken scanner",
        body="Draft reply",
        queue_name="support",
    )
    app = DaktelaPaleoApp(
        initial_state=AppState(tickets=[ticket], active_ticket=ticket),
        connector=MockTicketConnector(),
    )
    run_worker_calls: list[dict[str, object]] = []
    monkeypatch.setattr(
        app,
        "run_worker",
        lambda coro, **kwargs: run_worker_calls.append({"coro": coro, **kwargs}),
    )

    message = TicketDetail.EmailSendRequested(
        cast(TicketDetail, SimpleNamespace()),
        ticket,
        request,
    )

    app.handle_ticket_detail_email_send_requested(message)

    assert app._ticket_email_send_generation == 1
    assert app.loading_message == "Sending email: Broken scanner"
    assert app.error_message is None
    assert app.notice_message is None
    assert len(run_worker_calls) == 1
    run_worker_calls[0]["coro"].close()  # type: ignore[index, union-attr]
    assert run_worker_calls[0]["name"] == "send-ticket-email"
    assert run_worker_calls[0]["group"] == "ticket-email-send"


@pytest.mark.asyncio
async def test_app_load_ticket_email_draft_without_connector_restores_screen(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=8015)
    activity = make_activity(title="Customer replied", direction="in")
    app = DaktelaPaleoApp(
        initial_state=AppState(tickets=[ticket], active_ticket=ticket),
        connector=None,
    )
    app.connector = None
    failure_calls: list[str] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            handle_email_draft_failure=lambda: failure_calls.append("failure"),
        ),
    )

    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())

    await app._load_ticket_email_draft(detail_screen, ticket, activity, TicketEmailAction.REPLY, 1)

    assert failure_calls == ["failure"]
    assert app.loading_message is None
    assert app.error_message == "No connector is active."
    assert app.notice_message is None


@pytest.mark.asyncio
async def test_app_load_ticket_email_draft_ignores_stale_success(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=8015)
    activity = make_activity(title="Customer replied", direction="in")
    draft = TicketEmailDraft(
        action=TicketEmailAction.REPLY,
        source_activity_name=activity.name,
        source_email_name="emails_1",
        to="customer@example.com",
        subject="Re: Broken scanner",
        body="Draft reply",
        queue_name="support",
    )
    app = DaktelaPaleoApp(
        initial_state=AppState(tickets=[ticket], active_ticket=ticket),
        connector=MockTicketConnector(),
    )
    loaded_drafts: list[TicketEmailDraft] = []
    failure_calls: list[str] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            handle_email_draft_loaded=lambda current_draft: loaded_drafts.append(current_draft),
            handle_email_draft_failure=lambda: failure_calls.append("failure"),
        ),
    )

    async def fake_get_ticket_email_draft(
        _ticket: Ticket,
        _activity: TicketActivity,
        _action: TicketEmailAction,
    ) -> TicketEmailDraft:
        app._ticket_email_draft_generation = 2
        return draft

    monkeypatch.setattr(app.connector, "get_ticket_email_draft", fake_get_ticket_email_draft)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_email_draft_generation = 1
    cast(Any, app).loading_message = "Loading email draft: Broken scanner"

    await app._load_ticket_email_draft(detail_screen, ticket, activity, TicketEmailAction.REPLY, 1)

    assert loaded_drafts == []
    assert failure_calls == []
    assert app.loading_message == "Loading email draft: Broken scanner"
    assert app.notice_message is None


@pytest.mark.asyncio
async def test_app_send_ticket_email_propagates_cancellation(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=8016)
    request = TicketEmailSendRequest(
        action=TicketEmailAction.REPLY,
        source_email_name="emails_1",
        to="customer@example.com",
        subject="Re: Broken scanner",
        body="Draft reply",
        queue_name="support",
    )
    app = DaktelaPaleoApp(
        initial_state=AppState(tickets=[ticket], active_ticket=ticket),
        connector=MockTicketConnector(),
    )
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            handle_email_submit_success=lambda: None,
            handle_email_submit_failure=lambda _message: None,
        ),
    )

    async def fake_send_ticket_email(current_ticket: Ticket, current_request: TicketEmailSendRequest) -> None:
        assert current_ticket == ticket
        assert current_request == request
        raise asyncio.CancelledError()

    monkeypatch.setattr(app.connector, "send_ticket_email", fake_send_ticket_email)
    app._ticket_email_send_generation = 1

    with pytest.raises(asyncio.CancelledError):
        await app._send_ticket_email(detail_screen, ticket, request, 1)


@pytest.mark.asyncio
async def test_app_send_ticket_email_ignores_stale_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=8017)
    request = TicketEmailSendRequest(
        action=TicketEmailAction.REPLY,
        source_email_name="emails_1",
        to="customer@example.com",
        subject="Re: Broken scanner",
        body="Draft reply",
        queue_name="support",
    )
    app = DaktelaPaleoApp(
        initial_state=AppState(tickets=[ticket], active_ticket=ticket),
        connector=MockTicketConnector(),
    )
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            handle_email_submit_success=lambda: None,
            handle_email_submit_failure=lambda _message: None,
        ),
    )

    async def fake_send_ticket_email(_ticket: Ticket, _request: TicketEmailSendRequest) -> None:
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "send_ticket_email", fake_send_ticket_email)
    app._ticket_email_send_generation = 2
    cast(Any, app).loading_message = "Sending email: Broken scanner"

    await app._send_ticket_email(detail_screen, ticket, request, 1)

    assert app.loading_message == "Sending email: Broken scanner"
    assert app.error_message is None
    assert app.notice_message is None


@pytest.mark.asyncio
async def test_app_send_ticket_email_sets_error_without_refresh(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=8018)
    request = TicketEmailSendRequest(
        action=TicketEmailAction.REPLY,
        source_email_name="emails_1",
        to="customer@example.com",
        subject="Re: Broken scanner",
        body="Draft reply",
        queue_name="support",
    )
    app = DaktelaPaleoApp(
        initial_state=AppState(tickets=[ticket], active_ticket=ticket),
        connector=MockTicketConnector(),
    )
    success_calls: list[str] = []
    failure_calls: list[str] = []
    begin_reload_calls: list[tuple[object, Ticket]] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            handle_email_submit_success=lambda: success_calls.append("success"),
            handle_email_submit_failure=lambda message: failure_calls.append(message),
        ),
    )

    async def fake_send_ticket_email(_ticket: Ticket, _request: TicketEmailSendRequest) -> None:
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "send_ticket_email", fake_send_ticket_email)
    monkeypatch.setattr(
        app,
        "_begin_ticket_activity_load",
        lambda current_screen, current_ticket: begin_reload_calls.append((current_screen, current_ticket)),
    )
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_email_send_generation = 1

    await app._send_ticket_email(detail_screen, ticket, request, 1)

    assert success_calls == []
    assert failure_calls == ["Error sending email: boom"]
    assert begin_reload_calls == []
    assert app.loading_message is None
    assert app.error_message == "Error sending email: boom"
    assert app.notice_message is None


@pytest.mark.asyncio
async def test_app_send_ticket_email_refreshes_activities_on_success(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=8019)
    request = TicketEmailSendRequest(
        action=TicketEmailAction.REPLY,
        source_email_name="emails_1",
        to="customer@example.com",
        subject="Re: Broken scanner",
        body="Draft reply",
        queue_name="support",
    )
    app = DaktelaPaleoApp(
        initial_state=AppState(tickets=[ticket], active_ticket=ticket),
        connector=MockTicketConnector(),
    )
    success_calls: list[str] = []
    failure_calls: list[str] = []
    begin_reload_calls: list[tuple[object, Ticket]] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            handle_email_submit_success=lambda: success_calls.append("success"),
            handle_email_submit_failure=lambda message: failure_calls.append(message),
        ),
    )

    async def fake_send_ticket_email(current_ticket: Ticket, current_request: TicketEmailSendRequest) -> None:
        assert current_ticket == ticket
        assert current_request == request
        return None

    monkeypatch.setattr(app.connector, "send_ticket_email", fake_send_ticket_email)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    monkeypatch.setattr(
        app,
        "_begin_ticket_activity_load",
        lambda current_screen, current_ticket: begin_reload_calls.append((current_screen, current_ticket)),
    )
    app._ticket_email_send_generation = 1

    await app._send_ticket_email(detail_screen, ticket, request, 1)

    assert success_calls == ["success"]
    assert failure_calls == []
    assert begin_reload_calls == [(detail_screen, ticket)]
    assert app.loading_message is None
    assert app.error_message is None
    assert app.notice_message == "Sent email: Broken scanner"


@pytest.mark.asyncio
async def test_app_send_ticket_email_without_connector_restores_screen(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=8020)
    request = TicketEmailSendRequest(
        action=TicketEmailAction.REPLY,
        source_email_name="emails_1",
        to="customer@example.com",
        subject="Re: Broken scanner",
        body="Draft reply",
        queue_name="support",
    )
    app = DaktelaPaleoApp(
        initial_state=AppState(tickets=[ticket], active_ticket=ticket),
        connector=None,
    )
    app.connector = None
    failure_calls: list[str] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            handle_email_submit_failure=lambda message: failure_calls.append(message),
        ),
    )

    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())

    await app._send_ticket_email(detail_screen, ticket, request, 1)

    assert failure_calls == ["No connector is active."]
    assert app.loading_message is None
    assert app.error_message == "No connector is active."
    assert app.notice_message is None


@pytest.mark.asyncio
async def test_app_send_ticket_email_ignores_stale_success(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=8021)
    request = TicketEmailSendRequest(
        action=TicketEmailAction.REPLY,
        source_email_name="emails_1",
        to="customer@example.com",
        subject="Re: Broken scanner",
        body="Draft reply",
        queue_name="support",
    )
    app = DaktelaPaleoApp(
        initial_state=AppState(tickets=[ticket], active_ticket=ticket),
        connector=MockTicketConnector(),
    )
    success_calls: list[str] = []
    failure_calls: list[str] = []
    begin_reload_calls: list[tuple[object, Ticket]] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            handle_email_submit_success=lambda: success_calls.append("success"),
            handle_email_submit_failure=lambda message: failure_calls.append(message),
        ),
    )

    async def fake_send_ticket_email(_ticket: Ticket, _request: TicketEmailSendRequest) -> None:
        app._ticket_email_send_generation = 2
        return None

    monkeypatch.setattr(app.connector, "send_ticket_email", fake_send_ticket_email)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    monkeypatch.setattr(
        app,
        "_begin_ticket_activity_load",
        lambda current_screen, current_ticket: begin_reload_calls.append((current_screen, current_ticket)),
    )
    app._ticket_email_send_generation = 1
    cast(Any, app).loading_message = "Sending email: Broken scanner"

    await app._send_ticket_email(detail_screen, ticket, request, 1)

    assert success_calls == []
    assert failure_calls == []
    assert begin_reload_calls == []
    assert app.loading_message == "Sending email: Broken scanner"
    assert app.notice_message is None


def test_app_helper_methods_cover_connector_and_ticket_identity() -> None:
    anonymous_ticket = Ticket(
        title="Anonymous",
        category="delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )
    tracked_ticket = Ticket(
        ticket=77,
        title="Tracked",
        category="delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )

    app = DaktelaPaleoApp(connector=MockTicketConnector())
    app.instance_config = DaktelaInstanceConfig(
        active_instance_id="saved",
        instances=[
            DaktelaInstanceRecord(
                id="saved",
                base_url="https://demo.daktela.com",
                user_token="token-123",
            )
        ],
    )
    app.active_instance = app.instance_config.active_instance()

    assert isinstance(app._create_active_instance_connector(), DaktelaTicketConnector)
    assert DaktelaPaleoApp._view_key(None) is None
    assert DaktelaPaleoApp._ticket_key(tracked_ticket) == ("ticket", "77")
    assert DaktelaPaleoApp._ticket_key(anonymous_ticket) is None
    assert DaktelaPaleoApp._tickets_match(
        anonymous_ticket,
        anonymous_ticket.model_copy(deep=True),
    ) is True


def test_begin_current_user_load_returns_early_when_app_is_not_running(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()

    def fail_if_called(*args: object, **kwargs: object) -> None:
        raise AssertionError("run_worker should not be called when the app is stopped")

    monkeypatch.setattr(DaktelaPaleoApp, "is_running", property(lambda self: False))
    monkeypatch.setattr(app, "run_worker", fail_if_called)

    app._begin_current_user_load()


def test_begin_current_user_load_reuses_cached_user_for_mounted_detail_screen(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    cached_user = TicketUserOption(name="operator_2", title="Operator Two")
    updates: list[TicketUserOption | None] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            set_current_user=updates.append,
        ),
    )

    def fail_if_called(*args: object, **kwargs: object) -> None:
        raise AssertionError("run_worker should not be called when the user is cached")

    monkeypatch.setattr(DaktelaPaleoApp, "is_running", property(lambda self: True))
    monkeypatch.setattr(app, "run_worker", fail_if_called)
    app._current_ticket_user = cached_user

    app._begin_current_user_load(detail_screen)

    assert updates == [cached_user]


def test_begin_current_user_load_returns_early_without_active_connector(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = DaktelaPaleoApp(instance_store=make_instance_store(tmp_path))

    def fail_if_called(*args: object, **kwargs: object) -> None:
        raise AssertionError("run_worker should not be called without an active connector")

    monkeypatch.setattr(DaktelaPaleoApp, "is_running", property(lambda self: True))
    monkeypatch.setattr(app, "run_worker", fail_if_called)

    app._begin_current_user_load()


def test_ticket_detail_status_options_requested_ignores_non_detail_screen(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()

    def fail_if_called(*args: object, **kwargs: object) -> None:
        raise AssertionError("status loading should not start outside ticket detail")

    monkeypatch.setattr(DaktelaPaleoApp, "screen", property(lambda self: object()))
    monkeypatch.setattr(app, "_begin_ticket_status_load", fail_if_called)

    app.handle_ticket_detail_status_options_requested(
        cast(Any, SimpleNamespace(category_name="categories_delivery"))
    )


def test_ticket_detail_status_options_requested_reuses_cached_statuses(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    cached_statuses = [TicketStatusOption(name="status_dispatch", title="Dispatch")]
    updates: list[tuple[str, list[TicketStatusOption]]] = []
    detail_screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")

    def fail_if_called(*args: object, **kwargs: object) -> None:
        raise AssertionError("cached status options should bypass loading")

    monkeypatch.setattr(DaktelaPaleoApp, "screen", property(lambda self: detail_screen))
    monkeypatch.setattr(app, "_begin_ticket_status_load", fail_if_called)
    monkeypatch.setattr(
        detail_screen,
        "set_ticket_statuses",
        lambda category_name, options: updates.append((category_name, options)),
    )
    app._ticket_status_options_by_category["categories_delivery"] = cached_statuses

    app.handle_ticket_detail_status_options_requested(
        cast(Any, SimpleNamespace(category_name="categories_delivery"))
    )

    assert updates == [("categories_delivery", cached_statuses)]


def test_open_in_browser_requested_reports_browser_exception(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    ticket = make_ticket(title="Broken scanner", name=2001)

    monkeypatch.setattr(app.connector, "ticket_browser_url", lambda opened_ticket: "https://example.test")

    def raise_browser_error(url: str) -> bool:
        raise RuntimeError("boom")

    monkeypatch.setattr(app_module.webbrowser, "open", raise_browser_error)

    app.handle_ticket_detail_open_in_browser_requested(cast(Any, SimpleNamespace(ticket=ticket)))

    assert app.notice_message is None
    assert app.error_message == "Error opening ticket in browser: boom"


def test_open_view_in_browser_requested_reports_missing_selected_view() -> None:
    app = make_demo_app()

    app.handle_ticket_list_open_in_browser_requested(
        cast(Any, SimpleNamespace(view=None))
    )

    assert app.notice_message is None
    assert app.error_message == "View browser URL is not available without a selected view."


def test_open_view_in_browser_requested_reports_browser_exception(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    view = make_ticket_view(title="Returns", name="views_returns")

    monkeypatch.setattr(app.connector, "view_browser_url", lambda opened_view: "https://example.test")

    def raise_browser_error(url: str) -> bool:
        raise RuntimeError("boom")

    monkeypatch.setattr(app_module.webbrowser, "open", raise_browser_error)

    app.handle_ticket_list_open_in_browser_requested(cast(Any, SimpleNamespace(view=view)))

    assert app.notice_message is None
    assert app.error_message == "Error opening view in browser: boom"


def test_open_view_in_browser_requested_reports_missing_connector(tmp_path: Path) -> None:
    app = DaktelaPaleoApp(instance_store=make_instance_store(tmp_path))
    view = make_ticket_view(title="Returns", name="views_returns")

    app.handle_ticket_list_open_in_browser_requested(cast(Any, SimpleNamespace(view=view)))

    assert app.notice_message is None
    assert app.error_message == "View browser URL is not available without an active connector."


def test_open_view_in_browser_requested_reports_open_false(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    view = make_ticket_view(title="Returns", name="views_returns")

    monkeypatch.setattr(app.connector, "view_browser_url", lambda opened_view: "https://example.test")
    monkeypatch.setattr(app_module.webbrowser, "open", lambda url: False)

    app.handle_ticket_list_open_in_browser_requested(cast(Any, SimpleNamespace(view=view)))

    assert app.notice_message is None
    assert app.error_message == "Error opening view in browser."


def test_open_in_browser_requested_reports_missing_connector(tmp_path: Path) -> None:
    app = DaktelaPaleoApp(instance_store=make_instance_store(tmp_path))
    ticket = make_ticket(title="Broken scanner", name=2001)

    app.handle_ticket_detail_open_in_browser_requested(cast(Any, SimpleNamespace(ticket=ticket)))

    assert app.notice_message is None
    assert app.error_message == "Ticket browser URL is not available without an active connector."


def test_open_in_browser_requested_reports_open_false(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    ticket = make_ticket(title="Broken scanner", name=2001)

    monkeypatch.setattr(app.connector, "ticket_browser_url", lambda opened_ticket: "https://example.test")
    monkeypatch.setattr(app_module.webbrowser, "open", lambda url: False)

    app.handle_ticket_detail_open_in_browser_requested(cast(Any, SimpleNamespace(ticket=ticket)))

    assert app.notice_message is None
    assert app.error_message == "Error opening ticket in browser."


def test_open_activity_link_requested_sets_notice_on_success(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()

    monkeypatch.setattr(app_module.webbrowser, "open", lambda url: True)

    app.handle_ticket_detail_open_activity_link_requested(
        cast(Any, SimpleNamespace(url="https://example.test"))
    )

    assert app.error_message is None
    assert app.notice_message == "Opened link in browser."


def test_open_activity_link_requested_reports_browser_exception(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()

    def raise_browser_error(url: str) -> bool:
        raise RuntimeError("boom")

    monkeypatch.setattr(app_module.webbrowser, "open", raise_browser_error)

    app.handle_ticket_detail_open_activity_link_requested(
        cast(Any, SimpleNamespace(url="https://example.test"))
    )

    assert app.notice_message is None
    assert app.error_message == "Error opening link in browser: boom"


def test_open_activity_link_requested_reports_open_false(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()

    monkeypatch.setattr(app_module.webbrowser, "open", lambda url: False)

    app.handle_ticket_detail_open_activity_link_requested(
        cast(Any, SimpleNamespace(url="https://example.test"))
    )

    assert app.notice_message is None
    assert app.error_message == "Error opening link in browser."


@pytest.mark.asyncio
async def test_app_load_initial_state_ignores_current_user_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    view = TicketView(name="delivery", title="Delivery")
    tickets = [make_ticket(title="Loaded ticket", name=9100)]

    async def fake_list_views() -> list[TicketView]:
        return [view]

    async def fake_list_tickets(active_view: TicketView | None = None) -> list[Ticket]:
        assert active_view == view
        return tickets

    async def fake_get_current_user() -> TicketUserOption | None:
        raise RuntimeError("boom")

    app._initial_load_generation = 1
    app.connector.list_views = fake_list_views  # type: ignore[method-assign]
    app.connector.list_tickets = fake_list_tickets  # type: ignore[method-assign]
    app.connector.get_current_user = fake_get_current_user  # type: ignore[method-assign]
    monkeypatch.setattr(DaktelaPaleoApp, "watch_app_state", lambda self, app_state: None)

    await app._load_initial_state(1)

    assert app.app_state.views == [view]
    assert app.app_state.tickets == tickets
    assert app.app_state.active_view == view
    assert app._current_ticket_user is None


@pytest.mark.asyncio
async def test_app_load_initial_state_applies_loaded_ticket_grid_column_keys(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    view = TicketView(name="delivery", title="Delivery")
    tickets = [make_ticket(title="Loaded ticket", name=9100, user="Operator One")]

    async def fake_list_views() -> list[TicketView]:
        return [view]

    async def fake_list_tickets(active_view: TicketView | None = None) -> list[Ticket]:
        assert active_view == view
        return tickets

    async def fake_get_ticket_grid_column_keys() -> list[str] | None:
        return ["edited", "user.title"]

    app._initial_load_generation = 1
    app.connector.list_views = fake_list_views  # type: ignore[method-assign]
    app.connector.list_tickets = fake_list_tickets  # type: ignore[method-assign]
    app.connector.get_ticket_grid_column_keys = fake_get_ticket_grid_column_keys  # type: ignore[method-assign]
    monkeypatch.setattr(DaktelaPaleoApp, "watch_app_state", lambda self, app_state: None)

    await app._load_initial_state(1)

    assert app.app_state.ticket_grid_column_keys == [
        "name",
        "title",
        "edited",
        "user.title",
    ]


@pytest.mark.asyncio
async def test_app_load_initial_state_ignores_ticket_grid_column_loading_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    view = TicketView(name="delivery", title="Delivery")
    tickets = [make_ticket(title="Loaded ticket", name=9100)]

    async def fake_list_views() -> list[TicketView]:
        return [view]

    async def fake_list_tickets(active_view: TicketView | None = None) -> list[Ticket]:
        assert active_view == view
        return tickets

    async def fake_get_ticket_grid_column_keys() -> list[str] | None:
        raise RuntimeError("boom")

    app._initial_load_generation = 1
    app.connector.list_views = fake_list_views  # type: ignore[method-assign]
    app.connector.list_tickets = fake_list_tickets  # type: ignore[method-assign]
    app.connector.get_ticket_grid_column_keys = fake_get_ticket_grid_column_keys  # type: ignore[method-assign]
    monkeypatch.setattr(DaktelaPaleoApp, "watch_app_state", lambda self, app_state: None)

    await app._load_initial_state(1)

    assert app.app_state.ticket_grid_column_keys == list(TICKET_GRID_DEFAULT_COLUMN_KEYS)


@pytest.mark.asyncio
async def test_app_load_initial_state_uses_default_ticket_grid_column_order_for_unusable_loaded_values(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    view = TicketView(name="delivery", title="Delivery")
    tickets = [make_ticket(title="Loaded ticket", name=9100)]

    async def fake_list_views() -> list[TicketView]:
        return [view]

    async def fake_list_tickets(active_view: TicketView | None = None) -> list[Ticket]:
        assert active_view == view
        return tickets

    async def fake_get_ticket_grid_column_keys() -> list[str] | None:
        return ["first_answer_deadline", "created_by"]

    app._initial_load_generation = 1
    app.connector.list_views = fake_list_views  # type: ignore[method-assign]
    app.connector.list_tickets = fake_list_tickets  # type: ignore[method-assign]
    app.connector.get_ticket_grid_column_keys = fake_get_ticket_grid_column_keys  # type: ignore[method-assign]
    monkeypatch.setattr(DaktelaPaleoApp, "watch_app_state", lambda self, app_state: None)

    await app._load_initial_state(1)

    assert app.app_state.ticket_grid_column_keys == list(TICKET_GRID_DEFAULT_COLUMN_KEYS)


@pytest.mark.asyncio
async def test_app_load_initial_state_handles_unimplemented_ticket_loading(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    view = TicketView(name="delivery", title="Delivery")
    connector = ViewsOnlyConnector([view])
    app = DaktelaPaleoApp(connector=connector)

    async def fake_get_current_user() -> TicketUserOption | None:
        raise RuntimeError("boom")

    connector.get_current_user = fake_get_current_user  # type: ignore[method-assign]
    app._initial_load_generation = 1
    monkeypatch.setattr(DaktelaPaleoApp, "watch_app_state", lambda self, app_state: None)

    await app._load_initial_state(1)

    assert app.app_state.views == [view]
    assert app.app_state.tickets == []
    assert app.app_state.active_view == view
    assert app._current_ticket_user is None


@pytest.mark.asyncio
async def test_app_load_initial_state_uses_default_ticket_grid_column_order_when_connector_returns_none(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    view = TicketView(name="delivery", title="Delivery")
    connector = ViewsOnlyConnector([view])
    app = DaktelaPaleoApp(connector=connector)

    app._initial_load_generation = 1
    monkeypatch.setattr(DaktelaPaleoApp, "watch_app_state", lambda self, app_state: None)

    await app._load_initial_state(1)

    assert app.app_state.ticket_grid_column_keys == list(TICKET_GRID_DEFAULT_COLUMN_KEYS)


@pytest.mark.asyncio
async def test_app_load_current_user_ignores_current_generation_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()

    async def fake_get_current_user() -> TicketUserOption | None:
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "get_current_user", fake_get_current_user)
    app._ticket_current_user_load_generation = 1

    await app._load_current_user(None, 1)

    assert app._current_ticket_user is None


@pytest.mark.asyncio
async def test_disconnected_app_async_loader_helpers_return_early(
    tmp_path: Path,
) -> None:
    app = DaktelaPaleoApp(instance_store=make_instance_store(tmp_path))
    detail_screen = cast(TicketDetail, SimpleNamespace(is_mounted=True))
    ticket = make_ticket(title="Broken scanner", name=2001)
    view = TicketView(name="delivery", title="Delivery")

    await app._load_initial_state(1)
    await app._load_tickets_for_view(view, 1)
    await app._load_ticket_categories(detail_screen, 1)
    await app._load_ticket_users(detail_screen, 1)
    await app._load_current_user(detail_screen, 1)
    await app._load_ticket_activities(detail_screen, ticket, 1)
    await app._load_ticket_statuses(detail_screen, "categories_delivery", 1)

    assert app.app_state == AppState()
    assert app._current_ticket_user is None


@pytest.mark.asyncio
async def test_disconnected_app_store_ticket_reports_missing_connector(tmp_path: Path) -> None:
    app = DaktelaPaleoApp(instance_store=make_instance_store(tmp_path))
    ticket = make_ticket(title="Broken scanner", name=2001)
    cancel_calls: list[str] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(cancel_close_after_save=lambda: cancel_calls.append("cancel")),
    )

    await app._store_ticket(detail_screen, ticket, TicketEditPatch(title="Saved"), 1)

    assert cancel_calls == ["cancel"]
    assert app.loading_message is None
    assert app.error_message == "No connector is active."
    assert app.notice_message is None


@pytest.mark.asyncio
async def test_disconnected_app_create_ticket_comment_reports_missing_connector(
    tmp_path: Path,
) -> None:
    app = DaktelaPaleoApp(instance_store=make_instance_store(tmp_path))
    ticket = make_ticket(title="Broken scanner", name=2001)
    detail_screen = cast(TicketDetail, SimpleNamespace())

    await app._create_ticket_comment(
        detail_screen,
        ticket,
        TicketCommentCreateRequest(body="Internal note"),
        (),
        1,
    )

    assert app.loading_message is None
    assert app.error_message == "No connector is active."
    assert app.notice_message is None


@pytest.mark.asyncio
async def test_app_load_current_user_propagates_cancellation(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()

    async def fake_get_current_user() -> TicketUserOption | None:
        raise asyncio.CancelledError()

    monkeypatch.setattr(app.connector, "get_current_user", fake_get_current_user)
    app._ticket_current_user_load_generation = 1

    with pytest.raises(asyncio.CancelledError):
        await app._load_current_user(None, 1)


@pytest.mark.asyncio
async def test_app_load_current_user_ignores_stale_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()

    async def fake_get_current_user() -> TicketUserOption | None:
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "get_current_user", fake_get_current_user)
    app._ticket_current_user_load_generation = 2

    await app._load_current_user(None, 1)

    assert app._current_ticket_user is None


@pytest.mark.asyncio
async def test_app_load_current_user_ignores_stale_success(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    current_user = TicketUserOption(name="operator_2", title="Operator Two")
    updates: list[TicketUserOption | None] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            set_current_user=updates.append,
        ),
    )

    async def fake_get_current_user() -> TicketUserOption | None:
        return current_user

    monkeypatch.setattr(app.connector, "get_current_user", fake_get_current_user)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_current_user_load_generation = 2

    await app._load_current_user(detail_screen, 1)

    assert app._current_ticket_user is None
    assert updates == []


@pytest.mark.asyncio
async def test_app_load_current_user_updates_cache_without_detail_screen(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    current_user = TicketUserOption(name="operator_2", title="Operator Two")

    async def fake_get_current_user() -> TicketUserOption | None:
        return current_user

    monkeypatch.setattr(app.connector, "get_current_user", fake_get_current_user)
    app._ticket_current_user_load_generation = 1

    await app._load_current_user(None, 1)

    assert app._current_ticket_user == current_user


@pytest.mark.asyncio
async def test_app_load_ticket_activities_ignores_stale_success(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    ticket = make_ticket(title="Broken scanner", name=8005)
    updated_activities: list[list[TicketActivity]] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            post_message=lambda message: None,
            set_ticket_activities=updated_activities.append,
        ),
    )
    activities = [make_activity(title="Fwd: test")]

    async def fake_list_ticket_activities(current_ticket: Ticket) -> list[TicketActivity]:
        assert current_ticket == ticket
        return activities

    monkeypatch.setattr(app.connector, "list_ticket_activities", fake_list_ticket_activities)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_activity_load_generation = 2

    await app._load_ticket_activities(detail_screen, ticket, 1)

    assert updated_activities == []


@pytest.mark.asyncio
async def test_app_load_ticket_statuses_propagates_cancellation(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(is_mounted=True, post_message=lambda message: None),
    )

    async def fake_list_ticket_statuses(category_name: str) -> list[TicketStatusOption]:
        raise asyncio.CancelledError()

    monkeypatch.setattr(app.connector, "list_ticket_statuses", fake_list_ticket_statuses)
    app._ticket_status_load_generation = 1

    with pytest.raises(asyncio.CancelledError):
        await app._load_ticket_statuses(detail_screen, "delivery", 1)


@pytest.mark.asyncio
async def test_app_load_ticket_statuses_posts_error_for_mounted_detail_screen(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    posted_messages: list[TicketDetail.StatusRequested] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            post_message=posted_messages.append,
            set_ticket_statuses=lambda category_name, options: None,
        ),
    )

    async def fake_list_ticket_statuses(category_name: str) -> list[TicketStatusOption]:
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "list_ticket_statuses", fake_list_ticket_statuses)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_status_load_generation = 1

    await app._load_ticket_statuses(detail_screen, "delivery", 1)

    assert len(posted_messages) == 1
    assert posted_messages[0].text == "Error loading ticket statuses: boom"
    assert posted_messages[0].error is True


@pytest.mark.asyncio
async def test_app_load_ticket_statuses_ignores_unmounted_detail_screen_on_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    posted_messages: list[TicketDetail.StatusRequested] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=False,
            post_message=posted_messages.append,
            set_ticket_statuses=lambda category_name, options: None,
        ),
    )

    async def fake_list_ticket_statuses(category_name: str) -> list[TicketStatusOption]:
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "list_ticket_statuses", fake_list_ticket_statuses)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_status_load_generation = 1

    await app._load_ticket_statuses(detail_screen, "delivery", 1)

    assert posted_messages == []


@pytest.mark.asyncio
async def test_app_load_ticket_statuses_ignores_stale_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    posted_messages: list[TicketDetail.StatusRequested] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            post_message=posted_messages.append,
            set_ticket_statuses=lambda category_name, options: None,
        ),
    )

    async def fake_list_ticket_statuses(category_name: str) -> list[TicketStatusOption]:
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "list_ticket_statuses", fake_list_ticket_statuses)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_status_load_generation = 2

    await app._load_ticket_statuses(detail_screen, "delivery", 1)

    assert posted_messages == []


@pytest.mark.asyncio
async def test_app_load_ticket_statuses_ignores_stale_success(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    updated_statuses: list[tuple[str, list[TicketStatusOption]]] = []
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            is_mounted=True,
            post_message=lambda message: None,
            set_ticket_statuses=lambda category_name, options: updated_statuses.append(
                (category_name, options)
            ),
        ),
    )
    status_options = [TicketStatusOption(name="status_dispatch", title="Dispatch")]

    async def fake_list_ticket_statuses(category_name: str) -> list[TicketStatusOption]:
        assert category_name == "delivery"
        return status_options

    monkeypatch.setattr(app.connector, "list_ticket_statuses", fake_list_ticket_statuses)
    monkeypatch.setattr(app, "call_after_refresh", lambda callback: callback())
    app._ticket_status_load_generation = 2

    await app._load_ticket_statuses(detail_screen, "delivery", 1)

    assert app._ticket_status_options_by_category == {}
    assert updated_statuses == []


@pytest.mark.asyncio
async def test_app_store_ticket_applies_saved_ticket_when_refresh_active_view_returns_false(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    ticket = make_ticket(title="Broken scanner", name=9001)
    saved_ticket = ticket.model_copy(update={"title": "Saved scanner"})
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            sync_ticket=lambda current_ticket: None,
            consume_close_after_save=lambda: False,
            cancel_close_after_save=lambda: None,
        ),
    )
    applied_tickets: list[Ticket] = []

    async def fake_store_ticket(current_ticket: Ticket, patch: TicketEditPatch) -> Ticket:
        assert current_ticket == ticket
        return saved_ticket

    monkeypatch.setattr(app.connector, "store_ticket", fake_store_ticket)
    monkeypatch.setattr(DaktelaPaleoApp, "screen", property(lambda self: detail_screen))
    monkeypatch.setattr(DaktelaPaleoApp, "watch_app_state", lambda self, app_state: None)
    monkeypatch.setattr(DaktelaPaleoApp, "watch_loading_message", lambda self, message: None)
    monkeypatch.setattr(DaktelaPaleoApp, "watch_error_message", lambda self, message: None)
    monkeypatch.setattr(DaktelaPaleoApp, "watch_notice_message", lambda self, message: None)
    monkeypatch.setattr(DaktelaPaleoApp, "watch_status_message", lambda self, message: None)
    monkeypatch.setattr(app, "_refresh_active_view", lambda **kwargs: False)
    monkeypatch.setattr(app, "_apply_saved_ticket", applied_tickets.append)
    app._ticket_save_generation = 1

    await app._store_ticket(detail_screen, ticket, TicketEditPatch(title="Saved scanner"), 1)

    assert applied_tickets == [saved_ticket]
    assert app.notice_message == "Saved ticket: Saved scanner"


@pytest.mark.asyncio
async def test_app_store_ticket_ignores_view_reload_error_after_save(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = make_demo_app()
    ticket = make_ticket(title="Broken scanner", name=9002)
    saved_ticket = ticket.model_copy(update={"title": "Saved scanner"})
    detail_screen = cast(
        TicketDetail,
        SimpleNamespace(
            sync_ticket=lambda current_ticket: None,
            consume_close_after_save=lambda: False,
            cancel_close_after_save=lambda: None,
        ),
    )
    applied_tickets: list[Ticket] = []

    async def fake_store_ticket(current_ticket: Ticket, patch: TicketEditPatch) -> Ticket:
        assert current_ticket == ticket
        return saved_ticket

    async def fake_list_views() -> list[TicketView]:
        raise RuntimeError("boom")

    monkeypatch.setattr(app.connector, "store_ticket", fake_store_ticket)
    monkeypatch.setattr(app.connector, "list_views", fake_list_views)
    monkeypatch.setattr(DaktelaPaleoApp, "screen", property(lambda self: detail_screen))
    monkeypatch.setattr(DaktelaPaleoApp, "watch_loading_message", lambda self, message: None)
    monkeypatch.setattr(DaktelaPaleoApp, "watch_error_message", lambda self, message: None)
    monkeypatch.setattr(DaktelaPaleoApp, "watch_notice_message", lambda self, message: None)
    monkeypatch.setattr(DaktelaPaleoApp, "watch_status_message", lambda self, message: None)
    monkeypatch.setattr(app, "_refresh_active_view", lambda **kwargs: False)
    monkeypatch.setattr(app, "_apply_saved_ticket", applied_tickets.append)
    app._ticket_save_generation = 1

    await app._store_ticket(detail_screen, ticket, TicketEditPatch(title="Saved scanner"), 1)

    assert applied_tickets == [saved_ticket]
    assert app.notice_message == "Saved ticket: Saved scanner"
    assert app.error_message is None


def test_apply_saved_ticket_updates_matching_active_ticket_and_table_rows(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    active_ticket = make_ticket(title="Broken scanner", name=2001)
    other_ticket = make_ticket(title="Other ticket", name=2002)
    saved_ticket = active_ticket.model_copy(update={"title": "Saved scanner"})
    app = DaktelaPaleoApp(
        initial_state=AppState(
            tickets=[active_ticket, other_ticket],
            views=[],
            active_ticket=active_ticket,
            active_view=None,
        ),
        connector=DemoTicketConnector(),
    )
    monkeypatch.setattr(DaktelaPaleoApp, "watch_app_state", lambda self, app_state: None)

    app._apply_saved_ticket(saved_ticket)

    assert app.app_state.active_ticket == saved_ticket
    assert app.app_state.tickets == [saved_ticket, other_ticket]


def test_ticket_status_options_for_category_returns_deep_copies() -> None:
    app = make_demo_app()
    original_options = [TicketStatusOption(name="status_dispatch", title="Dispatch")]
    app._ticket_status_options_by_category["delivery"] = original_options

    copied_options = app._ticket_status_options_for_category("delivery")

    assert copied_options == original_options
    assert copied_options is not original_options
    assert copied_options is not None

    copied_options[0].title = "Changed"

    assert original_options[0].title == "Dispatch"


def test_refresh_active_view_returns_false_without_active_view() -> None:
    app = DaktelaPaleoApp(initial_state=AppState(), connector=DemoTicketConnector())

    assert app._refresh_active_view() is False


def test_load_relative_ticket_page_returns_false_without_active_view() -> None:
    app = DaktelaPaleoApp(initial_state=AppState(), connector=DemoTicketConnector())

    assert app._load_relative_ticket_page(1) is False


def test_load_relative_ticket_page_returns_false_at_page_boundaries() -> None:
    view = TicketView(name="delivery", title="Delivery")
    app = DaktelaPaleoApp(
        initial_state=AppState(
            active_view=view,
            ticket_pagination=TicketPagination(current_page=1, total_pages=2, total_tickets=2),
        ),
        connector=DemoTicketConnector(),
    )

    assert app._load_relative_ticket_page(-1) is False
