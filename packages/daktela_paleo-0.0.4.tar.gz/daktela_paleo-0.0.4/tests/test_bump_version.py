from __future__ import annotations

from pathlib import Path

from scripts import bump_version


def test_resolve_release_version_strips_optional_v_prefix() -> None:
    version, exit_code, error = bump_version.resolve_release_version("v1.2.3")

    assert (version, exit_code, error) == ("1.2.3", 0, None)


def test_resolve_release_version_accepts_plain_semver() -> None:
    version, exit_code, error = bump_version.resolve_release_version("1.2.3")

    assert (version, exit_code, error) == ("1.2.3", 0, None)


def test_resolve_release_version_rejects_missing_input() -> None:
    version, exit_code, error = bump_version.resolve_release_version(None)

    assert version is None
    assert exit_code == 3
    assert error == "missing release tag; pass --tag or set RELEASE_TAG / CI_COMMIT_TAG"


def test_resolve_release_version_rejects_invalid_tag() -> None:
    version, exit_code, error = bump_version.resolve_release_version("release-1")

    assert version is None
    assert exit_code == 4
    assert error == "invalid release tag 'release-1'; expected vX.Y.Z or X.Y.Z"


def test_update_pyproject_version_rewrites_project_version(tmp_path: Path) -> None:
    pyproject = tmp_path / "pyproject.toml"
    pyproject.write_text(
        """
[project]
name = "daktela-paleo"
version = "0.1.0"
description = "demo"
""".lstrip(),
        encoding="utf-8",
    )

    exit_code, error = bump_version.update_pyproject_version(pyproject, "0.0.7")

    assert (exit_code, error) == (0, None)
    updated = pyproject.read_text(encoding="utf-8")
    assert 'version = "0.0.7"' in updated
    assert 'name = "daktela-paleo"' in updated


def test_update_pyproject_version_requires_project_table(tmp_path: Path) -> None:
    pyproject = tmp_path / "pyproject.toml"
    pyproject.write_text("[tool.demo]\nvalue = 1\n", encoding="utf-8")

    exit_code, error = bump_version.update_pyproject_version(pyproject, "0.0.1")

    assert exit_code == 4
    assert error == "missing [project] table in pyproject.toml"
