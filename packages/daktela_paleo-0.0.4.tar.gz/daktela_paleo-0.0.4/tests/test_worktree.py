from __future__ import annotations

import os
import shutil
import subprocess
from collections.abc import Callable
from pathlib import Path
from typing import Any, TypedDict

import pytest

from scripts import worktree


class RunCall(TypedDict):
    args: tuple[str, ...]
    cwd: Path | None
    env: dict[str, str] | None
    capture_output: bool
    text: bool
    check: bool


RunResponse = subprocess.CompletedProcess[str]
RunHandler = Callable[..., RunResponse]


def completed(
    args: tuple[str, ...],
    returncode: int = 0,
    stdout: str = "",
    stderr: str = "",
) -> subprocess.CompletedProcess[str]:
    return subprocess.CompletedProcess(args=args, returncode=returncode, stdout=stdout, stderr=stderr)


def prepare_repo(tmp_path: Path) -> None:
    (tmp_path / ".git").mkdir()
    (tmp_path / "backlog").mkdir()
    (tmp_path / ".envrc").write_text("source .venv/bin/activate\n", encoding="utf-8")


def worktree_list_output(entries: list[tuple[Path, str | None]]) -> str:
    lines: list[str] = []

    for index, (path, branch_ref) in enumerate(entries):
        lines.append(f"worktree {path}")
        lines.append(f"HEAD head{index}")
        if branch_ref is None:
            lines.append("detached")
        else:
            lines.append(f"branch {branch_ref}")
        lines.append("")

    return "\n".join(lines)


def install_fake_run(
    monkeypatch: pytest.MonkeyPatch,
    responses: dict[tuple[str, ...], RunResponse | RunHandler],
    calls: list[RunCall],
) -> None:
    def fake_run(
        args: list[str] | tuple[str, ...],
        cwd: str | os.PathLike[str] | None = None,
        env: dict[str, str] | None = None,
        **kwargs: Any,
    ) -> RunResponse:
        check = kwargs.get("check", False)
        key = tuple(args)
        calls.append(
            {
                "args": key,
                "cwd": Path(cwd) if cwd is not None else None,
                "env": dict(env) if env is not None else None,
                "capture_output": kwargs.get("capture_output", False),
                "text": kwargs.get("text", False),
                "check": check,
            }
        )
        response = responses.get(key)
        if response is None:
            raise AssertionError(f"Unexpected command: {key}")
        result = response(args=args, cwd=cwd, env=env, **kwargs) if callable(response) else response
        if check and result.returncode != 0:
            raise subprocess.CalledProcessError(result.returncode, args)
        return result

    monkeypatch.setattr(worktree.subprocess, "run", fake_run)


def install_fake_clean_helpers(
    monkeypatch: pytest.MonkeyPatch,
    *,
    entries: list[tuple[Path, str | None]],
    current_branch: str = "main",
    head_sha: str = "same-sha",
    main_sha: str = "same-sha",
    origin_main_sha: str = "same-sha",
    dirty_paths: set[Path] | None = None,
    unmerged_branch_refs: set[str] | None = None,
    existing_branches: set[str] | None = None,
) -> tuple[list[tuple[tuple[str, ...], Path | None]], list[Path], list[str]]:
    dirty_paths = dirty_paths or set()
    unmerged_branch_refs = unmerged_branch_refs or set()
    existing_branches = existing_branches or set()
    worktree_output = worktree_list_output(entries)

    run_checked_calls: list[tuple[tuple[str, ...], Path | None]] = []
    removed_paths: list[Path] = []
    deleted_branches: list[str] = []

    def fake_capture_stdout(
        args: list[str] | tuple[str, ...],
        cwd: Path | None = None,
        env: dict[str, str] | None = None,
    ) -> str:
        key = tuple(args)
        if key == ("git", "branch", "--show-current"):
            return current_branch
        if key == ("git", "worktree", "list", "--porcelain"):
            return worktree_output
        if key == ("git", "status", "--short"):
            assert cwd is not None
            return " M README.md\n" if Path(cwd) in dirty_paths else ""
        if key == ("git", "rev-parse", "HEAD"):
            return head_sha
        if key == ("git", "rev-parse", "main"):
            return main_sha
        if key == ("git", "rev-parse", "origin/main"):
            return origin_main_sha
        raise AssertionError(f"Unexpected capture_stdout command: {key}")

    def fake_command_succeeds(
        args: list[str] | tuple[str, ...],
        cwd: Path | None = None,
        env: dict[str, str] | None = None,
    ) -> bool:
        key = tuple(args)
        if key[:3] == ("git", "merge-base", "--is-ancestor"):
            return key[3] not in unmerged_branch_refs
        if key[:4] == ("git", "show-ref", "--verify", "--quiet"):
            return key[4].removeprefix("refs/heads/") in existing_branches
        raise AssertionError(f"Unexpected command_succeeds command: {key}")

    def fake_run_checked(
        args: list[str] | tuple[str, ...],
        cwd: Path | None = None,
        env: dict[str, str] | None = None,
    ) -> None:
        key = tuple(args)
        run_checked_calls.append((key, Path(cwd) if cwd is not None else None))
        if key == ("git", "fetch", "origin", "main"):
            return
        if key[:3] == ("git", "worktree", "remove"):
            target_dir = Path(key[3])
            removed_paths.append(target_dir)
            target_dir.rmdir()
            return
        if key[:3] == ("git", "branch", "-D"):
            deleted_branches.append(key[3])
            return
        raise AssertionError(f"Unexpected run_checked command: {key}")

    monkeypatch.setattr(worktree, "capture_stdout", fake_capture_stdout)
    monkeypatch.setattr(worktree, "command_succeeds", fake_command_succeeds)
    monkeypatch.setattr(worktree, "run_checked", fake_run_checked)
    return run_checked_calls, removed_paths, deleted_branches


def create_success_responses(
    repo_root: Path,
    branch: str,
    *,
    merge_main: bool = False,
    backlog_setup: Callable[[Path], None] | None = None,
):
    target_dir = repo_root / "worktrees" / branch

    def add_worktree(**_: object):
        target_dir.mkdir(parents=True)
        if backlog_setup is not None:
            backlog_setup(target_dir)
        return completed(("git", "worktree", "add", "-b", branch, str(target_dir), "main"))

    def create_venv(**_: object):
        (target_dir / ".venv").mkdir(parents=True)
        return completed(("uv", "venv", "--python", "3.14", str(target_dir / ".venv")))

    responses: dict[tuple[str, ...], RunResponse | RunHandler] = {
        ("git", "branch", "--show-current"): completed(
            ("git", "branch", "--show-current"),
            stdout="main\n",
        ),
        ("git", "status", "--short"): completed(("git", "status", "--short")),
        ("git", "check-ref-format", "--branch", branch): completed(
            ("git", "check-ref-format", "--branch", branch),
        ),
        ("git", "show-ref", "--verify", "--quiet", f"refs/heads/{branch}"): completed(
            ("git", "show-ref", "--verify", "--quiet", f"refs/heads/{branch}"),
            returncode=1,
        ),
        ("git", "ls-remote", "--exit-code", "--heads", "origin", branch): completed(
            ("git", "ls-remote", "--exit-code", "--heads", "origin", branch),
            returncode=2,
        ),
        ("git", "fetch", "origin", "main"): completed(("git", "fetch", "origin", "main")),
        ("git", "merge-base", "--is-ancestor", "main", "origin/main"): completed(
            ("git", "merge-base", "--is-ancestor", "main", "origin/main"),
        ),
        ("git", "merge-base", "--is-ancestor", "HEAD", "origin/main"): completed(
            ("git", "merge-base", "--is-ancestor", "HEAD", "origin/main"),
        ),
        ("git", "rev-parse", "main"): completed(
            ("git", "rev-parse", "main"),
            stdout="local-main\n" if merge_main else "same-main\n",
        ),
        ("git", "rev-parse", "origin/main"): completed(
            ("git", "rev-parse", "origin/main"),
            stdout="origin-main\n" if merge_main else "same-main\n",
        ),
        ("git", "worktree", "add", "-b", branch, str(target_dir), "main"): add_worktree,
        ("git", "merge", "--ff-only", "origin/main"): completed(
            ("git", "merge", "--ff-only", "origin/main"),
        ),
        ("uv", "venv", "--python", "3.14", str(target_dir / ".venv")): create_venv,
        ("uv", "sync", "--group", "dev", "--directory", str(target_dir)): completed(
            ("uv", "sync", "--group", "dev", "--directory", str(target_dir)),
        ),
        ("direnv", "allow", "."): completed(("direnv", "allow", ".")),
    }
    return responses, target_dir


def test_create_worktree_bootstraps_dependencies(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    prepare_repo(tmp_path)
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("VIRTUAL_ENV", str(tmp_path / ".active-venv"))
    monkeypatch.setattr(worktree.shutil, "which", lambda name: "/usr/bin/direnv" if name == "direnv" else None)

    calls: list[RunCall] = []
    responses, target_dir = create_success_responses(tmp_path, "feature/demo")
    install_fake_run(monkeypatch, responses, calls)

    exit_code = worktree.main(["create", "feature/demo"])

    assert exit_code == 0
    expected_backlog_target = os.path.relpath(tmp_path / "backlog", target_dir)
    assert (target_dir / "backlog").is_symlink()
    assert os.readlink(target_dir / "backlog") == expected_backlog_target
    uv_commands = [call for call in calls if call["args"][0] == "uv"]
    assert uv_commands
    assert all("VIRTUAL_ENV" not in call["env"] for call in uv_commands if call["env"] is not None)
    assert any(
        call["args"] == ("uv", "venv", "--python", "3.14", str(target_dir / ".venv"))
        for call in calls
    )
    assert any(
        call["args"] == ("uv", "sync", "--group", "dev", "--directory", str(target_dir))
        for call in calls
    )
    assert any(call["args"] == ("direnv", "allow", ".") and call["cwd"] == target_dir for call in calls)


def test_create_worktree_fast_forwards_main(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    prepare_repo(tmp_path)
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(worktree.shutil, "which", lambda name: "/usr/bin/direnv" if name == "direnv" else None)

    calls: list[RunCall] = []
    responses, _ = create_success_responses(tmp_path, "feature/ff", merge_main=True)
    install_fake_run(monkeypatch, responses, calls)

    exit_code = worktree.main(["create", "feature/ff"])

    assert exit_code == 0
    assert any(call["args"] == ("git", "merge", "--ff-only", "origin/main") for call in calls)


def test_create_worktree_preserves_correct_shared_backlog_symlink(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    prepare_repo(tmp_path)
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(worktree.shutil, "which", lambda name: "/usr/bin/direnv" if name == "direnv" else None)

    branch = "feature/demo"

    def backlog_setup(target_dir: Path) -> None:
        target = os.path.relpath(tmp_path / "backlog", target_dir)
        (target_dir / "backlog").symlink_to(target, target_is_directory=True)

    calls: list[RunCall] = []
    responses, target_dir = create_success_responses(
        tmp_path, branch, backlog_setup=backlog_setup
    )
    install_fake_run(monkeypatch, responses, calls)

    exit_code = worktree.main(["create", branch])

    assert exit_code == 0
    assert (target_dir / "backlog").is_symlink()
    assert os.readlink(target_dir / "backlog") == os.path.relpath(tmp_path / "backlog", target_dir)


@pytest.mark.parametrize(
    "existing_backlog_kind",
    ["wrong-symlink", "file", "directory"],
)
def test_create_worktree_replaces_existing_backlog_path(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    existing_backlog_kind: str,
) -> None:
    prepare_repo(tmp_path)
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(worktree.shutil, "which", lambda name: "/usr/bin/direnv" if name == "direnv" else None)

    branch = "feature/demo"

    def backlog_setup(target_dir: Path) -> None:
        backlog_path = target_dir / "backlog"
        if existing_backlog_kind == "wrong-symlink":
            backlog_path.symlink_to("../wrong-backlog", target_is_directory=True)
        elif existing_backlog_kind == "file":
            backlog_path.write_text("stale backlog placeholder\n", encoding="utf-8")
        else:
            backlog_path.mkdir()
            (backlog_path / "task.md").write_text("stale task\n", encoding="utf-8")

    calls: list[RunCall] = []
    responses, target_dir = create_success_responses(
        tmp_path, branch, backlog_setup=backlog_setup
    )
    install_fake_run(monkeypatch, responses, calls)

    exit_code = worktree.main(["create", branch])

    assert exit_code == 0
    assert (target_dir / "backlog").is_symlink()
    assert os.readlink(target_dir / "backlog") == os.path.relpath(tmp_path / "backlog", target_dir)


class ExecCalledError(RuntimeError):
    pass


class FakeStream:
    def __init__(self, is_tty: bool) -> None:
        self._is_tty = is_tty
        self.buffer: list[str] = []

    def isatty(self) -> bool:
        return self._is_tty

    def write(self, text: str) -> int:
        self.buffer.append(text)
        return len(text)

    def flush(self) -> None:
        return None


def test_create_worktree_opens_shell_when_interactive(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    prepare_repo(tmp_path)
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(worktree.shutil, "which", lambda name: "/usr/bin/direnv" if name == "direnv" else None)
    monkeypatch.setattr(worktree.sys, "stdin", FakeStream(is_tty=True))
    monkeypatch.setattr(worktree.sys, "stdout", FakeStream(is_tty=True))
    monkeypatch.setenv("SHELL", "/bin/bash")

    calls: list[RunCall] = []
    responses, target_dir = create_success_responses(tmp_path, "feature/shell")
    install_fake_run(monkeypatch, responses, calls)

    chdir_calls: list[Path] = []
    exec_calls: list[tuple[str, list[str], dict[str, str]]] = []

    def fake_chdir(path: str | os.PathLike[str]) -> None:
        chdir_calls.append(Path(path))

    def fake_execvpe(file: str, argv: list[str], env: dict[str, str]) -> None:
        exec_calls.append((file, argv, env))
        raise ExecCalledError

    monkeypatch.setattr(worktree.os, "chdir", fake_chdir)
    monkeypatch.setattr(worktree.os, "execvpe", fake_execvpe)

    with pytest.raises(ExecCalledError):
        worktree.main(["create", "feature/shell"])

    assert chdir_calls == [target_dir]
    assert exec_calls == [
        ("/bin/bash", ["/bin/bash", "-l"], dict(os.environ)),
    ]


@pytest.mark.parametrize(
    ("argv", "expected_message"),
    [
        ([], "Usage: make worktree <create|delete|list|check|clean> [args...]"),
        (["create"], "Usage: make worktree create <branch-name>"),
        (["create", "one", "two"], "Usage: make worktree create <branch-name>"),
        (["delete"], "Usage: make worktree delete <branch-name>"),
        (["delete", "one", "two"], "Usage: make worktree delete <branch-name>"),
        (["list", "one"], "Usage: make worktree list"),
        (["check", "one"], "Usage: make worktree check"),
        (["clean", "one"], "Usage: make worktree clean"),
    ],
)
def test_main_validates_command_arguments(
    argv: list[str],
    expected_message: str,
    capsys: pytest.CaptureFixture[str],
) -> None:
    exit_code = worktree.main(argv)

    assert exit_code == 1
    assert expected_message in capsys.readouterr().err


def test_list_worktrees_prints_branches_and_paths(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    prepare_repo(tmp_path)
    monkeypatch.chdir(tmp_path)

    output = "\n".join(
        [
            f"worktree {tmp_path}",
            "HEAD abc123",
            "branch refs/heads/main",
            "",
            f"worktree {tmp_path / 'worktrees' / 'feature' / 'demo'}",
            "HEAD def456",
            "branch refs/heads/feature/demo",
            "",
        ]
    )

    monkeypatch.setattr(worktree, "capture_stdout", lambda args, cwd=None, env=None: output)

    exit_code = worktree.main(["list"])

    assert exit_code == 0
    assert capsys.readouterr().out.splitlines() == [
        f"main\t{tmp_path}",
        f"feature/demo\t{tmp_path / 'worktrees' / 'feature' / 'demo'}",
    ]


def test_check_worktrees_reports_all_merged(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    prepare_repo(tmp_path)
    monkeypatch.chdir(tmp_path)

    output = "\n".join(
        [
            f"worktree {tmp_path}",
            "HEAD abc123",
            "branch refs/heads/main",
            "",
            f"worktree {tmp_path / 'worktrees' / 'feature' / 'demo'}",
            "HEAD def456",
            "branch refs/heads/feature/demo",
            "",
            f"worktree {tmp_path / 'worktrees' / 'bug' / 'fix'}",
            "HEAD ghi789",
            "branch refs/heads/bug/fix",
            "",
        ]
    )

    monkeypatch.setattr(worktree, "capture_stdout", lambda args, cwd=None, env=None: output)
    monkeypatch.setattr(worktree, "command_succeeds", lambda args, cwd=None, env=None: True)

    exit_code = worktree.main(["check"])

    assert exit_code == 0
    assert capsys.readouterr().out.splitlines() == [
        f"merged\tfeature/demo\t{tmp_path / 'worktrees' / 'feature' / 'demo'}",
        f"merged\tbug/fix\t{tmp_path / 'worktrees' / 'bug' / 'fix'}",
    ]


def test_check_worktrees_fails_for_unmerged_branches(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    prepare_repo(tmp_path)
    monkeypatch.chdir(tmp_path)

    feature_path = tmp_path / "worktrees" / "feature" / "demo"
    bug_path = tmp_path / "worktrees" / "bug" / "fix"
    output = "\n".join(
        [
            f"worktree {tmp_path}",
            "HEAD abc123",
            "branch refs/heads/main",
            "",
            f"worktree {feature_path}",
            "HEAD def456",
            "branch refs/heads/feature/demo",
            "",
            f"worktree {bug_path}",
            "HEAD ghi789",
            "branch refs/heads/bug/fix",
            "",
        ]
    )

    def fake_command_succeeds(
        args: list[str] | tuple[str, ...],
        cwd: Path | None = None,
        env: dict[str, str] | None = None,
    ) -> bool:
        return tuple(args) != ("git", "merge-base", "--is-ancestor", "refs/heads/bug/fix", "main")

    monkeypatch.setattr(worktree, "capture_stdout", lambda args, cwd=None, env=None: output)
    monkeypatch.setattr(worktree, "command_succeeds", fake_command_succeeds)

    exit_code = worktree.main(["check"])

    captured = capsys.readouterr()
    assert exit_code == 1
    assert captured.out.splitlines() == [
        f"merged\tfeature/demo\t{feature_path}",
        f"unmerged\tbug/fix\t{bug_path}",
    ]
    assert "Found worktrees not merged into main." in captured.err


def test_check_worktrees_skips_detached_entries_and_main(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    prepare_repo(tmp_path)
    monkeypatch.chdir(tmp_path)

    output = "\n".join(
        [
            f"worktree {tmp_path}",
            "HEAD abc123",
            "branch refs/heads/main",
            "",
            f"worktree {tmp_path / 'scratch'}",
            "HEAD def456",
            "detached",
            "",
            f"worktree {tmp_path / 'worktrees' / 'feature' / 'demo'}",
            "HEAD ghi789",
            "branch refs/heads/feature/demo",
            "",
        ]
    )

    checked_args: list[tuple[str, ...]] = []

    def fake_command_succeeds(
        args: list[str] | tuple[str, ...],
        cwd: Path | None = None,
        env: dict[str, str] | None = None,
    ) -> bool:
        checked_args.append(tuple(args))
        return True

    monkeypatch.setattr(worktree, "capture_stdout", lambda args, cwd=None, env=None: output)
    monkeypatch.setattr(worktree, "command_succeeds", fake_command_succeeds)

    exit_code = worktree.main(["check"])

    assert exit_code == 0
    assert checked_args == [
        ("git", "merge-base", "--is-ancestor", "refs/heads/feature/demo", "main")
    ]
    assert capsys.readouterr().out.splitlines() == [
        f"merged\tfeature/demo\t{tmp_path / 'worktrees' / 'feature' / 'demo'}"
    ]


def test_clean_worktrees_removes_all_non_main_worktrees(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    prepare_repo(tmp_path)
    monkeypatch.chdir(tmp_path)

    feature_path = tmp_path / "worktrees" / "feature" / "demo"
    bug_path = tmp_path / "worktrees" / "bug" / "fix"
    feature_path.mkdir(parents=True)
    bug_path.mkdir(parents=True)

    run_checked_calls, removed_paths, deleted_branches = install_fake_clean_helpers(
        monkeypatch,
        entries=[
            (tmp_path, "refs/heads/main"),
            (feature_path, "refs/heads/feature/demo"),
            (bug_path, "refs/heads/bug/fix"),
        ],
        existing_branches={"feature/demo", "bug/fix"},
    )

    exit_code = worktree.main(["clean"])

    captured = capsys.readouterr()
    assert exit_code == 0
    assert removed_paths == [feature_path, bug_path]
    assert deleted_branches == ["feature/demo", "bug/fix"]
    assert not (tmp_path / "worktrees").exists()
    assert run_checked_calls[0][0] == ("git", "fetch", "origin", "main")
    assert "Cleaned 2 worktrees." in captured.out


def test_clean_worktrees_reports_no_targets(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    prepare_repo(tmp_path)
    monkeypatch.chdir(tmp_path)

    run_checked_calls, removed_paths, deleted_branches = install_fake_clean_helpers(
        monkeypatch,
        entries=[(tmp_path, "refs/heads/main")],
    )

    exit_code = worktree.main(["clean"])

    captured = capsys.readouterr()
    assert exit_code == 0
    assert run_checked_calls == [(("git", "fetch", "origin", "main"), None)]
    assert removed_paths == []
    assert deleted_branches == []
    assert "No worktrees to clean." in captured.out


def test_clean_worktrees_requires_main_branch(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    prepare_repo(tmp_path)
    monkeypatch.chdir(tmp_path)

    run_checked_calls, _, _ = install_fake_clean_helpers(
        monkeypatch,
        entries=[(tmp_path, "refs/heads/main")],
        current_branch="feature/demo",
    )

    exit_code = worktree.main(["clean"])

    assert exit_code == 1
    assert run_checked_calls == []
    assert "Current branch must be main (found feature/demo)." in capsys.readouterr().err


def test_clean_worktrees_requires_origin_main_sync(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    prepare_repo(tmp_path)
    monkeypatch.chdir(tmp_path)

    feature_path = tmp_path / "worktrees" / "feature" / "demo"
    feature_path.mkdir(parents=True)

    run_checked_calls, removed_paths, deleted_branches = install_fake_clean_helpers(
        monkeypatch,
        entries=[
            (tmp_path, "refs/heads/main"),
            (feature_path, "refs/heads/feature/demo"),
        ],
        head_sha="head-sha",
        main_sha="main-sha",
        origin_main_sha="origin-sha",
        existing_branches={"feature/demo"},
    )

    exit_code = worktree.main(["clean"])

    assert exit_code == 1
    assert run_checked_calls == [(("git", "fetch", "origin", "main"), None)]
    assert removed_paths == []
    assert deleted_branches == []
    assert (
        "Current HEAD, local main, and origin/main must point to the same commit."
        in capsys.readouterr().err
    )


def test_clean_worktrees_requires_clean_worktrees(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    prepare_repo(tmp_path)
    monkeypatch.chdir(tmp_path)

    feature_path = tmp_path / "worktrees" / "feature" / "demo"
    feature_path.mkdir(parents=True)

    run_checked_calls, removed_paths, deleted_branches = install_fake_clean_helpers(
        monkeypatch,
        entries=[
            (tmp_path, "refs/heads/main"),
            (feature_path, "refs/heads/feature/demo"),
        ],
        dirty_paths={feature_path},
        existing_branches={"feature/demo"},
    )

    exit_code = worktree.main(["clean"])

    assert exit_code == 1
    assert run_checked_calls == [(("git", "fetch", "origin", "main"), None)]
    assert removed_paths == []
    assert deleted_branches == []
    assert (
        "Worktree must be clean before cleanup: worktrees/feature/demo"
        in capsys.readouterr().err
    )


def test_clean_worktrees_rejects_detached_worktrees(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    prepare_repo(tmp_path)
    monkeypatch.chdir(tmp_path)

    scratch_path = tmp_path / "scratch"
    scratch_path.mkdir()

    run_checked_calls, removed_paths, deleted_branches = install_fake_clean_helpers(
        monkeypatch,
        entries=[
            (tmp_path, "refs/heads/main"),
            (scratch_path, None),
        ],
    )

    exit_code = worktree.main(["clean"])

    assert exit_code == 1
    assert run_checked_calls == [(("git", "fetch", "origin", "main"), None)]
    assert removed_paths == []
    assert deleted_branches == []
    assert (
        "Detached worktree cannot be cleaned safely: scratch"
        in capsys.readouterr().err
    )


def test_clean_worktrees_requires_merged_branches(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    prepare_repo(tmp_path)
    monkeypatch.chdir(tmp_path)

    feature_path = tmp_path / "worktrees" / "feature" / "demo"
    feature_path.mkdir(parents=True)

    run_checked_calls, removed_paths, deleted_branches = install_fake_clean_helpers(
        monkeypatch,
        entries=[
            (tmp_path, "refs/heads/main"),
            (feature_path, "refs/heads/feature/demo"),
        ],
        unmerged_branch_refs={"refs/heads/feature/demo"},
        existing_branches={"feature/demo"},
    )

    exit_code = worktree.main(["clean"])

    assert exit_code == 1
    assert run_checked_calls == [(("git", "fetch", "origin", "main"), None)]
    assert removed_paths == []
    assert deleted_branches == []
    assert "Worktree branch is not merged into main: feature/demo" in capsys.readouterr().err


def test_clean_worktrees_does_not_prune_external_parents(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    prepare_repo(tmp_path)
    monkeypatch.chdir(tmp_path)

    external_parent = tmp_path / "external-worktrees"
    external_path = external_parent / "feature-demo"
    external_path.mkdir(parents=True)

    _, removed_paths, deleted_branches = install_fake_clean_helpers(
        monkeypatch,
        entries=[
            (tmp_path, "refs/heads/main"),
            (external_path, "refs/heads/feature/demo"),
        ],
        existing_branches={"feature/demo"},
    )

    exit_code = worktree.main(["clean"])

    assert exit_code == 0
    assert removed_paths == [external_path]
    assert deleted_branches == ["feature/demo"]
    assert external_parent.exists()
    assert "Cleaned 1 worktrees." in capsys.readouterr().out


@pytest.mark.parametrize(
    ("scenario", "expected_message"),
    [
        ("not-main", "Current branch must be main (found feature/demo)."),
        ("dirty", "Primary checkout must be clean before creating a worktree."),
        ("invalid", "Invalid branch name: feature/demo"),
        ("local-exists", "Local branch already exists: feature/demo"),
        ("remote-exists", "Remote branch already exists on origin: feature/demo"),
    ],
)
def test_create_worktree_validates_preconditions(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
    scenario: str,
    expected_message: str,
) -> None:
    prepare_repo(tmp_path)
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(worktree.shutil, "which", lambda name: "/usr/bin/direnv" if name == "direnv" else None)

    branch = "feature/demo"
    responses, _ = create_success_responses(tmp_path, branch)
    if scenario == "not-main":
        responses[("git", "branch", "--show-current")] = completed(
            ("git", "branch", "--show-current"),
            stdout="feature/demo\n",
        )
    elif scenario == "dirty":
        responses[("git", "status", "--short")] = completed(
            ("git", "status", "--short"),
            stdout=" M README.md\n",
        )
    elif scenario == "invalid":
        responses[("git", "check-ref-format", "--branch", branch)] = completed(
            ("git", "check-ref-format", "--branch", branch),
            returncode=1,
        )
    elif scenario == "local-exists":
        responses[("git", "show-ref", "--verify", "--quiet", f"refs/heads/{branch}")] = completed(
            ("git", "show-ref", "--verify", "--quiet", f"refs/heads/{branch}"),
        )
    else:
        responses[("git", "ls-remote", "--exit-code", "--heads", "origin", branch)] = completed(
            ("git", "ls-remote", "--exit-code", "--heads", "origin", branch),
        )

    calls: list[RunCall] = []
    install_fake_run(monkeypatch, responses, calls)

    exit_code = worktree.main(["create", branch])

    assert exit_code == 1
    assert expected_message in capsys.readouterr().err


def test_create_worktree_requires_primary_checkout_root(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    (tmp_path / ".git").write_text("gitdir: /tmp/example\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)

    exit_code = worktree.main(["create", "feature/demo"])

    assert exit_code == 1
    assert "Run this target from the primary checkout root" in capsys.readouterr().err


def test_create_worktree_requires_missing_target_directory(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    prepare_repo(tmp_path)
    target_dir = tmp_path / "worktrees" / "feature" / "demo"
    target_dir.mkdir(parents=True)
    monkeypatch.chdir(tmp_path)

    calls: list[RunCall] = []
    responses, _ = create_success_responses(tmp_path, "feature/demo")
    install_fake_run(monkeypatch, responses, calls)

    exit_code = worktree.main(["create", "feature/demo"])

    assert exit_code == 1
    assert f"Target directory already exists: {target_dir.relative_to(tmp_path).as_posix()}" in capsys.readouterr().err


def test_create_worktree_requires_shared_backlog_directory(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    prepare_repo(tmp_path)
    shutil.rmtree(tmp_path / "backlog")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(worktree.shutil, "which", lambda name: "/usr/bin/direnv" if name == "direnv" else None)

    calls: list[RunCall] = []
    responses, _ = create_success_responses(tmp_path, "feature/demo")
    install_fake_run(monkeypatch, responses, calls)

    exit_code = worktree.main(["create", "feature/demo"])

    assert exit_code == 1
    assert "Shared backlog directory not found: backlog" in capsys.readouterr().err


def test_create_worktree_requires_direnv(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    prepare_repo(tmp_path)
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(worktree.shutil, "which", lambda name: None)

    calls: list[RunCall] = []
    responses, target_dir = create_success_responses(tmp_path, "feature/demo")
    install_fake_run(monkeypatch, responses, calls)

    exit_code = worktree.main(["create", "feature/demo"])

    assert exit_code == 1
    assert f"direnv is required to approve {target_dir.relative_to(tmp_path).as_posix()}/.envrc." in capsys.readouterr().err


def test_delete_worktree_removes_directory_and_branch(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    prepare_repo(tmp_path)
    monkeypatch.chdir(tmp_path)
    branch = "feature/demo"
    target_dir = tmp_path / "worktrees" / branch
    target_dir.mkdir(parents=True)

    calls: list[RunCall] = []

    def remove_worktree(**_: object):
        target_dir.rmdir()
        return completed(("git", "worktree", "remove", str(target_dir)))

    responses: dict[tuple[str, ...], RunResponse | RunHandler] = {
        ("git", "check-ref-format", "--branch", branch): completed(
            ("git", "check-ref-format", "--branch", branch),
        ),
        ("git", "worktree", "remove", str(target_dir)): remove_worktree,
        ("git", "show-ref", "--verify", "--quiet", f"refs/heads/{branch}"): completed(
            ("git", "show-ref", "--verify", "--quiet", f"refs/heads/{branch}"),
        ),
        ("git", "branch", "-D", branch): completed(("git", "branch", "-D", branch)),
    }
    install_fake_run(monkeypatch, responses, calls)

    exit_code = worktree.main(["delete", branch])

    assert exit_code == 0
    assert not (tmp_path / "worktrees").exists()
    assert any(call["args"] == ("git", "branch", "-D", branch) for call in calls)


def test_delete_worktree_requires_existing_directory(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    prepare_repo(tmp_path)
    monkeypatch.chdir(tmp_path)

    calls: list[RunCall] = []
    responses: dict[tuple[str, ...], RunResponse | RunHandler] = {
        ("git", "check-ref-format", "--branch", "feature/missing"): completed(
            ("git", "check-ref-format", "--branch", "feature/missing"),
        ),
    }
    install_fake_run(monkeypatch, responses, calls)

    exit_code = worktree.main(["delete", "feature/missing"])

    assert exit_code == 1
    assert "Worktree directory not found: worktrees/feature/missing" in capsys.readouterr().err


def test_delete_worktree_requires_primary_checkout_root(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    (tmp_path / ".git").write_text("gitdir: /tmp/example\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)

    exit_code = worktree.main(["delete", "feature/demo"])

    assert exit_code == 1
    assert "Run this target from the primary checkout root" in capsys.readouterr().err
