from datetime import datetime, timedelta

import pytest
from pydantic import ValidationError

from daktela_paleo import models as models_module
from daktela_paleo.models import (
    ActivityBodyFragment,
    AppState,
    Ticket,
    TicketActivity,
    TicketActivityAttachment,
    TicketActivityItem,
    TicketCategoryOption,
    TicketCustomField,
    TicketCustomFieldOption,
    TicketEditPatch,
    TicketPagination,
    TicketPriority,
    TicketStatusOption,
    TicketStage,
    TICKET_GRID_DEFAULT_COLUMN_KEYS,
    TicketUserOption,
    TicketView,
    normalize_ticket_grid_column_keys,
)


def make_ticket_payload() -> dict[str, object]:
    return {
        "title": "Printer is jammed",
        "category": "category_123456",
        "stage": "OPEN",
        "priority": "HIGH",
    }


def make_ticket_view_payload() -> dict[str, object]:
    return {
        "title": "Open high priority tickets",
    }


def make_attachment_payload() -> dict[str, object]:
    return {
        "file": 6,
        "title": "April report.txt",
        "type": "text/plain",
        "size": 2556,
    }


def test_ticket_accepts_minimal_required_payload() -> None:
    ticket = Ticket.model_validate(make_ticket_payload())

    assert ticket.title == "Printer is jammed"
    assert ticket.category == "category_123456"
    assert ticket.stage is TicketStage.OPEN
    assert ticket.priority is TicketPriority.HIGH


def test_ticket_activity_attachment_normalizes_file_identifier_and_title() -> None:
    attachment = TicketActivityAttachment.model_validate(
        {
            "file": 6,
            "title": "   ",
        }
    )

    assert attachment.file == "6"
    assert attachment.title == "6"


def test_ticket_activity_attachment_rejects_non_mapping_input() -> None:
    with pytest.raises(ValidationError):
        TicketActivityAttachment.model_validate("broken")


def test_ticket_activity_downloadable_attachments_prefers_nested_email_attachments() -> None:
    activity = TicketActivity.model_validate(
        {
            "type": "EMAIL",
            "attachments": [{"file": 99, "title": "ignore.txt"}],
            "item": {
                "model": "activitiesEmail",
                "attachments": [make_attachment_payload()],
            },
        }
    )

    assert activity.downloadable_attachments() == (
        TicketActivityAttachment.model_validate(make_attachment_payload()),
    )


def test_ticket_activity_item_invalid_attachment_shape_normalizes_to_none() -> None:
    item = TicketActivityItem.model_validate(
        {
            "model": "activitiesEmail",
            "attachments": "broken",
        }
    )

    assert item.attachments is None


def test_ticket_activity_downloadable_attachments_uses_top_level_for_comments() -> None:
    activity = TicketActivity.model_validate(
        {
            "type": "",
            "attachments": [make_attachment_payload()],
            "item": {
                "model": "activitiesComment",
                "attachments": [{"file": 99, "title": "nested.txt"}],
            },
        }
    )

    assert activity.downloadable_attachments() == (
        TicketActivityAttachment.model_validate(make_attachment_payload()),
    )


def test_ticket_activity_invalid_top_level_attachment_shape_normalizes_to_none() -> None:
    activity = TicketActivity.model_validate(
        {
            "type": "",
            "attachments": "broken",
        }
    )

    assert activity.attachments is None


def test_ticket_requires_documented_required_fields() -> None:
    with pytest.raises(ValidationError) as excinfo:
        Ticket.model_validate({})

    errors = {error["loc"][0] for error in excinfo.value.errors()}
    assert errors == {"title", "category", "stage", "priority"}


def test_ticket_rejects_invalid_enum_values() -> None:
    with pytest.raises(ValidationError):
        Ticket.model_validate(
            {
                **make_ticket_payload(),
                "stage": "PAUSED",
                "priority": "URGENT",
            }
        )


def test_ticket_stage_display_labels_are_reusable() -> None:
    assert TicketStage.OPEN.display_label == "Open"
    assert TicketStage.WAIT.display_label == "Waiting"
    assert TicketStage.CLOSE.display_label == "Closed"
    assert TicketStage.ARCHIVE.display_label == "Archived"


def test_ticket_priority_table_values_match_requested_scale() -> None:
    assert TicketPriority.HIGH.table_value == 1
    assert TicketPriority.MEDIUM.table_value == 2
    assert TicketPriority.LOW.table_value == 3


def test_ticket_priority_display_labels_are_reusable() -> None:
    assert TicketPriority.HIGH.display_label == "High"
    assert TicketPriority.MEDIUM.display_label == "Medium"
    assert TicketPriority.LOW.display_label == "Low"


def test_ticket_parses_datetime_fields() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "created": "2026-03-25 10:11:12",
            "closed": "2026-03-26 08:00:00",
        }
    )

    assert ticket.created == datetime(2026, 3, 25, 10, 11, 12)
    assert ticket.closed == datetime(2026, 3, 26, 8, 0, 0)


def test_ticket_formats_edited_age_using_largest_unit() -> None:
    now = datetime(2026, 3, 26, 12, 0, 0)

    minutes_ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "edited": "2026-03-26 11:15:00",
        }
    )
    hours_ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "edited": "2026-03-26 09:30:00",
        }
    )
    days_ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "edited": "2026-03-24 10:00:00",
        }
    )

    assert minutes_ticket.edited_age(now) == "45m"
    assert hours_ticket.edited_age(now) == "2h"
    assert days_ticket.edited_age(now) == "2d"


def test_ticket_formats_sla_deadtime_age_with_sign() -> None:
    now = datetime(2026, 3, 26, 12, 0, 0)

    overdue_ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "sla_deadtime": "2026-03-24 10:00:00",
        }
    )
    future_ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "sla_deadtime": "2026-03-26 15:30:00",
        }
    )

    assert overdue_ticket.sla_deadtime_age(now) == "-2d"
    assert future_ticket.sla_deadtime_age(now) == "3h"


def test_ticket_sla_deadtime_age_falls_back_to_dash() -> None:
    ticket = Ticket.model_validate(make_ticket_payload())

    assert ticket.sla_deadtime_age() == "-"


def test_ticket_sla_deadtime_age_uses_naive_now_when_timestamp_is_naive(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "sla_deadtime": "2026-03-26 11:15:00",
        }
    )

    class FakeDateTime(datetime):
        @classmethod
        def now(cls, tz=None):
            assert tz is None
            return cls(2026, 3, 26, 12, 0, 0)

    monkeypatch.setattr(models_module, "datetime", FakeDateTime)

    assert ticket.sla_deadtime_age() == "-45m"


def test_ticket_sla_deadtime_age_uses_timezone_aware_now_when_timestamp_has_tzinfo(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "sla_deadtime": "2026-03-26T13:00:00+02:00",
        }
    )

    class FakeDateTime(datetime):
        @classmethod
        def now(cls, tz=None):
            assert tz is not None
            return cls(2026, 3, 26, 12, 0, 0, tzinfo=tz)

    monkeypatch.setattr(models_module, "datetime", FakeDateTime)

    assert ticket.sla_deadtime_age() == "1h"


def test_ticket_edited_age_uses_naive_now_when_timestamp_is_naive(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class FakeDateTime(datetime):
        @classmethod
        def now(cls, tz=None):  # type: ignore[override]
            assert tz is None
            return cls(2026, 3, 26, 12, 0, 0)

    monkeypatch.setattr(models_module, "datetime", FakeDateTime)
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "edited": "2026-03-26 11:30:00",
        }
    )

    assert ticket.edited_age() == "30m"


def test_ticket_edited_age_uses_timezone_aware_now_when_timestamp_has_tzinfo(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class FakeDateTime(datetime):
        @classmethod
        def now(cls, tz=None):  # type: ignore[override]
            assert tz is not None
            assert tz.utcoffset(None) == timedelta(hours=1)
            return cls(2026, 3, 26, 12, 0, 0, tzinfo=tz)

    monkeypatch.setattr(models_module, "datetime", FakeDateTime)
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "edited": "2026-03-26T11:00:00+01:00",
        }
    )

    assert ticket.edited_age() == "1h"


def test_ticket_accepts_name_only_relations() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "user": "operator_1",
            "contact": "contact_2",
            "followers": ["user_1", "user_2"],
            "statuses": {
                "status_open": "Open",
                "status_waiting": "Waiting",
            },
            "children": ["ticket_100", "ticket_101"],
        }
    )

    assert ticket.user == "operator_1"
    assert ticket.contact == "contact_2"
    assert ticket.followers == ["user_1", "user_2"]
    assert ticket.statuses == {
        "status_open": "Open",
        "status_waiting": "Waiting",
    }
    assert ticket.children == ["ticket_100", "ticket_101"]


def test_ticket_statuses_display_label_joins_titles() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "statuses": {
                "status_open": "Open",
                "status_waiting": "Waiting",
            },
        }
    )

    assert ticket.statuses_display_label == "Open, Waiting"


def test_ticket_statuses_display_label_falls_back_to_dash() -> None:
    ticket = Ticket.model_validate(make_ticket_payload())

    assert ticket.statuses_display_label == "-"


def test_ticket_activity_display_helpers_use_expected_fallbacks() -> None:
    activity = TicketActivity.model_validate(
        {
            "type": "EMAIL",
            "time": "2026-03-28 10:30:00",
            "user": "Operator One",
            "item": {
                "model": "activitiesEmail",
                "title": "Fwd: test",
                "body_html": "<p>Hello<br />world</p>",
            },
        }
    )

    assert activity.display_type == "Email"
    assert activity.display_summary_type == "Email"
    assert activity.display_user == "Operator One"
    assert activity.headline == "Fwd: test"
    assert activity.preview_text() == "Hello world"
    assert activity.body_text() == "Hello\nworld"
    assert activity.body_markdown() == "Hello  \nworld"


def test_ticket_activity_display_type_maps_blank_type_to_comment() -> None:
    activity = TicketActivity(type="")

    assert activity.display_type == "Comment"


def test_ticket_activity_display_type_falls_back_to_activity_for_missing_type() -> None:
    activity = TicketActivity(item=TicketActivityItem(model="activitiesEmail"))

    assert activity.display_type == "Activity"


def test_ticket_activity_display_type_keeps_unknown_raw_value() -> None:
    activity = TicketActivity(type="VOICEBOT")

    assert activity.display_type == "VOICEBOT"


def test_ticket_activity_display_summary_type_adds_email_direction_glyph() -> None:
    activity = TicketActivity.model_validate(
        {
            "type": "EMAIL",
            "item": {
                "model": "activitiesEmail",
                "direction": "out",
            },
        }
    )

    assert activity.display_type == "Email"
    assert activity.display_summary_type == "Email ↑"


def test_ticket_activity_display_summary_type_ignores_unknown_email_direction() -> None:
    activity = TicketActivity.model_validate(
        {
            "type": "EMAIL",
            "item": {
                "model": "activitiesEmail",
                "direction": "sideways",
            },
        }
    )

    assert activity.display_summary_type == "Email"


def test_ticket_activity_display_user_falls_back_to_dash() -> None:
    activity = TicketActivity()

    assert activity.display_user == "-"


def test_ticket_activity_preview_falls_back_to_description_and_truncates() -> None:
    activity = TicketActivity(
        description="x" * 200,
        created_by="AI Agent",
    )

    assert activity.display_type == "Activity"
    assert activity.display_user == "AI Agent"
    assert activity.headline == "x" * 200
    assert activity.preview_text() == f"{'x' * 159}…"


def test_ticket_activity_body_text_falls_back_to_description_without_truncation() -> None:
    activity = TicketActivity(
        description="Line one\n\nLine two " + ("x" * 200),
        created_by="AI Agent",
    )

    assert activity.body_text() == f"Line one\n\nLine two {'x' * 200}"
    assert activity.body_markdown() is None


def test_ticket_activity_html_description_fallback_converts_to_markdown() -> None:
    activity = TicketActivity(
        description="<p>Hello<br />world</p>",
        created_by="AI Agent",
    )

    assert activity.headline == "Hello\nworld"
    assert activity.preview_text() == "Hello world"
    assert activity.body_text() == "Hello\nworld"
    assert activity.body_markdown() == "Hello  \nworld"


def test_ticket_activity_body_fragments_preserve_image_order_from_html() -> None:
    activity = TicketActivity(
        description=(
            '<p>Before <strong>image</strong></p>'
            '<img src="/file/image.php?mapper=activities&amp;name=5" alt="Scan" />'
            "<p>After</p>"
        ),
        created_by="AI Agent",
    )

    assert activity.body_fragments() == (
        ActivityBodyFragment.from_markdown("Before **image**"),
        ActivityBodyFragment.from_image("/file/image.php?mapper=activities&name=5", "Scan"),
        ActivityBodyFragment.from_markdown("After"),
    )


def test_ticket_activity_body_fragments_returns_markdown_only_for_html_without_images() -> None:
    activity = TicketActivity(
        description="<p>Hello<br />world</p>",
        created_by="AI Agent",
    )

    assert activity.body_fragments() == (ActivityBodyFragment.from_markdown("Hello  \nworld"),)


def test_ticket_activity_headline_returns_raw_description_when_plain_text_is_empty() -> None:
    activity = TicketActivity(
        description="&nbsp;",
        created_by="AI Agent",
    )

    assert activity.headline == "&nbsp;"


def test_ticket_activity_headline_returns_raw_item_description_when_plain_text_is_empty() -> None:
    activity = TicketActivity(
        item=TicketActivityItem(description="&nbsp;"),
    )

    assert activity.headline == "&nbsp;"


def test_activity_body_html_parser_handles_non_self_closing_image_tags() -> None:
    parser = models_module._ActivityBodyHTMLParser()

    parser.handle_starttag(
        "img",
        [("src", "/file/image.php?mapper=activities&name=5"), ("alt", "Scan")],
    )
    parser.handle_endtag("img")

    assert parser.fragments == [
        ActivityBodyFragment.from_image("/file/image.php?mapper=activities&name=5", "Scan")
    ]


def test_activity_body_html_parser_preserves_entities_charrefs_and_comments_in_buffer() -> None:
    parser = models_module._ActivityBodyHTMLParser()

    parser.handle_entityref("amp")
    parser.handle_charref("169")
    parser.handle_comment("comment")

    assert parser._buffer == ["&amp;", "&#169;", "<!--comment-->"]


def test_activity_body_html_parser_ignores_images_without_src() -> None:
    parser = models_module._ActivityBodyHTMLParser()

    parser._append_image_fragment([("alt", "Scan")])

    assert parser.fragments == []


def test_activity_body_html_parser_flush_buffer_skips_empty_markdown(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    parser = models_module._ActivityBodyHTMLParser()
    parser._buffer.extend(["<!--comment-->"])
    monkeypatch.setattr(models_module, "_markdown_from_html", lambda _value: None)

    parser._flush_buffer()

    assert parser.fragments == []
    assert parser._buffer == []


def test_body_fragments_from_html_returns_none_for_none_and_blank_input() -> None:
    assert models_module._body_fragments_from_html(None) is None
    assert models_module._body_fragments_from_html("   ") is None


def test_body_fragments_from_html_falls_back_to_markdown_when_parser_returns_none(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class EmptyParser:
        def __init__(self) -> None:
            self.fragments: list[ActivityBodyFragment] = []

        def feed(self, _value: str) -> None:
            return

        def close(self) -> None:
            return

    monkeypatch.setattr(models_module, "_ActivityBodyHTMLParser", EmptyParser)
    monkeypatch.setattr(
        models_module,
        "_markdown_from_html",
        lambda value: "Fallback body" if value == "<p>Fallback</p>" else None,
    )

    assert models_module._body_fragments_from_html("<p>Fallback</p>") == (
        ActivityBodyFragment.from_markdown("Fallback body"),
    )


def test_body_fragments_from_html_returns_none_when_fallback_markdown_is_empty(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class EmptyParser:
        def __init__(self) -> None:
            self.fragments: list[ActivityBodyFragment] = []

        def feed(self, _value: str) -> None:
            return

        def close(self) -> None:
            return

    monkeypatch.setattr(models_module, "_ActivityBodyHTMLParser", EmptyParser)
    monkeypatch.setattr(models_module, "_markdown_from_html", lambda _value: None)

    assert models_module._body_fragments_from_html("<p>Fallback</p>") is None


def test_ticket_activity_html_item_description_fallback_converts_to_markdown() -> None:
    activity = TicketActivity(
        item=TicketActivityItem(description="<p>Hello<br />world</p>"),
    )

    assert activity.headline == "Hello\nworld"
    assert activity.preview_text() == "Hello world"
    assert activity.body_text() == "Hello\nworld"
    assert activity.body_markdown() == "Hello  \nworld"


def test_ticket_activity_headline_falls_back_to_item_description_then_untitled() -> None:
    described_activity = TicketActivity(
        item=TicketActivityItem(description="Fallback description"),
    )
    untitled_activity = TicketActivity()

    assert described_activity.headline == "Fallback description"
    assert untitled_activity.headline == "Untitled activity"


def test_ticket_activity_body_markdown_returns_none_for_blank_html() -> None:
    activity = TicketActivity(
        item=TicketActivityItem(body_html="   "),
    )

    assert activity.body_markdown() is None


def test_ticket_activity_preview_and_body_text_return_none_when_candidates_normalize_empty() -> None:
    activity = TicketActivity(
        description="   ",
        item=TicketActivityItem(description="\n\n"),
    )

    assert activity.preview_text() is None
    assert activity.body_text() is None


def test_preview_text_helper_returns_none_for_blank_text() -> None:
    assert models_module._preview_text("   ", max_length=10) is None


def test_markdown_from_html_returns_none_when_markdown_normalizes_empty(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(models_module, "html_to_markdown", lambda value: "   ")

    assert models_module._markdown_from_html("<p>ignored</p>") is None


def test_markdown_from_html_returns_none_for_none_and_blank_values() -> None:
    assert models_module._markdown_from_html(None) is None
    assert models_module._markdown_from_html("   ") is None
    assert models_module._markdown_from_html("  \n\t  ") is None


def test_ticket_activity_item_accepts_datetime_fields() -> None:
    item = TicketActivityItem.model_validate(
        {
            "model": "activitiesEmail",
            "time": "2026-03-28 10:30:00",
        }
    )

    assert item.model == "activitiesEmail"
    assert item.time == datetime(2026, 3, 28, 10, 30, 0)


def test_ticket_edit_patch_tracks_status_change() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "statuses": {
                "status_open": "Open",
            },
        }
    )

    patch = TicketEditPatch.from_form_values(
        ticket,
        title=ticket.title,
        stage=ticket.stage,
        priority=ticket.priority,
        category_name=ticket.category,
        category_title=ticket.category,
        status_name="status_waiting",
        status_title="Waiting",
        description=ticket.description or "",
    )

    assert patch == TicketEditPatch(
        status_name="status_waiting",
        status_title="Waiting",
    )


def test_ticket_edit_patch_apply_to_updates_single_selected_status() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "statuses": {
                "status_open": "Open",
                "status_waiting": "Waiting",
            },
        }
    )

    saved_ticket = TicketEditPatch(
        status_name="status_waiting",
        status_title="Waiting",
    ).apply_to(ticket)

    assert saved_ticket.statuses == {"status_waiting": "Waiting"}


def test_ticket_edit_patch_apply_to_clears_statuses() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "statuses": {
                "status_open": "Open",
            },
        }
    )

    saved_ticket = TicketEditPatch(
        status_name=None,
        status_title=None,
    ).apply_to(ticket)

    assert saved_ticket.statuses is None


def test_ticket_accepts_typed_custom_fields() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "customFields": [
                {
                    "field": "consultant",
                    "title": "Consultant",
                    "values": ["alice"],
                    "field_type": "select",
                    "options": [
                        {"value": "alice", "title": "Alice"},
                        {"value": "bob", "title": "Bob"},
                    ],
                }
            ],
        }
    )

    assert ticket.customFields == [
        TicketCustomField(
            field="consultant",
            title="Consultant",
            values=["alice"],
            field_type="select",
            options=[
                TicketCustomFieldOption(value="alice", title="Alice"),
                TicketCustomFieldOption(value="bob", title="Bob"),
            ],
        )
    ]


def test_ticket_coerces_legacy_custom_field_records() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "customFields": [
                {"field": "interesting", "value": "YES"},
                {"field": "serial_number", "value": 42},
            ],
        }
    )

    assert ticket.customFields == [
        TicketCustomField(
            field="interesting",
            title="interesting",
            values=["YES"],
        ),
        TicketCustomField(
            field="serial_number",
            title="serial_number",
            values=[42],
        ),
    ]


def test_ticket_coerces_custom_field_option_mappings_and_missing_titles() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "customFields": [
                {
                    "field": "replacement_required",
                    "values": ["YES"],
                    "options": {
                        "YES": "Yes",
                        "NO": "No",
                    },
                }
            ],
        }
    )

    assert ticket.customFields == [
        TicketCustomField(
            field="replacement_required",
            title="replacement_required",
            values=["YES"],
            options=[
                TicketCustomFieldOption(value="YES", title="Yes"),
                TicketCustomFieldOption(value="NO", title="No"),
            ],
        )
    ]


def test_ticket_accepts_custom_fields_as_mapping_input() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "customFields": {
                "consultant": ["alice"],
            },
        }
    )

    assert ticket.customFields == [
        TicketCustomField(
            field="consultant",
            title="consultant",
            values=["alice"],
        )
    ]


def test_ticket_ignores_invalid_custom_fields_input_type() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "customFields": "broken",
        }
    )

    assert ticket.customFields is None


def test_ticket_custom_field_coerces_type_none_tuple_and_invalid_options() -> None:
    field = TicketCustomField.model_validate(
        {
            "field": "follow_up_at",
            "type": "datetime",
            "value": None,
            "options": "broken",
        }
    )
    tuple_field = TicketCustomField.model_validate(
        {
            "field": "serial_number",
            "values": ("SN-42", "SN-43"),
        }
    )

    assert field == TicketCustomField(
        field="follow_up_at",
        title="follow_up_at",
        values=[],
        field_type="datetime",
        options=None,
    )
    assert tuple_field == TicketCustomField(
        field="serial_number",
        title="serial_number",
        values=["SN-42", "SN-43"],
    )


def test_ticket_custom_field_option_coercion_skips_missing_values_and_accepts_scalars() -> None:
    option = TicketCustomFieldOption(value="YES", title="Yes")
    field = TicketCustomField.model_validate(
        {
            "field": "replacement_required",
            "options": [
                {"label": "Missing value"},
                7,
                option,
            ],
        }
    )

    assert field.options == [
        TicketCustomFieldOption(value=7, title="7"),
        option,
    ]


def test_ticket_custom_field_rejects_non_mapping_payload() -> None:
    with pytest.raises(ValidationError):
        TicketCustomField.model_validate("broken")


def test_ticket_status_option_accepts_minimal_payload() -> None:
    option = TicketStatusOption.model_validate({"name": "status_dispatch", "title": "Dispatch"})

    assert option.name == "status_dispatch"
    assert option.title == "Dispatch"


def test_ticket_ignores_unknown_api_fields() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "unknownField": "ignored",
        }
    )

    assert "unknownField" not in ticket.model_dump()


def test_ticket_edit_patch_tracks_only_changed_fields() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "description": "Old description",
        }
    )

    patch = TicketEditPatch.from_form_values(
        ticket,
        title="  Printer is jammed  ",
        stage=TicketStage.OPEN,
        category_name="category_123456",
        category_title="category_123456",
        description="Updated description",
    )

    assert patch.model_dump(exclude_unset=True) == {
        "description": "Updated description",
    }
    assert patch.has_changes() is True


def test_ticket_edit_patch_turns_empty_description_into_clear_operation() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "description": "Old description",
        }
    )

    patch = TicketEditPatch.from_form_values(
        ticket,
        title="Printer is jammed",
        stage=TicketStage.OPEN,
        category_name="category_123456",
        category_title="category_123456",
        description="",
    )

    assert patch.model_dump(exclude_unset=True) == {"description": None}
    assert patch.apply_to(ticket).description is None


def test_ticket_edit_patch_rejects_blank_title() -> None:
    ticket = Ticket.model_validate(make_ticket_payload())

    with pytest.raises(ValueError, match="Ticket name can't be blank."):
        TicketEditPatch.from_form_values(
            ticket,
            title="   ",
            stage=TicketStage.OPEN,
            category_name="category_123456",
            category_title="category_123456",
            description="",
        )


def test_ticket_edit_patch_tracks_reopen_change() -> None:
    ticket = Ticket.model_validate(make_ticket_payload())

    patch = TicketEditPatch.from_form_values(
        ticket,
        title="Printer is jammed",
        stage=TicketStage.OPEN,
        category_name="category_123456",
        category_title="category_123456",
        reopen="2026-03-31 09:15:00",
        description="",
    )

    assert patch.model_dump(exclude_unset=True) == {
        "reopen": datetime(2026, 3, 31, 9, 15, 0),
    }


def test_ticket_edit_patch_clears_reopen_with_blank_input() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "reopen": "2026-03-31 09:15:00",
        }
    )

    patch = TicketEditPatch.from_form_values(
        ticket,
        title="Printer is jammed",
        stage=TicketStage.OPEN,
        category_name="category_123456",
        category_title="category_123456",
        reopen="   ",
        description="",
    )

    assert patch.model_dump(exclude_unset=True) == {"reopen": None}


@pytest.mark.parametrize("reopen", ["2026/03/31 09:15:00", "2026-03-31T09:15:00"])
def test_ticket_edit_patch_rejects_reopen_with_wrong_format(reopen: str) -> None:
    ticket = Ticket.model_validate(make_ticket_payload())

    with pytest.raises(
        ValueError,
        match=r"Reopen must use YYYY-MM-DD HH:MM:SS with a real date and time\.",
    ):
        TicketEditPatch.from_form_values(
            ticket,
            title="Printer is jammed",
            stage=TicketStage.OPEN,
            category_name="category_123456",
            category_title="category_123456",
            reopen=reopen,
            description="",
        )


@pytest.mark.parametrize("reopen", ["2026-02-31 09:15:00", "2026-03-31 25:15:00"])
def test_ticket_edit_patch_rejects_impossible_reopen_datetime(reopen: str) -> None:
    ticket = Ticket.model_validate(make_ticket_payload())

    with pytest.raises(
        ValueError,
        match=r"Reopen must use YYYY-MM-DD HH:MM:SS with a real date and time\.",
    ):
        TicketEditPatch.from_form_values(
            ticket,
            title="Printer is jammed",
            stage=TicketStage.OPEN,
            category_name="category_123456",
            category_title="category_123456",
            reopen=reopen,
            description="",
        )


def test_ticket_edit_patch_tracks_category_change_by_name_and_title() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "category": "Delivery",
            "category_name": "categories_delivery",
        }
    )

    patch = TicketEditPatch.from_form_values(
        ticket,
        title="Printer is jammed",
        stage=TicketStage.OPEN,
        category_name="categories_returns",
        category_title="Returns",
        description="",
    )

    assert patch.model_dump(exclude_unset=True) == {
        "category_name": "categories_returns",
        "category_title": "Returns",
    }


def test_ticket_edit_patch_apply_to_updates_category_name_and_title() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "category": "Delivery",
            "category_name": "categories_delivery",
        }
    )

    saved_ticket = TicketEditPatch(
        category_name="categories_returns",
        category_title="Returns",
    ).apply_to(ticket)

    assert saved_ticket.category == "Returns"
    assert saved_ticket.category_name == "categories_returns"


def test_ticket_edit_patch_tracks_user_change_by_name_and_title() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "user": "Operator One",
            "user_name": "operator_1",
        }
    )

    patch = TicketEditPatch.from_form_values(
        ticket,
        title="Printer is jammed",
        stage=TicketStage.OPEN,
        category_name="category_123456",
        category_title="category_123456",
        user_name="operator_2",
        user_title="Operator Two",
        description="",
    )

    assert patch.model_dump(exclude_unset=True) == {
        "user_name": "operator_2",
        "user_title": "Operator Two",
    }


def test_ticket_edit_patch_apply_to_updates_user_name_and_title() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "user": "Operator One",
            "user_name": "operator_1",
        }
    )

    saved_ticket = TicketEditPatch(
        user_name="operator_2",
        user_title="Operator Two",
    ).apply_to(ticket)

    assert saved_ticket.user_name == "operator_2"
    assert saved_ticket.user == "Operator Two"


def test_ticket_edit_patch_clears_user_assignment() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "user": "Operator One",
            "user_name": "operator_1",
        }
    )

    patch = TicketEditPatch.from_form_values(
        ticket,
        title="Printer is jammed",
        stage=TicketStage.OPEN,
        category_name="category_123456",
        category_title="category_123456",
        user_name=None,
        user_title=None,
        description="",
    )

    saved_ticket = patch.apply_to(ticket)

    assert patch.model_dump(exclude_unset=True) == {
        "user_name": None,
        "user_title": None,
    }
    assert saved_ticket.user_name is None
    assert saved_ticket.user is None


def test_ticket_edit_patch_ignores_unchanged_user_when_name_falls_back_to_label() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "user": "operator_1",
        }
    )

    patch = TicketEditPatch.from_form_values(
        ticket,
        title="Printer is jammed",
        stage=TicketStage.OPEN,
        category_name="category_123456",
        category_title="category_123456",
        user_name="operator_1",
        user_title="operator_1",
        description="",
    )

    assert patch.has_changes() is False


def test_ticket_edit_patch_tracks_stage_change() -> None:
    ticket = Ticket.model_validate(make_ticket_payload())

    patch = TicketEditPatch.from_form_values(
        ticket,
        title="Printer is jammed",
        stage=TicketStage.WAIT,
        category_name="category_123456",
        category_title="category_123456",
        description="",
    )

    assert patch.model_dump(exclude_unset=True) == {"stage": TicketStage.WAIT}


def test_ticket_edit_patch_tracks_priority_change() -> None:
    ticket = Ticket.model_validate(make_ticket_payload())

    patch = TicketEditPatch.from_form_values(
        ticket,
        title="Printer is jammed",
        stage=TicketStage.OPEN,
        priority=TicketPriority.LOW,
        category_name="category_123456",
        category_title="category_123456",
        description="",
    )

    assert patch.model_dump(exclude_unset=True) == {"priority": TicketPriority.LOW}


def test_ticket_edit_patch_apply_to_updates_stage() -> None:
    ticket = Ticket.model_validate(make_ticket_payload())

    saved_ticket = TicketEditPatch(stage=TicketStage.CLOSE).apply_to(ticket)

    assert saved_ticket.stage is TicketStage.CLOSE


def test_ticket_edit_patch_apply_to_updates_priority() -> None:
    ticket = Ticket.model_validate(make_ticket_payload())

    saved_ticket = TicketEditPatch(priority=TicketPriority.LOW).apply_to(ticket)

    assert saved_ticket.priority is TicketPriority.LOW


def test_ticket_edit_patch_apply_to_updates_reopen() -> None:
    ticket = Ticket.model_validate(make_ticket_payload())

    saved_ticket = TicketEditPatch(reopen=datetime(2026, 3, 31, 9, 15, 0)).apply_to(ticket)

    assert saved_ticket.reopen == datetime(2026, 3, 31, 9, 15, 0)


def test_ticket_edit_patch_apply_to_clears_reopen() -> None:
    ticket = Ticket.model_validate(
        {
            **make_ticket_payload(),
            "reopen": "2026-03-31 09:15:00",
        }
    )

    saved_ticket = TicketEditPatch(reopen=None).apply_to(ticket)

    assert saved_ticket.reopen is None


def test_ticket_category_option_accepts_minimal_payload() -> None:
    option = TicketCategoryOption.model_validate(
        {
            "name": "categories_delivery",
            "title": "Delivery",
        }
    )

    assert option.name == "categories_delivery"
    assert option.title == "Delivery"


def test_ticket_user_option_accepts_minimal_payload() -> None:
    option = TicketUserOption.model_validate(
        {
            "name": "operator_1",
            "title": "Operator One",
        }
    )

    assert option.name == "operator_1"
    assert option.title == "Operator One"


def test_ticket_view_accepts_minimal_required_payload() -> None:
    ticket_view = TicketView.model_validate(make_ticket_view_payload())

    assert ticket_view.title == "Open high priority tickets"


def test_ticket_view_requires_documented_required_fields() -> None:
    with pytest.raises(ValidationError) as excinfo:
        TicketView.model_validate({})

    errors = {error["loc"][0] for error in excinfo.value.errors()}
    assert errors == {"title"}


def test_ticket_view_accepts_json_object_settings() -> None:
    ticket_view = TicketView.model_validate(
        {
            **make_ticket_view_payload(),
            "filter": {"stage": ["OPEN"], "priority": ["HIGH"]},
            "sort": {"created": "desc"},
            "limit": {"count": 50},
            "default_settings": {"columns": ["title", "priority"]},
        }
    )

    assert ticket_view.filter == {"stage": ["OPEN"], "priority": ["HIGH"]}
    assert ticket_view.sort == {"created": "desc"}
    assert ticket_view.limit == {"count": 50}
    assert ticket_view.default_settings == {"columns": ["title", "priority"]}


def test_ticket_view_parses_basic_scalar_fields() -> None:
    ticket_view = TicketView.model_validate(
        {
            **make_ticket_view_payload(),
            "view": 42,
            "name": "open_high_priority",
            "count": "12",
            "parentView": "team_views",
            "deleted": False,
        }
    )

    assert ticket_view.view == 42
    assert ticket_view.name == "open_high_priority"
    assert ticket_view.ticket_count == 12
    assert ticket_view.parent_view == "team_views"
    assert ticket_view.deleted is False


def test_ticket_view_accepts_parent_view_by_python_field_name() -> None:
    ticket_view = TicketView(title="Open", parent_view="team_views", ticket_count=7)

    assert ticket_view.parent_view == "team_views"
    assert ticket_view.ticket_count == 7


def test_ticket_view_selection_key_prefers_view_then_name_then_title() -> None:
    assert TicketView(title="Open", view=12, name="open").selection_key() == ("view", "12")
    assert TicketView(title="Open", name="open").selection_key() == ("name", "open")
    assert TicketView(title="Open").selection_key() == ("title", "Open")


def test_ticket_view_ignores_unknown_api_fields() -> None:
    ticket_view = TicketView.model_validate(
        {
            **make_ticket_view_payload(),
            "unknownField": "ignored",
        }
    )

    assert "unknownField" not in ticket_view.model_dump()


def test_app_state_uses_independent_default_lists() -> None:
    left_state = AppState()
    right_state = AppState()

    left_state.tickets.append(Ticket.model_validate(make_ticket_payload()))
    left_state.views.append(TicketView.model_validate(make_ticket_view_payload()))

    assert right_state.tickets == []
    assert right_state.views == []


def test_app_state_defaults_ticket_grid_columns_to_supported_order() -> None:
    assert AppState().ticket_grid_column_keys == list(TICKET_GRID_DEFAULT_COLUMN_KEYS)


def test_ticket_pagination_normalizes_bool_and_invalid_inputs() -> None:
    pagination = TicketPagination.model_validate(
        {
            "current_page": True,
            "total_pages": "bad",
            "total_tickets": "bad",
        }
    )

    assert pagination.current_page == 1
    assert pagination.total_pages == 1
    assert pagination.total_tickets == 0


def test_ticket_pagination_clamps_negative_totals_and_page_numbers() -> None:
    pagination = TicketPagination(
        current_page=-5,
        total_pages=0,
        total_tickets=-10,
    )

    assert pagination.current_page == 1
    assert pagination.total_pages == 1
    assert pagination.total_tickets == 0


def test_ticket_pagination_normalizes_boolean_ticket_totals_to_zero() -> None:
    assert TicketPagination.model_validate({"total_tickets": True}).total_tickets == 0


def test_normalize_ticket_grid_column_keys_forces_name_and_title_to_front() -> None:
    assert normalize_ticket_grid_column_keys(["priority", "edited"]) == [
        "name",
        "title",
        "priority",
        "edited",
    ]


def test_normalize_ticket_grid_column_keys_removes_duplicates_and_unsupported_values() -> None:
    assert normalize_ticket_grid_column_keys(
        [
            "edited",
            "priority",
            "priority",
            "unsupported",
            "title",
            "edited",
        ]
    ) == [
        "name",
        "title",
        "edited",
        "priority",
    ]


def test_normalize_ticket_grid_column_keys_falls_back_to_default_order_when_no_supported_keys_exist() -> None:
    assert normalize_ticket_grid_column_keys([]) == list(TICKET_GRID_DEFAULT_COLUMN_KEYS)
    assert normalize_ticket_grid_column_keys(["unsupported"]) == list(
        TICKET_GRID_DEFAULT_COLUMN_KEYS
    )


def test_normalize_ticket_grid_column_keys_accepts_single_string_input() -> None:
    assert normalize_ticket_grid_column_keys("edited") == [
        "name",
        "title",
        "edited",
    ]


def test_normalize_ticket_grid_column_keys_ignores_non_iterables_and_non_string_members() -> None:
    assert normalize_ticket_grid_column_keys(123) == list(TICKET_GRID_DEFAULT_COLUMN_KEYS)
    assert normalize_ticket_grid_column_keys(["edited", 123]) == [
        "name",
        "title",
        "edited",
    ]


def test_app_state_model_copy_normalizes_ticket_grid_columns() -> None:
    state = AppState().model_copy(
        update={
            "ticket_grid_column_keys": [
                "user.title",
                "unsupported",
                "user.title",
            ]
        }
    )

    assert state.ticket_grid_column_keys == [
        "name",
        "title",
        "user.title",
    ]
