from __future__ import annotations

import logging
import os
from datetime import datetime
from typing import Any, cast

import httpx
import pytest

from daktela_paleo.connectors.daktela import (
    BadTokenDaktelaError,
    CantConnectToDaktelaError,
    DaktelaEmailDetails,
    DaktelaConnectorError,
    VIEW_TICKET_QUERY_LIMIT,
    DaktelaTicketConnector,
    _custom_field_scheme_map_from_payload,
    _normalize_custom_field_scheme_map,
    _nested_name,
    _nested_named_string_map,
    _nested_string_list,
    _normalize_custom_fields,
    _ticket_reference_value,
    _string_value,
    _sys_model,
    flatten,
)
from daktela_paleo.models import (
    Ticket,
    TicketActivity,
    TicketActivityAttachment,
    TicketCategoryOption,
    TicketCommentAttachmentUpload,
    TicketCommentCreateRequest,
    TicketCustomField,
    TicketCustomFieldOption,
    TicketEmailAction,
    TicketEmailDraft,
    TicketEmailSendRequest,
    TicketEditPatch,
    TicketPagination,
    TicketPriority,
    TicketStatusOption,
    TicketStage,
    TICKET_GRID_DEFAULT_COLUMN_KEYS,
    TicketUserOption,
    TicketView,
)

LIVE_EMAIL_TEST_ADDRESS = "tomas.lysek@daktela.com"


class ResponseStub:
    def __init__(
        self,
        *,
        status_code: int,
        payload: Any | None = None,
        content: bytes = b"",
        json_error: Exception | None = None,
    ) -> None:
        self.status_code = status_code
        self._payload = payload
        self.content = content
        self._json_error = json_error

    def json(self) -> Any:
        if self._json_error is not None:
            raise self._json_error
        return self._payload


def _validate_live_email_test_recipient(address: str) -> str:
    normalized = address.strip().casefold()
    if normalized != LIVE_EMAIL_TEST_ADDRESS:
        raise ValueError(
            "Live email send tests may only target tomas.lysek@daktela.com."
        )
    return LIVE_EMAIL_TEST_ADDRESS


def make_email_activity(
    *,
    activity_name: str = "activities_1",
    email_name: str | None = "emails_1",
) -> TicketActivity:
    item = {"model": "activitiesEmail"} if email_name is None else {"model": "activitiesEmail", "name": email_name}
    return TicketActivity.model_validate(
        {
            "name": activity_name,
            "type": "EMAIL",
            "title": "Original subject",
            "item": item,
        }
    )


def make_ticket_payload_with_custom_fields(
    *,
    include_scheme: bool = True,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "name": 42,
        "title": "Real ticket",
        "category": {"name": "categories_1", "title": "Delivery"},
        "contact": {"name": "contacts_1", "title": "VIP Client"},
        "user": {
            "name": "operator_1",
            "title": "Operator One",
        },
        "created_by": {"name": "creator_1"},
        "edited_by": {
            "name": "editor_1",
            "title": "Editor One",
        },
        "statuses": [
            {"name": "status_open", "title": "Open"},
            {"name": "status_waiting", "title": "Waiting"},
        ],
        "customFields": {
            "consultant": ["alice"],
            "serial_number": ["SN-42", "SN-43"],
            "replacement_required": ["YES"],
        },
        "stage": "OPEN",
        "priority": "HIGH",
    }
    if include_scheme:
        payload["_sys"] = {
            "cfScheme": {
                "consultant": {
                    "title": "Consultant",
                    "type": "select",
                    "options": [
                        {"value": "alice", "title": "Alice"},
                        {"value": "bob", "title": "Bob"},
                    ],
                },
                "serial_number": {
                    "title": "Serial Number",
                    "type": "text",
                },
                "replacement_required": {
                    "title": "Replacement Required",
                    "type": "checkbox",
                    "options": {
                        "YES": "Yes",
                        "NO": "No",
                    },
                },
                "unused_field": {
                    "title": "Unused Field",
                    "type": "text",
                },
            }
        }
    return payload


@pytest.fixture
def live_daktela_connector() -> DaktelaTicketConnector:
    pbx_name = os.environ.get("DAKTELA_PBX_NAME")
    user_token = os.environ.get("DAKTELA_USER_TOKEN")
    if not pbx_name or not user_token:
        pytest.skip("Live Daktela tests require DAKTELA_PBX_NAME and DAKTELA_USER_TOKEN.")
    return DaktelaTicketConnector(pbx_name, user_token)


@pytest.fixture
def live_daktela_user_assignment_target() -> tuple[int, str]:
    ticket_id = os.environ.get("DAKTELA_TEST_TICKET_ID")
    user_name = os.environ.get("DAKTELA_TEST_ASSIGNABLE_USER_NAME")
    if not ticket_id or not user_name:
        pytest.skip(
            "Live Daktela write tests require DAKTELA_TEST_TICKET_ID and "
            "DAKTELA_TEST_ASSIGNABLE_USER_NAME."
        )
    return int(ticket_id), user_name


@pytest.fixture
def live_daktela_comment_target() -> int:
    ticket_id = os.environ.get("DAKTELA_TEST_COMMENT_TICKET_ID")
    if not ticket_id:
        pytest.skip("Live Daktela comment-write test requires DAKTELA_TEST_COMMENT_TICKET_ID.")
    return int(ticket_id)


@pytest.fixture
def live_daktela_email_send_target() -> tuple[int, str]:
    ticket_id = os.environ.get("DAKTELA_TEST_EMAIL_TICKET_ID")
    email_to = os.environ.get("DAKTELA_TEST_EMAIL_TO")
    if not ticket_id or not email_to:
        pytest.skip(
            "Live Daktela email-send tests require DAKTELA_TEST_EMAIL_TICKET_ID and "
            "DAKTELA_TEST_EMAIL_TO."
        )
    return int(ticket_id), _validate_live_email_test_recipient(email_to)

# temporary tests start 
def test_flatten_uses_mailbot_style_bracket_notation() -> None:
    flattened = flatten(
        {
            "filter": {
                "filters": [
                    {"field": "ticket.name", "value": [1001, 1002]},
                ]
            }
        },
        False,
        "[",
        "]",
    )

    assert flattened == {
        "filter[filters][0][field]": "ticket.name",
        "filter[filters][0][value][0]": 1001,
        "filter[filters][0][value][1]": 1002,
    }


def test_daktela_ticket_connector_normalizes_pbx_name() -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    assert connector.pbx_name == "https://demo.daktela.com"


def test_daktela_ticket_connector_builds_ticket_browser_url_from_name() -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )

    assert connector.ticket_browser_url(ticket) == "https://demo.daktela.com/tickets/update/42"


def test_daktela_ticket_connector_ticket_browser_url_prefers_name_over_ticket() -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        ticket=77,
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )

    assert connector.ticket_browser_url(ticket) == "https://demo.daktela.com/tickets/update/42"


def test_daktela_ticket_connector_ticket_browser_url_falls_back_to_ticket_id() -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        ticket=77,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )

    assert connector.ticket_browser_url(ticket) == "https://demo.daktela.com/tickets/update/77"


def test_daktela_ticket_connector_ticket_browser_url_returns_none_without_identity() -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )

    assert connector.ticket_browser_url(ticket) is None


def test_daktela_ticket_connector_builds_view_browser_url_from_name() -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    view = TicketView(name="views_56cb1b3b23717310986148", title="Returns")

    assert (
        connector.view_browser_url(view)
        == "https://demo.daktela.com/tickets/#views_56cb1b3b23717310986148"
    )


def test_daktela_ticket_connector_view_browser_url_returns_none_without_name() -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    view = TicketView(view=56, title="Returns")

    assert connector.view_browser_url(view) is None


def test_daktela_ticket_connector_resolves_relative_activity_asset_url_with_access_token() -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    assert connector.resolve_activity_asset_url("/file/image.php?mapper=activities&name=5") == (
        "https://demo.daktela.com/file/image.php?mapper=activities&name=5&accessToken=token-123"
    )


def test_daktela_ticket_connector_preserves_existing_access_token_when_resolving_activity_asset_url() -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    assert connector.resolve_activity_asset_url(
        "https://demo.daktela.com/file/image.php?mapper=activities&name=5&accessToken=custom"
    ) == (
        "https://demo.daktela.com/file/image.php?mapper=activities&name=5&accessToken=custom"
    )


def test_daktela_ticket_connector_rejects_unsupported_activity_asset_url_scheme() -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    assert connector.resolve_activity_asset_url("ftp://example.test/image.png") is None


@pytest.mark.asyncio
async def test_daktela_ticket_connector_load_activity_asset_uses_resolved_authenticated_url(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    calls: list[tuple[str, str]] = []

    async def fake_send_request(method: str, url: str, **kwargs: Any) -> ResponseStub:
        calls.append((method, url))
        assert kwargs == {}
        return ResponseStub(status_code=200, content=b"png-bytes")

    monkeypatch.setattr(connector, "_send_request", fake_send_request)

    content = await connector.load_activity_asset("/file/image.php?mapper=activities&name=5")

    assert content == b"png-bytes"
    assert calls == [
        (
            "GET",
            "https://demo.daktela.com/file/image.php?mapper=activities&name=5&accessToken=token-123",
        )
    ]


@pytest.mark.asyncio
async def test_daktela_ticket_connector_load_activity_asset_rejects_unsupported_url() -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    with pytest.raises(DaktelaConnectorError, match="Unsupported activity asset URL"):
        await connector.load_activity_asset("ftp://example.test/image.png")


@pytest.mark.asyncio
async def test_daktela_ticket_connector_load_activity_asset_raises_on_http_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_send_request(method: str, url: str, **kwargs: Any) -> ResponseStub:
        assert method == "GET"
        assert url == (
            "https://demo.daktela.com/file/image.php?mapper=activities&name=5&accessToken=token-123"
        )
        assert kwargs == {}
        return ResponseStub(status_code=404)

    monkeypatch.setattr(connector, "_send_request", fake_send_request)

    with pytest.raises(DaktelaConnectorError, match="status 404"):
        await connector.load_activity_asset("/file/image.php?mapper=activities&name=5")


def test_daktela_ticket_connector_response_error_handles_supported_shapes() -> None:
    assert DaktelaTicketConnector._response_error(None) is None
    assert DaktelaTicketConnector._response_error({"error": None}) is None
    assert DaktelaTicketConnector._response_error({"error": []}) is None
    assert DaktelaTicketConnector._response_error({"error": {}}) is None
    assert DaktelaTicketConnector._response_error({"error": ""}) is None
    assert DaktelaTicketConnector._response_error("boom") is None
    assert DaktelaTicketConnector._response_error({"error": "boom"}) == "boom"
    assert DaktelaTicketConnector._response_error({"error": "Permission denied"}) == "Permission denied"
    assert DaktelaTicketConnector._response_error({"error": ["boom", 7]}) == "boom; 7"
    assert DaktelaTicketConnector._response_error({"error": ["first", 2]}) == "first; 2"
    assert DaktelaTicketConnector._response_error({"error": {"ticket": "missing"}}) == (
        "ticket: missing"
    )
    assert (
        DaktelaTicketConnector._response_error({"error": {"code": 403, "detail": "forbidden"}})
        == "code: 403; detail: forbidden"
    )
    assert DaktelaTicketConnector._response_error({"error": 42}) == "42"


def test_validate_live_email_test_recipient_accepts_allowed_address() -> None:
    assert _validate_live_email_test_recipient("  tomas.lysek@daktela.com ") == (
        LIVE_EMAIL_TEST_ADDRESS
    )


def test_validate_live_email_test_recipient_rejects_other_addresses() -> None:
    with pytest.raises(ValueError, match="only target tomas.lysek@daktela.com"):
        _validate_live_email_test_recipient("other@example.com")


def test_daktela_ticket_connector_reply_recipient_resolution_prefers_reply_to_then_address() -> None:
    assert DaktelaTicketConnector._reply_recipients(
        DaktelaEmailDetails(
            activity_name="activities_1",
            email_name="emails_1",
            subject="Subject",
            address="customer@example.com",
            queue_name="queues_1",
            queue_address="queue@example.com",
            header_to_all=("queue@example.com",),
            reply_to_all=("reply@example.com", "backup@example.com"),
        )
    ) == ("reply@example.com", "backup@example.com")

    assert DaktelaTicketConnector._reply_recipients(
        DaktelaEmailDetails(
            activity_name="activities_1",
            email_name="emails_1",
            subject="Subject",
            address="customer@example.com",
            queue_name="queues_1",
            queue_address="queue@example.com",
            header_to_all=("queue@example.com",),
            reply_to_all=(),
        )
    ) == ("customer@example.com",)


def test_daktela_ticket_connector_reply_recipient_resolution_falls_back_to_headers_and_queue() -> None:
    assert DaktelaTicketConnector._reply_recipients(
        DaktelaEmailDetails(
            activity_name="activities_1",
            email_name="emails_1",
            subject="Subject",
            address=None,
            queue_name="queues_1",
            queue_address="queue@example.com",
            header_to_all=("header@example.com",),
            reply_to_all=(),
        )
    ) == ("header@example.com",)

    assert DaktelaTicketConnector._reply_recipients(
        DaktelaEmailDetails(
            activity_name="activities_1",
            email_name="emails_1",
            subject="Subject",
            address=None,
            queue_name="queues_1",
            queue_address="queue@example.com",
            header_to_all=(),
            reply_to_all=(),
        )
    ) == ("queue@example.com",)

    assert DaktelaTicketConnector._reply_recipients(
        DaktelaEmailDetails(
            activity_name="activities_1",
            email_name="emails_1",
            subject="Subject",
            address=None,
            queue_name="queues_1",
            queue_address=None,
            header_to_all=(),
            reply_to_all=(),
        )
    ) == ()


def test_daktela_ticket_connector_subject_helpers_preserve_existing_prefixes() -> None:
    assert DaktelaTicketConnector._reply_subject("Subject") == "Re: Subject"
    assert DaktelaTicketConnector._reply_subject("Re: Subject") == "Re: Subject"
    assert DaktelaTicketConnector._forward_subject("Subject") == "Fwd: Subject"
    assert DaktelaTicketConnector._forward_subject("FW: Subject") == "FW: Subject"
    assert DaktelaTicketConnector._forward_subject("") == ""


def test_daktela_ticket_connector_forward_original_message_helper_handles_present_and_missing_options() -> None:
    assert DaktelaTicketConnector._forward_original_message_from_result(
        {"options": {"message": "<p>Original</p>"}}
    ) == "<p>Original</p>"
    assert DaktelaTicketConnector._forward_original_message_from_result({}) is None


def test_daktela_ticket_connector_merge_forward_message_handles_supported_shapes() -> None:
    assert DaktelaTicketConnector._merge_forward_message("Body", "Original") == "Body<br/>Original"
    assert DaktelaTicketConnector._merge_forward_message("", "Original") == "Original"
    assert DaktelaTicketConnector._merge_forward_message("Body", "") == "Body"


def test_daktela_ticket_connector_header_addresses_ignores_invalid_payloads() -> None:
    assert DaktelaTicketConnector._header_addresses(None, "to") == ()
    assert DaktelaTicketConnector._header_addresses({"to": "invalid"}, "to") == ()
    assert DaktelaTicketConnector._header_addresses(
        {"to": [{"address": "a@example.com"}, "skip-me", {"address": ""}, {"x": "missing"}]},
        "to",
    ) == ("a@example.com",)


def test_daktela_ticket_connector_email_name_from_activity_payload_requires_email_model() -> None:
    assert DaktelaTicketConnector._email_name_from_activity_payload(
        {"item": {"name": "emails_1", "_sys": {"model": "activitiesEmail"}}}
    ) == "emails_1"
    assert DaktelaTicketConnector._email_name_from_activity_payload({"item": "emails_1"}) is None
    assert DaktelaTicketConnector._email_name_from_activity_payload(
        {"item": {"name": "emails_1", "_sys": {"model": "activitiesComment"}}}
    ) is None


def test_daktela_ticket_connector_result_object_raises_for_missing_result() -> None:
    with pytest.raises(DaktelaConnectorError, match="missing result"):
        DaktelaTicketConnector._result_object({}, "missing result")


def test_daktela_ticket_connector_email_details_require_queue_name() -> None:
    with pytest.raises(DaktelaConnectorError, match="missing a queue"):
        DaktelaTicketConnector._email_details_from_payload(
            {"title": "Subject", "options": {"headers": {}}},
            source_email_name="emails_1",
            fallback_activity_name="activities_1",
        )


def test_daktela_ticket_connector_email_details_prefer_queue_identifier_over_title() -> None:
    details = DaktelaTicketConnector._email_details_from_payload(
        {
            "title": "Subject",
            "queue": {
                "name": "queues_1",
                "title": "Emailbot E2E test",
                "options": {"address": "queue@example.com"},
            },
            "options": {"headers": {}},
        },
        source_email_name="emails_1",
        fallback_activity_name="activities_1",
    )

    assert details.queue_name == "queues_1"
    assert details.queue_address == "queue@example.com"


def test_daktela_ticket_connector_email_details_fall_back_to_queue_title_then_queue_key() -> None:
    details_from_title = DaktelaTicketConnector._email_details_from_payload(
        {
            "title": "Subject",
            "queue": {
                "title": "Emailbot E2E test",
            },
            "options": {"headers": {}},
        },
        source_email_name="emails_1",
        fallback_activity_name="activities_1",
    )
    details_from_queue_key = DaktelaTicketConnector._email_details_from_payload(
        {
            "title": "Subject",
            "queue": {
                "queue": "queues_fallback",
            },
            "options": {"headers": {}},
        },
        source_email_name="emails_1",
        fallback_activity_name="activities_1",
    )

    assert details_from_title.queue_name == "Emailbot E2E test"
    assert details_from_queue_key.queue_name == "queues_fallback"


def test_daktela_ticket_connector_maps_nested_ticket_payloads() -> None:
    ticket = DaktelaTicketConnector._ticket_from_payload(make_ticket_payload_with_custom_fields())

    assert ticket.name == 42
    assert ticket.category == "Delivery"
    assert ticket.category_name == "categories_1"
    assert ticket.contact == "VIP Client"
    assert ticket.user == "Operator One"
    assert ticket.user_name == "operator_1"
    assert ticket.created_by == "creator_1"
    assert ticket.edited_by == "Editor One"
    assert ticket.statuses == {
        "status_open": "Open",
        "status_waiting": "Waiting",
    }
    assert ticket.customFields == [
        TicketCustomField(
            field="consultant",
            title="Consultant",
            values=["alice"],
            field_type="select",
            options=[
                TicketCustomFieldOption(value="alice", title="Alice"),
                TicketCustomFieldOption(value="bob", title="Bob"),
            ],
        ),
        TicketCustomField(
            field="serial_number",
            title="Serial Number",
            values=["SN-42", "SN-43"],
            field_type="text",
        ),
        TicketCustomField(
            field="replacement_required",
            title="Replacement Required",
            values=["YES"],
            field_type="checkbox",
            options=[
                TicketCustomFieldOption(value="YES", title="Yes"),
                TicketCustomFieldOption(value="NO", title="No"),
            ],
        ),
    ]


def test_daktela_ticket_connector_maps_nested_id_merge_payloads() -> None:
    payload = make_ticket_payload_with_custom_fields()
    payload["id_merge"] = {
        "name": 602226,
        "title": "Merged ticket",
    }

    ticket = DaktelaTicketConnector._ticket_from_payload(payload)

    assert ticket.id_merge == "602226"


def test_ticket_reference_value_normalizes_supported_shapes() -> None:
    assert _ticket_reference_value(None) is None
    assert _ticket_reference_value("ticket_42") == "ticket_42"
    assert _ticket_reference_value(77) == "77"
    assert _ticket_reference_value(["bad"]) is None
    assert _ticket_reference_value({"name": "ticket_43"}) == "ticket_43"
    assert _ticket_reference_value({"ticket": 88}) == "88"
    assert _ticket_reference_value({"title": "Missing identifier"}) is None


def test_daktela_ticket_connector_custom_fields_fall_back_without_scheme_metadata() -> None:
    ticket = DaktelaTicketConnector._ticket_from_payload(
        make_ticket_payload_with_custom_fields(include_scheme=False)
    )

    assert ticket.customFields == [
        TicketCustomField(
            field="consultant",
            title="consultant",
            values=["alice"],
        ),
        TicketCustomField(
            field="serial_number",
            title="serial_number",
            values=["SN-42", "SN-43"],
        ),
        TicketCustomField(
            field="replacement_required",
            title="replacement_required",
            values=["YES"],
        ),
    ]


def test_normalize_custom_fields_tolerates_partial_and_incomplete_scheme_entries() -> None:
    assert _normalize_custom_fields(
        {
            "consultant": ["alice"],
            "replacement_required": ["YES"],
            "follow_up_at": "2026-03-30 09:15:00",
        },
        {
            "consultant": {
                "title": "Consultant",
                "type": "select",
                "options": [{"name": "alice", "label": "Alice"}],
            },
            "replacement_required": {
                "options": {"YES": "Yes", "NO": "No"},
            },
        },
    ) == [
        {
            "field": "consultant",
            "title": "Consultant",
            "values": ["alice"],
            "field_type": "select",
            "options": [
                {"value": "alice", "title": "Alice"},
            ],
        },
        {
            "field": "replacement_required",
            "title": "replacement_required",
            "values": ["YES"],
            "field_type": None,
            "options": [
                {"value": "YES", "title": "Yes"},
                {"value": "NO", "title": "No"},
            ],
        },
        {
            "field": "follow_up_at",
            "title": "follow_up_at",
            "values": ["2026-03-30 09:15:00"],
            "field_type": None,
            "options": None,
        },
    ]


def test_normalize_custom_fields_supports_nested_scheme_collections_and_option_edge_cases() -> None:
    scheme_by_field = _custom_field_scheme_map_from_payload(
        {
            "_sys": {
                "cfScheme": {
                    "fields": [
                        {
                            "name": "consultant",
                            "title": "Consultant",
                            "type": "select",
                            "options": [
                                {"name": "alice", "label": "Alice"},
                                {"label": "Skip missing value"},
                                "bob",
                            ],
                        },
                        {
                            "name": "follow_up_at",
                            "title": "Follow Up At",
                            "type": "datetime",
                            "options": "broken",
                        },
                    ]
                }
            }
        }
    )

    assert _normalize_custom_fields(
        {
            "consultant": ("alice", "bob"),
            "follow_up_at": ["2026-03-30 09:15:00"],
        },
        scheme_by_field,
    ) == [
        {
            "field": "consultant",
            "title": "Consultant",
            "values": ["alice", "bob"],
            "field_type": "select",
            "options": [
                {"value": "alice", "title": "Alice"},
                {"value": "bob", "title": "bob"},
            ],
        },
        {
            "field": "follow_up_at",
            "title": "Follow Up At",
            "values": ["2026-03-30 09:15:00"],
            "field_type": "datetime",
            "options": None,
        },
    ]


def test_normalize_custom_field_scheme_map_ignores_unsupported_shapes() -> None:
    assert _normalize_custom_field_scheme_map(
        {
            "fields": None,
            "items": None,
            "data": None,
            "customFields": None,
        }
    ) == {}
    assert _normalize_custom_field_scheme_map("broken") == {}
    assert _normalize_custom_field_scheme_map(
        [
            "broken",
            {"label": "Missing field identifier"},
        ]
    ) == {}


def test_daktela_ticket_connector_maps_activity_payloads() -> None:
    activity = DaktelaTicketConnector._activity_from_payload(
        {
            "name": "activities_1",
            "type": "EMAIL",
            "title": "Fwd: test",
            "time": "2026-03-28 10:30:00",
            "description": "",
            "user": {
                "name": "operator_1",
                "title": "Operator One",
            },
            "created_by": {
                "name": "creator_1",
                "title": "Creator One",
            },
            "item": {
                "name": "emails_1",
                "title": "Nested title",
                "time": "2026-03-28 10:30:00",
                "text": "<p>Hello<br />world</p>",
                "address": "client@example.com",
                "queue": {"name": "queues_1"},
                "direction": "out",
                "state": "SENT",
                "_sys": {"model": "activitiesEmail"},
            },
        }
    )

    assert activity.name == "activities_1"
    assert activity.type == "EMAIL"
    assert activity.title == "Fwd: test"
    assert activity.user == "Operator One"
    assert activity.user_name == "operator_1"
    assert activity.created_by == "Creator One"
    assert activity.created_by_name == "creator_1"
    assert activity.item is not None
    assert activity.item.name == "emails_1"
    assert activity.item.model == "activitiesEmail"
    assert activity.item.body_html == "<p>Hello<br />world</p>"
    assert activity.item.address == "client@example.com"
    assert activity.item.queue_name == "queues_1"
    assert activity.item.direction == "out"
    assert activity.item.state == "SENT"


def test_daktela_ticket_connector_maps_activity_attachments() -> None:
    activity = DaktelaTicketConnector._activity_from_payload(
        {
            "name": "activities_1",
            "type": "",
            "attachments": [
                {
                    "file": 6,
                    "title": "April report.txt",
                    "type": "text/plain",
                    "size": 2556,
                }
            ],
            "item": {
                "name": "emails_1",
                "_sys": {"model": "activitiesEmail"},
                "attachments": [
                    {
                        "file": "7",
                        "title": "invoice.pdf",
                        "type": "application/pdf",
                        "size": 512,
                    }
                ],
            },
        }
    )

    assert activity.attachments == [
        TicketActivityAttachment(
            file="6",
            title="April report.txt",
            type="text/plain",
            size=2556,
            inline=False,
        )
    ]
    assert activity.item is not None
    assert activity.item.attachments == [
        TicketActivityAttachment(
            file="7",
            title="invoice.pdf",
            type="application/pdf",
            size=512,
            inline=False,
        )
    ]


def test_daktela_ticket_connector_maps_comment_item_content_into_description() -> None:
    activity = DaktelaTicketConnector._activity_from_payload(
        {
            "type": "",
            "item": {
                "content": "Saved comment body",
                "_sys": {"model": "activitiesComment"},
            },
        }
    )

    assert activity.item is not None
    assert activity.item.model == "activitiesComment"
    assert activity.item.description == "Saved comment body"


def test_daktela_ticket_connector_preserves_blank_activity_type_for_comment_mapping() -> None:
    activity = DaktelaTicketConnector._activity_from_payload(
        {
            "type": "",
            "created_by": {"name": "creator_1"},
            "item": None,
        }
    )

    assert activity.type == ""
    assert activity.created_by == "creator_1"
    assert activity.item is None
    assert activity.display_type == "Comment"


def test_daktela_ticket_connector_maps_missing_activity_type_to_none() -> None:
    activity = DaktelaTicketConnector._activity_from_payload(
        {
            "created_by": {"name": "creator_1"},
            "item": None,
        }
    )

    assert activity.type is None
    assert activity.display_type == "Activity"


def test_daktela_ticket_connector_builds_comment_attachment_download_path() -> None:
    path = DaktelaTicketConnector._activity_attachment_download_path(
        TicketActivity.model_validate({"type": "", "name": "activities_1"}),
        TicketActivityAttachment(file="6", title="April report.txt"),
    )

    assert path == "/file/download.php?mapper=activitiesComment&name=6&download=1"


def test_daktela_ticket_connector_builds_email_attachment_download_path() -> None:
    path = DaktelaTicketConnector._activity_attachment_download_path(
        TicketActivity.model_validate(
            {
                "type": "EMAIL",
                "name": "activities_1",
                "item": {"model": "activitiesEmail"},
            }
        ),
        TicketActivityAttachment(file="7", title="invoice.pdf"),
    )

    assert path == "/file/download.php?mapper=activitiesEmail&name=7&download=1"


@pytest.mark.asyncio
async def test_daktela_ticket_connector_load_ticket_activity_attachment_uses_private_request(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    activity = TicketActivity.model_validate({"type": "", "name": "activities_1"})
    attachment = TicketActivityAttachment(file="6", title="April report.txt")
    calls: list[str] = []

    async def fake_send_get_private_request(url: str, **kwargs: Any) -> ResponseStub:
        calls.append(url)
        assert kwargs == {}
        return ResponseStub(status_code=200, content=b"file-bytes")

    monkeypatch.setattr(connector, "_send_get_private_request", fake_send_get_private_request)

    content = await connector.load_ticket_activity_attachment(activity, attachment)

    assert content == b"file-bytes"
    assert calls == ["/file/download.php?mapper=activitiesComment&name=6&download=1"]


@pytest.mark.asyncio
async def test_daktela_ticket_connector_load_ticket_activity_attachment_raises_on_http_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    activity = TicketActivity.model_validate({"type": "", "name": "activities_1"})
    attachment = TicketActivityAttachment(file="6", title="April report.txt")

    async def fake_send_get_private_request(url: str, **kwargs: Any) -> ResponseStub:
        assert url == "/file/download.php?mapper=activitiesComment&name=6&download=1"
        assert kwargs == {}
        return ResponseStub(status_code=404, content=b"")

    monkeypatch.setattr(connector, "_send_get_private_request", fake_send_get_private_request)

    with pytest.raises(DaktelaConnectorError, match="status 404"):
        await connector.load_ticket_activity_attachment(activity, attachment)


def test_daktela_ticket_connector_rejects_unsupported_attachment_download_mapper() -> None:
    with pytest.raises(
        DaktelaConnectorError,
        match="does not support attachment downloads",
    ):
        DaktelaTicketConnector._activity_attachment_download_path(
            TicketActivity.model_validate({"type": "CALL", "name": "activities_1"}),
            TicketActivityAttachment(file="6", title="April report.txt"),
        )


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_current_user_returns_none_for_invalid_user_payload(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_get_whoiam_result() -> dict[str, Any]:
        return {"user": []}

    monkeypatch.setattr(connector, "_get_whoiam_result", fake_get_whoiam_result)

    assert await connector.get_current_user() is None


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_current_user_returns_none_for_invalid_name_or_title(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_get_whoiam_result() -> dict[str, Any]:
        return {"user": {"name": 7, "title": None}}

    monkeypatch.setattr(connector, "_get_whoiam_result", fake_get_whoiam_result)

    assert await connector.get_current_user() is None


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_current_user_returns_valid_user(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_get_whoiam_result() -> dict[str, Any]:
        return {"user": {"name": "operator_2", "title": "Operator Two"}}

    monkeypatch.setattr(connector, "_get_whoiam_result", fake_get_whoiam_result)

    assert await connector.get_current_user() == TicketUserOption(
        name="operator_2",
        title="Operator Two",
    )


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_ticket_grid_column_keys_returns_none_for_invalid_profile_payload(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_get_whoiam_result() -> dict[str, Any]:
        return {"user": []}

    monkeypatch.setattr(connector, "_get_whoiam_result", fake_get_whoiam_result)

    assert await connector.get_ticket_grid_column_keys() is None


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_ticket_grid_column_keys_reads_top_level_custom_grid_columns(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_get_whoiam_result() -> dict[str, Any]:
        return {
            "customGridColumns": {
                "tickets": [
                    {"alias": "tickets", "name": "priority"},
                    {"alias": "tickets", "name": "sla_deadtime"},
                    {"alias": "tickets", "name": "category.title"},
                    {"alias": "tickets", "name": "contact.title"},
                    {"alias": "tickets", "name": "user.title"},
                    {"alias": "tickets", "name": "statuses"},
                    {"alias": "tickets", "name": "stage"},
                    {"alias": "tickets", "name": "edited"},
                    {"alias": "tickets", "name": "edited_by"},
                ]
            },
            "user": {"profile": {}},
        }

    monkeypatch.setattr(connector, "_get_whoiam_result", fake_get_whoiam_result)

    assert await connector.get_ticket_grid_column_keys() == [
        "name",
        "title",
        "priority",
        "sla_deadtime",
        "category.title",
        "contact.title",
        "user.title",
        "statuses",
        "stage",
        "edited",
        "edited_by",
    ]


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "whoiam_result",
    [
        {"user": {"profile": []}},
        {"user": {"profile": {"customGridColumns": []}}},
        {"user": {"profile": {"customGridColumns": {"tickets": {}}}}},
    ],
)
async def test_daktela_ticket_connector_get_ticket_grid_column_keys_returns_none_for_invalid_ticket_grid_shapes(
    monkeypatch: pytest.MonkeyPatch,
    whoiam_result: dict[str, Any],
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_get_whoiam_result() -> dict[str, Any]:
        return whoiam_result

    monkeypatch.setattr(connector, "_get_whoiam_result", fake_get_whoiam_result)

    assert await connector.get_ticket_grid_column_keys() is None


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_ticket_grid_column_keys_extracts_normalized_ticket_columns(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_get_whoiam_result() -> dict[str, Any]:
        return {
            "customGridColumns": {
                "tickets": [
                    {"alias": "contacts", "name": "contact.title"},
                    {"alias": "tickets", "name": "edited"},
                    {"alias": "tickets", "name": "user.title"},
                    {"alias": "tickets", "name": "edited"},
                    {"alias": "tickets", "name": "sla_deadtime"},
                    {"alias": "tickets", "name": 7},
                    [],
                ]
            }
        }

    monkeypatch.setattr(connector, "_get_whoiam_result", fake_get_whoiam_result)

    assert await connector.get_ticket_grid_column_keys() == [
        "name",
        "title",
        "edited",
        "user.title",
        "sla_deadtime",
    ]


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_ticket_grid_column_keys_falls_back_to_default_order_when_no_supported_values_exist(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_get_whoiam_result() -> dict[str, Any]:
        return {
            "user": {
                "profile": {
                    "customGridColumns": {
                        "tickets": [
                            {"alias": "tickets", "name": "first_answer_deadline"},
                            {"alias": "tickets", "name": "created_by"},
                            {"alias": "contacts", "name": "contact.title"},
                        ]
                    }
                }
            }
        }

    monkeypatch.setattr(connector, "_get_whoiam_result", fake_get_whoiam_result)

    assert await connector.get_ticket_grid_column_keys() == list(
        TICKET_GRID_DEFAULT_COLUMN_KEYS
    )


@pytest.mark.asyncio
async def test_daktela_ticket_connector_list_tickets_uses_ticket_view_name(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    view = TicketView(name="group", title="Group")

    async def fake_get_tickets_by_filter(
        filters: dict[str, Any],
        *,
        max_objects: int | None = None,
    ) -> list[dict[str, Any]]:
        assert filters == {
            "filter": {
                "logic": "and",
                "filters": [
                    {
                        "field": "_ticketView",
                        "operator": "eq",
                        "value": "group",
                    }
                ],
            }
        }
        assert max_objects == VIEW_TICKET_QUERY_LIMIT
        return [
            {
                "name": 42,
                "title": "Real ticket",
                "category": {"name": "categories_1", "title": "Delivery"},
                "contact": {"name": "contacts_1", "title": "VIP Client"},
                "user": {"name": "operator_1"},
                "statuses": [{"name": "status_vip", "title": "VIP"}],
                "stage": "OPEN",
                "priority": "HIGH",
            }
        ]

    monkeypatch.setattr(connector, "get_tickets_by_filter", fake_get_tickets_by_filter)

    tickets = await connector.list_tickets(view)

    assert [ticket.name for ticket in tickets] == [42]
    assert tickets[0].category == "Delivery"
    assert tickets[0].contact == "VIP Client"
    assert tickets[0].user_name == "operator_1"
    assert tickets[0].statuses == {"status_vip": "VIP"}


@pytest.mark.asyncio
async def test_daktela_ticket_connector_list_ticket_activities_uses_ticket_endpoint(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )

    async def fake_get_objects_paged(
        url: str,
        *,
        params: dict[str, Any] | None = None,
        max_objects: int | None = None,
    ) -> list[dict[str, Any]]:
        assert url == "/api/v6/tickets/42/activities.json"
        assert params is None
        assert max_objects is None
        return [
            {
                "type": "EMAIL",
                "title": "Fwd: test",
                "time": "2026-03-28 10:30:00",
                "item": {
                    "_sys": {"model": "activitiesEmail"},
                    "text": "<p>Hello</p>",
                },
            }
        ]

    monkeypatch.setattr(connector, "_get_objects_paged", fake_get_objects_paged)

    activities = await connector.list_ticket_activities(ticket)

    assert len(activities) == 1
    assert activities[0].display_type == "Email"
    assert activities[0].headline == "Fwd: test"
    assert activities[0].preview_text() == "Hello"


@pytest.mark.asyncio
async def test_daktela_ticket_connector_list_tickets_falls_back_to_view_filter(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    view_filter = {"logic": "and", "filters": [{"field": "stage", "operator": "in", "value": ["OPEN"]}]}
    view = TicketView(title="Open", filter=view_filter)

    async def fake_get_tickets_by_filter(
        filters: dict[str, Any],
        *,
        max_objects: int | None = None,
    ) -> list[dict[str, Any]]:
        assert filters == {"filter": view_filter}
        assert max_objects == VIEW_TICKET_QUERY_LIMIT
        return []

    monkeypatch.setattr(connector, "get_tickets_by_filter", fake_get_tickets_by_filter)

    tickets = await connector.list_tickets(view)

    assert tickets == []


@pytest.mark.asyncio
async def test_daktela_ticket_connector_list_tickets_uses_view_sort_when_supported(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    view = TicketView(
        name="group",
        title="Group",
        sort={"field": "edited", "dir": "DESC"},
    )

    async def fake_get_tickets_by_filter(
        filters: dict[str, Any],
        *,
        max_objects: int | None = None,
    ) -> list[dict[str, Any]]:
        assert filters == {
            "filter": {
                "logic": "and",
                "filters": [
                    {
                        "field": "_ticketView",
                        "operator": "eq",
                        "value": "group",
                    }
                ],
            },
            "sort": {
                "field": "edited",
                "dir": "desc",
            },
        }
        assert max_objects == VIEW_TICKET_QUERY_LIMIT
        return []

    monkeypatch.setattr(connector, "get_tickets_by_filter", fake_get_tickets_by_filter)

    tickets = await connector.list_tickets(view)

    assert tickets == []


@pytest.mark.asyncio
async def test_daktela_ticket_connector_list_tickets_ignores_unsupported_view_sort(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    view = TicketView(name="group", title="Group", sort={"created": "desc"})

    async def fake_get_tickets_by_filter(
        filters: dict[str, Any],
        *,
        max_objects: int | None = None,
    ) -> list[dict[str, Any]]:
        assert filters == {
            "filter": {
                "logic": "and",
                "filters": [
                    {
                        "field": "_ticketView",
                        "operator": "eq",
                        "value": "group",
                    }
                ],
            }
        }
        assert max_objects == VIEW_TICKET_QUERY_LIMIT
        return []

    monkeypatch.setattr(connector, "get_tickets_by_filter", fake_get_tickets_by_filter)

    tickets = await connector.list_tickets(view)

    assert tickets == []


@pytest.mark.asyncio
async def test_daktela_ticket_connector_list_ticket_page_uses_requested_page(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    view = TicketView(name="group", title="Group", sort={"field": "edited", "dir": "asc"})

    async def fake_get_ticket_page_by_filter(
        filters: dict[str, Any],
        *,
        page: int = 1,
    ) -> tuple[list[dict[str, Any]], TicketPagination]:
        assert filters == {
            "filter": {
                "logic": "and",
                "filters": [
                    {
                        "field": "_ticketView",
                        "operator": "eq",
                        "value": "group",
                    }
                ],
            },
            "sort": {
                "field": "edited",
                "dir": "asc",
            },
        }
        assert page == 2
        return (
            [
                {
                    "name": 42,
                    "title": "Paged ticket",
                    "category": {"name": "categories_1", "title": "Delivery"},
                    "stage": "OPEN",
                    "priority": "HIGH",
                }
            ],
            TicketPagination(current_page=2, total_pages=4, total_tickets=301),
        )

    monkeypatch.setattr(connector, "get_ticket_page_by_filter", fake_get_ticket_page_by_filter)

    ticket_page = await connector.list_ticket_page(view, page=2)

    assert [ticket.name for ticket in ticket_page.tickets] == [42]
    assert ticket_page.pagination == TicketPagination(
        current_page=2,
        total_pages=4,
        total_tickets=301,
    )


@pytest.mark.asyncio
async def test_daktela_ticket_connector_list_views_joins_hierarchy_with_payloads(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_get_whoiam_result() -> dict[str, Any]:
        return {
            "user": {
                "profile": {
                    "customViews": {
                        "group": {
                            "index": 0,
                            "children": {
                                "child": {
                                    "index": 0,
                                    "children": [],
                                }
                            },
                        },
                        "root": {
                            "index": 1,
                            "children": [],
                        },
                        "missing": {
                            "index": 2,
                            "children": {
                                "missing_child": {
                                    "index": 0,
                                    "children": [],
                                }
                            },
                        },
                    }
                }
            }
        }

    async def fake_get_ticket_view_payloads_by_name() -> dict[str, dict[str, Any]]:
        return {
            "group": {
                "name": "group",
                "title": "Group",
                "count": "12",
                "description": "Group root",
                "filter": {"logic": "and", "filters": [{"field": "category", "operator": "in"}]},
                "sort": {"field": "edited", "dir": "ASC"},
            },
            "child": {
                "name": "child",
                "title": "Child",
                "count": "many",
                "description": "Nested child",
                "filter": [],
                "sort": {"created": "desc"},
            },
            "root": {
                "name": "root",
                "title": "Root",
                "count": 0,
                "description": "",
                "filter": {"logic": "or", "filters": [{"field": "stage", "operator": "in"}]},
            },
            "extra": {
                "name": "extra",
                "title": "Extra",
                "description": "Not in hierarchy",
                "filter": {"logic": "and", "filters": []},
            },
        }

    monkeypatch.setattr(connector, "_get_whoiam_result", fake_get_whoiam_result)
    monkeypatch.setattr(
        connector,
        "_get_ticket_view_payloads_by_name",
        fake_get_ticket_view_payloads_by_name,
    )

    async def fake_fill_missing_ticket_view_counts(views: list[TicketView]) -> list[TicketView]:
        return views

    monkeypatch.setattr(connector, "_fill_missing_ticket_view_counts", fake_fill_missing_ticket_view_counts)

    caplog.set_level(logging.WARNING)

    views = await connector.list_views()

    assert [view.name for view in views] == ["group", "child", "root"]
    assert [view.parent_view for view in views] == [None, "group", None]
    assert [view.ticket_count for view in views] == [12, None, 0]
    assert views[0].filter == {"logic": "and", "filters": [{"field": "category", "operator": "in"}]}
    assert views[0].sort == {"field": "edited", "dir": "asc"}
    assert views[1].filter is None
    assert views[1].sort is None
    assert views[2].filter == {"logic": "or", "filters": [{"field": "stage", "operator": "in"}]}
    assert views[0].selection_key() == ("name", "group")
    assert "Ignoring unsupported count payload for Daktela view child" in caplog.text
    assert "Ignoring unsupported sort payload for Daktela view child" in caplog.text
    assert "Skipping Daktela custom view missing because ticketsViews metadata is missing." in caplog.text


@pytest.mark.asyncio
async def test_daktela_ticket_connector_fill_missing_ticket_view_counts_returns_original_views_when_complete() -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    views = [TicketView(name="group", title="Group", ticket_count=4)]

    resolved_views = await connector._fill_missing_ticket_view_counts(views)

    assert resolved_views == views


@pytest.mark.asyncio
async def test_daktela_ticket_connector_fill_missing_ticket_view_counts_fetches_only_missing_views(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    counted_view = TicketView(name="counted", title="Counted", ticket_count=4)
    missing_view = TicketView(name="missing", title="Missing")
    calls: list[str | None] = []

    async def fake_ticket_count_for_view(view: TicketView) -> int | None:
        calls.append(view.name)
        return 7

    monkeypatch.setattr(connector, "_ticket_count_for_view", fake_ticket_count_for_view)

    resolved_views = await connector._fill_missing_ticket_view_counts([counted_view, missing_view])

    assert [view.ticket_count for view in resolved_views] == [4, 7]
    assert calls == ["missing"]


@pytest.mark.asyncio
async def test_daktela_ticket_connector_ticket_count_for_view_uses_ticket_total(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    view = TicketView(name="group", title="Group")

    async def fake_get_total_objects(
        url: str,
        *,
        params: dict[str, Any] | None = None,
    ) -> int:
        assert url == "/api/v6/tickets"
        assert params == {
            "filter": {
                "logic": "and",
                "filters": [
                    {
                        "field": "_ticketView",
                        "operator": "eq",
                        "value": "group",
                    }
                ],
            }
        }
        return 9

    monkeypatch.setattr(connector, "_get_total_objects", fake_get_total_objects)

    assert await connector._ticket_count_for_view(view) == 9


@pytest.mark.asyncio
async def test_daktela_ticket_connector_ticket_count_for_view_returns_none_on_error(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    view = TicketView(name="group", title="Group")

    async def fake_get_total_objects(
        url: str,
        *,
        params: dict[str, Any] | None = None,
    ) -> int:
        raise RuntimeError("boom")

    monkeypatch.setattr(connector, "_get_total_objects", fake_get_total_objects)
    caplog.set_level(logging.WARNING)

    assert await connector._ticket_count_for_view(view) is None
    assert "Unable to load ticket count for Daktela view group" in caplog.text


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_total_objects_reads_total(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    class FakeResponse:
        @staticmethod
        def json() -> dict[str, Any]:
            return {"result": {"total": 13}}

    async def fake_send_get_request_v2(
        url: str,
        params: dict[str, Any] | None = None,
        *,
        page_size: int = 100,
        page: int = 1,
    ) -> FakeResponse:
        assert url == "/api/v6/tickets"
        assert params == {"filter": {"logic": "and", "filters": []}}
        assert page_size == 1
        assert page == 1
        return FakeResponse()

    monkeypatch.setattr(connector, "_send_get_request_v2", fake_send_get_request_v2)

    total = await connector._get_total_objects(
        "/api/v6/tickets",
        params={"filter": {"logic": "and", "filters": []}},
    )

    assert total == 13


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_total_objects_rejects_non_object_result(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    class FakeResponse:
        @staticmethod
        def json() -> dict[str, Any]:
            return {"result": []}

    async def fake_send_get_request_v2(
        url: str,
        params: dict[str, Any] | None = None,
        *,
        page_size: int = 100,
        page: int = 1,
    ) -> FakeResponse:
        return FakeResponse()

    monkeypatch.setattr(connector, "_send_get_request_v2", fake_send_get_request_v2)

    with pytest.raises(DaktelaConnectorError, match="did not contain an object result"):
        await connector._get_total_objects("/api/v6/tickets")


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_total_objects_rejects_invalid_total(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    class FakeResponse:
        @staticmethod
        def json() -> dict[str, Any]:
            return {"result": {"total": "many"}}

    async def fake_send_get_request_v2(
        url: str,
        params: dict[str, Any] | None = None,
        *,
        page_size: int = 100,
        page: int = 1,
    ) -> FakeResponse:
        return FakeResponse()

    monkeypatch.setattr(connector, "_send_get_request_v2", fake_send_get_request_v2)

    with pytest.raises(DaktelaConnectorError, match="did not contain a valid total"):
        await connector._get_total_objects("/api/v6/tickets")


@pytest.mark.asyncio
async def test_daktela_ticket_connector_store_ticket_puts_sparse_payload(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        description="Old description",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )

    class FakeResponse:
        status_code = 200

        @staticmethod
        def json() -> dict[str, Any]:
            return {
                "result": {
                    "name": 42,
                    "title": "Updated ticket",
                    "category": {"title": "Delivery"},
                    "description": "New description",
                    "stage": "OPEN",
                    "priority": "HIGH",
                }
            }

    async def fake_send_request(method: str, url: str, **kwargs: Any) -> FakeResponse:
        assert method == "PUT"
        assert url == "https://demo.daktela.com/api/v6/tickets/42.json?accessToken=token-123"
        assert kwargs["json"] == {
            "title": "Updated ticket",
            "description": "New description",
        }
        return FakeResponse()

    monkeypatch.setattr(connector, "_send_request", fake_send_request)

    saved_ticket = await connector.store_ticket(
        ticket,
        TicketEditPatch(title="Updated ticket", description="New description"),
    )

    assert saved_ticket.title == "Updated ticket"
    assert saved_ticket.description == "New description"


@pytest.mark.asyncio
async def test_daktela_ticket_connector_create_ticket_comment_posts_activity_payload(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )

    class FakeResponse:
        status_code = 201

        @staticmethod
        def json() -> dict[str, Any]:
            return {"result": {"data": {"name": "activity_1"}}}

    async def fake_send_request(method: str, url: str, **kwargs: Any) -> FakeResponse:
        assert method == "POST"
        assert url == "https://demo.daktela.com/api/v6/activities.json?accessToken=token-123"
        assert kwargs["json"] == {
            "ticket": 42,
            "type": "",
            "description": "Internal note",
        }
        return FakeResponse()

    monkeypatch.setattr(connector, "_send_request", fake_send_request)

    await connector.create_ticket_comment(ticket, TicketCommentCreateRequest(body="Internal note"))


@pytest.mark.asyncio
async def test_daktela_ticket_connector_create_ticket_comment_uploads_attachments_and_updates_ticket(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )
    request = TicketCommentCreateRequest(
        body="Internal note",
        attachments=[
            TicketCommentAttachmentUpload(
                filename="report.txt",
                content=b"alpha",
                content_type="text/plain",
            )
        ],
    )
    calls: list[tuple[str, str, dict[str, Any]]] = []

    class UploadResponse:
        status_code = 200

        @staticmethod
        def json() -> str:
            return "temp-upload-name.txt"

    class UpdateResponse:
        status_code = 200

        @staticmethod
        def json() -> dict[str, Any]:
            return {"result": {"name": 42}}

    async def fake_send_request(method: str, url: str, **kwargs: Any) -> UploadResponse | UpdateResponse:
        calls.append((method, url, kwargs))
        if url.startswith("https://demo.daktela.com/file/upload.php"):
            return UploadResponse()
        return UpdateResponse()

    monkeypatch.setattr(connector, "_send_request", fake_send_request)

    await connector.create_ticket_comment(ticket, request)

    assert calls == [
        (
            "POST",
            "https://demo.daktela.com/file/upload.php?type=save&accessToken=token-123",
            {
                "files": {
                    "files": ("report.txt", b"alpha", "text/plain"),
                }
            },
        ),
        (
            "PUT",
            "https://demo.daktela.com/api/v6/tickets/42.json?accessToken=token-123",
            {
                "json": {
                    "comment": "Internal note",
                    "comment_add_files": {
                        "attachment_1": {
                            "_uid": "attachment_1",
                            "name": "temp-upload-name.txt",
                            "title": "report.txt",
                            "size": 5,
                            "type": "text/plain",
                        }
                    },
                }
            },
        ),
    ]


@pytest.mark.asyncio
async def test_daktela_ticket_connector_upload_comment_attachment_posts_async_safe_request(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    attachment = TicketCommentAttachmentUpload(
        filename="report.txt",
        content=b"alpha",
        content_type="text/plain",
    )
    captured: dict[str, Any] = {}
    real_async_client = httpx.AsyncClient

    async def handler(http_request: httpx.Request) -> httpx.Response:
        captured["method"] = http_request.method
        captured["url"] = str(http_request.url)
        captured["content_type"] = http_request.headers["content-type"]
        captured["body"] = await http_request.aread()
        return httpx.Response(
            200,
            json="temp-upload-name.txt",
        )

    def fake_async_client(*, timeout: int) -> httpx.AsyncClient:
        assert timeout == 30
        return real_async_client(timeout=timeout, transport=httpx.MockTransport(handler))

    monkeypatch.setattr(httpx, "AsyncClient", fake_async_client)

    upload_name = await connector._upload_comment_attachment(attachment)

    assert upload_name == "temp-upload-name.txt"
    assert captured["method"] == "POST"
    assert captured["url"] == "https://demo.daktela.com/file/upload.php?type=save&accessToken=token-123"
    assert "multipart/form-data" in captured["content_type"]
    assert b'name="files"; filename="report.txt"' in captured["body"]
    assert b"Content-Type: text/plain" in captured["body"]
    assert b"alpha" in captured["body"]


@pytest.mark.asyncio
async def test_daktela_ticket_connector_upload_comment_attachment_raises_for_http_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    attachment = TicketCommentAttachmentUpload(
        filename="report.txt",
        content=b"alpha",
        content_type="text/plain",
    )

    class ErrorResponse:
        status_code = 500

        @staticmethod
        def json() -> dict[str, Any]:
            return {"error": {"primary": ["boom"]}}

    async def fake_send_request(method: str, url: str, **kwargs: Any) -> ErrorResponse:
        return ErrorResponse()

    monkeypatch.setattr(connector, "_send_request", fake_send_request)

    with pytest.raises(DaktelaConnectorError, match="upload failed with status 500"):
        await connector._upload_comment_attachment(attachment)


@pytest.mark.asyncio
async def test_daktela_ticket_connector_upload_comment_attachment_raises_for_missing_file_id(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    attachment = TicketCommentAttachmentUpload(
        filename="report.txt",
        content=b"alpha",
        content_type="text/plain",
    )

    class InvalidResponse:
        status_code = 200

        @staticmethod
        def json() -> object:
            return {"name": "not-a-string"}

    async def fake_send_request(method: str, url: str, **kwargs: Any) -> InvalidResponse:
        return InvalidResponse()

    monkeypatch.setattr(connector, "_send_request", fake_send_request)

    with pytest.raises(DaktelaConnectorError, match="did not return a file ID"):
        await connector._upload_comment_attachment(attachment)


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_ticket_email_draft_loads_reply_defaults(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )
    activity = make_email_activity()

    async def fake_send_get_request(url: str, **kwargs: Any) -> ResponseStub:
        assert url == "/api/v6/activitiesEmail/emails_1.json"
        assert kwargs["additional_params"] == ""
        return ResponseStub(
            status_code=200,
            payload={
                "result": {
                    "title": "Original subject",
                    "address": "customer@example.com",
                    "queue": {
                        "name": "queues_1",
                        "options": {"address": "queue@example.com"},
                    },
                    "options": {
                        "headers": {
                            "reply-to": [
                                {"address": "reply@example.com"},
                                {"address": "backup@example.com"},
                            ],
                            "to": [{"address": "queue@example.com"}],
                        }
                    },
                    "activities": [{"name": "activities_1"}],
                }
            },
        )

    monkeypatch.setattr(connector, "_send_get_request", fake_send_get_request)

    draft = await connector.get_ticket_email_draft(ticket, activity, TicketEmailAction.REPLY)

    assert draft == TicketEmailDraft(
        action=TicketEmailAction.REPLY,
        source_activity_name="activities_1",
        source_email_name="emails_1",
        to="reply@example.com, backup@example.com",
        subject="Re: Original subject",
        body="",
        queue_name="queues_1",
    )


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_ticket_email_draft_uses_activity_lookup_fallback(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )
    activity = make_email_activity(email_name=None)
    calls: list[str] = []

    async def fake_send_get_request(url: str, **kwargs: Any) -> ResponseStub:
        calls.append(url)
        if url == "/api/v6/activities/activities_1.json":
            return ResponseStub(
                status_code=200,
                payload={
                    "result": {
                        "name": "activities_1",
                        "item": {
                            "name": "emails_nested_1",
                            "_sys": {"model": "activitiesEmail"},
                        },
                    }
                },
            )
        assert url == "/api/v6/activitiesEmail/emails_nested_1.json"
        assert kwargs["additional_params"] == ""
        return ResponseStub(
            status_code=200,
            payload={
                "result": {
                    "title": "Original subject",
                    "address": "customer@example.com",
                    "queue": {"name": "queues_1"},
                    "options": {"headers": {}},
                }
            },
        )

    monkeypatch.setattr(connector, "_send_get_request", fake_send_get_request)

    draft = await connector.get_ticket_email_draft(ticket, activity, TicketEmailAction.REPLY)

    assert calls == [
        "/api/v6/activities/activities_1.json",
        "/api/v6/activitiesEmail/emails_nested_1.json",
    ]
    assert draft.source_email_name == "emails_nested_1"
    assert draft.to == "customer@example.com"


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_ticket_email_draft_for_forward_leaves_recipients_blank(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )
    activity = make_email_activity()

    async def fake_send_get_request(url: str, **kwargs: Any) -> ResponseStub:
        assert url == "/api/v6/activitiesEmail/emails_1.json"
        return ResponseStub(
            status_code=200,
            payload={
                "result": {
                    "title": "FW: Original subject",
                    "address": "customer@example.com",
                    "queue": {"name": "queues_1"},
                    "options": {"headers": {}},
                }
            },
        )

    monkeypatch.setattr(connector, "_send_get_request", fake_send_get_request)

    draft = await connector.get_ticket_email_draft(ticket, activity, TicketEmailAction.FORWARD)

    assert draft.to == ""
    assert draft.subject == "FW: Original subject"


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_ticket_email_draft_raises_for_missing_email_reference() -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )
    activity = TicketActivity.model_validate({"type": "EMAIL", "title": "No item"})

    with pytest.raises(DaktelaConnectorError, match="does not reference an email item"):
        await connector.get_ticket_email_draft(ticket, activity, TicketEmailAction.REPLY)


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_ticket_email_draft_raises_for_error_payload(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )
    activity = make_email_activity()

    async def fake_send_get_request(url: str, **kwargs: Any) -> ResponseStub:
        assert url == "/api/v6/activitiesEmail/emails_1.json"
        return ResponseStub(status_code=200, payload={"error": {"detail": "Permission denied"}})

    monkeypatch.setattr(connector, "_send_get_request", fake_send_get_request)

    with pytest.raises(DaktelaConnectorError, match="Permission denied"):
        await connector.get_ticket_email_draft(ticket, activity, TicketEmailAction.REPLY)


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_ticket_email_draft_rejects_invalid_action(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )
    activity = make_email_activity()

    async def fake_get_email_details_for_activity(_: TicketActivity) -> DaktelaEmailDetails:
        return DaktelaEmailDetails(
            activity_name="activities_1",
            email_name="emails_1",
            subject="Original subject",
            address="customer@example.com",
            queue_name="queues_1",
            queue_address="queue@example.com",
            header_to_all=(),
            reply_to_all=(),
        )

    monkeypatch.setattr(connector, "_get_email_details_for_activity", fake_get_email_details_for_activity)

    with pytest.raises(ValueError, match="Unsupported ticket email action"):
        await connector.get_ticket_email_draft(ticket, activity, "invalid-action")  # type: ignore[arg-type]


@pytest.mark.asyncio
async def test_daktela_ticket_connector_send_ticket_email_reply_posts_activity_payload(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )
    request = TicketEmailSendRequest(
        action=TicketEmailAction.REPLY,
        source_email_name="emails_1",
        to="customer@example.com",
        subject="Re: Original subject",
        body="<p>Thanks</p>",
        queue_name="queues_1",
    )

    async def fake_send_request(method: str, url: str, **kwargs: Any) -> ResponseStub:
        assert method == "POST"
        assert url == "https://demo.daktela.com/api/v6/activities.json?accessToken=token-123"
        assert kwargs["json"] == {
            "type": "EMAIL",
            "ticket": 42,
            "subject": "Re: Original subject",
            "message": "<p>Thanks</p>",
            "to": "customer@example.com",
            "queue": "queues_1",
            "duration": 0,
            "sendMail": True,
        }
        return ResponseStub(status_code=201, payload={"result": {"name": "activities_2"}})

    monkeypatch.setattr(connector, "_send_request", fake_send_request)

    await connector.send_ticket_email(ticket, request)


@pytest.mark.asyncio
async def test_daktela_ticket_connector_send_ticket_email_forward_opens_and_closes_activity(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )
    request = TicketEmailSendRequest(
        action=TicketEmailAction.FORWARD,
        source_email_name="emails_1",
        to="other@example.com",
        subject="Fwd: Original subject",
        body="<p>Please review</p>",
        queue_name="queues_1",
    )
    calls: list[tuple[str, str, dict[str, Any]]] = []

    async def fake_send_request(method: str, url: str, **kwargs: Any) -> ResponseStub:
        calls.append((method, url, kwargs["json"]))
        if method == "POST":
            return ResponseStub(
                status_code=201,
                payload={
                    "result": {
                        "name": "activities_forward_1",
                        "options": {"message": "<p>Original message</p>"},
                    }
                },
            )
        return ResponseStub(status_code=200, payload={"result": {"item": {"name": "emails_2"}}})

    monkeypatch.setattr(connector, "_send_request", fake_send_request)

    await connector.send_ticket_email(ticket, request)

    assert calls == [
        (
            "POST",
            "https://demo.daktela.com/api/v6/activities.json?accessToken=token-123",
            {
                "action": "OPEN",
                "options": {
                    "item": {"model": "activitiesEmail", "name": "emails_1"},
                    "replyAction": "forward",
                },
                "type": "EMAIL",
            },
        ),
        (
            "PUT",
            "https://demo.daktela.com/api/v6/activities/activities_forward_1.json?accessToken=token-123",
            {
                "to": "other@example.com",
                "message": "<p>Please review</p><br/><p>Original message</p>",
                "queue": "queues_1",
                "subject": "Fwd: Original subject",
                "action": "CLOSE",
                "sendMail": True,
            },
        ),
    ]


@pytest.mark.asyncio
async def test_daktela_ticket_connector_send_ticket_email_forward_uses_original_message_fallback(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )
    request = TicketEmailSendRequest(
        action=TicketEmailAction.FORWARD,
        source_email_name="emails_1",
        to="other@example.com",
        subject="Fwd: Original subject",
        body="",
        queue_name="queues_1",
    )
    put_payloads: list[dict[str, Any]] = []

    async def fake_send_request(method: str, url: str, **kwargs: Any) -> ResponseStub:
        if method == "POST":
            return ResponseStub(status_code=201, payload={"result": {"name": "activities_forward_1"}})
        put_payloads.append(kwargs["json"])
        return ResponseStub(status_code=200, payload={"result": {"item": {"name": "emails_2"}}})

    async def fake_send_get_private_request(url: str, **kwargs: Any) -> ResponseStub:
        assert url == "/internal/activity/activities_forward_1/originalMessage"
        return ResponseStub(status_code=200, payload={"result": "<p>Original message</p>"})

    monkeypatch.setattr(connector, "_send_request", fake_send_request)
    monkeypatch.setattr(connector, "_send_get_private_request", fake_send_get_private_request)

    await connector.send_ticket_email(ticket, request)

    assert put_payloads == [
        {
            "to": "other@example.com",
            "message": "<p>Original message</p>",
            "queue": "queues_1",
            "subject": "Fwd: Original subject",
            "action": "CLOSE",
            "sendMail": True,
        }
    ]


@pytest.mark.asyncio
async def test_daktela_ticket_connector_send_ticket_email_rejects_invalid_action() -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )
    request = TicketEmailSendRequest(
        action=TicketEmailAction.REPLY,
        source_email_name="emails_1",
        to="customer@example.com",
        subject="Re: Original subject",
        body="<p>Thanks</p>",
        queue_name="queues_1",
    )
    request = request.model_copy(update={"action": "invalid-action"})

    with pytest.raises(ValueError, match="Unsupported ticket email action"):
        await connector.send_ticket_email(ticket, request)  # type: ignore[arg-type]


@pytest.mark.asyncio
async def test_daktela_ticket_connector_send_get_private_request_adds_auth_header_and_params(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    calls: list[tuple[str, str, dict[str, Any]]] = []

    async def fake_send_request(method: str, url: str, **kwargs: Any) -> ResponseStub:
        calls.append((method, url, kwargs))
        return ResponseStub(status_code=200, payload={"result": "ok"})

    monkeypatch.setattr(connector, "_send_request", fake_send_request)

    await connector._send_get_private_request(
        "/internal/activity/activities_1/originalMessage",
        additional_params="full=1",
        headers={"X-Test": "1"},
    )

    assert calls == [
        (
            "GET",
            "https://demo.daktela.com/internal/activity/activities_1/originalMessage?full=1",
            {
                "headers": {
                    "X-Test": "1",
                    "X-Auth-Token": "token-123",
                }
            },
        )
    ]


@pytest.mark.asyncio
async def test_daktela_ticket_connector_open_forward_activity_requires_forwarded_activity_name(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_send_request(method: str, url: str, **kwargs: Any) -> ResponseStub:
        return ResponseStub(status_code=201, payload={"result": {"options": {}}})

    monkeypatch.setattr(connector, "_send_request", fake_send_request)

    with pytest.raises(DaktelaConnectorError, match="missing forwarded activity name"):
        await connector._open_forward_activity("emails_1")


@pytest.mark.asyncio
async def test_daktela_ticket_connector_lists_ticket_categories(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_get_objects_paged(
        url: str,
        *,
        params: dict[str, Any] | None = None,
        max_objects: int | None = None,
    ) -> list[dict[str, Any]]:
        assert url == "/api/v6/ticketsCategories.json"
        assert params is None
        assert max_objects is None
        return [
            {"name": "categories_delivery", "title": "Delivery"},
            {"name": "categories_returns", "title": "Returns"},
            {"name": None, "title": "Ignored"},
        ]

    monkeypatch.setattr(connector, "_get_objects_paged", fake_get_objects_paged)

    category_options = await connector.list_ticket_categories()

    assert category_options == [
        TicketCategoryOption(name="categories_delivery", title="Delivery"),
        TicketCategoryOption(name="categories_returns", title="Returns"),
    ]


@pytest.mark.asyncio
async def test_daktela_ticket_connector_lists_ticket_users(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_get_objects_paged(
        url: str,
        *,
        params: dict[str, Any] | None = None,
        max_objects: int | None = None,
    ) -> list[dict[str, Any]]:
        assert url == "/api/v6/users.json"
        assert params is None
        assert max_objects is None
        return [
            {"name": "operator_1", "title": "Operator One"},
            {"name": "operator_2", "title": ""},
            {"name": None, "title": "Ignored"},
        ]

    monkeypatch.setattr(connector, "_get_objects_paged", fake_get_objects_paged)

    user_options = await connector.list_ticket_users()

    assert user_options == [
        TicketUserOption(name="operator_1", title="Operator One"),
        TicketUserOption(name="operator_2", title="operator_2"),
    ]


@pytest.mark.asyncio
async def test_daktela_ticket_connector_lists_ticket_statuses_for_category(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_get_objects_paged(
        url: str,
        *,
        params: dict[str, Any] | None = None,
        max_objects: int | None = None,
    ) -> list[dict[str, Any]]:
        assert url == "/api/v6/ticketsCategories/categories_delivery/statuses.json"
        assert params is None
        assert max_objects is None
        return [
            {"name": "status_dispatch", "title": "Dispatch"},
            {"name": "status_return", "title": ""},
            {"name": None, "title": "Ignored"},
        ]

    monkeypatch.setattr(connector, "_get_objects_paged", fake_get_objects_paged)

    status_options = await connector.list_ticket_statuses("categories_delivery")

    assert status_options == [
        TicketStatusOption(name="status_dispatch", title="Dispatch"),
        TicketStatusOption(name="status_return", title="status_return"),
    ]


@pytest.mark.asyncio
async def test_daktela_ticket_connector_store_ticket_clears_description_with_empty_string(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        description="Old description",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )

    class FakeResponse:
        status_code = 200

        @staticmethod
        def json() -> dict[str, Any]:
            return {
                "result": {
                    "name": 42,
                    "title": "Real ticket",
                    "category": {"title": "Delivery"},
                    "description": "",
                    "stage": "OPEN",
                    "priority": "HIGH",
                }
            }

    async def fake_send_request(method: str, url: str, **kwargs: Any) -> FakeResponse:
        assert method == "PUT"
        assert kwargs["json"] == {"description": ""}
        return FakeResponse()

    monkeypatch.setattr(connector, "_send_request", fake_send_request)

    saved_ticket = await connector.store_ticket(
        ticket,
        TicketEditPatch(description=None),
    )

    assert saved_ticket.description == ""


@pytest.mark.asyncio
async def test_daktela_ticket_connector_store_ticket_clears_user_with_empty_string(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        user="Operator One",
        user_name="operator_1",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )

    class FakeResponse:
        status_code = 200

        @staticmethod
        def json() -> dict[str, Any]:
            return {
                "result": {
                    "name": 42,
                    "title": "Real ticket",
                    "category": {"title": "Delivery"},
                    "user": "",
                    "stage": "OPEN",
                    "priority": "HIGH",
                }
            }

    async def fake_send_request(method: str, url: str, **kwargs: Any) -> FakeResponse:
        assert method == "PUT"
        assert kwargs["json"] == {"user": ""}
        return FakeResponse()

    monkeypatch.setattr(connector, "_send_request", fake_send_request)

    saved_ticket = await connector.store_ticket(
        ticket,
        TicketEditPatch(user_name=None, user_title=None),
    )

    assert saved_ticket.user is None
    assert saved_ticket.user_name is None


def test_daktela_ticket_connector_store_payload_maps_category_name_to_category_field() -> None:
    payload = DaktelaTicketConnector._store_payload_from_patch(
        TicketEditPatch(
            category_name="categories_returns",
            category_title="Returns",
        )
    )

    assert payload == {"category": "categories_returns"}


def test_daktela_ticket_connector_comment_payload_maps_ticket_and_description() -> None:
    payload = DaktelaTicketConnector._comment_payload(42, "Internal note")

    assert payload == {
        "ticket": 42,
        "type": "",
        "description": "Internal note",
    }


@pytest.mark.parametrize(
    ("payload", "expected"),
    [
        ([], None),
        ({"error": "broken"}, "broken"),
        ({"error": ["one", 2]}, "one; 2"),
        ({"error": {"name": "missing"}}, "name: missing"),
        ({"error": 404}, "404"),
    ],
)
def test_daktela_ticket_connector_response_error_formats_supported_payloads(
    payload: Any,
    expected: str | None,
) -> None:
    assert DaktelaTicketConnector._response_error(payload) == expected


def test_daktela_ticket_connector_store_payload_includes_stage_value() -> None:
    payload = DaktelaTicketConnector._store_payload_from_patch(
        TicketEditPatch(stage=TicketStage.WAIT)
    )

    assert payload == {"stage": "WAIT"}


def test_daktela_ticket_connector_store_payload_includes_priority_value() -> None:
    payload = DaktelaTicketConnector._store_payload_from_patch(
        TicketEditPatch(priority=TicketPriority.LOW)
    )

    assert payload == {"priority": "LOW"}


def test_daktela_ticket_connector_store_payload_formats_reopen_datetime() -> None:
    payload = DaktelaTicketConnector._store_payload_from_patch(
        TicketEditPatch(reopen=datetime(2026, 3, 31, 9, 15, 0))
    )

    assert payload == {"reopen": "2026-03-31 09:15:00"}


def test_daktela_ticket_connector_store_payload_clears_reopen_with_empty_string() -> None:
    payload = DaktelaTicketConnector._store_payload_from_patch(
        TicketEditPatch(reopen=None)
    )

    assert payload == {"reopen": ""}


def test_daktela_ticket_connector_store_payload_maps_user_name_to_user_field() -> None:
    payload = DaktelaTicketConnector._store_payload_from_patch(
        TicketEditPatch(
            user_name="operator_2",
            user_title="Operator Two",
        )
    )

    assert payload == {"user": "operator_2"}


def test_daktela_ticket_connector_store_payload_maps_status_name_to_statuses_list() -> None:
    payload = DaktelaTicketConnector._store_payload_from_patch(
        TicketEditPatch(
            status_name="status_dispatch",
            status_title="Dispatch",
        )
    )

    assert payload == {"statuses": ["status_dispatch"]}


def test_daktela_ticket_connector_store_payload_clears_statuses_with_empty_list() -> None:
    payload = DaktelaTicketConnector._store_payload_from_patch(
        TicketEditPatch(
            status_name=None,
            status_title=None,
        )
    )

    assert payload == {"statuses": []}


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_objects_paged_uses_ceiling_division(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    calls: list[tuple[int, int]] = []

    class FakeResponse:
        def __init__(self, payload: dict[str, Any]) -> None:
            self._payload = payload

        def json(self) -> dict[str, Any]:
            return self._payload

    async def fake_send_get_request_v2(
        url: str,
        params: dict[str, Any] | None = None,
        *,
        page_size: int = 100,
        page: int = 1,
    ) -> FakeResponse:
        assert url == "/api/v6/ticketsViews.json"
        assert params is None
        calls.append((page_size, page))
        if page_size == 1:
            return FakeResponse({"result": {"total": 200, "data": []}})
        return FakeResponse(
            {
                "result": {
                    "data": [{"name": f"page-{page}"}],
                }
            }
        )

    monkeypatch.setattr(connector, "_send_get_request_v2", fake_send_get_request_v2)

    payloads = await connector._get_objects_paged("/api/v6/ticketsViews.json")

    assert payloads == [{"name": "page-1"}, {"name": "page-2"}]
    assert calls == [(1, 1), (100, 1), (100, 2)]


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_objects_paged_honors_max_objects(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    calls: list[tuple[int, int]] = []

    class FakeResponse:
        def __init__(self, payload: dict[str, Any]) -> None:
            self._payload = payload

        def json(self) -> dict[str, Any]:
            return self._payload

    async def fake_send_get_request_v2(
        url: str,
        params: dict[str, Any] | None = None,
        *,
        page_size: int = 100,
        page: int = 1,
    ) -> FakeResponse:
        assert url == "/api/v6/tickets"
        assert params == {"filter": {"logic": "and", "filters": []}}
        calls.append((page_size, page))
        if page_size == 1:
            return FakeResponse({"result": {"total": 350, "data": []}})
        return FakeResponse(
            {
                "result": {
                    "data": [
                        {"name": page * 100 + index}
                        for index in range(page_size)
                    ],
                }
            }
        )

    monkeypatch.setattr(connector, "_send_get_request_v2", fake_send_get_request_v2)

    payloads = await connector._get_objects_paged(
        "/api/v6/tickets",
        params={"filter": {"logic": "and", "filters": []}},
        max_objects=VIEW_TICKET_QUERY_LIMIT,
    )

    assert len(payloads) == VIEW_TICKET_QUERY_LIMIT
    assert calls == [(1, 1), (100, 1), (100, 2)]


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_objects_page_clamps_requested_page(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    calls: list[tuple[int, int]] = []

    class FakeResponse:
        def __init__(self, payload: dict[str, Any]) -> None:
            self._payload = payload

        def json(self) -> dict[str, Any]:
            return self._payload

    async def fake_send_get_request_v2(
        url: str,
        params: dict[str, Any] | None = None,
        *,
        page_size: int = 100,
        page: int = 1,
    ) -> FakeResponse:
        assert url == "/api/v6/tickets"
        calls.append((page_size, page))
        if page_size == 1:
            return FakeResponse({"result": {"total": 250}})
        return FakeResponse({"result": {"data": [{"name": page}]}})

    monkeypatch.setattr(connector, "_send_get_request_v2", fake_send_get_request_v2)

    payloads, pagination = await connector._get_objects_page("/api/v6/tickets", page=9)

    assert payloads == [{"name": 3}]
    assert pagination == TicketPagination(
        current_page=3,
        total_pages=3,
        total_tickets=250,
    )
    assert calls == [(1, 1), (100, 3)]


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_objects_page_returns_empty_for_zero_total(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_get_total_objects(
        url: str,
        *,
        params: dict[str, Any] | None = None,
    ) -> int:
        assert url == "/api/v6/tickets"
        assert params is None
        return 0

    monkeypatch.setattr(connector, "_get_total_objects", fake_get_total_objects)

    payloads, pagination = await connector._get_objects_page("/api/v6/tickets")

    assert payloads == []
    assert pagination == TicketPagination(
        current_page=1,
        total_pages=1,
        total_tickets=0,
    )


def test_daktela_ticket_connector_response_data_requires_list_data() -> None:
    with pytest.raises(DaktelaConnectorError, match="did not contain a data list"):
        DaktelaTicketConnector._response_data({"result": {"data": "bad"}}, "/api/v6/tickets")


def test_daktela_ticket_connector_response_data_requires_object_items() -> None:
    with pytest.raises(DaktelaConnectorError, match="did not contain object data items"):
        DaktelaTicketConnector._response_data({"result": {"data": ["bad"]}}, "/api/v6/tickets")


@pytest.mark.asyncio
async def test_daktela_ticket_connector_list_views_returns_empty_when_custom_views_missing(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_get_whoiam_result() -> dict[str, Any]:
        return {"user": {"profile": {"customViews": []}}}

    monkeypatch.setattr(connector, "_get_whoiam_result", fake_get_whoiam_result)
    caplog.set_level(logging.WARNING)

    assert await connector.list_views() == []
    assert "missing user.profile.customViews" in caplog.text


@pytest.mark.asyncio
async def test_daktela_ticket_connector_list_tickets_without_view_is_not_implemented() -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    with pytest.raises(NotImplementedError):
        await connector.list_tickets(None)


@pytest.mark.asyncio
async def test_daktela_ticket_connector_store_ticket_raises_for_error_response(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )

    class FakeResponse:
        status_code = 500

        @staticmethod
        def json() -> dict[str, Any]:
            return {}

    async def fake_send_request(method: str, url: str, **kwargs: Any) -> FakeResponse:
        return FakeResponse()

    monkeypatch.setattr(connector, "_send_request", fake_send_request)

    with pytest.raises(DaktelaConnectorError, match="status 500"):
        await connector.store_ticket(ticket, TicketEditPatch(title="Updated"))


@pytest.mark.asyncio
async def test_daktela_ticket_connector_create_ticket_comment_raises_for_error_response(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )

    class FakeResponse:
        status_code = 500

        @staticmethod
        def json() -> dict[str, Any]:
            return {}

    async def fake_send_request(method: str, url: str, **kwargs: Any) -> FakeResponse:
        return FakeResponse()

    monkeypatch.setattr(connector, "_send_request", fake_send_request)

    with pytest.raises(DaktelaConnectorError, match="status 500"):
        await connector.create_ticket_comment(ticket, TicketCommentCreateRequest(body="Updated"))


@pytest.mark.asyncio
async def test_daktela_ticket_connector_create_ticket_comment_raises_for_api_error_payload(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )

    class FakeResponse:
        status_code = 200

        @staticmethod
        def json() -> dict[str, Any]:
            return {"error": {"description": "Permission denied"}}

    async def fake_send_request(method: str, url: str, **kwargs: Any) -> FakeResponse:
        return FakeResponse()

    monkeypatch.setattr(connector, "_send_request", fake_send_request)

    with pytest.raises(DaktelaConnectorError, match="Permission denied"):
        await connector.create_ticket_comment(ticket, TicketCommentCreateRequest(body="Updated"))


@pytest.mark.asyncio
async def test_daktela_ticket_connector_send_ticket_email_reply_raises_for_api_error_payload(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )
    request = TicketEmailSendRequest(
        action=TicketEmailAction.REPLY,
        source_email_name="emails_1",
        to="customer@example.com",
        subject="Re: Original subject",
        body="<p>Thanks</p>",
        queue_name="queues_1",
    )

    async def fake_send_request(method: str, url: str, **kwargs: Any) -> ResponseStub:
        return ResponseStub(status_code=200, payload={"error": {"detail": "Permission denied"}})

    monkeypatch.setattr(connector, "_send_request", fake_send_request)

    with pytest.raises(DaktelaConnectorError, match="Permission denied"):
        await connector.send_ticket_email(ticket, request)


@pytest.mark.asyncio
async def test_daktela_ticket_connector_send_ticket_email_reply_raises_for_400_error_payload(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )
    request = TicketEmailSendRequest(
        action=TicketEmailAction.REPLY,
        source_email_name="emails_1",
        to="customer@example.com",
        subject="Re: Original subject",
        body="<p>Thanks</p>",
        queue_name="queues_1",
    )

    async def fake_send_request(method: str, url: str, **kwargs: Any) -> ResponseStub:
        return ResponseStub(status_code=400, payload={"error": {"form": {"queue": "Permission denied"}}})

    monkeypatch.setattr(connector, "_send_request", fake_send_request)

    with pytest.raises(DaktelaConnectorError, match="Permission denied"):
        await connector.send_ticket_email(ticket, request)


def test_daktela_ticket_connector_validated_response_payload_falls_back_to_status_when_400_is_not_json() -> None:
    response = ResponseStub(status_code=400, json_error=ValueError("not json"))

    with pytest.raises(DaktelaConnectorError, match="send failed with status 400"):
        DaktelaTicketConnector._validated_response_payload(
            cast(httpx.Response, response),
            "send failed",
        )


@pytest.mark.asyncio
async def test_daktela_ticket_connector_send_ticket_email_forward_raises_for_error_response(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    ticket = Ticket(
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )
    request = TicketEmailSendRequest(
        action=TicketEmailAction.FORWARD,
        source_email_name="emails_1",
        to="other@example.com",
        subject="Fwd: Original subject",
        body="<p>Please review</p>",
        queue_name="queues_1",
    )

    async def fake_send_request(method: str, url: str, **kwargs: Any) -> ResponseStub:
        return ResponseStub(status_code=500, payload={})

    monkeypatch.setattr(connector, "_send_request", fake_send_request)

    with pytest.raises(DaktelaConnectorError, match="status 500"):
        await connector.send_ticket_email(ticket, request)


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_original_email_message_returns_empty_on_private_request_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_send_get_private_request(url: str, **kwargs: Any) -> ResponseStub:
        raise DaktelaConnectorError("boom")

    monkeypatch.setattr(connector, "_send_get_private_request", fake_send_get_private_request)

    assert await connector._get_original_email_message("activities_forward_1") == ""


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_original_email_message_returns_empty_for_error_status(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_send_get_private_request(url: str, **kwargs: Any) -> ResponseStub:
        return ResponseStub(status_code=500, payload={})

    monkeypatch.setattr(connector, "_send_get_private_request", fake_send_get_private_request)

    assert await connector._get_original_email_message("activities_forward_1") == ""


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_original_email_message_returns_empty_for_invalid_json(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_send_get_private_request(url: str, **kwargs: Any) -> ResponseStub:
        return ResponseStub(status_code=200, json_error=ValueError("bad json"))

    monkeypatch.setattr(connector, "_send_get_private_request", fake_send_get_private_request)

    assert await connector._get_original_email_message("activities_forward_1") == ""


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_original_email_message_returns_empty_for_non_string_result(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_send_get_private_request(url: str, **kwargs: Any) -> ResponseStub:
        return ResponseStub(status_code=200, payload={"result": {"message": "nope"}})

    monkeypatch.setattr(connector, "_send_get_private_request", fake_send_get_private_request)

    assert await connector._get_original_email_message("activities_forward_1") == ""


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_whoiam_falls_back_to_zero_version(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_get_whoiam_result() -> dict[str, Any]:
        return {
            "version": {"current": "broken"},
            "user": {
                "title": "Operator",
                "alias": None,
                "description": None,
            },
        }

    monkeypatch.setattr(connector, "_get_whoiam_result", fake_get_whoiam_result)
    caplog.set_level(logging.WARNING)

    whoiam = await connector.get_whoiam()

    assert whoiam.major_version == 0
    assert whoiam.minor_version == 0
    assert "Error while parsing Daktela version" in caplog.text


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_whoiam_parses_major_and_minor_version(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_get_whoiam_result() -> dict[str, Any]:
        return {
            "version": {"current": "6.29.3"},
            "user": {
                "title": "Operator",
                "alias": "op",
                "description": "Desk",
            },
        }

    monkeypatch.setattr(connector, "_get_whoiam_result", fake_get_whoiam_result)

    whoiam = await connector.get_whoiam()

    assert whoiam.major_version == 6
    assert whoiam.minor_version == 29
    assert whoiam.title == "Operator"
    assert whoiam.alias == "op"


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_whoiam_result_returns_json_object_result(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    class FakeResponse:
        @staticmethod
        def json() -> dict[str, Any]:
            return {"result": {"alias": "op"}}

    async def fake_send_get_request(url: str, **kwargs: Any) -> FakeResponse:
        assert url == "/api/v6/whoim.json"
        return FakeResponse()

    monkeypatch.setattr(connector, "_send_get_request", fake_send_get_request)

    assert await connector._get_whoiam_result() == {"alias": "op"}


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_whoiam_result_returns_empty_dict_for_invalid_result(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    class FakeResponse:
        @staticmethod
        def json() -> dict[str, Any]:
            return {"result": []}

    async def fake_send_get_request(url: str, **kwargs: Any) -> FakeResponse:
        assert url == "/api/v6/whoim.json"
        return FakeResponse()

    monkeypatch.setattr(connector, "_send_get_request", fake_send_get_request)
    caplog.set_level(logging.WARNING)

    assert await connector._get_whoiam_result() == {}
    assert "did not contain a JSON object result" in caplog.text


@pytest.mark.asyncio
async def test_daktela_ticket_connector_skips_ticket_view_payload_without_string_name(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_get_objects_paged(
        url: str,
        *,
        params: dict[str, Any] | None = None,
        max_objects: int | None = None,
    ) -> list[dict[str, Any]]:
        assert url == "/api/v6/ticketsViews.json"
        return [
            {"name": "good", "title": "Good"},
            {"name": None, "title": "Ignored"},
        ]

    monkeypatch.setattr(connector, "_get_objects_paged", fake_get_objects_paged)
    caplog.set_level(logging.WARNING)

    payloads = await connector._get_ticket_view_payloads_by_name()

    assert payloads == {"good": {"name": "good", "title": "Good"}}
    assert "Skipping Daktela ticketsViews payload without a string name" in caplog.text


@pytest.mark.asyncio
async def test_daktela_ticket_connector_send_request_returns_response_on_success(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    class FakeResponse:
        status_code = 200

    class FakeAsyncClient:
        def __init__(self, *, timeout: int) -> None:
            assert timeout == 30

        async def __aenter__(self) -> FakeAsyncClient:
            return self

        async def __aexit__(self, exc_type: object, exc: object, tb: object) -> None:
            return None

        async def request(self, method: str, url: str, **kwargs: Any) -> FakeResponse:
            assert method == "GET"
            assert url == "https://demo.daktela.com"
            return FakeResponse()

    monkeypatch.setattr(httpx, "AsyncClient", FakeAsyncClient)

    response = await connector._send_request("GET", "https://demo.daktela.com")

    assert isinstance(response, FakeResponse)


@pytest.mark.asyncio
async def test_daktela_ticket_connector_send_request_raises_for_bad_token(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    class FakeResponse:
        status_code = 401

    class FakeAsyncClient:
        def __init__(self, *, timeout: int) -> None:
            assert timeout == 30

        async def __aenter__(self) -> FakeAsyncClient:
            return self

        async def __aexit__(self, exc_type: object, exc: object, tb: object) -> None:
            return None

        async def request(self, method: str, url: str, **kwargs: Any) -> FakeResponse:
            return FakeResponse()

    monkeypatch.setattr(httpx, "AsyncClient", FakeAsyncClient)

    with pytest.raises(BadTokenDaktelaError):
        await connector._send_request("GET", "https://demo.daktela.com")


@pytest.mark.asyncio
async def test_daktela_ticket_connector_send_request_wraps_http_errors(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    class FakeAsyncClient:
        def __init__(self, *, timeout: int) -> None:
            assert timeout == 30

        async def __aenter__(self) -> FakeAsyncClient:
            return self

        async def __aexit__(self, exc_type: object, exc: object, tb: object) -> None:
            return None

        async def request(self, method: str, url: str, **kwargs: Any) -> Any:
            raise httpx.ConnectError("boom")

    monkeypatch.setattr(httpx, "AsyncClient", FakeAsyncClient)
    caplog.set_level(logging.ERROR)

    with pytest.raises(CantConnectToDaktelaError):
        await connector._send_request("GET", "https://demo.daktela.com")

    assert "Cant connect to Daktela" in caplog.text


@pytest.mark.asyncio
async def test_daktela_ticket_connector_send_get_request_appends_additional_params(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    calls: list[tuple[str, str]] = []

    async def fake_send_request(method: str, url: str, **kwargs: Any) -> object:
        calls.append((method, url))
        return object()

    monkeypatch.setattr(connector, "_send_request", fake_send_request)

    await connector._send_get_request(
        "/api/v6/tickets.json",
        additional_params="foo=bar&baz=1",
    )

    assert calls == [
        (
            "GET",
            "https://demo.daktela.com/api/v6/tickets.json?accessToken=token-123&foo=bar&baz=1",
        )
    ]


@pytest.mark.asyncio
async def test_daktela_ticket_connector_send_get_request_v2_raises_for_bad_token(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    class FakeResponse:
        status_code = 401

    class FakeAsyncClient:
        def __init__(self, *, timeout: int) -> None:
            assert timeout == 20

        async def __aenter__(self) -> FakeAsyncClient:
            return self

        async def __aexit__(self, exc_type: object, exc: object, tb: object) -> None:
            return None

        async def get(self, url: str) -> FakeResponse:
            return FakeResponse()

    monkeypatch.setattr(httpx, "AsyncClient", FakeAsyncClient)

    with pytest.raises(BadTokenDaktelaError):
        await connector._send_get_request_v2("/api/v6/tickets.json")


@pytest.mark.asyncio
async def test_daktela_ticket_connector_send_get_request_v2_wraps_http_errors(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    class FakeAsyncClient:
        def __init__(self, *, timeout: int) -> None:
            assert timeout == 20

        async def __aenter__(self) -> FakeAsyncClient:
            return self

        async def __aexit__(self, exc_type: object, exc: object, tb: object) -> None:
            return None

        async def get(self, url: str) -> Any:
            raise httpx.ConnectError("boom")

    monkeypatch.setattr(httpx, "AsyncClient", FakeAsyncClient)
    caplog.set_level(logging.ERROR)

    with pytest.raises(CantConnectToDaktelaError):
        await connector._send_get_request_v2("/api/v6/tickets.json")

    assert "Cant connect to Daktela" in caplog.text


@pytest.mark.asyncio
async def test_daktela_ticket_connector_send_get_request_v2_returns_successful_response(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    class FakeResponse:
        status_code = 200

    class FakeAsyncClient:
        def __init__(self, **kwargs: Any) -> None:
            assert kwargs == {"timeout": 20}

        async def __aenter__(self) -> FakeAsyncClient:
            return self

        async def __aexit__(self, exc_type: object, exc: object, tb: object) -> None:
            return None

        async def get(self, url: str) -> FakeResponse:
            assert url.startswith("https://demo.daktela.com/api/v6/tickets.json?")
            return FakeResponse()

    monkeypatch.setattr(httpx, "AsyncClient", FakeAsyncClient)

    response = await connector._send_get_request_v2("/api/v6/tickets.json")

    assert response.status_code == 200


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_objects_paged_returns_empty_for_zero_total(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    class FakeResponse:
        @staticmethod
        def json() -> dict[str, Any]:
            return {"result": {"total": 0, "data": []}}

    async def fake_send_get_request_v2(
        url: str,
        params: dict[str, Any] | None = None,
        *,
        page_size: int = 100,
        page: int = 1,
    ) -> FakeResponse:
        assert page_size == 1
        assert page == 1
        return FakeResponse()

    monkeypatch.setattr(connector, "_send_get_request_v2", fake_send_get_request_v2)

    assert await connector._get_objects_paged("/api/v6/ticketsViews.json") == []


def test_daktela_ticket_connector_build_ticket_views_skips_invalid_hierarchy_nodes(
    caplog: pytest.LogCaptureFixture,
) -> None:
    caplog.set_level(logging.WARNING)

    views = DaktelaTicketConnector._build_ticket_views(
        {"broken": []},
        {"broken": {"name": "broken", "title": "Broken", "filter": {}}},
    )

    assert views == []
    assert "invalid hierarchy node" in caplog.text


def test_daktela_ticket_connector_custom_view_sort_key_falls_back_to_name() -> None:
    assert DaktelaTicketConnector._custom_view_sort_key(("beta", {})) == (0, "beta")


def test_daktela_ticket_connector_normalize_ticket_view_filter_handles_none_and_invalid_payloads(
    caplog: pytest.LogCaptureFixture,
) -> None:
    caplog.set_level(logging.WARNING)

    assert (
        DaktelaTicketConnector._normalize_ticket_view_filter(None, view_name="empty") is None
    )
    assert (
        DaktelaTicketConnector._normalize_ticket_view_filter(
            "bad",
            view_name="broken",
        )
        is None
    )
    assert "Ignoring unsupported filter payload" in caplog.text


def test_daktela_ticket_connector_normalize_ticket_view_count_handles_supported_and_invalid_values(
    caplog: pytest.LogCaptureFixture,
) -> None:
    caplog.set_level(logging.WARNING)

    assert DaktelaTicketConnector._normalize_ticket_view_count(None, view_name="empty") is None
    assert DaktelaTicketConnector._normalize_ticket_view_count(True, view_name="invalid") is None
    assert DaktelaTicketConnector._normalize_ticket_view_count(3.0, view_name="floaty") == 3
    assert "Ignoring unsupported count payload for Daktela view invalid" in caplog.text


def test_daktela_ticket_connector_filters_for_view_requires_identity() -> None:
    with pytest.raises(ValueError, match="either a name or filter payload"):
        DaktelaTicketConnector._filters_for_view(TicketView(title="Open"))


def test_daktela_ticket_connector_normalize_ticket_view_sort_handles_supported_and_invalid_values(
    caplog: pytest.LogCaptureFixture,
) -> None:
    caplog.set_level(logging.WARNING)

    assert DaktelaTicketConnector._normalize_ticket_view_sort(None, view_name="empty") is None
    assert DaktelaTicketConnector._normalize_ticket_view_sort(
        [],
        view_name="shape",
    ) is None
    assert DaktelaTicketConnector._normalize_ticket_view_sort(
        {"field": "edited", "dir": "DESC"},
        view_name="sorted",
    ) == {"field": "edited", "dir": "desc"}
    assert (
        DaktelaTicketConnector._normalize_ticket_view_sort(
            {"field": "edited", "dir": 7},
            view_name="type",
        )
        is None
    )
    assert (
        DaktelaTicketConnector._normalize_ticket_view_sort(
            {"field": "edited", "dir": "sideways"},
            view_name="invalid",
        )
        is None
    )
    assert "Ignoring unsupported sort payload for Daktela view shape" in caplog.text
    assert "Ignoring unsupported sort payload for Daktela view type" in caplog.text
    assert "Ignoring unsupported sort payload for Daktela view invalid" in caplog.text


def test_daktela_ticket_connector_ticket_query_params_for_view_adds_supported_sort() -> None:
    view = TicketView(name="group", title="Group", sort={"field": "edited", "dir": "ASC"})

    assert DaktelaTicketConnector._ticket_query_params_for_view(view) == {
        "filter": {
            "logic": "and",
            "filters": [
                {
                    "field": "_ticketView",
                    "operator": "eq",
                    "value": "group",
                }
            ],
        },
        "sort": {
            "field": "edited",
            "dir": "asc",
        },
    }


def test_daktela_ticket_connector_ticket_identifier_prefers_ticket_field() -> None:
    ticket = Ticket(
        ticket=77,
        name=42,
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )

    assert DaktelaTicketConnector._ticket_identifier(ticket) == 77


def test_daktela_ticket_connector_ticket_identifier_requires_ticket_or_name() -> None:
    ticket = Ticket(
        title="Real ticket",
        category="Delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )

    with pytest.raises(ValueError, match="either ticket or name"):
        DaktelaTicketConnector._ticket_identifier(ticket)


def test_daktela_ticket_connector_ticket_payload_from_response_handles_supported_shapes() -> None:
    assert DaktelaTicketConnector._ticket_payload_from_response(
        {"result": {"data": {"name": 41}}}
    ) == {"name": 41}
    assert DaktelaTicketConnector._ticket_payload_from_response(
        {"result": {"data": [{"name": 42}]}}
    ) == {"name": 42}
    assert DaktelaTicketConnector._ticket_payload_from_response(
        {"result": {"name": 43}}
    ) == {"name": 43}


def test_daktela_ticket_connector_ticket_payload_from_response_requires_result_dict() -> None:
    with pytest.raises(DaktelaConnectorError, match="did not return a ticket payload"):
        DaktelaTicketConnector._ticket_payload_from_response({"result": []})

def test_daktela_ticket_connector_nested_name_returns_string_values() -> None:
    assert _nested_name("delivery") == "delivery"


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_tickets_by_filter_passes_arguments_through(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")
    received: list[tuple[str, dict[str, Any], int | None]] = []

    async def fake_get_objects_paged(
        url: str,
        *,
        params: dict[str, Any] | None = None,
        max_objects: int | None = None,
    ) -> list[dict[str, Any]]:
        assert params is not None
        received.append((url, params, max_objects))
        return [{"name": 42}]

    monkeypatch.setattr(connector, "_get_objects_paged", fake_get_objects_paged)

    result = await connector.get_tickets_by_filter({"field": "value"}, max_objects=5)

    assert result == [{"name": 42}]
    assert received == [("/api/v6/tickets", {"field": "value"}, 5)]


@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_ticket_page_by_filter_passes_arguments_through(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = DaktelaTicketConnector("demo.daktela.com/", "token-123")

    async def fake_get_objects_page(
        url: str,
        *,
        params: dict[str, Any] | None = None,
        page: int = 1,
        page_size: int = 100,
    ) -> tuple[list[dict[str, Any]], TicketPagination]:
        assert url == "/api/v6/tickets"
        assert params == {"field": "value"}
        assert page == 3
        assert page_size == 100
        return [{"name": 42}], TicketPagination(
            current_page=3,
            total_pages=4,
            total_tickets=301,
        )

    monkeypatch.setattr(connector, "_get_objects_page", fake_get_objects_page)

    payloads, pagination = await connector.get_ticket_page_by_filter(
        {"field": "value"},
        page=3,
    )

    assert payloads == [{"name": 42}]
    assert pagination == TicketPagination(
        current_page=3,
        total_pages=4,
        total_tickets=301,
    )


def test_daktela_ticket_connector_string_value_handles_numbers_and_invalid_values() -> None:
    assert _string_value(7) == "7"
    assert _string_value(3.5) == "3.5"
    assert _string_value(object()) is None


def test_daktela_ticket_connector_sys_model_rejects_invalid_shapes() -> None:
    assert _sys_model("bad") is None
    assert _sys_model({"_sys": "bad"}) is None
    assert _sys_model({"_sys": {"model": 7}}) is None


def test_daktela_ticket_connector_nested_string_list_handles_supported_item_types() -> None:
    assert _nested_string_list("bad") is None
    assert _nested_string_list(
        ["billing", 5, {"title": "Delivery"}, object()],
        fallback_keys=("title", "name"),
    ) == ["billing", "5", "Delivery"]


def test_daktela_ticket_connector_nested_named_string_map_handles_mixed_values() -> None:
    assert _nested_named_string_map("bad") is None
    assert _nested_named_string_map(
        [
            "open",
            {"name": "waiting", "title": "Waiting"},
            7,
        ]
    ) == {
        "open": "open",
        "waiting": "Waiting",
    }


def test_daktela_ticket_connector_normalize_custom_fields_rejects_invalid_types() -> None:
    assert _normalize_custom_fields("bad") is None


def test_daktela_ticket_connector_normalize_custom_fields_returns_list_passthrough() -> None:
    payload = [{"field": "consultant", "value": ["alice"]}]

    assert _normalize_custom_fields(payload) is payload
# temporary tests end


async def _load_live_ticket_by_id(
    connector: DaktelaTicketConnector,
    ticket_id: int,
) -> Ticket:
    response = await connector._send_get_request(f"/api/v6/tickets/{ticket_id}.json")
    return connector._ticket_from_payload(
        connector._ticket_payload_from_response(response.json())
    )


@pytest.mark.daktela_integration
@pytest.mark.asyncio
async def test_daktela_ticket_connector_get_whoiam_returns_live_user(
    live_daktela_connector: DaktelaTicketConnector,
) -> None:
    whoiam = await live_daktela_connector.get_whoiam()

    assert whoiam.title
    assert isinstance(whoiam.major_version, int)
    assert isinstance(whoiam.minor_version, int)


@pytest.mark.daktela_integration
@pytest.mark.asyncio
async def test_daktela_ticket_connector_list_views_returns_live_hierarchy(
    live_daktela_connector: DaktelaTicketConnector,
) -> None:
    views = await live_daktela_connector.list_views()
    view_names = {view.name for view in views}

    assert views
    assert all(view.name for view in views)
    assert any(view.title for view in views)
    assert any(view.filter is not None for view in views)
    assert all(
        view.parent_view is None or view.parent_view in view_names
        for view in views
    )


@pytest.mark.daktela_integration
@pytest.mark.asyncio
async def test_daktela_ticket_connector_list_tickets_returns_live_first_view_tickets(
    live_daktela_connector: DaktelaTicketConnector,
) -> None:
    views = await live_daktela_connector.list_views()

    tickets = await live_daktela_connector.list_tickets(views[0])

    assert len(tickets) > 0


@pytest.mark.daktela_integration
@pytest.mark.asyncio
async def test_daktela_ticket_connector_list_ticket_users_returns_live_users(
    live_daktela_connector: DaktelaTicketConnector,
) -> None:
    user_options = await live_daktela_connector.list_ticket_users()

    assert user_options
    assert all(option.name for option in user_options)
    assert all(option.title for option in user_options)


@pytest.mark.daktela_integration
@pytest.mark.asyncio
async def test_daktela_ticket_connector_store_ticket_updates_and_clears_live_user_assignment(
    live_daktela_connector: DaktelaTicketConnector,
    live_daktela_user_assignment_target: tuple[int, str],
) -> None:
    ticket_id, requested_user_name = live_daktela_user_assignment_target
    original_ticket = await _load_live_ticket_by_id(live_daktela_connector, ticket_id)
    user_options = await live_daktela_connector.list_ticket_users()
    user_options_by_name = {option.name: option for option in user_options}

    requested_option = user_options_by_name.get(requested_user_name)
    if requested_option is None:
        pytest.skip(
            f"Assignable user {requested_user_name!r} was not returned by list_ticket_users()."
        )

    assign_option = requested_option
    if original_ticket.user_name == assign_option.name:
        assign_option = next(
            (option for option in user_options if option.name != original_ticket.user_name),
            None,
        )
        if assign_option is None:
            pytest.skip("Need at least two assignable Daktela users for the live write test.")

    restore_patch = TicketEditPatch(
        user_name=original_ticket.user_name,
        user_title=original_ticket.user,
    )

    try:
        assigned_ticket = await live_daktela_connector.store_ticket(
            original_ticket,
            TicketEditPatch(
                user_name=assign_option.name,
                user_title=assign_option.title,
            ),
        )
        assert assigned_ticket.user_name == assign_option.name
        assert assigned_ticket.user == assign_option.title

        reloaded_assigned_ticket = await _load_live_ticket_by_id(
            live_daktela_connector,
            ticket_id,
        )
        assert reloaded_assigned_ticket.user_name == assign_option.name
        assert reloaded_assigned_ticket.user == assign_option.title

        cleared_ticket = await live_daktela_connector.store_ticket(
            reloaded_assigned_ticket,
            TicketEditPatch(user_name=None, user_title=None),
        )
        assert cleared_ticket.user_name is None
        assert cleared_ticket.user is None

        reloaded_cleared_ticket = await _load_live_ticket_by_id(
            live_daktela_connector,
            ticket_id,
        )
        assert reloaded_cleared_ticket.user_name is None
        assert reloaded_cleared_ticket.user is None
    finally:
        current_ticket = await _load_live_ticket_by_id(live_daktela_connector, ticket_id)
        await live_daktela_connector.store_ticket(current_ticket, restore_patch)


@pytest.mark.daktela_integration
@pytest.mark.asyncio
async def test_daktela_ticket_connector_create_ticket_comment_persists_live_comment(
    live_daktela_connector: DaktelaTicketConnector,
    live_daktela_comment_target: int,
) -> None:
    ticket = await _load_live_ticket_by_id(
        live_daktela_connector,
        live_daktela_comment_target,
    )
    marker = f"codex-comment-{os.urandom(4).hex()}"

    await live_daktela_connector.create_ticket_comment(
        ticket,
        TicketCommentCreateRequest(body=marker),
    )

    activities = await live_daktela_connector.list_ticket_activities(ticket)
    assert any(marker in (activity.body_text() or "") for activity in activities)
