from __future__ import annotations

import json
from pathlib import Path

import pytest

from daktela_paleo import instances as instances_module
from daktela_paleo.instances import (
    DaktelaInstanceConfig,
    DaktelaInstanceRecord,
    DaktelaInstanceStore,
)


def test_default_instance_config_path_uses_user_config_dir(
    monkeypatch,
    tmp_path: Path,
) -> None:
    config_dir = tmp_path / "config-home"
    monkeypatch.setattr(
        instances_module,
        "user_config_path",
        lambda app_name: config_dir / app_name,
    )

    assert instances_module.default_instance_config_path() == (
        config_dir / "daktela-paleo" / "instances.json"
    )


def test_instance_store_round_trips_multiple_instances_and_active_selection(
    tmp_path: Path,
) -> None:
    store = DaktelaInstanceStore(tmp_path / "instances.json")
    first = DaktelaInstanceRecord.create(
        "demo-one.daktela.com/",
        "token-1",
        id="one",
    )
    second = DaktelaInstanceRecord.create(
        "https://demo-two.daktela.com/",
        "token-2",
        id="two",
    )

    store.save(
        DaktelaInstanceConfig(
            active_instance_id="two",
            instances=[first, second],
        )
    )
    loaded = store.load()

    assert [instance.id for instance in loaded.instances] == ["one", "two"]
    assert [instance.base_url for instance in loaded.instances] == [
        "https://demo-one.daktela.com",
        "https://demo-two.daktela.com",
    ]
    assert loaded.active_instance_id == "two"
    assert loaded.active_instance() == second


def test_instance_config_active_instance_returns_none_when_constructed_with_missing_id() -> None:
    config = DaktelaInstanceConfig.model_construct(
        version=1,
        active_instance_id="missing",
        instances=[DaktelaInstanceRecord(id="saved", base_url="demo.daktela.com/", user_token="token")],
    )

    assert config.active_instance() is None


def test_instance_config_with_saved_instance_reuses_exact_duplicate_and_activates() -> None:
    existing = DaktelaInstanceRecord.create(
        "demo.daktela.com/",
        "token-1",
        id="saved",
    )
    config = DaktelaInstanceConfig(instances=[existing])

    updated, resolved = config.with_saved_instance(
        "https://demo.daktela.com/",
        "token-1",
        activate=True,
    )

    assert resolved == existing
    assert [instance.id for instance in updated.instances] == ["saved"]
    assert updated.active_instance_id == "saved"


def test_instance_config_with_saved_instance_allows_same_url_with_different_token() -> None:
    existing = DaktelaInstanceRecord.create(
        "demo.daktela.com/",
        "token-1",
        id="saved",
    )
    config = DaktelaInstanceConfig(instances=[existing])

    updated, resolved = config.with_saved_instance(
        "demo.daktela.com/",
        "token-2",
        activate=True,
    )

    assert len(updated.instances) == 2
    assert updated.instances[0] == existing
    assert updated.instances[1] == resolved
    assert resolved.base_url == "https://demo.daktela.com"
    assert resolved.user_token == "token-2"
    assert updated.active_instance_id == resolved.id


def test_instance_config_with_active_instance_returns_updated_copy() -> None:
    first = DaktelaInstanceRecord.create("first.daktela.com/", "token-1", id="one")
    second = DaktelaInstanceRecord.create("second.daktela.com/", "token-2", id="two")
    config = DaktelaInstanceConfig(active_instance_id="one", instances=[first, second])

    updated = config.with_active_instance("two")

    assert updated.active_instance_id == "two"
    assert updated.active_instance() == second
    assert config.active_instance_id == "one"


def test_instance_store_returns_empty_config_when_file_is_missing(tmp_path: Path) -> None:
    store = DaktelaInstanceStore(tmp_path / "instances.json")

    assert store.load() == DaktelaInstanceConfig()


def test_instance_store_returns_empty_config_when_read_fails(
    monkeypatch,
    tmp_path: Path,
) -> None:
    config_path = tmp_path / "instances.json"
    config_path.write_text("{}", encoding="utf-8")
    store = DaktelaInstanceStore(config_path)

    monkeypatch.setattr(
        Path,
        "read_text",
        lambda self, encoding="utf-8": (_ for _ in ()).throw(OSError("boom")),
    )

    assert store.load() == DaktelaInstanceConfig()


def test_instance_store_returns_empty_config_when_file_is_empty(tmp_path: Path) -> None:
    config_path = tmp_path / "instances.json"
    config_path.write_text(" \n", encoding="utf-8")

    store = DaktelaInstanceStore(config_path)

    assert store.load() == DaktelaInstanceConfig()


def test_instance_store_ignores_invalid_entries_and_clears_missing_active_instance(
    tmp_path: Path,
) -> None:
    config_path = tmp_path / "instances.json"
    config_path.write_text(
        """
        {
          "version": "oops",
          "active_instance_id": "missing",
          "instances": [
            {"id": "valid", "base_url": "demo.daktela.com/", "user_token": "token-1"},
            {"id": "", "base_url": "bad", "user_token": "token-2"},
            {"base_url": "demo-two.daktela.com/", "user_token": "token-3"}
          ]
        }
        """.strip(),
        encoding="utf-8",
    )

    store = DaktelaInstanceStore(config_path)
    loaded = store.load()

    assert loaded.version == 1
    assert loaded.active_instance_id is None
    assert loaded.instances == [
        DaktelaInstanceRecord(
            id="valid",
            base_url="https://demo.daktela.com",
            user_token="token-1",
        )
    ]


def test_instance_store_returns_empty_config_for_non_object_json(tmp_path: Path) -> None:
    config_path = tmp_path / "instances.json"
    config_path.write_text(json.dumps([]), encoding="utf-8")

    store = DaktelaInstanceStore(config_path)

    assert store.load() == DaktelaInstanceConfig()


def test_instance_store_returns_empty_config_when_json_is_malformed(tmp_path: Path) -> None:
    config_path = tmp_path / "instances.json"
    config_path.write_text("{not json", encoding="utf-8")

    store = DaktelaInstanceStore(config_path)

    assert store.load() == DaktelaInstanceConfig()


def test_instance_store_save_cleans_up_temp_file_when_replace_fails(
    monkeypatch,
    tmp_path: Path,
) -> None:
    store = DaktelaInstanceStore(tmp_path / "instances.json")
    config = DaktelaInstanceConfig(
        active_instance_id="one",
        instances=[DaktelaInstanceRecord(id="one", base_url="demo.daktela.com/", user_token="token")],
    )
    temp_files_before = set(tmp_path.iterdir())

    def raise_replace(self: Path, target: Path) -> None:
        raise OSError("replace failed")

    monkeypatch.setattr(Path, "replace", raise_replace)

    with pytest.raises(OSError, match="replace failed"):
        store.save(config)

    assert set(tmp_path.iterdir()) == temp_files_before
