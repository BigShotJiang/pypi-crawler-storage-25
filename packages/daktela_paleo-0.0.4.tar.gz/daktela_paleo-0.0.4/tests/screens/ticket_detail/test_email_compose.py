from types import SimpleNamespace
from typing import cast

import pytest
from textual import events
from textual.widgets import Button, Input, Static, TextArea

from daktela_paleo.models import TicketEmailAction, TicketEmailDraft, TicketEmailSendRequest
from daktela_paleo.screens.ticket_detail.widgets.comment_reply import ExternalEditorError
from daktela_paleo.screens.ticket_detail.widgets.email_compose import (
    EmailComposeInput,
    EmailComposeTextArea,
    TicketEmailComposer,
)
from tests.support import TicketDetailHarness, make_ticket


def make_draft(
    *,
    action: TicketEmailAction = TicketEmailAction.REPLY,
    source_activity_name: str | None = "activities_1",
    source_email_name: str = "emails_1",
    to: str = "customer@example.com",
    subject: str = "Re: Broken scanner",
    body: str = "Draft reply",
    queue_name: str = "support",
) -> TicketEmailDraft:
    return TicketEmailDraft(
        action=action,
        source_activity_name=source_activity_name,
        source_email_name=source_email_name,
        to=to,
        subject=subject,
        body=body,
        queue_name=queue_name,
    )


def test_ticket_email_composer_message_controls_reference_widget() -> None:
    composer = TicketEmailComposer()
    request = TicketEmailSendRequest(
        action=TicketEmailAction.REPLY,
        source_email_name="emails_1",
        to="customer@example.com",
        subject="Re: Broken scanner",
        body="Draft reply",
        queue_name="support",
    )

    assert composer.Submitted(composer, request).control is composer
    assert composer.Cancelled(composer).control is composer


def test_ticket_email_composer_on_key_routes_submit_edit_and_cancel_actions() -> None:
    composer = TicketEmailComposer()
    calls: list[str] = []
    composer._is_open = True
    original_has_focus_within = type(composer).has_focus_within
    type(composer).has_focus_within = property(lambda self: True)  # type: ignore[assignment]

    try:
        composer.action_submit = lambda: calls.append("submit")  # type: ignore[method-assign]
        composer.action_edit_in_external_editor = lambda: calls.append("edit")  # type: ignore[method-assign]
        composer.action_cancel = lambda: calls.append("cancel")  # type: ignore[method-assign]

        submit_event = cast(
            events.Key,
            SimpleNamespace(key="ctrl+s", stop=lambda: calls.append("stop-submit")),
        )
        composer.on_key(submit_event)

        external_edit_event = cast(
            events.Key,
            SimpleNamespace(key="ctrl+e", stop=lambda: calls.append("stop-edit")),
        )
        composer.on_key(external_edit_event)

        cancel_event = cast(
            events.Key,
            SimpleNamespace(key="escape", stop=lambda: calls.append("stop-cancel")),
        )
        composer.on_key(cancel_event)
    finally:
        type(composer).has_focus_within = original_has_focus_within  # type: ignore[assignment]

    assert calls == ["stop-submit", "submit", "stop-edit", "edit", "stop-cancel", "cancel"]


def test_ticket_email_composer_on_key_ignores_when_closed_or_unfocused() -> None:
    composer = TicketEmailComposer()
    calls: list[str] = []
    composer.action_submit = lambda: calls.append("submit")  # type: ignore[method-assign]

    composer.on_key(cast(events.Key, SimpleNamespace(key="ctrl+s", stop=lambda: calls.append("stop"))))

    assert calls == []


def test_ticket_email_composer_button_press_routes_submit_and_cancel_actions() -> None:
    composer = TicketEmailComposer()
    calls: list[str] = []

    composer.action_submit = lambda: calls.append("submit")  # type: ignore[method-assign]
    composer.action_cancel = lambda: calls.append("cancel")  # type: ignore[method-assign]

    composer.on_button_pressed(
        cast(
            Button.Pressed,
            SimpleNamespace(
                button=SimpleNamespace(id="email-reply-submit"),
                stop=lambda: calls.append("stop-submit"),
            ),
        )
    )
    composer.on_button_pressed(
        cast(
            Button.Pressed,
            SimpleNamespace(
                button=SimpleNamespace(id="email-reply-cancel"),
                stop=lambda: calls.append("stop-cancel"),
            ),
        )
    )

    assert calls == ["stop-submit", "submit", "stop-cancel", "cancel"]


def test_ticket_email_composer_open_draft_populates_fields_and_focus_target(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    composer = TicketEmailComposer()
    to_input = SimpleNamespace(value="")
    subject_input = SimpleNamespace(value="")
    body_input = SimpleNamespace(load_text=lambda text: load_calls.append(text), text="")
    validation_widget = SimpleNamespace(update=lambda text: validation_updates.append(text), display=None)
    submit_button = SimpleNamespace(disabled=False)
    cancel_button = SimpleNamespace(disabled=False)
    title_widget = SimpleNamespace(update=lambda text: title_updates.append(text))
    hint_widget = SimpleNamespace(update=lambda text: hint_updates.append(text))
    load_calls: list[str] = []
    validation_updates: list[str] = []
    title_updates: list[str] = []
    hint_updates: list[str] = []
    class_calls: list[tuple[bool, str]] = []
    focus_calls: list[str] = []

    def fake_query_one(selector: str, *_args: object) -> object:
        lookup = {
            "#email-reply-to": to_input,
            "#email-reply-subject": subject_input,
            "#email-reply-body": body_input,
            "#email-reply-validation": validation_widget,
            "#email-reply-submit": submit_button,
            "#email-reply-cancel": cancel_button,
            "#email-reply-title": title_widget,
            "#email-reply-hint": hint_widget,
        }
        return lookup[selector]

    monkeypatch.setattr(composer, "query_one", fake_query_one)
    monkeypatch.setattr(composer, "set_class", lambda enabled, name: class_calls.append((enabled, name)))
    monkeypatch.setattr(composer, "focus_editor", lambda: focus_calls.append("focus"))

    composer.open_draft(make_draft())
    composer.open_draft(make_draft(action=TicketEmailAction.FORWARD, to="", subject="Fwd: Broken scanner"))

    assert composer.is_open is True
    assert composer.action is TicketEmailAction.FORWARD
    assert composer.source_activity_name == "activities_1"
    assert class_calls == [(True, "-open"), (True, "-open")]
    assert to_input.value == ""
    assert subject_input.value == "Fwd: Broken scanner"
    assert load_calls == ["Draft reply", "Draft reply"]
    assert validation_updates == ["", ""]
    assert validation_widget.display is False
    assert title_updates == ["Reply to all email", "Forward email"]
    assert hint_updates == [
        "Reply target stays locked while this draft is open. Ctrl+E opens $EDITOR. Enter inserts a newline.",
        "Forward keeps the selected activity visible while you compose. Ctrl+E opens $EDITOR. Enter inserts a newline.",
    ]
    assert focus_calls == ["focus", "focus"]
    assert composer._focused_field == "to"


def test_ticket_email_composer_close_clears_state(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    composer = TicketEmailComposer()
    to_input = SimpleNamespace(value="customer@example.com", disabled=True)
    subject_input = SimpleNamespace(value="Re: Broken scanner", disabled=True)
    body_input = SimpleNamespace(load_text=lambda text: load_calls.append(text), read_only=True)
    validation_widget = SimpleNamespace(update=lambda text: validation_updates.append(text), display=None)
    submit_button = SimpleNamespace(disabled=True)
    cancel_button = SimpleNamespace(disabled=True)
    title_widget = SimpleNamespace(update=lambda text: title_updates.append(text))
    hint_widget = SimpleNamespace(update=lambda text: hint_updates.append(text))
    load_calls: list[str] = []
    validation_updates: list[str] = []
    title_updates: list[str] = []
    hint_updates: list[str] = []
    class_calls: list[tuple[bool, str]] = []

    def fake_query_one(selector: str, *_args: object) -> object:
        lookup = {
            "#email-reply-to": to_input,
            "#email-reply-subject": subject_input,
            "#email-reply-body": body_input,
            "#email-reply-validation": validation_widget,
            "#email-reply-submit": submit_button,
            "#email-reply-cancel": cancel_button,
            "#email-reply-title": title_widget,
            "#email-reply-hint": hint_widget,
        }
        return lookup[selector]

    monkeypatch.setattr(composer, "query_one", fake_query_one)
    monkeypatch.setattr(composer, "set_class", lambda enabled, name: class_calls.append((enabled, name)))
    composer._is_open = True
    composer._is_submitting = True
    composer._action = TicketEmailAction.FORWARD
    composer._source_activity_name = "activities_1"
    composer._source_email_name = "emails_1"
    composer._queue_name = "support"

    composer.close()

    assert composer.is_open is False
    assert composer.action is None
    assert composer.source_activity_name is None
    assert class_calls == [(False, "-open")]
    assert to_input.value == ""
    assert subject_input.value == ""
    assert load_calls == [""]
    assert validation_updates == [""]
    assert validation_widget.display is False
    assert title_updates == ["Reply to all email"]
    assert hint_updates == [
        "Reply target stays locked while this draft is open. Ctrl+E opens $EDITOR. Enter inserts a newline."
    ]
    assert to_input.disabled is False
    assert subject_input.disabled is False
    assert body_input.read_only is False
    assert submit_button.disabled is False
    assert cancel_button.disabled is False


def test_ticket_email_composer_focus_editor_returns_when_closed() -> None:
    composer = TicketEmailComposer()

    composer.focus_editor()


def test_ticket_email_composer_set_submission_pending_updates_controls(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    composer = TicketEmailComposer()
    pending_calls: list[bool] = []

    monkeypatch.setattr(composer, "_set_submitting", lambda pending: pending_calls.append(pending))

    composer.set_submission_pending(True)

    assert composer._is_submitting is True
    assert pending_calls == [True]


def test_ticket_email_composer_action_submit_validates_to_and_posts_request(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    composer = TicketEmailComposer()
    validation_widget = SimpleNamespace(update=lambda text: validation_updates.append(text), display=None)
    posted_messages: list[TicketEmailComposer.Submitted] = []
    validation_updates: list[str] = []
    focus_calls: list[str] = []

    def fake_query_one(selector: str, *_args: object) -> object:
        lookup = {
            "#email-reply-to": SimpleNamespace(value="  customer@example.com  "),
            "#email-reply-subject": SimpleNamespace(value=" Re: Broken scanner "),
            "#email-reply-body": SimpleNamespace(text="  Draft body  "),
            "#email-reply-validation": validation_widget,
        }
        return lookup[selector]

    monkeypatch.setattr(composer, "query_one", fake_query_one)
    monkeypatch.setattr(composer, "post_message", posted_messages.append)
    monkeypatch.setattr(composer, "focus_editor", lambda: focus_calls.append("focus"))
    monkeypatch.setattr(
        composer,
        "_capture_focused_field",
        lambda: setattr(composer, "_focused_field", "subject"),
    )
    composer._is_open = True
    composer._action = TicketEmailAction.REPLY
    composer._source_email_name = "emails_1"
    composer._queue_name = "support"

    composer.action_submit()

    assert validation_updates == [""]
    assert validation_widget.display is False
    assert focus_calls == []
    assert len(posted_messages) == 1
    assert posted_messages[0].request == TicketEmailSendRequest(
        action=TicketEmailAction.REPLY,
        source_email_name="emails_1",
        to="customer@example.com",
        subject="Re: Broken scanner",
        body="Draft body",
        queue_name="support",
    )


def test_ticket_email_composer_action_submit_blank_to_stays_open_and_focuses_editor(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    composer = TicketEmailComposer()
    validation_widget = SimpleNamespace(update=lambda text: validation_updates.append(text), display=None)
    validation_updates: list[str] = []
    focus_calls: list[str] = []

    def fake_query_one(selector: str, *_args: object) -> object:
        lookup = {
            "#email-reply-to": SimpleNamespace(value="   "),
            "#email-reply-subject": SimpleNamespace(value="Subject"),
            "#email-reply-body": SimpleNamespace(text="Body"),
            "#email-reply-validation": validation_widget,
        }
        return lookup[selector]

    monkeypatch.setattr(composer, "query_one", fake_query_one)
    monkeypatch.setattr(composer, "focus_editor", lambda: focus_calls.append("focus"))
    monkeypatch.setattr(
        composer,
        "post_message",
        lambda message: (_ for _ in ()).throw(
            AssertionError(f"post_message should not be called for blank to: {message!r}")
        ),
    )
    composer._is_open = True
    composer._action = TicketEmailAction.REPLY
    composer._source_email_name = "emails_1"
    composer._queue_name = "support"

    composer.action_submit()

    assert validation_updates == ["Recipient list can't be blank."]
    assert validation_widget.display is True
    assert focus_calls == ["focus"]
    assert composer._focused_field == "to"


def test_ticket_email_composer_action_submit_requires_loaded_metadata(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    composer = TicketEmailComposer()
    validation_widget = SimpleNamespace(update=lambda text: validation_updates.append(text), display=None)
    validation_updates: list[str] = []
    focus_calls: list[str] = []

    def fake_query_one(selector: str, *_args: object) -> object:
        lookup = {
            "#email-reply-to": SimpleNamespace(value="customer@example.com"),
            "#email-reply-subject": SimpleNamespace(value="Subject"),
            "#email-reply-body": SimpleNamespace(text="Body"),
            "#email-reply-validation": validation_widget,
        }
        return lookup[selector]

    monkeypatch.setattr(composer, "query_one", fake_query_one)
    monkeypatch.setattr(composer, "focus_editor", lambda: focus_calls.append("focus"))
    monkeypatch.setattr(
        composer,
        "post_message",
        lambda message: (_ for _ in ()).throw(
            AssertionError(f"post_message should not be called without metadata: {message!r}")
        ),
    )
    composer._is_open = True

    composer.action_submit()

    assert validation_updates == ["Email draft is not ready yet."]
    assert validation_widget.display is True
    assert focus_calls == ["focus"]


def test_ticket_email_composer_action_cancel_posts_cancelled_message(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    composer = TicketEmailComposer()
    posted_messages: list[TicketEmailComposer.Cancelled] = []
    monkeypatch.setattr(composer, "post_message", posted_messages.append)
    composer._is_open = True

    composer.action_cancel()

    assert len(posted_messages) == 1


def test_ticket_email_composer_action_edit_in_external_editor_round_trips_body(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    composer = TicketEmailComposer()
    validation_messages: list[str] = []
    focus_calls: list[str] = []
    load_calls: list[str] = []
    to_input = SimpleNamespace(value="customer@example.com")
    subject_input = SimpleNamespace(value="Re: Broken scanner")
    body_input = SimpleNamespace(text="Draft reply", load_text=load_calls.append)
    validation_widget = SimpleNamespace(update=validation_messages.append, display=None)

    def fake_query_one(selector: str, *_args: object) -> object:
        lookup = {
            "#email-reply-to": to_input,
            "#email-reply-subject": subject_input,
            "#email-reply-body": body_input,
            "#email-reply-validation": validation_widget,
        }
        return lookup[selector]

    monkeypatch.setattr(composer, "query_one", fake_query_one)
    monkeypatch.setattr(composer, "focus_editor", lambda: focus_calls.append("focus"))
    monkeypatch.setattr(
        composer,
        "_edit_draft_in_external_editor",
        lambda draft: f"{draft}\nEdited externally",
    )
    composer._is_open = True
    composer._action = TicketEmailAction.REPLY
    composer._focused_field = "subject"

    composer.action_edit_in_external_editor()

    assert validation_messages == [""]
    assert validation_widget.display is False
    assert load_calls == ["Draft reply\nEdited externally"]
    assert focus_calls == ["focus"]
    assert composer._focused_field == "body"
    assert to_input.value == "customer@example.com"
    assert subject_input.value == "Re: Broken scanner"


def test_ticket_email_composer_action_edit_in_external_editor_preserves_body_on_failure(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    composer = TicketEmailComposer()
    validation_messages: list[str] = []
    focus_calls: list[str] = []
    load_calls: list[str] = []
    body_input = SimpleNamespace(text="Draft reply", load_text=load_calls.append)
    validation_widget = SimpleNamespace(update=validation_messages.append, display=None)

    def fake_query_one(selector: str, *_args: object) -> object:
        lookup = {
            "#email-reply-body": body_input,
            "#email-reply-validation": validation_widget,
        }
        return lookup[selector]

    monkeypatch.setattr(composer, "query_one", fake_query_one)
    monkeypatch.setattr(composer, "focus_editor", lambda: focus_calls.append("focus"))
    monkeypatch.setattr(
        composer,
        "_edit_draft_in_external_editor",
        lambda _draft: (_ for _ in ()).throw(ExternalEditorError("Unable to launch external editor.")),
    )
    composer._is_open = True
    composer._focused_field = "to"

    composer.action_edit_in_external_editor()

    assert validation_messages == ["", "Unable to launch external editor."]
    assert validation_widget.display is True
    assert load_calls == []
    assert focus_calls == ["focus"]
    assert composer._focused_field == "body"


def test_ticket_email_composer_action_submit_and_cancel_ignore_closed_or_pending_state() -> None:
    composer = TicketEmailComposer()

    composer.action_submit()
    composer.action_cancel()
    composer._is_open = True
    composer._is_submitting = True
    composer.action_submit()
    composer.action_cancel()


def test_ticket_email_composer_action_edit_in_external_editor_ignores_closed_or_pending_state() -> None:
    composer = TicketEmailComposer()

    composer.action_edit_in_external_editor()
    composer._is_open = True
    composer._is_submitting = True
    composer.action_edit_in_external_editor()


def test_ticket_email_composer_capture_focused_field_tracks_supported_inputs(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    composer = TicketEmailComposer()
    monkeypatch.setattr(
        TicketEmailComposer,
        "app",
        property(lambda _self: SimpleNamespace(focused=SimpleNamespace(id="email-reply-to"))),
    )

    composer._capture_focused_field()
    assert composer._focused_field == "to"

    monkeypatch.setattr(
        TicketEmailComposer,
        "app",
        property(lambda _self: SimpleNamespace(focused=SimpleNamespace(id="email-reply-subject"))),
    )
    composer._capture_focused_field()
    assert composer._focused_field == "subject"

    monkeypatch.setattr(
        TicketEmailComposer,
        "app",
        property(lambda _self: SimpleNamespace(focused=SimpleNamespace(id="email-reply-body"))),
    )
    composer._capture_focused_field()
    assert composer._focused_field == "body"


@pytest.mark.asyncio
async def test_ticket_email_composer_renders_inside_ticket_detail() -> None:
    app = TicketDetailHarness(make_ticket(title="Broken scanner"))

    async with app.run_test() as pilot:
        await pilot.pause()

        composer = app.screen.query_one("#email-reply-composer", TicketEmailComposer)
        to_input = composer.query_one("#email-reply-to", Input)
        subject_input = composer.query_one("#email-reply-subject", Input)
        body_input = composer.query_one("#email-reply-body", TextArea)
        submit_button = composer.query_one("#email-reply-submit", Button)
        cancel_button = composer.query_one("#email-reply-cancel", Button)
        validation = composer.query_one("#email-reply-validation", Static)

        assert composer.query_one("#email-reply-title", Static).render() == "Reply to all email"
        assert composer.query_one("#email-reply-hint", Static).render() == (
            "Selected activity stays visible while you compose. Ctrl+E opens $EDITOR. Enter inserts a newline."
        )
        assert validation.render() == ""
        assert validation.display is False
        assert to_input.value == ""
        assert subject_input.value == ""
        assert body_input.text == ""
        assert submit_button.styles.min_width is not None
        assert submit_button.styles.min_width.cells == 0
        assert cancel_button.styles.min_width is not None
        assert cancel_button.styles.min_width.cells == 0


@pytest.mark.asyncio
async def test_ticket_email_input_and_text_area_delegate_actions_to_parent_composer() -> None:
    app = TicketDetailHarness(make_ticket(title="Broken scanner"))

    async with app.run_test() as pilot:
        await pilot.pause()

        composer = app.screen.query_one("#email-reply-composer", TicketEmailComposer)
        to_input = composer.query_one("#email-reply-to", EmailComposeInput)
        body_input = composer.query_one("#email-reply-body", EmailComposeTextArea)
        calls: list[str] = []

        composer.action_submit = lambda: calls.append("submit")  # type: ignore[method-assign]
        composer.action_edit_in_external_editor = lambda: calls.append("edit")  # type: ignore[method-assign]
        composer.action_cancel = lambda: calls.append("cancel")  # type: ignore[method-assign]

        to_input.action_submit_email()
        to_input.action_edit_in_external_editor()
        to_input.action_cancel_email()
        body_input.action_submit_email()
        body_input.action_edit_in_external_editor()
        body_input.action_cancel_email()

        assert calls == ["submit", "edit", "cancel", "submit", "edit", "cancel"]
