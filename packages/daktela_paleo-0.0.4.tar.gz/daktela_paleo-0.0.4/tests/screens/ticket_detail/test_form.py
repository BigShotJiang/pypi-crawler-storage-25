from datetime import datetime
from types import SimpleNamespace
from typing import cast

import pytest
from rich.text import Text
from textual import events
from textual.css.query import NoMatches
from textual.widgets.option_list import Option
from textual.widgets import Input, Select, TextArea
from textual.widgets._select import SelectOverlay
from textual.widgets import Static

from daktela_paleo.models import (
    TicketCategoryOption,
    TicketCustomField,
    TicketCustomFieldOption,
    TicketEditPatch,
    TicketPriority,
    TicketStatusOption,
    TicketStage,
    TicketUserOption,
)
from daktela_paleo.screens.ticket_detail.widgets.form import (
    EditStopped,
    NO_STATUS_VALUE,
    TicketDetailForm,
    TicketFormSelect,
    TicketFormSelectOverlay,
    UNASSIGNED_USER_VALUE,
)
from tests.support import TicketDetailHarness, make_ticket, make_ticket_custom_fields


def overlay_labels(overlay: TicketFormSelectOverlay) -> list[str]:
    return [
        prompt.plain if isinstance(prompt, Text) else str(prompt)
        for prompt in (option.prompt for option in overlay.options)
    ]


def test_ticket_detail_form_custom_field_rendering_helpers_cover_empty_values_and_fallbacks() -> None:
    form = TicketDetailForm(make_ticket(title="Broken scanner", name=2001))

    assert (
        form._render_custom_field_value(
            TicketCustomField(
                field="empty_field",
                title="Empty Field",
                values=[None, "   "],
            )
        )
        is None
    )
    assert (
        form._render_custom_field_value(
            TicketCustomField(
                field="attempt_count",
                title="Attempt Count",
                values=[7],
            )
        )
        == "7"
    )
    assert (
        form._render_custom_field_value(
            TicketCustomField(
                field="consultant",
                title="Consultant",
                values=["bob"],
                options=[
                    TicketCustomFieldOption(value="alice", title="Alice"),
                    TicketCustomFieldOption(value="bob", title="Bob"),
                ],
            )
        )
        == "Bob"
    )


@pytest.mark.asyncio
async def test_ticket_detail_form_uses_title_label_for_name_field() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        name_row = app.screen.query_one("#ticket-name-row")
        label = name_row.query_one(".ticket-detail-form-label", Static)

        assert label.render() == "Title:"


@pytest.mark.asyncio
async def test_ticket_detail_form_renders_description_textarea_with_multiple_rows() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001, description="First line")
    app = TicketDetailHarness(ticket)

    async with app.run_test(size=(120, 30)) as pilot:
        await pilot.pause()

        reopen_row = app.screen.query_one("#ticket-reopen-row")
        description_row = app.screen.query_one("#ticket-description-row")
        description = app.screen.query_one("#ticket-description-input", TextArea)

        assert description_row.region.y == reopen_row.region.y + reopen_row.region.height
        assert description_row.region.height == description.region.height
        assert description.region.height >= 2


@pytest.mark.asyncio
async def test_ticket_detail_form_left_arrow_focuses_textarea_and_escape_returns_to_form() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        description="First line",
        custom_fields=make_ticket_custom_fields(),
    )
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        form = app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        description = app.screen.query_one("#ticket-description-input", TextArea)

        assert app.focused is form
        assert form.active_index == 0

        await pilot.press("down")
        await pilot.pause()
        assert form.active_index == 1

        await pilot.press("down")
        await pilot.pause()
        assert form.active_index == 2

        await pilot.press("down")
        await pilot.pause()
        assert form.active_index == 3

        await pilot.press("down")
        await pilot.pause()
        assert form.active_index == 4

        await pilot.press("down")
        await pilot.pause()
        assert form.active_index == 5

        await pilot.press("down")
        await pilot.pause()
        assert form.active_index == 6

        await pilot.press("down")
        await pilot.pause()
        assert form.active_index == 7

        await pilot.press("left")
        await pilot.pause()
        assert app.focused is description

        await pilot.press("x")
        await pilot.pause()
        assert description.text.startswith("x")

        await pilot.press("escape")
        await pilot.pause()
        assert app.focused is form
        assert form.active_index == 7


@pytest.mark.asyncio
async def test_ticket_detail_form_left_arrow_opens_stage_select_and_returns_to_form() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001, stage=TicketStage.OPEN)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        form = app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        stage_select = app.screen.query_one("#ticket-stage-input", Select)

        await pilot.press("down")
        await pilot.pause()
        assert form.active_index == 1

        await pilot.press("left")
        await pilot.pause()
        assert stage_select.expanded is True

        await pilot.press("down", "enter")
        await pilot.pause()

        assert app.focused is form
        assert form.active_index == 1
        assert stage_select.value == "WAIT"


@pytest.mark.asyncio
async def test_ticket_detail_form_l_opens_priority_select_and_returns_to_form() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001, priority=TicketPriority.HIGH)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        form = app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        priority_select = app.screen.query_one("#ticket-priority-input", Select)

        await pilot.press("down", "down")
        await pilot.pause()
        assert form.active_index == 2

        await pilot.press("l")
        await pilot.pause()
        assert priority_select.expanded is True

        await pilot.press("down", "enter")
        await pilot.pause()

        assert app.focused is form
        assert form.active_index == 2
        assert priority_select.value == "MEDIUM"
        assert form.build_patch() == TicketEditPatch(priority=TicketPriority.MEDIUM)


@pytest.mark.asyncio
async def test_ticket_detail_form_l_opens_category_select_and_returns_to_form() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        category="Delivery",
        category_name="categories_delivery",
    )
    app = TicketDetailHarness(
        ticket,
        category_options=[
            TicketCategoryOption(name="categories_delivery", title="Delivery"),
            TicketCategoryOption(name="categories_returns", title="Returns"),
        ],
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        form = app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        category_select = app.screen.query_one("#ticket-category-input", Select)

        await pilot.press("down", "down", "down")
        await pilot.pause()
        assert form.active_index == 3

        await pilot.press("l")
        await pilot.pause()
        assert category_select.expanded is True

        await pilot.press("down", "enter")
        await pilot.pause()

        assert app.focused is form
        assert form.active_index == 3
        assert category_select.value == "categories_returns"


@pytest.mark.asyncio
async def test_ticket_detail_form_category_select_supports_hjkl_navigation() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        category="Delivery",
        category_name="categories_delivery",
    )
    app = TicketDetailHarness(
        ticket,
        category_options=[
            TicketCategoryOption(name="categories_billing", title="Billing"),
            TicketCategoryOption(name="categories_delivery", title="Delivery"),
            TicketCategoryOption(name="categories_returns", title="Returns"),
        ],
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        form = app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        category_select = app.screen.query_one("#ticket-category-input", Select)

        await pilot.press("down", "down", "down", "enter")
        await pilot.pause()

        await pilot.press("j", "l")
        await pilot.pause()

        assert app.focused is form
        assert form.active_index == 3
        assert category_select.value == "categories_returns"

        await pilot.press("enter")
        await pilot.pause()

        await pilot.press("k", "h")
        await pilot.pause()

        assert app.focused is form
        assert category_select.value == "categories_returns"


@pytest.mark.asyncio
async def test_ticket_detail_form_l_opens_user_select_and_returns_to_form() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        user="Operator One",
        user_name="operator_1",
    )
    app = TicketDetailHarness(
        ticket,
        user_options=[
            TicketUserOption(name="operator_1", title="Operator One"),
            TicketUserOption(name="operator_2", title="Operator Two"),
        ],
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        form = app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        user_select = app.screen.query_one("#ticket-user-input", Select)

        await pilot.press("down", "down", "down", "down")
        await pilot.pause()
        assert form.active_index == 4

        await pilot.press("l")
        await pilot.pause()
        assert user_select.expanded is True

        await pilot.press("down", "enter")
        await pilot.pause()

        assert app.focused is form
        assert form.active_index == 4
        assert user_select.value == "operator_2"


@pytest.mark.asyncio
async def test_ticket_detail_form_l_opens_status_select_and_returns_to_form() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        category="Delivery",
        category_name="categories_delivery",
        statuses={"status_dispatch": "Dispatch"},
    )
    app = TicketDetailHarness(
        ticket,
        status_options=[
            TicketStatusOption(name="status_dispatch", title="Dispatch"),
            TicketStatusOption(name="status_return", title="Return"),
        ],
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        form = app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        status_select = app.screen.query_one("#ticket-status-input", Select)

        await pilot.press("down", "down", "down", "down", "down")
        await pilot.pause()
        assert form.active_index == 5

        await pilot.press("l")
        await pilot.pause()
        assert status_select.expanded is True

        await pilot.press("down", "enter")
        await pilot.pause()

        assert app.focused is form
        assert form.active_index == 5
        assert status_select.value == "status_return"
        assert form.build_patch() == TicketEditPatch(
            status_name="status_return",
            status_title="Return",
        )


@pytest.mark.asyncio
async def test_ticket_detail_form_reopen_input_builds_datetime_patch() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        reopen=datetime(2026, 3, 30, 8, 0, 0),
    )
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        form = app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        reopen_input = app.screen.query_one("#ticket-reopen-input", Input)

        await pilot.press("down", "down", "down", "down", "down", "down", "enter")
        await pilot.pause()

        reopen_input.value = "2026-03-31 09:15:00"
        await pilot.press("escape")
        await pilot.pause()

        assert app.focused is form
        assert form.active_index == 6
        assert form.build_patch() == TicketEditPatch(
            reopen=datetime(2026, 3, 31, 9, 15, 0)
        )


@pytest.mark.asyncio
async def test_ticket_detail_form_user_select_supports_unassign_and_hjkl_navigation() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        user="Operator One",
        user_name="operator_1",
    )
    app = TicketDetailHarness(
        ticket,
        user_options=[
            TicketUserOption(name="operator_1", title="Operator One"),
            TicketUserOption(name="operator_2", title="Operator Two"),
        ],
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        form = app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        user_select = app.screen.query_one("#ticket-user-input", Select)

        await pilot.press("down", "down", "down", "down", "enter")
        await pilot.pause()

        await pilot.press("k", "l")
        await pilot.pause()

        assert app.focused is form
        assert form.active_index == 4
        assert user_select.value == UNASSIGNED_USER_VALUE


@pytest.mark.asyncio
async def test_ticket_detail_form_d_clears_user_select_and_builds_unassign_patch() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        user="Operator One",
        user_name="operator_1",
    )
    app = TicketDetailHarness(
        ticket,
        user_options=[
            TicketUserOption(name="operator_1", title="Operator One"),
            TicketUserOption(name="operator_2", title="Operator Two"),
        ],
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        form = app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        user_select = app.screen.query_one("#ticket-user-input", TicketFormSelect)

        await pilot.press("down", "down", "down", "down", "d")
        await pilot.pause()

        assert app.focused is form
        assert form.active_index == 4
        assert user_select.value == UNASSIGNED_USER_VALUE
        assert form.build_patch() == TicketEditPatch(user_name=None, user_title=None)


@pytest.mark.asyncio
async def test_ticket_detail_form_d_does_not_clear_non_clearable_selects() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        category="Delivery",
        category_name="categories_delivery",
    )
    app = TicketDetailHarness(
        ticket,
        category_options=[
            TicketCategoryOption(name="categories_delivery", title="Delivery"),
            TicketCategoryOption(name="categories_returns", title="Returns"),
        ],
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        form = app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        category_select = app.screen.query_one("#ticket-category-input", TicketFormSelect)

        await pilot.press("down", "down", "down", "d")
        await pilot.pause()

        assert app.focused is form
        assert form.active_index == 3
        assert category_select.value == "categories_delivery"


@pytest.mark.asyncio
async def test_ticket_detail_form_d_does_not_clear_priority_select() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        priority=TicketPriority.HIGH,
    )
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        form = app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        priority_select = app.screen.query_one("#ticket-priority-input", TicketFormSelect)

        await pilot.press("down", "down", "d")
        await pilot.pause()

        assert app.focused is form
        assert form.active_index == 2
        assert priority_select.value == "HIGH"


@pytest.mark.asyncio
async def test_ticket_detail_form_d_does_not_clear_user_select_while_overlay_is_open() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        user="Operator One",
        user_name="operator_1",
    )
    app = TicketDetailHarness(
        ticket,
        user_options=[
            TicketUserOption(name="operator_1", title="Operator One"),
            TicketUserOption(name="operator_2", title="Operator Two"),
        ],
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        form = app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        user_select = app.screen.query_one("#ticket-user-input", TicketFormSelect)

        await pilot.press("down", "down", "down", "down", "enter")
        await pilot.pause()

        assert form.editing is True
        assert user_select.expanded is True

        await pilot.press("d")
        await pilot.pause()

        assert form.editing is True
        assert user_select.expanded is True
        assert user_select.value == "operator_1"


async def test_ticket_detail_form_category_select_search_filters_and_selects_fuzzy_match() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        category="Delivery",
        category_name="categories_delivery",
    )
    app = TicketDetailHarness(
        ticket,
        category_options=[
            TicketCategoryOption(name="categories_billing", title="Billing"),
            TicketCategoryOption(name="categories_delivery", title="Delivery"),
            TicketCategoryOption(name="categories_returns", title="Returns"),
        ],
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        form = app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        category_select = app.screen.query_one("#ticket-category-input", TicketFormSelect)
        overlay = category_select.query_one(TicketFormSelectOverlay)

        await pilot.press("down", "down", "down", "enter")
        await pilot.pause()

        await pilot.press("i", "r", "t", "n")
        await pilot.pause()

        assert category_select.expanded is True
        assert overlay.search_active is True
        assert overlay.search_query == "rtn"
        assert overlay_labels(overlay) == ["Returns"]

        await pilot.press("enter")
        await pilot.pause()

        assert app.focused is form
        assert form.active_index == 3
        assert category_select.value == "categories_returns"


@pytest.mark.asyncio
async def test_ticket_detail_form_select_escape_exits_search_before_closing_overlay() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        user="Operator One",
        user_name="operator_1",
    )
    app = TicketDetailHarness(
        ticket,
        user_options=[
            TicketUserOption(name="operator_1", title="Operator One"),
            TicketUserOption(name="operator_2", title="Operator Two"),
        ],
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        form = app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        user_select = app.screen.query_one("#ticket-user-input", TicketFormSelect)
        overlay = user_select.query_one(TicketFormSelectOverlay)

        await pilot.press("down", "down", "down", "down", "enter")
        await pilot.pause()

        await pilot.press("i", "t", "w")
        await pilot.pause()

        assert user_select.expanded is True
        assert overlay.search_active is True
        assert overlay_labels(overlay) == ["Operator Two"]

        await pilot.press("escape")
        await pilot.pause()

        assert user_select.expanded is True
        assert overlay.search_active is False
        assert overlay.search_query == ""
        assert overlay_labels(overlay) == ["Unassigned", "Operator One", "Operator Two"]

        await pilot.press("escape")
        await pilot.pause()

        assert user_select.expanded is False
        assert app.focused is form

        await pilot.press("enter")
        await pilot.pause()

        assert user_select.expanded is True
        assert overlay.search_active is False
        assert overlay.search_query == ""
        assert overlay_labels(overlay) == ["Unassigned", "Operator One", "Operator Two"]


@pytest.mark.asyncio
async def test_ticket_detail_form_enter_submits_title_edit_back_to_navigation_mode() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        form = app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        title_input = app.screen.query_one("#ticket-name-input", Input)

        assert app.focused is form

        await pilot.press("enter")
        await pilot.pause()
        assert app.focused is title_input

        await pilot.press("enter")
        await pilot.pause()
        assert app.focused is form


@pytest.mark.asyncio
async def test_ticket_detail_form_enter_submits_reopen_edit_back_to_navigation_mode() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        form = app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        reopen_input = app.screen.query_one("#ticket-reopen-input", Input)

        await pilot.press("down", "down", "down", "down", "down", "down", "enter")
        await pilot.pause()
        assert app.focused is reopen_input

        await pilot.press("enter")
        await pilot.pause()
        assert app.focused is form
        assert form.active_index == 6


@pytest.mark.asyncio
async def test_ticket_detail_title_backspace_removes_only_last_character() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        title_input = app.screen.query_one("#ticket-name-input", Input)

        await pilot.press("enter")
        await pilot.pause()
        assert app.focused is title_input

        await pilot.press("backspace")
        await pilot.pause()

        assert app.focused is title_input
        assert title_input.value == "Broken scanne"


@pytest.mark.asyncio
async def test_ticket_detail_title_typing_appends_instead_of_replacing_value() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        title_input = app.screen.query_one("#ticket-name-input", Input)

        await pilot.press("enter")
        await pilot.pause()
        assert app.focused is title_input

        await pilot.press("x")
        await pilot.pause()

        assert app.focused is title_input
        assert title_input.value == "Broken scannerx"


def test_ticket_form_select_action_stop_edit_posts_edit_stopped_message() -> None:
    select = TicketFormSelect(
        [("Delivery", "delivery")],
        value="delivery",
        id="ticket-category-input",
        classes="ticket-detail-form-control",
    )
    messages: list[EditStopped] = []
    select.post_message = messages.append  # type: ignore[method-assign]

    select.action_stop_edit()

    assert select._return_focus_after_collapse is False
    assert len(messages) == 1
    assert messages[0].control is select


def test_ticket_form_select_clear_selection_uses_configured_clear_value() -> None:
    select = TicketFormSelect(
        [("Unassigned", UNASSIGNED_USER_VALUE), ("Operator One", "operator_1")],
        value="operator_1",
        id="ticket-user-input",
        classes="ticket-detail-form-control",
        clear_value=UNASSIGNED_USER_VALUE,
    )

    select.clear_selection()

    assert select.is_clearable is True
    assert select.value == UNASSIGNED_USER_VALUE


def test_ticket_form_select_clear_selection_returns_early_when_unclearable() -> None:
    select = TicketFormSelect(
        [("Operator One", "operator_1")],
        value="operator_1",
        id="ticket-user-input",
        classes="ticket-detail-form-control",
    )
    original_value = select.value

    select.clear_selection()

    assert select.value == original_value


def test_ticket_form_select_clear_selection_returns_early_when_already_cleared() -> None:
    select = TicketFormSelect(
        [("Unassigned", UNASSIGNED_USER_VALUE), ("Operator One", "operator_1")],
        value=UNASSIGNED_USER_VALUE,
        id="ticket-user-input",
        classes="ticket-detail-form-control",
        clear_value=UNASSIGNED_USER_VALUE,
    )

    select.clear_selection()

    assert select.value == UNASSIGNED_USER_VALUE


def test_ticket_form_status_select_clear_selection_uses_configured_clear_value() -> None:
    select = TicketFormSelect(
        [("No status", NO_STATUS_VALUE), ("Dispatch", "status_dispatch")],
        value="status_dispatch",
        id="ticket-status-input",
        classes="ticket-detail-form-control",
        clear_value=NO_STATUS_VALUE,
    )

    select.clear_selection()

    assert select.is_clearable is True
    assert select.value == NO_STATUS_VALUE


def test_ticket_form_select_watch_expanded_ignores_missing_overlay(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    select = TicketFormSelect(
        [("Delivery", "delivery")],
        value="delivery",
        id="ticket-category-input",
        classes="ticket-detail-form-control",
    )

    def raise_no_matches(selector: object, *args: object) -> object:
        raise NoMatches(str(selector))

    monkeypatch.setattr(select, "query_one", raise_no_matches)

    select._watch_expanded(True)


def test_ticket_form_select_watch_value_handles_null_selection(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    select = TicketFormSelect(
        [("Delivery", "delivery")],
        value="delivery",
        id="ticket-category-input",
        classes="ticket-detail-form-control",
    )
    overlay_indices: list[int | None] = []
    updates: list[object] = []
    messages: list[object] = []
    overlay = SimpleNamespace(select_source_index=overlay_indices.append)
    select_current = SimpleNamespace(update=updates.append)

    def fake_query_one(selector: object, *args: object) -> object:
        if getattr(selector, "__name__", "") == "SelectCurrent":
            return select_current
        return overlay

    monkeypatch.setattr(select, "query_one", fake_query_one)
    select.post_message = messages.append  # type: ignore[method-assign]

    select._watch_value(Select.NULL)

    assert overlay_indices == [None]
    assert updates == [Select.NULL]
    assert len(messages) == 1


def test_ticket_form_select_action_show_overlay_bootstraps_first_option(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    select = TicketFormSelect(
        [("Delivery", "delivery")],
        value="delivery",
        id="ticket-category-input",
        classes="ticket-detail-form-control",
    )
    calls: list[str] = []
    overlay = SimpleNamespace(highlighted=None, action_first=lambda: calls.append("first"))
    select_current = SimpleNamespace(has_value=False)

    def fake_query_one(selector: object, *args: object) -> object:
        if getattr(selector, "__name__", "") == "SelectCurrent":
            return select_current
        return overlay

    monkeypatch.setattr(TicketFormSelect, "_watch_expanded", lambda self, expanded: None)
    monkeypatch.setattr(select, "query_one", fake_query_one)

    select.action_show_overlay()

    assert select_current.has_value is True
    assert calls == ["first"]


def test_ticket_form_select_current_source_index_returns_none_for_null_and_unknown_values(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    select = TicketFormSelect(
        [("Delivery", "delivery")],
        value="delivery",
        id="ticket-category-input",
        classes="ticket-detail-form-control",
    )

    monkeypatch.setattr(TicketFormSelect, "value", property(lambda self: Select.NULL))
    assert select._current_source_index() is None

    monkeypatch.setattr(TicketFormSelect, "value", property(lambda self: "missing"))
    assert select._current_source_index() is None


def test_ticket_form_select_overlay_maps_filtered_selection_to_original_index() -> None:
    overlay = TicketFormSelectOverlay(type_to_search=False)
    overlay.set_source_options(
        [Option("Billing"), Option("Delivery"), Option("Returns")]
    )
    overlay.start_search()
    overlay._set_search_query("del")
    messages: list[TicketFormSelectOverlay.UpdateSelection] = []
    overlay.post_message = messages.append  # type: ignore[method-assign]
    overlay.action_select()

    assert len(messages) == 1
    assert messages[0].option_index == 1


def test_ticket_form_select_overlay_select_source_index_handles_none_and_missing() -> None:
    overlay = TicketFormSelectOverlay(type_to_search=False)
    overlay.set_source_options([Option("Billing"), Option("Delivery")])

    overlay.select_source_index(None)
    assert overlay.highlighted is None

    overlay.select_source_index(99)
    assert overlay.highlighted is None


def test_ticket_form_select_overlay_exact_matches_rank_before_fuzzy_matches() -> None:
    overlay = TicketFormSelectOverlay(type_to_search=False)
    overlay.set_source_options(
        [
            Option("Returns"),
            Option("Returns backlog"),
            Option("Retuurns"),
        ]
    )

    overlay.start_search()
    overlay._set_search_query("returns")

    assert overlay_labels(overlay) == ["Returns", "Returns backlog", "Retuurns"]


def test_ticket_form_select_overlay_no_matches_row_is_disabled() -> None:
    overlay = TicketFormSelectOverlay(type_to_search=False)
    overlay.set_source_options([Option("Billing"), Option("Delivery")])

    overlay.start_search()
    overlay._set_search_query("zzz")

    assert overlay_labels(overlay) == [overlay.NO_MATCHES_LABEL]
    assert overlay.highlighted is None
    assert overlay.get_option_at_index(0).disabled is True


def test_ticket_form_select_overlay_action_select_returns_early_without_highlight() -> None:
    overlay = TicketFormSelectOverlay(type_to_search=False)
    overlay.set_source_options([Option("Billing")])
    overlay.highlighted = None
    messages: list[TicketFormSelectOverlay.UpdateSelection] = []
    overlay.post_message = messages.append  # type: ignore[method-assign]

    overlay.action_select()

    assert messages == []


def test_ticket_form_select_overlay_action_select_returns_early_for_disabled_option() -> None:
    overlay = TicketFormSelectOverlay(type_to_search=False)
    overlay.set_source_options([Option("No matches", disabled=True)])
    overlay.highlighted = 0
    messages: list[TicketFormSelectOverlay.UpdateSelection] = []
    overlay.post_message = messages.append  # type: ignore[method-assign]

    overlay.action_select()

    assert messages == []


@pytest.mark.asyncio
async def test_ticket_form_select_overlay_hjkl_are_search_input_when_search_is_active() -> None:
    overlay = TicketFormSelectOverlay(type_to_search=False)
    overlay.set_source_options([Option("Jack"), Option("Kilo"), Option("Zulu")])

    event = cast(
        events.Key,
        SimpleNamespace(
            key="j",
            character="j",
            is_printable=True,
            stop=lambda: None,
            prevent_default=lambda: None,
        ),
    )

    overlay.start_search()
    await overlay._on_key(event)

    assert overlay.search_query == "j"
    assert overlay_labels(overlay) == ["Jack"]


@pytest.mark.asyncio
async def test_ticket_form_select_overlay_backspace_updates_search_query() -> None:
    overlay = TicketFormSelectOverlay(type_to_search=False)
    overlay.set_source_options([Option("Jack"), Option("Kilo")])
    stopped: list[str] = []
    prevented: list[str] = []
    event = cast(
        events.Key,
        SimpleNamespace(
            key="backspace",
            character=None,
            is_printable=False,
            stop=lambda: stopped.append("stop"),
            prevent_default=lambda: prevented.append("prevent"),
        ),
    )

    overlay.start_search()
    overlay._set_search_query("ja")
    await overlay._on_key(event)

    assert overlay.search_query == "j"
    assert stopped == ["stop"]
    assert prevented == ["prevent"]


@pytest.mark.asyncio
async def test_ticket_form_select_overlay_reserved_custom_vi_key_returns_early(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    overlay = TicketFormSelectOverlay(type_to_search=True)
    overlay._VI_KEYS = {"x"}
    delegated: list[str | None] = []

    async def fake_super_on_key(self: SelectOverlay, event: events.Key) -> None:
        delegated.append(event.character)

    monkeypatch.setattr(SelectOverlay, "_on_key", fake_super_on_key)
    event = cast(
        events.Key,
        SimpleNamespace(
            character="x",
            stop=lambda: None,
            prevent_default=lambda: None,
        ),
    )

    await overlay._on_key(event)

    assert delegated == []


def test_ticket_form_select_overlay_check_consume_key_reserves_insert_mode() -> None:
    overlay = TicketFormSelectOverlay(type_to_search=True)

    assert overlay.check_consume_key("i", "i") is True


def test_ticket_form_select_overlay_apply_search_resets_when_query_is_empty(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    overlay = TicketFormSelectOverlay(type_to_search=False)
    preferred_indices: list[int | None] = []

    monkeypatch.setattr(
        overlay,
        "_render_source_options",
        lambda preferred_source_index=None: preferred_indices.append(preferred_source_index),
    )
    overlay.highlighted = 10
    overlay._filtered_source_indices = [0]
    overlay.search_query = ""

    overlay._apply_search()

    assert preferred_indices == [None]


def test_ticket_form_select_overlay_prefers_next_enabled_index_when_preferred_is_missing() -> None:
    overlay = TicketFormSelectOverlay(type_to_search=False)
    overlay.set_source_options([Option("Blocked", disabled=True), Option("Ready")])

    assert overlay._preferred_visible_index(99) == 1


def test_ticket_form_select_overlay_next_enabled_index_returns_none_when_all_options_disabled() -> None:
    overlay = TicketFormSelectOverlay(type_to_search=False)
    overlay.set_source_options([Option("Blocked", disabled=True)])

    assert overlay._next_enabled_index() is None


def test_ticket_form_select_overlay_highlighted_source_index_returns_none_out_of_range(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    overlay = TicketFormSelectOverlay(type_to_search=False)
    overlay.set_source_options([Option("Billing")])

    monkeypatch.setattr(TicketFormSelectOverlay, "highlighted", property(lambda self: 2))

    assert overlay._highlighted_source_index() is None


def test_ticket_form_select_overlay_match_rank_handles_empty_and_similarity_queries() -> None:
    overlay = TicketFormSelectOverlay(type_to_search=False)
    overlay.set_source_options([Option("Broken")])
    option = overlay._source_options[0]

    assert overlay._match_rank("   ", option) == (0, 0.0, 0, len("Broken"), 0)
    assert overlay._match_rank("brokne", option) == (4, pytest.approx(-0.8333333333333334), 0, 6, 0)


def test_ticket_form_select_overlay_prompt_label_uses_rich_text_plain_value() -> None:
    assert TicketFormSelectOverlay._prompt_label(Text("Delivery")) == "Delivery"


def test_ticket_detail_form_cursor_up_moves_only_when_not_editing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    form = TicketDetailForm(make_ticket())
    moves: list[int] = []

    monkeypatch.setattr(form, "_move_active_field", moves.append)

    form.action_cursor_up()
    form.editing = True
    form.action_cursor_up()

    assert moves == [-1]


def test_ticket_detail_form_action_clear_active_field_ignores_non_select_control(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    form = TicketDetailForm(make_ticket())

    def fail_if_called(control: TicketFormSelect) -> None:
        raise AssertionError("_clear_select should not be called for non-select controls")

    monkeypatch.setattr(form, "_active_control", lambda: object())
    monkeypatch.setattr(form, "_clear_select", fail_if_called)

    form.action_clear_active_field()


def test_ticket_detail_form_edit_active_field_returns_early_while_editing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    form = TicketDetailForm(make_ticket())
    form.editing = True

    def fail_if_called() -> object:
        raise AssertionError("_active_control should not be used while already editing")

    monkeypatch.setattr(form, "_active_control", fail_if_called)

    form.action_edit_active_field()


def test_ticket_detail_form_on_edit_stopped_ignores_unknown_control(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    form = TicketDetailForm(make_ticket())
    known_control = object()
    stop_calls: list[str] = []

    monkeypatch.setattr(form, "_controls", lambda: [known_control])
    message = cast(
        EditStopped,
        SimpleNamespace(
            control=object(),
            stop=lambda: stop_calls.append("stop"),
        ),
    )

    form.on_edit_stopped(message)

    assert stop_calls == []


def test_ticket_detail_form_on_input_submitted_ignores_non_title_input(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    form = TicketDetailForm(make_ticket())
    title_input = object()
    other_input = object()

    monkeypatch.setattr(form, "query_one", lambda selector, *args: title_input)

    form.on_input_submitted(cast(Input.Submitted, SimpleNamespace(input=other_input)))


def test_ticket_detail_form_selected_category_name_uses_fallback_for_blank_select(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(
        category="Delivery",
        category_name="categories_delivery",
    )
    form = TicketDetailForm(ticket)

    monkeypatch.setattr(
        form,
        "query_one",
        lambda selector, *args: SimpleNamespace(value=Select.NULL),
    )

    assert form._selected_category_name() == "categories_delivery"


def test_ticket_detail_form_selected_user_name_uses_fallback_for_blank_select(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    form = TicketDetailForm(make_ticket(user="operator_1"))

    monkeypatch.setattr(
        form,
        "query_one",
        lambda selector, *args: SimpleNamespace(value=Select.NULL),
    )

    assert form._selected_user_name() == "operator_1"


def test_ticket_detail_form_selected_user_value_fallback_prefers_ticket_user_label() -> None:
    ticket = make_ticket(user="Operator One")
    ticket = ticket.model_copy(update={"user_name": None})
    form = TicketDetailForm(ticket)

    assert form._selected_user_value_fallback() == "Operator One"


def test_ticket_detail_form_selected_status_name_uses_fallback_for_blank_select(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    form = TicketDetailForm(make_ticket(statuses={"status_dispatch": "Dispatch"}))

    monkeypatch.setattr(
        form,
        "query_one",
        lambda selector, *args: SimpleNamespace(value=Select.NULL),
    )

    assert form._selected_status_name() == "status_dispatch"


def test_ticket_detail_form_status_options_requested_control_references_form() -> None:
    form = TicketDetailForm(make_ticket())
    message = TicketDetailForm.StatusOptionsRequested(form, "delivery")

    assert message.control is form


def test_ticket_detail_form_selected_stage_uses_fallback_for_blank_select(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    form = TicketDetailForm(make_ticket(stage=TicketStage.WAIT))

    monkeypatch.setattr(
        form,
        "query_one",
        lambda selector, *args: SimpleNamespace(value=Select.NULL),
    )

    assert form._selected_stage() is TicketStage.WAIT


def test_ticket_detail_form_selected_priority_uses_fallback_for_blank_select(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    form = TicketDetailForm(make_ticket(priority=TicketPriority.MEDIUM))

    monkeypatch.setattr(
        form,
        "query_one",
        lambda selector, *args: SimpleNamespace(value=Select.NULL),
    )

    assert form._selected_priority() is TicketPriority.MEDIUM


def test_ticket_detail_form_category_title_falls_back_to_raw_name() -> None:
    form = TicketDetailForm(make_ticket(category="Delivery", category_name="categories_delivery"))

    assert form._category_title_for_name("categories_unknown") == "categories_unknown"


def test_ticket_detail_form_user_title_falls_back_to_ticket_label() -> None:
    form = TicketDetailForm(make_ticket(user="Operator One", user_name="operator_1"))

    assert form._user_title_for_name("operator_1") == "Operator One"


def test_ticket_detail_form_user_title_falls_back_to_raw_name() -> None:
    form = TicketDetailForm(make_ticket())

    assert form._user_title_for_name("operator_unknown") == "operator_unknown"


def test_ticket_detail_form_resolve_assignable_user_prefers_exact_user_name() -> None:
    form = TicketDetailForm(
        make_ticket(),
        user_options=[
            TicketUserOption(name="operator_1", title="Operator One"),
            TicketUserOption(name="operator_2", title="Operator Two"),
        ],
    )

    assert form.resolve_assignable_user(
        user_name="operator_2",
        user_title="Operator One",
    ) == TicketUserOption(name="operator_2", title="Operator Two")


def test_ticket_detail_form_resolve_assignable_user_requires_unique_title_match() -> None:
    form = TicketDetailForm(
        make_ticket(),
        user_options=[
            TicketUserOption(name="operator_1", title="Operator One"),
            TicketUserOption(name="operator_2", title="Operator One"),
        ],
    )

    assert form.resolve_assignable_user(
        user_name=None,
        user_title="Operator One",
    ) is None


def test_ticket_detail_form_resolve_assignable_user_returns_none_without_actor_title() -> None:
    form = TicketDetailForm(
        make_ticket(),
        user_options=[TicketUserOption(name="operator_1", title="Operator One")],
    )

    assert form.resolve_assignable_user(
        user_name=None,
        user_title=None,
    ) is None


def test_ticket_detail_form_resolve_assignable_user_uses_unique_title_match() -> None:
    form = TicketDetailForm(
        make_ticket(),
        user_options=[
            TicketUserOption(name="operator_1", title="Operator One"),
            TicketUserOption(name="operator_2", title="Operator Two"),
        ],
    )

    assert form.resolve_assignable_user(
        user_name=None,
        user_title="Operator Two",
    ) == TicketUserOption(name="operator_2", title="Operator Two")


def test_ticket_detail_form_status_title_falls_back_to_ticket_label() -> None:
    form = TicketDetailForm(make_ticket(statuses={"status_dispatch": "Dispatch"}))

    assert form._status_title_for_name("status_dispatch") == "Dispatch"


def test_ticket_detail_form_status_title_falls_back_to_raw_name() -> None:
    form = TicketDetailForm(make_ticket())

    assert form._status_title_for_name("status_unknown") == "status_unknown"


def test_ticket_detail_form_set_ticket_statuses_returns_early_for_non_selected_category(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    form = TicketDetailForm(make_ticket(category="Delivery", category_name="categories_delivery"))
    refresh_calls: list[str] = []

    monkeypatch.setattr(form, "_selected_category_name", lambda: "categories_returns")
    monkeypatch.setattr(form, "_refresh_status_select", lambda value: refresh_calls.append(value))

    form.set_ticket_statuses(
        "categories_delivery",
        [TicketStatusOption(name="status_dispatch", title="Dispatch")],
    )

    assert refresh_calls == []
    assert form._status_options_category_name == "categories_delivery"
