import io
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
from typing import cast

import pytest
from PIL import Image
from rich.text import Text
from textual import events
from textual.containers import Horizontal, Vertical
from textual.css.query import NoMatches
from textual.widgets import Button, Input, Markdown, Select, Static, TextArea

import daktela_paleo.screens.ticket_detail.widgets.comment_reply as comment_reply_module
import daktela_paleo.screens.ticket_detail.widgets.detail_pane as detail_pane_module
import daktela_paleo.screens.ticket_detail.widgets.email_compose as email_compose_module
from daktela_paleo.models import (
    ActivityBodyFragment,
    TicketActivity,
    TicketEditPatch,
    TicketEmailAction,
    TicketEmailDraft,
    TicketEmailSendRequest,
    TicketStage,
    TicketUserOption,
)
from daktela_paleo.screens.ticket_detail.widgets.comment_reply import (
    CommentReplyComposer,
    ExternalEditorError,
)
from daktela_paleo.screens.ticket_detail.widgets.detail_pane import (
    ActivityImageWidget,
    ActivityLink,
    DetailPaneBody,
)
from daktela_paleo.screens.ticket_detail.widgets.email_compose import TicketEmailComposer
from daktela_paleo.screens.ticket_detail.widgets.form import (
    NO_STATUS_VALUE,
    TicketDetailForm,
    TicketFormSelect,
    UNASSIGNED_USER_VALUE,
)
from daktela_paleo.screens.ticket_detail.widgets.modals import (
    ActivityLinkPickerModal,
    CommentAttachmentPathPickerModal,
    CommentAttachmentRemovalModal,
)
from daktela_paleo.screens.ticket_detail.screen import (
    ACTIVITY_COPY_EMPTY_STATUS,
    ACTIVITY_COPY_SUCCESS_STATUS,
    ACTIVITY_DOWNLOAD_EMPTY_STATUS,
    ActivitySearchInput,
    COMMENT_QUICK_ACTIONS,
    COPY_QUICK_ACTION,
    DOWNLOAD_QUICK_ACTION,
    REPLY_USER_UNMATCHED_STATUS,
    TicketDetail,
)
from daktela_paleo.widgets.vertical_splitter import VerticalSplitter
from tests.support import (
    TicketDetailHarness,
    make_activity,
    make_ticket,
    make_ticket_custom_fields,
)


def activity_title_widgets(right_body: DetailPaneBody) -> list[Static]:
    return [widget for widget in right_body.query(".detail-pane-entry-title") if isinstance(widget, Static)]


def activity_headline_widgets(right_body: DetailPaneBody) -> list[Static]:
    return [
        widget
        for widget in right_body.query(".detail-pane-entry-headline")
        if isinstance(widget, Static)
    ]


def activity_markdown_widgets(right_body: DetailPaneBody) -> list[Markdown]:
    return [widget for widget in right_body.query(".detail-pane-entry-markdown") if isinstance(widget, Markdown)]


def activity_image_widgets(right_body: DetailPaneBody) -> list[ActivityImageWidget]:
    return [
        widget
        for widget in right_body.query(".detail-pane-entry-image")
        if isinstance(widget, ActivityImageWidget)
    ]


def make_png_bytes(width: int = 4, height: int = 2) -> bytes:
    image = Image.new("RGBA", (width, height), (255, 0, 0, 255))
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    return buffer.getvalue()


def test_sanitize_activity_link_label_removes_access_token() -> None:
    assert detail_pane_module._sanitize_activity_link_label(
        "https://example.test/file/image.php?name=5&accessToken=secret"
    ) == "https://example.test/file/image.php?name=5"


def test_placeholder_grid_returns_empty_for_non_positive_dimensions() -> None:
    assert detail_pane_module._placeholder_grid(7, 0, 1) == ()
    assert detail_pane_module._placeholder_grid(7, 1, 0) == ()


def test_activity_image_widget_on_mount_uses_cached_asset(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    async def load_image(_url: str) -> bytes:
        return b"unused"

    cached_asset = detail_pane_module._CachedActivityAsset(
        path=tmp_path / "cached.png",
        width_px=16,
        height_px=16,
    )
    cached_asset.path.write_bytes(make_png_bytes())
    widget = ActivityImageWidget(
        resolved_url="https://example.test/image.png",
        label="Image: Scan",
        image_id=7,
        asset_cache={"https://example.test/image.png": cached_asset},
        temp_dir=tmp_path,
        load_activity_asset=load_image,
        supports_inline_images=True,
    )
    callbacks: list[object] = []

    monkeypatch.setattr(widget, "call_after_refresh", callbacks.append)

    widget.on_mount()

    assert widget._cached_asset == cached_asset
    assert widget._status == "loaded"
    assert len(callbacks) == 1
    assert getattr(callbacks[0], "__name__", None) == "_sync_inline_geometry"


def test_activity_image_widget_render_returns_label_when_loaded(tmp_path: Path) -> None:
    widget = ActivityImageWidget(
        resolved_url="https://example.test/image.png",
        label="Image: Scan",
        image_id=7,
        asset_cache={},
        temp_dir=tmp_path,
        load_activity_asset=None,
        supports_inline_images=True,
    )
    widget._status = "loaded"

    assert widget.render() == "Image: Scan"


def test_activity_image_widget_render_returns_label_when_not_loaded(tmp_path: Path) -> None:
    widget = ActivityImageWidget(
        resolved_url=None,
        label="Image: Scan",
        image_id=7,
        asset_cache={},
        temp_dir=tmp_path,
        load_activity_asset=None,
        supports_inline_images=False,
    )

    assert widget.render() == "Image: Scan"


@pytest.mark.asyncio
async def test_activity_image_widget_load_asset_schedules_fallback_on_error(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    async def fail_load(_url: str) -> bytes:
        raise RuntimeError("boom")

    widget = ActivityImageWidget(
        resolved_url="https://example.test/image.png",
        label="Image: Scan",
        image_id=7,
        asset_cache={},
        temp_dir=tmp_path,
        load_activity_asset=fail_load,
        supports_inline_images=True,
    )
    callbacks: list[object] = []

    monkeypatch.setattr(widget, "call_after_refresh", callbacks.append)

    await widget._load_asset()

    assert len(callbacks) == 1
    assert getattr(callbacks[0], "__name__", None) == "_set_fallback"


def test_activity_image_widget_sync_inline_geometry_falls_back_without_cached_asset(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    widget = ActivityImageWidget(
        resolved_url="https://example.test/image.png",
        label="Image: Scan",
        image_id=7,
        asset_cache={},
        temp_dir=tmp_path,
        load_activity_asset=None,
        supports_inline_images=True,
    )
    calls: list[str] = []

    monkeypatch.setattr(widget, "_set_fallback", lambda: calls.append("fallback"))

    widget._sync_inline_geometry()

    assert calls == ["fallback"]


def test_activity_image_widget_render_line_returns_blank_for_non_first_fallback_line(
    tmp_path: Path,
) -> None:
    widget = ActivityImageWidget(
        resolved_url=None,
        label="Image: Scan",
        image_id=7,
        asset_cache={},
        temp_dir=tmp_path,
        load_activity_asset=None,
        supports_inline_images=False,
    )

    line = widget.render_line(1)

    assert all(segment.text.strip() == "" for segment in line)


def test_activity_image_widget_render_line_returns_blank_for_loaded_line_out_of_range(
    tmp_path: Path,
) -> None:
    widget = ActivityImageWidget(
        resolved_url="https://example.test/image.png",
        label="Image: Scan",
        image_id=7,
        asset_cache={},
        temp_dir=tmp_path,
        load_activity_asset=None,
        supports_inline_images=True,
    )
    widget._status = "loaded"
    widget._placeholder_lines = ("x", "y")

    line = widget.render_line(3)

    assert all(segment.text.strip() == "" for segment in line)


def test_detail_pane_discover_links_skips_unresolved_and_dedupes_resolved_image_urls() -> None:
    activities = [
        make_activity(
            title="Internal note",
            type="",
            item_model=None,
            body_html=(
                '<img src="/file/image.php?name=skip" alt="Skip" />'
                '<img src="/file/image.php?name=one" alt="Scan one" />'
                '<img src="/file/image.php?name=two" alt="Scan two" />'
            ),
        )
    ]

    assert DetailPaneBody.discover_links(
        activities,
        resolve_activity_asset_url=lambda url: (
            None
            if url.endswith("skip")
            else "https://example.test/file/image.php?name=shared&accessToken=secret"
        ),
    ) == [
        ActivityLink(
            url="https://example.test/file/image.php?name=shared&accessToken=secret",
            label="Image: Scan one",
        )
    ]


def test_detail_pane_activity_body_lines_uses_body_text_when_headline_is_suppressed_without_fragments(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    activity = make_activity(
        title="Hello",
        body_html="<p>Hello</p>",
        item_model=None,
    )

    monkeypatch.setattr(TicketActivity, "body_fragments", lambda self: None)

    assert DetailPaneBody._activity_body_lines(activity) == ["Hello"]


def test_detail_pane_image_fragment_label_uses_sanitized_url_without_alt() -> None:
    fragment = ActivityBodyFragment.from_image("/file/image.php?name=5")

    assert DetailPaneBody._image_fragment_label(
        fragment,
        "https://example.test/file/image.php?name=5&accessToken=secret",
    ) == "Image attachment: https://example.test/file/image.php?name=5"


def test_detail_pane_image_fragment_label_without_alt_or_url_uses_generic_label() -> None:
    fragment = ActivityBodyFragment.from_image("/file/image.php?name=5")

    assert DetailPaneBody._image_fragment_label(fragment, None) == "Image attachment"


def quick_action_buttons(screen: TicketDetail) -> list[Static]:
    return [
        widget
        for widget in screen.query(".detail-pane-quick-action")
        if isinstance(widget, Static)
    ]


def quick_action_labels(screen: TicketDetail) -> list[str]:
    return [str(widget.render()) for widget in quick_action_buttons(screen)]


def title_quick_action_labels(screen: TicketDetail) -> list[str]:
    right_title = screen.query_one("#ticket-detail-right-title")
    return [
        str(widget.render())
        for widget in right_title.query(".detail-pane-quick-action")
        if isinstance(widget, Static)
    ]


def right_title_label(screen: TicketDetail) -> Static:
    return screen.query_one("#ticket-detail-right-title-label", Static)


def static_text(widget: Static) -> str:
    rendered = widget.render()
    return rendered.plain if isinstance(rendered, Text) else str(rendered)


def custom_field_rows(screen: TicketDetail) -> list[tuple[str, str]]:
    rows = []
    for row in screen.query(".ticket-custom-field-row"):
        label = row.query_one(".ticket-custom-field-label", Static)
        value = row.query_one(".ticket-custom-field-value", Static)
        rows.append((static_text(label), static_text(value)))
    return rows


def comment_reply_composer(screen: TicketDetail) -> CommentReplyComposer:
    return screen.query_one("#comment-reply-composer", CommentReplyComposer)


def email_reply_composer(screen: TicketDetail) -> TicketEmailComposer:
    return screen.query_one("#email-reply-composer", TicketEmailComposer)


def activity_search_input(screen: TicketDetail) -> ActivitySearchInput:
    return screen.query_one("#ticket-detail-activity-search-input", ActivitySearchInput)


def make_discovered_link(url: str = "https://example.test/alpha") -> ActivityLink:
    return ActivityLink(url=url)


def test_activity_search_input_messages_expose_control() -> None:
    search_input = ActivitySearchInput()

    assert search_input.SearchCancelled(search_input).control is search_input


def test_activity_search_input_cancel_posts_search_cancelled_message() -> None:
    search_input = ActivitySearchInput()
    posted_messages: list[ActivitySearchInput.SearchCancelled] = []
    search_input.post_message = posted_messages.append  # type: ignore[method-assign]

    search_input.action_cancel_search()

    assert len(posted_messages) == 1
    assert posted_messages[0].control is search_input


def test_ticket_detail_apply_pane_layout_defaults_to_thirty_percent(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    panes = SimpleNamespace(size=SimpleNamespace(width=100))
    left_pane = SimpleNamespace(styles=SimpleNamespace(width=None))
    right_pane = SimpleNamespace(styles=SimpleNamespace(width=None))

    def fake_query_one(selector: object, *args: object) -> object:
        if selector == "#ticket-detail-panes":
            return panes
        if selector == "#ticket-detail-left-pane":
            return left_pane
        if selector == "#ticket-detail-right-pane":
            return right_pane
        raise AssertionError(f"unexpected selector: {selector!r}")

    monkeypatch.setattr(screen, "query_one", fake_query_one)

    screen._apply_pane_layout()

    assert left_pane.styles.width == 30
    assert right_pane.styles.width == 69


def test_ticket_detail_apply_pane_layout_respects_minimum_widths(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    panes = SimpleNamespace(size=SimpleNamespace(width=50))
    left_pane = SimpleNamespace(styles=SimpleNamespace(width=None))
    right_pane = SimpleNamespace(styles=SimpleNamespace(width=None))

    def fake_query_one(selector: object, *args: object) -> object:
        if selector == "#ticket-detail-panes":
            return panes
        if selector == "#ticket-detail-left-pane":
            return left_pane
        if selector == "#ticket-detail-right-pane":
            return right_pane
        raise AssertionError(f"unexpected selector: {selector!r}")

    monkeypatch.setattr(screen, "query_one", fake_query_one)

    screen._apply_pane_layout()

    assert left_pane.styles.width == 18
    assert right_pane.styles.width == 31


@pytest.mark.asyncio
async def test_ticket_detail_renders_form_fields_and_empty_activities() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        description="Needs a replacement",
    )
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#ticket-name-input", Input).value == "Broken scanner"
        assert app.screen.query_one("#ticket-stage-input", Select).value == "OPEN"
        assert app.screen.query_one("#ticket-priority-input", Select).value == "HIGH"
        assert app.screen.query_one("#ticket-user-input", Select).value == UNASSIGNED_USER_VALUE
        assert app.screen.query_one("#ticket-status-input", Select).value == NO_STATUS_VALUE
        assert app.screen.query_one("#ticket-reopen-input", Input).value == ""
        assert app.screen.query_one("#ticket-description-input", TextArea).text == "Needs a replacement"
        assert right_title_label(cast(TicketDetail, app.screen)).render() == "Activities"
        assert app.screen.query_one("#ticket-detail-right-body", DetailPaneBody).render() == "no activities yet"
        assert app.screen.query_one("#status-bar", Static).render() == "Selected ticket: Broken scanner"
        assert app.screen.query_one("#instance-context", Static).render() == "Instance: disconnected"


@pytest.mark.asyncio
async def test_ticket_detail_renders_custom_fields_section_below_description() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        description="Needs a replacement",
        custom_fields=make_ticket_custom_fields(),
    )
    app = TicketDetailHarness(ticket)

    async with app.run_test(size=(120, 30)) as pilot:
        await pilot.pause()

        description_row = app.screen.query_one("#ticket-description-row")
        section = app.screen.query_one("#ticket-custom-fields-section")
        title = app.screen.query_one("#ticket-custom-fields-title", Static)

        assert title.render() == "Custom Fields"
        assert section.region.y == description_row.region.y + description_row.region.height
        assert custom_field_rows(cast(TicketDetail, app.screen)) == [
            ("Consultant:", "Alice"),
            ("Serial Number:", "SN-42, SN-43"),
            ("Replacement Required:", "Yes"),
        ]
        first_row = section.query_one("#ticket-custom-field-row-0")
        first_label = first_row.query_one(".ticket-custom-field-label", Static)
        first_value = first_row.query_one(".ticket-custom-field-value", Static)

        assert first_label.region.width == 14
        assert first_value.region.width > 1
        assert first_value.region.height == 1
        assert first_value.region.x > first_label.region.x


@pytest.mark.asyncio
async def test_ticket_detail_omits_custom_fields_section_without_displayable_fields() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        description="Needs a replacement",
        custom_fields=[],
    )
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        with pytest.raises(NoMatches):
            app.screen.query_one("#ticket-custom-fields-section")


@pytest.mark.asyncio
async def test_ticket_detail_renders_formatted_reopen_value() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        reopen=datetime(2026, 3, 31, 9, 15, 0),
    )
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        assert app.screen.query_one("#ticket-reopen-input", Input).value == "2026-03-31 09:15:00"


@pytest.mark.asyncio
async def test_ticket_detail_renders_provided_instance_context() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket, instance_context="Instance: https://demo.daktela.com")

    async with app.run_test() as pilot:
        await pilot.pause()

        assert isinstance(app.screen, TicketDetail)
        assert app.screen.query_one("#instance-context", Static).render() == (
            "Instance: https://demo.daktela.com"
        )


@pytest.mark.asyncio
async def test_ticket_detail_comment_reply_opens_inline_composer_and_focuses_editor() -> None:
    app = TicketDetailHarness(make_ticket(title="Broken scanner", name=2001))

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="Internal note",
                    type="",
                    body_html="<p>Plain text</p>",
                    item_model=None,
                )
            ]
        )
        await pilot.pause()

        await pilot.press("tab", "r")
        await pilot.pause()

        composer = comment_reply_composer(detail_screen)
        editor = composer.query_one("#comment-reply-input", TextArea)
        submit_button = composer.query_one("#comment-reply-submit", Button)
        cancel_button = composer.query_one("#comment-reply-cancel", Button)

        assert composer.is_open is True
        assert app.focused is editor
        assert composer.query_one("#comment-reply-title", Static).render() == "Add comment reply"
        assert composer.styles.padding.top == 0
        assert composer.styles.padding.bottom == 0
        assert editor.styles.margin.top == 0
        assert editor.styles.margin.bottom == 0
        assert editor.styles.padding.left == 0
        assert editor.styles.padding.right == 0
        assert editor.styles.height is not None
        assert editor.styles.height.cells == 10
        assert submit_button.styles.min_width is not None
        assert submit_button.styles.min_width.cells == 0
        assert cancel_button.styles.min_width is not None
        assert cancel_button.styles.min_width.cells == 0
        with pytest.raises(NoMatches):
            composer.query_one("#comment-reply-target", Static)
        with pytest.raises(NoMatches):
            composer.query_one("#comment-reply-target-preview", Static)
        assert activity_title_widgets(detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody))[
            0
        ].has_class("-active")


@pytest.mark.asyncio
async def test_ticket_detail_new_comment_ctrl_e_round_trips_draft_and_keeps_inline_composer(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = TicketDetailHarness(make_ticket(title="Broken scanner", name=2001))

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)

        await pilot.press("n")
        await pilot.pause()

        composer = comment_reply_composer(detail_screen)
        editor = composer.query_one("#comment-reply-input", TextArea)
        editor.load_text("Draft comment")
        monkeypatch.setattr(
            comment_reply_module,
            "_edit_draft_in_external_editor",
            lambda _app, draft: f"{draft}\nEdited externally",
        )

        await pilot.press("ctrl+e")
        await pilot.pause()

        assert composer.is_open is True
        assert composer.mode == "new_comment"
        assert editor.text == "Draft comment\nEdited externally"
        assert app.focused is editor
        assert composer.query_one("#comment-reply-validation", Static).display is False


@pytest.mark.asyncio
async def test_ticket_detail_comment_reply_ctrl_e_failure_preserves_draft_and_mode(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = TicketDetailHarness(make_ticket(title="Broken scanner", name=2001))

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="Internal note",
                    type="",
                    body_html="<p>Plain text</p>",
                    item_model=None,
                )
            ]
        )
        await pilot.pause()

        await pilot.press("tab", "r")
        await pilot.pause()

        composer = comment_reply_composer(detail_screen)
        editor = composer.query_one("#comment-reply-input", TextArea)
        editor.load_text("Draft reply")
        monkeypatch.setattr(
            comment_reply_module,
            "_edit_draft_in_external_editor",
            lambda _app, _draft: (_ for _ in ()).throw(
                ExternalEditorError("External editor is unavailable.")
            ),
        )

        await pilot.press("ctrl+e")
        await pilot.pause()

        assert composer.is_open is True
        assert composer.mode == "reply"
        assert editor.text == "Draft reply"
        assert app.focused is editor
        assert composer.query_one("#comment-reply-validation", Static).display is True
        assert composer.query_one("#comment-reply-validation", Static).render() == (
            "External editor is unavailable."
        )


@pytest.mark.asyncio
async def test_ticket_detail_email_forward_ctrl_e_round_trips_body_and_keeps_inline_composer(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = TicketDetailHarness(make_ticket(title="Broken scanner", name=2001))

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        activity = make_activity(title="Customer replied", direction="in")
        detail_screen.set_ticket_activities([activity])
        await pilot.pause()

        detail_screen._request_email_draft(TicketEmailAction.FORWARD)
        detail_screen.handle_email_draft_loaded(
            TicketEmailDraft(
                action=TicketEmailAction.FORWARD,
                source_activity_name=activity.name,
                source_email_name="emails_1",
                to="new@example.com",
                subject="Fwd: Broken scanner",
                body="Forward draft",
                queue_name="support",
            )
        )
        await pilot.pause()

        composer = email_reply_composer(detail_screen)
        to_input = composer.query_one("#email-reply-to", Input)
        subject_input = composer.query_one("#email-reply-subject", Input)
        body_input = composer.query_one("#email-reply-body", TextArea)
        monkeypatch.setattr(
            email_compose_module,
            "_edit_draft_in_external_editor",
            lambda _app, draft: f"{draft}\nEdited externally",
        )

        assert app.focused is to_input

        await pilot.press("ctrl+e")
        await pilot.pause()

        assert composer.is_open is True
        assert composer.action is TicketEmailAction.FORWARD
        assert to_input.value == "new@example.com"
        assert subject_input.value == "Fwd: Broken scanner"
        assert body_input.text == "Forward draft\nEdited externally"
        assert app.focused is body_input
        assert composer.query_one("#email-reply-validation", Static).display is False
        assert activity_title_widgets(detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody))[
            0
        ].has_class("-active")


@pytest.mark.asyncio
async def test_ticket_detail_email_reply_ctrl_e_failure_preserves_body_and_mode(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = TicketDetailHarness(make_ticket(title="Broken scanner", name=2001))

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        activity = make_activity(title="Customer replied", direction="in")
        detail_screen.set_ticket_activities([activity])
        await pilot.pause()

        detail_screen._request_email_draft(TicketEmailAction.REPLY)
        detail_screen.handle_email_draft_loaded(
            TicketEmailDraft(
                action=TicketEmailAction.REPLY,
                source_activity_name=activity.name,
                source_email_name="emails_1",
                to="customer@example.com",
                subject="Re: Broken scanner",
                body="Draft reply",
                queue_name="support",
            )
        )
        await pilot.pause()

        composer = email_reply_composer(detail_screen)
        body_input = composer.query_one("#email-reply-body", TextArea)
        monkeypatch.setattr(
            email_compose_module,
            "_edit_draft_in_external_editor",
            lambda _app, _draft: (_ for _ in ()).throw(
                ExternalEditorError("External editor is unavailable.")
            ),
        )

        assert app.focused is body_input

        await pilot.press("ctrl+e")
        await pilot.pause()

        assert composer.is_open is True
        assert composer.action is TicketEmailAction.REPLY
        assert body_input.text == "Draft reply"
        assert app.focused is body_input
        assert composer.query_one("#email-reply-validation", Static).display is True
        assert composer.query_one("#email-reply-validation", Static).render() == (
            "External editor is unavailable."
        )
        assert activity_title_widgets(detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody))[
            0
        ].has_class("-active")


@pytest.mark.asyncio
async def test_ticket_detail_comment_reply_assigns_matching_activity_user() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001, user=None, user_name=None)
    app = TicketDetailHarness(
        ticket,
        user_options=[
            TicketUserOption(name="operator_1", title="Operator One"),
            TicketUserOption(name="operator_2", title="Operator Two"),
        ],
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="Internal note",
                    type="",
                    body_html="<p>Plain text</p>",
                    item_model=None,
                    user="Operator Two",
                    user_name="operator_2",
                )
            ]
        )
        await pilot.pause()

        form = detail_screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        user_select = detail_screen.query_one("#ticket-user-input", TicketFormSelect)

        assert user_select.value == UNASSIGNED_USER_VALUE

        await pilot.press("tab", "r")
        await pilot.pause()

        composer = comment_reply_composer(detail_screen)

        assert composer.is_open is True
        assert user_select.value == "operator_2"
        assert form.has_unsaved_changes() is True
        assert form.build_patch() == TicketEditPatch(
            user_name="operator_2",
            user_title="Operator Two",
        )
        assert detail_screen.query_one("#status-bar", Static).render() == (
            "Selected ticket: Broken scanner"
        )


@pytest.mark.asyncio
async def test_ticket_detail_comment_reply_leaves_user_unchanged_when_activity_user_is_unmatched() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        user="Operator One",
        user_name="operator_1",
    )
    app = TicketDetailHarness(
        ticket,
        user_options=[
            TicketUserOption(name="operator_1", title="Operator One"),
            TicketUserOption(name="operator_2", title="Operator Two"),
        ],
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="Internal note",
                    type="",
                    body_html="<p>Plain text</p>",
                    item_model=None,
                    user="Operator Three",
                    user_name="operator_3",
                )
            ]
        )
        await pilot.pause()

        form = detail_screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        user_select = detail_screen.query_one("#ticket-user-input", TicketFormSelect)

        await pilot.press("tab", "r")
        await pilot.pause()

        assert comment_reply_composer(detail_screen).is_open is True
        assert user_select.value == "operator_1"
        assert form.has_unsaved_changes() is False


@pytest.mark.asyncio
async def test_ticket_detail_comment_reply_blank_submit_stays_inline_and_shows_validation() -> None:
    app = TicketDetailHarness(make_ticket(title="Broken scanner", name=2001))

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="Internal note",
                    type="",
                    body_html="<p>Plain text</p>",
                    item_model=None,
                )
            ]
        )
        await pilot.pause()

        await pilot.press("tab", "r")
        await pilot.pause()

        composer = comment_reply_composer(detail_screen)
        composer.query_one("#comment-reply-input", TextArea).load_text("   ")

        await pilot.press("ctrl+s")
        await pilot.pause()

        assert composer.is_open is True
        assert composer.query_one("#comment-reply-validation", Static).display is True
        assert composer.query_one("#comment-reply-validation", Static).render() == (
            "Comment body can't be blank."
        )


@pytest.mark.asyncio
async def test_ticket_detail_comment_reply_escape_closes_only_inline_composer() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001, description="Needs a replacement")
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="Internal note",
                    type="",
                    body_html="<p>Plain text</p>",
                    item_model=None,
                )
            ]
        )
        await pilot.pause()

        await pilot.press("tab", "r")
        await pilot.pause()

        comment_reply_composer(detail_screen).query_one("#comment-reply-input", TextArea).load_text(
            "Draft comment"
        )

        await pilot.press("escape")
        await pilot.pause()

        assert comment_reply_composer(detail_screen).is_open is False
        assert app.focused is detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        assert detail_screen.query_one("#ticket-description-input", TextArea).text == (
            "Needs a replacement"
        )


@pytest.mark.asyncio
async def test_ticket_detail_c_sets_stage_close_without_leaving_ticket_detail() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        stage=TicketStage.OPEN,
    )
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)

        assert detail_screen.query_one("#ticket-stage-input", Select).value == "OPEN"

        await pilot.press("c")
        await pilot.pause()

        assert app.screen is detail_screen
        assert detail_screen.query_one("#ticket-stage-input", Select).value == "CLOSE"


@pytest.mark.asyncio
async def test_ticket_detail_n_opens_inline_top_level_comment_with_activity_context_visible() -> None:
    app = TicketDetailHarness(make_ticket(title="Broken scanner", name=2001))

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="Internal note",
                    type="",
                    body_html="<p>Plain text</p>",
                    item_model=None,
                )
            ]
        )
        await pilot.pause()

        await pilot.press("n")
        await pilot.pause()

        composer = comment_reply_composer(detail_screen)

        assert app.screen is detail_screen
        assert composer.is_open is True
        assert composer.mode == "new_comment"
        assert app.focused is composer.query_one("#comment-reply-input", TextArea)
        assert composer.query_one("#comment-reply-title", Static).render() == "Add comment"
        with pytest.raises(NoMatches):
            composer.query_one("#comment-reply-target", Static)
        with pytest.raises(NoMatches):
            composer.query_one("#comment-reply-target-preview", Static)
        assert "Internal note" in str(
            detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody).render()
        )


@pytest.mark.asyncio
async def test_ticket_detail_m_assigns_current_user_without_opening_user_select() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        user=None,
        user_name=None,
    )
    app = TicketDetailHarness(
        ticket,
        user_options=[TicketUserOption(name="operator_1", title="Operator One")],
        current_user=TicketUserOption(name="operator_2", title="Operator Two"),
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        form = app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        user_select = app.screen.query_one("#ticket-user-input", TicketFormSelect)

        assert user_select.value == UNASSIGNED_USER_VALUE

        await pilot.press("m")
        await pilot.pause()

        assert app.focused is form
        assert user_select.value == "operator_2"
        assert form.has_unsaved_changes() is True
        assert form.build_patch() == TicketEditPatch(
            user_name="operator_2",
            user_title="Operator Two",
        )


@pytest.mark.asyncio
async def test_ticket_detail_activities_pane_updates_loading_error_and_loaded_states() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_activities_loading()
        await pilot.pause()
        assert right_title_label(detail_screen).render() == "Activities"
        assert detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody).render() == (
            "loading activities..."
        )

        detail_screen.set_activities_error()
        await pilot.pause()
        assert right_title_label(detail_screen).render() == "Activities"
        assert detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody).render() == (
            "unable to load activities"
        )

        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="Fwd: test",
                    body_html="<p>Hello<br />world</p>",
                    direction="in",
                )
            ]
        )
        await pilot.pause()
        assert right_title_label(detail_screen).render() == "Activities"
        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        activity_titles = [str(widget.render()) for widget in activity_title_widgets(right_body)]
        assert activity_titles == ["Email ↓ | 2026-03-28 10:30 | Operator One"]
        assert len(activity_markdown_widgets(right_body)) == 1
        rendered = str(detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody).render())
        assert rendered == "Email ↓ | 2026-03-28 10:30 | Operator One\nFwd: test\nHello\nworld"


@pytest.mark.asyncio
async def test_ticket_detail_multiple_activities_render_as_header_body_blocks() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="Fwd: test",
                    body_html="<p>Hello<br />world</p>",
                    direction="in",
                ),
                make_activity(
                    title="Customer replied",
                    type="CALL",
                    user="Tomas Lysek",
                    time="2026-03-28 10:45:00",
                    body_html="<p>Second line</p><p>Third line</p>",
                ),
            ]
        )
        await pilot.pause()

        assert right_title_label(detail_screen).render() == "Activities"
        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        activity_titles = [str(widget.render()) for widget in activity_title_widgets(right_body)]
        assert activity_titles == [
            "Email ↓ | 2026-03-28 10:30 | Operator One",
            "Call | 2026-03-28 10:45 | Tomas Lysek",
        ]
        assert detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody).render() == (
            "Email ↓ | 2026-03-28 10:30 | Operator One\n"
            "Fwd: test\n"
            "Hello\n"
            "world\n\n"
            "Call | 2026-03-28 10:45 | Tomas Lysek\n"
            "Customer replied\n"
            "Second line\n"
            "Third line"
        )
        assert len(activity_markdown_widgets(right_body)) == 2


@pytest.mark.asyncio
async def test_ticket_detail_outgoing_email_activity_renders_up_arrow_in_header() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="Sent update",
                    body_html="<p>Reply sent</p>",
                    direction="out",
                )
            ]
        )
        await pilot.pause()

        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        activity_titles = [str(widget.render()) for widget in activity_title_widgets(right_body)]
        assert activity_titles == ["Email ↑ | 2026-03-28 10:30 | Operator One"]
        assert str(right_body.render()) == "Email ↑ | 2026-03-28 10:30 | Operator One\nSent update\nReply sent"


@pytest.mark.asyncio
async def test_ticket_detail_attachment_activity_renders_indicator_in_header() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="Internal note",
                    type="",
                    item_model=None,
                    body_html="<p>Attachment added</p>",
                    attachments=[{"file": "6", "title": "April report.txt"}],
                )
            ]
        )
        await pilot.pause()

        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        activity_titles = [str(widget.render()) for widget in activity_title_widgets(right_body)]
        assert activity_titles == ["Comment | 2026-03-28 10:30 | Operator One |  1"]
        assert str(right_body.render()) == (
            "Comment | 2026-03-28 10:30 | Operator One |  1\n"
            "Internal note\n"
            "Attachment added"
        )


@pytest.mark.asyncio
async def test_ticket_detail_plain_text_activity_body_uses_static_fallback() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="Internal note",
                    body_html=None,
                    description="Plain line one\n\nPlain line two",
                )
            ]
        )
        await pilot.pause()

        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        assert activity_markdown_widgets(right_body) == []
        plain_bodies = [
            widget
            for widget in right_body.query(".detail-pane-entry-body-plain")
            if isinstance(widget, Static)
        ]
        assert len(plain_bodies) == 1
        assert str(plain_bodies[0].render()) == "Plain line one\n\nPlain line two"


@pytest.mark.asyncio
async def test_ticket_detail_html_description_fallback_renders_as_markdown() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="Internal note",
                    body_html=None,
                    description="<p>Line one<br />Line two</p>",
                )
            ]
        )
        await pilot.pause()

        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        assert [str(widget.render()) for widget in activity_headline_widgets(right_body)] == ["Internal note"]
        assert len(activity_markdown_widgets(right_body)) == 1
        assert str(right_body.render()) == (
            "Email | 2026-03-28 10:30 | Operator One\n"
            "Internal note\n"
            "Line one\n"
            "Line two"
        )


@pytest.mark.asyncio
async def test_ticket_detail_html_item_description_fallback_renders_as_markdown() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="Call note",
                    type="CALL",
                    body_html=None,
                    description=None,
                    item_description="<p>Line one<br />Line two</p>",
                )
            ]
        )
        await pilot.pause()

        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        assert [str(widget.render()) for widget in activity_headline_widgets(right_body)] == ["Call note"]
        assert len(activity_markdown_widgets(right_body)) == 1
        assert str(right_body.render()) == (
            "Call | 2026-03-28 10:30 | Operator One\n"
            "Call note\n"
            "Line one\n"
            "Line two"
        )


@pytest.mark.asyncio
async def test_ticket_detail_blank_comment_html_fallback_does_not_render_raw_html_tags() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="",
                    type="",
                    body_html=None,
                    description="<p>Line one<br />Line two</p>",
                    item_model=None,
                )
            ]
        )
        await pilot.pause()

        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        assert activity_headline_widgets(right_body) == []
        assert len(activity_markdown_widgets(right_body)) == 1
        rendered = str(right_body.render())
        assert rendered == "Comment | 2026-03-28 10:30 | Operator One\nLine one\nLine two"
        assert "<p>" not in rendered
        assert "<br" not in rendered


@pytest.mark.asyncio
async def test_ticket_detail_activity_image_falls_back_to_placeholder_in_headless_mode() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)

    async def fail_load(_url: str) -> bytes:
        raise AssertionError("headless fallback should not load image bytes")

    app = TicketDetailHarness(
        ticket,
        resolve_activity_asset_url=lambda url: (
            f"https://demo.daktela.com{url}&accessToken=token-123"
            if url.startswith("/file/")
            else url
        ),
        load_activity_asset=fail_load,
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="Internal note",
                    type="",
                    body_html=(
                        '<p>Before</p><img src="/file/image.php?mapper=activities&name=5" alt="Scan" />'
                        "<p>After</p>"
                    ),
                    item_model=None,
                )
            ]
        )
        await pilot.pause()

        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        assert len(activity_markdown_widgets(right_body)) == 2
        assert len(activity_image_widgets(right_body)) == 1
        assert str(right_body.render()) == (
            "Comment | 2026-03-28 10:30 | Operator One\n"
            "Internal note\n"
            "Before\n"
            "Image: Scan\n"
            "After"
        )
        assert right_body.discovered_links == [
            ActivityLink(
                url="https://demo.daktela.com/file/image.php?mapper=activities&name=5&accessToken=token-123",
                label="Image: Scan",
            )
        ]


@pytest.mark.asyncio
async def test_ticket_detail_activity_image_widget_loads_inline_when_supported(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    loaded_urls: list[str] = []

    async def load_image(url: str) -> bytes:
        loaded_urls.append(url)
        return make_png_bytes()

    app = TicketDetailHarness(
        ticket,
        resolve_activity_asset_url=lambda url: f"https://demo.daktela.com{url}",
        load_activity_asset=load_image,
    )
    monkeypatch.setattr(DetailPaneBody, "_supports_inline_images", lambda self: True)

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="Internal note",
                    type="",
                    body_html='<img src="/file/image.php?mapper=activities&name=5" alt="Scan" />',
                    item_model=None,
                )
            ]
        )
        await pilot.pause()
        await pilot.pause()

        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        image_widget = activity_image_widgets(right_body)[0]
        assert loaded_urls == ["https://demo.daktela.com/file/image.php?mapper=activities&name=5"]
        assert len(image_widget._placeholder_lines) > 1
        first_line = image_widget.render_line(0)
        assert any(_segment.text.startswith("\x1b_G") for _segment in first_line)


@pytest.mark.asyncio
async def test_ticket_detail_image_only_comment_does_not_render_raw_img_html() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(
        ticket,
        resolve_activity_asset_url=lambda url: f"https://demo.daktela.com{url}",
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="",
                    type="",
                    body_html='<img src="/file/image.php?mapper=activities&name=5" alt="Scan" />',
                    item_model=None,
                )
            ]
        )
        await pilot.pause()

        rendered = str(
            detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody).render()
        )
        assert rendered == "Comment | 2026-03-28 10:30 | Operator One\nImage: Scan"
        assert "<img" not in rendered


@pytest.mark.asyncio
async def test_ticket_detail_activities_pane_initializes_selection_to_first_activity() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(title="First activity", body_html="<p>One</p>"),
                make_activity(title="Second activity", time="2026-03-28 10:45:00", body_html="<p>Two</p>"),
            ]
        )
        await pilot.pause()

        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        assert right_body.active_index == 0
        assert [widget.has_class("-active") for widget in activity_title_widgets(right_body)] == [False, False]

        await pilot.press("tab")
        await pilot.pause()

        assert [widget.has_class("-active") for widget in activity_title_widgets(right_body)] == [True, False]


@pytest.mark.asyncio
async def test_ticket_detail_activities_pane_navigates_with_jk_and_arrow_keys() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(title="First activity", body_html="<p>One</p>"),
                make_activity(title="Second activity", time="2026-03-28 10:45:00", body_html="<p>Two</p>"),
                make_activity(title="Third activity", type="CALL", time="2026-03-28 11:00:00", body_html="<p>Three</p>"),
            ]
        )
        await pilot.pause()

        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        await pilot.press("tab")
        await pilot.pause()

        assert right_body.active_index == 0
        assert [widget.has_class("-active") for widget in activity_title_widgets(right_body)] == [
            True,
            False,
            False,
        ]

        await pilot.press("j")
        await pilot.pause()

        assert right_body.active_index == 1
        assert [widget.has_class("-active") for widget in activity_title_widgets(right_body)] == [
            False,
            True,
            False,
        ]

        await pilot.press("down")
        await pilot.pause()

        assert right_body.active_index == 2
        assert [widget.has_class("-active") for widget in activity_title_widgets(right_body)] == [
            False,
            False,
            True,
        ]

        await pilot.press("down")
        await pilot.pause()

        assert right_body.active_index == 2

        await pilot.press("k")
        await pilot.pause()

        assert right_body.active_index == 1

        await pilot.press("up")
        await pilot.pause()

        assert right_body.active_index == 0
        assert [widget.has_class("-active") for widget in activity_title_widgets(right_body)] == [
            True,
            False,
            False,
        ]

        await pilot.press("up")
        await pilot.pause()

        assert right_body.active_index == 0


@pytest.mark.asyncio
async def test_ticket_detail_activities_highlight_clears_when_pane_loses_focus() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(title="First activity", body_html="<p>One</p>"),
                make_activity(title="Second activity", time="2026-03-28 10:45:00", body_html="<p>Two</p>"),
            ]
        )
        await pilot.pause()

        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)

        await pilot.press("tab", "j")
        await pilot.pause()

        assert right_body.active_index == 1
        assert [widget.has_class("-active") for widget in activity_title_widgets(right_body)] == [False, True]

        await pilot.press("shift+tab")
        await pilot.pause()

        assert right_body.active_index == 1
        assert [widget.has_class("-active") for widget in activity_title_widgets(right_body)] == [False, False]


@pytest.mark.asyncio
async def test_ticket_detail_activities_placeholder_states_clear_visible_selection() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(title="First activity", body_html="<p>One</p>"),
                make_activity(title="Second activity", time="2026-03-28 10:45:00", body_html="<p>Two</p>"),
            ]
        )
        await pilot.pause()

        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        await pilot.press("tab", "j")
        await pilot.pause()

        assert right_body.active_index == 1
        assert [widget.has_class("-active") for widget in activity_title_widgets(right_body)] == [False, True]

        detail_screen.set_activities_loading()
        await pilot.pause()

        assert right_body.render() == "loading activities..."
        assert right_body.active_index == 0
        assert activity_title_widgets(right_body) == []

        detail_screen.set_activities_error()
        await pilot.pause()

        assert right_body.render() == "unable to load activities"
        assert right_body.active_index == 0
        assert activity_title_widgets(right_body) == []

        detail_screen.set_ticket_activities([])
        await pilot.pause()

        assert right_body.render() == "no activities yet"
        assert right_body.active_index == 0
        assert activity_title_widgets(right_body) == []


@pytest.mark.asyncio
async def test_ticket_detail_uses_compact_left_pane_and_wider_activity_pane() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001, description="Needs a replacement")
    app = TicketDetailHarness(ticket)

    async with app.run_test(size=(120, 24)) as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        left_pane = detail_screen.query_one("#ticket-detail-left-pane", Vertical)
        right_pane = detail_screen.query_one("#ticket-detail-right-pane", Vertical)
        panes = detail_screen.query_one("#ticket-detail-panes", Horizontal)
        splitter = detail_screen.query_one("#ticket-detail-splitter", VerticalSplitter)

        assert left_pane.region.width < right_pane.region.width
        assert left_pane.region.width <= round(panes.region.width * 0.35)
        assert right_pane.region.width >= round(panes.region.width * 0.6)
        assert splitter.region.width == 1

        initial_left_width = left_pane.region.width
        detail_screen.split_percent = 45.0
        await pilot.pause()

        assert left_pane.region.width > initial_left_width


@pytest.mark.asyncio
async def test_ticket_detail_tab_and_shift_tab_switch_focus_between_panes() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        left_body = app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        right_body = app.screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        left_title = app.screen.query_one("#ticket-detail-left-title", Static)
        right_title = app.screen.query_one("#ticket-detail-right-title")

        assert left_title.render() == "Ticket Detail"
        assert right_title_label(cast(TicketDetail, app.screen)).render() == "Activities"
        assert app.screen.active_bindings["tab"].binding.description == "Next Pane"
        assert app.screen.active_bindings["tab"].binding.show is True
        assert app.screen.active_bindings["shift+tab"].binding.description == "Previous Pane"
        assert app.screen.active_bindings["shift+tab"].binding.show is False
        assert app.focused is left_body
        assert left_title.has_class("-focused") is True
        assert right_title.has_class("-focused") is False

        await pilot.press("tab")
        await pilot.pause()

        assert app.focused is right_body
        assert left_title.has_class("-focused") is False
        assert right_title.has_class("-focused") is True

        await pilot.press("shift+tab")
        await pilot.pause()

        assert app.focused is left_body


@pytest.mark.asyncio
async def test_ticket_detail_slash_opens_activity_search_from_right_pane() -> None:
    app = TicketDetailHarness(make_ticket(title="Broken scanner", name=2001))

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities([make_activity(title="Customer replied")])
        await pilot.pause()

        await pilot.press("tab", "/")
        await pilot.pause()

        search_bar = detail_screen.query_one("#ticket-detail-activity-search-bar", Horizontal)

        assert search_bar.has_class("-active") is True
        assert app.focused is activity_search_input(detail_screen)


@pytest.mark.asyncio
async def test_ticket_detail_escape_closes_activity_search_and_refocuses_right_pane() -> None:
    app = TicketDetailHarness(make_ticket(title="Broken scanner", name=2001))

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities([make_activity(title="Customer replied")])
        await pilot.pause()

        await pilot.press("tab", "/")
        await pilot.pause()
        await pilot.press("escape")
        await pilot.pause()

        search_bar = detail_screen.query_one("#ticket-detail-activity-search-bar", Horizontal)
        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)

        assert search_bar.has_class("-active") is False
        assert app.focused is right_body


@pytest.mark.asyncio
async def test_ticket_detail_activity_search_selects_match_and_keeps_all_activities_visible() -> None:
    app = TicketDetailHarness(make_ticket(title="Broken scanner", name=2001))

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(title="Customer replied"),
                make_activity(title="Internal note", type="", item_model=None),
                make_activity(title="Target escalation"),
            ]
        )
        await pilot.pause()

        await pilot.press("tab", "/", "T", "a", "r", "g", "e", "t", "enter")
        await pilot.pause()

        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        search_bar = detail_screen.query_one("#ticket-detail-activity-search-bar", Horizontal)

        assert search_bar.has_class("-active") is False
        assert app.focused is right_body
        assert right_body.active_index == 2
        assert right_body.selected_activity is not None
        assert right_body.selected_activity.title == "Target escalation"
        assert len(activity_title_widgets(right_body)) == 3
        assert right_body._search_status_message() == "/Target 1/1"


@pytest.mark.asyncio
async def test_ticket_detail_activity_search_navigation_wraps_for_n_and_shift_n() -> None:
    app = TicketDetailHarness(make_ticket(title="Broken scanner", name=2001))

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(title="Target alpha"),
                make_activity(title="Internal note", type="", item_model=None),
                make_activity(title="Target beta"),
            ]
        )
        await pilot.pause()

        await pilot.press("tab", "/", "T", "a", "r", "g", "e", "t", "enter")
        await pilot.pause()

        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        assert right_body.active_index == 0
        assert right_body._search_status_message() == "/Target 1/2"

        await pilot.press("n")
        await pilot.pause()
        assert right_body.active_index == 2
        assert right_body._search_status_message() == "/Target 2/2"

        await pilot.press("n")
        await pilot.pause()
        assert right_body.active_index == 0
        assert right_body._search_status_message() == "/Target 1/2"

        await pilot.press("N")
        await pilot.pause()
        assert right_body.active_index == 2
        assert right_body._search_status_message() == "/Target 2/2"


@pytest.mark.asyncio
async def test_ticket_detail_activity_search_scrolls_match_into_view() -> None:
    app = TicketDetailHarness(make_ticket(title="Broken scanner", name=2001))

    async with app.run_test(size=(100, 18)) as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(title=f"Activity {index:02d}")
                for index in range(12)
            ]
            + [make_activity(title="Needle match")]
        )
        await pilot.pause()

        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        assert right_body.scroll_y == 0

        await pilot.press("tab", "/", "N", "e", "e", "d", "l", "e", "enter")
        await pilot.pause()

        assert right_body.active_index == 12
        assert right_body.scroll_y > 0


@pytest.mark.asyncio
async def test_ticket_detail_activity_search_no_match_keeps_selection_and_scroll_position() -> None:
    app = TicketDetailHarness(make_ticket(title="Broken scanner", name=2001))

    async with app.run_test(size=(100, 18)) as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [make_activity(title=f"Activity {index:02d}") for index in range(20)]
        )
        await pilot.pause()

        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)

        await pilot.press("tab", *["j"] * 15)
        await pilot.pause()

        selected_before = right_body.active_index
        scroll_before = right_body.scroll_y

        await pilot.press("/", "m", "i", "s", "s", "i", "n", "g", "enter")
        await pilot.pause()

        assert right_body.active_index == selected_before
        assert right_body.scroll_y == scroll_before
        assert right_body._search_status_message() == "No matches: /missing"


@pytest.mark.asyncio
async def test_ticket_detail_activity_search_invalid_regex_clears_previous_matches() -> None:
    app = TicketDetailHarness(make_ticket(title="Broken scanner", name=2001))

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(title="Target alpha"),
                make_activity(title="Target beta"),
            ]
        )
        await pilot.pause()

        right_body = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)

        await pilot.press("tab", "/", "T", "a", "r", "g", "e", "t", "enter")
        await pilot.pause()
        assert right_body._search_status_message() == "/Target 1/2"

        await pilot.press("/", "[", "enter")
        await pilot.pause()

        selected_before = right_body.active_index
        await pilot.press("n")
        await pilot.pause()

        assert right_body.active_index == selected_before
        assert right_body._search_match_indexes == []
        search_status = right_body._search_status_message()
        assert search_status is not None
        assert search_status.startswith("Invalid regex: ")


@pytest.mark.asyncio
async def test_ticket_detail_right_pane_focus_style_uses_composite_activities_header() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        right_title = detail_screen.query_one("#ticket-detail-right-title")
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="Fwd: test",
                    body_html="<p>Hello<br />world</p>",
                )
            ]
        )
        await pilot.pause()

        assert right_title_label(detail_screen).render() == "Activities"
        assert right_title.has_class("-focused") is False

        await pilot.press("tab")
        await pilot.pause()

        assert right_title.has_class("-focused") is True


@pytest.mark.asyncio
async def test_ticket_detail_email_quick_actions_show_only_for_focused_right_pane() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="Fwd: test",
                    body_html="<p>Hello<br />world</p>",
                    direction="in",
                )
            ]
        )
        await pilot.pause()

        assert quick_action_labels(detail_screen) == []
        assert title_quick_action_labels(detail_screen) == []

        await pilot.press("tab")
        await pilot.pause()

        assert quick_action_labels(detail_screen) == [
            "Reply to all (r)",
            "Forward (f)",
            "Copy (y)",
        ]
        assert title_quick_action_labels(detail_screen) == []

        await pilot.press("shift+tab")
        await pilot.pause()

        assert quick_action_labels(detail_screen) == []


@pytest.mark.asyncio
async def test_ticket_detail_comment_quick_actions_replace_email_actions_on_selection_change() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="Email activity",
                    type="EMAIL",
                    body_html="<p>One</p>",
                    direction="in",
                ),
                make_activity(
                    title="Comment activity",
                    type="",
                    body_html="<p>Two</p>",
                    item_model=None,
                ),
                make_activity(
                    title="Call activity",
                    type="CALL",
                    body_html="<p>Three</p>",
                    item_model=None,
                ),
            ]
        )
        await pilot.pause()

        await pilot.press("tab")
        await pilot.pause()

        assert quick_action_labels(detail_screen) == [
            "Reply to all (r)",
            "Forward (f)",
            "Copy (y)",
        ]

        await pilot.press("j")
        await pilot.pause()

        assert quick_action_labels(detail_screen) == ["Reply (r)", "Copy (y)"]

        await pilot.press("j")
        await pilot.pause()

        assert quick_action_labels(detail_screen) == ["Copy (y)"]


@pytest.mark.asyncio
async def test_ticket_detail_quick_actions_clear_for_placeholder_states() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="Fwd: test",
                    body_html="<p>Hello</p>",
                    direction="in",
                )
            ]
        )
        await pilot.pause()

        await pilot.press("tab")
        await pilot.pause()

        assert quick_action_labels(detail_screen) == [
            "Reply to all (r)",
            "Forward (f)",
            "Copy (y)",
        ]

        detail_screen.set_activities_loading()
        await pilot.pause()
        assert quick_action_labels(detail_screen) == []

        detail_screen.set_activities_error()
        await pilot.pause()
        assert quick_action_labels(detail_screen) == []

        detail_screen.set_ticket_activities([])
        await pilot.pause()
        assert quick_action_labels(detail_screen) == []


@pytest.mark.asyncio
async def test_ticket_detail_tab_from_active_select_clears_editing_state() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001, stage=TicketStage.OPEN)
    app = TicketDetailHarness(ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        form = app.screen.query_one("#ticket-detail-left-body", TicketDetailForm)
        right_body = app.screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        stage_select = app.screen.query_one("#ticket-stage-input", TicketFormSelect)

        await pilot.press("down", "left")
        await pilot.pause()

        assert form.editing is True
        assert stage_select.expanded is True

        await pilot.press("tab")
        await pilot.pause()

        assert app.focused is right_body
        assert form.editing is False
        assert stage_select.expanded is False

        await pilot.press("shift+tab")
        await pilot.pause()

        assert app.focused is form


def test_ticket_detail_message_control_properties_reference_the_screen() -> None:
    ticket = make_ticket()
    screen = TicketDetail(ticket, f"Selected ticket: {ticket.title}")
    activity = make_activity()
    link = make_discovered_link()
    request = TicketEmailSendRequest(
        action=TicketEmailAction.REPLY,
        source_email_name="emails_1",
        to="customer@example.com",
        subject="Re: Broken scanner",
        body="Draft reply",
        queue_name="support",
    )

    assert screen.SaveRequested(screen, ticket, TicketEditPatch(title="Updated")).control is screen
    assert screen.StatusRequested(screen, "Saved").control is screen
    assert screen.OpenInBrowserRequested(screen, ticket).control is screen
    assert screen.OpenActivityLinkRequested(screen, link.url).control is screen
    assert screen.CommentRequested(screen, ticket, "Internal note", ()).control is screen
    assert screen.EmailDraftRequested(screen, ticket, activity, TicketEmailAction.REPLY).control is screen
    assert screen.EmailSendRequested(screen, ticket, request).control is screen
    assert (
        screen.ActivityAttachmentDownloadRequested(screen, ticket, activity, Path("/tmp")).control
        is screen
    )


def test_ticket_detail_action_open_link_picker_posts_notice_without_links(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    posted_messages: list[TicketDetail.StatusRequested] = []
    right_body = SimpleNamespace(discovered_links=[])

    monkeypatch.setattr(screen, "query_one", lambda selector, *_args: right_body)
    monkeypatch.setattr(screen, "post_message", posted_messages.append)

    screen.action_open_link_picker()

    assert len(posted_messages) == 1
    assert posted_messages[0].text == "No links found in ticket activities."
    assert posted_messages[0].error is False


def test_ticket_detail_action_open_link_picker_pushes_modal_with_discovered_links(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    pushed_screens: list[object] = []
    callbacks: list[object] = []
    links = [
        make_discovered_link("https://example.test/alpha"),
        make_discovered_link("https://example.test/beta"),
    ]
    right_body = SimpleNamespace(discovered_links=links)

    monkeypatch.setattr(screen, "query_one", lambda selector, *_args: right_body)
    monkeypatch.setattr(
        TicketDetail,
        "app",
        property(
            lambda _self: SimpleNamespace(
                push_screen=lambda modal, callback: (pushed_screens.append(modal), callbacks.append(callback)),
            )
        ),
    )

    screen.action_open_link_picker()

    assert len(pushed_screens) == 1
    assert isinstance(pushed_screens[0], ActivityLinkPickerModal)
    assert callbacks == [screen._handle_link_picker_result]


def test_ticket_detail_request_attachment_download_posts_notice_without_attachments(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    posted_messages: list[TicketDetail.StatusRequested] = []

    monkeypatch.setattr(screen, "_selected_activity", lambda: make_activity(attachments=None))
    monkeypatch.setattr(screen, "post_message", posted_messages.append)

    screen._request_attachment_download()

    assert len(posted_messages) == 1
    assert posted_messages[0].text == ACTIVITY_DOWNLOAD_EMPTY_STATUS
    assert posted_messages[0].error is False


def test_ticket_detail_request_attachment_download_pushes_destination_picker(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    pushed_screens: list[object] = []
    callbacks: list[object] = []
    activity = make_activity(
        type="",
        item_model=None,
        attachments=[{"file": "6", "title": "April report.txt"}],
    )

    class AttachmentDestinationPickerModalStub:
        def __init__(self, initial_path: str) -> None:
            self.initial_path = initial_path

    monkeypatch.setattr(screen, "_selected_activity", lambda: activity)
    monkeypatch.setattr(
        "daktela_paleo.screens.ticket_detail.screen.AttachmentDestinationPickerModal",
        AttachmentDestinationPickerModalStub,
    )
    monkeypatch.setattr(
        TicketDetail,
        "app",
        property(
            lambda _self: SimpleNamespace(
                attachment_download_default_path=lambda: "~/Downloads",
                push_screen=lambda modal, callback: (pushed_screens.append(modal), callbacks.append(callback)),
            )
        ),
    )

    screen._request_attachment_download()

    assert screen._pending_attachment_download_activity == activity
    assert len(pushed_screens) == 1
    assert isinstance(pushed_screens[0], AttachmentDestinationPickerModalStub)
    assert pushed_screens[0].initial_path == "~/Downloads"
    assert callbacks == [screen._handle_attachment_destination_result]


def test_ticket_detail_handle_link_picker_result_restores_activities_focus_without_opening_on_cancel(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []

    monkeypatch.setattr(screen, "action_focus_right", lambda: calls.append("focus-right"))
    monkeypatch.setattr(
        screen,
        "post_message",
        lambda message: (_ for _ in ()).throw(
            AssertionError(f"post_message should not be used for cancel: {message!r}")
        ),
    )

    screen._handle_link_picker_result(None)

    assert calls == ["focus-right"]


def test_ticket_detail_handle_link_picker_result_posts_open_request_for_selected_link(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []
    posted_messages: list[TicketDetail.OpenActivityLinkRequested] = []
    link = make_discovered_link("https://example.test/path")

    monkeypatch.setattr(screen, "action_focus_right", lambda: calls.append("focus-right"))
    monkeypatch.setattr(screen, "post_message", posted_messages.append)

    screen._handle_link_picker_result(link)

    assert calls == ["focus-right"]
    assert len(posted_messages) == 1
    assert posted_messages[0].url == "https://example.test/path"


def test_ticket_detail_handle_attachment_destination_result_restores_focus_without_download_on_cancel(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []
    screen._pending_attachment_download_activity = make_activity(
        type="",
        item_model=None,
        attachments=[{"file": "6", "title": "April report.txt"}],
    )

    monkeypatch.setattr(screen, "action_focus_right", lambda: calls.append("focus-right"))
    monkeypatch.setattr(
        screen,
        "post_message",
        lambda message: (_ for _ in ()).throw(
            AssertionError(f"post_message should not be used for cancel: {message!r}")
        ),
    )

    screen._handle_attachment_destination_result(None)

    assert calls == ["focus-right"]
    assert screen._pending_attachment_download_activity is None


def test_ticket_detail_handle_attachment_destination_result_posts_download_request(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    ticket = make_ticket()
    activity = make_activity(
        type="",
        item_model=None,
        attachments=[{"file": "6", "title": "April report.txt"}],
    )
    screen = TicketDetail(ticket, f"Selected ticket: {ticket.title}")
    screen._pending_attachment_download_activity = activity
    calls: list[str] = []
    posted_messages: list[TicketDetail.ActivityAttachmentDownloadRequested] = []

    monkeypatch.setattr(screen, "action_focus_right", lambda: calls.append("focus-right"))
    monkeypatch.setattr(screen, "post_message", posted_messages.append)

    screen._handle_attachment_destination_result(tmp_path)

    assert calls == ["focus-right"]
    assert len(posted_messages) == 1
    assert posted_messages[0].ticket == ticket
    assert posted_messages[0].activity == activity
    assert posted_messages[0].destination_dir == tmp_path


def test_ticket_detail_handle_comment_reply_submitted_posts_comment_request(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket()
    screen = TicketDetail(ticket, f"Selected ticket: {ticket.title}")
    posted_messages: list[TicketDetail.CommentRequested] = []
    pin_calls: list[str] = []
    pending_calls: list[bool] = []
    composer = cast(
        CommentReplyComposer,
        SimpleNamespace(
            set_submission_pending=lambda pending: pending_calls.append(pending),
            reply_target=make_activity(title="Internal note", type="", item_model=None),
        ),
    )

    monkeypatch.setattr(
        screen,
        "query_one",
        lambda selector, *_args: (
            SimpleNamespace(pin_selection=lambda: pin_calls.append("pin"))
            if selector == "#ticket-detail-right-body"
            else composer
        ),
    )
    monkeypatch.setattr(screen, "post_message", posted_messages.append)
    attachment_paths = (Path("/tmp/report.txt"),)

    screen.handle_comment_reply_submitted(
        CommentReplyComposer.Submitted(composer, "Internal note", attachment_paths)
    )

    assert pin_calls == ["pin"]
    assert pending_calls == [True]
    assert len(posted_messages) == 1
    assert posted_messages[0].ticket == ticket
    assert posted_messages[0].content == "Internal note"
    assert posted_messages[0].attachment_paths == attachment_paths


def test_ticket_detail_handle_top_level_comment_submit_skips_selection_pin(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket()
    screen = TicketDetail(ticket, f"Selected ticket: {ticket.title}")
    posted_messages: list[TicketDetail.CommentRequested] = []
    pending_calls: list[bool] = []
    composer = cast(
        CommentReplyComposer,
        SimpleNamespace(
            set_submission_pending=lambda pending: pending_calls.append(pending),
            reply_target=None,
        ),
    )

    monkeypatch.setattr(
        screen,
        "query_one",
        lambda selector, *_args: (_ for _ in ()).throw(
            AssertionError(f"query_one should not be used for top-level submit: {selector!r}")
        ),
    )
    monkeypatch.setattr(screen, "post_message", posted_messages.append)

    screen.handle_comment_reply_submitted(
        CommentReplyComposer.Submitted(composer, "Internal note", ())
    )

    assert pending_calls == [True]
    assert len(posted_messages) == 1


def test_ticket_detail_handle_comment_attachment_path_requested_pushes_path_picker(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    pushed_screens: list[object] = []
    callbacks: list[object] = []
    composer = cast(CommentReplyComposer, SimpleNamespace())

    monkeypatch.setattr(
        TicketDetail,
        "app",
        property(
            lambda _self: SimpleNamespace(
                push_screen=lambda modal, callback: (pushed_screens.append(modal), callbacks.append(callback)),
            )
        ),
    )

    screen.handle_comment_attachment_path_requested(
        CommentReplyComposer.AttachmentPathRequested(composer)
    )

    assert len(pushed_screens) == 1
    assert isinstance(pushed_screens[0], CommentAttachmentPathPickerModal)
    assert callbacks == [screen._handle_comment_attachment_path_result]


def test_ticket_detail_handle_comment_attachment_removal_requested_pushes_removal_picker(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    pushed_screens: list[object] = []
    callbacks: list[object] = []
    paths = (Path("/tmp/report.txt"), Path("/tmp/invoice.pdf"))
    composer = cast(
        CommentReplyComposer,
        SimpleNamespace(staged_attachment_paths=paths),
    )

    monkeypatch.setattr(
        TicketDetail,
        "app",
        property(
            lambda _self: SimpleNamespace(
                push_screen=lambda modal, callback: (pushed_screens.append(modal), callbacks.append(callback)),
            )
        ),
    )

    screen.handle_comment_attachment_removal_requested(
        CommentReplyComposer.AttachmentRemovalRequested(composer)
    )

    assert len(pushed_screens) == 1
    assert isinstance(pushed_screens[0], CommentAttachmentRemovalModal)
    assert callbacks == [screen._handle_comment_attachment_removal_result]


def test_ticket_detail_handle_comment_attachment_path_result_stages_file_and_refreshes_focus(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []
    composer = SimpleNamespace(
        is_open=True,
        stage_attachment=lambda path: calls.append(f"stage:{path}"),
        focus_editor=lambda: calls.append("focus"),
    )

    monkeypatch.setattr(screen, "_comment_reply_composer", lambda: composer)
    monkeypatch.setattr(screen, "call_after_refresh", lambda callback: callback())
    monkeypatch.setattr(screen, "_refresh_focus_styles", lambda: calls.append("refresh"))

    staged_path = tmp_path / "report.txt"
    screen._handle_comment_attachment_path_result(staged_path)

    assert calls == [f"stage:{staged_path}", "refresh"]


def test_ticket_detail_handle_comment_attachment_path_result_refocuses_when_cancelled(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []
    composer = SimpleNamespace(
        is_open=False,
        stage_attachment=lambda path: calls.append(f"stage:{path}"),
        focus_editor=lambda: calls.append("focus"),
    )

    monkeypatch.setattr(screen, "_comment_reply_composer", lambda: composer)
    monkeypatch.setattr(screen, "call_after_refresh", lambda callback: callback())
    monkeypatch.setattr(screen, "_refresh_focus_styles", lambda: calls.append("refresh"))

    screen._handle_comment_attachment_path_result(None)

    assert calls == ["focus", "refresh"]


def test_ticket_detail_handle_comment_attachment_removal_result_unstages_file_and_refreshes_focus(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []
    composer = SimpleNamespace(
        is_open=True,
        unstage_attachment=lambda path: calls.append(f"unstage:{path}"),
        focus_editor=lambda: calls.append("focus"),
    )

    monkeypatch.setattr(screen, "_comment_reply_composer", lambda: composer)
    monkeypatch.setattr(screen, "call_after_refresh", lambda callback: callback())
    monkeypatch.setattr(screen, "_refresh_focus_styles", lambda: calls.append("refresh"))

    staged_path = tmp_path / "report.txt"
    screen._handle_comment_attachment_removal_result(staged_path)

    assert calls == [f"unstage:{staged_path}", "refresh"]


def test_ticket_detail_handle_comment_attachment_removal_result_refocuses_when_cancelled(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []
    composer = SimpleNamespace(
        is_open=False,
        unstage_attachment=lambda path: calls.append(f"unstage:{path}"),
        focus_editor=lambda: calls.append("focus"),
    )

    monkeypatch.setattr(screen, "_comment_reply_composer", lambda: composer)
    monkeypatch.setattr(screen, "call_after_refresh", lambda callback: callback())
    monkeypatch.setattr(screen, "_refresh_focus_styles", lambda: calls.append("refresh"))

    screen._handle_comment_attachment_removal_result(None)

    assert calls == ["focus", "refresh"]


def test_ticket_detail_save_or_submit_comment_reply_prefers_email_composer(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []

    monkeypatch.setattr(
        screen,
        "_email_reply_composer",
        lambda: SimpleNamespace(
            is_open=True,
            has_focus_within=True,
            action_submit=lambda: calls.append("submit-email"),
        ),
    )
    monkeypatch.setattr(
        screen,
        "_comment_reply_composer",
        lambda: SimpleNamespace(
            is_open=True,
            has_focus_within=True,
            action_submit=lambda: calls.append("submit-comment"),
        ),
    )
    monkeypatch.setattr(screen, "action_save", lambda: calls.append("save"))

    screen.action_save_or_submit_comment_reply()

    assert calls == ["submit-email"]


def test_ticket_detail_handle_email_reply_submitted_posts_email_send_request(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket()
    screen = TicketDetail(ticket, f"Selected ticket: {ticket.title}")
    request = TicketEmailSendRequest(
        action=TicketEmailAction.REPLY,
        source_email_name="emails_1",
        to="customer@example.com",
        subject="Re: Broken scanner",
        body="Draft reply",
        queue_name="support",
    )
    posted_messages: list[TicketDetail.EmailSendRequested] = []
    pin_calls: list[str] = []
    pending_calls: list[bool] = []
    composer = cast(
        TicketEmailComposer,
        SimpleNamespace(
            set_submission_pending=lambda pending: pending_calls.append(pending),
        ),
    )

    monkeypatch.setattr(
        screen,
        "query_one",
        lambda selector, *_args: (
            SimpleNamespace(pin_selection=lambda: pin_calls.append("pin"))
            if selector == "#ticket-detail-right-body"
            else composer
        ),
    )
    monkeypatch.setattr(screen, "post_message", posted_messages.append)

    screen.handle_email_reply_submitted(TicketEmailComposer.Submitted(composer, request))

    assert pin_calls == ["pin"]
    assert pending_calls == [True]
    assert len(posted_messages) == 1
    assert posted_messages[0].ticket == ticket
    assert posted_messages[0].request == request


def test_ticket_detail_invoke_quick_action_opens_inline_comment_reply_for_comment_reply(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []

    monkeypatch.setattr(screen, "_current_quick_actions", lambda: COMMENT_QUICK_ACTIONS)
    monkeypatch.setattr(screen, "_selected_activity_is_comment", lambda: True)
    monkeypatch.setattr(screen, "_open_comment_reply", lambda: calls.append("open"))
    monkeypatch.setattr(
        screen,
        "post_message",
        lambda message: (_ for _ in ()).throw(
            AssertionError(f"post_message should not be used for comment reply: {message!r}")
        ),
    )

    screen._invoke_quick_action("reply")

    assert calls == ["open"]


def test_ticket_detail_invoke_quick_action_copies_selected_activity_body_for_copy(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []

    monkeypatch.setattr(screen, "_copy_selected_activity_body", lambda: calls.append("copy"))

    screen._invoke_quick_action("copy")

    assert calls == ["copy"]


def test_ticket_detail_invoke_quick_action_opens_attachment_picker_for_download(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []

    monkeypatch.setattr(screen, "_current_quick_actions", lambda: (DOWNLOAD_QUICK_ACTION,))
    monkeypatch.setattr(screen, "_request_attachment_download", lambda: calls.append("download"))

    screen._invoke_quick_action("download")

    assert calls == ["download"]


def test_ticket_detail_invoke_quick_action_posts_email_draft_request_for_email_reply(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[TicketEmailAction] = []

    monkeypatch.setattr(screen, "_current_quick_actions", lambda: (SimpleNamespace(action="reply"),))
    monkeypatch.setattr(screen, "_selected_activity_is_comment", lambda: False)
    monkeypatch.setattr(screen, "_selected_activity_is_email", lambda: True)
    monkeypatch.setattr(screen, "_request_email_draft", lambda action: calls.append(action))

    screen._invoke_quick_action("reply")

    assert calls == [TicketEmailAction.REPLY]


def test_ticket_detail_copy_selected_activity_body_updates_clipboard_and_posts_notice(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    copied_values: list[str] = []
    posted_messages: list[TicketDetail.StatusRequested] = []
    activity = make_activity(body_html="<p>Hello<br />world</p>")

    monkeypatch.setattr(screen, "_selected_activity", lambda: activity)
    monkeypatch.setattr(screen, "post_message", posted_messages.append)
    monkeypatch.setattr(
        TicketDetail,
        "app",
        property(lambda self: SimpleNamespace(copy_to_clipboard=copied_values.append)),
    )

    screen._copy_selected_activity_body()

    assert copied_values == ["Hello\r\nworld"]
    assert len(posted_messages) == 1
    assert posted_messages[0].text == ACTIVITY_COPY_SUCCESS_STATUS
    assert posted_messages[0].error is False


def test_ticket_detail_clipboard_text_normalizes_line_endings_to_crlf() -> None:
    assert TicketDetail._clipboard_text("Line one\nLine two") == "Line one\r\nLine two"
    assert TicketDetail._clipboard_text("Line one\rLine two") == "Line one\r\nLine two"
    assert TicketDetail._clipboard_text("Line one\r\nLine two") == "Line one\r\nLine two"


def test_ticket_detail_copy_selected_activity_body_posts_notice_without_copyable_text(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    posted_messages: list[TicketDetail.StatusRequested] = []
    activity = make_activity(body_html=None, item_description=None, description=None)

    monkeypatch.setattr(screen, "_selected_activity", lambda: activity)
    monkeypatch.setattr(screen, "post_message", posted_messages.append)
    monkeypatch.setattr(
        TicketDetail,
        "app",
        property(
            lambda self: SimpleNamespace(
                copy_to_clipboard=lambda text: (_ for _ in ()).throw(
                    AssertionError(f"copy_to_clipboard should not be called: {text!r}")
                )
            )
        ),
    )

    screen._copy_selected_activity_body()

    assert len(posted_messages) == 1
    assert posted_messages[0].text == ACTIVITY_COPY_EMPTY_STATUS
    assert posted_messages[0].error is False


def test_ticket_detail_copy_selected_activity_body_posts_notice_without_selection(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    posted_messages: list[TicketDetail.StatusRequested] = []

    monkeypatch.setattr(screen, "_selected_activity", lambda: None)
    monkeypatch.setattr(screen, "post_message", posted_messages.append)

    screen._copy_selected_activity_body()

    assert len(posted_messages) == 1
    assert posted_messages[0].text == ACTIVITY_COPY_EMPTY_STATUS
    assert posted_messages[0].error is False


def test_ticket_detail_handle_email_draft_failure_restores_activities_focus(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []
    right_body = SimpleNamespace(unpin_selection=lambda: calls.append("unpin"))

    monkeypatch.setattr(screen, "_close_email_reply", lambda *, restore_focus: calls.append(f"close:{restore_focus}"))
    monkeypatch.setattr(screen, "query_one", lambda selector, *_args: right_body)
    monkeypatch.setattr(
        TicketDetail,
        "app",
        property(lambda _self: SimpleNamespace(set_focus=lambda widget: calls.append(f"focus:{widget is right_body}"))),
    )
    monkeypatch.setattr(screen, "call_after_refresh", lambda callback: calls.append(callback.__name__))

    screen.handle_email_draft_failure()

    assert calls == ["close:False", "unpin", "focus:True", "_refresh_focus_styles"]


def test_ticket_detail_handle_email_submit_success_closes_composer_and_shows_loading(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []

    monkeypatch.setattr(screen, "_email_reply_is_open", lambda: True)
    monkeypatch.setattr(screen, "_close_email_reply", lambda *, restore_focus: calls.append(f"close:{restore_focus}"))
    monkeypatch.setattr(
        screen,
        "query_one",
        lambda selector, *_args: SimpleNamespace(show_loading=lambda: calls.append("loading")),
    )
    monkeypatch.setattr(screen, "action_focus_right", lambda: calls.append("focus-right"))

    screen.handle_email_submit_success()

    assert calls == ["close:False", "loading", "focus-right"]


def test_ticket_detail_handle_email_submit_failure_preserves_draft(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []
    composer = SimpleNamespace(
        is_open=True,
        set_submission_pending=lambda pending: calls.append(f"pending:{pending}"),
        show_validation=lambda message: calls.append(f"validation:{message}"),
        focus_editor=lambda: calls.append("focus"),
    )

    monkeypatch.setattr(screen, "_email_reply_composer", lambda: composer)
    monkeypatch.setattr(
        screen,
        "query_one",
        lambda selector, *_args: SimpleNamespace(pin_selection=lambda: calls.append("pin")),
    )

    screen.handle_email_submit_failure("boom")

    assert calls == ["pending:False", "validation:boom", "pin", "focus"]


def test_ticket_detail_open_in_browser_posts_message(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket()
    screen = TicketDetail(ticket, f"Selected ticket: {ticket.title}")
    posted_messages: list[TicketDetail.OpenInBrowserRequested] = []

    monkeypatch.setattr(screen, "post_message", posted_messages.append)

    screen.action_open_in_browser()

    assert len(posted_messages) == 1
    assert posted_messages[0].ticket == ticket


def test_ticket_detail_focus_and_blur_schedule_focus_refresh() -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    scheduled: list[object] = []

    screen.call_after_refresh = scheduled.append  # type: ignore[method-assign]

    screen.on_focus()
    screen.on_blur()

    assert scheduled == [screen._refresh_focus_styles, screen._refresh_focus_styles]


def test_ticket_detail_splitter_drag_updates_split_percent(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    panes = SimpleNamespace(
        size=SimpleNamespace(width=101),
        region=SimpleNamespace(x=10),
    )

    monkeypatch.setattr(screen, "query_one", lambda selector, *args: panes)

    screen.on_vertical_splitter_dragged(VerticalSplitter.Dragged(VerticalSplitter(), 60))

    assert screen.split_percent == 50.0


def test_ticket_detail_apply_pane_layout_returns_early_when_too_narrow(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    panes = SimpleNamespace(size=SimpleNamespace(width=2))

    def fake_query_one(selector: object, *args: object) -> object:
        if selector == "#ticket-detail-panes":
            return panes
        raise AssertionError("pane widgets should not be queried for a narrow layout")

    monkeypatch.setattr(screen, "query_one", fake_query_one)

    screen._apply_pane_layout()


def test_ticket_detail_refresh_focus_styles_ignores_missing_widgets(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")

    def raise_no_matches(*args: object, **kwargs: object) -> None:
        raise NoMatches("detail children not mounted")

    monkeypatch.setattr(screen, "query_one", raise_no_matches)

    screen._refresh_focus_styles()


def test_ticket_detail_handle_unsaved_changes_none_returns(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []

    monkeypatch.setattr(screen, "request_close_after_save", lambda: calls.append("save"))

    screen._handle_unsaved_changes_decision(None)

    assert calls == []


def test_ticket_detail_selection_and_quick_action_message_controls_reference_pane() -> None:
    pane = DetailPaneBody()

    assert pane.SelectionChanged(pane, None).control is pane
    assert pane.QuickActionRequested(pane, "reply").control is pane
    assert pane.QuickActionRequested(pane, "copy").control is pane


def test_detail_pane_action_request_copy_quick_action_posts_copy_message() -> None:
    pane = DetailPaneBody()
    posted_messages: list[DetailPaneBody.QuickActionRequested] = []
    pane.post_message = posted_messages.append  # type: ignore[method-assign]

    pane.action_request_copy_quick_action()

    assert len(posted_messages) == 1
    assert posted_messages[0].action == "copy"
    assert posted_messages[0].control is pane


def test_detail_pane_quick_action_from_widget_id_returns_copy_for_copy_button() -> None:
    assert DetailPaneBody._quick_action_from_widget_id("ticket-detail-quick-action-copy") == "copy"


def test_detail_pane_quick_action_from_widget_id_returns_download_for_download_button() -> None:
    assert DetailPaneBody._quick_action_from_widget_id("ticket-detail-quick-action-download") == (
        "download"
    )


def test_ticket_detail_focus_next_pane_focuses_left_when_right_pane_is_active(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []

    monkeypatch.setattr(screen, "_left_pane_has_focus", lambda: False)
    monkeypatch.setattr(screen, "action_focus_left", lambda: calls.append("left"))

    screen.action_focus_next_pane()

    assert calls == ["left"]


def test_ticket_detail_focus_previous_pane_blurs_left_and_focuses_right(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []

    monkeypatch.setattr(screen, "_left_pane_has_focus", lambda: True)
    monkeypatch.setattr(screen, "_prepare_left_pane_for_blur", lambda: calls.append("blur"))
    monkeypatch.setattr(screen, "action_focus_right", lambda: calls.append("right"))

    screen.action_focus_previous_pane()

    assert calls == ["blur", "right"]


def test_ticket_detail_focus_right_uses_reply_editor_when_inline_reply_is_open(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []

    monkeypatch.setattr(screen, "_email_reply_is_open", lambda: False)
    monkeypatch.setattr(screen, "_comment_reply_is_open", lambda: True)
    monkeypatch.setattr(
        screen,
        "_comment_reply_composer",
        lambda: SimpleNamespace(focus_editor=lambda: calls.append("focus-editor")),
    )
    monkeypatch.setattr(screen, "call_after_refresh", lambda _callback: None)

    screen.action_focus_right()

    assert calls == ["focus-editor"]


def test_ticket_detail_focus_right_prefers_email_editor_when_inline_email_is_open(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []

    monkeypatch.setattr(screen, "_email_reply_is_open", lambda: True)
    monkeypatch.setattr(
        screen,
        "_email_reply_composer",
        lambda: SimpleNamespace(focus_editor=lambda: calls.append("focus-email")),
    )
    monkeypatch.setattr(
        screen,
        "_comment_reply_composer",
        lambda: SimpleNamespace(focus_editor=lambda: calls.append("focus-comment")),
    )
    monkeypatch.setattr(screen, "call_after_refresh", lambda _callback: None)

    screen.action_focus_right()

    assert calls == ["focus-email"]


def test_ticket_detail_assign_to_me_posts_error_without_current_user(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    posted_messages: list[TicketDetail.StatusRequested] = []

    monkeypatch.setattr(screen, "post_message", posted_messages.append)

    screen.action_assign_to_me()

    assert len(posted_messages) == 1
    assert posted_messages[0].text == "Current app user is not available."
    assert posted_messages[0].error is True


def test_ticket_detail_action_add_comment_opens_inline_comment_compose(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []

    monkeypatch.setattr(screen, "_open_new_comment", lambda: calls.append("open"))

    screen.action_add_comment()

    assert calls == ["open"]


def test_ticket_detail_assign_reply_user_from_activity_posts_notice_without_safe_match(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    posted_messages: list[TicketDetail.StatusRequested] = []
    form = SimpleNamespace(resolve_assignable_user=lambda **_kwargs: None)

    monkeypatch.setattr(screen, "query_one", lambda selector, *_args: form)
    monkeypatch.setattr(screen, "post_message", posted_messages.append)

    screen._assign_reply_user_from_activity(
        make_activity(type="", item_model=None, user="Operator Three", user_name="operator_3")
    )

    assert len(posted_messages) == 1
    assert posted_messages[0].text == REPLY_USER_UNMATCHED_STATUS
    assert posted_messages[0].error is False


def test_ticket_detail_open_new_comment_unpins_selection_and_opens_inline_composer(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []
    composer = SimpleNamespace(open_new_comment=lambda: calls.append("open"))

    def fake_query_one(selector: str, *_args: object) -> object:
        if selector == "#ticket-detail-right-body":
            return SimpleNamespace(unpin_selection=lambda: calls.append("unpin"))
        if selector == "#email-reply-composer":
            return SimpleNamespace(is_open=False)
        if selector == "#comment-reply-composer":
            return composer
        raise AssertionError(f"unexpected selector: {selector!r}")

    monkeypatch.setattr(screen, "query_one", fake_query_one)
    monkeypatch.setattr(screen, "call_after_refresh", lambda callback: calls.append(callback.__name__))

    screen._open_new_comment()

    assert calls == ["unpin", "open", "_refresh_focus_styles"]


def test_ticket_detail_open_new_comment_closes_open_email_composer(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []

    def fake_query_one(selector: str, *_args: object) -> object:
        if selector == "#ticket-detail-right-body":
            return SimpleNamespace(unpin_selection=lambda: calls.append("unpin"))
        if selector == "#comment-reply-composer":
            return SimpleNamespace(open_new_comment=lambda: calls.append("open"))
        raise AssertionError(f"unexpected selector: {selector!r}")

    monkeypatch.setattr(screen, "query_one", fake_query_one)
    monkeypatch.setattr(screen, "_email_reply_is_open", lambda: True)
    monkeypatch.setattr(screen, "_close_email_reply", lambda *, restore_focus: calls.append(f"close-email:{restore_focus}"))
    monkeypatch.setattr(screen, "call_after_refresh", lambda callback: calls.append(callback.__name__))

    screen._open_new_comment()

    assert calls == ["close-email:False", "unpin", "open", "_refresh_focus_styles"]


def test_ticket_detail_handle_comment_submit_success_returns_when_reply_is_closed(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")

    monkeypatch.setattr(screen, "_comment_reply_is_open", lambda: False)

    screen.handle_comment_submit_success()


def test_ticket_detail_handle_comment_submit_failure_returns_when_reply_is_closed(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")

    monkeypatch.setattr(screen, "_comment_reply_composer", lambda: SimpleNamespace(is_open=False))

    screen.handle_comment_submit_failure("boom")


def test_ticket_detail_handle_email_submit_success_returns_when_reply_is_closed(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")

    monkeypatch.setattr(screen, "_email_reply_is_open", lambda: False)

    screen.handle_email_submit_success()


def test_ticket_detail_handle_email_submit_failure_returns_when_reply_is_closed(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")

    monkeypatch.setattr(screen, "_email_reply_composer", lambda: SimpleNamespace(is_open=False))

    screen.handle_email_submit_failure("boom")


def test_ticket_detail_cancel_comment_reply_or_close_prefers_cancelling_inline_reply(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []

    monkeypatch.setattr(
        screen,
        "_email_reply_composer",
        lambda: SimpleNamespace(
            is_open=False,
            has_focus_within=False,
        ),
    )
    monkeypatch.setattr(
        screen,
        "_comment_reply_composer",
        lambda: SimpleNamespace(
            is_open=True,
            has_focus_within=True,
            action_cancel=lambda: calls.append("cancel"),
        ),
    )
    monkeypatch.setattr(screen, "action_close", lambda: calls.append("close"))

    screen.action_cancel_comment_reply_or_close()

    assert calls == ["cancel"]


def test_ticket_detail_cancel_comment_reply_or_close_prefers_cancelling_inline_email(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []

    monkeypatch.setattr(
        screen,
        "_email_reply_composer",
        lambda: SimpleNamespace(
            is_open=True,
            has_focus_within=True,
            action_cancel=lambda: calls.append("cancel-email"),
        ),
    )
    monkeypatch.setattr(
        screen,
        "_comment_reply_composer",
        lambda: SimpleNamespace(
            is_open=True,
            has_focus_within=True,
            action_cancel=lambda: calls.append("cancel-comment"),
        ),
    )
    monkeypatch.setattr(screen, "action_close", lambda: calls.append("close"))

    screen.action_cancel_comment_reply_or_close()

    assert calls == ["cancel-email"]


def test_ticket_detail_open_comment_reply_ignores_non_comment_selection(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    right_body = SimpleNamespace(selected_activity=None, pin_selection=lambda: None)
    calls: list[str] = []

    monkeypatch.setattr(
        screen,
        "query_one",
        lambda selector, *_args: (
            right_body
            if selector == "#ticket-detail-right-body"
            else SimpleNamespace(is_open=False)
        ),
    )
    monkeypatch.setattr(screen, "_comment_reply_composer", lambda: SimpleNamespace(open_for=lambda _: calls.append("open")))

    screen._open_comment_reply()

    assert calls == []


def test_ticket_detail_open_comment_reply_closes_open_email_composer(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []
    activity = make_activity(title="Internal note", type="", item_model=None)
    right_body = SimpleNamespace(selected_activity=activity, pin_selection=lambda: calls.append("pin"))

    monkeypatch.setattr(screen, "query_one", lambda selector, *_args: right_body)
    monkeypatch.setattr(screen, "_email_reply_is_open", lambda: True)
    monkeypatch.setattr(screen, "_close_email_reply", lambda *, restore_focus: calls.append(f"close-email:{restore_focus}"))
    monkeypatch.setattr(screen, "_assign_reply_user_from_activity", lambda current: calls.append(f"assign:{current is activity}"))
    monkeypatch.setattr(screen, "_comment_reply_composer", lambda: SimpleNamespace(open_for=lambda current: calls.append(f"open:{current is activity}")))
    monkeypatch.setattr(screen, "call_after_refresh", lambda callback: calls.append(callback.__name__))

    screen._open_comment_reply()

    assert calls == [
        "close-email:False",
        "assign:True",
        "pin",
        "open:True",
        "_refresh_focus_styles",
    ]


def test_ticket_detail_request_email_draft_pins_selection_and_posts_message(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket()
    activity = make_activity(title="Customer replied", direction="in")
    screen = TicketDetail(ticket, f"Selected ticket: {ticket.title}")
    posted_messages: list[TicketDetail.EmailDraftRequested] = []
    calls: list[str] = []

    def fake_query_one(selector: str, *_args: object) -> object:
        if selector == "#ticket-detail-right-body":
            return SimpleNamespace(selected_activity=activity, pin_selection=lambda: calls.append("pin"))
        if selector == "#comment-reply-composer":
            return SimpleNamespace(is_open=False)
        if selector == "#email-reply-composer":
            return SimpleNamespace(is_open=False)
        raise AssertionError(f"unexpected selector: {selector!r}")

    monkeypatch.setattr(screen, "query_one", fake_query_one)
    monkeypatch.setattr(screen, "post_message", posted_messages.append)

    screen._request_email_draft(TicketEmailAction.FORWARD)

    assert calls == ["pin"]
    assert len(posted_messages) == 1
    assert posted_messages[0].ticket == ticket
    assert posted_messages[0].activity == activity
    assert posted_messages[0].action is TicketEmailAction.FORWARD


def test_ticket_detail_request_email_draft_returns_for_non_email_selection(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")

    monkeypatch.setattr(screen, "_selected_activity", lambda: make_activity(type="", item_model=None))
    monkeypatch.setattr(
        screen,
        "post_message",
        lambda message: (_ for _ in ()).throw(
            AssertionError(f"post_message should not be used for non-email selection: {message!r}")
        ),
    )

    screen._request_email_draft(TicketEmailAction.REPLY)


def test_ticket_detail_request_email_draft_refocuses_existing_matching_composer(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    activity = make_activity(title="Customer replied", direction="in")
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    calls: list[str] = []

    def fake_query_one(selector: str, *_args: object) -> object:
        if selector == "#ticket-detail-right-body":
            return SimpleNamespace(selected_activity=activity, pin_selection=lambda: calls.append("pin"))
        if selector == "#email-reply-composer":
            return SimpleNamespace(
                is_open=True,
                action=TicketEmailAction.REPLY,
                source_activity_name=activity.name,
                focus_editor=lambda: calls.append("focus"),
            )
        raise AssertionError(f"unexpected selector: {selector!r}")

    monkeypatch.setattr(screen, "query_one", fake_query_one)
    monkeypatch.setattr(screen, "call_after_refresh", lambda callback: calls.append(callback.__name__))
    monkeypatch.setattr(
        screen,
        "post_message",
        lambda message: (_ for _ in ()).throw(
            AssertionError(f"post_message should not be used when refocusing: {message!r}")
        ),
    )

    screen._request_email_draft(TicketEmailAction.REPLY)

    assert calls == ["focus", "_refresh_focus_styles"]


def test_ticket_detail_request_email_draft_closes_open_inline_composers(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ticket = make_ticket()
    activity = make_activity(title="Customer replied", direction="in")
    screen = TicketDetail(ticket, f"Selected ticket: {ticket.title}")
    posted_messages: list[TicketDetail.EmailDraftRequested] = []
    calls: list[str] = []

    def fake_query_one(selector: str, *_args: object) -> object:
        if selector == "#ticket-detail-right-body":
            return SimpleNamespace(selected_activity=activity, pin_selection=lambda: calls.append("pin"))
        if selector == "#email-reply-composer":
            return SimpleNamespace(is_open=True, action=TicketEmailAction.FORWARD, source_activity_name="other")
        raise AssertionError(f"unexpected selector: {selector!r}")

    monkeypatch.setattr(screen, "query_one", fake_query_one)
    monkeypatch.setattr(screen, "_comment_reply_is_open", lambda: True)
    monkeypatch.setattr(screen, "_close_comment_reply", lambda *, restore_focus: calls.append(f"close-comment:{restore_focus}"))
    monkeypatch.setattr(screen, "_close_email_reply", lambda *, restore_focus: calls.append(f"close-email:{restore_focus}"))
    monkeypatch.setattr(screen, "post_message", posted_messages.append)

    screen._request_email_draft(TicketEmailAction.REPLY)

    assert calls == ["close-comment:False", "close-email:False", "pin"]
    assert len(posted_messages) == 1


def test_ticket_detail_close_email_reply_returns_when_closed(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")

    monkeypatch.setattr(screen, "_email_reply_composer", lambda: SimpleNamespace(is_open=False))

    screen._close_email_reply(restore_focus=True)


def test_ticket_detail_cancel_comment_reply_returns_when_reply_is_closed(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")

    monkeypatch.setattr(screen, "_comment_reply_composer", lambda: SimpleNamespace(is_open=False))

    screen._cancel_comment_reply()


def test_detail_pane_click_reply_quick_action_focuses_pane_and_posts_request() -> None:
    pane = DetailPaneBody()
    calls: list[str] = []
    stop_calls: list[str] = []
    posted_messages: list[DetailPaneBody.QuickActionRequested] = []

    pane.focus = lambda: calls.append("focus")  # type: ignore[method-assign]
    pane.post_message = posted_messages.append  # type: ignore[method-assign]

    pane.on_click(
        cast(
            events.Click,
            SimpleNamespace(
                widget=SimpleNamespace(id="ticket-detail-quick-action-reply"),
                stop=lambda: stop_calls.append("stop"),
            ),
        )
    )

    assert calls == ["focus"]
    assert stop_calls == ["stop"]
    assert [message.action for message in posted_messages] == ["reply"]


def test_detail_pane_click_forward_quick_action_focuses_pane_and_posts_request() -> None:
    pane = DetailPaneBody()
    calls: list[str] = []
    stop_calls: list[str] = []
    posted_messages: list[DetailPaneBody.QuickActionRequested] = []

    pane.focus = lambda: calls.append("focus")  # type: ignore[method-assign]
    pane.post_message = posted_messages.append  # type: ignore[method-assign]

    pane.on_click(
        cast(
            events.Click,
            SimpleNamespace(
                widget=SimpleNamespace(id="ticket-detail-quick-action-forward"),
                stop=lambda: stop_calls.append("stop"),
            ),
        )
    )

    assert calls == ["focus"]
    assert stop_calls == ["stop"]
    assert [message.action for message in posted_messages] == ["forward"]


def test_detail_pane_click_ignores_unknown_widgets() -> None:
    pane = DetailPaneBody()
    calls: list[str] = []
    posted_messages: list[DetailPaneBody.QuickActionRequested] = []

    pane.focus = lambda: calls.append("focus")  # type: ignore[method-assign]
    pane.post_message = posted_messages.append  # type: ignore[method-assign]

    pane.on_click(
        cast(
            events.Click,
            SimpleNamespace(
                widget=SimpleNamespace(id="ticket-detail-quick-action-unknown"),
                stop=lambda: calls.append("stop"),
            ),
        )
    )

    assert calls == []
    assert posted_messages == []


def test_ticket_detail_current_quick_actions_returns_empty_tuple_when_right_body_is_missing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")

    def raise_no_matches(selector: object, *args: object) -> object:
        raise NoMatches(str(selector))

    monkeypatch.setattr(screen, "query_one", raise_no_matches)

    assert screen._current_quick_actions() == ()


def test_ticket_detail_current_quick_actions_returns_empty_tuple_when_right_body_is_unfocused(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")
    right_body = SimpleNamespace(selected_activity=make_activity(type="EMAIL"))
    monkeypatch.setattr(type(screen), "app", property(lambda self: SimpleNamespace(focused=object())))
    monkeypatch.setattr(screen, "query_one", lambda selector, *args: right_body)

    assert screen._current_quick_actions() == ()


def test_ticket_detail_quick_actions_for_activity_returns_empty_tuple_for_missing_activity() -> None:
    assert TicketDetail._quick_actions_for_activity(None) == ()


def test_ticket_detail_quick_actions_for_activity_returns_copy_only_for_other_copyable_activity() -> None:
    activity = make_activity(type="CALL", body_html="<p>Copied text</p>", item_model=None)

    assert TicketDetail._quick_actions_for_activity(activity) == (COPY_QUICK_ACTION,)


def test_ticket_detail_quick_actions_for_activity_includes_download_when_attachments_exist() -> None:
    activity = make_activity(
        type="",
        item_model=None,
        body_html="<p>Copied text</p>",
        attachments=[{"file": "6", "title": "April report.txt"}],
    )

    assert TicketDetail._quick_actions_for_activity(activity) == (
        *COMMENT_QUICK_ACTIONS,
        DOWNLOAD_QUICK_ACTION,
        COPY_QUICK_ACTION,
    )


@pytest.mark.asyncio
async def test_ticket_detail_current_quick_actions_returns_empty_tuple_when_right_body_is_not_focused() -> None:
    app = TicketDetailHarness(make_ticket())

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(
                    title="Internal note",
                    type="",
                    item_model=None,
                )
            ]
        )
        await pilot.pause()

        assert detail_screen._current_quick_actions() == ()
def test_ticket_detail_selected_activity_is_comment_returns_false_when_right_body_is_missing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    screen = TicketDetail(make_ticket(), "Selected ticket: Printer is jammed")

    def raise_no_matches(selector: object, *args: object) -> object:
        raise NoMatches(str(selector))

    monkeypatch.setattr(screen, "query_one", raise_no_matches)

    assert screen._selected_activity_is_comment() is False


def test_detail_pane_selected_activity_returns_none_for_out_of_range_index() -> None:
    pane = DetailPaneBody()
    pane._activities = [make_activity(title="One")]
    pane.active_index = 5

    assert pane.selected_activity is None


def test_detail_pane_move_active_activity_ignores_empty_activity_list() -> None:
    pane = DetailPaneBody()
    pane.active_index = 3

    pane._move_active_activity(1)

    assert pane.active_index == 3


def test_detail_pane_apply_search_empty_query_clears_matches() -> None:
    pane = DetailPaneBody()
    pane._search_query = "needle"
    pane._search_match_indexes = [0]
    pane._search_active_match_index = 0

    pane.apply_search("")

    assert pane._search_query is None
    assert pane._search_match_indexes == []
    assert pane._search_active_match_index is None


def test_detail_pane_search_messages_expose_control() -> None:
    pane = DetailPaneBody()

    assert pane.SearchRequested(pane).control is pane
    assert pane.SearchStatusChanged(pane, "/needle 1/2").control is pane


def test_detail_pane_initial_search_match_index_wraps_when_selection_is_past_matches() -> None:
    pane = DetailPaneBody()
    pane.active_index = 5

    assert pane._initial_search_match_index([1, 3]) == 0


def test_detail_pane_initial_search_match_index_returns_none_for_empty_matches() -> None:
    pane = DetailPaneBody()

    assert pane._initial_search_match_index([]) is None


def test_detail_pane_activity_search_values_include_summary_headline_and_body() -> None:
    activity = make_activity(
        title="Escalation update",
        body_html="<p>Customer called back</p>",
    )

    assert DetailPaneBody._activity_search_values(activity) == (
        "Email | 2026-03-28 10:30 | Operator One",
        "Escalation update",
        "Customer called back",
    )


def test_detail_pane_discover_links_collects_plain_text_html_and_dedupes() -> None:
    activities = [
        make_activity(
            title="Customer replied",
            description="Docs: https://example.test/docs and https://example.test/docs.",
            item_model=None,
        ),
        make_activity(
            title="Email body",
            body_html=(
                '<p>Open <a href="https://example.test/html">the portal</a> and '
                '<a href="https://example.test/docs">the docs</a>.</p>'
            ),
        ),
    ]

    assert DetailPaneBody.discover_links(activities) == [
        ActivityLink(url="https://example.test/docs"),
        ActivityLink(url="https://example.test/html"),
    ]


def test_detail_pane_discovered_links_reflect_current_activities() -> None:
    pane = DetailPaneBody()
    pane._activities = [
        make_activity(
            title="Internal note",
            description="Use https://example.test/internal",
            item_model=None,
            type="",
        )
    ]

    assert pane.discovered_links == [
        ActivityLink(url="https://example.test/internal")
    ]


def test_detail_pane_discover_links_includes_item_description_source() -> None:
    activities = [
        make_activity(
            title="Escalation update",
            body_html=None,
            item_description="Read https://example.test/item-description",
        )
    ]

    assert DetailPaneBody.discover_links(activities) == [
        ActivityLink(url="https://example.test/item-description")
    ]


def test_detail_pane_next_search_match_initializes_from_selection_when_index_is_missing() -> None:
    pane = DetailPaneBody()
    pane._activities = [make_activity(title="One"), make_activity(title="Two"), make_activity(title="Three")]
    pane.active_index = 0
    pane._search_match_indexes = [1, 2]
    pane._search_active_match_index = None

    pane.action_next_search_match()

    assert pane.active_index == 1
    assert pane._search_active_match_index == 0


def test_detail_pane_sync_search_match_from_active_index_posts_updated_status() -> None:
    pane = DetailPaneBody()
    posted_messages: list[DetailPaneBody.SearchStatusChanged] = []
    pane.post_message = posted_messages.append  # type: ignore[method-assign]
    pane._search_query = "needle"
    pane._search_match_indexes = [1, 3]
    pane._search_active_match_index = 0

    pane._sync_search_match_from_active_index(3)

    assert pane._search_active_match_index == 1
    assert posted_messages[-1].status == "/needle 2/2"


def test_detail_pane_refresh_inline_quick_actions_ignores_out_of_range_widget_index(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    pane = DetailPaneBody()
    pane._activities = [make_activity(title="One"), make_activity(title="Two", type="EMAIL")]
    pane.active_index = 1
    actions: list[tuple[object, ...]] = []
    widget = SimpleNamespace(set_actions=lambda values: actions.append(tuple(values)))

    monkeypatch.setattr(pane, "_entry_quick_action_widgets", lambda: [widget])
    monkeypatch.setattr(DetailPaneBody, "app", property(lambda self: SimpleNamespace(focused=pane)))
    monkeypatch.setattr(
        pane,
        "_quick_actions_for_activity",
        lambda activity: (_ for _ in ()).throw(
            AssertionError("quick actions should not be resolved for an out-of-range widget index")
        ),
    )

    pane._refresh_inline_quick_actions()

    assert actions == [()]


def test_detail_pane_cursor_actions_ignore_movement_when_selection_is_pinned() -> None:
    pane = DetailPaneBody()
    pane._activities = [make_activity(title="One"), make_activity(title="Two")]
    pane.active_index = 0
    pane.selection_pinned = True

    pane.action_cursor_down()
    pane.action_cursor_up()

    assert pane.active_index == 0


def test_detail_pane_pin_selection_ignores_empty_activity_list() -> None:
    pane = DetailPaneBody()

    pane.pin_selection()
    pane.unpin_selection()

    assert pane.selection_pinned is False


def test_detail_pane_scroll_active_activity_ignores_missing_entry(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    pane = DetailPaneBody()
    pane._activities = [make_activity(title="One")]
    pane.active_index = 1

    monkeypatch.setattr(pane, "_entry_widgets", lambda: [])
    monkeypatch.setattr(
        pane,
        "scroll_to_widget",
        lambda *args, **kwargs: (_ for _ in ()).throw(
            AssertionError("scroll_to_widget should not be called without an entry")
        ),
    )

    pane._scroll_active_activity_into_view()


@pytest.mark.asyncio
async def test_detail_pane_refresh_inline_quick_actions_ignores_out_of_range_quick_action_widget(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = TicketDetailHarness(make_ticket())

    async with app.run_test() as pilot:
        await pilot.pause()

        detail_screen = cast(TicketDetail, app.screen)
        detail_screen.set_ticket_activities(
            [
                make_activity(title="First email"),
                make_activity(title="Second email"),
            ]
        )

        await pilot.press("tab")
        await pilot.pause()

        pane = detail_screen.query_one("#ticket-detail-right-body", DetailPaneBody)
        calls: list[tuple[object, ...]] = []
        fake_widget = SimpleNamespace(set_actions=lambda actions: calls.append(tuple(actions)))
        monkeypatch.setattr(pane, "_entry_quick_action_widgets", lambda: [fake_widget])
        pane.active_index = 1

        pane._refresh_inline_quick_actions()

        assert calls == [()]


def test_detail_pane_summary_line_uses_dash_for_missing_timestamp() -> None:
    activity = make_activity(title="Internal note").model_copy(update={"time": None})

    assert DetailPaneBody._summary_line(activity) == "Email | - | Operator One"


def test_detail_pane_summary_line_includes_attachment_indicator_and_count() -> None:
    activity = make_activity(
        title="Internal note",
        type="",
        item_model=None,
        attachments=[
            {"file": "6", "title": "April report.txt"},
            {"file": "7", "title": "invoice.pdf"},
        ],
    )

    assert DetailPaneBody._summary_line(activity) == "Comment | 2026-03-28 10:30 | Operator One |  2"
