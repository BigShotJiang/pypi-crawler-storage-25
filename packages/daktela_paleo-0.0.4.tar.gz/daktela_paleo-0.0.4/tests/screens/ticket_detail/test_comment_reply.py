import subprocess
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
from typing import cast

import pytest
from textual import events
from textual.widgets import Button, Static, TextArea

import daktela_paleo.screens.ticket_detail.widgets.comment_reply as comment_reply_module
from daktela_paleo.screens.ticket_detail.widgets.comment_reply import (
    CommentReplyComposer,
    CommentReplyTextArea,
    ExternalEditorError,
    _edit_draft_in_external_editor,
)
from tests.support import TicketDetailHarness, make_activity, make_ticket


def test_comment_reply_composer_message_controls_reference_widget() -> None:
    composer = CommentReplyComposer()

    assert composer.Submitted(composer, "Internal note", ()).control is composer
    assert composer.AttachmentPathRequested(composer).control is composer
    assert composer.AttachmentRemovalRequested(composer).control is composer
    assert composer.Cancelled(composer).control is composer


def test_edit_draft_in_external_editor_round_trips_draft_through_editor(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    suspend_calls: list[str] = []
    run_calls: list[tuple[list[str], bool]] = []
    edited_path: str | None = None

    class FakeApp:
        @contextmanager
        def suspend(self) -> Iterator[None]:
            suspend_calls.append("enter")
            try:
                yield
            finally:
                suspend_calls.append("exit")

    def fake_run(args: list[str], *, check: bool) -> subprocess.CompletedProcess[str]:
        nonlocal edited_path
        run_calls.append((list(args), check))
        edited_path = args[-1]
        assert Path(args[-1]).read_text(encoding="utf-8") == "Draft comment"
        Path(args[-1]).write_text("Edited externally\nSecond line", encoding="utf-8")
        return subprocess.CompletedProcess(args, 0)

    monkeypatch.setenv("EDITOR", "nvim -f")
    monkeypatch.setattr(comment_reply_module.subprocess, "run", fake_run)

    edited = _edit_draft_in_external_editor(FakeApp(), "Draft comment")

    assert edited == "Edited externally\nSecond line"
    assert suspend_calls == ["enter", "exit"]
    assert run_calls == [(["nvim", "-f", edited_path], True)]
    assert edited_path is not None
    assert Path(edited_path).exists() is False


def test_edit_draft_in_external_editor_requires_editor_environment_variable(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class FakeApp:
        @contextmanager
        def suspend(self) -> Iterator[None]:
            yield

    monkeypatch.delenv("EDITOR", raising=False)

    with pytest.raises(ExternalEditorError, match=r"set \$EDITOR first"):
        _edit_draft_in_external_editor(FakeApp(), "Draft comment")


def test_edit_draft_in_external_editor_reports_launch_failure(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class FakeApp:
        @contextmanager
        def suspend(self) -> Iterator[None]:
            yield

    def fake_run(args: list[str], *, check: bool) -> subprocess.CompletedProcess[str]:
        raise FileNotFoundError("missing-editor")

    monkeypatch.setenv("EDITOR", "missing-editor")
    monkeypatch.setattr(comment_reply_module.subprocess, "run", fake_run)

    with pytest.raises(ExternalEditorError, match="Unable to launch external editor"):
        _edit_draft_in_external_editor(FakeApp(), "Draft comment")


def test_edit_draft_in_external_editor_reports_suspend_not_supported(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class FakeApp:
        @contextmanager
        def suspend(self) -> Iterator[None]:
            raise comment_reply_module.SuspendNotSupported("unsupported")
            yield

    monkeypatch.setenv("EDITOR", "nvim")

    with pytest.raises(ExternalEditorError, match="unavailable in this environment"):
        _edit_draft_in_external_editor(FakeApp(), "Draft comment")


def test_edit_draft_in_external_editor_reports_non_zero_exit_status(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class FakeApp:
        @contextmanager
        def suspend(self) -> Iterator[None]:
            yield

    def fake_run(args: list[str], *, check: bool) -> subprocess.CompletedProcess[str]:
        raise subprocess.CalledProcessError(23, args)

    monkeypatch.setenv("EDITOR", "nvim")
    monkeypatch.setattr(comment_reply_module.subprocess, "run", fake_run)

    with pytest.raises(ExternalEditorError, match="status 23"):
        _edit_draft_in_external_editor(FakeApp(), "Draft comment")


def test_comment_reply_composer_on_key_routes_submit_external_edit_and_cancel_actions() -> None:
    composer = CommentReplyComposer()
    calls: list[str] = []
    composer._is_open = True
    original_has_focus_within = type(composer).has_focus_within
    type(composer).has_focus_within = property(lambda self: True)  # type: ignore[assignment]

    try:
        composer.action_submit = lambda: calls.append("submit")  # type: ignore[method-assign]
        composer.action_edit_in_external_editor = lambda: calls.append("edit")  # type: ignore[method-assign]
        composer.action_request_attachment_path = lambda: calls.append("attach")  # type: ignore[method-assign]
        composer.action_request_attachment_removal = lambda: calls.append("remove")  # type: ignore[method-assign]
        composer.action_cancel = lambda: calls.append("cancel")  # type: ignore[method-assign]

        submit_event = cast(
            events.Key,
            SimpleNamespace(key="ctrl+s", stop=lambda: calls.append("stop-submit")),
        )
        composer.on_key(submit_event)

        external_edit_event = cast(
            events.Key,
            SimpleNamespace(key="ctrl+e", stop=lambda: calls.append("stop-edit")),
        )
        composer.on_key(external_edit_event)

        attach_event = cast(
            events.Key,
            SimpleNamespace(key="ctrl+a", stop=lambda: calls.append("stop-attach")),
        )
        composer.on_key(attach_event)

        remove_event = cast(
            events.Key,
            SimpleNamespace(key="ctrl+d", stop=lambda: calls.append("stop-remove")),
        )
        composer.on_key(remove_event)

        cancel_event = cast(
            events.Key,
            SimpleNamespace(key="escape", stop=lambda: calls.append("stop-cancel")),
        )
        composer.on_key(cancel_event)
    finally:
        type(composer).has_focus_within = original_has_focus_within  # type: ignore[assignment]

    assert calls == [
        "stop-submit",
        "submit",
        "stop-edit",
        "edit",
        "stop-attach",
        "attach",
        "stop-remove",
        "remove",
        "stop-cancel",
        "cancel",
    ]


def test_comment_reply_composer_on_key_ignores_when_closed_or_unfocused() -> None:
    composer = CommentReplyComposer()
    calls: list[str] = []
    composer.action_submit = lambda: calls.append("submit")  # type: ignore[method-assign]

    composer.on_key(cast(events.Key, SimpleNamespace(key="ctrl+s", stop=lambda: calls.append("stop"))))

    assert calls == []


def test_comment_reply_composer_button_press_routes_submit_and_cancel_actions() -> None:
    composer = CommentReplyComposer()
    calls: list[str] = []

    composer.action_submit = lambda: calls.append("submit")  # type: ignore[method-assign]
    composer.action_cancel = lambda: calls.append("cancel")  # type: ignore[method-assign]
    composer.action_edit_in_external_editor = lambda: calls.append("edit")  # type: ignore[method-assign]
    composer.action_request_attachment_path = lambda: calls.append("attach")  # type: ignore[method-assign]
    composer.action_request_attachment_removal = lambda: calls.append("remove")  # type: ignore[method-assign]

    composer.on_button_pressed(
        cast(
            Button.Pressed,
            SimpleNamespace(
                button=SimpleNamespace(id="comment-reply-submit"),
                stop=lambda: calls.append("stop-submit"),
            ),
        )
    )
    composer.on_button_pressed(
        cast(
            Button.Pressed,
            SimpleNamespace(
                button=SimpleNamespace(id="comment-reply-attach"),
                stop=lambda: calls.append("stop-attach"),
            ),
        )
    )
    composer.on_button_pressed(
        cast(
            Button.Pressed,
            SimpleNamespace(
                button=SimpleNamespace(id="comment-reply-remove"),
                stop=lambda: calls.append("stop-remove"),
            ),
        )
    )
    composer.on_button_pressed(
        cast(
            Button.Pressed,
            SimpleNamespace(
                button=SimpleNamespace(id="comment-reply-cancel"),
                stop=lambda: calls.append("stop-cancel"),
            ),
        )
    )

    assert calls == [
        "stop-submit",
        "submit",
        "stop-attach",
        "attach",
        "stop-remove",
        "remove",
        "stop-cancel",
        "cancel",
    ]


def test_comment_reply_composer_open_for_updates_target_and_preserves_same_target_draft(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    composer = CommentReplyComposer()
    activity = make_activity(title="Internal note", type="", body_html="<p>Plain text</p>", item_model=None)
    input_widget = SimpleNamespace(load_text=lambda text: load_calls.append(text), text="Draft")
    title_widget = SimpleNamespace(update=lambda text: title_updates.append(text))
    validation_widget = SimpleNamespace(update=lambda text: validation_updates.append(text), display=None)
    submit_button = SimpleNamespace(disabled=False)
    cancel_button = SimpleNamespace(disabled=False)
    hint_widget = SimpleNamespace(update=lambda text: hint_updates.append(text))
    load_calls: list[str] = []
    title_updates: list[str] = []
    validation_updates: list[str] = []
    hint_updates: list[str] = []
    class_calls: list[tuple[bool, str]] = []
    focus_calls: list[str] = []
    attach_button = SimpleNamespace(disabled=False)
    remove_button = SimpleNamespace(disabled=False)
    attachment_title_widget = SimpleNamespace(display=False)
    attachment_widget = SimpleNamespace(update=lambda text: attachment_updates.append(text), display=False)
    attachment_updates: list[str] = []

    def fake_query_one(selector: str, *_args: object) -> object:
        lookup = {
            "#comment-reply-input": input_widget,
            "#comment-reply-title": title_widget,
            "#comment-reply-attachments-title": attachment_title_widget,
            "#comment-reply-attachments": attachment_widget,
            "#comment-reply-validation": validation_widget,
            "#comment-reply-attach": attach_button,
            "#comment-reply-remove": remove_button,
            "#comment-reply-submit": submit_button,
            "#comment-reply-cancel": cancel_button,
            "#comment-reply-hint": hint_widget,
        }
        return lookup[selector]

    monkeypatch.setattr(composer, "query_one", fake_query_one)
    monkeypatch.setattr(composer, "set_class", lambda enabled, name: class_calls.append((enabled, name)))
    monkeypatch.setattr(composer, "focus_editor", lambda: focus_calls.append("focus"))

    composer.open_for(activity)
    composer.open_for(activity)

    assert composer.is_open is True
    assert composer.mode == "reply"
    assert composer.reply_target == activity
    assert load_calls == [""]
    assert class_calls == [(True, "-open"), (True, "-open")]
    assert focus_calls == ["focus", "focus"]
    assert title_updates == ["Add comment reply", "Add comment reply"]
    assert validation_updates == ["", ""]
    assert validation_widget.display is False
    assert hint_updates == [
        "Reply target stays locked while this draft is open. Ctrl+A stages a file, Ctrl+D removes one, Ctrl+E opens $EDITOR, and Enter inserts a newline.",
        "Reply target stays locked while this draft is open. Ctrl+A stages a file, Ctrl+D removes one, Ctrl+E opens $EDITOR, and Enter inserts a newline.",
    ]
    assert attachment_updates == [""]
    assert input_widget.read_only is False
    assert attach_button.disabled is False
    assert remove_button.disabled is True
    assert submit_button.disabled is False
    assert cancel_button.disabled is False


def test_comment_reply_composer_open_new_comment_preserves_draft_for_same_mode(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    composer = CommentReplyComposer()
    input_widget = SimpleNamespace(load_text=lambda text: load_calls.append(text), text="Draft")
    title_widget = SimpleNamespace(update=lambda text: title_updates.append(text))
    validation_widget = SimpleNamespace(update=lambda text: validation_updates.append(text), display=None)
    submit_button = SimpleNamespace(disabled=False)
    cancel_button = SimpleNamespace(disabled=False)
    hint_widget = SimpleNamespace(update=lambda text: hint_updates.append(text))
    load_calls: list[str] = []
    title_updates: list[str] = []
    validation_updates: list[str] = []
    hint_updates: list[str] = []
    class_calls: list[tuple[bool, str]] = []
    focus_calls: list[str] = []
    attach_button = SimpleNamespace(disabled=False)
    remove_button = SimpleNamespace(disabled=False)
    attachment_title_widget = SimpleNamespace(display=False)
    attachment_widget = SimpleNamespace(update=lambda text: attachment_updates.append(text), display=False)
    attachment_updates: list[str] = []

    def fake_query_one(selector: str, *_args: object) -> object:
        lookup = {
            "#comment-reply-input": input_widget,
            "#comment-reply-title": title_widget,
            "#comment-reply-attachments-title": attachment_title_widget,
            "#comment-reply-attachments": attachment_widget,
            "#comment-reply-validation": validation_widget,
            "#comment-reply-attach": attach_button,
            "#comment-reply-remove": remove_button,
            "#comment-reply-submit": submit_button,
            "#comment-reply-cancel": cancel_button,
            "#comment-reply-hint": hint_widget,
        }
        return lookup[selector]

    monkeypatch.setattr(composer, "query_one", fake_query_one)
    monkeypatch.setattr(composer, "set_class", lambda enabled, name: class_calls.append((enabled, name)))
    monkeypatch.setattr(composer, "focus_editor", lambda: focus_calls.append("focus"))

    composer.open_new_comment()
    composer.open_new_comment()

    assert composer.is_open is True
    assert composer.mode == "new_comment"
    assert composer.reply_target is None
    assert load_calls == [""]
    assert class_calls == [(True, "-open"), (True, "-open")]
    assert focus_calls == ["focus", "focus"]
    assert title_updates == ["Add comment", "Add comment"]
    assert validation_updates == ["", ""]
    assert validation_widget.display is False
    assert hint_updates == [
        "Recent activity stays visible while you compose. Ctrl+A stages a file, Ctrl+D removes one, Ctrl+E opens $EDITOR, and Enter inserts a newline.",
        "Recent activity stays visible while you compose. Ctrl+A stages a file, Ctrl+D removes one, Ctrl+E opens $EDITOR, and Enter inserts a newline.",
    ]
    assert attachment_updates == [""]


def test_comment_reply_composer_close_clears_state(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    composer = CommentReplyComposer()
    input_widget = SimpleNamespace(load_text=lambda text: load_calls.append(text))
    title_widget = SimpleNamespace(update=lambda text: title_updates.append(text))
    validation_widget = SimpleNamespace(update=lambda text: validation_updates.append(text), display=None)
    submit_button = SimpleNamespace(disabled=False)
    cancel_button = SimpleNamespace(disabled=False)
    hint_widget = SimpleNamespace(update=lambda text: hint_updates.append(text))
    load_calls: list[str] = []
    title_updates: list[str] = []
    validation_updates: list[str] = []
    hint_updates: list[str] = []
    class_calls: list[tuple[bool, str]] = []
    attach_button = SimpleNamespace(disabled=False)
    remove_button = SimpleNamespace(disabled=False)
    attachment_title_widget = SimpleNamespace(display=False)
    attachment_widget = SimpleNamespace(update=lambda text: attachment_updates.append(text), display=False)
    attachment_updates: list[str] = []

    def fake_query_one(selector: str, *_args: object) -> object:
        lookup = {
            "#comment-reply-input": input_widget,
            "#comment-reply-title": title_widget,
            "#comment-reply-attachments-title": attachment_title_widget,
            "#comment-reply-attachments": attachment_widget,
            "#comment-reply-validation": validation_widget,
            "#comment-reply-attach": attach_button,
            "#comment-reply-remove": remove_button,
            "#comment-reply-submit": submit_button,
            "#comment-reply-cancel": cancel_button,
            "#comment-reply-hint": hint_widget,
        }
        return lookup[selector]

    monkeypatch.setattr(composer, "query_one", fake_query_one)
    monkeypatch.setattr(composer, "set_class", lambda enabled, name: class_calls.append((enabled, name)))
    composer._is_open = True
    composer._is_submitting = True
    composer._mode = "reply"
    composer._reply_target = make_activity(title="Internal note", type="", item_model=None)

    composer.close()

    assert composer.is_open is False
    assert composer.mode == "new_comment"
    assert composer.reply_target is None
    assert class_calls == [(False, "-open")]
    assert load_calls == [""]
    assert title_updates == ["Add comment"]
    assert validation_updates == [""]
    assert validation_widget.display is False
    assert hint_updates == [
        "Recent activity stays visible while you compose. Ctrl+A stages a file, Ctrl+D removes one, Ctrl+E opens $EDITOR, and Enter inserts a newline."
    ]
    assert attachment_updates == [""]
    assert input_widget.read_only is False
    assert attach_button.disabled is False
    assert remove_button.disabled is True
    assert submit_button.disabled is False
    assert cancel_button.disabled is False


def test_comment_reply_composer_focus_editor_returns_when_closed() -> None:
    composer = CommentReplyComposer()

    composer.focus_editor()


def test_comment_reply_composer_action_submit_validates_and_posts_message(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    composer = CommentReplyComposer()
    validation_messages: list[str] = []
    posted_messages: list[CommentReplyComposer.Submitted] = []
    focus_calls: list[str] = []
    validation_widget = SimpleNamespace(update=validation_messages.append, display=None)

    def fake_query_one(selector: str, *_args: object) -> object:
        if selector == "#comment-reply-input":
            return SimpleNamespace(text="  Internal note  ")
        if selector == "#comment-reply-validation":
            return validation_widget
        raise AssertionError(f"unexpected selector: {selector!r}")

    monkeypatch.setattr(composer, "query_one", fake_query_one)
    monkeypatch.setattr(composer, "post_message", posted_messages.append)
    monkeypatch.setattr(composer, "focus_editor", lambda: focus_calls.append("focus"))
    composer._is_open = True

    composer.action_submit()

    assert validation_messages == [""]
    assert validation_widget.display is False
    assert focus_calls == []
    assert [message.content for message in posted_messages] == ["Internal note"]
    assert [message.attachment_paths for message in posted_messages] == [()]


def test_comment_reply_composer_action_submit_blank_stays_open_and_focuses_editor(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    composer = CommentReplyComposer()
    validation_messages: list[str] = []
    focus_calls: list[str] = []
    validation_widget = SimpleNamespace(update=validation_messages.append, display=None)

    def fake_query_one(selector: str, *_args: object) -> object:
        if selector == "#comment-reply-input":
            return SimpleNamespace(text="   ")
        if selector == "#comment-reply-validation":
            return validation_widget
        raise AssertionError(f"unexpected selector: {selector!r}")

    monkeypatch.setattr(composer, "query_one", fake_query_one)
    monkeypatch.setattr(composer, "focus_editor", lambda: focus_calls.append("focus"))
    monkeypatch.setattr(
        composer,
        "post_message",
        lambda message: (_ for _ in ()).throw(
            AssertionError(f"post_message should not be called for blank submit: {message!r}")
        ),
    )
    composer._is_open = True

    composer.action_submit()

    assert validation_messages == ["Comment body can't be blank."]
    assert validation_widget.display is True
    assert focus_calls == ["focus"]


def test_comment_reply_composer_action_submit_ignores_closed_or_pending_state() -> None:
    composer = CommentReplyComposer()

    composer.action_submit()
    composer._is_open = True
    composer._is_submitting = True
    composer.action_submit()


def test_comment_reply_composer_action_cancel_posts_cancelled_message(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    composer = CommentReplyComposer()
    posted_messages: list[CommentReplyComposer.Cancelled] = []
    monkeypatch.setattr(composer, "post_message", posted_messages.append)
    composer._is_open = True

    composer.action_cancel()

    assert len(posted_messages) == 1


def test_comment_reply_composer_action_request_attachment_path_posts_message(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    composer = CommentReplyComposer()
    posted_messages: list[CommentReplyComposer.AttachmentPathRequested] = []
    validation_messages: list[str] = []
    validation_widget = SimpleNamespace(update=validation_messages.append, display=None)

    monkeypatch.setattr(
        composer,
        "query_one",
        lambda selector, *_args: validation_widget
        if selector == "#comment-reply-validation"
        else (_ for _ in ()).throw(AssertionError(f"unexpected selector: {selector!r}")),
    )
    monkeypatch.setattr(composer, "post_message", posted_messages.append)

    composer.action_request_attachment_path()
    composer._is_open = True

    composer.action_request_attachment_path()
    composer._is_submitting = True
    composer.action_request_attachment_path()

    assert validation_messages == [""]
    assert len(posted_messages) == 1


def test_comment_reply_composer_action_request_attachment_removal_validates_empty_and_posts_message(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    composer = CommentReplyComposer()
    validation_messages: list[str] = []
    focus_calls: list[str] = []
    posted_messages: list[CommentReplyComposer.AttachmentRemovalRequested] = []
    validation_widget = SimpleNamespace(update=validation_messages.append, display=None)

    monkeypatch.setattr(
        composer,
        "query_one",
        lambda selector, *_args: validation_widget
        if selector == "#comment-reply-validation"
        else (_ for _ in ()).throw(AssertionError(f"unexpected selector: {selector!r}")),
    )
    monkeypatch.setattr(composer, "focus_editor", lambda: focus_calls.append("focus"))
    monkeypatch.setattr(composer, "post_message", posted_messages.append)
    composer._is_open = True

    composer.action_request_attachment_removal()
    composer._staged_attachment_paths = [Path("/tmp/report.txt")]
    composer.action_request_attachment_removal()
    composer._is_submitting = True
    composer.action_request_attachment_removal()

    assert validation_messages == ["No staged attachments to remove.", ""]
    assert focus_calls == ["focus"]
    assert len(posted_messages) == 1


def test_comment_reply_composer_stage_and_unstage_attachment_manage_state(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    composer = CommentReplyComposer()
    validation_messages: list[str] = []
    focus_calls: list[str] = []
    remove_button = SimpleNamespace(disabled=False)
    attachment_title_widget = SimpleNamespace(display=False)
    attachment_updates: list[str] = []
    attachment_widget = SimpleNamespace(update=attachment_updates.append, display=False)
    validation_widget = SimpleNamespace(update=validation_messages.append, display=None)

    def fake_query_one(selector: str, *_args: object) -> object:
        lookup = {
            "#comment-reply-attachments-title": attachment_title_widget,
            "#comment-reply-attachments": attachment_widget,
            "#comment-reply-validation": validation_widget,
            "#comment-reply-remove": remove_button,
        }
        return lookup[selector]

    monkeypatch.setattr(composer, "query_one", fake_query_one)
    monkeypatch.setattr(composer, "focus_editor", lambda: focus_calls.append("focus"))
    attachment_path = Path("/tmp/report.txt")

    assert composer.stage_attachment(attachment_path) is True
    assert composer.stage_attachment(attachment_path) is False
    assert composer.unstage_attachment(Path("/tmp/missing.txt")) is False
    assert composer.unstage_attachment(attachment_path) is True

    assert attachment_updates == [
        "report.txt (/tmp/report.txt)",
        "",
    ]
    assert validation_messages == ["", "File is already staged: report.txt", ""]
    assert focus_calls == ["focus", "focus", "focus"]
    assert remove_button.disabled is True


def test_comment_reply_composer_action_cancel_ignores_closed_or_pending_state() -> None:
    composer = CommentReplyComposer()

    composer.action_cancel()
    composer._is_open = True
    composer._is_submitting = True
    composer.action_cancel()


def test_comment_reply_composer_action_edit_in_external_editor_round_trips_draft(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    composer = CommentReplyComposer()
    validation_messages: list[str] = []
    focus_calls: list[str] = []
    load_calls: list[str] = []
    validation_widget = SimpleNamespace(update=validation_messages.append, display=None)
    input_widget = SimpleNamespace(text="Draft comment", load_text=load_calls.append)

    def fake_query_one(selector: str, *_args: object) -> object:
        if selector == "#comment-reply-input":
            return input_widget
        if selector == "#comment-reply-validation":
            return validation_widget
        raise AssertionError(f"unexpected selector: {selector!r}")

    monkeypatch.setattr(composer, "query_one", fake_query_one)
    monkeypatch.setattr(composer, "focus_editor", lambda: focus_calls.append("focus"))
    monkeypatch.setattr(
        composer,
        "_edit_draft_in_external_editor",
        lambda draft: f"{draft}\nEdited externally",
    )
    composer._is_open = True

    composer.action_edit_in_external_editor()

    assert validation_messages == [""]
    assert validation_widget.display is False
    assert load_calls == ["Draft comment\nEdited externally"]
    assert focus_calls == ["focus"]


def test_comment_reply_composer_action_edit_in_external_editor_preserves_draft_on_failure(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    composer = CommentReplyComposer()
    validation_messages: list[str] = []
    focus_calls: list[str] = []
    load_calls: list[str] = []
    validation_widget = SimpleNamespace(update=validation_messages.append, display=None)
    input_widget = SimpleNamespace(text="Draft comment", load_text=load_calls.append)

    def fake_query_one(selector: str, *_args: object) -> object:
        if selector == "#comment-reply-input":
            return input_widget
        if selector == "#comment-reply-validation":
            return validation_widget
        raise AssertionError(f"unexpected selector: {selector!r}")

    monkeypatch.setattr(composer, "query_one", fake_query_one)
    monkeypatch.setattr(composer, "focus_editor", lambda: focus_calls.append("focus"))
    monkeypatch.setattr(
        composer,
        "_edit_draft_in_external_editor",
        lambda _draft: (_ for _ in ()).throw(ExternalEditorError("Unable to launch external editor.")),
    )
    composer._is_open = True

    composer.action_edit_in_external_editor()

    assert validation_messages == ["", "Unable to launch external editor."]
    assert validation_widget.display is True
    assert load_calls == []
    assert focus_calls == ["focus"]


def test_comment_reply_composer_action_edit_in_external_editor_ignores_closed_or_pending_state() -> None:
    composer = CommentReplyComposer()

    composer.action_edit_in_external_editor()
    composer._is_open = True
    composer._is_submitting = True
    composer.action_edit_in_external_editor()


@pytest.mark.asyncio
async def test_comment_reply_composer_renders_inside_ticket_detail() -> None:
    app = TicketDetailHarness(make_ticket(title="Broken scanner"))

    async with app.run_test() as pilot:
        await pilot.pause()

        composer = app.screen.query_one("#comment-reply-composer", CommentReplyComposer)
        editor = composer.query_one("#comment-reply-input", TextArea)
        submit_button = composer.query_one("#comment-reply-submit", Button)
        cancel_button = composer.query_one("#comment-reply-cancel", Button)
        validation = composer.query_one("#comment-reply-validation", Static)
        actions = composer.query_one("#comment-reply-actions")

        assert composer.query_one("#comment-reply-title", Static).render() == "Add comment"
        assert validation.render() == ""
        assert validation.display is False
        assert editor.text == ""
        assert composer.styles.padding.top == 0
        assert composer.styles.padding.bottom == 0
        assert editor.styles.margin.top == 0
        assert editor.styles.margin.bottom == 0
        assert editor.styles.padding.left == 0
        assert editor.styles.padding.right == 0
        assert editor.styles.height is not None
        assert editor.styles.height.cells == 10
        assert actions.styles.margin.top == 0
        assert submit_button.styles.min_width is not None
        assert submit_button.styles.min_width.cells == 0
        assert cancel_button.styles.min_width is not None
        assert cancel_button.styles.min_width.cells == 0
        assert str(composer.query_one("#comment-reply-attach", Button).label) == "Attach (Ctrl+A)"
        assert str(composer.query_one("#comment-reply-remove", Button).label) == "Remove (Ctrl+D)"
        assert composer.query_one("#comment-reply-hint", Static).render() == (
            "Recent activity stays visible while you compose. Ctrl+A stages a file, Ctrl+D removes one, Ctrl+E opens $EDITOR, and Enter inserts a newline."
        )


@pytest.mark.asyncio
async def test_comment_reply_text_area_actions_delegate_to_parent_composer() -> None:
    app = TicketDetailHarness(make_ticket(title="Broken scanner"))

    async with app.run_test() as pilot:
        await pilot.pause()

        composer = app.screen.query_one("#comment-reply-composer", CommentReplyComposer)
        editor = composer.query_one("#comment-reply-input", CommentReplyTextArea)
        calls: list[str] = []

        composer.action_submit = lambda: calls.append("submit")  # type: ignore[method-assign]
        composer.action_cancel = lambda: calls.append("cancel")  # type: ignore[method-assign]
        composer.action_edit_in_external_editor = lambda: calls.append("edit")  # type: ignore[method-assign]
        composer.action_request_attachment_path = lambda: calls.append("attach")  # type: ignore[method-assign]
        composer.action_request_attachment_removal = lambda: calls.append("remove")  # type: ignore[method-assign]

        editor.action_submit_reply()
        editor.action_request_attachment_path()
        editor.action_request_attachment_removal()
        editor.action_edit_in_external_editor()
        editor.action_cancel_reply()

        assert calls == ["submit", "attach", "remove", "edit", "cancel"]
