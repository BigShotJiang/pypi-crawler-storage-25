from pathlib import Path
from types import SimpleNamespace
from typing import Any, cast

import pytest
from textual import events
from textual.app import App, ComposeResult
from textual.screen import Screen
from textual.widgets import Input, ListView

from daktela_paleo.screens.ticket_detail.widgets.detail_pane import ActivityLink
from daktela_paleo.screens.ticket_detail.widgets.modals import (
    ActivityLinkList,
    ActivityLinkListItem,
    ActivityLinkPickerModal,
    AttachmentDestinationPickerModal,
    CommentAttachmentList,
    CommentAttachmentListItem,
    CommentAttachmentPathPickerModal,
    CommentAttachmentRemovalModal,
    UnsavedChangesModal,
)


def make_activity_link(
    url: str = "https://example.test/alpha",
    *,
    label: str | None = None,
) -> ActivityLink:
    return ActivityLink(url=url, label=label)


def make_attachment_destination_modal() -> AttachmentDestinationPickerModal:
    return cast(AttachmentDestinationPickerModal, object.__new__(AttachmentDestinationPickerModal))


def make_comment_attachment_path_modal() -> CommentAttachmentPathPickerModal:
    return cast(CommentAttachmentPathPickerModal, object.__new__(CommentAttachmentPathPickerModal))


class ModalHarness(App[None]):
    def __init__(self, modal: Screen[Any]) -> None:
        super().__init__()
        self._modal = modal

    def compose(self) -> ComposeResult:
        return
        yield

    def on_mount(self) -> None:
        self.push_screen(self._modal)


def test_unsaved_changes_modal_on_key_routes_discard_and_cancel_actions() -> None:
    modal = UnsavedChangesModal()
    calls: list[str] = []

    modal.action_save = lambda: calls.append("save")  # type: ignore[method-assign]
    modal.action_discard = lambda: calls.append("discard")  # type: ignore[method-assign]
    modal.action_cancel = lambda: calls.append("cancel")  # type: ignore[method-assign]

    save_event = cast(events.Key, SimpleNamespace(key="s", stop=lambda: calls.append("stop-s")))
    modal.on_key(save_event)

    discard_event = cast(events.Key, SimpleNamespace(key="c", stop=lambda: calls.append("stop-c")))
    modal.on_key(discard_event)

    cancel_event = cast(
        events.Key,
        SimpleNamespace(key="escape", stop=lambda: calls.append("stop-escape")),
    )
    modal.on_key(cancel_event)

    assert calls == [
        "stop-s",
        "save",
        "stop-c",
        "discard",
        "stop-escape",
        "cancel",
    ]


def test_unsaved_changes_modal_on_click_routes_discard_and_cancel_actions(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    modal = UnsavedChangesModal()
    save_widget = object()
    discard_widget = object()
    cancel_widget = object()
    calls: list[str] = []

    def fake_query_one(selector: str, *args: object) -> object:
        if selector == "#unsaved-changes-option-save":
            return save_widget
        if selector == "#unsaved-changes-option-discard":
            return discard_widget
        if selector == "#unsaved-changes-option-cancel":
            return cancel_widget
        raise AssertionError(f"unexpected selector: {selector!r}")

    monkeypatch.setattr(modal, "query_one", fake_query_one)
    modal.action_discard = lambda: calls.append("discard")  # type: ignore[method-assign]
    modal.action_cancel = lambda: calls.append("cancel")  # type: ignore[method-assign]

    discard_event = cast(
        events.Click,
        SimpleNamespace(
            widget=discard_widget,
            stop=lambda: calls.append("stop-discard"),
        ),
    )
    modal.on_click(discard_event)

    cancel_event = cast(
        events.Click,
        SimpleNamespace(
            widget=cancel_widget,
            stop=lambda: calls.append("stop-cancel"),
        ),
    )
    modal.on_click(cancel_event)

    assert calls == ["stop-discard", "discard", "stop-cancel", "cancel"]


def test_activity_link_list_selected_posts_link_activated_message() -> None:
    link = make_activity_link()
    link_list = ActivityLinkList([link])
    item = ActivityLinkListItem(link)
    posted_messages: list[ActivityLinkList.LinkActivated] = []

    link_list.post_message = posted_messages.append  # type: ignore[method-assign]
    link_list.on_list_view_selected(
        cast(ListView.Selected, SimpleNamespace(list_view=link_list, item=item))
    )

    assert len(posted_messages) == 1
    assert posted_messages[0].control is link_list
    assert posted_messages[0].link == link


def test_activity_link_list_item_uses_display_label_when_present() -> None:
    item = ActivityLinkListItem(
        make_activity_link(
            "https://example.test/alpha?accessToken=secret",
            label="Image: Scan",
        )
    )

    assert item.display_label == "Image: Scan"


def test_activity_link_list_ignores_selected_event_from_other_list() -> None:
    link = make_activity_link()
    link_list = ActivityLinkList([link])
    posted_messages: list[ActivityLinkList.LinkActivated] = []

    link_list.post_message = posted_messages.append  # type: ignore[method-assign]
    link_list.on_list_view_selected(
        cast(ListView.Selected, SimpleNamespace(list_view=ListView(), item=ActivityLinkListItem(link)))
    )

    assert posted_messages == []


def test_activity_link_list_selected_link_returns_highlighted_link(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    link = make_activity_link()
    link_list = ActivityLinkList([link])
    item = ActivityLinkListItem(link)

    monkeypatch.setattr(ActivityLinkList, "highlighted_child", property(lambda self: item))

    assert link_list.selected_link == link


def test_activity_link_list_selected_link_returns_none_without_highlighted_link(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    link_list = ActivityLinkList([make_activity_link()])

    monkeypatch.setattr(ActivityLinkList, "highlighted_child", property(lambda self: None))

    assert link_list.selected_link is None


def test_activity_link_picker_modal_on_key_routes_activate_and_cancel_actions() -> None:
    modal = ActivityLinkPickerModal([make_activity_link()])
    calls: list[str] = []

    modal.action_activate = lambda: calls.append("activate")  # type: ignore[method-assign]
    modal.action_copy_link = lambda: calls.append("copy")  # type: ignore[method-assign]
    modal.action_cancel = lambda: calls.append("cancel")  # type: ignore[method-assign]

    enter_event = cast(events.Key, SimpleNamespace(key="enter", stop=lambda: calls.append("stop-enter")))
    modal.on_key(enter_event)

    escape_event = cast(
        events.Key,
        SimpleNamespace(key="escape", stop=lambda: calls.append("stop-escape")),
    )
    modal.on_key(escape_event)

    y_event = cast(events.Key, SimpleNamespace(key="y", stop=lambda: calls.append("stop-y")))
    modal.on_key(y_event)

    q_event = cast(events.Key, SimpleNamespace(key="q", stop=lambda: calls.append("stop-q")))
    modal.on_key(q_event)

    assert calls == [
        "stop-enter",
        "activate",
        "stop-escape",
        "cancel",
        "stop-y",
        "copy",
        "stop-q",
        "cancel",
    ]


def test_activity_link_picker_modal_link_activated_dismisses_selected_link(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    link = make_activity_link()
    modal = ActivityLinkPickerModal([link])
    dismissed: list[ActivityLink | None] = []

    monkeypatch.setattr(modal, "dismiss", dismissed.append)

    modal.on_activity_link_list_link_activated(
        ActivityLinkList.LinkActivated(
            ActivityLinkList([link]),
            link,
        )
    )

    assert dismissed == [link]


def test_activity_link_picker_modal_action_cancel_dismisses_none(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    modal = ActivityLinkPickerModal([make_activity_link()])
    dismissed: list[ActivityLink | None] = []

    monkeypatch.setattr(modal, "dismiss", dismissed.append)

    modal.action_cancel()

    assert dismissed == [None]


def test_activity_link_picker_modal_action_copy_link_updates_clipboard_and_status(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    link = make_activity_link()
    modal = ActivityLinkPickerModal([link])
    copied_values: list[str] = []
    status_updates: list[str] = []
    link_list = SimpleNamespace(selected_link=link)
    status_widget = SimpleNamespace(update=status_updates.append)

    def fake_query_one(selector: str, *_args: object) -> object:
        if selector == "#activity-link-picker-list":
            return link_list
        if selector == "#activity-link-picker-status":
            return status_widget
        raise AssertionError(f"unexpected selector: {selector!r}")

    monkeypatch.setattr(modal, "query_one", fake_query_one)
    monkeypatch.setattr(
        ActivityLinkPickerModal,
        "app",
        property(lambda self: SimpleNamespace(copy_to_clipboard=copied_values.append)),
    )

    modal.action_copy_link()

    assert copied_values == [link.url]
    assert status_updates == ["Copied link to clipboard."]


def test_comment_attachment_list_selected_posts_attachment_activated_message() -> None:
    path = Path("/tmp/report.txt")
    attachment_list = CommentAttachmentList([path])
    item = CommentAttachmentListItem(path)
    posted_messages: list[CommentAttachmentList.AttachmentActivated] = []

    attachment_list.post_message = posted_messages.append  # type: ignore[method-assign]
    attachment_list.on_list_view_selected(
        cast(ListView.Selected, SimpleNamespace(list_view=attachment_list, item=item))
    )

    assert len(posted_messages) == 1
    assert posted_messages[0].control is attachment_list
    assert posted_messages[0].path == path


def test_comment_attachment_list_action_activate_selects_cursor() -> None:
    attachment_list = CommentAttachmentList([Path("/tmp/report.txt")])
    calls: list[str] = []

    attachment_list.action_select_cursor = lambda: calls.append("select")  # type: ignore[method-assign]

    attachment_list.action_activate()

    assert calls == ["select"]


def test_comment_attachment_list_ignores_selected_event_from_other_list() -> None:
    path = Path("/tmp/report.txt")
    attachment_list = CommentAttachmentList([path])
    posted_messages: list[CommentAttachmentList.AttachmentActivated] = []

    attachment_list.post_message = posted_messages.append  # type: ignore[method-assign]
    attachment_list.on_list_view_selected(
        cast(ListView.Selected, SimpleNamespace(list_view=ListView(), item=CommentAttachmentListItem(path)))
    )

    assert posted_messages == []


def test_comment_attachment_list_selected_path_returns_none_without_highlighted_item(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    attachment_list = CommentAttachmentList([Path("/tmp/report.txt")])

    monkeypatch.setattr(CommentAttachmentList, "highlighted_child", property(lambda self: None))

    assert attachment_list.selected_path is None


def test_comment_attachment_path_picker_modal_rejects_missing_path(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    modal = make_comment_attachment_path_modal()
    status_updates: list[str] = []
    input_widget = SimpleNamespace(value="~/missing.txt")
    status_widget = SimpleNamespace(update=status_updates.append)

    def fake_query_one(selector: str, *_args: object) -> object:
        if selector == "#comment-attachment-path-picker-input":
            return input_widget
        if selector == "#comment-attachment-path-picker-status":
            return status_widget
        raise AssertionError(f"unexpected selector: {selector!r}")

    monkeypatch.setattr(modal, "query_one", fake_query_one)
    monkeypatch.setattr(
        modal,
        "dismiss",
        lambda value: (_ for _ in ()).throw(
            AssertionError(f"dismiss should not be called: {value!r}")
        ),
    )

    modal.action_activate()

    assert status_updates == ["Attachment path does not exist."]


def test_comment_attachment_path_picker_modal_renders_and_mount_focuses_input(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    modal = CommentAttachmentPathPickerModal("~/Downloads/report.txt")
    input_widget = SimpleNamespace(focus=lambda: focus_calls.append("focus"))
    focus_calls: list[str] = []

    monkeypatch.setattr(modal, "query_one", lambda _selector, *_args: input_widget)
    modal.on_mount()

    assert focus_calls == ["focus"]


@pytest.mark.asyncio
async def test_comment_attachment_path_picker_modal_renders_inside_app() -> None:
    app = ModalHarness(CommentAttachmentPathPickerModal("~/Downloads/report.txt"))

    async with app.run_test() as pilot:
        await pilot.pause()

        modal = cast(CommentAttachmentPathPickerModal, app.screen)
        assert modal.query_one("#comment-attachment-path-picker-title").render() == "Attach File"
        assert modal.query_one("#comment-attachment-path-picker-input", Input).value == "~/Downloads/report.txt"


def test_comment_attachment_path_picker_modal_on_key_and_input_submit_route_actions(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    modal = make_comment_attachment_path_modal()
    calls: list[str] = []
    input_widget = cast(Input, object())

    monkeypatch.setattr(modal, "action_activate", lambda: calls.append("activate"))
    monkeypatch.setattr(modal, "action_cancel", lambda: calls.append("cancel"))
    monkeypatch.setattr(modal, "query_one", lambda _selector, *_args: input_widget)

    modal.on_key(cast(events.Key, SimpleNamespace(key="escape", stop=lambda: calls.append("stop-escape"))))
    modal.on_input_submitted(Input.Submitted(input_widget, "~/Downloads/report.txt"))

    assert calls == ["stop-escape", "cancel", "activate"]


def test_comment_attachment_path_picker_modal_rejects_blank_directory_and_unreadable_paths(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    modal = make_comment_attachment_path_modal()
    status_updates: list[str] = []
    blocked_file = tmp_path / "blocked.txt"
    blocked_file.write_text("payload", encoding="utf-8")
    input_widget = SimpleNamespace(value="   ")
    status_widget = SimpleNamespace(update=status_updates.append)

    def fake_query_one(selector: str, *_args: object) -> object:
        if selector == "#comment-attachment-path-picker-input":
            return input_widget
        if selector == "#comment-attachment-path-picker-status":
            return status_widget
        raise AssertionError(f"unexpected selector: {selector!r}")

    monkeypatch.setattr(modal, "query_one", fake_query_one)
    monkeypatch.setattr(
        modal,
        "dismiss",
        lambda value: (_ for _ in ()).throw(
            AssertionError(f"dismiss should not be called: {value!r}")
        ),
    )

    modal.action_activate()
    input_widget.value = str(tmp_path)
    modal.action_activate()
    input_widget.value = str(blocked_file)
    monkeypatch.setattr(Path, "open", lambda self, *_args, **_kwargs: (_ for _ in ()).throw(OSError("boom")))
    modal.action_activate()

    assert status_updates == [
        "Attachment path is required.",
        "Attachment path must point to a file.",
        "Unable to read attachment path: boom",
    ]


def test_comment_attachment_path_picker_modal_dismisses_resolved_file(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    modal = make_comment_attachment_path_modal()
    staged_file = tmp_path / "report.txt"
    staged_file.write_text("payload", encoding="utf-8")
    input_widget = SimpleNamespace(value=str(staged_file))
    status_widget = SimpleNamespace(update=lambda _text: None)
    dismissed: list[Path | None] = []

    def fake_query_one(selector: str, *_args: object) -> object:
        if selector == "#comment-attachment-path-picker-input":
            return input_widget
        if selector == "#comment-attachment-path-picker-status":
            return status_widget
        raise AssertionError(f"unexpected selector: {selector!r}")

    monkeypatch.setattr(modal, "query_one", fake_query_one)
    monkeypatch.setattr(modal, "dismiss", dismissed.append)

    modal.action_activate()

    assert dismissed == [staged_file.resolve()]


def test_comment_attachment_path_picker_modal_action_cancel_dismisses_none(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    modal = make_comment_attachment_path_modal()
    dismissed: list[Path | None] = []

    monkeypatch.setattr(modal, "dismiss", dismissed.append)

    modal.action_cancel()

    assert dismissed == [None]


def test_comment_attachment_removal_modal_action_cancel_dismisses_none(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    modal = CommentAttachmentRemovalModal([Path("/tmp/report.txt")])
    dismissed: list[Path | None] = []

    monkeypatch.setattr(modal, "dismiss", dismissed.append)

    modal.action_cancel()

    assert dismissed == [None]


def test_comment_attachment_removal_modal_renders_mounts_and_routes_actions(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    path = Path("/tmp/report.txt")
    modal = CommentAttachmentRemovalModal([path])
    attachment_list = SimpleNamespace(
        focus=lambda: calls.append("focus"),
        action_activate=lambda: calls.append("activate"),
    )
    calls: list[str] = []

    monkeypatch.setattr(modal, "query_one", lambda _selector, *_args: attachment_list)
    monkeypatch.setattr(modal, "dismiss", lambda value: calls.append(f"dismiss:{value}"))

    modal.on_mount()
    modal.on_key(cast(events.Key, SimpleNamespace(key="enter", stop=lambda: calls.append("stop-enter"))))
    modal.on_key(cast(events.Key, SimpleNamespace(key="escape", stop=lambda: calls.append("stop-escape"))))
    modal.on_comment_attachment_list_attachment_activated(
        CommentAttachmentList.AttachmentActivated(CommentAttachmentList([path]), path)
    )

    assert calls == [
        "focus",
        "stop-enter",
        "activate",
        "stop-escape",
        "dismiss:None",
        f"dismiss:{path}",
    ]


@pytest.mark.asyncio
async def test_comment_attachment_removal_modal_renders_inside_app() -> None:
    path = Path("/tmp/report.txt")
    app = ModalHarness(CommentAttachmentRemovalModal([path]))

    async with app.run_test() as pilot:
        await pilot.pause()

        modal = cast(CommentAttachmentRemovalModal, app.screen)
        assert modal.query_one("#comment-attachment-removal-title").render() == "Remove Attachment"
        assert modal.query_one("#comment-attachment-removal-list", CommentAttachmentList).selected_path == path


def test_activity_link_picker_modal_action_copy_link_returns_early_without_selection(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    modal = ActivityLinkPickerModal([make_activity_link()])
    link_list = SimpleNamespace(selected_link=None)

    monkeypatch.setattr(modal, "query_one", lambda selector, *_args: link_list)
    monkeypatch.setattr(
        ActivityLinkPickerModal,
        "app",
        property(
            lambda self: SimpleNamespace(
                copy_to_clipboard=lambda text: (_ for _ in ()).throw(
                    AssertionError("copy_to_clipboard should not be called")
                )
            )
        ),
    )

    modal.action_copy_link()


def test_attachment_destination_picker_modal_on_key_routes_activate_and_cancel_actions() -> None:
    modal = make_attachment_destination_modal()
    calls: list[str] = []

    modal.action_cancel = lambda: calls.append("cancel")  # type: ignore[method-assign]

    q_event = cast(events.Key, SimpleNamespace(key="q", stop=lambda: calls.append("stop-q")))
    modal.on_key(q_event)

    assert calls == ["stop-q", "cancel"]


def test_attachment_destination_picker_modal_action_activate_dismisses_expanded_path(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    modal = make_attachment_destination_modal()
    dismissed: list[Path | None] = []
    input_widget = SimpleNamespace(value=str(tmp_path / "../downloads"))

    monkeypatch.setattr(modal, "dismiss", dismissed.append)
    monkeypatch.setattr(
        modal,
        "query_one",
        lambda _selector, *_args: input_widget,
    )

    modal.action_activate()

    assert dismissed == [(tmp_path / "../downloads").expanduser()]


def test_attachment_destination_picker_modal_action_activate_requires_non_empty_path(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    modal = make_attachment_destination_modal()
    status_updates: list[str] = []
    input_widget = SimpleNamespace(value="   ")
    status_widget = SimpleNamespace(update=status_updates.append)

    def fake_query_one(selector: str, *_args: object) -> object:
        if selector == "#attachment-destination-picker-input":
            return input_widget
        if selector == "#attachment-destination-picker-status":
            return status_widget
        raise AssertionError(f"unexpected selector: {selector!r}")

    monkeypatch.setattr(modal, "query_one", fake_query_one)
    monkeypatch.setattr(
        modal,
        "dismiss",
        lambda value: (_ for _ in ()).throw(
            AssertionError(f"dismiss should not be called: {value!r}")
        ),
    )

    modal.action_activate()

    assert status_updates == ["Destination path is required."]


def test_attachment_destination_picker_modal_input_submit_activates_current_path(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    modal = make_attachment_destination_modal()
    calls: list[str] = []
    input_widget = cast(Input, object())

    monkeypatch.setattr(modal, "action_activate", lambda: calls.append("activate"))
    monkeypatch.setattr(modal, "query_one", lambda _selector, *_args: input_widget)

    modal.on_input_submitted(Input.Submitted(input_widget, "~/Downloads"))

    assert calls == ["activate"]


def test_attachment_destination_picker_modal_action_cancel_dismisses_none(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    modal = make_attachment_destination_modal()
    dismissed: list[Path | None] = []

    monkeypatch.setattr(modal, "dismiss", dismissed.append)

    modal.action_cancel()

    assert dismissed == [None]
