from types import SimpleNamespace
from typing import cast

import pytest
from textual.containers import Horizontal, Vertical
from textual.binding import Binding
from textual.css.query import NoMatches
from textual.widgets import DataTable
from textual.widgets import Input, Static

from daktela_paleo.models import AppState, TicketPagination
from daktela_paleo.screens.main.screen import TicketList, TicketSearchInput
from daktela_paleo.screens.main.widgets.tickets import TicketTable
from daktela_paleo.screens.main.widgets.views import TicketViewsList
from tests.support import TicketListHarness, make_demo_state, make_ticket, make_ticket_view


@pytest.mark.asyncio
async def test_ticket_list_syncs_ticket_loading_state_to_table() -> None:
    app = TicketListHarness(AppState(), ticket_loading=True)

    async with app.run_test() as pilot:
        await pilot.pause()
        ticket_list = app.query_one(TicketList)
        ticket_table = app.query_one(TicketTable)

        assert ticket_table.loading is True

        ticket_list.set_ticket_loading(False)
        await pilot.pause()

        assert ticket_table.loading is False


@pytest.mark.asyncio
async def test_ticket_list_posts_refresh_requested_message() -> None:
    app = TicketListHarness(make_demo_state())

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("r")
        await pilot.pause()

        assert app.refresh_requested is True


@pytest.mark.asyncio
async def test_ticket_list_updates_focus_styles_and_split_layout() -> None:
    app = TicketListHarness(make_demo_state())

    async with app.run_test(size=(120, 24)) as pilot:
        await pilot.pause()

        browser = app.query_one(TicketList)
        views_title = app.query_one("#views-title", Static)
        tickets_title = app.query_one("#tickets-title", Static)
        views_pane = app.query_one("#views-pane", Vertical)
        tickets_pane = app.query_one("#tickets-pane", Vertical)

        assert views_title.has_class("-focused") is True
        assert tickets_title.has_class("-focused") is False

        initial_views_width = views_pane.region.width
        initial_tickets_width = tickets_pane.region.width

        browser.focus_tickets()
        browser.split_percent = 75.0
        await pilot.pause()

        assert views_title.has_class("-focused") is False
        assert tickets_title.has_class("-focused") is True
        assert views_pane.region.width > initial_views_width
        assert tickets_pane.region.width < initial_tickets_width


@pytest.mark.asyncio
async def test_ticket_list_shows_ticket_page_index_in_pane_title_when_paginated() -> None:
    view = make_ticket_view("My Open")
    app = TicketListHarness(
        AppState(
            tickets=[make_ticket(title="Broken scanner", name=2001)],
            views=[view],
            active_view=view,
            ticket_pagination=TicketPagination(current_page=2, total_pages=4, total_tickets=7),
        )
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        assert app.query_one("#tickets-title", Static).render() == "Tickets 2/4"


@pytest.mark.asyncio
async def test_ticket_list_opens_and_closes_ticket_search_prompt_from_ticket_table() -> None:
    app = TicketListHarness(make_demo_state())

    async with app.run_test() as pilot:
        await pilot.pause()

        browser = app.query_one(TicketList)
        tickets_table = app.query_one(TicketTable)
        tickets_title = app.query_one("#tickets-title", Static)
        search_bar = app.query_one("#ticket-search-bar", Horizontal)
        search_input = app.query_one("#ticket-search-input", Input)

        browser.focus_tickets()
        await pilot.pause()
        await pilot.press("/")
        await pilot.pause()

        assert search_bar.has_class("-active") is True
        assert app.focused is search_input
        assert tickets_title.has_class("-focused") is True

        await pilot.press("escape")
        await pilot.pause()

        assert search_bar.has_class("-active") is False
        assert app.focused is tickets_table
        assert tickets_title.has_class("-focused") is True


@pytest.mark.asyncio
async def test_ticket_list_search_prompt_applies_query_and_returns_focus_to_table() -> None:
    view = make_ticket_view("My Open")
    app = TicketListHarness(
        AppState(
            tickets=[
                make_ticket(title="Broken scanner", name=2001),
                make_ticket(title="Delivery blocked", name=2002),
                make_ticket(title="Scanner offline", name=2003),
            ],
            views=[view],
            active_view=view,
        )
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        browser = app.query_one(TicketList)
        tickets_table = app.query_one(TicketTable)
        search_bar = app.query_one("#ticket-search-bar", Horizontal)

        browser.focus_tickets()
        await pilot.pause()
        await pilot.press("/")
        await pilot.pause()
        await pilot.press("S", "c", "a", "n", "n", "e", "r", "enter")
        await pilot.pause()

        assert search_bar.has_class("-active") is False
        assert app.focused is tickets_table
        assert tickets_table.cursor_row == 2
        assert tickets_table._search_match_rows == [2]


def test_ticket_list_focus_and_blur_schedule_focus_refresh() -> None:
    browser = TicketList(make_demo_state())
    scheduled: list[object] = []

    def capture(callback: object) -> None:
        scheduled.append(callback)

    browser.call_after_refresh = capture  # type: ignore[method-assign]

    browser.on_focus()
    browser.on_blur()

    assert scheduled == [browser._refresh_focus_styles, browser._refresh_focus_styles]


def test_ticket_list_refresh_requested_message_exposes_control() -> None:
    browser = TicketList(make_demo_state())

    assert browser.RefreshRequested(browser).control is browser


def test_ticket_search_input_cancelled_message_exposes_control() -> None:
    search_input = TicketSearchInput()

    assert search_input.SearchCancelled(search_input).control is search_input


def test_ticket_list_on_input_submitted_ignores_non_search_input(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    browser = TicketList(make_demo_state())
    search_input = object()
    other_input = object()

    monkeypatch.setattr(browser, "query_one", lambda selector, *args: search_input)

    browser.on_input_submitted(cast(Input.Submitted, SimpleNamespace(input=other_input)))


def test_ticket_list_open_in_browser_requested_message_exposes_control() -> None:
    browser = TicketList(make_demo_state())
    view = make_ticket_view("My Open", name="my_open")

    assert browser.OpenInBrowserRequested(browser, view).control is browser


def test_ticket_list_sync_from_state_returns_early_when_unmounted(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    browser = TicketList(make_demo_state())
    new_state = AppState(
        tickets=[make_ticket(title="VIP queue", name=3001)],
        views=[make_ticket_view("VIP only")],
    )

    def fail_if_called(*args: object, **kwargs: object) -> None:
        raise AssertionError("query_one should not be used before mount")

    monkeypatch.setattr(browser, "query_one", fail_if_called)

    browser.sync_from_state(new_state)

    assert browser._app_state == new_state


def test_ticket_list_apply_split_layout_returns_early_when_too_narrow(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    browser = TicketList(make_demo_state())
    panes = SimpleNamespace(size=SimpleNamespace(width=2))

    def fake_query_one(selector: object, *args: object) -> object:
        if selector == "#panes":
            return panes
        raise AssertionError("pane widgets should not be queried for a narrow layout")

    monkeypatch.setattr(browser, "query_one", fake_query_one)

    browser._apply_split_layout()


def test_ticket_list_apply_split_layout_defaults_to_twenty_percent(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    browser = TicketList(make_demo_state())
    panes = SimpleNamespace(size=SimpleNamespace(width=101))
    views_pane = SimpleNamespace(styles=SimpleNamespace(width=None))
    tickets_pane = SimpleNamespace(styles=SimpleNamespace(width=None))

    def fake_query_one(selector: object, *args: object) -> object:
        if selector == "#panes":
            return panes
        if selector == "#views-pane":
            return views_pane
        if selector == "#tickets-pane":
            return tickets_pane
        raise AssertionError(f"unexpected selector: {selector!r}")

    monkeypatch.setattr(browser, "query_one", fake_query_one)

    browser._apply_split_layout()

    assert views_pane.styles.width == 20
    assert tickets_pane.styles.width == 80


def test_ticket_list_apply_split_layout_uses_compact_minimums(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    browser = TicketList(make_demo_state())
    browser.split_percent = 5.0
    panes = SimpleNamespace(size=SimpleNamespace(width=40))
    views_pane = SimpleNamespace(styles=SimpleNamespace(width=None))
    tickets_pane = SimpleNamespace(styles=SimpleNamespace(width=None))

    def fake_query_one(selector: object, *args: object) -> object:
        if selector == "#panes":
            return panes
        if selector == "#views-pane":
            return views_pane
        if selector == "#tickets-pane":
            return tickets_pane
        raise AssertionError(f"unexpected selector: {selector!r}")

    monkeypatch.setattr(browser, "query_one", fake_query_one)

    browser._apply_split_layout()

    assert views_pane.styles.width == 2
    assert tickets_pane.styles.width == 37


def test_ticket_list_refresh_focus_styles_ignores_missing_widgets(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    browser = TicketList(make_demo_state())

    def raise_no_matches(*args: object, **kwargs: object) -> None:
        raise NoMatches("browser children not mounted")

    monkeypatch.setattr(browser, "query_one", raise_no_matches)

    browser._refresh_focus_styles()


def test_ticket_list_set_ticket_loading_returns_early_when_unmounted(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    browser = TicketList(make_demo_state())

    def fail_if_called(*args: object, **kwargs: object) -> None:
        raise AssertionError("query_one should not be called before mount")

    monkeypatch.setattr(browser, "query_one", fail_if_called)

    browser.set_ticket_loading(True)

    assert browser._ticket_loading is True


def test_main_screen_focusable_widgets_bind_q_to_quit() -> None:
    def binding_key(binding: object) -> str:
        if isinstance(binding, Binding):
            return binding.key
        return binding[0]  # type: ignore[index]

    views_keys = [binding_key(binding) for binding in TicketViewsList.BINDINGS]
    ticket_keys = [binding_key(binding) for binding in TicketTable.BINDINGS]

    assert "q" in views_keys
    assert "q" in ticket_keys


@pytest.mark.asyncio
async def test_ticket_list_b_posts_open_in_browser_request_from_views() -> None:
    view = make_ticket_view("My Open", name="my_open")
    app = TicketListHarness(AppState(views=[view], active_view=view))

    async with app.run_test() as pilot:
        await pilot.pause()

        assert app.focused is app.query_one(TicketViewsList)

        await pilot.press("b")
        await pilot.pause()

        assert app.view_open_requested == view


@pytest.mark.asyncio
async def test_ticket_list_b_posts_open_in_browser_request_from_tickets() -> None:
    view = make_ticket_view("Delivery", name="delivery")
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketListHarness(AppState(views=[view], tickets=[ticket], active_view=view))

    async with app.run_test() as pilot:
        await pilot.pause()

        browser = app.query_one(TicketList)
        browser.focus_tickets()
        await pilot.pause()

        assert isinstance(app.focused, DataTable)

        await pilot.press("b")
        await pilot.pause()

        assert app.view_open_requested == view
        assert isinstance(app.focused, DataTable)
