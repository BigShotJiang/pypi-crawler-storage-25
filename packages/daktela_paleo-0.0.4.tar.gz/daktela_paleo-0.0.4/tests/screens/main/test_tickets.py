from datetime import datetime, timedelta
from types import SimpleNamespace
from typing import cast

import pytest
from rich.text import Text
from textual import events
from textual.widgets import DataTable
from textual.widgets.data_table import ColumnKey

from daktela_paleo.models import TicketPagination, TicketPriority, TicketStage
from daktela_paleo.screens.main.widgets.tickets import TicketTable
from tests.support import (
    TicketTableHarness,
    make_ticket,
    make_ticket_batch,
    ticket_row_renderables,
    ticket_rows,
)


@pytest.mark.asyncio
async def test_ticket_table_renders_rows_and_syncs_cursor() -> None:
    first_ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        contact="vip_client",
        user="op_1",
        statuses={
            "status_new": "New",
            "status_vip": "VIP",
        },
    )
    second_ticket = make_ticket(
        title="Delivery blocked",
        name=2002,
        contact="warehouse_7",
        user="op_2",
        stage=TicketStage.WAIT,
        priority=TicketPriority.MEDIUM,
    )
    app = TicketTableHarness([first_ticket, second_ticket], active_ticket=second_ticket)

    async with app.run_test() as pilot:
        await pilot.pause()

        table = app.query_one(TicketTable)
        assert [column.label.plain for column in table.ordered_columns] == [
            "",
            "#",
            "Title",
            "Priority",
            "Category",
            "Statuses",
            "Contact",
            "Stage",
            "User",
            "Edited",
        ]
        assert ticket_rows(table) == [
            ["1", "2001", "Broken scanner", "1", "category_123456", "New, VIP", "vip_client", "Open", "op_1", "-"],
            ["2", "2002", "Delivery blocked", "2", "category_123456", "-", "warehouse_7", "Waiting", "op_2", "-"],
        ]
        assert table.cursor_row == 1


@pytest.mark.asyncio
async def test_ticket_table_renders_configured_columns_in_normalized_order() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        user="operator_1",
    )
    app = TicketTableHarness(
        [ticket],
        column_keys=["edited", "priority", "user.title"],
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        table = app.query_one(TicketTable)

        assert [column.label.plain for column in table.ordered_columns] == [
            "",
            "#",
            "Title",
            "Edited",
            "Priority",
            "User",
        ]
        assert ticket_rows(table) == [
            ["1", "2001", "Broken scanner", "-", "1", "operator_1"]
        ]


@pytest.mark.asyncio
async def test_ticket_table_renders_deadline_and_editor_columns() -> None:
    ticket = make_ticket(
        title="Broken scanner",
        name=2001,
        user="operator_1",
        edited_by="editor_2",
        sla_deadtime=datetime.now() - timedelta(days=5),
    )
    app = TicketTableHarness(
        [ticket],
        column_keys=["sla_deadtime", "edited_by"],
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        table = app.query_one(TicketTable)

        assert [column.label.plain for column in table.ordered_columns] == [
            "",
            "#",
            "Title",
            "Deadline",
            "Edited By",
        ]
        assert ticket_rows(table) == [
            ["1", "2001", "Broken scanner", "-5d", "editor_2"]
        ]


@pytest.mark.asyncio
async def test_ticket_table_filters_duplicate_and_unsupported_column_keys() -> None:
    app = TicketTableHarness(
        [make_ticket(title="Broken scanner", name=2001, user="operator_1")],
        column_keys=["user.title", "unsupported", "user.title", "title"],
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        table = app.query_one(TicketTable)

        assert [column.label.plain for column in table.ordered_columns] == [
            "",
            "#",
            "Title",
            "User",
        ]
        assert ticket_rows(table) == [
            ["1", "2001", "Broken scanner", "operator_1"]
        ]


@pytest.mark.asyncio
async def test_ticket_table_falls_back_to_default_columns_when_config_has_no_supported_keys() -> None:
    app = TicketTableHarness(
        [make_ticket(title="Broken scanner", name=2001)],
        column_keys=["unsupported"],
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        table = app.query_one(TicketTable)

        assert [column.label.plain for column in table.ordered_columns] == [
            "",
            "#",
            "Title",
            "Priority",
            "Category",
            "Statuses",
            "Contact",
            "Stage",
            "User",
            "Edited",
        ]


@pytest.mark.asyncio
async def test_ticket_table_re_renders_when_only_column_keys_change() -> None:
    tickets = [make_ticket(title="Broken scanner", name=2001, user="operator_1")]
    app = TicketTableHarness(tickets, column_keys=["priority"])

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        table.set_tickets(tickets, active_ticket=None, column_keys=["user.title"])
        await pilot.pause()

        assert [column.label.plain for column in table.ordered_columns] == [
            "",
            "#",
            "Title",
            "User",
        ]
        assert ticket_rows(table) == [
            ["1", "2001", "Broken scanner", "operator_1"]
        ]


def test_ticket_table_ticket_cell_raises_for_unsupported_column_key() -> None:
    with pytest.raises(KeyError):
        TicketTable._ticket_cell(make_ticket(title="Broken scanner", name=2001), "unsupported")


@pytest.mark.asyncio
async def test_ticket_table_truncates_only_titles_longer_than_seventy_five_characters() -> None:
    long_title = "L" * 80
    exact_limit_title = "E" * TicketTable.TITLE_TRUNCATE_LIMIT
    short_title = "Short title"
    app = TicketTableHarness(
        [
            make_ticket(title=long_title, name=2001),
            make_ticket(title=exact_limit_title, name=2002),
            make_ticket(title=short_title, name=2003),
        ]
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        table = app.query_one(TicketTable)
        rows = ticket_rows(table)

        assert rows[0][2] == ("L" * TicketTable.TITLE_TRUNCATE_LIMIT) + "..."
        assert rows[1][2] == exact_limit_title
        assert rows[2][2] == short_title


@pytest.mark.asyncio
async def test_ticket_table_posts_ticket_activated_message() -> None:
    first_ticket = make_ticket(title="Broken scanner", name=2001)
    second_ticket = make_ticket(title="Delivery blocked", name=2002)
    app = TicketTableHarness([first_ticket, second_ticket])

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("j", "l")
        await pilot.pause()

        assert app.selected_ticket == second_ticket


@pytest.mark.asyncio
async def test_ticket_table_ctrl_d_posts_next_page_requested_when_available() -> None:
    app = TicketTableHarness(
        [make_ticket(title="Broken scanner", name=2001)],
        pagination=TicketPagination(current_page=1, total_pages=3, total_tickets=3),
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("ctrl+d")
        await pilot.pause()

        assert app.next_page_requested is True
        assert app.previous_page_requested is False


@pytest.mark.asyncio
async def test_ticket_table_ctrl_b_posts_previous_page_requested_when_available() -> None:
    app = TicketTableHarness(
        [make_ticket(title="Broken scanner", name=2001)],
        pagination=TicketPagination(current_page=2, total_pages=3, total_tickets=3),
    )

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("ctrl+b")
        await pilot.pause()

        assert app.previous_page_requested is True
        assert app.next_page_requested is False


@pytest.mark.asyncio
async def test_ticket_table_slash_posts_search_requested_message() -> None:
    app = TicketTableHarness([make_ticket(title="Broken scanner", name=2001)])

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("/")
        await pilot.pause()

        assert app.search_requested is True
        assert app.selected_ticket is None


@pytest.mark.asyncio
async def test_ticket_table_handle_key_requests_search_for_slash_key_events() -> None:
    app = TicketTableHarness([make_ticket(title="Broken scanner", name=2001)])

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)
        stop_calls: list[str] = []

        handled = await table.handle_key(
            cast(
                events.Key,
                SimpleNamespace(key="/", character="/", stop=lambda: stop_calls.append("stop")),
            )
        )
        await pilot.pause()

        assert handled is True
        assert app.search_requested is True
        assert stop_calls == ["stop"]


@pytest.mark.asyncio
async def test_ticket_table_apply_search_highlights_matches_and_posts_status() -> None:
    app = TicketTableHarness(
        [
            make_ticket(title="Broken scanner", name=2001),
            make_ticket(title="Delivery blocked", name=2002, contact="vip_client"),
            make_ticket(title="Dispatch queue", name=2003),
        ]
    )

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        table.apply_search("(?i)scanner|vip")
        await pilot.pause()

        renderables = ticket_row_renderables(table)

        assert table.cursor_row == 0
        assert app.search_status == "/(?i)scanner|vip 1/2"
        assert cast(Text, renderables[0][2]).plain == "Broken scanner"
        assert cast(Text, renderables[0][2]).spans
        assert cast(Text, renderables[1][6]).plain == "vip_client"
        assert cast(Text, renderables[1][6]).spans


@pytest.mark.asyncio
async def test_ticket_table_apply_search_moves_to_next_matching_row_when_needed() -> None:
    app = TicketTableHarness(
        [
            make_ticket(title="Broken scanner", name=2001),
            make_ticket(title="Delivery blocked", name=2002),
            make_ticket(title="Target ticket", name=2003),
        ]
    )

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        table.apply_search("Target")
        await pilot.pause()

        assert table.cursor_row == 2
        assert app.search_status == "/Target 1/1"


@pytest.mark.asyncio
async def test_ticket_table_search_navigation_wraps_for_n_and_shift_n() -> None:
    app = TicketTableHarness(
        [
            make_ticket(title="Target alpha", name=2001),
            make_ticket(title="Delivery blocked", name=2002),
            make_ticket(title="Target beta", name=2003),
        ]
    )

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)
        table.apply_search("Target")
        await pilot.pause()

        await pilot.press("n")
        await pilot.pause()
        assert table.cursor_row == 2
        assert app.search_status == "/Target 2/2"

        await pilot.press("n")
        await pilot.pause()
        assert table.cursor_row == 0
        assert app.search_status == "/Target 1/2"

        await pilot.press("N")
        await pilot.pause()
        assert table.cursor_row == 2
        assert app.search_status == "/Target 2/2"


@pytest.mark.asyncio
async def test_ticket_table_next_search_match_initializes_from_cursor_when_index_is_missing() -> None:
    app = TicketTableHarness(make_ticket_batch(4))

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)
        table._search_match_rows = [1, 3]
        table._search_active_match_index = None

        table.action_next_search_match()
        await pilot.pause()

        assert table.cursor_row == 1
        assert table._search_active_match_index == 0


@pytest.mark.asyncio
async def test_ticket_table_invalid_regex_clears_previous_matches_and_reports_error() -> None:
    app = TicketTableHarness([make_ticket(title="Broken scanner", name=2001)])

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        table.apply_search("scanner")
        await pilot.pause()
        assert app.search_status == "/scanner 1/1"
        assert isinstance(ticket_row_renderables(table)[0][2], Text)

        table.apply_search("[")
        await pilot.pause()

        assert app.search_status is not None
        assert app.search_status.startswith("Invalid regex: ")
        assert table._search_match_rows == []
        assert isinstance(ticket_row_renderables(table)[0][2], str)


@pytest.mark.asyncio
async def test_ticket_table_empty_search_clears_active_matches() -> None:
    app = TicketTableHarness([make_ticket(title="Broken scanner", name=2001)])

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        table.apply_search("scanner")
        await pilot.pause()
        assert app.search_status == "/scanner 1/1"

        table.apply_search("")
        await pilot.pause()

        assert app.search_status is None
        assert table._search_match_rows == []
        assert isinstance(ticket_row_renderables(table)[0][2], str)


@pytest.mark.asyncio
async def test_ticket_table_no_match_search_keeps_cursor_and_reports_feedback() -> None:
    app = TicketTableHarness([make_ticket(title="Broken scanner", name=2001)])

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        table.apply_search("missing")
        await pilot.pause()

        assert table.cursor_row == 0
        assert app.search_status == "No matches: /missing"

        await pilot.press("n")
        await pilot.pause()

        assert table.cursor_row == 0
        assert app.search_status == "No matches: /missing"


@pytest.mark.asyncio
async def test_ticket_table_refresh_clears_search_when_visible_rows_change() -> None:
    tickets = [make_ticket(title="Broken scanner", name=2001)]
    app = TicketTableHarness(tickets)

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        table.apply_search("scanner")
        await pilot.pause()
        assert app.search_status == "/scanner 1/1"

        table.set_tickets([make_ticket(title="Delivery blocked", name=2002)], active_ticket=None)
        await pilot.pause()

        assert app.search_status is None
        assert table._search_match_rows == []
        assert isinstance(ticket_row_renderables(table)[0][2], str)


@pytest.mark.asyncio
async def test_ticket_table_page_change_clears_search_even_when_rows_match() -> None:
    tickets = [make_ticket(title="Broken scanner", name=2001)]
    app = TicketTableHarness(
        tickets,
        pagination=TicketPagination(current_page=1, total_pages=2, total_tickets=2),
    )

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        table.apply_search("scanner")
        await pilot.pause()
        assert app.search_status == "/scanner 1/1"

        table.set_tickets(
            tickets,
            active_ticket=None,
            pagination=TicketPagination(current_page=2, total_pages=2, total_tickets=2),
        )
        await pilot.pause()

        assert app.search_status is None
        assert table._search_match_rows == []


@pytest.mark.asyncio
async def test_ticket_table_ignores_selection_from_other_table_and_invalid_rows() -> None:
    first_ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketTableHarness([first_ticket])

    async with app.run_test() as pilot:
        await pilot.pause()

        table = app.query_one(TicketTable)
        other_table = cast(DataTable, object())

        table.on_data_table_row_selected(
            cast(
                DataTable.RowSelected,
                SimpleNamespace(data_table=other_table, cursor_row=0),
            )
        )
        table.on_data_table_row_selected(
            cast(
                DataTable.RowSelected,
                SimpleNamespace(data_table=table, cursor_row=4),
            )
        )

        assert app.selected_ticket is None


@pytest.mark.asyncio
async def test_ticket_table_messages_expose_control() -> None:
    ticket = make_ticket(title="Broken scanner", name=2001)
    app = TicketTableHarness([ticket])

    async with app.run_test() as pilot:
        await pilot.pause()

        table = app.query_one(TicketTable)

        assert table.TicketActivated(table, ticket).control is table
        assert table.FocusViewsRequested(table).control is table
        assert table.PendingCountChanged(table, 13).control is table
        assert table.NextPageRequested(table).control is table
        assert table.PreviousPageRequested(table).control is table
        assert table.SearchRequested(table).control is table
        assert table.SearchStatusChanged(table, "/scanner 1/1").control is table


def test_ticket_table_match_index_returns_none_when_ticket_is_absent() -> None:
    first_ticket = make_ticket(title="Broken scanner", name=2001)
    second_ticket = make_ticket(title="Delivery blocked", name=2002)

    assert TicketTable._match_index([first_ticket], second_ticket) is None


def test_ticket_table_initial_search_match_index_returns_none_for_empty_matches() -> None:
    table = cast(TicketTable, SimpleNamespace(cursor_row=0))

    assert TicketTable._initial_search_match_index(table, []) is None


def test_ticket_table_initial_search_match_index_wraps_when_cursor_is_past_all_matches() -> None:
    table = cast(TicketTable, SimpleNamespace(cursor_row=5))

    assert TicketTable._initial_search_match_index(table, [1, 3]) == 0


def test_ticket_table_cell_renderable_skips_zero_width_match_spans() -> None:
    table = cast(TicketTable, object.__new__(TicketTable))
    ticket = make_ticket(title="Broken scanner", name=2001)
    table._search_match_spans = {}
    table._search_match_spans[(0, "title")] = [(0, 0)]

    renderable = TicketTable._ticket_cell_renderable(table, ticket, "title", 0)

    assert isinstance(renderable, Text)
    assert renderable.plain == "Broken scanner"
    assert renderable.spans == []


@pytest.mark.asyncio
async def test_ticket_table_renders_hybrid_line_number_gutter_around_cursor() -> None:
    tickets = make_ticket_batch(6)
    app = TicketTableHarness(tickets, active_ticket=tickets[3])

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        gutter = [row[0] for row in ticket_rows(table)]

        assert gutter == ["3", "2", "1", "4", "1", "2"]


@pytest.mark.asyncio
async def test_ticket_table_line_number_gutter_updates_after_plain_navigation() -> None:
    tickets = make_ticket_batch(4)
    app = TicketTableHarness(tickets)

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        await pilot.press("j")
        await pilot.pause()

        assert [row[0] for row in ticket_rows(table)] == ["1", "2", "1", "2"]


@pytest.mark.asyncio
async def test_ticket_table_line_number_gutter_updates_after_counted_navigation() -> None:
    tickets = make_ticket_batch(20)
    app = TicketTableHarness(tickets)

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        await pilot.press("1", "3", "j")
        await pilot.pause()

        renderables = ticket_row_renderables(table)
        assert cast(Text, renderables[0][0]).plain == "13"
        assert cast(Text, renderables[12][0]).plain.strip() == "1"
        assert cast(Text, renderables[13][0]).plain == "14"
        assert cast(Text, renderables[14][0]).plain.strip() == "1"


@pytest.mark.asyncio
async def test_ticket_table_line_number_gutter_uses_dimmed_style_for_non_focused_rows() -> None:
    tickets = make_ticket_batch(3)
    app = TicketTableHarness(tickets, active_ticket=tickets[1])

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        renderables = ticket_row_renderables(table)

        assert cast(Text, renderables[0][0]).style == "#3B4261"
        assert cast(Text, renderables[1][0]).style == "#828BB8"


@pytest.mark.asyncio
async def test_ticket_table_counted_j_moves_cursor_down_by_prefix() -> None:
    tickets = make_ticket_batch(20)
    app = TicketTableHarness(tickets)

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        await pilot.press("1", "3", "j")
        await pilot.pause()

        assert table.cursor_row == 13
        assert app.selected_ticket is None
        assert table._pending_count is None


@pytest.mark.asyncio
async def test_ticket_table_counted_k_moves_cursor_up_by_prefix() -> None:
    tickets = make_ticket_batch(20)
    app = TicketTableHarness(tickets, active_ticket=tickets[15])

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        await pilot.press("1", "0", "k")
        await pilot.pause()

        assert table.cursor_row == 5
        assert table._pending_count is None


@pytest.mark.asyncio
async def test_ticket_table_counted_j_clamps_at_last_row() -> None:
    tickets = make_ticket_batch(5)
    app = TicketTableHarness(tickets, active_ticket=tickets[2])

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        await pilot.press("9", "j")
        await pilot.pause()

        assert table.cursor_row == 4
        assert table._pending_count is None


@pytest.mark.asyncio
async def test_ticket_table_counted_k_clamps_at_first_row() -> None:
    tickets = make_ticket_batch(5)
    app = TicketTableHarness(tickets, active_ticket=tickets[2])

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        await pilot.press("9", "k")
        await pilot.pause()

        assert table.cursor_row == 0
        assert table._pending_count is None


@pytest.mark.asyncio
async def test_ticket_table_leading_zero_is_ignored() -> None:
    tickets = make_ticket_batch(5)
    app = TicketTableHarness(tickets)

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        await pilot.press("0", "j")
        await pilot.pause()

        assert table.cursor_row == 1
        assert table._pending_count is None


@pytest.mark.asyncio
async def test_ticket_table_zero_is_allowed_after_non_zero_digit() -> None:
    tickets = make_ticket_batch(20)
    app = TicketTableHarness(tickets)

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        await pilot.press("1", "0", "j")
        await pilot.pause()

        assert table.cursor_row == 10
        assert table._pending_count is None


@pytest.mark.asyncio
async def test_ticket_table_prefix_is_consumed_after_one_motion() -> None:
    tickets = make_ticket_batch(20)
    app = TicketTableHarness(tickets)

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        await pilot.press("1", "3", "j", "j")
        await pilot.pause()

        assert table.cursor_row == 14
        assert table._pending_count is None


@pytest.mark.asyncio
async def test_ticket_table_unrelated_key_clears_pending_prefix() -> None:
    tickets = make_ticket_batch(20)
    app = TicketTableHarness(tickets)

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        await pilot.press("1", "2", "down", "j")
        await pilot.pause()

        assert table.cursor_row == 2
        assert table._pending_count is None


@pytest.mark.asyncio
async def test_ticket_table_empty_table_counted_motion_is_noop() -> None:
    app = TicketTableHarness([])

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        await pilot.press("1", "3", "j")
        await pilot.pause()

        assert table.row_count == 0
        assert table._pending_count is None
        assert app.selected_ticket is None


@pytest.mark.asyncio
async def test_ticket_table_ticket_refresh_clears_pending_prefix() -> None:
    tickets = make_ticket_batch(20)
    app = TicketTableHarness(tickets)

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)
        await pilot.press("1", "2")
        await pilot.pause()

        table.set_tickets(tickets, active_ticket=None)
        await pilot.press("j")
        await pilot.pause()

        assert table.cursor_row == 1
        assert table._pending_count is None


@pytest.mark.asyncio
async def test_ticket_table_page_change_resets_cursor_to_top_row() -> None:
    tickets = make_ticket_batch(5)
    app = TicketTableHarness(
        tickets,
        pagination=TicketPagination(current_page=1, total_pages=3, total_tickets=15),
    )

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        await pilot.press("3", "j")
        await pilot.pause()
        assert table.cursor_row == 3

        table.set_tickets(
            tickets,
            active_ticket=None,
            pagination=TicketPagination(current_page=2, total_pages=3, total_tickets=15),
        )
        await pilot.pause()

        assert table.cursor_row == 0


@pytest.mark.asyncio
async def test_ticket_table_configure_columns_returns_when_columns_already_exist(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = TicketTableHarness([make_ticket(title="Broken scanner", name=2001)])

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)

        monkeypatch.setattr(
            table,
            "add_column",
            lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError()),
        )
        monkeypatch.setattr(
            table,
            "add_columns",
            lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError()),
        )

        table._configure_columns()


@pytest.mark.asyncio
async def test_ticket_table_refresh_line_number_gutter_returns_early_without_rows() -> None:
    app = TicketTableHarness([])

    async with app.run_test() as pilot:
        await pilot.pause()

        app.query_one(TicketTable)._refresh_line_number_gutter(0)


@pytest.mark.asyncio
async def test_ticket_table_refresh_line_number_gutter_updates_width_when_digits_grow(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    app = TicketTableHarness(make_ticket_batch(12))

    async with app.run_test() as pilot:
        await pilot.pause()
        table = app.query_one(TicketTable)
        column = table.columns[ColumnKey(table.LINE_NUMBER_COLUMN_KEY)]
        idle_checks: list[str] = []

        column.width = 1
        monkeypatch.setattr(table, "check_idle", lambda: idle_checks.append("idle"))

        table._refresh_line_number_gutter(9)

        assert column.width == 2
        assert table._require_update_dimensions is True
        assert idle_checks


def test_ticket_table_check_action_hides_pagination_without_multiple_pages() -> None:
    table = cast(TicketTable, object.__new__(TicketTable))
    table._pagination = TicketPagination(current_page=1, total_pages=1, total_tickets=1)

    assert table.check_action("next_ticket_page", ()) is False
    assert table.check_action("previous_ticket_page", ()) is False


def test_ticket_table_check_action_disables_boundary_pagination_actions() -> None:
    table = cast(TicketTable, object.__new__(TicketTable))
    table._pagination = TicketPagination(current_page=1, total_pages=3, total_tickets=3)

    assert table.check_action("previous_ticket_page", ()) is None
    assert table.check_action("next_ticket_page", ()) is True
