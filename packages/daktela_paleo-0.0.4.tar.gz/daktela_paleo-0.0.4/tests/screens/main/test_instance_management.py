from __future__ import annotations

from types import SimpleNamespace
from typing import Any, cast

from textual.widgets import Button

from daktela_paleo.screens.main.widgets.instance_management import (
    AddInstanceModal,
    AddInstanceResult,
    InstanceList,
    InstanceManagementModal,
    InstanceManagementResult,
)
from daktela_paleo.instances import DaktelaInstanceRecord


def make_saved_instance(
    *,
    id: str,
    base_url: str,
    user_token: str,
) -> DaktelaInstanceRecord:
    return DaktelaInstanceRecord.create(base_url, user_token, id=id)


def test_instance_list_message_control_returns_originating_list() -> None:
    instance_list = InstanceList([], active_instance_id=None)
    message = InstanceList.InstanceActivated(instance_list, "saved")

    assert message.control is instance_list


def test_instance_list_selected_ignores_other_list_view() -> None:
    instance_list = InstanceList([], active_instance_id=None)

    instance_list.on_list_view_selected(
        cast(
            Any,
            SimpleNamespace(
            list_view=object(),
            item=None,
            ),
        )
    )


def test_instance_list_initial_index_handles_empty_and_missing_active() -> None:
    instance = make_saved_instance(
        id="saved",
        base_url="demo.daktela.com/",
        user_token="token-1",
    )

    assert InstanceList._initial_index([], None) is None
    assert InstanceList._initial_index([instance], "missing") == 0


def test_instance_list_labels_include_token_suffix_for_duplicate_urls() -> None:
    first = make_saved_instance(
        id="one",
        base_url="demo.daktela.com/",
        user_token="token-1234",
    )
    second = make_saved_instance(
        id="two",
        base_url="demo.daktela.com/",
        user_token="token-5678",
    )

    assert InstanceList._labels([first, second], active_instance_id="two") == [
        "https://demo.daktela.com [..1234]",
        "https://demo.daktela.com [..5678] (active)",
    ]


def test_instance_management_modal_action_activate_returns_early_without_instances() -> None:
    modal = InstanceManagementModal([], active_instance_id=None)

    modal.action_activate()


def test_instance_management_modal_toggle_demo_dismisses_hidden_result(monkeypatch) -> None:
    modal = InstanceManagementModal([], active_instance_id=None)
    dismissed: list[InstanceManagementResult] = []

    monkeypatch.setattr(modal, "dismiss", dismissed.append)

    modal.action_toggle_demo_mode()

    assert dismissed == [InstanceManagementResult(action="toggle_demo_mode")]


def test_add_instance_modal_on_key_routes_submit_and_cancel(monkeypatch) -> None:
    modal = AddInstanceModal()
    calls: list[str] = []

    monkeypatch.setattr(modal, "action_submit", lambda: calls.append("submit"))
    monkeypatch.setattr(modal, "action_cancel", lambda: calls.append("cancel"))

    submit_event = cast(
        Any,
        SimpleNamespace(key="ctrl+s", stop=lambda: calls.append("submit-stop")),
    )
    cancel_event = cast(
        Any,
        SimpleNamespace(key="escape", stop=lambda: calls.append("cancel-stop")),
    )

    modal.on_key(submit_event)
    modal.on_key(cancel_event)

    assert calls == ["submit-stop", "submit", "cancel-stop", "cancel"]


def test_add_instance_modal_on_button_pressed_routes_actions(monkeypatch) -> None:
    modal = AddInstanceModal()
    calls: list[str] = []

    monkeypatch.setattr(modal, "action_submit", lambda: calls.append("submit"))
    monkeypatch.setattr(modal, "action_cancel", lambda: calls.append("cancel"))

    submit_event = Button.Pressed(Button(id="add-instance-submit"))
    cancel_event = Button.Pressed(Button(id="add-instance-cancel"))

    modal.on_button_pressed(submit_event)
    modal.on_button_pressed(cancel_event)

    assert calls == ["submit", "cancel"]


def test_add_instance_modal_action_cancel_dismisses_cancel_result(monkeypatch) -> None:
    modal = AddInstanceModal()
    dismissed: list[AddInstanceResult] = []

    monkeypatch.setattr(modal, "dismiss", dismissed.append)

    modal.action_cancel()

    assert dismissed == [AddInstanceResult(action="cancel")]
