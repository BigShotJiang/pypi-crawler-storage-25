import pytest
from textual.widgets import ListView

from daktela_paleo.models import TicketView
from daktela_paleo.screens.main.widgets.views import TicketViewListItem, TicketViewsList
from tests.support import make_ticket_view, rendered_labels, TicketViewsHarness


@pytest.mark.asyncio
async def test_ticket_views_list_renders_views_and_posts_activation_message() -> None:
    first_view = make_ticket_view("My Open")
    second_view = make_ticket_view("Delivery")
    third_view = make_ticket_view("All")
    app = TicketViewsHarness([first_view, second_view, third_view], active_view=first_view)

    async with app.run_test() as pilot:
        await pilot.pause()

        views_list = app.query_one(TicketViewsList)
        assert rendered_labels(views_list) == ["My Open", "Delivery", "All"]
        assert views_list.index == 0

        await pilot.press("j", "enter")
        await pilot.pause()

        assert app.selected_view == second_view


@pytest.mark.asyncio
async def test_ticket_views_list_right_arrow_posts_activation_message() -> None:
    first_view = make_ticket_view("My Open")
    second_view = make_ticket_view("Delivery")
    app = TicketViewsHarness([first_view, second_view], active_view=first_view)

    async with app.run_test() as pilot:
        await pilot.pause()

        await pilot.press("j", "right")
        await pilot.pause()

        assert app.selected_view == second_view


@pytest.mark.asyncio
async def test_ticket_views_list_renders_ticket_counts() -> None:
    first_view = make_ticket_view("My Open", ticket_count=12)
    second_view = make_ticket_view("Delivery")
    app = TicketViewsHarness([first_view, second_view], active_view=first_view)

    async with app.run_test() as pilot:
        await pilot.pause()

        views_list = app.query_one(TicketViewsList)
        assert rendered_labels(views_list) == ["My Open (12)", "Delivery"]


def test_ticket_views_list_renders_ascii_hierarchy_from_parent_views() -> None:
    views = [
        TicketView(title="Delivery", name="delivery", ticket_count=8),
        TicketView(title="Escalations", name="delivery_escalations", parent_view="delivery", ticket_count=2),
        TicketView(title="Waiting", name="delivery_waiting", parent_view="delivery"),
        TicketView(
            title="VIP",
            name="delivery_waiting_vip",
            parent_view="delivery_waiting",
            ticket_count=1,
        ),
        TicketView(
            title="Returns",
            name="delivery_waiting_returns",
            parent_view="delivery_waiting",
        ),
        TicketView(
            title="SLA Breach",
            name="delivery_waiting_sla",
            parent_view="delivery_waiting",
        ),
        TicketView(
            title="Missed Pickup",
            name="delivery_missed_pickup",
            parent_view="delivery",
        ),
    ]

    assert TicketViewsList._view_labels(views) == [
        "Delivery (8)",
        "|- Escalations (2)",
        "|- Waiting",
        "|  |- VIP (1)",
        "|  |- Returns",
        "|  `- SLA Breach",
        "`- Missed Pickup",
    ]


def test_ticket_views_list_view_activated_message_exposes_control() -> None:
    views_list = TicketViewsList()
    view = make_ticket_view("My Open")
    message = views_list.ViewActivated(views_list, view)

    assert message.control is views_list


def test_ticket_views_list_ignores_selection_from_other_list() -> None:
    views_list = TicketViewsList([make_ticket_view("My Open")])
    other_list = ListView()
    item = TicketViewListItem(make_ticket_view("Delivery"))
    messages: list[object] = []
    views_list.post_message = messages.append  # type: ignore[method-assign]

    views_list.on_list_view_selected(ListView.Selected(other_list, item, 0))

    assert messages == []


def test_ticket_views_list_sync_index_handles_empty_views() -> None:
    views_list = TicketViewsList()
    views_list.index = 3
    views_list._views = []

    views_list._sync_index()

    assert views_list.index is None


@pytest.mark.asyncio
async def test_ticket_views_list_sync_index_defaults_to_first_item_when_selection_is_missing() -> None:
    app = TicketViewsHarness([])

    async with app.run_test() as pilot:
        await pilot.pause()

        views_list = app.query_one(TicketViewsList)
        views_list.set_views([make_ticket_view("My Open")], active_view=None)
        await pilot.pause()

        assert views_list.index == 0


def test_ticket_views_list_match_index_returns_none_when_view_is_absent() -> None:
    first_view = make_ticket_view("My Open")
    second_view = make_ticket_view("Delivery")

    assert TicketViewsList._match_index([first_view], second_view) is None


def test_ticket_views_list_match_index_uses_stable_identity_instead_of_full_model_equality() -> None:
    listed_view = TicketView(title="Delivery", view=7, parent_view="team_views")
    active_view = TicketView(title="Delivery", view=7, parent_view="favorite_views")

    assert TicketViewsList._match_index([listed_view], active_view) == 0


def test_ticket_views_list_match_index_prefers_name_when_view_is_missing() -> None:
    listed_view = TicketView(title="My Open", name="my_open", parent_view="team_views")
    active_view = TicketView(title="My Open", name="my_open", parent_view="favorite_views")

    assert TicketViewsList._match_index([listed_view], active_view) == 0


def test_ticket_views_list_view_signature_tracks_identity_and_title() -> None:
    first_view = TicketView(title="My Open", view=1, parent_view="team_views", ticket_count=4)
    second_view = TicketView(title="Renamed", view=1, parent_view="favorite_views", ticket_count=4)

    assert TicketViewsList._view_signature([first_view]) == (
        ("view", "1", "My Open", "team_views", "4"),
    )
    assert TicketViewsList._view_signature([first_view]) != TicketViewsList._view_signature(
        [second_view]
    )


@pytest.mark.asyncio
async def test_ticket_views_list_rerenders_when_only_ticket_count_changes() -> None:
    initial_view = TicketView(title="My Open", name="my_open", ticket_count=2)
    updated_view = TicketView(title="My Open", name="my_open", ticket_count=5)
    app = TicketViewsHarness([initial_view], active_view=initial_view)

    async with app.run_test() as pilot:
        await pilot.pause()

        views_list = app.query_one(TicketViewsList)
        assert rendered_labels(views_list) == ["My Open (2)"]

        views_list.set_views([updated_view], active_view=updated_view)
        await pilot.pause()

        assert rendered_labels(views_list) == ["My Open (5)"]


def test_ticket_views_list_view_labels_skip_orphaned_parent_links() -> None:
    views = [TicketView(title="Orphan", name="orphan", parent_view="missing")]

    assert TicketViewsList._view_labels(views) == ["Orphan"]


def test_ticket_views_list_view_labels_indent_last_ancestor_with_spaces() -> None:
    views = [
        TicketView(title="Root", name="root"),
        TicketView(title="Last Parent", name="last_parent", parent_view="root"),
        TicketView(title="Leaf", name="leaf", parent_view="last_parent"),
    ]

    assert TicketViewsList._view_labels(views) == [
        "Root",
        "`- Last Parent",
        "   `- Leaf",
    ]


def test_ticket_views_list_hierarchy_path_handles_cycles_and_missing_parents() -> None:
    cyclic_view = TicketView(title="Loop", name="loop", parent_view="loop")
    orphan_view = TicketView(title="Orphan", name="orphan", parent_view="missing")

    assert TicketViewsList._hierarchy_path(cyclic_view, {"loop": cyclic_view}) == ["loop"]
    assert TicketViewsList._hierarchy_path(orphan_view, {}) == ["orphan"]
