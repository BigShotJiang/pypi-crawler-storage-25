from types import SimpleNamespace
from typing import cast

import pytest
from textual import events

from daktela_paleo.widgets.vertical_splitter import VerticalSplitter


def test_vertical_splitter_dragged_message_exposes_control() -> None:
    splitter = VerticalSplitter(id="splitter")
    message = VerticalSplitter.Dragged(splitter, 12)

    assert message.control is splitter


@pytest.mark.asyncio
async def test_vertical_splitter_click_stops_event() -> None:
    splitter = VerticalSplitter(id="splitter")
    event = SimpleNamespace(stopped=False)

    def stop() -> None:
        event.stopped = True

    event.stop = stop

    await splitter._on_click(cast(events.Click, event))

    assert event.stopped is True
