from __future__ import annotations

from textual.app import App, ComposeResult
from textual.css.query import NoMatches
from textual.widgets import Static

from daktela_paleo.widgets.chrome import AppChrome


class ChromeHarness(App[None]):
    def compose(self) -> ComposeResult:
        yield AppChrome("Ready", "Instance: disconnected")


async def test_app_chrome_updates_both_segments() -> None:
    app = ChromeHarness()

    async with app.run_test() as pilot:
        await pilot.pause()

        chrome = app.query_one(AppChrome)
        chrome.set_status_text("Busy")
        chrome.set_instance_text("Instance: https://demo.daktela.com")
        await pilot.pause()

        assert chrome.query_one("#status-bar", Static).render() == "Busy"
        assert chrome.query_one("#instance-context", Static).render() == (
            "Instance: https://demo.daktela.com"
        )


async def test_app_chrome_watchers_ignore_missing_segments(
    monkeypatch,
) -> None:
    app = ChromeHarness()

    async with app.run_test() as pilot:
        await pilot.pause()

        chrome = app.query_one(AppChrome)

        def raise_no_matches(*args: object, **kwargs: object) -> object:
            raise NoMatches("segment missing")

        monkeypatch.setattr(chrome, "query_one", raise_no_matches)

        chrome.watch_status_text("Busy")
        chrome.watch_instance_text("Instance: https://demo.daktela.com")
