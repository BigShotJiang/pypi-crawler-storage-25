from datetime import datetime
from typing import Any

from rich.text import Text
from textual import on
from textual.app import App, ComposeResult
from textual.widgets import DataTable, ListView

from daktela_paleo.connectors import DemoTicketConnector
from daktela_paleo.models import (
    AppState,
    Ticket,
    TicketActivity,
    TicketActivityAttachment,
    TicketActivityItem,
    TicketCategoryOption,
    TicketPagination,
    TicketCustomField,
    TicketCustomFieldOption,
    TicketPriority,
    TicketStatusOption,
    TicketStage,
    TicketUserOption,
    TicketView,
)
from daktela_paleo.screens.main.screen import TicketList
from daktela_paleo.screens.main.widgets.tickets import TicketTable
from daktela_paleo.screens.main.widgets.views import TicketViewsList
from daktela_paleo.screens.ticket_detail.screen import TicketDetail


def make_ticket(
    title: str = "Printer is jammed",
    *,
    name: int | None = None,
    category: str = "category_123456",
    category_name: str | None = None,
    description: str | None = None,
    contact: str | None = None,
    user: str | None = None,
    user_name: str | None = None,
    statuses: dict[str, str] | None = None,
    edited: datetime | None = None,
    edited_by: str | None = None,
    sla_deadtime: datetime | None = None,
    reopen: datetime | None = None,
    custom_fields: Any = None,
    stage: TicketStage = TicketStage.OPEN,
    priority: TicketPriority = TicketPriority.HIGH,
) -> Ticket:
    return Ticket(
        name=name,
        title=title,
        category=category,
        category_name=category if category_name is None else category_name,
        description=description,
        contact=contact,
        user=user,
        user_name=user if user_name is None else user_name,
        statuses=statuses,
        edited=edited,
        edited_by=edited_by,
        sla_deadtime=sla_deadtime,
        reopen=reopen,
        customFields=custom_fields,
        stage=stage,
        priority=priority,
    )


def make_ticket_custom_fields() -> list[TicketCustomField]:
    return [
        TicketCustomField(
            field="consultant",
            title="Consultant",
            values=["alice"],
            field_type="select",
            options=[
                TicketCustomFieldOption(value="alice", title="Alice"),
                TicketCustomFieldOption(value="bob", title="Bob"),
            ],
        ),
        TicketCustomField(
            field="serial_number",
            title="Serial Number",
            values=["SN-42", "SN-43"],
            field_type="text",
        ),
        TicketCustomField(
            field="replacement_required",
            title="Replacement Required",
            values=["YES"],
            field_type="checkbox",
            options=[
                TicketCustomFieldOption(value="YES", title="Yes"),
                TicketCustomFieldOption(value="NO", title="No"),
            ],
        ),
    ]


def make_ticket_view(
    title: str = "Open high priority tickets",
    *,
    view: int | None = None,
    name: str | None = None,
    parent_view: str | None = None,
    ticket_count: int | None = None,
) -> TicketView:
    return TicketView(
        title=title,
        view=view,
        name=name,
        parent_view=parent_view,
        ticket_count=ticket_count,
    )


def make_activity(
    title: str = "Customer replied",
    *,
    name: str = "activities_1",
    type: str = "EMAIL",
    user: str | None = "Operator One",
    user_name: str | None = None,
    time: datetime | str = "2026-03-28 10:30:00",
    description: str | None = None,
    body_html: str | None = None,
    item_model: str | None = "activitiesEmail",
    item_description: str | None = None,
    direction: str | None = None,
    attachments: list[dict[str, object] | TicketActivityAttachment] | None = None,
) -> TicketActivity:
    item = None
    if any(value is not None for value in (item_model, title, body_html, item_description, direction)):
        item_payload: dict[str, object] = {
            "model": item_model,
            "title": title,
            "time": time,
            "description": item_description,
            "body_html": body_html,
            "direction": direction,
        }
        if item_model == "activitiesEmail":
            item_payload["attachments"] = attachments
        item = TicketActivityItem.model_validate(item_payload)

    activity_payload: dict[str, object] = {
        "name": name,
        "type": type,
        "title": title,
        "time": time,
        "user": user,
        "user_name": user if user_name is None else user_name,
        "description": description,
        "item": item,
    }
    if item_model != "activitiesEmail":
        activity_payload["attachments"] = attachments

    return TicketActivity.model_validate(
        activity_payload
    )


def make_ticket_batch(count: int, *, start: int = 1000) -> list[Ticket]:
    return [
        make_ticket(title=f"Ticket {index}", name=start + index)
        for index in range(count)
    ]


def make_demo_state() -> AppState:
    return DemoTicketConnector.build_state()


def ticket_rows(table: DataTable) -> list[list[str]]:
    return [
        [
            cell.plain.strip() if isinstance(cell, Text) else str(cell)
            for cell in table.get_row_at(index)
        ]
        for index in range(table.row_count)
    ]


def ticket_row_renderables(table: DataTable) -> list[list[object]]:
    return [
        list(table.get_row_at(index))
        for index in range(table.row_count)
    ]


def rendered_labels(list_view: ListView) -> list[str]:
    return [str(widget.render()) for widget in list_view.query("ListItem Static")]


class TicketTableHarness(App[None]):
    def __init__(
        self,
        tickets: list[Ticket],
        active_ticket: Ticket | None = None,
        column_keys: list[str] | None = None,
        pagination: TicketPagination | None = None,
    ) -> None:
        super().__init__()
        self._tickets = tickets
        self._active_ticket = active_ticket
        self._column_keys = column_keys
        self._pagination = pagination
        self.selected_ticket: Ticket | None = None
        self.search_requested = False
        self.search_status: str | None = None
        self.next_page_requested = False
        self.previous_page_requested = False

    def compose(self) -> ComposeResult:
        yield TicketTable(id="tickets-table")

    def on_mount(self) -> None:
        table = self.query_one(TicketTable)
        table.set_tickets(
            self._tickets,
            self._active_ticket,
            self._column_keys,
            self._pagination,
        )
        self.set_focus(table)

    @on(TicketTable.TicketActivated)
    def handle_ticket_activated(self, message: TicketTable.TicketActivated) -> None:
        self.selected_ticket = message.ticket

    @on(TicketTable.SearchRequested)
    def handle_search_requested(self, _: TicketTable.SearchRequested) -> None:
        self.search_requested = True

    @on(TicketTable.SearchStatusChanged)
    def handle_search_status_changed(self, message: TicketTable.SearchStatusChanged) -> None:
        self.search_status = message.status

    @on(TicketTable.NextPageRequested)
    def handle_next_page_requested(self, _: TicketTable.NextPageRequested) -> None:
        self.next_page_requested = True

    @on(TicketTable.PreviousPageRequested)
    def handle_previous_page_requested(self, _: TicketTable.PreviousPageRequested) -> None:
        self.previous_page_requested = True


class TicketViewsHarness(App[None]):
    def __init__(self, views: list[TicketView], active_view: TicketView | None = None) -> None:
        super().__init__()
        self._views = views
        self._active_view = active_view
        self.selected_view: TicketView | None = None

    def compose(self) -> ComposeResult:
        yield TicketViewsList(id="views-list")

    def on_mount(self) -> None:
        views_list = self.query_one(TicketViewsList)
        views_list.set_views(self._views, self._active_view)
        self.set_focus(views_list)

    @on(TicketViewsList.ViewActivated)
    def handle_view_activated(self, message: TicketViewsList.ViewActivated) -> None:
        self.selected_view = message.view


class TicketListHarness(App[None]):
    def __init__(self, initial_state: AppState, *, ticket_loading: bool = False) -> None:
        super().__init__()
        self._initial_state = initial_state
        self._ticket_loading = ticket_loading
        self.refresh_requested = False
        self.view_open_requested: TicketView | None = None

    def compose(self) -> ComposeResult:
        yield TicketList(
            self._initial_state,
            ticket_loading=self._ticket_loading,
            id="ticket-list",
        )

    @on(TicketList.RefreshRequested)
    def handle_refresh_requested(self, _: TicketList.RefreshRequested) -> None:
        self.refresh_requested = True

    @on(TicketList.OpenInBrowserRequested)
    def handle_open_in_browser_requested(
        self,
        message: TicketList.OpenInBrowserRequested,
    ) -> None:
        self.view_open_requested = message.view


class TicketDetailHarness(App[None]):
    def __init__(
        self,
        ticket: Ticket,
        category_options: list[TicketCategoryOption] | None = None,
        status_options: list[TicketStatusOption] | None = None,
        user_options: list[TicketUserOption] | None = None,
        current_user: TicketUserOption | None = None,
        instance_context: str = "Instance: disconnected",
        resolve_activity_asset_url: Any = None,
        load_activity_asset: Any = None,
    ) -> None:
        super().__init__()
        self._ticket = ticket
        self._category_options = category_options
        self._status_options = status_options
        self._user_options = user_options
        self._current_user = current_user
        self._instance_context = instance_context
        self._resolve_activity_asset_url = resolve_activity_asset_url
        self._load_activity_asset = load_activity_asset

    def on_mount(self) -> None:
        self.push_screen(
            TicketDetail(
                self._ticket,
                f"Selected ticket: {self._ticket.title}",
                instance_context=self._instance_context,
                category_options=self._category_options,
                status_options=self._status_options,
                user_options=self._user_options,
                current_user=self._current_user,
                status_options_category_name=(
                    self._ticket.category_name or self._ticket.category
                    if self._status_options is not None
                    else None
                ),
                resolve_activity_asset_url=self._resolve_activity_asset_url,
                load_activity_asset=self._load_activity_asset,
            )
        )
