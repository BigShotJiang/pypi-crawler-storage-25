from __future__ import annotations

import asyncio
from importlib.resources import files

import pytest

import daktela_paleo.connectors.base as base_module
from daktela_paleo.connectors import demo as demo_module
from daktela_paleo.connectors import (
    DemoTicketConnector,
    MockTicketConnector,
    TicketActivity,
    TicketCategoryOption,
    TicketConnector,
    TicketStatusOption,
    TicketUserOption,
)
from daktela_paleo.models import (
    AppState,
    Ticket,
    TicketActivityAttachment,
    TicketCommentAttachmentUpload,
    TicketCommentCreateRequest,
    TicketEmailAction,
    TicketEmailDraft,
    TicketEmailSendRequest,
    TicketEditPatch,
    TicketPagination,
    TicketPriority,
    TicketStage,
    TicketView,
)


def make_ticket(
    title: str,
    *,
    name: int,
    category: str = "delivery",
    category_name: str | None = None,
    contact: str | None = None,
    user: str | None = None,
    user_name: str | None = None,
    stage: TicketStage = TicketStage.OPEN,
    priority: TicketPriority = TicketPriority.HIGH,
) -> Ticket:
    return Ticket(
        name=name,
        title=title,
        category=category,
        category_name=category if category_name is None else category_name,
        contact=contact,
        user=user,
        user_name=user if user_name is None else user_name,
        stage=stage,
        priority=priority,
    )


def make_email_activity(
    *,
    activity_name: str = "activities_1",
    email_name: str = "emails_1",
    title: str = "Customer replied",
    address: str | None = "customer@example.com",
    queue_name: str | None = "queues_1",
) -> TicketActivity:
    return TicketActivity.model_validate(
        {
            "name": activity_name,
            "type": "EMAIL",
            "title": title,
            "item": {
                "name": email_name,
                "model": "activitiesEmail",
                "title": title,
                "address": address,
                "queue_name": queue_name,
            },
        }
    )


class StaticConnector(TicketConnector):
    def __init__(self) -> None:
        self.views = [TicketView(view=1, title="All")]
        self.tickets = [make_ticket("Static ticket", name=7001)]
        self.calls: list[tuple[str, tuple[str, str] | None]] = []

    async def list_views(self) -> list[TicketView]:
        self.calls.append(("views", None))
        return self.views

    async def list_tickets(self, view: TicketView | None = None) -> list[Ticket]:
        self.calls.append(("tickets", None if view is None else view.selection_key()))
        return self.tickets

    async def list_ticket_categories(self) -> list[TicketCategoryOption]:
        self.calls.append(("categories", None))
        return [TicketCategoryOption(name="delivery", title="Delivery")]

    async def list_ticket_users(self) -> list[TicketUserOption]:
        self.calls.append(("users", None))
        return [TicketUserOption(name="operator_alice", title="Operator Alice")]

    async def list_ticket_statuses(self, category_name: str) -> list[TicketStatusOption]:
        self.calls.append((f"statuses:{category_name}", None))
        return [TicketStatusOption(name="status_dispatch", title="Dispatch")]

    async def list_ticket_activities(self, ticket: Ticket) -> list[TicketActivity]:
        self.calls.append(("activities", None if ticket.name is None else ("name", str(ticket.name))))
        return []

    async def load_ticket_activity_attachment(
        self,
        activity: TicketActivity,
        attachment: TicketActivityAttachment,
    ) -> bytes:
        self.calls.append(
            (
                "attachment",
                None if activity.name is None else ("name", activity.name),
            )
        )
        raise AssertionError(
            "load_ticket_activity_attachment should not be called for "
            f"{activity.title}: {attachment.title}"
        )

    async def store_ticket(self, ticket: Ticket, patch: TicketEditPatch) -> Ticket:
        self.calls.append(("store", None if ticket.name is None else ("name", str(ticket.name))))
        saved_ticket = patch.apply_to(ticket)
        self.tickets = [saved_ticket if current.name == ticket.name else current for current in self.tickets]
        return saved_ticket

    async def create_ticket_comment(
        self,
        ticket: Ticket,
        request: TicketCommentCreateRequest,
    ) -> None:
        self.calls.append(("comment", None if ticket.name is None else ("name", str(ticket.name))))

    async def get_ticket_email_draft(
        self,
        ticket: Ticket,
        activity: TicketActivity,
        action: TicketEmailAction,
    ) -> TicketEmailDraft:
        self.calls.append(("email-draft", None if ticket.name is None else ("name", str(ticket.name))))
        return TicketEmailDraft(
            action=action,
            source_activity_name=activity.name or "activities_1",
            source_email_name="emails_1",
            to="client@example.com" if action == TicketEmailAction.REPLY else "",
            subject="Re: Static ticket" if action == TicketEmailAction.REPLY else "Fwd: Static ticket",
            body="",
            queue_name="queue_1",
        )

    async def send_ticket_email(self, ticket: Ticket, request: TicketEmailSendRequest) -> None:
        self.calls.append(("email-send", None if ticket.name is None else ("name", str(ticket.name))))


@pytest.mark.asyncio
async def test_ticket_connector_load_initial_state_uses_views_and_default_tickets() -> None:
    connector = StaticConnector()

    state = await connector.load_initial_state()

    assert state == AppState(tickets=connector.tickets, views=connector.views)
    assert connector.calls == [("views", None), ("tickets", None)]


@pytest.mark.asyncio
async def test_ticket_connector_default_list_ticket_page_wraps_list_tickets() -> None:
    connector = StaticConnector()
    view = connector.views[0]

    ticket_page = await connector.list_ticket_page(view, page=3)

    assert ticket_page.tickets == connector.tickets
    assert ticket_page.pagination == TicketPagination(
        current_page=1,
        total_pages=1,
        total_tickets=1,
    )
    assert connector.calls == [("tickets", ("view", "1"))]


@pytest.mark.asyncio
async def test_ticket_connector_default_optional_methods_return_none() -> None:
    connector = StaticConnector()
    ticket = make_ticket("Static ticket", name=7001)
    view = connector.views[0]

    assert await connector.get_current_user() is None
    assert await connector.get_ticket_grid_column_keys() is None
    assert connector.resolve_activity_asset_url("https://example.test/image.png") == (
        "https://example.test/image.png"
    )
    assert connector.resolve_activity_asset_url("/file/image.php?name=5") is None
    assert connector.ticket_browser_url(ticket) is None
    assert connector.view_browser_url(view) is None


@pytest.mark.asyncio
async def test_ticket_connector_default_load_activity_asset_fetches_content(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = StaticConnector()
    calls: list[object] = []

    class ResponseStub:
        content = b"png-bytes"

        def raise_for_status(self) -> None:
            calls.append("raise_for_status")

    class ClientStub:
        def __init__(self, *, timeout: int) -> None:
            calls.append(("init", timeout))

        async def __aenter__(self) -> ClientStub:
            calls.append("enter")
            return self

        async def __aexit__(self, *_args: object) -> None:
            calls.append("exit")

        async def get(self, url: str) -> ResponseStub:
            calls.append(("get", url))
            return ResponseStub()

    monkeypatch.setattr(base_module.httpx, "AsyncClient", ClientStub)

    content = await connector.load_activity_asset("https://example.test/image.png")

    assert content == b"png-bytes"
    assert calls == [
        ("init", 30),
        "enter",
        ("get", "https://example.test/image.png"),
        "raise_for_status",
        "exit",
    ]


@pytest.mark.asyncio
async def test_mock_ticket_connector_records_calls_and_returns_view_specific_tickets() -> None:
    delivery = TicketView(view=2, name="delivery", title="Delivery")
    default_ticket = make_ticket("All queue", name=7002)
    delivery_ticket = make_ticket("Delivery queue", name=7003)
    connector = MockTicketConnector(views=[delivery], tickets=[default_ticket])
    connector.set_tickets_for_view(delivery, [delivery_ticket])

    default_result = await connector.list_tickets()
    delivery_result = await connector.list_tickets(delivery)

    assert default_result == [default_ticket]
    assert delivery_result == [delivery_ticket]
    assert connector.list_tickets_calls == [None, ("view", "2")]


def test_mock_ticket_connector_rejects_attachment_fixture_without_activity_name() -> None:
    connector = MockTicketConnector()
    activity = TicketActivity.model_validate({"type": ""})

    with pytest.raises(ValueError, match="must include a name"):
        connector.set_ticket_activity_attachment(
            activity,
            TicketActivityAttachment(file="6", title="April report.txt"),
            b"bytes",
        )


@pytest.mark.asyncio
async def test_mock_ticket_connector_returns_configured_ticket_pages() -> None:
    delivery = TicketView(view=2, name="delivery", title="Delivery")
    first_page_ticket = make_ticket("Delivery page 1", name=7003)
    second_page_ticket = make_ticket("Delivery page 2", name=7004)
    connector = MockTicketConnector(views=[delivery])
    connector.set_ticket_pages_for_view(
        delivery,
        [[first_page_ticket], [second_page_ticket]],
        total_tickets=2,
    )

    ticket_page = await connector.list_ticket_page(delivery, page=9)

    assert ticket_page.tickets == [second_page_ticket]
    assert ticket_page.pagination == TicketPagination(
        current_page=2,
        total_pages=2,
        total_tickets=2,
    )
    assert connector.list_ticket_page_calls == [(("view", "2"), 9)]


@pytest.mark.asyncio
async def test_mock_ticket_connector_resolves_and_loads_configured_activity_asset() -> None:
    connector = MockTicketConnector()
    connector.set_activity_asset(
        "/file/image.php?mapper=activities&name=5",
        "https://demo.daktela.com/file/image.php?mapper=activities&name=5&accessToken=token-123",
        b"asset-bytes",
    )

    resolved_url = connector.resolve_activity_asset_url("/file/image.php?mapper=activities&name=5")
    content = await connector.load_activity_asset(
        "https://demo.daktela.com/file/image.php?mapper=activities&name=5&accessToken=token-123"
    )

    assert resolved_url == (
        "https://demo.daktela.com/file/image.php?mapper=activities&name=5&accessToken=token-123"
    )
    assert content == b"asset-bytes"
    assert connector.resolve_activity_asset_url_calls == ["/file/image.php?mapper=activities&name=5"]
    assert connector.load_activity_asset_calls == [
        "https://demo.daktela.com/file/image.php?mapper=activities&name=5&accessToken=token-123"
    ]


def test_mock_ticket_connector_activity_asset_url_falls_back_to_base_resolution() -> None:
    connector = MockTicketConnector()

    assert connector.resolve_activity_asset_url("https://example.test/image.png") == (
        "https://example.test/image.png"
    )
    assert connector.resolve_activity_asset_url_calls == ["https://example.test/image.png"]


@pytest.mark.asyncio
async def test_mock_ticket_connector_load_activity_asset_raises_for_unconfigured_asset() -> None:
    connector = MockTicketConnector()

    with pytest.raises(ValueError, match="not configured"):
        await connector.load_activity_asset("https://example.test/image.png")

    assert connector.load_activity_asset_calls == ["https://example.test/image.png"]


@pytest.mark.asyncio
async def test_mock_ticket_connector_store_ticket_updates_paginated_pages() -> None:
    delivery = TicketView(view=2, name="delivery", title="Delivery")
    page_one_ticket = make_ticket("Delivery page 1", name=7003)
    page_two_ticket = make_ticket("Delivery page 2", name=7004, user="operator_old")
    connector = MockTicketConnector(views=[delivery])
    connector.set_ticket_pages_for_view(
        delivery,
        [[page_one_ticket], [page_two_ticket]],
        total_tickets=2,
    )

    await connector.store_ticket(
        page_two_ticket,
        TicketEditPatch(user_name="operator_new", user_title="Operator New"),
    )
    ticket_page = await connector.list_ticket_page(delivery, page=2)

    assert ticket_page.tickets[0].user_name == "operator_new"


@pytest.mark.asyncio
async def test_mock_ticket_connector_set_default_ticket_pages_handles_empty_pages() -> None:
    connector = MockTicketConnector()
    connector.set_ticket_pages_for_view(None, [])

    ticket_page = await connector.list_ticket_page(None, page=4)

    assert ticket_page.tickets == []
    assert ticket_page.pagination == TicketPagination(
        current_page=1,
        total_pages=1,
        total_tickets=0,
    )


@pytest.mark.asyncio
async def test_mock_ticket_connector_paginated_view_can_raise_configured_error() -> None:
    delivery = TicketView(view=2, name="delivery", title="Delivery")
    connector = MockTicketConnector(views=[delivery])
    connector.set_ticket_pages_for_view(
        delivery,
        [[make_ticket("Delivery page 1", name=7003)]],
        error=RuntimeError("boom"),
    )

    with pytest.raises(RuntimeError, match="boom"):
        await connector.list_ticket_page(delivery)


def test_mock_ticket_connector_ticket_exists_checks_view_specific_tickets() -> None:
    delivery = TicketView(view=2, name="delivery", title="Delivery")
    delivery_ticket = make_ticket("Delivery queue", name=7003)
    connector = MockTicketConnector(views=[delivery])
    connector.set_tickets_for_view(delivery, [delivery_ticket])

    assert connector._ticket_exists(("name", "7003")) is True


@pytest.mark.asyncio
async def test_demo_ticket_connector_filters_tickets_for_universe_branch() -> None:
    connector = DemoTicketConnector()
    hl2_view = next(view for view in connector.build_views() if view.name == "hl2")

    tickets = await connector.list_tickets(hl2_view)

    assert [ticket.name for ticket in tickets] == [2001, 2002, 2003, 2004]


@pytest.mark.asyncio
async def test_demo_ticket_connector_paginated_leaf_returns_configured_second_page() -> None:
    connector = DemoTicketConnector()
    city17_view = next(view for view in connector.build_views() if view.name == "hl2_city17")

    ticket_page = await connector.list_ticket_page(city17_view, page=2)

    assert [ticket.name for ticket in ticket_page.tickets] == [2002]
    assert ticket_page.pagination == TicketPagination(
        current_page=2,
        total_pages=2,
        total_tickets=2,
    )


@pytest.mark.asyncio
async def test_mock_ticket_connector_returns_configured_ticket_categories() -> None:
    category_options = [
        TicketCategoryOption(name="delivery", title="Delivery"),
        TicketCategoryOption(name="returns", title="Returns"),
    ]
    connector = MockTicketConnector(category_options=category_options)

    result = await connector.list_ticket_categories()

    assert result == category_options
    assert connector.list_ticket_categories_calls == 1


@pytest.mark.asyncio
async def test_mock_ticket_connector_returns_configured_ticket_users() -> None:
    user_options = [
        TicketUserOption(name="operator_1", title="Operator One"),
        TicketUserOption(name="operator_2", title="Operator Two"),
    ]
    connector = MockTicketConnector(user_options=user_options)

    result = await connector.list_ticket_users()

    assert result == user_options
    assert connector.list_ticket_users_calls == 1


@pytest.mark.asyncio
async def test_mock_ticket_connector_returns_configured_ticket_grid_column_keys() -> None:
    connector = MockTicketConnector(
        ticket_grid_column_keys=["edited", "user.title", "edited"]
    )

    result = await connector.get_ticket_grid_column_keys()

    assert result == ["edited", "user.title", "edited"]
    assert connector.get_ticket_grid_column_keys_calls == 1


@pytest.mark.asyncio
async def test_mock_ticket_connector_ticket_grid_column_keys_honors_delay_and_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    sleep_calls: list[float] = []

    async def fake_sleep(delay: float) -> None:
        sleep_calls.append(delay)

    monkeypatch.setattr(asyncio, "sleep", fake_sleep)
    connector = MockTicketConnector(
        ticket_grid_column_keys_error=RuntimeError("boom"),
        ticket_grid_column_keys_delay=0.2,
    )

    with pytest.raises(RuntimeError, match="boom"):
        await connector.get_ticket_grid_column_keys()

    assert connector.get_ticket_grid_column_keys_calls == 1
    assert sleep_calls == [0.2]


@pytest.mark.asyncio
async def test_mock_ticket_connector_set_ticket_grid_column_keys_updates_response() -> None:
    connector = MockTicketConnector(ticket_grid_column_keys=["edited"])

    connector.set_ticket_grid_column_keys(
        ["user.title"],
        error=RuntimeError("boom"),
        delay=0.4,
    )

    with pytest.raises(RuntimeError, match="boom"):
        await connector.get_ticket_grid_column_keys()

    connector.set_ticket_grid_column_keys(["edited", "user.title"])

    assert await connector.get_ticket_grid_column_keys() == ["edited", "user.title"]


@pytest.mark.asyncio
async def test_mock_ticket_connector_returns_configured_ticket_statuses_for_category() -> None:
    status_options = [
        TicketStatusOption(name="status_dispatch", title="Dispatch"),
        TicketStatusOption(name="status_return", title="Return"),
    ]
    connector = MockTicketConnector(
        status_options_by_category={"delivery": status_options}
    )

    result = await connector.list_ticket_statuses("delivery")

    assert result == status_options
    assert connector.list_ticket_statuses_calls == ["delivery"]


@pytest.mark.asyncio
async def test_mock_ticket_connector_returns_configured_ticket_activities_for_ticket() -> None:
    ticket = make_ticket("Delivery queue", name=7014)
    activities = [TicketActivity(type="EMAIL", title="Customer replied")]
    connector = MockTicketConnector(tickets=[ticket])
    connector.set_ticket_activities(ticket, activities)

    result = await connector.list_ticket_activities(ticket)

    assert result == activities
    assert connector.list_ticket_activities_calls == [("name", "7014")]


@pytest.mark.asyncio
async def test_mock_ticket_connector_store_ticket_updates_all_matching_collections() -> None:
    delivery = TicketView(view=2, name="delivery", title="Delivery")
    original_ticket = make_ticket("Delivery queue", name=7003)
    connector = MockTicketConnector(views=[delivery], tickets=[original_ticket])
    connector.set_tickets_for_view(delivery, [original_ticket])

    saved_ticket = await connector.store_ticket(
        original_ticket,
        TicketEditPatch(title="Updated delivery queue"),
    )

    assert saved_ticket.title == "Updated delivery queue"
    assert connector.store_ticket_calls == [
        (original_ticket, TicketEditPatch(title="Updated delivery queue"))
    ]
    assert [ticket.title for ticket in await connector.list_tickets()] == ["Updated delivery queue"]
    assert [ticket.title for ticket in await connector.list_tickets(delivery)] == [
        "Updated delivery queue"
    ]


@pytest.mark.asyncio
async def test_mock_ticket_connector_store_ticket_updates_stage_in_matching_collections() -> None:
    delivery = TicketView(view=2, name="delivery", title="Delivery")
    original_ticket = make_ticket("Delivery queue", name=7008, stage=TicketStage.OPEN)
    connector = MockTicketConnector(views=[delivery], tickets=[original_ticket])
    connector.set_tickets_for_view(delivery, [original_ticket])

    saved_ticket = await connector.store_ticket(
        original_ticket,
        TicketEditPatch(stage=TicketStage.WAIT),
    )

    assert saved_ticket.stage is TicketStage.WAIT
    assert connector.store_ticket_calls == [
        (original_ticket, TicketEditPatch(stage=TicketStage.WAIT))
    ]
    assert [ticket.stage for ticket in await connector.list_tickets()] == [TicketStage.WAIT]
    assert [ticket.stage for ticket in await connector.list_tickets(delivery)] == [TicketStage.WAIT]


@pytest.mark.asyncio
async def test_mock_ticket_connector_store_ticket_updates_priority_in_matching_collections() -> None:
    delivery = TicketView(view=2, name="delivery", title="Delivery")
    original_ticket = make_ticket("Delivery queue", name=7013, priority=TicketPriority.HIGH)
    connector = MockTicketConnector(views=[delivery], tickets=[original_ticket])
    connector.set_tickets_for_view(delivery, [original_ticket])

    saved_ticket = await connector.store_ticket(
        original_ticket,
        TicketEditPatch(priority=TicketPriority.LOW),
    )

    assert saved_ticket.priority is TicketPriority.LOW
    assert connector.store_ticket_calls == [
        (original_ticket, TicketEditPatch(priority=TicketPriority.LOW))
    ]
    assert [ticket.priority for ticket in await connector.list_tickets()] == [TicketPriority.LOW]
    assert [ticket.priority for ticket in await connector.list_tickets(delivery)] == [
        TicketPriority.LOW
    ]


@pytest.mark.asyncio
async def test_mock_ticket_connector_store_ticket_updates_user_in_matching_collections() -> None:
    delivery = TicketView(view=2, name="delivery", title="Delivery")
    original_ticket = make_ticket(
        "Delivery queue",
        name=7009,
        user="Operator One",
        user_name="operator_1",
    )
    connector = MockTicketConnector(views=[delivery], tickets=[original_ticket])
    connector.set_tickets_for_view(delivery, [original_ticket])

    saved_ticket = await connector.store_ticket(
        original_ticket,
        TicketEditPatch(user_name="operator_2", user_title="Operator Two"),
    )

    assert saved_ticket.user_name == "operator_2"
    assert saved_ticket.user == "Operator Two"
    assert connector.store_ticket_calls == [
        (
            original_ticket,
            TicketEditPatch(user_name="operator_2", user_title="Operator Two"),
        )
    ]
    assert [ticket.user for ticket in await connector.list_tickets()] == ["Operator Two"]
    assert [ticket.user_name for ticket in await connector.list_tickets(delivery)] == ["operator_2"]


@pytest.mark.asyncio
async def test_mock_ticket_connector_load_initial_state_returns_initial_state_copy() -> None:
    state = AppState(
        views=[TicketView(name="delivery", title="Delivery")],
        tickets=[make_ticket("Delivery queue", name=7004)],
    )
    connector = MockTicketConnector(initial_state=state)

    loaded_state = await connector.load_initial_state()

    assert loaded_state == state
    assert loaded_state is not state
    assert connector.load_initial_state_calls == 1


@pytest.mark.asyncio
async def test_mock_ticket_connector_load_initial_state_falls_back_to_base_connector() -> None:
    view = TicketView(name="delivery", title="Delivery")
    ticket = make_ticket("Delivery queue", name=7012)
    connector = MockTicketConnector(views=[view], tickets=[ticket])

    loaded_state = await connector.load_initial_state()

    assert loaded_state == AppState(views=[view], tickets=[ticket])
    assert connector.load_initial_state_calls == 1
    assert connector.list_views_calls == 1
    assert connector.list_tickets_calls == [None]


@pytest.mark.asyncio
async def test_mock_ticket_connector_list_views_honors_delay(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    sleep_calls: list[float] = []

    async def fake_sleep(delay: float) -> None:
        sleep_calls.append(delay)

    monkeypatch.setattr(asyncio, "sleep", fake_sleep)
    connector = MockTicketConnector(
        views=[TicketView(name="delivery", title="Delivery")],
        views_delay=0.25,
    )

    views = await connector.list_views()

    assert [view.title for view in views] == ["Delivery"]
    assert sleep_calls == [0.25]


@pytest.mark.asyncio
async def test_mock_ticket_connector_list_ticket_categories_honors_delay_and_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    sleep_calls: list[float] = []

    async def fake_sleep(delay: float) -> None:
        sleep_calls.append(delay)

    monkeypatch.setattr(asyncio, "sleep", fake_sleep)
    connector = MockTicketConnector(
        categories_error=RuntimeError("boom"),
        categories_delay=0.5,
    )

    with pytest.raises(RuntimeError, match="boom"):
        await connector.list_ticket_categories()

    assert sleep_calls == [0.5]


@pytest.mark.asyncio
async def test_mock_ticket_connector_list_ticket_users_honors_delay_and_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    sleep_calls: list[float] = []

    async def fake_sleep(delay: float) -> None:
        sleep_calls.append(delay)

    monkeypatch.setattr(asyncio, "sleep", fake_sleep)
    connector = MockTicketConnector(
        users_error=RuntimeError("boom"),
        users_delay=0.4,
    )

    with pytest.raises(RuntimeError, match="boom"):
        await connector.list_ticket_users()

    assert sleep_calls == [0.4]


@pytest.mark.asyncio
async def test_mock_ticket_connector_list_ticket_activities_honors_delay_and_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    sleep_calls: list[float] = []

    async def fake_sleep(delay: float) -> None:
        sleep_calls.append(delay)

    monkeypatch.setattr(asyncio, "sleep", fake_sleep)
    ticket = make_ticket("Delivery queue", name=7015)
    connector = MockTicketConnector(
        tickets=[ticket],
        activities_error=RuntimeError("boom"),
        activities_delay=0.3,
    )

    with pytest.raises(RuntimeError, match="boom"):
        await connector.list_ticket_activities(ticket)

    assert connector.list_ticket_activities_calls == [("name", "7015")]
    assert sleep_calls == [0.3]


@pytest.mark.asyncio
async def test_mock_ticket_connector_store_ticket_honors_delay(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    sleep_calls: list[float] = []

    async def fake_sleep(delay: float) -> None:
        sleep_calls.append(delay)

    monkeypatch.setattr(asyncio, "sleep", fake_sleep)
    ticket = make_ticket("Delivery queue", name=7005)
    connector = MockTicketConnector(tickets=[ticket], store_delay=0.75)

    saved_ticket = await connector.store_ticket(
        ticket,
        TicketEditPatch(title="Updated delivery queue"),
    )

    assert saved_ticket.title == "Updated delivery queue"
    assert sleep_calls == [0.75]


@pytest.mark.asyncio
async def test_mock_ticket_connector_store_ticket_raises_when_ticket_is_missing() -> None:
    connector = MockTicketConnector(tickets=[])
    ticket = make_ticket("Missing ticket", name=7006)

    with pytest.raises(ValueError, match="not present in the mock connector"):
        await connector.store_ticket(ticket, TicketEditPatch(title="Updated"))


@pytest.mark.asyncio
async def test_mock_ticket_connector_create_ticket_comment_prepends_generated_comment() -> None:
    ticket = make_ticket("Delivery queue", name=7016)
    existing_activity = TicketActivity(type="EMAIL", title="Customer replied")
    current_user = TicketUserOption(name="operator_1", title="Operator One")
    connector = MockTicketConnector(
        tickets=[ticket],
        current_user=current_user,
    )
    connector.set_ticket_activities(ticket, [existing_activity])

    await connector.create_ticket_comment(ticket, TicketCommentCreateRequest(body="Internal note"))

    activities = await connector.list_ticket_activities(ticket)
    assert connector.create_ticket_comment_calls == [
        (ticket, TicketCommentCreateRequest(body="Internal note"))
    ]
    assert activities[0].type == ""
    assert activities[0].description == "Internal note"
    assert activities[0].user == "Operator One"
    assert activities[0].user_name == "operator_1"
    assert activities[0].time is not None
    assert activities[1] == existing_activity


@pytest.mark.asyncio
async def test_mock_ticket_connector_create_ticket_comment_creates_activity_list_when_missing() -> None:
    ticket = make_ticket("Delivery queue", name=7017)
    connector = MockTicketConnector(tickets=[ticket])

    await connector.create_ticket_comment(ticket, TicketCommentCreateRequest(body="First note"))

    activities = await connector.list_ticket_activities(ticket)
    assert len(activities) == 1
    assert activities[0].type == ""
    assert activities[0].description == "First note"
    assert activities[0].item is None


@pytest.mark.asyncio
async def test_mock_ticket_connector_create_ticket_comment_preserves_attachment_metadata_and_bytes() -> None:
    ticket = make_ticket("Delivery queue", name=70175)
    connector = MockTicketConnector(tickets=[ticket])
    request = TicketCommentCreateRequest(
        body="Attached note",
        attachments=[
            TicketCommentAttachmentUpload(
                filename="report.txt",
                content=b"alpha",
                content_type="text/plain",
            )
        ],
    )

    await connector.create_ticket_comment(ticket, request)

    activities = await connector.list_ticket_activities(ticket)
    attachment = activities[0].downloadable_attachments()[0]

    assert activities[0].description == "Attached note"
    assert attachment.title == "report.txt"
    assert attachment.type == "text/plain"
    assert attachment.size == 5
    assert await connector.load_ticket_activity_attachment(activities[0], attachment) == b"alpha"


@pytest.mark.asyncio
async def test_mock_ticket_connector_create_ticket_comment_honors_delay_and_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    slept: list[float] = []

    async def fake_sleep(delay: float) -> None:
        slept.append(delay)

    monkeypatch.setattr(asyncio, "sleep", fake_sleep)
    ticket = make_ticket("Delivery queue", name=7018)
    connector = MockTicketConnector(
        tickets=[ticket],
        comment_create_delay=0.6,
        comment_create_error=RuntimeError("boom"),
    )

    with pytest.raises(RuntimeError, match="boom"):
        await connector.create_ticket_comment(ticket, TicketCommentCreateRequest(body="Will fail"))

    assert connector.create_ticket_comment_calls == [
        (ticket, TicketCommentCreateRequest(body="Will fail"))
    ]
    assert slept == [0.6]


@pytest.mark.asyncio
async def test_mock_ticket_connector_create_ticket_comment_raises_when_ticket_is_missing() -> None:
    connector = MockTicketConnector(tickets=[])
    ticket = make_ticket("Missing ticket", name=7019)

    with pytest.raises(ValueError, match="not present in the mock connector"):
        await connector.create_ticket_comment(ticket, TicketCommentCreateRequest(body="No target"))


@pytest.mark.asyncio
async def test_mock_ticket_connector_returns_configured_ticket_email_draft() -> None:
    ticket = make_ticket("Delivery queue", name=7020)
    activity = make_email_activity()
    draft = TicketEmailDraft(
        action=TicketEmailAction.REPLY,
        source_activity_name="activities_1",
        source_email_name="emails_1",
        to="reply@example.com",
        subject="Re: Customer replied",
        body="",
        queue_name="queues_1",
    )
    connector = MockTicketConnector(tickets=[ticket])

    connector.set_ticket_email_draft(ticket, activity, TicketEmailAction.REPLY, draft)

    result = await connector.get_ticket_email_draft(ticket, activity, TicketEmailAction.REPLY)

    assert result == draft
    assert connector.get_ticket_email_draft_calls == [(ticket, activity, TicketEmailAction.REPLY)]


@pytest.mark.asyncio
async def test_mock_ticket_connector_generates_default_ticket_email_draft() -> None:
    ticket = make_ticket("Delivery queue", name=7021)
    activity = make_email_activity(title="Queue update")
    connector = MockTicketConnector(tickets=[ticket])

    draft = await connector.get_ticket_email_draft(ticket, activity, TicketEmailAction.FORWARD)

    assert draft == TicketEmailDraft(
        action=TicketEmailAction.FORWARD,
        source_activity_name="activities_1",
        source_email_name="emails_1",
        to="",
        subject="Fwd: Queue update",
        body="",
        queue_name="queues_1",
    )


@pytest.mark.asyncio
async def test_mock_ticket_connector_generates_default_reply_ticket_email_draft() -> None:
    ticket = make_ticket("Delivery queue", name=7025)
    activity = make_email_activity(title="Queue update")
    connector = MockTicketConnector(tickets=[ticket])

    draft = await connector.get_ticket_email_draft(ticket, activity, TicketEmailAction.REPLY)

    assert draft == TicketEmailDraft(
        action=TicketEmailAction.REPLY,
        source_activity_name="activities_1",
        source_email_name="emails_1",
        to="customer@example.com",
        subject="Re: Queue update",
        body="",
        queue_name="queues_1",
    )


@pytest.mark.asyncio
async def test_mock_ticket_connector_get_ticket_email_draft_honors_delay_and_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    sleep_calls: list[float] = []

    async def fake_sleep(delay: float) -> None:
        sleep_calls.append(delay)

    monkeypatch.setattr(asyncio, "sleep", fake_sleep)
    ticket = make_ticket("Delivery queue", name=7022)
    activity = make_email_activity()
    connector = MockTicketConnector(tickets=[ticket])
    connector.set_email_draft_behavior(error=RuntimeError("boom"), delay=0.35)

    with pytest.raises(RuntimeError, match="boom"):
        await connector.get_ticket_email_draft(ticket, activity, TicketEmailAction.REPLY)

    assert sleep_calls == [0.35]


@pytest.mark.asyncio
async def test_mock_ticket_connector_get_ticket_email_draft_raises_when_ticket_is_missing() -> None:
    ticket = make_ticket("Missing ticket", name=7026)
    activity = make_email_activity()
    connector = MockTicketConnector(tickets=[])

    with pytest.raises(ValueError, match="not present in the mock connector"):
        await connector.get_ticket_email_draft(ticket, activity, TicketEmailAction.REPLY)


@pytest.mark.asyncio
async def test_mock_ticket_connector_send_ticket_email_prepends_generated_email_activity() -> None:
    ticket = make_ticket("Delivery queue", name=7023)
    existing_activity = make_email_activity(activity_name="activities_existing", email_name="emails_existing")
    current_user = TicketUserOption(name="operator_1", title="Operator One")
    connector = MockTicketConnector(
        tickets=[ticket],
        current_user=current_user,
    )
    connector.set_ticket_activities(ticket, [existing_activity])

    await connector.send_ticket_email(
        ticket,
        TicketEmailSendRequest(
            action=TicketEmailAction.REPLY,
            source_email_name="emails_1",
            to="customer@example.com",
            subject="Re: Customer replied",
            body="<p>Thanks</p>",
            queue_name="queues_1",
        ),
    )

    activities = await connector.list_ticket_activities(ticket)
    assert connector.send_ticket_email_calls == [
        (
            ticket,
            TicketEmailSendRequest(
                action=TicketEmailAction.REPLY,
                source_email_name="emails_1",
                to="customer@example.com",
                subject="Re: Customer replied",
                body="<p>Thanks</p>",
                queue_name="queues_1",
            ),
        )
    ]
    assert activities[0].type == "EMAIL"
    assert activities[0].title == "Re: Customer replied"
    assert activities[0].item is not None
    assert activities[0].item.direction == "out"
    assert activities[0].item.queue_name == "queues_1"
    assert activities[0].user == "Operator One"
    assert activities[1] == existing_activity


@pytest.mark.asyncio
async def test_mock_ticket_connector_send_ticket_email_honors_delay_error_and_missing_ticket(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    sleep_calls: list[float] = []

    async def fake_sleep(delay: float) -> None:
        sleep_calls.append(delay)

    monkeypatch.setattr(asyncio, "sleep", fake_sleep)
    ticket = make_ticket("Delivery queue", name=7024)
    request = TicketEmailSendRequest(
        action=TicketEmailAction.FORWARD,
        source_email_name="emails_1",
        to="other@example.com",
        subject="Fwd: Customer replied",
        body="<p>FYI</p>",
        queue_name="queues_1",
    )
    connector = MockTicketConnector(tickets=[ticket])
    connector.set_email_send_behavior(error=RuntimeError("boom"), delay=0.45)

    with pytest.raises(RuntimeError, match="boom"):
        await connector.send_ticket_email(ticket, request)

    assert sleep_calls == [0.45]

    missing_connector = MockTicketConnector(tickets=[])
    with pytest.raises(ValueError, match="not present in the mock connector"):
        await missing_connector.send_ticket_email(ticket, request)


def test_mock_ticket_connector_prefixed_subject_helper_handles_blank_and_existing_prefix() -> None:
    assert MockTicketConnector._prefixed_subject("", "Re: ", prefixes=("re:",)) == ""
    assert (
        MockTicketConnector._prefixed_subject("Re: Existing", "Re: ", prefixes=("re:",))
        == "Re: Existing"
    )


def test_mock_ticket_connector_set_views_replaces_initial_state_and_behavior() -> None:
    connector = MockTicketConnector(
        initial_state=AppState(
            views=[TicketView(name="initial", title="Initial")],
            tickets=[make_ticket("Initial ticket", name=7007)],
        )
    )

    connector.set_views(
        [TicketView(name="delivery", title="Delivery")],
        error=RuntimeError("boom"),
        delay=0.25,
    )

    assert connector._initial_state is None
    assert [view.title for view in connector._views] == ["Delivery"]
    assert isinstance(connector._views_error, RuntimeError)
    assert connector._views_delay == 0.25


def test_mock_ticket_connector_set_default_tickets_replaces_initial_state_and_behavior() -> None:
    connector = MockTicketConnector(
        initial_state=AppState(
            views=[],
            tickets=[make_ticket("Initial ticket", name=7008)],
        )
    )

    connector.set_default_tickets(
        [make_ticket("Updated ticket", name=7009)],
        error=RuntimeError("boom"),
        delay=0.5,
    )

    assert connector._initial_state is None
    assert [ticket.title for ticket in connector._default_tickets] == ["Updated ticket"]
    assert isinstance(connector._default_tickets_error, RuntimeError)
    assert connector._default_tickets_delay == 0.5


def test_mock_ticket_connector_ticket_key_handles_name_and_missing_identity() -> None:
    tracked_ticket = Ticket(
        title="Tracked ticket",
        ticket=7011,
        category="delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )
    named_ticket = Ticket(
        title="Named ticket",
        name=7010,
        category="delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )
    anonymous_ticket = Ticket(
        title="Anonymous ticket",
        category="delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )

    assert MockTicketConnector._ticket_key(tracked_ticket) == ("ticket", "7011")
    assert MockTicketConnector._ticket_key(named_ticket) == ("name", "7010")
    assert MockTicketConnector._ticket_key(anonymous_ticket) is None


def test_mock_ticket_connector_require_ticket_key_rejects_missing_identity() -> None:
    ticket = Ticket(
        title="Anonymous ticket",
        category="delivery",
        stage=TicketStage.OPEN,
        priority=TicketPriority.HIGH,
    )

    with pytest.raises(ValueError, match="either ticket or name"):
        MockTicketConnector._require_ticket_key(ticket)


def test_mock_ticket_connector_replace_ticket_preserves_unmatched_rows() -> None:
    ticket = make_ticket("Delivery queue", name=7011)
    replacement = make_ticket("Updated queue", name=7012)

    updated, replaced = MockTicketConnector._replace_ticket(
        [ticket],
        ("name", "9999"),
        replacement,
    )

    assert replaced is False
    assert updated == [ticket]
    assert updated[0] is not ticket


def test_demo_ticket_connector_build_current_user_falls_back_to_first_user(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fallback_user = TicketUserOption(name="operator_alice", title="Operator Alice")

    monkeypatch.setattr(
        DemoTicketConnector,
        "build_ticket_users",
        classmethod(lambda cls: [fallback_user]),
    )

    assert DemoTicketConnector.build_current_user() == fallback_user


@pytest.mark.asyncio
async def test_demo_ticket_connector_provides_seeded_comment_activities() -> None:
    connector = DemoTicketConnector()
    ticket = next(ticket for ticket in connector.build_tickets() if ticket.name == 2201)

    activities = await connector.list_ticket_activities(ticket)

    assert activities
    assert any(activity.display_type == "Comment" for activity in activities)


@pytest.mark.asyncio
async def test_demo_ticket_connector_create_ticket_comment_updates_subsequent_activity_reads() -> None:
    connector = DemoTicketConnector()
    ticket = next(ticket for ticket in connector.build_tickets() if ticket.name == 2201)

    before = await connector.list_ticket_activities(ticket)
    await connector.create_ticket_comment(
        ticket,
        TicketCommentCreateRequest(body="Followed up with finance."),
    )
    after = await connector.list_ticket_activities(ticket)

    assert len(after) == len(before) + 1
    assert after[0].description == "Followed up with finance."
    assert after[0].display_type == "Comment"


@pytest.mark.asyncio
async def test_demo_ticket_connector_returns_seeded_email_drafts() -> None:
    connector = DemoTicketConnector()
    ticket = next(ticket for ticket in connector.build_tickets() if ticket.name == 2101)
    activity = (await connector.list_ticket_activities(ticket))[0]

    reply_draft = await connector.get_ticket_email_draft(ticket, activity, TicketEmailAction.REPLY)
    forward_draft = await connector.get_ticket_email_draft(ticket, activity, TicketEmailAction.FORWARD)

    assert reply_draft.to == "zion-ops@matrix.invalid, niobe@matrix.invalid"
    assert reply_draft.subject == "Re: Sentinel sweep over Zion"
    assert "Dock 12" in reply_draft.body
    assert forward_draft.to == "lock@matrix.invalid"
    assert forward_draft.subject == "Fwd: Sentinel sweep over Zion"


@pytest.mark.asyncio
async def test_demo_ticket_connector_matrix_hero_ticket_has_markdown_showcase_activities() -> None:
    connector = DemoTicketConnector()
    ticket = next(ticket for ticket in connector.build_tickets() if ticket.name == 2101)

    activities = await connector.list_ticket_activities(ticket)
    markdown_bodies = [activity.body_markdown() for activity in activities]

    assert len(activities) >= 5
    assert any(body and "* Reroute the freight line" in body for body in markdown_bodies)
    assert any(body and "1. Trace sentinel perimeter" in body for body in markdown_bodies)
    assert any(body and "| Lane | Status | Owner |" in body for body in markdown_bodies)
    assert any(
        body and "> There is no spoon. There is only the lane we hold." in body and "```" in body
        for body in markdown_bodies
    )


@pytest.mark.asyncio
async def test_demo_ticket_connector_resolves_seeded_assets_and_attachments() -> None:
    connector = DemoTicketConnector()
    ticket = next(ticket for ticket in connector.build_tickets() if ticket.name == 2001)
    activity = (await connector.list_ticket_activities(ticket))[0]
    attachment = activity.downloadable_attachments()[0]

    resolved_url = connector.resolve_activity_asset_url("/assets/demo/hl2-strider.png")
    attachment_bytes = await connector.load_ticket_activity_attachment(activity, attachment)
    image_bytes = await connector.load_activity_asset(
        "https://demo.invalid/assets/hl2-strider.png?accessToken=demo"
    )

    assert resolved_url == "https://demo.invalid/assets/hl2-strider.png?accessToken=demo"
    assert b"Marker: strider" in attachment_bytes
    assert image_bytes


@pytest.mark.asyncio
async def test_demo_ticket_connector_lotr_hero_ticket_resolves_seeded_image_asset() -> None:
    connector = DemoTicketConnector()
    ticket = next(ticket for ticket in connector.build_tickets() if ticket.name == 2301)
    activities = await connector.list_ticket_activities(ticket)
    activity = activities[0]
    expected_image_bytes = files("daktela_paleo").joinpath("assets", "courier-trail.png").read_bytes()

    resolved_url = connector.resolve_activity_asset_url("/assets/demo/lotr-courier-trail.png")

    assert len(activities) >= 4
    assert activity.body_text() == "Aragorn sent a field sketch before dawn to mark the courier trail."
    assert any(
        fragment.alt == "Courier trail sketch"
        for fragment in activity.body_fragments() or ()
        if fragment.kind == "image"
    )
    markdown_bodies = [seeded_activity.body_markdown() for seeded_activity in activities]
    assert any(body and "* Fresh relay horse waiting beyond the east gate" in body for body in markdown_bodies)
    assert any(body and "1. Cut north through the hedgerows beyond Bree" in body for body in markdown_bodies)
    assert any(
        body and "| Waystation | Signal | Keeper |" in body and "| Bree gate | Amber |" in body
        for body in markdown_bodies
    )
    assert resolved_url == "https://demo.invalid/assets/lotr-courier-trail.png?accessToken=demo"
    assert resolved_url is not None
    assert await connector.load_activity_asset(resolved_url) == expected_image_bytes


def test_demo_ticket_connector_loads_courier_trail_from_packaged_resource() -> None:
    expected_image_bytes = files("daktela_paleo").joinpath("assets", "courier-trail.png").read_bytes()

    assert demo_module._load_demo_asset_bytes("courier-trail.png") == expected_image_bytes


def test_demo_ticket_connector_returns_browser_urls_for_views_and_tickets() -> None:
    connector = DemoTicketConnector()
    view = next(view for view in connector.build_views() if view.name == "matrix_zion")
    ticket = next(ticket for ticket in connector.build_tickets() if ticket.name == 2101)
    nameless_ticket = Ticket(
        title="Nameless ticket",
        category="Field Ops",
        category_name="Field Ops",
        stage=TicketStage.OPEN,
        priority=TicketPriority.LOW,
    )

    assert connector.view_browser_url(view) == "https://demo.invalid/views/matrix_zion"
    assert connector.ticket_browser_url(ticket) == "https://demo.invalid/tickets/2101"
    assert connector.view_browser_url(TicketView(title="No name")) is None
    assert connector.ticket_browser_url(nameless_ticket) is None


def test_demo_ticket_connector_seed_activity_attachments_skips_unknown_payloads() -> None:
    connector = DemoTicketConnector()
    connector._ticket_activities[("name", "9999")] = [
        TicketActivity.model_validate(
            {
                "name": "activities_unknown",
                "type": "",
                "attachments": [{"file": "missing-demo-payload", "title": "missing.txt"}],
            }
        )
    ]

    connector._seed_activity_attachments()

    assert connector.load_ticket_activity_attachment_calls == []


@pytest.mark.asyncio
async def test_mock_ticket_connector_list_ticket_statuses_waits_and_raises_configured_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = MockTicketConnector()
    slept: list[float] = []

    async def fake_sleep(delay: float) -> None:
        slept.append(delay)

    monkeypatch.setattr(asyncio, "sleep", fake_sleep)
    connector.set_ticket_statuses("delivery", [], error=RuntimeError("boom"), delay=0.25)

    with pytest.raises(RuntimeError, match="boom"):
        await connector.list_ticket_statuses("delivery")

    assert slept == [0.25]


@pytest.mark.asyncio
async def test_mock_ticket_connector_get_current_user_waits_and_raises_configured_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    connector = MockTicketConnector()
    slept: list[float] = []

    async def fake_sleep(delay: float) -> None:
        slept.append(delay)

    monkeypatch.setattr(asyncio, "sleep", fake_sleep)
    connector.set_current_user(None, error=RuntimeError("boom"), delay=0.5)

    with pytest.raises(RuntimeError, match="boom"):
        await connector.get_current_user()

    assert slept == [0.5]


def test_mock_ticket_connector_set_ticket_activities_stores_per_ticket_error() -> None:
    connector = MockTicketConnector()
    ticket = make_ticket("Delivery queue", name=7013)
    error = RuntimeError("boom")

    connector.set_ticket_activities(ticket, [], error=error)

    assert connector._activity_errors_by_ticket[("name", "7013")] is error
