# Contributing

`README.md` is the public landing page and PyPI long description for the package. Keep it short and user-facing. Put contributor workflow, release process, and maintenance details here or in the structured docs under `docs/`.

## Start Here

- `docs/index.md` is the documentation site overview.
- `docs/getting-started.md` covers contributor setup and daily commands.
- `docs/interaction-model.md` explains the keyboard-first UI rules.
- `docs/contributing.md` covers documentation workflow.

## Requirements

- `uv`
- Python `3.12` or newer available through `uv`

## Local Setup

Create the virtual environment:

```bash
uv venv --python 3.14 .venv
```

The project supports Python `3.12` and newer. Keep `3.14` as the default development interpreter unless you specifically need to validate compatibility on `3.12`:

```bash
uv venv --python 3.12 .venv
```

Install the project and development dependencies:

```bash
uv sync --group dev
```

Run the application:

```bash
uv run daktela-paleo
```

If a saved active Daktela instance exists, the app will load it on startup. Use `c` to open the instance manager and switch between saved Daktela instances.

## Quality Checks

Run the full test suite locally:

```bash
uv run pytest
```

`pytest` runs with 8 workers by default via `pytest-xdist`.

Run a single test file:

```bash
uv run pytest tests/test_app.py
```

Run the lint, type check, and coverage targets:

```bash
make ruff
make pyright
make coverage
```

Run focused coverage for a test file and a covered source file:

```bash
make coverage tests/test_app.py src/daktela_paleo/app.py
```

## Documentation Workflow

Serve the documentation locally:

```bash
make docs-serve
```

Build the documentation locally:

```bash
make docs-build
```

Structured project documentation should live under `docs/` and be registered in `mkdocs.yml`.

## Release Workflow

Build and validate the distributable artifacts locally:

```bash
make clean build check-wheel check-dist
```

Prepare and publish a CI-style release from a disposable checkout:

```bash
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=<pypi-token>
make release RELEASE_TAG=v0.0.2
```

`make update-version` and `make release` rewrite `[project].version` in `pyproject.toml` from `RELEASE_TAG` or `CI_COMMIT_TAG`. Use them in CI or a temporary checkout rather than in a long-lived working tree.

Tag push pipelines run:

```bash
make clean update-version build check-wheel check-dist RELEASE_TAG="$CI_COMMIT_TAG"
make publish
```

Before the first official PyPI release, create a PyPI account with 2FA enabled, generate an upload token, and add it to the GitLab project as a protected masked `PYPI_TOKEN` CI/CD variable. The release job exports `TWINE_USERNAME=__token__` and `TWINE_PASSWORD=$PYPI_TOKEN` before calling `make publish`.

Trigger the GitLab release pipeline by pushing a tag:

```bash
git tag v0.0.2
git push origin v0.0.2
```

## Git Worktrees

This repository includes a helper workflow for creating bootstrapped git worktrees for feature branches.

Create a worktree from the primary checkout root on `main`:

```bash
make worktree create <branch-name>
```

This workflow requires a clean primary checkout, fast-forwards local `main` to `origin/main`, creates `worktrees/<branch-name>`, creates a Python virtual environment, runs `uv sync --group dev`, approves `.envrc` with `direnv`, and opens a shell in the new worktree when run interactively.

Remove a worktree from the primary checkout root:

```bash
make worktree delete <branch-name>
```

List all worktrees from any checkout in the repository:

```bash
make worktree list
```

Check whether every non-`main` worktree branch has already been merged into the local `main` branch:

```bash
make worktree check
```

Clean every non-`main` worktree only when the primary checkout is on `main`, `HEAD`, local `main`, and `origin/main` all point to the same commit, every listed worktree is clean, every non-`main` branched worktree is already merged into local `main`, and no detached non-`main` worktrees exist:

```bash
make worktree clean
```
