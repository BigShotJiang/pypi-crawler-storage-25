#!/usr/bin/env python3

from __future__ import annotations

import argparse
import os
import re
from pathlib import Path
from typing import Any, cast

from tomlkit import dumps, parse

TAG_PATTERN = re.compile(r"^v?(?P<version>\d+\.\d+\.\d+)$")

def resolve_release_version(raw_tag: str | None) -> tuple[str | None, int, str | None]:
    """Normalize release tags like `v1.2.3` into package versions."""

    if raw_tag is None or not raw_tag.strip():
        return None, 3, "missing release tag; pass --tag or set RELEASE_TAG / CI_COMMIT_TAG"

    match = TAG_PATTERN.fullmatch(raw_tag.strip())
    if match is None:
        return None, 4, f"invalid release tag {raw_tag!r}; expected vX.Y.Z or X.Y.Z"

    return match.group("version"), 0, None


def update_pyproject_version(pyproject_path: Path, new_version: str) -> tuple[int, str | None]:
    """Rewrite `[project].version` in the provided pyproject file."""

    if not pyproject_path.exists():
        return 2, f"{pyproject_path} not found"

    try:
        document = parse(pyproject_path.read_text(encoding="utf-8"))
        project = document.get("project")
        if project is None:
            return 4, "missing [project] table in pyproject.toml"

        cast(dict[str, Any], project)["version"] = new_version
        pyproject_path.write_text(dumps(document), encoding="utf-8", newline="\n")
        return 0, None
    except Exception as error:  # pragma: no cover - defensive fallback
        return 5, f"failed to update pyproject.toml: {error}"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tag", help="Release tag in X.Y.Z or vX.Y.Z format")
    parser.add_argument("--pyproject", default="pyproject.toml", help="Path to pyproject.toml")
    arguments = parser.parse_args()

    raw_tag = arguments.tag or os.getenv("RELEASE_TAG") or os.getenv("CI_COMMIT_TAG")
    version, exit_code, error = resolve_release_version(raw_tag)
    if exit_code != 0:
        print(f"ERROR: {error}")
        return exit_code
    if version is None:
        print("ERROR: failed to compute a release version")
        return 3

    exit_code, error = update_pyproject_version(Path(arguments.pyproject), version)
    if exit_code != 0:
        print(f"ERROR: {error}")
        return exit_code

    print(version)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
