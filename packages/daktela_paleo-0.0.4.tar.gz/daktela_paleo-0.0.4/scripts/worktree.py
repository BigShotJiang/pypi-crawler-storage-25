from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from collections.abc import Sequence
from pathlib import Path


class WorktreeError(Exception):
    def __init__(self, message: str, exit_code: int = 1) -> None:
        super().__init__(message)
        self.exit_code = exit_code


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Manage bootstrapped git worktrees.")
    parser.add_argument("command", choices=("create", "delete", "list", "check", "clean"), nargs="?")
    parser.add_argument("args", nargs="*")
    return parser.parse_args(argv)


def usage_for(command: str | None) -> str:
    if command == "create":
        return "Usage: make worktree create <branch-name>"
    if command == "delete":
        return "Usage: make worktree delete <branch-name>"
    if command == "list":
        return "Usage: make worktree list"
    if command == "check":
        return "Usage: make worktree check"
    if command == "clean":
        return "Usage: make worktree clean"
    return "Usage: make worktree <create|delete|list|check|clean> [args...]"


def require_single_branch(command: str, args: Sequence[str]) -> str:
    if len(args) != 1:
        raise WorktreeError(usage_for(command))
    return args[0]


def require_no_args(command: str, args: Sequence[str]) -> None:
    if args:
        raise WorktreeError(usage_for(command))


def _display_path(path: Path) -> str:
    try:
        return path.relative_to(Path.cwd()).as_posix()
    except ValueError:
        return str(path)


def run_checked(
    args: Sequence[str],
    *,
    cwd: Path | None = None,
    env: dict[str, str] | None = None,
) -> None:
    try:
        subprocess.run(args, cwd=cwd, env=env, check=True)  # noqa: S603
    except FileNotFoundError as exc:
        raise WorktreeError(f"Required command not found: {args[0]}") from exc
    except subprocess.CalledProcessError as exc:
        raise WorktreeError(
            f"Command failed ({exc.returncode}): {' '.join(args)}",
            exit_code=exc.returncode or 1,
        ) from exc


def capture_stdout(
    args: Sequence[str],
    *,
    cwd: Path | None = None,
    env: dict[str, str] | None = None,
) -> str:
    try:
        result = subprocess.run(  # noqa: S603
            args,
            cwd=cwd,
            env=env,
            check=False,
            capture_output=True,
            text=True,
        )
    except FileNotFoundError as exc:
        raise WorktreeError(f"Required command not found: {args[0]}") from exc

    if result.returncode != 0:
        raise WorktreeError(
            result.stderr.strip()
            or f"Command failed ({result.returncode}): {' '.join(args)}",
            exit_code=result.returncode or 1,
        )
    return result.stdout.strip()


def command_succeeds(
    args: Sequence[str],
    *,
    cwd: Path | None = None,
    env: dict[str, str] | None = None,
) -> bool:
    try:
        result = subprocess.run(  # noqa: S603
            args,
            cwd=cwd,
            env=env,
            check=False,
            capture_output=True,
            text=True,
        )
    except FileNotFoundError as exc:
        raise WorktreeError(f"Required command not found: {args[0]}") from exc
    return result.returncode == 0


def require_primary_checkout_root(repo_root: Path) -> None:
    if not (repo_root / ".git").is_dir():
        raise WorktreeError(
            "Run this target from the primary checkout root, not from a linked worktree."
        )


def require_current_branch(expected_branch: str) -> None:
    current_branch = capture_stdout(["git", "branch", "--show-current"])
    if current_branch != expected_branch:
        raise WorktreeError(f"Current branch must be {expected_branch} (found {current_branch}).")


def validate_branch_name(branch: str) -> None:
    if not command_succeeds(["git", "check-ref-format", "--branch", branch]):
        raise WorktreeError(f"Invalid branch name: {branch}")


def build_tool_env() -> dict[str, str]:
    env = os.environ.copy()
    env.pop("VIRTUAL_ENV", None)
    return env


def ensure_shared_backlog_symlink(repo_root: Path, target_dir: Path) -> None:
    shared_backlog = repo_root / "backlog"
    if not shared_backlog.is_dir():
        raise WorktreeError(
            f"Shared backlog directory not found: {_display_path(shared_backlog)}"
        )

    link_path = target_dir / "backlog"
    relative_target = Path(os.path.relpath(shared_backlog, target_dir))

    if link_path.is_symlink():
        current_target = Path(os.readlink(link_path))
        if current_target == relative_target:
            return
        link_path.unlink()
    elif link_path.exists():
        if link_path.is_dir():
            shutil.rmtree(link_path)
        else:
            link_path.unlink()

    link_path.symlink_to(relative_target, target_is_directory=True)


def stream_is_tty(stream: object) -> bool:
    isatty = getattr(stream, "isatty", None)
    return bool(callable(isatty) and isatty())


def maybe_open_shell(target_dir: Path) -> None:
    if not stream_is_tty(sys.stdin) or not stream_is_tty(sys.stdout):
        return

    print(f"Opening a shell in {_display_path(target_dir)}. Exit that shell to return here.")
    shell = os.environ.get("SHELL", "/bin/zsh")
    os.chdir(target_dir)
    try:
        os.execvpe(shell, [shell, "-l"], os.environ.copy())  # noqa: S606
    except OSError as exc:
        raise WorktreeError(f"Failed to open shell {shell}: {exc}") from exc


def validate_create_prerequisites(repo_root: Path, target_dir: Path, branch: str) -> None:
    require_primary_checkout_root(repo_root)
    require_current_branch("main")

    if capture_stdout(["git", "status", "--short"]):
        raise WorktreeError("Primary checkout must be clean before creating a worktree.")

    validate_branch_name(branch)

    if command_succeeds(["git", "show-ref", "--verify", "--quiet", f"refs/heads/{branch}"]):
        raise WorktreeError(f"Local branch already exists: {branch}")

    if command_succeeds(["git", "ls-remote", "--exit-code", "--heads", "origin", branch]):
        raise WorktreeError(f"Remote branch already exists on origin: {branch}")

    if target_dir.exists():
        raise WorktreeError(f"Target directory already exists: {_display_path(target_dir)}")


def ensure_main_is_up_to_date() -> None:
    print("Fetching origin/main...")
    run_checked(["git", "fetch", "origin", "main"])

    if not command_succeeds(["git", "merge-base", "--is-ancestor", "main", "origin/main"]):
        raise WorktreeError("Local main cannot be fast-forwarded cleanly to origin/main.")

    if not command_succeeds(["git", "merge-base", "--is-ancestor", "HEAD", "origin/main"]):
        raise WorktreeError("Current HEAD cannot be fast-forwarded cleanly to origin/main.")

    main_sha = capture_stdout(["git", "rev-parse", "main"])
    origin_main_sha = capture_stdout(["git", "rev-parse", "origin/main"])
    if main_sha != origin_main_sha:
        print("Fast-forwarding local main to origin/main...")
        run_checked(["git", "merge", "--ff-only", "origin/main"])


def bootstrap_worktree(target_dir: Path) -> None:
    tool_env = build_tool_env()

    venv_dir = target_dir / ".venv"
    if not venv_dir.is_dir():
        print("Creating Python virtual environment...")
        run_checked(["uv", "venv", "--python", "3.14", str(venv_dir)], env=tool_env)

    print("Syncing Python dependencies...")
    run_checked(["uv", "sync", "--group", "dev", "--directory", str(target_dir)], env=tool_env)

    if shutil.which("direnv") is None:
        raise WorktreeError(
            f"direnv is required to approve {_display_path(target_dir / '.envrc')}."
        )

    print("Approving .envrc...")
    run_checked(["direnv", "allow", "."], cwd=target_dir)


def create_worktree(branch: str) -> None:
    repo_root = Path.cwd()
    target_dir = repo_root / "worktrees" / branch

    validate_create_prerequisites(repo_root, target_dir, branch)
    ensure_main_is_up_to_date()

    target_dir.parent.mkdir(parents=True, exist_ok=True)
    print(f"Creating worktree at {_display_path(target_dir)}...")
    run_checked(["git", "worktree", "add", "-b", branch, str(target_dir), "main"])

    ensure_shared_backlog_symlink(repo_root, target_dir)
    bootstrap_worktree(target_dir)

    print(f"Worktree ready: {_display_path(target_dir)}")
    maybe_open_shell(target_dir)


def prune_empty_parent_dirs(start_dir: Path, stop_dir: Path) -> None:
    current_dir = start_dir
    while current_dir != stop_dir and current_dir.is_dir():
        try:
            current_dir.rmdir()
        except OSError:
            break
        current_dir = current_dir.parent


def _prune_repo_managed_worktree_dirs(repo_root: Path, target_dir: Path) -> None:
    worktrees_root = repo_root / "worktrees"
    if not target_dir.is_relative_to(worktrees_root):
        return
    prune_empty_parent_dirs(target_dir.parent, repo_root)


def _remove_worktree(repo_root: Path, target_dir: Path, branch: str) -> None:
    print(f"Removing worktree {_display_path(target_dir)}...")
    run_checked(["git", "worktree", "remove", str(target_dir)])

    if command_succeeds(["git", "show-ref", "--verify", "--quiet", f"refs/heads/{branch}"]):
        print(f"Deleting local branch {branch}...")
        run_checked(["git", "branch", "-D", branch])

    _prune_repo_managed_worktree_dirs(repo_root, target_dir)
    print(f"Worktree deleted: {_display_path(target_dir)}")


def delete_worktree(branch: str) -> None:
    repo_root = Path.cwd()
    target_dir = repo_root / "worktrees" / branch

    require_primary_checkout_root(repo_root)
    validate_branch_name(branch)

    if not target_dir.is_dir():
        raise WorktreeError(f"Worktree directory not found: {_display_path(target_dir)}")

    _remove_worktree(repo_root, target_dir, branch)


def _parse_worktree_list(output: str) -> list[dict[str, str]]:
    entries: list[dict[str, str]] = []
    current_entry: dict[str, str] = {}

    for line in output.splitlines():
        if not line:
            if current_entry:
                entries.append(current_entry)
                current_entry = {}
            continue

        key, _, value = line.partition(" ")
        current_entry[key] = value

    if current_entry:
        entries.append(current_entry)

    return entries


def _display_branch_name(entry: dict[str, str]) -> str:
    branch = entry.get("branch")
    if branch is None:
        return "(detached)"

    branch_prefix = "refs/heads/"
    if branch.startswith(branch_prefix):
        return branch[len(branch_prefix) :]
    return branch


def _worktree_entries() -> list[dict[str, str]]:
    output = capture_stdout(["git", "worktree", "list", "--porcelain"])
    return _parse_worktree_list(output)


def _worktree_path(entry: dict[str, str]) -> Path | None:
    worktree_path = entry.get("worktree")
    if worktree_path is None:
        return None
    return Path(worktree_path)


def _non_main_branched_worktree_entries(
    entries: Sequence[dict[str, str]],
) -> list[dict[str, str]]:
    non_main_entries: list[dict[str, str]] = []

    for entry in entries:
        if entry.get("branch") is None:
            continue
        if _display_branch_name(entry) == "main":
            continue
        if _worktree_path(entry) is None:
            continue
        non_main_entries.append(entry)

    return non_main_entries


def _detached_worktree_entries(entries: Sequence[dict[str, str]]) -> list[dict[str, str]]:
    detached_entries: list[dict[str, str]] = []

    for entry in entries:
        if entry.get("branch") is not None:
            continue
        if _worktree_path(entry) is None:
            continue
        detached_entries.append(entry)

    return detached_entries


def _worktree_is_clean(worktree_path: Path) -> bool:
    return not capture_stdout(["git", "status", "--short"], cwd=worktree_path)


def _worktree_is_merged_into_main(entry: dict[str, str]) -> bool:
    branch_ref = entry.get("branch")
    if branch_ref is None:
        return False
    return command_succeeds(["git", "merge-base", "--is-ancestor", branch_ref, "main"])


def list_worktrees() -> None:
    for entry in _worktree_entries():
        worktree_path = entry.get("worktree")
        if worktree_path is None:
            continue
        print(f"{_display_branch_name(entry)}\t{worktree_path}")


def check_worktrees() -> None:
    has_unmerged = False

    for entry in _non_main_branched_worktree_entries(_worktree_entries()):
        worktree_path = _worktree_path(entry)
        if worktree_path is None:
            continue

        branch_name = _display_branch_name(entry)
        is_merged = _worktree_is_merged_into_main(entry)
        status = "merged" if is_merged else "unmerged"
        print(f"{status}\t{branch_name}\t{worktree_path}")
        has_unmerged = has_unmerged or not is_merged

    if has_unmerged:
        raise WorktreeError("Found worktrees not merged into main.")


def _validate_clean_prerequisites(repo_root: Path) -> list[dict[str, str]]:
    require_primary_checkout_root(repo_root)
    require_current_branch("main")

    print("Fetching origin/main...")
    run_checked(["git", "fetch", "origin", "main"])

    head_sha = capture_stdout(["git", "rev-parse", "HEAD"])
    main_sha = capture_stdout(["git", "rev-parse", "main"])
    origin_main_sha = capture_stdout(["git", "rev-parse", "origin/main"])
    if head_sha != main_sha or main_sha != origin_main_sha:
        raise WorktreeError(
            "Current HEAD, local main, and origin/main must point to the same commit."
        )

    entries = _worktree_entries()
    for entry in entries:
        worktree_path = _worktree_path(entry)
        if worktree_path is None:
            continue
        if not _worktree_is_clean(worktree_path):
            raise WorktreeError(
                f"Worktree must be clean before cleanup: {_display_path(worktree_path)}"
            )

    detached_entries = _detached_worktree_entries(entries)
    if detached_entries:
        detached_path = _worktree_path(detached_entries[0])
        if detached_path is not None:
            raise WorktreeError(
                f"Detached worktree cannot be cleaned safely: {_display_path(detached_path)}"
            )

    cleanup_targets = _non_main_branched_worktree_entries(entries)
    for entry in cleanup_targets:
        if not _worktree_is_merged_into_main(entry):
            raise WorktreeError(
                f"Worktree branch is not merged into main: {_display_branch_name(entry)}"
            )

    return cleanup_targets


def clean_worktrees() -> None:
    repo_root = Path.cwd()
    cleanup_targets = _validate_clean_prerequisites(repo_root)
    if not cleanup_targets:
        print("No worktrees to clean.")
        return

    cleaned_count = 0
    for entry in cleanup_targets:
        target_dir = _worktree_path(entry)
        if target_dir is None:
            continue
        _remove_worktree(repo_root, target_dir, _display_branch_name(entry))
        cleaned_count += 1

    print(f"Cleaned {cleaned_count} worktrees.")


def main(argv: Sequence[str] | None = None) -> int:
    try:
        args = parse_args(argv)
        if args.command is None:
            raise WorktreeError(usage_for(None))

        if args.command == "create":
            branch = require_single_branch(args.command, args.args)
            create_worktree(branch)
        elif args.command == "delete":
            branch = require_single_branch(args.command, args.args)
            delete_worktree(branch)
        elif args.command == "list":
            require_no_args(args.command, args.args)
            list_worktrees()
        elif args.command == "check":
            require_no_args(args.command, args.args)
            check_worktrees()
        else:
            require_no_args(args.command, args.args)
            clean_worktrees()
        return 0
    except WorktreeError as exc:
        print(exc, file=sys.stderr)
        return exc.exit_code


if __name__ == "__main__":
    raise SystemExit(main())
