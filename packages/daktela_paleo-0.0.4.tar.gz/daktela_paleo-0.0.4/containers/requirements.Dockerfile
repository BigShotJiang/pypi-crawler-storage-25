FROM python:3.14

ENV PATH="/root/.local/bin:/app/.venv/bin:${PATH}"

RUN apt-get update && apt-get install -y --no-install-recommends \
      ca-certificates \
      curl \
      libatomic1 \
      make \
    && rm -rf /var/lib/apt/lists/*

WORKDIR /app

RUN curl -LsSf https://astral.sh/uv/install.sh | sh \
    && ln -s /root/.local/bin/uv /usr/local/bin/uv \
    && uv --version

COPY pyproject.toml uv.lock ./

RUN uv sync --frozen --group dev --no-install-project \
    && /app/.venv/bin/pyright --version
