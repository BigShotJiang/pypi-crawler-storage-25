"""SBOM API endpoints."""

import logging

from fastapi import APIRouter, Depends, HTTPException, Query

from ..auth import require_scope
from ..database import get_all_sboms, get_sbom, get_sboms_for_scan, save_sbom
from ..sbom import SBOMGenerator

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/sbom", tags=["sbom"])


@router.post("/generate", dependencies=[Depends(require_scope("write"))])
async def generate_sbom(
    target_path: str = Query(..., description="Path to the project directory"),
    format: str = Query("cyclonedx", description="Export format: cyclonedx or spdx"),
    scan_id: str | None = Query(None, description="Linked scan ID"),
):
    """Generate an SBOM for the given target path, save it to the database, and return the result."""
    if format not in ("cyclonedx", "spdx"):
        raise HTTPException(status_code=400, detail="format must be 'cyclonedx' or 'spdx'")

    generator = SBOMGenerator(target_path=target_path, scan_id=scan_id)
    try:
        doc = await generator.generate()
    except Exception as exc:
        logger.exception("SBOM generation failed for %s", target_path)
        raise HTTPException(status_code=500, detail=f"SBOM generation failed: {exc}") from exc

    doc.format = format
    await save_sbom(doc)

    if format == "cyclonedx":
        exported = generator.export_cyclonedx(doc)
    else:
        exported = generator.export_spdx(doc)

    return {
        "sbom_id": doc.id,
        "format": format,
        "component_count": len(doc.components),
        "document": exported,
    }


@router.get("/history", dependencies=[Depends(require_scope("read"))])
async def list_sboms():
    """List all previously generated SBOMs with metadata and component counts."""
    return await get_all_sboms()


@router.get("/{sbom_id}", dependencies=[Depends(require_scope("read"))])
async def get_sbom_document(sbom_id: str):
    """Retrieve a stored SBOM document by ID."""
    doc = await get_sbom(sbom_id)
    if doc is None:
        raise HTTPException(status_code=404, detail="SBOM not found")
    return doc


@router.get("/{sbom_id}/export", dependencies=[Depends(require_scope("read"))])
async def export_sbom(
    sbom_id: str,
    format: str = Query("cyclonedx", description="Export format: cyclonedx or spdx"),
):
    """Export a stored SBOM in the specified format."""
    if format not in ("cyclonedx", "spdx"):
        raise HTTPException(status_code=400, detail="format must be 'cyclonedx' or 'spdx'")

    doc = await get_sbom(sbom_id)
    if doc is None:
        raise HTTPException(status_code=404, detail="SBOM not found")

    generator = SBOMGenerator(target_path=doc.target_path)
    if format == "cyclonedx":
        return generator.export_cyclonedx(doc)
    else:
        return generator.export_spdx(doc)


@router.get("/scan/{scan_id}", dependencies=[Depends(require_scope("read"))])
async def get_sboms_for_scan_endpoint(scan_id: str):
    """Get all SBOM documents linked to a specific scan."""
    docs = await get_sboms_for_scan(scan_id)
    return docs
