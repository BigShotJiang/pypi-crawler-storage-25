# NomosAI — Assistant juridique IA

Serveur MCP pour Claude Desktop et Claude Code. Anonymise les documents confidentiels, initialise des espaces de travail juridiques et installe des skills spécialisés pour la recherche jurisprudentielle et la rédaction de mémoires.

---

## Installation

**Étape 1 — Installer `uv` (une seule fois par machine) :**

- **Windows :** ouvre PowerShell et colle :
  ```powershell
  powershell -c "irm https://astral.sh/uv/install.ps1 | iex"
  ```
- **Mac / Linux :** ouvre Terminal et colle :
  ```bash
  curl -LsSf https://astral.sh/uv/install.sh | sh
  ```

**Étape 2 — Installer NomosAI :**

```bash
uv tool install nomos-ai
```

**Étape 3 — Connecter NomosAI à Claude :**

```bash
claude mcp add --scope user nomos-ai -- uv tool run nomos-ai
```

Ou manuellement selon ton client :

| Client | Fichier de config |
|--------|-------------------|
| **Claude Code** (CLI / VS Code) | `~/.claude/settings.json` |
| **Claude Desktop** — Windows | `%APPDATA%\Claude\claude_desktop_config.json` |
| **Claude Desktop** — Mac | `~/Library/Application Support/Claude/claude_desktop_config.json` |

```json
{
  "mcpServers": {
    "nomos-ai": {
      "command": "uv",
      "args": ["tool", "run", "nomos-ai"]
    }
  }
}
```

Redémarrer Claude.

---

## Mise à jour

```bash
uv tool upgrade nomos-ai
```

Redémarrer Claude pour que le nouveau serveur soit pris en compte.

Pour mettre à jour les skills juridiques installés, utiliser l'outil **`update_nomos_skills`** depuis Claude — il présente la liste des skills disponibles et permet de sélectionner ceux à écraser avec la version la plus récente.

---

## Fonctionnalités principales

### Espace de travail juridique — `initiate_project`

Initialise un dossier de travail structuré adapté au type de procédure (défense, demande, autre) :

- Arborescence standard (`documents-confidentiels/`, `sources/`, `documents-anonymisés/`, `livrables/`, `artefacts/`)
- `CLAUDE.md` avec les instructions adaptées au type de dossier
- Hook de sécurité qui bloque la lecture directe des documents confidentiels et force leur traitement via le MCP

### Skills juridiques — `initialise_nomos_skills` / `update_nomos_skills`

Installe ou met à jour dans `~/.claude/skills/` un ensemble de skills Claude spécialisés :

| Skill | Rôle |
|-------|------|
| `extraction-faits` | Extrait les faits pertinents d'un dossier |
| `recherche-Ccass_droit privé` | Recherche jurisprudentielle — Cour de cassation |
| `recherche-CE_droit-public` | Recherche jurisprudentielle — Conseil d'État (ArianeWeb) |
| `recherche-CEDH` | Recherche jurisprudentielle — CEDH (HUDOC) |
| `recherche-CJUE_UE` | Recherche jurisprudentielle — CJUE |
| `recherche-BOFIP_fiscal` | Recherche fiscale — BOFIP |
| `redaction-MA-cassation` | Rédaction mémoire ampliatif |
| `redaction-MD-cassation` | Rédaction mémoire en défense |
| `redaction-moyen` | Rédaction de moyens de cassation |

### Recherche ArianeWeb — `search_arianeweb` / `get_conclusion`

Interroge directement la base de jurisprudence du Conseil d'État :

- Recherche plein texte ou par numéro dans les décisions CE, CAA, Tribunal des conflits et conclusions de rapporteurs publics
- Téléchargement et extraction du texte intégral des conclusions des rapporteurs publics (PDF)

### Anonymisation — `anonymize_file` / `deanonymize_file`

Détecte et remplace les données personnelles dans les documents `.docx`, `.pdf`, `.txt`, `.md` et `.rst`, et produit un Markdown anonymisé. Supporte le français, l'anglais et cinq autres langues européennes.

---

## Formats supportés

`.docx` · `.pdf` · `.txt` · `.md` · `.rst`
