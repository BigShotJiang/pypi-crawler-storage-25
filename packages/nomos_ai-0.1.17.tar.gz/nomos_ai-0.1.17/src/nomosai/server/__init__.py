#!/usr/bin/env python3
"""
NomosAI MCP Server
==================
Expose les capacités d'anonymisation de NomosAI comme outils MCP pour agents LLM.

Transport : stdio (par défaut, compatible Claude Desktop / Claude Code)

Outils disponibles :
    anonymize_file   — traite un fichier (.docx, .pdf, .txt, .md, .rst), écrit le .md anonymisé
    list_entities    — liste les types de PII disponibles avec leurs descriptions

Usage :
    uvx nomos-ai

Configuration Claude Desktop (%APPDATA%\\Claude\\claude_desktop_config.json) :
    {
      "mcpServers": {
        "nomos-ai": {
          "command": "uvx",
          "args": ["nomos-ai"]
        }
      }
    }
"""

import subprocess
import sys
import threading

from nomosai.server._mcp import mcp

# Import tool modules to trigger @mcp.tool() registration
from nomosai.server import (  # noqa: F401
    _tools_anon,
    _project,
    _arianeweb,
    _skills,
)

# Re-export symbols for backward compatibility (tests import from nomosai.server)
from nomosai.server._analyzer import _validate_entities  # noqa: F401
from nomosai.server._index import (  # noqa: F401
    _merge_index_entries,
    _find_confidential_dir,
    _read_global_index,
    _write_global_index,
)
from nomosai.server._project import (  # noqa: F401
    _build_settings,
    _build_claude_md,
    _TEMPLATES_DIR,
    _TEMPLATE_FILES,
    initiate_project,
)
from nomosai.server._tools_anon import (  # noqa: F401
    list_entities,
    anonymize_file,
    deanonymize_file,
)
from nomosai.server._skills import update_nomos_skills  # noqa: F401


# ---------------------------------------------------------------------------
# Warm-up : charge le modèle français en arrière-plan au démarrage
# ---------------------------------------------------------------------------

def _warmup() -> None:
    # subprocess output must be suppressed: stdout is the MCP stdio channel and
    # any stray bytes corrupt the JSON-RPC stream.
    from nomosai.server._analyzer import _get_analyzer
    try:
        _get_analyzer("fr")
    except OSError:
        # spaCy model absent — download silently so no output leaks to stdout.
        subprocess.run(
            [sys.executable, "-m", "spacy", "download", "fr_core_news_lg"],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        try:
            _get_analyzer("fr")
        except Exception:
            pass
    except Exception:
        pass


threading.Thread(target=_warmup, daemon=True, name="nomos-warmup").start()


# ---------------------------------------------------------------------------
# Point d'entrée
# ---------------------------------------------------------------------------

def main():
    mcp.run()


if __name__ == "__main__":
    main()
