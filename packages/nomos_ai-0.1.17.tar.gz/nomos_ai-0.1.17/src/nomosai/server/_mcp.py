from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    name="nomos-ai",
    instructions=(
        "Serveur d'anonymisation NomosAI.\n\n"
        "CONFIDENTIALITÉ : utilisez toujours anonymize_file avec le chemin du fichier — "
        "le contenu brut ne circule jamais dans le contexte LLM.\n\n"
        "SÉLECTION DES ENTITÉS avant chaque appel à anonymize_file :\n"
        "  • Demande générique → anonymize_file(elicit_entities=True)\n"
        "    Présente 3 profils : base / avancee / personnalise\n"
        "    L'utilisateur tape son choix et confirme.\n"
        "  • Entités nommées explicitement → anonymize_file(entities=[<codes>])\n"
        "  • 'Par défaut' → anonymize_file() sans paramètre\n\n"
        "PROFILS DISPONIBLES (elicit_entities=True) :\n"
        "  base         PERSON · ORGANIZATION · EMAIL_ADDRESS · PHONE_NUMBER\n"
        "  avancee      base + FR_NIR · FR_CNI · FR_PASSPORT · FR_DRIVING_LICENSE\n"
        "               · LOCATION · FR_POSTAL_CODE · IBAN_CODE · CREDIT_CARD · URL · IP_ADDRESS\n"
        "  personnalise l'utilisateur liste ses catégories (texte libre)\n\n"
        "CODES pour entities=[...] :\n"
        "  PERSON  ORGANIZATION  EMAIL_ADDRESS  PHONE_NUMBER  LOCATION\n"
        "  IBAN_CODE  CREDIT_CARD  URL  IP_ADDRESS  MEDICAL_LICENSE\n"
        "  FR_NIR  FR_CNI  FR_PASSPORT  FR_DRIVING_LICENSE  FR_SIRET  FR_SIREN  FR_TVA  FR_POSTAL_CODE\n"
        "  DATE_TIME  FILE_PATH  (opt-in — désactivés par défaut)\n\n"
        "Formats supportés : .docx .pdf .txt .md .rst"
    ),
)