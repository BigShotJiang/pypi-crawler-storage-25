import io
import json
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Optional

from pdfminer.high_level import extract_text as _pdf_extract_text

from nomosai.server._mcp import mcp
from nomosai.server._index import _find_artefacts_dir

_AW_SEARCH_URL = "https://www.conseil-etat.fr/xsearch"
_AW_CONCLUSION_BASE = "https://www.conseil-etat.fr/fr/arianeweb/CRP/conclusion"
_AW_UA = "Mozilla/5.0 (compatible; NomosAI/1.0)"
_AW_VALID_FUNDS = {"AW_DCE", "AW_DCA", "AW_DTC", "AW_CRP", "AW_AJCE", "AW_AJTC"}


def _aw_fetch(params: dict) -> dict:
    url = _AW_SEARCH_URL + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": _AW_UA})
    with urllib.request.urlopen(req, timeout=20) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _aw_doc_to_dict(doc: dict) -> dict:
    date_raw = doc.get("SourceDateTime1", "")
    return {
        "id": doc.get("Id", ""),
        "collection": doc.get("Collection", ""),
        "numero": doc.get("SourceStr5", ""),
        "numeros": doc.get("SourceCsv1", ""),
        "juridiction": doc.get("SourceStr3", ""),
        "formation": doc.get("SourceStr7", ""),
        "date": date_raw[:10] if date_raw else "",
        "solution": doc.get("SourceStr12", ""),
        "publication": doc.get("SourceStr8", ""),
        "procedure": doc.get("SourceStr9", ""),
        "ecli": doc.get("SourceStr30", ""),
        "pcja_codes": doc.get("SourceCsv3", ""),
        "resume": doc.get("SourceStr21", ""),
        "linked_decision": doc.get("SourceCsv2", ""),
    }


@mcp.tool()
def search_arianeweb(
    query: Optional[str] = None,
    numero: Optional[str] = None,
    fund: str = "AW_DCE",
    page_size: int = 10,
    offset: int = 0,
    pcja: Optional[str] = None,
) -> dict:
    """
    Recherche dans la base ArianeWeb du Conseil d'État.

    Interroge l'API xsearch et retourne les métadonnées structurées des décisions
    ou conclusions. Remplace les appels WebFetch manuels à l'API xsearch.

    Args:
        query: Termes de recherche plein texte (ex. : "responsabilité puissance publique").
        numero: Numéro de requête (ex. : "489441"). Prioritaire sur query.
        fund: Fond de jurisprudence :
              "AW_DCE"  — Décisions CE (défaut)
              "AW_DCA"  — Décisions CAA
              "AW_DTC"  — Tribunal des conflits
              "AW_CRP"  — Conclusions des rapporteurs publics
        page_size: Résultats par page (défaut 10, max 50).
        offset: Décalage pour la pagination (défaut 0).
        pcja: Code PCJA pour filtrer par rubrique (ex. : "60-01-02-01").
              Match exact sur la valeur — ne remonte pas les sous-rubriques.

    Returns:
        dict avec : success, total, fund, documents (liste de métadonnées).
        Chaque document expose : numero, numeros, juridiction, formation, date,
        solution, publication, procedure, ecli, pcja_codes, resume, linked_decision.
    """
    if not query and not numero and not pcja:
        return {"success": False, "error": "Au moins un paramètre parmi query, numero, pcja est requis."}

    if fund not in _AW_VALID_FUNDS:
        return {"success": False, "error": f"Fund inconnu : '{fund}'. Valeurs : {sorted(_AW_VALID_FUNDS)}"}

    params: dict = {
        "advanced": "1",
        "type": "json",
        "SourceStr4": fund,
        "SkipCount": str(min(page_size, 50)),
        "SkipFrom": str(offset),
        "sort": "SourceDateTime1.desc",
        "synonyms": "true",
        "scmode": "smart",
    }
    if query:
        params["text.add"] = query
    if numero:
        params["sourcecsv1"] = numero
    if pcja:
        params["sourcecsv3"] = pcja

    try:
        data = _aw_fetch(params)
    except Exception as e:
        return {"success": False, "error": f"Erreur réseau ArianeWeb : {e}"}

    return {
        "success": True,
        "total": data.get("TotalCount", 0),
        "page_size": page_size,
        "offset": offset,
        "fund": fund,
        "documents": [_aw_doc_to_dict(d) for d in data.get("Documents", [])],
    }


@mcp.tool()
def get_conclusion(numero: str, output_dir: Optional[str] = None) -> dict:
    """
    Télécharge et extrait le texte intégral des conclusions du rapporteur public
    pour un numéro de requête CE.

    Interroge ArianeWeb CRP pour obtenir la date et les métadonnées, télécharge
    le PDF officiel, puis en extrait le texte complet via pdfminer.

    Args:
        numero: Numéro de requête principal (ex. : "368082"). Si la conclusion
                couvre plusieurs requêtes jointes, n'importe lequel suffit.
        output_dir: Répertoire où sauvegarder le PDF. Si absent, le PDF est
                    enregistré dans le dossier artefacts/ du projet NomosAI
                    courant (détecté automatiquement).

    Returns:
        dict avec : success, numero, numeros, date, ecli, formation, publication,
        linked_decision, resume, pdf_url, saved_pdf_path, text, copyright.
        Le champ text contient le texte intégral des conclusions.
        saved_pdf_path est null si aucun dossier de destination n'a été trouvé.
    """
    # --- Métadonnées CRP ---
    try:
        data = _aw_fetch({
            "advanced": "1",
            "type": "json",
            "SourceStr4": "AW_CRP",
            "sourcecsv1": numero,
            "SkipCount": "1",
            "SkipFrom": "0",
        })
    except Exception as e:
        return {"success": False, "error": f"Erreur API ArianeWeb : {e}"}

    docs = data.get("Documents", [])
    if not docs:
        return {"success": False, "error": f"Aucune conclusion trouvée pour le n° {numero} dans AW_CRP."}

    doc = docs[0]
    date_raw = doc.get("SourceDateTime1", "")
    date_str = date_raw[:10] if date_raw else ""

    if not date_str:
        return {"success": False, "error": "Date des conclusions introuvable dans les métadonnées."}

    # SourceStr5 est le numéro canonique (peut différer si l'entrée était un numéro joint)
    primary = doc.get("SourceStr5", numero)

    # --- Téléchargement du PDF ---
    pdf_url = f"{_AW_CONCLUSION_BASE}/{date_str}/{primary}?download_pdf="
    try:
        req = urllib.request.Request(pdf_url, headers={"User-Agent": _AW_UA})
        with urllib.request.urlopen(req, timeout=30) as resp:
            pdf_bytes = resp.read()
    except Exception as e:
        return {"success": False, "error": f"Erreur téléchargement PDF ({pdf_url}) : {e}"}

    # --- Extraction du texte ---
    try:
        text = _pdf_extract_text(io.BytesIO(pdf_bytes))
    except Exception as e:
        return {"success": False, "error": f"Erreur extraction texte PDF : {e}"}

    # --- Sauvegarde du PDF ---
    saved_pdf_path: Optional[str] = None
    save_dir = Path(output_dir).resolve() if output_dir else _find_artefacts_dir()
    if save_dir:
        try:
            save_dir.mkdir(parents=True, exist_ok=True)
            dest = save_dir / f"conclusions_{primary}_{date_str}.pdf"
            dest.write_bytes(pdf_bytes)
            saved_pdf_path = str(dest)
        except Exception:
            pass  # non bloquant

    return {
        "success": True,
        "numero": primary,
        "numeros": doc.get("SourceCsv1", primary),
        "date": date_str,
        "ecli": doc.get("SourceStr30", ""),
        "formation": doc.get("SourceStr7", ""),
        "publication": doc.get("SourceStr8", ""),
        "linked_decision": doc.get("SourceCsv2", ""),
        "resume": doc.get("SourceStr21", ""),
        "pdf_url": pdf_url,
        "saved_pdf_path": saved_pdf_path,
        "text": text.strip(),
        "copyright": (
            "Ces conclusions ne sont pas libres de droits. Leur citation doit respecter "
            "le code de la propriété intellectuelle. Toute rediffusion, commerciale ou non, "
            "est subordonnée à l'accord du rapporteur public."
        ),
    }
