import threading
from typing import Optional

from nomosai.engine import build_analyzer, DEFAULT_ENTITIES, ENTITY_LABELS

SUPPORTED_LANGUAGES = {"fr", "en", "de", "es", "it", "nl", "pt"}

_SPACY_MODELS = {
    "fr": "fr_core_news_lg",
    "en": "en_core_web_lg",
    "de": "de_core_news_lg",
    "es": "es_core_news_lg",
    "it": "it_core_news_lg",
    "nl": "nl_core_news_lg",
    "pt": "pt_core_news_lg",
}

_analyzer_cache: dict[str, object] = {}
_cache_lock = threading.Lock()


def _get_analyzer(language: str):
    """Retourne l'analyseur Presidio pour la langue, en le construisant une seule fois."""
    if language not in _analyzer_cache:
        with _cache_lock:
            if language not in _analyzer_cache:
                _analyzer_cache[language] = build_analyzer(language)
    return _analyzer_cache[language]


def _validate_entities(entities: Optional[list[str]]) -> tuple[list[str], list[str]]:
    """Retourne (entités_valides, entités_inconnues)."""
    if entities is None:
        return DEFAULT_ENTITIES, []
    all_known = set(ENTITY_LABELS.keys())
    valid = [e for e in entities if e in all_known]
    unknown = [e for e in entities if e not in all_known]
    return (valid if valid else DEFAULT_ENTITIES), unknown
