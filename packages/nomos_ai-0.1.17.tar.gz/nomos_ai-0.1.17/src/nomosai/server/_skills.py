import re
import shutil
from pathlib import Path
from typing import Optional

from nomosai.server._mcp import mcp
from nomosai.server._project import _NOMOS_SKILLS_SRC_DIR


def _skill_short_description(skill_dir: Path) -> str:
    """Extrait la première phrase de la description depuis le frontmatter de SKILL.md."""
    try:
        text = (skill_dir / "SKILL.md").read_text(encoding="utf-8")
        m = re.match(r"^---\s*\n(.*?)\n---", text, re.DOTALL)
        if not m:
            return ""
        dm = re.search(r"^description:\s*(.+)$", m.group(1), re.MULTILINE)
        if not dm:
            return ""
        desc = dm.group(1).strip().strip('"').strip("'")
        first = re.split(r"(?<=\.)\s", desc)[0]
        return first[:110] if len(first) > 110 else first
    except Exception:
        return ""


@mcp.tool()
def initialise_nomos_skills(
    skills_dir: Optional[str] = None,
) -> dict:
    """
    Installe les skills Claude NomosAI pour l'assistance juridique par IA.

    Copie dans le dossier de configuration Claude (par défaut ~/.claude/skills/)
    les skills juridiques NomosAI présents dans references/nomos-skills/.
    Les skills déjà présents ne sont pas écrasés.

    Skills disponibles : extraction de faits, recherche jurisprudentielle
    (Cour de cassation, Conseil d'État, CJUE, BOFIP), rédaction de mémoires
    (mémoire ampliatif / en défense cassation, moyens de cassation).

    Args:
        skills_dir: Chemin vers le dossier skills Claude.
                    Par défaut : ~/.claude/skills/
                    NOTE pour Claude : si l'utilisateur ne précise pas ce chemin,
                    déterminer le dossier de configuration Claude de la machine
                    (souvent ~/.claude/) avant d'appeler cet outil, puis passer
                    le sous-dossier skills/ correspondant.

    Returns:
        dict avec : success, skills_dir, installed, already_present,
                    total_available, total_installed
    """
    target = Path(skills_dir).expanduser().resolve() if skills_dir else Path.home() / ".claude" / "skills"

    src = _NOMOS_SKILLS_SRC_DIR
    if not src.exists():
        return {
            "success": False,
            "error_type": "SkillsSourceNotFound",
            "error": f"Dossier de skills source introuvable : {src}",
        }

    try:
        target.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return {
            "success": False,
            "error_type": "DirectoryCreateError",
            "error": f"Impossible de créer le dossier skills : {e}",
        }

    skill_dirs = [
        item for item in sorted(src.iterdir())
        if item.is_dir() and not item.name.startswith(".") and (item / "SKILL.md").exists()
    ]

    installed: list[str] = []
    already_present: list[str] = []
    errors: list[dict] = []

    for skill_dir in skill_dirs:
        dest = target / skill_dir.name
        if dest.exists():
            already_present.append(skill_dir.name)
            continue
        try:
            shutil.copytree(
                skill_dir,
                dest,
                ignore=shutil.ignore_patterns(".git", ".gitignore"),
            )
            installed.append(skill_dir.name)
        except Exception as e:
            errors.append({"skill": skill_dir.name, "error": str(e)})

    result: dict = {
        "success": True,
        "skills_dir": str(target),
        "installed": installed,
        "already_present": already_present,
        "total_available": len(skill_dirs),
        "total_installed": len(installed),
    }
    if errors:
        result["errors"] = errors
        result["success"] = len(installed) > 0 or len(already_present) > 0
    return result


@mcp.tool()
def update_nomos_skills(
    skill_names: Optional[list[str]] = None,
    skills_dir: Optional[str] = None,
) -> dict:
    """
    Met à jour des skills Claude NomosAI installés (écrase la version installée).

    Workflow en deux temps :
      1. Appeler sans skill_names → retourne la liste numérotée des skills avec descriptions.
         INSTRUCTIONS STRICTES pour Claude :
           a. Afficher dans le chat un tableau Markdown : N° | Skill | Description.
           b. Appeler AskUserQuestion avec exactement 2 options :
              - "Tout mettre à jour"
              - "Annuler"
              L'utilisateur peut aussi utiliser "Other" pour saisir les numéros ou noms
              des skills souhaités (ex. "1, 3" ou "extraction-faits, recherche-CEDH").
           c. Si "Tout mettre à jour" → rappeler update_nomos_skills(skill_names=["__all__"]).
              Si "Other" → résoudre les indices/noms et rappeler update_nomos_skills(skill_names=[...]).
              Si "Annuler" → ne rien faire.
      2. Appeler avec skill_names=[...] → effectue la mise à jour.
         skill_names accepte des noms exacts OU des numéros (ex. ["1", "3"]).
         Passer ["__all__"] pour tout mettre à jour.

    Args:
        skill_names: Noms ou numéros des skills à mettre à jour, ou ["__all__"] pour tous.
                     Si None, retourne la liste avec descriptions et les instructions ci-dessus.
        skills_dir: Chemin vers le dossier skills Claude (défaut : ~/.claude/skills/).

    Returns:
        Sans skill_names : dict avec available_skills (liste de dicts index/name/description).
        Avec skill_names : dict avec updated, skipped, errors, total_updated.
    """
    src = _NOMOS_SKILLS_SRC_DIR
    if not src.exists():
        return {
            "success": False,
            "error_type": "SkillsSourceNotFound",
            "error": f"Dossier de skills source introuvable : {src}",
        }

    skill_dirs = [
        item for item in sorted(src.iterdir())
        if item.is_dir() and not item.name.startswith(".") and (item / "SKILL.md").exists()
    ]

    if not skill_dirs:
        return {
            "success": False,
            "error_type": "NoSkillsFound",
            "error": "Aucun skill trouvé dans le dossier source.",
        }

    available = [
        {"index": i + 1, "name": sd.name, "description": _skill_short_description(sd)}
        for i, sd in enumerate(skill_dirs)
    ]

    if not skill_names:
        return {
            "success": True,
            "action": "selection_required",
            "available_skills": available,
        }

    # Resolve "__all__", index strings ("1", "2") and exact names
    index_map = {str(i + 1): sd.name for i, sd in enumerate(skill_dirs)}
    name_to_dir = {sd.name: sd for sd in skill_dirs}

    if skill_names == ["__all__"]:
        resolved = list(name_to_dir.keys())
    else:
        resolved = [index_map.get(n, n) for n in skill_names]

    unknown = [n for n in resolved if n not in name_to_dir]
    selected = [name_to_dir[n] for n in resolved if n in name_to_dir]

    all_names = [sd.name for sd in skill_dirs]

    if not selected:
        return {
            "success": False,
            "error_type": "UnknownSkills",
            "error": f"Aucun skill valide dans la liste fournie. Inconnus : {unknown}",
            "available_skills": available,
        }

    target = Path(skills_dir).expanduser().resolve() if skills_dir else Path.home() / ".claude" / "skills"
    try:
        target.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return {
            "success": False,
            "error_type": "DirectoryCreateError",
            "error": f"Impossible d'accéder au dossier skills : {e}",
        }

    updated: list[str] = []
    errors: list[dict] = []

    for skill_dir in selected:
        dest = target / skill_dir.name
        try:
            if dest.exists():
                shutil.rmtree(dest)
            shutil.copytree(
                skill_dir,
                dest,
                ignore=shutil.ignore_patterns(".git", ".gitignore"),
            )
            updated.append(skill_dir.name)
        except Exception as e:
            errors.append({"skill": skill_dir.name, "error": str(e)})

    selected_names = {sd.name for sd in selected}
    skipped = [n for n in all_names if n not in selected_names]

    result: dict = {
        "success": len(errors) == 0 or len(updated) > 0,
        "skills_dir": str(target),
        "updated": updated,
        "skipped": skipped,
        "total_available": len(skill_dirs),
        "total_updated": len(updated),
    }
    if unknown:
        result["unknown_skills"] = unknown
    if errors:
        result["errors"] = errors
    return result
