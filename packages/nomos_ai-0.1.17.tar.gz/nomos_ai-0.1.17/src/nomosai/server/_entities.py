from pydantic import create_model, Field

_OPT_IN_ENTITIES = {"DATE_TIME", "FILE_PATH"}

_FRENCH_ONLY = {
    "FR_NIR", "FR_SIRET", "FR_SIREN", "FR_TVA",
    "FR_PASSPORT", "FR_CNI", "FR_DRIVING_LICENSE", "FR_POSTAL_CODE",
    "FILE_PATH",
}

_ENTITY_DESCRIPTIONS = {
    "PERSON":             "Noms de personnes physiques",
    "ORGANIZATION":       "Noms d'organisations ou entreprises",
    "LOCATION":           "Lieux géographiques, adresses",
    "EMAIL_ADDRESS":      "Adresses e-mail",
    "PHONE_NUMBER":       "Numéros de téléphone",
    "IBAN_CODE":          "Codes IBAN bancaires",
    "CREDIT_CARD":        "Numéros de carte de crédit",
    "MEDICAL_LICENSE":    "Licences médicales",
    "URL":                "URLs et liens web",
    "IP_ADDRESS":         "Adresses IP",
    "FR_NIR":             "Numéro INSEE / Sécurité Sociale (15 chiffres)",
    "FR_SIRET":           "SIRET — identifiant établissement (14 chiffres)",
    "FR_SIREN":           "SIREN — identifiant entreprise (9 chiffres)",
    "FR_TVA":             "Numéro TVA intracommunautaire",
    "FR_PASSPORT":        "Numéro de passeport français",
    "FR_CNI":             "Carte Nationale d'Identité (12 chiffres)",
    "FR_DRIVING_LICENSE": "Permis de conduire format post-2013 (AA-NNN-AA)",
    "FR_POSTAL_CODE":     "Code postal français (avec contexte)",
    "DATE_TIME":          "Dates et heures — opt-in, génèrent du bruit par défaut",
    "FILE_PATH":          "Chemins de fichiers Windows/Unix — opt-in",
}

# (field_name, label, entities_covered, default_on)
_ENTITY_GROUPS: list[tuple[str, str, list[str], bool]] = [
    (
        "personnes",
        "Personnes — noms et prénoms",
        ["PERSON"],
        True,
    ),
    (
        "identite",
        "Documents d'identité — NIR/sécu, CNI, passeport, permis, licences",
        ["FR_NIR", "FR_CNI", "FR_PASSPORT", "FR_DRIVING_LICENSE", "MEDICAL_LICENSE"],
        True,
    ),
    (
        "organisations",
        "Organisations — noms, SIRET, SIREN, TVA",
        ["ORGANIZATION", "FR_SIRET", "FR_SIREN", "FR_TVA"],
        True,
    ),
    (
        "contacts",
        "Coordonnées — e-mails et téléphones",
        ["EMAIL_ADDRESS", "PHONE_NUMBER"],
        True,
    ),
    (
        "localisation",
        "Localisation — lieux, adresses, codes postaux",
        ["LOCATION", "FR_POSTAL_CODE"],
        True,
    ),
    (
        "financier",
        "Données financières — IBAN et cartes bancaires",
        ["IBAN_CODE", "CREDIT_CARD"],
        True,
    ),
    (
        "web",
        "Identifiants numériques — URLs et adresses IP",
        ["URL", "IP_ADDRESS"],
        True,
    ),
    (
        "dates_et_fichiers",
        "Dates / chemins de fichiers (opt-in — peuvent générer du bruit)",
        ["DATE_TIME", "FILE_PATH"],
        False,
    ),
]

# Groupes couverts par chaque profil (noms des clés de _ENTITY_GROUPS)
_PRESET_GROUPS = {
    "base":    ["personnes", "organisations", "contacts"],
    "avancee": ["personnes", "identite", "organisations", "contacts",
                "localisation", "financier", "web"],
}

_PRESET_SCHEMA = create_model(
    "ProfilAnonymisation",
    profil=(
        str,
        Field(
            default="avancee",
            description=(
                "Tapez le profil voulu :\n"
                "  base        — Personnes · Organisations · Contacts\n"
                "  avancee     — Identité · Localisation · Financier · Web + base\n"
                "  personnalise — précisez les catégories ci-dessous"
            ),
        ),
    ),
    categories=(
        str,
        Field(
            default="",
            description=(
                "Profil personnalise uniquement — listez les catégories séparées par des virgules :\n"
                "personnes, identite, organisations, contacts, localisation, financier, web, dates_et_fichiers"
            ),
        ),
    ),
)


def _resolve_preset(profil: str, categories_text: str, language: str) -> list[str]:
    """Traduit un profil (base/avancee/personnalise) en liste de types d'entités."""
    key = profil.strip().lower()
    valid_groups = {g[0] for g in _ENTITY_GROUPS}

    if key in _PRESET_GROUPS:
        selected = _PRESET_GROUPS[key]
    else:
        # Profil personnalisé : parse le texte libre
        tokens = [t.strip().lower() for t in categories_text.replace(",", " ").split()]
        selected = [t for t in tokens if t in valid_groups]
        if not selected:
            selected = _PRESET_GROUPS["avancee"]  # fallback

    result: list[str] = []
    for field_name, _, entities, _ in _ENTITY_GROUPS:
        if field_name not in selected:
            continue
        for entity in entities:
            if entity in _FRENCH_ONLY and language != "fr":
                continue
            if entity not in result:
                result.append(entity)
    return result
