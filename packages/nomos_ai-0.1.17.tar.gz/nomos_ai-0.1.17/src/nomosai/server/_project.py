import json
from pathlib import Path
from typing import Optional

from mcp.server.fastmcp import Context
from pydantic import create_model, Field

from nomosai.server._mcp import mcp

# Path(__file__).parent = src/nomosai/server/ → go up one level to src/nomosai/
_DATA_DIR = Path(__file__).parent.parent / "references"
_TEMPLATES_DIR = _DATA_DIR / "Claude_templates"
_NOMOS_SKILLS_SRC_DIR = _DATA_DIR / "nomos-skills"

_TEMPLATE_FILES: dict[str, str] = {
    "defense": "dossier-defense.md",
    "demande": "dossier-demande.md",
}

_DOSSIER_TYPE_SCHEMA = create_model(
    "TypeDossier",
    type_dossier=(
        str,
        Field(
            default="autre",
            description=(
                "Type de dossier juridique — choisissez parmi :\n"
                "  defense — Mémoire en défense (réponse à un pourvoi adverse)\n"
                "  demande — Mémoire ampliatif / pourvoi en cassation\n"
                "  autre   — Autre type de dossier (espace de travail générique)"
            ),
        ),
    ),
)

_HOOK_SCRIPT = '''\
#!/usr/bin/env python3
"""Hook NomosAI — bloque la lecture directe dans documents-confidentiels/"""
import json
import pathlib
import sys


def main() -> None:
    try:
        data = json.load(sys.stdin)
    except Exception:
        sys.exit(0)

    path_str = data.get("file_path", data.get("path", ""))
    if not path_str:
        sys.exit(0)

    try:
        parts = pathlib.PurePath(path_str).parts
    except Exception:
        sys.exit(0)

    if "documents-confidentiels" in parts:
        print("BLOQUE : Lecture directe interdite dans documents-confidentiels/", file=sys.stderr)
        print("Ce dossier contient des donnees a caractere personnel (DCP).", file=sys.stderr)
        print("Utilisez anonymize_file via le serveur MCP nomos-ai.", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
'''


def _build_claude_md(project_name: str, dossier_type: Optional[str] = None) -> str:
    base = f"""\
# {project_name}

Espace de travail juridique assisté par IA. Tâches : recherche sémantique, rédaction et édition de textes juridiques.

## Répertoires

Respecter la structure de répertoires et le role de chacun des dossiers par defaults.

| Répertoire                    | Rôle                                                        |
|-------------------------------|-------------------------------------------------------------|
| `documents-confidentiels/`    | DCP — lecture directe **interdite**, anonymiser via MCP     |
| `sources/`                    | Documents lisibles directement (publics ou anonymisés)      |
| `documents-anonymisés/`       | Sorties de `anonymize_file` fichier anonymisés accessibles  |
| `livrables/`                  | Livrables finaux ecrire les fichiers ici                    |
| `artefacts/`                  | Fichiers temporaires — supprimer dès que possible           |

## Règles

1. **Confidentialité** : ne jamais lire `documents-confidentiels/` directement. Utiliser uniquement l'outil `anonymize_file` du MCP `nomos-ai`.
2. **Pas de code** sauf si explicitement demandé ou strictement nécessaire.
3. **Nettoyage** : supprimer les artefacts dès qu'ils ne sont plus utiles.
"""
    if dossier_type and dossier_type in _TEMPLATE_FILES:
        template_path = _TEMPLATES_DIR / _TEMPLATE_FILES[dossier_type]
        if template_path.exists():
            base += "\n---\n\n" + template_path.read_text(encoding="utf-8")
    return base


def _build_settings() -> str:
    settings = {
        "hooks": {
            "PreToolUse": [
                {
                    "matcher": "Read|Edit",
                    "hooks": [
                        {
                            "type": "command",
                            "command": "python .claude/hooks/block_confidentiel.py",
                        }
                    ],
                }
            ]
        }
    }
    return json.dumps(settings, indent=2, ensure_ascii=False)


@mcp.tool()
async def initiate_project(
    ctx: Context,
    directory: str,
    project_name: Optional[str] = None,
    dossier_type: Optional[str] = None,
) -> dict:
    """
    Initialise un espace de travail juridique NomosAI dans le répertoire spécifié.

    Crée la structure de répertoires standard, un fichier CLAUDE.md adapté au
    type de dossier, et un hook de sécurité qui bloque la lecture directe des
    fichiers dans le dossier documents-confidentiels/.

    Si dossier_type est absent, demande interactivement à l'utilisateur de choisir
    parmi les types disponibles : defense, demande, autre.

    Structure créée :
        documents-confidentiels/   — Documents confidentiels (DCP) : traitement via nomos-ai MCP uniquement
        sources/                   — Documents sources lisibles directement par l'agent
        documents-anonymisés/      — Sorties anonymisées produites par NomosAI
        livrables/                 — Livrables finaux en cours de production
        artefacts/                 — Fichiers temporaires produits par l'agent (à nettoyer)
        .claude/settings.json      — Hook bloquant la lecture directe de documents-confidentiels/
        CLAUDE.md                  — Instructions de l'agent adaptées au type de dossier

    Args:
        ctx: Contexte MCP (injecté automatiquement par FastMCP).
        directory: Chemin absolu ou relatif vers le répertoire du projet.
                   Le répertoire est créé s'il n'existe pas.
        project_name: Nom du projet (titre du CLAUDE.md). Défaut : nom du répertoire.
        dossier_type: Type de dossier juridique. Valeurs acceptées : "defense", "demande", "autre".
                      Si None, une question interactive est posée à l'utilisateur.

    Returns:
        dict avec : success, project_path, dossier_type, template_loaded, created_dirs,
                    claude_md_path, hook_path, settings_path
    """
    if dossier_type is None:
        try:
            elicit_result = await ctx.elicit(
                message=(
                    "Quel type de dossier souhaitez-vous initialiser ?\n\n"
                    "  defense — Mémoire en défense (réponse à un pourvoi adverse)\n"
                    "  demande — Mémoire ampliatif / pourvoi en cassation\n"
                    "  autre   — Autre type de dossier (espace de travail générique)\n\n"
                    "Refuser = espace générique par défaut."
                ),
                schema=_DOSSIER_TYPE_SCHEMA,
            )
            if elicit_result.action == "accept" and elicit_result.data is not None:
                chosen = elicit_result.data.model_dump().get("type_dossier", "autre").strip().lower()
                dossier_type = chosen if chosen in _TEMPLATE_FILES else None
        except Exception:
            dossier_type = None

    project_path = Path(directory).resolve()

    try:
        project_path.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return {
            "success": False,
            "error_type": "DirectoryCreateError",
            "error": f"Impossible de créer le répertoire : {e}",
        }

    name = project_name or project_path.name

    subdirs = ["documents-confidentiels", "sources", "documents-anonymisés", "livrables", "artefacts"]
    created_dirs: list[str] = []
    for subdir in subdirs:
        subdir_path = project_path / subdir
        try:
            subdir_path.mkdir(exist_ok=True)
            created_dirs.append(str(subdir_path))
        except Exception as e:
            return {
                "success": False,
                "error_type": "DirectoryCreateError",
                "error": f"Impossible de créer {subdir}/ : {e}",
                "created_dirs": created_dirs,
            }

    hooks_dir = project_path / ".claude" / "hooks"
    try:
        hooks_dir.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return {
            "success": False,
            "error_type": "DirectoryCreateError",
            "error": f"Impossible de créer .claude/hooks/ : {e}",
        }

    hook_script_path = hooks_dir / "block_confidentiel.py"
    try:
        hook_script_path.write_text(_HOOK_SCRIPT, encoding="utf-8")
    except Exception as e:
        return {
            "success": False,
            "error_type": "FileWriteError",
            "error": f"Impossible d'écrire le script de hook : {e}",
        }

    settings_path = project_path / ".claude" / "settings.json"
    try:
        settings_path.write_text(_build_settings(), encoding="utf-8")
    except Exception as e:
        return {
            "success": False,
            "error_type": "FileWriteError",
            "error": f"Impossible d'écrire settings.json : {e}",
        }

    template_loaded = (
        dossier_type is not None
        and dossier_type in _TEMPLATE_FILES
        and (_TEMPLATES_DIR / _TEMPLATE_FILES[dossier_type]).exists()
    )

    claude_md_path = project_path / "CLAUDE.md"
    try:
        claude_md_path.write_text(_build_claude_md(name, dossier_type=dossier_type), encoding="utf-8")
    except Exception as e:
        return {
            "success": False,
            "error_type": "FileWriteError",
            "error": f"Impossible d'écrire CLAUDE.md : {e}",
        }

    return {
        "success": True,
        "project_path": str(project_path),
        "project_name": name,
        "dossier_type": dossier_type or "generic",
        "template_loaded": template_loaded,
        "created_dirs": created_dirs,
        "claude_md_path": str(claude_md_path),
        "hook_path": str(hook_script_path),
        "settings_path": str(settings_path),
        "message": (
            f"Projet '{name}' initialisé"
            + (f" (type : {dossier_type})" if dossier_type else "")
            + ". "
            "Le hook bloque la lecture directe de documents-confidentiels/ (outils Read et Edit). "
            "Placez les documents confidentiels dans documents-confidentiels/ et utilisez "
            "anonymize_file via nomos-ai MCP pour les traiter."
        ),
    }
