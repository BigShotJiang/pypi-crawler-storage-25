import datetime
import re
from pathlib import Path
from typing import Optional

_GLOBAL_INDEX_NAME = "_nomos_index.md"
_GLOBAL_ROW_RE = re.compile(r"^\|\s*`(\[[^\]]+\])`\s*\|\s*(.*?)\s*\|\s*`([^`]+)`\s*\|$")


def _find_artefacts_dir() -> Optional[Path]:
    """Remonte depuis le répertoire courant pour localiser un dossier artefacts/ NomosAI."""
    for ancestor in [Path.cwd(), *Path.cwd().parents]:
        candidate = ancestor / "artefacts"
        if candidate.is_dir():
            return candidate
        # Stop climbing once we leave a NomosAI project (sentinel: CLAUDE.md + artefacts sibling)
        if (ancestor / "CLAUDE.md").exists():
            break
    return None


def _find_confidential_dir(input_path: Path, output_path: Path) -> Optional[Path]:
    """Localise le répertoire documents-confidentiels/ du projet NomosAI.

    Cherche d'abord dans les ancêtres du fichier d'entrée (cas typique : le fichier
    est dans documents-confidentiels/ ou ses sources sont dans un projet NomosAI initié).
    Cherche ensuite dans les ancêtres du fichier de sortie.
    """
    for path in (input_path, output_path):
        for ancestor in path.parents:
            if ancestor.name == "documents-confidentiels" and ancestor.is_dir():
                return ancestor
        for ancestor in path.parents:
            candidate = ancestor / "documents-confidentiels"
            if candidate.is_dir():
                return candidate
    return None


def _read_global_index(conf_dir: Path) -> list[dict]:
    """Lit _nomos_index.md depuis documents-confidentiels/ et retourne les entrées existantes."""
    index_path = conf_dir / _GLOBAL_INDEX_NAME
    if not index_path.exists():
        return []
    entries = []
    try:
        for line in index_path.read_text(encoding="utf-8").splitlines():
            m = _GLOBAL_ROW_RE.match(line.strip())
            if not m:
                continue
            placeholder = m.group(1)
            original = m.group(2).strip().replace(r"\|", "|").replace(r"\n", "\n")
            entity_type = m.group(3).strip()
            if placeholder and original and entity_type:
                from nomosai.engine import ENTITY_LABELS as _EL
                entries.append({
                    "placeholder": placeholder,
                    "original": original,
                    "entity_type": entity_type,
                    "label": _EL.get(entity_type, entity_type),
                })
    except Exception:
        pass
    return entries


def _merge_index_entries(existing: list[dict], new: list[dict]) -> list[dict]:
    """Fusionne deux listes d'entrées d'index (clé unique = placeholder)."""
    merged = {e["placeholder"]: e for e in existing}
    for entry in new:
        merged[entry["placeholder"]] = entry
    return list(merged.values())


def _write_global_index(conf_dir: Path, entries: list[dict]) -> Path:
    """Écrit (ou met à jour) _nomos_index.md dans documents-confidentiels/."""
    index_path = conf_dir / _GLOBAL_INDEX_NAME
    date_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        "---",
        f"generated: {date_str}",
        f"total_entities: {len(entries)}",
        "---",
        "",
        "# Index global d'anonymisation NomosAI",
        "",
        "> Ce fichier est **confidentiel** — il contient les données personnelles originales.",
        "> Ne pas inclure dans les exports anonymisés.",
        "",
        "| Placeholder | Valeur originale | Entité |",
        "| --- | --- | --- |",
    ]
    for entry in sorted(entries, key=lambda e: (e.get("label", ""), e["placeholder"])):
        original = (
            entry["original"]
            .replace("|", "\\|")
            .replace("\r\n", "\\n")
            .replace("\n", "\\n")
            .replace("\r", "\\n")
        )
        lines.append(f"| `{entry['placeholder']}` | {original} | `{entry['entity_type']}` |")
    lines += ["", "---", ""]
    index_path.write_text("\n".join(lines), encoding="utf-8")
    return index_path
