import re
from pathlib import Path
from typing import Optional

from mcp.server.fastmcp import Context

from nomosai.engine import DocumentAnonymizer, ENTITY_LABELS
from nomosai.readers import read_document, SUPPORTED_EXTENSIONS
from nomosai.formatter import to_markdown

from nomosai.server._mcp import mcp
from nomosai.server._entities import (
    _OPT_IN_ENTITIES,
    _FRENCH_ONLY,
    _ENTITY_DESCRIPTIONS,
    _PRESET_SCHEMA,
    _resolve_preset,
)
from nomosai.server._analyzer import (
    SUPPORTED_LANGUAGES,
    _SPACY_MODELS,
    _get_analyzer,
    _validate_entities,
)
from nomosai.server._index import (
    _GLOBAL_INDEX_NAME,
    _find_confidential_dir,
    _read_global_index,
    _merge_index_entries,
    _write_global_index,
)


@mcp.tool()
async def anonymize_file(
    ctx: Context,
    file_path: str,
    output_path: Optional[str] = None,
    language: str = "fr",
    entities: Optional[list[str]] = None,
    elicit_entities: bool = False,
    score_threshold: float = 0.55,
    write_index: bool = True,
) -> dict:
    """
    Anonymise un fichier document (.docx, .pdf, .txt, .md, .rst).

    Lit le document, détecte et remplace les PII, puis écrit un fichier Markdown
    anonymisé avec frontmatter YAML. Génère optionnellement
    un fichier d'index confidentiel (placeholder → valeur originale).

    Args:
        ctx: Contexte MCP (injecté automatiquement par FastMCP).
        file_path: Chemin absolu ou relatif vers le document source.
        output_path: Chemin du fichier .md de sortie. Par défaut : <nom>_anonymise.md.
        language: Code langue — 'fr' (défaut), 'en', 'de', 'es', 'it', 'nl', 'pt'.
        entities: Types d'entités à détecter. None = tous les types par défaut.
        elicit_entities: Si True et entities est None, présente un formulaire interactif
            pour que l'utilisateur choisisse les types d'entités. Ignoré si entities
            est fourni. Défaut False.
        score_threshold: Seuil de confiance 0.0–1.0 (défaut 0.55).
        write_index: Écrire le fichier d'index confidentiel (défaut True).

    Returns:
        dict avec : success, input_path, output_path, index_path, stats, total_entities
    """
    input_p = Path(file_path).resolve()

    if not input_p.exists():
        return {
            "success": False,
            "error_type": "FileNotFound",
            "error": f"Fichier introuvable : {input_p}",
        }

    suffix = input_p.suffix.lower()
    if suffix not in SUPPORTED_EXTENSIONS:
        return {
            "success": False,
            "error_type": "UnsupportedFormat",
            "error": (
                f"Format '{suffix}' non supporté. "
                f"Supportés : {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
            ),
        }

    if language not in SUPPORTED_LANGUAGES:
        return {
            "success": False,
            "error_type": "UnsupportedLanguage",
            "error": f"Langue '{language}' non supportée. Supportées : {sorted(SUPPORTED_LANGUAGES)}",
        }

    elicitation_fallback = False
    if elicit_entities and entities is None:
        try:
            elicit_result = await ctx.elicit(
                message=(
                    "Choisissez un profil d'anonymisation :\n"
                    "  base         — Personnes · Organisations · Contacts\n"
                    "  avancee      — + Identité · Localisation · Financier · Web\n"
                    "  personnalise — listez vos catégories dans le champ ci-dessous\n\n"
                    "Refuser = réglages par défaut."
                ),
                schema=_PRESET_SCHEMA,
            )
            if elicit_result.action == "accept" and elicit_result.data is not None:
                data = elicit_result.data.model_dump()
                entities = _resolve_preset(
                    data.get("profil", "avancee"),
                    data.get("categories", ""),
                    language,
                )
            else:
                elicitation_fallback = True
        except Exception:
            elicitation_fallback = True

    out_p = (
        Path(output_path).resolve()
        if output_path
        else input_p.with_name(input_p.stem + "_anonymise.md")
    )

    valid_entities, unknown = _validate_entities(entities)

    try:
        analyzer = _get_analyzer(language)
    except OSError as e:
        model = _SPACY_MODELS.get(language, f"{language}_core_news_lg")
        return {
            "success": False,
            "error_type": "SpacyModelMissing",
            "error": f"Exécutez : python -m spacy download {model}",
            "detail": str(e),
        }

    try:
        blocks = read_document(input_p)
    except Exception as e:
        return {"success": False, "error_type": "ReadError", "error": str(e)}

    if not blocks:
        return {
            "success": False,
            "error_type": "EmptyDocument",
            "error": f"Aucun texte extrait de {input_p.name}",
        }

    conf_dir = _find_confidential_dir(input_p, out_p)

    anonymizer = DocumentAnonymizer(
        analyzer,
        language=language,
        score_threshold=score_threshold,
    )

    # Pré-charge l'index global pour garantir la cohérence des placeholders
    # entre tous les documents du projet.
    existing_entries: list[dict] = []
    if conf_dir:
        existing_entries = _read_global_index(conf_dir)
        if existing_entries:
            anonymizer.load_index(existing_entries)

    try:
        anon_blocks = anonymizer.anonymize_blocks(blocks, valid_entities)
        md = to_markdown(
            anon_blocks,
            source_path=input_p,
            language=language,
            stats=dict(anonymizer.stats),
            score_threshold=score_threshold,
        )
        out_p.parent.mkdir(parents=True, exist_ok=True)
        out_p.write_text(md, encoding="utf-8")
    except Exception as e:
        return {"success": False, "error_type": "AnonymizationError", "error": str(e)}

    index_path_str = None
    if write_index:
        try:
            target_dir = conf_dir if conf_dir else out_p.parent
            all_entries = _merge_index_entries(existing_entries, anonymizer.get_index())
            idx_p = _write_global_index(target_dir, all_entries)
            index_path_str = str(idx_p)
        except Exception:
            pass  # non bloquant : l'anonymisation a réussi

    result = {
        "success": True,
        "input_path": str(input_p),
        "output_path": str(out_p),
        "index_path": index_path_str,
        "format_detected": suffix,
        "stats": dict(anonymizer.stats),
        "total_entities": sum(anonymizer.stats.values()),
        "language": language,
        "score_threshold": score_threshold,
    }
    if unknown:
        result["warnings"] = [f"Types d'entités inconnus ignorés : {unknown}"]
    if elicitation_fallback:
        result["elicitation_fallback"] = True
    return result


@mcp.tool()
def deanonymize_file(
    anonymized_file_path: str,
    index_path: Optional[str] = None,
    output_path: Optional[str] = None,
) -> dict:
    """
    Restaure un document anonymisé NomosAI en remplaçant les placeholders
    ([PERSONNE_1], [EMAIL_2]…) par les valeurs originales stockées dans l'index.

    L'index est le fichier confidentiel <nom>-index.md généré lors de l'anonymisation.
    Si index_path est absent, il est cherché automatiquement à côté du fichier anonymisé
    sous le nom <stem>-index.md.

    Args:
        anonymized_file_path: Chemin vers le fichier .md anonymisé.
        index_path: Chemin vers le fichier index (-index.md). Auto-détecté si absent.
        output_path: Chemin de sortie. Par défaut : <stem>_restaure.md.

    Returns:
        dict avec : success, input_path, index_path, output_path, replacements_count
    """
    _ROW_RE = re.compile(
        r"^\|\s*`(\[[^\]]+\])`\s*\|\s*(.*?)\s*\|\s*`[^`]+`\s*\|$"
    )

    doc_p = Path(anonymized_file_path).resolve()

    if not doc_p.exists():
        return {
            "success": False,
            "error_type": "FileNotFound",
            "error": f"Fichier introuvable : {doc_p}",
        }

    if doc_p.suffix.lower() != ".md":
        return {
            "success": False,
            "error_type": "InvalidFormat",
            "error": f"Le fichier doit être un .md anonymisé (reçu : {doc_p.suffix!r})",
        }

    # Résolution de l'index
    if index_path:
        idx_p = Path(index_path).resolve()
        if not idx_p.exists():
            return {
                "success": False,
                "error_type": "FileNotFound",
                "error": f"Index introuvable : {idx_p}",
            }
    else:
        # 1. Index global NomosAI dans documents-confidentiels/ (nouveau comportement)
        conf_dir = _find_confidential_dir(doc_p, doc_p)
        global_idx = (conf_dir / _GLOBAL_INDEX_NAME) if conf_dir else None
        # 2. Ancien index par document à côté du fichier (rétrocompatibilité)
        legacy_idx = doc_p.with_name(doc_p.stem + "-index.md")

        if global_idx and global_idx.exists():
            idx_p = global_idx
        elif legacy_idx.exists():
            idx_p = legacy_idx
        else:
            return {
                "success": False,
                "error_type": "IndexNotFound",
                "error": (
                    f"Aucun index trouvé (cherché : {global_idx}, {legacy_idx}).\n"
                    "Utilisez index_path pour en spécifier un explicitement."
                ),
            }

    # Parsing de l'index
    try:
        content = idx_p.read_text(encoding="utf-8")
        mapping: dict[str, str] = {}
        for line in content.splitlines():
            m = _ROW_RE.match(line.strip())
            if not m:
                continue
            placeholder = m.group(1)
            original = m.group(2).strip().replace(r"\|", "|").replace(r"\n", "\n")
            mapping[placeholder] = original
    except Exception as e:
        return {"success": False, "error_type": "IndexParseError", "error": str(e)}

    if not mapping:
        return {
            "success": False,
            "error_type": "EmptyIndex",
            "error": f"Aucun placeholder trouvé dans l'index : {idx_p}",
        }

    # Restauration du texte
    try:
        text = doc_p.read_text(encoding="utf-8")
        replacements = sum(text.count(ph) for ph in mapping)
        # Remplacer les plus longs en premier (évite [PERSONNE_1] avant [PERSONNE_10])
        for placeholder in sorted(mapping, key=len, reverse=True):
            text = text.replace(placeholder, mapping[placeholder])

        stem = doc_p.stem.removesuffix("_anonymise")
        out_p = Path(output_path).resolve() if output_path else doc_p.with_name(stem + "_restaure.md")
        out_p.parent.mkdir(parents=True, exist_ok=True)
        out_p.write_text(text, encoding="utf-8")
    except Exception as e:
        return {"success": False, "error_type": "RestoreError", "error": str(e)}

    return {
        "success": True,
        "input_path": str(doc_p),
        "index_path": str(idx_p),
        "output_path": str(out_p),
        "entries_in_index": len(mapping),
        "replacements_count": replacements,
    }


@mcp.tool()
def list_entities(language: str = "fr") -> dict:
    """
    Liste tous les types de PII que NomosAI peut détecter.

    Ne nécessite pas de chargement d'analyseur — répond instantanément.
    Les entités FR_* sont uniquement disponibles avec language='fr'.
    Les entités opt-in (DATE_TIME, FILE_PATH) doivent être explicitement
    listées dans le paramètre 'entities' de anonymize_file.

    Args:
        language: Code langue pour filtrer les entités pertinentes.

    Returns:
        dict avec : default_entities, opt_in_entities, total_default, total_opt_in
    """
    default_list = []
    opt_in_list = []

    for entity_type, label in ENTITY_LABELS.items():
        is_opt_in = entity_type in _OPT_IN_ENTITIES
        is_french_only = entity_type in _FRENCH_ONLY

        if is_french_only and language != "fr":
            continue

        entry = {
            "entity_type": entity_type,
            "label": label,
            "description": _ENTITY_DESCRIPTIONS.get(entity_type, ""),
            "opt_in": is_opt_in,
        }
        if is_french_only:
            entry["french_only"] = True

        if is_opt_in:
            opt_in_list.append(entry)
        else:
            default_list.append(entry)

    return {
        "language": language,
        "default_entities": default_list,
        "opt_in_entities": opt_in_list,
        "total_default": len(default_list),
        "total_opt_in": len(opt_in_list),
        "note": (
            "Les entités opt_in doivent être explicitement listées dans le paramètre "
            "'entities' pour être activées."
        ),
    }
