---
name: recherche-ce-droit-public
version: 1.3
date: 2026-05-17
description: "Recherche et analyse de jurisprudence du Conseil d'État. Utilise ArianeWeb (via MCP nomos) comme source primaire et Open Legi (Légifrance) pour la lecture des textes intégraux. Déclencher pour toute question de droit public impliquant le Conseil d'État : recours pour excès de pouvoir, pourvoi en cassation administratif, référé suspension ou liberté, avis contentieux, responsabilité de la puissance publique, contrats administratifs, fonction publique, urbanisme, ou toute recherche par numéro de requête CE."
---

# Recherche et analyse — Conseil d'État

---

## §1 — Sources

### 1.1 — ArianeWeb (via MCP nomos) — source primaire

Outils : `search_arianeweb` (découverte, filtrage, rebond PCJA) · `get_conclusion` (conclusions RP).

**`search_arianeweb`** — paramètres :

| Paramètre | Rôle | Valeurs |
|---|---|---|
| `query` | Recherche plein texte | Termes libres |
| `numero` | N° de requête exact | Ex. : `489441` |
| `fund` | Fond | `AW_DCE` (CE) · `AW_CRP` (conclusions) · `AW_DTC` (Tribunal des conflits) |
| `pcja` | Code PCJA (match exact) | Ex. : `60-01-02-01` |
| `page_size` | Résultats / page | `10` défaut, max `50` |
| `offset` | Pagination | `0` défaut |

**Jamais `fund="AW_DCA"`** (CAA).

Champs retournés : `numero`, `juridiction`, `formation`, `date`, `solution`, `publication` (A/B/C), `ecli`, `pcja_codes`, `resume`, `linked_decision` (contient `CRP:[id]` si conclusions disponibles).

**Tri** : résultats non triés par date. Hiérarchiser par formation et publication. En fin de recherche, lancer une requête dédiée pour vérifier une éventuelle évolution récente.

**Limites** : pas de texte intégral des décisions (extraits seulement) · codes PCJA exploitables uniquement par rebond à partir d'une décision trouvée · pas d'arborescence PCJA.

**Conclusions du rapporteur public** (`fund="AW_CRP"`, ~9 000 documents) :
- Vérifier existence : `search_arianeweb(fund="AW_CRP", numero="[n°]")`
- Lire de façon ciblée : appeler `get_conclusion(numero="[n°]")` — texte dans le champ `text`, PDF sauvegardé dans `artefacts/` (`saved_pdf_path`, `null` si aucun projet nomos actif). Utiliser `grep` pour localiser les sections pertinentes, puis lire uniquement les passages via `python3 -c "print(open('[chemin]').read()[A:B])"`. Supprimer le PDF après lecture si `saved_pdf_path` n'est pas `null` : `Remove-Item "[saved_pdf_path]"`.
- Vérifier si le rapporteur cite des décisions non encore signalées.
- Copyright : les conclusions ne sont pas libres de droits.

### 1.2 — Open Legi — lecture texte intégral

`rechercher_jurisprudence_administrative` — pour lire le texte intégral des décisions CE identifiées via ArianeWeb, et pour les textes normatifs (`rechercher_code`).

**Règle absolue — juridictions du fond** : ne jamais lire ni interroger CAA ou TA. Vérifier systématiquement le champ `Juridiction` : écarter immédiatement tout résultat qui n'est pas `Conseil d'État`.

Limites : mélange CE/CAA/TA sans filtre · pas d'ECLI · pas de filtre formation/solution · recherche par numéro de requête non fiable.

### 1.3 — WebSearch (dernier recours)

`site:conseil-etat.fr [termes]` : pour les recherches par nom d'affaire quand ArianeWeb et Open Legi ne remontent rien.

---

## §2 — Méthode

### Principe de transparence (toutes phases)

Narrer le travail en direct à chaque étape.

| Moment | Ce qu'on affiche |
|---|---|
| Avant une requête | `Requête : [outil] — terme : "[X]" — filtres : [Y]` |
| Après la requête | `[N] résultat(s) : [liste des références avec date et formation]` |
| Sélection / rejet | `Retenu : [réf.] — [raison]` / `Écarté : [réf.] — [raison]` |
| Lecture | `Lecture §§ [X-Y] — [affaire] — [date]` |
| Résultat nul | `Aucun résultat — reformulation : [nouveau terme]` |

---

### Règle anti-hallucination — CHERCHER → TROUVER → CITER

- Ne jamais citer une décision sans l'avoir trouvée par recherche préalable.
- Ne jamais produire un numéro de requête, une date, une formation ou un nom d'affaire.
- Ne jamais attribuer une portée sans avoir lu les considérants contenant la solution.
- Décision non localisée : « non trouvée » — jamais « fausse ».
- Vérifier que la décision est applicable à la date des faits du dossier.

---

==### Phase 0 — Triage==

==Classer la question sur la forme de la demande, pas sur des connaissances de fond.==

==| Critère | SIMPLE | COMPLEXE |==
==|---|---|---|==
==| Questions | Une seule, bien délimitée | Plusieurs imbriquées ou à décomposer |==
==| Texte de référence | Nommé ou identifiable à la lecture | Non identifié, multiple ou incertain |==
==| Dimension temporelle | Aucune (droit positif) | Réforme, évolution, transition |==
==| Conflit de normes | Aucun | Textes concurrents, articulation à trancher |==

==SIMPLE si tous les critères pointent SIMPLE. Un seul COMPLEXE suffit à basculer.==

==**En cas de doute** — afficher et attendre confirmation :==

```
Triage : je classe [SIMPLE / COMPLEXE] — [critère déterminant].
Confirmer ou corriger ?
```

---

### Phase 1 — Cadrage juridique

==**Bypass** — sauter cette phase si :==
==- la question porte sur une question purement jurisprudentielle (ex. contrôle du juge de cassation administratif, office du juge des référés) dont le régime ne découle pas d'un texte précis ;==
==- l'utilisateur fournit déjà les textes applicables dans sa demande.==
==Dans ces cas, passer directement à la Phase 2 en notant : `Phase 1 sautée — [raison]`.==

==| Triage | Phase 1 |==
==|---|---|==
==| SIMPLE | Étapes 1-2, cadrage en 2 lignes |==
==| COMPLEXE | Étapes 1-2-3, bloc CADRAGE formaté |==

La jurisprudence administrative ne s'interprète que dans son cadre normatif. Identifier les textes applicables avant de chercher des décisions.

**Étape 1 — Formulation des questions juridiques**

Identifier 1 à 3 questions précises à partir de la demande. Si la demande est trop large, la décomposer.

Préciser la **procédure** en cause, car elle détermine la nature de la solution attendue :

| Procédure | Objet |
|---|---|
| Recours pour excès de pouvoir (REP) | Légalité d'un acte administratif |
| Pourvoi en cassation | Contrôle de l'arrêt de la CAA |
| Référé suspension (L. 521-1 CJA) | Urgence + doute sérieux sur la légalité |
| Référé liberté (L. 521-2 CJA) | Atteinte grave et manifestement illégale à une liberté fondamentale |
| Avis contentieux (L. 113-1 CJA) | Question de droit nouvelle, sérieuse, se posant dans de nombreux litiges |
| Recours de plein contentieux | Droits subjectifs, responsabilité, contrats |

**Étape 2 — Identification des textes normatifs applicables**

Pour chaque question :
1. Identifier les textes applicables : CJA, CGCT, code de l'urbanisme, loi, décret, PGD, CEDH, bloc de constitutionnalité.
2. Rechercher les articles via `OpenLegi:rechercher_code` — texte exact, numéro d'article, état de vigueur.
3. Vérifier le statut temporel de chaque texte.

**Règle d'application de la loi dans le temps — impérative**

En droit administratif, la légalité d'un acte s'apprécie **à la date à laquelle il a été pris**, et non à la date du jugement. Vérifier systématiquement :
- Quelle version du texte était en vigueur à la date de l'acte contesté ?
- Si le texte a évolué depuis, le signaler et identifier la version applicable.
- Pour les contrats : c'est la loi en vigueur à la date de la signature qui régit le fond.

Ne pas passer à la Phase 2 sans au moins un texte normatif identifié et applicable.

**Étape 3 — Production du cadre (dans le chat, pas dans un fichier)**

```
CADRAGE — [Objet de la demande]

QUESTION : [Formulation précise]
  Procédure : [REP / cassation / référé / plein contentieux / avis]
  Textes applicables : [Articles + code + état de vigueur à la date de l'acte]
  Conditions légales : [Éléments constitutifs posés par le texte]
  Ce que la jurisprudence doit préciser : [Zone d'incertitude, condition débattue, niveau de contrôle]
```

---

### Phase 2 — Recherche

**Contra reo — absolue**

Chercher systématiquement les décisions contraires. Présenter dans l'ordre hiérarchique — jamais les décisions favorables en premier.

**Hiérarchie des formations**

1. Assemblée du contentieux (Ass.)
2. Section du contentieux (Sect.)
3. Formation plénière (Plén.)
4. Chambres réunies
5. Chambre seule
6. Ordonnance (juge unique)

Un arrêt d'Assemblée prime toujours un arrêt de Section, même postérieur. Signaler explicitement un revirement.

**Codes de publication**

| Code | Signification | Portée |
|---|---|---|
| A | Publié au Recueil Lebon | Apport jurisprudentiel majeur — priorité absolue |
| B | Publié aux Tables du Recueil Lebon | Apport notable |
| C | Non publié | Sans apport particulier — utiliser si A et B insuffisants |

Épuiser les décisions A et B (champ `Recueil` dans les métadonnées) avant de citer des décisions C. Signaler explicitement quand une décision citée est non publiée (Recueil C).

**Séquence de recherche**

1. Construire les termes à partir des questions et conditions légales identifiées en Phase 1.
2. **Première requête : ArianeWeb** `search_arianeweb(query="[termes]", fund="AW_DCE")` — filtre CE pur nativement. Lire `resume`, `formation`, `publication` de chaque résultat.
3. Si un résumé répond directement à la question → citer sans lire le texte intégral.
4. Si lecture du texte intégral nécessaire → Open Legi `rechercher_jurisprudence_administrative` avec le numéro de requête, vérifier `Juridiction = Conseil d'État`.
5. Si aucun résumé ne répond → **mode collaboratif** : présenter les candidats, attendre validation avant lecture.
6. **Rebond PCJA** (systématique dès la première décision pertinente) :
   a. Lire le champ `pcja_codes` de la décision (ex. : `60-01-02-01;54-08-01-03-02`)
   b. Relancer : `search_arianeweb(pcja="[code le plus spécifique]")`
   c. Si volume trop large, combiner : `search_arianeweb(pcja="[code]", query="[termes]")`
   d. `pcja` : match exact — `60-01-02` ne matche pas `60-01-02-01`
   e. Pour élargir, remonter d'un niveau
7. **Vérification évolution récente** (en fin de recherche) : relancer `search_arianeweb` avec les mêmes termes en filtrant sur les dernières années pour détecter un revirement ou une précision.
8. Recherche par numéro de requête (fallback) :
   a. ArianeWeb : `search_arianeweb(numero="[numéro]")`
   b. Open Legi : `search` avec `champ: "ALL"`
   c. WebSearch `site:conseil-etat.fr [numéro]` (dernier recours)

==**Budget de requêtes panorama**==

==| Triage | Règle |==
==|---|---|==
==| SIMPLE | **3-4 panoramas** |==
==| COMPLEXE | Plancher **8 panoramas minimum** |==
==| Plafond | **15** — au-delà, redécomposer |==

==Saturation : s'arrêter après deux requêtes consécutives stériles (au-dessus du plancher).==

==**Calibrage `page_size`**==

==| Triage | `page_size` |==
==|---|---|==
==| SIMPLE | **3 à 5** |==
==| COMPLEXE | **10** (défaut Open Legi) |==

**Matrice de recherche**

| Angle | Description |
|---|---|
| Ancrage impératif | Notion juridique exacte du texte + numéro d'article (ex. : « urgence » + « L. 521-1 ») |
| Calibration lexicale | Plusieurs formules concurrentes pour la même notion (ex. : « doute sérieux », « illégalité manifeste », « atteinte grave ») |
| Reformulation temporelle | Ajouter `sort: DATE_DESC` pour capturer la jurisprudence récente post-réforme |
| Évolution terminologique | Chercher les deux terminologies quand un concept a changé de nom (ex. : « directive » pré-2014 / « lignes directrices » post-2014, « commissaire du gouvernement » pré-2009 / « rapporteur public » post-2009) |
| Rebond PCJA | À partir d'une décision pertinente, lire son champ `pcja_codes` et relancer `search_arianeweb(pcja="[code]")` pour trouver les arrêts classés sur la même rubrique. Combinable avec `query` pour affiner. |

Résultats nuls : deux reformulations distinctes minimum avant de signaler l'échec. En cas d'échec confirmé : le dire, puis produire depuis la connaissance propre, clairement signalé comme tel.

**Conclusions du rapporteur public** : Pour toute décision pertinente, vérifier l'existence de conclusions : `search_arianeweb(fund="AW_CRP", numero="[n°]")`. Si elles existent, les lire de façon ciblée :
1. Appeler `get_conclusion(numero="[n°]")` — le texte intégral est retourné dans le champ `text` ; le PDF est sauvegardé dans `sources/` du projet nomos courant (`saved_pdf_path`, `null` si aucun projet actif).
2. Si le texte dépasse la fenêtre de contexte, il est sauvegardé dans un fichier outil. Utiliser `grep` pour localiser les sections pertinentes (titres de parties, termes de la question posée), puis lire uniquement les passages identifiés via `python3 -c "print(open('[chemin]').read()[A:B])"`.
3. Après lecture, supprimer le PDF sauvegardé si `saved_pdf_path` n'est pas `null` : `Remove-Item "[saved_pdf_path]"`.
4. Vérifier si le rapporteur cite des décisions en lien avec la question qui n'ont pas encore été signalées.

---

### Phase 2 — Lecture (ciblée)

Lire uniquement après avoir retenu une décision sur la base de son résumé ou de ses métadonnées.

**Structure d'une décision CE — plan de lecture**

Le Conseil d'État a abandonné la forme « Considérant que » en 2019 au profit de paragraphes numérotés. Les deux styles coexistent dans la base.

```
1. Visas            → textes visés — ne pas citer comme solution
2. Faits / procédure → contexte factuel
3. Motifs (§§ numérotés ou « Considérant que »)
   → C'est ici que se trouve la solution
   → Repérer : rappel de la règle → application aux faits → conclusion
4. Dispositif       → « Article 1er : ... est annulé » / « Le pourvoi est rejeté »
   ↑ ARRÊT DE LECTURE — s'arrêter ici
```

**Marqueurs selon le style**

| Style | Section à lire | Marqueur |
|---|---|---|
| Nouveau (post-2019) | §§ numérotés, rubriques explicites | Titre de section + numéro de §§ |
| Ancien | « Considérant que » | « Il résulte de ce qui précède que... » précède le dispositif |

Lire uniquement les motifs répondant à la question identifiée en Phase 1, puis le dispositif. S'arrêter au dispositif.

**Niveaux de contrôle — signaux dans l'arrêt**

| Signal dans l'arrêt | Niveau |
|---|---|
| « erreur de droit » | Contrôle entier sur la qualification juridique |
| « erreur manifeste d'appréciation » | Contrôle restreint |
| « pouvoir discrétionnaire » | Contrôle minimal |
| « n'a pas commis d'erreur de droit en jugeant que » | Validation sans contrôle propre |
| « a exactement qualifié les faits » | Contrôle normal de la qualification |

Ne jamais qualifier le niveau de contrôle sans avoir vérifié la formule utilisée dans l'arrêt.

**Portée**

- **Arrêt de principe** : Assemblée ou Section, publié Recueil (A), formule générale → fonde une règle.
- **Décision d'espèce** : solution liée aux faits, portée limitée.
- **Avis contentieux** : lie la juridiction de renvoi et oriente les juridictions inférieures saisies de la même question.

---

## §3 — Format de sortie

Résumé court dans le chat + numéro de requête + lien Légifrance. Pas de fichier Markdown. Ne pas construire d'argumentation ni faire de cours.

**Synthèse finale — exhaustivité obligatoire**

La synthèse clôt chaque recherche. Elle comprend :
1. **Toutes les décisions CE pertinentes trouvées**, classées par formation et publication (A → B → C), pas seulement les plus importantes.
2. **Les conclusions du rapporteur public** disponibles : mentionner le nom du rapporteur et le numéro CRP.

**Format de citation**

```
CE, [formation], [date], [nom usuel], n° [requête][, Rec. si publié au Recueil].
Ex. : CE, Ass., 8 févr. 2007, Gardedieu, n° 279522, Rec. 78.

**Statut épistémique — obligatoire à l'issue**

- **Constante** : solution uniforme et concordante
- **Divisée** : courants contradictoires, les exposer
- **Incertaine** : décisions insuffisantes, question non tranchée ou renvoyée aux juges du fond
