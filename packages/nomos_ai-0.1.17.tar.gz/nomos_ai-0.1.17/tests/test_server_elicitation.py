"""Tests pour la fonctionnalité d'élicitation MCP des entités de NomosAI."""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from nomosai.server import _build_entity_schema
from nomosai.engine import DEFAULT_ENTITIES


# ---------------------------------------------------------------------------
# _build_entity_schema — construit le schéma Pydantic pour l'élicitation
# ---------------------------------------------------------------------------

def test_build_entity_schema_fr_includes_all_default_entities():
    schema = _build_entity_schema("fr")
    fields = schema.model_fields
    for entity_type in DEFAULT_ENTITIES:
        assert entity_type in fields, f"Champ manquant : {entity_type}"


def test_build_entity_schema_fr_includes_french_only():
    schema = _build_entity_schema("fr")
    fields = schema.model_fields
    for fr_type in ("FR_NIR", "FR_SIRET", "FR_SIREN", "FR_TVA", "FR_PASSPORT", "FR_CNI"):
        assert fr_type in fields, f"Champ FR manquant : {fr_type}"


def test_build_entity_schema_en_excludes_french_only():
    schema = _build_entity_schema("en")
    fields = schema.model_fields
    for fr_type in ("FR_NIR", "FR_SIRET", "FR_SIREN", "FR_TVA", "FR_PASSPORT", "FR_CNI"):
        assert fr_type not in fields, f"Champ FR inattendu pour 'en' : {fr_type}"


def test_build_entity_schema_opt_in_default_false():
    schema = _build_entity_schema("fr")
    fields = schema.model_fields
    assert fields["DATE_TIME"].default is False
    assert fields["FILE_PATH"].default is False


def test_build_entity_schema_standard_entities_default_true():
    schema = _build_entity_schema("fr")
    fields = schema.model_fields
    for entity_type in ("PERSON", "EMAIL_ADDRESS", "PHONE_NUMBER", "ORGANIZATION"):
        assert fields[entity_type].default is True, f"Défaut incorrect pour {entity_type}"


def test_build_entity_schema_person_has_description():
    schema = _build_entity_schema("fr")
    fields = schema.model_fields
    assert fields["PERSON"].description == "Noms de personnes physiques"


def test_build_entity_schema_returns_instantiable_model():
    schema = _build_entity_schema("fr")
    instance = schema()
    assert hasattr(instance, "PERSON")
    assert instance.PERSON is True
    assert instance.DATE_TIME is False


def test_build_entity_schema_model_dump_returns_bool_dict():
    schema = _build_entity_schema("fr")
    data = schema().model_dump()
    assert isinstance(data, dict)
    for v in data.values():
        assert isinstance(v, bool)


# ---------------------------------------------------------------------------
# Helpers pour mocker l'élicitation MCP
# ---------------------------------------------------------------------------

def _make_elicit_result(action: str, selected: dict | None = None):
    """Simule un ElicitationResult du SDK MCP."""
    r = MagicMock()
    r.action = action
    if selected is not None:
        r.data = MagicMock()
        r.data.model_dump.return_value = selected
    else:
        r.data = None
    return r


def _make_mock_analyzer():
    """Analyseur Presidio mocké qui ne détecte aucune entité."""
    analyzer = MagicMock()
    analyzer.analyze.return_value = []
    return analyzer


# ---------------------------------------------------------------------------
# Comportement de l'élicitation dans anonymize_file
# ---------------------------------------------------------------------------

@patch("nomosai.server._get_analyzer")
async def test_elicitation_accept_calls_elicit_once(mock_get_analyzer, tmp_path):
    from nomosai.server import anonymize_file

    mock_get_analyzer.return_value = _make_mock_analyzer()
    doc = tmp_path / "doc.txt"
    doc.write_text("Jean Dupont habite à Paris.", encoding="utf-8")

    selected = {"PERSON": True, "EMAIL_ADDRESS": False, "LOCATION": False,
                "PHONE_NUMBER": False, "ORGANIZATION": False}
    mock_ctx = MagicMock()
    mock_ctx.elicit = AsyncMock(return_value=_make_elicit_result("accept", selected))

    result = await anonymize_file(ctx=mock_ctx, file_path=str(doc), elicit_entities=True)

    assert result["success"] is True
    mock_ctx.elicit.assert_called_once()
    assert "elicitation_fallback" not in result


@patch("nomosai.server._get_analyzer")
async def test_elicitation_cancel_falls_back_to_default(mock_get_analyzer, tmp_path):
    from nomosai.server import anonymize_file

    mock_get_analyzer.return_value = _make_mock_analyzer()
    doc = tmp_path / "doc.txt"
    doc.write_text("contenu test", encoding="utf-8")

    mock_ctx = MagicMock()
    mock_ctx.elicit = AsyncMock(return_value=_make_elicit_result("cancel"))

    result = await anonymize_file(ctx=mock_ctx, file_path=str(doc), elicit_entities=True)

    assert result["success"] is True
    assert result.get("elicitation_fallback") is True


@patch("nomosai.server._get_analyzer")
async def test_elicitation_decline_falls_back_to_default(mock_get_analyzer, tmp_path):
    from nomosai.server import anonymize_file

    mock_get_analyzer.return_value = _make_mock_analyzer()
    doc = tmp_path / "doc.txt"
    doc.write_text("contenu test", encoding="utf-8")

    mock_ctx = MagicMock()
    mock_ctx.elicit = AsyncMock(return_value=_make_elicit_result("decline"))

    result = await anonymize_file(ctx=mock_ctx, file_path=str(doc), elicit_entities=True)

    assert result["success"] is True
    assert result.get("elicitation_fallback") is True


@patch("nomosai.server._get_analyzer")
async def test_elicitation_exception_falls_back_to_default(mock_get_analyzer, tmp_path):
    from nomosai.server import anonymize_file

    mock_get_analyzer.return_value = _make_mock_analyzer()
    doc = tmp_path / "doc.txt"
    doc.write_text("contenu test", encoding="utf-8")

    mock_ctx = MagicMock()
    mock_ctx.elicit = AsyncMock(side_effect=RuntimeError("client sans support élicitation"))

    result = await anonymize_file(ctx=mock_ctx, file_path=str(doc), elicit_entities=True)

    assert result["success"] is True
    assert result.get("elicitation_fallback") is True


@patch("nomosai.server._get_analyzer")
async def test_no_elicitation_when_entities_provided(mock_get_analyzer, tmp_path):
    """Si entities est fourni, elicit_entities est ignoré."""
    from nomosai.server import anonymize_file

    mock_get_analyzer.return_value = _make_mock_analyzer()
    doc = tmp_path / "doc.txt"
    doc.write_text("contenu test", encoding="utf-8")

    mock_ctx = MagicMock()
    mock_ctx.elicit = AsyncMock()

    result = await anonymize_file(
        ctx=mock_ctx,
        file_path=str(doc),
        entities=["PERSON"],
        elicit_entities=True,
    )

    mock_ctx.elicit.assert_not_called()
    assert result["success"] is True
    assert "elicitation_fallback" not in result


@patch("nomosai.server._get_analyzer")
async def test_no_elicitation_by_default(mock_get_analyzer, tmp_path):
    """Sans elicit_entities=True, ctx.elicit ne doit jamais être appelé."""
    from nomosai.server import anonymize_file

    mock_get_analyzer.return_value = _make_mock_analyzer()
    doc = tmp_path / "doc.txt"
    doc.write_text("contenu test", encoding="utf-8")

    mock_ctx = MagicMock()
    mock_ctx.elicit = AsyncMock()

    result = await anonymize_file(ctx=mock_ctx, file_path=str(doc))

    mock_ctx.elicit.assert_not_called()
    assert result["success"] is True
    assert "elicitation_fallback" not in result
