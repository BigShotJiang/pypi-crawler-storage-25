"""
Tests unitaires purs pour les fonctions helper du serveur NomosAI et l'outil MCP
list_entities — aucun chargement de modèle NLP requis.
"""

import json
import re
import pytest
from pathlib import Path
from nomosai.server import (
    _validate_entities,
    _merge_index_entries,
    _find_confidential_dir,
    _read_global_index,
    _write_global_index,
    _build_settings,
    _build_claude_md,
    list_entities,
)
from nomosai.engine import DEFAULT_ENTITIES


# ---------------------------------------------------------------------------
# _validate_entities — contrat : (valid_list, unknown_list)
# ---------------------------------------------------------------------------

def test_validate_none_returns_default_entities():
    valid, unknown = _validate_entities(None)
    assert valid == DEFAULT_ENTITIES
    assert unknown == []


def test_validate_known_entities_returned_as_valid():
    valid, unknown = _validate_entities(["PERSON", "EMAIL_ADDRESS"])
    assert "PERSON" in valid
    assert "EMAIL_ADDRESS" in valid
    assert unknown == []


def test_validate_unknown_entities_reported():
    valid, unknown = _validate_entities(["PERSON", "FAKE_ENTITY"])
    assert "FAKE_ENTITY" in unknown
    assert "PERSON" in valid


def test_validate_all_unknown_falls_back_to_defaults():
    valid, unknown = _validate_entities(["NONEXISTENT_A", "NONEXISTENT_B"])
    assert valid == DEFAULT_ENTITIES
    assert set(unknown) == {"NONEXISTENT_A", "NONEXISTENT_B"}


def test_validate_mixed_preserves_only_known():
    valid, unknown = _validate_entities(["PERSON", "BAD1", "EMAIL_ADDRESS", "BAD2"])
    assert set(valid) == {"PERSON", "EMAIL_ADDRESS"}
    assert set(unknown) == {"BAD1", "BAD2"}


# ---------------------------------------------------------------------------
# _merge_index_entries — contrat : clé unique = placeholder
# ---------------------------------------------------------------------------

def _entry(placeholder, original, entity_type="PERSON"):
    return {"placeholder": placeholder, "original": original,
            "entity_type": entity_type, "label": entity_type}


def test_merge_adds_new_entries():
    existing = [_entry("[PERSONNE_1]", "Alice")]
    new = [_entry("[EMAIL_1]", "alice@test.com", "EMAIL_ADDRESS")]
    merged = _merge_index_entries(existing, new)
    assert len(merged) == 2


def test_merge_deduplicates_by_placeholder_new_wins():
    existing = [_entry("[PERSONNE_1]", "Alice")]
    new = [_entry("[PERSONNE_1]", "Alice Updated")]
    merged = _merge_index_entries(existing, new)
    assert len(merged) == 1
    assert merged[0]["original"] == "Alice Updated"


def test_merge_empty_existing():
    new = [_entry("[PERSONNE_1]", "Bob")]
    assert len(_merge_index_entries([], new)) == 1


def test_merge_empty_new():
    existing = [_entry("[PERSONNE_1]", "Alice")]
    assert len(_merge_index_entries(existing, [])) == 1


def test_merge_both_empty():
    assert _merge_index_entries([], []) == []


# ---------------------------------------------------------------------------
# _find_confidential_dir — contrat : retrouve documents-confidentiels/ par heuristique
# ---------------------------------------------------------------------------

def test_find_confidential_dir_as_ancestor_of_input(tmp_path):
    conf = tmp_path / "documents-confidentiels"
    conf.mkdir()
    doc = conf / "document.pdf"
    doc.touch()
    out = tmp_path / "documents-anonymisés" / "document.md"
    result = _find_confidential_dir(doc, out)
    assert result == conf


def test_find_confidential_dir_as_sibling_of_input_parent(tmp_path):
    conf = tmp_path / "documents-confidentiels"
    conf.mkdir()
    sources = tmp_path / "sources"
    sources.mkdir()
    doc = sources / "document.pdf"
    doc.touch()
    out = tmp_path / "documents-anonymisés" / "document.md"
    result = _find_confidential_dir(doc, out)
    assert result == conf


def test_find_confidential_dir_not_found(tmp_path):
    doc = tmp_path / "document.pdf"
    doc.touch()
    out = tmp_path / "document_anonymise.md"
    result = _find_confidential_dir(doc, out)
    assert result is None


def test_find_confidential_dir_found_via_output_path(tmp_path):
    # Le répertoire documents-confidentiels/ est ancêtre du chemin de sortie
    conf = tmp_path / "projet" / "documents-confidentiels"
    conf.mkdir(parents=True)
    doc = tmp_path / "autre" / "doc.pdf"
    doc.parent.mkdir(parents=True)
    doc.touch()
    out = tmp_path / "projet" / "documents-confidentiels" / "documents-anonymisés" / "doc.md"
    result = _find_confidential_dir(doc, out)
    assert result == conf


# ---------------------------------------------------------------------------
# list_entities — outil MCP, aucun modèle requis
# ---------------------------------------------------------------------------

def test_list_entities_returns_required_keys():
    result = list_entities("fr")
    assert "default_entities" in result
    assert "opt_in_entities" in result
    assert "total_default" in result
    assert "total_opt_in" in result
    assert "language" in result
    assert "note" in result


def test_list_entities_fr_includes_french_specific():
    result = list_entities("fr")
    default_types = {e["entity_type"] for e in result["default_entities"]}
    assert "FR_NIR" in default_types
    assert "FR_SIRET" in default_types
    assert "FR_SIREN" in default_types
    assert "FR_TVA" in default_types


def test_list_entities_en_excludes_french_only():
    result = list_entities("en")
    all_types = (
        {e["entity_type"] for e in result["default_entities"]}
        | {e["entity_type"] for e in result["opt_in_entities"]}
    )
    assert "FR_NIR" not in all_types
    assert "FR_SIRET" not in all_types


def test_list_entities_opt_in_contains_datetime_and_filepath():
    result = list_entities("fr")
    opt_in_types = {e["entity_type"] for e in result["opt_in_entities"]}
    assert "DATE_TIME" in opt_in_types
    assert "FILE_PATH" in opt_in_types


def test_list_entities_opt_in_not_in_default():
    result = list_entities("fr")
    default_types = {e["entity_type"] for e in result["default_entities"]}
    assert "DATE_TIME" not in default_types
    assert "FILE_PATH" not in default_types


def test_list_entities_counts_match_list_lengths():
    result = list_entities("fr")
    assert result["total_default"] == len(result["default_entities"])
    assert result["total_opt_in"] == len(result["opt_in_entities"])


def test_list_entities_each_entry_has_required_keys():
    result = list_entities("fr")
    required = {"entity_type", "label", "description", "opt_in"}
    for entry in result["default_entities"] + result["opt_in_entities"]:
        assert required <= set(entry.keys()), f"Missing keys in {entry}"


def test_list_entities_language_echoed():
    assert list_entities("fr")["language"] == "fr"
    assert list_entities("en")["language"] == "en"


# ---------------------------------------------------------------------------
# _build_settings — gabarit JSON pour les hooks Claude Code
# ---------------------------------------------------------------------------

def test_build_settings_is_valid_json():
    settings = json.loads(_build_settings())
    assert isinstance(settings, dict)


def test_build_settings_has_pretooluse_hook():
    settings = json.loads(_build_settings())
    assert "hooks" in settings
    hooks = settings["hooks"]
    assert "PreToolUse" in hooks
    assert len(hooks["PreToolUse"]) > 0


def test_build_settings_hook_targets_read_and_edit():
    settings = json.loads(_build_settings())
    matchers = [h["matcher"] for h in settings["hooks"]["PreToolUse"]]
    assert any("Read" in m for m in matchers)
    assert any("Edit" in m for m in matchers)


def test_build_settings_hook_references_block_script():
    settings = json.loads(_build_settings())
    commands = [
        h["command"]
        for group in settings["hooks"]["PreToolUse"]
        for h in group.get("hooks", [])
    ]
    assert any("block_confidentiel" in cmd for cmd in commands)


# ---------------------------------------------------------------------------
# _build_claude_md — gabarit Markdown pour les projets juridiques
# ---------------------------------------------------------------------------

def test_build_claude_md_contains_project_name():
    md = _build_claude_md("MonProjet")
    assert "MonProjet" in md


def test_build_claude_md_documents_all_subdirs():
    md = _build_claude_md("Test")
    for subdir in ("documents-confidentiels/", "sources/", "documents-anonymisés/", "livrables/", "artefacts/"):
        assert subdir in md, f"Répertoire manquant dans CLAUDE.md : {subdir}"


def test_build_claude_md_mentions_anonymize_file_tool():
    md = _build_claude_md("Test")
    assert "anonymize_file" in md


def test_build_claude_md_mentions_confidential_restriction():
    md = _build_claude_md("Test")
    # Le CLAUDE.md doit signaler que la lecture directe est interdite
    assert "interdit" in md.lower() or "interdite" in md.lower()


# ---------------------------------------------------------------------------
# Constantes templates — _TEMPLATES_DIR / _TEMPLATE_FILES
# ---------------------------------------------------------------------------

def test_templates_dir_is_a_path():
    from nomosai.server import _TEMPLATES_DIR
    from pathlib import Path
    assert isinstance(_TEMPLATES_DIR, Path)


def test_template_files_has_defense_and_demande():
    from nomosai.server import _TEMPLATE_FILES
    assert "defense" in _TEMPLATE_FILES
    assert "demande" in _TEMPLATE_FILES


# ---------------------------------------------------------------------------
# _build_claude_md — comportement avec dossier_type
# ---------------------------------------------------------------------------

def test_build_claude_md_generic_no_type():
    """Sans dossier_type, le CLAUDE.md ne contient pas de section template."""
    md = _build_claude_md("MonProjet")
    assert "MonProjet" in md
    assert "documents-confidentiels/" in md
    assert "Mémoire en défense" not in md
    assert "Mémoire ampliatif" not in md


def test_build_claude_md_defense_appends_template(tmp_path, monkeypatch):
    """Avec dossier_type='defense', le contenu de dossier-defense.md est appendé."""
    fake_dir = tmp_path
    (fake_dir / "dossier-defense.md").write_text("# Mémoire en défense\nContenu défense.", encoding="utf-8")
    import nomosai.server._project as _proj
    monkeypatch.setattr(_proj, "_TEMPLATES_DIR", fake_dir)
    md = _build_claude_md("MonProjet", dossier_type="defense")
    assert "documents-confidentiels/" in md
    assert "# Mémoire en défense" in md
    assert "Contenu défense." in md
    assert "---" in md


def test_build_claude_md_demande_appends_template(tmp_path, monkeypatch):
    """Avec dossier_type='demande', le contenu de dossier-demande.md est appendé."""
    fake_dir = tmp_path
    (fake_dir / "dossier-demande.md").write_text("# Mémoire ampliatif\nContenu demande.", encoding="utf-8")
    import nomosai.server._project as _proj
    monkeypatch.setattr(_proj, "_TEMPLATES_DIR", fake_dir)
    md = _build_claude_md("MonProjet", dossier_type="demande")
    assert "documents-confidentiels/" in md
    assert "# Mémoire ampliatif" in md
    assert "Contenu demande." in md


def test_build_claude_md_unknown_type_is_generic():
    """Un dossier_type inconnu produit le CLAUDE.md générique sans erreur."""
    md = _build_claude_md("MonProjet", dossier_type="autre")
    assert "MonProjet" in md
    assert "documents-confidentiels/" in md
    assert "Mémoire en défense" not in md
    assert "Mémoire ampliatif" not in md


def test_build_claude_md_template_missing_returns_generic(tmp_path, monkeypatch):
    """Si le fichier template est absent, retourne le corps commun sans erreur."""
    import nomosai.server._project as _proj
    monkeypatch.setattr(_proj, "_TEMPLATES_DIR", tmp_path)
    md = _build_claude_md("MonProjet", dossier_type="defense")
    assert "MonProjet" in md
    assert "documents-confidentiels/" in md
    assert "Mémoire en défense" not in md


# ---------------------------------------------------------------------------
# MCP tools — chemins d'erreur qui ne nécessitent pas de modèle NLP
# ---------------------------------------------------------------------------


async def test_mcp_anonymize_file_file_not_found(mock_ctx):
    from nomosai.server import anonymize_file
    result = await anonymize_file(ctx=mock_ctx, file_path="/nonexistent/document.pdf")
    assert result["success"] is False
    assert result["error_type"] == "FileNotFound"


async def test_mcp_anonymize_file_unsupported_format(tmp_path, mock_ctx):
    from nomosai.server import anonymize_file
    doc = tmp_path / "document.xyz"
    doc.write_text("contenu", encoding="utf-8")
    result = await anonymize_file(ctx=mock_ctx, file_path=str(doc))
    assert result["success"] is False
    assert result["error_type"] == "UnsupportedFormat"


async def test_mcp_anonymize_file_unsupported_language(tmp_path, mock_ctx):
    from nomosai.server import anonymize_file
    doc = tmp_path / "document.txt"
    doc.write_text("contenu", encoding="utf-8")
    result = await anonymize_file(ctx=mock_ctx, file_path=str(doc), language="xx")
    assert result["success"] is False
    assert result["error_type"] == "UnsupportedLanguage"


def test_mcp_deanonymize_file_not_found():
    from nomosai.server import deanonymize_file
    result = deanonymize_file(anonymized_file_path="/nonexistent/doc.md")
    assert result["success"] is False
    assert result["error_type"] == "FileNotFound"


def test_mcp_deanonymize_file_wrong_extension(tmp_path):
    from nomosai.server import deanonymize_file
    doc = tmp_path / "doc.txt"
    doc.write_text("contenu", encoding="utf-8")
    result = deanonymize_file(anonymized_file_path=str(doc))
    assert result["success"] is False
    assert result["error_type"] == "InvalidFormat"


def test_mcp_deanonymize_file_index_not_found(tmp_path):
    from nomosai.server import deanonymize_file
    doc = tmp_path / "doc_anonymise.md"
    doc.write_text("[PERSONNE_1] a signé.", encoding="utf-8")
    result = deanonymize_file(anonymized_file_path=str(doc))
    assert result["success"] is False
    assert result["error_type"] == "IndexNotFound"


def test_mcp_deanonymize_file_explicit_index_not_found(tmp_path):
    from nomosai.server import deanonymize_file
    doc = tmp_path / "doc_anonymise.md"
    doc.write_text("[PERSONNE_1] a signé.", encoding="utf-8")
    result = deanonymize_file(
        anonymized_file_path=str(doc),
        index_path="/nonexistent/index.md",
    )
    assert result["success"] is False
    assert result["error_type"] == "FileNotFound"


def test_mcp_deanonymize_file_empty_index(tmp_path):
    from nomosai.server import deanonymize_file
    doc = tmp_path / "doc_anonymise.md"
    doc.write_text("[PERSONNE_1] a signé.", encoding="utf-8")
    idx = tmp_path / "doc_anonymise-index.md"
    idx.write_text("# Index vide\nAucun placeholder.\n", encoding="utf-8")
    result = deanonymize_file(anonymized_file_path=str(doc))
    assert result["success"] is False
    assert result["error_type"] == "EmptyIndex"


def test_mcp_deanonymize_file_success(tmp_path):
    from nomosai.server import deanonymize_file
    doc = tmp_path / "doc_anonymise.md"
    doc.write_text("[PERSONNE_1] a signé.", encoding="utf-8")
    idx = tmp_path / "doc_anonymise-index.md"
    idx.write_text(
        "| Placeholder | Valeur originale | Type |\n"
        "| --- | --- | --- |\n"
        "| `[PERSONNE_1]` | Jean Dupont | `PERSONNE` |\n",
        encoding="utf-8",
    )
    result = deanonymize_file(anonymized_file_path=str(doc))
    assert result["success"] is True
    assert result["replacements_count"] == 1
    output = Path(result["output_path"]).read_text(encoding="utf-8")
    assert "Jean Dupont" in output


def test_mcp_initiate_project_creates_structure(tmp_path):
    import asyncio
    from unittest.mock import AsyncMock, MagicMock
    import nomosai.server as srv

    ctx = AsyncMock()
    cancelled = MagicMock()
    cancelled.action = "cancel"
    cancelled.data = None
    ctx.elicit = AsyncMock(return_value=cancelled)

    project_dir = tmp_path / "mon_projet"
    result = asyncio.run(srv.initiate_project(ctx, directory=str(project_dir), project_name="MonProjet"))
    assert result["success"] is True
    for subdir in ("documents-confidentiels", "sources", "documents-anonymisés", "livrables", "artefacts"):
        assert (project_dir / subdir).is_dir(), f"Répertoire manquant : {subdir}/"
    assert Path(result["claude_md_path"]).exists()
    assert Path(result["hook_path"]).exists()
    assert Path(result["settings_path"]).exists()


def test_mcp_initiate_project_claude_md_contains_name(tmp_path):
    import asyncio
    from unittest.mock import AsyncMock, MagicMock
    import nomosai.server as srv

    ctx = AsyncMock()
    cancelled = MagicMock()
    cancelled.action = "cancel"
    cancelled.data = None
    ctx.elicit = AsyncMock(return_value=cancelled)

    result = asyncio.run(srv.initiate_project(ctx, directory=str(tmp_path / "p"), project_name="TestNomosAI"))
    assert "TestNomosAI" in Path(result["claude_md_path"]).read_text(encoding="utf-8")


def test_mcp_initiate_project_defense_template_loaded(tmp_path, monkeypatch):
    """Avec dossier_type='defense' et template présent, le CLAUDE.md contient le template."""
    import asyncio
    from unittest.mock import AsyncMock
    import nomosai.server as srv

    fake_templates = tmp_path / "templates"
    fake_templates.mkdir()
    (fake_templates / "dossier-defense.md").write_text(
        "# Mémoire en défense\nInstructions défense.", encoding="utf-8"
    )
    monkeypatch.setattr(srv, "_TEMPLATES_DIR", fake_templates)

    ctx = AsyncMock()  # elicit not called when dossier_type is provided

    project_dir = tmp_path / "projet_defense"
    result = asyncio.run(srv.initiate_project(
        ctx,
        directory=str(project_dir),
        project_name="DossierDéfense",
        dossier_type="defense",
    ))
    assert result["success"] is True
    assert result["dossier_type"] == "defense"
    assert result["template_loaded"] is True
    claude_md = Path(result["claude_md_path"]).read_text(encoding="utf-8")
    assert "DossierDéfense" in claude_md
    assert "# Mémoire en défense" in claude_md


def test_mcp_initiate_project_generic_when_no_type(tmp_path):
    """Sans dossier_type, le projet est créé et template_loaded est False."""
    import asyncio
    from unittest.mock import AsyncMock, MagicMock
    import nomosai.server as srv

    ctx = AsyncMock()
    cancelled = MagicMock()
    cancelled.action = "cancel"
    cancelled.data = None
    ctx.elicit = AsyncMock(return_value=cancelled)

    result = asyncio.run(srv.initiate_project(ctx, directory=str(tmp_path / "p"), project_name="Générique"))
    assert result["success"] is True
    assert result["dossier_type"] == "generic"
    assert result["template_loaded"] is False
    claude_md = Path(result["claude_md_path"]).read_text(encoding="utf-8")
    assert "Générique" in claude_md
    assert "Mémoire en défense" not in claude_md
    assert "Mémoire ampliatif" not in claude_md


# ---------------------------------------------------------------------------
# _read_global_index — lecture de l'index global depuis documents-confidentiels/
# ---------------------------------------------------------------------------

def _write_index_file(conf_dir: Path, content: str) -> None:
    (conf_dir / "_nomos_index.md").write_text(content, encoding="utf-8")


def test_read_global_index_no_file_returns_empty(tmp_path):
    result = _read_global_index(tmp_path)
    assert result == []


def test_read_global_index_parses_valid_row(tmp_path):
    _write_index_file(tmp_path, (
        "---\n"
        "generated: 2026-01-01 00:00:00\n"
        "total_entities: 1\n"
        "---\n\n"
        "| Placeholder | Valeur originale | Entité |\n"
        "| --- | --- | --- |\n"
        "| `[PERSONNE_1]` | Jean Dupont | `PERSON` |\n"
    ))
    entries = _read_global_index(tmp_path)
    assert len(entries) == 1
    assert entries[0]["placeholder"] == "[PERSONNE_1]"
    assert entries[0]["original"] == "Jean Dupont"
    assert entries[0]["entity_type"] == "PERSON"


def test_read_global_index_skips_non_matching_lines(tmp_path):
    _write_index_file(tmp_path, (
        "# Index global\n"
        "\n"
        "| --- | --- | --- |\n"
        "| `[EMAIL_1]` | alice@test.com | `EMAIL_ADDRESS` |\n"
    ))
    entries = _read_global_index(tmp_path)
    assert len(entries) == 1
    assert entries[0]["placeholder"] == "[EMAIL_1]"


def test_read_global_index_unescapes_pipe(tmp_path):
    _write_index_file(tmp_path, (
        "| `[PERSONNE_1]` | Jean \\| Dupont | `PERSON` |\n"
    ))
    entries = _read_global_index(tmp_path)
    assert entries[0]["original"] == "Jean | Dupont"


def test_read_global_index_unescapes_newline(tmp_path):
    _write_index_file(tmp_path, (
        "| `[PERSONNE_1]` | Jean\\nDupont | `PERSON` |\n"
    ))
    entries = _read_global_index(tmp_path)
    assert entries[0]["original"] == "Jean\nDupont"


def test_read_global_index_unreadable_file_returns_empty(tmp_path):
    # Crée un RÉPERTOIRE au lieu d'un fichier → read_text() lève une exception
    (tmp_path / "_nomos_index.md").mkdir()
    result = _read_global_index(tmp_path)
    assert result == []


def test_read_global_index_multiple_entries(tmp_path):
    _write_index_file(tmp_path, (
        "| `[PERSONNE_1]` | Alice Martin | `PERSON` |\n"
        "| `[EMAIL_1]` | alice@test.com | `EMAIL_ADDRESS` |\n"
        "| `[PERSONNE_2]` | Bob Dupont | `PERSON` |\n"
    ))
    entries = _read_global_index(tmp_path)
    assert len(entries) == 3
    placeholders = {e["placeholder"] for e in entries}
    assert "[PERSONNE_1]" in placeholders
    assert "[EMAIL_1]" in placeholders
    assert "[PERSONNE_2]" in placeholders


# ---------------------------------------------------------------------------
# _write_global_index — écriture de l'index global dans documents-confidentiels/
# ---------------------------------------------------------------------------

def test_write_global_index_creates_file(tmp_path):
    entries = [{"placeholder": "[PERSONNE_1]", "original": "Alice", "entity_type": "PERSON", "label": "PERSONNE"}]
    idx_path = _write_global_index(tmp_path, entries)
    assert idx_path.exists()
    assert idx_path.name == "_nomos_index.md"


def test_write_global_index_contains_placeholder(tmp_path):
    entries = [{"placeholder": "[EMAIL_1]", "original": "alice@test.com", "entity_type": "EMAIL_ADDRESS", "label": "EMAIL"}]
    _write_global_index(tmp_path, entries)
    content = (tmp_path / "_nomos_index.md").read_text(encoding="utf-8")
    assert "`[EMAIL_1]`" in content
    assert "alice@test.com" in content
    assert "`EMAIL_ADDRESS`" in content


def test_write_global_index_escapes_pipe_in_original(tmp_path):
    entries = [{"placeholder": "[PERSONNE_1]", "original": "Jean | Dupont", "entity_type": "PERSON", "label": "PERSONNE"}]
    _write_global_index(tmp_path, entries)
    content = (tmp_path / "_nomos_index.md").read_text(encoding="utf-8")
    assert r"Jean \| Dupont" in content


def test_write_global_index_contains_total_entities(tmp_path):
    entries = [
        {"placeholder": "[PERSONNE_1]", "original": "Alice", "entity_type": "PERSON", "label": "PERSONNE"},
        {"placeholder": "[EMAIL_1]", "original": "alice@test.com", "entity_type": "EMAIL_ADDRESS", "label": "EMAIL"},
    ]
    _write_global_index(tmp_path, entries)
    content = (tmp_path / "_nomos_index.md").read_text(encoding="utf-8")
    assert "total_entities: 2" in content


def test_write_then_read_roundtrip(tmp_path):
    entries = [
        {"placeholder": "[PERSONNE_1]", "original": "Jean Dupont", "entity_type": "PERSON", "label": "PERSONNE"},
        {"placeholder": "[EMAIL_1]", "original": "jean@test.com", "entity_type": "EMAIL_ADDRESS", "label": "EMAIL"},
    ]
    _write_global_index(tmp_path, entries)
    read_back = _read_global_index(tmp_path)
    assert len(read_back) == 2
    placeholders = {e["placeholder"] for e in read_back}
    assert "[PERSONNE_1]" in placeholders
    assert "[EMAIL_1]" in placeholders


# ---------------------------------------------------------------------------
# update_nomos_skills — liste puis mise à jour par noms
# ---------------------------------------------------------------------------


def _make_fake_skills_src(tmp_path: Path, names: list) -> Path:
    """Crée de faux répertoires de skills dans tmp_path."""
    src = tmp_path / "nomos-skills"
    src.mkdir()
    for name in names:
        sd = src / name
        sd.mkdir()
        (sd / "SKILL.md").write_text(f"# {name}", encoding="utf-8")
        (sd / "content.txt").write_text(f"contenu de {name}", encoding="utf-8")
    return src


def test_update_nomos_skills_no_names_returns_list(tmp_path, monkeypatch):
    import nomosai.server as srv
    import nomosai.server._skills as _skl

    src = _make_fake_skills_src(tmp_path, ["skill-alpha", "skill-beta"])
    monkeypatch.setattr(_skl, "_NOMOS_SKILLS_SRC_DIR", src)

    result = srv.update_nomos_skills(skills_dir=str(tmp_path / "skills"))

    assert result["success"] is True
    assert result["action"] == "selection_required"
    names = [s["name"] for s in result["available_skills"]]
    assert "skill-alpha" in names
    assert "skill-beta" in names
    assert all("index" in s and "description" in s for s in result["available_skills"])


def test_update_nomos_skills_updates_selected(tmp_path, monkeypatch):
    import nomosai.server as srv
    import nomosai.server._skills as _skl

    src = _make_fake_skills_src(tmp_path, ["skill-alpha", "skill-beta"])
    skills_target = tmp_path / "skills"
    skills_target.mkdir()
    (skills_target / "skill-alpha").mkdir()
    (skills_target / "skill-alpha" / "SKILL.md").write_text("# old", encoding="utf-8")

    monkeypatch.setattr(_skl, "_NOMOS_SKILLS_SRC_DIR", src)

    result = srv.update_nomos_skills(
        skill_names=["skill-alpha"],
        skills_dir=str(skills_target),
    )

    assert result["success"] is True
    assert "skill-alpha" in result["updated"]
    assert "skill-beta" in result["skipped"]
    assert (skills_target / "skill-alpha" / "SKILL.md").read_text(encoding="utf-8") == "# skill-alpha"


def test_update_nomos_skills_unknown_name_reported(tmp_path, monkeypatch):
    import nomosai.server as srv
    import nomosai.server._skills as _skl

    src = _make_fake_skills_src(tmp_path, ["skill-alpha"])
    monkeypatch.setattr(_skl, "_NOMOS_SKILLS_SRC_DIR", src)

    result = srv.update_nomos_skills(
        skill_names=["does-not-exist"],
        skills_dir=str(tmp_path / "skills"),
    )

    assert result["success"] is False
    assert result["error_type"] == "UnknownSkills"


def test_update_nomos_skills_missing_src_returns_error(tmp_path, monkeypatch):
    import nomosai.server._skills as _skl

    monkeypatch.setattr(_skl, "_NOMOS_SKILLS_SRC_DIR", tmp_path / "nonexistent")

    result = _skl.update_nomos_skills(skills_dir=str(tmp_path / "skills"))

    assert result["success"] is False
    assert result["error_type"] == "SkillsSourceNotFound"
