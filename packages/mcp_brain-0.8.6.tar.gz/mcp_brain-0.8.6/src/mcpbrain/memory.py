"""Memory for MCP agents — working memory, learned patterns, and session index."""

import os
import re
import json
import time
import threading
import uuid
from pathlib import Path
from typing import List, Dict, Any, Optional

from .logging_config import log as _log


# ── Shared utilities ───────────────────────────────────────────────────────────

_STOPWORDS = frozenset({
    "this", "that", "with", "from", "have", "they", "what", "when", "where",
    "which", "their", "there", "being", "were", "been", "have", "has", "had",
    "will", "would", "could", "should", "about", "into", "only", "other",
    "some", "these", "those", "file", "files", "code", "session", "mcp",
    "brain", "read", "task", "please", "tell", "give", "want", "need",
})


def _fingerprint_task(task: str, max_words: int = 20) -> str:
    """Create a normalized task fingerprint from keywords for similarity matching."""
    words = re.findall(r'\b\w{4,}\b', task.lower())
    significant = sorted(w for w in words if w not in _STOPWORDS)
    return " ".join(significant[:max_words])


def _jaccard(fp1: str, fp2: str) -> float:
    """Jaccard similarity between two space-separated fingerprints."""
    set1 = set(fp1.split())
    set2 = set(fp2.split())
    if not set1 or not set2:
        return 0.0
    return len(set1 & set2) / len(set1 | set2)


# ── Learned Memory ────────────────────────────────────────────────────────────

class LearnedMemory:
    """Stores successful (and failed) patterns across sessions for future reference.

    Persists to ~/.mcp/learned/patterns.json and ~/.mcp/learned/heuristics.json
    """

    PATTERNS_FILE = "patterns.json"
    HEURISTICS_FILE = "heuristics.json"

    def __init__(self, storage_path: Optional[str] = None):
        self.storage_path = Path(storage_path or os.path.expanduser("~/.mcp/learned"))
        self.patterns_file = self.storage_path / self.PATTERNS_FILE
        self.heuristics_file = self.storage_path / self.HEURISTICS_FILE
        try:
            self.storage_path.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            raise RuntimeError(f"Failed to create learned memory directory {self.storage_path}: {e}") from e
        self._lock = threading.Lock()

    # ── patterns ─────────────────────────────────────────────────────────────

    # ── private I/O (no locks — only for use within a locked context) ────────────

    def _load_patterns_unsafe(self) -> List[Dict[str, Any]]:
        """Load patterns WITHOUT acquiring the lock. Caller must hold self._lock."""
        try:
            with open(self.patterns_file) as f:
                return json.load(f)
        except FileNotFoundError:
            return []
        except json.JSONDecodeError as e:
            _log.error("corrupt_patterns_file", path=str(self.patterns_file), error=str(e))
            return []

    def _load_heuristics_unsafe(self) -> List[Dict[str, Any]]:
        """Load heuristics WITHOUT acquiring the lock. Caller must hold self._lock."""
        try:
            with open(self.heuristics_file) as f:
                return json.load(f)
        except FileNotFoundError:
            return []
        except json.JSONDecodeError as e:
            _log.error("corrupt_heuristics_file", path=str(self.heuristics_file), error=str(e))
            return []

    # ── public I/O (thread-safe reads) ──────────────────────────────────────────

    def _load_patterns(self) -> List[Dict[str, Any]]:
        """Thread-safe patterns read."""
        with self._lock:
            return self._load_patterns_unsafe()

    def _load_heuristics(self) -> List[Dict[str, Any]]:
        """Thread-safe heuristics read."""
        with self._lock:
            return self._load_heuristics_unsafe()

    def _save_patterns_unsafe(self, patterns: List[Dict[str, Any]]) -> None:
        """Save patterns WITHOUT acquiring the lock. Caller must hold self._lock."""
        with open(self.patterns_file, "w") as f:
            json.dump(patterns, f, indent=2)

    def _save_heuristics_unsafe(self, heuristics: List[Dict[str, Any]]) -> None:
        """Save heuristics WITHOUT acquiring the lock. Caller must hold self._lock."""
        with open(self.heuristics_file, "w") as f:
            json.dump(heuristics, f, indent=2)

    def _save_patterns(self, patterns: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Thread-safe patterns save (acquires lock for the write)."""
        try:
            with self._lock:
                self._save_patterns_unsafe(patterns)
            return {"success": True, "path": str(self.patterns_file)}
        except (OSError, TypeError) as e:
            return {"success": False, "error": str(e)}

    def _save_heuristics(self, heuristics: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Thread-safe heuristics save."""
        try:
            with self._lock:
                self._save_heuristics_unsafe(heuristics)
            return {"success": True, "path": str(self.heuristics_file)}
        except (OSError, TypeError) as e:
            return {"success": False, "error": str(e)}

    # ── public API ─────────────────────────────────────────────────────────────

    def record_outcome(
        self,
        task: str,
        complexity: str,
        solution: str,
        outcome: str,
        rating: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Record a session outcome for future reference."""
        entry = {
            "task_fingerprint": _fingerprint_task(task),
            "task_sample": task[:200],
            "complexity": complexity,
            "outcome": outcome,
            "rating": rating,
            "timestamp": time.time(),
        }
        # Atomic read-modify-write: hold lock for the entire cycle
        with self._lock:
            patterns = self._load_patterns_unsafe()
            patterns.append(entry)
            patterns = patterns[-500:]
            self._save_patterns_unsafe(patterns)
        return {"success": True, "path": str(self.patterns_file)}

    def get_relevant_patterns(self, task: str, max_results: int = 5) -> List[Dict[str, Any]]:
        """Find past session patterns similar to the given task."""
        task_fp = _fingerprint_task(task)
        patterns = self._load_patterns()  # thread-safe read
        scored = []
        for p in patterns:
            score = _jaccard(task_fp, p.get("task_fingerprint", ""))
            if score > 0:
                scored.append((score, p))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [p for _, p in scored[:max_results]]

    # ── heuristics ────────────────────────────────────────────────────────────

    def add_heuristic(self, heuristic: str, context: str = "") -> Dict[str, Any]:
        """Store an extracted heuristic."""
        entry = {"heuristic": heuristic, "context": context, "timestamp": time.time()}
        with self._lock:
            heuristics = self._load_heuristics_unsafe()
            heuristics.append(entry)
            self._save_heuristics_unsafe(heuristics)
        return {"success": True, "path": str(self.heuristics_file)}

    def get_heuristics(self) -> List[str]:
        """Return all stored heuristics as plain strings."""
        return [h["heuristic"] for h in self._load_heuristics()]


# ── Session Index ─────────────────────────────────────────────────────────────

class SessionIndex:
    """Indexes session results by task fingerprint for similarity search.

    Persists to ~/.mcp/learned/session_index.json
    """

    def __init__(self, storage_path: Optional[str] = None):
        self.storage_path = Path(storage_path or os.path.expanduser("~/.mcp/learned"))
        self.index_file = self.storage_path / "session_index.json"
        try:
            self.storage_path.mkdir(parents=True, exist_ok=True)
        except OSError:
            pass
        self._lock = threading.Lock()

    def add(self, session_id: str, task: str, complexity: str, outcome: Optional[str] = None) -> None:
        """Index a session by its task fingerprint."""
        fingerprint = _fingerprint_task(task)
        # Atomic read-modify-write
        with self._lock:
            index = self._load_unsafe()
            index[session_id] = {
                "fingerprint": fingerprint,
                "task_sample": task[:200],
                "complexity": complexity,
                "outcome": outcome,
                "timestamp": time.time(),
            }
            self._save_unsafe(index)

    def find_similar(self, task: str, max_results: int = 3) -> List[Dict[str, Any]]:
        """Find indexed sessions with similar task fingerprints (Jaccard >= 0.2)."""
        task_fp = _fingerprint_task(task)
        with self._lock:
            index = self._load_unsafe()
        scored = []
        for sid, entry in index.items():
            score = _jaccard(task_fp, entry.get("fingerprint", ""))
            if score >= 0.2:
                scored.append((score, entry, sid))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [
            {"session_id": sid, **entry, "similarity": round(score, 3)}
            for score, entry, sid in scored[:max_results]
        ]

    def _load_unsafe(self) -> Dict[str, Dict[str, Any]]:
        """Load WITHOUT acquiring the lock. Caller must hold self._lock."""
        try:
            with open(self.index_file) as f:
                return json.load(f)
        except FileNotFoundError:
            return {}
        except json.JSONDecodeError as e:
            _log.error("corrupt_session_index", path=str(self.index_file), error=str(e))
            return {}

    def _load(self) -> Dict[str, Dict[str, Any]]:
        """Thread-safe read."""
        with self._lock:
            return self._load_unsafe()

    def _save_unsafe(self, index: Dict[str, Dict[str, Any]]) -> None:
        """Save WITHOUT acquiring the lock. Caller must hold self._lock."""
        with open(self.index_file, "w") as f:
            json.dump(index, f, indent=2)

    def _save(self, index: Dict[str, Dict[str, Any]]) -> None:
        with self._lock:
            self._save_unsafe(index)


# ── Working Memory ────────────────────────────────────────────────────────────

class WorkingMemory:
    """Manages short-term context across agent turns within a single session."""

    def __init__(self, capacity: int = 20, storage_path: Optional[str] = None):
        self.items: List[Dict[str, Any]] = []
        self.capacity = capacity
        self._lock = threading.Lock()
        self.storage_path = Path(storage_path or os.path.expanduser("~/.mcp/memory"))
        try:
            self.storage_path.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            raise RuntimeError(f"Failed to create memory storage directory {self.storage_path}: {e}") from e

    def add(self, item: Dict[str, Any]) -> None:
        """Add an item to working memory, evicting oldest if at capacity."""
        with self._lock:
            if len(self.items) >= self.capacity:
                self.items.pop(0)
            self.items.append(item)

    def get_context(self) -> str:
        """Render current memory as a string for LLM context."""
        if not self.items:
            return "(no prior context)"
        lines = []
        for item in self.items:
            role = item.get("role", item.get("agent_id", "Agent"))
            resp = item.get("response", item.get("content", ""))
            lines.append(f"[{role}]: {resp}")
        return "\n\n".join(lines)

    def save(self, session_id: Optional[str] = None) -> Dict[str, Any]:
        """Persist current memory to disk. Returns dict with 'path' or 'error'."""
        ts = time.strftime("%Y%m%d_%H%M%S")
        unique = f"{time.time_ns() % 1_000_000_000:09d}_{uuid.uuid4().hex[:6]}"
        suffix = f"_{session_id}" if session_id else ""
        filename = f"memory{suffix}_{ts}_{unique}.json"
        path = self.storage_path / filename
        try:
            with open(path, "w") as f:
                json.dump({"items": self.items, "saved_at": ts}, f, indent=2)
            return {"success": True, "path": str(path)}
        except (OSError, TypeError) as e:
            return {"success": False, "error": f"Failed to write {path}: {e}"}

    def load(self, session_id: Optional[str] = None) -> bool:
        """Load most recent memory (or session-specific). Returns True if loaded."""
        files = sorted(self.storage_path.glob("memory*.json"), reverse=True)
        if not files:
            return False
        if session_id:
            matches = [f for f in files if session_id in f.name]
            if not matches:
                return False
            file_path = matches[0]
        else:
            file_path = files[0]
        try:
            with open(file_path) as f:
                data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError, PermissionError, OSError):
            return False
        if not isinstance(data.get("items"), list):
            return False
        self.items = data.get("items", [])
        return True

    def clear(self) -> None:
        """Clear in-memory items (does not delete saved files)."""
        self.items.clear()
