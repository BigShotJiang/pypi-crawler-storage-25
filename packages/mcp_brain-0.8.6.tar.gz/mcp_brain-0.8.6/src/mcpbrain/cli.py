"""MCP CLI — command-line interface for the cognitive processing framework."""

import os
import sys
import json
import time
import click
from pathlib import Path
from typing import Optional

# Add src to path for direct execution
sys.path.insert(0, str(Path(__file__).parent.parent))

from mcpbrain.mcp_core import MCP
from mcpbrain.minimax_client import MiniMaxClient


DEFAULT_CONFIG = Path("~/.mcp/config.json").expanduser()


# ── Helpers ────────────────────────────────────────────────────────────────────

def get_mcp() -> MCP:
    """Get or create MCP instance, exits with clear message if not set up."""
    try:
        mcp = MCP()
    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        click.echo("Run 'mcp setup' first.", err=True)
        sys.exit(1)
    if not mcp.is_setup():
        click.echo("Error: MCP not configured.", err=True)
        click.echo("Run 'mcp setup' first.", err=True)
        sys.exit(1)
    return mcp


def render_result(result: dict):
    """Pretty-print a processing result."""
    click.echo("\n" + "=" * 60)
    click.echo(f"SOLUTION  (session={result['session_id']}, {result['duration_seconds']}s)")
    click.echo("=" * 60)
    click.echo(result["solution"])

    click.echo("\n" + "-" * 60)
    click.echo("EVALUATION")
    click.echo("-" * 60)
    click.echo(result.get("evaluation", "(no evaluation)"))

    click.echo("\n" + "-" * 60)
    click.echo("ANALYSIS")
    click.echo("-" * 60)
    click.echo(result.get("analysis", "(no analysis)"))


# ── Commands ─────────────────────────────────────────────────────────────────

@click.group()
@click.version_option(version="0.8.6")
def cli():
    """Multi-agent Cognitive Processing Framework.

    Uses specialized Creator, Critic, and Analyst agents to solve
    complex problems through structured cognitive collaboration.
    """
    pass


@cli.command()
def setup():
    """Interactively set up your MiniMax API key."""
    config_path = Path("~/.mcp/config.json").expanduser()
    config_path.parent.mkdir(parents=True, exist_ok=True)

    click.echo("MCP Setup\n")

    api_key = os.environ.get("MINIMAX_API_KEY", "")
    prompted_key = click.prompt(
        "MiniMax API Key",
        default=api_key,
        hide_input=True,
        show_default=bool(api_key),
    ).strip()

    if not prompted_key:
        click.echo("No API key provided. Setup cancelled.", err=True)
        sys.exit(1)

    # Fetch available models using the provided key
    click.echo("Fetching available models...")
    try:
        client = MiniMaxClient(prompted_key)
        models = client.list_models()
    except Exception as e:
        click.echo(f"Warning: Could not fetch models ({e})", err=True)
        models = []

    if models:
        click.echo("\nAvailable models:")
        # Show all model IDs — don't filter, some valid models have no "chat"/"text" in name
        all_ids = [m["id"] for m in models]
        for mid in sorted(all_ids)[:20]:
            click.echo(f"  - {mid}")
        if len(all_ids) > 20:
            click.echo(f"  ... and {len(all_ids) - 20} more")

        click.echo("")
        default_model = models[0]["id"] if models else "MiniMax-M2.7"
    else:
        default_model = "MiniMax-M2.7"

    model = click.prompt(
        "Model",
        default=default_model,
        show_default=True,
    ).strip()

    mcp = MCP(skip_api_key_check=True)
    mcp.setup(api_key=prompted_key, model=model)

    click.echo(f"\n✓ Config saved to {config_path}")
    click.echo("✓ MCP is ready. Run 'mcp process \"your task\"' to get started.")


@cli.command()
@click.argument("task", nargs=-1, type=click.UNPROCESSED, required=True)
@click.option("--quiet", "-q", is_flag=True, help="Suppress verbose output")
@click.option("--file", "-f", "files", multiple=True, help="Additional files to include in context (forces tool-use)")
def process(task: tuple, quiet: bool, files: tuple):
    """Process a task through the cognitive pipeline."""
    task_str = " ".join(task)
    if not task_str.strip():
        click.echo("Error: empty task", err=True)
        sys.exit(1)

    # Build file context if --file specified
    extra_context = ""
    if files:
        for fp in files:
            try:
                with open(fp) as fh:
                    content = fh.read()
                extra_context += f"\n\n[File: {fp}]\n{content}"
            except Exception as e:
                click.echo(f"Warning: could not read {fp}: {e}", err=True)

    mcp = get_mcp()

    try:
        result = mcp.process_task(task_str, verbose=not quiet, extra_context=extra_context)
        if not quiet:
            render_result(result)
        else:
            click.echo(result["solution"])
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command(name="sessions")
@click.option("--limit", "-n", default=10, help="Number of sessions to show")
def list_sessions(limit: int):
    """List recent session logs."""
    log_dir = Path("~/.mcp/logs").expanduser()
    if not log_dir.exists():
        click.echo("No sessions found.")
        return

    files = sorted(log_dir.glob("session_*.json"), reverse=True)[:limit]
    if not files:
        click.echo("No sessions found.")
        return

    click.echo(f"{'Session ID':<12} {'Timestamp':<20} {'Task':<50}")
    click.echo("-" * 84)
    for f in files:
        try:
            with open(f) as fh:
                data = json.load(fh)
            sid = data.get("session_id", "-")
            ts = data.get("timestamp", "-")
            task = data.get("task", "-")[:47]
            click.echo(f"{sid:<12} {ts:<20} {task:<50}")
        except Exception:
            pass


@cli.command()
@click.argument("session_id")
def session(session_id: str):
    """Show full details of a past session."""
    log_dir = Path("~/.mcp/logs").expanduser()
    matches = list(log_dir.glob(f"session_*_{session_id}.json"))
    if not matches:
        click.echo(f"Session '{session_id}' not found.", err=True)
        sys.exit(1)

    with open(matches[0]) as f:
        data = json.load(f)

    result = data.get("result", {})
    click.echo(f"\nTask: {data.get('task')}")
    click.echo(f"Session: {data.get('session_id')}  Timestamp: {data.get('timestamp')}")
    render_result(result)


@cli.command()
@click.argument("session_id")
@click.argument("outcome", type=click.Choice(["success", "partial", "failed"]))
@click.argument("rating", type=int, required=False, default=None)
@click.option("--notes", "-n", default="", help="Optional notes about the outcome")
def feedback(session_id: str, outcome: str, rating: Optional[int], notes: str):
    """Record the outcome of a session (success | partial | failed).

    Call this after running a task to close the learning loop. The outcome
    is stored in ~/.mcp/learned/patterns.json and used to improve future sessions.
    """
    try:
        mcp = MCP()
    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        click.echo("Run 'mcp setup' first.", err=True)
        sys.exit(1)

    if rating is not None and (rating < 1 or rating > 5):
        click.echo("Rating must be between 1 and 5", err=True)
        sys.exit(1)

    result = mcp.report_outcome(session_id, outcome, rating=rating, notes=notes)
    if result.get("success"):
        click.echo(f"✓ Recorded: {session_id} -> {outcome}" + (f" (rating={rating})" if rating else ""))
    else:
        click.echo(f"✗ Failed: {result.get('error', 'unknown error')}", err=True)
        sys.exit(1)


@cli.command()
@click.option("--patterns", "-p", is_flag=True, help="Show learned patterns")
@click.option("--heuristics", "-H", is_flag=True, help="Show stored heuristics")
@click.option("--similar", "-s", "show_similar", is_flag=True, help="Show similar session lookup")
@click.option("--limit", "-n", default=10, help="Max results to show")
def learned(patterns: bool, heuristics: bool, show_similar: bool, limit: int):
    """Inspect learned patterns and heuristics.

    Shows what mcp-brain has learned from past session outcomes.
    Without flags, shows patterns.
    """
    import json
    try:
        mcp = MCP(skip_api_key_check=True)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    learned_dir = Path("~/.mcp/learned").expanduser()
    if not patterns and not heuristics and not show_similar:
        patterns = True

    if patterns:
        pf = learned_dir / "patterns.json"
        if pf.exists():
            with open(pf) as f:
                pats = json.load(f)
            click.echo(f"[{len(pats)} learned patterns — last {limit}]")
            click.echo("-" * 60)
            for p in pats[-limit:]:
                ts = time.strftime("%Y-%m-%d", time.localtime(p.get("timestamp", 0)))
                click.echo(f"  {ts}  {p.get('outcome', '?')}/rating={p.get('rating')}  {p.get('task_sample', '')[:55]}")
        else:
            click.echo("No patterns recorded yet. Run `mcp feedback` after tasks.")

    if heuristics:
        hf = learned_dir / "heuristics.json"
        if hf.exists():
            with open(hf) as f:
                hrs = json.load(f)
            click.echo(f"\n[{len(hrs)} heuristics]")
            click.echo("-" * 60)
            for h in hrs[-limit:]:
                click.echo(f"  - {h.get('heuristic', '')[:75]}")
        else:
            click.echo("\nNo heuristics recorded yet.")

    if show_similar:
        si_file = learned_dir / "session_index.json"
        if si_file.exists():
            with open(si_file) as f:
                idx = json.load(f)
            click.echo(f"\n[{len(idx)} indexed sessions]")
            click.echo("-" * 60)
            for sid, entry in sorted(idx.items(), key=lambda x: x[1].get("timestamp", 0), reverse=True)[:limit]:
                ts = time.strftime("%Y-%m-%d", time.localtime(entry.get("timestamp", 0)))
                click.echo(f"  {ts}  [{entry.get('complexity', '?')}]  {entry.get('task_sample', '')[:55]}  outcome={entry.get('outcome', '?')}")
        else:
            click.echo("\nNo sessions indexed yet.")


@cli.command()
def status():
    """Check MCP configuration status."""
    try:
        mcp = MCP()
    except Exception as e:
        click.echo(f"Config: not initialized — {e}")
        return

    cfg = mcp.config
    key_set = bool(cfg.get("api_key") or os.environ.get("MINIMAX_API_KEY"))
    click.echo(f"API key set:  {'✓' if key_set else '✗'}")
    click.echo(f"Model:        {cfg.get('model', 'unknown')}")
    click.echo(f"Config:       {mcp.config_path}")

    log_dir = Path("~/.mcp/logs").expanduser()
    n_sessions = len(list(log_dir.glob("session_*.json"))) if log_dir.exists() else 0
    click.echo(f"Sessions:     {n_sessions} on disk")


def main():
    cli()


if __name__ == "__main__":
    main()
