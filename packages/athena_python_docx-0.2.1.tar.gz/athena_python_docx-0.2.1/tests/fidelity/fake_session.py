"""Fake Superdoc session for local fidelity testing.

Records every op invocation and returns deterministic responses matching
the real Superdoc contract shapes. Use this to drive the full SDK surface
through complex python-docx scripts without spinning up a Daytona sandbox.
"""

from __future__ import annotations

import itertools
from typing import Any


class FakeSDKMethods:
    """Callable-proxy namespace that records every op."""

    def __init__(self, state: "FakeDocState") -> None:
        self._state: "FakeDocState" = state

    def __getattr__(self, name: str) -> "FakeNamespace":
        return FakeNamespace(self._state, [name])


class FakeNamespace:
    def __init__(self, state: "FakeDocState", path: list[str]) -> None:
        self._state: "FakeDocState" = state
        self._path: list[str] = path

    def __getattr__(self, name: str) -> "FakeNamespace":
        return FakeNamespace(self._state, [*self._path, name])

    async def __call__(self, params: dict | None = None) -> Any:
        # Snake-case the path: "format.paragraph.set_alignment" -> "format.paragraph.setAlignment"
        op_parts: list[str] = []
        for seg in self._path:
            if "_" in seg:
                head, *tail = seg.split("_")
                camel = head + "".join(p.capitalize() for p in tail)
                op_parts.append(camel)
            else:
                op_parts.append(seg)
        op_name: str = ".".join(op_parts)
        self._state.calls.append((op_name, params or {}))
        return self._state.respond(op_name, params or {})


class _Block:
    def __init__(self, node_id: str, node_type: str, text: str = "") -> None:
        self.node_id: str = node_id
        self.node_type: str = node_type
        self.text: str = text
        self.style_id: str | None = None
        self.alignment: str | None = None
        self.attrs: dict[str, Any] = {}
        self.inlines: list[dict] = [{"run": {"text": text}}] if text else []


class _Table:
    def __init__(self, node_id: str, rows: int, cols: int, style: str = "TableGrid") -> None:
        self.node_id: str = node_id
        self.rows: int = rows
        self.cols: int = cols
        self.style_id: str = style
        self.alignment: str | None = None
        self.direction: str | None = None
        self.auto_fit_mode: str = "fitContents"
        # Parent cell info (when nested). None when top-level.
        self.parent_cell: tuple[str, int, int] | None = None
        # Merge groups: each merged region is stored as a set of (r,c) tuples.
        self.merge_groups: list[set[tuple[int, int]]] = []
        # Each cell has one empty paragraph
        self.cells: list[list[_Block]] = []
        # Extra paragraphs added after the initial one, keyed by (r, c)
        self.cell_extra_paragraphs: dict[tuple[int, int], list[_Block]] = {}
        # Nested tables keyed by (r, c)
        self.cell_nested_tables: dict[tuple[int, int], list["_Table"]] = {}
        for r in range(rows):
            row: list[_Block] = []
            for c in range(cols):
                pid = f"tp_{node_id}_{r}_{c}"
                p = _Block(pid, "paragraph", "")
                row.append(p)
            self.cells.append(row)
        # Column/row sizing
        self.row_heights: list[tuple[float, str]] = [(0.0, "auto")] * rows
        self.col_widths: list[float] = [0.0] * cols
        self.cell_verticals: list[list[str]] = [["top"] * cols for _ in range(rows)]
        self.cell_widths: list[list[float]] = [[0.0] * cols for _ in range(rows)]


class _Section:
    def __init__(self, section_id: str) -> None:
        self.id: str = section_id
        self.break_type: str = "nextPage"
        self.page_setup: dict[str, Any] = {
            "width": 612.0,  # 8.5" in pt
            "height": 792.0,  # 11" in pt
            "orientation": "portrait",
        }
        self.margins: dict[str, Any] = {
            "top": 72.0,
            "right": 72.0,
            "bottom": 72.0,
            "left": 72.0,
            "gutter": 0.0,
        }
        self.header_footer_margins: dict[str, Any] = {"header": 36.0, "footer": 36.0}
        self.title_page: bool = False


class FakeDocState:
    """Holds a minimal in-memory model of the document for the fake session."""

    _ids = itertools.count(1)

    def __init__(self) -> None:
        self.blocks: list[_Block] = []
        self.tables: list[_Table] = []
        self.sections: list[_Section] = [_Section("sec_1")]
        self.images: list[dict] = []
        self.calls: list[tuple[str, dict]] = []

    def _new_id(self, prefix: str) -> str:
        return f"{prefix}_{next(self._ids)}"

    def _find_block(self, node_id: str) -> _Block | None:
        for b in self.blocks:
            if b.node_id == node_id:
                return b
        for t in self.tables:
            for r_idx, row in enumerate(t.cells):
                for c_idx, c in enumerate(row):
                    if c.node_id == node_id:
                        return c
                    for extra in t.cell_extra_paragraphs.get((r_idx, c_idx), []):
                        if extra.node_id == node_id:
                            return extra
        return None

    def _find_cell_owner(self, paragraph_node_id: str) -> tuple[_Table, int, int] | None:
        """Given a paragraph's nodeId, find the (table, row, col) it belongs to."""
        for t in self.tables:
            for r_idx, row in enumerate(t.cells):
                for c_idx, cell in enumerate(row):
                    if cell.node_id == paragraph_node_id:
                        return (t, r_idx, c_idx)
                    for extra in t.cell_extra_paragraphs.get((r_idx, c_idx), []):
                        if extra.node_id == paragraph_node_id:
                            return (t, r_idx, c_idx)
        return None

    def _find_table(self, node_id: str) -> _Table | None:
        for t in self.tables:
            if t.node_id == node_id:
                return t
        return None

    def respond(self, op: str, params: dict) -> Any:
        # ---- lifecycle ----
        if op in ("open", "close", "save", "getText", "info"):
            if op == "getText":
                return "\n".join(b.text for b in self.blocks)
            if op == "info":
                return {"styles": {"paragraphStyles": []}}
            return {"ok": True}

        # ---- create.* ----
        if op == "create.paragraph":
            nid = self._new_id("p")
            b = _Block(nid, "paragraph", params.get("text", ""))
            self._place_block(params.get("at"), b)
            return {"success": True, "paragraph": {"nodeId": nid}}
        if op == "create.heading":
            nid = self._new_id("h")
            level = params.get("level", 1)
            b = _Block(nid, "heading", params.get("text", ""))
            b.attrs["level"] = level
            self._place_block(params.get("at"), b)
            return {"success": True, "heading": {"nodeId": nid, "level": level}}
        if op == "create.table":
            rows = params.get("rows", 1)
            cols = params.get("columns") or params.get("cols") or 1
            tid = self._new_id("t")
            t = _Table(tid, rows, cols)
            # Check if the anchor points inside a cell — make this nested.
            at = params.get("at") or {}
            if at.get("kind") in ("before", "after"):
                tgt = at.get("target") or {}
                tgt_nid = tgt.get("nodeId")
                if tgt_nid:
                    owner = self._find_cell_owner(str(tgt_nid))
                    if owner is not None:
                        parent_t, r_idx, c_idx = owner
                        t.parent_cell = (parent_t.node_id, r_idx, c_idx)
                        parent_t.cell_nested_tables.setdefault(
                            (r_idx, c_idx), []
                        ).append(t)
                        self.tables.append(t)
                        return {"success": True, "table": {"nodeId": tid}}
            self.tables.append(t)
            return {"success": True, "table": {"nodeId": tid}}
        if op == "create.image":
            iid = self._new_id("img")
            info = {
                "nodeId": iid,
                "size": params.get("size", {"width": 576, "height": 432}),
                "src": params.get("src", ""),
            }
            self.images.append(info)
            return {"success": True, "image": {"nodeId": iid}}
        if op == "create.sectionBreak":
            sid = self._new_id("sec")
            s = _Section(sid)
            s.break_type = params.get("breakType", "nextPage")
            self.sections.append(s)
            return {"success": True}

        # ---- reading ----
        if op == "getNodeById":
            nid = params.get("id") or params.get("nodeId")
            # Paragraph / heading
            b = self._find_block(str(nid))
            if b is not None:
                block_data: dict = {
                    "inlines": list(b.inlines),
                    "alignment": b.alignment,
                    "attrs": b.attrs,
                    "styleId": b.style_id,
                }
                if b.alignment:
                    block_data["alignment"] = b.alignment
                node: dict = {
                    "nodeType": b.node_type,
                    "styleId": b.style_id,
                    b.node_type: block_data,
                }
                return {"node": node, "address": {"kind": "block", "nodeType": b.node_type, "nodeId": b.node_id}}
            # Table cell
            for t in self.tables:
                for r_idx, row in enumerate(t.cells):
                    for c_idx, cell in enumerate(row):
                        if cell.node_id == nid or (
                            params.get("nodeType") == "tableCell"
                            and nid == f"cell_{t.node_id}_{r_idx}_{c_idx}"
                        ):
                            # Return a tree containing the inner paragraph
                            inner = {
                                "type": "paragraph",
                                "attrs": {"nodeId": cell.node_id},
                                "content": [{"type": "text", "text": cell.text}] if cell.text else [],
                            }
                            return {
                                "node": {
                                    "nodeType": "tableCell",
                                    "tableCell": {"content": [inner]},
                                },
                                "address": {
                                    "kind": "block",
                                    "nodeType": "tableCell",
                                    "nodeId": cell.node_id,
                                },
                            }
            return {"node": {}, "address": {}}

        if op == "blocks.list":
            types = params.get("nodeTypes") or None
            out_blocks: list[dict] = []
            for b in self.blocks:
                if types and b.node_type not in types:
                    continue
                entry = {
                    "nodeId": b.node_id,
                    "nodeType": b.node_type,
                    "textPreview": b.text,
                    "styleId": b.style_id,
                    "alignment": b.alignment,
                }
                out_blocks.append(entry)
            return {"blocks": out_blocks, "total": len(out_blocks), "revision": "r0"}

        if op == "find":
            if params.get("type") == "table":
                # Only top-level (non-nested) tables match python-docx's
                # Document.tables semantics.
                return {
                    "items": [
                        {
                            "address": {
                                "kind": "block",
                                "nodeType": "table",
                                "nodeId": t.node_id,
                            },
                        }
                        for t in self.tables
                        if t.parent_cell is None
                    ],
                }
            return {"items": []}

        # ---- mutations ----
        if op == "replace":
            target = params.get("target") or {}
            text = params.get("text", "")
            def _apply_to_block(b: _Block, s: int, e: int, new: str) -> None:
                result = b.text[:s] + new + b.text[e:]
                b.text = result
                b.inlines = [{"run": {"text": result}}] if result else []
                # Propagate to merged siblings, if this block is a cell's
                # first paragraph in a merge group.
                for t in self.tables:
                    for r_idx, row in enumerate(t.cells):
                        for c_idx, cell in enumerate(row):
                            if cell is b:
                                # Find merge group containing (r_idx, c_idx)
                                for group in t.merge_groups:
                                    if (r_idx, c_idx) in group:
                                        for gr, gc in group:
                                            sib = t.cells[gr][gc]
                                            if sib is not b:
                                                sib.text = result
                                                sib.inlines = (
                                                    [{"run": {"text": result}}]
                                                    if result
                                                    else []
                                                )
                                        return
            if target.get("kind") == "selection":
                start = target.get("start", {})
                blk_id = start.get("blockId")
                b = self._find_block(str(blk_id)) if blk_id else None
                if b is not None:
                    s = int(start.get("offset", 0))
                    end_info = target.get("end", {}) or {}
                    e = int(end_info.get("offset", len(b.text)))
                    _apply_to_block(b, s, e, text)
                    return {"ok": True}
            if target.get("kind") == "text":
                blk_id = target.get("blockId")
                b = self._find_block(str(blk_id)) if blk_id else None
                if b is not None:
                    rng = target.get("range", {}) or {}
                    s = int(rng.get("start", 0))
                    e = int(rng.get("end", len(b.text)))
                    _apply_to_block(b, s, e, text)
            return {"ok": True}

        if op == "insert":
            target = params.get("target") or {}
            value = params.get("value", "")
            blk_id: str | None = None
            if target.get("kind") == "selection":
                start = target.get("start") or {}
                if start.get("kind") == "text":
                    blk_id = start.get("blockId")
            if blk_id:
                b = self._find_block(str(blk_id))
                if b is not None:
                    b.text = b.text + value
                    b.inlines = [{"run": {"text": b.text}}]
            return {"ok": True}

        if op == "insertLineBreak":
            blk_id = params.get("blockId")
            if blk_id:
                b = self._find_block(str(blk_id))
                if b is not None:
                    b.text = b.text + "\n"
                    b.inlines = [{"run": {"text": b.text}}]
            return {"ok": True}

        if op == "insertTab":
            blk_id = params.get("blockId")
            if blk_id:
                b = self._find_block(str(blk_id))
                if b is not None:
                    b.text = b.text + "\t"
                    b.inlines = [{"run": {"text": b.text}}]
            return {"ok": True}

        # ---- format.apply (inline) ----
        if op == "format.apply":
            target = params.get("target") or {}
            inline = params.get("inline") or {}
            blk_id = target.get("blockId")
            if blk_id:
                b = self._find_block(str(blk_id))
                if b is not None:
                    # Attach inline marks to the run(s)
                    rng = target.get("range", {})
                    start = rng.get("start", 0)
                    end = rng.get("end", 0)
                    # Single-run model in fake — just set attrs on the one run.
                    if b.inlines:
                        for kind, val in inline.items():
                            b.inlines[0].setdefault("run", {})[kind] = val
            return {"ok": True}

        # ---- paragraph format ----
        if op == "format.paragraph.setAlignment":
            t = params.get("target") or {}
            b = self._find_block(str(t.get("nodeId")))
            if b is not None:
                b.alignment = params.get("alignment")
                b.attrs["textAlign"] = params.get("alignment")
            return {"ok": True}
        if op == "format.paragraph.clearAlignment":
            t = params.get("target") or {}
            b = self._find_block(str(t.get("nodeId")))
            if b is not None:
                b.alignment = None
                b.attrs.pop("textAlign", None)
            return {"ok": True}
        if op == "format.paragraph.setIndentation":
            t = params.get("target") or {}
            b = self._find_block(str(t.get("nodeId")))
            if b is not None:
                indent = b.attrs.setdefault("indent", {})
                for k in ("left", "right", "firstLine", "hanging"):
                    if k in params:
                        indent[k] = params[k]
            return {"ok": True}
        if op == "format.paragraph.clearIndentation":
            t = params.get("target") or {}
            b = self._find_block(str(t.get("nodeId")))
            if b is not None:
                b.attrs.pop("indent", None)
            return {"ok": True}
        if op == "format.paragraph.setSpacing":
            t = params.get("target") or {}
            b = self._find_block(str(t.get("nodeId")))
            if b is not None:
                sp = b.attrs.setdefault("spacing", {})
                for k in ("before", "after", "line", "lineRule"):
                    if k in params:
                        sp[k] = params[k]
            return {"ok": True}
        if op == "format.paragraph.clearSpacing":
            t = params.get("target") or {}
            b = self._find_block(str(t.get("nodeId")))
            if b is not None:
                b.attrs.pop("spacing", None)
            return {"ok": True}
        if op == "format.paragraph.setKeepOptions":
            t = params.get("target") or {}
            b = self._find_block(str(t.get("nodeId")))
            if b is not None:
                for k in ("keepNext", "keepLines", "widowControl"):
                    if k in params:
                        b.attrs[k] = params[k]
            return {"ok": True}
        if op == "format.paragraph.setFlowOptions":
            t = params.get("target") or {}
            b = self._find_block(str(t.get("nodeId")))
            if b is not None:
                if "pageBreakBefore" in params:
                    b.attrs["pageBreakBefore"] = params["pageBreakBefore"]
            return {"ok": True}
        if op.startswith("format.paragraph."):
            return {"ok": True}

        # ---- styles ----
        if op == "styles.paragraph.setStyle":
            t = params.get("target") or {}
            b = self._find_block(str(t.get("nodeId")))
            if b is not None:
                b.style_id = params.get("styleId")
            return {"ok": True}
        if op.startswith("styles."):
            return {"ok": True}

        # ---- tables ----
        if op == "tables.get":
            tid = params.get("nodeId")
            t = self._find_table(str(tid))
            if t is not None:
                return {
                    "nodeId": t.node_id,
                    "rows": t.rows,
                    "columns": t.cols,
                    "styleId": t.style_id,
                    "columnInfo": [{"widthPt": w} for w in t.col_widths],
                    "rowInfo": [{"heightPt": h, "rule": rule} for h, rule in t.row_heights],
                }
            return {"rows": 0, "columns": 0}
        if op == "tables.getProperties":
            tid = params.get("nodeId")
            t = self._find_table(str(tid))
            if t is not None:
                return {
                    "nodeId": t.node_id,
                    "styleId": t.style_id,
                    "alignment": t.alignment,
                    "direction": t.direction,
                    "autoFitMode": t.auto_fit_mode,
                }
            return {}
        if op == "tables.getCells":
            tid = params.get("nodeId")
            t = self._find_table(str(tid))
            if t is None:
                return {"cells": []}
            r = params.get("rowIndex")
            c = params.get("columnIndex")
            cells: list[dict] = []
            for r_idx, row in enumerate(t.cells):
                for c_idx, cell in enumerate(row):
                    if r is not None and r_idx != r:
                        continue
                    if c is not None and c_idx != c:
                        continue
                    cells.append(
                        {
                            "nodeId": f"cell_{t.node_id}_{r_idx}_{c_idx}",
                            "address": {
                                "kind": "block",
                                "nodeType": "tableCell",
                                "nodeId": f"cell_{t.node_id}_{r_idx}_{c_idx}",
                            },
                            "rowIndex": r_idx,
                            "columnIndex": c_idx,
                            "colspan": 1,
                            "rowspan": 1,
                            "text": cell.text,
                            "preferredWidthPt": t.cell_widths[r_idx][c_idx] or None,
                            "verticalAlign": t.cell_verticals[r_idx][c_idx],
                        },
                    )
            return {"nodeId": t.node_id, "address": {"kind": "block", "nodeType": "table", "nodeId": t.node_id}, "cells": cells}
        if op == "tables.insertRow":
            tid = params.get("nodeId")
            t = self._find_table(str(tid))
            if t is not None:
                t.rows += 1
                new_row = []
                for c in range(t.cols):
                    nid = f"tp_{t.node_id}_{t.rows - 1}_{c}"
                    new_row.append(_Block(nid, "paragraph", ""))
                t.cells.append(new_row)
                t.row_heights.append((0.0, "auto"))
                t.cell_verticals.append(["top"] * t.cols)
                t.cell_widths.append([0.0] * t.cols)
            return {"ok": True}
        if op == "tables.insertColumn":
            tid = params.get("nodeId")
            t = self._find_table(str(tid))
            if t is not None:
                t.cols += 1
                for r_idx, row in enumerate(t.cells):
                    nid = f"tp_{t.node_id}_{r_idx}_{t.cols - 1}"
                    row.append(_Block(nid, "paragraph", ""))
                    t.cell_verticals[r_idx].append("top")
                    t.cell_widths[r_idx].append(0.0)
                t.col_widths.append(0.0)
            return {"ok": True}
        if op == "tables.setStyle":
            tid = params.get("nodeId")
            t = self._find_table(str(tid))
            if t is not None:
                t.style_id = params.get("styleId") or t.style_id
            return {"ok": True}
        if op == "tables.setRowHeight":
            tid = params.get("nodeId") or (params.get("target", {}) or {}).get("nodeId")
            t = self._find_table(str(tid))
            if t is not None:
                r = params.get("rowIndex", 0)
                if 0 <= r < t.rows:
                    t.row_heights[r] = (params.get("heightPt", 0.0), params.get("rule", "auto"))
            return {"ok": True}
        if op == "tables.setColumnWidth":
            tid = params.get("nodeId") or (params.get("target", {}) or {}).get("nodeId")
            t = self._find_table(str(tid))
            if t is not None:
                c = params.get("columnIndex", 0)
                if 0 <= c < t.cols:
                    t.col_widths[c] = params.get("widthPt", 0.0)
            return {"ok": True}
        if op == "tables.setCellProperties":
            target = params.get("target") or {}
            nid = target.get("nodeId") or params.get("nodeId")
            # Find the cell
            for t in self.tables:
                for r_idx, row in enumerate(t.cells):
                    for c_idx, _cell in enumerate(row):
                        if nid == f"cell_{t.node_id}_{r_idx}_{c_idx}":
                            if "verticalAlign" in params:
                                t.cell_verticals[r_idx][c_idx] = params["verticalAlign"]
                            if "preferredWidthPt" in params:
                                t.cell_widths[r_idx][c_idx] = params["preferredWidthPt"]
            return {"ok": True}
        if op == "tables.setTableOptions":
            tid = params.get("nodeId")
            t = self._find_table(str(tid))
            if t is not None:
                if "alignment" in params:
                    t.alignment = params["alignment"]
                if "direction" in params:
                    t.direction = params["direction"]
            return {"ok": True}
        if op == "tables.setLayout":
            tid = params.get("nodeId")
            t = self._find_table(str(tid))
            if t is not None:
                t.auto_fit_mode = params.get("autoFit", t.auto_fit_mode)
            return {"ok": True}
        if op == "tables.mergeCells":
            tid = params.get("nodeId")
            t = self._find_table(str(tid))
            if t is not None:
                start = params.get("start") or {}
                end = params.get("end") or {}
                r0 = start.get("rowIndex", 0)
                c0 = start.get("columnIndex", 0)
                r1 = end.get("rowIndex", r0)
                c1 = end.get("columnIndex", c0)
                group: set[tuple[int, int]] = set()
                for r_i in range(min(r0, r1), max(r0, r1) + 1):
                    for c_i in range(min(c0, c1), max(c0, c1) + 1):
                        if 0 <= r_i < t.rows and 0 <= c_i < t.cols:
                            group.add((r_i, c_i))
                if group:
                    t.merge_groups.append(group)
            return {"ok": True}
        if op.startswith("tables."):
            return {"ok": True}

        # ---- sections ----
        if op == "sections.list":
            return {
                "total": len(self.sections),
                "items": [
                    {
                        "id": s.id,
                        "address": {"kind": "section", "sectionId": s.id},
                        "index": i,
                        "range": {"startParagraphIndex": 0, "endParagraphIndex": 0},
                        "breakType": s.break_type,
                        "pageSetup": s.page_setup,
                    }
                    for i, s in enumerate(self.sections)
                ],
            }
        if op == "sections.get":
            target = params.get("target") or {}
            sec_id = target.get("sectionId")
            s = next((x for x in self.sections if x.id == sec_id), self.sections[0] if self.sections else None)
            if s is None:
                return {}
            return {
                "address": target,
                "index": 0,
                "range": {"startParagraphIndex": 0, "endParagraphIndex": 0},
                "breakType": s.break_type,
                "pageSetup": s.page_setup,
                "margins": s.margins,
                "headerFooterMargins": s.header_footer_margins,
                "titlePage": s.title_page,
            }
        if op == "sections.setPageMargins":
            target = params.get("target") or {}
            sec_id = target.get("sectionId")
            s = next((x for x in self.sections if x.id == sec_id), None)
            if s is not None:
                for k in ("top", "right", "bottom", "left", "gutter"):
                    if k in params:
                        s.margins[k] = params[k]
            return {"ok": True}
        if op == "sections.setPageSetup":
            target = params.get("target") or {}
            sec_id = target.get("sectionId")
            s = next((x for x in self.sections if x.id == sec_id), None)
            if s is not None:
                for k in ("width", "height", "orientation", "paperSize"):
                    if k in params:
                        s.page_setup[k] = params[k]
            return {"ok": True}
        if op == "sections.setHeaderFooterMargins":
            target = params.get("target") or {}
            sec_id = target.get("sectionId")
            s = next((x for x in self.sections if x.id == sec_id), None)
            if s is not None:
                for k in ("header", "footer"):
                    if k in params:
                        s.header_footer_margins[k] = params[k]
            return {"ok": True}
        if op == "sections.setBreakType":
            target = params.get("target") or {}
            sec_id = target.get("sectionId")
            s = next((x for x in self.sections if x.id == sec_id), None)
            if s is not None:
                s.break_type = params.get("breakType", s.break_type)
            return {"ok": True}
        if op == "sections.setTitlePage":
            target = params.get("target") or {}
            sec_id = target.get("sectionId")
            s = next((x for x in self.sections if x.id == sec_id), None)
            if s is not None:
                s.title_page = bool(params.get("titlePage", False))
            return {"ok": True}
        if op.startswith("sections."):
            return {"ok": True}

        # ---- images ----
        if op == "images.list":
            return {"items": list(self.images)}
        if op == "images.setSize":
            for im in self.images:
                if im.get("nodeId") == params.get("nodeId"):
                    im["size"] = {
                        "width": params.get("widthPt", im["size"].get("width")),
                        "height": params.get("heightPt", im["size"].get("height")),
                    }
            return {"ok": True}
        if op.startswith("images."):
            return {"ok": True}

        # ---- fallthrough ----
        return {"ok": True}

    def _place_block(self, at: dict | None, block: _Block) -> None:
        if not at or at.get("kind") == "documentEnd":
            self.blocks.append(block)
            return
        if at.get("kind") == "documentStart":
            self.blocks.insert(0, block)
            return
        target = at.get("target") or {}
        target_id = target.get("nodeId")
        # Target at top level?
        for i, b in enumerate(self.blocks):
            if b.node_id == target_id:
                if at.get("kind") == "before":
                    self.blocks.insert(i, block)
                else:
                    self.blocks.insert(i + 1, block)
                return
        # Target inside a cell?
        if target_id:
            owner = self._find_cell_owner(str(target_id))
            if owner is not None:
                t, r_idx, c_idx = owner
                # Append to the cell's extra-paragraph list.
                extras = t.cell_extra_paragraphs.setdefault((r_idx, c_idx), [])
                extras.append(block)
                return
        self.blocks.append(block)


class FakeSession:
    """Drop-in replacement for docx.client.Session used in fidelity tests."""

    def __init__(self, *, asset_id: str, user_info: dict | None = None) -> None:  # noqa: ARG002
        self._asset_id: str = asset_id
        self._state: FakeDocState = FakeDocState()
        self._opened: bool = True
        self._closed: bool = False
        self._methods: FakeSDKMethods = FakeSDKMethods(self._state)

    @property
    def asset_id(self) -> str:
        return self._asset_id

    @property
    def is_open(self) -> bool:
        return self._opened and not self._closed

    @property
    def doc(self) -> FakeSDKMethods:
        return self._methods

    async def open(self) -> None:
        self._opened = True

    async def save(self, *, in_place: bool = True) -> None:  # noqa: ARG002
        return None

    async def close(self) -> None:
        self._closed = True

    def calls(self) -> list[tuple[str, dict]]:
        return self._state.calls

    def state(self) -> FakeDocState:
        return self._state


def install_fake_session() -> None:
    """Monkey-patch docx.client.Session globally so Document() uses the fake."""
    import docx.client
    import docx.document

    docx.client.Session = FakeSession  # type: ignore[misc]
    docx.document.Session = FakeSession  # type: ignore[misc]
