"""Real-world python-docx cases copy-pasted from widely-used scripts.

These are the kinds of scripts you'd find in tutorials and actual
python-docx usage in the wild. Each is an idiomatic pattern; we run the
same snippet through our SDK to catch gaps that only show up with the
actual patterns users write.
"""

from __future__ import annotations

from tests.fidelity.complex_cases import ComplexCase  # noqa


REAL_WORLD_CASES: list[ComplexCase] = [
    # https://python-docx.readthedocs.io/en/latest/user/quickstart.html  (quickstart)
    ComplexCase(
        name="rw01_official_quickstart",
        description="python-docx official quickstart example",
        script=(
            "from docx.shared import Inches\n"
            "document = doc\n"
            "document.add_heading('Document Title', 0)\n"
            "p = document.add_paragraph('A plain paragraph having some ')\n"
            "p.add_run('bold').bold = True\n"
            "p.add_run(' and some ')\n"
            "p.add_run('italic.').italic = True\n"
            "document.add_heading('Heading, level 1', level=1)\n"
            "document.add_paragraph('Intense quote', style='Intense Quote')\n"
            "document.add_paragraph(\n"
            "    'first item in unordered list', style='List Bullet'\n"
            ")\n"
            "document.add_paragraph(\n"
            "    'first item in ordered list', style='List Number'\n"
            ")\n"
            "table = document.add_table(rows=1, cols=3)\n"
            "hdr_cells = table.rows[0].cells\n"
            "hdr_cells[0].text = 'Qty'\n"
            "hdr_cells[1].text = 'Id'\n"
            "hdr_cells[2].text = 'Desc'\n"
            "for i in range(3):\n"
            "    row_cells = table.add_row().cells\n"
            "    row_cells[0].text = str(i)\n"
            "    row_cells[1].text = f'id-{i}'\n"
            "    row_cells[2].text = f'description {i}'\n"
            "document.add_page_break()"
        ),
        tags=("real_world", "quickstart"),
    ),

    # https://python-docx.readthedocs.io/en/latest/user/text.html#applying-paragraph-style
    ComplexCase(
        name="rw02_paragraph_style_list",
        description="Paragraph styles applied to a bulleted list",
        script=(
            "document = doc\n"
            "for i in range(5):\n"
            "    document.add_paragraph(f'List item {i+1}', style='List Bullet')"
        ),
        tags=("real_world", "lists"),
    ),

    # https://python-docx.readthedocs.io/en/latest/user/text.html#applying-character-formatting
    ComplexCase(
        name="rw03_character_formatting",
        description="Run-level character formatting",
        script=(
            "from docx.shared import RGBColor, Pt\n"
            "document = doc\n"
            "paragraph = document.add_paragraph('The quick brown fox ')\n"
            "run = paragraph.add_run('jumps')\n"
            "run.bold = True\n"
            "run.italic = True\n"
            "run.font.color.rgb = RGBColor(0xFF, 0x00, 0x00)\n"
            "paragraph.add_run(' over the lazy dog.')"
        ),
        tags=("real_world", "formatting"),
    ),

    # https://python-docx.readthedocs.io/en/latest/user/sections.html
    ComplexCase(
        name="rw04_section_page_setup",
        description="Portrait/landscape switch across sections",
        script=(
            "from docx.enum.section import WD_ORIENT, WD_SECTION_START\n"
            "from docx.shared import Inches\n"
            "document = doc\n"
            "section = document.sections[0]\n"
            "section.page_width = Inches(8.5)\n"
            "section.page_height = Inches(11)\n"
            "# landscape section\n"
            "new_section = document.add_section(WD_SECTION_START.NEW_PAGE)\n"
            "new_section.orientation = WD_ORIENT.LANDSCAPE\n"
            "new_section.page_width = Inches(11)\n"
            "new_section.page_height = Inches(8.5)\n"
        ),
        tags=("real_world", "sections"),
    ),

    # Common table-of-contents pattern
    ComplexCase(
        name="rw05_toc_pattern",
        description="Table-of-contents-style doc",
        script=(
            "document = doc\n"
            "document.add_heading('Table of Contents', level=1)\n"
            "for i, title in enumerate(['Introduction', 'Methodology', 'Results', 'Conclusion']):\n"
            "    document.add_paragraph(f'{i+1}. {title}', style='Normal')\n"
            "document.add_page_break()\n"
            "for title in ['Introduction', 'Methodology', 'Results', 'Conclusion']:\n"
            "    document.add_heading(title, level=1)\n"
            "    for _ in range(3):\n"
            "        document.add_paragraph('Body text ' * 5)"
        ),
        tags=("real_world", "toc"),
    ),

    # Stock template for a meeting minutes doc
    ComplexCase(
        name="rw06_meeting_minutes",
        description="Meeting minutes template",
        script=(
            "from docx.shared import Pt, Inches\n"
            "from docx.enum.text import WD_ALIGN_PARAGRAPH\n"
            "document = doc\n"
            "# Header\n"
            "title = document.add_heading('Meeting Minutes', level=0)\n"
            "title.alignment = WD_ALIGN_PARAGRAPH.CENTER\n"
            "# Info\n"
            "info = document.add_paragraph()\n"
            "info.add_run('Date: ').bold = True\n"
            "info.add_run('April 21, 2026')\n"
            "info2 = document.add_paragraph()\n"
            "info2.add_run('Attendees: ').bold = True\n"
            "info2.add_run('Alice, Bob, Carol, Dave')\n"
            "# Agenda\n"
            "document.add_heading('Agenda', level=1)\n"
            "for item in ['Project status', 'Budget review', 'Q&A']:\n"
            "    document.add_paragraph(f'• {item}')\n"
            "# Notes\n"
            "document.add_heading('Notes', level=1)\n"
            "document.add_paragraph('Alice provided an update on project status.')\n"
            "document.add_paragraph('Bob reviewed the budget.')\n"
            "# Action items as a table\n"
            "document.add_heading('Action Items', level=1)\n"
            "t = document.add_table(rows=1, cols=3, style='TableGrid')\n"
            "hdr = t.rows[0].cells\n"
            "hdr[0].text = 'Owner'\n"
            "hdr[1].text = 'Task'\n"
            "hdr[2].text = 'Due'\n"
            "for owner, task, due in [\n"
            "    ('Alice', 'Update project plan', '2026-05-01'),\n"
            "    ('Bob', 'Revise budget', '2026-05-03'),\n"
            "    ('Carol', 'Schedule follow-up', '2026-04-25'),\n"
            "]:\n"
            "    row = t.add_row().cells\n"
            "    row[0].text = owner\n"
            "    row[1].text = task\n"
            "    row[2].text = due"
        ),
        tags=("real_world", "combo"),
    ),

    # Dense formatting demo (like some tutorial scripts)
    ComplexCase(
        name="rw07_dense_formatting_demo",
        description="Dense formatting combinations used in tutorials",
        script=(
            "from docx.shared import Pt, RGBColor\n"
            "from docx.enum.text import WD_ALIGN_PARAGRAPH\n"
            "d = doc\n"
            "for alignment, name in [\n"
            "    (WD_ALIGN_PARAGRAPH.LEFT, 'Left'),\n"
            "    (WD_ALIGN_PARAGRAPH.CENTER, 'Center'),\n"
            "    (WD_ALIGN_PARAGRAPH.RIGHT, 'Right'),\n"
            "    (WD_ALIGN_PARAGRAPH.JUSTIFY, 'Justify'),\n"
            "]:\n"
            "    p = d.add_paragraph(f'{name}-aligned text ' * 5)\n"
            "    p.alignment = alignment\n"
            "# Mixed runs\n"
            "p = d.add_paragraph()\n"
            "for i, (text, cfg) in enumerate([\n"
            "    ('Bold ', {'bold': True}),\n"
            "    ('Italic ', {'italic': True}),\n"
            "    ('Underline ', {'underline': True}),\n"
            "    ('Big ', {'size': Pt(20)}),\n"
            "    ('Red ', {'color': RGBColor(0xFF, 0, 0)}),\n"
            "    ('Fancy', {'bold': True, 'italic': True, 'underline': True}),\n"
            "]):\n"
            "    r = p.add_run(text)\n"
            "    if cfg.get('bold'): r.bold = True\n"
            "    if cfg.get('italic'): r.italic = True\n"
            "    if cfg.get('underline'): r.underline = True\n"
            "    if cfg.get('size'): r.font.size = cfg['size']\n"
            "    if cfg.get('color'): r.font.color.rgb = cfg['color']"
        ),
        tags=("real_world", "formatting"),
    ),

    # Table with merged header cell — common
    ComplexCase(
        name="rw08_table_merged_header",
        description="Table with merged header row",
        script=(
            "document = doc\n"
            "t = document.add_table(rows=3, cols=3, style='TableGrid')\n"
            "# Merge the top row into one header cell\n"
            "a = t.cell(0, 0)\n"
            "b = t.cell(0, 2)\n"
            "a.merge(b)\n"
            "a.text = 'Header (merged)'\n"
            "# Fill body\n"
            "for r in range(1, 3):\n"
            "    for c in range(3):\n"
            "        t.cell(r, c).text = f'r{r}c{c}'"
        ),
        tags=("real_world", "table", "merge"),
    ),

    # Iterate every run in every paragraph — common pattern
    ComplexCase(
        name="rw09_bulk_run_iteration",
        description="Iterate every paragraph and every run in the doc",
        script=(
            "document = doc\n"
            "for i in range(10):\n"
            "    p = document.add_paragraph()\n"
            "    for j in range(3):\n"
            "        p.add_run(f'p{i}r{j} ')\n"
            "\n"
            "# Read-only walk\n"
            "total_runs = 0\n"
            "total_text_len = 0\n"
            "for p in document.paragraphs:\n"
            "    for r in p.runs:\n"
            "        total_runs += 1\n"
            "        total_text_len += len(r.text)\n"
            "assert total_runs >= 1, total_runs"
        ),
        tags=("real_world", "iteration"),
    ),

    # Large table with per-cell formatting
    ComplexCase(
        name="rw10_colored_grid_table",
        description="4x4 table with per-cell font color",
        script=(
            "from docx.shared import RGBColor\n"
            "document = doc\n"
            "t = document.add_table(rows=4, cols=4, style='TableGrid')\n"
            "colors = [\n"
            "    RGBColor(0xFF, 0, 0),\n"
            "    RGBColor(0, 0xFF, 0),\n"
            "    RGBColor(0, 0, 0xFF),\n"
            "    RGBColor(0x80, 0, 0x80),\n"
            "]\n"
            "for r in range(4):\n"
            "    for c in range(4):\n"
            "        cell = t.cell(r, c)\n"
            "        cell.text = f'{r},{c}'\n"
            "        p = cell.paragraphs[0]\n"
            "        if p.runs:\n"
            "            p.runs[0].font.color.rgb = colors[(r + c) % 4]"
        ),
        tags=("real_world", "table", "color"),
    ),
]
