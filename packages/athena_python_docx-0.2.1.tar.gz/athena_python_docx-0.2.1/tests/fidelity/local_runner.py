"""Local fidelity runner — no Daytona, no Keryx, fast iteration.

Uses the FakeSession to drive every case from ``complex_cases.CASES``
through our SDK. Reports each case as PASS / FAIL and on FAIL prints the
exception type and message.

Also, for every case, runs the same script against *stock* python-docx
(installed at .venv-pydocx in the repo) to confirm the snippet itself
is valid python-docx code. This catches typos in our cases that aren't
about our SDK gaps.

Usage:
    .venv/bin/python tests/fidelity/local_runner.py
    .venv/bin/python tests/fidelity/local_runner.py --verbose
    .venv/bin/python tests/fidelity/local_runner.py --filter level5
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
import traceback
from pathlib import Path

_SDK_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_SDK_ROOT))

from tests.fidelity.complex_cases import CASES, ComplexCase  # noqa: E402
from tests.fidelity.fake_session import install_fake_session  # noqa: E402
from tests.fidelity.real_world_cases import REAL_WORLD_CASES  # noqa: E402
from tests.fidelity.extreme_cases import EXTREME_CASES  # noqa: E402
from tests.fidelity.mega_cases import MEGA_CASES  # noqa: E402

ALL_CASES: list[ComplexCase] = CASES + REAL_WORLD_CASES + EXTREME_CASES + MEGA_CASES


def run_our_sdk(case: ComplexCase) -> tuple[bool, str, list[tuple[str, dict]]]:
    """Run the case against our SDK with a fake session. Returns (ok, err_msg, ops)."""
    # Fresh import set so each case has a clean state.
    install_fake_session()
    from docx import Document
    from docx.shared import Pt, RGBColor  # noqa: F401 — leaked into exec namespace

    try:
        doc = Document("asset_fake")
        # Execute the case's script.
        local_ns: dict = {
            "doc": doc,
            "RGBColor": RGBColor,
            "Pt": Pt,
        }
        exec(compile(case.script, f"<case:{case.name}>", "exec"), local_ns, local_ns)
        # doc.save flushes
        doc.save()
    except Exception as e:  # noqa: BLE001
        tb = traceback.format_exc()
        ops = list(doc._session.calls()) if "doc" in dir() else []  # type: ignore[attr-defined]
        return False, f"{type(e).__name__}: {e}\n{tb}", ops
    ops = list(doc._session.calls())  # type: ignore[attr-defined]
    return True, "", ops


def run_stock(case: ComplexCase) -> tuple[bool, str]:
    """Run the case against stock python-docx in an isolated subprocess.

    Returns (ok, err_msg). We don't save the file; we just confirm the
    python-docx script executes cleanly.
    """
    pydocx_python = _SDK_ROOT / ".venv-pydocx" / "bin" / "python"
    if not pydocx_python.exists():
        return True, "(skipped — no .venv-pydocx)"
    wrapped = (
        "from docx import Document\n"
        "doc = Document()\n"
        f"{case.script}\n"
    )
    # Avoid picking up our SDK's docx/ if we're running from within the sdk dir.
    env = dict(os.environ)
    env.pop("PYTHONPATH", None)
    result = subprocess.run(
        [str(pydocx_python), "-c", wrapped],
        capture_output=True,
        text=True,
        timeout=10,
        cwd="/tmp",
        env=env,
    )
    if result.returncode != 0:
        return False, f"stock python-docx failed: {result.stderr[:400]}"
    return True, ""


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--filter", default=None, help="substring filter for case names/tags")
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--skip-stock", action="store_true", help="don't validate scripts with stock python-docx")
    args = parser.parse_args()

    selected: list[ComplexCase] = []
    for c in ALL_CASES:
        if args.filter:
            haystack = f"{c.name} {' '.join(c.tags)}"
            if args.filter not in haystack:
                continue
        selected.append(c)

    print(f"[local-fidelity] running {len(selected)}/{len(ALL_CASES)} cases")
    passes = 0
    fails: list[tuple[ComplexCase, str]] = []
    stock_fails: list[tuple[ComplexCase, str]] = []
    missing_ops: list[tuple[ComplexCase, list[str]]] = []

    for case in selected:
        # Step 1: validate the script with stock python-docx (optional)
        if not args.skip_stock:
            ok_stock, err_stock = run_stock(case)
            if not ok_stock:
                stock_fails.append((case, err_stock))

        # Step 2: run against our SDK + fake session
        ok_ours, err_ours, ops = run_our_sdk(case)
        if not ok_ours:
            fails.append((case, err_ours))
            print(f"  ❌ {case.name:40} — FAIL")
            if args.verbose:
                print("      " + err_ours.replace("\n", "\n      "))
            continue

        # Step 3: verify expected ops were recorded
        op_names = [o[0] for o in ops]
        missing = [op for op in case.expected_ops if not any(op in n for n in op_names)]
        if missing:
            missing_ops.append((case, missing))
            print(f"  ⚠️  {case.name:40} — PASS but missing ops: {missing}")
            if args.verbose:
                print(f"      recorded ops: {op_names}")
        else:
            print(f"  ✅ {case.name:40} — PASS ({len(ops)} ops)")
        passes += 1

    print()
    print("=" * 70)
    print(f"Results: {passes}/{len(selected)} passed")
    if fails:
        print(f"FAIL: {len(fails)}")
        for case, err in fails[:10]:
            short = err.split("\n")[0]
            print(f"  - {case.name}: {short}")
    if missing_ops:
        print(f"MISSING_OPS: {len(missing_ops)} (PASS but expected op not recorded)")
        for case, ops in missing_ops[:10]:
            print(f"  - {case.name}: {ops}")
    if stock_fails:
        print(f"STOCK_FAIL (our SDK may still be fine): {len(stock_fails)}")
        for case, err in stock_fails[:5]:
            print(f"  - {case.name}: {err[:100]}")
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main())
