"""Binary round-trip — generate .docx files with stock python-docx, read
back with stock python-docx to verify the scripts are sound, and also
exercise our SDK's surface (with fake session) to verify equivalent-code
paths work.

This is the closest we can get to a true round-trip without running
against a live Keryx / Daytona. For each case:

  1. Run the script through stock python-docx → .docx binary on disk.
  2. Read that .docx with stock python-docx → extract features.
  3. Run the SAME script through our SDK with a FakeSession → extract
     features from the fake state.
  4. Compare the two feature sets.

Step 3's "features from fake state" is the tricky bit: we walk the
fake session's in-memory `_Block`/`_Table` model to emit a DocxFeatures
structure matching `tests/fidelity/extract.py`.

Run with:
    .venv/bin/python tests/fidelity/binary_round_trip.py
"""

from __future__ import annotations

import os
import subprocess
import sys
import tempfile
from pathlib import Path

_SDK_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_SDK_ROOT))

from tests.fidelity.complex_cases import CASES, ComplexCase  # noqa: E402
from tests.fidelity.real_world_cases import REAL_WORLD_CASES  # noqa: E402
from tests.fidelity.mega_cases import MEGA_CASES  # noqa: E402
from tests.fidelity.fake_session import FakeDocState, install_fake_session  # noqa: E402


def run_stock_and_save(case: ComplexCase, out_path: Path) -> tuple[bool, str]:
    """Run script with stock python-docx and save to out_path."""
    pydocx_python = _SDK_ROOT / ".venv-pydocx" / "bin" / "python"
    if not pydocx_python.exists():
        return False, "no .venv-pydocx"
    wrapped = (
        "from docx import Document\n"
        "doc = Document()\n"
        f"{case.script}\n"
        f"doc.save({str(out_path)!r})\n"
    )
    env = dict(os.environ)
    env.pop("PYTHONPATH", None)
    result = subprocess.run(
        [str(pydocx_python), "-c", wrapped],
        capture_output=True,
        text=True,
        timeout=30,
        cwd="/tmp",
        env=env,
    )
    if result.returncode != 0:
        return False, result.stderr[:500]
    return True, ""


def extract_stock_features(path: Path) -> dict:
    """Extract features from a .docx with stock python-docx."""
    pydocx_python = _SDK_ROOT / ".venv-pydocx" / "bin" / "python"
    script = f'''
import json, sys
from docx import Document
d = Document({str(path)!r})
paragraphs = []
for p in d.paragraphs:
    runs = []
    for r in p.runs:
        runs.append({{
            "text": r.text,
            "bold": bool(r.bold) if r.bold else False,
            "italic": bool(r.italic) if r.italic else False,
        }})
    paragraphs.append({{
        "text": p.text,
        "style": p.style.name if p.style else "",
        "runs": runs,
    }})
tables = []
for t in d.tables:
    rows = []
    for row in t.rows:
        rows.append([c.text for c in row.cells])
    tables.append(rows)
out = {{
    "paragraph_count": len(paragraphs),
    "table_count": len(tables),
    "paragraphs": paragraphs,
    "tables": tables,
    "section_count": len(d.sections),
}}
print(json.dumps(out))
'''
    env = dict(os.environ)
    env.pop("PYTHONPATH", None)
    result = subprocess.run(
        [str(pydocx_python), "-c", script],
        capture_output=True,
        text=True,
        timeout=30,
        cwd="/tmp",
        env=env,
    )
    if result.returncode != 0:
        return {"error": result.stderr[:500]}
    import json
    return json.loads(result.stdout)


def extract_fake_features(state: FakeDocState) -> dict:
    """Extract features from our fake session state to compare shape."""
    paragraphs: list = []
    for b in state.blocks:
        runs = []
        if b.inlines:
            for inline in b.inlines:
                run_data = inline.get("run") or {}
                if isinstance(run_data, dict):
                    runs.append({
                        "text": run_data.get("text", ""),
                        "bold": bool(run_data.get("bold", False)),
                        "italic": bool(run_data.get("italic", False)),
                    })
        paragraphs.append({
            "text": b.text,
            "style": b.style_id or "",
            "runs": runs,
        })
    # Only top-level tables (mirrors python-docx doc.tables).
    def cell_text(tbl, r_idx: int, c_idx: int) -> str:
        """Join direct-child paragraph texts (shallow) like python-docx.

        For cells containing a nested table, Word inserts an anchor empty
        paragraph both before and after the table — the fake's
        cell_extra_paragraphs list tracks those.
        """
        cell = tbl.cells[r_idx][c_idx]
        parts: list[str] = [cell.text]
        for extra in tbl.cell_extra_paragraphs.get((r_idx, c_idx), []):
            parts.append(extra.text)
        # If there's a nested table in the cell, Word adds a trailing empty
        # paragraph that doesn't exist as an extra but shows up in cell.text.
        nested_count = len(tbl.cell_nested_tables.get((r_idx, c_idx), []))
        for _ in range(nested_count):
            parts.append("")
        return "\n".join(parts)

    tables: list = []
    for t in state.tables:
        if t.parent_cell is not None:
            continue
        rows = []
        for r_idx in range(len(t.cells)):
            row_texts = [cell_text(t, r_idx, c_idx) for c_idx in range(len(t.cells[r_idx]))]
            rows.append(row_texts)
        tables.append(rows)
    return {
        "paragraph_count": len(state.blocks),
        "table_count": len(tables),
        "paragraphs": paragraphs,
        "tables": tables,
        "section_count": len(state.sections),
    }


def run_our_sdk_and_extract(case: ComplexCase) -> tuple[bool, str, dict]:
    install_fake_session()
    from docx import Document
    from docx.shared import Pt, RGBColor  # noqa: F401
    try:
        doc = Document("asset_fake")
        local_ns: dict = {
            "doc": doc,
            "RGBColor": RGBColor,
            "Pt": Pt,
        }
        exec(compile(case.script, f"<case:{case.name}>", "exec"), local_ns, local_ns)
        doc.save()
        state = doc._session.state()  # type: ignore[attr-defined]
        return True, "", extract_fake_features(state)
    except Exception as e:  # noqa: BLE001
        return False, f"{type(e).__name__}: {e}", {}


def compare_features(stock: dict, ours: dict) -> list[str]:
    """Semantic comparison between stock and our fake-extracted features."""
    diffs: list[str] = []
    if "error" in stock:
        return [f"stock error: {stock['error'][:200]}"]
    # Counts
    if stock["paragraph_count"] != ours["paragraph_count"]:
        diffs.append(
            f"paragraph_count: stock={stock['paragraph_count']} "
            f"ours={ours['paragraph_count']}"
        )
    if stock["table_count"] != ours["table_count"]:
        diffs.append(
            f"table_count: stock={stock['table_count']} ours={ours['table_count']}"
        )
    # Paragraph text
    s_texts = [p["text"] for p in stock["paragraphs"]]
    o_texts = [p["text"] for p in ours["paragraphs"]]
    # Allow trailing empty paragraph mismatch (common in python-docx vs Superdoc)
    def trim_trailing_empty(xs):
        xs = list(xs)
        while xs and not xs[-1]:
            xs.pop()
        return xs
    s_trim = trim_trailing_empty(s_texts)
    o_trim = trim_trailing_empty(o_texts)
    if s_trim != o_trim:
        if len(s_trim) != len(o_trim):
            diffs.append(
                f"paragraph text sequence differs (len: stock={len(s_trim)} ours={len(o_trim)})"
            )
        else:
            for i, (s, o) in enumerate(zip(s_trim, o_trim)):
                if s != o:
                    diffs.append(f"paragraphs[{i}]: stock={s!r} ours={o!r}")
                    if len(diffs) > 5:
                        diffs.append("...more diffs")
                        break
    # Table cells
    for i, (st, ot) in enumerate(zip(stock["tables"], ours["tables"])):
        if st != ot:
            diffs.append(f"table[{i}] differs")
            if len(diffs) > 10:
                diffs.append("...more")
                break
    return diffs


def main() -> int:
    all_cases = CASES + REAL_WORLD_CASES + MEGA_CASES
    # Pick a representative sample — skip the heavy stress cases
    sample = [c for c in all_cases if "large" not in c.tags and "extreme" not in c.tags]
    print(f"[binary-rt] running {len(sample)} cases with real stock python-docx round-trip")

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir_p = Path(tmpdir)
        passes = 0
        fails: list[tuple[ComplexCase, str]] = []

        for case in sample:
            out_path = tmpdir_p / f"{case.name}.docx"
            # Stock
            stock_ok, stock_err = run_stock_and_save(case, out_path)
            if not stock_ok:
                print(f"  ⏭  {case.name:45} — SKIP (stock failed: {stock_err[:60]})")
                continue
            stock_feat = extract_stock_features(out_path)
            # Ours
            ours_ok, ours_err, ours_feat = run_our_sdk_and_extract(case)
            if not ours_ok:
                print(f"  ❌ {case.name:45} — OUR SDK FAIL: {ours_err[:60]}")
                fails.append((case, ours_err))
                continue
            diffs = compare_features(stock_feat, ours_feat)
            if diffs:
                print(f"  ⚠️  {case.name:45} — DIFF ({len(diffs)})")
                for d in diffs[:3]:
                    print(f"      {d}")
            else:
                print(f"  ✅ {case.name:45} — MATCH")
                passes += 1

    print()
    print(f"Results: {passes}/{len(sample)} cases matched exactly")
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main())
