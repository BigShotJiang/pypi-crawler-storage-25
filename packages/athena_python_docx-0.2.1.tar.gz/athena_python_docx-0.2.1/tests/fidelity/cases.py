"""Fidelity test cases.

Each case is a snippet that operates on a pre-bound ``doc`` (the Document
instance). The same snippet runs against stock python-docx and against
athena-python-docx via Daytona.

Conventions
-----------
- Use only the python-docx public API — no private `_element` access, no
  imports beyond what's in the preamble.
- Keep cases minimal (one surface per case where possible) so a failure
  pinpoints the SDK gap.
- Mark known-stubbed operations with ``expected_exc`` — the case passes
  if the stub actually raises (regression detection).
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Case:
    name: str
    description: str
    script: str
    # When set, the athena-python-docx run is expected to raise this exception
    # type. The local python-docx run is never expected to raise — if it does,
    # the case is broken and reported as an infrastructure error.
    expected_athena_exc: str | None = None
    # If True, the athena side is not compared against stock — only asserted
    # to succeed. Use when the op has no content-level effect worth diffing
    # (e.g. add_page_break), or when the stock and Superdoc template diverge
    # too much for a meaningful diff.
    skip_content_diff: bool = False
    # Optional tags for filtering.
    tags: tuple[str, ...] = field(default_factory=tuple)


CASES: list[Case] = [
    # ---- Core append ops -----------------------------------------------------
    Case(
        name="add_paragraph_with_text",
        description="One plain paragraph containing a short string.",
        script='doc.add_paragraph("hello world")',
        tags=("paragraph",),
    ),
    Case(
        name="add_paragraph_empty",
        description="A paragraph with no text (docx.add_paragraph()).",
        script="doc.add_paragraph()",
        tags=("paragraph",),
    ),
    Case(
        name="add_heading_level_1",
        description="Heading 1 with text.",
        script='doc.add_heading("H1 heading", level=1)',
        tags=("heading",),
    ),
    Case(
        name="add_heading_level_2",
        description="Heading 2 with text.",
        script='doc.add_heading("H2 heading", level=2)',
        tags=("heading",),
    ),
    Case(
        name="add_heading_level_3",
        description="Heading 3 with text.",
        script='doc.add_heading("H3 heading", level=3)',
        tags=("heading",),
    ),
    Case(
        name="add_paragraph_style_title",
        description=(
            "add_paragraph(style='Title') — routes through add_heading(level=0). "
            "Regression for devin #3115708111 / greptile #3115709241."
        ),
        script='doc.add_paragraph("The Title", style="Title")',
        tags=("paragraph", "heading", "title"),
    ),
    Case(
        name="add_run_on_heading",
        description=(
            "Add two runs to a heading — exercises _node_text heading-key "
            "support. Regression for greptile #3119401124."
        ),
        script=(
            'h = doc.add_heading("", level=2)\n'
            'h.add_run("first ")\n'
            'h.add_run("second")'
        ),
        tags=("heading", "run"),
    ),
    # ---- Runs + inline formatting --------------------------------------------
    Case(
        name="add_run_bold_italic",
        description="Paragraph with two runs, bold + italic.",
        script=(
            "p = doc.add_paragraph()\n"
            'r1 = p.add_run("bold run")\n'
            "r1.bold = True\n"
            'r2 = p.add_run("italic run")\n'
            "r2.italic = True"
        ),
        tags=("run", "formatting"),
    ),
    Case(
        name="add_run_colored",
        description="Paragraph with a run colored green via RGBColor.",
        script=(
            "from docx.shared import RGBColor\n"
            "p = doc.add_paragraph()\n"
            'r = p.add_run("green text")\n'
            "r.font.color.rgb = RGBColor(0x00, 0x66, 0x00)"
        ),
        tags=("run", "formatting", "color"),
    ),
    Case(
        name="add_run_font_size",
        description="Paragraph with a run set to 18pt.",
        script=(
            "from docx.shared import Pt\n"
            "p = doc.add_paragraph()\n"
            'r = p.add_run("sized 18pt")\n'
            "r.font.size = Pt(18)"
        ),
        tags=("run", "formatting", "font"),
    ),
    # ---- Tables --------------------------------------------------------------
    Case(
        name="add_table_2x2_empty",
        description="Create an empty 2x2 table; verify row/col count.",
        script="doc.add_table(rows=2, cols=2)",
        tags=("table",),
    ),
    Case(
        name="add_table_3x3_with_style",
        description="Create a 3x3 TableGrid table.",
        script='doc.add_table(rows=3, cols=3, style="TableGrid")',
        tags=("table", "style"),
    ),
    Case(
        name="cell_text_setter",
        description="Set cell(0,0).text on a 2x2 table — known NotImplementedError (Phase 2 stub).",
        script=(
            "t = doc.add_table(rows=2, cols=2)\n"
            't.cell(0, 0).text = "A1"'
        ),
        expected_athena_exc="NotImplementedError",
        tags=("table", "stub"),
    ),
    # ---- Structural ops ------------------------------------------------------
    Case(
        name="add_page_break",
        description="Append a page break; content-diff skipped (template differs).",
        script="doc.add_page_break()",
        skip_content_diff=True,
        tags=("structural",),
    ),
    # ---- Multi-op combo ------------------------------------------------------
    Case(
        name="combo_heading_paragraph_table",
        description="Heading + paragraph with formatted runs + 2x2 table (no cell text).",
        script=(
            "from docx.shared import RGBColor\n"
            'doc.add_heading("Report", level=1)\n'
            "p = doc.add_paragraph()\n"
            'r1 = p.add_run("Revenue grew ")\n'
            'r2 = p.add_run("12%")\n'
            "r2.bold = True\n"
            "r2.font.color.rgb = RGBColor(0x00, 0x66, 0x00)\n"
            'p.add_run(" YoY.")\n'
            'doc.add_table(rows=2, cols=2, style="TableGrid")'
        ),
        tags=("combo",),
    ),
]
