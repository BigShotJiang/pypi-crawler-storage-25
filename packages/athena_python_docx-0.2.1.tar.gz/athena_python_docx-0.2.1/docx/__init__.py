"""athena-python-docx — drop-in replacement for python-docx.

Calls translate into Superdoc SDK operations against a Keryx Y.Doc.
See CLAUDE.md for the API parity contract.
"""

from __future__ import annotations

__version__ = "0.2.1"

from docx.api import Document

__all__ = [
    "Document",
    "__version__",
]
