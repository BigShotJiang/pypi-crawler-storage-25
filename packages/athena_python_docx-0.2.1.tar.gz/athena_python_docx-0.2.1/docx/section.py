"""Section — python-docx docx.section.Section parity.

Sections expose page geometry (size, margins, orientation), header/footer
references, and the start break type. Values are read from and persisted
to Superdoc via `doc.sections.*` ops.

Length values are stored in EMU in python-docx; we accept Length/Emu/Pt
instances for setters and round-trip via Superdoc (which takes point
or twip values depending on the op).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from docx._batching import run_sync
from docx.shared import Emu, Length, Pt

if TYPE_CHECKING:
    from docx.client import Session
    from docx.enum.section import WD_ORIENTATION, WD_SECTION_START


def _emu_from(value: object) -> int:
    """Coerce a length input to EMU."""
    if value is None:
        return 0
    if isinstance(value, Length):
        return int(value)
    if isinstance(value, (int, float)):
        return int(value)
    raise TypeError(f"Cannot convert {type(value).__name__} to EMU")


def _emu_to_pt(emu: int) -> float:
    return emu / 12700.0


class Section:
    """A document section — page size, margins, headers/footers, break type."""

    def __init__(self, *, session: "Session", address: dict) -> None:
        self._session: "Session" = session
        self._address: dict = address

    # ---- snapshot helpers ----
    def _fetch(self) -> dict:
        info: object = run_sync(
            self._session.doc.sections.get({"target": self._address}),
        )
        return info if isinstance(info, dict) else {}

    def _set_margins(self, **kwargs: float) -> None:
        run_sync(
            self._session.doc.sections.set_page_margins(
                {"target": self._address, **kwargs},
            ),
        )

    def _set_page_setup(self, **kwargs: object) -> None:
        run_sync(
            self._session.doc.sections.set_page_setup(
                {"target": self._address, **kwargs},
            ),
        )

    # ---- page size ----
    @property
    def page_width(self) -> "Length | None":
        data = self._fetch()
        ps = data.get("pageSetup", {}) if isinstance(data, dict) else {}
        w = ps.get("width") if isinstance(ps, dict) else None
        if isinstance(w, (int, float)):
            # returned in pt
            return Pt(float(w))
        return None

    @page_width.setter
    def page_width(self, value: "Length | int | None") -> None:
        if value is None:
            return
        pt = _emu_to_pt(_emu_from(value))
        self._set_page_setup(width=pt)

    @property
    def page_height(self) -> "Length | None":
        data = self._fetch()
        ps = data.get("pageSetup", {}) if isinstance(data, dict) else {}
        h = ps.get("height") if isinstance(ps, dict) else None
        if isinstance(h, (int, float)):
            return Pt(float(h))
        return None

    @page_height.setter
    def page_height(self, value: "Length | int | None") -> None:
        if value is None:
            return
        pt = _emu_to_pt(_emu_from(value))
        self._set_page_setup(height=pt)

    @property
    def orientation(self) -> "WD_ORIENTATION | None":
        from docx.enum.section import WD_ORIENTATION

        data = self._fetch()
        ps = data.get("pageSetup", {}) if isinstance(data, dict) else {}
        o = ps.get("orientation") if isinstance(ps, dict) else None
        if isinstance(o, str):
            try:
                return WD_ORIENTATION(o)
            except ValueError:
                return None
        return None

    @orientation.setter
    def orientation(self, value: "WD_ORIENTATION | str | None") -> None:
        from docx.enum.section import WD_ORIENTATION

        if value is None:
            return
        v: str = (
            value.to_superdoc()
            if isinstance(value, WD_ORIENTATION)
            else str(value).lower()
        )
        self._set_page_setup(orientation=v)

    # ---- margins ----
    def _margin(self, key: str) -> "Length | None":
        data = self._fetch()
        m = data.get("margins", {}) if isinstance(data, dict) else {}
        v = m.get(key) if isinstance(m, dict) else None
        if isinstance(v, (int, float)):
            return Pt(float(v))
        return None

    @property
    def left_margin(self) -> "Length | None":
        return self._margin("left")

    @left_margin.setter
    def left_margin(self, value: "Length | int | None") -> None:
        if value is None:
            return
        self._set_margins(left=_emu_to_pt(_emu_from(value)))

    @property
    def right_margin(self) -> "Length | None":
        return self._margin("right")

    @right_margin.setter
    def right_margin(self, value: "Length | int | None") -> None:
        if value is None:
            return
        self._set_margins(right=_emu_to_pt(_emu_from(value)))

    @property
    def top_margin(self) -> "Length | None":
        return self._margin("top")

    @top_margin.setter
    def top_margin(self, value: "Length | int | None") -> None:
        if value is None:
            return
        self._set_margins(top=_emu_to_pt(_emu_from(value)))

    @property
    def bottom_margin(self) -> "Length | None":
        return self._margin("bottom")

    @bottom_margin.setter
    def bottom_margin(self, value: "Length | int | None") -> None:
        if value is None:
            return
        self._set_margins(bottom=_emu_to_pt(_emu_from(value)))

    @property
    def gutter(self) -> "Length | None":
        return self._margin("gutter")

    @gutter.setter
    def gutter(self, value: "Length | int | None") -> None:
        if value is None:
            return
        self._set_margins(gutter=_emu_to_pt(_emu_from(value)))

    @property
    def header_distance(self) -> "Length | None":
        data = self._fetch()
        hfm = data.get("headerFooterMargins", {}) if isinstance(data, dict) else {}
        v = hfm.get("header") if isinstance(hfm, dict) else None
        if isinstance(v, (int, float)):
            return Pt(float(v))
        return None

    @header_distance.setter
    def header_distance(self, value: "Length | int | None") -> None:
        if value is None:
            return
        run_sync(
            self._session.doc.sections.set_header_footer_margins(
                {"target": self._address, "header": _emu_to_pt(_emu_from(value))},
            ),
        )

    @property
    def footer_distance(self) -> "Length | None":
        data = self._fetch()
        hfm = data.get("headerFooterMargins", {}) if isinstance(data, dict) else {}
        v = hfm.get("footer") if isinstance(hfm, dict) else None
        if isinstance(v, (int, float)):
            return Pt(float(v))
        return None

    @footer_distance.setter
    def footer_distance(self, value: "Length | int | None") -> None:
        if value is None:
            return
        run_sync(
            self._session.doc.sections.set_header_footer_margins(
                {"target": self._address, "footer": _emu_to_pt(_emu_from(value))},
            ),
        )

    # ---- break type ----
    @property
    def start_type(self) -> "WD_SECTION_START | None":
        from docx.enum.section import WD_SECTION_START

        data = self._fetch()
        bt = data.get("breakType") if isinstance(data, dict) else None
        if not isinstance(bt, str):
            return None
        for member in WD_SECTION_START:
            if member.to_superdoc() == bt:
                return member
        return None

    @start_type.setter
    def start_type(self, value: "WD_SECTION_START | str | None") -> None:
        from docx.enum.section import WD_SECTION_START

        if value is None:
            return
        v: str = (
            value.to_superdoc()
            if isinstance(value, WD_SECTION_START)
            else str(value)
        )
        run_sync(
            self._session.doc.sections.set_break_type(
                {"target": self._address, "breakType": v},
            ),
        )

    # ---- header/footer presence flags ----
    @property
    def different_first_page_header_footer(self) -> bool | None:
        data = self._fetch()
        v = data.get("titlePage") if isinstance(data, dict) else None
        return bool(v) if isinstance(v, bool) else None

    @different_first_page_header_footer.setter
    def different_first_page_header_footer(self, value: bool | None) -> None:
        if value is None:
            return
        run_sync(
            self._session.doc.sections.set_title_page(
                {"target": self._address, "titlePage": bool(value)},
            ),
        )

    # python-docx also exposes .header and .footer but those return
    # Header/Footer objects with paragraphs. We return read-only stubs
    # to allow attribute access without AttributeError.
    @property
    def header(self) -> "_HeaderFooter":
        return _HeaderFooter(self, "header")

    @property
    def footer(self) -> "_HeaderFooter":
        return _HeaderFooter(self, "footer")

    @property
    def first_page_header(self) -> "_HeaderFooter":
        return _HeaderFooter(self, "header", first_page=True)

    @property
    def first_page_footer(self) -> "_HeaderFooter":
        return _HeaderFooter(self, "footer", first_page=True)


class _HeaderFooter:
    """Lightweight Header/Footer proxy — exposes is_linked_to_previous and
    a (possibly empty) paragraphs list."""

    def __init__(self, section: Section, kind: str, first_page: bool = False) -> None:
        self._section: Section = section
        self._kind: str = kind
        self._first_page: bool = first_page

    @property
    def is_linked_to_previous(self) -> bool:
        data = self._section._fetch()
        linked = data.get("linkedToPrevious", {}) if isinstance(data, dict) else {}
        if isinstance(linked, dict):
            return bool(linked.get(self._kind, True))
        return True

    @is_linked_to_previous.setter
    def is_linked_to_previous(self, value: bool) -> None:
        run_sync(
            self._section._session.doc.sections.set_link_to_previous(
                {
                    "target": self._section._address,
                    "kind": self._kind,
                    "linkedToPrevious": bool(value),
                },
            ),
        )

    @property
    def paragraphs(self) -> list:
        # Headers/footers paragraphs iteration needs a separate fetch; we
        # return an empty list rather than raising so code that iterates
        # these without modification still works.
        return []


class Sections:
    """Ordered collection of sections in a document."""

    def __init__(self, *, session: "Session") -> None:
        self._session: "Session" = session

    def _items(self) -> list[dict]:
        info: object = run_sync(self._session.doc.sections.list({}))
        if isinstance(info, dict):
            items: object = info.get("items", [])
            if isinstance(items, list):
                return [i for i in items if isinstance(i, dict)]
        return []

    def __iter__(self):
        for item in self._items():
            addr = item.get("address", {})
            if isinstance(addr, dict):
                yield Section(session=self._session, address=addr)

    def __len__(self) -> int:
        return len(self._items())

    def __getitem__(self, index: int) -> Section:
        items = self._items()
        addr = items[index].get("address", {})
        if not isinstance(addr, dict):
            raise IndexError(f"Section {index} has no address")
        return Section(session=self._session, address=addr)
