"""Style-related enums — python-docx parity (docx.enum.style)."""

from __future__ import annotations

from enum import Enum


class WD_STYLE_TYPE(Enum):
    PARAGRAPH = "paragraph"
    CHARACTER = "character"
    LIST = "list"
    TABLE = "table"


WD_STYLE = WD_STYLE_TYPE


class WD_BUILTIN_STYLE(Enum):
    """Common built-in Word style names. Names match python-docx exactly."""

    BLOCK_QUOTATION = "Quote"
    BODY_TEXT = "Body Text"
    BODY_TEXT_2 = "Body Text 2"
    BODY_TEXT_3 = "Body Text 3"
    BODY_TEXT_FIRST_INDENT = "Body Text First Indent"
    BODY_TEXT_FIRST_INDENT_2 = "Body Text First Indent 2"
    BODY_TEXT_IND = "Body Text Indent"
    BODY_TEXT_IND_2 = "Body Text Indent 2"
    BODY_TEXT_IND_3 = "Body Text Indent 3"
    CAPTION = "Caption"
    DEFAULT_PARAGRAPH_FONT = "Default Paragraph Font"
    EMPHASIS = "Emphasis"
    HEADING_1 = "Heading 1"
    HEADING_2 = "Heading 2"
    HEADING_3 = "Heading 3"
    HEADING_4 = "Heading 4"
    HEADING_5 = "Heading 5"
    HEADING_6 = "Heading 6"
    HEADING_7 = "Heading 7"
    HEADING_8 = "Heading 8"
    HEADING_9 = "Heading 9"
    INTENSE_EMPHASIS = "Intense Emphasis"
    INTENSE_QUOTE = "Intense Quote"
    INTENSE_REFERENCE = "Intense Reference"
    LIST_BULLET = "List Bullet"
    LIST_BULLET_2 = "List Bullet 2"
    LIST_BULLET_3 = "List Bullet 3"
    LIST_NUMBER = "List Number"
    LIST_NUMBER_2 = "List Number 2"
    LIST_NUMBER_3 = "List Number 3"
    MACRO_TEXT = "Macro Text"
    NAV_PANE = "Nav Pane"
    NORMAL = "Normal"
    NORMAL_INDENT = "Normal Indent"
    NORMAL_TABLE = "Normal Table"
    NO_SPACING = "No Spacing"
    QUOTE = "Quote"
    SUBTITLE = "Subtitle"
    STRONG = "Strong"
    TABLE_GRID = "Table Grid"
    TITLE = "Title"
    TOC_1 = "TOC 1"
    TOC_2 = "TOC 2"
    TOC_3 = "TOC 3"
