"""Text-related enums — python-docx parity (docx.enum.text).

Values map to Superdoc primitives where supported; unmapped values
(e.g. Thai/Arabic justification variants) still parse but serialize to
their best Superdoc equivalent.
"""

from __future__ import annotations

from enum import Enum


class WD_ALIGN_PARAGRAPH(Enum):
    """Paragraph alignment (justification)."""

    LEFT = "left"
    CENTER = "center"
    RIGHT = "right"
    JUSTIFY = "justify"
    DISTRIBUTE = "distribute"
    JUSTIFY_MED = "justifyMed"
    JUSTIFY_HI = "justifyHi"
    JUSTIFY_LOW = "justifyLow"
    THAI_JUSTIFY = "thaiJustify"

    def to_superdoc(self) -> str:
        # Superdoc only supports left/center/right/justify; coerce the
        # distributed/thai variants to "justify" so set_alignment doesn't
        # reject them.
        if self in (
            WD_ALIGN_PARAGRAPH.DISTRIBUTE,
            WD_ALIGN_PARAGRAPH.JUSTIFY_MED,
            WD_ALIGN_PARAGRAPH.JUSTIFY_HI,
            WD_ALIGN_PARAGRAPH.JUSTIFY_LOW,
            WD_ALIGN_PARAGRAPH.THAI_JUSTIFY,
        ):
            return "justify"
        return self.value

    @classmethod
    def from_superdoc(cls, s: str) -> "WD_ALIGN_PARAGRAPH | None":
        try:
            return cls(s)
        except ValueError:
            pass
        try:
            return cls(s.lower())
        except ValueError:
            return None


class WD_LINE_SPACING(Enum):
    """Line-spacing rule."""

    SINGLE = "single"
    ONE_POINT_FIVE = "onePointFive"
    DOUBLE = "double"
    AT_LEAST = "atLeast"
    EXACTLY = "exactly"
    MULTIPLE = "multiple"

    def to_superdoc(self) -> str:
        # Superdoc's lineRule enum: "auto" | "exact" | "atLeast"
        if self == WD_LINE_SPACING.EXACTLY:
            return "exact"
        if self == WD_LINE_SPACING.AT_LEAST:
            return "atLeast"
        # SINGLE/1.5/DOUBLE/MULTIPLE all map to "auto" with a line value
        return "auto"


class WD_TAB_ALIGNMENT(Enum):
    LEFT = "left"
    CENTER = "center"
    RIGHT = "right"
    DECIMAL = "decimal"
    BAR = "bar"
    LIST = "list"
    CLEAR = "clear"
    END = "end"
    NUM = "num"
    START = "start"

    def to_superdoc(self) -> str:
        if self in (
            WD_TAB_ALIGNMENT.LIST,
            WD_TAB_ALIGNMENT.CLEAR,
            WD_TAB_ALIGNMENT.END,
            WD_TAB_ALIGNMENT.NUM,
            WD_TAB_ALIGNMENT.START,
        ):
            return "left"
        return self.value


class WD_TAB_LEADER(Enum):
    SPACES = "none"
    DOTS = "dot"
    DASHES = "hyphen"
    LINES = "underscore"
    HEAVY = "heavy"
    MIDDLE_DOT = "middleDot"

    def to_superdoc(self) -> str:
        return self.value


class WD_BREAK(Enum):
    LINE = "line"
    PAGE = "page"
    COLUMN = "column"
    LINE_CLEAR_LEFT = "lineClearLeft"
    LINE_CLEAR_RIGHT = "lineClearRight"
    LINE_CLEAR_ALL = "lineClearAll"
    TEXT_WRAPPING = "textWrapping"


class WD_UNDERLINE(Enum):
    NONE = "none"
    SINGLE = "single"
    WORDS = "words"
    DOUBLE = "double"
    DOTTED = "dotted"
    THICK = "thick"
    DASH = "dash"
    DOT_DASH = "dotDash"
    DOT_DOT_DASH = "dotDotDash"
    WAVY = "wavy"
    DOTTED_HEAVY = "dottedHeavy"
    DASH_HEAVY = "dashHeavy"
    DOT_DASH_HEAVY = "dotDashHeavy"
    DOT_DOT_DASH_HEAVY = "dotDotDashHeavy"
    WAVY_HEAVY = "wavyHeavy"
    DASH_LONG = "dashLong"
    DASH_LONG_HEAVY = "dashLongHeavy"
    WAVY_DOUBLE = "wavyDouble"


class WD_COLOR_INDEX(Enum):
    AUTO = "default"
    BLACK = "black"
    BLUE = "blue"
    BRIGHT_GREEN = "green"
    DARK_BLUE = "darkBlue"
    DARK_RED = "darkRed"
    DARK_YELLOW = "darkYellow"
    GRAY_25 = "lightGray"
    GRAY_50 = "darkGray"
    GREEN = "darkGreen"
    PINK = "magenta"
    RED = "red"
    TEAL = "darkCyan"
    TURQUOISE = "cyan"
    VIOLET = "darkMagenta"
    WHITE = "white"
    YELLOW = "yellow"


# Alias used by python-docx as well
WD_COLOR = WD_COLOR_INDEX
