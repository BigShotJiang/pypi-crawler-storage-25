"""Section-related enums — python-docx parity (docx.enum.section)."""

from __future__ import annotations

from enum import Enum


class WD_ORIENTATION(Enum):
    PORTRAIT = "portrait"
    LANDSCAPE = "landscape"

    def to_superdoc(self) -> str:
        return self.value


# python-docx also exposes a short alias
WD_ORIENT = WD_ORIENTATION


class WD_SECTION_START(Enum):
    CONTINUOUS = "continuous"
    NEW_COLUMN = "nextColumn"
    NEW_PAGE = "nextPage"
    EVEN_PAGE = "evenPage"
    ODD_PAGE = "oddPage"

    def to_superdoc(self) -> str:
        if self == WD_SECTION_START.CONTINUOUS:
            return "continuous"
        if self == WD_SECTION_START.EVEN_PAGE:
            return "evenPage"
        if self == WD_SECTION_START.ODD_PAGE:
            return "oddPage"
        return "nextPage"


WD_SECTION = WD_SECTION_START
