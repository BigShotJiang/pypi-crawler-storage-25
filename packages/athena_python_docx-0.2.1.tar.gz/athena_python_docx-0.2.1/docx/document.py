"""Document class — mirrors python-docx's Document.

Phase 1 supported methods:
    .paragraphs        -> list[Paragraph]  (snapshot on access)
    .tables            -> list[Table]
    .add_paragraph(text, style=None) -> Paragraph
    .add_heading(text, level=1) -> Paragraph
    .add_table(rows, cols, style=None) -> Table
    .add_picture(image_path_or_stream, width=None, height=None) -> None
    .add_page_break() -> None
    .save(path=None) -> None  (path ignored; always in-place)
    .close() -> None
"""

from __future__ import annotations

import base64
import io
import sys
from typing import TYPE_CHECKING, BinaryIO

from docx._batching import run_sync
from docx.client import Session
from docx.errors import DocumentClosedError, ValidationError

if TYPE_CHECKING:
    from docx.shared import Emu
    from docx.table import Table
    from docx.text.paragraph import Paragraph


def _log_warn(msg: str) -> None:
    print(f"[docx-sdk] WARN: {msg}", file=sys.stderr)


class Document:
    """A Word document backed by a Superdoc/Keryx Y.Doc.

    Construct via :func:`docx.api.Document` (recommended) — do not
    instantiate this class directly in user code.
    """

    def __init__(self, *, asset_id: str) -> None:
        self._session: Session = Session(asset_id=asset_id)
        self._saved: bool = False
        self._closed: bool = False

    # ---- Public properties ----

    @property
    def paragraphs(self) -> list["Paragraph"]:
        """Return all paragraphs in document order.

        python-docx returns a live list; we return a snapshot. For a
        live-ish list, call this again.
        """
        from docx.text.paragraph import Paragraph

        self._ensure_open()
        # doc.blocks.list takes `nodeTypes: list[str]` (not `type: str`).
        # Include "heading" too so iterating over paragraphs covers both —
        # python-docx does not distinguish headings from paragraphs at the
        # Document.paragraphs level either (they're all Paragraph instances).
        raw: object = run_sync(
            self._session.doc.blocks.list(
                {"nodeTypes": ["paragraph", "heading"], "includeText": True},
            ),
        )
        # Real shape: {"blocks": [{"kind":"block","nodeType":..,"nodeId":..,"text":..}], ...}
        if isinstance(raw, dict):
            blocks_obj: object = raw.get("blocks", [])
            blocks: list = blocks_obj if isinstance(blocks_obj, list) else []
        elif isinstance(raw, list):
            blocks = raw
        else:
            blocks = []
        out: list["Paragraph"] = []
        for b in blocks:
            if not isinstance(b, dict):
                continue
            node_id: str = str(b.get("nodeId", ""))
            if node_id:
                out.append(Paragraph(session=self._session, node_id=node_id))
        return out

    @property
    def tables(self) -> list["Table"]:
        """Return all tables in document order."""
        from docx.table import Table

        self._ensure_open()
        find_result: dict = run_sync(
            self._session.doc.find({"type": "table"}),
        )
        items: list[dict] = find_result.get("items", [])
        return [
            Table(session=self._session, node_id=item["address"]["nodeId"])
            for item in items
        ]

    @property
    def sections(self):
        """Return the document's sections collection."""
        from docx.section import Sections

        self._ensure_open()
        return Sections(session=self._session)

    @property
    def inline_shapes(self):
        """Return the document's inline-shape collection."""
        from docx.shape import InlineShapes

        self._ensure_open()
        return InlineShapes(session=self._session)

    @property
    def styles(self):
        """Return the document's styles collection."""
        from docx.styles.styles import Styles

        self._ensure_open()
        return Styles(session=self._session)

    @property
    def core_properties(self):
        """Return a minimal CoreProperties proxy.

        Most python-docx fields aren't surfaced by Superdoc; accessing an
        unsupported field returns None rather than raising.
        """
        from docx.opc.coreprops import CoreProperties

        return CoreProperties(session=self._session)

    @property
    def settings(self):
        """Return a minimal Settings proxy (stubbed; Superdoc doesn't surface app settings)."""
        from docx.settings import Settings

        return Settings(session=self._session)

    @property
    def element(self):
        """python-docx returns the underlying lxml element. We return a best-effort proxy."""
        return None

    part = element

    # ---- Append operations ----

    @staticmethod
    def _normalize_text(text: str) -> str:
        """Normalize line endings like python-docx: \\r\\n → \\n\\n, lone \\r → \\n."""
        # python-docx's text IO strips \r and converts \r to \n.
        if not text:
            return text
        # \r\n → \n\n (preserves paragraph-break semantics)
        return text.replace("\r\n", "\n\n").replace("\r", "\n")

    def add_paragraph(
        self,
        text: str = "",
        style: str | None = None,
    ) -> "Paragraph":
        """Append a new paragraph at the end of the document.

        Args:
            text: The paragraph text.
            style: The paragraph style name (e.g. "Heading 1", "Normal").
                   If None, uses the default style.

        Returns:
            The newly-created Paragraph.
        """
        from docx.text.paragraph import Paragraph

        self._ensure_open()

        # Use Superdoc's canonical primitive `doc.create.paragraph`. It
        # accepts an `at` anchor and a `text` body; an empty `text` creates
        # a truly-empty paragraph (no markdown-parser edge case).
        #
        # For heading styles we still dispatch to add_heading, which uses
        # `doc.create.heading` (also canonical, takes `level`).
        if style and style.lower().startswith("heading"):
            try:
                level: int = int(style.rsplit(" ", 1)[-1])
            except ValueError:
                level = 1
            return self.add_heading(text=text, level=level)
        if style and style.lower() == "title":
            return self.add_heading(text=text, level=0)

        params: dict = {
            "text": self._normalize_text(text),
            "at": {"kind": "documentEnd"},
        }
        result: dict = run_sync(
            self._session.doc.create.paragraph(params),
        )
        node_id: str = _extract_inserted_node_id(result, expected_type="paragraph")
        if not node_id:
            raise RuntimeError(
                f"Superdoc did not return a nodeId for add_paragraph: {result!r}",
            )
        return Paragraph(session=self._session, node_id=node_id)

    def add_heading(
        self,
        text: str = "",
        level: int = 1,
    ) -> "Paragraph":
        """Append a heading via Superdoc's canonical `doc.create.heading`."""
        from docx.text.paragraph import Paragraph

        self._ensure_open()
        if not 0 <= level <= 9:
            raise ValidationError(
                f"level must be in 0..9; got {level}",
            )

        # python-docx semantics: level=0 is Title, 1..9 are Heading N.
        # Superdoc's doc.create.heading only accepts integer levels 1..6,
        # so Title (level=0) routes through create.paragraph followed by a
        # style change to "Title". Levels 7..9 fall through to create.heading
        # and will raise a SuperDocError if the runtime rejects them — that
        # mirrors python-docx's tolerance without silently degrading.
        if level == 0:
            result: dict = run_sync(
                self._session.doc.create.paragraph(
                    {"text": text, "at": {"kind": "documentEnd"}},
                ),
            )
            node_id: str = _extract_inserted_node_id(
                result, expected_type="paragraph",
            )
            if not node_id:
                raise RuntimeError(
                    f"Superdoc did not return a nodeId for add_heading(level=0): {result!r}",
                )
            paragraph = Paragraph(session=self._session, node_id=node_id)
            paragraph.style = "Title"
            return paragraph

        params: dict = {
            "text": text,
            "level": level,
            "at": {"kind": "documentEnd"},
        }
        result = run_sync(
            self._session.doc.create.heading(params),
        )
        node_id = _extract_inserted_node_id(result, expected_type="paragraph")
        if not node_id:
            raise RuntimeError(
                f"Superdoc did not return a nodeId for add_heading: {result!r}",
            )
        return Paragraph(session=self._session, node_id=node_id)

    def add_table(
        self,
        rows: int,
        cols: int,
        style: str | None = None,
    ) -> "Table":
        """Append a table with the given dimensions via `doc.create.table`."""
        from docx.table import Table

        self._ensure_open()
        if rows < 1 or cols < 1:
            raise ValidationError(
                f"rows and cols must be >= 1; got rows={rows} cols={cols}",
            )

        # The real param is `columns` (not `cols`). `at` is required to
        # position the table; we always append to document end.
        result: dict = run_sync(
            self._session.doc.create.table(
                {
                    "rows": rows,
                    "columns": cols,
                    "at": {"kind": "documentEnd"},
                },
            ),
        )
        node_id: str = _extract_inserted_node_id(result, expected_type="table")
        if not node_id:
            raise RuntimeError(
                f"Superdoc did not return a nodeId for add_table: {result!r}",
            )

        if style:
            run_sync(
                self._session.doc.tables.set_style(
                    {"nodeId": node_id, "styleId": style},
                ),
            )
            # Re-fetch nodeId — set_style may rotate it. Prefer matching the
            # original id; fall back to last-in-list with a warning.
            refetch: dict = run_sync(
                self._session.doc.find({"type": "table"}),
            )
            items: list[dict] = refetch.get("items", [])
            matched: bool = any(
                isinstance(item, dict)
                and item.get("address", {}).get("nodeId") == node_id
                for item in items
            )
            if not matched and items:
                last: dict = items[-1] if isinstance(items[-1], dict) else {}
                new_id: str = str(last.get("address", {}).get("nodeId", ""))
                if new_id:
                    import sys
                    print(
                        f"[docx-sdk] WARN: add_table nodeId rotated after "
                        f"set_style: {node_id} -> {new_id}",
                        file=sys.stderr,
                    )
                    node_id = new_id

        return Table(session=self._session, node_id=node_id)

    def add_picture(
        self,
        image_path_or_stream: str | BinaryIO,
        width: "Emu | int | None" = None,
        height: "Emu | int | None" = None,
    ) -> None:
        """Append an inline image via `doc.create.image`."""
        self._ensure_open()

        image_bytes: bytes
        content_type: str = "image/png"
        if isinstance(image_path_or_stream, str):
            with open(image_path_or_stream, "rb") as f:
                image_bytes = f.read()
            lower: str = image_path_or_stream.lower()
            if lower.endswith((".jpg", ".jpeg")):
                content_type = "image/jpeg"
            elif lower.endswith(".gif"):
                content_type = "image/gif"
            elif lower.endswith(".webp"):
                content_type = "image/webp"
        elif isinstance(image_path_or_stream, io.IOBase):
            image_bytes = image_path_or_stream.read()
        else:
            raise TypeError(
                "Expected path str or binary stream, "
                f"got {type(image_path_or_stream).__name__}",
            )

        b64: str = base64.b64encode(image_bytes).decode("ascii")
        data_uri: str = f"data:{content_type};base64,{b64}"

        w_px: float = _emu_to_px(width) if width is not None else 576.0
        h_px: float = _emu_to_px(height) if height is not None else 432.0

        run_sync(
            self._session.doc.create.image(
                {
                    "src": data_uri,
                    "size": {"width": w_px, "height": h_px},
                    "at": {"kind": "documentEnd"},
                },
            ),
        )

    def add_section(self, start_type: object = None):
        """Append a new section and return its Section proxy.

        Mirrors python-docx: creating a section adds a trailing empty
        paragraph that marks the section boundary.
        """
        from docx.enum.section import WD_SECTION_START
        from docx.section import Section

        self._ensure_open()
        # python-docx always inserts an anchor paragraph at the section break
        self.add_paragraph("")
        break_type: str = "nextPage"
        if start_type is not None:
            if isinstance(start_type, WD_SECTION_START):
                break_type = start_type.to_superdoc()
            elif isinstance(start_type, str):
                break_type = start_type
        run_sync(
            self._session.doc.create.section_break(
                {"at": {"kind": "documentEnd"}, "breakType": break_type},
            ),
        )
        info: object = run_sync(self._session.doc.sections.list({}))
        items: list = []
        if isinstance(info, dict):
            items_obj = info.get("items", [])
            if isinstance(items_obj, list):
                items = items_obj
        if not items:
            raise RuntimeError(
                "Superdoc did not return any sections after add_section",
            )
        last = items[-1]
        addr = last.get("address", {}) if isinstance(last, dict) else {}
        return Section(session=self._session, address=addr if isinstance(addr, dict) else {})

    def add_page_break(self) -> None:
        """Append a page break at the end of the document.

        python-docx appends an empty paragraph with a page-break run inside;
        `doc.paragraphs` includes that new paragraph. We mirror by adding
        an anchor paragraph first, then the section break.
        """
        self._ensure_open()
        # Anchor paragraph so doc.paragraphs reflects the break visually.
        self.add_paragraph("")
        run_sync(
            self._session.doc.create.section_break(
                {"at": {"kind": "documentEnd"}, "breakType": "nextPage"},
            ),
        )

    # ---- Lifecycle ----

    def save(self, path: str | None = None) -> None:  # noqa: ARG002
        """Flush pending edits to Keryx.

        `path` is accepted for python-docx parity but ignored — writes
        are always in-place against the Y.Doc. Saving to a local file
        is not supported in Phase 1 (use the Olympus UI's Export DOCX).
        """
        self._ensure_open()
        run_sync(self._session.save(in_place=True))
        self._saved = True

    def close(self) -> None:
        """Close the session. Not strictly needed (context-managed)."""
        if self._closed:
            return
        try:
            run_sync(self._session.close())
        finally:
            self._closed = True

    def __enter__(self) -> "Document":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:  # noqa: ANN001
        if exc_type is None and not self._saved and self._session.is_open:
            try:
                self.save()
            except Exception as e:
                _log_warn(f"autosave failed for {self._session.asset_id}: {e}")
        self.close()

    # ---- Internals ----

    def _ensure_open(self) -> None:
        if self._closed:
            raise DocumentClosedError(
                f"Document {self._session.asset_id} is closed.",
            )
        if not self._session.is_open:
            run_sync(self._session.open())


# ---- Module-level helpers ----

def _extract_inserted_node_id(result: dict, *, expected_type: str) -> str:
    """Parse Superdoc create/insert response to find the new node's blockId.

    Real observed shapes (superdoc-sdk 1.6.0.dev29):

      doc.create.paragraph/heading/table returns
          {"success": True, "<paragraph|heading|table>": {"nodeId": "..."}}

      doc.insert (markdown/text) returns
          {"receipt": {"resolution": {"target": {"blockId": "..."}}}, ...}

    We probe create-shape first (nested by expected_type), then insert-shape.
    Returns "" if nothing matches.
    """
    if not isinstance(result, dict):
        return ""

    # Shape 1 — doc.create.paragraph/heading/table/image: top-level key
    # named by the result type holds `{kind, nodeType, nodeId}`.
    for key in (expected_type, "paragraph", "heading", "table", "image"):
        obj = result.get(key)
        if isinstance(obj, dict):
            node_id = obj.get("nodeId")
            if isinstance(node_id, str) and node_id:
                return node_id

    # Shape 2 — doc.insert: receipt.resolution.target.blockId.
    receipt: object = result.get("receipt")
    if isinstance(receipt, dict):
        resolution: object = receipt.get("resolution")
        if isinstance(resolution, dict):
            target: object = resolution.get("target")
            if isinstance(target, dict):
                block_id: str = str(target.get("blockId", ""))
                if block_id:
                    return block_id

    # Shape 3 — top-level blockId or target.blockId.
    top_block: object = result.get("blockId")
    if isinstance(top_block, str) and top_block:
        return top_block
    top_target: object = result.get("target")
    if isinstance(top_target, dict):
        tb: str = str(top_target.get("blockId", ""))
        if tb:
            return tb

    # Shape 4 (legacy): nested result.result.insertedNodes[] / nodes[].
    data_obj: object = result.get("result", {})
    data: dict = data_obj if isinstance(data_obj, dict) else {}
    nodes_obj: object = data.get("insertedNodes", data.get("nodes", []))
    nodes: list = nodes_obj if isinstance(nodes_obj, list) else []
    for node in nodes:
        if not isinstance(node, dict):
            continue
        if node.get("type") == expected_type:
            return str(node.get("nodeId", ""))
    if nodes and isinstance(nodes[-1], dict):
        return str(nodes[-1].get("nodeId", ""))

    return ""


def _emu_to_px(emu: object) -> float:
    """EMU → px at 96 DPI. 914400 EMU = 1 inch.

    Accepts Emu/Inches/Pt subclasses (all of which are int) or plain int.
    """
    val: float = float(emu) if not hasattr(emu, "emu") else float(emu.emu)  # type: ignore[union-attr]
    return val / 914400.0 * 96.0
