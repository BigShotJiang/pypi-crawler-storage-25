"""InlineShape / InlineShapes — python-docx image shapes.

Enumerates images in the document via `doc.images.list`. For Phase 1, we
read image metadata (width, height, nodeId, src) but do not round-trip
binary payloads.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from docx._batching import run_sync
from docx.shared import Emu, Length, Pt

if TYPE_CHECKING:
    from docx.client import Session


class InlineShape:
    """An inline image/shape in the document."""

    def __init__(self, *, session: "Session", info: dict) -> None:
        self._session: "Session" = session
        self._info: dict = info

    @property
    def _node_id(self) -> str:
        nid = self._info.get("nodeId") or self._info.get("id")
        return str(nid) if nid else ""

    @property
    def width(self) -> "Length | None":
        size = self._info.get("size") or {}
        if isinstance(size, dict):
            w = size.get("width") or size.get("widthPt")
            if isinstance(w, (int, float)):
                return Pt(float(w))
        return None

    @width.setter
    def width(self, value: "Length | int | None") -> None:
        if value is None:
            return
        pt: float = value.pt if isinstance(value, Length) else float(value) / 12700.0
        h = self.height
        h_pt: float = float(h.pt) if isinstance(h, Length) else 72.0
        run_sync(
            self._session.doc.images.set_size(
                {
                    "nodeId": self._node_id,
                    "widthPt": pt,
                    "heightPt": h_pt,
                },
            ),
        )

    @property
    def height(self) -> "Length | None":
        size = self._info.get("size") or {}
        if isinstance(size, dict):
            h = size.get("height") or size.get("heightPt")
            if isinstance(h, (int, float)):
                return Pt(float(h))
        return None

    @height.setter
    def height(self, value: "Length | int | None") -> None:
        if value is None:
            return
        pt: float = value.pt if isinstance(value, Length) else float(value) / 12700.0
        w = self.width
        w_pt: float = float(w.pt) if isinstance(w, Length) else 72.0
        run_sync(
            self._session.doc.images.set_size(
                {
                    "nodeId": self._node_id,
                    "widthPt": w_pt,
                    "heightPt": pt,
                },
            ),
        )

    @property
    def type(self) -> int:
        # python-docx enum: WD_INLINE_SHAPE.PICTURE = 3. Return PICTURE for all.
        return 3


class InlineShapes:
    """Collection of inline shapes (images) in the document."""

    def __init__(self, *, session: "Session") -> None:
        self._session: "Session" = session

    def _items(self) -> list[dict]:
        info: object = run_sync(self._session.doc.images.list({}))
        if isinstance(info, dict):
            items: object = info.get("items") or info.get("images") or []
            if isinstance(items, list):
                return [i for i in items if isinstance(i, dict)]
        elif isinstance(info, list):
            return [i for i in info if isinstance(i, dict)]
        return []

    def __len__(self) -> int:
        return len(self._items())

    def __iter__(self):
        for info in self._items():
            yield InlineShape(session=self._session, info=info)

    def __getitem__(self, index: int) -> InlineShape:
        return InlineShape(session=self._session, info=self._items()[index])


# python-docx also exposes Shape (non-inline) and Picture; minimal stubs below.
class Shape:
    """Floating/positioned shape — minimal python-docx parity stub."""

    def __init__(self, *, session: "Session", info: dict) -> None:
        self._session: "Session" = session
        self._info: dict = info


class Picture:
    """Picture accessor — mirrors python-docx's InlineShape.picture."""

    def __init__(self, inline_shape: InlineShape) -> None:
        self._inline_shape: InlineShape = inline_shape

    @property
    def image_bytes(self) -> bytes:
        return b""

    @property
    def content_type(self) -> str | None:
        return None

    @property
    def filename(self) -> str | None:
        return None
