"""Run and Font — mirrors python-docx's run.Run and text.font.Font."""

from __future__ import annotations

from typing import TYPE_CHECKING, BinaryIO

from docx._batching import run_sync
from docx.shared import Pt, RGBColor

if TYPE_CHECKING:
    from docx.client import Session


def _block_text(session: "Session", block_id: str) -> str:
    from docx.text.paragraph import _node_text

    return _node_text(session, block_id)


class Run:
    """A text run — a contiguous span with uniform formatting."""

    def __init__(
        self,
        *,
        session: "Session",
        block_id: str,
        range_: tuple[int, int],
        inline: dict | None = None,
    ) -> None:
        self._session: "Session" = session
        self._block_id: str = block_id
        self._range: tuple[int, int] = range_
        # Snapshot of inline marks at construction time (if available).
        self._inline_snapshot: dict = inline or {}

    @property
    def _text_range(self) -> dict:
        return {
            "kind": "text",
            "blockId": self._block_id,
            "range": {"start": self._range[0], "end": self._range[1]},
        }

    # ---- text ----
    @property
    def text(self) -> str:
        full: str = _block_text(self._session, self._block_id)
        return full[self._range[0] : self._range[1]]

    @text.setter
    def text(self, value: str) -> None:
        run_sync(
            self._session.doc.replace(
                {"target": self._text_range, "text": value},
            ),
        )
        new_end: int = self._range[0] + len(value)
        self._range = (self._range[0], new_end)

    def add_text(self, text: str) -> "Run":
        """python-docx: append text to the run. Returns a new Run for the added text."""
        end: int = self._range[1]
        cursor: dict = {"kind": "text", "blockId": self._block_id, "offset": end}
        run_sync(
            self._session.doc.insert(
                {
                    "target": {"kind": "selection", "start": cursor, "end": cursor},
                    "value": text,
                    "type": "text",
                },
            ),
        )
        new_range = (end, end + len(text))
        self._range = (self._range[0], end + len(text))
        return Run(
            session=self._session,
            block_id=self._block_id,
            range_=new_range,
        )

    def add_tab(self) -> None:
        """Insert a tab character at the end of the run."""
        end: int = self._range[1]
        run_sync(
            self._session.doc.insert_tab({"blockId": self._block_id, "offset": end}),
        )
        self._range = (self._range[0], end + 1)

    def add_break(self, break_type: object | None = None) -> None:
        """Insert a break (line or page) at the end of the run.

        python-docx inserts a real Word break element that does not appear
        in the paragraph's `.text` output. We mirror that by using Superdoc
        primitives that don't pollute text content:
          - PAGE → doc.create.sectionBreak(breakType='nextPage')
          - LINE → doc.insertLineBreak (a real Word line-break node)
        """
        from docx.enum.text import WD_BREAK

        end: int = self._range[1]
        is_page: bool = False
        if isinstance(break_type, WD_BREAK) and break_type == WD_BREAK.PAGE:
            is_page = True
        elif isinstance(break_type, str) and break_type.lower() == "page":
            is_page = True
        if is_page:
            run_sync(
                self._session.doc.create.section_break(
                    {"at": {"kind": "documentEnd"}, "breakType": "nextPage"},
                ),
            )
        else:
            run_sync(
                self._session.doc.insert_line_break(
                    {"blockId": self._block_id, "offset": end},
                ),
            )

    def add_picture(
        self,
        image_path_or_stream: str | BinaryIO,
        width: object | None = None,
        height: object | None = None,
    ) -> None:
        """Insert an inline picture at the end of this run."""
        from docx.document import _emu_to_px
        import base64
        import io

        image_bytes: bytes
        content_type: str = "image/png"
        if isinstance(image_path_or_stream, str):
            with open(image_path_or_stream, "rb") as f:
                image_bytes = f.read()
            lower: str = image_path_or_stream.lower()
            if lower.endswith((".jpg", ".jpeg")):
                content_type = "image/jpeg"
            elif lower.endswith(".gif"):
                content_type = "image/gif"
            elif lower.endswith(".webp"):
                content_type = "image/webp"
        elif isinstance(image_path_or_stream, io.IOBase):
            image_bytes = image_path_or_stream.read()
        else:
            raise TypeError(
                "Expected path str or binary stream, "
                f"got {type(image_path_or_stream).__name__}",
            )
        b64: str = base64.b64encode(image_bytes).decode("ascii")
        data_uri: str = f"data:{content_type};base64,{b64}"
        w_px: float = _emu_to_px(width) if width is not None else 576.0
        h_px: float = _emu_to_px(height) if height is not None else 432.0
        run_sync(
            self._session.doc.create.image(
                {
                    "src": data_uri,
                    "size": {"width": w_px, "height": h_px},
                    "at": {"kind": "documentEnd"},
                },
            ),
        )

    def clear(self) -> "Run":
        """Clear the run's text content."""
        self.text = ""
        return self

    # ---- formatting helpers ----
    def _apply_inline(self, **kwargs: object) -> None:
        run_sync(
            self._session.doc.format.apply(
                {"target": self._text_range, "inline": kwargs},
            ),
        )

    def _read_inline_attr(self, key: str) -> object:
        """Read an inline attribute from the snapshot or live node walk."""
        if key in self._inline_snapshot:
            return self._inline_snapshot[key]
        marks: object = self._inline_snapshot.get("marks")
        if isinstance(marks, list):
            for m in marks:
                if isinstance(m, dict) and m.get("type") == key:
                    return True
                if isinstance(m, dict) and isinstance(m.get("attrs"), dict):
                    if key in m["attrs"]:
                        return m["attrs"][key]
        # Live walk: re-fetch paragraph and find this run's inline.
        from docx.text.paragraph import _walk_inlines

        info: object = run_sync(
            self._session.doc.get_node_by_id({"id": self._block_id}),
        )
        inlines: list[dict] = _walk_inlines(info)
        offset: int = 0
        for inline in inlines:
            run_data: object = inline.get("run")
            if isinstance(run_data, dict):
                text: object = run_data.get("text", "")
                length: int = len(text) if isinstance(text, str) else 0
                if offset == self._range[0] and (offset + length) == self._range[1]:
                    if key in run_data:
                        return run_data[key]
                    return None
                offset += length
        return None

    # ---- bold / italic / underline ----
    @property
    def bold(self) -> bool | None:
        v = self._read_inline_attr("bold")
        return bool(v) if isinstance(v, bool) else None

    @bold.setter
    def bold(self, value: bool | None) -> None:
        if value is None:
            return
        self._apply_inline(bold=bool(value))

    @property
    def italic(self) -> bool | None:
        v = self._read_inline_attr("italic")
        return bool(v) if isinstance(v, bool) else None

    @italic.setter
    def italic(self, value: bool | None) -> None:
        if value is None:
            return
        self._apply_inline(italic=bool(value))

    @property
    def underline(self) -> bool | object | None:
        v = self._read_inline_attr("underline")
        if isinstance(v, bool):
            return v
        if isinstance(v, str):
            from docx.enum.text import WD_UNDERLINE

            try:
                return WD_UNDERLINE(v)
            except ValueError:
                return True if v and v != "none" else False
        return None

    @underline.setter
    def underline(self, value: object) -> None:
        from docx.enum.text import WD_UNDERLINE

        if value is None:
            return
        if isinstance(value, bool):
            self._apply_inline(underline=value)
            return
        if isinstance(value, WD_UNDERLINE):
            self._apply_inline(underline=value.value)
            return
        self._apply_inline(underline=value)

    # ---- style ----
    @property
    def style(self) -> str | None:
        v = self._read_inline_attr("rStyle") or self._read_inline_attr("styleId")
        return str(v) if v else None

    @style.setter
    def style(self, value: str | None) -> None:
        if value is None:
            return
        self._apply_inline(rStyle=str(value))

    # ---- font proxy ----
    @property
    def font(self) -> "Font":
        return Font(self)


class Font:
    """Font properties of a Run. Accessed via `run.font`; do not instantiate."""

    def __init__(self, run: Run) -> None:
        self._run: Run = run

    # ---- identity ----
    @property
    def name(self) -> str | None:
        v = self._run._read_inline_attr("fontFamily")
        if not v:
            v = self._run._read_inline_attr("rFonts")
            if isinstance(v, dict):
                return v.get("ascii") or v.get("hAnsi")
            return None
        return str(v) if v else None

    @name.setter
    def name(self, value: str | None) -> None:
        if value is None:
            return
        self._run._apply_inline(fontFamily=str(value))

    @property
    def size(self) -> "Pt | None":
        v = self._run._read_inline_attr("fontSize")
        if isinstance(v, (int, float)):
            return Pt(float(v))
        return None

    @size.setter
    def size(self, value: "Pt | int | None") -> None:
        if value is None:
            return
        pt_value: float = (
            float(value.pt) if hasattr(value, "pt") else float(value)
        )
        self._run._apply_inline(fontSize=pt_value)

    @property
    def color(self) -> "_ColorProxy":
        return _ColorProxy(self._run)

    @property
    def highlight_color(self) -> "object | None":
        from docx.enum.text import WD_COLOR_INDEX

        v = self._run._read_inline_attr("highlight")
        if isinstance(v, str):
            try:
                return WD_COLOR_INDEX(v)
            except ValueError:
                return v
        return None

    @highlight_color.setter
    def highlight_color(self, value: object) -> None:
        from docx.enum.text import WD_COLOR_INDEX

        if value is None:
            return
        val_str: str = value.value if isinstance(value, WD_COLOR_INDEX) else str(value)
        self._run._apply_inline(highlight=val_str)

    # ---- boolean character properties ----
    def _bool_get(self, key: str) -> bool | None:
        v = self._run._read_inline_attr(key)
        return bool(v) if isinstance(v, bool) else None

    def _bool_set(self, key: str, value: bool | None) -> None:
        if value is None:
            return
        self._run._apply_inline(**{key: bool(value)})

    # Mirrored on Run
    @property
    def bold(self) -> bool | None:
        return self._run.bold

    @bold.setter
    def bold(self, value: bool | None) -> None:
        self._run.bold = value

    @property
    def italic(self) -> bool | None:
        return self._run.italic

    @italic.setter
    def italic(self, value: bool | None) -> None:
        self._run.italic = value

    @property
    def underline(self) -> bool | object | None:
        return self._run.underline

    @underline.setter
    def underline(self, value: object) -> None:
        self._run.underline = value

    # strike-through
    @property
    def strike(self) -> bool | None:
        return self._bool_get("strike")

    @strike.setter
    def strike(self, value: bool | None) -> None:
        self._bool_set("strike", value)

    @property
    def double_strike(self) -> bool | None:
        return self._bool_get("dstrike")

    @double_strike.setter
    def double_strike(self, value: bool | None) -> None:
        self._bool_set("dstrike", value)

    @property
    def all_caps(self) -> bool | None:
        return self._bool_get("caps")

    @all_caps.setter
    def all_caps(self, value: bool | None) -> None:
        self._bool_set("caps", value)

    @property
    def small_caps(self) -> bool | None:
        return self._bool_get("smallCaps")

    @small_caps.setter
    def small_caps(self, value: bool | None) -> None:
        self._bool_set("smallCaps", value)

    @property
    def shadow(self) -> bool | None:
        return self._bool_get("shadow")

    @shadow.setter
    def shadow(self, value: bool | None) -> None:
        self._bool_set("shadow", value)

    @property
    def outline(self) -> bool | None:
        return self._bool_get("outline")

    @outline.setter
    def outline(self, value: bool | None) -> None:
        self._bool_set("outline", value)

    @property
    def emboss(self) -> bool | None:
        return self._bool_get("emboss")

    @emboss.setter
    def emboss(self, value: bool | None) -> None:
        self._bool_set("emboss", value)

    @property
    def imprint(self) -> bool | None:
        return self._bool_get("imprint")

    @imprint.setter
    def imprint(self, value: bool | None) -> None:
        self._bool_set("imprint", value)

    @property
    def hidden(self) -> bool | None:
        return self._bool_get("vanish")

    @hidden.setter
    def hidden(self, value: bool | None) -> None:
        self._bool_set("vanish", value)

    @property
    def web_hidden(self) -> bool | None:
        return self._bool_get("webHidden")

    @web_hidden.setter
    def web_hidden(self, value: bool | None) -> None:
        self._bool_set("webHidden", value)

    @property
    def spec_vanish(self) -> bool | None:
        return self._bool_get("specVanish")

    @spec_vanish.setter
    def spec_vanish(self, value: bool | None) -> None:
        self._bool_set("specVanish", value)

    @property
    def rtl(self) -> bool | None:
        return self._bool_get("rtl")

    @rtl.setter
    def rtl(self, value: bool | None) -> None:
        self._bool_set("rtl", value)

    @property
    def cs_bold(self) -> bool | None:
        return self._bool_get("bCs")

    @cs_bold.setter
    def cs_bold(self, value: bool | None) -> None:
        self._bool_set("bCs", value)

    @property
    def cs_italic(self) -> bool | None:
        return self._bool_get("iCs")

    @cs_italic.setter
    def cs_italic(self, value: bool | None) -> None:
        self._bool_set("iCs", value)

    @property
    def complex_script(self) -> bool | None:
        return self._bool_get("cs")

    @complex_script.setter
    def complex_script(self, value: bool | None) -> None:
        self._bool_set("cs", value)

    @property
    def no_proof(self) -> bool | None:
        # python-docx uses proofing flag; map to vanish-like.
        return self._bool_get("noProof")

    @no_proof.setter
    def no_proof(self, value: bool | None) -> None:
        self._bool_set("noProof", value)

    @property
    def snap_to_grid(self) -> bool | None:
        return self._bool_get("snapToGrid")

    @snap_to_grid.setter
    def snap_to_grid(self, value: bool | None) -> None:
        self._bool_set("snapToGrid", value)

    # subscript / superscript — mapped to vertAlign
    @property
    def subscript(self) -> bool | None:
        v = self._run._read_inline_attr("vertAlign")
        if isinstance(v, str):
            return v == "subscript"
        return None

    @subscript.setter
    def subscript(self, value: bool | None) -> None:
        if value is None:
            return
        self._run._apply_inline(vertAlign="subscript" if value else "baseline")

    @property
    def superscript(self) -> bool | None:
        v = self._run._read_inline_attr("vertAlign")
        if isinstance(v, str):
            return v == "superscript"
        return None

    @superscript.setter
    def superscript(self, value: bool | None) -> None:
        if value is None:
            return
        self._run._apply_inline(vertAlign="superscript" if value else "baseline")

    # style
    @property
    def style(self) -> str | None:
        return self._run.style

    @style.setter
    def style(self, value: str | None) -> None:
        self._run.style = value


class _ColorProxy:
    """Matches python-docx's `run.font.color` — has .rgb / .type get/set."""

    def __init__(self, run: Run) -> None:
        self._run: Run = run

    @property
    def rgb(self) -> "RGBColor | None":
        v = self._run._read_inline_attr("color")
        if isinstance(v, str) and len(v) in (6, 7):
            try:
                return RGBColor.from_string(v)
            except ValueError:
                return None
        return None

    @rgb.setter
    def rgb(self, value: "RGBColor | None") -> None:
        if value is None:
            return
        self._run._apply_inline(color=str(value))

    @property
    def type(self) -> None:
        # python-docx: MSO_THEME_COLOR_INDEX / MSO_COLOR_TYPE — not modeled.
        return None
