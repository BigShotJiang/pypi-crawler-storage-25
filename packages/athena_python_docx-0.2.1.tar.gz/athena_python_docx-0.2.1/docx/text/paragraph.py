"""Paragraph — mirrors python-docx's Paragraph class."""

from __future__ import annotations

from typing import TYPE_CHECKING

from docx._batching import run_sync

if TYPE_CHECKING:
    from docx.client import Session
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.text.parfmt import ParagraphFormat
    from docx.text.run import Run


def _node_text(session: "Session", node_id: str) -> str:
    """Fetch a block's full text via doc.get_node_by_id.

    The response shape nests inlines under a node-type key — ``paragraph``
    for paragraphs, ``heading`` for headings:
        {"node": {"paragraph": {"inlines": [{"run": {"text": "..."}}, ...]}}}
    """
    info: object = run_sync(
        session.doc.get_node_by_id({"id": node_id}),
    )
    return _extract_text(info)


def _extract_text(info: object) -> str:
    if not isinstance(info, dict):
        return ""
    node: object = info.get("node")
    if not isinstance(node, dict):
        return ""
    block: object = node.get("paragraph") or node.get("heading")
    if not isinstance(block, dict):
        return ""
    inlines: object = block.get("inlines")
    if not isinstance(inlines, list):
        return ""
    parts: list[str] = []
    for inline in inlines:
        if not isinstance(inline, dict):
            continue
        run: object = inline.get("run")
        if isinstance(run, dict):
            text: object = run.get("text")
            if isinstance(text, str):
                parts.append(text)
            continue
        # Prosemirror-style: {type: "text", text: "..."}
        t: object = inline.get("type")
        if t == "text":
            text2: object = inline.get("text")
            if isinstance(text2, str):
                parts.append(text2)
    return "".join(parts)


def _walk_inlines(info: object) -> list[dict]:
    """Return the inlines array (runs) from a getNodeById paragraph response."""
    if not isinstance(info, dict):
        return []
    node: object = info.get("node")
    if not isinstance(node, dict):
        return []
    block: object = node.get("paragraph") or node.get("heading")
    if not isinstance(block, dict):
        return []
    inlines: object = block.get("inlines")
    if isinstance(inlines, list):
        return [i for i in inlines if isinstance(i, dict)]
    return []


class Paragraph:
    """A paragraph block in a Word document."""

    def __init__(self, *, session: "Session", node_id: str) -> None:
        self._session: "Session" = session
        self._node_id: str = node_id

    @property
    def text(self) -> str:
        """Return the plain-text content of this paragraph."""
        return _node_text(self._session, self._node_id)

    @text.setter
    def text(self, value: str) -> None:
        """Replace the paragraph's text. Preserves the paragraph itself."""
        current: str = _node_text(self._session, self._node_id)
        run_sync(
            self._session.doc.replace(
                {
                    "target": {
                        "kind": "selection",
                        "start": {
                            "kind": "text",
                            "blockId": self._node_id,
                            "offset": 0,
                        },
                        "end": {
                            "kind": "text",
                            "blockId": self._node_id,
                            "offset": len(current),
                        },
                    },
                    "text": value,
                },
            ),
        )

    @property
    def runs(self) -> list["Run"]:
        """Return the runs in this paragraph (in document order)."""
        from docx.text.run import Run

        info: object = run_sync(
            self._session.doc.get_node_by_id({"id": self._node_id}),
        )
        inlines: list[dict] = _walk_inlines(info)
        runs: list["Run"] = []
        offset: int = 0
        for inline in inlines:
            run_data: object = inline.get("run")
            if isinstance(run_data, dict):
                text: object = run_data.get("text")
                if not isinstance(text, str):
                    continue
                start: int = offset
                end: int = offset + len(text)
                offset = end
                runs.append(
                    Run(
                        session=self._session,
                        block_id=self._node_id,
                        range_=(start, end),
                        inline=run_data,
                    ),
                )
                continue
            # Prosemirror-style flat shape
            if inline.get("type") == "text":
                text2: object = inline.get("text")
                if isinstance(text2, str):
                    start = offset
                    end = offset + len(text2)
                    offset = end
                    runs.append(
                        Run(
                            session=self._session,
                            block_id=self._node_id,
                            range_=(start, end),
                            inline=inline,
                        ),
                    )
        return runs

    @property
    def style(self):
        """Return a ParagraphStyle-like object whose .name == styleId.

        For python-docx parity, comparing the returned object to a string
        works via `.name` (not == string), matching stock behavior.
        """
        from docx.styles.style import ParagraphStyle
        from docx.enum.style import WD_STYLE_TYPE

        info: object = run_sync(
            self._session.doc.get_node_by_id({"id": self._node_id}),
        )
        if not isinstance(info, dict):
            return None
        node: object = info.get("node")
        if not isinstance(node, dict):
            return None
        style_id: object = node.get("styleId") or node.get("style")
        if not style_id:
            return None
        return ParagraphStyle(
            name=str(style_id),
            style_type=WD_STYLE_TYPE.PARAGRAPH,
            session=self._session,
        )

    @style.setter
    def style(self, value) -> None:
        """Set paragraph style. Accepts a style name or a style object."""
        style_id: str
        if value is None:
            style_id = "Normal"
        elif isinstance(value, str):
            style_id = value
        elif hasattr(value, "name"):
            style_id = str(value.name)
        else:
            style_id = str(value)
        run_sync(
            self._session.doc.styles.paragraph.set_style(
                {
                    "target": self._block_target(),
                    "styleId": style_id,
                },
            ),
        )

    @property
    def alignment(self) -> "WD_ALIGN_PARAGRAPH | None":
        from docx.enum.text import WD_ALIGN_PARAGRAPH

        info: object = run_sync(
            self._session.doc.get_node_by_id({"id": self._node_id}),
        )
        if not isinstance(info, dict):
            return None
        node: object = info.get("node")
        if not isinstance(node, dict):
            return None
        block: object = node.get("paragraph") or node.get("heading")
        if isinstance(block, dict):
            raw: object = (
                block.get("alignment")
                or (block.get("attrs", {}) or {}).get("textAlign")
            )
            if isinstance(raw, str) and raw:
                return WD_ALIGN_PARAGRAPH.from_superdoc(raw)
        return None

    @alignment.setter
    def alignment(self, value: "WD_ALIGN_PARAGRAPH | str | None") -> None:
        from docx.enum.text import WD_ALIGN_PARAGRAPH

        if value is None:
            run_sync(
                self._session.doc.format.paragraph.clear_alignment(
                    {"target": self._block_target()},
                ),
            )
            return
        if isinstance(value, WD_ALIGN_PARAGRAPH):
            alignment_str: str = value.to_superdoc()
        else:
            alignment_str = str(value).lower()
        run_sync(
            self._session.doc.format.paragraph.set_alignment(
                {
                    "target": self._block_target(),
                    "alignment": alignment_str,
                },
            ),
        )

    @property
    def paragraph_format(self) -> "ParagraphFormat":
        from docx.text.parfmt import ParagraphFormat

        return ParagraphFormat(self)

    @property
    def hyperlinks(self) -> list:
        """Return the hyperlinks in this paragraph.

        python-docx 1.x exposes Hyperlink objects; we walk inlines for runs
        with a hyperlink mark and return a list of Hyperlink proxies.
        """
        from docx.text.hyperlink import Hyperlink

        info: object = run_sync(
            self._session.doc.get_node_by_id({"id": self._node_id}),
        )
        out: list[Hyperlink] = []
        for inline in _walk_inlines(info):
            run_data = inline.get("run")
            target: str | None = None
            if isinstance(run_data, dict):
                hl = run_data.get("hyperlink") or run_data.get("href")
                if isinstance(hl, str) and hl:
                    target = hl
                elif isinstance(hl, dict):
                    maybe = hl.get("url") or hl.get("target")
                    if isinstance(maybe, str):
                        target = maybe
            if target:
                out.append(Hyperlink(paragraph=self, target=target, run=run_data if isinstance(run_data, dict) else None))
        return out

    @property
    def contains_page_break(self) -> bool:
        """python-docx 1.x: True if the paragraph contains a hard page break."""
        return "\f" in self.text

    def _block_target(self) -> dict:
        """Build a {kind, nodeType, nodeId} target for paragraph-level ops."""
        info: object = run_sync(
            self._session.doc.get_node_by_id({"id": self._node_id}),
        )
        node_type: str = "paragraph"
        if isinstance(info, dict):
            node_obj: object = info.get("node")
            if isinstance(node_obj, dict):
                raw: object = node_obj.get("nodeType")
                if isinstance(raw, str) and raw:
                    node_type = raw
        return {
            "kind": "block",
            "nodeType": node_type,
            "nodeId": self._node_id,
        }

    def add_run(
        self,
        text: str = "",
        style: str | None = None,
    ) -> "Run":
        """Append a run to this paragraph."""
        from docx.text.run import Run

        current: str = _node_text(self._session, self._node_id)
        start: int = len(current)

        if text:
            cursor: dict = {
                "kind": "text",
                "blockId": self._node_id,
                "offset": start,
            }
            run_sync(
                self._session.doc.insert(
                    {
                        "target": {
                            "kind": "selection",
                            "start": cursor,
                            "end": cursor,
                        },
                        "value": text,
                        "type": "text",
                    },
                ),
            )
        run_obj: "Run" = Run(
            session=self._session,
            block_id=self._node_id,
            range_=(start, start + len(text)),
        )
        if style:
            # Apply the run's character style.
            try:
                run_obj.style = style
            except Exception:
                pass
        return run_obj

    def clear(self) -> "Paragraph":
        """Clear the paragraph's text content."""
        self.text = ""
        return self

    def insert_paragraph_before(
        self,
        text: str | None = None,
        style: str | None = None,
    ) -> "Paragraph":
        """Insert a new paragraph directly before this one."""
        result: object = run_sync(
            self._session.doc.create.paragraph(
                {
                    "text": text or "",
                    "at": {"kind": "before", "target": self._block_target()},
                },
            ),
        )
        from docx.document import _extract_inserted_node_id

        if isinstance(result, dict):
            node_id: str = _extract_inserted_node_id(
                result, expected_type="paragraph",
            )
        else:
            node_id = ""
        if not node_id:
            raise RuntimeError(
                f"Superdoc did not return nodeId for insert_paragraph_before: {result!r}",
            )
        new_para = Paragraph(session=self._session, node_id=node_id)
        if style:
            new_para.style = style
        return new_para
