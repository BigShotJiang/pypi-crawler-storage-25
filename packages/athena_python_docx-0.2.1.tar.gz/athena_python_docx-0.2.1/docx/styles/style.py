"""Style classes — python-docx docx.styles.style parity."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from docx.client import Session
    from docx.enum.style import WD_STYLE_TYPE


class BaseStyle:
    """Base for all style kinds. Matches python-docx.styles.style.BaseStyle."""

    def __init__(self, *, name: str, style_type: "WD_STYLE_TYPE", session: "Session | None" = None) -> None:
        self._name: str = name
        self._type: "WD_STYLE_TYPE" = style_type
        self._session: "Session | None" = session

    @property
    def name(self) -> str:
        return self._name

    @property
    def style_id(self) -> str:
        return self._name

    @property
    def type(self) -> "WD_STYLE_TYPE":
        return self._type

    @property
    def hidden(self) -> bool:
        return False

    @property
    def quick_style(self) -> bool:
        return False

    @property
    def priority(self) -> int | None:
        return None

    @property
    def unhide_when_used(self) -> bool:
        return False

    def delete(self) -> None:
        return None


class CharacterStyle(BaseStyle):
    @property
    def base_style(self) -> "CharacterStyle | None":
        return None

    @property
    def font(self):
        return None


class ParagraphStyle(CharacterStyle):
    @property
    def paragraph_format(self):
        return None

    @property
    def next_paragraph_style(self) -> "ParagraphStyle | None":
        return None


class TableStyle(ParagraphStyle):
    pass


class _NumberingStyle(BaseStyle):
    pass
