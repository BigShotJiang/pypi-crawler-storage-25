"""Table, _Row, _Column, _Cell — python-docx parity."""

from __future__ import annotations

import sys
from typing import TYPE_CHECKING

from docx._batching import run_sync
from docx.errors import ValidationError
from docx.shared import Length, Pt

if TYPE_CHECKING:
    from docx.client import Session
    from docx.enum.table import (
        WD_ALIGN_VERTICAL,
        WD_ROW_HEIGHT_RULE,
        WD_TABLE_ALIGNMENT,
        WD_TABLE_DIRECTION,
    )
    from docx.text.paragraph import Paragraph


def _log_warn(msg: str) -> None:
    print(f"[docx-sdk] WARN: {msg}", file=sys.stderr)


def _find_first_paragraph_id(obj: object) -> str:
    """Walk a getNodeById result to find the first paragraph nodeId."""
    if isinstance(obj, dict):
        t: object = obj.get("type")
        if isinstance(t, str) and t in ("paragraph", "heading"):
            attrs: object = obj.get("attrs")
            if isinstance(attrs, dict):
                nid: object = attrs.get("nodeId") or attrs.get("id")
                if isinstance(nid, str) and nid:
                    return nid
            top_nid: object = obj.get("nodeId")
            if isinstance(top_nid, str) and top_nid:
                return top_nid
        for key in ("paragraph", "heading"):
            if key in obj and isinstance(obj[key], dict):
                nid_o: object = obj.get("nodeId")
                if isinstance(nid_o, str) and nid_o:
                    return nid_o
                inner = _find_first_paragraph_id(obj[key])
                if inner:
                    return inner
        for v in obj.values():
            found: str = _find_first_paragraph_id(v)
            if found:
                return found
    elif isinstance(obj, list):
        for item in obj:
            found = _find_first_paragraph_id(item)
            if found:
                return found
    return ""


def _collect_paragraph_ids(obj: object, out: list[str]) -> None:
    """Walk a node tree and collect all paragraph/heading nodeIds in order.

    Tolerates several shapes that Superdoc has emitted over versions:
      - prosemirror-style: {"type": "paragraph", "attrs": {"nodeId": ...}}
      - typed-wrapper:     {"paragraph": {...}, "nodeId": "..."}
      - flat-address:      {"kind": "block", "nodeType": "paragraph", "nodeId": ...}
      - block-list shape:  {"nodeType": "paragraph", "nodeId": ...}
    """
    seen: set[str] = set(out)

    def _add(nid: object) -> None:
        if isinstance(nid, str) and nid and nid not in seen:
            seen.add(nid)
            out.append(nid)

    if isinstance(obj, dict):
        # Prosemirror-style
        t: object = obj.get("type")
        if isinstance(t, str) and t in ("paragraph", "heading"):
            attrs: object = obj.get("attrs")
            if isinstance(attrs, dict):
                _add(attrs.get("nodeId") or attrs.get("id"))
            _add(obj.get("nodeId"))
            _add(obj.get("id"))
        # Flat-address / block-list
        node_type: object = obj.get("nodeType")
        if isinstance(node_type, str) and node_type in ("paragraph", "heading"):
            _add(obj.get("nodeId"))
        # Typed-wrapper
        for key in ("paragraph", "heading"):
            if key in obj and isinstance(obj[key], dict):
                _add(obj.get("nodeId"))
                inner = obj[key]
                if isinstance(inner, dict):
                    _add(inner.get("nodeId"))
        # Recurse
        for v in obj.values():
            _collect_paragraph_ids(v, out)
    elif isinstance(obj, list):
        for item in obj:
            _collect_paragraph_ids(item, out)


class Table:
    def __init__(self, *, session: "Session", node_id: str) -> None:
        self._session: "Session" = session
        self._node_id: str = node_id

    def _fresh_node_id(self) -> str:
        """Return the live nodeId. Verifies it still exists; only falls back
        to the last-seen table if our specific id truly can't be located.

        We first try doc.tables.get — that accepts any table (incl. nested),
        unlike doc.find which only enumerates top-level tables.
        """
        # Fast-path: ask for this table directly. If the server finds it,
        # we're done — no rotation needed.
        try:
            info: object = run_sync(
                self._session.doc.tables.get({"nodeId": self._node_id}),
            )
            if isinstance(info, dict) and info.get("nodeId") == self._node_id:
                return self._node_id
            # Some fakes don't echo nodeId; treat a non-error response as OK.
            if isinstance(info, dict) and info:
                return self._node_id
        except Exception:
            pass
        # Fallback: scan top-level tables via doc.find.
        find_result: object = run_sync(
            self._session.doc.find({"type": "table"}),
        )
        items_obj: object = (
            find_result.get("items", []) if isinstance(find_result, dict) else []
        )
        items: list = items_obj if isinstance(items_obj, list) else []
        for item in items:
            if not isinstance(item, dict):
                continue
            addr = item.get("address", {})
            if isinstance(addr, dict) and addr.get("nodeId") == self._node_id:
                return self._node_id
        if items:
            last = items[-1] if isinstance(items[-1], dict) else {}
            last_addr = last.get("address", {}) if isinstance(last, dict) else {}
            new_id: str = str(last_addr.get("nodeId", ""))
            if new_id and new_id != self._node_id:
                _log_warn(
                    f"table nodeId rotated: {self._node_id} -> {new_id}",
                )
                self._node_id = new_id
        return self._node_id

    def _address(self) -> dict:
        return {"kind": "block", "nodeType": "table", "nodeId": self._fresh_node_id()}

    @property
    def rows(self) -> list["_Row"]:
        nid: str = self._fresh_node_id()
        info: object = run_sync(self._session.doc.tables.get({"nodeId": nid}))
        info_dict: dict = info if isinstance(info, dict) else {}
        row_count: int = int(
            info_dict.get("rows")
            or info_dict.get("rowCount")
            or (info_dict.get("table", {}) or {}).get("rows")
            or 0,
        )
        return [_Row(table=self, index=i) for i in range(row_count)]

    @property
    def columns(self) -> list["_Column"]:
        nid: str = self._fresh_node_id()
        info: object = run_sync(self._session.doc.tables.get({"nodeId": nid}))
        info_dict: dict = info if isinstance(info, dict) else {}
        col_count: int = int(
            info_dict.get("columns")
            or info_dict.get("cols")
            or info_dict.get("columnCount")
            or (info_dict.get("table", {}) or {}).get("columns")
            or 0,
        )
        return [_Column(table=self, index=j) for j in range(col_count)]

    def cell(self, row_idx: int, col_idx: int) -> "_Cell":
        return _Cell(table=self, row=row_idx, col=col_idx)

    def add_row(self) -> "_Row":
        nid: str = self._fresh_node_id()
        row_count: int = len(self.rows)
        if row_count < 1:
            raise ValidationError(f"Cannot add row to empty table {nid}")
        run_sync(
            self._session.doc.tables.insert_row(
                {
                    "nodeId": nid,
                    "rowIndex": row_count - 1,
                    "position": "below",
                    "count": 1,
                },
            ),
        )
        return _Row(table=self, index=row_count)

    def add_column(self, width: "Length | int | None" = None) -> "_Column":
        nid: str = self._fresh_node_id()
        col_count: int = len(self.columns)
        if col_count < 1:
            raise ValidationError(f"Cannot add column to empty table {nid}")
        run_sync(
            self._session.doc.tables.insert_column(
                {
                    "nodeId": nid,
                    "columnIndex": col_count - 1,
                    "position": "right",
                    "count": 1,
                },
            ),
        )
        new_col = _Column(table=self, index=col_count)
        if width is not None:
            new_col.width = width
        return new_col

    @property
    def style(self) -> str | None:
        info: object = run_sync(
            self._session.doc.tables.get_properties({"nodeId": self._fresh_node_id()}),
        )
        if isinstance(info, dict):
            sid: object = info.get("styleId")
            if isinstance(sid, str) and sid:
                return sid
        return None

    @style.setter
    def style(self, value: str | None) -> None:
        nid: str = self._fresh_node_id()
        run_sync(
            self._session.doc.tables.set_style(
                {"nodeId": nid, "styleId": value or "TableGrid"},
            ),
        )

    @property
    def alignment(self) -> "WD_TABLE_ALIGNMENT | None":
        from docx.enum.table import WD_TABLE_ALIGNMENT

        info: object = run_sync(
            self._session.doc.tables.get_properties({"nodeId": self._fresh_node_id()}),
        )
        if isinstance(info, dict):
            a: object = info.get("alignment")
            if isinstance(a, str):
                for member in WD_TABLE_ALIGNMENT:
                    if member.value == a:
                        return member
        return None

    @alignment.setter
    def alignment(self, value: "WD_TABLE_ALIGNMENT | str | None") -> None:
        from docx.enum.table import WD_TABLE_ALIGNMENT

        if value is None:
            return
        v: str = (
            value.to_superdoc()
            if isinstance(value, WD_TABLE_ALIGNMENT)
            else str(value).lower()
        )
        run_sync(
            self._session.doc.tables.set_table_options(
                {"nodeId": self._fresh_node_id(), "alignment": v},
            ),
        )

    @property
    def direction(self) -> "WD_TABLE_DIRECTION | None":
        from docx.enum.table import WD_TABLE_DIRECTION

        info: object = run_sync(
            self._session.doc.tables.get_properties({"nodeId": self._fresh_node_id()}),
        )
        if isinstance(info, dict):
            d: object = info.get("direction")
            if isinstance(d, str):
                for member in WD_TABLE_DIRECTION:
                    if member.value == d:
                        return member
        return None

    @direction.setter
    def direction(self, value: "WD_TABLE_DIRECTION | str | None") -> None:
        from docx.enum.table import WD_TABLE_DIRECTION

        if value is None:
            return
        v: str = (
            value.to_superdoc()
            if isinstance(value, WD_TABLE_DIRECTION)
            else str(value).lower()
        )
        run_sync(
            self._session.doc.tables.set_table_options(
                {"nodeId": self._fresh_node_id(), "direction": v},
            ),
        )

    # python-docx aliases
    table_direction = direction

    @property
    def autofit(self) -> bool | None:
        info: object = run_sync(
            self._session.doc.tables.get_properties({"nodeId": self._fresh_node_id()}),
        )
        if isinstance(info, dict):
            mode: object = info.get("autoFitMode")
            if isinstance(mode, str):
                return mode != "fixedWidth"
        return None

    @autofit.setter
    def autofit(self, value: bool | None) -> None:
        if value is None:
            return
        run_sync(
            self._session.doc.tables.set_layout(
                {
                    "nodeId": self._fresh_node_id(),
                    "autoFit": "fitContents" if value else "fixedWidth",
                },
            ),
        )

    allow_autofit = autofit

    @property
    def _cells(self) -> list["_Cell"]:
        """Flat list of cells in row-major order."""
        out: list[_Cell] = []
        for r in self.rows:
            out.extend(r.cells)
        return out


class _Row:
    def __init__(self, *, table: Table, index: int) -> None:
        self._table: Table = table
        self._index: int = index

    @property
    def cells(self) -> list["_Cell"]:
        col_count: int = len(self._table.columns)
        return [
            _Cell(table=self._table, row=self._index, col=j)
            for j in range(col_count)
        ]

    @property
    def table(self) -> Table:
        return self._table

    @property
    def height(self) -> "Length | None":
        nid = self._table._fresh_node_id()
        info: object = run_sync(
            self._table._session.doc.tables.get({"nodeId": nid}),
        )
        if isinstance(info, dict):
            rows: object = info.get("rowInfo") or info.get("rowsInfo")
            if isinstance(rows, list) and 0 <= self._index < len(rows):
                entry = rows[self._index]
                if isinstance(entry, dict):
                    h: object = entry.get("heightPt")
                    if isinstance(h, (int, float)):
                        return Pt(float(h))
        return None

    @height.setter
    def height(self, value: "Length | int | None") -> None:
        if value is None:
            return
        pt: float = value.pt if isinstance(value, Length) else float(value) / 12700.0
        run_sync(
            self._table._session.doc.tables.set_row_height(
                {
                    "nodeId": self._table._fresh_node_id(),
                    "rowIndex": self._index,
                    "heightPt": pt,
                    "rule": "atLeast",
                },
            ),
        )

    @property
    def height_rule(self) -> "WD_ROW_HEIGHT_RULE | None":
        from docx.enum.table import WD_ROW_HEIGHT_RULE

        nid = self._table._fresh_node_id()
        info: object = run_sync(
            self._table._session.doc.tables.get({"nodeId": nid}),
        )
        if isinstance(info, dict):
            rows: object = info.get("rowInfo") or info.get("rowsInfo")
            if isinstance(rows, list) and 0 <= self._index < len(rows):
                entry = rows[self._index]
                if isinstance(entry, dict):
                    r: object = entry.get("rule")
                    if isinstance(r, str):
                        for member in WD_ROW_HEIGHT_RULE:
                            if member.value == r:
                                return member
        return None

    @height_rule.setter
    def height_rule(self, value: "WD_ROW_HEIGHT_RULE | str | None") -> None:
        from docx.enum.table import WD_ROW_HEIGHT_RULE

        if value is None:
            return
        rule: str = (
            value.to_superdoc()
            if isinstance(value, WD_ROW_HEIGHT_RULE)
            else str(value)
        )
        h = self.height
        h_pt: float = float(h.pt) if isinstance(h, Length) else 12.0
        run_sync(
            self._table._session.doc.tables.set_row_height(
                {
                    "nodeId": self._table._fresh_node_id(),
                    "rowIndex": self._index,
                    "heightPt": h_pt,
                    "rule": rule,
                },
            ),
        )


class _Column:
    def __init__(self, *, table: Table, index: int) -> None:
        self._table: Table = table
        self._index: int = index

    @property
    def cells(self) -> list["_Cell"]:
        row_count: int = len(self._table.rows)
        return [
            _Cell(table=self._table, row=i, col=self._index)
            for i in range(row_count)
        ]

    @property
    def table(self) -> Table:
        return self._table

    @property
    def width(self) -> "Length | None":
        nid = self._table._fresh_node_id()
        info: object = run_sync(
            self._table._session.doc.tables.get({"nodeId": nid}),
        )
        if isinstance(info, dict):
            cols: object = info.get("columnInfo") or info.get("columnsInfo")
            if isinstance(cols, list) and 0 <= self._index < len(cols):
                entry = cols[self._index]
                if isinstance(entry, dict):
                    w: object = entry.get("widthPt")
                    if isinstance(w, (int, float)):
                        return Pt(float(w))
        return None

    @width.setter
    def width(self, value: "Length | int | None") -> None:
        if value is None:
            return
        pt: float = value.pt if isinstance(value, Length) else float(value) / 12700.0
        run_sync(
            self._table._session.doc.tables.set_column_width(
                {
                    "nodeId": self._table._fresh_node_id(),
                    "columnIndex": self._index,
                    "widthPt": pt,
                },
            ),
        )


class _Cell:
    def __init__(self, *, table: Table, row: int, col: int) -> None:
        self._table: Table = table
        self._row: int = row
        self._col: int = col

    def _cell_info(self) -> dict | None:
        nid: str = self._table._fresh_node_id()
        result: object = run_sync(
            self._table._session.doc.tables.get_cells(
                {
                    "nodeId": nid,
                    "rowIndex": self._row,
                    "columnIndex": self._col,
                },
            ),
        )
        if not isinstance(result, dict):
            return None
        cells_obj: object = result.get("cells", result.get("items", []))
        cells: list = cells_obj if isinstance(cells_obj, list) else []
        if not cells or not isinstance(cells[0], dict):
            return None
        return cells[0]

    def _cell_id(self) -> str:
        info = self._cell_info()
        if info is None:
            raise ValidationError(
                f"Cell ({self._row}, {self._col}) not found in "
                f"table {self._table._fresh_node_id()}",
            )
        nid: object = info.get("nodeId")
        if not isinstance(nid, str) or not nid:
            raise ValidationError(
                f"Cell ({self._row}, {self._col}) has no nodeId",
            )
        return nid

    def _cell_address(self) -> dict:
        return {"kind": "block", "nodeType": "tableCell", "nodeId": self._cell_id()}

    def _inner_paragraph_ids(self) -> list[str]:
        """Locate the paragraph nodeIds inside this cell, trying multiple
        Superdoc response shapes.

        Strategies (in order):
          1. doc.getNodeById with explicit nodeType=tableCell
          2. doc.getNodeById with just {id: ...}
          3. doc.getNode with target=tableCell address
          4. doc.blocks.list filtered to paragraph/heading + location match
        """
        cell_id = self._cell_id()
        session = self._table._session
        ids: list[str] = []

        # Strategy 1: with explicit nodeType
        try:
            info = run_sync(
                session.doc.get_node_by_id(
                    {"id": cell_id, "nodeType": "tableCell"},
                ),
            )
            _collect_paragraph_ids(info, ids)
            if ids:
                return ids
        except Exception:
            pass

        # Strategy 2: without nodeType (some sdk versions expect only id)
        try:
            info = run_sync(session.doc.get_node_by_id({"id": cell_id}))
            _collect_paragraph_ids(info, ids)
            if ids:
                return ids
        except Exception:
            pass

        # Strategy 3: doc.getNode with target address
        try:
            info = run_sync(
                session.doc.get_node(
                    {
                        "target": {
                            "kind": "block",
                            "nodeType": "tableCell",
                            "nodeId": cell_id,
                        },
                    },
                ),
            )
            _collect_paragraph_ids(info, ids)
            if ids:
                return ids
        except Exception:
            pass

        return ids

    @property
    def text(self) -> str:
        """Return the combined text of direct-child paragraphs in the cell.

        Mirrors python-docx's `_Cell.text`, which is:
            "\\n".join(p.text for p in self.paragraphs)

        Note: this is NOT recursive — nested-table content is not included
        (stock python-docx's _Cell.text has that same shallow semantic).
        """
        from docx.text.paragraph import _node_text

        ids = self._inner_paragraph_ids()
        if ids:
            return "\n".join(_node_text(self._table._session, pid) for pid in ids)
        info = self._cell_info()
        if info is not None:
            t: object = info.get("text")
            if isinstance(t, str):
                return t
        return ""

    @text.setter
    def text(self, value: str) -> None:
        """Set the cell's text content.

        Tries three strategies in order:
          1. Text-range replace on the inner paragraph (fastest, preserves
             paragraph-level formatting like alignment, style).
          2. Structural replace of the tableCell with a markdown-derived
             fragment via doc.markdownToFragment → doc.replace.
          3. Structural replace of the tableCell with a hand-built
             prosemirror paragraph fragment as last resort.
        """
        from docx.text.paragraph import _node_text

        cell_id = self._cell_id()
        session = self._table._session

        # --- Strategy 1: inner paragraph + text-range replace ---
        ids = self._inner_paragraph_ids()
        if ids:
            first = ids[0]
            current = _node_text(session, first)
            try:
                run_sync(
                    session.doc.replace(
                        {
                            "target": {
                                "kind": "selection",
                                "start": {
                                    "kind": "text",
                                    "blockId": first,
                                    "offset": 0,
                                },
                                "end": {
                                    "kind": "text",
                                    "blockId": first,
                                    "offset": len(current),
                                },
                            },
                            "text": value,
                        },
                    ),
                )
                for extra in ids[1:]:
                    existing = _node_text(session, extra)
                    if existing:
                        run_sync(
                            session.doc.replace(
                                {
                                    "target": {
                                        "kind": "selection",
                                        "start": {
                                            "kind": "text",
                                            "blockId": extra,
                                            "offset": 0,
                                        },
                                        "end": {
                                            "kind": "text",
                                            "blockId": extra,
                                            "offset": len(existing),
                                        },
                                    },
                                    "text": "",
                                },
                            ),
                        )
                return
            except Exception as e:
                _log_warn(
                    f"_Cell.text text-range replace failed on paragraph "
                    f"{first}: {e!r}; falling back to structural replace.",
                )

        # --- Strategy 2: markdownToFragment + structural replace ---
        cell_target: dict = {
            "kind": "block",
            "nodeType": "tableCell",
            "nodeId": cell_id,
        }
        try:
            frag_result: object = run_sync(
                session.doc.markdown_to_fragment({"markdown": value or ""}),
            )
            fragment: object = None
            if isinstance(frag_result, dict):
                fragment = frag_result.get("fragment")
            if fragment is not None:
                run_sync(
                    session.doc.replace(
                        {"target": cell_target, "content": fragment},
                    ),
                )
                return
        except Exception as e:
            _log_warn(
                f"_Cell.text markdownToFragment/replace failed: {e!r}; "
                f"falling back to prosemirror fragment.",
            )

        # --- Strategy 3: hand-built prosemirror paragraph fragment ---
        pm_fragment: dict = {
            "type": "paragraph",
            "content": [{"type": "text", "text": value}] if value else [],
        }
        try:
            run_sync(
                session.doc.replace(
                    {"target": cell_target, "content": pm_fragment},
                ),
            )
            return
        except Exception as e:
            raise RuntimeError(
                f"Failed to set _Cell.text on cell ({self._row}, {self._col}) "
                f"of table {self._table._fresh_node_id()}: all three strategies "
                f"failed. Last error: {e!r}",
            ) from e

    @property
    def paragraphs(self) -> list["Paragraph"]:
        from docx.text.paragraph import Paragraph

        return [
            Paragraph(session=self._table._session, node_id=pid)
            for pid in self._inner_paragraph_ids()
        ]

    @property
    def tables(self) -> list[Table]:
        cell_id = self._cell_id()
        info: object = run_sync(
            self._table._session.doc.get_node_by_id(
                {"id": cell_id, "nodeType": "tableCell"},
            ),
        )
        nested: list[Table] = []

        def walk(obj: object) -> None:
            if isinstance(obj, dict):
                t = obj.get("type") or obj.get("nodeType")
                if t == "table":
                    nid = obj.get("nodeId") or (
                        obj.get("attrs", {}).get("nodeId")
                        if isinstance(obj.get("attrs"), dict)
                        else None
                    )
                    if isinstance(nid, str) and nid:
                        nested.append(Table(session=self._table._session, node_id=nid))
                for v in obj.values():
                    walk(v)
            elif isinstance(obj, list):
                for item in obj:
                    walk(item)

        walk(info)
        return nested

    def add_paragraph(
        self,
        text: str = "",
        style: str | None = None,
    ) -> "Paragraph":
        """Append a paragraph to the cell."""
        from docx.document import _extract_inserted_node_id
        from docx.text.paragraph import Paragraph

        ids = self._inner_paragraph_ids()
        if ids:
            anchor = {
                "kind": "after",
                "target": {
                    "kind": "block",
                    "nodeType": "paragraph",
                    "nodeId": ids[-1],
                },
            }
        else:
            # No paragraphs yet — create one inside the cell (sibling of cell
            # is invalid; fall back to documentEnd and accept degraded placement).
            anchor = {"kind": "documentEnd"}

        result: object = run_sync(
            self._table._session.doc.create.paragraph(
                {"text": text, "at": anchor},
            ),
        )
        if isinstance(result, dict):
            node_id: str = _extract_inserted_node_id(
                result, expected_type="paragraph",
            )
        else:
            node_id = ""
        if not node_id:
            raise RuntimeError(
                f"Superdoc did not return nodeId for _Cell.add_paragraph: {result!r}",
            )
        para = Paragraph(session=self._table._session, node_id=node_id)
        if style:
            para.style = style
        return para

    def add_table(self, rows: int, cols: int, style: str | None = None) -> Table:
        """Append a nested table inside the cell."""
        from docx.document import _extract_inserted_node_id

        if rows < 1 or cols < 1:
            raise ValidationError(f"rows/cols must be >=1; got {rows}/{cols}")
        # We can target the cell's last paragraph as an anchor.
        ids = self._inner_paragraph_ids()
        if ids:
            anchor = {
                "kind": "after",
                "target": {
                    "kind": "block",
                    "nodeType": "paragraph",
                    "nodeId": ids[-1],
                },
            }
        else:
            anchor = {"kind": "documentEnd"}
        result: object = run_sync(
            self._table._session.doc.create.table(
                {"rows": rows, "columns": cols, "at": anchor},
            ),
        )
        node_id: str = _extract_inserted_node_id(result, expected_type="table") if isinstance(result, dict) else ""
        if not node_id:
            raise RuntimeError(
                f"Superdoc did not return nodeId for nested table: {result!r}",
            )
        t = Table(session=self._table._session, node_id=node_id)
        if style:
            t.style = style
        return t

    def merge(self, other: "_Cell") -> "_Cell":
        if other._table is not self._table:
            raise ValidationError(
                "Cannot merge cells from different tables.",
            )
        nid: str = self._table._fresh_node_id()
        run_sync(
            self._table._session.doc.tables.merge_cells(
                {
                    "nodeId": nid,
                    "start": {"rowIndex": self._row, "columnIndex": self._col},
                    "end": {"rowIndex": other._row, "columnIndex": other._col},
                },
            ),
        )
        return self

    @property
    def vertical_alignment(self) -> "WD_ALIGN_VERTICAL | None":
        from docx.enum.table import WD_ALIGN_VERTICAL

        info = self._cell_info()
        if info and isinstance(info, dict):
            va = info.get("verticalAlign")
            if isinstance(va, str):
                for m in WD_ALIGN_VERTICAL:
                    if m.value == va:
                        return m
        return None

    @vertical_alignment.setter
    def vertical_alignment(self, value: "WD_ALIGN_VERTICAL | str | None") -> None:
        from docx.enum.table import WD_ALIGN_VERTICAL

        if value is None:
            return
        v: str = (
            value.to_superdoc()
            if isinstance(value, WD_ALIGN_VERTICAL)
            else str(value).lower()
        )
        run_sync(
            self._table._session.doc.tables.set_cell_properties(
                {"target": self._cell_address(), "verticalAlign": v},
            ),
        )

    @property
    def width(self) -> "Length | None":
        info = self._cell_info()
        if info and isinstance(info, dict):
            w = info.get("preferredWidthPt") or info.get("widthPt")
            if isinstance(w, (int, float)):
                return Pt(float(w))
        return None

    @width.setter
    def width(self, value: "Length | int | None") -> None:
        if value is None:
            return
        pt: float = value.pt if isinstance(value, Length) else float(value) / 12700.0
        run_sync(
            self._table._session.doc.tables.set_cell_properties(
                {"target": self._cell_address(), "preferredWidthPt": pt},
            ),
        )

    @property
    def height(self) -> "Length | None":
        # python-docx: Cell has no 'height' directly; row does. Return the row's height.
        row = _Row(table=self._table, index=self._row)
        return row.height

    @height.setter
    def height(self, value: "Length | int | None") -> None:
        row = _Row(table=self._table, index=self._row)
        row.height = value
