"""CoreProperties — python-docx docx.opc.coreprops.CoreProperties parity.

Superdoc doesn't surface most core document properties (author, title,
modified, etc.). We expose the attributes with defaults so code that
reads them doesn't raise.
"""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from docx.client import Session


class CoreProperties:
    def __init__(self, *, session: "Session") -> None:
        self._session: "Session" = session
        self._cache: dict[str, object] = {}

    @property
    def author(self) -> str:
        return str(self._cache.get("author", ""))

    @author.setter
    def author(self, value: str) -> None:
        self._cache["author"] = value

    @property
    def category(self) -> str:
        return str(self._cache.get("category", ""))

    @category.setter
    def category(self, value: str) -> None:
        self._cache["category"] = value

    @property
    def comments(self) -> str:
        return str(self._cache.get("comments", ""))

    @comments.setter
    def comments(self, value: str) -> None:
        self._cache["comments"] = value

    @property
    def content_status(self) -> str:
        return str(self._cache.get("content_status", ""))

    @content_status.setter
    def content_status(self, value: str) -> None:
        self._cache["content_status"] = value

    @property
    def created(self) -> datetime | None:
        v = self._cache.get("created")
        return v if isinstance(v, datetime) else None

    @created.setter
    def created(self, value: datetime | None) -> None:
        self._cache["created"] = value

    @property
    def identifier(self) -> str:
        return str(self._cache.get("identifier", ""))

    @identifier.setter
    def identifier(self, value: str) -> None:
        self._cache["identifier"] = value

    @property
    def keywords(self) -> str:
        return str(self._cache.get("keywords", ""))

    @keywords.setter
    def keywords(self, value: str) -> None:
        self._cache["keywords"] = value

    @property
    def language(self) -> str:
        return str(self._cache.get("language", ""))

    @language.setter
    def language(self, value: str) -> None:
        self._cache["language"] = value

    @property
    def last_modified_by(self) -> str:
        # Intentionally returns empty — attribution is Keryx-owned.
        return str(self._cache.get("last_modified_by", ""))

    @last_modified_by.setter
    def last_modified_by(self, value: str) -> None:
        self._cache["last_modified_by"] = value

    @property
    def last_printed(self) -> datetime | None:
        v = self._cache.get("last_printed")
        return v if isinstance(v, datetime) else None

    @last_printed.setter
    def last_printed(self, value: datetime | None) -> None:
        self._cache["last_printed"] = value

    @property
    def modified(self) -> datetime | None:
        v = self._cache.get("modified")
        return v if isinstance(v, datetime) else None

    @modified.setter
    def modified(self, value: datetime | None) -> None:
        self._cache["modified"] = value

    @property
    def revision(self) -> int:
        v = self._cache.get("revision", 0)
        return int(v) if isinstance(v, (int, float, str)) else 0

    @revision.setter
    def revision(self, value: int) -> None:
        self._cache["revision"] = value

    @property
    def subject(self) -> str:
        return str(self._cache.get("subject", ""))

    @subject.setter
    def subject(self, value: str) -> None:
        self._cache["subject"] = value

    @property
    def title(self) -> str:
        return str(self._cache.get("title", ""))

    @title.setter
    def title(self, value: str) -> None:
        self._cache["title"] = value

    @property
    def version(self) -> str:
        return str(self._cache.get("version", ""))

    @version.setter
    def version(self, value: str) -> None:
        self._cache["version"] = value
