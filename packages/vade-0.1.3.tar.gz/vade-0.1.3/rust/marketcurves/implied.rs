use chrono::NaiveDate;
use serde::{Serialize, Deserialize};
use indexmap::IndexMap;
use crate::autodiff::enums::Number;
use crate::autodiff::ops::math_funcs::MathFuncs;
use crate::calendar::convention::{DayCountConvention, DcfOptions};
use crate::calendar::cal::BusinessCalendar;
use crate::calendar::tenor::Tenor;
use crate::marketcurves::curve::CurveQuery;
use crate::marketcurves::nodes::Nodes;
use crate::marketcurves::interpolation::{CurveInterpolation, Interpolator};

/// An interest rate implied curve that snapshots discount factors from a source
/// curve at custom tenor points. Supports bucket-level delta risk via AD.
///
/// Not added to CurveRef enum -- this is a read-only risk reporting curve,
/// not a solver target.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct IRImpliedCurve {
    pub nodes: Nodes,
    pub interpolator: Interpolator,
    pub convention: DayCountConvention,
    pub calendar: BusinessCalendar,
    pub id: String,
    pub tenor_labels: Vec<String>,
    pub ref_date: NaiveDate,
}

impl IRImpliedCurve {
    /// Construct an IRImpliedCurve by snapshotting discount factors from a source
    /// curve at each tenor date.
    ///
    /// The first node is always (ref_date, 1.0) representing DF=1 at the reference date.
    /// Subsequent nodes are computed by evaluating the source curve's discount_factor
    /// at each tenor date derived from ref_date.
    pub fn from_curve(
        source: &dyn CurveQuery,
        ref_date: NaiveDate,
        tenors: &[String],
        calendar: &BusinessCalendar,
        convention: DayCountConvention,
    ) -> Result<Self, String> {
        let mut nodes_map: IndexMap<NaiveDate, f64> = IndexMap::new();
        let mut tenor_labels = vec!["0D".to_string()];

        // First node: ref_date with DF=1.0
        nodes_map.insert(ref_date, 1.0);

        for t in tenors {
            let tenor = Tenor::parse(t)?;
            let date = tenor.add_to(ref_date, Some(calendar))?;
            let df_val = match source.discount_factor(date) {
                Number::F64(v) => v,
                Number::Dual(d) => d.real(),
                Number::Dual2(d) => d.real(),
            };
            nodes_map.insert(date, df_val);
            tenor_labels.push(t.clone());
        }

        Ok(Self {
            nodes: Nodes::from_f64_map(nodes_map),
            interpolator: Interpolator::LogLinear,
            convention,
            calendar: calendar.clone(),
            id: "ir_implied".to_string(),
            tenor_labels,
            ref_date,
        })
    }
    /// Switch nodes from F64 to Dual mode for AD gradient extraction.
    ///
    /// Each node gets an identity gradient: dual[i] = 1.0 for its own index.
    /// Variable names are taken from tenor_labels.
    pub fn set_dual_mode(&mut self) {
        use ndarray::Array1;
        use crate::autodiff::dual::Dual;
        use std::sync::Arc;
        use indexmap::IndexSet;

        let keys = self.nodes.keys();
        let n = keys.len();
        let var_names: Arc<IndexSet<String>> = Arc::new(
            self.tenor_labels.iter().cloned().collect()
        );

        let mut map = IndexMap::new();
        for (i, date) in keys.iter().enumerate() {
            let val = match self.nodes.get_value_at_index(i) {
                Number::F64(v) => v,
                Number::Dual(d) => d.real(),
                Number::Dual2(d) => d.real(),
            };
            let mut dual_vec = Array1::zeros(n);
            dual_vec[i] = 1.0;
            let dual = Dual {
                real: val,
                vars: Arc::clone(&var_names),
                dual: dual_vec,
            };
            map.insert(*date, dual);
        }
        self.nodes = Nodes::Dual(map);
    }

    /// Restore nodes from Dual (or Dual2) mode back to F64 mode.
    ///
    /// Preserves the real values of each node.
    pub fn restore_f64_mode(&mut self) {
        let keys = self.nodes.keys();
        let mut map = IndexMap::new();
        for (i, date) in keys.iter().enumerate() {
            let val = match self.nodes.get_value_at_index(i) {
                Number::F64(v) => v,
                Number::Dual(d) => d.real(),
                Number::Dual2(d) => d.real(),
            };
            map.insert(*date, val);
        }
        self.nodes = Nodes::F64(map);
    }

    /// Compute bucket-level delta risk (DV01) for an instrument.
    ///
    /// Sets nodes to Dual mode, computes NPV via the provided function,
    /// extracts gradient dNPV/dNode_i, scales by 0.0001 for DV01 units,
    /// and restores F64 mode.
    ///
    /// Returns Vec<(String, NaiveDate, f64)> -- (tenor_label, date, delta).
    pub fn bucket_delta<F>(&mut self, npv_fn: F) -> Vec<(String, NaiveDate, f64)>
    where
        F: Fn(&dyn CurveQuery) -> Number,
    {
        // 1. Switch to Dual mode
        self.set_dual_mode();

        // 2. Compute NPV
        let npv = npv_fn(self as &dyn CurveQuery);

        // 3. Extract gradient
        let gradient = match &npv {
            Number::Dual(d) => d.dual.to_vec(),
            _ => vec![0.0; self.nodes.len()],
        };

        // 4. Restore F64 mode
        self.restore_f64_mode();

        // 5. Build results: scale by 0.0001 for DV01
        let keys = self.nodes.keys();
        self.tenor_labels.iter()
            .zip(keys.iter())
            .zip(gradient.iter())
            .map(|((label, date), &grad)| {
                (label.clone(), *date, grad * 0.0001)
            })
            .collect()
    }
}

impl CurveQuery for IRImpliedCurve {
    fn discount_factor(&self, date: NaiveDate) -> Number {
        self.interpolator.interpolated_value(&self.nodes, date)
    }

    fn zero_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        let dcf = self.convention.dcf(start, end, &DcfOptions::default()).unwrap();
        let df_start = self.discount_factor(start);
        let df_end = self.discount_factor(end);
        let df_ratio = &df_end / &df_start;
        -(df_ratio.log()) / dcf
    }

    fn forward_rate(&self, start: NaiveDate, end: NaiveDate) -> Number {
        self.zero_rate(start, end)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::nodes::Nodes;
    use crate::calendar::cal::BusinessCalendar;
    use crate::calendar::convention::DayCountConvention;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn empty_calendar() -> BusinessCalendar {
        BusinessCalendar {
            holidays: std::collections::HashSet::new(),
            weekmask: vec![5, 6],
        }
    }

    /// Build a simple DiscountCurve with known DFs for testing.
    fn source_curve() -> DiscountCurve {
        let ref_date = ymd(2024, 1, 1);
        // Flat 3% continuous rate: DF(t) = exp(-0.03 * t)
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ref_date, 1.0),
            (ymd(2025, 1, 1), (-0.03_f64 * 1.0).exp()),  // ~0.9704
            (ymd(2026, 1, 1), (-0.03_f64 * 2.0).exp()),  // ~0.9418
            (ymd(2029, 1, 1), (-0.03_f64 * 5.0).exp()),  // ~0.8607
            (ymd(2034, 1, 1), (-0.03_f64 * 10.0).exp()), // ~0.7408
        ]));
        DiscountCurve {
            nodes,
            interpolator: Interpolator::LogLinear,
            convention: DayCountConvention::Act365F,
            modifier: crate::calendar::adjuster::Adjuster::Actual,
            calendar: None,
            id: "source".to_string(),
        }
    }

    #[test]
    fn test_from_curve_node_count() {
        let source = source_curve();
        let cal = empty_calendar();
        let tenors: Vec<String> = vec!["1Y", "2Y", "5Y", "10Y"]
            .into_iter().map(String::from).collect();
        let curve = IRImpliedCurve::from_curve(
            &source, ymd(2024, 1, 1), &tenors, &cal, DayCountConvention::Act365F,
        ).unwrap();
        // ref_date + 4 tenors = 5 nodes
        assert_eq!(curve.nodes.len(), 5);
    }

    #[test]
    fn test_from_curve_first_node_is_ref_date_with_df_one() {
        let source = source_curve();
        let cal = empty_calendar();
        let tenors: Vec<String> = vec!["1Y", "2Y", "5Y", "10Y"]
            .into_iter().map(String::from).collect();
        let curve = IRImpliedCurve::from_curve(
            &source, ymd(2024, 1, 1), &tenors, &cal, DayCountConvention::Act365F,
        ).unwrap();
        let keys = curve.nodes.keys();
        assert_eq!(keys[0], ymd(2024, 1, 1));
        if let Number::F64(v) = curve.nodes.get_value_at_index(0) {
            assert!((v - 1.0).abs() < 1e-14, "First node DF should be 1.0, got {v}");
        } else {
            panic!("Expected F64 node");
        }
    }

    #[test]
    fn test_discount_factor_at_tenor_matches_source() {
        let source = source_curve();
        let cal = empty_calendar();
        let tenors: Vec<String> = vec!["1Y", "2Y", "5Y", "10Y"]
            .into_iter().map(String::from).collect();
        let curve = IRImpliedCurve::from_curve(
            &source, ymd(2024, 1, 1), &tenors, &cal, DayCountConvention::Act365F,
        ).unwrap();

        for date in &[ymd(2025, 1, 1), ymd(2026, 1, 1), ymd(2029, 1, 1), ymd(2034, 1, 1)] {
            let src_df = source.discount_factor(*date);
            let imp_df = curve.discount_factor(*date);
            match (src_df, imp_df) {
                (Number::F64(a), Number::F64(b)) => {
                    assert!((a - b).abs() < 1e-14,
                        "DF mismatch at {date}: source={a}, implied={b}");
                }
                _ => panic!("Expected F64"),
            }
        }
    }

    #[test]
    fn test_discount_factor_intermediate_uses_interpolation() {
        let source = source_curve();
        let cal = empty_calendar();
        let tenors: Vec<String> = vec!["1Y", "2Y", "5Y", "10Y"]
            .into_iter().map(String::from).collect();
        let curve = IRImpliedCurve::from_curve(
            &source, ymd(2024, 1, 1), &tenors, &cal, DayCountConvention::Act365F,
        ).unwrap();

        // DF at 3Y should be between DF(2Y) and DF(5Y)
        let df_3y = curve.discount_factor(ymd(2027, 1, 1));
        let df_2y = curve.discount_factor(ymd(2026, 1, 1));
        let df_5y = curve.discount_factor(ymd(2029, 1, 1));
        match (df_2y, df_3y, df_5y) {
            (Number::F64(a), Number::F64(b), Number::F64(c)) => {
                assert!(b < a && b > c,
                    "DF(3Y)={b} should be between DF(2Y)={a} and DF(5Y)={c}");
            }
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_zero_rate_positive() {
        let source = source_curve();
        let cal = empty_calendar();
        let tenors: Vec<String> = vec!["1Y", "2Y", "5Y", "10Y"]
            .into_iter().map(String::from).collect();
        let curve = IRImpliedCurve::from_curve(
            &source, ymd(2024, 1, 1), &tenors, &cal, DayCountConvention::Act365F,
        ).unwrap();

        let zr = curve.zero_rate(ymd(2024, 1, 1), ymd(2026, 1, 1));
        if let Number::F64(r) = zr {
            assert!(r > 0.0, "Zero rate should be positive, got {r}");
            // Should be close to 3% for flat curve
            assert!((r - 0.03).abs() < 0.001,
                "Zero rate should be ~0.03, got {r}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_discount_factor_returns_f64_for_f64_nodes() {
        let source = source_curve();
        let cal = empty_calendar();
        let tenors: Vec<String> = vec!["1Y", "2Y"].into_iter().map(String::from).collect();
        let curve = IRImpliedCurve::from_curve(
            &source, ymd(2024, 1, 1), &tenors, &cal, DayCountConvention::Act365F,
        ).unwrap();

        let df = curve.discount_factor(ymd(2025, 1, 1));
        assert!(matches!(df, Number::F64(_)), "Should return Number::F64");
    }

    #[test]
    fn test_set_dual_mode() {
        let source = source_curve();
        let cal = empty_calendar();
        let tenors: Vec<String> = vec!["1Y", "2Y", "5Y", "10Y"]
            .into_iter().map(String::from).collect();
        let mut curve = IRImpliedCurve::from_curve(
            &source, ymd(2024, 1, 1), &tenors, &cal, DayCountConvention::Act365F,
        ).unwrap();

        curve.set_dual_mode();

        // Nodes should be Dual variant
        assert!(matches!(curve.nodes, Nodes::Dual(_)), "Expected Dual nodes");

        // discount_factor should return Number::Dual
        let df = curve.discount_factor(ymd(2025, 6, 1));
        assert!(matches!(df, Number::Dual(_)), "Expected Dual result");

        // Gradient dimensionality should equal number of nodes
        if let Number::Dual(d) = df {
            assert_eq!(d.dual.len(), 5, "Gradient should have 5 components");
        }
    }

    #[test]
    fn test_restore_f64_mode() {
        let source = source_curve();
        let cal = empty_calendar();
        let tenors: Vec<String> = vec!["1Y", "2Y", "5Y", "10Y"]
            .into_iter().map(String::from).collect();
        let mut curve = IRImpliedCurve::from_curve(
            &source, ymd(2024, 1, 1), &tenors, &cal, DayCountConvention::Act365F,
        ).unwrap();

        // Get original values
        let original_values: Vec<f64> = (0..curve.nodes.len())
            .map(|i| match curve.nodes.get_value_at_index(i) {
                Number::F64(v) => v,
                _ => panic!("Expected F64"),
            })
            .collect();

        // Switch to Dual and back
        curve.set_dual_mode();
        curve.restore_f64_mode();

        // Should be F64 again
        assert!(matches!(curve.nodes, Nodes::F64(_)), "Expected F64 nodes");

        // Real values should be unchanged
        for (i, &orig) in original_values.iter().enumerate() {
            if let Number::F64(v) = curve.nodes.get_value_at_index(i) {
                assert!((v - orig).abs() < 1e-14,
                    "Value at index {i} changed: {orig} -> {v}");
            } else {
                panic!("Expected F64");
            }
        }
    }

    #[test]
    fn test_bucket_delta_basic() {
        let source = source_curve();
        let cal = empty_calendar();
        let tenors: Vec<String> = vec!["1Y", "2Y", "5Y"]
            .into_iter().map(String::from).collect();
        let mut curve = IRImpliedCurve::from_curve(
            &source, ymd(2024, 1, 1), &tenors, &cal, DayCountConvention::Act365F,
        ).unwrap();

        // NPV function: just the discount factor at 3Y (intermediate point)
        let date_3y = ymd(2027, 1, 1);
        let deltas = curve.bucket_delta(|c| c.discount_factor(date_3y));

        // Should have 4 entries (ref_date + 3 tenors)
        assert_eq!(deltas.len(), 4, "Expected 4 delta entries");

        // Check labels
        assert_eq!(deltas[0].0, "0D");
        assert_eq!(deltas[1].0, "1Y");
        assert_eq!(deltas[2].0, "2Y");
        assert_eq!(deltas[3].0, "5Y");

        // Deltas at 2Y and 5Y should be non-zero (3Y is between them in log-linear interp)
        assert!(deltas[2].2.abs() > 1e-10,
            "Delta at 2Y should be non-zero, got {}", deltas[2].2);
        assert!(deltas[3].2.abs() > 1e-10,
            "Delta at 5Y should be non-zero, got {}", deltas[3].2);

        // Delta at 0D (ref_date) should be zero or very small
        // (3Y is far from ref_date in log-linear)
        assert!(deltas[0].2.abs() < 1e-10,
            "Delta at 0D should be ~0, got {}", deltas[0].2);

        // All deltas should be DV01-scaled (0.0001 factor)
        // The raw gradient of DF(3Y) w.r.t. a node is O(1),
        // so DV01-scaled values should be O(0.0001)
        for (label, _, delta) in &deltas {
            assert!(delta.abs() < 1.0,
                "Delta for {label} seems too large for DV01: {delta}");
        }

        // After bucket_delta, curve should be back in F64 mode
        assert!(matches!(curve.nodes, Nodes::F64(_)), "Should restore F64 mode");
    }
}
