use chrono::NaiveDate;
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;

use crate::cashflows::py::PyCashflowRow;
use crate::instruments;
use crate::instruments::py_utils::{
    number_to_py, parse_day_count, parse_adjuster, parse_frequency,
    parse_stub, build_calendar, parse_curves, extract_curve_ref,
};

// ---- PyBondInstrument ----

#[pyclass(name = "PyBondInstrument", module = "vade._vade_rs.instruments", from_py_object)]
#[derive(Clone)]
pub struct PyBondInstrument {
    pub inner: instruments::BondInstrument,
}

#[pymethods]
impl PyBondInstrument {
    #[new]
    #[pyo3(signature = (
        variant,
        effective,
        termination,
        coupon = 0.0,
        spread = 0.0,
        frequency = "s",
        settlement_days = 1,
        ex_div_days = 0,
        calendar = None,
        currency = "USD",
        convention = "actactisda",
        accrued_convention = None,
        face_value = 100.0,
        modifier = "none",
        issue_price = None,
        coupon_rates = None,
        amortization_schedule = None,
        pik_fraction = None,
        fixing_frequency = None,
        cap_rate = None,
        floor_rate = None,
        vol = None,
        vol_model = None,
    ))]
    #[allow(clippy::too_many_arguments)]
    fn new(
        variant: &str,
        effective: NaiveDate,
        termination: NaiveDate,
        coupon: f64,
        spread: f64,
        frequency: &str,
        settlement_days: i32,
        ex_div_days: i32,
        calendar: Option<&str>,
        currency: &str,
        convention: &str,
        accrued_convention: Option<&str>,
        face_value: f64,
        modifier: &str,
        issue_price: Option<f64>,
        coupon_rates: Option<Vec<(NaiveDate, f64)>>,
        amortization_schedule: Option<Vec<(NaiveDate, f64)>>,
        pik_fraction: Option<f64>,
        fixing_frequency: Option<&str>,
        cap_rate: Option<f64>,
        floor_rate: Option<f64>,
        vol: Option<f64>,
        vol_model: Option<&str>,
    ) -> PyResult<Self> {
        let conv = parse_day_count(convention)?;
        let acc_conv = match accrued_convention {
            Some(s) => parse_day_count(s)?,
            None => conv,
        };
        let freq = parse_frequency(frequency)?;
        let adj = parse_adjuster(modifier)?;
        let cal = build_calendar(calendar);

        let bond = match variant.to_lowercase().replace([' ', '_', '-'], "").as_str() {
            "fixedratebond" | "fixed" => {
                instruments::BondInstrument::new_fixed_rate(
                    effective, termination, coupon, freq,
                    settlement_days, ex_div_days, cal,
                    currency.to_string(), conv, acc_conv,
                    face_value, adj,
                )
            }
            "bill" | "zerocoupon" => {
                instruments::BondInstrument::new_bill(
                    effective, termination, settlement_days, cal,
                    currency.to_string(), conv, face_value,
                )
            }
            "floatratenote" | "frn" | "float" => {
                instruments::BondInstrument::new_float_rate_note(
                    effective, termination, spread, freq,
                    settlement_days, ex_div_days, cal,
                    currency.to_string(), conv, acc_conv,
                    face_value, adj,
                )
            }
            "zerocouponbond" => {
                let ip = issue_price.ok_or_else(|| {
                    PyValueError::new_err("issue_price is required for zero_coupon_bond variant")
                })?;
                instruments::BondInstrument::new_zero_coupon(
                    effective, termination, ip, freq,
                    settlement_days, cal, currency.to_string(),
                    conv, face_value,
                )
            }
            "stepupbond" | "stepup" => {
                let rates = coupon_rates.ok_or_else(|| {
                    PyValueError::new_err("coupon_rates is required for step_up_bond variant")
                })?;
                instruments::BondInstrument::new_step_up(
                    effective, termination, rates, freq,
                    settlement_days, ex_div_days, cal,
                    currency.to_string(), conv, acc_conv,
                    face_value, adj,
                )
            }
            "amortizingbond" | "amortizing" => {
                let schedule = amortization_schedule.ok_or_else(|| {
                    PyValueError::new_err("amortization_schedule is required for amortizing_bond variant")
                })?;
                instruments::BondInstrument::new_amortizing(
                    effective, termination, coupon, schedule, freq,
                    settlement_days, ex_div_days, cal,
                    currency.to_string(), conv, acc_conv,
                    face_value, adj,
                )
            }
            "pikbond" | "pik" => {
                let pf = pik_fraction.unwrap_or(1.0);
                instruments::BondInstrument::new_pik(
                    effective, termination, coupon, pf, freq,
                    settlement_days, ex_div_days, cal,
                    currency.to_string(), conv, acc_conv,
                    face_value, adj,
                )
            }
            "subperiodfrn" | "subperiod" | "subperiodfloatratenote" => {
                let fix_freq_str = fixing_frequency.ok_or_else(|| {
                    PyValueError::new_err("fixing_frequency is required for sub_period_frn variant")
                })?;
                let fix_freq = parse_frequency(fix_freq_str)?;
                instruments::BondInstrument::new_sub_period_frn(
                    effective, termination, spread, freq, fix_freq,
                    settlement_days, ex_div_days, cal,
                    currency.to_string(), conv, acc_conv,
                    face_value, adj,
                )
            }
            "cappedfloored" | "cappedfrn" | "cappedfloatratenote" => {
                let fix_freq = match fixing_frequency {
                    Some(ff) => Some(parse_frequency(ff)?),
                    None => None,
                };
                let v = vol.ok_or_else(|| {
                    PyValueError::new_err("vol is required for capped_floored variant")
                })?;
                let vm_str = vol_model.unwrap_or("black76").to_lowercase().replace([' ', '_', '-'], "");
                let vm = match vm_str.as_str() {
                    "black76" => crate::models::black::VolModel::Black76,
                    "bachelier" | "normal" => crate::models::black::VolModel::Bachelier,
                    other => return Err(PyValueError::new_err(format!(
                        "Unknown vol_model: '{}'. Use: 'black76' or 'bachelier'.", other
                    ))),
                };
                instruments::BondInstrument::new_capped_floored(
                    effective, termination, spread, freq, fix_freq,
                    cap_rate, floor_rate, v, vm,
                    settlement_days, ex_div_days, cal,
                    currency.to_string(), conv, acc_conv,
                    face_value, adj,
                )
            }
            _ => {
                return Err(PyValueError::new_err(format!(
                    "Unknown bond variant: '{}'. Use: 'fixed_rate_bond', 'bill', 'float_rate_note', 'zero_coupon_bond', 'step_up_bond', 'amortizing_bond', 'pik_bond', 'sub_period_frn', 'capped_floored'.",
                    variant
                )));
            }
        };

        Ok(PyBondInstrument { inner: bond })
    }

    #[pyo3(signature = (curves, settlement = None))]
    fn price(&self, py: Python<'_>, curves: &Bound<'_, PyAny>, settlement: Option<NaiveDate>) -> PyResult<Py<PyAny>> {
        let (disc, _forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.price(&*disc, settlement))
    }

    #[pyo3(signature = (curves, settlement = None))]
    fn dirty_price(&self, py: Python<'_>, curves: &Bound<'_, PyAny>, settlement: Option<NaiveDate>) -> PyResult<Py<PyAny>> {
        let (disc, _) = parse_curves(curves)?;
        number_to_py(py, self.inner.dirty_price(&*disc, settlement))
    }

    fn accrued_interest(&self, settlement: NaiveDate) -> f64 {
        self.inner.accrued_interest(settlement)
    }

    #[pyo3(signature = (clean_price, settlement, convention = "periodic"))]
    fn ytm(&self, clean_price: f64, settlement: NaiveDate, convention: &str) -> f64 {
        self.inner.ytm(clean_price, settlement, convention)
    }

    #[pyo3(signature = (ytm, settlement, convention = "periodic"))]
    fn price_from_ytm(&self, ytm: f64, settlement: NaiveDate, convention: &str) -> f64 {
        self.inner.price_from_ytm(ytm, settlement, convention)
    }

    #[pyo3(signature = (curves, metric = "modified", settlement = None))]
    fn duration(&self, curves: &Bound<'_, PyAny>, metric: &str, settlement: Option<NaiveDate>) -> PyResult<f64> {
        let (disc, _) = parse_curves(curves)?;
        Ok(self.inner.duration(&*disc, metric, settlement))
    }

    #[pyo3(signature = (curves, settlement = None))]
    fn convexity(&self, curves: &Bound<'_, PyAny>, settlement: Option<NaiveDate>) -> PyResult<f64> {
        let (disc, _) = parse_curves(curves)?;
        Ok(self.inner.convexity(&*disc, settlement))
    }

    fn dv01(&self, curves: &Bound<'_, PyAny>) -> PyResult<f64> {
        let (disc, _) = parse_curves(curves)?;
        Ok(self.inner.dv01(&*disc))
    }

    #[pyo3(signature = (curves, clean_price, settlement = None))]
    fn z_spread(&self, curves: &Bound<'_, PyAny>, clean_price: f64, settlement: Option<NaiveDate>) -> PyResult<f64> {
        let (disc, _) = parse_curves(curves)?;
        Ok(self.inner.z_spread(&*disc, clean_price, settlement))
    }

    #[pyo3(signature = (curves, clean_price, method = "par_par", settlement = None))]
    fn asw_spread(&self, curves: &Bound<'_, PyAny>, clean_price: f64, method: &str, settlement: Option<NaiveDate>) -> PyResult<f64> {
        let (disc, _) = parse_curves(curves)?;
        Ok(self.inner.asw_spread(&*disc, clean_price, method, settlement))
    }

    fn cs01(&self, curves: &Bound<'_, PyAny>) -> PyResult<f64> {
        let (disc, _) = parse_curves(curves)?;
        Ok(self.inner.cs01(&*disc))
    }

    fn i_spread(&self, settlement: NaiveDate, swap_curve: &Bound<'_, PyAny>) -> PyResult<f64> {
        let curve = extract_curve_ref(swap_curve)?;
        Ok(self.inner.i_spread(settlement, &*curve))
    }

    fn price_yield_sensitivity(&self, curves: &Bound<'_, PyAny>) -> PyResult<f64> {
        let (disc, _) = parse_curves(curves)?;
        Ok(self.inner.price_yield_sensitivity(&*disc))
    }

    fn rate(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.rate(&*disc, &*forecast))
    }

    fn npv(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.npv(&*disc, &*forecast))
    }

    fn cashflows(&self, curves: &Bound<'_, PyAny>) -> PyResult<Vec<PyCashflowRow>> {
        let (disc, forecast) = parse_curves(curves)?;
        let rows = self.inner.cashflows(Some(&*disc), Some(&*forecast));
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    fn spread(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.spread(&*disc, &*forecast))
    }

    fn analytic_delta(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.analytic_delta(&*disc, &*forecast))
    }

    fn notional_schedule(&self) -> Vec<(NaiveDate, f64)> {
        self.inner.notional_schedule()
    }

    fn sub_period_schedule(
        &self,
    ) -> Option<Vec<(NaiveDate, NaiveDate, NaiveDate, Vec<(NaiveDate, NaiveDate, f64, Option<f64>)>)>>
    {
        self.inner.sub_period_schedule()
    }

    fn __repr__(&self) -> String {
        "BondInstrument(...)".to_string()
    }
}

// ---- PyCDS (CreditDefaultSwap) ----

#[pyclass(name = "CreditDefaultSwap", module = "vade._vade_rs.instruments", from_py_object)]
#[derive(Clone)]
pub struct PyCDS {
    pub inner: instruments::CreditDefaultSwap,
}

#[pymethods]
impl PyCDS {
    #[new]
    #[pyo3(signature = (
        effective,
        termination,
        frequency = "q",
        notional = 10000000.0,
        recovery_rate = 0.4,
        fixed_rate = 100.0,
        convention = "act360",
        currency = "USD",
        premium_accrued = true,
        modifier = "mf",
        stub = "shortfront",
    ))]
    #[allow(clippy::too_many_arguments)]
    fn new(
        effective: NaiveDate,
        termination: NaiveDate,
        frequency: &str,
        notional: f64,
        recovery_rate: f64,
        fixed_rate: f64,
        convention: &str,
        currency: &str,
        premium_accrued: bool,
        modifier: &str,
        stub: &str,
    ) -> PyResult<Self> {
        let freq = parse_frequency(frequency)?;
        let conv = parse_day_count(convention)?;
        let adj = parse_adjuster(modifier)?;
        let stub_inf = parse_stub(stub);
        let cal = build_calendar(None);

        let schedule = crate::calendar::schedule::Schedule::try_new(
            effective,
            termination,
            freq,
            cal,
            adj,
            None, None, None,
            stub_inf,
        ).map_err(|e| PyValueError::new_err(format!("Schedule error: {e}")))?;

        use crate::cashflows::credit_leg::{CreditPremiumLeg, CreditProtectionLeg};

        let premium_leg = CreditPremiumLeg::new(
            &schedule, notional, fixed_rate, conv,
            currency.to_string(), premium_accrued, recovery_rate,
        );
        let protection_leg = CreditProtectionLeg::new(
            &schedule, notional, recovery_rate, conv, currency.to_string(),
        );

        Ok(PyCDS {
            inner: instruments::CreditDefaultSwap::new(
                premium_leg, protection_leg, recovery_rate, notional,
                fixed_rate, currency.to_string(),
            ),
        })
    }

    fn rate(&self, py: Python<'_>, disc_curve: &Bound<'_, PyAny>, credit_curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let dc = extract_curve_ref(disc_curve)?;
        let cc = extract_curve_ref(credit_curve)?;
        number_to_py(py, self.inner.rate(&*dc, &*cc))
    }

    fn npv(&self, py: Python<'_>, disc_curve: &Bound<'_, PyAny>, credit_curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let dc = extract_curve_ref(disc_curve)?;
        let cc = extract_curve_ref(credit_curve)?;
        number_to_py(py, self.inner.npv(&*dc, &*cc))
    }

    fn spread(&self, py: Python<'_>, disc_curve: &Bound<'_, PyAny>, credit_curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let dc = extract_curve_ref(disc_curve)?;
        let cc = extract_curve_ref(credit_curve)?;
        number_to_py(py, self.inner.spread(&*dc, &*cc))
    }

    fn cashflows(&self, disc_curve: &Bound<'_, PyAny>, credit_curve: &Bound<'_, PyAny>) -> PyResult<Vec<PyCashflowRow>> {
        let dc = extract_curve_ref(disc_curve)?;
        let cc = extract_curve_ref(credit_curve)?;
        let rows = self.inner.cashflows(Some(&*dc), Some(&*cc));
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    fn accrued(&self, today: NaiveDate) -> f64 {
        self.inner.accrued(today)
    }

    fn analytic_rec_risk(&self, py: Python<'_>, disc_curve: &Bound<'_, PyAny>, credit_curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let dc = extract_curve_ref(disc_curve)?;
        let cc = extract_curve_ref(credit_curve)?;
        number_to_py(py, self.inner.analytic_rec_risk(&*dc, &*cc))
    }

    fn jtd(&self, today: NaiveDate) -> f64 {
        self.inner.jtd(today)
    }

    fn ead(&self) -> f64 {
        self.inner.ead()
    }

    fn upfront(&self, py: Python<'_>, disc_curve: &Bound<'_, PyAny>, credit_curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let dc = extract_curve_ref(disc_curve)?;
        let cc = extract_curve_ref(credit_curve)?;
        number_to_py(py, self.inner.upfront(&*dc, &*cc))
    }

    fn to_upfront_spread(&self, py: Python<'_>, disc_curve: &Bound<'_, PyAny>, credit_curve: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let dc = extract_curve_ref(disc_curve)?;
        let cc = extract_curve_ref(credit_curve)?;
        number_to_py(py, self.inner.to_upfront_spread(&*dc, &*cc))
    }

    fn __repr__(&self) -> String {
        format!("CreditDefaultSwap(notional={}, fixed_rate={}bp)", self.inner.notional, self.inner.fixed_rate)
    }
}

// ---- PyAssetSwap ----

#[pyclass(name = "PyAssetSwap", module = "vade._vade_rs.instruments", from_py_object)]
#[derive(Clone)]
pub struct PyAssetSwap {
    pub inner: instruments::asset_swap::AssetSwapInstrument,
}

#[pymethods]
impl PyAssetSwap {
    #[new]
    #[pyo3(signature = (bond, asw_type="par", dirty_price=None, spread=None))]
    fn new(
        bond: &PyBondInstrument,
        asw_type: &str,
        dirty_price: Option<f64>,
        spread: Option<f64>,
    ) -> PyResult<Self> {
        let asw_type_enum = match asw_type {
            "par" => instruments::asset_swap::AssetSwapType::Par,
            "non_par" | "market_value" => instruments::asset_swap::AssetSwapType::MarketValue,
            _ => return Err(PyValueError::new_err(
                format!("asw_type must be 'par' or 'non_par', got '{}'", asw_type)
            )),
        };

        if asw_type_enum == instruments::asset_swap::AssetSwapType::MarketValue && dirty_price.is_none() {
            return Err(PyValueError::new_err(
                "dirty_price is required for non_par (market_value) asset swap"
            ));
        }

        let inst = instruments::asset_swap::AssetSwapInstrument::new(
            bond.inner.clone(),
            asw_type_enum,
            dirty_price,
            spread,
        );
        Ok(Self { inner: inst })
    }

    fn rate(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.rate(&*disc, &*forecast))
    }

    fn npv(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.npv(&*disc, &*forecast))
    }

    fn cashflows(&self, curves: &Bound<'_, PyAny>) -> PyResult<Vec<PyCashflowRow>> {
        let (disc, forecast) = parse_curves(curves)?;
        let rows = self.inner.cashflows(&*disc, &*forecast);
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    fn spread(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.spread(&*disc, &*forecast))
    }

    fn analytic_delta(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.analytic_delta(&*disc, &*forecast))
    }

    fn __repr__(&self) -> String {
        "AssetSwap(...)".to_string()
    }
}

// ---- PyCallableBond ----

#[pyclass(name = "PyCallableBond", module = "vade._vade_rs.instruments", from_py_object)]
#[derive(Clone)]
pub struct PyCallableBond {
    pub inner: instruments::callable_bond::CallableBondInstrument,
}

#[pymethods]
impl PyCallableBond {
    #[new]
    #[pyo3(signature = (bond, call_schedule, put_schedule=None))]
    fn new(
        bond: &PyBondInstrument,
        call_schedule: Vec<(NaiveDate, f64)>,
        put_schedule: Option<Vec<(NaiveDate, f64)>>,
    ) -> PyResult<Self> {
        if call_schedule.is_empty() && put_schedule.as_ref().map_or(true, |p| p.is_empty()) {
            return Err(PyValueError::new_err("call_schedule or put_schedule must not be empty"));
        }
        let inst = instruments::callable_bond::CallableBondInstrument::new(
            bond.inner.clone(),
            call_schedule,
            put_schedule,
        );
        Ok(Self { inner: inst })
    }

    #[pyo3(signature = (curves, a, sigma, spread=0.0))]
    fn tree_price(&self, curves: &Bound<'_, PyAny>, a: f64, sigma: f64, spread: f64) -> PyResult<f64> {
        let (disc, _forecast) = parse_curves(curves)?;
        Ok(self.inner.tree_price(&*disc, a, sigma, spread))
    }

    #[pyo3(signature = (curves, market_price, a, sigma))]
    fn oas(&self, curves: &Bound<'_, PyAny>, market_price: f64, a: f64, sigma: f64) -> PyResult<f64> {
        let (disc, _forecast) = parse_curves(curves)?;
        self.inner.oas(&*disc, market_price, a, sigma)
            .map_err(|e| PyValueError::new_err(e))
    }

    #[pyo3(signature = (curves, a, sigma, oas=0.0, bump=0.0001))]
    fn effective_duration(&self, curves: &Bound<'_, PyAny>, a: f64, sigma: f64, oas: f64, bump: f64) -> PyResult<f64> {
        let (disc, _forecast) = parse_curves(curves)?;
        Ok(self.inner.effective_duration(&*disc, a, sigma, oas, bump))
    }

    #[pyo3(signature = (curves, a, sigma, oas=0.0, bump=0.0001))]
    fn effective_convexity(&self, curves: &Bound<'_, PyAny>, a: f64, sigma: f64, oas: f64, bump: f64) -> PyResult<f64> {
        let (disc, _forecast) = parse_curves(curves)?;
        Ok(self.inner.effective_convexity(&*disc, a, sigma, oas, bump))
    }

    #[pyo3(signature = (curves, a, sigma, oas=0.0, bump=0.0001))]
    fn vega(&self, curves: &Bound<'_, PyAny>, a: f64, sigma: f64, oas: f64, bump: f64) -> PyResult<f64> {
        let (disc, _forecast) = parse_curves(curves)?;
        Ok(self.inner.vega(&*disc, a, sigma, oas, bump))
    }

    fn rate(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.bond.rate(&*disc, &*forecast))
    }

    fn npv(&self, py: Python<'_>, curves: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        let (disc, forecast) = parse_curves(curves)?;
        number_to_py(py, self.inner.bond.npv(&*disc, &*forecast))
    }

    fn cashflows(&self, curves: &Bound<'_, PyAny>) -> PyResult<Vec<PyCashflowRow>> {
        let (disc, forecast) = parse_curves(curves)?;
        let rows = self.inner.bond.cashflows(Some(&*disc), Some(&*forecast));
        Ok(rows.into_iter().map(|r| PyCashflowRow { inner: r }).collect())
    }

    fn __repr__(&self) -> String {
        format!("CallableBond(calls={}, puts={})",
            self.inner.call_schedule.len(),
            self.inner.put_schedule.as_ref().map_or(0, |p| p.len()))
    }
}

pub fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyBondInstrument>()?;
    m.add_class::<PyCDS>()?;
    m.add_class::<PyAssetSwap>()?;
    m.add_class::<PyCallableBond>()?;
    Ok(())
}
