// Product subdirectories
pub mod rates;
pub mod fx;
pub mod credit;

// Shared PyO3 helpers
pub(crate) mod py_utils;
pub mod py;

// Facade: preserve all existing import paths for external consumers
pub use rates::InterestRateSwap;
pub use rates::ForwardRateAgreement;
pub use rates::ZeroCouponSwap;
pub use rates::SingleBasisSwap;
pub use rates::OvernightIndexedSwap;
pub use rates::DepositInstrument;
pub use rates::IRFutureInstrument;
pub use fx::FXForwardInstrument;
pub use fx::CrossCurrencySwap;
pub use credit::CreditDefaultSwap;
pub use credit::BondInstrument;
pub use credit::AssetSwapInstrument;
pub use credit::CallableBondInstrument;

// Module-level re-exports for backward compat (py.rs and solver/ use module paths directly)
pub use rates::future as ir_future;    // py.rs L20: use crate::instruments::ir_future::QuoteConvention
pub use fx::forward as fx_forward;     // solver/mod.rs L1329: use crate::instruments::fx_forward::FXForwardInstrument
pub use rates::cap_floor;              // credit/bond.rs L13: use crate::instruments::cap_floor

// Sub-module re-exports used by external consumers via direct module paths
pub use credit::bond;                  // curves/fitted.rs: use crate::instruments::bond::{BondInstrument, BondVariant}
pub use fx::xcs;                       // py.rs L1531/2295: use crate::instruments::xcs::XCSLeg
pub use rates::irs;                    // solver/mod.rs L852: use crate::instruments::irs::InterestRateSwap
pub use rates::deposit;                // solver/mod.rs L853: use crate::instruments::deposit::DepositInstrument
pub use credit::cds;                   // solver/mod.rs L1177: use crate::instruments::cds
pub use credit::asset_swap;            // py.rs: instruments::asset_swap::AssetSwapInstrument
pub use credit::callable_bond;         // py.rs: instruments::callable_bond::CallableBondInstrument

use chrono::NaiveDate;
use serde::{Serialize, Deserialize};
use crate::autodiff::enums::Number;
use crate::cashflows::period::CashflowRow;
use crate::marketcurves::curve::CurveQuery;
use crate::marketcurves::fx::rates::FXRates;

/// Unified instrument enum for dispatch.
#[derive(Clone, Serialize, Deserialize)]
pub enum Instrument {
    IRS(InterestRateSwap),
    FRA(ForwardRateAgreement),
    ZCS(ZeroCouponSwap),
    SBS(SingleBasisSwap),
    OIS(OvernightIndexedSwap),
    Deposit(DepositInstrument),
    IRFuture(IRFutureInstrument),
    Bond(BondInstrument),
    CDS(CreditDefaultSwap),
    XCS(CrossCurrencySwap),
    FXForward(FXForwardInstrument),
    AssetSwap(AssetSwapInstrument),
    CallableBond(CallableBondInstrument),
    NDF(FXForwardInstrument),
    NDIRS(InterestRateSwap),
    NDXCS(CrossCurrencySwap),
}

impl Instrument {
    /// Compute par rate for the instrument.
    ///
    /// Extended signature for multi-currency support:
    /// - fx_rates: required for XCS and FXForward, None for single-currency instruments
    /// - leg2_disc_curve / leg2_forecast_curve: required for XCS 4-curve model, None for others
    pub fn rate(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
        fx_rates: Option<&FXRates>,
        leg2_disc_curve: Option<&dyn CurveQuery>,
        leg2_forecast_curve: Option<&dyn CurveQuery>,
    ) -> Number {
        match self {
            Instrument::IRS(inst) => inst.rate(disc_curve, forecast_curve),
            Instrument::FRA(inst) => inst.rate(disc_curve, forecast_curve),
            Instrument::ZCS(inst) => inst.rate(disc_curve, forecast_curve),
            Instrument::SBS(inst) => inst.rate(disc_curve, forecast_curve),
            Instrument::OIS(inst) => inst.rate(disc_curve, forecast_curve),
            Instrument::Deposit(inst) => inst.rate_from_curve(disc_curve, forecast_curve),
            Instrument::IRFuture(inst) => inst.rate(disc_curve, forecast_curve),
            Instrument::Bond(inst) => inst.rate(disc_curve, forecast_curve),
            Instrument::CDS(inst) => inst.rate(disc_curve, forecast_curve),
            Instrument::XCS(inst) => {
                let fxr = fx_rates.expect("XCS requires fx_rates");
                let l2d = leg2_disc_curve.expect("XCS requires leg2_disc_curve");
                let l2f = leg2_forecast_curve.unwrap_or(l2d);
                inst.rate(disc_curve, forecast_curve, l2d, l2f, fxr, "leg2")
            }
            Instrument::FXForward(inst) => {
                let fxr = fx_rates.expect("FXForward requires fx_rates");
                inst.rate(disc_curve, forecast_curve, fxr)
            }
            Instrument::AssetSwap(inst) => inst.rate(disc_curve, forecast_curve),
            Instrument::CallableBond(inst) => inst.rate(disc_curve, forecast_curve),
            Instrument::NDF(inst) => {
                let fxr = fx_rates.expect("NDF requires fx_rates");
                inst.ndf_rate(disc_curve, forecast_curve, fxr)
            }
            Instrument::NDIRS(inst) => {
                let fxr = fx_rates.expect("NDIRS requires fx_rates");
                let l2d = leg2_disc_curve.expect("NDIRS requires leg2_disc_curve");
                inst.ndirs_rate(disc_curve, forecast_curve, l2d, fxr)
            }
            Instrument::NDXCS(inst) => {
                let fxr = fx_rates.expect("NDXCS requires fx_rates");
                let l2d = leg2_disc_curve.expect("NDXCS requires leg2_disc_curve");
                let l2f = leg2_forecast_curve.unwrap_or(l2d);
                inst.ndxcs_rate(disc_curve, forecast_curve, l2d, l2f, fxr)
            }
        }
    }

    /// Compute NPV of the instrument.
    pub fn npv(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
        fx_rates: Option<&FXRates>,
        leg2_disc_curve: Option<&dyn CurveQuery>,
        leg2_forecast_curve: Option<&dyn CurveQuery>,
    ) -> Number {
        match self {
            Instrument::IRS(inst) => inst.npv(disc_curve, forecast_curve),
            Instrument::FRA(inst) => inst.npv(disc_curve, forecast_curve),
            Instrument::ZCS(inst) => inst.npv(disc_curve, forecast_curve),
            Instrument::SBS(inst) => inst.npv(disc_curve, forecast_curve),
            Instrument::OIS(inst) => inst.npv(disc_curve, forecast_curve),
            Instrument::Deposit(inst) => inst.npv(disc_curve, forecast_curve),
            Instrument::IRFuture(inst) => inst.npv(disc_curve, forecast_curve),
            Instrument::Bond(inst) => inst.npv(disc_curve, forecast_curve),
            Instrument::CDS(inst) => inst.npv(disc_curve, forecast_curve),
            Instrument::XCS(inst) => {
                let fxr = fx_rates.expect("XCS requires fx_rates");
                let l2d = leg2_disc_curve.expect("XCS requires leg2_disc_curve");
                let l2f = leg2_forecast_curve.unwrap_or(l2d);
                inst.npv(disc_curve, forecast_curve, l2d, l2f, fxr)
            }
            Instrument::FXForward(inst) => {
                let fxr = fx_rates.expect("FXForward requires fx_rates");
                inst.npv(disc_curve, forecast_curve, fxr)
            }
            Instrument::AssetSwap(inst) => inst.npv(disc_curve, forecast_curve),
            Instrument::CallableBond(inst) => inst.npv(disc_curve, forecast_curve),
            Instrument::NDF(inst) => {
                let fxr = fx_rates.expect("NDF requires fx_rates");
                inst.ndf_npv(disc_curve, forecast_curve, fxr)
            }
            Instrument::NDIRS(inst) => {
                let fxr = fx_rates.expect("NDIRS requires fx_rates");
                let l2d = leg2_disc_curve.expect("NDIRS requires leg2_disc_curve");
                inst.ndirs_npv(disc_curve, forecast_curve, l2d, fxr)
            }
            Instrument::NDXCS(inst) => {
                let fxr = fx_rates.expect("NDXCS requires fx_rates");
                let l2d = leg2_disc_curve.expect("NDXCS requires leg2_disc_curve");
                let l2f = leg2_forecast_curve.unwrap_or(l2d);
                inst.ndxcs_npv(disc_curve, forecast_curve, l2d, l2f, fxr)
            }
        }
    }

    /// Collect cashflow rows.
    pub fn cashflows(
        &self,
        disc_curve: Option<&dyn CurveQuery>,
        forecast_curve: Option<&dyn CurveQuery>,
        fx_rates: Option<&FXRates>,
        leg2_disc_curve: Option<&dyn CurveQuery>,
        leg2_forecast_curve: Option<&dyn CurveQuery>,
    ) -> Vec<CashflowRow> {
        match self {
            Instrument::IRS(inst) => inst.cashflows(disc_curve, forecast_curve),
            Instrument::FRA(inst) => inst.cashflows(disc_curve, forecast_curve),
            Instrument::ZCS(inst) => inst.cashflows(disc_curve, forecast_curve),
            Instrument::SBS(inst) => inst.cashflows(disc_curve, forecast_curve),
            Instrument::OIS(inst) => inst.cashflows(disc_curve, forecast_curve),
            Instrument::Deposit(inst) => inst.cashflows(disc_curve, forecast_curve),
            Instrument::IRFuture(inst) => inst.cashflows(disc_curve, forecast_curve),
            Instrument::Bond(inst) => inst.cashflows(disc_curve, forecast_curve),
            Instrument::CDS(inst) => inst.cashflows(disc_curve, forecast_curve),
            Instrument::XCS(inst) => {
                inst.cashflows(disc_curve, forecast_curve, leg2_disc_curve, leg2_forecast_curve)
            }
            Instrument::FXForward(inst) => {
                inst.cashflows(disc_curve, forecast_curve, fx_rates)
            }
            Instrument::AssetSwap(inst) => {
                let dc = disc_curve.expect("AssetSwap requires disc_curve");
                let fc = forecast_curve.expect("AssetSwap requires forecast_curve");
                inst.cashflows(dc, fc)
            }
            Instrument::CallableBond(inst) => inst.cashflows(disc_curve, forecast_curve),
            Instrument::NDF(inst) => {
                inst.ndf_cashflows(disc_curve, forecast_curve, fx_rates)
            }
            Instrument::NDIRS(inst) => {
                inst.ndirs_cashflows(disc_curve, forecast_curve, leg2_disc_curve, fx_rates)
            }
            Instrument::NDXCS(inst) => {
                inst.ndxcs_cashflows(disc_curve, forecast_curve, leg2_disc_curve, leg2_forecast_curve, fx_rates)
            }
        }
    }

    /// Compute spread in basis points.
    pub fn spread(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
        fx_rates: Option<&FXRates>,
        leg2_disc_curve: Option<&dyn CurveQuery>,
        leg2_forecast_curve: Option<&dyn CurveQuery>,
    ) -> Number {
        match self {
            Instrument::IRS(inst) => inst.spread(disc_curve, forecast_curve),
            Instrument::FRA(inst) => inst.spread(disc_curve, forecast_curve),
            Instrument::ZCS(inst) => inst.spread(disc_curve, forecast_curve),
            Instrument::SBS(inst) => inst.spread(disc_curve, forecast_curve),
            Instrument::OIS(inst) => inst.spread(disc_curve, forecast_curve),
            Instrument::Deposit(inst) => inst.spread(disc_curve, forecast_curve),
            Instrument::IRFuture(inst) => inst.spread(disc_curve, forecast_curve),
            Instrument::Bond(inst) => inst.spread(disc_curve, forecast_curve),
            Instrument::CDS(inst) => inst.spread(disc_curve, forecast_curve),
            Instrument::XCS(inst) => {
                let fxr = fx_rates.expect("XCS requires fx_rates");
                let l2d = leg2_disc_curve.expect("XCS requires leg2_disc_curve");
                let l2f = leg2_forecast_curve.unwrap_or(l2d);
                inst.spread(disc_curve, forecast_curve, l2d, l2f, fxr)
            }
            Instrument::FXForward(inst) => {
                let fxr = fx_rates.expect("FXForward requires fx_rates");
                inst.spread(disc_curve, forecast_curve, fxr)
            }
            Instrument::AssetSwap(inst) => inst.spread(disc_curve, forecast_curve),
            Instrument::CallableBond(inst) => inst.spread(disc_curve, forecast_curve),
            Instrument::NDF(inst) => {
                let fxr = fx_rates.expect("NDF requires fx_rates");
                inst.ndf_spread(disc_curve, forecast_curve, fxr)
            }
            Instrument::NDIRS(inst) => {
                let fxr = fx_rates.expect("NDIRS requires fx_rates");
                let l2d = leg2_disc_curve.expect("NDIRS requires leg2_disc_curve");
                inst.ndirs_spread(disc_curve, forecast_curve, l2d, fxr)
            }
            Instrument::NDXCS(inst) => {
                let fxr = fx_rates.expect("NDXCS requires fx_rates");
                let l2d = leg2_disc_curve.expect("NDXCS requires leg2_disc_curve");
                let l2f = leg2_forecast_curve.unwrap_or(l2d);
                inst.ndxcs_spread(disc_curve, forecast_curve, l2d, l2f, fxr)
            }
        }
    }

    /// Return the pillar date (maturity date for curve construction).
    pub fn pillar_date(&self) -> NaiveDate {
        match self {
            Instrument::IRS(inst) => inst.pillar_date(),
            Instrument::FRA(inst) => inst.pillar_date(),
            Instrument::ZCS(inst) => inst.pillar_date(),
            Instrument::SBS(inst) => inst.pillar_date(),
            Instrument::OIS(inst) => inst.pillar_date(),
            Instrument::Deposit(inst) => inst.pillar_date(),
            Instrument::IRFuture(inst) => inst.pillar_date(),
            Instrument::Bond(inst) => inst.pillar_date(),
            Instrument::CDS(inst) => inst.pillar_date(),
            Instrument::XCS(inst) => inst.pillar_date(),
            Instrument::FXForward(inst) => inst.pillar_date(),
            Instrument::AssetSwap(inst) => inst.pillar_date(),
            Instrument::CallableBond(inst) => inst.pillar_date(),
            Instrument::NDF(inst) => inst.pillar_date(),
            Instrument::NDIRS(inst) => inst.pillar_date(),
            Instrument::NDXCS(inst) => inst.pillar_date(),
        }
    }

    /// Analytic delta: sensitivity to a 1bp rate change for all instrument types.
    pub fn analytic_delta(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        match self {
            Instrument::IRS(inst) => {
                let fixed_ad = inst.fixed_leg.analytic_delta(disc_curve);
                let float_ad = inst.float_leg.analytic_delta(disc_curve);
                fixed_ad + float_ad
            }
            Instrument::FRA(inst) => {
                let fixed_ad = inst.fixed_period.analytic_delta(disc_curve);
                let float_ad = inst.float_period.analytic_delta(disc_curve);
                fixed_ad + float_ad
            }
            Instrument::ZCS(inst) => {
                let fixed_ad = inst.fixed_leg.analytic_delta(disc_curve);
                let float_ad = inst.float_leg.analytic_delta(disc_curve);
                fixed_ad + float_ad
            }
            Instrument::SBS(inst) => {
                let leg1_ad = inst.leg1.analytic_delta(disc_curve);
                let leg2_ad = inst.leg2.analytic_delta(disc_curve);
                leg1_ad + leg2_ad
            }
            Instrument::OIS(inst) => {
                let fixed_ad = inst.fixed_leg.analytic_delta(disc_curve);
                let float_ad = inst.float_leg.analytic_delta(disc_curve);
                fixed_ad + float_ad
            }
            Instrument::Deposit(_inst) => {
                Number::F64(0.0)
            }
            Instrument::IRFuture(_inst) => {
                Number::F64(0.0)
            }
            Instrument::Bond(inst) => inst.analytic_delta(disc_curve, forecast_curve),
            Instrument::CDS(_inst) => {
                Number::F64(0.0)
            }
            Instrument::XCS(_inst) => {
                // XCS analytic delta requires 4 curves; return 0 from this 2-curve method
                Number::F64(0.0)
            }
            Instrument::FXForward(_inst) => {
                Number::F64(0.0)
            }
            Instrument::AssetSwap(inst) => inst.analytic_delta(disc_curve, forecast_curve),
            Instrument::CallableBond(inst) => inst.analytic_delta(disc_curve, forecast_curve),
            Instrument::NDF(_inst) => {
                Number::F64(0.0)
            }
            Instrument::NDIRS(_inst) => {
                // NDIRS analytic delta requires FX conversion; return 0 from this 2-curve method
                Number::F64(0.0)
            }
            Instrument::NDXCS(_inst) => {
                // NDXCS analytic delta requires FX conversion; return 0 from this 2-curve method
                Number::F64(0.0)
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::nodes::Nodes;
    use crate::calendar::convention::DayCountConvention;
    use indexmap::IndexMap;
    use chrono::NaiveDate;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn test_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
            (ymd(2027, 1, 1), 0.91),
            (ymd(2028, 1, 1), 0.88),
            (ymd(2029, 1, 1), 0.85),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "test".to_string(),
        )
    }

    #[test]
    fn test_instrument_enum_dispatch_irs() {
        let curve = test_curve();
        let irs = rates::irs::tests::make_test_irs();
        let inst = Instrument::IRS(irs);
        let rate = inst.rate(&curve, &curve, None, None, None);
        match rate {
            Number::F64(r) => assert!(r.is_finite(), "IRS rate should be finite"),
            _ => panic!("Expected F64"),
        }
        let npv = inst.npv(&curve, &curve, None, None, None);
        match npv {
            Number::F64(v) => assert!(v.is_finite(), "IRS NPV should be finite"),
            _ => panic!("Expected F64"),
        }
        let cfs = inst.cashflows(Some(&curve), Some(&curve), None, None, None);
        assert!(!cfs.is_empty(), "IRS should have cashflows");
        let spread = inst.spread(&curve, &curve, None, None, None);
        match spread {
            Number::F64(s) => assert!(s.is_finite(), "IRS spread should be finite"),
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_instrument_enum_dispatch_fra() {
        let curve = test_curve();
        let fra = rates::fra::tests::make_test_fra();
        let inst = Instrument::FRA(fra);
        let rate = inst.rate(&curve, &curve, None, None, None);
        match rate {
            Number::F64(r) => assert!(r > 0.0, "FRA rate should be positive"),
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_instrument_enum_dispatch_zcs() {
        let curve = test_curve();
        let zcs = rates::zcs::tests::make_test_zcs();
        let inst = Instrument::ZCS(zcs);
        let rate = inst.rate(&curve, &curve, None, None, None);
        match rate {
            Number::F64(r) => assert!(r.is_finite(), "ZCS rate should be finite"),
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_instrument_enum_dispatch_sbs() {
        let curve = test_curve();
        let sbs = rates::sbs::tests::make_test_sbs();
        let inst = Instrument::SBS(sbs);
        let rate = inst.rate(&curve, &curve, None, None, None);
        match rate {
            Number::F64(r) => assert!(r.is_finite(), "SBS rate should be finite"),
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_instrument_enum_dispatch_ois() {
        let curve = test_curve();
        let ois_inst = rates::ois::tests::make_test_ois();
        let inst = Instrument::OIS(ois_inst);
        let rate = inst.rate(&curve, &curve, None, None, None);
        match rate {
            Number::F64(r) => assert!(r.is_finite(), "OIS rate should be finite"),
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_instrument_enum_dispatch_deposit() {
        let curve = test_curve();
        let dep = rates::deposit::tests::make_test_deposit();
        let inst = Instrument::Deposit(dep);
        let rate = inst.rate(&curve, &curve, None, None, None);
        match rate {
            Number::F64(r) => assert!(r.is_finite(), "Deposit rate should be finite"),
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_instrument_enum_dispatch_ir_future() {
        let curve = test_curve();
        let fut = rates::future::tests::make_test_ir_future();
        let inst = Instrument::IRFuture(fut);
        let rate = inst.rate(&curve, &curve, None, None, None);
        match rate {
            Number::F64(r) => assert!(r > 0.0, "IRFuture rate should be positive"),
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_instrument_pillar_date() {
        let irs = rates::irs::tests::make_test_irs();
        let inst = Instrument::IRS(irs);
        let pillar = inst.pillar_date();
        assert!(pillar > ymd(2024, 1, 1), "Pillar should be after start");
    }

    #[test]
    fn test_instrument_enum_dispatch_xcs() {
        let xcs = fx::xcs::tests::make_test_xcs();
        let inst = Instrument::XCS(xcs);

        let usd_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
        ]));
        let usd = DiscountCurve::new(usd_nodes, Interpolator::LogLinear, DayCountConvention::Act365F, "usd".to_string());
        let eur_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.98),
            (ymd(2026, 1, 1), 0.96),
        ]));
        let eur = DiscountCurve::new(eur_nodes, Interpolator::LogLinear, DayCountConvention::Act365F, "eur".to_string());
        let fxr = FXRates::new(
            vec![(crate::marketcurves::fx::pair::FXPair::new("eur", "usd"), 1.1)],
            ymd(2024, 1, 15),
        );

        let rate = inst.rate(&eur, &eur, Some(&fxr), Some(&usd), Some(&usd));
        match rate {
            Number::Dual(d) => assert!(d.real.is_finite(), "XCS rate should be finite"),
            Number::F64(v) => assert!(v.is_finite(), "XCS rate should be finite"),
            _ => panic!("Unexpected variant"),
        }

        let pillar = inst.pillar_date();
        assert_eq!(pillar, ymd(2026, 1, 1));
    }

    #[test]
    fn test_serde_instrument_irs_roundtrip() {
        let irs = rates::irs::tests::make_test_irs();
        let inst = Instrument::IRS(irs);
        let json = serde_json::to_string(&inst).unwrap();
        let restored: Instrument = serde_json::from_str(&json).unwrap();
        // Verify structure by checking pillar date
        assert_eq!(inst.pillar_date(), restored.pillar_date());
        // Verify functional equivalence
        let curve = test_curve();
        let npv_orig = inst.npv(&curve, &curve, None, None, None);
        let npv_restored = restored.npv(&curve, &curve, None, None, None);
        if let (Number::F64(a), Number::F64(b)) = (&npv_orig, &npv_restored) {
            assert!((a - b).abs() < 1e-10, "NPV mismatch: {} vs {}", a, b);
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_instrument_enum_dispatch_ndf() {
        let ndf = fx::forward::tests::make_test_ndf();
        let inst = Instrument::NDF(ndf);

        let usd_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
        ]));
        let usd = DiscountCurve::new(usd_nodes, Interpolator::LogLinear, DayCountConvention::Act365F, "usd".to_string());
        let brl_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.88),
            (ymd(2026, 1, 1), 0.77),
        ]));
        let brl = DiscountCurve::new(brl_nodes, Interpolator::LogLinear, DayCountConvention::Act365F, "brl".to_string());
        let fxr = FXRates::new(
            vec![(crate::marketcurves::fx::pair::FXPair::new("usd", "brl"), 5.0)],
            ymd(2024, 1, 15),
        );

        // rate() should return the implied forward
        let rate = inst.rate(&usd, &brl, Some(&fxr), None, None);
        match &rate {
            Number::Dual(d) => assert!(d.real > 0.0, "NDF rate should be positive"),
            Number::F64(v) => assert!(*v > 0.0, "NDF rate should be positive"),
            _ => panic!("Unexpected variant"),
        }

        // npv() should return finite value
        let npv = inst.npv(&usd, &brl, Some(&fxr), None, None);
        match &npv {
            Number::Dual(d) => assert!(d.real.is_finite(), "NDF NPV should be finite"),
            Number::F64(v) => assert!(v.is_finite(), "NDF NPV should be finite"),
            _ => panic!("Unexpected variant"),
        }

        // cashflows() should return 2 rows
        let cfs = inst.cashflows(Some(&usd), Some(&brl), Some(&fxr), None, None);
        assert_eq!(cfs.len(), 2, "NDF should have 2 cashflow rows");
        assert_eq!(cfs[0].period_type, "NDF_Domestic");
        assert_eq!(cfs[1].period_type, "NDF_Foreign");

        // spread() should return forward points
        let spread = inst.spread(&usd, &brl, Some(&fxr), None, None);
        match &spread {
            Number::Dual(d) => assert!(d.real.is_finite(), "NDF spread should be finite"),
            Number::F64(v) => assert!(v.is_finite(), "NDF spread should be finite"),
            _ => panic!("Unexpected variant"),
        }

        // pillar_date() should return delivery
        let pillar = inst.pillar_date();
        assert_eq!(pillar, ymd(2025, 1, 1));
    }

    #[test]
    fn test_instrument_enum_dispatch_fx_forward() {
        let fwd = fx::forward::tests::make_test_fx_forward();
        let inst = Instrument::FXForward(fwd);

        let usd_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
        ]));
        let usd = DiscountCurve::new(usd_nodes, Interpolator::LogLinear, DayCountConvention::Act365F, "usd".to_string());
        let eur_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.98),
            (ymd(2026, 1, 1), 0.96),
        ]));
        let eur = DiscountCurve::new(eur_nodes, Interpolator::LogLinear, DayCountConvention::Act365F, "eur".to_string());
        let fxr = FXRates::new(
            vec![(crate::marketcurves::fx::pair::FXPair::new("eur", "usd"), 1.1)],
            ymd(2024, 1, 15),
        );

        let rate = inst.rate(&eur, &usd, Some(&fxr), None, None);
        match rate {
            Number::Dual(d) => assert!(d.real > 0.0, "FXForward rate should be positive, got {}", d.real),
            Number::F64(v) => assert!(v > 0.0, "FXForward rate should be positive, got {}", v),
            _ => panic!("Unexpected variant"),
        }

        let pillar = inst.pillar_date();
        assert_eq!(pillar, ymd(2025, 1, 1));
    }

    #[test]
    fn test_instrument_enum_dispatch_ndirs() {
        use crate::marketcurves::fx::pair::FXPair;
        use crate::marketcurves::fx::rates::FXRates;

        let ndirs = rates::irs::tests::make_test_ndirs();
        let inst = Instrument::NDIRS(ndirs);

        // USD (settlement) and BRL (restricted) curves
        let usd_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
            (ymd(2027, 1, 1), 0.91),
        ]));
        let usd = DiscountCurve::new(usd_nodes, Interpolator::LogLinear, DayCountConvention::Act365F, "usd".to_string());
        let brl_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.88),
            (ymd(2026, 1, 1), 0.77),
            (ymd(2027, 1, 1), 0.67),
        ]));
        let brl = DiscountCurve::new(brl_nodes, Interpolator::LogLinear, DayCountConvention::Act365F, "brl".to_string());
        let fxr = FXRates::new(
            vec![(FXPair::new("usd", "brl"), 5.0)],
            ymd(2024, 1, 1),
        );

        // rate() through dispatch
        let rate = inst.rate(&usd, &brl, Some(&fxr), Some(&brl), None);
        let r = match &rate {
            Number::Dual(d) => d.real,
            Number::F64(v) => *v,
            _ => panic!("Unexpected variant"),
        };
        assert!(r.is_finite() && r > 0.0, "NDIRS rate should be positive finite, got {r}");

        // npv() through dispatch
        let npv = inst.npv(&usd, &brl, Some(&fxr), Some(&brl), None);
        let v = match &npv {
            Number::Dual(d) => d.real,
            Number::F64(v) => *v,
            _ => panic!("Unexpected variant"),
        };
        assert!(v.is_finite(), "NDIRS NPV should be finite, got {v}");

        // cashflows() through dispatch
        let cfs = inst.cashflows(Some(&usd), Some(&brl), Some(&fxr), Some(&brl), None);
        assert!(!cfs.is_empty(), "NDIRS should have cashflows");
        // Verify settlement fields are populated
        assert!(cfs[0].settlement_amount.is_some(), "settlement_amount should be Some");
        assert!(cfs[0].fx_rate.is_some(), "fx_rate should be Some");

        // spread() through dispatch
        let spread = inst.spread(&usd, &brl, Some(&fxr), Some(&brl), None);
        let s = match &spread {
            Number::Dual(d) => d.real,
            Number::F64(v) => *v,
            _ => panic!("Unexpected variant"),
        };
        assert!(s.is_finite(), "NDIRS spread should be finite, got {s}");

        // pillar_date() through dispatch
        let pillar = inst.pillar_date();
        assert_eq!(pillar, ymd(2026, 1, 1));
    }

    #[test]
    fn test_serde_instrument_ndirs_roundtrip() {
        let ndirs = rates::irs::tests::make_test_ndirs();
        let inst = Instrument::NDIRS(ndirs);
        let json = serde_json::to_string(&inst).unwrap();
        let restored: Instrument = serde_json::from_str(&json).unwrap();
        assert_eq!(inst.pillar_date(), restored.pillar_date());
    }

    #[test]
    fn test_instrument_enum_dispatch_ndxcs() {
        use crate::marketcurves::fx::pair::FXPair;
        use crate::marketcurves::fx::rates::FXRates;

        let ndxcs = fx::xcs::tests::make_test_ndxcs();
        let inst = Instrument::NDXCS(ndxcs);

        // USD (settlement) and BRL (restricted) curves
        let usd_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
        ]));
        let usd = DiscountCurve::new(usd_nodes, Interpolator::LogLinear, DayCountConvention::Act365F, "usd".to_string());
        let brl_nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.88),
            (ymd(2026, 1, 1), 0.77),
        ]));
        let brl = DiscountCurve::new(brl_nodes, Interpolator::LogLinear, DayCountConvention::Act365F, "brl".to_string());
        let fxr = FXRates::new(
            vec![(FXPair::new("usd", "brl"), 5.0)],
            ymd(2024, 1, 1),
        );

        // rate() through dispatch
        let rate = inst.rate(&usd, &usd, Some(&fxr), Some(&brl), Some(&brl));
        let r = match &rate {
            Number::Dual(d) => d.real,
            Number::F64(v) => *v,
            _ => panic!("Unexpected variant"),
        };
        assert!(r.is_finite(), "NDXCS rate should be finite, got {r}");

        // npv() through dispatch
        let npv = inst.npv(&usd, &usd, Some(&fxr), Some(&brl), Some(&brl));
        let v = match &npv {
            Number::Dual(d) => d.real,
            Number::F64(v) => *v,
            _ => panic!("Unexpected variant"),
        };
        assert!(v.is_finite(), "NDXCS NPV should be finite, got {v}");

        // cashflows() through dispatch
        let cfs = inst.cashflows(Some(&usd), Some(&usd), Some(&fxr), Some(&brl), Some(&brl));
        assert!(!cfs.is_empty(), "NDXCS should have cashflows");

        // spread() through dispatch
        let spread = inst.spread(&usd, &usd, Some(&fxr), Some(&brl), Some(&brl));
        let s = match &spread {
            Number::Dual(d) => d.real,
            Number::F64(v) => *v,
            _ => panic!("Unexpected variant"),
        };
        assert!(s.is_finite(), "NDXCS spread should be finite, got {s}");

        // pillar_date() through dispatch
        let pillar = inst.pillar_date();
        assert_eq!(pillar, ymd(2026, 1, 1));
    }

    #[test]
    fn test_serde_instrument_ndxcs_roundtrip() {
        let ndxcs = fx::xcs::tests::make_test_ndxcs();
        let inst = Instrument::NDXCS(ndxcs);
        let json = serde_json::to_string(&inst).unwrap();
        let restored: Instrument = serde_json::from_str(&json).unwrap();
        assert_eq!(inst.pillar_date(), restored.pillar_date());
    }
}
