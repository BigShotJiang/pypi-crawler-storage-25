use std::collections::HashMap;

use chrono::NaiveDate;
use serde::{Serialize, Deserialize};

use crate::autodiff::enums::Number;
use crate::calendar::cal::BusinessCalendar;
use crate::calendar::convention::{DayCountConvention, DcfOptions};
use crate::calendar::dateroll::add_business_days;
use crate::marketcurves::curve::CurveQuery;

/// RFR fixing method variants: 4 compounding + 4 averaging.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub enum FixingMethod {
    RFRPaymentDelay,
    RFRObservationShift(i32),
    RFRLockout(i32),
    RFRLookback(i32),
    RFRPaymentDelayAverage,
    RFRObservationShiftAverage(i32),
    RFRLookoutAverage(i32),
    RFRLookbackAverage(i32),
}

/// How spread is applied in RFR compounding.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub enum SpreadMethod {
    /// Spread added after compounding: (compounded_rate + spread)
    NoneSimple,
    /// Spread compounds with rate at each step: compound(rate_i + spread)
    ISDACompounding,
}

impl Default for SpreadMethod {
    fn default() -> Self {
        SpreadMethod::NoneSimple
    }
}

/// Look up an overnight rate: first try historical fixings, then fallback to curve.
fn overnight_rate(
    obs_date: NaiveDate,
    obs_next: NaiveDate,
    curve: &dyn CurveQuery,
    fixings: Option<&HashMap<NaiveDate, f64>>,
) -> Number {
    if let Some(rate) = fixings.and_then(|f| f.get(&obs_date)) {
        Number::F64(*rate / 100.0)
    } else {
        curve.forward_rate(obs_date, obs_next)
    }
}

/// Generate the list of business day dates from start (inclusive) to end (exclusive).
fn business_day_sequence(
    start: NaiveDate,
    end: NaiveDate,
    cal: &BusinessCalendar,
) -> Vec<NaiveDate> {
    let mut dates = Vec::new();
    let mut current = start;
    while current < end {
        dates.push(current);
        current = add_business_days(current, 1, cal);
    }
    dates
}

/// Compute RFR compounded rate for a period.
///
/// Returns the annualized rate as a Number (AD-aware when curve has Dual nodes).
/// The rate is NOT in percentage form -- it's the decimal rate.
pub fn rfr_rate(
    method: &FixingMethod,
    start: NaiveDate,
    end: NaiveDate,
    convention: &DayCountConvention,
    curve: &dyn CurveQuery,
    fixings: Option<&HashMap<NaiveDate, f64>>,
    spread: f64,
    spread_method: &SpreadMethod,
    calendar: &BusinessCalendar,
) -> Number {
    let spread_decimal = spread / 100.0;
    let dcf_opts = DcfOptions::default();
    let total_dcf = convention.dcf(start, end, &dcf_opts).unwrap();

    match method {
        FixingMethod::RFRPaymentDelay => {
            rfr_compound(start, end, start, end, convention, curve, fixings, spread_decimal, spread_method, calendar, total_dcf)
        }
        FixingMethod::RFRPaymentDelayAverage => {
            rfr_average(start, end, start, end, convention, curve, fixings, spread_decimal, spread_method, calendar, total_dcf)
        }
        FixingMethod::RFRObservationShift(shift) => {
            let obs_start = add_business_days(start, -*shift, calendar);
            let obs_end = add_business_days(end, -*shift, calendar);
            rfr_compound_obs_shift(obs_start, obs_end, convention, curve, fixings, spread_decimal, spread_method, calendar, total_dcf)
        }
        FixingMethod::RFRObservationShiftAverage(shift) => {
            let obs_start = add_business_days(start, -*shift, calendar);
            let obs_end = add_business_days(end, -*shift, calendar);
            rfr_average_obs_shift(obs_start, obs_end, convention, curve, fixings, spread_decimal, spread_method, calendar, total_dcf)
        }
        FixingMethod::RFRLockout(lockout_days) => {
            rfr_compound_lockout(start, end, *lockout_days, convention, curve, fixings, spread_decimal, spread_method, calendar, total_dcf)
        }
        FixingMethod::RFRLookoutAverage(lockout_days) => {
            rfr_average_lockout(start, end, *lockout_days, convention, curve, fixings, spread_decimal, spread_method, calendar, total_dcf)
        }
        FixingMethod::RFRLookback(lookback_days) => {
            rfr_compound_lookback(start, end, *lookback_days, convention, curve, fixings, spread_decimal, spread_method, calendar, total_dcf)
        }
        FixingMethod::RFRLookbackAverage(lookback_days) => {
            rfr_average_lookback(start, end, *lookback_days, convention, curve, fixings, spread_decimal, spread_method, calendar, total_dcf)
        }
    }
}

/// Standard compounding: observation window = accrual window.
fn rfr_compound(
    _accrual_start: NaiveDate,
    _accrual_end: NaiveDate,
    obs_start: NaiveDate,
    obs_end: NaiveDate,
    convention: &DayCountConvention,
    curve: &dyn CurveQuery,
    fixings: Option<&HashMap<NaiveDate, f64>>,
    spread: f64,
    spread_method: &SpreadMethod,
    calendar: &BusinessCalendar,
    total_dcf: f64,
) -> Number {
    let dcf_opts = DcfOptions::default();
    let mut compounded = Number::F64(1.0);
    let mut current = obs_start;

    while current < obs_end {
        let next = add_business_days(current, 1, calendar);
        let dcf_i = convention.dcf(current, next, &dcf_opts).unwrap();
        let rate_i = overnight_rate(current, next, curve, fixings);

        match spread_method {
            SpreadMethod::NoneSimple => {
                compounded = compounded * (1.0 + &rate_i * dcf_i);
            }
            SpreadMethod::ISDACompounding => {
                compounded = compounded * (1.0 + (&rate_i + spread) * dcf_i);
            }
        }
        current = next;
    }

    match spread_method {
        SpreadMethod::NoneSimple => (compounded - 1.0) / total_dcf + spread,
        SpreadMethod::ISDACompounding => (compounded - 1.0) / total_dcf,
    }
}

/// Standard averaging: observation window = accrual window.
fn rfr_average(
    _accrual_start: NaiveDate,
    _accrual_end: NaiveDate,
    obs_start: NaiveDate,
    obs_end: NaiveDate,
    convention: &DayCountConvention,
    curve: &dyn CurveQuery,
    fixings: Option<&HashMap<NaiveDate, f64>>,
    spread: f64,
    _spread_method: &SpreadMethod,
    calendar: &BusinessCalendar,
    total_dcf: f64,
) -> Number {
    let dcf_opts = DcfOptions::default();
    let mut weighted_sum = Number::F64(0.0);
    let mut current = obs_start;

    while current < obs_end {
        let next = add_business_days(current, 1, calendar);
        let dcf_i = convention.dcf(current, next, &dcf_opts).unwrap();
        let rate_i = overnight_rate(current, next, curve, fixings);
        weighted_sum = weighted_sum + rate_i * dcf_i;
        current = next;
    }

    weighted_sum / total_dcf + spread
}

/// Observation shift compounding: shift observation window back by N business days.
/// Observation dates shifted but accrual weights come from observation window (shifted).
fn rfr_compound_obs_shift(
    obs_start: NaiveDate,
    obs_end: NaiveDate,
    convention: &DayCountConvention,
    curve: &dyn CurveQuery,
    fixings: Option<&HashMap<NaiveDate, f64>>,
    spread: f64,
    spread_method: &SpreadMethod,
    calendar: &BusinessCalendar,
    total_dcf: f64,
) -> Number {
    let dcf_opts = DcfOptions::default();
    let mut compounded = Number::F64(1.0);
    let mut current = obs_start;

    while current < obs_end {
        let next = add_business_days(current, 1, calendar);
        let dcf_i = convention.dcf(current, next, &dcf_opts).unwrap();
        let rate_i = overnight_rate(current, next, curve, fixings);

        match spread_method {
            SpreadMethod::NoneSimple => {
                compounded = compounded * (1.0 + &rate_i * dcf_i);
            }
            SpreadMethod::ISDACompounding => {
                compounded = compounded * (1.0 + (&rate_i + spread) * dcf_i);
            }
        }
        current = next;
    }

    match spread_method {
        SpreadMethod::NoneSimple => (compounded - 1.0) / total_dcf + spread,
        SpreadMethod::ISDACompounding => (compounded - 1.0) / total_dcf,
    }
}

/// Observation shift averaging.
fn rfr_average_obs_shift(
    obs_start: NaiveDate,
    obs_end: NaiveDate,
    convention: &DayCountConvention,
    curve: &dyn CurveQuery,
    fixings: Option<&HashMap<NaiveDate, f64>>,
    spread: f64,
    _spread_method: &SpreadMethod,
    calendar: &BusinessCalendar,
    total_dcf: f64,
) -> Number {
    let dcf_opts = DcfOptions::default();
    let mut weighted_sum = Number::F64(0.0);
    let mut current = obs_start;

    while current < obs_end {
        let next = add_business_days(current, 1, calendar);
        let dcf_i = convention.dcf(current, next, &dcf_opts).unwrap();
        let rate_i = overnight_rate(current, next, curve, fixings);
        weighted_sum = weighted_sum + rate_i * dcf_i;
        current = next;
    }

    weighted_sum / total_dcf + spread
}

/// Lockout compounding: freeze the rate for the last N business days.
fn rfr_compound_lockout(
    start: NaiveDate,
    end: NaiveDate,
    lockout_days: i32,
    convention: &DayCountConvention,
    curve: &dyn CurveQuery,
    fixings: Option<&HashMap<NaiveDate, f64>>,
    spread: f64,
    spread_method: &SpreadMethod,
    calendar: &BusinessCalendar,
    total_dcf: f64,
) -> Number {
    let dcf_opts = DcfOptions::default();
    let dates = business_day_sequence(start, end, calendar);
    let n = dates.len();

    // Determine the lockout cutoff date (N business days before end)
    let lockout_start_idx = if n > lockout_days as usize {
        n - lockout_days as usize
    } else {
        0
    };

    let mut compounded = Number::F64(1.0);
    let mut lockout_rate: Option<Number> = None;

    for (i, &current) in dates.iter().enumerate() {
        let next = if i + 1 < n {
            dates[i + 1]
        } else {
            end
        };
        let dcf_i = convention.dcf(current, next, &dcf_opts).unwrap();

        let rate_i = if i >= lockout_start_idx {
            // Use the frozen rate
            lockout_rate.clone().unwrap_or(Number::F64(0.0))
        } else {
            let r = overnight_rate(current, next, curve, fixings);
            if i + 1 == lockout_start_idx {
                lockout_rate = Some(r.clone());
            }
            r
        };

        // If we're at the last date before lockout, capture the rate
        if i + 1 == lockout_start_idx && lockout_rate.is_none() {
            lockout_rate = Some(rate_i.clone());
        }

        match spread_method {
            SpreadMethod::NoneSimple => {
                compounded = compounded * (1.0 + &rate_i * dcf_i);
            }
            SpreadMethod::ISDACompounding => {
                compounded = compounded * (1.0 + (&rate_i + spread) * dcf_i);
            }
        }
    }

    match spread_method {
        SpreadMethod::NoneSimple => (compounded - 1.0) / total_dcf + spread,
        SpreadMethod::ISDACompounding => (compounded - 1.0) / total_dcf,
    }
}

/// Lockout averaging.
fn rfr_average_lockout(
    start: NaiveDate,
    end: NaiveDate,
    lockout_days: i32,
    convention: &DayCountConvention,
    curve: &dyn CurveQuery,
    fixings: Option<&HashMap<NaiveDate, f64>>,
    spread: f64,
    _spread_method: &SpreadMethod,
    calendar: &BusinessCalendar,
    total_dcf: f64,
) -> Number {
    let dcf_opts = DcfOptions::default();
    let dates = business_day_sequence(start, end, calendar);
    let n = dates.len();
    let lockout_start_idx = if n > lockout_days as usize {
        n - lockout_days as usize
    } else {
        0
    };

    let mut weighted_sum = Number::F64(0.0);
    let mut lockout_rate: Option<Number> = None;

    for (i, &current) in dates.iter().enumerate() {
        let next = if i + 1 < n { dates[i + 1] } else { end };
        let dcf_i = convention.dcf(current, next, &dcf_opts).unwrap();

        let rate_i = if i >= lockout_start_idx {
            lockout_rate.clone().unwrap_or(Number::F64(0.0))
        } else {
            let r = overnight_rate(current, next, curve, fixings);
            if i + 1 == lockout_start_idx {
                lockout_rate = Some(r.clone());
            }
            r
        };

        if i + 1 == lockout_start_idx && lockout_rate.is_none() {
            lockout_rate = Some(rate_i.clone());
        }

        weighted_sum = weighted_sum + rate_i * dcf_i;
    }

    weighted_sum / total_dcf + spread
}

/// Lookback compounding: shift observation dates back by N business days,
/// but keep original accrual day count fractions.
fn rfr_compound_lookback(
    start: NaiveDate,
    end: NaiveDate,
    lookback_days: i32,
    convention: &DayCountConvention,
    curve: &dyn CurveQuery,
    fixings: Option<&HashMap<NaiveDate, f64>>,
    spread: f64,
    spread_method: &SpreadMethod,
    calendar: &BusinessCalendar,
    total_dcf: f64,
) -> Number {
    let dcf_opts = DcfOptions::default();
    let mut compounded = Number::F64(1.0);
    let mut current = start;

    while current < end {
        let next = add_business_days(current, 1, calendar);
        let dcf_i = convention.dcf(current, next, &dcf_opts).unwrap();

        // Observation dates shifted back
        let obs_date = add_business_days(current, -lookback_days, calendar);
        let obs_next = add_business_days(next, -lookback_days, calendar);
        let rate_i = overnight_rate(obs_date, obs_next, curve, fixings);

        match spread_method {
            SpreadMethod::NoneSimple => {
                compounded = compounded * (1.0 + &rate_i * dcf_i);
            }
            SpreadMethod::ISDACompounding => {
                compounded = compounded * (1.0 + (&rate_i + spread) * dcf_i);
            }
        }
        current = next;
    }

    match spread_method {
        SpreadMethod::NoneSimple => (compounded - 1.0) / total_dcf + spread,
        SpreadMethod::ISDACompounding => (compounded - 1.0) / total_dcf,
    }
}

/// Lookback averaging.
fn rfr_average_lookback(
    start: NaiveDate,
    end: NaiveDate,
    lookback_days: i32,
    convention: &DayCountConvention,
    curve: &dyn CurveQuery,
    fixings: Option<&HashMap<NaiveDate, f64>>,
    spread: f64,
    _spread_method: &SpreadMethod,
    calendar: &BusinessCalendar,
    total_dcf: f64,
) -> Number {
    let dcf_opts = DcfOptions::default();
    let mut weighted_sum = Number::F64(0.0);
    let mut current = start;

    while current < end {
        let next = add_business_days(current, 1, calendar);
        let dcf_i = convention.dcf(current, next, &dcf_opts).unwrap();

        let obs_date = add_business_days(current, -lookback_days, calendar);
        let obs_next = add_business_days(next, -lookback_days, calendar);
        let rate_i = overnight_rate(obs_date, obs_next, curve, fixings);

        weighted_sum = weighted_sum + rate_i * dcf_i;
        current = next;
    }

    weighted_sum / total_dcf + spread
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::nodes::Nodes;
    use crate::marketcurves::interpolation::Interpolator;
    use indexmap::IndexMap;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn test_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "test".to_string(),
        )
    }

    #[test]
    fn test_fixing_method_8_variants() {
        let methods = vec![
            FixingMethod::RFRPaymentDelay,
            FixingMethod::RFRObservationShift(2),
            FixingMethod::RFRLockout(2),
            FixingMethod::RFRLookback(2),
            FixingMethod::RFRPaymentDelayAverage,
            FixingMethod::RFRObservationShiftAverage(2),
            FixingMethod::RFRLookoutAverage(2),
            FixingMethod::RFRLookbackAverage(2),
        ];
        assert_eq!(methods.len(), 8);
    }

    #[test]
    fn test_rfr_rate_payment_delay() {
        let curve = test_curve();
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let rate = rfr_rate(
            &FixingMethod::RFRPaymentDelay,
            ymd(2024, 6, 3),
            ymd(2024, 6, 10),
            &DayCountConvention::Act360,
            &curve,
            None,
            0.0,
            &SpreadMethod::NoneSimple,
            &cal,
        );
        if let Number::F64(r) = rate {
            assert!(r > 0.0, "RFR rate should be positive, got {r}");
        } else {
            panic!("Expected F64 from curve without AD");
        }
    }

    #[test]
    fn test_rfr_rate_with_spread() {
        let curve = test_curve();
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let rate_no_spread = rfr_rate(
            &FixingMethod::RFRPaymentDelay,
            ymd(2024, 6, 3),
            ymd(2024, 6, 10),
            &DayCountConvention::Act360,
            &curve,
            None,
            0.0,
            &SpreadMethod::NoneSimple,
            &cal,
        );
        let rate_with_spread = rfr_rate(
            &FixingMethod::RFRPaymentDelay,
            ymd(2024, 6, 3),
            ymd(2024, 6, 10),
            &DayCountConvention::Act360,
            &curve,
            None,
            0.5, // 50bp spread
            &SpreadMethod::NoneSimple,
            &cal,
        );
        if let (Number::F64(r1), Number::F64(r2)) = (&rate_no_spread, &rate_with_spread) {
            assert!((r2 - r1 - 0.005).abs() < 1e-10, "Spread should add 0.005 (50bp)");
        }
    }
}
