use pyo3::prelude::*;
use pyo3::exceptions::PyValueError;
use super::{brent, newton_raphson};

/// Brent's method root finder for Python callables.
///
/// Finds x such that f(x) = 0, where f is a Python callable.
#[pyfunction]
#[pyo3(signature = (f, a, b, tol = 1e-12, max_iter = 200))]
fn brent_solve(py: Python<'_>, f: Py<PyAny>, a: f64, b: f64, tol: f64, max_iter: usize) -> PyResult<f64> {
    let result = brent(
        |x| {
            f.call1(py, (x,))
                .and_then(|r| r.extract::<f64>(py))
                .unwrap_or(f64::NAN)
        },
        a, b, tol, max_iter,
    );
    result.map_err(|e| PyValueError::new_err(e))
}

/// Newton-Raphson root finder for Python callables.
///
/// Finds x such that f(x) = 0, where f is a Python callable that returns (value, derivative).
#[pyfunction]
#[pyo3(signature = (f, x0, tol = 1e-12, max_iter = 200))]
fn newton_raphson_solve(py: Python<'_>, f: Py<PyAny>, x0: f64, tol: f64, max_iter: usize) -> PyResult<f64> {
    let result = newton_raphson(
        |x| {
            let result = f.call1(py, (x,)).unwrap();
            let tuple: (f64, f64) = result.extract(py).unwrap();
            tuple
        },
        x0, tol, max_iter,
    );
    result.map_err(|e| PyValueError::new_err(e))
}

pub fn register_module(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(brent_solve, m)?)?;
    m.add_function(wrap_pyfunction!(newton_raphson_solve, m)?)?;
    Ok(())
}
