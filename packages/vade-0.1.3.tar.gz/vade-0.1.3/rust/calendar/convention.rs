use chrono::{Datelike, NaiveDate};
use serde::{Serialize, Deserialize};

use super::cal::BusinessCalendar;

/// Day count convention options for computing accrual fractions.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum DayCountConvention {
    Act360,
    Act365F,
    Act365_25,
    Act364,
    ActActISDA,
    Thirty360,
    ThirtyE360,
    ThirtyE360ISDA,
    Bus252,
    One,
}

/// Optional parameters for day count fraction computation.
pub struct DcfOptions<'a> {
    pub calendar: Option<&'a BusinessCalendar>,
    pub termination: Option<NaiveDate>,
}

impl Default for DcfOptions<'_> {
    fn default() -> Self {
        DcfOptions {
            calendar: None,
            termination: None,
        }
    }
}

impl DayCountConvention {
    /// Compute the day count fraction between two dates.
    pub fn dcf(&self, start: NaiveDate, end: NaiveDate, opts: &DcfOptions) -> Result<f64, String> {
        match self {
            DayCountConvention::Act360 => Ok(dcf_act_numeric(360.0, start, end)),
            DayCountConvention::Act365F => Ok(dcf_act_numeric(365.0, start, end)),
            DayCountConvention::Act365_25 => Ok(dcf_act_numeric(365.25, start, end)),
            DayCountConvention::Act364 => Ok(dcf_act_numeric(364.0, start, end)),
            DayCountConvention::ActActISDA => Ok(dcf_act_isda(start, end)),
            DayCountConvention::Thirty360 => Ok(dcf_30360(start, end)),
            DayCountConvention::ThirtyE360 => Ok(dcf_30e360(start, end)),
            DayCountConvention::ThirtyE360ISDA => dcf_30e360_isda(start, end, opts.termination),
            DayCountConvention::Bus252 => {
                let cal = opts
                    .calendar
                    .ok_or("Bus252 requires a calendar in DcfOptions")?;
                Ok(dcf_bus252(start, end, cal))
            }
            DayCountConvention::One => Ok(1.0),
        }
    }
}

fn dcf_act_numeric(denominator: f64, start: NaiveDate, end: NaiveDate) -> f64 {
    (end - start).num_days() as f64 / denominator
}

fn dcf_act_isda(start: NaiveDate, end: NaiveDate) -> f64 {
    if start == end {
        return 0.0;
    }

    let is_start_leap = NaiveDate::from_ymd_opt(start.year(), 2, 29).is_some();
    let is_end_leap = NaiveDate::from_ymd_opt(end.year(), 2, 29).is_some();

    let year_1_days = if is_start_leap { 366.0 } else { 365.0 };
    let year_2_days = if is_end_leap { 366.0 } else { 365.0 };

    if start.year() == end.year() {
        return (end - start).num_days() as f64 / year_1_days;
    }

    let start_year_end = NaiveDate::from_ymd_opt(start.year() + 1, 1, 1).unwrap();
    let end_year_start = NaiveDate::from_ymd_opt(end.year(), 1, 1).unwrap();

    let mut total = (end.year() - start.year()) as f64 - 1.0;
    total += (start_year_end - start).num_days() as f64 / year_1_days;
    total += (end - end_year_start).num_days() as f64 / year_2_days;
    total
}

/// 30/360 unadjusted formula.
fn dcf_30360_unadjusted(ys: i32, ms: u32, ds: u32, ye: i32, me: u32, de: u32) -> f64 {
    (ye - ys) as f64 + (me as f64 - ms as f64) / 12.0 + (de as f64 - ds as f64) / 360.0
}

fn dcf_30360(start: NaiveDate, end: NaiveDate) -> f64 {
    let ds = u32::min(30, start.day());
    let de = if ds == 30 {
        u32::min(30, end.day())
    } else {
        end.day()
    };
    dcf_30360_unadjusted(start.year(), start.month(), ds, end.year(), end.month(), de)
}

fn dcf_30e360(start: NaiveDate, end: NaiveDate) -> f64 {
    let ds = u32::min(30, start.day());
    let de = u32::min(30, end.day());
    dcf_30360_unadjusted(start.year(), start.month(), ds, end.year(), end.month(), de)
}

fn is_last_day_of_february(date: NaiveDate) -> bool {
    date.month() == 2 && date.day() == last_day_of_month(date.year(), 2)
}

fn last_day_of_month(year: i32, month: u32) -> u32 {
    if month == 12 {
        31
    } else {
        NaiveDate::from_ymd_opt(year, month + 1, 1)
            .unwrap()
            .pred_opt()
            .unwrap()
            .day()
    }
}

fn dcf_30e360_isda(
    start: NaiveDate,
    end: NaiveDate,
    termination: Option<NaiveDate>,
) -> Result<f64, String> {
    let mut ds = u32::min(30, start.day());
    if is_last_day_of_february(start) {
        ds = 30;
    }

    let mut de = u32::min(30, end.day());
    if is_last_day_of_february(end) {
        let termination =
            termination.ok_or("ThirtyE360ISDA requires termination date in DcfOptions")?;
        if end != termination {
            de = 30;
        }
    }

    Ok(dcf_30360_unadjusted(
        start.year(),
        start.month(),
        ds,
        end.year(),
        end.month(),
        de,
    ))
}

fn dcf_bus252(start: NaiveDate, end: NaiveDate, cal: &BusinessCalendar) -> f64 {
    cal.bus_day_count(start, end) as f64 / 252.0
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::NaiveDate;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    #[test]
    fn test_act360() {
        let dcf = DayCountConvention::Act360
            .dcf(ymd(2024, 1, 15), ymd(2024, 7, 15), &DcfOptions::default())
            .unwrap();
        assert_eq!(dcf, 182.0 / 360.0);
    }

    #[test]
    fn test_act365f() {
        let dcf = DayCountConvention::Act365F
            .dcf(ymd(2024, 1, 15), ymd(2024, 7, 15), &DcfOptions::default())
            .unwrap();
        assert_eq!(dcf, 182.0 / 365.0);
    }

    #[test]
    fn test_act365_25() {
        let dcf = DayCountConvention::Act365_25
            .dcf(ymd(2024, 1, 15), ymd(2024, 7, 15), &DcfOptions::default())
            .unwrap();
        assert_eq!(dcf, 182.0 / 365.25);
    }

    #[test]
    fn test_act364() {
        let dcf = DayCountConvention::Act364
            .dcf(ymd(2000, 1, 1), ymd(2000, 1, 21), &DcfOptions::default())
            .unwrap();
        assert_eq!(dcf, 20.0 / 364.0);
    }

    #[test]
    fn test_act_act_isda_same_year() {
        let dcf = DayCountConvention::ActActISDA
            .dcf(ymd(2024, 1, 1), ymd(2024, 7, 1), &DcfOptions::default())
            .unwrap();
        // 2024 is a leap year, 182 days / 366
        assert_eq!(dcf, 182.0 / 366.0);
    }

    #[test]
    fn test_act_act_isda_cross_year() {
        let dcf = DayCountConvention::ActActISDA
            .dcf(ymd(2023, 7, 1), ymd(2024, 7, 1), &DcfOptions::default())
            .unwrap();
        // 184 days in 2023 (non-leap, /365) + 182 days in 2024 (leap, /366)
        let expected = 184.0 / 365.0 + 182.0 / 366.0;
        assert!((dcf - expected).abs() < 1e-12);
    }

    #[test]
    fn test_act_act_isda_same_date() {
        let dcf = DayCountConvention::ActActISDA
            .dcf(ymd(2024, 1, 1), ymd(2024, 1, 1), &DcfOptions::default())
            .unwrap();
        assert_eq!(dcf, 0.0);
    }

    #[test]
    fn test_thirty360() {
        let dcf = DayCountConvention::Thirty360
            .dcf(ymd(2000, 1, 1), ymd(2000, 1, 21), &DcfOptions::default())
            .unwrap();
        assert_eq!(dcf, 20.0 / 360.0);
    }

    #[test]
    fn test_thirty360_cross_month() {
        let dcf = DayCountConvention::Thirty360
            .dcf(ymd(2000, 1, 1), ymd(2001, 3, 21), &DcfOptions::default())
            .unwrap();
        assert_eq!(dcf, 1.0 + 2.0 / 12.0 + 20.0 / 360.0);
    }

    #[test]
    fn test_thirty_e360() {
        let dcf = DayCountConvention::ThirtyE360
            .dcf(ymd(2024, 1, 31), ymd(2024, 3, 31), &DcfOptions::default())
            .unwrap();
        // ds=30, de=30 -> (30-30)/360 + 2/12 = 2/12
        assert_eq!(dcf, 2.0 / 12.0);
    }

    #[test]
    fn test_thirty_e360_isda() {
        let opts = DcfOptions {
            termination: Some(ymd(2025, 2, 28)),
            ..Default::default()
        };
        let dcf = DayCountConvention::ThirtyE360ISDA
            .dcf(ymd(2024, 2, 29), ymd(2025, 2, 28), &opts)
            .unwrap();
        // start: Feb 29 is last day of Feb -> ds=30
        // end: Feb 28 is last day of Feb and IS termination -> de=28
        let expected = dcf_30360_unadjusted(2024, 2, 30, 2025, 2, 28);
        assert_eq!(dcf, expected);
    }

    #[test]
    fn test_thirty_e360_isda_non_termination() {
        let opts = DcfOptions {
            termination: Some(ymd(2026, 2, 28)),
            ..Default::default()
        };
        let dcf = DayCountConvention::ThirtyE360ISDA
            .dcf(ymd(2024, 2, 29), ymd(2025, 2, 28), &opts)
            .unwrap();
        // end: Feb 28 is last day of Feb and NOT termination -> de=30
        let expected = dcf_30360_unadjusted(2024, 2, 30, 2025, 2, 30);
        assert_eq!(dcf, expected);
    }

    #[test]
    fn test_bus252() {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let opts = DcfOptions {
            calendar: Some(&cal),
            ..Default::default()
        };
        // Mon Jan 1 to Mon Jan 8 = 5 business days -> 5/252
        let dcf = DayCountConvention::Bus252
            .dcf(ymd(2024, 1, 1), ymd(2024, 1, 8), &opts)
            .unwrap();
        assert_eq!(dcf, 5.0 / 252.0);
    }

    #[test]
    fn test_bus252_requires_calendar() {
        let result = DayCountConvention::Bus252.dcf(
            ymd(2024, 1, 1),
            ymd(2024, 1, 8),
            &DcfOptions::default(),
        );
        assert!(result.is_err());
    }

    #[test]
    fn test_one() {
        let dcf = DayCountConvention::One
            .dcf(ymd(2024, 1, 1), ymd(2099, 12, 31), &DcfOptions::default())
            .unwrap();
        assert_eq!(dcf, 1.0);
    }
}
