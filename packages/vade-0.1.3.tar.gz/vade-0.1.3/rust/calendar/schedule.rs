use chrono::{Datelike, NaiveDate};
use serde::{Serialize, Deserialize};

use super::adjuster::Adjuster;
use super::cal::BusinessCalendar;
use super::frequency::{add_months, Frequency, RollDay};

/// Stub inference preference for schedule generation.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum StubInference {
    /// Prefer a short front stub (most common default).
    ShortFront,
    /// Prefer a long front stub.
    LongFront,
    /// Prefer a short back stub.
    ShortBack,
    /// Prefer a long back stub.
    LongBack,
}

/// What kind of stub exists in the schedule.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum StubType {
    ShortFront,
    LongFront,
    ShortBack,
    LongBack,
}

/// A financial schedule with regular contiguous periods and optional stubs.
///
/// The schedule generates period boundary dates from effective to termination,
/// applying roll day conventions and business day adjustment.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Schedule {
    /// Unadjusted effective date.
    pub effective: NaiveDate,
    /// Unadjusted termination date.
    pub termination: NaiveDate,
    /// Frequency of regular periods.
    pub frequency: Frequency,
    /// Calendar for business day adjustment.
    pub calendar: BusinessCalendar,
    /// Adjustment rule for dates.
    pub adjuster: Adjuster,
    /// Roll day convention.
    pub roll_day: RollDay,
    /// Period boundaries before business day adjustment.
    pub unadjusted_dates: Vec<NaiveDate>,
    /// Period boundaries after business day adjustment.
    pub adjusted_dates: Vec<NaiveDate>,
    /// What kind of stub was applied, if any.
    pub stub_type: Option<StubType>,
}

impl Schedule {
    /// Create a new schedule.
    ///
    /// # Arguments
    /// * `effective` - Start date of the schedule
    /// * `termination` - End date of the schedule
    /// * `frequency` - Period frequency
    /// * `calendar` - Business day calendar
    /// * `adjuster` - Business day adjustment rule
    /// * `roll_day` - Roll day convention (if None, inferred from termination or effective)
    /// * `front_stub` - Optional explicit front stub date
    /// * `back_stub` - Optional explicit back stub date
    /// * `stub_inference` - Stub inference preference (default: ShortFront)
    pub fn try_new(
        effective: NaiveDate,
        termination: NaiveDate,
        frequency: Frequency,
        calendar: BusinessCalendar,
        adjuster: Adjuster,
        roll_day: Option<RollDay>,
        front_stub: Option<NaiveDate>,
        back_stub: Option<NaiveDate>,
        stub_inference: StubInference,
    ) -> Result<Self, String> {
        if effective >= termination {
            return Err("Effective date must be before termination date".to_string());
        }

        if frequency == Frequency::ZeroCoupon {
            // Zero coupon: just two dates
            let unadjusted_dates = vec![effective, termination];
            let adjusted_dates = unadjusted_dates
                .iter()
                .map(|d| adjuster.adjust(*d, &calendar))
                .collect();
            return Ok(Schedule {
                effective,
                termination,
                frequency,
                calendar,
                adjuster,
                roll_day: roll_day.unwrap_or(RollDay::Day(termination.day())),
                unadjusted_dates,
                adjusted_dates,
                stub_type: None,
            });
        }

        let months = frequency.months() as i32;
        if months == 0 {
            return Err("Frequency must have non-zero months for schedule generation".to_string());
        }

        // Infer roll day from termination date if not provided
        let roll = roll_day.unwrap_or_else(|| infer_roll_day(termination));

        // Generate schedule based on stub dates or inference
        let (unadjusted_dates, stub_type) = match (front_stub, back_stub) {
            (Some(fs), Some(bs)) => {
                // Both stubs provided
                generate_with_both_stubs(effective, termination, months, roll, fs, bs)?
            }
            (Some(fs), None) => {
                // Front stub provided: generate regular from fs to termination
                generate_with_front_stub(effective, termination, months, roll, fs)?
            }
            (None, Some(bs)) => {
                // Back stub provided: generate regular from effective to bs
                generate_with_back_stub(effective, termination, months, roll, bs)?
            }
            (None, None) => {
                // No stubs: try regular, then infer
                generate_with_inference(effective, termination, months, roll, stub_inference)?
            }
        };

        let adjusted_dates = unadjusted_dates
            .iter()
            .map(|d| adjuster.adjust(*d, &calendar))
            .collect();

        Ok(Schedule {
            effective,
            termination,
            frequency,
            calendar,
            adjuster,
            roll_day: roll,
            unadjusted_dates,
            adjusted_dates,
            stub_type,
        })
    }

    /// Number of periods in the schedule.
    pub fn n_periods(&self) -> usize {
        if self.unadjusted_dates.len() > 1 {
            self.unadjusted_dates.len() - 1
        } else {
            0
        }
    }

    /// Unadjusted period boundary dates.
    pub fn unadjusted_dates(&self) -> &[NaiveDate] {
        &self.unadjusted_dates
    }

    /// Adjusted period boundary dates.
    pub fn adjusted_dates(&self) -> &[NaiveDate] {
        &self.adjusted_dates
    }

    /// Whether the schedule has a front stub.
    pub fn has_front_stub(&self) -> bool {
        matches!(
            self.stub_type,
            Some(StubType::ShortFront) | Some(StubType::LongFront)
        )
    }

    /// Whether the schedule has a back stub.
    pub fn has_back_stub(&self) -> bool {
        matches!(
            self.stub_type,
            Some(StubType::ShortBack) | Some(StubType::LongBack)
        )
    }
}

/// Infer roll day from a date.
fn infer_roll_day(date: NaiveDate) -> RollDay {
    let day = date.day();
    let last = super::frequency::last_day_of_month(date.year(), date.month());
    if day == last {
        RollDay::Eom
    } else {
        RollDay::Day(day)
    }
}

/// Apply roll day to a date that has been moved by months.
fn apply_roll(date: NaiveDate, roll: RollDay) -> NaiveDate {
    roll.date_in_month(date.year(), date.month())
}

/// Generate regular dates backward from `end` to `start` by `months` intervals.
/// Returns dates in forward order. Returns None if start doesn't align.
fn generate_regular_backward(
    start: NaiveDate,
    end: NaiveDate,
    months: i32,
    roll: RollDay,
) -> Option<Vec<NaiveDate>> {
    let mut dates = vec![end];
    let mut current = end;
    loop {
        let prev = apply_roll(add_months(current, -months), roll);
        if prev <= start {
            if prev == start {
                dates.push(start);
                dates.reverse();
                return Some(dates);
            } else {
                return None;
            }
        }
        dates.push(prev);
        current = prev;
    }
}

/// Generate regular dates forward from `start` to `end` by `months` intervals.
/// Returns dates in forward order. Returns None if end doesn't align.
fn generate_regular_forward(
    start: NaiveDate,
    end: NaiveDate,
    months: i32,
    roll: RollDay,
) -> Option<Vec<NaiveDate>> {
    let mut dates = vec![start];
    let mut current = start;
    loop {
        let next = apply_roll(add_months(current, months), roll);
        if next >= end {
            if next == end {
                dates.push(end);
                return Some(dates);
            } else {
                return None;
            }
        }
        dates.push(next);
        current = next;
    }
}

/// Generate schedule with both explicit stub dates.
fn generate_with_both_stubs(
    effective: NaiveDate,
    termination: NaiveDate,
    months: i32,
    roll: RollDay,
    front_stub: NaiveDate,
    back_stub: NaiveDate,
) -> Result<(Vec<NaiveDate>, Option<StubType>), String> {
    if front_stub >= back_stub {
        return Err("Front stub must be before back stub".to_string());
    }
    // Generate regular between stubs
    let regular = generate_regular_forward(front_stub, back_stub, months, roll)
        .ok_or("Cannot generate regular schedule between stub dates")?;

    let mut dates = vec![effective];
    // Add regular dates (skip first which is front_stub, already preceded by effective)
    dates.extend_from_slice(&regular[..]);
    dates.push(termination);
    // Deduplicate in case effective == front_stub or back_stub == termination
    dates.dedup();

    Ok((dates, Some(StubType::ShortFront))) // simplification: report front stub
}

/// Generate schedule with explicit front stub.
fn generate_with_front_stub(
    effective: NaiveDate,
    termination: NaiveDate,
    months: i32,
    roll: RollDay,
    front_stub: NaiveDate,
) -> Result<(Vec<NaiveDate>, Option<StubType>), String> {
    let regular = generate_regular_forward(front_stub, termination, months, roll)
        .ok_or("Cannot generate regular schedule from front stub to termination")?;

    let mut dates = vec![effective];
    dates.extend_from_slice(&regular[..]);
    dates.dedup();

    let stub_type = classify_front_stub(effective, front_stub, months);
    Ok((dates, Some(stub_type)))
}

/// Generate schedule with explicit back stub.
fn generate_with_back_stub(
    effective: NaiveDate,
    termination: NaiveDate,
    months: i32,
    roll: RollDay,
    back_stub: NaiveDate,
) -> Result<(Vec<NaiveDate>, Option<StubType>), String> {
    let regular = generate_regular_forward(effective, back_stub, months, roll)
        .ok_or("Cannot generate regular schedule from effective to back stub")?;

    let mut dates = regular;
    dates.push(termination);
    dates.dedup();

    let stub_type = classify_back_stub(back_stub, termination, months);
    Ok((dates, Some(stub_type)))
}

/// Generate schedule with stub inference (no explicit stubs).
fn generate_with_inference(
    effective: NaiveDate,
    termination: NaiveDate,
    months: i32,
    roll: RollDay,
    inference: StubInference,
) -> Result<(Vec<NaiveDate>, Option<StubType>), String> {
    // First, try regular schedule
    if let Some(dates) = generate_regular_backward(effective, termination, months, roll) {
        return Ok((dates, None));
    }
    if let Some(dates) = generate_regular_forward(effective, termination, months, roll) {
        return Ok((dates, None));
    }

    // Need to infer a stub
    match inference {
        StubInference::ShortFront | StubInference::LongFront => {
            // Generate backward from termination, creating a front stub
            let mut dates = vec![termination];
            let mut current = termination;
            loop {
                let prev = apply_roll(add_months(current, -months), roll);
                if prev <= effective {
                    // effective becomes the first date (front stub)
                    dates.push(effective);
                    break;
                }
                dates.push(prev);
                current = prev;
            }
            dates.reverse();

            let stub_type = if dates.len() >= 2 {
                classify_front_stub(dates[0], dates[1], months)
            } else {
                StubType::ShortFront
            };

            // Check if inference preference matches
            let stub_type = match inference {
                StubInference::ShortFront => stub_type,
                StubInference::LongFront => {
                    // If we got a short front stub but wanted long, extend by one period
                    if matches!(stub_type, StubType::ShortFront) && dates.len() > 2 {
                        // Remove the second date to make the front stub longer
                        dates.remove(1);
                        StubType::LongFront
                    } else {
                        stub_type
                    }
                }
                _ => unreachable!(),
            };

            Ok((dates, Some(stub_type)))
        }
        StubInference::ShortBack | StubInference::LongBack => {
            // Generate forward from effective, creating a back stub
            let mut dates = vec![effective];
            let mut current = effective;
            loop {
                let next = apply_roll(add_months(current, months), roll);
                if next >= termination {
                    // termination becomes the last date (back stub)
                    dates.push(termination);
                    break;
                }
                dates.push(next);
                current = next;
            }

            let n = dates.len();
            let stub_type = if n >= 2 {
                classify_back_stub(dates[n - 2], dates[n - 1], months)
            } else {
                StubType::ShortBack
            };

            // Check if inference preference matches
            let stub_type = match inference {
                StubInference::ShortBack => stub_type,
                StubInference::LongBack => {
                    // If we got a short back stub but wanted long, remove second-to-last
                    if matches!(stub_type, StubType::ShortBack) && dates.len() > 2 {
                        let last = dates.pop().unwrap();
                        dates.pop(); // remove the second-to-last
                        dates.push(last);
                        StubType::LongBack
                    } else {
                        stub_type
                    }
                }
                _ => unreachable!(),
            };

            Ok((dates, Some(stub_type)))
        }
    }
}

/// Classify a front stub as short or long.
fn classify_front_stub(effective: NaiveDate, first_regular: NaiveDate, months: i32) -> StubType {
    let days = (first_regular - effective).num_days() as f64;
    // A regular period is approximately months * 30.44 days
    let regular_days = months as f64 * 30.44;
    if days > regular_days {
        // If the stub period exceeds a regular period, it's long
        StubType::LongFront
    } else {
        StubType::ShortFront
    }
}

/// Classify a back stub as short or long.
fn classify_back_stub(last_regular: NaiveDate, termination: NaiveDate, months: i32) -> StubType {
    let days = (termination - last_regular).num_days() as f64;
    let regular_days = months as f64 * 30.44;
    if days > regular_days {
        StubType::LongBack
    } else {
        StubType::ShortBack
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::NaiveDate;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn simple_cal() -> BusinessCalendar {
        BusinessCalendar::new_custom(vec![], vec![5, 6]) // weekends only
    }

    #[test]
    fn test_regular_schedule_semi_annual() {
        let cal = simple_cal();
        let s = Schedule::try_new(
            ymd(2024, 1, 15),
            ymd(2025, 1, 15),
            Frequency::SemiAnnual,
            cal,
            Adjuster::ModifiedFollowing,
            None,
            None,
            None,
            StubInference::ShortFront,
        )
        .unwrap();

        assert_eq!(
            s.unadjusted_dates,
            vec![ymd(2024, 1, 15), ymd(2024, 7, 15), ymd(2025, 1, 15)]
        );
        assert_eq!(s.n_periods(), 2);
        assert!(!s.has_front_stub());
        assert!(!s.has_back_stub());
        assert_eq!(s.stub_type, None);
    }

    #[test]
    fn test_regular_schedule_quarterly() {
        let cal = simple_cal();
        let s = Schedule::try_new(
            ymd(2024, 1, 15),
            ymd(2025, 1, 15),
            Frequency::Quarterly,
            cal,
            Adjuster::ModifiedFollowing,
            None,
            None,
            None,
            StubInference::ShortFront,
        )
        .unwrap();

        assert_eq!(
            s.unadjusted_dates,
            vec![
                ymd(2024, 1, 15),
                ymd(2024, 4, 15),
                ymd(2024, 7, 15),
                ymd(2024, 10, 15),
                ymd(2025, 1, 15),
            ]
        );
        assert_eq!(s.n_periods(), 4);
    }

    #[test]
    fn test_short_front_stub() {
        let cal = simple_cal();
        // effective doesn't align with semi-annual backward from termination
        let s = Schedule::try_new(
            ymd(2024, 3, 1),
            ymd(2025, 1, 15),
            Frequency::SemiAnnual,
            cal,
            Adjuster::Actual,
            Some(RollDay::Day(15)),
            None,
            None,
            StubInference::ShortFront,
        )
        .unwrap();

        // Should generate: 2024-03-01, 2024-07-15, 2025-01-15
        assert_eq!(
            s.unadjusted_dates,
            vec![ymd(2024, 3, 1), ymd(2024, 7, 15), ymd(2025, 1, 15)]
        );
        assert!(s.has_front_stub());
        assert!(!s.has_back_stub());
    }

    #[test]
    fn test_short_back_stub() {
        let cal = simple_cal();
        let s = Schedule::try_new(
            ymd(2024, 1, 15),
            ymd(2025, 3, 1),
            Frequency::SemiAnnual,
            cal,
            Adjuster::Actual,
            Some(RollDay::Day(15)),
            None,
            None,
            StubInference::ShortBack,
        )
        .unwrap();

        // Forward from 2024-01-15: 2024-07-15, 2025-01-15, then 2025-03-01 as back stub
        assert_eq!(
            s.unadjusted_dates,
            vec![
                ymd(2024, 1, 15),
                ymd(2024, 7, 15),
                ymd(2025, 1, 15),
                ymd(2025, 3, 1),
            ]
        );
        assert!(!s.has_front_stub());
        assert!(s.has_back_stub());
    }

    #[test]
    fn test_long_front_stub() {
        let cal = simple_cal();
        let s = Schedule::try_new(
            ymd(2024, 3, 1),
            ymd(2025, 1, 15),
            Frequency::SemiAnnual,
            cal,
            Adjuster::Actual,
            Some(RollDay::Day(15)),
            None,
            None,
            StubInference::LongFront,
        )
        .unwrap();

        // With long front: merge the short front stub into the next period
        // 2024-03-01, 2025-01-15 (single long period) or
        // 2024-03-01 to 2025-01-15 with front stub consuming the first regular period
        assert!(s.has_front_stub());
        assert_eq!(
            s.unadjusted_dates,
            vec![ymd(2024, 3, 1), ymd(2025, 1, 15)]
        );
    }

    #[test]
    fn test_long_back_stub() {
        let cal = simple_cal();
        let s = Schedule::try_new(
            ymd(2024, 1, 15),
            ymd(2025, 3, 1),
            Frequency::SemiAnnual,
            cal,
            Adjuster::Actual,
            Some(RollDay::Day(15)),
            None,
            None,
            StubInference::LongBack,
        )
        .unwrap();

        // With long back: merge the short back stub into the previous period
        // 2024-01-15, 2024-07-15, 2025-03-01
        assert!(s.has_back_stub());
        assert_eq!(
            s.unadjusted_dates,
            vec![ymd(2024, 1, 15), ymd(2024, 7, 15), ymd(2025, 3, 1)]
        );
    }

    #[test]
    fn test_roll_day_eom() {
        let cal = simple_cal();
        let s = Schedule::try_new(
            ymd(2024, 1, 31),
            ymd(2024, 7, 31),
            Frequency::Monthly,
            cal,
            Adjuster::Actual,
            Some(RollDay::Eom),
            None,
            None,
            StubInference::ShortFront,
        )
        .unwrap();

        // All dates should be end of month
        assert_eq!(
            s.unadjusted_dates,
            vec![
                ymd(2024, 1, 31),
                ymd(2024, 2, 29), // leap year
                ymd(2024, 3, 31),
                ymd(2024, 4, 30),
                ymd(2024, 5, 31),
                ymd(2024, 6, 30),
                ymd(2024, 7, 31),
            ]
        );
    }

    #[test]
    fn test_roll_day_imm() {
        let cal = simple_cal();
        let s = Schedule::try_new(
            ymd(2024, 3, 20), // IMM date for March
            ymd(2024, 9, 18), // IMM date for September
            Frequency::Quarterly,
            cal,
            Adjuster::Actual,
            Some(RollDay::Imm),
            None,
            None,
            StubInference::ShortFront,
        )
        .unwrap();

        // IMM dates: 3rd Wednesday
        // Mar 2024: 20, Jun 2024: 19, Sep 2024: 18
        assert_eq!(
            s.unadjusted_dates,
            vec![ymd(2024, 3, 20), ymd(2024, 6, 19), ymd(2024, 9, 18)]
        );
    }

    #[test]
    fn test_business_day_adjustment() {
        let cal = simple_cal(); // weekends only
        let s = Schedule::try_new(
            ymd(2024, 1, 15),
            ymd(2024, 7, 15),
            Frequency::SemiAnnual,
            cal,
            Adjuster::ModifiedFollowing,
            None,
            None,
            None,
            StubInference::ShortFront,
        )
        .unwrap();

        // 2024-01-15 is Monday (ok), 2024-07-15 is Monday (ok)
        assert_eq!(
            s.adjusted_dates,
            vec![ymd(2024, 1, 15), ymd(2024, 7, 15)]
        );
    }

    #[test]
    fn test_adjustment_weekend_roll() {
        let cal = simple_cal();
        // 2024-03-31 is a Sunday, should roll
        let s = Schedule::try_new(
            ymd(2024, 1, 31),
            ymd(2024, 3, 31),
            Frequency::Monthly,
            cal,
            Adjuster::ModifiedFollowing,
            Some(RollDay::Eom),
            None,
            None,
            StubInference::ShortFront,
        )
        .unwrap();

        // Unadjusted: [Jan 31, Feb 29, Mar 31]
        // Adjusted: Jan 31 (Wed), Feb 29 (Thu), Mar 31 (Sun) -> ModFoll -> Mar 29 (Fri, stays in March)
        assert_eq!(s.unadjusted_dates[2], ymd(2024, 3, 31));
        assert_eq!(s.adjusted_dates[2], ymd(2024, 3, 29));
    }

    #[test]
    fn test_zero_coupon() {
        let cal = simple_cal();
        let s = Schedule::try_new(
            ymd(2024, 1, 15),
            ymd(2029, 1, 15),
            Frequency::ZeroCoupon,
            cal,
            Adjuster::Actual,
            None,
            None,
            None,
            StubInference::ShortFront,
        )
        .unwrap();

        assert_eq!(
            s.unadjusted_dates,
            vec![ymd(2024, 1, 15), ymd(2029, 1, 15)]
        );
        assert_eq!(s.n_periods(), 1);
    }

    #[test]
    fn test_effective_after_termination() {
        let cal = simple_cal();
        let result = Schedule::try_new(
            ymd(2025, 1, 15),
            ymd(2024, 1, 15),
            Frequency::SemiAnnual,
            cal,
            Adjuster::Actual,
            None,
            None,
            None,
            StubInference::ShortFront,
        );
        assert!(result.is_err());
    }

    #[test]
    fn test_annual_schedule() {
        let cal = simple_cal();
        let s = Schedule::try_new(
            ymd(2022, 6, 15),
            ymd(2025, 6, 15),
            Frequency::Annual,
            cal,
            Adjuster::Actual,
            None,
            None,
            None,
            StubInference::ShortFront,
        )
        .unwrap();

        assert_eq!(
            s.unadjusted_dates,
            vec![
                ymd(2022, 6, 15),
                ymd(2023, 6, 15),
                ymd(2024, 6, 15),
                ymd(2025, 6, 15),
            ]
        );
    }

    #[test]
    fn test_explicit_front_stub_date() {
        let cal = simple_cal();
        let s = Schedule::try_new(
            ymd(2024, 2, 1),
            ymd(2025, 1, 15),
            Frequency::SemiAnnual,
            cal,
            Adjuster::Actual,
            Some(RollDay::Day(15)),
            Some(ymd(2024, 7, 15)), // explicit front stub boundary
            None,
            StubInference::ShortFront,
        )
        .unwrap();

        assert_eq!(
            s.unadjusted_dates,
            vec![ymd(2024, 2, 1), ymd(2024, 7, 15), ymd(2025, 1, 15)]
        );
    }

    #[test]
    fn test_explicit_back_stub_date() {
        let cal = simple_cal();
        let s = Schedule::try_new(
            ymd(2024, 1, 15),
            ymd(2025, 3, 20),
            Frequency::SemiAnnual,
            cal,
            Adjuster::Actual,
            Some(RollDay::Day(15)),
            None,
            Some(ymd(2025, 1, 15)), // explicit back stub boundary
            StubInference::ShortFront,
        )
        .unwrap();

        assert_eq!(
            s.unadjusted_dates,
            vec![
                ymd(2024, 1, 15),
                ymd(2024, 7, 15),
                ymd(2025, 1, 15),
                ymd(2025, 3, 20),
            ]
        );
    }

    #[test]
    fn test_monthly_regular() {
        let cal = simple_cal();
        let s = Schedule::try_new(
            ymd(2024, 1, 15),
            ymd(2024, 6, 15),
            Frequency::Monthly,
            cal,
            Adjuster::Actual,
            None,
            None,
            None,
            StubInference::ShortFront,
        )
        .unwrap();

        assert_eq!(
            s.unadjusted_dates,
            vec![
                ymd(2024, 1, 15),
                ymd(2024, 2, 15),
                ymd(2024, 3, 15),
                ymd(2024, 4, 15),
                ymd(2024, 5, 15),
                ymd(2024, 6, 15),
            ]
        );
    }

    #[test]
    fn test_stub_inference_default_short_front() {
        let cal = simple_cal();
        let s = Schedule::try_new(
            ymd(2024, 3, 1),
            ymd(2025, 7, 15),
            Frequency::SemiAnnual,
            cal,
            Adjuster::Actual,
            Some(RollDay::Day(15)),
            None,
            None,
            StubInference::ShortFront,
        )
        .unwrap();

        // Backward from 2025-07-15: 2025-01-15, 2024-07-15, effective 2024-03-01
        assert_eq!(s.unadjusted_dates[0], ymd(2024, 3, 1));
        assert_eq!(*s.unadjusted_dates.last().unwrap(), ymd(2025, 7, 15));
        assert!(s.has_front_stub());
    }

    #[test]
    fn test_named_calendar_adjustment() {
        let cal = BusinessCalendar::new_named("NYC").unwrap();
        let s = Schedule::try_new(
            ymd(2024, 1, 15),
            ymd(2024, 7, 15),
            Frequency::SemiAnnual,
            cal,
            Adjuster::Following,
            None,
            None,
            None,
            StubInference::ShortFront,
        )
        .unwrap();

        // Both dates are weekdays and not NYC holidays
        assert_eq!(s.adjusted_dates[0], ymd(2024, 1, 16));
        // Wait, Jan 15 2024 is MLK day (holiday). Following -> Jan 16.
        // Actually let me verify: MLK is 3rd Monday of January
        // Jan 2024: 1st Monday is Jan 1 (but that's New Year),
        // 3rd Monday is Jan 15. So yes, it's a holiday.
        assert_eq!(s.adjusted_dates[1], ymd(2024, 7, 15)); // Jul 15 is Monday, ok
    }
}
