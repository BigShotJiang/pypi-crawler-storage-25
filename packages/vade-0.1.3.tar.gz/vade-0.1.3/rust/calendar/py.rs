use chrono::NaiveDate;
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;

use super::adjuster::Adjuster;
use super::cal::BusinessCalendar;
use super::convention::{DayCountConvention, DcfOptions};
use super::dateroll::add_business_days;
use super::frequency::{Frequency, RollDay};
use super::schedule::{Schedule, StubInference};
use super::tenor::Tenor;

// ---- String-to-enum parsing helpers ----

fn parse_adjuster(s: &str) -> PyResult<Adjuster> {
    match s.to_lowercase().as_str() {
        "actual" | "none" => Ok(Adjuster::Actual),
        "following" | "fol" => Ok(Adjuster::Following),
        "modified_following" | "modfollowing" | "mod_following" | "mf" => {
            Ok(Adjuster::ModifiedFollowing)
        }
        "preceding" | "pre" => Ok(Adjuster::Preceding),
        "modified_preceding" | "modpreceding" | "mod_preceding" | "mp" => {
            Ok(Adjuster::ModifiedPreceding)
        }
        _ => Err(PyValueError::new_err(format!(
            "Unknown adjuster: '{}'. Use: 'actual', 'following', 'modified_following', 'preceding', 'modified_preceding'",
            s
        ))),
    }
}

fn parse_frequency(s: &str) -> PyResult<Frequency> {
    match s.to_uppercase().as_str() {
        "M" | "MONTHLY" => Ok(Frequency::Monthly),
        "Q" | "QUARTERLY" => Ok(Frequency::Quarterly),
        "S" | "SEMIANNUAL" | "SEMI_ANNUAL" | "SEMI-ANNUAL" => Ok(Frequency::SemiAnnual),
        "A" | "ANNUAL" | "ANNUALLY" => Ok(Frequency::Annual),
        "Z" | "ZEROCOUPON" | "ZERO_COUPON" | "ZERO-COUPON" => Ok(Frequency::ZeroCoupon),
        _ => Err(PyValueError::new_err(format!(
            "Unknown frequency: '{}'. Use: 'M', 'Q', 'S', 'A', 'Z'",
            s
        ))),
    }
}

fn parse_day_count(s: &str) -> PyResult<DayCountConvention> {
    match s.to_lowercase().replace([' ', '_', '-'], "").as_str() {
        "act360" | "actual360" => Ok(DayCountConvention::Act360),
        "act365f" | "act365fixed" | "actual365fixed" => Ok(DayCountConvention::Act365F),
        "act365.25" | "act36525" => Ok(DayCountConvention::Act365_25),
        "act364" | "actual364" => Ok(DayCountConvention::Act364),
        "actactisda" | "actualactual" | "actualactualactual" | "actact" => {
            Ok(DayCountConvention::ActActISDA)
        }
        "30/360" | "30360" | "thirty360" => Ok(DayCountConvention::Thirty360),
        "30e/360" | "30e360" | "thirtye360" => Ok(DayCountConvention::ThirtyE360),
        "30e/360isda" | "30e360isda" | "thirtye360isda" => Ok(DayCountConvention::ThirtyE360ISDA),
        "bus252" | "bus/252" | "business252" => Ok(DayCountConvention::Bus252),
        "one" | "1" | "1/1" => Ok(DayCountConvention::One),
        _ => Err(PyValueError::new_err(format!(
            "Unknown day count convention: '{}'. Use: 'act360', 'act365f', 'actactisda', '30/360', '30e/360', '30e/360isda', 'bus252', 'one'",
            s
        ))),
    }
}

fn parse_roll_day(s: &str) -> PyResult<RollDay> {
    match s.to_lowercase().as_str() {
        "eom" | "end_of_month" => Ok(RollDay::Eom),
        "imm" => Ok(RollDay::Imm),
        _ => {
            // Try parsing as integer
            let day: u32 = s.parse().map_err(|_| {
                PyValueError::new_err(format!(
                    "Unknown roll day: '{}'. Use: 'eom', 'imm', or a day number 1-31",
                    s
                ))
            })?;
            if day < 1 || day > 31 {
                return Err(PyValueError::new_err("Roll day must be between 1 and 31"));
            }
            Ok(RollDay::Day(day))
        }
    }
}

fn parse_stub_inference(s: &str) -> PyResult<StubInference> {
    match s.to_lowercase().replace([' ', '_', '-'], "").as_str() {
        "shortfront" => Ok(StubInference::ShortFront),
        "longfront" => Ok(StubInference::LongFront),
        "shortback" => Ok(StubInference::ShortBack),
        "longback" => Ok(StubInference::LongBack),
        _ => Err(PyValueError::new_err(format!(
            "Unknown stub inference: '{}'. Use: 'short_front', 'long_front', 'short_back', 'long_back'",
            s
        ))),
    }
}

// ---- PyO3 wrapper for BusinessCalendar ----

/// Python-visible wrapper for BusinessCalendar.
#[pyclass(name = "BusinessCalendar", module = "vade._vade_rs.calendar", from_py_object)]
#[derive(Clone)]
pub struct PyBusinessCalendar {
    pub inner: BusinessCalendar,
    pub name: Option<String>,
}

#[pymethods]
impl PyBusinessCalendar {
    /// Create a named calendar.
    ///
    /// Args:
    ///     name: Calendar name (e.g., "NYC", "LDN", "TGT", "TYO", "SYD", etc.)
    #[new]
    #[pyo3(signature = (name))]
    fn new(name: &str) -> PyResult<Self> {
        let inner = BusinessCalendar::new_named(name)
            .map_err(|e| PyValueError::new_err(e))?;
        Ok(PyBusinessCalendar {
            inner,
            name: Some(name.to_uppercase()),
        })
    }

    /// Create a custom calendar with explicit holidays and weekend mask.
    ///
    /// Args:
    ///     holidays: List of holiday dates as strings "YYYY-MM-DD"
    ///     weekmask: List of weekend day numbers (0=Mon, 5=Sat, 6=Sun)
    #[staticmethod]
    #[pyo3(signature = (holidays, weekmask))]
    fn new_custom(holidays: Vec<String>, weekmask: Vec<u8>) -> PyResult<Self> {
        let holiday_dates: Vec<NaiveDate> = holidays
            .iter()
            .map(|s| {
                NaiveDate::parse_from_str(s, "%Y-%m-%d")
                    .map_err(|e| PyValueError::new_err(format!("Invalid date '{}': {}", s, e)))
            })
            .collect::<PyResult<Vec<_>>>()?;

        let inner = BusinessCalendar::new_custom(holiday_dates, weekmask);
        Ok(PyBusinessCalendar { inner, name: None })
    }

    /// Check if a date is a holiday.
    fn is_holiday(&self, date: NaiveDate) -> bool {
        self.inner.is_holiday(date)
    }

    /// Check if a date is a business day.
    fn is_business_day(&self, date: NaiveDate) -> bool {
        self.inner.is_business_day(date)
    }

    /// Count business days between start (inclusive) and end (exclusive).
    fn bus_day_count(&self, start: NaiveDate, end: NaiveDate) -> i32 {
        self.inner.bus_day_count(start, end)
    }

    /// Create a union calendar (settlement: holidays from either).
    fn union_cal(&self, other: &PyBusinessCalendar) -> PyBusinessCalendar {
        let inner = BusinessCalendar::union(&self.inner, &other.inner);
        PyBusinessCalendar { inner, name: None }
    }

    fn __repr__(&self) -> String {
        match &self.name {
            Some(n) => format!("BusinessCalendar('{}')", n),
            None => "BusinessCalendar(custom)".to_string(),
        }
    }
}

// ---- PyO3 wrapper for Schedule ----

/// Python-visible wrapper for Schedule.
#[pyclass(name = "Schedule", module = "vade._vade_rs.calendar", from_py_object)]
#[derive(Clone)]
pub struct PySchedule {
    pub inner: Schedule,
}

#[pymethods]
impl PySchedule {
    /// Create a new schedule.
    ///
    /// Args:
    ///     effective: Start date
    ///     termination: End date
    ///     frequency: Period frequency ("M", "Q", "S", "A", "Z")
    ///     calendar: BusinessCalendar (optional, defaults to weekends-only)
    ///     adjuster: Business day adjustment rule (default: "modified_following")
    ///     roll_day: Roll day convention (optional, inferred from dates)
    ///     front_stub: Optional explicit front stub date
    ///     back_stub: Optional explicit back stub date
    ///     stub_inference: Stub preference (default: "short_front")
    #[new]
    #[pyo3(signature = (effective, termination, frequency, calendar=None, adjuster="modified_following", roll_day=None, front_stub=None, back_stub=None, stub_inference="short_front"))]
    fn new(
        effective: NaiveDate,
        termination: NaiveDate,
        frequency: &str,
        calendar: Option<&PyBusinessCalendar>,
        adjuster: &str,
        roll_day: Option<&str>,
        front_stub: Option<NaiveDate>,
        back_stub: Option<NaiveDate>,
        stub_inference: &str,
    ) -> PyResult<Self> {
        let freq = parse_frequency(frequency)?;
        let adj = parse_adjuster(adjuster)?;
        let roll = match roll_day {
            Some(s) => Some(parse_roll_day(s)?),
            None => None,
        };
        let si = parse_stub_inference(stub_inference)?;
        let cal = match calendar {
            Some(c) => c.inner.clone(),
            None => BusinessCalendar::new_custom(vec![], vec![5, 6]),
        };

        let inner = Schedule::try_new(
            effective,
            termination,
            freq,
            cal,
            adj,
            roll,
            front_stub,
            back_stub,
            si,
        )
        .map_err(|e| PyValueError::new_err(e))?;

        Ok(PySchedule { inner })
    }

    /// Unadjusted period boundary dates.
    #[getter]
    fn unadjusted_dates(&self) -> Vec<NaiveDate> {
        self.inner.unadjusted_dates.clone()
    }

    /// Adjusted period boundary dates.
    #[getter]
    fn adjusted_dates(&self) -> Vec<NaiveDate> {
        self.inner.adjusted_dates.clone()
    }

    /// Number of periods in the schedule.
    #[getter]
    fn n_periods(&self) -> usize {
        self.inner.n_periods()
    }

    /// Whether the schedule has a front stub.
    fn has_front_stub(&self) -> bool {
        self.inner.has_front_stub()
    }

    /// Whether the schedule has a back stub.
    fn has_back_stub(&self) -> bool {
        self.inner.has_back_stub()
    }

    fn __len__(&self) -> usize {
        self.inner.n_periods()
    }

    fn __repr__(&self) -> String {
        let adj = &self.inner.adjusted_dates;
        if adj.len() <= 4 {
            let dates: Vec<String> = adj.iter().map(|d| d.to_string()).collect();
            format!("Schedule([{}], periods={})", dates.join(", "), self.inner.n_periods())
        } else {
            format!(
                "Schedule([{}, ..., {}], periods={})",
                adj.first().unwrap(),
                adj.last().unwrap(),
                self.inner.n_periods()
            )
        }
    }
}

// ---- Standalone functions ----

/// Compute day count fraction between two dates.
///
/// Args:
///     convention: Day count convention string ("act360", "act365f", "actactisda", "30/360", etc.)
///     start: Start date
///     end: End date
///     calendar: Optional calendar (required for "bus252")
///     termination: Optional termination date (required for "30e/360isda")
#[pyfunction]
#[pyo3(signature = (convention, start, end, calendar=None, termination=None))]
fn dcf(
    convention: &str,
    start: NaiveDate,
    end: NaiveDate,
    calendar: Option<&PyBusinessCalendar>,
    termination: Option<NaiveDate>,
) -> PyResult<f64> {
    let conv = parse_day_count(convention)?;
    let opts = DcfOptions {
        calendar: calendar.map(|c| &c.inner),
        termination,
    };
    conv.dcf(start, end, &opts)
        .map_err(|e| PyValueError::new_err(e))
}

/// Add a tenor to a date.
///
/// Args:
///     date: Base date
///     tenor: Tenor string (e.g., "2Y", "6M", "1W", "3D", "3B")
///     calendar: Optional calendar (required for business day tenors)
#[pyfunction]
#[pyo3(signature = (date, tenor, calendar=None))]
fn add_tenor(
    date: NaiveDate,
    tenor: &str,
    calendar: Option<&PyBusinessCalendar>,
) -> PyResult<NaiveDate> {
    let t = Tenor::parse(tenor).map_err(|e| PyValueError::new_err(e))?;
    t.add_to(date, calendar.map(|c| &c.inner))
        .map_err(|e| PyValueError::new_err(e))
}

/// Add business days to a date.
///
/// Args:
///     date: Base date
///     days: Number of business days (positive for forward, negative for backward)
///     calendar: Business day calendar
#[pyfunction]
#[pyo3(name = "add_business_days", signature = (date, days, calendar))]
fn py_add_business_days(
    date: NaiveDate,
    days: i32,
    calendar: &PyBusinessCalendar,
) -> NaiveDate {
    add_business_days(date, days, &calendar.inner)
}

// ---- Module registration ----

pub fn register_module(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyBusinessCalendar>()?;
    m.add_class::<PySchedule>()?;
    m.add_function(wrap_pyfunction!(dcf, m)?)?;
    m.add_function(wrap_pyfunction!(add_tenor, m)?)?;
    m.add_function(wrap_pyfunction!(py_add_business_days, m)?)?;
    Ok(())
}
