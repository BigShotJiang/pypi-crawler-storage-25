//! Hull-White one-factor trinomial tree for short-rate modelling.
//!
//! Builds a recombining trinomial tree for the Ornstein-Uhlenbeck process
//! `dx = -a*x*dt + sigma*dW`, then calibrates `phi(t)` so that the tree
//! reproduces the input discount curve exactly.  The tree is reusable for
//! pricing any instrument with early-exercise features (callable/puttable
//! bonds, Bermudan swaptions, etc.).

use chrono::NaiveDate;
use crate::autodiff::enums::Number;
use crate::calendar::convention::{DayCountConvention, DcfOptions};
use crate::marketcurves::curve::CurveQuery;

// ---------------------------------------------------------------------------
// Data structures
// ---------------------------------------------------------------------------

/// A single time step (transition from level i to level i+1) in the tree.
struct TreeStep {
    dt: f64,
    /// For each source node j in [j_min..=j_max] at level i:
    /// `k[j - j_min]` = central descendant index at level i+1.
    k: Vec<i32>,
    /// Transition probabilities `[p_down, p_mid, p_up]` for each source node.
    probs: Vec<[f64; 3]>,
}

/// Info about a time level in the tree (nodes at time t_i).
struct LevelInfo {
    j_min: i32,
    j_max: i32,
    dx: f64,
}

/// Hull-White one-factor trinomial tree.
///
/// Build once with [`HullWhiteTree::build`], then call
/// [`HullWhiteTree::price_callable`] as many times as needed with different
/// spread values (the tree structure is spread-independent).
#[allow(dead_code)]
pub struct HullWhiteTree {
    a: f64,
    sigma: f64,
    times: Vec<f64>,
    levels: Vec<LevelInfo>,
    steps: Vec<TreeStep>,
    phi: Vec<f64>,
    state_prices: Vec<Vec<f64>>,
    /// Cached discount factors from the input curve at each time point.
    curve_dfs: Vec<f64>,
}

// ---------------------------------------------------------------------------
// Construction
// ---------------------------------------------------------------------------

impl HullWhiteTree {
    /// Build a Hull-White trinomial tree calibrated to `curve`.
    pub fn build(
        a: f64,
        sigma: f64,
        curve: &dyn CurveQuery,
        valuation_date: NaiveDate,
        mandatory_dates: &[NaiveDate],
        convention: DayCountConvention,
    ) -> Self {
        // 1. Convert dates to year fractions, sort, deduplicate.
        let mut time_date_pairs: Vec<(f64, NaiveDate)> = mandatory_dates
            .iter()
            .filter_map(|&d| {
                let t = convention
                    .dcf(valuation_date, d, &DcfOptions::default())
                    .unwrap_or(0.0);
                if t > 1e-10 { Some((t, d)) } else { None }
            })
            .collect();
        time_date_pairs.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());
        time_date_pairs.dedup_by(|a, b| (a.0 - b.0).abs() < 1e-10);

        let mut times = vec![0.0];
        let mut grid_dates = vec![valuation_date];
        for (t, d) in &time_date_pairs {
            times.push(*t);
            grid_dates.push(*d);
        }

        let n = times.len() - 1;

        let curve_dfs: Vec<f64> = grid_dates
            .iter()
            .map(|&d| match curve.discount_factor(d) {
                Number::F64(v) => v,
                Number::Dual(d) => d.real,
                Number::Dual2(d) => d.real,
            })
            .collect();

        // 2. Build tree step-by-step.
        let mut levels: Vec<LevelInfo> = Vec::with_capacity(n + 1);
        let mut steps: Vec<TreeStep> = Vec::with_capacity(n);
        let mut phi: Vec<f64> = Vec::with_capacity(n);
        let mut state_prices: Vec<Vec<f64>> = Vec::with_capacity(n + 1);

        // Level 0: single root node at x=0
        levels.push(LevelInfo { j_min: 0, j_max: 0, dx: 1.0 });
        state_prices.push(vec![1.0]);

        for i in 0..n {
            let dt = times[i + 1] - times[i];

            let v2 = if a.abs() < 1e-10 {
                sigma * sigma * dt
            } else {
                sigma * sigma * (1.0 - (-2.0 * a * dt).exp()) / (2.0 * a)
            };

            let dx_next = if v2 > 1e-30 { (3.0 * v2).sqrt() } else { 1.0 };

            let src = &levels[i];
            let src_j_min = src.j_min;
            let src_j_max = src.j_max;
            let src_dx = src.dx;
            let src_count = (src_j_max - src_j_min + 1) as usize;

            let mut k_vec: Vec<i32> = Vec::with_capacity(src_count);
            let mut probs_vec: Vec<[f64; 3]> = Vec::with_capacity(src_count);
            let mut j_min_next = i32::MAX;
            let mut j_max_next = i32::MIN;

            for j in src_j_min..=src_j_max {
                let x_j = if i == 0 { 0.0 } else { j as f64 * src_dx };
                let m = x_j * (-a * dt).exp();

                let k = if dx_next > 1e-30 {
                    (m / dx_next).round() as i32
                } else {
                    0
                };
                k_vec.push(k);

                j_min_next = j_min_next.min(k - 1);
                j_max_next = j_max_next.max(k + 1);

                let e = m - k as f64 * dx_next;
                let (p_down, p_mid, p_up) = if v2 < 1e-30 {
                    (0.0, 1.0, 0.0)
                } else {
                    let e2_v2 = e * e / v2;
                    let e_rt3_rtv2 = e * 3.0_f64.sqrt() / v2.sqrt();
                    let pd = (1.0 + e2_v2 - e_rt3_rtv2) / 6.0;
                    let pm = (2.0 - e2_v2) / 3.0;
                    let pu = (1.0 + e2_v2 + e_rt3_rtv2) / 6.0;
                    (pd.clamp(0.0, 1.0), pm.clamp(0.0, 1.0), pu.clamp(0.0, 1.0))
                };
                probs_vec.push([p_down, p_mid, p_up]);
            }

            if j_min_next > j_max_next {
                j_min_next = 0;
                j_max_next = 0;
            }

            let step = TreeStep { dt, k: k_vec, probs: probs_vec };

            // Calibrate phi[i]
            let sp = &state_prices[i];
            let mut value = 0.0;
            for j in src_j_min..=src_j_max {
                let idx = (j - src_j_min) as usize;
                let x_j = if i == 0 { 0.0 } else { j as f64 * src_dx };
                value += sp[idx] * (-x_j * dt).exp();
            }

            let df_next = curve_dfs[i + 1];
            let phi_i = if dt > 1e-30 && value > 0.0 && df_next > 0.0 {
                (value / df_next).ln() / dt
            } else {
                0.0
            };
            phi.push(phi_i);

            // Propagate state prices
            let next_count = (j_max_next - j_min_next + 1) as usize;
            let mut sp_next = vec![0.0; next_count];

            for j in src_j_min..=src_j_max {
                let idx = (j - src_j_min) as usize;
                let x_j = if i == 0 { 0.0 } else { j as f64 * src_dx };
                let r_j = phi_i + x_j;
                let disc_j = (-r_j * dt).exp();
                let prob = step.probs[idx];
                let kk = step.k[idx];

                for (branch, offset) in [(0, -1_i32), (1, 0), (2, 1)] {
                    let desc = kk + offset;
                    let desc_idx = (desc - j_min_next) as usize;
                    if desc_idx < next_count {
                        sp_next[desc_idx] += sp[idx] * prob[branch] * disc_j;
                    }
                }
            }

            levels.push(LevelInfo { j_min: j_min_next, j_max: j_max_next, dx: dx_next });
            state_prices.push(sp_next);
            steps.push(step);
        }

        HullWhiteTree { a, sigma, times, levels, steps, phi, state_prices, curve_dfs }
    }

    // -----------------------------------------------------------------------
    // Pricing
    // -----------------------------------------------------------------------

    /// Price a callable/puttable bond via backward induction on the tree.
    ///
    /// * `cashflows` -- `(time, amount)` pairs for coupon and redemption flows
    /// * `call_schedule` -- `(time, strike)` pairs for call exercise dates
    /// * `put_schedule` -- `(time, strike)` pairs for put exercise dates
    /// * `spread` -- OAS spread added to the short rate at every node
    ///
    /// Returns the model dirty price at the root node.
    pub fn price_callable(
        &self,
        cashflows: &[(f64, f64)],
        call_schedule: &[(f64, f64)],
        put_schedule: &[(f64, f64)],
        spread: f64,
    ) -> f64 {
        let n = self.steps.len();
        if n == 0 {
            return 0.0;
        }

        // Initialize V at the terminal level to zero.
        let term = &self.levels[n];
        let term_count = (term.j_max - term.j_min + 1) as usize;
        let mut values = vec![0.0; term_count];

        // Backward induction: for each step i from n-1 down to 0:
        //   1. Add cashflows at t_{i+1} to current (source-level) values
        //   2. Apply exercise at t_{i+1}
        //   3. Discount from level i+1 to level i
        //
        // At i=n-1: values is at level n (all zeros), we add terminal CFs
        // (redemption + last coupon), apply terminal exercise, then discount.
        for i in (0..n).rev() {
            let t_src = self.times[i + 1];

            // Step 1: Add cashflows at source level time
            for &(t, amt) in cashflows {
                if (t - t_src).abs() < 1e-8 {
                    for v in values.iter_mut() {
                        *v += amt;
                    }
                }
            }

            // Step 2: Apply exercise at source level time
            Self::apply_exercise(&mut values, t_src, call_schedule, put_schedule);

            // Step 3: Discount from level i+1 to level i
            let step = &self.steps[i];
            let phi_i = self.phi[i];
            let dt = step.dt;
            let src = &self.levels[i];
            let dst = &self.levels[i + 1];

            let src_count = (src.j_max - src.j_min + 1) as usize;
            let mut new_values = vec![0.0; src_count];

            for j in src.j_min..=src.j_max {
                let idx = (j - src.j_min) as usize;
                let x_j = if i == 0 { 0.0 } else { j as f64 * src.dx };
                let r_j = phi_i + x_j + spread;
                let disc = (-r_j * dt).exp();
                let prob = step.probs[idx];
                let kk = step.k[idx];

                let mut cont = 0.0;
                for (branch, offset) in [(0, -1_i32), (1, 0), (2, 1)] {
                    let desc = kk + offset;
                    let desc_idx = (desc - dst.j_min) as usize;
                    if desc_idx < values.len() {
                        cont += prob[branch] * values[desc_idx];
                    }
                }
                new_values[idx] = disc * cont;
            }

            values = new_values;
        }

        values[0]
    }

    /// Apply call/put exercise decisions at a given time.
    fn apply_exercise(
        values: &mut [f64],
        t: f64,
        call_schedule: &[(f64, f64)],
        put_schedule: &[(f64, f64)],
    ) {
        let tol = 7.0 / 365.25;
        for &(call_t, strike) in call_schedule {
            if (call_t - t).abs() < tol {
                for v in values.iter_mut() {
                    *v = v.min(strike);
                }
            }
        }
        for &(put_t, strike) in put_schedule {
            if (put_t - t).abs() < tol {
                for v in values.iter_mut() {
                    *v = v.max(strike);
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
pub(crate) mod tests {
    use super::*;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::nodes::Nodes;
    use crate::calendar::convention::DayCountConvention;
    use crate::calendar::adjuster::Adjuster;
    use crate::calendar::cal::BusinessCalendar;
    use crate::calendar::frequency::Frequency;
    use crate::instruments::bond::BondInstrument;
    use indexmap::IndexMap;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    /// Flat 3% continuously compounded discount curve for testing.
    fn flat_curve_3pct() -> DiscountCurve {
        let rate = 0.03;
        let base = ymd(2024, 1, 1);
        let conv = DayCountConvention::Act365F;
        let mut map = IndexMap::new();
        for yr in 0..=10 {
            let d = ymd(2024 + yr, 1, 1);
            let t = conv.dcf(base, d, &DcfOptions::default()).unwrap_or(0.0);
            let df = (-rate * t).exp();
            map.insert(d, df);
        }
        DiscountCurve::new(
            Nodes::from_f64_map(map),
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "flat3pct".to_string(),
        )
    }

    pub(crate) fn make_fixed_bond_5y() -> BondInstrument {
        BondInstrument::new_fixed_rate(
            ymd(2024, 1, 1),
            ymd(2029, 1, 1),
            0.04,
            Frequency::Annual,
            0,
            0,
            BusinessCalendar::new_custom(vec![], vec![0, 1, 2, 3, 4]),
            "USD".to_string(),
            DayCountConvention::Act365F,
            DayCountConvention::Act365F,
            100.0,
            Adjuster::ModifiedFollowing,
        )
    }

    /// Extract cashflow (time, amount) pairs and payment dates from a bond.
    fn bond_cf_data(bond: &BondInstrument, valuation: NaiveDate, conv: DayCountConvention) -> (Vec<(f64, f64)>, Vec<NaiveDate>) {
        let cfs = bond.variant.bond_cashflows(valuation, bond.face_value, bond.termination, None);
        let mut dates: Vec<NaiveDate> = cfs.iter().map(|cf| cf.payment).collect();
        dates.sort();
        dates.dedup();
        let pairs = cfs.iter()
            .map(|cf| {
                let t = conv.dcf(valuation, cf.payment, &DcfOptions::default()).unwrap();
                let amt = match &cf.amount {
                    Number::F64(v) => *v,
                    Number::Dual(d) => d.real,
                    Number::Dual2(d) => d.real,
                };
                (t, amt)
            })
            .collect();
        (pairs, dates)
    }

    #[test]
    fn test_build_flat_curve() {
        let curve = flat_curve_3pct();
        let conv = DayCountConvention::Act365F;
        let dates: Vec<NaiveDate> = (1..=5).map(|yr| ymd(2024 + yr, 1, 1)).collect();

        let tree = HullWhiteTree::build(0.1, 0.01, &curve, ymd(2024, 1, 1), &dates, conv);

        for (i, &p) in tree.phi.iter().enumerate() {
            assert!(
                (p - 0.03).abs() < 0.005,
                "phi[{}] = {} should be close to 0.03", i, p
            );
        }

        for i in 1..tree.state_prices.len() {
            let sp_sum: f64 = tree.state_prices[i].iter().sum();
            let df = tree.curve_dfs[i];
            assert!(
                (sp_sum - df).abs() < 0.01,
                "State price sum at step {} = {}, expected DF = {}", i, sp_sum, df
            );
        }
    }

    #[test]
    fn test_vanilla_bond_repricing() {
        let curve = flat_curve_3pct();
        let bond = make_fixed_bond_5y();
        let conv = DayCountConvention::Act365F;

        let bond_price = match bond.dirty_price(&curve, None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };

        // Use actual bond payment dates as mandatory tree dates
        let (cf_pairs, cf_dates) = bond_cf_data(&bond, ymd(2024, 1, 1), conv);
        let tree = HullWhiteTree::build(0.1, 0.01, &curve, ymd(2024, 1, 1), &cf_dates, conv);

        let tree_price = tree.price_callable(&cf_pairs, &[], &[], 0.0);

        let diff = (tree_price - bond_price).abs();
        assert!(
            diff < 0.05,
            "Tree price {} vs bond price {}: diff {} exceeds 0.05 per 100 face",
            tree_price, bond_price, diff
        );
    }

    #[test]
    fn test_callable_le_noncallable() {
        let curve = flat_curve_3pct();
        let bond = make_fixed_bond_5y();
        let conv = DayCountConvention::Act365F;

        let (cf_pairs, cf_dates) = bond_cf_data(&bond, ymd(2024, 1, 1), conv);
        // Add call dates to mandatory dates
        let call_dates: Vec<NaiveDate> = (2..=4).map(|yr| ymd(2024 + yr, 1, 1)).collect();
        let mut all_dates = cf_dates.clone();
        all_dates.extend_from_slice(&call_dates);

        let tree = HullWhiteTree::build(0.1, 0.01, &curve, ymd(2024, 1, 1), &all_dates, conv);

        let noncallable_price = tree.price_callable(&cf_pairs, &[], &[], 0.0);

        let call_sched: Vec<(f64, f64)> = call_dates.iter()
            .map(|&d| {
                let t = conv.dcf(ymd(2024, 1, 1), d, &DcfOptions::default()).unwrap();
                (t, 100.0)
            })
            .collect();

        let callable_price = tree.price_callable(&cf_pairs, &call_sched, &[], 0.0);

        assert!(
            callable_price <= noncallable_price + 0.01,
            "Callable price {} should be <= non-callable price {} + 0.01",
            callable_price, noncallable_price
        );
    }

    #[test]
    fn test_zero_vol_callable_equals_noncallable() {
        let curve = flat_curve_3pct();
        let bond = make_fixed_bond_5y();
        let conv = DayCountConvention::Act365F;

        let (cf_pairs, cf_dates) = bond_cf_data(&bond, ymd(2024, 1, 1), conv);
        let call_dates: Vec<NaiveDate> = (2..=4).map(|yr| ymd(2024 + yr, 1, 1)).collect();
        let mut all_dates = cf_dates;
        all_dates.extend_from_slice(&call_dates);

        let tree = HullWhiteTree::build(0.1, 1e-12, &curve, ymd(2024, 1, 1), &all_dates, conv);

        let noncallable = tree.price_callable(&cf_pairs, &[], &[], 0.0);

        let call_sched: Vec<(f64, f64)> = call_dates.iter()
            .map(|&d| {
                let t = conv.dcf(ymd(2024, 1, 1), d, &DcfOptions::default()).unwrap();
                (t, 100.0)
            })
            .collect();

        let callable = tree.price_callable(&cf_pairs, &call_sched, &[], 0.0);

        // With zero vol on a 4% bond / 3% curve, bond > par, callable should be near par.
        // Small deviations arise because call dates and coupon dates may not perfectly
        // align, and the exercise tolerance snaps them.
        assert!(
            callable < noncallable,
            "Zero-vol callable {} should be < noncallable {}", callable, noncallable
        );
        assert!(
            callable <= noncallable + 0.01,
            "Zero-vol callable {} should be <= noncallable {}", callable, noncallable
        );
        // With call at par, callable should be at most a few points below par
        assert!(
            callable > 95.0 && callable <= 101.0,
            "Zero-vol callable at par should be in [95, 101], got {}", callable
        );
    }

    #[test]
    fn test_probabilities_valid() {
        let curve = flat_curve_3pct();
        let conv = DayCountConvention::Act365F;
        let dates: Vec<NaiveDate> = (1..=5).map(|yr| ymd(2024 + yr, 1, 1)).collect();

        for &(a, sigma) in &[(0.1, 0.01), (0.05, 0.02), (0.5, 0.005), (0.01, 0.03)] {
            let tree = HullWhiteTree::build(a, sigma, &curve, ymd(2024, 1, 1), &dates, conv);
            for (i, step) in tree.steps.iter().enumerate() {
                for (j_idx, prob) in step.probs.iter().enumerate() {
                    let sum = prob[0] + prob[1] + prob[2];
                    assert!(
                        (sum - 1.0).abs() < 0.01,
                        "Step {} node {}: prob sum = {} (a={}, sigma={})",
                        i, j_idx, sum, a, sigma
                    );
                    for (b, &p) in prob.iter().enumerate() {
                        assert!(
                            p >= 0.0 && p <= 1.0,
                            "Step {} node {} branch {}: prob = {} (a={}, sigma={})",
                            i, j_idx, b, p, a, sigma
                        );
                    }
                }
            }
        }
    }
}
