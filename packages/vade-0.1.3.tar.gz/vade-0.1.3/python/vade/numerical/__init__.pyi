"""Type stubs for vade.numerical module."""

from typing import Callable, Tuple


def brent_solve(
    f: Callable[[float], float],
    a: float,
    b: float,
    tol: float = 1e-12,
    max_iter: int = 200,
) -> float:
    """Brent's method root finder.

    Finds x in [a, b] such that f(x) = 0.

    Args:
        f: Callable taking float, returning float.
        a: Lower bracket.
        b: Upper bracket.
        tol: Convergence tolerance.
        max_iter: Maximum iterations.

    Returns:
        Root x where f(x) ~ 0.

    Raises:
        ValueError: If root is not bracketed or max_iter exceeded.
    """
    ...


def newton_raphson_solve(
    f: Callable[[float], Tuple[float, float]],
    x0: float,
    tol: float = 1e-12,
    max_iter: int = 200,
) -> float:
    """Newton-Raphson root finder.

    Finds x such that f(x) = 0, where f returns (value, derivative).

    Args:
        f: Callable taking float, returning (value, derivative) tuple.
        x0: Initial guess.
        tol: Convergence tolerance.
        max_iter: Maximum iterations.

    Returns:
        Root x where f(x) ~ 0.

    Raises:
        ValueError: If derivative is zero or max_iter exceeded.
    """
    ...
