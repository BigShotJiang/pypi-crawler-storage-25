"""Numerical root-finding algorithms."""

from vade._vade_rs.numerical import brent_solve, newton_raphson_solve

__all__ = ["brent_solve", "newton_raphson_solve"]
