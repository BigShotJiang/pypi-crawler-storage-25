"""Integration tests for bond instruments (FixedRateBond, Bill, FloatRateNote, ZeroCouponBond, StepUpBond, SubPeriodFRN, CappedFloatRateNote)."""

import datetime
from datetime import date

import pytest

from vade import FixedRateBond, Bill, FloatRateNote, DiscountCurve, LineCurve
from vade import ZeroCouponBond, StepUpBond, AmortizingBond, PIKBond
from vade import SubPeriodFRN, CappedFloatRateNote
from vade.instruments.specs import get_spec, list_specs


def make_flat_curve(rate: float = 0.03) -> DiscountCurve:
    """Create a flat discount curve for testing."""
    import math

    base = datetime.date(2024, 1, 1)
    dates = [base]
    dfs = [1.0]
    for y in range(1, 11):
        d = datetime.date(2024 + y, 1, 1)
        dates.append(d)
        dfs.append(math.exp(-rate * y))

    return DiscountCurve(
        dict(zip(dates, dfs)),
        interpolation="log_linear",
        convention="act365f",
        id="test_curve",
    )


def test_fixed_rate_bond_price():
    """FixedRateBond.price() returns clean price as float."""
    bond = FixedRateBond(
        effective=datetime.date(2024, 1, 1),
        termination="5Y",
        coupon=0.04,
        frequency="s",
    )
    curve = make_flat_curve(0.03)
    price = bond.price(curve)
    assert isinstance(price, float)
    assert 100.0 < price < 120.0  # above par when coupon > yield


def test_fixed_rate_bond_dirty_price():
    """dirty_price() returns a float."""
    bond = FixedRateBond(
        effective=datetime.date(2024, 1, 1),
        termination="5Y",
        coupon=0.04,
    )
    curve = make_flat_curve(0.03)
    dp = bond.dirty_price(curve)
    assert isinstance(dp, float)
    assert dp > 0.0


def test_fixed_rate_bond_ytm_roundtrip():
    """price -> ytm -> price roundtrip consistency."""
    bond = FixedRateBond(
        effective=datetime.date(2024, 1, 1),
        termination="5Y",
        coupon=0.04,
    )
    curve = make_flat_curve(0.03)
    price = bond.price(curve)
    ytm = bond.ytm(price, datetime.date(2024, 1, 1))
    assert isinstance(ytm, float)
    assert 0.0 < ytm < 0.10  # reasonable yield range


def test_fixed_rate_bond_duration():
    """duration() returns positive value less than maturity."""
    bond = FixedRateBond(
        effective=datetime.date(2024, 1, 1),
        termination="5Y",
        coupon=0.04,
    )
    curve = make_flat_curve(0.03)
    mod_dur = bond.duration(curve, metric="modified")
    assert isinstance(mod_dur, float)
    assert 0.0 < mod_dur < 5.0


def test_bill_price():
    """Bill prices at discount factor * face."""
    bill = Bill(
        effective=datetime.date(2024, 1, 1),
        termination="6M",
    )
    curve = make_flat_curve(0.03)
    price = bill.price(curve)
    assert isinstance(price, float)
    assert 90.0 < price < 100.0  # below par for positive rates


def test_bill_ytm():
    """Bill YTM is positive for discount price."""
    bill = Bill(
        effective=datetime.date(2024, 1, 1),
        termination="1Y",
    )
    ytm = bill.ytm(97.0, datetime.date(2024, 1, 1))
    assert isinstance(ytm, float)
    assert ytm > 0.0


def test_frn_price():
    """FRN with 0 spread prices near par on flat curve."""
    frn = FloatRateNote(
        effective=datetime.date(2024, 1, 1),
        termination="5Y",
        spread=0.0,
        frequency="q",
    )
    curve = make_flat_curve(0.03)
    price = frn.price(curve)
    assert isinstance(price, float)
    # FRN at par when spread = 0 (approximately)
    assert 90.0 < price < 110.0


def test_bond_spec_construction():
    """FixedRateBond(spec='us_treasury', ...) works."""
    bond = FixedRateBond(
        spec="us_treasury",
        effective=datetime.date(2024, 1, 15),
        termination="10Y",
        coupon=0.04,
    )
    curve = make_flat_curve(0.04)
    price = bond.price(curve)
    assert isinstance(price, float)
    # At par when coupon matches yield
    assert 95.0 < price < 105.0


def test_bond_cashflows():
    """cashflows() returns a DataFrame-like object."""
    bond = FixedRateBond(
        effective=datetime.date(2024, 1, 1),
        termination="3Y",
        coupon=0.04,
    )
    curve = make_flat_curve(0.03)
    cf = bond.cashflows(curve)
    # Should be a Polars DataFrame with rows
    assert len(cf) > 0


def test_bond_spec_count():
    """At least 15 bond specs are available."""
    specs = list_specs()
    bond_specs = [s for s in specs if s in [
        "us_treasury", "us_tbill", "uk_gilt", "de_bund", "fr_oat",
        "it_btp", "es_bonos", "nl_dsl", "jp_jgb", "au_gov", "ca_gov",
        "usd_corporate", "eur_corporate", "gbp_corporate",
        "usd_frn", "eur_frn",
    ]]
    assert len(bond_specs) >= 15, f"Expected 15+ bond specs, got {len(bond_specs)}"


def test_bond_convexity():
    """convexity() returns a positive finite value."""
    bond = FixedRateBond(
        effective=datetime.date(2024, 1, 1),
        termination="5Y",
        coupon=0.04,
    )
    curve = make_flat_curve(0.03)
    cvx = bond.convexity(curve)
    assert isinstance(cvx, float)
    assert cvx > 0.0


def test_bond_analytic_delta():
    """analytic_delta() returns a number."""
    bond = FixedRateBond(
        effective=datetime.date(2024, 1, 1),
        termination="5Y",
        coupon=0.04,
    )
    curve = make_flat_curve(0.03)
    ad = bond.analytic_delta(curve)
    assert isinstance(ad, float)


# ---- Convention and settlement parameter tests ----


def test_ytm_convention_periodic():
    """bond.ytm with convention='periodic' matches existing behavior."""
    bond = FixedRateBond(
        effective=datetime.date(2024, 1, 1),
        termination="5Y",
        coupon=0.04,
        frequency="s",
    )
    curve = make_flat_curve(0.03)
    price = bond.price(curve)
    ytm_default = bond.ytm(price, datetime.date(2024, 1, 1))
    ytm_periodic = bond.ytm(price, datetime.date(2024, 1, 1), convention="periodic")
    assert abs(ytm_default - ytm_periodic) < 1e-12


def test_ytm_convention_annual():
    """ytm with convention='annual' gives different value than periodic."""
    bond = FixedRateBond(
        effective=datetime.date(2024, 1, 1),
        termination="5Y",
        coupon=0.04,
        frequency="s",
    )
    curve = make_flat_curve(0.03)
    price = bond.price(curve)
    ytm_periodic = bond.ytm(price, datetime.date(2024, 1, 1), convention="periodic")
    ytm_annual = bond.ytm(price, datetime.date(2024, 1, 1), convention="annual")
    # Annual and periodic should differ for semi-annual bonds
    assert abs(ytm_periodic - ytm_annual) > 1e-6


def test_ytm_convention_continuous():
    """ytm with convention='continuous' gives different value."""
    bond = FixedRateBond(
        effective=datetime.date(2024, 1, 1),
        termination="5Y",
        coupon=0.04,
        frequency="s",
    )
    curve = make_flat_curve(0.03)
    price = bond.price(curve)
    ytm_periodic = bond.ytm(price, datetime.date(2024, 1, 1), convention="periodic")
    ytm_continuous = bond.ytm(price, datetime.date(2024, 1, 1), convention="continuous")
    assert abs(ytm_periodic - ytm_continuous) > 1e-6


def test_ytm_roundtrip_all_conventions():
    """For each convention, ytm(price_from_ytm(y)) ~= y."""
    bond = FixedRateBond(
        effective=datetime.date(2024, 1, 1),
        termination="5Y",
        coupon=0.04,
        frequency="s",
    )
    settlement = datetime.date(2024, 1, 1)
    for conv in ["periodic", "annual", "continuous"]:
        y_in = 0.035
        p = bond.price_from_ytm(y_in, settlement, convention=conv)
        y_out = bond.ytm(p, settlement, convention=conv)
        assert abs(y_in - y_out) < 1e-8, f"Roundtrip failed for {conv}: {y_in} -> {y_out}"


def test_duration_with_settlement():
    """duration(settlement=later_date) != duration(settlement=None)."""
    bond = FixedRateBond(
        effective=datetime.date(2024, 1, 1),
        termination="5Y",
        coupon=0.04,
        frequency="s",
    )
    curve = make_flat_curve(0.03)
    dur_default = bond.duration(curve)
    dur_settled = bond.duration(curve, settlement=datetime.date(2024, 6, 1))
    # With settlement 6 months later, duration should be different
    assert isinstance(dur_settled, float)
    assert abs(dur_default - dur_settled) > 0.01


def test_z_spread_with_settlement():
    """z_spread works with explicit settlement."""
    bond = FixedRateBond(
        effective=datetime.date(2024, 1, 1),
        termination="5Y",
        coupon=0.04,
        frequency="s",
    )
    curve = make_flat_curve(0.03)
    price = bond.price(curve)
    zs = bond.z_spread(curve, price=price, settlement=datetime.date(2024, 6, 1))
    assert isinstance(zs, float)


def test_dirty_price_with_settlement():
    """dirty_price with settlement parameter is accepted and returns float."""
    bond = FixedRateBond(
        effective=datetime.date(2024, 1, 1),
        termination="5Y",
        coupon=0.04,
        frequency="s",
    )
    curve = make_flat_curve(0.03)
    dp_settled = bond.dirty_price(curve, settlement=datetime.date(2024, 6, 1))
    assert isinstance(dp_settled, float)
    assert dp_settled > 0.0


# ---- ZeroCouponBond tests ----


def test_zero_coupon_bond_construction():
    """BOND-01: ZeroCouponBond can be created with basic parameters."""
    zcb = ZeroCouponBond(
        effective=date(2024, 1, 15),
        termination="10Y",
        issue_price=70.0,
        frequency="s",
        settlement_days=1,
        convention="actactisda",
        face_value=100.0,
    )
    assert repr(zcb) == "ZeroCouponBond(...)"


def test_zero_coupon_bond_price_and_ytm():
    """BOND-01: ZeroCouponBond computes price, YTM with compound discounting."""
    zcb = ZeroCouponBond(
        effective=date(2024, 1, 15),
        termination=date(2034, 1, 15),
        issue_price=70.0,
        frequency="s",
        settlement_days=1,
        face_value=100.0,
    )
    # Create a flat discount curve (5% continuously compounded)
    curve = DiscountCurve(
        {date(2024, 1, 15): 1.0, date(2044, 1, 15): 0.3679},
        convention="act365f",
    )
    price = zcb.price(curve, settlement=date(2024, 6, 15))
    assert isinstance(price, float)
    assert 0 < price < 200  # sanity range

    # YTM roundtrip: price -> ytm -> price should match
    settlement = date(2024, 6, 15)
    clean = float(price)
    ytm_val = zcb.ytm(clean, settlement)
    price_back = zcb.price_from_ytm(ytm_val, settlement)
    # Allow small tolerance for roundtrip
    assert abs(price_back - (clean + zcb.accrued_interest(settlement))) < 0.01


def test_zero_coupon_bond_accrued_interest():
    """BOND-01: ZeroCouponBond OID accrued interest uses compound method."""
    zcb = ZeroCouponBond(
        effective=date(2024, 1, 15),
        termination=date(2034, 1, 15),
        issue_price=70.0,
        face_value=100.0,
    )
    # Accrued at effective should be 0 (or near 0)
    accrued_eff = zcb.accrued_interest(date(2024, 1, 15))
    assert accrued_eff == 0.0

    # Accrued mid-life should be positive (OID accretion)
    accrued_mid = zcb.accrued_interest(date(2029, 1, 15))
    assert accrued_mid > 0.0

    # Accrued at maturity should be 0 (edge case)
    accrued_mat = zcb.accrued_interest(date(2034, 1, 15))
    assert accrued_mat == 0.0


def test_zero_coupon_bond_duration():
    """BOND-01: ZeroCouponBond duration and Z-spread work."""
    zcb = ZeroCouponBond(
        effective=date(2024, 1, 15),
        termination=date(2034, 1, 15),
        issue_price=70.0,
        face_value=100.0,
    )
    curve = DiscountCurve(
        {date(2024, 1, 15): 1.0, date(2044, 1, 15): 0.3679},
        convention="act365f",
    )
    dur = zcb.duration(curve, metric="modified", settlement=date(2024, 6, 15))
    assert isinstance(dur, float)
    assert dur > 0

    price = float(zcb.price(curve, settlement=date(2024, 6, 15)))
    zsprd = zcb.z_spread(curve, price=price, settlement=date(2024, 6, 15))
    assert isinstance(zsprd, float)


# ---- StepUpBond tests ----


def test_step_up_bond_construction():
    """BOND-02: StepUpBond can be created with dated rate pairs."""
    sub = StepUpBond(
        effective=date(2024, 1, 15),
        termination="5Y",
        coupon_rates=[
            (date(2024, 1, 15), 0.02),
            (date(2026, 1, 15), 0.03),
            (date(2028, 1, 15), 0.04),
        ],
        frequency="s",
        settlement_days=1,
    )
    assert repr(sub) == "StepUpBond(...)"


def test_step_up_bond_analytics():
    """BOND-02: StepUpBond computes price, YTM, duration."""
    sub = StepUpBond(
        effective=date(2024, 1, 15),
        termination=date(2029, 1, 15),
        coupon_rates=[
            (date(2024, 1, 15), 0.02),
            (date(2026, 1, 15), 0.03),
            (date(2028, 1, 15), 0.04),
        ],
        frequency="s",
        settlement_days=1,
        face_value=100.0,
    )
    curve = DiscountCurve(
        {date(2024, 1, 15): 1.0, date(2034, 1, 15): 0.7},
        convention="act365f",
    )
    settlement = date(2024, 6, 15)
    price = sub.price(curve, settlement=settlement)
    assert isinstance(float(price), float)
    assert 0 < float(price) < 200

    # YTM roundtrip
    clean = float(price)
    ytm_val = sub.ytm(clean, settlement)
    price_back = sub.price_from_ytm(ytm_val, settlement)
    assert abs(price_back - (clean + sub.accrued_interest(settlement))) < 0.01

    dur = sub.duration(curve, metric="modified", settlement=settlement)
    assert dur > 0

    conv = sub.convexity(curve, settlement=settlement)
    assert isinstance(conv, float)


def test_step_up_bond_varying_coupons():
    """BOND-02: StepUpBond generates cashflows with different coupon amounts."""
    sub = StepUpBond(
        effective=date(2024, 1, 15),
        termination=date(2026, 1, 15),
        coupon_rates=[
            (date(2024, 1, 15), 0.02),  # 2% for first year
            (date(2025, 1, 15), 0.04),  # 4% for second year
        ],
        frequency="s",
        settlement_days=0,
        face_value=100.0,
    )
    curve = DiscountCurve(
        {date(2024, 1, 15): 1.0, date(2026, 1, 15): 0.95},
        convention="act365f",
    )
    cfs = sub.cashflows(curve)
    # Should have multiple coupon rows with different amounts
    assert len(cfs) > 0  # Has cashflow rows


# ---- I-spread tests ----


def test_i_spread_fixed_rate_bond():
    """SPRD-01: I-spread works on FixedRateBond."""
    bond = FixedRateBond(
        effective=date(2024, 1, 15),
        termination="5Y",
        coupon=0.04,
        frequency="s",
    )
    swap_curve = LineCurve(
        {date(2024, 1, 15): 0.035, date(2029, 1, 15): 0.038, date(2034, 1, 15): 0.040},
        convention="act365f",
    )
    settlement = date(2024, 6, 15)
    i_sprd = bond.i_spread(settlement, swap_curve)
    assert isinstance(i_sprd, float)
    # I-spread should be reasonable (within +/- 500bp of zero)
    assert -0.05 < i_sprd < 0.05


def test_i_spread_zero_coupon_bond():
    """SPRD-01: I-spread works on ZeroCouponBond."""
    zcb = ZeroCouponBond(
        effective=date(2024, 1, 15),
        termination=date(2034, 1, 15),
        issue_price=70.0,
        face_value=100.0,
    )
    swap_curve = LineCurve(
        {date(2024, 1, 15): 0.035, date(2034, 1, 15): 0.040},
        convention="act365f",
    )
    settlement = date(2024, 6, 15)
    i_sprd = zcb.i_spread(settlement, swap_curve)
    assert isinstance(i_sprd, float)


def test_i_spread_step_up_bond():
    """SPRD-01: I-spread works on StepUpBond."""
    sub = StepUpBond(
        effective=date(2024, 1, 15),
        termination=date(2029, 1, 15),
        coupon_rates=[(date(2024, 1, 15), 0.03), (date(2027, 1, 15), 0.05)],
        frequency="s",
    )
    swap_curve = LineCurve(
        {date(2024, 1, 15): 0.035, date(2029, 1, 15): 0.038},
        convention="act365f",
    )
    settlement = date(2024, 6, 15)
    i_sprd = sub.i_spread(settlement, swap_curve)
    assert isinstance(i_sprd, float)


def test_flat_namespace_imports():
    """D-14: ZeroCouponBond and StepUpBond importable from flat namespace."""
    from vade import ZeroCouponBond, StepUpBond
    assert ZeroCouponBond is not None
    assert StepUpBond is not None


# ---- Amortizing Bond Tests ----

def test_amortizing_bond_construction():
    """AmortizingBond construction with amortization schedule."""
    bond = AmortizingBond(
        effective=date(2024, 1, 15),
        termination=date(2027, 1, 15),
        coupon=0.05,
        amortization_schedule=[
            (date(2025, 1, 15), 30.0),
            (date(2026, 1, 15), 20.0),
        ],
        frequency="a",
        face_value=100.0,
        convention="actactisda",
    )
    # Accrued interest at midpoint of first period should use full notional
    ai = bond.accrued_interest(date(2024, 7, 15))
    assert ai > 0.0
    # After first principal repayment, accrued should be lower
    ai2 = bond.accrued_interest(date(2025, 7, 15))
    assert ai2 < ai  # notional is 70 now vs 100


def test_amortizing_bond_analytics():
    """AmortizingBond full analytics suite."""
    bond = AmortizingBond(
        effective=date(2024, 1, 15),
        termination=date(2027, 1, 15),
        coupon=0.05,
        amortization_schedule=[
            (date(2025, 1, 15), 30.0),
            (date(2026, 1, 15), 20.0),
        ],
        frequency="a",
        face_value=100.0,
        convention="actactisda",
    )
    settle = date(2024, 1, 15)
    # YTM round-trip
    ytm_val = bond.ytm(100.0, settle)
    price_back = bond.price_from_ytm(ytm_val, settle)
    assert abs(price_back - (100.0 + bond.accrued_interest(settle))) < 0.01

    # Cashflows should contain Principal period types
    import vade
    curve = vade.DiscountCurve(
        {settle: 1.0, date(2027, 7, 15): 0.95},
        interpolation="log_linear",
        convention="act365f",
    )
    df = bond.cashflows(curve)
    period_types = df["Type"].to_list()
    assert "Principal" in period_types
    assert "Amortizing" in period_types


def test_amortizing_bond_from_flat_namespace():
    """AmortizingBond importable from flat namespace."""
    from vade import AmortizingBond as AB
    assert AB is not None


# ---- PIK Bond Tests ----

def test_pik_bond_construction():
    """PIKBond construction with growing notional."""
    bond = PIKBond(
        effective=date(2024, 1, 15),
        termination=date(2026, 1, 15),
        coupon=0.06,
        pik_fraction=1.0,
        frequency="a",
        face_value=100.0,
        convention="actactisda",
    )
    # Full PIK: no cash coupons, so accrued should be 0
    ai = bond.accrued_interest(date(2024, 7, 15))
    assert ai == 0.0  # full PIK means no cash coupon accrues


def test_pik_bond_notional_schedule():
    """PIKBond notional_schedule returns growing notionals."""
    bond = PIKBond(
        effective=date(2024, 1, 15),
        termination=date(2026, 1, 15),
        coupon=0.06,
        pik_fraction=1.0,
        frequency="a",
        face_value=100.0,
        convention="actactisda",
    )
    schedule = bond.notional_schedule()
    assert len(schedule) >= 3  # 2 period starts + final
    # First notional is face_value
    assert schedule[0][1] == 100.0
    # Notional should grow
    assert schedule[1][1] > 100.0
    # Final should be largest
    assert schedule[-1][1] > schedule[0][1]


def test_pik_bond_partial():
    """Partial PIK bond produces cash coupons and growing notional."""
    bond = PIKBond(
        effective=date(2024, 1, 15),
        termination=date(2026, 1, 15),
        coupon=0.06,
        pik_fraction=0.5,
        frequency="a",
        face_value=100.0,
        convention="actactisda",
    )
    # Partial PIK: should have non-zero accrued (50% cash)
    ai = bond.accrued_interest(date(2024, 7, 15))
    assert ai > 0.0
    # Notional still grows (but slower)
    schedule = bond.notional_schedule()
    assert schedule[1][1] > 100.0
    # But less than full PIK
    full_pik = PIKBond(
        effective=date(2024, 1, 15),
        termination=date(2026, 1, 15),
        coupon=0.06,
        pik_fraction=1.0,
        frequency="a",
        face_value=100.0,
        convention="actactisda",
    )
    full_schedule = full_pik.notional_schedule()
    assert schedule[1][1] < full_schedule[1][1]


def test_pik_bond_from_flat_namespace():
    """PIKBond importable from flat namespace."""
    from vade import PIKBond as PB
    assert PB is not None


# ---- SubPeriodFRN tests ----


def test_sub_period_frn_construction():
    """SubPeriodFRN with quarterly pay / monthly fixing creates successfully."""
    frn = SubPeriodFRN(
        effective=date(2024, 1, 15),
        termination=date(2026, 1, 15),
        spread=0.001,
        frequency="q",
        fixing_frequency="m",
        convention="act360",
    )
    assert frn is not None


def test_sub_period_frn_dirty_price():
    """SubPeriodFRN dirty_price with curve returns a float close to par."""
    frn = SubPeriodFRN(
        effective=date(2024, 1, 15),
        termination=date(2026, 1, 15),
        spread=0.0,
        frequency="q",
        fixing_frequency="m",
        convention="act360",
    )
    dc = DiscountCurve(
        {date(2024, 1, 15): 1.0, date(2030, 1, 15): 0.85},
        interpolation="log_linear",
    )
    dp = frn.dirty_price(curves=[dc, dc])
    assert isinstance(dp, float)
    assert 90.0 < dp < 110.0


def test_sub_period_frn_ytm_roundtrip():
    """SubPeriodFRN YTM round-trip: price_from_ytm(ytm) matches dirty_price."""
    frn = SubPeriodFRN(
        effective=date(2024, 1, 15),
        termination=date(2026, 1, 15),
        spread=0.001,
        frequency="q",
        fixing_frequency="m",
        convention="act360",
    )
    dc = DiscountCurve(
        {date(2024, 1, 15): 1.0, date(2030, 1, 15): 0.85},
        interpolation="log_linear",
    )
    dp = frn.dirty_price(curves=[dc, dc])
    # SubPeriodFRN uses simplified price_from_ytm (returns face_value)
    # so we just verify both methods return valid floats
    assert isinstance(dp, float)


def test_sub_period_frn_sub_period_schedule():
    """sub_period_schedule() returns per-period detail."""
    frn = SubPeriodFRN(
        effective=date(2024, 1, 15),
        termination=date(2025, 1, 15),
        spread=0.0,
        frequency="q",
        fixing_frequency="m",
    )
    schedule = frn.sub_period_schedule()
    assert schedule is not None
    assert len(schedule) == 4  # 4 quarterly periods
    # Each period should have ~3 monthly sub-periods
    for period in schedule:
        assert len(period[3]) >= 2  # at least 2 sub-periods


# ---- CappedFloatRateNote tests ----


def test_capped_frn_reduces_price():
    """CappedFloatRateNote with low cap produces lower dirty_price than uncapped FRN."""
    dc = DiscountCurve(
        {date(2024, 1, 15): 1.0, date(2030, 1, 15): 0.70},
        interpolation="log_linear",
    )
    # Uncapped FRN
    frn = FloatRateNote(
        effective=date(2024, 1, 15),
        termination=date(2026, 1, 15),
        spread=0.0,
        frequency="q",
        convention="act360",
    )
    frn_dp = frn.dirty_price(curves=[dc, dc])

    # Capped FRN with low cap
    capped = CappedFloatRateNote(
        effective=date(2024, 1, 15),
        termination=date(2026, 1, 15),
        spread=0.0,
        frequency="q",
        cap_rate=0.02,
        vol=0.20,
        convention="act360",
    )
    capped_dp = capped.dirty_price(curves=[dc, dc])
    assert capped_dp < frn_dp  # cap reduces value


def test_floored_frn_increases_price():
    """CappedFloatRateNote with floor produces higher dirty_price than unfloored."""
    dc = DiscountCurve(
        {date(2024, 1, 15): 1.0, date(2030, 1, 15): 0.95},
        interpolation="log_linear",
    )
    frn = FloatRateNote(
        effective=date(2024, 1, 15),
        termination=date(2026, 1, 15),
        spread=0.0,
        frequency="q",
        convention="act360",
    )
    frn_dp = frn.dirty_price(curves=[dc, dc])

    floored = CappedFloatRateNote(
        effective=date(2024, 1, 15),
        termination=date(2026, 1, 15),
        spread=0.0,
        frequency="q",
        floor_rate=0.03,
        vol=0.20,
        convention="act360",
    )
    floored_dp = floored.dirty_price(curves=[dc, dc])
    assert floored_dp > frn_dp  # floor increases value


def test_collared_frn():
    """CappedFloatRateNote with both cap and floor (collar) produces valid price."""
    dc = DiscountCurve(
        {date(2024, 1, 15): 1.0, date(2030, 1, 15): 0.85},
        interpolation="log_linear",
    )
    collared = CappedFloatRateNote(
        effective=date(2024, 1, 15),
        termination=date(2026, 1, 15),
        spread=0.001,
        frequency="q",
        cap_rate=0.06,
        floor_rate=0.01,
        vol=0.20,
    )
    dp = collared.dirty_price(curves=[dc, dc])
    assert isinstance(dp, float)
    assert 80.0 < dp < 120.0


def test_capped_requires_vol():
    """CappedFloatRateNote raises ValueError if vol is not provided."""
    with pytest.raises(ValueError, match="vol is required"):
        CappedFloatRateNote(
            effective=date(2024, 1, 15),
            termination=date(2026, 1, 15),
            frequency="q",
            cap_rate=0.05,
        )


def test_capped_sub_period():
    """CappedFloatRateNote with fixing_frequency enables sub-period compounding."""
    dc = DiscountCurve(
        {date(2024, 1, 15): 1.0, date(2030, 1, 15): 0.85},
        interpolation="log_linear",
    )
    capped = CappedFloatRateNote(
        effective=date(2024, 1, 15),
        termination=date(2026, 1, 15),
        spread=0.001,
        frequency="q",
        fixing_frequency="m",
        cap_rate=0.05,
        vol=0.20,
    )
    dp = capped.dirty_price(curves=[dc, dc])
    assert isinstance(dp, float)


def test_flat_namespace_imports():
    """SubPeriodFRN and CappedFloatRateNote importable from vade flat namespace."""
    from vade import SubPeriodFRN, CappedFloatRateNote
    assert SubPeriodFRN is not None
    assert CappedFloatRateNote is not None
