import pytest
import asyncio
from mcp_stata.sessions import SessionManager

pytestmark = [pytest.mark.requires_stata, pytest.mark.xdist_group("stata_heavy")]

@pytest.mark.asyncio
async def test_session_process_isolation():
    """Verify that different sessions run in different processes."""
    manager = SessionManager()
    try:
        await manager.start() # default
        s2 = await manager.get_or_create_session("s2")
        
        default_session = manager.get_session("default")
        
        assert default_session.pid is not None
        assert s2.pid is not None
        assert default_session.pid != s2.pid
        
    finally:
        await manager.stop_all()


@pytest.mark.asyncio
async def test_session_history_diff_tracks_schema_and_results():
    """Verify command-indexed history diffs on a real Stata-backed session."""
    manager = SessionManager()
    try:
        await manager.start()
        session = manager.get_session("default")

        await session.call("run_command", {"code": "clear", "options": {"echo": False}})
        await session.call("run_command", {"code": "set obs 3", "options": {"echo": False}})
        await session.call("run_command", {"code": "gen x = _n", "options": {"echo": False}})

        stats = session.get_history_stats()
        baseline_cmd = stats["latest_command"]
        assert baseline_cmd is not None

        await session.call("run_command", {"code": "gen y = x*2", "options": {"echo": False}})
        diff = await session.get_session_diff(since_command=baseline_cmd)
        assert "y" in diff["new_variables"]
        assert diff["n_vars"] >= 2

    finally:
        await manager.stop_all()

@pytest.mark.asyncio
async def test_session_memory_isolation():
    """Verify that scalars defined in one session are not visible in another."""
    manager = SessionManager()
    try:
        await manager.start()
        s2 = await manager.get_or_create_session("s2")
        s1 = manager.get_session("default")
        
        # Define different values for x
        await s1.call("run_command", {"code": "scalar x = 123", "options": {"echo": False}})
        await s2.call("run_command", {"code": "scalar x = 456", "options": {"echo": False}})
        
        # Verify isolation
        res1 = await s1.call("run_command", {"code": "display x", "options": {"echo": False}})
        res2 = await s2.call("run_command", {"code": "display x", "options": {"echo": False}})
        
        # Stata output usually has some padding, check if value in stdout
        assert "123" in res1.get("smcl_output", "")
        assert "456" in res2.get("smcl_output", "")
        assert "456" not in res1.get("smcl_output", "")
        assert "123" not in res2.get("smcl_output", "")
        
    finally:
        await manager.stop_all()

@pytest.mark.asyncio
async def test_session_dataset_isolation():
    """Verify that loading data in one session doesn't affect another."""
    manager = SessionManager()
    try:
        await manager.start()
        s1 = manager.get_session("default")
        s2 = await manager.get_or_create_session("s2")
        
        # Load auto in s1
        await s1.call("run_command", {"code": "sysuse auto, clear", "options": {"echo": False}})
        
        # Check in s1
        res1 = await s1.call("get_data", {"count": 1})
        assert len(res1) == 1
        assert "make" in res1[0]
        
        # Check in s2 (should be empty)
        res = await s2.call("get_data", {"count": 1})
        # If there's no data, get_data returns an empty list []
        assert len(res) == 0
    finally:
        await manager.stop_all()
