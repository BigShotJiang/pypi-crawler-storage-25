#!/usr/bin/env python3
"""
Poster MCP Server
A simple MCP server for poster generation capabilities.
"""

import sys
from mcp.server.fastmcp import FastMCP

# Create the MCP server
mcp = FastMCP("Poster")

@mcp.tool()
def list_styles() -> list[str]:
    """
    List available poster styles.
    
    Returns:
        A list of available style names
    """
    return ["modern", "minimal", "bold", "elegant", "playful"]

@mcp.tool()
def get_template(template_id: str) -> str:
    """
    Get a specific template by ID.
    
    Args:
        template_id: The ID of the template to retrieve
        
    Returns:
        template information
    """
    import json
    import os
    
    # Read templates from JSON file
    template_file = os.path.join(os.path.dirname(__file__), "template", "templates.json")
    
    try:
        filePath = ''
        with open(template_file, 'r', encoding='utf-8') as f:
            templates = json.load(f)
            for template in templates["templates"]:
                if template["id"] == template_id:
                    filePath = os.path.join(os.path.dirname(__file__), "template", f"{template_id}.html")
                    break
            # 返回第一个默认模版
            if not filePath:
                filePath = os.path.join(os.path.dirname(__file__), "template", "1.html")
            with open(filePath, 'r', encoding='utf-8') as f:
                return f.read()
    except FileNotFoundError:
        return f"Template file not found"

@mcp.resource("poster://templates")
def get_templates() -> str:
    """
    Get available poster templates.
    
    Returns:
        A JSON string containing template information
    """
    import json
    import os
    
    # Read templates from JSON file
    template_file = os.path.join(os.path.dirname(__file__), "template", "templates.json")
    try:
        with open(template_file, 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        # Fallback to hardcoded templates if file doesn't exist
        return "Template file not found"


def main():
    """Main entry point for the MCP server."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
