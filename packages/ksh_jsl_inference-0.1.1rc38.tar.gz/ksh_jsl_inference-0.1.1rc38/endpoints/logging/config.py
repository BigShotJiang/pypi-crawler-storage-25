import os

DEFAULT_LOG_LEVEL: str = os.environ.get("LOG_LEVEL", "INFO").upper()
