"""Logging configuration and utilities for the endpoints package.

This module provides a centralized logging configuration for the endpoints package,
including a pre-configured logger instance and initialization functionality.
"""

import logging

from . import config

logger = logging.getLogger(__name__.split(".")[0])
logger.addHandler(logging.NullHandler())


DEFAULT_FORMAT = "%(levelname)s:[%(name)s]:%(message)s"


def init_logging():
    """Initialize logging configuration for the endpoints package.

    Sets the endpoints package logger level based on the LOG_LEVEL environment variable.
    Initializes basic root logging configuration if none is configured yet.

    Environment Variables:
        LOG_LEVEL (str): Desired log level (DEBUG, INFO, WARNING, ERROR, CRITICAL).
                        Defaults to "INFO" if not set.
    """
    log_level = getattr(logging, config.DEFAULT_LOG_LEVEL)
    logging.basicConfig(format=DEFAULT_FORMAT)
    logger.setLevel(log_level)


__all__ = ["logger", "init_logging"]
