"""Utilities for creating and monitoring SageMaker Marketplace model packages.

This module provides functions to upload validation data to S3, create SageMaker
Marketplace model packages with validation specifications, and poll package status
until completion or timeout.

Usage:
    from endpoints.sagemaker import marketplace

    marketplace.create_model_package(
        model_package_name="my-model",
        ...
    )
"""

from typing import Optional

from endpoints.core import ModelInfo
from endpoints.sagemaker import build_docker_image
from endpoints.server.utils import download_model
from endpoints.settings import DEFAULT_JOHNSNOWLABS_VERSION

from .. import utils
from . import helper
from .constants import PREFIX


def upload_validation_data(
    model_info: ModelInfo, version: str, s3_bucket: str, overwrite: bool = False
):
    """
    Uploads example validation data for a model to a specified S3 bucket for SageMaker Marketplace validation.

    Checks if validation data already exists in the given S3 location; if not, or if overwrite is True, it uploads an example based on the model info.

    Args:
        model_info (ModelInfo): The model metadata to determine S3 key and (in the future) to prepare example input data.
        version (str): The version string for this model upload.
        s3_bucket (str): The S3 bucket where validation data should be stored.
        overwrite (bool, optional): Whether to force upload even if the file exists. Defaults to False.

    Returns:
        str: The S3 URI of the uploaded or pre-existing validation data file.
    """
    s3_key = f"{PREFIX}/validation_data/{model_info.key}/{version}/validation-input/input1.jsonl"
    input_validation_data_s3_path = f"s3://{s3_bucket}/{s3_key}"

    overwrite = overwrite or not utils.s3_object_exists(input_validation_data_s3_path)

    if overwrite:
        input_validation_data_s3_path = helper.upload_validation_data_to_s3(
            # todo: use model_info.example to prepare input_data
            input_data={
                "text": "Patient Name: Samantha JohnsonAge: 52Gender: FemalePatient Info:Name: Samantha JohnsonAge: 52Gender: FemaleMedical History:Patient has a history of Chronic respiratory disease.Clinical History:Patient presented with shortness of breath and chest pain.Chief Complaint:Patient complained of chest pain and difficulty breathing.History of Present Illness:Patient has been experiencing chest pain and shortness of breath for the past week. Symptoms were relieved by medication at first but became worse over time.Past Medical History:Patient has a history of Asthma and was previously diagnosed with Bronchitis.Medications:Patient is currently taking Albuterol, Singulair, and Advair for respiratory issues.Allergies:Patient has a documented allergy to Penicillin.Physical Examination:Patient had diffuse wheezing and decreased breath sounds on lung auscultation. Heart rate and rhythm were regular.Laboratory Results:Pulmonary function test results showed a decrease in Forced Expiratory Volume in one second (FEV1).Imaging Studies:Chest x-ray showed bilateral infiltrates consistent with Chronic obstructive pulmonary disease (COPD).Diagnosis:The patient was diagnosed with COPD exacerbation."
            },
            s3_bucket=s3_bucket,
            key=s3_key,
        )
    return input_validation_data_s3_path


def upload_model_artifacts(
    model_info: ModelInfo,
    s3_bucket: str,
    overwrite: bool = False,
) -> str:
    """Packages and uploads model artifacts to an S3 bucket.

    Downloads model artifacts, creates a tarball, and uploads it to the specified S3 bucket.
    If no s3_key is provided, one is generated based on the model info.

    Args:
        model_info (ModelInfo): Metadata and configuration for the model to upload.
        s3_bucket (str): Name of the S3 bucket where the model artifacts should be uploaded.
        overwrite: (bool): To overwrite if existing target file exists. Default False

    Returns:
        str: S3 URI for the uploaded model artifacts.
    """
    s3_key = helper.build_model_artifacts_s3_key(model_info)
    model_artifacts_s3_path = f"s3://{s3_bucket}/{s3_key}"
    overwrite = overwrite or not utils.s3_object_exists(model_artifacts_s3_path)

    if overwrite:
        model_artifacts_path = download_model(model_info)
        model_artifacts_path = utils.create_model_tarball(model_artifacts_path)
        utils.upload_model_to_s3(
            file_path=model_artifacts_path,
            bucket_name=s3_bucket,
            s3_key=s3_key,
        )

    return model_artifacts_s3_path


def build_ecr_image(
    model_info: ModelInfo,
    json_license_path: Optional[str] = None,
    johnsnowlabs_version: str = DEFAULT_JOHNSNOWLABS_VERSION,
    image_name: Optional[str] = None,
    image_tag: str = "latest",
    recreate: bool = False,
):
    """Builds and pushes a Docker image to Amazon ECR for SageMaker Marketplace.

    This function builds a Docker image based on the given model info and optional license and version,
    logs into Amazon ECR, and pushes the image for later use in SageMaker Marketplace workflows.

    Args:
        model_info (ModelInfo): Metadata and info about the model.
        json_license_path (Optional[str], optional): Path to a license in JSON format for airgapped validation. Defaults to None.
        johnsnowlabs_version (str, optional): Version of JohnSnowLabs libraries to use in the image. Defaults to DEFAULT_JOHNSNOWLABS_VERSION.
        image_name (Optional[str], optional): Custom image name. If not supplied, one is constructed from model_info. Defaults to None.
        image_tag (str, optional): Image tag. Defaults to "latest".

    Returns:
        str: The URI of the pushed ECR image.
    """
    if not image_name:
        image_name, image_tag = helper.build_ecr_image_name_with_tag(model_info)

    utils.login_to_ecr()
    utils.ensure_ecr_repo_exists(image_name)

    recreate = recreate or not utils.check_ecr_image_exists(
        image_name=image_name, image_tag=image_tag
    )
    if recreate:
        # TODO: Validate that the license is an airgap license.
        # Model Validation runs with network isolation
        ecr_image = build_docker_image(
            model_id=model_info.model_id,
            language=model_info.language,
            johnsnowlabs_version=johnsnowlabs_version,
            image_name=image_name,
            image_tag=image_tag,
            license_path=json_license_path,
        )
        return utils.push_image_to_ecr(ecr_image, image_name, image_tag)

    return f"{utils.get_ecr_registry()}/{image_name}:{image_tag}"


def create_model_package(
    model_info: ModelInfo,
    s3_bucket: str,
    reuse_existing: bool = True,
    execution_role_arn: Optional[str] = None,
    johnsnowlabs_version: str = DEFAULT_JOHNSNOWLABS_VERSION,
    json_license_path: Optional[str] = None,
):
    """
    Creates and registers a SageMaker model package for John Snow Labs models. Handles building the ECR image,
    uploading model artifacts and validation data to S3, and creating the package with appropriate metadata for Marketplace.

    Args:
        model_info (ModelInfo):
            Metadata and configuration for the model to be packaged (includes IDs, language, key, etc).
        s3_bucket (str):
            Name of the S3 bucket where model artifacts and validation data will be stored.
        reuse_existing (bool, optional):
            If True, will reuse existing Docker images and S3 artifacts if present. If False, will create them anew.
            Defaults to True.
        execution_role_arn (Optional[str], optional):
            The SageMaker execution role ARN. If not provided, it will be fetched automatically.
        johnsnowlabs_version (str, optional):
            John Snow Labs package version to use for the Docker image tag.
        json_license_path (Optional[str], optional):
            Path to the JSON license file for packaging with the model (if any).

    Returns:
        dict: Response payload from the helper.create_model_package() call, representing the created/registered model package.

    Workflow:
        1. Checks the existence (or builds) the required ECR image for the model.
        2. Checks the existence (or uploads) the model artifacts to the provided S3 bucket.
        3. Checks the existence (or uploads) an example input validation dataset to S3.
        4. Constructs image URIs, S3 paths, and model metadata.
        5. Registers/creates the model package in SageMaker Marketplace using helper.create_model_package().
    """
    image_to_use = ""
    version = f"v{DEFAULT_JOHNSNOWLABS_VERSION}"

    if not execution_role_arn:
        execution_role_arn = utils.get_sagemaker_execution_role()

    ### Docker Image
    ecr_image_arn = build_ecr_image(
        model_info=model_info,
        json_license_path=json_license_path,
        johnsnowlabs_version=johnsnowlabs_version,
        image_name=image_to_use,
        image_tag=version,
        recreate=not reuse_existing,
    )

    ### Model Artifacts
    model_artifacts_s3_path = upload_model_artifacts(
        model_info=model_info, s3_bucket=s3_bucket, overwrite=not reuse_existing
    )

    ### Validation Data
    input_validation_data_s3_path = upload_validation_data(
        model_info=model_info,
        version=version,
        s3_bucket=s3_bucket,
        overwrite=not reuse_existing,
    )
    output_validation_data_s3_path = f"s3://{s3_bucket}/{PREFIX}/validation_data/{model_info.key}/{version}/validation-output"

    return helper.create_model_package(
        model_package_name=utils.format_for_sagemaker(
            f"{model_info.key}_v{DEFAULT_JOHNSNOWLABS_VERSION}"
        ),
        model_description=f"{model_info.model_id} ({model_info.language}) - SageMaker Marketplace",
        docker_image_arn=ecr_image_arn,
        execution_role_arn=execution_role_arn,
        validation_input_json_path=input_validation_data_s3_path,
        validation_output_json_path=output_validation_data_s3_path,
        model_artifacts_s3_path=model_artifacts_s3_path,
    )
