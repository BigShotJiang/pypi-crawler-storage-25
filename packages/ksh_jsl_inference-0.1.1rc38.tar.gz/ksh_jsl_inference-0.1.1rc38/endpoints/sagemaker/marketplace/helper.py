import json
import sys
import time
from typing import Dict, List, Optional

from endpoints.core import ModelInfo
from endpoints.logging import logger
from endpoints.settings import DEFAULT_JOHNSNOWLABS_VERSION

from .constants import PREFIX


def build_model_artifacts_s3_key(model_info: ModelInfo) -> str:
    """Build the S3 key for Marketplace model artifacts.

    Args:
        model_info: Metadata about the model to package.

    Returns:
        S3 key for the model artifacts tarball.
    """
    return f"{PREFIX}/{model_info.key}/v{DEFAULT_JOHNSNOWLABS_VERSION}.tar.gz"


def build_ecr_image_name_with_tag(model_info: ModelInfo):
    """Build the ECR image name and tag for the specified model.

    Args:
        model_info (ModelInfo): Metadata about the model.

    Returns:
        Tuple[str, str]: The ECR image name and image tag.
    """
    return (
        f"{PREFIX}/{model_info.key}",
        f"v{DEFAULT_JOHNSNOWLABS_VERSION}",
    )


def upload_validation_data_to_s3(input_data: Dict, s3_bucket: str, key: str) -> str:
    """Upload validation data to S3 as JSONLines and return the S3 URI.

    Stores data under key in the s3_bucket

    Args:
        input_data: JSONLines data to upload.
        key: Prefix for the S3 object to upload.

    Returns:
        Full S3 URI where the file was uploaded.
    """
    from endpoints.sagemaker.utils import get_aws_client

    s3_client = get_aws_client("s3")
    s3_path = f"s3://{s3_bucket}/{key}"
    logger.info(f"Uploading validation input data to {s3_path}")
    json_l_data = "\n".join(([json.dumps(input_data)] * 15))
    s3_client.put_object(
        Bucket=s3_bucket, Key=key, Body=bytes(json_l_data.encode("utf-8"))
    )
    return s3_path


def wait_for_model_package(
    model_package_name: str,
    wait_interval: int = 30,
    timeout: int = 1800,
) -> Dict:
    """Poll model package status until terminal state or timeout.

    Args:
        model_package_name: Name of the model package to monitor.
        wait_interval: Seconds between status checks. Default: 30.
        timeout: Max seconds to wait. Default: 1800.

    Returns:
        Final model package description.

    Raises:
        TimeoutError: If package does not reach terminal state within timeout.
    """
    from endpoints.sagemaker.utils import get_aws_client

    sagemaker_client = get_aws_client("sagemaker")
    terminal_states = ["Completed", "Failed", "Rejected"]
    elapsed_time = 0

    sys.stdout.write("Waiting for model package to complete")
    sys.stdout.flush()

    while elapsed_time < timeout:
        desc = sagemaker_client.describe_model_package(
            ModelPackageName=model_package_name
        )
        status = desc.get("ModelPackageStatus")
        logger.info(
            f"Model Package '{model_package_name}' status: {status} (elapsed: {elapsed_time}s)"
        )
        if status in terminal_states:
            sys.stdout.write("\n")
            return desc

        sys.stdout.write(".")
        sys.stdout.flush()
        time.sleep(wait_interval)
        elapsed_time += wait_interval

    sys.stdout.write("\n")
    raise TimeoutError(
        f"Model package '{model_package_name}' did not complete within {timeout} seconds."
    )


def create_model_package(
    model_package_name: str,
    model_description: str,
    docker_image_arn: str,
    execution_role_arn: str,
    validation_input_json_path: str,
    validation_output_json_path: str,
    supported_content_types: Optional[List[str]] = None,
    supported_response_mime_types: Optional[List[str]] = None,
    supported_realtime_inference_instance_types: Optional[List[str]] = None,
    supported_batch_transform_instance_types: Optional[List[str]] = None,
    model_artifacts_s3_path: Optional[str] = None,
    wait_interval: int = 30,
    timeout: int = 1800,
) -> Dict:
    """Create a SageMaker Marketplace model package and wait for completion.

    Args:
        model_package_name: Name for the model package.
        model_description: Description of the model package.
        docker_image_arn: ECR image URI for inference.
        execution_role_arn: IAM role ARN for validation jobs.
        validation_input_json_path: S3 URI for validation input data.
        validation_output_json_path: S3 URI for validation output.
        supported_content_types: Input MIME types. Default: json + jsonlines.
        supported_response_mime_types: Output MIME types. Default: json + jsonlines.
        supported_realtime_inference_instance_types: Real-time instance types. Default: ml.m4.xlarge.
        supported_batch_transform_instance_types: Batch transform instance types. Default: ml.m4.2xlarge.
        model_artifacts_s3_path: S3 URI for model artifacts.
        wait_interval: Seconds between status polls. Default: 30.
        timeout: Max seconds to wait. Default: 1800.

    Returns:
        Final model package description once terminal state is reached.

    Raises:
        TimeoutError: If package does not reach terminal state within timeout.
    """
    from endpoints.sagemaker.utils import get_aws_client

    if supported_content_types is None:
        supported_content_types = ["application/json", "application/jsonlines"]
    if supported_response_mime_types is None:
        supported_response_mime_types = [
            "application/json",
            "application/jsonlines",
        ]
    if supported_realtime_inference_instance_types is None:
        supported_realtime_inference_instance_types = ["ml.m4.xlarge"]
    if supported_batch_transform_instance_types is None:
        supported_batch_transform_instance_types = ["ml.m4.2xlarge"]

    container_spec = {"Image": docker_image_arn}
    if model_artifacts_s3_path:
        container_spec["ModelDataUrl"] = model_artifacts_s3_path

    sagemaker_client = get_aws_client("sagemaker")
    logger.info(f"Creating model package '{model_package_name}'...")
    sagemaker_client.create_model_package(
        ModelPackageName=model_package_name,
        ModelPackageDescription=model_description,
        InferenceSpecification={
            "Containers": [container_spec],
            "SupportedTransformInstanceTypes": supported_batch_transform_instance_types,
            "SupportedRealtimeInferenceInstanceTypes": supported_realtime_inference_instance_types,
            "SupportedContentTypes": supported_content_types,
            "SupportedResponseMIMETypes": supported_response_mime_types,
        },
        CertifyForMarketplace=True,
        ValidationSpecification={
            "ValidationRole": execution_role_arn,
            "ValidationProfiles": [
                {
                    "ProfileName": "Validation-test",
                    "TransformJobDefinition": {
                        "BatchStrategy": "MultiRecord",
                        "Environment": {"LOG_LEVEL": "DEBUG"},
                        "TransformInput": {
                            "DataSource": {
                                "S3DataSource": {
                                    "S3DataType": "S3Prefix",
                                    "S3Uri": validation_input_json_path,
                                }
                            },
                            "ContentType": "application/jsonlines",
                            "SplitType": "Line",
                        },
                        "TransformOutput": {
                            "S3OutputPath": validation_output_json_path,
                        },
                        "TransformResources": {
                            "InstanceType": supported_batch_transform_instance_types[0],
                            "InstanceCount": 1,
                        },
                    },
                }
            ],
        },
    )

    logger.info(
        f"Model package '{model_package_name}' created. Waiting for terminal state..."
    )
    result = wait_for_model_package(model_package_name, wait_interval, timeout)
    logger.info(
        f"Model package '{model_package_name}' reached terminal status: {result.get('ModelPackageStatus')}"
    )
    return result
