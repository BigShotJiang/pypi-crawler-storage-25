import time
from http import HTTPStatus
from typing import Dict

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.concurrency import run_in_threadpool
from pydantic import ValidationError

from endpoints.core.models.schema import SchemaValidationError
from endpoints.logging import logger
from endpoints.server.dependencies import parse_multi_modal_input
from endpoints.server.response.generator import get_default_response_generator

router = APIRouter()

SUPPORTED_RESPONSE_MIMETYPES = ["application/json", "application/jsonlines"]


@router.post("/invocations")
async def invocations(
    request: Request,
    data: Dict = Depends(parse_multi_modal_input),
    response_generator=Depends(get_default_response_generator),
):
    """Handle SageMaker invocations for model inference.

    Parses request payloads in supported formats, runs model prediction,
    and serializes the response in the requested format.

    Args:
        request: FastAPI request containing model and payload.

    Returns:
        Response: FastAPI response with serialized predictions.

    Raises:
        HTTPException: If the content type is unsupported, the payload is invalid,
            or an internal error occurs.
    """
    try:
        model = request.app.state.model_info.model

        prediction_start_time = time.perf_counter()
        predictions = {}
        is_blocking = getattr(request.app.state, "is_blocking", False)
        if not is_blocking:
            predictions = await run_in_threadpool(model.predict, data)
        else:
            ## This block the request thread
            predictions = model.predict(data)

        logger.debug("Prediction time: %s", time.perf_counter() - prediction_start_time)

        return response_generator(predictions)
    except (SchemaValidationError, ValidationError) as e:
        logger.error(e)
        raise HTTPException(
            status_code=HTTPStatus.BAD_REQUEST,
            detail=str(e),
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(e)
        raise HTTPException(
            status_code=HTTPStatus.INTERNAL_SERVER_ERROR, detail="Internal server error"
        )
