from dataclasses import dataclass
from typing import Optional

from endpoints import ModelType
from endpoints.core.models import BaseModel


@dataclass
class ModelInfo:
    """Data class for storing information about a registered model.

    Attributes:
        id (str): Unique identifier for the model
        model (BaseModel): The model instance that handles inference
        language (str): Language code for the model (default: "en")
        model_type (ModelType): The type for this model (default: ModelType.HEALTHCARE_NLP)
        artifacts_path (Optional[str]): Path to model artifacts, only used when model_type is ModelType.LOCAL

    Examples:
        ```python
        from endpoints.core import ModelInfo
        from endpoints.johnsnowlabs.healthcare.models import MedNlpModel
        from endpoints import ModelType

        # Create a ModelInfo instance for a medical NLP model
        model_info = ModelInfo(
            model_id="medical_ner_model",
            model=MedNlpModel(),
            language="en",
            model_type=ModelType.HEALTHCARE_NLP
        )

        print(f"Model ID: {model_info.model_id}")
        print(f"Model key: {model_info.key}")
        ```
    """

    model_id: str
    model: BaseModel
    language: str = "en"  # en, de, gr
    model_type: ModelType = ModelType.PRETRAINED_HEALTHCARE
    # artifacts_path only used when model_type is ModelType.LOCAL
    artifacts_path: Optional[str] = None

    @staticmethod
    def generate_key(model_id: str, language: str) -> str:
        """Generate a key from model_id and language.

        Args:
            model_id: The model identifier
            language: The language code

        Returns:
            The key for the model info

        """
        return f"{model_id}_{language}"

    @property
    def key(self) -> str:
        """Get the unique key for this model instance.

        Returns:
            str: The unique key for the model instance

        """
        return self.generate_key(self.model_id, self.language)
