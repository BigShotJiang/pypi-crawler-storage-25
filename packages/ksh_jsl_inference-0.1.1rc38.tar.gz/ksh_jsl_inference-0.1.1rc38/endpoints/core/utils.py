import os

from endpoints import ModelType
from endpoints.logging import logger
from endpoints.settings import MODEL_LOCATION
from endpoints.utils import copy_from_source_to_target

from .model_registry import ModelInfo


def download_local_model(model_info: ModelInfo) -> str:
    """Download a local model into the configured model location.

    Args:
        model_info: Model metadata describing a local model and its artifacts.

    Returns:
        str: The configured model location path where artifacts were copied.

    Raises:
        Exception: If the model type is not local or artifacts are missing.
        FileNotFoundError: If artifacts cannot be found at the expected path.
    """
    if model_info.model_type != ModelType.LOCAL:
        raise Exception(f"Model Type should be ModelType.LOCAL")
    if model_info.artifacts_path is None:
        raise Exception("Model artifacts path is missing")

    if (
        model_info.model_type == ModelType.LOCAL
        and model_info.artifacts_path is not None
    ):
        try:
            copy_from_source_to_target(model_info.artifacts_path, MODEL_LOCATION)
        except FileNotFoundError:
            # Extract filename from artifacts_path and try to find on current directory

            filename = os.path.basename(model_info.artifacts_path)
            current_dir_path = os.path.join(os.getcwd(), filename)
            if os.path.exists(current_dir_path):
                copy_from_source_to_target(current_dir_path, MODEL_LOCATION)
            else:
                raise FileNotFoundError(
                    f"Model artifacts not found at {model_info.artifacts_path} "
                    f"or in current directory as {filename}"
                )
    else:
        logger.warning("Skipping as not a local model ...")

    return MODEL_LOCATION
