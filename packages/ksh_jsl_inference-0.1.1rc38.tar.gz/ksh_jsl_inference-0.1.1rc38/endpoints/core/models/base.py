from abc import ABC, abstractmethod
from typing import Dict, List, Union

from endpoints.utils import convert_to_a_list

from .schema import Schema, SchemaCollection, SchemaValidationError

DEFAULT_INPUT_KEYS = ["text", "input_text", "texts", "input_texts", "file"]


class BaseModel(ABC):
    """Base class for all inference models."""

    def __init__(self, input: Schema, input_params: SchemaCollection, output: Schema):
        """Initialize the base inference model.

        Args:
            input: The input schema.
            input_params: The input parameters schema.
            output: The output schema.
        """
        self._input = input
        assert (
            input._field in DEFAULT_INPUT_KEYS
        ), f"Input schema must contain one of the following keys: {DEFAULT_INPUT_KEYS}"

        self._input_params = input_params
        self._output = output

    def _validate_input(self, input_data: Union[Dict, List[Dict]]) -> Dict:
        inputs = []
        params = []

        def _validate_common_input(input: Dict):
            validated_input = self._input.validate(input)
            validated_input_params = self._input_params.validate(input)

            convert_to_a_list(validated_input, inputs)

            # Append the same params for each input
            for input in inputs:
                params.append(validated_input_params)

        if isinstance(input_data, dict):
            _validate_common_input(input_data)

        if isinstance(input_data, list):
            for item in input_data:
                _validate_common_input(item)
            if not inputs:
                raise SchemaValidationError(
                    f"Input data must contain one of the following keys: {DEFAULT_INPUT_KEYS}"
                )

        return {"inputs": inputs, "params": params}

    def predict(self, input_data: Union[Dict, List[Dict]]) -> Dict:
        """Validate input, perform prediction, and return the output.

        Args:
            input_data: The input data to be predicted.

        Returns:
            The output of the prediction.
        """
        validated_data = self._validate_input(input_data)
        predictions = self.concrete_predict(validated_data)
        predictions = self._output.validate(predictions)
        return {
            self._output._field: (
                predictions[0] if len(predictions) == 1 else predictions
            )
        }

    @abstractmethod
    def concrete_predict(self, input_data: Dict) -> Dict:
        """Run concrete prediction logic.

        All subclasses should implement this method.

        Args:
            input_data: The input data to be predicted by the model. The input data
                contains "inputs" and "params" keys. The "inputs" key contains the
                input data to be predicted and the "params" key contains the input
                parameters.

        Returns:
            The output of the prediction. Output schema needs to match.
        """
        pass

    @abstractmethod
    def get_python_requirements(self) -> List[str]:
        """Return required Python packages for the model."""
        pass

    @abstractmethod
    def dispose(self):
        """Dispose of the model and release any resources."""
        pass
