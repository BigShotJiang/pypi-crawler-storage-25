import os
import shutil
from typing import Optional

from endpoints.logging import init_logging, logger
from endpoints.server import download_model, find_model_to_serve

from .utils import (
    install_johnsnowlabs_from_docker_secret,
)


def _cleanup_container():
    home_dir = os.path.expanduser("~")
    paths_to_remove = [
        os.path.join(home_dir, "cache_pretrained"),
        os.path.join(home_dir, ".javacpp"),
        os.path.join(home_dir, ".cache"),
        os.path.join("/tmp"),
    ]
    for path in paths_to_remove:
        shutil.rmtree(path, ignore_errors=True)


def setup_container_env(
    model_id: Optional[str] = None,
    language: Optional[str] = None,
    store_license: bool = True,
    store_model: bool = False,
    include_visual_nlp: bool = False,
):
    """
    Set up the container environment required to serve a model.

    This function initializes logging, installs John Snow Labs packages from
    Docker secrets (if configured), resolves the model from the registry, and
    prepares runtime assets for inference.

    Args:
        model_id (str): Identifier of the model to resolve from the registry.
        language (str): Model language code. Defaults to ``"en"``.
        store_license (bool): Whether to keep license files in the container
            after setup. Defaults to ``True``.
        store_model (bool): Whether to persist model artifacts in the
            container. Defaults to ``False``.
        include_visual_nlp (bool): Whether to include sparkocr dependency in the
            container. Defaults to ``False``.

    Returns:
        None

    Examples:
        >>> from endpoints.container import setup_container_env
        >>> setup_container_env(model_id="clinical_deidentification", language="en")
    """

    init_logging()
    install_johnsnowlabs_from_docker_secret(visual=include_visual_nlp)
    if store_model:
        model_info = find_model_to_serve(model_id=model_id, language=language)
        download_model(model_info=model_info)

    if not store_license:
        logger.info("Removing the licenses")
        shutil.rmtree(
            f"/{os.path.expanduser('~')}/.johnsnowlabs/licenses", ignore_errors=True
        )

    _cleanup_container()
