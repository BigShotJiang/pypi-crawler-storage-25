"""Container module for serving inference models in Docker environments.

This module provides functionality for containerizing and serving machine learning
models using Docker. It includes utilities for building Docker images, generating
Docker files, and setting up container environments for model inference.

The module supports various deployment platforms and provides a standardized way
to package and deploy models in containerized environments.
"""

from typing import Optional

from endpoints.server import find_model_to_serve, serve
from endpoints.settings import config

from .setup import setup_container_env
from .utils import (
    build_docker_image,
    format_docker_image_name,
    format_image_tag,
    generate_docker_files,
    validate_docker_image_name,
    validate_image_tag,
)


# Default entrypoint for the Docker containers
def _init(command, model_id: Optional[str], language: Optional[str]):
    """Initialize and execute commands for containerized model serving.

    This function serves as the main entrypoint for Docker containers, handling
    different commands for model operations. Currently supports serving models
    for inference.

    Args:
        command: The command to execute ('serve' for model serving).
        model_id (str): Unique identifier for the model to be loaded.
        language (str): Programming language or model language specification.

    Raises:
        NotImplementedError: If the provided command is not implemented.

    Example:
        >>> _init('serve', 'bert-base-uncased', 'en')
        # Starts serving the specified model
    """
    # For Sagemaker, serve and train are the possible commands
    if command == "serve":
        model = find_model_to_serve(model_id=model_id, language=language)
        serve(
            model=model,
            platform=config.platform,
        )
    else:
        raise NotImplementedError("Command not implemented")


__all__ = [
    "build_docker_image",
    "generate_docker_files",
    "setup_container_env",
    "format_image_tag",
    "format_docker_image_name",
    "validate_docker_image_name",
    "validate_image_tag",
]
