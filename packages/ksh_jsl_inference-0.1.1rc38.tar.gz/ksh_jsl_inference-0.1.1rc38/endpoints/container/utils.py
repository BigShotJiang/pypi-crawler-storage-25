import os
import re
import subprocess
from typing import List, Optional

from endpoints import ModelType
from endpoints import johnsnowlabs as jsl
from endpoints.__about__ import __version__
from endpoints.core import ModelInfo, ModelRegistry
from endpoints.core.models import BaseModel
from endpoints.logging import logger
from endpoints.server import get_requirements
from endpoints.settings import JSL_CACHE_PRETRAINED_DIR, PACKAGE_NAME
from endpoints.utils import (
    copy_and_replace,
    copy_from_source_to_target,
    generate_license_file,
)

from .requests import GenerateDockerFilesRequest

current_dir = os.path.dirname(__file__)


def _get_requirements_for_docker_image(req: GenerateDockerFilesRequest) -> List[str]:
    """Generate requirements list for Docker image based on platform and model.

    This helper function creates a list of Python package requirements needed
    for the Docker image, including the main package and additional dependencies
    based on the target platform and model type.

    Args:
        req (GenerateDockerFilesRequest): Request object containing model info,
            platform details, and johnsnowlabs version requirements.

    Returns:
        list[str]: List of package requirements in pip format.

    Example:
        ```python
        req = GenerateDockerFilesRequest(model=model, platform=Platform.SAGEMAKER)
        requirements = _get_requirements_for_docker_image(req)
        print(requirements)
        # ['endpoints==1.0.0', 'torch>=1.9.0', 'transformers>=4.0.0']
        ```
    """

    requirements = [f"{PACKAGE_NAME}>={__version__}"]

    inference_obj = None
    if isinstance(req.model.model, BaseModel):
        inference_obj = req.model.model
    requirements.extend(
        get_requirements(req.platform, req.johnsnowlabs_version, inference_obj)
    )

    return requirements


def __generate_requirements_file(req):
    """Generate and write requirements.txt file for Docker image build.

    Creates a requirements.txt file in the specified output directory containing
    all necessary Python package dependencies for the Docker image.

    Args:
        req (GenerateDockerFilesRequest): Request object containing model info
            and output directory path.

    Note:
        This function writes the requirements.txt file directly to disk at
        {req.output_dir}/requirements.txt. The file will be created or
        overwritten if it already exists.

    Example:
        ```python
        req = GenerateDockerFilesRequest(output_dir="/tmp/build")
        __generate_requirements_file(req)
        # Creates /tmp/build/requirements.txt with package dependencies
        ```
    """
    requirements = _get_requirements_for_docker_image(req)

    logger.debug(f"Generating requirements file in: {req.output_dir}")
    with open(f"{req.output_dir}/requirements.txt", "w+") as f:
        f.write("\n".join(requirements))


def _get_env_setup_command(req: GenerateDockerFilesRequest):
    """Generate Python command for setting up container environment.

    Creates a Python command string that will be executed during Docker image
    build to set up the container environment with the specified model,
    language, and configuration options.

    Args:
        req (GenerateDockerFilesRequest): Request object containing model info,
            language, johnsnowlabs version, license settings, and store options.

    Returns:
        str: Python command string for container environment setup.

    Example:
        ```python
        req = GenerateDockerFilesRequest(
            model=model_info,
            language="en",
            johnsnowlabs_version="5.5.0",
            no_license=False,
            store_model=True
        )
        cmd = _get_env_setup_command(req)
        print(cmd)
        # "python3 -c \"from endpoints.container import setup_container_env as S;S(model_id='bert-base', language='en', ...)\""
        ```
    """

    setup_container_args = {
        "store_license": not req.no_license,
        "store_model": req.store_model,
        "model_id": None,
        "language": None,
        "include_visual_nlp": jsl.is_visual_nlp_model(req.model.model),
    }

    if req.store_model:
        setup_container_args["model_id"] = f"'{req.model.model_id}'"
        setup_container_args["language"] = f"'{req.language}'"

    args_string = ",".join(
        [
            f"{key}={value}"
            for key, value in setup_container_args.items()
            if value is not None
        ]
    )
    container_serve_command = f"S({args_string})"
    setup_env_command = (
        "python3 -c "
        '"from endpoints.container import setup_container_env as S;'
        f'{container_serve_command}"'
    )
    return setup_env_command


def __get_entrypoint_command(model: ModelInfo):
    """Generate Python entrypoint command for Docker container.

    Creates a Python command string that serves as the entrypoint for the
    Docker container, setting up the model serving functionality with the
    specified model ID and language.

    Args:
        model (ModelInfo): Model information object containing model ID and
            language specifications.

    Returns:
        str: Python import and execution command for container entrypoint.

    Example:
        ```python
        model_info = ModelInfo(id="bert-base-uncased", language="en")
        cmd = __get_entrypoint_command(model_info)
        print(cmd)
        # "import sys;from endpoints import container as C;C._init(sys.argv[1], model_id='bert-base-uncased', language='en')"
        ```
    """
    return (
        "import sys;"
        f"from endpoints import container as C;"
        f"C._init(sys.argv[1], model_id='{model.model_id}', language='{model.language}')"
    )


def _generate_docker_files_v1(req: GenerateDockerFilesRequest):
    """Generate Docker files using version 1 template and configuration.

    Creates all necessary Docker build files including Dockerfile, requirements.txt,
    and license files. Handles local model artifacts copying and template
    substitution for Docker image generation.

    Args:
        req (GenerateDockerFilesRequest): Request object containing all
            configuration details including model info, output directory,
            platform settings, and build options.

    Note:
        This function performs the following operations:
        - Generates requirements.txt file
        - Creates license file
        - Copies local model artifacts if applicable
        - Processes Dockerfile template with proper substitutions
        - Writes all files to the specified output directory

    Example:
        ```python
        req = GenerateDockerFilesRequest(
            model=model_info,
            output_dir="/tmp/build",
            platform=Platform.SAGEMAKER
        )
        _generate_docker_files_v1(req)
        # Creates Dockerfile, requirements.txt, and license in /tmp/build/
        ```
    """

    __generate_requirements_file(req)

    generate_license_file(req.output_dir)
    setup_env_command = _get_env_setup_command(req)

    entrypoint_command = __get_entrypoint_command(req.model)

    copy_artifacts_instruction = ""
    if req.model.model_type == ModelType.LOCAL and req.model.artifacts_path:
        # For local models, copy the artifacts to the build context
        artifact_base_name = os.path.basename(req.model.artifacts_path)
        copy_from_source_to_target(
            source=req.model.artifacts_path,
            target=os.path.join(req.output_dir, artifact_base_name),
        )
        copy_artifacts_instruction = f"COPY {artifact_base_name} ./{artifact_base_name}"

    copy_and_replace(
        f"{current_dir}/Dockerfile",
        f"{req.output_dir}/Dockerfile",
        {
            "{{STORE_LICENSE}}": str(not req.no_license),
            "{{STORE_MODEL}}": str(req.store_model),
            "{{LANGUAGE}}": req.language,
            "{{ENTRYPOINT}}": f'ENTRYPOINT ["python3", "-c", "{entrypoint_command}"]',
            "{{ENVIRONMENT_VARIABLES}}": f"ENV PLATFORM={req.platform.value}\nENV MODEL_FROM_DISK=True",
            "{{SETUP_ENVIRONMENT}}": setup_env_command,
            "{{COPY_ARTIFACTS_INSTRUCTION}}": copy_artifacts_instruction,
        },
    )


def _generate_docker_files(req: GenerateDockerFilesRequest):
    """Generate Docker build files with common setup logic.

    Common entry point for generating Docker files that handles output directory
    creation and delegates to version-specific file generation logic.

    Args:
        req (GenerateDockerFilesRequest): Request object containing all
            configuration details for Docker file generation.

    Returns:
        str: Path to the output directory containing generated Docker files.

    Note:
        This function creates the output directory if it doesn't exist and
        currently delegates to _generate_docker_files_v1 for the actual
        file generation logic.

    Example:
        ```python
        req = GenerateDockerFilesRequest(output_dir="/tmp/build")
        output_path = _generate_docker_files(req)
        print(output_path)
        # /tmp/build
        ```
    """

    os.makedirs(req.output_dir, exist_ok=True)
    _generate_docker_files_v1(req)

    return req.output_dir


def generate_docker_files(model_id: str, language: str, **kwargs) -> str:
    """Generates Docker files to serve JSL model.

    Args:
        model_id (str): The identifier of the model to generate Docker files for.
        johnsnowlabs_version (str, optional): Johnsnowlabs version to use.
            Default: DEFAULT_JOHNSNOWLABS_VERSION
        no_license (bool, optional): Indicate whether to include license in the docker image.
            Default: False
        language (str): The language of the model. Default: 'en'
        output_dir (str, optional): The output directory to store the generated files.
            If not provided, a temporary directory is used.
        store_model (bool, optional): Indicate whether to include model in the docker image.
            Default: False
        platform (Platform, optional): Platform to target. Default: Platform.SAGEMAKER
    Returns:
        str: The path to the directory containing the generated docker files

    Example:
        ```python
        from endpoints.container import generate_docker_files

        generate_docker_files(
            model_id="clinical_deidentification",
            johnsnowlabs_version="5.5.0",
            no_license=False,
            store_model=True,
            language="en"
        )
        ```
    """
    model = ModelRegistry.find(model_id=model_id, language=language)

    logger.info(f"Generating Docker files for model: {model_id}")

    req = GenerateDockerFilesRequest(model=model, language=language, **kwargs)

    output_dir = _generate_docker_files(req)

    logger.info(f"Docker files generated in: {output_dir}")
    return output_dir


def build_docker_image(
    image_name: str,
    license_path: Optional[str],
    build_context_dir: str,
    no_cache: bool = False,
    image_tag: str = "latest",
    **kwargs,
) -> str:
    """Build a Docker image using the specified build context directory.

    Executes Docker build command with proper build contexts, license handling,
    and platform specifications for creating a containerized model serving image.

    Args:
        image_name (str): Name for the Docker image to be built.
        license_path (Optional[str]): Path to the license file. If None or invalid,
            will attempt to find license from JSL_HOME.
        build_context_dir (str): Directory containing the Dockerfile and build context.
        no_cache (bool, optional): Whether to build without using Docker cache.
            Defaults to False.
        image_tag (str, optional): Tag for the Docker image. Defaults to "latest".
        **kwargs: Additional keyword arguments (currently unused).

    Returns:
        image_name: Name of the docker image.

    Raises:
        subprocess.CalledProcessError: If the Docker build command fails.

    Note:
        This function:
        - Validates and locates the license file
        - Sets up build contexts for model registry and cache directories
        - Executes Docker build with linux/amd64 platform targeting
        - Uses Docker secrets for secure license handling

    Example:
        ```python
        build_docker_image(
            image_name="my-model-server",
            license_path="/path/to/license.json",
            build_context_dir="/tmp/docker-build",
            image_tag="v1.0.0"
        )
        ```
    """
    if license_path and jsl.is_license_valid(license_path):
        license_to_use = license_path
    else:
        license_to_use = jsl.find_license_from_jsl_home()

    # Make sure build-context dirs exists
    os.makedirs(JSL_CACHE_PRETRAINED_DIR, exist_ok=True)
    build_command = [
        "docker",
        "build",
        "--build-context",
        f"jsl_model_registry={ModelRegistry.get_persisted_dir()}",
        "--build-context",
        f"jsl_cache_pretrained={JSL_CACHE_PRETRAINED_DIR}",
        "--platform=linux/amd64",
        "--provenance=false",
    ]

    if no_cache:
        build_command.append("--no-cache")

    build_command.extend(
        [
            "--secret",
            f"id=license,src={license_to_use}",
            "-t",
            f"{image_name}:{image_tag}",
            build_context_dir,
        ]
    )

    logger.info(f"Executing Docker build command: {' '.join(build_command)}")

    subprocess.run(build_command, check=True)
    logger.info(f"Docker image '{image_name}:{image_tag}' built successfully!")

    return f"{image_name}:{image_tag}"


def is_valid_output_dir(directory: str) -> bool:
    """
    Validates if the specified directory contains the required Docker files.

    Args:
        directory (str): Path to the directory to validate.

    Returns:
        bool: True if the directory contains the required files, False otherwise.
    """
    if not directory or not os.path.isdir(directory):
        return False

    required_files = ["Dockerfile", "requirements.txt"]
    return all(os.path.isfile(os.path.join(directory, file)) for file in required_files)


def install_johnsnowlabs_from_docker_secret(visual: bool = False):
    """Install John Snow Labs library using license from Docker secret.

    Installs the John Snow Labs NLP library using a license file that has been
    mounted as a Docker secret at /run/secrets/license. This function is typically
    called during Docker container initialization to set up the NLP environment
    with proper licensing.

    Note:
        This function expects the license to be available as a Docker secret
        mounted at /run/secrets/license. The installation is performed without
        browser interaction, making it suitable for containerized environments.

    Raises:
        Exception: If the license file is not found or invalid, or if the
            installation process fails.

    Example:
        ```python
        install_johnsnowlabs_from_docker_secret()
        # Installs johnsnowlabs with license from Docker secret
        ```
    """

    jsl.install(json_license_path="/run/secrets/license", visual=visual)


def validate_docker_image_name(image_name: str) -> bool:
    """Validate a Docker image name according to Docker specifications.

    Validates that the provided image name conforms to Docker's naming
    conventions and requirements for image names.

    Args:
        image_name (str): The Docker image name to validate.

    Returns:
        bool: True if the image name is valid, False otherwise.

    Note:
        Docker image name validation rules:
        - 1-255 characters total length
        - Can contain lowercase letters, digits, separated by slashes
        - Each component must start/end with alphanumeric characters
        - Allowed characters: a-z, 0-9, ._- (within components), / (separator)

    Example:
        ```python
        validate_docker_image_name("my-app/backend")
        # True
        validate_docker_image_name("My-App/Backend")  # uppercase not allowed
        # False
        validate_docker_image_name("my_app.service")
        # True
        ```
    """
    if len(image_name) < 1 or len(image_name) > 255:
        return False

    components = image_name.split("/")

    component_pattern = r"^[a-z0-9]+(?:[._-][a-z0-9]+)*$"
    for comp in components:
        if not re.match(component_pattern, comp):
            return False

    return True


def validate_image_tag(image_tag: str) -> bool:
    """Validate a Docker image tag according to Docker specifications.

    Validates that the provided image tag conforms to Docker's naming
    conventions and requirements for image tags.

    Args:
        image_tag (str): The Docker image tag to validate.

    Returns:
        bool: True if the image tag is valid, False otherwise.

    Note:
        Docker image tag validation rules:
        - 1-128 characters maximum length
        - Must start with alphanumeric character
        - Allowed characters: A-Za-z0-9._-

    Example:
        ```python
        validate_image_tag("v1.0.0")
        # True
        validate_image_tag("latest")
        # True
        validate_image_tag("-invalid")  # cannot start with dash
        # False
        validate_image_tag("valid_tag.123")
        # True
        ```
    """
    pattern = r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$"
    return bool(re.match(pattern, image_tag))


def format_docker_image_name(image_name: str) -> str:
    """Format a Docker image name to be specification-compliant.

    Converts the provided image name to conform with Docker naming specifications
    by converting to lowercase, replacing invalid characters, and ensuring
    proper component structure.

    Args:
        image_name (str): The Docker image name to format.

    Returns:
        str: A Docker specification-compliant image name.

    Raises:
        ValueError: If the image name cannot be made valid even after formatting.

    Note:
        Formatting operations performed:
        - Converts to lowercase
        - Replaces invalid characters with '-'
        - Ensures valid component structure (alphanumeric start/end)
        - Preserves '/' separators between components

    Example:
        ```python
        format_docker_image_name("My-App/Backend Service")
        # "my-app/backend-service"
        format_docker_image_name("registry.com/My_App")
        # "registry.com/my_app"
        ```
    """
    components = image_name.split("/")
    formatted_components = []

    for comp in components:
        formatted = re.sub(r"[^a-z0-9._-]", "-", comp.lower())

        formatted = re.sub(r"^[^a-z0-9]+", "", formatted)
        formatted = re.sub(r"[^a-z0-9]+$", "", formatted)

        if not formatted:
            formatted = "invalid"

        formatted_components.append(formatted)

    formatted_name = "/".join(formatted_components)

    if not validate_docker_image_name(formatted_name):
        raise ValueError(
            f"Invalid Docker image name after formatting: {formatted_name}"
        )

    return formatted_name


def format_image_tag(image_tag: str) -> str:
    """Format a Docker image tag to be specification-compliant.

    Converts the provided image tag to conform with Docker naming specifications
    while preserving case sensitivity and ensuring proper structure.

    Args:
        image_tag (str): The Docker image tag to format.

    Returns:
        str: A Docker specification-compliant image tag.

    Raises:
        ValueError: If the image tag cannot be made valid even after formatting.

    Note:
        Formatting operations performed:
        - Preserves case (unlike image names)
        - Replaces invalid characters with '.'
        - Ensures tag starts with alphanumeric character
        - Truncates to 128 characters maximum
        - Defaults to "latest" if no valid characters remain

    Example:
        ```python
        format_image_tag("v1.0.0-beta@latest")
        # "v1.0.0-beta.latest"
        format_image_tag("@#invalid-start")
        # "invalid-start"
        format_image_tag("###")
        # "latest"
        ```
    """
    formatted_tag = re.sub(r"[^A-Za-z0-9._-]", ".", image_tag)

    formatted_tag = re.sub(r"^[^A-Za-z0-9]+", "", formatted_tag)

    formatted_tag = formatted_tag[:128]

    formatted_tag = re.sub(r"[^A-Za-z0-9]+$", "", formatted_tag)

    if not formatted_tag:
        formatted_tag = "latest"

    if not validate_image_tag(formatted_tag):
        raise ValueError(f"Invalid Docker image tag after formatting: {formatted_tag}")

    return formatted_tag
