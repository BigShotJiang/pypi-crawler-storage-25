"""This contains Docker templates for the older approach to publish to Sagemaker / Snowflake"""
