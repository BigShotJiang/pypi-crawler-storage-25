from typing import cast

from fastapi import FastAPI

from endpoints import Platform
from endpoints.core import ModelInfo
from endpoints.johnsnowlabs import (
    JslModel,
    is_chroma_resolver_model,
    is_visual_nlp_model,
)
from endpoints.johnsnowlabs.spark_session import get_spark_session
from endpoints.logging import logger

from .request.parsers import (
    parse_json,
    parse_json_with_file,
    parse_jsonlines,
    parse_octet_stream,
)

SUPPORTED_VISUAL_CONTENT_TYPES = [
    "application/octet-stream",
    "application/json",
    "application/pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "image/bmp",
    "image/gif",
    "image/jpeg",
    "image/png",
    "image/tiff",
    "image/webp",
]

SUPPORTED_TEXT_CONTENT_TYPES = [
    "application/json",
    "application/jsonlines",
]


def _configure_healthcare_nlp_pipeline_for_platform(
    model_info: ModelInfo, platform: Platform
):
    """Load and attach healthcare NLP pipelines for the selected platform.

    Args:
        model_info: Model metadata and instance to configure.
        platform: Target runtime platform selection.
    """

    from endpoints.johnsnowlabs.healthcare.loader import HealthcareModelLoader
    from endpoints.johnsnowlabs.healthcare.models import (
        ChromaDbResolverModel,
        MedNlpModel,
    )

    healthcare_nlp_model = cast(MedNlpModel, model_info.model)

    if is_chroma_resolver_model(healthcare_nlp_model):
        from endpoints.johnsnowlabs.healthcare.loader.chroma_loader import (
            ChromaResolverModelLoader,
        )

        chroma_model = cast(ChromaDbResolverModel, healthcare_nlp_model)
        loader = ChromaResolverModelLoader(model_info)
        model_artifacts = loader.load()
        chroma_model.pipeline = model_artifacts["pipeline"]
        chroma_model.local_db = model_artifacts["additional_artifacts"]

    else:
        loader = HealthcareModelLoader(model_info)
        healthcare_nlp_model.pipeline = loader.load()["pipeline"]


def _configure_visual_nlp_pipeline_for_platform(
    app, model_info: ModelInfo, platform: Platform
):
    """Load visual NLP pipeline and adjust app settings.

    Args:
        app: FastAPI application instance.
        model_info: Model metadata and instance to configure.
        platform: Target runtime platform selection.
    """

    from endpoints.johnsnowlabs.visual.loader import VisualNlpModelLoader
    from endpoints.johnsnowlabs.visual.models import VisualNlpModel

    visual_nlp_model = cast(VisualNlpModel, model_info.model)
    visual_nlp_loader = VisualNlpModelLoader(model_info)

    visual_nlp_model.pipeline = visual_nlp_loader.load()["pipeline"]
    ## Disable lightpipelines for Visual Model as there is an issue with them
    logger.warning("This model doesn't support lightpipelines.")
    app.state.is_blocking = True

    # TODO: Find some condition use lp or PretrainedPipeline for Visual Models
    visual_nlp_model.use_lp = False


def _configure_jsl_for_app(app: FastAPI, model_info: ModelInfo):
    """Attach Spark session and default blocking behavior.

    Args:
        app: FastAPI application instance.
        model_info: Model metadata and instance to configure.
    """
    jsl_model = cast(JslModel, model_info.model)

    app.state.is_blocking = False
    # Attaching spark session
    jsl_model.spark = get_spark_session(jsl_model)


def _configure_visual_model(
    app: FastAPI, model_info: ModelInfo, platform: Platform
) -> None:
    """Configure a visual model with content types and pipeline setup.

    Args:
        app: FastAPI application instance.
        model_info: Model metadata and instance to configure.
        platform: Target runtime platform selection.
    """
    _configure_jsl_for_app(app=app, model_info=model_info)

    logger.info("Configuring Content and MIME types for the app ...")
    from endpoints.johnsnowlabs.visual.models import VisualNlpModel

    visual_nlp_model = cast(VisualNlpModel, model_info.model)
    supported_mime_types = ["application/json"] + visual_nlp_model.supported_mime_types

    app.state.allowed_content_types = supported_mime_types
    app.state.allowed_mime_types = supported_mime_types

    _configure_visual_nlp_pipeline_for_platform(app, model_info, platform)


def _configure_chroma_resolver_model(
    app: FastAPI, model_info: ModelInfo, platform: Platform
) -> None:
    """Configure a healthcare model with pipelines and content types.

    Args:
        app: FastAPI application instance.
        model_info: Model metadata and instance to configure.
        platform: Target runtime platform selection.
    """

    _configure_healthcare_nlp_pipeline_for_platform(model_info, platform)

    # For Chroma, start spark session after downloading pipelines
    _configure_jsl_for_app(app=app, model_info=model_info)
    logger.info("Configuring Content and MIME types for the app ...")
    app.state.allowed_content_types = SUPPORTED_TEXT_CONTENT_TYPES
    app.state.allowed_mime_types = SUPPORTED_TEXT_CONTENT_TYPES

    model_info.model.predict({model_info.model._input._field: "Sample request"})


def _configure_healthcare_model(
    app: FastAPI, model_info: ModelInfo, platform: Platform
) -> None:
    """Configure a healthcare model with pipelines and content types.

    Args:
        app: FastAPI application instance.
        model_info: Model metadata and instance to configure.
        platform: Target runtime platform selection.
    """

    _configure_jsl_for_app(app=app, model_info=model_info)
    _configure_healthcare_nlp_pipeline_for_platform(model_info, platform)
    logger.info("Configuring Content and MIME types for the app ...")
    app.state.allowed_content_types = SUPPORTED_TEXT_CONTENT_TYPES
    app.state.allowed_mime_types = SUPPORTED_TEXT_CONTENT_TYPES

    model_info.model.predict({model_info.model._input._field: "Sample request"})


def configure_input_parser_strategies(app: FastAPI):
    """Register input parser strategies for text and visual payloads.

    Args:
        app: FastAPI application instance.
    """
    logger.info("Registering input parsers for the app ...")
    strategies = {"text": {}, "visual": {}}
    strategies["text"]["application/json"] = parse_json
    strategies["text"]["application/jsonlines"] = parse_jsonlines

    for content_type in SUPPORTED_VISUAL_CONTENT_TYPES:
        strategies["visual"][content_type] = parse_octet_stream

    # Overide for application/json
    strategies["visual"]["application/json"] = parse_json_with_file

    app.state.input_parser_strategies = strategies


MODEL_CONFIGURATORS = {
    "healthcare": _configure_healthcare_model,
    "visual": _configure_visual_model,
    "chroma_resolver": _configure_chroma_resolver_model,
}


def configure_app_for_model_and_platform(
    app: FastAPI, model_info: ModelInfo, platform: Platform
) -> None:
    """Configure app state and parsers for the selected model/platform.

    Args:
        app: FastAPI application instance.
        model_info: Model metadata and instance to configure.
        platform: Target runtime platform selection.
    """
    key = "healthcare"
    if is_visual_nlp_model(model_info.model):
        key = "visual"
    elif is_chroma_resolver_model(model_info.model):
        key = "chroma_resolver"

    MODEL_CONFIGURATORS[key](app, model_info, platform)
    configure_input_parser_strategies(app)
