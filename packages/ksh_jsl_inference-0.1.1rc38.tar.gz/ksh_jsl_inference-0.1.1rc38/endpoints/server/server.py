"""Server setup and application lifecycle utilities.

This module provides helpers to prepare runtime dependencies, initialize the
serving environment, build a FastAPI app, and run the model server.
"""

import os
from typing import List, Optional

import uvicorn
from fastapi import FastAPI
from uvicorn import config as uv_config

from endpoints import Platform
from endpoints.core import ModelInfo
from endpoints.core.models import BaseModel
from endpoints.logging import init_logging, logger
from endpoints.pip_utils import install
from endpoints.settings import config

from . import utils
from .app_config import configure_app_for_model_and_platform
from .routers import healthcheck


def get_requirements(
    platform: Platform,
    johnsnowlabs_version: Optional[str] = None,
    inference: Optional[BaseModel] = None,
) -> List[str]:
    """Build Python package requirements for a platform and optional model.

    Combines John Snow Labs, platform-specific, and model-specific dependencies.
    Any additional package that starts with ``johnsnowlabs`` is filtered out to
    avoid duplicate package entries.

    Args:
        platform: Target platform used to resolve platform-level dependencies.
        johnsnowlabs_version: Specific ``johnsnowlabs`` version to pin. If not
            provided, no explicit ``johnsnowlabs`` pin is added.
        inference: Inference model used to resolve model-level dependencies.

    Returns:
        list[str]: Requirement specifiers consumable by ``pip``.

    Todo:
        Add checks for requirements conflicts between packages.
    """
    requirements = []
    if johnsnowlabs_version:
        requirements = [f"johnsnowlabs=={johnsnowlabs_version}"]

    additional_packages = platform.get_python_requirements()
    if inference:
        additional_packages.extend(inference.get_python_requirements())
    additional_packages = [
        package
        for package in additional_packages
        if not package.startswith("johnsnowlabs")
    ]
    ##TODO: Add checks for requirements conflicts
    requirements.extend(additional_packages)

    return requirements


def install_python_requirements(
    platform: Platform,
    inference_model: BaseModel,
    johnsnowlabs_version: Optional[str] = None,
):
    """Install Python requirements for the selected platform and model.

    Installation is skipped when package download is disabled by settings.

    Args:
        platform: Target platform used to resolve platform-level dependencies.
        inference_model: Model used to resolve model-level dependencies.
        johnsnowlabs_version: Specific ``johnsnowlabs`` version to pin. If not
            provided, default dependency resolution is used.

    Returns:
        None

    """
    requirements = get_requirements(
        platform=platform,
        inference=inference_model,
        johnsnowlabs_version=johnsnowlabs_version,
    )
    install(requirements)


def create_app(
    model_info: Optional[ModelInfo] = None, platform: Optional[Platform] = None
) -> FastAPI:
    """Create a FastAPI application configured for model serving.

    If ``model`` or ``platform`` is not provided, values are inferred from
    environment variables. The app lifecycle performs a model warmup prediction
    on startup and disposes the model on shutdown.

    Args:
        model_info: Model metadata and loaded model instance to serve. If ``None``,
            the model is resolved from environment variables.
        platform: Serving platform used to determine which routers are included.
            If ``None``, defaults to the ``platform`` environment variable or
            ``local``.

    Returns:
        FastAPI: Configured application instance with platform-specific routes.
    """
    if not model_info:
        model_info = utils.find_model_to_serve()

    if not platform:
        platform = config.platform

    from contextlib import asynccontextmanager

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        app.state.model_info = model_info
        configure_app_for_model_and_platform(app, model_info, platform)

        yield

        if hasattr(app.state, "model_info"):

            app.state.model_info.model.dispose()

    app = FastAPI(lifespan=lifespan)
    init_logging()

    include_sagemaker_route = platform in {Platform.LOCAL, Platform.SAGEMAKER}

    include_snowflake_route = platform in {Platform.LOCAL, Platform.SNOWFLAKE}

    app.include_router(healthcheck.router)
    if include_sagemaker_route:
        from endpoints.sagemaker import router

        app.include_router(router)
    if include_snowflake_route:
        from endpoints.snowflake import router

        app.include_router(router)
    return app


def setup_env(
    model: ModelInfo,
    platform: Platform,
    johnsnowlabs_version: Optional[str] = None,
    store_model: bool = False,
):
    """Prepare runtime dependencies and optional model artifacts.

    Installs platform and model Python dependencies. Optionally downloads and
    stores model artifacts for local availability.

    Args:
        model: Model metadata and loaded model instance.
        platform: Target platform for dependency resolution.
        johnsnowlabs_version: Specific ``johnsnowlabs`` version to pin. If not
            provided, default dependency resolution is used.
        store_model: Whether to download and store model artifacts.

    Returns:
        None
    """
    install_python_requirements(platform, model.model, johnsnowlabs_version)
    if store_model:
        # Set environment variable , to instruct app to load model from disk
        os.environ["MODEL_FROM_DISK"] = str(store_model)
        utils.download_model(model_info=model)


def serve(
    model: ModelInfo,
    platform: Platform,
    port: int = 8080,
    **uvicorn_kwargs,
):
    """Starts the model server with uvicorn.

    Sets required environment variables so the uvicorn factory can resolve the
    model and platform context, then launches the ASGI server.

    Args:
        model: Model metadata to expose for inference.
        platform: Target platform identifier.
        port: Port to bind the HTTP server to.
        uvicorn_kwargs: Additional keyword arguments forwarded to ``uvicorn.run``.
            The ``workers`` value overrides ``config.workers`` when provided.
    """
    # Set env variable so that uvicorn workers can find it

    os.environ["MODEL_ID"] = model.model_id
    os.environ["LANGUAGE"] = model.language
    os.environ["PLATFORM"] = platform.value

    format = "%(levelname)s:[PID: %(process)d]:%(message)s"
    logger.info("Starting application ...")
    log_config = uv_config.LOGGING_CONFIG
    log_config["formatters"]["access"]["fmt"] = format

    workers = uvicorn_kwargs.pop("workers", None) or config.workers
    uvicorn.run(
        "endpoints.server:create_app",
        factory=True,
        host="0.0.0.0",
        loop="uvloop",  # Make sure uvloop is used
        workers=workers,
        port=port,
        log_config=log_config,
        **uvicorn_kwargs,
    )
