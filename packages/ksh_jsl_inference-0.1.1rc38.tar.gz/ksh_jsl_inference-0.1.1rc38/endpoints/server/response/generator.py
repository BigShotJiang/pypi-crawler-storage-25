import json
import uuid
from typing import Any, Dict

from fastapi import Depends, Response
from fastapi.responses import JSONResponse

from endpoints.core.models.base import BaseModel
from endpoints.johnsnowlabs import is_visual_nlp_model
from endpoints.logging import logger

from ..dependencies import get_mime_type, get_serving_model


class SnowflakeResponseGenerator:
    """Generate Snowflake-compatible JSON responses.

    Args:
        model: Serving model used to resolve the output field.
    """

    def __init__(self, model: BaseModel = Depends(get_serving_model)) -> None:
        """Initialize the generator.

        Args:
            model: Serving model used to resolve the output field.
        """
        self._model = model

    def __call__(self, predictions) -> Response:
        """Return predictions formatted for Snowflake external functions.

        Args:
            predictions: Prediction payload with the model output field.

        Returns:
            Response: FastAPI JSON response with Snowflake "data" format.

        Examples:
            Example output payload:
                {
                    "data": [[0, ["value-1"]], [1, ["value-2"]]]
                }
        """
        result = predictions[self._model._output._field]
        results = result if isinstance(result, list) else [result]
        return JSONResponse(
            content={
                "data": [
                    [idx, prediction] for idx, prediction in enumerate(zip(results))
                ]
            }
        )


class JsonOutputGenerator:
    """Generate a JSON response from predictions.

    Examples:
        Example output payload:
            {
                "result": ["value-1", "value-2"]
            }
    """

    def __call__(self, predictions) -> Response:
        """Return predictions as a JSON response.

        Args:
            predictions: Prediction payload to serialize as JSON.

        Returns:
            Response: FastAPI JSON response with the predictions content.

        Examples:
            Example output payload:
                {
                    "result": ["value-1", "value-2"]
                }
        """
        return JSONResponse(content=predictions)


class JsonLinesOutputGenerator:
    """Generate a JSON Lines response from predictions.

    Examples:
        Example output payload:
            {"prediction": "value-1"}
            {"prediction": "value-2"}
    """

    def __init__(self, model: BaseModel = Depends(get_serving_model)):
        """Initialize the generator.

        Args:
            model: Serving model used to resolve the output field.
        """
        self._model = model

    def __call__(self, predictions: Dict) -> Response:
        """Return predictions as a JSON Lines response.

        Args:
            predictions: Prediction payload with the model output field.

        Returns:
            Response: FastAPI response containing JSON Lines content.

        Examples:
            Example output payload:
                {"prediction": "value-1"}
                {"prediction": "value-2"}
        """
        return Response(
            content="\n".join(
                [
                    json.dumps({self._model._output._field: pred})
                    for pred in predictions[self._model._output._field]
                ]
            ),
            media_type="application/jsonlines",
        )


class FileToJsonOutputGenerator:
    """Write binary output to a file and return a JSON message.

    Examples:
        Example output payload:
            {
                "message": "Output file created at /tmp/3a2b1c4d"
            }
    """

    def __init__(self, model: BaseModel = Depends(get_serving_model)):
        """Initialize the generator.

        Args:
            model: Serving model used to resolve the output field.
        """
        self.model = model

    def __call__(self, predictions: Dict) -> Response:
        """Write the output bytes to a temp file and return its path.

        Args:
            predictions: Prediction payload with the model output field.

        Returns:
            Response: JSON response containing the output file path message.

        Examples:
            Example output payload:
                {
                    "message": "Output file created at /tmp/3a2b1c4d"
                }
        """
        output = predictions[self.model._output._field]
        if isinstance(output, bytes):
            file_name = f"/tmp/{uuid.uuid4()}"
            with open(file_name, "wb") as f:
                f.write(output)

            return JSONResponse(
                content={"message": f"Output file created at {file_name}"}
            )
        else:
            logger.debug("Falling back to JsonOutput Generator ...")
            return JsonOutputGenerator()(predictions=predictions)


class FileOutputGenerator:
    """Return raw file content with the requested MIME type.

    Examples:
        Example output payload:
            <binary payload returned with the selected MIME type>
    """

    def __init__(
        self,
        model: BaseModel = Depends(get_serving_model),
        mime_type: str = Depends(get_mime_type),
    ):
        """Initialize the generator.

        Args:
            model: Serving model used to resolve the output field.
            mime_type: MIME type to set on the response.
        """
        self.model = model
        self.mime_type = mime_type

    def __call__(self, predictions: Dict) -> Any:
        """Return raw bytes response for the model output.

        Args:
            predictions: Prediction payload with the model output field.

        Returns:
            Any: FastAPI response containing raw output bytes.

        Examples:
            Example output payload:
                <binary payload returned with the selected MIME type>
        """
        output = predictions[self.model._output._field]
        return Response(content=output, media_type=self.mime_type)


def get_default_response_generator(
    model=Depends(get_serving_model), mime_type=Depends(get_mime_type)
):
    """Select the default response generator based on model and MIME type.

    Args:
        model: Serving model used to determine output handling.
        mime_type: Requested response MIME type.

    Returns:
        Any: A response generator instance for the given model and MIME type.

    Examples:
        Example output payload (application/json):
            {
                "result": ["value-1", "value-2"]
            }
        Example output payload (application/jsonlines):
            {"prediction": "value-1"}
            {"prediction": "value-2"}
        Example output payload (binary MIME types):
            <binary payload returned with the selected MIME type>
    """

    if is_visual_nlp_model(model):
        if mime_type == "application/json":
            return FileToJsonOutputGenerator(model=model)
        else:
            return FileOutputGenerator(model=model, mime_type=mime_type)

    else:
        if mime_type == "application/json":
            return JsonOutputGenerator()
        elif mime_type == "application/jsonlines":
            return JsonLinesOutputGenerator(model=model)


def get_snowflake_response_generator(model=Depends(get_serving_model)):
    """Return the Snowflake response generator for the serving model.

    Args:
        model: Serving model used to generate predictions .

    Returns:
        SnowflakeResponseGenerator: Response generator for Snowflake requests.
    """

    return SnowflakeResponseGenerator(model)
