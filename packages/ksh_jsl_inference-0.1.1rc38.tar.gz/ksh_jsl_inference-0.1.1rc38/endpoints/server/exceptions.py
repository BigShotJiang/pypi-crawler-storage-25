class ModelServingException(Exception):
    pass
