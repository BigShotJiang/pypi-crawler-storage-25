import base64
import json
from typing import Dict, List, Optional

from fastapi import Request


async def parse_octet_stream(
    request: Request,
    input_data: Optional[bytes] = None,
    content_type: Optional[str] = None,
    **kwargs,
):
    """Parse a raw octet-stream request body into the standard file payload.

    Expects the request body to be raw bytes and a resolved content type.
    Returns a dict with in-memory file data and the provided content type.

    Example input
    Body: b"%PDF-1.4..."
    Content-Type: application/pdf
    """
    return {
        "file": {"data": input_data or await request.body()},
        "content_type": content_type,
    }


async def parse_file_url(request: Request, input_data: Optional[Dict] = None, **kwargs):
    """Parse JSON containing a file URL into the standard file payload.

    Example input
    {"url": "https://example.com/file.pdf", "content_type": "application/pdf"}
    """
    data = input_data or await request.json()
    path = data["url"]
    return {"file": {"url": path}, "content_type": data.get("content_type")}


async def parse_base64encoded_data_url(
    request: Request, input_data: Optional[Dict] = None, **kwargs
):
    """
    Parse JSON containing a base64 data URL into the standard file payload.

    Example input
    {"data": "data:application/pdf;base64,SGVsbG8gV29ybGQh", "content_type": "application/pdf"}
    """

    data = input_data or await request.json()
    data_url = data["data"]

    header, encoded = data_url.split(",", 1)
    header_value = header[5:] if header.startswith("data:") else header
    content_type = header_value.split(";", 1)[0]

    data_bytes = base64.b64decode(encoded)
    return {"file": {"data": data_bytes}, "content_type": content_type}


async def parse_json_with_file(
    request: Request, input_data: Optional[Dict] = None, **kwargs
):
    """Parse JSON that includes either a file URL or base64 data URL.

    Delegates to parse_file_url when a "path" field is present, or to
    parse_base64encoded_data_url when a "data" field is present.

    Example input (URL)
    {"url": "https://example.com/file.pdf", "content_type": "application/pdf"}

    Example input (data URL)
    {"data": "data:application/pdf;base64,SGVsbG8gV29ybGQh"}
    """
    data = input_data or await request.json()
    if "url" in data:
        return await parse_file_url(request, input_data=data, **kwargs)
    elif "data" in data:
        return await parse_base64encoded_data_url(request, input_data=data, **kwargs)
    raise Exception("No file in sent json")


async def parse_json(request: Request, input_data: Optional[Dict] = None, **kwargs):
    """Parse and return the request JSON body as a Python object.

    Example input
    {"records": [{"id": 1, "text": "hello"}]}
    """
    return input_data or await request.json()


async def parse_jsonlines(
    request: Request, input_data: Optional[bytes] = None, **kwargs
):
    """Parse a JSON Lines request body into a list of JSON objects.

    Example input
    {"id": 1, "text": "hello"}\n{"id": 2, "text": "world"}
    """
    body = input_data or await request.body()
    lines = body.decode("utf-8").strip().split("\n")
    return [json.loads(line) for line in lines]


async def parse_snowflake_input(
    request: Request, input_data: Optional[Dict] = {}
) -> List[Dict]:
    """Parse Snowflake request payload for external functions.

    Args:
        request: Incoming HTTP request.
        input_data: Optional input payload for tests or overrides.

    Returns:
        A list of dicts formatted for model input.

    Example:
        Input payload:
            {"data": [[0, "hello", 0.9], [1, "world", 0.1]]}
    """
    data = input_data or await request.json()
    data_json_array = data["data"]
    model = request.app.state.model_info.model

    standard_input = []
    for row_array in data_json_array:
        obj = {model._input._field: row_array[1]}

        for idx in range(len(row_array[2:])):
            obj[model._input_params.schemas[idx]._field] = row_array[idx + 2]
        standard_input.append(obj)
    return standard_input
