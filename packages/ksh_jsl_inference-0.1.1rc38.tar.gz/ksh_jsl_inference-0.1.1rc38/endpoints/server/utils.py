from typing import Optional, cast

from endpoints import ModelType
from endpoints.core import ModelInfo, ModelRegistry, download_local_model
from endpoints.core.exceptions import ModelRegistryException
from endpoints.johnsnowlabs import (
    JslModel,
    is_chroma_resolver_model,
    is_healthcare_nlp_model,
    is_visual_nlp_model,
)
from endpoints.johnsnowlabs.spark_session import get_spark_session
from endpoints.server.exceptions import ModelServingException


def download_model(model_info: ModelInfo) -> str:
    """Download a model based on its type and family.

    Args:
        model_info: Model metadata used to resolve the download path.

    Returns:
        str: The downloaded model or local model reference.
    """

    if model_info.model_type == ModelType.LOCAL:
        return download_local_model(model_info)

    ## Make sure spark session exists before downloading JSL
    jsl_model = cast(JslModel, model_info.model)
    if is_chroma_resolver_model(model_info.model):
        # Not starting spark sesion from Chroma db, as it resets the
        # AWS Keys for vector db downloads
        return download_chroma_resolver_model(model_info)
    if is_healthcare_nlp_model(model_info.model):
        get_spark_session(jsl_model)
        return download_healthcare_nlp_model(model_info)
    if is_visual_nlp_model(model_info.model):
        get_spark_session(jsl_model)
        return download_visual_nlp_model(model_info)
    raise NotImplemented(f"Downloader not implement for {model_info.model_type}")


def download_chroma_resolver_model(model_info: ModelInfo):
    """Download and persist a Chroma resolver model.

    Args:
        model_info: Model metadata used to initialize the loader.

    Returns:
        The downloaded model or local model reference.
    """
    from endpoints.johnsnowlabs.healthcare.loader.chroma_loader import (
        ChromaResolverModelLoader,
    )

    loader = ChromaResolverModelLoader(model_info)
    return loader.save_to_disk()


def download_healthcare_nlp_model(model_info: ModelInfo):
    """Download and persist a Healthcare NLP model.

    Args:
        model_info: Model metadata used to initialize the loader.

    Returns:
        The downloaded model or local model reference.
    """
    from endpoints.johnsnowlabs.healthcare.loader import HealthcareModelLoader

    loader = HealthcareModelLoader(model_info)
    return loader.save_to_disk()


def download_visual_nlp_model(model_info: ModelInfo):
    """Download and persist a Visual NLP model.

    Args:
        model_info: Model metadata used to initialize the loader.

    Returns:
        None. The model is saved to disk by the loader.
    """

    from endpoints.johnsnowlabs.visual.loader import VisualNlpModelLoader

    loader = VisualNlpModelLoader(model_info)
    return loader.save_to_disk()


def find_model_to_serve(
    model_id: Optional[str] = None, language: Optional[str] = None
) -> ModelInfo:
    """Find the model to serve from registry or environment.

    Args:
        model_id: Optional model identifier to look up in the registry.
        language: Optional language code to filter the registry lookup.

    Returns:
        The selected model metadata to serve.

    Raises:
        ModelServingException: If no model can be found in the registry or
            environment.
    """
    try:
        return ModelRegistry.find(
            model_id=model_id or "Unknown", language=language or "Unknown"
        )
    except ModelRegistryException:
        model = ModelRegistry.find_from_env()
        if not model:
            raise ModelServingException(
                "Model not found to serve. Make sure to set the environment variable"
            )
        return model
