import os
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

from johnsnowlabs import settings
from johnsnowlabs.nlp import install as jsl_install
from johnsnowlabs.py_models.install_info import (
    RootInfo,
)
from johnsnowlabs.py_models.jsl_secrets import JslSecrets

from endpoints.logging import logger


def download_jars_dependency_for_jsl(
    secrets: Optional[JslSecrets] = None, nlp: bool = True, visual: bool = False
) -> None:
    """Download required Spark NLP JAR dependencies into the local Java directory.

    Downloads the public Spark NLP assembly JAR and, when valid secrets are provided,
    also downloads the private Spark NLP JSL JAR. Existing files are reused when their
    sizes match the corresponding object size in S3.

    Args:
        secrets: Optional JSL secrets used to build the authenticated JSL JAR path.
        nlp: Flag to download Healthcare NLP Jar
        visual: Flag to download Visual NLP Jar
    """
    import boto3
    from botocore import UNSIGNED
    from botocore.config import Config

    # Create boto3 client without credentials as the s3 buckets are public
    s3_client = boto3.client("s3", config=Config(signature_version=UNSIGNED))
    Path(settings.java_dir).mkdir(parents=True, exist_ok=True)

    jars_to_download: list[str] = [
        # Spark NLP Fat Jar
        f"s3://auxdata.johnsnowlabs.com/public/jars/spark-nlp-assembly-{settings.raw_version_nlp}.jar"
    ]

    if secrets:
        if nlp:
            jars_to_download.append(
                # Spark NLP JSL Far
                f"s3://pypi.johnsnowlabs.com/{secrets.HC_SECRET}/spark-nlp-jsl-{settings.raw_version_medical}.jar"
            )
        if visual:
            jars_to_download.append(
                # Spark OCR Far
                f"s3://pypi.johnsnowlabs.com/{secrets.OCR_SECRET}/jars/spark-ocr-assembly-{settings.raw_version_secret_ocr}.jar"
            )

    def download_jars_from_s3_bucket(s3_url: str) -> None:
        """Download one JAR from an S3 URL if needed.

        Args:
            s3_url: Full S3 URL in the format ``s3://bucket/key``.
        """
        parsed = urlparse(s3_url)
        s3_bucket = parsed.netloc
        s3_prefix = parsed.path.lstrip("/")
        jar_name = os.path.basename(s3_prefix)
        local_path = os.path.join(str(settings.java_dir), jar_name)

        try:
            s3_metadata = s3_client.head_object(Bucket=s3_bucket, Key=s3_prefix)
            s3_size = s3_metadata.get("ContentLength")
        except Exception:
            logger.error(f"Could not read metadata for {jar_name}")
            return

        if os.path.exists(local_path):
            local_size = os.path.getsize(local_path)
            if s3_size is not None and local_size == s3_size:
                logger.debug(f"Skipping {jar_name}; Local file Already exists")
                return
            logger.info(f"Re-downloading {jar_name} ...")
        else:
            logger.info(f"Downloading {jar_name} ...")

        try:
            s3_client.download_file(s3_bucket, s3_prefix, local_path)
            logger.info(f"Successfully downloaded {jar_name} ...")
        except Exception:
            logger.error(f"Error downloading {jar_name}")

    with ThreadPoolExecutor(max_workers=2) as executor:
        executor.map(download_jars_from_s3_bucket, jars_to_download)


def install(
    json_license_path: Optional[str] = None,
    nlp: bool = True,
    visual: bool = False,
    **jsl_install_kwargs,
) -> None:
    """Install John Snow Labs resources and dependencies.

    Faster implementation of ``johnsnowlabs nlp.install``. Improvements made to
    the slow downloads of jars by switching to S3 instead of https. Adds
    additional checks to ensure jars are properly downloaded. Skips downloads
    if jars size match object size on s3. For installation other dependenciess,
    delegates steps to ``johnsnowlabs nlp.install``.

    If any step in this flow raises an exception, installation falls back to
    ``nlp.install(refresh_install=True)``.

    Args:
        json_license_path: Optional path to a JSL license JSON file.
        nlp: Flag to download Healthcare NLP
        visual: Flat to download Visual NLP
    """
    force_browser = jsl_install_kwargs.pop("force_browser", False)
    browser_login = jsl_install_kwargs.pop("browser_login", False)

    try:
        logger.info("Installing John Snow Labs ...")

        Path(settings.root_dir).mkdir(parents=True, exist_ok=True)
        root_info = RootInfo(
            version=settings.raw_version_jsl_lib, run_from=sys.executable
        )
        root_info.version = root_info.version.as_str()
        root_info.write(settings.root_info_file)

        secrets = None
        try:
            if json_license_path:
                secrets = JslSecrets.from_json_file_path(json_license_path)
                secrets = JslSecrets.enforce_versions(secrets)
        except:
            secrets = None

        # Download jars
        download_jars_dependency_for_jsl(secrets=secrets, nlp=nlp, visual=visual)

        # Rely on nlp.install() for rest of the installation
        jsl_install(
            nlp=nlp,
            visual=visual,
            json_license_path=json_license_path,
            force_browser=force_browser,
            browser_login=browser_login,
            **jsl_install_kwargs,
        )

    except Exception as e:
        logger.info(
            "Fallback to using nlp.install(refresh_install=True) for installation ..."
        )
        jsl_install(
            json_license_path=json_license_path,
            nlp=nlp,
            visual=visual,
            force_browser=force_browser,
            browser_login=browser_login,
            refresh_install=True,
            **jsl_install_kwargs,
        )
