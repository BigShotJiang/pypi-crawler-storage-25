from typing import TYPE_CHECKING, Any, List, Optional, Union

try:
    from pyspark.sql import SparkSession
except Exception:  # pragma: no cover - optional dependency
    SparkSession = Any  # type: ignore[assignment]

try:
    from sparknlp.pretrained import PretrainedPipeline
except Exception:  # pragma: no cover - optional dependency
    PretrainedPipeline = Any  # type: ignore[assignment]

from typing_extensions import override

from endpoints.core.models.base import BaseModel
from endpoints.core.models.schema import Schema, SchemaCollection

if TYPE_CHECKING:
    from sparkocr.pretrained import PretrainedPipeline as OcrPretrained


class JslModel(BaseModel):
    def __init__(self, input: Schema, input_params: SchemaCollection, output: Schema):
        """Initialize the JSL model wrapper.

        Args:
            input: Input schema for the model.
            input_params: Schema collection describing input parameters.
            output: Output schema for the model.
        """
        super().__init__(input=input, input_params=input_params, output=output)
        self._spark: Optional[SparkSession] = None
        self._pipeline: Optional[Union[PretrainedPipeline, "OcrPretrained"]] = None

    @property
    def spark(self) -> SparkSession:
        """Return the active Spark session.

        Raises:
            Exception: If the Spark session has not been initialized.
        """
        if self._spark is None:
            raise Exception("Spark not initiated")
        return self._spark

    @spark.setter
    def spark(self, value):
        """Set the Spark session.

        Args:
            value: Spark session instance to store.
        """
        self._spark = value

    @property
    def pipeline(self) -> Union[PretrainedPipeline, "OcrPretrained"]:
        """Return the active NLP/OCR pipeline.

        Raises:
            ValueError: If the pipeline has not been initialized.
        """
        if self._pipeline is None:
            raise ValueError("Pipeline not initiazed")
        return self._pipeline

    @pipeline.setter
    def pipeline(self, value):
        """Set the NLP/OCR pipeline.

        Args:
            value: Pipeline instance to store.
        """
        self._pipeline = value

    @override
    def concrete_predict(self, input_data):
        """Run inference with the configured pipeline.

        Args:
            input_data: Validated inputs and params.
        """
        raise NotImplementedError("JslModel requires a configured pipeline")

    @override
    def get_python_requirements(self) -> List[str]:
        """Return required Python package specifications.

        Returns:
            A list of requirement strings.
        """
        return ["johnsnowlabs>=6.2.0"]

    @override
    def dispose(self):
        """Dispose model resources by closing the Spark session."""
        if self.spark:
            self.spark.sparkContext.stop()
