from endpoints import ModelType
from endpoints.core.model_info import ModelInfo

from .models import (
    ChromaDbResolverModel,
    DeidentificationModel,
    ExplainDocClinicalGranular,
    ExtractClinicalDocSODHSmall,
    ExtractSDOH,
    MedNlpModel,
    MhExtractEntities,
)

## Use this as a Flyweight to load generic Healthcare Models
BASE_MEDICAL_NLP_INFERENCE = MedNlpModel()
BASE_CHROMA_DB_NLP_INFERENCE = ChromaDbResolverModel()


HEALTHCARE_MODELS = [
    ####################################################################
    ####################  Clinical Deidentification ####################
    ####################################################################
    ModelInfo(
        model_id="clinical_deidentification_docwise_wip",
        language="en",
        model=DeidentificationModel("en"),
    ),
    ModelInfo(
        model_id="clinical_deidentification_docwise_wip",
        language="de",
        model=DeidentificationModel("de"),
    ),
    ModelInfo(
        model_id="clinical_deidentification",
        language="it",
        model=DeidentificationModel("it"),
    ),
    ModelInfo(
        model_id="clinical_deidentification",
        language="ar",
        model=DeidentificationModel("ar"),
    ),
    ModelInfo(
        model_id="clinical_deidentification",
        language="es",
        model=DeidentificationModel("es"),
    ),
    ModelInfo(
        model_id="clinical_deidentification",
        language="fr",
        model=DeidentificationModel("fr"),
    ),
    ModelInfo(
        model_id="clinical_deidentification",
        language="pt",
        model=DeidentificationModel("pt"),
    ),
    ModelInfo(
        model_id="clinical_deidentification",
        language="ro",
        model=DeidentificationModel("ro"),
    ),
    ModelInfo(
        model_id="explain_clinical_doc_mental_health",
        language="en",
        model=MhExtractEntities(),
    ),
    ModelInfo(
        model_id="ner_sdoh_langtest_pipeline",
        language="en",
        model=ExtractSDOH(),
    ),
    ModelInfo(
        model_id="explain_clinical_doc_sdoh_small",
        language="en",
        model=ExtractClinicalDocSODHSmall(),
    ),
    ModelInfo(
        model_id="explain_clinical_doc_granular",
        language="en",
        model=ExplainDocClinicalGranular(),
    ),
    ####################################################################
    ####################  Chroma DB Resolvers ####################
    ####################################################################
    ModelInfo(
        model_id="rxnorm",
        language="en",
        model=BASE_CHROMA_DB_NLP_INFERENCE,
        model_type=ModelType.CHROMADB_RESOLVER,
    ),
    ModelInfo(
        model_id="icd10cm",
        language="en",
        model=BASE_CHROMA_DB_NLP_INFERENCE,
        model_type=ModelType.CHROMADB_RESOLVER,
    ),
    ModelInfo(
        model_id="snomed",
        language="en",
        model=BASE_CHROMA_DB_NLP_INFERENCE,
        model_type=ModelType.CHROMADB_RESOLVER,
    ),
    ModelInfo(
        model_id="loinc",
        language="en",
        model=BASE_CHROMA_DB_NLP_INFERENCE,
        model_type=ModelType.CHROMADB_RESOLVER,
    ),
]
