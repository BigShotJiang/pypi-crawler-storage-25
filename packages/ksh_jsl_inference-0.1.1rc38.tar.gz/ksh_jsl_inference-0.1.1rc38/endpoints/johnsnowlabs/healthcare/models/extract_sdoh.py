from typing import Dict, List

from pyspark.sql.dataframe import DataFrame
from pyspark.sql.functions import expr
from typing_extensions import override

from endpoints.core.models.schema import Schema

from .med_nlp import MedNlpModel


class ExtractSDOH(MedNlpModel):
    """
    Identify socio-environmental health determinants
    """

    def __init__(self):
        super().__init__()
        self._output = Schema(field="predictions", typing=List)

    @override
    def process_pretrained_pipeline_results(
        self, inputs: List[str], results: DataFrame, params: Dict
    ) -> List:
        """Convert Spark pipeline results prediction results

        Overrides base class implementation.

        Args:
            inputs: Input texts corresponding to each pipeline result.
            results: Spark DataFrame containing de-identification annotations.
            params: Per-input parameters

        Returns:
            List[str]: List of prediction dict
        """
        df = results.select(
            expr("ner_chunk.result").alias("ner_chunk"),
            expr("ner_chunk.begin").alias("begin"),
            expr("ner_chunk.end").alias("end"),
            expr("transform(ner_chunk.metadata, x -> x['entity'])").alias("ner_label"),
            expr("transform(ner_chunk.metadata, x -> x['confidence'])").alias(
                "ner_confidence"
            ),
        )

        pdf = df.toPandas()

        output = pdf.apply(
            lambda row: [
                dict(
                    ner_chunk=row["ner_chunk"][i],
                    begin=row["begin"][i],
                    end=row["end"][i],
                    ner_label=row["ner_label"][i],
                    ner_confidence=row["ner_confidence"][i],
                )
                for i in range(len(row["ner_chunk"]))
            ],
            axis=1,
        ).tolist()

        return output

    @override
    def process_light_pipeline_results(
        self, inputs: List[str], results: List, params: Dict
    ) -> List:
        """Convert light pipeline results into prediction results

        Overrides base class implementation.

        Args:
            inputs: Input texts corresponding to each pipeline result.
            results: Light pipeline outputs for each input.
            params: Per-input parameters

        Returns:
            List[str]: List of prediction dict
        """
        data = list()
        for prediction in results:
            temp = list()
            for ner_chunk in prediction.get("ner_chunk", []):
                temp.append(
                    {
                        "begin": ner_chunk.begin,
                        "end": ner_chunk.end,
                        "ner_chunk": ner_chunk.result,
                        "ner_label": ner_chunk.metadata["entity"],
                        "ner_confidence": ner_chunk.metadata["confidence"],
                    }
                )
            data.append(temp)
        return data
