from .entity_extraction import EntityExtractionBaseClass


class MhExtractEntities(EntityExtractionBaseClass):
    """Identify mental-health entities,assign assertion status"""

    ner_annotation_field = "merged_ner_chunk"
    relations_annotation_field = "relations"
