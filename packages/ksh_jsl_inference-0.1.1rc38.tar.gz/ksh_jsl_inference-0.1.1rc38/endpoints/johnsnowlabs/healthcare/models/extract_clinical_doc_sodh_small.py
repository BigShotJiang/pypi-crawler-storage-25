from .entity_extraction import EntityExtractionBaseClass


class ExtractClinicalDocSODHSmall(EntityExtractionBaseClass):
    """
    Identify socio-environmental health determinants
    """

    ner_annotation_field = "sdoh_chunk"
    relations_annotation_field = "relations"
