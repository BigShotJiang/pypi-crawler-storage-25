from .entity_extraction import EntityExtractionBaseClass


class ExplainDocClinicalGranular(EntityExtractionBaseClass):
    """
    Transform clinical text into structured data with NLP
    """

    ner_annotation_field = "jsl_ner_chunk"
    relations_annotation_field = "all_relations"
