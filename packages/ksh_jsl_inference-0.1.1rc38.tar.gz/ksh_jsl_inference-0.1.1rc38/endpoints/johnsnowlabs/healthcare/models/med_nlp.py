import json
from typing import Dict, List, cast

from pyspark.sql.dataframe import DataFrame
from sparknlp.pretrained import PretrainedPipeline
from typing_extensions import override

from endpoints.core.models.schema import Schema, SchemaCollection
from endpoints.logging import logger

from ...encoder import JslEncoder
from ...jsl_model import JslModel


class MedNlpModel(JslModel):
    """Base class for Medical NLP models."""

    def __init__(self):
        """Initialize the Medical NLP model base."""
        super().__init__(
            input=Schema(field="text", typing=str, required=True),
            input_params=SchemaCollection([]),
            output=Schema(field="predictions", typing=Dict, required=True),
        )

    def _prepare_data(self, texts: List[str]) -> DataFrame:
        """Prepare a Spark DataFrame for inference.

        Args:
            texts (List[str]): Input texts to index and convert.

        Returns:
            DataFrame: Repartitioned DataFrame with indexed texts.
        """
        logger.debug("Preparing the Spark DataFrame")
        indexed_text = [(i, t) for i, t in enumerate(texts)]
        df = self.spark.createDataFrame(indexed_text, ["index", "text"])
        return df.repartition(1000)

    def process_light_pipeline_results(
        self, inputs: List[str], results: List, params: Dict
    ) -> List:
        """Process results from the light pipeline.

        Subclasses should override this method to customize the output.

        Args:
            inputs (List[str]): Input texts.
            results (List): Results from the light pipeline.
            params (Dict): Additional input params.

        Returns:
            List: Processed results.
        """
        data = json.dumps(results, cls=JslEncoder)
        return json.loads(data)

    def process_pretrained_pipeline_results(
        self, inputs: List[str], results: DataFrame, params: Dict
    ) -> List:
        """Process results from the pretrained pipeline.

        Subclasses should override this method to customize the output.

        Args:
            inputs (List[str]): Input texts.
            results (DataFrame): Results from the pretrained pipeline.
            params (Dict): Additional input params.

        Returns:
            List: Processed results.
        """
        json_result = results.toJSON().collect()
        return list(map(json.loads, json_result))

    def _get_predictions_from_light_pipeline(
        self, texts: List[str], params: Dict
    ) -> List:
        """Run inference using the light pipeline.

        Args:
            texts (List[str]): Input texts.
            params (Dict): Additional input params.

        Returns:
            List: Model predictions.
        """
        logger.debug(f"Processing {len(texts)} texts with Light Pipeline")
        # typecast
        pipeline = cast(PretrainedPipeline, self.pipeline)

        results = pipeline.fullAnnotate(texts)
        return self.process_light_pipeline_results(texts, results, params)

    def _get_predictions_from_pretrained_pipeline(
        self, texts: List[str], params: Dict
    ) -> List:
        """Run inference using the pretrained pipeline.

        Args:
            texts (List[str]): Input texts.
            params (Dict): Additional input params.

        Returns:
            List: Model predictions.
        """
        logger.debug(f"Processing {len(texts)} texts with Pretrained Pipeline")
        input_df = self._prepare_data(texts)
        predictions_df = self.pipeline.transform(input_df)
        sorted_df = predictions_df.orderBy("index")
        logger.debug("Transformation complete, extracting results")
        return self.process_pretrained_pipeline_results(texts, sorted_df, params)

    @override
    def concrete_predict(self, input_data: Dict) -> Dict:
        """Perform model prediction using the appropriate pipeline.

        Args:
            input_data (Dict): Input data to be predicted by the model.

        Returns:
            Dict: The output of the prediction.
        """

        inputs = input_data["inputs"]
        params = input_data["params"]

        if isinstance(inputs, list) and len(inputs) >= 20:
            predictions = self._get_predictions_from_pretrained_pipeline(inputs, params)
        else:
            predictions = self._get_predictions_from_light_pipeline(inputs, params)

        return {self._output._field: predictions}

    @override
    def dispose(self):
        """Dispose model resources by closing the Spark session."""
        self.spark.sparkContext.stop()
