from typing import Dict

from sparknlp.pretrained import PretrainedPipeline
from typing_extensions import override

from endpoints.logging import logger
from endpoints.settings import MODEL_LOCATION

from ...model_loader import JslModelLoader


class HealthcareModelLoader(JslModelLoader):
    @override
    def load_from_disk(self, path: str = MODEL_LOCATION) -> Dict:
        """Load the Healthcare NLP Pretrained pipeline from disk.

        Args:
            path: Filesystem path to the pipeline artifacts. Defaults to the
                configured model location.

        Returns:
            Dict: Mapping with a "pipeline" key containing the loaded
                PretrainedPipeline instance.
        """
        logger.info(f"Loading model artifacts from  {path}...")
        return {"pipeline": PretrainedPipeline.from_disk(path)}

    @override
    def load_from_hub(self) -> Dict:
        """Load the Healthcare NLP Pretrained pipeline from models hub.

        Returns:
            Dict: Mapping with a "pipeline" key containing the loaded
                PretrainedPipeline instance.
        """
        logger.info(
            f"Downloading Medical NLP Model '{self._model_info.model_id}' from models hubs..."
        )

        return {
            "pipeline": PretrainedPipeline(
                self._model_info.model_id, self._model_info.language, "clinical/models"
            )
        }

    @override
    def save_to_disk(self, output_dir: str = MODEL_LOCATION) -> str:
        super().save_to_disk(output_dir=output_dir)
        try:
            pretrained_pipeline = self.load_from_hub()["pipeline"]
            pretrained_pipeline.model.write().overwrite().save(output_dir)
            return output_dir
        except Exception as e:
            raise RuntimeError(
                f"Failed to download and save the Healthcare NLP model: {e}"
            )
