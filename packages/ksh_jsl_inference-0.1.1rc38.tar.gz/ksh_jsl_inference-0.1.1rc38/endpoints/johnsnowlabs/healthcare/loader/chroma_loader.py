import os
import shutil

import torch
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma
from sparknlp.annotation import *  # noqa: F401
from sparknlp.base import *  # noqa: F401
from sparknlp.pretrained import PretrainedPipeline
from typing_extensions import override

from endpoints.logging import logger
from endpoints.settings import MODEL_LOCATION
from endpoints.utils import ProgressPercentage

from ...model_loader import JslModelLoader

vdb_ner_models = {
    "icd10cm": {
        "ner_clinical": ["PROBLEM"],
        "ner_jsl": [
            "CEREBROVASCULAR_DISEASE",
            "COMMUNICABLE_DISEASE",
            "DIABETES",
            "DISEASE_SYNDROME_DISORDER",
            "EKG_FINDINGS",
            "HEART_DISEASE",
            "HYPERLIPIDEMIA",
            "HYPERTENSION",
            "IMAGINGFINDINGS",
            "INJURY_OR_POISONING",
            "KIDNEY_DISEASE",
            "OBESITY",
            "ONCOLOGICAL",
            "OVERWEIGHT",
            "PREGNANCY",
            "PSYCHOLOGICAL_CONDITION",
            "SYMPTOM",
            "VS_FINDING",
        ],
    },
    "mesh": {"ner_clinical": []},
    "atc": {"ner_posology": ["DRUG"]},
    "cpt": {
        "ner_jsl": ["PROCEDURE"],
        "ner_measurements_clinical": ["MEASUREMENTS"],
    },
    "hcc": {
        "ner_clinical": ["PROBLEM"],
        "ner_jsl": [
            "CEREBROVASCULAR_DISEASE",
            "COMMUNICABLE_DISEASE",
            "DIABETES",
            "DISEASE_SYNDROME_DISORDER",
            "EKG_FINDINGS",
            "HEART_DISEASE",
            "HYPERLIPIDEMIA",
            "HYPERTENSION",
            "IMAGINGFINDINGS",
            "INJURY_OR_POISONING",
            "KIDNEY_DISEASE",
            "OBESITY",
            "ONCOLOGICAL",
            "OVERWEIGHT",
            "PREGNANCY",
            "PSYCHOLOGICAL_CONDITION",
            "SYMPTOM",
            "VS_FINDING",
        ],
    },
    "ndc": {"ner_posology_greedy": ["DRUG"]},
    "ncit": {
        "ner_oncology": [
            "ADENOPATHY",
            "BIOMARKER",
            "BIOMARKER_RESULT",
            "CANCER_DX",
            "CANCER_SCORE",
            "CANCER_SURGERY",
            "CHEMOTHERAPY",
            "CYCLE_COUNT",
            "CYCLE_DAY",
            "CYCLE_NUMBER",
            "DIRECTION",
            "DURATION",
            "FREQUENCY",
            "GRADE",
            "HISTOLOGICAL_TYPE",
            "HORMONAL_THERAPY",
            "IMAGING_TEST",
            "IMMUNOTHERAPY",
            "INVASION",
            "LINE_OF_THERAPY",
            "METASTASIS",
            "ONCOGENE",
            "PATHOLOGY_RESULT",
            "PATHOLOGY_TEST",
            "PERFORMANCE_STATUS",
            "RADIATION_DOSE",
            "RADIOTHERAPY",
            "RESPONSE_TO_TREATMENT",
            "ROUTE",
            "SITE_BONE",
            "SITE_BRAIN",
            "SITE_BREAST",
            "SITE_LIVER",
            "SITE_LUNG",
            "SITE_LYMPH_NODE",
            "SITE_OTHER_BODY_PART",
            "STAGING",
            "TARGETED_THERAPY",
            "TUMOR_FINDING",
            "UNSPECIFIC_THERAPY",
        ]
    },
    "hcpcs": {"ner_jsl": ["PROCEDURE"], "ner_clinical": ["TREATMENT"]},
    "hgnc": {"ner_human_phenotype_gene_clinical": ["GENE"]},
    "meddra_llt": {
        "ner_jsl": [
            "PROCEDURE",
            "KIDNEY_DISEASE",
            "CEREBROVASCULAR_DISEASE",
            "HEART_DISEASE",
            "DISEASE_SYNDROME_DISORDER",
            "IMAGINGFINDINGS",
            "SYMPTOM",
            "VS_FINDING",
            "EKG_FINDINGS",
            "COMMUNICABLE_DISEASE",
            "SUBSTANCE",
            "INTERNAL_ORGAN_OR_COMPONENT",
            "EXTERNAL_BODY_PART_OR_REGION",
            "MODIFIER",
            "TRIGLYCERIDES",
            "ALCOHOL",
            "SMOKING",
            "PREGNANCY",
            "HYPERTENSION",
            "OBESITY",
            "INJURY_OR_POISONING",
            "TEST",
            "HYPERLIPIDEMIA",
            "BMI",
            "ONCOLOGICAL",
            "PSYCHOLOGICAL_CONDITION",
            "LDL",
            "DIABETES",
        ],
        "ner_clinical_large": ["PROBLEM"],
    },
    "meddra_pt": {
        "ner_jsl": [
            "PROCEDURE",
            "KIDNEY_DISEASE",
            "CEREBROVASCULAR_DISEASE",
            "HEART_DISEASE",
            "DISEASE_SYNDROME_DISORDER",
            "IMAGINGFINDINGS",
            "SYMPTOM",
            "VS_FINDING",
            "EKG_FINDINGS",
            "COMMUNICABLE_DISEASE",
            "SUBSTANCE",
            "INTERNAL_ORGAN_OR_COMPONENT",
            "EXTERNAL_BODY_PART_OR_REGION",
            "MODIFIER",
            "TRIGLYCERIDES",
            "ALCOHOL",
            "SMOKING",
            "PREGNANCY",
            "HYPERTENSION",
            "OBESITY",
            "INJURY_OR_POISONING",
            "TEST",
            "HYPERLIPIDEMIA",
            "BMI",
            "ONCOLOGICAL",
            "PSYCHOLOGICAL_CONDITION",
            "LDL",
            "DIABETES",
        ],
        "ner_clinical_large": ["PROBLEM"],
    },
    "rxnorm": {"ner_posology_greedy": ["DRUG"], "ner_jsl_greedy": ["DRUG"]},
    "icd10pcs": {"ner_clinical": ["TREATMENT"], "ner_jsl": ["PROCEDURE"]},
    "icdo": {
        "ner_oncology": [
            "CANCER_DX",
            "HISTOLOGICAL_TYPE",
            "METASTASIS",
            "TUMOR_FINDING",
        ],
        "ner_jsl": ["ONCOLOGICAL"],
    },
    "loinc": {"ner_jsl": ["TEST"], "ner_clinical": ["TEST"]},
    "snomed": {
        "ner_jsl": [
            "PROCEDURE",
            "KIDNEY_DISEASE",
            "CEREBROVASCULAR_DISEASE",
            "HEART_DISEASE",
            "DISEASE_SYNDROME_DISORDER",
            "IMAGINGFINDINGS",
            "SYMPTOM",
            "VS_FINDING",
            "EKG_FINDINGS",
            "COMMUNICABLE_DISEASE",
            "SUBSTANCE",
            "DRUG_INGREDIENT",
            "INTERNAL_ORGAN_OR_COMPONENT",
            "EXTERNAL_BODY_PART_OR_REGION",
            "MODIFIER",
            "TRIGLYCERIDES",
            "ALCOHOL",
            "SMOKING",
            "PREGNANCY",
            "HYPERTENSION",
            "OBESITY",
            "INJURY_OR_POISONING",
            "TEST",
            "HYPERLIPIDEMIA",
            "BMI",
            "ONCOLOGICAL",
            "PSYCHOLOGICAL_CONDITION",
            "LDL",
            "DIABETES",
            "HDL",
        ],
        "ner_snomed_term": ["SNOMED_TERM"],
        "ner_posology": ["DRUG"],
        "ner_clinical": ["PROBLEM", "TREATMENT"],
    },
}


def download_vector_db(concept, output_dir=MODEL_LOCATION, region_name="us-east-1"):
    import boto3
    from botocore.client import Config

    BUCKET_NAME = "dev.johnsnowlabs.com"
    SOURCE_FILE = f"healthcare_team/resolvers_by_vectordb/{concept}_chroma_db/{concept}_chroma_db.zip"
    target_file = os.path.join(output_dir, f"{concept}_chroma_db.zip")
    extract_path = os.path.join(output_dir, "vector_db")

    os.makedirs(output_dir, exist_ok=True)
    if os.path.isdir(extract_path) and os.listdir(extract_path):
        logger.info("Vector DB already present at %s; skipping download.", extract_path)
        return
    s3 = boto3.client(
        "s3",
        region_name=region_name,
        config=Config(connect_timeout=60, read_timeout=70),
    )
    response = s3.head_object(Bucket=BUCKET_NAME, Key=SOURCE_FILE)

    total_size = response["ContentLength"]

    progress_tracker = ProgressPercentage(total_size)

    s3.download_file(
        BUCKET_NAME,
        SOURCE_FILE,
        target_file,
        Callback=progress_tracker.download_callback,
    )

    logger.info("\nDownload complete.")

    shutil.unpack_archive(target_file, extract_path)
    os.remove(target_file)


class ChromaResolverModelLoader(JslModelLoader):

    def _get_ner_stages(self, concept):
        """
        Builds a pipeline of stages for Named Entity Recognition (NER) based on the given concept.

        Args:
            concept (str): The medical coding system or concept (e.g., "icd10cm", "mesh").

        Returns:
            list: A list of Spark NLP pipeline stages for NER.
        """
        from sparknlp_jsl.annotator import (
            ChunkMergeApproach,
            MedicalNerModel,
            NerConverterInternal,
        )

        # Get the NER models and whitelists for the specified concept
        ner_models = vdb_ner_models[concept]

        # Initialize lists to store pipeline stages and chunk column names
        merger_inputs = []  # Stores names of columns containing NER chunks to be merged
        ner_pipe = []  # Stores the individual stages of the NER pipeline

        # Iterate through the selected NER models and their whitelists
        for ner_model, whitelist in ner_models.items():
            logger.info("Model Name :", ner_model, "---", "White List:", whitelist)

            try:
                # Load a pre-trained MedicalNerModel
                tmp_model = (
                    MedicalNerModel.pretrained(ner_model, "en", "clinical/models")
                    .setInputCols(["sentence", "token", "word_embeddings"])
                    .setOutputCol(ner_model)
                    .setLabelCasing("upper")
                )
                ner_pipe.append(tmp_model)  # Add the NER model to the pipeline

                # Add NerConverterInternal to convert NER annotations into chunks
                if len(whitelist) == 0:
                    # If no whitelist, use all entities
                    ner_pipe.append(
                        NerConverterInternal()
                        .setInputCols(["sentence", "token", ner_model])
                        .setOutputCol(f"{ner_model}_chunk")
                    )
                else:
                    # If whitelist is provided, filter entities
                    ner_pipe.append(
                        NerConverterInternal()
                        .setInputCols(["sentence", "token", ner_model])
                        .setOutputCol(f"{ner_model}_chunk")
                        .setWhiteList(whitelist)
                    )

                # Add the chunk column name to the list for merging
                merger_inputs.append(f"{ner_model}_chunk")

            except Exception as e:
                logger.error(e)

        # Create a ChunkMergeApproach to combine chunks from different NER models
        chunk_merger = (
            ChunkMergeApproach()
            .setInputCols(merger_inputs)
            .setOutputCol("ner_chunk")
            .setMergeOverlapping(True)
        )
        ner_pipe.append(chunk_merger)  # Add the chunk merger to the pipeline

        # Return the assembled NER pipeline stages
        return ner_pipe

    def load_local_model_from_disk(self, path: str = MODEL_LOCATION):

        logger.info(f"Loading Resover DB from {path}")
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        embeddings = HuggingFaceEmbeddings(
            model_name=f"{path}/embeddings",
            model_kwargs={"device": device},
        )
        db = Chroma(
            persist_directory=f"{MODEL_LOCATION}/vector_db",
            embedding_function=embeddings,
        )
        logger.info("Local DB loaded successfully")
        return db

    def get_ner_model(self, concept, spark):

        from sparknlp_jsl.annotator import (
            SentenceDetectorDLModel,
            Tokenizer,
            WordEmbeddingsModel,
        )

        """
        Creates and returns a Spark NLP pipeline model for Named Entity Recognition (NER).

        Args:
            concept (str): The medical coding system or concept (e.g., "icd10cm", "mesh").

        Returns:
            PipelineModel: A fitted Spark NLP pipeline model for NER.
        """

        # 1. Document Assembler: Converts raw text into Spark NLP Documents
        documentAssembler = (
            DocumentAssembler().setInputCol("text").setOutputCol("document")
        )

        # 2. Sentence Detector: Splits documents into sentences
        sentenceDetector = (
            SentenceDetectorDLModel.pretrained(
                "sentence_detector_dl_healthcare", "en", "clinical/models"
            )
            .setInputCols(["document"])
            .setOutputCol("sentence")
        )

        # 3. Tokenizer: Splits sentences into individual tokens (words)
        tokenizer = Tokenizer().setInputCols("sentence").setOutputCol("token")

        # 4. Word Embeddings: Generates word embeddings for each token
        word_embeddings = (
            WordEmbeddingsModel.pretrained(
                "embeddings_clinical", "en", "clinical/models"
            )
            .setInputCols("sentence", "token")
            .setOutputCol("word_embeddings")
        )

        # 5. Get NER Stages: Dynamically builds NER stages based on the concept
        ner_stages = self._get_ner_stages(concept)

        # 6. Create Pipeline: Combines all stages into a single pipeline
        pipeline = Pipeline(
            stages=[
                documentAssembler,
                sentenceDetector,
                tokenizer,
                word_embeddings,
                *ner_stages,
            ]
        )

        # 7. Fit Pipeline: Fits the pipeline to an empty DataFrame to initialize it
        empty_df = spark.createDataFrame([[""]]).toDF(
            "text"
        )  # Empty DataFrame for fitting
        logger.info("NER pipeline is ready...")
        model = pipeline.fit(empty_df)

        # 8. Return Model: Returns the fitted NER pipeline model
        return model

    @override
    def load_from_disk(self, path: str = MODEL_LOCATION) -> Dict:
        return {
            "pipeline": PretrainedPipeline.from_disk(f"{path}/ner_model"),
            "additional_artifacts": self.load_local_model_from_disk(),
        }

    @override
    def load_from_hub(self) -> Dict:
        output_dir = self.save_to_disk()
        return self.load_from_disk(output_dir)

    @override
    def save_to_disk(self, output_dir: str = MODEL_LOCATION) -> str:
        """Downloads the NER model, embeddings, and VectorDB for the specified concept."""

        concept = self._model_info.model_id

        if concept not in vdb_ner_models:
            raise ValueError(
                f"Unsupported concept: '{concept}'. "
                f"Supported concepts are: {', '.join(sorted(vdb_ner_models.keys()))}"
            )

        # VectorDB
        download_vector_db(
            concept,
            output_dir,
        )
        from endpoints.johnsnowlabs.spark_session import get_spark_session

        spark = get_spark_session()

        from sentence_transformers import SentenceTransformer

        # Download the model for the specified concept
        ner_model_path = os.path.join(output_dir, "ner_model")
        embeddings_path = os.path.join(output_dir, "embeddings")

        # NER model
        ner_model = self.get_ner_model(concept, spark)
        ner_model.write().overwrite().save(ner_model_path)

        # Embeddings model
        embeddings = SentenceTransformer("BAAI/bge-base-en-v1.5")
        embeddings.save_pretrained(embeddings_path)

        return output_dir
