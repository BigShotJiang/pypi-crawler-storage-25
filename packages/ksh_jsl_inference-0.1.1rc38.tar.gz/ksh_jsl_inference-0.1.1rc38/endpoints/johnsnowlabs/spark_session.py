import os
import sys
from typing import Optional

from johnsnowlabs import nlp

from endpoints.logging import logger

from .jsl_model import JslModel
from .utils import is_visual_nlp_model

os.environ["PYSPARK_PYTHON"] = sys.executable
os.environ["PYSPARK_DRIVER_PYTHON"] = sys.executable


def _start_spark(**jsl_kwargs):
    """Start a Spark session using John Snow Labs helpers.

    Args:
        **jsl_kwargs: Keyword arguments forwarded to ``johnsnowlabs.nlp.start``.

    Returns:
        pyspark.sql.SparkSession: The configured Spark session instance.
    """
    logger.info("Starting Spark Session ...")

    spark = nlp.start(**jsl_kwargs)
    spark.sparkContext.setLogLevel("ERROR")

    logger.info("Spark Session started")
    return spark


class SparkSession:
    """Singleton wrapper around a Spark session.

    The first instantiation starts Spark and caches the session for
    subsequent calls.
    """

    _instance = None
    _spark = None

    def __new__(cls, **jsl_kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._spark = _start_spark(**jsl_kwargs)
        return cls._instance

    @property
    def spark(self):
        """Return the cached Spark session.

        Returns:
            pyspark.sql.SparkSession: The cached Spark session.
        """
        return self._spark


def get_spark_session(model: Optional[JslModel] = None):
    """Return a Spark session, enabling visual NLP when needed.

    Args:
        model: Optional JSL model used to determine if visual support
            is required.

    Returns:
        pyspark.sql.SparkSession: The Spark session instance.
    """
    visual = False
    if model:
        visual = is_visual_nlp_model(model)

    return SparkSession(visual=visual).spark
