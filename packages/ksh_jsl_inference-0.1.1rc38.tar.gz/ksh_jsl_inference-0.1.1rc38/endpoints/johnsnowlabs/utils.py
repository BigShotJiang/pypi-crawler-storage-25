from typing import TYPE_CHECKING

try:
    from sparknlp_jsl.annotator import *  # noqa: F403
except:
    pass

if TYPE_CHECKING:
    from endpoints.core.models import BaseModel


def is_healthcare_nlp_model(model: "BaseModel"):
    """Check whether the model is a healthcare NLP model.

    Args:
        model_info: Model metadata containing the loaded model instance.

    Returns:
        True if the model is a `MedNlpModel` instance or subclass, otherwise False.
    """
    from endpoints.johnsnowlabs.healthcare.models import MedNlpModel

    return isinstance(model, MedNlpModel)


def is_base_visual_nlp_model(model: "BaseModel"):
    """Check whether the model is the base visual NLP model.

    Args:
        model_info: Model metadata containing the loaded model instance.

    Returns:
        True if the model is a `VisualNlpModel` instance, otherwise False.
    """
    try:
        from endpoints.johnsnowlabs.visual.models import VisualNlpModel

        return type(model) is VisualNlpModel
    except:
        return False


def is_chroma_resolver_model(model: "BaseModel"):
    """Checks whether the model is a Chroma Resolver model

    Args:
        model_info: Model metadata containing the loaded model instance.

    Returns:
        True if the model is a `ChromaDbResolverModel` instance or subclass, otherwise False.
    """
    try:
        from endpoints.johnsnowlabs.healthcare.models import ChromaDbResolverModel

        return isinstance(model, ChromaDbResolverModel)
    except:
        return False


def is_visual_nlp_model(model: "BaseModel"):
    """Check whether the model is a visual NLP model.

    Args:
        model_info: Model metadata containing the loaded model instance.

    Returns:
        True if the model is a `VisualNlpModel` instance or subclass, otherwise False.
    """
    try:
        from endpoints.johnsnowlabs.visual.models import VisualNlpModel

        return isinstance(model, VisualNlpModel)
    except:
        return False


def is_jsl_model(model: "BaseModel"):
    return is_healthcare_nlp_model(model) or is_visual_nlp_model(model)
