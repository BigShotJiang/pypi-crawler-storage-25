from endpoints import ModelType
from endpoints.core import ModelInfo

from .models import PdfDeidentification

VISUAL_NLP_MODELS = [
    ModelInfo(
        model_id="pdf_deid_multi_model_context_pipeline",
        language="en",
        model_type=ModelType.PRETRAINED_VISUAL,
        model=PdfDeidentification(),
    )
]
