from endpoints.logging import logger

try:
    import sparkocr  # noqa: F401

    from . import loader, models  # noqa: F401  # noqa: F401
except ImportError:
    logger.warning("sparkocr is not installed. Visual NLP modules can't be used")
