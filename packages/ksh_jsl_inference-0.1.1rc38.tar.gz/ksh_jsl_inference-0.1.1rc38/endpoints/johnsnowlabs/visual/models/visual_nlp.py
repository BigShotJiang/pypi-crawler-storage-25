import base64
import json
import os
import tempfile
from typing import Dict, List, cast

from pyspark.sql.dataframe import DataFrame
from sparkocr.base import LightPipeline
from sparkocr.pretrained import PretrainedPipeline
from typing_extensions import override

from endpoints.core.models.schema import Schema, SchemaCollection
from endpoints.logging import logger

from ...encoder import JslEncoder
from ...jsl_model import JslModel


class VisualNlpModel(JslModel):
    """Visual NLP model wrapper for OCR pipelines."""

    def __init__(self, mime_types: List[str] = []):
        """Initialize the visual NLP model.

        Args:
            mime_types (List[str]): Additional MIME types to accept for inputs.
        """
        super().__init__(
            input=Schema(field="file", typing=Dict, required=True),
            input_params=SchemaCollection([Schema(field="content_type", typing=str)]),
            output=Schema(field="predictions", typing=Dict, required=True),
        )
        self._spark = None
        self._pipeline = None
        self._use_lp = False
        self.supported_mime_types = ["application/octet-stream"] + mime_types

    @property
    def use_lp(self):
        """bool: Whether to use the light pipeline for inference."""
        return self._use_lp

    @use_lp.setter
    def use_lp(self, value):
        """Set whether to use the light pipeline for inference.

        Args:
            value (bool): True to use light pipeline, False to use pretrained.
        """
        self._use_lp = value

    @override
    def concrete_predict(self, input_data: Dict) -> Dict:
        """Run inference for one or more inputs.

        Args:
            input_data (Dict): Payload containing inputs and params.

        Returns:
            Dict: Predictions keyed by the output field name.
        """
        file_inputs = input_data["inputs"]
        all_params = input_data["params"]

        all_results = []
        for file_input, params in zip(file_inputs, all_params):
            if self.use_lp:
                results = self.process_file_data_using_light_pipeline(
                    file_input, params
                )
            else:
                results = self.process_file_using_pipeline(file_input, params)
            all_results.append(results)
        return {self._output._field: all_results}

    def process_file_data_using_light_pipeline(
        self, file_input: Dict, params: Dict
    ) -> Dict:
        """Process file input using a light pipeline.

        Args:
            file_input (Dict): Single input containing data or url.
            params (Dict): Additional input params.

        Returns:
            Dict: Processed prediction results.
        """
        logger.debug("Use light pipeline to get the results ...")
        ocr_pretrained = cast(PretrainedPipeline, self.pipeline)
        light_pipeline = ocr_pretrained.light_model or LightPipeline(
            ocr_pretrained.model
        )
        results = []

        if "url" in file_input:
            url_input = file_input["url"]
            results = light_pipeline.fromLocalPath(url_input)
        else:
            data_input = file_input["data"]
            if isinstance(data_input, str):
                # base64 encoded data
                results = light_pipeline.fromString(data_input)
            elif (data_input, bytes):
                results = light_pipeline.fromBinary(data_input)

        return self.process_light_pipeline_results(results, file_input, params)

    def process_file_using_pipeline(self, file_input: Dict, params: Dict) -> Dict:
        """Process file input using the pretrained pipeline.

        Args:
            file_input (Dict): Single input containing data or url.
            params (Dict): Additional input params.

        Returns:
            Dict: Processed prediction results.
        """
        logger.debug("Use pretrained pipeline to get the results ...")
        results = None
        path = None
        if "data" in file_input:
            fd, path = tempfile.mkstemp()
            try:
                raw_data = file_input["data"]
                ## Save file to temporary directory
                if isinstance(raw_data, str):
                    # base64 encoded data
                    os.write(fd, base64.b64decode(raw_data))
                elif isinstance(raw_data, bytes):
                    os.write(fd, raw_data)
            except:
                pass

            finally:
                os.close(fd)
        else:
            path = file_input["url"]

        df = self.spark.read.format("binaryFile").load(path)
        results = self.pipeline.transform(df)

        return self.process_pretrained_pipeline_results(file_input, results, params)

    def process_light_pipeline_results(
        self, results: List[Dict], file_input: Dict, params: Dict
    ) -> Dict:
        """Convert light pipeline results into JSON-serializable output.

        Args:
            results (List[Dict]): Raw results from the light pipeline.
            file_input (Dict): Original file input.
            params (Dict): Additional input params.

        Returns:
            Dict: JSON-serializable results.
        """
        data = json.dumps(results, cls=JslEncoder)
        return json.loads(data)

    def process_pretrained_pipeline_results(
        self, input: Dict, results: DataFrame, params: Dict
    ) -> Dict:
        """Process results from the pretrained pipeline.

        Subclasses can override this method to customize the output.

        Args:
            input (Dict): Original file input.
            results (DataFrame): Results from the pretrained pipeline.
            params (Dict): Additional input params.

        Returns:
            Dict: Processed results.
        """
        json_result = results.toJSON().collect()
        return list(map(json.loads, json_result))[0]

    @override
    def dispose(self):
        """Dispose model resources and stop the Spark context."""
        self.spark.sparkContext.stop()
