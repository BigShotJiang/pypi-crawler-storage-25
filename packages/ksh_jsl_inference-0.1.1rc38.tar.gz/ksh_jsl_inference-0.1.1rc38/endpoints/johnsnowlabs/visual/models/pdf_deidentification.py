from typing import Any, Dict

from pyspark.sql.dataframe import DataFrame
from typing_extensions import override

from endpoints.core.models.schema import Schema

from .visual_nlp import VisualNlpModel


class PdfDeidentification(VisualNlpModel):

    def __init__(self):
        # Only support pdfs
        super().__init__(mime_types=["application/pdf"])

        self._output = Schema(field="deidentified_pdf", typing=bytes, required=True)

    @override
    def process_pretrained_pipeline_results(
        self, input: Dict, results: DataFrame, params: Dict
    ) -> Any:
        """Process results from the pretrained pipeline.

        Subclasses can override this method to customize the output.

        Args:
            inputs (List[str]): Input texts.
            results (DataFrame): Results from the pretrained pipeline.
            params (Dict): Additional input params.

        Returns:
            List: Processed results.
        """
        res = None
        for index, row in enumerate(results.select("pdf", "path").toLocalIterator()):
            res = row.pdf

        return bytes(res)

    # TODO add for light pipelines
