import json


def ignore_unserializable(obj):
    # Instead of raising TypeError, return a string or None
    return f"<<{type(obj).__name__} not serializable>>"


class JslEncoder(json.JSONEncoder):
    def default(self, o):
        try:
            return o.__dict__
        except:
            return ignore_unserializable(o)
