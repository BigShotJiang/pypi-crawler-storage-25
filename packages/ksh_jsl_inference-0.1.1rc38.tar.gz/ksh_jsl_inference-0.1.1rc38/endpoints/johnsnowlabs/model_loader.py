import os
import shutil
from abc import ABC, abstractmethod
from typing import Dict

from endpoints.core import ModelInfo
from endpoints.settings import MODEL_LOCATION, config


class JslModelLoader(ABC):

    def __init__(self, model_info: ModelInfo) -> None:
        self._model_info = model_info

    @abstractmethod
    def load_from_disk(self, path: str = MODEL_LOCATION) -> Dict:
        """Load model artifacts from the local disk.

        Args:
            path (str): Filesystem path for model artifacts. Defaults to
                MODEL_LOCATION (/opt/ml/model).

        Returns:
            Dict: Dictionary with two keys: pipeline and additional_artifacts.
            `pipeline` contains the JohnSnowlabs Pipeline Line
            `additional_artifacts` contains any other artifacts required
        """
        pass

    @abstractmethod
    def load_from_hub(self) -> Dict:
        """Load model artifacts from hub.

        Returns:
            Dict: Dictionary with two keys: pipeline and additional_artifacts.
            `pipeline` contains the JohnSnowlabs Pipeline Line
            `additional_artifacts` contains any other artifacts required
        """
        pass

    @abstractmethod
    def save_to_disk(self, output_dir: str = MODEL_LOCATION) -> str:
        """Save model artifacts to the local disk.

        Args:
            output_dir (str): Filesystem output_dir for model artifacts. Defaults to
                MODEL_LOCATION (/opt/ml/model).

        Returns:
            str: Directory containing the saved model artifacts.
        """
        try:
            if os.path.exists(output_dir):
                shutil.rmtree(output_dir, ignore_errors=True)

            os.makedirs(output_dir, exist_ok=True)
            return output_dir
        except PermissionError as e:
            raise PermissionError(
                f"Permission error: {e}. Please ensure you have read/write access to {output_dir}."
            )

    def load(self) -> Dict:
        """Load model artifacts based on configuration.

        Returns:
            Dict: Dictionary with two keys: pipeline and additional_artifacts.
            `pipeline` contains the JohnSnowlabs Pipeline Line
            `additional_artifacts` contains any other artifacts required
        """
        if config.load_model_from_disk:
            return self.load_from_disk()
        else:
            return self.load_from_hub()
