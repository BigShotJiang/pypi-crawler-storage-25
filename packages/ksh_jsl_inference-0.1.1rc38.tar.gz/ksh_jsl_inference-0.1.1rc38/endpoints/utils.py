import os
import shutil
import sys
import threading
from pathlib import Path
from typing import Dict, List, Union

from endpoints.logging import logger


def validate_artifacts_path(path: str) -> str:
    """
    Validates when the file contains a JSL Model

    Args:
        path (str): Path containing the artifacts

    Returns:
        str: The validated artifacts path

    Raises:
        ValueError: If path is empty or None
        FileNotFoundError: If the path does not exist
        NotADirectoryError: If the path is not a directory
    """
    if not path:
        raise ValueError("Path cannot be empty or None")

    path_to_validate = Path(path).expanduser().absolute()

    if not os.path.exists(path_to_validate):
        raise FileNotFoundError(f"Artifacts path does not exist: {path_to_validate}")

    if not os.path.isdir(path_to_validate):
        raise NotADirectoryError(
            f"Artifacts path must be a directory: {path_to_validate}"
        )

    logger.debug(f"Successfully validated artifacts path: {path_to_validate}")
    return str(path_to_validate)


def copy_from_source_to_target(source: str, target: str):
    """
    Copies file or folder from source to target.

    Args:
        source (str): Path to the source file or directory
        target (str): Path to the target location

    Raises:
        FileNotFoundError: If source path does not exist
        PermissionError: If insufficient permissions to copy
        OSError: If an error occurs during copying
    """
    if not os.path.exists(source):
        raise FileNotFoundError(f"Source path does not exist: {source}")

    # Create target directory if it doesn't exist
    target_dir = os.path.dirname(target)
    if target_dir and not os.path.exists(target_dir):
        os.makedirs(target_dir, exist_ok=True)

    try:
        if os.path.isfile(source):
            # Copy file
            shutil.copy2(source, target)
            logger.debug(f"Copied file from {source} to {target}")
        elif os.path.isdir(source):
            # Copy directory
            if os.path.exists(target):
                shutil.rmtree(target)
            shutil.copytree(source, target)
            logger.debug(f"Copied directory from {source} to {target}")
        else:
            raise OSError(f"Source path is neither a file nor a directory: {source}")
    except Exception as e:
        logger.error(f"Failed to copy from {source} to {target}: {str(e)}")
        raise


def convert_to_a_list(
    text: Union[str, List, bytes], texts: List
) -> Union[List[str], bytes]:
    """
    Appends a string or list of strings to an existing list.

    Args:
        text (Union[str, List]): String or list of strings to append
        texts (List): Target list to append to

    Returns:
        List[str]: The modified list with appended text(s)
    """

    if isinstance(text, list):
        texts.extend(text)
    else:
        texts.append(text)
    return texts


def get_attr_or_key(item, key):
    """
    Fetches an attribute or dictionary key from an item.

    Tries to get an attribute first, and if that fails, tries to get a dictionary key.
    Returns None if neither exists.

    Args:
        item: Object or dictionary to retrieve value from
        key: Attribute name or dictionary key to retrieve

    Returns:
        The value of the attribute/key, or None if not found
    """
    return getattr(item, key, None) if hasattr(item, key) else item.get(key, None)


def copy_and_replace(src: str, dest: str, replacements: Dict[str, str]) -> None:
    """
    Copy a file from src to dest and replace the placeholders.

    Reads the source file, replaces all occurrences of keys in replacements
    with their corresponding values, then writes to the destination file.

    Args:
        src (str): Path to the source file
        dest (str): Path to the destination file
        replacements (Dict[str, str]): Dictionary of placeholder-to-value mappings

    Raises:
        FileNotFoundError: If source file does not exist
        PermissionError: If insufficient permissions to read/write files
        OSError: If an error occurs during file operations
    """
    with open(src, "r") as f:
        content = f.read()
    for key, value in replacements.items():
        content = content.replace(key, value)
    with open(dest, "w") as f:
        f.write(content)


def generate_license_file(output_dir: str) -> None:
    """
    Generate a license file in the specified directory.

    Creates a LICENSE file containing John Snow Labs Inc. proprietary license text
    in the given output directory.

    Args:
        output_dir (str): Directory path where the LICENSE file will be created

    Raises:
        PermissionError: If insufficient permissions to write to the directory
        OSError: If an error occurs during file creation
    """

    logger.debug(f"Generating license file in: {output_dir}")
    with open(f"{output_dir}/LICENSE", "w+") as f:
        f.write(
            """
Copyright 2015-2026 © John Snow Labs Inc.

This Software ("Software" or "Product") including code, design, documentation, configuration, models, tests, and related assets is owned by John Snow Labs Inc. All rights reserved.

John Snow Labs Inc. ("we") is the only owner of the copyright for this Software.

Unless otherwise specified in a separate Software License Agreement, Services Agreement, or End User License Agreement that you have executed directly with John Snow Labs Inc.:

* You are NOT granted any license or right to use the Software in any way.
* You are NOT granted any license or right to retain a copy of this Software.
* You are NOT granted any license or right to change, modify, adapt, or translate the Software.
* You are NOT granted any license or right to sell, assign, rent, exchange, lend, lease, sublease, or redistribute the Software.
* You are NOT granted any license or rights to bundle, repackage, or include the Software with any software in any way.
* The Software is Confidential and Proprietary. You are NOT allowed to distribute copies of the Software to others by any means whatsoever.
* The Software does NOT come with any warranty, express or implied.
* It is NOT legal to create derivative works based on the Software.
* It is NOT legal to claim any title in the Software or any of its derivatives.
* It is NOT legal to reverse engineer, disassemble or decompile the Software.
* It is NOT legal to make or retain a copy of the Software.
* We have no liability whatsoever for use of the Software.
* You may not make any public statements about this Software or John Snow Labs without explicit written permission from John Snow Labs.
* You must retain a copy of this notice without changes along with every copy of the Software, even if you have a license for it.

Unless required by applicable law or agreed to in writing, John Snow Labs provides the Software on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied, including, without limitation, any warranties or conditions of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A PARTICULAR PURPOSE. You are solely responsible for determining the appropriateness of using or redistributing the Software and assume any risks associated with Your exercise of permissions under this license.

In no event and under no legal theory, whether in tort (including negligence), contract, or otherwise, unless required by applicable law (such as deliberate and grossly negligent acts) or agreed to in writing, shall John Snow Labs be liable to You for damages, including any direct, indirect, special, incidental, or consequential damages of any character arising as a result of this license or out of the use or inability to use the Software (including but not limited to damages for loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages or losses), even if advised of the possibility of such damages.

Unless required by applicable law or agreed to in writing, Software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. """
        )


class ProgressPercentage:
    """
    A thread-safe progress tracking utility for file operations.

    This class provides callback methods for tracking upload and download progress,
    displaying real-time percentage completion in the terminal.

    Attributes:
        _total_size (int): Total size of the operation in bytes
        _seen_so_far (int): Number of bytes processed so far
        _lock (threading.Lock): Thread lock for safe concurrent access
    """

    def __init__(self, total_size):
        """
        Initialize the progress tracker.

        Args:
            total_size (int): Total size of the file in bytes.
        """
        self._total_size = total_size
        self._seen_so_far = 0
        self._lock = threading.Lock()

    def _update_progress(self, bytes_amount, operation):
        """
        Internal method to update and display progress.

        Args:
            bytes_amount (int): Number of bytes processed in the current chunk.
            operation (str): Type of operation ("uploading" or "downloading").
        """
        with self._lock:
            self._seen_so_far += bytes_amount
            percent = (self._seen_so_far / self._total_size) * 100
            sys.stdout.write(f"\r{operation.capitalize()}... {percent:.2f}% complete")
            sys.stdout.flush()

    def upload_callback(self, bytes_amount):
        """
        Callback method for upload progress.

        Args:
            bytes_amount (int): Number of bytes uploaded in the current chunk.
        """
        self._update_progress(bytes_amount, operation="uploading")

    def download_callback(self, bytes_amount):
        """
        Callback method for download progress.

        Args:
            bytes_amount (int): Number of bytes downloaded in the current chunk.
        """
        self._update_progress(bytes_amount, operation="downloading")
