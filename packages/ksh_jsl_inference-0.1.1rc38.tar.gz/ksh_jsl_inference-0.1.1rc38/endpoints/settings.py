"""
Default settings configuration module.

This module contains the default settings and configuration values used throughout
the JohnSnowLabs endpoints application. It defines constants for model locations,
directory paths, package information, and platform-specific configurations.
"""

import os
from typing import Optional

from endpoints import Platform

MODEL_LOCATION: str = os.environ.get("MODEL_LOCATION", "/opt/ml/model")
HOME_DIR: str = os.path.expanduser("~")

DEFAULT_JOHNSNOWLABS_VERSION: str = "6.2.0"
JSL_CACHE_PRETRAINED_DIR: str = os.path.join(HOME_DIR, "cache_pretrained")

ROOT_DIR: str = os.path.dirname(os.path.abspath(__file__))
PACKAGE_NAME: str = "ksh-jsl-inference"

DEFAULT_IMAGE_REPOSITORY_NAME: str = "jsl_inference"


os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")

"""Configuration accessors for server environment variables."""


class Config:
    @property
    def model_id(self) -> Optional[str]:
        """Optional model identifier from the environment.

        Returns:
            The value of the MODEL_ID environment variable, if set.
        """
        return os.getenv("MODEL_ID")

    @property
    def language(self) -> Optional[str]:
        """Optional language code from the environment.

        Returns:
            The value of the LANGUAGE environment variable, if set.
        """
        return os.getenv("LANGUAGE")

    @property
    def platform(self) -> Platform:
        """Target platform parsed from the environment.

        Returns:
            The Platform derived from the PLATFORM environment variable.
        """
        return Platform(os.getenv("PLATFORM", "local"))

    @property
    def workers(self) -> Optional[int]:
        """Worker process count from the environment.

        Returns:
            The integer value of WORKERS, or None if unset/invalid.
        """
        workers_env = os.getenv("WORKERS")
        try:
            return int(workers_env) if workers_env is not None else None
        except ValueError:
            return None

    @property
    def load_model_from_disk(self) -> bool:
        return bool(os.getenv("MODEL_FROM_DISK", False))


config = Config()
