import json
import os
from datetime import datetime
from http import HTTPStatus
from typing import Dict

from fastapi import APIRouter, BackgroundTasks, Depends, Request, status
from fastapi.responses import JSONResponse, Response

from endpoints.core.models import BaseModel
from endpoints.core.models.schema import SchemaValidationError
from endpoints.logging import logger
from endpoints.server.request.parsers import parse_snowflake_input

# Environment variables below will be automatically populated by Snowflake.
SNOWFLAKE_ACCOUNT = os.getenv("SNOWFLAKE_ACCOUNT")
SNOWFLAKE_HOST = os.getenv("SNOWFLAKE_HOST")
SNOWFLAKE_DATABASE = os.getenv("SNOWFLAKE_DATABASE")
SNOWFLAKE_SCHEMA = os.getenv("SNOWFLAKE_SCHEMA")

# Custom environment variables
SNOWFLAKE_USER = os.getenv("SNOWFLAKE_USER")
SNOWFLAKE_PASSWORD = os.getenv("SNOWFLAKE_PASSWORD")
SNOWFLAKE_ROLE = os.getenv("SNOWFLAKE_ROLE")
SNOWFLAKE_WAREHOUSE = os.getenv("SNOWFLAKE_WAREHOUSE")


BATCH_ID_STRING = "sf-external-function-query-batch-id"
SNOWFLAKE_BATCH_TABLE = "BATCH_JOBS"

router = APIRouter()


def get_login_token():
    """Read the Snowflake OAuth session token from disk.

    Returns:
        str: The session token contents.
    """
    with open("/snowflake/session/token", "r") as f:
        return f.read()


def get_connection_params() -> Dict:
    """Construct Snowflake connection params from environment variables.

    Returns:
        Dict: Connection parameters for snowflake.connector, or an empty dict
        when the session token is unavailable.
    """
    if os.path.exists("/snowflake/session/token"):
        return {
            "account": SNOWFLAKE_ACCOUNT,
            "host": SNOWFLAKE_HOST,
            "authenticator": "oauth",
            "token": get_login_token(),
            "warehouse": SNOWFLAKE_WAREHOUSE,
            "database": SNOWFLAKE_DATABASE,
            "schema": SNOWFLAKE_SCHEMA,
        }
    else:
        return {}


def create_snowflake_connection():
    """Create a Snowflake connector connection.

    Returns:
        snowflake.connector.SnowflakeConnection: An active connection instance.
    """
    import snowflake.connector

    return snowflake.connector.connect(**get_connection_params())


def get_batch_results(batch_id: str):
    """Fetch batch status and results for a given batch id.

    Args:
        batch_id (str): The batch identifier.

    Returns:
        tuple: A tuple of (status, results). Returns (None, None) when not found.
    """
    query = f"SELECT STATUS, RESULTS FROM {SNOWFLAKE_BATCH_TABLE} WHERE BATCH_ID = %s"
    with create_snowflake_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(query, (batch_id,))
            result = cursor.fetchone()
            if result:
                return (result[0], result[1])
            return (None, None)


def store_batch_records(batch_id, batch_length):
    """Create the batch table and insert a pending batch record.

    Args:
        batch_id (str): The batch identifier.
        data (dict): The request payload containing the input data array.
    """
    create_table_query = f"""
        CREATE TRANSIENT TABLE IF NOT EXISTS {SNOWFLAKE_BATCH_TABLE} (
            BATCH_ID STRING,
            CREATED_DATE TIMESTAMP,
            NUMBER_OF_INPUTS INTEGER,
            RESULTS STRING,
            STATUS INTEGER
        )
    """
    insert_query = (
        f"INSERT INTO {SNOWFLAKE_BATCH_TABLE} "
        "(BATCH_ID, CREATED_DATE, NUMBER_OF_INPUTS, RESULTS, STATUS) "
        "VALUES (%s, %s, %s, %s, %s)"
    )
    with create_snowflake_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(create_table_query)
            cursor.execute(
                insert_query,
                (
                    batch_id,
                    datetime.now(),
                    batch_length,
                    "",
                    202,
                ),
            )
        connection.commit()


def _prepare_standard_input(model: BaseModel, data_json_array):
    """Map Snowflake row arrays into the model's standard input schema.

    Args:
        model (BaseModel): The model providing input schema metadata.
        data_json_array (list): Raw input rows from the Snowflake request.

    Returns:
        list: A list of dictionaries formatted for model prediction.
    """
    standard_input = []
    for row_array in data_json_array:
        obj = {model._input._field: row_array[1]}

        for idx in range(len(row_array[2:])):
            obj[model._input_params.schemas[idx]._field] = row_array[idx + 2]
        standard_input.append(obj)
    return standard_input


def process_batch_input(model: BaseModel, batch_id, input_data):
    """Run model prediction and persist batch results.

    Args:
        model (BaseModel): Model instance used for prediction.
        batch_id (str): The batch identifier.
        input_data (List[dict]): The request payload containing input rows.
    """
    response_data = None
    status_code = 200

    try:
        logger.debug(f"Processing batch: {batch_id}")
        predictions = model.predict(input_data)
        logger.debug("Got predictions from background")

        result = predictions[model._output._field]

        results = result if isinstance(result, list) else [result]
        response_data = [
            [idx, prediction] for idx, prediction in enumerate(zip(results))
        ]
    except SchemaValidationError as e:
        status_code = 400
        response_data = {"error": str(e)}
        logger.error(e)
    except Exception as e:
        status_code = 500
        logger.error(e)
        response_data = {"error": str(e)}
    update_query = (
        f"UPDATE {SNOWFLAKE_BATCH_TABLE} "
        "SET RESULTS = %s, STATUS = %s WHERE BATCH_ID = %s"
    )
    with create_snowflake_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                update_query,
                (json.dumps({"data": response_data}), status_code, batch_id),
            )
        connection.commit()


@router.get("/invoke")
async def get_invoke_status(request: Request):
    """Return the processing status or results for a batch.

    Args:
        request (Request): FastAPI request with batch id header.

    Returns:
        Response: A 202 when processing, 404 if unknown, or the stored result.
    """
    batch_id = request.headers.get(BATCH_ID_STRING, "")
    logger.debug(f"Request status of Batch: {batch_id}")
    status_flag, result = get_batch_results(batch_id)
    if not status_flag:
        return Response(
            status_code=status.HTTP_404_NOT_FOUND,
            content="Unknown item status",
        )
    if status_flag == 202:
        return JSONResponse(
            status_code=status.HTTP_202_ACCEPTED, content={"message": "Processing"}
        )

    return Response(
        status_code=status_flag, content=result, media_type="application/json"
    )


@router.post("/invoke", status_code=status.HTTP_202_ACCEPTED)
async def invoke(
    request: Request,
    background_tasks: BackgroundTasks,
    input_data=Depends(parse_snowflake_input),
):
    """Store request and enqueue background batch processing.

    Args:
        request (Request): FastAPI request containing batch id and payload.
        background_tasks (BackgroundTasks): Task manager for async work.

    Returns:
        dict | JSONResponse: Processing message or error response.
    """
    try:
        model = request.app.state.model_info.model
        batch_id = request.headers.get(BATCH_ID_STRING)
        store_batch_records(batch_id, len(input_data))
        background_tasks.add_task(process_batch_input, model, batch_id, input_data)
        return {"message": "Processing"}
    except Exception as e:
        logger.error(f"Error processing request: {str(e)}")
        return JSONResponse(
            status_code=HTTPStatus.INTERNAL_SERVER_ERROR, content={"detail": str(e)}
        )
