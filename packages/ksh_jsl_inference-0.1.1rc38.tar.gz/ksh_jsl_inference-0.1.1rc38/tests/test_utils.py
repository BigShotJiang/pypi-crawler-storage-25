from pathlib import Path

import pytest

from endpoints.utils import (
    ProgressPercentage,
    convert_to_a_list,
    copy_and_replace,
    copy_from_source_to_target,
    generate_license_file,
    get_attr_or_key,
    validate_artifacts_path,
)


class DummyItem:
    def __init__(self, value):
        self.value = value


def test_validate_artifacts_path_errors(tmp_path):
    with pytest.raises(ValueError, match="Path cannot be empty or None"):
        validate_artifacts_path("")

    with pytest.raises(FileNotFoundError):
        validate_artifacts_path(str(tmp_path / "missing"))

    file_path = tmp_path / "file.txt"
    file_path.write_text("data")
    with pytest.raises(NotADirectoryError):
        validate_artifacts_path(str(file_path))


def test_validate_artifacts_path_returns_absolute(tmp_path):
    result = validate_artifacts_path(str(tmp_path))
    assert result == str(Path(tmp_path).absolute())


def test_copy_from_source_to_target_file(tmp_path):
    source = tmp_path / "source.txt"
    target = tmp_path / "target" / "copy.txt"
    source.write_text("hello")

    copy_from_source_to_target(str(source), str(target))

    assert target.read_text() == "hello"


def test_copy_from_source_to_target_directory(tmp_path):
    source_dir = tmp_path / "source_dir"
    source_dir.mkdir()
    (source_dir / "a.txt").write_text("a")

    target_dir = tmp_path / "target_dir"
    target_dir.mkdir()
    (target_dir / "old.txt").write_text("old")

    copy_from_source_to_target(str(source_dir), str(target_dir))

    assert (target_dir / "a.txt").read_text() == "a"
    assert not (target_dir / "old.txt").exists()


def test_copy_from_source_to_target_missing_source(tmp_path):
    with pytest.raises(FileNotFoundError):
        copy_from_source_to_target(str(tmp_path / "missing"), str(tmp_path / "target"))


def test_convert_to_a_list_appends_strings():
    texts = ["one"]
    result = convert_to_a_list("two", texts)
    assert result == ["one", "two"]


def test_convert_to_a_list_extends_list():
    texts = ["one"]
    result = convert_to_a_list(["two", "three"], texts)
    assert result == ["one", "two", "three"]


def test_convert_to_a_list_appends_bytes():
    texts = []
    result = convert_to_a_list(b"data", texts)
    assert result == [b"data"]


def test_get_attr_or_key_prefers_attribute():
    item = DummyItem("attr")
    assert get_attr_or_key(item, "value") == "attr"


def test_get_attr_or_key_falls_back_to_key():
    item = {"value": "key"}
    assert get_attr_or_key(item, "value") == "key"


def test_get_attr_or_key_missing_returns_none():
    item = {"value": "key"}
    assert get_attr_or_key(item, "missing") is None


def test_copy_and_replace(tmp_path):
    src = tmp_path / "template.txt"
    dest = tmp_path / "output.txt"
    src.write_text("Hello {{name}}")

    copy_and_replace(str(src), str(dest), {"{{name}}": "World"})

    assert dest.read_text() == "Hello World"


def test_generate_license_file(tmp_path):
    generate_license_file(str(tmp_path))

    license_path = tmp_path / "LICENSE"
    assert license_path.exists()
    content = license_path.read_text()
    assert "John Snow Labs Inc." in content
    assert "Copyright 2015-2026" in content


def test_progress_percentage_upload_callback(capsys):
    progress = ProgressPercentage(total_size=100)

    progress.upload_callback(25)

    captured = capsys.readouterr()
    assert "Uploading... 25.00% complete" in captured.out


def test_progress_percentage_download_callback(capsys):
    progress = ProgressPercentage(total_size=200)

    progress.download_callback(50)

    captured = capsys.readouterr()
    assert "Downloading... 25.00% complete" in captured.out
