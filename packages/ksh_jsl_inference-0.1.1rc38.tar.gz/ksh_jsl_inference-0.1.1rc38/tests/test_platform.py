import subprocess
import sys

import pytest

from endpoints import Platform


class TestPlatform:
    @pytest.mark.parametrize(
        "platform,expected_requirements",
        [
            (Platform.SNOWFLAKE, ["snowflake.core"]),
            (Platform.LOCAL, []),
            (Platform.SAGEMAKER, []),
        ],
    )
    def test_get_python_requirements(self, platform, expected_requirements):
        assert platform.get_python_requirements() == expected_requirements


@pytest.mark.parametrize(
    "module",
    [
        "endpoints.johnsnowlabs",
        "endpoints.cli",
        "endpoints.container",
        "endpoints.core",
        "endpoints.logging",
        "endpoints.sagemaker",
        "endpoints.snowflake",
        "endpoints.server",
        "endpoints.settings",
    ],
)
def test_circular_dependency(module):
    # Run a separate python process to try importing the module
    result = subprocess.run(
        [sys.executable, "-c", f"import {module}"], capture_output=True, text=True
    )
    # If returncode is not 0, an ImportError occurred
    assert (
        result.returncode == 0
    ), f"Circular import detected in {module}:\n{result.stderr}"
