from .d2_loader import *

__doc__ = d2_loader.__doc__
if hasattr(d2_loader, "__all__"):
    __all__ = d2_loader.__all__