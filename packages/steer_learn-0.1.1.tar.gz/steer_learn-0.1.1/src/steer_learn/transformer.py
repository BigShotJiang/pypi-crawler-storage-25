import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin

class PathSplitter(BaseEstimator, TransformerMixin):
    def __init__(self, sep = "->"):
        self.sep = sep

    def fit(self, X, y=None):
        return self

    def transform(self, X, y=None):
        return np.array(
            [state.strip() for state in x.split(self.sep)]
            for x in X
        )

class PathFlanker(BaseEstimator, TransformerMixin):
    def __init__(self, start_state = "<START>"):
        self.start_state = start_state

    def fit(self, X, y=None):
        return self

    def transform(self, X, y=None):
        return np.array(
            np.array(
                [self.start_state] + list(x) + [_y, _y]
            )
            for x, _y in zip(X, y)
        )

class TransitionRoller(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None):
        return self

    @staticmethod
    def transform(self, X, y=None):
        transitions = []
        for x in X:
            for i in range(len(x) - 1):
                transitions.append([x[i], x[i + 1]])
        return np.array(transitions)

class PaddingTransformer(BaseEstimator, TransformerMixin):
    max_len: int
    _pad_token = "<PADDING>"

    def fit(self, X, y=None):
        self.max_len = max(len(x) for x in X)
        return self

    def transform(self, X, y=None):
        return np.array(
            [self._pad_token] * (self.max_len - len(X)) + list(X)
        )
