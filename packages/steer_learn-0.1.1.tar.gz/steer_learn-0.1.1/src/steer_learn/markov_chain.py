from typing import Iterable

import numpy as np
from sklearn.base import BaseEstimator, ClassifierMixin

class MarkovAbsorbingModel(BaseEstimator, ClassifierMixin):
    _n_absorbing_states: int
    _n_transient_states: int
    _b_matrix: np.ndarray
    _absorbing_states: np.ndarray
    _transient_states: np.ndarray
    _transient_map: np.ndarray

    def fit(self, X: Iterable[Iterable[int]], y: Iterable[Iterable[int]]):
        srcs = np.array(X)
        trgs = np.array(y)
        n_states = srcs.shape[1]
        srcs = np.argmax(srcs, axis=1)
        trgs = np.argmax(trgs, axis=1)
        transitions = np.zeros((
            n_states,
            n_states
        ))
        for src, trg in zip(srcs, trgs):
            transitions[src, trg] += 1
        totals = np.sum(transitions, axis=1)
        abs_idx = totals == 1
        trans_idx = totals < 1
        safe_totals = totals.copy()
        safe_totals[abs_idx] = 1
        transitions = transitions / safe_totals[:, None]
        self._n_absorbing_states = np.sum(abs_idx)
        self._n_transient_states = np.sum(trans_idx)
        self._absorbing_states = np.flatnonzero(abs_idx)
        self._transient_states = np.flatnonzero(trans_idx)
        self._transient_map = np.full(n_states, -1, dtype=int)
        self._transient_map[self._transient_states] = np.arange(self._n_transient_states)
        Q = transitions[np.ix_(trans_idx, trans_idx)]
        R = transitions[np.ix_(trans_idx, abs_idx)]
        N = np.linalg.inv(
            np.identity(self._n_transient_states) - Q
        )
        self._b_matrix = N @ R
        return self

    def predict(self, X: Iterable[Iterable[int]]) -> Iterable[int]:
        probs = self.predict_proba(X)
        return self._absorbing_states[np.argmax(probs, axis=1)]

    def predict_proba(self, X: Iterable[Iterable[int]]) -> Iterable[Iterable[float]]:
        idx = np.argmax(np.array(X), axis=1)
        probs = np.zeros((len(idx), self._n_absorbing_states))
        transient_mask = self._transient_map[idx] >= 0
        probs[transient_mask] = self._b_matrix[self._transient_map[idx[transient_mask]]]
        for i, state in enumerate(idx):
            if not transient_mask[i]:
                probs[i, self._absorbing_states == state] = 1.0
        return probs

class BayesianAbsorbingModel(BaseEstimator, ClassifierMixin):
    _n_absorbing_states: int
    _n_transient_states: int
    _p_matrix: np.ndarray
    _states_probs: np.ndarray
    _absorption_probs: np.ndarray

    def fit(self, X: Iterable[Iterable[int]], y: Iterable[Iterable[int]]):
        paths = np.array(X)
        end_states = np.argmax(y, axis=1)

        self._n_absorbing_states = np.max(end_states) + 1
        self._n_transient_states = np.max(paths) + 1

        p_matrix = np.zeros((
            self._n_absorbing_states,
            self._n_transient_states
        ))
        states_occurrences = np.zeros((
            self._n_transient_states,
        ))
        absorption_occurrences = np.zeros((self._n_absorbing_states,))

        for path, end_state in zip(paths, end_states):
            absorption_occurrences[end_state] += 1
            for state in set(path):
                p_matrix[end_state, state] += 1
            for state in set(path):
                states_occurrences[state] += 1

        p_row_sums = np.sum(p_matrix, axis=1, keepdims=True)
        self._p_matrix = np.divide(
            p_matrix,
            p_row_sums,
            out=np.zeros_like(p_matrix),
            where=p_row_sums != 0
        )

        states_total = states_occurrences.sum()
        if states_total == 0:
            self._states_probs = np.zeros_like(states_occurrences)
        else:
            self._states_probs = states_occurrences / states_total

        absorption_total = absorption_occurrences.sum()
        if absorption_total == 0:
            self._absorption_probs = np.zeros_like(absorption_occurrences)
        else:
            self._absorption_probs = absorption_occurrences / absorption_total

        return self

    def _prob(self, path: Iterable[int]) -> np.ndarray:
        path = np.array(path)
        result = np.log(self._absorption_probs) * len(path)
        for state in path:
            result += (
                np.log(self._p_matrix[:, state]) -
                np.log(self._states_probs[state])
            )
        return result

    def predict_proba(self, X: Iterable[Iterable[int]]) -> Iterable[Iterable[float]]:
        log_probs = self.predict_log_proba(X)
        return np.exp(log_probs)

    def predict_log_proba(self, X: Iterable[Iterable[int]]) -> Iterable[Iterable[float]]:
        x = np.array(X)
        result = np.zeros((len(x), self._n_absorbing_states))
        for i, path in enumerate(x):
            result[i, :] = self._prob(path)
        return result

    def predict(self, X: Iterable[Iterable[int]]) -> Iterable[int]:
        log_probs = self.predict_log_proba(X)
        return np.argmax(log_probs, axis=1)