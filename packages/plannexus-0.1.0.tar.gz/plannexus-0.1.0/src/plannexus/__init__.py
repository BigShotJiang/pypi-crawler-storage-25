"""Official Python client for the PlanNexus planning data API.

Example
-------

    from plannexus import PlanNexus

    client = PlanNexus(api_key="pn_live_...")

    # Search
    result = client.applications.search(postcode="SW1", per_page=10)
    for app in result["data"]:
        print(app["reference"], app["address"])

    # Nearby
    nearby = client.applications.nearby(lat=51.509, lng=-0.118, radius=500)

    # Detail
    full = client.applications.get(app_id)

    # Async variant
    import asyncio
    from plannexus import AsyncPlanNexus

    async def main():
        async with AsyncPlanNexus(api_key="pn_live_...") as client:
            result = await client.applications.search(postcode="SW1")
            print(result["meta"]["total"])

    asyncio.run(main())

For the full endpoint surface see https://plannexus.io/docs.
"""

from plannexus._client import AsyncPlanNexus, PlanNexus, PlanNexusError, RateLimitError

__version__ = "0.1.0"

__all__ = [
    "PlanNexus",
    "AsyncPlanNexus",
    "PlanNexusError",
    "RateLimitError",
    "__version__",
]
