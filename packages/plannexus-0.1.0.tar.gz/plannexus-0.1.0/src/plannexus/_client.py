"""Thin httpx-backed client for api.plannexus.io.

Exposes both a synchronous ``PlanNexus`` and an async ``AsyncPlanNexus``
so callers can use whichever fits their runtime. Both expose the same
resource namespaces (``.applications``, ``.authorities``); the only
difference is that the async variant returns coroutines.
"""

from __future__ import annotations

import time
from typing import Any

import httpx

__all__ = [
    "PlanNexus",
    "AsyncPlanNexus",
    "PlanNexusError",
    "RateLimitError",
]

DEFAULT_BASE_URL = "https://api.plannexus.io"
_DEFAULT_USER_AGENT = "plannexus-python/0.1.0"
_DEFAULT_RETRY_429 = 3


class PlanNexusError(Exception):
    """Raised when the API returns a non-2xx response that isn't a 429.

    Attributes:
        status_code: HTTP status code of the response.
        detail: ``detail`` field from the error envelope, if present.
        body: The raw response body for debugging.
    """

    def __init__(self, status_code: int, detail: str | None, body: str) -> None:
        super().__init__(f"HTTP {status_code}: {detail or body[:200]}")
        self.status_code = status_code
        self.detail = detail
        self.body = body


class RateLimitError(PlanNexusError):
    """Raised when retries are exhausted on a 429.

    ``retry_after`` is the server-supplied hint (seconds) if present.
    """

    def __init__(self, detail: str | None, body: str, retry_after: int | None) -> None:
        super().__init__(429, detail, body)
        self.retry_after = retry_after


def _parse_error(response: httpx.Response) -> tuple[str | None, str]:
    body_text = response.text
    try:
        detail = response.json().get("detail")
    except Exception:
        detail = None
    return detail, body_text


def _raise_for_status(response: httpx.Response) -> None:
    if 200 <= response.status_code < 300:
        return
    detail, body = _parse_error(response)
    if response.status_code == 429:
        retry_after = None
        try:
            retry_after = int(response.headers.get("retry-after", "").strip() or "0") or None
        except ValueError:
            retry_after = None
        raise RateLimitError(detail, body, retry_after)
    raise PlanNexusError(response.status_code, detail, body)


class _Applications:
    def __init__(self, client: PlanNexus) -> None:
        self._c = client

    def search(self, **params: Any) -> dict[str, Any]:
        """Full-text + structured search. Returns ``{data, meta}``."""
        return self._c._get("/v1/applications", params=params)

    def nearby(self, lat: float, lng: float, radius: int = 1000, **params: Any) -> dict[str, Any]:
        """Applications within ``radius`` metres of (lat, lng)."""
        return self._c._get(
            "/v1/applications/nearby",
            params={"lat": lat, "lng": lng, "radius": radius, **params},
        )

    def get(self, application_id: str) -> dict[str, Any]:
        """Single application by UUID."""
        return self._c._get(f"/v1/applications/{application_id}")

    def documents(self, application_id: str) -> list[dict[str, Any]]:
        return self._c._get(f"/v1/applications/{application_id}/documents")

    def history(self, application_id: str) -> list[dict[str, Any]]:
        return self._c._get(f"/v1/applications/{application_id}/history")


class _Authorities:
    def __init__(self, client: PlanNexus) -> None:
        self._c = client

    def list(self) -> dict[str, Any]:
        return self._c._get("/v1/authorities")

    def get(self, authority_id: str) -> dict[str, Any]:
        return self._c._get(f"/v1/authorities/{authority_id}")


class _AsyncApplications:
    def __init__(self, client: AsyncPlanNexus) -> None:
        self._c = client

    async def search(self, **params: Any) -> dict[str, Any]:
        return await self._c._get("/v1/applications", params=params)

    async def nearby(
        self, lat: float, lng: float, radius: int = 1000, **params: Any
    ) -> dict[str, Any]:
        return await self._c._get(
            "/v1/applications/nearby",
            params={"lat": lat, "lng": lng, "radius": radius, **params},
        )

    async def get(self, application_id: str) -> dict[str, Any]:
        return await self._c._get(f"/v1/applications/{application_id}")

    async def documents(self, application_id: str) -> list[dict[str, Any]]:
        return await self._c._get(f"/v1/applications/{application_id}/documents")

    async def history(self, application_id: str) -> list[dict[str, Any]]:
        return await self._c._get(f"/v1/applications/{application_id}/history")


class _AsyncAuthorities:
    def __init__(self, client: AsyncPlanNexus) -> None:
        self._c = client

    async def list(self) -> dict[str, Any]:
        return await self._c._get("/v1/authorities")

    async def get(self, authority_id: str) -> dict[str, Any]:
        return await self._c._get(f"/v1/authorities/{authority_id}")


class PlanNexus:
    """Synchronous client. Closes its underlying httpx.Client on __exit__.

    Usage
    -----

        client = PlanNexus(api_key="pn_live_...")
        result = client.applications.search(postcode="SW1")

        # or with context manager:
        with PlanNexus(api_key=...) as client:
            ...
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        max_retries_429: int = _DEFAULT_RETRY_429,
    ) -> None:
        self._api_key = api_key
        self._max_retries_429 = max_retries_429
        self._http = httpx.Client(
            base_url=base_url,
            timeout=timeout,
            headers={
                "X-API-Key": api_key,
                "User-Agent": _DEFAULT_USER_AGENT,
                "Accept": "application/json",
            },
        )
        self.applications = _Applications(self)
        self.authorities = _Authorities(self)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> PlanNexus:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    def _get(self, path: str, *, params: dict[str, Any] | None = None) -> Any:
        for attempt in range(self._max_retries_429 + 1):
            response = self._http.get(path, params=params)
            if response.status_code == 429 and attempt < self._max_retries_429:
                # Honour Retry-After (seconds) if sent; otherwise exponential
                # backoff capped at 60s per attempt.
                wait = _backoff_seconds(response, attempt)
                time.sleep(wait)
                continue
            _raise_for_status(response)
            return response.json()
        raise RuntimeError("unreachable")


class AsyncPlanNexus:
    """Asynchronous client. Use as an async context manager."""

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        max_retries_429: int = _DEFAULT_RETRY_429,
    ) -> None:
        self._api_key = api_key
        self._max_retries_429 = max_retries_429
        self._http = httpx.AsyncClient(
            base_url=base_url,
            timeout=timeout,
            headers={
                "X-API-Key": api_key,
                "User-Agent": _DEFAULT_USER_AGENT,
                "Accept": "application/json",
            },
        )
        self.applications = _AsyncApplications(self)
        self.authorities = _AsyncAuthorities(self)

    async def aclose(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> AsyncPlanNexus:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.aclose()

    async def _get(self, path: str, *, params: dict[str, Any] | None = None) -> Any:
        import asyncio

        for attempt in range(self._max_retries_429 + 1):
            response = await self._http.get(path, params=params)
            if response.status_code == 429 and attempt < self._max_retries_429:
                wait = _backoff_seconds(response, attempt)
                await asyncio.sleep(wait)
                continue
            _raise_for_status(response)
            return response.json()
        raise RuntimeError("unreachable")


def _backoff_seconds(response: httpx.Response, attempt: int) -> float:
    """Pick the wait between a 429 and the retry.

    Prefer the server's Retry-After (seconds); fall back to a capped
    exponential. 60s is the typical per-minute rate-limit window on
    the PlanNexus API.
    """
    hdr = response.headers.get("retry-after", "").strip()
    try:
        retry_after = int(hdr)
        if retry_after > 0:
            return float(retry_after)
    except ValueError:
        pass
    return float(min(60, 2 ** (attempt + 1)))
