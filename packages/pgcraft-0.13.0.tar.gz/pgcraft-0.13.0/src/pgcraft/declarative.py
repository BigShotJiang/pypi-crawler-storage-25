"""Declarative base classes for pgcraft-managed models and views.

Subclass :class:`PGCraftBase` once to create a project-level base,
then define model classes by inheriting from it.  The pgcraft plugin
pipeline runs automatically when each class body is executed.

Subclass :class:`PGCraftView` once to create a project-level
view base, then define views by inheriting from it.  The view is
registered for Alembic and the class is ORM-mapped so that
``select(MyView)`` works.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, ClassVar

from sqlalchemy import Column, Table
from sqlalchemy import MetaData as _SAMetaData
from sqlalchemy import types as sa_types
from sqlalchemy.orm import registry as SARegistry  # noqa: N812
from sqlalchemy_declarative_extensions import (
    View,
    register_function,
    register_view,
)
from sqlalchemy_declarative_extensions.dialects.postgresql import (
    Function,
    FunctionSecurity,
    FunctionVolatility,
)

from pgcraft.errors import PGCraftValidationError
from pgcraft.factory.base import (
    _resolve_plugins,
    _run_plugin_validators,
    _sort_plugins,
)
from pgcraft.factory.context import FactoryContext
from pgcraft.factory.dimension.simple import PGCraftSimple
from pgcraft.fk import DimensionRef, register_dimension
from pgcraft.utils.naming_convention import (
    construct_pgcraft_naming_conventions_dict,
)
from pgcraft.utils.query import compile_query

if TYPE_CHECKING:
    from sqlalchemy import MetaData, Select

    from pgcraft.plugin import Plugin


@dataclass(frozen=True)
class ViewOptions:
    """Options for declarative views.

    Set on a :class:`PGCraftViewMixin` or :class:`PGCraftView` subclass
    via ``__options__``.

    Attributes:
        materialized: If ``True``, creates a PostgreSQL materialized
            view instead of a regular view.

    """

    materialized: bool = False


def _parse_table_args(
    cls: type,
) -> tuple[str | None, list]:
    """Extract schema and extra constraints from __table_args__.

    Returns:
        ``(schema, extra_constraints)`` where *schema* may be
        ``None`` and *extra_constraints* is a list of table-level
        objects (``PGCraftCheck``, ``ForeignKeyConstraint``, etc.).

    """
    raw = getattr(cls, "__table_args__", None)
    if raw is None:
        return None, []
    if isinstance(raw, dict):
        return raw.get("schema"), []
    if isinstance(raw, tuple) and raw:
        items = list(raw)
        last = items[-1]
        if isinstance(last, dict):
            return last.get("schema"), items[:-1]
        return None, items
    return None, []


def _collect_columns(cls: type) -> list[Column]:
    """Read ``Column`` objects from the class's own ``__dict__``.

    Column objects whose ``name`` is ``None`` get the attribute
    name assigned automatically (matching declarative behaviour).
    Only the class's own dict is searched — inherited columns are
    not collected.
    """
    columns: list[Column] = []
    for attr_name, value in list(cls.__dict__.items()):
        if isinstance(value, Column):
            if value.name is None:
                value.name = attr_name
            if value.key is None:
                value.key = attr_name
            columns.append(value)
    return columns


def _find_registry(cls: type) -> SARegistry:
    """Return the ``_registry`` from the nearest base class in the MRO."""
    for klass in cls.__mro__:
        if "_registry" in klass.__dict__:
            return klass.__dict__["_registry"]
    msg = (
        f"{cls.__name__}: no ORM registry found on any base class. "
        f"Subclass PGCraftBase (or PGCraftView) before declaring models."
    )
    raise PGCraftValidationError(msg)


def _build_model(cls: type, registry: SARegistry) -> None:
    """Run the pgcraft plugin pipeline for *cls* and ORM-map it.

    Called from :meth:`PGCraftBase.__init_subclass__` once per
    model class (those that have a ``__tablename__``).

    Args:
        cls: The model class being defined.
        registry: The SQLAlchemy ``registry`` to use for imperative
            mapping.

    Raises:
        PGCraftValidationError: On missing metadata, schema, or
            plugin misconfiguration.

    """
    # Resolve metadata from the MRO (set on the base class).
    md: MetaData | None = None
    for klass in cls.__mro__:
        if "metadata" in klass.__dict__:
            md = klass.__dict__["metadata"]
            break
    if md is None:
        msg = (
            f"{cls.__name__}: base class must define "
            f"'metadata' before declaring model classes."
        )
        raise PGCraftValidationError(msg)

    schema, extra_constraints = _parse_table_args(cls)
    if schema is None:
        msg = (
            f"{cls.__name__} must specify a schema via "
            f"__table_args__ = {{'schema': '...'}} "
            f"or as the final dict in a tuple __table_args__."
        )
        raise PGCraftValidationError(msg)

    # Per-model plugin config — own dict only, no MRO inheritance.
    factory_cls = cls.__dict__.get("__factory__", PGCraftSimple)
    extra_plugins: list[Plugin] = list(cls.__dict__.get("__plugins__", []))
    config = getattr(cls, "pgcraft_config", None) or md.info.get(
        "pgcraft_config"
    )

    schema_items: list = [
        *_collect_columns(cls),
        *extra_constraints,
    ]

    internal = list(factory_cls._INTERNAL_PLUGINS)  # noqa: SLF001
    resolved = _resolve_plugins(config, None, extra_plugins, [], internal)
    _run_plugin_validators(resolved)

    ctx = FactoryContext(
        tablename=cls.__tablename__,
        schemaname=schema,
        metadata=md,
        schema_items=schema_items,
        plugins=resolved,
    )
    for p in _sort_plugins(resolved):
        p.run(ctx)

    if "__root__" not in ctx:
        msg = (
            f"{cls.__name__}: no plugin produced '__root__'. "
            f"Ensure the factory has a table-creating plugin."
        )
        raise PGCraftValidationError(msg)

    cls.__table__ = ctx["__root__"]
    registry.map_imperatively(cls, cls.__table__)

    # Expose ctx and table so that view factories (PostgRESTView,
    # construct_ledger_balance_query, ledger_event_function) that accept either
    # a ResourceFactory instance or a declarative class can access
    # them uniformly.
    cls.ctx = ctx
    cls.table = ctx["__root__"]

    # Register the dimension so that PGCraftForeignKey can resolve
    # references to this model by name (mirrors ResourceFactory.__init__).
    fk_target_key: str = factory_cls._FK_TARGET_KEY  # noqa: SLF001
    if fk_target_key in ctx:
        fk_table = ctx[fk_target_key]
        register_dimension(
            md,
            cls.__tablename__,
            DimensionRef(schema=schema, table=fk_table.name),
        )


class PGCraftViewMixin:
    """Mixin that marks a :class:`PGCraftBase` subclass as a SQL view.

    Combine with your project base to define views in the same class
    hierarchy as tables::

        class OrderStats(PGCraftViewMixin, Base):
            __tablename__ = "order_stats"
            __table_args__ = {"schema": "public"}
            __query__ = select(Orders.customer_id, func.count().label("n"))

    """


class PGCraftFunctionMixin:
    """Mixin marking a :class:`PGCraftBase` subclass as a PostgreSQL function.

    Combine with your project base to define functions alongside
    tables and views::

        class InventoryAdjust(PGCraftFunctionMixin, Base):
            __table_args__ = {"schema": "private"}
            __funcspec__ = ledger_event_function(Inventory, adjust_event)

    ``__funcspec__`` must be a
    :class:`~pgcraft.ext.ledger.functions.LedgerFunctionSpec` (returned by
    :func:`~pgcraft.ext.ledger.functions.ledger_event_function`).
    The schema is taken from ``__table_args__``, not from the spec.

    """


def _build_function_model(cls: type) -> None:
    """Register a declarative function on the class's metadata.

    Called from :meth:`PGCraftBase.__init_subclass__` for classes
    that include :class:`PGCraftFunctionMixin`.

    Args:
        cls: The function class being defined. Must declare
            ``__funcspec__`` (a
            :class:`~pgcraft.ext.ledger.functions.LedgerFunctionSpec`).

    Raises:
        PGCraftValidationError: On missing metadata or schema.

    """
    md: _SAMetaData | None = None
    for klass in cls.__mro__:
        if "metadata" in klass.__dict__:
            md = klass.__dict__["metadata"]
            break
    if md is None:
        msg = (
            f"{cls.__name__}: base class must define "
            f"'metadata' before declaring function classes."
        )
        raise PGCraftValidationError(msg)

    schema, _ = _parse_table_args(cls)
    if schema is None:
        msg = (
            f"{cls.__name__} must specify a schema via "
            f"__table_args__ = {{'schema': '...'}} "
            f"or as the final dict in a tuple __table_args__."
        )
        raise PGCraftValidationError(msg)

    spec: dict[str, Any] = cls.__dict__["__funcspec__"]
    fn = Function(
        spec["name"],
        spec["definition"],
        returns=spec.get("returns", "void"),
        language=spec.get("language", "sql"),
        schema=schema,
        parameters=spec.get("parameters", []),
        security=spec.get("security", FunctionSecurity.invoker),
        volatility=spec.get("volatility", FunctionVolatility.VOLATILE),
    )
    register_function(md, fn)
    cls.function = fn


class PGCraftBase:
    """Base class for declarative pgcraft models.

    Define a project-level base by subclassing.  Metadata is
    auto-created with pgcraft naming conventions if you don't
    provide it::

        class Base(PGCraftBase):
            pass  # Base.metadata created automatically

    Override ``metadata`` to use custom naming conventions::

        class Base(PGCraftBase):
            metadata = MetaData(naming_convention=...)

    Define tables and views in the same inheritance tree.  A class
    with ``__query__`` is treated as a view; without it, the pgcraft
    plugin pipeline runs and creates a table::

        class Locations(Base):
            __tablename__ = "locations"
            __table_args__ = {"schema": "public"}
            __plugins__ = [PostgRESTPlugin(grants=["select"])]

            name = Column(String, nullable=False)

        class LocationStats(Base):
            __tablename__ = "location_stats"
            __table_args__ = {"schema": "public"}
            __query__ = select(
                Locations.name,
                func.count().label("count"),
            ).group_by(Locations.name)

    When the class body executes the appropriate pipeline runs and
    the class is ORM-mapped so that ``select(LocationStats)`` works.

    **Base-level attributes** (set on your ``Base`` subclass):

    - ``metadata``: Optional.  Auto-created with pgcraft naming
      conventions if not provided.
    - ``pgcraft_config``: Optional ``PGCraftConfig``.  If omitted,
      falls back to ``metadata.info["pgcraft_config"]`` so you only
      need to set the config once.

    **Per-model attributes** (own class dict only, not inherited):

    - ``__factory__``: Factory class whose ``_INTERNAL_PLUGINS`` are
      used (default
      :class:`~pgcraft.factory.dimension.simple.PGCraftSimple`).
      Set to e.g. ``PGCraftAppendOnly`` for append-only semantics.
    - ``__plugins__``: List of plugin instances appended to the
      resolved plugin list.

    Intermediate classes without ``__tablename__`` are silently
    skipped, so shared column mixins work as expected.
    """

    pgcraft_config: ClassVar[object | None] = None

    # Set by _build_model after the plugin pipeline runs.
    id: ClassVar[Column]
    __table__: ClassVar[Table]
    table: ClassVar[Table]
    ctx: ClassVar[FactoryContext]
    # Set by __init_subclass__ on each direct subclass.
    _registry: ClassVar[SARegistry]
    metadata: ClassVar[_SAMetaData]

    def __init_subclass__(cls, **kwargs: Any) -> None:  # noqa: ANN401
        """Run the plugin pipeline when a model class is defined."""
        super().__init_subclass__(**kwargs)

        # Direct subclasses of PGCraftBase are base classes (e.g. the
        # user's ``Base``).  Give each its own ORM registry and
        # auto-create metadata if none was provided.
        if PGCraftBase in cls.__bases__:
            cls._registry = SARegistry()
            if "metadata" not in cls.__dict__:
                cls.metadata = _SAMetaData(
                    naming_convention=construct_pgcraft_naming_conventions_dict()
                )
            return

        # Functions are identified by PGCraftFunctionMixin — they don't
        # need __tablename__ so handle them before that check.
        if PGCraftFunctionMixin in cls.__mro__:
            _build_function_model(cls)
            return

        # Abstract intermediate classes have no __tablename__ — skip.
        if not hasattr(cls, "__tablename__"):
            return

        registry = _find_registry(cls)
        if PGCraftViewMixin in cls.__mro__:
            _build_view_model(cls, registry)
        else:
            _build_model(cls, registry)


def _build_view_model(cls: type, registry: SARegistry) -> None:
    """Register a declarative view and ORM-map *cls* to it.

    Called from :meth:`PGCraftBase.__init_subclass__` (and
    :meth:`PGCraftView.__init_subclass__` for backward compatibility)
    for classes that have both ``__tablename__`` and ``__query__``.

    Columns are taken from the class's own ``Column`` declarations if
    any are present (preferred — gives accurate types and makes intent
    explicit).  When no columns are declared the column list is derived
    automatically from ``__query__.selected_columns``.  In that case a
    surrogate primary key is chosen for the ORM mapper: the column
    named ``id`` if it exists, otherwise the first column.

    Args:
        cls: The view class being defined.
        registry: The SQLAlchemy ``registry`` to use for imperative
            mapping.

    Raises:
        PGCraftValidationError: On missing metadata, schema, or
            missing ``__query__``.

    """
    md: MetaData | None = None
    for klass in cls.__mro__:
        if "metadata" in klass.__dict__:
            md = klass.__dict__["metadata"]
            break
    if md is None:
        msg = (
            f"{cls.__name__}: base class must define "
            f"'metadata' before declaring view classes."
        )
        raise PGCraftValidationError(msg)

    schema, _ = _parse_table_args(cls)
    if schema is None:
        msg = (
            f"{cls.__name__} must specify a schema via "
            f"__table_args__ = {{'schema': '...'}} "
            f"or as the final dict in a tuple __table_args__."
        )
        raise PGCraftValidationError(msg)

    query: Select | None = getattr(cls, "__query__", None)
    if query is None:
        msg = f"{cls.__name__}: must define __query__ = select(...)."
        raise PGCraftValidationError(msg)

    options: ViewOptions = cls.__dict__.get("__options__", ViewOptions())

    # Columns: explicit declarations on the class take priority.
    # Fallback: infer names and types from the query's selected columns.
    explicit = _collect_columns(cls)
    if explicit:
        proxy_cols = explicit
    else:
        proxy_cols = [
            Column(c.key, getattr(c, "type", sa_types.NullType()))
            for c in query.selected_columns
            if c.key is not None
        ]

    # Proxy table on a private MetaData — Alembic sees only the view
    # DDL (registered below), not this table.
    tablename: str = cls.__tablename__
    proxy = Table(tablename, _SAMetaData(), *proxy_cols, schema=schema)

    # Register the view DDL on the main metadata for Alembic.
    register_view(
        md,
        View(
            tablename,
            compile_query(query),
            schema=schema,
            materialized=options.materialized,
        ),
    )

    cls.__table__ = proxy

    # SQLAlchemy requires at least one primary key column for ORM
    # mapping.  Views have no natural PK, so designate a surrogate
    # unless the user already marked one with primary_key=True.
    # Prefer a column named "id"; fall back to the first column.
    mapper_kwargs: dict[str, Any] = {}
    if not any(c.primary_key for c in proxy.c):
        pk_name = next(
            (c.name for c in proxy.c if c.name == "id"),
            next(iter(proxy.c), Column("")).name,
        )
        pk_col = proxy.c.get(pk_name)
        if pk_col is not None:
            mapper_kwargs["primary_key"] = [pk_col]

    registry.map_imperatively(cls, proxy, **mapper_kwargs)


class PGCraftView:
    """Base class for declarative pgcraft views.

    Define a project-level view base by subclassing and setting
    ``metadata`` to the same instance used by your model base.
    Views and tables must share metadata so that Alembic sees
    everything in one place::

        class ViewBase(PGCraftView):
            metadata = Base.metadata

    Then define view classes by inheriting from that base::

        # Columns inferred from the query (names and best-effort types).
        class CustomerStats(ViewBase):
            __tablename__ = "customer_order_stats"
            __table_args__ = {"schema": "public"}
            __query__ = (
                select(
                    orders.c.customer_id,
                    func.count().label("order_count"),
                    func.sum(orders.c.total).label("order_total"),
                )
                .group_by(orders.c.customer_id)
            )

        # Columns declared explicitly (accurate types, self-documenting).
        class InvoiceStats(ViewBase):
            __tablename__ = "customer_invoice_stats"
            __table_args__ = {"schema": "public"}

            customer_id = Column(Integer, nullable=False)
            invoice_count = Column(Integer)
            invoiced_total = Column(Numeric(10, 2))

            __query__ = (
                select(
                    invoices.c.customer_id,
                    func.count().label("invoice_count"),
                    func.sum(invoices.c.amount).label("invoiced_total"),
                )
                .group_by(invoices.c.customer_id)
            )

        # Materialized view.
        class ProductSummary(ViewBase):
            __tablename__ = "product_summary"
            __table_args__ = {"schema": "public"}
            __options__ = ViewOptions(materialized=True)
            __query__ = select(...)

    When the class body executes the view DDL is registered on the
    metadata for Alembic autogeneration, and the class is ORM-mapped
    so that ``select(CustomerStats)`` works.

    **Column resolution:**

    If the class declares ``Column`` attributes they are used as-is —
    this is the preferred form because it gives accurate types for the
    ORM mapper and is self-documenting.

    If no columns are declared the list is derived from
    ``__query__.selected_columns``.  Types are inherited from the
    source columns where possible (e.g. direct column references), but
    aggregates and expressions that lose type information are mapped as
    ``NullType``.  A surrogate primary key is chosen automatically:
    the column named ``id`` if present, otherwise the first column.

    **Per-view ``__options__``** (own class dict only):

    Set ``__options__ = ViewOptions(materialized=True)`` to create a
    PostgreSQL materialized view.

    Intermediate classes without ``__tablename__`` are silently
    skipped, so shared mixins work as expected.
    """

    # Set by _build_view_model after the view is registered.
    __table__: ClassVar[Table]
    ctx: ClassVar[FactoryContext]
    # Set by __init_subclass__ on each direct subclass.
    _registry: ClassVar[SARegistry]
    metadata: ClassVar[_SAMetaData]

    def __init_subclass__(cls, **kwargs: Any) -> None:  # noqa: ANN401
        """Register and ORM-map the view when the class is defined."""
        super().__init_subclass__(**kwargs)

        # Direct subclasses of PGCraftView are project-level bases
        # (e.g. the user's ``ViewBase``).  Give each its own registry.
        # metadata must be set explicitly — views belong to the same
        # schema as their source tables and must share metadata with
        # the model base so that Alembic sees everything in one place.
        if PGCraftView in cls.__bases__:
            cls._registry = SARegistry()
            return

        # Abstract intermediate classes have no __tablename__ — skip.
        if not hasattr(cls, "__tablename__"):
            return

        registry = _find_registry(cls)
        _build_view_model(cls, registry)
