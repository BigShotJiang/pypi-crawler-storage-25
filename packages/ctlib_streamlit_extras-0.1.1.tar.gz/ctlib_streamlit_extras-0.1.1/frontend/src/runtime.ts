type InteractionLockState = {
  kind: "interaction";
  ownerId: string;
  ownerType: "button" | "table";
  awaitingRerunFinish: boolean;
  sawRunningState: boolean;
  watcherId: number | null;
};

type InteractionController = {
  clearPending: () => void;
  isActive: () => boolean;
};

type RuntimeState = {
  buttonControllers: Map<string, InteractionController>;
  tableControllers: Map<string, InteractionController>;
  optimisticPendingButtons: Set<string>;
  optimisticPendingTables: Set<string>;
  interactionLockState: InteractionLockState | null;
  appElement: HTMLElement | null;
  appStateObserver: MutationObserver | null;
  appScriptState: string | null;
};

type CtlibRuntime = {
  state: RuntimeState;
};

const STATE_CHANGE_EVENT = "ctlib-button-state-change";
export const APP_SELECTOR = '[data-testid="stApp"]';
const APP_SCRIPT_STATE_ATTR = "data-test-script-state";
const RUNNING_SCRIPT_STATE = "running";
const FINISHED_SCRIPT_STATES = new Set(["notRunning"]);

declare global {
  interface Window {
    __ctlibStreamlitExtrasRuntime__?: CtlibRuntime;
  }
}

function createRuntime(): CtlibRuntime {
  return {
    state: {
      buttonControllers: new Map<string, InteractionController>(),
      tableControllers: new Map<string, InteractionController>(),
      optimisticPendingButtons: new Set<string>(),
      optimisticPendingTables: new Set<string>(),
      interactionLockState: null,
      appElement: null,
      appStateObserver: null,
      appScriptState: null,
    },
  };
}

function getRuntime(): CtlibRuntime {
  if (!window.__ctlibStreamlitExtrasRuntime__) {
    window.__ctlibStreamlitExtrasRuntime__ = createRuntime();
  }

  return window.__ctlibStreamlitExtrasRuntime__;
}

function getRuntimeState(): RuntimeState {
  return getRuntime().state;
}

function dispatchStateChange(): void {
  try {
    window.dispatchEvent(new CustomEvent(STATE_CHANGE_EVENT));
  } catch (error) {
    console.error("[ctlib-streamlit-extras] failed to dispatch state change", error);
  }
}

function stopGlobalLockWatcher(): void {
  const state = getRuntimeState();
  const lock = state.interactionLockState;
  if (lock?.watcherId != null) {
    window.clearInterval(lock.watcherId);
    lock.watcherId = null;
  }
}

function isRunningScriptState(state: string | null): boolean {
  return state === RUNNING_SCRIPT_STATE;
}

function isFinishedScriptState(state: string | null): boolean {
  return state !== null && FINISHED_SCRIPT_STATES.has(state);
}

function getAppElement(): HTMLElement {
  const appElement = document.querySelector<HTMLElement>(APP_SELECTOR);
  if (!appElement) {
    throw new Error(
      "ctlib-streamlit-extras could not find Streamlit's top-level stApp element.",
    );
  }
  return appElement;
}

function readAppScriptState(appElement: HTMLElement): string | null {
  return appElement.getAttribute(APP_SCRIPT_STATE_ATTR);
}

function clearButtonPending(buttonId: string): void {
  const state = getRuntimeState();
  const controller = state.buttonControllers.get(buttonId);
  if (controller) {
    controller.clearPending();
    return;
  }

  setButtonOptimisticPending(buttonId, false);
}

function clearTablePending(tableId: string): void {
  const state = getRuntimeState();
  const controller = state.tableControllers.get(tableId);
  if (controller) {
    controller.clearPending();
    return;
  }

  setTableOptimisticPending(tableId, false);
}

function clearInteractionPending(lock: InteractionLockState): void {
  if (lock.ownerType === "table") {
    clearTablePending(lock.ownerId);
    return;
  }
  clearButtonPending(lock.ownerId);
}

function getInteractionController(lock: InteractionLockState): InteractionController | undefined {
  const state = getRuntimeState();
  if (lock.ownerType === "table") {
    return state.tableControllers.get(lock.ownerId);
  }
  return state.buttonControllers.get(lock.ownerId);
}

function maybeReleaseInteractionLock(): void {
  const state = getRuntimeState();
  const lock = state.interactionLockState;
  if (!lock || !lock.awaitingRerunFinish) {
    return;
  }

  if (lock.sawRunningState && isFinishedScriptState(state.appScriptState)) {
    clearInteractionPending(lock);
    unlockGlobalLock();
  }
}

function handleAppStateMutations(mutations: MutationRecord[]): void {
  const state = getRuntimeState();
  const appElement = state.appElement;
  if (!appElement) {
    return;
  }

  const nextState = readAppScriptState(appElement);
  state.appScriptState = nextState;

  const lock = state.interactionLockState;
  if (!lock || !lock.awaitingRerunFinish) {
    return;
  }

  for (const mutation of mutations) {
    if (
      mutation.type === "attributes" &&
      mutation.attributeName === APP_SCRIPT_STATE_ATTR &&
      isRunningScriptState(mutation.oldValue)
    ) {
      lock.sawRunningState = true;
      break;
    }
  }

  if (isRunningScriptState(nextState)) {
    lock.sawRunningState = true;
  }

  maybeReleaseInteractionLock();
}

function ensureAppStateObserver(): void {
  const state = getRuntimeState();
  const appElement = getAppElement();

  if (state.appElement !== appElement) {
    state.appStateObserver?.disconnect();
    state.appStateObserver = null;
  }

  state.appElement = appElement;
  state.appScriptState = readAppScriptState(appElement);

  if (state.appStateObserver) {
    return;
  }

  state.appStateObserver = new MutationObserver((mutations) => {
    handleAppStateMutations(mutations);
  });
  state.appStateObserver.observe(appElement, {
    attributes: true,
    attributeFilter: [APP_SCRIPT_STATE_ATTR],
    attributeOldValue: true,
  });
}

export function unlockGlobalLock(): void {
  const state = getRuntimeState();
  if (!state.interactionLockState) {
    return;
  }

  stopGlobalLockWatcher();
  state.interactionLockState = null;
  dispatchStateChange();
}

export function getGlobalLock():
  | { kind: "interaction"; ownerId: string; ownerType: "button" | "table" }
  | null {
  const state = getRuntimeState();
  return state.interactionLockState
    ? {
        kind: state.interactionLockState.kind,
        ownerId: state.interactionLockState.ownerId,
        ownerType: state.interactionLockState.ownerType,
      }
    : null;
}

export function isGlobalLockActive(
  lock: { kind: "interaction"; ownerId: string; ownerType: "button" | "table" } | null,
): lock is { kind: "interaction"; ownerId: string; ownerType: "button" | "table" } {
  return Boolean(lock);
}

export function reconcileGlobalLock(): void {
  const state = getRuntimeState();
  if (!state.interactionLockState) {
    return;
  }

  ensureAppStateObserver();

  const lock = state.interactionLockState;
  const ownerController = getInteractionController(lock);
  if (!ownerController || !ownerController.isActive()) {
    clearInteractionPending(lock);
    unlockGlobalLock();
    return;
  }

  state.appScriptState = readAppScriptState(state.appElement ?? getAppElement());
  if (isRunningScriptState(state.appScriptState)) {
    state.interactionLockState.sawRunningState = true;
  }
  maybeReleaseInteractionLock();
}

function ensureGlobalLockWatcher(): void {
  const state = getRuntimeState();
  if (!state.interactionLockState || state.interactionLockState.watcherId !== null) {
    return;
  }

  // MutationObserver is the primary signal. The interval reconciles edge cases
  // where Streamlit replaces nodes or misses an observable attribute transition.
  state.interactionLockState.watcherId = window.setInterval(() => {
    reconcileGlobalLock();
  }, 100);
}

export function setGlobalLock(payload: {
  ownerId: string;
  ownerType: "button" | "table";
}): boolean {
  const state = getRuntimeState();
  ensureAppStateObserver();

  if (state.interactionLockState) {
    return false;
  }

  const currentScriptState = state.appScriptState;

  state.interactionLockState = {
    kind: "interaction",
    ownerId: payload.ownerId,
    ownerType: payload.ownerType,
    awaitingRerunFinish: true,
    sawRunningState: isRunningScriptState(currentScriptState),
    watcherId: null,
  };
  ensureGlobalLockWatcher();
  dispatchStateChange();
  return true;
}

export function registerButtonController(
  buttonId: string,
  controller: InteractionController,
): () => void {
  const state = getRuntimeState();
  state.buttonControllers.set(buttonId, controller);

  return () => {
    state.buttonControllers.delete(buttonId);
    state.optimisticPendingButtons.delete(buttonId);
    reconcileGlobalLock();
  };
}

export function registerTableController(
  tableId: string,
  controller: InteractionController,
): () => void {
  const state = getRuntimeState();
  state.tableControllers.set(tableId, controller);

  return () => {
    state.tableControllers.delete(tableId);
    state.optimisticPendingTables.delete(tableId);
    reconcileGlobalLock();
  };
}

export function setButtonOptimisticPending(buttonId: string, pending: boolean): void {
  const state = getRuntimeState();
  const hadPending = state.optimisticPendingButtons.has(buttonId);

  if (pending) {
    state.optimisticPendingButtons.add(buttonId);
  } else {
    state.optimisticPendingButtons.delete(buttonId);
  }

  if (hadPending !== pending) {
    dispatchStateChange();
  }
}

export function setTableOptimisticPending(tableId: string, pending: boolean): void {
  const state = getRuntimeState();
  const hadPending = state.optimisticPendingTables.has(tableId);

  if (pending) {
    state.optimisticPendingTables.add(tableId);
  } else {
    state.optimisticPendingTables.delete(tableId);
  }

  if (hadPending !== pending) {
    dispatchStateChange();
  }
}

export function isButtonOptimisticPending(buttonId: string | undefined): boolean {
  if (!buttonId) {
    return false;
  }
  return getRuntimeState().optimisticPendingButtons.has(buttonId);
}

export function isTableOptimisticPending(tableId: string | undefined): boolean {
  if (!tableId) {
    return false;
  }
  return getRuntimeState().optimisticPendingTables.has(tableId);
}

export function subscribeStateChanges(listener: () => void): () => void {
  window.addEventListener(STATE_CHANGE_EVENT, listener);
  return () => {
    window.removeEventListener(STATE_CHANGE_EVENT, listener);
  };
}
