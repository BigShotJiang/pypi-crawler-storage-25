import createCache, { EmotionCache } from "@emotion/cache";
import { CacheProvider } from "@emotion/react";
import {
  Button,
  Chip,
  Link as MuiLink,
  ThemeProvider,
  createTheme,
} from "@mui/material";
import {
  DataGrid,
  type GridColDef,
  type GridPaginationModel,
  type GridRenderCellParams,
  type GridSortModel,
} from "@mui/x-data-grid";
import React from "react";
import { createRoot, Root } from "react-dom/client";
import {
  APP_SELECTOR,
  getGlobalLock,
  isGlobalLockActive,
  isTableOptimisticPending,
  reconcileGlobalLock,
  registerTableController,
  setGlobalLock,
  setTableOptimisticPending,
  subscribeStateChanges,
} from "./runtime";
import "./table.css";

type ButtonType = "primary" | "secondary" | "tertiary";

type TableButton = {
  key: string;
  label: string;
  type?: ButtonType;
  icon?: string | null;
  disabled?: boolean;
};

type TableColumn = {
  field: string;
  headerName: string;
  type: "text" | "number" | "link" | "button_group" | "chip";
  help?: string | null;
  width?: number | null;
  sortable?: boolean;
  config?: Record<string, unknown>;
};

type TableRow = {
  __ctlib_row_id: string;
  __ctlib_row_position: number;
  __ctlib_row_index: unknown;
  [field: string]: unknown;
};

type LinkCellValue = {
  url?: unknown;
  href?: unknown;
  link?: unknown;
  label?: unknown;
  text?: unknown;
  title?: unknown;
  display?: unknown;
  target?: unknown;
};

type ComponentData = {
  component_id?: string;
  rows?: TableRow[];
  columns?: TableColumn[];
  page?: number;
  page_size?: number;
  page_size_options?: number[];
  row_count?: number;
  sort_column?: string | null;
  sort_direction?: "asc" | "desc" | null;
  height_mode?: "fixed" | "content";
  height?: number;
};

type ComponentApi = {
  data?: ComponentData;
  parentElement: HTMLElement | ShadowRoot;
  setTriggerValue: (name: string, value: unknown) => void;
};

type TableViewProps = {
  data: ComponentData;
  portalContainer: HTMLElement;
  onPageChange: (model: GridPaginationModel) => void;
  onSortChange: (model: GridSortModel) => void;
  onButtonClick: (payload: {
    column: string;
    button: string;
    rowPosition: number;
  }) => void;
  onInteractionStart: () => boolean;
};

const roots = new WeakMap<Element, Root>();
const emotionCaches = new WeakMap<Node, EmotionCache>();

function makeEventId(): string {
  const random =
    window.crypto?.getRandomValues !== undefined
      ? window.crypto.getRandomValues(new Uint32Array(1))[0].toString(36)
      : Math.random().toString(36).slice(2);
  return `${Date.now().toString(36)}_${random}`;
}

function getShadowRoot(parent: HTMLElement | ShadowRoot): ShadowRoot | null {
  return parent instanceof ShadowRoot ? parent : parent.shadowRoot;
}

function getEmotionCache(parent: HTMLElement | ShadowRoot): EmotionCache {
  const cacheOwner = getShadowRoot(parent) ?? document.head;
  const existing = emotionCaches.get(cacheOwner);
  if (existing) {
    return existing;
  }

  const shadowRoot = getShadowRoot(parent);
  let container: HTMLElement = document.head;
  if (shadowRoot) {
    const existingContainer = shadowRoot.querySelector<HTMLElement>(
      "[data-ctlib-table-emotion]",
    );
    if (existingContainer) {
      container = existingContainer;
    } else {
      container = document.createElement("div");
      container.dataset.ctlibTableEmotion = "1";
      shadowRoot.appendChild(container);
    }
  }

  const cache = createCache({
    key: "ctlib-table",
    container,
    prepend: true,
  });
  emotionCaches.set(cacheOwner, cache);
  return cache;
}

function isResolvedCssColor(value: string): boolean {
  const trimmed = value.trim();
  return Boolean(trimmed && !trimmed.startsWith("var(") && trimmed !== "transparent");
}

function getCssTargets(): [HTMLElement | null, HTMLElement, HTMLElement] {
  return [
    document.querySelector<HTMLElement>(APP_SELECTOR),
    document.body,
    document.documentElement,
  ];
}

function cssVar(name: string, fallback: string): string {
  const [appElement, body, root] = getCssTargets();
  for (const el of [appElement, body, root]) {
    if (!el) {
      continue;
    }
    const value = getComputedStyle(el).getPropertyValue(name).trim();
    if (value && !value.startsWith("var(")) {
      return value;
    }
  }
  return fallback;
}

function computedCssColor(
  property: "backgroundColor" | "color",
  fallback: string,
): string {
  const [appElement, body, root] = getCssTargets();
  for (const el of [appElement, body, root]) {
    if (!el) {
      continue;
    }
    const value = getComputedStyle(el)[property].trim();
    if (isResolvedCssColor(value)) {
      return value;
    }
  }
  return fallback;
}

function streamlitBackgroundColor(fallback: string): string {
  const variable = cssVar("--st-background-color", "");
  return isResolvedCssColor(variable) ? variable : computedCssColor("backgroundColor", fallback);
}

function streamlitTextColor(fallback: string): string {
  const variable = cssVar("--st-text-color", "");
  return isResolvedCssColor(variable) ? variable : computedCssColor("color", fallback);
}

function parseRgb(color: string): [number, number, number] | null {
  const match = color.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
  if (match) {
    return [Number(match[1]), Number(match[2]), Number(match[3])];
  }

  const hex = color.match(/^#([0-9a-f]{6})$/i);
  if (!hex) {
    return null;
  }

  const value = Number.parseInt(hex[1], 16);
  return [(value >> 16) & 255, (value >> 8) & 255, value & 255];
}

function streamlitColorMode(): "light" | "dark" {
  const background = streamlitBackgroundColor("#ffffff");
  const rgb = parseRgb(background);
  if (!rgb) {
    return window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }

  const [r, g, b] = rgb.map((channel) => {
    const scaled = channel / 255;
    return scaled <= 0.03928 ? scaled / 12.92 : ((scaled + 0.055) / 1.055) ** 2.4;
  });
  const luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  return luminance < 0.45 ? "dark" : "light";
}

function rgbCss(rgb: [number, number, number]): string {
  return `rgb(${Math.round(rgb[0])}, ${Math.round(rgb[1])}, ${Math.round(rgb[2])})`;
}

function mixRgb(
  base: [number, number, number],
  overlay: [number, number, number],
  overlayRatio: number,
): [number, number, number] {
  return [
    base[0] * (1 - overlayRatio) + overlay[0] * overlayRatio,
    base[1] * (1 - overlayRatio) + overlay[1] * overlayRatio,
    base[2] * (1 - overlayRatio) + overlay[2] * overlayRatio,
  ];
}

type StreamlitBaseColors = {
  mode: "light" | "dark";
  background: string;
  secondaryBackground: string;
  text: string;
  primary: string;
  border: string;
  font: string;
};

function computeStreamlitBaseColors(): StreamlitBaseColors {
  const mode = streamlitColorMode();
  return {
    mode,
    background: streamlitBackgroundColor(mode === "dark" ? "#0e1117" : "#ffffff"),
    secondaryBackground: cssVar(
      "--st-secondary-background-color",
      mode === "dark" ? "#262730" : "#f0f2f6",
    ),
    text: streamlitTextColor(mode === "dark" ? "#fafafa" : "#31333f"),
    primary: cssVar("--st-primary-color", "#ff4b4b"),
    border: cssVar(
      "--st-border-color",
      mode === "dark" ? "rgba(250, 250, 250, 0.2)" : "rgba(49, 51, 63, 0.2)",
    ),
    font: cssVar("--st-font", '"Source Sans Pro", sans-serif'),
  };
}

function createStreamlitTableColors(base: StreamlitBaseColors) {
  const { mode, background, secondaryBackground, text, primary, border } = base;

  const backgroundRgb =
    parseRgb(background) ??
    (mode === "dark"
      ? ([14, 17, 23] as [number, number, number])
      : ([255, 255, 255] as [number, number, number]));
  const textRgb =
    parseRgb(text) ??
    (mode === "dark"
      ? ([250, 250, 250] as [number, number, number])
      : ([49, 51, 63] as [number, number, number]));
  const secondaryRgb =
    parseRgb(secondaryBackground) ??
    (mode === "dark"
      ? ([38, 39, 48] as [number, number, number])
      : ([240, 242, 246] as [number, number, number]));
  const headerBase = mode === "dark" ? secondaryRgb : backgroundRgb;
  const headerBackground = rgbCss(mixRgb(headerBase, textRgb, mode === "dark" ? 0.1 : 0.065));
  const footerBackground = rgbCss(mixRgb(backgroundRgb, textRgb, mode === "dark" ? 0.045 : 0.025));
  const rowBorder = rgbCss(mixRgb(backgroundRgb, textRgb, mode === "dark" ? 0.14 : 0.1));
  const overlayBackground = `color-mix(in srgb, ${background} 68%, transparent)`;

  return {
    mode,
    background,
    secondaryBackground,
    text,
    primary,
    border,
    headerBackground,
    footerBackground,
    rowBorder,
    overlayBackground,
  };
}

function streamlitThemeSignature(): string {
  return [
    streamlitBackgroundColor(""),
    streamlitTextColor(""),
    cssVar("--st-background-color", ""),
    cssVar("--st-secondary-background-color", ""),
    cssVar("--st-text-color", ""),
    cssVar("--st-primary-color", ""),
    cssVar("--st-border-color", ""),
    cssVar("--st-font", ""),
  ].join("|");
}

function useStreamlitThemeSignature(): string {
  const [signature, setSignature] = React.useState(streamlitThemeSignature);

  React.useEffect(() => {
    let animationFrame: number | null = null;
    const update = (): void => {
      if (animationFrame !== null) {
        return;
      }
      animationFrame = window.requestAnimationFrame(() => {
        animationFrame = null;
        const nextSignature = streamlitThemeSignature();
        setSignature((currentSignature) =>
          currentSignature === nextSignature ? currentSignature : nextSignature,
        );
      });
    };

    const observer = new MutationObserver(update);
    observer.observe(document.documentElement, {
      attributes: true,
    });
    observer.observe(document.head, {
      childList: true,
      subtree: true,
    });
    const colorSchemeQuery = window.matchMedia?.("(prefers-color-scheme: dark)");
    colorSchemeQuery?.addEventListener("change", update);
    update();

    return () => {
      observer.disconnect();
      colorSchemeQuery?.removeEventListener("change", update);
      if (animationFrame !== null) {
        window.cancelAnimationFrame(animationFrame);
      }
    };
  }, []);

  return signature;
}

function createStreamlitTheme(base: StreamlitBaseColors) {
  const { mode, background, text, primary, border, font } = base;
  return createTheme({
    palette: {
      mode,
      primary: {
        main: primary,
      },
      background: {
        default: background,
        paper: background,
      },
      text: {
        primary: text,
      },
      divider: border,
    },
    typography: {
      fontFamily: font,
      fontSize: 14,
      button: {
        textTransform: "none",
        fontWeight: 600,
      },
    },
    shape: {
      borderRadius: 6,
    },
    components: {
      MuiButton: {
        styleOverrides: {
          root: {
            minHeight: 30,
            whiteSpace: "nowrap",
          },
        },
      },
      MuiChip: {
        styleOverrides: {
          root: {
            fontWeight: 600,
          },
        },
      },
    },
  });
}

function buttonVariant(type: ButtonType | undefined): "contained" | "outlined" | "text" {
  if (type === "primary") {
    return "contained";
  }
  if (type === "tertiary") {
    return "text";
  }
  return "outlined";
}

function parseIcon(icon: string | null | undefined): string | null {
  if (!icon) {
    return null;
  }
  if (icon.startsWith(":material/") && icon.endsWith(":")) {
    return icon.slice(10, -1);
  }
  return icon;
}

function isEmptyCell(value: unknown): value is null | undefined | "" {
  return value === null || value === undefined || value === "";
}

function renderTextCell(params: GridRenderCellParams<TableRow>, config: Record<string, unknown>) {
  const raw = params.value;
  if (raw === null || raw === undefined) {
    return "";
  }

  const value = String(raw);
  const maxChars = typeof config.max_chars === "number" ? config.max_chars : null;
  const display = maxChars && value.length > maxChars ? `${value.slice(0, maxChars)}...` : value;
  return (
    <span className={config.multiline ? "ctlib-table-text multiline" : "ctlib-table-text"}>
      {display}
    </span>
  );
}

const numberFormatCache = new Map<string, Intl.NumberFormat>();

function getNumberFormatter(precision: number | undefined): Intl.NumberFormat {
  const key = String(precision ?? "");
  let formatter = numberFormatCache.get(key);
  if (!formatter) {
    formatter = new Intl.NumberFormat(undefined, {
      minimumFractionDigits: precision,
      maximumFractionDigits: precision,
    });
    numberFormatCache.set(key, formatter);
  }
  return formatter;
}

function renderNumberCell(params: GridRenderCellParams<TableRow>, config: Record<string, unknown>) {
  if (isEmptyCell(params.value)) {
    return "";
  }

  const value = Number(params.value);
  if (Number.isNaN(value)) {
    return String(params.value);
  }

  const precision = typeof config.precision === "number" ? config.precision : undefined;
  const formatted = getNumberFormatter(precision).format(value);
  return `${typeof config.prefix === "string" ? config.prefix : ""}${formatted}${
    typeof config.suffix === "string" ? config.suffix : ""
  }`;
}

function renderLinkCell(params: GridRenderCellParams<TableRow>, config: Record<string, unknown>) {
  if (isEmptyCell(params.value)) {
    return "";
  }

  const raw = params.value;
  const linkValue =
    typeof raw === "object" && raw !== null && !Array.isArray(raw)
      ? (raw as LinkCellValue)
      : null;
  const rawHref = linkValue?.url ?? linkValue?.href ?? linkValue?.link ?? raw;
  if (rawHref === null || rawHref === undefined || rawHref === "") {
    return "";
  }

  const href = String(rawHref);
  const configuredText = typeof config.display_text === "string" ? config.display_text : null;
  const embeddedText = linkValue?.label ?? linkValue?.text ?? linkValue?.title ?? linkValue?.display;
  const text =
    embeddedText !== null && embeddedText !== undefined
      ? String(embeddedText)
      : configuredText && params.row[configuredText] !== undefined
      ? String(params.row[configuredText])
      : configuredText ?? href;
  const target =
    typeof linkValue?.target === "string"
      ? linkValue.target
      : typeof config.target === "string"
      ? config.target
      : "_blank";

  return (
    <MuiLink
      href={href}
      target={target}
      rel={target === "_blank" ? "noreferrer" : undefined}
      underline="hover"
      onClick={(event) => event.stopPropagation()}
    >
      {text}
    </MuiLink>
  );
}

function renderChipCell(params: GridRenderCellParams<TableRow>, config: Record<string, unknown>) {
  if (isEmptyCell(params.value)) {
    return "";
  }

  const value = String(params.value);
  const chips = (config.chips ?? {}) as Record<string, Record<string, unknown>>;
  const chip = chips[value] ?? {};
  return (
    <Chip
      label={typeof chip.label === "string" ? chip.label : value}
      size="small"
      color={typeof chip.color === "string" ? (chip.color as never) : "default"}
      variant={chip.variant === "outlined" ? "outlined" : "filled"}
    />
  );
}

function renderButtonGroupCell(
  params: GridRenderCellParams<TableRow>,
  column: TableColumn,
  onButtonClick: TableViewProps["onButtonClick"],
) {
  const config = column.config ?? {};
  const buttons = Array.isArray(config.buttons) ? (config.buttons as TableButton[]) : [];
  if (buttons.length === 0) {
    return "";
  }

  return (
    <div className="ctlib-table-button-list" onClick={(event) => event.stopPropagation()}>
      {buttons.map((button) => {
        const icon = parseIcon(button.icon);
        return (
          <Button
            key={button.key}
            variant={buttonVariant(button.type)}
            disabled={button.disabled}
            title={button.label}
            onClick={(event) => {
              event.preventDefault();
              event.stopPropagation();
              onButtonClick({
                column: column.field,
                button: button.key,
                rowPosition: params.row.__ctlib_row_position,
              });
            }}
          >
            {icon ? (
              <span className="ctlib-table-material-icon" aria-hidden="true">
                {icon}
              </span>
            ) : null}
            {button.label}
          </Button>
        );
      })}
    </div>
  );
}

function buildColumns(
  columns: TableColumn[],
  onButtonClick: TableViewProps["onButtonClick"],
): GridColDef<TableRow>[] {
  return columns.map((column): GridColDef<TableRow> => {
    const config = column.config ?? {};
    const base: GridColDef<TableRow> = {
      field: column.field,
      headerName: column.headerName,
      description: column.help ?? undefined,
      width: column.width ?? (column.type === "button_group" ? 180 : 150),
      minWidth: column.type === "button_group" ? 120 : 80,
      sortable: column.type !== "button_group" && column.sortable !== false,
      filterable: column.type !== "button_group",
      align: column.type === "number" ? "right" : "left",
      headerAlign: column.type === "number" ? "right" : "left",
    };

    if (column.type === "number") {
      return {
        ...base,
        renderCell: (params) => renderNumberCell(params, config),
      };
    }
    if (column.type === "link") {
      return {
        ...base,
        renderCell: (params) => renderLinkCell(params, config),
      };
    }
    if (column.type === "button_group") {
      return {
        ...base,
        renderCell: (params) => renderButtonGroupCell(params, column, onButtonClick),
      };
    }
    if (column.type === "chip") {
      return {
        ...base,
        renderCell: (params) => renderChipCell(params, config),
      };
    }
    return {
      ...base,
      flex: column.width ? undefined : 1,
      renderCell: (params) => renderTextCell(params, config),
    };
  });
}

function initialSortModel(data: ComponentData): GridSortModel {
  if (!data.sort_column || !data.sort_direction) {
    return [];
  }
  return [{ field: data.sort_column, sort: data.sort_direction }];
}

function TableView({
  data,
  portalContainer,
  onPageChange,
  onSortChange,
  onButtonClick,
  onInteractionStart,
}: TableViewProps): React.JSX.Element {
  const { component_id } = data;
  const rows = data.rows ?? [];
  const tableElementRef = React.useRef<HTMLDivElement | null>(null);
  const [, setStateVersion] = React.useState(0);
  const startInteraction = React.useCallback((): boolean => {
    if (!onInteractionStart()) {
      return false;
    }
    if (component_id) {
      setTableOptimisticPending(component_id, true);
    }
    return true;
  }, [component_id, onInteractionStart]);
  const handleButtonClick = React.useCallback(
    (payload: { column: string; button: string; rowPosition: number }) => {
      if (startInteraction()) {
        onButtonClick(payload);
      }
    },
    [onButtonClick, startInteraction],
  );
  const columns = React.useMemo(
    () => buildColumns(data.columns ?? [], handleButtonClick),
    [data.columns, handleButtonClick],
  );
  const paginationModel: GridPaginationModel = {
    page: Math.max(0, (data.page ?? 1) - 1),
    pageSize: data.page_size ?? 10,
  };
  const sortModel = React.useMemo(() => initialSortModel(data), [data.sort_column, data.sort_direction]);

  React.useEffect(() => {
    if (!component_id) {
      return;
    }

    return registerTableController(component_id, {
      clearPending: () => {
        setTableOptimisticPending(component_id, false);
      },
      isActive: () => Boolean(tableElementRef.current?.isConnected),
    });
  }, [component_id]);

  React.useEffect(() => {
    const onStateChange = (): void => {
      reconcileGlobalLock();
      setStateVersion((value) => value + 1);
    };
    return subscribeStateChanges(onStateChange);
  }, []);

  React.useEffect(() => {
    return () => {
      reconcileGlobalLock();
    };
  }, []);

  const themeSignature = useStreamlitThemeSignature();
  const baseColors = React.useMemo(() => computeStreamlitBaseColors(), [themeSignature]);
  const theme = React.useMemo(() => createStreamlitTheme(baseColors), [baseColors]);
  const tableColors = React.useMemo(() => createStreamlitTableColors(baseColors), [baseColors]);
  const heightMode = data.height_mode ?? "fixed";
  const rootStyle = {
    ...(heightMode === "fixed" ? { height: data.height ?? 420 } : {}),
    "--ct-table-background-color": tableColors.background,
    "--ct-table-secondary-background-color": tableColors.secondaryBackground,
    "--ct-table-header-background-color": tableColors.headerBackground,
    "--ct-table-footer-background-color": tableColors.footerBackground,
    "--ct-table-text-color": tableColors.text,
    "--ct-table-primary-color": tableColors.primary,
    "--ct-table-border-color": tableColors.border,
    "--ct-table-row-border-color": tableColors.rowBorder,
    "--ct-table-overlay-background-color": tableColors.overlayBackground,
    "--ct-table-font": baseColors.font,
  } as React.CSSProperties;
  const globalLock = getGlobalLock();
  const globalLockActive = isGlobalLockActive(globalLock);
  const effectivePending =
    isTableOptimisticPending(component_id) || globalLockActive;

  return (
    <ThemeProvider theme={theme}>
      <div
        ref={tableElementRef}
        className={`ctlib-table-root ${heightMode}`}
        style={rootStyle}
      >
        <DataGrid
          rows={rows}
          columns={columns}
          getRowId={(row) => row.__ctlib_row_id}
          autoHeight={heightMode === "content"}
          disableVirtualization={heightMode === "content"}
          pagination
          paginationMode="server"
          sortingMode="server"
          rowCount={data.row_count ?? rows.length}
          paginationModel={paginationModel}
          columnHeaderHeight={48}
          rowHeight={40}
          pageSizeOptions={data.page_size_options ?? [10, 25, 50, 100]}
          sortModel={sortModel}
          onPaginationModelChange={(model) => {
            const changed =
              model.page !== paginationModel.page || model.pageSize !== paginationModel.pageSize;
            if (changed && startInteraction()) {
              onPageChange(model);
            }
          }}
          onSortModelChange={(model) => {
            const nextSort = model[0];
            const currentSort = sortModel[0];
            const changed =
              nextSort?.field !== currentSort?.field || nextSort?.sort !== currentSort?.sort;
            if (changed && startInteraction()) {
              onSortChange(model);
            }
          }}
          disableRowSelectionOnClick
          density="standard"
          slotProps={{
            basePopper: {
              material: {
                container: portalContainer,
                sx: {
                  zIndex: 1500,
                },
              },
            },
            baseSelect: {
              material: {
                MenuProps: {
                  container: portalContainer,
                  disableScrollLock: true,
                  sx: {
                    zIndex: 1500,
                  },
                },
              },
            },
            basePagination: {
              material: {
                slotProps: {
                  select: {
                    MenuProps: {
                      container: portalContainer,
                      disableScrollLock: true,
                      sx: {
                        zIndex: 1500,
                      },
                    },
                  },
                },
              },
            },
            columnMenu: {
              slots: {
                columnMenuFilterItem: null,
              },
            },
          }}
          sx={{
            borderColor: "var(--ct-table-border-color)",
            borderRadius: 1,
            backgroundColor: "var(--ct-table-background-color)",
            color: "var(--ct-table-text-color)",
            fontFamily: "var(--ct-table-font)",
            "& .MuiDataGrid-columnHeaders": {
              backgroundColor: "var(--ct-table-header-background-color)",
              borderBottomColor: "var(--ct-table-border-color)",
            },
            "& .MuiDataGrid-columnHeader": {
              backgroundColor: "var(--ct-table-header-background-color)",
              borderTop: 0,
              borderLeft: 0,
              borderRight: 0,
              borderBottomColor: "var(--ct-table-border-color)",
              position: "relative",
            },
            "& .MuiDataGrid-footerContainer": {
              backgroundColor: "var(--ct-table-footer-background-color)",
              borderTopColor: "var(--ct-table-border-color)",
              minHeight: 52,
            },
            "& .MuiDataGrid-cell": {
              borderTop: 0,
              borderLeft: 0,
              borderRight: 0,
              borderBottom: "1px solid var(--ct-table-row-border-color)",
            },
            "& .MuiDataGrid-columnHeader:not(:last-of-type)::after": {
              backgroundColor: "var(--ct-table-border-color)",
              content: '""',
              height: "45%",
              position: "absolute",
              right: 0,
              top: "27.5%",
              width: "1px",
            },
            "& .MuiTablePagination-root": {
              color: "var(--ct-table-text-color)",
            },
            "& .MuiTablePagination-toolbar": {
              minHeight: 52,
            },
            "& .MuiDataGrid-row:last-of-type .MuiDataGrid-cell": {
              borderBottom: 0,
            },
            "& .MuiDataGrid-overlayWrapper": {
              backgroundColor: "var(--ct-table-background-color)",
            },
          }}
        />
        {effectivePending ? (
          <div className="ctlib-table-loading-overlay" aria-hidden="true">
            <span className="ctlib-table-spinner" />
          </div>
        ) : null}
      </div>
    </ThemeProvider>
  );
}

export default function render(component: ComponentApi): (() => void) | void {
  const host = component.parentElement;
  let mountNode = host.querySelector<HTMLElement>("[data-ctlib-table-root]");
  if (!mountNode) {
    mountNode = document.createElement("div");
    mountNode.dataset.ctlibTableRoot = "1";
    host.appendChild(mountNode);
  }

  let portalContainer = host.querySelector<HTMLElement>("[data-ctlib-table-portal]");
  if (!portalContainer) {
    portalContainer = document.createElement("div");
    portalContainer.dataset.ctlibTablePortal = "1";
    host.appendChild(portalContainer);
  }

  let root = roots.get(mountNode);
  if (!root) {
    root = createRoot(mountNode);
    roots.set(mountNode, root);
  }

  const data = component.data ?? {};
  const cache = getEmotionCache(host);

  root.render(
    <React.StrictMode>
      <CacheProvider value={cache}>
        <TableView
          data={data}
          portalContainer={portalContainer}
          onPageChange={(model) => {
            component.setTriggerValue("page_change", {
              event_id: makeEventId(),
              page: model.page + 1,
              page_size: model.pageSize,
            });
          }}
          onSortChange={(model) => {
            const sortItem = model[0];
            component.setTriggerValue("sort_change", {
              event_id: makeEventId(),
              column: sortItem?.field ?? null,
              direction: sortItem?.sort ?? null,
            });
          }}
          onButtonClick={(payload) => {
            component.setTriggerValue("button_click", {
              event_id: makeEventId(),
              column: payload.column,
              button: payload.button,
              row_position: payload.rowPosition,
            });
          }}
          onInteractionStart={() => {
            const componentId = data.component_id;
            if (!componentId) {
              return true;
            }
            return setGlobalLock({
              ownerId: componentId,
              ownerType: "table",
            });
          }}
        />
      </CacheProvider>
    </React.StrictMode>,
  );

  return () => {
    root.unmount();
    roots.delete(mountNode);
    mountNode.remove();
    portalContainer.remove();
  };
}
