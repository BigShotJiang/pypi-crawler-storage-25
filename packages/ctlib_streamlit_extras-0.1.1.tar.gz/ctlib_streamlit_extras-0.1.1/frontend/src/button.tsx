import React from "react";
import { createRoot, Root } from "react-dom/client";
import {
  getGlobalLock,
  isButtonOptimisticPending,
  isGlobalLockActive,
  reconcileGlobalLock,
  registerButtonController,
  setButtonOptimisticPending,
  setGlobalLock,
  subscribeStateChanges,
  unlockGlobalLock,
} from "./runtime";
import "./styles.css";

type ButtonType = "primary" | "secondary" | "tertiary";
type WidthMode = "content" | "stretch";
type ClickAction = "trigger" | "history_back";

type ComponentData = {
  label?: string;
  // Python always provides this for normal renders, but the frontend still treats
  // incoming component data as partially optional while mounting and testing.
  component_id?: string;
  help?: string | null;
  button_type?: ButtonType;
  icon?: string | null;
  disabled?: boolean;
  width?: WidthMode;
  click_action?: ClickAction;
};

type ComponentApi = {
  data?: ComponentData;
  parentElement: HTMLElement;
  setTriggerValue: (name: string, value: unknown) => void;
};

type ButtonProps = {
  data: ComponentData;
  onClick: () => void;
};

const roots = new WeakMap<HTMLElement, Root>();

function parseIcon(
  icon: string | null | undefined,
): { kind: "material" | "text"; value: string } | null {
  if (!icon) {
    return null;
  }
  if (icon.startsWith(":material/") && icon.endsWith(":")) {
    return { kind: "material", value: icon.slice(10, -1) };
  }
  return { kind: "text", value: icon };
}

function ButtonView({ data, onClick }: ButtonProps): React.JSX.Element {
  const {
    label = "Button",
    component_id,
    help = null,
    button_type = "secondary",
    icon = null,
    disabled = false,
    width = "content",
  } = data;
  const clickAction = data.click_action ?? "trigger";
  const isFrontendOnlyAction = clickAction === "history_back";

  const [optimisticPending, setOptimisticPending] = React.useState(false);
  const [, setStateVersion] = React.useState(0);
  const buttonElementRef = React.useRef<HTMLButtonElement | null>(null);

  React.useEffect(() => {
    if (isFrontendOnlyAction || !component_id) {
      return;
    }

    return registerButtonController(component_id, {
      clearPending: () => {
        setOptimisticPending(false);
        setButtonOptimisticPending(component_id, false);
      },
      isActive: () => Boolean(buttonElementRef.current?.isConnected),
    });
  }, [component_id, isFrontendOnlyAction]);

  React.useEffect(() => {
    if (isFrontendOnlyAction) {
      return;
    }

    const onStateChange = (): void => {
      reconcileGlobalLock();
      setStateVersion((value) => value + 1);
    };
    return subscribeStateChanges(onStateChange);
  }, [isFrontendOnlyAction]);

  React.useEffect(() => {
    if (isFrontendOnlyAction) {
      return;
    }

    return () => {
      reconcileGlobalLock();
    };
  }, [isFrontendOnlyAction]);

  const globalLock = getGlobalLock();
  const globalLockActive = isGlobalLockActive(globalLock);
  const sharedOptimisticPending = isButtonOptimisticPending(component_id);
  const effectivePending =
    !isFrontendOnlyAction &&
    (optimisticPending ||
      sharedOptimisticPending ||
      Boolean(globalLockActive && component_id && globalLock?.ownerId === component_id));
  const lockedByOtherInteraction = Boolean(
    !isFrontendOnlyAction &&
      globalLockActive &&
      (!component_id || globalLock?.ownerId !== component_id),
  );
  const effectiveDisabled = disabled || effectivePending || lockedByOtherInteraction;
  const parsedIcon = parseIcon(icon);

  function acquireInteractionLock(): boolean {
    if (!component_id) {
      return true;
    }
    return setGlobalLock({
      ownerId: component_id,
      ownerType: "button",
    });
  }

  function handleClick(): void {
    if (clickAction === "history_back") {
      window.history.back();
      return;
    }
    if (effectiveDisabled || !acquireInteractionLock()) {
      return;
    }
    setOptimisticPending(true);
    if (component_id) {
      setButtonOptimisticPending(component_id, true);
    }
    onClick();
  }

  const style = {
    "--ct-primary-color": "var(--st-primary-color)",
    "--ct-background-color": "var(--st-background-color)",
    "--ct-secondary-background-color": "var(--st-secondary-background-color)",
    "--ct-text-color": "var(--st-text-color)",
    "--ct-border-color": "var(--st-border-color, var(--st-secondary-background-color))",
    "--ct-radius": "var(--st-radius, 0.5rem)",
    "--ct-font": 'var(--st-font, "Source Sans Pro", sans-serif)',
  } as React.CSSProperties;

  return (
    <div className={`ctlib-root ${width === "stretch" ? "stretch" : "content"}`} style={style}>
      <button
        ref={buttonElementRef}
        type="button"
        className={`ctlib-button ${button_type}`}
        disabled={effectiveDisabled}
        title={help ?? ""}
        onClick={handleClick}
      >
        <span className="ctlib-content">
          {effectivePending ? (
            <span className="ctlib-spinner" aria-hidden="true" />
          ) : parsedIcon?.kind === "material" ? (
            <span className="ctlib-icon ctlib-material-icon" aria-hidden="true">
              {parsedIcon.value}
            </span>
          ) : parsedIcon?.kind === "text" ? (
            <span className="ctlib-icon" aria-hidden="true">{parsedIcon.value}</span>
          ) : null}
          <span>{label}</span>
        </span>
      </button>
    </div>
  );
}

export default function render(component: ComponentApi): (() => void) | void {
  const host = component.parentElement;
  let mountNode = host.querySelector<HTMLElement>("[data-ctlib-button-root]");
  if (!mountNode) {
    mountNode = document.createElement("div");
    mountNode.dataset.ctlibButtonRoot = "1";
    host.appendChild(mountNode);
  }

  let root = roots.get(mountNode);
  if (!root) {
    root = createRoot(mountNode);
    roots.set(mountNode, root);
  }

  const data = component.data ?? {};

  root.render(
    <React.StrictMode>
      <ButtonView
        data={data}
        onClick={() => {
          const eventId = Date.now();
          component.setTriggerValue("clicked", eventId);
        }}
      />
    </React.StrictMode>,
  );

  return () => {
    root.unmount();
    roots.delete(mountNode);
    mountNode.remove();
  };
}
