import path from "node:path";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

export default defineConfig({
  define: {
    "process.env.NODE_ENV": JSON.stringify("production"),
  },
  plugins: [react()],
  build: {
    outDir: path.resolve(__dirname, "../src/ctlib_streamlit_extras/frontend/dist"),
    emptyOutDir: false,
    lib: {
      entry: path.resolve(__dirname, "src/table.tsx"),
      formats: ["es"],
      fileName: () => "table.js",
    },
    rollupOptions: {
      output: {
        assetFileNames: (assetInfo) =>
          assetInfo.name?.endsWith(".css") ? "table.css" : "assets/[name]-[hash][extname]",
        inlineDynamicImports: true,
      },
    },
  },
});
