import { expect, Locator, Page, test } from "@playwright/test";

async function openRegressionPage(page: Page, route: string): Promise<void> {
  await page.goto(route);
}

async function expectRunCount(page: Page, label: string, count: number): Promise<void> {
  await expect(page.getByText(`${label} runs: ${count}`, { exact: true })).toBeVisible();
}

async function expectSingleButton(page: Page, name: string): Promise<Locator> {
  const button = page.getByRole("button", { name, exact: true });
  await expect(button).toHaveCount(1);
  return button;
}

async function expectSingleButtons(page: Page, names: string[]): Promise<Locator[]> {
  const buttons: Locator[] = [];
  for (const name of names) {
    buttons.push(await expectSingleButton(page, name));
  }
  return buttons;
}

async function expectButtonsEnabled(buttons: Locator[]): Promise<void> {
  for (const button of buttons) {
    await expect(button).toBeEnabled();
  }
}

async function expectButtonsDisabled(buttons: Locator[]): Promise<void> {
  for (const button of buttons) {
    await expect(button).toBeDisabled();
  }
}

async function leavePageDuringLoading(
  page: Page,
  options: {
    trigger: Locator;
    destinationName: string;
    leaveDelayMs?: number;
  },
): Promise<void> {
  await options.trigger.click();
  await page.waitForTimeout(options.leaveDelayMs ?? 50);
  await page.getByRole("link", { name: options.destinationName, exact: true }).click();
}

async function expectButtonsStateAfterRerun(
  page: Page,
  buttonNames: string[],
  disabledButtonNames: string[] = [],
): Promise<void> {
  await page.waitForTimeout(700);

  for (const name of buttonNames) {
    const button = await expectSingleButton(page, name);
    if (disabledButtonNames.includes(name)) {
      await expect(button).toBeDisabled();
    } else {
      await expect(button).toBeEnabled();
    }
  }
}

test("button holds the global lock until the full rerun completes", async ({ page }) => {
  await openRegressionPage(page, "/button_regression");

  const owner = page.getByRole("button", { name: "Button owner", exact: true });
  const peer = page.getByRole("button", { name: "Button peer", exact: true });
  const extraPeer = page.getByRole("button", { name: "Button extra peer", exact: true });

  await expectButtonsEnabled([owner, peer, extraPeer]);
  await owner.click();
  await expectButtonsDisabled([owner, peer, extraPeer]);
  await page.waitForTimeout(100);
  await expectButtonsDisabled([owner, peer, extraPeer]);
  await page.waitForTimeout(1100);
  await expectButtonsDisabled([owner, peer, extraPeer]);
  await expect(page.getByText("Tail marker: 0", { exact: true })).toBeVisible();
  await expect(page.getByText("Button owner completed #1", { exact: true })).toBeVisible();
  await expect(page.getByText("Tail marker: 1", { exact: true })).toBeVisible();
  await expect(page.getByText("Tail work finished", { exact: true })).toBeVisible();
  await expectButtonsStateAfterRerun(page, [
    "Button owner",
    "Button peer",
    "Button extra peer",
  ]);
});

test("button keeps backend-disabled peers disabled after the global lock releases", async ({
  page,
}) => {
  await openRegressionPage(page, "/button_regression");

  const owner = await expectSingleButton(page, "Button disable owner");
  const backendDisabledPeer = await expectSingleButton(page, "Button backend disabled peer");

  await expectButtonsEnabled([owner, backendDisabledPeer]);
  await owner.click();
  await expectButtonsDisabled([owner, backendDisabledPeer]);
  await expect(page.getByText("Button disable owner completed #1", { exact: true })).toBeVisible();
  await expectButtonsStateAfterRerun(
    page,
    ["Button disable owner", "Button backend disabled peer"],
    ["Button backend disabled peer"],
  );
  await expectRunCount(page, "Button disable owner", 1);
});

test("button clears stale loading after page switch and works again", async ({ page }) => {
  await openRegressionPage(page, "/button_regression");

  const owner = await expectSingleButton(page, "Button owner");
  const peer = await expectSingleButton(page, "Button peer");
  const extraPeer = await expectSingleButton(page, "Button extra peer");

  await leavePageDuringLoading(page, {
    trigger: owner,
    destinationName: "button",
  });
  await expect(page.getByRole("button", { name: "Generate", exact: true })).toBeVisible();

  await openRegressionPage(page, "/button_regression");
  const returnedButtons = await expectSingleButtons(page, [
    "Button owner",
    "Button peer",
    "Button extra peer",
  ]);
  const returnedOwner = returnedButtons[0];
  const returnedPeers = returnedButtons.slice(1);

  await expectButtonsEnabled([returnedOwner, ...returnedPeers]);
  await expectRunCount(page, "Button owner", 0);

  await returnedOwner.click();
  await page.waitForTimeout(100);
  await expectButtonsDisabled([returnedOwner, ...returnedPeers]);
  await expect(page.getByText("Button owner completed #1", { exact: true })).toBeVisible();
  await expectButtonsStateAfterRerun(page, [
    "Button owner",
    "Button peer",
    "Button extra peer",
  ]);
});

test("back button returns to the previous browser history entry", async ({ page }) => {
  await openRegressionPage(page, "/button");
  await expect(page.getByRole("button", { name: "Generate", exact: true })).toBeVisible();

  await openRegressionPage(page, "/back_button");
  await expect(page.getByRole("button", { name: "返回", exact: true })).toBeVisible();

  await page.getByRole("button", { name: "返回", exact: true }).click();
  await expect(page).toHaveURL(/\/button$/);
  await expect(page.getByRole("button", { name: "Generate", exact: true })).toBeVisible();
});

test("table and button interactions share one global lock", async ({
  page,
}) => {
  await openRegressionPage(page, "/table_regression");
  await expect(page.getByRole("heading", { name: "table regression" })).toBeVisible();
  await expect(page.locator(".ctlib-table-root")).toHaveCount(2);
  await expect(page.locator(".ctlib-table-loading-overlay")).toHaveCount(0);
  const regressionButton = page.getByRole("button", {
    name: "Table regression button",
    exact: true,
  });
  await expect(regressionButton).toBeEnabled();

  await page.locator(".ctlib-table-root").first().getByLabel("Go to next page").click();
  await expect(page.locator(".ctlib-table-loading-overlay")).toHaveCount(2);
  await expect(regressionButton).toBeDisabled();
  await expect(
    page.locator(".ctlib-table-root").nth(1).locator(".ctlib-table-loading-overlay"),
  ).toHaveCount(1);

  await expect(page.getByText("Owner page changes: 1", { exact: true })).toBeVisible();
  await expect(page.getByText("Peer page changes: 0", { exact: true })).toBeVisible();
  await expect(page.locator(".ctlib-table-loading-overlay")).toHaveCount(0);
  await expect(regressionButton).toBeEnabled();

  await regressionButton.click();
  await expect(regressionButton).toBeDisabled();
  await expect(page.locator(".ctlib-table-loading-overlay")).toHaveCount(2);
  await expect(page.getByText("Button actions: 1", { exact: true })).toBeVisible();
  await expect(page.locator(".ctlib-table-loading-overlay")).toHaveCount(0);
  await expect(regressionButton).toBeEnabled();
});
