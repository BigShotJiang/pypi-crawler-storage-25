# ctlib-streamlit-extras

React-based Streamlit custom components packaged as a reusable Python library.

Docs:

- [Framework](docs/framework.md)
- [App](docs/app.md)
- [Page State](docs/page_state.md)
- [Context](docs/context.md)
- [Middleware](docs/middleware.md)
- [Button](docs/button.md)
- [Back Button](docs/back_button.md)
- [Table](docs/table.md)

## Install

```bash
pip install ctlib-streamlit-extras
```

## Usage

See the docs for the current framework and button APIs:

- [Framework](docs/framework.md)
- [Button](docs/button.md)
- [Back Button](docs/back_button.md)
- [Table](docs/table.md)

## Examples

Run the multi-page Streamlit demo app:

```bash
poetry run streamlit run examples/Home.py
```

## Development

Install frontend dependencies and build the React bundle:

```bash
cd frontend
npm install
npm run build
```

Then install the package locally:

```bash
python -m pip install setuptools wheel
pip install -e .
```
