import streamlit as st

st.set_page_config(page_title="ctlib-streamlit-extras examples", layout="centered")

st.title("ctlib-streamlit-extras examples")
st.write("Use the sidebar to open a component example page.")

st.markdown(
    """
    Available pages:

    - `button`
    - `back_button`
    - `button_regression`
    - `table`
    - `table_regression`
    """
)
