import time
from collections.abc import Callable

import streamlit as st
from pydantic import Field

import ctlib_streamlit_extras as ste


class DemoContext(ste.PageState):
    label: str = "Shared context"


class CounterState(ste.PageState):
    counter: int = 0
    history: list[str] = Field(default_factory=list)


class CounterPage(ste.Page[CounterState]):
    title = "Counter"

    def render(self) -> None:
        context = ste.use_context(DemoContext)

        st.title(self.title)
        st.caption(context.label)
        st.write(
            "This page keeps state across reruns, but switching to another page clears it."
        )
        st.write("It can also jump to an internal page that is registered but hidden from navigation.")
        st.write(f"Counter: {self.state.counter}")

        if ste.button("Increment", key="counter_increment", type="primary"):
            self.state.counter += 1
            self.state.history.append(f"Incremented to {self.state.counter}")
            st.rerun()

        if ste.button("Open internal details", key="counter_details"):
            ste.current_app().switch_page("details")

        if self.state.history:
            st.write("History:")
            for item in self.state.history:
                st.write(f"- {item}")


class OtherPageState(ste.PageState):
    visits: int = 0


class OtherPage(ste.Page[OtherPageState]):
    title = "Other"

    def render(self) -> None:
        self.state.visits += 1
        st.title(self.title)
        st.write("Switch back to Counter and its state will be recreated.")
        st.write(f"Visits on this page during the current stay: {self.state.visits}")


class DetailsPage(ste.Page[ste.PageState]):
    title = "Details"
    visible = False

    def render(self) -> None:
        st.title(self.title)
        st.write("This page is registered in navigation, but hidden from the navigation UI.")
        st.write("It is meant for internal jumps such as drill-down or details flows.")

        if ste.button("Back to Counter", key="details_back", type="primary"):
            ste.current_app().switch_page("counter")


class CrashPage(ste.Page[ste.PageState]):
    title = "Crash"

    def render(self) -> None:
        st.title(self.title)
        st.write("Use this page to verify App(debug=False) error handling.")
        st.write("Click the button below to raise an exception during page execution.")

        if ste.button("Raise exception", key="crash_raise", type="primary"):
            raise RuntimeError("Intentional demo exception")
        st.info("Crash page finished")


class BannerMiddleware(ste.Middleware):
    def __init__(self, message: str):
        self.message = message

    def __call__(
        self,
        next_handler: Callable[[], None],
        route: ste.Route,
    ) -> Callable[[], None]:
        def wrapped() -> None:
            st.info(f"Middleware active for `{route.path}`")
            next_handler()

        return wrapped


def build_demo_app():
    app = ste.App()
    with ste.ContextProvider(DemoContext):
        with BannerMiddleware("demo"):
            app.register_page("counter", CounterPage, default=True)
            app.register_page("other", OtherPage)
            app.register_page("details", DetailsPage)
            app.register_page("crash", CrashPage)
    return app


build_demo_app().build_navigation().run()
