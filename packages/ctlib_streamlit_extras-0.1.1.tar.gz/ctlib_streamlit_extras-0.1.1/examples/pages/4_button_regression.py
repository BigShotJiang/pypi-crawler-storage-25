import time

import streamlit as st

import ctlib_streamlit_extras as ste


def increment_run_count(count_key: str) -> int:
    count = int(st.session_state.get(count_key, 0)) + 1
    st.session_state[count_key] = count
    return count


def render_run_count(label: str, count_key: str) -> None:
    st.caption(f"{label} runs: {int(st.session_state.get(count_key, 0))}")


if st.session_state.pop("button_regression_disable_owner_requested", False):
    time.sleep(2)
    count = increment_run_count("button_regression_disable_owner_runs")
    st.session_state["button_regression_backend_disabled"] = True
    st.success(f"Button disable owner completed #{count}")

st.title("button regression")
st.write("Regression scenarios for `ste.button(...)` global locking, stale cleanup, and disabled-state compatibility.")

st.subheader("Lock Waits For Full Rerun")
st.write("Buttons render before tail work starts. The global lock should stay active until the page finishes rerunning.")
render_run_count("Button owner", "button_regression_owner_runs")
render_run_count("Button peer", "button_regression_peer_runs")
render_run_count("Button extra peer", "button_regression_extra_peer_runs")

owner_clicked = ste.button(
    "Button owner",
    key="button_regression_owner",
    type="primary",
)
peer_clicked = ste.button(
    "Button peer",
    key="button_regression_peer",
)
extra_peer_clicked = ste.button(
    "Button extra peer",
    key="button_regression_extra_peer",
)

first_section_clicked = owner_clicked or peer_clicked or extra_peer_clicked

if owner_clicked:
    time.sleep(2)
    count = increment_run_count("button_regression_owner_runs")
    st.success(f"Button owner completed #{count}")

if peer_clicked:
    time.sleep(2)
    count = increment_run_count("button_regression_peer_runs")
    st.info(f"Button peer completed #{count}")

if extra_peer_clicked:
    time.sleep(2)
    count = increment_run_count("button_regression_extra_peer_runs")
    st.info(f"Button extra peer completed #{count}")

if first_section_clicked:
    time.sleep(1)
    st.session_state["button_regression_tail_marker"] = (
        int(st.session_state.get("button_regression_tail_marker", 0)) + 1
    )

st.caption(f"Tail marker: {int(st.session_state.get('button_regression_tail_marker', 0))}")
st.caption("Tail work finished")

st.divider()

st.subheader("Backend Disabled Peer")
st.write("A peer disabled by the backend must stay disabled after the global lock releases.")
render_run_count("Button disable owner", "button_regression_disable_owner_runs")

ste.button(
    "Button disable owner",
    key="button_regression_disable_owner",
    type="primary",
    on_click=lambda: st.session_state.__setitem__("button_regression_disable_owner_requested", True),
)
ste.button(
    "Button backend disabled peer",
    key="button_regression_backend_disabled_peer",
    disabled=bool(st.session_state.get("button_regression_backend_disabled", False)),
)
