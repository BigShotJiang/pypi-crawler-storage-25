import time

import streamlit as st

import ctlib_streamlit_extras as ste

st.title("button")
st.write("`ste.button(...)` is the plain button API. This example uses `on_click` to mark the click and then runs work above the button.")

if st.session_state.pop("button_example_clicked", False):
    time.sleep(3)
    st.success("Plain button finished")

ste.button(
    "Generate",
    type="primary",
    icon=":material/bolt:",
    on_click=lambda: st.session_state.__setitem__("button_example_clicked", True),
)
