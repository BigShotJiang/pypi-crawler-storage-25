import streamlit as st

import ctlib_streamlit_extras as ste

st.title("back_button")
st.write("`ste.back_button(...)` is a frontend-only browser history back button.")

ste.back_button(key="example_back_button", type="secondary")

st.info("Open this page from another example page, then click the return button.")
