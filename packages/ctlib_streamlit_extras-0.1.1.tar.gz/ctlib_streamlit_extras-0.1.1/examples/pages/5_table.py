import time
from typing import Any

import pandas as pd
import streamlit as st
from pydantic import BaseModel

import ctlib_streamlit_extras as ste

st.title("table")

PAGE_KEY = "table_demo_page"
PAGE_SIZE_KEY = "table_demo_page_size"
SORT_COLUMN_KEY = "table_demo_sort_column"
SORT_DIRECTION_KEY = "table_demo_sort_direction"

ALL_ORDERS: list[dict[str, Any]] = [
    {
        "order": "A-1001",
        "customer": "Ada",
        "amount": 128.5,
        "profile": ste.LinkValue("https://example.com/ada", "Ada profile"),
        "status": "paid",
    },
    {
        "order": "A-1002",
        "customer": "Grace",
        "amount": 86.25,
        "profile": {"url": "https://example.com/grace", "label": "Grace profile"},
        "status": "pending",
    },
    {
        "order": "A-1003",
        "customer": "Linus",
        "amount": 243.0,
        "profile": "https://example.com/linus",
        "status": "failed",
    },
    {
        "order": "A-1004",
        "customer": "Katherine",
        "amount": 310.75,
        "profile": ste.LinkValue("https://example.com/katherine", "Katherine profile"),
        "status": "paid",
    },
    {
        "order": "A-1005",
        "customer": "Margaret",
        "amount": 54.0,
        "profile": {"href": "https://example.com/margaret", "text": "Margaret profile"},
        "status": "pending",
    },
    {
        "order": "A-1006",
        "customer": "Donald",
        "amount": 191.2,
        "profile": "https://example.com/donald",
        "status": "paid",
    },
    {
        "order": "A-1007",
        "customer": "Barbara",
        "amount": 72.4,
        "profile": ste.LinkValue("https://example.com/barbara", "Barbara profile"),
        "status": "failed",
    },
    {
        "order": "A-1008",
        "customer": "Edsger",
        "amount": 455.9,
        "profile": {"link": "https://example.com/edsger", "title": "Edsger profile"},
        "status": "paid",
    },
    {
        "order": "A-1009",
        "customer": "Frances",
        "amount": 22.8,
        "profile": "https://example.com/frances",
        "status": "pending",
    },
    {
        "order": "A-1010",
        "customer": "Alan",
        "amount": 640.0,
        "profile": ste.LinkValue("https://example.com/alan", "Alan profile"),
        "status": "paid",
    },
    {
        "order": "A-1011",
        "customer": "Jean",
        "amount": 118.35,
        "profile": {"url": "https://example.com/jean", "display": "Jean profile"},
        "status": "failed",
    },
    {
        "order": "A-1012",
        "customer": "Mary",
        "amount": 268.1,
        "profile": "https://example.com/mary",
        "status": "pending",
    },
]


class OrderRow(BaseModel):
    order: str
    customer: str
    amount: float
    profile: Any
    status: str


def handle_page_change(page: int, page_size: int) -> None:
    previous_page_size = int(st.session_state.get(PAGE_SIZE_KEY, page_size))
    st.session_state[PAGE_KEY] = 1 if page_size != previous_page_size else page
    st.session_state[PAGE_SIZE_KEY] = page_size


def handle_sort_change(column: str | None, direction: str | None) -> None:
    st.session_state[SORT_COLUMN_KEY] = column
    st.session_state[SORT_DIRECTION_KEY] = direction
    st.session_state[PAGE_KEY] = 1


def select_row(row: dict[str, object]) -> None:
    time.sleep(1)
    st.session_state["table_example_selected"] = row


def base_column_config() -> dict[str, ste.Column]:
    return {
        "order": ste.TextColumn("Order", width="small"),
        "customer": ste.TextColumn("Customer"),
        "amount": ste.NumberColumn("Amount", precision=2, prefix="$", width="small"),
        "profile": ste.LinkColumn("Profile", target="_self", sortable=False),
        "status": ste.ChipColumn(
            "Status",
            width="small",
            chips={
                "paid": {"label": "Paid", "color": "success"},
                "pending": {"label": "Pending", "color": "warning", "variant": "outlined"},
                "failed": {"label": "Failed", "color": "error"},
            },
        ),
    }


def action_column() -> ste.ButtonGroupColumn:
    return ste.ButtonGroupColumn(
        "Actions",
        width=300,
        buttons=[
            ste.TableButton("Select", key="select", type="primary", on_click=select_row),
            ste.TableButton("Details", type="secondary", on_click=select_row),
            ste.TableButton("Archive", type="tertiary", on_click=select_row),
        ],
    )


def sorted_orders(
    rows: list[dict[str, Any]],
    column: str | None,
    direction: str | None,
) -> list[dict[str, Any]]:
    if column is None or direction not in {"asc", "desc"}:
        return rows
    if column not in {"order", "customer", "amount", "status"}:
        return rows

    return sorted(
        rows,
        key=lambda row: row[column],
        reverse=direction == "desc",
    )


current_page = int(st.session_state.get(PAGE_KEY, 1))
current_page_size = int(st.session_state.get(PAGE_SIZE_KEY, 5))
current_sort_column = st.session_state.get(SORT_COLUMN_KEY)
current_sort_direction = st.session_state.get(SORT_DIRECTION_KEY)

ordered_rows = sorted_orders(ALL_ORDERS, current_sort_column, current_sort_direction)
total_rows = len(ordered_rows)
page_count = max(1, (total_rows + current_page_size - 1) // current_page_size)
current_page = min(max(current_page, 1), page_count)
st.session_state[PAGE_KEY] = current_page

start = (current_page - 1) * current_page_size
end = start + current_page_size
visible_orders = ordered_rows[start:end]

orders_dataframe = pd.DataFrame(visible_orders)
orders_dict_rows = ALL_ORDERS[:4]
orders_model_rows = [OrderRow.model_validate(row) for row in ALL_ORDERS[4:8]]

st.subheader("DataFrame")
st.caption("服务端分页和排序，传入 `pandas.DataFrame`。")

table_state = ste.table(
    orders_dataframe,
    key="orders_demo",
    column_order=["order", "customer", "amount", "status", "profile", "actions"],
    column_config={**base_column_config(), "actions": action_column()},
    page=current_page,
    page_size=current_page_size,
    page_size_options=[5, 10, 20],
    total_rows=total_rows,
    sort_column=current_sort_column,
    sort_direction=current_sort_direction,
    on_page_change=handle_page_change,
    on_sort_change=handle_sort_change,
    height="content",
    width="stretch",
)

if table_state.page_event is not None or table_state.sort_event is not None:
    st.rerun()

st.caption(
    f"Showing rows {start + 1}-{min(end, total_rows)} of {total_rows}; "
    f"page={current_page}, page_size={current_page_size}, "
    f"sort={current_sort_column}, direction={current_sort_direction}"
)

st.subheader("list[dict]")
st.caption("直接传入 `list[dict]`，适合已经在后端拿到结构化记录的场景。")

ste.table(
    orders_dict_rows,
    key="orders_demo_dict",
    column_order=["order", "customer", "amount", "status", "profile", "actions"],
    column_config={**base_column_config(), "actions": action_column()},
    page_size=4,
    height="content",
    width="stretch",
)

st.subheader("list[pydantic.BaseModel]")
st.caption("直接传入 `list[BaseModel]`，适合已有领域模型对象的场景。")

ste.table(
    orders_model_rows,
    key="orders_demo_model",
    column_order=["order", "customer", "amount", "status", "profile", "actions"],
    column_config={**base_column_config(), "actions": action_column()},
    page_size=4,
    height="content",
    width="stretch",
)

if "table_example_selected" in st.session_state:
    st.write("Selected row", st.session_state["table_example_selected"])
