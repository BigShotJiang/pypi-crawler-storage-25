import time

import pandas as pd
import streamlit as st

import ctlib_streamlit_extras as ste

OWNER_PAGE_KEY = "table_regression_owner_page"
PEER_PAGE_KEY = "table_regression_peer_page"
OWNER_RUNS_KEY = "table_regression_owner_runs"
PEER_RUNS_KEY = "table_regression_peer_runs"
BUTTON_REQUEST_KEY = "table_regression_button_requested"
BUTTON_RUNS_KEY = "table_regression_button_runs"


def handle_owner_page_change(page: int, page_size: int) -> None:
    time.sleep(3)
    st.session_state[OWNER_PAGE_KEY] = page
    st.session_state[OWNER_RUNS_KEY] = int(st.session_state.get(OWNER_RUNS_KEY, 0)) + 1


def handle_peer_page_change(page: int, page_size: int) -> None:
    st.session_state[PEER_PAGE_KEY] = page
    st.session_state[PEER_RUNS_KEY] = int(st.session_state.get(PEER_RUNS_KEY, 0)) + 1


def page_rows(label: str, page: int) -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "name": f"{label} row {page}",
                "page": page,
            }
        ]
    )


if st.session_state.pop(BUTTON_REQUEST_KEY, False):
    time.sleep(3)
    st.session_state[BUTTON_RUNS_KEY] = int(st.session_state.get(BUTTON_RUNS_KEY, 0)) + 1
    st.success("Button action completed")

st.title("table regression")
st.write("Regression scenarios for `ste.table(...)` and `ste.button(...)` global locking.")

owner_page = int(st.session_state.get(OWNER_PAGE_KEY, 1))
peer_page = int(st.session_state.get(PEER_PAGE_KEY, 1))

ste.button(
    "Table regression button",
    key="table_regression_button",
    type="primary",
    on_click=lambda: st.session_state.__setitem__(BUTTON_REQUEST_KEY, True),
)

st.subheader("Owner table")
owner_state = ste.table(
    page_rows("Owner", owner_page),
    key="table_regression_owner",
    column_config={
        "name": ste.TextColumn("Name"),
        "page": ste.NumberColumn("Page", width="small"),
    },
    page=owner_page,
    page_size=1,
    page_size_options=[1],
    total_rows=3,
    on_page_change=handle_owner_page_change,
    height=260,
)

st.subheader("Peer table")
peer_state = ste.table(
    page_rows("Peer", peer_page),
    key="table_regression_peer",
    column_config={
        "name": ste.TextColumn("Name"),
        "page": ste.NumberColumn("Page", width="small"),
    },
    page=peer_page,
    page_size=1,
    page_size_options=[1],
    total_rows=3,
    on_page_change=handle_peer_page_change,
    height=260,
)

if owner_state.page_event is not None or peer_state.page_event is not None:
    st.rerun()

st.caption(f"Owner page changes: {int(st.session_state.get(OWNER_RUNS_KEY, 0))}")
st.caption(f"Peer page changes: {int(st.session_state.get(PEER_RUNS_KEY, 0))}")
st.caption(f"Button actions: {int(st.session_state.get(BUTTON_RUNS_KEY, 0))}")
