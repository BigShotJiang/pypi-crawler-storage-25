import unittest
from decimal import Decimal
from types import SimpleNamespace
from unittest.mock import Mock, patch

import pandas as pd
from pydantic import BaseModel

import ctlib_streamlit_extras as ste


def component_result(**kwargs):
    return SimpleNamespace(
        page_change=kwargs.get("page_change"),
        sort_change=kwargs.get("sort_change"),
        button_click=kwargs.get("button_click"),
    )


class OrderRow(BaseModel):
    name: str
    amount: int
    status: str | None = None


class TableApiTests(unittest.TestCase):
    def test_table_is_exported(self) -> None:
        self.assertTrue(callable(ste.table))
        self.assertEqual(ste.Column(label="Name").label, "Name")
        self.assertEqual(ste.TextColumn(label="Name").label, "Name")
        self.assertEqual(ste.NumberColumn(precision=2).precision, 2)
        self.assertEqual(ste.LinkColumn(target="_self").target, "_self")
        self.assertEqual(ste.LinkValue("https://example.com", "Example").label, "Example")
        self.assertIsInstance(ste.ButtonGroupColumn(), ste.ButtonGroupColumn)
        self.assertIsInstance(ste.ChipColumn(), ste.ChipColumn)

    def test_table_serializes_dataframe_and_column_config(self) -> None:
        frame = pd.DataFrame(
            {
                "name": ["Ada"],
                "amount": [12.345],
                "profile": [ste.LinkValue("https://example.com/ada", "Ada profile")],
                "details": [{"href": "https://example.com/details/ada", "text": "Details"}],
                "status": ["active"],
            }
        )

        with (
            patch("ctlib_streamlit_extras.table.st.session_state", {}),
            patch(
                "ctlib_streamlit_extras.table._table_component",
                return_value=component_result(),
            ) as component,
        ):
            state = ste.table(
                frame,
                key="orders",
                column_order=["name", "amount", "profile", "details", "status", "actions"],
                column_config={
                    "name": ste.TextColumn(label="Customer", max_chars=10),
                    "amount": ste.NumberColumn(label="Total", precision=2, prefix="$"),
                    "profile": ste.LinkColumn(
                        label="Profile",
                        target="_self",
                        sortable=False,
                    ),
                    "details": ste.LinkColumn(label="Details"),
                    "status": ste.ChipColumn(
                        label="Status",
                        chips={"active": {"label": "Active", "color": "success"}},
                    ),
                    "actions": ste.ButtonGroupColumn(
                        label="Actions",
                        buttons=[ste.TableButton("Open", key="open")],
                    ),
                },
                page_size=25,
                height=360,
            )

        self.assertEqual(state.page, 1)
        self.assertEqual(state.page_size, 25)
        component.assert_called_once()
        _, kwargs = component.call_args
        self.assertEqual(kwargs["key"], "orders")
        self.assertEqual(kwargs["height"], 360)
        self.assertEqual(kwargs["data"]["height_mode"], "fixed")
        self.assertEqual(kwargs["data"]["height"], 360)
        self.assertEqual(kwargs["data"]["row_count"], 1)
        self.assertEqual(
            kwargs["data"]["rows"],
            [
                {
                    "__ctlib_row_id": "0",
                    "__ctlib_row_position": 0,
                    "__ctlib_row_index": 0,
                    "name": "Ada",
                    "amount": 12.345,
                    "profile": {
                        "url": "https://example.com/ada",
                        "label": "Ada profile",
                        "target": None,
                    },
                    "details": {
                        "href": "https://example.com/details/ada",
                        "text": "Details",
                    },
                    "status": "active",
                }
            ],
        )
        self.assertEqual(
            [column["field"] for column in kwargs["data"]["columns"]],
            ["name", "amount", "profile", "details", "status", "actions"],
        )
        self.assertEqual(kwargs["data"]["columns"][1]["type"], "number")
        self.assertEqual(kwargs["data"]["columns"][2]["config"]["target"], "_self")
        self.assertFalse(kwargs["data"]["columns"][2]["sortable"])
        self.assertEqual(
            kwargs["data"]["columns"][4]["config"]["chips"]["active"]["color"],
            "success",
        )
        self.assertEqual(kwargs["data"]["columns"][5]["config"]["buttons"][0]["key"], "open")
        self.assertFalse(kwargs["data"]["columns"][5]["sortable"])
        self.assertEqual(kwargs["data"]["page_size_options"], [10, 25, 50, 100])
        self.assertTrue(callable(kwargs["on_page_change_change"]))
        self.assertTrue(callable(kwargs["on_sort_change_change"]))
        self.assertTrue(callable(kwargs["on_button_click_change"]))

    def test_table_serializes_list_of_dicts(self) -> None:
        rows = [
            {"name": "Ada", "amount": Decimal("12.5")},
            {"name": "Grace", "status": "pending"},
        ]

        with (
            patch("ctlib_streamlit_extras.table.st.session_state", {}),
            patch(
                "ctlib_streamlit_extras.table._table_component",
                return_value=component_result(),
            ) as component,
        ):
            ste.table(rows, key="orders")

        _, kwargs = component.call_args
        self.assertEqual(
            kwargs["data"]["rows"],
            [
                {
                    "__ctlib_row_id": "0",
                    "__ctlib_row_position": 0,
                    "__ctlib_row_index": 0,
                    "name": "Ada",
                    "amount": 12.5,
                    "status": None,
                },
                {
                    "__ctlib_row_id": "1",
                    "__ctlib_row_position": 1,
                    "__ctlib_row_index": 1,
                    "name": "Grace",
                    "amount": None,
                    "status": "pending",
                },
            ],
        )
        self.assertEqual(
            [column["field"] for column in kwargs["data"]["columns"]],
            ["name", "amount", "status"],
        )

    def test_table_serializes_list_of_pydantic_models(self) -> None:
        rows = [
            OrderRow(name="Ada", amount=12, status="active"),
            OrderRow(name="Grace", amount=34),
        ]

        with (
            patch("ctlib_streamlit_extras.table.st.session_state", {}),
            patch(
                "ctlib_streamlit_extras.table._table_component",
                return_value=component_result(),
            ) as component,
        ):
            ste.table(rows, key="orders")

        _, kwargs = component.call_args
        self.assertEqual(
            kwargs["data"]["rows"],
            [
                {
                    "__ctlib_row_id": "0",
                    "__ctlib_row_position": 0,
                    "__ctlib_row_index": 0,
                    "name": "Ada",
                    "amount": 12,
                    "status": "active",
                },
                {
                    "__ctlib_row_id": "1",
                    "__ctlib_row_position": 1,
                    "__ctlib_row_index": 1,
                    "name": "Grace",
                    "amount": 34,
                    "status": None,
                },
            ],
        )

    def test_table_auto_generates_positional_button_keys(self) -> None:
        with (
            patch("ctlib_streamlit_extras.table.st.session_state", {}),
            patch(
                "ctlib_streamlit_extras.table._table_component",
                return_value=component_result(),
            ) as component,
        ):
            ste.table(
                pd.DataFrame({"name": ["Ada"]}),
                key="orders",
                column_order=["name", "actions"],
                column_config={
                    "actions": ste.ButtonGroupColumn(
                        buttons=[
                            ste.TableButton("Open"),
                            ste.TableButton("Open!"),
                            ste.TableButton(""),
                        ],
                    )
                },
            )

        _, kwargs = component.call_args
        buttons = kwargs["data"]["columns"][1]["config"]["buttons"]
        self.assertEqual([button["key"] for button in buttons], ["open_0", "open_1", "button_2"])

    def test_table_dispatches_duplicate_label_button_by_positional_key(self) -> None:
        on_first = Mock()
        on_second = Mock()
        frame = pd.DataFrame({"name": ["Ada"]})

        with (
            patch("ctlib_streamlit_extras.table.st.session_state", {}),
            patch(
                "ctlib_streamlit_extras.table._table_component",
                return_value=component_result(
                    button_click={
                        "event_id": "button-1",
                        "column": "actions",
                        "button": "open_1",
                        "row_position": 0,
                    }
                ),
            ),
        ):
            state = ste.table(
                frame,
                key="orders",
                column_order=["name", "actions"],
                column_config={
                    "actions": ste.ButtonGroupColumn(
                        buttons=[
                            ste.TableButton("Open", on_click=on_first),
                            ste.TableButton("Open!", on_click=on_second),
                        ],
                    )
                },
            )

        on_first.assert_not_called()
        on_second.assert_called_once_with({"name": "Ada"})
        self.assertEqual(state.button_event.button, "open_1")

    def test_table_rejects_duplicate_explicit_button_keys(self) -> None:
        with (
            patch("ctlib_streamlit_extras.table.st.session_state", {}),
            patch(
                "ctlib_streamlit_extras.table._table_component",
                return_value=component_result(),
            ),
        ):
            with self.assertRaisesRegex(ValueError, "duplicate button key 'same'"):
                ste.table(
                    pd.DataFrame({"name": ["Ada"]}),
                    key="orders",
                    column_order=["name", "actions"],
                    column_config={
                        "actions": ste.ButtonGroupColumn(
                            buttons=[
                                ste.TableButton("Open", key="same"),
                                ste.TableButton("Close", key="same"),
                            ],
                        )
                    },
                )

    def test_table_resolves_chip_keys_with_chip_func(self) -> None:
        frame = pd.DataFrame(
            {
                "status": ["paid"],
                "amount": [Decimal("0.000001")],
            }
        )

        with (
            patch("ctlib_streamlit_extras.table.st.session_state", {}),
            patch(
                "ctlib_streamlit_extras.table._table_component",
                return_value=component_result(),
            ) as component,
        ):
            ste.table(
                frame,
                key="chips",
                column_config={
                    "status": ste.ChipColumn(chips={"paid": "Paid"}),
                    "amount": ste.ChipColumn(
                        chips={"tiny": {"label": "Tiny", "color": "info"}},
                        chip_func=lambda value: "tiny" if value == Decimal("0.000001") else "large",
                    ),
                },
            )

        _, kwargs = component.call_args
        columns = {column["field"]: column for column in kwargs["data"]["columns"]}
        self.assertEqual(kwargs["data"]["rows"][0]["status"], "paid")
        self.assertEqual(kwargs["data"]["rows"][0]["amount"], "tiny")
        self.assertEqual(columns["amount"]["config"]["chips"]["tiny"]["label"], "Tiny")

    def test_table_rejects_unknown_chip_key(self) -> None:
        with (
            patch("ctlib_streamlit_extras.table.st.session_state", {}),
            patch(
                "ctlib_streamlit_extras.table._table_component",
                return_value=component_result(),
            ),
        ):
            with self.assertRaisesRegex(ValueError, "unknown chip key 'missing'"):
                ste.table(
                    pd.DataFrame({"status": ["paid"]}),
                    key="chips",
                    column_config={
                        "status": ste.ChipColumn(
                            chips={"paid": "Paid"},
                            chip_func=lambda value: "missing",
                        ),
                    },
                )

    def test_table_rejects_non_string_chip_key_result(self) -> None:
        with (
            patch("ctlib_streamlit_extras.table.st.session_state", {}),
            patch(
                "ctlib_streamlit_extras.table._table_component",
                return_value=component_result(),
            ),
        ):
            with self.assertRaisesRegex(TypeError, "chip_func must return a string"):
                ste.table(
                    pd.DataFrame({"status": ["paid"]}),
                    key="chips",
                    column_config={
                        "status": ste.ChipColumn(
                            chips={"paid": "Paid"},
                            chip_func=lambda value: 1,
                        ),
                    },
                )

    def test_table_rejects_non_string_chip_config_key(self) -> None:
        with (
            patch("ctlib_streamlit_extras.table.st.session_state", {}),
            patch(
                "ctlib_streamlit_extras.table._table_component",
                return_value=component_result(),
            ),
        ):
            with self.assertRaisesRegex(TypeError, "chips keys must be strings"):
                ste.table(
                    pd.DataFrame({"status": ["paid"]}),
                    key="chips",
                    column_config={
                        "status": ste.ChipColumn(chips={1: "One"}),
                    },
                )

    def test_table_supports_content_height(self) -> None:
        with (
            patch("ctlib_streamlit_extras.table.st.session_state", {}),
            patch(
                "ctlib_streamlit_extras.table._table_component",
                return_value=component_result(),
            ) as component,
        ):
            ste.table(pd.DataFrame({"name": ["Ada"]}), key="orders", height="content")

        _, kwargs = component.call_args
        self.assertEqual(kwargs["height"], "content")
        self.assertEqual(kwargs["data"]["height_mode"], "content")
        self.assertIsNone(kwargs["data"]["height"])

    def test_table_dispatches_page_change_callback_once(self) -> None:
        on_page_change = Mock()
        session_state = {}

        with (
            patch("ctlib_streamlit_extras.table.st.session_state", session_state),
            patch(
                "ctlib_streamlit_extras.table._table_component",
                return_value=component_result(
                    page_change={
                        "event_id": "page-1",
                        "page": 2,
                        "page_size": 25,
                    }
                ),
            ),
        ):
            state = ste.table(
                pd.DataFrame({"name": list("abcdef")}),
                key="orders",
                page_size=10,
                on_page_change=on_page_change,
            )
            repeated = ste.table(
                pd.DataFrame({"name": list("abcdef")}),
                key="orders",
                page_size=10,
                on_page_change=on_page_change,
            )

        on_page_change.assert_called_once_with(2, 25)
        self.assertEqual(state.page_event, ste.TablePageEvent(page=2, page_size=25))
        self.assertEqual(state.page, 1)
        self.assertEqual(state.page_size, 10)
        self.assertIsNone(repeated.page_event)

    def test_table_uses_backend_page_state_and_total_rows(self) -> None:
        with (
            patch("ctlib_streamlit_extras.table.st.session_state", {}),
            patch(
                "ctlib_streamlit_extras.table._table_component",
                return_value=component_result(),
            ) as component,
        ):
            state = ste.table(
                pd.DataFrame({"name": list("abcdef")}),
                key="orders",
                page=99,
                page_size=10,
                total_rows=125,
            )

        _, kwargs = component.call_args
        self.assertEqual(kwargs["data"]["page"], 99)
        self.assertEqual(kwargs["data"]["page_size"], 10)
        self.assertEqual(kwargs["data"]["row_count"], 125)
        self.assertEqual(len(kwargs["data"]["rows"]), 6)
        self.assertEqual(state.page, 99)
        self.assertEqual(state.page_size, 10)
        self.assertEqual(state.page_count, 13)

    def test_table_dispatches_sort_change_callback_once(self) -> None:
        on_sort_change = Mock()
        session_state = {}

        with (
            patch("ctlib_streamlit_extras.table.st.session_state", session_state),
            patch(
                "ctlib_streamlit_extras.table._table_component",
                return_value=component_result(
                    sort_change={
                        "event_id": "sort-1",
                        "column": "amount",
                        "direction": "desc",
                    }
                ),
            ),
        ):
            state = ste.table(
                pd.DataFrame({"name": ["Ada"], "amount": [12]}),
                key="orders",
                sort_column="name",
                sort_direction="asc",
                on_sort_change=on_sort_change,
            )
            repeated = ste.table(
                pd.DataFrame({"name": ["Ada"], "amount": [12]}),
                key="orders",
                sort_column="name",
                sort_direction="asc",
                on_sort_change=on_sort_change,
            )

        on_sort_change.assert_called_once_with("amount", "desc")
        self.assertEqual(
            state.sort_event,
            ste.TableSortEvent(column="amount", direction="desc"),
        )
        self.assertEqual(state.sort_column, "name")
        self.assertEqual(state.sort_direction, "asc")
        self.assertIsNone(repeated.sort_event)

    def test_table_dispatches_button_callback_with_row_data_once(self) -> None:
        on_open = Mock()
        frame = pd.DataFrame(
            {
                "name": ["Ada", "Grace"],
                "amount": [12, 34],
            },
            index=["a", "g"],
        )
        session_state = {}

        with (
            patch("ctlib_streamlit_extras.table.st.session_state", session_state),
            patch(
                "ctlib_streamlit_extras.table._table_component",
                return_value=component_result(
                    button_click={
                        "event_id": "button-1",
                        "column": "actions",
                        "button": "open",
                        "row_position": 1,
                    }
                ),
            ),
        ):
            state = ste.table(
                frame,
                key="orders",
                column_order=["name", "amount", "actions"],
                column_config={
                    "actions": ste.ButtonGroupColumn(
                        buttons=[ste.TableButton("Open", key="open", on_click=on_open)]
                    )
                },
            )
            repeated = ste.table(
                frame,
                key="orders",
                column_order=["name", "amount", "actions"],
                column_config={
                    "actions": ste.ButtonGroupColumn(
                        buttons=[ste.TableButton("Open", key="open", on_click=on_open)]
                    )
                },
            )

        on_open.assert_called_once_with({"name": "Grace", "amount": 34})
        self.assertEqual(
            state.button_event,
            ste.TableButtonEvent(
                column="actions",
                button="open",
                row_index="g",
                row_position=1,
                row={"name": "Grace", "amount": 34},
            ),
        )
        self.assertIsNone(repeated.button_event)

    def test_table_dispatches_button_callback_for_list_of_dicts(self) -> None:
        on_open = Mock()
        rows = [
            {"name": "Ada", "amount": 12},
            {"name": "Grace", "amount": 34},
        ]

        with (
            patch("ctlib_streamlit_extras.table.st.session_state", {}),
            patch(
                "ctlib_streamlit_extras.table._table_component",
                return_value=component_result(
                    button_click={
                        "event_id": "button-1",
                        "column": "actions",
                        "button": "open",
                        "row_position": 1,
                    }
                ),
            ),
        ):
            state = ste.table(
                rows,
                key="orders",
                column_order=["name", "amount", "actions"],
                column_config={
                    "actions": ste.ButtonGroupColumn(
                        buttons=[ste.TableButton("Open", key="open", on_click=on_open)]
                    )
                },
            )

        on_open.assert_called_once_with({"name": "Grace", "amount": 34})
        self.assertEqual(
            state.button_event,
            ste.TableButtonEvent(
                column="actions",
                button="open",
                row_index=1,
                row_position=1,
                row={"name": "Grace", "amount": 34},
            ),
        )

    def test_table_rejects_unsupported_list_item_types(self) -> None:
        with (
            patch("ctlib_streamlit_extras.table.st.session_state", {}),
            patch(
                "ctlib_streamlit_extras.table._table_component",
                return_value=component_result(),
            ),
        ):
            with self.assertRaisesRegex(
                TypeError,
                "only accepts pandas.DataFrame-like data, list\\[dict\\], or list\\[pydantic.BaseModel\\]",
            ):
                ste.table([1, 2, 3], key="orders")


if __name__ == "__main__":
    unittest.main()
