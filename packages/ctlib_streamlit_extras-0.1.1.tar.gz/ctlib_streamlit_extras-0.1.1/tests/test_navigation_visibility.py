import unittest
from unittest.mock import patch

import ctlib_streamlit_extras as ste
from ctlib_streamlit_extras.app import Meta


class DemoApp(ste.App):
    @property
    def meta(self) -> Meta:
        if not hasattr(self, "_test_meta"):
            self._test_meta = Meta()
        return self._test_meta


class VisiblePage(ste.Page[ste.PageState]):
    def render(self) -> None:
        pass


class UnavailablePage(ste.Page[ste.PageState]):
    available = False

    def render(self) -> None:
        pass


def is_dynamic_page_available(app: ste.App, route: ste.Route) -> bool:
    return route.path == "visible"


class DynamicPage(ste.Page[ste.PageState]):
    available = is_dynamic_page_available

    def render(self) -> None:
        pass


class HiddenPage(ste.Page[ste.PageState]):
    visible = False

    def render(self) -> None:
        pass


def is_dynamic_page_visible(app: ste.App, route: ste.Route) -> bool:
    return route.path == "visible"


class DynamicVisibilityPage(ste.Page[ste.PageState]):
    visible = is_dynamic_page_visible

    def render(self) -> None:
        pass


class ReportsPage(ste.Page[ste.PageState]):
    group = "Reports"

    def render(self) -> None:
        pass


class AdminPage(ste.Page[ste.PageState]):
    group = "Admin"

    def render(self) -> None:
        pass


class NavigationVisibilityTests(unittest.TestCase):
    @staticmethod
    def make_page(*args, **kwargs):
        return {
            "path": kwargs["url_path"],
            "title": kwargs["title"],
            "visibility": kwargs["visibility"],
        }

    def test_build_navigation_excludes_unavailable_pages(self) -> None:
        app = DemoApp()
        app.register_page("visible", VisiblePage, default=True)
        app.register_page("hidden", UnavailablePage)

        with (
            patch("ctlib_streamlit_extras.app.st.Page", side_effect=self.make_page) as page_factory,
            patch("ctlib_streamlit_extras.app.st.navigation", side_effect=lambda pages: pages) as navigation,
        ):
            result = app.build_navigation()

        self.assertEqual(
            result,
            [{"path": "visible", "title": "Page", "visibility": "visible"}],
        )
        self.assertEqual(page_factory.call_count, 1)
        self.assertIn("visible", app.meta.page_objects)
        self.assertNotIn("hidden", app.meta.page_objects)
        navigation.assert_called_once_with(
            [{"path": "visible", "title": "Page", "visibility": "visible"}]
        )

    def test_build_navigation_groups_pages_when_enabled(self) -> None:
        app = DemoApp()
        app.register_page("reports", ReportsPage, default=True)
        app.register_page("admin", AdminPage)

        with (
            patch("ctlib_streamlit_extras.app.st.Page", side_effect=self.make_page) as page_factory,
            patch("ctlib_streamlit_extras.app.st.navigation", side_effect=lambda pages: pages) as navigation,
        ):
            result = app.build_navigation()

        self.assertEqual(
            result,
            {
                "Reports": [{"path": "reports", "title": "Page", "visibility": "visible"}],
                "Admin": [{"path": "admin", "title": "Page", "visibility": "visible"}],
            },
        )
        self.assertEqual(page_factory.call_count, 2)
        navigation.assert_called_once_with(
            {
                "Reports": [{"path": "reports", "title": "Page", "visibility": "visible"}],
                "Admin": [{"path": "admin", "title": "Page", "visibility": "visible"}],
            }
        )

    def test_build_navigation_ignores_groups_when_disabled(self) -> None:
        app = DemoApp(enable_page_groups=False)
        app.register_page("reports", ReportsPage, default=True)
        app.register_page("admin", AdminPage)

        with (
            patch("ctlib_streamlit_extras.app.st.Page", side_effect=self.make_page) as page_factory,
            patch("ctlib_streamlit_extras.app.st.navigation", side_effect=lambda pages: pages) as navigation,
        ):
            result = app.build_navigation()

        self.assertEqual(
            result,
            [
                {"path": "reports", "title": "Page", "visibility": "visible"},
                {"path": "admin", "title": "Page", "visibility": "visible"},
            ],
        )
        self.assertEqual(page_factory.call_count, 2)
        navigation.assert_called_once_with(
            [
                {"path": "reports", "title": "Page", "visibility": "visible"},
                {"path": "admin", "title": "Page", "visibility": "visible"},
            ]
        )

    def test_build_navigation_supports_callable_available(self) -> None:
        app = DemoApp()
        app.register_page("visible", DynamicPage, default=True)
        app.register_page("hidden", DynamicPage)

        with (
            patch("ctlib_streamlit_extras.app.st.Page", side_effect=self.make_page) as page_factory,
            patch("ctlib_streamlit_extras.app.st.navigation", side_effect=lambda pages: pages) as navigation,
        ):
            result = app.build_navigation()

        self.assertEqual(
            result,
            [{"path": "visible", "title": "Page", "visibility": "visible"}],
        )
        self.assertEqual(page_factory.call_count, 1)
        self.assertIn("visible", app.meta.page_objects)
        self.assertNotIn("hidden", app.meta.page_objects)
        navigation.assert_called_once_with(
            [{"path": "visible", "title": "Page", "visibility": "visible"}]
        )

    def test_route_visibility_defaults_to_available_when_visible_is_omit(self) -> None:
        app = DemoApp()
        app.register_page("visible", VisiblePage, default=True)
        app.register_page("hidden", UnavailablePage)

        self.assertEqual(app.route_visibility(app.routes["visible"]), "visible")
        self.assertEqual(app.route_visibility(app.routes["hidden"]), "hidden")

    def test_build_navigation_registers_hidden_pages_without_showing_them(self) -> None:
        app = DemoApp()
        app.register_page("visible", VisiblePage, default=True)
        app.register_page("internal", HiddenPage)

        with (
            patch("ctlib_streamlit_extras.app.st.Page", side_effect=self.make_page) as page_factory,
            patch("ctlib_streamlit_extras.app.st.navigation", side_effect=lambda pages: pages) as navigation,
        ):
            result = app.build_navigation()

        self.assertEqual(
            result,
            [
                {"path": "visible", "title": "Page", "visibility": "visible"},
                {"path": "internal", "title": "Page", "visibility": "hidden"},
            ],
        )
        self.assertEqual(page_factory.call_count, 2)
        self.assertIn("internal", app.meta.page_objects)
        navigation.assert_called_once_with(
            [
                {"path": "visible", "title": "Page", "visibility": "visible"},
                {"path": "internal", "title": "Page", "visibility": "hidden"},
            ]
        )

    def test_build_navigation_supports_callable_visible(self) -> None:
        app = DemoApp()
        app.register_page("visible", DynamicVisibilityPage, default=True)
        app.register_page("internal", DynamicVisibilityPage)

        with (
            patch("ctlib_streamlit_extras.app.st.Page", side_effect=self.make_page) as page_factory,
            patch("ctlib_streamlit_extras.app.st.navigation", side_effect=lambda pages: pages) as navigation,
        ):
            result = app.build_navigation()

        self.assertEqual(
            result,
            [
                {"path": "visible", "title": "Page", "visibility": "visible"},
                {"path": "internal", "title": "Page", "visibility": "hidden"},
            ],
        )
        self.assertEqual(page_factory.call_count, 2)
        self.assertIn("internal", app.meta.page_objects)
        navigation.assert_called_once_with(
            [
                {"path": "visible", "title": "Page", "visibility": "visible"},
                {"path": "internal", "title": "Page", "visibility": "hidden"},
            ]
        )

    def test_switch_page_supports_hidden_registered_route(self) -> None:
        app = DemoApp()
        app.register_page("visible", VisiblePage, default=True)
        app.register_page("internal", HiddenPage)

        with (
            patch("ctlib_streamlit_extras.app.st.Page", side_effect=self.make_page),
            patch("ctlib_streamlit_extras.app.st.navigation", side_effect=lambda pages: pages),
            patch("ctlib_streamlit_extras.app.st.switch_page") as switch_page,
        ):
            app.build_navigation()
            app.switch_page("internal")

        switch_page.assert_called_once_with(
            {"path": "internal", "title": "Page", "visibility": "hidden"},
            query_params=None,
        )


if __name__ == "__main__":
    unittest.main()
