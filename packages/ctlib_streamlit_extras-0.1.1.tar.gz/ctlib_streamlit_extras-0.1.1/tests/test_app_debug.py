import unittest
from unittest.mock import patch

import ctlib_streamlit_extras as ste
from ctlib_streamlit_extras.app import Meta


class DemoApp(ste.App):
    @property
    def meta(self) -> Meta:
        if not hasattr(self, "_test_meta"):
            self._test_meta = Meta()
        return self._test_meta


class FailingPage(ste.Page[ste.PageState]):
    def render(self) -> None:
        raise RuntimeError("page failed")


class AppDebugTests(unittest.TestCase):
    def test_debug_false_converts_page_error_into_st_error(self) -> None:
        app = DemoApp(debug=False)
        app.register_page("failing", FailingPage, default=True)

        with (
            patch("ctlib_streamlit_extras.app.logger.exception") as log_exception,
            patch("ctlib_streamlit_extras.app.st.error") as error,
        ):
            app.build_route_handler(app.routes["failing"])()

        log_exception.assert_called_once_with(
            "Unhandled exception while executing route %s",
            "failing",
        )
        error.assert_called_once_with("😵 Oops, something went wrong.")

    def test_debug_true_reraises_page_error(self) -> None:
        app = DemoApp(debug=True)
        app.register_page("failing", FailingPage, default=True)

        with (
            patch("ctlib_streamlit_extras.app.st.error") as error,
            self.assertRaisesRegex(RuntimeError, "page failed"),
        ):
            app.build_route_handler(app.routes["failing"])()

        error.assert_not_called()


if __name__ == "__main__":
    unittest.main()
