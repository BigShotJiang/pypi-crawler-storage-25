import unittest

import ctlib_streamlit_extras as ste
from ctlib_streamlit_extras.context import _reset_context_providers


class DemoContext(ste.PageState):
    label: str = "demo"


class DemoPage(ste.Page[ste.PageState]):
    def render(self) -> None:
        pass


class AppContextContractTests(unittest.TestCase):
    def tearDown(self) -> None:
        _reset_context_providers()

    def test_app_must_not_be_created_inside_active_context_provider(self) -> None:
        with ste.ContextProvider(DemoContext):
            with self.assertRaisesRegex(RuntimeError, "cannot be created inside an active ContextProvider"):
                ste.App()

    def test_reset_context_providers_is_not_exported_from_top_level_package(self) -> None:
        self.assertFalse(hasattr(ste, "reset_context_providers"))

    def test_internal_variables_are_not_exported_from_top_level_package(self) -> None:
        self.assertFalse(hasattr(ste, "ACTIVE_CONTEXT_BINDINGS"))
        self.assertFalse(hasattr(ste, "CURRENT_CONTEXT_BINDINGS"))
        self.assertFalse(hasattr(ste, "ACTIVE_MIDDLEWARES"))
        self.assertFalse(hasattr(ste, "STATE_KEY_PREFIX"))

    def test_register_page_still_captures_context_when_app_is_created_first(self) -> None:
        app = ste.App()

        with ste.ContextProvider(DemoContext):
            app.register_page("demo", DemoPage)

        route = app.routes["demo"]
        self.assertEqual(len(route.context_bindings), 1)
        self.assertIs(route.context_bindings[0].context_type, DemoContext)


if __name__ == "__main__":
    unittest.main()
