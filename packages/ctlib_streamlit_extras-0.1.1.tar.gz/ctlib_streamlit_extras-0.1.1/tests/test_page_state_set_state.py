import unittest

import ctlib_streamlit_extras as ste


class DemoState(ste.PageState):
    name: str = "initial"
    count: int = 1
    enabled: bool = True


class OtherState(ste.PageState):
    value: int = 0


class DemoPage(ste.Page[DemoState]):
    def render(self) -> None:
        pass


class PageSetStateTests(unittest.TestCase):
    def test_set_state_updates_only_explicit_patch_fields(self) -> None:
        page = DemoPage(DemoState(name="before", count=7, enabled=True))

        page.set_state(DemoState(name="after"))

        self.assertEqual(page.state.name, "after")
        self.assertEqual(page.state.count, 7)
        self.assertTrue(page.state.enabled)

    def test_set_state_applies_explicit_default_values(self) -> None:
        page = DemoPage(DemoState(name="before", count=7, enabled=False))

        page.set_state(DemoState(enabled=True))

        self.assertEqual(page.state.name, "before")
        self.assertEqual(page.state.count, 7)
        self.assertTrue(page.state.enabled)

    def test_set_state_rejects_wrong_state_type(self) -> None:
        page = DemoPage(DemoState())

        with self.assertRaisesRegex(TypeError, "set_state_cb\\(\\) expected DemoState, got OtherState"):
            page.set_state(OtherState(value=5))

    def test_set_state_cb_returns_callback(self) -> None:
        page = DemoPage(DemoState(name="before", count=7, enabled=True))

        callback = page.set_state_cb(DemoState(name="after"))
        callback()

        self.assertEqual(page.state.name, "after")
        self.assertEqual(page.state.count, 7)
        self.assertTrue(page.state.enabled)


if __name__ == "__main__":
    unittest.main()
