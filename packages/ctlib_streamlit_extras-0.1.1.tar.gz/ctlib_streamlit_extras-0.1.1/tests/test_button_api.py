import inspect
import unittest
from unittest.mock import patch

import ctlib_streamlit_extras as ste


class ButtonApiTests(unittest.TestCase):
    def test_button_signature_does_not_expose_disable_other_buttons(self) -> None:
        params = inspect.signature(ste.button).parameters
        self.assertNotIn("disable_other_buttons", params)

    def test_back_button_is_exported(self) -> None:
        self.assertTrue(callable(ste.back_button))

    def test_back_button_exposes_frontend_control_params(self) -> None:
        params = inspect.signature(ste.back_button).parameters
        self.assertEqual(
            list(params),
            [
                "label",
                "key",
                "type",
                "icon",
                "disabled",
                "use_container_width",
                "width",
            ],
        )
        self.assertNotIn("on_click", params)

    def test_back_button_renders_frontend_only_history_back_action(self) -> None:
        with patch("ctlib_streamlit_extras.button._button_component") as component:
            result = ste.back_button(
                "Back",
                key="details_back",
                type="primary",
                icon=":material/keyboard_backspace:",
                disabled=True,
                width="stretch",
            )

        self.assertIsNone(result)
        component.assert_called_once()
        _, kwargs = component.call_args
        self.assertNotIn("on_clicked_change", kwargs)
        self.assertEqual(kwargs["key"], "details_back")
        self.assertEqual(
            kwargs["data"],
            {
                "label": "Back",
                "component_id": "details_back",
                "help": None,
                "button_type": "primary",
                "icon": ":material/keyboard_backspace:",
                "disabled": True,
                "width": "stretch",
                "click_action": "history_back",
            },
        )


if __name__ == "__main__":
    unittest.main()
