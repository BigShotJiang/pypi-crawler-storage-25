import unittest
from typing import Annotated
from unittest.mock import patch

from pydantic import Field

import ctlib_streamlit_extras as ste
from ctlib_streamlit_extras.app import Meta


class FakeQueryParams(dict):
    def get_all(self, key: str) -> list[str]:
        if key not in self:
            return []

        value = self[key]
        if isinstance(value, list):
            return [str(item) for item in value]
        return [str(value)]

    def __setitem__(self, key: str, value) -> None:
        if isinstance(value, list):
            super().__setitem__(key, [str(item) for item in value])
            return
        super().__setitem__(key, str(value))


class DemoApp(ste.App):
    @property
    def meta(self) -> Meta:
        if not hasattr(self, "_test_meta"):
            self._test_meta = Meta()
        return self._test_meta


class UrlState(ste.PageState):
    page: Annotated[int, ste.UrlParam("p")] = 1
    tags: Annotated[list[int], ste.UrlParam("tag")] = Field(default_factory=list)
    enabled: Annotated[bool, ste.UrlParam("enabled")] = False
    name: str = "local"


class UrlPage(ste.Page[UrlState]):
    def render(self) -> None:
        pass


class StringAnnotationState(ste.PageState):
    tags: "Annotated[list[int], ste.UrlParam('tag')]" = Field(default_factory=list)


class StringAnnotationPage(ste.Page[StringAnnotationState]):
    def render(self) -> None:
        pass


class PageStateUrlParamTests(unittest.TestCase):
    def test_page_state_rejects_fields_without_defaults(self) -> None:
        with self.assertRaisesRegex(
            TypeError,
            "MissingDefaultState PageState fields must define defaults or default_factory: page",
        ):

            class MissingDefaultState(ste.PageState):
                page: Annotated[int, ste.UrlParam("p")]

    def test_get_page_state_reads_url_params_and_validates_field_types(self) -> None:
        app = DemoApp()
        app.register_page("demo", UrlPage)
        query_params = FakeQueryParams(
            {
                "p": "3",
                "tag": ["4", "5"],
                "enabled": "true",
            }
        )

        with patch("ctlib_streamlit_extras.page_state.st.query_params", query_params):
            state = app.get_page_state(app.routes["demo"])

        self.assertEqual(state.page, 3)
        self.assertEqual(state.tags, [4, 5])
        self.assertTrue(state.enabled)
        self.assertEqual(state.name, "local")

    def test_get_page_state_removes_initial_url_params_that_equal_defaults(self) -> None:
        app = DemoApp()
        app.register_page("demo", UrlPage)
        query_params = FakeQueryParams(
            {
                "p": "1",
                "enabled": "false",
            }
        )

        with patch("ctlib_streamlit_extras.page_state.st.query_params", query_params):
            state = app.get_page_state(app.routes["demo"])

        self.assertEqual(state.page, 1)
        self.assertFalse(state.enabled)
        self.assertNotIn("p", query_params)
        self.assertNotIn("enabled", query_params)

    def test_route_handler_opens_page_with_url_params_synced_to_state(self) -> None:
        app = DemoApp(debug=True)
        app.register_page("demo", UrlPage)
        query_params = FakeQueryParams({"p": "7"})

        with patch("ctlib_streamlit_extras.page_state.st.query_params", query_params):
            app.build_route_handler(app.routes["demo"])()

        self.assertEqual(app.meta.page_states["demo"].page, 7)

    def test_existing_page_state_ignores_later_url_param_changes(self) -> None:
        app = DemoApp()
        app.register_page("demo", UrlPage)
        app.meta.page_states["demo"] = UrlState(page=9, tags=[8], enabled=True)
        query_params = FakeQueryParams({"p": "1", "enabled": "false"})

        with patch("ctlib_streamlit_extras.page_state.st.query_params", query_params):
            state = app.get_page_state(app.routes["demo"])

        self.assertEqual(state.page, 9)
        self.assertEqual(state.tags, [8])
        self.assertTrue(state.enabled)
        self.assertEqual(query_params["p"], "1")
        self.assertEqual(query_params["enabled"], "false")

    def test_assignment_updates_bound_url_params(self) -> None:
        state = UrlState()
        query_params = FakeQueryParams()

        with patch("ctlib_streamlit_extras.page_state.st.query_params", query_params):
            state.page = 7
            state.tags = [8, 9]
            state.enabled = True

        self.assertEqual(query_params["p"], "7")
        self.assertEqual(query_params["tag"], ["8", "9"])
        self.assertEqual(query_params["enabled"], "true")

    def test_assignment_removes_bound_url_params_when_value_equals_default(self) -> None:
        state = UrlState(page=7, tags=[8, 9], enabled=True)
        query_params = FakeQueryParams(
            {
                "p": "7",
                "tag": ["8", "9"],
                "enabled": "true",
            }
        )

        with patch("ctlib_streamlit_extras.page_state.st.query_params", query_params):
            state.page = 1
            state.tags = []
            state.enabled = False

        self.assertNotIn("p", query_params)
        self.assertNotIn("tag", query_params)
        self.assertNotIn("enabled", query_params)

    def test_set_state_updates_bound_url_params(self) -> None:
        page = UrlPage(UrlState())
        query_params = FakeQueryParams()

        with patch("ctlib_streamlit_extras.page_state.st.query_params", query_params):
            page.set_state(UrlState(page=4))

        self.assertEqual(page.state.page, 4)
        self.assertEqual(query_params["p"], "4")
        self.assertNotIn("tag", query_params)

    def test_string_annotation_url_param_uses_pydantic_field_annotation(self) -> None:
        app = DemoApp()
        app.register_page("demo", StringAnnotationPage)
        query_params = FakeQueryParams({"tag": ["4", "5"]})

        with patch("ctlib_streamlit_extras.page_state.st.query_params", query_params):
            state = app.get_page_state(app.routes["demo"])
            state.tags = [8, 9]

        self.assertEqual(state.tags, [8, 9])
        self.assertEqual(query_params["tag"], ["8", "9"])

    def test_future_annotations_url_param_uses_pydantic_field_annotation(self) -> None:
        namespace = dict(globals())
        exec(
            """
from __future__ import annotations

class FutureAnnotationState(ste.PageState):
    tags: Annotated[list[int], ste.UrlParam("tag")] = Field(default_factory=list)


class FutureAnnotationPage(ste.Page[FutureAnnotationState]):
    def render(self) -> None:
        pass
""",
            namespace,
        )
        page_cls = namespace["FutureAnnotationPage"]
        app = DemoApp()
        app.register_page("demo", page_cls)
        query_params = FakeQueryParams({"tag": ["4", "5"]})

        with patch("ctlib_streamlit_extras.page_state.st.query_params", query_params):
            state = app.get_page_state(app.routes["demo"])
            state.tags = [8, 9]

        self.assertEqual(state.tags, [8, 9])
        self.assertEqual(query_params["tag"], ["8", "9"])

    def test_local_type_alias_url_param_uses_pydantic_field_annotation(self) -> None:
        namespace = dict(globals())
        exec(
            """
from __future__ import annotations

def build_local_page():
    Tags = list[int]

    class LocalAliasState(ste.PageState):
        tags: Annotated[Tags, ste.UrlParam("tag")] = Field(default_factory=list)

    class LocalAliasPage(ste.Page[LocalAliasState]):
        def render(self) -> None:
            pass

    return LocalAliasPage
""",
            namespace,
        )
        page_cls = namespace["build_local_page"]()
        app = DemoApp()
        app.register_page("demo", page_cls)
        query_params = FakeQueryParams({"tag": ["4", "5"]})

        with patch("ctlib_streamlit_extras.page_state.st.query_params", query_params):
            state = app.get_page_state(app.routes["demo"])
            state.tags = [8, 9]

        self.assertEqual(state.tags, [8, 9])
        self.assertEqual(query_params["tag"], ["8", "9"])

    def test_reset_state_restores_defaults_instead_of_url_params(self) -> None:
        page = UrlPage(UrlState(page=7, tags=[8], enabled=True, name="changed"))
        query_params = FakeQueryParams(
            {
                "p": "7",
                "tag": ["8"],
                "enabled": "true",
            }
        )

        with patch("ctlib_streamlit_extras.page_state.st.query_params", query_params):
            page.reset_state()

        self.assertEqual(page.state.page, 1)
        self.assertEqual(page.state.tags, [])
        self.assertFalse(page.state.enabled)
        self.assertEqual(page.state.name, "local")
        self.assertNotIn("p", query_params)
        self.assertNotIn("tag", query_params)
        self.assertNotIn("enabled", query_params)


if __name__ == "__main__":
    unittest.main()
