import unittest

from pydantic import Field

import ctlib_streamlit_extras as ste


class DemoState(ste.PageState):
    name: str = "initial"
    count: int = 1
    enabled: bool = True


class OtherState(ste.PageState):
    value: int = 0


class DemoPage(ste.Page[DemoState]):
    def render(self) -> None:
        pass


class PageReplaceStateTests(unittest.TestCase):
    def test_replace_state_overwrites_the_current_state_object(self) -> None:
        initial_state = DemoState(name="before", count=7, enabled=False)
        next_state = DemoState(name="after", count=1, enabled=True)
        page = DemoPage(initial_state)

        page.replace_state(next_state)

        self.assertIs(page.state, initial_state)
        self.assertEqual(page.state.name, "after")
        self.assertEqual(page.state.count, 1)
        self.assertTrue(page.state.enabled)

    def test_replace_state_rejects_wrong_state_type(self) -> None:
        page = DemoPage(DemoState())

        with self.assertRaisesRegex(
            TypeError,
            "replace_state_cb\\(\\) expected DemoState, got OtherState",
        ):
            page.replace_state(OtherState(value=5))

    def test_reset_state_replaces_with_new_default_values(self) -> None:
        page = DemoPage(DemoState(name="before", count=7, enabled=False))

        page.reset_state()

        self.assertEqual(page.state.name, "initial")
        self.assertEqual(page.state.count, 1)
        self.assertTrue(page.state.enabled)

    def test_reset_state_cb_returns_callback(self) -> None:
        page = DemoPage(DemoState(name="before", count=7, enabled=False))

        callback = page.reset_state_cb()
        callback()

        self.assertEqual(page.state.name, "initial")
        self.assertEqual(page.state.count, 1)
        self.assertTrue(page.state.enabled)

    def test_reset_state_cb_creates_default_state_when_callback_runs(self) -> None:
        factory_calls = 0

        def next_default() -> int:
            nonlocal factory_calls
            factory_calls += 1
            return factory_calls

        class FactoryState(ste.PageState):
            value: int = Field(default_factory=next_default)

        class FactoryPage(ste.Page[FactoryState]):
            def render(self) -> None:
                pass

        page = FactoryPage(FactoryState(value=99))

        callback = page.reset_state_cb()

        self.assertEqual(factory_calls, 0)
        callback()
        self.assertEqual(factory_calls, 1)
        self.assertEqual(page.state.value, 1)

    def test_replace_state_cb_returns_callback(self) -> None:
        initial_state = DemoState(name="before", count=7, enabled=False)
        next_state = DemoState(name="after", count=1, enabled=True)
        page = DemoPage(initial_state)

        callback = page.replace_state_cb(next_state)
        callback()

        self.assertIs(page.state, initial_state)
        self.assertEqual(page.state.name, "after")
        self.assertEqual(page.state.count, 1)
        self.assertTrue(page.state.enabled)


if __name__ == "__main__":
    unittest.main()
