# Back Button

`ctlib_streamlit_extras.back_button(...)` 是一个简单的返回按钮小组件。

## 用途

点击后会：

- 调用浏览器的 `history.back()` 返回上一条浏览历史
- 不触发 Streamlit rerun
- 不返回点击状态
- 不执行 Python 回调
- 保留 `key`、`type`、`disabled`、`width` 等前端渲染控制参数

适合放在详情页、隐藏内部页或从列表进入的二级页面顶部。

## 用法

```python
import ctlib_streamlit_extras as ste

ste.back_button()
ste.back_button("Back", key="details_back", type="secondary", width="stretch")
```

默认文案是 `返回`，默认图标是 `:material/arrow_back:`，默认样式是 `tertiary`。

## API

```python
ste.back_button(
    label="返回",
    key=None,
    type="tertiary",
    icon=":material/arrow_back:",
    disabled=False,
    use_container_width=False,
    width="content",
)
```

点击动作固定为浏览器返回。`key`、`type`、`disabled`、`width` 只影响前端渲染和组件挂载，不会让组件产生 Python 点击事件。

## 说明

- 如果当前浏览器标签页没有可返回的历史记录，浏览器返回动作本身不会改变页面。
- 这个组件没有 `on_click`，也不会返回 `True` / `False`。
