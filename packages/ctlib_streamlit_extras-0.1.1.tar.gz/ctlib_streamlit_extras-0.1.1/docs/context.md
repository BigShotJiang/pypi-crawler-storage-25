# Context

`ContextProvider` 和 `use_context()` 用来在多个路由之间共享类型化对象，而不用把所有内容都塞进单个页面状态里。

## 声明上下文类型

```python
import ctlib_streamlit_extras as ste


class DemoContext(ste.PageState):
    label: str = "Shared context"
```

上下文类型本质上是一个 Pydantic 模型。

## 注册上下文作用域

```python
app = ste.App()

with ste.ContextProvider(DemoContext):
    app.register_page("counter", CounterPage, default=True)
    app.register_page("other", OtherPage)
```

这里有一个重要约束：

- 先创建 `App()`
- 再在 `ContextProvider(...)` 作用域里注册页面

provider 捕获的是“注册时”的上下文绑定，而不是后面懒加载决定。

## 读取上下文

在页面内部：

```python
context = ste.use_context(DemoContext)
st.caption(context.label)
```

如果当前路由上没有这个类型的有效绑定，`use_context(...)` 会抛出 `LookupError`。

## 生命周期

对于当前路由的每个生效绑定，app 都会在元数据里保存一个上下文对象。

行为如下：

- 在同一个 provider 作用域下注册的多个路由，会在该绑定仍有效时共享同一个上下文对象
- 当当前路由不再使用某个绑定时，失活的上下文对象会被清理

## 嵌套 Provider

支持嵌套 provider。`use_context(...)` 会解析最近的、类型匹配的有效绑定。

这意味着如果内层 provider 使用了相同的上下文类型，它会遮蔽外层 provider。
