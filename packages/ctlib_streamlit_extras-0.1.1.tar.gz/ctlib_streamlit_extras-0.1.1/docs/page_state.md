# Page State

`PageState` 和 `Page[StateT]` 提供了类型化的、按路由隔离的页面状态。

## 声明状态

```python
import ctlib_streamlit_extras as ste
from pydantic import Field
from typing import Annotated


class CounterState(ste.PageState):
    counter: int = 0
    history: list[str] = Field(default_factory=list)
```

`PageState` 本质上只是一个 `pydantic.BaseModel` 基类。你可以正常使用 Pydantic 字段和默认值。

由于页面状态由框架无参创建，`PageState` 的所有字段都必须声明默认值或 `default_factory`。如果字段缺少默认值，状态类定义时会直接报错。

## 绑定 URL 参数

可以用 `Annotated[..., ste.UrlParam(...)]` 把字段绑定到 URL query parameter：

```python
class SearchState(ste.PageState):
    page: Annotated[int, ste.UrlParam("page")] = 1
    tags: Annotated[list[int], ste.UrlParam("tag")] = Field(default_factory=list)
```

首次创建页面状态时，`Page.create_state()` 会从 `st.query_params` 读取绑定字段：

- URL 里存在对应 key 时，原始字符串值会交给 Pydantic 按字段类型校验和转换
- URL 里不存在对应 key 时，使用字段声明的默认值或 `default_factory`
- `list`、`set`、`tuple`、`frozenset` 字段会读取重复 query parameter 的全部值

URL 参数只在状态创建阶段读取一次。页面状态已经存在后，后续 URL 参数变化不会覆盖现有 `PageState`。

字段被赋值更新时，对应 URL 参数会同步更新：

```python
self.state.page = 2
self.state.tags = [10, 20]
```

如果字段当前值等于声明的默认值，对应 URL 参数会被移除。例如 `page` 恢复为默认值 `1` 时，URL 里不会继续保留 `?page=1`。

`set_state(...)`、`replace_state(...)` 和 `reset_state(...)` 也会通过字段赋值触发 URL 同步。对于可变字段，请用重新赋值的方式更新，例如
`self.state.tags = [*self.state.tags, 30]`。

## 声明页面

```python
class CounterPage(ste.Page[CounterState]):
    title = "Counter"

    def render(self) -> None:
        ...
```

泛型参数会决定页面绑定的状态类型。如果页面没有声明合法的 Pydantic 模型类型，类创建时就会失败。

## 读取状态

每个页面实例都会收到一个状态对象：

```python
def render(self) -> None:
    st.write(self.state.counter)
```

只要用户还停留在同一路由，这个对象就会跨 rerun 保留。

## 更新状态

可以直接修改 `self.state`：

```python
self.state.counter += 1
```

也可以使用回调辅助方法：

```python
st.button("Reset", on_click=self.reset_state_cb())
st.button("Rename", on_click=self.set_state_cb(CounterState(counter=0)))
```

可用的辅助方法有：

- `set_state(patch)`
- `replace_state(next_state)`
- `reset_state()`
- `set_state_cb(patch)`
- `replace_state_cb(next_state)`
- `reset_state_cb()`

## `set_state()` 与 `replace_state()`

`set_state(patch)` 会立即更新补丁模型里被显式设置的字段。

`replace_state(next_state)` 会立即用 `next_state` 的全部字段值覆盖当前状态。

如果你需要传给 `on_click=...` 这类回调参数，使用对应的 `*_cb(...)` 版本。

这些方法都会：

- 校验传入对象是否与页面声明的状态类型一致
- 原地修改现有状态对象

其中：

- `set_state_cb(...)`
- `replace_state_cb(...)`
- `reset_state_cb()`

会返回 callback，适合直接传给 `on_click=...`

## 可见性与分组

页面类还可以定义：

- `title`
- `available`
- `visible`
- `group`

这些属性会在 `App` 构建导航时使用。

如果没有显式设置 `visible`，它会跟随 `available`。
