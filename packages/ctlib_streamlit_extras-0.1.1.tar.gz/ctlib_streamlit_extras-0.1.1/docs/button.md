# Button

`ctlib_streamlit_extras.button(...)` 是基础按钮 API。

## 用途

这个版本有意保持与 `st.button(...)` 接近：

- 点击触发的那一轮 rerun 中返回 `True`
- 不需要配合 `with`
- loading 完全由前端管理

适合用于你需要立刻防止重复点击，但不需要 Python 侧维护 loading 生命周期的场景。

## 用法

```python
import time
import streamlit as st

import ctlib_streamlit_extras as ste

if st.session_state.pop("button_example_clicked", False):
    time.sleep(3)
    st.success("Plain button finished")

ste.button(
    "Generate",
    type="primary",
    icon=":material/bolt:",
    on_click=lambda: st.session_state.__setitem__("button_example_clicked", True),
)
```

## 回调时序

`on_click` 遵循 Streamlit 官方回调顺序：

- 先接收到点击事件
- 先执行回调
- 然后应用从上到下重新 rerun

如果回调抛出异常，异常不会被吞掉，这次失败点击也不会在后续 rerun 中被当作一次成功点击继续保留。

## 状态模型

Python 侧只跟踪：

- `disabled`
- 当前这轮 rerun 是否由一次点击触发
- 稳定的 `button_id`

Python 不保存这个按钮的服务端 loading 状态。

浏览器侧跟踪：

- 点击后的 optimistic loading
- 页面级全局交互锁的 owner

浏览器会让 owner 按钮一直保持 loading，直到当前这轮 Streamlit rerun 真正结束。

## 全局锁

点击一个自定义按钮时，会临时禁用：

- 这个库中的其他自定义按钮

这把锁完全存在于前端。它记录：

- owner 按钮 id
- 当前页面级全局交互锁状态

这把锁会在以下情况释放：

- Streamlit 完成当前这轮 rerun，释放边界通过顶层 `stApp[data-test-script-state]` 判断
- 或者 owner 按钮在 rerun 完成前已经消失，此时会清理陈旧锁状态

## 标识

- 如果传了 `key`，则 `button_id == key`
- 否则 id 会由调用位置推导：
  - 源文件
  - 函数名
  - 行号

这个保守生成的 id 也会作为组件挂载 key 使用，因此展示字段变化不会创建新的按钮实例。

## 说明

- 在循环或动态布局中重复渲染按钮时，显式传入 `key`。
- Material 图标使用 `:material/...:` 语法，例如 `:material/bolt:`。
