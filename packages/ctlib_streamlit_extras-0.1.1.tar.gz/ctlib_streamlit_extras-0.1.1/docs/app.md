# App

`App` 是路由注册器和导航构建器。

## 职责

`App` 负责：

- 注册路由
- 把每个路由解析成 Streamlit page
- 创建并复用页面状态对象
- 创建并复用当前生效的上下文对象
- 在页面处理器外应用中间件

## 创建 App

```python
import ctlib_streamlit_extras as ste

app = ste.App()
debug_app = ste.App(debug=True)
```

不要在一个已经激活的 `ContextProvider` 作用域里创建 `App()`。正确顺序是先创建 app，再在 provider 作用域里注册页面。

## Debug 模式

`App(debug=False)` 是默认行为。

行为如下：

- `debug=False`：如果路由执行抛出 `Exception`，app 会渲染 `st.error(...)`，而不是继续把异常往外抛
- `debug=True`：路由执行错误会原样抛出

这个行为覆盖的是整条路由执行链，包括页面实例化、中间件包装和页面渲染。

## 注册页面

```python
app.register_page("counter", CounterPage, default=True)
app.register_page("settings", SettingsPage, title="Settings", icon=":material/settings:")
```

参数含义：

- `path`：传给 `st.Page(..., url_path=...)` 的路由路径
- `page_cls`：一个 `Page[...]` 子类
- `title`：可选，覆盖 `page_cls.title`
- `icon`：可选，Streamlit 页面图标
- `default`：当前路由是否为默认页
- `middlewares`：只作用于该路由的额外中间件实例

`path` 必须非空且唯一。

## 构建导航

```python
app.build_navigation().run()
```

`build_navigation()` 会把已注册路由转换成 `st.Page(...)` 对象，并传给 `st.navigation(...)`。

如果启用了分组，并且某些页面声明了 `Page.group`，这些页面会以分组结构出现在导航里。

## 路由可见性

页面类可以定义：

```python
class AdminPage(ste.Page[AdminState]):
    available = False
```

也可以定义：

```python
def can_show_admin(app: ste.App, route: ste.Route) -> bool:
    return route.path == "admin"
```

如果 `available` 结果为 `False`，这个路由不会进入导航。

## 隐藏但已注册的页面

页面类还可以定义：

```python
class DetailsPage(ste.Page[ste.PageState]):
    visible = False
```

`visible` 控制的是“这个已经注册的路由是否显示在导航 UI 中”。

如果没有显式覆盖 `visible`，它会跟随 `available`。

行为区别如下：

- `available = False`：路由不会被注册，也不能作为跳转目标
- `available = True, visible = False`：路由会被注册，但不会显示在导航 UI 中

这种隐藏但已注册的路由适合详情页、钻取页、流程中间页等只希望通过 `app.switch_page(...)` 进入的内部页面。

## 页面状态生命周期

`App` 会把页面状态保存在 session state 的框架元数据里。

行为如下：

- 同一路由上的 rerun 会复用该路由的状态对象
- 切换到其他路由时，前一个路由的状态会被清理
- 如果已有存储状态需要重新校验成页面声明的状态类型，app 会重新构造它

## 导航辅助方法

`App` 还暴露了：

- `switch_page(path, query_params=None)`
- `get_streamlit_page(path)`

`switch_page(...)` 使用的是通过 `register_page(...)` 注册的路由路径。

## 当前 App 查询

在页面执行期间，`current_app()` 会返回当前激活的 app：

```python
app = ste.current_app()
app.switch_page("settings")
```

如果在页面执行上下文之外调用，`current_app()` 会抛出 `LookupError`。
