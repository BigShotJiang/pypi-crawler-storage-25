# Middleware

`Middleware` 用来在路由执行外层包裹可复用逻辑。

## 声明中间件

```python
from collections.abc import Callable
import streamlit as st
import ctlib_streamlit_extras as ste


class BannerMiddleware(ste.Middleware):
    def __call__(
        self,
        next_handler: Callable[[], None],
        route: ste.Route,
    ) -> Callable[[], None]:
        def wrapped() -> None:
            st.info(f"Middleware active for `{route.path}`")
            next_handler()

        return wrapped
```

Middleware 会收到：

- `next_handler`：链中的下一个处理器
- `route`：当前路由元数据

它必须返回一个最终会调用 `next_handler()` 的可调用对象。

## 应用中间件

可以按作用域应用：

```python
with BannerMiddleware():
    app.register_page("counter", CounterPage)
```

也可以按单个路由应用：

```python
app.register_page("counter", CounterPage, middlewares=[BannerMiddleware()])
```

作用域中间件和上下文绑定一样，都是在页面注册时被捕获。

## 执行顺序

中间件会按注册顺序包裹页面处理器。

例如：

```python
with OuterMiddleware():
    with InnerMiddleware():
        app.register_page("counter", CounterPage)
```

最终调用顺序是：

1. `OuterMiddleware`
2. `InnerMiddleware`
3. 页面处理器

## MiddlewareChain

`MiddlewareChain(m1, m2, m3)` 是一个便捷中间件，用来把多个中间件实例组合成一个。
