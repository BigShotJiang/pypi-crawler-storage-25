# Framework

`ctlib_streamlit_extras` 除了自定义组件外，还包含一层基于 Streamlit navigation 的轻量应用框架。

这套框架由四部分组成：

- `App`：注册路由并构建 Streamlit 导航
- `Page[StateT]`：把页面绑定到类型化的 Pydantic 状态模型
- `ContextProvider` / `use_context()`：为一组路由注册共享上下文对象
- `Middleware`：在页面执行前后包装路由处理器

## 心智模型

整体执行方式是：

1. 创建一个 `App`
2. 在这个 app 上注册页面
3. 需要的话，在 `ContextProvider` 和 `Middleware` 作用域里注册页面
4. 调用 `app.build_navigation().run()`

运行时，当某个路由被选中：

1. app 解析当前 `Route`
2. 为该路由取出页面状态对象
3. 为该路由准备当前生效的上下文对象
4. 用中间件把页面处理器包起来
5. 执行页面

## 哪些状态会保留

- 只要还停留在同一路由上，页面状态会跨 rerun 保留
- 切换到其他路由后，前一个路由的页面状态会被清理
- 只要当前路由仍然依赖某个上下文绑定，对应上下文对象就会保留
- Middleware 本身不会自动持久化状态，除非你自己把状态存到别处

## 路由可见性与分组

每个页面类都可以控制是否出现在导航中：

- `available = True | False`
- `available = callable(app, route) -> bool`

`available` 控制的是这个路由是否被注册到导航系统里。

页面类也可以单独控制“已注册的路由是否显示在导航 UI 中”：

- `visible = True | False`
- `visible = callable(app, route) -> bool`

默认情况下，`visible` 会跟随 `available`。

当 `visible` 为 `False` 时，路由仍然会注册到 `st.navigation(...)`，但会以 Streamlit hidden page 的方式传入。这样就可以支持通过 `app.switch_page(...)` 跳转的内部页面。

每个页面类也可以设置：

- `group = "分组名"`

当使用 `App(enable_page_groups=True)` 时，带分组的页面会以分组结构传给 `st.navigation(...)`。

## 模块文档

- [App](app.md)
- [Page State](page_state.md)
- [Context](context.md)
- [Middleware](middleware.md)
- [Button](button.md)
- [Back Button](back_button.md)

## 示例

可参考 [examples/page_state_app.py](/Users/jimin/workspace/codetech/ctlib-streamlit-extras/examples/page_state_app.py)，其中组合演示了：

- `App`
- 类型化页面状态
- 共享上下文
- 中间件
