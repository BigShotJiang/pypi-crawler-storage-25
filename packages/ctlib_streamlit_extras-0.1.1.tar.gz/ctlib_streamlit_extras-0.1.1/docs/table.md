# Table

`ste.table(...)` 用于渲染表格数据，前端基于 MUI X Data Grid。
当前支持传入 `pandas.DataFrame`、`list[dict]` 和 `list[pydantic.BaseModel]`。
这个组件的前端只负责展示：分页、修改 page size、排序等动作会立刻上报给
Python，并等待 Streamlit rerun 后由后端传入新的数据。

```python
import pandas as pd
import streamlit as st
import ctlib_streamlit_extras as ste


def open_order(row: dict[str, object]) -> None:
    st.session_state["selected_order"] = row


def page_changed(page: int, page_size: int) -> None:
    st.session_state["table_page"] = page
    st.session_state["table_page_size"] = page_size


def sort_changed(column: str | None, direction: str | None) -> None:
    st.session_state["table_sort_column"] = column
    st.session_state["table_sort_direction"] = direction
    st.session_state["table_page"] = 1


orders = pd.DataFrame(
    [
        {
            "id": "A-1001",
            "customer": "Ada",
            "amount": 128.5,
            "profile": ste.LinkValue("https://example.com/ada", "Ada profile"),
            "status": "paid",
        },
        {
            "id": "A-1002",
            "customer": "Grace",
            "amount": 86.25,
            "profile": {"url": "https://example.com/grace", "label": "Grace profile"},
            "status": "pending",
        },
    ]
)

state = ste.table(
    orders,
    key="orders_table",
    column_order=["id", "customer", "amount", "status", "profile", "actions"],
    column_config={
        "id": ste.TextColumn("Order"),
        "customer": ste.TextColumn("Customer"),
        "amount": ste.NumberColumn("Amount", precision=2, prefix="$"),
        "profile": ste.LinkColumn("Profile", target="_blank", sortable=False),
        "status": ste.ChipColumn(
            "Status",
            chips={
                "paid": {"label": "Paid", "color": "success"},
                "pending": {"label": "Pending", "color": "warning", "variant": "outlined"},
            },
        ),
        "actions": ste.ButtonGroupColumn(
            "Actions",
            buttons=[
                ste.TableButton("Open", key="open", type="primary", on_click=open_order),
            ],
        ),
    },
    page=st.session_state.get("table_page", 1),
    page_size=st.session_state.get("table_page_size", 10),
    page_size_options=[10, 25, 50],
    total_rows=100,
    sort_column=st.session_state.get("table_sort_column"),
    sort_direction=st.session_state.get("table_sort_direction"),
    on_page_change=page_changed,
    on_sort_change=sort_changed,
    height=420,
)

if state.page_event is not None or state.sort_event is not None:
    st.rerun()
```

## Column Config

当前支持以下列配置类：

- `Column`：基础列配置，包含 label、width、help tooltip 元数据和 `sortable`。
- `TextColumn`：文本展示，支持可选的最大字符数和多行模式。
- `NumberColumn`：数字展示，支持固定小数位、前缀和后缀。
- `LinkColumn`：把单元格值渲染为链接。`target` 的语义与 HTML `<a>` 标签一致，
  可使用 `"_blank"`、`"_self"`、`"_parent"` 或 `"_top"`。链接单元格的值可以是
  URL 字符串、`ste.LinkValue(...)`，也可以是 mapping。mapping 中可用
  `url`、`href`、`link` 表示链接地址，用 `label`、`text`、`title`、`display`
  表示展示文本。
- `ButtonGroupColumn`：渲染一组独立按钮。每个 `TableButton` 的 callback 会收到当前行数据，类型是普通 `dict`。
- `ChipColumn`：使用 MUI Chip 展示值。`chips` 定义可用的 chip key 及其
  label、color、variant；`chip_func` 接收当前单元格的原始值，并返回一个
  `str` 类型的 chip key。默认 `chip_func` 直接返回原值，因此默认适合原始值已经是
  字符串 key 的列。如果 `chip_func` 返回了未在 `chips` 中定义的 key，Python 侧会抛出异常。

`TableButton` 未显式指定 `key` 时，会根据按钮 label 和按钮位置生成 key，
例如 `"Open"` 会生成 `"open_0"`。如果需要长期稳定的事件 id，建议显式传入
`key`。同一个 `ButtonGroupColumn` 内不允许重复的显式 key。

`column_order` 同时控制列顺序和可见性。若要添加数据源中不存在的操作列，
可以在 `column_config` 里配置一个 `ButtonGroupColumn`，并把它的 key
放进 `column_order`，例如 `"actions"`。

## 高度

`height` 控制表格的纵向布局：

- `height=420` 或任意正整数：组件固定高度，表格内部滚动。
- `height="content"`：组件高度跟随当前渲染行数增长，组件内部不做纵向滚动，由页面滚动。

## 事件

分页 callback 接收 `(page, page_size)`，其中 `page` 从 1 开始。用户修改 page size
选择器时，也会触发同一个 callback，并传入新的 `page_size`。

排序 callback 接收 `(column, direction)`。清除排序时，`column` 和 `direction`
都是 `None`；否则 `direction` 为 `"asc"` 或 `"desc"`。

按钮 callback 接收当前行数据，类型是普通 `dict`。

分页和排序都是服务端控制。前端不会在本地对数据做切片或排序；它始终渲染当前
`ste.table(...)` 调用传入的全部行。即使 `page_size=10`，但后端传入了 100 行，
前端也会展示这 100 行。后端知道完整结果数量时，应通过 `total_rows` 告诉前端，
这样底部页码区域才能显示正确的总页数。

由于 Streamlit 组件事件是在 `ste.table(...)` 返回时才可见，如果页面上方的数据查询、
排序或切片依赖这些事件写入的 `session_state`，通常需要在收到
`state.page_event` 或 `state.sort_event` 后调用 `st.rerun()`。这样下一轮 rerun
会用更新后的后端参数重新生成当前表格数据。

`ste.table(...)` 会返回 `TableState`，包含：

- `page`、`page_size`、`page_count`
- 当前运行由分页触发时的 `page_event`
- `sort_column`、`sort_direction`，以及当前运行由排序触发时的 `sort_event`
- 当前运行由行按钮触发时的 `button_event`
