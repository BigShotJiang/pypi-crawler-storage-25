# AGENTS

## Engineering Constraints

- When fixing bugs or behavioral issues, do not use defensive fallback patches as the primary solution.
- Do not rely on tricks, temporary workarounds, heuristic guards, or stopgap timeouts unless the user explicitly asks for a temporary mitigation.
- First identify the root cause, then implement a clean and durable fix that matches the actual lifecycle and state model of the code.
- Prefer simple and explicit state transitions over indirect inference or environment-based guesses.
- If a fully clean fix is not currently possible, state the blocker clearly instead of hiding it behind a defensive fallback.
