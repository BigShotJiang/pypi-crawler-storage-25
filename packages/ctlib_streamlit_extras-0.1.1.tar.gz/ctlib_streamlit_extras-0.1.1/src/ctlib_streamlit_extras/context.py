import typing
from contextvars import ContextVar

from pydantic import BaseModel, ConfigDict

_T = typing.TypeVar("_T", bound=BaseModel)

ACTIVE_CONTEXT_BINDINGS: ContextVar[tuple["ContextBinding", ...]] = ContextVar(
    "active_context_bindings",
    default=(),
)
CURRENT_CONTEXT_BINDINGS: ContextVar[tuple["ContextBinding", ...]] = ContextVar(
    "current_context_bindings",
    default=(),
)
CONTEXT_PROVIDER_INDEX: ContextVar[int] = ContextVar(
    "context_provider_index",
    default=0,
)


class ContextBinding(BaseModel):
    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    key: str
    context_type: type[BaseModel]


class ContextProvider:
    def __init__(self, context_type: type[BaseModel]):
        self.context_type = context_type
        self.binding: ContextBinding | None = None
        self._active_token = None

    def __enter__(self) -> "ContextProvider":
        # Provider keys are derived from declaration order within a single script run.
        # App() resets this counter before page registration so equivalent reruns
        # reproduce the same binding keys for the same provider structure.
        index = CONTEXT_PROVIDER_INDEX.get()
        CONTEXT_PROVIDER_INDEX.set(index + 1)
        self.binding = ContextBinding(
            key=f"{self.context_type.__module__}.{self.context_type.__qualname__}:{index}",
            context_type=self.context_type,
        )
        self._active_token = ACTIVE_CONTEXT_BINDINGS.set(
            ACTIVE_CONTEXT_BINDINGS.get() + (self.binding,)
        )
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        ACTIVE_CONTEXT_BINDINGS.reset(self._active_token)
        self._active_token = None


def _reset_context_providers() -> None:
    # Streamlit reruns rebuild provider scopes from top to bottom, so the provider
    # index must restart from zero to keep binding keys stable across reruns.
    ACTIVE_CONTEXT_BINDINGS.set(())
    CURRENT_CONTEXT_BINDINGS.set(())
    CONTEXT_PROVIDER_INDEX.set(0)


def use_context(context_type: type[_T]) -> _T:
    from ctlib_streamlit_extras.app import current_app

    app = current_app()
    for binding in reversed(CURRENT_CONTEXT_BINDINGS.get()):
        if binding.context_type is context_type:
            return typing.cast(_T, app.meta.context_objects[binding.key])
    raise LookupError(f"No active context found for {context_type.__qualname__}")
