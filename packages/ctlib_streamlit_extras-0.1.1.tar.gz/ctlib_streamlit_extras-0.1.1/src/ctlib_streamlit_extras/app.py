import logging
from collections.abc import Callable, Mapping
from contextvars import ContextVar
from typing import Literal

import streamlit as st
from pydantic import BaseModel, ConfigDict, Field
from streamlit.navigation.page import StreamlitPage
from streamlit.runtime.state.query_params import QueryParamsInput

from ctlib_streamlit_extras._state_common import framework_state_key
from ctlib_streamlit_extras.context import (
    ACTIVE_CONTEXT_BINDINGS,
    CURRENT_CONTEXT_BINDINGS,
    ContextBinding,
    _reset_context_providers,
)
from ctlib_streamlit_extras.middleware import ACTIVE_MIDDLEWARES, Middleware
from ctlib_streamlit_extras.page_state import Omit, Page, RoutePredicate

CURRENT_APP: ContextVar["App | None"] = ContextVar("current_app", default=None)
META_STATE_KEY = framework_state_key("meta")
logger = logging.getLogger(__name__)


class Route(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    path: str
    page_cls: type[Page]
    title: str | None = None
    icon: str | None = None
    default: bool = False
    middlewares: list[Middleware] = Field(default_factory=list)
    context_bindings: list[ContextBinding] = Field(default_factory=list)

    @property
    def resolved_title(self) -> str:
        return self.title or self.page_cls.title


class Meta(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    page_objects: dict[str, StreamlitPage] = Field(default_factory=dict)
    page_states: dict[str, BaseModel] = Field(default_factory=dict)
    current_context_keys: list[str] = Field(default_factory=list)
    context_objects: dict[str, BaseModel] = Field(default_factory=dict)


class App:
    def __init__(self, *, enable_page_groups: bool = True, debug: bool = False):
        if ACTIVE_CONTEXT_BINDINGS.get():
            raise RuntimeError(
                "App() cannot be created inside an active ContextProvider scope. "
                "Create the App first, then register pages inside ContextProvider blocks."
            )
        _reset_context_providers()
        self.routes: dict[str, Route] = {}
        self.enable_page_groups = enable_page_groups
        self.debug = debug

    @property
    def meta(self) -> Meta:
        if META_STATE_KEY not in st.session_state:
            st.session_state[META_STATE_KEY] = Meta()
        return st.session_state[META_STATE_KEY]

    def register_page(
        self,
        path: str,
        page_cls: type[Page],
        *,
        title: str | None = None,
        icon: str | None = None,
        default: bool = False,
        middlewares: list[Middleware] | None = None,
    ) -> None:
        if not path:
            raise ValueError("path must be non-empty")
        if path in self.routes:
            raise ValueError(f"Duplicate route path: {path}")

        self.routes[path] = Route(
            path=path,
            page_cls=page_cls,
            title=title,
            icon=icon,
            default=default,
            middlewares=[*ACTIVE_MIDDLEWARES.get(), *(middlewares or [])],
            context_bindings=[*ACTIVE_CONTEXT_BINDINGS.get()],
        )

    def get_streamlit_page(self, path: str) -> StreamlitPage:
        return self.meta.page_objects[path]

    def switch_page(
        self,
        path: str,
        *,
        query_params: QueryParamsInput | None = None,
    ) -> None:
        st.switch_page(self.get_streamlit_page(path), query_params=query_params)

    def cleanup_inactive_page_states(self, route: Route) -> None:
        stale_paths = [path for path in self.meta.page_states if path != route.path]
        for path in stale_paths:
            self.meta.page_states.pop(path, None)

    def cleanup_inactive_contexts(self, route: Route) -> None:
        active_keys = {binding.key for binding in route.context_bindings}
        stale_keys = [
            key for key in self.meta.current_context_keys if key not in active_keys
        ]
        for key in stale_keys:
            self.meta.context_objects.pop(key, None)

    def ensure_contexts(self, route: Route) -> None:
        for binding in route.context_bindings:
            if binding.key not in self.meta.context_objects:
                self.meta.context_objects[binding.key] = binding.context_type()
        self.meta.current_context_keys = [binding.key for binding in route.context_bindings]

    def get_page_state(self, route: Route) -> BaseModel:
        state = self.meta.page_states.get(route.path)
        state_type = route.page_cls.get_state_type()

        if state is None:
            state = route.page_cls.create_state()
        elif isinstance(state, state_type):
            pass
        elif isinstance(state, BaseModel):
            state = state_type.model_validate(state.model_dump())
        elif isinstance(state, Mapping):
            state = state_type.model_validate(dict(state))
        else:
            raise TypeError(
                f"{route.path} is bound to {state.__class__.__name__}, "
                f"expected {state_type.__name__}"
            )

        self.meta.page_states[route.path] = state
        return state

    def is_route_available(self, route: Route) -> bool:
        return self.resolve_route_predicate(route.page_cls.available, route)

    def resolve_route_predicate(
        self,
        predicate: RoutePredicate,
        route: Route,
    ) -> bool:
        if callable(predicate):
            return bool(predicate(self, route))
        return bool(predicate)

    def route_visibility(self, route: Route) -> Literal["visible", "hidden"]:
        visible = route.page_cls.visible
        if visible is Omit:
            route_visible = self.is_route_available(route)
        else:
            route_visible = self.resolve_route_predicate(visible, route)
        return "visible" if route_visible else "hidden"

    def build_route_handler(self, route: Route) -> Callable[[], None]:
        def run_route() -> None:
            app_token = CURRENT_APP.set(self)
            self.cleanup_inactive_page_states(route)
            self.cleanup_inactive_contexts(route)
            self.ensure_contexts(route)

            token = CURRENT_CONTEXT_BINDINGS.set(tuple(route.context_bindings))
            try:
                page = route.page_cls(self.get_page_state(route))
                handler: Callable[[], None] = page
                for middleware in reversed(route.middlewares):
                    handler = middleware(handler, route)
                handler()
                self.meta.page_states[route.path] = page.state
            except Exception:
                if self.debug:
                    raise
                logger.exception("Unhandled exception while executing route %s", route.path)
                st.error("😵 Oops, something went wrong.")
            finally:
                CURRENT_CONTEXT_BINDINGS.reset(token)
                CURRENT_APP.reset(app_token)

        return run_route

    def build_navigation(self):
        streamlit_pages: list[StreamlitPage] = []
        page_objects: dict[str, StreamlitPage] = {}
        grouped_pages: dict[str, list[StreamlitPage]] = {}

        for route in self.routes.values():
            if not self.is_route_available(route):
                continue

            streamlit_page = st.Page(
                self.build_route_handler(route),
                title=route.resolved_title,
                icon=route.icon,
                url_path=route.path,
                default=route.default,
                visibility=self.route_visibility(route),
            )
            streamlit_pages.append(streamlit_page)
            page_objects[route.path] = streamlit_page
            if self.enable_page_groups and route.page_cls.group:
                grouped_pages.setdefault(route.page_cls.group, []).append(streamlit_page)

        self.meta.page_objects = page_objects
        if self.enable_page_groups and grouped_pages:
            navigation_pages: list[StreamlitPage] | dict[str, list[StreamlitPage]]
            ungrouped_pages = [
                page
                for route, page in (
                    (route, page_objects[route.path])
                    for route in self.routes.values()
                    if route.path in page_objects
                )
                if not route.page_cls.group
            ]
            navigation_pages = dict(grouped_pages)
            if ungrouped_pages:
                navigation_pages = {"Pages": ungrouped_pages, **navigation_pages}
            return st.navigation(navigation_pages)

        return st.navigation(streamlit_pages)


def current_app() -> App:
    app = CURRENT_APP.get()
    if app is None:
        raise LookupError("No current App is bound in this execution context")
    return app
