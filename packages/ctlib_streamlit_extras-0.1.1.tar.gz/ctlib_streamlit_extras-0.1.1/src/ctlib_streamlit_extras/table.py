from __future__ import annotations

import math
import re
from dataclasses import asdict, dataclass, field, is_dataclass
from datetime import date, datetime, time
from decimal import Decimal
from typing import Any, Callable, Literal, Mapping, Sequence

import pandas as pd
import streamlit as st
import streamlit.components.v2 as components
from pydantic import BaseModel

from ctlib_streamlit_extras._component_common import (
    _DIST_DIR,
    component_identity,
    load_css,
)
from ctlib_streamlit_extras._state_common import component_state_key

_table_component = components.component(
    "ctlib_table",
    js=(_DIST_DIR / "table.js").read_text(encoding="utf-8"),
    css=load_css("table.css"),
    isolate_styles=True,
)

ColumnWidth = int | Literal["small", "medium", "large"]
ButtonType = Literal["primary", "secondary", "tertiary"]
ChipColor = Literal["default", "primary", "secondary", "success", "error", "info", "warning"]
ChipVariant = Literal["filled", "outlined"]
SortDirection = Literal["asc", "desc"]
TableHeight = int | Literal["content"]
LinkTarget = Literal["_self", "_blank", "_parent", "_top"]


@dataclass(frozen=True)
class Column:
    label: str | None = None
    width: ColumnWidth | None = None
    help: str | None = None
    sortable: bool = True


@dataclass(frozen=True)
class TextColumn(Column):
    max_chars: int | None = None
    multiline: bool = False


@dataclass(frozen=True)
class NumberColumn(Column):
    precision: int | None = None
    prefix: str = ""
    suffix: str = ""


@dataclass(frozen=True)
class LinkColumn(Column):
    display_text: str | None = None
    target: LinkTarget = "_blank"


@dataclass(frozen=True)
class LinkValue:
    url: str
    label: str | None = None
    target: LinkTarget | None = None


@dataclass(frozen=True)
class TableButton:
    label: str
    on_click: Callable[..., Any] | None = None
    key: str | None = None
    type: ButtonType = "secondary"
    icon: str | None = None
    disabled: bool = False
    args: tuple[Any, ...] = ()
    kwargs: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ButtonGroupColumn(Column):
    buttons: Sequence[TableButton | Mapping[str, Any]] = ()


def _default_chip_func(value: Any) -> str:
    return value


@dataclass(frozen=True)
class ChipColumn(Column):
    chips: Mapping[str, str | Mapping[str, Any]] = field(default_factory=dict)
    chip_func: Callable[[Any], str] = _default_chip_func


@dataclass(frozen=True)
class TablePageEvent:
    page: int
    page_size: int


@dataclass(frozen=True)
class TableSortEvent:
    column: str | None
    direction: SortDirection | None


@dataclass(frozen=True)
class TableButtonEvent:
    column: str
    button: str
    row_index: Any
    row_position: int
    row: dict[str, Any]


@dataclass(frozen=True)
class TableState:
    page: int
    page_size: int
    page_count: int
    sort_column: str | None = None
    sort_direction: SortDirection | None = None
    page_event: TablePageEvent | None = None
    sort_event: TableSortEvent | None = None
    button_event: TableButtonEvent | None = None


@dataclass(frozen=True)
class _NormalizedTableData:
    columns: list[str]
    row_indices: list[Any]
    rows: list[dict[str, Any]]
    callback_rows: list[dict[str, Any]]


def _noop_callback() -> None:
    return None


def _is_dataframe(value: Any) -> bool:
    return hasattr(value, "columns") and hasattr(value, "iloc") and hasattr(value, "to_dict")


def _table_type_error() -> TypeError:
    return TypeError(
        "ste.table only accepts pandas.DataFrame-like data, list[dict], or list[pydantic.BaseModel]."
    )


def _normalize_column_key(value: Any) -> str:
    return str(value)


def _column_label(column_key: str, config: Column | None) -> str:
    if config is not None and config.label is not None:
        return config.label
    return column_key


def _resolve_width(width: ColumnWidth | None) -> int | None:
    if width is None:
        return None
    if isinstance(width, int):
        return width
    return {
        "small": 90,
        "medium": 180,
        "large": 360,
    }[width]


def _unwrap_scalar(value: Any) -> tuple[bool, Any]:
    if value is None:
        return True, None
    try:
        if pd.isna(value):
            return True, None
    except (TypeError, ValueError):
        pass
    if hasattr(value, "item") and callable(value.item):
        try:
            value = value.item()
        except (TypeError, ValueError):
            pass
    return False, value


def _json_value(value: Any) -> Any:
    is_null, value = _unwrap_scalar(value)
    if is_null:
        return None

    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            return None
        return value
    if isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, (datetime, date, time)):
        return value.isoformat()
    if isinstance(value, Mapping):
        return {str(key): _json_value(item) for key, item in value.items()}
    if is_dataclass(value) and not isinstance(value, type):
        return _json_value(asdict(value))
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return [_json_value(item) for item in value]
    link_payload = _object_link_payload(value)
    if link_payload is not None:
        return link_payload
    return str(value)


def _object_link_payload(value: Any) -> dict[str, Any] | None:
    url = None
    for attr in ("url", "href", "link"):
        if hasattr(value, attr):
            url = getattr(value, attr)
            break
    if url is None:
        return None

    payload: dict[str, Any] = {"url": _json_value(url)}
    for attr in ("label", "text", "title", "display"):
        if hasattr(value, attr):
            label = getattr(value, attr)
            if label is not None:
                payload["label"] = _json_value(label)
                break
    if hasattr(value, "target"):
        target = getattr(value, "target")
        if target is not None:
            payload["target"] = _json_value(target)
    return payload


def _row_payload(value: Any) -> Any:
    is_null, value = _unwrap_scalar(value)
    if is_null:
        return None
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, (datetime, date, time)):
        return value.isoformat()
    return value


def _chip_cell_value(value: Any, config: ChipColumn, column_key: str) -> str | None:
    is_null, value = _unwrap_scalar(value)
    if is_null:
        return None

    chip_key = config.chip_func(value)
    if not isinstance(chip_key, str):
        raise TypeError(
            f"ChipColumn {column_key!r} chip_func must return a string chip key."
        )
    if chip_key not in config.chips:
        raise ValueError(
            f"ChipColumn {column_key!r} resolved unknown chip key {chip_key!r}."
        )
    return chip_key


def _cell_json_value(value: Any, column_key: str, config: Column | None) -> Any:
    if isinstance(config, ChipColumn):
        return _chip_cell_value(value, config, column_key)
    return _json_value(value)


def _records_from_dataframe(
    data: Any,
    column_config: Mapping[str, Column | None],
) -> _NormalizedTableData:
    if not _is_dataframe(data):
        raise _table_type_error()

    raw_columns = list(data.columns)
    columns = [_normalize_column_key(column) for column in raw_columns]
    if len(set(columns)) != len(columns):
        raise ValueError("ste.table requires unique column names after converting them to strings.")

    rows: list[dict[str, Any]] = []
    callback_rows: list[dict[str, Any]] = []
    for position in range(len(data)):
        row = data.iloc[position]
        callback_rows.append(
            {
                column_key: _row_payload(row[raw_column])
                for raw_column, column_key in zip(raw_columns, columns)
            }
        )
        rows.append(
            {
                "__ctlib_row_id": str(position),
                "__ctlib_row_position": position,
                "__ctlib_row_index": _json_value(data.index[position]),
                **{
                    column_key: _cell_json_value(
                        row[raw_column],
                        column_key,
                        column_config.get(column_key),
                    )
                    for raw_column, column_key in zip(raw_columns, columns)
                },
            }
        )

    return _NormalizedTableData(
        columns=columns,
        row_indices=list(data.index),
        rows=rows,
        callback_rows=callback_rows,
    )


def _mapping_row(value: Any) -> Mapping[Any, Any] | None:
    if isinstance(value, BaseModel):
        return value.model_dump(mode="python")
    if isinstance(value, Mapping):
        return value
    return None


def _records_from_mapping_rows(
    records: Sequence[Mapping[Any, Any]],
    column_config: Mapping[str, Column | None],
) -> _NormalizedTableData:
    raw_columns: list[Any] = []
    seen_columns: set[Any] = set()
    for record in records:
        for raw_column in record.keys():
            if raw_column not in seen_columns:
                seen_columns.add(raw_column)
                raw_columns.append(raw_column)

    columns = [_normalize_column_key(column) for column in raw_columns]
    if len(set(columns)) != len(columns):
        raise ValueError("ste.table requires unique column names after converting them to strings.")

    row_indices = list(range(len(records)))
    rows: list[dict[str, Any]] = []
    callback_rows: list[dict[str, Any]] = []
    for position, record in enumerate(records):
        callback_row = {
            column_key: _row_payload(record.get(raw_column))
            for raw_column, column_key in zip(raw_columns, columns)
        }
        callback_rows.append(callback_row)
        rows.append(
            {
                "__ctlib_row_id": str(position),
                "__ctlib_row_position": position,
                "__ctlib_row_index": _json_value(row_indices[position]),
                **{
                    column_key: _cell_json_value(
                        record.get(raw_column),
                        column_key,
                        column_config.get(column_key),
                    )
                    for raw_column, column_key in zip(raw_columns, columns)
                },
            }
        )

    return _NormalizedTableData(
        columns=columns,
        row_indices=row_indices,
        rows=rows,
        callback_rows=callback_rows,
    )


def _normalize_table_data(
    data: Any,
    column_config: Mapping[str, Column | None],
) -> _NormalizedTableData:
    if _is_dataframe(data):
        return _records_from_dataframe(data, column_config)

    if isinstance(data, list):
        records: list[Mapping[Any, Any]] = []
        for item in data:
            record = _mapping_row(item)
            if record is None:
                raise _table_type_error()
            records.append(record)
        return _records_from_mapping_rows(records, column_config)

    raise _table_type_error()


def _normalize_column_config(
    column_config: Mapping[Any, Column | str | None] | None,
) -> dict[str, Column | None]:
    if not column_config:
        return {}

    normalized: dict[str, Column | None] = {}
    for key, config in column_config.items():
        normalized_key = _normalize_column_key(key)
        if config is None:
            normalized[normalized_key] = None
        elif isinstance(config, str):
            normalized[normalized_key] = Column(label=config)
        elif isinstance(config, Column):
            normalized[normalized_key] = config
        else:
            raise TypeError(
                "column_config values must be Column instances, strings, or None."
            )
    return normalized


def _display_columns(
    *,
    dataframe_columns: Sequence[str],
    column_order: Sequence[Any] | None,
    column_config: Mapping[str, Column | None],
) -> list[str]:
    if column_order is None:
        ordered = list(dataframe_columns)
        for key, config in column_config.items():
            if key not in ordered and isinstance(config, ButtonGroupColumn):
                ordered.append(key)
    else:
        ordered = [_normalize_column_key(column) for column in column_order]

    # Keep columns unless explicitly hidden (config set to None).
    # Columns absent from column_config are shown with default settings.
    return [
        column
        for column in ordered
        if column not in column_config or column_config[column] is not None
    ]


def _button_key(label: str, index: int, explicit_key: str | None) -> str:
    if explicit_key:
        return explicit_key
    slug = re.sub(r"[^a-zA-Z0-9_]+", "_", label.strip()).strip("_").lower()
    return f"{slug or 'button'}_{index}"


def _normalize_table_button(
    value: TableButton | Mapping[str, Any],
    index: int,
) -> TableButton:
    if isinstance(value, TableButton):
        return value
    if isinstance(value, Mapping):
        if "label" not in value:
            raise ValueError("ButtonGroupColumn button mappings must include a 'label'.")
        return TableButton(
            label=str(value["label"]),
            on_click=value.get("on_click"),
            key=None if value.get("key") is None else str(value.get("key")),
            type=value.get("type", "secondary"),
            icon=value.get("icon"),
            disabled=bool(value.get("disabled", False)),
            args=tuple(value.get("args", ())),
            kwargs=value.get("kwargs", {}),
        )
    raise TypeError("ButtonGroupColumn buttons must be TableButton instances or mappings.")


def _serialize_chip_config(config: ChipColumn) -> dict[str, Any]:
    chips: dict[str, dict[str, Any]] = {}
    for chip_key, raw_chip in config.chips.items():
        if not isinstance(chip_key, str):
            raise TypeError("ChipColumn chips keys must be strings.")
        if isinstance(raw_chip, str):
            chips[chip_key] = {
                "label": raw_chip,
                "color": "default",
                "variant": "filled",
            }
        elif isinstance(raw_chip, Mapping):
            chips[chip_key] = {
                "label": raw_chip.get("label", chip_key),
                "color": raw_chip.get("color", "default"),
                "variant": raw_chip.get("variant", "filled"),
            }
        else:
            raise TypeError("ChipColumn chips must map values to strings or mappings.")
    return chips


def _validate_column_configs(column_config: Mapping[str, Column | None]) -> None:
    for field_name, config in column_config.items():
        if config is None:
            continue
        if isinstance(config, ChipColumn):
            _serialize_chip_config(config)
            continue
        if isinstance(config, ButtonGroupColumn):
            seen_button_keys: set[str] = set()
            for index, raw_button in enumerate(config.buttons):
                button = _normalize_table_button(raw_button, index)
                button_key = _button_key(button.label, index, button.key)
                if button_key in seen_button_keys:
                    raise ValueError(
                        f"ButtonGroupColumn {field_name!r} contains duplicate "
                        f"button key {button_key!r}."
                    )
                seen_button_keys.add(button_key)


def _serialize_columns(
    *,
    display_columns: Sequence[str],
    column_config: Mapping[str, Column | None],
    callback_registry: dict[tuple[str, str], TableButton],
) -> list[dict[str, Any]]:
    serialized: list[dict[str, Any]] = []
    for field_name in display_columns:
        config = column_config.get(field_name)
        if config is None:
            config = TextColumn()

        column_type = "text"
        payload: dict[str, Any] = {}

        if isinstance(config, NumberColumn):
            column_type = "number"
            payload = {
                "precision": config.precision,
                "prefix": config.prefix,
                "suffix": config.suffix,
            }
        elif isinstance(config, LinkColumn):
            column_type = "link"
            payload = {
                "display_text": config.display_text,
                "target": config.target,
            }
        elif isinstance(config, ButtonGroupColumn):
            column_type = "button_group"
            buttons: list[dict[str, Any]] = []
            seen_button_keys: set[str] = set()
            for index, raw_button in enumerate(config.buttons):
                button = _normalize_table_button(raw_button, index)
                button_key = _button_key(button.label, index, button.key)
                if button_key in seen_button_keys:
                    raise ValueError(
                        f"ButtonGroupColumn {field_name!r} contains duplicate "
                        f"button key {button_key!r}."
                    )
                seen_button_keys.add(button_key)
                callback_registry[(field_name, button_key)] = button
                buttons.append(
                    {
                        "key": button_key,
                        "label": button.label,
                        "type": button.type,
                        "icon": button.icon,
                        "disabled": button.disabled,
                    }
                )
            payload = {"buttons": buttons}
        elif isinstance(config, ChipColumn):
            column_type = "chip"
            payload = {"chips": _serialize_chip_config(config)}
        elif isinstance(config, TextColumn):
            payload = {
                "max_chars": config.max_chars,
                "multiline": config.multiline,
            }
        elif not isinstance(config, Column):
            raise TypeError("Unsupported column configuration.")

        column: dict[str, Any] = {
            "field": field_name,
            "headerName": _column_label(field_name, config),
            "type": column_type,
            "help": config.help,
            "width": _resolve_width(config.width),
            "sortable": config.sortable and column_type != "button_group",
            "config": payload,
        }
        serialized.append(column)
    return serialized


def _page_size_options(
    options: Sequence[int],
    current_page_size: int,
) -> list[int]:
    normalized: list[int] = []
    for option in [*options, current_page_size]:
        option = int(option)
        if option > 0 and option not in normalized:
            normalized.append(option)
    normalized.sort()
    return normalized


def _normalize_height(height: TableHeight) -> tuple[Literal["fixed", "content"], int | None]:
    if height == "content":
        return "content", None
    height_value = int(height)
    if height_value <= 0:
        raise ValueError("height must be a positive integer or 'content'.")
    return "fixed", height_value


def _dispatch_page_event(
    *,
    identity: str,
    event: Any,
    on_page_change: Callable[..., Any] | None,
    page_change_args: tuple[Any, ...] | None,
    page_change_kwargs: Mapping[str, Any] | None,
) -> TablePageEvent | None:
    if not isinstance(event, Mapping):
        return None

    event_id = event.get("event_id")
    if event_id is None:
        return None

    last_event_key = component_state_key(identity, "table_last_page_event")
    if st.session_state.get(last_event_key) == event_id:
        return None

    page = int(event.get("page", 1))
    page_size = int(event.get("page_size", 10))
    st.session_state[last_event_key] = event_id

    if on_page_change is not None:
        on_page_change(
            page,
            page_size,
            *(page_change_args or ()),
            **dict(page_change_kwargs or {}),
        )

    return TablePageEvent(page=page, page_size=page_size)


def _normalize_sort_direction(value: Any) -> SortDirection | None:
    if value in ("asc", "desc"):
        return value
    return None


def _dispatch_sort_event(
    *,
    identity: str,
    event: Any,
    on_sort_change: Callable[..., Any] | None,
    sort_change_args: tuple[Any, ...] | None,
    sort_change_kwargs: Mapping[str, Any] | None,
) -> TableSortEvent | None:
    if not isinstance(event, Mapping):
        return None

    event_id = event.get("event_id")
    if event_id is None:
        return None

    last_event_key = component_state_key(identity, "table_last_sort_event")
    if st.session_state.get(last_event_key) == event_id:
        return None

    column = event.get("column")
    column = str(column) if column is not None else None
    direction = _normalize_sort_direction(event.get("direction"))
    if column is None:
        direction = None

    st.session_state[last_event_key] = event_id

    if on_sort_change is not None:
        on_sort_change(
            column,
            direction,
            *(sort_change_args or ()),
            **dict(sort_change_kwargs or {}),
        )

    return TableSortEvent(column=column, direction=direction)


def _dispatch_button_event(
    *,
    identity: str,
    event: Any,
    row_indices: Sequence[Any],
    callback_rows: Sequence[dict[str, Any]],
    callback_registry: Mapping[tuple[str, str], TableButton],
) -> TableButtonEvent | None:
    if not isinstance(event, Mapping):
        return None

    event_id = event.get("event_id")
    if event_id is None:
        return None

    last_event_key = component_state_key(identity, "table_last_button_event")
    if st.session_state.get(last_event_key) == event_id:
        return None

    column = str(event.get("column", ""))
    button_key = str(event.get("button", ""))
    try:
        row_position = int(event.get("row_position"))
    except (TypeError, ValueError):
        return None

    if row_position < 0 or row_position >= len(row_indices):
        return None

    button = callback_registry.get((column, button_key))
    if button is None:
        return None

    row = callback_rows[row_position]
    st.session_state[last_event_key] = event_id
    if button.on_click is not None:
        button.on_click(row, *button.args, **dict(button.kwargs))

    return TableButtonEvent(
        column=column,
        button=button_key,
        row_index=row_indices[row_position],
        row_position=row_position,
        row=row,
    )


def table(
    data: Any,
    key: str | None = None,
    *,
    column_order: Sequence[Any] | None = None,
    column_config: Mapping[Any, Column | str | None] | None = None,
    page_size: int = 10,
    page_size_options: Sequence[int] = (10, 25, 50, 100),
    page: int = 1,
    total_rows: int | None = None,
    on_page_change: Callable[..., Any] | None = None,
    page_change_args: tuple[Any, ...] | None = None,
    page_change_kwargs: Mapping[str, Any] | None = None,
    sort_column: Any | None = None,
    sort_direction: SortDirection | None = None,
    on_sort_change: Callable[..., Any] | None = None,
    sort_change_args: tuple[Any, ...] | None = None,
    sort_change_kwargs: Mapping[str, Any] | None = None,
    height: TableHeight = 420,
    width: Literal["stretch", "content"] | int = "stretch",
) -> TableState:
    identity = component_identity(key=key, prefix="ctlib_table")
    normalized_config = _normalize_column_config(column_config)
    _validate_column_configs(normalized_config)
    normalized_data = _normalize_table_data(data, normalized_config)
    displayed_columns = _display_columns(
        dataframe_columns=normalized_data.columns,
        column_order=column_order,
        column_config=normalized_config,
    )

    callback_registry: dict[tuple[str, str], TableButton] = {}
    serialized_columns = _serialize_columns(
        display_columns=displayed_columns,
        column_config=normalized_config,
        callback_registry=callback_registry,
    )

    current_page = int(page)
    current_page_size = int(page_size)
    current_sort_column = None if sort_column is None else _normalize_column_key(sort_column)
    current_sort_direction = _normalize_sort_direction(sort_direction)
    if current_sort_column is None:
        current_sort_direction = None
    row_count = len(normalized_data.rows) if total_rows is None else max(int(total_rows), 0)
    page_count = max(1, math.ceil(row_count / max(current_page_size, 1)))
    height_mode, height_value = _normalize_height(height)

    result = _table_component(
        key=identity,
        data={
            "component_id": identity,
            "rows": normalized_data.rows,
            "columns": serialized_columns,
            "page": current_page,
            "page_size": current_page_size,
            "page_size_options": _page_size_options(page_size_options, current_page_size),
            "row_count": row_count,
            "sort_column": current_sort_column,
            "sort_direction": current_sort_direction,
            "height_mode": height_mode,
            "height": height_value,
        },
        width=width,
        height=height_value if height_mode == "fixed" else "content",
        on_page_change_change=_noop_callback,
        on_sort_change_change=_noop_callback,
        on_button_click_change=_noop_callback,
    )

    page_event = _dispatch_page_event(
        identity=identity,
        event=getattr(result, "page_change", None),
        on_page_change=on_page_change,
        page_change_args=page_change_args,
        page_change_kwargs=page_change_kwargs,
    )
    sort_event = _dispatch_sort_event(
        identity=identity,
        event=getattr(result, "sort_change", None),
        on_sort_change=on_sort_change,
        sort_change_args=sort_change_args,
        sort_change_kwargs=sort_change_kwargs,
    )
    button_event = _dispatch_button_event(
        identity=identity,
        event=getattr(result, "button_click", None),
        row_indices=normalized_data.row_indices,
        callback_rows=normalized_data.callback_rows,
        callback_registry=callback_registry,
    )

    return TableState(
        page=current_page,
        page_size=current_page_size,
        page_count=page_count,
        sort_column=current_sort_column,
        sort_direction=current_sort_direction,
        page_event=page_event,
        sort_event=sort_event,
        button_event=button_event,
    )
