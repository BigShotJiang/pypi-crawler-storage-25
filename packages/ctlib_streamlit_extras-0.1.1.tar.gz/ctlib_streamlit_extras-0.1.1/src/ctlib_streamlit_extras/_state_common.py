STATE_KEY_PREFIX = "__ctlib_streamlit_extras"


def framework_state_key(*parts: str) -> str:
    suffix = ".".join(part for part in parts if part)
    if not suffix:
        return STATE_KEY_PREFIX
    return f"{STATE_KEY_PREFIX}.{suffix}"


def component_state_key(identity: str, name: str) -> str:
    return framework_state_key(identity, name)
