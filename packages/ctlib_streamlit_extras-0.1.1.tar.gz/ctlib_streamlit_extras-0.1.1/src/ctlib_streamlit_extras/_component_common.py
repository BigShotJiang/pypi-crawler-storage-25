import hashlib
import inspect
import json
from pathlib import Path

_DIST_DIR = Path(__file__).parent / "frontend" / "dist"


def load_css(filename: str = "button.css") -> str:
    css_path = _DIST_DIR / filename
    if not css_path.exists():
        raise RuntimeError(
            "ctlib-streamlit-extras frontend assets are missing. "
            "Build the frontend bundle before importing the package."
        )
    return "/* ctlib inline css */\n" + css_path.read_text(encoding="utf-8")


def component_identity(*, key: str | None, prefix: str = "ctlib_component") -> str:
    if key is not None:
        return str(key)

    frame = inspect.currentframe()
    try:
        component_frame = frame.f_back if frame is not None else None
        caller_frame = component_frame.f_back if component_frame is not None else None
        if caller_frame is None:
            return f"{prefix}_unknown"

        payload = {
            "file": caller_frame.f_code.co_filename,
            "function": caller_frame.f_code.co_name,
            "line": caller_frame.f_lineno,
        }
    finally:
        del frame

    digest = hashlib.sha1(json.dumps(payload, sort_keys=True).encode()).hexdigest()
    return f"{prefix}_{digest}"
