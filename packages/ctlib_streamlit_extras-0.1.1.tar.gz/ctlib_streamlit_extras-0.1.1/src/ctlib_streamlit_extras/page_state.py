import abc
import dataclasses
import functools
import types
import typing

import streamlit as st
from pydantic import BaseModel, ConfigDict

StateT = typing.TypeVar("StateT", bound=BaseModel)
RoutePredicate = bool | typing.Callable[["App", "Route"], bool]


@dataclasses.dataclass(frozen=True, slots=True)
class UrlParam:
    key: str | None = None

    def resolve_key(self, field_name: str) -> str:
        return self.key or field_name


class PageState(BaseModel):
    model_config = ConfigDict(
        validate_assignment=True,
        arbitrary_types_allowed=True,
    )

    @classmethod
    def __pydantic_init_subclass__(cls, **kwargs: typing.Any) -> None:
        super().__pydantic_init_subclass__(**kwargs)

        required_fields = [
            name for name, field in cls.model_fields.items() if field.is_required()
        ]
        if required_fields:
            fields = ", ".join(required_fields)
            raise TypeError(
                f"{cls.__name__} PageState fields must define defaults or default_factory: "
                f"{fields}"
            )

    @classmethod
    @functools.cache
    def url_param_fields(cls) -> dict[str, UrlParam]:
        fields: dict[str, UrlParam] = {}
        for name, field in cls.model_fields.items():
            for metadata in field.metadata:
                if isinstance(metadata, UrlParam):
                    fields[name] = metadata
                    break
        return fields

    @classmethod
    def from_url_params(cls) -> "typing.Self":
        data: dict[str, typing.Any] = {}
        for name, url_param in cls.url_param_fields().items():
            values = cls._read_url_param_values(name, url_param)
            if values:
                data[name] = cls._parse_url_param_value(name, values)

        state = cls.model_validate(data)
        state._prune_default_url_params(data)
        return state

    def _prune_default_url_params(self, present: dict[str, typing.Any]) -> None:
        url_fields = self.url_param_fields()
        for name in present:
            url_param = url_fields.get(name)
            if url_param is not None and self._field_value_equals_default(name):
                _delete_query_param(url_param.resolve_key(name))

    def __setattr__(self, name: str, value: typing.Any) -> None:
        super().__setattr__(name, value)

        url_param = self.url_param_fields().get(name)
        if url_param is None:
            return

        self._write_url_param_field(name, url_param)

    @classmethod
    def _read_url_param_values(cls, name: str, url_param: UrlParam) -> list[str]:
        return st.query_params.get_all(url_param.resolve_key(name))

    @classmethod
    def _parse_url_param_value(cls, name: str, values: list[str]) -> typing.Any:
        field = cls.model_fields[name]
        if _annotation_expects_multiple(field.annotation):
            return values

        return values[-1]

    def _write_url_param_field(self, name: str, url_param: UrlParam) -> None:
        field = type(self).model_fields[name]
        key = url_param.resolve_key(name)

        if self._field_value_equals_default(name):
            _delete_query_param(key)
            return

        serialized = self.model_dump(mode="json", include={name})[name]

        if serialized is None:
            _delete_query_param(key)
            return

        if _annotation_expects_multiple(field.annotation):
            if not isinstance(serialized, list):
                raise TypeError(
                    f"{self.__class__.__name__}.{name} is declared as a repeated URL param "
                    f"but serialized to {serialized.__class__.__name__}"
                )
            if not serialized:
                _delete_query_param(key)
                return
            st.query_params[key] = [_stringify_url_value(value) for value in serialized]
            return

        st.query_params[key] = _stringify_url_value(serialized)

    def _field_value_equals_default(self, name: str) -> bool:
        field = type(self).model_fields[name]
        return getattr(self, name) == field.get_default(call_default_factory=True)


class _OmitType:
    def __repr__(self) -> str:
        return "Omit"


Omit = _OmitType()
VisibleSetting = RoutePredicate | _OmitType


def _delete_query_param(key: str) -> None:
    try:
        del st.query_params[key]
    except KeyError:
        pass


def _annotation_expects_multiple(annotation: typing.Any) -> bool:
    origin = typing.get_origin(annotation)

    if origin is typing.Annotated:
        return _annotation_expects_multiple(typing.get_args(annotation)[0])

    if origin in (list, set, tuple, frozenset):
        return True

    if origin in (typing.Union, types.UnionType):
        return any(
            arg is not type(None) and _annotation_expects_multiple(arg)
            for arg in typing.get_args(annotation)
        )

    return False


def _stringify_url_value(value: typing.Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


class Page(abc.ABC, typing.Generic[StateT]):
    title = "Page"
    StateType: type[BaseModel] = PageState
    available: RoutePredicate = True
    visible: VisibleSetting = Omit
    group: str | None = None

    def __init_subclass__(cls, **kwargs) -> None:
        super().__init_subclass__(**kwargs)

        for base in getattr(cls, "__orig_bases__", ()):
            if typing.get_origin(base) is Page:
                args = typing.get_args(base)
                if not args:
                    break

                state_type = args[0]
                if not isinstance(state_type, type) or not issubclass(state_type, BaseModel):
                    raise TypeError(
                        f"{cls.__name__} must declare a pydantic BaseModel state type"
                    )
                cls.StateType = state_type
                break

    def __init__(self, state: StateT):
        self.state = state

    @classmethod
    def get_state_type(cls) -> type[StateT]:
        return typing.cast(type[StateT], cls.StateType)  # noqa

    @classmethod
    def create_state(cls) -> StateT:
        state_type = cls.get_state_type()
        if issubclass(state_type, PageState):
            return typing.cast(StateT, state_type.from_url_params())
        return state_type()

    @classmethod
    def create_default_state(cls) -> StateT:
        return cls.get_state_type()()

    def set_state_cb(self, patch: StateT):
        def callback() -> None:
            state_type = self.get_state_type()
            if not isinstance(patch, state_type):
                raise TypeError(
                    f"{self.__class__.__name__}.set_state_cb() expected {state_type.__name__}, "
                    f"got {patch.__class__.__name__}"
                )

            for key, value in patch.model_dump(exclude_unset=True).items():
                setattr(self.state, key, value)

        return callback

    def set_state(self, patch: StateT) -> None:
        self.set_state_cb(patch)()

    def replace_state_cb(self, next_state: StateT):
        def callback() -> None:
            state_type = self.get_state_type()
            if not isinstance(next_state, state_type):
                raise TypeError(
                    f"{self.__class__.__name__}.replace_state_cb() expected {state_type.__name__}, "
                    f"got {next_state.__class__.__name__}"
                )

            for key, value in next_state.model_dump().items():
                setattr(self.state, key, value)

        return callback

    def replace_state(self, next_state: StateT) -> None:
        self.replace_state_cb(next_state)()

    def reset_state_cb(self):
        def callback() -> None:
            self.replace_state(self.create_default_state())

        return callback

    def reset_state(self) -> None:
        self.reset_state_cb()()

    @abc.abstractmethod
    def render(self) -> None:
        raise NotImplementedError

    def __call__(self) -> None:
        self.render()
