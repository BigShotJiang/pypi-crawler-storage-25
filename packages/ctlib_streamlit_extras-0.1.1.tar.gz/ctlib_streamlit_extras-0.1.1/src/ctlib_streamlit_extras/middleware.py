import abc
from collections.abc import Callable
from contextvars import ContextVar
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ctlib_streamlit_extras.app import Route

ACTIVE_MIDDLEWARES: ContextVar[tuple["Middleware", ...]] = ContextVar(
    "active_middlewares",
    default=(),
)


class Middleware(abc.ABC):
    def __enter__(self) -> "Middleware":
        self._token = ACTIVE_MIDDLEWARES.set(ACTIVE_MIDDLEWARES.get() + (self,))
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        ACTIVE_MIDDLEWARES.reset(self._token)
        self._token = None

    @abc.abstractmethod
    def __call__(
        self,
        next_handler: Callable[[], None],
        route: "Route",
    ) -> Callable[[], None]:
        raise NotImplementedError


class MiddlewareChain(Middleware):
    def __init__(self, *middlewares: Middleware):
        self.middlewares = middlewares

    def __call__(
        self,
        next_handler: Callable[[], None],
        route: "Route",
    ) -> Callable[[], None]:
        handler = next_handler
        for middleware in reversed(self.middlewares):
            handler = middleware(handler, route)
        return handler
