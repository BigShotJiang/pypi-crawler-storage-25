from typing import Any, Literal

import streamlit as st
import streamlit.components.v2 as components

from ctlib_streamlit_extras._component_common import (
    _DIST_DIR,
    component_identity,
    load_css,
)
from ctlib_streamlit_extras._state_common import component_state_key

_button_component = components.component(
    "ctlib_button",
    js=(_DIST_DIR / "button.js").read_text(encoding="utf-8"),
    css=load_css(),
    isolate_styles=True,
)


def _handle_click(
    *,
    clicked_state_key: str,
    on_click: Any | None,
    args: tuple[Any, ...] | None,
    kwargs: dict[str, Any] | None,
) -> None:
    if on_click is not None:
        on_click(*(args or ()), **(kwargs or {}))
    st.session_state[clicked_state_key] = True


ButtonType = Literal["primary", "secondary", "tertiary"]
WidthMode = Literal["content", "stretch"]
ClickAction = Literal["trigger", "history_back"]


def _render_button(
    *,
    identity: str,
    label: str,
    help: str | None = None,
    on_click: Any | None = None,
    args: tuple[Any, ...] | None = None,
    kwargs: dict[str, Any] | None = None,
    type: ButtonType = "secondary",
    icon: str | None = None,
    disabled: bool = False,
    use_container_width: bool = False,
    width: WidthMode = "content",
    click_action: ClickAction = "trigger",
) -> bool:
    if use_container_width:
        width = "stretch"

    clicked_state_key = component_state_key(identity, "button_clicked")

    _button_component(
        key=identity,
        data={
            "label": label,
            "component_id": identity,
            "help": help,
            "button_type": type,
            "icon": icon,
            "disabled": disabled,
            "width": width,
            "click_action": click_action,
        },
        on_clicked_change=lambda: _handle_click(
            clicked_state_key=clicked_state_key,
            on_click=on_click,
            args=args,
            kwargs=kwargs,
        ),
    )

    return bool(st.session_state.pop(clicked_state_key, False))


def button(
    label: str,
    key: str | None = None,
    help: str | None = None,
    on_click: Any | None = None,
    args: tuple[Any, ...] | None = None,
    kwargs: dict[str, Any] | None = None,
    *,
    type: ButtonType = "secondary",
    icon: str | None = None,
    disabled: bool = False,
    use_container_width: bool = False,
    width: WidthMode = "content",
) -> bool:
    return _render_button(
        identity=component_identity(key=key, prefix="ctlib_button"),
        label=label,
        help=help,
        on_click=on_click,
        args=args,
        kwargs=kwargs,
        type=type,
        icon=icon,
        disabled=disabled,
        use_container_width=use_container_width,
        width=width,
    )


def back_button(
    label: str = "返回",
    key: str | None = None,
    *,
    type: ButtonType = "tertiary",
    icon: str | None = ":material/arrow_back:",
    disabled: bool = False,
    use_container_width: bool = False,
    width: WidthMode = "content",
) -> None:
    if use_container_width:
        width = "stretch"

    identity = component_identity(key=key, prefix="ctlib_back_button")

    _button_component(
        key=identity,
        data={
            "label": label,
            "component_id": identity,
            "help": None,
            "button_type": type,
            "icon": icon,
            "disabled": disabled,
            "width": width,
            "click_action": "history_back",
        },
    )
