import copy
import xlrd
import xlwt
from openpyxl.utils.datetime import to_excel
from openpyxl.cell.cell import NUMERIC_TYPES, TIME_TYPES, STRING_TYPES
BOOL_TYPE = bool

def get_type(value):
    if isinstance(value, NUMERIC_TYPES):
        dt = xlrd.XL_CELL_NUMBER
    elif isinstance(value, STRING_TYPES):
        dt = xlrd.XL_CELL_TEXT
    elif isinstance(value, TIME_TYPES):
        dt = xlrd.XL_CELL_DATE
        return to_excel(value), dt
    elif isinstance(value, BOOL_TYPE):
        dt = xlrd.XL_CELL_BOOLEAN
    else:
        return str(value), xlrd.XL_CELL_TEXT
    return value, dt

class Base(object):

    def __init__(self, sheet_writer, cell_node, value, data_type):
        self.sheet_writer = sheet_writer
        self.cell_node = cell_node
        self.value = value
        self.data_type = data_type

    @property
    def rdsheet(self):
        return self.sheet_writer.rdsheet

    @property
    def wtsheet(self):
        return self.sheet_writer.wtsheet

    @property
    def source_cell(self):
        return self.cell_node.sheet_cell

    @property
    def target_cell(self):
        return None

    @property
    def rdcolx(self):
        return self.cell_node.colx

    @property
    def rdrowx(self):
        return self.cell_node.rowx

    @property
    def wtcolx(self):
        return self.sheet_writer.box.right

    @property
    def wtrowx(self):
        return self.sheet_writer.box.bottom

    def apply_filters(self):
        if hasattr(self.cell_node, 'filters') and self.cell_node.filters:
            for (filter, args) in self.cell_node.filters:
                #print('args', args)
                filter(self, *args)
            self.cell_node.filters.clear()


class CellContextX(Base):

    def __init__(self, sheet_writer, cell_node, value, data_type):
        super().__init__(sheet_writer, cell_node, value, data_type)
        self._target_cell = None

    @property
    def target_cell(self):
        if self._target_cell:
            return self._target_cell
        source = self.source_cell
        wtcolx = self.wtcolx
        wtrowx = self.wtrowx
        value = self.value
        data_type = self.data_type
        # 调用 sheet_writer (即 SheetWriter 实例) 的 cell 方法，传入 cell_node
        target = self.sheet_writer.cell(source, self.rdrowx, self.rdcolx, wtrowx, wtcolx, value, data_type, self.cell_node)
        self._target_cell = target
        return self._target_cell

    def get_style(self):
        return self.target_cell.style

    def finish(self):
        self.apply_filters()



class CellContext(Base):

    def __init__(self, sheet_writer, cell_node, value, data_type):
        super().__init__(sheet_writer, cell_node, value, data_type)
        self._style = None

    def get_style(self):
        if self._style:
            return self._style
        source_cell = self.source_cell
        if source_cell.xf_index is not None:
            style = self.sheet_writer.style_list[source_cell.xf_index]
        else:
            style = self.style_list[0]
        self._style = copy.copy(style)
        if self.cell_node and hasattr(self.cell_node, 'cell_tag') and self.cell_node.cell_tag and self.cell_node.cell_tag.cell_lock:
            lock_val = str(self.cell_node.cell_tag.cell_lock).lower().strip()
            if lock_val in ['0', 'false', 'off', 'unlocked']:
                self._style.protection.cell_locked = 0
            elif lock_val in ['1', 'true', 'on', 'locked']:
                self._style.protection.cell_locked = 1

        if self.cell_node and getattr(self.cell_node, 'is_dollar_cell', False) and getattr(self.sheet_writer.bookwriter, 'dollar_cell_bg_color', None):
            bg_color = self.sheet_writer.bookwriter.dollar_cell_bg_color
            import xlwt
            self._style.pattern.pattern = xlwt.Pattern.SOLID_PATTERN
            if isinstance(bg_color, int):
                self._style.pattern.pattern_fore_colour = bg_color
            elif isinstance(bg_color, str):
                color_name = bg_color.lower().strip()
                if color_name in xlwt.Style.colour_map:
                    self._style.pattern.pattern_fore_colour = xlwt.Style.colour_map[color_name]
                else:
                    hex_map = {
                        'ffff00': 'yellow',
                        'ff0000': 'red',
                        '00ff00': 'green',
                        '0000ff': 'blue',
                        'ffffff': 'white',
                        '000000': 'black',
                    }
                    clean_hex = color_name.lstrip('#')
                    mapped_name = hex_map.get(clean_hex, 'yellow')
                    self._style.pattern.pattern_fore_colour = xlwt.Style.colour_map[mapped_name]
        return self._style

    def set_cell(self):
        cty = self.data_type
        if cty == xlrd.XL_CELL_EMPTY:
            return
        source_cell = self.source_cell
        rdrowx = self.rdrowx
        rdcolx = self.rdcolx
        wtrowx = self.wtrowx
        wtcolx = self.wtcolx
        value = self.value
        style = self.get_style()

        if value is None:
            value = source_cell.value
            cty = source_cell.ctype
        if cty is None:
            value, cty = get_type(value)

        wtrow = self.wtsheet.row(wtrowx)
        if cty == xlrd.XL_CELL_TEXT:
            if isinstance(value, (list, tuple)):
                wtrow.set_cell_rich_text(wtcolx, value, style)
            elif value.startswith('='):
                try:
                    if not self.cell_node.manual_formula:
                        from .utils import relocate_formula
                        value = relocate_formula(value, rdrowx, rdcolx, wtrowx, wtcolx, index_1=False)
                    formula = xlwt.Formula(value[1:])
                    wtrow.set_cell_formula(wtcolx, formula, style)
                except BaseException as e:
                    wtrow.set_cell_text(wtcolx, value, style)
            else:
                wtrow.set_cell_text(wtcolx, value, style)
        elif cty == xlrd.XL_CELL_NUMBER or cty == xlrd.XL_CELL_DATE:
            wtrow.set_cell_number(wtcolx, value, style)
        elif cty == xlrd.XL_CELL_BLANK:
            wtrow.set_cell_blank(wtcolx, style)
        elif cty == xlrd.XL_CELL_BOOLEAN:
            wtrow.set_cell_boolean(wtcolx, value, style)
        elif cty == xlrd.XL_CELL_ERROR:
            wtrow.set_cell_error(wtcolx, value, style)
        else:
            raise Exception(
                "Unknown xlrd cell type %r with value %r at (sheet=%r,rowx=%r,colx=%r)" \
                % (cty, value, self.rdsheet.name, rdrowx, rdcolx)
            )

        if self.cell_node and getattr(self.cell_node, 'is_dollar_cell', False):
            from openpyxl.utils import get_column_letter
            col_letter = get_column_letter(wtcolx + 1)
            coord = f"{col_letter}{wtrowx + 1}"
            self.sheet_writer.bookwriter.dollar_cells.append({
                'sheet': self.wtsheet.name,
                'coordinate': coord,
                'key': self.cell_node.dollar_name,
                'default_value': self.cell_node.default_value
            })
    def finish(self):
        self.apply_filters()
        self.set_cell()
