
class Box(object):

    def __init__(self, top, left):
        self.reset_pos(top, left)

    def next_row(self):
        self.bottom += 1
        self.right = self.left

    def next_cell(self):
        self.right += 1

    def jump_to_col(self, colx):
        # 强制跳转到指定列
        # colx 是 1-indexed (A=1, B=2...)
        # self.right 是写入偏移量，box.next_cell 会将其 +1
        # 所以 jump_to_col 应该设置为 colx - 1
        self.right = colx - 1

    def reset_pos(self, top, left):
        self.top = top
        self.bottom = top
        self.left = left
        self.right = left

class SheetMixin(object):

    def copy_dimensions(self, rdrowx, rdcolx, wtrowx, wtcolx):
        self.copy_row_dimension(rdrowx, wtrowx)
        self.copy_col_dimension(rdcolx, wtcolx)

    def reset_pos(self, top_left):
        if isinstance(top_left, (tuple, list)):
            self.box = Box(top_left[0], top_left[1])
        elif isinstance(top_left, dict):
            self.box = Box(top_left['top'], top_left['left'])
        else:
            self.box = Box(top_left.top, top_left.left)

    def set_sheet_resource(self, sheet_resource):
        self.merger = sheet_resource.merger
        self.rdsheet = sheet_resource.rdsheet

    def write_row(self, row_node):
        self.box.next_row()

    def write_cell(self, cell_node, rv, cty):
        # 检查是否需要忽略该单元格（不写入，不推进坐标）
        if hasattr(cell_node, 'cell_tag') and cell_node.cell_tag and cell_node.cell_tag.cell_ignore:
            ignore_val = str(cell_node.cell_tag.cell_ignore).lower().strip()
            if ignore_val in ['1', 'true', 'on', 'yes']:
                return # 直接返回，不执行后续坐标增加和写入逻辑
        
        # 检查是否存在固定列配置
        if hasattr(cell_node, 'cell_tag') and cell_node.cell_tag and cell_node.cell_tag.fixed_col:
            fixed = str(cell_node.cell_tag.fixed_col).strip()
            if fixed == '$col':
                # 注意：self.box.right 是当前列坐标。
                # 如果我们要锁定在 rdcol 列，则需要根据起始位置计算。
                # 在 openpyxl 模式下，box.left 通常是 0。
                self.box.right = self.box.left + cell_node.colx
            else:
                try:
                    self.box.right = self.box.left + int(fixed)
                except:
                    self.box.next_cell()
        else:
            self.box.next_cell()

        self.merger.merge_cell(cell_node.rowx, cell_node.colx, self.box.bottom, self.box.right)

        self.copy_dimensions(cell_node.rowx, cell_node.colx, self.box.bottom, self.box.right)
        if cell_node.sheet_cell:
            cell_context = self.get_cell_context(cell_node, rv, cty)
            # 这里的 get_cell_context 返回的是 CellContextX，其内部会调用 basex.cell
            # 我们需要确保 cell_node 传进去，以便在 basex.py 中处理批注
            # 由于 cell_context.target_cell 会触发写入，我们先补全参数
            cell_context.cell_node = cell_node 
            cell_context.finish()
            target_cell = cell_context.target_cell
            if target_cell and hasattr(cell_node, 'ops') and cell_node.ops:
                for (func, func_args) in cell_node.ops:
                    func(*func_args, cell_context)
                cell_node.ops.clear()

    def set_image_ref(self, image_ref):
        image_ref.wtrowx = self.box.bottom
        image_ref.wtcolx = self.box.right + 1
        self.merger.set_image_ref(image_ref)


class BookMixin(object):

    def load(self, fname):
        pass

    def build(self, sheet, index):
        pass

    def add_filter(self, key, value):
        self.jinja_env.filters[key] = value

    def add_global(self, key, value):
        self.jinja_env.globals[key] = value

    def set_jinja_filters(self, **kwargs):
        self.jinja_env.filters.update(kwargs)

    def set_jinja_globals(self, **kwargs):
        self.jinja_env.globals.update(kwargs)

    def get_sheet_writer(self, sheet_resource, sheet_name):
        sheet_writer = self.sheet_writer_map.get(sheet_name)
        if not sheet_writer:
            sheet_writer = self.sheet_writer_cls(self, sheet_resource, sheet_name)
            self.sheet_writer_map[sheet_name] = sheet_writer
        else:
            sheet_writer.set_sheet_resource(sheet_resource)
        return sheet_writer

    def get_sheet_name(self, payload):
        sheet_name = payload.get('sheet_name')
        if sheet_name:
            return sheet_name
        for i in range(9999):
            sheet_name = "sheet%d" % i
            if not self.sheet_writer_map.get(sheet_name):
                return sheet_name
        return "XLSheet"

    def get_sheet_resource(self, payload):
        return self.sheet_resource_map.get_sheet_resource(payload)

    def render_sheet(self, payload, top_left=None):
        sheet_name = self.get_sheet_name(payload)
        sheet_resource = self.get_sheet_resource(payload)
        sheet_writer = self.get_sheet_writer(sheet_resource, sheet_name)
        if top_left:
            sheet_writer.reset_pos(top_left)
        sheet_resource.render_sheet(sheet_writer, payload)
        return sheet_writer.box

    def render_sheets(self, payloads):
        for payload in payloads:
            self.render_sheet(payload)

    def render_book(self, payloads):
        return self.render_sheets(payloads)

    def save(self, fname):
        pass