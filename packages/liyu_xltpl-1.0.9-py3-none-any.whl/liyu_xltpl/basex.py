# -*- coding: utf-8 -*-

import copy
from openpyxl.utils import get_column_letter
from openpyxl.cell.text import InlineFont
from .cellcontext import CellContextX

class SheetBase():

    def copy_sheet_settings(self):
        self.wtsheet.sheet_format = copy.copy(self.rdsheet.sheet_format)
        self.wtsheet.sheet_properties = copy.copy(self.rdsheet.sheet_properties)
        # copy print settings
        self.wtsheet.page_setup = copy.copy(self.rdsheet.page_setup)
        self.wtsheet.print_options = copy.copy(self.rdsheet.print_options)
        self.wtsheet._print_rows = copy.copy(self.rdsheet._print_rows)
        self.wtsheet._print_cols = copy.copy(self.rdsheet._print_cols)
        self.wtsheet._print_area = copy.copy(self.rdsheet._print_area)
        self.wtsheet.page_margins = copy.copy(self.rdsheet.page_margins)
        self.wtsheet.protection = copy.copy(self.rdsheet.protection)
        self.wtsheet.HeaderFooter = copy.copy(self.rdsheet.HeaderFooter)
        self.wtsheet.views = copy.copy(self.rdsheet.views)
        self.wtsheet._images = copy.copy(self.rdsheet._images)

    def copy_row_dimension(self, rdrowx, wtrowx):
        if wtrowx in self.wtrows:
            return
        dim = self.rdsheet.row_dimensions.get(rdrowx)
        if dim:
            self.wtsheet.row_dimensions[wtrowx] = copy.copy(dim)
            self.wtsheet.row_dimensions[wtrowx].worksheet = self.wtsheet
            self.wtrows.add(wtrowx)

    def copy_col_dimension(self, rdcolx, wtcolx):
        if wtcolx in self.wtcols:
            return
        rdkey = get_column_letter(rdcolx)
        rddim = self.rdsheet.column_dimensions.get(rdkey)
        if not rddim:
            return
        wtdim = copy.copy(rddim)
        if rdcolx != wtcolx:
            wtkey = get_column_letter(wtcolx)
            wtdim.index = wtkey
            d = wtcolx - rdcolx
            wtdim.min += d
            wtdim.max += d
        else:
            wtkey = rdkey
        self.wtsheet.column_dimensions[wtkey] = wtdim
        self.wtsheet.column_dimensions[wtkey].worksheet = self.wtsheet
        self.wtcols.add(wtcolx)

    def _cell(self, source_cell, rdrowx, rdcolx, wtrowx, wtcolx, value=None, data_type=None, cell_node=None):
        target_cell = self.wtsheet.cell(column=wtcolx, row=wtrowx)
        from openpyxl.cell.cell import STRING_TYPES
        if value is None:
            target_cell._value = source_cell._value
            target_cell.data_type = source_cell.data_type
        elif isinstance(value, (str, bytes)) and value.startswith("="):
            if cell_node and not cell_node.manual_formula:
                from .utils import relocate_formula
                value = relocate_formula(value, rdrowx, rdcolx, wtrowx, wtcolx, index_1=True)
            target_cell.value = value
        elif data_type:
            target_cell._value = value
            target_cell.data_type = data_type
        else:
            target_cell.value = value

        if source_cell.has_style:
            target_cell._style = copy.copy(source_cell._style)

        # 处理单元格锁定/解锁逻辑
        if cell_node and hasattr(cell_node, 'cell_tag') and cell_node.cell_tag and cell_node.cell_tag.cell_lock:
            lock_val = str(cell_node.cell_tag.cell_lock).lower().strip()
            from openpyxl.styles import Protection
            if lock_val in ['0', 'false', 'off', 'unlocked']:
                target_cell.protection = Protection(locked=False)
            elif lock_val in ['1', 'true', 'on', 'locked']:
                target_cell.protection = Protection(locked=True)

        if source_cell.hyperlink:
            target_cell._hyperlink = copy.copy(source_cell.hyperlink)

        # 处理批注保留逻辑
        if cell_node and hasattr(cell_node, 'cell_tag') and cell_node.cell_tag and cell_node.cell_tag.cell_name:
            from openpyxl.comments import Comment
            name = cell_node.cell_tag.cell_name
            target_cell.comment = Comment(text=f"cell_name {name}", author="liyu_xltpl")

        if cell_node and getattr(cell_node, 'is_dollar_cell', False):
            from openpyxl.utils import get_column_letter
            col_letter = get_column_letter(wtcolx)
            coord = f"{col_letter}{wtrowx}"
            self.bookwriter.dollar_cells.append({
                'sheet': self.wtsheet.title,
                'coordinate': coord,
                'key': cell_node.dollar_name,
                'default_value': cell_node.default_value
            })
            if getattr(self.bookwriter, 'dollar_cell_bg_color', None):
                from openpyxl.styles import PatternFill
                bg_color = self.bookwriter.dollar_cell_bg_color
                if isinstance(bg_color, str):
                    color_name = bg_color.lower().strip()
                    # HTML color names mapping
                    color_map = {
                        'aliceblue': 'F0F8FF', 'antiquewhite': 'FAEBD7', 'aqua': '00FFFF', 'aquamarine': '7FFFD4',
                        'azure': 'F0FFFF', 'beige': 'F5F5DC', 'bisque': 'FFE4C4', 'black': '000000', 'blanchedalmond': 'FFEBCD',
                        'blue': '0000FF', 'blueviolet': '8A2BE2', 'brown': 'A52A2A', 'burlywood': 'DEB887', 'cadetblue': '5F9EA0',
                        'chartreuse': '7FFF00', 'chocolate': 'D2691E', 'coral': 'FF7F50', 'cornflowerblue': '6495ED',
                        'cornsilk': 'FFF8DC', 'crimson': 'DC143C', 'cyan': '00FFFF', 'darkblue': '00008B', 'darkcyan': '008B8B',
                        'darkgoldenrod': 'B8860B', 'darkgray': 'A9A9A9', 'darkgrey': 'A9A9A9', 'darkgreen': '006400',
                        'darkkhaki': 'BDB76B', 'darkmagenta': '8B008B', 'darkolivegreen': '556B2F', 'darkorange': 'FF8C00',
                        'darkorchid': '9932CC', 'darkred': '8B0000', 'darksalmon': 'E9967A', 'darkseagreen': '8FBC8F',
                        'darkslateblue': '483D8B', 'darkslategray': '2F4F4F', 'darkslategrey': '2F4F4F', 'darkturquoise': '00CED1',
                        'darkviolet': '9400D3', 'deeppink': 'FF1493', 'deepskyblue': '00BFFF', 'dimgray': '696969',
                        'dimgrey': '696969', 'dodgerblue': '1E90FF', 'firebrick': 'B22222', 'floralwhite': 'FFFAF0',
                        'forestgreen': '228B22', 'fuchsia': 'FF00FF', 'gainsboro': 'DCDCDC', 'ghostwhite': 'F8F8FF',
                        'gold': 'FFD700', 'goldenrod': 'DAA520', 'gray': '808080', 'grey': '808080', 'green': '008000',
                        'greenyellow': 'ADFF2F', 'honeydew': 'F0FFF0', 'hotpink': 'FF69B4', 'indianred': 'CD5C5C',
                        'indigo': '4B0082', 'ivory': 'FFFFF0', 'khaki': 'F0E68C', 'lavender': 'E6E6FA', 'lavenderblush': 'FFF0F5',
                        'lawngreen': '7CFC00', 'lemonchiffon': 'FFFACD', 'lightblue': 'ADD8E6', 'lightcoral': 'F08080',
                        'lightcyan': 'E0FFFF', 'lightgoldenrodyellow': 'FAFAD2', 'lightgray': 'D3D3D3', 'lightgrey': 'D3D3D3',
                        'lightgreen': '90EE90', 'lightpink': 'FFB6C1', 'lightsalmon': 'FFA07A', 'lightseagreen': '20B2AA',
                        'lightskyblue': '87CEFA', 'lightslategray': '778899', 'lightslategrey': '778899', 'lightsteelblue': 'B0C4DE',
                        'lightyellow': 'FFFFE0', 'lime': '00FF00', 'limegreen': '32CD32', 'linen': 'FAF0E6', 'magenta': 'FF00FF',
                        'maroon': '800000', 'mediumaquamarine': '66CDAA', 'mediumblue': '0000CD', 'mediumorchid': 'BA55D3',
                        'mediumpurple': '9370DB', 'mediumseagreen': '3CB371', 'mediumslateblue': '7B68EE', 'mediumspringgreen': '00FA9A',
                        'mediumturquoise': '48D1CC', 'mediumvioletred': 'C71585', 'midnightblue': '191970', 'mintcream': 'F5FFFA',
                        'mistyrose': 'FFE4E1', 'moccasin': 'FFE4B5', 'navajowhite': 'FFDEAD', 'navy': '000080', 'oldlace': 'FDF5E6',
                        'olive': '808000', 'olivedrab': '6B8E23', 'orange': 'FFA500', 'orangered': 'FF4500', 'orchid': 'DA70D6',
                        'palegoldenrod': 'EEE8AA', 'palegreen': '98FB98', 'paleturquoise': 'AFEEEE', 'palevioletred': 'DB7093',
                        'papayawhip': 'FFEFD5', 'peachpuff': 'FFDAB9', 'peru': 'CD853F', 'pink': 'FFC0CB', 'plum': 'DDA0DD',
                        'powderblue': 'B0E0E6', 'purple': '800080', 'rebeccapurple': '663399', 'red': 'FF0000', 'rosybrown': 'BC8F8F',
                        'royalblue': '4169E1', 'saddlebrown': '8B4513', 'salmon': 'FA8072', 'sandybrown': 'F4A460',
                        'seagreen': '2E8B57', 'seashell': 'FFF5EE', 'sienna': 'A0522D', 'silver': 'C0C0C0', 'skyblue': '87CEEB',
                        'slateblue': '6A5ACD', 'slategray': '708090', 'slategrey': '708090', 'snow': 'FFFAFA', 'springgreen': '00FF7F',
                        'steelblue': '4682B4', 'tan': 'D2B48C', 'teal': '008080', 'thistle': 'D8BFD8', 'tomato': 'FF6347',
                        'turquoise': '40E0D0', 'violet': 'EE82EE', 'wheat': 'F5DEB3', 'white': 'FFFFFF', 'whitesmoke': 'F5F5F5',
                        'yellow': 'FFFF00', 'yellowgreen': '9ACD32'
                    }
                    if color_name in color_map:
                        hex_color = color_map[color_name]
                    else:
                        hex_color = color_name.lstrip('#')
                    if len(hex_color) == 6:
                        hex_color = 'FF' + hex_color
                    target_cell.fill = PatternFill(start_color=hex_color, end_color=hex_color, fill_type='solid')
                elif isinstance(bg_color, PatternFill):
                    target_cell.fill = bg_color

        return target_cell

    def cell(self, source_cell, rdrowx, rdcolx, wtrowx, wtcolx, value=None, data_type=None, cell_node=None):
        self.copy_row_dimension(rdrowx, wtrowx)
        self.copy_col_dimension(rdcolx, wtcolx)
        return self._cell(source_cell, rdrowx, rdcolx, wtrowx, wtcolx, value, data_type, cell_node)

    def get_cell_context(self, cell_node, rv, cty):
        return CellContextX(self, cell_node, rv, cty)


class BookBase():

    def get_font(self, fontId):
        ifont = self.font_map.get(fontId)
        if ifont:
            return ifont
        else:
            font = self.workbook._fonts[fontId]
            ifont = InlineFont()
            ifont.rFont = font.name
            ifont.charset = font.charset
            ifont.family = font.family
            ifont.b = font.b
            ifont.i = font.i
            ifont.strike = font.strike
            ifont.outline = font.outline
            ifont.shadow = font.shadow
            ifont.condense = font.condense
            ifont.extend = font.extend
            ifont.color = font.color
            ifont.sz = font.sz
            ifont.u = font.u
            ifont.vertAlign = font.vertAlign
            ifont.scheme = font.scheme
            self.font_map[fontId] = ifont
            return ifont
