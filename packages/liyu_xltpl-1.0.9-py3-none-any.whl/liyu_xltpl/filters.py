from openpyxl.utils import get_column_letter


def add_filter(filter):
    def wrapper(env, *args):
        cell_node = env.node_map.current_node.current_cell
        cell_node.add_filter(filter, args)
        return ""

    return wrapper


def num_to_letter(col_index):
    try:
        return get_column_letter(int(col_index))
    except (ValueError, TypeError):
        return col_index


def pad_list(lst, min_len):
    if not isinstance(lst, list):
        return lst
    if len(lst) >= min_len:
        return lst

    if not lst:
        return [""] * min_len

    template = lst[0]
    padding = []
    if isinstance(template, dict):
        empty_item = {k: "" for k in template.keys()}
        padding = [empty_item.copy() for _ in range(min_len - len(lst))]
    else:
        padding = [""] * (min_len - len(lst))

    return lst + padding
