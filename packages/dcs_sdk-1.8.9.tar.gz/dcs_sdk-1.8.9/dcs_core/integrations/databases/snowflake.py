#  Copyright 2022-present, the Waterdip Labs Pvt. Ltd.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
import datetime
import math
import re
import urllib.parse
from decimal import Decimal
from typing import Any, Dict, List, Optional, Tuple
from uuid import UUID

from loguru import logger
from snowflake.sqlalchemy import URL
from sqlalchemy import create_engine, text

from dcs_core.core.common.errors import DataChecksDataSourcesConnectionError
from dcs_core.core.common.models.data_source_resource import RawColumnInfo
from dcs_core.core.datasource.sql_datasource import SQLDataSource

DEFAULT_SNOWFLAKE_HOST_SUFFIX = ".snowflakecomputing.com"
DEFAULT_SNOWFLAKE_PORT = 443


def get_snowflake_host(account: str | None, host: str | None = None) -> str | None:
    if not account:
        return host or None

    account = str(account).lower()
    if not host:
        return (
            account if account.endswith(DEFAULT_SNOWFLAKE_HOST_SUFFIX) else f"{account}{DEFAULT_SNOWFLAKE_HOST_SUFFIX}"
        )

    host = str(host).strip()
    host_suffix = DEFAULT_SNOWFLAKE_HOST_SUFFIX.lstrip(".")
    if host in (host_suffix, DEFAULT_SNOWFLAKE_HOST_SUFFIX):
        return f"{account}{DEFAULT_SNOWFLAKE_HOST_SUFFIX}"
    return host


def get_snowflake_port(port: int | str | None = None) -> int:
    if port in (None, ""):
        return DEFAULT_SNOWFLAKE_PORT
    return int(port)


class SnowFlakeDataSource(SQLDataSource):
    SQLGLOT_DIALECT = "snowflake"

    def __init__(self, data_source_name: str, data_connection: Dict):
        super().__init__(data_source_name, data_connection)

    def connect(self) -> Any:
        """
        Connect to the data source
        """
        try:
            account = self.data_connection.get("account")
            connect_args = {
                "host": get_snowflake_host(account, self.data_connection.get("host")),
                "port": get_snowflake_port(self.data_connection.get("port")),
            }
            connect_args = {key: value for key, value in connect_args.items() if value is not None}

            url = URL(
                account=account,
                user=self.data_connection.get("username"),
                password=urllib.parse.quote(self.data_connection.get("password")),
                database=self.data_connection.get("database"),
                schema=self.data_connection.get("schema"),
                warehouse=self.data_connection.get("warehouse"),
                role=self.data_connection.get("role"),
            )
            engine = create_engine(url, connect_args=connect_args)
            self.connection = engine.connect()
            return self.connection
        except Exception as e:
            raise DataChecksDataSourcesConnectionError(
                message=f"Failed to connect to Snowflake data source: [{str(e)}]"
            )

    def quote_column(self, column: str) -> str:
        return f'"{column}"'

    def quote_database(self, database: str) -> str:
        return f'"{database}"'

    def qualified_table_name(self, table_name: str) -> str:
        if self.schema_name:
            return f'"{self.schema_name}"."{table_name}"'
        return f'"{table_name}"'

    def query_get_database_version(self, database_version_query: Optional[str] = None) -> str:
        query = database_version_query or "SELECT CURRENT_VERSION()"
        result = self.fetchone(query)
        if result:
            return result[0]
        return None

    def query_get_table_indexes(self, table: str, schema: str | None = None) -> dict[str, dict]:
        schema = (schema or self.schema_name or "").upper()
        database = self.database or self.data_connection.get("database")

        try:
            rows = self.fetchall(f'SHOW PRIMARY KEYS IN TABLE "{database}"."{schema}"."{table.upper()}"')
        except Exception:
            return {}

        # SHOW PRIMARY KEYS columns (positional):
        #   0:created_on, 1:database_name, 2:schema_name, 3:table_name,
        #   4:column_name, 5:key_sequence, 6:constraint_name, 7:rely, 8:comment
        indexes = {}
        for row in rows or []:
            constraint_name = row[6]
            if constraint_name not in indexes:
                indexes[constraint_name] = {
                    "columns": [],
                    "index_type": "PRIMARY KEY",
                    "is_primary_key": True,
                }
            indexes[constraint_name]["columns"].append(
                {
                    "column_name": row[4],
                    "column_order": row[5],
                }
            )

        return indexes

    def get_table_foreign_key_info(self, table_name: str, schema: str | None = None) -> list[dict]:
        schema = (schema or self.schema_name or "").upper()
        database = self.database or self.data_connection.get("database")

        try:
            rows = self.fetchall(f'SHOW IMPORTED KEYS IN TABLE "{database}"."{schema}"."{table_name.upper()}"')
        except Exception:
            return []

        # SHOW IMPORTED KEYS columns (positional):
        #   0:created_on, 1:pk_database_name, 2:pk_schema_name, 3:pk_table_name,
        #   4:pk_column_name, 5:fk_database_name, 6:fk_schema_name, 7:fk_table_name,
        #   8:fk_column_name, 9:key_sequence, 10:update_rule, 11:delete_rule,
        #   12:fk_name, 13:pk_name, 14:deferrability
        fk_info = []
        for row in rows or []:
            fk_info.append(
                {
                    "constraint_name": row[12],
                    "table_name": row[7],
                    "fk_column": row[8],
                    "referenced_table": row[3],
                    "referenced_column": row[4],
                }
            )

        return fk_info

    def get_schema_fk_relations(self, schema: str) -> list[tuple]:
        # SHOW IMPORTED KEYS is the reliable way to fetch FK metadata in Snowflake.
        # information_schema.referential_constraints is almost always empty because
        # Snowflake does not enforce FK constraints at write time.
        # Result columns: created_on, pk_database, pk_schema, pk_table, pk_column,
        #                 fk_database, fk_schema, fk_table, fk_column, key_sequence,
        #                 update_rule, delete_rule, fk_name, pk_name, deferrability
        database = self.database or self.data_connection.get("database")
        schema_upper = schema.upper()
        try:
            rows = self.fetchall(f'SHOW IMPORTED KEYS IN SCHEMA "{database}"."{schema_upper}"')
            # positional: 7=fk_table_name, 8=fk_column_name, 3=pk_table_name, 4=pk_column_name
            return [(r[7], r[8], r[3], r[4]) for r in (rows or [])]
        except Exception as e:
            logger.warning(f"get_schema_fk_relations failed: {e}")
            return []

    def get_schema_pk_map(self, schema: str) -> list[tuple]:
        # SHOW PRIMARY KEYS is the reliable Snowflake catalog command for PK metadata.
        # Result columns (positional): 0:created_on, 1:database_name, 2:schema_name,
        #   3:table_name, 4:column_name, 5:key_sequence, 6:constraint_name, 7:rely, 8:comment
        database = self.database or self.data_connection.get("database")
        schema_upper = schema.upper()
        try:
            rows = self.fetchall(f'SHOW PRIMARY KEYS IN SCHEMA "{database}"."{schema_upper}"')
            # rows ordered by key_sequence; 3=table_name, 4=column_name
            return [(r[3], r[4]) for r in (rows or [])]
        except Exception as e:
            logger.warning(f"get_schema_pk_map failed: {e}")
            return []

    def query_get_table_names(
        self,
        schema: str | None = None,
        with_view: bool = False,
    ) -> dict:
        schema = schema or self.schema_name
        database = self.database or self.data_connection.get("database")
        quoted_database = self.quote_database(database)

        query = (
            f"SELECT table_name, table_type FROM {quoted_database}.information_schema.tables "
            f"WHERE table_schema = '{schema}'"
        )
        if not with_view:
            query += " AND table_type != 'VIEW'"

        rows = self.fetchall(query)

        if with_view:
            result = {"table": [], "view": []}
            if rows:
                for row in rows:
                    table_name = row[0]
                    table_type = row[1]
                    if table_type == "VIEW":
                        result["view"].append(table_name)
                    else:
                        result["table"].append(table_name)
        else:
            result = {"table": []}
            if rows:
                result["table"] = [row[0] for row in rows]

        return result

    def query_get_table_columns(
        self,
        table: str,
        schema: str | None = None,
    ) -> RawColumnInfo:
        schema = schema or self.schema_name
        database = self.database or self.data_connection.get("database")
        quoted_database = self.quote_database(database)

        query = (
            f"SELECT column_name, data_type, datetime_precision, numeric_precision, numeric_scale, "
            f"character_maximum_length "
            f"FROM {quoted_database}.information_schema.columns "
            f"WHERE table_name = '{table}' AND table_schema = '{schema}'"
        )
        rows = self.fetchall(query)

        if not rows:
            raise RuntimeError(f"{table}: Table, {schema}: Schema, does not exist, or has no columns")

        column_info = {
            r[0]: RawColumnInfo(
                column_name=self.safe_get(r, 0),
                data_type=self.safe_get(r, 1),
                datetime_precision=self.safe_get(r, 2),
                numeric_precision=self.safe_get(r, 3),
                numeric_scale=self.safe_get(r, 4),
                character_maximum_length=self.safe_get(r, 5),
            )
            for r in rows
        }
        return column_info

    def fetch_rows(
        self,
        query: str,
        limit: int = 1,
        with_column_names: bool = False,
        complete_query: Optional[str] = None,
    ) -> Tuple[List, Optional[List[str]]]:
        query = complete_query or f"SELECT * FROM ({query}) AS subquery LIMIT {limit}"

        result = self.connection.execute(text(query))
        rows = result.fetchmany(limit)

        if with_column_names:
            column_names = [desc[0] for desc in result.cursor.description]
            return rows, column_names
        else:
            return rows, None

    def fetch_sample_values_from_database(
        self,
        table_name: str,
        column_names: list[str],
        limit: int = 5,
    ) -> List[Tuple]:
        table_name = self.qualified_table_name(table_name)

        if not column_names:
            raise ValueError("At least one column name must be provided")

        if len(column_names) == 1 and column_names[0] == "*":
            query = f"SELECT * FROM {table_name} LIMIT {limit}"
        else:
            columns = ", ".join([self.quote_column(col) for col in column_names])
            query = f"SELECT {columns} FROM {table_name} LIMIT {limit}"

        result = self.connection.execute(text(query))
        column_names = list(result.keys())
        rows = self.normalize_sample_rows(result.fetchall())
        return rows, column_names

    def build_table_metrics_query(
        self,
        table_name: str,
        column_info: list[dict],
        additional_queries: Optional[List[str]] = None,
    ) -> list[dict]:
        query_parts = []
        if not column_info:
            return []

        _NUMERIC_TYPES = (
            "number",
            "decimal",
            "numeric",
            "int",
            "integer",
            "bigint",
            "smallint",
            "tinyint",
            "byteint",
            "float",
            "float4",
            "float8",
            "double",
            "real",
        )
        _STRING_TYPES = ("text", "varchar", "char", "character", "string", "nchar", "nvarchar", "nvarchar2")
        _DATETIME_TYPES = (
            "date",
            "datetime",
            "time",
            "timestamp",
            "timestamp_ltz",
            "timestamp_ntz",
            "timestamp_tz",
            "boolean",
        )

        for col in column_info:
            name = col["column_name"]
            dtype = col["data_type"].lower()
            quoted = self.quote_column(name)

            query_parts.append(f'COUNT(DISTINCT {quoted}) AS "{name}_distinct"')
            query_parts.append(f'COUNT(*) - COUNT(DISTINCT {quoted}) AS "{name}_duplicate"')
            query_parts.append(f'SUM(CASE WHEN {quoted} IS NULL THEN 1 ELSE 0 END) AS "{name}_is_null"')

            if dtype in _NUMERIC_TYPES:
                query_parts.append(f'MIN({quoted}) AS "{name}_min"')
                query_parts.append(f'MAX({quoted}) AS "{name}_max"')
                query_parts.append(f'AVG({quoted}) AS "{name}_average"')

            elif dtype in _STRING_TYPES:
                query_parts.append(f'MAX(LENGTH({quoted})) AS "{name}_max_character_length"')

            elif dtype in _DATETIME_TYPES:
                query_parts.append(f'MIN({quoted}) AS "{name}_min"')
                query_parts.append(f'MAX({quoted}) AS "{name}_max"')

        if additional_queries:
            for queries in additional_queries:
                query_parts.append(queries)

        qualified_table = self.qualified_table_name(table_name)
        joined_parts = ",\n    ".join(query_parts)
        query = f"SELECT\n    {joined_parts}\nFROM {qualified_table};"

        result = self.connection.execute(text(query))
        row = dict(list(result)[0]._mapping)

        def _normalize_metrics(value):
            if value is None:
                return None
            if isinstance(value, bool):
                return value
            if isinstance(value, Decimal):
                return float(value)
            if isinstance(value, (int, float)):
                return value
            if isinstance(value, datetime.datetime):
                return value.isoformat()
            if isinstance(value, datetime.date):
                return value.isoformat()
            if isinstance(value, datetime.timedelta):
                return str(value)
            if isinstance(value, datetime.time):
                return value.isoformat()
            if isinstance(value, UUID):
                return str(value)
            if isinstance(value, bytes):
                try:
                    return value.decode("utf-8")
                except Exception:
                    return value.hex()
            if isinstance(value, list):
                return [_normalize_metrics(v) for v in value]
            if isinstance(value, dict):
                return {k: _normalize_metrics(v) for k, v in value.items()}
            return str(value)

        key_owner: dict[str, str] = {}
        for col in column_info:
            n = col["column_name"]
            for key in row:
                if key.startswith(f"{n}_"):
                    if key not in key_owner or len(n) > len(key_owner[key]):
                        key_owner[key] = n

        column_wise = []
        for col in column_info:
            name = col["column_name"]
            col_metrics = {
                key[len(name) + 1 :]: _normalize_metrics(value)
                for key, value in row.items()
                if key_owner.get(key) == name
            }
            column_wise.append({"column_name": name, "metrics": col_metrics})

        for col_data in column_wise:
            metrics = col_data["metrics"]
            distinct_count = metrics.get("distinct")
            col_name = col_data["column_name"]
            dtype = next(c["data_type"].lower() for c in column_info if c["column_name"] == col_name)

            quoted = self.quote_column(col_name)

            is_dtype_numeric = dtype in _NUMERIC_TYPES

            if is_dtype_numeric:
                col_min = metrics.get("min")
                col_max = metrics.get("max")

                if col_min is not None and col_max is not None and col_min != col_max:
                    col_min = float(col_min)
                    col_max = float(col_max)
                    bucket_count = 20
                    bucket_size = (col_max - col_min) / bucket_count

                    bucket_queries = []
                    for i in range(bucket_count):
                        start = col_min + i * bucket_size
                        end = col_min + (i + 1) * bucket_size
                        bucket_queries.append(
                            f'SUM(CASE WHEN {quoted} >= {start} AND {quoted} < {end} THEN 1 ELSE 0 END) AS "bucket_{i}"'
                        )

                    bucket_sql = f"SELECT {', '.join(bucket_queries)} FROM {qualified_table}"

                    try:
                        bucket_result = self.connection.execute(text(bucket_sql)).fetchone()
                        distribution = []

                        for i in range(bucket_count):
                            start_raw = col_min + i * bucket_size
                            end_raw = col_min + (i + 1) * bucket_size
                            if dtype in ("int", "integer", "bigint", "smallint", "tinyint", "byteint"):
                                start = math.floor(start_raw)
                                end = math.ceil(end_raw)
                            else:
                                start = round(start_raw, 2)
                                end = round(end_raw, 2)

                            count = _normalize_metrics(bucket_result[i])
                            distribution.append({"col_val": f"{start} - {end}", "count": count})

                        metrics["distribution_graph"] = distribution

                    except Exception as e:
                        logger.warning(f"Failed to generate numeric distribution for {col_name}: {e}")

                continue

            if isinstance(distinct_count, (int, float)) and distinct_count <= 20:
                dist_query = (
                    f"SELECT {quoted}, COUNT(*) " f"FROM {qualified_table} GROUP BY {quoted} ORDER BY COUNT(*) DESC"
                )

                try:
                    dist_result = self.connection.execute(text(dist_query)).fetchall()

                    distribution = []
                    for r in dist_result:
                        val = _normalize_metrics(r[0])
                        distribution.append({"col_val": val, "count": _normalize_metrics(r[1])})

                    metrics["distribution_graph"] = distribution

                except Exception as e:
                    logger.warning(f"Failed to generate distribution graph for column {col_name}: {e}")

        for col_data in column_wise:
            metrics = col_data["metrics"]
            is_dtype_numeric = (
                next(c["data_type"].lower() for c in column_info if c["column_name"] == col_data["column_name"])
                in _NUMERIC_TYPES
            )

            formatted_metrics_data = {
                "general_data": {key: value for key, value in metrics.items() if key != "distribution_graph"},
                "is_dtype_numeric": is_dtype_numeric,
                "distribution_data": metrics.get("distribution_graph", []),
            }
            col_data["metrics"] = formatted_metrics_data

        return column_wise

    def get_table_autoincrement_info(self, table_name: str, schema: str | None = None) -> dict:
        schema = schema or self.schema_name
        database = self.database or self.data_connection.get("database")
        quoted_database = self.quote_database(database)

        query = f"""
            SELECT column_name, data_type, column_default
            FROM {quoted_database}.information_schema.columns
            WHERE table_name = '{table_name}'
              AND table_schema = '{schema}'
              AND column_default ILIKE 'AUTOINCREMENT%'
        """

        result: dict = {"identity_columns": []}
        try:
            rows = self.connection.execute(text(query)).fetchall()
            for row in rows:
                col_name = row[0]
                data_type = row[1]
                col_default = row[2] or ""

                # Parse: AUTOINCREMENT START <n> INCREMENT <m>
                start_match = re.search(r"START\s+(\d+)", col_default, re.IGNORECASE)
                increment_match = re.search(r"INCREMENT\s+(\d+)", col_default, re.IGNORECASE)

                result["identity_columns"].append(
                    {
                        "column_name": col_name,
                        "data_type": data_type,
                        "identity_generation": "BY DEFAULT",
                        "start_value": start_match.group(1) if start_match else "1",
                        "increment": increment_match.group(1) if increment_match else "1",
                        "minimum_value": None,
                        "maximum_value": None,
                        "cycle": "NO",
                    }
                )
        except Exception as e:
            logger.warning(f"Failed to fetch AUTOINCREMENT info for table '{table_name}': {e}")

        return result

    def query_sequences(self, schema: str) -> Dict[str, dict]:
        schema = schema or self.schema_name
        database = self.database or self.data_connection.get("database")

        rows = self.fetchall(f"SHOW SEQUENCES IN SCHEMA {self.quote_database(database)}.{self.quote_column(schema)}")

        return (
            {
                row[1]: {
                    "start_value": row[5],
                    "increment": row[6],
                    "min_value": None,
                    "max_value": None,
                    "current_value": row[8],
                    "cycle": False,
                }
                for row in rows
            }
            if rows
            else {}
        )

    def _procedure_type_signature(self, argument_signature: str | None) -> str:
        if not argument_signature or argument_signature == "()":
            return "()"

        signature = argument_signature.strip()
        if not signature.startswith("(") or not signature.endswith(")"):
            return signature

        args = []
        current = []
        depth = 0
        for char in signature[1:-1]:
            if char == "(":
                depth += 1
            elif char == ")":
                depth -= 1
            elif char == "," and depth == 0:
                args.append("".join(current).strip())
                current = []
                continue
            current.append(char)

        if current:
            args.append("".join(current).strip())

        types = []
        for arg in args:
            match = re.match(r'(?:"[^"]+"|\w+)\s+(.+)$', arg)
            types.append(match.group(1).strip() if match else arg)

        return f"({', '.join(types)})"

    def query_views_defination(self, schema: str) -> Dict[str, str]:
        schema = schema or self.schema_name

        view_rows = self.fetchall(
            f"""
            SELECT table_name
            FROM information_schema.views
            WHERE table_schema = '{schema.upper()}'
            """
        )

        result = {}

        for (view_name,) in view_rows or []:
            object_name = f"{self.quote_database(schema)}.{self.quote_column(view_name)}"

            try:
                row = self.fetchone(f"SELECT GET_DDL('VIEW', '{object_name}')")
                if row and row[0]:
                    result[view_name] = row[0]
            except Exception as exc:
                logger.warning(f"Failed to fetch DDL for view {object_name}: {exc}")

        return result

    def query_all_procedures_defination(self, schema: str) -> Dict[str, str]:
        schema = schema or self.schema_name

        proc_rows = self.fetchall(
            f"""
            SELECT procedure_name, argument_signature, procedure_definition
            FROM information_schema.procedures
            WHERE procedure_schema = '{schema.upper()}'
            """
        )

        result = {}

        for proc_name, arg_sig, proc_definition in proc_rows or []:
            type_signature = self._procedure_type_signature(arg_sig)
            object_name = f"{proc_name}{type_signature}"

            try:
                row = self.fetchone(f"SELECT GET_DDL('PROCEDURE', '{object_name}')")
                if row and row[0]:
                    result[object_name] = row[0]
            except Exception as exc:
                logger.warning(f"Failed to fetch DDL for procedure {object_name}: {exc}")
                if proc_definition:
                    result[object_name] = proc_definition

        return result

    def get_view_dependency_map(self, schema: str) -> Dict[str, List[str]]:
        schema = schema or self.schema_name
        query = f"""
            SELECT view_name, table_name
            FROM information_schema.view_table_usage
            WHERE view_schema = '{schema}'
        """
        rows = self.fetchall(query)
        result: Dict[str, List[str]] = {}
        for view_name, table_name in rows or []:
            result.setdefault(view_name, []).append(table_name)
        return result

    def query_trigger_definitions(self, schema: str) -> Dict[str, str]:
        return {}
