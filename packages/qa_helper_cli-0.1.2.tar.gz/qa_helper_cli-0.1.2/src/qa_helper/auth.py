"""Auth module — device code login flow."""

import asyncio
import sys
import webbrowser

import httpx

from .config import load_config, save_config

SERVER_URL = "https://www.qa-helper.xyz"
POLL_INTERVAL = 2   # seconds between polls
POLL_TIMEOUT = 300  # 5 minutes max wait


async def login() -> None:
    """Start device code login flow.

    Opens browser to authenticate with the QA Helper server.
    Saves access token to ~/.qa-helper/config.json on success.
    """
    async with httpx.AsyncClient(timeout=15.0) as client:
        response = await client.post(f"{SERVER_URL}/api/cli/auth/start")

    if response.status_code != 200:
        print(f"Error: Could not start login ({response.status_code}). Is the server reachable?", file=sys.stderr)
        sys.exit(1)

    data = response.json()
    device_code = data["device_code"]
    login_url = data["login_url"]

    print(f"\nOpening browser for login...")
    print(f"If it didn't open, visit: {login_url}\n")
    webbrowser.open(login_url)

    print("Waiting for authentication", end="", flush=True)

    elapsed = 0
    while elapsed < POLL_TIMEOUT:
        await asyncio.sleep(POLL_INTERVAL)
        elapsed += POLL_INTERVAL
        print(".", end="", flush=True)

        async with httpx.AsyncClient(timeout=15.0) as client:
            poll = await client.post(
                f"{SERVER_URL}/api/cli/auth/poll",
                json={"device_code": device_code},
            )

        if poll.status_code != 200:
            continue

        result = poll.json()
        status = result.get("status")

        if status == "confirmed":
            access_token = result["access_token"]
            config = load_config()
            config["server_url"] = SERVER_URL
            config["access_token"] = access_token
            save_config(config)
            print(f"\nLogged in successfully.\n")
            return

        if status == "expired":
            print(f"\nLogin timed out. Run 'qa-helper login' to try again.", file=sys.stderr)
            sys.exit(1)

        # status == "pending" — keep polling

    print(f"\nLogin timed out after {POLL_TIMEOUT // 60} minutes.", file=sys.stderr)
    sys.exit(1)


def logout() -> None:
    """Clear saved access token from config."""
    config = load_config()
    if not config.get("access_token"):
        print("Not logged in.")
        return
    config.pop("access_token", None)
    save_config(config)
    print("Logged out.")
