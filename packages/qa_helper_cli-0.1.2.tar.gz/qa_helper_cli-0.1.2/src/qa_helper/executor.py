"""TC executor — runs test cases step by step using browser-use and the AI interpreter."""

import asyncio
import os
import re
from urllib.parse import urlparse

from .interpreter import StepInterpreter
from .llm import call_llm


def _screenshot(interpreter: StepInterpreter, path: str) -> None:
    """Take a screenshot, silently ignore errors."""
    try:
        interpreter.browser.screenshot(path)
    except Exception:
        pass


async def _resolve_preconditions(interpreter: StepInterpreter, base_url: str, precondition: str) -> dict:
    """Use AI to resolve preconditions into a URL and login requirement."""
    prompt = f"""Given the app base URL and a test case precondition, return the URL and whether login is needed.

Base URL: {base_url}

Precondition: {precondition}

Common patterns:
- "User is on login page" -> url=/login, needs_login=false
- "User is on the main page" or "User is on the home page" -> url=base, needs_login=false
- "User is logged in" -> url=base, needs_login=true
- "User is logged in and on settings page" -> url=/settings, needs_login=true
- "User is on signup page" -> url=/signup, needs_login=false

Return ONLY a JSON object:
{{"url": "<full URL>", "needs_login": <true|false>, "reason": "<one sentence>"}}"""

    result = await call_llm(
        system_prompt="You resolve test case preconditions into URLs. Return only JSON.",
        user_message=prompt,
        max_tokens=200,
        config=interpreter.config,
    )

    import json
    try:
        import re as _re
        json_match = _re.search(r'\{[^{}]*"url"[^{}]*\}', result["text"], _re.DOTALL)
        if json_match:
            return json.loads(json_match.group())
    except (json.JSONDecodeError, KeyError):
        pass

    return {"url": base_url, "needs_login": False, "reason": "fallback"}


async def _perform_login(interpreter: StepInterpreter, base_url: str) -> bool:
    """Log in using credentials from environment variables."""
    login_email = os.getenv("APP_LOGIN_EMAIL") or os.getenv("ADMIN_USERNAME")
    login_password = os.getenv("APP_LOGIN_PASSWORD") or os.getenv("ADMIN_PASSWORD")
    login_path = os.getenv("APP_LOGIN_PATH", "/login")

    if not login_email or not login_password:
        print("    Warning: Login required but APP_LOGIN_EMAIL / APP_LOGIN_PASSWORD not set")
        return False

    login_url = base_url.rstrip("/") + login_path
    print(f"    Logging in at {login_url}...")
    interpreter.browser.open(login_url)

    # Get page state to find form fields
    state_result = interpreter.browser.state()
    page_state = state_result.get("stdout", "")

    # Use AI to find email field and enter it
    cmd = await interpreter.interpret_step(f'Enter email "{login_email}"', page_state)
    await interpreter.execute_command(cmd)

    # Refresh state, find password field
    state_result = interpreter.browser.state()
    page_state = state_result.get("stdout", "")

    cmd = await interpreter.interpret_step(f'Enter password "{login_password}"', page_state)
    await interpreter.execute_command(cmd)

    # Refresh state, click login button
    state_result = interpreter.browser.state()
    page_state = state_result.get("stdout", "")

    cmd = await interpreter.interpret_step('Click the login/sign-in submit button', page_state)
    await interpreter.execute_command(cmd)

    # Wait briefly for login to complete
    await asyncio.sleep(2)
    print("    Login complete")
    return True


async def execute_tc(tc: dict, app_url: str, interpreter: StepInterpreter, screenshots_dir: str) -> dict:
    """Execute a single test case, capturing before/after screenshots per step."""
    print(f"\n{'─' * 60}")
    print(f"  {tc['id']}: {tc['scenario']}")
    print(f"  Category: {tc['category']} | Priority: {tc['priority']}")
    print(f"{'─' * 60}")

    tc_dir = os.path.join(screenshots_dir, tc["id"])
    os.makedirs(tc_dir, exist_ok=True)

    steps_text = tc['steps']
    step_lines = [s.strip() for s in steps_text.split('\n') if s.strip()]
    preconditions = []
    steps = []
    for line in step_lines:
        if re.match(r'Pre:', line, re.IGNORECASE):
            preconditions.append(re.sub(r'^Pre:\s*', '', line, flags=re.IGNORECASE).strip())
            continue
        if re.match(r'Expected Result:', line, re.IGNORECASE):
            continue
        line = re.sub(r'^\d+[\.\)]\s*', '', line)
        if line:
            steps.append(line)

    # Resolve preconditions into a starting URL + login requirement
    start_url = app_url
    needs_login = False
    if preconditions:
        pre_text = "; ".join(preconditions)
        print(f"  Preconditions: {pre_text}")
        resolved = await _resolve_preconditions(interpreter, app_url, pre_text)
        start_url = resolved.get("url", app_url)
        needs_login = resolved.get("needs_login", False)
        print(f"  Resolved start URL: {start_url} | Login needed: {needs_login}")

    # Perform login if precondition requires it
    if needs_login:
        logged_in = await _perform_login(interpreter, app_url)
        if not logged_in:
            return {
                "tc_id": tc["id"], "scenario": tc["scenario"],
                "category": tc["category"], "priority": tc["priority"],
                "status": "FAIL", "step_results": [{
                    "step_num": 0, "step": "Precondition: login",
                    "status": "FAIL", "error": "APP_LOGIN_EMAIL / APP_LOGIN_PASSWORD not set",
                }], "screenshots_dir": tc_dir,
            }
        # Navigate to the target page after login
        if start_url != app_url:
            print(f"\n  Navigating to {start_url}...")
            interpreter.browser.open(start_url)
    else:
        print(f"\n  Opening {start_url}...")
        interpreter.browser.open(start_url)

    # Navigation verification — check if we landed on a valid page
    nav_state = interpreter.browser.state()
    nav_page_state = nav_state.get("stdout", "")
    validity = await interpreter.check_page_valid(nav_page_state)
    heal_log = []  # Track all heals for this TC

    if not validity.get("valid", True):
        print(f"  Warning: Invalid page detected: {validity.get('reason', 'unknown')}")
        fallback_url = app_url
        print(f"  Warning: Falling back to base URL: {fallback_url}")
        interpreter.browser.open(fallback_url)
        # Check fallback
        fb_state = interpreter.browser.state()
        fb_validity = await interpreter.check_page_valid(fb_state.get("stdout", ""))
        if not fb_validity.get("valid", True):
            print(f"  Fallback URL also invalid — failing TC")
            return {
                "tc_id": tc["id"], "scenario": tc["scenario"],
                "category": tc["category"], "priority": tc["priority"],
                "status": "FAIL", "step_results": [{
                    "step_num": 0, "step": "Navigation verification",
                    "status": "FAIL", "error": f"Both {start_url} and {fallback_url} are invalid pages",
                }], "screenshots_dir": tc_dir, "heal_log": [],
            }
        heal_log.append({
            "step_num": 0, "type": "navigation",
            "original_target": start_url, "actual_target": fallback_url,
            "heal_reasoning": f"Precondition URL was invalid ({validity.get('reason', '')}), fell back to base URL",
        })
        print(f"  HEALED: Navigation fell back to {fallback_url}")

    print(f"  Steps to execute: {len(steps)}")

    page_state = ""
    step_results = []
    overall_status = "HEALED" if heal_log else "PASS"
    selector_map = {}  # page_path -> list of element records

    for i, step in enumerate(steps, 1):
        print(f"\n  Step {i}/{len(steps)}: {step[:60]}...")

        before_path = os.path.join(tc_dir, f"step_{i:02d}_before.png")
        after_path = os.path.join(tc_dir, f"step_{i:02d}_after.png")

        try:
            # Get page state
            if not page_state:
                print("    -> Getting page state...")
                state_result = interpreter.browser.state()
                page_state = state_result.get("stdout", "")

            # Screenshot BEFORE
            print("    -> Screenshot before...")
            _screenshot(interpreter, before_path)

            # Interpret step
            print("    -> Interpreting step...")
            cmd_dict = await interpreter.interpret_step(step, page_state)
            print(f"    -> Command: {cmd_dict['command']} {cmd_dict.get('index', '')} {cmd_dict.get('value', '')}")

            # --- Healing check ---
            step_status = "PASS"
            heal_detail = None

            if interpreter.needs_healing(step, cmd_dict):
                print("    Healing triggered — interpreter fell back to screenshot for action step")
                healed = await interpreter.heal_step(step, page_state)

                if healed.get("command") and healed["command"] != "null":
                    print(f"    Healed -> {healed['command']} index={healed.get('index')} | {healed.get('heal_reasoning', '')}")
                    cmd_dict = healed
                    step_status = "HEALED"
                    heal_detail = {
                        "original_target": healed.get("original_target", ""),
                        "actual_target": healed.get("actual_target", ""),
                        "confidence": healed.get("heal_confidence", "UNKNOWN"),
                        "reasoning": healed.get("heal_reasoning", ""),
                    }
                    heal_log.append({
                        "step_num": i, "type": "element",
                        **heal_detail,
                    })
                else:
                    print("    Healing failed — no reasonable match found")
                    step_status = "FAIL"

            # Execute command
            if step_status != "FAIL":
                print("    -> Executing...")
                result = await interpreter.execute_command(cmd_dict)
            else:
                result = {"error": "Element not found and healing failed"}

            # Refresh page state after actions
            if cmd_dict.get("command") in ["click", "input", "upload", "scroll"]:
                print("    -> Refreshing page state...")
                state_result = interpreter.browser.state()
                page_state = state_result.get("stdout", "")

            # Screenshot AFTER
            print("    -> Screenshot after...")
            _screenshot(interpreter, after_path)

            # Track selector for selectors.json
            if cmd_dict.get("index") is not None and page_state:
                selector_info = await interpreter.extract_selector(cmd_dict["index"], page_state)
                # Extract page path from page_state
                page_path = "/"
                for state_line in page_state.split("\n")[:5]:
                    if "http" in state_line:
                        try:
                            page_path = urlparse(state_line.strip()).path or "/"
                        except Exception:
                            pass
                        break
                if page_path not in selector_map:
                    selector_map[page_path] = []
                selector_map[page_path].append({
                    "tc_reference": step[:80],
                    "tag": selector_info.get("tag", ""),
                    "text": selector_info.get("text", ""),
                    "selector_css": selector_info.get("selector_css", ""),
                    "selector_text": selector_info.get("selector_text", ""),
                    "selector_test_id": selector_info.get("selector_test_id"),
                    "attributes": selector_info.get("attributes", {}),
                    "index": cmd_dict.get("index"),
                    "healed": step_status == "HEALED",
                    "used_by": [f"{tc['id']}/step{i}"],
                })

            if result.get("error"):
                print(f"    Error: {result['error']}")
                overall_status = "FAIL"
                step_results.append({
                    "step_num": i, "step": step, "status": "FAIL",
                    "error": result["error"], "command": cmd_dict,
                    "heal_detail": heal_detail,
                    "screenshot_before": before_path, "screenshot_after": after_path,
                })
                continue

            if step_status == "HEALED" and overall_status == "PASS":
                overall_status = "HEALED"

            icon = "HEALED" if step_status == "HEALED" else "OK"
            print(f"    {icon} Step completed ({step_status})")
            step_results.append({
                "step_num": i, "step": step, "status": step_status,
                "command": cmd_dict, "result": result.get("stdout", ""),
                "heal_detail": heal_detail,
                "screenshot_before": before_path, "screenshot_after": after_path,
            })

        except Exception as e:
            print(f"    Exception: {e}")
            _screenshot(interpreter, after_path)
            overall_status = "FAIL"
            step_results.append({
                "step_num": i, "step": step, "status": "ERROR",
                "error": str(e), "heal_detail": None,
                "screenshot_before": before_path, "screenshot_after": after_path,
            })

    print(f"\n  Final Verdict: {overall_status}")

    return {
        "tc_id": tc["id"],
        "scenario": tc["scenario"],
        "category": tc["category"],
        "priority": tc["priority"],
        "status": overall_status,
        "step_results": step_results,
        "screenshots_dir": tc_dir,
        "heal_log": heal_log,
        "selector_map": selector_map,
    }
