"""Step interpreter — converts TC steps to browser-use commands via the AI proxy."""

import json
import re

from . import heal as heal_client
from .browser import BrowserUseCLI
from .llm import call_llm


class StepInterpreter:
    """Interprets TC steps and generates browser-use commands via server-side AI."""

    # This prompt is visible to users — it's generic, not proprietary IP.
    SYSTEM_PROMPT = """You are a browser automation expert. Given a page state and a test step, return the exact browser-use CLI command to execute that step.

Available commands:
- state                    # Refresh and get current page state
- click <index>            # Click element by index
- input <index> "text"     # Type text into element by index
- upload <index> "path"    # Upload file to input element by index
- scroll down              # Scroll page down
- screenshot <path>        # Take screenshot

Page state format:
[index]<element_type> element_text

Return ONLY a JSON object:
{
  "command": "state | click | input | upload | scroll | screenshot",
  "index": <integer or null>,
  "value": "<string or null>",
  "reason": "<one sentence>"
}

STRICT RULES — read carefully:
1. The index MUST be a real integer visible in the current page state. Never guess or invent an index.
2. If the step says "enter text into a field" but NO input/textarea element is in the state — do NOT click buttons. Return command="screenshot" with reason="required input field not found on page".
3. If the step says "click X button" but no button named X is visible — do NOT click a different button. Return command="screenshot" with reason="button not found".
4. Never click a navigation button (Early Access, Sign Up, Get Started, etc.) unless the step explicitly says to click that exact button.
5. Verification steps ("verify", "check", "assert", "expect") always use command="screenshot".
6. When in doubt, return command="screenshot" — never take a destructive guess."""

    # Action verbs that require interacting with a specific UI element
    ACTION_VERBS = re.compile(
        r'\b(click|tap|press|enter|type|input|fill|select|choose|upload|attach|scroll|drag|drop|toggle|check|uncheck|submit|send|locate|find)\b',
        re.IGNORECASE,
    )

    def __init__(self, headed: bool = False, venv_path: str = ".venv", config: dict | None = None):
        self.browser = BrowserUseCLI(venv_path=venv_path, headed=headed)
        self.config = config or {}

    async def interpret_step(
        self,
        step: str,
        page_state: str = "",
    ) -> dict:
        """Interpret a TC step and return a browser-use command dict."""
        prompt = f"""Current page state:
{page_state if page_state else "(no state yet, start with 'state' command)"}

Test step to execute: {step}

Analyze and return the browser-use command to execute this step."""

        result = await call_llm(
            system_prompt=self.SYSTEM_PROMPT,
            user_message=prompt,
            max_tokens=500,
            config=self.config,
        )

        try:
            json_match = re.search(r'\{[^{}]*"command"[^{}]*\}', result["text"], re.DOTALL)
            if json_match:
                cmd_dict = json.loads(json_match.group())
            else:
                cmd_dict = json.loads(result["text"])
            return cmd_dict
        except json.JSONDecodeError as e:
            print(f"  Warning: Failed to parse AI response: {e}")
            print(f"  Raw response: {result['text'][:200]}")
            return {"command": "state", "index": None, "value": None, "reason": "Parse error, refreshing state"}

    async def execute_command(self, cmd_dict: dict) -> dict:
        """Execute a browser-use command."""
        command = cmd_dict["command"]
        index = cmd_dict.get("index")
        value = cmd_dict.get("value")

        if command == "state":
            return self.browser.state()
        elif command == "click" and index is not None:
            return self.browser.click(index)
        elif command == "input" and index is not None and value is not None:
            return self.browser.input(index, value)
        elif command == "upload" and index is not None and value is not None:
            return self.browser.upload(index, value)
        elif command == "scroll":
            return self.browser.scroll_down()
        elif command == "screenshot":
            path = value or f"/tmp/tc_screenshot_{id(cmd_dict)}.png"
            return self.browser.screenshot(path)
        else:
            return {"error": f"Unknown or incomplete command: {cmd_dict}"}

    def needs_healing(self, step_text: str, cmd_dict: dict) -> bool:
        """Detect when interpreter couldn't perform the intended action.

        Returns True when the step had an action verb but the AI fell back to
        a screenshot — which means it couldn't find the target element.
        """
        intended_action = bool(self.ACTION_VERBS.search(step_text))
        actual_command = cmd_dict.get("command")
        return intended_action and actual_command == "screenshot"

    async def heal_step(self, step: str, page_state: str) -> dict:
        """Delegate to heal.py — sends step + DOM to server for healing.

        No healing prompts here. The server has the healing logic.
        """
        return await heal_client.heal_step(step, page_state, self.config)

    async def check_page_valid(self, page_state: str) -> dict:
        """Delegate to heal.py — sends DOM to server to check page validity."""
        if not page_state or len(page_state.strip()) < 20:
            return {"valid": False, "reason": "Page appears blank or empty"}
        return await heal_client.check_page_valid(page_state, self.config)

    async def extract_selector(self, index: int, page_state: str) -> dict:
        """Delegate to heal.py — sends DOM to server to extract a Playwright selector."""
        return await heal_client.extract_selector(index, page_state, self.config)
