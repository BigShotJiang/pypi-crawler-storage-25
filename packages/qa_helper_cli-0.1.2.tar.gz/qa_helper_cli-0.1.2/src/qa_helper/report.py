"""HTML report generator — produces a self-contained report with embedded screenshots."""


def _img_tag(path: str) -> str:
    """Return a clickable <img> tag with base64-encoded image, or a placeholder if missing."""
    import base64
    import os
    if not path or not os.path.exists(path):
        return '<div class="no-img">No screenshot</div>'
    with open(path, "rb") as f:
        data = base64.b64encode(f.read()).decode()
    src = f"data:image/png;base64,{data}"
    return f'<img src="{src}" onclick="openLightbox(this.src)" class="clickable-img" />'


def _esc(text: str) -> str:
    """HTML-escape text to prevent XSS."""
    import html as _html
    return _html.escape(str(text)) if text else ""


def generate_html_report(results: list[dict], meta: dict) -> str:
    """Generate a self-contained HTML report with before/after screenshots per step."""
    timestamp = meta["timestamp"]
    source_file = _esc(meta["source_file"])
    passed = meta["passed"]
    failed = meta["failed"]
    healed = meta.get("healed", 0)
    total = passed + healed + failed

    # Collect all heals across TCs for the healing summary section
    all_heals = []
    for r in results:
        for h in r.get("heal_log", []):
            all_heals.append({"tc_id": r["tc_id"], **h})

    tc_sections = []
    for r in results:
        status_cls = "pass" if r["status"] == "PASS" else ("healed" if r["status"] == "HEALED" else "fail")
        step_rows = []
        for s in r["step_results"]:
            step_status_cls = "pass" if s["status"] == "PASS" else ("healed" if s["status"] == "HEALED" else "fail")
            error_html = f'<div class="error">{_esc(s["error"])}</div>' if s.get("error") else ""
            cmd = s.get("command", {})
            cmd_text = f'{_esc(cmd.get("command",""))} {_esc(str(cmd.get("index","") or ""))} {_esc(str(cmd.get("value","") or ""))}'.strip() if cmd else ""

            # Healing detail box
            heal_html = ""
            if s.get("heal_detail"):
                hd = s["heal_detail"]
                heal_html = f"""<div class="heal-box">
                  <div class="heal-badge">HEALED</div>
                  <div><strong>TC Said:</strong> {_esc(hd.get('original_target', ''))}</div>
                  <div><strong>Matched To:</strong> {_esc(hd.get('actual_target', ''))}</div>
                  <div><strong>Confidence:</strong> {_esc(hd.get('confidence', ''))}</div>
                  <div><strong>Reason:</strong> {_esc(hd.get('reasoning', ''))}</div>
                </div>"""

            step_rows.append(f"""
            <tr class="{step_status_cls}">
              <td class="step-num">Step {s['step_num']}</td>
              <td class="step-desc">{_esc(s['step'])}{error_html}{heal_html}<div class="cmd">{cmd_text}</div></td>
              <td class="screenshot-cell">
                <div class="screenshot-label">Before</div>
                {_img_tag(s.get('screenshot_before',''))}
              </td>
              <td class="screenshot-cell">
                <div class="screenshot-label">After</div>
                {_img_tag(s.get('screenshot_after',''))}
              </td>
              <td class="status-badge">{s['status']}</td>
            </tr>""")

        tc_sections.append(f"""
        <div class="tc-block {status_cls}">
          <div class="tc-header">
            <span class="tc-id">{_esc(r['tc_id'])}</span>
            <span class="tc-scenario">{_esc(r['scenario'])}</span>
            <span class="tc-meta">{_esc(r['category'])} · {_esc(r['priority'])}</span>
            <span class="tc-status {status_cls}">{r['status']}</span>
          </div>
          <table class="steps-table">
            <thead><tr><th>#</th><th>Step</th><th>Before</th><th>After</th><th>Result</th></tr></thead>
            <tbody>{''.join(step_rows)}</tbody>
          </table>
        </div>""")

    # Healing summary section
    heal_summary_html = ""
    if all_heals:
        heal_rows = []
        for h in all_heals:
            heal_rows.append(f"""<tr>
              <td>{_esc(h.get('tc_id', ''))}</td>
              <td>Step {h.get('step_num', 0)}</td>
              <td>{_esc(h.get('type', ''))}</td>
              <td>{_esc(h.get('original_target', ''))}</td>
              <td>{_esc(h.get('actual_target', ''))}</td>
              <td>{_esc(h.get('reasoning', h.get('heal_reasoning', '')))}</td>
            </tr>""")
        heal_summary_html = f"""
        <div class="heal-summary">
          <h2>Healing Summary</h2>
          <p>{len(all_heals)} heal(s) applied. Review these to determine if TCs need updating or if these are real bugs.</p>
          <table class="heal-table">
            <thead><tr><th>TC</th><th>Step</th><th>Type</th><th>TC Referenced</th><th>Matched To</th><th>Reason</th></tr></thead>
            <tbody>{''.join(heal_rows)}</tbody>
          </table>
        </div>"""

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>TC Report — {source_file}</title>
<style>
  body {{ font-family: system-ui, sans-serif; background: #f5f5f5; margin: 0; padding: 20px; color: #222; }}
  h1 {{ font-size: 1.4rem; margin-bottom: 4px; }}
  .meta {{ color: #666; font-size: 0.85rem; margin-bottom: 20px; }}
  .summary {{ display: flex; gap: 16px; margin-bottom: 28px; }}
  .summary-box {{ padding: 12px 20px; border-radius: 8px; font-weight: 600; font-size: 1rem; }}
  .summary-box.total {{ background: #e8eaf6; color: #3949ab; }}
  .summary-box.pass {{ background: #e8f5e9; color: #2e7d32; }}
  .summary-box.healed {{ background: #fff3e0; color: #e65100; }}
  .summary-box.fail {{ background: #fce4ec; color: #c62828; }}
  .tc-block {{ background: #fff; border-radius: 10px; margin-bottom: 24px; overflow: hidden; box-shadow: 0 1px 4px rgba(0,0,0,.1); }}
  .tc-block.pass {{ border-left: 5px solid #4caf50; }}
  .tc-block.healed {{ border-left: 5px solid #ff9800; }}
  .tc-block.fail {{ border-left: 5px solid #f44336; }}
  .tc-header {{ display: flex; align-items: center; gap: 12px; padding: 14px 18px; background: #fafafa; border-bottom: 1px solid #eee; flex-wrap: wrap; }}
  .tc-id {{ font-weight: 700; font-size: 0.95rem; color: #1a237e; }}
  .tc-scenario {{ flex: 1; font-size: 0.9rem; }}
  .tc-meta {{ font-size: 0.78rem; color: #888; }}
  .tc-status {{ font-weight: 700; font-size: 0.85rem; padding: 3px 10px; border-radius: 12px; }}
  .tc-status.pass {{ background: #e8f5e9; color: #2e7d32; }}
  .tc-status.healed {{ background: #fff3e0; color: #e65100; }}
  .tc-status.fail {{ background: #fce4ec; color: #c62828; }}
  .steps-table {{ width: 100%; border-collapse: collapse; font-size: 0.83rem; }}
  .steps-table th {{ background: #f0f0f0; padding: 8px 12px; text-align: left; font-weight: 600; }}
  .steps-table td {{ padding: 10px 12px; vertical-align: top; border-top: 1px solid #f0f0f0; }}
  tr.pass {{ background: #fff; }}
  tr.healed {{ background: #fff8f0; }}
  tr.fail {{ background: #fff8f8; }}
  tr.error {{ background: #fff8f8; }}
  .step-num {{ white-space: nowrap; color: #888; font-size: 0.8rem; width: 60px; }}
  .step-desc {{ max-width: 280px; line-height: 1.5; }}
  .cmd {{ font-family: monospace; font-size: 0.75rem; color: #555; margin-top: 4px; background: #f5f5f5; padding: 2px 6px; border-radius: 4px; }}
  .error {{ color: #c62828; font-size: 0.8rem; margin-top: 4px; }}
  .screenshot-cell {{ width: 260px; }}
  .screenshot-cell img {{ max-width: 240px; border-radius: 6px; border: 1px solid #ddd; display: block; cursor: pointer; transition: opacity .15s; }}
  .screenshot-cell img:hover {{ opacity: .8; }}
  .lightbox {{ display: none; position: fixed; inset: 0; background: rgba(0,0,0,.85); z-index: 9999; justify-content: center; align-items: center; cursor: pointer; }}
  .lightbox.open {{ display: flex; }}
  .lightbox img {{ max-width: 92vw; max-height: 92vh; border-radius: 8px; box-shadow: 0 4px 30px rgba(0,0,0,.5); }}
  .lightbox-close {{ position: fixed; top: 16px; right: 24px; color: #fff; font-size: 2rem; cursor: pointer; z-index: 10000; line-height: 1; }}
  .screenshot-label {{ font-size: 0.72rem; color: #999; margin-bottom: 4px; text-transform: uppercase; letter-spacing: .05em; }}
  .no-img {{ color: #bbb; font-size: 0.78rem; font-style: italic; }}
  .status-badge {{ font-weight: 700; font-size: 0.8rem; white-space: nowrap; width: 60px; }}
  tr.pass .status-badge {{ color: #2e7d32; }}
  tr.healed .status-badge {{ color: #e65100; }}
  tr.fail .status-badge, tr.error .status-badge {{ color: #c62828; }}
  .heal-box {{ background: #fff3e0; border: 1px solid #ffcc80; border-radius: 6px; padding: 8px 12px; margin-top: 6px; font-size: 0.8rem; }}
  .heal-badge {{ display: inline-block; background: #ff9800; color: #fff; font-weight: 700; font-size: 0.72rem; padding: 2px 8px; border-radius: 10px; margin-bottom: 4px; }}
  .heal-box div {{ margin: 2px 0; }}
  .heal-summary {{ background: #fff; border-radius: 10px; margin-top: 28px; padding: 20px 24px; box-shadow: 0 1px 4px rgba(0,0,0,.1); }}
  .heal-summary h2 {{ font-size: 1.1rem; margin: 0 0 8px; color: #e65100; }}
  .heal-summary p {{ font-size: 0.85rem; color: #666; margin: 0 0 12px; }}
  .heal-table {{ width: 100%; border-collapse: collapse; font-size: 0.82rem; }}
  .heal-table th {{ background: #fff3e0; padding: 8px 10px; text-align: left; font-weight: 600; }}
  .heal-table td {{ padding: 6px 10px; border-top: 1px solid #f0f0f0; }}
</style>
</head>
<body>
<h1>TC Execution Report</h1>
<div class="meta">Source: {source_file} &nbsp;·&nbsp; {timestamp}</div>
<div class="summary">
  <div class="summary-box total">Total: {total}</div>
  <div class="summary-box pass">Pass: {passed}</div>
  <div class="summary-box healed">Healed: {healed}</div>
  <div class="summary-box fail">Fail: {failed}</div>
</div>
{''.join(tc_sections)}
{heal_summary_html}
<div class="lightbox" id="lightbox" onclick="closeLightbox()">
  <span class="lightbox-close" onclick="closeLightbox()">&times;</span>
  <img id="lightbox-img" src="" alt="Screenshot" />
</div>
<script>
function openLightbox(src) {{
  var lb = document.getElementById('lightbox');
  document.getElementById('lightbox-img').src = src;
  lb.classList.add('open');
}}
function closeLightbox() {{
  document.getElementById('lightbox').classList.remove('open');
}}
document.addEventListener('keydown', function(e) {{
  if (e.key === 'Escape') closeLightbox();
}});
</script>
</body>
</html>"""
