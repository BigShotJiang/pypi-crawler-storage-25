"""CLI entry point — argparse-based command dispatcher for qa-helper."""

import argparse
import asyncio
import json
import os
import sys
from datetime import datetime

from .parser import parse_tcs_from_markdown
from .llm import NotLoggedInError


def cmd_list(md_file: str) -> None:
    """Parse and print all TCs from a markdown file."""
    if not os.path.exists(md_file):
        print(f"Error: File not found: {md_file}", file=sys.stderr)
        sys.exit(1)

    tcs = parse_tcs_from_markdown(md_file)
    if not tcs:
        print(f"No TCs found in {md_file}")
        sys.exit(0)

    print(f"\nFound {len(tcs)} test cases in {md_file}\n")
    for tc in tcs:
        print(f"  {tc['id']:8s} [{tc['priority']:6s}] {tc['category']:20s}  {tc['scenario']}")
    print()


async def cmd_execute(md_file: str, tc_ids: list[str] | None, app_url: str, headed: bool, venv: str) -> None:
    """Execute test cases from a markdown file."""
    from .config import load_config
    from .executor import execute_tc
    from .interpreter import StepInterpreter
    from .report import generate_html_report

    if not os.path.exists(md_file):
        print(f"Error: File not found: {md_file}", file=sys.stderr)
        sys.exit(1)

    config = load_config()

    if not config.get("access_token"):
        print("Error: Not logged in. Run: qa-helper login", file=sys.stderr)
        sys.exit(1)

    all_tcs = parse_tcs_from_markdown(md_file)
    if not all_tcs:
        print(f"No TCs found in {md_file}")
        sys.exit(1)

    print(f"\nFound {len(all_tcs)} TCs in {md_file}")

    if tc_ids:
        ids_upper = [t.upper() for t in tc_ids]
        tcs = [tc for tc in all_tcs if tc["id"] in ids_upper]
        missing = set(ids_upper) - {tc["id"] for tc in tcs}
        if missing:
            print(f"Error: TCs not found: {', '.join(sorted(missing))}", file=sys.stderr)
            sys.exit(1)
    else:
        tcs = all_tcs

    run_ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    output_dir = os.path.join("qa_run_result", f"run_{run_ts}")
    screenshots_dir = os.path.join(output_dir, "screenshots")
    os.makedirs(screenshots_dir, exist_ok=True)

    print(f"\nApp URL:      {app_url}")
    print(f"TCs:          {', '.join(tc['id'] for tc in tcs)}")
    print(f"Screenshots:  {screenshots_dir}/")
    print(f"{'=' * 60}")

    results = []
    for tc in tcs:
        # Fresh browser per TC — no cookie/session bleed between test cases
        interpreter = StepInterpreter(headed=headed, venv_path=venv, config=config)
        try:
            result = await execute_tc(tc, app_url, interpreter, screenshots_dir)
        finally:
            interpreter.browser.close()
        results.append(result)

    passed = sum(1 for r in results if r["status"] == "PASS")
    healed = sum(1 for r in results if r["status"] == "HEALED")
    failed = sum(1 for r in results if r["status"] in ("FAIL", "ERROR"))

    print(f"\n{'=' * 60}")
    print("  SUMMARY")
    print(f"{'=' * 60}")
    for r in results:
        icon = {"PASS": "PASS", "HEALED": "HEALED", "FAIL": "FAIL"}.get(r["status"], "?")
        print(f"  [{icon}] {r['tc_id']:8s} {r['scenario'][:50]}")
    print(f"\n  {passed} Pass  {healed} Healed  {failed} Fail")
    print(f"{'=' * 60}")

    now = datetime.now().isoformat()

    merged_selectors: dict = {}
    for r in results:
        for page_path, elements in r.get("selector_map", {}).items():
            if page_path not in merged_selectors:
                merged_selectors[page_path] = []
            merged_selectors[page_path].extend(elements)

    selectors_file = os.path.join(output_dir, "selectors.json")
    with open(selectors_file, "w") as f:
        json.dump({"app_url": app_url, "timestamp": now, "pages": merged_selectors}, f, indent=2)

    json_report = os.path.join(output_dir, f"tc_report_{run_ts}.json")
    with open(json_report, "w") as f:
        json.dump({
            "timestamp": now,
            "source_file": md_file,
            "app_url": app_url,
            "summary": {"passed": passed, "healed": healed, "failed": failed},
            "results": results,
        }, f, indent=2)

    html_report = os.path.join(output_dir, f"tc_report_{run_ts}.html")
    html = generate_html_report(results, {
        "timestamp": now,
        "source_file": md_file,
        "passed": passed,
        "healed": healed,
        "failed": failed,
    })
    with open(html_report, "w") as f:
        f.write(html)

    print(f"\n  JSON report:  {json_report}")
    print(f"  HTML report:  {html_report}  <- open this in a browser")
    print(f"  Selectors:    {selectors_file}")


def main() -> None:
    """Main CLI entry point."""
    # Detect subcommand before argparse to avoid conflict with md_file positional
    if len(sys.argv) >= 2 and sys.argv[1] == "login":
        from . import auth
        try:
            asyncio.run(auth.login())
        except NotImplementedError as e:
            print(f"Not yet available: {e}", file=sys.stderr)
            sys.exit(1)
        return

    if len(sys.argv) >= 2 and sys.argv[1] == "logout":
        from . import auth
        try:
            auth.logout()
        except NotImplementedError as e:
            print(f"Not yet available: {e}", file=sys.stderr)
            sys.exit(1)
        return

    parser = argparse.ArgumentParser(
        prog="qa-helper",
        description="Execute QA test cases with AI-powered browser automation",
        usage="qa-helper [login|logout] | qa-helper <file.md> [--list] [--tc TC-001 ...] [--url URL] [--headed]",
    )
    parser.add_argument("md_file", help="Path to markdown file containing test cases")
    parser.add_argument("--list", action="store_true", help="List TCs and exit (no server required)")
    parser.add_argument("--tc", nargs="*", dest="tc_ids", metavar="TC_ID", help="Specific TC IDs to run (e.g. TC-001 TC-003)")
    parser.add_argument("--url", default="http://localhost:3000", metavar="URL", help="App URL to test against (default: http://localhost:3000)")
    parser.add_argument("--headed", action="store_true", help="Run browser in visible window")
    parser.add_argument("--venv", default=".venv", metavar="PATH", help="Virtual environment path for browser-use (default: .venv)")

    args = parser.parse_args()

    if args.list:
        cmd_list(args.md_file)
        return

    try:
        asyncio.run(cmd_execute(
            md_file=args.md_file,
            tc_ids=args.tc_ids,
            app_url=args.url,
            headed=args.headed,
            venv=args.venv,
        ))
    except NotLoggedInError as e:
        print(f"\nError: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
