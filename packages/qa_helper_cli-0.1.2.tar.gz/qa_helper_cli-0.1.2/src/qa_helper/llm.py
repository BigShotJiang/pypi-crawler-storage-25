"""LLM proxy client — sends interpretation requests to the QA Helper server."""

import asyncio
import httpx


class NotLoggedInError(Exception):
    """Raised when no auth token is found in config."""
    pass


async def call_llm(
    system_prompt: str,
    user_message: str,
    max_tokens: int = 2000,
    temperature: float = 0.1,
    config: dict | None = None,
) -> dict:
    """Send a prompt to the server's AI proxy and return the response.

    The server handles model selection and API keys — the CLI never
    needs to know which AI provider is being used.
    """
    config = config or {}
    server_url = config.get("server_url", "https://www.qa-helper.xyz")
    access_token = config.get("access_token")

    if not access_token:
        raise NotLoggedInError("Not logged in. Run: qa-helper login")

    payload = {
        "system_prompt": system_prompt,
        "user_message": user_message,
        "max_tokens": max_tokens,
        "temperature": temperature,
    }

    retryable = {502, 503, 504}
    delays = [3, 6, 12]

    for attempt, delay in enumerate(delays + [None]):
        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.post(
                f"{server_url}/api/cli/interpret",
                headers={"Authorization": f"Bearer {access_token}"},
                json=payload,
            )

        if response.status_code == 401:
            raise NotLoggedInError("Not authorized. Run: qa-helper login")

        if response.status_code == 429:
            raise Exception("Rate limit exceeded. Try again in a few minutes.")

        if response.status_code in retryable and delay is not None:
            await asyncio.sleep(delay)
            continue

        if response.status_code != 200:
            raise Exception(f"Server error {response.status_code}: {response.text[:200]}")

        data = response.json()
        return {"text": data.get("text", ""), "tokens": data.get("tokens_used", 0)}

    raise Exception(f"Server error {response.status_code} after retries: {response.text[:200]}")
