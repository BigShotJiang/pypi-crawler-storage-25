"""Config management — read/write ~/.qa-helper/config.json."""

import json
import os
from pathlib import Path


def get_config_path() -> Path:
    """Return path to config file."""
    return Path.home() / ".qa-helper" / "config.json"


def load_config() -> dict:
    """Load config from ~/.qa-helper/config.json. Returns empty dict if not found."""
    path = get_config_path()
    if not path.exists():
        return {}
    try:
        with open(path) as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


def save_config(config: dict) -> None:
    """Write config to ~/.qa-helper/config.json, creating directory if needed."""
    path = get_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(config, f, indent=2)
