"""TC markdown parser — converts markdown test case files to structured dicts."""

import re


def parse_tcs_from_markdown(filepath: str) -> list[dict]:
    """Parse test cases from markdown — supports both table format and header/bullet format."""
    with open(filepath, "r") as f:
        content = f.read()

    # --- Try table format first (pipe-delimited, 6 columns) ---
    step3_match = re.search(r"## Step 3: Test Cases(.*?)(?=\n## (?!#)|$)", content, re.DOTALL)
    if step3_match:
        section = step3_match.group(1)
    else:
        section = content

    table_tcs = []
    for line in section.split("\n"):
        line = line.strip()
        if not line.startswith("|"):
            continue
        cells = [c.strip() for c in line.split("|")]
        cells = [c for c in cells if c or c == ""]
        if cells and cells[0] == "":
            cells = cells[1:]
        if cells and cells[-1] == "":
            cells = cells[:-1]
        if len(cells) != 6:
            continue
        if not re.match(r"TC-\d+", cells[0]):
            continue
        steps = cells[4].replace("<br>", "\n").replace("<br/>", "\n")
        steps = steps.replace("**✓ Expect:**", "Expected Result:")
        steps = steps.replace("**", "")
        table_tcs.append({
            "id": cells[0].strip(),
            "category": cells[1].strip(),
            "scenario": cells[2].strip(),
            "acs": cells[3].strip(),
            "steps": steps,
            "priority": cells[5].strip(),
        })

    if table_tcs:
        return table_tcs

    # --- Fallback: header/bullet format (#### TC-NNN: Title) ---
    # Scan for TC blocks, track category from ### section headers above each TC
    header_tcs = []
    current_category = "General"

    lines = content.split("\n")
    i = 0
    while i < len(lines):
        line = lines[i]

        # Track category from ### headers (Happy Path, Negative, etc.)
        cat_match = re.match(r"^###\s+(.+)", line)
        if cat_match:
            current_category = cat_match.group(1).strip()
            i += 1
            continue

        # Match TC header: #### TC-001: Title
        tc_match = re.match(r"^#{3,5}\s+(TC-\d+[\w-]*):\s*(.+)", line)
        if not tc_match:
            i += 1
            continue

        tc_id = tc_match.group(1).strip()
        scenario = tc_match.group(2).strip()
        priority = "Medium"
        acs = ""
        steps_lines = []
        expect_line = ""

        # Read bullet fields until next TC header or section header
        i += 1
        while i < len(lines):
            l = lines[i].strip()
            if re.match(r"^#{3,5}\s+TC-\d+", lines[i]) or re.match(r"^#{2,3}\s+", lines[i]):
                break

            pri_match = re.match(r"[-*]\s*\*\*Priority:\*\*\s*(.+)", l)
            if pri_match:
                priority = pri_match.group(1).strip()
                i += 1
                continue

            acs_match = re.match(r"[-*]\s*\*\*ACs?:\*\*\s*(.+)", l)
            if acs_match:
                acs = acs_match.group(1).strip()
                i += 1
                continue

            expect_match = re.match(r"[-*]\s*\*\*[✓]?\s*Expect(?:ed)?(?:\s*Result)?:\*\*\s*(.*)", l)
            if expect_match:
                expect_line = expect_match.group(1).strip()
                i += 1
                continue

            # Skip the "Steps & Expected:" label line
            if re.match(r"[-*]\s*\*\*Steps.*:\*\*", l):
                i += 1
                continue

            # Numbered step lines and Pre: lines
            if re.match(r"[-*]\s*(Pre:|(?:\d+[\.\)])\s+)", l) or (l.startswith("-") and l[1:].strip()):
                step_text = re.sub(r"^[-*]\s*", "", l)
                if step_text and not step_text.startswith("Data:"):
                    steps_lines.append(step_text)

            i += 1

        if expect_line:
            steps_lines.append(f"Expected Result: {expect_line}")

        header_tcs.append({
            "id": tc_id,
            "category": current_category,
            "scenario": scenario,
            "acs": acs,
            "steps": "\n".join(steps_lines),
            "priority": priority,
        })

    if not header_tcs:
        print("Warning: No '## Step 3: Test Cases' section found, scanning entire file.")

    return header_tcs
