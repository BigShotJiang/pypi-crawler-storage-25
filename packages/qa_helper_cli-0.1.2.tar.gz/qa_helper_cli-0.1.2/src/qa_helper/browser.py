"""Browser-use CLI wrapper — thin shell around browser-use subprocess commands."""

import subprocess


class BrowserUseCLI:
    """Wrapper around browser-use CLI commands."""

    def __init__(self, venv_path: str = ".venv", headed: bool = False):
        self.venv_path = venv_path
        self.headed = headed
        self.activate_cmd = f"source {venv_path}/bin/activate && "

    def run(self, command: str, capture_output: bool = True) -> dict:
        """Execute a browser-use command via subprocess."""
        headed_flag = "--headed " if self.headed else ""
        full_cmd = f"{self.activate_cmd} browser-use {headed_flag}{command}"
        result = subprocess.run(
            full_cmd,
            shell=True,
            capture_output=capture_output,
            text=True,
            timeout=30,
        )

        return {
            "command": command,
            "exit_code": result.returncode,
            "stdout": result.stdout.strip() if result.stdout else "",
            "stderr": result.stderr.strip() if result.stderr else "",
        }

    def open(self, url: str) -> dict:
        """Open URL in browser."""
        return self.run(f"open {url}")

    def state(self) -> dict:
        """Get current page state."""
        return self.run("state")

    def click(self, index: int) -> dict:
        """Click element by index."""
        return self.run(f"click {index}")

    def input(self, index: int, text: str) -> dict:
        """Input text into element."""
        # Escape special shell characters in text
        escaped_text = text.replace('"', '\\"').replace("'", "\\'").replace("`", "\\`")
        return self.run(f'input {index} "{escaped_text}"')

    def upload(self, index: int, file_path: str) -> dict:
        """Upload file to input element."""
        return self.run(f'upload {index} "{file_path}"')

    def scroll_down(self) -> dict:
        """Scroll page down."""
        return self.run("scroll down")

    def screenshot(self, path: str) -> dict:
        """Take screenshot."""
        return self.run(f"screenshot {path}")

    def close(self) -> dict:
        """Close browser."""
        return self.run("close")
