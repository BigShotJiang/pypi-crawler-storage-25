"""QA Helper CLI — Execute test cases with AI-powered browser automation."""

__version__ = "0.1.0"
