"""Heal client — sends raw step + DOM data to the server for AI healing.

No healing prompts live here — those are server-side IP.
This module is a pure API client: sends data, receives commands.
"""

import asyncio
import httpx
from .llm import NotLoggedInError


async def _post(action: str, payload: dict, config: dict) -> dict:
    """Send a healing request to the server."""
    server_url = config.get("server_url", "https://www.qa-helper.xyz")
    access_token = config.get("access_token")

    if not access_token:
        raise NotLoggedInError("Not logged in. Run: qa-helper login")

    body = {"action": action, **payload}
    retryable = {502, 503, 504}
    delays = [3, 6, 12]

    for delay in delays + [None]:
        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.post(
                f"{server_url}/api/cli/heal",
                headers={"Authorization": f"Bearer {access_token}"},
                json=body,
            )

        if response.status_code == 401:
            raise NotLoggedInError("Not authorized. Run: qa-helper login")

        if response.status_code in retryable and delay is not None:
            await asyncio.sleep(delay)
            continue

        if response.status_code != 200:
            raise Exception(f"Heal server error {response.status_code}: {response.text[:200]}")

        return response.json()

    raise Exception(f"Heal server error {response.status_code} after retries: {response.text[:200]}")


async def heal_step(step: str, page_state: str, config: dict) -> dict:
    """Send a failed step + current DOM to the server for healing.

    The server applies the healing prompt (hidden IP) and returns
    the best matching command.
    """
    return await _post("heal_step", {"step": step, "page_state": page_state}, config)


async def check_page_valid(page_state: str, config: dict) -> dict:
    """Send current DOM to server to check if the page loaded successfully."""
    return await _post("check_page", {"page_state": page_state}, config)


async def extract_selector(index: int, page_state: str, config: dict) -> dict:
    """Send DOM to server to extract a Playwright-usable selector for an element."""
    return await _post("extract_selector", {"index": index, "page_state": page_state}, config)
