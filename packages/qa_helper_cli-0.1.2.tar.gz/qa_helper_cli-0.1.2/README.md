# qa-helper-cli

Execute AI-generated test cases against your app using browser automation.

## Install

```bash
pip install qa-helper-cli
playwright install chromium
```

## Usage

```bash
# Authenticate with your QA Helper account
qa-helper login

# List all TCs in a markdown file (no login needed)
qa-helper testcases.md --list

# Run a specific TC
qa-helper testcases.md --tc TC-001

# Run multiple TCs
qa-helper testcases.md --tc TC-001 TC-003

# Run all TCs
qa-helper testcases.md

# Run against a specific app URL
qa-helper testcases.md --url https://staging.myapp.com

# Run with visible browser
qa-helper testcases.md --headed

# Clear credentials
qa-helper logout
```

## Requirements

- Python 3.10+
- A QA Helper account at [qa-helper.xyz](https://www.qa-helper.xyz)
