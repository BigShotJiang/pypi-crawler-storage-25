"""
this test module shall verify that code generation from direct connection
with postgres works
"""

from helpers.helpers import collect_code_info
from helpers.verify_helpers import postgres_verify


def test_gen_code():

    sql = '''CREATE TABLE users(
    id uuid NOT NULL,
    PRIMARY KEY (id),
    email TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL UNIQUE,
    psw_hash TEXT NOT NULL,
    registered_at TIMESTAMP WITH TIME ZONE NOT NULL,
    date_of_birth DATE
);

CREATE TABLE leagues(
    id uuid PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    public BOOLEAN NOT NULL
);

CREATE TABLE participations(
    admin BOOLEAN NOT NULL,
    user_id uuid,
    FOREIGN KEY (user_id) REFERENCES users(id),
    league_id uuid,
    FOREIGN KEY (league_id) REFERENCES leagues(id),
    PRIMARY KEY (user_id, league_id)
);

CREATE TABLE invitations(
    invitee_id uuid,
    FOREIGN KEY (invitee_id) REFERENCES users(id),
    league_id uuid,
    FOREIGN KEY (league_id) REFERENCES leagues(id),
    inviter_id uuid,
    FOREIGN KEY (inviter_id) REFERENCES users(id),
    PRIMARY KEY (invitee_id, league_id)
);

CREATE TABLE nations(
    id BIGSERIAL PRIMARY KEY,
    name TEXT NOT NULL
);

CREATE TABLE athletes(
    id BIGSERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    nation_id BIGSERIAL,
    FOREIGN KEY (nation_id) REFERENCES nations(id),
    height INTEGER,
    weight INTEGER,
    bio TEXT,
    nickname TEXT
);'''

    code_generated = postgres_verify(sql, rels=True)

    assert collect_code_info(code_generated) == collect_code_info('''from sqlmodel import SQLModel, Field, Relationship, UniqueConstraint
from uuid import UUID, uuid4
from datetime import datetime
from datetime import date

                                                                      
class Users(SQLModel, table=True):
    __tablename__ = 'users'
    __table_args__ = (UniqueConstraint('email'), UniqueConstraint('name'))
    id: UUID = Field(primary_key=True, default_factory=uuid4)
    email: str
    name: str
    psw_hash: str
    registered_at: datetime
    date_of_birth: date | None
    participationss: list['Participations'] = Relationship(back_populates='user')
    invitationss: list['Invitations'] = Relationship(back_populates='invitee')
    invitationss0: list['Invitations'] = Relationship(back_populates='inviter')

class Participations(SQLModel, table=True):
    __tablename__ = 'participations'
    admin: bool
    user_id: UUID = Field(primary_key=True, foreign_key='users.id', default_factory=uuid4)
    league_id: UUID = Field(primary_key=True, foreign_key='leagues.id', default_factory=uuid4)
    user: 'Users' | None = Relationship(back_populates='participationss')
    league: 'Leagues' | None = Relationship(back_populates='participationss')

class Leagues(SQLModel, table=True):
    __tablename__ = 'leagues'
    __table_args__ = (UniqueConstraint('name'),)
    id: UUID = Field(primary_key=True, default_factory=uuid4)
    name: str
    public: bool
    participationss: list['Participations'] = Relationship(back_populates='league')
    invitationss: list['Invitations'] = Relationship(back_populates='league')

class Invitations(SQLModel, table=True):
    __tablename__ = 'invitations'
    invitee_id: UUID = Field(primary_key=True, foreign_key='users.id', default_factory=uuid4)
    league_id: UUID = Field(primary_key=True, foreign_key='leagues.id', default_factory=uuid4)
    inviter_id: UUID | None = Field(foreign_key='users.id', default_factory=uuid4)
    invitee: 'Users' | None = Relationship(back_populates='invitationss')
    league: 'Leagues' | None = Relationship(back_populates='invitationss')
    inviter: 'Users' | None = Relationship(back_populates='invitationss0')

class Nations(SQLModel, table=True):
    __tablename__ = 'nations'
    id: int = Field(primary_key=True)
    name: str
    athletess: list['Athletes'] = Relationship(back_populates='nation')

class Athletes(SQLModel, table=True):
    __tablename__ = 'athletes'
    id: int = Field(primary_key=True)
    name: str
    nation_id: int = Field(foreign_key='nations.id')
    height: int | None
    weight: int | None
    bio: str | None
    nickname: str | None
    nation: 'Nations' | None = Relationship(back_populates='athletess')''')


def test_postgres_schema_varying_uniques():
    '''
    the purpose of this test is to verify that a postgres database
    with a schema and tables with and without uniques is correctly
    processed
    '''

    sql = '''CREATE SCHEMA IF NOT EXISTS user_data;
    
CREATE TABLE user_data.users(
    id uuid NOT NULL,
    PRIMARY KEY (id),
    email TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL UNIQUE,
    psw TEXT NOT NULL
);

CREATE TABLE user_data.stuff(
    id uuid NOT NULL,
    PRIMARY KEY (id),
    email TEXT NOT NULL,
    name TEXT NOT NULL,
    psw TEXT NOT NULL
);
'''

    code_generated = postgres_verify(sql, rels=True)

    assert collect_code_info(code_generated) == collect_code_info('''
from sqlmodel import SQLModel, Field, UniqueConstraint
from uuid import UUID, uuid4

class Users(SQLModel, table=True):
    __tablename__ = 'users'
    __table_args__ = (UniqueConstraint('email'), UniqueConstraint('name'), {'schema': 'user_data'})
    id: UUID = Field(primary_key=True, default_factory=uuid4)
    email: str
    name: str
    psw: str


class Stuff(SQLModel, table=True):
    __tablename__ = 'stuff'
    __table_args__ = {'schema': 'user_data'}
    id: UUID = Field(primary_key=True, default_factory=uuid4)
    email: str
    name: str
    psw: str
''')
