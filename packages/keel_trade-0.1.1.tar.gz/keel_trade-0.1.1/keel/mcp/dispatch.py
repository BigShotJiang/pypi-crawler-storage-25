"""Tool dispatch — routes MCP tool calls to local functions or remote API."""

from __future__ import annotations

from typing import Any

from keel.mcp.registry import _LOCAL_TOOLS, _REMOTE_TOOLS


# Map tool names to keel.tools.local function names (most are 1:1)
_LOCAL_DISPATCH: dict[str, str] = {
    "strategy_components_search": "strategy_components_search",
    "strategy_component_detail": "strategy_component_detail",
    "strategy_components_after": "strategy_components_after",
    "strategy_components_before": "strategy_components_before",
    "strategy_components_dump": "strategy_components_dump",
    "dsl_reference": "dsl_reference",
    "strategy_new": "strategy_new_inline",
    "strategy_validate": "strategy_validate",
    "strategy_explain": "strategy_explain",
    "strategy_diff": "strategy_diff",
    "strategy_examples": "strategy_examples",
    "composition_patterns": "composition_patterns",
    "pipeline_stage": "pipeline_stage",
    "strategy_lock_generate": "strategy_lock_generate",
    "strategy_lock_status": "strategy_lock_status",
    "strategy_lock_upgrade": "strategy_lock_upgrade",
    "strategy_checkout": "strategy_checkout",
    "strategy_push": "strategy_push",
    "strategy_pull": "strategy_pull",
    "strategy_status": "strategy_status",
    "strategy_workspaces": "strategy_workspaces",
    "strategy_discard": "strategy_discard",
    "universe_set": "universe_set",
    "universe_get": "universe_get",
    "universe_add_group": "universe_add_group",
    "universe_modify_group": "universe_modify_group",
    "universe_remove_group": "universe_remove_group",
}


def execute_local(tool_name: str, arguments: dict[str, Any]) -> Any:
    """Execute a local tool by name. Returns the result dict."""
    func_name = _LOCAL_DISPATCH.get(tool_name)
    if not func_name:
        raise ValueError(f"Unknown local tool: {tool_name}")

    import keel.tools.local as tools

    func = getattr(tools, func_name)
    return func(**arguments)


def execute_remote(tool_name: str, arguments: dict[str, Any]) -> Any:
    """Execute a remote tool via the Keel API."""
    info = _REMOTE_TOOLS.get(tool_name)
    if not info:
        raise ValueError(f"Unknown remote tool: {tool_name}")

    from keel.client import KeelClient

    client = KeelClient()
    method = info["method"]
    path = info["path"]

    # Substitute path parameters from arguments
    path_params = {}
    remaining = dict(arguments)
    for key in list(remaining.keys()):
        placeholder = "{" + key + "}"
        if placeholder in path:
            path = path.replace(placeholder, str(remaining.pop(key)))
            path_params[key] = True

    try:
        if method == "GET":
            return client.get(path, **remaining)
        elif method == "POST":
            return client.post(path, json=remaining or None)
        elif method == "PATCH":
            return client.patch(path, json=remaining or None)
        elif method == "DELETE":
            return client.delete(path)
        else:
            raise ValueError(f"Unsupported method: {method}")
    finally:
        client.close()


def execute_tool(tool_name: str, arguments: dict[str, Any]) -> Any:
    """Execute any tool — routes to local or remote based on name."""
    if tool_name in _LOCAL_TOOLS:
        return execute_local(tool_name, arguments)
    if tool_name in _REMOTE_TOOLS:
        return execute_remote(tool_name, arguments)
    raise ValueError(f"Unknown tool: {tool_name}")
