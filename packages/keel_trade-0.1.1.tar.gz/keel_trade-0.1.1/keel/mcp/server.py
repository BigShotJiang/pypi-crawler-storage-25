"""MCP server — exposes all Keel tools directly via the Model Context Protocol.

Each bundled tool (local) and remote API operation is registered as a
first-class MCP tool. Agents call them directly — no meta-tool indirection.
"""

from __future__ import annotations

import json
from typing import Any

from fastmcp import FastMCP

from keel.mcp.dispatch import execute_tool
from keel.mcp.registry import _REMOTE_TOOLS, get_registry


def _make_tool_handler(tool_name: str, properties: dict[str, Any], required: list[str]):
    """Create a typed handler function for a given tool from its JSON schema.

    Dynamically builds a function with explicit parameters (no **kwargs)
    so FastMCP can introspect the signature for MCP tool registration.
    """
    import types

    param_names = list(properties.keys())

    def handler_impl(args: dict[str, Any]) -> str:
        try:
            result = execute_tool(tool_name, args)
            return json.dumps(result, indent=2, default=str)
        except Exception as e:
            from keel.errors import KeelError

            if isinstance(e, KeelError):
                return json.dumps(e.to_dict())
            return json.dumps({
                "error": "execution_failed",
                "message": str(e),
                "retryable": False,
            })

    # Build parameter list for the function signature
    params = []
    for pname in param_names:
        pinfo = properties[pname]
        default = pinfo.get("default")
        if pname in required:
            params.append(f"{pname}: str")
        elif default is not None:
            params.append(f"{pname}: str = {default!r}")
        else:
            params.append(f"{pname}: str = None")

    # Create a function with explicit parameters via exec
    params_str = ", ".join(params) if params else ""
    args_dict = ", ".join(f"'{p}': {p}" for p in param_names) if param_names else ""
    func_code = f"""
def {tool_name}({params_str}) -> str:
    _args = {{{args_dict}}}
    # Strip None values (optional params not provided)
    _args = {{k: v for k, v in _args.items() if v is not None}}
    return _handler_impl(_args)
"""
    local_ns: dict[str, Any] = {"_handler_impl": handler_impl}
    exec(func_code, local_ns)  # noqa: S102 — controlled code generation
    fn = local_ns[tool_name]
    fn.__module__ = "keel.mcp.server"
    return fn


def _build_tool_annotations(tool_name: str) -> dict:
    """Determine MCP annotations (readOnly, destructive, etc.) for a tool."""
    # Write operations
    _DESTRUCTIVE = {"strategy_discard", "live_stop", "strategy_archive"}
    _WRITE_OPS = {
        "strategy_new", "strategy_create", "strategy_update", "strategy_push",
        "strategy_checkout", "strategy_pull", "strategy_compile",
        "strategy_lock_upgrade", "strategy_lock_upgrade_by_id",
        "update_strategy", "universe_set", "universe_add_group",
        "universe_modify_group", "universe_remove_group",
        "backtest_run", "live_deploy", "live_pause", "live_resume",
        "sharing_create_link", "sharing_fork",
    }

    if tool_name in _DESTRUCTIVE:
        return {"readOnlyHint": False, "destructiveHint": True}
    if tool_name in _WRITE_OPS:
        return {"readOnlyHint": False}
    return {"readOnlyHint": True, "idempotentHint": True}


def create_server() -> FastMCP:
    """Create and configure the MCP server with all tools registered directly."""
    mcp = FastMCP(
        name="keel",
        instructions=(
            "Keel is a quantitative crypto trading platform for Hyperliquid. "
            "Tools prefixed with strategy_components_ search and inspect 160+ pipeline components. "
            "strategy_validate, strategy_explain, and pipeline_stage work on strategy DSL source. "
            "universe_ tools manage which assets a strategy trades. "
            "backtest_ and live_ tools require authentication (keel auth login). "
            "Call keel_status to check auth state."
        ),
    )

    # ── Load bundled tool schemas (local tools) ──────────────────────────

    from keel.mcp.registry import _load_tool_schemas, _DOMAIN_MAP

    bundled_names = set()
    for schema in _load_tool_schemas():
        name = schema["name"]
        if name not in _DOMAIN_MAP:
            continue
        bundled_names.add(name)

        input_schema = schema.get("inputSchema", {})
        properties = input_schema.get("properties", {})
        required = input_schema.get("required", [])

        handler = _make_tool_handler(name, properties, required)
        annotations = _build_tool_annotations(name)

        mcp.tool(
            handler,
            name=name,
            description=schema.get("description", ""),
            annotations=annotations,
        )

    # ── Register remote tools ────────────────────────────────────────────

    for name, info in _REMOTE_TOOLS.items():
        if name in bundled_names:
            continue

        handler = _make_tool_handler(name, {}, [])
        annotations = _build_tool_annotations(name)

        mcp.tool(
            handler,
            name=name,
            description=info.get("description", ""),
            annotations=annotations,
        )

    # ── keel_status (always present) ─────────────────────────────────────

    @mcp.tool(annotations={"readOnlyHint": True, "idempotentHint": True})
    def keel_status() -> str:
        """Check authentication state and available capabilities.

        Returns: {authenticated, api_url, local_tools, remote_tools}.
        """
        from keel.config import load_config

        config = load_config()
        status: dict[str, Any] = {
            "authenticated": config.api_key is not None,
            "api_url": config.api_url,
            "local_tools": "Available (no auth needed): components, strategy validation, universe editing",
        }
        if config.api_key:
            try:
                from keel.auth import get_status

                remote = get_status()
                status.update(remote)
            except Exception as e:
                status["auth_error"] = str(e)
                status["remote_tools"] = "Auth configured but validation failed"
        else:
            status["remote_tools"] = "Requires KEEL_API_KEY: backtest, live, workspace sync, market-data"
            status["suggestion"] = "Set KEEL_API_KEY env var or run 'keel auth login'"
        return json.dumps(status, indent=2)

    # ── Resources ────────────────────────────────────────────────────────

    @mcp.resource("keel://components/catalog")
    def components_catalog() -> str:
        """Full component catalog — all 160+ components with parameters.
        Use when you need to browse the entire registry at once."""
        from keel.tools.local import strategy_components_dump

        return json.dumps(strategy_components_dump(), indent=2, default=str)

    @mcp.resource("keel://dsl/reference/{topic}")
    def dsl_reference_resource(topic: str) -> str:
        """DSL reference docs by topic (phases, types, slots, composition, normalization, best_practices)."""
        from keel.tools.local import dsl_reference

        return json.dumps(dsl_reference(topic=topic), indent=2)

    return mcp
