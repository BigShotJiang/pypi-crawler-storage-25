"""Structured errors with exit codes for agent-friendly error handling.

Exit codes:
    0 = success
    1 = general failure
    2 = usage error (bad args)
    3 = not found
    4 = authentication failed
    5 = conflict (already exists)
    6 = insufficient entitlements
    7 = validation failed
"""

from __future__ import annotations


class KeelError(Exception):
    """Base error with structured fields for agent consumption."""

    error_code: str = "error"
    exit_code: int = 1

    retryable: bool = False

    def __init__(
        self,
        message: str,
        *,
        error_code: str | None = None,
        exit_code: int | None = None,
        suggestion: str | None = None,
        docs_url: str | None = None,
        retryable: bool | None = None,
        input: dict | None = None,
    ) -> None:
        super().__init__(message)
        if error_code is not None:
            self.error_code = error_code
        if exit_code is not None:
            self.exit_code = exit_code
        if retryable is not None:
            self.retryable = retryable
        self.suggestion = suggestion
        self.docs_url = docs_url
        self.input = input

    def to_dict(self) -> dict:
        d: dict = {
            "error": self.error_code,
            "message": str(self),
            "exit_code": self.exit_code,
            "retryable": self.retryable,
        }
        if self.suggestion:
            d["suggestion"] = self.suggestion
        if self.docs_url:
            d["docs_url"] = self.docs_url
        if self.input:
            d["input"] = self.input
        return d


class NotFoundError(KeelError):
    error_code = "not_found"
    exit_code = 3


class AuthError(KeelError):
    error_code = "auth_failed"
    exit_code = 4


class ConflictError(KeelError):
    error_code = "conflict"
    exit_code = 5


class EntitlementError(KeelError):
    error_code = "insufficient_entitlements"
    exit_code = 6


class ValidationError(KeelError):
    error_code = "validation_failed"
    exit_code = 7


class UsageError(KeelError):
    error_code = "usage_error"
    exit_code = 2


def translate_http_error(status: int, body: str) -> KeelError:
    """Map HTTP status codes to KeelError subclasses."""
    if status == 401:
        return AuthError("Authentication required", suggestion="Run 'keel auth login'")
    if status == 403:
        return EntitlementError(
            "Insufficient permissions or entitlements",
            suggestion="Check 'keel auth status'",
        )
    if status == 404:
        return NotFoundError(body or "Resource not found")
    if status == 409:
        return ConflictError(
            body or "Conflict — resource changed",
            suggestion="Run 'keel strategy pull' to fetch latest, then retry",
        )
    if status == 422:
        return ValidationError(body or "Validation failed")
    if status == 429:
        return KeelError(
            "Rate limited — too many requests",
            error_code="rate_limited",
            exit_code=1,
            retryable=True,
            suggestion="Wait a few seconds and retry",
        )
    if status >= 500:
        return KeelError(
            f"Server error (HTTP {status})",
            error_code="server_error",
            exit_code=1,
            retryable=True,
            suggestion="Retry in a few seconds. If persistent, check https://status.usekeel.io",
        )
    return KeelError(f"HTTP {status}: {body}", exit_code=1)
