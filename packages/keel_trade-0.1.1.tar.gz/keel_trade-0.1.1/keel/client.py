"""Sync HTTP client for the Keel API.

Handles authentication, retries with exponential backoff, and error translation.
"""

from __future__ import annotations

import logging
import time
from typing import Any

import httpx

from keel.config import KeelConfig, load_config
from keel.errors import AuthError, KeelError, translate_http_error

logger = logging.getLogger(__name__)

_DEFAULT_TIMEOUT = httpx.Timeout(connect=5.0, read=30.0, write=5.0, pool=5.0)
_MAX_RETRIES = 3
_BACKOFF_BASE = 1.0  # 1s, 2s, 4s


class KeelClient:
    """Sync httpx wrapper with auth, retries, and error translation."""

    def __init__(self, config: KeelConfig | None = None) -> None:
        self._config = config or load_config()
        self._client = httpx.Client(
            base_url=self._config.api_url,
            timeout=_DEFAULT_TIMEOUT,
            headers=self._auth_headers(),
        )

    def _auth_headers(self) -> dict[str, str]:
        headers: dict[str, str] = {}
        if self._config.api_key:
            headers["Authorization"] = f"Bearer {self._config.api_key}"
        return headers

    def _require_auth(self) -> None:
        if not self._config.api_key:
            raise AuthError(
                "Not authenticated. Run 'keel auth login' or set KEEL_API_KEY.",
                suggestion="Run 'keel auth login'",
            )

    def get(self, path: str, **params: Any) -> Any:
        """GET request with retries and error handling."""
        self._require_auth()
        return self._request("GET", path, params=params or None)

    def post(self, path: str, json: dict | None = None, **params: Any) -> Any:
        """POST request with retries and error handling."""
        self._require_auth()
        return self._request("POST", path, json=json, params=params or None)

    def patch(self, path: str, json: dict | None = None) -> Any:
        """PATCH request with retries and error handling."""
        self._require_auth()
        return self._request("PATCH", path, json=json)

    def delete(self, path: str) -> Any:
        """DELETE request with retries and error handling."""
        self._require_auth()
        return self._request("DELETE", path)

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        """Execute request with retry logic."""
        last_error: Exception | None = None
        for attempt in range(_MAX_RETRIES):
            try:
                response = self._client.request(method, path, **kwargs)
                # Log rate limit info at verbose level
                remaining = response.headers.get("X-RateLimit-Remaining")
                if remaining is not None:
                    logger.debug("Rate limit remaining: %s", remaining)
                if response.status_code == 429:
                    # Rate limited — retry after backoff
                    retry_after = float(response.headers.get("Retry-After", _BACKOFF_BASE * (2**attempt)))
                    logger.warning("Rate limited, retrying after %.1fs", retry_after)
                    time.sleep(retry_after)
                    continue
                if response.status_code >= 500 and attempt < _MAX_RETRIES - 1:
                    # Server error — retry with backoff
                    delay = _BACKOFF_BASE * (2**attempt)
                    logger.warning("Server error %d, retrying in %.1fs", response.status_code, delay)
                    time.sleep(delay)
                    continue
                if response.status_code >= 400:
                    raise translate_http_error(response.status_code, response.text)
                return response.json()
            except KeelError:
                raise
            except httpx.TimeoutException as e:
                last_error = e
                if attempt < _MAX_RETRIES - 1:
                    delay = _BACKOFF_BASE * (2**attempt)
                    logger.warning("Request timeout, retrying in %.1fs", delay)
                    time.sleep(delay)
                    continue
            except httpx.HTTPError as e:
                last_error = e
                if attempt < _MAX_RETRIES - 1:
                    delay = _BACKOFF_BASE * (2**attempt)
                    logger.warning("HTTP error: %s, retrying in %.1fs", e, delay)
                    time.sleep(delay)
                    continue
        raise KeelError(f"Request failed after {_MAX_RETRIES} attempts: {last_error}")

    def close(self) -> None:
        """Close the underlying httpx client."""
        self._client.close()

    def __enter__(self) -> KeelClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
