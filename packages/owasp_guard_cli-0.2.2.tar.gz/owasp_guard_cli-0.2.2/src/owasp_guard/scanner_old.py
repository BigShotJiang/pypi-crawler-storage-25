import ast
import json
import os
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable

from pydantic import TypeAdapter

from .models import (
    CodeChunk,
    Finding,
    FindingsResponse,
    ScanReport,
    VerificationResponse,
)
from .prompts import (
    ANALYZER_SYSTEM_PROMPT,
    VERIFIER_SYSTEM_PROMPT,
    build_analysis_prompt,
    build_verification_prompt,
)
from .errors import ApiError, InputError, ScanError


SUPPORTED_EXTENSIONS = {
    # Web / JS ecosystem
    ".js",
    ".jsx",
    ".mjs",
    ".cjs",
    ".ts",
    ".tsx",
    ".vue",
    ".svelte",
    ".astro",
    # Python
    ".py",
    ".pyw",
    ".pyi",
    # JVM
    ".java",
    ".kt",
    ".kts",
    ".scala",
    ".groovy",
    # .NET
    ".cs",
    ".vb",
    ".fs",
    # Systems / native
    ".c",
    ".h",
    ".cpp",
    ".cc",
    ".cxx",
    ".hpp",
    ".hh",
    ".rs",
    ".zig",
    # Mobile / Apple
    ".swift",
    ".m",
    ".mm",
    # Backend / scripting
    ".go",
    ".rb",
    ".php",
    ".pl",
    ".pm",
    ".lua",
    ".r",
    ".sh",
    ".bash",
    ".zsh",
    ".ps1",
    # Data / query / config that can still contain security-relevant logic
    ".sql",
    ".graphql",
    ".gql",
    ".yaml",
    ".yml",
    ".json",
    ".toml",
    ".ini",
    ".xml",
    # Infra / IaC
    ".tf",
    ".hcl",
    ".dockerfile",
}

SKIP_DIRS = {
    ".git",
    ".github",
    "node_modules",
    "dist",
    "build",
    "__pycache__",
    ".venv",
    "venv",
    ".next",
    ".nuxt",
    ".scannerwork",
    "coverage",
    "target",
    "bin",
    "obj",
}

SKIP_FILENAMES = {
    "package-lock.json",
    "yarn.lock",
    "pnpm-lock.yaml",
    "poetry.lock",
    "Cargo.lock",
}

ProgressCallback = Callable[[str, str, dict[str, Any]], None]
DEFAULT_MAX_CHUNK_LINES = 150
DEFAULT_MIN_CHUNK_LINES = 30
DEFAULT_MAX_CHUNKS_PER_FILE = 15
DEFAULT_ANALYZE_WORKERS = 8

# Cache for chunks
_chunk_cache = {}
_MAX_CACHE_SIZE = 100


def _emit_progress(
    callback: ProgressCallback | None, stage: str, message: str, **data: Any
) -> None:
    if callback is None:
        return
    callback(stage, message, data)


def collect_source_files(target_path: str, max_files: int | None = None) -> list[str]:
    if max_files is not None and max_files <= 0:
        raise InputError("--max-files must be greater than 0.")
    p = Path(target_path)
    if not p.exists():
        raise InputError(f"Path not found: {target_path}")
    if p.is_file():
        ext = p.suffix.lower()
        if ext not in SUPPORTED_EXTENSIONS and p.name.lower() not in {"dockerfile"}:
            raise InputError(f"Unsupported file extension: {ext or '(none)'}")
        return [str(p.resolve())]

    files: list[str] = []
    for root, dirs, names in os.walk(p):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for name in names:
            if name in SKIP_FILENAMES:
                continue
            ext = Path(name).suffix.lower()
            if ext in SUPPORTED_EXTENSIONS or name.lower() == "dockerfile":
                files.append(str((Path(root) / name).resolve()))
                if max_files and len(files) >= max_files:
                    return sorted(files)
    return sorted(files)


def _extract_shared_context(lines: list[str]) -> str:
    """Extract imports and important declarations for context."""
    context_lines: list[str] = []
    important_patterns = [
        "import ",
        "from ",
        "require(",
        "export ",
        "const ",
        "let ",
        "var ",
        "app.",
        "router.",
        "server.",
        "use(",
        "middleware",
        "process.env",
        "database",
        "db.",
        "config",
    ]

    for line in lines[:200]:  # Check first 200 lines
        s = line.strip()
        for pattern in important_patterns:
            if pattern in s:
                context_lines.append(line.rstrip())
                break

    return "\n".join(context_lines[:50]).strip()


def _function_block_starts_enhanced(file_path: str, lines: list[str]) -> list[int]:
    """Enhanced function detection that also finds route handlers."""
    ext = Path(file_path).suffix.lower()
    starts: list[int] = []

    if ext == ".py":
        for i, line in enumerate(lines, start=1):
            if re.match(r"^\s*(def|class)\s+\w+", line):
                starts.append(i)
    else:
        # CRITICAL: Look for Express/Fastify route handlers
        route_patterns = [
            r"app\.(get|post|put|delete|patch|all)\s*\(",  # app.get(), app.post()
            r"router\.(get|post|put|delete|patch|all)\s*\(",  # router.get()
            r"route\.(get|post|put|delete|patch|all)\s*\(",  # route.get()
            r"server\.(get|post|put|delete|patch|all)\s*\(",  # server.get()
            r"\.addRoute\s*\(",  # Fastify
            r"\.route\s*\(",  # Express route chaining
        ]

        # Function patterns
        func_patterns = [
            r"^\s*(export\s+)?(async\s+)?function\s+\w+\s*\(",
            r"^\s*(export\s+)?(const|let|var)\s+\w+\s*=\s*(async\s*)?\([^)]*\)\s*=>",
            r"^\s*(export\s+)?class\s+\w+",
        ]

        for i, line in enumerate(lines, start=1):
            # Check for route handlers (highest priority)
            for pattern in route_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    starts.append(i)
                    break

            # Check for functions (if not already found)
            if not starts or starts[-1] != i:
                for pattern in func_patterns:
                    if re.search(pattern, line):
                        starts.append(i)
                        break

    # Sort and remove duplicates
    starts = sorted(set(starts))

    # If no starts found, create chunks at regular intervals
    if not starts and len(lines) > 100:
        print(
            f"[DEBUG] No function/route boundaries found in {file_path}, using sliding windows"
        )
        for i in range(1, len(lines) + 1, 100):
            starts.append(i)

    return starts


def _chunk_route_file(
    file_path: str, lines: list[str], context: str
) -> list[CodeChunk]:
    """Specialized chunking for Express/Fastify route files."""
    chunks = []

    # Find all route handlers
    route_starts = []
    for i, line in enumerate(lines, 1):
        if re.search(r"app\.(get|post|put|delete|patch|all)\s*\(", line, re.IGNORECASE):
            route_starts.append(i)
        elif re.search(
            r"router\.(get|post|put|delete|patch|all)\s*\(", line, re.IGNORECASE
        ):
            route_starts.append(i)

    # If we found routes, chunk them with context
    if route_starts:
        for i, start in enumerate(route_starts[:DEFAULT_MAX_CHUNKS_PER_FILE]):
            # End at next route or 50 lines later
            if i + 1 < len(route_starts):
                end = route_starts[i + 1] - 1
            else:
                end = min(start + 50, len(lines))

            # Include some lines before for middleware/context
            chunk_start = max(1, start - 5)

            code = "\n".join(lines[chunk_start - 1 : end]).strip()
            if code:
                chunks.append(
                    CodeChunk(
                        file=file_path,
                        line_start=chunk_start,
                        line_end=end,
                        context=context,
                        code=code,
                    )
                )
    else:
        # No routes found? Use sliding windows
        window_size = 100
        overlap = 20

        for i in range(0, len(lines), window_size - overlap):
            if len(chunks) >= DEFAULT_MAX_CHUNKS_PER_FILE:
                break
            start = i + 1
            end = min(i + window_size, len(lines))
            code = "\n".join(lines[i:end]).strip()
            if code:
                chunks.append(
                    CodeChunk(
                        file=file_path,
                        line_start=start,
                        line_end=end,
                        context=context,
                        code=code,
                    )
                )

    return chunks


def _chunk_general_file(
    file_path: str, lines: list[str], context: str
) -> list[CodeChunk]:
    """General chunking for non-route files."""
    starts = _function_block_starts_enhanced(file_path, lines)

    if not starts:
        # No functions found, use sliding windows
        window_size = 100
        overlap = 20
        chunks = []

        for i in range(0, len(lines), window_size - overlap):
            if len(chunks) >= DEFAULT_MAX_CHUNKS_PER_FILE:
                break
            start = i + 1
            end = min(i + window_size, len(lines))
            code = "\n".join(lines[i:end]).strip()
            if code:
                chunks.append(
                    CodeChunk(
                        file=file_path,
                        line_start=start,
                        line_end=end,
                        context=context,
                        code=code,
                    )
                )
        return chunks

    # Use function boundaries for chunking
    chunks = []
    for idx, start in enumerate(starts[:DEFAULT_MAX_CHUNKS_PER_FILE]):
        end = starts[idx + 1] - 1 if idx + 1 < len(starts) else len(lines)

        # If chunk is too large, split it
        if end - start + 1 > DEFAULT_MAX_CHUNK_LINES * 1.5:
            # Split into smaller chunks
            for sub_start in range(start, end + 1, DEFAULT_MAX_CHUNK_LINES):
                sub_end = min(sub_start + DEFAULT_MAX_CHUNK_LINES - 1, end)
                code = "\n".join(lines[sub_start - 1 : sub_end]).strip()
                if code:
                    chunks.append(
                        CodeChunk(
                            file=file_path,
                            line_start=sub_start,
                            line_end=sub_end,
                            context=context,
                            code=code,
                        )
                    )
        else:
            code = "\n".join(lines[start - 1 : end]).strip()
            if code:
                chunks.append(
                    CodeChunk(
                        file=file_path,
                        line_start=start,
                        line_end=end,
                        context=context,
                        code=code,
                    )
                )

    return chunks


def _prioritize_chunks(chunks: list[CodeChunk], max_chunks: int) -> list[CodeChunk]:
    """Keep the most important chunks when we have too many."""
    if len(chunks) <= max_chunks:
        return chunks

    # Score each chunk by "interestingness"
    scored_chunks = []
    for chunk in chunks:
        score = 0
        code_lower = chunk.code.lower()

        # Higher score for chunks with security-relevant patterns
        security_patterns = [
            ("sql", 10),
            ("query", 8),
            ("execute", 8),
            ("password", 10),
            ("secret", 10),
            ("key", 8),
            ("token", 8),
            ("eval(", 10),
            ("function(", 5),
            ("req.", 8),
            ("request.", 8),
            ("res.", 5),
            ("response.", 5),
            ("app.", 7),
            ("router.", 7),
            ("process.env", 6),
            ("env", 4),
            ("<script", 10),
            ("innerhtml", 8),
            ("document.write", 8),
            ("auth", 6),
            ("login", 6),
            ("register", 5),
            ("file", 5),
            ("fs.", 6),
            ("readfile", 6),
            ("http://", 3),
            ("https://", 3),
            ("cors", 5),
            ("origin", 5),
        ]

        for pattern, points in security_patterns:
            if pattern in code_lower:
                score += points

        # Penalize very short chunks
        if len(chunk.code) < 50:
            score -= 5

        # Boost chunks with more lines of actual code
        non_empty_lines = sum(1 for line in chunk.code.split("\n") if line.strip())
        score += min(10, non_empty_lines / 5)

        scored_chunks.append((score, chunk))

    # Sort by score and take top chunks
    scored_chunks.sort(reverse=True, key=lambda x: x[0])
    return [chunk for score, chunk in scored_chunks[:max_chunks]]


def chunk_file(file_path: str) -> list[CodeChunk]:
    """Optimized chunking with caching and smart boundaries."""

    # Check cache first (file modification time)
    try:
        mtime = os.path.getmtime(file_path)
        cache_key = f"{file_path}:{mtime}"
        if cache_key in _chunk_cache:
            print(f"[DEBUG] Using cached chunks for {file_path}")
            return _chunk_cache[cache_key]
    except OSError:
        pass

    # Read file
    try:
        text = Path(file_path).read_text(encoding="utf-8", errors="ignore")
    except OSError as exc:
        raise ScanError(f"Unable to read source file: {file_path} ({exc})") from exc

    lines = text.splitlines()
    if not lines:
        return []

    # Get settings from environment
    max_chunks = int(
        os.getenv("OWASP_GUARD_MAX_CHUNKS_PER_FILE", str(DEFAULT_MAX_CHUNKS_PER_FILE))
    )

    # Extract context
    context = _extract_shared_context(lines)

    # Determine file type
    text_lower = text.lower()
    is_route_file = (
        "app." in text_lower or "router." in text_lower or "route." in text_lower
    )
    is_config_file = "config" in file_path.lower() or ".env" in file_path.lower()

    # Different strategies based on file type
    if is_route_file and len(lines) > 100:
        # For route files like server.ts: use special handling
        chunks = _chunk_route_file(file_path, lines, context)
    elif is_config_file:
        # For config files: one chunk is usually enough
        chunks = [
            CodeChunk(
                file=file_path,
                line_start=1,
                line_end=len(lines),
                context=context,
                code=text,
            )
        ]
    else:
        # For other files: use general chunking
        chunks = _chunk_general_file(file_path, lines, context)

    # Apply chunk merging
    max_chunk_lines = int(
        os.getenv("OWASP_GUARD_MAX_CHUNK_LINES", str(DEFAULT_MAX_CHUNK_LINES))
    )
    min_chunk_lines = int(
        os.getenv("OWASP_GUARD_MIN_CHUNK_LINES", str(DEFAULT_MIN_CHUNK_LINES))
    )
    chunks = _merge_chunks(
        chunks, max_chunk_lines=max_chunk_lines, min_chunk_lines=min_chunk_lines
    )

    # Prioritize chunks if we have too many
    if len(chunks) > max_chunks:
        print(f"[DEBUG] Limiting {file_path} from {len(chunks)} to {max_chunks} chunks")
        chunks = _prioritize_chunks(chunks, max_chunks)

    # Cache the result
    try:
        mtime = os.path.getmtime(file_path)
        cache_key = f"{file_path}:{mtime}"
        _chunk_cache[cache_key] = chunks

        # Limit cache size
        if len(_chunk_cache) > _MAX_CACHE_SIZE:
            # Remove oldest 50 items
            oldest = sorted(_chunk_cache.keys())[:50]
            for key in oldest:
                del _chunk_cache[key]
    except OSError:
        pass

    print(f"[DEBUG] {file_path}: created {len(chunks)} chunks")
    return chunks


def _merge_chunks(
    chunks: list[CodeChunk],
    max_chunk_lines: int,
    min_chunk_lines: int,
) -> list[CodeChunk]:
    if len(chunks) <= 1:
        return chunks

    merged: list[CodeChunk] = []
    active = chunks[0]
    for nxt in chunks[1:]:
        active_lines = active.line_end - active.line_start + 1
        next_lines = nxt.line_end - nxt.line_start + 1
        combined = active_lines + next_lines
        should_merge = (
            active.file == nxt.file
            and active.line_end + 1 >= nxt.line_start
            and (
                combined <= max_chunk_lines
                or active_lines < min_chunk_lines
                or next_lines < min_chunk_lines
            )
        )
        if should_merge:
            active = CodeChunk(
                file=active.file,
                line_start=active.line_start,
                line_end=nxt.line_end,
                context=active.context,
                code=f"{active.code}\n{nxt.code}".strip(),
            )
        else:
            merged.append(active)
            active = nxt
    merged.append(active)
    return merged


def _new_structured_llm(model_name: str, api_key: str, temperature: float, schema):
    from langchain_groq import ChatGroq

    try:
        llm = ChatGroq(model=model_name, api_key=api_key, temperature=temperature)
    except Exception as exc:
        raise ApiError(f"Failed to initialize model '{model_name}': {exc}") from exc
    return llm.with_structured_output(schema)


def _parse_failed_generation(exception: Exception, schema_cls):
    """
    Recover model output from Groq tool_use_failed errors where the provider
    includes a serialized fallback payload under error.failed_generation.
    """
    msg = str(exception)
    marker = "Error code:"
    if marker not in msg:
        return None
    payload_start = msg.find("{")
    if payload_start < 0:
        return None

    raw_payload = msg[payload_start:]
    try:
        parsed = ast.literal_eval(raw_payload)
    except Exception:
        return None
    if not isinstance(parsed, dict):
        return None
    err = parsed.get("error")
    if not isinstance(err, dict):
        return None
    failed_generation = err.get("failed_generation")
    if not isinstance(failed_generation, str):
        return None

    cleaned = failed_generation.strip()
    # Typical provider envelope: <function=SchemaName> { ...json... } </function>
    json_start = cleaned.find("{")
    if json_start < 0:
        return None
    cleaned = cleaned[json_start:]

    try:
        as_dict, _ = json.JSONDecoder().raw_decode(cleaned)
        return schema_cls.model_validate(as_dict)
    except Exception:
        return None


def _extract_json_payload(text: str) -> Any | None:
    candidate = text.strip()
    if candidate.startswith("```"):
        lines = candidate.splitlines()
        if len(lines) >= 3 and lines[-1].strip().startswith("```"):
            candidate = "\n".join(lines[1:-1]).strip()
    json_start = candidate.find("{")
    if json_start < 0:
        return None
    candidate = candidate[json_start:]
    try:
        obj, _ = json.JSONDecoder().raw_decode(candidate)
        return obj
    except Exception:
        return None


def _retry_unstructured_json(
    model_name: str,
    api_key: str,
    system_prompt: str,
    user_prompt: str,
    schema_cls,
):
    from langchain_groq import ChatGroq

    guidance = (
        "Your previous response format failed. "
        "Return only a single valid JSON object matching the required schema. "
        "Do not call any tools and do not include markdown."
    )
    try:
        llm = ChatGroq(model=model_name, api_key=api_key, temperature=0.0)
        raw_response = llm.invoke(
            [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
                {"role": "user", "content": guidance},
            ]
        )
    except Exception:
        return None

    content = raw_response.content
    if isinstance(content, list):
        text = "".join(
            part.get("text", "") for part in content if isinstance(part, dict)
        )
    else:
        text = str(content)
    payload = _extract_json_payload(text)
    if payload is None:
        return None
    try:
        return schema_cls.model_validate(payload)
    except Exception:
        return None


def _scan_chunks(
    chunks: list[CodeChunk],
    model_name: str,
    api_key: str,
    progress_callback: ProgressCallback | None = None,
) -> list[Finding]:
    findings: list[Finding] = []
    total_chunks = len(chunks)
    if total_chunks == 0:
        _emit_progress(
            progress_callback, "analyze_done", "Chunk analysis completed", findings=0
        )
        return findings

    workers = int(
        os.getenv("OWASP_GUARD_ANALYZE_WORKERS", str(DEFAULT_ANALYZE_WORKERS))
    )
    workers = max(1, min(workers, total_chunks))

    def analyze_one(index: int, chunk: CodeChunk) -> list[Finding]:
        analyzer = _new_structured_llm(model_name, api_key, 0.0, FindingsResponse)
        _emit_progress(
            progress_callback,
            "analyze_chunk",
            "Analyzing chunk",
            index=index,
            total=total_chunks,
            file=chunk.file,
            line_start=chunk.line_start,
            line_end=chunk.line_end,
        )
        prompt = build_analysis_prompt(
            chunk_file=chunk.file,
            line_start=chunk.line_start,
            line_end=chunk.line_end,
            context=chunk.context or "(none)",
            code=chunk.code,
        )

        # Add instructions to be more thorough
        enhanced_prompt = (
            prompt
            + "\n\nIMPORTANT: Identify ALL vulnerabilities in this code chunk, including but not limited to: SQL injection, command injection, hardcoded secrets, weak crypto, broken access control, insecure deserialization, SSRF, and information exposure."
        )

        try:
            response = analyzer.invoke(
                [
                    {
                        "role": "system",
                        "content": ANALYZER_SYSTEM_PROMPT
                        + "\nBe thorough and identify ALL security issues, even if they seem obvious.",
                    },
                    {"role": "user", "content": enhanced_prompt},
                ]
            )
        except Exception as exc:
            recovered = _parse_failed_generation(exc, FindingsResponse)
            if recovered is None:
                recovered = _retry_unstructured_json(
                    model_name=model_name,
                    api_key=api_key,
                    system_prompt=ANALYZER_SYSTEM_PROMPT,
                    user_prompt=prompt,
                    schema_cls=FindingsResponse,
                )
            if recovered is None:
                raise ApiError(
                    f"Analyzer failed for {chunk.file}:{chunk.line_start}-{chunk.line_end}: {exc}"
                ) from exc
            response = recovered
        local_findings: list[Finding] = []
        for finding in response.findings:
            finding.file = chunk.file
            finding.line_start = chunk.line_start
            finding.line_end = chunk.line_end
            local_findings.append(finding)
        return local_findings

    if workers == 1 or total_chunks == 1:
        for index, chunk in enumerate(chunks, start=1):
            findings.extend(analyze_one(index, chunk))
    else:
        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {
                executor.submit(analyze_one, index, chunk): (index, chunk)
                for index, chunk in enumerate(chunks, start=1)
            }
            for future in as_completed(futures):
                try:
                    findings.extend(future.result())
                except Exception as exc:
                    print(f"[ERROR] Chunk analysis failed: {exc}")
                    continue
    _emit_progress(
        progress_callback,
        "analyze_done",
        "Chunk analysis completed",
        findings=len(findings),
    )
    return findings


def _verify_findings(
    findings: list[Finding],
    model_name: str,
    api_key: str,
    progress_callback: ProgressCallback | None = None,
) -> list[Finding]:
    if not findings:
        _emit_progress(
            progress_callback, "verify_done", "No findings to verify", kept=0, total=0
        )
        return []

    _emit_progress(
        progress_callback,
        "verify_start",
        "Running verification pass",
        total=len(findings),
    )
    verifier = _new_structured_llm(model_name, api_key, 0.0, VerificationResponse)
    raw = [f.model_dump() for f in findings]
    prompt = build_verification_prompt(json.dumps(raw, indent=2))
    try:
        response = verifier.invoke(
            [
                {"role": "system", "content": VERIFIER_SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ]
        )
    except Exception as exc:
        recovered = _parse_failed_generation(exc, VerificationResponse)
        if recovered is None:
            recovered = _retry_unstructured_json(
                model_name=model_name,
                api_key=api_key,
                system_prompt=VERIFIER_SYSTEM_PROMPT,
                user_prompt=prompt,
                schema_cls=VerificationResponse,
            )
        if recovered is None:
            raise ApiError(f"Verifier pass failed: {exc}") from exc
        response = recovered

    decision_map = {d.index: d for d in response.decisions}
    kept: list[Finding] = []
    for idx, finding in enumerate(findings):
        decision = decision_map.get(idx)
        if decision is None or not decision.keep:
            continue
        finding.owasp_category = decision.normalized_owasp_category
        finding.title = decision.normalized_title
        finding.confidence = decision.adjusted_confidence
        kept.append(finding)
    _emit_progress(
        progress_callback,
        "verify_done",
        "Verification completed",
        kept=len(kept),
        total=len(findings),
    )
    return kept


def _dedup_findings(findings: list[Finding]) -> list[Finding]:
    best: dict[tuple[str, str, str], Finding] = {}  # Changed key structure
    for f in findings:
        # Use a more lenient key that doesn't include line_end and evidence
        key = (
            f.file,
            f.owasp_category,
            f.title.split()[
                0
            ],  # Group by first word of title (e.g., "SQL", "OS", "Hardcoded")
        )
        if key not in best or f.confidence > best[key].confidence:
            best[key] = f
        # Also try to keep distinct vulnerability types in the same file
        elif f.file == best[key].file and f.title != best[key].title:
            # If it's a different type of vulnerability, keep both by using a more specific key
            specific_key = (
                f.file,
                f.owasp_category,
                f.title,  # Use full title for distinct vulnerabilities
            )
            if specific_key not in best:
                best[specific_key] = f

    # Sort by file and line number
    return sorted(best.values(), key=lambda x: (x.file, x.line_start))


def run_scan(
    target_path: str,
    model_name: str,
    api_key: str,
    max_files: int | None = None,
    progress_callback: ProgressCallback | None = None,
) -> ScanReport:
    _emit_progress(
        progress_callback,
        "collect_start",
        "Collecting files",
        target_path=target_path,
        max_files=max_files,
    )
    source_files = collect_source_files(target_path, max_files=max_files)
    if not source_files:
        raise InputError("No supported source files found in the provided path.")
    _emit_progress(
        progress_callback,
        "collect_done",
        "Files collected",
        total_files=len(source_files),
    )

    all_chunks: list[CodeChunk] = []
    for index, file_path in enumerate(source_files, start=1):
        try:
            chunks = chunk_file(file_path)
            all_chunks.extend(chunks)
            _emit_progress(
                progress_callback,
                "chunk_file",
                "Chunked file",
                index=index,
                total=len(source_files),
                file=file_path,
                chunks=len(chunks),
            )
        except Exception as exc:
            print(f"[WARN] Failed to chunk {file_path}: {exc}")
            continue

    _emit_progress(
        progress_callback,
        "chunk_done",
        "Code chunking completed",
        total_chunks=len(all_chunks),
    )

    raw_findings = _scan_chunks(
        all_chunks,
        model_name=model_name,
        api_key=api_key,
        progress_callback=progress_callback,
    )

    verified = _verify_findings(
        raw_findings,
        model_name=model_name,
        api_key=api_key,
        progress_callback=progress_callback,
    )

    final_findings = _dedup_findings(verified)
    _emit_progress(
        progress_callback,
        "dedup_done",
        "Deduplication completed",
        before=len(verified),
        after=len(final_findings),
    )

    return ScanReport(
        scanned_path=str(Path(target_path).resolve()),
        total_files=len(source_files),
        total_chunks=len(all_chunks),
        total_findings=len(final_findings),
        findings=final_findings,
    )


def findings_from_json(text: str) -> list[Finding]:
    adapter = TypeAdapter(list[Finding])
    return adapter.validate_json(text)
