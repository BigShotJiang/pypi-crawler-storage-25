"""Main OWASP Guard security code scanner."""

import json
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable

from pydantic import TypeAdapter

from .chunking import chunk_file
from .errors import ApiError
from .file_collector import collect_source_files
from .llm_utils import (
    create_structured_llm,
    parse_failed_generation,
    retry_unstructured_json,
)
from .models import (
    CodeChunk,
    Finding,
    FindingsResponse,
    ScanReport,
    VerificationResponse,
)
from .prompts import (
    ANALYZER_SYSTEM_PROMPT,
    VERIFIER_SYSTEM_PROMPT,
    build_analysis_prompt,
    build_verification_prompt,
)

ProgressCallback = Callable[[str, str, dict[str, Any]], None]


def _relative_path(path: str, base: Path | None = None) -> str:
    """Render a path relative to the working directory when possible."""
    path_obj = Path(path)
    root = base or Path.cwd()

    try:
        return str(path_obj.resolve().relative_to(root.resolve()))
    except ValueError:
        return str(path_obj.resolve())


def _make_finding(
    *,
    file: str,
    line_start: int,
    line_end: int,
    owasp_category: str,
    title: str,
    risk_summary: str,
    fix_recommendation: str,
    evidence: str,
    confidence: float,
) -> Finding:
    return Finding(
        file=file,
        line_start=line_start,
        line_end=line_end,
        owasp_category=owasp_category,
        title=title,
        risk_summary=risk_summary,
        fix_recommendation=fix_recommendation,
        evidence=evidence,
        confidence=confidence,
    )


def _heuristic_findings_for_chunk(chunk: CodeChunk) -> list[Finding]:
    """
    Add deterministic findings for explicit high-signal patterns.

    This complements the LLM pass so obvious issues do not disappear when the
    model under-reports or a verification pass over-filters.
    """
    findings: list[Finding] = []
    lines = chunk.code.splitlines()
    lower_lines = [line.lower() for line in lines]

    user_controlled_vars: set[str] = set()
    for idx, line in enumerate(lines, start=chunk.line_start):
        if "request." not in line and "input(" not in line:
            continue
        assign_match = re.match(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=", line)
        if assign_match:
            user_controlled_vars.add(assign_match.group(1))

    for offset, line in enumerate(lines):
        line_no = chunk.line_start + offset
        lowered = lower_lines[offset]

        if (
            "secret" in lowered
            and "=" in line
            and re.search(r'["\'][^"\']{4,}["\']', line)
            and "os.getenv" not in lowered
            and "environ" not in lowered
        ):
            findings.append(
                _make_finding(
                    file=chunk.file,
                    line_start=line_no,
                    line_end=line_no,
                    owasp_category="A02:2021 Cryptographic Failures",
                    title="Hardcoded secret in source code",
                    risk_summary=(
                        "Secret material is embedded directly in source, which increases "
                        "leakage risk and weakens environment separation."
                    ),
                    fix_recommendation=(
                        "Load secrets from environment variables or a secrets manager "
                        "and rotate the exposed value."
                    ),
                    evidence=line.strip(),
                    confidence=0.98,
                )
            )

        if "hashlib.md5" in lowered:
            findings.append(
                _make_finding(
                    file=chunk.file,
                    line_start=line_no,
                    line_end=line_no,
                    owasp_category="A02:2021 Cryptographic Failures",
                    title="Weak cryptographic hash function",
                    risk_summary=(
                        "MD5 is unsuitable for password or security-sensitive hashing "
                        "because it is fast and cryptographically broken."
                    ),
                    fix_recommendation=(
                        "Use Argon2, bcrypt, or PBKDF2 for password hashing instead of MD5."
                    ),
                    evidence=line.strip(),
                    confidence=0.98,
                )
            )

        if (
            ("select " in lowered or "insert " in lowered or "update " in lowered)
            and ("f\"" in line or "f'" in line or "{" in line or " + " in line)
            and "request." not in lowered
        ):
            findings.append(
                _make_finding(
                    file=chunk.file,
                    line_start=line_no,
                    line_end=line_no,
                    owasp_category="A03:2021 Injection",
                    title="SQL injection through string-built query",
                    risk_summary=(
                        "Untrusted input is concatenated into SQL text, allowing query "
                        "manipulation and unauthorized data access."
                    ),
                    fix_recommendation=(
                        "Use parameterized statements and bind user input instead of "
                        "building SQL strings."
                    ),
                    evidence=line.strip(),
                    confidence=0.97,
                )
            )

        command_sink = "os.popen(" in lowered or "subprocess." in lowered
        command_uses_request = "request." in lowered
        command_uses_user_var = any(
            re.search(rf"\b{re.escape(var)}\b", line) for var in user_controlled_vars
        )
        if command_sink and (command_uses_request or command_uses_user_var):
            findings.append(
                _make_finding(
                    file=chunk.file,
                    line_start=line_no,
                    line_end=line_no,
                    owasp_category="A03:2021 Injection",
                    title="Command injection through shell-executed command",
                    risk_summary=(
                        "User-controlled input reaches a shell execution sink, enabling "
                        "arbitrary command execution on the host."
                    ),
                    fix_recommendation=(
                        "Avoid shell execution for user input. Use allowlisted commands "
                        "or structured process APIs without shell interpretation."
                    ),
                    evidence=line.strip(),
                    confidence=0.98,
                )
            )

    return findings


def _augment_with_heuristics(
    chunks: list[CodeChunk],
    findings: list[Finding],
    progress_callback: ProgressCallback | None = None,
) -> list[Finding]:
    """Merge deterministic findings with model findings."""
    augmented = list(findings)
    heuristic_count = 0

    for chunk in chunks:
        chunk_findings = _heuristic_findings_for_chunk(chunk)
        heuristic_count += len(chunk_findings)
        augmented.extend(chunk_findings)

    _emit_progress(
        progress_callback,
        "heuristic_done",
        "Deterministic checks completed",
        findings=heuristic_count,
        total=len(augmented),
    )
    return augmented


def _emit_progress(
    callback: ProgressCallback | None, stage: str, message: str, **data: Any
) -> None:
    """Emit progress callback if callback is registered."""
    if callback is None:
        return
    callback(stage, message, data)


def _scan_chunks(
    chunks: list[CodeChunk],
    model_name: str,
    api_key: str,
    progress_callback: ProgressCallback | None = None,
) -> list[Finding]:
    """
    Analyze code chunks for security vulnerabilities.

    Args:
        chunks: List of code chunks to analyze
        model_name: Name of the LLM model to use
        api_key: API key for the LLM
        progress_callback: Optional callback for progress updates

    Returns:
        List of findings discovered

    Raises:
        ApiError: If analysis fails
    """
    findings: list[Finding] = []
    total_chunks = len(chunks)

    if total_chunks == 0:
        _emit_progress(
            progress_callback, "analyze_done", "Chunk analysis completed", findings=0
        )
        return findings

    workers = 1  # Process chunks sequentially to avoid rate limiting

    def analyze_one(index: int, chunk: CodeChunk) -> list[Finding]:
        """Analyze a single code chunk."""
        analyzer = create_structured_llm(model_name, api_key, 0.0, FindingsResponse)

        _emit_progress(
            progress_callback,
            "analyze_chunk",
            "Analyzing chunk",
            index=index,
            total=total_chunks,
            file=chunk.file,
            line_start=chunk.line_start,
            line_end=chunk.line_end,
        )

        prompt = build_analysis_prompt(
            chunk_file=chunk.file,
            line_start=chunk.line_start,
            line_end=chunk.line_end,
            context=chunk.context or "(none)",
            code=chunk.code,
        )

        # Add instructions to be thorough
        enhanced_prompt = (
            prompt
            + "\n\nIMPORTANT: Identify ALL vulnerabilities in this code chunk, "
            + "including but not limited to: SQL injection, command injection, "
            + "hardcoded secrets, weak crypto, broken access control, "
            + "insecure deserialization, SSRF, and information exposure."
        )

        try:
            response = analyzer.invoke(
                [
                    {
                        "role": "system",
                        "content": ANALYZER_SYSTEM_PROMPT
                        + "\nBe thorough and identify ALL security issues, even if they seem obvious.",
                    },
                    {"role": "user", "content": enhanced_prompt},
                ]
            )
        except Exception as exc:
            recovered = parse_failed_generation(exc, FindingsResponse)
            if recovered is None:
                recovered = retry_unstructured_json(
                    model_name=model_name,
                    api_key=api_key,
                    system_prompt=ANALYZER_SYSTEM_PROMPT,
                    user_prompt=prompt,
                    schema_cls=FindingsResponse,
                )
            if recovered is None:
                raise ApiError(
                    f"Analyzer failed for {chunk.file}:{chunk.line_start}-{chunk.line_end}: {exc}"
                ) from exc
            response = recovered

        local_findings: list[Finding] = []
        for finding in response.findings:
            finding.file = chunk.file
            finding.line_start = chunk.line_start
            finding.line_end = chunk.line_end
            local_findings.append(finding)

        return local_findings

    # Execute analysis
    if workers == 1 or total_chunks == 1:
        for index, chunk in enumerate(chunks, start=1):
            findings.extend(analyze_one(index, chunk))
    else:
        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {
                executor.submit(analyze_one, index, chunk): (index, chunk)
                for index, chunk in enumerate(chunks, start=1)
            }
            for future in as_completed(futures):
                try:
                    findings.extend(future.result())
                except Exception as exc:
                    print(f"[ERROR] Chunk analysis failed: {exc}")
                    continue

    _emit_progress(
        progress_callback,
        "analyze_done",
        "Chunk analysis completed",
        findings=len(findings),
    )
    return findings


def _verify_findings(
    findings: list[Finding],
    model_name: str,
    api_key: str,
    progress_callback: ProgressCallback | None = None,
) -> list[Finding]:
    """
    Verify findings and normalize categorization.

    Args:
        findings: List of findings to verify
        model_name: Name of the LLM model to use
        api_key: API key for the LLM
        progress_callback: Optional callback for progress updates

    Returns:
        List of verified and filtered findings

    Raises:
        ApiError: If verification fails
    """
    if not findings:
        _emit_progress(
            progress_callback, "verify_done", "No findings to verify", kept=0, total=0
        )
        return []

    _emit_progress(
        progress_callback,
        "verify_start",
        "Running verification pass",
        total=len(findings),
    )

    verifier = create_structured_llm(model_name, api_key, 0.0, VerificationResponse)
    raw = [f.model_dump() for f in findings]
    prompt = build_verification_prompt(json.dumps(raw, indent=2))

    try:
        response = verifier.invoke(
            [
                {"role": "system", "content": VERIFIER_SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ]
        )
    except Exception as exc:
        recovered = parse_failed_generation(exc, VerificationResponse)
        if recovered is None:
            recovered = retry_unstructured_json(
                model_name=model_name,
                api_key=api_key,
                system_prompt=VERIFIER_SYSTEM_PROMPT,
                user_prompt=prompt,
                schema_cls=VerificationResponse,
            )
        if recovered is None:
            raise ApiError(f"Verifier pass failed: {exc}") from exc
        response = recovered

    decision_map = {d.index: d for d in response.decisions}
    kept: list[Finding] = []

    for idx, finding in enumerate(findings):
        decision = decision_map.get(idx)
        if decision is None or not decision.keep:
            continue
        finding.owasp_category = decision.normalized_owasp_category
        finding.title = decision.normalized_title
        finding.confidence = decision.adjusted_confidence
        kept.append(finding)

    _emit_progress(
        progress_callback,
        "verify_done",
        "Verification completed",
        kept=len(kept),
        total=len(findings),
    )
    return kept


def _dedup_findings(findings: list[Finding]) -> list[Finding]:
    """
    Deduplicate findings, keeping highest confidence ones.

    Args:
        findings: List of findings to deduplicate

    Returns:
        Deduplicated list of findings sorted by file and line
    """
    best: dict[tuple[str, str, str], Finding] = {}

    for f in findings:
        # Use key that groups similar vulnerabilities
        key = (
            f.file,
            f.owasp_category,
            f.title.split()[0],  # Group by first word (e.g., "SQL", "OS")
        )
        if key not in best or f.confidence > best[key].confidence:
            best[key] = f
        elif f.file == best[key].file and f.title != best[key].title:
            # Keep distinct vulnerability types in same file
            specific_key = (
                f.file,
                f.owasp_category,
                f.title,
            )
            if specific_key not in best:
                best[specific_key] = f

    # Sort by file and line number
    return sorted(best.values(), key=lambda x: (x.file, x.line_start))


def run_scan(
    target_path: str,
    model_name: str,
    api_key: str,
    max_files: int | None = None,
    progress_callback: ProgressCallback | None = None,
) -> ScanReport:
    """
    Execute a complete security scan on the target path.

    Args:
        target_path: Path to directory or file to scan
        model_name: Name of the LLM model to use for analysis
        api_key: API key for the LLM
        max_files: Maximum number of files to scan (None for unlimited)
        progress_callback: Optional callback for progress updates

    Returns:
        ScanReport with all findings and statistics

    Raises:
        InputError: If target path is invalid
        ApiError: If LLM analysis fails
    """
    # Step 1: Collect source files
    _emit_progress(
        progress_callback,
        "collect_start",
        "Collecting files",
        target_path=target_path,
        max_files=max_files,
    )
    source_files = collect_source_files(target_path, max_files=max_files)
    _emit_progress(
        progress_callback,
        "collect_done",
        "Files collected",
        total_files=len(source_files),
    )

    # Step 2: Chunk source files
    all_chunks: list[CodeChunk] = []
    for index, file_path in enumerate(source_files, start=1):
        try:
            chunks = chunk_file(file_path)
            all_chunks.extend(chunks)
            _emit_progress(
                progress_callback,
                "chunk_file",
                "Chunked file",
                index=index,
                total=len(source_files),
                file=file_path,
                chunks=len(chunks),
            )
        except Exception as exc:
            print(f"[WARN] Failed to chunk {file_path}: {exc}")
            continue

    _emit_progress(
        progress_callback,
        "chunk_done",
        "Code chunking completed",
        total_chunks=len(all_chunks),
    )

    # Step 3: Analyze chunks for vulnerabilities
    raw_findings = _scan_chunks(
        all_chunks,
        model_name=model_name,
        api_key=api_key,
        progress_callback=progress_callback,
    )

    # Step 4: Verify findings
    verified = _verify_findings(
        raw_findings,
        model_name=model_name,
        api_key=api_key,
        progress_callback=progress_callback,
    )

    # Step 5: Add deterministic findings for obvious patterns
    augmented = _augment_with_heuristics(
        all_chunks,
        verified,
        progress_callback=progress_callback,
    )

    # Step 6: Deduplicate findings
    final_findings = _dedup_findings(augmented)
    _emit_progress(
        progress_callback,
        "dedup_done",
        "Deduplication completed",
        before=len(augmented),
        after=len(final_findings),
    )

    for finding in final_findings:
        finding.file = _relative_path(finding.file)

    return ScanReport(
        scanned_path=_relative_path(target_path),
        total_files=len(source_files),
        total_chunks=len(all_chunks),
        total_findings=len(final_findings),
        findings=final_findings,
    )


def findings_from_json(text: str) -> list[Finding]:
    """
    Parse findings from JSON text.

    Args:
        text: JSON text containing findings

    Returns:
        List of parsed Finding objects
    """
    adapter = TypeAdapter(list[Finding])
    return adapter.validate_json(text)
