import json
import os
from getpass import getpass
from pathlib import Path

from .errors import ConfigError


CONFIG_DIR = Path.home() / ".owasp_guard"
CONFIG_FILE = CONFIG_DIR / "config.json"


def _load_config() -> dict:
    if not CONFIG_FILE.exists():
        return {}
    try:
        raw = CONFIG_FILE.read_text(encoding="utf-8")
        loaded = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ConfigError(f"Invalid config file format: {CONFIG_FILE} ({exc})") from exc
    except OSError as exc:
        raise ConfigError(f"Unable to read config file: {CONFIG_FILE} ({exc})") from exc
    if not isinstance(loaded, dict):
        raise ConfigError(f"Invalid config file structure: {CONFIG_FILE}")
    return loaded


def save_api_key(api_key: str) -> Path:
    sanitized = api_key.strip()
    if not sanitized:
        raise ConfigError("API key cannot be empty.")
    if not sanitized.startswith("gsk_"):
        raise ConfigError("API key must start with 'gsk_'.")
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    payload = _load_config()
    payload["groq_api_key"] = sanitized
    try:
        CONFIG_FILE.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    except OSError as exc:
        raise ConfigError(f"Unable to write config file: {CONFIG_FILE} ({exc})") from exc
    return CONFIG_FILE


def get_api_key() -> str | None:
    from_env = os.getenv("GROQ_API_KEY")
    if from_env:
        return from_env.strip()
    payload = _load_config()
    key = payload.get("groq_api_key")
    if isinstance(key, str) and key.strip():
        return key.strip()
    return None


def ensure_api_key(interactive: bool = True) -> str:
    key = get_api_key()
    if key:
        return key
    if not interactive:
        raise ConfigError("Groq API key not set. Run: owasp-guard init")
    entered = getpass("Enter your Groq API key (input hidden): ").strip()
    if not entered:
        raise ConfigError("Empty API key. Run again with a valid key.")
    save_api_key(entered)
    return entered
