"""LLM utilities and error handling for the OWASP Guard scanner."""

import ast
import json
from typing import Any

from .errors import ApiError


def create_structured_llm(model_name: str, api_key: str, temperature: float, schema):
    """
    Create an LLM instance with structured output support.

    Args:
        model_name: Name of the model to use
        api_key: API key for the model
        temperature: Temperature setting for the model
        schema: Output schema class

    Returns:
        LLM instance with structured output

    Raises:
        ApiError: If model initialization fails
    """
    from langchain_groq import ChatGroq

    try:
        llm = ChatGroq(model=model_name, api_key=api_key, temperature=temperature)
    except Exception as exc:
        raise ApiError(f"Failed to initialize model '{model_name}': {exc}") from exc
    return llm.with_structured_output(schema)


def parse_failed_generation(exception: Exception, schema_cls) -> Any | None:
    """
    Recover model output from Groq tool_use_failed errors.

    Extracts serialized fallback payload from error message when
    the provider includes a serialized fallback under error.failed_generation.

    Args:
        exception: The exception from failed generation
        schema_cls: Schema class to validate against

    Returns:
        Validated schema instance, or None if recovery failed
    """
    msg = str(exception)
    marker = "Error code:"
    if marker not in msg:
        return None

    payload_start = msg.find("{")
    if payload_start < 0:
        return None

    raw_payload = msg[payload_start:]
    try:
        parsed = ast.literal_eval(raw_payload)
    except Exception:
        return None

    if not isinstance(parsed, dict):
        return None

    err = parsed.get("error")
    if not isinstance(err, dict):
        return None

    failed_generation = err.get("failed_generation")
    if not isinstance(failed_generation, str):
        return None

    cleaned = failed_generation.strip()
    # Typical provider envelope: <function=SchemaName> { ...json... } </function>
    json_start = cleaned.find("{")
    if json_start < 0:
        return None

    cleaned = cleaned[json_start:]

    try:
        as_dict, _ = json.JSONDecoder().raw_decode(cleaned)
        return schema_cls.model_validate(as_dict)
    except Exception:
        return None


def extract_json_payload(text: str) -> Any | None:
    """
    Extract JSON object from text, handling markdown code blocks.

    Args:
        text: Text potentially containing JSON

    Returns:
        Parsed JSON object, or None if extraction failed
    """
    candidate = text.strip()
    if candidate.startswith("```"):
        lines = candidate.splitlines()
        if len(lines) >= 3 and lines[-1].strip().startswith("```"):
            candidate = "\n".join(lines[1:-1]).strip()

    json_start = candidate.find("{")
    if json_start < 0:
        return None

    candidate = candidate[json_start:]
    try:
        obj, _ = json.JSONDecoder().raw_decode(candidate)
        return obj
    except Exception:
        return None


def retry_unstructured_json(
    model_name: str,
    api_key: str,
    system_prompt: str,
    user_prompt: str,
    schema_cls,
) -> Any | None:
    """
    Fallback JSON parsing when structured output fails.

    Makes a second attempt with explicit guidance to return only
    valid JSON without tools or markdown formatting.

    Args:
        model_name: Name of the model to use
        api_key: API key for the model
        system_prompt: System prompt for context
        user_prompt: User prompt with the task
        schema_cls: Schema class to validate against

    Returns:
        Validated schema instance, or None if fallback failed
    """
    from langchain_groq import ChatGroq

    guidance = (
        "Your previous response format failed. "
        "Return only a single valid JSON object matching the required schema. "
        "Do not call any tools and do not include markdown."
    )

    try:
        llm = ChatGroq(model=model_name, api_key=api_key, temperature=0.0)
        raw_response = llm.invoke(
            [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
                {"role": "user", "content": guidance},
            ]
        )
    except Exception:
        return None

    content = raw_response.content
    if isinstance(content, list):
        text = "".join(
            part.get("text", "") for part in content if isinstance(part, dict)
        )
    else:
        text = str(content)

    payload = extract_json_payload(text)
    if payload is None:
        return None

    try:
        return schema_cls.model_validate(payload)
    except Exception:
        return None
