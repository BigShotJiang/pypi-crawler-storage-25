"""File collection module for the OWASP Guard scanner."""

import os
from pathlib import Path

from .constants import SKIP_DIRS, SKIP_FILENAMES, SUPPORTED_EXTENSIONS
from .errors import InputError


def collect_source_files(target_path: str, max_files: int | None = None) -> list[str]:
    """
    Collect all supported source code files from the target path.

    Args:
        target_path: Path to directory or file to scan
        max_files: Maximum number of files to collect (None for unlimited)

    Returns:
        Sorted list of absolute file paths

    Raises:
        InputError: If path is invalid or max_files is invalid
    """
    if max_files is not None and max_files <= 0:
        raise InputError("--max-files must be greater than 0.")

    p = Path(target_path)
    if not p.exists():
        raise InputError(f"Path not found: {target_path}")

    # Handle single file input
    if p.is_file():
        ext = p.suffix.lower()
        if ext not in SUPPORTED_EXTENSIONS and p.name.lower() not in {"dockerfile"}:
            raise InputError(f"Unsupported file extension: {ext or '(none)'}")
        return [str(p.resolve())]

    # Collect files from directory
    files: list[str] = []
    for root, dirs, names in os.walk(p):
        # Skip unwanted directories
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]

        for name in names:
            if name in SKIP_FILENAMES:
                continue

            ext = Path(name).suffix.lower()
            if ext in SUPPORTED_EXTENSIONS or name.lower() == "dockerfile":
                files.append(str((Path(root) / name).resolve()))

                if max_files and len(files) >= max_files:
                    return sorted(files)

    return sorted(files)
