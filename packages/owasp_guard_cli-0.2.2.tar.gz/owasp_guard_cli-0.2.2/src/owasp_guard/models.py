from pydantic import BaseModel, Field


class CodeChunk(BaseModel):
    file: str
    line_start: int = Field(ge=1)
    line_end: int = Field(ge=1)
    context: str
    code: str


class Finding(BaseModel):
    file: str
    line_start: int = Field(ge=1)
    line_end: int = Field(ge=1)
    owasp_category: str
    title: str
    risk_summary: str
    fix_recommendation: str
    evidence: str
    confidence: float = Field(ge=0.0, le=1.0)


class FindingsResponse(BaseModel):
    findings: list[Finding] = Field(default_factory=list)


class VerificationDecision(BaseModel):
    index: int = Field(ge=0)
    keep: bool
    normalized_owasp_category: str
    normalized_title: str
    adjusted_confidence: float = Field(ge=0.0, le=1.0)
    reason: str


class VerificationResponse(BaseModel):
    decisions: list[VerificationDecision] = Field(default_factory=list)


class ScanReport(BaseModel):
    scanned_path: str
    total_files: int
    total_chunks: int
    total_findings: int
    findings: list[Finding] = Field(default_factory=list)
