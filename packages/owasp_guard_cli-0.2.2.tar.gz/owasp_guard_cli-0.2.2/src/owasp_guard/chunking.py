"""Code chunking module for the OWASP Guard scanner."""

import os
import re
from pathlib import Path

from .constants import (
    DEFAULT_MAX_CHUNK_LINES,
    DEFAULT_MAX_CHUNKS_PER_FILE,
    DEFAULT_MIN_CHUNK_LINES,
    FUNC_PATTERNS,
    IMPORTANT_PATTERNS,
    MAX_CACHE_SIZE,
    ROUTE_PATTERNS,
    SECURITY_PATTERNS,
)
from .errors import ScanError
from .models import CodeChunk

# Cache for chunks
_chunk_cache = {}


def extract_shared_context(lines: list[str]) -> str:
    """
    Extract imports and important declarations for context.

    Args:
        lines: List of source code lines

    Returns:
        String containing extracted context (imports, declarations, etc.)
    """
    context_lines: list[str] = []

    for line in lines[:200]:  # Check first 200 lines
        s = line.strip()
        for pattern in IMPORTANT_PATTERNS:
            if pattern in s:
                context_lines.append(line.rstrip())
                break

    return "\n".join(context_lines[:50]).strip()


def find_function_boundaries(file_path: str, lines: list[str]) -> list[int]:
    """
    Enhanced function detection that also finds route handlers.

    Args:
        file_path: Path to source file
        lines: List of source code lines

    Returns:
        List of line numbers where functions/routes start
    """
    ext = Path(file_path).suffix.lower()
    starts: list[int] = []

    if ext == ".py":
        for i, line in enumerate(lines, start=1):
            # Match function/class definitions
            if re.match(r"^\s*(def|class)\s+\w+", line):
                starts.append(i)
            # Match Flask/FastAPI decorators (they come before the function)
            elif re.match(r"^\s*@(app|router)\.", line):
                starts.append(i)
    else:
        # Look for Express/Fastify route handlers and functions
        for i, line in enumerate(lines, start=1):
            # Check for route handlers (highest priority)
            for pattern in ROUTE_PATTERNS:
                if re.search(pattern, line, re.IGNORECASE):
                    starts.append(i)
                    break

            # Check for functions (if not already found)
            if not starts or starts[-1] != i:
                for pattern in FUNC_PATTERNS:
                    if re.search(pattern, line):
                        starts.append(i)
                        break

    # Sort and remove duplicates
    starts = sorted(set(starts))

    # If no starts found, create chunks at regular intervals
    if not starts and len(lines) > 100:
        print(
            f"[DEBUG] No function/route boundaries found in {file_path}, using sliding windows"
        )
        for i in range(1, len(lines) + 1, 100):
            starts.append(i)

    return starts


def chunk_route_file(file_path: str, lines: list[str], context: str) -> list[CodeChunk]:
    """
    Specialized chunking for Express/Fastify/Flask route files.

    Strategy:
    1. Include module-level code (imports, constants, helpers) as first chunk
    2. Each route handler as its own separate, non-overlapping chunk
    3. This ensures each route is analyzed independently for vulnerabilities

    Args:
        file_path: Path to file being chunked
        lines: List of source code lines
        context: Extracted context from file

    Returns:
        List of CodeChunk objects
    """
    chunks = []
    route_starts = []

    # Find all route handlers (both Express and Flask styles)
    for i, line in enumerate(lines, 1):
        # Flask decorators
        if re.match(r"^\s*@(app|router)\.", line):
            route_starts.append(i)
        # Express/Fastify methods
        elif re.search(
            r"app\.(get|post|put|delete|patch|all)\s*\(", line, re.IGNORECASE
        ):
            route_starts.append(i)
        elif re.search(
            r"router\.(get|post|put|delete|patch|all)\s*\(", line, re.IGNORECASE
        ):
            route_starts.append(i)

    # If we found routes, chunk them with context
    if route_starts:
        first_route = route_starts[0]

        # Chunk 1: Module-level code (everything before first route)
        if first_route > 1:
            code = "\n".join(lines[0:first_route]).strip()
            if code:
                chunks.append(
                    CodeChunk(
                        file=file_path,
                        line_start=1,
                        line_end=first_route - 1,
                        context=context,
                        code=code,
                    )
                )

        # Chunks 2+: Individual route handlers - NON-OVERLAPPING
        for i, start in enumerate(route_starts[:DEFAULT_MAX_CHUNKS_PER_FILE]):
            # End at the line before next route (or end of file)
            if i + 1 < len(route_starts):
                end = route_starts[i + 1] - 1
            else:
                # Last route: take all remaining lines
                end = len(lines)

            code = "\n".join(lines[start - 1 : end]).strip()
            if code:
                chunks.append(
                    CodeChunk(
                        file=file_path,
                        line_start=start,
                        line_end=end,
                        context=context,
                        code=code,
                    )
                )
    else:
        # No routes found? Use sliding windows
        chunks = _chunk_with_sliding_window(file_path, lines, context)

    return chunks


def chunk_general_file(
    file_path: str, lines: list[str], context: str
) -> list[CodeChunk]:
    """
    General chunking for non-route files.

    Args:
        file_path: Path to file being chunked
        lines: List of source code lines
        context: Extracted context from file

    Returns:
        List of CodeChunk objects
    """
    starts = find_function_boundaries(file_path, lines)

    if not starts:
        return _chunk_with_sliding_window(file_path, lines, context)

    # Use function boundaries for chunking
    chunks = []
    for idx, start in enumerate(starts[:DEFAULT_MAX_CHUNKS_PER_FILE]):
        end = starts[idx + 1] - 1 if idx + 1 < len(starts) else len(lines)

        # If chunk is too large, split it
        if end - start + 1 > DEFAULT_MAX_CHUNK_LINES * 1.5:
            # Split into smaller chunks
            for sub_start in range(start, end + 1, DEFAULT_MAX_CHUNK_LINES):
                sub_end = min(sub_start + DEFAULT_MAX_CHUNK_LINES - 1, end)
                code = "\n".join(lines[sub_start - 1 : sub_end]).strip()
                if code:
                    chunks.append(
                        CodeChunk(
                            file=file_path,
                            line_start=sub_start,
                            line_end=sub_end,
                            context=context,
                            code=code,
                        )
                    )
        else:
            code = "\n".join(lines[start - 1 : end]).strip()
            if code:
                chunks.append(
                    CodeChunk(
                        file=file_path,
                        line_start=start,
                        line_end=end,
                        context=context,
                        code=code,
                    )
                )

    return chunks


def _chunk_with_sliding_window(
    file_path: str, lines: list[str], context: str
) -> list[CodeChunk]:
    """Create chunks using a sliding window approach."""
    window_size = 100
    overlap = 20
    chunks = []

    for i in range(0, len(lines), window_size - overlap):
        if len(chunks) >= DEFAULT_MAX_CHUNKS_PER_FILE:
            break
        start = i + 1
        end = min(i + window_size, len(lines))
        code = "\n".join(lines[i:end]).strip()
        if code:
            chunks.append(
                CodeChunk(
                    file=file_path,
                    line_start=start,
                    line_end=end,
                    context=context,
                    code=code,
                )
            )

    return chunks


def prioritize_chunks(chunks: list[CodeChunk], max_chunks: int) -> list[CodeChunk]:
    """
    Keep the most important chunks when we have too many.

    Args:
        chunks: List of code chunks
        max_chunks: Maximum number of chunks to keep

    Returns:
        Filtered list of high-priority chunks
    """
    if len(chunks) <= max_chunks:
        return chunks

    # Score each chunk by "interestingness"
    scored_chunks = []
    for chunk in chunks:
        score = 0
        code_lower = chunk.code.lower()

        for pattern, points in SECURITY_PATTERNS:
            if pattern in code_lower:
                score += points

        # Penalize very short chunks
        if len(chunk.code) < 50:
            score -= 5

        # Boost chunks with more lines of actual code
        non_empty_lines = sum(1 for line in chunk.code.split("\n") if line.strip())
        score += min(10, non_empty_lines / 5)

        scored_chunks.append((score, chunk))

    # Sort by score and take top chunks
    scored_chunks.sort(reverse=True, key=lambda x: x[0])
    return [chunk for score, chunk in scored_chunks[:max_chunks]]


def merge_chunks(
    chunks: list[CodeChunk],
    max_chunk_lines: int,
    min_chunk_lines: int,
) -> list[CodeChunk]:
    """
    Merge adjacent chunks only if combined size is reasonable.

    NOTE: We're intentionally conservative with merging to preserve
    separate vulnerability detection per function/route.

    Args:
        chunks: List of code chunks
        max_chunk_lines: Maximum lines per chunk
        min_chunk_lines: Minimum lines per chunk (informational only)

    Returns:
        List of merged chunks
    """
    if len(chunks) <= 1:
        return chunks

    merged: list[CodeChunk] = []
    active = chunks[0]

    for nxt in chunks[1:]:
        active_lines = active.line_end - active.line_start + 1
        next_lines = nxt.line_end - nxt.line_start + 1
        combined = active_lines + next_lines

        # Only merge if: adjacent/overlapping AND combined size is still manageable
        # We DON'T merge just because one chunk is too small - keep them separate!
        should_merge = (
            active.file == nxt.file
            and active.line_end + 1 >= nxt.line_start
            and combined <= max_chunk_lines  # Only condition: keep total reasonable
        )

        if should_merge:
            active = CodeChunk(
                file=active.file,
                line_start=active.line_start,
                line_end=nxt.line_end,
                context=active.context,
                code=f"{active.code}\n{nxt.code}".strip(),
            )
        else:
            merged.append(active)
            active = nxt

    merged.append(active)
    return merged


def chunk_file(file_path: str) -> list[CodeChunk]:
    """
    Optimized chunking with caching and smart boundaries.

    Args:
        file_path: Path to source file to chunk

    Returns:
        List of CodeChunk objects

    Raises:
        ScanError: If file cannot be read
    """
    # Check cache first
    try:
        mtime = os.path.getmtime(file_path)
        cache_key = f"{file_path}:{mtime}"
        if cache_key in _chunk_cache:
            print(f"[DEBUG] Using cached chunks for {file_path}")
            return _chunk_cache[cache_key]
    except OSError:
        pass

    # Read file
    try:
        text = Path(file_path).read_text(encoding="utf-8", errors="ignore")
    except OSError as exc:
        raise ScanError(f"Unable to read source file: {file_path} ({exc})") from exc

    lines = text.splitlines()
    if not lines:
        return []

    # Get settings from environment
    max_chunks = int(
        os.getenv("OWASP_GUARD_MAX_CHUNKS_PER_FILE", str(DEFAULT_MAX_CHUNKS_PER_FILE))
    )

    # Extract context
    context = extract_shared_context(lines)

    # Determine file type
    text_lower = text.lower()
    is_route_file = (
        "app." in text_lower or "router." in text_lower or "route." in text_lower
    )
    is_config_file = "config" in file_path.lower() or ".env" in file_path.lower()

    # Different strategies based on file type
    if is_route_file and len(lines) > 100:
        chunks = chunk_route_file(file_path, lines, context)
        # DON'T MERGE route chunks - we want each route analyzed separately!
    elif is_config_file:
        # For config files: one chunk is usually enough
        chunks = [
            CodeChunk(
                file=file_path,
                line_start=1,
                line_end=len(lines),
                context=context,
                code=text,
            )
        ]
    else:
        chunks = chunk_general_file(file_path, lines, context)

        # Apply chunk merging only for non-route files
        max_chunk_lines = int(
            os.getenv("OWASP_GUARD_MAX_CHUNK_LINES", str(DEFAULT_MAX_CHUNK_LINES))
        )
        min_chunk_lines = int(
            os.getenv("OWASP_GUARD_MIN_CHUNK_LINES", str(DEFAULT_MIN_CHUNK_LINES))
        )
        chunks = merge_chunks(
            chunks, max_chunk_lines=max_chunk_lines, min_chunk_lines=min_chunk_lines
        )

    # Prioritize chunks if we have too many
    if len(chunks) > max_chunks:
        print(f"[DEBUG] Limiting {file_path} from {len(chunks)} to {max_chunks} chunks")
        chunks = prioritize_chunks(chunks, max_chunks)

    # Cache the result
    try:
        mtime = os.path.getmtime(file_path)
        cache_key = f"{file_path}:{mtime}"
        _chunk_cache[cache_key] = chunks

        # Limit cache size
        if len(_chunk_cache) > MAX_CACHE_SIZE:
            oldest = sorted(_chunk_cache.keys())[:50]
            for key in oldest:
                del _chunk_cache[key]
    except OSError:
        pass

    print(f"[DEBUG] {file_path}: created {len(chunks)} chunks")
    return chunks
