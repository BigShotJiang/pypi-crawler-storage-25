class OwaspGuardError(Exception):
    """Base exception for all tool errors."""


class ConfigError(OwaspGuardError):
    """Configuration or credential setup issues."""


class InputError(OwaspGuardError):
    """Invalid or unsupported user input."""


class ScanError(OwaspGuardError):
    """General scan pipeline failures."""


class ApiError(ScanError):
    """Remote LLM API request failures."""


class ReportError(OwaspGuardError):
    """Report serialization or write failures."""
