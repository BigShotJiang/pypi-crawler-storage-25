"""Configuration and constants for the OWASP Guard scanner."""

# Supported file extensions for security scanning
SUPPORTED_EXTENSIONS = {
    # Web / JS ecosystem
    ".js",
    ".jsx",
    ".mjs",
    ".cjs",
    ".ts",
    ".tsx",
    ".vue",
    ".svelte",
    ".astro",
    # Python
    ".py",
    ".pyw",
    ".pyi",
    # JVM
    ".java",
    ".kt",
    ".kts",
    ".scala",
    ".groovy",
    # .NET
    ".cs",
    ".vb",
    ".fs",
    # Systems / native
    ".c",
    ".h",
    ".cpp",
    ".cc",
    ".cxx",
    ".hpp",
    ".hh",
    ".rs",
    ".zig",
    # Mobile / Apple
    ".swift",
    ".m",
    ".mm",
    # Backend / scripting
    ".go",
    ".rb",
    ".php",
    ".pl",
    ".pm",
    ".lua",
    ".r",
    ".sh",
    ".bash",
    ".zsh",
    ".ps1",
    # Data / query / config that can still contain security-relevant logic
    ".sql",
    ".graphql",
    ".gql",
    ".yaml",
    ".yml",
    ".json",
    ".toml",
    ".ini",
    ".xml",
    # Infra / IaC
    ".tf",
    ".hcl",
    ".dockerfile",
}

# Directories to skip during file collection
SKIP_DIRS = {
    ".git",
    ".github",
    "node_modules",
    "dist",
    "build",
    "__pycache__",
    ".venv",
    "venv",
    ".next",
    ".nuxt",
    ".scannerwork",
    "coverage",
    "target",
    "bin",
    "obj",
}

# Lock files to skip
SKIP_FILENAMES = {
    "package-lock.json",
    "yarn.lock",
    "pnpm-lock.yaml",
    "poetry.lock",
    "Cargo.lock",
}

# Chunking configuration
DEFAULT_MAX_CHUNK_LINES = 150
DEFAULT_MIN_CHUNK_LINES = 30
DEFAULT_MAX_CHUNKS_PER_FILE = 15
DEFAULT_ANALYZE_WORKERS = 8

# Cache configuration
MAX_CACHE_SIZE = 100

# Security patterns for chunk prioritization
SECURITY_PATTERNS = [
    ("sql", 10),
    ("query", 8),
    ("execute", 8),
    ("password", 10),
    ("secret", 10),
    ("key", 8),
    ("token", 8),
    ("eval(", 10),
    ("function(", 5),
    ("req.", 8),
    ("request.", 8),
    ("res.", 5),
    ("response.", 5),
    ("app.", 7),
    ("router.", 7),
    ("process.env", 6),
    ("env", 4),
    ("<script", 10),
    ("innerhtml", 8),
    ("document.write", 8),
    ("auth", 6),
    ("login", 6),
    ("register", 5),
    ("file", 5),
    ("fs.", 6),
    ("readfile", 6),
    ("http://", 3),
    ("https://", 3),
    ("cors", 5),
    ("origin", 5),
]

# Context extraction patterns
IMPORTANT_PATTERNS = [
    "import ",
    "from ",
    "require(",
    "export ",
    "const ",
    "let ",
    "var ",
    "app.",
    "router.",
    "server.",
    "use(",
    "middleware",
    "process.env",
    "database",
    "db.",
    "config",
]

# Route detection patterns
ROUTE_PATTERNS = [
    # Flask decorators
    r"@app\.(route|get|post|put|delete|patch|before_request|after_request)",
    # Express/Fastify methods
    r"app\.(get|post|put|delete|patch|all)\s*\(",
    r"router\.(get|post|put|delete|patch|all)\s*\(",
    r"route\.(get|post|put|delete|patch|all)\s*\(",
    r"server\.(get|post|put|delete|patch|all)\s*\(",
    r"\.addRoute\s*\(",
    r"\.route\s*\(",
]

# Function definition patterns
FUNC_PATTERNS = [
    r"^\s*(export\s+)?(async\s+)?function\s+\w+\s*\(",
    r"^\s*(export\s+)?(const|let|var)\s+\w+\s*=\s*(async\s*)?\([^)]*\)\s*=>",
    r"^\s*(export\s+)?class\s+\w+",
]
