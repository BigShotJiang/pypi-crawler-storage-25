import os
import sqlite3
import hashlib
import pickle
import subprocess
from flask import Flask, request, jsonify, session

app = Flask(__name__)

# ── VULNERABILITY 1: Hardcoded secrets (A02) ─────────────────────────────────
SECRET_KEY = "supersecret123"
DB_PASSWORD = "admin123"
JWT_SECRET = "jwt-hardcoded-key"
app.secret_key = "flask-secret-abc"


# ── VULNERABILITY 2: Weak database setup ─────────────────────────────────────
def get_db():
    conn = sqlite3.connect("users.db")
    return conn


# ── VULNERABILITY 3: SQL Injection (A03) ─────────────────────────────────────
@app.route("/login", methods=["POST"])
def login():
    username = request.form["username"]
    password = request.form["password"]

    # VULNERABLE: direct string concat into SQL
    conn = get_db()
    query = (
        "SELECT * FROM users WHERE username = '"
        + username
        + "' AND password = '"
        + password
        + "'"
    )
    user = conn.execute(query).fetchone()

    if user:
        session["user"] = username
        return jsonify({"status": "logged in"})
    return jsonify({"status": "failed"}), 401


# ── VULNERABILITY 4: Broken Access Control (A01) ─────────────────────────────
@app.route("/api/admin/users", methods=["GET"])
def get_all_users():
    # VULNERABLE: no authentication check at all
    conn = get_db()
    users = conn.execute("SELECT * FROM users").fetchall()
    return jsonify(users)


# ── VULNERABILITY 5: OS Command Injection (A03) ──────────────────────────────
@app.route("/ping", methods=["GET"])
def ping():
    host = request.args.get("host")
    # VULNERABLE: user input passed directly to shell
    result = subprocess.check_output("ping -c 1 " + host, shell=True)
    return result


# ── VULNERABILITY 6: Insecure Deserialization (A08) ──────────────────────────
@app.route("/load_session", methods=["POST"])
def load_session():
    data = request.get_data()
    # VULNERABLE: unpickling untrusted data
    obj = pickle.loads(data)
    return jsonify({"loaded": str(obj)})


# ── VULNERABILITY 7: Weak Hashing (A02) ──────────────────────────────────────
def hash_password(password: str) -> str:
    # VULNERABLE: MD5 is cryptographically broken for passwords
    return hashlib.md5(password.encode()).hexdigest()


# ── VULNERABILITY 8: SSRF (A10) ──────────────────────────────────────────────
@app.route("/fetch", methods=["GET"])
def fetch_url():
    import urllib.request

    url = request.args.get("url")
    # VULNERABLE: fetches any user-supplied URL, including internal services
    response = urllib.request.urlopen(url)
    return response.read()


# ── VULNERABILITY 9: Sensitive Data Exposure in Logs (A09) ───────────────────
@app.route("/register", methods=["POST"])
def register():
    username = request.form["username"]
    password = request.form["password"]
    # VULNERABLE: logging plaintext password
    print(f"[LOG] New registration: username={username} password={password}")
    hashed = hash_password(password)
    conn = get_db()
    conn.execute(f"INSERT INTO users VALUES ('{username}', '{hashed}')")
    conn.commit()
    return jsonify({"status": "registered"})


# ── VULNERABILITY 10: No Rate Limiting on Auth (A04) ─────────────────────────
@app.route("/api/reset_password", methods=["POST"])
def reset_password():
    email = request.form["email"]
    # VULNERABLE: no rate limiting, allows brute force / account enumeration
    conn = get_db()
    user = conn.execute(f"SELECT * FROM users WHERE email = '{email}'").fetchone()
    if user:
        return jsonify({"status": "reset link sent"})
    return jsonify({"status": "email not found"})  # enumeration leak


if __name__ == "__main__":
    # VULNERABLE: debug=True exposes interactive debugger
    app.run(debug=True, host="0.0.0.0", port=5000)
