#!/usr/bin/env python
#
# #########################################################################
# Copyright (c) , UChicago Argonne, LLC. All rights reserved.             #
#                                                                         #
# See LICENSE file.                                                       #
# #########################################################################
"""
This script reads phasing result image file(s) and applies postprocessing as defined in config_disp file.
Refer to :ref:`config_disp` for definition of parameters that direct the processing. The outcome
is a collection of files in vti and vtk formats that can be visualized with Paraview.

To deliver the files for visualization the program calculates geometry that depends on parameters in config_instr
file that differ for beamlines. Refer to :ref:`config_instr` for definitions of these parameters by beamline.
The parameters are metadata, however for some beamlines some parameters have to be configured.

The script will generate image of the reconstructed object in direct space in vts format.
In addition, through configuration user can request twin image, unwrapped phase, interpolation, resolution, and
reciprocal space view.

To run this script from command line::

    beamline_visualization <experiment_dir>

optional argument may follow:  --no_verify

One can use --help to get explanation of command line parameters.
"""

__author__ = "Ross Harder"
__copyright__ = "Copyright (c), UChicago Argonne, LLC."
__docformat__ = 'restructuredtext en'
__all__ = ['process_dir',
           'handle_visualization',
           'main']

import argparse
import os
import numpy as np
from functools import partial
from multiprocessing import cpu_count
import importlib
import cohere_core.utilities as ut
import cohere_ui.api.multipeak as mp
import cohere_ui.api.common as com
import cohere_ui.api.postprocessor as pu
import pandas as pd
from concurrent.futures import ProcessPoolExecutor


def process_dir(config_maps, res_dir_scan):
    """
    Loads arrays with reconstructed image from files in results directory and applies postprocessing according to
    configuration.

    :param config_maps: dictionary of dictionaries with configuration parameters with the config file names as keys
    :param res_dir_scan: tuple containing phasing results directory and corresponding scan number
    :param kwargs:
        no_verify : boolean switch to determine if the verification error throws exception
    """
    [scan, res_dir] = res_dir_scan

    save_dir = res_dir.replace('_phasing', '_viz')
    # create dir if it does not exist
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)

    config_map = config_maps['config']
    beamline = config_map["beamline"]
    try:
        instr_module = importlib.import_module(f'cohere_beamlines.{beamline}.instrument')
        instr_obj = instr_module.create_instr(config_maps)
    except Exception as ex:
        print('exiting post-processing')
        raise ex

    # image file was checked in calling function
    imagefile = ut.join(res_dir, 'image.npy')
    image = np.load(imagefile)

    # init variables
    support = None
    coh = None

    supportfile = ut.join(res_dir, 'support.npy')
    if os.path.isfile(supportfile):
        try:
            support = np.load(supportfile)
        except:
            print(f'cannot load file {supportfile}')
    else:
        print(f'support file is missing in {res_dir} directory')

    viz_params = config_maps['config_disp']
    # get geometry
    ds = {}
    ds['res_dir'] = res_dir
    geometry = instr_obj.get_geometry(image.shape, scan, config_maps)
    myq = geometry[2]
    ki = geometry[3]
    kf = geometry[4]
    ds['Ki'] = ki
    ds['Kf'] = kf
    ds['Q'] = myq

    # This block of code creates vts file with arrays depending on the complex_mode.
    # If complex_mode is "AmpPhase" the following arrays are included: imAmp, imPh, support.
    # If complex_mode is "ReIm" the following arrays are included: imRe, imImag, support .
    dir_viz = pu.make_image_viz(geometry, image, support, config_maps, ds)
    complex_mode = viz_params.get('complex_mode', 'AmpPhase')
    filename = ut.join(save_dir, f'direct_space_images_{complex_mode}.vts')
    dir_viz.write(filename, complex_mode=complex_mode)
    print(f'saved direct_space_images_{complex_mode}.vts file')

    imcom = dir_viz.get_COM('im')
    ds['image com'] = imcom
    #output the vectors of the measurement in lab frame (ki, kf, Q=kf-ki)
    #the Q is needed for the strain calc
    vectorviz = pu.make_geometry_vectors_viz(geometry, position=imcom)
    filename = ut.join(save_dir, f'KiKfQ.vtu')
    vectorviz.save(filename, binary=False)

    res_viz_d, res_viz_r = None, None
    # If 'interpolation_mode' and 'interpolation_resolution' parameters are configured then
    # the image is interpolated. First the resolution is determined. It can be configured
    # or calculated depending on the 'interpolation_resolution' parameter.
    if 'interpolation_mode' in viz_params:
        cont_interpolation = True
        if 'interpolation_resolution' not in viz_params:
            print (f'interpolation_resolution parameter not configured, will not do interpolation')
            cont_interpolation = False

        # Find the resolution, as it can be configured as a value or prompted to derive it if configured
        # to 'min_deconv_res'.
        if cont_interpolation:
            match viz_params['interpolation_resolution']:
                case [*_]:
                    interpolation_resolution = viz_params['interpolation_resolution']
                case int():
                    interpolation_resolution = viz_params['interpolation_resolution']
                case float():
                    interpolation_resolution = viz_params['interpolation_resolution']
                case 'min_deconv_res':
                    # Only direct resolution is needed for interpolation.
                    # If configured to determine resolution, get it here in direct and reciprocal spaces, otherwise
                    # get only direct space resolution to use for interpolation.
                    if 'determine_resolution_type' not in viz_params:
                        raise ValueError(f'Unable processing of interpolation with resolution set to "min_deconv_res". Activate the resolution in GUI or when running from command line, set determine_resolution_type parameter, exiting')
                    res_viz_d, res_viz_r = pu.make_resolution_viz(geometry, np.abs(image), config_maps)
                    res_viz_d.write(ut.join(save_dir, "resolution_direct.vts"))
                    res_viz_r.write(ut.join(save_dir, "resolution_recip.vts"))
                    print('saved resolution_direct.vts and resolution_recip.vts files')
                    res_ssg = res_viz_d.get_structured_grid()
                    res_arr = res_ssg.point_data['resolution']
                    # because of [::-1] to get array indexing right the x axis in paraview is last axis in array.
                    res_arr.shape = res_ssg.dimensions[::-1]
                    res_bounds = pu.find_datarange(res_arr, 0, 0.5)
                    r1 = np.dot(geometry[1], [res_bounds[0] / res_arr.shape[0], 0, 0])
                    r2 = np.dot(geometry[1], [0, res_bounds[1] / res_arr.shape[1], 0])
                    r3 = np.dot(geometry[1], [0, 0, res_bounds[2] / res_arr.shape[2]])
                    # interpolate at half the smallest value.  Could make a param.
                    interpolation_resolution = min([np.linalg.norm(r1), np.linalg.norm(r2), np.linalg.norm(r3)]) / 2
                case _:
                    cont_interpolation = False
                    print (f'not supported interpolation_resolution parameter value {viz_params["interpolation_resolution"]}, will not do interpolation')

        if cont_interpolation:
            interpolation_mode = viz_params['interpolation_mode']
            sgrid = dir_viz.get_structured_grid(complex_mode=interpolation_mode)
            interpolated_data = pu.interpolate(sgrid, interpolation_resolution)
            filename = ut.join(save_dir, f'direct_space_images_interpolated_{interpolation_mode}.vti')
            match interpolation_mode:
                case 'AmpPhase':
                    # In this mode the image amplitudes and phases are obtained from the grid and interpolated
                    # The imAmp and imPh arrays are then saved.
                    pass
                case 'ReIm':
                    # In this mode the image amplitudes and phases are calculated from real and imaginary values
                    # obtained from the grid and then interpolated.
                    # The imAmp and imPh arrays are then saved.
                    interpolated_data.point_data['imAmp'] = np.abs(interpolated_data.point_data['imRe'] +
                                                                   1j * interpolated_data.point_data['imImag'])
                    interpolated_data.point_data['imPh'] = np.angle(interpolated_data.point_data['imRe'] +
                                                                   1j * interpolated_data.point_data['imImag'])
                case _:
                    cont_interpolation = False
                    print (f'not supported interpolation_mode parameter value {viz_params["interpolation_mode"]}, will not do interpolation')
            if cont_interpolation:
                interpolated_data.save(filename)
                print(f'saved direct_space_images_interpolated_{interpolation_mode}.vti file')

    del dir_viz

    if 'determine_resolution_type' in viz_params:
        if res_viz_d is None: # otherwise it was saved during interpolation
            res_viz_d, res_viz_r = pu.make_resolution_viz(geometry, np.abs(image), config_maps)
            res_viz_d.write(ut.join(save_dir, "resolution_direct.vts"))
            res_viz_r.write(ut.join(save_dir, "resolution_recip.vts"))
            print('saved resolution_direct.vts and resolution_recip.vts files')

        del res_viz_d
        del res_viz_r

    if viz_params.get('write_recip', False):
        while not res_dir.endswith('results_phasing'):
            res_dir = os.path.split(res_dir)[0]
        dfile = ut.join(*(os.path.split(res_dir)[0], "phasing_data", "data.tif"))
        d = ut.read_tif(dfile)
        ftim = np.fft.ifftshift(np.fft.ifftn(np.fft.fftshift(image), norm='forward'))
        dviz = pu.make_recip_viz(geometry, np.abs(d), ftim)
        dviz.write(ut.join(save_dir, "reciprocal_space.vts"))
        print('saved reciprocal_space.vts file')

    if viz_params.get('make_twin', False):
        twin_image = np.conjugate(np.flip(image))
        if support is not None:
            twin_support = np.flip(support)
        twin_viz = pu.make_image_viz(geometry, twin_image, twin_support, config_maps, ds)
        twin_viz.write(ut.join(save_dir, "twin_direct_space_images.vts"))
        print('saved twin_direct_space_images.vts file')

    cohfile = ut.join(res_dir, 'coherence.npy')
    if os.path.isfile(cohfile):
        coh = np.load(cohfile)
        (viz_d, viz_r) = pu.make_coherence_viz(geometry, coh, image.shape)
        viz_d.write(ut.join(save_dir, "direct_space_coherence.vts"))
        viz_r.write(ut.join(save_dir, "recip_space_coherence.vts"))
        print('saved direct_space_coherence.vts and recip_space_coherence.vts files')

    return ds


def handle_visualization(experiment_dir, **kwargs):
    """
    Reads the configuration files and accordingly to configuration continues postprocessing for all image files
    found in the configured results_dir tree. The outcome are vts and vti format files that can be viewed using
    Paraview.

    :param experimnent_dir: directory with experiment files
    :param kwargs:
        no_verify : boolean switch to determine if the verification error throws exception
        rec_id : reconstruction id, pointing to alternate config
    """
    print ('starting post-processing')

    conf_list = ['config_disp', 'config_instr', 'config_data', 'config_mp']
    conf_maps, converted = com.get_config_maps(experiment_dir, conf_list, **kwargs)

    if 'config_disp' not in conf_maps.keys():
        print('exiting post-processing')
        raise FileNotFoundError('missing config_disp file, exiting')
    if 'config_instr' not in conf_maps.keys():
        print('exiting post-processing')
        raise FileNotFoundError('missing config_instr file, exiting')
    if 'config_data' not in conf_maps.keys():
        print('no config_data file')

    main_conf_map = conf_maps['config']

    if 'multipeak' in main_conf_map and main_conf_map['multipeak']:
        mp.process_dir(experiment_dir, conf_maps)
    else:
        separate = main_conf_map.get('separate_scans', False) or main_conf_map.get('separate_scan_ranges', False)
        rec_id = kwargs.get('rec_id', None)
        if 'results_dir' in conf_maps['config_disp']:
            results_dir = conf_maps['config_disp']['results_dir'].replace(os.sep, '/')
            if rec_id is not None and not results_dir.endswith(rec_id):
                print(f'Verify the results_directory. Currently set to {results_dir}')
            if separate and results_dir != experiment_dir:
                print(f'Verify the results_directory. Currently set to {results_dir}')
            if not os.path.isdir(results_dir):
                msg = f'the configured results_dir: {results_dir} does not exist'
                raise FileNotFoundError(msg)
        else:
            results_dir = ut.join(experiment_dir, 'results_phasing')

        # find directories with image.npy file in the root of results_dir
        scandirs = []
        for (dirpath, dirnames, filenames) in os.walk(results_dir):
            for file in filenames:
                if file.endswith('image.npy'):
                    scandirs.append((dirpath).replace(os.sep, '/'))
        if len(scandirs) == 0:
            print('exiting post-processing')
            msg = f'no image.npy files found in the directory tree {results_dir}'
            raise FileNotFoundError(msg)

        scans_dirs = []
        if separate:
            # the scan that will be used to derive geometry is determined from the scan directory
            # the code below finds the last scan
            for dir in scandirs:
                # go up dir until reaching scan dir
                scandir_path = dir.split('/')
                i = -1
                temp = scandir_path[i]
                while not temp.startswith('scan'):
                    i -= 1
                    temp = scandir_path[i]
                scan_subdir = temp
                scans_dirs.append((int(scan_subdir.split('_')[-1].split('-')[-1]), dir))
        else:
            last_scan = int(main_conf_map['scan'].split(',')[-1].split('-')[-1])
            scans_dirs = [[last_scan, dir] for dir in scandirs]

        if len(scans_dirs) == 1:
            result = [process_dir(conf_maps, scans_dirs[0])]
        else:
            func = partial(process_dir, conf_maps)
            no_proc = min(cpu_count(), len(scandirs))
            with ProcessPoolExecutor(max_workers=no_proc) as exe:
                # Maps the function with a iterable
                result = exe.map(func, scans_dirs)

        res = [r for r in result]
        df = pd.DataFrame(res)
        df.to_excel(ut.join(experiment_dir, 'visualization_results.xlsx'), index=False)

    print ('done with processing display')
    return ''


def main():
    """
    An entry function that takes command line parameters. It invokes the processing function handle_visualization with
    the parameters. The command line parameters: experiment directory, rec_id, --no_verify.
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("experiment_dir", help="experiment directory")
    parser.add_argument("--rec_id", action="store", help="alternate reconstruction id")
    parser.add_argument("--no_verify", action="store_true",
                        help="if True the verifier has no effect on processing, error is always printed when incorrect configuration")
    parser.add_argument("--debug", action="store_true",
                        help="not used currently, available to developer for debugging")
    args = parser.parse_args()
    handle_visualization(args.experiment_dir, rec_id=args.rec_id, no_verify=args.no_verify, debug=args.debug)


if __name__ == "__main__":
    main()

# python run_disp.py experiment_dir