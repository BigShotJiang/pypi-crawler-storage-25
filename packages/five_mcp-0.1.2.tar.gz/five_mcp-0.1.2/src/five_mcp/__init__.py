"""FIVE Character Engine – MCP Server package."""

__version__ = "0.1.2"
