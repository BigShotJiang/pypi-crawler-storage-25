"""
Data migration workflow initializer.

This module implements the workflow initializer for data migration workflows.
It creates the initial set of tasks for migrating tables from a source database
to Snowflake.
"""

import json

from typing import Any, TypeAlias, cast

from data_migration_orchestrator.cloud_core.constants.priorities import (
    DEFAULT_PRIORITY,
    PRIORITY_FOR_FAN_OUT_TASKS,
)
from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.snowflake_query_task import (
    SnowflakeQueryTaskPayload,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.tasks.task_builder import TaskBuilder
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.cloud_core.workflows.base_workflow_initializer import (
    BaseWorkflowInitializer,
)
from data_migration_orchestrator.cloud_core.workflows.workflow import Workflow
from data_migration_orchestrator.data_migration_cloud.config import (
    configuration_properties_keys,
)
from data_migration_orchestrator.data_migration_cloud.config.configuration_parser import (
    ConfigurationError,
    ConfigurationParser,
)
from data_migration_orchestrator.data_migration_cloud.config.sync_strategy import (
    SyncStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    DEFAULT_TARGET_TABLE_TYPE,
    ICEBERG_STRATEGY_CATALOG_LINK,
    ICEBERG_STRATEGY_CONVERT_TO_MANAGED,
    ICEBERG_STRATEGY_COPY_FILES,
    ICEBERG_TARGET_TABLE_TYPE,
    SNOWFLAKE_CATALOG,
    IcebergTargetConfig,
    LoadingStrategy,
    PartitionSizeConfig,
    TableConfiguration,
)
from data_migration_orchestrator.data_migration_cloud.config.workflow_configuration_schema import (
    validate_workflow_configuration,
)
from data_migration_orchestrator.data_migration_cloud.constants.stages import (
    default_internal_stage,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_platform import (
    BasePlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.platform_registry import (
    PlatformRegistry,
)
from data_migration_orchestrator.data_migration_cloud.scope import ScopeBuilder
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_reuse_service import (
    PartitionReuseService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    CreatePartitionTasksPayload,
    DataMovementTaskPayload,
    PreprocessingCheckPayload,
    ProcessStagedDataTaskPayload,
    SetupSnowpipePayload,
    TeardownSnowpipePayload,
)
from data_migration_orchestrator.data_migration_cloud.utils.pipe_utils import (
    build_pipe_name,
    build_snowpipe_stage_path,
)
from data_migration_orchestrator.data_migration_cloud.utils.snowpipe_event_table import (
    setup_snowpipe_for_data_migration,
)
from data_migration_orchestrator.data_migration_cloud.utils.stage_utils import (
    stage_path_for_object_type,
    stage_path_for_schema,
)
from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_migration_schema,
)
from data_migration_orchestrator.utils.snowflake_sql_utils import escape_sql_string
from shared.enums.source_type import SourceType
from shared.queries.object_type import build_object_type_query


# Per-table context after partition-strategy tasks are built: config, FQN, metadata id,
# preprocessing scope, source database/schema/table names, optional USE database command.
NewPartitionBatchTaskRow: TypeAlias = tuple[
    TableConfiguration,
    str,
    int,
    str,
    str,
    str,
    str,
    str | None,
]


logger = get_logger("data_migration_workflow_initializer")


class DataMigrationWorkflowInitializer(BaseWorkflowInitializer):
    """
    Workflow initializer for data migration workflows.

    This initializer creates the initial set of tasks for migrating tables
    from a source database to Snowflake. For each table in the workflow
    configuration, it creates:
    1. Metadata extraction task
    2. Schema extraction task
    3. Partition strategy determination task (blocked until 1 and 2 complete)

    The partition strategy task then dynamically creates extraction and
    loading tasks based on the table size and partitioning strategy.
    """

    def __init__(
        self,
        task_queue: BaseTaskQueue,
        warehouse_proxy: Warehouse,
        configuration_parser: ConfigurationParser | None = None,
    ):
        """
        Initialize the data migration workflow initializer.

        Args:
            task_queue: Task queue for pushing tasks
            warehouse_proxy: Proxy for executing warehouse operations
            configuration_parser: Parser for table configurations. If None, a default one is created.

        """
        super().__init__()
        self.task_queue = task_queue
        self.warehouse_proxy = warehouse_proxy
        self.configuration_parser = configuration_parser or ConfigurationParser()
        self.partition_reuse_service = PartitionReuseService(warehouse_proxy)

    async def create_initial_tasks(self, workflow: Workflow) -> None:
        """
        Create the initial tasks for a data migration workflow.

        Classifies each table (Iceberg, incremental reuse, or first-time migration),
        bulk-inserts migration ``TABLE_METADATA`` for tables that need new rows,
        then queues tasks using batch APIs where dependencies allow.

        Args:
            workflow: The workflow object containing configuration and metadata for
                     task creation, including tables to migrate, source platform,
                     target cloud type, and target cloud stage name.

        Raises:
            ConfigurationError: If the workflow configuration is missing or invalid

        """
        validate_workflow_configuration(workflow.configuration)

        configuration = workflow.configuration
        assert (
            configuration is not None
        )  # guaranteed by validate_workflow_configuration

        raw_tables_config = configuration.get(configuration_properties_keys.TABLES, [])

        # Extract default table configuration (optional)
        default_table_config = configuration.get(
            configuration_properties_keys.DEFAULT_TABLE_CONFIGURATION
        )

        source_platform = workflow.source_platform

        # Parse all table configurations using the ConfigurationParser
        # Each table config is merged with defaults before validation
        try:
            table_configurations = self.configuration_parser.parse_tables(
                raw_tables_config,
                default_config=default_table_config,
                source_platform=source_platform,
            )
        except ConfigurationError as e:
            logger.error(f"Invalid table configuration in workflow {workflow.id}: {e}")
            raise

        workflow_id = int(workflow.id)
        target_cloud_type = workflow.target_cloud_type
        platform = PlatformRegistry.create_by_name_or_alias(source_platform)

        iceberg_tables: list[TableConfiguration] = []
        incremental_specs: list[tuple[TableConfiguration, int]] = []
        new_tables: list[TableConfiguration] = []

        for table_config in table_configurations:
            fully_qualified_source_table_name = platform.build_normalized_table_name(
                table_config.source
            )
            logger.info(f"Creating tasks for {fully_qualified_source_table_name}.")

            if (
                table_config.target_table_type == ICEBERG_TARGET_TABLE_TYPE
                and table_config.iceberg_config
            ):
                iceberg_tables.append(table_config)
                continue

            # Only consult prior TABLE_METADATA when the workload genuinely
            # opts into incremental sync. ``SyncStrategy.NONE`` means "always
            # perform full partition extraction" (see ``sync_strategy.py``);
            # reusing stale metadata in that case would route the table
            # through the incremental branch even when the physical target
            # table no longer exists, re-introducing the Setup Snowpipe race
            # this fix is meant to prevent.
            existing_table_metadata_id: int | None = None
            if table_config.synchronization.strategy != SyncStrategy.NONE:
                existing_table_metadata_id = (
                    await self.partition_reuse_service.find_existing_table_metadata(
                        fully_qualified_source_table_name
                    )
                )
            if existing_table_metadata_id:
                incremental_specs.append((table_config, existing_table_metadata_id))
            else:
                new_tables.append(table_config)

        tables_needing_metadata_insert = iceberg_tables + new_tables
        id_by_source = await self._bulk_insert_table_metadata(
            workflow_id,
            source_platform,
            tables_needing_metadata_insert,
        )

        if new_tables:
            await self._batch_create_tasks_with_new_partitions(
                workflow_id,
                new_tables,
                source_platform,
                target_cloud_type,
                id_by_source,
            )

        for table_config in iceberg_tables:
            fq = platform.build_normalized_table_name(table_config.source)
            await self._create_iceberg_table_tasks(
                workflow_id=workflow_id,
                table_config=table_config,
                platform=platform,
                target_cloud_type=target_cloud_type,
                table_metadata_id=id_by_source[fq],
            )

        incremental_chains: list[tuple[Task[Any], Task[Any]]] = []
        for table_config, existing_table_metadata_id in incremental_specs:
            pair, new_table_metadata_id = (
                await self._incremental_sync_task_pair_or_fallback(
                    workflow_id=workflow_id,
                    table_config=table_config,
                    platform=platform,
                    target_cloud_type=target_cloud_type,
                    existing_table_metadata_id=existing_table_metadata_id,
                )
            )
            if pair is not None:
                incremental_chains.append(pair)

            # Record the NEW table_metadata_id (where the current extraction
            # actually writes) so snowpipe lifecycle tasks wire the pipe up to
            # the right stage path. Using the OLD existing_table_metadata_id
            # here would point the pipe at stale partition data that no task in
            # this workflow will ever touch.
            fq_source = platform.build_normalized_table_name(table_config.source)
            id_by_source[fq_source] = new_table_metadata_id

        if incremental_chains:
            await self.task_queue.push_independent_two_task_chains(incremental_chains)

        # Set up the database-scoped event table required by Snowpipe.
        # This is a no-op when no table uses snowpipe loading.
        if any(
            tc.loading_strategy == LoadingStrategy.SNOWPIPE
            for tc in table_configurations
        ):
            await setup_snowpipe_for_data_migration(self.warehouse_proxy)

        # Create Snowpipe lifecycle tasks for tables using snowpipe loading.
        #
        # New-table migrations only get the teardown task at init time;
        # ``Setup Snowpipe`` (CREATE PIPE) is queued later by
        # ``PartitionStrategyHandler`` with a ``Create target table``
        # predecessor — this avoids the race where CREATE PIPE runs before
        # the target table exists. Incremental sync tables are different:
        # the target already exists, so init queues setup immediately
        # (no race possible).
        incremental_source_fqns = {
            platform.build_normalized_table_name(tc.source)
            for tc, _ in incremental_specs
        }
        for table_config in table_configurations:
            if table_config.loading_strategy != LoadingStrategy.SNOWPIPE:
                continue
            fq_target = platform.build_target_table_name(table_config.target)
            fq_source = platform.build_normalized_table_name(table_config.source)
            table_metadata_id = id_by_source.get(fq_source)
            if table_metadata_id is None:
                continue

            await self._create_snowpipe_teardown_task(
                workflow_id=workflow_id,
                table_config=table_config,
                platform=platform,
                target_table=fq_target,
                table_metadata_id=table_metadata_id,
            )
            if fq_source in incremental_source_fqns:
                await self._create_snowpipe_setup_task_for_existing_table(
                    workflow_id=workflow_id,
                    table_config=table_config,
                    platform=platform,
                    target_table=fq_target,
                    table_metadata_id=table_metadata_id,
                )

    async def _create_snowpipe_teardown_task(
        self,
        workflow_id: int,
        table_config: TableConfiguration,
        platform: BasePlatform,
        target_table: str,
        table_metadata_id: int,
    ) -> None:
        """Queue DROP PIPE cleanup task. Always pushed at init time."""
        pipe_name = build_pipe_name(workflow_id, target_table)
        scope = ScopeBuilder.for_table(table_config.source, platform).preprocessing()

        teardown_task = (
            TaskBuilder(
                workflow_id=workflow_id,
                task_name=f"Teardown Snowpipe: {target_table}",
                executor_type=ExecutorType.ORCHESTRATOR,
                scope=f"{scope}::SnowpipeTeardown",
                payload=TeardownSnowpipePayload(pipe_name=pipe_name),
            )
            .blocked()
            .cleanup()
            .build()
        )
        await self.task_queue.push_task(teardown_task)
        logger.info(
            "Created Snowpipe teardown task for %s (pipe=%s)", target_table, pipe_name
        )

    async def _create_snowpipe_setup_task_for_existing_table(
        self,
        workflow_id: int,
        table_config: TableConfiguration,
        platform: BasePlatform,
        target_table: str,
        table_metadata_id: int,
    ) -> None:
        """
        Queue ``Setup Snowpipe`` at init time for an existing target table.

        Used ONLY for genuine incremental-sync tables (synchronization
        strategy != NONE) where prior ``TABLE_METADATA`` exists and the
        target table is therefore known to exist already. The handler still
        runs an idempotent ``CREATE TABLE IF NOT EXISTS`` before
        ``CREATE PIPE`` (no-op when the table is present), so the same
        race-free invariant holds whether we're new or incremental.

        For new-table snowpipe migrations, ``PartitionStrategyHandler``
        queues this task itself once schema extraction is on stage.
        """
        pipe_name = build_pipe_name(workflow_id, target_table)
        stage_path = build_snowpipe_stage_path(
            table_config, workflow_id, table_metadata_id
        )
        scope = ScopeBuilder.for_table(table_config.source, platform).preprocessing()

        setup_task = TaskBuilder(
            workflow_id=workflow_id,
            task_name=f"Setup Snowpipe: {target_table}",
            executor_type=ExecutorType.ORCHESTRATOR,
            scope=f"{scope}::SnowpipeSetup",
            payload=SetupSnowpipePayload(
                pipe_name=pipe_name,
                target_table=target_table,
                stage_path=stage_path,
                table_metadata_id=table_metadata_id,
            ),
        ).build()
        await self.task_queue.push_task(setup_task)
        logger.info(
            "Created Snowpipe setup task at init for existing table %s (pipe=%s)",
            target_table,
            pipe_name,
        )

    @staticmethod
    def _build_snowpipe_stage_path(
        table_config: TableConfiguration,
        workflow_id: int,
        table_metadata_id: int,
    ) -> str:
        """
        Build the stage path used in CREATE PIPE for a table.

        Thin wrapper around :func:`build_snowpipe_stage_path` from ``pipe_utils``;
        kept for backward compatibility with any external callers.
        """
        return build_snowpipe_stage_path(table_config, workflow_id, table_metadata_id)

    async def _create_tasks_for_table(
        self,
        workflow_id: int,
        table_config: TableConfiguration,
        source_platform: SourceType,
        target_cloud_type: str,
    ):
        """
        Create the task chain for table migration with metadata-driven partitioning.

        For incremental sync, if the table was previously migrated, we reuse the existing
        partition definitions (copying TABLE_METADATA and PARTITION_METADATA rows) and skip
        the boundary analysis phase. The SYNCHRONIZATION_DATA is preserved for incremental sync.

        Task Flow (first migration):
        1. Metadata Extraction (DATA_MOVEMENT) - Extracts table metadata (runs immediately)
        2. Schema Extraction (DATA_MOVEMENT) - Extracts table schema (runs in parallel with metadata)
        3. Partition Strategy (DETERMINE_PARTITION_STRATEGY) - Waits for BOTH metadata and schema, then:
           - Analyzes metadata to determine partitioning strategy
           - Creates extraction + load tasks based on table size
           - Small tables: Creates single EXTRACT -> LOAD chain
           - Large tables: Creates ANALYZE -> PROCESS_RESULTS -> N × [EXTRACT -> LOAD] chains
        4. Load tasks (PROCESS_STAGED_DATA) - Use the schema for type mappings during COPY INTO

        Task Flow (incremental sync with existing partitions):
        1. Schema Extraction (DATA_MOVEMENT) - Extracts table schema (still needed for type mappings)
        2. Create Extraction Tasks (CREATE_PARTITION_TASKS_FROM_EXISTING) - Uses existing partitions
           - Skips metadata extraction and boundary analysis
           - Reuses partition definitions from previous workflow
           - Preserves SYNCHRONIZATION_DATA for incremental filtering

        Args:
            workflow_id: The ID of the workflow.
            table_config: Parsed TableConfiguration object with source, target, and mappings
            source_platform: The source platform type (e.g., 'sqlserver')
            target_cloud_type: The target cloud type (e.g., 'snowflake:stage')

        """
        # Resolve the platform once and pass through to sub-methods
        platform = PlatformRegistry.create_by_name_or_alias(source_platform)

        # Extract table information from typed configuration
        fully_qualified_source_table_name = platform.build_normalized_table_name(
            table_config.source
        )
        logger.info(f"Creating tasks for {fully_qualified_source_table_name}.")

        # Check for existing table metadata from previous workflows (incremental sync)
        existing_table_metadata_id: int | None = (
            await self.partition_reuse_service.find_existing_table_metadata(
                fully_qualified_source_table_name
            )
        )

        # Route Iceberg targets to a dedicated task chain that avoids
        # ODBC extraction entirely -- the data is already on S3 as Parquet.
        if (
            table_config.target_table_type == ICEBERG_TARGET_TABLE_TYPE
            and table_config.iceberg_config
        ):
            id_map = await self._bulk_insert_table_metadata(
                workflow_id, source_platform, [table_config]
            )
            fq = platform.build_normalized_table_name(table_config.source)
            await self._create_iceberg_table_tasks(
                workflow_id=workflow_id,
                table_config=table_config,
                platform=platform,
                target_cloud_type=target_cloud_type,
                table_metadata_id=id_map[fq],
            )
        elif existing_table_metadata_id:
            await self._create_tasks_with_existing_partitions(
                workflow_id=workflow_id,
                table_config=table_config,
                platform=platform,
                target_cloud_type=target_cloud_type,
                existing_table_metadata_id=existing_table_metadata_id,
            )
        else:
            id_map = await self._bulk_insert_table_metadata(
                workflow_id, source_platform, [table_config]
            )
            await self._batch_create_tasks_with_new_partitions(
                workflow_id,
                [table_config],
                source_platform,
                target_cloud_type,
                id_map,
            )

    async def _create_tasks_with_existing_partitions(
        self,
        workflow_id: int,
        table_config: TableConfiguration,
        platform: BasePlatform,
        target_cloud_type: str,
        existing_table_metadata_id: int,
    ):
        """
        Create tasks using existing partition definitions (incremental sync).

        Copies TABLE_METADATA and PARTITION_METADATA from a previous workflow,
        preserving SYNCHRONIZATION_DATA for incremental filtering.

        Args:
            workflow_id: The ID of the workflow
            table_config: Parsed TableConfiguration object
            platform: The source platform instance
            target_cloud_type: The target cloud type
            existing_table_metadata_id: ID of existing TABLE_METADATA to copy from

        """
        pair, _new_table_metadata_id = (
            await self._incremental_sync_task_pair_or_fallback(
                workflow_id=workflow_id,
                table_config=table_config,
                platform=platform,
                target_cloud_type=target_cloud_type,
                existing_table_metadata_id=existing_table_metadata_id,
            )
        )
        if pair is not None:
            await self.task_queue.push_independent_two_task_chains([pair])

    async def _incremental_sync_task_pair_or_fallback(
        self,
        workflow_id: int,
        table_config: TableConfiguration,
        platform: BasePlatform,
        target_cloud_type: str,
        existing_table_metadata_id: int,
    ) -> tuple[tuple[Task[Any], Task[Any]] | None, int]:
        """
        Copy metadata/partitions and build (schema_extract, create_tasks) pair.

        Returns a tuple ``(pair, new_table_metadata_id)`` where:

        - ``pair`` is the ``(schema_extract, create_tasks)`` pair when partitions
          were successfully reused, or ``None`` if the copy failed and full
          preprocessing tasks were scheduled via the fallback path.
        - ``new_table_metadata_id`` is the metadata ID that the current
          extraction will write to (the freshly copied row on the reuse path,
          or the freshly inserted row on the fallback path).
        """
        fully_qualified_source_table_name = platform.build_normalized_table_name(
            table_config.source
        )

        logger.info(
            f"Reusing existing partitions from table_metadata_id={existing_table_metadata_id} "
            f"for {fully_qualified_source_table_name} (incremental sync)"
        )

        table_config_dict = self._serialize_table_configuration(table_config)
        table_config_json = escape_sql_string(json.dumps(table_config_dict))
        table_config_param = f"PARSE_JSON('{table_config_json}')"

        copied = await self.partition_reuse_service.copy_table_and_partitions(
            source_table_metadata_id=existing_table_metadata_id,
            new_workflow_id=workflow_id,
            table_configuration_sql=table_config_param,
        )

        if not copied:
            logger.warning(
                f"Failed to copy existing partitions for {fully_qualified_source_table_name}, "
                f"falling back to full preprocessing"
            )
            source_platform = platform.name
            table_metadata_id = await self._insert_table_metadata(
                workflow_id,
                fully_qualified_source_table_name,
                table_config,
            )
            if table_metadata_id is None:
                raise Exception(
                    f"Failed to insert table metadata for {fully_qualified_source_table_name}"
                )
            await self._batch_create_tasks_with_new_partitions(
                workflow_id,
                [table_config],
                source_platform,
                target_cloud_type,
                {fully_qualified_source_table_name: table_metadata_id},
            )
            return None, table_metadata_id

        logger.info(
            f"Copied {copied.partitions_copied} partition(s) with SYNCHRONIZATION_DATA "
            f"for {fully_qualified_source_table_name}"
        )

        fully_qualified_target_table_name = platform.build_target_table_name(
            table_config.target
        )

        source_database_name = table_config.source.database_name
        source_schema_name = table_config.source.schema_name
        source_table_name = table_config.source.table_name

        if source_database_name is None or source_schema_name is None:
            raise ConfigurationError(
                f"Source database and schema names must be provided for {fully_qualified_source_table_name}"
            )

        preprocessing_scope = ScopeBuilder.for_table(
            table_config.source, platform
        ).preprocessing()

        use_database_command = platform.query_builder.build_use_database_command(
            source_database_name
        )

        existing_partitions = (
            await self.partition_reuse_service.get_existing_partitions(
                copied.new_table_metadata_id
            )
        )

        schema_location = stage_path_for_schema(
            default_internal_stage(), workflow_id, copied.new_table_metadata_id
        )

        create_tasks_task = (
            TaskBuilder(
                workflow_id=workflow_id,
                executor_type=ExecutorType.ORCHESTRATOR,
                task_name=f"Create extraction tasks (reusing partitions): {fully_qualified_source_table_name}",
                scope=preprocessing_scope,
                payload=CreatePartitionTasksPayload(
                    database=source_database_name,
                    schema=source_schema_name,
                    table_name=source_table_name,
                    source_type=platform.name,
                    num_partitions=len(existing_partitions),
                    target_table=fully_qualified_target_table_name,
                    table_metadata_id=copied.new_table_metadata_id,
                ),
            )
            .with_priority(PRIORITY_FOR_FAN_OUT_TASKS)
            .blocked()
            .build()
        )

        schema_query = platform.query_builder.build_schema_query(table_config.source)
        schema_extract_task = TaskBuilder(
            workflow_id=workflow_id,
            executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
            task_name=f"Extract schema: {fully_qualified_source_table_name}",
            scope=preprocessing_scope,
            payload=DataMovementTaskPayload(
                database=source_database_name,
                schema=source_schema_name,
                source_type=platform.name,
                source_id="*",
                target_type=target_cloud_type,
                target_id=schema_location,
                statement_location_id=schema_query,
                use_database_command=use_database_command,
            ),
        ).build()

        logger.info(
            f"Prepared incremental sync tasks for {fully_qualified_source_table_name}: "
            f"schema extraction -> create partition tasks (reusing {copied.partitions_copied} partitions)"
        )
        return (schema_extract_task, create_tasks_task), copied.new_table_metadata_id

    @staticmethod
    def _resolve_iceberg_strategy(iceberg_config: IcebergTargetConfig) -> str:
        """
        Resolve the effective migration strategy for an Iceberg target.

        If ``migration_strategy`` is explicitly set, return it. Otherwise
        auto-detect from the catalog and source_data_stage values:
        - External catalog (not SNOWFLAKE) -> ``catalog_link``
        - SNOWFLAKE + sourceDataStage      -> ``copy_files``
        - SNOWFLAKE without sourceDataStage -> ``copy_files`` (DEA fallback)
        """
        if iceberg_config.migration_strategy:
            return iceberg_config.migration_strategy

        if iceberg_config.catalog.upper() != SNOWFLAKE_CATALOG:
            return ICEBERG_STRATEGY_CATALOG_LINK
        if not iceberg_config.source_data_stage:
            logger.warning(
                "Iceberg copy_files strategy auto-selected without sourceDataStage; "
                "falling back to DEA extraction pipeline. Set sourceDataStage or "
                "migrationStrategy explicitly to avoid this."
            )
        return ICEBERG_STRATEGY_COPY_FILES

    async def _create_iceberg_table_tasks(
        self,
        workflow_id: int,
        table_config: TableConfiguration,
        platform: BasePlatform,
        target_cloud_type: str,
        table_metadata_id: int,
    ):
        """
        Create the task chain for an Iceberg-to-Iceberg migration.

        ``table_metadata_id`` must already exist in ``TABLE_METADATA`` (caller bulk-inserts).

        Three strategies are supported, controlled by
        ``icebergConfig.migrationStrategy`` (auto-detected when absent):

        **catalog_link** (zero-copy, read-only):
        ``CREATE ICEBERG TABLE ... CATALOG = '<integration>'``

        **convert_to_managed** (zero-copy, full DML):
        Step 1 -- catalog link (as above).
        Step 2 -- ``ALTER ICEBERG TABLE ... CONVERT TO MANAGED``.

        **copy_files** (server-side binary copy, full DML):
        ``COPY INTO ... LOAD_MODE = ADD_FILES_COPY`` from the source data
        stage (or DEA-extracted files when ``sourceDataStage`` is absent).
        """
        iceberg_config = table_config.iceberg_config
        if iceberg_config is None:
            raise ValueError(
                "Iceberg target workflows require table_config.iceberg_config to be set"
            )

        fully_qualified_source = platform.build_normalized_table_name(
            table_config.source
        )
        fully_qualified_target = platform.build_target_table_name(
            table_config.target
        )

        strategy = self._resolve_iceberg_strategy(iceberg_config)

        preprocessing_scope = ScopeBuilder.for_table(
            table_config.source, platform
        ).preprocessing()

        if strategy == ICEBERG_STRATEGY_CATALOG_LINK:
            await self._create_iceberg_catalog_link_tasks(
                workflow_id,
                table_config,
                iceberg_config,
                fully_qualified_target,
                preprocessing_scope,
            )
        elif strategy == ICEBERG_STRATEGY_CONVERT_TO_MANAGED:
            await self._create_iceberg_convert_to_managed_tasks(
                workflow_id,
                table_config,
                iceberg_config,
                fully_qualified_target,
                preprocessing_scope,
            )
        elif strategy == ICEBERG_STRATEGY_COPY_FILES:
            await self._create_iceberg_copy_files_tasks(
                workflow_id,
                table_config,
                platform,
                iceberg_config,
                fully_qualified_source,
                fully_qualified_target,
                preprocessing_scope,
                target_cloud_type,
                table_metadata_id,
            )
        else:
            raise ConfigurationError(
                f"Unknown Iceberg migration strategy '{strategy}' "
                f"for {fully_qualified_target}"
            )

    @staticmethod
    def _build_catalog_link_ddl(
        fully_qualified_target: str,
        iceberg_config: IcebergTargetConfig,
        catalog_table_name: str,
    ) -> str:
        """
        Build CREATE ICEBERG TABLE DDL for catalog link strategy.

        Args:
            fully_qualified_target: Fully qualified target table name
            iceberg_config: Iceberg configuration
            catalog_table_name: Table name in the external catalog

        Returns:
            DDL statement for creating catalog-linked Iceberg table

        """
        ddl = (
            f"CREATE OR REPLACE ICEBERG TABLE {fully_qualified_target}\n"
            f"  CATALOG = '{iceberg_config.catalog}'\n"
            f"  CATALOG_TABLE_NAME = '{catalog_table_name}'"
        )
        if iceberg_config.external_volume:
            ddl += f"\n  EXTERNAL_VOLUME = '{iceberg_config.external_volume}'"
        return ddl

    async def _create_iceberg_catalog_link_tasks(
        self,
        workflow_id: int,
        table_config: TableConfiguration,
        iceberg_config: IcebergTargetConfig,
        fully_qualified_target: str,
        scope: str,
    ):
        """catalog_link: single DDL task -- zero-copy read-only."""
        catalog_table = (
            iceberg_config.catalog_table_name or table_config.source.table_name or ""
        )
        ddl = self._build_catalog_link_ddl(
            fully_qualified_target, iceberg_config, catalog_table
        )

        await self.warehouse_proxy.execute_snowflake_query_and_push_task(
            workflow_id,
            ddl,
            task_name=f"Create Iceberg table (catalog link): {fully_qualified_target}",
            scope=scope,
            priority=DEFAULT_PRIORITY,
        )

        logger.info(
            f"Iceberg [{ICEBERG_STRATEGY_CATALOG_LINK}]: created DDL task for {fully_qualified_target}"
        )

    async def _create_iceberg_convert_to_managed_tasks(
        self,
        workflow_id: int,
        table_config: TableConfiguration,
        iceberg_config: IcebergTargetConfig,
        fully_qualified_target: str,
        scope: str,
    ):
        """convert_to_managed: catalog link DDL + ALTER CONVERT TO MANAGED."""
        catalog_table = (
            iceberg_config.catalog_table_name or table_config.source.table_name or ""
        )
        create_ddl = self._build_catalog_link_ddl(
            fully_qualified_target, iceberg_config, catalog_table
        )

        alter_ddl = f"ALTER ICEBERG TABLE {fully_qualified_target} CONVERT TO MANAGED"

        # The ALTER is blocked until the CREATE completes
        alter_task = (
            TaskBuilder(
                workflow_id=workflow_id,
                task_name=f"Convert Iceberg table to managed: {fully_qualified_target}",
                executor_type=ExecutorType.WAREHOUSE,
                scope=scope,
                payload=SnowflakeQueryTaskPayload(query=alter_ddl),
            )
            .blocked()
            .build()
        )
        alter_task_id = await self.task_queue.push_task(alter_task)
        if alter_task_id is None:
            raise Exception(
                f"Failed to queue ALTER CONVERT TO MANAGED task "
                f"for {fully_qualified_target}"
            )

        # Fire the CREATE DDL immediately via the warehouse; when it completes,
        # the bookkeeping loop will unblock the ALTER task.
        await self.warehouse_proxy.execute_snowflake_query_and_push_task(
            workflow_id,
            create_ddl,
            task_name=f"Create Iceberg table (catalog link): {fully_qualified_target}",
            scope=scope,
            priority=DEFAULT_PRIORITY,
            successor_task_id=alter_task_id,
        )

        logger.info(
            f"Iceberg [{ICEBERG_STRATEGY_CONVERT_TO_MANAGED}]: created CREATE -> ALTER chain "
            f"for {fully_qualified_target}"
        )

    async def _create_iceberg_copy_files_tasks(
        self,
        workflow_id: int,
        table_config: TableConfiguration,
        platform: BasePlatform,
        iceberg_config: IcebergTargetConfig,
        fully_qualified_source: str,
        fully_qualified_target: str,
        preprocessing_scope: str,
        target_cloud_type: str,
        table_metadata_id: int,
    ):
        """copy_files: INFER_SCHEMA + CREATE TABLE + COPY INTO ADD_FILES_COPY."""
        loading_scope = (
            ScopeBuilder.for_table(table_config.source, platform).partition(0).loading()
        )

        if iceberg_config.source_data_stage:
            # Entire flow runs in Snowflake -- no DEA involvement.
            load_task = TaskBuilder(
                workflow_id=workflow_id,
                task_name=f"Create Iceberg table + COPY INTO: {fully_qualified_target}",
                executor_type=ExecutorType.ORCHESTRATOR,
                scope=loading_scope,
                payload=ProcessStagedDataTaskPayload(
                    table_metadata_id=table_metadata_id,
                    partition_metadata_id=0,
                    partition_index=0,
                    target_table=fully_qualified_target,
                ),
            ).build()
            await self.task_queue.push_task(load_task)

            logger.info(
                f"Iceberg [{ICEBERG_STRATEGY_COPY_FILES}]: created load task for "
                f"{fully_qualified_target} (INFER_SCHEMA, no DEA)"
            )
        else:
            # Fall back to DEA schema extraction, then load.
            source_database_name = table_config.source.database_name
            source_schema_name = table_config.source.schema_name

            if source_database_name is None or source_schema_name is None:
                raise ConfigurationError(
                    f"Source database and schema names must be provided "
                    f"for {fully_qualified_source}"
                )

            load_task = (
                TaskBuilder(
                    workflow_id=workflow_id,
                    task_name=f"Create Iceberg table + COPY INTO: {fully_qualified_target}",
                    executor_type=ExecutorType.ORCHESTRATOR,
                    scope=loading_scope,
                    payload=ProcessStagedDataTaskPayload(
                        table_metadata_id=table_metadata_id,
                        partition_metadata_id=0,
                        partition_index=0,
                        target_table=fully_qualified_target,
                    ),
                )
                .blocked()
                .build()
            )
            load_task_id = await self.task_queue.push_task(load_task)
            if load_task_id is None:
                raise Exception(
                    f"Failed to queue Iceberg load task for {fully_qualified_target}"
                )

            schema_location = stage_path_for_schema(
                default_internal_stage(), workflow_id, table_metadata_id
            )
            use_database_command = platform.query_builder.build_use_database_command(
                source_database_name
            )
            qb = platform.query_builder
            if hasattr(qb, "build_external_table_schema_query"):
                schema_query = cast(Any, qb).build_external_table_schema_query(
                    table_config.source
                )
            else:
                schema_query = qb.build_schema_query(table_config.source)

            schema_task = (
                TaskBuilder(
                    workflow_id=workflow_id,
                    task_name=f"Extract schema (Iceberg): {fully_qualified_source}",
                    executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
                    scope=preprocessing_scope,
                    payload=DataMovementTaskPayload(
                        database=source_database_name,
                        schema=source_schema_name,
                        source_type=platform.name,
                        source_id="*",
                        target_type=target_cloud_type,
                        target_id=schema_location,
                        statement_location_id=schema_query,
                        use_database_command=use_database_command,
                    ),
                )
                .with_successor(load_task_id)
                .build()
            )
            await self.task_queue.push_task(schema_task)

            logger.info(
                f"Iceberg [{ICEBERG_STRATEGY_COPY_FILES}]: created schema extraction -> "
                f"load task chain for {fully_qualified_target}"
            )

    async def _batch_create_tasks_with_new_partitions(
        self,
        workflow_id: int,
        table_configs: list[TableConfiguration],
        source_platform: SourceType,
        target_cloud_type: str,
        id_by_source: dict[str, int],
    ) -> None:
        """
        Create two-phase preprocessing tasks for first-time migrations.

        Phase 1 (created here):
            [Extract Object Type (DEA)] -> [Preprocessing Check (Orchestrator)]

        Phase 2 (created dynamically by PreprocessingCheckHandler when phase 1 passes):
            [Extract Metadata (DEA)] + [Extract Schema (DEA)] -> [Partition Strategy (Orchestrator)]
        """
        if not table_configs:
            return

        platform = PlatformRegistry.create_by_name_or_alias(source_platform)
        source_type_enum = SourceType.from_string(source_platform)

        preprocessing_check_tasks: list[Task[Any]] = []
        table_order_meta: list[NewPartitionBatchTaskRow] = []

        for table_config in table_configs:
            fully_qualified_source_table_name = platform.build_normalized_table_name(
                table_config.source
            )
            fully_qualified_target_table_name = platform.build_target_table_name(
                table_config.target
            )
            source_database_name = table_config.source.database_name
            source_schema_name = table_config.source.schema_name
            source_table_name = table_config.source.table_name

            if source_database_name is None or source_schema_name is None:
                raise ConfigurationError(
                    "Source database and schema names must be provided for "
                    f"{fully_qualified_source_table_name}"
                )

            table_metadata_id = id_by_source[fully_qualified_source_table_name]
            preprocessing_scope = ScopeBuilder.for_table(
                table_config.source, platform
            ).preprocessing()

            preprocessing_check_tasks.append(
                TaskBuilder(
                    workflow_id=workflow_id,
                    task_name=(
                        f"Preprocessing check: {fully_qualified_source_table_name}"
                    ),
                    executor_type=ExecutorType.ORCHESTRATOR,
                    scope=preprocessing_scope,
                    payload=PreprocessingCheckPayload(
                        database=source_database_name,
                        schema=source_schema_name,
                        table_name=source_table_name,
                        source_type=platform.name,
                        target_table=fully_qualified_target_table_name,
                        target_cloud_type=target_cloud_type,
                        table_metadata_id=table_metadata_id,
                    ),
                )
                .blocked()
                .build()
            )

            use_db = platform.query_builder.build_use_database_command(
                source_database_name
            )
            table_order_meta.append(
                (
                    table_config,
                    fully_qualified_source_table_name,
                    table_metadata_id,
                    preprocessing_scope,
                    source_database_name,
                    source_schema_name,
                    source_table_name,
                    use_db,
                )
            )

        check_ids = await self.task_queue.push_tasks_batch(preprocessing_check_tasks)

        object_type_tasks: list[Task[Any]] = []
        for i, row in enumerate(table_order_meta):
            (
                table_config,
                fully_qualified_source_table_name,
                table_metadata_id,
                preprocessing_scope,
                source_database_name,
                source_schema_name,
                source_table_name,
                use_database_command,
            ) = row
            check_id = check_ids[i]

            object_type_location = stage_path_for_object_type(
                default_internal_stage(), workflow_id, table_metadata_id
            )
            object_type_query = build_object_type_query(
                source_type_enum,
                source_database_name,
                source_schema_name,
                source_table_name,
            )

            object_type_tasks.append(
                TaskBuilder(
                    workflow_id=workflow_id,
                    task_name=f"Extract object type: {fully_qualified_source_table_name}",
                    executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
                    scope=preprocessing_scope,
                    payload=DataMovementTaskPayload(
                        database=source_database_name,
                        schema=source_schema_name,
                        source_type=platform.name,
                        source_id="*",
                        target_type=target_cloud_type,
                        target_id=object_type_location,
                        statement_location_id=object_type_query,
                        use_database_command=use_database_command,
                    ),
                )
                .with_successor(check_id)
                .build()
            )

        await self.task_queue.push_tasks_batch(object_type_tasks)

    async def _bulk_insert_table_metadata(
        self,
        workflow_id: int,
        source_platform: SourceType,
        table_configs: list[TableConfiguration],
    ) -> dict[str, int]:
        """Insert all TABLE_METADATA rows in one statement; return ID by source identifier."""
        if not table_configs:
            return {}

        qm = qualified_migration_schema()
        seq = f"{qm}.TABLE_METADATA_ID_SEQ"
        platform = PlatformRegistry.create_by_name_or_alias(source_platform)
        select_rows: list[str] = []
        source_identifiers: list[str] = []

        for tc in table_configs:
            src = platform.build_normalized_table_name(tc.source)
            source_identifiers.append(src)
            cfg_dict = self._serialize_table_configuration(tc)
            cfg_json = escape_sql_string(json.dumps(cfg_dict))
            select_rows.append(
                f"SELECT {seq}.NEXTVAL AS NEW_ID, "
                f"{workflow_id} AS WORKFLOW_ID, "
                f"'{escape_sql_string(src)}' AS SOURCE_IDENTIFIER, "
                f"PARSE_JSON('{cfg_json}') AS TABLE_CONFIGURATION, "
                f"FALSE AS HAS_BEEN_PREPROCESSED"
            )

        source_union = " UNION ALL ".join(select_rows)
        insert_sql = (
            f"INSERT INTO {qm}.TABLE_METADATA "
            f"(ID, WORKFLOW_ID, SOURCE_IDENTIFIER, TABLE_CONFIGURATION, HAS_BEEN_PREPROCESSED) "
            f"SELECT NEW_ID, WORKFLOW_ID, SOURCE_IDENTIFIER, TABLE_CONFIGURATION, "
            f"HAS_BEEN_PREPROCESSED FROM ({source_union}) AS bulk_rows"
        )
        await self.warehouse_proxy.execute_sync_query(insert_sql)

        escaped_identifiers = ", ".join(
            f"'{escape_sql_string(s)}'" for s in source_identifiers
        )
        select_sql = (
            f"SELECT ID, SOURCE_IDENTIFIER FROM {qm}.TABLE_METADATA "
            f"WHERE WORKFLOW_ID = {workflow_id} "
            f"AND SOURCE_IDENTIFIER IN ({escaped_identifiers})"
        )
        rows = await self.warehouse_proxy.execute_sync_query(select_sql)

        id_by_source: dict[str, int] = {}
        for row in rows:
            id_by_source[row["SOURCE_IDENTIFIER"]] = int(row["ID"])

        for src in source_identifiers:
            if src not in id_by_source:
                raise RuntimeError(
                    f"TABLE_METADATA row not found after bulk insert for {src}"
                )

        logger.info(
            "Bulk-inserted %d TABLE_METADATA row(s) for workflow %d",
            len(source_identifiers),
            workflow_id,
        )
        return id_by_source

    async def _insert_table_metadata(
        self,
        workflow_id: int,
        source_identifier: str,
        table_config: TableConfiguration,
    ) -> int | None:
        """
        Insert a table metadata record and return its ID.

        Args:
            workflow_id: The workflow ID
            source_identifier: Fully qualified source table name (must be normalized)
            table_config: The full table configuration to store

        Returns:
            The ID of the inserted table metadata record, or None if insertion failed

        """
        try:
            # Escape single quotes in the source identifier
            escaped_identifier = escape_sql_string(source_identifier)

            # Serialize full TableConfiguration as JSON for TABLE_CONFIGURATION column
            table_config_dict = self._serialize_table_configuration(table_config)
            table_config_json = escape_sql_string(json.dumps(table_config_dict))
            table_config_param = f"PARSE_JSON('{table_config_json}')"

            query = (
                f"CALL {qualified_migration_schema()}.INSERT_TABLE_METADATA("
                f"{workflow_id}, '{escaped_identifier}', {table_config_param})"
            )
            result = await self.warehouse_proxy.execute_sync_query(query)
            if (
                result and len(result) > 0
            ):  # TODO: Get scalar value instead of list of rows
                # The stored procedure returns the new ID as the first (and only) column
                first_row = result[0]
                table_metadata_id = next(iter(first_row.values()), None)
                logger.info(
                    f"Inserted table metadata for {source_identifier} with ID {table_metadata_id}"
                )
                return table_metadata_id
            return None
        except Exception as e:
            logger.error(
                f"Failed to insert table metadata for {source_identifier}: {e}"
            )
            return None

    def _serialize_table_configuration(self, table_config: TableConfiguration) -> dict:
        """
        Serialize a TableConfiguration to a dictionary for JSON storage.

        Args:
            table_config: The table configuration to serialize

        Returns:
            Dictionary representation suitable for JSON serialization

        """
        return {
            configuration_properties_keys.SOURCE: {
                configuration_properties_keys.DATABASE_NAME: table_config.source.database_name,
                configuration_properties_keys.SCHEMA_NAME: table_config.source.schema_name,
                configuration_properties_keys.TABLE_NAME: table_config.source.table_name,
            },
            configuration_properties_keys.TARGET: self._serialize_target_endpoint(
                table_config
            ),
            configuration_properties_keys.COLUMN_NAMES_TO_PARTITION_BY: table_config.partition_columns,
            configuration_properties_keys.COLUMN_TYPE_MAPPINGS: table_config.column_type_mappings,
            configuration_properties_keys.COLUMN_NAME_MAPPINGS: table_config.column_name_mappings,
            configuration_properties_keys.PRIMARY_KEY_COLUMNS: table_config.primary_key_columns,
            configuration_properties_keys.SYNCHRONIZATION: {
                configuration_properties_keys.STRATEGY: table_config.synchronization.strategy.value,
                configuration_properties_keys.WATERMARK_COLUMN: table_config.synchronization.watermark_column,
                configuration_properties_keys.TRACK_MODIFICATIONS: table_config.synchronization.track_modifications,
            },
            configuration_properties_keys.EXTRACTION: {
                configuration_properties_keys.STRATEGY: table_config.extraction.strategy.value,
                configuration_properties_keys.EXTERNAL_STAGE: table_config.extraction.external_stage,
            },
            configuration_properties_keys.LOADING: {
                configuration_properties_keys.STRATEGY: table_config.loading.strategy.value,
            },
            **self._serialize_partition_size(table_config.partition_size),
            configuration_properties_keys.WHERE_CLAUSE_CRITERIA: table_config.where_clause_criteria,
            configuration_properties_keys.LOAD_SEGMENTATION: (
                {
                    configuration_properties_keys.TARGET_SEGMENT_SIZE_MB: table_config.load_segmentation.target_segment_size_mb,
                }
                if table_config.load_segmentation is not None
                else None
            ),
        }

    @staticmethod
    def _serialize_target_endpoint(table_config: TableConfiguration) -> dict:
        """Serialize the target endpoint including Iceberg fields."""
        target: dict = {
            configuration_properties_keys.DATABASE_NAME: table_config.target.database_name,
            configuration_properties_keys.SCHEMA_NAME: table_config.target.schema_name,
            configuration_properties_keys.TABLE_NAME: table_config.target.table_name,
        }

        if table_config.target_table_type != DEFAULT_TARGET_TABLE_TYPE:
            target[configuration_properties_keys.TABLE_TYPE] = (
                table_config.target_table_type
            )

        if table_config.iceberg_config is not None:
            ic = table_config.iceberg_config
            iceberg_dict: dict = {
                configuration_properties_keys.CATALOG: ic.catalog,
            }
            if ic.external_volume is not None:
                iceberg_dict[configuration_properties_keys.EXTERNAL_VOLUME] = (
                    ic.external_volume
                )
            if ic.base_location_prefix is not None:
                iceberg_dict[configuration_properties_keys.BASE_LOCATION_PREFIX] = (
                    ic.base_location_prefix
                )
            if ic.catalog_table_name is not None:
                iceberg_dict[configuration_properties_keys.CATALOG_TABLE_NAME] = (
                    ic.catalog_table_name
                )
            if ic.catalog_sync is not None:
                iceberg_dict[configuration_properties_keys.CATALOG_SYNC] = (
                    ic.catalog_sync
                )
            if ic.source_data_stage is not None:
                iceberg_dict[configuration_properties_keys.SOURCE_DATA_STAGE] = (
                    ic.source_data_stage
                )
            if ic.migration_strategy is not None:
                iceberg_dict[configuration_properties_keys.MIGRATION_STRATEGY] = (
                    ic.migration_strategy
                )
            target[configuration_properties_keys.ICEBERG_CONFIG] = iceberg_dict

        return target

    @staticmethod
    def _serialize_partition_size(
        partition_size: PartitionSizeConfig,
    ) -> dict:
        """Serialize ``PartitionSizeConfig`` as flat fields for JSON storage."""
        result: dict = {}
        if partition_size.target_size_mb is not None:
            result[configuration_properties_keys.TARGET_PARTITION_SIZE_MB] = (
                partition_size.target_size_mb
            )
        if partition_size.target_size_rows is not None:
            result[configuration_properties_keys.TARGET_PARTITION_SIZE_ROWS] = (
                partition_size.target_size_rows
            )
        return result
