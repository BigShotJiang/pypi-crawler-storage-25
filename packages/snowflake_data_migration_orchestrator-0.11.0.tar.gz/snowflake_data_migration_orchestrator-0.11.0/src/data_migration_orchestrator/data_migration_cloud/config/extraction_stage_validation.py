"""
Validation for WRITE_NOS / UNLOAD external stage auto-provisioning settings.

Rejects obvious documentation placeholders so Snowflake does not execute
``CREATE STAGE ... STORAGE_INTEGRATION = REPLACE_WITH_...``.
"""

import re


_PLACEHOLDER_STORAGE_INTEGRATION = re.compile(
    r"(REPLACE\s*(_WITH)?|<.*?>|TODO|TBD|CHANGE(_ME)?|PLACEHOLDER|\bEXAMPLE\b)",
    re.IGNORECASE,
)

_INTEGRATION_ERROR_PATTERN = re.compile(
    r"Integration\s+'([^']+)'\s+does not exist or not authorized",
    re.IGNORECASE,
)


def explain_if_integration_access_failure(exc: BaseException) -> str | None:
    """
    If *exc* is a Snowflake external-stage integration error, return remediation text.

    Runtime paths wrap connector errors in ``RuntimeError``; this inspects ``str(exc)``.

    """
    text = str(exc)
    if "002003" not in text or "Integration" not in text:
        return None
    if "does not exist or not authorized" not in text.lower():
        return None
    m = _INTEGRATION_ERROR_PATTERN.search(text)
    name = m.group(1) if m else None
    if name:
        grant_line = (
            f"GRANT USAGE ON INTEGRATION {name} TO ROLE <your_orchestrator_role>; "
        )
    else:
        grant_line = (
            "GRANT USAGE ON INTEGRATION <integration_name> TO ROLE "
            "<your_orchestrator_role>; "
        )
    show_grants_line = (
        f"SHOW GRANTS ON INTEGRATION {name}; "
        if name
        else "SHOW GRANTS ON INTEGRATION <name>; "
    )
    return (
        "Snowflake rejected access to the external stage (error 002003): the stage's "
        "STORAGE_INTEGRATION name is wrong, the integration was dropped, or — most often — "
        "your current role lacks USAGE ON INTEGRATION (Snowflake uses the same message for "
        "missing vs unauthorized). "
        f"Integration referenced: {repr(name) if name else 'unknown'}. "
        f"Verify with SHOW INTEGRATIONS IN ACCOUNT; check grants with {show_grants_line}"
        f"then {grant_line}"
        "Or recreate the stage: CREATE STAGE ... URL='s3://bucket/' "
        "STORAGE_INTEGRATION=<valid_integration> matching the Teradata WRITE_NOS bucket."
    )


def explain_if_aws_role_assumption_failure(exc: BaseException) -> str | None:
    """Snowflake 003167: IAM refused sts:AssumeRole for the STORAGE INTEGRATION role."""
    text = str(exc)
    if "003167" not in text and "Error assuming AWS_ROLE" not in text:
        return None
    if "AssumeRole" not in text:
        return None
    role_m = re.search(r"(arn:aws:iam::\d+:role/[^\s]+)", text)
    role = role_m.group(1) if role_m else None
    role_hint = f" Role ARN from error: {role}." if role else ""
    user_m = re.search(
        r"User:\s+(arn:aws:iam::(\d+):(?:user|role)/[^\s]+)",
        text,
    )
    cross_account = ""
    if user_m and role:
        user_arn = user_m.group(1)
        user_acct = user_m.group(2)
        role_acct_m = re.search(r"arn:aws:iam::(\d+):role/", role)
        if role_acct_m and user_acct != role_acct_m.group(1):
            cross_account = (
                f" Cross-account: Snowflake's IAM principal is {user_arn} (account {user_acct}); "
                f"the storage role is in AWS account {role_acct_m.group(1)}. In that account, "
                "edit the role trust policy so sts:AssumeRole is allowed for that Snowflake user "
                "ARN, with ExternalId set to STORAGE_AWS_EXTERNAL_ID from DESC INTEGRATION "
                "(must match Snowflake's value for this integration). "
            )
    return (
        "Snowflake cannot read S3 through this external stage: AWS denied sts:AssumeRole "
        "for the IAM role linked to the stage's STORAGE INTEGRATION."
        f"{role_hint}{cross_account}"
        "Fix in AWS IAM: the role's trust policy must allow Snowflake to assume it "
        "(correct external ID / Snowflake IAM user per Snowflake storage integration docs). "
        "Or recreate DESC STAGE / DESC INTEGRATION and align STORAGE_AWS_ROLE_ARN with a "
        "role whose trust policy matches your Snowflake account's integration."
    )


def explain_external_stage_access_failure(exc: BaseException) -> str | None:
    """Return remediation text for common Snowflake external-stage access errors, if any."""
    return explain_if_integration_access_failure(
        exc
    ) or explain_if_aws_role_assumption_failure(exc)


def storage_integration_looks_like_placeholder(value: str) -> bool:
    """Return True if *value* looks like a template rather than a real identifier."""
    s = value.strip()
    if not s:
        return True
    return bool(_PLACEHOLDER_STORAGE_INTEGRATION.search(s))


def reject_placeholder_storage_integration(value: str, *, context: str) -> None:
    """
    Raise ValueError if *value* is empty or looks like documentation filler.

    Args:
        value: Snowflake storage integration name from workflow JSON.
        context: Short description for the error (e.g. table name or 'workflow default').

    """
    if storage_integration_looks_like_placeholder(value):
        raise ValueError(
            f"externalStageStorageIntegration ({context}) must be a real Snowflake "
            "storage integration name (run SHOW INTEGRATIONS IN ACCOUNT). "
            f"Rejecting value: {value.strip()!r}"
        )
