from enum import StrEnum
from typing import Self


class ExtractionStrategy(StrEnum):
    """
    Extraction strategies for data migration.

    Determines how data is extracted from the source database.
    - REGULAR: Regular extraction strategy (default). Worker-side bulk tools
      that need no orchestrator config (e.g. SQL Server BCP, Teradata TPT when
      ``tpt_*`` is set on the DEA connection) also use this strategy.
    - UNLOAD: Unload strategy (Redshift -> S3 via UNLOAD command)
    - WRITE_NOS: Teradata WRITE_NOS strategy (Teradata -> S3/Azure/GCS via
      the WRITE_NOS table function)
    """

    REGULAR = "regular"
    UNLOAD = "unload"
    WRITE_NOS = "write_nos"

    @classmethod
    def from_string(cls, extraction_strategy: str) -> Self:
        """
        Convert string to ExtractionStrategy enum.

        The legacy workflow value ``tpt`` is accepted and mapped to :attr:`REGULAR`
        (Teradata TPT is selected on the worker from DEA connection config).

        Args:
            extraction_strategy: String representation of the extraction strategy

        Returns:
            ExtractionStrategy enum value

        """
        normalized = extraction_strategy.lower().strip()
        # Workflows may still emit ``tpt``; orchestration uses REGULAR and the DEA
        # picks TPT from connection ``tpt_*`` settings (see class docstring).
        if normalized == "tpt":
            return cls.REGULAR
        return cls(normalized)


# Default extraction strategy (full data extraction)
DEFAULT_EXTRACTION_STRATEGY = ExtractionStrategy.REGULAR
