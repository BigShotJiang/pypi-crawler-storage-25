"""Data models for table configuration in workflow definitions."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Self

from data_migration_orchestrator.data_migration_cloud.config import (
    configuration_properties_keys as _keys,
)
from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    DEFAULT_EXTRACTION_STRATEGY,
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.sync_strategy import (
    DEFAULT_SYNCHRONIZATION_STRATEGY,
    SyncStrategy,
)


@dataclass(frozen=True)
class ExtractionConfig:
    """
    Configuration for extraction strategy of a table.

    Uses a tagged union pattern where the 'strategy' field determines which
    additional fields are relevant.

    Attributes:
        strategy: The extraction strategy to use (REGULAR, UNLOAD, WRITE_NOS).
            Defaults to REGULAR.
        external_stage: Fully-qualified Snowflake external stage for UNLOAD and
            WRITE_NOS. URL and storage integration are defined on the stage in
            Snowflake (``DESC STAGE``); workflow JSON must not duplicate them.

    """

    strategy: ExtractionStrategy = DEFAULT_EXTRACTION_STRATEGY

    # Fields for UNLOAD / WRITE_NOS strategies
    external_stage: str | None = None


@dataclass(frozen=True)
class SynchronizationConfig:
    """
    Configuration for incremental synchronization of a table.

    Attributes:
        strategy: The synchronization strategy to use (NONE, CHECKSUM, WATERMARK, etc.)
            Defaults to NONE (no incremental sync, always full partition extraction).
        watermark_column: Column name to use for watermark-based sync (required for WATERMARK strategy)
        track_modifications: Whether to track and deduplicate modified rows (WATERMARK strategy only).
            When True, requires primary_key_columns to be set on the table configuration.

    """

    strategy: SyncStrategy = DEFAULT_SYNCHRONIZATION_STRATEGY

    # Fields for CHECKSUM strategy
    # N/A

    # Fields for WATERMARK strategy
    watermark_column: str | None = None
    track_modifications: bool = False

    # Fields for CHANGE_TRACKING strategy
    # TODO(SNOW-3067427)


class LoadingStrategy(StrEnum):
    """Strategy for loading data into the target table."""

    WAREHOUSE = "warehouse"
    SNOWPIPE = "snowpipe"

    @classmethod
    def from_string(cls, value: str) -> Self:
        """Convert string to LoadingStrategy enum."""
        return cls(value.lower())


DEFAULT_LOADING_STRATEGY = LoadingStrategy.WAREHOUSE


@dataclass(frozen=True)
class LoadingConfig:
    """
    Configuration for loading strategy of a table.

    Attributes:
        strategy: The loading strategy to use (WAREHOUSE, SNOWPIPE).
            Defaults to WAREHOUSE (standard COPY INTO).

    """

    strategy: LoadingStrategy = DEFAULT_LOADING_STRATEGY


class TargetTableType(StrEnum):
    """Target table type for data migration."""

    NATIVE = "native"
    ICEBERG = "iceberg"

    @classmethod
    def from_string(cls, value: str) -> Self:
        """Convert string to TargetTableType enum."""
        return cls(value.lower())


DEFAULT_TARGET_TABLE_TYPE = TargetTableType.NATIVE
ICEBERG_TARGET_TABLE_TYPE = TargetTableType.ICEBERG


class IcebergMigrationStrategy(StrEnum):
    """Migration strategy for Iceberg table targets."""

    CATALOG_LINK = "catalog_link"
    CONVERT_TO_MANAGED = "convert_to_managed"
    COPY_FILES = "copy_files"

    @classmethod
    def from_string(cls, value: str) -> Self:
        """Convert string to IcebergMigrationStrategy enum."""
        return cls(value.lower())


# Backwards-compatible aliases
ICEBERG_STRATEGY_CATALOG_LINK = IcebergMigrationStrategy.CATALOG_LINK
ICEBERG_STRATEGY_CONVERT_TO_MANAGED = IcebergMigrationStrategy.CONVERT_TO_MANAGED
ICEBERG_STRATEGY_COPY_FILES = IcebergMigrationStrategy.COPY_FILES
VALID_ICEBERG_STRATEGIES = frozenset(IcebergMigrationStrategy)


# Well-known Iceberg catalog name for Snowflake-managed tables
SNOWFLAKE_CATALOG = "SNOWFLAKE"


@dataclass(frozen=True)
class IcebergTargetConfig:
    """
    Configuration for Iceberg table targets in Snowflake.

    Attributes:
        catalog: The Iceberg catalog to use. ``"SNOWFLAKE"`` for Snowflake-managed
            Iceberg tables, or the name of a catalog integration for externally
            managed tables (e.g., a Glue catalog integration).
        external_volume: Name of the Snowflake external volume where Iceberg
            data and metadata files are stored.
        base_location_prefix: Relative path prefix on the external volume.
            The table name is appended automatically to form the full base location.
        catalog_table_name: The table name in the external catalog.
            Required when using an external catalog integration.
        catalog_sync: Optional catalog integration name to sync Snowflake-managed
            Iceberg metadata back to an external catalog (e.g., Glue).
        source_data_stage: Snowflake external stage pointing to the S3 location
            of existing Iceberg Parquet data files. When set, the orchestrator
            skips ODBC/UNLOAD extraction and uses ``COPY INTO`` directly from
            this stage. Only relevant for Snowflake-managed Iceberg targets
            (``catalog='SNOWFLAKE'``).
        migration_strategy: How to create the target Iceberg table. When
            ``None``, the strategy is auto-detected from the catalog and
            ``source_data_stage`` values. Accepted values:
            - ``"catalog_link"``: zero-copy read-only link via external catalog.
            - ``"convert_to_managed"``: create catalog-linked table then
              ``ALTER ICEBERG TABLE ... CONVERT TO MANAGED`` (zero-copy, full DML).
            - ``"copy_files"``: ``COPY INTO ... LOAD_MODE = ADD_FILES_COPY``
              (server-side binary copy, full DML).

    """

    catalog: str = SNOWFLAKE_CATALOG
    external_volume: str | None = None
    base_location_prefix: str | None = None
    catalog_table_name: str | None = None
    catalog_sync: str | None = None
    source_data_stage: str | None = None
    migration_strategy: str | None = None

    def __post_init__(self):
        """Validate migration_strategy if explicitly provided."""
        if (
            self.migration_strategy is not None
            and self.migration_strategy not in VALID_ICEBERG_STRATEGIES
        ):
            raise ValueError(
                f"Invalid migration_strategy '{self.migration_strategy}'. "
                f"Valid options: {', '.join(sorted(VALID_ICEBERG_STRATEGIES))}"
            )

    @classmethod
    def from_dict(cls, iceberg_dict: dict) -> IcebergTargetConfig:
        """
        Parse an Iceberg configuration from a raw dictionary.

        Shared by both ``ConfigurationParser`` (user input) and
        ``TableConfigurationService`` (stored DB data) to guarantee
        consistent parsing behaviour.

        Args:
            iceberg_dict: Raw dictionary with camelCase keys matching
                ``configuration_properties_keys`` constants.

        Returns:
            A validated ``IcebergTargetConfig`` instance.

        """
        return cls(
            catalog=iceberg_dict.get(_keys.CATALOG, SNOWFLAKE_CATALOG),
            external_volume=iceberg_dict.get(_keys.EXTERNAL_VOLUME),
            base_location_prefix=iceberg_dict.get(_keys.BASE_LOCATION_PREFIX),
            catalog_table_name=iceberg_dict.get(_keys.CATALOG_TABLE_NAME),
            catalog_sync=iceberg_dict.get(_keys.CATALOG_SYNC),
            source_data_stage=iceberg_dict.get(_keys.SOURCE_DATA_STAGE),
            migration_strategy=iceberg_dict.get(_keys.MIGRATION_STRATEGY),
        )


@dataclass(frozen=True)
class LoadSegmentationConfig:
    """
    Configuration for post-upload load segmentation.

    When configured, the orchestrator splits a single COPY INTO into multiple
    COPY INTO statements, each targeting a subset of staged files. This is
    useful when many files have been uploaded to a stage directory (e.g. via
    Redshift UNLOAD) and loading them in a single statement would be too slow
    or hit resource limits.

    Attributes:
        target_segment_size_mb: Target total file size (in MB) per COPY INTO
            segment. The orchestrator groups files greedily until this size is
            reached, then starts a new segment.

    """

    target_segment_size_mb: int


@dataclass(frozen=True)
class PartitionSizeConfig:
    """
    User-facing partition size configuration.

    Supports three modes:
    - Auto (default): Both fields are None. The system selects optimal partition
      parameters based on platform, extraction strategy, and table size.
    - Fixed MB: ``target_size_mb`` is set. Each partition targets this size.
    - Fixed rows: ``target_size_rows`` is set. Each partition targets this
      row count, regardless of data size.

    Only one of ``target_size_mb`` or ``target_size_rows`` may be set.

    """

    target_size_mb: int | None = None
    target_size_rows: int | None = None

    @property
    def is_auto(self) -> bool:
        """Return True when the system should pick partition parameters automatically."""
        return self.target_size_mb is None and self.target_size_rows is None


def parse_partition_size(
    target_size_mb: int | None,
    target_size_rows: int | None,
    *,
    strict: bool = True,
) -> PartitionSizeConfig:
    """
    Build a ``PartitionSizeConfig`` from flat fields.

    Shared by ``ConfigurationParser`` (user input) and
    ``TableConfigurationService`` (stored DB data).

    Args:
        target_size_mb: Target partition size in MB, or None.
        target_size_rows: Target partition size in rows, or None.
        strict: When ``True``, raise ``ValueError`` on invalid input.
            When ``False``, silently return auto mode instead.

    Returns:
        A ``PartitionSizeConfig`` instance.

    Raises:
        ValueError: (only when *strict* is ``True``) if both fields are
            set or values are non-positive.

    """
    _auto = PartitionSizeConfig()

    if target_size_mb is not None and target_size_rows is not None:
        if strict:
            raise ValueError(
                "Only one of 'targetPartitionSizeMb' or 'targetPartitionSizeRows' "
                "may be specified"
            )
        return _auto

    if target_size_mb is None and target_size_rows is None:
        return _auto

    if target_size_mb is not None:
        if not isinstance(target_size_mb, int) or target_size_mb <= 0:
            if strict:
                raise ValueError(
                    f"'targetPartitionSizeMb' must be a positive integer, got {target_size_mb}"
                )
            return _auto
        return PartitionSizeConfig(target_size_mb=target_size_mb)

    if not isinstance(target_size_rows, int) or target_size_rows <= 0:
        if strict:
            raise ValueError(
                f"'targetPartitionSizeRows' must be a positive integer, got {target_size_rows}"
            )
        return _auto
    return PartitionSizeConfig(target_size_rows=target_size_rows)


@dataclass(frozen=True)
class TableIdentifier:
    """
    Represents a source or target table endpoint.

    Attributes:
        database_name: The database/catalog name
        schema_name: The schema name
        table_name: The table name

    """

    database_name: str
    schema_name: str
    table_name: str

    @property
    def fully_qualified_friendly_name(self) -> str:
        """
        Get the fully qualified table name (database.schema.table).

        Returns unquoted names joined with dots. For normalized names suitable
        for SQL queries, use ``platform.build_normalized_table_name(table_id)``.
        """
        db_fragment = self.database_name + "." if self.database_name else ""
        schema_fragment = self.schema_name + "." if self.schema_name else ""
        return f"{db_fragment}{schema_fragment}{self.table_name}"


@dataclass(frozen=True)
class TableConfiguration:
    """
    Parsed and validated table configuration from workflow definition.

    This model represents a single table migration configuration with all
    its properties strongly typed. It is constructed by ConfigurationParser
    from raw dictionary configurations.

    Attributes:
        source: The source table endpoint
        target: The target table endpoint
        partition_columns: List of column names to partition by during extraction
        column_type_mappings: Optional dict mapping source types to target types
            (e.g., {"MONEY": "DECIMAL(19,4)", "BIT": "BOOLEAN"})
        column_name_mappings: Optional dict mapping source column names to target column names
            (e.g., {"id": "old_id", "name": "full_name"})
        primary_key_columns: List of column names that form the primary key of the table.
            Used for deduplication in watermark-based incremental sync with track_modifications.
        synchronization: Configuration for incremental synchronization
        extraction: Configuration for extraction strategy (tagged union pattern).
            Contains the strategy type and strategy-specific settings.

    """

    source: TableIdentifier
    target: TableIdentifier
    partition_columns: list[str] = field(default_factory=list)
    column_type_mappings: dict[str, str] = field(default_factory=dict)
    column_name_mappings: dict[str, str] = field(default_factory=dict)
    primary_key_columns: list[str] = field(default_factory=list)
    synchronization: SynchronizationConfig = field(
        default_factory=SynchronizationConfig
    )
    extraction: ExtractionConfig = field(default_factory=ExtractionConfig)
    partition_size: PartitionSizeConfig = field(default_factory=PartitionSizeConfig)
    target_table_type: str = DEFAULT_TARGET_TABLE_TYPE
    iceberg_config: IcebergTargetConfig | None = None

    where_clause_criteria: str | None = None

    loading: LoadingConfig = field(default_factory=LoadingConfig)

    load_segmentation: LoadSegmentationConfig | None = None

    @property
    def partition_column(self) -> str | None:
        """
        First partition column, or None when ``partition_columns`` is empty.

        Prefer :attr:`partition_columns` for multi-column partitioning.
        """
        if not self.partition_columns:
            return None
        return self.partition_columns[0]

    @property
    def loading_strategy(self) -> LoadingStrategy:
        """Get the loading strategy (shortcut for ``loading.strategy``)."""
        return self.loading.strategy

    @property
    def extraction_strategy(self) -> ExtractionStrategy:
        """Get the extraction strategy (shortcut for ``extraction.strategy``)."""
        return self.extraction.strategy
