"""
Oracle platform implementation.

Provides catalog-based schema discovery (``ALL_*`` views) aligned with
information_schema-style column aliases consumed by migration staging and
type mapping.
"""

from data_migration_orchestrator.data_migration_cloud.platforms.oracle.platform import (
    OraclePlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.oracle.query_builder import (
    OracleQueryBuilder,
)
from data_migration_orchestrator.data_migration_core.type_mappings.oracle_default_mappings import (
    ORACLE_TO_SNOWFLAKE_TYPE_MAPPINGS,
)


__all__ = [
    "OraclePlatform",
    "OracleQueryBuilder",
    "ORACLE_TO_SNOWFLAKE_TYPE_MAPPINGS",
]
