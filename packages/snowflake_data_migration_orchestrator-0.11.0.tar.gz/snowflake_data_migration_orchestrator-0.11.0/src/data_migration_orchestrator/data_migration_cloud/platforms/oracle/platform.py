"""Oracle source platform."""

from functools import cached_property

from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_platform import (
    BasePlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_query_builder import (
    BaseQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.platforms.oracle.identifiers import (
    normalize_oracle_data_type_key,
)
from data_migration_orchestrator.data_migration_cloud.platforms.oracle.query_builder import (
    OracleQueryBuilder,
)
from data_migration_orchestrator.data_migration_core.type_mappings.oracle_default_mappings import (
    ORACLE_TO_SNOWFLAKE_TYPE_MAPPINGS,
)
from shared.enums.source_type import SourceType


class OraclePlatform(BasePlatform):
    """Oracle Database as a migration source (ODBC / regular extraction)."""

    @property
    def name(self) -> SourceType:
        """Return the canonical platform name."""
        return SourceType.ORACLE

    @property
    def display_name(self) -> str:
        """Return a human-readable platform name."""
        return "Oracle Database"

    @property
    def aliases(self) -> list[str]:
        """Return common aliases (hyphenated tokens registered on ``PlatformRegistry``)."""
        return ["oracle-db"]

    @property
    def default_strategy(self) -> ExtractionStrategy:
        """Return the default extraction strategy."""
        return ExtractionStrategy.REGULAR

    @property
    def supported_strategies(self) -> list[ExtractionStrategy]:
        """Return all supported extraction strategies."""
        return [ExtractionStrategy.REGULAR]

    @cached_property
    def query_builder(self) -> BaseQueryBuilder:
        """Return the Oracle query builder instance."""
        return OracleQueryBuilder()

    @property
    def type_mappings(self) -> dict[str, str]:
        """Return Oracle to Snowflake type mappings."""
        return ORACLE_TO_SNOWFLAKE_TYPE_MAPPINGS

    def get_type_mapping(self, source_type: str) -> str | None:
        """
        Get the Snowflake type for an Oracle ``DATA_TYPE`` string.

        Args:
            source_type: Oracle data type name (possibly including precision).

        Returns:
            Corresponding Snowflake type or None if not mapped.

        """
        key = normalize_oracle_data_type_key(source_type)
        return self.type_mappings.get(key)

    def require_type_mapping(self, source_type: str) -> str:
        """
        Return the Snowflake type for an Oracle ``DATA_TYPE`` or raise if unmapped.

        Raises:
            ValueError: If no mapping exists for the normalized Oracle type.

        """
        mapped = self.get_type_mapping(source_type)
        if mapped is None:
            msg = f"No Snowflake type mapping for Oracle type {source_type!r}"
            raise ValueError(msg)
        return mapped
