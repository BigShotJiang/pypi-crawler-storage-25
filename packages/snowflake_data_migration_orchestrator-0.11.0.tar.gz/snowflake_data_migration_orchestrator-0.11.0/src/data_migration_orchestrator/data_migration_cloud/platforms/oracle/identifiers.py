"""Oracle identifier normalization, data-type keys, and selective quoting."""

from __future__ import annotations

import re


# Valid nonquoted Oracle identifiers: ASCII letter first, then letters, digits,
# ``_``, ``$``, or ``#``.
_VALID_UNQUOTED = re.compile(r"^[A-Za-z][A-Za-z0-9_$#]*$")


def is_already_double_quoted(identifier: str) -> bool:
    """Return True if *identifier* is wrapped in double quotes."""
    return len(identifier) >= 2 and identifier[0] == '"' and identifier[-1] == '"'


def needs_quoting(identifier: str) -> bool:
    """Return True if *identifier* must be double-quoted for Oracle SQL."""
    if not identifier:
        return True
    if is_already_double_quoted(identifier):
        return False
    return not _VALID_UNQUOTED.match(identifier)


def quote_identifier_if_needed(identifier: str) -> str:
    """Quote *identifier* with double quotes only when required."""
    if not identifier:
        return '""'
    if is_already_double_quoted(identifier):
        return identifier
    if not needs_quoting(identifier):
        return identifier
    inner = identifier.replace('"', '""')
    return f'"{inner}"'


def normalize_identifier_oracle(identifier: str) -> str:
    """
    Normalize an identifier for Oracle.

    Unquoted names fold to uppercase; double-quoted names are left unchanged.
    """
    stripped = identifier.strip()
    possibly_quoted = quote_identifier_if_needed(stripped)
    if is_already_double_quoted(possibly_quoted):
        return possibly_quoted
    return possibly_quoted.upper()


def normalize_oracle_data_type_key(raw: str) -> str:
    """
    Normalize Oracle ``DATA_TYPE`` text for lookups (type mappings, extraction).

    **Order matters:** ``TIMESTAMP(fraction) WITH [LOCAL] TIME ZONE`` must be
    recognized *before* stripping ``(...)``. Otherwise ``timestamp(6) with time
    zone`` would become ``timestamp`` and lose the time-zone qualifier. Type
    mapping via ``OraclePlatform.get_type_mapping`` already used this order;
    extraction SQL uses the same helper so both paths agree.

    Returns:
        Lowercase base token, or canonical strings for timestamps, intervals, and
        ``vector``.

    """
    s = raw.lower().strip()
    if "timestamp" in s and "with" in s and "time zone" in s:
        if "local" in s:
            return "timestamp with local time zone"
        return "timestamp with time zone"
    if "interval" in s:
        if "year" in s and "month" in s:
            return "interval year to month"
        return "interval day to second"
    if s.startswith("vector"):
        return "vector"
    if "(" in s:
        return s.split("(", 1)[0].strip()
    return s
