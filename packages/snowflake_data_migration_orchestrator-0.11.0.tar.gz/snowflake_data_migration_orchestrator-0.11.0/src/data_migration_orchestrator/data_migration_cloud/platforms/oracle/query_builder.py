"""
Oracle-specific SQL generation for migration metadata and extraction.

Schema discovery uses ``ALL_TABLES``, ``ALL_TAB_COLUMNS``, ``ALL_CONSTRAINTS``,
and ``ALL_CONS_COLUMNS`` so results respect the connected user's privileges.

**Minimum privileges**

The migration database user typically needs:

- ``SELECT`` on ``ALL_TABLES``, ``ALL_TAB_COLUMNS``, ``ALL_CONSTRAINTS``,
  and ``ALL_CONS_COLUMNS``. Table metadata uses ``ALL_TABLES.NUM_ROWS`` when
  available (optimizer statistics) and falls back to ``COUNT(*)`` when
  ``NUM_ROWS`` is NULL; ``data_size_mb`` is ``0`` to avoid brittle
  ``ALL_SEGMENTS`` access over ODBC.
- Access to the migrated tables (for extraction / partition queries).

``ALL_*`` views show objects visible to the user (own objects plus those granted
by other owners). ``DBA_*`` is not required.

**Identifier casing (schema / table names)**

Catalog queries filter ``OWNER`` / ``TABLE_NAME`` using **uppercased** string
literals derived from ``TableIdentifier.schema_name`` and
``TableIdentifier.table_name`` (after ``'`` escaping via
:func:`_escape_sql_literal`). That matches how **unquoted** Oracle identifiers
are stored in ``ALL_*`` views (typically uppercase in the data dictionary for
non-quoted names).

**Limitation:** If an object was created with a **case-sensitive, double-quoted**
identifier (e.g. ``"MyTable"``), its stored name in ``ALL_TABLES`` /
``ALL_TAB_COLUMNS`` is not the all-upper form. In that situation this builder's
filters may **not** find the object unless the inputs preserve the same quoting
and casing as the data dictionary. For standard migration sources that use
unquoted, dictionary-style names, uppercased literals are the expected path.

Result column names for :meth:`build_schema_query` match the information_schema
shape used elsewhere: ``column_name``, ``data_type``, ``character_maximum_length``,
``numeric_precision``, ``numeric_scale``, ``is_nullable``, ``ordinal_position``.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_query_builder import (
    BaseQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.platforms.oracle.identifiers import (
    normalize_identifier_oracle,
    normalize_oracle_data_type_key,
    quote_identifier_if_needed,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.checksum_models import (
    ColumnInfo,
    PartitionInfo,
)
from data_migration_orchestrator.data_migration_core.queries.constants import (
    COLUMN_NAME,
    DATA_TYPE,
)
from data_migration_orchestrator.utils.datetime_utils import is_datetime_string
from shared.enums.source_type import SourceType


_ORACLE_EXTRACTION_CONVERSIONS: dict[str, str] = {
    "clob": "TO_CHAR({col})",
    "nclob": "TO_CHAR({col})",
    "blob": "RAWTOHEX({col})",
    "long": "TO_CHAR({col})",
    "long raw": "RAWTOHEX({col})",
    "xmltype": "XMLSERIALIZE(CONTENT {col} AS CLOB)",
    "bfile": "TO_CHAR({col})",
}


def _escape_sql_literal(value: str) -> str:
    """Escape a value for safe embedding in Oracle string literals."""
    return value.replace("'", "''")


class OracleQueryBuilder(BaseQueryBuilder):
    """Query builder for Oracle Database (catalog-based metadata)."""

    @property
    def platform_name(self) -> SourceType:
        """Return the platform name."""
        return SourceType.ORACLE

    @property
    def identifier_quote_char(self) -> tuple[str, str]:
        """Return double quotes for Oracle identifier quoting."""
        return ('"', '"')

    @property
    def string_literal_prefix(self) -> str:
        """Return empty string (no Unicode literal prefix for Oracle)."""
        return ""

    def normalize_identifier(self, identifier: str) -> str:
        """Normalize an identifier for Oracle (uppercase unquoted; preserve quoted)."""
        return normalize_identifier_oracle(identifier)

    def quote_column_name(self, column_name: str) -> str:
        """Quote a column name only when needed for Oracle."""
        return quote_identifier_if_needed(column_name)

    def quote_identifier(self, identifier: str) -> str:
        """Quote an identifier using double quotes."""
        open_q, close_q = self.identifier_quote_char
        escaped = identifier.replace('"', '""')
        return f"{open_q}{escaped}{close_q}"

    def build_table_fqn(self, table_id: TableIdentifier) -> str:
        """
        Build ``OWNER.TABLE`` for Oracle.

        ``database_name`` is ignored because session connections are not
        switched with a three-part catalog prefix in standard Oracle SQL.
        """
        owner = self.normalize_identifier(table_id.schema_name)
        tbl = self.normalize_identifier(table_id.table_name)
        return f"{owner}.{tbl}"

    def build_metadata_query(self, table_name: TableIdentifier) -> str:
        """
        Prefer ``ALL_TABLES.NUM_ROWS`` for ``row_count`` with ``COUNT(*)`` fallback.

        Uses optimizer statistics for ``row_count``; falls back to ``COUNT(*)``
        when statistics are missing (``NUM_ROWS`` is NULL). ``data_size_mb`` is
        ``0``.

        ``NUM_ROWS`` can be stale until ``DBMS_STATS.GATHER_TABLE_STATS`` (or
        equivalent); same trade-off as Teradata ``DBC.TableStatsV``.

        Segment sizing is skipped: some Oracle ODBC stacks fail when dictionary
        views share the statement with heavier segment queries.
        """
        fqn = self.build_table_fqn(table_name)
        owner = _escape_sql_literal(table_name.schema_name.upper())
        tbl = _escape_sql_literal(table_name.table_name.upper())
        return f"""
SELECT
    CAST(COALESCE(
        (SELECT t.num_rows FROM all_tables t WHERE t.owner = '{owner}' AND t.table_name = '{tbl}'),
        (SELECT COUNT(*) FROM {fqn})
    ) AS NUMBER(38, 0)) AS row_count,
    CAST(0 AS NUMBER(38, 2)) AS data_size_mb
FROM DUAL
""".strip()

    def build_schema_query(self, table_name: TableIdentifier) -> str:
        """Return column metadata from ``ALL_TAB_COLUMNS`` (information_schema-style aliases)."""
        owner = _escape_sql_literal(table_name.schema_name.upper())
        tbl = _escape_sql_literal(table_name.table_name.upper())
        return f"""
SELECT
    column_name AS column_name,
    data_type AS data_type,
    CASE
        WHEN data_type IN ('CHAR', 'NCHAR', 'NVARCHAR2', 'VARCHAR2')
            THEN char_length
        ELSE NULL
    END AS character_maximum_length,
    data_precision AS numeric_precision,
    data_scale AS numeric_scale,
    CASE WHEN nullable = 'Y' THEN 'YES' ELSE 'NO' END AS is_nullable,
    column_id AS ordinal_position
FROM all_tab_columns
WHERE owner = '{owner}'
  AND table_name = '{tbl}'
ORDER BY column_id
""".strip()

    def build_select_query(
        self,
        table_name: TableIdentifier,
        column_types: list[dict[str, str]],
        where_clause: str | None = None,
    ) -> str:
        """Build a type-aware ``SELECT`` with server-side conversions where needed."""
        fqn = self.build_table_fqn(table_name)
        parts: list[str] = []
        for col in column_types:
            cname = col[COLUMN_NAME]
            dtype = normalize_oracle_data_type_key(col.get(DATA_TYPE) or "")
            quoted = self.quote_column_name(cname)
            tpl = _ORACLE_EXTRACTION_CONVERSIONS.get(dtype)
            if tpl:
                expr = tpl.format(col=quoted)
                parts.append(f"{expr} AS {quoted}")
            else:
                parts.append(quoted)
        sql = f"SELECT {', '.join(parts)} FROM {fqn}"
        if where_clause:
            sql += f" WHERE {where_clause}"
        return sql

    def format_sql_value(self, value: Any) -> str:
        """Format a value for Oracle ``WHERE`` clause literals."""
        if value is None:
            return "NULL"
        if isinstance(value, int | float):
            return str(value)
        if isinstance(value, Decimal):
            return (
                str(int(value))
                if value == value.to_integral_value()
                else str(float(value))
            )
        if isinstance(value, datetime):
            iso = value.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
            return f"TIMESTAMP '{iso}'"
        if isinstance(value, str):
            trimmed = value[1:-1] if value.startswith('"') and value.endswith('"') else value
            if is_datetime_string(trimmed):
                normalized = trimmed.replace("T", " ")
                return f"TIMESTAMP '{normalized}'"
            return self.quote_string_literal(trimmed)
        return self.quote_string_literal(str(value))

    def build_checksum_query(
        self,
        partition_info: PartitionInfo,
        source_table_id: TableIdentifier,
        columns: list[ColumnInfo],
    ) -> str:
        """
        Partition checksum SQL is not implemented for Oracle.

        A constant ``SELECT`` would look like a successful integrity check while
        doing no real work. Use extraction strategies that do not rely on source
        partition checksums until a real Oracle implementation exists.

        Raises:
            NotImplementedError: Always, until checksum support is implemented.

        """
        raise NotImplementedError(
            "Oracle partition checksum is not implemented. Do not use CHECKSUM "
            "incremental sync against Oracle until a real checksum query is "
            "wired; a placeholder would falsely imply row- or table-level integrity."
        )

    def build_primary_key_columns_query(self, table_name: TableIdentifier) -> str:
        """Return PK column order for one table (``constraint_type = 'P'``)."""
        owner = _escape_sql_literal(table_name.schema_name.upper())
        tbl = _escape_sql_literal(table_name.table_name.upper())
        return f"""
SELECT
    ac.constraint_name AS constraint_name,
    'P' AS constraint_type,
    acc.column_name AS column_name,
    acc.position AS ordinal_position,
    CAST(NULL AS VARCHAR2(128)) AS referenced_owner,
    CAST(NULL AS VARCHAR2(128)) AS referenced_table,
    CAST(NULL AS VARCHAR2(128)) AS referenced_constraint
FROM all_constraints ac
JOIN all_cons_columns acc
    ON acc.owner = ac.owner
    AND acc.constraint_name = ac.constraint_name
WHERE ac.owner = '{owner}'
  AND ac.table_name = '{tbl}'
  AND ac.constraint_type = 'P'
ORDER BY ac.constraint_name, acc.position
""".strip()

    def build_unique_constraint_columns_query(self, table_name: TableIdentifier) -> str:
        """Return SQL listing unique constraint columns (``constraint_type = 'U'``)."""
        owner = _escape_sql_literal(table_name.schema_name.upper())
        tbl = _escape_sql_literal(table_name.table_name.upper())
        return f"""
SELECT
    ac.constraint_name AS constraint_name,
    'U' AS constraint_type,
    acc.column_name AS column_name,
    acc.position AS ordinal_position,
    CAST(NULL AS VARCHAR2(128)) AS referenced_owner,
    CAST(NULL AS VARCHAR2(128)) AS referenced_table,
    CAST(NULL AS VARCHAR2(128)) AS referenced_constraint
FROM all_constraints ac
JOIN all_cons_columns acc
    ON acc.owner = ac.owner
    AND acc.constraint_name = ac.constraint_name
WHERE ac.owner = '{owner}'
  AND ac.table_name = '{tbl}'
  AND ac.constraint_type = 'U'
ORDER BY ac.constraint_name, acc.position
""".strip()

    def build_foreign_key_columns_query(self, table_name: TableIdentifier) -> str:
        """Return SQL listing foreign key columns (``constraint_type = 'R'``)."""
        owner = _escape_sql_literal(table_name.schema_name.upper())
        tbl = _escape_sql_literal(table_name.table_name.upper())
        return f"""
SELECT
    ac.constraint_name AS constraint_name,
    'R' AS constraint_type,
    acc.column_name AS column_name,
    acc.position AS ordinal_position,
    ac.r_owner AS referenced_owner,
    pk.table_name AS referenced_table,
    ac.r_constraint_name AS referenced_constraint
FROM all_constraints ac
JOIN all_cons_columns acc
    ON acc.owner = ac.owner
    AND acc.constraint_name = ac.constraint_name
LEFT JOIN all_constraints pk
    ON pk.owner = ac.r_owner
    AND pk.constraint_name = ac.r_constraint_name
    AND pk.constraint_type = 'P'
WHERE ac.owner = '{owner}'
  AND ac.table_name = '{tbl}'
  AND ac.constraint_type = 'R'
ORDER BY ac.constraint_name, acc.position
""".strip()
