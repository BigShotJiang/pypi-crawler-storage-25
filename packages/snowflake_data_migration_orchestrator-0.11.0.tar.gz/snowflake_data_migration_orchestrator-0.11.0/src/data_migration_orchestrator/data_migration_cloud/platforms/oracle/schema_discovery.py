"""
Parse Oracle catalog query rows into structured metadata models.

Rows are expected to use **lowercase snake_case** keys matching the aliases from
our catalog SQL (e.g. ``column_name``, ``data_type``). Drivers or upstream code
should normalize result column names accordingly.

"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class OracleColumnMetadata:
    """One row of ``build_schema_query`` / ``ALL_TAB_COLUMNS``-shaped output."""

    column_name: str
    data_type: str
    character_maximum_length: int | None
    numeric_precision: int | None
    numeric_scale: int | None
    is_nullable: str
    ordinal_position: int


@dataclass(frozen=True)
class OracleConstraintColumn:
    """PK, unique, or FK column membership from ``ALL_CONSTRAINTS`` / ``ALL_CONS_COLUMNS``."""

    constraint_name: str
    constraint_type: str
    column_name: str
    ordinal_position: int
    referenced_owner: str | None = None
    referenced_table: str | None = None
    referenced_constraint: str | None = None


def _to_int(value: Any) -> int | None:
    if value is None:
        return None
    return int(value)


def oracle_column_from_schema_row(row: dict[str, Any]) -> OracleColumnMetadata:
    """Map a schema-query result row to :class:`OracleColumnMetadata`."""
    return OracleColumnMetadata(
        column_name=str(row["column_name"]),
        data_type=str(row["data_type"]),
        character_maximum_length=_to_int(row["character_maximum_length"]),
        numeric_precision=_to_int(row["numeric_precision"]),
        numeric_scale=_to_int(row["numeric_scale"]),
        is_nullable=str(row["is_nullable"] or ""),
        ordinal_position=int(row["ordinal_position"] or 0),
    )


def oracle_constraint_column_from_row(row: dict[str, Any]) -> OracleConstraintColumn:
    """Map a PK/unique/FK discovery row to :class:`OracleConstraintColumn`."""
    ro = row.get("referenced_owner")
    rt = row.get("referenced_table")
    rc = row.get("referenced_constraint")
    return OracleConstraintColumn(
        constraint_name=str(row["constraint_name"]),
        constraint_type=str(row["constraint_type"]),
        column_name=str(row["column_name"]),
        ordinal_position=int(row["ordinal_position"] or 0),
        referenced_owner=str(ro) if ro is not None else None,
        referenced_table=str(rt) if rt is not None else None,
        referenced_constraint=str(rc) if rc is not None else None,
    )


def group_columns_by_constraint(
    rows: list[OracleConstraintColumn],
) -> dict[tuple[str, str], list[OracleConstraintColumn]]:
    """Group ordered columns by ``(constraint_type, constraint_name)``."""
    out: dict[tuple[str, str], list[OracleConstraintColumn]] = {}
    for r in sorted(rows, key=lambda x: (x.constraint_type, x.constraint_name, x.ordinal_position)):
        key = (r.constraint_type, r.constraint_name)
        out.setdefault(key, []).append(r)
    return out
