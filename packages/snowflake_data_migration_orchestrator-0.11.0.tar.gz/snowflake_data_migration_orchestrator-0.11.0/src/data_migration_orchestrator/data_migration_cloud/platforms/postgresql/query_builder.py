"""
PostgreSQL-specific SQL query builder.

This module provides the PostgresqlQueryBuilder class that generates
SQL queries using PostgreSQL syntax for metadata extraction,
schema queries, and partition calculations.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_query_builder import (
    BaseQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.platforms.postgresql.identifiers import (
    normalize_identifier_postgresql,
    quote_identifier_if_needed,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.checksum_models import (
    ColumnInfo,
    PartitionInfo,
)
from data_migration_orchestrator.data_migration_core.queries.constants import (
    COLUMN_NAME,
    DATA_TYPE,
)
from data_migration_orchestrator.utils.datetime_utils import is_datetime_string
from shared.enums.source_type import SourceType


# Server-side conversions for PostgreSQL types that need special handling.
_POSTGRESQL_EXTRACTION_CONVERSIONS: dict[str, str] = {
    "geometry": "ST_AsText({col})",
    "geography": "ST_AsText({col})",
    "xml": "CAST({col} AS TEXT)",
    "json": "CAST({col} AS TEXT)",
    "jsonb": "CAST({col} AS TEXT)",
    "tsvector": "CAST({col} AS TEXT)",
    "tsquery": "CAST({col} AS TEXT)",
    "bytea": "encode({col}, 'hex')",
}


class PostgresqlQueryBuilder(BaseQueryBuilder):
    """
    Query builder for PostgreSQL SQL syntax.

    Generates SQL queries compatible with PostgreSQL, using standard
    PostgreSQL system catalogs for metadata and schema extraction.
    """

    @property
    def platform_name(self) -> SourceType:
        """Return the platform name."""
        return SourceType.POSTGRESQL

    @property
    def identifier_quote_char(self) -> tuple[str, str]:
        """Return double quotes for PostgreSQL identifier quoting."""
        return ('"', '"')

    @property
    def string_literal_prefix(self) -> str:
        """Return empty string - PostgreSQL has no special prefix."""
        return ""

    def normalize_identifier(self, identifier: str) -> str:
        """Normalize an identifier for PostgreSQL (lowercase unquoted, preserve quoted)."""
        return normalize_identifier_postgresql(identifier)

    def quote_column_name(self, column_name: str) -> str:
        """Quote a column name only when needed for PostgreSQL."""
        return quote_identifier_if_needed(column_name)

    def quote_identifier(self, identifier: str) -> str:
        """
        Quote an identifier using double quotes.

        Args:
            identifier: Identifier to quote

        Returns:
            Quoted identifier

        """
        open_q, close_q = self.identifier_quote_char
        # Escape any existing quotes by doubling them
        escaped = identifier.replace('"', '""')
        return f"{open_q}{escaped}{close_q}"

    def build_metadata_query(self, table_name: TableIdentifier) -> str:
        """
        Generate SQL query to get table metadata from PostgreSQL.

        Uses pg_class and pg_stat_user_tables system catalogs to get
        row count and size information.

        Args:
            table_name: Fully qualified table name (database.schema.table)

        Returns:
            SQL query string

        """
        return f"""
SELECT
    (SELECT COUNT(*) FROM {table_name.fully_qualified_friendly_name}) AS row_count,
    ROUND(pg_total_relation_size('{table_name.fully_qualified_friendly_name}'::regclass)::NUMERIC / (1024 * 1024), 2) AS data_size_mb
""".strip()

    def build_schema_query(self, table_name: TableIdentifier) -> str:
        """
        Generate SQL query to get table schema from PostgreSQL.

        Uses information_schema.columns to get column definitions.

        Args:
            table_name: Fully qualified table name (database.schema.table)

        Returns:
            SQL query string

        """
        return f"""
SELECT
    column_name,
    data_type,
    character_maximum_length,
    numeric_precision,
    numeric_scale,
    is_nullable,
    column_default,
    ordinal_position
FROM information_schema.columns
WHERE table_schema = '{table_name.schema_name}'
  AND table_name = '{table_name.table_name}'
ORDER BY ordinal_position
""".strip()

    def build_select_query(
        self,
        table_name: TableIdentifier,
        column_types: list[dict[str, str]],
        where_clause: str | None = None,
    ) -> str:
        """Build a type-aware SELECT with server-side conversions where needed."""
        fqn = self.build_table_fqn(table_name)
        # Build column expressions with conversions where needed
        col_expressions: list[str] = []
        for col in column_types:
            col_name = col[COLUMN_NAME]
            data_type = col.get(DATA_TYPE, "").lower()
            quoted_col = self.quote_identifier(col_name)

            conversion_template = _POSTGRESQL_EXTRACTION_CONVERSIONS.get(data_type)
            if conversion_template:
                expr = conversion_template.format(col=quoted_col)
                col_expressions.append(f"{expr} AS {quoted_col}")
            else:
                col_expressions.append(quoted_col)

        col_str = ", ".join(col_expressions)
        query = f"SELECT {col_str} FROM {fqn}"

        if where_clause:
            query += f" WHERE {where_clause}"

        return query

    def format_sql_value(self, value: Any) -> str:
        """
        Format a value for PostgreSQL WHERE clauses.

        Uses simple quoted ISO strings for datetime values, which PostgreSQL
        can parse implicitly without explicit type conversion functions.

        Args:
            value: The value to format

        Returns:
            A PostgreSQL-compatible string representation of the value

        """
        if value is None:
            return "NULL"

        if isinstance(value, int | float):
            return str(value)

        if isinstance(value, Decimal):
            return (
                str(int(value))
                if value == value.to_integral_value()
                else str(float(value))
            )

        # Handle Python datetime objects - use ISO format string
        if isinstance(value, datetime):
            # PostgreSQL accepts ISO format strings directly
            iso_str = value.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
            return self.quote_string_literal(iso_str)

        if isinstance(value, str):
            # Remove surrounding double quotes if present (from Snowflake VARIANT)
            trimmed = value
            if value.startswith('"') and value.endswith('"'):
                trimmed = value[1:-1]

            # Datetime strings work as-is in PostgreSQL (implicit conversion)
            # Just normalize the format
            if is_datetime_string(trimmed):
                # Normalize: replace 'T' with space for PostgreSQL compatibility
                normalized = trimmed.replace("T", " ")
                return self.quote_string_literal(normalized)

            # Regular string
            return self.quote_string_literal(trimmed)

        # Fallback: convert to string and quote
        return self.quote_string_literal(str(value))

    def build_checksum_query(
        self,
        partition_info: PartitionInfo,
        source_table_id: TableIdentifier,
        columns: list[ColumnInfo],
    ) -> str:
        """
        Build PostgreSQL checksum query.

        TODO: Implement proper checksum computation using md5/sha256.
        Currently returns a constant value for testing the "unchanged" path.

        """
        return "SELECT 'CONSTANT_CHECKSUM_FOR_TESTING' AS checksum"
