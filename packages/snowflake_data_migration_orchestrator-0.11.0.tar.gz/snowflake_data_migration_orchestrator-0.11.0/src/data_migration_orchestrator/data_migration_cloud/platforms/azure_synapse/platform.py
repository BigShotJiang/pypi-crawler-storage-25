"""Azure Synapse Analytics source platform."""

from functools import cached_property

from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.platforms.azure_synapse.query_builder import (
    AzureSynapseQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_platform import (
    BasePlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_query_builder import (
    BaseQueryBuilder,
)
from data_migration_orchestrator.data_migration_core.type_mappings.azure_synapse_default_mappings import (
    AZURE_SYNAPSE_TO_SNOWFLAKE_TYPE_MAPPINGS,
)
from shared.enums.source_type import SourceType


class AzureSynapsePlatform(BasePlatform):
    """Azure Synapse Analytics Dedicated SQL Pool as a migration source."""

    @property
    def name(self) -> SourceType:
        """Return the platform's canonical SourceType enum value."""
        return SourceType.AZURE_SYNAPSE

    @property
    def display_name(self) -> str:
        """Return the human-readable platform name."""
        return "Azure Synapse Analytics"

    @property
    def aliases(self) -> list[str]:
        """Return alternative identifiers used for registry lookup."""
        return ["synapse", "azure-synapse", "azure-sql-dw"]

    @property
    def default_strategy(self) -> ExtractionStrategy:
        """Return the default extraction strategy for this platform."""
        return ExtractionStrategy.REGULAR

    @property
    def supported_strategies(self) -> list[ExtractionStrategy]:
        """Return the list of extraction strategies this platform supports."""
        return [ExtractionStrategy.REGULAR]

    @cached_property
    def query_builder(self) -> BaseQueryBuilder:
        """Return the T-SQL query builder for Synapse."""
        return AzureSynapseQueryBuilder()

    @property
    def type_mappings(self) -> dict[str, str]:
        """Return the Synapse-to-Snowflake type mapping dictionary."""
        return AZURE_SYNAPSE_TO_SNOWFLAKE_TYPE_MAPPINGS

    def get_type_mapping(self, source_type: str) -> str | None:
        """Look up the Snowflake type for a given Synapse source type."""
        normalized = source_type.upper().strip()
        return self.type_mappings.get(normalized)
