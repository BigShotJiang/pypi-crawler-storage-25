"""Azure Synapse Analytics platform components."""
