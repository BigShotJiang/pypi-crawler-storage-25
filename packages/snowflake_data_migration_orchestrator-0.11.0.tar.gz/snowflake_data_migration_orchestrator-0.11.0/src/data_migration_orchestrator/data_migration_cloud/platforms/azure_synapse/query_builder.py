"""Azure Synapse-specific SQL query builder."""

from __future__ import annotations

import re

from datetime import datetime
from decimal import Decimal
from typing import Any

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.platforms.azure_synapse.identifiers import (
    normalize_identifier_azure_synapse,
    quote_identifier_for_ref_azure_synapse,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_query_builder import (
    BaseQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.platforms.sqlserver.checksum import (
    build_sqlserver_checksum_query,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.checksum_models import (
    ColumnInfo,
    PartitionInfo,
)
from data_migration_orchestrator.data_migration_core.queries.constants import (
    COLUMN_NAME,
)
from data_migration_orchestrator.utils.datetime_utils import is_datetime_string
from shared.enums.source_type import SourceType


TIMEZONE_OFFSET_PATTERN = re.compile(r"[+-]\d{2}:\d{2}$")
FRACTIONAL_SECONDS_PATTERN = re.compile(r"\.(\d{3})\d*")


class AzureSynapseQueryBuilder(BaseQueryBuilder):
    """Query builder for Azure Synapse Analytics T-SQL syntax."""

    @property
    def platform_name(self) -> SourceType:
        """Return the platform's SourceType enum value."""
        return SourceType.AZURE_SYNAPSE

    @property
    def identifier_quote_char(self) -> tuple[str, str]:
        """Return bracket-style identifier quoting used by T-SQL."""
        return ("[", "]")

    @property
    def string_literal_prefix(self) -> str:
        """Return the N-prefix for Unicode string literals."""
        return "N"

    def normalize_identifier(self, identifier: str) -> str:
        """Normalize a Synapse identifier for case-insensitive comparison."""
        return normalize_identifier_azure_synapse(identifier)

    def quote_column_name(self, column_name: str) -> str:
        """Quote a column name for use in query references."""
        return quote_identifier_for_ref_azure_synapse(column_name)

    def build_use_database_command(self, database: str) -> str | None:
        """Return None; Synapse does not support USE DATABASE."""
        return None

    def quote_identifier(self, identifier: str) -> str:
        """Quote an identifier with bracket escaping."""
        open_q, close_q = self.identifier_quote_char
        escaped = identifier.replace("]", "]]")
        return f"{open_q}{escaped}{close_q}"

    def build_metadata_query(self, table_name: TableIdentifier) -> str:
        """Build a query to retrieve row count and size for a Synapse table."""
        return f"""
SELECT
    nps.row_count AS row_count,
    ROUND(nps.reserved_space / 1024.0 / 1024.0, 2) AS data_size_mb
FROM sys.dm_pdw_table_sizes nps
INNER JOIN sys.tables t ON nps.object_id = t.object_id
INNER JOIN sys.schemas s ON t.schema_id = s.schema_id
WHERE s.name = '{table_name.schema_name}'
  AND t.name = '{table_name.table_name}'
""".strip()

    def build_schema_query(self, table_name: TableIdentifier) -> str:
        """Build a query to retrieve column metadata from INFORMATION_SCHEMA."""
        db_filter = f"AND TABLE_CATALOG = '{table_name.database_name}'"
        return f"""
SELECT
    COLUMN_NAME AS column_name,
    DATA_TYPE AS data_type,
    CHARACTER_MAXIMUM_LENGTH AS character_maximum_length,
    NUMERIC_PRECISION AS numeric_precision,
    NUMERIC_SCALE AS numeric_scale,
    IS_NULLABLE AS is_nullable,
    COLUMN_DEFAULT AS column_default,
    ORDINAL_POSITION AS ordinal_position
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = '{table_name.schema_name}'
  AND TABLE_NAME = '{table_name.table_name}'
  {db_filter}
ORDER BY ORDINAL_POSITION
""".strip()

    def build_select_query(
        self,
        table_name: TableIdentifier,
        column_types: list[dict[str, str]],
        where_clause: str | None = None,
    ) -> str:
        """Build a SELECT query for the given table and columns."""
        fqn = self.build_table_fqn(table_name)
        col_expressions: list[str] = []
        for col in column_types:
            col_name = col[COLUMN_NAME]
            quoted_col = self.quote_identifier(col_name)
            col_expressions.append(quoted_col)
        col_str = ", ".join(col_expressions)
        query = f"SELECT {col_str} FROM {fqn}"
        if where_clause:
            query += f" WHERE {where_clause}"
        return query

    def format_sql_value(self, value: Any) -> str:
        """Format a Python value as a T-SQL literal for use in queries."""
        if value is None:
            return "NULL"
        if isinstance(value, (int | float)):
            return str(value)
        if isinstance(value, Decimal):
            return (
                str(int(value))
                if value == value.to_integral_value()
                else str(float(value))
            )
        if isinstance(value, datetime):
            if value.tzinfo is not None:
                iso_str = value.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]
                offset = value.strftime("%z")
                if offset:
                    formatted_offset = f"{offset[:3]}:{offset[3:]}"
                    iso_str = f"{iso_str}{formatted_offset}"
                return f"CONVERT(datetimeoffset, '{iso_str}', 127)"
            else:
                iso_str = value.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]
                return f"CONVERT(datetime2, '{iso_str}', 126)"
        if isinstance(value, str):
            trimmed = value
            if value.startswith('"') and value.endswith('"'):
                trimmed = value[1:-1]
            if is_datetime_string(trimmed):
                normalized = trimmed.replace(" ", "T")
                normalized = FRACTIONAL_SECONDS_PATTERN.sub(r".\1", normalized)
                has_tz = bool(TIMEZONE_OFFSET_PATTERN.search(normalized))
                if has_tz:
                    return f"CONVERT(datetimeoffset, '{normalized}', 127)"
                return f"CONVERT(datetime2, '{normalized}', 126)"
            return self.quote_string_literal(trimmed)
        return self.quote_string_literal(str(value))

    def build_checksum_query(
        self,
        partition_info: PartitionInfo,
        source_table_id: TableIdentifier,
        columns: list[ColumnInfo],
    ) -> str:
        """
        Build Synapse checksum query.

        Reuses SQL Server's HASHBYTES-based implementation since Synapse
        Dedicated SQL Pool supports the same T-SQL checksum primitives.
        """
        where_clause = self.build_partition_condition(
            partition_info.partition_columns,
            partition_info.min_value,
            partition_info.max_value,
            upper_inclusive=partition_info.upper_inclusive,
        )
        return build_sqlserver_checksum_query(
            partition_info=partition_info,
            source_table_id=source_table_id,
            columns=columns,
            quote_identifier_fn=self.quote_identifier,
            where_clause=where_clause,
        )
