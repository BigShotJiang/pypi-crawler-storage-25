"""Azure Synapse identifier normalization and quoting utilities."""

import re


_UNQUOTED_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_@#$]*$")


def normalize_identifier_azure_synapse(identifier: str) -> str:
    """Normalize an identifier for Azure Synapse (uppercase unquoted, preserve quoted)."""
    if identifier.startswith("[") and identifier.endswith("]"):
        return identifier
    return identifier.upper()


def quote_identifier_for_ref_azure_synapse(column_name: str) -> str:
    """Quote a column name with square brackets if it needs quoting."""
    if _UNQUOTED_IDENT.match(column_name):
        return column_name
    escaped = column_name.replace("]", "]]")
    return f"[{escaped}]"
