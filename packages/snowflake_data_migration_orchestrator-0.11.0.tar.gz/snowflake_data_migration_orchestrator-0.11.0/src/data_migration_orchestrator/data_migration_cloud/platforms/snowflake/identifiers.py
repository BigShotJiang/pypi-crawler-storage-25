"""
Snowflake identifier quoting and unquoting.

Handles Snowflake-specific identifier conventions:
- Double-quote notation: "schema"."table"
- Unquoted identifiers are case-insensitive (stored as uppercase)

Implementation lives in :mod:`data_migration_orchestrator.utils.snowflake_identifiers`
(import rules: ``utils`` cannot depend on ``data_migration_cloud``).
"""

from data_migration_orchestrator.utils.snowflake_identifiers import (
    build_snowflake_fqn,
    is_already_quoted,
    needs_quoting,
    quote_identifier,
    unquote_identifier,
)


__all__ = [
    "build_snowflake_fqn",
    "is_already_quoted",
    "needs_quoting",
    "quote_identifier",
    "unquote_identifier",
]
