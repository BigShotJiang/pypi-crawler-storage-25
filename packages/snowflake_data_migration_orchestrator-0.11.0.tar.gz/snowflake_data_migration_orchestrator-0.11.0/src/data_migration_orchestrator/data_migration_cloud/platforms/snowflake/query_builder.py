"""
Snowflake query builder for target database operations.

This module provides a standalone query builder for Snowflake target operations
such as DELETE statements for clearing partition data. It is intentionally
separate from BaseQueryBuilder, which is designed for source platforms.

The module-level :func:`build_snowflake_partition_condition` is the single
source of truth for building partition boundary WHERE conditions against
Snowflake.  Both :class:`SnowflakeQueryBuilder` and other target-side
handlers (e.g. deduplication) should delegate to it.
"""

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Any

from data_migration_orchestrator.data_migration_cloud.partition.coercion import (
    coerce_partition_value,
)
from data_migration_orchestrator.data_migration_cloud.partition.partition_range import (
    build_lex_range_condition,
    build_partition_range_condition,
    decode_partition_bound,
    partition_range_from_encoded,
)
from data_migration_orchestrator.data_migration_cloud.platforms.snowflake.identifiers import (
    quote_identifier,
)


# ---------------------------------------------------------------------------
# Module-level helpers (used by both the utility function and the class)
# ---------------------------------------------------------------------------


def _format_snowflake_value(value: Any) -> str:
    """
    Format a value for use in Snowflake SQL WHERE clauses.

    Handles common Python types and converts them to Snowflake-compatible
    SQL literal representations.

    Args:
        value: The value to format (None, int, float, str, datetime, etc.)

    Returns:
        A SQL-safe string representation of the value

    """
    if value is None:
        return "NULL"

    if isinstance(value, (int | float)):
        return str(value)

    if isinstance(value, Decimal):
        return (
            str(int(value)) if value == value.to_integral_value() else str(float(value))
        )

    if isinstance(value, datetime):
        iso_str = value.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        return _quote_snowflake_string_literal(iso_str)

    if isinstance(value, str):
        trimmed = value
        if value.startswith('"') and value.endswith('"'):
            trimmed = value[1:-1]

        coerced = coerce_partition_value(trimmed)
        if not isinstance(coerced, str):
            return _format_snowflake_value(coerced)

        return _quote_snowflake_string_literal(trimmed)

    return _quote_snowflake_string_literal(str(value))


def _quote_snowflake_string_literal(value: str) -> str:
    """Quote a string literal for Snowflake SQL."""
    escaped = value.replace("'", "''")
    return f"'{escaped}'"


# ---------------------------------------------------------------------------
# Public utility function
# ---------------------------------------------------------------------------


def build_snowflake_partition_condition(
    partition_columns: list[str] | str | None,
    min_value: Any | None,
    max_value: Any | None,
    *,
    upper_inclusive: bool = False,
) -> str:
    """
    Build SQL condition for partition boundaries on Snowflake (without WHERE keyword).

    Mirrors ``BaseQueryBuilder.build_partition_condition`` for target-side filters.
    """
    if min_value is None and max_value is None:
        return "1=1"
    if partition_columns is None:
        return "1=1"
    columns = (
        [partition_columns]
        if isinstance(partition_columns, str)
        else list(partition_columns)
    )
    if not columns:
        return "1=1"

    def quote(c: str) -> str:
        return quote_identifier(c, force_quote=False)

    fmt = _format_snowflake_value

    if min_value is None and max_value is not None:
        upper = decode_partition_bound(max_value, columns)
        return build_lex_range_condition(
            columns,
            None,
            upper,
            upper_inclusive=False,
            quote_identifier=quote,
            format_value=fmt,
        )

    if max_value is None and min_value is not None:
        lower = decode_partition_bound(min_value, columns)
        return build_lex_range_condition(
            columns,
            lower,
            None,
            lower_inclusive=False,
            quote_identifier=quote,
            format_value=fmt,
        )

    partition_range = partition_range_from_encoded(
        columns,
        min_value,
        max_value,
        upper_inclusive=upper_inclusive,
    )
    return build_partition_range_condition(
        partition_range,
        quote_identifier=quote,
        format_value=fmt,
    )


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class PartitionRange:
    """
    Partition range for WHERE clause generation on Snowflake targets.

    Attributes:
        columns: Partition column names (lexicographic order)
        min_value: Encoded lower bound (scalar or delimited string)
        max_value: Encoded upper bound (scalar or delimited string)
        upper_inclusive: Use ``<= max`` when both bounds are set

    """

    columns: list[str]
    min_value: Any
    max_value: Any
    upper_inclusive: bool = False

    @property
    def column(self) -> str | None:
        """First column, for backward compatibility."""
        return self.columns[0] if self.columns else None


# ---------------------------------------------------------------------------
# Query builder class
# ---------------------------------------------------------------------------


class SnowflakeQueryBuilder:
    """
    Query builder for Snowflake target operations.

    This class provides methods for building SQL statements that run on
    Snowflake as the target database, such as DELETE statements for
    clearing partition data during incremental sync operations.

    Unlike BaseQueryBuilder (for source platforms), this is a standalone
    class focused specifically on target database operations.
    """

    def build_delete_statement(
        self, table_name: str, partition_range: PartitionRange
    ) -> str:
        """
        Build DELETE statement with partition boundary conditions.

        Generates a DELETE SQL statement that removes rows within the specified
        partition range from the target Snowflake table.

        Args:
            table_name: Fully qualified table name (e.g., 'db.schema.table')
            partition_range: The partition range defining which rows to delete

        Returns:
            DELETE SQL statement

        Example:
            >>> builder = SnowflakeQueryBuilder()
            >>> builder.build_delete_statement(
            ...     "mydb.myschema.mytable",
            ...     PartitionRange(column="id", min_value=1, max_value=100)
            ... )
            'DELETE FROM mydb.myschema.mytable WHERE id >= 1 AND id <= 100'

        """
        where_clause = build_snowflake_partition_condition(
            partition_range.columns,
            partition_range.min_value,
            partition_range.max_value,
            upper_inclusive=partition_range.upper_inclusive,
        )
        return f"DELETE FROM {table_name} WHERE {where_clause}"
