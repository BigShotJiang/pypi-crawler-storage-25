"""
Teradata-specific SQL query builder.

This module provides the TeradataQueryBuilder class that generates
SQL queries using Teradata syntax for metadata extraction,
schema queries, and data extraction.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_query_builder import (
    BaseQueryBuilder,
    coerce_partition_value,
)
from data_migration_orchestrator.data_migration_cloud.platforms.teradata.checksum import (
    build_teradata_checksum_query,
)
from data_migration_orchestrator.data_migration_cloud.platforms.teradata.identifiers import (
    normalize_identifier_teradata,
    quote_identifier_if_needed,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.checksum_models import (
    ColumnInfo,
    PartitionInfo,
)
from data_migration_orchestrator.data_migration_core.queries.constants import (
    COLUMN_NAME,
    DATA_TYPE,
)
from data_migration_orchestrator.utils.datetime_utils import is_datetime_string
from shared.enums.source_type import SourceType


# Server-side conversions for Teradata types that need special handling
# during ODBC extraction to ensure safe transfer to Snowflake.
#
# Keys cover both the long Teradata type names (e.g. ``clob``, ``varbyte``)
# AND the DBC.ColumnsV ``ColumnType`` abbreviation codes returned by
# ``build_schema_query`` (e.g. ``co``, ``bv``).  See
# ``teradata_default_mappings.TERADATA_TO_SNOWFLAKE_TYPE_MAPPINGS`` for the
# full code reference.  Without the codes, schema-driven extraction never
# matched these branches in production because ``DBC.ColumnsV.ColumnType``
# only returns the short codes.
_LOB_VARCHAR_CAST = "CAST({col} AS VARCHAR(64000))"
# Reversible hex text for ODBC/CSV transport. HASHROW is a one-way 4-byte hash and loses data.
# Snowflake load: decode VARCHAR hex with TO_BINARY($n, 'HEX') (or equivalent) into BINARY.
_BINARY_HEX_VARCHAR_CAST = "FROM_BYTES({col}, 'base16')"
_PERIOD_VARCHAR_CAST = "CAST({col} AS VARCHAR(100))"
_INTERVAL_VARCHAR_CAST = "CAST({col} AS VARCHAR(100))"

_TERADATA_EXTRACTION_CONVERSIONS: dict[str, str] = {
    # LOB types — cast to VARCHAR for ODBC transport
    "clob": _LOB_VARCHAR_CAST,
    "co": _LOB_VARCHAR_CAST,  # DBC code: CLOB
    # XML / JSON — cast to VARCHAR
    "xml": _LOB_VARCHAR_CAST,
    "xm": _LOB_VARCHAR_CAST,  # DBC code: XML
    "json": _LOB_VARCHAR_CAST,
    "jn": _LOB_VARCHAR_CAST,  # DBC code: JSON
    # Binary types — hex encode for safe text transport
    "byte": _BINARY_HEX_VARCHAR_CAST,
    "bf": _BINARY_HEX_VARCHAR_CAST,  # DBC code: BYTE
    "varbyte": _BINARY_HEX_VARCHAR_CAST,
    "bv": _BINARY_HEX_VARCHAR_CAST,  # DBC code: VARBYTE
    "blob": _BINARY_HEX_VARCHAR_CAST,
    "bo": _BINARY_HEX_VARCHAR_CAST,  # DBC code: BLOB
    # Geospatial — convert to WKT text representation
    "st_geometry": "CAST({col}.ST_AsText() AS VARCHAR(64000))",
    # User-defined types — cast to VARCHAR
    "ut": _LOB_VARCHAR_CAST,  # DBC code: UDT
    # Period types — cast to VARCHAR representation
    "period(date)": _PERIOD_VARCHAR_CAST,
    "period(time)": _PERIOD_VARCHAR_CAST,
    "period(time with time zone)": _PERIOD_VARCHAR_CAST,
    "period(timestamp)": _PERIOD_VARCHAR_CAST,
    "period(timestamp with time zone)": _PERIOD_VARCHAR_CAST,
    # DBC codes for period types
    "pd": _PERIOD_VARCHAR_CAST,  # PERIOD(DATE)
    "pt": _PERIOD_VARCHAR_CAST,  # PERIOD(TIME)
    "pz": _PERIOD_VARCHAR_CAST,  # PERIOD(TIME WITH TIME ZONE)
    "ps": _PERIOD_VARCHAR_CAST,  # PERIOD(TIMESTAMP)
    "pm": _PERIOD_VARCHAR_CAST,  # PERIOD(TIMESTAMP WITH TIME ZONE)
    # DBC codes for interval types
    "yr": _INTERVAL_VARCHAR_CAST,  # INTERVAL YEAR
    "ym": _INTERVAL_VARCHAR_CAST,  # INTERVAL YEAR TO MONTH
    "mo": _INTERVAL_VARCHAR_CAST,  # INTERVAL MONTH
    "dy": _INTERVAL_VARCHAR_CAST,  # INTERVAL DAY
    "dh": _INTERVAL_VARCHAR_CAST,  # INTERVAL DAY TO HOUR
    "dm": _INTERVAL_VARCHAR_CAST,  # INTERVAL DAY TO MINUTE
    "ds": _INTERVAL_VARCHAR_CAST,  # INTERVAL DAY TO SECOND
    "hr": _INTERVAL_VARCHAR_CAST,  # INTERVAL HOUR
    "hm": _INTERVAL_VARCHAR_CAST,  # INTERVAL HOUR TO MINUTE
    "hs": _INTERVAL_VARCHAR_CAST,  # INTERVAL HOUR TO SECOND
    "mi": _INTERVAL_VARCHAR_CAST,  # INTERVAL MINUTE
    "ms": _INTERVAL_VARCHAR_CAST,  # INTERVAL MINUTE TO SECOND
    "sc": _INTERVAL_VARCHAR_CAST,  # INTERVAL SECOND
}


class TeradataQueryBuilder(BaseQueryBuilder):
    """
    Query builder for Teradata SQL syntax.

    Generates SQL queries compatible with Teradata, using DBC system views
    for metadata and schema extraction (REGULAR / ODBC extraction).
    """

    @property
    def platform_name(self) -> SourceType:
        """Return the platform name."""
        return SourceType.TERADATA

    @property
    def identifier_quote_char(self) -> tuple[str, str]:
        """Return double quotes for Teradata identifier quoting."""
        return ('"', '"')

    @property
    def string_literal_prefix(self) -> str:
        """Return empty string - Teradata has no special prefix."""
        return ""

    def normalize_identifier(self, identifier: str) -> str:
        """Normalize an identifier for Teradata (uppercase unquoted, preserve quoted)."""
        return normalize_identifier_teradata(identifier)

    def quote_column_name(self, column_name: str) -> str:
        """Quote a column name only when needed for Teradata."""
        return quote_identifier_if_needed(column_name)

    def quote_identifier(self, identifier: str) -> str:
        """
        Quote an identifier using double quotes.

        Args:
            identifier: Identifier to quote

        Returns:
            Quoted identifier

        """
        open_q, close_q = self.identifier_quote_char
        # Escape any existing quotes by doubling them
        escaped = identifier.replace('"', '""')
        return f"{open_q}{escaped}{close_q}"

    def build_table_fqn(self, table_id: TableIdentifier) -> str:
        """
        Build a Teradata fully qualified name using database.table (two-part).

        Teradata has no separate schema concept; the database IS the schema.
        Uses schema_name as the database if database_name is empty.
        """
        db = table_id.schema_name or table_id.database_name
        table = table_id.table_name
        db_fragment = self.normalize_identifier(db) + "." if db else ""
        return f"{db_fragment}{self.normalize_identifier(table)}"

    def build_metadata_query(self, table_name: TableIdentifier) -> str:
        """
        Generate SQL query to get table metadata from Teradata.

        Prefers **catalog estimates** so metadata refresh stays cheap on
        well-maintained tables, with a guaranteed-correct fallback:

        - ``row_count`` is taken from ``DBC.TableStatsV.RowCount`` (collected
          statistics) when available.  When ``COLLECT STATISTICS`` has not been
          run on the table the inner subquery returns ``NULL``; the ``COALESCE``
          then falls back to ``SELECT COUNT(*) FROM "<db>"."<table>"`` so the
          downstream stage reader never has to deal with a sentinel value.
          (Returning ``-1`` here used to break ``read_metadata_from_stage``
          for any source table without stats — e.g. ``ECOMMERCE.CUSTOMERS``.)
        - ``data_size_mb`` is summed from ``DBC.TableSizeV.CurrentPerm``
          across AMPs and converted from bytes to megabytes.

        This mirrors what other platforms do (PostgreSQL
        ``pg_stat_user_tables``, SQL Server ``sys.dm_db_partition_stats``)
        while still guaranteeing a real row count when catalog stats are
        missing or stale.

        Args:
            table_name: Fully qualified table name (database.schema.table)

        Returns:
            SQL query string

        """
        # Teradata uses DatabaseName instead of schema
        db_name = table_name.schema_name or table_name.database_name
        tbl_name = table_name.table_name

        return f"""
SELECT
    COALESCE(
        (SELECT CAST(MAX(ts.RowCount) AS BIGINT)
         FROM DBC.TableStatsV ts
         WHERE ts.DatabaseName = '{db_name}'
           AND ts.TableName = '{tbl_name}'),
        (SELECT CAST(COUNT(*) AS BIGINT) FROM "{db_name}"."{tbl_name}")
    ) AS row_count,
    CAST(COALESCE(SUM(s.CurrentPerm), 0) / (1024.0 * 1024.0) AS DECIMAL(18,2)) AS data_size_mb
FROM DBC.TableSizeV s
WHERE s.DatabaseName = '{db_name}'
  AND s.TableName = '{tbl_name}'
""".strip()

    def build_schema_query(self, table_name: TableIdentifier) -> str:
        """
        Generate SQL query to get table schema from Teradata.

        Uses DBC.ColumnsV system view to get column definitions.

        Args:
            table_name: Fully qualified table name (database.schema.table)

        Returns:
            SQL query string

        """
        db_name = table_name.schema_name or table_name.database_name
        tbl_name = table_name.table_name

        return f"""
SELECT
    ColumnName AS column_name,
    ColumnType AS data_type,
    ColumnLength AS character_maximum_length,
    DecimalTotalDigits AS numeric_precision,
    DecimalFractionalDigits AS numeric_scale,
    CASE WHEN Nullable = 'Y' THEN 'YES' ELSE 'NO' END AS is_nullable,
    DefaultValue AS column_default,
    ColumnId AS ordinal_position
FROM DBC.ColumnsV
WHERE DatabaseName = '{db_name}'
  AND TableName = '{tbl_name}'
ORDER BY ColumnId
""".strip()

    def build_use_database_command(self, database: str) -> str | None:
        """
        Build a Teradata DATABASE command to switch the active database.

        Teradata uses the DATABASE command (not USE) to switch context.

        Args:
            database: The target database name to switch to

        Returns:
            The DATABASE command string

        """
        return f"DATABASE {self.quote_identifier(database)}"

    def build_select_query(
        self,
        table_name: TableIdentifier,
        column_types: list[dict[str, str]],
        where_clause: str | None = None,
    ) -> str:
        """Build a type-aware SELECT with server-side conversions where needed."""
        fqn = self.build_table_fqn(table_name)
        # Build column expressions with conversions where needed
        col_expressions: list[str] = []
        for col in column_types:
            col_name = col[COLUMN_NAME]
            data_type = col.get(DATA_TYPE, "").lower()
            quoted_col = self.quote_identifier(col_name)

            conversion_template = self._get_extraction_conversion(data_type)
            if conversion_template:
                expr = conversion_template.format(col=quoted_col)
                col_expressions.append(f"{expr} AS {quoted_col}")
            else:
                col_expressions.append(quoted_col)

        col_str = ", ".join(col_expressions)
        query = f"SELECT {col_str} FROM {fqn}"

        if where_clause:
            query += f" WHERE {where_clause}"

        return query

    def _get_extraction_conversion(self, data_type: str) -> str | None:
        """
        Get the extraction conversion template for a Teradata data type.

        Handles exact matches first, then prefix matching for INTERVAL
        and PERIOD types which can have various suffixes.

        Args:
            data_type: Lowercase Teradata data type name

        Returns:
            Conversion template string with {col} placeholder, or None

        """
        # Exact match first
        template = _TERADATA_EXTRACTION_CONVERSIONS.get(data_type)
        if template:
            return template

        # Prefix matching for INTERVAL types (all map to VARCHAR)
        if data_type.startswith("interval"):
            return "CAST({col} AS VARCHAR(100))"

        # Prefix matching for PERIOD types
        if data_type.startswith("period("):
            return "CAST({col} AS VARCHAR(100))"

        return None

    def format_sql_value(self, value: Any) -> str:
        """
        Format a value for Teradata WHERE clauses.

        Uses Teradata ``TIMESTAMP '...'`` literal syntax for datetime values
        and ordinary numeric literals for ``int`` / ``float`` / ``Decimal``.

        ``bool`` is handled explicitly **before** ``int | float`` because in
        Python ``isinstance(True, int)`` is ``True``; without this guard a
        boolean partition / watermark value would render as ``1`` or ``0``.

        Numeric partition bounds that arrive as strings (e.g. from Snowflake
        ``PARTITION_METADATA``) are unwrapped via
        :func:`coerce_partition_value` so they are emitted as numeric literals
        instead of quoted strings (avoids type-mismatch errors against numeric
        columns on Teradata).

        Args:
            value: The value to format

        Returns:
            A Teradata-compatible string representation of the value

        """
        if value is None:
            return "NULL"

        if isinstance(value, bool):
            # Teradata 16.20+ supports the ``BOOLEAN`` data type with these
            # literal forms; using uppercase keywords keeps the rendered SQL
            # consistent with the rest of the platform layer.
            return "TRUE" if value else "FALSE"

        if isinstance(value, (int | float)):
            return str(value)

        if isinstance(value, Decimal):
            return (
                str(int(value))
                if value == value.to_integral_value()
                else str(float(value))
            )

        # Handle Python datetime objects - use Teradata TIMESTAMP literal
        if isinstance(value, datetime):
            iso_str = value.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
            return f"TIMESTAMP '{iso_str}'"

        if isinstance(value, str):
            # Remove surrounding double quotes if present (from Snowflake VARIANT)
            trimmed = value
            if value.startswith('"') and value.endswith('"'):
                trimmed = value[1:-1]

            # Coerce numeric-looking strings (``'1718751.0000000000'`` / Decimal)
            # to native types before quoting; this matches the base class so
            # numeric partition columns aren't filtered with string literals.
            coerced = coerce_partition_value(trimmed)
            if not isinstance(coerced, str):
                return self.format_sql_value(coerced)

            # Datetime strings get Teradata TIMESTAMP literal syntax
            if is_datetime_string(trimmed):
                normalized = trimmed.replace("T", " ")
                return f"TIMESTAMP '{normalized}'"

            # Regular string
            return self.quote_string_literal(trimmed)

        # Fallback: convert to string and quote
        return self.quote_string_literal(str(value))

    def build_checksum_query(
        self,
        partition_info: PartitionInfo,
        source_table_id: TableIdentifier,
        columns: list[ColumnInfo],
    ) -> str:
        """
        Build Teradata checksum query.

        Delegates to :func:`~...platforms.teradata.checksum.build_teradata_checksum_query`,
        which matches ps_dmva (DMVA) default Teradata checksum SQL generation.

        The fully qualified table reference is built via
        :meth:`build_table_fqn` so it follows Teradata's two-part naming and
        case-folding rules (``database.table``), rather than blindly quoting
        three segments.

        """
        where_clause = self.build_partition_condition(
            partition_info.partition_columns,
            partition_info.min_value,
            partition_info.max_value,
            upper_inclusive=partition_info.upper_inclusive,
        )
        table_ref = self.build_table_fqn(
            TableIdentifier(
                database_name=partition_info.database,
                schema_name=partition_info.schema,
                table_name=partition_info.table_name,
            )
        )
        return build_teradata_checksum_query(
            table_ref=table_ref,
            source_table_id=source_table_id,
            columns=columns,
            quote_identifier_fn=self.quote_identifier,
            where_clause=where_clause,
        )
