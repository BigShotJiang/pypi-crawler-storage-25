"""
Teradata platform implementation.

This module provides the TeradataPlatform class that defines Teradata-specific
behavior for data migration workflows.
"""

from functools import cached_property

from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_platform import (
    BasePlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_query_builder import (
    BaseQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.platforms.teradata.query_builder import (
    TeradataQueryBuilder,
)
from data_migration_orchestrator.data_migration_core.type_mappings.teradata_default_mappings import (
    TERADATA_TO_SNOWFLAKE_TYPE_MAPPINGS,
)
from shared.enums.source_type import SourceType


class TeradataPlatform(BasePlatform):
    """
    Platform implementation for Teradata.

    Supports extraction via REGULAR (ODBC / worker-side TPT when configured on
    the DEA, default) and WRITE_NOS (direct export to cloud object storage via
    the Teradata WRITE_NOS table function).
    """

    @property
    def name(self) -> SourceType:
        """Return the canonical platform name."""
        return SourceType.TERADATA

    @property
    def display_name(self) -> str:
        """Return a human-readable platform name."""
        return "Teradata"

    @property
    def aliases(self) -> list[str]:
        """Return common aliases for this platform."""
        return ["td", "teradata-vantage"]

    @property
    def default_strategy(self) -> ExtractionStrategy:
        """Return the default extraction strategy."""
        return ExtractionStrategy.REGULAR

    @property
    def supported_strategies(self) -> list[ExtractionStrategy]:
        """Return all supported extraction strategies."""
        return [
            ExtractionStrategy.REGULAR,
            ExtractionStrategy.WRITE_NOS,
        ]

    @cached_property
    def query_builder(self) -> BaseQueryBuilder:
        """Return the Teradata query builder instance."""
        return TeradataQueryBuilder()

    @property
    def type_mappings(self) -> dict[str, str]:
        """Return Teradata to Snowflake type mappings."""
        return TERADATA_TO_SNOWFLAKE_TYPE_MAPPINGS

    def get_type_mapping(self, source_type: str) -> str | None:
        """
        Get the Snowflake type for a Teradata type.

        Args:
            source_type: Teradata data type name

        Returns:
            Corresponding Snowflake type or None if not mapped

        """
        # Normalize to lowercase for lookup
        normalized = source_type.lower().strip()
        return self.type_mappings.get(normalized)
