"""
Teradata checksum query generation.

Aligned with ps_dmva ``system_teradata.Teradata.get_checksum_values`` / DMVA default
checksum SQL: ``HASHROW`` on up to 64 columns per slice (``BITXOR`` across slices),
``FROM_BYTES('00'xb || …, 'base16')`` + ``TO_NUMBER`` → ``BIGINT`` per row, then
per-bucket ``SUM(BITAND / SHIFTRIGHT)`` values concatenated with ``':'``.

Columns whose types are in ``_SKIPPED_TYPES`` (LOB/JSON/XML/period/analytics/UDT
spellings, etc.) are excluded from ``HASHROW``; if none remain hashable, the query
falls back to ``COUNT(1)``.
"""

from __future__ import annotations

from collections.abc import Callable

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.checksum_models import (
    ColumnInfo,
)


logger = get_logger("platforms.teradata.checksum")

# Teradata type strings / DBC column type codes not passed to HASHROW for checksums.
_SKIPPED_TYPES = frozenset(
    {
        "blob",
        "bo",
        "clob",
        "co",
        "json",
        "jn",
        "xml",
        "xm",
        "dataset",
        "dt",
        "period",
        "pd",
        "st_geometry",
        "ut",
        "mbr",
        "array",
        "a1",
        "an",
        "varray",
    }
)


_BITS_PER_HASH = 32
_MAX_COLUMNS_PER_HASH = 64
_DEFAULT_BUCKETS_PER_HASH = 4


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------
def build_teradata_checksum_query(
    *,
    table_ref: str,
    source_table_id: TableIdentifier,
    columns: list[ColumnInfo],
    quote_identifier_fn: Callable[[str], str],
    where_clause: str,
    buckets_per_hash: int | None = None,
    columns_per_hash: int | None = None,
) -> str:
    """
    Build a Teradata partition checksum query consistent with DMVA defaults.

    Args:
        table_ref: Pre-built Teradata fully qualified table reference (e.g.
            ``MYDB.ORDERS``). The caller is responsible for assembling and
            normalizing this via the platform's ``build_table_fqn``.
        source_table_id: Source table identifier (used for log messages).
        columns: Column metadata list.
        quote_identifier_fn: Identifier quoting callable used for **column**
            references inside ``HASHROW``.
        where_clause: Pre-built partition boundary condition (without WHERE).
        buckets_per_hash: Optional power-of-two bucket count (2, 4, 8, or 16).
            Must satisfy ``1 < n < 32``. Defaults to 4 per DMVA.
        columns_per_hash: Optional max columns per ``HASHROW`` call (max 64).
            Defaults to ``min(64, column_count)`` per DMVA.

    Returns:
        SQL query that computes the partition checksum string.

    """
    hashable_columns = [c for c in columns if _is_hashable(c.data_type)]

    if not hashable_columns:
        logger.warning(
            "No hashable columns for %s, falling back to COUNT(1)",
            source_table_id.fully_qualified_friendly_name,
        )
        return _build_count_only_query(table_ref, where_clause)

    bph = _normalize_buckets_per_hash(buckets_per_hash)
    cph = _normalize_columns_per_hash(columns_per_hash, len(hashable_columns))
    hashrow_expr = _build_hashrow_expression(hashable_columns, quote_identifier_fn, cph)
    hashed_select = _build_hashed_columns_select_expr(hashrow_expr)
    checksum_agg = _build_partition_checksum_aggregate(bph)

    return (
        "WITH hashes AS (\n"
        "    SELECT\n"
        f"        {hashed_select}\n"
        f"    FROM {table_ref} t\n"
        f"    WHERE {where_clause}\n"
        ")\n"
        "SELECT\n"
        f"    {checksum_agg} AS checksum\n"
        "FROM hashes"
    )


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------
def _is_hashable(data_type: str) -> bool:
    return data_type.lower().strip() not in _SKIPPED_TYPES


def _normalize_buckets_per_hash(bph: int | None) -> int:
    if isinstance(bph, int) and 1 < bph < _BITS_PER_HASH and (bph & (bph - 1) == 0):
        return bph
    return _DEFAULT_BUCKETS_PER_HASH


def _normalize_columns_per_hash(cph: int | None, n_cols: int) -> int:
    if n_cols <= 0:
        return 1
    if isinstance(cph, int):
        return max(1, min(cph, _MAX_COLUMNS_PER_HASH, n_cols))
    return min(_MAX_COLUMNS_PER_HASH, n_cols)


def _build_hashrow_expression(
    columns: list[ColumnInfo],
    quote_identifier_fn: Callable[[str], str],
    columns_per_hash: int,
) -> str:
    refs = [quote_identifier_fn(c.column_name) for c in columns]
    slices: list[str] = []
    for start in range(0, len(refs), columns_per_hash):
        end = min(len(refs), start + columns_per_hash)
        inner = ", ".join(refs[start:end])
        slices.append(f"HASHROW({inner})")
    expr = slices[0]
    for s in slices[1:]:
        expr = f"BITXOR({expr}, {s})"
    return expr


def _build_hashed_columns_select_expr(hashrow_expr: str) -> str:
    # DMVA: cast(to_number(from_bytes('00'xb || hashrow, 'base16'), 'xxxxxxxxxx') as bigint)
    return (
        "CAST(TO_NUMBER(FROM_BYTES('00'xb || "
        f"{hashrow_expr}"
        ", 'base16'), 'XXXXXXXXXX') AS BIGINT) AS hashed_columns"
    )


def _build_partition_checksum_aggregate(buckets_per_hash: int) -> str:
    bits_per_bucket = _BITS_PER_HASH // buckets_per_hash
    bitand_mask = (2**bits_per_bucket) - 1
    parts: list[str] = []
    for i in range(buckets_per_hash - 1, -1, -1):
        if i == 0:
            bucket_expr = f"BITAND(hashed_columns, {bitand_mask})"
        else:
            shift = i * bits_per_bucket
            bucket_expr = f"BITAND(SHIFTRIGHT(hashed_columns, {shift}), {bitand_mask})"
        parts.append(f"TRIM(TO_CHAR(NVL(SUM({bucket_expr}), 0)))")
    return " || ':' || ".join(parts)


def _build_count_only_query(table_ref: str, where_clause: str) -> str:
    """DMVA uses count(1) when no hashable columns exist."""
    return (
        "SELECT\n"
        "    CAST(COUNT(1) AS VARCHAR(40)) AS checksum\n"
        f"FROM {table_ref}\n"
        f"WHERE {where_clause}"
    )
