"""
Teradata platform implementation.

This package provides Teradata-specific components for data migration:
    TeradataPlatform: Platform definition and configuration
    TeradataQueryBuilder: Teradata dialect query generation
    TERADATA_TO_SNOWFLAKE_TYPE_MAPPINGS: Type conversion mappings
"""

from data_migration_orchestrator.data_migration_cloud.platforms.teradata.platform import (
    TeradataPlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.teradata.query_builder import (
    TeradataQueryBuilder,
)
from data_migration_orchestrator.data_migration_core.type_mappings.teradata_default_mappings import (
    TERADATA_TO_SNOWFLAKE_TYPE_MAPPINGS,
)


__all__ = [
    "TeradataPlatform",
    "TeradataQueryBuilder",
    "TERADATA_TO_SNOWFLAKE_TYPE_MAPPINGS",
]
