"""
Base query builder abstract class for platform-specific SQL generation.

This module defines the abstract base class that all platform query builders
must implement. Each query builder generates SQL syntax appropriate for its
target database platform.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime
from decimal import Decimal
from typing import Any

from data_migration_orchestrator.data_migration_cloud.config.sync_strategy import (
    SyncStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.partition.coercion import (
    coerce_partition_value,
)
from data_migration_orchestrator.data_migration_cloud.partition.partition_range import (
    build_lex_range_condition,
    build_partition_range_condition,
    decode_partition_bound,
    partition_range_from_encoded,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.checksum_models import (
    ColumnInfo,
    PartitionInfo,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.synchronization_data import (
    SyncData,
    WatermarkSyncData,
)
from data_migration_orchestrator.data_migration_core.queries.constants import (
    COLUMN_NAME,
    DATA_TYPE,
)
from shared.enums.source_type import SourceType


# Re-export for platform modules that import coerce from this module.
__all__ = ["BaseQueryBuilder", "coerce_partition_value"]


class BaseQueryBuilder(ABC):
    """
    Abstract base class for platform-specific SQL query generation.

    Each query builder implementation provides methods to generate SQL queries
    for metadata extraction, schema extraction, and partition boundary calculation
    using the syntax appropriate for its target database platform.

    Example:
        >>> class SqlServerQueryBuilder(BaseQueryBuilder):
        ...     @property
        ...     def platform_name(self) -> SourceType:
        ...         return SourceType.SQLSERVER
        ...     # ... implement other abstract properties/methods

    """

    @property
    @abstractmethod
    def platform_name(self) -> SourceType:
        """
        Name of the platform this query builder targets.

        Returns:
            SourceType enum value (e.g., SourceType.SQLSERVER, SourceType.REDSHIFT)

        """
        ...

    @property
    @abstractmethod
    def identifier_quote_char(self) -> tuple[str, str]:
        """
        Characters used to quote identifiers in this platform's SQL.

        Returns:
            Tuple of (open_quote, close_quote) characters
            (e.g., ("[", "]") for SQL Server, ('"', '"') for PostgreSQL/Redshift)

        """
        ...

    @property
    def string_literal_prefix(self) -> str:
        """
        Prefix for Unicode string literals (if any).

        Returns:
            Prefix string (e.g., "N" for SQL Server, "" for most others)

        """
        return ""

    @abstractmethod
    def build_metadata_query(self, table_name: TableIdentifier) -> str:
        """
        Generate SQL query to get table metadata.

        The query should return row_count and data_size_mb for the table.

        Args:
            table_name: Object representing fully qualified table name (database.schema.table)

        Returns:
            SQL query string that returns metadata columns

        """
        ...

    @abstractmethod
    def build_schema_query(self, table_name: TableIdentifier) -> str:
        """
        Generate SQL query to get table schema.

        The query should return column definitions including name, type,
        precision, scale, and nullability.

        Args:
            table_name: Object representing fully qualified table name (database.schema.table)

        Returns:
            SQL query string that returns schema information

        """
        ...

    @abstractmethod
    def normalize_identifier(self, identifier: str) -> str:
        """
        Normalize an identifier for this platform.

        Each concrete query builder must define how unquoted identifiers are
        canonicalized (e.g. SQL Server uppercases, PostgreSQL lowercases).
        Already-quoted identifiers should be returned unchanged.

        Args:
            identifier: The identifier to normalize

        Returns:
            The normalized identifier

        """
        ...

    @abstractmethod
    def quote_column_name(self, column_name: str) -> str:
        """
        Quote a column name if needed by this platform.

        Each concrete query builder must define its quoting rules for
        identifiers that contain special characters, start with a digit, etc.

        Args:
            column_name: The column name to quote

        Returns:
            The column name, quoted only if necessary

        """
        ...

    def build_table_fqn(self, table_id: TableIdentifier) -> str:
        """
        Build a fully qualified table name with platform-appropriate normalization.

        Joins non-empty components with dots, applying
        :meth:`normalize_identifier` to each one.

        Args:
            table_id: Table identifier with database, schema, and table name

        Returns:
            Normalized fully qualified table name

        """
        db = table_id.database_name
        schema = table_id.schema_name
        table = table_id.table_name
        db_fragment = self.normalize_identifier(db) + "." if db else ""
        schema_fragment = self.normalize_identifier(schema) + "." if schema else ""
        return f"{db_fragment}{schema_fragment}{self.normalize_identifier(table)}"

    def build_partition_boundary_query(
        self,
        table_name: TableIdentifier,
        columns: list[str],
        num_partitions: int,
        row_count: int | None = None,
    ) -> str:
        """
        Generate SQL query to calculate partition boundaries.

        Uses NTILE on ``ORDER BY`` all partition columns. Single-column tables
        return scalar min/max; multi-column tables return ``min_0``..``min_n`` and
        ``max_0``..``max_n`` lex endpoints (encode with :func:`normalize_ntile_boundary_row`).

        Subclasses may override to use sampling for very large tables when
        ``row_count`` is provided.
        """
        if isinstance(columns, str):
            columns = [columns]
        if not columns:
            raise ValueError("columns must be non-empty")
        fqn = self.build_table_fqn(table_name)
        if len(columns) == 1:
            quoted_column = self.quote_identifier(columns[0])
            return f"""
WITH partitioned AS (
    SELECT
        {quoted_column},
        NTILE({num_partitions}) OVER (ORDER BY {quoted_column}) AS partition_id
    FROM {fqn}
)
SELECT
    partition_id,
    MIN({quoted_column}) AS min_value_in_partition,
    MAX({quoted_column}) AS max_value_in_partition,
    COUNT(*) AS n_rows
FROM partitioned
GROUP BY partition_id
ORDER BY partition_id
""".strip()

        quoted_cols = [self.quote_identifier(c) for c in columns]
        order_by = ", ".join(quoted_cols)
        order_by_desc = ", ".join(f"{c} DESC" for c in quoted_cols)
        select_cols = ", ".join(quoted_cols)
        min_select = ", ".join(
            f"MIN(CASE WHEN rn_asc = 1 THEN {c} END) AS min_{i}"
            for i, c in enumerate(quoted_cols)
        )
        max_select = ", ".join(
            f"MAX(CASE WHEN rn_desc = 1 THEN {c} END) AS max_{i}"
            for i, c in enumerate(quoted_cols)
        )

        return f"""
WITH partitioned AS (
    SELECT
        {select_cols},
        NTILE({num_partitions}) OVER (ORDER BY {order_by}) AS partition_id
    FROM {fqn}
),
ranked AS (
    SELECT
        {select_cols},
        partition_id,
        ROW_NUMBER() OVER (
            PARTITION BY partition_id ORDER BY {order_by}
        ) AS rn_asc,
        ROW_NUMBER() OVER (
            PARTITION BY partition_id ORDER BY {order_by_desc}
        ) AS rn_desc
    FROM partitioned
)
SELECT
    partition_id,
    {min_select},
    {max_select},
    COUNT(*) AS n_rows
FROM ranked
GROUP BY partition_id
ORDER BY partition_id
""".strip()

    def build_checksum_query(
        self,
        partition_info: PartitionInfo,
        source_table_id: TableIdentifier,
        columns: list[ColumnInfo],
    ) -> str:
        """
        Build a SQL query that computes a checksum for a partition.

        The query should:
        1. Select all rows within the partition boundaries
        2. Hash all column values for each row
        3. Aggregate row hashes into a single partition checksum
        4. Return a single row with a single column named 'checksum'

        Override in subclasses that support checksum-based incremental sync.
        The default raises ``NotImplementedError``.

        Args:
            partition_info: Information about the partition to checksum
            source_table_id: Fully qualified source table name
            columns: List of column metadata for the table

        Returns:
            SQL query string that computes the partition checksum

        Raises:
            NotImplementedError: If the platform does not support checksums

        """
        raise NotImplementedError(
            f"Checksum query building not supported for platform: {self.platform_name}"
        )

    @abstractmethod
    def quote_identifier(self, identifier: str) -> str:
        """
        Quote an identifier using platform-specific syntax.

        Args:
            identifier: Identifier to quote (table name, column name, etc.)

        Returns:
            Properly quoted identifier

        """
        ...

    @abstractmethod
    def build_select_query(
        self,
        table_name: TableIdentifier,
        column_types: list[dict[str, str]],
        where_clause: str | None = None,
    ) -> str:
        """
        Build a SELECT query with explicit columns and server-side type conversions.

        Args:
            table_name: Fully qualified table name
            column_types: Column definitions (``column_name``, ``data_type``)
            where_clause: Optional WHERE condition (without the WHERE keyword)

        Returns:
            SELECT SQL query

        """
        ...

    def build_extraction_query(
        self,
        table_name: TableIdentifier,
        source_schema: list[dict],
        partition_condition: str | None = None,
        sync_data: SyncData | None = None,
        where_clause_criteria: str | None = None,
    ) -> str:
        """
        Build a type-aware extraction SELECT from source schema.

        Combines partition boundaries and sync data conditions into a single
        extraction query. This is the main entry point for building extraction
        queries with all filtering conditions.

        Args:
            table_name: Fully qualified table name as a TableIdentifier
            source_schema: Source schema list with column_name and data_type keys
            partition_condition: Optional partition boundary condition (with or without WHERE)
            sync_data: Optional synchronization data for incremental sync conditions
            where_clause_criteria: Optional user-provided SQL condition to filter
                extracted data (without WHERE keyword). Does not affect partition
                boundary calculations.

        Returns:
            SELECT SQL query with type-aware column conversions and filtering

        """
        # Build WHERE clause from partition + sync + user criteria conditions
        where_clause = self.build_where_clause(
            partition_condition=partition_condition,
            sync_data=sync_data,
            where_clause_criteria=where_clause_criteria,
        )

        # Use lowercase keys to match the schema format from stage files
        column_types = [
            {COLUMN_NAME: col[COLUMN_NAME], DATA_TYPE: col[DATA_TYPE]}
            for col in source_schema
        ]
        return self.build_select_query(
            table_name=table_name,
            column_types=column_types,
            where_clause=where_clause,
        )

    def build_use_database_command(self, database: str) -> str | None:
        """
        Build a command to switch the active database on a connection.

        Override in subclasses for platforms that support runtime database
        switching (e.g., SQL Server's ``USE [db]``, MySQL's ``USE `db```).

        The default implementation returns ``None``, indicating the platform
        does not support switching databases after connection. For these
        platforms the database must be set in the connection string at
        connect time.

        Args:
            database: The target database name to switch to.

        Returns:
            The SQL command string, or ``None`` if the platform does not
            support runtime database switching.

        """
        return None

    def quote_string_literal(self, value: str) -> str:
        """
        Quote a string literal using platform-specific syntax.

        Args:
            value: String value to quote

        Returns:
            Properly quoted string literal

        """
        # Escape single quotes by doubling them
        escaped = value.replace("'", "''")
        return f"{self.string_literal_prefix}'{escaped}'"

    def format_sql_value(self, value: Any) -> str:
        """
        Format a value for use in SQL WHERE clauses.

        Override in subclasses for platform-specific formatting (e.g., datetime).
        The base implementation handles common types with simple quoting.

        Args:
            value: The value to format (None, int, float, str, datetime, etc.)

        Returns:
            A SQL-safe string representation of the value

        """
        if value is None:
            return "NULL"

        # ``bool`` must be checked before ``int | float`` because ``True`` /
        # ``False`` are instances of ``int`` in Python; without this branch a
        # boolean partition / watermark value would be rendered as ``1`` /
        # ``0`` and silently mismatch boolean predicates on the source.
        if isinstance(value, bool):
            return "TRUE" if value else "FALSE"

        if isinstance(value, (int | float)):
            return str(value)

        if isinstance(value, Decimal):
            return (
                str(int(value))
                if value == value.to_integral_value()
                else str(float(value))
            )

        if isinstance(value, datetime):
            # Default: ISO format string literal (subclasses can override)
            iso_str = value.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]
            return self.quote_string_literal(iso_str)

        if isinstance(value, str):
            # Remove surrounding double quotes if present (from Snowflake VARIANT)
            trimmed = value
            if value.startswith('"') and value.endswith('"'):
                trimmed = value[1:-1]

            coerced = coerce_partition_value(trimmed)
            if not isinstance(coerced, str):
                return self.format_sql_value(coerced)

            # Default: just quote the string (subclasses can handle datetime strings)
            return self.quote_string_literal(trimmed)

        # Fallback: convert to string and quote
        return self.quote_string_literal(str(value))

    def build_partition_condition(
        self,
        partition_columns: list[str] | str | None,
        min_value: Any | None,
        max_value: Any | None,
        *,
        upper_inclusive: bool = False,
    ) -> str:
        """
        Build SQL condition for partition boundaries (without WHERE keyword).

        Supports single- and multi-column lexicographic ranges. Interior partitions
        use ``>= min`` and ``< max`` when ``upper_inclusive`` is False; the last
        interior bucket uses ``<= max`` when ``upper_inclusive`` is True.

        Edge partitions:
        - Only ``max`` (lower edge): ``key < max``
        - Only ``min`` (upper edge): ``key > min``

        Args:
            partition_columns: Column name(s) used for partitioning, or None
            min_value: Encoded lower bound (scalar or delimited string)
            max_value: Encoded upper bound (scalar or delimited string)
            upper_inclusive: When both bounds are set, use ``<= max`` if True

        Returns:
            SQL condition string without the WHERE keyword

        """
        if min_value is None and max_value is None:
            return "1=1"
        if partition_columns is None:
            return "1=1"
        columns = (
            [partition_columns]
            if isinstance(partition_columns, str)
            else list(partition_columns)
        )
        if not columns:
            return "1=1"

        quote = self.quote_identifier
        fmt = self.format_sql_value

        if min_value is None and max_value is not None:
            upper = decode_partition_bound(max_value, columns)
            return build_lex_range_condition(
                columns,
                None,
                upper,
                upper_inclusive=False,
                quote_identifier=quote,
                format_value=fmt,
            )

        if max_value is None and min_value is not None:
            lower = decode_partition_bound(min_value, columns)
            return build_lex_range_condition(
                columns,
                lower,
                None,
                lower_inclusive=False,
                quote_identifier=quote,
                format_value=fmt,
            )

        partition_range = partition_range_from_encoded(
            columns,
            min_value,
            max_value,
            upper_inclusive=upper_inclusive,
        )
        return build_partition_range_condition(
            partition_range,
            quote_identifier=quote,
            format_value=fmt,
        )

    def build_fully_qualified_name(self, database: str, schema: str, table: str) -> str:
        """
        Build a fully qualified table name.

        Args:
            database: Database/catalog name
            schema: Schema name
            table: Table name

        Returns:
            Fully qualified table name with proper quoting

        """
        return (
            f"{self.quote_identifier(database)}."
            f"{self.quote_identifier(schema)}."
            f"{self.quote_identifier(table)}"
        )

    def build_where_clause(
        self,
        partition_condition: str | None = None,
        sync_data: SyncData | None = None,
        where_clause_criteria: str | None = None,
    ) -> str | None:
        """
        Build a WHERE clause combining partition boundaries, sync conditions, and user criteria.

        This method unifies the logic for building WHERE clauses from:
        - Partition boundary conditions (e.g., "col >= 1 AND col < 100")
        - Synchronization data conditions (e.g., watermark filters)
        - User-provided filter criteria (e.g., "is_deleted = 0")

        Args:
            partition_condition: Raw partition boundary condition string (without WHERE).
                Can come from PartitionBoundary.where_clause (stripped of "WHERE " prefix).
            sync_data: Optional synchronization data for incremental sync conditions.
                Currently supports WATERMARK strategy with max_watermark_value.
            where_clause_criteria: Optional user-provided SQL condition to filter
                extracted data (without WHERE keyword). Applied in addition to
                partition and sync conditions.

        Returns:
            Combined WHERE clause string (without "WHERE" keyword), or None if no conditions.

        Example:
            >>> builder.build_where_clause("id >= 1 AND id < 100", watermark_sync_data, "is_deleted = 0")
            "id >= 1 AND id < 100 AND timestamp > CONVERT(...) AND is_deleted = 0"

        """
        conditions: list[str] = []

        # Add partition boundary condition if provided
        if partition_condition:
            # Strip "WHERE " prefix if present (for backward compatibility)
            clean_condition = partition_condition.removeprefix("WHERE ").strip()
            if clean_condition:
                conditions.append(clean_condition)

        # Add sync data condition (watermark filter)
        if (
            sync_data is not None
            and sync_data.strategy == SyncStrategy.WATERMARK
            and isinstance(sync_data, WatermarkSyncData)
            and sync_data.max_watermark_value is not None
        ):
            formatted_value = self.format_sql_value(sync_data.max_watermark_value)
            watermark_condition = f"{self.quote_identifier(sync_data.watermark_column)} > {formatted_value}"
            conditions.append(watermark_condition)

        # Add user-provided filter criteria
        if where_clause_criteria:
            clean_criteria = where_clause_criteria.strip()
            if clean_criteria:
                conditions.append(clean_criteria)

        if not conditions:
            return None

        return " AND ".join(conditions)
