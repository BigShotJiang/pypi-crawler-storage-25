"""Coerce partition boundary values from storage representations."""

from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Any


def coerce_partition_value(value: Any) -> Any:
    """
    Convert partition boundaries to native numeric types when possible.

    Partition boundaries stored in Snowflake PARTITION_METADATA are often
    retrieved as strings (e.g. ``'1718751.0000000000'``) or as ``Decimal``
    objects.
    """
    if isinstance(value, Decimal):
        return int(value) if value == value.to_integral_value() else float(value)
    if not isinstance(value, str):
        return value
    try:
        d = Decimal(value)
        return int(d) if d == d.to_integral_value() else d
    except (InvalidOperation, ValueError):
        return value
