r"""
Lexicographic partition bounds for single- and multi-column partitioning.

Single-column bounds are stored as plain scalars in PARTITION_METADATA. Two or
more columns are stored as delimiter-separated strings (ASCII unit separator
``\x1f``), in ``columnNamesToPartitionBy`` order. Delimiter characters inside
string components are escaped with a backslash.
"""

from __future__ import annotations

import json
import re

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from data_migration_orchestrator.data_migration_cloud.partition.coercion import (
    coerce_partition_value,
)


# ASCII unit separator — unlikely in numeric/date partition keys.
PARTITION_BOUND_DELIMITER = "\x1f"

_ESCAPE_CHAR = "\\"


@dataclass(frozen=True)
class PartitionRange:
    """Lexicographic partition slice over ordered columns."""

    columns: list[str]
    lower: list[Any] | None
    upper: list[Any] | None
    upper_inclusive: bool = False

    @property
    def is_single_column(self) -> bool:
        """Return ``True`` when this range is over a single partition column."""
        return len(self.columns) == 1


def _escape_component(value: str) -> str:
    return value.replace(_ESCAPE_CHAR, _ESCAPE_CHAR + _ESCAPE_CHAR).replace(
        PARTITION_BOUND_DELIMITER, _ESCAPE_CHAR + PARTITION_BOUND_DELIMITER
    )


def _unescape_component(value: str) -> str:
    out: list[str] = []
    i = 0
    while i < len(value):
        if value[i] == _ESCAPE_CHAR and i + 1 < len(value):
            out.append(value[i + 1])
            i += 2
        else:
            out.append(value[i])
            i += 1
    return "".join(out)


def _component_to_storage(value: Any) -> str:
    if value is None:
        return ""
    return _escape_component(str(value))


def encode_partition_bound(columns: list[str], values: list[Any]) -> Any:
    """
    Encode partition bound values for PARTITION_METADATA storage.

    One column → scalar; two or more → delimiter-separated string.
    """
    if not columns:
        raise ValueError("columns must be non-empty")
    if len(values) != len(columns):
        raise ValueError(f"Expected {len(columns)} bound values, got {len(values)}")
    if len(columns) == 1:
        return values[0]
    return PARTITION_BOUND_DELIMITER.join(_component_to_storage(v) for v in values)


def _normalize_stored_bound_raw(raw: str) -> str:
    r"""
    Normalize PARTITION_METADATA VARIANT round-trips before delimiter split.

    Snowflake / connectors may return a JSON-encoded string (with ``\u001f`` for
    the unit separator) or wrap the value in extra quote characters.
    """
    s = raw.strip()
    if not s:
        return s

    if s[0] == '"' and s[-1] == '"':
        try:
            parsed = json.loads(s)
            if isinstance(parsed, str):
                s = parsed
        except json.JSONDecodeError:
            s = s[1:-1]

    if PARTITION_BOUND_DELIMITER not in s:
        for pattern in (r"\\u001f", r"\\U001F", r"\\x1f", r"\\X1F"):
            if re.search(pattern, s, flags=re.IGNORECASE):
                s = re.sub(pattern, PARTITION_BOUND_DELIMITER, s, flags=re.IGNORECASE)
                break

    return s


def decode_partition_bound(raw: Any, columns: list[str]) -> list[Any]:
    """
    Decode a stored partition bound into per-column values.

    Accepts legacy scalars (single column) or delimiter-separated strings.
    """
    if not columns:
        raise ValueError("columns must be non-empty")
    if raw is None:
        raise ValueError("partition bound is None")

    if len(columns) == 1:
        return [coerce_partition_value(raw)]

    if not isinstance(raw, str):
        raw = str(raw)

    raw = _normalize_stored_bound_raw(raw)
    parts = _split_delimited_bound(raw)
    if len(parts) != len(columns):
        raise ValueError(
            f"Expected {len(columns)} components in bound {raw!r}, got {len(parts)}"
        )
    return [coerce_partition_value(_unescape_component(p)) for p in parts]


def _split_delimited_bound(raw: str) -> list[str]:
    parts: list[str] = []
    current: list[str] = []
    i = 0
    while i < len(raw):
        if raw[i] == _ESCAPE_CHAR and i + 1 < len(raw):
            current.append(raw[i + 1])
            i += 2
        elif raw[i] == PARTITION_BOUND_DELIMITER:
            parts.append("".join(current))
            current = []
            i += 1
        else:
            current.append(raw[i])
            i += 1
    parts.append("".join(current))
    return parts


def compare_lex(values: list[Any], bound: list[Any]) -> int:
    """
    Compare *values* to *bound* lexicographically.

    Returns -1 if values < bound, 0 if equal, 1 if values > bound.
    """
    for v, b in zip(values, bound, strict=True):
        cv = coerce_partition_value(v)
        cb = coerce_partition_value(b)
        if cv == cb:
            continue
        if cv < cb:
            return -1
        return 1
    return 0


def _lex_gte_condition(
    columns: list[str],
    bound: list[Any],
    *,
    inclusive: bool,
    quote_identifier: Callable[[str], str],
    format_value: Callable[[Any], str],
) -> str:
    """
    Build SQL for lex (c1, c2, ...) >= bound (or > when not inclusive).

    Prefix columns use strict ``>``; only the last column uses ``>=`` when
    *inclusive* (interior lower bound), or ``>`` when exclusive (upper edge).
    """
    n = len(columns)
    parts: list[str] = []
    prefix_eq: list[str] = []
    for i, (col, val) in enumerate(zip(columns, bound, strict=True)):
        quoted = quote_identifier(col)
        formatted = format_value(val)
        if i < n - 1:
            op = ">"
        else:
            op = ">=" if inclusive else ">"
        eq_chain = " AND ".join(prefix_eq) if prefix_eq else ""
        if eq_chain:
            parts.append(f"({eq_chain} AND {quoted} {op} {formatted})")
        else:
            parts.append(f"{quoted} {op} {formatted}")
        prefix_eq = [*prefix_eq, f"{quoted} = {formatted}"]
    return "(" + " OR ".join(parts) + ")"


def _lex_lt_condition(
    columns: list[str],
    bound: list[Any],
    *,
    inclusive: bool,
    quote_identifier: Callable[[str], str],
    format_value: Callable[[Any], str],
) -> str:
    """
    Build SQL for lex (c1, c2, ...) < bound (or <= when inclusive).

    Prefix columns use strict ``<``; only the last column uses ``<=`` when
    *inclusive* (last interior bucket), or ``<`` when exclusive.
    """
    n = len(columns)
    parts: list[str] = []
    prefix_eq: list[str] = []
    for i, (col, val) in enumerate(zip(columns, bound, strict=True)):
        quoted = quote_identifier(col)
        formatted = format_value(val)
        if i < n - 1:
            op = "<"
        else:
            op = "<=" if inclusive else "<"
        eq_chain = " AND ".join(prefix_eq) if prefix_eq else ""
        if eq_chain:
            parts.append(f"({eq_chain} AND {quoted} {op} {formatted})")
        else:
            parts.append(f"{quoted} {op} {formatted}")
        prefix_eq = [*prefix_eq, f"{quoted} = {formatted}"]
    return "(" + " OR ".join(parts) + ")"


def build_lex_range_condition(
    columns: list[str],
    lower: list[Any] | None,
    upper: list[Any] | None,
    *,
    lower_inclusive: bool = True,
    upper_inclusive: bool = False,
    quote_identifier: Callable[[str], str],
    format_value: Callable[[Any], str],
) -> str:
    """
      Build a lexicographic range predicate without the WHERE keyword.

    Interior (non-last): lower_inclusive=True, upper_inclusive=False → [L, H).
    """
    if not columns:
        return "1=1"
    if lower is None and upper is None:
        return "1=1"

    conditions: list[str] = []
    if lower is not None:
        if len(lower) != len(columns):
            raise ValueError("lower bound length does not match columns")
        conditions.append(
            _lex_gte_condition(
                columns,
                lower,
                inclusive=lower_inclusive,
                quote_identifier=quote_identifier,
                format_value=format_value,
            )
        )
    if upper is not None:
        if len(upper) != len(columns):
            raise ValueError("upper bound length does not match columns")
        conditions.append(
            _lex_lt_condition(
                columns,
                upper,
                inclusive=upper_inclusive,
                quote_identifier=quote_identifier,
                format_value=format_value,
            )
        )
    return " AND ".join(conditions) if conditions else "1=1"


def build_partition_range_condition(
    partition_range: PartitionRange,
    *,
    quote_identifier: Callable[[str], str],
    format_value: Callable[[Any], str],
) -> str:
    """Build SQL for a :class:`PartitionRange`."""
    lower = partition_range.lower
    upper = partition_range.upper

    if lower is None and upper is None:
        return "1=1"

    if partition_range.is_single_column:
        col = partition_range.columns[0]
        quoted = quote_identifier(col)
        conditions: list[str] = []
        if lower is not None:
            lv = coerce_partition_value(lower[0])
            conditions.append(f"{quoted} >= {format_value(lv)}")
        if upper is not None:
            uv = coerce_partition_value(upper[0])
            op = "<=" if partition_range.upper_inclusive else "<"
            conditions.append(f"{quoted} {op} {format_value(uv)}")
        return " AND ".join(conditions) if conditions else "1=1"

    return build_lex_range_condition(
        partition_range.columns,
        lower,
        upper,
        lower_inclusive=True,
        upper_inclusive=partition_range.upper_inclusive,
        quote_identifier=quote_identifier,
        format_value=format_value,
    )


def partition_range_from_encoded(
    columns: list[str],
    min_value: Any | None,
    max_value: Any | None,
    *,
    upper_inclusive: bool,
) -> PartitionRange:
    """Build a :class:`PartitionRange` from stored metadata values."""
    lower = (
        decode_partition_bound(min_value, columns) if min_value is not None else None
    )
    upper = (
        decode_partition_bound(max_value, columns) if max_value is not None else None
    )
    return PartitionRange(
        columns=columns,
        lower=lower,
        upper=upper,
        upper_inclusive=upper_inclusive,
    )


def apply_column_name_mappings(
    columns: list[str],
    mappings: dict[str, str],
) -> list[str]:
    """Map source partition column names to target names where configured."""
    if not mappings:
        return list(columns)
    return [mappings.get(c, c) for c in columns]


def _row_get(row: dict, key: str) -> Any:
    if key in row:
        return row[key]
    upper = key.upper()
    if upper in row:
        return row[upper]
    lower = key.lower()
    if lower in row:
        return row[lower]
    return None


def normalize_ntile_boundary_row(row: dict, columns: list[str]) -> dict:
    """
    Normalize a boundary query row to ``min_value_in_partition`` / ``max_value_in_partition``.

    Single-column rows pass through. Multi-column rows read ``min_0``..``min_n`` and
    ``max_0``..``max_n`` (or legacy scalar fields) and encode delimited bounds.
    """
    out = dict(row)
    if len(columns) == 1:
        if _row_get(row, "min_value_in_partition") is not None:
            out["min_value_in_partition"] = _row_get(row, "min_value_in_partition")
        if _row_get(row, "max_value_in_partition") is not None:
            out["max_value_in_partition"] = _row_get(row, "max_value_in_partition")
        return out

    min_vals: list[Any] = []
    max_vals: list[Any] = []
    for i in range(len(columns)):
        min_v = _row_get(row, f"min_{i}")
        max_v = _row_get(row, f"max_{i}")
        if min_v is None:
            min_v = _row_get(row, f"min_{columns[i]}")
        if max_v is None:
            max_v = _row_get(row, f"max_{columns[i]}")
        min_vals.append(min_v)
        max_vals.append(max_v)

    if any(v is None for v in min_vals + max_vals):
        legacy_min = _row_get(row, "min_value_in_partition")
        legacy_max = _row_get(row, "max_value_in_partition")
        if legacy_min is not None and legacy_max is not None:
            return out
        raise ValueError(f"Boundary row missing per-column min/max fields: {row!r}")

    out["min_value_in_partition"] = encode_partition_bound(columns, min_vals)
    out["max_value_in_partition"] = encode_partition_bound(columns, max_vals)
    return out


def normalize_ntile_boundary_rows(rows: list[dict], columns: list[str]) -> list[dict]:
    """Normalize all boundary rows for downstream boundary generation."""
    return [normalize_ntile_boundary_row(row, columns) for row in rows]


def infer_boundary_flags(
    partition_number: int,
    min_value: Any | None,
    max_value: Any | None,
    *,
    num_partitions: int | None = None,
) -> tuple[bool, bool, bool]:
    """
      Return ``(is_lower_edge, is_upper_edge, is_last_interior)`` from stored bounds.

      Lower edge rows use ``min_value is None``; upper edge use ``max_value is None``.
    When *num_partitions* is provided, the last interior bucket is ``partition_number
      == num_partitions`` (NTILE ids ``1..num_partitions``).
    """
    if min_value is None and max_value is not None:
        return True, False, False
    if max_value is None and min_value is not None:
        return False, True, False
    is_last_interior = (
        num_partitions is not None
        and partition_number == num_partitions
        and min_value is not None
        and max_value is not None
    )
    return False, False, is_last_interior
