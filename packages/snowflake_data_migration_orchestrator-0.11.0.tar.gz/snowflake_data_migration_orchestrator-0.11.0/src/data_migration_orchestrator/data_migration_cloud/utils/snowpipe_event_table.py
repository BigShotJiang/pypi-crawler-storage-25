"""On-demand setup of the Snowflake event table required by Snowpipe loading."""

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.utils.snowflake_metadata import (
    metadata_database,
    qualified_event_table,
)


logger = get_logger("snowpipe_event_table")


async def setup_snowpipe_for_data_migration(warehouse: Warehouse) -> None:
    """
    Create the event table and bind it to the metadata database.

    This must be called before any Snowpipe-based loading workflow runs,
    because pipes rely on ``file_lifecycle`` events to track ingestion
    progress.

    Raises:
        RuntimeError: If ``ALTER DATABASE … SET EVENT_TABLE`` fails, which
            typically means database-scoped event tables are not supported
            on the account.

    """
    event_table = qualified_event_table()
    db = metadata_database()

    await warehouse.execute_sync_query(
        f"CREATE EVENT TABLE IF NOT EXISTS {event_table}"
    )

    try:
        await warehouse.execute_sync_query(
            f"ALTER DATABASE {db} SET EVENT_TABLE = {event_table}"
        )
    except Exception as e:
        raise RuntimeError(
            f"Failed to set database-scoped event table on '{db}'. "
            "This likely means database-scoped event tables are not supported "
            "on your Snowflake account. "
            'To proceed, avoid using the "snowpipe" loading strategy '
            "in your workflow configuration."
        ) from e

    logger.info("Snowpipe event table configured: %s on database %s", event_table, db)
