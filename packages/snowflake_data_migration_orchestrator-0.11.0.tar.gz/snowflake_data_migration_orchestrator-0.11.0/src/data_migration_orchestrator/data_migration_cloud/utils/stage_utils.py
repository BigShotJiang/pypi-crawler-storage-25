"""Utilities for reading staged data in Snowflake."""

from __future__ import annotations

import asyncio

from dataclasses import dataclass
from typing import Any

from data_migration_orchestrator.cloud_core.constants.file_formats import (
    parquet_file_format_fqn,
)
from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.constants.stages import (
    default_internal_stage,
)


logger = get_logger("utils.stage_utils")


@dataclass(frozen=True)
class ObjectTypeFromStageResult:
    """Outcome of querying staged object_type Parquet via Snowflake."""

    value: str | None
    """Resolved type string (e.g. TABLE) or None when missing/unreadable."""

    snowflake_row_count: int
    """Rows returned by the stage query (0 means no Parquet matched)."""


# =============================================================================
# Stage Resolution for Extraction Strategies
# =============================================================================


@dataclass
class StageResolution:
    """Result of resolving stage information for an extraction strategy."""

    stage_id: str
    """The Snowflake stage identifier to use (e.g., @MY_DB.MY_SCHEMA.MY_STAGE)"""

    is_external: bool
    """Whether this is an external stage (e.g., S3-backed)"""

    external_stage_base_path: str | None = None
    """
    For external stages, the base path within the stage for data files.
    This path is relative to the stage root and maps to the S3 prefix.
    Example: If stage points to s3://bucket/prefix/ and data is at
    s3://bucket/prefix/workflow_1/table_2/, this would be "workflow_1/table_2/"
    """


def resolve_stage_for_strategy(
    extraction_strategy: ExtractionStrategy,
    strategy_config: dict[str, Any] | None = None,
    workflow_external_stage: str | None = None,
    table_external_stage: str | None = None,
) -> StageResolution:
    """
    Resolve the appropriate stage to use based on the extraction strategy.

    Different extraction strategies may require different stages:

    - REGULAR: Uses the default internal stage (@TASK_RESULTS)
    - UNLOAD: Uses an external stage pointing to S3 (configured via
      table_external_stage, strategy_config, or workflow_external_stage)
    - WRITE_NOS: Uses an external stage pointing to cloud storage (S3, Azure
      Blob, or GCS) where Teradata WRITE_NOS wrote Parquet files. Same
      resolution rules as UNLOAD.

    For the UNLOAD / WRITE_NOS strategies, the external stage can be
    configured (in order of precedence):

    1. Via the ``table_external_stage`` parameter (from the table's
       ``strategy.externalStage`` config)
    2. Via ``external_stage`` in ``strategy_config`` (workflow-level config)
    3. Via the ``workflow_external_stage`` parameter (fallback, typically from
       the workflow's ``target_cloud_stage_name``)

    The stage should be a Snowflake external stage that points to the cloud
    storage bucket where the source database wrote the data.

    Args:
        extraction_strategy: The extraction strategy being used
        strategy_config: Strategy-specific configuration from the workflow (deprecated)
        workflow_external_stage: Optional fallback external stage from workflow config
        table_external_stage: External stage from table's strategy configuration

    Returns:
        StageResolution containing stage_id, is_external flag, and optional base path

    Raises:
        ValueError: If UNLOAD or WRITE_NOS strategy is used but no
            external_stage is available.

    Example:
        >>> result = resolve_stage_for_strategy(
        ...     ExtractionStrategy.UNLOAD,
        ...     table_external_stage="@MY_DB.MY_SCHEMA.S3_STAGE"
        ... )
        >>> result.stage_id
        '@MY_DB.MY_SCHEMA.S3_STAGE'
        >>> result.is_external
        True

    """
    if extraction_strategy in (ExtractionStrategy.UNLOAD, ExtractionStrategy.WRITE_NOS):
        strategy_label = extraction_strategy.value.upper()

        # Priority: table config > workflow strategy_config > workflow external stage
        external_stage = table_external_stage

        if not external_stage and strategy_config:
            external_stage = strategy_config.get("external_stage")

        if not external_stage:
            external_stage = workflow_external_stage

        if not external_stage:
            raise ValueError(
                f"{strategy_label} extraction strategy requires 'externalStage' in "
                "the table's strategy configuration or a workflow-level external "
                "stage. This should be a Snowflake external stage pointing to the "
                "cloud storage bucket where "
                f"{strategy_label} will write data "
                "(e.g., @MY_DB.MY_SCHEMA.CLOUD_STAGE)."
            )

        # Normalize the stage identifier (ensure it starts with @)
        stage_id = (
            external_stage if external_stage.startswith("@") else f"@{external_stage}"
        )

        # Optional path prefix for path computation; the legacy ``s3_prefix``
        # key is preserved so workflow_configs that already use it keep
        # working for both UNLOAD (S3) and WRITE_NOS (S3/Azure/GCS).
        cloud_prefix = ""
        if strategy_config:
            raw_prefix = strategy_config.get("s3_prefix", "")
            if raw_prefix:
                cloud_prefix = str(raw_prefix).strip("/")

        return StageResolution(
            stage_id=stage_id,
            is_external=True,
            external_stage_base_path=cloud_prefix if cloud_prefix else None,
        )

    # Default: REGULAR strategy uses internal stage
    return StageResolution(
        stage_id=default_internal_stage(),
        is_external=False,
    )


# =============================================================================
# Stage File Listing
# =============================================================================


@dataclass(frozen=True)
class StageFile:
    """A single file listed from a Snowflake stage."""

    name: str
    """Relative file name (e.g. ``'0000_part_00.parquet'``)."""

    size_bytes: int
    """File size in bytes as reported by ``LIST``."""


async def list_stage_files(warehouse_proxy: Any, stage_path: str) -> list[StageFile]:
    """
    List files in a Snowflake stage directory via ``LIST @stage/path/``.

    Snowflake ``LIST`` returns rows with columns: ``name``, ``size``,
    ``md5``, ``last_modified``.  The ``name`` column contains the full
    path relative to the stage root (without the ``@STAGE/`` prefix).
    This function strips everything up to and including the last directory
    component of *stage_path* so the returned names are relative to
    *stage_path*.

    Args:
        warehouse_proxy: Object with an ``execute_sync_query`` async method.
        stage_path: Full stage path (e.g. ``@MY_STAGE/task_results/.../data/full_table/``).

    Returns:
        List of ``StageFile`` instances sorted by name.

    """
    query = f"LIST {stage_path}"
    logger.info(f"Listing stage files: {query}")

    rows = await warehouse_proxy.execute_sync_query(query)

    if not rows:
        return []

    # Determine the prefix to strip from the ``name`` column.
    # LIST returns paths like ``stage_name/relative/path/file.parquet``.
    # We want just the filename portion relative to *stage_path*.
    # Strip the leading ``@`` and normalise trailing slash.
    stripped = stage_path.lstrip("@").rstrip("/") + "/"

    files: list[StageFile] = []
    for row in rows:
        full_name: str = row.get("name") or row.get("NAME") or ""
        size_raw = row.get("size") or row.get("SIZE") or 0

        # Strip the stage-path prefix to get the relative filename
        if full_name.startswith(stripped):
            relative_name = full_name[len(stripped) :]
        else:
            relative_name = full_name.rsplit("/", 1)[-1]

        if not relative_name:
            continue

        files.append(StageFile(name=relative_name, size_bytes=int(size_raw)))

    files.sort(key=lambda f: f.name)
    logger.info(f"Listed {len(files)} file(s) at {stage_path}")
    return files


def build_external_stage_data_path(
    stage_resolution: StageResolution,
    workflow_id: int,
    table_metadata_id: int,
    partition_index: int,
) -> str:
    """
    Build the full path for data files when using an external stage.

    For UNLOAD strategy, data is written directly to S3 by Redshift, and then
    Snowflake reads it via an external stage. Uses the same relative path
    structure as internal stages for consistency.

    Args:
        stage_resolution: The resolved stage information
        workflow_id: The workflow ID
        table_metadata_id: The table metadata ID
        partition_index: The partition index

    Returns:
        Full stage path for the partition data (stage + optional base path + relative path)

    """
    # Build the base: stage_id + optional external_stage_base_path
    base_parts = [stage_resolution.stage_id.rstrip("/")]
    if stage_resolution.external_stage_base_path:
        base_parts.append(stage_resolution.external_stage_base_path.strip("/"))

    base = "/".join(base_parts)

    # Use the standard relative path structure
    relative = relative_path_for_partition_data(
        workflow_id, table_metadata_id, partition_index
    )

    return f"{base}/{relative}"


# =============================================================================
# Deterministic Path Computation Functions
# =============================================================================
#
# Paths follow a consistent structure with two layers:
#
# 1. RELATIVE PATHS (platform-agnostic, no base):
#    task_results/workflows/{workflow_id}/tables/{table_metadata_id}/{subfolder}
#
# 2. ABSOLUTE PATHS (with base):
#    - Snowflake stage: @{stage_id}/{relative_path}
#    - S3 (for UNLOAD): DEA prepends its configured s3_bucket + s3_prefix
#
# Where {subfolder} can be:
#   - data/full_table or data/partition_{N} - extracted data files
#   - schema/ - source table schema metadata
#   - metadata/ - table row count and size metadata
#   - boundaries/ - partition boundary definitions
#   - checksum/partition_{N} - checksum computation results
#
# Both internal stage uploads and UNLOAD use the same relative path structure.
# =============================================================================


# -----------------------------------------------------------------------------
# Relative Path Functions (platform-agnostic, no base)
# -----------------------------------------------------------------------------
# These functions generate paths without any base prefix.
# Use these when you need to:
#   - Pass relative paths to external systems (e.g., DEA for UNLOAD)
#   - Build paths that will have different bases in different contexts
# -----------------------------------------------------------------------------


def _relative_base_path(workflow_id: int, table_metadata_id: int) -> str:
    """
    Generate the relative base path for a table in a workflow.

    This is the root path structure (without any stage/S3 prefix) under which
    all table-related artifacts are stored.

    Args:
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata

    Returns:
        Relative path like task_results/workflows/{id}/tables/{id}

    """
    return f"task_results/workflows/{workflow_id}/tables/{table_metadata_id}"


def relative_path_for_partition_data(
    workflow_id: int, table_metadata_id: int, partition_index: int
) -> str:
    """
    Generate the relative path for partition data (no base prefix).

    Use this for UNLOAD operations where the DEA will prepend its S3 bucket,
    or when you need just the path structure.

    Args:
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata
        partition_index: The index of the partition (0 for full table, >0 for partitions)

    Returns:
        Relative path like task_results/.../data/partition_{N}/

    """
    base_path = _relative_base_path(workflow_id, table_metadata_id)
    partition_fragment = (
        f"partition_{partition_index}" if partition_index > 0 else "full_table"
    )
    return f"{base_path}/data/{partition_fragment}/"


def relative_path_for_schema(workflow_id: int, table_metadata_id: int) -> str:
    """
    Generate the relative path for source table schema metadata (no base prefix).

    Args:
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata

    Returns:
        Relative path like task_results/.../schema/

    """
    base_path = _relative_base_path(workflow_id, table_metadata_id)
    return f"{base_path}/schema/"


def relative_path_for_metadata(workflow_id: int, table_metadata_id: int) -> str:
    """
    Generate the relative path for table metadata (no base prefix).

    Args:
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata

    Returns:
        Relative path like task_results/.../metadata/

    """
    base_path = _relative_base_path(workflow_id, table_metadata_id)
    return f"{base_path}/metadata/"


def relative_path_for_boundaries(workflow_id: int, table_metadata_id: int) -> str:
    """
    Generate the relative path for partition boundaries (no base prefix).

    Args:
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata

    Returns:
        Relative path like task_results/.../boundaries/

    """
    base_path = _relative_base_path(workflow_id, table_metadata_id)
    return f"{base_path}/boundaries/"


def relative_path_for_object_type(workflow_id: int, table_metadata_id: int) -> str:
    """
    Generate the relative path for object-type detection results (no base prefix).

    Args:
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata

    Returns:
        Relative path like task_results/.../object_type/

    """
    base_path = _relative_base_path(workflow_id, table_metadata_id)
    return f"{base_path}/object_type/"


def relative_path_for_checksum(
    workflow_id: int, table_metadata_id: int, partition_index: int
) -> str:
    """
    Generate the relative path for checksum results (no base prefix).

    Args:
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata
        partition_index: The index of the partition

    Returns:
        Relative path like task_results/.../checksum/partition_{N}/

    """
    base_path = _relative_base_path(workflow_id, table_metadata_id)
    return f"{base_path}/checksum/partition_{partition_index}/"


# -----------------------------------------------------------------------------
# Stage Path Functions (Snowflake stage base + relative path)
# -----------------------------------------------------------------------------
# These functions prepend a Snowflake stage identifier to the relative path.
# Use these when working with Snowflake internal stages.
# -----------------------------------------------------------------------------


def stage_path_for_partition_data(
    stage_id: str, workflow_id: int, table_metadata_id: int, partition_index: int
) -> str:
    """
    Generate the full stage path for partition data in Snowflake.

    Args:
        stage_id: The Snowflake stage identifier (e.g., @MY_DB.MY_SCHEMA.MY_STAGE)
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata
        partition_index: The index of the partition (0 for full table, >0 for partitions)

    Returns:
        Full path like @STAGE/task_results/.../data/partition_{N}/

    """
    relative = relative_path_for_partition_data(
        workflow_id, table_metadata_id, partition_index
    )
    return f"{stage_id}/{relative}"


def stage_path_for_schema(
    stage_id: str, workflow_id: int, table_metadata_id: int
) -> str:
    """
    Generate the full stage path for source table schema metadata.

    Args:
        stage_id: The Snowflake stage identifier (e.g., @MY_DB.MY_SCHEMA.MY_STAGE)
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata

    Returns:
        Full path like @STAGE/task_results/.../schema/

    """
    relative = relative_path_for_schema(workflow_id, table_metadata_id)
    return f"{stage_id}/{relative}"


def stage_path_for_metadata(
    stage_id: str, workflow_id: int, table_metadata_id: int
) -> str:
    """
    Generate the full stage path for table metadata (row count, size).

    Args:
        stage_id: The Snowflake stage identifier (e.g., @MY_DB.MY_SCHEMA.MY_STAGE)
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata

    Returns:
        Full path like @STAGE/task_results/.../metadata/

    """
    relative = relative_path_for_metadata(workflow_id, table_metadata_id)
    return f"{stage_id}/{relative}"


def stage_path_for_boundaries(
    stage_id: str, workflow_id: int, table_metadata_id: int
) -> str:
    """
    Generate the full stage path for partition boundaries.

    Args:
        stage_id: The Snowflake stage identifier (e.g., @MY_DB.MY_SCHEMA.MY_STAGE)
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata

    Returns:
        Full path like @STAGE/task_results/.../boundaries/

    """
    relative = relative_path_for_boundaries(workflow_id, table_metadata_id)
    return f"{stage_id}/{relative}"


def stage_path_for_checksum(
    stage_id: str, workflow_id: int, table_metadata_id: int, partition_index: int
) -> str:
    """
    Generate the full stage path for checksum computation results.

    Args:
        stage_id: The Snowflake stage identifier (e.g., @MY_DB.MY_SCHEMA.MY_STAGE)
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata
        partition_index: The index of the partition

    Returns:
        Full path like @STAGE/task_results/.../checksum/partition_{N}/

    """
    relative = relative_path_for_checksum(
        workflow_id, table_metadata_id, partition_index
    )
    return f"{stage_id}/{relative}"


def stage_path_for_object_type(
    stage_id: str, workflow_id: int, table_metadata_id: int
) -> str:
    """
    Generate the full stage path for object-type detection results.

    Args:
        stage_id: The Snowflake stage identifier (e.g., @MY_DB.MY_SCHEMA.MY_STAGE)
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata

    Returns:
        Full path like @STAGE/task_results/.../object_type/

    """
    relative = relative_path_for_object_type(workflow_id, table_metadata_id)
    return f"{stage_id}/{relative}"


async def read_object_type_from_stage(
    warehouse_proxy, object_type_location: str
) -> ObjectTypeFromStageResult:
    """
    Read the object type string from Snowflake stage.

    Returns :class:`ObjectTypeFromStageResult`: ``value`` is the raw object type
    (e.g. ``'TABLE'``, ``'VIEW'``) or ``None`` when no Parquet rows matched or the
    value could not be extracted. Use ``snowflake_row_count`` to distinguish
    those cases (0 vs greater than zero).
    """
    # Parquet from Oracle/pyodbc uses uppercase OBJECT_TYPE; Snowflake path access is picky.
    # Also try GET (variant) and scalar $1 (single-column Parquet edge cases).
    query = f"""
        SELECT
            COALESCE(
                $1:"OBJECT_TYPE"::VARCHAR,
                $1:"object_type"::VARCHAR,
                GET($1, 'OBJECT_TYPE')::VARCHAR,
                GET($1, 'object_type')::VARCHAR,
                $1::VARCHAR
            ) AS object_type
        FROM {object_type_location}
        (FILE_FORMAT => '{parquet_file_format_fqn()}',
        PATTERN => '.*[.]parquet')
        LIMIT 1
    """
    logger.info(f"Read object type from stage: {query}")

    result = await warehouse_proxy.execute_sync_query(query)
    row_count = len(result)

    if not result:
        return ObjectTypeFromStageResult(None, 0)

    row = result[0]
    raw = row.get("OBJECT_TYPE") or row.get("object_type")
    if raw is None:
        # Snowflake connector may use other aliases for the single selected column.
        for _k, v in row.items():
            if v is not None and str(v).strip():
                raw = v
                break
    if raw is None:
        logger.warning(
            "read_object_type_from_stage: no value extracted; row=%r location=%s",
            row,
            object_type_location,
        )
        return ObjectTypeFromStageResult(None, row_count)

    return ObjectTypeFromStageResult(str(raw).strip().strip('"'), row_count)


async def read_metadata_from_stage(
    warehouse_proxy, metadata_location: str
) -> dict[str, Any]:
    """
    Read table metadata from Snowflake stage.

    Queries staged Parquet file directly without loading.
    Returns: {'row_count': int, 'data_size_mb': float}

    Fails fast if the staged file contains more than one row. Each platform's
    ``build_metadata_query`` is required to return exactly one row per logical
    table (see SNOW-3454590); silently dropping extra rows would mask
    duplicate-row bugs in the source catalog query and lead to silent target
    duplication downstream.
    """
    # Parquet column names come from the DEA/driver (often UPPERCASE). Snowflake ``$1:row_count``
    # is case-sensitive, so we COALESCE upper/lower keys only.
    # Casts: direct ``VARIANT::NUMBER`` can fail Snowflake compilation or yield NULL; use
    # ``TO_VARCHAR`` + ``TRY_TO_NUMBER`` / ``TRY_TO_DOUBLE`` (not related to case).
    query = f"""
        SELECT
            TRY_TO_NUMBER(TO_VARCHAR(COALESCE(
                $1:"ROW_COUNT",
                $1:"row_count",
                GET($1, 'ROW_COUNT'),
                GET($1, 'row_count')
            ))) AS row_count,
            COALESCE(
                TRY_TO_DOUBLE(TO_VARCHAR(COALESCE(
                    $1:"DATA_SIZE_MB",
                    $1:"data_size_mb",
                    GET($1, 'DATA_SIZE_MB'),
                    GET($1, 'data_size_mb')
                ))),
                TRY_TO_NUMBER(TO_VARCHAR(COALESCE(
                    $1:"DATA_SIZE_MB",
                    $1:"data_size_mb",
                    GET($1, 'DATA_SIZE_MB'),
                    GET($1, 'data_size_mb')
                ))),
                0::FLOAT
            ) AS data_size_mb
        FROM {metadata_location}
        (FILE_FORMAT => '{parquet_file_format_fqn()}',
        PATTERN => '.*[.]parquet')
    """
    logger.info(f"Read metadata from stage: {query}")

    result = await warehouse_proxy.execute_sync_query(query)

    if not result:
        raise ValueError(
            f"No metadata found at {metadata_location}. "
            "This typically indicates that the source table does not exist or is empty. "
            "Please verify that the table name specified in your configuration exists "
            "in the source database."
        )

    if len(result) > 1:
        raise ValueError(
            f"Source platform metadata extraction returned {len(result)} rows "
            f"at {metadata_location}; expected exactly 1. This indicates the "
            f"platform's metadata query did not collapse duplicate catalog "
            f"entries (e.g. missing aggregation/DISTINCT for tables with "
            f"DISTSTYLE=ALL + AUTO(SORTKEY) on Redshift). Refusing to proceed "
            f"to avoid silent row duplication in the target."
        )

    row = result[0]

    # Extract values from result (Snowflake returns uppercase column names)
    row_count_raw = row.get("ROW_COUNT") or row.get("row_count")
    data_size_mb_raw = row.get("DATA_SIZE_MB") or row.get("data_size_mb")

    if row_count_raw is None:
        raise ValueError(
            f"Missing row_count in staged metadata at {metadata_location}. "
            "If Parquet exists, column names may not match ROW_COUNT/row_count."
        )
    if data_size_mb_raw is None:
        # Staged VARIANT/Parquet paths sometimes yield SQL NULL for size even when
        # the source query selected 0 (e.g. Oracle ODBC metadata). Partition logic
        # treats missing size as unknown → use 0.0 so row_count-only heuristics apply.
        logger.warning(
            "read_metadata_from_stage: data_size_mb is NULL at %s; defaulting to 0.0 "
            "(row keys=%r)",
            metadata_location,
            sorted(row.keys()),
        )
        data_size_mb_raw = 0.0

    row_count = int(row_count_raw)
    data_size_mb = float(data_size_mb_raw)

    if row_count < 0 or data_size_mb < 0:
        raise ValueError(
            f"Invalid values: row_count={row_count}, data_size_mb={data_size_mb}"
        )

    return {"row_count": row_count, "data_size_mb": data_size_mb}


async def read_boundaries_from_stage(
    warehouse_proxy, boundaries_location: str
) -> list[dict[str, Any]]:
    """
    Read partition boundaries from Snowflake stage.

    Returns: [{'partition_id': int, 'min_value_in_partition': Any,
               'max_value_in_partition': Any, 'n_rows': int}, ...]
    """
    query = f"""
        SELECT
            $1:partition_id AS partition_id,
            $1:min_value_in_partition AS min_value_in_partition,
            $1:max_value_in_partition AS max_value_in_partition,
            $1:n_rows AS n_rows
        FROM {boundaries_location}
        (FILE_FORMAT => '{parquet_file_format_fqn()}',
        PATTERN => '.*[.]parquet')
        ORDER BY partition_id
    """
    logger.info(f"Read boundaries from stage: {query}")

    result = await warehouse_proxy.execute_sync_query(query)

    if not result or len(result) < 2:
        raise ValueError(f"Invalid boundaries at {boundaries_location}")

    # Parse results (Snowflake returns uppercase column names)
    boundaries = []
    for row in result:
        partition_id_raw = row.get("PARTITION_ID") or row.get("partition_id")
        if partition_id_raw is None:
            raise ValueError(
                f"Missing partition_id in staged boundary data at {boundaries_location}"
            )
        partition_id = int(partition_id_raw)

        min_value_in_partition = row.get("MIN_VALUE_IN_PARTITION") or row.get(
            "min_value_in_partition"
        )
        max_value_in_partition = row.get("MAX_VALUE_IN_PARTITION") or row.get(
            "max_value_in_partition"
        )
        n_rows_raw = row.get("N_ROWS") or row.get("n_rows")

        if n_rows_raw is None:
            raise ValueError(
                f"Missing n_rows in staged boundary data at {boundaries_location}"
            )
        n_rows = int(n_rows_raw)

        boundaries.append(
            {
                "partition_id": partition_id,
                "min_value_in_partition": min_value_in_partition,
                "max_value_in_partition": max_value_in_partition,
                "n_rows": n_rows,
            }
        )

    return boundaries


async def read_schema_from_stage(
    warehouse_proxy, schema_location: str
) -> list[dict[str, Any]]:
    """
    Read source table schema metadata from Snowflake stage.

    Returns: [{'column_name': str, 'data_type': str, 'max_length': int|None,
               'precision': int|None, 'scale': int|None, 'is_nullable': str,
               'ordinal_position': int}, ...]
    """
    # Case: COALESCE ``COLUMN_NAME`` / ``column_name``. Oracle catalog aliases vs
    # ``information_schema`` names: COALESCE character_maximum_length / max_length, etc.
    # Numbers: TO_VARCHAR + TRY_TO_NUMBER for VARIANT (same rationale as metadata).
    query = f"""
        SELECT
            COALESCE(
                TO_VARCHAR($1:"COLUMN_NAME"),
                TO_VARCHAR($1:"column_name")
            ) AS column_name,
            COALESCE(
                TO_VARCHAR($1:"DATA_TYPE"),
                TO_VARCHAR($1:"data_type")
            ) AS data_type,
            TRY_TO_NUMBER(TO_VARCHAR(COALESCE(
                $1:"CHARACTER_MAXIMUM_LENGTH",
                $1:"character_maximum_length",
                $1:"MAX_LENGTH",
                $1:"max_length"
            ))) AS max_length,
            TRY_TO_NUMBER(TO_VARCHAR(COALESCE(
                $1:"NUMERIC_PRECISION",
                $1:"numeric_precision",
                $1:"PRECISION",
                $1:"precision"
            ))) AS precision,
            TRY_TO_NUMBER(TO_VARCHAR(COALESCE(
                $1:"NUMERIC_SCALE",
                $1:"numeric_scale",
                $1:"SCALE",
                $1:"scale"
            ))) AS scale,
            COALESCE(
                TO_VARCHAR($1:"IS_NULLABLE"),
                TO_VARCHAR($1:"is_nullable")
            ) AS is_nullable,
            TRY_TO_NUMBER(TO_VARCHAR(COALESCE(
                $1:"ORDINAL_POSITION",
                $1:"ordinal_position"
            ))) AS ordinal_position
        FROM {schema_location}
        (FILE_FORMAT => '{parquet_file_format_fqn()}',
        PATTERN => '.*[.]parquet')
        ORDER BY ordinal_position
    """
    logger.info(f"Read schema from stage: {query}")

    # TODO(SNOW-2993674): Remove this after improving stage fetch processes
    await asyncio.sleep(3)
    result = await warehouse_proxy.execute_sync_query(query)

    if not result:
        raise ValueError(
            f"No schema found at {schema_location}. "
            "This typically indicates that the source table does not exist. "
            "Please verify that the table name specified in your configuration exists "
            "in the source database."
        )

    schema = []
    seen: set[tuple[str, int]] = set()
    duplicates_dropped = 0
    for row in result:
        column_name = row.get("COLUMN_NAME") or row.get("column_name")
        data_type = row.get("DATA_TYPE") or row.get("data_type")
        ordinal_position_raw = row.get("ORDINAL_POSITION") or row.get(
            "ordinal_position"
        )

        if not column_name or not data_type or ordinal_position_raw is None:
            raise ValueError(
                f"Missing required schema fields in staged data at {schema_location}"
            )

        max_length_raw = row.get("MAX_LENGTH") or row.get("max_length")
        precision_raw = row.get("PRECISION") or row.get("precision")
        scale_raw = row.get("SCALE") or row.get("scale")
        is_nullable = row.get("IS_NULLABLE") or row.get("is_nullable")

        # Dedupe by (column_name, ordinal_position). Some Redshift catalog
        # states (e.g. DISTSTYLE=ALL + AUTO(SORTKEY) tables) cause
        # information_schema.columns to report the same logical column more
        # than once; without this guard duplicate columns flow into the
        # extraction-query builder downstream (see SNOW-3454590).
        key = (column_name.strip('"'), int(ordinal_position_raw))
        if key in seen:
            duplicates_dropped += 1
            continue
        seen.add(key)

        schema.append(
            {
                "column_name": column_name.strip('"'),
                "data_type": data_type.strip('"').upper(),
                "max_length": (
                    int(max_length_raw) if max_length_raw is not None else None
                ),
                "precision": int(precision_raw) if precision_raw is not None else None,
                "scale": int(scale_raw) if scale_raw is not None else None,
                "is_nullable": is_nullable,
                "ordinal_position": int(ordinal_position_raw),
            }
        )

    if duplicates_dropped > 0:
        logger.warning(
            f"Stripped {duplicates_dropped} duplicate column row(s) from "
            f"staged schema at {schema_location}; this indicates the source "
            f"schema query did not deduplicate."
        )

    return schema
