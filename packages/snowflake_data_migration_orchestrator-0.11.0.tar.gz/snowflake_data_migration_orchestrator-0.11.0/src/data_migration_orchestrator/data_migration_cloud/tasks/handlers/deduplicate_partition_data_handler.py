"""
Deduplicate partition data handler.

This handler removes duplicate rows from the target table after COPY INTO
for watermark-based incremental sync with track_modifications enabled.
"""

import json

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_migration_cloud.platforms.snowflake import (
    build_snowflake_partition_condition,
)
from data_migration_orchestrator.data_migration_cloud.platforms.snowflake.identifiers import (
    quote_identifier as quote_identifier_snowflake,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.base_task_handler import (
    BaseTaskHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.synchronization_config_service import (
    SynchronizationConfigService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.table_configuration_service import (
    TableConfigurationService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.partition_migration_status import (
    PartitionMigrationStatus,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    DeduplicatePartitionDataPayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)
from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_migration_schema,
)


logger = get_logger("tasks.handlers.deduplicate_partition_data")


class DeduplicatePartitionDataHandler(BaseTaskHandler):
    """
    Handler for deduplicating partition data in target table.

    This handler executes a DELETE statement to remove old versions of
    modified rows after COPY INTO, keeping only the latest version based
    on the watermark column. Used in WATERMARK sync strategy with
    track_modifications enabled.
    """

    def __init__(self, task_queue: BaseTaskQueue, warehouse_proxy: Warehouse):
        """Initialize handler with task queue and warehouse proxy."""
        super().__init__(
            TaskPayloadKind.DEDUPLICATE_PARTITION_DATA,
            task_queue,
            warehouse_proxy,
        )
        self.table_config_service = TableConfigurationService(warehouse_proxy)
        self.sync_config_service = SynchronizationConfigService(warehouse_proxy)

    async def handle(self, task: Task) -> None:
        """
        Handle a deduplicate partition data task.

        Args:
            task: The task containing DeduplicatePartitionDataPayload

        """
        if not isinstance(task.payload, DeduplicatePartitionDataPayload):
            raise ValueError(
                f"Expected DeduplicatePartitionDataPayload, got {type(task.payload)}"
            )

        if self.warehouse_proxy is None:
            raise ValueError(
                "warehouse_proxy is required for DeduplicatePartitionDataHandler"
            )

        payload = task.payload
        logger.info(
            f"DeduplicatePartitionDataHandler: table_metadata_id={payload.table_metadata_id}, "
            f"partition_metadata_id={payload.partition_metadata_id}"
        )

        # Fetch table configuration (target table, primary key columns)
        table_config = (
            await self.table_config_service.fetch_required_table_configuration(
                payload.table_metadata_id
            )
        )

        # Fetch synchronization config (watermark column)
        sync_config = await self.sync_config_service.fetch_synchronization_config(
            payload.table_metadata_id
        )

        # Fetch partition metadata (min/max values)
        partition_info = await self._fetch_partition_metadata(
            payload.partition_metadata_id
        )

        if partition_info is None:
            raise ValueError(
                f"Partition metadata not found for partition_metadata_id={payload.partition_metadata_id}"
            )

        # Build target table name
        target_table = table_config.target.fully_qualified_friendly_name

        # Get required fields
        primary_key_columns = table_config.primary_key_columns
        watermark_column = sync_config.watermark_column
        # Partition column comes from table config, not partition metadata
        partition_columns = list(table_config.partition_columns)
        min_value = partition_info["min_value"]
        max_value = partition_info["max_value"]

        if not primary_key_columns:
            raise ValueError(
                f"Primary key columns are required for deduplication but not configured "
                f"for table_metadata_id={payload.table_metadata_id}"
            )

        if not partition_columns:
            raise ValueError(
                f"columnNamesToPartitionBy is required for deduplication but not configured "
                f"for table_metadata_id={payload.table_metadata_id}"
            )

        if not watermark_column:
            raise ValueError(
                f"Watermark column is required for deduplication but not configured "
                f"for table_metadata_id={payload.table_metadata_id}"
            )

        # Translate source column names to target column names via mappings.
        # The DELETE runs against the target table, so all identifiers must
        # use the target-side names.  Mapped values carry their own quoting
        # (e.g. `"Id"` for case-sensitive targets) which
        # quote_identifier_snowflake(force_quote=False) preserves.
        column_name_mappings = table_config.column_name_mappings or {}
        target_pk_columns = [
            column_name_mappings.get(col, col) for col in primary_key_columns
        ]
        target_watermark_column = column_name_mappings.get(
            watermark_column, watermark_column
        )
        target_partition_columns = [
            column_name_mappings.get(col, col) for col in partition_columns
        ]

        logger.info(
            f"Deduplicating {target_table}: "
            f"primary_keys={target_pk_columns}, watermark={target_watermark_column}, "
            f"partition_columns={target_partition_columns}"
        )

        # Update partition status to LOADING (deduplication is part of loading phase)
        await self._update_partition_status(
            payload.partition_metadata_id, PartitionMigrationStatus.LOADING
        )

        # Build and execute DELETE statement for deduplication
        from data_migration_orchestrator.data_migration_cloud.partition.partition_range import (
            infer_boundary_flags,
        )

        pnum = int(partition_info.get("partition_number") or 0)
        _, _, is_last = infer_boundary_flags(pnum, min_value, max_value)
        delete_sql = self._build_deduplication_statement(
            target_table=target_table,
            partition_columns=target_partition_columns,
            min_value=min_value,
            max_value=max_value,
            primary_key_columns=target_pk_columns,
            watermark_column=target_watermark_column,
            upper_inclusive=is_last,
        )
        logger.info(f"Executing deduplication DELETE: {delete_sql}")

        try:
            await self.warehouse_proxy.execute_sync_query(delete_sql)
            logger.info(f"Successfully deduplicated partition data in {target_table}")
        except Exception as e:
            logger.error(f"Failed to deduplicate partition data: {e}")
            raise

        # Complete this task (will unblock the successor COMPLETE_PARTITION_MIGRATION task)
        if task.id is None:
            raise ValueError("Task ID is required")

        await self.task_queue.complete_task(
            consumer_type=ExecutorType.ORCHESTRATOR,
            task_id=task.id,
        )

    async def _fetch_partition_metadata(
        self, partition_metadata_id: int
    ) -> dict | None:
        """
        Fetch partition metadata from PARTITION_METADATA table.

        Args:
            partition_metadata_id: ID of the partition metadata record

        Returns:
            Dict with min_value and max_value, or None if not found

        """
        if self.warehouse_proxy is None:
            return None

        try:
            query = f"""
                SELECT MIN_VALUE, MAX_VALUE, PARTITION_NUMBER
                FROM {qualified_migration_schema()}.PARTITION_METADATA
                WHERE ID = {partition_metadata_id}
            """
            result = await self.warehouse_proxy.execute_sync_query(query)

            if not result:
                logger.warning(
                    f"No partition metadata found for partition_metadata_id={partition_metadata_id}"
                )
                return None

            row = result[0]
            return {
                "min_value": row.get("MIN_VALUE") or row.get("min_value"),
                "max_value": row.get("MAX_VALUE") or row.get("max_value"),
                "partition_number": row.get("PARTITION_NUMBER")
                or row.get("partition_number"),
            }

        except Exception as e:
            logger.error(
                f"Failed to fetch partition metadata for partition_metadata_id={partition_metadata_id}: {e}"
            )
            return None

    def _build_deduplication_statement(
        self,
        target_table: str,
        partition_columns: list[str],
        min_value: str | int | float | None,
        max_value: str | int | float | None,
        primary_key_columns: list[str],
        watermark_column: str,
        *,
        upper_inclusive: bool = False,
    ) -> str:
        """
        Build DELETE statement for deduplication.

        This query removes duplicate rows, keeping only the row(s) with the highest
        watermark value for each primary key combination within the partition range.
        Note: If multiple rows have the same max watermark, all are kept (tied winners).

        Args:
            target_table: Fully qualified target table name
            partition_columns: Columns used for partitioning (one or more)
            min_value: Minimum value of the partition range
            max_value: Maximum value of the partition range
            primary_key_columns: List of primary key column names
            watermark_column: Column used for watermark ordering
            upper_inclusive: Whether the upper bound is inclusive (last interior bucket)

        Returns:
            DELETE SQL statement

        """
        # Parse JSON-encoded min/max values if needed
        parsed_min = self._parse_boundary_value(min_value)
        parsed_max = self._parse_boundary_value(max_value)

        # Build partition range condition for subquery
        subquery_condition = build_snowflake_partition_condition(
            partition_columns,
            parsed_min,
            parsed_max,
            upper_inclusive=upper_inclusive,
        )

        # Quote column names using Snowflake conventions (only quote if necessary)
        quoted_pk_columns = [
            quote_identifier_snowflake(col, force_quote=False)
            for col in primary_key_columns
        ]
        quoted_watermark = quote_identifier_snowflake(
            watermark_column, force_quote=False
        )

        # Build join conditions for WHERE clause (Snowflake DELETE...USING has no ON clause)
        join_conditions = [f"target.{col} = winners.{col}" for col in quoted_pk_columns]
        join_clause = " AND ".join(join_conditions)

        # Build GROUP BY clause
        group_by_clause = ", ".join(quoted_pk_columns)

        # Build the deduplication DELETE statement using DELETE...USING pattern
        # This finds max watermark per primary key and deletes older rows
        return f"""
            DELETE FROM {target_table} AS target
            USING (
                SELECT {group_by_clause}, MAX({quoted_watermark}) AS max_watermark
                FROM {target_table}
                WHERE {subquery_condition}
                GROUP BY {group_by_clause}
            ) AS winners
            WHERE {join_clause}
              AND target.{quoted_watermark} < winners.max_watermark
        """

    def _parse_boundary_value(
        self, value: str | int | float | None
    ) -> str | int | float | None:
        """
        Parse a potentially JSON-encoded boundary value.

        Args:
            value: Boundary value (may be JSON-encoded or raw)

        Returns:
            Parsed value (string, int, float) or None

        """
        if value is None:
            return None

        if isinstance(value, (int | float)):
            return value

        if isinstance(value, str):
            try:
                return json.loads(value)
            except (json.JSONDecodeError, TypeError):
                return value

        return value

    async def _update_partition_status(
        self, partition_metadata_id: int, status: PartitionMigrationStatus
    ) -> None:
        """
        Update the migration status of a partition metadata record.

        Args:
            partition_metadata_id: ID of the partition metadata record
            status: New status value from PartitionMigrationStatus enum

        """
        if self.warehouse_proxy is None:
            return

        try:
            query = (
                f"UPDATE {qualified_migration_schema()}.PARTITION_METADATA "
                f"SET MIGRATION_STATUS = '{status}', "
                f"MIGRATION_STATUS_TIMESTAMP = CURRENT_TIMESTAMP() "
                f"WHERE ID = {partition_metadata_id}"
            )
            await self.warehouse_proxy.execute_sync_query(query)
            logger.debug(
                f"Updated partition metadata {partition_metadata_id} status to {status}"
            )
        except Exception as e:
            logger.error(
                f"Failed to update partition metadata {partition_metadata_id} status: {e}"
            )
