"""
Smart partition configuration resolver.

Resolves a user-facing ``PartitionSizeConfig`` (auto, fixed-MB, or fixed-rows)
into a concrete ``PartitionConfig`` that the ``PartitionCalculator`` can use.

When in *auto* mode the resolver selects parameters based on the source
platform, extraction strategy, and (optionally) the table's data size so that
partition sizes are appropriate for each scenario.
"""

from __future__ import annotations

from dataclasses import dataclass

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    PartitionSizeConfig,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_calculator import (
    PartitionConfig,
)
from shared.enums.source_type import SourceType


logger = get_logger("tasks.handlers.smart_partition_config_resolver")

_MB_PER_GB = 1024


@dataclass(frozen=True)
class _PlatformProfile:
    """Pre-tuned partition parameters for a platform / extraction strategy pair."""

    target_mb_per_partition: int
    max_target_mb_per_partition: int | None = None
    max_target_rows_per_partition: int | None = None


_FALLBACK_PROFILE = _PlatformProfile(
    target_mb_per_partition=2 * _MB_PER_GB,
    max_target_mb_per_partition=5 * _MB_PER_GB,
)

_PLATFORM_PROFILES: dict[tuple[SourceType, ExtractionStrategy], _PlatformProfile] = {
    # Redshift UNLOAD writes Parquet to S3; S3 and Snowflake external stages
    # handle large files efficiently, so we allow bigger partitions.
    (SourceType.REDSHIFT, ExtractionStrategy.UNLOAD): _PlatformProfile(
        target_mb_per_partition=5 * _MB_PER_GB,
        max_target_mb_per_partition=10 * _MB_PER_GB,
    ),
    # Redshift REGULAR (ODBC) — data flows through the worker's memory, so
    # partitions should be smaller to limit memory pressure.
    (SourceType.REDSHIFT, ExtractionStrategy.REGULAR): _PlatformProfile(
        target_mb_per_partition=2 * _MB_PER_GB,
        max_target_mb_per_partition=5 * _MB_PER_GB,
    ),
    # SQL Server REGULAR (ODBC / BCP) — similar memory constraints as Redshift
    # ODBC, but throughput per partition tends to be lower.
    (SourceType.SQLSERVER, ExtractionStrategy.REGULAR): _PlatformProfile(
        target_mb_per_partition=1 * _MB_PER_GB,
        max_target_mb_per_partition=2 * _MB_PER_GB,
    ),
    # PostgreSQL REGULAR (ODBC) — same extraction path as SQL Server.
    (SourceType.POSTGRESQL, ExtractionStrategy.REGULAR): _PlatformProfile(
        target_mb_per_partition=1 * _MB_PER_GB,
        max_target_mb_per_partition=2 * _MB_PER_GB,
    ),
    # Teradata REGULAR — ODBC/teradatasql or worker-side TPT when ``tpt_*`` is
    # configured on the DEA; TPT streams to disk so allow larger partitions than
    # pure in-memory ODBC extractions.
    (SourceType.TERADATA, ExtractionStrategy.REGULAR): _PlatformProfile(
        target_mb_per_partition=3 * _MB_PER_GB,
        max_target_mb_per_partition=6 * _MB_PER_GB,
    ),
    # Teradata WRITE_NOS — server-side export to cloud storage (similar to UNLOAD).
    (SourceType.TERADATA, ExtractionStrategy.WRITE_NOS): _PlatformProfile(
        target_mb_per_partition=5 * _MB_PER_GB,
        max_target_mb_per_partition=10 * _MB_PER_GB,
    ),
}


class SmartPartitionConfigResolver:
    """
    Resolves a ``PartitionSizeConfig`` into a ``PartitionConfig``.

    Resolution modes:
    - **auto**: Selects a pre-tuned profile based on the source platform and
      extraction strategy.
    - **fixed-MB** (``target_size_mb``): Uses the user-provided target size.
    - **fixed-rows** (``target_size_rows``): Uses the user-provided row target.

    In all modes the resolver applies the profile's internal ``max_*`` fields
    so infrastructure limits are always enforced.
    """

    @staticmethod
    def resolve(
        partition_size_config: PartitionSizeConfig,
        source_type: SourceType,
        extraction_strategy: ExtractionStrategy,
        data_size_mb: float | None = None,
    ) -> PartitionConfig:
        """
        Resolve user config into a concrete ``PartitionConfig``.

        Args:
            partition_size_config: User-facing partition size configuration.
            source_type: Source database platform.
            extraction_strategy: Extraction strategy in use.
            data_size_mb: Total table data size (used for adaptive scaling in
                auto mode).  May be ``None`` when not yet known.

        Returns:
            A ``PartitionConfig`` ready for ``PartitionCalculator``.

        """
        profile = _PLATFORM_PROFILES.get(
            (source_type, extraction_strategy), _FALLBACK_PROFILE
        )

        if partition_size_config.target_size_rows is not None:
            return SmartPartitionConfigResolver._resolve_fixed_rows(
                partition_size_config.target_size_rows, profile
            )

        if partition_size_config.target_size_mb is not None:
            return SmartPartitionConfigResolver._resolve_fixed_mb(
                partition_size_config.target_size_mb, profile
            )

        return SmartPartitionConfigResolver._resolve_auto(profile)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _resolve_auto(profile: _PlatformProfile) -> PartitionConfig:
        config = PartitionConfig(
            target_mb_per_partition=profile.target_mb_per_partition,
            max_target_mb_per_partition=profile.max_target_mb_per_partition,
            max_target_rows_per_partition=profile.max_target_rows_per_partition,
        )

        logger.info(
            "Auto-resolved partition config: " "target=%d MB, max_mb=%s, max_rows=%s",
            profile.target_mb_per_partition,
            profile.max_target_mb_per_partition,
            profile.max_target_rows_per_partition,
        )
        return config

    @staticmethod
    def _resolve_fixed_mb(
        target_size_mb: int, profile: _PlatformProfile
    ) -> PartitionConfig:
        config = PartitionConfig(
            target_mb_per_partition=target_size_mb,
        )
        logger.info(
            "Fixed-MB partition config: target=%d MB",
            target_size_mb,
        )
        return config

    @staticmethod
    def _resolve_fixed_rows(
        target_size_rows: int, profile: _PlatformProfile
    ) -> PartitionConfig:
        config = PartitionConfig(
            target_rows_per_partition=target_size_rows,
        )
        logger.info(
            "Fixed-rows partition config: target=%d rows",
            target_size_rows,
        )
        return config
