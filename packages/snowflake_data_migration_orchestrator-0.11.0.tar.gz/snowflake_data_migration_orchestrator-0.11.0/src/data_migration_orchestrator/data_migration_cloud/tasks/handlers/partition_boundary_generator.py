"""Partition boundary generator for creating WHERE clauses."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from data_migration_orchestrator.data_migration_cloud.platforms.base_platform import (
    BasePlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_query_builder import (
    BaseQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.platforms.platform_registry import (
    PlatformRegistry,
)
from shared.enums.source_type import SourceType


@dataclass
class PartitionBoundary:
    """Represents a partition with its WHERE clause."""

    partition_index: int
    where_clause: str | None  # None for full table (no filtering)
    min_value: Any
    max_value: Any
    row_count: int


class PartitionBoundaryGenerator:
    """Generates partition boundaries and WHERE clauses from NTILE results."""

    def __init__(self) -> None:
        """Initialize with no query builder (set per-call based on source_type)."""
        self._query_builder: BaseQueryBuilder | None = None
        self._platform: BasePlatform | None = None

    def _get_platform(self, source_type: SourceType) -> BasePlatform:
        """Get or create platform for the given source type."""
        if self._platform is None or self._platform.name != source_type:
            self._platform = PlatformRegistry.create_by_name_or_alias(source_type)
            self._query_builder = self._platform.query_builder
        return self._platform

    def _get_query_builder(self, source_type: SourceType) -> BaseQueryBuilder:
        """Get or create query builder for the given source type."""
        self._get_platform(source_type)
        assert self._query_builder is not None
        return self._query_builder

    def generate_boundaries(
        self,
        partition_columns: list[str],
        boundary_values: list[dict],
        num_partitions: int,
        source_type: SourceType,
    ) -> list[PartitionBoundary]:
        """
        Generate partition boundaries from NTILE query results.

        Returns N interior partitions (from the NTILE results) plus two
        **edge partitions** that cover values below the observed minimum
        and above the observed maximum.

        Interior partitions use ``[L, H)`` (min closed, max open) except the
        last NTILE bucket, which uses ``[L, H]`` (closed top).
        """
        if not boundary_values:
            raise ValueError("No boundary values provided")

        if len(boundary_values) != num_partitions:
            raise ValueError(
                f"Expected {num_partitions} partitions, got {len(boundary_values)}"
            )

        if not partition_columns:
            raise ValueError("partition_columns is required to generate boundaries")

        query_builder = self._get_query_builder(source_type)

        partitions: list[PartitionBoundary] = []
        for idx, row in enumerate(boundary_values):
            partition_id = self._extract_value(row, "partition_id")
            min_val = self._extract_value(row, "min_value_in_partition")
            max_val = self._extract_value(row, "max_value_in_partition")
            n_rows = self._extract_value(row, "n_rows")
            is_last = idx == len(boundary_values) - 1

            condition = query_builder.build_partition_condition(
                partition_columns,
                min_val,
                max_val,
                upper_inclusive=is_last,
            )
            partitions.append(
                PartitionBoundary(
                    partition_index=int(partition_id),
                    where_clause=f"WHERE {condition}",
                    min_value=min_val,
                    max_value=max_val,
                    row_count=int(n_rows),
                )
            )

        first_min = self._extract_value(boundary_values[0], "min_value_in_partition")
        last_max = self._extract_value(boundary_values[-1], "max_value_in_partition")

        lower_edge_condition = query_builder.build_partition_condition(
            partition_columns, None, first_min
        )
        upper_edge_condition = query_builder.build_partition_condition(
            partition_columns, last_max, None
        )

        lower_edge = PartitionBoundary(
            partition_index=0,
            where_clause=f"WHERE {lower_edge_condition}",
            min_value=None,
            max_value=first_min,
            row_count=0,
        )
        upper_edge = PartitionBoundary(
            partition_index=num_partitions + 1,
            where_clause=f"WHERE {upper_edge_condition}",
            min_value=last_max,
            max_value=None,
            row_count=0,
        )

        return [lower_edge] + partitions + [upper_edge]

    def generate_single_boundary(
        self,
        partition_columns: list[str],
        partition_id: int,
        min_value: Any,
        max_value: Any,
        source_type: SourceType,
        row_count: int = 0,
        *,
        is_last_interior: bool = False,
        is_lower_edge: bool = False,
        is_upper_edge: bool = False,
    ) -> PartitionBoundary:
        """
        Generate a single partition boundary from min/max values.

        Used when recreating boundaries from existing partition metadata
        during incremental sync operations.
        """
        if min_value is None and max_value is None:
            return PartitionBoundary(
                partition_index=partition_id,
                where_clause="",
                min_value=min_value,
                max_value=max_value,
                row_count=row_count,
            )

        query_builder = self._get_query_builder(source_type)

        if is_lower_edge:
            condition = query_builder.build_partition_condition(
                partition_columns, None, max_value
            )
        elif is_upper_edge:
            condition = query_builder.build_partition_condition(
                partition_columns, min_value, None
            )
        else:
            condition = query_builder.build_partition_condition(
                partition_columns,
                min_value,
                max_value,
                upper_inclusive=is_last_interior,
            )

        return PartitionBoundary(
            partition_index=partition_id,
            where_clause=f"WHERE {condition}",
            min_value=min_value,
            max_value=max_value,
            row_count=row_count,
        )

    def _extract_value(self, row: dict, key: str) -> Any:
        """Extract value from row, handling case-insensitive keys."""
        if key in row:
            return row[key]
        upper_key = key.upper()
        if upper_key in row:
            return row[upper_key]
        lower_key = key.lower()
        if lower_key in row:
            return row[lower_key]

        raise KeyError(f"Key '{key}' not found in row: {row}")
