"""
Clear partition data handler.

This handler deletes existing partition data from the target table
before re-syncing in the CHECKSUM incremental sync strategy.
"""

import json

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_migration_cloud.platforms.snowflake import (
    PartitionRange,
    SnowflakeQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.services.schema_validator import (
    SchemaValidator,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.base_task_handler import (
    BaseTaskHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.table_configuration_service import (
    TableConfigurationService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.partition_migration_status import (
    PartitionMigrationStatus,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    ClearPartitionDataPayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)
from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_migration_schema,
)


logger = get_logger("tasks.handlers.clear_partition_data")


class ClearPartitionDataHandler(BaseTaskHandler):
    """
    Handler for clearing partition data from target table.

    This handler executes a DELETE statement to remove existing
    partition data before re-syncing changed partitions in the
    CHECKSUM sync strategy.
    """

    def __init__(self, task_queue: BaseTaskQueue, warehouse_proxy: Warehouse):
        """Initialize handler with task queue and warehouse proxy."""
        super().__init__(
            TaskPayloadKind.CLEAR_PARTITION_DATA,
            task_queue,
            warehouse_proxy,
        )
        self._query_builder = SnowflakeQueryBuilder()
        self.table_config_service = TableConfigurationService(warehouse_proxy)
        self._schema_validator = SchemaValidator(warehouse_proxy)

    async def handle(self, task: Task) -> None:
        """
        Handle a clear partition data task.

        Args:
            task: The task containing ClearPartitionDataPayload

        """
        if not isinstance(task.payload, ClearPartitionDataPayload):
            raise ValueError(
                f"Expected ClearPartitionDataPayload, got {type(task.payload)}"
            )

        if self.warehouse_proxy is None:
            raise ValueError(
                "warehouse_proxy is required for ClearPartitionDataHandler"
            )

        payload = task.payload

        table_config = (
            await self.table_config_service.fetch_required_table_configuration(
                payload.table_metadata_id
            )
        )
        partition_columns = list(table_config.partition_columns)

        # Defense-in-depth: skip DELETE if target table does not exist yet.
        # On first sync the LOAD step will CREATE the table — nothing to clear.
        target = table_config.target
        target_exists = await self._schema_validator.table_exists(
            target.database_name, target.schema_name, target.table_name
        )
        if not target_exists:
            logger.info(
                f"Target table {payload.target_table} does not exist yet, "
                f"skipping partition clear (first sync)"
            )
            # Complete the task so the chain can proceed to LOAD
            if task.id is None:
                raise ValueError("Task ID is required")
            await self.task_queue.complete_task(
                consumer_type=ExecutorType.ORCHESTRATOR,
                task_id=task.id,
            )
            return

        logger.info(
            f"ClearPartitionDataHandler: clearing partition data from {payload.target_table} "
            f"for partition columns {partition_columns}"
        )

        # Update partition status to LOADING (clearing is part of re-loading)
        await self._update_partition_status(
            payload.partition_metadata_id, PartitionMigrationStatus.LOADING
        )

        # Build and execute DELETE statement
        delete_sql = self._build_delete_statement(payload, partition_columns)
        logger.info(f"Executing DELETE: {delete_sql}")

        try:
            await self.warehouse_proxy.execute_sync_query(delete_sql)
            logger.info(
                f"Successfully cleared partition data from {payload.target_table}"
            )
        except Exception as e:
            logger.error(f"Failed to clear partition data: {e}")
            raise

        # Complete this task (will unblock the successor EXTRACT task)
        if task.id is None:
            raise ValueError("Task ID is required")

        await self.task_queue.complete_task(
            consumer_type=ExecutorType.ORCHESTRATOR,
            task_id=task.id,
        )

    def _build_delete_statement(
        self, payload: ClearPartitionDataPayload, partition_columns: list[str]
    ) -> str:
        """
        Build DELETE statement with partition boundary conditions.

        Args:
            payload: The task payload with partition information
            partition_columns: Columns used for partitioning (one or more)

        Returns:
            DELETE SQL statement

        """
        # Parse JSON-encoded min/max values
        min_value = self._parse_boundary_value(payload.min_value)
        max_value = self._parse_boundary_value(payload.max_value)

        from data_migration_orchestrator.data_migration_cloud.partition.partition_range import (
            infer_boundary_flags,
        )

        _, _, is_last = infer_boundary_flags(
            0,
            payload.min_value,
            payload.max_value,
        )
        partition_range = PartitionRange(
            columns=partition_columns,
            min_value=min_value,
            max_value=max_value,
            upper_inclusive=is_last,
        )
        return self._query_builder.build_delete_statement(
            table_name=payload.target_table,
            partition_range=partition_range,
        )

    def _parse_boundary_value(self, value: str | None) -> str | int | float | None:
        """
        Parse a JSON-encoded boundary value.

        Args:
            value: JSON-encoded boundary value or None

        Returns:
            Parsed value (string, int, float) or None

        """
        if value is None:
            return None

        try:
            return json.loads(value)
        except (json.JSONDecodeError, TypeError):
            # If not valid JSON, return as-is (might be a plain string)
            return value

    async def _update_partition_status(
        self, partition_metadata_id: int, status: PartitionMigrationStatus
    ) -> None:
        """
        Update the migration status of a partition metadata record.

        Args:
            partition_metadata_id: ID of the partition metadata record
            status: New status value from PartitionMigrationStatus enum

        """
        if self.warehouse_proxy is None:
            return

        try:
            query = (
                f"UPDATE {qualified_migration_schema()}.PARTITION_METADATA "
                f"SET MIGRATION_STATUS = '{status}', "
                f"MIGRATION_STATUS_TIMESTAMP = CURRENT_TIMESTAMP() "
                f"WHERE ID = {partition_metadata_id}"
            )
            await self.warehouse_proxy.execute_sync_query(query)
            logger.debug(
                f"Updated partition metadata {partition_metadata_id} status to {status}"
            )
        except Exception as e:
            logger.error(
                f"Failed to update partition metadata {partition_metadata_id} status: {e}"
            )
