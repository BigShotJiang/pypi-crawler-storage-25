"""Partition calculation for determining optimal partitioning strategy."""

import math

from dataclasses import dataclass


@dataclass
class PartitionConfig:
    """
    Partition configuration with five factors.

    **Targets** (public / user-configurable) express the *desired* partition
    size.  **Maxes** (internal / system-imposed) enforce hard limits that the
    infrastructure can handle.

    The calculator pipeline:

    1. **Target rows** – ``min(target_rows_per_partition,
       target_mb_per_partition / avg_row_mb)``; whichever is set and tighter.
       Falls back to ``row_count`` when neither is available.
    2. **Max rows** – ``min(max_target_rows_per_partition,
       max_target_mb_per_partition / avg_row_mb,
       max_target_cells_per_partition / num_columns)``; whichever is set and
       tighter.  Uncapped when none are set.
    3. **Effective** – ``min(target_rows, max_rows)``, at least 1.
    4. **Partition count** – ``ceil(row_count / effective)`` when
       ``effective < row_count``, else 1.
    """

    target_mb_per_partition: int | None = None
    target_rows_per_partition: int | None = None
    max_target_mb_per_partition: int | None = None
    max_target_rows_per_partition: int | None = None
    max_target_cells_per_partition: int | None = None


@dataclass
class PartitionDecision:
    """Partition analysis result."""

    should_partition: bool
    num_partitions: int
    rows_per_partition: int
    reasoning: str
    partition_column: str | None = None


class PartitionCalculator:
    """
    Calculates partitioning strategy based on table size.

    Uses a five-factor pipeline: compute target rows (from rows and/or MB
    targets), compute max rows (from rows, MB, and/or cells maxes), cap the
    target with the max, then derive the partition count.
    """

    def __init__(self, config: PartitionConfig | None = None):
        """Initialize calculator with optional custom config."""
        self.config = config or PartitionConfig()

    def calculate_partition_strategy(
        self, row_count: int, data_size_mb: float, num_columns: int = 0
    ) -> PartitionDecision:
        """Decide: partition or not? If yes, how many partitions?."""
        if row_count == 0:
            return PartitionDecision(
                should_partition=False,
                num_partitions=1,
                rows_per_partition=0,
                reasoning="Empty table - single extraction",
            )

        avg_row_mb = data_size_mb / row_count if data_size_mb > 0 else 0.0
        target_rows = self._resolve_target_rows(row_count, avg_row_mb)

        max_rows = self._resolve_max_rows(avg_row_mb, num_columns)

        effective = min(target_rows, max_rows) if max_rows is not None else target_rows
        effective = max(1, effective)

        if effective >= row_count:
            return PartitionDecision(
                should_partition=False,
                num_partitions=1,
                rows_per_partition=row_count,
                reasoning=(
                    f"{data_size_mb:.2f} MB ({row_count:,} rows) - "
                    f"single extraction "
                    f"(effective target: {effective:,} rows/partition)"
                ),
            )

        num_partitions = math.ceil(row_count / effective)
        rows_per_partition = row_count // num_partitions

        return PartitionDecision(
            should_partition=True,
            num_partitions=num_partitions,
            rows_per_partition=rows_per_partition,
            reasoning=(
                f"{data_size_mb:.2f} MB ({row_count:,} rows) - "
                f"{num_partitions} partitions (~{rows_per_partition:,} rows each, "
                f"effective target: {effective:,} rows/partition)"
            ),
        )

    def _resolve_target_rows(self, row_count: int, avg_row_mb: float) -> int:
        """
        Resolve target rows per partition.

        Takes the tighter of the explicit rows target and the MB-derived
        rows target.  Falls back to ``row_count`` when neither is set.
        """
        candidates: list[int] = []

        if self.config.target_rows_per_partition is not None:
            candidates.append(self.config.target_rows_per_partition)

        if self.config.target_mb_per_partition is not None and avg_row_mb > 0:
            candidates.append(
                max(1, int(self.config.target_mb_per_partition / avg_row_mb))
            )

        return min(candidates) if candidates else row_count

    def _resolve_max_rows(self, avg_row_mb: float, num_columns: int = 0) -> int | None:
        """
        Resolve maximum rows per partition.

        Takes the tighter of the explicit rows max, the MB-derived rows max,
        and the cells-derived rows max (``max_cells / num_columns``).
        Returns ``None`` when no max is set (no cap).
        """
        candidates: list[int] = []

        if self.config.max_target_rows_per_partition is not None:
            candidates.append(self.config.max_target_rows_per_partition)

        if self.config.max_target_mb_per_partition is not None and avg_row_mb > 0:
            candidates.append(
                max(1, int(self.config.max_target_mb_per_partition / avg_row_mb))
            )

        if self.config.max_target_cells_per_partition is not None and num_columns > 0:
            candidates.append(
                max(1, self.config.max_target_cells_per_partition // num_columns)
            )

        return min(candidates) if candidates else None
