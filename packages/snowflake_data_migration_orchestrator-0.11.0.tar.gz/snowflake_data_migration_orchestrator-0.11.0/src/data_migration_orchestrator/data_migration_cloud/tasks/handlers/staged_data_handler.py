"""
Staged data handler for processing staged data tasks.

This module defines the handler for PROCESS_STAGED_DATA tasks.
"""

import asyncio

from typing import Any, cast

from data_migration_orchestrator.cloud_core.constants.file_formats import (
    csv_file_format_fqn,
    parquet_file_format_fqn,
)
from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.tasks.task_builder import TaskBuilder
from data_migration_orchestrator.cloud_core.tasks.task_status import TaskStatus
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.cloud_core.workflows import workflow_columns
from data_migration_orchestrator.data_migration_cloud.config.extraction_stage_validation import (
    explain_external_stage_access_failure,
)
from data_migration_orchestrator.data_migration_cloud.config.sync_strategy import (
    SyncStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    LoadingStrategy,
)
from data_migration_orchestrator.data_migration_cloud.constants.priorities import (
    PRIORITY_FOR_COPY_INTO_TASKS,
)
from data_migration_orchestrator.data_migration_cloud.constants.stages import (
    default_internal_stage,
)
from data_migration_orchestrator.data_migration_cloud.exceptions.table_not_found_error import (
    TableNotFoundError,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_platform import (
    BasePlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.platform_registry import (
    PlatformRegistry,
)
from data_migration_orchestrator.data_migration_cloud.platforms.snowflake.identifiers import (
    unquote_identifier as unquote_identifier_snowflake,
)
from data_migration_orchestrator.data_migration_cloud.services.schema_validator import (
    ColumnSchema,
    SchemaValidator,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers._create_table_ddl import (
    build_create_table_ddl,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.base_task_handler import (
    BaseTaskHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.synchronization_config_service import (
    SynchronizationConfigService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.table_configuration_service import (
    TableConfigurationService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.target_table_creator import (
    create_target_table_if_missing,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.workflow_config_service import (
    WorkflowConfigService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.partition_migration_status import (
    PartitionMigrationStatus,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.synchronization_data import (
    WatermarkSyncData,
    WatermarkValue,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    CompletePartitionMigrationTaskPayload,
    DeduplicatePartitionDataPayload,
    ProcessStagedDataTaskPayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)
from data_migration_orchestrator.data_migration_cloud.utils.load_segmentation import (
    compute_segments,
)
from data_migration_orchestrator.data_migration_cloud.utils.pipe_utils import (
    build_pipe_name,
)
from data_migration_orchestrator.data_migration_cloud.utils.stage_utils import (
    build_external_stage_data_path,
    list_stage_files,
    read_schema_from_stage,
    resolve_stage_for_strategy,
    stage_path_for_partition_data,
    stage_path_for_schema,
)
from data_migration_orchestrator.data_migration_cloud.utils.type_mapping_loader import (
    TypeMappingLoader,
)
from data_migration_orchestrator.data_migration_core.queries.constants import (
    COLUMN_NAME,
    DATA_TYPE,
)
from data_migration_orchestrator.utils.lru_cache import LRUCache
from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_migration_schema,
)
from data_migration_orchestrator.utils.snowflake_schema import (
    ensure_database_and_schema,
    parse_external_stage_three_part_name,
    validate_external_stage_exists,
)
from data_migration_orchestrator.utils.snowflake_sql_utils import (
    escape_sql_string,
    quote_string_literal,
)
from shared.enums.file_type import FileType
from shared.enums.source_type import SourceType


logger = get_logger("tasks.handlers.staged_data")

# Retry configuration for waiting for staged files to appear
MAX_FILE_WAIT_RETRIES = 5  # Maximum number of retry attempts
INITIAL_RETRY_DELAY_SECONDS = 2  # Initial delay between retries
MAX_RETRY_DELAY_SECONDS = 60  # Maximum delay between retries (caps exponential backoff)

# Cache for source platform by workflow_id
# Shared across all StagedDataHandler instances
_source_platform_cache: LRUCache[int, str | None] = LRUCache(
    max_size=100,
    ttl_seconds=7200.0,  # 2 hours (workflows don't change platform)
)  # TODO(SNOW-3067445): Standardize this pattern. We have other LRU caches, and also cache for affinity.


# Task name prefix for warehouse COPY INTO tasks.  Used both when creating the
# task (``execute_snowflake_query_and_push_task``) and when querying TASK_QUEUE
# for an existing task in the idempotency guard.
COPY_INTO_TASK_NAME_PREFIX = "Execute COPY INTO"
SNOWPIPE_REFRESH_TASK_NAME_PREFIX = "Snowpipe refresh"

# Backward-compat re-export: ``build_create_table_ddl`` lives in
# ``_create_table_ddl`` so it can be shared with ``target_table_creator``
# without producing a circular import (tests import ``_build_create_table_ddl``).
_build_create_table_ddl = build_create_table_ddl


class StagedDataHandler(BaseTaskHandler):
    """
    Handler for processing staged data tasks.

    This handler processes tasks that load data from Snowflake stages into target tables
    using COPY INTO operations.
    """

    def __init__(self, task_queue: BaseTaskQueue, warehouse_proxy: Warehouse):
        """
        Initialize the staged data handler.

        Args:
            task_queue: The task queue for managing tasks
            warehouse_proxy: The warehouse proxy for Snowflake operations

        """
        super().__init__(
            TaskPayloadKind.PROCESS_STAGED_DATA,
            task_queue,
            warehouse_proxy,
        )
        self.sync_config_service = SynchronizationConfigService(warehouse_proxy)
        self.table_config_service = TableConfigurationService(warehouse_proxy)
        self.workflow_config_service = WorkflowConfigService(warehouse_proxy)

    async def handle(self, task: Task) -> None:
        """
        Handle a staged data task with type-aware transformations.

        Args:
            task: The task containing the ProcessStagedDataTaskPayload

        """
        if not isinstance(task.payload, ProcessStagedDataTaskPayload):
            raise ValueError(
                f"Expected ProcessStagedDataTaskPayload, got {type(task.payload)}"
            )

        if self.warehouse_proxy is None:
            raise ValueError("warehouse_proxy is required for StagedDataHandler")

        payload = task.payload

        # --- Idempotency guard (SNOW-3380238) ---
        if await self._should_skip_duplicate_load(task, payload):
            return

        # Update partition metadata to LOADING status
        await self._update_partition_status(
            payload.partition_metadata_id, PartitionMigrationStatus.LOADING
        )

        # Get source platform from workflow
        source_platform_raw = await self._fetch_source_platform(task.workflow_id)
        if not source_platform_raw:
            raise ValueError(
                f"Source platform is required for workflow {task.workflow_id}"
            )
        source_platform: SourceType = SourceType.from_string(source_platform_raw)
        logger.info(f"Using source platform: {source_platform}")

        # Fetch table config to determine extraction strategy and resolve stage
        table_config = (
            await self.table_config_service.fetch_required_table_configuration(
                payload.table_metadata_id
            )
        )
        table_id = table_config.target
        platform: BasePlatform = PlatformRegistry.create(source_platform)
        database_name = table_id.database_name
        schema_name = table_id.schema_name
        table_name = table_id.table_name
        full_table_name = platform.build_target_table_name(table_id)

        strategy_config = await self.workflow_config_service.fetch_strategy_config(
            task.workflow_id, table_config.extraction_strategy.value
        )
        # Fetch workflow's external stage as fallback for strategies that need it
        workflow_external_stage = (
            await self.workflow_config_service.fetch_workflow_external_stage(
                task.workflow_id
            )
        )
        stage_resolution = resolve_stage_for_strategy(
            table_config.extraction_strategy,
            strategy_config,
            workflow_external_stage,
            table_external_stage=table_config.extraction.external_stage,
        )

        # Iceberg copy_files with sourceDataStage: data already lives on S3,
        # read directly from the external stage configured in sourceDataStage.
        is_iceberg_source_stage = (
            table_config.iceberg_config is not None
            and table_config.iceberg_config.source_data_stage is not None
        )

        if is_iceberg_source_stage:
            ic = table_config.iceberg_config
            assert ic is not None  # narrowing for type checker
            assert ic.source_data_stage is not None  # narrowing for type checker

            # Validate source_data_stage format
            if not ic.source_data_stage.startswith("@"):
                raise ValueError(
                    f"Invalid source_data_stage '{ic.source_data_stage}': "
                    f"must start with '@' (e.g., '@DB.SCHEMA.STAGE_NAME')"
                )

            source_table_name = table_config.source.table_name or ""
            if not source_table_name:
                raise ValueError(
                    "source.tableName is required when using sourceDataStage for Iceberg migrations"
                )

            staged_location = f"{ic.source_data_stage}/{source_table_name}/"
            schema_location = stage_path_for_schema(
                default_internal_stage(), task.workflow_id, payload.table_metadata_id
            )
        elif stage_resolution.is_external:
            # Compute paths deterministically from identifiers
            # For external stages (UNLOAD), data location is in the external stage
            staged_location = build_external_stage_data_path(
                stage_resolution,
                task.workflow_id,
                payload.table_metadata_id,
                payload.partition_index,
            )
            # Schema is always on internal stage (PUT only works with internal stages)
            schema_location = stage_path_for_schema(
                default_internal_stage(), task.workflow_id, payload.table_metadata_id
            )
        else:
            # For internal stages (REGULAR), both data and schema are in the internal stage
            staged_location = stage_path_for_partition_data(
                stage_resolution.stage_id,
                task.workflow_id,
                payload.table_metadata_id,
                payload.partition_index,
            )
            schema_location = stage_path_for_schema(
                stage_resolution.stage_id, task.workflow_id, payload.table_metadata_id
            )

        logger.info(
            f"Stage locations for {table_name}:\n"
            f"  Data location: {staged_location}\n"
            f"  Schema location: {schema_location}\n"
            f"  Target table: {full_table_name}"
        )

        # External-stage extraction (Redshift UNLOAD, Teradata WRITE_NOS) uses paths like
        # @DATABASE.SCHEMA.STAGE/... — Snowflake must resolve SCHEMA before LIST/METADATA
        # queries in _detect_stage_file_type. Same timing as target-table DDL for LOAD.
        # The external stage must already exist in Snowflake (SHOW STAGES validation).
        if stage_resolution.is_external:
            await ensure_database_and_schema(
                self.warehouse_proxy.execute_sync_query,
                database_name,
                schema_name,
            )
            try:
                db_stg, sch_stg, name_stg = parse_external_stage_three_part_name(
                    stage_resolution.stage_id
                )
            except ValueError as exc:
                raise RuntimeError(
                    "Invalid externalStage in workflow configuration "
                    "(expected @DATABASE.SCHEMA.STAGE_NAME)."
                ) from exc
            await validate_external_stage_exists(
                self.warehouse_proxy.execute_sync_query,
                db_stg,
                sch_stg,
                name_stg,
            )

        base_loader = TypeMappingLoader(source_type=source_platform)

        # Get column mappings from table configuration (already fetched above)
        column_type_mappings = table_config.column_type_mappings or dict()
        column_name_mappings = table_config.column_name_mappings or dict()

        # Apply per-table type mapping overrides if provided
        if column_type_mappings:
            loader = base_loader.with_table_overrides(column_type_mappings)
            logger.info(
                f"Applied {len(column_type_mappings)} custom type mapping(s) "
                f"for table {payload.target_table}"
            )
        else:
            loader = base_loader

        if column_name_mappings:
            logger.info(
                f"Found {len(column_name_mappings)} column name mapping(s) "
                f"for table {payload.target_table}"
            )

        schema_validator = SchemaValidator(self.warehouse_proxy)

        try:
            # Detect file type in stage first (Parquet or CSV - mutually exclusive)
            # For Iceberg source stage, data is always Parquet -- skip detection.
            if is_iceberg_source_stage:
                file_type = FileType.PARQUET
                logger.info(
                    "Iceberg source stage: skipping file detection, using Parquet"
                )
            else:
                # Wait for files to appear (handles async upload from data-exchange-agent)
                try:
                    file_type = await self._detect_stage_file_type(staged_location)
                except ValueError:
                    # Extraction succeeded on the agent side but produced no files,
                    # meaning the partition's WHERE clause matched 0 source rows.
                    # This is expected for edge partitions and any other empty partition.
                    logger.warning(
                        f"No staged files found for {table_name} partition {payload.partition_index}. "
                        f"Extraction returned 0 rows — marking partition as complete."
                    )
                    await self._update_partition_status(
                        payload.partition_metadata_id,
                        PartitionMigrationStatus.COMPLETED,
                    )
                    if task.id is None:
                        raise ValueError("Task ID is required") from None
                    await self.task_queue.complete_task(
                        consumer_type=ExecutorType.ORCHESTRATOR,
                        task_id=task.id,
                    )
                    return

            logger.info(f"Detected file type in stage: {file_type}")

            source_schema: list[dict[str, Any]] = []

            if is_iceberg_source_stage:
                # Schema is inferred directly from the Parquet files on the
                # source data stage -- no DEA extraction needed.
                logger.info(
                    f"Inferring schema from source data stage: {staged_location}"
                )
                file_schema = await self._infer_file_schema(staged_location, file_type)
                for col_name, col_type in file_schema.items():
                    source_schema.append({COLUMN_NAME: col_name, DATA_TYPE: col_type})
                logger.info(
                    f"Inferred {len(source_schema)} column(s) from source data stage"
                )
            else:
                try:
                    logger.info(f"Reading schema from stage: {schema_location}")
                    source_schema = await read_schema_from_stage(
                        self.warehouse_proxy, schema_location
                    )
                except ValueError as e:
                    if "No schema found" in str(e):
                        raise TableNotFoundError(
                            database=database_name,
                            schema=schema_name,
                            table_name=table_name,
                            source_type=source_platform,
                            detail=(
                                f"Schema extraction returned no results from {schema_location}. "
                                f"Target table: {full_table_name}"
                            ),
                        ) from e
                    raise
                logger.info(
                    f"Schema was successfully read from stage. Number of columns: {len(source_schema)}"
                )

                # Infer schema from staged files (needed for type transformations)
                file_schema = await self._infer_file_schema(staged_location, file_type)

            if not stage_resolution.is_external:
                await ensure_database_and_schema(
                    self.warehouse_proxy.execute_sync_query,
                    database_name,
                    schema_name,
                )

            # Validate schema and detect drift if table exists
            validation_result = await schema_validator.validate_schema(
                database_name=database_name,
                schema_name=schema_name,
                table_name=table_name,
                source_schema=source_schema,
                type_mapping_loader=loader,
            )

            # When we create the table, we need the same types for COPY INTO casts
            # (e.g. NUMBER(38,10)) so "Number out of representable range" doesn't occur.
            created_types = await create_target_table_if_missing(
                warehouse_proxy=self.warehouse_proxy,
                full_table_name=full_table_name,
                source_schema=source_schema,
                type_mapping_loader=loader,
                column_name_mappings=column_name_mappings,
                iceberg_config=table_config.iceberg_config,
                is_iceberg_source_stage=is_iceberg_source_stage,
                target_table_id=table_id,
                table_already_exists=validation_result.table_exists,
            )
            created_table_target_types: dict[str, str] | None = (
                created_types if created_types else None
            )

            if validation_result.table_exists:
                logger.info(
                    f"Table {full_table_name} already exists, using existing schema"
                )
                if validation_result.has_drift:
                    logger.warning(
                        f"Schema drift detected: {len(validation_result.drifts)} "
                        f"difference(s). Data will be loaded using existing table schema."
                    )

                # Validate column name mappings against existing table schema
                if column_name_mappings:
                    self._validate_column_name_mappings(
                        column_name_mappings,
                        validation_result.actual_schema,
                        full_table_name,
                    )

            # Get columns for COPY INTO based on validation result
            # Uses existing schema if table exists, source schema if new table
            columns = schema_validator.get_columns_for_copy_into(
                validation_result, source_schema
            )

            # Use actual target table types for COPY INTO casts so casts match the table
            # (e.g. NUMBER(38,10) for new tables avoids "Number out of representable range").
            target_types = None
            if validation_result.actual_schema:
                target_types = {
                    col.column_name.upper(): col.get_full_type()
                    for col in validation_result.actual_schema
                }
            elif created_table_target_types:
                target_types = created_table_target_types

            # -----------------------------------------------------------------
            # Determine load segments (post-upload partitioning)
            # -----------------------------------------------------------------
            segments: list[list[str]] | None = None

            if table_config.load_segmentation is not None:
                target_bytes = (
                    table_config.load_segmentation.target_segment_size_mb * 1024 * 1024
                )
                stage_files = await list_stage_files(
                    self.warehouse_proxy, staged_location
                )
                if stage_files:
                    computed = compute_segments(stage_files, target_bytes)
                    if len(computed) > 1:
                        segments = [seg.files for seg in computed]
                        logger.info(
                            f"Load segmentation for {table_name}: "
                            f"{len(stage_files)} files split into "
                            f"{len(segments)} segment(s)"
                        )

            # -----------------------------------------------------------------
            # Build COPY INTO SQL(s)
            # -----------------------------------------------------------------
            if segments is not None:
                # Multiple segments -- one COPY INTO per segment (FILES clause)
                copy_into_sqls: list[str] = []
                for seg_files in segments:
                    if is_iceberg_source_stage:
                        file_list = ", ".join(f"'{f}'" for f in seg_files)
                        sql = (
                            f"COPY INTO {full_table_name}\n"
                            f"  FROM '{staged_location}'\n"
                            f"  LOAD_MODE = ADD_FILES_COPY\n"
                            f"  MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE\n"
                            f"  FILES = ({file_list})"
                        )
                    else:
                        sql = loader.generate_copy_into_statement(
                            target_table=full_table_name,
                            columns=columns,
                            stage_location=staged_location,
                            file_schema=file_schema,
                            column_name_mappings=column_name_mappings,
                            file_type=file_type,
                            target_types=target_types,
                            files=seg_files,
                        )
                    copy_into_sqls.append(sql)
            else:
                # Single COPY INTO (existing behaviour)
                if is_iceberg_source_stage:
                    sql = (
                        f"COPY INTO {full_table_name}\n"
                        f"  FROM '{staged_location}'\n"
                        f"  LOAD_MODE = ADD_FILES_COPY\n"
                        f"  MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE\n"
                        f"  PATTERN = '.*\\.parquet'"
                    )
                    copy_into_sqls = [sql]
                else:
                    copy_into_sqls = [
                        loader.generate_copy_into_statement(
                            target_table=full_table_name,
                            columns=columns,
                            stage_location=staged_location,
                            file_schema=file_schema,
                            column_name_mappings=column_name_mappings,
                            file_type=file_type,
                            target_types=target_types,
                        )
                    ]

            for sql in copy_into_sqls:
                logger.info(f"Executing COPY INTO: {sql}")

            # Before submitting COPY INTO, capture candidate_max_watermark_value
            # for WATERMARK sync strategy (per incremental-sync.md spec)
            await self._capture_candidate_watermark(
                payload.table_metadata_id,
                payload.partition_metadata_id,
                staged_location,
                file_type,
                source_schema,
            )

            # Use the task's scope for all successor tasks (they're all loading tasks)
            if task.scope is None:
                raise ValueError("Task scope is required for creating successor tasks")

            # Create successor task for completion tracking
            complete_task = (
                TaskBuilder(
                    workflow_id=task.workflow_id,
                    executor_type=ExecutorType.ORCHESTRATOR,
                    task_name=f"Complete partition migration: {table_name}",
                    scope=task.scope,
                    payload=CompletePartitionMigrationTaskPayload(
                        partition_metadata_id=payload.partition_metadata_id,
                        table_metadata_id=payload.table_metadata_id,
                        target_table=full_table_name,
                    ),
                )
                .with_priority(PRIORITY_FOR_COPY_INTO_TASKS)
                .blocked()
                .build()
            )
            complete_task_id = await self.task_queue.push_task(complete_task)

            # Determine what task should follow COPY INTO
            # For WATERMARK strategy with track_modifications, add deduplication step
            sync_config = table_config.synchronization
            needs_deduplication = (
                sync_config.strategy == SyncStrategy.WATERMARK
                and sync_config.track_modifications
                and table_config.primary_key_columns
            )

            if needs_deduplication:
                # Create deduplication task between COPY INTO and COMPLETE
                # Chain: COPY INTO -> DEDUPLICATE -> COMPLETE
                dedup_task = (
                    TaskBuilder(
                        workflow_id=task.workflow_id,
                        executor_type=ExecutorType.ORCHESTRATOR,
                        task_name=f"Deduplicate partition data: {table_name}",
                        scope=task.scope,
                        payload=DeduplicatePartitionDataPayload(
                            table_metadata_id=payload.table_metadata_id,
                            partition_metadata_id=payload.partition_metadata_id,
                        ),
                    )
                    .with_priority(PRIORITY_FOR_COPY_INTO_TASKS)
                    .blocked()
                    .with_successor(complete_task_id)
                    .build()
                )
                copy_into_successor_id = await self.task_queue.push_task(dedup_task)
                logger.info(
                    f"Created deduplication task chain for {table_name}: "
                    f"COPY INTO -> DEDUPLICATE ({copy_into_successor_id}) -> COMPLETE ({complete_task_id})"
                )
            else:
                # Standard chain: COPY INTO -> COMPLETE
                copy_into_successor_id = complete_task_id

            use_snowpipe = table_config.loading_strategy == LoadingStrategy.SNOWPIPE

            if use_snowpipe:
                # Snowpipe path: refresh the pre-created pipe for this partition's prefix.
                # The pipe was created by SetupSnowpipeHandler during workflow init.
                # PREFIX is appended to the pipe's FROM path (.../data/), and must match
                # the snow.file.path values recorded in file_lifecycle events (which are
                # also relative to the pipe's FROM path). See ALTER PIPE REFRESH docs.
                pipe_name = build_pipe_name(task.workflow_id, full_table_name)
                partition_fragment = (
                    f"partition_{payload.partition_index}"
                    if payload.partition_index > 0
                    else "full_table"
                )
                snowpipe_prefix = f"{partition_fragment}/"
                await self.warehouse_proxy.execute_snowpipe_refresh_and_push_task(
                    task.workflow_id,
                    pipe_name,
                    snowpipe_prefix,
                    task_name=f"{SNOWPIPE_REFRESH_TASK_NAME_PREFIX}: {table_name}",
                    scope=task.scope,
                    priority=PRIORITY_FOR_COPY_INTO_TASKS,
                    successor_task_id=copy_into_successor_id,
                )
            else:
                # Warehouse path: submit COPY INTO statements directly.
                # When segmented they fan-in to the same successor
                # (unblock_tasks checks ALL predecessors).
                for i, copy_sql in enumerate(copy_into_sqls):
                    segment_label = (
                        f" (segment {i + 1}/{len(copy_into_sqls)})"
                        if len(copy_into_sqls) > 1
                        else ""
                    )
                    await self.warehouse_proxy.execute_snowflake_query_and_push_task(
                        task.workflow_id,
                        copy_sql,
                        task_name=f"{COPY_INTO_TASK_NAME_PREFIX}: {table_name}{segment_label}",
                        scope=task.scope,
                        priority=PRIORITY_FOR_COPY_INTO_TASKS,
                        successor_task_id=copy_into_successor_id,
                    )

        except Exception as e:
            logger.error(f"Failed to process staged data: {e}")
            raise

        if task.id is None:
            raise ValueError("Task ID is required")

        await self.task_queue.complete_task(
            consumer_type=ExecutorType.ORCHESTRATOR,
            task_id=task.id,
        )

    async def _should_skip_duplicate_load(
        self,
        task: Task,
        payload: ProcessStagedDataTaskPayload,
    ) -> bool:
        """
        Check idempotency guards and return True if this task should be skipped.

        After an orchestrator crash the lease on a PROCESS_STAGED_DATA task
        expires and it is retried.  If the previous attempt already fired a
        COPY INTO that is still running (or completed), we must NOT fire a
        second one — that would insert duplicate rows (SNOW-3380238).

        Returns True (and completes the orchestrator task) when the load can
        safely be skipped.  Raises ``RuntimeError`` when a COPY INTO is still
        in-flight to defer the retry.
        """
        if task.scope is not None:
            existing = await self._find_existing_copy_into_task(
                task.workflow_id, task.scope
            )
            if existing is not None:
                existing_status = str(existing.get("STATUS", ""))
                existing_id = existing.get("ID")
                if existing_status == TaskStatus.COMPLETED:
                    logger.warning(
                        "COPY INTO already completed for scope %s (task_id=%s), "
                        "skipping duplicate load",
                        task.scope,
                        existing_id,
                    )
                    if task.id is not None:
                        await self.task_queue.complete_task(
                            consumer_type=ExecutorType.ORCHESTRATOR,
                            task_id=task.id,
                        )
                    return True
                if existing_status == TaskStatus.EXECUTING:
                    logger.warning(
                        "COPY INTO still in-flight for scope %s (task_id=%s), "
                        "deferring retry",
                        task.scope,
                        existing_id,
                    )
                    raise RuntimeError(
                        f"COPY INTO already in-flight for scope {task.scope}, "
                        f"deferring to avoid duplicate rows"
                    )

        current_status = await self._get_partition_status(payload.partition_metadata_id)
        if current_status == str(PartitionMigrationStatus.COMPLETED):
            logger.warning(
                "Partition %d already COMPLETED, skipping duplicate load",
                payload.partition_metadata_id,
            )
            if task.id is not None:
                await self.task_queue.complete_task(
                    consumer_type=ExecutorType.ORCHESTRATOR,
                    task_id=task.id,
                )
            return True

        return False

    async def _find_existing_copy_into_task(
        self, workflow_id: int, scope: str
    ) -> dict[str, Any] | None:
        """Check if a warehouse COPY INTO task already exists for this scope."""
        if self.warehouse_proxy is None:
            return None

        esc_scope = scope.replace("'", "''")
        query = (
            f"SELECT ID, STATUS "
            f"FROM {qualified_migration_schema()}.TASK_QUEUE "
            f"WHERE WORKFLOW_ID = {workflow_id} "
            f"AND SCOPE = '{esc_scope}' "
            f"AND EXECUTOR_TYPE = '{ExecutorType.WAREHOUSE.value}' "
            f"AND NAME LIKE '{COPY_INTO_TASK_NAME_PREFIX}%' "
            f"AND STATUS IN ('{TaskStatus.EXECUTING}', '{TaskStatus.COMPLETED}') "
            f"ORDER BY ID DESC LIMIT 1"
        )
        rows = await self.warehouse_proxy.execute_sync_query(query)
        if rows:
            return rows[0]
        return None

    async def _get_partition_status(self, partition_metadata_id: int) -> str | None:
        """Return the current MIGRATION_STATUS for a partition, or None."""
        if self.warehouse_proxy is None:
            return None

        query = (
            f"SELECT MIGRATION_STATUS "
            f"FROM {qualified_migration_schema()}.PARTITION_METADATA "
            f"WHERE ID = {partition_metadata_id}"
        )
        rows = await self.warehouse_proxy.execute_sync_query(query)
        if rows:
            return rows[0].get("MIGRATION_STATUS")
        return None

    async def _update_partition_status(
        self, partition_metadata_id: int, status: PartitionMigrationStatus
    ) -> None:
        """
        Update the migration status of a partition metadata record.

        Args:
            partition_metadata_id: ID of the partition metadata record
            status: New status value from PartitionMigrationStatus enum

        """
        if self.warehouse_proxy is None:
            return

        try:
            query = (
                f"UPDATE {qualified_migration_schema()}.PARTITION_METADATA "  # TODO: Add to stored_procedure_calls.sql
                f"SET MIGRATION_STATUS = '{status}', "
                f"MIGRATION_STATUS_TIMESTAMP = CURRENT_TIMESTAMP() "
                f"WHERE ID = {partition_metadata_id}"
            )
            await self.warehouse_proxy.execute_sync_query(query)
            logger.info(
                f"Updated partition metadata {partition_metadata_id} status to {status}"
            )
        except Exception as e:
            logger.error(
                f"Failed to update partition metadata {partition_metadata_id} status: {e}"
            )

    async def _capture_candidate_watermark(
        self,
        table_metadata_id: int | None,
        partition_metadata_id: int | None,
        stage_location: str,
        file_type: FileType,
        source_schema: list[dict],
    ) -> None:
        """
        Capture candidate max watermark value from staged file before COPY INTO.

        For WATERMARK sync strategy, queries the MAX value of the watermark column
        directly from the staged file and stores it as candidate_max_watermark_value
        in PARTITION_METADATA.SYNCHRONIZATION_DATA.

        This value becomes max_watermark_value only after successful COPY INTO completion.

        Args:
            table_metadata_id: ID of the table metadata record
            partition_metadata_id: ID of the partition metadata record
            stage_location: Stage location path (e.g., @my_stage/path/)
            file_type: The detected file type (PARQUET or CSV)
            source_schema: Source schema with column names and ordinal positions

        """
        if (
            table_metadata_id is None
            or partition_metadata_id is None
            or self.warehouse_proxy is None
        ):
            return

        # Fetch sync config to check if WATERMARK strategy
        sync_config = await self.sync_config_service.fetch_synchronization_config(
            table_metadata_id
        )

        if sync_config.strategy != SyncStrategy.WATERMARK:
            logger.debug(
                f"Skipping candidate watermark capture - strategy is {sync_config.strategy.value}"
            )
            return

        if not sync_config.watermark_column:
            logger.warning(
                "WATERMARK strategy configured but no watermark_column specified"
            )
            return

        # Query max watermark value from staged file
        candidate_value = await self._query_max_watermark_from_stage(
            stage_location, sync_config.watermark_column, file_type, source_schema
        )

        if candidate_value is None:
            logger.warning(
                f"Could not determine max watermark value from staged file at {stage_location}"
            )
            return

        # Update PARTITION_METADATA with candidate_max_watermark_value
        await self._update_partition_candidate_watermark(
            partition_metadata_id, sync_config.watermark_column, candidate_value
        )

    async def _query_max_watermark_from_stage(
        self,
        stage_location: str,
        watermark_column: str,
        file_type: FileType,
        source_schema: list[dict],
    ) -> WatermarkValue:
        """
        Query MAX value of watermark column directly from staged file.

        Args:
            stage_location: Stage location path (e.g., @my_stage/path/)
            watermark_column: Name of the watermark column to query MAX for
            file_type: The detected file type (PARQUET or CSV)
            source_schema: Source schema with column names and ordinal positions

        Returns:
            The max watermark value, or None if query failed

        """
        if self.warehouse_proxy is None:
            return None

        file_format = (
            parquet_file_format_fqn()
            if file_type == FileType.PARQUET
            else csv_file_format_fqn()
        )

        # Build query based on file type
        if file_type == FileType.PARQUET:
            query = self._build_parquet_watermark_query(
                stage_location, watermark_column, file_format
            )
        else:
            query = self._build_csv_watermark_query(
                stage_location, watermark_column, file_format, source_schema
            )

        if query is None:
            return None

        try:
            logger.info(
                f"Querying max watermark value for column '{watermark_column}' "
                f"from {stage_location} ({file_type.value})"
            )
            logger.debug(f"Watermark query: {query}")
            result = await self.warehouse_proxy.execute_sync_query(query)

            if not result:
                return None

            max_value = result[0].get("MAX_WATERMARK") or result[0].get("max_watermark")
            logger.info(f"Found candidate max watermark value: {max_value}")
            return max_value

        except Exception as e:
            logger.error(f"Failed to query max watermark from staged file: {e}")
            return None

    def _build_parquet_watermark_query(
        self,
        stage_location: str,
        watermark_column: str,
        file_format: str,
    ) -> str:
        """
        Build query to get MAX watermark value from Parquet file.

        Uses semi-structured access with $1:"column_name" syntax.
        Tries uppercase, as-is, and lowercase to handle sources that fold
        identifier case (e.g. Redshift lowercases unquoted identifiers).
        """
        col_upper = watermark_column.upper()
        col_lower = watermark_column.lower()
        return f"""
            SELECT MAX(
                COALESCE($1:"{col_upper}", $1:"{watermark_column}", $1:"{col_lower}")
            ) AS max_watermark
            FROM {stage_location}
            (FILE_FORMAT => '{file_format}',
            PATTERN => '.*[.]parquet')
        """

    def _build_csv_watermark_query(
        self,
        stage_location: str,
        watermark_column: str,
        file_format: str,
        source_schema: list[dict],
    ) -> str | None:
        """
        Build query to get MAX watermark value from CSV file.

        Uses positional column access with $N syntax.
        Finds column position from source schema.
        """
        # Find the column position (1-based) from schema
        column_position = None
        watermark_upper = watermark_column.upper()

        for col in source_schema:
            col_name = col.get(COLUMN_NAME, "")
            ordinal = col.get("ORDINAL_POSITION") or col.get("ordinal_position")

            if col_name.upper() == watermark_upper and ordinal is not None:
                column_position = int(ordinal)
                break

        if column_position is None:
            logger.warning(
                f"Could not find column '{watermark_column}' in schema for CSV watermark query"
            )
            return None

        return f"""
            SELECT MAX(${column_position}) AS max_watermark
            FROM {stage_location}
            (FILE_FORMAT => '{file_format}',
            PATTERN => '.*[.]csv.*')
        """

    async def _update_partition_candidate_watermark(
        self,
        partition_metadata_id: int,
        watermark_column: str,
        candidate_value: WatermarkValue,
    ) -> None:
        """
        Update PARTITION_METADATA.SYNCHRONIZATION_DATA with candidate_max_watermark_value.

        Args:
            partition_metadata_id: ID of the partition metadata record
            watermark_column: Name of the watermark column
            candidate_value: The candidate max watermark value to store

        """
        if self.warehouse_proxy is None:
            return

        # Strip surrounding quotes if present (Snowflake may return strings with quotes)
        if isinstance(candidate_value, str):
            candidate_value = candidate_value.strip('"')

        # Build WatermarkSyncData with candidate value
        sync_data = WatermarkSyncData(
            strategy=SyncStrategy.WATERMARK,
            watermark_column=watermark_column,
            max_watermark_value=None,  # Will be set on completion
            candidate_max_watermark_value=candidate_value,
        )
        sync_data_json = escape_sql_string(sync_data.to_json())

        try:
            # Update SYNCHRONIZATION_DATA in PARTITION_METADATA
            # Use OBJECT_INSERT to merge with existing data if present
            query = (
                f"UPDATE {qualified_migration_schema()}.PARTITION_METADATA "
                f"SET SYNCHRONIZATION_DATA = PARSE_JSON('{sync_data_json}') "
                f"WHERE ID = {partition_metadata_id}"
            )
            await self.warehouse_proxy.execute_sync_query(query)
            logger.info(
                f"Updated partition {partition_metadata_id} with "
                f"candidate_max_watermark_value={candidate_value}"
            )
        except Exception as e:
            logger.error(
                f"Failed to update partition metadata {partition_metadata_id} "
                f"with candidate watermark: {e}"
            )

    async def _detect_stage_file_type(self, stage_location: str) -> FileType:
        """
        Detect whether staged files are Parquet or CSV, retrying for async uploads.

        The data-exchange-agent uploads files asynchronously, so files may not
        be immediately available when this task starts. This method retries with
        exponential backoff to wait for files to appear.

        Args:
            stage_location: Stage location path (e.g., @my_stage/path/)

        Returns:
            FileType.PARQUET or FileType.CSV based on files found

        Raises:
            ValueError: If no data files found after all retries, or warehouse_proxy is None

        """
        if self.warehouse_proxy is None:
            raise ValueError("warehouse_proxy is required for _detect_stage_file_type")

        unknown_file_format = "unknown"
        query = f"""
            SELECT
                CASE
                    WHEN COUNT_IF(METADATA$FILENAME LIKE '%.parquet') > 0 THEN '{FileType.PARQUET.value}'
                    WHEN COUNT_IF(METADATA$FILENAME LIKE '%.csv' OR METADATA$FILENAME LIKE '%.csv.gz') > 0 THEN '{FileType.CSV.value}'
                    ELSE '{unknown_file_format}'
                END AS file_type
            FROM {stage_location}
        """

        retry_delay = INITIAL_RETRY_DELAY_SECONDS
        last_error = None

        for attempt in range(1, MAX_FILE_WAIT_RETRIES + 1):
            try:
                result = await self.warehouse_proxy.execute_sync_query(query)

                if not result:
                    raise ValueError(f"No files found at {stage_location}")

                file_type_str = result[0].get("FILE_TYPE") or result[0].get("file_type")

                if file_type_str == unknown_file_format:
                    raise ValueError(
                        f"No Parquet or CSV files found at {stage_location}"
                    )

                if attempt > 1:
                    logger.info(
                        f"Files found at {stage_location} after {attempt} attempt(s)"
                    )
                return FileType(file_type_str)

            except RuntimeError as e:
                hint = explain_external_stage_access_failure(e)
                if hint:
                    raise RuntimeError(f"{hint}\n{e}") from e
                raise

            except ValueError as e:
                last_error = e
                if attempt < MAX_FILE_WAIT_RETRIES:
                    logger.info(
                        f"No files found at {stage_location} (attempt {attempt}/{MAX_FILE_WAIT_RETRIES}). "
                        f"Retrying in {retry_delay}s..."
                    )
                    await asyncio.sleep(retry_delay)
                    # Exponential backoff with cap
                    retry_delay = min(retry_delay * 2, MAX_RETRY_DELAY_SECONDS)
                else:
                    logger.error(
                        f"No files found at {stage_location} after {MAX_FILE_WAIT_RETRIES} attempts. "
                        f"Data extraction may have failed or files are in a different location."
                    )

        # All retries exhausted
        raise ValueError(
            f"No files found at {stage_location} after {MAX_FILE_WAIT_RETRIES} retry attempts. "
            f"Last error: {last_error}"
        )

    async def _infer_file_schema(
        self, stage_location: str, file_type: FileType
    ) -> dict[str, str]:
        """
        Infer schema from staged files for type transformations in COPY INTO.

        For Parquet files, uses INFER_SCHEMA to get column types.
        For CSV files, returns an empty dict (CSV columns are treated as strings).

        Args:
            stage_location: Stage location path (e.g., @my_stage/path/)
            file_type: The detected file type

        Returns:
            Dictionary mapping column names (uppercase) to their types in the file

        """
        if self.warehouse_proxy is None:
            raise ValueError("warehouse_proxy is required for _infer_file_schema")

        if file_type == FileType.CSV:
            # CSV files don't have type information - columns are strings
            return {}

        # Parquet: use INFER_SCHEMA to get actual column types
        infer_query = f"""
            SELECT *
            FROM TABLE(
                INFER_SCHEMA(
                    LOCATION => {quote_string_literal(stage_location)},
                    FILE_FORMAT => {quote_string_literal(parquet_file_format_fqn())}
                )
            )
        """
        result = await self.warehouse_proxy.execute_sync_query(infer_query)

        file_schema: dict[str, str] = {}
        for row in result:
            col_name = row.get("COLUMN_NAME") or row.get("column_name")
            col_type = row.get("TYPE") or row.get("type")
            if col_name and col_type:
                # Normalize column names to uppercase for consistent lookup
                file_schema[str(col_name).upper()] = str(col_type)

        return file_schema

    async def _fetch_source_platform(self, workflow_id: int) -> str | None:
        """
        Fetch source platform from WORKFLOW table with LRU+TTL caching.

        Args:
            workflow_id: ID of the workflow

        Returns:
            Source platform string (e.g., 'redshift', 'sqlserver'), or None if not found

        """
        if workflow_id is None or self.warehouse_proxy is None:
            return None

        # Check cache first
        cached = _source_platform_cache.get_with_sentinel(workflow_id)
        if cached is not LRUCache.NOT_FOUND:
            # Cache hit (could be None if workflow not found)
            cached_value = cast(str | None, cached)
            if cached_value is not None:
                logger.debug(
                    "Cache hit: source platform '%s' for workflow_id=%s",
                    cached_value,
                    workflow_id,
                )
            return cached_value

        # Cache miss - fetch from database
        try:
            qm = qualified_migration_schema()
            query = f"""
                SELECT SOURCE_PLATFORM
                FROM {qm}.WORKFLOW
                WHERE ID = {workflow_id}
            """
            result = await self.warehouse_proxy.execute_sync_query(query)

            source_platform: str | None = None
            if result and len(result) > 0:
                platform = result[0].get(workflow_columns.SOURCE_PLATFORM)
                if platform:
                    source_platform = platform.lower()
                    logger.debug(
                        "Fetched and cached source platform '%s' for workflow_id=%s",
                        source_platform,
                        workflow_id,
                    )

            # Cache the result (including None)
            _source_platform_cache.set(workflow_id, source_platform)
            return source_platform
        except Exception as e:
            logger.error(
                "Failed to fetch source platform for workflow_id=%s: %s", workflow_id, e
            )
            return None

    def _validate_column_name_mappings(
        self,
        column_name_mappings: dict[str, str],
        actual_schema: list[ColumnSchema],
        table_name: str,
    ) -> None:
        """
        Validate that all target column names exist in the actual table.

        Args:
            column_name_mappings: Dict mapping source column names to target column names
            actual_schema: List of ColumnSchema from the existing table
            table_name: Full table name for error messages

        Raises:
            ValueError: If any target column from mappings doesn't exist in the table

        """
        if not column_name_mappings or not actual_schema:
            return

        actual_columns = {col.column_name for col in actual_schema}
        missing_columns = []

        for source_name, target_name in column_name_mappings.items():
            bare_target = unquote_identifier_snowflake(target_name)
            if bare_target not in actual_columns:
                missing_columns.append(f"'{source_name}' -> '{target_name}'")

        if missing_columns:
            raise ValueError(
                f"Column name mapping validation failed for table '{table_name}'. "
                f"Target columns not found in existing table: {', '.join(missing_columns)}. "
                f"Available columns: {', '.join(sorted(actual_columns))}"
            )


# TODO(SNOW-3072704):Move queries to a separate place
