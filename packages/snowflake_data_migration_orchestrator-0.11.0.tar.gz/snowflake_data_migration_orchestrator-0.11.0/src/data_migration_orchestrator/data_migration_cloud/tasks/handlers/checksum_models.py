"""
Data models for partition-level checksum computation.

This module provides the shared data classes used by platform-specific
checksum query builders and the checksum comparison handler.
"""

from dataclasses import dataclass


# Default null token used when converting NULL values to strings for hashing
NULL_TOKEN = "-99999999"


@dataclass
class ColumnInfo:
    """
    Column metadata for checksum query building.

    Attributes:
        column_name: The column name
        data_type: The SQL Server data type (e.g., 'int', 'varchar', 'datetime2')
        is_nullable: Whether the column allows NULL values
        numeric_precision: Precision for numeric types
        numeric_scale: Scale for numeric types

    """

    column_name: str
    data_type: str
    is_nullable: bool
    numeric_precision: int | None = None
    numeric_scale: int | None = None


@dataclass
class PartitionInfo:
    """
    Information about a partition for checksum query building.

    Attributes:
        database: Source database name
        schema: Source schema name
        table_name: Source table name
        partition_columns: Columns used for partitioning (lexicographic order)
        min_value: Encoded minimum bound (scalar or delimited string)
        max_value: Encoded maximum bound (scalar or delimited string)
        partition_number: The partition number/index
        upper_inclusive: Use ``<= max`` when both bounds are set

    """

    database: str
    schema: str
    table_name: str
    partition_columns: list[str]
    min_value: str | None
    max_value: str | None
    partition_number: int
    upper_inclusive: bool = False
