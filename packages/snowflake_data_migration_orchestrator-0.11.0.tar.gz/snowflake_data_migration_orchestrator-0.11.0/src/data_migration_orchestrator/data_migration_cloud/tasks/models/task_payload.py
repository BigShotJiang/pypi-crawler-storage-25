from dataclasses import dataclass
from enum import StrEnum
from typing import Literal

from data_migration_orchestrator.cloud_core.tasks.snowflake_query_task import (
    SnowflakeQueryTaskPayload,
)
from data_migration_orchestrator.cloud_core.tasks.snowpipe_task import (
    SnowpipeTaskPayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)


# DATA EXCHANGE AGENT PAYLOADS
IN_PAYLOAD_STATEMENT_TYPE = "in-payload"


class TargetType(StrEnum):
    """
    Target types for data movement tasks.

    Defines where the DEA should write extracted data.
    """

    SNOWFLAKE_STAGE = "snowflake:stage"
    """Upload data to Snowflake internal stage via PUT command."""

    S3_UNLOAD = "s3:unload"
    """
    Write data directly to S3 using Redshift UNLOAD.
    The DEA builds the UNLOAD command using its configured S3 bucket and IAM role.
    The target_id contains the relative path within the bucket.
    """

    WRITE_NOS = "write_nos"
    """
    Write data directly to cloud object storage using Teradata WRITE_NOS.
    The DEA wraps the SELECT with WRITE_NOS syntax, injecting the cloud
    location and credentials from its configuration. Teradata writes Parquet
    files directly to the configured cloud storage (S3, Azure Blob, or GCS).
    The target_id contains the relative path within the storage container.
    """

    TPT = "tpt"
    """
    Teradata Parallel Transporter: DEA runs ``tbuild`` locally, converts output
    to Parquet, then PUTs to the Snowflake internal stage (same path convention
    as REGULAR). ``target_id`` is the internal stage path prefix.
    """

    NONE = "none"
    """No upload needed (data already at destination or handled separately)."""


@dataclass
class DataMovementTaskPayload:
    """
    Payload for a data movement task.

    This includes any task that involves querying data and putting the results in a specific location.
    """

    database: str
    """
    The source database from which data will be moved.
    """

    schema: str
    """
    The source schema from which data will be moved.
    """

    source_type: str
    """
    The type of source from which data will be moved.
    For example, this could be 'sql-server', 'teradata', 'redshift', etc...
    This could also be a file in a blob storage, like 'aws-s3', 'azure-blob', 'gcp-storage', etc...
    This could also just be 'file' and provide a file path in the source_id.
    """

    source_id: str
    """
    The identifier for the specific source.
    Format depends on the source_type, but it refers to a specific data source of the mentioned type.
    """

    target_type: str
    """
    The type of target to which data will be moved. Use TargetType enum values:
    - TargetType.SNOWFLAKE_STAGE: Upload to Snowflake internal stage
    - TargetType.S3_UNLOAD: Write directly to S3 via Redshift UNLOAD (DEA builds the command)
    - TargetType.WRITE_NOS: Teradata WRITE_NOS to cloud storage (relative path in target_id)
    - TargetType.TPT: Teradata Parallel Transporter (internal stage path in target_id;
      DEA remaps upload to SNOWFLAKE_STAGE)
    - TargetType.NONE: No upload needed
    """

    target_id: str
    """
    The identifier for the specific target. Format depends on target_type:
    - For SNOWFLAKE_STAGE: Stage path like '@MY_DB.MY_SCHEMA.MY_STAGE/path/'
    - For S3_UNLOAD: Relative path within DEA's configured S3 bucket (e.g., '1/2/partition_0/')
    - For NONE: Can be empty or descriptive
    """

    statement_location_id: str
    """
    The ID of the location from which the statement will be loaded.
    For example, it could be 'MY_DB.MY_SCHEMA.MY_STAGE/my-dir/my-statement.sql' for type 'snowflake:stage',
    or 'MY_DB.MY_SCHEMA.MY_TABLE:ROW(ID=42):COL(MY_STMT)' for 'snowflake:table'
    (in this case, it would be available in the column 'MY_STMT' of the row WHERE ID = 42,
    in the table 'MY_DB.MY_SCHEMA.MY_TABLE').
    In the case of 'in-payload', it contains the payload (for example, 'SELECT * FROM MY_SCHEMA.MY_TABLE').
    """

    kind: Literal[TaskPayloadKind.DATA_MOVEMENT] = TaskPayloadKind.DATA_MOVEMENT

    statement_location_type: str = IN_PAYLOAD_STATEMENT_TYPE
    """
    The type of location from which the statement will be loaded.
    For example, it could be 'in-payload', 'snowflake:stage', 'snowflake:table'.
    """

    suggested_batch_size: int | None = None
    """
    Suggested batch size for data extraction (number of rows per batch).
    Calculated based on average row size to target ~15 MB per batch.
    When None, the data-exchange-agent will use its default batch size (50000).
    """

    is_bulk_operation: bool = False
    """
    Whether to use bulk utilities (like BCP) for data extraction.
    When True and a bulk utility is configured, the data-exchange-agent will use
    the bulk utility instead of standard ODBC for better performance on large datasets.
    Should be True for full table and partition extractions, False for metadata/schema queries.
    """

    use_database_command: str | None = None
    """
    Optional SQL command to switch the active database before executing the statement.
    Generated by the orchestrator using the source platform's query builder
    (e.g., ``USE [SampleStoreDB]`` for SQL Server).
    When None, no database switching is performed — the connection's default database is used.
    """

    extraction_strategy: str | None = None
    """
    Orchestrator extraction strategy for diagnostics and telemetry (e.g. ``regular``,
    ``write_nos``, ``tpt``). Routing uses ``target_type``; this field is optional.
    """


# ORCHESTRATOR PAYLOADS
@dataclass
class PreprocessingCheckPayload:
    """
    Payload for the preprocessing check that validates object type.

    The handler reads the object-type result from stage and:
    - Raises TableNotFoundError if the object does not exist.
    - Attaches a warning if the object is a VIEW.
    - Dynamically creates metadata extraction, schema extraction, and
      partition strategy tasks when the check passes.
    """

    database: str
    """Source database"""

    schema: str
    """Source schema"""

    table_name: str
    """Table name"""

    source_type: str
    """Source type (e.g., 'sqlserver')"""

    target_table: str
    """Fully qualified target table name"""

    target_cloud_type: str
    """Target cloud type (e.g., 'snowflake:stage')"""

    table_metadata_id: int
    """ID from TABLE_METADATA table"""

    kind: Literal[TaskPayloadKind.PREPROCESSING_CHECK] = (
        TaskPayloadKind.PREPROCESSING_CHECK
    )


@dataclass
class DeterminePartitionStrategyTaskPayload:
    """
    Payload for determining partitioning strategy.

    This task analyzes table metadata to determine how to partition
    data extraction (full table vs partitioned).
    """

    database: str
    """Source database"""

    schema: str
    """Source schema"""

    table_name: str
    """Table name"""

    source_type: str
    """Source type (e.g., 'sqlserver')"""

    target_table: str
    """Fully qualified target table name (e.g., 'db.schema.table')"""

    table_metadata_id: int
    """ID from TABLE_METADATA table, used for tracking partition metadata and computing paths"""

    extraction_strategy: str | None = None
    """Extraction strategy to use (e.g., 'odbc', 'unload'). If None, defaults to 'odbc'"""

    kind: Literal[TaskPayloadKind.DETERMINE_PARTITION_STRATEGY] = (
        TaskPayloadKind.DETERMINE_PARTITION_STRATEGY
    )


@dataclass
class CreatePartitionTasksPayload:
    """
    Payload for creating partitioned extraction tasks.

    This task reads the boundaries computed by the ANALYZE task and creates
    multiple extraction tasks with parallel chains pattern:
    [Extract Part N] -> [Load Part N] -> [COPY_INTO Part N]

    Each partition gets its own independent chain that runs in parallel.
    All chains write to the same target table.
    """

    database: str
    """Source database"""

    schema: str
    """Source schema"""

    table_name: str
    """Table name"""

    source_type: str
    """Source type (e.g., 'sqlserver')"""

    num_partitions: int
    """Number of partitions to create"""

    target_table: str
    """Fully qualified target table name (e.g., 'db.schema.table')"""

    table_metadata_id: int
    """ID from TABLE_METADATA table, used for tracking partition metadata and computing paths"""

    kind: Literal[TaskPayloadKind.CREATE_PARTITION_TASKS] = (
        TaskPayloadKind.CREATE_PARTITION_TASKS
    )

    avg_row_size_bytes: float | None = None
    """
    Average row size in bytes, used to calculate suggested batch size for extraction tasks.
    When None, extraction tasks will use the default batch size.
    """


@dataclass
class ProcessStagedDataTaskPayload:
    """
    Payload for a process staged data task.

    This task is responsible for processing data that has been staged in a temporary location.
    """

    table_metadata_id: int
    """ID from TABLE_METADATA table, used for fetching column type mappings and computing paths"""

    partition_metadata_id: int
    """ID from PARTITION_METADATA table, used for tracking partition status"""

    partition_index: int
    """The partition index (0 for full table, >0 for partitions), used to compute data path"""

    target_table: str
    """
    The fully qualified target table name (e.g., 'MY_DB.MY_SCHEMA.MY_TABLE').
    """

    kind: Literal[TaskPayloadKind.PROCESS_STAGED_DATA] = (
        TaskPayloadKind.PROCESS_STAGED_DATA
    )


@dataclass
class CompletePartitionMigrationTaskPayload:
    """
    Payload for completing partition migration after COPY INTO.

    This task is the successor to COPY INTO and is responsible for
    updating the partition metadata status to COMPLETED and recording
    synchronization metadata for incremental sync.
    """

    partition_metadata_id: int
    """ID from PARTITION_METADATA table to mark as COMPLETED"""

    # TODO(SNOW-3067445): This could be read from the partition_metadata_id
    table_metadata_id: int | None = None
    """ID from TABLE_METADATA table, used to fetch synchronization config"""

    # TODO(SNOW-3067445): This could also be read from the partition_metadata_id)
    target_table: str | None = None
    """Fully qualified target table name, used to query max watermark values"""

    kind: Literal[TaskPayloadKind.COMPLETE_PARTITION_MIGRATION] = (
        TaskPayloadKind.COMPLETE_PARTITION_MIGRATION
    )


@dataclass
class ComparePartitionChecksumPayload:
    """
    Payload for comparing partition checksums in CHECKSUM sync strategy.

    This task computes the source partition checksum and compares it with
    the stored checksum. Based on the result, it either:
    - Marks the partition as complete (if unchanged)
    - Creates extraction chain (EXTRACT -> CLEAR -> LOAD) if changed or first-time
    """

    partition_metadata_id: int
    """ID from PARTITION_METADATA table"""

    table_metadata_id: int
    """ID from TABLE_METADATA table"""

    partition_number: int
    """The partition number/index"""

    min_value: str | None
    """Minimum value of the partition range (inclusive), JSON-encoded"""

    max_value: str | None
    """Maximum value of the partition range (inclusive), JSON-encoded"""

    stored_checksum: str | None
    """The stored checksum from previous sync, or None for first-time sync"""

    # Source information for checksum computation
    database: str
    """Source database"""

    schema: str
    """Source schema"""

    table_name: str
    """Source table name"""

    source_type: str
    """Source type (e.g., 'sqlserver', 'redshift')"""

    # Target information for creating extraction chain
    target_table: str
    """Fully qualified target table name (e.g., 'db.schema.table')"""

    avg_row_size_bytes: float | None = None
    """Average row size in bytes, for batch size calculation"""

    kind: Literal[TaskPayloadKind.COMPARE_PARTITION_CHECKSUM] = (
        TaskPayloadKind.COMPARE_PARTITION_CHECKSUM
    )


@dataclass
class ProcessChecksumResultPayload:
    """
    Payload for processing checksum result after DataMovementTask completes.

    This task reads the staged checksum result, compares it with the stored
    checksum, and decides whether to create the extraction chain.
    """

    partition_metadata_id: int
    """ID from PARTITION_METADATA table"""

    table_metadata_id: int
    """ID from TABLE_METADATA table, also used for computing paths"""

    partition_number: int
    """The partition number/index, used for computing checksum result path"""

    min_value: str | None
    """Minimum value of the partition range (inclusive), JSON-encoded"""

    max_value: str | None
    """Maximum value of the partition range (inclusive), JSON-encoded"""

    stored_checksum: str | None
    """The stored checksum from previous sync, or None for first-time sync"""

    # Source information for creating extraction chain
    database: str
    """Source database"""

    schema: str
    """Source schema"""

    table_name: str
    """Source table name"""

    source_type: str
    """Source type (e.g., 'sqlserver', 'redshift')"""

    # Target information for creating extraction chain
    target_table: str
    """Fully qualified target table name (e.g., 'db.schema.table')"""

    avg_row_size_bytes: float | None = None
    """Average row size in bytes, for batch size calculation"""

    kind: Literal[TaskPayloadKind.PROCESS_CHECKSUM_RESULT] = (
        TaskPayloadKind.PROCESS_CHECKSUM_RESULT
    )


@dataclass
class ClearPartitionDataPayload:
    """
    Payload for clearing partition data from target table.

    This task is used in CHECKSUM sync strategy to delete existing
    partition data before re-syncing changed partitions.
    """

    target_table: str
    """Fully qualified target table name (e.g., 'db.schema.table')"""

    table_metadata_id: int
    """ID from TABLE_METADATA table"""

    min_value: str | None
    """Minimum value of the partition range (inclusive), JSON-encoded"""

    max_value: str | None
    """Maximum value of the partition range (inclusive), JSON-encoded"""

    partition_metadata_id: int
    """ID from PARTITION_METADATA table for status tracking"""

    kind: Literal[TaskPayloadKind.CLEAR_PARTITION_DATA] = (
        TaskPayloadKind.CLEAR_PARTITION_DATA
    )


@dataclass
class DeduplicatePartitionDataPayload:
    """
    Payload for deduplicating partition data in the target table.

    This task is used in WATERMARK sync strategy with track_modifications enabled
    to remove old versions of modified rows after COPY INTO, keeping only the
    latest version based on the watermark column.

    The handler fetches all required information (target table, partition boundaries,
    primary key columns, watermark column) from the database using these IDs.
    """

    table_metadata_id: int
    """ID from TABLE_METADATA table, used to fetch table config (target table, primary keys, watermark)"""

    partition_metadata_id: int
    """ID from PARTITION_METADATA table, used to fetch partition boundaries and status tracking"""

    kind: Literal[TaskPayloadKind.DEDUPLICATE_PARTITION_DATA] = (
        TaskPayloadKind.DEDUPLICATE_PARTITION_DATA
    )


@dataclass
class SetupSnowpipePayload:
    """
    Payload for creating a Snowpipe for a table.

    The handler runs an idempotent ``CREATE TABLE IF NOT EXISTS`` on the
    target *before* issuing ``CREATE PIPE``. This eliminates the race
    where ``CREATE PIPE … AS COPY INTO <target>`` fails with
    ``invalid identifier`` because lazy table creation (in
    ``StagedDataHandler``) hasn't run yet. The pipe is created with
    ``AUTO_INGEST=FALSE`` and ``MATCH_BY_COLUMN_NAME`` so that partition
    refreshes can match Parquet column names to target columns
    automatically.

    The source platform identifier is intentionally **not** carried on
    the payload: the handler resolves it from ``WORKFLOW.SOURCE_PLATFORM``
    via ``WorkflowConfigService`` so workflow-level state stays the
    single source of truth.
    """

    pipe_name: str
    """Fully qualified Snowpipe name to create."""

    target_table: str
    """Fully qualified target table name."""

    stage_path: str
    """Stage path prefix covering all partitions for this table."""

    table_metadata_id: int
    """ID from TABLE_METADATA, used to fetch the inferred column type mappings."""

    kind: Literal[TaskPayloadKind.SETUP_SNOWPIPE] = TaskPayloadKind.SETUP_SNOWPIPE


@dataclass
class TeardownSnowpipePayload:
    """
    Payload for dropping a Snowpipe after migration completes or fails.

    This is always a cleanup task so it runs even when predecessors fail.
    """

    pipe_name: str
    """Fully qualified Snowpipe name to drop."""

    kind: Literal[TaskPayloadKind.TEARDOWN_SNOWPIPE] = TaskPayloadKind.TEARDOWN_SNOWPIPE


TaskPayload = (
    DataMovementTaskPayload
    | PreprocessingCheckPayload
    | DeterminePartitionStrategyTaskPayload
    | CreatePartitionTasksPayload
    | ProcessStagedDataTaskPayload
    | SnowflakeQueryTaskPayload
    | SnowpipeTaskPayload
    | CompletePartitionMigrationTaskPayload
    | ComparePartitionChecksumPayload
    | ProcessChecksumResultPayload
    | ClearPartitionDataPayload
    | DeduplicatePartitionDataPayload
    | SetupSnowpipePayload
    | TeardownSnowpipePayload
)
