"""
Teradata to Snowflake data type mappings.

This module provides a comprehensive mapping from Teradata data types
to their equivalent Snowflake data types.

Reference:
- Teradata data types: https://docs.teradata.com/r/Teradata-VantageCloud-Lake/SQL-Data-Types-and-Literals
- Snowflake data types: https://docs.snowflake.com/en/sql-reference/intro-summary-data-types
"""

# Comprehensive mapping of Teradata types to Snowflake types
# Keys are lowercase for case-insensitive lookup
TERADATA_TO_SNOWFLAKE_TYPE_MAPPINGS: dict[str, str] = {
    # Integer types
    "byteint": "NUMBER(3,0)",
    "smallint": "NUMBER(5,0)",
    "integer": "NUMBER(10,0)",
    "int": "NUMBER(10,0)",
    "bigint": "NUMBER(19,0)",
    # Decimal/Numeric types (precision preserved in actual migration)
    "decimal": "NUMBER(20,10)",
    "numeric": "NUMBER(20,10)",
    "number": "NUMBER(20,10)",
    # Floating point types
    "float": "FLOAT",
    "real": "FLOAT",
    "double precision": "FLOAT",
    # Character types
    "char": "VARCHAR",
    "character": "VARCHAR",
    "varchar": "VARCHAR",
    "char varying": "VARCHAR",
    "character varying": "VARCHAR",
    "long varchar": "VARCHAR(32000)",
    "clob": "VARCHAR(16777216)",
    # Unicode character types
    "graphic": "VARCHAR",
    "vargraphic": "VARCHAR",
    # Binary types
    "byte": "BINARY",
    "varbyte": "BINARY",
    "blob": "BINARY(8388608)",
    # Boolean type (Teradata does not have native BOOLEAN, but some versions support it)
    "boolean": "BOOLEAN",
    # Date/Time types
    "date": "DATE",
    "time": "TIME",
    "time with time zone": "TIME",
    "timestamp": "TIMESTAMP_NTZ",
    "timestamp with time zone": "TIMESTAMP_TZ",
    # Interval types (no direct Snowflake equivalent — store as VARCHAR)
    "interval year": "VARCHAR",
    "interval year to month": "VARCHAR",
    "interval month": "VARCHAR",
    "interval day": "VARCHAR",
    "interval day to hour": "VARCHAR",
    "interval day to minute": "VARCHAR",
    "interval day to second": "VARCHAR",
    "interval hour": "VARCHAR",
    "interval hour to minute": "VARCHAR",
    "interval hour to second": "VARCHAR",
    "interval minute": "VARCHAR",
    "interval minute to second": "VARCHAR",
    "interval second": "VARCHAR",
    # Period types (temporal — store as VARCHAR representation)
    "period(date)": "VARCHAR",
    "period(time)": "VARCHAR",
    "period(time with time zone)": "VARCHAR",
    "period(timestamp)": "VARCHAR",
    "period(timestamp with time zone)": "VARCHAR",
    # Semi-structured types
    "json": "VARIANT",
    "xml": "VARCHAR(16777216)",
    # Geospatial types
    "st_geometry": "VARCHAR(16777216)",
    # Complex / special types
    "array": "VARIANT",
    "udt": "VARCHAR",
    # DBC.ColumnsV ColumnType abbreviation codes
    "i1": "NUMBER(3,0)",  # BYTEINT
    "i2": "NUMBER(5,0)",  # SMALLINT
    "i": "NUMBER(10,0)",  # INTEGER
    "i8": "NUMBER(19,0)",  # BIGINT
    "d": "NUMBER(20,10)",  # DECIMAL
    "n": "NUMBER(20,10)",  # NUMBER / NUMERIC
    "f": "FLOAT",  # FLOAT / DOUBLE PRECISION
    "cf": "VARCHAR",  # CHAR (LATIN)
    "cv": "VARCHAR",  # VARCHAR (LATIN)
    "co": "VARCHAR(16777216)",  # CLOB
    "bf": "BINARY",  # BYTE
    "bv": "BINARY",  # VARBYTE
    "bo": "BINARY(8388608)",  # BLOB
    "da": "DATE",  # DATE
    "at": "TIME",  # TIME
    "tz": "TIME",  # TIME WITH TIME ZONE
    "ts": "TIMESTAMP_NTZ",  # TIMESTAMP
    "sz": "TIMESTAMP_TZ",  # TIMESTAMP WITH TIME ZONE
    "a1": "VARCHAR",  # ARRAY / UDT
    "an": "VARIANT",  # ARRAY
    "jn": "VARIANT",  # JSON
    "xm": "VARCHAR(16777216)",  # XML
    "gf": "VARCHAR",  # GRAPHIC
    "gv": "VARCHAR",  # VARGRAPHIC
    "pm": "VARCHAR",  # PERIOD(DATE) and others
    "ps": "VARCHAR",  # PERIOD(TIMESTAMP)
    "pz": "VARCHAR",  # PERIOD(TIMESTAMP WITH TIME ZONE)
    "pt": "VARCHAR",  # PERIOD(TIME)
    "pd": "VARCHAR",  # PERIOD(DATE)
    "ut": "VARCHAR",  # UDT
    "yr": "VARCHAR",  # INTERVAL YEAR
    "ym": "VARCHAR",  # INTERVAL YEAR TO MONTH
    "mo": "VARCHAR",  # INTERVAL MONTH
    "dy": "VARCHAR",  # INTERVAL DAY
    "dh": "VARCHAR",  # INTERVAL DAY TO HOUR
    "dm": "VARCHAR",  # INTERVAL DAY TO MINUTE
    "ds": "VARCHAR",  # INTERVAL DAY TO SECOND
    "hr": "VARCHAR",  # INTERVAL HOUR
    "hm": "VARCHAR",  # INTERVAL HOUR TO MINUTE
    "hs": "VARCHAR",  # INTERVAL HOUR TO SECOND
    "mi": "VARCHAR",  # INTERVAL MINUTE
    "ms": "VARCHAR",  # INTERVAL MINUTE TO SECOND
    "sc": "VARCHAR",  # INTERVAL SECOND
    "uc": "VARCHAR",  # UNICODE CHAR
    "uv": "VARCHAR",  # UNICODE VARCHAR
}


def get_snowflake_type(
    teradata_type: str,
    precision: int | None = None,
    scale: int | None = None,
    length: int | None = None,
) -> str:
    """
    Get the Snowflake equivalent type for a Teradata type.

    This function provides more precise mapping when precision/scale/length
    are known from the source schema.

    Args:
        teradata_type: Teradata data type name
        precision: Numeric precision (for DECIMAL/NUMERIC/NUMBER)
        scale: Numeric scale (for DECIMAL/NUMERIC/NUMBER)
        length: Character or byte length (for CHAR/VARCHAR/BYTE/VARBYTE)

    Returns:
        Snowflake data type string

    """
    normalized = teradata_type.lower().strip()

    # Handle parameterized numeric types (full names and DBC codes)
    if (
        normalized in ("decimal", "numeric", "number", "d", "n")
        and precision is not None
    ):
        actual_scale = scale if scale is not None else 0
        return f"NUMBER({precision},{actual_scale})"

    # Handle parameterized character types (full names and DBC codes)
    if normalized in ("char", "character", "cf") and length is not None:
        return f"CHAR({length})"

    if (
        normalized in ("varchar", "char varying", "character varying", "cv")
        and length is not None
    ):
        return f"VARCHAR({length})"

    # Handle parameterized binary types (full names and DBC codes)
    if normalized in ("byte", "varbyte", "bf", "bv") and length is not None:
        return f"BINARY({length})"

    # Handle CLOB with explicit length
    if normalized == "clob" and length is not None:
        return f"VARCHAR({min(length, 16777216)})"

    # Handle BLOB with explicit length
    if normalized == "blob" and length is not None:
        return f"BINARY({min(length, 8388608)})"

    # Handle GRAPHIC/VARGRAPHIC with length
    if normalized in ("graphic", "vargraphic") and length is not None:
        return f"VARCHAR({length})"

    # Fall back to default mapping
    return TERADATA_TO_SNOWFLAKE_TYPE_MAPPINGS.get(normalized, "VARCHAR")
