"""
Azure Synapse Analytics to Snowflake type mappings.

Synapse Dedicated SQL Pool supports a subset of SQL Server types.
Unsupported types (hierarchyid, image, text, ntext, sql_variant, xml,
geography, geometry) are excluded.
"""

AZURE_SYNAPSE_TO_SNOWFLAKE_TYPE_MAPPINGS: dict[str, str] = {
    "BIGINT": "NUMBER",
    "INT": "NUMBER",
    "SMALLINT": "NUMBER",
    "TINYINT": "NUMBER",
    "DECIMAL": "NUMBER",
    "NUMERIC": "NUMBER",
    "MONEY": "NUMBER",
    "SMALLMONEY": "NUMBER",
    "FLOAT": "FLOAT",
    "REAL": "FLOAT",
    "BIT": "BOOLEAN",
    "CHAR": "VARCHAR",
    "VARCHAR": "VARCHAR",
    "NCHAR": "VARCHAR",
    "NVARCHAR": "VARCHAR",
    "DATE": "DATE",
    "TIME": "TIME",
    "DATETIME": "TIMESTAMP_NTZ",
    "DATETIME2": "TIMESTAMP_NTZ",
    "SMALLDATETIME": "TIMESTAMP_NTZ",
    "DATETIMEOFFSET": "TIMESTAMP_TZ",
    "BINARY": "BINARY",
    "VARBINARY": "BINARY",
    "UNIQUEIDENTIFIER": "VARCHAR",
}
