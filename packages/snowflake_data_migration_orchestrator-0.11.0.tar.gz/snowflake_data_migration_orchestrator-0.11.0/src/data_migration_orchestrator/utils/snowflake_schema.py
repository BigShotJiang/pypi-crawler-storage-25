"""
Snowflake database and schema provisioning utilities.

Provides helpers that check for existence before creating, so callers don't
need CREATE privileges when the objects already exist.
"""

import logging

from collections.abc import Awaitable, Callable
from typing import Any

from data_migration_orchestrator.utils.snowflake_identifiers import (
    normalize_identifier_for_metadata_lookup,
    quote_identifier,
)


logger = logging.getLogger(__name__)


def _escape_like_pattern(pattern: str) -> str:
    r"""
    Escape a Snowflake LIKE/string-literal pattern (single-quote and backslash only).

    Snowflake LIKE patterns use ``\`` as the default escape character.  Callers
    pass identifier names directly, so we only need to escape characters that
    would prematurely terminate the literal or be misinterpreted as escapes.
    """
    return pattern.replace("\\", "\\\\").replace("'", "''")


def _skip_ws(s: str, i: int) -> int:
    while i < len(s) and s[i].isspace():
        i += 1
    return i


def _consume_snowflake_identifier_segment(stage_id: str, i: int) -> tuple[str, int]:
    """
    Read one Snowflake identifier starting at *i*.

    - Double-quoted (``"..."``): inner text is returned as-is except ``""`` → ``"``.
    - Unquoted: characters until the next ``.`` delimiter; result is stripped and
      folded to uppercase (Snowflake unquoted identifier rules).

    Returns:
        Tuple of (normalized name, index of first character after this segment).

    """
    if i >= len(stage_id):
        raise ValueError(f"Expected identifier segment in {stage_id!r}")

    if stage_id[i] != '"':
        start = i
        while i < len(stage_id) and stage_id[i] != ".":
            i += 1
        raw = stage_id[start:i].strip()
        if not raw:
            raise ValueError(f"Empty identifier segment in {stage_id!r}")
        return raw.upper(), i

    i += 1
    out: list[str] = []
    n = len(stage_id)
    while i < n:
        if stage_id[i] == '"' and i + 1 < n and stage_id[i + 1] == '"':
            out.append('"')
            i += 2
            continue
        if stage_id[i] == '"':
            return "".join(out), i + 1
        out.append(stage_id[i])
        i += 1
    raise ValueError(f"Unterminated quoted identifier in {stage_id!r}")


def parse_external_stage_three_part_name(stage_id: str) -> tuple[str, str, str]:
    """
    Parse ``@DATABASE.SCHEMA.STAGE_NAME`` into three identifier components.

    Supports Snowflake identifier rules:

    - **Unquoted** segments are folded to **uppercase** (case-insensitive identifiers).
    - **Quoted** segments (``"..."``) preserve **case** and may contain ``.`` or other
      characters; double-quote inside a quoted id is escaped as ``""``.

    Raises:
        ValueError: If *stage_id* is not a valid three-part Snowflake stage reference.

    """
    s = stage_id.strip()
    if not s:
        raise ValueError("Empty external stage identifier")
    s = s.removeprefix("@").lstrip()

    bad_three_part = (
        "Expected external stage identifier like @DATABASE.SCHEMA.STAGE_NAME "
        f"(quoted segments allowed); got {stage_id!r}"
    )
    i = _skip_ws(s, 0)
    parts: list[str] = []
    for _ in range(2):
        part, i = _consume_snowflake_identifier_segment(s, i)
        parts.append(part)
        i = _skip_ws(s, i)
        if i >= len(s) or s[i] != ".":
            raise ValueError(bad_three_part)
        i = _skip_ws(s, i + 1)

    part, i = _consume_snowflake_identifier_segment(s, i)
    parts.append(part)
    i = _skip_ws(s, i)
    if i != len(s):
        raise ValueError(
            "Expected exactly three identifier segments for external stage; "
            f"trailing content {s[i:]!r} in {stage_id!r}"
        )
    return parts[0], parts[1], parts[2]


async def ensure_database_and_schema(
    execute_query: Callable[[str], Awaitable[list[Any]]],
    database_name: str,
    schema_name: str,
) -> None:
    """
    Ensure a Snowflake database and schema exist, creating them if needed.

    Uses SHOW commands to check existence first, avoiding CREATE IF NOT EXISTS
    which requires CREATE privileges even when the object already exists.

    Identifier handling follows Snowflake rules: unquoted names are
    case-insensitive (folded to upper-case), quoted names preserve case.

    Args:
        execute_query: Async callable that executes a SQL query and returns
            a list of results (empty list when no rows match).
        database_name: Name of the database to ensure exists.
        schema_name: Name of the schema to ensure exists.

    """
    db_lookup = normalize_identifier_for_metadata_lookup(database_name)
    schema_lookup = normalize_identifier_for_metadata_lookup(schema_name)
    quoted_db_for_create = quote_identifier(database_name, force_quote=False)
    quoted_schema_for_create = quote_identifier(schema_name, force_quote=False)

    db_rows = await execute_query(
        f"SHOW DATABASES LIKE '{_escape_like_pattern(db_lookup)}'"
    )
    if not db_rows:
        logger.info("Database %s does not exist, creating...", database_name)
        await execute_query(f"CREATE DATABASE IF NOT EXISTS {quoted_db_for_create}")
    else:
        logger.info("Database %s already exists, skipping creation", database_name)

    schema_rows = await execute_query(
        f"SHOW SCHEMAS LIKE '{_escape_like_pattern(schema_lookup)}' "
        f"IN DATABASE {quoted_db_for_create}"
    )
    if not schema_rows:
        logger.info("Schema %s does not exist, creating...", schema_name)
        await execute_query(
            f"CREATE SCHEMA IF NOT EXISTS "
            f"{quoted_db_for_create}.{quoted_schema_for_create}"
        )
    else:
        logger.info("Schema %s already exists, skipping creation", schema_name)


async def validate_external_stage_exists(
    execute_query: Callable[[str], Awaitable[list[Any]]],
    database_name: str,
    schema_name: str,
    stage_name: str,
) -> None:
    """
    Confirm that an external stage exists and is visible to the current role.

    The orchestrator does **not** create external stages. Operators must define
    the stage (URL, ``STORAGE_INTEGRATION``, grants) in Snowflake before running
    workflows that use it.

    Args:
        execute_query: Async callable that executes SQL and returns row list.
        database_name: Stage database.
        schema_name: Stage schema.
        stage_name: Stage object name (last segment of ``@DB.SCHEMA.STAGE``).

    Raises:
        ValueError: If ``SHOW STAGES`` finds no matching stage.

    """
    quoted_db = quote_identifier(database_name, force_quote=False)
    quoted_schema = quote_identifier(schema_name, force_quote=False)
    quoted_stage = quote_identifier(stage_name, force_quote=False)

    stage_lookup = normalize_identifier_for_metadata_lookup(stage_name)
    esc_stage_like = _escape_like_pattern(stage_lookup)
    rows = await execute_query(
        f"SHOW STAGES LIKE '{esc_stage_like}' IN SCHEMA {quoted_db}.{quoted_schema}"
    )
    if not rows:
        raise ValueError(
            f"External stage {quoted_db}.{quoted_schema}.{quoted_stage} does not exist "
            "or is not accessible with the current role. Create the stage in Snowflake "
            "(including URL and STORAGE_INTEGRATION) and grant USAGE before running "
            "this workflow."
        )

    logger.info(
        "Validated external stage %s.%s.%s exists",
        database_name,
        schema_name,
        stage_name,
    )


def ensure_database_and_schema_sync(
    execute_and_fetch: Callable[[str], Any],
    database_name: str,
    schema_name: str,
) -> None:
    """
     Ensure a Snowflake database and schema exist, creating them if needed (synchronous).

    Identifier handling follows Snowflake rules: unquoted names are
    case-insensitive (folded to upper-case), quoted names preserve case.

    Args:
        execute_and_fetch: Callable that executes a SQL query and returns the
            first row (or a falsy value when no rows match).
        database_name: Name of the database to ensure exists.
        schema_name: Name of the schema to ensure exists.

    """
    db_lookup = normalize_identifier_for_metadata_lookup(database_name)
    schema_lookup = normalize_identifier_for_metadata_lookup(schema_name)
    quoted_db_for_create = quote_identifier(database_name, force_quote=False)
    quoted_schema_for_create = quote_identifier(schema_name, force_quote=False)

    db_result = execute_and_fetch(
        f"SHOW DATABASES LIKE '{_escape_like_pattern(db_lookup)}'"
    )
    if not db_result:
        logger.info("Database %s does not exist, creating...", database_name)
        execute_and_fetch(f"CREATE DATABASE IF NOT EXISTS {quoted_db_for_create}")
    else:
        logger.info("Database %s already exists, skipping creation", database_name)

    schema_result = execute_and_fetch(
        f"SHOW SCHEMAS LIKE '{_escape_like_pattern(schema_lookup)}' "
        f"IN DATABASE {quoted_db_for_create}"
    )
    if not schema_result:
        logger.info("Schema %s does not exist, creating...", schema_name)
        execute_and_fetch(
            f"CREATE SCHEMA IF NOT EXISTS "
            f"{quoted_db_for_create}.{quoted_schema_for_create}"
        )
    else:
        logger.info("Schema %s already exists, skipping creation", schema_name)
