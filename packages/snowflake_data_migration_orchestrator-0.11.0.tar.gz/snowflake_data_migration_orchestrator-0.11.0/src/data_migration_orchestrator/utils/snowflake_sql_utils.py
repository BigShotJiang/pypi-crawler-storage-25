"""
Generic SQL utility functions for query construction and value sanitization.

``build_snowflake_fqn`` is defined in :mod:`data_migration_orchestrator.utils.snowflake_identifiers`
(same implementation re-exported from
``data_migration_cloud.platforms.snowflake.identifiers`` for platform code).
"""

from data_migration_orchestrator.utils.snowflake_identifiers import build_snowflake_fqn


__all__ = [
    "build_snowflake_fqn",
    "escape_sql_string",
    "quote_snowflake_identifier_if_needed",
    "quote_string_literal",
]


# Characters allowed in unquoted Snowflake identifiers (Snowflake docs: SQL data
# types reference > Identifiers).  Letters and digits are case-folded to upper
# at storage time when unquoted.
_SNOWFLAKE_UNQUOTED_ALLOWED = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_$")


def quote_snowflake_identifier_if_needed(identifier: str) -> str:
    """
    Quote a Snowflake identifier only when needed.

    Returns *identifier* unquoted when it is already a valid unquoted Snowflake
    identifier; otherwise returns it double-quoted with internal ``"`` doubled.

    Rules (mirrors Snowflake parser):
        - First character must be a letter (A-Z) or underscore.
        - Remaining characters must be letters, digits, underscores, or ``$``.
        - Letters must be uppercase (mixed-case implies the writer cared about
          case, so we quote to preserve it).

    Empty input returns ``""`` so callers can join non-empty parts with dots.
    """
    if not identifier:
        return ""
    first = identifier[0]
    is_unquoted = (
        (first.isalpha() or first == "_")
        and identifier == identifier.upper()
        and all(c in _SNOWFLAKE_UNQUOTED_ALLOWED for c in identifier)
    )
    if is_unquoted:
        return identifier
    return '"' + identifier.replace('"', '""') + '"'


def escape_sql_string(value: str) -> str:
    """
    Escape a string value for safe use in Snowflake SQL string literals.

    Snowflake treats backslash as an escape character inside single-quoted
    strings, so both backslashes and single quotes must be escaped.

    Args:
        value: The string value to escape

    Returns:
        The escaped string (without surrounding quotes)

    """
    return value.replace("\\", "\\\\").replace("'", "''")


def quote_string_literal(value: str, unicode_prefix: bool = False) -> str:
    """
    Quote a string value for use in SQL queries.

    This function wraps a string value in single quotes for use as a SQL string literal.
    It also escapes internal single quotes by doubling them.

    Args:
        value: The string value to quote
        unicode_prefix: If True, prefix with N for SQL Server Unicode literals (N'...')

    Returns:
        The quoted string literal

    """
    escaped_value = escape_sql_string(value)
    prefix = "N" if unicode_prefix else ""
    return f"{prefix}'{escaped_value}'"
