"""SQL builders for bulk INSERT into PARTITION_METADATA (migration and validation schemas)."""

from collections.abc import Iterator
from typing import Any


PARTITION_METADATA_INSERT_CHUNK_SIZE = 10_000


def format_sql_literal_for_values(value: Any) -> str:
    """
    Format a Python value as a plain SQL literal (no VARIANT cast).

    Suitable for use inside VALUES clauses where ::VARIANT casts are not allowed.
    """
    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, int | float):
        return str(value)
    if isinstance(value, str):
        try:
            int(value)
            return value
        except ValueError:
            pass
        try:
            float(value)
            return value
        except ValueError:
            pass
        escaped = value.replace("'", "''")
        return f"'{escaped}'"
    escaped = str(value).replace("'", "''")
    return f"'{escaped}'"


def build_bulk_insert_partition_metadata_sql(
    qualified_schema: str,
    table_metadata_id: int,
    partitions: list[tuple[int, Any, Any, int | None]],
    status_column: str,
    status_sql_literal: str,
) -> str:
    """
    Build a single INSERT ... SELECT ... FROM VALUES for PARTITION_METADATA.

    Args:
        qualified_schema: Fully qualified schema name (e.g. DB.SCHEMA).
        table_metadata_id: Parent TABLE_METADATA.ID.
        partitions: Rows as (partition_number, min_value, max_value, n_rows).
        status_column: Target column name (MIGRATION_STATUS or VALIDATION_STATUS).
        status_sql_literal: Quoted SQL literal for the status value, e.g. "'EXTRACTING'".

    """
    if not partitions:
        raise ValueError("partitions must be non-empty")

    values_rows: list[str] = []
    for partition_number, min_value, max_value, n_rows in partitions:
        min_sql = format_sql_literal_for_values(min_value)
        max_sql = format_sql_literal_for_values(max_value)
        rows_sql = str(n_rows) if n_rows is not None else "NULL"
        values_rows.append(
            f"({table_metadata_id}, {partition_number}, {min_sql}, {max_sql}, "
            f"{rows_sql}, {status_sql_literal})"
        )

    vs = ", ".join(values_rows)
    return (
        f"INSERT INTO {qualified_schema}.PARTITION_METADATA "
        f"(ID, TABLE_ID, PARTITION_NUMBER, MIN_VALUE, MAX_VALUE, N_ROWS, {status_column}) "
        f"SELECT {qualified_schema}.PARTITION_METADATA_ID_SEQ.NEXTVAL, "
        "column1, column2, TO_VARIANT(column3), TO_VARIANT(column4), column5, column6 "
        f"FROM VALUES {vs}"
    )


def iter_bulk_insert_partition_metadata_sqls(
    qualified_schema: str,
    table_metadata_id: int,
    partitions: list[tuple[int, Any, Any, int | None]],
    status_column: str,
    status_sql_literal: str,
    chunk_size: int = PARTITION_METADATA_INSERT_CHUNK_SIZE,
) -> Iterator[str]:
    """
    Yield chunked INSERT statements for PARTITION_METADATA.

    Splitting the bulk insert is required for tables with very large partition
    counts: Snowflake rejects a single ``VALUES`` clause with more than
    200,000 expressions, and a single statement is also capped at ~1 MiB of
    inline SQL text. Both limits are easily hit on tables with hundreds of
    thousands of partitions.

    Args:
        qualified_schema: Fully qualified schema name (e.g. DB.SCHEMA).
        table_metadata_id: Parent TABLE_METADATA.ID.
        partitions: Rows as (partition_number, min_value, max_value, n_rows).
        status_column: Target column name (MIGRATION_STATUS or VALIDATION_STATUS).
        status_sql_literal: Quoted SQL literal for the status value, e.g. "'EXTRACTING'".
        chunk_size: Maximum number of partition rows per INSERT statement.

    Raises:
        ValueError: If ``partitions`` is empty or ``chunk_size`` is non-positive.

    """
    if not partitions:
        raise ValueError("partitions must be non-empty")
    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive")

    for offset in range(0, len(partitions), chunk_size):
        chunk = partitions[offset : offset + chunk_size]
        yield build_bulk_insert_partition_metadata_sql(
            qualified_schema,
            table_metadata_id,
            chunk,
            status_column=status_column,
            status_sql_literal=status_sql_literal,
        )
