"""
Snowflake identifier quoting, unquoting, and fully qualified name assembly.

Lives under ``utils`` so ``snowflake_sql_utils`` and other low-level modules can
use :func:`build_snowflake_fqn` without importing ``data_migration_cloud``
(import rules forbid ``utils`` → ``data_migration_cloud``).

``data_migration_cloud.platforms.snowflake.identifiers`` re-exports these
symbols for backward compatibility.
"""

from __future__ import annotations

import re


# Valid Snowflake identifiers (no quoting needed):
# starts with a letter or underscore, followed by letters/digits/underscores/$.
_VALID_IDENTIFIER_PATTERN = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_$]*$")


def is_already_quoted(identifier: str) -> bool:
    """Check if an identifier is already double-quoted."""
    return identifier.startswith('"') and identifier.endswith('"')


def needs_quoting(identifier: str) -> bool:
    """
    Check if a Snowflake identifier needs to be quoted.

    Unquoted identifiers are case-insensitive in Snowflake (converted to
    uppercase automatically), so lowercase names work without quoting.
    Only structural issues (spaces, dots, leading digits, etc.) require
    quoting.
    """
    if not identifier:
        return True
    if is_already_quoted(identifier):
        return False
    return not _VALID_IDENTIFIER_PATTERN.match(identifier)


def quote_identifier(identifier: str, force_quote: bool = True) -> str:
    """
    Quote an identifier for Snowflake using double quotes.

    Internal ``"`` characters are escaped by doubling them.

    Args:
        identifier: The identifier to quote
        force_quote: If True, always quote. If False, only quote if necessary.

    Returns:
        The quoted identifier in ``"double quote"`` notation

    """
    if not identifier:
        return '""'
    if is_already_quoted(identifier):
        return identifier
    if not force_quote and not needs_quoting(identifier):
        return identifier
    escaped = identifier.replace('"', '""')
    return f'"{escaped}"'


def unquote_identifier(identifier: str) -> str:
    """Remove Snowflake double-quote quoting from an identifier."""
    if is_already_quoted(identifier):
        return identifier[1:-1].replace('""', '"')
    return identifier


def normalize_identifier_for_metadata_lookup(identifier: str) -> str:
    """
    Normalize a Snowflake identifier to the form stored in the metadata layer.

    Snowflake folds **unquoted** identifiers to upper-case at parse time, while
    **quoted** identifiers preserve the inner case verbatim. Use this helper
    when constructing string literals for ``SHOW ... LIKE '<pattern>'`` and for
    ``INFORMATION_SCHEMA`` predicates that compare against the stored name --
    those comparisons are case-sensitive against the stored (folded) form.

    Examples:
        - ``SampleDB``      -> ``SAMPLEDB``     (unquoted, case-insensitive)
        - ``"My_TaBle"``    -> ``My_TaBle``     (quoted, case-sensitive)
        - quoted identifier with an escaped ``""`` is unescaped to a single
          ``"`` while inner case is preserved.

    """
    s = identifier.strip()
    if is_already_quoted(s):
        return s[1:-1].replace('""', '"')
    return s.upper()


def build_snowflake_fqn(
    database: str | None,
    schema: str | None,
    name: str,
) -> str:
    """
    Build a Snowflake fully qualified name for the target.

    Joins ``database.schema.name``, quoting each non-empty part with
    :func:`quote_identifier` when required (``force_quote=False``).  Missing
    database or schema are omitted.  The *name* component is required.

    This is the **target** Snowflake naming used regardless of source platform
    (replaces source-platform FQN helpers when the target is Snowflake).
    """
    if not name:
        raise ValueError(
            "Snowflake FQN requires at least a non-empty table/object name"
        )
    parts = [
        quote_identifier(part, force_quote=False) if part else ""
        for part in (database, schema, name)
    ]
    return ".".join(p for p in parts if p)


__all__ = [
    "build_snowflake_fqn",
    "is_already_quoted",
    "needs_quoting",
    "normalize_identifier_for_metadata_lookup",
    "quote_identifier",
    "unquote_identifier",
]
