"""Re-apply affinity-aware claim procedures so workers without an affinity stop pulling affined work."""

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)


class Migration0024AffinityClaimFix(BaseMigration):
    """
    Tighten the affinity predicate in the three claim procedures.

    Prior versions of ``PULL_SINGLE_TASK``, ``PULL_MANY_TASKS`` and
    ``GET_PENDING_WORKFLOWS`` matched a row when **either** the worker had no
    affinity (``:affinity IS NULL``) **or** the row had no affinity. That made
    a worker without an affinity claim every task, regardless of the row's
    ``AFFINITY``. The expected behavior is that an unaffined worker only picks
    up tasks/workflows whose ``AFFINITY IS NULL``; affined work must wait for a
    matching (or wildcard ``*``) worker.

    The procedures are recreated via ``CREATE OR REPLACE PROCEDURE``, so this
    migration just re-applies the updated ``.sql.j2`` assets — no data changes
    are required.
    """

    @property
    def version(self) -> int:
        """Return version 24."""
        return 24

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return (
            "Fix affinity claim predicate in PULL_SINGLE_TASK, PULL_MANY_TASKS, "
            "and GET_PENDING_WORKFLOWS so a worker without affinity only claims "
            "tasks/workflows that have no affinity."
        )

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Re-apply the three claim procedures with the corrected predicate."""
        with connection.cursor() as cursor:
            self._execute_migration_sql_assets(
                cursor,
                [
                    "scripts/task-queue/procedures/pull_single_task.sql.j2",
                    "scripts/task-queue/procedures/pull_many_tasks.sql.j2",
                    "scripts/workflows/procedures/get_pending_workflows.sql.j2",
                ],
            )
