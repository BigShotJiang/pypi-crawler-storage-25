"""NEXT_ELIGIBLE_AT, pull/reschedule, TRY_UNBLOCK_TASK, and SKIP_ALL_DV_L3_CANDIDATE_TASKS (incl. second scope)."""

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)
from data_migration_orchestrator.utils.snowflake_metadata import sql_template_context


class Migration0023NextEligibleAt(BaseMigration):
    """Deferred pulls, periodical reschedule, L3 bulk skip with optional second SCOPE LIKE pattern."""

    @property
    def version(self) -> int:
        """Return version 23."""
        return 23

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return (
            "TASK_QUEUE.NEXT_ELIGIBLE_AT; PULL_*; RESCHEDULE_PERIODICAL_TASK; "
            "TRY_UNBLOCK_TASK; SKIP_ALL_DV_L3_CANDIDATE_TASKS "
            "(drop legacy SKIP_ONE / old SKIP_ALL overloads; optional p_scope_like_pattern_2)"
        )

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Apply column, refresh task-queue procedures, deploy SKIP_ALL for L3 early-stop."""
        qm = sql_template_context()["qualified_migration"]
        script_paths = [
            "scripts/task-queue/task_queue_add_next_eligible_at.sql.j2",
            "scripts/task-queue/procedures/pull_single_task.sql.j2",
            "scripts/task-queue/procedures/pull_many_tasks.sql.j2",
            "scripts/task-queue/procedures/reschedule_periodical_task.sql.j2",
            "scripts/task-queue/procedures/try_unblock_task.sql.j2",
            "scripts/task-queue/procedures/skip_all_dv_l3_candidate_tasks.sql.j2",
        ]
        with connection.cursor() as cursor:
            cursor.execute(
                f"DROP PROCEDURE IF EXISTS {qm}.SKIP_ONE_DV_L3_CANDIDATE_TASK("
                f"NUMBER, VARCHAR, VARCHAR, VARCHAR, NUMBER, NUMBER)"
            )
            cursor.execute(
                f"DROP PROCEDURE IF EXISTS {qm}.SKIP_ALL_DV_L3_CANDIDATE_TASKS("
                f"NUMBER, VARCHAR, VARCHAR, VARCHAR, NUMBER, NUMBER)"
            )
            cursor.execute(
                f"DROP PROCEDURE IF EXISTS {qm}.SKIP_ALL_DV_L3_CANDIDATE_TASKS("
                f"NUMBER, VARCHAR, NUMBER, NUMBER)"
            )
            cursor.execute(
                f"DROP PROCEDURE IF EXISTS {qm}.SKIP_ALL_DV_L3_CANDIDATE_TASKS("
                f"NUMBER, VARCHAR, NUMBER)"
            )
            self._execute_migration_sql_assets(cursor, script_paths)
