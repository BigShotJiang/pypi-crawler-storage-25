"""Re-apply PULL_SINGLE_TASK with snapshot-read + conditional-update claim."""

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)


class Migration0025PullSingleTaskConditionalClaim(BaseMigration):
    """
    Redeploy ``PULL_SINGLE_TASK`` to drop ``FOR UPDATE`` entirely.

    The previous version used ``SELECT ... ORDER BY PRIORITY ASC, RANDOM()
    LIMIT 1 FOR UPDATE NOWAIT`` followed by an unconditional ``UPDATE``.
    Under hybrid-table OCC this collapsed to a hot-row contention regardless
    of the ``RANDOM()`` tiebreaker: every worker's ``FOR UPDATE`` statement
    locks (or at minimum, conflicts with peer commits across) the scanned
    pending range, so any concurrent committer aborted everyone else with
    the wrapped ``200010`` "has locked a key" error. The DEA absorbs the
    error via exponential backoff (``_is_transient_lock_wait``), but the
    throughput cost was significant under dozens of concurrent workers.

    The new procedure:

    1. **Phase 1** – snapshot up to 100 eligible candidate IDs in a
       read-only statement (no ``FOR UPDATE``, no row locks). Ordered by
       ``PRIORITY ASC, RANDOM()`` so high-priority work still goes first
       while equal-priority rows are shuffled per worker.
    2. **Phase 2** – pick one ID uniformly at random inside the procedure
       using ``UNIFORM(0, n-1, RANDOM())``.
    3. **Phase 3** – inside ``BEGIN TRANSACTION``, claim the row with a
       conditional point UPDATE: ``UPDATE ... WHERE ID = :picked AND
       LEASED_TO IS NULL AND STATUS = 'pending'``. The ``WHERE`` predicate
       is the lock; if a peer beat us to the row, ``SQLROWCOUNT = 0`` and
       we ``COMMIT`` the empty transaction and loop with a fresh snapshot.
       If the UPDATE succeeds, the readback ``SELECT`` runs in the same
       transaction and ``COMMIT`` makes both visible atomically. The
       ``WHEN OTHER`` exception handler ``ROLLBACK``s the transaction so
       no row is left leased without being reported back to the worker.
       No ``NOWAIT`` exception is ever raised by ``FOR UPDATE`` because we
       no longer use it.

    Per-worker write-lock surface drops from "the entire scanned range" to
    one row's primary key, so 50 concurrent workers contend over 50 distinct
    keys instead of overlapping ranges. A small bounded retry (3 attempts)
    covers the rare case where two workers ``RANDOM()``-pick the same ID;
    beyond that, the SP returns empty and the client's existing back-off
    handles the heavy-contention regime.

    The procedure is recreated via ``CREATE OR REPLACE PROCEDURE``, so this
    migration just re-applies the updated ``.sql.j2`` asset.
    """

    @property
    def version(self) -> int:
        """Return version 25."""
        return 25

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return (
            "Redeploy PULL_SINGLE_TASK with snapshot-read + conditional-update "
            "claim (no FOR UPDATE) to remove hybrid-table OCC contention "
            "under high worker concurrency."
        )

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Re-apply ``PULL_SINGLE_TASK`` with the conditional-claim pattern."""
        with connection.cursor() as cursor:
            self._execute_migration_sql_assets(
                cursor,
                [
                    "scripts/task-queue/procedures/pull_single_task.sql.j2",
                ],
            )
