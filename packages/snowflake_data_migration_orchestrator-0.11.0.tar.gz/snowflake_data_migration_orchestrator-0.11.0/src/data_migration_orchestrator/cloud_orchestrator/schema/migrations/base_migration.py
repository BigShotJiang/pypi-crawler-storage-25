"""Base migration class for schema migrations."""

from __future__ import annotations

import time

from abc import ABC, abstractmethod
from pathlib import Path

import snowflake.connector

from snowflake.connector.cursor import SnowflakeCursor

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.utils.snowflake_metadata import (
    metadata_database,
    migration_metadata_schema,
)
from data_migration_orchestrator.utils.templated_sql import execute_migration_sql_asset


logger = get_logger(__name__)


# Hybrid-table secondary indexes are built asynchronously: CREATE INDEX returns
# immediately while the build runs in the background, and only one build per
# table can be in progress at a time. Issuing a second CREATE INDEX on the same
# table while a previous build is still running fails with errors like
# "Another index is being built". To make schema migrations deterministic, we
# poll INFORMATION_SCHEMA.INDEXES for the index STATUS and only return once the
# build has finished.
#
# Default timeout is sized for TASK_QUEUE in the wild: indexed columns here are
# small scalars, and even tens of millions of rows finish in a few minutes.
# 10 minutes is a safety net, not a target -- the helper returns as soon as
# the build is ACTIVE. Increase the constants if a customer is observed to need
# more headroom.
DEFAULT_INDEX_BUILD_TIMEOUT_S = 600.0
DEFAULT_INDEX_BUILD_POLL_INTERVAL_S = 2.0

_INDEX_STATUS_ACTIVE = "ACTIVE"
_INDEX_STATUS_BUILD_IN_PROGRESS = "BUILD IN PROGRESS"
_INDEX_STATUS_BUILD_FAILURE = "BUILD FAILURE"


class IndexBuildFailedError(RuntimeError):
    """Raised when a hybrid-table index build ends in BUILD FAILURE status."""


class IndexBuildTimeoutError(RuntimeError):
    """Raised when a hybrid-table index build does not finish in time."""


class BaseMigration(ABC):
    """
    Abstract base class for schema migrations.

    All schema migrations must inherit from this class and implement the required methods.
    """

    @property
    @abstractmethod
    def version(self) -> int:
        """
        Return the migration version number.

        Returns:
            int: Unique version number for this migration (must be positive integer)

        """
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """
        Return a description of this migration.

        Returns:
            str: Human-readable description of what this migration does

        """
        pass

    def needs_reapply(
        self, connection: snowflake.connector.SnowflakeConnection
    ) -> bool:
        """
        Check whether this migration must be re-applied.

        Called for every applied migration on startup.
        Override in subclasses whose artifacts (schemas, tables, etc.) can be
        dropped independently of the migration tracker.

        Returns ``False`` by default (no re-apply needed).
        """
        return False

    @abstractmethod
    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """
        Apply this migration.

        Args:
            connection: Active Snowflake connection to execute migration against

        Raises:
            Exception: If migration fails for any reason

        """
        pass

    def _get_assets_directory(self) -> str:
        """
        Return the absolute path to the package ``assets`` directory.

        ``base_migration.py`` lives next to concrete migrations under
        ``.../schema/migrations/``; three parents up is ``data_migration_orchestrator/``.
        """
        migrations_dir = Path(__file__).resolve().parent
        package_root = migrations_dir.parent.parent.parent
        assets_dir = package_root / "assets"
        if not assets_dir.exists():
            raise FileNotFoundError(f"Assets directory not found: {assets_dir}")
        return str(assets_dir)

    def _execute_migration_sql_assets(
        self,
        cursor: SnowflakeCursor,
        script_paths: list[str],
    ) -> None:
        """Render and execute ordered ``scripts/.../*.sql.j2`` paths under assets."""
        assets_dir = self._get_assets_directory()
        label = self.__class__.__name__
        for script_path in script_paths:
            logger.info(f"[{label}] Executing: {script_path}")
            execute_migration_sql_asset(cursor, assets_dir, script_path)
            logger.info(f"[{label}] Completed: {script_path}")

    def _create_index_synchronously(
        self,
        cursor: SnowflakeCursor,
        asset_path: str,
        table: str,
        index_name: str,
        timeout_s: float = DEFAULT_INDEX_BUILD_TIMEOUT_S,
        poll_interval_s: float = DEFAULT_INDEX_BUILD_POLL_INTERVAL_S,
    ) -> None:
        """
        Apply a CREATE [OR REPLACE] INDEX asset and wait for the build to finish.

        Hybrid-table index builds are asynchronous and Snowflake allows only one
        build per table at a time. To prevent ``Another index is being built``
        errors when later migrations create another index on the same table,
        this helper:

        1. Pre-waits for any in-progress build on the target table.
        2. Renders and executes the index DDL asset.
        3. Post-waits for the new index to reach ``ACTIVE`` status, so the
           migration is only recorded as applied once the index is usable.

        Args:
            cursor: Active Snowflake cursor.
            asset_path: Path to the ``CREATE [OR REPLACE] INDEX ...`` asset
                relative to the ``assets`` directory.
            table: Unqualified hybrid table name (e.g. ``"TASK_QUEUE"``).
            index_name: Name of the index created by ``asset_path``.
            timeout_s: Per-wait timeout in seconds.
            poll_interval_s: Polling interval in seconds.

        Raises:
            IndexBuildFailedError: If the build status reaches ``BUILD FAILURE``.
            IndexBuildTimeoutError: If the build does not finish in ``timeout_s``.

        """
        schema = migration_metadata_schema()
        database = metadata_database()
        label = self.__class__.__name__

        logger.info(
            f"[{label}] Pre-waiting for any in-progress index build on "
            f"{database}.{schema}.{table} before applying {asset_path}"
        )
        self._wait_for_no_in_progress_index_build(
            cursor=cursor,
            database=database,
            schema=schema,
            table=table,
            timeout_s=timeout_s,
            poll_interval_s=poll_interval_s,
        )

        self._execute_migration_sql_assets(cursor, [asset_path])

        logger.info(
            f"[{label}] Waiting for index {index_name} on "
            f"{database}.{schema}.{table} to reach ACTIVE status"
        )
        self._wait_for_index_active(
            cursor=cursor,
            database=database,
            schema=schema,
            table=table,
            index_name=index_name,
            timeout_s=timeout_s,
            poll_interval_s=poll_interval_s,
        )

    @staticmethod
    def _wait_for_no_in_progress_index_build(
        cursor: SnowflakeCursor,
        database: str,
        schema: str,
        table: str,
        timeout_s: float,
        poll_interval_s: float,
    ) -> None:
        """
        Block until no index on ``table`` is in ``BUILD IN PROGRESS`` state.

        Returns immediately when no index is currently building. Raises
        :class:`IndexBuildFailedError` if any index is in ``BUILD FAILURE`` and
        :class:`IndexBuildTimeoutError` if the wait exceeds ``timeout_s``.
        """
        deadline = time.monotonic() + timeout_s
        while True:
            statuses = BaseMigration._fetch_index_statuses(
                cursor, database, schema, table
            )
            BaseMigration._raise_if_any_build_failure(statuses, table)
            in_progress = [
                name
                for name, status in statuses
                if status == _INDEX_STATUS_BUILD_IN_PROGRESS
            ]
            if not in_progress:
                return
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise IndexBuildTimeoutError(
                    f"Timed out after {timeout_s:.0f}s waiting for index build(s) "
                    f"on {database}.{schema}.{table} to finish; "
                    f"still in progress: {sorted(in_progress)}"
                )
            logger.info(
                f"Index build still in progress on {database}.{schema}.{table}: "
                f"{sorted(in_progress)}. Sleeping {poll_interval_s:.1f}s "
                f"({remaining:.0f}s remaining)."
            )
            time.sleep(min(poll_interval_s, remaining))

    @staticmethod
    def _wait_for_index_active(
        cursor: SnowflakeCursor,
        database: str,
        schema: str,
        table: str,
        index_name: str,
        timeout_s: float,
        poll_interval_s: float,
    ) -> None:
        """
        Block until ``index_name`` on ``table`` reaches ``ACTIVE`` status.

        Raises :class:`IndexBuildFailedError` if the index reaches
        ``BUILD FAILURE`` and :class:`IndexBuildTimeoutError` if the wait
        exceeds ``timeout_s``.
        """
        deadline = time.monotonic() + timeout_s
        while True:
            statuses = BaseMigration._fetch_index_statuses(
                cursor, database, schema, table
            )
            target = next(
                (status for name, status in statuses if name == index_name), None
            )
            if target == _INDEX_STATUS_ACTIVE:
                return
            if target == _INDEX_STATUS_BUILD_FAILURE:
                raise IndexBuildFailedError(
                    f"Index {index_name} on {database}.{schema}.{table} "
                    f"reached BUILD FAILURE status; drop and recreate it."
                )
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise IndexBuildTimeoutError(
                    f"Timed out after {timeout_s:.0f}s waiting for index "
                    f"{index_name} on {database}.{schema}.{table} to reach "
                    f"ACTIVE (last observed status: {target!r})"
                )
            logger.info(
                f"Index {index_name} on {database}.{schema}.{table} status="
                f"{target!r}; sleeping {poll_interval_s:.1f}s "
                f"({remaining:.0f}s remaining)."
            )
            time.sleep(min(poll_interval_s, remaining))

    @staticmethod
    def _fetch_index_statuses(
        cursor: SnowflakeCursor,
        database: str,
        schema: str,
        table: str,
    ) -> list[tuple[str, str]]:
        """
        Return ``[(index_name, status), ...]`` for all indexes on ``table``.

        Reads from ``<database>.INFORMATION_SCHEMA.INDEXES``.
        """
        cursor.execute(
            f"""
            SELECT NAME, STATUS
            FROM {database}.INFORMATION_SCHEMA.INDEXES
            WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s
            """,
            (schema, table),
        )
        rows = cursor.fetchall()
        return [(str(row[0]), str(row[1])) for row in rows]

    @staticmethod
    def _raise_if_any_build_failure(
        statuses: list[tuple[str, str]], table: str
    ) -> None:
        """Raise :class:`IndexBuildFailedError` if any index is in ``BUILD FAILURE``."""
        failed = [
            name for name, status in statuses if status == _INDEX_STATUS_BUILD_FAILURE
        ]
        if failed:
            raise IndexBuildFailedError(
                f"Index(es) on {table} reached BUILD FAILURE status: "
                f"{sorted(failed)}; drop and recreate them."
            )

    def rollback(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """
        Rollback this migration (optional, not implemented in initial version).

        Args:
            connection: Active Snowflake connection to execute rollback against

        Raises:
            NotImplementedError: Rollback is not yet supported

        """
        raise NotImplementedError("Rollback is not yet supported")

    def __repr__(self) -> str:
        """Return string representation of migration."""
        return f"{self.__class__.__name__}(version={self.version}, description='{self.description}')"
