"""Create DATA_MIGRATION_WORKFLOW and DATA_VALIDATION_WORKFLOW views (SNOW-3443999)."""

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)


class Migration0022WorkflowViews(BaseMigration):
    """
    Create purpose-built views over the shared WORKFLOW table.

    The WORKFLOW table stores records for both data-migration and data-validation
    workflows, distinguished by the WORKFLOW_TYPE column.  Reading from the raw
    table requires callers to filter on WORKFLOW_TYPE themselves, which is error-
    prone and was the root cause of SNOW-3443999 (Cloud Data Validation reading
    migration-type rows).

    This migration adds two idempotent ``CREATE OR REPLACE VIEW`` statements:

    * ``DATA_MIGRATION_WORKFLOW`` — a simple filter view that projects the subset
      of columns relevant to data-migration workflows.

    * ``DATA_VALIDATION_WORKFLOW`` — a richer view that also LEFT JOINs the
      data-validation schema (TABLE_METADATA, SCHEMA_VALIDATION_RESULTS,
      METRICS_VALIDATION_RESULTS, ROW_VALIDATION_SUMMARY) to surface per-workflow
      L1/L2/L3 progress rollups.  Both schemas live in the same database so the
      cross-schema join is deterministic inside a view definition.
    """

    @property
    def version(self) -> int:
        """Return version 22."""
        return 22

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return "Create DATA_MIGRATION_WORKFLOW and DATA_VALIDATION_WORKFLOW views"

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Create the two workflow-type views."""
        with connection.cursor() as cursor:
            self._execute_migration_sql_assets(
                cursor,
                [
                    "scripts/workflows/views/data_migration_workflow.sql.j2",
                    "scripts/workflows/views/data_validation_workflow.sql.j2",
                ],
            )
