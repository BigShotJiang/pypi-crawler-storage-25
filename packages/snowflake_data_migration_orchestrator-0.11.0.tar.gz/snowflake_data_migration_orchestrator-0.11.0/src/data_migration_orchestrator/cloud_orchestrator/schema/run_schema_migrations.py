from data_migration_orchestrator.cloud_core.connection_manager import (
    SnowflakeConnectionLike,
)
from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_orchestrator.schema.schema_manager import (
    SchemaManager,
)


def run_schema_migrations(conn: SnowflakeConnectionLike) -> None:
    """
    Run schema migrations to ensure database is up to date.

    Args:
        conn: Snowflake connection

    Raises:
        Exception: If migrations fail

    """
    logger = get_logger("schema_migrations")
    logger.info("Running schema migrations...")
    try:
        schema_manager = SchemaManager(conn)
        schema_manager.migrate()
        logger.info("Schema migrations completed successfully")
    except Exception as e:
        logger.error(f"Schema migration failed: {e}", exc_info=True)
        raise
