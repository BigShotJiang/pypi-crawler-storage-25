"""
Data validation workflow initializer.

Creates the initial set of tasks for validating tables between a source
database and Snowflake.
"""

import json

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task_builder import TaskBuilder
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.cloud_core.workflows.base_workflow_initializer import (
    BaseWorkflowInitializer,
)
from data_migration_orchestrator.cloud_core.workflows.workflow import Workflow
from data_migration_orchestrator.data_validation_cloud.config.validation_configuration_parser import (
    ValidationConfigurationParser,
)
from data_migration_orchestrator.data_validation_cloud.config.validation_table_configuration import (
    ValidationTableConfiguration,
)
from data_migration_orchestrator.data_validation_cloud.scope import (
    build_preprocessing_scope,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    GenerateValidationQueriesPayload,
)
from data_migration_orchestrator.data_validation_core.constants import (
    fq_table_metadata,
    table_metadata_id_seq,
)
from data_migration_orchestrator.utils.snowflake_sql_utils import escape_sql_string


logger = get_logger("data_validation_workflow_initializer")


class DataValidationWorkflowInitializer(BaseWorkflowInitializer):
    """
    Workflow initializer for data validation workflows.

    For each table in the workflow configuration, creates:
    1. TABLE_METADATA rows in DATA_VALIDATION (bulk MERGE)
    2. GENERATE_VALIDATION_QUERIES tasks (single ``push_tasks_batch``)
    """

    def __init__(
        self,
        task_queue: BaseTaskQueue,
        warehouse_proxy: Warehouse,
    ) -> None:
        """
        Initialize the data validation workflow initializer.

        Args:
            task_queue: Task queue for pushing tasks.
            warehouse_proxy: Warehouse proxy for Snowflake operations.

        """
        self.task_queue = task_queue
        self.warehouse_proxy = warehouse_proxy

    async def create_initial_tasks(self, workflow: Workflow) -> None:
        """
        Create initial tasks for a data validation workflow.

        For each table in the configuration:
        1. Bulk-upsert all TABLE_METADATA rows in a single MERGE statement
        2. Push all GENERATE_VALIDATION_QUERIES tasks in one ``push_tasks_batch``

        Args:
            workflow: The workflow containing configuration and metadata.

        """
        if workflow.configuration is None:
            raise ValueError(
                f"Workflow {workflow.id} has no configuration; cannot initialise"
            )
        config_parser = ValidationConfigurationParser(workflow.configuration)
        table_configs = config_parser.parse_tables()

        logger.info(
            "Initializing data validation workflow %d with %d table(s)",
            workflow.id,
            len(table_configs),
        )

        metadata_ids = await self._bulk_upsert_table_metadata(
            workflow_id=workflow.id,
            table_configs=table_configs,
        )

        gen_queries_tasks = []
        for table_config, table_metadata_id in zip(
            table_configs, metadata_ids, strict=False
        ):
            source_identifier = table_config.fully_qualified_name

            logger.info(
                "Created TABLE_METADATA %d for %s in workflow %d",
                table_metadata_id,
                source_identifier,
                workflow.id,
            )

            gen_queries_tasks.append(
                TaskBuilder(
                    workflow_id=workflow.id,
                    task_name=f"Generate validation queries for {source_identifier}",
                    executor_type=ExecutorType.ORCHESTRATOR,
                    payload=GenerateValidationQueriesPayload(
                        table_metadata_id=table_metadata_id,
                        source_identifier=source_identifier,
                        workflow_id=workflow.id,
                        source_platform=config_parser.source_platform,
                        use_snowpipe_for_results=config_parser.use_snowpipe_for_results,
                        custom_overrides=config_parser.custom_overrides,
                    ),
                    scope=build_preprocessing_scope(source_identifier),
                ).build()
            )

        await self.task_queue.push_tasks_batch(gen_queries_tasks)

        logger.info(
            "Created initial tasks for %d table(s) in workflow %d",
            len(table_configs),
            workflow.id,
        )

    async def _bulk_upsert_table_metadata(
        self,
        workflow_id: int,
        table_configs: list[ValidationTableConfiguration],
    ) -> list[int]:
        """
        Upsert all TABLE_METADATA rows in a single MERGE and return their IDs.

        Returns IDs in the same order as ``table_configs``.
        """
        if not table_configs:
            return []

        select_rows: list[str] = []
        source_identifiers: list[str] = []
        for tc in table_configs:
            src = tc.fully_qualified_name
            tgt = self._build_target_identifier(tc)
            cfg_json = json.dumps(tc.to_sdv_dict())
            source_identifiers.append(src)
            select_rows.append(
                f"SELECT {table_metadata_id_seq()}.NEXTVAL AS NEW_ID, "
                f"{workflow_id} AS WORKFLOW_ID, "
                f"'{escape_sql_string(src)}' AS SOURCE_IDENTIFIER, "
                f"'{escape_sql_string(tgt)}' AS TARGET_IDENTIFIER, "
                f"PARSE_JSON('{escape_sql_string(cfg_json)}') AS TABLE_CONFIGURATION, "
                f"FALSE AS HAS_BEEN_PREPROCESSED"
            )

        source_union = " UNION ALL ".join(select_rows)
        merge_sql = (
            f"MERGE INTO {fq_table_metadata()} AS tgt "
            f"USING ({source_union}) AS src "
            f"ON tgt.WORKFLOW_ID = src.WORKFLOW_ID "
            f"AND tgt.SOURCE_IDENTIFIER = src.SOURCE_IDENTIFIER "
            f"WHEN MATCHED THEN UPDATE SET "
            f"tgt.TARGET_IDENTIFIER = src.TARGET_IDENTIFIER, "
            f"tgt.TABLE_CONFIGURATION = src.TABLE_CONFIGURATION, "
            f"tgt.HAS_BEEN_PREPROCESSED = FALSE "
            f"WHEN NOT MATCHED THEN INSERT "
            f"(ID, WORKFLOW_ID, SOURCE_IDENTIFIER, TARGET_IDENTIFIER, "
            f"TABLE_CONFIGURATION, HAS_BEEN_PREPROCESSED) "
            f"VALUES (src.NEW_ID, src.WORKFLOW_ID, src.SOURCE_IDENTIFIER, "
            f"src.TARGET_IDENTIFIER, src.TABLE_CONFIGURATION, "
            f"src.HAS_BEEN_PREPROCESSED)"
        )
        await self.warehouse_proxy.execute_sync_query(merge_sql)

        # Fetch the IDs back keyed by SOURCE_IDENTIFIER (unique within workflow)
        escaped_identifiers = ", ".join(
            f"'{escape_sql_string(s)}'" for s in source_identifiers
        )
        select_sql = (
            f"SELECT ID, SOURCE_IDENTIFIER FROM {fq_table_metadata()} "
            f"WHERE WORKFLOW_ID = {workflow_id} "
            f"AND SOURCE_IDENTIFIER IN ({escaped_identifiers})"
        )
        rows = await self.warehouse_proxy.execute_sync_query(select_sql)

        id_by_source: dict[str, int] = {}
        for row in rows:
            id_by_source[row["SOURCE_IDENTIFIER"]] = int(row["ID"])

        result: list[int] = []
        for src in source_identifiers:
            if src not in id_by_source:
                raise RuntimeError(
                    f"TABLE_METADATA row not found after MERGE for {src}"
                )
            result.append(id_by_source[src])

        logger.info(
            "Bulk-upserted %d TABLE_METADATA rows for workflow %d",
            len(result),
            workflow_id,
        )
        return result

    @staticmethod
    def _build_target_identifier(table_config: ValidationTableConfiguration) -> str:
        """Build the target fully qualified name from table configuration."""
        target_db = table_config.target_database or ""
        target_schema = table_config.target_schema or ""
        target_name = (
            table_config.target_name or table_config.fully_qualified_name.split(".")[-1]
        )

        parts = [p for p in [target_db, target_schema, target_name] if p]
        return ".".join(parts)
