"""Custom template overrides for data validation workflows."""

from dataclasses import dataclass

from shared.models.custom_templates import (
    CustomTypesConfig,
    WorkflowCustomMetricsList,
    WorkflowCustomNormalizationsList,
)


@dataclass
class CustomTemplateOverrides:
    """
    Custom template overrides for source and target validation.

    Groups all custom template configurations that can be passed through
    the validation workflow to override default metrics and normalizations.
    """

    custom_types_source: CustomTypesConfig | None = None
    custom_metrics_source: WorkflowCustomMetricsList | None = None
    custom_metrics_target: WorkflowCustomMetricsList | None = None
    custom_normalizations_source: WorkflowCustomNormalizationsList | None = None
    custom_normalizations_target: WorkflowCustomNormalizationsList | None = None
