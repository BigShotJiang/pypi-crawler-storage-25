"""Task payload dataclasses for data validation workflows."""

from dataclasses import dataclass, field
from typing import Literal, TypedDict

from snowflake.snowflake_data_validation.public import MetricsResultShapeDict

from data_migration_orchestrator.cloud_core.tasks.snowflake_query_task import (
    SnowflakeQueryTaskPayload,
)
from data_migration_orchestrator.cloud_core.tasks.snowpipe_task import (
    SnowpipeTaskPayload,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.custom_template_overrides import (
    CustomTemplateOverrides,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload_kind import (
    DataValidationTaskPayloadKind,
)
from data_migration_orchestrator.data_validation_core.constants import (
    RowValidationMode,
)


# ==================== ORCHESTRATOR PAYLOADS ====================


@dataclass
class ExtractSourceMetadataPayload:
    """Payload for the metadata extraction task (reuses DEA data_movement)."""

    table_metadata_id: int
    source_identifier: str
    workflow_id: int
    source_platform: str
    kind: Literal[DataValidationTaskPayloadKind.EXTRACT_SOURCE_METADATA] = (
        DataValidationTaskPayloadKind.EXTRACT_SOURCE_METADATA
    )


@dataclass
class GenerateValidationQueriesPayload:
    """Payload for the query generation + partitioning orchestrator task."""

    table_metadata_id: int
    source_identifier: str
    workflow_id: int
    source_platform: str
    use_snowpipe_for_results: bool = True
    custom_overrides: CustomTemplateOverrides | None = None
    kind: Literal[DataValidationTaskPayloadKind.GENERATE_VALIDATION_QUERIES] = (
        DataValidationTaskPayloadKind.GENERATE_VALIDATION_QUERIES
    )


@dataclass
class EvaluateLevelResultPayload:
    """Payload for the level-gating orchestrator task."""

    table_metadata_id: int
    completed_level: str
    next_level: str | None
    continue_on_failure: bool
    next_level_enabled: bool
    workflow_id: int
    source_platform: str
    source_identifier: str
    row_validation_mode: RowValidationMode | None = None
    l3_drill_down_phase: bool = False
    use_snowpipe_for_results: bool = True
    custom_overrides: CustomTemplateOverrides | None = None
    kind: Literal[DataValidationTaskPayloadKind.EVALUATE_LEVEL_RESULT] = (
        DataValidationTaskPayloadKind.EVALUATE_LEVEL_RESULT
    )


@dataclass
class TeardownDvSnowpipePayload:
    """
    Payload for dropping a per-workflow DV result Snowpipe.

    This is always scheduled as a cleanup task (``.blocked().cleanup()``)
    so it runs after every non-cleanup task terminates, even when the
    workflow failed. The handler runs ``DROP PIPE IF EXISTS``.
    """

    workflow_id: int
    pipe_name: str

    kind: Literal[DataValidationTaskPayloadKind.TEARDOWN_DV_SNOWPIPE] = (
        DataValidationTaskPayloadKind.TEARDOWN_DV_SNOWPIPE
    )


@dataclass
class PrepareDvDrainPayload:
    """
    Payload for the orchestrator task that fans out DV Snowpipe drains.

    When a level has multiple result pipes (currently only L3 row mode,
    with diffs/summary/chunk-hashes), the planning step pushes a single
    ``PrepareDvDrain`` task instead of wiring drains into a linear chain.
    Once all upstream DEA validate partitions have completed, this task
    unblocks and its handler pushes one :class:`SnowpipeTaskPayload` per
    pipe, each with ``SUCCESSOR_TASK_ID = evaluate_task_id``. The drains
    then run in parallel and Evaluate unblocks when all have completed.
    """

    workflow_id: int
    level: str
    pipe_names: list[str]
    """Fully qualified pipe names, aligned positionally with ``pipe_keys``."""

    pipe_keys: list[str]
    """``DvResultsPipeKey`` values, used to build drain task names/scopes."""

    evaluate_task_id: int | None
    """Successor task id for each pushed drain, or ``None`` for drill-down."""

    table_metadata_id: int | None = None
    """Owning table; used for drain task scopes/names. Omitted on legacy payloads."""

    kind: Literal[DataValidationTaskPayloadKind.PREPARE_DV_DRAIN] = (
        DataValidationTaskPayloadKind.PREPARE_DV_DRAIN
    )


@dataclass
class FinalizeHybridL3Payload:
    """
    Payload for the orchestrator task that closes out hybrid L3 validation.

    Pushed by the per-table hybrid Evaluate L3 task as the successor of the
    cell drill-down chain (or run inline when there are zero mismatched
    partitions). The handler reads ``CELL_VALIDATION_RESULTS`` for the
    table, sets ``L3_STATUS`` for every partition via
    ``bulk_set_partition_level_status``, and calls
    ``UPDATE_TABLE_VALIDATION_STATUS`` based on whether any cell diffs were
    recorded.
    """

    workflow_id: int
    table_metadata_id: int
    source_identifier: str

    kind: Literal[DataValidationTaskPayloadKind.FINALIZE_HYBRID_L3] = (
        DataValidationTaskPayloadKind.FINALIZE_HYBRID_L3
    )


@dataclass
class L3EarlyStopPollPayload:
    """
    Orchestrator payload for periodic L3 mismatch checks (early stopping).

    ``anchor_task_id``: the per-table sync task whose terminal status ends polling
    and that is also the ``TRY_UNBLOCK_TASK`` target after a bulk skip. For
    Snowpipe L3 it is the DEA fan-in entry id (``PrepareDvDrain`` or single
    ``SnowpipeDrain`` from ``snowpipe_chain.entry_task_id``); for non-Snowpipe L3
    it is the ``Evaluate`` task id.
    """

    workflow_id: int
    table_metadata_id: int
    source_identifier: str
    row_validation_mode: RowValidationMode
    early_stop_check_interval_minutes: int
    early_stop_mismatch_row_threshold: int
    anchor_task_id: int | None = None
    use_snowpipe_for_results: bool = False
    kind: Literal[DataValidationTaskPayloadKind.DV_L3_EARLY_STOP_POLL] = (
        DataValidationTaskPayloadKind.DV_L3_EARLY_STOP_POLL
    )


# ==================== DEA PAYLOADS ====================


class ColumnMetadataDict(TypedDict):
    """Shape of each entry in the ``columns_metadata`` payload list."""

    name: str
    data_type: str


@dataclass
class ResultPipeInfo:
    """Metadata describing a Snowpipe the DEA must refresh after uploads."""

    pipe_name: str
    """Fully qualified Snowpipe name (e.g. ``DB.TEMP.DVO_PIPE_42_5001_METRICS``)."""

    stage_prefix: str
    """Stage path prefix (no leading ``@``) to pass to ``ALTER PIPE ... REFRESH PREFIX='...'``."""


@dataclass
class MetricsQueryBatch:
    """
    A single metrics query batch plus the shape of its wide result row.

    Both the orchestrator and the DEA need to know how to reshape the
    single-row wide metrics query result back into the long-form DataFrame
    expected by ``MetricsDataValidator``.  The ``result_shape`` field holds
    the JSON-serialized form of
    :class:`snowflake.snowflake_data_validation.public.MetricsResultShape`
    (see its ``to_dict()`` / ``from_dict()`` helpers) so the whole payload
    can be round-tripped via ``dataclasses.asdict`` + JSON.
    """

    query: str
    result_shape: MetricsResultShapeDict = field(
        default_factory=lambda: MetricsResultShapeDict(cells=[], all_metrics=[])
    )


@dataclass
class DataValidationTaskPayload:
    """Payload sent from orchestrator to DEA for validation execution."""

    source_query: str
    target_query: str
    validation_type: str
    source_platform: str
    target_type: str
    target_id: str
    table_name: str
    table_metadata_id: int
    workflow_id: int
    partition_number: int | None
    database: str
    schema: str
    column_mappings: dict[str, str] | None = None
    datatypes_mappings: dict[str, str] | None = None
    tolerance: float | None = None
    use_database_command: str | None = None
    row_validation_mode: RowValidationMode | None = None
    index_column_list: list[str] | None = None
    target_index_column_list: list[str] | None = None
    source_table_fqn: str | None = None
    target_table_fqn: str | None = None
    max_failed_rows_number: int | None = None
    columns_metadata: list[ColumnMetadataDict] | None = None
    source_where_clause: str | None = None
    target_where_clause: str | None = None
    source_query_batches: list[MetricsQueryBatch] | None = None
    target_query_batches: list[MetricsQueryBatch] | None = None
    max_columns_per_cell_batch: int | None = None
    result_pipes: list[ResultPipeInfo] | None = None
    object_type: str = "TABLE"
    custom_overrides: CustomTemplateOverrides | None = None
    kind: Literal[DataValidationTaskPayloadKind.DATA_VALIDATION] = (
        DataValidationTaskPayloadKind.DATA_VALIDATION
    )


# ==================== WAREHOUSE PAYLOADS ====================


@dataclass
class WriteValidationResultsPayload:
    """Payload for the warehouse COPY INTO task (wraps SnowflakeQueryTaskPayload)."""

    query: str
    table_metadata_id: int
    workflow_id: int
    validation_level: str
    partition_number: int | None = None
    query_id: str | None = None
    kind: Literal[DataValidationTaskPayloadKind.WRITE_VALIDATION_RESULTS] = (
        DataValidationTaskPayloadKind.WRITE_VALIDATION_RESULTS
    )


# ==================== UNION TYPE ====================

DataValidationTaskPayloadUnion = (
    ExtractSourceMetadataPayload
    | GenerateValidationQueriesPayload
    | EvaluateLevelResultPayload
    | TeardownDvSnowpipePayload
    | PrepareDvDrainPayload
    | FinalizeHybridL3Payload
    | L3EarlyStopPollPayload
    | DataValidationTaskPayload
    | WriteValidationResultsPayload
    | SnowflakeQueryTaskPayload
    | SnowpipeTaskPayload
)
