"""Map raw task payload dictionaries to typed data validation payload dataclasses."""

from data_migration_orchestrator.cloud_core.tasks.snowpipe_task import (
    SnowpipeTaskPayload,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    DataValidationTaskPayload,
    DataValidationTaskPayloadUnion,
    EvaluateLevelResultPayload,
    ExtractSourceMetadataPayload,
    FinalizeHybridL3Payload,
    GenerateValidationQueriesPayload,
    L3EarlyStopPollPayload,
    PrepareDvDrainPayload,
    ResultPipeInfo,
    SnowflakeQueryTaskPayload,
    TeardownDvSnowpipePayload,
    WriteValidationResultsPayload,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload_kind import (
    DataValidationTaskPayloadKind,
)


def _build_data_validation_payload(payload_dict: dict) -> DataValidationTaskPayload:
    """Coerce ``result_pipes`` entries to :class:`ResultPipeInfo` before constructing."""
    pipes_raw = payload_dict.get("result_pipes")
    if pipes_raw:
        payload_dict = {
            **payload_dict,
            "result_pipes": [
                ResultPipeInfo(**p) if isinstance(p, dict) else p for p in pipes_raw
            ],
        }
    return DataValidationTaskPayload(**payload_dict)


def map_data_validation_task_payload(
    kind: str, payload_dict: dict
) -> DataValidationTaskPayloadUnion:
    """Map a task payload dictionary to the appropriate dataclass based on kind."""
    match kind:
        case DataValidationTaskPayloadKind.EXTRACT_SOURCE_METADATA.value:
            return ExtractSourceMetadataPayload(**payload_dict)
        case DataValidationTaskPayloadKind.GENERATE_VALIDATION_QUERIES.value:
            return GenerateValidationQueriesPayload(**payload_dict)
        case DataValidationTaskPayloadKind.EVALUATE_LEVEL_RESULT.value:
            return EvaluateLevelResultPayload(**payload_dict)
        case DataValidationTaskPayloadKind.TEARDOWN_DV_SNOWPIPE.value:
            return TeardownDvSnowpipePayload(**payload_dict)
        case DataValidationTaskPayloadKind.PREPARE_DV_DRAIN.value:
            return PrepareDvDrainPayload(**payload_dict)
        case DataValidationTaskPayloadKind.FINALIZE_HYBRID_L3.value:
            return FinalizeHybridL3Payload(**payload_dict)
        case DataValidationTaskPayloadKind.DV_L3_EARLY_STOP_POLL.value:
            return L3EarlyStopPollPayload(**payload_dict)
        case DataValidationTaskPayloadKind.DATA_VALIDATION.value:
            return _build_data_validation_payload(payload_dict)
        case DataValidationTaskPayloadKind.WRITE_VALIDATION_RESULTS.value:
            return WriteValidationResultsPayload(**payload_dict)
        case DataValidationTaskPayloadKind.SNOWFLAKE_QUERY.value:
            return SnowflakeQueryTaskPayload(**payload_dict)
        case DataValidationTaskPayloadKind.SNOWPIPE_INGESTION.value:
            return SnowpipeTaskPayload(**payload_dict)
        case _:
            raise ValueError(f"Unknown data validation task payload kind: {kind}")
