"""L3 early-stop periodical poll (orchestrator) and enqueue helper."""

from __future__ import annotations

from typing import Any, cast

from data_migration_orchestrator.cloud_core.constants.priorities import DEFAULT_PRIORITY
from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.queues.table_task_queue import (
    TableTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.tasks.task_builder import TaskBuilder
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_validation_cloud.config import (
    configuration_properties_keys as keys,
)
from data_migration_orchestrator.data_validation_cloud.scope import (
    build_l3_early_stop_monitor_scope,
    build_l3_early_stop_skip_scope_like_pattern,
    build_l3_early_stop_skip_write_results_row_pattern,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    L3EarlyStopPollPayload,
)
from data_migration_orchestrator.data_validation_core.constants import (
    RowValidationMode,
    fq_cell_validation_results,
    fq_row_validation_results,
)
from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_migration_schema,
)


logger = get_logger("dv.l3_early_stop_poll")

_TERMINAL = frozenset({"completed", "failed", "abandoned"})


def _mismatch_results_fqn(mode: RowValidationMode) -> str:
    """
    Return the result table the early-stop poll counts against for this mode.

    Hybrid counts row-hash mismatches (``ROW_VALIDATION_RESULTS``); the cell
    drill-down phase that follows hybrid is not factored into the early-stop
    threshold. Pure cell L3 still counts cell mismatches.
    """
    if mode is RowValidationMode.CELL:
        return fq_cell_validation_results()
    return fq_row_validation_results()


async def maybe_push_l3_early_stop_poll(
    task_queue: BaseTaskQueue,
    *,
    workflow_id: int,
    table_metadata_id: int,
    source_identifier: str,
    row_validation_mode: RowValidationMode,
    table_config: dict,
    anchor_task_id: int,
    use_snowpipe_for_results: bool = False,
) -> None:
    """Push the periodical poll task when ``early_stopping`` is enabled in table config."""
    if not table_config.get(keys.EARLY_STOPPING):
        return
    if not hasattr(task_queue, "skip_all_dv_l3_candidate_tasks"):
        raise TypeError(
            "L3 early stop requires a task queue implementation that supports "
            "skip_all_dv_l3_candidate_tasks (Snowflake TableTaskQueue)."
        )
    thr = table_config.get(keys.EARLY_STOP_MISMATCH_ROW_THRESHOLD)
    inv = table_config.get(keys.EARLY_STOP_CHECK_INTERVAL_MINUTES)
    if thr is None or inv is None:
        logger.warning(
            "L3 early stopping enabled but missing threshold or interval for %s",
            source_identifier,
        )
        return
    poll_task = (
        TaskBuilder(
            workflow_id=workflow_id,
            task_name=f"L3 early-stop poll for {source_identifier}",
            executor_type=ExecutorType.ORCHESTRATOR,
            payload=L3EarlyStopPollPayload(
                workflow_id=workflow_id,
                table_metadata_id=table_metadata_id,
                source_identifier=source_identifier,
                row_validation_mode=row_validation_mode,
                early_stop_check_interval_minutes=int(inv),
                early_stop_mismatch_row_threshold=int(thr),
                anchor_task_id=anchor_task_id,
                use_snowpipe_for_results=use_snowpipe_for_results,
            ),
            scope=build_l3_early_stop_monitor_scope(source_identifier),
        )
        .with_priority(DEFAULT_PRIORITY)
        .build()
    )
    await task_queue.push_task(poll_task)


class L3EarlyStopPollHandler:
    """Poll ingested L3 mismatch counts and optionally skip pending L3 tasks."""

    def __init__(self, task_queue: BaseTaskQueue, warehouse_proxy: Warehouse) -> None:
        """Store the shared task queue and warehouse proxy."""
        self.task_queue = task_queue
        self.warehouse_proxy = warehouse_proxy

    async def handle(self, task: Task) -> None:
        """Run one poll tick: stop, bulk-skip over threshold, or reschedule."""
        payload: L3EarlyStopPollPayload = task.payload
        assert task.id is not None
        tq = self.task_queue
        if not hasattr(tq, "skip_all_dv_l3_candidate_tasks") or not hasattr(
            tq, "reschedule_periodical_task"
        ):
            raise TypeError(
                "L3 early stop requires skip_all_dv_l3_candidate_tasks and "
                "reschedule_periodical_task on the task queue."
            )
        if payload.anchor_task_id is None:
            raise ValueError(
                "L3 early-stop poll requires anchor_task_id on the payload "
                f"(workflow_id={payload.workflow_id}, "
                f"table_metadata_id={payload.table_metadata_id})"
            )

        tq_snowflake = cast(TableTaskQueue[Any], tq)

        logger.info(
            "L3 early-stop poll BEGIN task_id=%s workflow_id=%s table_metadata_id=%s "
            "source_identifier=%s row_validation_mode=%s anchor_task_id=%s "
            "use_snowpipe_for_results=%s "
            "mismatch_threshold=%s check_interval_minutes=%s",
            task.id,
            payload.workflow_id,
            payload.table_metadata_id,
            payload.source_identifier,
            payload.row_validation_mode,
            payload.anchor_task_id,
            payload.use_snowpipe_for_results,
            payload.early_stop_mismatch_row_threshold,
            payload.early_stop_check_interval_minutes,
        )

        if await self._anchor_terminal(payload):
            logger.info(
                "L3 early-stop poll DECIDE STOP (anchor terminal): no more polling "
                "needed task_id=%s workflow_id=%s table_metadata_id=%s",
                task.id,
                payload.workflow_id,
                payload.table_metadata_id,
            )
            await tq.complete_task(ExecutorType.ORCHESTRATOR, task.id)
            logger.info(
                "L3 early-stop poll STOPPED (complete_task done) task_id=%s",
                task.id,
            )
            return

        mode = (
            RowValidationMode(payload.row_validation_mode)
            if isinstance(payload.row_validation_mode, str)
            else payload.row_validation_mode
        )
        mismatch_fq = _mismatch_results_fqn(mode)
        logger.info(
            "L3 early-stop poll mismatch CHECK table=%s workflow_id=%s "
            "table_metadata_id=%s threshold=%s",
            mismatch_fq,
            payload.workflow_id,
            payload.table_metadata_id,
            payload.early_stop_mismatch_row_threshold,
        )
        cnt = await self._mismatch_row_count(
            mode, payload.workflow_id, payload.table_metadata_id
        )
        logger.info(
            "L3 early-stop poll mismatch RESULT count=%s threshold=%s (below_threshold=%s)",
            cnt,
            payload.early_stop_mismatch_row_threshold,
            cnt < payload.early_stop_mismatch_row_threshold,
        )
        if cnt >= payload.early_stop_mismatch_row_threshold:
            logger.info(
                "L3 early-stop poll DECIDE EARLY_STOP: count >= threshold, "
                "calling skip_all_dv_l3_candidate_tasks task_id=%s",
                task.id,
            )
            scope_like = build_l3_early_stop_skip_scope_like_pattern(
                payload.source_identifier
            )
            scope_like_write: str | None = None
            if not payload.use_snowpipe_for_results:
                scope_like_write = build_l3_early_stop_skip_write_results_row_pattern(
                    payload.source_identifier
                )
            logger.info(
                "L3 early-stop poll skip INPUT scope_like_pattern=%r "
                "scope_like_pattern_2=%r unblock_if_ready_task_id=%s (poll_task_id=%s)",
                scope_like,
                scope_like_write,
                payload.anchor_task_id,
                task.id,
            )
            skipped = await tq_snowflake.skip_all_dv_l3_candidate_tasks(
                payload.workflow_id,
                scope_like,
                payload.anchor_task_id,
                scope_like_write,
            )
            logger.info(
                "L3 early-stop poll skip_all_dv_l3_candidate_tasks DONE skipped=%s "
                "workflow_id=%s table_metadata_id=%s mismatches=%s (>=%s)",
                skipped,
                payload.workflow_id,
                payload.table_metadata_id,
                cnt,
                payload.early_stop_mismatch_row_threshold,
            )
            if skipped > 0:
                if not hasattr(tq, "unblock_tasks"):
                    raise TypeError(
                        "L3 early stop requires unblock_tasks on the task queue after a bulk skip."
                    )
                await tq.unblock_tasks()
            await tq.complete_task(ExecutorType.ORCHESTRATOR, task.id)
            logger.info(
                "L3 early-stop poll END after early-stop (complete_task done) task_id=%s",
                task.id,
            )
            return

        logger.info(
            "L3 early-stop poll DECIDE RESCHEDULE: count below threshold, "
            "interval_minutes=%s task_id=%s",
            payload.early_stop_check_interval_minutes,
            task.id,
        )
        ok = await tq_snowflake.reschedule_periodical_task(
            ExecutorType.ORCHESTRATOR,
            task.id,
            payload.early_stop_check_interval_minutes,
        )
        logger.info(
            "L3 early-stop poll reschedule_periodical_task RESULT ok=%s task_id=%s",
            ok,
            task.id,
        )
        if not ok:
            logger.error(
                "RESCHEDULE_PERIODICAL_TASK failed for task_id=%s; completing task",
                task.id,
            )
            await tq.complete_task(ExecutorType.ORCHESTRATOR, task.id)
            logger.info(
                "L3 early-stop poll END after reschedule failure (complete_task done) "
                "task_id=%s",
                task.id,
            )
        else:
            logger.info(
                "L3 early-stop poll END tick (rescheduled; poll task pending with "
                "NEXT_ELIGIBLE_AT) task_id=%s",
                task.id,
            )

    async def _anchor_terminal(self, payload: L3EarlyStopPollPayload) -> bool:
        """Return True when the anchor task row is terminal (or missing)."""
        anchor_id = payload.anchor_task_id
        assert anchor_id is not None
        logger.info(
            "L3 early-stop poll stop-check BRANCH=anchor_task "
            "anchor_task_id=%s workflow_id=%s",
            anchor_id,
            payload.workflow_id,
        )
        rows = await self.warehouse_proxy.execute_sync_query(
            f"SELECT STATUS FROM {qualified_migration_schema()}.TASK_QUEUE "
            f"WHERE ID = {int(anchor_id)}"
        )
        if not rows:
            logger.info(
                "L3 early-stop poll stop-check RESULT branch=anchor "
                "anchor_row_missing=True stop=True",
            )
            return True
        st = str(next(iter(rows[0].values()))).lower()
        stop = st in _TERMINAL
        logger.info(
            "L3 early-stop poll stop-check RESULT branch=anchor "
            "anchor_status=%s terminal=%s stop=%s",
            st,
            st in _TERMINAL,
            stop,
        )
        return stop

    async def _mismatch_row_count(
        self, mode: RowValidationMode, workflow_id: int, table_metadata_id: int
    ) -> int:
        fq = _mismatch_results_fqn(mode)
        q = (
            f"SELECT COUNT(*) AS c FROM {fq} "
            f"WHERE WORKFLOW_ID = {workflow_id} "
            f"AND TABLE_METADATA_ID = {table_metadata_id}"
        )
        logger.debug(
            "L3 early-stop poll mismatch_count SQL workflow_id=%s table_metadata_id=%s "
            "sql=%s",
            workflow_id,
            table_metadata_id,
            q,
        )
        rows = await self.warehouse_proxy.execute_sync_query(q)
        if not rows:
            return 0
        return int(rows[0].get("c") or rows[0].get("C") or 0)
