"""
Handler for WRITE_VALIDATION_RESULTS tasks.

Executes COPY INTO SQL to load staged CSV validation results into the
appropriate per-level results table in Snowflake.
"""

from __future__ import annotations

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_validation_cloud.partition_progress import (
    partition_number_from_dv_task_scope,
    record_partition_write_milestone,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    WriteValidationResultsPayload,
)
from shared.telemetry import WorkflowStep, set_current_step


logger = get_logger("dv.write_results_handler")


class WriteResultsHandler:
    """
    Handle WRITE_VALIDATION_RESULTS tasks.

    Executes the COPY INTO SQL query that was pre-built by the query
    generation or level evaluation handler. The query loads staged CSV
    files into the appropriate per-level results table.
    """

    def __init__(
        self,
        task_queue: BaseTaskQueue,
        warehouse_proxy: Warehouse,
    ) -> None:
        """
        Initialize the handler.

        Args:
            task_queue: Task queue for task lifecycle operations.
            warehouse_proxy: Warehouse proxy for executing Snowflake queries.

        """
        self.task_queue = task_queue
        self.warehouse_proxy = warehouse_proxy

    async def handle(self, task: Task) -> None:
        """
        Handle the write validation results task.

        Executes the pre-built COPY INTO query. If the query contains
        multiple statements (for L3 row validation), they are executed
        sequentially.

        Args:
            task: The task containing WriteValidationResultsPayload.

        """
        payload: WriteValidationResultsPayload = task.payload
        assert task.id is not None, "Task must have an ID when being handled"

        set_current_step(WorkflowStep.LOAD, "dv-write-validation-results")

        logger.info(
            "Writing %s validation results for table_metadata_id=%d, workflow=%d",
            payload.validation_level,
            payload.table_metadata_id,
            payload.workflow_id,
        )

        queries = payload.query.split("; ")

        partition_number = payload.partition_number
        if partition_number is None:
            partition_number = partition_number_from_dv_task_scope(task.scope)

        try:
            for query in queries:
                query = query.strip()
                if not query:
                    continue

                try:
                    await self.warehouse_proxy.execute_sync_query(query)
                    logger.info(
                        "COPY INTO completed for table_metadata_id=%d, level=%s",
                        payload.table_metadata_id,
                        payload.validation_level,
                    )
                except Exception as e:
                    logger.error(
                        "COPY INTO failed for table_metadata_id=%d: %s",
                        payload.table_metadata_id,
                        str(e),
                    )
                    raise
        except Exception:
            await record_partition_write_milestone(
                self.warehouse_proxy,
                table_metadata_id=payload.table_metadata_id,
                validation_level=payload.validation_level,
                partition_number=partition_number,
                failed=True,
            )
            raise

        await record_partition_write_milestone(
            self.warehouse_proxy,
            table_metadata_id=payload.table_metadata_id,
            validation_level=payload.validation_level,
            partition_number=partition_number,
            failed=False,
        )

        logger.info(
            "All write operations complete for table_metadata_id=%d, level=%s",
            payload.table_metadata_id,
            payload.validation_level,
        )

        await self.task_queue.complete_task(ExecutorType.ORCHESTRATOR, task.id)
