"""
Hybrid row validation handler.

Hybrid L3 runs in two phases per table, both anchored on the per-table
``Evaluate L3`` orchestrator task:

1. Row-hashing phase. One MD5 row-hash DEA task per partition writes its
   results to the per-table row-result Snowpipes (``ROW_DIFFS``,
   ``ROW_SUMMARY``, ``CHUNK_HASHES`` for the Snowpipe path; per-partition
   ``WriteResults[row]`` COPY INTO for the non-Snowpipe path). All DEA /
   write tasks set the per-table ``Evaluate L3`` task as their successor
   (directly for the non-Snowpipe path, indirectly via the per-table
   ``PrepareDvDrain`` ⇒ row drains for the Snowpipe path). The early-stop
   poll watches that anchor and may bulk-skip remaining row tasks for the
   table once the configured row-mismatch threshold is met.

2. Cell drill-down phase. When the per-table ``Evaluate L3`` task runs,
   :meth:`HybridValidationHandler.push_cell_drilldown_for_partitions`
   inspects ``ROW_VALIDATION_RESULTS`` for the table, picks the partitions
   with mismatches, and pushes one cell DEA task per such partition
   (narrowed to the failed row keys). The cell DEAs fan in to a per-table
   cell ``CELL_DIFFS`` Snowpipe drain whose successor is a single
   ``FinalizeHybridL3`` orchestrator task that sets ``L3_STATUS`` and the
   table validation status from the cell-diff count. When there are no
   mismatched partitions, the Evaluate handler runs the finalize logic
   inline.

``max_failed_rows_number`` caps how many cell-level diff rows are produced
in phase 2 (drill-down detail), not whether drill-down runs.

Hybrid mode is only valid in combination with early stopping; the
configuration parser rejects ``row_validation_mode=hybrid`` when
``early_stopping`` is not enabled.
"""

from __future__ import annotations

import json

from typing import Any

from data_migration_orchestrator.cloud_core.constants.priorities import DEFAULT_PRIORITY
from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.tasks.task_builder import TaskBuilder
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_migration_cloud.partition.partition_range import (
    infer_boundary_flags,
)
from data_migration_orchestrator.data_migration_cloud.platforms.platform_registry import (
    PlatformRegistry,
)
from data_migration_orchestrator.data_migration_cloud.platforms.snowflake.query_builder import (
    build_snowflake_partition_condition,
)
from data_migration_orchestrator.data_validation_cloud.config import (
    configuration_properties_keys as keys,
)
from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
    build_cell_validation_queries,
    build_normalized_cell_validation_queries_for_partitions,
    build_or_predicate_for_index_value_strings,
    merge_sql_where_clauses,
    parse_source_fqn_parts,
    resolve_object_type,
)
from data_migration_orchestrator.data_validation_cloud.scope import (
    build_evaluate_scope,
    build_validation_scope,
    build_write_results_scope,
)
from data_migration_orchestrator.data_validation_cloud.tasks.handlers.l3_early_stop_poll_handler import (
    maybe_push_l3_early_stop_poll,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.dea_payload_factory import (
    DEAPayloadFactory,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    ColumnMetadataDict,
    EvaluateLevelResultPayload,
    FinalizeHybridL3Payload,
    WriteValidationResultsPayload,
)
from data_migration_orchestrator.data_validation_cloud.tasks.snowpipe_flow import (
    build_result_pipes_for_partition,
    build_snowpipe_level_chain,
)
from data_migration_orchestrator.data_validation_cloud.utils.identifier_folding import (
    apply_identifier_folding,
    folding_strategy_for_source_platform,
)
from data_migration_orchestrator.data_validation_cloud.utils.partition_where import (
    build_scoped_partition_where,
    max_interior_partition_number,
)
from data_migration_orchestrator.data_validation_cloud.utils.pipe_utils import (
    DvResultsPipeKey,
)
from data_migration_orchestrator.data_validation_core.constants import (
    COL_COLUMN_VALIDATED,
    COL_MAX_VALUE,
    COL_MIN_VALUE,
    COL_PARTITION_NUMBER,
    COL_SOURCE_VALUE,
    ROW_VALIDATION,
    ROW_VALIDATION_MODE_HYBRID,
    data_validation_full_schema,
    fq_cell_validation_results,
    fq_chunk_hashes,
    fq_row_validation_results,
    fq_row_validation_summary,
    fq_schema_validation_results,
    task_results_stage,
    validation_csv_file_format_fqn,
)
from data_migration_orchestrator.utils.snowflake_sql_utils import (
    quote_string_literal,
)


logger = get_logger("dv.hybrid_validation_handler")

_CTX_SOURCE_COLUMNS = "source_columns"
_CTX_TARGET_COLUMNS = "target_columns"
_CTX_SRC_DB = "src_db"
_CTX_SRC_SCHEMA = "src_schema"
_CTX_SRC_TABLE = "src_table"
_CTX_TGT_DB = "tgt_db"
_CTX_TGT_SCHEMA = "tgt_schema"
_CTX_TGT_TABLE = "tgt_table"
_CTX_SRC_FQ = "src_fq"
_CTX_TGT_FQ = "tgt_fq"


class HybridValidationHandler:
    """Plan hybrid (row-hash + cell drilldown) L3 validation tasks."""

    def __init__(
        self,
        task_queue: BaseTaskQueue,
        warehouse_proxy: Warehouse,
    ) -> None:
        """Initialize with shared task queue and warehouse proxy."""
        self.task_queue = task_queue
        self.warehouse_proxy = warehouse_proxy

    # ------------------------------------------------------------------
    # Public API — called by EvaluateLevelResultHandler
    # ------------------------------------------------------------------

    async def push_hybrid_row_chain(
        self,
        payload: EvaluateLevelResultPayload,
        table_config: dict,
        partitions: list[dict],
    ) -> None:
        """
        Push hybrid L3 row-hashing phase: one anchor Evaluate + one Snowpipe chain per table.

        For both Snowpipe and non-Snowpipe paths, a single per-table
        ``Evaluate L3`` orchestrator task acts as the fan-in anchor (and as
        the early-stop poll's anchor task). All row-hash DEAs (and, in the
        non-Snowpipe path, their per-partition ``WriteResults[row]``
        successors) ultimately point at this Evaluate task either directly
        (non-Snowpipe) or through the per-table row Snowpipe drain chain
        (Snowpipe path).
        """
        src_db, src_schema, src_table = parse_source_fqn_parts(
            payload.source_identifier, payload.source_platform
        )
        tgt_db = table_config.get(keys.TARGET_DATABASE, "")
        tgt_schema = table_config.get(keys.TARGET_SCHEMA, src_schema)
        tgt_table = table_config.get(keys.TARGET_NAME, src_table)

        src_fq = (
            f"{src_db}.{src_schema}.{src_table}"
            if src_db
            else f"{src_schema}.{src_table}"
        )
        tgt_fq = (
            f"{tgt_db}.{tgt_schema}.{tgt_table}"
            if tgt_db
            else f"{tgt_schema}.{tgt_table}"
        )

        index_column_list = table_config.get(keys.INDEX_COLUMN_LIST) or []
        target_index_column_list = (
            table_config.get(keys.TARGET_INDEX_COLUMN_LIST) or index_column_list
        )
        max_failed_rows_number = table_config.get(keys.MAX_FAILED_ROWS_NUMBER)

        columns_metadata = await self._get_columns_metadata(
            payload.workflow_id,
            payload.table_metadata_id,
            payload.source_platform,
        )

        object_type_str = table_config.get("object_type", "TABLE")

        dea_factory = DEAPayloadFactory(
            workflow_id=payload.workflow_id,
            table_metadata_id=payload.table_metadata_id,
            source_identifier=payload.source_identifier,
            source_platform=payload.source_platform,
            object_type=object_type_str,
            custom_overrides=payload.custom_overrides,
        )

        use_snowpipe = payload.use_snowpipe_for_results

        evaluate_payload = EvaluateLevelResultPayload(
            table_metadata_id=payload.table_metadata_id,
            completed_level=ROW_VALIDATION,
            next_level=None,
            continue_on_failure=payload.continue_on_failure,
            next_level_enabled=False,
            workflow_id=payload.workflow_id,
            source_platform=payload.source_platform,
            source_identifier=payload.source_identifier,
            row_validation_mode=ROW_VALIDATION_MODE_HYBRID,
            l3_drill_down_phase=False,
            use_snowpipe_for_results=use_snowpipe,
        )
        evaluate_task = (
            TaskBuilder(
                workflow_id=payload.workflow_id,
                task_name=f"Evaluate hybrid L3 for {payload.source_identifier}",
                executor_type=ExecutorType.ORCHESTRATOR,
                payload=evaluate_payload,
                scope=build_evaluate_scope(payload.source_identifier, ROW_VALIDATION),
            )
            .blocked()
            .build()
        )
        evaluate_task_id = await self.task_queue.push_task(evaluate_task)
        if evaluate_task_id is None:
            raise RuntimeError(
                f"Failed to push hybrid Evaluate L3 task for "
                f"{payload.source_identifier}"
            )

        snowpipe_chain = None
        if use_snowpipe:
            snowpipe_chain = await build_snowpipe_level_chain(
                task_queue=self.task_queue,
                warehouse=self.warehouse_proxy,
                workflow_id=payload.workflow_id,
                table_metadata_id=payload.table_metadata_id,
                level="row",
                pipe_keys=[
                    DvResultsPipeKey.ROW_DIFFS,
                    DvResultsPipeKey.ROW_SUMMARY,
                    DvResultsPipeKey.CHUNK_HASHES,
                ],
                evaluate_task_id=evaluate_task_id,
            )

        max_interior = max_interior_partition_number(partitions)
        snowpipe_dea_tasks: list[Task] = []
        chains: list[tuple[Task, Task]] = []
        for partition in partitions:
            partition_num = partition.get(COL_PARTITION_NUMBER)
            min_val = partition.get(COL_MIN_VALUE)
            max_val = partition.get(COL_MAX_VALUE)

            user_source_where = table_config.get(keys.WHERE_CLAUSE) or ""
            user_target_where = table_config.get(keys.TARGET_WHERE_CLAUSE) or ""
            _pcols = table_config.get(keys.COLUMN_NAMES_TO_PARTITION_BY, [])
            _, _, is_last = infer_boundary_flags(
                int(partition_num) if partition_num is not None else 0,
                min_val,
                max_val,
                num_partitions=max_interior,
            )
            source_where = build_scoped_partition_where(
                user_source_where,
                _pcols,
                min_val,
                max_val,
                payload.source_platform,
                target_side=False,
                upper_inclusive=is_last,
            )
            target_where = build_scoped_partition_where(
                user_target_where,
                _pcols,
                min_val,
                max_val,
                payload.source_platform,
                target_side=True,
                upper_inclusive=is_last,
                column_name_mappings=table_config.get(keys.COLUMN_MAPPINGS),
            )

            stage_path = dea_factory.stage_path("row", partition_num)

            dea_payload = dea_factory.row_payload(
                index_column_list=index_column_list,
                target_index_column_list=target_index_column_list,
                columns_metadata=columns_metadata,
                source_where_clause=source_where,
                target_where_clause=target_where,
                max_failed_rows_number=max_failed_rows_number,
                partition_number=partition_num,
                source_table_fqn=src_fq,
                target_table_fqn=tgt_fq,
            )

            if snowpipe_chain is not None:
                dea_payload.result_pipes = build_result_pipes_for_partition(
                    pipe_entries=snowpipe_chain.pipe_entries,
                    workflow_id=payload.workflow_id,
                    table_metadata_id=payload.table_metadata_id,
                    level="row",
                    partition_number=partition_num,
                )
                dea_task = (
                    TaskBuilder(
                        workflow_id=payload.workflow_id,
                        task_name=(
                            f"MD5 validation for hybrid partition {partition_num} "
                            f"of {payload.source_identifier}"
                        ),
                        executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
                        payload=dea_payload,
                        scope=build_validation_scope(
                            payload.source_identifier,
                            ROW_VALIDATION,
                            partition_num,
                        ),
                    )
                    .with_successor(snowpipe_chain.entry_task_id)
                    .build()
                )
                snowpipe_dea_tasks.append(dea_task)
                continue

            dea_task = TaskBuilder(
                workflow_id=payload.workflow_id,
                task_name=(
                    f"MD5 validation for hybrid partition {partition_num} "
                    f"of {payload.source_identifier}"
                ),
                executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
                payload=dea_payload,
                scope=build_validation_scope(
                    payload.source_identifier, ROW_VALIDATION, partition_num
                ),
            ).build()

            summary_copy_query = _build_row_summary_copy_query(stage_path)
            diffs_copy_query = _build_row_diffs_copy_query(stage_path, partition_num)
            hashes_copy_query = _build_chunk_hashes_copy_query(stage_path)

            write_payload = WriteValidationResultsPayload(
                query=f"{summary_copy_query}; {diffs_copy_query}; {hashes_copy_query}",
                table_metadata_id=payload.table_metadata_id,
                workflow_id=payload.workflow_id,
                validation_level=ROW_VALIDATION,
                partition_number=partition_num,
            )
            write_task = (
                TaskBuilder(
                    workflow_id=payload.workflow_id,
                    task_name=(
                        f"Write MD5 results for hybrid partition {partition_num}"
                    ),
                    executor_type=ExecutorType.ORCHESTRATOR,
                    payload=write_payload,
                    scope=build_write_results_scope(
                        payload.source_identifier, ROW_VALIDATION, partition_num
                    ),
                )
                .with_successor(evaluate_task_id)
                .build()
            )

            chains.append((dea_task, write_task))

        if snowpipe_dea_tasks:
            await self.task_queue.push_tasks_batch(snowpipe_dea_tasks)
        if chains:
            await self.task_queue.push_independent_two_task_chains(chains)

        await maybe_push_l3_early_stop_poll(
            self.task_queue,
            workflow_id=payload.workflow_id,
            table_metadata_id=payload.table_metadata_id,
            source_identifier=payload.source_identifier,
            row_validation_mode=ROW_VALIDATION_MODE_HYBRID,
            table_config=table_config,
            anchor_task_id=evaluate_task_id,
            use_snowpipe_for_results=use_snowpipe,
        )

        logger.info(
            "Pushed hybrid L3 row-hashing chain for %s "
            "(table_metadata_id=%d, %d partition(s), use_snowpipe=%s, "
            "anchor_task_id=%d)",
            payload.source_identifier,
            payload.table_metadata_id,
            len(partitions),
            use_snowpipe,
            evaluate_task_id,
        )

    async def fetch_mismatched_partition_numbers(
        self, workflow_id: int, table_metadata_id: int
    ) -> list[int | None]:
        """
        Return distinct ``PARTITION_NUMBER`` values eligible for cell drill-down.

        Reads ``ROW_VALIDATION_RESULTS`` filtered to ``RESULT = 'FAILURE'``
        for the given workflow/table — i.e. rows that exist on both sides
        but whose hashes disagree. ``NOT_FOUND_SOURCE``/``NOT_FOUND_TARGET``
        and ``DUPLICATE_*`` rows are intentionally excluded: a missing row
        has nothing to compare cell-by-cell against, and duplicate keys
        cannot be unambiguously paired up. ``NULL`` partitions
        (un-partitioned tables) are returned as ``None`` so callers can
        still fan out the cell drill-down for them.
        """
        sql = (
            f"SELECT DISTINCT PARTITION_NUMBER "
            f"FROM {fq_row_validation_results()} "
            f"WHERE WORKFLOW_ID = {workflow_id} "
            f"AND TABLE_METADATA_ID = {table_metadata_id} "
            f"AND RESULT = 'FAILURE'"
        )
        rows = await self.warehouse_proxy.execute_sync_query(sql)
        if not rows:
            return []
        partitions: list[int | None] = []
        for row in rows:
            raw = row.get("PARTITION_NUMBER", row.get("partition_number"))
            if raw is None:
                partitions.append(None)
            else:
                try:
                    partitions.append(int(raw))
                except (TypeError, ValueError):
                    continue
        return partitions

    async def push_cell_drilldown_for_partitions(
        self,
        payload: EvaluateLevelResultPayload,
        partition_numbers: list[int | None],
    ) -> int | None:
        """
        Push cell DEA tasks for the given mismatched partitions and the finalize task.

        Wires every cell DEA into a per-table cell ``CELL_DIFFS`` Snowpipe
        chain (Snowpipe path) or per-partition ``WriteResults[row]`` task
        chain (non-Snowpipe path) whose successor is a single per-table
        :class:`FinalizeHybridL3Payload` orchestrator task. Returns the
        finalize task id, or ``None`` when ``partition_numbers`` is empty
        (caller is responsible for inline finalization in that case).
        """
        if not partition_numbers:
            return None

        table_config = await self._fetch_table_config(payload.table_metadata_id)
        cell_metrics_ctx = await self._fetch_metrics_column_metadata(
            payload.workflow_id,
            payload.table_metadata_id,
            payload.source_identifier,
            table_config,
            payload.source_platform,
        )
        src_db, src_schema, src_table = parse_source_fqn_parts(
            payload.source_identifier, payload.source_platform
        )
        tgt_db = table_config.get(keys.TARGET_DATABASE, "")
        tgt_schema = table_config.get(keys.TARGET_SCHEMA, src_schema)
        tgt_table = table_config.get(keys.TARGET_NAME, src_table)
        src_fq = (
            f"{src_db}.{src_schema}.{src_table}"
            if src_db
            else f"{src_schema}.{src_table}"
        )
        tgt_fq = (
            f"{tgt_db}.{tgt_schema}.{tgt_table}"
            if tgt_db
            else f"{tgt_schema}.{tgt_table}"
        )
        index_column_list = table_config.get(keys.INDEX_COLUMN_LIST) or []
        target_index_column_list = (
            table_config.get(keys.TARGET_INDEX_COLUMN_LIST) or index_column_list
        )
        max_failed_raw = table_config.get(keys.MAX_FAILED_ROWS_NUMBER)
        try:
            cell_max_failed_rows: int | None = (
                int(max_failed_raw) if max_failed_raw is not None else None
            )
        except (TypeError, ValueError):
            cell_max_failed_rows = None
        max_cols_batch = table_config.get(keys.MAX_COLUMNS_PER_CELL_BATCH)

        finalize_task = (
            TaskBuilder(
                workflow_id=payload.workflow_id,
                task_name=f"Finalize hybrid L3 for {payload.source_identifier}",
                executor_type=ExecutorType.ORCHESTRATOR,
                payload=FinalizeHybridL3Payload(
                    workflow_id=payload.workflow_id,
                    table_metadata_id=payload.table_metadata_id,
                    source_identifier=payload.source_identifier,
                ),
                scope=(
                    f"{build_evaluate_scope(payload.source_identifier, ROW_VALIDATION)}"
                    f"::Finalize"
                ),
            )
            .blocked()
            .with_priority(DEFAULT_PRIORITY)
            .build()
        )
        finalize_task_id = await self.task_queue.push_task(finalize_task)
        if finalize_task_id is None:
            raise RuntimeError(
                f"Failed to push FinalizeHybridL3 task for "
                f"{payload.source_identifier}"
            )

        snowpipe_chain = None
        if payload.use_snowpipe_for_results:
            snowpipe_chain = await build_snowpipe_level_chain(
                task_queue=self.task_queue,
                warehouse=self.warehouse_proxy,
                workflow_id=payload.workflow_id,
                table_metadata_id=payload.table_metadata_id,
                level="cell",
                pipe_keys=[DvResultsPipeKey.CELL_DIFFS],
                evaluate_task_id=finalize_task_id,
            )

        user_source_where = table_config.get(keys.WHERE_CLAUSE) or ""
        user_target_where = table_config.get(keys.TARGET_WHERE_CLAUSE) or ""
        _pcols = table_config.get(keys.COLUMN_NAMES_TO_PARTITION_BY, [])
        partition_map = (
            await self._get_partition_map(payload.table_metadata_id)
            if any(part is not None for part in partition_numbers)
            else {}
        )

        partition_contexts: list[tuple[int | None, str, str]] = []
        for partition_num in partition_numbers:
            if partition_num is None:
                partition_contexts.append(
                    (partition_num, user_source_where, user_target_where)
                )
                continue

            partition = partition_map.get(int(partition_num))
            if not partition:
                logger.error(
                    "Could not find partition %s for table_metadata_id=%d",
                    partition_num,
                    payload.table_metadata_id,
                )
                continue

            min_val = partition.get(COL_MIN_VALUE)
            max_val = partition.get(COL_MAX_VALUE)
            _, _, is_last = infer_boundary_flags(
                int(partition_num),
                min_val,
                max_val,
                num_partitions=max_interior_partition_number(
                    list(partition_map.values())
                ),
            )
            source_where = build_scoped_partition_where(
                user_source_where,
                _pcols,
                min_val,
                max_val,
                payload.source_platform,
                target_side=False,
                upper_inclusive=is_last,
            )
            target_where = build_scoped_partition_where(
                user_target_where,
                _pcols,
                min_val,
                max_val,
                payload.source_platform,
                target_side=True,
                upper_inclusive=is_last,
                column_name_mappings=table_config.get(keys.COLUMN_MAPPINGS),
            )
            partition_contexts.append((partition_num, source_where, target_where))

        if index_column_list and target_index_column_list and partition_contexts:
            prefetched_rows = await self._prefetch_md5_failure_rows_by_partition(
                workflow_id=payload.workflow_id,
                table_metadata_id=payload.table_metadata_id,
                source_table_fqn=src_fq,
                partition_numbers=[part for part, _, _ in partition_contexts],
            )
            narrowed_contexts: list[tuple[int | None, str, str]] = []
            for partition_num, source_where, target_where in partition_contexts:
                narrowed_contexts.append(
                    (
                        partition_num,
                        *self._narrow_hybrid_cell_where_with_prefetched_rows(
                            partition_number=partition_num,
                            prefetched_rows=prefetched_rows.get(partition_num, []),
                            index_column_list=index_column_list,
                            target_index_column_list=target_index_column_list,
                            source_where=source_where,
                            target_where=target_where,
                        ),
                    )
                )
            partition_contexts = narrowed_contexts

        source_object_type = resolve_object_type(
            table_config.get("object_type", "TABLE")
        )
        normalized_queries: list[tuple[str, str]] | None = None
        if cell_metrics_ctx and partition_contexts:
            normalized_queries = (
                build_normalized_cell_validation_queries_for_partitions(
                    source_platform_str=payload.source_platform,
                    source_db=cell_metrics_ctx[_CTX_SRC_DB],
                    source_schema=cell_metrics_ctx[_CTX_SRC_SCHEMA],
                    source_table=cell_metrics_ctx[_CTX_SRC_TABLE],
                    source_fqn=cell_metrics_ctx[_CTX_SRC_FQ],
                    target_db=cell_metrics_ctx[_CTX_TGT_DB],
                    target_schema=cell_metrics_ctx[_CTX_TGT_SCHEMA],
                    target_table=cell_metrics_ctx[_CTX_TGT_TABLE],
                    target_fqn=cell_metrics_ctx[_CTX_TGT_FQ],
                    source_columns=cell_metrics_ctx[_CTX_SOURCE_COLUMNS],
                    target_columns=cell_metrics_ctx[_CTX_TARGET_COLUMNS],
                    partition_where_clauses=[
                        (source_where, target_where)
                        for _, source_where, target_where in partition_contexts
                    ],
                    order_by_columns=index_column_list or None,
                    source_object_type=source_object_type,
                    custom_normalizations_source=(
                        payload.custom_overrides.custom_normalizations_source
                        if payload.custom_overrides
                        else None
                    ),
                    custom_normalizations_target=(
                        payload.custom_overrides.custom_normalizations_target
                        if payload.custom_overrides
                        else None
                    ),
                )
            )

        dea_factory = DEAPayloadFactory(
            workflow_id=payload.workflow_id,
            table_metadata_id=payload.table_metadata_id,
            source_identifier=payload.source_identifier,
            source_platform=payload.source_platform,
            object_type=table_config.get("object_type", "TABLE"),
            custom_overrides=payload.custom_overrides,
        )
        snowpipe_dea_tasks: list[Task] = []
        chains: list[tuple[Task, Task]] = []
        successor_task_id = (
            snowpipe_chain.entry_task_id
            if snowpipe_chain is not None
            else finalize_task_id
        )
        for idx, (partition_num, source_where, target_where) in enumerate(
            partition_contexts
        ):
            if normalized_queries:
                source_query, target_query = normalized_queries[idx]
            else:
                logger.warning(
                    "Hybrid cell validation: could not build normalized queries for %s "
                    "(missing or misaligned column metadata); using raw SELECT *",
                    payload.source_identifier,
                )
                source_query, target_query = build_cell_validation_queries(
                    src_fq,
                    tgt_fq,
                    source_where,
                    target_where,
                    order_by_columns=index_column_list or None,
                )
            dea_task, write_task = self._build_cell_tasks_for_partition(
                payload=payload,
                partition_num=partition_num,
                source_query=source_query,
                target_query=target_query,
                source_fqn=src_fq,
                target_fqn=tgt_fq,
                index_column_list=index_column_list,
                target_index_column_list=target_index_column_list,
                cell_max_failed_rows=cell_max_failed_rows,
                max_cols_batch=max_cols_batch,
                dea_factory=dea_factory,
                successor_task_id=successor_task_id,
                snowpipe_chain=snowpipe_chain,
            )
            if snowpipe_chain is not None:
                snowpipe_dea_tasks.append(dea_task)
            else:
                assert write_task is not None
                chains.append((dea_task, write_task))

        if snowpipe_dea_tasks:
            await self.task_queue.push_tasks_batch(snowpipe_dea_tasks)
        if chains:
            await self.task_queue.push_independent_two_task_chains(chains)

        logger.info(
            "Pushed hybrid L3 cell drill-down for %s "
            "(table_metadata_id=%d, %d mismatched partition(s), "
            "use_snowpipe=%s, finalize_task_id=%d)",
            payload.source_identifier,
            payload.table_metadata_id,
            len(partition_numbers),
            payload.use_snowpipe_for_results,
            finalize_task_id,
        )
        return finalize_task_id

    async def finalize_no_mismatch_inline(
        self, payload: EvaluateLevelResultPayload
    ) -> None:
        """
        Run the FinalizeHybridL3 logic inline when zero partitions need cell drill-down.

        Mirrors :class:`FinalizeHybridL3Handler.handle` but skips pushing
        a separate task: we already know the cell-diff count is zero.
        """
        from data_migration_orchestrator.data_validation_cloud.partition_progress import (
            bulk_set_partition_level_status,
        )
        from data_migration_orchestrator.data_validation_core.constants import (
            TABLE_STATUS_COMPLETED,
            VALIDATION_STATUS_VALID,
        )

        await bulk_set_partition_level_status(
            self.warehouse_proxy,
            table_metadata_id=payload.table_metadata_id,
            column="L3_STATUS",
            status=VALIDATION_STATUS_VALID,
        )
        await self.warehouse_proxy.execute_sync_query(
            f"CALL {data_validation_full_schema()}.UPDATE_TABLE_VALIDATION_STATUS("
            f"{payload.table_metadata_id}, '{TABLE_STATUS_COMPLETED}')"
        )
        logger.info(
            "Hybrid L3 finalize INLINE for %s (table_metadata_id=%d): no "
            "mismatched partitions; marked L3_STATUS=valid",
            payload.source_identifier,
            payload.table_metadata_id,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_cell_tasks_for_partition(
        self,
        *,
        payload: EvaluateLevelResultPayload,
        partition_num: int | None,
        source_query: str,
        target_query: str,
        source_fqn: str,
        target_fqn: str,
        index_column_list: list[str],
        target_index_column_list: list[str],
        cell_max_failed_rows: int | None,
        max_cols_batch: int | None,
        dea_factory: DEAPayloadFactory,
        successor_task_id: int,
        snowpipe_chain: Any | None,
    ) -> tuple[Task, Task | None]:
        stage_path = dea_factory.stage_path("cell", partition_num)
        copy_query = _build_cell_diffs_copy_query(stage_path)

        dea_payload = dea_factory.cell_payload(
            source_query=source_query,
            target_query=target_query,
            index_column_list=index_column_list,
            target_index_column_list=target_index_column_list,
            partition_number=partition_num,
            source_table_fqn=source_fqn,
            target_table_fqn=target_fqn,
            max_failed_rows_number=cell_max_failed_rows,
            max_columns_per_cell_batch=max_cols_batch,
        )
        if snowpipe_chain is not None:
            dea_payload.result_pipes = build_result_pipes_for_partition(
                pipe_entries=snowpipe_chain.pipe_entries,
                workflow_id=payload.workflow_id,
                table_metadata_id=payload.table_metadata_id,
                level="cell",
                partition_number=partition_num,
            )
        dea_builder = TaskBuilder(
            workflow_id=payload.workflow_id,
            task_name=(
                f"Cell validation for hybrid partition {partition_num} "
                f"of {payload.source_identifier}"
            ),
            executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
            payload=dea_payload,
            scope=build_validation_scope(
                payload.source_identifier, ROW_VALIDATION, partition_num
            ),
        )
        if snowpipe_chain is not None:
            dea_builder = dea_builder.with_successor(successor_task_id)
        dea_task = dea_builder.build()
        if snowpipe_chain is not None:
            return dea_task, None

        write_payload = WriteValidationResultsPayload(
            query=copy_query,
            table_metadata_id=payload.table_metadata_id,
            workflow_id=payload.workflow_id,
            validation_level=ROW_VALIDATION,
            partition_number=partition_num,
        )
        write_task = (
            TaskBuilder(
                workflow_id=payload.workflow_id,
                task_name=f"Write cell results for hybrid partition {partition_num}",
                executor_type=ExecutorType.ORCHESTRATOR,
                payload=write_payload,
                scope=build_write_results_scope(
                    payload.source_identifier, ROW_VALIDATION, partition_num
                ),
            )
            .with_successor(successor_task_id)
            .build()
        )
        return dea_task, write_task

    async def _prefetch_md5_failure_rows_by_partition(
        self,
        *,
        workflow_id: int,
        table_metadata_id: int,
        source_table_fqn: str,
        partition_numbers: list[int | None],
    ) -> dict[int | None, list[dict[str, Any]]]:
        """Read MD5 diff key rows once and group them by partition number."""
        unique_non_null = sorted(
            {
                int(partition_number)
                for partition_number in partition_numbers
                if partition_number is not None
            }
        )
        include_null = any(
            partition_number is None for partition_number in partition_numbers
        )
        partition_predicates: list[str] = []
        if unique_non_null:
            in_list = ", ".join(
                str(partition_number) for partition_number in unique_non_null
            )
            partition_predicates.append(f"PARTITION_NUMBER IN ({in_list})")
        if include_null:
            partition_predicates.append("PARTITION_NUMBER IS NULL")
        partition_clause = (
            f" AND ({' OR '.join(partition_predicates)})"
            if partition_predicates
            else ""
        )

        try:
            safe_name = quote_string_literal(source_table_fqn)
            q = (
                f"SELECT PARTITION_NUMBER, SOURCE_INDEX_VALUES, TARGET_INDEX_VALUES "
                f"FROM {fq_row_validation_results()} "
                f"WHERE WORKFLOW_ID = {workflow_id} "
                f"AND TABLE_METADATA_ID = {table_metadata_id} "
                f"AND TABLE_NAME = {safe_name} "
                f"AND RESULT = 'FAILURE' "
                f"{partition_clause}"
            )
            rows = await self.warehouse_proxy.execute_sync_query(q)
        except Exception as exc:
            logger.warning(
                "Hybrid cell: could not read MD5 failure keys from "
                "ROW_VALIDATION_RESULTS (%s); using partition-scoped scan only",
                exc,
            )
            return {}

        grouped: dict[int | None, list[dict[str, Any]]] = {}
        for row in rows or []:
            raw_partition = row.get("PARTITION_NUMBER", row.get("partition_number"))
            partition_number: int | None
            if raw_partition is None:
                partition_number = None
            else:
                try:
                    partition_number = int(raw_partition)
                except (TypeError, ValueError):
                    continue
            grouped.setdefault(partition_number, []).append(row)

        logger.debug(
            "Hybrid cell: prefetched MD5 failure rows for %d partition key(s) "
            "(workflow=%d, table_metadata_id=%d)",
            len(grouped),
            workflow_id,
            table_metadata_id,
        )
        return grouped

    def _narrow_hybrid_cell_where_with_prefetched_rows(
        self,
        *,
        partition_number: int | None,
        prefetched_rows: list[dict[str, Any]],
        index_column_list: list[str],
        target_index_column_list: list[str],
        source_where: str,
        target_where: str,
    ) -> tuple[str, str]:
        """Apply prefetched MD5 row predicates to source/target WHERE clauses."""
        if not prefetched_rows:
            logger.debug(
                "Hybrid cell: no MD5 diff rows found for partition=%s; "
                "using partition-scoped scan only",
                partition_number,
            )
            return source_where, target_where

        src_strings = [str(r.get("SOURCE_INDEX_VALUES") or "") for r in prefetched_rows]
        tgt_strings = [str(r.get("TARGET_INDEX_VALUES") or "") for r in prefetched_rows]

        src_pred = build_or_predicate_for_index_value_strings(
            index_column_list, src_strings
        )
        tgt_pred = build_or_predicate_for_index_value_strings(
            target_index_column_list, tgt_strings
        )

        if not src_pred and not tgt_pred:
            return source_where, target_where

        new_src = (
            merge_sql_where_clauses(source_where, src_pred)
            if src_pred
            else source_where
        )
        new_tgt = (
            merge_sql_where_clauses(target_where, tgt_pred)
            if tgt_pred
            else target_where
        )

        logger.debug(
            "Hybrid cell: narrowed SELECT to MD5-failed keys "
            "(partition=%s, %d diff row(s); source_predicate=%s target_predicate=%s)",
            partition_number,
            len(prefetched_rows),
            bool(src_pred),
            bool(tgt_pred),
        )
        return new_src, new_tgt

    async def _get_partition_map(
        self, table_metadata_id: int
    ) -> dict[int, dict[str, Any]]:
        """Return partition metadata keyed by PARTITION_NUMBER."""
        partitions = await self._get_partitions(table_metadata_id)
        partition_map: dict[int, dict[str, Any]] = {}
        for partition in partitions:
            raw_partition = partition.get(COL_PARTITION_NUMBER)
            if raw_partition is None:
                continue
            try:
                partition_number = int(raw_partition)
            except (TypeError, ValueError):
                continue
            partition_map[partition_number] = partition
        return partition_map

    async def _fetch_table_config(self, table_metadata_id: int) -> dict:
        """Fetch table configuration from Snowflake."""
        config_result = await self.warehouse_proxy.execute_sync_query(
            f"CALL {data_validation_full_schema()}.GET_TABLE_CONFIGURATION({table_metadata_id})"
        )
        table_config_variant = (
            next(iter(config_result[0].values())) if config_result else None
        )
        return (
            json.loads(table_config_variant)
            if isinstance(table_config_variant, str)
            else table_config_variant
        ) or {}

    async def _get_partitions(self, table_metadata_id: int) -> list[dict]:
        """Get partition metadata for a table."""
        result = await self.warehouse_proxy.execute_sync_query(
            f"CALL {data_validation_full_schema()}.GET_PARTITION_METADATA({table_metadata_id})"
        )
        if not result:
            return []
        if isinstance(result, list):
            return result
        return []

    async def _get_columns_metadata(
        self,
        workflow_id: int,
        table_metadata_id: int,
        source_platform: str,
    ) -> list[ColumnMetadataDict]:
        """
        Read source column names + data types from L1 schema results.

        Uses the same SQL-based approach as the evaluate handler, with a
        fallback to re-run COPY INTO from the stage if results are missing.
        """
        columns = await self._query_schema_columns(
            workflow_id, table_metadata_id, source_platform
        )
        if columns:
            return columns

        logger.warning(
            "No L1 schema results found for workflow=%d, table_metadata_id=%d. "
            "Attempting to load from stage as fallback.",
            workflow_id,
            table_metadata_id,
        )
        stage_path = (
            f"@{task_results_stage()}/{workflow_id}/{table_metadata_id}/schema/"
        )
        delete_sql = (
            f"DELETE FROM {fq_schema_validation_results()} "
            f"WHERE WORKFLOW_ID = {workflow_id} "
            f"AND TABLE_METADATA_ID = {table_metadata_id}"
        )
        copy_sql = (
            f"COPY INTO {fq_schema_validation_results()} "
            f"(WORKFLOW_ID, TABLE_METADATA_ID, VALIDATION_TYPE, TABLE_NAME, "
            f"COLUMN_VALIDATED, EVALUATION_CRITERIA, SOURCE_VALUE, "
            f"SNOWFLAKE_VALUE, STATUS, COMMENTS) "
            f"FROM (SELECT $1, $2, $3, $4, $5, $6, $7, $8, $9, $10 "
            f"FROM '{stage_path}') "
            f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
            f"FORCE = TRUE ON_ERROR = 'CONTINUE'"
        )
        try:
            await self.warehouse_proxy.execute_sync_query(delete_sql)
            await self.warehouse_proxy.execute_sync_query(copy_sql)
        except Exception:
            logger.warning(
                "Fallback COPY INTO failed for workflow=%d, table_metadata_id=%d",
                workflow_id,
                table_metadata_id,
                exc_info=True,
            )

        return await self._query_schema_columns(
            workflow_id, table_metadata_id, source_platform
        )

    async def _query_schema_columns(
        self,
        workflow_id: int,
        table_metadata_id: int,
        source_platform: str,
    ) -> list[ColumnMetadataDict]:
        """Query SCHEMA_VALIDATION_RESULTS for column metadata."""
        schema_rows = await self.warehouse_proxy.execute_sync_query(
            f"SELECT COLUMN_VALIDATED, SOURCE_VALUE "
            f"FROM {fq_schema_validation_results()} "
            f"WHERE WORKFLOW_ID = {workflow_id} "
            f"AND TABLE_METADATA_ID = {table_metadata_id} "
            f"AND EVALUATION_CRITERIA = 'DATA_TYPE' "
            f"AND SOURCE_VALUE != 'MISSING'"
        )
        columns: list[ColumnMetadataDict] = []
        folding = folding_strategy_for_source_platform(source_platform)
        if schema_rows:
            for row in schema_rows:
                col_name = row.get(COL_COLUMN_VALIDATED, "")
                src_type = row.get(COL_SOURCE_VALUE, "")
                if col_name and src_type:
                    col_name = apply_identifier_folding(col_name, folding)
                    columns.append({"name": col_name, "data_type": src_type})
        return columns

    async def _fetch_metrics_column_metadata(
        self,
        workflow_id: int,
        table_metadata_id: int,
        source_identifier: str,
        table_config: dict,
        source_platform: str,
    ) -> dict[str, Any] | None:
        """
        Build the metrics column context dict needed for normalized cell queries.

        Source columns come from SCHEMA_VALIDATION_RESULTS (Teradata data
        types). Target columns come from information_schema.columns
        (Snowflake data types), matching the approach used in
        evaluate_level_result_handler.
        """
        from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
            make_column_metadata,
        )

        source_columns_raw = await self._get_columns_metadata(
            workflow_id, table_metadata_id, source_platform
        )
        if not source_columns_raw:
            return None

        src_db, src_schema, src_table = parse_source_fqn_parts(
            source_identifier, source_platform
        )
        tgt_db = table_config.get(keys.TARGET_DATABASE, "")
        tgt_schema = table_config.get(keys.TARGET_SCHEMA, src_schema)
        tgt_table = table_config.get(keys.TARGET_NAME, src_table)

        source_columns = [
            make_column_metadata(c["name"], c["data_type"]) for c in source_columns_raw
        ]

        tgt_fq_prefix = f"{tgt_db}." if tgt_db else ""
        target_col_rows = await self.warehouse_proxy.execute_sync_query(
            f"SELECT column_name, data_type "
            f"FROM {tgt_fq_prefix}information_schema.columns "
            f"WHERE table_schema = '{tgt_schema.upper()}' "
            f"AND table_name = '{tgt_table.upper()}' "
            f"ORDER BY ordinal_position"
        )

        target_columns = []
        if target_col_rows:
            for row in target_col_rows:
                col_name = row.get("COLUMN_NAME", row.get("column_name", ""))
                data_type = row.get("DATA_TYPE", row.get("data_type", ""))
                if col_name and data_type:
                    target_columns.append(
                        make_column_metadata(name=col_name, data_type=data_type)
                    )

        src_fq = (
            f"{src_db}.{src_schema}.{src_table}"
            if src_db
            else f"{src_schema}.{src_table}"
        )
        tgt_fq = (
            f"{tgt_db}.{tgt_schema}.{tgt_table}"
            if tgt_db
            else f"{tgt_schema}.{tgt_table}"
        )

        return {
            _CTX_SOURCE_COLUMNS: source_columns,
            _CTX_TARGET_COLUMNS: target_columns,
            _CTX_SRC_DB: src_db,
            _CTX_SRC_SCHEMA: src_schema,
            _CTX_SRC_TABLE: src_table,
            _CTX_TGT_DB: tgt_db,
            _CTX_TGT_SCHEMA: tgt_schema,
            _CTX_TGT_TABLE: tgt_table,
            _CTX_SRC_FQ: src_fq,
            _CTX_TGT_FQ: tgt_fq,
        }


# ------------------------------------------------------------------
# Module-level static utilities
# ------------------------------------------------------------------


def _build_scoped_where(
    user_where: str,
    partition_column: str | None,
    min_value: Any,
    max_value: Any,
    source_platform: str,
    *,
    target_side: bool,
) -> str:
    """Combine a user WHERE clause with a partition range condition."""
    if not partition_column or (min_value is None and max_value is None):
        return user_where

    if target_side:
        range_clause = build_snowflake_partition_condition(
            partition_column,
            min_value,
            max_value,
        )
    else:
        try:
            platform = PlatformRegistry.create_by_name_or_alias(
                source_platform,
            )
            range_clause = platform.query_builder.build_partition_condition(
                partition_column,
                min_value,
                max_value,
            )
        except (KeyError, ValueError):
            range_clause = build_snowflake_partition_condition(
                partition_column,
                min_value,
                max_value,
            )

    if range_clause == "1=1":
        return user_where

    if user_where:
        return f"({user_where}) AND {range_clause}"
    return range_clause


def _parse_fqn(fqn: str) -> tuple[str, str, str]:
    """Parse a fully-qualified name into (database, schema, table)."""
    parts = fqn.split(".")
    if len(parts) == 3:
        return parts[0], parts[1], parts[2]
    if len(parts) == 2:
        return "", parts[0], parts[1]
    return "", "", fqn


def _build_row_summary_copy_query(stage_path: str) -> str:
    """Build COPY INTO SQL for row validation summary."""
    return (
        f"COPY INTO {fq_row_validation_summary()} "
        f"(WORKFLOW_ID, TABLE_METADATA_ID, TABLE_NAME, TOTAL_CHUNKS, "
        f"MATCHING_CHUNKS, DIFFERING_CHUNKS, TOTAL_ROWS_COMPARED, "
        f"ROWS_NOT_FOUND_IN_TARGET, ROWS_NOT_FOUND_IN_SOURCE, "
        f"ROWS_WITH_DIFFERENCES, IS_VALID) "
        f"FROM (SELECT "
        f"$1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11 "
        f"FROM '{stage_path}/summary/') "
        f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
        f"ON_ERROR = 'CONTINUE'"
    )


def _build_row_diffs_copy_query(
    stage_path: str, partition_number: int | None = None
) -> str:
    """Build COPY INTO SQL for row validation diffs."""
    partition_expr = (
        f"{int(partition_number)}::INT" if partition_number is not None else "NULL::INT"
    )
    return (
        f"COPY INTO {fq_row_validation_results()} "
        f"(WORKFLOW_ID, TABLE_METADATA_ID, TABLE_NAME, "
        f"OBJECT_TYPE, RESULT, SOURCE_INDEX_VALUES, TARGET_INDEX_VALUES, "
        f"TARGET_TABLE_NAME, PARTITION_NUMBER) "
        f"FROM (SELECT "
        f"$1, $2, $3, $4, $5, $6, $7, $8, {partition_expr} "
        f"FROM '{stage_path}/diffs/') "
        f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
        f"ON_ERROR = 'CONTINUE'"
    )


def _build_chunk_hashes_copy_query(stage_path: str) -> str:
    """Build COPY INTO SQL for chunk hashes."""
    return (
        f"COPY INTO {fq_chunk_hashes()} "
        f"(WORKFLOW_ID, TABLE_METADATA_ID, TABLE_NAME, CHUNK_ID, "
        f"SOURCE_HASH, TARGET_HASH, IS_MATCH) "
        f"FROM (SELECT "
        f"$1, $2, $3, $4, $5, $6, $7 "
        f"FROM '{stage_path}/hashes/') "
        f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
        f"ON_ERROR = 'CONTINUE'"
    )


def _build_cell_diffs_copy_query(stage_path: str) -> str:
    """Build COPY INTO SQL for cell validation diffs."""
    return (
        f"COPY INTO {fq_cell_validation_results()} "
        f"(WORKFLOW_ID, TABLE_METADATA_ID, TABLE_NAME, "
        f"ROW_INDEX, COLUMN_NAME, SOURCE_VALUE, TARGET_VALUE) "
        f"FROM (SELECT "
        f"$1, $2, $3, $4, $5, $6, $7 "
        f"FROM '{stage_path}/diffs/') "
        f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
        f"ON_ERROR = 'CONTINUE'"
    )
