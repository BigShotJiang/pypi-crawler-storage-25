"""
Handler for GENERATE_VALIDATION_QUERIES tasks.

Reads staged source metadata, determines partitioning, generates L1 schema
validation queries via sdv, and pushes L1 DEA tasks + write-results +
blocked EVALUATE_LEVEL_RESULT.
"""

from __future__ import annotations

import json

from typing import Any

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.tasks.task_builder import TaskBuilder
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_migration_cloud.platforms.snowflake.identifiers import (
    quote_identifier,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_calculator import (
    PartitionCalculator,
    PartitionConfig,
)
from data_migration_orchestrator.data_validation_cloud.config.configuration_properties_keys import (
    COLUMN_NAMES_TO_PARTITION_BY,
    TARGET_PARTITION_SIZE_MB,
    TARGET_PARTITION_SIZE_ROWS,
    TARGET_WHERE_CLAUSE,
    WHERE_CLAUSE,
)
from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
    build_schema_queries,
    load_datatypes_mappings,
    parse_source_fqn_parts,
    resolve_object_type,
)
from data_migration_orchestrator.data_validation_cloud.scope import (
    build_evaluate_scope,
    build_validation_scope,
    build_write_results_scope,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.custom_template_overrides import (
    CustomTemplateOverrides,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.dea_payload_factory import (
    DEAPayloadFactory,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    EvaluateLevelResultPayload,
    GenerateValidationQueriesPayload,
    WriteValidationResultsPayload,
)
from data_migration_orchestrator.data_validation_core.constants import (
    METRICS_VALIDATION,
    ROW_VALIDATION,
    SCHEMA_VALIDATION,
    SKIP_LEVEL,
    data_validation_full_schema,
    fq_schema_validation_results,
    fq_table_metadata,
    validation_csv_file_format_fqn,
)
from data_migration_orchestrator.utils.partition_metadata_bulk_sql import (
    PARTITION_METADATA_INSERT_CHUNK_SIZE,
    iter_bulk_insert_partition_metadata_sqls,
)
from shared.telemetry import WorkflowStep, set_current_step


logger = get_logger("dv.generate_validation_queries_handler")

# Large-table NTILE boundary sampling (Snowflake SAMPLE BERNOULLI)
SAMPLING_THRESHOLD_ROWS = 100_000_000
SAMPLING_TARGET_ROWS = 20_000_000

# DV-specific defaults
DEFAULT_BASE_MAX_ROWS_PER_PARTITION = 5_000_000
DEFAULT_DV_TARGET_MB_PER_PARTITION = 200
DEFAULT_DV_MAX_MB_PER_PARTITION = 1_024
DEFAULT_MAX_CELLS_PER_PARTITION = 100_000_000

_BYTES_PER_MB = 1024 * 1024


class GenerateValidationQueriesHandler:
    """
    Handle GENERATE_VALIDATION_QUERIES tasks.

    Reads staged metadata, determines partitioning strategy, generates L1 schema
    queries, and pushes the L1 task chain: DEA validation -> write results ->
    evaluate level result.
    """

    def __init__(
        self,
        task_queue: BaseTaskQueue,
        warehouse_proxy: Warehouse,
    ) -> None:
        """
        Initialize the handler.

        Args:
            task_queue: Task queue for pushing follow-up tasks.
            warehouse_proxy: Warehouse proxy for Snowflake operations.

        """
        self.task_queue = task_queue
        self.warehouse_proxy = warehouse_proxy

    async def handle(self, task: Task) -> None:
        """
        Handle the generate validation queries task.

        1. Read table configuration from TABLE_METADATA
        2. Insert PARTITION_METADATA rows based on row count and column count
        3. Generate L1 schema validation queries
        4. Push L1 task chain

        Args:
            task: The task containing GenerateValidationQueriesPayload.

        """
        payload: GenerateValidationQueriesPayload = task.payload
        assert task.id is not None, "Task must have an ID when being handled"
        table_metadata_id = payload.table_metadata_id
        source_identifier = payload.source_identifier
        workflow_id = payload.workflow_id
        source_platform = payload.source_platform

        set_current_step(WorkflowStep.PLAN, "generate-validation-queries")

        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: START (task_id=%d, workflow_id=%d, "
            "source_platform=%s)",
            source_identifier,
            table_metadata_id,
            task.id,
            workflow_id,
            source_platform,
        )

        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: step=get_table_configuration start",
            source_identifier,
            table_metadata_id,
        )
        config_result = await self.warehouse_proxy.execute_sync_query(
            f"CALL {data_validation_full_schema()}.GET_TABLE_CONFIGURATION({table_metadata_id})"
        )
        table_config_variant = (
            next(iter(config_result[0].values())) if config_result else None
        )
        table_config = (
            json.loads(table_config_variant)
            if isinstance(table_config_variant, str)
            else (table_config_variant or {})
        )
        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: step=get_table_configuration done",
            source_identifier,
            table_metadata_id,
        )

        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: step=update_validation_status start",
            source_identifier,
            table_metadata_id,
        )
        await self.warehouse_proxy.execute_sync_query(
            f"CALL {data_validation_full_schema()}.UPDATE_TABLE_VALIDATION_STATUS({table_metadata_id}, 'IN_PROGRESS')"
        )
        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: step=update_validation_status done",
            source_identifier,
            table_metadata_id,
        )

        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: step=create_partition_metadata start",
            source_identifier,
            table_metadata_id,
        )
        await self._create_partition_metadata(
            task_id=task.id,
            table_metadata_id=table_metadata_id,
            source_identifier=source_identifier,
            source_platform=source_platform,
            table_config=table_config,
        )
        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: step=create_partition_metadata done",
            source_identifier,
            table_metadata_id,
        )

        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: step=mark_preprocessed start",
            source_identifier,
            table_metadata_id,
        )
        await self.warehouse_proxy.execute_sync_query(
            f"UPDATE {fq_table_metadata()} "
            f"SET HAS_BEEN_PREPROCESSED = TRUE, UPDATED_AT = CURRENT_TIMESTAMP() "
            f"WHERE ID = {table_metadata_id}"
        )
        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: step=mark_preprocessed done",
            source_identifier,
            table_metadata_id,
        )

        schema_enabled = table_config.get("schema_validation", True)
        metrics_enabled = table_config.get("metrics_validation", True)
        row_enabled = table_config.get("row_validation", False)
        continue_on_failure = table_config.get("continue_on_failure", False)

        if not schema_enabled:
            logger.info(
                "GenerateValidationQueries[%s/tmid=%d]: schema disabled, checking next level "
                "(metrics=%s, row=%s)",
                source_identifier,
                table_metadata_id,
                metrics_enabled,
                row_enabled,
            )
            next_level = (
                METRICS_VALIDATION
                if metrics_enabled
                else (ROW_VALIDATION if row_enabled else None)
            )
            if next_level is None:
                logger.info(
                    "GenerateValidationQueries[%s/tmid=%d]: no validation levels enabled; "
                    "completing task",
                    source_identifier,
                    table_metadata_id,
                )
                await self.task_queue.complete_task(ExecutorType.ORCHESTRATOR, task.id)
                return
            logger.info(
                "GenerateValidationQueries[%s/tmid=%d]: step=push_skip_to_level start "
                "(target=%s)",
                source_identifier,
                table_metadata_id,
                next_level,
            )
            await self._push_skip_to_level(
                workflow_id=workflow_id,
                table_metadata_id=table_metadata_id,
                source_identifier=source_identifier,
                source_platform=source_platform,
                target_level=next_level,
                metrics_enabled=metrics_enabled,
                row_enabled=row_enabled,
                continue_on_failure=continue_on_failure,
                use_snowpipe_for_results=payload.use_snowpipe_for_results,
                custom_overrides=payload.custom_overrides,
            )
            logger.info(
                "GenerateValidationQueries[%s/tmid=%d]: step=push_skip_to_level done",
                source_identifier,
                table_metadata_id,
            )
            await self.task_queue.complete_task(ExecutorType.ORCHESTRATOR, task.id)
            logger.info(
                "GenerateValidationQueries[%s/tmid=%d]: complete (schema skipped, "
                "next level=%s)",
                source_identifier,
                table_metadata_id,
                next_level,
            )
            return

        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: step=push_l1_schema_chain start",
            source_identifier,
            table_metadata_id,
        )
        await self._push_l1_schema_chain(
            workflow_id=workflow_id,
            table_metadata_id=table_metadata_id,
            source_identifier=source_identifier,
            source_platform=source_platform,
            table_config=table_config,
            metrics_enabled=metrics_enabled,
            row_enabled=row_enabled,
            continue_on_failure=continue_on_failure,
            use_snowpipe_for_results=payload.use_snowpipe_for_results,
            custom_overrides=payload.custom_overrides,
        )
        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: step=push_l1_schema_chain done",
            source_identifier,
            table_metadata_id,
        )

        await self.task_queue.complete_task(ExecutorType.ORCHESTRATOR, task.id)
        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: complete (L1 schema chain queued)",
            source_identifier,
            table_metadata_id,
        )

    async def _push_l1_schema_chain(
        self,
        workflow_id: int,
        table_metadata_id: int,
        source_identifier: str,
        source_platform: str,
        table_config: dict,
        metrics_enabled: bool,
        row_enabled: bool,
        continue_on_failure: bool,
        use_snowpipe_for_results: bool = True,
        custom_overrides: CustomTemplateOverrides | None = None,
    ) -> None:
        """Push the L1 schema validation task chain: DEA -> write -> evaluate."""
        next_level = (
            METRICS_VALIDATION
            if metrics_enabled
            else (ROW_VALIDATION if row_enabled else None)
        )
        next_level_enabled = next_level is not None

        column_mappings = table_config.get("column_mappings", {})
        datatypes_mappings = load_datatypes_mappings(source_platform)

        object_type_str = table_config.get("object_type", "TABLE")
        source_object_type = resolve_object_type(object_type_str)
        custom_types_source = None
        if custom_overrides and custom_overrides.custom_types_source:
            custom_types_source = custom_overrides.custom_types_source.source
        if custom_types_source:
            for custom_type_dict in custom_types_source:
                for source_dt, normalized_dt in custom_type_dict.items():
                    datatypes_mappings[source_dt.upper()] = normalized_dt.upper()

        src_db, src_schema, src_table = parse_source_fqn_parts(
            source_identifier, source_platform
        )
        tgt_db = table_config.get("target_database", "")
        tgt_schema = table_config.get("target_schema", src_schema)
        tgt_table = table_config.get("target_name", src_table)

        source_where = table_config.get(WHERE_CLAUSE, "")
        target_where = table_config.get(TARGET_WHERE_CLAUSE, "")

        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: L1 build_schema_queries start",
            source_identifier,
            table_metadata_id,
        )
        source_query, target_query = build_schema_queries(
            source_platform_str=source_platform,
            source_db=src_db,
            source_schema=src_schema,
            source_table=src_table,
            target_db=tgt_db,
            target_schema=tgt_schema,
            target_table=tgt_table,
            source_where_clause=source_where,
            target_where_clause=target_where,
            source_object_type=source_object_type,
        )
        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: L1 build_schema_queries done",
            source_identifier,
            table_metadata_id,
        )

        dea_factory = DEAPayloadFactory(
            workflow_id=workflow_id,
            table_metadata_id=table_metadata_id,
            source_identifier=source_identifier,
            source_platform=source_platform,
            object_type=object_type_str,
            custom_overrides=custom_overrides,
        )

        dea_task = TaskBuilder(
            workflow_id=workflow_id,
            task_name=f"Validate schema for {source_identifier}",
            executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
            payload=dea_factory.schema_payload(
                source_query=source_query,
                target_query=target_query,
                column_mappings=column_mappings or None,
                datatypes_mappings=datatypes_mappings or None,
            ),
            scope=build_validation_scope(source_identifier, SCHEMA_VALIDATION),
        ).build()

        copy_query = self._build_schema_copy_into_query(
            workflow_id, table_metadata_id, dea_factory.stage_path(SCHEMA_VALIDATION)
        )
        write_task = TaskBuilder(
            workflow_id=workflow_id,
            task_name=f"Write L1 results for {source_identifier}",
            executor_type=ExecutorType.ORCHESTRATOR,
            payload=WriteValidationResultsPayload(
                query=copy_query,
                table_metadata_id=table_metadata_id,
                workflow_id=workflow_id,
                validation_level=SCHEMA_VALIDATION,
            ),
            scope=build_write_results_scope(source_identifier, SCHEMA_VALIDATION),
        ).build()

        evaluate_task = TaskBuilder(
            workflow_id=workflow_id,
            task_name=f"Evaluate L1 result for {source_identifier}",
            executor_type=ExecutorType.ORCHESTRATOR,
            payload=EvaluateLevelResultPayload(
                table_metadata_id=table_metadata_id,
                completed_level=SCHEMA_VALIDATION,
                next_level=next_level,
                continue_on_failure=continue_on_failure,
                next_level_enabled=next_level_enabled,
                workflow_id=workflow_id,
                source_platform=source_platform,
                source_identifier=source_identifier,
                use_snowpipe_for_results=use_snowpipe_for_results,
                custom_overrides=custom_overrides,
            ),
            scope=build_evaluate_scope(source_identifier, SCHEMA_VALIDATION),
        ).build()

        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: L1 push_task_chain start",
            source_identifier,
            table_metadata_id,
        )
        await self.task_queue.push_task_chain([dea_task, write_task, evaluate_task])
        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: L1 push_task_chain done",
            source_identifier,
            table_metadata_id,
        )

    async def _push_skip_to_level(
        self,
        workflow_id: int,
        table_metadata_id: int,
        source_identifier: str,
        source_platform: str,
        target_level: str,
        metrics_enabled: bool,
        row_enabled: bool,
        continue_on_failure: bool,
        use_snowpipe_for_results: bool = True,
        custom_overrides: CustomTemplateOverrides | None = None,
    ) -> None:
        """Push an evaluate task that will generate the next enabled level's queries."""
        evaluate_scope = build_evaluate_scope(source_identifier, SKIP_LEVEL)
        evaluate_task = TaskBuilder(
            workflow_id=workflow_id,
            task_name=f"Skip to {target_level} for {source_identifier}",
            executor_type=ExecutorType.ORCHESTRATOR,
            payload=EvaluateLevelResultPayload(
                table_metadata_id=table_metadata_id,
                completed_level=SKIP_LEVEL,
                next_level=target_level,
                continue_on_failure=continue_on_failure,
                next_level_enabled=True,
                workflow_id=workflow_id,
                source_platform=source_platform,
                source_identifier=source_identifier,
                use_snowpipe_for_results=use_snowpipe_for_results,
                custom_overrides=custom_overrides,
            ),
            scope=evaluate_scope,
        ).build()
        await self.task_queue.push_task(evaluate_task)

    async def _fetch_target_table_bytes_mb(
        self, tgt_db: str, tgt_schema: str, tgt_table: str
    ) -> float | None:
        """
        Return Snowflake target table size in MB from INFORMATION_SCHEMA.TABLES.

        Requires ``tgt_db`` (no session-database guess). Returns None when the
        catalog row is missing or BYTES is NULL.
        """
        if not (tgt_db or "").strip():
            return None
        esc_schema = tgt_schema.replace("'", "''")
        esc_table = tgt_table.replace("'", "''")
        q = (
            f"SELECT BYTES AS TS_BYTES FROM {tgt_db}.INFORMATION_SCHEMA.TABLES "
            f"WHERE TABLE_SCHEMA = '{esc_schema}' "
            f"AND TABLE_NAME = '{esc_table}' "
            f"LIMIT 1"
        )
        rows = await self.warehouse_proxy.execute_sync_query(q)
        if not rows:
            return None
        raw = rows[0].get("TS_BYTES") or rows[0].get("ts_bytes")
        if raw is None:
            return None
        try:
            nbytes = float(raw)
        except (TypeError, ValueError):
            return None
        if nbytes <= 0:
            return None
        return nbytes / _BYTES_PER_MB

    async def _fetch_target_column_count(
        self, tgt_db: str, tgt_schema: str, tgt_table: str
    ) -> int | None:
        """
        Return column count of the Snowflake target table.

        Requires ``tgt_db``. Returns None when the catalog row is missing.
        """
        if not (tgt_db or "").strip():
            return None
        esc_schema = tgt_schema.replace("'", "''")
        esc_table = tgt_table.replace("'", "''")
        q = (
            f"SELECT COUNT(*) AS COL_COUNT "
            f"FROM {tgt_db}.INFORMATION_SCHEMA.COLUMNS "
            f"WHERE TABLE_SCHEMA = '{esc_schema}' "
            f"AND TABLE_NAME = '{esc_table}'"
        )
        rows = await self.warehouse_proxy.execute_sync_query(q)
        if not rows:
            return None
        raw = rows[0].get("COL_COUNT") or rows[0].get("col_count")
        if raw is None:
            return None
        try:
            count = int(raw)
        except (TypeError, ValueError):
            return None
        return count if count > 0 else None

    @staticmethod
    def _build_schema_copy_into_query(
        workflow_id: int, table_metadata_id: int, stage_path: str
    ) -> str:
        """Build COPY INTO SQL for schema validation results."""
        return (
            f"COPY INTO {fq_schema_validation_results()} "
            f"(WORKFLOW_ID, TABLE_METADATA_ID, VALIDATION_TYPE, TABLE_NAME, "
            f"COLUMN_VALIDATED, EVALUATION_CRITERIA, SOURCE_VALUE, "
            f"SNOWFLAKE_VALUE, STATUS, COMMENTS) "
            f"FROM (SELECT "
            f"$1, $2, $3, $4, $5, $6, $7, $8, $9, $10 "
            f"FROM '{stage_path}/') "
            f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
            f"ON_ERROR = 'CONTINUE'"
        )

    async def _create_partition_metadata(
        self,
        task_id: int,
        table_metadata_id: int,
        source_identifier: str,
        source_platform: str,
        table_config: dict,
    ) -> None:
        """Populate PARTITION_METADATA using ``PartitionCalculator`` sizing."""
        partition_columns = table_config.get(COLUMN_NAMES_TO_PARTITION_BY, [])

        if not partition_columns:
            warning_msg = (
                f"Table '{source_identifier}' has no columnNamesToPartitionBy "
                f"configured. It will be validated as a single unit, which may "
                f"be slow or fail for large tables."
            )
            logger.warning(warning_msg)
            await self.task_queue.warn_task(task_id, warning_msg)
            await self._insert_single_partition(table_metadata_id)
            return

        src_db, src_schema, src_table = parse_source_fqn_parts(
            source_identifier, source_platform
        )
        tgt_db = table_config.get("target_database", "")
        tgt_schema = table_config.get("target_schema", src_schema)
        tgt_table = table_config.get("target_name", src_table)
        tgt_fqn = (
            f"{tgt_db}.{tgt_schema}.{tgt_table}"
            if tgt_db
            else f"{tgt_schema}.{tgt_table}"
        )

        target_where = table_config.get("target_where_clause", "")
        where_sql = f" WHERE {target_where}" if target_where else ""

        count_sql = f"SELECT COUNT(*) AS ROW_COUNT FROM {tgt_fqn}{where_sql}"
        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: partition_metadata row_count start",
            source_identifier,
            table_metadata_id,
        )
        count_result = await self.warehouse_proxy.execute_sync_query(count_sql)
        row_count = int(next(iter(count_result[0].values()))) if count_result else 0
        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: partition_metadata row_count done "
            "(row_count=%d)",
            source_identifier,
            table_metadata_id,
            row_count,
        )

        if row_count == 0:
            await self._insert_single_partition(table_metadata_id)
            logger.info(
                "GenerateValidationQueries[%s/tmid=%d]: empty target; inserted "
                "single virtual partition",
                source_identifier,
                table_metadata_id,
            )
            return

        raw_target_rows = table_config.get(TARGET_PARTITION_SIZE_ROWS)
        target_rows: int | None = (
            int(raw_target_rows) if raw_target_rows is not None else None
        )

        raw_target_mb = table_config.get(TARGET_PARTITION_SIZE_MB)
        target_mb: int | None = (
            int(raw_target_mb) if raw_target_mb is not None else None
        )

        data_size_mb: float = 0.0
        if (tgt_db or "").strip():
            fetched = await self._fetch_target_table_bytes_mb(
                tgt_db, tgt_schema, tgt_table
            )
            if fetched is not None and fetched > 0:
                data_size_mb = fetched

        max_cells: int | None = None
        num_columns: int = 0
        if (tgt_db or "").strip():
            fetched_cols = await self._fetch_target_column_count(
                tgt_db, tgt_schema, tgt_table
            )
            if fetched_cols is not None:
                num_columns = fetched_cols
                max_cells = DEFAULT_MAX_CELLS_PER_PARTITION

        if target_rows is not None:
            config = PartitionConfig(
                target_rows_per_partition=target_rows,
                max_target_rows_per_partition=DEFAULT_BASE_MAX_ROWS_PER_PARTITION,
                max_target_mb_per_partition=DEFAULT_DV_MAX_MB_PER_PARTITION,
                max_target_cells_per_partition=max_cells,
            )
        else:
            config = PartitionConfig(
                target_mb_per_partition=target_mb or DEFAULT_DV_TARGET_MB_PER_PARTITION,
                max_target_rows_per_partition=DEFAULT_BASE_MAX_ROWS_PER_PARTITION,
                max_target_mb_per_partition=DEFAULT_DV_MAX_MB_PER_PARTITION,
                max_target_cells_per_partition=max_cells,
            )
        decision = PartitionCalculator(config).calculate_partition_strategy(
            row_count, data_size_mb, num_columns
        )
        num_partitions = decision.num_partitions
        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: partition_strategy "
            "num_partitions=%d (row_count=%d, data_size_mb=%.2f, num_columns=%d, "
            "max_cells=%s; %s)",
            source_identifier,
            table_metadata_id,
            num_partitions,
            row_count,
            data_size_mb,
            num_columns,
            max_cells,
            decision.reasoning,
        )

        if num_partitions <= 1:
            await self._insert_single_partition(table_metadata_id)
            logger.info(
                "GenerateValidationQueries[%s/tmid=%d]: single virtual partition (%s)",
                source_identifier,
                table_metadata_id,
                decision.reasoning,
            )
            return

        used_sampling = row_count >= SAMPLING_THRESHOLD_ROWS
        ntile_query = self._build_partition_boundary_query(
            tgt_fqn,
            partition_columns,
            num_partitions,
            row_count,
            target_where,
        )

        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: partition_metadata boundary_query start",
            source_identifier,
            table_metadata_id,
        )
        boundary_rows = await self.warehouse_proxy.execute_sync_query(ntile_query)
        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: partition_metadata boundary_query done "
            "(boundary_rows=%d)",
            source_identifier,
            table_metadata_id,
            len(boundary_rows) if boundary_rows else 0,
        )

        if not boundary_rows:
            await self._insert_single_partition(table_metadata_id)
            logger.info(
                "GenerateValidationQueries[%s/tmid=%d]: NTILE returned no rows; "
                "inserted single virtual partition",
                source_identifier,
                table_metadata_id,
            )
            return

        from data_migration_orchestrator.data_migration_cloud.partition.partition_range import (
            normalize_ntile_boundary_row,
        )

        partition_rows: list[tuple[int, Any, Any, int | None]] = []
        sampled_counts: list[int] = []
        for row in boundary_rows:
            normalized = normalize_ntile_boundary_row(row, partition_columns)
            part_num = normalized.get("PARTITION_ID", normalized.get("partition_id"))
            min_val = normalized.get(
                "MIN_VALUE_IN_PARTITION", normalized.get("min_value_in_partition")
            )
            max_val = normalized.get(
                "MAX_VALUE_IN_PARTITION", normalized.get("max_value_in_partition")
            )
            raw_n = row.get("N_ROWS", row.get("n_rows"))
            n_rows_val: int | None
            if raw_n is None:
                n_rows_val = None
            else:
                n_rows_val = int(raw_n)
            if part_num is None:
                raise ValueError(f"Partition row missing PARTITION_ID: {row!r}")
            partition_rows.append((int(part_num), min_val, max_val, n_rows_val))
            sampled_counts.append(n_rows_val if n_rows_val is not None else 0)

        if used_sampling:
            total_sampled = sum(sampled_counts)
            if total_sampled > 0:
                scaled: list[tuple[int, Any, Any, int | None]] = []
                assigned = 0
                for idx, (pnum, mn, mx, _) in enumerate(partition_rows):
                    if idx == len(partition_rows) - 1:
                        est = row_count - assigned
                    else:
                        est = round(sampled_counts[idx] / total_sampled * row_count)
                        assigned += est
                    scaled.append((pnum, mn, mx, est))
                partition_rows = scaled
            else:
                logger.warning(
                    "GenerateValidationQueries[%s/tmid=%d]: used_sampling=True but "
                    "total_sampled=0; skipping per-partition row estimate scaling",
                    source_identifier,
                    table_metadata_id,
                )

        expected_chunks = (
            len(partition_rows) + PARTITION_METADATA_INSERT_CHUNK_SIZE - 1
        ) // PARTITION_METADATA_INSERT_CHUNK_SIZE
        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: partition_metadata bulk_insert start "
            "(rows=%d, chunk_size=%d, chunks=%d)",
            source_identifier,
            table_metadata_id,
            len(partition_rows),
            PARTITION_METADATA_INSERT_CHUNK_SIZE,
            expected_chunks,
        )
        await self._bulk_insert_validation_partition_rows(
            table_metadata_id,
            partition_rows,
        )
        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: partition_metadata bulk_insert done "
            "(rows=%d, chunks=%d)",
            source_identifier,
            table_metadata_id,
            len(partition_rows),
            expected_chunks,
        )

        logger.info(
            "GenerateValidationQueries[%s/tmid=%d]: created %d partitions on columns "
            "%s (%s)",
            source_identifier,
            table_metadata_id,
            len(boundary_rows),
            partition_columns,
            decision.reasoning,
        )

    async def _insert_single_partition(self, table_metadata_id: int) -> None:
        """Insert a single virtual partition with NULL bounds (partition_number=1)."""
        await self._bulk_insert_validation_partition_rows(
            table_metadata_id, [(1, None, None, None)]
        )

    async def _bulk_insert_validation_partition_rows(
        self,
        table_metadata_id: int,
        partition_rows: list[tuple[int, Any, Any, int | None]],
    ) -> None:
        """
        Insert one or more PARTITION_METADATA rows.

        Splits the bulk insert into chunked INSERT statements so very large
        partition counts do not exceed Snowflake's per-statement limits.
        """
        if not partition_rows:
            return
        for q in iter_bulk_insert_partition_metadata_sqls(
            data_validation_full_schema(),
            table_metadata_id,
            partition_rows,
            status_column="VALIDATION_STATUS",
            status_sql_literal="'PENDING'",
        ):
            await self.warehouse_proxy.execute_sync_query(q)

    @staticmethod
    def _build_partition_boundary_query(
        tgt_fqn: str,
        columns: list[str],
        num_partitions: int,
        row_count: int,
        target_where_clause: str = "",
    ) -> str:
        """
        Build NTILE partition boundary query against the Snowflake target.

        Large tables (>= SAMPLING_THRESHOLD_ROWS) use ``SAMPLE BERNOULLI`` before
        NTILE (~20M rows, single- and multi-column).
        """
        where_sql = f" WHERE {target_where_clause}" if target_where_clause else ""
        quoted_cols = [quote_identifier(c, force_quote=False) for c in columns]
        use_sampling = row_count >= SAMPLING_THRESHOLD_ROWS
        target_sample_rows = SAMPLING_TARGET_ROWS
        sample_pct = (
            min((target_sample_rows / row_count) * 100, 100.0) if use_sampling else 0.0
        )

        if len(columns) == 1:
            col_sql = quoted_cols[0]
            if use_sampling:
                return (
                    f"WITH sampled AS ("
                    f"SELECT {col_sql} "
                    f"FROM {tgt_fqn} SAMPLE BERNOULLI ({sample_pct:.6f})"
                    f"{where_sql}"
                    f"), "
                    f"partitioned AS ("
                    f"SELECT {col_sql}, "
                    f"NTILE({num_partitions}) OVER (ORDER BY {col_sql}) AS partition_id "
                    f"FROM sampled"
                    f") "
                    f"SELECT partition_id, "
                    f"MIN({col_sql}) AS min_value_in_partition, "
                    f"MAX({col_sql}) AS max_value_in_partition, "
                    f"COUNT(*) AS n_rows "
                    f"FROM partitioned "
                    f"GROUP BY partition_id "
                    f"ORDER BY partition_id"
                )
            return (
                f"WITH partitioned AS ("
                f"SELECT {col_sql}, "
                f"NTILE({num_partitions}) OVER (ORDER BY {col_sql}) AS partition_id "
                f"FROM {tgt_fqn}"
                f"{where_sql}"
                f") "
                f"SELECT partition_id, "
                f"MIN({col_sql}) AS min_value_in_partition, "
                f"MAX({col_sql}) AS max_value_in_partition, "
                f"COUNT(*) AS n_rows "
                f"FROM partitioned "
                f"GROUP BY partition_id "
                f"ORDER BY partition_id"
            )

        order_by = ", ".join(quoted_cols)
        order_by_desc = ", ".join(f"{c} DESC" for c in quoted_cols)
        select_cols = ", ".join(quoted_cols)
        min_select = ", ".join(
            f"MIN(CASE WHEN rn_asc = 1 THEN {c} END) AS min_{i}"
            for i, c in enumerate(quoted_cols)
        )
        max_select = ", ".join(
            f"MAX(CASE WHEN rn_desc = 1 THEN {c} END) AS max_{i}"
            for i, c in enumerate(quoted_cols)
        )
        if use_sampling:
            sampled_cte = (
                f"WITH sampled AS (\n"
                f"    SELECT {select_cols}\n"
                f"    FROM {tgt_fqn} SAMPLE BERNOULLI ({sample_pct:.6f}){where_sql}\n"
                f"),\n"
            )
            partitioned_from = "FROM sampled"
        else:
            sampled_cte = "WITH "
            partitioned_from = f"FROM {tgt_fqn}{where_sql}"

        return f"""
{sampled_cte}partitioned AS (
    SELECT
        {select_cols},
        NTILE({num_partitions}) OVER (ORDER BY {order_by}) AS partition_id
    {partitioned_from}
),
ranked AS (
    SELECT
        {select_cols},
        partition_id,
        ROW_NUMBER() OVER (
            PARTITION BY partition_id ORDER BY {order_by}
        ) AS rn_asc,
        ROW_NUMBER() OVER (
            PARTITION BY partition_id ORDER BY {order_by_desc}
        ) AS rn_desc
    FROM partitioned
)
SELECT
    partition_id,
    {min_select},
    {max_select},
    COUNT(*) AS n_rows
FROM ranked
GROUP BY partition_id
ORDER BY partition_id
""".strip()
