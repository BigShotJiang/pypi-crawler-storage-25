"""
Handler for FINALIZE_HYBRID_L3 tasks.

The hybrid L3 flow has two phases per table:

1. Row-hashing phase (anchor = per-table Evaluate L3): pushes one row-hash
   DEA task per partition that fan in to a per-table Snowpipe drain chain;
   the early-stop poll watches that anchor and may bulk-skip remaining
   partitions once the row-mismatch threshold is met.
2. Cell drill-down phase: the hybrid Evaluate L3 handler queries
   ``ROW_VALIDATION_RESULTS`` for partitions with mismatches and pushes
   one cell DEA task per such partition through a per-table cell
   ``CELL_DIFFS`` Snowpipe drain. ``FinalizeHybridL3`` is the successor of
   that drain (or runs inline when there are no mismatched partitions).

This handler closes out the table by:

- counting cell diffs in ``CELL_VALIDATION_RESULTS`` for the
  ``(workflow_id, table_metadata_id)`` pair;
- setting ``L3_STATUS`` for every partition row of the table via
  :func:`bulk_set_partition_level_status` based on that count;
- updating table validation status via
  ``UPDATE_TABLE_VALIDATION_STATUS``.
"""

from __future__ import annotations

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_validation_cloud.partition_progress import (
    bulk_set_partition_level_status,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    FinalizeHybridL3Payload,
)
from data_migration_orchestrator.data_validation_core.constants import (
    TABLE_STATUS_COMPLETED,
    TABLE_STATUS_FAILED,
    VALIDATION_STATUS_INVALID,
    VALIDATION_STATUS_VALID,
    data_validation_full_schema,
    fq_cell_validation_results,
)


logger = get_logger("dv.finalize_hybrid_l3_handler")


class FinalizeHybridL3Handler:
    """Set L3_STATUS and table status from cell mismatch counts."""

    def __init__(
        self,
        task_queue: BaseTaskQueue,
        warehouse_proxy: Warehouse,
    ) -> None:
        """Initialize with the shared task queue and warehouse proxy."""
        self.task_queue = task_queue
        self.warehouse_proxy = warehouse_proxy

    async def handle(self, task: Task) -> None:
        """Roll up cell diff counts into L3_STATUS + table validation status."""
        payload: FinalizeHybridL3Payload = task.payload
        assert task.id is not None, "Task must have an ID when being handled"

        diff_count = await self._count_cell_diffs(
            payload.workflow_id, payload.table_metadata_id
        )

        l3_partition_status = (
            VALIDATION_STATUS_INVALID if diff_count > 0 else VALIDATION_STATUS_VALID
        )
        await bulk_set_partition_level_status(
            self.warehouse_proxy,
            table_metadata_id=payload.table_metadata_id,
            column="L3_STATUS",
            status=l3_partition_status,
        )

        status = TABLE_STATUS_FAILED if diff_count > 0 else TABLE_STATUS_COMPLETED
        await self.warehouse_proxy.execute_sync_query(
            f"CALL {data_validation_full_schema()}.UPDATE_TABLE_VALIDATION_STATUS("
            f"{payload.table_metadata_id}, '{status}')"
        )

        logger.info(
            "Hybrid L3 finalize for %s (table_metadata_id=%d): %s "
            "(cell diffs=%d, L3_STATUS=%s)",
            payload.source_identifier,
            payload.table_metadata_id,
            status,
            diff_count,
            l3_partition_status,
        )

        await self.task_queue.complete_task(ExecutorType.ORCHESTRATOR, task.id)

    async def _count_cell_diffs(self, workflow_id: int, table_metadata_id: int) -> int:
        sql = (
            f"SELECT COUNT(*) AS DIFF_COUNT FROM {fq_cell_validation_results()} "
            f"WHERE WORKFLOW_ID = {workflow_id} "
            f"AND TABLE_METADATA_ID = {table_metadata_id}"
        )
        rows = await self.warehouse_proxy.execute_sync_query(sql)
        if not rows:
            return 0
        first = rows[0]
        return int(first.get("DIFF_COUNT") or first.get("diff_count") or 0)
