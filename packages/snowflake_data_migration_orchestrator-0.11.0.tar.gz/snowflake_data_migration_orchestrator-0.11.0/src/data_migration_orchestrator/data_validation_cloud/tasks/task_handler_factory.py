"""
Task handler factory for data validation orchestrator tasks.

Creates handlers for DV-specific orchestrator tasks based on payload kind.
"""

from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_validation_cloud.tasks.handlers.evaluate_level_result_handler import (
    EvaluateLevelResultHandler,
)
from data_migration_orchestrator.data_validation_cloud.tasks.handlers.finalize_hybrid_l3_handler import (
    FinalizeHybridL3Handler,
)
from data_migration_orchestrator.data_validation_cloud.tasks.handlers.generate_validation_queries_handler import (
    GenerateValidationQueriesHandler,
)
from data_migration_orchestrator.data_validation_cloud.tasks.handlers.l3_early_stop_poll_handler import (
    L3EarlyStopPollHandler,
)
from data_migration_orchestrator.data_validation_cloud.tasks.handlers.prepare_dv_drain_handler import (
    PrepareDvDrainHandler,
)
from data_migration_orchestrator.data_validation_cloud.tasks.handlers.teardown_dv_snowpipe_handler import (
    TeardownDvSnowpipeHandler,
)
from data_migration_orchestrator.data_validation_cloud.tasks.handlers.write_results_handler import (
    WriteResultsHandler,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload_kind import (
    DataValidationTaskPayloadKind,
)


class DataValidationTaskHandlerFactory:
    """
    Factory for creating data validation task handlers.

    Maps DV task payload kinds to their handler instances.
    Only orchestrator-side DV tasks are registered here.
    """

    def __init__(
        self,
        task_queue: BaseTaskQueue,
        warehouse_proxy: Warehouse,
    ) -> None:
        """
        Initialize the factory with shared resources.

        Args:
            task_queue: Task queue for task operations.
            warehouse_proxy: Warehouse proxy for Snowflake operations.

        """
        self._handlers = {
            DataValidationTaskPayloadKind.GENERATE_VALIDATION_QUERIES: GenerateValidationQueriesHandler(
                task_queue=task_queue,
                warehouse_proxy=warehouse_proxy,
            ),
            DataValidationTaskPayloadKind.EVALUATE_LEVEL_RESULT: EvaluateLevelResultHandler(
                task_queue=task_queue,
                warehouse_proxy=warehouse_proxy,
            ),
            DataValidationTaskPayloadKind.WRITE_VALIDATION_RESULTS: WriteResultsHandler(
                task_queue=task_queue,
                warehouse_proxy=warehouse_proxy,
            ),
            DataValidationTaskPayloadKind.TEARDOWN_DV_SNOWPIPE: TeardownDvSnowpipeHandler(
                task_queue=task_queue,
                warehouse_proxy=warehouse_proxy,
            ),
            DataValidationTaskPayloadKind.PREPARE_DV_DRAIN: PrepareDvDrainHandler(
                task_queue=task_queue,
                warehouse_proxy=warehouse_proxy,
            ),
            DataValidationTaskPayloadKind.DV_L3_EARLY_STOP_POLL: L3EarlyStopPollHandler(
                task_queue=task_queue,
                warehouse_proxy=warehouse_proxy,
            ),
            DataValidationTaskPayloadKind.FINALIZE_HYBRID_L3: FinalizeHybridL3Handler(
                task_queue=task_queue,
                warehouse_proxy=warehouse_proxy,
            ),
        }

    def get_handler(
        self, payload_kind: DataValidationTaskPayloadKind
    ) -> (
        GenerateValidationQueriesHandler
        | EvaluateLevelResultHandler
        | WriteResultsHandler
        | TeardownDvSnowpipeHandler
        | PrepareDvDrainHandler
        | L3EarlyStopPollHandler
        | FinalizeHybridL3Handler
        | None
    ):
        """
        Get a handler for the given payload kind.

        Args:
            payload_kind: The task payload kind enum value.

        Returns:
            The handler instance, or None if not found.

        """
        return self._handlers.get(payload_kind)

    def has_handler(self, payload_kind: DataValidationTaskPayloadKind) -> bool:
        """Check if a handler exists for the given payload kind."""
        return payload_kind in self._handlers
