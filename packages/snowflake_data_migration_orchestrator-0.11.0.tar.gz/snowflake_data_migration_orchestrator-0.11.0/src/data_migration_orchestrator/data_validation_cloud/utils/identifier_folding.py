"""
Identifier folding for schema column names derived from SCHEMA_VALIDATION_RESULTS.

Source engines disagree on default identifier case; this module maps ``source_platform``
to a folding strategy so L2/L3 metadata matches how SDV quotes columns per dialect.
"""

from __future__ import annotations

from enum import StrEnum


class FoldingStrategy(StrEnum):
    """How to normalize a source column name for downstream query generation."""

    NONE = "none"
    LOWER = "lower"
    UPPER = "upper"


_LOWER_FOLD_PLATFORMS: frozenset[str] = frozenset({"redshift", "postgresql", "postgres", "pg"})
_UPPER_FOLD_PLATFORMS: frozenset[str] = frozenset({"teradata", "oracle"})


def folding_strategy_for_source_platform(
    source_platform: str | None,
) -> FoldingStrategy:
    """
    Return identifier folding for a DV source platform string.

    Args:
        source_platform: Raw workflow ``source_platform`` (e.g. ``postgresql``,
            ``PostgreSQL``). None and empty strings fold like unknown dialects.

    Returns:
        ``LOWER`` for Redshift and PostgreSQL family, ``UPPER`` for Teradata
        and Oracle, ``NONE`` for SQL Server and other values.

    """
    sp = (source_platform or "").strip().lower()
    if sp in _LOWER_FOLD_PLATFORMS:
        return FoldingStrategy.LOWER
    if sp in _UPPER_FOLD_PLATFORMS:
        return FoldingStrategy.UPPER
    return FoldingStrategy.NONE


def apply_identifier_folding(identifier: str, strategy: FoldingStrategy) -> str:
    """Apply *strategy* to *identifier* (no-op when strategy is ``NONE``)."""
    if strategy is FoldingStrategy.LOWER:
        return identifier.lower()
    if strategy is FoldingStrategy.UPPER:
        return identifier.upper()
    return identifier
