"""
Lazy, idempotent provisioning of per-table DV result Snowpipes.

DV pipes are **temporary and per workflow table**: each
``(workflow_id, table_metadata_id, key)`` gets its own pipe in the shared
``TEMP`` schema. The first call to :func:`ensure_dv_pipe` for a given triple:

1. Synchronously runs ``CREATE PIPE IF NOT EXISTS`` against the
   warehouse, so the pipe demonstrably exists before this coroutine
   returns. This is required for the ordering contract that callers
   rely on: any DEA task pushed by the caller after this returns is
   guaranteed to find the pipe when it later issues
   ``ALTER PIPE ... REFRESH PREFIX='...'``. Modeling Setup as a queued
   task instead would race against DEA workers that pull the
   refresh task before the (still-queued) Setup task runs.
2. Pushes a ``TEARDOWN_DV_SNOWPIPE`` cleanup task that will
   ``DROP PIPE IF EXISTS`` once every non-cleanup task in the workflow
   has terminated (even on failure, because ``.blocked().cleanup()``
   runs the teardown in the cleanup phase).

Both DDL statements are idempotent (``IF NOT EXISTS`` / ``IF EXISTS``),
so cross-process duplicates are harmless. A process-local cache keyed
by ``(workflow_id, table_metadata_id, key)`` short-circuits repeat calls within the same
orchestrator process. The cache is protected by a ``threading.Lock``
because orchestrator worker threads each run their own ``asyncio``
event loop (via ``asyncio.run(...)`` per task), so the synchronization
primitive must be OS-thread-safe rather than tied to a single event
loop.
"""

from __future__ import annotations

import threading

from data_migration_orchestrator.cloud_core.constants.priorities import (
    DEFAULT_PRIORITY,
)
from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task_builder import TaskBuilder
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_validation_cloud.scope import (
    ValidationScopeOperation,
    build_dv_snowpipe_scope,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    TeardownDvSnowpipePayload,
)
from data_migration_orchestrator.data_validation_cloud.utils.pipe_utils import (
    DvResultsPipeKey,
    build_create_pipe_sql,
    build_dv_pipe_name,
)


logger = get_logger("dv.ensure_dv_pipe")


_ensured_pairs: set[tuple[int, int, DvResultsPipeKey]] = set()
_cache_lock = threading.Lock()


async def ensure_dv_pipe(
    task_queue: BaseTaskQueue,
    warehouse: Warehouse,
    workflow_id: int,
    table_metadata_id: int,
    key: DvResultsPipeKey,
) -> str:
    """
    Ensure the per-table DV pipe for ``key`` exists and queue its teardown.

    On first call in this process for ``(workflow_id, table_metadata_id, key)``
    the function synchronously runs ``CREATE PIPE IF NOT EXISTS`` and pushes a
    ``TEARDOWN_DV_SNOWPIPE`` cleanup task. Subsequent calls short-circuit
    via the process-local cache.

    Args:
        task_queue: Queue used to push the Teardown task.
        warehouse: Warehouse used to run the synchronous ``CREATE PIPE``.
        workflow_id: Owning workflow id (also baked into the pipe name
            and PATTERN).
        table_metadata_id: Table metadata id (pipe name and PATTERN).
        key: Logical results-pipe identifier.

    Returns:
        The fully qualified pipe name (suitable for
        ``ALTER PIPE <name> REFRESH PREFIX='...'``).

    """
    pipe_name = build_dv_pipe_name(workflow_id, table_metadata_id, key)
    cache_key = (workflow_id, table_metadata_id, key)

    if cache_key in _ensured_pairs:
        return pipe_name

    with _cache_lock:
        if cache_key in _ensured_pairs:
            return pipe_name
        _ensured_pairs.add(cache_key)

    try:
        logger.info(
            "Provisioning DV Snowpipe %s (workflow=%d, table_metadata_id=%d, key=%s)",
            pipe_name,
            workflow_id,
            table_metadata_id,
            key.value,
        )

        await warehouse.execute_sync_query(
            build_create_pipe_sql(workflow_id, table_metadata_id, pipe_name, key)
        )

        pipe_scope_key = f"{table_metadata_id}.{key.value}"
        teardown_scope = build_dv_snowpipe_scope(
            workflow_id, pipe_scope_key, ValidationScopeOperation.SNOWPIPE_TEARDOWN
        )
        teardown_task = (
            TaskBuilder(
                workflow_id=workflow_id,
                task_name=f"Teardown DV Snowpipe: {table_metadata_id}/{key.value}",
                executor_type=ExecutorType.ORCHESTRATOR,
                payload=TeardownDvSnowpipePayload(
                    workflow_id=workflow_id,
                    pipe_name=pipe_name,
                ),
                scope=teardown_scope,
            )
            .with_priority(DEFAULT_PRIORITY)
            .blocked()
            .cleanup()
            .build()
        )
        await task_queue.push_task(teardown_task)
    except BaseException:
        with _cache_lock:
            _ensured_pairs.discard(cache_key)
        raise

    return pipe_name


def _reset_cache_for_tests() -> None:
    """Clear the process-local cache. Intended for unit tests only."""
    with _cache_lock:
        _ensured_pairs.clear()
