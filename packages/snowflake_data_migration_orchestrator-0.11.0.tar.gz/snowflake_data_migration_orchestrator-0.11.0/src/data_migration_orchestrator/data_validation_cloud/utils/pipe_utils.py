"""
Snowpipe identifier/SQL helpers for data validation result ingestion.

DV results land in a fixed set of shared tables (``METRICS_VALIDATION_RESULTS``,
``ROW_VALIDATION_RESULTS``, ``ROW_VALIDATION_SUMMARY``, ``CHUNK_HASHES``,
``CELL_VALIDATION_RESULTS``) in the validation schema. Ingestion goes through
one Snowpipe per :class:`DvResultsPipeKey` per **table** (per ``table_metadata_id``)
within a workflow.

Lifecycle:
    * Pipes are **temporary and per-workflow per table**. They live in the shared
      ``TEMP`` schema under the name
      ``DVO_PIPE_<WORKFLOW_ID>_<TABLE_METADATA_ID>_<KEY>`` and are explicitly
      created on first use and dropped by a Teardown cleanup task at the end.
      Concurrent workflows never share a pipe; concurrent tables in the same
      workflow each get their own pipes so ``SYSTEM$PIPE_STATUS`` is a reliable
      drain signal per table.
    * ``ensure_dv_pipe`` is the single entrypoint that pushes the
      Setup+Teardown pair for a ``(workflow_id, table_metadata_id, key)``
      lazily on first use.

Refresh semantics:
    Each pipe's ``FROM`` clause watches the whole DV task-results stage
    root. The ``PATTERN`` regex narrows ingestion to this workflow and
    table (``<workflow_id>/<table_metadata_id>/<level>/p<partition>/<subdir>/``),
    and each :func:`ALTER PIPE ... REFRESH PREFIX='...'` call issued by
    the DEA further limits the refresh to the partition's sub-prefix.
"""

from __future__ import annotations

from enum import StrEnum

from data_migration_orchestrator.cloud_core.utils.pipe_utils import (
    build_drop_pipe_sql as _shared_build_drop_pipe_sql,
)
from data_migration_orchestrator.data_validation_cloud.constants.stages import (
    default_internal_stage,
)
from data_migration_orchestrator.data_validation_core.constants import (
    fq_cell_validation_results,
    fq_chunk_hashes,
    fq_metrics_validation_results,
    fq_row_validation_results,
    fq_row_validation_summary,
    validation_csv_file_format_fqn,
)
from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_temp_schema,
)


class DvResultsPipeKey(StrEnum):
    """Logical identifier for a DV results Snowpipe."""

    METRICS = "METRICS"
    ROW_DIFFS = "ROW_DIFFS"
    ROW_SUMMARY = "ROW_SUMMARY"
    CHUNK_HASHES = "CHUNK_HASHES"
    CELL_DIFFS = "CELL_DIFFS"


def build_dv_pipe_name(
    workflow_id: int, table_metadata_id: int, key: DvResultsPipeKey
) -> str:
    """
    Build the fully qualified Snowpipe name for ``key`` and ``table_metadata_id``.

    The pipe lives in the shared ``TEMP`` schema. The name embeds
    ``workflow_id`` and ``table_metadata_id`` so concurrent workflows and
    sibling tables in the same workflow never share a Snowpipe. Names are
    upper-cased so they match Snowflake's stored identifier casing.
    """
    return (
        f"{qualified_temp_schema()}.DVO_PIPE_{workflow_id}_"
        f"{table_metadata_id}_{key.value}"
    ).upper()


def build_dv_stage_prefix(
    workflow_id: int,
    table_metadata_id: int,
    level: str,
    partition_number: int | None,
) -> str:
    """
    Build the stage prefix (without leading ``@``) used in ``ALTER PIPE REFRESH``.

    The prefix is relative to each pipe's ``FROM`` location, which is the
    DV task-results stage root (see :func:`_stage_root`). It mirrors the
    directory layout produced by :meth:`DEAPayloadFactory.stage_path`, so
    one ``REFRESH PREFIX=`` call enqueues every relevant file for that
    partition across all pipes that match the ``PATTERN``.
    """
    base = f"{workflow_id}/{table_metadata_id}/{level}"
    if partition_number is not None:
        base = f"{base}/p{partition_number}"
    return f"{base}/"


def _stage_root() -> str:
    """Return the stage root (no workflow_id) that every DV pipe watches."""
    return default_internal_stage()


def _pattern_for_key(
    workflow_id: int, table_metadata_id: int, key: DvResultsPipeKey
) -> str:
    """
    Build the per-key PATTERN regex, scoped to one workflow and table.

    The leading ``(.*/)?`` group is required because Snowpipe applies the
    PATTERN regex to two slightly different path representations during a
    single load:

    * ``ALTER PIPE ... REFRESH`` matches the regex against the path
      *including* the lowercased stage name as a leading segment
      (e.g. ``task_results/<wfid>/<tmid>/cell/p<N>/diffs/file.csv.gz``).
    * Subsequent ingestion matches the regex against the path *without*
      that prefix (e.g. ``<wfid>/<tmid>/cell/p<N>/diffs/file.csv.gz``).

    A regex that requires a slash before ``<wfid>`` (e.g. ``.*/<wfid>/...``)
    matches the REFRESH path but silently fails the ingestion match, so
    files end up reported as ``SENT`` by REFRESH but never load. Making
    the leading prefix optional with ``(.*/)?`` matches both shapes.
    """
    prefix = rf"(.*/)?{workflow_id}/{table_metadata_id}"
    if key is DvResultsPipeKey.METRICS:
        return prefix + r"/metrics/p[0-9]+/.*"
    if key is DvResultsPipeKey.ROW_DIFFS:
        return prefix + r"/row/p[0-9]+/diffs/.*"
    if key is DvResultsPipeKey.ROW_SUMMARY:
        return prefix + r"/row/p[0-9]+/summary/.*"
    if key is DvResultsPipeKey.CHUNK_HASHES:
        return prefix + r"/row/p[0-9]+/hashes/.*"
    if key is DvResultsPipeKey.CELL_DIFFS:
        return prefix + r"/cell/p[0-9]+/diffs/.*"
    raise ValueError(f"Unknown DV results pipe key: {key}")


_FILENAME_PARTITION_EXPR = (
    "TRY_CAST("
    "REGEXP_SUBSTR(METADATA$FILENAME, '/p([0-9]+)/', 1, 1, 'e', 1) "
    "AS INT)"
)


def _metrics_pipe_sql(pipe_name: str, stage_root: str, pattern: str) -> str:
    return (
        f"CREATE PIPE IF NOT EXISTS {pipe_name} AS "
        f"COPY INTO {fq_metrics_validation_results()} "
        f"(WORKFLOW_ID, TABLE_METADATA_ID, PARTITION_NUMBER, VALIDATION_TYPE, "
        f"TABLE_NAME, COLUMN_VALIDATED, EVALUATION_CRITERIA, SOURCE_VALUE, "
        f"SNOWFLAKE_VALUE, STATUS, COMMENTS) "
        f"FROM (SELECT $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11 "
        f"FROM '{stage_root}/') "
        f"PATTERN = '{pattern}' "
        f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
        f"ON_ERROR = 'CONTINUE'"
    )


def _row_diffs_pipe_sql(pipe_name: str, stage_root: str, pattern: str) -> str:
    return (
        f"CREATE PIPE IF NOT EXISTS {pipe_name} AS "
        f"COPY INTO {fq_row_validation_results()} "
        f"(WORKFLOW_ID, TABLE_METADATA_ID, TABLE_NAME, OBJECT_TYPE, RESULT, "
        f"SOURCE_INDEX_VALUES, TARGET_INDEX_VALUES, TARGET_TABLE_NAME, "
        f"PARTITION_NUMBER) "
        f"FROM (SELECT $1, $2, $3, $4, $5, $6, $7, $8, "
        f"{_FILENAME_PARTITION_EXPR} "
        f"FROM '{stage_root}/') "
        f"PATTERN = '{pattern}' "
        f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
        f"ON_ERROR = 'CONTINUE'"
    )


def _row_summary_pipe_sql(pipe_name: str, stage_root: str, pattern: str) -> str:
    return (
        f"CREATE PIPE IF NOT EXISTS {pipe_name} AS "
        f"COPY INTO {fq_row_validation_summary()} "
        f"(WORKFLOW_ID, TABLE_METADATA_ID, TABLE_NAME, TOTAL_CHUNKS, "
        f"MATCHING_CHUNKS, DIFFERING_CHUNKS, TOTAL_ROWS_COMPARED, "
        f"ROWS_NOT_FOUND_IN_TARGET, ROWS_NOT_FOUND_IN_SOURCE, "
        f"ROWS_WITH_DIFFERENCES, IS_VALID) "
        f"FROM (SELECT $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11 "
        f"FROM '{stage_root}/') "
        f"PATTERN = '{pattern}' "
        f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
        f"ON_ERROR = 'CONTINUE'"
    )


def _chunk_hashes_pipe_sql(pipe_name: str, stage_root: str, pattern: str) -> str:
    return (
        f"CREATE PIPE IF NOT EXISTS {pipe_name} AS "
        f"COPY INTO {fq_chunk_hashes()} "
        f"(WORKFLOW_ID, TABLE_METADATA_ID, TABLE_NAME, CHUNK_ID, "
        f"SOURCE_HASH, TARGET_HASH, IS_MATCH) "
        f"FROM (SELECT $1, $2, $3, $4, $5, $6, $7 "
        f"FROM '{stage_root}/') "
        f"PATTERN = '{pattern}' "
        f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
        f"ON_ERROR = 'CONTINUE'"
    )


def _cell_diffs_pipe_sql(pipe_name: str, stage_root: str, pattern: str) -> str:
    return (
        f"CREATE PIPE IF NOT EXISTS {pipe_name} AS "
        f"COPY INTO {fq_cell_validation_results()} "
        f"(WORKFLOW_ID, TABLE_METADATA_ID, TABLE_NAME, "
        f"ROW_INDEX, COLUMN_NAME, SOURCE_VALUE, TARGET_VALUE) "
        f"FROM (SELECT $1, $2, $3, $4, $5, $6, $7 "
        f"FROM '{stage_root}/') "
        f"PATTERN = '{pattern}' "
        f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
        f"ON_ERROR = 'CONTINUE'"
    )


_BUILDERS = {
    DvResultsPipeKey.METRICS: _metrics_pipe_sql,
    DvResultsPipeKey.ROW_DIFFS: _row_diffs_pipe_sql,
    DvResultsPipeKey.ROW_SUMMARY: _row_summary_pipe_sql,
    DvResultsPipeKey.CHUNK_HASHES: _chunk_hashes_pipe_sql,
    DvResultsPipeKey.CELL_DIFFS: _cell_diffs_pipe_sql,
}


def build_create_pipe_sql(
    workflow_id: int,
    table_metadata_id: int,
    pipe_name: str,
    key: DvResultsPipeKey,
) -> str:
    """
    Build the idempotent ``CREATE PIPE IF NOT EXISTS`` SQL for ``key``.

    The generated statement's ``FROM`` watches the whole DV stage root so
    the pipe survives workflow re-runs even if the stage layout shifts,
    but its ``PATTERN`` is narrowed to this workflow and table so files
    from other workflows or tables are not ingested.
    """
    pattern = _pattern_for_key(workflow_id, table_metadata_id, key)
    return _BUILDERS[key](pipe_name, _stage_root(), pattern)


def build_drop_pipe_sql(pipe_name: str) -> str:
    """Thin wrapper around the shared ``DROP PIPE IF EXISTS`` helper."""
    return _shared_build_drop_pipe_sql(pipe_name)
