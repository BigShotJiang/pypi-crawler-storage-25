"""Shared partition WHERE clause building for data validation."""

from __future__ import annotations

from typing import Any

from data_migration_orchestrator.data_migration_cloud.partition.partition_range import (
    apply_column_name_mappings,
)
from data_migration_orchestrator.data_migration_cloud.platforms.platform_registry import (
    PlatformRegistry,
)
from data_migration_orchestrator.data_migration_cloud.platforms.snowflake.query_builder import (
    build_snowflake_partition_condition,
)


def max_interior_partition_number(
    partitions: list[dict],
    *,
    min_key: str = "MIN_VALUE",
    max_key: str = "MAX_VALUE",
    number_key: str = "PARTITION_NUMBER",
) -> int | None:
    """Largest partition number that has both min and max bounds (interior bucket)."""
    interior: list[int] = []
    for row in partitions:
        pnum = row.get(number_key) or row.get(number_key.lower())
        if pnum is None:
            continue
        mn = row.get(min_key) or row.get(min_key.lower())
        mx = row.get(max_key) or row.get(max_key.lower())
        if mn is not None and mx is not None:
            interior.append(int(pnum))
    return max(interior) if interior else None


def build_scoped_partition_where(
    user_where: str,
    partition_columns: list[str],
    min_value: Any,
    max_value: Any,
    source_platform: str,
    *,
    target_side: bool,
    upper_inclusive: bool = False,
    column_name_mappings: dict[str, str] | None = None,
) -> str:
    """
    Combine a user WHERE clause with a partition range condition.

    Uses the same lexicographic interval semantics as data migration.
    """
    if not partition_columns or (min_value is None and max_value is None):
        return user_where

    columns = apply_column_name_mappings(
        partition_columns,
        column_name_mappings or {},
    )

    if target_side:
        range_clause = build_snowflake_partition_condition(
            columns,
            min_value,
            max_value,
            upper_inclusive=upper_inclusive,
        )
    else:
        try:
            platform = PlatformRegistry.create_by_name_or_alias(source_platform)
            range_clause = platform.query_builder.build_partition_condition(
                columns,
                min_value,
                max_value,
                upper_inclusive=upper_inclusive,
            )
        except (KeyError, ValueError):
            range_clause = build_snowflake_partition_condition(
                columns,
                min_value,
                max_value,
                upper_inclusive=upper_inclusive,
            )

    if range_clause == "1=1":
        return user_where

    if user_where:
        return f"({user_where}) AND {range_clause}"
    return range_clause
