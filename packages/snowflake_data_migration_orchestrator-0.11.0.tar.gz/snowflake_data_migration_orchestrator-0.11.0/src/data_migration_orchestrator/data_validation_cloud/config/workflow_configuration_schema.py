"""
Pydantic schema for structural validation of data validation workflow configurations.

Validates the raw JSON config dict before the ValidationConfigurationParser
performs semantic validation and builds domain objects.
"""

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from data_migration_orchestrator.data_validation_cloud.config.validation_custom_templates import (
    CustomMetricsConfig,
    CustomNormalizationsConfig,
    CustomTypesConfig,
)
from data_migration_orchestrator.data_validation_core.constants import (
    RowValidationMode,
)


class ValidationLevelSchema(BaseModel):
    """Schema for the validation_configuration block."""

    model_config = ConfigDict(extra="forbid")

    schema_validation: bool | None = None
    metrics_validation: bool | None = None
    row_validation: bool | None = None
    row_validation_mode: str | None = None
    continue_on_failure: bool | None = None
    max_failed_rows_number: int | None = Field(
        default=None,
        gt=0,
        description=(
            "Caps L3 cell-level diff rows. In hybrid mode, limits phase-2 drill-down "
            "output; it does not skip cell validation after MD5 failures."
        ),
    )
    exclude_metrics: bool | None = None
    apply_metric_column_modifier: bool | None = None
    max_columns_per_metrics_batch: int | None = Field(default=None, gt=0)
    early_stopping: bool | None = Field(
        default=None,
        description="When true, L3 may stop early once enough mismatch rows are ingested.",
    )
    early_stop_mismatch_row_threshold: int | None = Field(
        default=None,
        gt=0,
        description="Ingested diff-row count at or above which pending L3 work is skipped.",
    )
    early_stop_check_interval_minutes: int | None = Field(
        default=None,
        gt=0,
        description="Minimum minutes between L3 early-stop poll orchestrator ticks.",
    )

    @field_validator("row_validation_mode")
    @classmethod
    def validate_row_validation_mode(cls, v: str | None) -> str | None:
        """Validate row_validation_mode is one of the supported values."""
        if v is not None:
            valid = {m.value for m in RowValidationMode}
            if v not in valid:
                raise ValueError(
                    f"row_validation_mode must be one of {valid}, got '{v}'"
                )
        return v


class ComparisonSchema(BaseModel):
    """Schema for the comparison_configuration block."""

    model_config = ConfigDict(extra="forbid")

    tolerance: float | None = Field(default=None, gt=0)
    type_mapping_file_path: str | None = None


class TableSchema(BaseModel):
    """Schema for a single table configuration entry."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    fully_qualified_name: str = Field(alias="fullyQualifiedName")
    use_column_selection_as_exclude_list: bool = Field(
        default=False, alias="useColumnSelectionAsExcludeList"
    )
    column_selection_list: list[str] = Field(
        default_factory=list, alias="columnSelectionList"
    )
    target_name: str | None = Field(default=None, alias="targetName")
    target_database: str | None = Field(default=None, alias="targetDatabase")
    target_schema: str | None = Field(default=None, alias="targetSchema")
    where_clause: str | None = Field(default=None, alias="whereClause")
    target_where_clause: str | None = Field(default=None, alias="targetWhereClause")
    index_column_list: list[str] | None = Field(default=None, alias="indexColumnList")
    target_index_column_list: list[str] | None = Field(
        default=None, alias="targetIndexColumnList"
    )
    column_mappings: dict[str, str] | None = Field(default=None, alias="columnMappings")
    is_case_sensitive: bool | None = Field(default=None, alias="isCaseSensitive")
    max_failed_rows_number: int | None = Field(
        default=None, gt=0, alias="maxFailedRowsNumber"
    )
    exclude_metrics: bool | None = Field(default=None, alias="excludeMetrics")
    apply_metric_column_modifier: bool | None = Field(
        default=None, alias="applyMetricColumnModifier"
    )
    max_columns_per_metrics_batch: int | None = Field(
        default=None, gt=0, alias="maxColumnsPerMetricsBatch"
    )
    max_columns_per_cell_batch: int | None = Field(
        default=None, gt=0, alias="maxColumnsPerCellBatch"
    )
    object_type: str | None = Field(default=None, alias="objectType")
    column_names_to_partition_by: list[str] | None = Field(
        default=None, alias="columnNamesToPartitionBy"
    )
    target_partition_size_rows: int | None = Field(
        default=None, gt=0, alias="targetPartitionSizeRows"
    )
    target_partition_size_mb: int | None = Field(
        default=None, gt=0, alias="targetPartitionSizeMb"
    )
    validation_configuration: ValidationLevelSchema | None = Field(
        default=None, alias="validationConfiguration"
    )

    @model_validator(mode="after")
    def _mutually_exclusive_partition_targets(self) -> "TableSchema":
        """Ensure targetPartitionSizeRows and targetPartitionSizeMb are not both set."""
        if (
            self.target_partition_size_rows is not None
            and self.target_partition_size_mb is not None
        ):
            raise ValueError(
                "Only one of 'targetPartitionSizeRows' or "
                "'targetPartitionSizeMb' may be specified per table"
            )
        return self

    @field_validator("use_column_selection_as_exclude_list", mode="before")
    @classmethod
    def _coerce_null_exclude_list_flag(cls, v: object) -> object:
        """Treat explicit null as the default (False)."""
        return False if v is None else v

    @field_validator("column_selection_list", mode="before")
    @classmethod
    def _coerce_null_column_selection(cls, v: object) -> object:
        """Treat explicit null as an empty list."""
        return [] if v is None else v


class DataValidationWorkflowConfigurationSchema(BaseModel):
    """
    Top-level schema for a Data Validation Workflow configuration.

    Aligned with SDV ConfigurationModel fields, minus connection/output fields.
    """

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    source_platform: str = Field(alias="sourcePlatform")
    target_platform: str = Field(default="Snowflake", alias="targetPlatform")
    target_database: str | None = Field(default=None, alias="targetDatabase")
    validation_configuration: ValidationLevelSchema | None = Field(
        default=None, alias="validationConfiguration"
    )
    comparison_configuration: ComparisonSchema | None = Field(
        default=None, alias="comparisonConfiguration"
    )
    database_mappings: dict[str, str] | None = Field(
        default=None, alias="databaseMappings"
    )
    schema_mappings: dict[str, str] | None = Field(default=None, alias="schemaMappings")
    tables: list[TableSchema]
    views: list[TableSchema] | None = None
    affinity: str | None = None
    use_snowflake_compute: bool = Field(default=False, alias="useSnowflakeCompute")
    use_snowpipe_for_results: bool = True
    target_partition_size_rows: int | None = Field(
        default=None, gt=0, alias="targetPartitionSizeRows"
    )
    target_partition_size_mb: int | None = Field(
        default=None, gt=0, alias="targetPartitionSizeMb"
    )
    validation_custom_types: CustomTypesConfig = Field(
        default_factory=CustomTypesConfig, alias="validationCustomTypes"
    )
    validation_custom_metrics: CustomMetricsConfig = Field(
        default_factory=CustomMetricsConfig, alias="validationCustomMetrics"
    )
    validation_custom_normalizations: CustomNormalizationsConfig = Field(
        default_factory=CustomNormalizationsConfig,
        alias="validationCustomNormalizations",
    )

    @model_validator(mode="after")
    def _mutually_exclusive_partition_targets(
        self,
    ) -> "DataValidationWorkflowConfigurationSchema":
        """Ensure targetPartitionSizeRows and targetPartitionSizeMb are not both set."""
        if (
            self.target_partition_size_rows is not None
            and self.target_partition_size_mb is not None
        ):
            raise ValueError(
                "Only one of 'targetPartitionSizeRows' or "
                "'targetPartitionSizeMb' may be specified at the global level"
            )
        return self

    @field_validator("use_snowflake_compute", mode="before")
    @classmethod
    def _coerce_null_snowflake_compute(cls, v: object) -> object:
        """Treat explicit null as the default (False)."""
        return False if v is None else v

    @field_validator("use_snowpipe_for_results", mode="before")
    @classmethod
    def _coerce_null_use_snowpipe_for_results(cls, v: object) -> object:
        """Treat explicit null as the default (True)."""
        return True if v is None else v

    @field_validator("tables")
    @classmethod
    def tables_must_not_be_empty(cls, v: list[TableSchema]) -> list[TableSchema]:
        """Ensure at least one table is configured."""
        if len(v) == 0:
            raise ValueError("'tables' must contain at least one table configuration")
        return v


def validate_data_validation_workflow_configuration(
    configuration: dict | None,
) -> DataValidationWorkflowConfigurationSchema:
    """
    Validate a raw data validation workflow configuration dict.

    Args:
        configuration: Raw config dict from the workflow, or None.

    Returns:
        Validated schema model.

    Raises:
        ValueError: If configuration is None or structurally invalid.

    """
    if configuration is None:
        raise ValueError("Workflow configuration must not be None")

    return DataValidationWorkflowConfigurationSchema.model_validate(configuration)
