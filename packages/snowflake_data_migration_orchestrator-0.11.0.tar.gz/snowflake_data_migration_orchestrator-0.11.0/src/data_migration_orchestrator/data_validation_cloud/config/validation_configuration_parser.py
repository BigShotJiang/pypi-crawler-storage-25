"""
Parser for data validation workflow configurations.

Converts raw JSON config dicts into typed ValidationTableConfiguration objects
and resolves global defaults.
"""

from __future__ import annotations

from typing import cast

from snowflake.snowflake_data_validation.public import CustomTypesConfig

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.data_validation_cloud.config import (
    configuration_properties_keys as keys,
)
from data_migration_orchestrator.data_validation_cloud.config.validation_table_configuration import (
    ValidationTableConfiguration,
)
from data_migration_orchestrator.data_validation_cloud.config.workflow_configuration_schema import (
    TableSchema,
    validate_data_validation_workflow_configuration,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.custom_template_overrides import (
    CustomTemplateOverrides,
    WorkflowCustomMetricsList,
    WorkflowCustomNormalizationsList,
)
from data_migration_orchestrator.data_validation_core.constants import (
    RowValidationMode,
)
from shared.enums.source_type import SourceType
from shared.identifiers.fqn import normalize_oracle_fully_qualified_name


logger = get_logger("data_validation.configuration_parser")

DEFAULT_TOLERANCE = 0.001
DEFAULT_MAX_FAILED_ROWS = 100


class ValidationConfigurationError(Exception):
    """Raised when data validation configuration is invalid."""


class ValidationConfigurationParser:
    """
    Parse and validate data validation workflow configurations.

    Converts raw JSON configuration dicts into strongly-typed objects suitable
    for the orchestrator and DEA.
    """

    def __init__(self, raw_config: dict) -> None:
        """
        Initialize the parser by validating the raw configuration.

        Args:
            raw_config: Raw JSON configuration dictionary from the workflow.

        """
        self._schema = validate_data_validation_workflow_configuration(raw_config)
        self._raw = raw_config

    @property
    def source_platform(self) -> str:
        """Return the source platform identifier."""
        return self._schema.source_platform

    @property
    def target_platform(self) -> str:
        """Return the target platform identifier."""
        return self._schema.target_platform

    @property
    def target_database(self) -> str | None:
        """Return the default target database, if set."""
        return self._schema.target_database

    @property
    def affinity(self) -> str | None:
        """Return the task affinity group, if set."""
        return self._schema.affinity

    @property
    def use_snowflake_compute(self) -> bool:
        """Return whether Snowflake-side computation is enabled."""
        return self._schema.use_snowflake_compute

    @property
    def use_snowpipe_for_results(self) -> bool:
        """Return whether L2/L3 result ingestion should use Snowpipe (default True)."""
        return self._schema.use_snowpipe_for_results

    @property
    def tolerance(self) -> float:
        """Return the numeric comparison tolerance for metrics validation."""
        if (
            self._schema.comparison_configuration
            and self._schema.comparison_configuration.tolerance
        ):
            return self._schema.comparison_configuration.tolerance
        return DEFAULT_TOLERANCE

    @property
    def type_mapping_file_path(self) -> str | None:
        """Return the path to the type mapping file, if configured."""
        if self._schema.comparison_configuration:
            return self._schema.comparison_configuration.type_mapping_file_path
        return None

    @property
    def database_mappings(self) -> dict[str, str]:
        """Return source-to-target database name mappings."""
        return self._schema.database_mappings or {}

    @property
    def schema_mappings(self) -> dict[str, str]:
        """Return source-to-target schema name mappings."""
        return self._schema.schema_mappings or {}

    @property
    def schema_validation_enabled(self) -> bool:
        """Return whether L1 schema validation is enabled globally."""
        vc = self._schema.validation_configuration
        if vc and vc.schema_validation is not None:
            return vc.schema_validation
        return True

    @property
    def metrics_validation_enabled(self) -> bool:
        """Return whether L2 metrics validation is enabled globally."""
        vc = self._schema.validation_configuration
        if vc and vc.metrics_validation is not None:
            return vc.metrics_validation
        return True

    @property
    def row_validation_enabled(self) -> bool:
        """Return whether L3 row validation is enabled globally."""
        vc = self._schema.validation_configuration
        if vc and vc.row_validation is not None:
            return vc.row_validation
        return False

    @property
    def row_validation_mode(self) -> RowValidationMode:
        """Return the L3 row validation mode (row, cell, or hybrid)."""
        vc = self._schema.validation_configuration
        if vc and vc.row_validation_mode is not None:
            return RowValidationMode(vc.row_validation_mode)
        return RowValidationMode.ROW

    @property
    def continue_on_failure(self) -> bool:
        """Return whether validation should continue to the next level on failure."""
        vc = self._schema.validation_configuration
        if vc and vc.continue_on_failure is not None:
            return vc.continue_on_failure
        return False

    @property
    def max_failed_rows_number(self) -> int:
        """Return the maximum number of failed rows to report in L3 validation."""
        vc = self._schema.validation_configuration
        if vc and vc.max_failed_rows_number is not None:
            return vc.max_failed_rows_number
        return DEFAULT_MAX_FAILED_ROWS

    @property
    def target_partition_size_rows(self) -> int | None:
        """Return the global target partition size in rows, if set."""
        return self._schema.target_partition_size_rows

    @property
    def target_partition_size_mb(self) -> int | None:
        """Return the global target partition size in MB, if set."""
        return self._schema.target_partition_size_mb

    @property
    def exclude_metrics(self) -> bool:
        """Return whether to exclude unsupported metric columns globally."""
        vc = self._schema.validation_configuration
        if vc and vc.exclude_metrics is not None:
            return vc.exclude_metrics
        return False

    @property
    def apply_metric_column_modifier(self) -> bool:
        """Return whether to apply metric column modifiers globally."""
        vc = self._schema.validation_configuration
        if vc and vc.apply_metric_column_modifier is not None:
            return vc.apply_metric_column_modifier
        return True

    @property
    def max_columns_per_metrics_batch(self) -> int | None:
        """Return the global max columns per metrics batch, if set."""
        vc = self._schema.validation_configuration
        if vc and vc.max_columns_per_metrics_batch is not None:
            return vc.max_columns_per_metrics_batch
        return None

    @property
    def validation_custom_types_source(self) -> CustomTypesConfig:
        """Return source custom datatype mappings."""
        return self._schema.validation_custom_types.source

    @property
    def validation_custom_metrics_source(self) -> WorkflowCustomMetricsList:
        """Return source custom metrics configurations as dicts for serialization."""
        return cast(
            WorkflowCustomMetricsList,
            [m.model_dump() for m in self._schema.validation_custom_metrics.source],
        )

    @property
    def validation_custom_metrics_target(self) -> WorkflowCustomMetricsList:
        """Return target custom metrics configurations as dicts for serialization."""
        return cast(
            WorkflowCustomMetricsList,
            [m.model_dump() for m in self._schema.validation_custom_metrics.target],
        )

    @property
    def validation_custom_normalizations_source(
        self,
    ) -> WorkflowCustomNormalizationsList:
        """Return source custom normalization mappings."""
        return self._schema.validation_custom_normalizations.source

    @property
    def validation_custom_normalizations_target(
        self,
    ) -> WorkflowCustomNormalizationsList:
        """Return target custom normalization mappings."""
        return self._schema.validation_custom_normalizations.target

    @property
    def custom_overrides(self) -> CustomTemplateOverrides | None:
        """
        Return a CustomTemplateOverrides instance with all custom configurations.

        Returns None if no custom overrides are defined.
        """
        vc = self._schema.validation_custom_types
        vm = self._schema.validation_custom_metrics
        vn = self._schema.validation_custom_normalizations

        types_src = vc if vc.source else None
        metrics_src = [m.model_dump() for m in vm.source] if vm.source else None
        metrics_tgt = [m.model_dump() for m in vm.target] if vm.target else None
        norms_src = vn.source if vn.source else None
        norms_tgt = vn.target if vn.target else None

        if not any([types_src, metrics_src, metrics_tgt, norms_src, norms_tgt]):
            return None

        return CustomTemplateOverrides(
            custom_types_source=types_src,
            custom_metrics_source=metrics_src,
            custom_metrics_target=metrics_tgt,
            custom_normalizations_source=norms_src,
            custom_normalizations_target=norms_tgt,
        )

    def parse_tables(self) -> list[ValidationTableConfiguration]:
        """Parse all table configurations with global defaults applied."""
        tables: list[ValidationTableConfiguration] = []
        for table_schema in self._schema.tables:
            tables.append(self._parse_table(table_schema, object_type="TABLE"))

        if self._schema.views:
            for view_schema in self._schema.views:
                tables.append(self._parse_table(view_schema, object_type="VIEW"))

        return tables

    def _normalize_oracle_fully_qualified_name(self, fqn: str) -> str:
        """
        Return canonical ``SCHEMA.TABLE`` for Oracle workflow config.

        Delegates to :func:`shared.identifiers.fqn.normalize_oracle_fully_qualified_name`.
        """
        try:
            return normalize_oracle_fully_qualified_name(fqn)
        except ValueError as exc:
            raise ValidationConfigurationError(str(exc)) from exc

    def _parse_table(
        self, table_schema: TableSchema, object_type: str
    ) -> ValidationTableConfiguration:
        """Parse a single table/view schema into a ValidationTableConfiguration."""
        table_vc = getattr(table_schema, "validation_configuration", None)

        schema_val = self._resolve_bool(
            table_vc, keys.SCHEMA_VALIDATION, self.schema_validation_enabled
        )
        metrics_val = self._resolve_bool(
            table_vc, keys.METRICS_VALIDATION, self.metrics_validation_enabled
        )
        row_val = self._resolve_bool(
            table_vc, keys.ROW_VALIDATION, self.row_validation_enabled
        )
        cont_fail = self._resolve_bool(
            table_vc, keys.CONTINUE_ON_FAILURE, self.continue_on_failure
        )

        row_mode = self.row_validation_mode
        if table_vc is not None:
            table_row_mode = getattr(table_vc, keys.ROW_VALIDATION_MODE, None)
            if table_row_mode is not None:
                row_mode = table_row_mode

        early_stopping, early_thr, early_iv = self._resolve_early_stopping_fields(
            table_vc
        )

        if (
            row_val
            and RowValidationMode(row_mode) is RowValidationMode.HYBRID
            and not early_stopping
        ):
            raise ValidationConfigurationError(
                f"row_validation_mode=hybrid requires early_stopping=true with "
                f"early_stop_mismatch_row_threshold and early_stop_check_interval_minutes "
                f"(table {table_schema.fully_qualified_name})."
            )

        source_fqn = table_schema.fully_qualified_name
        if self.source_platform.casefold() == SourceType.ORACLE.value.casefold():
            source_fqn = self._normalize_oracle_fully_qualified_name(source_fqn)

        return ValidationTableConfiguration(
            fully_qualified_name=source_fqn,
            use_column_selection_as_exclude_list=table_schema.use_column_selection_as_exclude_list,
            column_selection_list=table_schema.column_selection_list or [],
            target_name=table_schema.target_name,
            target_database=table_schema.target_database or self.target_database,
            target_schema=table_schema.target_schema,
            where_clause=table_schema.where_clause or "",
            target_where_clause=table_schema.target_where_clause or "",
            index_column_list=table_schema.index_column_list or [],
            target_index_column_list=table_schema.target_index_column_list or [],
            column_mappings=table_schema.column_mappings or {},
            is_case_sensitive=table_schema.is_case_sensitive or False,
            max_failed_rows_number=table_schema.max_failed_rows_number
            or self.max_failed_rows_number,
            exclude_metrics=(
                table_schema.exclude_metrics
                if table_schema.exclude_metrics is not None
                else self.exclude_metrics
            ),
            apply_metric_column_modifier=(
                table_schema.apply_metric_column_modifier
                if table_schema.apply_metric_column_modifier is not None
                else self.apply_metric_column_modifier
            ),
            object_type=object_type,
            column_names_to_partition_by=table_schema.column_names_to_partition_by
            or [],
            max_columns_per_metrics_batch=(
                table_schema.max_columns_per_metrics_batch
                if table_schema.max_columns_per_metrics_batch is not None
                else self.max_columns_per_metrics_batch
            ),
            target_partition_size_rows=(
                table_schema.target_partition_size_rows
                if table_schema.target_partition_size_rows is not None
                else self.target_partition_size_rows
            ),
            target_partition_size_mb=(
                table_schema.target_partition_size_mb
                if table_schema.target_partition_size_mb is not None
                else self.target_partition_size_mb
            ),
            schema_validation=schema_val,
            metrics_validation=metrics_val,
            row_validation=row_val,
            row_validation_mode=row_mode,
            continue_on_failure=cont_fail,
            early_stopping=early_stopping,
            early_stop_mismatch_row_threshold=early_thr,
            early_stop_check_interval_minutes=early_iv,
        )

    def _resolve_early_stopping_fields(
        self, table_vc: object | None
    ) -> tuple[bool, int | None, int | None]:
        """Resolve L3 early-stop flags from per-table then global validation_configuration."""
        g_vc = self._schema.validation_configuration

        early_stopping = False
        if (
            table_vc is not None
            and getattr(table_vc, keys.EARLY_STOPPING, None) is not None
        ):
            early_stopping = bool(getattr(table_vc, keys.EARLY_STOPPING))
        elif g_vc is not None and getattr(g_vc, keys.EARLY_STOPPING, None) is not None:
            early_stopping = bool(getattr(g_vc, keys.EARLY_STOPPING))

        threshold: int | None = None
        interval: int | None = None
        for vc in (table_vc, g_vc):
            if vc is None:
                continue
            raw_t = getattr(vc, keys.EARLY_STOP_MISMATCH_ROW_THRESHOLD, None)
            if raw_t is not None:
                threshold = int(raw_t)
                break
        for vc in (table_vc, g_vc):
            if vc is None:
                continue
            raw_i = getattr(vc, keys.EARLY_STOP_CHECK_INTERVAL_MINUTES, None)
            if raw_i is not None:
                interval = int(raw_i)
                break

        if early_stopping and (threshold is None or interval is None):
            raise ValidationConfigurationError(
                "early_stopping is enabled but early_stop_mismatch_row_threshold and "
                "early_stop_check_interval_minutes must be set (globally or per table)."
            )

        return early_stopping, threshold, interval

    @staticmethod
    def _resolve_bool(
        table_vc: object | None, attr_name: str, global_default: bool
    ) -> bool:
        """Resolve a boolean value from per-table override or global default."""
        if table_vc is not None:
            val = getattr(table_vc, attr_name, None)
            if val is not None:
                return val
        return global_default
