"""Configuration property key constants for data validation workflow JSON."""

# Root-level fields (aligned with SDV ConfigurationModel, minus connections)
SOURCE_PLATFORM = "source_platform"
TARGET_PLATFORM = "target_platform"
TARGET_DATABASE = "target_database"
VALIDATION_CONFIGURATION = "validation_configuration"
COMPARISON_CONFIGURATION = "comparison_configuration"
DATABASE_MAPPINGS = "database_mappings"
SCHEMA_MAPPINGS = "schema_mappings"
TABLES = "tables"
VIEWS = "views"

# Validation configuration fields (aligned with SDV ValidationConfiguration)
SCHEMA_VALIDATION = "schema_validation"
METRICS_VALIDATION = "metrics_validation"
ROW_VALIDATION = "row_validation"
ROW_VALIDATION_MODE = "row_validation_mode"
CONTINUE_ON_FAILURE = "continue_on_failure"
MAX_FAILED_ROWS_NUMBER = "max_failed_rows_number"
EARLY_STOPPING = "early_stopping"
EARLY_STOP_MISMATCH_ROW_THRESHOLD = "early_stop_mismatch_row_threshold"
EARLY_STOP_CHECK_INTERVAL_MINUTES = "early_stop_check_interval_minutes"
EXCLUDE_METRICS = "exclude_metrics"
APPLY_METRIC_COLUMN_MODIFIER = "apply_metric_column_modifier"
MAX_COLUMNS_PER_METRICS_BATCH = "max_columns_per_metrics_batch"
MAX_COLUMNS_PER_CELL_BATCH = "max_columns_per_cell_batch"

# Comparison configuration fields
TOLERANCE = "tolerance"
TYPE_MAPPING_FILE_PATH = "type_mapping_file_path"

# Per-table fields (aligned with SDV TableConfiguration)
FULLY_QUALIFIED_NAME = "fully_qualified_name"
USE_COLUMN_SELECTION_AS_EXCLUDE_LIST = "use_column_selection_as_exclude_list"
COLUMN_SELECTION_LIST = "column_selection_list"
TARGET_NAME = "target_name"
TARGET_SCHEMA = "target_schema"
WHERE_CLAUSE = "where_clause"
TARGET_WHERE_CLAUSE = "target_where_clause"
INDEX_COLUMN_LIST = "index_column_list"
TARGET_INDEX_COLUMN_LIST = "target_index_column_list"
COLUMN_MAPPINGS = "column_mappings"
IS_CASE_SENSITIVE = "is_case_sensitive"
OBJECT_TYPE = "object_type"
COLUMN_NAMES_TO_PARTITION_BY = "columnNamesToPartitionBy"
TARGET_PARTITION_SIZE_ROWS = "targetPartitionSizeRows"
TARGET_PARTITION_SIZE_MB = "targetPartitionSizeMb"

# Orchestrator-specific additions
AFFINITY = "affinity"
USE_SNOWFLAKE_COMPUTE = "use_snowflake_compute"
