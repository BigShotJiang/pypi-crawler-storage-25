import json

from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import Any, Generic, TypeVar

from data_migration_orchestrator.cloud_core.exceptions.queueing_error import (
    QueueingError,
)
from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.constants.task_columns import (
    ID,
    NAME,
    PAYLOAD,
    PRIORITY,
    SCOPE,
    STATUS,
    WORKFLOW_ID,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.tasks.task_status import TaskStatus
from data_migration_orchestrator.cloud_core.workflows.workflow import Workflow


logger = get_logger("tasks.queues.base_task_queue")


# Constants
UNKNOWN = "unknown"

TPayload = TypeVar("TPayload", contravariant=True)


class BaseTaskQueue(ABC, Generic[TPayload]):
    """
    Abstract base class for task queue implementations.

    This interface defines the contract that all task queue implementations
    must follow for adding, retrieving, and managing tasks in the system.
    """

    def __init__(self, payload_mapper: Callable[[str, dict], TPayload]):
        """
        Initialize the task queue.

        Args:
            payload_mapper: A function that maps a payload kind string to a dataclass instance.

        """
        self.payload_mapper = payload_mapper

    def register_thread_connection(self, connection: Any) -> None:
        """
        Register a per-thread connection for the calling thread.

        Subclasses that support multi-threaded access should override this to
        store the connection in thread-local storage.
        """

    @abstractmethod
    async def _push_task_internal(
        self,
        workflow_id: int,
        executor_type: ExecutorType,
        task_name: str,
        payload: TPayload,
        scope: str,
        priority: float = 3,
        successor_task_id: int | None = None,
        is_blocked: bool = False,
        is_cleanup: bool = False,
    ) -> int | None:
        """
        Add a new task to the queue.

        Args:
            workflow_id (int): The ID of the workflow to which the task belongs.
            executor_type (ExecutorType): The type of executor that should process the task.
            task_name (str): The name of the task.
            payload (TPayload): The payload containing task data and metadata.
            scope (str): The hierarchical scope describing the task's purpose
                (e.g., 'Table[DB.SCHEMA.TABLE]::Preprocessing').
            priority (float, optional): The priority of the task (default is 3).
            successor_task_id (int | None, optional): The ID of the successor task, if any.
            is_blocked (bool, optional): Whether the task is initially blocked (default is False).
            is_cleanup (bool, optional): Whether this is a cleanup task (default is False).

        Returns:
            int | None: The ID of the newly created task, or None if creation failed.

        """
        pass

    @abstractmethod
    async def check_tasks(
        self, workflow_id: int, task_ids: list[int]
    ) -> list[Task[TPayload]]:
        """
        Check the status for some task.

        Args:
            workflow_id: The ID for a workflow.
            task_ids: List of task IDs to check.

        Returns:
            The list of tasks with their status.

        """
        pass

    @abstractmethod
    async def unblock_tasks(self):
        """Unblock tasks for which all predecessor tasks have been completed."""
        pass

    @abstractmethod
    async def unblock_cleanup_tasks(self):
        """Unblock cleanup tasks once every non-cleanup task in their workflow is terminal."""
        pass

    @abstractmethod
    async def expire_leases(self):
        """Expire leases for tasks that have exceeded their lease duration."""
        pass

    @abstractmethod
    async def refresh_active_leases(self, task_ids: set[int]) -> None:
        """
        Refresh leases only for the given task IDs.

        Only targets tasks that are known to be actively processed by a live
        worker thread, so orphaned tasks from a previous process are never
        touched and can be recovered by expire_leases().
        """
        pass

    @abstractmethod
    async def refresh_warehouse_tasks(self):
        """Check tasks associated with queries running in a warehouse and mark them as complete."""
        pass

    @abstractmethod
    async def refresh_snowpipe_tasks(self) -> None:
        """Refresh book-keeping for tasks tied to Snowpipe ingestion (implementations may no-op)."""
        pass

    def _map_task(self, row: tuple, workflow_id: int) -> Task:
        """
        Map a database row tuple to a Task object.

        Args:
            row: Tuple with (ID, NAME, EXECUTOR_TYPE, STATUS, PRIORITY, PAYLOAD, SCOPE)
                 where indices are: 0=ID(int), 1=NAME(str), 2=EXECUTOR_TYPE(str),
                 3=STATUS(str), 4=PRIORITY(float), 5=PAYLOAD(variant/any), 6=SCOPE(str)
            workflow_id: The ID for the workflow this task belongs to

        Returns:
            Task object

        """
        return Task(
            workflow_id=workflow_id,
            executor_type=ExecutorType(str(row[2])),
            task_name=str(row[1]),
            payload=row[5],
            priority=float(row[4]),
            id=int(row[0]),
            status=TaskStatus(str(row[3])),
            scope=str(row[6]),
        )

    def _map_task_by_column_name(
        self,
        row: dict[str, int | str | TPayload],
        executor_type: ExecutorType,
        status: TaskStatus | None = None,
    ) -> Task[TPayload] | None:
        """
        Map a database row to a Task object.

        Args:
            row: Database row containing task data
            workflow_id: The workflow this task belongs to
            executor_type: The type of executor that will process this task
            status: Optional status override (if None, read from row)

        Returns:
            Task object or None if mapping fails

        """
        kind: str | None = None
        try:
            if status is None:
                status = TaskStatus(row[STATUS])

            workflow_id = int(row[WORKFLOW_ID])  # type: ignore
            payload_dict = json.loads(str(row[PAYLOAD]))
            kind = str(payload_dict.get("kind", UNKNOWN))
            payload = self.payload_mapper(kind, payload_dict)
            return Task(
                workflow_id=workflow_id,
                executor_type=executor_type,
                task_name=str(row[NAME]),
                payload=payload,
                priority=float(row[PRIORITY]),  # type: ignore
                id=int(row[ID]),  # type: ignore
                status=status,
                scope=str(row[SCOPE]),
            )
        except Exception as e:
            logger.error(f"Failed to map task (kind={kind}): {type(e).__name__}")
            return None

    @abstractmethod
    async def get_tasks(self, max_tasks: int | None = None) -> list[Task]:
        """
        Get tasks for a workflow.

        Args:
            max_tasks: Maximum number of tasks to pull. If None, uses the
                queue's default limit.

        Returns:
            The list of tasks for the workflow.

        """
        pass

    @abstractmethod
    async def has_workflow_started(self, workflow_id: int) -> bool:
        """
        Check if the workflow has started.

        This checks if the workflow has any tasks in the task queue.
        """
        pass

    @abstractmethod
    async def complete_task(
        self,
        consumer_type: ExecutorType,
        task_id: int,
        execution_profile: str | None = None,
    ) -> bool:
        """
        Complete a task.

        Args:
            consumer_type: The type of consumer that completed the task.
            task_id: The ID of the task to complete.
            execution_profile: Optional JSON string with step-level timing data.

        Returns:
            bool: True if the task was completed successfully, False otherwise.

        """
        pass

    @abstractmethod
    async def fail_task(
        self, consumer_id: str, task_id: int, error_message: str
    ) -> bool:
        """
        Mark a task as failed.

        Args:
            consumer_id: The ID of the consumer that failed the task.
            task_id: The ID of the task to mark as failed.
            error_message: The error message describing the failure.

        Returns:
            bool: True if the task was marked as failed successfully, False otherwise.

        """
        pass

    @abstractmethod
    async def warn_task(self, task_id: int, warning_message: str) -> None:
        """
        Attach a non-blocking warning message to a task.

        Args:
            task_id: The ID of the task to attach the warning to.
            warning_message: The warning message to attach.

        """
        pass

    @abstractmethod
    async def get_pending_workflows(self) -> list[Workflow]:
        """
        Get pending workflows to be started.

        Returns:
            The list of pending workflows to be started.

        """
        pass

    @abstractmethod
    async def complete_workflows(self):
        """Complete executing workflows for which all tasks are in terminal state."""
        pass

    @abstractmethod
    async def set_workflow_running(self, workflow_id: int) -> None:
        """
        Transition a workflow from 'initializing' to 'running'.

        Called after initial tasks have been successfully created.

        Args:
            workflow_id: The ID of the workflow to transition.

        """
        pass

    @abstractmethod
    async def fail_workflow_initialization(
        self, workflow_id: int, error_message: str
    ) -> None:
        """
        Record a failed initialization attempt for a workflow.

        Increments the failure counter. If the counter reaches the maximum
        (3), the workflow is moved to 'finished'. Otherwise it reverts
        to 'pending' so another attempt can be made.

        Args:
            workflow_id: The ID of the workflow.
            error_message: Description of the failure.

        """
        pass

    @abstractmethod
    async def expire_stale_initializations(self) -> None:
        """
        Expire workflows stuck in 'initializing' for longer than the timeout.

        Workflows that have exhausted all retries are moved to 'finished'.
        Others are reverted to 'pending' with an incremented failure counter.
        """
        pass

    @abstractmethod
    async def delete_workflow_tasks(self, workflow_id: int) -> None:
        """
        Delete all tasks, table metadata, and partition metadata for a workflow.

        Used before re-initializing a workflow that previously failed.

        Args:
            workflow_id: The ID of the workflow whose tasks should be removed.

        """
        pass

    async def push_task(self, task: Task[TPayload]) -> int:
        """
        Push a task into the queue.

        Args:
            task: The task to push (created by TaskBuilder)

        Returns:
            Task ID assigned by the queue, or None if queueing failed

        Raises:
            ValueError: If task is already queued (has id/status)
            ValueError: If task has no scope defined

        """
        if task.is_queued():
            raise ValueError(f"Task {task.id} is already queued")

        if task.scope is None:
            raise ValueError(f"Task '{task.task_name}' has no scope defined")

        maybe_task_id: int | None = await self._push_task_internal(
            workflow_id=task.workflow_id,
            executor_type=task.executor_type,
            task_name=task.task_name,
            payload=task.payload,
            scope=task.scope,
            priority=task.priority,
            successor_task_id=task.successor_task_id,
            is_blocked=task.is_blocked,
            is_cleanup=task.is_cleanup,
        )

        if maybe_task_id is None:
            message = f"Failed to queue task '{task.task_name}' for workflow {task.workflow_id}"
            logger.error(message)
            raise QueueingError(task.task_name)
        return maybe_task_id

    async def push_tasks_batch(self, tasks: list[Task[TPayload]]) -> list[int]:
        """
        Push multiple tasks.

        Default implementation calls push_task for each item. Subclasses may
        override with a single bulk INSERT for better performance.

        Args:
            tasks: Tasks to queue, in order.

        Returns:
            Task IDs in the same order as ``tasks``.

        """
        ids: list[int] = []
        for task in tasks:
            ids.append(await self.push_task(task))
        return ids

    async def push_task_chain(self, tasks: list[Task[TPayload]]) -> list[int]:
        """
        Push a chain of tasks into the queue.

        Args:
            tasks: The list of tasks to push (created by TaskBuilder), in execution order

        Returns:
            List of task IDs assigned by the queue, in the same order as input list

        Raises:
            ValueError: If any task is already queued (has id/status)
            ValueError: If any task has no scope defined

        """
        task_ids: list[int] = []
        # Preserve any pre-set successor on the last task (supports fan-in patterns
        # where the terminal task in the chain already points to a shared successor).
        successor_task_id: int | None = tasks[-1].successor_task_id if tasks else None

        # We push tasks in reverse order so that we can set successor task ids appropriately
        for index in reversed(range(len(tasks))):
            task = tasks[index]
            task.successor_task_id = successor_task_id
            task.is_blocked = (
                index != 0
            )  # Only the first task in the chain is unblocked initially
            task_id = await self.push_task(task)
            task_ids.append(task_id)
            successor_task_id = (
                task_id  # Next task in the chain will depend on this one
            )

        task_ids.reverse()
        return task_ids

    async def push_independent_two_task_chains(
        self,
        chains: list[tuple[Task[TPayload], Task[TPayload]]],
    ) -> list[int]:
        """
        Push N independent [first_task -> second_task] chains using batch inserts.

        Each chain has exactly 2 tasks: the first task (unblocked) has a successor
        pointing to the second task (blocked). Chains are independent of each other.

        Default implementation falls back to sequential push_task_chain calls.
        Subclasses (e.g. TableTaskQueue) override with batch SQL for performance.

        Args:
            chains: List of (first_task, second_task) tuples in execution order

        Returns:
            Flat list of all created task IDs

        """
        all_task_ids: list[int] = []
        for first_task, second_task in chains:
            task_ids = await self.push_task_chain([first_task, second_task])
            all_task_ids.extend(task_ids)
        return all_task_ids
