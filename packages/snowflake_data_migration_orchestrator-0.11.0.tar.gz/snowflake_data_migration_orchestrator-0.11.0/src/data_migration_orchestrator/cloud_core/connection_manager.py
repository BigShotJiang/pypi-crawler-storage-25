"""
Connection Manager for Snowflake.

Handles both local development and SPCS (Snowflake Container Services) environments.
Provides ``ResilientConnection``, a wrapper around ``SnowflakeConnection`` with
proactive age-based refresh, exponential-backoff connect retry, ``SELECT 1``
verification, and a shared circuit breaker.
"""

import os
import random
import threading
import time

from typing import Any, Protocol, runtime_checkable

import snowflake.connector

from data_migration_orchestrator.__version__ import __version__
from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from shared.telemetry import detect_runtime_environment, initialize_telemetry


logger = get_logger("connection_manager")

# ---------------------------------------------------------------------------
# Proactive connection refresh by age (per thread, at safe boundaries only).
# ---------------------------------------------------------------------------
ORCHESTRATOR_SF_CONNECTION_MAX_AGE_ENV = "ORCHESTRATOR_SF_CONNECTION_MAX_AGE_SECONDS"
DEFAULT_MAX_CONNECTION_AGE_SECONDS = 10800  # 3 hours

# ---------------------------------------------------------------------------
# Connect-retry constants (when opening a new underlying connection)
# ---------------------------------------------------------------------------
_CONNECT_RETRY_MAX_ATTEMPTS = 3
_CONNECT_RETRY_BASE_DELAY_SECONDS = 1.0
_CONNECT_RETRY_DELAY_MULTIPLIER = 2.0
_CONNECT_RETRY_JITTER_MAX_SECONDS = 1.0

_CIRCUIT_BREAKER_MAX_FAILURES = 5


class _UnsetMaxConnectionAge:
    """Sentinel: use account default from ``get_max_connection_age_seconds()``."""

    __slots__ = ()


_UNSET_MAX_CONNECTION_AGE = _UnsetMaxConnectionAge()


# ---------------------------------------------------------------------------
# Protocol — everything that ``TableTaskQueue`` / ``Warehouse`` need
# ---------------------------------------------------------------------------
@runtime_checkable
class SnowflakeConnectionLike(Protocol):
    """Structural type shared by ``SnowflakeConnection`` and ``ResilientConnection``."""

    def cursor(self, *args: Any, **kwargs: Any):
        """Open a new cursor."""
        ...

    def close(self) -> None:
        """Close the connection."""
        ...

    def commit(self) -> None:
        """Commit the current transaction."""
        ...

    def is_closed(self) -> bool:
        """Return ``True`` if the connection is closed."""
        ...

    def get_query_status_throw_if_error(self, query_id: str):
        """Return query status or raise on error."""
        ...

    def is_still_running(self, status: Any) -> bool:
        """Return ``True`` if *status* represents a running query."""
        ...


# ---------------------------------------------------------------------------
# Environment helpers (unchanged from the original module)
# ---------------------------------------------------------------------------
def is_spcs_environment() -> bool:
    """
    Detect if running in SPCS environment.

    It does so by checking for SNOWFLAKE_HOST
    which is automatically injected by SPCS.
    """
    return "SNOWFLAKE_HOST" in os.environ and "OMIT_SPCS_CREDENTIALS" not in os.environ


def get_connection_config() -> dict[str, Any]:
    """
    Build connection configuration based on the environment.

    Returns:
        Connection configuration dict for local or SPCS environment

    """
    if is_spcs_environment():
        cfg = _get_spcs_config()
    else:
        cfg = _get_local_config()
    return _with_default_migration_session_parameters(cfg)


def _with_default_migration_session_parameters(
    config: dict[str, Any],
) -> dict[str, Any]:
    """
    Apply default ``TIMEZONE = UTC`` for migration sessions.

    Ensures COPY INTO and ``MAX(timestamp)`` results return wall-clock values,
    not session-local renderings (avoids ``TIMESTAMP_NTZ`` wall-clock drift
    seen with the account default Pacific timezone).
    """
    out = dict(config)
    params = dict(out.get("session_parameters") or {})
    params.setdefault("TIMEZONE", "UTC")
    out["session_parameters"] = params
    return out


def _get_local_config() -> dict[str, Any]:
    """
    Get connection configuration for local development.

    Requires explicit credentials via environment variables.
    """
    logger.info("Detected LOCAL environment - using explicit credentials")

    connection_name = os.environ.get("SNOWFLAKE_CONNECTION_NAME")
    if connection_name:
        logger.info(f"Using connection_name: {connection_name}")
        return {"connection_name": connection_name}

    config: dict[str, Any] = {}

    required_fields = ["SNOWFLAKE_ACCOUNT", "SNOWFLAKE_USER", "SNOWFLAKE_PASSWORD"]
    for field in required_fields:
        value = os.environ.get(field)
        if not value:
            raise ValueError(f"Missing required environment variable: {field}")
        config[field.lower().replace("snowflake_", "")] = value

    optional_fields = [
        "SNOWFLAKE_WAREHOUSE",
        "SNOWFLAKE_DATABASE",
        "SNOWFLAKE_SCHEMA",
        "SNOWFLAKE_ROLE",
    ]
    for field in optional_fields:
        value = os.environ.get(field)
        if value:
            config[field.lower().replace("snowflake_", "")] = value

    logger.info(
        f"Local connection config: account={config.get('account')}, user={config.get('user')}, "
        f"warehouse={config.get('warehouse')}, database={config.get('database')}"
    )

    return config


def _get_login_token() -> str:
    """Read SPCS OAuth token — called on every fresh connection so the token is never stale."""
    with open("/snowflake/session/token") as f:
        return f.read()


def _get_spcs_config() -> dict[str, Any]:
    """
    Get connection configuration for SPCS environment.

    Uses auto-injected environment variables from Snowflake.
    """
    logger.info("Detected SPCS environment - using auto-injected credentials")

    token_value: str = _get_login_token()
    config: dict[str, Any] = {
        "account": os.environ.get("SNOWFLAKE_ACCOUNT"),
        "host": os.environ.get("SNOWFLAKE_HOST"),
        "port": int(os.environ.get("SNOWFLAKE_PORT", "443")),
        "authenticator": "oauth",
        "token": token_value,
        "protocol": os.environ.get("SNOWFLAKE_PROTOCOL", "https"),
    }

    if os.environ.get("SNOWFLAKE_DATABASE"):
        config["database"] = os.environ["SNOWFLAKE_DATABASE"]
    if os.environ.get("SNOWFLAKE_SCHEMA"):
        config["schema"] = os.environ["SNOWFLAKE_SCHEMA"]

    snowflake_warehouse = os.environ.get("SNOWFLAKE_WAREHOUSE")
    if snowflake_warehouse is not None and snowflake_warehouse != "":
        config["warehouse"] = snowflake_warehouse
    if os.environ.get("SNOWFLAKE_ROLE"):
        config["role"] = os.environ["SNOWFLAKE_ROLE"]

    logger.info(
        f"SPCS connection config: account={config.get('account')}, host={config.get('host')}, "
        f"role = {config.get('role')}, warehouse={config.get('warehouse')}, database={config.get('database')}, "
        f"token length={len(token_value)}, protocol={config.get('protocol')}, port={config.get('port')}"
    )
    return config


def get_max_connection_age_seconds() -> float | None:
    """
    Return max connection age from env (seconds) or the default.

    Unset/empty → ``DEFAULT_MAX_CONNECTION_AGE_SECONDS`` (3 h).
    ``0`` or negative → ``None`` (proactive age-refresh disabled).
    """
    raw = os.environ.get(ORCHESTRATOR_SF_CONNECTION_MAX_AGE_ENV)
    if raw is None or not str(raw).strip():
        return float(DEFAULT_MAX_CONNECTION_AGE_SECONDS)
    try:
        v = int(str(raw).strip())
    except ValueError:
        logger.warning(
            "Invalid %s=%r; using default %s",
            ORCHESTRATOR_SF_CONNECTION_MAX_AGE_ENV,
            raw,
            DEFAULT_MAX_CONNECTION_AGE_SECONDS,
        )
        return float(DEFAULT_MAX_CONNECTION_AGE_SECONDS)
    if v <= 0:
        return None
    return float(v)


# ---------------------------------------------------------------------------
# Legacy helper (used by CLI commands that create short-lived connections)
# ---------------------------------------------------------------------------
def create_connection() -> snowflake.connector.SnowflakeConnection:
    """
    Create and return a Snowflake connection based on the environment.

    Returns:
        An active Snowflake connection with telemetry initialized.

    """
    config = get_connection_config()
    logger.info("Creating Snowflake connection...")
    connection = snowflake.connector.connect(**config)
    logger.info("Snowflake connection created.")

    try:
        env = os.getenv("ENVIRONMENT", "prod")
        runtime = detect_runtime_environment()
        initialize_telemetry(
            conn=connection,
            app_name="data_migration_orchestrator",
            app_version=__version__,
            env=env,
            runtime=runtime,
        )
        logger.info(f"Telemetry initialized (env={env}, runtime={runtime.value})")
    except Exception as e:
        logger.debug(f"Telemetry initialization skipped: {e}")

    return connection


# ============================================================================
# Resilient connection infrastructure
# ============================================================================


class FailureTracker:
    """
    Thread-safe consecutive-failure counter (circuit breaker).

    Shared across all ``ResilientConnection`` instances in the process so that
    persistent infrastructure issues (bad credentials, network partition) trip
    early rather than letting every thread retry independently.
    """

    def __init__(
        self, max_consecutive_failures: int = _CIRCUIT_BREAKER_MAX_FAILURES
    ) -> None:
        """Create a tracker with the given *max_consecutive_failures* threshold."""
        self._max = max_consecutive_failures
        self._count = 0
        self._lock = threading.Lock()

    def increment(self) -> None:
        """Record one more consecutive failure."""
        with self._lock:
            self._count += 1

    def reset(self) -> None:
        """Clear the counter after a successful connect."""
        with self._lock:
            self._count = 0

    def get_count(self) -> int:
        """Return the current consecutive failure count."""
        with self._lock:
            return self._count

    def check_threshold(self) -> None:
        """Raise ``ConnectionError`` if the failure threshold was reached."""
        with self._lock:
            if self._count >= self._max:
                raise ConnectionError(
                    f"Circuit breaker tripped: {self._count} consecutive connection "
                    f"failures (threshold: {self._max})"
                )


def _verify_connection(conn: snowflake.connector.SnowflakeConnection) -> None:
    """Run ``SELECT 1`` to confirm the connection is live."""
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT 1")
            cursor.fetchone()
    except Exception as e:
        try:
            conn.close()
        except Exception:
            pass
        raise ConnectionError(f"Connection verification failed: {e}") from e


def _initialize_telemetry_safe(
    conn: snowflake.connector.SnowflakeConnection, app_version: str
) -> None:
    try:
        env = os.getenv("ENVIRONMENT", "prod")
        runtime = detect_runtime_environment()
        initialize_telemetry(
            conn=conn,
            app_name="data_migration_orchestrator",
            app_version=app_version,
            env=env,
            runtime=runtime,
        )
    except Exception as e:
        logger.debug(f"Telemetry initialization skipped: {e}")


class ResilientConnection:
    """
    Wrapper around ``SnowflakeConnection`` with resilience features.

    * **Proactive age-based refresh** — ``_ensure_connected()`` runs before each
      ``cursor()`` / ``get_query_status_throw_if_error()`` call.  If the underlying
      connection has lived longer than ``max_connection_age_seconds`` it is closed and
      a fresh one is opened.  This only triggers **between** logical operations (safe
      boundary), never while a cursor is open.
    * **Connect retry with backoff + jitter** — ``_connect_with_retry()`` retries up to
      ``_CONNECT_RETRY_MAX_ATTEMPTS`` times with exponential delay.
    * **SELECT 1 verification** after every new connection.
    * **Circuit breaker** via a shared ``FailureTracker``.

    Each worker thread should own its own ``ResilientConnection``.
    """

    def __init__(
        self,
        connection_config: dict[str, Any],
        app_version: str,
        failure_tracker: FailureTracker,
        thread_name: str = "main",
        max_connection_age_seconds: (
            float | None | _UnsetMaxConnectionAge
        ) = _UNSET_MAX_CONNECTION_AGE,
    ) -> None:
        """Create a new resilient connection (opens immediately with retry)."""
        self._base_config = connection_config
        self._app_version = app_version
        self._failure_tracker = failure_tracker
        self.thread_name = thread_name
        self._raw_conn: snowflake.connector.SnowflakeConnection | None = None
        self._creation_time = 0.0
        self._is_spcs = is_spcs_environment()

        if isinstance(max_connection_age_seconds, _UnsetMaxConnectionAge):
            self._max_age = get_max_connection_age_seconds()
        else:
            self._max_age = max_connection_age_seconds

        self._connect_with_retry()

    # -- public API (SnowflakeConnectionLike) --------------------------------

    def cursor(self, *args: Any, **kwargs: Any):
        """Return a cursor, reconnecting first if needed."""
        self._ensure_connected()
        conn = self._raw_conn
        assert conn is not None
        return conn.cursor(*args, **kwargs)

    def close(self) -> None:
        """Close the underlying connection (idempotent)."""
        if self._raw_conn is not None:
            try:
                self._raw_conn.close()
            except Exception as e:
                logger.debug(f"[{self.thread_name}] Error closing connection: {e}")
            finally:
                self._raw_conn = None

    def commit(self) -> None:
        """Commit the current transaction on the underlying connection."""
        if self._raw_conn is not None:
            self._raw_conn.commit()

    def is_closed(self) -> bool:
        """Return ``True`` when no usable underlying connection exists."""
        if self._raw_conn is None:
            return True
        try:
            return self._raw_conn.is_closed()
        except Exception:
            return True

    def get_query_status_throw_if_error(self, query_id: str):
        """Delegate to the underlying connection, reconnecting first if needed."""
        self._ensure_connected()
        conn = self._raw_conn
        assert conn is not None
        return conn.get_query_status_throw_if_error(query_id)

    def is_still_running(self, status: Any) -> bool:
        """Delegate ``is_still_running`` to the underlying connection."""
        if self._raw_conn is None:
            return False
        return self._raw_conn.is_still_running(status)

    # -- context manager -----------------------------------------------------

    def __enter__(self) -> "ResilientConnection":
        """Enter context manager."""
        return self

    def __exit__(
        self, exc_type: type | None, exc_val: Exception | None, exc_tb: Any
    ) -> None:
        """Exit context manager — always closes."""
        self.close()

    # -- reconnect entry point (called by run_with_session_retry) ------------

    def force_reconnect(self) -> None:
        """Close the current connection and open a fresh one with retry."""
        if self._raw_conn is not None:
            try:
                self._raw_conn.close()
            except Exception:
                pass
            self._raw_conn = None
        self._connect_with_retry()

    # -- internal ------------------------------------------------------------

    def _ensure_connected(self) -> None:
        should_reconnect = False
        if self._raw_conn is None:
            should_reconnect = True
        elif self.is_closed():
            should_reconnect = True
            logger.debug(f"[{self.thread_name}] Connection is closed, reconnecting")
        elif self._max_age is not None:
            age = time.time() - self._creation_time
            if age > self._max_age:
                should_reconnect = True
                logger.info(
                    f"[{self.thread_name}] Connection age ({age:.0f}s) exceeds "
                    f"max ({self._max_age:.0f}s), proactively refreshing"
                )

        if should_reconnect:
            if self._raw_conn is not None:
                try:
                    self._raw_conn.close()
                except Exception:
                    pass
                self._raw_conn = None
            self._connect_with_retry()

    def _connect_with_retry(self) -> None:
        last_exc: Exception | None = None
        delay = _CONNECT_RETRY_BASE_DELAY_SECONDS

        for attempt in range(1, _CONNECT_RETRY_MAX_ATTEMPTS + 1):
            try:
                config = self._get_fresh_config()
                logger.debug(
                    f"[{self.thread_name}] Connect attempt {attempt}/{_CONNECT_RETRY_MAX_ATTEMPTS}"
                )

                raw = snowflake.connector.connect(**config)
                _verify_connection(raw)
                _initialize_telemetry_safe(raw, self._app_version)

                self._raw_conn = raw
                self._creation_time = time.time()
                self._failure_tracker.reset()

                logger.info(
                    f"[{self.thread_name}] Connection established (attempt {attempt})"
                )
                return

            except Exception as e:
                self._failure_tracker.increment()
                self._failure_tracker.check_threshold()
                last_exc = e

                logger.warning(
                    f"[{self.thread_name}] Connect attempt {attempt} failed: {e}"
                )

                if attempt < _CONNECT_RETRY_MAX_ATTEMPTS:
                    jitter = random.uniform(0, _CONNECT_RETRY_JITTER_MAX_SECONDS)
                    sleep_time = delay + jitter
                    logger.debug(f"[{self.thread_name}] Retrying in {sleep_time:.2f}s")
                    time.sleep(sleep_time)
                    delay *= _CONNECT_RETRY_DELAY_MULTIPLIER

        raise ConnectionError(
            f"Failed to establish connection after {_CONNECT_RETRY_MAX_ATTEMPTS} "
            f"attempts. Last error: {last_exc}"
        ) from last_exc

    def _get_fresh_config(self) -> dict[str, Any]:
        if self._is_spcs:
            return _get_spcs_config()
        return self._base_config.copy()


# Module-level shared failure tracker
shared_failure_tracker = FailureTracker()
