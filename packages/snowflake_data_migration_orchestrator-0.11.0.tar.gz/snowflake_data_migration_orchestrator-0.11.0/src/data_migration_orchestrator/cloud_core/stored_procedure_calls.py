"""Templates for Snowflake stored procedure calls (data-migration metadata schema)."""

from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_migration_schema,
)


def pull_tasks_call_template() -> str:
    """Return parameterized SQL template for the PULL_TASKS stored procedure."""
    return f"CALL {qualified_migration_schema()}.PULL_TASKS(%s, %s, %s, %s)"


def push_task_call_template() -> str:
    """Return parameterized SQL template for the PUSH_TASK stored procedure."""
    return f"CALL {qualified_migration_schema()}.PUSH_TASK(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"


def create_table_call_template() -> str:
    """Return parameterized SQL template for the CREATE_TABLE stored procedure."""
    return f"CALL {qualified_migration_schema()}.CREATE_TABLE(%s, %s, %s, %s, %s)"


def copy_parquet_into_table_call_template() -> str:
    """Return parameterized SQL template for COPY_PARQUET_INTO_TABLE."""
    return f"CALL {qualified_migration_schema()}.COPY_PARQUET_INTO_TABLE(%s, %s, %s, %s, %s, %s)"


def has_workflow_started_call_template() -> str:
    """Return parameterized SQL template for HAS_WORKFLOW_STARTED."""
    return f"CALL {qualified_migration_schema()}.HAS_WORKFLOW_STARTED(%s)"


def complete_task_call_template() -> str:
    """Return parameterized SQL template for COMPLETE_TASK."""
    return f"CALL {qualified_migration_schema()}.COMPLETE_TASK(%s, %s, %s)"


def fail_task_call_template() -> str:
    """Return parameterized SQL template for FAIL_TASK."""
    return f"CALL {qualified_migration_schema()}.FAIL_TASK(%s, %s, %s)"


def reschedule_periodical_task_call_template() -> str:
    """Return parameterized SQL template for RESCHEDULE_PERIODICAL_TASK."""
    return f"CALL {qualified_migration_schema()}.RESCHEDULE_PERIODICAL_TASK(%s, %s, %s)"


def try_unblock_task_call_template() -> str:
    """Return parameterized SQL template for TRY_UNBLOCK_TASK."""
    return f"CALL {qualified_migration_schema()}.TRY_UNBLOCK_TASK(%s, %s)"


def skip_all_dv_l3_candidate_tasks_call_template() -> str:
    """Return parameterized SQL template for SKIP_ALL_DV_L3_CANDIDATE_TASKS."""
    return (
        f"CALL {qualified_migration_schema()}.SKIP_ALL_DV_L3_CANDIDATE_TASKS("
        f"%s, %s, %s, %s)"
    )
