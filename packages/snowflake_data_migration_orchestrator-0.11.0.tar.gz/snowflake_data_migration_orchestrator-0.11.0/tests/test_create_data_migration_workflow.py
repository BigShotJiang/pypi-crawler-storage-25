"""Unit tests for the create-data-migration-workflow command."""

import json

from argparse import Namespace
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

import snowflake.connector.errors

from data_migration_orchestrator.commands.create_data_migration_workflow import (
    SUPPORTED_DATA_MIGRATION_DIALECTS,
    _build_insert_sql,
    _read_config_file,
    _validate_source_platform,
    create_data_migration_workflow,
)
from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_migration_schema,
)
from shared.enums.source_type import SourceType


def _minimal_config() -> dict:
    return {
        "tables": [
            {
                "source": {
                    "databaseName": "src_db",
                    "schemaName": "dbo",
                    "tableName": "customers",
                },
                "target": {
                    "databaseName": "tgt_db",
                    "schemaName": "public",
                    "tableName": "customers",
                },
                "columnNamesToPartitionBy": ["id"],
            }
        ]
    }


class TestReadConfigFile:
    """Tests for _read_config_file."""

    def test_reads_valid_json(self, tmp_path: Path):
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({"tables": []}))

        result = _read_config_file(config_file)

        assert result == {"tables": []}

    def test_exits_when_file_not_found(self, tmp_path: Path):
        missing = tmp_path / "missing.json"

        with pytest.raises(SystemExit):
            _read_config_file(missing)

    def test_exits_on_invalid_json(self, tmp_path: Path):
        bad_file = tmp_path / "bad.json"
        bad_file.write_text("not json {{{")

        with pytest.raises(SystemExit):
            _read_config_file(bad_file)


class TestBuildInsertSql:
    """Tests for _build_insert_sql."""

    def test_basic_sql_structure(self):
        sql = _build_insert_sql(
            name="test_wf",
            source_platform=SourceType.SQLSERVER,
            configuration_json='{"tables":[]}',
            affinity=None,
        )

        qm = qualified_migration_schema()
        assert f"INSERT INTO {qm}.WORKFLOW" in sql
        assert "'test_wf'" in sql
        assert f"'{SourceType.SQLSERVER.value}'" in sql
        assert "'data-migration'" in sql
        assert "PARSE_JSON" in sql
        assert "NULL" in sql

    def test_affinity_included_when_provided(self):
        sql = _build_insert_sql(
            name="wf",
            source_platform=SourceType.SQLSERVER,
            configuration_json="{}",
            affinity="blue",
        )

        assert "'blue'" in sql
        assert "NULL" not in sql

    def test_affinity_null_when_not_provided(self):
        sql = _build_insert_sql(
            name="wf",
            source_platform=SourceType.SQLSERVER,
            configuration_json="{}",
            affinity=None,
        )

        assert "NULL" in sql

    def test_escapes_single_quotes_in_name(self):
        sql = _build_insert_sql(
            name="it's a test",
            source_platform=SourceType.SQLSERVER,
            configuration_json="{}",
            affinity=None,
        )

        assert "it''s a test" in sql

    def test_escapes_single_quotes_in_config(self):
        sql = _build_insert_sql(
            name="wf",
            source_platform=SourceType.SQLSERVER,
            configuration_json='{"key": "val\'ue"}',
            affinity=None,
        )

        assert "val''ue" in sql

    def test_escapes_backslashes_in_config(self):
        sql = _build_insert_sql(
            name="wf",
            source_platform=SourceType.SQLSERVER,
            configuration_json='{"targetName": "\\"Id\\""}',
            affinity=None,
        )

        assert '\\\\"Id\\\\"' in sql

    def test_contains_default_constants(self):
        sql = _build_insert_sql(
            name="wf",
            source_platform=SourceType.SQLSERVER,
            configuration_json="{}",
            affinity=None,
        )

        assert "snowflake:stage" in sql
        qm = qualified_migration_schema()
        assert f"@{qm}.TASK_RESULTS" in sql
        assert "'1.0'" in sql


@patch(
    "data_migration_orchestrator.commands.create_data_migration_workflow._workflow_name_exists",
    return_value=False,
)
class TestCreateDataMigrationWorkflow:
    """Tests for the create_data_migration_workflow entry point."""

    def _make_args(self, config_file: Path, **overrides) -> Namespace:
        defaults = {
            "config_file": config_file,
            "connection_name": None,
            "name": "MY_WORKFLOW",
            "source_platform": SourceType.SQLSERVER.value,
        }
        defaults.update(overrides)
        return Namespace(**defaults)

    def test_validates_config_and_executes_insert(
        self, _mock_name_exists, tmp_path: Path
    ):
        config = _minimal_config()
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps(config))

        mock_cursor = MagicMock()
        mock_cursor.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn = MagicMock()
        mock_conn.__enter__ = MagicMock(return_value=mock_conn)
        mock_conn.cursor.return_value = mock_cursor

        args = self._make_args(config_file)

        with patch(
            "data_migration_orchestrator.commands.create_data_migration_workflow._connect",
            return_value=mock_conn,
        ):
            create_data_migration_workflow(args)

        mock_cursor.execute.assert_called_once()
        executed_sql = mock_cursor.execute.call_args[0][0]
        assert "INSERT INTO" in executed_sql
        assert "MY_WORKFLOW" in executed_sql

    def test_raises_on_invalid_config(self, _mock_name_exists, tmp_path: Path):
        config_file = tmp_path / "bad_config.json"
        config_file.write_text(json.dumps({"tables": []}))

        args = self._make_args(config_file)

        with pytest.raises(SystemExit):
            create_data_migration_workflow(args)

    def test_exits_when_source_platform_missing(self, tmp_path: Path):
        config = _minimal_config()
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps(config))

        args = self._make_args(config_file, source_platform=None)

        with pytest.raises(SystemExit):
            create_data_migration_workflow(args)

    def test_exits_on_sql_execution_error(self, tmp_path: Path):
        config = _minimal_config()
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps(config))

        mock_cursor = MagicMock()
        mock_cursor.execute.side_effect = snowflake.connector.errors.ProgrammingError(
            "Table does not exist"
        )
        mock_conn = MagicMock()
        mock_conn.cursor.return_value = mock_cursor

        args = self._make_args(config_file)

        with (
            patch(
                "data_migration_orchestrator.commands.create_data_migration_workflow._connect",
                return_value=mock_conn,
            ),
            pytest.raises(SystemExit),
        ):
            create_data_migration_workflow(args)

    def test_affinity_extracted_from_config(self, _mock_name_exists, tmp_path: Path):
        config = _minimal_config()
        config["affinity"] = "team-red"
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps(config))

        mock_cursor = MagicMock()
        mock_cursor.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn = MagicMock()
        mock_conn.__enter__ = MagicMock(return_value=mock_conn)
        mock_conn.cursor.return_value = mock_cursor

        args = self._make_args(config_file)

        with patch(
            "data_migration_orchestrator.commands.create_data_migration_workflow._connect",
            return_value=mock_conn,
        ):
            create_data_migration_workflow(args)

        executed_sql = mock_cursor.execute.call_args[0][0]
        assert "'team-red'" in executed_sql

    def test_custom_name_and_platform(self, _mock_name_exists, tmp_path: Path):
        config = _minimal_config()
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps(config))

        mock_cursor = MagicMock()
        mock_cursor.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn = MagicMock()
        mock_conn.__enter__ = MagicMock(return_value=mock_conn)
        mock_conn.cursor.return_value = mock_cursor

        args = self._make_args(
            config_file,
            name="custom_wf",
            source_platform=SourceType.REDSHIFT.value,
        )

        with patch(
            "data_migration_orchestrator.commands.create_data_migration_workflow._connect",
            return_value=mock_conn,
        ):
            create_data_migration_workflow(args)

        executed_sql = mock_cursor.execute.call_args[0][0]
        assert "'custom_wf'" in executed_sql
        assert f"'{SourceType.REDSHIFT.value}'" in executed_sql

    def test_exits_on_duplicate_workflow_name(self, _mock_name_exists, tmp_path: Path):
        config = _minimal_config()
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps(config))

        mock_cursor = MagicMock()
        mock_cursor.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor.__exit__ = MagicMock(return_value=False)
        mock_conn = MagicMock()
        mock_conn.__enter__ = MagicMock(return_value=mock_conn)
        mock_conn.__exit__ = MagicMock(return_value=False)
        mock_conn.cursor.return_value = mock_cursor

        args = self._make_args(config_file, name="DUPLICATE_WF")

        with (
            patch(
                "data_migration_orchestrator.commands.create_data_migration_workflow._connect",
                return_value=mock_conn,
            ),
            patch(
                "data_migration_orchestrator.commands.create_data_migration_workflow._workflow_name_exists",
                return_value=True,
            ),
            pytest.raises(SystemExit) as exc_info,
        ):
            create_data_migration_workflow(args)

        assert exc_info.value.code == 1
        mock_cursor.execute.assert_not_called()
        mock_cursor.__exit__.assert_called_once()
        mock_conn.__exit__.assert_called_once()


class TestConnect:
    """Tests for _connect."""

    @patch(
        "data_migration_orchestrator.commands.create_data_migration_workflow.snowflake.connector.connect"
    )
    def test_uses_explicit_connection_name(self, mock_connect):
        from data_migration_orchestrator.commands.create_data_migration_workflow import (
            _connect,
        )

        _connect("my_connection")

        mock_connect.assert_called_once_with(connection_name="my_connection")

    @patch(
        "data_migration_orchestrator.commands.create_data_migration_workflow.snowflake.connector.connect"
    )
    @patch(
        "data_migration_orchestrator.commands.create_data_migration_workflow.get_connection_config"
    )
    def test_uses_env_config_when_no_name(self, mock_get_config, mock_connect):
        from data_migration_orchestrator.commands.create_data_migration_workflow import (
            _connect,
        )

        mock_get_config.return_value = {"account": "my_account", "user": "admin"}

        _connect(None)

        mock_connect.assert_called_once_with(account="my_account", user="admin")

    @patch(
        "data_migration_orchestrator.commands.create_data_migration_workflow.get_connection_config"
    )
    def test_exits_on_missing_env_vars(self, mock_get_config):
        from data_migration_orchestrator.commands.create_data_migration_workflow import (
            _connect,
        )

        mock_get_config.side_effect = ValueError(
            "Missing required environment variable"
        )

        with pytest.raises(SystemExit):
            _connect(None)

    @patch(
        "data_migration_orchestrator.commands.create_data_migration_workflow.snowflake.connector.connect"
    )
    def test_exits_on_database_error(self, mock_connect):
        from data_migration_orchestrator.commands.create_data_migration_workflow import (
            _connect,
        )

        mock_connect.side_effect = snowflake.connector.errors.DatabaseError(
            "Connection refused"
        )

        with pytest.raises(SystemExit):
            _connect("bad_connection")


class TestValidateSourcePlatform:
    """Tests for _validate_source_platform (feature gate)."""

    def test_accepts_sqlserver(self):
        result = _validate_source_platform("sqlserver")
        assert result == SourceType.SQLSERVER

    def test_accepts_redshift(self):
        result = _validate_source_platform("redshift")
        assert result == SourceType.REDSHIFT

    def test_accepts_postgresql(self):
        result = _validate_source_platform("postgresql")
        assert result == SourceType.POSTGRESQL

    def test_accepts_teradata(self):
        result = _validate_source_platform("teradata")
        assert result == SourceType.TERADATA

    def test_rejects_unknown_dialect(self):
        with pytest.raises(SystemExit):
            _validate_source_platform("mysql")

    def test_accepts_oracle(self):
        assert _validate_source_platform("oracle") == SourceType.ORACLE

    def test_supported_dialects_constant(self):
        assert SourceType.SQLSERVER in SUPPORTED_DATA_MIGRATION_DIALECTS
        assert SourceType.REDSHIFT in SUPPORTED_DATA_MIGRATION_DIALECTS
        assert SourceType.TERADATA in SUPPORTED_DATA_MIGRATION_DIALECTS
        assert SourceType.ORACLE in SUPPORTED_DATA_MIGRATION_DIALECTS
        assert SourceType.POSTGRESQL in SUPPORTED_DATA_MIGRATION_DIALECTS
