"""Tests for Snowflake provisioning helpers."""

import pytest

from data_migration_orchestrator.utils.snowflake_identifiers import (
    normalize_identifier_for_metadata_lookup,
)
from data_migration_orchestrator.utils.snowflake_schema import (
    ensure_database_and_schema,
    ensure_database_and_schema_sync,
    parse_external_stage_three_part_name,
    validate_external_stage_exists,
)


def test_parse_external_stage_three_part_name() -> None:
    db, sch, stg = parse_external_stage_three_part_name(
        "@DBABB.ECOMMERCE_TD_WRITENOS.TD_NOS_EXPORTS_STAGE"
    )
    assert db == "DBABB"
    assert sch == "ECOMMERCE_TD_WRITENOS"
    assert stg == "TD_NOS_EXPORTS_STAGE"


def test_parse_external_stage_unquoted_folded_to_uppercase() -> None:
    db, sch, stg = parse_external_stage_three_part_name("@dbabb.my_schema.my_stage")
    assert db == "DBABB"
    assert sch == "MY_SCHEMA"
    assert stg == "MY_STAGE"


def test_parse_external_stage_quoted_preserves_case_and_special_chars() -> None:
    db, sch, stg = parse_external_stage_three_part_name('@"Db"."Sch.Name"."stg-1"')
    assert db == "Db"
    assert sch == "Sch.Name"
    assert stg == "stg-1"


def test_parse_external_stage_quoted_escape_double_quote() -> None:
    db, sch, stg = parse_external_stage_three_part_name('@DB.SCHEMA."st""g"')
    assert db == "DB"
    assert sch == "SCHEMA"
    assert stg == 'st"g'


def test_parse_external_stage_whitespace_around_dots() -> None:
    db, sch, stg = parse_external_stage_three_part_name("@DB . SCHEMA . STAGE")
    assert db == "DB"
    assert sch == "SCHEMA"
    assert stg == "STAGE"


def test_parse_external_stage_mixed_quoted_and_unquoted() -> None:
    db, sch, stg = parse_external_stage_three_part_name(
        '@dbabb.ecommerce."export.stage"'
    )
    assert db == "DBABB"
    assert sch == "ECOMMERCE"
    assert stg == "export.stage"


def test_parse_external_stage_three_part_name_invalid() -> None:
    with pytest.raises(ValueError):
        parse_external_stage_three_part_name("@ONLY_TWO")


def test_parse_external_stage_four_segments_rejected() -> None:
    with pytest.raises(ValueError, match="trailing"):
        parse_external_stage_three_part_name("@A.B.C.D")


@pytest.mark.asyncio
async def test_validate_external_stage_exists_raises_when_missing() -> None:
    calls: list[str] = []

    async def fake_execute(sql: str) -> list:
        calls.append(sql)
        if sql.startswith("SHOW STAGES"):
            return []
        return []

    with pytest.raises(ValueError, match="does not exist"):
        await validate_external_stage_exists(
            fake_execute,
            "DBABB",
            "ECOMMERCE_TD_WRITENOS",
            "TD_NOS_EXPORTS_STAGE",
        )
    assert len(calls) == 1
    assert "SHOW STAGES LIKE" in calls[0]


@pytest.mark.asyncio
async def test_validate_external_stage_exists_succeeds_when_present() -> None:
    calls: list[str] = []

    async def fake_execute(sql: str) -> list:
        calls.append(sql)
        if sql.startswith("SHOW STAGES"):
            return [{"name": "TD_NOS_EXPORTS_STAGE"}]
        return []

    await validate_external_stage_exists(
        fake_execute,
        "DBABB",
        "S",
        "TD_NOS_EXPORTS_STAGE",
    )
    assert len(calls) == 1
    assert calls[0].startswith("SHOW STAGES")


class TestNormalizeIdentifierForMetadataLookup:
    """``normalize_identifier_for_metadata_lookup`` mirrors Snowflake's parser."""

    def test_unquoted_mixed_case_folds_to_upper(self) -> None:
        assert normalize_identifier_for_metadata_lookup("SampleDB") == "SAMPLEDB"

    def test_unquoted_already_upper_is_unchanged(self) -> None:
        assert normalize_identifier_for_metadata_lookup("SAMPLEDB") == "SAMPLEDB"

    def test_unquoted_lowercase_folds_to_upper(self) -> None:
        assert normalize_identifier_for_metadata_lookup("sampledb") == "SAMPLEDB"

    def test_quoted_identifier_preserves_case(self) -> None:
        assert normalize_identifier_for_metadata_lookup('"My_TaBle"') == "My_TaBle"

    def test_quoted_with_doubled_quote_unescapes(self) -> None:
        assert (
            normalize_identifier_for_metadata_lookup('"He said ""hi"""')
            == 'He said "hi"'
        )

    def test_strips_outer_whitespace(self) -> None:
        assert normalize_identifier_for_metadata_lookup("  SampleDB  ") == "SAMPLEDB"


class _RecordingFetch:
    """Simple stub that captures every SQL it is called with and returns *result*."""

    def __init__(self, *, exists: bool) -> None:
        self.calls: list[str] = []
        self._exists = exists

    def __call__(self, sql: str) -> list[dict] | None:
        self.calls.append(sql)
        upper = sql.lstrip().upper()
        if upper.startswith("SHOW DATABASES") or upper.startswith("SHOW SCHEMAS"):
            return [{"name": "X"}] if self._exists else None
        return None


class TestEnsureDatabaseAndSchemaSyncIdentifierHandling:
    """Sync ``ensure_database_and_schema`` honors Snowflake identifier rules."""

    def test_unquoted_mixed_case_uses_upper_for_lookup(self) -> None:
        fetch = _RecordingFetch(exists=True)
        ensure_database_and_schema_sync(fetch, "SampleDB", "E2E_Tests_Odbc")
        # Both lookups should hit the upper-folded stored name.
        assert "SHOW DATABASES LIKE 'SAMPLEDB'" in fetch.calls[0]
        assert "SHOW SCHEMAS LIKE 'E2E_TESTS_ODBC'" in fetch.calls[1]

    def test_quoted_input_preserves_case_in_lookup_and_create(self) -> None:
        fetch = _RecordingFetch(exists=False)
        ensure_database_and_schema_sync(fetch, '"MixedDB"', '"MixedSchema"')
        # SHOW LIKE pattern preserves inner case for quoted input.
        assert "SHOW DATABASES LIKE 'MixedDB'" in fetch.calls[0]
        # CREATE DATABASE quoted to preserve case.
        assert 'CREATE DATABASE IF NOT EXISTS "MixedDB"' in fetch.calls[1]
        assert "SHOW SCHEMAS LIKE 'MixedSchema'" in fetch.calls[2]
        assert 'CREATE SCHEMA IF NOT EXISTS "MixedDB"."MixedSchema"' in fetch.calls[3]

    def test_skips_create_when_database_exists(self) -> None:
        fetch = _RecordingFetch(exists=True)
        ensure_database_and_schema_sync(fetch, "SampleDB", "E2E_Tests_Odbc")
        # Two SHOW calls; no CREATE because both existed.
        assert all("CREATE" not in sql for sql in fetch.calls)
        assert len(fetch.calls) == 2


@pytest.mark.asyncio
async def test_ensure_database_and_schema_async_uses_upper_for_unquoted_lookup() -> (
    None
):
    calls: list[str] = []

    async def fake(sql: str) -> list:
        calls.append(sql)
        upper = sql.lstrip().upper()
        if upper.startswith("SHOW DATABASES") or upper.startswith("SHOW SCHEMAS"):
            return [{"name": "X"}]
        return []

    await ensure_database_and_schema(fake, "SampleDB", "E2E_Tests_Odbc")
    assert "SHOW DATABASES LIKE 'SAMPLEDB'" in calls[0]
    assert "SHOW SCHEMAS LIKE 'E2E_TESTS_ODBC'" in calls[1]
    # No CREATE issued when SHOW returned a row.
    assert all("CREATE" not in sql for sql in calls)
