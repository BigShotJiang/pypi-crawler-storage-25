"""Unit tests for PartitionCalculator with the four-factor model."""

from data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_calculator import (
    PartitionCalculator,
    PartitionConfig,
)


class TestEmptyTable:
    """An empty table should never be partitioned."""

    def test_empty_table_returns_no_partition(self):
        calc = PartitionCalculator()
        decision = calc.calculate_partition_strategy(row_count=0, data_size_mb=0)

        assert not decision.should_partition
        assert decision.num_partitions == 1
        assert decision.rows_per_partition == 0


class TestMbOnlyTarget:
    """Target rows derived from target_mb_per_partition."""

    def test_small_table_below_target_no_partition(self):
        config = PartitionConfig(target_mb_per_partition=512)
        calc = PartitionCalculator(config)
        # 100 rows at 50 MB: avg 0.5 MB/row → target_rows = 512/0.5 = 1024
        decision = calc.calculate_partition_strategy(row_count=100, data_size_mb=50)
        assert not decision.should_partition
        assert decision.num_partitions == 1
        assert decision.rows_per_partition == 100

    def test_large_table_returns_partitions(self):
        config = PartitionConfig(target_mb_per_partition=512)
        calc = PartitionCalculator(config)
        # 100K rows at 2 GB: avg 0.02048 MB/row → target_rows = int(512/0.02048) = 24999
        # (floating-point truncation) → ceil(100K/24999) = 5
        decision = calc.calculate_partition_strategy(
            row_count=100_000, data_size_mb=2048
        )
        assert decision.should_partition
        assert decision.num_partitions == 5
        assert decision.rows_per_partition > 0

    def test_no_data_size_returns_single_partition(self):
        config = PartitionConfig(target_mb_per_partition=512)
        calc = PartitionCalculator(config)
        # avg_row_mb=0 → MB target cannot be derived; fallback to row_count
        decision = calc.calculate_partition_strategy(row_count=1000, data_size_mb=0)
        assert not decision.should_partition
        assert decision.num_partitions == 1
        assert decision.rows_per_partition == 1000


class TestRowsOnlyTarget:
    """Target rows from explicit target_rows_per_partition."""

    def test_explicit_target_rows_partitions(self):
        config = PartitionConfig(target_rows_per_partition=50_000)
        calc = PartitionCalculator(config)
        # ceil(200K/50K) = 4
        decision = calc.calculate_partition_strategy(
            row_count=200_000, data_size_mb=1000
        )
        assert decision.should_partition
        assert decision.num_partitions == 4

    def test_explicit_target_rows_no_partition_when_small(self):
        config = PartitionConfig(target_rows_per_partition=500_000)
        calc = PartitionCalculator(config)
        decision = calc.calculate_partition_strategy(row_count=100_000, data_size_mb=0)
        assert not decision.should_partition
        assert decision.num_partitions == 1


class TestCombinedTargets:
    """When both MB and rows targets are set, the tighter constraint wins."""

    def test_tighter_target_rows_wins(self):
        config = PartitionConfig(
            target_mb_per_partition=5120,
            target_rows_per_partition=50_000,
        )
        calc = PartitionCalculator(config)
        # 200K rows at 1000 MB: avg 0.005 MB/row → MB target = 5120/0.005 = 1,024,000
        # Rows target = 50K → tighter, ceil(200K/50K) = 4
        decision = calc.calculate_partition_strategy(
            row_count=200_000, data_size_mb=1000
        )
        assert decision.should_partition
        assert decision.num_partitions == 4

    def test_tighter_mb_target_wins(self):
        config = PartitionConfig(
            target_mb_per_partition=100,
            target_rows_per_partition=500_000,
        )
        calc = PartitionCalculator(config)
        # 100K rows at 1000 MB: avg 0.01 MB/row → MB target = 100/0.01 = 10,000
        # Rows target = 500K → MB target is tighter, ceil(100K/10K) = 10
        decision = calc.calculate_partition_strategy(
            row_count=100_000, data_size_mb=1000
        )
        assert decision.should_partition
        assert decision.num_partitions == 10


class TestMaxCapsTarget:
    """max_target_rows_per_partition / max_target_mb_per_partition cap the effective target."""

    def test_max_rows_caps_target_rows(self):
        config = PartitionConfig(
            target_rows_per_partition=200_000,
            max_target_rows_per_partition=50_000,
        )
        calc = PartitionCalculator(config)
        # target=200K capped to 50K → ceil(400K/50K) = 8
        decision = calc.calculate_partition_strategy(row_count=400_000, data_size_mb=0)
        assert decision.should_partition
        assert decision.num_partitions == 8

    def test_max_rows_does_not_increase_beyond_target(self):
        """A large max_rows does not override a small target."""
        config = PartitionConfig(
            target_rows_per_partition=50_000,
            max_target_rows_per_partition=500_000,
        )
        calc = PartitionCalculator(config)
        # target=50K, max=500K → effective = min(50K, 500K) = 50K → ceil(200K/50K) = 4
        decision = calc.calculate_partition_strategy(row_count=200_000, data_size_mb=0)
        assert decision.should_partition
        assert decision.num_partitions == 4

    def test_max_mb_caps_size_derived_target(self):
        config = PartitionConfig(
            target_mb_per_partition=5120,
            max_target_mb_per_partition=100,
        )
        calc = PartitionCalculator(config)
        # 1M rows at 500 MB: avg 0.0005 MB/row
        # target from MB = 5120/0.0005 = 10,240,000
        # max from MB = 100/0.0005 = 200,000
        # effective = min(10.24M, 200K) = 200K → ceil(1M/200K) = 5
        decision = calc.calculate_partition_strategy(
            row_count=1_000_000, data_size_mb=500
        )
        assert decision.should_partition
        assert decision.num_partitions == 5

    def test_max_rows_alone_when_no_data_size(self):
        config = PartitionConfig(max_target_rows_per_partition=1000)
        calc = PartitionCalculator(config)
        # No targets → fallback target = row_count (5000), capped to 1000
        decision = calc.calculate_partition_strategy(row_count=5000, data_size_mb=0)
        assert decision.should_partition
        assert decision.num_partitions == 5
        assert decision.rows_per_partition == 1000

    def test_max_rows_no_partition_when_within_limit(self):
        config = PartitionConfig(max_target_rows_per_partition=10_000)
        calc = PartitionCalculator(config)
        decision = calc.calculate_partition_strategy(row_count=5000, data_size_mb=0)
        assert not decision.should_partition
        assert decision.num_partitions == 1
        assert decision.rows_per_partition == 5000

    def test_max_rows_ceiling_division(self):
        config = PartitionConfig(max_target_rows_per_partition=3000)
        calc = PartitionCalculator(config)
        decision = calc.calculate_partition_strategy(row_count=10_000, data_size_mb=0)
        assert decision.should_partition
        assert decision.num_partitions == 4  # ceil(10000/3000)

    def test_both_maxes_tighter_wins(self):
        config = PartitionConfig(
            target_mb_per_partition=5120,
            max_target_mb_per_partition=5120,
            max_target_rows_per_partition=100_000,
        )
        calc = PartitionCalculator(config)
        # 1M rows at 500 MB: avg 0.0005 MB/row
        # target from MB = 5120/0.0005 = 10,240,000
        # max from MB = 5120/0.0005 = 10,240,000
        # max from rows = 100K → tighter cap
        # effective = min(10.24M, 100K) = 100K → ceil(1M/100K) = 10
        decision = calc.calculate_partition_strategy(
            row_count=1_000_000, data_size_mb=500
        )
        assert decision.should_partition
        assert decision.num_partitions == 10


class TestNoMinPartitions:
    """min_partitions has been removed; partition count is purely ceil(rows/effective)."""

    def test_no_min_partitions_floor(self):
        config = PartitionConfig(target_mb_per_partition=512)
        calc = PartitionCalculator(config)
        # 600 rows at 600 MB: avg 1 MB/row → target = 512/1 = 512
        # effective=512, ceil(600/512) = 2 — no artificial floor
        decision = calc.calculate_partition_strategy(row_count=600, data_size_mb=600)
        assert decision.should_partition
        assert decision.num_partitions == 2


class TestMaxCellsCapsTarget:
    """max_target_cells_per_partition caps effective rows via cells / num_columns."""

    def test_cells_limit_tighter_than_row_target(self):
        config = PartitionConfig(
            target_rows_per_partition=500_000,
            max_target_cells_per_partition=4_000_000,
        )
        calc = PartitionCalculator(config)
        # 100 columns: max_rows_from_cells = 4M / 100 = 40K
        # target = 500K, capped to 40K → ceil(1M / 40K) = 25
        decision = calc.calculate_partition_strategy(
            row_count=1_000_000, data_size_mb=0, num_columns=100
        )
        assert decision.should_partition
        assert decision.num_partitions == 25

    def test_cells_limit_ignored_when_num_columns_zero(self):
        config = PartitionConfig(
            target_rows_per_partition=50_000,
            max_target_cells_per_partition=4_000_000,
        )
        calc = PartitionCalculator(config)
        # num_columns=0 → cells limit skipped; target 50K applies → ceil(200K/50K) = 4
        decision = calc.calculate_partition_strategy(
            row_count=200_000, data_size_mb=0, num_columns=0
        )
        assert decision.should_partition
        assert decision.num_partitions == 4

    def test_cells_limit_combined_with_max_rows_tighter_wins(self):
        config = PartitionConfig(
            target_rows_per_partition=500_000,
            max_target_rows_per_partition=100_000,
            max_target_cells_per_partition=4_000_000,
        )
        calc = PartitionCalculator(config)
        # 10 columns: max_rows_from_cells = 4M / 10 = 400K
        # max_rows_explicit = 100K → tighter; effective = min(500K, 100K) = 100K
        # ceil(1M / 100K) = 10
        decision = calc.calculate_partition_strategy(
            row_count=1_000_000, data_size_mb=0, num_columns=10
        )
        assert decision.should_partition
        assert decision.num_partitions == 10

    def test_cells_limit_tighter_than_max_rows(self):
        config = PartitionConfig(
            target_rows_per_partition=500_000,
            max_target_rows_per_partition=500_000,
            max_target_cells_per_partition=4_000_000,
        )
        calc = PartitionCalculator(config)
        # 200 columns: max_rows_from_cells = 4M / 200 = 20K
        # max_rows_explicit = 500K → cells tighter; effective = 20K
        # ceil(1M / 20K) = 50
        decision = calc.calculate_partition_strategy(
            row_count=1_000_000, data_size_mb=0, num_columns=200
        )
        assert decision.should_partition
        assert decision.num_partitions == 50

    def test_cells_limit_alone_caps_effective(self):
        config = PartitionConfig(
            max_target_cells_per_partition=4_000_000,
        )
        calc = PartitionCalculator(config)
        # No targets → fallback target = row_count (1M)
        # 50 columns: max_rows_from_cells = 4M / 50 = 80K
        # effective = min(1M, 80K) = 80K → ceil(1M / 80K) = 13
        decision = calc.calculate_partition_strategy(
            row_count=1_000_000, data_size_mb=0, num_columns=50
        )
        assert decision.should_partition
        assert decision.num_partitions == 13

    def test_cells_limit_no_partition_when_within_budget(self):
        config = PartitionConfig(
            max_target_cells_per_partition=4_000_000,
        )
        calc = PartitionCalculator(config)
        # 10 columns, 100K rows → 1M cells < 4M limit
        # max_rows_from_cells = 4M / 10 = 400K ≥ row_count → no partition
        decision = calc.calculate_partition_strategy(
            row_count=100_000, data_size_mb=0, num_columns=10
        )
        assert not decision.should_partition
        assert decision.num_partitions == 1


class TestMaxCaps:
    """Max caps always apply on top of targets."""

    def test_max_rows_cap(self):
        config = PartitionConfig(
            target_rows_per_partition=200_000,
            max_target_rows_per_partition=50_000,
        )
        calc = PartitionCalculator(config)
        # effective = min(200K, 50K) = 50K → ceil(400K/50K) = 8
        decision = calc.calculate_partition_strategy(row_count=400_000, data_size_mb=0)
        assert decision.should_partition
        assert decision.num_partitions == 8

    def test_max_mb_cap(self):
        config = PartitionConfig(
            target_mb_per_partition=5120,
            max_target_mb_per_partition=100,
        )
        calc = PartitionCalculator(config)
        # 1M rows at 500 MB: avg 0.0005 MB/row
        # target from MB = 5120/0.0005 = 10,240,000
        # max from MB = 100/0.0005 = 200K → effective 200K → 5 partitions
        decision = calc.calculate_partition_strategy(
            row_count=1_000_000, data_size_mb=500
        )
        assert decision.should_partition
        assert decision.num_partitions == 5

    def test_cells_cap(self):
        config = PartitionConfig(
            target_rows_per_partition=500_000,
            max_target_cells_per_partition=4_000_000,
        )
        calc = PartitionCalculator(config)
        # 100 columns: cells cap = 4M/100 = 40K → ceil(1M/40K) = 25
        decision = calc.calculate_partition_strategy(
            row_count=1_000_000, data_size_mb=0, num_columns=100
        )
        assert decision.should_partition
        assert decision.num_partitions == 25


class TestDefaultConfig:
    """Default PartitionConfig (all None) means no partitioning from targets."""

    def test_defaults_no_partition(self):
        calc = PartitionCalculator()
        decision = calc.calculate_partition_strategy(row_count=1000, data_size_mb=0)
        assert not decision.should_partition
        assert decision.num_partitions == 1
        assert decision.rows_per_partition == 1000

    def test_defaults_with_data_size_no_partition(self):
        calc = PartitionCalculator()
        # No target set → fallback target = row_count, no max → single partition
        decision = calc.calculate_partition_strategy(
            row_count=1_000_000, data_size_mb=1000
        )
        assert not decision.should_partition
        assert decision.num_partitions == 1
