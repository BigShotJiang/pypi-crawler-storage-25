"""Tests for lexicographic partition range encoding and SQL."""

import json

from data_migration_orchestrator.data_migration_cloud.partition.partition_range import (
    PARTITION_BOUND_DELIMITER,
    PartitionRange,
    build_lex_range_condition,
    build_partition_range_condition,
    compare_lex,
    decode_partition_bound,
    encode_partition_bound,
    partition_range_from_encoded,
)


class TestEncodeDecode:
    """Encode/decode round-trips for partition bound storage."""

    def test_single_column_scalar(self):
        assert encode_partition_bound(["id"], [42]) == 42
        assert decode_partition_bound(42, ["id"]) == [42]

    def test_multi_column_delimited(self):
        encoded = encode_partition_bound(["year", "month"], [2020, 3])
        assert encoded == f"2020{PARTITION_BOUND_DELIMITER}3"
        assert decode_partition_bound(encoded, ["year", "month"]) == [2020, 3]

    def test_escape_delimiter_in_string(self):
        raw = f"a{PARTITION_BOUND_DELIMITER}b"
        encoded = encode_partition_bound(["k1", "k2"], ["x", raw])
        assert decode_partition_bound(encoded, ["k1", "k2"]) == ["x", raw]

    def test_coerce_numeric_string(self):
        assert decode_partition_bound("100", ["id"]) == [100]

    def test_decode_json_string_literal_with_unicode_delimiter(self):
        r"""VARIANT/connector may return a JSON string with \u001f for the separator."""
        encoded = encode_partition_bound(
            ["ss_sold_date_sk", "ss_item_sk"],
            [2450816, 4],
        )
        stored = json.dumps(encoded)
        assert decode_partition_bound(stored, ["ss_sold_date_sk", "ss_item_sk"]) == [
            2450816,
            4,
        ]

    def test_decode_wrapped_quotes_and_literal_backslash_u001f(self):
        r"""Extra quotes plus literal \u001f spelling (no real unit separator yet)."""
        inner = "2450816.0000000000\\u001f4.0000000000"
        stored = f'"{inner}"'
        assert decode_partition_bound(stored, ["a", "b"]) == [2450816, 4]


class TestCompareLex:
    """Lexicographic comparison of multi-column values."""

    def test_less_greater_equal(self):
        assert compare_lex([2020, 1], [2020, 2]) == -1
        assert compare_lex([2021, 0], [2020, 12]) == 1
        assert compare_lex([2020, 5], [2020, 5]) == 0


class TestLexSql:
    """SQL generation for lexicographic partition range predicates."""

    def _quote(self, ident: str) -> str:
        return f'"{ident}"'

    def _fmt(self, value: object) -> str:
        if isinstance(value, str):
            return f"'{value}'"
        return str(value)

    def test_two_column_gte_and_lt(self):
        sql = build_lex_range_condition(
            ["year", "month"],
            [2020, 3],
            [2020, 5],
            lower_inclusive=True,
            upper_inclusive=False,
            quote_identifier=self._quote,
            format_value=self._fmt,
        )
        assert '"year" > 2020' in sql
        assert '("year" = 2020 AND "month" >= 3)' in sql
        assert '"year" >= 2020' not in sql
        assert '"month" < 5' in sql
        assert " OR " in sql

    def test_three_column_lower_strict_prefix(self):
        sql = build_lex_range_condition(
            ["ss_sold_date_sk", "ss_item_sk", "ss_ticket_number"],
            [2450847, 387223, 18219558717],
            [2450847, 398708, 13746405630],
            lower_inclusive=True,
            upper_inclusive=False,
            quote_identifier=self._quote,
            format_value=self._fmt,
        )
        assert '"ss_sold_date_sk" > 2450847' in sql
        assert '("ss_sold_date_sk" = 2450847 AND "ss_item_sk" > 387223)' in sql
        assert (
            '("ss_sold_date_sk" = 2450847 AND "ss_item_sk" = 387223 '
            'AND "ss_ticket_number" >= 18219558717)' in sql
        )
        assert '"ss_sold_date_sk" >= 2450847' not in sql
        assert '"ss_item_sk" >= 387223' not in sql

    def test_three_column_upper_inclusive_last_column(self):
        sql = build_lex_range_condition(
            ["ss_sold_date_sk", "ss_item_sk", "ss_ticket_number"],
            [2450847, 387223, 18219558717],
            [2450847, 398708, 13746405630],
            lower_inclusive=True,
            upper_inclusive=True,
            quote_identifier=self._quote,
            format_value=self._fmt,
        )
        assert '"ss_sold_date_sk" < 2450847' in sql
        assert '("ss_sold_date_sk" = 2450847 AND "ss_item_sk" < 398708)' in sql
        assert (
            '("ss_sold_date_sk" = 2450847 AND "ss_item_sk" = 398708 '
            'AND "ss_ticket_number" <= 13746405630)' in sql
        )
        assert '"ss_sold_date_sk" <= 2450847' not in sql
        assert '"ss_item_sk" <= 398708' not in sql

    def test_single_column_half_open(self):
        pr = PartitionRange(
            columns=["id"],
            lower=[100],
            upper=[200],
            upper_inclusive=False,
        )
        sql = build_partition_range_condition(
            pr,
            quote_identifier=self._quote,
            format_value=self._fmt,
        )
        assert sql == '"id" >= 100 AND "id" < 200'

    def test_edge_lower_only(self):
        pr = PartitionRange(
            columns=["year", "month"],
            lower=None,
            upper=[2020, 1],
            upper_inclusive=False,
        )
        sql = build_partition_range_condition(
            pr,
            quote_identifier=self._quote,
            format_value=self._fmt,
        )
        assert " < " in sql
        assert ">=" not in sql


class TestPartitionRangeFromEncoded:
    """Construction of ``PartitionRange`` from stored metadata values."""

    def test_interior_half_open(self):
        pr = partition_range_from_encoded(
            ["id"],
            100,
            200,
            upper_inclusive=False,
        )
        assert pr.upper_inclusive is False
        assert pr.lower == [100]
        assert pr.upper == [200]
