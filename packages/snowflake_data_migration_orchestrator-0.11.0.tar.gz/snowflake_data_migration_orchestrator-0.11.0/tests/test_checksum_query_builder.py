"""Tests for checksum data models and base query builder checksum default."""

from data_migration_orchestrator.data_migration_cloud.tasks.handlers.checksum_models import (
    ColumnInfo,
    PartitionInfo,
)


class TestColumnInfo:
    """Tests for ColumnInfo dataclass."""

    def test_column_info_creation(self):
        """Test creating a ColumnInfo with all fields."""
        col = ColumnInfo(
            column_name="amount",
            data_type="decimal",
            is_nullable=True,
            numeric_precision=18,
            numeric_scale=2,
        )
        assert col.column_name == "amount"
        assert col.data_type == "decimal"
        assert col.is_nullable is True
        assert col.numeric_precision == 18
        assert col.numeric_scale == 2

    def test_column_info_defaults(self):
        """Test ColumnInfo with default values."""
        col = ColumnInfo(
            column_name="name",
            data_type="varchar",
            is_nullable=False,
        )
        assert col.numeric_precision is None
        assert col.numeric_scale is None


class TestPartitionInfo:
    """Tests for PartitionInfo dataclass."""

    def test_partition_info_creation(self):
        """Test creating a PartitionInfo with all fields."""
        info = PartitionInfo(
            database="TestDB",
            schema="dbo",
            table_name="Orders",
            partition_columns=["order_id"],
            min_value="1000",
            max_value="1999",
            partition_number=1,
        )
        assert info.database == "TestDB"
        assert info.schema == "dbo"
        assert info.table_name == "Orders"
        assert info.partition_columns == ["order_id"]
        assert info.min_value == "1000"
        assert info.max_value == "1999"
        assert info.partition_number == 1

    def test_partition_info_with_none_boundaries(self):
        """Test PartitionInfo with None min/max values."""
        info = PartitionInfo(
            database="TestDB",
            schema="dbo",
            table_name="Orders",
            partition_columns=["order_id"],
            min_value=None,
            max_value=None,
            partition_number=0,
        )
        assert info.min_value is None
        assert info.max_value is None


class TestBaseQueryBuilderChecksumDefault:
    """Test that BaseQueryBuilder.build_checksum_query raises by default."""

    def test_default_raises_not_implemented(self):
        """Platforms that don't override build_checksum_query should raise."""
        from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
            TableIdentifier,
        )
        from data_migration_orchestrator.data_migration_cloud.platforms.sqlserver.query_builder import (
            SqlServerQueryBuilder,
        )

        builder = SqlServerQueryBuilder()
        partition_info = PartitionInfo(
            database="TestDB",
            schema="dbo",
            table_name="Orders",
            partition_columns=["order_id"],
            min_value="1",
            max_value="100",
            partition_number=1,
        )
        source_table_id = TableIdentifier(
            database_name="TestDB",
            schema_name="dbo",
            table_name="Orders",
        )
        columns = [ColumnInfo("id", "int", False)]

        # SqlServer does support checksums, so it should NOT raise
        query = builder.build_checksum_query(partition_info, source_table_id, columns)
        assert "checksum" in query
