"""Tests for Oracle fullyQualifiedName normalization in ValidationConfigurationParser."""

from data_migration_orchestrator.data_validation_cloud.config.validation_configuration_parser import (
    ValidationConfigurationParser,
)


def _oracle_parser() -> ValidationConfigurationParser:
    """Minimal parser instance to call ``_normalize_oracle_fully_qualified_name``."""
    return ValidationConfigurationParser(
        {
            "sourcePlatform": "oracle",
            "tables": [{"fullyQualifiedName": "HR.EMPLOYEES"}],
        }
    )


class TestNormalizeOracleFullyQualifiedName:
    """Tests for ``ValidationConfigurationParser._normalize_oracle_fully_qualified_name``."""

    def test_two_part_unchanged(self):
        parser = _oracle_parser()
        assert parser._normalize_oracle_fully_qualified_name("HR.EMPLOYEES") == (
            "HR.EMPLOYEES"
        )

    def test_two_part_strips_surrounding_whitespace(self):
        parser = _oracle_parser()
        assert parser._normalize_oracle_fully_qualified_name("  HR.EMPLOYEES  ") == (
            "HR.EMPLOYEES"
        )

    def test_three_part_drops_leading_catalog_segment(self):
        parser = _oracle_parser()
        assert parser._normalize_oracle_fully_qualified_name(
            "CONNECT.HR.EMPLOYEES"
        ) == ("HR.EMPLOYEES")

    def test_empty_returns_empty_string(self):
        parser = _oracle_parser()
        assert parser._normalize_oracle_fully_qualified_name("   ") == ""

    def test_single_segment_unchanged(self):
        parser = _oracle_parser()
        assert parser._normalize_oracle_fully_qualified_name("EMPLOYEES") == "EMPLOYEES"

    def test_three_part_with_empty_middle_segment(self):
        parser = _oracle_parser()
        assert (
            parser._normalize_oracle_fully_qualified_name("CONNECT..EMPLOYEES")
            == "EMPLOYEES"
        )

    def test_parse_tables_stores_normalized_two_part_fqn(self):
        raw = {
            "sourcePlatform": "oracle",
            "tables": [{"fullyQualifiedName": "CONNECT.HR.EMPLOYEES"}],
        }
        tables = ValidationConfigurationParser(raw).parse_tables()
        assert len(tables) == 1
        assert tables[0].fully_qualified_name == "HR.EMPLOYEES"

    def test_parse_tables_two_part_unchanged(self):
        raw = {
            "sourcePlatform": "oracle",
            "tables": [{"fullyQualifiedName": "HR.EMPLOYEES"}],
        }
        tables = ValidationConfigurationParser(raw).parse_tables()
        assert tables[0].fully_qualified_name == "HR.EMPLOYEES"
