"""
Tests for TaskChainCreator.

This module tests the TaskChainCreator class, particularly the UNLOAD
extraction strategy support.
"""

import pytest
from unittest.mock import MagicMock, AsyncMock

from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    ExtractionConfig,
    TableConfiguration,
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.exceptions.unsupported_extraction_strategy_error import (
    UnsupportedExtractionStrategyError,
)
from data_migration_orchestrator.data_migration_cloud.platforms.redshift.query_builder import (
    RedshiftQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.platforms.teradata.query_builder import (
    TeradataQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_boundary_generator import (
    PartitionBoundary,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    TargetType,
)
from data_migration_orchestrator.data_migration_cloud.tasks.task_chain_creator import (
    PartitionInput,
    TaskChainContext,
    TaskChainCreator,
)
from shared.enums.source_type import SourceType


class TestTaskChainCreatorUnloadStrategy:
    """Tests for UNLOAD extraction strategy in TaskChainCreator."""

    @pytest.fixture
    def source_table(self):
        """Create a sample source table identifier."""
        return TableIdentifier(
            database_name="test_db",
            schema_name="test_schema",
            table_name="test_table",
        )

    @pytest.fixture
    def target_table(self):
        """Create a sample target table identifier."""
        return TableIdentifier(
            database_name="SNOWFLAKE_DB",
            schema_name="PUBLIC",
            table_name="TEST_TABLE",
        )

    @pytest.fixture
    def source_schema(self):
        """Create a sample source schema."""
        return [
            {"column_name": "id", "data_type": "INTEGER"},
            {"column_name": "name", "data_type": "VARCHAR"},
            {"column_name": "created_at", "data_type": "TIMESTAMP"},
        ]

    @pytest.fixture
    def partition_input(self):
        """Create a sample partition input."""
        return PartitionInput(
            partition_index=1,
            partition_metadata_id=100,
            partition_boundary=PartitionBoundary(
                partition_index=1,
                where_clause="id >= 1 AND id < 1000",
                min_value=1,
                max_value=999,
                row_count=999,
            ),
            sync_data=None,
        )

    @pytest.fixture
    def mock_redshift_platform(self):
        """Create a mock Redshift platform with RedshiftQueryBuilder."""
        platform = MagicMock()
        platform.name = SourceType.REDSHIFT.value

        # Use actual RedshiftQueryBuilder for realistic query generation
        query_builder = RedshiftQueryBuilder()
        platform.query_builder = query_builder
        platform.build_normalized_table_name = MagicMock(
            return_value="test_db.test_schema.test_table"
        )

        return platform

    @pytest.fixture
    def mock_non_redshift_platform(self):
        """Create a mock non-Redshift platform (e.g., SQL Server)."""
        platform = MagicMock()
        platform.name = SourceType.SQLSERVER.value

        # Mock query builder that is NOT a RedshiftQueryBuilder
        query_builder = MagicMock()
        query_builder.build_use_database_command = MagicMock(return_value=None)
        platform.query_builder = query_builder
        platform.build_normalized_table_name = MagicMock(
            return_value="test_db.test_schema.test_table"
        )

        # Non-Redshift platforms don't support UNLOAD strategy
        platform.supports_strategy = MagicMock(return_value=False)

        return platform

    @pytest.fixture
    def mock_task_queue(self):
        """Create a mock task queue."""
        task_queue = MagicMock()
        task_queue.push_task_chain = AsyncMock(return_value=[1, 2])
        return task_queue

    def test_build_unload_extraction_payload_with_redshift(
        self,
        source_table,
        target_table,
        source_schema,
        partition_input,
        mock_redshift_platform,
        mock_task_queue,
    ):
        """Test that UNLOAD extraction task is correctly built for Redshift platform."""
        table_config = TableConfiguration(
            source=source_table,
            target=target_table,
            extraction=ExtractionConfig(
                strategy=ExtractionStrategy.UNLOAD,
                external_stage="@MY_DB.MY_SCHEMA.S3_STAGE",
            ),
        )

        context = TaskChainContext(
            workflow_id=42,
            table_metadata_id=123,
            table_config=table_config,
            source_schema=source_schema,
            suggested_batch_size=None,
            strategy_config={
                "s3_bucket": "test-bucket",
                "iam_role_arn": "arn:aws:iam::123456789012:role/test",
            },
        )

        creator = TaskChainCreator(
            platform=mock_redshift_platform,
            task_queue=mock_task_queue,
            task_chain_context=context,
        )

        # Call the internal method directly for focused testing
        payload = creator._build_data_extraction_payload(partition_input)

        # Verify the payload is configured for S3 UNLOAD
        assert payload.target_type == TargetType.S3_UNLOAD
        assert payload.source_type == SourceType.REDSHIFT.value
        assert payload.database == "test_db"
        assert payload.schema == "test_schema"
        assert payload.is_bulk_operation is True

        # Verify target_id is a relative path (DEA prepends S3 bucket)
        assert (
            "task_results/workflows/42/tables/123/data/partition_1/"
            in payload.target_id
        )
        assert not payload.target_id.startswith("@")  # Should not have stage prefix
        assert not payload.target_id.startswith("s3://")  # Should not have S3 prefix

        # Verify statement_location_id contains the SELECT query
        assert "SELECT" in payload.statement_location_id
        assert (
            "test_schema" in payload.statement_location_id
            or "test_table" in payload.statement_location_id
        )

    def test_build_unload_extraction_raises_for_non_redshift_platform(
        self,
        source_table,
        target_table,
        source_schema,
        partition_input,
        mock_non_redshift_platform,
        mock_task_queue,
    ):
        """Test that UNLOAD strategy raises error for non-Redshift platforms."""
        table_config = TableConfiguration(
            source=source_table,
            target=target_table,
            extraction=ExtractionConfig(
                strategy=ExtractionStrategy.UNLOAD,
                external_stage="@MY_DB.MY_SCHEMA.S3_STAGE",
            ),
        )

        context = TaskChainContext(
            workflow_id=42,
            table_metadata_id=123,
            table_config=table_config,
            source_schema=source_schema,
            suggested_batch_size=None,
        )

        creator = TaskChainCreator(
            platform=mock_non_redshift_platform,
            task_queue=mock_task_queue,
            task_chain_context=context,
        )

        # Verify that attempting UNLOAD with non-Redshift platform raises error
        with pytest.raises(UnsupportedExtractionStrategyError) as exc_info:
            creator._build_data_extraction_payload(partition_input)

        assert exc_info.value.extraction_strategy_name == "UNLOAD"
        assert exc_info.value.platform_name == SourceType.SQLSERVER.value
        assert "UNLOAD" in str(exc_info.value)
        assert SourceType.SQLSERVER.value in str(exc_info.value)


class TestTaskChainCreatorWriteNosStrategy:
    """Tests for WRITE_NOS extraction strategy in TaskChainCreator."""

    @pytest.fixture
    def source_table(self):
        return TableIdentifier(
            database_name="ecommerce",
            schema_name="ecommerce",
            table_name="customers",
        )

    @pytest.fixture
    def target_table(self):
        return TableIdentifier(
            database_name="DBABB",
            schema_name="ECOMMERCE_TD_WRITENOS",
            table_name="CUSTOMERS",
        )

    @pytest.fixture
    def source_schema(self):
        return [
            {"column_name": "id", "data_type": "INTEGER"},
            {"column_name": "name", "data_type": "VARCHAR"},
        ]

    @pytest.fixture
    def partition_input(self):
        return PartitionInput(
            partition_index=2,
            partition_metadata_id=200,
            partition_boundary=PartitionBoundary(
                partition_index=2,
                where_clause="id >= 1000 AND id < 2000",
                min_value=1000,
                max_value=1999,
                row_count=1000,
            ),
            sync_data=None,
        )

    @pytest.fixture
    def mock_teradata_platform(self):
        """Real TeradataQueryBuilder wrapped in a MagicMock platform."""
        platform = MagicMock()
        platform.name = SourceType.TERADATA.value
        platform.query_builder = TeradataQueryBuilder()
        # Real Teradata supports WRITE_NOS.
        platform.supports_strategy = MagicMock(return_value=True)
        return platform

    @pytest.fixture
    def mock_non_teradata_platform(self):
        """Mock platform that does NOT support WRITE_NOS (e.g., SQL Server)."""
        platform = MagicMock()
        platform.name = SourceType.SQLSERVER.value
        query_builder = MagicMock()
        query_builder.build_use_database_command = MagicMock(return_value=None)
        platform.query_builder = query_builder
        platform.supports_strategy = MagicMock(return_value=False)
        return platform

    @pytest.fixture
    def mock_task_queue(self):
        task_queue = MagicMock()
        task_queue.push_task_chain = AsyncMock(return_value=[1, 2])
        return task_queue

    def test_build_write_nos_extraction_payload_with_teradata(
        self,
        source_table,
        target_table,
        source_schema,
        partition_input,
        mock_teradata_platform,
        mock_task_queue,
    ):
        """WRITE_NOS extraction task is correctly built for Teradata."""
        table_config = TableConfiguration(
            source=source_table,
            target=target_table,
            extraction=ExtractionConfig(
                strategy=ExtractionStrategy.WRITE_NOS,
                external_stage="@DBABB.ECOMMERCE_TD_WRITENOS.TD_NOS_STAGE",
            ),
        )

        context = TaskChainContext(
            workflow_id=7,
            table_metadata_id=11,
            table_config=table_config,
            source_schema=source_schema,
            suggested_batch_size=None,
        )

        creator = TaskChainCreator(
            platform=mock_teradata_platform,
            task_queue=mock_task_queue,
            task_chain_context=context,
        )

        payload = creator._build_data_extraction_payload(partition_input)

        # Target shape mirrors UNLOAD: relative path, DEA fills in the cloud
        # location and the source platform writes Parquet itself.
        assert payload.target_type == TargetType.WRITE_NOS
        assert payload.source_type == SourceType.TERADATA.value
        assert (
            "task_results/workflows/7/tables/11/data/partition_2/" in payload.target_id
        )
        assert not payload.target_id.startswith("@")
        # WRITE_NOS does not need a suggested batch size; Teradata sizes its
        # own output via MAXOBJECTSIZE.
        assert payload.suggested_batch_size is None
        assert payload.is_bulk_operation is True
        assert "SELECT" in payload.statement_location_id

    def test_build_write_nos_extraction_raises_for_unsupported_platform(
        self,
        source_table,
        target_table,
        source_schema,
        partition_input,
        mock_non_teradata_platform,
        mock_task_queue,
    ):
        """WRITE_NOS strategy raises for non-Teradata platforms."""
        table_config = TableConfiguration(
            source=source_table,
            target=target_table,
            extraction=ExtractionConfig(
                strategy=ExtractionStrategy.WRITE_NOS,
                external_stage="@DBABB.SCHEMA.STAGE",
            ),
        )

        context = TaskChainContext(
            workflow_id=7,
            table_metadata_id=11,
            table_config=table_config,
            source_schema=source_schema,
            suggested_batch_size=None,
        )

        creator = TaskChainCreator(
            platform=mock_non_teradata_platform,
            task_queue=mock_task_queue,
            task_chain_context=context,
        )

        with pytest.raises(UnsupportedExtractionStrategyError) as exc_info:
            creator._build_data_extraction_payload(partition_input)

        assert exc_info.value.extraction_strategy_name == "WRITE_NOS"
        assert exc_info.value.platform_name == SourceType.SQLSERVER.value
        assert "WRITE_NOS" in str(exc_info.value)


class TestTaskChainCreatorTeradataRegularBulk:
    """Teradata REGULAR extraction uses internal stage (TPT is DEA-side when tpt_* is set)."""

    @pytest.fixture
    def source_table(self):
        return TableIdentifier(
            database_name="ecommerce",
            schema_name="ecommerce",
            table_name="customers",
        )

    @pytest.fixture
    def target_table(self):
        return TableIdentifier(
            database_name="DBABB",
            schema_name="ECOMMERCE_TD_TPT",
            table_name="CUSTOMERS",
        )

    @pytest.fixture
    def source_schema(self):
        return [
            {"column_name": "id", "data_type": "INTEGER"},
            {"column_name": "name", "data_type": "VARCHAR"},
        ]

    @pytest.fixture
    def partition_input(self):
        return PartitionInput(
            partition_index=2,
            partition_metadata_id=200,
            partition_boundary=PartitionBoundary(
                partition_index=2,
                where_clause="id >= 1000 AND id < 2000",
                min_value=1000,
                max_value=1999,
                row_count=1000,
            ),
            sync_data=None,
        )

    @pytest.fixture
    def mock_teradata_platform(self):
        platform = MagicMock()
        platform.name = SourceType.TERADATA.value
        platform.query_builder = TeradataQueryBuilder()
        platform.supports_strategy = MagicMock(return_value=True)
        return platform

    @pytest.fixture
    def mock_task_queue(self):
        task_queue = MagicMock()
        task_queue.push_task_chain = AsyncMock(return_value=[1, 2])
        return task_queue

    def test_build_teradata_regular_payload_uses_internal_stage(
        self,
        source_table,
        target_table,
        source_schema,
        partition_input,
        mock_teradata_platform,
        mock_task_queue,
    ):
        """REGULAR extraction uses snowflake:stage target (same path convention as ODBC/TPT bulk)."""
        table_config = TableConfiguration(
            source=source_table,
            target=target_table,
            extraction=ExtractionConfig(strategy=ExtractionStrategy.REGULAR),
        )

        context = TaskChainContext(
            workflow_id=7,
            table_metadata_id=11,
            table_config=table_config,
            source_schema=source_schema,
            suggested_batch_size=50000,
        )

        creator = TaskChainCreator(
            platform=mock_teradata_platform,
            task_queue=mock_task_queue,
            task_chain_context=context,
        )

        payload = creator._build_data_extraction_payload(partition_input)

        assert payload.target_type == TargetType.SNOWFLAKE_STAGE
        assert payload.source_type == SourceType.TERADATA.value
        assert payload.target_id.startswith("@")
        assert (
            "task_results/workflows/7/tables/11/data/partition_2/" in payload.target_id
        )
        assert payload.suggested_batch_size == 50000
        assert payload.is_bulk_operation is True
        assert payload.extraction_strategy == "regular"
        assert "SELECT" in payload.statement_location_id
