"""Tests for ``data_migration_orchestrator.utils.dashboard_aggregation``."""

from __future__ import annotations

import pandas as pd

from data_migration_orchestrator.utils.dashboard_aggregation import (
    COL_CLOUD_STAGE,
    COL_EXAMPLE_ERROR,
    COL_EXTRACTING,
    COL_FAILED_PARTITIONS,
    COL_LAST_ERROR_MESSAGE,
    COL_LATEST_WORKFLOW_ID,
    COL_LOADED_PARTITIONS,
    COL_LOADING,
    COL_PROGRESS_PCT,
    COL_RUNS_COUNT,
    COL_STATUS,
    COL_TABLE_NAME,
    COL_TOTAL_PARTITIONS,
    COL_TOTAL_ROWS,
    COL_VALIDATION_STATUS,
    COL_WORKFLOW_ID,
    STATUS_COMPLETE,
    STATUS_FAILED,
    STATUS_IN_PROGRESS,
    STATUS_NOT_STARTED,
    aggregate_migration_tables_by_name,
    aggregate_validation_tables_by_name,
    compute_migration_progress_pct,
    compute_migration_row_status,
    compute_validation_progress_pct,
    compute_validation_timing,
    filter_by_table_search,
    format_duration_seconds,
)


def _migration_row(
    workflow_id: int,
    table_name: str,
    *,
    total: int = 0,
    loaded: int = 0,
    failed: int = 0,
    extracting: int = 0,
    loading: int = 0,
    total_rows: int | None = 0,
    cloud_stage: str | None = None,
    error: str | None = None,
) -> dict:
    return {
        COL_WORKFLOW_ID: workflow_id,
        COL_TABLE_NAME: table_name,
        COL_TOTAL_PARTITIONS: total,
        COL_LOADED_PARTITIONS: loaded,
        COL_FAILED_PARTITIONS: failed,
        COL_EXTRACTING: extracting,
        COL_LOADING: loading,
        COL_TOTAL_ROWS: total_rows,
        COL_CLOUD_STAGE: cloud_stage,
        COL_EXAMPLE_ERROR: error,
    }


class TestComputeMigrationRowStatus:
    """Tests for the vectorized per-row migration status helper."""

    def test_failed_wins_over_complete(self):
        status = compute_migration_row_status(
            pd.Series([10]), pd.Series([10]), pd.Series([1])
        )
        assert status.tolist() == [STATUS_FAILED]

    def test_complete_when_all_loaded(self):
        status = compute_migration_row_status(
            pd.Series([5]), pd.Series([5]), pd.Series([0])
        )
        assert status.tolist() == [STATUS_COMPLETE]

    def test_not_started_when_zero_total(self):
        status = compute_migration_row_status(
            pd.Series([0]), pd.Series([0]), pd.Series([0])
        )
        assert status.tolist() == [STATUS_NOT_STARTED]

    def test_in_progress_when_partial(self):
        status = compute_migration_row_status(
            pd.Series([10]), pd.Series([3]), pd.Series([0])
        )
        assert status.tolist() == [STATUS_IN_PROGRESS]

    def test_handles_nulls(self):
        status = compute_migration_row_status(
            pd.Series([None, 5]),
            pd.Series([None, 5]),
            pd.Series([None, 0]),
        )
        assert status.tolist() == [STATUS_NOT_STARTED, STATUS_COMPLETE]


class TestComputeMigrationProgressPct:
    """Tests for the vectorized progress-percentage helper."""

    def test_zero_total_yields_zero(self):
        pct = compute_migration_progress_pct(pd.Series([0]), pd.Series([0]))
        assert pct.tolist() == [0.0]

    def test_partial_is_rounded_to_one_decimal(self):
        pct = compute_migration_progress_pct(pd.Series([3]), pd.Series([1]))
        assert pct.tolist() == [33.3]

    def test_complete_is_100(self):
        pct = compute_migration_progress_pct(pd.Series([7]), pd.Series([7]))
        assert pct.tolist() == [100.0]


class TestFilterByTableSearch:
    """Tests for the table-name substring filter."""

    def test_empty_search_returns_input(self):
        df = pd.DataFrame({COL_TABLE_NAME: ["a", "b"]})
        out = filter_by_table_search(df, "")
        assert list(out[COL_TABLE_NAME]) == ["a", "b"]

    def test_whitespace_search_returns_input(self):
        df = pd.DataFrame({COL_TABLE_NAME: ["a", "b"]})
        out = filter_by_table_search(df, "   ")
        assert list(out[COL_TABLE_NAME]) == ["a", "b"]

    def test_case_insensitive_substring(self):
        df = pd.DataFrame({COL_TABLE_NAME: ["DB.SALES", "DB.ORDERS", "DB.PRODUCTS"]})
        out = filter_by_table_search(df, "order")
        assert list(out[COL_TABLE_NAME]) == ["DB.ORDERS"]

    def test_handles_missing_column(self):
        df = pd.DataFrame({"OTHER": ["a", "b"]})
        out = filter_by_table_search(df, "a")
        assert len(out) == 2  # unchanged

    def test_handles_empty_frame(self):
        out = filter_by_table_search(pd.DataFrame(), "x")
        assert len(out) == 0


class TestAggregateMigrationTablesByName:
    """Tests for the cross-workflow table aggregation."""

    def test_empty_input_returns_empty_schema(self):
        out = aggregate_migration_tables_by_name(pd.DataFrame())
        for col in (
            COL_TABLE_NAME,
            COL_STATUS,
            COL_LATEST_WORKFLOW_ID,
            COL_RUNS_COUNT,
        ):
            assert col in out.columns
        assert len(out) == 0

    def test_single_workflow_single_table(self):
        df = pd.DataFrame(
            [_migration_row(10, "DB.T1", total=5, loaded=5, total_rows=1000)]
        )
        out = aggregate_migration_tables_by_name(df)
        assert len(out) == 1
        row = out.iloc[0]
        assert row[COL_TABLE_NAME] == "DB.T1"
        assert row[COL_STATUS] == STATUS_COMPLETE
        assert row[COL_LATEST_WORKFLOW_ID] == 10
        assert row[COL_RUNS_COUNT] == 1
        assert row[COL_TOTAL_ROWS] == 1000
        assert row[COL_PROGRESS_PCT] == 100.0

    def test_latest_workflow_wins_for_status(self):
        # Older workflow failed, newer workflow succeeded: latest wins.
        df = pd.DataFrame(
            [
                _migration_row(5, "DB.T1", total=3, loaded=0, failed=3),
                _migration_row(10, "DB.T1", total=3, loaded=3),
            ]
        )
        out = aggregate_migration_tables_by_name(df)
        row = out.iloc[0]
        assert row[COL_STATUS] == STATUS_COMPLETE
        assert row[COL_LATEST_WORKFLOW_ID] == 10
        assert row[COL_RUNS_COUNT] == 2

    def test_latest_error_message_picked_across_runs(self):
        df = pd.DataFrame(
            [
                _migration_row(3, "DB.T1", total=1, loaded=1, error="old err"),
                _migration_row(
                    7, "DB.T1", total=1, loaded=0, failed=1, error="new err"
                ),
            ]
        )
        out = aggregate_migration_tables_by_name(df)
        assert out.iloc[0][COL_LAST_ERROR_MESSAGE] == "new err"

    def test_failed_sorted_before_in_progress_before_complete(self):
        df = pd.DataFrame(
            [
                _migration_row(1, "AAA", total=5, loaded=5),  # complete
                _migration_row(1, "BBB", total=5, loaded=2),  # in progress
                _migration_row(1, "CCC", total=5, loaded=0, failed=1),  # failed
            ]
        )
        out = aggregate_migration_tables_by_name(df)
        assert list(out[COL_TABLE_NAME]) == ["CCC", "BBB", "AAA"]

    def test_alphabetical_within_same_status(self):
        df = pd.DataFrame(
            [
                _migration_row(1, "ZED", total=5, loaded=5),
                _migration_row(1, "APPLE", total=5, loaded=5),
                _migration_row(1, "MANGO", total=5, loaded=5),
            ]
        )
        out = aggregate_migration_tables_by_name(df)
        assert list(out[COL_TABLE_NAME]) == ["APPLE", "MANGO", "ZED"]

    def test_runs_count_is_distinct_workflow_ids(self):
        df = pd.DataFrame(
            [
                _migration_row(1, "DB.T1", total=2, loaded=2),
                _migration_row(1, "DB.T1", total=2, loaded=2),  # duplicate id
                _migration_row(2, "DB.T1", total=2, loaded=2),
            ]
        )
        out = aggregate_migration_tables_by_name(df)
        assert out.iloc[0][COL_RUNS_COUNT] == 2

    def test_missing_total_rows_column_defaults_to_zero(self):
        df = pd.DataFrame(
            [
                {
                    COL_WORKFLOW_ID: 1,
                    COL_TABLE_NAME: "DB.T1",
                    COL_TOTAL_PARTITIONS: 2,
                    COL_LOADED_PARTITIONS: 2,
                    COL_FAILED_PARTITIONS: 0,
                    COL_EXTRACTING: 0,
                    COL_LOADING: 0,
                }
            ]
        )
        out = aggregate_migration_tables_by_name(df)
        assert out.iloc[0][COL_TOTAL_ROWS] == 0

    def test_null_error_message_is_ignored(self):
        df = pd.DataFrame(
            [
                _migration_row(3, "DB.T1", total=1, loaded=1, error=None),
                _migration_row(7, "DB.T1", total=1, loaded=1, error=""),
            ]
        )
        out = aggregate_migration_tables_by_name(df)
        assert out.iloc[0][COL_LAST_ERROR_MESSAGE] is None

    def test_cloud_stage_latest_wins(self):
        df = pd.DataFrame(
            [
                _migration_row(1, "DB.T1", total=1, loaded=1, cloud_stage="old_stage"),
                _migration_row(9, "DB.T1", total=1, loaded=1, cloud_stage="new_stage"),
            ]
        )
        out = aggregate_migration_tables_by_name(df)
        assert out.iloc[0][COL_CLOUD_STAGE] == "new_stage"


class TestAggregateValidationTablesByName:
    """Tests for the cross-workflow validation aggregation."""

    def _vrow(
        self,
        workflow_id: int,
        name: str,
        *,
        schema: bool = False,
        metrics: bool = False,
        rows: bool = False,
        status: str = "pending",
        error: str | None = None,
    ) -> dict:
        return {
            COL_WORKFLOW_ID: workflow_id,
            COL_TABLE_NAME: name,
            "SCHEMA_VALIDATED": schema,
            "METRICS_VALIDATED": metrics,
            "ROWS_VALIDATED": rows,
            COL_VALIDATION_STATUS: status,
            "ERROR_MESSAGE": error,
        }

    def test_empty_input_returns_empty_schema(self):
        out = aggregate_validation_tables_by_name(pd.DataFrame())
        assert COL_TABLE_NAME in out.columns
        assert len(out) == 0

    def test_latest_run_wins(self):
        df = pd.DataFrame(
            [
                self._vrow(3, "DB.T1", status="failed", error="old fail"),
                self._vrow(
                    7, "DB.T1", status="validated", schema=True, metrics=True, rows=True
                ),
            ]
        )
        out = aggregate_validation_tables_by_name(df)
        assert out.iloc[0][COL_VALIDATION_STATUS] == "validated"
        assert out.iloc[0][COL_LATEST_WORKFLOW_ID] == 7
        assert out.iloc[0][COL_LAST_ERROR_MESSAGE] == "old fail"

    def test_failed_sorted_before_pending_before_validated(self):
        df = pd.DataFrame(
            [
                self._vrow(1, "AA", status="validated"),
                self._vrow(1, "BB", status="pending"),
                self._vrow(1, "CC", status="failed"),
            ]
        )
        out = aggregate_validation_tables_by_name(df)
        assert list(out[COL_TABLE_NAME]) == ["CC", "BB", "AA"]


class TestComputeValidationProgressPct:
    """Tests for ``compute_validation_progress_pct``."""

    def test_zero_total_yields_zero(self):
        pct = compute_validation_progress_pct(
            pd.Series([0]), pd.Series([0]), pd.Series([0])
        )
        assert pct.tolist() == [0.0]

    def test_l2_only_plateaus_near_50(self):
        # All L2 done, no L3 progress: 10 / (2*10) = 50%
        pct = compute_validation_progress_pct(
            pd.Series([10]), pd.Series([0]), pd.Series([10])
        )
        assert pct.tolist() == [50.0]

    def test_full_completion_is_100(self):
        pct = compute_validation_progress_pct(
            pd.Series([10]), pd.Series([10]), pd.Series([10])
        )
        assert pct.tolist() == [100.0]

    def test_partial_is_rounded_to_one_decimal(self):
        # (3 + 2) / (2 * 10) * 100 = 25.0
        pct = compute_validation_progress_pct(
            pd.Series([3]), pd.Series([2]), pd.Series([10])
        )
        assert pct.tolist() == [25.0]

    def test_handles_nulls(self):
        pct = compute_validation_progress_pct(
            pd.Series([None, 5]),
            pd.Series([None, 5]),
            pd.Series([None, 10]),
        )
        # First row: total=0 -> 0; second row: 10 / 20 * 100 = 50
        assert pct.tolist() == [0.0, 50.0]

    def test_vectorized_across_multiple_rows(self):
        pct = compute_validation_progress_pct(
            pd.Series([0, 5, 10]),
            pd.Series([0, 0, 10]),
            pd.Series([10, 10, 10]),
        )
        assert pct.tolist() == [0.0, 25.0, 100.0]


class TestComputeValidationTiming:
    """Tests for ``compute_validation_timing`` (deterministic via injected ``now``)."""

    _NOW = pd.Timestamp("2026-05-01 12:00:00")

    def test_in_progress_uses_now_for_elapsed(self):
        # Started 1h ago, in progress -> elapsed=3600
        elapsed, eta = compute_validation_timing(
            pd.Series([pd.Timestamp("2026-05-01 11:00:00")]),
            pd.Series([pd.NaT]),
            pd.Series(["IN_PROGRESS"]),
            pd.Series([50.0]),
            now=self._NOW,
        )
        assert elapsed.tolist() == [3600.0]
        # 50% done in 1h -> ETA ~= 1h remaining
        assert eta.tolist() == [3600.0]

    def test_terminal_uses_updated_at_for_elapsed(self):
        # Completed at +30 min from start
        elapsed, eta = compute_validation_timing(
            pd.Series([pd.Timestamp("2026-05-01 10:00:00")]),
            pd.Series([pd.Timestamp("2026-05-01 10:30:00")]),
            pd.Series(["COMPLETED"]),
            pd.Series([100.0]),
            now=self._NOW,
        )
        assert elapsed.tolist() == [1800.0]
        # Terminal -> ETA is NaN
        assert pd.isna(eta.iloc[0])

    def test_failed_is_terminal(self):
        elapsed, eta = compute_validation_timing(
            pd.Series([pd.Timestamp("2026-05-01 10:00:00")]),
            pd.Series([pd.Timestamp("2026-05-01 10:30:00")]),
            pd.Series(["FAILED"]),
            pd.Series([60.0]),
            now=self._NOW,
        )
        assert elapsed.tolist() == [1800.0]
        assert pd.isna(eta.iloc[0])

    def test_zero_progress_yields_nan_eta(self):
        elapsed, eta = compute_validation_timing(
            pd.Series([pd.Timestamp("2026-05-01 11:30:00")]),
            pd.Series([pd.NaT]),
            pd.Series(["IN_PROGRESS"]),
            pd.Series([0.0]),
            now=self._NOW,
        )
        assert elapsed.tolist() == [1800.0]
        assert pd.isna(eta.iloc[0])

    def test_full_progress_in_flight_yields_nan_eta(self):
        # Edge case: progress == 100 but status not terminal yet
        _, eta = compute_validation_timing(
            pd.Series([pd.Timestamp("2026-05-01 11:00:00")]),
            pd.Series([pd.NaT]),
            pd.Series(["PENDING"]),
            pd.Series([100.0]),
            now=self._NOW,
        )
        assert pd.isna(eta.iloc[0])

    def test_negative_elapsed_clipped_to_zero(self):
        # CREATED_AT in the future relative to now -> negative would be wrong, clip to 0
        elapsed, _ = compute_validation_timing(
            pd.Series([pd.Timestamp("2026-05-01 13:00:00")]),
            pd.Series([pd.NaT]),
            pd.Series(["IN_PROGRESS"]),
            pd.Series([10.0]),
            now=self._NOW,
        )
        assert elapsed.tolist() == [0.0]

    def test_vectorized_mixed_statuses(self):
        elapsed, eta = compute_validation_timing(
            pd.Series(
                [
                    pd.Timestamp("2026-05-01 11:00:00"),
                    pd.Timestamp("2026-05-01 11:00:00"),
                    pd.Timestamp("2026-05-01 11:00:00"),
                ]
            ),
            pd.Series(
                [
                    pd.NaT,
                    pd.Timestamp("2026-05-01 11:30:00"),
                    pd.NaT,
                ]
            ),
            pd.Series(["IN_PROGRESS", "COMPLETED", "PENDING"]),
            pd.Series([25.0, 100.0, 0.0]),
            now=self._NOW,
        )
        # In-progress at 25% after 1h -> 3h remaining = 10800s
        assert elapsed.tolist() == [3600.0, 1800.0, 3600.0]
        assert eta.iloc[0] == 10800.0
        assert pd.isna(eta.iloc[1])
        assert pd.isna(eta.iloc[2])

    def test_tz_aware_timestamps_normalized(self):
        # tz-aware created_at should be handled the same as naive UTC
        elapsed, _ = compute_validation_timing(
            pd.Series([pd.Timestamp("2026-05-01 11:00:00", tz="UTC")]),
            pd.Series([pd.NaT]),
            pd.Series(["IN_PROGRESS"]),
            pd.Series([50.0]),
            now=self._NOW,
        )
        assert elapsed.tolist() == [3600.0]


class TestFormatDurationSeconds:
    """Tests for the human-readable duration formatter."""

    def test_none_renders_em_dash(self):
        assert format_duration_seconds(None) == "—"

    def test_nan_renders_em_dash(self):
        assert format_duration_seconds(float("nan")) == "—"

    def test_negative_renders_em_dash(self):
        assert format_duration_seconds(-1) == "—"

    def test_invalid_string_renders_em_dash(self):
        assert format_duration_seconds("not-a-number") == "—"  # type: ignore[arg-type]

    def test_seconds_only_under_a_minute(self):
        assert format_duration_seconds(0) == "0s"
        assert format_duration_seconds(45) == "45s"
        assert format_duration_seconds(59) == "59s"

    def test_minutes_only_under_an_hour(self):
        assert format_duration_seconds(60) == "1m"
        assert format_duration_seconds(125) == "2m"
        assert format_duration_seconds(3599) == "59m"

    def test_hours_and_minutes(self):
        assert format_duration_seconds(3600) == "1h 0m"
        assert format_duration_seconds(3725) == "1h 2m"
        assert format_duration_seconds(7200) == "2h 0m"
        assert format_duration_seconds(36_000) == "10h 0m"

    def test_accepts_floats(self):
        assert format_duration_seconds(3725.9) == "1h 2m"
