"""Unit tests for the hybrid L3 validation handler (row-hash + cell drill-down)."""

from __future__ import annotations

import sys
import unittest

from types import ModuleType
from unittest.mock import AsyncMock, MagicMock, patch

# Stub SDV imports required by sdv_query_helper-driven code paths.
_sdv_public = ModuleType("snowflake.snowflake_data_validation.public")
for _attr in (
    "ColumnMetadata",
    "ObjectType",
    "Origin",
    "Platform",
    "SQLQueriesTemplateGenerator",
    "TableContext",
    "TemplatesLoaderManager",
    "generate_batched_metrics_queries",
    "generate_cell_validation_data_query",
    "generate_metrics_query",
    "generate_schema_query",
    "QueryExecutionResult",
    "validate_cell",
    "MetricsResultShapeDict",
):
    setattr(_sdv_public, _attr, MagicMock())
sys.modules.setdefault("snowflake.snowflake_data_validation.public", _sdv_public)

_sdv_constants = ModuleType("snowflake.snowflake_data_validation.utils.constants")
_sdv_constants.DEFAULT_MAX_COLUMNS_PER_METRICS_BATCH = 50  # type: ignore[attr-defined]
sys.modules.setdefault(
    "snowflake.snowflake_data_validation.utils.constants", _sdv_constants
)

_sdv_helpers = ModuleType(
    "snowflake.snowflake_data_validation.utils.helpers.helper_templates"
)
_sdv_helpers.HelperTemplates = MagicMock()  # type: ignore[attr-defined]
sys.modules.setdefault(
    "snowflake.snowflake_data_validation.utils.helpers.helper_templates",
    _sdv_helpers,
)

from data_migration_orchestrator.data_validation_cloud.tasks.handlers.hybrid_validation_handler import (  # noqa: E402
    HybridValidationHandler,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (  # noqa: E402
    EvaluateLevelResultPayload,
    FinalizeHybridL3Payload,
)
from data_migration_orchestrator.data_validation_core.constants import (  # noqa: E402
    ROW_VALIDATION,
    ROW_VALIDATION_MODE_HYBRID,
)


def _make_payload(use_snowpipe: bool) -> EvaluateLevelResultPayload:
    return EvaluateLevelResultPayload(
        table_metadata_id=42,
        completed_level=ROW_VALIDATION,
        next_level=None,
        continue_on_failure=False,
        next_level_enabled=False,
        workflow_id=7,
        source_platform="teradata",
        source_identifier="db.sch.t",
        row_validation_mode=ROW_VALIDATION_MODE_HYBRID,
        use_snowpipe_for_results=use_snowpipe,
    )


class TestFetchMismatchedPartitions(unittest.IsolatedAsyncioTestCase):
    """
    Drilldown picks partitions whose ROW_VALIDATION_RESULTS show FAILUREs.

    Only ``FAILURE`` rows (key present on both sides, hashes disagree) are
    eligible for cell drill-down. ``NOT_FOUND_*`` and ``DUPLICATE_*`` rows
    are intentionally excluded from the filter — there is nothing to
    compare cell-by-cell when a row is missing on one side or duplicated.
    """

    async def test_returns_distinct_partition_numbers(self):
        tq = MagicMock()
        wh = MagicMock()
        wh.execute_sync_query = AsyncMock(
            return_value=[
                {"PARTITION_NUMBER": 0},
                {"PARTITION_NUMBER": 2},
                {"PARTITION_NUMBER": None},
            ]
        )
        handler = HybridValidationHandler(tq, wh)
        partitions = await handler.fetch_mismatched_partition_numbers(7, 42)
        self.assertEqual(partitions, [0, 2, None])
        sql_called = wh.execute_sync_query.await_args[0][0]
        self.assertIn("ROW_VALIDATION_RESULTS", sql_called)
        self.assertIn("RESULT = 'FAILURE'", sql_called)
        self.assertNotIn("NOT_FOUND_SOURCE", sql_called)
        self.assertNotIn("NOT_FOUND_TARGET", sql_called)
        self.assertNotIn("DUPLICATE_SOURCE", sql_called)
        self.assertNotIn("DUPLICATE_TARGET", sql_called)
        self.assertNotIn("DUPLICATE_BOTH_SIDES", sql_called)

    async def test_empty_when_no_mismatches(self):
        tq = MagicMock()
        wh = MagicMock()
        wh.execute_sync_query = AsyncMock(return_value=[])
        handler = HybridValidationHandler(tq, wh)
        partitions = await handler.fetch_mismatched_partition_numbers(7, 42)
        self.assertEqual(partitions, [])


class TestHybridMd5Prefetch(unittest.IsolatedAsyncioTestCase):
    """Hybrid drill-down prefetches MD5 rows once and groups by partition."""

    async def test_prefetch_groups_rows_and_uses_partition_filter(self):
        tq = MagicMock()
        wh = MagicMock()
        wh.execute_sync_query = AsyncMock(
            return_value=[
                {
                    "PARTITION_NUMBER": 1,
                    "SOURCE_INDEX_VALUES": "ID=1",
                    "TARGET_INDEX_VALUES": "ID=1",
                },
                {
                    "PARTITION_NUMBER": None,
                    "SOURCE_INDEX_VALUES": "ID=2",
                    "TARGET_INDEX_VALUES": "ID=2",
                },
            ]
        )
        handler = HybridValidationHandler(tq, wh)
        grouped = await handler._prefetch_md5_failure_rows_by_partition(
            workflow_id=7,
            table_metadata_id=42,
            source_table_fqn="db.sch.t",
            partition_numbers=[1, None],
        )
        self.assertIn(1, grouped)
        self.assertIn(None, grouped)
        sql_called = wh.execute_sync_query.await_args[0][0]
        self.assertIn("PARTITION_NUMBER IN (1)", sql_called)
        self.assertIn("PARTITION_NUMBER IS NULL", sql_called)


class TestPushCellDrilldown(unittest.IsolatedAsyncioTestCase):
    """Drilldown pushes one finalize task wired to a cell snowpipe chain."""

    async def test_returns_none_for_empty_partition_list(self):
        tq = MagicMock()
        wh = MagicMock()
        handler = HybridValidationHandler(tq, wh)
        result = await handler.push_cell_drilldown_for_partitions(
            _make_payload(use_snowpipe=True), []
        )
        self.assertIsNone(result)

    async def test_snowpipe_path_pushes_finalize_with_cell_chain(self):
        tq = MagicMock()
        tq.push_task = AsyncMock(return_value=888)
        tq.push_independent_two_task_chains = AsyncMock()
        tq.push_tasks_batch = AsyncMock()
        wh = MagicMock()
        wh.execute_sync_query = AsyncMock(return_value=[])
        handler = HybridValidationHandler(tq, wh)

        chain = MagicMock()
        chain.entry_task_id = 555
        chain.pipe_entries = []
        with (
            patch.object(
                handler, "_fetch_table_config", new=AsyncMock(return_value={})
            ),
            patch.object(
                handler,
                "_fetch_metrics_column_metadata",
                new=AsyncMock(return_value=None),
            ),
            patch.object(
                handler,
                "_get_partition_map",
                new=AsyncMock(
                    return_value={
                        0: {"PARTITION_NUMBER": 0},
                        2: {"PARTITION_NUMBER": 2},
                    }
                ),
            ),
            patch.object(
                handler,
                "_prefetch_md5_failure_rows_by_partition",
                new=AsyncMock(return_value={}),
            ),
            patch.object(
                handler,
                "_build_cell_tasks_for_partition",
                new=MagicMock(
                    side_effect=[
                        (MagicMock(name="dea_0"), None),
                        (MagicMock(name="dea_2"), None),
                    ]
                ),
            ) as mock_build_cell,
            patch(
                "data_migration_orchestrator.data_validation_cloud.tasks.handlers.hybrid_validation_handler.build_snowpipe_level_chain",
                new=AsyncMock(return_value=chain),
            ) as mock_chain,
        ):
            result = await handler.push_cell_drilldown_for_partitions(
                _make_payload(use_snowpipe=True), [0, 2]
            )

        self.assertEqual(result, 888)
        mock_chain.assert_awaited_once()
        chain_kwargs = mock_chain.await_args.kwargs
        self.assertEqual(chain_kwargs["level"], "cell")
        self.assertEqual(chain_kwargs["evaluate_task_id"], 888)

        self.assertEqual(mock_build_cell.call_count, 2)
        tq.push_tasks_batch.assert_awaited_once()
        tq.push_independent_two_task_chains.assert_not_awaited()

        finalize_task = tq.push_task.await_args_list[0][0][0]
        self.assertIsInstance(finalize_task.payload, FinalizeHybridL3Payload)
        self.assertEqual(finalize_task.payload.workflow_id, 7)
        self.assertEqual(finalize_task.payload.table_metadata_id, 42)
        self.assertEqual(finalize_task.payload.source_identifier, "db.sch.t")

    async def test_non_snowpipe_path_uses_finalize_as_successor(self):
        tq = MagicMock()
        tq.push_task = AsyncMock(return_value=888)
        tq.push_independent_two_task_chains = AsyncMock()
        tq.push_tasks_batch = AsyncMock()
        wh = MagicMock()
        wh.execute_sync_query = AsyncMock(return_value=[])
        handler = HybridValidationHandler(tq, wh)

        with (
            patch.object(
                handler, "_fetch_table_config", new=AsyncMock(return_value={})
            ),
            patch.object(
                handler,
                "_fetch_metrics_column_metadata",
                new=AsyncMock(return_value=None),
            ),
            patch.object(
                handler,
                "_get_partition_map",
                new=AsyncMock(return_value={3: {"PARTITION_NUMBER": 3}}),
            ),
            patch.object(
                handler,
                "_prefetch_md5_failure_rows_by_partition",
                new=AsyncMock(return_value={}),
            ),
            patch.object(
                handler,
                "_build_cell_tasks_for_partition",
                new=MagicMock(
                    return_value=(MagicMock(name="dea"), MagicMock(name="write"))
                ),
            ) as mock_build_cell,
            patch(
                "data_migration_orchestrator.data_validation_cloud.tasks.handlers.hybrid_validation_handler.build_snowpipe_level_chain",
                new=AsyncMock(),
            ) as mock_chain,
        ):
            result = await handler.push_cell_drilldown_for_partitions(
                _make_payload(use_snowpipe=False), [3]
            )

        self.assertEqual(result, 888)
        mock_chain.assert_not_awaited()
        mock_build_cell.assert_called_once()
        tq.push_tasks_batch.assert_not_awaited()
        tq.push_independent_two_task_chains.assert_awaited_once()


class TestFinalizeNoMismatchInline(unittest.IsolatedAsyncioTestCase):
    """Inline finalize marks every partition L3_STATUS=valid and table COMPLETED."""

    async def test_sets_status_and_table_completed(self):
        tq = MagicMock()
        wh = MagicMock()
        wh.execute_sync_query = AsyncMock()
        handler = HybridValidationHandler(tq, wh)

        with patch(
            "data_migration_orchestrator.data_validation_cloud.partition_progress.bulk_set_partition_level_status",
            new=AsyncMock(),
        ) as mock_bulk:
            await handler.finalize_no_mismatch_inline(_make_payload(use_snowpipe=True))

        mock_bulk.assert_awaited_once()
        self.assertEqual(mock_bulk.await_args.kwargs["column"], "L3_STATUS")
        wh.execute_sync_query.assert_awaited_once()
        sql = wh.execute_sync_query.await_args[0][0]
        self.assertIn("UPDATE_TABLE_VALIDATION_STATUS", sql)
        self.assertIn("COMPLETED", sql)


if __name__ == "__main__":
    unittest.main()
