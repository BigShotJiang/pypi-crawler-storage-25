"""Unit tests for partition_metadata_bulk_sql."""

import pytest

from data_migration_orchestrator.utils.partition_metadata_bulk_sql import (
    PARTITION_METADATA_INSERT_CHUNK_SIZE,
    build_bulk_insert_partition_metadata_sql,
    format_sql_literal_for_values,
    iter_bulk_insert_partition_metadata_sqls,
)


class TestFormatSqlLiteralForValues:
    """Tests for format_sql_literal_for_values."""

    def test_none(self):
        assert format_sql_literal_for_values(None) == "NULL"

    def test_bool(self):
        assert format_sql_literal_for_values(True) == "TRUE"
        assert format_sql_literal_for_values(False) == "FALSE"

    def test_int_float(self):
        assert format_sql_literal_for_values(42) == "42"
        assert format_sql_literal_for_values(3.14) == "3.14"

    def test_numeric_strings_unquoted(self):
        assert format_sql_literal_for_values("123") == "123"
        assert format_sql_literal_for_values("45.67") == "45.67"

    def test_string_quoted(self):
        assert format_sql_literal_for_values("hello") == "'hello'"

    def test_escapes_quotes(self):
        assert format_sql_literal_for_values("it's") == "'it''s'"


class TestBuildBulkInsertPartitionMetadataSql:
    """Tests for build_bulk_insert_partition_metadata_sql."""

    def test_empty_raises(self):
        with pytest.raises(ValueError, match="non-empty"):
            build_bulk_insert_partition_metadata_sql(
                "DB.SCH",
                1,
                [],
                status_column="MIGRATION_STATUS",
                status_sql_literal="'EXTRACTING'",
            )

    def test_migration_shape(self):
        sql = build_bulk_insert_partition_metadata_sql(
            "MIG.SCHEMA",
            10,
            [(0, None, None, None), (1, 1, 100, None)],
            status_column="MIGRATION_STATUS",
            status_sql_literal="'EXTRACTING'",
        )
        assert "INSERT INTO MIG.SCHEMA.PARTITION_METADATA" in sql
        assert "MIGRATION_STATUS" in sql
        assert "MIG.SCHEMA.PARTITION_METADATA_ID_SEQ.NEXTVAL" in sql
        assert "FROM VALUES" in sql
        assert "(10, 0, NULL, NULL, NULL, 'EXTRACTING')" in sql
        assert "(10, 1, 1, 100, NULL, 'EXTRACTING')" in sql
        assert "TO_VARIANT(column3)" in sql
        assert "TO_VARIANT(column4)" in sql

    def test_validation_shape(self):
        sql = build_bulk_insert_partition_metadata_sql(
            "DV.SCHEMA",
            7,
            [(1, None, None, None)],
            status_column="VALIDATION_STATUS",
            status_sql_literal="'PENDING'",
        )
        assert "INSERT INTO DV.SCHEMA.PARTITION_METADATA" in sql
        assert "VALIDATION_STATUS" in sql
        assert "(7, 1, NULL, NULL, NULL, 'PENDING')" in sql

    def test_n_rows_preserved(self):
        sql = build_bulk_insert_partition_metadata_sql(
            "S.SC",
            1,
            [(1, 10, 20, 500_000)],
            status_column="VALIDATION_STATUS",
            status_sql_literal="'PENDING'",
        )
        assert ", 500000, 'PENDING')" in sql


class TestIterBulkInsertPartitionMetadataSqls:
    """Tests for iter_bulk_insert_partition_metadata_sqls."""

    def test_empty_raises(self):
        with pytest.raises(ValueError, match="non-empty"):
            list(
                iter_bulk_insert_partition_metadata_sqls(
                    "DB.SCH",
                    1,
                    [],
                    status_column="VALIDATION_STATUS",
                    status_sql_literal="'PENDING'",
                )
            )

    def test_non_positive_chunk_raises(self):
        with pytest.raises(ValueError, match="chunk_size"):
            list(
                iter_bulk_insert_partition_metadata_sqls(
                    "DB.SCH",
                    1,
                    [(1, None, None, None)],
                    status_column="VALIDATION_STATUS",
                    status_sql_literal="'PENDING'",
                    chunk_size=0,
                )
            )

    def test_single_chunk_when_below_size(self):
        partitions = [(i, None, None, None) for i in range(1, 4)]
        sqls = list(
            iter_bulk_insert_partition_metadata_sqls(
                "DB.SCH",
                1,
                partitions,
                status_column="VALIDATION_STATUS",
                status_sql_literal="'PENDING'",
                chunk_size=10,
            )
        )
        assert len(sqls) == 1
        assert "(1, 1, NULL, NULL, NULL, 'PENDING')" in sqls[0]
        assert "(1, 3, NULL, NULL, NULL, 'PENDING')" in sqls[0]

    def test_splits_at_chunk_boundary(self):
        partitions = [(i, None, None, None) for i in range(1, 8)]
        sqls = list(
            iter_bulk_insert_partition_metadata_sqls(
                "DB.SCH",
                1,
                partitions,
                status_column="VALIDATION_STATUS",
                status_sql_literal="'PENDING'",
                chunk_size=3,
            )
        )
        assert len(sqls) == 3
        # Chunk 1: partitions 1-3
        assert "(1, 1, NULL, NULL, NULL, 'PENDING')" in sqls[0]
        assert "(1, 3, NULL, NULL, NULL, 'PENDING')" in sqls[0]
        assert "(1, 4," not in sqls[0]
        # Chunk 2: partitions 4-6
        assert "(1, 4, NULL, NULL, NULL, 'PENDING')" in sqls[1]
        assert "(1, 6, NULL, NULL, NULL, 'PENDING')" in sqls[1]
        # Chunk 3: partition 7 only
        assert "(1, 7, NULL, NULL, NULL, 'PENDING')" in sqls[2]
        assert "(1, 6," not in sqls[2]

    def test_uses_default_chunk_size(self):
        # Two full default-sized chunks plus a small tail.
        n = PARTITION_METADATA_INSERT_CHUNK_SIZE * 2 + 5
        partitions = [(i, None, None, None) for i in range(1, n + 1)]
        sqls = list(
            iter_bulk_insert_partition_metadata_sqls(
                "DB.SCH",
                1,
                partitions,
                status_column="VALIDATION_STATUS",
                status_sql_literal="'PENDING'",
            )
        )
        assert len(sqls) == 3
        # Each statement is a valid full bulk insert.
        for sql in sqls:
            assert sql.startswith("INSERT INTO DB.SCH.PARTITION_METADATA")
            assert "FROM VALUES" in sql

    def test_default_chunk_below_snowflake_limits(self):
        # Sanity guardrail: keep the chunk well under Snowflake's 200,000
        # expressions-per-VALUES cap so future tweaks fail loudly here.
        assert PARTITION_METADATA_INSERT_CHUNK_SIZE <= 50_000
