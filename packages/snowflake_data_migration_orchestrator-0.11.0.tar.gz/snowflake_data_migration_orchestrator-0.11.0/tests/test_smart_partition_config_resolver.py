"""Unit tests for SmartPartitionConfigResolver."""

import pytest

from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    PartitionSizeConfig,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.smart_partition_config_resolver import (
    SmartPartitionConfigResolver,
)
from shared.enums.source_type import SourceType


class TestAutoMode:
    """Tests for the auto-resolution mode (both fields None)."""

    @pytest.mark.parametrize(
        "source_type, strategy",
        [
            (SourceType.REDSHIFT, ExtractionStrategy.UNLOAD),
            (SourceType.REDSHIFT, ExtractionStrategy.REGULAR),
            (SourceType.SQLSERVER, ExtractionStrategy.REGULAR),
            (SourceType.POSTGRESQL, ExtractionStrategy.REGULAR),
        ],
    )
    def test_auto_returns_config_for_known_platform(self, source_type, strategy):
        config = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(),
            source_type=source_type,
            extraction_strategy=strategy,
        )

        assert config.target_mb_per_partition is not None
        assert config.target_mb_per_partition > 0
        assert config.max_target_mb_per_partition is not None
        assert config.target_rows_per_partition is None

    def test_redshift_unload_has_larger_target_than_odbc(self):
        unload = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(),
            source_type=SourceType.REDSHIFT,
            extraction_strategy=ExtractionStrategy.UNLOAD,
        )
        odbc = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(),
            source_type=SourceType.REDSHIFT,
            extraction_strategy=ExtractionStrategy.REGULAR,
        )

        assert unload.target_mb_per_partition > odbc.target_mb_per_partition

    def test_auto_includes_max_fields(self):
        config = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(),
            source_type=SourceType.REDSHIFT,
            extraction_strategy=ExtractionStrategy.UNLOAD,
        )
        assert config.max_target_mb_per_partition == 10 * 1024
        assert config.max_target_rows_per_partition is None

    def test_teradata_regular_profile_uses_disk_export_tuning(self):
        """Teradata REGULAR auto profile allows larger partitions (TPT-style disk path)."""
        regular = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(),
            source_type=SourceType.TERADATA,
            extraction_strategy=ExtractionStrategy.REGULAR,
        )
        assert regular.target_mb_per_partition == 3 * 1024
        assert regular.max_target_mb_per_partition == 6 * 1024

    def test_teradata_write_nos_profile(self):
        wn = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(),
            source_type=SourceType.TERADATA,
            extraction_strategy=ExtractionStrategy.WRITE_NOS,
        )
        assert wn.target_mb_per_partition == 5 * 1024
        assert wn.max_target_mb_per_partition == 10 * 1024


class TestFixedMbMode:
    """Tests for the fixed-MB mode."""

    def test_fixed_mb_sets_target(self):
        config = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(target_size_mb=2048),
            source_type=SourceType.SQLSERVER,
            extraction_strategy=ExtractionStrategy.REGULAR,
        )

        assert config.target_mb_per_partition == 2048
        assert config.target_rows_per_partition is None

    def test_fixed_mb_does_not_apply_profile_maxes(self):
        config = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(target_size_mb=512),
            source_type=SourceType.SQLSERVER,
            extraction_strategy=ExtractionStrategy.REGULAR,
        )
        assert config.max_target_mb_per_partition is None
        assert config.max_target_rows_per_partition is None

    def test_fixed_mb_uses_user_target_not_profile(self):
        rs = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(target_size_mb=512),
            source_type=SourceType.REDSHIFT,
            extraction_strategy=ExtractionStrategy.UNLOAD,
        )
        ss = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(target_size_mb=512),
            source_type=SourceType.SQLSERVER,
            extraction_strategy=ExtractionStrategy.REGULAR,
        )

        assert rs.target_mb_per_partition == ss.target_mb_per_partition == 512


class TestFixedRowsMode:
    """Tests for the fixed-rows mode."""

    def test_fixed_rows_sets_target_rows(self):
        config = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(target_size_rows=500_000),
            source_type=SourceType.SQLSERVER,
            extraction_strategy=ExtractionStrategy.REGULAR,
        )

        assert config.target_rows_per_partition == 500_000
        assert config.target_mb_per_partition is None

    def test_fixed_rows_does_not_apply_profile_maxes(self):
        config = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(target_size_rows=100_000),
            source_type=SourceType.REDSHIFT,
            extraction_strategy=ExtractionStrategy.UNLOAD,
        )
        assert config.max_target_mb_per_partition is None
        assert config.max_target_rows_per_partition is None


class TestPartitionSizeConfig:
    """Tests for the PartitionSizeConfig domain model."""

    def test_default_is_auto(self):
        config = PartitionSizeConfig()
        assert config.is_auto

    def test_setting_a_field_is_not_auto(self):
        assert not PartitionSizeConfig(target_size_mb=1024).is_auto
        assert not PartitionSizeConfig(target_size_rows=10_000).is_auto
