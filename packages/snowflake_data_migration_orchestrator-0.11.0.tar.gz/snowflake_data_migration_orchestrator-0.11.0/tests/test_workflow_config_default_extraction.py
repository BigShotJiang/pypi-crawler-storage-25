"""Tests for workflow default extraction merge helpers."""

from unittest.mock import AsyncMock

import pytest

from data_migration_orchestrator.data_migration_cloud.config import (
    configuration_properties_keys as cfg_keys,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.workflow_config_service import (
    WorkflowConfigService,
)


@pytest.mark.asyncio
async def test_fetch_default_table_extraction_dict_returns_nested_block() -> None:
    warehouse = AsyncMock()
    svc = WorkflowConfigService(warehouse)
    svc.fetch_workflow_config = AsyncMock(
        return_value={
            cfg_keys.DEFAULT_TABLE_CONFIGURATION: {
                cfg_keys.EXTRACTION: {
                    "strategy": "write_nos",
                    "externalStage": "DB.SCH.STG",
                }
            }
        }
    )

    result = await svc.fetch_default_table_extraction_dict(1)
    assert result["strategy"] == "write_nos"
    assert result["externalStage"] == "DB.SCH.STG"


@pytest.mark.asyncio
async def test_fetch_default_table_extraction_dict_empty_when_missing() -> None:
    warehouse = AsyncMock()
    svc = WorkflowConfigService(warehouse)
    svc.fetch_workflow_config = AsyncMock(return_value={})

    result = await svc.fetch_default_table_extraction_dict(1)
    assert result == {}
