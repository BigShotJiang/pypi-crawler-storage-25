"""Tests for SchemaManager retry behaviour on transient Snowflake errors."""

from __future__ import annotations

import unittest

from unittest.mock import MagicMock, patch

from snowflake.connector.errors import ProgrammingError

from data_migration_orchestrator.cloud_orchestrator.schema.schema_manager import (
    TRANSIENT_RETRY_ATTEMPTS,
    TRANSIENT_RETRY_BACKOFF_MULTIPLIER,
    TRANSIENT_RETRY_INITIAL_DELAY_SECONDS,
    SchemaManager,
    _is_transient_migration_error,
)


def _make_mock_connection() -> MagicMock:
    """Build a mock SnowflakeConnection whose cursor() context yields a cursor."""
    conn = MagicMock()
    cursor_ctx = MagicMock()
    conn.cursor.return_value = cursor_ctx
    cursor_ctx.__enter__ = MagicMock(return_value=cursor_ctx)
    cursor_ctx.__exit__ = MagicMock(return_value=False)
    cursor_ctx.execute.return_value = None
    return conn


def _make_migration(side_effects: list[BaseException | None]) -> MagicMock:
    """Build a mock BaseMigration whose apply() returns or raises in sequence."""
    migration = MagicMock()
    migration.version = 99
    migration.description = "test migration"
    migration.apply = MagicMock(side_effect=side_effects)
    return migration


def _index_build_error(
    msg: str = "Operation failed: another index is being built",
) -> ProgrammingError:
    """Build a ProgrammingError mimicking Snowflake's concurrent-index-build error."""
    return ProgrammingError(msg=msg)


def _wrapped_index_build_error() -> Exception:
    """
    Build the exception shape that actually reaches SchemaManager in production.

    ``utils/templated_sql.execute_templated_sql_file`` wraps any execute()
    failure as ``raise Exception(f"Failed to execute ...: {e!s}") from e``,
    so the top-level exception is a generic ``Exception`` whose ``__cause__``
    is the original ``ProgrammingError`` from snowflake-connector.
    """
    cause = ProgrammingError(
        msg=(
            "391480 (0A000): Another index is being built on table "
            "'TASK_QUEUE'. Only one index can be built at a time."
        )
    )
    wrapper = Exception(f"Failed to execute idx_task_queue_successor.sql.j2: {cause!s}")
    wrapper.__cause__ = cause
    return wrapper


# ---------------------------------------------------------------------------
# _is_transient_migration_error
# ---------------------------------------------------------------------------
class TestIsTransientMigrationError(unittest.TestCase):
    """Unit tests for the transient-error classifier."""

    def test_detects_is_being_built(self):
        err = _index_build_error("Index IDX_FOO is being built; please retry")
        self.assertTrue(_is_transient_migration_error(err))

    def test_detects_another_index(self):
        err = _index_build_error(
            "Operation failed because another index build is in progress"
        )
        self.assertTrue(_is_transient_migration_error(err))

    def test_match_is_case_insensitive(self):
        err = _index_build_error("Another Index Is Being Built right now")
        self.assertTrue(_is_transient_migration_error(err))

    def test_unrelated_programming_error_is_not_transient(self):
        err = ProgrammingError(msg="syntax error near 'FROM'")
        self.assertFalse(_is_transient_migration_error(err))

    def test_non_programming_error_is_not_transient(self):
        self.assertFalse(_is_transient_migration_error(RuntimeError("nope")))
        self.assertFalse(_is_transient_migration_error(ValueError("nope")))

    def test_detects_wrapped_in_generic_exception(self):
        """
        Regression: utils/templated_sql wraps the ProgrammingError.

        Without ``__cause__`` chain traversal the schema manager would never
        retry the migration 13 race in production.
        """
        self.assertTrue(_is_transient_migration_error(_wrapped_index_build_error()))

    def test_detects_double_wrapped(self):
        first = _wrapped_index_build_error()
        outer = RuntimeError("re-wrapped by an outer caller")
        outer.__cause__ = first
        self.assertTrue(_is_transient_migration_error(outer))

    def test_wrapped_unrelated_error_is_not_transient(self):
        cause = ProgrammingError(msg="syntax error near 'SELECT'")
        wrapper = Exception(f"Failed to execute foo.sql.j2: {cause!s}")
        wrapper.__cause__ = cause
        self.assertFalse(_is_transient_migration_error(wrapper))


# ---------------------------------------------------------------------------
# _apply_migration_with_retries
# ---------------------------------------------------------------------------
class TestApplyMigrationWithRetries(unittest.TestCase):
    """Unit tests for the retry helper around migration.apply()."""

    def setUp(self):
        self.connection = _make_mock_connection()
        self.manager = SchemaManager(self.connection)

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.schema_manager.time.sleep"
    )
    def test_succeeds_first_try_does_not_sleep(self, mock_sleep):
        migration = _make_migration([None])

        self.manager._apply_migration_with_retries(migration)

        self.assertEqual(migration.apply.call_count, 1)
        self.connection.commit.assert_called_once()
        mock_sleep.assert_not_called()

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.schema_manager.time.sleep"
    )
    def test_retries_transient_then_succeeds(self, mock_sleep):
        migration = _make_migration([_index_build_error(), None])

        self.manager._apply_migration_with_retries(migration)

        self.assertEqual(migration.apply.call_count, 2)
        self.connection.commit.assert_called_once()
        mock_sleep.assert_called_once_with(TRANSIENT_RETRY_INITIAL_DELAY_SECONDS)

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.schema_manager.time.sleep"
    )
    def test_retries_wrapped_transient_then_succeeds(self, mock_sleep):
        """The exact production shape: templated_sql wraps the ProgrammingError."""
        migration = _make_migration([_wrapped_index_build_error(), None])

        self.manager._apply_migration_with_retries(migration)

        self.assertEqual(migration.apply.call_count, 2)
        self.connection.commit.assert_called_once()
        mock_sleep.assert_called_once_with(TRANSIENT_RETRY_INITIAL_DELAY_SECONDS)

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.schema_manager.time.sleep"
    )
    def test_uses_exponential_backoff_between_attempts(self, mock_sleep):
        migration = _make_migration([_index_build_error(), _index_build_error(), None])

        self.manager._apply_migration_with_retries(migration)

        self.assertEqual(migration.apply.call_count, 3)
        expected_delays = [
            TRANSIENT_RETRY_INITIAL_DELAY_SECONDS,
            TRANSIENT_RETRY_INITIAL_DELAY_SECONDS * TRANSIENT_RETRY_BACKOFF_MULTIPLIER,
        ]
        actual_delays = [call.args[0] for call in mock_sleep.call_args_list]
        self.assertEqual(actual_delays, expected_delays)

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.schema_manager.time.sleep"
    )
    def test_raises_after_exhausting_retries(self, mock_sleep):
        final_error = _index_build_error("final attempt failed: is being built")
        side_effects: list[BaseException | None] = [
            _index_build_error() for _ in range(TRANSIENT_RETRY_ATTEMPTS - 1)
        ]
        side_effects.append(final_error)
        migration = _make_migration(side_effects)

        with self.assertRaises(ProgrammingError) as ctx:
            self.manager._apply_migration_with_retries(migration)

        self.assertIs(ctx.exception, final_error)
        self.assertEqual(migration.apply.call_count, TRANSIENT_RETRY_ATTEMPTS)
        # We sleep BETWEEN attempts, so one fewer sleep than attempts.
        self.assertEqual(mock_sleep.call_count, TRANSIENT_RETRY_ATTEMPTS - 1)
        self.connection.commit.assert_not_called()

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.schema_manager.time.sleep"
    )
    def test_does_not_retry_non_transient_programming_error(self, mock_sleep):
        non_transient = ProgrammingError(msg="syntax error near 'SELECT'")
        migration = _make_migration([non_transient, None])

        with self.assertRaises(ProgrammingError) as ctx:
            self.manager._apply_migration_with_retries(migration)

        self.assertIs(ctx.exception, non_transient)
        self.assertEqual(migration.apply.call_count, 1)
        mock_sleep.assert_not_called()
        self.connection.commit.assert_not_called()

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.schema_manager.time.sleep"
    )
    def test_does_not_retry_arbitrary_exception(self, mock_sleep):
        boom = RuntimeError("connection lost")
        migration = _make_migration([boom, None])

        with self.assertRaises(RuntimeError) as ctx:
            self.manager._apply_migration_with_retries(migration)

        self.assertIs(ctx.exception, boom)
        self.assertEqual(migration.apply.call_count, 1)
        mock_sleep.assert_not_called()


# ---------------------------------------------------------------------------
# _apply_migration end-to-end (records the right SUCCESS flag)
# ---------------------------------------------------------------------------
class TestApplyMigrationRecording(unittest.TestCase):
    """End-to-end tests: retry loop integrates with the SCHEMA_MIGRATION recording."""

    def setUp(self):
        self.connection = _make_mock_connection()
        self.manager = SchemaManager(self.connection)

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.schema_manager.time.sleep"
    )
    def test_success_after_retry_records_success_true(self, mock_sleep):
        migration = _make_migration([_index_build_error(), None])

        self.manager._apply_migration(migration)

        # _record_migration runs exactly once via the finally block
        cursor = self.connection.cursor.return_value
        self.assertEqual(cursor.execute.call_count, 1)
        recorded_params = cursor.execute.call_args_list[0].args[1]
        version, description, _execution_ms, success = recorded_params
        self.assertEqual(version, 99)
        self.assertEqual(description, "test migration")
        self.assertTrue(success)

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.schema_manager.time.sleep"
    )
    def test_exhausted_retries_records_success_false_and_reraises(self, mock_sleep):
        side_effects: list[BaseException | None] = [
            _index_build_error() for _ in range(TRANSIENT_RETRY_ATTEMPTS)
        ]
        migration = _make_migration(side_effects)

        with self.assertRaises(ProgrammingError):
            self.manager._apply_migration(migration)

        cursor = self.connection.cursor.return_value
        self.assertEqual(cursor.execute.call_count, 1)
        recorded_params = cursor.execute.call_args_list[0].args[1]
        _version, _description, _execution_ms, success = recorded_params
        self.assertFalse(success)


if __name__ == "__main__":
    unittest.main()
