"""Tests for generic SQL utility functions."""

import pytest
from data_migration_orchestrator.utils.snowflake_sql_utils import (
    escape_sql_string,
    quote_string_literal,
    quote_snowflake_identifier_if_needed,
    build_snowflake_fqn,
)


class TestEscapeSqlString:
    """Tests for escape_sql_string function."""

    def test_no_special_characters(self):
        assert escape_sql_string("hello") == "hello"

    def test_escapes_single_quotes(self):
        assert escape_sql_string("it's") == "it''s"

    def test_escapes_backslashes(self):
        assert escape_sql_string("a\\b") == "a\\\\b"

    def test_escapes_backslash_before_quote(self):
        result = escape_sql_string('\\"Id\\"')
        assert result == '\\\\"Id\\\\"'

    def test_json_with_escaped_quotes(self):
        raw_json = '{"columnNameMappings": {"ID": "\\"Id\\""}}'
        result = escape_sql_string(raw_json)
        assert '\\\\"Id\\\\"' in result


class TestQuoteStringLiteral:
    """Tests for quote_string_literal function."""

    def test_quote_simple_string(self):
        result = quote_string_literal("my_value")
        assert result == "'my_value'"

    def test_quote_path_string(self):
        result = quote_string_literal("@stage/path/to/file.parquet")
        assert result == "'@stage/path/to/file.parquet'"

    def test_quote_with_spaces(self):
        result = quote_string_literal("Order Details")
        assert result == "'Order Details'"

    def test_quote_empty_string(self):
        result = quote_string_literal("")
        assert result == "''"

    def test_quote_with_unicode_prefix(self):
        result = quote_string_literal("my_value", unicode_prefix=True)
        assert result == "N'my_value'"

    def test_quote_with_unicode_prefix_false(self):
        result = quote_string_literal("my_value", unicode_prefix=False)
        assert result == "'my_value'"

    def test_quote_special_characters(self):
        result = quote_string_literal("value-with_special$chars")
        assert result == "'value-with_special$chars'"

    def test_quote_with_single_quote(self):
        result = quote_string_literal("O'Brien")
        assert result == "'O''Brien'"

    def test_quote_multiple_single_quotes(self):
        result = quote_string_literal("It's O'Brien's")
        assert result == "'It''s O''Brien''s'"


class TestQuoteSnowflakeIdentifierIfNeeded:
    """Tests for quote_snowflake_identifier_if_needed."""

    @pytest.mark.parametrize(
        "identifier",
        ["DBABB", "ECOMMERCE_TD_ODBC", "CUSTOMERS", "_INTERNAL", "T1$X"],
    )
    def test_valid_uppercase_identifiers_remain_unquoted(self, identifier):
        assert quote_snowflake_identifier_if_needed(identifier) == identifier

    def test_lowercase_is_quoted_to_preserve_case(self):
        assert quote_snowflake_identifier_if_needed("orders") == '"orders"'

    def test_mixed_case_is_quoted_to_preserve_case(self):
        assert quote_snowflake_identifier_if_needed("Orders") == '"Orders"'

    def test_starts_with_digit_is_quoted(self):
        assert quote_snowflake_identifier_if_needed("1ABC") == '"1ABC"'

    def test_special_chars_are_quoted(self):
        assert quote_snowflake_identifier_if_needed("MY-TABLE") == '"MY-TABLE"'
        assert quote_snowflake_identifier_if_needed("MY TABLE") == '"MY TABLE"'

    def test_double_quotes_are_doubled(self):
        # Snowflake escapes embedded double quotes by doubling them inside quoted ids.
        assert quote_snowflake_identifier_if_needed('A"B') == '"A""B"'

    def test_empty_returns_empty(self):
        assert quote_snowflake_identifier_if_needed("") == ""


class TestBuildSnowflakeFqn:
    """
    Tests for build_snowflake_fqn re-exported from the canonical helper.

    The canonical implementation lives in ``utils.snowflake_identifiers`` and is
    re-exported from ``data_migration_cloud.platforms.snowflake.identifiers``;
    ``tests/platforms/snowflake/test_identifiers.py`` exercises the same
    behavior. These tests guard the re-export contract from ``snowflake_sql_utils``.
    """

    def test_three_part_uppercase_identifiers(self):
        assert (
            build_snowflake_fqn("DBABB", "ECOMMERCE_TD_ODBC", "ORDERS")
            == "DBABB.ECOMMERCE_TD_ODBC.ORDERS"
        )

    def test_valid_lowercase_and_mixed_case_remain_unquoted(self):
        # Snowflake folds unquoted identifiers; case is only preserved when the
        # identifier is already quoted or contains characters that require it.
        assert (
            build_snowflake_fqn("dbabb", "ECOMMERCE_TD_ODBC", "Orders")
            == "dbabb.ECOMMERCE_TD_ODBC.Orders"
        )

    def test_missing_database_keeps_two_parts(self):
        # Allowed when database falls back to session default.
        assert build_snowflake_fqn(None, "PUBLIC", "ORDERS") == "PUBLIC.ORDERS"

    def test_missing_schema_and_database_keeps_only_table(self):
        assert build_snowflake_fqn(None, None, "ORDERS") == "ORDERS"

    def test_missing_table_raises(self):
        with pytest.raises(ValueError):
            build_snowflake_fqn("DBABB", "ECOMMERCE_TD_ODBC", "")

    def test_special_chars_in_part_are_quoted(self):
        assert build_snowflake_fqn("DB", "MY SCHEMA", "T-1") == 'DB."MY SCHEMA"."T-1"'

    def test_re_export_matches_canonical(self):
        from data_migration_orchestrator.utils.snowflake_identifiers import (
            build_snowflake_fqn as canonical,
        )

        assert build_snowflake_fqn is canonical
