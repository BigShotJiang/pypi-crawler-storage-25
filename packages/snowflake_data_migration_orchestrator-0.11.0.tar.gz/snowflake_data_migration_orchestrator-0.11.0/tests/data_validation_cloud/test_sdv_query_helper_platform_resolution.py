"""Tests for SDV platform string resolution used by cloud data validation."""

import pytest

from snowflake.snowflake_data_validation.public import Platform

from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
    _normalize_identifier,
    resolve_platform,
)


def test_resolve_platform_postgresql_aliases() -> None:
    assert resolve_platform("postgresql") == Platform.POSTGRESQL
    assert resolve_platform("POSTGRESQL") == Platform.POSTGRESQL
    assert resolve_platform("postgres") == Platform.POSTGRESQL
    assert resolve_platform("pg") == Platform.POSTGRESQL


def test_normalize_identifier_postgresql_lowercase() -> None:
    assert _normalize_identifier("MyCol", Platform.POSTGRESQL) == "mycol"


def test_resolve_platform_unknown_raises() -> None:
    with pytest.raises(ValueError, match="Unknown platform"):
        resolve_platform("nosuchdb")
