"""Tests for build_task_extra in the orchestrator."""

from __future__ import annotations

from data_migration_orchestrator.cloud_orchestrator.orchestrator import (
    build_task_extra,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    DataValidationTaskPayload,
    EvaluateLevelResultPayload,
    WriteValidationResultsPayload,
)
from data_migration_orchestrator.data_validation_core.constants import (
    RowValidationMode,
)
from shared.telemetry import EXTRA_WORKFLOW_ID


def _call(payload) -> dict:
    return build_task_extra(payload, workflow_id=7253, payload_kind="x")


def test_unknown_payload_only_has_payload_kind_and_workflow_id() -> None:
    class Dummy:
        pass

    extra = _call(Dummy())
    assert extra == {"payload_kind": "x", EXTRA_WORKFLOW_ID: "7253"}


def test_write_validation_results_includes_only_level() -> None:
    extra = _call(
        WriteValidationResultsPayload(
            query="SELECT 1",
            table_metadata_id=1,
            workflow_id=7253,
            validation_level="row",
        )
    )
    assert extra["validation_level"] == "row"
    assert "next_level" not in extra
    assert "row_validation_mode" not in extra


def test_evaluate_level_result_full_shape() -> None:
    """Covers completed_level -> validation_level, non-null next_level, AND row_mode."""
    extra = _call(
        EvaluateLevelResultPayload(
            table_metadata_id=1,
            completed_level="metrics",
            next_level="row",
            continue_on_failure=False,
            next_level_enabled=True,
            workflow_id=7253,
            source_platform="sqlserver",
            source_identifier="src-1",
            row_validation_mode=RowValidationMode.CELL,
        )
    )
    assert extra["validation_level"] == "metrics"
    assert extra["next_level"] == "row"
    assert extra["row_validation_mode"] == "cell"


def test_evaluate_level_result_omits_optional_fields_when_absent() -> None:
    extra = _call(
        EvaluateLevelResultPayload(
            table_metadata_id=1,
            completed_level="row",
            next_level=None,
            continue_on_failure=False,
            next_level_enabled=False,
            workflow_id=7253,
            source_platform="sqlserver",
            source_identifier="src-1",
        )
    )
    assert extra["validation_level"] == "row"
    assert "next_level" not in extra
    assert "row_validation_mode" not in extra


def test_dv_payload_validation_type_and_row_mode() -> None:
    extra = _call(
        DataValidationTaskPayload(
            source_query="",
            target_query="",
            validation_type="row",
            source_platform="sqlserver",
            target_type="stage",
            target_id="0",
            table_name="t",
            table_metadata_id=1,
            workflow_id=7253,
            partition_number=None,
            database="d",
            schema="s",
            row_validation_mode=RowValidationMode.CELL,
        )
    )
    assert extra["validation_level"] == "row"
    assert extra["row_validation_mode"] == "cell"
