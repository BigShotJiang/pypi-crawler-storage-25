"""Focused tests for DataMigrationWorkflowInitializer (non-Iceberg routing)."""

import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from data_migration_orchestrator.cloud_core.workflows.workflow import Workflow
from data_migration_orchestrator.cloud_core.workflows.workflow_status import (
    WorkflowStatus,
)
from data_migration_orchestrator.data_migration_cloud.config.configuration_parser import (
    ConfigurationError,
)
from data_migration_orchestrator.data_migration_cloud.config.sync_strategy import (
    SyncStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    DEFAULT_TARGET_TABLE_TYPE,
    ExtractionConfig,
    IcebergTargetConfig,
    LoadingConfig,
    LoadingStrategy,
    PartitionSizeConfig,
    SynchronizationConfig,
    TableConfiguration,
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.data_migration_workflow_initializer import (
    DataMigrationWorkflowInitializer,
)
from data_migration_orchestrator.data_migration_cloud.platforms.platform_registry import (
    PlatformRegistry,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    DataMovementTaskPayload,
    PreprocessingCheckPayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)
from shared.enums.source_type import SourceType


def _workflow_for_dm_init() -> Workflow:
    return Workflow(
        id=1,
        name="test-workflow",
        source_platform=SourceType.SQLSERVER,
        target_cloud_type="snowflake:stage",
        target_cloud_stage_name="MY_STAGE",
        target_cloud_url=None,
        schema_version="1",
        workflow_type="data-migration",
        initiator_id="test-initiator",
        status=WorkflowStatus.INITIALIZING,
        configuration={"tables": [{"source": {"tableName": "T"}}]},
        initialization_failures=0,
    )


def _native_table_config() -> TableConfiguration:
    return TableConfiguration(
        source=TableIdentifier(
            database_name="src_db",
            schema_name="src_schema",
            table_name="my_table",
        ),
        target=TableIdentifier(
            database_name="tgt_db",
            schema_name="tgt_schema",
            table_name="my_table",
        ),
        partition_columns=[],
        column_type_mappings={},
        column_name_mappings={},
        primary_key_columns=[],
        synchronization=SynchronizationConfig(),
        extraction=ExtractionConfig(),
        partition_size=PartitionSizeConfig(),
        where_clause_criteria=None,
        target_table_type=DEFAULT_TARGET_TABLE_TYPE,
        iceberg_config=None,
    )


class TestCreateInitialTasksConfigurationError(unittest.IsolatedAsyncioTestCase):
    """``create_initial_tasks`` when table parsing raises ``ConfigurationError``."""

    async def test_propagates_configuration_error_from_parse_tables(self):
        init = DataMigrationWorkflowInitializer(
            task_queue=MagicMock(),
            warehouse_proxy=MagicMock(),
        )
        init.configuration_parser = MagicMock()
        init.configuration_parser.parse_tables = MagicMock(
            side_effect=ConfigurationError("bad table config")
        )
        wf = _workflow_for_dm_init()
        with self.assertRaises(ConfigurationError) as ctx:
            await init.create_initial_tasks(wf)
        self.assertIn("bad table config", str(ctx.exception))


class TestExistingPartitionsFallback(unittest.IsolatedAsyncioTestCase):
    """Incremental path when copying existing partition metadata fails."""

    async def test_copy_failure_falls_back_to_new_partitions(self):
        init = DataMigrationWorkflowInitializer(
            task_queue=MagicMock(),
            warehouse_proxy=MagicMock(),
        )
        init.partition_reuse_service = MagicMock()
        init.partition_reuse_service.copy_table_and_partitions = AsyncMock(
            return_value=None
        )
        init._insert_table_metadata = AsyncMock(return_value=55)
        init._batch_create_tasks_with_new_partitions = AsyncMock()

        platform = PlatformRegistry.create_by_name_or_alias(SourceType.SQLSERVER)
        table_config = _native_table_config()
        fq = platform.build_normalized_table_name(table_config.source)

        await init._create_tasks_with_existing_partitions(
            workflow_id=42,
            table_config=table_config,
            platform=platform,
            target_cloud_type="snowflake:stage",
            existing_table_metadata_id=99,
        )

        init._batch_create_tasks_with_new_partitions.assert_awaited_once_with(
            42,
            [table_config],
            platform.name,
            "snowflake:stage",
            {fq: 55},
        )


class TestCreateInitialTasksBulk(unittest.IsolatedAsyncioTestCase):
    """``create_initial_tasks`` uses bulk metadata SQL and batched task pushes."""

    async def test_two_new_tables_bulk_metadata_and_two_push_tasks_batch(self):
        task_queue = MagicMock()
        task_queue.push_tasks_batch = AsyncMock(
            side_effect=[[201, 202], [301, 302, 303, 304]]
        )
        task_queue.push_independent_two_task_chains = AsyncMock()

        warehouse = MagicMock()
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                None,
                [
                    {"ID": 1, "SOURCE_IDENTIFIER": "SRC_DB.SRC_SCHEMA.MY_TABLE"},
                    {"ID": 2, "SOURCE_IDENTIFIER": "SRC_DB.SRC_SCHEMA.OTHER_TABLE"},
                ],
            ]
        )

        init = DataMigrationWorkflowInitializer(
            task_queue=task_queue,
            warehouse_proxy=warehouse,
        )
        init.partition_reuse_service.find_existing_table_metadata = AsyncMock(
            return_value=None
        )

        src = {
            "databaseName": "src_db",
            "schemaName": "src_schema",
            "tableName": "my_table",
        }
        src2 = {
            "databaseName": "src_db",
            "schemaName": "src_schema",
            "tableName": "other_table",
        }
        tgt = {
            "databaseName": "tgt_db",
            "schemaName": "tgt_schema",
            "tableName": "my_table",
        }
        tgt2 = {
            "databaseName": "tgt_db",
            "schemaName": "tgt_schema",
            "tableName": "other_table",
        }
        wf = Workflow(
            id=1,
            name="test-workflow",
            source_platform=SourceType.SQLSERVER,
            target_cloud_type="snowflake:stage",
            target_cloud_stage_name="MY_STAGE",
            target_cloud_url=None,
            schema_version="1",
            workflow_type="data-migration",
            initiator_id="test-initiator",
            status=WorkflowStatus.INITIALIZING,
            configuration={
                "tables": [
                    {"source": src, "target": tgt},
                    {"source": src2, "target": tgt2},
                ]
            },
            initialization_failures=0,
        )

        await init.create_initial_tasks(wf)

        self.assertEqual(warehouse.execute_sync_query.call_count, 2)
        self.assertEqual(task_queue.push_tasks_batch.call_count, 2)
        task_queue.push_independent_two_task_chains.assert_not_awaited()

    async def test_oracle_bulk_metadata_uses_owner_table_and_snowflake_target_fqn(self):
        """
        Oracle uses OWNER.TABLE metadata keys; Snowflake targets stay three-part.

        Snowflake uses database.schema.table for preprocessing and DEA payloads.
        """
        task_queue = MagicMock()
        task_queue.push_tasks_batch = AsyncMock(
            side_effect=[[201, 202], [301, 302, 303, 304]]
        )
        task_queue.push_independent_two_task_chains = AsyncMock()

        warehouse = MagicMock()
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                None,
                [
                    {"ID": 1, "SOURCE_IDENTIFIER": "HR.MY_TABLE"},
                    {"ID": 2, "SOURCE_IDENTIFIER": "HR.OTHER_TABLE"},
                ],
            ]
        )

        init = DataMigrationWorkflowInitializer(
            task_queue=task_queue,
            warehouse_proxy=warehouse,
        )
        init.partition_reuse_service.find_existing_table_metadata = AsyncMock(
            return_value=None
        )

        src = {
            "databaseName": "orcl",
            "schemaName": "hr",
            "tableName": "my_table",
        }
        src2 = {
            "databaseName": "orcl",
            "schemaName": "hr",
            "tableName": "other_table",
        }
        tgt = {
            "databaseName": "tgt_db",
            "schemaName": "tgt_schema",
            "tableName": "my_table",
        }
        tgt2 = {
            "databaseName": "tgt_db",
            "schemaName": "tgt_schema",
            "tableName": "other_table",
        }
        wf = Workflow(
            id=1,
            name="test-workflow",
            source_platform=SourceType.ORACLE,
            target_cloud_type="snowflake:stage",
            target_cloud_stage_name="MY_STAGE",
            target_cloud_url=None,
            schema_version="1",
            workflow_type="data-migration",
            initiator_id="test-initiator",
            status=WorkflowStatus.INITIALIZING,
            configuration={
                "tables": [
                    {"source": src, "target": tgt},
                    {"source": src2, "target": tgt2},
                ]
            },
            initialization_failures=0,
        )

        oracle_platform = PlatformRegistry.create_by_name_or_alias(SourceType.ORACLE)
        expected_tgt = oracle_platform.build_target_table_name(
            TableIdentifier(
                database_name="tgt_db",
                schema_name="tgt_schema",
                table_name="my_table",
            )
        )
        expected_tgt2 = oracle_platform.build_target_table_name(
            TableIdentifier(
                database_name="tgt_db",
                schema_name="tgt_schema",
                table_name="other_table",
            )
        )

        await init.create_initial_tasks(wf)

        first_batch = task_queue.push_tasks_batch.await_args_list[0].args[0]
        self.assertEqual(len(first_batch), 2)
        for i, task in enumerate(first_batch):
            self.assertIsInstance(task.payload, PreprocessingCheckPayload)
            self.assertEqual(task.payload.source_type, SourceType.ORACLE)
            want = expected_tgt if i == 0 else expected_tgt2
            self.assertEqual(task.payload.target_table, want)

        second_batch = task_queue.push_tasks_batch.await_args_list[1].args[0]
        self.assertEqual(len(second_batch), 2)
        for task in second_batch:
            self.assertIsInstance(task.payload, DataMovementTaskPayload)
            self.assertEqual(task.payload.source_type, SourceType.ORACLE)
            self.assertIn("all_objects", task.payload.statement_location_id.lower())


class TestBuildCatalogLinkDdl(unittest.TestCase):
    """Static DDL builder for Iceberg catalog-link strategy."""

    def test_without_external_volume(self):
        cfg = IcebergTargetConfig(catalog="MY_CATALOG", external_volume=None)
        ddl = DataMigrationWorkflowInitializer._build_catalog_link_ddl(
            "DB.SCHEMA.TGT",
            cfg,
            "cat_tbl",
        )
        self.assertIn("CREATE OR REPLACE ICEBERG TABLE DB.SCHEMA.TGT", ddl)
        self.assertIn("CATALOG = 'MY_CATALOG'", ddl)
        self.assertIn("CATALOG_TABLE_NAME = 'cat_tbl'", ddl)
        self.assertNotIn("EXTERNAL_VOLUME", ddl)

    def test_with_external_volume(self):
        cfg = IcebergTargetConfig(catalog="MY_CATALOG", external_volume="EVOL")
        ddl = DataMigrationWorkflowInitializer._build_catalog_link_ddl(
            "DB.SCHEMA.TGT",
            cfg,
            "cat_tbl",
        )
        self.assertIn("EXTERNAL_VOLUME = 'EVOL'", ddl)


def _snowpipe_table_config(
    *,
    sync_strategy: SyncStrategy = SyncStrategy.NONE,
) -> TableConfiguration:
    """
    Return a snowpipe-loaded native table configuration.

    The sync strategy can be overridden so tests can assert how the
    initializer routes "incremental sync" vs "full redo (NONE)" workloads.
    """
    return TableConfiguration(
        source=TableIdentifier(
            database_name="src_db",
            schema_name="src_schema",
            table_name="my_table",
        ),
        target=TableIdentifier(
            database_name="tgt_db",
            schema_name="tgt_schema",
            table_name="my_table",
        ),
        partition_columns=[],
        column_type_mappings={},
        column_name_mappings={},
        primary_key_columns=[],
        synchronization=SynchronizationConfig(strategy=sync_strategy),
        extraction=ExtractionConfig(),
        partition_size=PartitionSizeConfig(),
        where_clause_criteria=None,
        target_table_type=DEFAULT_TARGET_TABLE_TYPE,
        iceberg_config=None,
        loading=LoadingConfig(strategy=LoadingStrategy.SNOWPIPE),
    )


class TestSnowpipeLifecycleSplit(unittest.IsolatedAsyncioTestCase):
    """
    Init phase Snowpipe lifecycle: separate setup/teardown task creation.

    Bug 1 fix (SNOW-XXXXXXX): For new-table snowpipe migrations, init must
    NOT queue ``Setup Snowpipe`` (the target table doesn't exist yet, so
    CREATE PIPE would fail). ``PartitionStrategyHandler`` queues setup
    later, after schema extraction, with a ``Create target table``
    predecessor.

    Incremental snowpipe migrations are unaffected: the target already
    exists, so init queues setup at workflow start (no race).
    """

    def _make_init_for_new_table_snowpipe(
        self,
    ) -> tuple[DataMigrationWorkflowInitializer, MagicMock]:
        task_queue = MagicMock()
        task_queue.push_tasks_batch = AsyncMock(side_effect=[[201], [301]])
        task_queue.push_task = AsyncMock(return_value=999)
        task_queue.push_independent_two_task_chains = AsyncMock()

        warehouse = MagicMock()
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                None,
                [{"ID": 1, "SOURCE_IDENTIFIER": "SRC_DB.SRC_SCHEMA.MY_TABLE"}],
            ]
        )

        init = DataMigrationWorkflowInitializer(
            task_queue=task_queue,
            warehouse_proxy=warehouse,
        )
        init.partition_reuse_service = MagicMock()
        init.partition_reuse_service.find_existing_table_metadata = AsyncMock(
            return_value=None
        )
        init.configuration_parser = MagicMock()
        init.configuration_parser.parse_tables = MagicMock(
            return_value=[_snowpipe_table_config()]
        )
        return init, task_queue

    def _make_init_for_incremental_snowpipe(
        self,
    ) -> tuple[DataMigrationWorkflowInitializer, MagicMock]:
        task_queue = MagicMock()
        task_queue.push_tasks_batch = AsyncMock(return_value=[])
        task_queue.push_task = AsyncMock(return_value=999)
        task_queue.push_independent_two_task_chains = AsyncMock()

        warehouse = MagicMock()
        warehouse.execute_sync_query = AsyncMock(return_value=[])

        init = DataMigrationWorkflowInitializer(
            task_queue=task_queue,
            warehouse_proxy=warehouse,
        )
        init.partition_reuse_service = MagicMock()
        init.partition_reuse_service.find_existing_table_metadata = AsyncMock(
            return_value=42
        )

        async def _stub_pair(**_kwargs):
            return None, 77

        init._incremental_sync_task_pair_or_fallback = AsyncMock(side_effect=_stub_pair)
        init.configuration_parser = MagicMock()
        init.configuration_parser.parse_tables = MagicMock(
            return_value=[_snowpipe_table_config(sync_strategy=SyncStrategy.CHECKSUM)]
        )
        return init, task_queue

    def _make_init_for_sync_none_with_stale_metadata(
        self,
    ) -> tuple[DataMigrationWorkflowInitializer, MagicMock, AsyncMock]:
        """
        SyncStrategy.NONE workload where stale TABLE_METADATA exists.

        Mirrors the production scenario that re-introduced the Setup Snowpipe
        race after the initial Bug 1 fix: a previous workflow left a
        ``TABLE_METADATA`` row for the same source, but the current workflow
        opted into ``SyncStrategy.NONE`` (full redo, no incremental reuse).
        The initializer must ignore the stale metadata and route the table
        through the new-table path so ``Setup Snowpipe`` is queued by
        ``PartitionStrategyHandler`` *after* ``Create target table``.
        """
        task_queue = MagicMock()
        task_queue.push_tasks_batch = AsyncMock(side_effect=[[201], [301]])
        task_queue.push_task = AsyncMock(return_value=999)
        task_queue.push_independent_two_task_chains = AsyncMock()

        warehouse = MagicMock()
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                None,
                [{"ID": 1, "SOURCE_IDENTIFIER": "SRC_DB.SRC_SCHEMA.MY_TABLE"}],
            ]
        )

        init = DataMigrationWorkflowInitializer(
            task_queue=task_queue,
            warehouse_proxy=warehouse,
        )
        init.partition_reuse_service = MagicMock()
        find_metadata_mock = AsyncMock(return_value=42)
        init.partition_reuse_service.find_existing_table_metadata = find_metadata_mock
        init.configuration_parser = MagicMock()
        init.configuration_parser.parse_tables = MagicMock(
            return_value=[_snowpipe_table_config(sync_strategy=SyncStrategy.NONE)]
        )
        return init, task_queue, find_metadata_mock

    @staticmethod
    def _workflow_with_snowpipe_table() -> Workflow:
        return Workflow(
            id=1,
            name="snowpipe-test",
            source_platform=SourceType.SQLSERVER,
            target_cloud_type="snowflake:stage",
            target_cloud_stage_name="MY_STAGE",
            target_cloud_url=None,
            schema_version="1",
            workflow_type="data-migration",
            initiator_id="test-initiator",
            status=WorkflowStatus.INITIALIZING,
            configuration={"tables": [{"source": {"tableName": "my_table"}}]},
            initialization_failures=0,
        )

    @patch(
        "data_migration_orchestrator.data_migration_cloud.data_migration_workflow_initializer.setup_snowpipe_for_data_migration",
        new_callable=AsyncMock,
    )
    async def test_new_table_snowpipe_init_only_queues_teardown_not_setup(
        self, _mock_setup
    ):
        init, task_queue = self._make_init_for_new_table_snowpipe()

        await init.create_initial_tasks(self._workflow_with_snowpipe_table())

        pushed_payload_kinds = [
            call.args[0].payload.kind for call in task_queue.push_task.await_args_list
        ]
        self.assertIn(TaskPayloadKind.TEARDOWN_SNOWPIPE, pushed_payload_kinds)
        self.assertNotIn(TaskPayloadKind.SETUP_SNOWPIPE, pushed_payload_kinds)

    @patch(
        "data_migration_orchestrator.data_migration_cloud.data_migration_workflow_initializer.setup_snowpipe_for_data_migration",
        new_callable=AsyncMock,
    )
    async def test_incremental_snowpipe_init_queues_both_setup_and_teardown(
        self, _mock_setup
    ):
        init, task_queue = self._make_init_for_incremental_snowpipe()

        await init.create_initial_tasks(self._workflow_with_snowpipe_table())

        pushed_payload_kinds = [
            call.args[0].payload.kind for call in task_queue.push_task.await_args_list
        ]
        self.assertIn(TaskPayloadKind.TEARDOWN_SNOWPIPE, pushed_payload_kinds)
        self.assertIn(TaskPayloadKind.SETUP_SNOWPIPE, pushed_payload_kinds)

    @patch(
        "data_migration_orchestrator.data_migration_cloud.data_migration_workflow_initializer.setup_snowpipe_for_data_migration",
        new_callable=AsyncMock,
    )
    async def test_sync_none_with_stale_metadata_routes_to_new_table_path(
        self, _mock_setup
    ):
        """
        A SyncStrategy.NONE table must NEVER take the incremental branch.

        Even if ``find_existing_table_metadata`` returns a stale row from a
        previous workflow, the initializer should treat the table as
        "new" (full redo) and let ``PartitionStrategyHandler`` queue
        ``Create target table`` -> ``Setup Snowpipe`` later, eliminating
        the CREATE PIPE race when the physical target table no longer
        exists. The lookup itself should be skipped to make the intent
        explicit.
        """
        init, task_queue, find_metadata_mock = (
            self._make_init_for_sync_none_with_stale_metadata()
        )

        await init.create_initial_tasks(self._workflow_with_snowpipe_table())

        find_metadata_mock.assert_not_awaited()

        pushed_payload_kinds = [
            call.args[0].payload.kind for call in task_queue.push_task.await_args_list
        ]
        self.assertIn(TaskPayloadKind.TEARDOWN_SNOWPIPE, pushed_payload_kinds)
        self.assertNotIn(TaskPayloadKind.SETUP_SNOWPIPE, pushed_payload_kinds)


class TestSnowpipeEventTableSetupIntegration(unittest.IsolatedAsyncioTestCase):
    """Verify ``setup_snowpipe_for_data_migration`` is called only when needed."""

    @patch(
        "data_migration_orchestrator.data_migration_cloud.data_migration_workflow_initializer.setup_snowpipe_for_data_migration",
        new_callable=AsyncMock,
    )
    async def test_not_called_when_no_snowpipe_tables(self, mock_setup):
        """Warehouse-only workflows must NOT invoke the event table setup."""
        task_queue = MagicMock()
        task_queue.push_tasks_batch = AsyncMock(side_effect=[[201], [301]])
        task_queue.push_independent_two_task_chains = AsyncMock()

        warehouse = MagicMock()
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                None,
                [{"ID": 1, "SOURCE_IDENTIFIER": "SRC_DB.SRC_SCHEMA.MY_TABLE"}],
            ]
        )

        init = DataMigrationWorkflowInitializer(
            task_queue=task_queue,
            warehouse_proxy=warehouse,
        )
        init.partition_reuse_service.find_existing_table_metadata = AsyncMock(
            return_value=None
        )

        wf = Workflow(
            id=1,
            name="warehouse-only",
            source_platform=SourceType.SQLSERVER,
            target_cloud_type="snowflake:stage",
            target_cloud_stage_name="MY_STAGE",
            target_cloud_url=None,
            schema_version="1",
            workflow_type="data-migration",
            initiator_id="test-initiator",
            status=WorkflowStatus.INITIALIZING,
            configuration={
                "tables": [
                    {
                        "source": {
                            "databaseName": "src_db",
                            "schemaName": "src_schema",
                            "tableName": "my_table",
                        },
                        "target": {
                            "databaseName": "tgt_db",
                            "schemaName": "tgt_schema",
                            "tableName": "my_table",
                        },
                    }
                ]
            },
            initialization_failures=0,
        )

        await init.create_initial_tasks(wf)
        mock_setup.assert_not_awaited()

    @patch(
        "data_migration_orchestrator.data_migration_cloud.data_migration_workflow_initializer.setup_snowpipe_for_data_migration",
        new_callable=AsyncMock,
    )
    async def test_called_when_snowpipe_table_present(self, mock_setup):
        """When any table uses snowpipe loading, event table setup must run."""
        task_queue = MagicMock()
        task_queue.push_tasks_batch = AsyncMock(side_effect=[[201], [301]])
        task_queue.push_task = AsyncMock(return_value=999)
        task_queue.push_independent_two_task_chains = AsyncMock()

        warehouse = MagicMock()
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                None,
                [{"ID": 1, "SOURCE_IDENTIFIER": "SRC_DB.SRC_SCHEMA.MY_TABLE"}],
            ]
        )

        init = DataMigrationWorkflowInitializer(
            task_queue=task_queue,
            warehouse_proxy=warehouse,
        )
        init.partition_reuse_service.find_existing_table_metadata = AsyncMock(
            return_value=None
        )
        init.configuration_parser = MagicMock()
        init.configuration_parser.parse_tables = MagicMock(
            return_value=[_snowpipe_table_config()]
        )

        wf = Workflow(
            id=1,
            name="snowpipe-test",
            source_platform=SourceType.SQLSERVER,
            target_cloud_type="snowflake:stage",
            target_cloud_stage_name="MY_STAGE",
            target_cloud_url=None,
            schema_version="1",
            workflow_type="data-migration",
            initiator_id="test-initiator",
            status=WorkflowStatus.INITIALIZING,
            configuration={"tables": [{"source": {"tableName": "my_table"}}]},
            initialization_failures=0,
        )

        await init.create_initial_tasks(wf)
        mock_setup.assert_awaited_once_with(warehouse)

    @patch(
        "data_migration_orchestrator.data_migration_cloud.data_migration_workflow_initializer.setup_snowpipe_for_data_migration",
        new_callable=AsyncMock,
    )
    async def test_setup_failure_propagates_as_runtime_error(self, mock_setup):
        """ALTER DATABASE failure must bubble up to fail workflow initialization."""
        mock_setup.side_effect = RuntimeError("event tables not supported")

        task_queue = MagicMock()
        task_queue.push_tasks_batch = AsyncMock(side_effect=[[201], [301]])
        task_queue.push_task = AsyncMock(return_value=999)
        task_queue.push_independent_two_task_chains = AsyncMock()

        warehouse = MagicMock()
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                None,
                [{"ID": 1, "SOURCE_IDENTIFIER": "SRC_DB.SRC_SCHEMA.MY_TABLE"}],
            ]
        )

        init = DataMigrationWorkflowInitializer(
            task_queue=task_queue,
            warehouse_proxy=warehouse,
        )
        init.partition_reuse_service.find_existing_table_metadata = AsyncMock(
            return_value=None
        )
        init.configuration_parser = MagicMock()
        init.configuration_parser.parse_tables = MagicMock(
            return_value=[_snowpipe_table_config()]
        )

        wf = Workflow(
            id=1,
            name="snowpipe-fail",
            source_platform=SourceType.SQLSERVER,
            target_cloud_type="snowflake:stage",
            target_cloud_stage_name="MY_STAGE",
            target_cloud_url=None,
            schema_version="1",
            workflow_type="data-migration",
            initiator_id="test-initiator",
            status=WorkflowStatus.INITIALIZING,
            configuration={"tables": [{"source": {"tableName": "my_table"}}]},
            initialization_failures=0,
        )

        with self.assertRaises(RuntimeError) as ctx:
            await init.create_initial_tasks(wf)
        self.assertIn("event tables not supported", str(ctx.exception))
