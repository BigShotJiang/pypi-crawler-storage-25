"""Tests for partition boundary sampling thresholds."""

from data_migration_orchestrator.data_migration_cloud.platforms.redshift.query_builder import (
    SAMPLING_TARGET_ROWS,
    SAMPLING_THRESHOLD_ROWS,
)


class TestSamplingConstants:
    """DM Redshift boundary sampling defaults (mirrored in DV handler)."""

    def test_threshold_and_target_rows(self):
        assert SAMPLING_THRESHOLD_ROWS == 100_000_000
        assert SAMPLING_TARGET_ROWS == 20_000_000
