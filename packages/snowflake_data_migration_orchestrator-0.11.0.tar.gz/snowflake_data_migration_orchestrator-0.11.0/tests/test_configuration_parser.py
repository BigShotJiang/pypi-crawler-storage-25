"""Unit tests for ConfigurationParser."""

import pytest

from data_migration_orchestrator.data_migration_cloud.config.configuration_parser import (
    ConfigurationError,
    ConfigurationParser,
)
from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableConfiguration,
)


class TestConfigurationParser:
    """Tests for ConfigurationParser class."""

    @pytest.fixture
    def parser(self):
        """Create a parser instance for testing."""
        return ConfigurationParser()

    @pytest.fixture
    def valid_config(self):
        """Create a valid table configuration dictionary."""
        return {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
        }

    def test_parse_valid_configuration(self, parser, valid_config):
        """Test parsing a valid configuration."""
        result = parser.parse_table_configuration(valid_config)

        assert isinstance(result, TableConfiguration)
        assert result.source.database_name == "source_db"
        assert result.source.schema_name == "dbo"
        assert result.source.table_name == "customers"
        assert result.target.database_name == "target_db"
        assert result.target.schema_name == "public"
        assert result.target.table_name == "customers"
        assert result.partition_columns == ["id"]
        assert result.column_type_mappings == {}

    def test_parse_with_column_type_mappings(self, parser, valid_config):
        """Test parsing configuration with custom type mappings."""
        valid_config["columnTypeMappings"] = [
            {"sourceType": "BIT", "targetType": "BOOLEAN"},
            {"sourceType": "MONEY", "targetType": "DECIMAL(19,4)"},
        ]

        result = parser.parse_table_configuration(valid_config)

        assert len(result.column_type_mappings) == 2
        assert result.column_type_mappings["BIT"] == "BOOLEAN"
        assert result.column_type_mappings["MONEY"] == "DECIMAL(19,4)"

    def test_parse_with_column_name_mappings(self, parser, valid_config):
        """Test parsing configuration with custom column name mappings."""
        valid_config["columnNameMappings"] = [
            {"sourceName": "id", "targetName": "old_id"},
            {"sourceName": "name", "targetName": "full_name"},
        ]

        result = parser.parse_table_configuration(valid_config)

        assert len(result.column_name_mappings) == 2
        assert result.column_name_mappings["id"] == "OLD_ID"
        assert result.column_name_mappings["name"] == "FULL_NAME"

    def test_parse_with_both_type_and_name_mappings(self, parser, valid_config):
        """Test parsing configuration with both type and name mappings."""
        valid_config["columnTypeMappings"] = [
            {"sourceType": "MONEY", "targetType": "DECIMAL(19,4)"},
        ]
        valid_config["columnNameMappings"] = [
            {"sourceName": "id", "targetName": "old_id"},
        ]

        result = parser.parse_table_configuration(valid_config)

        assert len(result.column_type_mappings) == 1
        assert result.column_type_mappings["MONEY"] == "DECIMAL(19,4)"
        assert len(result.column_name_mappings) == 1
        assert result.column_name_mappings["id"] == "OLD_ID"

    def test_parse_missing_source(self, parser):
        """Test that missing source raises ConfigurationError."""
        config = {
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
        }

        with pytest.raises(ConfigurationError, match="Missing required field 'source'"):
            parser.parse_table_configuration(config)

    def test_parse_missing_target(self, parser):
        """Test that missing target raises ConfigurationError."""
        config = {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
        }

        with pytest.raises(ConfigurationError, match="Missing required field 'target'"):
            parser.parse_table_configuration(config)

    def test_parse_missing_database_name(self, parser):
        """Test that missing databaseName raises ConfigurationError."""
        config = {
            "source": {
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
        }

        with pytest.raises(ConfigurationError, match="databaseName"):
            parser.parse_table_configuration(config)

    def test_parse_missing_schema_name(self, parser):
        """Test that missing schemaName raises ConfigurationError."""
        config = {
            "source": {
                "databaseName": "source_db",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
        }

        with pytest.raises(ConfigurationError, match="schemaName"):
            parser.parse_table_configuration(config)

    def test_parse_teradata_source_allows_missing_schema_name(self, parser):
        """Teradata uses database.table; source schemaName is optional when platform is set."""
        config = {
            "source": {
                "databaseName": "ecommerce",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
        }
        result = parser.parse_table_configuration(config, source_platform="teradata")
        assert result.source.database_name == "ecommerce"
        assert result.source.schema_name == ""
        assert result.target.schema_name == "public"

    def test_parse_teradata_target_still_requires_schema_name(self, parser):
        config = {
            "source": {
                "databaseName": "ecommerce",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "DBABB",
                "tableName": "CUSTOMERS",
            },
            "columnNamesToPartitionBy": ["id"],
        }
        with pytest.raises(ConfigurationError, match="target"):
            parser.parse_table_configuration(config, source_platform="teradata")

    def test_parse_missing_table_name(self, parser):
        """Test that missing tableName raises ConfigurationError."""
        config = {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
        }

        with pytest.raises(ConfigurationError, match="tableName"):
            parser.parse_table_configuration(config)

    def test_parse_missing_partition_columns(self, parser):
        """Test that missing partition columns results in no partitioning."""
        config = {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
        }

        result = parser.parse_table_configuration(config)

        assert result.partition_columns == []
        assert result.partition_column is None

    def test_parse_empty_partition_columns(self, parser):
        """Test that empty partition columns list results in no partitioning."""
        config = {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": [],
        }

        result = parser.parse_table_configuration(config)

        assert result.partition_columns == []
        assert result.partition_column is None

    def test_parse_multiple_partition_columns(self, parser, valid_config):
        """Test parsing configuration with multiple partition columns."""
        valid_config["columnNamesToPartitionBy"] = ["year", "month"]

        result = parser.parse_table_configuration(valid_config)

        assert result.partition_columns == ["year", "month"]

    def test_parse_skips_invalid_type_mappings(self, parser, valid_config):
        """Test that invalid type mappings are skipped with warning."""
        valid_config["columnTypeMappings"] = [
            {"sourceType": "BIT", "targetType": "BOOLEAN"},
            {"sourceType": "INVALID"},  # Missing targetType
            {"targetType": "VARCHAR"},  # Missing sourceType
            {"sourceType": "MONEY", "targetType": "DECIMAL(19,4)"},
        ]

        result = parser.parse_table_configuration(valid_config)

        # Only valid mappings should be included
        assert len(result.column_type_mappings) == 2
        assert "BIT" in result.column_type_mappings
        assert "MONEY" in result.column_type_mappings

    def test_parse_skips_invalid_name_mappings(self, parser, valid_config):
        """Test that invalid name mappings are skipped with warning."""
        valid_config["columnNameMappings"] = [
            {"sourceName": "id", "targetName": "old_id"},
            {"sourceName": "missing_target"},  # Missing targetName
            {"targetName": "orphan_target"},  # Missing sourceName
            {"sourceName": "name", "targetName": "full_name"},
        ]

        result = parser.parse_table_configuration(valid_config)

        # Only valid mappings should be included
        assert len(result.column_name_mappings) == 2
        assert "id" in result.column_name_mappings
        assert "name" in result.column_name_mappings

    def test_parse_tables_multiple(self, parser):
        """Test parsing multiple table configurations."""
        configs = [
            {
                "source": {
                    "databaseName": "source_db",
                    "schemaName": "dbo",
                    "tableName": "customers",
                },
                "target": {
                    "databaseName": "target_db",
                    "schemaName": "public",
                    "tableName": "customers",
                },
                "columnNamesToPartitionBy": ["customer_id"],
            },
            {
                "source": {
                    "databaseName": "source_db",
                    "schemaName": "dbo",
                    "tableName": "orders",
                },
                "target": {
                    "databaseName": "target_db",
                    "schemaName": "public",
                    "tableName": "orders",
                },
                "columnNamesToPartitionBy": ["order_id"],
            },
        ]

        results = parser.parse_tables(configs)

        assert len(results) == 2
        assert results[0].source.table_name == "customers"
        assert results[1].source.table_name == "orders"

    def test_parse_tables_empty_list(self, parser):
        """Test parsing empty list of configurations."""
        results = parser.parse_tables([])
        assert results == []

    def test_parse_tables_with_invalid_config(self, parser):
        """Test that invalid config in list raises with index info."""
        configs = [
            {
                "source": {
                    "databaseName": "source_db",
                    "schemaName": "dbo",
                    "tableName": "customers",
                },
                "target": {
                    "databaseName": "target_db",
                    "schemaName": "public",
                    "tableName": "customers",
                },
                "columnNamesToPartitionBy": ["id"],
            },
            {
                "source": {
                    "databaseName": "source_db",
                    "schemaName": "dbo",
                    "tableName": "orders",
                },
                # Missing target
                "columnNamesToPartitionBy": ["id"],
            },
        ]

        with pytest.raises(ConfigurationError, match="table at index 1"):
            parser.parse_tables(configs)

    def test_fully_qualified_friendly_names(self, parser, valid_config):
        """Test that parsed config provides fully qualified friendly names."""
        result = parser.parse_table_configuration(valid_config)

        assert result.source.fully_qualified_friendly_name == "source_db.dbo.customers"
        assert (
            result.target.fully_qualified_friendly_name == "target_db.public.customers"
        )


class TestConfigurationParserEdgeCases:
    """Edge case tests for ConfigurationParser."""

    @pytest.fixture
    def parser(self):
        """Create a parser instance for testing."""
        return ConfigurationParser()

    def test_empty_string_database_name(self, parser):
        """Test that empty string database name raises error."""
        config = {
            "source": {
                "databaseName": "",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
        }

        with pytest.raises(ConfigurationError, match="databaseName"):
            parser.parse_table_configuration(config)

    def test_none_values_treated_as_missing(self, parser):
        """Test that None values are treated as missing."""
        config = {
            "source": {
                "databaseName": None,
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
        }

        with pytest.raises(ConfigurationError, match="databaseName"):
            parser.parse_table_configuration(config)

    def test_type_mapping_normalization(self, parser):
        """Test that type mappings are normalized to uppercase."""
        config = {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
            "columnTypeMappings": [
                {"sourceType": "bit", "targetType": "boolean"},
            ],
        }

        result = parser.parse_table_configuration(config)

        assert result.column_type_mappings["BIT"] == "BOOLEAN"

    def test_empty_column_type_mappings_list(self, parser):
        """Test that empty columnTypeMappings list results in empty dict."""
        config = {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
            "columnTypeMappings": [],
        }

        result = parser.parse_table_configuration(config)

        assert result.column_type_mappings == {}

    def test_empty_column_name_mappings_list(self, parser):
        """Test that empty columnNameMappings list results in empty dict."""
        config = {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
            "columnNameMappings": [],
        }

        result = parser.parse_table_configuration(config)

        assert result.column_name_mappings == {}

    def test_unquoted_target_names_are_uppercased(self, parser):
        """Unquoted target names are uppercased per Snowflake identifier rules."""
        config = {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
            "columnNameMappings": [
                {"sourceName": "FirstName", "targetName": "first_name"},
                {"sourceName": "LastName", "targetName": "LAST_NAME"},
            ],
        }

        result = parser.parse_table_configuration(config)

        assert result.column_name_mappings["FirstName"] == "FIRST_NAME"
        assert result.column_name_mappings["LastName"] == "LAST_NAME"

    def test_quoted_target_names_preserve_casing(self, parser):
        """Double-quoted target names keep their quotes so downstream code can detect case-sensitivity."""
        config = {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
            "columnNameMappings": [
                {"sourceName": "ID", "targetName": '"Id"'},
                {"sourceName": "STATUS", "targetName": '"Active Status"'},
                {"sourceName": "NAME", "targetName": "plain_name"},
            ],
        }

        result = parser.parse_table_configuration(config)

        assert result.column_name_mappings["ID"] == '"Id"'
        assert result.column_name_mappings["STATUS"] == '"Active Status"'
        assert result.column_name_mappings["NAME"] == "PLAIN_NAME"


class TestWhereClauseCriteriaParsing:
    """Tests for whereClauseCriteria parsing in ConfigurationParser."""

    @pytest.fixture
    def parser(self):
        """Create a parser instance for testing."""
        return ConfigurationParser()

    @pytest.fixture
    def valid_config(self):
        """Create a valid table configuration dictionary."""
        return {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
        }

    def test_where_clause_criteria_present(self, parser, valid_config):
        """Test parsing a valid whereClauseCriteria."""
        valid_config["whereClauseCriteria"] = "is_deleted = 0"

        result = parser.parse_table_configuration(valid_config)

        assert result.where_clause_criteria == "is_deleted = 0"

    def test_where_clause_criteria_absent(self, parser, valid_config):
        """Test that missing whereClauseCriteria defaults to None."""
        result = parser.parse_table_configuration(valid_config)

        assert result.where_clause_criteria is None

    def test_where_clause_criteria_strips_where_prefix(self, parser, valid_config):
        """Test that leading WHERE keyword is stripped."""
        valid_config["whereClauseCriteria"] = "WHERE status = 'active'"

        result = parser.parse_table_configuration(valid_config)

        assert result.where_clause_criteria == "status = 'active'"

    def test_where_clause_criteria_strips_where_prefix_case_insensitive(
        self, parser, valid_config
    ):
        """Test that WHERE prefix stripping is case-insensitive."""
        valid_config["whereClauseCriteria"] = "where status = 'active'"

        result = parser.parse_table_configuration(valid_config)

        assert result.where_clause_criteria == "status = 'active'"

    def test_where_clause_criteria_empty_string(self, parser, valid_config):
        """Test that empty string results in None."""
        valid_config["whereClauseCriteria"] = ""

        result = parser.parse_table_configuration(valid_config)

        assert result.where_clause_criteria is None

    def test_where_clause_criteria_whitespace_only(self, parser, valid_config):
        """Test that whitespace-only string results in None."""
        valid_config["whereClauseCriteria"] = "   "

        result = parser.parse_table_configuration(valid_config)

        assert result.where_clause_criteria is None

    def test_where_clause_criteria_where_keyword_only(self, parser, valid_config):
        """Test that bare WHERE keyword results in None."""
        valid_config["whereClauseCriteria"] = "WHERE"

        result = parser.parse_table_configuration(valid_config)

        assert result.where_clause_criteria is None

    def test_where_clause_criteria_non_string_integer(self, parser, valid_config):
        """Test that non-string (integer) value is ignored."""
        valid_config["whereClauseCriteria"] = 42

        result = parser.parse_table_configuration(valid_config)

        assert result.where_clause_criteria is None

    def test_where_clause_criteria_non_string_list(self, parser, valid_config):
        """Test that non-string (list) value is ignored."""
        valid_config["whereClauseCriteria"] = ["status = 'active'"]

        result = parser.parse_table_configuration(valid_config)

        assert result.where_clause_criteria is None

    def test_where_clause_criteria_preserves_complex_condition(
        self, parser, valid_config
    ):
        """Test that complex SQL conditions are preserved as-is."""
        complex_criteria = (
            "status IN ('active', 'pending') AND created_at > '2026-01-01'"
        )
        valid_config["whereClauseCriteria"] = complex_criteria

        result = parser.parse_table_configuration(valid_config)

        assert result.where_clause_criteria == complex_criteria


class TestDefaultTableConfiguration:
    """Tests for defaultTableConfiguration merging functionality."""

    @pytest.fixture
    def parser(self):
        """Create a parser instance for testing."""
        return ConfigurationParser()

    @pytest.fixture
    def default_config(self):
        """Create a default table configuration for testing."""
        return {
            "target": {
                "databaseName": "default_target_db",
                "schemaName": "default_schema",
            },
            "extraction": {
                "strategy": "unload",
                "externalStage": "@MY_DB.MY_SCHEMA.S3_STAGE",
            },
            "columnTypeMappings": [
                {"sourceType": "MONEY", "targetType": "DECIMAL(19,4)"}
            ],
        }

    @pytest.fixture
    def partial_table_config(self):
        """Create a partial table configuration (missing defaults)."""
        return {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
        }

    def test_parse_tables_with_defaults_merges_target(self, parser):
        """Test that partial target is deep-merged with default target."""
        default_config = {
            "target": {
                "databaseName": "default_db",
                "schemaName": "default_schema",
            },
        }
        table_config = {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
        }

        results = parser.parse_tables([table_config], default_config=default_config)

        assert len(results) == 1
        # Target should have merged values
        assert results[0].target.database_name == "default_db"
        assert results[0].target.schema_name == "default_schema"
        assert results[0].target.table_name == "customers"

    def test_parse_tables_with_defaults_merges_source(self, parser):
        """Test that partial source is deep-merged with default source."""
        default_config = {
            "source": {
                "databaseName": "default_source_db",
                "schemaName": "default_source_schema",
            },
        }
        table_config = {
            "source": {
                "tableName": "customers",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
        }

        results = parser.parse_tables([table_config], default_config=default_config)

        assert len(results) == 1
        # Source should have merged values
        assert results[0].source.database_name == "default_source_db"
        assert results[0].source.schema_name == "default_source_schema"
        assert results[0].source.table_name == "customers"

    def test_parse_tables_with_defaults_table_overrides_extraction(self, parser):
        """Test that table-level extraction values override defaults."""
        default_config = {
            "extraction": {
                "strategy": "unload",
                "externalStage": "@MY_DB.MY_SCHEMA.S3_STAGE",
            },
            "whereClauseCriteria": "is_active = 1",
        }
        table_config = {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
            "extraction": {"strategy": "regular"},  # Override
        }

        results = parser.parse_tables([table_config], default_config=default_config)

        assert len(results) == 1
        # extraction should be overridden (and externalStage inherited from default due to deep merge)
        assert results[0].extraction_strategy.value == "regular"
        # whereClauseCriteria should come from default
        assert results[0].where_clause_criteria == "is_active = 1"

    def test_parse_tables_with_defaults_collection_shallow_replace(self, parser):
        """Test that collection fields are shallow-replaced (not merged)."""
        default_config = {
            "columnTypeMappings": [
                {"sourceType": "MONEY", "targetType": "DECIMAL(19,4)"},
                {"sourceType": "BIT", "targetType": "BOOLEAN"},
            ],
        }
        table_config = {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
            "columnTypeMappings": [
                {"sourceType": "VARCHAR", "targetType": "TEXT"},
            ],
        }

        results = parser.parse_tables([table_config], default_config=default_config)

        assert len(results) == 1
        # Table config should completely replace default (not merge)
        assert len(results[0].column_type_mappings) == 1
        assert "VARCHAR" in results[0].column_type_mappings
        assert "MONEY" not in results[0].column_type_mappings
        assert "BIT" not in results[0].column_type_mappings

    def test_parse_tables_with_defaults_inherits_collection(self, parser):
        """Test that collection fields are inherited when not specified in table."""
        default_config = {
            "columnTypeMappings": [
                {"sourceType": "MONEY", "targetType": "DECIMAL(19,4)"},
            ],
            "primaryKeyColumns": ["id"],
        }
        table_config = {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
            # No columnTypeMappings or primaryKeyColumns
        }

        results = parser.parse_tables([table_config], default_config=default_config)

        assert len(results) == 1
        # Should inherit from defaults
        assert len(results[0].column_type_mappings) == 1
        assert results[0].column_type_mappings["MONEY"] == "DECIMAL(19,4)"
        assert results[0].primary_key_columns == ["id"]

    def test_parse_tables_with_defaults_deep_merge_synchronization(self, parser):
        """Test that synchronization config is deep-merged."""
        default_config = {
            "synchronization": {
                "strategy": "watermark",
                "watermarkColumn": "updated_at",
            },
        }
        table_config = {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
            "primaryKeyColumns": ["id"],
            "synchronization": {
                "trackModifications": True,
            },
        }

        results = parser.parse_tables([table_config], default_config=default_config)

        assert len(results) == 1
        sync = results[0].synchronization
        # Should have strategy and watermarkColumn from default
        assert sync.strategy.value == "watermark"
        assert sync.watermark_column == "updated_at"
        # Should have trackModifications from table config
        assert sync.track_modifications is True

    def test_parse_tables_with_defaults_multiple_tables(self, parser):
        """Test that defaults apply to all tables."""
        default_config = {
            "target": {
                "databaseName": "shared_target_db",
                "schemaName": "migrated",
            },
            "extraction": {
                "strategy": "unload",
                "externalStage": "@MY_DB.MY_SCHEMA.S3_STAGE",
            },
        }
        tables = [
            {
                "source": {
                    "databaseName": "src",
                    "schemaName": "dbo",
                    "tableName": "customers",
                },
                "target": {"tableName": "customers"},
                "columnNamesToPartitionBy": ["customer_id"],
            },
            {
                "source": {
                    "databaseName": "src",
                    "schemaName": "dbo",
                    "tableName": "orders",
                },
                "target": {"tableName": "orders"},
                "columnNamesToPartitionBy": ["order_id"],
            },
        ]

        results = parser.parse_tables(tables, default_config=default_config)

        assert len(results) == 2
        for result in results:
            assert result.target.database_name == "shared_target_db"
            assert result.target.schema_name == "migrated"
            assert result.extraction_strategy.value == "unload"
        assert results[0].target.table_name == "customers"
        assert results[1].target.table_name == "orders"

    def test_parse_tables_no_defaults_backward_compatible(self, parser):
        """Test that parse_tables works without defaults (backward compatible)."""
        table_config = {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
        }

        # Call without default_config
        results = parser.parse_tables([table_config])

        assert len(results) == 1
        assert results[0].source.table_name == "customers"

    def test_parse_tables_with_defaults_validation_error_after_merge(self, parser):
        """Test that validation errors surface correctly after merging."""
        default_config = {
            "synchronization": {
                "strategy": "watermark",
                "trackModifications": True,
            },
        }
        table_config = {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "target_db",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
            "synchronization": {
                "watermarkColumn": "updated_at",
            },
            # Missing primaryKeyColumns required for trackModifications
        }

        with pytest.raises(ConfigurationError, match="primaryKeyColumns"):
            parser.parse_tables([table_config], default_config=default_config)

    def test_parse_tables_with_defaults_missing_required_field_after_merge(
        self, parser
    ):
        """Test error when required field is still missing after merge."""
        default_config = {
            "target": {
                "databaseName": "default_db",
                # Missing schemaName
            },
        }
        table_config = {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "tableName": "customers",
                # Missing schemaName (not in default either)
            },
            "columnNamesToPartitionBy": ["id"],
        }

        with pytest.raises(ConfigurationError, match="schemaName"):
            parser.parse_tables([table_config], default_config=default_config)


class TestDeepMergeDicts:
    """Tests for _deep_merge_dicts method."""

    @pytest.fixture
    def parser(self):
        """Create a parser instance for testing."""
        return ConfigurationParser()

    def test_deep_merge_simple(self, parser):
        """Test deep merge with simple values."""
        default = {"a": 1, "b": 2}
        override = {"b": 3, "c": 4}

        result = parser._deep_merge_dicts(default, override)

        assert result == {"a": 1, "b": 3, "c": 4}

    def test_deep_merge_nested_dicts(self, parser):
        """Test deep merge with nested dictionaries."""
        default = {"outer": {"inner1": "a", "inner2": "b"}}
        override = {"outer": {"inner2": "c", "inner3": "d"}}

        result = parser._deep_merge_dicts(default, override)

        assert result == {"outer": {"inner1": "a", "inner2": "c", "inner3": "d"}}

    def test_deep_merge_deeply_nested(self, parser):
        """Test deep merge with deeply nested structures."""
        default = {"l1": {"l2": {"l3": "default"}}}
        override = {"l1": {"l2": {"l3": "override", "new": "value"}}}

        result = parser._deep_merge_dicts(default, override)

        assert result == {"l1": {"l2": {"l3": "override", "new": "value"}}}

    def test_deep_merge_override_replaces_non_dict(self, parser):
        """Test that override replaces when types don't match for nesting."""
        default = {"key": {"nested": "value"}}
        override = {"key": "flat_value"}

        result = parser._deep_merge_dicts(default, override)

        assert result == {"key": "flat_value"}

    def test_deep_merge_empty_default(self, parser):
        """Test deep merge with empty default."""
        default = {}
        override = {"a": 1, "b": {"c": 2}}

        result = parser._deep_merge_dicts(default, override)

        assert result == {"a": 1, "b": {"c": 2}}

    def test_deep_merge_empty_override(self, parser):
        """Test deep merge with empty override."""
        default = {"a": 1, "b": {"c": 2}}
        override = {}

        result = parser._deep_merge_dicts(default, override)

        assert result == {"a": 1, "b": {"c": 2}}

    def test_deep_merge_does_not_modify_inputs(self, parser):
        """Test that deep merge doesn't modify input dictionaries."""
        default = {"a": {"b": 1}}
        override = {"a": {"c": 2}}
        default_copy = {"a": {"b": 1}}
        override_copy = {"a": {"c": 2}}

        parser._deep_merge_dicts(default, override)

        assert default == default_copy
        assert override == override_copy


class TestMergeTableConfigs:
    """Tests for _merge_table_configs method."""

    @pytest.fixture
    def parser(self):
        """Create a parser instance for testing."""
        return ConfigurationParser()

    def test_merge_table_configs_deep_merge_fields(self, parser):
        """Test that designated fields use deep merge."""
        default = {
            "source": {"databaseName": "db", "schemaName": "schema"},
            "target": {"databaseName": "target_db"},
            "synchronization": {"strategy": "watermark"},
        }
        table = {
            "source": {"tableName": "table"},
            "target": {"schemaName": "target_schema", "tableName": "table"},
            "synchronization": {"watermarkColumn": "updated_at"},
        }

        result = parser._merge_table_configs(default, table)

        # Source should be deep merged
        assert result["source"] == {
            "databaseName": "db",
            "schemaName": "schema",
            "tableName": "table",
        }
        # Target should be deep merged
        assert result["target"] == {
            "databaseName": "target_db",
            "schemaName": "target_schema",
            "tableName": "table",
        }
        # Synchronization should be deep merged
        assert result["synchronization"] == {
            "strategy": "watermark",
            "watermarkColumn": "updated_at",
        }

    def test_merge_table_configs_shallow_replace_fields(self, parser):
        """Test that collection fields use shallow replace."""
        default = {
            "columnTypeMappings": [{"sourceType": "A", "targetType": "B"}],
            "columnNameMappings": [{"sourceName": "x", "targetName": "y"}],
            "columnNamesToPartitionBy": ["col1", "col2"],
            "primaryKeyColumns": ["pk1"],
        }
        table = {
            "columnTypeMappings": [{"sourceType": "C", "targetType": "D"}],
            "columnNamesToPartitionBy": ["col3"],
        }

        result = parser._merge_table_configs(default, table)

        # Should completely replace, not merge
        assert result["columnTypeMappings"] == [{"sourceType": "C", "targetType": "D"}]
        assert result["columnNamesToPartitionBy"] == ["col3"]
        # Should keep defaults for unspecified fields
        assert result["columnNameMappings"] == [{"sourceName": "x", "targetName": "y"}]
        assert result["primaryKeyColumns"] == ["pk1"]

    def test_merge_table_configs_scalar_override(self, parser):
        """Test that scalar fields are overridden."""
        default = {
            "whereClauseCriteria": "active = 1",
            "someScalarField": "default_value",
        }
        table = {
            "someScalarField": "table_value",
        }

        result = parser._merge_table_configs(default, table)

        assert result["someScalarField"] == "table_value"
        assert result["whereClauseCriteria"] == "active = 1"


class TestParsePartitionSizeConfig:
    """Tests for the _parse_partition_size_config method with flat fields."""

    @pytest.fixture
    def parser(self):
        return ConfigurationParser()

    def _base_config(self, **extra):
        cfg = {
            "source": {"databaseName": "db", "schemaName": "dbo", "tableName": "t"},
            "target": {"databaseName": "tgt", "schemaName": "public", "tableName": "t"},
        }
        cfg.update(extra)
        return cfg

    def test_absent_returns_auto(self, parser):
        config = parser.parse_table_configuration(self._base_config())
        assert config.partition_size.is_auto

    def test_target_partition_size_mb(self, parser):
        config = parser.parse_table_configuration(
            self._base_config(targetPartitionSizeMb=2048)
        )
        assert config.partition_size.target_size_mb == 2048
        assert not config.partition_size.is_auto

    def test_target_partition_size_rows(self, parser):
        config = parser.parse_table_configuration(
            self._base_config(targetPartitionSizeRows=500_000)
        )
        assert config.partition_size.target_size_rows == 500_000
        assert not config.partition_size.is_auto

    def test_both_fields_raises_error(self, parser):
        with pytest.raises(ConfigurationError, match="Only one"):
            parser.parse_table_configuration(
                self._base_config(
                    targetPartitionSizeMb=1024,
                    targetPartitionSizeRows=10000,
                )
            )

    @pytest.mark.parametrize(
        "field, value",
        [
            ("targetPartitionSizeMb", 0),
            ("targetPartitionSizeRows", -5),
        ],
        ids=["zero_mb", "negative_rows"],
    )
    def test_non_positive_value_raises_error(self, parser, field, value):
        with pytest.raises(ConfigurationError, match="positive integer"):
            parser.parse_table_configuration(self._base_config(**{field: value}))


class TestIcebergTargetConfiguration:
    """Tests for Iceberg target table type parsing in ConfigurationParser."""

    @pytest.fixture
    def parser(self):
        """Create a parser instance for testing."""
        return ConfigurationParser()

    def _base_config(self, target_extra=None, **top_level_extra):
        """Create a base config dict with optional target and top-level overrides."""
        target = {
            "databaseName": "target_db",
            "schemaName": "public",
            "tableName": "customers",
        }
        if target_extra:
            target.update(target_extra)
        cfg = {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": target,
        }
        cfg.update(top_level_extra)
        return cfg

    def test_parse_iceberg_target_snowflake_managed(self, parser):
        """Valid Iceberg config with catalog=SNOWFLAKE, externalVolume, baseLocationPrefix."""
        config = self._base_config(
            target_extra={
                "tableType": "iceberg",
                "icebergConfig": {
                    "catalog": "SNOWFLAKE",
                    "externalVolume": "my_ext_volume",
                    "baseLocationPrefix": "data/customers",
                },
            }
        )

        result = parser.parse_table_configuration(config)

        assert result.target_table_type == "iceberg"
        assert result.iceberg_config is not None
        assert result.iceberg_config.catalog == "SNOWFLAKE"
        assert result.iceberg_config.external_volume == "my_ext_volume"
        assert result.iceberg_config.base_location_prefix == "data/customers"
        assert result.iceberg_config.catalog_table_name is None
        assert result.iceberg_config.catalog_sync is None

    def test_parse_iceberg_target_external_catalog(self, parser):
        """Valid Iceberg config with external catalog name and catalogTableName."""
        config = self._base_config(
            target_extra={
                "tableType": "iceberg",
                "icebergConfig": {
                    "catalog": "my_glue_catalog",
                    "catalogTableName": "glue_db.customers",
                },
            }
        )

        result = parser.parse_table_configuration(config)

        assert result.target_table_type == "iceberg"
        assert result.iceberg_config is not None
        assert result.iceberg_config.catalog == "my_glue_catalog"
        assert result.iceberg_config.catalog_table_name == "glue_db.customers"
        assert result.iceberg_config.external_volume is None

    def test_parse_iceberg_target_with_catalog_sync(self, parser):
        """Valid config with catalogSync field set."""
        config = self._base_config(
            target_extra={
                "tableType": "iceberg",
                "icebergConfig": {
                    "catalog": "SNOWFLAKE",
                    "externalVolume": "my_ext_volume",
                    "catalogSync": "my_glue_sync_integration",
                },
            }
        )

        result = parser.parse_table_configuration(config)

        assert result.iceberg_config is not None
        assert result.iceberg_config.catalog_sync == "my_glue_sync_integration"

    def test_default_target_table_type_is_native(self, parser):
        """When no tableType specified, defaults to 'native' and iceberg_config is None."""
        config = self._base_config()

        result = parser.parse_table_configuration(config)

        assert result.target_table_type == "native"
        assert result.iceberg_config is None

    def test_null_target_table_type_defaults_to_native(self, parser):
        """Explicit JSON null for tableType defaults to native (same as omitted)."""
        config = self._base_config(target_extra={"tableType": None})

        result = parser.parse_table_configuration(config)

        assert result.target_table_type == "native"
        assert result.iceberg_config is None

    def test_invalid_target_table_type_raises_error(self, parser):
        """tableType='invalid' raises ConfigurationError."""
        config = self._base_config(
            target_extra={
                "tableType": "invalid",
            }
        )

        with pytest.raises(ConfigurationError, match="must be 'native' or 'iceberg'"):
            parser.parse_table_configuration(config)

    def test_iceberg_without_iceberg_config_raises_error(self, parser):
        """tableType='iceberg' but no icebergConfig raises ConfigurationError."""
        config = self._base_config(
            target_extra={
                "tableType": "iceberg",
            }
        )

        with pytest.raises(ConfigurationError, match="icebergConfig"):
            parser.parse_table_configuration(config)

    def test_snowflake_iceberg_without_external_volume_raises_error(self, parser):
        """catalog=SNOWFLAKE but no externalVolume raises ConfigurationError."""
        config = self._base_config(
            target_extra={
                "tableType": "iceberg",
                "icebergConfig": {
                    "catalog": "SNOWFLAKE",
                },
            }
        )

        with pytest.raises(ConfigurationError, match="externalVolume"):
            parser.parse_table_configuration(config)

    def test_external_catalog_without_catalog_table_name_raises_error(self, parser):
        """External catalog but no catalogTableName raises ConfigurationError."""
        config = self._base_config(
            target_extra={
                "tableType": "iceberg",
                "icebergConfig": {
                    "catalog": "my_glue_catalog",
                },
            }
        )

        with pytest.raises(ConfigurationError, match="catalogTableName"):
            parser.parse_table_configuration(config)

    def test_iceberg_config_merges_with_defaults(self, parser):
        """Iceberg config from defaultTableConfiguration merges with per-table overrides."""
        default_config = {
            "target": {
                "databaseName": "default_db",
                "schemaName": "default_schema",
                "tableType": "iceberg",
                "icebergConfig": {
                    "catalog": "SNOWFLAKE",
                    "externalVolume": "shared_volume",
                    "baseLocationPrefix": "default/prefix",
                },
            },
        }
        table_config = {
            "source": {
                "databaseName": "source_db",
                "schemaName": "dbo",
                "tableName": "orders",
            },
            "target": {
                "tableName": "orders",
                "icebergConfig": {
                    "baseLocationPrefix": "orders/data",
                },
            },
        }

        results = parser.parse_tables([table_config], default_config=default_config)

        assert len(results) == 1
        result = results[0]
        assert result.target_table_type == "iceberg"
        assert result.iceberg_config is not None
        # externalVolume inherited from default
        assert result.iceberg_config.external_volume == "shared_volume"
        # baseLocationPrefix overridden by table config
        assert result.iceberg_config.base_location_prefix == "orders/data"
        # catalog inherited from default
        assert result.iceberg_config.catalog == "SNOWFLAKE"


class TestLoadSegmentationConfiguration:
    """Tests for loadSegmentation parsing."""

    @pytest.fixture
    def parser(self):
        return ConfigurationParser()

    @pytest.fixture
    def base_config(self):
        return {
            "source": {
                "databaseName": "src_db",
                "schemaName": "dbo",
                "tableName": "orders",
            },
            "target": {
                "databaseName": "tgt_db",
                "schemaName": "public",
                "tableName": "orders",
            },
        }

    def test_load_segmentation_absent(self, parser, base_config):
        result = parser.parse_table_configuration(base_config)
        assert result.load_segmentation is None

    def test_load_segmentation_valid(self, parser, base_config):
        base_config["loadSegmentation"] = {"targetSegmentSizeMb": 5000}
        result = parser.parse_table_configuration(base_config)
        assert result.load_segmentation is not None
        assert result.load_segmentation.target_segment_size_mb == 5000

    def test_load_segmentation_missing_target_size(self, parser, base_config):
        base_config["loadSegmentation"] = {}
        with pytest.raises(ConfigurationError, match="targetSegmentSizeMb"):
            parser.parse_table_configuration(base_config)

    def test_load_segmentation_non_positive_target_size(self, parser, base_config):
        base_config["loadSegmentation"] = {"targetSegmentSizeMb": 0}
        with pytest.raises(ConfigurationError, match="positive integer"):
            parser.parse_table_configuration(base_config)

    def test_load_segmentation_negative_target_size(self, parser, base_config):
        base_config["loadSegmentation"] = {"targetSegmentSizeMb": -10}
        with pytest.raises(ConfigurationError, match="positive integer"):
            parser.parse_table_configuration(base_config)

    def test_load_segmentation_non_dict_raises(self, parser, base_config):
        base_config["loadSegmentation"] = "auto"
        with pytest.raises(ConfigurationError, match="must be an object"):
            parser.parse_table_configuration(base_config)

    def test_load_segmentation_inherited_from_defaults(self, parser, base_config):
        defaults = {"loadSegmentation": {"targetSegmentSizeMb": 3000}}
        results = parser.parse_tables([base_config], default_config=defaults)
        assert results[0].load_segmentation is not None
        assert results[0].load_segmentation.target_segment_size_mb == 3000


class TestExtractionStrategyValidation:
    """Validation rules for ``extraction.strategy`` configuration."""

    @pytest.fixture
    def parser(self):
        return ConfigurationParser()

    @pytest.fixture
    def base_config(self):
        return {
            "source": {
                "databaseName": "src",
                "schemaName": "dbo",
                "tableName": "customers",
            },
            "target": {
                "databaseName": "dst",
                "schemaName": "public",
                "tableName": "customers",
            },
            "columnNamesToPartitionBy": ["id"],
        }

    def test_write_nos_with_external_stage_parses_successfully(
        self, parser, base_config
    ):
        base_config["extraction"] = {
            "strategy": "write_nos",
            "externalStage": "@MY_DB.MY_SCHEMA.TD_NOS_STAGE",
        }
        result = parser.parse_table_configuration(base_config)
        assert result.extraction_strategy.value == "write_nos"
        assert result.extraction.external_stage == "@MY_DB.MY_SCHEMA.TD_NOS_STAGE"

    def test_write_nos_without_external_stage_raises(self, parser, base_config):
        base_config["extraction"] = {"strategy": "write_nos"}
        with pytest.raises(
            ConfigurationError, match="'write_nos' requires 'externalStage'"
        ):
            parser.parse_table_configuration(base_config)

    def test_unload_without_external_stage_still_raises(self, parser, base_config):
        # Regression: error message format was changed to include the
        # strategy name dynamically; UNLOAD must still raise.
        base_config["extraction"] = {"strategy": "unload"}
        with pytest.raises(
            ConfigurationError, match="'unload' requires 'externalStage'"
        ):
            parser.parse_table_configuration(base_config)

    def test_legacy_tpt_strategy_alias_maps_to_regular(self, parser, base_config):
        """Legacy ``strategy: tpt`` is accepted and normalized to REGULAR (TPT is DEA-side)."""
        base_config["extraction"] = {"strategy": "tpt"}
        result = parser.parse_table_configuration(base_config)
        assert result.extraction_strategy == ExtractionStrategy.REGULAR
