"""
Tests for CreatePartitionTasksHandler.

This module tests the CreatePartitionTasksHandler class.
"""

import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from data_migration_orchestrator.data_migration_cloud.tasks.handlers.create_partition_tasks_handler import (
    CreatePartitionTasksHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_boundary_generator import (
    PartitionBoundary,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.workflow_progress_service import (
    WorkflowProgressService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    CreatePartitionTasksPayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)


class TestCreatePartitionTasksHandler(unittest.TestCase):
    """Test cases for CreatePartitionTasksHandler."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_task_queue = MagicMock()
        self.mock_task_queue.push_task = AsyncMock(return_value=1)
        self.mock_task_queue.complete_task = AsyncMock(return_value=True)

        self.mock_warehouse = MagicMock()
        self.mock_warehouse.execute_sync_query = AsyncMock(return_value=[])

        self.handler = CreatePartitionTasksHandler(
            task_queue=self.mock_task_queue,
            warehouse=self.mock_warehouse,
        )

    def test_handler_initialization(self):
        """Test handler initializes with correct task type."""
        self.assertEqual(self.handler.task_type, TaskPayloadKind.CREATE_PARTITION_TASKS)

    def test_handler_has_progress_service(self):
        """Test handler initializes with a progress service."""
        self.assertIsInstance(self.handler.progress_service, WorkflowProgressService)

    def test_handler_has_boundary_generator(self):
        """Test handler initializes with a boundary generator."""
        self.assertIsNotNone(self.handler.boundary_generator)


class TestCreatePartitionTasksHandlerPartitionRowCounts(
    unittest.IsolatedAsyncioTestCase
):
    """Ensure per-partition row counts flow into progress metadata batch insert."""

    def setUp(self):
        self.mock_task_queue = MagicMock()
        self.mock_task_queue.push_task = AsyncMock(return_value=1)
        self.mock_task_queue.complete_task = AsyncMock(return_value=True)
        self.mock_warehouse = MagicMock()
        self.mock_warehouse.execute_sync_query = AsyncMock(return_value=[])
        self.handler = CreatePartitionTasksHandler(
            task_queue=self.mock_task_queue,
            warehouse=self.mock_warehouse,
        )

    async def test_build_inputs_from_new_boundaries_passes_row_counts_to_batch_insert(
        self,
    ):
        """
        Batch insert tuples must include n_rows from each PartitionBoundary.

        Verifies ``(partition_number, min, max, n_rows)`` is passed so
        ``PARTITION_METADATA.N_ROWS`` reflects analyze-derived counts for progress totals.
        """
        payload = CreatePartitionTasksPayload(
            database="SRC_DB",
            schema="SRC_SCH",
            table_name="T1",
            source_type="sqlserver",
            num_partitions=1,
            target_table="TGT_DB.TGT_SCH.T1",
            table_metadata_id=4242,
        )
        mock_partitions = [
            PartitionBoundary(
                partition_index=0,
                where_clause="WHERE lo",
                min_value=None,
                max_value=10,
                row_count=0,
            ),
            PartitionBoundary(
                partition_index=1,
                where_clause="WHERE mid",
                min_value=10,
                max_value=50,
                row_count=99_001,
            ),
            PartitionBoundary(
                partition_index=2,
                where_clause="WHERE hi",
                min_value=50,
                max_value=None,
                row_count=0,
            ),
        ]
        id_map = {0: 900, 1: 901, 2: 902}
        self.handler.progress_service.insert_partition_metadata_batch = AsyncMock(
            return_value=id_map
        )

        with (
            patch(
                "data_migration_orchestrator.data_migration_cloud.tasks.handlers."
                "create_partition_tasks_handler.read_boundaries_from_stage",
                new_callable=AsyncMock,
                return_value=[{"partition_id": 1, "n_rows": 1}],
            ),
            patch.object(
                self.handler.boundary_generator,
                "generate_boundaries",
                return_value=mock_partitions,
            ),
        ):
            inputs = await self.handler._build_inputs_from_new_boundaries(
                workflow_id=7,
                payload=payload,
                partition_columns=["id_col"],
            )

        self.handler.progress_service.insert_partition_metadata_batch.assert_awaited_once()
        kwargs = (
            self.handler.progress_service.insert_partition_metadata_batch.await_args.kwargs
        )
        self.assertEqual(kwargs["table_metadata_id"], 4242)
        self.assertEqual(
            kwargs["partitions"],
            [
                (0, None, 10, 0),
                (1, 10, 50, 99_001),
                (2, 50, None, 0),
            ],
        )
        self.assertEqual(len(inputs), 3)
        self.assertEqual(inputs[1].partition_metadata_id, 901)


if __name__ == "__main__":
    unittest.main()
