"""Tests for Snowflake identifier quoting and unquoting."""

import pytest

from data_migration_orchestrator.data_migration_cloud.platforms.snowflake.identifiers import (
    build_snowflake_fqn,
    is_already_quoted,
    needs_quoting,
    quote_identifier,
    unquote_identifier,
)


class TestIsAlreadyQuotedSnowflake:
    """Tests for is_already_quoted."""

    def test_double_quoted(self):
        assert is_already_quoted('"MyTable"') is True
        assert is_already_quoted('"Order Details"') is True

    def test_unquoted(self):
        assert is_already_quoted("MyTable") is False
        assert is_already_quoted("PUBLIC") is False


class TestNeedsQuotingSnowflake:
    """Tests for needs_quoting."""

    def test_valid_identifiers_do_not_need_quoting(self):
        assert needs_quoting("mytable") is False
        assert needs_quoting("MyTable") is False
        assert needs_quoting("MYTABLE") is False
        assert needs_quoting("MY_TABLE_123") is False
        assert needs_quoting("_private") is False
        assert needs_quoting("table$name") is False

    def test_invalid_identifiers_need_quoting(self):
        assert needs_quoting("Order Details") is True
        assert needs_quoting("my.table") is True
        assert needs_quoting("123table") is True
        assert needs_quoting("table-name") is True


class TestQuoteIdentifierSnowflake:
    """Tests for quote_identifier."""

    def test_simple_identifier(self):
        assert quote_identifier("MyTable") == '"MyTable"'

    def test_spaces(self):
        assert quote_identifier("Order Details") == '"Order Details"'

    def test_internal_double_quote_escaped(self):
        assert quote_identifier('My"Table') == '"My""Table"'

    def test_no_force_valid_not_quoted(self):
        assert quote_identifier("MYTABLE", force_quote=False) == "MYTABLE"
        assert quote_identifier("mytable", force_quote=False) == "mytable"
        assert quote_identifier("MyTable", force_quote=False) == "MyTable"

    def test_no_force_invalid_still_quoted(self):
        assert quote_identifier("Order Details", force_quote=False) == '"Order Details"'


class TestUnquoteIdentifierSnowflake:
    """Tests for unquote_identifier."""

    def test_unquote_double_quoted(self):
        assert unquote_identifier('"MyTable"') == "MyTable"

    def test_unquote_escaped_quotes(self):
        assert unquote_identifier('"My""Table"') == 'My"Table'

    def test_unquote_unquoted(self):
        assert unquote_identifier("MYTABLE") == "MYTABLE"


class TestBuildSnowflakeFqn:
    """Tests for build_snowflake_fqn."""

    def test_three_part_uppercase_identifiers(self):
        assert (
            build_snowflake_fqn("DBABB", "ECOMMERCE_TD_ODBC", "ORDERS")
            == "DBABB.ECOMMERCE_TD_ODBC.ORDERS"
        )

    def test_valid_lowercase_and_mixed_case_remain_unquoted(self):
        assert (
            build_snowflake_fqn("dbabb", "ECOMMERCE_TD_ODBC", "Orders")
            == "dbabb.ECOMMERCE_TD_ODBC.Orders"
        )

    def test_missing_database_keeps_two_parts(self):
        assert build_snowflake_fqn(None, "PUBLIC", "ORDERS") == "PUBLIC.ORDERS"

    def test_missing_schema_and_database_keeps_only_table(self):
        assert build_snowflake_fqn(None, None, "ORDERS") == "ORDERS"

    def test_missing_table_raises(self):
        with pytest.raises(ValueError):
            build_snowflake_fqn("DBABB", "ECOMMERCE_TD_ODBC", "")

    def test_special_chars_in_part_are_quoted(self):
        assert build_snowflake_fqn("DB", "MY SCHEMA", "T-1") == 'DB."MY SCHEMA"."T-1"'
