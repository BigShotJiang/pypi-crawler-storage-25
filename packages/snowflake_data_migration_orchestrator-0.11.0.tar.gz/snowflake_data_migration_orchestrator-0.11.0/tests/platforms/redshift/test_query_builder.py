"""
Unit tests for RedshiftQueryBuilder.

Tests cover SQL generation for metadata queries, schema queries,
partition boundary calculations, identifier quoting, and checksum
query generation.
"""

import pytest

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.platforms.redshift.query_builder import (
    RedshiftQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.checksum_models import (
    ColumnInfo,
    PartitionInfo,
)
from shared.enums.source_type import SourceType


class TestRedshiftQueryBuilder:
    """Test suite for RedshiftQueryBuilder."""

    @pytest.fixture
    def query_builder(self) -> RedshiftQueryBuilder:
        """Create a RedshiftQueryBuilder instance for testing."""
        return RedshiftQueryBuilder()

    def test_platform_name(self, query_builder: RedshiftQueryBuilder):
        """Test that platform_name returns 'redshift'."""
        assert query_builder.platform_name == SourceType.REDSHIFT

    def test_identifier_quote_char(self, query_builder: RedshiftQueryBuilder):
        """Test that Redshift uses double quotes for identifiers."""
        assert query_builder.identifier_quote_char == ('"', '"')

    def test_string_literal_prefix(self, query_builder: RedshiftQueryBuilder):
        """Test that Redshift has no string literal prefix."""
        assert query_builder.string_literal_prefix == ""

    def test_quote_identifier_simple(self, query_builder: RedshiftQueryBuilder):
        """Test quoting a simple identifier."""
        assert query_builder.quote_identifier("users") == '"users"'

    def test_quote_identifier_with_spaces(self, query_builder: RedshiftQueryBuilder):
        """Test quoting an identifier with spaces."""
        assert query_builder.quote_identifier("user name") == '"user name"'

    def test_quote_identifier_with_special_chars(
        self, query_builder: RedshiftQueryBuilder
    ):
        """Test quoting an identifier with special characters."""
        assert query_builder.quote_identifier("user-data") == '"user-data"'

    def test_quote_string_literal(self, query_builder: RedshiftQueryBuilder):
        """Test quoting a string literal."""
        assert query_builder.quote_string_literal("hello") == "'hello'"

    def test_quote_string_literal_with_quotes(
        self, query_builder: RedshiftQueryBuilder
    ):
        """Test quoting a string literal that contains quotes."""
        assert query_builder.quote_string_literal("it's") == "'it''s'"

    def test_build_fully_qualified_name(self, query_builder: RedshiftQueryBuilder):
        """Test building a fully qualified table name."""
        fqn = query_builder.build_fully_qualified_name("mydb", "public", "users")
        assert fqn == '"mydb"."public"."users"'

    def test_build_metadata_query(self, query_builder: RedshiftQueryBuilder):
        """Test building a metadata query for a table."""
        table_id = TableIdentifier(
            database_name="mydb", schema_name="public", table_name="users"
        )
        query = query_builder.build_metadata_query(table_id)

        # Should query SVV_TABLE_INFO for table statistics
        assert "SVV_TABLE_INFO" in query or "svv_table_info" in query.lower()
        # Should filter by schema and table
        assert "public" in query
        assert "users" in query
        # Should return row count
        assert "tbl_rows" in query.lower() or "row" in query.lower()

    def test_build_schema_query(self, query_builder: RedshiftQueryBuilder):
        """Test building a schema query for a table."""
        table_id = TableIdentifier(
            database_name="mydb", schema_name="public", table_name="users"
        )
        query = query_builder.build_schema_query(table_id)

        # Should query information_schema or SVV_COLUMNS
        assert (
            "information_schema" in query.lower()
            or "svv_columns" in query.lower()
            or "pg_catalog" in query.lower()
        )
        # Should filter by schema and table
        assert "public" in query
        assert "users" in query
        # Should select column info
        assert "column" in query.lower()

    def test_build_partition_boundary_query(self, query_builder: RedshiftQueryBuilder):
        """Test building a partition boundary query."""
        table_id = TableIdentifier(
            database_name="mydb", schema_name="public", table_name="orders"
        )
        query = query_builder.build_partition_boundary_query(table_id, "order_id", 4)

        # Should use NTILE for partitioning
        assert "NTILE" in query.upper()
        # Should reference the partition column
        assert "order_id" in query
        # Should reference the table
        assert "orders" in query
        # Should use the partition count
        assert "4" in query

    def test_build_partition_boundary_query_with_quoted_column(
        self, query_builder: RedshiftQueryBuilder
    ):
        """Test partition boundary query with a column that needs quoting."""
        table_id = TableIdentifier(
            database_name="mydb", schema_name="public", table_name="orders"
        )
        query = query_builder.build_partition_boundary_query(table_id, "Order ID", 2)

        # Should quote the column name
        assert '"Order ID"' in query

    def test_build_partition_boundary_query_multi_column_sampling(
        self, query_builder: RedshiftQueryBuilder
    ):
        """Large multi-column tables sample before NTILE lex boundary discovery."""
        table_id = TableIdentifier(
            database_name="mydb", schema_name="public", table_name="orders"
        )
        query = query_builder.build_partition_boundary_query(
            table_id,
            ["order_id", "customer_id"],
            100,
            row_count=500_000_000,
        )
        assert "RANDOM() <" in query
        assert "FROM sampled" in query
        assert "min_0" in query
        assert "max_1" in query
        assert '"order_id"' in query
        assert '"customer_id"' in query
        # 20M / 500M = 0.04
        assert "RANDOM() < 0.0400000000" in query

    def test_build_partition_boundary_query_single_column_sampling_rate(
        self, query_builder: RedshiftQueryBuilder
    ):
        """Single-column large tables still sample ~20M rows."""
        table_id = TableIdentifier(
            database_name="mydb", schema_name="public", table_name="orders"
        )
        query = query_builder.build_partition_boundary_query(
            table_id,
            "order_id",
            100,
            row_count=500_000_000,
        )
        # 20M / 500M = 0.04
        assert "RANDOM() < 0.0400000000" in query

    def test_build_unload_query(self, query_builder: RedshiftQueryBuilder):
        """Test building an UNLOAD query for data extraction."""
        query = query_builder.build_unload_query(
            select_query="SELECT * FROM mydb.public.users",
            s3_path="s3://my-bucket/exports/users/",
            iam_role="arn:aws:iam::123456789012:role/RedshiftCopyRole",
        )

        # Should use UNLOAD command
        assert "UNLOAD" in query.upper()
        # Should include the select query
        assert "SELECT * FROM mydb.public.users" in query
        # Should include S3 path
        assert "s3://my-bucket/exports/users/" in query
        # Should include IAM role
        assert "arn:aws:iam::123456789012:role/RedshiftCopyRole" in query

    def test_build_unload_query_parquet_format(
        self, query_builder: RedshiftQueryBuilder
    ):
        """Test UNLOAD query with Parquet format."""
        query = query_builder.build_unload_query(
            select_query="SELECT id, name FROM mydb.public.users",
            s3_path="s3://my-bucket/exports/users/",
            iam_role="arn:aws:iam::123456789012:role/RedshiftCopyRole",
            file_format="parquet",
        )

        assert "PARQUET" in query.upper()

    def test_build_unload_query_with_partition(
        self, query_builder: RedshiftQueryBuilder
    ):
        """Test UNLOAD query with partition filter."""
        query = query_builder.build_unload_query(
            select_query="SELECT * FROM mydb.public.orders WHERE order_id >= 1000 AND order_id < 2000",
            s3_path="s3://my-bucket/exports/orders/part_0/",
            iam_role="arn:aws:iam::123456789012:role/RedshiftCopyRole",
        )

        # Should include the WHERE clause
        assert "order_id >= 1000" in query
        assert "order_id < 2000" in query

    def test_build_unload_query_with_header(self, query_builder: RedshiftQueryBuilder):
        """Test UNLOAD query with header option for CSV."""
        query = query_builder.build_unload_query(
            select_query="SELECT * FROM mydb.public.users",
            s3_path="s3://my-bucket/exports/users/",
            iam_role="arn:aws:iam::123456789012:role/RedshiftCopyRole",
            file_format="csv",
            include_header=True,
        )

        assert "HEADER" in query.upper()

    def test_build_unload_query_with_parallel(
        self, query_builder: RedshiftQueryBuilder
    ):
        """Test UNLOAD query with parallel option disabled."""
        query = query_builder.build_unload_query(
            select_query="SELECT * FROM mydb.public.users",
            s3_path="s3://my-bucket/exports/users/",
            iam_role="arn:aws:iam::123456789012:role/RedshiftCopyRole",
            parallel=False,
        )

        assert "PARALLEL OFF" in query.upper() or "PARALLEL FALSE" in query.upper()

    def test_build_unload_query_with_max_file_size(
        self, query_builder: RedshiftQueryBuilder
    ):
        """Test UNLOAD query with max file size option."""
        query = query_builder.build_unload_query(
            select_query="SELECT * FROM mydb.public.users",
            s3_path="s3://my-bucket/exports/users/",
            iam_role="arn:aws:iam::123456789012:role/RedshiftCopyRole",
            max_file_size_mb=256,
        )

        # Should include MAXFILESIZE option
        assert "MAXFILESIZE" in query.upper()
        # Size should be specified (256 MB = 256 MB or ~268 MB in bytes)
        assert "256" in query or "268" in query

    def test_build_select_with_columns(self, query_builder: RedshiftQueryBuilder):
        """Test building a SELECT query with explicit column types."""
        table_id = TableIdentifier(
            database_name="mydb", schema_name="public", table_name="users"
        )
        query = query_builder.build_select_query(
            table_name=table_id,
            column_types=[
                {"column_name": "id", "data_type": "integer"},
                {"column_name": "name", "data_type": "character varying"},
                {"column_name": "email", "data_type": "character varying"},
            ],
        )

        assert "SELECT" in query.upper()
        assert '"id"' in query
        assert '"name"' in query
        assert '"email"' in query
        assert "mydb" in query
        assert "public" in query
        assert "users" in query
        # Should NOT use SELECT *
        assert "*" not in query.split("FROM")[0]

    def test_build_select_with_where_clause(self, query_builder: RedshiftQueryBuilder):
        """Test building a SELECT query with WHERE clause."""
        table_id = TableIdentifier(
            database_name="mydb", schema_name="public", table_name="orders"
        )
        query = query_builder.build_select_query(
            table_name=table_id,
            column_types=[
                {"column_name": "order_id", "data_type": "integer"},
                {"column_name": "order_date", "data_type": "date"},
            ],
            where_clause="order_date >= '2024-01-01'",
        )

        assert "WHERE" in query.upper()
        assert "order_date >= '2024-01-01'" in query

    def test_build_select_casts_time_and_timetz_for_unload_parquet(
        self, query_builder: RedshiftQueryBuilder
    ):
        """TIME/TIMETZ must be cast to VARCHAR for UNLOAD to Parquet (not supported natively)."""
        table_id = TableIdentifier(
            database_name="mydb", schema_name="public", table_name="data_types"
        )
        query = query_builder.build_select_query(
            table_name=table_id,
            column_types=[
                {"column_name": "id", "data_type": "integer"},
                {"column_name": "col_time", "data_type": "time"},
                {"column_name": "col_timetz", "data_type": "timetz"},
            ],
        )
        assert 'CAST("col_time" AS VARCHAR) AS "col_time"' in query
        assert 'CAST("col_timetz" AS VARCHAR) AS "col_timetz"' in query

    def test_build_select_casts_time_without_with_time_zone_for_unload(
        self, query_builder: RedshiftQueryBuilder
    ):
        """information_schema returns 'time without time zone' / 'time with time zone'."""
        table_id = TableIdentifier(
            database_name="mydb", schema_name="public", table_name="data_types"
        )
        query = query_builder.build_select_query(
            table_name=table_id,
            column_types=[
                {"column_name": "col_time", "data_type": "time without time zone"},
                {"column_name": "col_timetz", "data_type": "time with time zone"},
            ],
        )
        assert 'CAST("col_time" AS VARCHAR) AS "col_time"' in query
        assert 'CAST("col_timetz" AS VARCHAR) AS "col_timetz"' in query

    def test_build_select_casts_varbyte_for_unload_parquet(
        self, query_builder: RedshiftQueryBuilder
    ):
        """VARBYTE is only supported for UNLOAD TEXT/CSV; use TO_HEX for Parquet (CAST to VARCHAR fails on non-UTF-8)."""
        table_id = TableIdentifier(
            database_name="mydb", schema_name="public", table_name="data_types"
        )
        query = query_builder.build_select_query(
            table_name=table_id,
            column_types=[
                {"column_name": "col_varbyte", "data_type": "varbyte"},
            ],
        )
        assert 'TO_HEX("col_varbyte") AS "col_varbyte"' in query

    def test_build_select_casts_varbyte_variants_for_unload(
        self, query_builder: RedshiftQueryBuilder
    ):
        """Binary varying and varbyte(n) use TO_HEX for UNLOAD (CAST to VARCHAR fails on non-UTF-8 binary)."""
        table_id = TableIdentifier(
            database_name="mydb", schema_name="public", table_name="data_types"
        )
        for data_type in ("binary varying", "varbyte(65535)"):
            query = query_builder.build_select_query(
                table_name=table_id,
                column_types=[
                    {"column_name": "col_varbyte", "data_type": data_type},
                ],
            )
            assert 'TO_HEX("col_varbyte") AS "col_varbyte"' in query

    def test_build_select_casts_geometry_and_geography_for_unload_parquet(
        self, query_builder: RedshiftQueryBuilder
    ):
        """GEOMETRY/GEOGRAPHY are only supported for UNLOAD TEXT/CSV; use ST_AsText for WKT in Parquet."""
        table_id = TableIdentifier(
            database_name="mydb", schema_name="public", table_name="data_types"
        )
        query = query_builder.build_select_query(
            table_name=table_id,
            column_types=[
                {"column_name": "col_geometry", "data_type": "geometry"},
                {"column_name": "col_geography", "data_type": "geography"},
            ],
        )
        assert 'ST_AsText("col_geometry") AS "col_geometry"' in query
        assert 'ST_AsText("col_geography") AS "col_geography"' in query

    def test_build_select_casts_hllsketch_for_unload_parquet(
        self, query_builder: RedshiftQueryBuilder
    ):
        """HLLSKETCH cannot be cast to VARCHAR in Redshift; export NULL for UNLOAD to Parquet."""
        table_id = TableIdentifier(
            database_name="mydb", schema_name="public", table_name="data_types"
        )
        query = query_builder.build_select_query(
            table_name=table_id,
            column_types=[
                {"column_name": "col_hllsketch", "data_type": "hllsketch"},
            ],
        )
        assert 'CAST(NULL AS VARCHAR) AS "col_hllsketch"' in query

    def test_build_use_database_command_returns_none(
        self, query_builder: RedshiftQueryBuilder
    ):
        """Redshift does not support runtime database switching, so returns None."""
        result = query_builder.build_use_database_command("some_database")
        assert result is None


class TestRedshiftChecksumQuery:
    """Tests for RedshiftQueryBuilder.build_checksum_query."""

    @pytest.fixture
    def builder(self):
        """Create a builder instance."""
        return RedshiftQueryBuilder()

    @pytest.fixture
    def partition_info(self):
        """Create sample partition info."""
        return PartitionInfo(
            database="mydb",
            schema="public",
            table_name="orders",
            partition_columns=["order_id"],
            min_value="1000",
            max_value="1999",
            partition_number=1,
        )

    @pytest.fixture
    def source_table_id(self):
        """Create sample source table identifier."""
        return TableIdentifier(
            database_name="mydb",
            schema_name="public",
            table_name="orders",
        )

    @pytest.fixture
    def sample_columns(self):
        """Create sample column list with mixed types."""
        return [
            ColumnInfo("order_id", "integer", False),
            ColumnInfo("customer_name", "varchar", True),
            ColumnInfo("amount", "decimal", True, 18, 2),
            ColumnInfo("created_at", "timestamp", False),
        ]

    def test_build_checksum_query_basic(
        self, builder, partition_info, source_table_id, sample_columns
    ):
        """Test building a basic checksum query with expected SQL structure."""
        query = builder.build_checksum_query(
            partition_info, source_table_id, sample_columns
        )

        assert "farmFingerprint64(" in query
        assert "crc32(" in query
        assert "AVG(hashed_columns)" in query
        assert '"mydb"."public"."orders"' in query
        assert '"order_id" >= 1000' in query
        assert '"order_id" < 1999' in query
        assert "DECIMAL(38,0)" in query
        assert "AS checksum" in query

    def test_nullable_columns_use_coalesce(
        self, builder, partition_info, source_table_id
    ):
        """Test that nullable columns are wrapped with COALESCE after CRC32."""
        columns = [
            ColumnInfo("id", "integer", False),
            ColumnInfo("name", "varchar", True),
        ]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "COALESCE(" in query
        assert "-99999999" in query

    def test_non_nullable_columns_no_coalesce_on_crc32(
        self, builder, partition_info, source_table_id
    ):
        """Test that non-nullable columns do not have COALESCE wrapping the CRC32."""
        columns = [
            ColumnInfo("id", "integer", False),
        ]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "COALESCE(crc32(" not in query
        assert "crc32(CAST(" in query

    def test_empty_columns_falls_back_to_count(
        self, builder, partition_info, source_table_id
    ):
        """Test fallback to COUNT(*) when no columns are provided."""
        query = builder.build_checksum_query(
            partition_info, source_table_id, columns=[]
        )

        assert "COUNT(*)" in query
        assert "farmFingerprint64" not in query

    def test_partition_without_boundaries(self, builder, source_table_id):
        """Test query when partition has no boundaries (full table)."""
        partition_info = PartitionInfo(
            database="mydb",
            schema="public",
            table_name="orders",
            partition_columns=["order_id"],
            min_value=None,
            max_value=None,
            partition_number=0,
        )
        columns = [ColumnInfo("id", "integer", False)]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "WHERE 1=1" in query

    def test_charamelize_character_types_used_as_is(
        self, builder, partition_info, source_table_id
    ):
        """Test that character types are used as-is without CAST."""
        columns = [
            ColumnInfo("name", "varchar", False),
            ColumnInfo("code", "char", False),
            ColumnInfo("notes", "text", False),
            ColumnInfo("label", "character varying", False),
        ]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert 'crc32("name")' in query
        assert 'crc32("code")' in query
        assert 'crc32("notes")' in query
        assert 'crc32("label")' in query

    def test_charamelize_numeric_types_cast_to_varchar(
        self, builder, partition_info, source_table_id
    ):
        """Test that numeric types are cast to VARCHAR."""
        columns = [
            ColumnInfo("id", "integer", False),
            ColumnInfo("big_id", "bigint", False),
            ColumnInfo("amount", "decimal", False, 18, 2),
            ColumnInfo("rate", "double precision", False),
        ]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "CAST(" in query
        assert "AS VARCHAR)" in query

    def test_charamelize_boolean_type(self, builder, partition_info, source_table_id):
        """Test that boolean columns use CASE expression."""
        columns = [ColumnInfo("is_active", "boolean", False)]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "CASE" in query
        assert "'TRUE'" in query
        assert "'FALSE'" in query

    def test_charamelize_super_type(self, builder, partition_info, source_table_id):
        """Test that SUPER type uses JSON_SERIALIZE."""
        columns = [ColumnInfo("data", "super", False)]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "JSON_SERIALIZE(" in query

    def test_charamelize_binary_type(self, builder, partition_info, source_table_id):
        """Test that binary types use RIGHT(CAST(...), -2) to strip 0x prefix."""
        columns = [ColumnInfo("data", "varbyte", False)]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "RIGHT(" in query
        assert "-2)" in query

    def test_charamelize_timetz_type(self, builder, partition_info, source_table_id):
        """Test that timetz is cast to VARCHAR."""
        columns = [ColumnInfo("event_time", "timetz", False)]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "CAST(" in query
        assert "AS VARCHAR)" in query

    def test_crc32_values_concatenated_with_pipes(
        self, builder, partition_info, source_table_id
    ):
        """Test that CRC32 column expressions are concatenated with ||."""
        columns = [
            ColumnInfo("col_a", "integer", False),
            ColumnInfo("col_b", "integer", False),
        ]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "||" in query

    def test_string_partition_boundary_values_are_quoted(
        self, builder, source_table_id
    ):
        """Test that non-numeric partition boundary values are single-quoted."""
        partition_info = PartitionInfo(
            database="mydb",
            schema="public",
            table_name="orders",
            partition_columns=["region"],
            min_value="EAST",
            max_value="WEST",
            partition_number=1,
        )
        columns = [ColumnInfo("id", "integer", False)]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "'EAST'" in query
        assert "'WEST'" in query


class TestRedshiftExternalTableQueries:
    """Tests for RedshiftQueryBuilder external table (Spectrum/Iceberg) queries."""

    @pytest.fixture
    def query_builder(self) -> RedshiftQueryBuilder:
        """Create a RedshiftQueryBuilder instance for testing."""
        return RedshiftQueryBuilder()

    def test_build_external_table_schema_query(
        self, query_builder: RedshiftQueryBuilder
    ):
        """Test building an external table schema query."""
        table_id = TableIdentifier(
            database_name="mydb",
            schema_name="iceberg_schema",
            table_name="events",
        )
        query = query_builder.build_external_table_schema_query(table_id)

        # Should query SVV_EXTERNAL_COLUMNS
        assert "SVV_EXTERNAL_COLUMNS" in query
        # Should filter by schema and table
        assert "iceberg_schema" in query
        assert "events" in query
        # Should alias columns to standard names
        assert "columnname AS column_name" in query
        assert "external_type AS data_type" in query
        assert "columnnum AS ordinal_position" in query
        # Should order by column position
        assert "ORDER BY columnnum" in query

    def test_build_external_table_detection_query(
        self, query_builder: RedshiftQueryBuilder
    ):
        """Test building an external table detection query."""
        table_id = TableIdentifier(
            database_name="mydb",
            schema_name="iceberg_schema",
            table_name="events",
        )
        query = query_builder.build_external_table_detection_query(table_id)

        # Should query SVV_EXTERNAL_TABLES
        assert "SVV_EXTERNAL_TABLES" in query
        # Should return tablename and parameters
        assert "tablename" in query
        assert "parameters" in query
        # Should filter by schema and table
        assert "iceberg_schema" in query
        assert "events" in query
