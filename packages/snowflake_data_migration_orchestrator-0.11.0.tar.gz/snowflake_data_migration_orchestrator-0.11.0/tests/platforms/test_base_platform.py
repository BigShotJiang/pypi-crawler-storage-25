"""
Contract tests for BasePlatform ABC.

Verifies that the BasePlatform abstract base class enforces the correct interface contract.
"""

import pytest

from data_migration_orchestrator.data_migration_cloud.platforms.base_platform import (
    BasePlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_query_builder import (
    BaseQueryBuilder,
)


class TestBasePlatformContract:
    """Tests verifying BasePlatform ABC contract."""

    def test_base_platform_is_abstract(self):
        """Test that BasePlatform cannot be instantiated directly."""
        with pytest.raises(TypeError) as exc_info:
            BasePlatform()
        assert "abstract" in str(exc_info.value).lower()

    def test_base_platform_requires_name(self):
        """Test that subclass must implement name property."""

        class IncompletePlatform(BasePlatform):
            @property
            def display_name(self) -> str:
                return "Test"

            @property
            def aliases(self) -> list[str]:
                return []

            @property
            def default_strategy(self) -> str:
                return "odbc"

            @property
            def supported_strategies(self) -> list[str]:
                return ["odbc"]

            @property
            def query_builder(self) -> BaseQueryBuilder:
                return None

            @property
            def type_mappings(self) -> dict[str, str]:
                return {}

        with pytest.raises(TypeError):
            IncompletePlatform()

    def test_base_platform_requires_all_properties(self):
        """Test that subclass must implement all required properties."""
        required_properties = [
            "name",
            "display_name",
            "aliases",
            "default_strategy",
            "supported_strategies",
            "query_builder",
            "type_mappings",
        ]

        # Check that BasePlatform has these as abstract
        for prop in required_properties:
            assert hasattr(BasePlatform, prop), f"BasePlatform should have {prop}"

    def test_complete_platform_implementation(self):
        """Test that a complete implementation can be instantiated."""

        class MockQueryBuilder(BaseQueryBuilder):
            @property
            def platform_name(self) -> str:
                return "test"

            @property
            def identifier_quote_char(self) -> tuple[str, str]:
                return ('"', '"')

            def build_metadata_query(self, table_name: str) -> str:
                return ""

            def build_schema_query(self, table_name: str) -> str:
                return ""

            def build_partition_boundary_query(
                self, table_name: str, columns: list[str], num_partitions: int
            ) -> str:
                return ""

            def quote_identifier(self, identifier: str) -> str:
                return f'"{identifier}"'

            def normalize_identifier(self, identifier: str) -> str:
                return identifier

            def quote_column_name(self, column_name: str) -> str:
                return column_name

        class CompletePlatform(BasePlatform):
            @property
            def name(self) -> str:
                return "test"

            @property
            def display_name(self) -> str:
                return "Test Platform"

            @property
            def aliases(self) -> list[str]:
                return ["testdb"]

            @property
            def default_strategy(self) -> str:
                return "odbc"

            @property
            def supported_strategies(self) -> list[str]:
                return ["odbc"]

            @property
            def query_builder(self) -> BaseQueryBuilder:
                return MockQueryBuilder()

            @property
            def type_mappings(self) -> dict[str, str]:
                return {"INT": "NUMBER"}

        platform = CompletePlatform()
        assert platform.name == "test"
        assert platform.display_name == "Test Platform"
        assert platform.aliases == ["testdb"]
        assert platform.default_strategy == "odbc"
        assert platform.supported_strategies == ["odbc"]
        assert platform.type_mappings == {"INT": "NUMBER"}

    def test_supports_strategy_method(self):
        """Test the supports_strategy helper method."""

        class MockQueryBuilder(BaseQueryBuilder):
            @property
            def platform_name(self) -> str:
                return "test"

            @property
            def identifier_quote_char(self) -> tuple[str, str]:
                return ('"', '"')

            def build_metadata_query(self, table_name: str) -> str:
                return ""

            def build_schema_query(self, table_name: str) -> str:
                return ""

            def build_partition_boundary_query(
                self, table_name: str, columns: list[str], num_partitions: int
            ) -> str:
                return ""

            def quote_identifier(self, identifier: str) -> str:
                return f'"{identifier}"'

            def normalize_identifier(self, identifier: str) -> str:
                return identifier

            def quote_column_name(self, column_name: str) -> str:
                return column_name

        class TestPlatform(BasePlatform):
            @property
            def name(self) -> str:
                return "test"

            @property
            def display_name(self) -> str:
                return "Test"

            @property
            def aliases(self) -> list[str]:
                return []

            @property
            def default_strategy(self) -> str:
                return "odbc"

            @property
            def supported_strategies(self) -> list[str]:
                return ["odbc", "unload"]

            @property
            def query_builder(self) -> BaseQueryBuilder:
                return MockQueryBuilder()

            @property
            def type_mappings(self) -> dict[str, str]:
                return {}

        platform = TestPlatform()
        assert platform.supports_strategy("odbc")
        assert platform.supports_strategy("unload")
        assert not platform.supports_strategy("copy")

    def test_get_type_mapping_method(self):
        """Test the get_type_mapping helper method."""

        class MockQueryBuilder(BaseQueryBuilder):
            @property
            def platform_name(self) -> str:
                return "test"

            @property
            def identifier_quote_char(self) -> tuple[str, str]:
                return ('"', '"')

            def build_metadata_query(self, table_name: str) -> str:
                return ""

            def build_schema_query(self, table_name: str) -> str:
                return ""

            def build_partition_boundary_query(
                self, table_name: str, columns: list[str], num_partitions: int
            ) -> str:
                return ""

            def quote_identifier(self, identifier: str) -> str:
                return f'"{identifier}"'

            def normalize_identifier(self, identifier: str) -> str:
                return identifier

            def quote_column_name(self, column_name: str) -> str:
                return column_name

        class TestPlatform(BasePlatform):
            @property
            def name(self) -> str:
                return "test"

            @property
            def display_name(self) -> str:
                return "Test"

            @property
            def aliases(self) -> list[str]:
                return []

            @property
            def default_strategy(self) -> str:
                return "odbc"

            @property
            def supported_strategies(self) -> list[str]:
                return ["odbc"]

            @property
            def query_builder(self) -> BaseQueryBuilder:
                return MockQueryBuilder()

            @property
            def type_mappings(self) -> dict[str, str]:
                return {
                    "INT": "NUMBER",
                    "VARCHAR": "VARCHAR",
                    "DATETIME": "TIMESTAMP_NTZ",
                }

        platform = TestPlatform()
        assert platform.get_type_mapping("INT") == "NUMBER"
        assert platform.get_type_mapping("VARCHAR") == "VARCHAR"
        assert platform.get_type_mapping("UNKNOWN") is None
