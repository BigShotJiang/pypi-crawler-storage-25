from data_migration_orchestrator.data_migration_cloud.platforms import (
    PlatformRegistry,
)
from data_migration_orchestrator.data_migration_cloud.platforms.azure_synapse.platform import (
    AzureSynapsePlatform,
)
from shared.enums.source_type import SourceType


class TestAzureSynapsePlatform:
    """Tests for AzureSynapsePlatform and PlatformRegistry integration."""

    def test_platform_name(self):
        platform = AzureSynapsePlatform()
        assert platform.name == SourceType.AZURE_SYNAPSE

    def test_display_name(self):
        platform = AzureSynapsePlatform()
        assert platform.display_name == "Azure Synapse Analytics"

    def test_type_mapping_bigint(self):
        platform = AzureSynapsePlatform()
        assert platform.get_type_mapping("BIGINT") == "NUMBER"

    def test_type_mapping_varchar(self):
        platform = AzureSynapsePlatform()
        assert platform.get_type_mapping("VARCHAR") == "VARCHAR"

    def test_type_mapping_unknown_returns_none(self):
        platform = AzureSynapsePlatform()
        assert platform.get_type_mapping("XMLTYPE") is None

    def test_registry_lookup(self):
        platform_cls = PlatformRegistry.get_by_name_or_alias("azure_synapse")
        assert platform_cls is AzureSynapsePlatform

    def test_registry_alias_synapse(self):
        platform_cls = PlatformRegistry.get_by_name_or_alias("synapse")
        assert platform_cls is AzureSynapsePlatform

    def test_registry_alias_azure_sql_dw(self):
        platform_cls = PlatformRegistry.get_by_name_or_alias("azure-sql-dw")
        assert platform_cls is AzureSynapsePlatform
