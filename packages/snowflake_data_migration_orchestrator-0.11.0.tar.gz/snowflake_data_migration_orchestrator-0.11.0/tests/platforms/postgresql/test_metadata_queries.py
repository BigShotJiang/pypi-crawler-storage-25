"""
Unit tests for PostgreSQL metadata and schema query generation via PostgresqlQueryBuilder.

Tests verify that:
1. Metadata queries use COUNT(*) on the fully qualified table name for row count
2. Metadata queries use pg_total_relation_size with the fully qualified name cast to regclass for size
3. Schema queries use information_schema.columns with correct filtering
4. Query structure includes expected column aliases
5. Metadata and schema queries are meaningfully different
"""

import pytest

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.platforms.postgresql.query_builder import (
    PostgresqlQueryBuilder,
)


@pytest.fixture
def builder() -> PostgresqlQueryBuilder:
    """Create a PostgresqlQueryBuilder instance for testing."""
    return PostgresqlQueryBuilder()


def _table(
    schema: str = "public", table: str = "customers", database: str = "sampledb"
) -> TableIdentifier:
    return TableIdentifier(database_name=database, schema_name=schema, table_name=table)


class TestPostgresqlMetadataQuery:
    """Tests for PostgresqlQueryBuilder.build_metadata_query."""

    def test_uses_count_star_for_row_count(self, builder: PostgresqlQueryBuilder):
        query = builder.build_metadata_query(_table())
        assert "COUNT(*)" in query.upper()

    def test_returns_row_count_column(self, builder: PostgresqlQueryBuilder):
        query = builder.build_metadata_query(_table())
        assert "row_count" in query.lower()

    def test_returns_data_size_mb_column(self, builder: PostgresqlQueryBuilder):
        query = builder.build_metadata_query(_table())
        assert "data_size_mb" in query.lower()

    def test_uses_pg_total_relation_size(self, builder: PostgresqlQueryBuilder):
        query = builder.build_metadata_query(_table())
        assert "pg_total_relation_size" in query

    def test_embeds_fully_qualified_name_in_count_clause(
        self, builder: PostgresqlQueryBuilder
    ):
        query = builder.build_metadata_query(
            _table(schema="sales", table="orders", database="mydb")
        )
        assert "count(*) from mydb.sales.orders" in query.lower()

    def test_embeds_fully_qualified_name_in_size_function(
        self, builder: PostgresqlQueryBuilder
    ):
        query = builder.build_metadata_query(
            _table(schema="sales", table="orders", database="mydb")
        )
        assert "pg_total_relation_size('mydb.sales.orders'::regclass)" in query

    def test_filters_by_schema(self, builder: PostgresqlQueryBuilder):
        query = builder.build_metadata_query(_table(schema="sales"))
        assert "sales" in query

    def test_filters_by_table(self, builder: PostgresqlQueryBuilder):
        query = builder.build_metadata_query(_table(table="orders"))
        assert "orders" in query

    def test_starts_with_select(self, builder: PostgresqlQueryBuilder):
        query = builder.build_metadata_query(_table())
        assert query.strip().upper().startswith("SELECT")

    def test_is_substantial(self, builder: PostgresqlQueryBuilder):
        query = builder.build_metadata_query(_table())
        assert len(query) > 50


class TestPostgresqlSchemaQuery:
    """Tests for PostgresqlQueryBuilder.build_schema_query."""

    def test_uses_information_schema(self, builder: PostgresqlQueryBuilder):
        query = builder.build_schema_query(_table())
        assert "information_schema" in query.lower()

    def test_selects_column_name(self, builder: PostgresqlQueryBuilder):
        query = builder.build_schema_query(_table())
        assert "column_name" in query.lower()

    def test_selects_data_type(self, builder: PostgresqlQueryBuilder):
        query = builder.build_schema_query(_table())
        assert "data_type" in query.lower()

    def test_selects_ordinal_position(self, builder: PostgresqlQueryBuilder):
        query = builder.build_schema_query(_table())
        assert "ordinal_position" in query.lower()

    def test_filters_by_schema(self, builder: PostgresqlQueryBuilder):
        query = builder.build_schema_query(_table(schema="sales"))
        assert "sales" in query

    def test_filters_by_table(self, builder: PostgresqlQueryBuilder):
        query = builder.build_schema_query(_table(table="products"))
        assert "products" in query

    def test_starts_with_select(self, builder: PostgresqlQueryBuilder):
        query = builder.build_schema_query(_table())
        assert query.strip().upper().startswith("SELECT")

    def test_is_substantial(self, builder: PostgresqlQueryBuilder):
        query = builder.build_schema_query(_table())
        assert len(query) > 50


class TestPostgresqlQueryStructure:
    """Cross-cutting tests comparing metadata vs. schema queries."""

    def test_queries_differ_by_purpose(self, builder: PostgresqlQueryBuilder):
        table = _table(schema="public", table="test_table")
        metadata = builder.build_metadata_query(table)
        schema = builder.build_schema_query(table)

        assert metadata != schema
        assert "count(*)" in metadata.lower()
        assert "information_schema" in schema.lower()

    def test_metadata_query_contains_schema_and_table(
        self, builder: PostgresqlQueryBuilder
    ):
        table = _table(schema="inventory", table="product_catalog")
        query = builder.build_metadata_query(table)

        assert "inventory" in query
        assert "product_catalog" in query

    def test_schema_query_contains_schema_and_table(
        self, builder: PostgresqlQueryBuilder
    ):
        table = _table(schema="inventory", table="product_catalog")
        query = builder.build_schema_query(table)

        assert "inventory" in query
        assert "product_catalog" in query
