"""
Unit tests for TeradataQueryBuilder.

Tests cover SQL generation for metadata queries, schema queries,
partition boundary calculations, identifier quoting, format_sql_value,
and checksum query generation.
"""

import pytest

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.platforms.teradata.query_builder import (
    TeradataQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.checksum_models import (
    ColumnInfo,
    PartitionInfo,
)
from shared.enums.source_type import SourceType


class TestTeradataQueryBuilder:
    """Test suite for TeradataQueryBuilder."""

    @pytest.fixture
    def query_builder(self) -> TeradataQueryBuilder:
        """Create a TeradataQueryBuilder instance for testing."""
        return TeradataQueryBuilder()

    def test_platform_name(self, query_builder: TeradataQueryBuilder):
        """Test that platform_name returns 'teradata'."""
        assert query_builder.platform_name == SourceType.TERADATA

    def test_identifier_quote_char(self, query_builder: TeradataQueryBuilder):
        """Test that Teradata uses double quotes for identifiers."""
        assert query_builder.identifier_quote_char == ('"', '"')

    def test_string_literal_prefix(self, query_builder: TeradataQueryBuilder):
        """Test that Teradata has no string literal prefix."""
        assert query_builder.string_literal_prefix == ""

    def test_quote_identifier_simple(self, query_builder: TeradataQueryBuilder):
        """Test quoting a simple identifier."""
        result = query_builder.quote_identifier("users")
        assert result == '"users"'

    def test_quote_identifier_with_spaces(self, query_builder: TeradataQueryBuilder):
        """Test quoting an identifier with spaces."""
        assert query_builder.quote_identifier("user name") == '"user name"'

    def test_quote_identifier_with_special_chars(
        self, query_builder: TeradataQueryBuilder
    ):
        """Test quoting an identifier with special characters."""
        assert query_builder.quote_identifier("user-data") == '"user-data"'

    def test_quote_string_literal(self, query_builder: TeradataQueryBuilder):
        """Test quoting a string literal."""
        assert query_builder.quote_string_literal("hello") == "'hello'"

    def test_quote_string_literal_with_quotes(
        self, query_builder: TeradataQueryBuilder
    ):
        """Test quoting a string literal that contains quotes."""
        assert query_builder.quote_string_literal("it's") == "'it''s'"

    def test_build_fully_qualified_name(self, query_builder: TeradataQueryBuilder):
        """Test building a fully qualified table name."""
        fqn = query_builder.build_fully_qualified_name("mydb", "public", "users")
        assert fqn == '"mydb"."public"."users"'

    def test_build_metadata_query(self, query_builder: TeradataQueryBuilder):
        """Metadata query must rely on DBC catalog estimates, not COUNT(*)."""
        table_id = TableIdentifier(
            database_name="mydb", schema_name="mydb", table_name="users"
        )
        query = query_builder.build_metadata_query(table_id)
        upper = query.upper()

        # Hits Teradata DBC catalog views for row-count estimates and size.
        assert "DBC.TABLESTATSV" in upper
        assert "DBC.TABLESIZEV" in upper
        assert "MAX(TS.ROWCOUNT)" in upper
        assert "SUM(S.CURRENTPERM)" in upper
        assert "MYDB" in upper
        assert "USERS" in upper

    def test_build_metadata_query_prefers_catalog_over_count(
        self, query_builder: TeradataQueryBuilder
    ):
        """
        ``DBC.TableStatsV`` must be tried before falling back to COUNT(*).

        We deliberately keep a ``COUNT(*)`` fallback inside the ``COALESCE`` so
        tables without ``COLLECT STATISTICS`` still produce a real row_count
        (the previous ``-1`` sentinel broke ``read_metadata_from_stage``).
        However, the catalog-stats subquery must come first so the user table
        is only scanned when stats are genuinely missing.
        """
        table_id = TableIdentifier(
            database_name="mydb", schema_name="mydb", table_name="users"
        )
        query = query_builder.build_metadata_query(table_id)
        upper = query.upper()

        stats_pos = upper.find("DBC.TABLESTATSV")
        count_pos = upper.find("COUNT(*)")
        assert stats_pos != -1, "expected DBC.TableStatsV fast path"
        assert count_pos != -1, "expected COUNT(*) fallback for tables without stats"
        assert (
            stats_pos < count_pos
        ), "catalog-stats subquery must precede the COUNT(*) fallback"

    def test_build_schema_query(self, query_builder: TeradataQueryBuilder):
        """Test building a schema query for a table."""
        table_id = TableIdentifier(
            database_name="mydb", schema_name="mydb", table_name="users"
        )
        query = query_builder.build_schema_query(table_id)

        # Should query DBC.ColumnsV
        assert "DBC" in query.upper()
        assert "COLUMN" in query.upper()
        assert "USERS" in query.upper()

    def test_build_partition_boundary_query(self, query_builder: TeradataQueryBuilder):
        """Test building a partition boundary query."""
        table_id = TableIdentifier(
            database_name="mydb", schema_name="mydb", table_name="orders"
        )
        query = query_builder.build_partition_boundary_query(table_id, "order_id", 4)

        # Should use NTILE or equivalent for partitioning
        assert "NTILE" in query.upper() or "QUANTILE" in query.upper()
        assert "order_id" in query.lower() or "ORDER_ID" in query.upper()
        assert "ORDERS" in query.upper()
        assert "4" in query

    def test_build_select_with_columns(self, query_builder: TeradataQueryBuilder):
        """Test building a SELECT query with explicit column types."""
        table_id = TableIdentifier(
            database_name="mydb", schema_name="mydb", table_name="users"
        )
        query = query_builder.build_select_query(
            table_name=table_id,
            column_types=[
                {"column_name": "id", "data_type": "integer"},
                {"column_name": "name", "data_type": "varchar"},
                {"column_name": "email", "data_type": "varchar"},
            ],
        )

        assert "SELECT" in query.upper()
        assert "USERS" in query.upper()

    def test_build_select_with_where_clause(self, query_builder: TeradataQueryBuilder):
        """Test building a SELECT query with WHERE clause."""
        table_id = TableIdentifier(
            database_name="mydb", schema_name="mydb", table_name="orders"
        )
        query = query_builder.build_select_query(
            table_name=table_id,
            column_types=[
                {"column_name": "order_id", "data_type": "integer"},
                {"column_name": "order_date", "data_type": "date"},
            ],
            where_clause="order_date >= '2024-01-01'",
        )

        assert "WHERE" in query.upper()
        assert "order_date >= '2024-01-01'" in query

    def test_build_use_database_command_returns_database(
        self, query_builder: TeradataQueryBuilder
    ):
        """Teradata supports DATABASE command for switching databases."""
        result = query_builder.build_use_database_command("some_database")
        assert result is not None
        assert "DATABASE" in result.upper()
        assert "some_database" in result.lower() or "SOME_DATABASE" in result.upper()


class TestTeradataExtractionConversions:
    """
    Tests for ``_get_extraction_conversion`` covering DBC ColumnType codes.

    ``DBC.ColumnsV.ColumnType`` returns short codes (e.g. ``CO``, ``BV``),
    so the long type names alone are not sufficient when conversions are
    driven by schema-extraction output.  These tests assert both forms map
    to the expected templates.
    """

    @pytest.fixture
    def builder(self):
        return TeradataQueryBuilder()

    @pytest.mark.parametrize(
        "data_type",
        ["clob", "co", "xml", "xm", "json", "jn", "ut"],
    )
    def test_lob_like_codes_cast_to_varchar_64000(
        self, builder: TeradataQueryBuilder, data_type: str
    ):
        result = builder._get_extraction_conversion(data_type)
        assert result == "CAST({col} AS VARCHAR(64000))"

    @pytest.mark.parametrize(
        "data_type",
        ["byte", "bf", "varbyte", "bv", "blob", "bo"],
    )
    def test_binary_codes_hex_encode_via_from_bytes(
        self, builder: TeradataQueryBuilder, data_type: str
    ):
        result = builder._get_extraction_conversion(data_type)
        assert result == "FROM_BYTES({col}, 'base16')"

    @pytest.mark.parametrize(
        "data_type",
        [
            "period(date)",
            "period(time)",
            "period(timestamp)",
            "pd",
            "pt",
            "pz",
            "ps",
            "pm",
        ],
    )
    def test_period_long_and_codes_cast_to_varchar_100(
        self, builder: TeradataQueryBuilder, data_type: str
    ):
        result = builder._get_extraction_conversion(data_type)
        assert result == "CAST({col} AS VARCHAR(100))"

    @pytest.mark.parametrize(
        "data_type",
        ["yr", "ym", "mo", "dy", "dh", "dm", "ds", "hr", "hm", "hs", "mi", "ms", "sc"],
    )
    def test_interval_codes_cast_to_varchar_100(
        self, builder: TeradataQueryBuilder, data_type: str
    ):
        result = builder._get_extraction_conversion(data_type)
        assert result == "CAST({col} AS VARCHAR(100))"

    def test_st_geometry_uses_st_astext(self, builder: TeradataQueryBuilder):
        assert (
            builder._get_extraction_conversion("st_geometry")
            == "CAST({col}.ST_AsText() AS VARCHAR(64000))"
        )

    @pytest.mark.parametrize("data_type", ["cv", "cf", "i", "i8", "n", "d", "ts"])
    def test_codes_without_conversion_return_none(
        self, builder: TeradataQueryBuilder, data_type: str
    ):
        """Plain numeric/character DBC codes need no extraction transform."""
        assert builder._get_extraction_conversion(data_type) is None


class TestTeradataFormatSqlValue:
    """Tests for TeradataQueryBuilder.format_sql_value."""

    @pytest.fixture
    def builder(self):
        """Create a builder instance."""
        return TeradataQueryBuilder()

    def test_none_value(self, builder: TeradataQueryBuilder):
        """Test that None is formatted as NULL."""
        result = builder.format_sql_value(None)
        assert result == "NULL"

    def test_integer_value(self, builder: TeradataQueryBuilder):
        """Test integer formatting."""
        result = builder.format_sql_value(42)
        assert result == "42"

    def test_string_value(self, builder: TeradataQueryBuilder):
        """Test string formatting with quotes."""
        result = builder.format_sql_value("hello")
        assert result == "'hello'"

    def test_string_with_single_quote(self, builder: TeradataQueryBuilder):
        """Test that single quotes in strings are escaped."""
        result = builder.format_sql_value("it's")
        assert result == "'it''s'"

    def test_bool_true_renders_as_true_keyword(self, builder: TeradataQueryBuilder):
        """``bool`` must be checked before ``int | float`` (subclass concern)."""
        assert builder.format_sql_value(True) == "TRUE"

    def test_bool_false_renders_as_false_keyword(self, builder: TeradataQueryBuilder):
        assert builder.format_sql_value(False) == "FALSE"

    def test_decimal_integer_value_is_inlined_as_int(
        self, builder: TeradataQueryBuilder
    ):
        from decimal import Decimal

        assert builder.format_sql_value(Decimal("1718751")) == "1718751"

    def test_decimal_with_fraction_renders_as_float(
        self, builder: TeradataQueryBuilder
    ):
        from decimal import Decimal

        assert builder.format_sql_value(Decimal("1.5")) == "1.5"

    def test_numeric_string_is_coerced_to_int(self, builder: TeradataQueryBuilder):
        """Snowflake PARTITION_METADATA gives bounds like ``'1718751.0000000000'``."""
        assert builder.format_sql_value("1718751.0000000000") == "1718751"

    def test_numeric_string_with_double_quote_wrapping_is_coerced(
        self, builder: TeradataQueryBuilder
    ):
        """Strings wrapped in double quotes (Snowflake VARIANT) are unwrapped first."""
        assert builder.format_sql_value('"1718751"') == "1718751"


class TestTeradataChecksumQuery:
    """Tests for TeradataQueryBuilder.build_checksum_query (DMVA-aligned HASHROW)."""

    @pytest.fixture
    def builder(self):
        """Create a builder instance."""
        return TeradataQueryBuilder()

    @pytest.fixture
    def partition_info(self):
        """Create sample partition info."""
        return PartitionInfo(
            database="mydb",
            schema="mydb",
            table_name="orders",
            partition_columns=["order_id"],
            min_value="1000",
            max_value="1999",
            partition_number=1,
        )

    @pytest.fixture
    def source_table_id(self):
        """Create sample source table identifier."""
        return TableIdentifier(
            database_name="mydb",
            schema_name="mydb",
            table_name="orders",
        )

    @pytest.fixture
    def sample_columns(self):
        """Create sample column list with mixed types."""
        return [
            ColumnInfo("order_id", "integer", False),
            ColumnInfo("customer_name", "varchar", True),
            ColumnInfo("amount", "decimal", True, 18, 2),
            ColumnInfo("created_at", "timestamp", False),
        ]

    def test_build_checksum_query_basic(
        self, builder, partition_info, source_table_id, sample_columns
    ):
        """DMVA-style checksum: HASHROW args, FROM_BYTES, bucket BITAND/SHIFTRIGHT."""
        query = builder.build_checksum_query(
            partition_info, source_table_id, sample_columns
        )

        assert "WITH hashes AS" in query
        assert "FROM_BYTES('00'xb || HASHROW(" in query
        assert ", 'base16')" in query
        assert '"order_id"' in query and '"customer_name"' in query
        assert "BITAND(hashed_columns, 255)" in query
        assert "SHIFTRIGHT(hashed_columns, 8)" in query
        assert "|| ':' ||" in query
        # Teradata uses two-part naming via build_table_fqn (uppercased
        # unquoted identifiers), not three-part force-quoted segments.
        assert "FROM MYDB.ORDERS t" in query
        assert '"mydb"."mydb"."orders"' not in query
        assert "AS checksum" in query
        assert "HASHBUCKET" not in query

    def test_nullable_columns_use_raw_identifiers_in_hashrow(
        self, builder, partition_info, source_table_id
    ):
        """DMVA passes column identifiers to HASHROW (no COALESCE null-token)."""
        columns = [
            ColumnInfo("id", "integer", False),
            ColumnInfo("name", "varchar", True),
        ]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert 'HASHROW("id", "name")' in query
        assert "COALESCE" not in query

    def test_non_nullable_single_column_hashrow(
        self, builder, partition_info, source_table_id
    ):
        columns = [
            ColumnInfo("id", "integer", False),
        ]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert 'HASHROW("id")' in query

    def test_empty_columns_falls_back_to_count(
        self, builder, partition_info, source_table_id
    ):
        """DMVA uses COUNT(1) when no columns are provided."""
        query = builder.build_checksum_query(
            partition_info, source_table_id, columns=[]
        )

        assert "COUNT(1)" in query
        assert "HASHROW" not in query

    @pytest.mark.parametrize(
        "data_type",
        [
            "blob",
            "bo",
            "clob",
            "co",
            "json",
            "jn",
            "xml",
            "xm",
            "dataset",
            "dt",
            "period",
            "pd",
            "st_geometry",
            "ut",
            "mbr",
            "array",
            "a1",
            "an",
            "varray",
        ],
    )
    def test_single_skipped_data_type_falls_back_to_count(
        self, builder, partition_info, source_table_id, data_type: str
    ):
        """Each ``_SKIPPED_TYPES`` value alone yields COUNT(1) (no HASHROW)."""
        columns = [ColumnInfo("c", data_type, False)]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "COUNT(1)" in query
        assert "HASHROW" not in query

    def test_all_blob_and_clob_columns_fall_back_to_count(
        self, builder, partition_info, source_table_id
    ):
        """Multiple skipped-only columns still use COUNT(1)."""
        columns = [
            ColumnInfo("data", "blob", False),
            ColumnInfo("text", "clob", False),
        ]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "COUNT(1)" in query
        assert "HASHROW" not in query

    def test_skipped_columns_omitted_from_hashrow(
        self, builder, partition_info, source_table_id
    ):
        """Skipped types are dropped; remaining columns are still hashed."""
        columns = [
            ColumnInfo("id", "integer", False),
            ColumnInfo("meta", "json", False),
            ColumnInfo("doc", "xml", False),
        ]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert 'HASHROW("id")' in query
        assert '"meta"' not in query
        assert '"doc"' not in query

    def test_partition_without_boundaries(self, builder, source_table_id):
        """Test query when partition has no boundaries (full table)."""
        partition_info = PartitionInfo(
            database="mydb",
            schema="mydb",
            table_name="orders",
            partition_columns=["order_id"],
            min_value=None,
            max_value=None,
            partition_number=0,
        )
        columns = [ColumnInfo("id", "integer", False)]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "WHERE 1=1" in query

    def test_character_and_integer_columns_in_hashrow_list(
        self, builder, partition_info, source_table_id
    ):
        columns = [
            ColumnInfo("name", "varchar", False),
            ColumnInfo("code", "char", False),
        ]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert 'HASHROW("name", "code")' in query

    def test_integer_columns_in_hashrow_list(
        self, builder, partition_info, source_table_id
    ):
        columns = [
            ColumnInfo("id", "integer", False),
            ColumnInfo("big_id", "bigint", False),
        ]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert 'HASHROW("id", "big_id")' in query

    def test_boolean_column_in_hashrow(self, builder, partition_info, source_table_id):
        columns = [ColumnInfo("is_active", "boolean", False)]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert 'HASHROW("is_active")' in query

    def test_date_column_in_hashrow(self, builder, partition_info, source_table_id):
        columns = [ColumnInfo("created", "date", False)]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert 'HASHROW("created")' in query

    def test_timestamp_column_in_hashrow(
        self, builder, partition_info, source_table_id
    ):
        columns = [ColumnInfo("created_at", "timestamp", False)]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert 'HASHROW("created_at")' in query

    def test_varbyte_column_in_hashrow(self, builder, partition_info, source_table_id):
        columns = [ColumnInfo("data", "varbyte", False)]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert 'HASHROW("data")' in query

    def test_many_columns_use_bitxor_between_hashrow_slices(
        self, builder, partition_info, source_table_id
    ):
        """More than 64 columns → multiple HASHROW slices XOR'd (DMVA)."""
        columns = [ColumnInfo(f"c{i}", "integer", False) for i in range(70)]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "BITXOR(" in query
        assert query.count("HASHROW(") == 2

    def test_string_partition_boundary_values_are_quoted(
        self, builder, source_table_id
    ):
        """Test that non-numeric partition boundary values are single-quoted."""
        partition_info = PartitionInfo(
            database="mydb",
            schema="mydb",
            table_name="orders",
            partition_columns=["region"],
            min_value="EAST",
            max_value="WEST",
            partition_number=1,
        )
        columns = [ColumnInfo("id", "integer", False)]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "'EAST'" in query
        assert "'WEST'" in query
