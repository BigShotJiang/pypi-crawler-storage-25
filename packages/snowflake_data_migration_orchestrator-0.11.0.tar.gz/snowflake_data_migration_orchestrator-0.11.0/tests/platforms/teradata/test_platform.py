"""
Unit tests for TeradataPlatform.

Tests cover platform properties, strategy support, type mappings,
and query builder integration.
"""

import pytest

from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.platforms.teradata.platform import (
    TeradataPlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.teradata.query_builder import (
    TeradataQueryBuilder,
)
from shared.enums.source_type import SourceType


class TestTeradataPlatform:
    """Test suite for TeradataPlatform."""

    @pytest.fixture
    def platform(self) -> TeradataPlatform:
        """Create a TeradataPlatform instance for testing."""
        return TeradataPlatform()

    def test_name(self, platform: TeradataPlatform):
        """Test that platform name is 'teradata'."""
        assert platform.name == SourceType.TERADATA

    def test_display_name(self, platform: TeradataPlatform):
        """Test that display name is properly formatted."""
        assert platform.display_name == "Teradata"

    def test_aliases(self, platform: TeradataPlatform):
        """Test that common aliases are defined."""
        aliases = platform.aliases
        assert "td" in aliases
        assert "teradata-vantage" in aliases

    def test_default_strategy(self, platform: TeradataPlatform):
        """Test that default extraction strategy is REGULAR."""
        assert platform.default_strategy == ExtractionStrategy.REGULAR

    def test_supported_strategies(self, platform: TeradataPlatform):
        """Test that REGULAR and WRITE_NOS are supported."""
        strategies = platform.supported_strategies
        assert strategies == [
            ExtractionStrategy.REGULAR,
            ExtractionStrategy.WRITE_NOS,
        ]

    def test_supports_regular_strategy(self, platform: TeradataPlatform):
        """Test that REGULAR strategy is supported."""
        assert platform.supports_strategy(ExtractionStrategy.REGULAR) is True

    def test_supports_write_nos_strategy(self, platform: TeradataPlatform):
        """Test that WRITE_NOS strategy is supported (Teradata-only)."""
        assert platform.supports_strategy(ExtractionStrategy.WRITE_NOS) is True

    def test_does_not_support_unknown_strategy(self, platform: TeradataPlatform):
        """Test that unknown strategies are not supported."""
        assert platform.supports_strategy("unknown") is False

    def test_does_not_support_unload_strategy(self, platform: TeradataPlatform):
        """Test that UNLOAD strategy is not supported (that's Redshift-only)."""
        assert platform.supports_strategy(ExtractionStrategy.UNLOAD) is False

    def test_query_builder_type(self, platform: TeradataPlatform):
        """Test that query builder is the correct type."""
        assert isinstance(platform.query_builder, TeradataQueryBuilder)

    def test_query_builder_cached(self, platform: TeradataPlatform):
        """Test that query builder instance is cached."""
        qb1 = platform.query_builder
        qb2 = platform.query_builder
        assert qb1 is qb2


class TestTeradataTypeMappings:
    """Test suite for Teradata to Snowflake type mappings."""

    @pytest.fixture
    def platform(self) -> TeradataPlatform:
        """Create a TeradataPlatform instance for testing."""
        return TeradataPlatform()

    def test_type_mappings_not_empty(self, platform: TeradataPlatform):
        """Test that type mappings dictionary is populated."""
        assert len(platform.type_mappings) > 0

    # Integer types
    def test_byteint_mapping(self, platform: TeradataPlatform):
        """Test BYTEINT maps to Snowflake NUMBER."""
        assert platform.get_type_mapping("byteint") == "NUMBER(3,0)"

    def test_smallint_mapping(self, platform: TeradataPlatform):
        """Test SMALLINT maps to Snowflake NUMBER."""
        assert platform.get_type_mapping("smallint") == "NUMBER(5,0)"

    def test_integer_mapping(self, platform: TeradataPlatform):
        """Test INTEGER maps to Snowflake NUMBER."""
        assert platform.get_type_mapping("integer") == "NUMBER(10,0)"
        assert platform.get_type_mapping("int") == "NUMBER(10,0)"

    def test_bigint_mapping(self, platform: TeradataPlatform):
        """Test BIGINT maps to Snowflake NUMBER."""
        assert platform.get_type_mapping("bigint") == "NUMBER(19,0)"

    # Decimal/Numeric types
    def test_decimal_mapping(self, platform: TeradataPlatform):
        """Test DECIMAL maps to Snowflake NUMBER."""
        mapping = platform.get_type_mapping("decimal")
        assert mapping is not None
        assert "NUMBER" in mapping.upper()

    def test_numeric_mapping(self, platform: TeradataPlatform):
        """Test NUMERIC maps to Snowflake NUMBER."""
        mapping = platform.get_type_mapping("numeric")
        assert mapping is not None
        assert "NUMBER" in mapping.upper()

    def test_number_mapping(self, platform: TeradataPlatform):
        """Test NUMBER maps to Snowflake NUMBER."""
        mapping = platform.get_type_mapping("number")
        assert mapping is not None
        assert "NUMBER" in mapping.upper()

    # Floating point types
    def test_float_mapping(self, platform: TeradataPlatform):
        """Test FLOAT maps to Snowflake FLOAT."""
        assert platform.get_type_mapping("float") == "FLOAT"

    def test_real_mapping(self, platform: TeradataPlatform):
        """Test REAL maps to Snowflake FLOAT."""
        assert platform.get_type_mapping("real") == "FLOAT"

    def test_double_precision_mapping(self, platform: TeradataPlatform):
        """Test DOUBLE PRECISION maps to Snowflake FLOAT."""
        assert platform.get_type_mapping("double precision") == "FLOAT"

    # String types
    def test_char_mapping(self, platform: TeradataPlatform):
        """Test CHAR maps correctly."""
        mapping = platform.get_type_mapping("char")
        assert mapping is not None
        assert "CHAR" in mapping.upper() or "VARCHAR" in mapping.upper()

    def test_varchar_mapping(self, platform: TeradataPlatform):
        """Test VARCHAR maps to Snowflake VARCHAR."""
        mapping = platform.get_type_mapping("varchar")
        assert mapping is not None
        assert "VARCHAR" in mapping.upper()

    def test_clob_mapping(self, platform: TeradataPlatform):
        """Test CLOB maps to Snowflake VARCHAR."""
        mapping = platform.get_type_mapping("clob")
        assert mapping is not None
        assert "VARCHAR" in mapping.upper()

    # Date/Time types
    def test_date_mapping(self, platform: TeradataPlatform):
        """Test DATE maps to Snowflake DATE."""
        assert platform.get_type_mapping("date") == "DATE"

    def test_time_mapping(self, platform: TeradataPlatform):
        """Test TIME maps to Snowflake TIME."""
        assert platform.get_type_mapping("time") == "TIME"

    def test_timestamp_mapping(self, platform: TeradataPlatform):
        """Test TIMESTAMP maps to Snowflake TIMESTAMP_NTZ."""
        mapping = platform.get_type_mapping("timestamp")
        assert mapping is not None
        assert "TIMESTAMP" in mapping.upper()

    def test_timestamp_with_time_zone_mapping(self, platform: TeradataPlatform):
        """Test TIMESTAMP WITH TIME ZONE maps to Snowflake TIMESTAMP_TZ."""
        mapping = platform.get_type_mapping("timestamp with time zone")
        assert mapping is not None
        assert "TIMESTAMP" in mapping.upper()
        assert "TZ" in mapping.upper()

    # Binary types
    def test_byte_mapping(self, platform: TeradataPlatform):
        """Test BYTE maps to Snowflake BINARY."""
        mapping = platform.get_type_mapping("byte")
        assert mapping is not None
        assert "BINARY" in mapping.upper()

    def test_varbyte_mapping(self, platform: TeradataPlatform):
        """Test VARBYTE maps to Snowflake BINARY."""
        mapping = platform.get_type_mapping("varbyte")
        assert mapping is not None
        assert "BINARY" in mapping.upper()

    def test_blob_mapping(self, platform: TeradataPlatform):
        """Test BLOB maps to Snowflake BINARY."""
        mapping = platform.get_type_mapping("blob")
        assert mapping is not None
        assert "BINARY" in mapping.upper()

    # Boolean type
    def test_boolean_mapping(self, platform: TeradataPlatform):
        """Test BOOLEAN maps to Snowflake BOOLEAN."""
        mapping = platform.get_type_mapping("boolean")
        assert mapping is not None
        assert "BOOLEAN" in mapping.upper()

    # Special types
    def test_json_mapping(self, platform: TeradataPlatform):
        """Test JSON maps to Snowflake VARIANT."""
        assert platform.get_type_mapping("json") == "VARIANT"

    def test_xml_mapping(self, platform: TeradataPlatform):
        """Test XML maps to Snowflake VARCHAR."""
        mapping = platform.get_type_mapping("xml")
        assert mapping is not None
        assert "VARCHAR" in mapping.upper()

    # Interval types
    def test_interval_year_mapping(self, platform: TeradataPlatform):
        """Test INTERVAL YEAR maps to Snowflake VARCHAR."""
        mapping = platform.get_type_mapping("interval year")
        assert mapping is not None
        assert "VARCHAR" in mapping.upper()

    def test_interval_day_mapping(self, platform: TeradataPlatform):
        """Test INTERVAL DAY maps to Snowflake VARCHAR."""
        mapping = platform.get_type_mapping("interval day")
        assert mapping is not None
        assert "VARCHAR" in mapping.upper()

    # Unknown type handling
    def test_unknown_type_returns_none(self, platform: TeradataPlatform):
        """Test that unknown types return None."""
        assert platform.get_type_mapping("unknown_type_xyz") is None

    def test_case_insensitive_lookup(self, platform: TeradataPlatform):
        """Test that type lookups are case-insensitive."""
        assert platform.get_type_mapping("VARCHAR") == platform.get_type_mapping(
            "varchar"
        )
        assert platform.get_type_mapping("Integer") == platform.get_type_mapping(
            "integer"
        )
        assert platform.get_type_mapping("DATE") == platform.get_type_mapping("date")


class TestTeradataPlatformTargetFqn:
    """
    Regression tests for the target-FQN bug.

    TeradataQueryBuilder.build_table_fqn intentionally emits two-part
    ``database.table`` names (Teradata has no separate "schema" concept).
    That is correct for the *source* Teradata table, but using it for the
    *target* Snowflake table dropped the database component, e.g. produced
    ``ECOMMERCE_TD_ODBC.ORDERS`` instead of ``DBABB.ECOMMERCE_TD_ODBC.ORDERS``.

    BasePlatform.build_target_table_name fixes this by always producing a
    Snowflake-canonical 3-part FQN for the target.
    """

    @pytest.fixture
    def platform(self) -> TeradataPlatform:
        return TeradataPlatform()

    def test_source_fqn_remains_two_part(self, platform: TeradataPlatform):
        """Source path: schema may be empty; FQN is database.table only."""
        source = TableIdentifier(
            database_name="ecommerce", schema_name="", table_name="customers"
        )
        # Teradata identifier normalization upper-cases unquoted names.
        assert platform.build_normalized_table_name(source) == "ECOMMERCE.CUSTOMERS"

    def test_target_fqn_is_three_part_snowflake(self, platform: TeradataPlatform):
        """Target path: must always be database.schema.table (Snowflake canonical)."""
        target = TableIdentifier(
            database_name="DBABB",
            schema_name="ECOMMERCE_TD_ODBC",
            table_name="ORDERS",
        )
        assert (
            platform.build_target_table_name(target) == "DBABB.ECOMMERCE_TD_ODBC.ORDERS"
        )

    def test_target_fqn_leaves_valid_lowercase_unquoted(
        self, platform: TeradataPlatform
    ):
        """Segments that satisfy Snowflake unquoted identifier rules are not quoted."""
        target = TableIdentifier(
            database_name="dbabb",
            schema_name="ecommerce_td_odbc",
            table_name="Orders",
        )
        assert (
            platform.build_target_table_name(target) == "dbabb.ecommerce_td_odbc.Orders"
        )
