"""
Tests for Teradata identifier normalization, quoting, and needs_quoting.

Exercises the functions in ``teradata/identifiers.py``.
"""

from data_migration_orchestrator.data_migration_cloud.platforms.teradata.identifiers import (
    is_already_quoted,
    needs_quoting,
    normalize_identifier_teradata,
    quote_identifier_if_needed,
)


# ---------------------------------------------------------------------------
# is_already_quoted
# ---------------------------------------------------------------------------
class TestIsAlreadyQuotedTeradata:
    """Tests for is_already_quoted."""

    def test_double_quoted_is_quoted(self):
        assert is_already_quoted('"MyTable"') is True
        assert is_already_quoted('"Order Details"') is True

    def test_unquoted_is_not_quoted(self):
        assert is_already_quoted("MyTable") is False
        assert is_already_quoted("dbo") is False
        assert is_already_quoted("") is False

    def test_partial_quotes_not_quoted(self):
        assert is_already_quoted('"MyTable') is False
        assert is_already_quoted('MyTable"') is False


# ---------------------------------------------------------------------------
# needs_quoting
# ---------------------------------------------------------------------------
class TestNeedsQuotingTeradata:
    """Tests for needs_quoting."""

    def test_simple_identifiers_do_not_need_quoting(self):
        assert needs_quoting("mytable") is False
        assert needs_quoting("MyTable") is False
        assert needs_quoting("my_table_123") is False
        assert needs_quoting("_private") is False

    def test_dollar_sign_allowed(self):
        assert needs_quoting("table$1") is False

    def test_spaces_need_quoting(self):
        assert needs_quoting("Order Details") is True
        assert needs_quoting("My Table") is True

    def test_special_chars_need_quoting(self):
        assert needs_quoting("my.table") is True
        assert needs_quoting("table-name") is True

    def test_leading_digit_needs_quoting(self):
        assert needs_quoting("123table") is True
        assert needs_quoting("1_column") is True

    def test_empty_needs_quoting(self):
        assert needs_quoting("") is True

    def test_already_quoted_does_not_need_quoting(self):
        assert needs_quoting('"MyTable"') is False
        assert needs_quoting('"Order Details"') is False


# ---------------------------------------------------------------------------
# quote_identifier_if_needed
# ---------------------------------------------------------------------------
class TestQuoteIdentifierIfNeededTeradata:
    """Tests for quote_identifier_if_needed."""

    def test_simple_identifier_not_quoted(self):
        assert quote_identifier_if_needed("mytable") == "mytable"

    def test_identifier_with_spaces_quoted(self):
        assert quote_identifier_if_needed("Order Details") == '"Order Details"'

    def test_identifier_with_special_chars_quoted(self):
        assert quote_identifier_if_needed("my.table") == '"my.table"'

    def test_leading_digit_quoted(self):
        assert quote_identifier_if_needed("123table") == '"123table"'

    def test_already_quoted_returned_as_is(self):
        assert quote_identifier_if_needed('"MyTable"') == '"MyTable"'

    def test_empty_identifier(self):
        assert quote_identifier_if_needed("") == '""'

    def test_internal_double_quote_escaped(self):
        assert quote_identifier_if_needed('Table"1') == '"Table""1"'

    def test_underscore_start_not_quoted(self):
        assert quote_identifier_if_needed("_mytable") == "_mytable"


# ---------------------------------------------------------------------------
# normalize_identifier_teradata
# ---------------------------------------------------------------------------
class TestNormalizeIdentifierTeradata:
    """Tests for normalize_identifier_teradata."""

    def test_simple_identifier_uppercased(self):
        assert normalize_identifier_teradata("mytable") == "MYTABLE"

    def test_mixed_case_uppercased(self):
        assert normalize_identifier_teradata("MyTable") == "MYTABLE"

    def test_already_uppercase_unchanged(self):
        assert normalize_identifier_teradata("MYTABLE") == "MYTABLE"

    def test_special_chars_quoted_preserves_case(self):
        assert normalize_identifier_teradata("Order Details") == '"Order Details"'

    def test_leading_digit_quoted_preserves_case(self):
        assert normalize_identifier_teradata("123table") == '"123table"'

    def test_dots_quoted_preserves_case(self):
        assert normalize_identifier_teradata("my.table") == '"my.table"'

    def test_already_quoted_preserved(self):
        assert normalize_identifier_teradata('"MyTable"') == '"MyTable"'

    def test_underscore_identifier_uppercased(self):
        assert normalize_identifier_teradata("_my_table") == "_MY_TABLE"

    def test_dollar_identifier_uppercased(self):
        assert normalize_identifier_teradata("table$1") == "TABLE$1"
