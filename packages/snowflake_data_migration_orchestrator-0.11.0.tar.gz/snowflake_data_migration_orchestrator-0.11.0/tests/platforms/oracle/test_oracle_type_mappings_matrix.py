"""Oracle catalog type mappings (SNOW-3446984): registry, SnowConvert-aligned matrix, ``require_type_mapping``."""

import pytest

from data_migration_orchestrator.data_migration_cloud.platforms.oracle.platform import (
    OraclePlatform,
)
from data_migration_orchestrator.data_migration_core.type_mappings.default_mappings import (
    DEFAULT_TYPE_MAPPINGS,
    get_default_mappings,
)
from data_migration_orchestrator.data_migration_core.type_mappings.oracle_default_mappings import (
    ORACLE_TO_SNOWFLAKE_TYPE_MAPPINGS,
)
from shared.enums.source_type import SourceType

# SnowConvert-aligned matrix: count tracks in-repo keys only (smaller than DMVA epic).
_MIN_ORACLE_MAPPING_KEYS = 30


def test_oracle_registered_in_default_type_mappings() -> None:
    """``DEFAULT_TYPE_MAPPINGS`` points at the shared Oracle matrix."""
    assert SourceType.ORACLE in DEFAULT_TYPE_MAPPINGS
    assert DEFAULT_TYPE_MAPPINGS[SourceType.ORACLE] is ORACLE_TO_SNOWFLAKE_TYPE_MAPPINGS


def test_get_default_mappings_returns_oracle_matrix() -> None:
    """``get_default_mappings`` returns the in-repo Oracle dict."""
    m = get_default_mappings(SourceType.ORACLE)
    assert m is not None
    assert m is ORACLE_TO_SNOWFLAKE_TYPE_MAPPINGS


def test_mapping_matrix_covers_snowconvert_baseline() -> None:
    """Matrix size reflects SnowConvert-registered dictionary types in-repo."""
    assert len(ORACLE_TO_SNOWFLAKE_TYPE_MAPPINGS) >= _MIN_ORACLE_MAPPING_KEYS


@pytest.mark.parametrize(
    ("oracle_data_type", "snowflake_type"),
    [
        ("NUMBER(38,0)", "NUMBER"),
        ("NUMBER(10,2)", "NUMBER"),
        ("VARCHAR2(4000 CHAR)", "VARCHAR"),
        ("NVARCHAR2(2000)", "VARCHAR"),
        ("CHAR(10)", "CHAR"),
        ("NCHAR(50)", "VARCHAR"),
        ("CLOB", "VARCHAR"),
        ("NCLOB", "VARCHAR"),
        ("LONG", "VARCHAR"),
        ("DATE", "TIMESTAMP_NTZ"),
        ("TIMESTAMP(6)", "TIMESTAMP_NTZ"),
        ("TIMESTAMP(6) WITH TIME ZONE", "TIMESTAMP_TZ"),
        ("TIMESTAMP(9) WITH LOCAL TIME ZONE", "TIMESTAMP_LTZ"),
        ("FLOAT", "FLOAT"),
        ("BINARY_DOUBLE", "FLOAT"),
        ("BINARY_FLOAT", "FLOAT"),
        ("REAL", "FLOAT"),
        ("DOUBLE PRECISION", "FLOAT"),
        ("INTEGER", "NUMBER"),
        ("RAW(16)", "BINARY"),
        ("BLOB", "BINARY"),
        ("LONG RAW", "BINARY"),
        ("BFILE", "VARCHAR"),
        ("ROWID", "VARCHAR"),
        ("UROWID", "VARCHAR"),
        ("JSON", "VARIANT"),
        ("XMLTYPE", "VARIANT"),
        ("INTERVAL YEAR(2) TO MONTH", "VARCHAR"),
        ("INTERVAL DAY(2) TO SECOND(6)", "VARCHAR"),
        ("TIME", "TIME"),
    ],
)
def test_platform_maps_representative_oracle_types(
    oracle_data_type: str,
    snowflake_type: str,
) -> None:
    """Parameterized catalog ``DATA_TYPE`` strings map after normalization."""
    platform = OraclePlatform()
    assert platform.get_type_mapping(oracle_data_type) == snowflake_type


def test_unknown_oracle_type_returns_none() -> None:
    """Unmapped types yield ``None`` from ``get_type_mapping``."""
    platform = OraclePlatform()
    assert platform.get_type_mapping("CONVERT_THIS_UNDEFINED_ORACLE_TYPE") is None


def test_require_type_mapping_raises_on_unknown() -> None:
    """Strict helper raises ``ValueError`` for unknown Oracle types."""
    platform = OraclePlatform()
    with pytest.raises(ValueError, match="No Snowflake type mapping"):
        platform.require_type_mapping("MY_MISSING_DOMAIN_TYPE")


def test_require_type_mapping_returns_mapped_type() -> None:
    """Strict helper returns the same Snowflake type as ``get_type_mapping``."""
    platform = OraclePlatform()
    assert platform.require_type_mapping("CLOB") == "VARCHAR"


def test_case_insensitive_dictionary_strings_match_normalizer() -> None:
    """Catalog strings fold via ``normalize_oracle_data_type_key``."""
    platform = OraclePlatform()
    assert platform.get_type_mapping("varchar2") == platform.get_type_mapping("VARCHAR2")


def test_types_not_in_snowconvert_matrix_are_unmapped() -> None:
    """SnowConvert-only replacers omit catalog types not wired in SnowConvert."""
    platform = OraclePlatform()
    assert platform.get_type_mapping("BOOLEAN") is None
    assert platform.get_type_mapping("VECTOR") is None
    assert platform.get_type_mapping("SDO_GEOMETRY") is None
