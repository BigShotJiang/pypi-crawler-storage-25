"""Tests for Oracle schema row parsers (fixtures / mocked catalog rows)."""

from data_migration_orchestrator.data_migration_cloud.platforms.oracle.schema_discovery import (
    OracleColumnMetadata,
    OracleConstraintColumn,
    group_columns_by_constraint,
    oracle_column_from_schema_row,
    oracle_constraint_column_from_row,
)


def test_oracle_column_from_schema_row():
    """Maps a schema query row to ``OracleColumnMetadata``."""
    row = {
        "column_name": "ID",
        "data_type": "NUMBER",
        "character_maximum_length": None,
        "numeric_precision": 10,
        "numeric_scale": 0,
        "is_nullable": "N",
        "ordinal_position": 1,
    }
    col = oracle_column_from_schema_row(row)
    assert col == OracleColumnMetadata(
        column_name="ID",
        data_type="NUMBER",
        character_maximum_length=None,
        numeric_precision=10,
        numeric_scale=0,
        is_nullable="N",
        ordinal_position=1,
    )


def test_oracle_column_from_schema_row_missing_column_raises():
    """Missing a required key raises ``KeyError``."""
    row = {
        "column_name": "A",
        "data_type": "CHAR",
        "character_maximum_length": 1,
        "numeric_precision": None,
        "numeric_scale": None,
        "is_nullable": "Y",
    }
    try:
        oracle_column_from_schema_row(row)
    except KeyError as exc:
        assert exc.args[0] == "ordinal_position"
    else:
        raise AssertionError("expected KeyError")


def test_oracle_constraint_column_from_row_fk():
    """Parse a foreign-key constraint row into OracleConstraintColumn."""
    row = {
        "constraint_name": "FK_DEPT",
        "constraint_type": "R",
        "column_name": "DEPTNO",
        "ordinal_position": 1,
        "referenced_owner": "HR",
        "referenced_table": "DEPT",
        "referenced_constraint": "PK_DEPT",
    }
    c = oracle_constraint_column_from_row(row)
    assert isinstance(c, OracleConstraintColumn)
    assert c.referenced_table == "DEPT"


def test_oracle_constraint_column_from_row_pk_omits_referenced_columns():
    """PK rows have no referenced_* columns; optional keys resolve to None."""
    row = {
        "constraint_name": "PK_EMP",
        "constraint_type": "P",
        "column_name": "EMPNO",
        "ordinal_position": 1,
    }
    c = oracle_constraint_column_from_row(row)
    assert c.referenced_owner is None
    assert c.referenced_table is None
    assert c.referenced_constraint is None


def test_group_columns_by_constraint_orders_within_group():
    """Ensure grouped constraint columns are ordered by ordinal_position."""
    rows = [
        OracleConstraintColumn("PK1", "P", "B", 2),
        OracleConstraintColumn("PK1", "P", "A", 1),
    ]
    g = group_columns_by_constraint(rows)
    assert g[("P", "PK1")][0].column_name == "A"
    assert g[("P", "PK1")][1].column_name == "B"
