"""Tests shared ``normalize_oracle_data_type_key`` (platform + query builder)."""

import pytest

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.platforms.oracle.identifiers import (
    normalize_oracle_data_type_key,
)
from data_migration_orchestrator.data_migration_cloud.platforms.oracle.platform import (
    OraclePlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.oracle.query_builder import (
    OracleQueryBuilder,
)
from data_migration_orchestrator.data_migration_core.queries.constants import (
    COLUMN_NAME,
    DATA_TYPE,
)


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("TIMESTAMP(6) WITH TIME ZONE", "timestamp with time zone"),
        ("timestamp(9) with time zone", "timestamp with time zone"),
        ("TIMESTAMP(3) WITH LOCAL TIME ZONE", "timestamp with local time zone"),
        ("Timestamp(6)", "timestamp"),
        ("NUMBER(38,0)", "number"),
        ("VECTOR", "vector"),
        ("VECTOR(768, FLOAT32)", "vector"),
        ("INTERVAL YEAR(2) TO MONTH", "interval year to month"),
        ("INTERVAL DAY(2) TO SECOND(6)", "interval day to second"),
    ],
)
def test_normalize_oracle_data_type_key(raw: str, expected: str) -> None:
    """Variants where ``(…)`` must not truncate semantics (TZ, INTERVAL), plus VECTOR."""
    assert normalize_oracle_data_type_key(raw) == expected


def test_platform_get_type_mapping_timestamp_with_precision_and_tz() -> None:
    """``OraclePlatform`` path: TIMESTAMP(p) WITH [LOCAL] TIME ZONE → Snowflake."""
    platform = OraclePlatform()
    assert platform.get_type_mapping("TIMESTAMP(6) WITH TIME ZONE") == "TIMESTAMP_TZ"
    assert (
        platform.get_type_mapping("TIMESTAMP(6) WITH LOCAL TIME ZONE") == "TIMESTAMP_LTZ"
    )


def test_platform_vector_normalized_but_unmapped_in_snowconvert_matrix() -> None:
    """``VECTOR`` normalizes for extraction; SnowConvert matrix has no VECTOR replacer."""
    platform = OraclePlatform()
    assert normalize_oracle_data_type_key("VECTOR(768, FLOAT32)") == "vector"
    assert platform.get_type_mapping("VECTOR") is None
    assert platform.get_type_mapping("VECTOR(768, FLOAT32)") is None


def test_query_builder_select_aligns_with_platform_for_timestamp_tz() -> None:
    """``OracleQueryBuilder.build_select_query`` uses the same normalization key."""
    builder = OracleQueryBuilder()
    tid = TableIdentifier("ORCL", "HR", "EMP")
    cols = [
        {COLUMN_NAME: "TS_TZ", DATA_TYPE: "TIMESTAMP(6) WITH TIME ZONE"},
        {COLUMN_NAME: "TS_LTZ", DATA_TYPE: "TIMESTAMP(6) WITH LOCAL TIME ZONE"},
        {COLUMN_NAME: "TS_NT", DATA_TYPE: "TIMESTAMP(6)"},
        {COLUMN_NAME: "NOTE", DATA_TYPE: "CLOB"},
    ]
    sql_upper = builder.build_select_query(tid, cols).upper()
    select_list = sql_upper.split("FROM", 1)[0]
    assert "TS_TZ" in select_list and "TS_LTZ" in select_list and "TS_NT" in select_list
    assert select_list.count("TO_CHAR(") == 1
    assert "TO_CHAR(" in select_list and "NOTE" in select_list
