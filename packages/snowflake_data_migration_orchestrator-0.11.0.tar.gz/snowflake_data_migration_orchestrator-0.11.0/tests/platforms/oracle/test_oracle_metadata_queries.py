"""Unit tests for Oracle catalog-based metadata and schema SQL generation."""

import pytest

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.platforms.oracle.query_builder import (
    OracleQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.checksum_models import (
    ColumnInfo,
    PartitionInfo,
)
from shared.enums.source_type import SourceType


@pytest.fixture
def builder() -> OracleQueryBuilder:
    """Create an OracleQueryBuilder instance for testing."""
    return OracleQueryBuilder()


def _table(
    schema: str = "HR", table: str = "EMPLOYEES", database: str = "ORCLPDB1"
) -> TableIdentifier:
    """Build a TableIdentifier for Oracle tests."""
    return TableIdentifier(database_name=database, schema_name=schema, table_name=table)


class TestOracleMetadataQuery:
    """Tests for OracleQueryBuilder.build_metadata_query."""

    def test_row_count_prefers_all_tables_num_rows_with_count_fallback(
        self, builder: OracleQueryBuilder
    ):
        q = builder.build_metadata_query(_table()).lower()
        assert "all_tables" in q
        assert "num_rows" in q
        assert "coalesce" in q
        assert "count(*)" in q

    def test_skips_segment_dictionary_for_odbc_stability(
        self, builder: OracleQueryBuilder
    ):
        q = builder.build_metadata_query(_table())
        assert "all_segments" not in q.lower()
        assert "cast(0 as number(38, 2))" in q.lower()

    def test_returns_row_count_and_size(self, builder: OracleQueryBuilder):
        q = builder.build_metadata_query(_table())
        assert "row_count" in q.lower()
        assert "data_size_mb" in q.lower()

    def test_row_count_fallback_targets_qualified_table(
        self, builder: OracleQueryBuilder
    ):
        """COUNT(*) fallback scans the migrated table (same privilege surface as export)."""
        q = builder.build_metadata_query(_table())
        assert "count(*)" in q.lower()
        assert "hr.employees" in q.lower()

    def test_num_rows_filters_owner_and_table(self, builder: OracleQueryBuilder):
        q = builder.build_metadata_query(_table(schema="SH", table="SALES"))
        assert "t.owner = 'SH'" in q
        assert "t.table_name = 'SALES'" in q


class TestOracleSchemaQuery:
    """Tests for OracleQueryBuilder.build_schema_query."""

    def test_uses_all_tab_columns(self, builder: OracleQueryBuilder):
        q = builder.build_schema_query(_table())
        assert "all_tab_columns" in q.lower()

    def test_selects_expected_aliases(self, builder: OracleQueryBuilder):
        q = builder.build_schema_query(_table()).lower()
        for col in (
            "column_name",
            "data_type",
            "character_maximum_length",
            "numeric_precision",
            "numeric_scale",
            "is_nullable",
            "ordinal_position",
        ):
            assert col in q
        # ALL_TAB_COLUMNS.nullable is Y/N; consumers expect information_schema YES/NO (cf. Teradata).
        assert "nullable = 'y'" in q
        assert "then 'yes'" in q
        assert "else 'no'" in q

    def test_orders_by_column_id(self, builder: OracleQueryBuilder):
        q = builder.build_schema_query(_table())
        assert "order by column_id" in q.lower()


class TestOracleConstraintQueries:
    """Tests for Oracle constraint discovery SQL."""

    def test_pk_query_joins_cons_columns(self, builder: OracleQueryBuilder):
        q = builder.build_primary_key_columns_query(_table())
        assert "all_constraints" in q.lower()
        assert "all_cons_columns" in q.lower()
        assert "constraint_type = 'p'" in q.lower()

    def test_unique_query(self, builder: OracleQueryBuilder):
        q = builder.build_unique_constraint_columns_query(_table())
        assert "constraint_type = 'u'" in q.lower()

    def test_fk_query_references_parent(self, builder: OracleQueryBuilder):
        q = builder.build_foreign_key_columns_query(_table())
        assert "constraint_type = 'r'" in q.lower()
        assert "r_owner" in q.lower()


class TestOracleQueryBuilderBasics:
    """Tests for basic OracleQueryBuilder behavior."""

    def test_platform_name(self, builder: OracleQueryBuilder):
        assert builder.platform_name == SourceType.ORACLE

    def test_build_table_fqn_ignores_database(self, builder: OracleQueryBuilder):
        tid = TableIdentifier("IGNORED", "hr", "employees")
        assert builder.build_table_fqn(tid) == "HR.EMPLOYEES"

    def test_quote_column_name_leading_special_needs_quotes(
        self, builder: OracleQueryBuilder
    ):
        """Nonquoted Oracle identifiers must start with a letter; leading ``_``/``#``/``$`` are quoted."""
        assert builder.quote_column_name("_COL").startswith('"')
        assert builder.quote_column_name("#SEG").startswith('"')
        assert builder.quote_column_name("$GEN").startswith('"')
        assert builder.quote_column_name("BAD-COL").startswith('"')

    def test_quote_column_name_embedded_special_stays_unquoted(
        self, builder: OracleQueryBuilder
    ):
        """``_``, ``$``, ``#`` are allowed after the first character without quotes."""
        assert builder.quote_column_name("COL_NAME") == "COL_NAME"
        assert builder.quote_column_name("A$1") == "A$1"
        assert builder.quote_column_name("AB#C") == "AB#C"

    def test_normalize_identifier_case(self, builder: OracleQueryBuilder):
        """Unquoted valid identifiers fold to uppercase; quoted identifiers keep spelling."""
        assert builder.normalize_identifier("hr") == "HR"
        assert builder.normalize_identifier("_x") == '"_x"'
        assert builder.normalize_identifier('"Leaf"') == '"Leaf"'

    def test_build_checksum_query_raises_not_implemented(
        self, builder: OracleQueryBuilder
    ):
        """Oracle must not emit a fake checksum; callers should fail fast."""
        partition = PartitionInfo(
            database="ORCL",
            schema="HR",
            table_name="EMPLOYEES",
            partition_columns=["EMPLOYEE_ID"],
            min_value="1",
            max_value="100",
            partition_number=0,
        )
        tid = TableIdentifier("ORCL", "HR", "EMPLOYEES")
        columns = [ColumnInfo("EMPLOYEE_ID", "NUMBER", False)]
        with pytest.raises(NotImplementedError, match="Oracle partition checksum"):
            builder.build_checksum_query(partition, tid, columns)
