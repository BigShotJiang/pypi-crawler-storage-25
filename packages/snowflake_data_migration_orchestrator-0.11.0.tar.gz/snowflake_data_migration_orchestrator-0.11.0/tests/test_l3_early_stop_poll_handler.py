"""Unit tests for L3 early-stop poll handler and enqueue helper."""

import unittest
from unittest.mock import AsyncMock, MagicMock

from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.data_validation_cloud.config import (
    configuration_properties_keys as keys,
)
from data_migration_orchestrator.data_validation_cloud.scope import (
    build_l3_early_stop_skip_scope_like_pattern,
    build_l3_early_stop_skip_write_results_row_pattern,
)
from data_migration_orchestrator.data_validation_cloud.tasks.handlers import (
    l3_early_stop_poll_handler as l3_poll_mod,
)
from data_migration_orchestrator.data_validation_cloud.tasks.handlers.l3_early_stop_poll_handler import (
    L3EarlyStopPollHandler,
    maybe_push_l3_early_stop_poll,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    L3EarlyStopPollPayload,
)
from data_migration_orchestrator.data_validation_core.constants import (
    RowValidationMode,
    fq_cell_validation_results,
    fq_row_validation_results,
)


class TestMaybePushL3EarlyStopPoll(unittest.IsolatedAsyncioTestCase):
    """Tests for ``maybe_push_l3_early_stop_poll``."""

    async def test_skips_when_early_stopping_disabled(self):
        tq = MagicMock()
        tq.push_task = AsyncMock()
        await maybe_push_l3_early_stop_poll(
            tq,
            workflow_id=1,
            table_metadata_id=2,
            source_identifier="db.schema.t",
            row_validation_mode=RowValidationMode.ROW,
            table_config={},
            anchor_task_id=99,
        )
        tq.push_task.assert_not_called()

    async def test_maybe_push_passes_snowpipe_flags_on_payload(self):
        tq = MagicMock()
        tq.push_task = AsyncMock()
        table_config = {
            keys.EARLY_STOPPING: True,
            keys.EARLY_STOP_MISMATCH_ROW_THRESHOLD: 5,
            keys.EARLY_STOP_CHECK_INTERVAL_MINUTES: 1,
        }
        await maybe_push_l3_early_stop_poll(
            tq,
            workflow_id=7,
            table_metadata_id=8,
            source_identifier="db.schema.t",
            row_validation_mode=RowValidationMode.ROW,
            table_config=table_config,
            anchor_task_id=555,
            use_snowpipe_for_results=True,
        )
        tq.push_task.assert_called_once()
        pushed = tq.push_task.call_args[0][0]
        self.assertEqual(pushed.payload.anchor_task_id, 555)
        self.assertTrue(pushed.payload.use_snowpipe_for_results)


class TestL3EarlyStopPollHandler(unittest.IsolatedAsyncioTestCase):
    """Tests for ``L3EarlyStopPollHandler``."""

    async def test_stops_when_anchor_completed(self):
        tq = MagicMock()
        tq.skip_all_dv_l3_candidate_tasks = AsyncMock()
        tq.reschedule_periodical_task = AsyncMock()
        tq.complete_task = AsyncMock(return_value=True)
        wh = MagicMock()
        wh.execute_sync_query = AsyncMock(
            return_value=[{"STATUS": "completed"}],
        )
        handler = L3EarlyStopPollHandler(tq, wh)
        payload = L3EarlyStopPollPayload(
            workflow_id=1,
            table_metadata_id=2,
            source_identifier="db.schema.t",
            row_validation_mode=RowValidationMode.ROW,
            early_stop_check_interval_minutes=5,
            early_stop_mismatch_row_threshold=10,
            anchor_task_id=42,
        )
        task = Task(
            workflow_id=1,
            task_name="poll",
            executor_type=ExecutorType.ORCHESTRATOR,
            payload=payload,
            priority=3.0,
            id=100,
            scope="x",
        )
        await handler.handle(task)
        tq.complete_task.assert_awaited_once_with(ExecutorType.ORCHESTRATOR, 100)
        wh.execute_sync_query.assert_awaited()

    async def test_skips_when_over_threshold(self):
        tq = MagicMock()
        tq.reschedule_periodical_task = AsyncMock()
        tq.complete_task = AsyncMock(return_value=True)
        tq.skip_all_dv_l3_candidate_tasks = AsyncMock(return_value=3)
        tq.unblock_tasks = AsyncMock()
        wh = MagicMock()
        wh.execute_sync_query = AsyncMock(
            side_effect=[
                [{"STATUS": "blocked"}],
                [{"c": 50}],
            ],
        )
        handler = L3EarlyStopPollHandler(tq, wh)
        payload = L3EarlyStopPollPayload(
            workflow_id=1,
            table_metadata_id=2,
            source_identifier="db.schema.t",
            row_validation_mode=RowValidationMode.ROW,
            early_stop_check_interval_minutes=5,
            early_stop_mismatch_row_threshold=10,
            anchor_task_id=42,
        )
        task = Task(
            workflow_id=1,
            task_name="poll",
            executor_type=ExecutorType.ORCHESTRATOR,
            payload=payload,
            priority=3.0,
            id=100,
            scope="x",
        )
        await handler.handle(task)
        tq.skip_all_dv_l3_candidate_tasks.assert_awaited_once_with(
            1,
            "DV::Table[db.schema.t]::Partition%::RowValidation",
            42,
            "DV::Table[db.schema.t]::Partition%::WriteResults[row]",
        )
        tq.unblock_tasks.assert_awaited_once()
        self.assertEqual(tq.complete_task.await_count, 1)

    async def test_skips_snowpipe_only_row_validation_pattern(self):
        tq = MagicMock()
        tq.reschedule_periodical_task = AsyncMock()
        tq.complete_task = AsyncMock(return_value=True)
        tq.skip_all_dv_l3_candidate_tasks = AsyncMock(return_value=2)
        tq.unblock_tasks = AsyncMock()
        wh = MagicMock()
        wh.execute_sync_query = AsyncMock(
            side_effect=[
                [{"STATUS": "blocked"}],
                [{"c": 50}],
            ],
        )
        handler = L3EarlyStopPollHandler(tq, wh)
        payload = L3EarlyStopPollPayload(
            workflow_id=1,
            table_metadata_id=2,
            source_identifier="db.schema.t",
            row_validation_mode=RowValidationMode.ROW,
            early_stop_check_interval_minutes=5,
            early_stop_mismatch_row_threshold=10,
            anchor_task_id=900,
            use_snowpipe_for_results=True,
        )
        task = Task(
            workflow_id=1,
            task_name="poll",
            executor_type=ExecutorType.ORCHESTRATOR,
            payload=payload,
            priority=3.0,
            id=100,
            scope="x",
        )
        await handler.handle(task)
        tq.skip_all_dv_l3_candidate_tasks.assert_awaited_once_with(
            1,
            "DV::Table[db.schema.t]::Partition%::RowValidation",
            900,
            None,
        )
        tq.unblock_tasks.assert_awaited_once()

    async def test_reschedules_when_below_threshold(self):
        tq = MagicMock()
        tq.skip_all_dv_l3_candidate_tasks = AsyncMock()
        tq.complete_task = AsyncMock(return_value=True)
        tq.reschedule_periodical_task = AsyncMock(return_value=True)
        tq.skip_all_dv_l3_candidate_tasks = AsyncMock()
        wh = MagicMock()
        wh.execute_sync_query = AsyncMock(
            side_effect=[
                [{"STATUS": "blocked"}],
                [{"c": 2}],
            ],
        )
        handler = L3EarlyStopPollHandler(tq, wh)
        payload = L3EarlyStopPollPayload(
            workflow_id=1,
            table_metadata_id=2,
            source_identifier="db.schema.t",
            row_validation_mode=RowValidationMode.ROW,
            early_stop_check_interval_minutes=5,
            early_stop_mismatch_row_threshold=10,
            anchor_task_id=42,
        )
        task = Task(
            workflow_id=1,
            task_name="poll",
            executor_type=ExecutorType.ORCHESTRATOR,
            payload=payload,
            priority=3.0,
            id=100,
            scope="x",
        )
        await handler.handle(task)
        tq.reschedule_periodical_task.assert_awaited_once_with(
            ExecutorType.ORCHESTRATOR,
            100,
            5,
        )
        tq.skip_all_dv_l3_candidate_tasks.assert_not_called()
        tq.complete_task.assert_not_called()


class TestMismatchResultsFqn(unittest.TestCase):
    """Early-stop mismatch counts use row results for ROW and HYBRID, cell for CELL."""

    def test_hybrid_uses_row_validation_results(self):
        self.assertEqual(
            l3_poll_mod._mismatch_results_fqn(RowValidationMode.HYBRID),
            fq_row_validation_results(),
        )

    def test_cell_uses_cell_validation_results(self):
        self.assertEqual(
            l3_poll_mod._mismatch_results_fqn(RowValidationMode.CELL),
            fq_cell_validation_results(),
        )


class TestL3EarlyStopSkipScopeLikePattern(unittest.TestCase):
    """``LIKE`` pattern passed to ``SKIP_ALL_DV_L3_CANDIDATE_TASKS``."""

    def test_plain_identifier(self) -> None:
        self.assertEqual(
            build_l3_early_stop_skip_scope_like_pattern("db.s.t"),
            "DV::Table[db.s.t]::Partition%::RowValidation",
        )

    def test_escapes_like_metacharacters(self) -> None:
        self.assertEqual(
            build_l3_early_stop_skip_scope_like_pattern("p%_x"),
            r"DV::Table[p\%\_x]::Partition%::RowValidation",
        )

    def test_write_row_pattern(self) -> None:
        self.assertEqual(
            build_l3_early_stop_skip_write_results_row_pattern("db.s.t"),
            "DV::Table[db.s.t]::Partition%::WriteResults[row]",
        )

    def test_write_row_pattern_escapes(self) -> None:
        self.assertEqual(
            build_l3_early_stop_skip_write_results_row_pattern("p%_x"),
            r"DV::Table[p\%\_x]::Partition%::WriteResults[row]",
        )
