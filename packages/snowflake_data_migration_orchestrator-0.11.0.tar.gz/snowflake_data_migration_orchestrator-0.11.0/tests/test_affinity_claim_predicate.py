"""
Regression tests for SNOW-3531383: unaffined workers must not claim affined work.

These tests inspect the rendered SQL of the three claim procedures and
assert that:

1. The buggy ``OR :affinity IS NULL`` (parameter-side) disjunct is gone —
   that disjunct made an unaffined worker match every row.
2. The row-side ``AFFINITY IS NULL`` disjunct is preserved — unaffined
   tasks/workflows must remain claimable by any worker.
3. The wildcard ``*`` matching support is preserved (e.g. ``A*`` matches
   ``ABLUE``).

The Migration0024 unit test verifies the migration metadata (version,
description) and that it re-applies exactly the three affected
``.sql.j2`` assets.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0024_affinity_claim_fix import (
    Migration0024AffinityClaimFix,
)
from data_migration_orchestrator.utils.templated_sql import render_sql_jinja_template


ASSETS_DIR = (
    Path(__file__).resolve().parent.parent
    / "src"
    / "data_migration_orchestrator"
    / "assets"
)

TEMPLATE_CONTEXT = {
    "metadata_database": "TEST_DB",
    "migration_schema": "DATA_MIGRATION",
    "validation_schema": "DATA_VALIDATION",
    "qualified_migration": "TEST_DB.DATA_MIGRATION",
    "qualified_validation": "TEST_DB.DATA_VALIDATION",
}

# Procedures fixed by SNOW-3531383.
AFFINITY_CLAIM_TEMPLATES = (
    "scripts/task-queue/procedures/pull_single_task.sql.j2",
    "scripts/task-queue/procedures/pull_many_tasks.sql.j2",
    "scripts/workflows/procedures/get_pending_workflows.sql.j2",
)


def _render(template_path: str) -> str:
    """Render an asset template with the standard test context."""
    full_path = ASSETS_DIR / template_path
    raw = full_path.read_text(encoding="utf-8")
    return render_sql_jinja_template(raw, TEMPLATE_CONTEXT)


class TestAffinityClaimPredicate:
    """The fixed predicate must not let an unaffined worker claim affined rows."""

    @pytest.mark.parametrize("template_path", AFFINITY_CLAIM_TEMPLATES)
    def test_buggy_parameter_side_disjunct_is_removed(self, template_path: str) -> None:
        """``OR :affinity IS NULL`` (param-side) is the SNOW-3531383 bug."""
        sql = _render(template_path)
        # Match the parameter-side check in either case (``:affinity`` or ``:AFFINITY``).
        bad_pattern = re.compile(r"OR\s+:affinity\s+IS\s+NULL", re.IGNORECASE)
        assert not bad_pattern.search(sql), (
            f"{template_path}: rendered SQL still contains the buggy "
            "'OR :affinity IS NULL' disjunct that lets an unaffined worker "
            "claim affined rows."
        )

    @pytest.mark.parametrize("template_path", AFFINITY_CLAIM_TEMPLATES)
    def test_row_side_affinity_is_null_is_preserved(self, template_path: str) -> None:
        """Tasks/workflows with no AFFINITY must remain claimable by any worker."""
        sql = _render(template_path)
        # Match the row-side disjunct: column ``AFFINITY`` (no leading colon)
        # ``IS NULL``. Use a negative-lookbehind so we don't accidentally
        # match ``:AFFINITY IS NULL`` if a regression slips back in.
        row_side_pattern = re.compile(r"(?<!:)\bAFFINITY\s+IS\s+NULL\b", re.IGNORECASE)
        assert row_side_pattern.search(sql), (
            f"{template_path}: rendered SQL is missing the row-side "
            "'AFFINITY IS NULL' disjunct; unaffined rows would no longer "
            "be claimable by any worker."
        )

    @pytest.mark.parametrize("template_path", AFFINITY_CLAIM_TEMPLATES)
    def test_wildcard_matching_is_preserved(self, template_path: str) -> None:
        """Wildcard ``*`` worker affinity (e.g. ``A*`` matches ``ABLUE``) must still work."""
        sql = _render(template_path)
        # CONTAINS / LIKE REPLACE pattern is the wildcard handling.
        wildcard_pattern = re.compile(
            r"CONTAINS\(\s*:affinity\s*,\s*'\*'\s*\).*?LIKE\s+REPLACE\(\s*:affinity\s*,\s*'\*'\s*,\s*'%'\s*\)",
            re.IGNORECASE | re.DOTALL,
        )
        assert wildcard_pattern.search(
            sql
        ), f"{template_path}: rendered SQL is missing the wildcard CONTAINS/LIKE REPLACE matching for ``*`` affinity patterns."

    @pytest.mark.parametrize("template_path", AFFINITY_CLAIM_TEMPLATES)
    def test_exact_affinity_equality_match_is_preserved(
        self, template_path: str
    ) -> None:
        """Exact-match path (``AFFINITY = :affinity``) must remain."""
        sql = _render(template_path)
        exact_pattern = re.compile(r"AFFINITY\s*=\s*:affinity", re.IGNORECASE)
        assert exact_pattern.search(
            sql
        ), f"{template_path}: rendered SQL is missing the exact 'AFFINITY = :affinity' match."


class TestMigration0024AffinityClaimFix:
    """Metadata + asset wiring for the schema migration."""

    def test_version_is_24(self) -> None:
        assert Migration0024AffinityClaimFix().version == 24

    def test_description_mentions_affinity(self) -> None:
        description = Migration0024AffinityClaimFix().description.lower()
        assert "affinity" in description
        # Sanity: should describe the three affected procedures.
        assert "pull_single_task" in description
        assert "pull_many_tasks" in description
        assert "get_pending_workflows" in description

    def test_apply_reapplies_three_affected_assets(self) -> None:
        """``apply`` must dispatch exactly the three updated ``.sql.j2`` assets."""
        captured_paths: list[str] = []

        class _StubMigration(Migration0024AffinityClaimFix):
            def _execute_migration_sql_assets(  # type: ignore[override]
                self, cursor, script_paths
            ):
                captured_paths.extend(script_paths)

        class _StubCursor:
            def __enter__(self):
                return self

            def __exit__(self, exc_type, exc, tb):
                return False

        class _StubConnection:
            def cursor(self):
                return _StubCursor()

        _StubMigration().apply(_StubConnection())  # type: ignore[arg-type]

        assert captured_paths == list(
            AFFINITY_CLAIM_TEMPLATES
        ), "Migration0024 must re-apply exactly the three affinity-claim procedure templates, in the documented order."
