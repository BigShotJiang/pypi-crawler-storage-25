"""Unit tests for DV Snowpipe utility helpers."""

from __future__ import annotations

import re

from data_migration_orchestrator.data_validation_cloud.utils.pipe_utils import (
    DvResultsPipeKey,
    build_create_pipe_sql,
    build_drop_pipe_sql,
    build_dv_pipe_name,
    build_dv_stage_prefix,
)


# Captures the regex literal inside a ``PATTERN = '...'`` clause of CREATE PIPE.
_PATTERN_CLAUSE_RE = re.compile(r"PATTERN = '([^']+)'")


def _extract_pattern(sql: str) -> str:
    """Pull the PATTERN regex literal back out of a CREATE PIPE statement."""
    match = _PATTERN_CLAUSE_RE.search(sql)
    assert match, f"PATTERN clause not found in: {sql!r}"
    return match.group(1)


def _workflow_id_token_re(workflow_id: int) -> re.Pattern[str]:
    """
    Match ``<workflow_id>/`` only when not preceded by another digit.

    Used to assert that workflow id 99 appears as a *standalone* path
    segment in a PATTERN regex, so a substring like ``/100/`` does not
    falsely contain ``99``.
    """
    return re.compile(rf"(?<!\d){workflow_id}/")


_TMID = 5001


class TestBuildDvPipeName:
    """Validate pipe name formatting for the per-table, temporary scheme."""

    def test_metrics(self):
        name = build_dv_pipe_name(42, _TMID, DvResultsPipeKey.METRICS)
        assert name.endswith(f".DVO_PIPE_42_{_TMID}_METRICS")
        assert name == name.upper()

    def test_row_diffs(self):
        name = build_dv_pipe_name(7, 99, DvResultsPipeKey.ROW_DIFFS)
        assert name.endswith(".DVO_PIPE_7_99_ROW_DIFFS")

    def test_name_is_workflow_scoped(self):
        """Same table id across workflows must yield different pipe names."""
        a = build_dv_pipe_name(1, _TMID, DvResultsPipeKey.METRICS)
        b = build_dv_pipe_name(2, _TMID, DvResultsPipeKey.METRICS)
        assert a != b
        assert "_1_" in a
        assert "_2_" in b

    def test_same_workflow_distinct_tables_yield_distinct_names(self):
        a = build_dv_pipe_name(1, 10, DvResultsPipeKey.METRICS)
        b = build_dv_pipe_name(1, 11, DvResultsPipeKey.METRICS)
        assert a != b
        assert "_10_" in a
        assert "_11_" in b

    def test_all_keys_yield_distinct_names(self):
        names = {build_dv_pipe_name(1, _TMID, key) for key in DvResultsPipeKey}
        assert len(names) == len(list(DvResultsPipeKey))


class TestBuildDvStagePrefix:
    """Validate stage prefix formatting for ALTER PIPE REFRESH."""

    def test_prefix_with_partition(self):
        prefix = build_dv_stage_prefix(
            workflow_id=1, table_metadata_id=2, level="row", partition_number=3
        )
        assert prefix == "1/2/row/p3/"

    def test_prefix_without_partition(self):
        prefix = build_dv_stage_prefix(
            workflow_id=1, table_metadata_id=2, level="metrics", partition_number=None
        )
        assert prefix == "1/2/metrics/"


class TestBuildCreatePipeSql:
    """Validate per-key CREATE PIPE SQL shape."""

    def _common_assertions(self, sql: str, pipe_name: str, level_segment: str):
        assert sql.startswith("CREATE PIPE IF NOT EXISTS ")
        assert pipe_name in sql
        assert "COPY INTO" in sql
        assert "FILE_FORMAT" in sql
        assert "ON_ERROR = 'CONTINUE'" in sql
        pattern = _extract_pattern(sql)
        # Pattern must scope to the level/subdir for this key (e.g. '/cell/p')
        assert (
            level_segment in pattern
        ), f"expected {level_segment!r} in PATTERN {pattern!r}"

    def test_metrics_sql(self):
        pipe = build_dv_pipe_name(42, _TMID, DvResultsPipeKey.METRICS)
        sql = build_create_pipe_sql(42, _TMID, pipe, DvResultsPipeKey.METRICS)
        self._common_assertions(sql, pipe, "/metrics/p")
        assert "METRICS_VALIDATION_RESULTS" in sql

    def test_row_diffs_sql_extracts_partition_from_filename(self):
        pipe = build_dv_pipe_name(42, _TMID, DvResultsPipeKey.ROW_DIFFS)
        sql = build_create_pipe_sql(42, _TMID, pipe, DvResultsPipeKey.ROW_DIFFS)
        self._common_assertions(sql, pipe, "/row/p")
        assert "ROW_VALIDATION_RESULTS" in sql
        assert "METADATA$FILENAME" in sql
        assert "REGEXP_SUBSTR" in sql

    def test_row_summary_sql(self):
        pipe = build_dv_pipe_name(42, _TMID, DvResultsPipeKey.ROW_SUMMARY)
        sql = build_create_pipe_sql(42, _TMID, pipe, DvResultsPipeKey.ROW_SUMMARY)
        self._common_assertions(sql, pipe, "/row/p")
        assert "ROW_VALIDATION_SUMMARY" in sql

    def test_chunk_hashes_sql(self):
        pipe = build_dv_pipe_name(42, _TMID, DvResultsPipeKey.CHUNK_HASHES)
        sql = build_create_pipe_sql(42, _TMID, pipe, DvResultsPipeKey.CHUNK_HASHES)
        self._common_assertions(sql, pipe, "/row/p")
        assert "CHUNK_HASHES" in sql

    def test_cell_diffs_sql(self):
        pipe = build_dv_pipe_name(42, _TMID, DvResultsPipeKey.CELL_DIFFS)
        sql = build_create_pipe_sql(42, _TMID, pipe, DvResultsPipeKey.CELL_DIFFS)
        self._common_assertions(sql, pipe, "/cell/p")
        assert "CELL_VALIDATION_RESULTS" in sql

    def test_pattern_includes_workflow_id(self):
        """PATTERN must scope ingestion to this workflow's subtree."""
        tmid_a, tmid_b = 50, 60
        sql_a = build_create_pipe_sql(
            99,
            tmid_a,
            build_dv_pipe_name(99, tmid_a, DvResultsPipeKey.METRICS),
            DvResultsPipeKey.METRICS,
        )
        sql_b = build_create_pipe_sql(
            100,
            tmid_b,
            build_dv_pipe_name(100, tmid_b, DvResultsPipeKey.METRICS),
            DvResultsPipeKey.METRICS,
        )
        pattern_a = _extract_pattern(sql_a)
        pattern_b = _extract_pattern(sql_b)
        # Workflow id must appear in its own pattern but not the other's
        assert "99/" in pattern_a
        assert "100/" in pattern_b
        assert "99/" not in pattern_b
        # Substring "100" trivially contains "00" but not "99"
        # A naive check would let "/99/" leak via "/100/"; assert on the
        # full digit boundary instead.
        wid_99 = _workflow_id_token_re(99)
        assert wid_99.search(pattern_a)
        assert not wid_99.search(pattern_b)

    def test_from_clause_has_no_workflow_id(self):
        """FROM must watch the stage root; workflow scoping goes into PATTERN."""
        pipe = build_dv_pipe_name(42, _TMID, DvResultsPipeKey.METRICS)
        sql = build_create_pipe_sql(42, _TMID, pipe, DvResultsPipeKey.METRICS)
        from_clause = sql.split("FROM (SELECT")[1].split(") PATTERN")[0]
        assert "/42/" not in from_clause


class TestPatternRegexMatchesStagePaths:
    """
    The PATTERN regex must match the relative paths Snowpipe sees.

    Snowpipe applies the regex to two path shapes for the same file:

    * REFRESH path includes the lowercased stage name segment (e.g.
      ``task_results/<wfid>/<tmid>/<level>/p<N>/<subdir>/<file>``).
    * Ingestion path omits that segment (e.g.
      ``<wfid>/<tmid>/<level>/p<N>/<subdir>/<file>``).

    A regex that only matches one shape silently drops files between
    REFRESH and ingestion, leaving the result tables empty. This test
    locks in that both shapes are matched.
    """

    @staticmethod
    def _pattern(
        workflow_id: int, table_metadata_id: int, key: DvResultsPipeKey
    ) -> str:
        sql = build_create_pipe_sql(
            workflow_id,
            table_metadata_id,
            build_dv_pipe_name(workflow_id, table_metadata_id, key),
            key,
        )
        return _extract_pattern(sql)

    @staticmethod
    def _both_shapes(rel: str) -> list[str]:
        """Return the path with and without the ``task_results/`` prefix."""
        return [rel, f"task_results/{rel}"]

    def test_metrics_pattern_matches_both_shapes(self):
        tmid = 43
        pat = self._pattern(42, tmid, DvResultsPipeKey.METRICS)
        for path in self._both_shapes(f"42/{tmid}/metrics/p1/validation_result.csv.gz"):
            assert re.fullmatch(pat, path), f"PATTERN did not match {path!r}"

    def test_cell_diffs_pattern_matches_both_shapes(self):
        tmid = 43
        pat = self._pattern(42, tmid, DvResultsPipeKey.CELL_DIFFS)
        for path in self._both_shapes(f"42/{tmid}/cell/p1/diffs/diffs.csv.gz"):
            assert re.fullmatch(pat, path), f"PATTERN did not match {path!r}"

    def test_row_diffs_pattern_matches_both_shapes(self):
        tmid = 43
        pat = self._pattern(42, tmid, DvResultsPipeKey.ROW_DIFFS)
        for path in self._both_shapes(f"42/{tmid}/row/p1/diffs/diffs.csv.gz"):
            assert re.fullmatch(pat, path), f"PATTERN did not match {path!r}"

    def test_row_summary_pattern_matches_both_shapes(self):
        tmid = 43
        pat = self._pattern(42, tmid, DvResultsPipeKey.ROW_SUMMARY)
        for path in self._both_shapes(f"42/{tmid}/row/p1/summary/summary.csv.gz"):
            assert re.fullmatch(pat, path), f"PATTERN did not match {path!r}"

    def test_chunk_hashes_pattern_matches_both_shapes(self):
        tmid = 43
        pat = self._pattern(42, tmid, DvResultsPipeKey.CHUNK_HASHES)
        for path in self._both_shapes(f"42/{tmid}/row/p1/hashes/hashes.csv.gz"):
            assert re.fullmatch(pat, path), f"PATTERN did not match {path!r}"

    def test_pattern_rejects_other_workflows(self):
        """PATTERN for workflow 42 / table 42 must not match other wf/tables."""
        tmid = 42
        pat = self._pattern(42, tmid, DvResultsPipeKey.CELL_DIFFS)
        bad = [
            "41/41/cell/p1/diffs/diffs.csv.gz",
            "420/420/cell/p1/diffs/diffs.csv.gz",
            "task_results/41/41/cell/p1/diffs/diffs.csv.gz",
            "task_results/420/420/cell/p1/diffs/diffs.csv.gz",
            # Wrong table under same workflow
            "42/99/cell/p1/diffs/diffs.csv.gz",
            # Wrong level
            f"42/{tmid}/row/p1/diffs/diffs.csv.gz",
            # Wrong subdir
            f"42/{tmid}/cell/p1/summary/diffs.csv.gz",
        ]
        for p in bad:
            assert not re.fullmatch(pat, p), f"PATTERN unexpectedly matched {p!r}"


class TestBuildDropPipeSql:
    """Validate the shared DROP PIPE helper re-exported from DV utils."""

    def test_shape(self):
        sql = build_drop_pipe_sql("FOO.BAR.BAZ")
        assert sql == "DROP PIPE IF EXISTS FOO.BAR.BAZ"
