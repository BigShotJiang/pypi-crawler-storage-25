"""Unit tests for the index-build polling helpers on ``BaseMigration``."""

from __future__ import annotations

import unittest

from unittest.mock import MagicMock, patch

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
    IndexBuildFailedError,
    IndexBuildTimeoutError,
)


class _StubMigration(BaseMigration):
    """Minimal concrete migration used to exercise the helpers."""

    @property
    def version(self) -> int:
        return 999

    @property
    def description(self) -> str:
        return "stub for index build helper tests"

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        return None


def _make_cursor_with_status_sequence(
    sequences: list[list[tuple[str, str]]],
) -> MagicMock:
    """
    Build a mock cursor whose successive polls return each entry in ``sequences``.

    Each element of ``sequences`` is the tuple list returned by ``fetchall()``
    on one polling iteration.
    """
    cursor = MagicMock()
    cursor.fetchall.side_effect = sequences
    cursor.execute.return_value = None
    return cursor


# ---------------------------------------------------------------------------
# _wait_for_no_in_progress_index_build
# ---------------------------------------------------------------------------
class TestWaitForNoInProgressIndexBuild(unittest.TestCase):
    """Behavior of the pre-CREATE wait helper."""

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration.time.sleep"
    )
    def test_returns_immediately_when_no_indexes(self, mock_sleep):
        cursor = _make_cursor_with_status_sequence([[]])

        BaseMigration._wait_for_no_in_progress_index_build(
            cursor=cursor,
            database="DB",
            schema="S",
            table="T",
            timeout_s=10.0,
            poll_interval_s=1.0,
        )

        self.assertEqual(cursor.fetchall.call_count, 1)
        mock_sleep.assert_not_called()

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration.time.sleep"
    )
    def test_returns_immediately_when_all_active(self, mock_sleep):
        cursor = _make_cursor_with_status_sequence([[("IDX_A", "ACTIVE")]])

        BaseMigration._wait_for_no_in_progress_index_build(
            cursor=cursor,
            database="DB",
            schema="S",
            table="T",
            timeout_s=10.0,
            poll_interval_s=1.0,
        )

        mock_sleep.assert_not_called()

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration.time.sleep"
    )
    def test_polls_until_build_in_progress_clears(self, mock_sleep):
        cursor = _make_cursor_with_status_sequence(
            [
                [("IDX_A", "BUILD IN PROGRESS")],
                [("IDX_A", "BUILD IN PROGRESS")],
                [("IDX_A", "ACTIVE")],
            ]
        )

        BaseMigration._wait_for_no_in_progress_index_build(
            cursor=cursor,
            database="DB",
            schema="S",
            table="T",
            timeout_s=60.0,
            poll_interval_s=1.5,
        )

        self.assertEqual(cursor.fetchall.call_count, 3)
        # Sleeps exactly between the two non-final polls.
        self.assertEqual(mock_sleep.call_count, 2)

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration.time.sleep"
    )
    def test_raises_on_build_failure(self, mock_sleep):
        cursor = _make_cursor_with_status_sequence(
            [[("IDX_A", "BUILD FAILURE"), ("IDX_B", "ACTIVE")]]
        )

        with self.assertRaises(IndexBuildFailedError) as ctx:
            BaseMigration._wait_for_no_in_progress_index_build(
                cursor=cursor,
                database="DB",
                schema="S",
                table="T",
                timeout_s=10.0,
                poll_interval_s=1.0,
            )

        self.assertIn("IDX_A", str(ctx.exception))
        mock_sleep.assert_not_called()

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration.time.monotonic"
    )
    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration.time.sleep"
    )
    def test_raises_on_timeout(self, mock_sleep, mock_monotonic):
        # Clock advances past the deadline between the deadline computation
        # (t=0, so deadline=10) and the first remaining check (t=11).
        mock_monotonic.side_effect = [0.0, 11.0]
        cursor = _make_cursor_with_status_sequence([[("IDX_A", "BUILD IN PROGRESS")]])

        with self.assertRaises(IndexBuildTimeoutError) as ctx:
            BaseMigration._wait_for_no_in_progress_index_build(
                cursor=cursor,
                database="DB",
                schema="S",
                table="T",
                timeout_s=10.0,
                poll_interval_s=1.0,
            )

        self.assertIn("IDX_A", str(ctx.exception))
        mock_sleep.assert_not_called()

    def test_query_filters_by_schema_and_table(self):
        cursor = _make_cursor_with_status_sequence([[]])

        BaseMigration._wait_for_no_in_progress_index_build(
            cursor=cursor,
            database="MY_DB",
            schema="MY_SCHEMA",
            table="TASK_QUEUE",
            timeout_s=1.0,
            poll_interval_s=0.1,
        )

        sql, params = cursor.execute.call_args.args
        self.assertIn("MY_DB.INFORMATION_SCHEMA.INDEXES", sql)
        self.assertIn("TABLE_SCHEMA = %s", sql)
        self.assertIn("TABLE_NAME = %s", sql)
        self.assertEqual(params, ("MY_SCHEMA", "TASK_QUEUE"))


# ---------------------------------------------------------------------------
# _wait_for_index_active
# ---------------------------------------------------------------------------
class TestWaitForIndexActive(unittest.TestCase):
    """Behavior of the post-CREATE wait helper."""

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration.time.sleep"
    )
    def test_returns_when_target_index_active(self, mock_sleep):
        cursor = _make_cursor_with_status_sequence(
            [[("IDX_A", "ACTIVE"), ("IDX_OTHER", "BUILD IN PROGRESS")]]
        )

        BaseMigration._wait_for_index_active(
            cursor=cursor,
            database="DB",
            schema="S",
            table="T",
            index_name="IDX_A",
            timeout_s=10.0,
            poll_interval_s=1.0,
        )

        mock_sleep.assert_not_called()

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration.time.sleep"
    )
    def test_polls_until_target_active(self, mock_sleep):
        cursor = _make_cursor_with_status_sequence(
            [
                [("IDX_A", "BUILD IN PROGRESS")],
                [("IDX_A", "ACTIVE")],
            ]
        )

        BaseMigration._wait_for_index_active(
            cursor=cursor,
            database="DB",
            schema="S",
            table="T",
            index_name="IDX_A",
            timeout_s=10.0,
            poll_interval_s=0.5,
        )

        self.assertEqual(cursor.fetchall.call_count, 2)
        self.assertEqual(mock_sleep.call_count, 1)

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration.time.sleep"
    )
    def test_polls_when_target_index_not_yet_visible(self, mock_sleep):
        # First poll returns no rows for the target index (e.g. metadata
        # propagation delay); next poll shows it ACTIVE.
        cursor = _make_cursor_with_status_sequence(
            [
                [],
                [("IDX_A", "ACTIVE")],
            ]
        )

        BaseMigration._wait_for_index_active(
            cursor=cursor,
            database="DB",
            schema="S",
            table="T",
            index_name="IDX_A",
            timeout_s=10.0,
            poll_interval_s=0.5,
        )

        self.assertEqual(cursor.fetchall.call_count, 2)

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration.time.sleep"
    )
    def test_raises_on_build_failure_for_target(self, mock_sleep):
        cursor = _make_cursor_with_status_sequence([[("IDX_A", "BUILD FAILURE")]])

        with self.assertRaises(IndexBuildFailedError) as ctx:
            BaseMigration._wait_for_index_active(
                cursor=cursor,
                database="DB",
                schema="S",
                table="T",
                index_name="IDX_A",
                timeout_s=10.0,
                poll_interval_s=1.0,
            )

        self.assertIn("IDX_A", str(ctx.exception))
        mock_sleep.assert_not_called()

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration.time.monotonic"
    )
    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration.time.sleep"
    )
    def test_raises_on_timeout(self, mock_sleep, mock_monotonic):
        mock_monotonic.side_effect = [0.0, 11.0]
        cursor = _make_cursor_with_status_sequence([[("IDX_A", "BUILD IN PROGRESS")]])

        with self.assertRaises(IndexBuildTimeoutError) as ctx:
            BaseMigration._wait_for_index_active(
                cursor=cursor,
                database="DB",
                schema="S",
                table="T",
                index_name="IDX_A",
                timeout_s=10.0,
                poll_interval_s=1.0,
            )

        self.assertIn("IDX_A", str(ctx.exception))
        self.assertIn("BUILD IN PROGRESS", str(ctx.exception))
        mock_sleep.assert_not_called()


# ---------------------------------------------------------------------------
# _create_index_synchronously (orchestrates pre-wait, DDL, post-wait)
# ---------------------------------------------------------------------------
class TestCreateIndexSynchronously(unittest.TestCase):
    """End-to-end behavior of the high-level synchronous-create helper."""

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration.metadata_database",
        return_value="MY_DB",
    )
    @patch(
        "data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration.migration_metadata_schema",
        return_value="MY_SCHEMA",
    )
    @patch.object(BaseMigration, "_execute_migration_sql_assets")
    @patch.object(BaseMigration, "_wait_for_index_active")
    @patch.object(BaseMigration, "_wait_for_no_in_progress_index_build")
    def test_orchestrates_prewait_execute_postwait(
        self,
        mock_pre,
        mock_post,
        mock_execute,
        _mock_schema,
        _mock_db,
    ):
        order: list[str] = []
        mock_pre.side_effect = lambda **_: order.append("pre")
        mock_execute.side_effect = lambda *_, **__: order.append("execute")
        mock_post.side_effect = lambda **_: order.append("post")

        migration = _StubMigration()
        cursor = MagicMock()

        migration._create_index_synchronously(
            cursor=cursor,
            asset_path="scripts/task-queue/idx_task_queue_pending_pull.sql.j2",
            table="TASK_QUEUE",
            index_name="IDX_TASK_QUEUE_PENDING_PULL",
            timeout_s=42.0,
            poll_interval_s=3.0,
        )

        self.assertEqual(order, ["pre", "execute", "post"])

        pre_kwargs = mock_pre.call_args.kwargs
        self.assertEqual(pre_kwargs["database"], "MY_DB")
        self.assertEqual(pre_kwargs["schema"], "MY_SCHEMA")
        self.assertEqual(pre_kwargs["table"], "TASK_QUEUE")
        self.assertEqual(pre_kwargs["timeout_s"], 42.0)
        self.assertEqual(pre_kwargs["poll_interval_s"], 3.0)

        mock_execute.assert_called_once_with(
            cursor,
            ["scripts/task-queue/idx_task_queue_pending_pull.sql.j2"],
        )

        post_kwargs = mock_post.call_args.kwargs
        self.assertEqual(post_kwargs["index_name"], "IDX_TASK_QUEUE_PENDING_PULL")
        self.assertEqual(post_kwargs["timeout_s"], 42.0)


if __name__ == "__main__":
    unittest.main()
