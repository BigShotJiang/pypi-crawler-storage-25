"""Tests for the on-demand Snowpipe event table setup utility."""

import unittest
from unittest.mock import AsyncMock, MagicMock

from data_migration_orchestrator.data_migration_cloud.utils.snowpipe_event_table import (
    setup_snowpipe_for_data_migration,
)


class TestSetupSnowpipeForDataMigration(unittest.IsolatedAsyncioTestCase):
    """Tests for ``setup_snowpipe_for_data_migration``."""

    async def test_success_creates_event_table_and_sets_database(self):
        warehouse = MagicMock()
        warehouse.execute_sync_query = AsyncMock(return_value=[])

        await setup_snowpipe_for_data_migration(warehouse)

        calls = warehouse.execute_sync_query.await_args_list
        self.assertEqual(len(calls), 2)
        self.assertIn("CREATE EVENT TABLE IF NOT EXISTS", calls[0].args[0])
        self.assertIn("ALTER DATABASE", calls[1].args[0])
        self.assertIn("SET EVENT_TABLE", calls[1].args[0])

    async def test_alter_database_failure_raises_with_clear_message(self):
        warehouse = MagicMock()
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                [],
                RuntimeError("SQL compilation error: unsupported feature"),
            ]
        )

        with self.assertRaises(RuntimeError) as ctx:
            await setup_snowpipe_for_data_migration(warehouse)

        msg = str(ctx.exception)
        self.assertIn("database-scoped event tables are not supported", msg)
        self.assertIn("snowpipe", msg.lower())
        self.assertIsNotNone(ctx.exception.__cause__)

    async def test_create_event_table_failure_propagates_directly(self):
        warehouse = MagicMock()
        warehouse.execute_sync_query = AsyncMock(
            side_effect=RuntimeError("access denied")
        )

        with self.assertRaises(RuntimeError) as ctx:
            await setup_snowpipe_for_data_migration(warehouse)

        self.assertIn("access denied", str(ctx.exception))
