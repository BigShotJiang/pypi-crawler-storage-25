"""Tests for external stage storage integration placeholder detection."""

import pytest

from data_migration_orchestrator.data_migration_cloud.config.extraction_stage_validation import (
    explain_external_stage_access_failure,
    explain_if_aws_role_assumption_failure,
    explain_if_integration_access_failure,
    reject_placeholder_storage_integration,
    storage_integration_looks_like_placeholder,
)


@pytest.mark.parametrize(
    "value,expect_placeholder",
    [
        ("REPLACE_WITH_YOUR_S3_STORAGE_INTEGRATION", True),
        ("MY_ACCOUNT_S3_INT", False),
        ("", True),
        ("TODO_INTEGRATION", True),
    ],
)
def test_storage_integration_placeholder_detection(
    value: str, expect_placeholder: bool
) -> None:
    assert storage_integration_looks_like_placeholder(value) is expect_placeholder


def test_explain_aws_role_assumption_matches_terminal_style_error() -> None:
    wrapped = RuntimeError(
        "Failed ... Error: 003167 (42601): Error assuming AWS_ROLE:\n"
        "User: arn:aws:iam::970547364499:user/x is not authorized to perform: "
        "sts:AssumeRole on resource: arn:aws:iam::101645636301:role/MyRole"
    )
    hint = explain_if_aws_role_assumption_failure(wrapped)
    assert hint is not None
    assert "trust policy" in hint.lower()
    assert "MyRole" in hint or "101645636301:role/MyRole" in hint
    assert "cross-account" in hint.lower()
    assert "970547364499" in hint
    assert "101645636301" in hint


def test_explain_aws_role_assumption_same_account_omits_cross_account_sentence() -> (
    None
):
    wrapped = RuntimeError(
        "Error: 003167 (42601): Error assuming AWS_ROLE:\n"
        "User: arn:aws:iam::111111111111:user/sfx is not authorized to perform: "
        "sts:AssumeRole on resource: arn:aws:iam::111111111111:role/SameAcct"
    )
    hint = explain_if_aws_role_assumption_failure(wrapped)
    assert hint is not None
    assert "cross-account" not in hint.lower()


def test_explain_external_stage_prefers_integration_then_falls_through() -> None:
    int_err = RuntimeError(
        "002003 ... Integration 'X' does not exist or not authorized"
    )
    assert explain_external_stage_access_failure(int_err) is not None

    assert explain_external_stage_access_failure(RuntimeError("other")) is None


def test_explain_external_stage_accepts_aws_role_assumption_error() -> None:
    aws_err = RuntimeError(
        "Error: 003167 (42601): Error assuming AWS_ROLE:\n"
        "User: arn:aws:iam::1:user/x is not authorized to perform: "
        "sts:AssumeRole on resource: arn:aws:iam::2:role/R"
    )
    hint = explain_external_stage_access_failure(aws_err)
    assert hint is not None
    assert "AssumeRole" in hint or "assume" in hint.lower()


def test_explain_integration_access_failure_matches_wrapped_snowflake_error() -> None:
    wrapped = RuntimeError(
        "Failed to execute query. Query: SELECT ... FROM @stg/path/. "
        "Error: 002003 (02000): SQL compilation error:\n"
        "Integration 'WRITE_NOS_S3_INT' does not exist or not authorized."
    )
    hint = explain_if_integration_access_failure(wrapped)
    assert hint is not None
    assert "WRITE_NOS_S3_INT" in hint
    assert "SHOW INTEGRATIONS" in hint


def test_explain_integration_access_failure_returns_none_for_other_errors() -> None:
    assert explain_if_integration_access_failure(RuntimeError("something else")) is None


def test_reject_placeholder_raises() -> None:
    with pytest.raises(ValueError, match="real Snowflake"):
        reject_placeholder_storage_integration(
            "REPLACE_WITH_X",
            context="test",
        )
