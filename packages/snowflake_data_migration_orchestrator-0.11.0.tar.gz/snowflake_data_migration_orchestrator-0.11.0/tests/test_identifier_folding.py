"""Tests for identifier folding by source platform."""

import pytest

from data_migration_orchestrator.data_validation_cloud.utils.identifier_folding import (
    FoldingStrategy,
    apply_identifier_folding,
    folding_strategy_for_source_platform,
)


@pytest.mark.parametrize(
    ("platform", "expected"),
    [
        (None, FoldingStrategy.NONE),
        ("", FoldingStrategy.NONE),
        ("   ", FoldingStrategy.NONE),
        ("sqlserver", FoldingStrategy.NONE),
        ("SQLSERVER", FoldingStrategy.NONE),
        ("redshift", FoldingStrategy.LOWER),
        ("REDSHIFT", FoldingStrategy.LOWER),
        ("postgresql", FoldingStrategy.LOWER),
        ("PostgreSQL", FoldingStrategy.LOWER),
        ("postgres", FoldingStrategy.LOWER),
        ("pg", FoldingStrategy.LOWER),
        ("teradata", FoldingStrategy.UPPER),
        ("TERADATA", FoldingStrategy.UPPER),
        ("oracle", FoldingStrategy.UPPER),
        ("Oracle", FoldingStrategy.UPPER),
    ],
)
def test_folding_strategy_for_source_platform(
    platform: str | None, expected: FoldingStrategy
) -> None:
    assert folding_strategy_for_source_platform(platform) is expected


@pytest.mark.parametrize(
    ("strategy", "name", "want"),
    [
        (FoldingStrategy.NONE, "FooBar", "FooBar"),
        (FoldingStrategy.LOWER, "FooBar", "foobar"),
        (FoldingStrategy.UPPER, "FooBar", "FOOBAR"),
    ],
)
def test_apply_identifier_folding(
    strategy: FoldingStrategy, name: str, want: str
) -> None:
    assert apply_identifier_folding(name, strategy) == want
