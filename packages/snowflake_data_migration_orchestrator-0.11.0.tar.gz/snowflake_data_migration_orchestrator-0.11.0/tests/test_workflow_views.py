"""
Tests for the DATA_MIGRATION_WORKFLOW and DATA_VALIDATION_WORKFLOW view templates.

Verifies that both Jinja templates:
- exist on disk and render without errors
- produce ``CREATE OR REPLACE VIEW`` DDL targeting the correct view names
- include the expected ``WORKFLOW_TYPE`` filter
- project the expected core columns
- (DATA_VALIDATION_WORKFLOW only) include L1/L2/L3 rollup columns and the
  cross-schema joins to the data-validation schema (SNOW-3443999)
"""

from __future__ import annotations

from pathlib import Path

import pytest

from data_migration_orchestrator.utils.templated_sql import render_sql_jinja_template


_ASSETS_DIR = (
    Path(__file__).resolve().parent.parent
    / "src"
    / "data_migration_orchestrator"
    / "assets"
)

_TEMPLATE_CONTEXT = {
    "metadata_database": "TEST_DB",
    "migration_schema": "DATA_MIGRATION",
    "validation_schema": "DATA_VALIDATION",
    "qualified_migration": "TEST_DB.DATA_MIGRATION",
    "qualified_validation": "TEST_DB.DATA_VALIDATION",
}

_DM_VIEW_TEMPLATE = "scripts/workflows/views/data_migration_workflow.sql.j2"
_DV_VIEW_TEMPLATE = "scripts/workflows/views/data_validation_workflow.sql.j2"


def _render(relative: str) -> str:
    path = _ASSETS_DIR / relative
    source = path.read_text(encoding="utf-8")
    return render_sql_jinja_template(source, _TEMPLATE_CONTEXT)


class TestDataMigrationWorkflowView:
    """DATA_MIGRATION_WORKFLOW view template correctness tests."""

    def test_template_file_exists(self):
        assert (
            _ASSETS_DIR / _DM_VIEW_TEMPLATE
        ).is_file(), f"Template not found: {_DM_VIEW_TEMPLATE}"

    def test_renders_without_error(self):
        sql = _render(_DM_VIEW_TEMPLATE)
        assert sql  # non-empty

    def test_creates_correct_view_name(self):
        sql = _render(_DM_VIEW_TEMPLATE)
        assert "CREATE OR REPLACE VIEW" in sql.upper()
        assert "DATA_MIGRATION_WORKFLOW" in sql.upper()

    def test_filters_by_workflow_type(self):
        sql = _render(_DM_VIEW_TEMPLATE)
        # The filter must be present (case-insensitive comparison via LOWER())
        assert "'data-migration'" in sql.lower()

    def test_projects_core_columns(self):
        sql = _render(_DM_VIEW_TEMPLATE)
        for col in (
            "ID",
            "NAME",
            "STATUS",
            "SOURCE_PLATFORM",
            "TARGET_CLOUD_TYPE",
            "TARGET_CLOUD_STAGE_NAME",
            "TARGET_CLOUD_URL",
            "INITIATOR_ID",
            "AFFINITY",
            "CREATION_TIME",
            "END_TIME",
            "INITIALIZATION_START_TIME",
            "LAST_ERROR_MESSAGE",
            "LAST_WARNING_MESSAGE",
        ):
            assert col in sql, f"Missing column {col} in DATA_MIGRATION_WORKFLOW"

    def test_reads_from_workflow_table(self):
        sql = _render(_DM_VIEW_TEMPLATE)
        assert "TEST_DB.DATA_MIGRATION.WORKFLOW" in sql


class TestDataValidationWorkflowView:
    """DATA_VALIDATION_WORKFLOW view template correctness tests."""

    def test_template_file_exists(self):
        assert (
            _ASSETS_DIR / _DV_VIEW_TEMPLATE
        ).is_file(), f"Template not found: {_DV_VIEW_TEMPLATE}"

    def test_renders_without_error(self):
        sql = _render(_DV_VIEW_TEMPLATE)
        assert sql

    def test_creates_correct_view_name(self):
        sql = _render(_DV_VIEW_TEMPLATE)
        assert "CREATE OR REPLACE VIEW" in sql.upper()
        assert "DATA_VALIDATION_WORKFLOW" in sql.upper()

    def test_filters_by_workflow_type(self):
        sql = _render(_DV_VIEW_TEMPLATE)
        assert "'data-validation'" in sql.lower()

    def test_projects_core_columns(self):
        sql = _render(_DV_VIEW_TEMPLATE)
        for col in (
            "ID",
            "NAME",
            "STATUS",
            "SOURCE_PLATFORM",
            "CREATION_TIME",
            "END_TIME",
            "LAST_ERROR_MESSAGE",
            "LAST_WARNING_MESSAGE",
        ):
            assert col in sql, f"Missing column {col} in DATA_VALIDATION_WORKFLOW"

    def test_includes_l1_rollup_columns(self):
        sql = _render(_DV_VIEW_TEMPLATE)
        for col in ("L1_TOTAL_CHECKS", "L1_PASSED", "L1_FAILED"):
            assert col in sql, f"Missing L1 rollup column {col}"

    def test_includes_l2_rollup_columns(self):
        sql = _render(_DV_VIEW_TEMPLATE)
        for col in ("L2_TOTAL_CHECKS", "L2_PASSED", "L2_FAILED"):
            assert col in sql, f"Missing L2 rollup column {col}"

    def test_includes_l3_rollup_columns(self):
        sql = _render(_DV_VIEW_TEMPLATE)
        for col in (
            "L3_TOTAL_TABLES",
            "L3_TABLES_VALID",
            "L3_TABLES_INVALID",
            "L3_TOTAL_ROWS_COMPARED",
        ):
            assert col in sql, f"Missing L3 rollup column {col}"

    def test_includes_table_count_columns(self):
        sql = _render(_DV_VIEW_TEMPLATE)
        for col in (
            "TOTAL_TABLES",
            "TABLES_COMPLETED",
            "TABLES_FAILED",
            "TABLES_PENDING",
        ):
            assert col in sql, f"Missing table-count column {col}"

    def test_joins_validation_schema_tables(self):
        sql = _render(_DV_VIEW_TEMPLATE)
        # The DV rollups must reference the validation schema tables
        for table in (
            "TABLE_METADATA",
            "SCHEMA_VALIDATION_RESULTS",
            "METRICS_VALIDATION_RESULTS",
            "ROW_VALIDATION_SUMMARY",
        ):
            assert table in sql, f"Missing join to {table}"
        # Cross-schema qualified references must use the rendered qualified_validation
        assert "TEST_DB.DATA_VALIDATION" in sql

    def test_uses_left_join_for_rollups(self):
        """Workflows with no results yet must still appear (LEFT JOIN)."""
        sql = _render(_DV_VIEW_TEMPLATE)
        assert "LEFT JOIN" in sql.upper()

    def test_reads_from_workflow_table(self):
        sql = _render(_DV_VIEW_TEMPLATE)
        assert "TEST_DB.DATA_MIGRATION.WORKFLOW" in sql


@pytest.mark.parametrize(
    "template",
    [_DM_VIEW_TEMPLATE, _DV_VIEW_TEMPLATE],
    ids=["data_migration_workflow", "data_validation_workflow"],
)
class TestWorkflowViewsIdempotent:
    """Both view templates must use CREATE OR REPLACE (idempotent)."""

    def test_create_or_replace_view(self, template):
        sql = _render(template)
        assert (
            "CREATE OR REPLACE VIEW" in sql.upper()
        ), f"{template} must use CREATE OR REPLACE VIEW for idempotency"
