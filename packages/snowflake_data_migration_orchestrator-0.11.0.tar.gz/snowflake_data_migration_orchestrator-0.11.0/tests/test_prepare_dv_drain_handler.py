"""Unit tests for the PrepareDvDrain orchestrator handler."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock

import pytest

from data_migration_orchestrator.cloud_core.constants.priorities import (
    DEFAULT_PRIORITY,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.data_validation_cloud.scope import (
    ValidationScopeOperation,
)
from data_migration_orchestrator.data_validation_cloud.tasks.handlers.prepare_dv_drain_handler import (
    PrepareDvDrainHandler,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    PrepareDvDrainPayload,
)


def _run(coro):
    return asyncio.new_event_loop().run_until_complete(coro)


def _make_task(
    pipe_names: list[str],
    pipe_keys: list[str],
    evaluate_task_id: int | None,
    workflow_id: int = 42,
    level: str = "row",
    table_metadata_id: int | None = 100,
) -> Task:
    payload = PrepareDvDrainPayload(
        workflow_id=workflow_id,
        level=level,
        pipe_names=pipe_names,
        pipe_keys=pipe_keys,
        evaluate_task_id=evaluate_task_id,
        table_metadata_id=table_metadata_id,
    )
    return Task(
        id=7777,
        workflow_id=workflow_id,
        task_name=f"Prepare DV drain ({level})",
        executor_type=ExecutorType.ORCHESTRATOR,
        payload=payload,
        scope="DV::Workflow[42]::Pipe[row]::SnowpipePrepareDrain",
    )


class TestPrepareDvDrainHandler:
    """Validate fan-out drain push + completion semantics."""

    def test_pushes_one_drain_per_pipe_with_evaluate_successor(self):
        task_queue = MagicMock()
        task_queue.complete_task = AsyncMock(return_value=None)
        warehouse = MagicMock()
        warehouse.execute_snowpipe_drain_and_push_task = AsyncMock(
            side_effect=[11, 22, 33]
        )

        handler = PrepareDvDrainHandler(
            task_queue=task_queue, warehouse_proxy=warehouse
        )
        task = _make_task(
            pipe_names=[
                "DB.TEMP.DVO_PIPE_42_ROW_DIFFS",
                "DB.TEMP.DVO_PIPE_42_ROW_SUMMARY",
                "DB.TEMP.DVO_PIPE_42_CHUNK_HASHES",
            ],
            pipe_keys=["ROW_DIFFS", "ROW_SUMMARY", "CHUNK_HASHES"],
            evaluate_task_id=555,
        )

        _run(handler.handle(task))

        calls = warehouse.execute_snowpipe_drain_and_push_task.await_args_list
        assert len(calls) == 3
        for call, expected_pipe, expected_key in zip(
            calls,
            task.payload.pipe_names,
            task.payload.pipe_keys,
            strict=True,
        ):
            assert call.kwargs["workflow_id"] == 42
            assert call.kwargs["pipe_name"] == expected_pipe
            assert call.kwargs["task_name"] == (
                f"Drain DV Snowpipe: {task.payload.table_metadata_id}.{expected_key}"
            )
            assert call.kwargs["successor_task_id"] == 555
            assert call.kwargs["is_blocked"] is False
            assert call.kwargs["priority"] == DEFAULT_PRIORITY
            assert ValidationScopeOperation.SNOWPIPE_DRAIN.value in call.kwargs["scope"]

        task_queue.complete_task.assert_awaited_once_with(
            consumer_type=ExecutorType.ORCHESTRATOR,
            task_id=7777,
        )

    def test_none_evaluate_task_id_still_pushes_drains(self):
        """Drill-down flows use evaluate_task_id=None; drains still fan out."""
        task_queue = MagicMock()
        task_queue.complete_task = AsyncMock(return_value=None)
        warehouse = MagicMock()
        warehouse.execute_snowpipe_drain_and_push_task = AsyncMock(
            side_effect=[1, 2, 3]
        )

        handler = PrepareDvDrainHandler(
            task_queue=task_queue, warehouse_proxy=warehouse
        )
        task = _make_task(
            pipe_names=["P1", "P2", "P3"],
            pipe_keys=["ROW_DIFFS", "ROW_SUMMARY", "CHUNK_HASHES"],
            evaluate_task_id=None,
        )

        _run(handler.handle(task))

        calls = warehouse.execute_snowpipe_drain_and_push_task.await_args_list
        assert len(calls) == 3
        for call in calls:
            assert call.kwargs["successor_task_id"] is None
        task_queue.complete_task.assert_awaited_once()

    def test_mismatched_lengths_raise(self):
        task_queue = MagicMock()
        task_queue.complete_task = AsyncMock(return_value=None)
        warehouse = MagicMock()
        warehouse.execute_snowpipe_drain_and_push_task = AsyncMock()

        handler = PrepareDvDrainHandler(
            task_queue=task_queue, warehouse_proxy=warehouse
        )
        task = _make_task(
            pipe_names=["P1", "P2"],
            pipe_keys=["ROW_DIFFS"],
            evaluate_task_id=1,
        )

        with pytest.raises(ValueError):
            _run(handler.handle(task))

        warehouse.execute_snowpipe_drain_and_push_task.assert_not_awaited()
        task_queue.complete_task.assert_not_awaited()

    def test_legacy_payload_without_table_metadata_uses_key_only_in_task_name(
        self,
    ):
        task_queue = MagicMock()
        task_queue.complete_task = AsyncMock(return_value=None)
        warehouse = MagicMock()
        warehouse.execute_snowpipe_drain_and_push_task = AsyncMock(side_effect=[11, 22])

        handler = PrepareDvDrainHandler(
            task_queue=task_queue, warehouse_proxy=warehouse
        )
        task = _make_task(
            pipe_names=["P1", "P2"],
            pipe_keys=["ROW_DIFFS", "ROW_SUMMARY"],
            evaluate_task_id=1,
            table_metadata_id=None,
        )

        _run(handler.handle(task))

        calls = warehouse.execute_snowpipe_drain_and_push_task.await_args_list
        assert calls[0].kwargs["task_name"] == "Drain DV Snowpipe: ROW_DIFFS"
        assert calls[1].kwargs["task_name"] == "Drain DV Snowpipe: ROW_SUMMARY"
