"""Unit tests for the FinalizeHybridL3 orchestrator handler."""

from __future__ import annotations

import sys
import unittest

from types import ModuleType
from unittest.mock import AsyncMock, MagicMock, patch

# Stub SDV imports required by the dataclass module's transitive imports.
_sdv_public = ModuleType("snowflake.snowflake_data_validation.public")
for _attr in (
    "ColumnMetadata",
    "MetricsResultShapeDict",
    "ObjectType",
    "Origin",
    "Platform",
):
    setattr(_sdv_public, _attr, MagicMock())
sys.modules.setdefault("snowflake.snowflake_data_validation.public", _sdv_public)

from data_migration_orchestrator.cloud_core.tasks.executor_type import (  # noqa: E402
    ExecutorType,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task  # noqa: E402
from data_migration_orchestrator.data_validation_cloud.tasks.handlers.finalize_hybrid_l3_handler import (  # noqa: E402
    FinalizeHybridL3Handler,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (  # noqa: E402
    FinalizeHybridL3Payload,
)


def _make_task(payload: FinalizeHybridL3Payload, task_id: int = 100) -> Task:
    return Task(
        workflow_id=payload.workflow_id,
        task_name="finalize",
        executor_type=ExecutorType.ORCHESTRATOR,
        payload=payload,
        priority=3.0,
        id=task_id,
        scope="DV::Table[t]::Evaluate[row]::Finalize",
    )


class TestFinalizeHybridL3Handler(unittest.IsolatedAsyncioTestCase):
    """Roll up cell diff counts to L3_STATUS and table validation status."""

    async def test_marks_completed_when_no_diffs(self):
        tq = MagicMock()
        tq.complete_task = AsyncMock()
        wh = MagicMock()
        wh.execute_sync_query = AsyncMock(
            side_effect=[
                [{"DIFF_COUNT": 0}],
                None,
            ]
        )
        handler = FinalizeHybridL3Handler(tq, wh)
        payload = FinalizeHybridL3Payload(
            workflow_id=7,
            table_metadata_id=42,
            source_identifier="db.sch.t",
        )

        with patch(
            "data_migration_orchestrator.data_validation_cloud.tasks.handlers.finalize_hybrid_l3_handler.bulk_set_partition_level_status",
            new=AsyncMock(),
        ) as mock_bulk:
            await handler.handle(_make_task(payload))

        mock_bulk.assert_awaited_once()
        self.assertEqual(mock_bulk.await_args.kwargs["column"], "L3_STATUS")
        self.assertEqual(mock_bulk.await_args.kwargs["status"], "VALID")

        update_sql = wh.execute_sync_query.await_args_list[1][0][0]
        self.assertIn("UPDATE_TABLE_VALIDATION_STATUS", update_sql)
        self.assertIn("COMPLETED", update_sql)
        tq.complete_task.assert_awaited_once_with(ExecutorType.ORCHESTRATOR, 100)

    async def test_marks_failed_when_cell_diffs_present(self):
        tq = MagicMock()
        tq.complete_task = AsyncMock()
        wh = MagicMock()
        wh.execute_sync_query = AsyncMock(
            side_effect=[
                [{"DIFF_COUNT": 3}],
                None,
            ]
        )
        handler = FinalizeHybridL3Handler(tq, wh)
        payload = FinalizeHybridL3Payload(
            workflow_id=7,
            table_metadata_id=42,
            source_identifier="db.sch.t",
        )

        with patch(
            "data_migration_orchestrator.data_validation_cloud.tasks.handlers.finalize_hybrid_l3_handler.bulk_set_partition_level_status",
            new=AsyncMock(),
        ) as mock_bulk:
            await handler.handle(_make_task(payload))

        self.assertEqual(mock_bulk.await_args.kwargs["status"], "INVALID")
        update_sql = wh.execute_sync_query.await_args_list[1][0][0]
        self.assertIn("FAILED", update_sql)


if __name__ == "__main__":
    unittest.main()
