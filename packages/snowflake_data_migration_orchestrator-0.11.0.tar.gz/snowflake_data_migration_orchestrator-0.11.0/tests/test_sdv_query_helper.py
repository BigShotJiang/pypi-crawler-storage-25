"""Tests for sdv_query_helper identifier normalization."""

import pytest

from snowflake.snowflake_data_validation.public import ObjectType, Platform

from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
    _needs_temporary_table_flag,
    _normalize_identifier,
    resolve_object_type,
)


class TestNormalizeIdentifier:
    """Tests for _normalize_identifier across all supported platforms."""

    @pytest.mark.parametrize(
        "platform",
        [Platform.SNOWFLAKE, Platform.TERADATA, Platform.ORACLE],
    )
    def test_uppercasing_platforms(self, platform: Platform):
        assert _normalize_identifier("My_Table", platform) == "MY_TABLE"

    def test_redshift_lowercases(self):
        assert _normalize_identifier("My_Table", Platform.REDSHIFT) == "my_table"

    def test_sqlserver_preserves_case(self):
        assert _normalize_identifier("My_Table", Platform.SQLSERVER) == "My_Table"

    def test_already_uppercase_is_noop(self):
        assert _normalize_identifier("BASIC", Platform.SNOWFLAKE) == "BASIC"

    def test_already_lowercase_is_noop(self):
        assert _normalize_identifier("basic", Platform.REDSHIFT) == "basic"

    def test_empty_string(self):
        assert _normalize_identifier("", Platform.SNOWFLAKE) == ""


class TestResolveObjectType:
    """Tests for resolve_object_type string-to-enum mapping."""

    def test_table_uppercase(self):
        assert resolve_object_type("TABLE") == ObjectType.TABLE

    def test_view_uppercase(self):
        assert resolve_object_type("VIEW") == ObjectType.VIEW

    @pytest.mark.parametrize(
        "object_type_str,expected",
        [
            ("table", ObjectType.TABLE),
            ("Table", ObjectType.TABLE),
            ("TaBlE", ObjectType.TABLE),
            ("view", ObjectType.VIEW),
            ("View", ObjectType.VIEW),
            ("ViEw", ObjectType.VIEW),
        ],
    )
    def test_case_insensitive(self, object_type_str: str, expected: ObjectType):
        assert resolve_object_type(object_type_str) == expected

    def test_unknown_raises(self):
        with pytest.raises(ValueError, match="Unknown object_type: unknown"):
            resolve_object_type("unknown")


class TestNeedsTemporaryTableFlag:
    """Tests for _needs_temporary_table_flag."""

    def test_view_teradata_returns_true(self):
        assert _needs_temporary_table_flag(ObjectType.VIEW, Platform.TERADATA) is True

    @pytest.mark.parametrize(
        "platform",
        [Platform.REDSHIFT, Platform.SNOWFLAKE, Platform.SQLSERVER, Platform.ORACLE],
    )
    def test_view_other_platforms_returns_false(self, platform: Platform):
        assert _needs_temporary_table_flag(ObjectType.VIEW, platform) is False

    @pytest.mark.parametrize(
        "platform",
        [
            Platform.REDSHIFT,
            Platform.SNOWFLAKE,
            Platform.SQLSERVER,
            Platform.TERADATA,
            Platform.ORACLE,
        ],
    )
    def test_table_any_platform_returns_false(self, platform: Platform):
        assert _needs_temporary_table_flag(ObjectType.TABLE, platform) is False
