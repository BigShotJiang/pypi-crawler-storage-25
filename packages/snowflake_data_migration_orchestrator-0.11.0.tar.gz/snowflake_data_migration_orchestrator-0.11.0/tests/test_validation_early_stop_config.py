"""Tests for L3 early-stopping workflow configuration."""

import pytest

from data_migration_orchestrator.data_validation_cloud.config.validation_configuration_parser import (
    ValidationConfigurationError,
    ValidationConfigurationParser,
)
from data_migration_orchestrator.data_validation_cloud.config.validation_table_configuration import (
    ValidationTableConfiguration,
)
from data_migration_orchestrator.data_validation_cloud.config.workflow_configuration_schema import (
    ValidationLevelSchema,
)


class TestValidationLevelSchemaEarlyStop:
    """Tests for early-stop fields on ``ValidationLevelSchema``."""

    def test_early_stopping_valid(self):
        vc = ValidationLevelSchema(
            early_stopping=True,
            early_stop_mismatch_row_threshold=3,
            early_stop_check_interval_minutes=2,
        )
        assert vc.early_stopping is True
        assert vc.early_stop_mismatch_row_threshold == 3


class TestValidationConfigurationParserEarlyStop:
    """Tests for early-stop parsing in ``ValidationConfigurationParser``."""

    def test_raises_when_global_early_stopping_without_numbers(self):
        raw = {
            "sourcePlatform": "redshift",
            "validationConfiguration": {"early_stopping": True},
            "tables": [{"fullyQualifiedName": "db.schema.t"}],
        }
        with pytest.raises(ValidationConfigurationError):
            ValidationConfigurationParser(raw).parse_tables()

    def test_raises_when_early_stopping_enabled_without_numbers(self):
        raw = {
            "sourcePlatform": "redshift",
            "tables": [
                {
                    "fullyQualifiedName": "db.schema.t",
                    "validationConfiguration": {"early_stopping": True},
                }
            ],
        }
        with pytest.raises(ValidationConfigurationError):
            ValidationConfigurationParser(raw).parse_tables()

    def test_inherits_global_early_stop_numbers(self):
        raw = {
            "sourcePlatform": "redshift",
            "validationConfiguration": {
                "early_stopping": True,
                "early_stop_mismatch_row_threshold": 10,
                "early_stop_check_interval_minutes": 4,
            },
            "tables": [
                {
                    "fullyQualifiedName": "db.schema.t",
                    "validationConfiguration": {"early_stopping": True},
                }
            ],
        }
        tables = ValidationConfigurationParser(raw).parse_tables()
        assert len(tables) == 1
        assert tables[0].early_stopping is True
        assert tables[0].early_stop_mismatch_row_threshold == 10
        assert tables[0].early_stop_check_interval_minutes == 4

    def test_rejects_hybrid_without_early_stopping(self):
        raw = {
            "sourcePlatform": "redshift",
            "validationConfiguration": {
                "row_validation": True,
                "row_validation_mode": "hybrid",
            },
            "tables": [{"fullyQualifiedName": "db.schema.t"}],
        }
        with pytest.raises(ValidationConfigurationError) as exc_info:
            ValidationConfigurationParser(raw).parse_tables()
        assert "row_validation_mode=hybrid" in str(exc_info.value)
        assert "early_stopping=true" in str(exc_info.value)

    def test_rejects_per_table_hybrid_without_early_stopping(self):
        raw = {
            "sourcePlatform": "redshift",
            "validationConfiguration": {"row_validation": True},
            "tables": [
                {
                    "fullyQualifiedName": "db.schema.t",
                    "validationConfiguration": {"row_validation_mode": "hybrid"},
                }
            ],
        }
        with pytest.raises(ValidationConfigurationError):
            ValidationConfigurationParser(raw).parse_tables()

    def test_accepts_hybrid_with_early_stopping(self):
        raw = {
            "sourcePlatform": "redshift",
            "validationConfiguration": {
                "row_validation": True,
                "row_validation_mode": "hybrid",
                "early_stopping": True,
                "early_stop_mismatch_row_threshold": 5,
                "early_stop_check_interval_minutes": 1,
            },
            "tables": [{"fullyQualifiedName": "db.schema.t"}],
        }
        tables = ValidationConfigurationParser(raw).parse_tables()
        assert len(tables) == 1
        assert tables[0].early_stopping is True


class TestValidationTableConfigurationEarlyStopToSdv:
    """Tests for early-stop fields in ``ValidationTableConfiguration.to_sdv_dict``."""

    def test_to_sdv_dict_includes_early_stop_when_enabled(self):
        vtc = ValidationTableConfiguration(
            fully_qualified_name="db.schema.t",
            early_stopping=True,
            early_stop_mismatch_row_threshold=7,
            early_stop_check_interval_minutes=3,
        )
        d = vtc.to_sdv_dict()
        assert d.get("early_stopping") is True
        assert d.get("early_stop_mismatch_row_threshold") == 7
        assert d.get("early_stop_check_interval_minutes") == 3
