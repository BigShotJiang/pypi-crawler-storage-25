"""Tests for partition boundary generator."""

from datetime import datetime

import pytest

# Import platforms to ensure registration happens
import data_migration_orchestrator.data_migration_cloud.platforms  # noqa: F401

from data_migration_orchestrator.data_migration_cloud.platforms.platform_registry import (
    PlatformRegistry,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_boundary_generator import (
    PartitionBoundaryGenerator,
)
from shared.enums.source_type import SourceType


class TestFormatSqlValue:
    """Tests for SQL Server format_sql_value via platform query builder."""

    def setup_method(self):
        """Set up SQL Server query builder."""
        platform = PlatformRegistry.create_by_name_or_alias("sqlserver")
        self.format_sql_value = platform.query_builder.format_sql_value

    def test_format_integer(self):
        """Test formatting an integer value."""
        assert self.format_sql_value(100) == "100"

    def test_format_float(self):
        """Test formatting a float value."""
        assert self.format_sql_value(123.456) == "123.456"

    def test_format_string(self):
        """Test formatting a regular string value."""
        assert self.format_sql_value("hello") == "N'hello'"

    def test_format_string_with_quotes(self):
        """Test formatting a string containing single quotes."""
        assert self.format_sql_value("it's a test") == "N'it''s a test'"

    def test_format_none(self):
        """Test formatting a None value."""
        assert self.format_sql_value(None) == "NULL"

    def test_format_datetime_string_delegates_to_utils(self):
        """Test that datetime strings are formatted using datetime utils."""
        result = self.format_sql_value("2023-07-01 01:01:52.197000")
        assert "CONVERT(datetime2," in result

    def test_format_python_datetime_delegates_to_utils(self):
        """Test that Python datetime objects are formatted using datetime utils."""
        dt = datetime(2023, 7, 1, 1, 1, 52, 197000)
        result = self.format_sql_value(dt)
        assert "CONVERT(datetime2," in result


class TestGenerateBoundariesWithDatetime:
    """Tests for generate_boundaries with datetime partition columns."""

    def setup_method(self):
        """Set up test instance."""
        self.generator = PartitionBoundaryGenerator()

    def test_generate_boundaries_with_datetime_values(self):
        """Test generating boundaries with datetime boundary values."""
        boundary_values = [
            {
                "partition_id": 1,
                "min_value_in_partition": "2023-01-01 00:00:00.000000",
                "max_value_in_partition": "2023-06-30 23:59:59.999000",
                "n_rows": 1000,
            },
            {
                "partition_id": 2,
                "min_value_in_partition": "2023-07-01 00:00:00.000000",
                "max_value_in_partition": "2023-12-31 23:59:59.999000",
                "n_rows": 1000,
            },
        ]

        partitions = self.generator.generate_boundaries(
            partition_columns=["LogTimestampUTC"],
            boundary_values=boundary_values,
            num_partitions=2,
            source_type=SourceType.SQLSERVER.value,
        )

        # 2 interior + 2 edge = 4
        assert len(partitions) == 4

        # Interior partitions are at indices 1 and 2
        first_where = partitions[1].where_clause
        assert "[LogTimestampUTC] >=" in first_where
        assert "CONVERT(datetime2," in first_where
        assert "2023-01-01T00:00:00.000" in first_where
        assert "[LogTimestampUTC] <" in first_where
        assert "2023-06-30T23:59:59.999" in first_where

        last_where = partitions[2].where_clause
        assert "[LogTimestampUTC] >=" in last_where
        assert "[LogTimestampUTC] <=" in last_where
        assert "2023-12-31T23:59:59.999" in last_where

    def test_generate_boundaries_with_datetimeoffset_values(self):
        """Test generating boundaries with DateTimeOffset boundary values."""
        boundary_values = [
            {
                "partition_id": 1,
                "min_value_in_partition": "2023-01-01T00:00:00.000+00:00",
                "max_value_in_partition": "2023-06-30T23:59:59.999+00:00",
                "n_rows": 1000,
            },
            {
                "partition_id": 2,
                "min_value_in_partition": "2023-07-01T00:00:00.000+00:00",
                "max_value_in_partition": "2023-12-31T23:59:59.999+00:00",
                "n_rows": 1000,
            },
        ]

        partitions = self.generator.generate_boundaries(
            partition_columns=["EventTimestamp"],
            boundary_values=boundary_values,
            num_partitions=2,
            source_type=SourceType.SQLSERVER.value,
        )

        # 2 interior + 2 edge = 4
        assert len(partitions) == 4

        # Interior partition at index 1
        first_interior_where = partitions[1].where_clause
        assert "CONVERT(datetimeoffset," in first_interior_where
        assert "+00:00" in first_interior_where


class TestWhereClauseGeneration:
    """Tests for WHERE clause generation."""

    def setup_method(self):
        """Set up test instance."""
        self.generator = PartitionBoundaryGenerator()

    def test_where_clause_uses_convert_for_datetime(self):
        """Test that WHERE clauses use CONVERT for datetime columns."""
        boundary_values = [
            {
                "partition_id": 1,
                "min_value_in_partition": "2023-07-01 01:01:52.197000",
                "max_value_in_partition": "2023-12-30 13:01:05.767000",
                "n_rows": 5000,
            },
        ]

        partitions = self.generator.generate_boundaries(
            partition_columns=["LogTimestampUTC"],
            boundary_values=boundary_values,
            num_partitions=1,
            source_type=SourceType.SQLSERVER.value,
        )

        # 1 interior + 2 edge = 3; interior partition is at index 1
        assert len(partitions) == 3
        where_clause = partitions[1].where_clause

        assert "CONVERT(datetime2," in where_clause
        assert "'2023-07-01T01:01:52.197'" in where_clause
        assert "'2023-12-30T13:01:05.767'" in where_clause
        assert ", 126)" in where_clause


class TestEdgePartitions:
    """Tests for edge partition generation in generate_boundaries."""

    def setup_method(self):
        """Set up test instance."""
        self.generator = PartitionBoundaryGenerator()

    def test_edge_partitions_are_created(self):
        """generate_boundaries returns N+2 partitions with lower and upper edges."""
        boundary_values = [
            {
                "partition_id": 1,
                "min_value_in_partition": 1,
                "max_value_in_partition": 500,
                "n_rows": 500,
            },
            {
                "partition_id": 2,
                "min_value_in_partition": 501,
                "max_value_in_partition": 1000,
                "n_rows": 500,
            },
        ]

        partitions = self.generator.generate_boundaries(
            partition_columns=["id"],
            boundary_values=boundary_values,
            num_partitions=2,
            source_type="redshift",
        )

        assert len(partitions) == 4

        lower = partitions[0]
        upper = partitions[3]

        assert lower.partition_index == 0
        assert lower.min_value is None
        assert lower.max_value == 1
        assert lower.row_count == 0

        assert upper.partition_index == 3
        assert upper.min_value == 1000
        assert upper.max_value is None
        assert upper.row_count == 0

    def test_lower_edge_uses_exclusive_less_than(self):
        """Lower edge partition uses '<' (exclusive upper bound)."""
        boundary_values = [
            {
                "partition_id": 1,
                "min_value_in_partition": 10,
                "max_value_in_partition": 20,
                "n_rows": 100,
            },
        ]

        partitions = self.generator.generate_boundaries(
            partition_columns=["val"],
            boundary_values=boundary_values,
            num_partitions=1,
            source_type="redshift",
        )

        lower = partitions[0]
        assert '"val" < 10' in lower.where_clause
        assert ">=" not in lower.where_clause

    def test_upper_edge_uses_exclusive_greater_than(self):
        """Upper edge partition uses '>' (exclusive lower bound)."""
        boundary_values = [
            {
                "partition_id": 1,
                "min_value_in_partition": 10,
                "max_value_in_partition": 20,
                "n_rows": 100,
            },
        ]

        partitions = self.generator.generate_boundaries(
            partition_columns=["val"],
            boundary_values=boundary_values,
            num_partitions=1,
            source_type="redshift",
        )

        upper = partitions[2]
        assert '"val" > 20' in upper.where_clause
        assert "<=" not in upper.where_clause

    def test_interior_partitions_unchanged(self):
        """Interior partitions retain the existing >= / < / <= logic."""
        boundary_values = [
            {
                "partition_id": 1,
                "min_value_in_partition": 1,
                "max_value_in_partition": 500,
                "n_rows": 500,
            },
            {
                "partition_id": 2,
                "min_value_in_partition": 501,
                "max_value_in_partition": 1000,
                "n_rows": 500,
            },
        ]

        partitions = self.generator.generate_boundaries(
            partition_columns=["id"],
            boundary_values=boundary_values,
            num_partitions=2,
            source_type="redshift",
        )

        first_interior = partitions[1]
        assert ">= 1" in first_interior.where_clause
        assert "< 500" in first_interior.where_clause

        last_interior = partitions[2]
        assert ">= 501" in last_interior.where_clause
        assert "<= 1000" in last_interior.where_clause


class TestGenerateSingleBoundaryEdge:
    """Tests for generate_single_boundary with NULL bounds (edge partitions)."""

    def setup_method(self):
        """Set up test instance."""
        self.generator = PartitionBoundaryGenerator()

    def test_single_boundary_full_table(self):
        """Both None -> empty WHERE clause (full table)."""
        boundary = self.generator.generate_single_boundary(
            partition_columns=["id"],
            partition_id=0,
            min_value=None,
            max_value=None,
            source_type="redshift",
        )

        assert boundary.where_clause == ""

    def test_single_boundary_only_max(self):
        """Only max (lower edge) -> exclusive: col < max."""
        boundary = self.generator.generate_single_boundary(
            partition_columns=["id"],
            partition_id=0,
            min_value=None,
            max_value=100,
            source_type="redshift",
        )

        assert '"id" < 100' in boundary.where_clause

    def test_single_boundary_only_min(self):
        """Only min (upper edge) -> exclusive: col > min."""
        boundary = self.generator.generate_single_boundary(
            partition_columns=["id"],
            partition_id=99,
            min_value=1000,
            max_value=None,
            source_type="redshift",
        )

        assert '"id" > 1000' in boundary.where_clause

    def test_single_boundary_both_bounds_half_open(self):
        """Both bounds (interior) -> col >= min AND col < max."""
        boundary = self.generator.generate_single_boundary(
            partition_columns=["id"],
            partition_id=1,
            min_value=10,
            max_value=50,
            source_type="redshift",
            is_last_interior=False,
        )

        assert '"id" >= 10' in boundary.where_clause
        assert '"id" < 50' in boundary.where_clause

    def test_single_boundary_both_bounds_last_interior(self):
        """Last interior bucket uses closed top: col >= min AND col <= max."""
        boundary = self.generator.generate_single_boundary(
            partition_columns=["id"],
            partition_id=2,
            min_value=10,
            max_value=50,
            source_type="redshift",
            is_last_interior=True,
        )

        assert '"id" >= 10' in boundary.where_clause
        assert '"id" <= 50' in boundary.where_clause


class TestBuildPartitionCondition:
    """Tests for BaseQueryBuilder.build_partition_condition through platform instances."""

    @pytest.fixture()
    def redshift_qb(self):
        platform = PlatformRegistry.create_by_name_or_alias("redshift")
        return platform.query_builder

    @pytest.fixture()
    def sqlserver_qb(self):
        platform = PlatformRegistry.create_by_name_or_alias("sqlserver")
        return platform.query_builder

    def test_both_bounds_half_open_by_default(self, redshift_qb):
        result = redshift_qb.build_partition_condition("col", 1, 100)
        assert result == '"col" >= 1 AND "col" < 100'

    def test_both_bounds_inclusive_when_requested(self, redshift_qb):
        result = redshift_qb.build_partition_condition(
            "col", 1, 100, upper_inclusive=True
        )
        assert result == '"col" >= 1 AND "col" <= 100'

    def test_only_min_exclusive(self, redshift_qb):
        result = redshift_qb.build_partition_condition("col", 1000, None)
        assert result == '("col" > 1000)'

    def test_only_max_exclusive(self, redshift_qb):
        result = redshift_qb.build_partition_condition("col", None, 500)
        assert result == '("col" < 500)'

    def test_no_bounds(self, redshift_qb):
        result = redshift_qb.build_partition_condition("col", None, None)
        assert result == "1=1"

    def test_sqlserver_quoting(self, sqlserver_qb):
        result = sqlserver_qb.build_partition_condition(
            "my col", 10, 20, upper_inclusive=True
        )
        assert "[my col] >= 10" in result
        assert "[my col] <= 20" in result

    def test_sqlserver_datetime_formatting(self, sqlserver_qb):
        result = sqlserver_qb.build_partition_condition(
            "ts", "2023-01-01 00:00:00.000000", None
        )
        assert "CONVERT(datetime2," in result
        assert ">" in result
        assert ">=" not in result

    def test_multi_column_lower_uses_strict_prefix(self, redshift_qb):
        from data_migration_orchestrator.data_migration_cloud.partition.partition_range import (
            encode_partition_bound,
        )

        columns = ["a", "b", "c"]
        min_val = encode_partition_bound(columns, [10, 20, 30])
        max_val = encode_partition_bound(columns, [10, 40, 50])
        result = redshift_qb.build_partition_condition(
            columns, min_val, max_val, upper_inclusive=False
        )
        assert '"a" > 10' in result
        assert '("a" = 10 AND "b" > 20' in result
        assert '"c" >= 30' in result
        assert '"a" >= 10' not in result
