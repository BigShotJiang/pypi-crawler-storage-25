"""Tests for workflow_start telemetry enrichment in the orchestrator."""

from __future__ import annotations

from typing import Any
from unittest.mock import patch

from data_migration_orchestrator.cloud_core.workflows.workflow import Workflow
from data_migration_orchestrator.cloud_core.workflows.workflow_status import (
    WorkflowStatus,
)
from shared.enums.source_type import SourceType


def _make_workflow(
    workflow_type: str = "data-migration",
    config: dict[str, Any] | None = None,
) -> Workflow:
    return Workflow(
        id=42,
        name="test",
        source_platform=SourceType.SQLSERVER,
        target_cloud_type="snowflake_stage",
        target_cloud_stage_name="STG",
        target_cloud_url=None,
        schema_version="1.4",
        workflow_type=workflow_type,
        initiator_id="system",
        status=WorkflowStatus.PENDING,
        configuration=config if config is not None else {"tables": []},
    )


class TestEmitWorkflowStart:
    """Behavioural tests for the orchestrator's _emit_workflow_start helper."""

    def test_passes_summary_as_extra_kwarg(self) -> None:
        from data_migration_orchestrator.cloud_orchestrator.orchestrator import (
            _emit_workflow_start,
        )

        wf = _make_workflow(workflow_type="data-migration")
        with patch(
            "data_migration_orchestrator.cloud_orchestrator.orchestrator.log_telemetry_event"
        ) as mock_log:
            _emit_workflow_start(wf)

        mock_log.assert_called_once()
        kwargs = mock_log.call_args.kwargs
        assert kwargs["action"] == "workflow_start"
        assert kwargs["status"] == "success"
        assert kwargs["task_id"] == "42"
        # source_platform is now coerced to its enum value, not the enum itself
        assert kwargs["source_type"] == "sqlserver"

        extra = kwargs["extra"]
        assert extra["workflow_type"] == "data-migration"
        assert extra["target_cloud_type"] == "snowflake_stage"
        assert extra["source_platform"] == "sqlserver"
        assert "config_size_bytes" in extra

    def test_dv_workflow_summary(self) -> None:
        from data_migration_orchestrator.cloud_orchestrator.orchestrator import (
            _emit_workflow_start,
        )

        wf = _make_workflow(
            workflow_type="data-validation",
            config={
                "validation_configuration": {
                    "schema_validation": True,
                    "metrics_validation": False,
                    "row_validation": True,
                    "row_validation_mode": "hybrid",
                },
                "tables": [{"fully_qualified_name": "db.s.t"}],
            },
        )
        with patch(
            "data_migration_orchestrator.cloud_orchestrator.orchestrator.log_telemetry_event"
        ) as mock_log:
            _emit_workflow_start(wf)

        extra = mock_log.call_args.kwargs["extra"]
        assert extra["enabled_levels"] == ["schema", "row"]
        assert extra["row_validation_mode"] == "hybrid"
        assert extra["workflow_type"] == "data-validation"

    def test_handles_workflow_with_none_configuration(self) -> None:
        from data_migration_orchestrator.cloud_orchestrator.orchestrator import (
            _emit_workflow_start,
        )

        wf = _make_workflow(workflow_type="data-migration", config=None)
        wf.configuration = None  # Override the dataclass default
        with patch(
            "data_migration_orchestrator.cloud_orchestrator.orchestrator.log_telemetry_event"
        ) as mock_log:
            _emit_workflow_start(wf)

        # Should not raise; should still produce the global fields.
        mock_log.assert_called_once()
        extra = mock_log.call_args.kwargs["extra"]
        assert extra["workflow_type"] == "data-migration"
        assert extra["config_size_bytes"] == 0

    def test_telemetry_failure_does_not_raise(self) -> None:
        from data_migration_orchestrator.cloud_orchestrator.orchestrator import (
            _emit_workflow_start,
        )

        wf = _make_workflow()
        with patch(
            "data_migration_orchestrator.cloud_orchestrator.orchestrator.log_telemetry_event",
            side_effect=RuntimeError("telemetry broken"),
        ):
            # Must not raise — telemetry failures are isolated.
            _emit_workflow_start(wf)
