"""
Tests for DeduplicatePartitionDataHandler.

This module tests the handler for deduplicating partition data after COPY INTO
for watermark-based incremental sync with track_modifications enabled.
"""

import unittest
from unittest.mock import AsyncMock, MagicMock

from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.tasks.task_status import TaskStatus
from data_migration_orchestrator.data_migration_cloud.config.sync_strategy import (
    SyncStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    SynchronizationConfig,
    TableConfiguration,
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.platforms.snowflake import (
    build_snowflake_partition_condition,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.deduplicate_partition_data_handler import (
    DeduplicatePartitionDataHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    DeduplicatePartitionDataPayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)


class TestDeduplicatePartitionDataHandlerInit(unittest.TestCase):
    """Test cases for handler initialization."""

    def test_handler_initialization(self):
        """Test handler initializes with correct task type."""
        mock_task_queue = MagicMock()
        mock_warehouse_proxy = MagicMock()

        handler = DeduplicatePartitionDataHandler(
            task_queue=mock_task_queue,
            warehouse_proxy=mock_warehouse_proxy,
        )

        self.assertEqual(handler.task_type, TaskPayloadKind.DEDUPLICATE_PARTITION_DATA)

    def test_handler_stores_dependencies(self):
        """Test handler stores task_queue and warehouse_proxy."""
        mock_task_queue = MagicMock()
        mock_warehouse_proxy = MagicMock()

        handler = DeduplicatePartitionDataHandler(
            task_queue=mock_task_queue,
            warehouse_proxy=mock_warehouse_proxy,
        )

        self.assertEqual(handler.task_queue, mock_task_queue)
        self.assertEqual(handler.warehouse_proxy, mock_warehouse_proxy)


class TestBuildDeduplicationStatement(unittest.TestCase):
    """Test cases for _build_deduplication_statement method."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_task_queue = MagicMock()
        self.mock_warehouse_proxy = MagicMock()
        self.handler = DeduplicatePartitionDataHandler(
            task_queue=self.mock_task_queue,
            warehouse_proxy=self.mock_warehouse_proxy,
        )

    def test_build_basic_deduplication_statement(self):
        """Test building a basic deduplication DELETE statement with unquoted columns."""
        sql = self.handler._build_deduplication_statement(
            target_table="DB.SCHEMA.TABLE",
            partition_columns=["ProductID"],
            min_value=1,
            max_value=100,
            primary_key_columns=["ProductID"],
            watermark_column="timestamp",
        )

        # Check DELETE...USING structure
        self.assertIn("DELETE FROM DB.SCHEMA.TABLE AS target", sql)
        self.assertIn("USING (", sql)
        self.assertIn(") AS winners", sql)

        # Unquoted column names pass through as-is (Snowflake resolves to uppercase)
        self.assertIn("MAX(timestamp) AS max_watermark", sql)
        self.assertIn("GROUP BY ProductID", sql)

        # Check WHERE clause has join condition
        self.assertIn("target.ProductID = winners.ProductID", sql)
        self.assertIn("target.timestamp < winners.max_watermark", sql)

    def test_build_statement_with_pre_quoted_columns(self):
        """Test that pre-quoted column names (from mappings) are preserved."""
        sql = self.handler._build_deduplication_statement(
            target_table="DB.SCHEMA.TABLE",
            partition_columns=['"Id"'],
            min_value=1,
            max_value=100,
            primary_key_columns=['"Id"'],
            watermark_column="timestamp",
        )

        # Pre-quoted identifier is preserved as-is
        self.assertIn('GROUP BY "Id"', sql)
        self.assertIn('target."Id" = winners."Id"', sql)

        # Unmapped watermark stays unquoted
        self.assertIn("MAX(timestamp) AS max_watermark", sql)
        self.assertIn("target.timestamp < winners.max_watermark", sql)

    def test_build_statement_with_multiple_primary_keys(self):
        """Test building statement with composite primary key."""
        sql = self.handler._build_deduplication_statement(
            target_table="DB.SCHEMA.ORDERS",
            partition_columns=["OrderDate"],
            min_value="2023-01-01",
            max_value="2023-12-31",
            primary_key_columns=["OrderID", "LineItemID"],
            watermark_column="UpdatedAt",
        )

        # Check both primary keys in GROUP BY
        self.assertIn("GROUP BY OrderID, LineItemID", sql)

        # Check both join conditions
        self.assertIn("target.OrderID = winners.OrderID", sql)
        self.assertIn("target.LineItemID = winners.LineItemID", sql)

    def test_build_statement_with_no_boundaries(self):
        """Test building statement when min/max values are None."""
        sql = self.handler._build_deduplication_statement(
            target_table="DB.SCHEMA.TABLE",
            partition_columns=["ID"],
            min_value=None,
            max_value=None,
            primary_key_columns=["ID"],
            watermark_column="ModifiedAt",
        )

        # Should use 1=1 as the partition condition
        self.assertIn("WHERE 1=1", sql)

    def test_build_statement_quotes_special_column_names(self):
        """Test that special column names are properly quoted."""
        sql = self.handler._build_deduplication_statement(
            target_table="DB.SCHEMA.TABLE",
            partition_columns=["Order Date"],
            min_value=1,
            max_value=100,
            primary_key_columns=["Product ID"],
            watermark_column="Modified At",
        )

        # Columns with spaces should be quoted
        self.assertIn('"Order Date"', sql)
        self.assertIn('"Product ID"', sql)
        self.assertIn('"Modified At"', sql)


class TestBuildSnowflakePartitionCondition(unittest.TestCase):
    """Test cases for the build_snowflake_partition_condition utility."""

    def test_build_condition_with_both_bounds(self):
        """Both bounds present -> half-open interior [min, max) by default."""
        condition = build_snowflake_partition_condition("ID", 1, 100)

        self.assertIn("ID >= 1", condition)
        self.assertIn("ID < 100", condition)
        self.assertIn(" AND ", condition)

    def test_build_condition_with_both_bounds_inclusive(self):
        """Last interior bucket uses closed upper bound when requested."""
        condition = build_snowflake_partition_condition(
            "ID", 1, 100, upper_inclusive=True
        )
        self.assertIn("ID >= 1", condition)
        self.assertIn("ID <= 100", condition)

    def test_build_condition_with_only_min_exclusive(self):
        """Only min (upper edge partition) -> exclusive lower bound."""
        condition = build_snowflake_partition_condition("ID", 50, None)
        self.assertEqual("(ID > 50)", condition)

    def test_build_condition_with_only_max_exclusive(self):
        """Only max (lower edge partition) -> exclusive upper bound."""
        condition = build_snowflake_partition_condition("ID", None, 200)
        self.assertEqual("(ID < 200)", condition)

    def test_build_condition_with_no_bounds(self):
        """No bounds -> 1=1."""
        condition = build_snowflake_partition_condition("ID", None, None)
        self.assertEqual("1=1", condition)

    def test_build_condition_with_string_values(self):
        """String values are properly quoted."""
        condition = build_snowflake_partition_condition(
            "CreatedDate", "2023-01-01", "2023-12-31"
        )
        self.assertIn("CreatedDate >= '2023-01-01'", condition)
        self.assertIn("CreatedDate < '2023-12-31'", condition)

    def test_lowercase_column_unquoted_for_snowflake_case_fold(self):
        """Lowercase source-style names stay unquoted so Snowflake uppercases them."""
        condition = build_snowflake_partition_condition("ss_sold_date_sk", 1, 10)
        self.assertIn("ss_sold_date_sk >= 1", condition)
        self.assertIn("ss_sold_date_sk < 10", condition)

    def test_column_with_space_still_quoted(self):
        condition = build_snowflake_partition_condition("Order Date", 1, 2)
        self.assertIn('"Order Date" >= 1', condition)


class TestParseBoundaryValue(unittest.TestCase):
    """Test cases for _parse_boundary_value method."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_task_queue = MagicMock()
        self.mock_warehouse_proxy = MagicMock()
        self.handler = DeduplicatePartitionDataHandler(
            task_queue=self.mock_task_queue,
            warehouse_proxy=self.mock_warehouse_proxy,
        )

    def test_parse_none_value(self):
        """Test parsing None returns None."""
        result = self.handler._parse_boundary_value(None)
        self.assertIsNone(result)

    def test_parse_integer_value(self):
        """Test parsing integer value returns as-is."""
        result = self.handler._parse_boundary_value(42)
        self.assertEqual(42, result)

    def test_parse_float_value(self):
        """Test parsing float value returns as-is."""
        result = self.handler._parse_boundary_value(3.14)
        self.assertEqual(3.14, result)

    def test_parse_plain_string_value(self):
        """Test parsing plain string returns as-is."""
        result = self.handler._parse_boundary_value("hello")
        self.assertEqual("hello", result)

    def test_parse_json_encoded_string(self):
        """Test parsing JSON-encoded string extracts inner value."""
        result = self.handler._parse_boundary_value('"2023-01-01"')
        self.assertEqual("2023-01-01", result)

    def test_parse_json_encoded_number(self):
        """Test parsing JSON-encoded number extracts the number."""
        result = self.handler._parse_boundary_value("123")
        self.assertEqual(123, result)


class TestDeduplicatePartitionDataHandlerHandle(unittest.IsolatedAsyncioTestCase):
    """Test cases for handle method."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_task_queue = MagicMock()
        self.mock_task_queue.complete_task = AsyncMock(return_value=True)

        self.mock_warehouse_proxy = MagicMock()
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(return_value=[])

        self.handler = DeduplicatePartitionDataHandler(
            task_queue=self.mock_task_queue,
            warehouse_proxy=self.mock_warehouse_proxy,
        )

    async def test_handle_raises_error_when_warehouse_proxy_is_none(self):
        """Test handle() raises ValueError when warehouse_proxy is None."""
        handler = DeduplicatePartitionDataHandler(
            task_queue=self.mock_task_queue,
            warehouse_proxy=None,
        )

        payload = DeduplicatePartitionDataPayload(
            table_metadata_id=1,
            partition_metadata_id=1,
        )
        task = Task(
            id=1,
            workflow_id=100,
            task_name="Deduplicate partition: test",
            executor_type=ExecutorType.ORCHESTRATOR,
            status=TaskStatus.EXECUTING,
            priority=1.0,
            payload=payload,
            scope="Table[DB.SCHEMA.TABLE]::Partition[1]::Deduplicating",
        )

        with self.assertRaises(ValueError) as context:
            await handler.handle(task)

        self.assertIn("warehouse_proxy is required", str(context.exception))

    async def test_handle_raises_error_on_invalid_payload(self):
        """Test handle() raises ValueError for invalid payload type."""
        # Create a mock payload of wrong type
        invalid_payload = MagicMock()
        invalid_payload.__class__ = type("WrongPayload", (), {})

        task = Task(
            id=1,
            workflow_id=100,
            task_name="Test task",
            executor_type=ExecutorType.ORCHESTRATOR,
            status=TaskStatus.EXECUTING,
            priority=1.0,
            payload=invalid_payload,
            scope="Test",
        )

        with self.assertRaises(ValueError) as context:
            await self.handler.handle(task)

        self.assertIn(
            "Expected DeduplicatePartitionDataPayload", str(context.exception)
        )

    async def test_handle_applies_column_name_mappings(self):
        """Test handle() translates mapped columns to quoted target names."""
        table_config = TableConfiguration(
            source=TableIdentifier("SRC_DB", "SRC_SCHEMA", "SRC_TABLE"),
            target=TableIdentifier("TGT_DB", "TGT_SCHEMA", "TGT_TABLE"),
            partition_columns=["ID"],
            primary_key_columns=["ID"],
            column_name_mappings={"ID": '"Id"'},
            synchronization=SynchronizationConfig(
                strategy=SyncStrategy.WATERMARK,
                watermark_column="timestamp",
                track_modifications=True,
            ),
        )

        self.handler.table_config_service.fetch_required_table_configuration = (
            AsyncMock(return_value=table_config)
        )
        self.handler.sync_config_service.fetch_synchronization_config = AsyncMock(
            return_value=table_config.synchronization
        )
        self.handler._fetch_partition_metadata = AsyncMock(
            return_value={"min_value": None, "max_value": None}
        )
        self.handler._update_partition_status = AsyncMock()

        payload = DeduplicatePartitionDataPayload(
            table_metadata_id=1,
            partition_metadata_id=1,
        )
        task = Task(
            id=1,
            workflow_id=100,
            task_name="Deduplicate partition: test",
            executor_type=ExecutorType.ORCHESTRATOR,
            status=TaskStatus.EXECUTING,
            priority=1.0,
            payload=payload,
            scope="Table[TGT_DB.TGT_SCHEMA.TGT_TABLE]::Partition[1]::Deduplicating",
        )

        await self.handler.handle(task)

        executed_sql = self.mock_warehouse_proxy.execute_sync_query.call_args[0][0]

        # Mapped column "ID" → "Id" must appear force-quoted to preserve case
        self.assertIn('"Id"', executed_sql)

        # Unmapped watermark "timestamp" must stay unquoted (Snowflake resolves to TIMESTAMP)
        self.assertIn("MAX(timestamp)", executed_sql)
        self.assertIn("target.timestamp < winners.max_watermark", executed_sql)

        # Source column name "ID" (unquoted) must NOT appear
        self.assertNotIn("SELECT ID", executed_sql)
        self.assertNotIn("GROUP BY ID", executed_sql)


if __name__ == "__main__":
    unittest.main()
