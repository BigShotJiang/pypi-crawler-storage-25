"""Tests for PreprocessingCheckHandler."""

import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.data_migration_cloud.exceptions.table_not_found_error import (
    TableNotFoundError,
)
from data_migration_orchestrator.data_migration_cloud.exceptions.view_not_supported_error import (
    ViewNotSupportedError,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.preprocessing_check_handler import (
    PreprocessingCheckHandler,
)
from data_migration_orchestrator.data_migration_cloud.utils.stage_utils import (
    ObjectTypeFromStageResult,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    PreprocessingCheckPayload,
)

MODULE = "data_migration_orchestrator.data_migration_cloud.tasks.handlers.preprocessing_check_handler"


def _make_handler() -> tuple[PreprocessingCheckHandler, MagicMock, MagicMock]:
    mock_queue = MagicMock()
    mock_queue.push_task = AsyncMock(return_value=1)
    mock_queue.complete_task = AsyncMock()
    mock_queue.warn_task = AsyncMock()

    mock_warehouse = MagicMock()
    mock_warehouse.execute_sync_query = AsyncMock(return_value=[])

    handler = PreprocessingCheckHandler(
        task_queue=mock_queue,
        warehouse_proxy=mock_warehouse,
    )
    return handler, mock_queue, mock_warehouse


def _make_payload(**overrides) -> PreprocessingCheckPayload:
    defaults = dict(
        database="db",
        schema="public",
        table_name="orders",
        source_type="sqlserver",
        target_table="db.public.orders",
        target_cloud_type="snowflake:stage",
        table_metadata_id=100,
    )
    defaults.update(overrides)
    return PreprocessingCheckPayload(**defaults)


def _make_task(payload: PreprocessingCheckPayload) -> Task:
    return Task(
        id=42,
        workflow_id=1,
        executor_type=ExecutorType.ORCHESTRATOR,
        task_name="test",
        payload=payload,
        scope="Table[db.public.orders]::Preprocessing",
    )


class TestPreprocessingCheckTableExists(unittest.IsolatedAsyncioTestCase):
    """Object is a TABLE -> no warning, creates downstream tasks."""

    @patch(f"{MODULE}.read_object_type_from_stage", new_callable=AsyncMock)
    @patch(f"{MODULE}.PlatformRegistry")
    async def test_table_creates_downstream_tasks_no_warning(
        self,
        mock_registry,
        mock_read_ot,
    ):
        mock_read_ot.return_value = ObjectTypeFromStageResult("TABLE", 1)

        mock_builder = MagicMock()
        mock_builder.build_metadata_query.return_value = "SELECT 1"
        mock_builder.build_schema_query.return_value = "SELECT 2"
        mock_builder.build_use_database_command.return_value = None
        mock_platform = MagicMock()
        mock_platform.query_builder = mock_builder
        mock_platform.name = "sqlserver"
        mock_registry.create_by_name_or_alias.return_value = mock_platform

        handler, mock_queue, _ = _make_handler()
        task = _make_task(_make_payload())

        await handler.handle(task)

        mock_queue.warn_task.assert_not_called()
        # 3 downstream tasks: partition strategy + metadata extract + schema extract
        self.assertEqual(mock_queue.push_task.call_count, 3)
        mock_queue.complete_task.assert_called_once()


class TestPreprocessingCheckObjectNotFound(unittest.IsolatedAsyncioTestCase):
    """Object does not exist -> raises TableNotFoundError."""

    @patch(f"{MODULE}.read_object_type_from_stage", new_callable=AsyncMock)
    async def test_missing_object_raises_table_not_found(self, mock_read_ot):
        mock_read_ot.return_value = ObjectTypeFromStageResult(None, 0)

        handler, _, _ = _make_handler()
        task = _make_task(_make_payload())

        with self.assertRaises(TableNotFoundError) as ctx:
            await handler.handle(task)
        self.assertIn("No object_type parquet rows matched", str(ctx.exception))

    @patch(f"{MODULE}.read_object_type_from_stage", new_callable=AsyncMock)
    async def test_unreadable_object_type_raises_table_not_found(self, mock_read_ot):
        mock_read_ot.return_value = ObjectTypeFromStageResult(None, 1)

        handler, _, _ = _make_handler()
        task = _make_task(_make_payload())

        with self.assertRaises(TableNotFoundError) as ctx:
            await handler.handle(task)
        self.assertIn("could not be read", str(ctx.exception))


class TestPreprocessingCheckView(unittest.IsolatedAsyncioTestCase):
    """Object is a VIEW -> raises ViewNotSupportedError, halts the chain."""

    @patch(f"{MODULE}.read_object_type_from_stage", new_callable=AsyncMock)
    async def test_view_raises_error(self, mock_read_ot):
        mock_read_ot.return_value = ObjectTypeFromStageResult("VIEW", 1)

        handler, mock_queue, _ = _make_handler()
        task = _make_task(_make_payload())

        with self.assertRaises(ViewNotSupportedError) as ctx:
            await handler.handle(task)

        self.assertIn("VIEW", str(ctx.exception))
        self.assertIn("not a TABLE", str(ctx.exception))
        mock_queue.push_task.assert_not_called()
        mock_queue.complete_task.assert_not_called()


class TestPreprocessingCheckUnknownType(unittest.IsolatedAsyncioTestCase):
    """Object type is UNKNOWN -> warn_task called, still proceeds."""

    @patch(f"{MODULE}.read_object_type_from_stage", new_callable=AsyncMock)
    @patch(f"{MODULE}.PlatformRegistry")
    async def test_unknown_type_warns_and_proceeds(self, mock_registry, mock_read_ot):
        mock_read_ot.return_value = ObjectTypeFromStageResult("SYNONYM", 1)

        mock_builder = MagicMock()
        mock_builder.build_metadata_query.return_value = "SELECT 1"
        mock_builder.build_schema_query.return_value = "SELECT 2"
        mock_builder.build_use_database_command.return_value = None
        mock_platform = MagicMock()
        mock_platform.query_builder = mock_builder
        mock_platform.name = "sqlserver"
        mock_registry.create_by_name_or_alias.return_value = mock_platform

        handler, mock_queue, _ = _make_handler()
        task = _make_task(_make_payload())

        await handler.handle(task)

        mock_queue.warn_task.assert_called_once()
        warn_msg = mock_queue.warn_task.call_args[0][1]
        self.assertIn("unrecognized", warn_msg)


class TestPreprocessingCheckTeradataMetadataWarning(unittest.IsolatedAsyncioTestCase):
    """Teradata metadata extraction may use COUNT(*); user is warned."""

    @patch(f"{MODULE}.read_object_type_from_stage", new_callable=AsyncMock)
    @patch(f"{MODULE}.PlatformRegistry")
    async def test_teradata_warns_about_count_fallback(
        self,
        mock_registry,
        mock_read_ot,
    ):
        mock_read_ot.return_value = ObjectTypeFromStageResult("TABLE", 1)

        mock_builder = MagicMock()
        mock_builder.build_metadata_query.return_value = "SELECT 1"
        mock_builder.build_schema_query.return_value = "SELECT 2"
        mock_builder.build_use_database_command.return_value = None
        mock_platform = MagicMock()
        mock_platform.query_builder = mock_builder
        mock_platform.name = "teradata"
        mock_registry.create_by_name_or_alias.return_value = mock_platform

        handler, mock_queue, _ = _make_handler()
        task = _make_task(_make_payload(source_type="teradata"))

        await handler.handle(task)

        mock_queue.warn_task.assert_called_once()
        warn_msg = mock_queue.warn_task.call_args[0][1]
        self.assertIn("COUNT(*)", warn_msg)
        self.assertIn("COLLECT STATISTICS", warn_msg)


class TestPreprocessingCheckOracleMetadataWarning(unittest.IsolatedAsyncioTestCase):
    """Oracle metadata extraction may use COUNT(*) when NUM_ROWS is null; user is warned."""

    @patch(f"{MODULE}.read_object_type_from_stage", new_callable=AsyncMock)
    @patch(f"{MODULE}.PlatformRegistry")
    async def test_oracle_warns_about_count_fallback(
        self,
        mock_registry,
        mock_read_ot,
    ):
        mock_read_ot.return_value = ObjectTypeFromStageResult("TABLE", 1)

        mock_builder = MagicMock()
        mock_builder.build_metadata_query.return_value = "SELECT 1"
        mock_builder.build_schema_query.return_value = "SELECT 2"
        mock_builder.build_use_database_command.return_value = None
        mock_platform = MagicMock()
        mock_platform.query_builder = mock_builder
        mock_platform.name = "oracle"
        mock_registry.create_by_name_or_alias.return_value = mock_platform

        handler, mock_queue, _ = _make_handler()
        task = _make_task(_make_payload(source_type="oracle"))

        await handler.handle(task)

        mock_queue.warn_task.assert_called_once()
        warn_msg = mock_queue.warn_task.call_args[0][1]
        self.assertIn("COUNT(*)", warn_msg)
        self.assertIn("ALL_TABLES.NUM_ROWS", warn_msg)
        self.assertIn("GATHER_TABLE_STATS", warn_msg)


if __name__ == "__main__":
    unittest.main()
