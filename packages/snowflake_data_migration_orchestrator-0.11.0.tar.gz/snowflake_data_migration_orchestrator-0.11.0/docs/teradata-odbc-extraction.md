# Teradata ODBC (`regular`) Extraction

This document describes the default Teradata extraction path: **`regular`** (ODBC-style).
The orchestrator builds tasks whose payloads target the Snowflake **internal** stage
(`TASK_RESULTS`); the data exchange agent (DEA) runs a partition `SELECT` via
**`teradatasql`** (preferred) or **`pyodbc`**, materializes **Parquet** locally, **`PUT`s**
to that stage, and the orchestrator later loads into the target table—same pattern as
other sources using `TargetType.SNOWFLAKE_STAGE`.

See also:

- [TPT extraction](./tpt-extraction.md) — Teradata Parallel Transporter (`tpt`).
- [Teradata `WRITE_NOS` extraction](./write-nos-extraction.md) — server-side export to
  object storage (`write_nos`).

## Overview

`regular` is the **default** extraction strategy when the workflow omits `extraction` or
sets `"strategy": "regular"`. Trade-offs versus other Teradata strategies:

| Strategy   | Where data flows | Pros | Cons |
|------------|------------------|------|------|
| `regular`  | Teradata → DEA (rows in memory) → Parquet → Snowflake **internal** stage | No TTU, no NOS, simplest config | Throughput bound by worker CPU/RAM and ODBC fetch |
| `tpt`      | Teradata → DEA (`tbuild`) → CSV → Parquet → internal stage | Parallel Teradata sessions | Requires TTU on the worker |
| `write_nos`| Teradata → cloud storage (Parquet) → Snowflake **external** stage | Server-side export | Bucket + stage + IAM alignment |

## Pre-requisites

1. **Teradata connectivity on the DEA host**
   - **`teradatasql`** (pure Python) is tried first — no ODBC install required when it is
     available (`data_sources/teradata_connection.py`).
   - Otherwise **`pyodbc`** with a valid ODBC setup for Teradata.
2. **DEA TOML** — standard `[connections.source.teradata]` host, port, database, credentials.
   You do **not** need `tpt_*` directories or `write_nos_*` keys for `regular` alone.
3. **Workflow JSON** — either omit `extraction` (defaults to `regular`) or:

   ```json
   "extraction": { "strategy": "regular" }
   ```

   Do **not** set `externalStage`; that is only for `write_nos` (and UNLOAD on other
   platforms).

4. **Snowflake internal stage** — orchestrator uses `default_internal_stage()` →
   `@<migration_schema>.TASK_RESULTS` (see `data_migration_cloud/constants/stages.py`).
   Partition data lands under the usual `task_results/workflows/...` prefix produced by
   `stage_path_for_partition_data` in `task_chain_creator.py`.

## Sequence diagram

```mermaid
sequenceDiagram
    autonumber
    participant U as User / workflow JSON
    participant O as Data migration orchestrator
    participant DB as Snowflake (control DB)
    participant DEA as Data exchange agent (worker)
    participant TD as Teradata
    participant FS as Worker disk (temp Parquet)
    participant ST as Snowflake internal stage (TASK_RESULTS)
    participant TGT as Snowflake target table

    U->>O: extraction_strategy = regular (or default)
    O->>O: TaskChainCreator builds DataMovementTaskPayload
    Note over O: target_type = SNOWFLAKE_STAGE<br/>target_id = @...TASK_RESULTS/.../partition_N/
    O->>DB: Push extraction task
    DB-->>DEA: Pull next task

    DEA->>TD: OPEN teradatasql or pyodbc
    DEA->>TD: EXEC partition SELECT (statement_location_id)
    TD-->>DEA: Fetch rows (streaming)

    DEA->>FS: Write Parquet (PyArrow)
    DEA->>ST: PUT file to internal stage path
    DEA->>DB: complete_task

    DB-->>O: Chain continues (preprocess / load)
    O->>ST: COPY INTO / staged reads from same internal prefix
    O->>TGT: Load into target table
```

## Task contract

| Field | `regular` (Teradata) value | Notes |
|-------|---------------------------|-------|
| `target_type` | `snowflake:stage` | Same string as `TargetType.SNOWFLAKE_STAGE`. |
| `target_id` | Internal stage URL prefix, e.g. `@DB.SCHEMA.TASK_RESULTS/task_results/workflows/{wf}/tables/{table}/.../partition_N/` | Built by `stage_path_for_partition_data` + `default_internal_stage()`. |
| `extraction_strategy` | `regular` | Optional telemetry; default when omitted from workflow. |
| `statement_location_id` | Partition-aware `SELECT` from `TeradataQueryBuilder` | Type-aware casts (same builder family as TPT / WRITE_NOS SELECT input). |
| `suggested_batch_size` | From smart partition resolver | Teradata `REGULAR` profile uses the ODBC-style memory bounds in `smart_partition_config_resolver.py` (1 GB target / 2 GB max per partition at time of writing). |
| `is_bulk_operation` | `true` | |

## Code map

### Orchestrator

- `data_migration_cloud/config/extraction_strategy.py` — `ExtractionStrategy.REGULAR`,
  `DEFAULT_EXTRACTION_STRATEGY`
- `data_migration_cloud/config/table_configuration.py` — default strategy `REGULAR`
- `data_migration_cloud/platforms/teradata/platform.py` — default strategy `REGULAR`;
  supported strategies include `REGULAR` and `WRITE_NOS`
- `data_migration_cloud/platforms/teradata/query_builder.py` — extraction `SELECT` for
  ODBC path
- `data_migration_cloud/tasks/task_chain_creator.py` — `TargetType.SNOWFLAKE_STAGE`,
  `stage_path_for_partition_data`, `suggested_batch_size` from context
- `data_migration_cloud/tasks/models/task_payload.py` — `TargetType.SNOWFLAKE_STAGE`
- `data_migration_cloud/tasks/handlers/smart_partition_config_resolver.py` —
  `(SourceType.TERADATA, ExtractionStrategy.REGULAR)` partition profile
- `data_migration_cloud/utils/stage_utils.py` — internal stage resolution for `REGULAR`
- `data_migration_cloud/constants/stages.py` — `default_internal_stage()` → `TASK_RESULTS`

### Data exchange agent

- `constants/task_keys.py` — `TargetTypeValues.SNOWFLAKE_STAGE` (`snowflake:stage`)
- `constants/data_source_types.py` — `DataSourceType.ODBC`
- `data_sources/odbc_data_source.py` — cursor fetch → Parquet
- `data_sources/teradata_connection.py` — `teradatasql` vs `pyodbc` selection
- `config/sections/connections/odbc/teradata.py` — `TeradataConnectionConfig` (host, port,
  database, etc.)
- `tasks/manager.py` — resolves to `ODBCDataSource` for Teradata `regular` extraction;
  performs **`PUT`** to Snowflake after export (contrast with `WRITE_NOS` / `UNLOAD`, which
  skip upload)

## Failure modes

- **Driver / connection** — cannot import `teradatasql` and ODBC not configured → connection
  errors from `open_teradata_connection`.
- **Teradata SQL** — syntax or permission errors on the partition `SELECT`; surfaced from
  `cursor.execute` / fetch.
- **Worker resources** — large partitions stress RAM during fetch → tune partition strategy,
  row counts, or move to **`tpt`** / **`write_nos`** for heavier profiles.
- **Snowflake `PUT`** — stage privileges, network, or file-size limits; same remediation as
  other platforms using internal-stage extraction.

## Why not `externalStage`?

`regular` always uses the **internal** migration stage for extracted Parquet. Only
**`write_nos`** (and Redshift **`unload`**) use **`externalStage`** in the workflow
configuration
