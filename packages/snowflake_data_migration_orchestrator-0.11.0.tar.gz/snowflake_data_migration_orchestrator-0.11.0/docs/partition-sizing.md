# Partition Sizing (internal)

For boundary discovery, edge partitions, multi-column lex bounds, interval semantics, and how DM vs DV use partitions, see [partitioning.md](partitioning.md).

Shared calculator: `data_migration_cloud/tasks/handlers/partition_calculator.py`

## Five-factor model

`PartitionConfig` exposes five fields grouped into **targets** (user-configurable) and **maxes** (internal / system-imposed):

| Factor | Field | Meaning |
|--------|-------|---------|
| Target MB | `target_mb_per_partition` | Desired partition size in MB |
| Target rows | `target_rows_per_partition` | Desired partition size in rows |
| Max MB | `max_target_mb_per_partition` | Hard ceiling on partition MB |
| Max rows | `max_target_rows_per_partition` | Hard ceiling on partition rows |
| Max cells | `max_target_cells_per_partition` | Hard ceiling on cells per partition (rows × columns) |

The two target fields are **mutually exclusive** at the user-config level (both DM and DV reject setting both). At runtime only one target is ever populated.

## Pipeline

1. **Target rows** — derived from whichever target is set (`target_rows_per_partition` directly, or `target_mb_per_partition / avg_row_mb`). Falls back to `row_count` (no split) when neither is set.
2. **Max rows** — `min(max_target_rows_per_partition, max_target_mb_per_partition / avg_row_mb, max_target_cells_per_partition / num_columns)`; tighter wins. Uncapped when none of the three are set (or when `avg_row_mb` is zero, the MB-derived term is omitted; when `num_columns` is zero, the cells-derived term is omitted).
3. **Effective** — `min(target_rows, max_rows)`, at least 1. When no max candidates apply, `max_rows` is treated as absent and the effective size is the target alone.
4. **Partition count** — `ceil(row_count / effective)`, or 1 when `effective >= row_count`.

## Unified JSON contract

Both DM and DV now use camelCase field names:

| Field | Type | Description |
|-------|------|-------------|
| `columnNamesToPartitionBy` | `list[str]` | Ordered columns for lexicographic NTILE partitioning (one or more) |
| `targetPartitionSizeMb` | `int` | Target partition size in MB |
| `targetPartitionSizeRows` | `int` | Target partition size in rows |

**Auto mode**: omit both `targetPartitionSizeMb` and `targetPartitionSizeRows`. No `"auto"` string needed.

**Explicit targets**: when either `targetPartitionSizeMb` or `targetPartitionSizeRows` is set, that value becomes the **desired** partition size. **Data Validation** still applies internal max caps (rows, MB, cells) on top of that target. **Data Migration** fixed sizing leaves `max_target_*` unset, so the calculator uses the explicit target only.

## DM defaults

Resolved by `SmartPartitionConfigResolver` using platform/strategy profiles (auto mode only):

| Platform | Strategy | target MB | max MB |
|----------|----------|-----------|--------|
| Redshift | UNLOAD | 5 120 | 10 240 |
| Redshift | REGULAR | 2 048 | 5 120 |
| SQL Server | REGULAR | 1 024 | 2 048 |
| PostgreSQL | REGULAR | 1 024 | 2 048 |
| *(fallback)* | — | 2 048 | 5 120 |

When a user sets an explicit MB or row target, `SmartPartitionConfigResolver` does **not** populate `max_target_*` on the config, so no internal caps are applied for that DM path.

## DV defaults

Set in `GenerateValidationQueriesHandler._create_partition_metadata`:

| Factor | Default | Condition |
|--------|---------|-----------|
| `target_mb_per_partition` | 200 MB | When `targetPartitionSizeMb` / `targetPartitionSizeRows` are omitted |
| `max_target_rows_per_partition` | 5 000 000 | Always (when using the calculator) |
| `max_target_mb_per_partition` | 1 024 MB | Always |
| `max_target_cells_per_partition` | 100 000 000 | When `target_database` is set and column count can be read from `INFORMATION_SCHEMA.COLUMNS` |

When the user specifies `targetPartitionSizeRows` or `targetPartitionSizeMb`, the internal max caps above are still **always** passed into `PartitionCalculator` and tighten the effective partition size together with the user's target.

The cells limit uses the target table's column count and is omitted when `target_database` is missing or the catalog query fails (then `num_columns` is zero in the calculator and the cells-derived max is skipped).

## Lexicographic partition boundaries

Boundary discovery, storage format, interval semantics, edge partitions, and multi-column behavior are documented in [partitioning.md](partitioning.md). Implementation: `data_migration_cloud/partition/partition_range.py` and platform `build_partition_condition` methods.
