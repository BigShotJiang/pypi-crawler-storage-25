# Cloud Data Validation Workflow (engineering notes)

## CLI and Hatch scripts

- **Python:** `python -m data_migration_orchestrator create-data-validation-workflow <config.json> --source-platform <platform> [--name ...] [--connection-name ...]`
- **Hatch (from `data-migration-orchestrator/`):** `hatch run create-validation-workflow -- <config.json> --source-platform <platform> [extra args]`

Pass `--source-platform` on every invocation; its value must match `source_platform` in the JSON (the field remains required in the file for validation).

## Code map

| Area | Location |
|------|----------|
| CLI | `src/data_migration_orchestrator/commands/create_data_validation_workflow.py` |
| JSON schema (structural) | `data_validation_cloud/config/workflow_configuration_schema.py` |
| Parsed config / defaults | `data_validation_cloud/config/validation_configuration_parser.py` |
| Workflow initialization | `data_validation_cloud/data_validation_workflow_initializer.py` |
| Snowpipe result ingestion | `data_validation_cloud/utils/pipe_utils.py`, `utils/ensure_dv_pipe.py`, `tasks/snowpipe_flow.py`, `tasks/handlers/teardown_dv_snowpipe_handler.py`, shared helpers in `cloud_core/utils/pipe_utils.py` |
| Worker execution | `data-exchange-agent` — `tasks/data_validation/` (dispatched from `tasks/manager.py` for `data_validation` tasks) |

## Dependencies

- Orchestrator packages include validation modules in-repo.
- Workers need **`snowflake-data-validation`** installed to run validation tasks (row/cell/schema/metrics), in addition to source ODBC drivers as appropriate.

## Metadata layout

- Workflow rows for validation use `WORKFLOW_TYPE = 'data-validation'` in the **data migration** metadata schema (default `SNOWCONVERT_AI.DATA_MIGRATION`), same `WORKFLOW` table as migrations.
- Result tables and validation-specific objects live under the **data validation** schema (default `SNOWCONVERT_AI.DATA_VALIDATION`), controlled by `CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_VALIDATION_METADATA`.

## Partitioning (`columnNamesToPartitionBy`)

DV uses the same partition calculator and lexicographic interval rules as DM. Boundaries are discovered with NTILE on the **Snowflake target** (`generate_validation_queries_handler._create_partition_metadata`). Metadata holds **N interior buckets only** (no DM-style edge partitions); L2/L3 tasks get scoped `WHERE` clauses from `data_validation_cloud/utils/partition_where.py`.

See [partitioning.md](partitioning.md) for the full guide (edge vs interior, multi-column bounds, sampling). Partition count defaults and caps are in [partition-sizing.md](partition-sizing.md).

## Result ingestion: Snowpipe vs. COPY INTO

L2 (metrics) and L3 (row / cell / hybrid) results are written to the shared
per-workflow results tables — `METRICS_VALIDATION_RESULTS`,
`ROW_VALIDATION_RESULTS`, `ROW_VALIDATION_SUMMARY`, `CHUNK_HASHES` and
`CELL_VALIDATION_RESULTS`. Two loading modes are available, selected by the
workflow-level `use_snowpipe_for_results` flag (default `true`):

- **Snowpipe mode** (`use_snowpipe_for_results = true`):
  - There is **one temporary Snowpipe per `(workflow_id, table_metadata_id, DvResultsPipeKey)`**
    (METRICS, ROW_DIFFS, ROW_SUMMARY, CHUNK_HASHES, CELL_DIFFS) living in
    the shared `TEMP` schema, named
    `DVO_PIPE_<WORKFLOW_ID>_<TABLE_METADATA_ID>_<KEY>` (see
    `data_validation_cloud/utils/pipe_utils.py`). Concurrent workflows
    and sibling tables therefore never share a pipe, so `SYSTEM$PIPE_STATUS.pendingFileCount`
    is a reliable drain signal per table.
  - Pipes are created synchronously and torn down via an orchestrator
    cleanup task. On the first
    `ensure_dv_pipe(task_queue, warehouse, workflow_id, table_metadata_id, key)` call per
    process for a given `(workflow_id, table_metadata_id, key)`, the helper:
    * runs `CREATE PIPE IF NOT EXISTS` inline through the warehouse proxy
      (DV pipes are monitored via `SYSTEM$PIPE_STATUS` drain mode, so
      `LOG_EVENT_LEVEL` is left at the account default), and only after
      the DDL succeeds does it
    * push a `TEARDOWN_DV_SNOWPIPE` cleanup task (`.blocked().cleanup()`)
      that runs `DROP PIPE IF EXISTS` after every non-cleanup task
      terminates, even on failure.
    Doing the create synchronously guarantees the pipe exists before any
    DEA partition task pushed afterwards can issue `ALTER PIPE … REFRESH`
    against it. A process-local cache keyed by `(workflow_id, table_metadata_id, key)`
    prevents duplicate creates/teardowns within a process; cross-process
    duplicates are harmless because both DDL statements are idempotent.
  - Each pipe's `FROM` clause watches the whole validation stage root and
    uses a `PATTERN` regex that embeds the `workflow_id` and `table_metadata_id` so only files
    from that table's subtree are eligible. DEA partition tasks upload
    CSVs to the partition stage path and, after the upload succeeds, issue
    `ALTER PIPE ... REFRESH PREFIX='<workflow>/<table>/<level>/p<N>/...'`
    for every pipe attached to their payload (`result_pipes`).
  - For each result pipe, the chain includes one **drain barrier** task
    (`executor = SNOWPIPE`, `mode = drain`) that polls `SYSTEM$PIPE_STATUS`
    until `pendingFileCount == 0` for that **entire pipe** (not per partition).
    Multiple partition DEAs can fan in to the **same** drain node for a given
    pipe (for example every partition’s row DEA pointing at the shared
    `ROW_DIFFS` drain). Multi-pipe levels chain drains sequentially
    (`ROW_DIFFS` → `ROW_SUMMARY` → `CHUNK_HASHES`); the last drain unblocks
    `Evaluate`. Implementation: `data_validation_cloud/tasks/snowpipe_flow.py`;
    drain polling groups tasks by pipe in
    `cloud_core/tasks/queues/table_task_queue.py` (`_refresh_snowpipe_drain_tasks`).
    For pipe-wide semantics, see `docs/snowpipe-data-validation.md` (Monitoring).
- **COPY INTO mode** (`use_snowpipe_for_results = false`):
  - Retains the original per-partition chain where each DEA task is
    followed by a `Write validation results` (`COPY INTO`) task, and all
    write tasks fan in to a single `Evaluate` task.

### Task chain after the change (L3 row, 2 partitions, Snowpipe mode)

> Pipes are created synchronously by `ensure_dv_pipe` while the planning
> task runs (before any node below is pushed to the queue), so they do
> not appear as task nodes in the chain.

```mermaid
graph LR
    V1[Validate L3 p0 DEA + ALTER PIPE REFRESH] --> D1[Drain ROW_DIFFS SNOWPIPE]
    V2[Validate L3 p1 DEA + ALTER PIPE REFRESH] --> D1
    D1 --> D2[Drain ROW_SUMMARY SNOWPIPE]
    D2 --> D3[Drain CHUNK_HASHES SNOWPIPE]
    D3 --> E[Evaluate L3 ORCH]
    E -. cleanup .-> T1[Teardown ROW_DIFFS]
    E -. cleanup .-> T2[Teardown ROW_SUMMARY]
    E -. cleanup .-> T3[Teardown CHUNK_HASHES]
```

> **Updating a pipe.** DV pipes are per workflow table and are dropped by the
> Teardown cleanup task at the end of each workflow, so you can change
> `build_create_pipe_sql` freely - every new workflow picks up the new
> DDL. No versioning or manual cleanup is required.

## Hybrid L3 (`row_validation_mode = "hybrid"`)

Hybrid validates a table in two phases anchored on a single per-table
`Evaluate L3` orchestrator task:

1. **Row-hashing phase** — one MD5 row-hash DEA per partition writes to the
   per-table row-result Snowpipes (`ROW_DIFFS`, `ROW_SUMMARY`,
   `CHUNK_HASHES`) or per-partition `WriteResults[row]` COPY tasks
   (non-Snowpipe). All row tasks fan in to the per-table `Evaluate L3` task
   either directly (non-Snowpipe) or through `PrepareDvDrain` ⇒ row drains
   (Snowpipe). The L3 early-stop poll (mandatory for hybrid; the parser
   rejects `hybrid` without `early_stopping`) watches that Evaluate task and
   may bulk-skip remaining row tasks for the table once the
   `early_stop_mismatch_row_threshold` count is reached against
   `ROW_VALIDATION_RESULTS`.
2. **Cell drill-down phase** — when the per-table `Evaluate L3` task runs,
   `EvaluateLevelResultHandler._dispatch_hybrid_drilldown` queries
   `ROW_VALIDATION_RESULTS` for partitions whose `RESULT = 'FAILURE'` (row
   present on both sides but hashes disagree) and pushes one cell DEA per
   such partition (narrowed to the failed row keys via
   `_narrow_hybrid_cell_where_to_md5_failures`). The cell DEAs fan in to a
   per-table `CELL_DIFFS` Snowpipe drain (single-pipe; no `PrepareDvDrain`)
   whose successor is a single per-table `FinalizeHybridL3` orchestrator
   task. `FinalizeHybridL3` reads `CELL_VALIDATION_RESULTS` for the table,
   sets `L3_STATUS` for every partition via
   `bulk_set_partition_level_status`, and marks the table `COMPLETED` (no
   diffs) or `FAILED` (any diffs) via `UPDATE_TABLE_VALIDATION_STATUS`.

If the row-hashing phase finds zero mismatched partitions, the cell phase
is skipped entirely — the Evaluate handler runs the finalize logic inline
and marks `L3_STATUS=valid` / table `COMPLETED`.

The cell drill-down tasks do **not** count toward the early-stop
threshold; the threshold is row-hash mismatches only.

## View validation support

Cloud Data Validation can validate **views** alongside (or instead of) tables. Views flow through the same L1/L2/L3 pipeline with a few platform-specific adaptations.

### Configuration

The workflow JSON accepts an optional **`views`** array at the top level, using the same entry shape as `tables`. Entries under `views` are automatically assigned `object_type = "VIEW"`; entries under `tables` get `object_type = "TABLE"`. You may also set `object_type` explicitly on any entry.

Parser: `ValidationConfigurationParser.parse_tables()` iterates `tables` then `views`, tagging each with the appropriate `object_type`. The combined list is stored as a single `ValidationTableConfiguration` sequence in Snowflake metadata.

### Pipeline behaviour

| Area | Tables | Views |
|------|--------|-------|
| **L1 schema (Teradata)** | Full field set (existence, datatype, precision, scale, length, nullable, ordinal) via `DBC.Columns` | Basic field set (existence + datatype only) via `HELP COLUMN`. Source metadata is normalized with `normalize_table_metadata` before comparison. |
| **L1 schema (Redshift)** | Full schema validation | Full schema validation via `SVV_COLUMNS` (same as tables). Cloud DV does not materialize views. |
| **L1 schema (Oracle)** | Full schema validation via `ALL_TAB_COLUMNS` | Full schema validation — Oracle exposes view columns through `ALL_TAB_COLUMNS` the same way as tables. No materialization or special handling needed. |
| **L1 schema (PostgreSQL)** | Full schema validation | Full schema validation via `information_schema` / `pg_catalog` (same as tables). Cloud DV does not materialize views. |
| **L1 schema (other platforms)** | Full schema validation | Full schema validation (catalogs expose view columns the same way) |
| **L2 metrics** | Standard metrics queries | Same queries; Teradata views use `HELP COLUMN` path for column list via `is_temporary_table` flag on `TableContext` |
| **L3 row / cell / hybrid** | Standard | Same queries; `object_type` carried on `TableContext` and DEA payloads |
| **Partitioning** | Supported | Supported — `columnNamesToPartitionBy` (including multi-column lex) and partition sizing work the same way |

### Key implementation notes

- **`object_type` propagation**: Workflow JSON → `ValidationTableConfiguration` → Snowflake config → handlers read `table_config.get("object_type", "TABLE")` → `DEAPayloadFactory` → DEA payload → SDV `ObjectType` enum.
- **`is_temporary_table` flag**: For **Teradata + VIEW** only, `_needs_temporary_table_flag()` sets `is_temporary_table=True` on `TableContext`. This steers Jinja templates (`teradata_table_metadata_query.sql.j2`, `teradata_get_columns_metadata.sql.j2`) to use `HELP COLUMN` instead of `DBC` catalog paths. Cloud DV does **not** materialize views into temp tables; the flag is reused solely for metadata extraction routing. Oracle views do **not** set this flag — `ALL_TAB_COLUMNS` handles both tables and views identically.
- **Local SDV (`snowflake-data-validation` CLI / IPC)**: For **Teradata**, **Redshift**, and **PostgreSQL** sources, `platform_skips_view_materialization()` skips `CREATE TABLE … AS SELECT` view materialization so validation uses the view FQN, consistent with cloud DV. Other source platforms still materialize views locally before L1/L2/L3.
- **Basic schema validation**: When `is_temporary_table` is set in the DEA L1 handler, schema validation runs with `basic_validation=True`, which limits comparison to `BASIC_SCHEMA_VALIDATION_FIELDS` (column existence and datatype).

## User-facing reference

The public **README.md** documents the JSON fields and defaults (including partitioning, views, and `use_snowpipe_for_results`). Example files live at `docs/public/example-workflows/`, including `example-data-validation-workflow.json` (tables) and `example-data-validation-view-workflow.json` (views).
