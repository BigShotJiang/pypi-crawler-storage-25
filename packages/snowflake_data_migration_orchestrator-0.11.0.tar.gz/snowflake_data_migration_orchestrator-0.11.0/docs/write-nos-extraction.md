# Teradata Native Object Store (`WRITE_NOS`) Extraction

This document describes the end-to-end `WRITE_NOS` extraction path: how the orchestrator
builds tasks that reference cloud-relative paths, how the data exchange agent (DEA)
executes Teradata `WRITE_NOS` over ODBC (writing Parquet to object storage), and how
Snowflake loads those files via an **external stage** that maps to the same bucket prefix.

See also: [TPT extraction](./tpt-extraction.md) for the worker-local Teradata Parallel
Transporter path; [Teradata ODBC (`regular`)](./teradata-odbc-extraction.md) for the default
internal-stage extraction path.

## Overview

`WRITE_NOS` is a Teradata extraction strategy alongside `regular` (internal stage,
including optional worker-side TPT when `tpt_*` is set in the DEA config). Trade-offs:

| Strategy   | Where data flows | Pros | Cons |
|------------|------------------|------|------|
| `regular`  | Teradata → DEA → Parquet → Snowflake internal stage (ODBC/`teradatasql`, or `tbuild` when configured) | No `externalStage` in workflow | Through DEA unless `write_nos` |
| `write_nos`| Teradata → cloud storage (Parquet) → Snowflake **external** stage | Server-side export, no bulk upload through DEA | Requires NOS + aligned bucket, Snowflake stage / IAM |

## Pre-requisites

1. **Teradata**: Native Object Store (`WRITE_NOS`) available on the cluster, plus a valid
   credential mode for cloud write access (inline keys, function mapping, or named
   `AUTHORIZATION` — see DEA `WriteNosConfig`).
2. **Object storage**: Bucket/container/path that Teradata can write to **must match** what
   the Snowflake external stage will read (same account/region/prefix expectations as your
   cloud design).
3. **DEA `WriteNosConfig`** in the TOML: `write_nos_location_scheme` and `write_nos_location_host`
   are required; `write_nos_location_container` is optional (omit when the Snowflake stage URL
   is the bucket root so Teradata writes `task_results/...` directly under that root). Plus one
   credential mode.

   ```toml
   [connections.source.teradata]
   host     = "td-host"
   username = "user"
   password = "pwd"
   database = "mydb"

   write_nos_location_scheme    = "/s3/"
   write_nos_location_host      = "my-bucket.s3.us-west-2.amazonaws.com"
   # Optional prefix inside the bucket (omit when stage URL is s3://my-bucket/):
   # write_nos_location_container = "my-prefix"

   # Exactly one credential mode (examples — use secrets management in production):
   # write_nos_access_id / write_nos_access_key
   # write_nos_function_mapping = "nos_util.WRITE_NOS_FM"
   # write_nos_authorization_name = "nos_util.DefAuth_Write"

   write_nos_stored_as       = "PARQUET"
   write_nos_compression     = "SNAPPY"
   write_nos_max_object_size = "16MB"
   write_nos_overwrite       = "TRUE"
   ```

4. **Workflow JSON**: `extraction.strategy = "write_nos"` and a three-part
   **`externalStage`** (required). The stage must point at the same object-store location
   Teradata writes to. Do **not** set `externalStageUrl` or `externalStageStorageIntegration`
5. **Snowflake**: The role used by the orchestrator typically needs `USAGE` on the storage
   integration backing the external stage; in AWS, the integration’s IAM role must trust
   Snowflake’s IAM principal (**storage integration docs**). Typical Snowflake errors when
   misaligned include **002003** (integration access) and **003167** (`sts:AssumeRole`).

## Sequence diagram

```mermaid
sequenceDiagram
    autonumber
    participant U as User / workflow JSON
    participant O as Data migration orchestrator
    participant DB as Snowflake (control DB)
    participant DEA as Data exchange agent (worker)
    participant TD as Teradata
    participant OBJ as Cloud object storage (S3 / Azure / GCS)
    participant EXT as Snowflake external stage
    participant TGT as Snowflake target table

    U->>O: extraction_strategy = "write_nos", externalStage set
    O->>O: TaskChainCreator builds DataMovementTaskPayload
    Note over O: target_type = WRITE_NOS<br/>target_id = relative cloud path
    O->>DB: Push extraction task
    DB-->>DEA: Pull next task

    DEA->>DEA: Build WRITE_NOS SQL (location + SELECT from payload)
    DEA->>TD: EXEC WRITE_NOS via ODBC
    TD->>OBJ: Write Parquet under bucket prefix

    DEA->>DB: complete_task (no PUT to internal stage)

    DB-->>O: Chain continues (preprocess / load)
    O->>EXT: COPY / staged reads from @externalStage/.../same prefix...
    EXT->>OBJ: Read objects via STORAGE INTEGRATION
    O->>TGT: Load into target table
```

## Task contract

| Field | `WRITE_NOS` value | Notes |
|-------|-------------------|-------|
| `target_type` | `write_nos` | Routes DEA to `WriteNosDataSource`; wraps `statement_location_id` in `WRITE_NOS`. |
| `target_id` | Relative path under the object-store root Teradata uses (no `@stage` prefix) | Combined with DEA `write_nos_location_*` into a full `LOCATION` for Teradata. Same logical prefix as orchestrator paths under the workflow table metadata ID. |
| `extraction_strategy` | `write_nos` | Optional telemetry field on the payload. |
| `statement_location_id` | Partition-aware `SELECT` from `TeradataQueryBuilder` | Type-aware casts. |
| `suggested_batch_size` | `null` | File sizing is driven by Teradata (`max_object_size` in `WriteNosConfig`), not the orchestrator batch hint. |
| `is_bulk_operation` | `true` | |

## Code map

### Orchestrator

- `data_migration_cloud/config/extraction_strategy.py` — `ExtractionStrategy.WRITE_NOS`
- `data_migration_cloud/config/configuration_parser.py` — `write_nos` requires `externalStage`
- `data_migration_cloud/config/extraction_stage_validation.py` — hints for **002003** / **003167** on external stage access
- `data_migration_cloud/platforms/teradata/platform.py` — `WRITE_NOS` in `supported_strategies`
- `data_migration_cloud/tasks/models/task_payload.py` — `TargetType.WRITE_NOS`
- `data_migration_cloud/tasks/task_chain_creator.py` — `relative_path_for_partition_data`,
  `TargetType.WRITE_NOS`, `suggested_batch_size = None`
- `data_migration_cloud/utils/stage_utils.py` — `resolve_stage_for_strategy` for
  `externalStage` precedence
- `data_migration_cloud/tasks/handlers/staged_data_handler.py` — ensure target schema, then
  file-type / load from `@externalStage/...`
- `data_migration_cloud/tasks/handlers/smart_partition_config_resolver.py` — Teradata
  `WRITE_NOS` partition profile
- `utils/snowflake_schema.py` — `validate_external_stage_exists`, `parse_external_stage_three_part_name`

### Data exchange agent

- `constants/data_source_types.py` — `DataSourceType.WRITE_NOS`
- `constants/task_keys.py` — `TargetTypeValues.WRITE_NOS`
- `config/sections/connections/odbc/teradata.py` — `WriteNosConfig`, `build_write_nos_query`
- `data_sources/write_nos_data_source.py` — executes `WRITE_NOS` SQL; redacts
  `AUTHORIZATION(...)` in logs
- `tasks/manager.py` — `WRITE_NOS` branch; **skips** Snowflake `PUT` (same class of skip as
  Redshift `UNLOAD` to S3)
- `tasks/task.py` / `task_sources/snowflake_stored_procedure.py` — forward
  `extraction_strategy` from payload

## Failure modes

- **DEA / Teradata**
  - Missing `write_nos_location_scheme` / `host` (or no `write_nos_config`) → `ValueError` from
    `_prepare_write_nos_statement` (see DEA error text).
  - `WRITE_NOS` SQL or NOS policy errors from Teradata → surfaced on `cursor.execute`;
    check Teradata logs and `LOCATION` / credentials mode.
  - `overwrite` vs manifest constraints: `WriteNosConfig` may emit SQL that trades off
    `OVERWRITE` and manifest options when Teradata rules conflict (see class docstring in
    `teradata.py`).
- **Snowflake (load phase)**
  - **002003** — storage integration missing or role lacks `USAGE ON INTEGRATION`.
  - **003167** — AWS denied `sts:AssumeRole` for the IAM role on the integration; fix trust
    policy / external ID alignment with `DESC INTEGRATION`.

## Why no `PUT` from the DEA?

Teradata writes Parquet **directly** to object storage. The DEA only issues the `WRITE_NOS`
statement and completes the task; the orchestrator load path reads via the **external
stage**, same as other cloud-direct strategies (`UNLOAD` to S3 does not re-upload through
the agent either).
