# L3 early stopping (engineering notes)

This document describes how **L3 early stopping** works in the data-migration orchestrator: configuration, the periodical poll task, how it differs by **row / cell / hybrid** mode, and how **Snowpipe vs COPY-based** result loading changes behavior.

## Purpose

When enabled, the workflow pushes an orchestrator task that **periodically** checks how many **L3 mismatch rows** have already landed in Snowflake result tables for the table/workflow. If the count reaches a configured threshold, the orchestrator **bulk-completes** pending L3 work items (so the graph can converge without running every partition) and stops polling. If the count stays below the threshold, the poll **reschedules** itself after a configured interval (using `NEXT_ELIGIBLE_AT` via `RESCHEDULE_PERIODICAL_TASK`).

Early stopping is **optional** for `row` / `cell` modes and **mandatory** for `hybrid` mode (the configuration parser rejects `row_validation_mode=hybrid` when `early_stopping` is not enabled).

## Configuration

Resolved in `data_validation_cloud/config/validation_configuration_parser.py` (`_resolve_early_stopping_fields`) and surfaced on each table’s SDV dict from `validation_table_configuration.py`.

| Setting | Meaning |
|--------|---------|
| `early_stopping` | Master switch (per table or global `validationConfiguration`). |
| `early_stop_mismatch_row_threshold` | Minimum mismatch **row count** in the appropriate results table to trigger a bulk skip. |
| `early_stop_check_interval_minutes` | Minutes between poll ticks when below threshold. |

If `early_stopping` is true but either number is missing, configuration parsing **raises** (`ValidationConfigurationError`). The parser also raises when `row_validation_mode=hybrid` is requested with `early_stopping=false` (per-table or global).

Structural schema: `workflow_configuration_schema.py` (`ValidationConfiguration` / per-table `validationConfiguration`).

## Task queue artifacts

### Poll task

- **Pushed by:** `maybe_push_l3_early_stop_poll` in `data_validation_cloud/tasks/handlers/l3_early_stop_poll_handler.py`, invoked when L3 chains are created (see below). Always pushed with a non-`None` `anchor_task_id` — callers that cannot supply one cannot enable early stopping.
- **Scope:** `DV::Table[<source_identifier>]::L3EarlyStopMonitor` (`build_l3_early_stop_monitor_scope` in `data_validation_cloud/scope.py`).
- **Payload:** `L3EarlyStopPollPayload` in `data_validation_cloud/tasks/models/task_payload.py`.
- **Handler:** `L3EarlyStopPollHandler` (registered in `task_handler_factory.py`).
- **Requirements:** `TableTaskQueue` must implement `skip_all_dv_l3_candidate_tasks`, `reschedule_periodical_task`, and (after a successful skip) `unblock_tasks`.

### Bulk skip stored procedure

`SKIP_ALL_DV_L3_CANDIDATE_TASKS` (`assets/scripts/task-queue/procedures/skip_all_dv_l3_candidate_tasks.sql.j2`):

- Completes **pending** tasks for a single `workflow_id` whose `SCOPE` matches one or two `LIKE` patterns (with `ESCAPE '\'`).
- **Pattern 1 (always):** partition **RowValidation** — `build_l3_early_stop_skip_scope_like_pattern` → `DV::Table[<escaped id>]::Partition%::RowValidation`.
- **Pattern 2 (non-Snowpipe L3 only in the poll handler):** partition **WriteResults[row]** — `build_l3_early_stop_skip_write_results_row_pattern` → `DV::Table[<escaped id>]::Partition%::WriteResults[row]`.
- If any rows were updated and `p_unblock_if_ready_task_id` is not null, calls **`TRY_UNBLOCK_TASK`** (`try_unblock_task.sql.j2`) for that single task id (same readiness rules as the first branch of `UNBLOCK_TASKS`, scoped by workflow).

Python loops the `CALL` until the procedure returns **0** rows skipped (`table_task_queue.py` — successor fan-out can require multiple rounds).

### After a non-zero skip

`L3EarlyStopPollHandler` calls **`unblock_tasks()`** (full `UNBLOCK_TASKS` procedure) when `skipped > 0`, so dependency edges beyond the single `TRY_UNBLOCK_TASK` hint can still be reconciled. That is intentional in the current code path.

## Poll handler logic (high level)

1. **Stop polling (complete poll task, no reschedule)** when the anchor task is **terminal**: `TASK_QUEUE.STATUS` is `completed` / `failed` / `abandoned`, or the row is missing entirely. The payload requires a non-`None` `anchor_task_id`; the handler raises if it ever encounters one without it.

2. **Mismatch count:** `SELECT COUNT(*) FROM <results_fqn> WHERE WORKFLOW_ID = ? AND TABLE_METADATA_ID = ?`
   - **Row mode** *and* **hybrid mode:** `ROW_VALIDATION_RESULTS` (via `fq_row_validation_results()`).
   - **Cell mode:** `CELL_VALIDATION_RESULTS` (via `fq_cell_validation_results()`).

   Hybrid intentionally counts **only** row-hash mismatches. The cell drill-down phase that follows hybrid does not contribute to the threshold.

3. **If count ≥ threshold:** build scope pattern(s), call `skip_all_dv_l3_candidate_tasks`, optionally `unblock_tasks()`, then **complete** the poll task (no further reschedules).

4. **If count < threshold:** `reschedule_periodical_task` for `early_stop_check_interval_minutes`.

## Interaction with L3 modes

### Standard L3 row and cell (`EvaluateLevelResultHandler._push_row_chain`)

Single **table-level** `source_identifier`, one **Evaluate L3** task shared by all partitions, chains:

- **DEA** partition task → (Snowpipe entry **or** **Write** orchestrator task) → … → **Evaluate**.

`maybe_push_l3_early_stop_poll` is called at the end of `_push_row_chain` with:

| | **Snowpipe** (`snowpipe_chain is not None`) | **Non-Snowpipe** |
|---|---------------------------------------------|------------------|
| `row_validation_mode` | `ROW` or `CELL` (effective mode) | Same |
| `anchor_task_id` | `snowpipe_chain.entry_task_id` (PrepareDvDrain / drain fan-in barrier) | `evaluate_task_id` |
| `use_snowpipe_for_results` | `True` | `False` |

**Meaning:**

- **Non-Snowpipe:** Polling stops when the **Evaluate** task is terminal; bulk skip passes **Evaluate** as `unblock_if_ready_task_id` and includes **both** RowValidation and WriteResults[row] `LIKE` patterns.
- **Snowpipe:** Polling stops when the **DEA fan-in barrier** task (`PrepareDvDrain` for multi-pipe levels, or the single `SnowpipeDrain` for single-pipe levels) reaches a terminal `TASK_QUEUE` status (or its row is missing) — even if downstream Snowpipe drains and Evaluate are still queued. By design: once the barrier is terminal, every L3 partition DEA task that fed it is already completed, so the bulk-skip target set (still **`pending`** rows under the **RowValidation** `LIKE` pattern only — no WriteResults pattern, since partition writes are replaced by the pipe/drain pipeline) is empty and further polling has nothing to skip.

### Hybrid (`HybridValidationHandler.push_hybrid_row_chain`)

Hybrid uses **one per-table Evaluate L3** task (anchor) + **one per-table row Snowpipe chain** (or per-partition `WriteResults[row]` for non-Snowpipe), wired so every row-hash DEA fans into the per-table Evaluate task — directly (non-Snowpipe) or through `PrepareDvDrain` ⇒ row drains (Snowpipe). The poll uses:

| | **Snowpipe** (`use_snowpipe_for_results=true`) | **Non-Snowpipe** |
|---|------------------------------------------------|------------------|
| `row_validation_mode` | `HYBRID` | `HYBRID` |
| `anchor_task_id` | per-table `Evaluate L3` task id | per-table `Evaluate L3` task id |
| `use_snowpipe_for_results` | `True` (skip pattern: RowValidation only) | `False` (skip patterns: RowValidation + WriteResults[row]) |

When the row-hash phase is done (anchor `Evaluate L3` runs):

1. The Evaluate handler queries `ROW_VALIDATION_RESULTS` for the table for partitions whose `RESULT = 'FAILURE'` (row present on both sides but hashes disagree). `NOT_FOUND_*` and `DUPLICATE_*` rows are intentionally excluded — there is no opposite-side row to compare cell-by-cell against, and duplicate keys cannot be unambiguously paired.
2. If there are mismatched partitions, it pushes one cell DEA per such partition (narrowed to the failed row keys via `_narrow_hybrid_cell_where_to_md5_failures`), wired into a **per-table cell `CELL_DIFFS` Snowpipe drain** (or per-partition `WriteResults[row]` chain for non-Snowpipe) whose successor is a single per-table `FinalizeHybridL3` task.
3. `FinalizeHybridL3` reads `CELL_VALIDATION_RESULTS` for the table, sets `L3_STATUS` for every partition via `bulk_set_partition_level_status`, and marks the table `COMPLETED` (zero diffs) or `FAILED` (any diffs) via `UPDATE_TABLE_VALIDATION_STATUS`.
4. If there are **no** mismatched partitions, the Evaluate handler runs the finalize logic inline (no extra task) — `L3_STATUS=valid`, table `COMPLETED`.

The early-stop poll completes when the per-table Evaluate task is terminal, i.e. once the row-hash phase has converged (every partition either drained or skipped). The cell drill-down tasks are **not** counted toward the early-stop threshold.

## Related docs and code

- Broader DV pipeline (Snowpipe vs COPY, result tables): `docs/data-validation-workflow.md`.
- Snowpipe-based result loading (per-table pipe naming, drain barriers, **pipe-wide** `SYSTEM$PIPE_STATUS` completion when many partitions share one pipe): `docs/snowpipe-data-validation.md`.
- Scope string patterns: `docs/scopes.md`.
- Pull / periodical eligibility (`NEXT_ELIGIBLE_AT`): task-queue procedures under `assets/scripts/task-queue/procedures/` (e.g. `pull_single_task.sql.j2`, `reschedule_periodical_task.sql.j2`).

## Caveats

- Scope `LIKE` builders and behavior across all L3 variants are still marked **WIP** in code comments (`scope.py`, `skip_all_dv_l3_candidate_tasks.sql.j2`); treat edge cases (special characters in table identifiers, unusual hybrid/Snowpipe mixes) as needing validation in real workflows.
