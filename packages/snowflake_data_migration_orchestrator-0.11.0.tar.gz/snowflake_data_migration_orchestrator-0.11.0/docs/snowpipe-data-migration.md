# Snowpipe in Data Migration

This note documents how Snowpipe is used by the data migration workflow, what
tasks are added, how to configure it, and the main trade-offs.

## Scope

This applies to table migrations that opt into:

```json
{
  "loading": {
    "strategy": "snowpipe"
  }
}
```

When this setting is omitted, migration uses the default warehouse `COPY INTO`
task flow.

## What Changes in the Task Flow

Snowpipe support adds three behaviors for each table configured with
`loading.strategy = "snowpipe"`:

1. A **Setup Snowpipe** task that creates the pipe definition.
2. A **Snowpipe refresh/monitor** task per partition load, instead of emitting
   warehouse `COPY INTO` tasks.
3. A **Teardown Snowpipe** cleanup task that drops the pipe at workflow end.

### Setup Snowpipe

- Task kind: `SETUP_SNOWPIPE` (orchestrator executor).
- Handler behavior:
  - Reads extracted schema from stage.
  - Resolves type mappings from workflow/table metadata.
  - Runs idempotent `CREATE TABLE IF NOT EXISTS` for the target.
  - Runs `CREATE PIPE IF NOT EXISTS ... AS COPY INTO <target>`.
  - Sets `LOG_EVENT_LEVEL = DEBUG` on the pipe.
- Why this exists: avoid the race where `CREATE PIPE ... AS COPY INTO <target>`
  runs before the target table exists.

For **new tables**, setup is queued by partition-strategy handling (after schema
extraction is available).  
For **incremental tables with existing metadata**, setup can be queued during
workflow initialization.

### Per-partition ingestion

When `PROCESS_STAGED_DATA` runs for a Snowpipe table, the orchestrator:

- Computes the table pipe name (`DMO_PIPE_<WORKFLOW_ID>_<TABLE>` in `TEMP`).
- Calls `ALTER PIPE <pipe> REFRESH PREFIX='<partition-prefix>/'`.
- Pushes a `SNOWPIPE` task (payload kind `snowpipe_ingestion`, mode `prefix`)
  to monitor ingestion completion.

So the partition no longer creates warehouse `COPY INTO` tasks directly; it
triggers pipe refresh and waits for Snowpipe monitoring to mark completion.

### Teardown Snowpipe

- Task kind: `TEARDOWN_SNOWPIPE` (orchestrator executor, cleanup task).
- Runs `DROP PIPE IF EXISTS <pipe>`.
- Scheduled so cleanup runs even when the workflow has failures.

## Monitoring Model

Data migration Snowpipe tasks use **prefix mode** monitoring:

- The queue polls file lifecycle events from the configured event table.
- It filters by short pipe name + stage path prefix.
- Completion: all relevant files are ingested.
- Failure: any relevant file reaches `ERRORED`.

This is why migration setup enables `LOG_EVENT_LEVEL = DEBUG` on DMO pipes.

## Required Configuration and Prerequisites

### Workflow configuration

- Per table, set `loading.strategy` to `"snowpipe"` to enable this mode.
- Other tables in the same workflow can still use default warehouse loading.

### Snowflake prerequisites

- The orchestrator configures a database-scoped event table before running any
  Snowpipe migration table.
- If `ALTER DATABASE ... SET EVENT_TABLE = ...` is not supported in the account,
  Snowpipe migration fails fast with guidance to avoid Snowpipe loading.

### Pipe behavior

- Pipes are created with `AUTO_INGEST = FALSE`.
- Refresh is explicit (`ALTER PIPE ... REFRESH PREFIX=...`) per partition.
- Pipe `FROM` points at the table-level `.../data/` stage path so every
  partition path is refreshable via prefix.

## Trade-offs

### Benefits

- Reduces direct warehouse `COPY INTO` task fan-out in orchestrator flow.
- Keeps ingestion idempotent with explicit refresh boundaries per partition.
- Moves load progression tracking into Snowpipe lifecycle state/events.

### Costs / caveats

- Requires event-table support for migration monitoring.
- Adds Snowpipe object lifecycle management (setup + teardown).
- Introduces polling/event-lag behavior before tasks can be marked complete.
- Marked experimental in workflow configuration reference.
