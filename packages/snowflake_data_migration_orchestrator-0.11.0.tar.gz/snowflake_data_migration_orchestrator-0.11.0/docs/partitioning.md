# Partitioning

This guide explains how **range partitioning** works in **Data Migration (DM)** and **Data Validation (DV)**: configuration, boundary discovery, what is stored in metadata, **edge partitions**, **multi-column lexicographic** keys, and how filters are applied.

For partition **count sizing** (target MB/rows, internal caps, platform defaults), see [partition-sizing.md](partition-sizing.md).

## Overview

Partition columns are configured as an **ordered list** in workflow JSON:

| Workflow | Field name |
|----------|------------|
| Data Migration | `columnNamesToPartitionBy` on each table entry |
| Data Validation | `column_names_to_partition_by` on each table/view entry |

The orchestrator sorts and splits data using **lexicographic** order on those columns (left-to-right). A single column uses ordinary scalar comparisons; two or more columns use **tuple** semantics (compare the first column, then the second on ties, and so on).

DM and DV share:

- The same **partition count** calculator (`PartitionCalculator`)
- **NTILE**-based boundary discovery
- The same **interval rules** for interior buckets (`[L, H)` and closed top on the last interior)
- The same **multi-column bound encoding** in `PARTITION_METADATA`

They differ in **where** boundaries are measured and **whether edge partitions exist**:

| | Data Migration | Data Validation |
|--|----------------|-----------------|
| Boundary query runs on | **Source** (via Data Exchange Agent / platform SQL) | **Snowflake target** table |
| Rows in metadata | **N + 2** (lower edge, N interiors, upper edge) | **N** (NTILE buckets only) |
| Work per partition | Extract → stage → `COPY INTO` | L2 metrics / L3 row or cell comparison with scoped `WHERE` |

```mermaid
flowchart TB
  config["columnNamesToPartitionBy"]
  calc["PartitionCalculator: N buckets"]
  ntile["NTILE boundary query"]
  meta["PARTITION_METADATA MIN_VALUE MAX_VALUE"]
  config --> calc --> ntile --> meta
  meta --> dm["DM: extraction WHERE per partition incl. edges"]
  meta --> dv["DV: scoped WHERE for L2/L3 interiors only"]
```

## Configuration

### Partition columns

```json
"columnNamesToPartitionBy": ["ss_sold_date_sk", "ss_item_sk"]
```

- Order matters: `["year", "month"]` means `ORDER BY year, month`.
- If omitted or empty, the table is treated as a **single partition** (full scan). For large tables without partition columns, DM logs a warning and still migrates as one unit.

### Partition size (optional)

| Field | Description |
|-------|-------------|
| `targetPartitionSizeMb` | Desired megabytes per partition |
| `targetPartitionSizeRows` | Desired rows per partition |

Only **one** of the two may be set per table. When both are omitted, **auto** sizing applies (DV defaults to ~200 MB per partition; DM uses platform-tuned targets — see [partition-sizing.md](partition-sizing.md)).

## How many partitions?

1. Compute **target rows per partition** from `targetPartitionSizeRows`, or from `targetPartitionSizeMb / average_row_mb`, or fall back when neither is set.
2. Apply **internal caps** (especially in DV: max rows, max MB, max cells per partition).
3. **Partition count** `N = ceil(row_count / effective_rows_per_partition)`, or `1` when the whole table fits in one bucket.

## Boundary discovery

After `N` is known, the orchestrator runs an **NTILE(N)** query:

```sql
NTILE(N) OVER (ORDER BY col1, col2, ...)
```

For each `partition_id` (bucket), it records:

| Columns | What is stored per bucket |
|---------|---------------------------|
| **One** | `MIN(col)`, `MAX(col)` |
| **Two or more** | Lexicographic **first row** and **last row** in the bucket (per-column `min_0`…`min_n`, `max_0`…`max_n` in SQL), then **encoded** into one string for metadata |

Buckets are assumed **contiguous** in sort order: the upper bound of bucket *i* aligns with the start of bucket *i+1*, so interior intervals use half-open ranges `[L, H)` without gaps.

### Large tables (sampling)

When `row_count >= 100_000_000`, boundary discovery uses a random sample of about **20_000_000** rows before NTILE (single- and multi-column):

| Path | Mechanism |
|------|-----------|
| DV (Snowflake target) | `SAMPLE BERNOULLI` |
| DM (Redshift source) | `WHERE RANDOM() < rate` in a `sampled` CTE |

Sampled boundaries are **approximate**. Row counts per partition in metadata may be scaled back to full-table estimates after sampling.

Implementation: `data_migration_cloud/partition/partition_range.py`, platform `build_partition_boundary_query`, DV `GenerateValidationQueriesHandler._build_partition_boundary_query`.

## What is stored in `PARTITION_METADATA`

Each row has:

| Column | Meaning |
|--------|---------|
| `PARTITION_NUMBER` | Bucket id (see [Edge partitions](#edge-partitions) for DM numbering) |
| `MIN_VALUE` | Lower bound (VARIANT) |
| `MAX_VALUE` | Upper bound (VARIANT) |
| `N_ROWS` | Estimated or observed rows in the bucket |

### Bound encoding

- **One partition column**: scalar value (number, string, date, etc.).
- **Two or more columns**: a single string with components joined by the ASCII **unit separator** (`\x1f`), in config order. Delimiter characters inside string components are escaped with backslash.

Example for `["year", "month"]` with bounds `(2020, 3)` and `(2020, 5)`:

- Stored min: `2020` + `\x1f` + `3` (one VARIANT string)
- Not a VARIANT object/array — always a delimited string for 2+ columns

When Snowflake returns VARIANT values to Python, the string may appear JSON-quoted with `\u001f` escapes; `decode_partition_bound` normalizes that before splitting.

## Interval semantics (shared)

These rules apply when building `WHERE` clauses from stored bounds (DM extraction, DV L2/L3 scoped filters).

| Partition kind | `MIN_VALUE` | `MAX_VALUE` | SQL filter (conceptual) |
|----------------|-------------|-------------|-------------------------|
| **Lower edge** | `NULL` | first observed key `L_first` | `key < L_first` |
| **Interior** (not last) | `L` | `H` | `key >= L` AND `key < H` |
| **Last interior** | `L` | `H` | `key >= L` AND `key <= H` |
| **Upper edge** | last observed key `H_last` | `NULL` | `key > H_last` |

For **multi-column** keys, `key` is a lexicographic tuple. SQL is expanded to the standard form (strict inequalities on prefix columns, `>=` / `<=` on the last compared column), for example:

```text
(c1 > a) OR (c1 = a AND c2 >= b) OR ...
```

DV applies the same rules in `data_validation_cloud/utils/partition_where.py` (`build_scoped_partition_where`). The **last interior** bucket is detected by `infer_boundary_flags` (largest `PARTITION_NUMBER` with both min and max set).

## Edge partitions

Edge partitions cover rows **outside** the min/max range observed during boundary analysis (for example keys below the sample’s smallest tuple or above the largest).

### Data Migration

`PartitionBoundaryGenerator.generate_boundaries` takes **N** NTILE results and produces **N + 2** partitions:

```text
  Partition 0          Partitions 1 … N           Partition N+1
  (lower edge)         (NTILE interiors)          (upper edge)
       |-------------------|------------------------|
  key < L_first    L_i <= key < H_i (last closed)   key > H_last
```

| `PARTITION_NUMBER` | Role | Typical `MIN_VALUE` / `MAX_VALUE` |
|--------------------|------|-----------------------------------|
| `0` | Lower edge | `NULL` / `L_first` |
| `1` … `N` | NTILE buckets | both set |
| `N + 1` | Upper edge | `H_last` / `NULL` |

Each partition gets its own extract → load chain. Edge partitions may show `N_ROWS = 0` in the boundary query result but still receive extraction tasks so **no rows are left unmigrated**.

Handlers: `partition_strategy_handler` → analyze boundaries on **source** → `create_partition_tasks_handler` → `generate_boundaries` → bulk insert into migration `PARTITION_METADATA`.

### Data Validation

DV **does not** create edge partition rows. `generate_validation_queries_handler._create_partition_metadata` inserts **only** the **N** NTILE buckets (typically `PARTITION_NUMBER` 1 through N), each with **both** `MIN_VALUE` and `MAX_VALUE`.

Implications:

- L2/L3 validation runs only on **interior-style** ranges derived from those buckets.
- Rows with partition keys **below** the global minimum or **above** the global maximum observed during boundary discovery are **not** included in any validation partition. This is intentional: validation focuses on the NTILE-covered key range, not the full real line.

Boundary NTILE runs on the **Snowflake target** table (with optional `target_where_clause`), not on the source.

## Multi-column (lexicographic) partitioning

### Sort order

Config order is SQL order:

```json
"columnNamesToPartitionBy": ["year", "month", "day"]
```

→ `ORDER BY year, month, day` in NTILE and in all partition filters.

### Example

Table keyed by `(year, month)`:

| year | month | NTILE bucket |
|------|-------|--------------|
| 2019 | 12 | 1 |
| 2020 | 1 | 2 |
| 2020 | 2 | 2 |
| 2021 | 1 | 3 |

Interior bucket 2 might store encoded min `2020\x1f1` and max `2020\x1f2` (conceptually). The generated `WHERE` clause enforces lex ranges, not independent `MIN(year)` / `MAX(month)` per column.

### Escaping

If a string component contains the unit separator, it is escaped on encode and unescaped on decode (`partition_range.py`).

### Limitations (current behavior)

- **NULL** partition keys: not specially handled; boundary rows with NULL components can fail normalization or produce incomplete bounds.
- **Ties** at bucket boundaries: NTILE assigns ties arbitrarily; adjacent buckets still use half-open intervals assuming contiguous sort order.
- **Very high N** (hundreds of thousands of partitions): sampling reduces scan cost, but NTILE over many buckets on the sample remains expensive.

## Data Migration workflow

1. **`determine_partition_strategy`** — Reads staged table metadata, runs `PartitionCalculator`, decides whether to partition. Warns if the table is large but `columnNamesToPartitionBy` is empty.
2. **Analyze boundaries** — Pushes a Data Exchange Agent task that runs the platform boundary query on the **source** and writes results to a stage.
3. **`create_partition_tasks`** — Reads boundaries from the stage, calls `PartitionBoundaryGenerator.generate_boundaries` (adds edges), bulk-inserts **N + 2** rows into `PARTITION_METADATA`, creates one extraction/load chain per partition.
4. **Incremental sync** — When reusing metadata, `infer_boundary_flags` and `generate_single_boundary` rebuild `WHERE` clauses from stored min/max (including edge rows with one null bound).

Related: [incremental-sync.md](incremental-sync.md) (checksum / watermark strategies are orthogonal to partitioning).

## Data Validation workflow

1. **`generate_validation_queries`** — After L1 setup, `_create_partition_metadata` runs the NTILE boundary query on the **target**, normalizes rows (`normalize_ntile_boundary_row`), inserts **N** partition rows with `VALIDATION_STATUS = PENDING`.
2. **L1 (schema)** — Whole table; no partition filter.
3. **L2 (metrics) / L3 (row, cell, hybrid)** — `evaluate_level_result_handler` loads partitions via `GET_PARTITION_METADATA`, builds `partition_where_clauses` with `build_scoped_partition_where` (source + target), and passes `source_where_clause` / `target_where_clause` on Data Exchange Agent payloads.
4. **Last interior** — The bucket with the largest `PARTITION_NUMBER` that has both min and max uses a **closed** top (`<= H`); others use `< H`.

Related: [data-validation-workflow.md](data-validation-workflow.md), [l3-early-stopping.md](l3-early-stopping.md).

## Code map

| Concern | Module |
|---------|--------|
| Encode / decode bounds, lex SQL | `data_migration_cloud/partition/partition_range.py` |
| DM edge + interior WHERE | `data_migration_cloud/tasks/handlers/partition_boundary_generator.py` |
| DM boundary SQL per platform | `data_migration_cloud/platforms/*/query_builder.py` |
| DV boundary SQL (Snowflake) | `data_validation_cloud/tasks/handlers/generate_validation_queries_handler.py` |
| DV scoped WHERE | `data_validation_cloud/utils/partition_where.py` |
| Partition count | `data_migration_cloud/tasks/handlers/partition_calculator.py` |
| Bulk metadata insert | `utils/partition_metadata_bulk_sql.py` |
