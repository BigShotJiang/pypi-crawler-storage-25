# Teradata Parallel Transporter (TPT) Extraction

This document describes the end-to-end TPT extraction path: how the orchestrator
emits regular internal-stage extraction tasks for Teradata, how the data exchange
agent (DEA) chooses `tbuild` when `tpt_*` is configured, and how the resulting
Parquet files are loaded into Snowflake.

See also: [Teradata `WRITE_NOS` extraction](./write-nos-extraction.md) for the
server-side export-to-object-store path; [Teradata ODBC (`regular`)](./teradata-odbc-extraction.md)
for the default ODBC / `teradatasql` path.

## Overview

TPT is a **worker-side** Teradata bulk export (same orchestrator extraction strategy
as `regular`). With `tpt_output_directory` (and related `tpt_*` keys) in the DEA
TOML, bulk tasks use `tbuild`; otherwise the worker uses ODBC / `teradatasql`.
Trade-offs vs other Teradata paths:

| Path | Where data flows | Pros | Cons |
|------|------------------|------|------|
| `regular` (no `tpt_*` on DEA) | Teradata → DEA (rows) → Parquet → Snowflake stage | Simplest, no TTU | Single-session ODBC-style path |
| `regular` (with `tpt_*` on DEA) | Teradata → DEA (`tbuild`) → CSV → Parquet → Snowflake stage | Parallel sessions on Teradata | Requires TTU (`tbuild`) on the worker |
| `write_nos`| Teradata → cloud storage (Parquet) → Snowflake external stage | Server-side export | Requires bucket + `externalStage` |

## Pre-requisites

1. **Teradata TTU on every DEA worker.** `tbuild` must be on `PATH`, or set
   `TPT_TBUILD_EXECUTABLE` to its absolute path.
2. **`TptConfig`** in the DEA TOML (`tpt_output_directory` enables TPT):

   ```toml
   [connections.source.teradata]
   host = "td-host"
   username = "user"
   password = "pwd"
   database = "mydb"
   tpt_output_directory = "/var/dea/tpt"
   tpt_delimiter        = "|"
   tpt_max_sessions     = 4
   tpt_charset          = "UTF8"
   tpt_log_directory    = "/var/log/dea/tpt"
   ```

3. **Workflow:** `extraction.strategy = "regular"` (or omit extraction; default is regular). Legacy `"tpt"` in JSON is accepted and treated as `"regular"`.

## Sequence diagram

```mermaid
sequenceDiagram
    autonumber
    participant U as User / workflow JSON
    participant O as Data migration orchestrator
    participant DB as Snowflake (control DB)
    participant DEA as Data exchange agent (worker)
    participant TD as Teradata
    participant FS as Worker disk
    participant ST as Snowflake internal stage
    participant TGT as Snowflake target table

    U->>O: extraction.strategy = "regular" (or legacy "tpt" → regular)
    O->>O: TaskChainCreator builds DataMovementTaskPayload
    Note over O: target_type = snowflake:stage<br/>target_id = internal stage path
    O->>DB: Push extraction task
    DB-->>DEA: Pull next task

    DEA->>DEA: Validate TptConfig (TaskManager)
    DEA->>TD: Probe SELECT ... WHERE 1=0 for column names
    TD-->>DEA: cursor.description

    DEA->>FS: Write TPT script (EXPORT + DATACONNECTOR)
    DEA->>DEA: subprocess.run(tbuild ...)
    DEA->>TD: TPT EXPORT (parallel sessions)
    TD-->>FS: Delimited text (results_folder/<base>.txt)

    DEA->>FS: PyArrow CSV to Parquet (<base>_001.parquet)
    DEA->>ST: PUT (upload target_type remapped to SNOWFLAKE_STAGE)
    DEA->>DB: complete_task

    DB-->>O: Notify chain
    O->>TGT: COPY INTO (unchanged)
```

## Task contract

| Field | Value | Notes |
|-------|-------|-------|
| `target_type` | `snowflake:stage` | Same as other `regular` bulk extractions. |
| `target_id` | Internal stage path (`@…/task_results/.../partition_N/`) | |
| `extraction_strategy` | `regular` | Legacy in-flight tasks may still show `tpt`. |
| `statement_location_id` | SELECT from `TeradataQueryBuilder` | Type-aware casts. |
| `is_bulk_operation` | `true` | Required for TPT path on the worker. |

DEA selects `TptDataSource` when `tpt_output_directory` is set on `[connections.source.teradata]` (and may still honor legacy `target_type = tpt` tasks).

## Code map

### Orchestrator

- `data_migration_cloud/config/extraction_strategy.py` — `ExtractionStrategy.REGULAR` (legacy `"tpt"` string maps here)
- `data_migration_cloud/platforms/teradata/platform.py` — `REGULAR`, `WRITE_NOS` in `supported_strategies`
- `data_migration_cloud/tasks/models/task_payload.py` — `TargetType.TPT` optional for legacy tasks; `extraction_strategy` on `DataMovementTaskPayload`
- `data_migration_cloud/tasks/task_chain_creator.py` — `regular` uses internal stage payloads
- `data_migration_cloud/tasks/handlers/smart_partition_config_resolver.py` — Teradata `REGULAR` auto profile (tuned for disk-backed bulk)

### Data exchange agent

- `constants/data_source_types.py` — `DataSourceType.TPT`
- `constants/task_keys.py` — `TargetTypeValues.TPT`, `EXTRACTION_STRATEGY`
- `config/sections/connections/odbc/teradata.py` — `TptConfig`
- `data_sources/tpt_data_source.py` — TPT job, `tbuild`, Parquet conversion
- `tasks/manager.py` — bulk resolver picks TPT when Teradata `TptConfig` is present; legacy `target_type=tpt` branch; upload uses `SNOWFLAKE_STAGE` for `StorageProvider`
- `tasks/task.py` / `task_sources/snowflake_stored_procedure.py` — forward `extraction_strategy` from payload

## Failure modes

- `tbuild` missing on PATH → clear `RuntimeError` with install / `TPT_TBUILD_EXECUTABLE` hint.
- Missing `tpt_output_directory` → `ValueError` from `_prepare_tpt_extraction`.
- Non-zero `tbuild` exit → `RuntimeError` with log directory path.
- Multi-byte delimiter → rejected at Parquet conversion (single-byte required for PyArrow CSV).

## Why delimited → Parquet on the worker?

The pipeline expects Parquet for `PUT` + `COPY INTO`. Converting on the DEA avoids changing the orchestrator load path.
