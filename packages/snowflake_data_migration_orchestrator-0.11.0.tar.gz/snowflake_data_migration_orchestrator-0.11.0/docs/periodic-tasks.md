# Periodic Tasks

A periodic task executes, then puts itself back into `pending` with a future eligibility timestamp so it runs again after a configured interval. This avoids spawning new task rows for each tick — a single row cycles between `executing` and `pending`.

## The `NEXT_ELIGIBLE_AT` Column

The `TASK_QUEUE` table has a nullable `NEXT_ELIGIBLE_AT TIMESTAMP_NTZ` column. The pull procedures (`PULL_SINGLE_TASK`, `PULL_MANY_TASKS`) filter on it:

```sql
AND (NEXT_ELIGIBLE_AT IS NULL OR NEXT_ELIGIBLE_AT <= :current_ts)
```

A task with `NEXT_ELIGIBLE_AT` in the future is invisible to all consumers until the clock catches up.

## Rescheduling

The `RESCHEDULE_PERIODICAL_TASK` stored procedure transitions a task from `executing` back to `pending`:

```sql
UPDATE TASK_QUEUE
SET
    STATUS = 'pending',
    LEASED_TO = NULL,
    LEASING_TIME = NULL,
    END_TIME = NULL,
    NEXT_ELIGIBLE_AT = DATEADD('minute', :interval_minutes, SYSDATE())
WHERE ID = :task_id
    AND LEASED_TO = :consumer_id
    AND STATUS = 'executing';
```

The procedure validates that `interval_minutes >= 1` and that the caller actually holds the lease. It returns `FALSE` if the update matched zero rows (e.g., task was already completed or interval is invalid).

## Handler Decision Flow

On each tick, a periodic task handler must choose one of three outcomes:

1. **Complete** — the task's purpose is fulfilled (e.g., anchor task finished); call `complete_task`.
2. **Act and complete** — a threshold is met; perform a bulk action, then `complete_task`.
3. **Reschedule** — no action needed yet; call `reschedule_periodical_task` to sleep until the next tick.

If rescheduling fails (returns `FALSE`), the handler should fall back to completing the task to avoid a stuck `executing` row.

## Current Periodic Task: L3 Early-Stop Poll

The only periodic task today is the **L3 early-stop poll**, used during data validation to short-circuit remaining L3 partition checks when enough mismatches have already been found.

**Configuration** (per-table in the workflow JSON):

| Key | Description |
|-----|-------------|
| `early_stopping` | Enable the poll (`true`/`false`) |
| `early_stop_mismatch_row_threshold` | Number of mismatch rows that triggers early stop |
| `early_stop_check_interval_minutes` | Minutes between poll ticks |

**Tick logic** (`L3EarlyStopPollHandler.handle`):

1. Is the **anchor task** (the `Evaluate L3` task for this table) terminal? → **Complete** (no more work to monitor).
2. Count mismatch rows in the results table. If `count >= threshold` → bulk-skip all pending L3 candidate tasks for this table via `SKIP_ALL_DV_L3_CANDIDATE_TASKS`, then call `unblock_tasks` if any were skipped, then **complete**.
3. Otherwise → **reschedule** (set `NEXT_ELIGIBLE_AT` to `now + interval_minutes`).

The poll task is pushed as a regular (non-cleanup) `pending` task by `maybe_push_l3_early_stop_poll` when `early_stopping` is enabled. It runs on the orchestrator executor.

## Design Considerations

- **Single-row reuse.** The task row cycles between `executing` and `pending`, keeping the queue small and avoiding unbounded row creation for long-running polls.
- **Idempotent actions.** Poll actions (counting + bulk skip) are safe to retry or duplicate.
- **Graceful degradation.** If `RESCHEDULE_PERIODICAL_TASK` fails (e.g., lease lost), the handler completes the task rather than leaving it stuck in `executing`.
