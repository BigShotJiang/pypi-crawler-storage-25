# Snowpipe in Data Validation

This note documents how Snowpipe is used to ingest L2/L3 validation results,
which tasks are added, how to configure it, and key trade-offs.

## Configuration Switch

At workflow level:

```json
{
  "use_snowpipe_for_results": true
}
```

- Default is `true`.
- If set to `false`, the workflow falls back to the legacy per-partition
  warehouse `COPY INTO` result-loading flow.

## What Snowpipe Replaces

With Snowpipe enabled, partition tasks do not directly queue result-table
`COPY INTO` tasks. Instead, they:

1. Upload validation result files to internal stage paths.
2. Issue `ALTER PIPE ... REFRESH PREFIX='...'` for each result pipe attached to
   the partition payload.
3. Wait on drain barriers that unblock Evaluate only after all result pipes are
   drained.

## Pipes and Naming

DV uses **per-workflow, per-table, per-result-type** pipes in `TEMP`:

- Name pattern: `DVO_PIPE_<WORKFLOW_ID>_<TABLE_METADATA_ID>_<KEY>`
- Keys:
  - `METRICS`
  - `ROW_DIFFS`
  - `ROW_SUMMARY`
  - `CHUNK_HASHES`
  - `CELL_DIFFS`

Each key maps to a shared DV results table (`METRICS_VALIDATION_RESULTS`,
`ROW_VALIDATION_RESULTS`, `ROW_VALIDATION_SUMMARY`, `CHUNK_HASHES`,
`CELL_VALIDATION_RESULTS`) with key-specific `COPY INTO` column mapping.

Pipes watch the DV stage root and use a `PATTERN` regex scoped to that
workflow and table so concurrent workflows (and other tables in the same
workflow) do not ingest each other's files.

## Tasks Added by Snowpipe Mode

### Setup + Teardown lifecycle

Provisioning runs through `ensure_dv_pipe(...)`:

- Runs `CREATE PIPE IF NOT EXISTS` **synchronously** on first use of a
  `(workflow_id, table_metadata_id, key)` triple in a process.
- Immediately queues a `TEARDOWN_DV_SNOWPIPE` cleanup task
  (`.blocked().cleanup()`) that runs `DROP PIPE IF EXISTS`.
- Uses idempotent DDL plus process-local cache to avoid duplicate provisioning.

Synchronous setup is intentional: it guarantees the pipe exists before any DEA
task can issue `ALTER PIPE ... REFRESH`.

### Drain barriers before Evaluate

The flow differs by number of result pipes for a validation level:

- **Single-pipe levels** (for example L2 metrics, L3 cell, L3 hybrid cell drill-down):
  - One **drain barrier** (`SNOWPIPE` task) per chain for that pipe; many DEA
    partitions can list the same drain as successor so they **fan in** before
    the downstream task runs.
  - The successor unblocks when the pipe drains (`Evaluate L3` for standard
    cell, `FinalizeHybridL3` for hybrid cell drill-down). See **Pipe-wide drain
    completion** under Monitoring.
- **Multi-pipe levels** (L3 row mode and L3 hybrid row-hashing phase: diffs, summary, chunk hashes):
  - One `PrepareDvDrain` orchestrator task is created as a fan-in barrier.
  - On execution, it inserts one drain task per pipe in parallel.
  - All drains point to Evaluate; normal predecessor rules enforce fan-in.

### Hybrid L3 specifics

Hybrid mode uses the same per-table pipes as the other modes but in two
phases per table:

1. **Row-hashing phase**: per-table `Evaluate L3` task is the anchor; row-hash
   DEAs across all partitions fan in via `PrepareDvDrain` ⇒ `ROW_DIFFS` /
   `ROW_SUMMARY` / `CHUNK_HASHES` drains ⇒ Evaluate. The early-stop poll
   watches that Evaluate task and may bulk-skip remaining row tasks for the
   table once the row-mismatch threshold is met.
2. **Cell drill-down phase**: when the row-hashing Evaluate task runs, it
   selects the partitions whose `ROW_VALIDATION_RESULTS` show mismatches and
   pushes one cell DEA per such partition. Those DEAs fan in to a per-table
   `CELL_DIFFS` Snowpipe drain whose successor is a single
   `FinalizeHybridL3` orchestrator task that sets `L3_STATUS` and table
   validation status from the resulting cell-diff count. When zero
   partitions had mismatches the finalize logic runs inline (no extra
   task / pipe).

## Monitoring Model

DV Snowpipe uses **drain mode** monitoring, not event-table scanning:

- Polls `SYSTEM$PIPE_STATUS('<pipe>')`.
- Completion requires:
  - `pendingFileCount == 0`
  - execution state is a healthy idle state.
- Failure occurs when execution state is in known unhealthy/stopped states.

### Pipe-wide drain completion (important)

`SYSTEM$PIPE_STATUS` reports **`pendingFileCount` for the entire Snowpipe**, not
for a single `ALTER PIPE … REFRESH PREFIX='…'` invocation. Per-partition refresh
still scopes what gets enqueued for load, but **drain** answers “has this
**pipe** finished everything in its queue?”

The orchestrator’s task queue groups pending `SNOWPIPE` drain tasks by
**`pipe_name`**. When a pipe shows `pendingFileCount == 0` and a healthy idle
execution state, it **completes every tracked drain task for that pipe in the
same refresh cycle** (see
`cloud_core/tasks/queues/table_task_queue.py`, `_refresh_snowpipe_drain_tasks`).
So when many DEA partitions fan into **one** `CELL_DIFFS` (or one row pipe) drain
barrier, each partition still waits on its own upstream chain before the drain
becomes eligible, but **all** those drain rows for the same physical pipe tend
to complete together once the **whole** pipe is idle—not “this partition’s
prefix only.”

Unlike migration Snowpipe, DV pipes do not need `LOG_EVENT_LEVEL = DEBUG` and do
not rely on event-table `file_lifecycle` events.

## Trade-offs

### Benefits

- Removes large per-partition result `COPY INTO` fan-out.
- Gives a clear workflow barrier: Evaluate runs only when all relevant pipes are
  fully drained.
- Uses workflow-scoped pipes, so status checks remain isolated and predictable.

### Costs / caveats

- Adds pipe lifecycle churn (create/drop per workflow per key).
- Adds drain polling latency before Evaluate can start.
- Multi-pipe levels require an extra fan-out task (`PrepareDvDrain`) because the
  queue model supports one direct successor per task.
- Drain completion is **pipe-global** (`SYSTEM$PIPE_STATUS`): concurrent
  partitions sharing one physical pipe do not get independent per-prefix “drain
  done” signals from Snowflake; the orchestrator completes matching drain tasks
  when the **entire** pipe reports zero pending files (see Monitoring above).
