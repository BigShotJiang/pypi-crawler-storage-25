# Cleanup Tasks

A cleanup task is a task that must run even when its workflow fails. It stays `blocked` until **every non-cleanup task** in the workflow reaches a terminal state (`completed` or `failed`), then becomes `pending` and executes normally.

## Creating a Cleanup Task

Use the `TaskBuilder` fluent API — chain `.blocked().cleanup()`:

```python
teardown_task = (
    TaskBuilder(
        workflow_id=workflow_id,
        task_name="Teardown Snowpipe: MY_TABLE",
        executor_type=ExecutorType.ORCHESTRATOR,
        payload=TeardownSnowpipePayload(pipe_name=pipe_name),
        scope="Table[DB.SCHEMA.MY_TABLE]::Preprocessing::SnowpipeTeardown",
    )
    .blocked()
    .cleanup()
    .build()
)
await task_queue.push_task(teardown_task)
```

This sets `is_blocked = True` and `is_cleanup = True` on the task row. The task is pushed to the queue at workflow initialization time but remains blocked for the entire duration of the workflow.

## Unblock Semantics

The `UNBLOCK_TASKS` stored procedure runs three steps in order:

1. **Unblock non-cleanup tasks** whose predecessors are all `completed`.
2. **Cascade failure** to non-cleanup blocked tasks that have at least one `failed` predecessor (loops until no more cascading is possible).
3. **Unblock cleanup tasks** when all non-cleanup tasks in the same workflow are terminal (`completed` or `failed`).

Step 3 is the key: cleanup tasks ignore individual predecessor relationships. Instead, they use a **workflow-wide** check — is there any non-cleanup task still in a non-terminal state? If not, the cleanup task becomes `pending`.

A standalone `UNBLOCK_CLEANUP_TASKS` procedure performs only step 3. The orchestrator calls it every bookkeeping cycle (~10 seconds) to ensure cleanup tasks are unblocked promptly, even between `UNBLOCK_TASKS` invocations.

## When Cleanup Runs

| Trigger | What happens |
|---------|-------------|
| Normal completion | All non-cleanup tasks reach `completed` → cleanup tasks unblock → they execute → workflow finishes |
| Partial failure | Some tasks `failed`, failures cascade to blocked successors → eventually all non-cleanup tasks are terminal → cleanup tasks unblock |
| Manual cancellation | `CANCEL_WORKFLOW` fails all active tasks, then calls `UNBLOCK_TASKS` which cascades failures and unblocks cleanup |

## Workflow Completion

`COMPLETE_WORKFLOWS` marks a workflow as `finished` only when **all** tasks (including cleanup) are in a terminal state. Cleanup tasks must themselves complete before the workflow can finish.

## Current Cleanup Task Types

| Task | Handler | Purpose |
|------|---------|---------|
| `TEARDOWN_SNOWPIPE` | `TeardownSnowpipeHandler` | Drops the data-migration Snowpipe (`DROP PIPE IF EXISTS`) |
| `TEARDOWN_DV_SNOWPIPE` | `TeardownDvSnowpipeHandler` | Drops a per-table data-validation result Snowpipe |

Both are pushed at setup time (workflow init or first use via `ensure_dv_pipe`) and sit blocked until the workflow winds down. The DDL is idempotent (`IF EXISTS`), so duplicate teardowns are harmless.

## Design Considerations

- **No predecessor edges.** Cleanup tasks rely on a workflow-wide terminal check, not on `successor_task_id` links. Adding or removing non-cleanup tasks doesn't require rewiring cleanup dependencies.
- **Idempotent handlers.** Cleanup DDL uses `DROP ... IF EXISTS`, so retries and duplicates are safe.
- **Bookkeeping frequency.** `unblock_cleanup_tasks` runs every orchestrator cycle (~10s). A cleanup task may sit blocked for up to one cycle after the last non-cleanup task finishes.
