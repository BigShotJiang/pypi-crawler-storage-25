programs={"ml":{
    1:'''import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import matplotlib.pyplot as plt

# Load dataset
data = pd.read_csv("iris.csv")

print("Dataset preview:\n", data.head(), "\n")

# Features & target
X = data.drop("species", axis=1)
y, labels = pd.factorize(data["species"])

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Model
clf = DecisionTreeClassifier(criterion="gini", max_depth=5, random_state=42)
clf.fit(X_train, y_train)

# Prediction
y_pred = clf.predict(X_test)

# Evaluation
print("Accuracy:", accuracy_score(y_test, y_pred))
print("\nClassification Report:\n", classification_report(y_test, y_pred))
print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred))

# New samples prediction
new_samples = pd.DataFrame([
    [5.1, 3.5, 1.4, 0.2],
    [6.7, 3.1, 4.7, 1.5],
    [7.5, 3.6, 6.1, 2.5]
], columns=X.columns)

predictions = clf.predict(new_samples)
species_predictions = [labels[p] for p in predictions]

print("\nPredictions:", species_predictions)

# Tree Visualization
plt.figure(figsize=(20, 10))
plot_tree(clf, feature_names=X.columns, class_names=labels, filled=True)
plt.title("Decision Tree")
plt.show()''',
2:'''#Linearity Visualization
import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets

iris = datasets.load_iris()
X = iris.data
y = iris.target

# Plot
plt.scatter(X[:50, 0], X[:50, 2], color='black', marker='x', label='setosa')
plt.scatter(X[50:100, 0], X[50:100, 2], color='green', marker='s', label='versicolor')

plt.xlabel('Sepal Length')
plt.ylabel('Petal Length')
plt.legend()
plt.show()''',
3:'''#Non-Linearity
import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets

iris = datasets.load_iris()
X = iris.data
y = iris.target

plt.scatter(X[50:100, 0], X[50:100, 2], color='black', marker='x', label='versicolor')
plt.scatter(X[100:150, 0], X[100:150, 2], color='red', marker='o', label='virginica')

plt.xlabel('Sepal Length')
plt.ylabel('Petal Length')
plt.legend()
plt.show()''',
4:'''#Spam Classification (SVM)
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import classification_report, accuracy_score

# Load dataset
data = pd.read_csv("spam.csv", delimiter='\t', encoding='latin-1')

# Keep required columns
data = data[['Type', 'Message']]
data.columns = ['label', 'email']

# Encode labels
data['label'] = data['label'].map({'ham': 0, 'spam': 1})

# Vectorization
vectorizer = TfidfVectorizer(stop_words='english')
X = vectorizer.fit_transform(data['email'])
y = data['label']

# Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Model
model = SVC(kernel='linear')
model.fit(X_train, y_train)

# Prediction
y_pred = model.predict(X_test)

# Evaluation
print(classification_report(y_test, y_pred))
print("Accuracy:", accuracy_score(y_test, y_pred))''',
5:'''#Face Detection
import cv2

face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 
                                     'haarcascade_frontalface_default.xml')

image = cv2.imread("image.jpg")

if image is None:
    print("Image not found")
else:
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    faces = face_cascade.detectMultiScale(gray, 1.1, 5)

    for (x, y, w, h) in faces:
        cv2.rectangle(image, (x, y), (x+w, y+h), (255, 0, 0), 2)

    cv2.imshow("Face Detection", image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
''',
6:'''#KNN
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

df = pd.read_csv("iris.csv")

le = LabelEncoder()
df["species"] = le.fit_transform(df["species"])

X = df.iloc[:, :-1]
y = df.iloc[:, -1]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

model = KNeighborsClassifier(n_neighbors=5)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, y_pred))''',
7:'''#MNIST Neural Network
import tensorflow as tf
from tensorflow import keras
import numpy as np
import matplotlib.pyplot as plt

# Load dataset
(x_train, y_train), (x_test, y_test) = keras.datasets.mnist.load_data()

# Normalize
x_train = x_train / 255.0
x_test = x_test / 255.0

# Flatten
x_train = x_train.reshape(-1, 28*28)
x_test = x_test.reshape(-1, 28*28)

# Model
model = keras.Sequential([
    keras.layers.Dense(128, activation='relu', input_shape=(784,)),
    keras.layers.Dense(64, activation='relu'),
    keras.layers.Dense(10, activation='softmax')
])

# Compile
model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

# Train
history = model.fit(x_train, y_train, epochs=10, batch_size=32,
                    validation_data=(x_test, y_test))

# Evaluate
loss, acc = model.evaluate(x_test, y_test)
print("Test Accuracy:", acc)

# Plot accuracy
plt.plot(history.history['accuracy'], label='train')
plt.plot(history.history['val_accuracy'], label='validation')
plt.legend()
plt.show()

# Prediction example
predictions = model.predict(x_test)

plt.imshow(x_test[0].reshape(28, 28), cmap='gray')
plt.title(f"Predicted: {np.argmax(predictions[0])}")
plt.show()''',
8:'''#K-Means Clustering
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import LabelEncoder
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv('adult.csv')

# Clean data
df.replace(' ?', np.nan, inplace=True)
df.dropna(inplace=True)

# Encode categorical columns
le = LabelEncoder()
for col in df.select_dtypes(include=['object']).columns:
    df[col] = le.fit_transform(df[col])

# Features & target
X = df.drop('income', axis=1)
y = df['income']

# Model
kmeans = KMeans(n_clusters=2, random_state=42)
df['predicted'] = kmeans.fit_predict(X)

# PCA for visualization
pca = PCA(n_components=2)
X_reduced = pca.fit_transform(X)

# Plot
plt.scatter(X_reduced[:, 0], X_reduced[:, 1], c=df['predicted'])
plt.title("K-Means Clustering")
plt.show()''',
9:'''#Random Forest
import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

# Load dataset
df = pd.read_csv('test.csv', encoding='ISO-8859-1')

# Encode sentiment
df['sentiment'] = df['sentiment'].apply(lambda x: 1 if x == 'positive' else 0)

X = df['text']
y = df['sentiment']

# Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Vectorization
vectorizer = TfidfVectorizer(max_features=5000)
X_train = vectorizer.fit_transform(X_train)
X_test = vectorizer.transform(X_test)

# Model
model = RandomForestClassifier()

# Grid Search
params = {
    'n_estimators': [50, 100],
    'max_depth': [None, 10],
    'min_samples_split': [2, 5]
}

grid = GridSearchCV(model, params, cv=3)
grid.fit(X_train, y_train)

# Prediction
y_pred = grid.predict(X_test)

print("Accuracy:", accuracy_score(y_test, y_pred))
print(classification_report(y_test, y_pred))
print("Best Params:", grid.best_params_)''',
10:'''#Locally Weighted Regression vs Linear Regression
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

# Gaussian weights
def gaussian_weights(X, x_query, tau):
    return np.exp(-((X - x_query) ** 2) / (2 * tau ** 2))

# LWR
def lwr(X, y, x_query, tau):
    W = np.diag(gaussian_weights(X, x_query, tau))
    X_b = np.c_[np.ones(len(X)), X]
    theta = np.linalg.inv(X_b.T @ W @ X_b) @ (X_b.T @ W @ y)
    return np.array([1, x_query]) @ theta

# Load dataset
data = pd.read_csv('tips.csv')
X = data['total_bill'].values
y = data['tip'].values

# Predictions
X_test = np.linspace(min(X), max(X), 100)
y_lwr = np.array([lwr(X, y, x, 10) for x in X_test])

# Linear Regression
lr = LinearRegression()
lr.fit(X.reshape(-1,1), y)
y_lr = lr.predict(X_test.reshape(-1,1))

# Plot
plt.scatter(X, y)
plt.plot(X_test, y_lwr, color='red', label='LWR')
plt.plot(X_test, y_lr, linestyle='dashed', label='Linear')
plt.legend()
plt.show()''',
11:'''#Bayesian Network
import pandas as pd
from pgmpy.models import BayesianNetwork
from pgmpy.estimators import BayesianEstimator
from pgmpy.inference import VariableElimination

# Load dataset
df = pd.read_csv('heart.csv')
df.dropna(inplace=True)

# Model
model = BayesianNetwork([
    ('age', 'target'),
    ('chol', 'target')
])

# Train
model.fit(df, estimator=BayesianEstimator)

# Inference
infer = VariableElimination(model)

result = infer.query(variables=['target'], evidence={
    'age': 63,
    'chol': 233
})

print(result)''',
12:'''#Credit Card Fraud Detection
import pandas as pd
import tensorflow as tf
from tensorflow import keras
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

# Load dataset
df = pd.read_csv("credit.csv")
df.dropna(inplace=True)

X = df.drop("Class", axis=1)
y = df["Class"]

# Scale
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Model
model = keras.Sequential([
    keras.layers.Dense(64, activation='relu', input_shape=(X.shape[1],)),
    keras.layers.Dense(32, activation='relu'),
    keras.layers.Dense(16, activation='relu'),
    keras.layers.Dense(1, activation='sigmoid')
])

# Compile
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# Train
model.fit(X_train, y_train, epochs=2, batch_size=32)

# Predict
y_pred = (model.predict(X_test) > 0.5).astype(int)

# Metrics
print("Accuracy:", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred))
print("Recall:", recall_score(y_test, y_pred))
print("F1:", f1_score(y_test, y_pred))'''
}}


datasets = {
    "iris":'''sepal_length,sepal_width,petal_length,petal_width,species
5.1,3.5,1.4,0.2,setosa
4.9,3.0,1.4,0.2,setosa
5.0,3.6,1.4,0.2,setosa
6.0,2.2,4.0,1.0,versicolor
5.5,2.3,4.0,1.3,versicolor
6.5,2.8,4.6,1.5,versicolor
6.3,3.3,6.0,2.5,virginica
5.8,2.7,5.1,1.9,virginica
7.1,3.0,5.9,2.1,virginica''',
"spam":'''Type	Message
ham	Hello how are you
spam	Win money now!!!
ham	Are you coming today?
spam	Claim your free prize
ham	Let's meet tomorrow
spam	Free entry in contest''',
"adult":'''age,workclass,education,marital-status,occupation,race,gender,hours-per-week,income
39,State-gov,Bachelors,Never-married,Adm-clerical,White,Male,40,<=50K
50,Self-emp,HS-grad,Married,Exec-managerial,White,Male,60,>50K
38,Private,HS-grad,Divorced,Handlers-cleaners,White,Male,40,<=50K
53,Private,11th,Married,Handlers-cleaners,Black,Male,40,<=50K
28,Private,Bachelors,Married,Prof-specialty,Black,Female,40,>50K''',
"test":'''text,sentiment
I love this product,positive
This is very bad,negative
Amazing experience,positive
Worst service ever,negative
Very happy with this,positive
Not good at all,negative''',
"tips":'''total_bill,tip
10.34,1.66
20.45,3.50
15.20,2.50
25.00,4.00
30.50,5.50
18.75,3.00''',
"heart":'''age,chol,target
63,233,1
37,250,1
41,204,1
56,236,0
57,354,1
44,263,0''',
"credit":'''Time,V1,V2,V3,Amount,Class
0,-1.35,-0.07,2.53,149.62,0
1,1.19,0.26,0.16,2.69,0
2,-1.36,-1.34,1.77,378.66,0
3,-0.97,-0.18,1.79,123.50,1
4,1.23,0.14,0.05,69.99,0'''
}

def get_code(sub,no):
    return programs[sub][no]

def get_data(title):
    return datasets[title]

