"""
✅ Class fdsa - Contains all programs from fds.py as text
Each method returns the program code as a string
"""


class fdsa:
    """Class containing all data science and ML programs as text"""

    @staticmethod
    def program_1():
        """EX NO: 1 – NumPy Arrays"""
        return """# ========== PROGRAM 1: NumPy Arrays ==========

import numpy as np

arr = np.array([[1,2,3],[4,2,5]])

print("Type:", type(arr))
print("Dimensions:", arr.ndim)
print("Shape:", arr.shape)
print("Size:", arr.size)
print("Datatype:", arr.dtype)"""

    @staticmethod
    def program_2():
        """EX NO: 2 – Array Slicing"""
        return """# ========== PROGRAM 2: Array Slicing ==========

import numpy as np

a = np.array([[1,2,3],[3,4,5],[4,5,6]])

print(a)
print("Second column:", a[:,1])
print("Second row:", a[1,:])
print("Column 1 onwards:\\n", a[:,1:])"""

    @staticmethod
    def program_3():
        """EX NO: 3 – Pandas DataFrame"""
        return """# ========== PROGRAM 3: Pandas DataFrame ==========

import numpy as np
import pandas as pd

data = np.array([['','Col1','Col2'],
                 ['Row1',1,2],
                 ['Row2',3,4]])

df = pd.DataFrame(data=data[1:,1:], index=data[1:,0], columns=data[0,1:])
print(df)

arr = np.array([[1,2,3],[4,5,6]])
print(pd.DataFrame(arr))

d = {1:['1','3'],2:['1','2'],3:['2','4']}
print(pd.DataFrame(d))"""

    @staticmethod
    def program_4():
        """EX NO: 4 – Iris Dataset (CSV)"""
        return """# ========== PROGRAM 4: Iris Dataset (CSV) ==========

import pandas as pd

df = pd.read_csv("Iris.csv")

print(df.head())
print("Shape:", df.shape)

print(df.info())
print(df.describe())

print("Missing values:\\n", df.isnull().sum())

# Remove duplicates
data = df.drop_duplicates(subset="Species")
print(data)

print(df["Species"].value_counts())"""

    @staticmethod
    def program_5():
        """EX NO: 5 – Univariate Analysis"""
        return """# ========== PROGRAM 5: Univariate Analysis ==========

import pandas as pd
import numpy as np

df = pd.read_csv("diabetes.csv")

def analysis(df):
    for col in df.columns:
        print(f"\\n--- {col} ---")
        print("Mean:", df[col].mean())
        print("Median:", df[col].median())
        print("Mode:", df[col].mode()[0])
        print("Variance:", df[col].var())
        print("Std Dev:", df[col].std())
        print("Skewness:", df[col].skew())

analysis(df)"""

    @staticmethod
    def program_6():
        """EX NO: 6 – Logistic Regression"""
        return """# ========== PROGRAM 6: Logistic Regression ==========

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

df = pd.read_csv("diabetes.csv")

df.replace(0, np.nan, inplace=True)
df.fillna(df.mean(numeric_only=True), inplace=True)

X = df.drop("Outcome", axis=1)
y = df["Outcome"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, y_pred))"""

    @staticmethod
    def program_7():
        """EX NO: 7 – Histogram + Normal Curve"""
        return """# ========== PROGRAM 7: Histogram + Normal Curve ==========

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from scipy.stats import norm

df = pd.read_csv("Iris.csv")

for col in df.columns[:-1]:
    sns.histplot(df[col], kde=True, stat="density")

    mean, std = norm.fit(df[col])
    xmin, xmax = plt.xlim()
    x = np.linspace(xmin, xmax, 100)
    p = norm.pdf(x, mean, std)

    plt.plot(x, p, 'k', linewidth=2)
    plt.title(col)
    plt.show()"""

    @staticmethod
    def program_8():
        """EX NO: 8 – Density + Contour"""
        return """# ========== PROGRAM 8: Density + Contour ==========

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv("Iris.csv")

# Density
for col in df.columns[:-1]:
    sns.kdeplot(data=df, x=col, hue="Species", fill=True)
    plt.show()

# Contour
sns.pairplot(df, hue="Species", kind="kde")
plt.show()"""

    @staticmethod
    def program_9():
        """EX NO: 9 – Correlation + Scatter"""
        return """# ========== PROGRAM 9: Correlation + Scatter ==========

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv("diabetes.csv")

corr = df.corr(numeric_only=True)
sns.heatmap(corr, annot=True)
plt.show()

plt.scatter(df["Glucose"], df["Insulin"])
plt.show()

plt.scatter(df["BMI"], df["Age"])
plt.show()"""

    @staticmethod
    def program_10():
        """EX NO: 10 – Histogram + 3D Plot"""
        return """# ========== PROGRAM 10: Histogram + 3D Plot ==========

import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

df = pd.read_csv("diabetes.csv")

# Histogram
df.hist()
plt.show()

# 3D plot
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

ax.scatter(df["Glucose"], df["BMI"], df["Age"])

ax.set_xlabel("Glucose")
ax.set_ylabel("BMI")
ax.set_zlabel("Age")

plt.show()"""


# Usage examples:
if __name__ == "__main__":
    # Get program 1 as text
    print("Program 1:")
    print(fdsa.program_1())
    print("\n" + "="*50 + "\n")
    
    # Get program 2 as text
    print("Program 2:")
    print(fdsa.program_2())
    print("\n" + "="*50 + "\n")
    
    # Get program 3 as text
    print("Program 3:")
    print(fdsa.program_3())
