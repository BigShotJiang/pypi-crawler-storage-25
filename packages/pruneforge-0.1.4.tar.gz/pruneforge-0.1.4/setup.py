"""
Legacy setup.py — all metadata lives in pyproject.toml.
Kept for compatibility with older pip versions and editable installs.
"""
from setuptools import setup

setup()
