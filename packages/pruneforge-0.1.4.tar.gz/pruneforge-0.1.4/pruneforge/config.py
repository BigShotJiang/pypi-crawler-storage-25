"""
PruneForge Configuration
=========================
Centralised dataclasses for every component.
All hyper-parameters live here so train.py can read/write them uniformly.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


# ---------------------------------------------------------------------------
# Knowledge Pool
# ---------------------------------------------------------------------------

@dataclass
class KnowledgePoolConfig:
    vocab_size: int = 50_000
    embedding_dim: int = 256
    num_concepts: int = 65_536
    topk_retrieval: int = 1_000
    temperature: float = 0.07          # NT-Xent contrastive temperature
    use_hnsw: bool = False             # HNSW ANN retrieval (requires faiss)

    # Training
    pretrain_epochs: int = 10
    pretrain_batch_size: int = 512
    pretrain_lr: float = 3e-4


# ---------------------------------------------------------------------------
# Pipeline stages
# ---------------------------------------------------------------------------

@dataclass
class Stage1Config:
    """Morphological Decomposition — BiLSTM over character sequences."""
    char_vocab_size: int = 512
    char_embed_dim: int = 64
    hidden_dim: int = 128
    num_layers: int = 2
    dropout: float = 0.1
    max_affix_len: int = 8             # max number of affixes per token

    # Training
    epochs: int = 5
    batch_size: int = 256
    lr: float = 1e-3


@dataclass
class Stage2Config:
    """Topical Relevance Filter — bilinear scorer."""
    hidden_dim: int = 128
    dropout: float = 0.1
    threshold: float = 0.5            # θ — relevance cutoff
    prune_ratio: float = 0.7          # expected fraction pruned (keeps 30 %)

    # Training
    epochs: int = 5
    batch_size: int = 256
    lr: float = 1e-3


@dataclass
class Stage3Config:
    """Composability Assessment — pairwise MLP."""
    hidden_dim: int = 64
    dropout: float = 0.1

    # Training
    epochs: int = 5
    batch_size: int = 256
    lr: float = 1e-3


@dataclass
class Stage4Config:
    """Coherence Validation — small Transformer encoder."""
    hidden_dim: int = 256
    num_heads: int = 4
    num_layers: int = 2
    dropout: float = 0.1

    # Training
    epochs: int = 5
    batch_size: int = 128
    lr: float = 5e-4


# ---------------------------------------------------------------------------
# Composition Motor
# ---------------------------------------------------------------------------

@dataclass
class CompositionMotorConfig:
    vocab_size: int = 50_000
    embedding_dim: int = 256           # must match KnowledgePool.embedding_dim
    hidden_dim: int = 512
    num_heads: int = 8
    num_layers: int = 6
    dropout: float = 0.1
    max_seq_len: int = 512
    max_correction_iters: int = 5      # M — self-correction loop iterations

    # RL reward shaping
    rl_reward_per_iter_saved: float = 1.0
    rl_penalty_backtrack: float = -2.0

    # Training
    epochs: int = 10
    batch_size: int = 32
    lr: float = 1e-4


# ---------------------------------------------------------------------------
# Top-level config
# ---------------------------------------------------------------------------

@dataclass
class PruneForgeConfig:
    lang: str = "multilingual"
    device: str = "cpu"
    seed: int = 42
    symbolic_threshold: float = 0.3   # SCF threshold for symbolic mode

    knowledge_pool: KnowledgePoolConfig = field(default_factory=KnowledgePoolConfig)
    stage1: Stage1Config = field(default_factory=Stage1Config)
    stage2: Stage2Config = field(default_factory=Stage2Config)
    stage3: Stage3Config = field(default_factory=Stage3Config)
    stage4: Stage4Config = field(default_factory=Stage4Config)
    motor: CompositionMotorConfig = field(default_factory=CompositionMotorConfig)
