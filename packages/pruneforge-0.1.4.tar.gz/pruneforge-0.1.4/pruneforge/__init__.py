"""
PruneForge: A Hierarchical Pruning Architecture for On-Device Language Intelligence
Research Paper — Version 0.1 (Draft), 2026

Architecture:
    1. Knowledge Pool       — compressed semantic storage
    2. Hierarchical Pruning Pipeline (5 stages)
    3. Composition Motor    — lightweight token assembly engine
"""

from pruneforge.knowledge_pool.pool import KnowledgePool
from pruneforge.pipeline.pipeline import HierarchicalPruningPipeline
from pruneforge.motor.motor import CompositionMotor
from pruneforge.inference import PruneForgeModel

__version__ = "0.1.0"
__all__ = ["KnowledgePool", "HierarchicalPruningPipeline", "CompositionMotor", "PruneForgeModel"]
