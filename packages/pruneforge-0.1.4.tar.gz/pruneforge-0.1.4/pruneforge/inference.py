"""
Inference
=========
PruneForgeModel: high-level wrapper for end-to-end inference.

Usage:
    model = PruneForgeModel.load("output/")
    output = model.generate("Türkçe bir cümle")
    print(output.text)
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, List

import torch
import torch.nn as nn

from pruneforge.config import PruneForgeConfig
from pruneforge.knowledge_pool.pool import KnowledgePool
from pruneforge.pipeline.pipeline import HierarchicalPruningPipeline
from pruneforge.motor.motor import CompositionMotor

logger = logging.getLogger(__name__)


@dataclass
class GenerationOutput:
    token_ids: torch.Tensor     # (seq_len,)
    text: str
    coherence_score: float
    iterations_used: int
    backtrack_needed: bool


class PruneForgeModel(nn.Module):
    """
    End-to-end inference wrapper.

    Combines KnowledgePool + HierarchicalPruningPipeline + CompositionMotor
    into a single generate() call.
    """

    def __init__(
        self,
        cfg: PruneForgeConfig,
        pool: KnowledgePool,
        pipeline: HierarchicalPruningPipeline,
        motor: CompositionMotor,
        tokenizer=None,
    ):
        super().__init__()
        self.cfg      = cfg
        self.pool     = pool
        self.pipeline = pipeline
        self.motor    = motor
        self.tokenizer = tokenizer

    # ------------------------------------------------------------------

    @torch.no_grad()
    def generate(
        self,
        text: str,
        max_output_len: Optional[int] = None,
        device: Optional[str] = None,
    ) -> GenerationOutput:
        """
        Generate output for a single text input.
        """
        if self.tokenizer is None:
            raise RuntimeError("Tokenizer not attached. Pass tokenizer= when constructing PruneForgeModel.")

        dev = device or self.cfg.device
        self.pool.to(dev)
        self.pipeline.to(dev)
        self.motor.to(dev)

        # Tokenise
        ids  = self.tokenizer.encode(text, max_len=512)
        mask = [1] * len(ids)
        # Pad to 512
        pad  = 512 - len(ids)
        ids  += [0] * pad
        mask += [0] * pad

        input_ids = torch.tensor([ids],  dtype=torch.long,  device=dev)
        attn_mask = torch.tensor([mask], dtype=torch.long,  device=dev)

        # Pool retrieval
        query_vec, scores, indices = self.pool.encode_and_retrieve(input_ids, attn_mask)

        # Build char_ids for candidates (proxy: repeat first token chars)
        char_ids_single = torch.tensor(
            [self.tokenizer.encode_chars(text.split()[0] if text.split() else text, 32)],
            dtype=torch.long, device=dev,
        )  # (1, 32)
        k = indices.size(1)
        char_ids = char_ids_single.unsqueeze(1).expand(1, k, 32)
        char_mask = (char_ids != 0).float()

        # Pipeline
        motor_input, _ = self.pipeline(char_ids, char_mask, query_vec, scores)

        # Motor
        output = self.motor(motor_input, max_output_len=max_output_len)

        token_ids = output.token_ids[0]
        text_out  = self.tokenizer.decode(token_ids.tolist()) if self.tokenizer else ""

        return GenerationOutput(
            token_ids=token_ids,
            text=text_out,
            coherence_score=output.coherence_score[0].item(),
            iterations_used=output.iterations_used[0].item(),
            backtrack_needed=output.backtrack_needed[0].item(),
        )

    # ------------------------------------------------------------------

    def save(self, directory: str) -> None:
        p = Path(directory)
        p.mkdir(parents=True, exist_ok=True)
        torch.save(self.pool.state_dict(),     p / "knowledge_pool_ft.pt")
        torch.save(self.pipeline.state_dict(), p / "pipeline_ft.pt")
        torch.save(self.motor.state_dict(),    p / "motor_ft.pt")
        if self.tokenizer is not None:
            self.tokenizer.save(p)
        logger.info(f"PruneForgeModel saved → {p}")

    @classmethod
    def load(cls, directory: str, device: str = "cpu") -> "PruneForgeModel":
        from pruneforge.utils.data import MultilingualTokenizer

        p = Path(directory)
        # Load config defaults (real config would be serialised too; this is a
        # reasonable fallback for research use)
        cfg = PruneForgeConfig(device=device)

        tokenizer = MultilingualTokenizer.load(p)
        cfg.knowledge_pool.vocab_size = tokenizer._next_id
        cfg.motor.vocab_size          = tokenizer._next_id

        pool     = KnowledgePool(cfg.knowledge_pool)
        pipeline = HierarchicalPruningPipeline(cfg)
        motor    = CompositionMotor(cfg.motor)

        def _load(module, name):
            path = p / name
            if path.exists():
                module.load_state_dict(torch.load(path, map_location=device))
                logger.info(f"  Loaded {name}")
            else:
                logger.warning(f"  {name} not found — using random weights")

        _load(pool,     "knowledge_pool_ft.pt")
        _load(pipeline, "pipeline_ft.pt")
        _load(motor,    "motor_ft.pt")

        return cls(cfg, pool, pipeline, motor, tokenizer=tokenizer)
