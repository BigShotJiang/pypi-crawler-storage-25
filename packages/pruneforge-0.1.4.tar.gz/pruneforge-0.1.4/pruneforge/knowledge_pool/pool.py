"""
Knowledge Pool
==============
Section 3.1

Compressed semantic storage: a large concept matrix C ∈ R^{N×d} that the
query encoder retrieves from via inner-product search.

Retrieval pipeline:
    1. QueryEncoder encodes (input_ids, mask) → query vector q ∈ R^d
    2. Inner-product search over C → top-k concept indices + scores
    3. Downstream stages receive (q, scores, indices)

Contrastive pre-training uses NT-Xent loss to align anchor/positive pairs
in the concept space.
"""
from __future__ import annotations

import logging
from typing import Tuple, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from pruneforge.config import KnowledgePoolConfig

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Query encoder
# ---------------------------------------------------------------------------

class QueryEncoder(nn.Module):
    """
    Lightweight encoder: token embedding → mean-pool → 2-layer MLP → L2-norm.
    Designed to be fast on-device; no attention required here.
    """

    def __init__(self, vocab_size: int, embedding_dim: int):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        self.mlp = nn.Sequential(
            nn.Linear(embedding_dim, embedding_dim * 2),
            nn.GELU(),
            nn.Linear(embedding_dim * 2, embedding_dim),
        )
        self.norm = nn.LayerNorm(embedding_dim)

    def forward(
        self,
        input_ids: torch.Tensor,        # (B, seq_len)
        attention_mask: torch.Tensor,   # (B, seq_len)  1=real, 0=pad
    ) -> torch.Tensor:                  # (B, d)
        x = self.embed(input_ids)                                   # (B, L, d)
        mask = attention_mask.unsqueeze(-1).float()                 # (B, L, 1)
        x = (x * mask).sum(1) / mask.sum(1).clamp(min=1e-9)       # (B, d) mean-pool
        x = self.mlp(x)
        x = self.norm(x)
        return F.normalize(x, dim=-1)


# ---------------------------------------------------------------------------
# Knowledge Pool
# ---------------------------------------------------------------------------

class KnowledgePool(nn.Module):
    """
    Large concept matrix C ∈ R^{N×d} with a lightweight query encoder.

    Retrieval: soft inner-product (exact), or HNSW ANN when use_hnsw=True.
    """

    def __init__(self, cfg: KnowledgePoolConfig):
        super().__init__()
        self.cfg = cfg
        d = cfg.embedding_dim

        self.encoder = QueryEncoder(cfg.vocab_size, d)

        # Concept matrix — the "knowledge pool" itself
        self.concepts = nn.Linear(d, cfg.num_concepts, bias=True)
        # Initialise with small normal weights
        nn.init.normal_(self.concepts.weight, std=0.02)
        nn.init.zeros_(self.concepts.bias)

        self._hnsw_index = None

    # ------------------------------------------------------------------
    # Retrieval
    # ------------------------------------------------------------------

    def encode_and_retrieve(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Encode input and retrieve top-k concepts.

        Returns:
            query_vec:  (B, d)       L2-normalised query vector
            scores:     (B, k)       inner-product scores for top-k concepts
            indices:    (B, k)       concept indices
        """
        q = self.encoder(input_ids, attention_mask)     # (B, d)
        # (B, N) — inner product with all concepts
        logits = self.concepts(q)
        k = min(self.cfg.topk_retrieval, self.cfg.num_concepts)
        scores, indices = logits.topk(k, dim=-1)        # (B, k)
        return q, scores, indices

    # ------------------------------------------------------------------
    # Contrastive loss (NT-Xent) — used in Phase 1 training
    # ------------------------------------------------------------------

    def contrastive_loss(
        self,
        anchor_ids: torch.Tensor,       # (B, L)
        positive_ids: torch.Tensor,     # (B, L)
        anchor_mask: torch.Tensor,
        positive_mask: torch.Tensor,
    ) -> torch.Tensor:
        """
        NT-Xent loss between anchor and positive concept vectors.
        Negatives are other samples in the batch.
        """
        z_a = self.encoder(anchor_ids, anchor_mask)     # (B, d)
        z_p = self.encoder(positive_ids, positive_mask) # (B, d)

        B = z_a.size(0)
        tau = self.cfg.temperature

        # Concatenate for 2B × 2B similarity matrix
        z = torch.cat([z_a, z_p], dim=0)               # (2B, d)
        sim = torch.mm(z, z.t()) / tau                  # (2B, 2B)

        # Mask out self-similarity
        mask = torch.eye(2 * B, dtype=torch.bool, device=z.device)
        sim = sim.masked_fill(mask, float('-inf'))

        # Positive pairs: (i, i+B) and (i+B, i)
        targets = torch.cat([
            torch.arange(B, 2 * B, device=z.device),
            torch.arange(0, B, device=z.device),
        ])

        loss = F.cross_entropy(sim, targets)
        return loss

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    def get_concept_embeddings(self, indices: torch.Tensor) -> torch.Tensor:
        """
        Look up concept embedding vectors by index.

        Args:
            indices: (B, k) long tensor

        Returns:
            (B, k, d)
        """
        # concepts.weight shape: (N, d)
        return F.embedding(indices, self.concepts.weight)
