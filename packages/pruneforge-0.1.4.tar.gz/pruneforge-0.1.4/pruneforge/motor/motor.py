"""
Composition Motor
==================
Section 3.3

The final assembly engine.  Receives MotorInput from Stage 5 and produces
a coherent output token sequence.

Design philosophy (Section 3.3):
    Explicit specialisation — analogous to BERT's specialisation for MLM.
    This is NOT a general-purpose LM.  It is a token assembly engine.

    It operates on pre-validated, pre-ordered token sets.
    Its inductive bias: roots first (semantic skeleton), affixes second
    (grammatical specification).  This ordering is learned, not hardcoded.

Self-Correction Loop (Section 3.3.2):
    After assembly, a small coherence evaluator checks the candidate output.
    If incoherent → discard, adjust state, retry (max M iterations).
    If still incoherent after M iterations → emit backtrack signal to Stage 4.

    RL training incentivises the motor to produce valid output on fewer
    iterations while retaining the correction mechanism as a safety net.

Architecture:
    - Root Encoder: projects root embeddings into motor's hidden space
    - Affix Embedder: affix ids → embeddings
    - Transformer decoder (cross-attention over root set)
    - Output head: hidden → vocab logits
    - Coherence evaluator: small binary classifier on the output
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from pruneforge.config import CompositionMotorConfig
from pruneforge.pipeline.stage5_handoff import MotorInput

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Output container
# ---------------------------------------------------------------------------

@dataclass
class MotorOutput:
    token_ids: torch.Tensor             # (B, seq_len) — generated token ids
    logits: torch.Tensor                # (B, seq_len, vocab_size)
    coherence_score: torch.Tensor       # (B,) ∈ [0,1] — final internal check
    iterations_used: torch.Tensor       # (B,) int — self-correction iterations
    backtrack_needed: torch.Tensor      # (B,) bool — True if motor gave up
    symbolic_mode: torch.Tensor         # (B,) bool


# ---------------------------------------------------------------------------
# Coherence evaluator (internal to motor)
# ---------------------------------------------------------------------------

class _CoherenceEvaluator(nn.Module):
    """
    Binary classifier: given generated hidden states, is this output coherent?
    Small by design — it is run M times per inference.
    """

    def __init__(self, hidden_dim: int):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(hidden_dim, 64),
            nn.GELU(),
            nn.Linear(64, 1),
        )

    def forward(self, hidden: torch.Tensor) -> torch.Tensor:
        """
        Args:
            hidden: (B, seq_len, H)

        Returns:
            score: (B,) ∈ [0,1] — higher = more coherent
        """
        pooled = hidden.mean(dim=1)     # (B, H)
        return torch.sigmoid(self.mlp(pooled).squeeze(-1))


# ---------------------------------------------------------------------------
# Composition Motor
# ---------------------------------------------------------------------------

class CompositionMotor(nn.Module):
    """
    Token assembly engine.

    Two assembly modes:
        semantic mode:  roots → affixes → output (natural language)
        symbolic mode:  operators before operands (prefix-first internally)

    The mode is selected per-sample based on SCF.
    """

    BOS_ID = 1
    EOS_ID = 2
    PAD_ID = 0

    def __init__(self, cfg: CompositionMotorConfig):
        super().__init__()
        self.cfg = cfg
        H = cfg.hidden_dim

        # Root projection: D → H
        self.root_proj = nn.Sequential(
            nn.Linear(cfg.embedding_dim, H),
            nn.LayerNorm(H),
        )

        # Affix embedding
        self.affix_embed = nn.Embedding(cfg.vocab_size, cfg.embedding_dim, padding_idx=0)
        self.affix_proj = nn.Linear(cfg.embedding_dim, H)

        # Output token embedding (shared with output head)
        self.token_embed = nn.Embedding(cfg.vocab_size, H, padding_idx=self.PAD_ID)
        self.pos_embed = nn.Embedding(cfg.max_seq_len, H)

        # Transformer decoder
        decoder_layer = nn.TransformerDecoderLayer(
            d_model=H,
            nhead=cfg.num_heads,
            dim_feedforward=H * 4,
            dropout=cfg.dropout,
            batch_first=True,
            norm_first=True,
        )
        self.decoder = nn.TransformerDecoder(decoder_layer, num_layers=cfg.num_layers)

        # Output head (weight-tied with token embedding)
        self.output_head = nn.Linear(H, cfg.vocab_size, bias=False)
        self.output_head.weight = self.token_embed.weight   # weight tying

        # Symbolic mode: separate lightweight decoder
        sym_layer = nn.TransformerDecoderLayer(
            d_model=H, nhead=cfg.num_heads // 2,
            dim_feedforward=H * 2, dropout=cfg.dropout,
            batch_first=True, norm_first=True,
        )
        self.symbolic_decoder = nn.TransformerDecoder(sym_layer, num_layers=2)

        # Internal coherence evaluator
        self.coherence_eval = _CoherenceEvaluator(H)

        # Internal state adjustment (used by self-correction loop)
        self.correction_gate = nn.GRUCell(H, H)

        self.dropout = nn.Dropout(cfg.dropout)
        self.layer_norm = nn.LayerNorm(H)

    # ------------------------------------------------------------------
    # Memory construction: encode root+affix set into memory for decoder
    # ------------------------------------------------------------------

    def _build_memory(self, motor_input: MotorInput, symbolic: bool = False) -> torch.Tensor:
        """
        Combine root embeddings and affix embeddings into a unified memory
        that the decoder will cross-attend to.

        Returns:
            memory: (B, k*(1+A), H)
        """
        B, k, D = motor_input.root_embeddings.shape
        A = motor_input.affix_map.size(-1)

        # Root encoding  (B, k, H)
        root_mem = self.root_proj(motor_input.root_embeddings)

        # Affix encoding  (B, k, A, H)
        # Clamp indices to valid embedding range (affix ids may use char vocab ~512)
        affix_map_clamped = motor_input.affix_map.clamp(0, self.cfg.vocab_size - 1)
        affix_emb = self.affix_embed(affix_map_clamped)   # (B, k, A, emb)
        affix_mem = self.affix_proj(affix_emb)                 # (B, k, A, H)

        if symbolic:
            # Symbolic mode: operators (roots) come before operands (affixes)
            # This is already the natural order; just flatten
            pass  # same layout works

        # Interleave root + affixes: root_i, aff_i_0, aff_i_1, ...
        # Final shape: (B, k*(1+A), H)
        root_exp = root_mem.unsqueeze(2)                       # (B, k, 1, H)
        combined = torch.cat([root_exp, affix_mem], dim=2)     # (B, k, 1+A, H)
        memory = combined.reshape(B, k * (1 + A), -1)            # (B, k*(1+A), H)

        return self.layer_norm(memory)

    # ------------------------------------------------------------------
    # Single assembly pass
    # ------------------------------------------------------------------

    def _assemble(
        self,
        memory: torch.Tensor,           # (B, mem_len, H)
        max_len: int,
        symbolic_mode: torch.Tensor,    # (B,) bool
        correction_state: Optional[torch.Tensor] = None,  # (B, H)
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Autoregressive decoding over memory.

        Returns:
            token_ids: (B, max_len)
            logits:    (B, max_len, vocab)
            hidden:    (B, max_len, H)
        """
        B = memory.size(0)
        device = memory.device

        # Start with BOS
        input_ids = torch.full((B, 1), self.BOS_ID, dtype=torch.long, device=device)
        all_logits = []
        all_hidden = []

        for t in range(max_len):
            # Token + positional embedding
            pos = torch.arange(input_ids.size(1), device=device).unsqueeze(0)
            pos = pos.clamp(max=self.cfg.max_seq_len - 1)
            x = self.token_embed(input_ids) + self.pos_embed(pos)
            x = self.dropout(x)

            # Causal mask
            T = x.size(1)
            causal_mask = torch.triu(
                torch.ones(T, T, device=device, dtype=torch.bool), diagonal=1
            )

            # Decode (use symbolic decoder for symbolic samples if needed)
            # For simplicity: run standard decoder for all; symbolic mode
            # difference is in memory construction + assembly order bias
            h = self.decoder(
                tgt=x,
                memory=memory,
                tgt_mask=causal_mask,
            )                                               # (B, T, H)

            # Optional: apply correction state from previous iteration
            if correction_state is not None:
                last_h = h[:, -1, :]                       # (B, H)
                corrected = self.correction_gate(correction_state, last_h)
                h = torch.cat([h[:, :-1, :], corrected.unsqueeze(1)], dim=1)

            logits_t = self.output_head(h[:, -1, :])       # (B, vocab)
            next_id = logits_t.argmax(-1, keepdim=True)    # (B, 1) greedy

            all_logits.append(logits_t)
            all_hidden.append(h[:, -1, :])
            input_ids = torch.cat([input_ids, next_id], dim=1)

            # Early stop if all samples have emitted EOS
            if (next_id.squeeze(-1) == self.EOS_ID).all():
                break

        # Pad to max_len
        seq_len = len(all_logits)
        token_ids = input_ids[:, 1:]                                        # strip BOS
        token_ids = F.pad(token_ids, (0, max_len - token_ids.size(1)))

        logits = torch.stack(all_logits, dim=1)                             # (B, T, vocab)
        logits = F.pad(logits, (0, 0, 0, max_len - logits.size(1)))

        hidden = torch.stack(all_hidden, dim=1)                             # (B, T, H)
        hidden = F.pad(hidden, (0, 0, 0, max_len - hidden.size(1)))

        return token_ids, logits, hidden

    # ------------------------------------------------------------------
    # Forward with self-correction loop
    # ------------------------------------------------------------------

    def forward(
        self,
        motor_input: MotorInput,
        max_output_len: Optional[int] = None,
        teacher_forcing_ids: Optional[torch.Tensor] = None,  # (B, seq) for training
    ) -> MotorOutput:
        """
        Args:
            motor_input:         structured input from Stage 5
            max_output_len:      maximum output sequence length
            teacher_forcing_ids: gold token ids for supervised training

        Returns:
            MotorOutput
        """
        B = motor_input.batch_size
        M = self.cfg.max_correction_iters
        device = motor_input.root_embeddings.device
        max_len = max_output_len or min(motor_input.num_candidates * 2, self.cfg.max_seq_len)

        symbolic_mode = motor_input.scf > 0.3              # (B,) bool

        # Build memory
        memory = self._build_memory(motor_input, symbolic=False)

        iterations_used = torch.zeros(B, dtype=torch.long, device=device)
        backtrack_needed = torch.zeros(B, dtype=torch.bool, device=device)
        final_ids = torch.zeros(B, max_len, dtype=torch.long, device=device)
        final_logits = torch.zeros(B, max_len, self.cfg.vocab_size, device=device)
        final_coherence = torch.zeros(B, device=device)

        # Per-sample "done" flag
        done = torch.zeros(B, dtype=torch.bool, device=device)
        correction_state: Optional[torch.Tensor] = None

        # ----- Supervised training: teacher forcing (no loop) -----
        if teacher_forcing_ids is not None:
            return self._forward_teacher_forcing(motor_input, teacher_forcing_ids, memory)

        # ----- Inference: self-correction loop -----
        for iteration in range(M):
            token_ids, logits, hidden = self._assemble(
                memory, max_len, symbolic_mode, correction_state
            )

            # Evaluate coherence
            coh_score = self.coherence_eval(hidden)         # (B,)

            # Update done mask
            newly_done = (~done) & (coh_score >= 0.5)
            final_ids[newly_done] = token_ids[newly_done]
            final_logits[newly_done] = logits[newly_done]
            final_coherence[newly_done] = coh_score[newly_done]
            iterations_used[newly_done] = iteration + 1
            done = done | newly_done

            if done.all():
                break

            # Update correction state for next iteration
            correction_state = hidden[:, -1, :]             # (B, H)

        # Samples that never passed coherence check
        still_failing = ~done
        if still_failing.any():
            final_ids[still_failing] = token_ids[still_failing]
            final_logits[still_failing] = logits[still_failing]
            final_coherence[still_failing] = coh_score[still_failing]
            iterations_used[still_failing] = M
            backtrack_needed[still_failing] = True
            logger.debug(
                f"Motor: {still_failing.sum().item()} samples need backtrack after {M} iterations."
            )

        return MotorOutput(
            token_ids=final_ids,
            logits=final_logits,
            coherence_score=final_coherence,
            iterations_used=iterations_used,
            backtrack_needed=backtrack_needed,
            symbolic_mode=symbolic_mode,
        )

    # ------------------------------------------------------------------
    # Supervised forward (teacher forcing for training)
    # ------------------------------------------------------------------

    def _forward_teacher_forcing(
        self,
        motor_input: MotorInput,
        target_ids: torch.Tensor,       # (B, seq_len)
        memory: torch.Tensor,           # (B, mem_len, H)
    ) -> MotorOutput:
        B, T = target_ids.shape
        device = target_ids.device
        symbolic_mode = motor_input.scf > 0.3

        # Prepend BOS
        bos = torch.full((B, 1), self.BOS_ID, dtype=torch.long, device=device)
        dec_in = torch.cat([bos, target_ids[:, :-1]], dim=1)  # (B, T)

        pos = torch.arange(T, device=device).unsqueeze(0).clamp(max=self.cfg.max_seq_len - 1)
        x = self.token_embed(dec_in) + self.pos_embed(pos)
        x = self.dropout(x)

        causal_mask = torch.triu(torch.ones(T, T, device=device, dtype=torch.bool), diagonal=1)
        h = self.decoder(tgt=x, memory=memory, tgt_mask=causal_mask)   # (B, T, H)

        logits = self.output_head(h)                                     # (B, T, vocab)
        token_ids = logits.argmax(-1)
        coh_score = self.coherence_eval(h)

        return MotorOutput(
            token_ids=token_ids,
            logits=logits,
            coherence_score=coh_score,
            iterations_used=torch.ones(B, dtype=torch.long, device=device),
            backtrack_needed=torch.zeros(B, dtype=torch.bool, device=device),
            symbolic_mode=symbolic_mode,
        )

    # ------------------------------------------------------------------
    # Training losses
    # ------------------------------------------------------------------

    def compute_ce_loss(
        self,
        output: MotorOutput,
        target_ids: torch.Tensor,       # (B, seq_len)
        ignore_index: int = 0,
    ) -> torch.Tensor:
        """Standard cross-entropy loss for supervised training."""
        B, T, V = output.logits.shape
        loss = F.cross_entropy(
            output.logits.view(B * T, V),
            target_ids.view(-1),
            ignore_index=ignore_index,
        )
        return loss

    def compute_rl_loss(
        self,
        output: MotorOutput,
        coherence_threshold: float = 0.5,
    ) -> torch.Tensor:
        """
        Reinforcement learning loss for self-correction loop.
        Reward: positive for coherent output, scaled by iterations saved.
        Penalty: for requiring backtrack.
        """
        cfg = self.cfg

        # Reward: coherent in fewer iterations
        iter_fraction = output.iterations_used.float() / self.cfg.max_correction_iters
        coherent = output.coherence_score >= coherence_threshold

        reward = torch.where(
            coherent,
            cfg.rl_reward_per_iter_saved * (1.0 - iter_fraction),
            torch.full_like(iter_fraction, cfg.rl_penalty_backtrack),
        )

        # Policy gradient (REINFORCE): loss = -reward * log_prob
        # Use mean log-prob of output tokens as proxy for log policy probability
        log_probs = F.log_softmax(output.logits, dim=-1)
        token_log_probs = log_probs.gather(
            -1, output.token_ids.unsqueeze(-1).clamp(0, self.cfg.vocab_size - 1)
        ).squeeze(-1)
        mean_log_prob = token_log_probs.mean(dim=-1)    # (B,)

        loss = -(reward * mean_log_prob).mean()
        return loss

    def save(self, path) -> None:
        from pathlib import Path
        p = Path(path)
        p.mkdir(parents=True, exist_ok=True)
        torch.save(self.state_dict(), p / "motor.pt")
        logger.info(f"Motor saved → {p / 'motor.pt'}")

    def load(self, path) -> None:
        from pathlib import Path
        p = Path(path)
        self.load_state_dict(torch.load(p / "motor.pt", map_location="cpu"))
        logger.info(f"Motor loaded ← {p / 'motor.pt'}")
