"""
Stage 2 — Topical Relevance Filter
=====================================
Section 3.2.2

Scores each morphological candidate against the query vector using a bilinear
scorer, then prunes candidates below threshold θ.

Input:   MorphOutput (from Stage 1) + query_vec (from KnowledgePool)
Output:  RelevanceOutput — per-candidate scores + filtered root embeddings
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

import torch
import torch.nn as nn
import torch.nn.functional as F

from pruneforge.config import Stage2Config
from pruneforge.pipeline.stage1 import MorphOutput

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Output container
# ---------------------------------------------------------------------------

@dataclass
class RelevanceOutput:
    root_embeddings: torch.Tensor   # (B, k, d)  — same as morph, passthrough
    affix_ids: torch.Tensor         # (B, k, A)
    is_symbolic: torch.Tensor       # (B, k)
    relevance_scores: torch.Tensor  # (B, k) ∈ [0,1]
    keep_mask: torch.Tensor         # (B, k) bool — True = kept after pruning


# ---------------------------------------------------------------------------
# Stage 2 module
# ---------------------------------------------------------------------------

class TopicalRelevanceFilter(nn.Module):
    """
    Bilinear relevance scorer.

    score(q, r_i) = sigmoid( q W r_i^T + b )

    where q ∈ R^d_pool is the query vector and r_i ∈ R^d_morph is the
    root embedding for candidate i.
    """

    def __init__(self, cfg: Stage2Config, query_dim: int, root_dim: int):
        super().__init__()
        self.cfg = cfg

        # Project both into shared hidden space first
        self.query_proj = nn.Linear(query_dim, cfg.hidden_dim)
        self.root_proj  = nn.Linear(root_dim,  cfg.hidden_dim)

        self.scorer = nn.Sequential(
            nn.Linear(cfg.hidden_dim * 2, cfg.hidden_dim),
            nn.GELU(),
            nn.Dropout(cfg.dropout),
            nn.Linear(cfg.hidden_dim, 1),
        )

    def forward(
        self,
        morph: MorphOutput,
        query_vec: torch.Tensor,    # (B, d_pool)
    ) -> RelevanceOutput:
        B, k, d = morph.root_embeddings.shape

        q_proj = self.query_proj(query_vec)                         # (B, H)
        q_exp  = q_proj.unsqueeze(1).expand(-1, k, -1)            # (B, k, H)

        r_proj = self.root_proj(morph.root_embeddings)             # (B, k, H)

        combined = torch.cat([q_exp, r_proj], dim=-1)              # (B, k, 2H)
        scores   = torch.sigmoid(self.scorer(combined).squeeze(-1)) # (B, k)

        keep_mask = scores >= self.cfg.threshold                    # (B, k)

        return RelevanceOutput(
            root_embeddings=morph.root_embeddings,
            affix_ids=morph.affix_ids,
            is_symbolic=morph.is_symbolic,
            relevance_scores=scores,
            keep_mask=keep_mask,
        )

    # ------------------------------------------------------------------
    # Training loss
    # ------------------------------------------------------------------

    def compute_loss(
        self,
        morph: MorphOutput,
        query_vec: torch.Tensor,    # (B, d_pool)
        labels: torch.Tensor,       # (B, k) float 0/1  — pseudo or gold
    ) -> torch.Tensor:
        B, k, _ = morph.root_embeddings.shape

        q_proj   = self.query_proj(query_vec).unsqueeze(1).expand(-1, k, -1)
        r_proj   = self.root_proj(morph.root_embeddings)
        combined = torch.cat([q_proj, r_proj], dim=-1)
        logits   = self.scorer(combined).squeeze(-1)                # (B, k) raw

        loss = F.binary_cross_entropy_with_logits(logits, labels)
        return loss
