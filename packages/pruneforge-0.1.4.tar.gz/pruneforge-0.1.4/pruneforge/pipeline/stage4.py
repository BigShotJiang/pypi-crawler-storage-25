"""
Stage 4 — Coherence Validation
=================================
Section 3.2.4

Global coherence check over the surviving candidate set.
Uses a small Transformer encoder over root embeddings (enriched by
relevance + composability scores) and produces a binary keep/drop decision.

Also computes the Symbolic Content Fraction (SCF) used by the Motor.

Input:   ComposabilityOutput (from Stage 3)
Output:  MotorInput (Stage 5 handoff to Composition Motor)
"""
from __future__ import annotations

import logging
from typing import Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from pruneforge.config import Stage4Config
from pruneforge.pipeline.stage3 import ComposabilityOutput
from pruneforge.pipeline.stage5_handoff import MotorInput

logger = logging.getLogger(__name__)


class CoherenceValidator(nn.Module):
    """
    Small Transformer encoder + binary classifier.

    Enriches root embeddings with relevance/composability context, then
    classifies each candidate and produces a global coherence gate.
    """

    def __init__(self, cfg: Stage4Config, root_dim: int):
        super().__init__()
        self.cfg = cfg
        H = cfg.hidden_dim

        # Project root embeddings into transformer hidden space
        # +2 for relevance_score and mean composability score scalars
        self.input_proj = nn.Linear(root_dim + 2, H)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=H,
            nhead=cfg.num_heads,
            dim_feedforward=H * 4,
            dropout=cfg.dropout,
            batch_first=True,
            norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=cfg.num_layers)

        # Per-candidate binary classifier
        self.candidate_classifier = nn.Linear(H, 1)

        # Global coherence: CLS-like pooling → binary gate
        self.global_classifier = nn.Linear(H, 1)

    def forward(self, comp: ComposabilityOutput) -> MotorInput:
        B, k, d = comp.root_embeddings.shape

        # Enrich with scalar signals
        rel_scores = comp.relevance_scores.unsqueeze(-1)            # (B, k, 1)
        comp_mean  = comp.composability_scores.mean(-1).unsqueeze(-1) # (B, k, 1)
        enriched   = torch.cat([comp.root_embeddings, rel_scores, comp_mean], dim=-1)  # (B,k,d+2)

        x = self.input_proj(enriched)                               # (B, k, H)
        h = self.encoder(x)                                         # (B, k, H)

        # Per-candidate coherence scores
        cand_logits = self.candidate_classifier(h).squeeze(-1)      # (B, k)
        cand_scores = torch.sigmoid(cand_logits)

        # Global coherence = mean of per-candidate scores
        coherence_mask = cand_scores >= 0.5                         # (B, k) bool

        # Symbolic Content Fraction: fraction of symbolic candidates
        scf = comp.is_symbolic.mean(dim=-1)                         # (B,)

        return MotorInput(
            root_embeddings=comp.root_embeddings,
            affix_map=comp.affix_ids,
            relevance_scores=comp.relevance_scores,
            composability=comp.composability_scores,
            coherence_mask=coherence_mask,
            scf=scf,
        )

    # ------------------------------------------------------------------
    # Training loss
    # ------------------------------------------------------------------

    def compute_loss(
        self,
        comp: ComposabilityOutput,
        global_labels: torch.Tensor,    # (B,) float 0/1
    ) -> torch.Tensor:
        B, k, d = comp.root_embeddings.shape

        rel_scores = comp.relevance_scores.unsqueeze(-1)
        comp_mean  = comp.composability_scores.mean(-1).unsqueeze(-1)
        enriched   = torch.cat([comp.root_embeddings, rel_scores, comp_mean], dim=-1)

        x = self.input_proj(enriched)
        h = self.encoder(x)

        # Global loss: mean-pool → classify
        pooled = h.mean(dim=1)                                      # (B, H)
        global_logits = self.global_classifier(pooled).squeeze(-1)  # (B,)

        loss = F.binary_cross_entropy_with_logits(global_logits, global_labels)
        return loss
