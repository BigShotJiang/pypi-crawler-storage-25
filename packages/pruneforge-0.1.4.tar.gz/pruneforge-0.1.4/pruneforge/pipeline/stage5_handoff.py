"""
Stage 5 → Motor handoff contract.
MotorInput is the structured payload that Stage 4 (coherence validation)
passes to the Composition Motor.
"""
from __future__ import annotations

from dataclasses import dataclass

import torch


@dataclass
class MotorInput:
    """
    Structured payload from the hierarchical pipeline to the Composition Motor.

    Attributes:
        root_embeddings:  (B, k, d)   — per-candidate root vectors
        affix_map:        (B, k, A)   — affix token id sequences per candidate
        relevance_scores: (B, k)      — Stage 2 relevance logits
        composability:    (B, k, k)   — Stage 3 pair composability scores
        coherence_mask:   (B, k)      — Stage 4 binary keep/drop mask
        scf:              (B,)        — Symbolic Content Fraction per sample
    """
    root_embeddings: torch.Tensor   # (B, k, d)
    affix_map: torch.Tensor         # (B, k, A)
    relevance_scores: torch.Tensor  # (B, k)
    composability: torch.Tensor     # (B, k, k)
    coherence_mask: torch.Tensor    # (B, k)  bool or float
    scf: torch.Tensor               # (B,)

    @property
    def batch_size(self) -> int:
        return self.root_embeddings.size(0)

    @property
    def num_candidates(self) -> int:
        return self.root_embeddings.size(1)
