"""
Stage 1 — Morphological Decomposition
======================================
Section 3.2.1

For each candidate token (represented as a character sequence), decomposes it
into:
    - root embedding:  dense vector representing the stem
    - affix ids:       ordered list of affix token ids
    - is_symbolic:     whether the token is punctuation / operator / number

Architecture: per-token BiLSTM over character sequence → root head + affix head.

Training modes:
    Supervised:    morph TSV with gold root_id + affix_ids → CE losses
    Self-supervised: reconstruct first character as root proxy (used in train.py
                     via _get_root_logits)
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from pruneforge.config import Stage1Config

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Output container
# ---------------------------------------------------------------------------

@dataclass
class MorphOutput:
    """
    Per-candidate morphological decomposition.

    Shapes use B=batch, k=candidates, d=hidden*2 (BiLSTM), A=max_affix_len.
    """
    root_embeddings: torch.Tensor   # (B, k, d)   BiLSTM hidden for root
    affix_ids: torch.Tensor         # (B, k, A)   predicted affix token ids
    is_symbolic: torch.Tensor       # (B, k)      float in [0,1]


# ---------------------------------------------------------------------------
# Stage 1 module
# ---------------------------------------------------------------------------

class MorphologicalDecomposer(nn.Module):
    """
    Lightweight BiLSTM morphological analyser.

    Input:  char_ids  (B, k, L)  — character id sequences for k candidates
            char_mask (B, k, L)  — 1=real char, 0=pad

    Output: MorphOutput
    """

    def __init__(self, cfg: Stage1Config):
        super().__init__()
        self.cfg = cfg
        d = cfg.hidden_dim
        A = cfg.max_affix_len

        self.char_embed = nn.Embedding(cfg.char_vocab_size, cfg.char_embed_dim, padding_idx=0)

        self.bilstm = nn.LSTM(
            input_size=cfg.char_embed_dim,
            hidden_size=d,
            num_layers=cfg.num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=cfg.dropout if cfg.num_layers > 1 else 0.0,
        )

        bilstm_out = d * 2   # bidirectional

        # Root head: maps BiLSTM mean-pool → root embedding space
        self.root_head = nn.Sequential(
            nn.Linear(bilstm_out, bilstm_out),
            nn.LayerNorm(bilstm_out),
            nn.GELU(),
        )

        # Root logit head: root embedding → vocab logits (for self-supervised loss)
        self.root_logit_head = nn.Linear(bilstm_out, cfg.char_vocab_size)

        # Affix head: A separate linear per affix position
        # Predicts affix token id at each position
        self.affix_head = nn.Linear(bilstm_out, A * cfg.char_vocab_size)

        # Symbolic classifier
        self.symbolic_head = nn.Linear(bilstm_out, 1)

        self.dropout = nn.Dropout(cfg.dropout)

    # ------------------------------------------------------------------
    # Encode: char_ids → BiLSTM hidden
    # ------------------------------------------------------------------

    def _encode(
        self,
        char_ids: torch.Tensor,     # (B*k, L)
        char_mask: torch.Tensor,    # (B*k, L)
    ) -> torch.Tensor:              # (B*k, d*2)
        """Run BiLSTM and mean-pool over valid characters."""
        x = self.char_embed(char_ids)                       # (B*k, L, emb)
        x = self.dropout(x)

        # Pack for efficiency (skip padding)
        lengths = char_mask.sum(-1).long().clamp(min=1).cpu()
        packed = nn.utils.rnn.pack_padded_sequence(
            x, lengths, batch_first=True, enforce_sorted=False
        )
        out_packed, _ = self.bilstm(packed)
        out, _ = nn.utils.rnn.pad_packed_sequence(out_packed, batch_first=True)  # (B*k, T, 2d)

        # Trim char_mask to match actual output length T (pad_packed_sequence truncates)
        T = out.size(1)
        mask = char_mask[:, :T].unsqueeze(-1).float()       # (B*k, T, 1)
        pooled = (out * mask).sum(1) / mask.sum(1).clamp(min=1e-9)  # (B*k, 2d)
        return pooled

    # ------------------------------------------------------------------
    # Forward
    # ------------------------------------------------------------------

    def forward(
        self,
        char_ids: torch.Tensor,     # (B, k, L)
        char_mask: torch.Tensor,    # (B, k, L)
    ) -> MorphOutput:
        B, k, L = char_ids.shape

        # Flatten candidates into batch dimension
        flat_ids  = char_ids.reshape(B * k, L)
        flat_mask = char_mask.reshape(B * k, L)

        hidden = self._encode(flat_ids, flat_mask)          # (B*k, 2d)

        # Root embedding
        root_emb = self.root_head(hidden)                   # (B*k, 2d)

        # Affix predictions: (B*k, A, char_vocab)
        A = self.cfg.max_affix_len
        affix_logits = self.affix_head(hidden).view(B * k, A, self.cfg.char_vocab_size)
        affix_ids = affix_logits.argmax(-1)                 # (B*k, A)

        # Symbolic prediction
        sym_score = torch.sigmoid(self.symbolic_head(hidden).squeeze(-1))  # (B*k,)

        return MorphOutput(
            root_embeddings=root_emb.view(B, k, -1),
            affix_ids=affix_ids.view(B, k, A),
            is_symbolic=sym_score.view(B, k),
        )

    # ------------------------------------------------------------------
    # _get_root_logits — used in self-supervised training path (train.py)
    # ------------------------------------------------------------------

    def _get_root_logits(
        self,
        char_ids: torch.Tensor,     # (B, k, L)
        char_mask: torch.Tensor,    # (B, k, L)
    ) -> torch.Tensor:              # (B, k, char_vocab_size)
        """
        Returns root logits over char vocabulary for the self-supervised
        reconstruction loss in train.py.

        The self-supervised objective treats the first character of each token
        as a proxy root label and trains the root head to predict it.
        """
        B, k, L = char_ids.shape
        flat_ids  = char_ids.reshape(B * k, L)
        flat_mask = char_mask.reshape(B * k, L)

        hidden   = self._encode(flat_ids, flat_mask)        # (B*k, 2d)
        root_emb = self.root_head(hidden)                   # (B*k, 2d)
        logits   = self.root_logit_head(root_emb)           # (B*k, char_vocab)

        return logits.view(B, k, self.cfg.char_vocab_size)

    # ------------------------------------------------------------------
    # Supervised training loss
    # ------------------------------------------------------------------

    def compute_loss(
        self,
        char_ids: torch.Tensor,         # (B, k, L)
        char_mask: torch.Tensor,        # (B, k, L)
        root_ids: torch.Tensor,         # (B, k)   gold root token id
        affix_ids: torch.Tensor,        # (B, k, A) gold affix ids
        sym_labels: torch.Tensor,       # (B, k)   float 0/1
    ) -> torch.Tensor:
        B, k, L = char_ids.shape
        A = self.cfg.max_affix_len

        flat_ids  = char_ids.reshape(B * k, L)
        flat_mask = char_mask.reshape(B * k, L)
        hidden    = self._encode(flat_ids, flat_mask)

        # Root loss
        root_emb    = self.root_head(hidden)
        root_logits = self.root_logit_head(root_emb)                # (B*k, V)
        root_loss   = F.cross_entropy(
            root_logits,
            root_ids.view(-1).clamp(0, self.cfg.char_vocab_size - 1),
            ignore_index=0,
        )

        # Affix loss
        affix_logits = self.affix_head(hidden).view(B * k, A, self.cfg.char_vocab_size)
        affix_loss = F.cross_entropy(
            affix_logits.view(B * k * A, self.cfg.char_vocab_size),
            affix_ids.view(-1).clamp(0, self.cfg.char_vocab_size - 1),
            ignore_index=0,
        )

        # Symbolic loss
        sym_pred  = self.symbolic_head(hidden).squeeze(-1)          # (B*k,)
        sym_loss  = F.binary_cross_entropy_with_logits(
            sym_pred, sym_labels.view(-1)
        )

        return root_loss + affix_loss + 0.5 * sym_loss
