"""
Stage 3 — Composability Assessment
=====================================
Section 3.2.3

Assesses whether pairs of candidates can be composed together coherently.
Uses a symmetric pairwise MLP on concatenated root embeddings.

Input:   RelevanceOutput (from Stage 2)
Output:  ComposabilityOutput — pairwise scores + updated root embeddings
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

import torch
import torch.nn as nn
import torch.nn.functional as F

from pruneforge.config import Stage3Config
from pruneforge.pipeline.stage2 import RelevanceOutput

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Output container
# ---------------------------------------------------------------------------

@dataclass
class ComposabilityOutput:
    root_embeddings: torch.Tensor       # (B, k, d)
    affix_ids: torch.Tensor             # (B, k, A)
    is_symbolic: torch.Tensor           # (B, k)
    relevance_scores: torch.Tensor      # (B, k)
    composability_scores: torch.Tensor  # (B, k, k) pairwise
    keep_mask: torch.Tensor             # (B, k)


# ---------------------------------------------------------------------------
# Stage 3 module
# ---------------------------------------------------------------------------

class ComposabilityAssessor(nn.Module):
    """
    Pairwise composability scorer.

    For each pair (r_i, r_j): score = sigmoid(MLP([r_i; r_j; r_i*r_j]))
    The interaction term r_i*r_j (element-wise product) captures compatibility.

    Score matrix is symmetrised: S = (S + S^T) / 2
    """

    def __init__(self, cfg: Stage3Config, root_dim: int):
        super().__init__()
        self.cfg = cfg

        # Input: [r_i; r_j; r_i*r_j] = 3 * root_dim
        self.pair_mlp = nn.Sequential(
            nn.Linear(root_dim * 3, cfg.hidden_dim * 2),
            nn.GELU(),
            nn.Dropout(cfg.dropout),
            nn.Linear(cfg.hidden_dim * 2, cfg.hidden_dim),
            nn.GELU(),
            nn.Linear(cfg.hidden_dim, 1),
        )

    def _score_pairs(self, root_emb: torch.Tensor) -> torch.Tensor:
        """
        Compute pairwise composability scores.

        Args:
            root_emb: (B, k, d)

        Returns:
            scores: (B, k, k) symmetrised ∈ [0,1]
        """
        B, k, d = root_emb.shape

        r_i = root_emb.unsqueeze(2).expand(-1, -1, k, -1)  # (B, k, k, d)
        r_j = root_emb.unsqueeze(1).expand(-1, k, -1, -1)  # (B, k, k, d)
        inter = r_i * r_j                                    # (B, k, k, d)

        pair_feat = torch.cat([r_i, r_j, inter], dim=-1)   # (B, k, k, 3d)
        logits = self.pair_mlp(pair_feat).squeeze(-1)        # (B, k, k)

        # Symmetrise
        logits = (logits + logits.transpose(1, 2)) / 2
        # Zero diagonal (self-pairs)
        eye = torch.eye(k, device=root_emb.device).unsqueeze(0)
        logits = logits * (1 - eye) + eye * float('-inf')

        return torch.sigmoid(logits)

    def forward(self, rel: RelevanceOutput) -> ComposabilityOutput:
        scores = self._score_pairs(rel.root_embeddings)

        return ComposabilityOutput(
            root_embeddings=rel.root_embeddings,
            affix_ids=rel.affix_ids,
            is_symbolic=rel.is_symbolic,
            relevance_scores=rel.relevance_scores,
            composability_scores=scores,
            keep_mask=rel.keep_mask,
        )

    # ------------------------------------------------------------------
    # Training loss
    # ------------------------------------------------------------------

    def compute_loss(
        self,
        rel: RelevanceOutput,
        pair_labels: torch.Tensor,  # (B, k, k) float 0/1
    ) -> torch.Tensor:
        B, k, d = rel.root_embeddings.shape

        r_i = rel.root_embeddings.unsqueeze(2).expand(-1, -1, k, -1)
        r_j = rel.root_embeddings.unsqueeze(1).expand(-1, k, -1, -1)
        inter = r_i * r_j
        pair_feat = torch.cat([r_i, r_j, inter], dim=-1)
        logits = self.pair_mlp(pair_feat).squeeze(-1)
        logits = (logits + logits.transpose(1, 2)) / 2

        # Only compute loss on off-diagonal pairs
        eye = torch.eye(k, device=logits.device, dtype=torch.bool).unsqueeze(0).expand(B, -1, -1).contiguous()
        logits_flat = logits[~eye]
        labels_flat = pair_labels[~eye]

        return F.binary_cross_entropy_with_logits(logits_flat, labels_flat)
