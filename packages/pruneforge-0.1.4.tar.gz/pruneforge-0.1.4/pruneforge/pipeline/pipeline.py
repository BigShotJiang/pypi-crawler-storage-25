"""
Hierarchical Pruning Pipeline
================================
Section 3.2

Wires Stage 1 → Stage 2 → Stage 3 → Stage 4 into a single nn.Module.
Also exposes per-stage parameter groups for independent optimisation during
the staged training in train.py.
"""
from __future__ import annotations

import logging
from typing import Tuple, Iterator

import torch
import torch.nn as nn

from pruneforge.config import PruneForgeConfig
from pruneforge.pipeline.stage1 import MorphologicalDecomposer, MorphOutput
from pruneforge.pipeline.stage2 import TopicalRelevanceFilter, RelevanceOutput
from pruneforge.pipeline.stage3 import ComposabilityAssessor, ComposabilityOutput
from pruneforge.pipeline.stage4 import CoherenceValidator
from pruneforge.pipeline.stage5_handoff import MotorInput

logger = logging.getLogger(__name__)


class HierarchicalPruningPipeline(nn.Module):
    """
    Four-stage hierarchical pruning pipeline.

    Usage (inference):
        motor_input, debug = pipeline(char_ids, char_mask, query_vec, scores)

    Usage (staged training — each stage trained independently):
        opt1 = AdamW(pipeline.stage1_parameters(), ...)
        opt2 = AdamW(pipeline.stage2_parameters(), ...)
        ...
    """

    def __init__(self, cfg: PruneForgeConfig):
        super().__init__()
        self.cfg = cfg

        # Stage 1: Morphological Decomposition
        self.stage1 = MorphologicalDecomposer(cfg.stage1)

        # root_dim = hidden_dim * 2 (BiLSTM bidirectional)
        root_dim = cfg.stage1.hidden_dim * 2

        # Stage 2: Topical Relevance Filter
        self.stage2 = TopicalRelevanceFilter(
            cfg.stage2,
            query_dim=cfg.knowledge_pool.embedding_dim,
            root_dim=root_dim,
        )

        # Stage 3: Composability Assessor
        self.stage3 = ComposabilityAssessor(cfg.stage3, root_dim=root_dim)

        # Stage 4: Coherence Validator
        self.stage4 = CoherenceValidator(cfg.stage4, root_dim=root_dim)

    # ------------------------------------------------------------------
    # End-to-end forward
    # ------------------------------------------------------------------

    def forward(
        self,
        char_ids: torch.Tensor,         # (B, k, L)
        char_mask: torch.Tensor,        # (B, k, L)
        query_vec: torch.Tensor,        # (B, d_pool)
        retrieval_scores: torch.Tensor, # (B, k)  — ignored by stages, passed through
    ) -> Tuple[MotorInput, dict]:
        """
        Full pipeline forward pass.

        Returns:
            motor_input:  structured payload for CompositionMotor
            debug:        intermediate outputs dict (useful for inspection)
        """
        morph: MorphOutput = self.stage1(char_ids, char_mask)
        rel:   RelevanceOutput = self.stage2(morph, query_vec)
        comp:  ComposabilityOutput = self.stage3(rel)
        motor_input: MotorInput = self.stage4(comp)

        debug = dict(morph=morph, rel=rel, comp=comp)
        return motor_input, debug

    # ------------------------------------------------------------------
    # Per-stage parameter iterators (for staged training optimisers)
    # ------------------------------------------------------------------

    def stage1_parameters(self) -> Iterator[nn.Parameter]:
        return self.stage1.parameters()

    def stage2_parameters(self) -> Iterator[nn.Parameter]:
        return self.stage2.parameters()

    def stage3_parameters(self) -> Iterator[nn.Parameter]:
        return self.stage3.parameters()

    def stage4_parameters(self) -> Iterator[nn.Parameter]:
        return self.stage4.parameters()
