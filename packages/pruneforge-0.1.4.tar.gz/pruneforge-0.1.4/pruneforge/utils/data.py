"""
Data Utilities
==============
Tokeniser, Dataset classes, and collate functions used by train.py.

MultilingualTokenizer:
    BPE-lite: character-level with a shared vocab across languages.
    Stores a vocab file for reproducible re-loading.

TextDataset:
    Plain text → (input_ids, attention_mask, char_ids).
    char_ids: (seq_len, max_char_len) — each token encoded as character ids.

MorphDataset:
    TSV with columns: surface, root_id, affix_ids (space-separated), is_symbolic
    Used for supervised Stage 1 training.
"""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import List, Dict, Optional, Callable

import torch
from torch.utils.data import Dataset

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Tokeniser
# ---------------------------------------------------------------------------

_SPECIAL = ["[PAD]", "[BOS]", "[EOS]", "[UNK]"]
_PAD_ID, _BOS_ID, _EOS_ID, _UNK_ID = 0, 1, 2, 3


class MultilingualTokenizer:
    """
    Simple unigram-style tokeniser that builds a vocab from training text.

    Strategy:
      1. Collect all unique characters → base vocab.
      2. Add the most frequent bigrams up to vocab_size.
      3. Encode: greedy longest-match over vocabulary.

    This is intentionally lightweight; swap for SentencePiece in production.
    """

    def __init__(self, vocab_size: int = 50_000):
        self.vocab_size = vocab_size
        self._tok2id: Dict[str, int] = {}
        self._id2tok: Dict[int, str] = {}
        self._next_id: int = len(_SPECIAL)

        for i, s in enumerate(_SPECIAL):
            self._tok2id[s] = i
            self._id2tok[i] = s

    # ------------------------------------------------------------------

    def train(self, lines: List[str]) -> None:
        """Build vocabulary from a list of text lines."""
        from collections import Counter

        # Collect character unigrams
        char_counts: Counter = Counter()
        bigram_counts: Counter = Counter()

        for line in lines:
            chars = list(line)
            for c in chars:
                char_counts[c] += 1
            for a, b in zip(chars, chars[1:]):
                bigram_counts[a + b] += 1

        # Add all characters first
        for ch, _ in char_counts.most_common():
            if ch not in self._tok2id and self._next_id < self.vocab_size:
                self._tok2id[ch] = self._next_id
                self._id2tok[self._next_id] = ch
                self._next_id += 1

        # Add bigrams until vocab full
        for bg, _ in bigram_counts.most_common():
            if self._next_id >= self.vocab_size:
                break
            if bg not in self._tok2id:
                self._tok2id[bg] = self._next_id
                self._id2tok[self._next_id] = bg
                self._next_id += 1

        logger.info(f"Tokenizer trained: {self._next_id} tokens")

    # ------------------------------------------------------------------

    def encode(self, text: str, max_len: Optional[int] = None) -> List[int]:
        """Greedy longest-match tokenisation → list of ids."""
        ids = [_BOS_ID]
        i = 0
        while i < len(text):
            # Try bigram first
            if i + 2 <= len(text) and text[i:i+2] in self._tok2id:
                ids.append(self._tok2id[text[i:i+2]])
                i += 2
            elif text[i] in self._tok2id:
                ids.append(self._tok2id[text[i]])
                i += 1
            else:
                ids.append(_UNK_ID)
                i += 1
        ids.append(_EOS_ID)

        if max_len is not None:
            ids = ids[:max_len]
        return ids

    def encode_chars(self, token: str, max_char_len: int) -> List[int]:
        """Encode a single token as a padded character id sequence."""
        ids = [self._tok2id.get(c, _UNK_ID) for c in token[:max_char_len]]
        ids += [_PAD_ID] * (max_char_len - len(ids))
        return ids

    def decode(self, ids: List[int]) -> str:
        return "".join(
            self._id2tok.get(i, "?")
            for i in ids
            if i not in (_PAD_ID, _BOS_ID, _EOS_ID)
        )

    # ------------------------------------------------------------------

    def save(self, directory) -> None:
        p = Path(directory)
        p.mkdir(parents=True, exist_ok=True)
        path = p / "tokenizer.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump({
                "vocab_size": self.vocab_size,
                "tok2id": self._tok2id,
                "next_id": self._next_id,
            }, f, ensure_ascii=False, indent=2)
        logger.info(f"Tokenizer saved → {path}")

    @classmethod
    def load(cls, directory) -> "MultilingualTokenizer":
        path = Path(directory) / "tokenizer.json"
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        tok = cls(vocab_size=data["vocab_size"])
        tok._tok2id = {k: int(v) for k, v in data["tok2id"].items()}
        tok._id2tok = {int(v): k for k, v in data["tok2id"].items()}
        tok._next_id = data["next_id"]
        logger.info(f"Tokenizer loaded ← {path}  ({tok._next_id} tokens)")
        return tok


# ---------------------------------------------------------------------------
# TextDataset
# ---------------------------------------------------------------------------

class TextDataset(Dataset):
    """
    Plain text file → token ids + char ids per token.

    Each item contains:
        input_ids:        (max_seq_len,)
        attention_mask:   (max_seq_len,)
        char_ids:         (max_seq_len, max_char_len)
    """

    def __init__(
        self,
        path: str,
        tokenizer: MultilingualTokenizer,
        max_seq_len: int = 512,
        max_char_len: int = 32,
    ):
        self.tokenizer = tokenizer
        self.max_seq_len = max_seq_len
        self.max_char_len = max_char_len

        with open(path, "r", encoding="utf-8") as f:
            self.lines = [l.strip() for l in f if l.strip()]

        logger.info(f"TextDataset: {len(self.lines):,} lines from {path}")

    def __len__(self) -> int:
        return len(self.lines)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        line = self.lines[idx]
        ids  = self.tokenizer.encode(line, max_len=self.max_seq_len)

        # Pad
        pad_len = self.max_seq_len - len(ids)
        mask    = [1] * len(ids) + [0] * pad_len
        ids     = ids + [_PAD_ID] * pad_len

        # Build char_ids: split line into "tokens" (space-split proxy)
        words = line.split()[:self.max_seq_len]
        char_ids = [
            self.tokenizer.encode_chars(w, self.max_char_len)
            for w in words
        ]
        # Pad to max_seq_len tokens
        empty_char = [_PAD_ID] * self.max_char_len
        while len(char_ids) < self.max_seq_len:
            char_ids.append(empty_char)

        return {
            "input_ids":      torch.tensor(ids,      dtype=torch.long),
            "attention_mask": torch.tensor(mask,     dtype=torch.long),
            "char_ids":       torch.tensor(char_ids, dtype=torch.long),
        }


# ---------------------------------------------------------------------------
# MorphDataset
# ---------------------------------------------------------------------------

class MorphDataset(Dataset):
    """
    Morphological TSV dataset for supervised Stage 1 training.

    TSV columns (tab-separated):
        surface   root_id   affix_id_1 affix_id_2 ...   is_symbolic

    Example:
        kitabı    42        7 15                         0
        running   108       3                            0
        123       0                                      1
    """

    def __init__(
        self,
        path: str,
        tokenizer: MultilingualTokenizer,
        max_affix_len: int = 8,
        max_char_len:  int = 32,
    ):
        self.tokenizer    = tokenizer
        self.max_affix_len = max_affix_len
        self.max_char_len  = max_char_len
        self.entries: List[Dict] = []

        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split("\t")
                if len(parts) < 2:
                    continue

                surface   = parts[0]
                root_id   = int(parts[1])
                is_sym    = int(parts[-1]) if len(parts) > 2 else 0
                affix_raw = parts[2:-1] if len(parts) > 3 else []
                affix_ids = [int(a) for a in affix_raw if a.strip().isdigit()]

                self.entries.append(dict(
                    surface=surface,
                    root_id=root_id,
                    affix_ids=affix_ids,
                    is_symbolic=is_sym,
                ))

        logger.info(f"MorphDataset: {len(self.entries):,} entries from {path}")

    def __len__(self) -> int:
        return len(self.entries)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        e = self.entries[idx]

        char_ids = self.tokenizer.encode_chars(e["surface"], self.max_char_len)

        affix_ids = e["affix_ids"][:self.max_affix_len]
        affix_ids += [0] * (self.max_affix_len - len(affix_ids))

        return {
            "char_ids":    torch.tensor(char_ids,      dtype=torch.long),
            "char_mask":   torch.tensor([int(c != 0) for c in char_ids], dtype=torch.float),
            "root_id":     torch.tensor(e["root_id"],  dtype=torch.long),
            "affix_ids":   torch.tensor(affix_ids,     dtype=torch.long),
            "is_symbolic": torch.tensor(float(e["is_symbolic"]), dtype=torch.float),
        }


# ---------------------------------------------------------------------------
# Collate functions
# ---------------------------------------------------------------------------

def collate_text(batch: List[Dict]) -> Dict[str, torch.Tensor]:
    return {
        "input_ids":      torch.stack([b["input_ids"]      for b in batch]),
        "attention_mask": torch.stack([b["attention_mask"] for b in batch]),
        "char_ids":       torch.stack([b["char_ids"]       for b in batch]),
    }


def collate_morph(batch: List[Dict]) -> Dict[str, torch.Tensor]:
    return {
        "char_ids":    torch.stack([b["char_ids"]    for b in batch]),
        "char_mask":   torch.stack([b["char_mask"]   for b in batch]),
        "root_id":     torch.stack([b["root_id"]     for b in batch]),
        "affix_ids":   torch.stack([b["affix_ids"]   for b in batch]),
        "is_symbolic": torch.stack([b["is_symbolic"] for b in batch]),
    }
