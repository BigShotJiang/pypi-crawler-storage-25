class tjw_class:
    def helloworld(self, name: str = "TJW"):
        return f"hello [{name}]!"


def hello(name: str = "TJW"):
    return f"hello {name}!"