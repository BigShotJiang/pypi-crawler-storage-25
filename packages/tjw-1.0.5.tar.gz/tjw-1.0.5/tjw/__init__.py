from TJW.core import *

if __name__ == '__main__':
    result = TJW.helloworld()
    print(f"结果：{result}")
