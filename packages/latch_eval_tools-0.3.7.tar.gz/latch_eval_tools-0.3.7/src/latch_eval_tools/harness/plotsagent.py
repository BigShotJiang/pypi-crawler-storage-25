import json
import os
import subprocess
import threading
import time
from pathlib import Path
from datetime import datetime
EVAL_TIMEOUT = 600


def _terminate_process(process: subprocess.Popen):
    """Terminate a subprocess, escalating to SIGKILL if needed."""
    try:
        process.terminate()
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=3)
    except ProcessLookupError:
        pass


def run_plotsagent_task(
    task_prompt: str,
    work_dir: Path,
    model_name: str | None = None,
    eval_timeout: int = EVAL_TIMEOUT,
) -> dict:
    """Run PlotsAgent on a task.
    
    Args:
        task_prompt: Task description for the agent
        work_dir: Working directory for the agent
        model_name: Optional model name (e.g., "anthropic/claude-sonnet-4")
        eval_timeout: Timeout for entire evaluation (seconds)
    
    Returns:
        dict with keys "answer" (parsed JSON or None) and "metadata"
    """
    agent_log_file = work_dir / "agent_output.log"
    if agent_log_file.exists():
        agent_log_file.unlink()

    eval_config = {
        "id": work_dir.name,
        "task": task_prompt,
        "data_node": None,
        "grader": None,
    }

    eval_file = work_dir / "eval_config.json"
    eval_file.write_text(json.dumps(eval_config, indent=2))

    output_file = work_dir / "eval_output.json"
    eval_id = work_dir.name
    workspace_dir = output_file.parent / "workspaces" / eval_id
    trajectory_src = workspace_dir / "trajectory.json"
    trajectory_dst = work_dir / "trajectory.json"
    trajectory_dst.write_text("[]")

    faas_python = Path(os.environ.get("PLOTS_FAAS_PYTHON", "/root/plots-faas-venv/bin/python"))

    cmd = [
        str(faas_python),
        "-m", "latch_eval_tools.eval_server",
        "--headless",
        "--eval", str(eval_file),
        "-o", str(output_file),
    ]

    env = {
        **os.environ,
        "LATCH_PLOTS_FAAS_PATH": os.environ.get("LATCH_PLOTS_FAAS_PATH", "/root/latch-plots-faas"),
        "LATCH_EVAL_OUTPUT_DIR": str(work_dir),
    }

    start_time = time.time()
    timed_out = False
    process = None

    try:
        with open(agent_log_file, "w") as log_f:
            process = subprocess.Popen(
                cmd,
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )

            def stream_output():
                if process.stdout is None:
                    return
                for line in process.stdout:
                    log_f.write(line)
                    log_f.flush()

            stream_thread = threading.Thread(target=stream_output, daemon=True)
            stream_thread.start()

            start_wait = time.monotonic()
            while True:
                if trajectory_src.exists():
                    try:
                        trajectory_dst.write_text(trajectory_src.read_text())
                    except OSError:
                        pass

                if process.poll() is not None:
                    break

                if time.monotonic() - start_wait > eval_timeout:
                    timed_out = True
                    _terminate_process(process)
                    break

                time.sleep(0.5)

            stream_thread.join(timeout=5)

            if timed_out:
                log_f.write(f"\n\nAgent timed out after {eval_timeout} seconds")
                log_f.flush()
    except Exception:
        if timed_out:
            with open(agent_log_file, "a") as log_f:
                log_f.write(f"\n\nAgent timed out after {eval_timeout} seconds")
        raise
    finally:
        if process is not None and process.poll() is None:
            _terminate_process(process)

    duration = time.time() - start_time
    print(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} Agent output saved to: {agent_log_file}")

    trajectory = []
    if workspace_dir.exists():
        if trajectory_src.exists():
            try:
                trajectory = json.loads(trajectory_src.read_text())
                trajectory_dst.write_text(json.dumps(trajectory, indent=2))
                print(f"Trajectory saved to: {trajectory_dst}")
            except json.JSONDecodeError:
                pass

    agent_answer = None
    error_details = None

    if output_file.exists():
        try:
            results = json.loads(output_file.read_text())
            evals = results.get("evals", [])
            if evals:
                eval_entry = evals[0]
                agent_answer = eval_entry.get("agent_answer")
                if agent_answer is not None:
                    eval_answer_file = work_dir / "eval_answer.json"
                    eval_answer_file.write_text(json.dumps(agent_answer, indent=2))
        except json.JSONDecodeError as e:
            error_details = {"error": f"Failed to parse output: {e}"}

    if agent_answer is None:
        eval_answer_file = work_dir / "eval_answer.json"
        if eval_answer_file.exists():
            try:
                agent_answer = json.loads(eval_answer_file.read_text())
            except json.JSONDecodeError:
                pass

    if agent_answer is None:
        if workspace_dir.exists():
            ws_eval_answer = workspace_dir / "eval_answer.json"
            if ws_eval_answer.exists():
                try:
                    agent_answer = json.loads(ws_eval_answer.read_text())
                    eval_answer_file = work_dir / "eval_answer.json"
                    eval_answer_file.write_text(json.dumps(agent_answer, indent=2))
                except json.JSONDecodeError:
                    pass

    if agent_answer is None and not error_details:
        log_tail = ""
        if agent_log_file.exists():
            log_content = agent_log_file.read_text()
            log_tail = log_content[-1000:]

        error_msg = "Agent timed out" if timed_out else "Agent did not produce an answer"
        error_details = {
            "error": error_msg,
            "timed_out": timed_out,
            "log_tail": log_tail,
        }
        print(f"\nWarning: {error_msg}")

    n_steps = len([t for t in trajectory if t.get("type") == "assistant"])

    metadata = {
        "duration_s": round(duration, 2),
        "model": model_name or "anthropic/claude-sonnet-4",
        "n_steps": n_steps,
        "n_messages": len(trajectory),
    }
    if timed_out:
        metadata["timed_out"] = True
        metadata["eval_timeout_seconds"] = eval_timeout
    if error_details:
        metadata["error_details"] = error_details

    return {"answer": agent_answer, "metadata": metadata}
