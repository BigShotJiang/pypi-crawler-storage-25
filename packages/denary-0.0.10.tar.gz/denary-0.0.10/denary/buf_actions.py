from __future__ import annotations

import curses
import json
import random
import re
import textwrap
import unicodedata
from difflib import SequenceMatcher
from pathlib import Path
from typing import Optional

from denary.buf import (
    Buffer,
    BufferAction,
    BufferActionGroup,
    BufferActionTypeEnum,
    CursorPosition,
)


def lines_to_chunk(lines: list[str], start: int, end: int) -> str:
    if start >= end:
        return ""

    chunk = "\n".join(lines[start:end])

    if end < len(lines):
        chunk += "\n"

    return chunk


def generate_buffer_actions(
    old_lines: list[str], new_lines: list[str]
) -> BufferActionGroup:
    old_text_lines = [str(l) for l in old_lines]
    new_text_lines = [str(l) for l in new_lines]

    matcher = SequenceMatcher(None, old_text_lines, new_text_lines)

    actions = []

    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            continue

        cursor = CursorPosition(y=i1, x=0)

        old_chunk = lines_to_chunk(old_text_lines, i1, i2)
        new_chunk = lines_to_chunk(new_text_lines, j1, j2)

        if tag == "replace":
            actions.append(
                BufferAction(
                    action_type=BufferActionTypeEnum.REPLACE,
                    content=(old_chunk, new_chunk),
                    cursor_position=cursor,
                )
            )

        elif tag == "delete":
            actions.append(
                BufferAction(
                    action_type=BufferActionTypeEnum.DELETE,
                    content=old_chunk,
                    cursor_position=cursor,
                )
            )

        elif tag == "insert":
            actions.append(
                BufferAction(
                    action_type=BufferActionTypeEnum.INSERT,
                    content=new_chunk,
                    cursor_position=cursor,
                )
            )

    actions.reverse()
    return BufferActionGroup(actions=actions)


def change_modes(buffer: Buffer) -> Optional[BufferAction]:
    action = None
    current_line = buffer.lines[buffer.cursor_y]
    line = current_line.rstrip()

    if len(line) == 0 and len(current_line) > 0:
        action = BufferAction(
            action_type=BufferActionTypeEnum.DELETE,
            content=buffer.lines[buffer.cursor_y],
            cursor_position=CursorPosition(y=buffer.cursor_y, x=0),
        )

    return action


def get_filepath(buffer: Buffer, abs_path: bool) -> BufferAction:
    action = None

    if abs_path:
        action = BufferAction(
            action_type=BufferActionTypeEnum.INSERT,
            content=str(Path(buffer.file_name or "").absolute()),
            cursor_position=buffer.get_cursor_position(),
        )

    else:
        action = BufferAction(
            action_type=BufferActionTypeEnum.INSERT,
            content=str(buffer.file_name or ""),
            cursor_position=buffer.get_cursor_position(),
        )

    return action


pairs = {
    "(": "()",
    "[": "[]",
    "{": "{}",
    "'": "''",
    '"': '""',
}


def insert_char(
    buffer: Buffer, ch: str, disable_autocomplete: bool = False
) -> BufferAction:
    """
    Insert a printable character at the cursor position.
    Uses BufferAction instead of direct buffer mutation.
    """

    if not disable_autocomplete:
        ch = pairs.get(ch, ch)

    cursor_pos = buffer.get_cursor_position()

    action = BufferAction(
        action_type=BufferActionTypeEnum.INSERT,
        content=ch,
        cursor_position=cursor_pos,
    )

    return action


def merge_lines(buffer: Buffer) -> Optional[BufferAction]:
    """
    Merge the current line with the one below (like VSCode Ctrl+J).
    Implemented as a REPLACE BufferAction.
    """
    y, x = buffer.get_cursor_position()

    if y >= len(buffer.lines) - 1:
        curses.beep()
        return None

    line = buffer.lines[y]
    next_line = buffer.lines[y + 1]

    if next_line.strip():
        merged = line.rstrip() + " " + next_line.lstrip()
    else:
        merged = line.rstrip()

    old_text = f"{line}\n{next_line}"
    new_text = merged

    action = BufferAction(
        action_type=BufferActionTypeEnum.REPLACE,
        content=(old_text, new_text),
        cursor_position=CursorPosition(y=y, x=0),
    )

    return action


def json_format(buffer, text, indent):
    action = BufferAction(
        action_type=BufferActionTypeEnum.REPLACE,
        content=(
            text,
            json.dumps(json.loads(text), indent=indent),
        ),
        cursor_position=buffer.get_cursor_position(),
    )

    return action


def parse_basic_escapes(s: str) -> str:
    return s.encode("utf-8").decode("unicode_escape")


def rejoin(buffer: Buffer, text: str, split_by: str, join_by: str) -> BufferAction:
    lines = text.splitlines()

    first_nonempty = next(
        (ln for ln in lines if ln.strip() != ""), lines[0] if lines else ""
    )
    indent = len(first_nonempty) - len(first_nonempty.lstrip()) if first_nonempty else 0

    try:
        pieces = re.split(split_by, text)
    except re.error as e:
        # self.send_notification(
        #     f"Could not split with regex ({split_by}) falling back to normal split."
        # )

        pieces = text.split(parse_basic_escapes(split_by))

    cleaned = [p.strip() for p in pieces if p.strip() != ""]

    new_text = join_by.join(f"{' ' * indent}{p}" for p in cleaned)

    return BufferAction(
        action_type=BufferActionTypeEnum.REPLACE,
        content=(text, new_text),
        cursor_position=buffer.get_cursor_position(),
    )


def align(buffer: Buffer, text: str, separator: str, add_spaces: bool) -> BufferAction:

    lines = text.splitlines()

    split_lines: list[tuple[Optional[str], str, Optional[str]]] = []
    for line in lines:
        indent_len = len(line) - len(line.lstrip())
        indent = line[:indent_len]
        rest = line[indent_len:]

        if separator in rest:
            left, right = rest.split(separator, 1)
            split_lines.append((indent, left.rstrip(), right.lstrip()))
        else:
            split_lines.append((None, line, None))

    max_width = max(
        (len(left) for _, left, right in split_lines if right is not None),
        default=0,
    )

    new_lines = []
    for _indent, _left, _right in split_lines:
        if _right is None:
            new_lines.append(_left)
            continue

        if _indent is None:
            _indent = ""

        padded_left = _left.ljust(max_width)

        if add_spaces:
            new_line = f"{_indent}{padded_left} {separator} {_right.rstrip()}"
        else:
            new_line = f"{_indent}{padded_left}{separator}{_right.rstrip()}"

        new_lines.append(new_line)

    new_text = "\n".join(new_lines)

    return BufferAction(
        action_type=BufferActionTypeEnum.REPLACE,
        content=(text, new_text),
        cursor_position=buffer.get_cursor_position(),
    )


def unique_lines(buffer: Buffer, text: str) -> BufferAction:
    lines = text.splitlines()

    unique_lines = list(dict.fromkeys(lines))

    new_text = "\n".join(unique_lines)

    return BufferAction(
        action_type=BufferActionTypeEnum.REPLACE,
        content=(text, new_text),
        cursor_position=buffer.get_cursor_position(),
    )


def reverse_lines(buffer: Buffer, text: str) -> BufferAction:
    lines = text.splitlines()

    new_text = "\n".join(reversed(lines))

    return BufferAction(
        action_type=BufferActionTypeEnum.REPLACE,
        content=(text, new_text),
        cursor_position=buffer.get_cursor_position(),
    )


def trim_lines(buffer: Buffer, text: str, res: str) -> BufferAction:
    preserve_trailing_newline = text.endswith("\n")
    lines = text.splitlines()

    if res == "trim":
        result = [line.strip() for line in lines]

    elif res == "trim_l":
        result = [line.lstrip() for line in lines]

    elif res == "trim_r":
        result = [line.rstrip() for line in lines]

    new_text = "\n".join(result)

    if preserve_trailing_newline:
        new_text += "\n"

    return BufferAction(
        action_type=BufferActionTypeEnum.REPLACE,
        content=(text, new_text),
        cursor_position=buffer.get_cursor_position(),
    )


def number_lines(
    buffer: Buffer, text: str, start: int, separator: str, pad: int, skip_empty: bool
) -> BufferAction:
    preserve_trailing_newline = text.endswith("\n")
    lines = text.splitlines()
    counter = start
    result = []

    for line in lines:
        if skip_empty and not line.strip():
            result.append(line)
            continue

        indent = len(line) - len(line.lstrip())
        content = line.lstrip()

        number_str = str(counter)
        if pad > 0:
            number_str = number_str.zfill(pad)

        result.append(f"{' ' * indent}{number_str}{separator} {content}")

        counter += 1

    new_text = "\n".join(result)

    if preserve_trailing_newline:
        new_text += "\n"

    return BufferAction(
        action_type=BufferActionTypeEnum.REPLACE,
        content=(text, new_text),
        cursor_position=buffer.get_cursor_position(),
    )


def remove_empty_lines(buffer: Buffer, text: str) -> BufferAction:
    preserve_trailing_newline = text.endswith("\n")
    lines = text.splitlines()

    result = [line for line in lines if line.strip()]

    new_text = "\n".join(result)

    if preserve_trailing_newline and result:
        new_text += "\n"

    return BufferAction(
        action_type=BufferActionTypeEnum.REPLACE,
        content=(text, new_text),
        cursor_position=buffer.get_cursor_position(),
    )


def wrap_paragraph(
    paragraph_lines: list[str], width: int, break_long_words: bool
) -> list[str]:
    if not paragraph_lines:
        return [""]

    first_line = paragraph_lines[0]
    indent_match = re.match(r"^(\s*)", first_line)
    indent_str = indent_match.group(1) if indent_match else ""

    bullet_match = re.match(r"^(\s*[\-\*\d\.\)]+\s+)", first_line)
    bullet_prefix = bullet_match.group(1) if bullet_match else ""

    if bullet_prefix:
        indent_str = bullet_prefix
        subsequent_indent = " " * len(bullet_prefix)
    else:
        subsequent_indent = indent_str

    joined = " ".join(line.strip() for line in paragraph_lines)

    wrapper = textwrap.TextWrapper(
        width=width,
        initial_indent=indent_str,
        subsequent_indent=subsequent_indent,
        break_long_words=break_long_words,
        break_on_hyphens=break_long_words,
    )

    return wrapper.fill(joined).splitlines()


def wrap(
    buffer: Buffer, text: str, width_input: int = 80, break_long_words: bool = False
) -> BufferAction:
    preserve_trailing_newline = text.endswith("\n")

    lines = text.splitlines()
    wrapped_lines = []
    paragraph: list[str] = []

    for line in lines:
        if line.strip() == "":
            if paragraph:
                wrapped_lines.extend(
                    wrap_paragraph(paragraph, width_input, break_long_words)
                )
                paragraph = []
            wrapped_lines.append("")
        else:
            paragraph.append(line)

    if paragraph:
        wrapped_lines.extend(wrap_paragraph(paragraph, width_input, break_long_words))

    result = "\n".join(wrapped_lines)

    if preserve_trailing_newline:
        result += "\n"

    return BufferAction(
        action_type=BufferActionTypeEnum.REPLACE,
        content=(text, result),
        cursor_position=buffer.get_cursor_position(),
    )


def shuffle_lines(buffer: Buffer, text: str) -> BufferAction:
    preserve_trailing_newline = text.endswith("\n")
    lines = text.splitlines()

    random.shuffle(lines)

    new_text = "\n".join(lines)

    if preserve_trailing_newline:
        new_text += "\n"

    return BufferAction(
        action_type=BufferActionTypeEnum.REPLACE,
        content=(text, new_text),
        cursor_position=buffer.get_cursor_position(),
    )


def slugify_line(line: str) -> str:
    line = unicodedata.normalize("NFKD", line)
    line = line.encode("ascii", "ignore").decode("ascii")
    line = line.lower()
    line = re.sub(r"[^a-z0-9]+", "-", line)
    line = re.sub(r"-+", "-", line)

    return line.strip("-")


def slugify(buffer: Buffer, text: str) -> BufferAction:
    preserve_trailing_newline = text.endswith("\n")
    lines = text.splitlines()

    result = [slugify_line(line) for line in lines]

    new_text = "\n".join(result)

    if preserve_trailing_newline:
        new_text += "\n"

    return BufferAction(
        action_type=BufferActionTypeEnum.REPLACE,
        content=(text, new_text),
        cursor_position=buffer.get_cursor_position(),
    )


def _to_int(s: str, default: int = 0) -> int:
    s = (s or "").strip()
    if s.lstrip("-").isdigit():
        return int(s)
    return default


def column_edit(
    buffer: Buffer,
    text: str,
    mode: str,
    start_col: int,
    end_col: int,
    insert_text: str,
    selection_start: tuple[int, int],
) -> BufferAction:
    start_row, _ = selection_start
    end_row, _ = buffer.get_cursor_position()

    if start_row > end_row:
        start_row, end_row = end_row, start_row

    lines = text.splitlines()
    preserve_trailing_newline = text.endswith("\n")

    new_lines = list(lines)

    if mode == "insert":
        col = start_col
        if col < 0:
            col = 0

        for i in range(0, len(lines)):
            line = lines[i]
            if len(line) < col:
                line = line.ljust(col)
            new_lines[i] = line[:col] + insert_text + line[col:]

    elif mode in ("replace", "delete"):
        left = min(start_col, end_col)
        right = max(start_col, end_col)

        if left < 0:
            left = 0
        if right < 0:
            right = 0

        for i in range(0, len(lines)):
            line = lines[i]

            if len(line) < right:
                line = line.ljust(right)

            if mode == "replace":
                new_lines[i] = line[:left] + insert_text + line[right:]
            else:
                new_lines[i] = line[:left] + line[right:]

    new_text = "\n".join(new_lines)
    if preserve_trailing_newline:
        new_text += "\n"

    return BufferAction(
        action_type=BufferActionTypeEnum.REPLACE,
        content=(text, new_text),
        cursor_position=CursorPosition(y=start_row, x=0),
    )


def _sort_text(text: str, reverse: bool) -> str:
    lines = text.splitlines()
    return "\n".join(sorted(lines, key=lambda l: l.lstrip().lower(), reverse=reverse))


def sort_lines(buffer: Buffer, text: str, reverse: bool) -> BufferAction:
    action = BufferAction(
        action_type=BufferActionTypeEnum.REPLACE,
        content=(text, _sort_text(text, reverse)),
        cursor_position=buffer.get_cursor_position(),
    )
    return action
