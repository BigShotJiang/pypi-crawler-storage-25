from __future__ import annotations

import curses
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from denary.editor import SimpleEditor


def send_notification(
    window: curses.window,
    message: str,
    duration: int = 500,
    editor: Optional[SimpleEditor] = None,
):
    try:
        height, width = window.getmaxyx()

        if height < 3 or width < 3:
            return  # terminal too small

        y = height - 2
        safe_width = max(1, width - 1)

        padded = message.ljust(safe_width)

        window.move(y, 0)
        window.clrtoeol()
        window.addstr(y, 0, padded[:safe_width])
        window.refresh()

        if duration <= 0:
            if (
                editor is not None
                and editor.current_macro_playing_index is not None
                and editor.current_macro_playing_name is not None
            ):
                editor.current_macro_playing_index += 1
                curses.napms(200)
            else:
                window.nodelay(False)
                window.getch()
        else:
            curses.napms(duration)

        curses.flushinp()

    except curses.error:
        # Rendering must never crash the editor
        pass


def send_multiline_notification(
    window: curses.window,
    message: str,
    duration: int = 500,
    editor: Optional[SimpleEditor] = None,
) -> float:
    try:
        height, width = window.getmaxyx()

        if height < 3 or width < 3:
            return 0

        safe_width = max(1, width - 1)

        lines = message.split("\n")

        for i, line in enumerate(reversed(lines[: height - 2])):
            y = height - (2 + i)
            padded = line.ljust(safe_width)

            window.move(y, 0)
            window.clrtoeol()
            window.addstr(y, 0, padded[:safe_width], curses.A_REVERSE)

        window.refresh()

        res: float = 0

        if duration <= 0:
            if (
                editor is not None
                and editor.current_macro_playing_index is not None
                and editor.current_macro_playing_name is not None
            ):
                editor.current_macro_playing_index += 1
                curses.napms(200)
            else:
                window.nodelay(False)
                res = window.getch()
        else:
            curses.napms(duration)

        curses.flushinp()
        return res

    except curses.error:
        return 0
