import asyncio
import re
import subprocess
from pathlib import Path
from typing import Any, NotRequired, Optional, TypedDict


def run_git_command(args: list[str], cwd: str = ".") -> str:
    """Run a git command and return output as text."""
    result = subprocess.run(
        ["git"] + args,
        cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        encoding="utf-8",
        errors="replace",
        text=True,
        timeout=10,  # timeout in seconds
    )
    if result.returncode != 0:
        raise Exception(f"Git error: {result.stderr.strip()}")
    return result.stdout.strip()


def is_inside_git_repo(path=".") -> bool:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            cwd=path,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        return result.returncode == 0 and result.stdout.strip() == "true"
    except Exception:
        return False


def git_branches(cmd=".") -> str:
    return run_git_command(["branch", "-a"], cmd)


def get_current_branch(cmd: str = ".") -> str:
    if not is_inside_git_repo(cmd):
        return "--"

    try:
        branches = git_branches(cmd)
        if len(v := [b for b in branches.split("\n") if b.startswith("*")]) > 0:
            return v[0].split("*")[-1].strip()
    except Exception:
        pass

    return "--"


def get_status(cwd=".") -> str:
    return run_git_command(["status"], cwd)


def get_diff(
    file_path: str | None = None,
    cwd: str = ".",
    staged: bool = False,
    compare_branch: str | None = None,
    exclude_patterns: list[str] | None = None,
) -> str:
    args = ["diff"]

    if compare_branch:
        args.append(f"{compare_branch}...HEAD")
    elif staged:
        args.append("--cached")

    if file_path or exclude_patterns:
        args.append("--")

        if file_path:
            args.append(file_path)
        else:
            args.append(".")

        if exclude_patterns:
            for pattern in exclude_patterns:
                args.append(f":(exclude){pattern}")

    return run_git_command(args, cwd)


def commit_all(message, cwd=".") -> str:
    run_git_command(["add", "."], cwd)
    return run_git_command(["commit", "-m", repr(message)], cwd)


def get_log(limit=10, cwd=".") -> str:
    return run_git_command(["log", f"-n{limit}", "--oneline"], cwd)


def get_blame(file_path, cwd=".") -> str:
    return run_git_command(["blame", file_path], cwd)


def get_blame_line(file_path, line_number, cwd=".") -> tuple[str, str]:
    """
    Get the commit hash and author for a specific line in a file.
    Line number is 1-based.
    """
    result = subprocess.run(
        ["git", "blame", "-L", f"{line_number},{line_number}", file_path],
        cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if result.returncode != 0:
        raise Exception(f"Git blame error: {result.stderr.strip()}")

    # Extract commit hash and author from the output
    match = re.match(r"^([0-9a-f]+) \(([^)]+)", result.stdout.strip())
    if match:
        return match.group(1), match.group(2)
    else:
        raise Exception("Could not parse git blame output.")


def get_diff_lines(file_path) -> str:
    result = subprocess.run(
        ["git", "diff", "--unified=0", "--no-color", file_path],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    return result.stdout


def parse_diff(diff_output) -> dict[int, str]:
    """
    Returns a dict: line_number (1-based) -> change_type ('added', 'modified')
    Only tracks changes in the new file.
    """
    change_map = {}
    old_line_num = 0
    new_line_num = 0

    lines = diff_output.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("@@"):
            m = re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", line)
            if m:
                old_line_num = int(m.group(1))
                new_line_num = int(m.group(3))
            i += 1
            continue

        if line.startswith("+") and not line.startswith("+++"):
            if (
                i > 0
                and lines[i - 1].startswith("-")
                and not lines[i - 1].startswith("---")
            ):
                change_map[new_line_num] = "modified"
            else:
                change_map[new_line_num] = "added"
            new_line_num += 1
            i += 1
            continue
        elif line.startswith("-") and not line.startswith("---"):
            old_line_num += 1
            i += 1
            continue
        else:
            old_line_num += 1
            new_line_num += 1
            i += 1
            continue

    return change_map


def get_file_changes(file_path: str | None) -> dict[int, str]:
    if file_path is None:
        return {}

    if not is_inside_git_repo():
        return {}
    try:
        diff_output = get_diff(file_path)
        change_map = parse_diff(diff_output)
    except Exception:
        return {}

    return change_map


_HUNK_RE = re.compile(
    r"@@ -(?P<old_start>\d+)(?:,(?P<old_len>\d+))?"
    r" \+(?P<new_start>\d+)(?:,(?P<new_len>\d+))? @@"
)


class GitHunk(TypedDict):
    old_start: int
    old_len: int
    new_start: int
    new_len: int

    header: NotRequired[str]
    lines: NotRequired[list[str]]


def parse_hunk_header(line: str) -> GitHunk | None:
    """
    Parse a unified-diff hunk header.

    Example: @@ -10,5 +12,7 @@
    Returns a dict or None.
    """
    m = _HUNK_RE.match(line)
    if not m:
        return None

    return GitHunk(
        **{
            "old_start": int(m.group("old_start")),
            "old_len": int(m.group("old_len") or 1),
            "new_start": int(m.group("new_start")),
            "new_len": int(m.group("new_len") or 1),
        }
    )


def get_diff_hunks(file_path: str) -> list[GitHunk]:
    """
    Return parsed diff hunks for file_path as a list of dicts:

    {
        header: str,
        old_start: int,
        old_len: int,
        new_start: int,
        new_len: int,
        lines: list[str]
    }
    """
    diff = get_diff(file_path)
    hunks = []
    current = None

    for line in diff.splitlines():
        hdr = parse_hunk_header(line)
        if hdr:
            if current:
                hunks.append(current)

            current = GitHunk(
                **{
                    "header": line,
                    **hdr,
                    "lines": [],
                }
            )
            continue

        if current:
            current["lines"].append(line)

    if current:
        hunks.append(current)

    return hunks


def find_previous_hunk_for_line(file_path: str, line_no: int) -> GitHunk | None:
    """
    Return the hunk in which `line_no` falls in the *new file*,
    or if not inside any hunk, the last one above it.

    line_no is 1-based.
    Returns the hunk dict, or None.
    """
    hunks = get_diff_hunks(file_path)
    chosen = None

    for h in hunks:
        start = h["new_start"]
        end = start + h["new_len"]

        if start <= line_no < end:
            return h

        if end <= line_no:
            chosen = h
        else:
            break

    return chosen


async def ais_inside_git_repo(path: str = ".") -> bool:
    try:
        process = await asyncio.create_subprocess_exec(
            "git",
            "-C",
            path,
            "rev-parse",
            "--is-inside-work-tree",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )

        stdout, _ = await process.communicate()
        return process.returncode == 0 and stdout.strip() == b"true"

    except Exception:
        return False


async def aget_current_branch(path: str = ".") -> str:
    if not await ais_inside_git_repo(path):
        return "--"

    try:
        process = await asyncio.create_subprocess_exec(
            "git",
            "-C",
            path,
            "branch",
            "--no-color",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )

        stdout, _ = await process.communicate()

        if process.returncode != 0:
            return "--"

        branches = stdout.decode()

        current = next(
            (
                line[1:].strip()
                for line in branches.splitlines()
                if line.startswith("*")
            ),
            None,
        )

        return current or "--"

    except Exception:
        return "--"


# Cached state (module-level, zero object overhead)
_last_head_mtime: int | None = None
_last_ref_mtime: int | None = None
_last_branch: str | None = None


def _resolve_git_dir(repo_path: str) -> Optional[Path]:
    git_path = Path(repo_path) / ".git"

    if git_path.is_dir():
        return git_path

    if git_path.is_file():
        try:
            content = git_path.read_text().strip()
        except OSError:
            return None

        if content.startswith("gitdir:"):
            return Path(content[7:].strip())

    return None


def get_current_branch_cached(repo_path: str = ".") -> Optional[str]:
    global _last_head_mtime, _last_ref_mtime, _last_branch

    git_dir = _resolve_git_dir(repo_path)
    if not git_dir:
        return None

    head_file = git_dir / "HEAD"

    try:
        head_stat = head_file.stat()
    except OSError:
        return None

    head_mtime = head_stat.st_mtime_ns

    # If HEAD hasn't changed, branch definitely hasn't changed
    if _last_head_mtime == head_mtime:
        return _last_branch

    _last_head_mtime = head_mtime

    # HEAD changed → read once
    try:
        content = head_file.read_text().strip()
    except OSError:
        return None

    if not content.startswith("ref:"):
        # Detached HEAD
        _last_branch = None
        _last_ref_mtime = None
        return None

    ref_path = git_dir / content[5:].strip()
    branch_name = ref_path.name

    try:
        ref_stat = ref_path.stat()
        _last_ref_mtime = ref_stat.st_mtime_ns
    except OSError:
        _last_ref_mtime = None

    _last_branch = branch_name
    return branch_name


if __name__ == "__main__":
    get_current_branch()
