import re

CASE_NONE = 0
CASE_UPPER = 1
CASE_LOWER = 2
CASE_UPPER_NEXT = 3
CASE_LOWER_NEXT = 4


def _get_group_text(match: re.Match, group_ref: str) -> str:
    if group_ref.isdigit():
        value = match.group(int(group_ref))
    else:
        value = match.group(group_ref)
    return "" if value is None else value


def expand_replacement(match: re.Match, replacement: str) -> str:
    result = []
    case_mode = CASE_NONE

    i = 0
    n = len(replacement)

    while i < n:
        c = replacement[i]
        text = None

        if c == "\\" and i + 1 < n:
            nxt = replacement[i + 1]

            # case modifiers
            if nxt == "U":
                case_mode = CASE_UPPER
                i += 2
                continue

            if nxt == "L":
                case_mode = CASE_LOWER
                i += 2
                continue

            if nxt == "E":
                case_mode = CASE_NONE
                i += 2
                continue

            if nxt == "u":
                case_mode = CASE_UPPER_NEXT
                i += 2
                continue

            if nxt == "l":
                case_mode = CASE_LOWER_NEXT
                i += 2
                continue

            # named or explicit group reference: \g<name> or \g<1>
            if nxt == "g" and i + 2 < n and replacement[i + 2] == "<":
                end = replacement.find(">", i + 3)
                if end == -1:
                    raise ValueError("Invalid replacement: missing '>' in \\g<...>")

                group_ref = replacement[i + 3 : end]
                if not group_ref:
                    raise ValueError(
                        "Invalid replacement: empty group name in \\g<...>"
                    )

                text = _get_group_text(match, group_ref)
                i = end + 1

            # numeric backreference: \1, \2, ...
            elif nxt.isdigit():
                j = i + 1
                while j < n and replacement[j].isdigit():
                    j += 1

                group_ref = replacement[i + 1 : j]
                text = _get_group_text(match, group_ref)
                i = j

            # escaped backslash
            elif nxt == "\\":
                text = "\\"
                i += 2

            # other escaped char => treat literally
            else:
                text = nxt
                i += 2

        else:
            text = c
            i += 1

        # apply case transform
        if case_mode == CASE_UPPER:
            text = text.upper()

        elif case_mode == CASE_LOWER:
            text = text.lower()

        elif case_mode == CASE_UPPER_NEXT:
            if text:
                text = text[0].upper() + text[1:]
            case_mode = CASE_NONE

        elif case_mode == CASE_LOWER_NEXT:
            if text:
                text = text[0].lower() + text[1:]
            case_mode = CASE_NONE

        result.append(text)

    return "".join(result)
