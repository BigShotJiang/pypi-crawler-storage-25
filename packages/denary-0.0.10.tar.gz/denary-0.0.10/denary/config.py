import importlib.util
import json
import os
import sys
from pathlib import Path
from typing import Any, TypedDict

from platformdirs import user_config_dir

from denary.lsp.client import LSPClient

EDITOR_NAME = "denary"


class LSPConfig(TypedDict):
    cmd: list[str]
    settings: dict[str, Any]


LSP_CONFIG: dict[str, LSPConfig] = {}
EXT_TO_LANG: dict[str, str] = {}

LOADING_LSPS: set[str] = set()
LOADED_LSPS: dict[str, LSPClient] = {}

STATIC_CONFIG: dict[str, Any] = {}
CURRENT_PLATFORM = sys.platform.lower()

MAX_UNDO = 2_000

MAX_LINE_LIMIT = 500
MAX_SCAN_LINES = 5_000

WORKING_DIR = Path(".")

COMMANDS = [
    # Help / Core
    {"name": "help", "alt_names": ["h"], "description": "Show help documentation"},
    {"name": "qa", "alt_names": [], "description": "Quit editor (confirm)"},
    {"name": "w", "alt_names": [], "description": "Save current buffer"},
    {"name": "open", "alt_names": [], "description": "Open file prompt"},
    {"name": "ls", "alt_names": [], "description": "List open buffers"},
    {"name": "jump_list", "alt_names": [], "description": "List of jumps abilable"},
    {
        "name": "paste_sys",
        "alt_names": [],
        "description": "Paste from system clipboard",
    },
    {
        "name": "cancel_tasks",
        "alt_names": ["ctasks"],
        "description": "Show and cancel running subprocess tasks",
    },
    # Buffers
    {"name": "bufnew", "alt_names": [], "description": "Create new empty buffer"},
    {
        "name": "nextbuf",
        "alt_names": ["nbuf", "next", "n"],
        "description": "Switch to next buffer",
    },
    {
        "name": "prevbuf",
        "alt_names": ["pbuf", "prev", "p"],
        "description": "Switch to previous buffer",
    },
    {
        "name": "deletebuf",
        "alt_names": ["delbuf", "del", "d"],
        "description": "Delete current buffer",
    },
    # Pickers / UI
    {
        "name": "ffr",
        "alt_names": ["ff"],
        "description": "Open file picker (reset search)",
    },
    {"name": "fb", "alt_names": [], "description": "Open buffer picker"},
    {"name": "themes", "alt_names": ["th"], "description": "Open theme picker"},
    {"name": "ex", "alt_names": [], "description": "Open file explorer"},
    {"name": "ln", "alt_names": [], "description": "Toggle line numbers"},
    {"name": "gch", "alt_names": [], "description": "Toggle Git change highlighting"},
    {"name": "brkm", "alt_names": [], "description": "Toggle bracket matching"},
    {
        "name": "change_ai_model",
        "alt_names": [],
        "description": "Change active AI model",
    },
    {"name": "scrolloff", "alt_names": [], "description": "Set scroll offset value"},
    # Markers
    {"name": "marker", "alt_names": ["m"], "description": "Set marker"},
    {"name": "pickmarker", "alt_names": ["pm"], "description": "Open marker picker"},
    {"name": "dm", "alt_names": [], "description": "Delete markers in current buffer"},
    {"name": "dgm", "alt_names": [], "description": "Delete global markers"},
    {"name": "dpm", "alt_names": [], "description": "Delete specific marker"},
    {"name": "dam", "alt_names": [], "description": "Delete all markers"},
    # Text utilities
    {"name": "replace", "alt_names": [], "description": "Regex search and replace"},
    {"name": "comment", "alt_names": [], "description": "Toggle comment on selection"},
    {"name": "filetype", "alt_names": [], "description": "Set buffer filetype / lexer"},
    {
        "name": "filepath",
        "alt_names": [],
        "description": "Insert file path into buffer",
    },
    {
        "name": "datetime",
        "alt_names": [],
        "description": "Insert current date and time",
    },
    {"name": "date", "alt_names": [], "description": "Insert current date"},
    {"name": "uuid", "alt_names": [], "description": "Insert random UUID"},
    {"name": "clear_registers", "alt_names": [], "description": "Clear all registers"},
    {"name": "capitalize", "alt_names": [], "description": "Capitalize selection"},
    {"name": "upper", "alt_names": [], "description": "Convert selection to uppercase"},
    {"name": "lower", "alt_names": [], "description": "Convert selection to lowercase"},
    # Advanced text actions
    {
        "name": "rejoin",
        "alt_names": [],
        "description": "Split and rejoin text by delimiter",
    },
    {"name": "align", "alt_names": [], "description": "Align text by separator"},
    {
        "name": "unique_lines",
        "alt_names": ["dedup"],
        "description": "Remove duplicate lines",
    },
    {"name": "reverse_lines", "alt_names": [], "description": "Reverse line order"},
    {"name": "trim", "alt_names": [], "description": "Trim whitespace (both sides)"},
    {"name": "trim_l", "alt_names": [], "description": "Trim left whitespace"},
    {"name": "trim_r", "alt_names": [], "description": "Trim right whitespace"},
    {"name": "number_lines", "alt_names": [], "description": "Add line numbers"},
    {
        "name": "remove_empty_lines",
        "alt_names": [],
        "description": "Remove empty lines",
    },
    {"name": "wrap", "alt_names": [], "description": "Wrap text to width"},
    {"name": "shuffle_lines", "alt_names": [], "description": "Shuffle lines randomly"},
    {"name": "slugify", "alt_names": [], "description": "Convert text to URL slug"},
    {
        "name": "column_edit",
        "alt_names": [],
        "description": "Column-based insert/replace/delete",
    },
    {"name": "sort", "alt_names": [], "description": "Sort lines ascending"},
    {"name": "sort_r", "alt_names": [], "description": "Sort lines descending"},
    # AI
    {"name": "ai", "alt_names": [], "description": "Send custom instruction to AI"},
    {"name": "ai_gen", "alt_names": [], "description": "Generate code at cursor"},
    {"name": "ai_review", "alt_names": [], "description": "Review Git diff with AI"},
    {
        "name": "ai_commit_message",
        "alt_names": [],
        "description": "Generate commit message from diff",
    },
    {"name": "ai_get", "alt_names": [], "description": "Retrieve AI result at cursor"},
    {"name": "ai_show", "alt_names": [], "description": "Show AI completion picker"},
    {
        "name": "ai_remove",
        "alt_names": [],
        "description": "Cancel/remove AI completion",
    },
    # LSP
    {
        "name": "lsp_diagnostics",
        "alt_names": [],
        "description": "Show buffer diagnostics",
    },
    {"name": "lsp_hover", "alt_names": [], "description": "Show hover information"},
    {"name": "lsp_definition", "alt_names": [], "description": "Go to definition"},
    {"name": "lsp_references", "alt_names": [], "description": "Find references"},
    {"name": "lsp_refresh", "alt_names": [], "description": "Restart LSP for buffer"},
    {
        "name": "lsp_code_action",
        "alt_names": [],
        "description": "Show available code actions",
    },
    {
        "name": "lsp_line_diagnostics",
        "alt_names": [],
        "description": "Show diagnostics for current line",
    },
    {
        "name": "lsp_clear_diagnostics",
        "alt_names": [],
        "description": "Clear all diagnostics",
    },
    {
        "name": "lsp_clear_line_diag",
        "alt_names": ["clrld"],
        "description": "Clear diagnostics for current line",
    },
    # Git
    {"name": "git_status", "alt_names": [], "description": "Show Git status"},
    {"name": "git_diff", "alt_names": [], "description": "Show Git diff"},
    {
        "name": "git_hunk",
        "alt_names": [],
        "description": "Show previous version of current hunk",
    },
    {"name": "git_commit_all", "alt_names": [], "description": "Commit all changes"},
    {
        "name": "git_blame",
        "alt_names": [],
        "description": "Show Git blame for current line",
    },
    {"name": "git_log", "alt_names": [], "description": "Show Git commit history"},
    {
        "name": "git_refresh",
        "alt_names": [],
        "description": "Refresh Git change indicators",
    },
    # External tools
    {
        "name": "lazygit",
        "alt_names": ["gg"],
        "description": "Open lazygit external TUI",
    },
    {"name": "fzf", "alt_names": [], "description": "Search files using fzf"},
    {"name": "eval", "alt_names": [], "description": "Evaluate Python code"},
    {
        "name": "req",
        "alt_names": [],
        "description": "Execute HTTP request from selection",
    },
]


def get_config_path() -> str:
    config_dir = user_config_dir(EDITOR_NAME)
    return os.path.join(config_dir, "init.py")


def get_config_dir() -> Path:
    config_dir = user_config_dir(EDITOR_NAME)
    if not os.path.exists(config_dir):
        os.makedirs(config_dir, exist_ok=True)
    return Path(config_dir)


CONFIG_PATH = get_config_path()
STATIC_CONFIG_PATH = get_config_dir() / "static_config.json"


def load_user_lsp_config(
    config_path: str | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    global LSP_CONFIG, EXT_TO_LANG

    if config_path is None:
        config_path = CONFIG_PATH

    if not os.path.exists(config_path):
        return {}, {}

    spec = importlib.util.spec_from_file_location("user_lspconfig", config_path)

    if spec is not None and spec.loader is not None:
        mod = importlib.util.module_from_spec(spec)

        if mod is not None:
            spec.loader.exec_module(mod)

            LSP_CONFIG, EXT_TO_LANG = getattr(mod, "LSP_CONFIG", {}), getattr(
                mod, "EXT_TO_LANG", {}
            )

    return LSP_CONFIG, EXT_TO_LANG


def save_static_config() -> None:
    global STATIC_CONFIG

    with STATIC_CONFIG_PATH.open("w") as f:
        f.write(json.dumps(STATIC_CONFIG))


def load_static_config() -> None:
    global STATIC_CONFIG

    if STATIC_CONFIG_PATH.exists():
        with STATIC_CONFIG_PATH.open() as f:
            STATIC_CONFIG = json.loads(f.read())


if __name__ == "__main__":
    # Example: find config path (use platformdirs or fallback as above)
    user_lsp_config, user_ext_to_lang = load_user_lsp_config(CONFIG_PATH)
    print(CONFIG_PATH)
    print(os.path.exists(CONFIG_PATH))
    print(user_lsp_config)
    print(user_ext_to_lang)
