import pickle

from denary.config import get_config_dir
from denary.syntax.gen_comments import generate_comments

config_path = get_config_dir()
data_path = config_path / "language_comments.pkl"

try:
    with open(data_path, "rb") as f:
        COMMENT_DATA = pickle.load(f)

except (FileNotFoundError, EOFError, pickle.UnpicklingError):
    COMMENT_DATA = generate_comments()
