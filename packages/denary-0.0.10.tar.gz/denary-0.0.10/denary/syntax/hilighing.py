from __future__ import annotations

import curses
import inspect
import math
import re
import time
from dataclasses import dataclass
from functools import lru_cache, wraps
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Generator,
    Iterable,
    Iterator,
    NamedTuple,
    TypedDict,
)

from pygments.lexer import Lexer, RegexLexer
from pygments.lexers import (
    HtmlDjangoLexer,
    JavascriptLexer,
    TextLexer,
    TOMLLexer,
    get_lexer_for_filename,
)
from pygments.token import *
from pygments.token import Error, Generic, Token, Whitespace, _TokenType
from pygments.util import ClassNotFound

from denary.config import MAX_LINE_LIMIT
from denary.key_mappings import BRACKETS
from denary.syntax.comments import COMMENT_DATA
from denary.syntax.custom_lexers import (
    CsvAlternatingLexer,
    EditorHttpRequestLexer,
    KivyLexer,
    ModernCSharpLexer,
)

if TYPE_CHECKING:
    from denary.buf import Buffer


type _Lexer = Lexer | RegexLexer
type _TokenResult = tuple[int, _TokenType, str]
type _SubLexerKey = tuple[str, int]
type _StackEntry = (
    str | tuple[str, tuple[tuple[_SubLexerKey, "_Stack"], ...]]  # should be _SUB
)
type _Stack = tuple[_StackEntry, ...]
type _SubLexerStack = dict[_SubLexerKey, _Stack]


class UsingInfo(TypedDict):
    other: type[Any]
    kwargs: dict[str, Any]
    child_stack: _Stack


class HilightedLine(NamedTuple):
    """
    Represents a highlighted segment of a line in the editor.
    Contains the line number, start and end column indices, and the attribute index.
    """

    y: int  # line number (0-based)
    start: int  # start column (0-based)
    end: int  # end column (0-based)
    attr: int  # attribute index for color/curses pair


class Diagnostic(NamedTuple):
    """
    Represents a diagnostic message for a line in the editor.
    Contains the line number, column index, and the message text.
    """

    line: int  # line number (0-based)
    char: int  # column index (0-based)
    code: str  # diagnostic code (e.g., "E123", "W456")
    message: str  # diagnostic message text
    severity: int  # severity level (e.g., "error", "warning", "info")


def adaptive_global_limit(
    *,
    target_ms=33.0,
    min_limit=1000,
    max_limit=200_000,
    downscale=0.7,  # stronger reduction
    upscale=1.05,
    ema_alpha=0.2,
    measure_every=3,
    increase_cooldown=6,  # cooldown ONLY for increases
):
    slow_th = target_ms * 1.05
    fast_th = target_ms * 0.75
    perf = time.perf_counter

    def decorator(func):
        ema = None
        frame = 0
        inc_cooldown = 0
        collapsed = False  # ⬅ infinity collapse flag

        @wraps(func)
        def wrapper(*args, **kwargs):
            global MAX_LINE_LIMIT
            nonlocal ema, frame, inc_cooldown, collapsed

            t0 = perf()
            result = func(*args, **kwargs)
            dt = (perf() - t0) * 1000.0

            if ema is None:
                ema = dt
            else:
                ema += (dt - ema) * ema_alpha

            frame += 1
            if frame % measure_every != 0:
                return result

            limit = MAX_LINE_LIMIT

            if ema > slow_th:
                if limit is math.inf:
                    limit = max_limit
                    collapsed = True
                limit = max(min_limit, int(limit * downscale))
                MAX_LINE_LIMIT = limit
                return result

            if ema < fast_th and limit is not math.inf:
                if inc_cooldown > 0:
                    inc_cooldown -= 1
                    return result

                limit = min(max_limit, int(limit * upscale))
                MAX_LINE_LIMIT = limit
                inc_cooldown = increase_cooldown

            return result

        return wrapper

    return decorator


def build_256_color_map() -> dict[int, int]:
    """
    Returns a dict mapping each background color (0-255)
    to a fixed readable foreground color (0-255).
    """

    color_map = {}

    overrides = {
        0: 15,  # Black -> White
        1: 15,  # Red -> White
        2: 15,  # Green -> White
        3: 0,  # Yellow -> Black
        4: 15,  # Blue -> White
        5: 15,  # Magenta -> White
        6: 0,  # Cyan -> Black
        7: 0,  # Light gray -> Black
        8: 15,  # Dark gray -> White
        9: 15,  # Bright red -> White
        10: 0,  # Bright green -> Black
        11: 0,  # Bright yellow -> Black
        12: 15,  # Bright blue -> White
        13: 15,  # Bright magenta -> White
        14: 0,  # Bright cyan -> Black
        15: 0,  # White -> Black
    }

    for i in range(16):
        color_map[i] = overrides[i]

    for i in range(16, 232):
        c = i - 16
        r = (c // 36) % 6 * 51
        g = (c // 6) % 6 * 51
        b = (c % 6) * 51

        brightness = (0.2126 * r) + (0.7152 * g) + (0.0722 * b)

        color_map[i] = 0 if brightness > 140 else 15

    for i in range(232, 256):
        gray = (i - 232) * 10 + 8
        brightness = 0.2126 * gray + 0.7152 * gray + 0.0722 * gray

        color_map[i] = 0 if brightness >= 150 else 15

    return color_map


def init_256_color_pairs(offset: int = 50) -> None:
    """
    Initialize 256 curses color pairs with a fixed offset.
    Returns a dict mapping: color_number -> curses_pair_id (color + offset)
    """
    mappings = build_256_color_map()
    if not curses.has_colors():
        raise RuntimeError("Terminal does not support colors")
    curses.start_color()
    curses.use_default_colors()

    for color in range(0, 256):
        pair_id = color + offset
        try:
            curses.init_pair(pair_id, mappings[color], color)
        except Exception:
            pass


CSS_COLOR_256 = {
    "black": 0,  # curses.COLOR_BLACK
    "maroon": 1,  # dark red
    "green": 2,
    "olive": 3,  # dark yellow
    "gold": 3,  # dark yellow
    "navy": 4,  # dark blue
    "purple": 5,  # dark magenta / indigo-ish
    "magenta": 5,  # dark magenta / indigo-ish
    "indigo": 5,  # dark magenta / indigo-ish
    "teal": 6,  # dark cyan
    "silver": 7,  # light gray
    "gray": 8,  # dark gray
    "red": 9,
    "lime": 10,  # bright green
    "yellow": 11,
    "blue": 12,
    "pink": 13,  # bright magenta
    "cyan": 14,
    "white": 15,
}


def hex_to_256(hex_color: str) -> int:
    """
    Convert #RGB or #RRGGBB hex to the nearest xterm-256 color.
    """
    hex_color = hex_color.lstrip("#")
    if len(hex_color) == 3:
        hex_color = "".join(c * 2 for c in hex_color)
    if len(hex_color) != 6:
        return 15
    r, g, b = int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)

    r6 = round(r / 255 * 5)
    g6 = round(g / 255 * 5)
    b6 = round(b / 255 * 5)
    res = 16 + 36 * r6 + 6 * g6 + b6

    assert res < 256 and res > -1

    return 16 + 36 * r6 + 6 * g6 + b6


def default_color_mapper(color: int) -> int:
    """
    Default mapper: add 1000 to the 256-color code (matches curses.init_pair prefix).
    """
    return 50 + color


CSS_COLOR_256_LC = {k.lower(): v for k, v in CSS_COLOR_256.items()}

_COLOR_WORDS_ALT = "|".join(
    re.escape(k) for k in sorted(CSS_COLOR_256_LC.keys(), key=len, reverse=True)
)

COLOR_PATTERN = re.compile(
    rf"\b(?P<word>(?i:{_COLOR_WORDS_ALT}))\b|(?P<hex>\#(?:[0-9a-fA-F]{{3}}|[0-9a-fA-F]{{6}}))"
)


@lru_cache(maxsize=2048)
def _hex_to_attr(hex_str: str, mapper_id: int) -> int:
    return hex_to_256(hex_str)


def color_highlighter(
    line: str, color_mapper: Callable[[int], int] | None = None, y: int = 0
) -> list[HilightedLine]:
    if color_mapper is None:
        color_mapper = default_color_mapper

    spans: list[HilightedLine] = []
    HL = HilightedLine
    cmap = CSS_COLOR_256_LC
    finditer = COLOR_PATTERN.finditer

    is_default_mapper = color_mapper is default_color_mapper

    mid = id(color_mapper)

    for m in finditer(line):
        s, e = m.start(), m.end()

        w = m.group("word")
        if w is not None:
            code = cmap[w.lower()]
            attr = (50 + code) if is_default_mapper else color_mapper(code)
            spans.append(HL(y=y, start=s, end=e, attr=attr))
            continue

        hx = m.group("hex")
        if hx is not None:
            code256 = _hex_to_attr(hx.lower(), mid)
            attr = (50 + code256) if is_default_mapper else color_mapper(code256)
            spans.append(HL(y=y, start=s, end=e, attr=attr))

    return spans


SEVERITY_COLORS = {
    1: 32,  # Error (red)
    2: 33,  # Warning (yellow)
    3: 34,  # Information (cyan)
    4: 35,  # Hint (magenta)
}


@lru_cache(maxsize=500)
def get_token_attr(token_type: type) -> int:
    # Token.Generic.Subheading
    # Token.Comment.Single
    # Token.Keyword
    # Token.Keyword.Constant
    # Token.Keyword.Namespace
    # Token.Keyword.Type
    # Token.Literal.Number.Float
    # Token.Literal.Number.Integer
    # Token.Literal.String.Affix
    # Token.Literal.String.Doc
    # Token.Literal.String.Double
    # Token.Literal.String.Interpol
    # Token.Literal.String.Single
    # Token.Name
    # Token.Name.Builtin
    # Token.Name.Builtin.Pseudo
    # Token.Name.Class
    # Token.Name.Exception
    # Token.Name.Function
    # Token.Name.Function.Magic
    # Token.Name.Namespace
    # Token.Name.Variable.Magic
    # Token.Operator
    # Token.Operator.Word
    # Token.Punctuation
    # Token.Text
    # Token.Text.Whitespace

    match token_type:
        case Token.Comment | Token.Comment.Single | Token.Comment.Multiline:
            return 2

        case (
            Token.Keyword
            | Token.Keyword.Namespace
            | Token.Keyword.Declaration
            | Token.Literal.String.Char
            | Token.Keyword.Reserved
        ):
            return 3

        case (
            Token.Literal.Number.Integer
            | Token.Literal.Number.Float
            | Token.Number
            | Token.Keyword.Constant
        ):
            return 7

        case (
            Token.Literal.String
            | Token.Literal.String.Affix
            | Token.Literal.String.Doc
            | Token.Literal.String.Double
            | Token.Literal.String.Interpol
            | Token.Literal.String.Single
            | Token.Literal.String.Backtick
        ):
            return 4

        case (
            Token.Name.Builtin
            | Token.Name.Function
            | Token.Name.Function.Magic
            | Token.Generic.Subheading
        ):
            return 5

        case (
            Token.Name.Class
            | Token.Name.Function
            | Token.Name.Namespace
            | Token.Name.Variable.Magic
            | Token.Name.Exception
            | Token.Name.Builtin.Pseudo
            | Token.Comment.Preproc
            | Token.Comment.Single
            | Token.Name.Tag
            | Token.Name.Decorator
            | Token.Keyword.Type
            | Token.Keyword.Pseudo
        ):
            return 6

        case Token.Name | Token.Text | Token.Text.Whitespace:
            return 1

        case (
            Token.Operator
            | Token.Operator.Word
            | Token.Punctuation
            | Token.Name.Attribute
        ):
            return 8

        case Generic.Inserted:
            return 40

        case Generic.Deleted:
            return 41

        case _:
            return 1


@lru_cache(maxsize=503)
def get_lexer(suffix: str) -> _Lexer:
    if suffix in (".j2", ".jinja2", ".jinja"):
        lexer = HtmlDjangoLexer()
    elif suffix == ".kv":
        lexer = KivyLexer()
    elif suffix == ".cs":
        lexer = ModernCSharpLexer()
    elif suffix == ".csv":
        lexer = CsvAlternatingLexer()
        # lexer = CsvLexer()

    elif suffix in (".http", ".req"):
        lexer = EditorHttpRequestLexer()
    # elif suffix in (".md", ".markdown"):
    #     lexer = SimpleMarkdownLexer()
    else:
        try:
            lexer = get_lexer_for_filename(f"file{suffix}")
        except ClassNotFound:
            lexer = TextLexer()

    return lexer


ROOT_STACK = ("root",)


def is_complex_lexer(lexer) -> bool:
    """
    Detect if a lexer is too complex for custom incremental engine.
    """

    name = getattr(lexer, "name", "").lower()
    aliases = [a.lower() for a in getattr(lexer, "aliases", [])]

    KNOWN_COMPLEX = {
        # "markdown",
        # "md",
        # "rst",
        # "restructuredtext",
        # "toml",
        # "html",
        # "xml",
        "csv_alt",
    }

    if name in KNOWN_COMPLEX or any(a in KNOWN_COMPLEX for a in aliases):
        return True

    return False


def is_regex_lexer(obj: _Lexer) -> bool:
    if isinstance(obj, type):
        return issubclass(obj, RegexLexer)
    return isinstance(obj, RegexLexer)


def _get_tokens_and_stack(
    lexer: _Lexer, code: str, stack: _Stack = ROOT_STACK
) -> tuple[list[_TokenResult], _Stack]:
    is_regex = is_regex_lexer(lexer)

    gen: Generator[_TokenResult, None, _Stack] | Iterator[_TokenResult] | None = None

    if is_regex:
        if stack:
            gen = lex_with_state(lexer, code, stack)
        else:
            gen = lex_with_state(lexer, code)
    else:
        gen = lexer.get_tokens_unprocessed(code)

    tokens = []

    try:
        while True:
            tokens.append(next(gen))

    except StopIteration as e:

        if not is_regex:
            final_state = ROOT_STACK
        else:
            final_state = e.value

    return tokens, final_state


def get_tokens_and_stack(
    lexer: _Lexer, code: str, stack: _Stack = ROOT_STACK
) -> tuple[list[_TokenResult], _Stack]:
    if not is_complex_lexer(lexer):
        try:
            return _get_tokens_and_stack(lexer, code, stack)
        except Exception:
            pass

    tokens = list(lexer.get_tokens_unprocessed(code))
    return tokens, ROOT_STACK


@adaptive_global_limit(target_ms=20.0)
def highlight_with_pygments(
    code_lines: list,
    lexer: _Lexer,
    start_line: int,
    end_line: int,
    buffer: Buffer,
    width: int = 500,
    height: int = int(MAX_LINE_LIMIT / 2),
) -> None:
    n = len(code_lines)

    if isinstance(lexer, TextLexer):
        buffer.deverge_state = n
        return

    bs = max(0, start_line)
    be = min(n, end_line)

    dirty_from = buffer.deverge_state

    if be < dirty_from:
        return

    bs = min(bs, dirty_from)

    HL = HilightedLine
    get_attr = get_token_attr
    lines_to_process = [i for i in range(bs, be)][: max(MAX_LINE_LIMIT, height)]

    for ln in lines_to_process:
        if ln < dirty_from:
            continue

        line = code_lines[ln]

        if ln == 0:
            stack = ROOT_STACK
        else:
            stack = code_lines[ln - 1].state

        toks, new_stack = get_tokens_and_stack(lexer, line, stack)

        hls: list[HilightedLine] = []
        append = hls.append

        for so, ttype, val in toks:
            attr = get_attr(ttype)
            if val.isspace() and attr == 1:
                continue
            append(HL(ln, so, so + len(val), attr))

        old_state = line.state
        old_tokens = line.tokens

        if (
            ln <= be
            and ln >= dirty_from
            and old_state == new_stack
            and old_tokens == hls
        ):
            for i, line in enumerate(buffer.lines[ln:], start=ln):
                if line.state is None or line.tokens is None:
                    buffer.deverge_state = i
                    line.state = None
                    line.tokens = None
                    break
            else:
                buffer.deverge_state = n - 1

            dirty_form = buffer.deverge_state

            continue

        if isinstance(stack, list) or isinstance(stack, tuple) or stack:
            line.state = new_stack
        else:
            line.state = ROOT_STACK

        line.tokens = hls

        if line._bracket_cache is None:
            line._bracket_cache = [(i, c) for i, c in enumerate(line) if c in BRACKETS]

        buffer.deverge_state = ln + 1


COMMENT_PREFIX = {
    ".py": "#",
    ".sh": "#",
    ".js": "//",
    ".jsx": "//",
    ".ts": "//",
    ".tsx": "//",
    ".c": "//",
    ".cpp": "//",
    ".java": "//",
    ".html": "<!--",
    ".xml": "<!--",
    ".sql": "--",
    ".cs": "//",
}


def get_suffix_from_filename(filename: str) -> str:
    """
    Fast suffix extraction without pathlib.
    Returns extension including dot (e.g. ".py") or "" if none.
    """
    if filename is not None:
        idx = filename.rfind(".")
        return filename[idx:].lower() if idx != -1 else ""

    return ""


@lru_cache(maxsize=1000)
def lookup_prefix_from_extension(ext: str) -> str | tuple[str, str]:
    """
    Get the comment prefix based on the file extension.
    Returns a single-line comment prefix or a tuple of multi-line start and end prefixes.
    """
    ext = ext.lower()
    for lang in COMMENT_DATA:
        if ext in lang["file_extensions"]:
            if lang["single_line_comment"]:
                return lang["single_line_comment"] + " "
            elif lang["multi_line_comment_start"] and lang["multi_line_comment_end"]:
                return (
                    lang["multi_line_comment_start"] + " ",
                    lang["multi_line_comment_end"],
                )

    return "# "  # default


EXT_TO_COMMENT: dict[str, str | tuple[str, str]] = {}

for lang in COMMENT_DATA:
    for ext in lang["file_extensions"]:
        if lang["single_line_comment"]:
            EXT_TO_COMMENT[ext] = lang["single_line_comment"] + " "
        elif lang["multi_line_comment_start"] and lang["multi_line_comment_end"]:
            EXT_TO_COMMENT[ext] = (
                lang["multi_line_comment_start"] + " ",
                lang["multi_line_comment_end"],
            )


def lookup_prefix(filename: str) -> str | tuple[str, str]:
    """
    O(1) lookup using precomputed EXT_TO_COMMENT map.
    Falls back to "# " if extension is unknown.
    """
    ext = get_suffix_from_filename(filename)
    return EXT_TO_COMMENT.get(ext, "# ")


def get_suffix_from_lexer(lexer: _Lexer) -> list[str]:
    suffixes = [pattern.replace("*", "") for pattern in lexer.filenames]
    return suffixes


_SUB = "__sublexers__"
_USING_INFO_CACHE: dict[Any, Any] = {}
_CHILD_LEXER_CACHE: dict[Any, Any] = {}


def ensure_trailing_newlines_per_line(text: str) -> str:
    """
    Faster normalization:
    - preserves empty string
    - guarantees each logical line ends with '\n'
    - avoids generator overhead
    """
    if not text:
        return ""

    # Fast path: already line-terminated
    if text.endswith("\n") and "\r" not in text:
        return text

    lines = text.splitlines()
    if not lines:
        return ""
    return "\n".join(lines) + "\n"


def _split_stack(stack: _Stack) -> tuple[tuple[str, ...], _SubLexerStack]:
    if not stack:
        return ("root",), {}

    last = stack[-1]

    # If last entry is the sublexer marker
    if isinstance(last, tuple) and last and isinstance(last[0], tuple):
        parent_entries = stack[:-1]
        sub: _SubLexerStack = dict(last)
    else:
        parent_entries = stack
        sub = {}

    # Explicit narrowing to str
    parent: tuple[str, ...] = tuple(
        entry for entry in parent_entries if isinstance(entry, str)
    )

    return parent or ("root",), sub


def _join_stack(parent: _Stack, sub: _SubLexerStack) -> _Stack:
    if not sub:
        return tuple(parent)
    return tuple(parent) + ((_SUB, tuple(sub.items())),)


def _get_using_info_cached(action: Callable[..., Any]) -> UsingInfo | None:
    cached = _USING_INFO_CACHE.get(action, Ellipsis)
    if cached is not Ellipsis:
        return cached

    if not callable(action):
        _USING_INFO_CACHE[action] = None
        return None

    try:
        nonlocals_ = inspect.getclosurevars(action).nonlocals
    except Exception:
        _USING_INFO_CACHE[action] = None
        return None

    gt_kwargs = nonlocals_.get("gt_kwargs")
    kwargs = nonlocals_.get("kwargs")
    other = nonlocals_.get("_other")

    if not isinstance(gt_kwargs, dict) or not isinstance(kwargs, dict) or other is None:
        _USING_INFO_CACHE[action] = None
        return None

    info = UsingInfo(
        **{
            "other": other,
            "kwargs": kwargs,
            "child_stack": tuple(gt_kwargs.get("stack", ("root",))),
        }
    )
    _USING_INFO_CACHE[action] = info
    return info


def _is_pop_state(new_state: str) -> bool:
    return new_state == "#pop" or new_state == -1


def _should_suppress_pop_for_partial_sublexer_match(
    text_len: int,
    match_end: int,
    info: UsingInfo | None,
    new_state: str,
) -> bool:
    if info is None:
        return False
    if not _is_pop_state(new_state):
        return False
    return match_end == text_len


def _get_cached_child_lexer(
    parent_lexer: _Lexer,
    action: Callable[..., Any],
    info: UsingInfo,
) -> _Lexer:
    key = (parent_lexer.__class__, action)
    lx = _CHILD_LEXER_CACHE.get(key)
    if lx is not None:
        return lx

    parent_options = getattr(parent_lexer, "options", None)
    if parent_options:
        opts = dict(parent_options)
        opts.update(info["kwargs"])
    else:
        opts = dict(info["kwargs"])

    lx = info["other"](**opts)
    _CHILD_LEXER_CACHE[key] = lx
    return lx


def _purge_sublexers_for_states(
    sublexer_stacks: _SubLexerStack, states: Iterable[str]
) -> None:
    if not sublexer_stacks:
        return

    states = set(states)
    for key in tuple(sublexer_stacks):
        if key[0] in states:
            sublexer_stacks.pop(key, None)


def lex_with_state(
    lexer: _Lexer, text: str, stack: _Stack = ("root",)
) -> Generator[_TokenResult, None, _Stack]:
    if not hasattr(lexer, "_tokens"):
        normalized = ensure_trailing_newlines_per_line(text)
        yield from lexer.get_tokens_unprocessed(normalized)
        return ("root",)

    original_text = text
    text = ensure_trailing_newlines_per_line(text)

    tokendefs = lexer._tokens
    parent_stack, sublexer_stacks = _split_stack(stack)
    statestack = list(parent_stack or ("root",))

    # Cache repeated globals / lookups locally
    token_type_cls = _TokenType
    whitespace_tok = Whitespace
    error_tok = Error
    get_using_info = _get_using_info_cached
    get_child_lexer = _get_cached_child_lexer
    purge_sublexers = _purge_sublexers_for_states
    suppress_pop_check = _should_suppress_pop_for_partial_sublexer_match

    text_len = len(text)
    original_len = len(original_text)

    last_state = statestack[-1]
    lexer_type = type(lexer)

    # Avoid isinstance(...) or issubclass(...) double checks
    if last_state == "badregex" and issubclass(lexer_type, JavascriptLexer):
        statestack.pop()
    elif (
        last_state == "value"
        and issubclass(lexer_type, TOMLLexer)
        and len(statestack) > 1
        and statestack[-2] == "array"
    ):
        statestack.pop()

    current_state = statestack[-1]
    statetokens = tokendefs[current_state]
    pos = 0
    original_endswith_nl = original_text.endswith("\n")

    while True:
        for rexmatch, action, new_state in statetokens:
            m = rexmatch(text, pos)
            if m is None:
                continue

            m_start = m.start()
            m_end = m.end()
            suppressed_pop = False

            if action is not None:
                if type(action) is token_type_cls:
                    value = m.group()
                    if (
                        m_end > original_len
                        and value.endswith("\n")
                        and not original_endswith_nl
                    ):
                        value = value[:-1]
                    yield pos, action, value
                else:
                    info = get_using_info(action)

                    if info is not None:
                        lx = get_child_lexer(lexer, action, info)

                        state_name = statestack[-1]
                        key = (state_name, id(action))
                        child_stack = sublexer_stacks.get(key, info["child_stack"])

                        gen = lex_with_state(lx, m.group(), child_stack)
                        try:
                            while True:
                                i, t, v = next(gen)
                                yield m_start + i, t, v
                        except StopIteration as e:
                            sublexer_stacks[key] = e.value or ("root",)

                        suppressed_pop = suppress_pop_check(
                            text_len, m_end, info, new_state
                        )
                    else:
                        for item in action(lexer, m):
                            yield item

            pos = m_end
            effective_new_state = None if suppressed_pop else new_state

            if effective_new_state is not None:
                if isinstance(effective_new_state, tuple):
                    for state in effective_new_state:
                        if state == "#pop":
                            if len(statestack) > 1:
                                popped = statestack.pop()
                                purge_sublexers(sublexer_stacks, (popped,))
                        elif state == "#push":
                            statestack.append(statestack[-1])
                        else:
                            statestack.append(state)

                elif isinstance(effective_new_state, int):
                    if abs(effective_new_state) >= len(statestack):
                        removed = statestack[1:]
                        del statestack[1:]
                    else:
                        removed = statestack[effective_new_state:]
                        del statestack[effective_new_state:]

                    purge_sublexers(sublexer_stacks, removed)

                elif effective_new_state == "#push":
                    statestack.append(statestack[-1])
                else:
                    raise AssertionError(f"wrong state def: {effective_new_state!r}")

                statetokens = tokendefs[statestack[-1]]

            break

        else:
            if pos >= text_len:
                break

            ch = text[pos]

            if ch == "\n":
                if pos < original_len:
                    yield pos, whitespace_tok, "\n"

                pos += 1
                if pos >= text_len:
                    continue

                statestack[:] = ["root"]
                statetokens = tokendefs["root"]
                continue

            if pos < original_len:
                yield pos, error_tok, ch

            pos += 1

    return _join_stack(tuple(statestack), sublexer_stacks)
