import re

from pygments.lexer import RegexLexer, bygroups, using
from pygments.lexers import JsonLexer
from pygments.token import (
    Comment,
    Keyword,
    Name,
    Number,
    Operator,
    Punctuation,
    String,
    Text,
    Whitespace,
)


class KivyLexer(RegexLexer):
    name = "Kivy"
    aliases = ["kv", "kivy"]
    filenames = ["*.kv"]

    tokens = {
        "root": [
            (r"#.*$", Comment.Single),
            (r"^\s*<[\w@]+>", Name.Class),  # Rule start: <Widget@Base>
            (r"^\s*[\w\.]+:", Name.Attribute),  # Property key
            (r'".*?"', String.Double),
            (r"'.*?'", String.Single),
            (r"\b\d+\.\d+\b", Number.Float),
            (r"\b\d+\b", Number.Integer),
            (r"\b(True|False|None)\b", Keyword.Constant),
            (r"\bon_[\w]+", Name.Function),  # on_press etc.
            (r"\s+", Text),
            (r"[\[\]{}(),.:=]", Punctuation),
            (r"[a-zA-Z_][\w.]*", Name),
            (r".", Text),
        ],
    }


class ModernCSharpLexer(RegexLexer):
    name = "MCS"
    aliases = ["modern-csharp"]
    filenames = ["*.cs"]
    flags = re.MULTILINE | re.UNICODE

    keywords = (
        "abstract",
        "as",
        "base",
        "break",
        "case",
        "catch",
        "checked",
        "class",
        "const",
        "continue",
        "default",
        "delegate",
        "do",
        "else",
        "enum",
        "event",
        "explicit",
        "extern",
        "finally",
        "fixed",
        "for",
        "foreach",
        "goto",
        "if",
        "implicit",
        "in",
        "interface",
        "internal",
        "is",
        "lock",
        "namespace",
        "new",
        "null",
        "operator",
        "out",
        "override",
        "params",
        "private",
        "protected",
        "public",
        "readonly",
        "ref",
        "return",
        "sealed",
        "sizeof",
        "stackalloc",
        "static",
        "struct",
        "switch",
        "this",
        "throw",
        "try",
        "typeof",
        "unchecked",
        "unsafe",
        "using",
        "virtual",
        "void",
        "volatile",
        "while",
        "add",
        "alias",
        "and",
        "ascending",
        "async",
        "await",
        "by",
        "descending",
        "dynamic",
        "equals",
        "file",
        "from",
        "get",
        "global",
        "group",
        "init",
        "into",
        "join",
        "let",
        "managed",
        "nameof",
        "nint",
        "not",
        "notnull",
        "nuint",
        "on",
        "or",
        "orderby",
        "partial",
        "record",
        "remove",
        "required",
        "scoped",
        "select",
        "set",
        "unmanaged",
        "value",
        "when",
        "where",
        "with",
        "yield",
    )

    types = (
        "bool",
        "var",
        "byte",
        "char",
        "decimal",
        "double",
        "float",
        "int",
        "long",
        "object",
        "sbyte",
        "short",
        "string",
        "uint",
        "ulong",
        "ushort",
        "DateTime",
    )

    constants = ("true", "false", "null")

    tokens = {
        "root": [
            (r"\s+", Text),
            (r"//.*", Comment.Single),
            (r"/\*", Comment.Multiline, "comment"),
            # Preprocessor directives
            (
                r"^\s*#(region|endregion|if|else|elif|endif|define|undef|warning|error|line)\b.*$",
                Keyword.Pseudo,
            ),
            # Generic # fallback
            (r"#\s*\w+[^\n]*", Keyword.Pseudo),
            # interpolated strings
            (r'\$@?"', String.Interpol, "interp_string"),
            (r'"([^"\\]|\\.)*"', String),
            (r"'\\.'|'[^\\]'", String.Char),
            # attributes
            (r"(?<!\w)\[", Punctuation, "attribute"),
            # generics start after identifier
            (r"(?<=\w)<", Punctuation, "type_parameters"),
            # var declarations
            (
                r"\b(var)\s+([a-zA-Z_][a-zA-Z0-9_]*)",
                bygroups(Keyword.Type, Name.Variable),
            ),
            # typed declarations (simple types and PascalCase)
            (
                r"\b("
                + "|".join(types)
                + r"|[A-Z][a-zA-Z0-9_]*)\s+([a-zA-Z_][a-zA-Z0-9_]*)",
                bygroups(Keyword.Type, Name.Variable),
            ),
            # keywords, types, constants
            (r"\b(" + "|".join(keywords) + r")\b", Keyword),
            (r"\b(" + "|".join(types) + r")\b", Keyword.Type),
            (r"\b(" + "|".join(constants) + r")\b", Keyword.Constant),
            # function calls
            (r"\b([a-zA-Z_][a-zA-Z0-9_]*)\s*(?=\()", Name.Function),
            # all other identifiers
            (r"[a-zA-Z_][a-zA-Z0-9_]*", Name),
            # numbers
            (r"\b\d+\.\d+[fFdDmM]?\b", Number.Float),
            (r"\b\d+[fFdDmM]\b", Number.Float),
            (r"\b0[xX][0-9a-fA-F]+\b", Number.Hex),
            (r"\b\d+\b", Number.Integer),
            # operators and punctuation
            (r"[~!%^&*+=|\?:<>/-]", Operator),
            (r"[{}\[\]();,.]", Punctuation),
        ],
        "comment": [
            (r"\*/", Comment.Multiline, "#pop"),
            (r".|\n", Comment.Multiline),
        ],
        "interp_string": [
            (r'"', String.Interpol, "#pop"),
            (r"{{|}}", String.Escape),
            (r"\{", String.Interpol, "interpolation"),
            (r'[^\{"\\]+', String.Interpol),
            (r"\\.", String.Interpol),
        ],
        "interpolation": [
            (r'\$@?"', String.Interpol, "interp_string"),
            (r'"([^"\\]|\\.)*"', String),
            (r"\{", String.Interpol, "#push"),
            (r"\}", String.Interpol, "#pop"),
            (r"\b(" + "|".join(keywords) + r")\b", Keyword),
            (r"\b(" + "|".join(types) + r")\b", Keyword.Type),
            (r"\b(" + "|".join(constants) + r")\b", Keyword.Constant),
            (r"\b([a-zA-Z_][a-zA-Z0-9_]*)\s*(?=\()", Name.Function),
            (r"[a-zA-Z_][a-zA-Z0-9_]*", Name.Variable),
            (r"\b\d+\.\d+[fFdDmM]?\b", Number.Float),
            (r"\b\d+\b", Number.Integer),
            (r"[~!%^&*+=|\?:<>/-]", Operator),
            (r"[()\[\].,]", Punctuation),
            (r"\s+", Text),
        ],
        "attribute": [
            (r"\]", Punctuation, "#pop"),
            # keywords inside attributes (like typeof)
            (r"\b(" + "|".join(keywords) + r")\b", Keyword),
            # strings inside attributes
            (r'\$@?"', String.Interpol, "interp_string"),
            (r'"([^"\\]|\\.)*"', String),
            (r"'\\.'|'[^\\]'", String.Char),
            # types
            (r"\b(" + "|".join(types) + r")\b", Keyword.Type),
            # attribute identifiers, allow dot access
            (r"[a-zA-Z_][a-zA-Z0-9_]*(\.[a-zA-Z_][a-zA-Z0-9_]*)*", Name.Decorator),
            # numbers
            (r"\b\d+\b", Number.Integer),
            # operators
            (r"[=,:<>]", Operator),
            # parentheses
            (r"[()]", Punctuation),
            # whitespace
            (r"\s+", Text),
        ],
        "type_parameters": [
            (r">", Punctuation, "#pop"),
            (r"<", Punctuation, "#push"),
            (r"\b(" + "|".join(types) + r")\b", Keyword.Type),
            (r"[a-zA-Z_][a-zA-Z0-9_]*", Name.Class),
            (r"[,\.\?]", Punctuation),
            (r"\s+", Text),
        ],
    }


class CsvLexer(RegexLexer):
    name = "CSV"
    aliases = ["csv"]
    filenames = ["*.csv"]

    tokens = {
        "root": [
            (r"#.*$", Comment.Single),
            # Quoted field: "text", allowing escaped quotes ("")
            (r'"(?:[^"]|"")*"', String),
            # Numeric values
            (r"\b\d+\.\d+\b", Number.Float),
            (r"\b\d+\b", Number.Integer),
            # Separator
            (r",", Punctuation),
            # Newline
            (r"\n", Text),
            # Trim leading/trailing spaces
            (r"[ \t]+", Text),
            # Any unquoted field text (until comma or newline)
            (r"[^,\n]+", Name),
        ]
    }


class CsvAlternatingLexer(RegexLexer):
    name = "CSV-Alt"
    aliases = ["csv_alt"]
    filenames = ["*.csv"]

    tokens = {
        "col0": [
            (r"\n", Text, "col0"),  # reset each line
            # Quoted field
            (r'"(?:[^"]|"")*"', String, "col1"),
            # Unquoted field
            (r"[^,\n]+", String, "col1"),
            # Separator
            (r",", Punctuation),
            # Whitespace
            (r"[ \t]+", Text),
        ],
        "col1": [
            (r"\n", Text, "col0"),  # reset each line
            # Quoted field
            (r'"(?:[^"]|"")*"', Number, "col0"),
            # Unquoted field
            (r"[^,\n]+", Number, "col0"),
            # Separator
            (r",", Punctuation),
            # Whitespace
            (r"[ \t]+", Text),
        ],
        # Start in column 0
        "root": [
            (r"", Text, "col0"),
        ],
    }


class SimpleHttpRequestLexer(RegexLexer):
    name = "SimpleHTTP"
    aliases = ["simple_http"]
    filenames = ["*.http", "*.req"]

    tokens = {
        "root": [
            (
                r"^(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)(\s+)(\S+)",
                bygroups(Keyword, Text, String),
                "headers",
            ),
            (r"\s+", Text),
        ],
        "headers": [
            # Blank line → body
            (r"\n\s*\n", Text, "body"),
            # Header: Value
            (
                r"^([A-Za-z0-9\-]+)(:)(\s*)(.+)$",
                bygroups(Name.Attribute, Punctuation, Text, String),
            ),
            (r"\n", Text),
        ],
        "body": [
            # If it looks like JSON → use JSON lexer
            (r"\{.*", using(JsonLexer)),
            (r".+", String),
            (r"\n", Text),
        ],
    }


class EditorHttpRequestLexer(RegexLexer):
    name = "EditorHTTP"
    aliases = ["editor_http"]
    filenames = ["*.http", "*.req"]

    tokens = {
        "root": [
            # Request separator
            (r"^###.*?$", Comment.Preproc),
            # Comment
            (r"#.*?$", Comment.Single),
            # HTTP request line
            (
                r"^(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)(\s+)(\S+)",
                bygroups(Keyword, Whitespace, String),
                "headers",
            ),
            (r"\s+", Text),
        ],
        "headers": [
            (r"^###.*?$", Comment.Preproc, "root"),
            (r"#.*?$", Comment.Single),
            # Blank line → body
            (r"\n\s*\n", Text, "body"),
            (
                r"^([A-Za-z0-9\-]+)(\s*)(:)(\s*)(.+)$",
                bygroups(Name.Attribute, Text, Punctuation, Text, String),
            ),
            (r"\n", Text),
        ],
        "body": [
            # New request separator → back to root
            (r"^###.*?$", Comment.Preproc, "root"),
            # Detect JSON body
            (r"\s*(\{|\[)", Punctuation, "json"),
            # Detect HTML
            (r"\s*<", Punctuation, "html"),
            # Detect YAML-like
            (r"^\s*[^:\n]+:\s*", String, "yaml"),
            # Plain text body
            (r".+\n?", String),
        ],
        "json": [
            (r"^###.*?$", Comment.Preproc, "root"),
            (r'"(\\.|[^"\\])*"', String),
            (r"\b(true|false|null)\b", Keyword),
            (r"-?\d+(\.\d+)?([eE][+-]?\d+)?", Number),
            (r"[{}\[\],:]", Punctuation),
            (r"\s+", Text),
        ],
        "html": [
            (r"^###.*?$", Comment.Preproc, "root"),
            (r"<!--(.*?)-->", Comment),
            (r"<\!DOCTYPE.*?>", Comment.Preproc),
            (r"<\?[^>]+\?>", Comment.Preproc),
            (r"</?[A-Za-z0-9_:-]+", Name.Tag),
            (r"[A-Za-z0-9_:-]+=", Name.Attribute),
            (r'"[^"]*"', String),
            (r"[<>/]", Punctuation),
            (r"[^<]+", String),
        ],
        "yaml": [
            (r"^###.*?$", Comment.Preproc, "root"),
            (r"^\s*[^:\n]+:(\s*.*)?$", String),
            (r".+\n?", String),
        ],
    }


class SimpleMarkdownLexer(RegexLexer):
    name = "SimpleMarkdown"
    aliases = ["smd", "simple_md"]
    filenames = ["*.md"]

    tokens = {
        "root": [
            # fenced code block start: ``` or ```lang
            (r"^[ \t]*```[a-zA-Z0-9_+-]*[ \t]*\r?\n", String.Backtick, "codeblock"),
            # headings
            (r"^(#{1,6})(\s+)(.*)$", bygroups(Keyword, Whitespace, Name.Tag)),
            # horizontal rule
            (r"^\s*([-*_]){3,}\s*$", Punctuation),
            # blockquote
            (r"^(>\s?)(.*)$", bygroups(Comment, Comment)),
            # task list
            (
                r"^(\s*[-*+])(\s+)(\[[ xX]\])",
                bygroups(Punctuation, Whitespace, Keyword),
            ),
            # unordered list
            (r"^(\s*[-*+])(\s+)", bygroups(Punctuation, Whitespace)),
            # ordered list
            (r"^(\s*\d+\.)(\s+)", bygroups(Punctuation, Whitespace)),
            # image
            (r"!\[([^\]]*)\]\(([^)]+)\)", bygroups(Name.Attribute, String)),
            # link
            (r"\[([^\]]+)\]\(([^)]+)\)", bygroups(Name.Attribute, String)),
            # inline code
            (r"`[^`\r\n]+`", String.Backtick),
            # bold
            (r"\*\*[^*\r\n]+\*\*", String.Strong),
            (r"__[^_\r\n]+__", String.Strong),
            # italic
            (r"\*[^*\r\n]+\*", String.Emph),
            (r"_[^_\r\n]+_", String.Emph),
            # strikethrough
            (r"~~[^~\r\n]+~~", Operator),
            # escape
            (r"\\.", String.Escape),
            # whitespace / newline
            (r"\r?\n", Whitespace),
            (r"[ \t]+", Text),
            # normal text
            (r"[^\\`\[*_!~\r\n]+", Text),
            # fallback
            (r".", Text),
        ],
        "codeblock": [
            # fenced code block end
            (r"^[ \t]*```[ \t]*\r?\n?", String.Backtick, "#pop"),
            # content inside fence
            (r".*\r?\n", String),
            (r".+", String),
        ],
    }
