from __future__ import annotations

import pickle
import re
from typing import Any, Optional

from pygments.lexers import get_all_lexers

from denary.config import get_config_dir


def comments_for(name: str) -> tuple[Optional[str], Optional[str], Optional[str]]:
    n = name.lower()

    def any_in(*subs):
        return any(s in n for s in subs)

    # No comments formats
    if any_in("jsonbareobject", "raw token data", "urlencoded", "text output"):
        return None, None, None

    # Markup / XML-ish
    if any_in("xml", "xsl", "xslt", "wsdl", "xquery", "xorg", "xul", "svg"):
        return None, "<!--", "-->"
    if any_in("html"):
        return None, "<!--", "-->"
    if any_in("dtd"):
        return None, "<!--", "-->"

    # CSS
    if n == "css" or n.startswith("css+"):
        return None, "/*", "*/"

    # SQL family
    if any_in(
        "sql",
        "postgres",
        "pl/pgsql",
        "transact-sql",
        "google",
        "zetasql",
        "prql",
        "promql",
        "sparql",
    ):
        return "--", "/*", "*/"

    # C-like
    if any_in(
        "c#",
        "c++",
        "cpp",
        "objective-c++",
        "objective-c",
        "java",
        "javascript",
        "typescript",
        "tsx",
        "jsx",
        "groovy",
        "kotlin",
        "swift",
        "haxe",
        "glsl",
        "hlsl",
        "cuda",
        "wgsl",
        "web idl",
        "carbon",
        "verilog",
        "systemverilog",
        "scala",
        "dart",
        "go ",
        " go",
        "zig",
        "php",
        "pawn",
        "pike",
        "protobuf",
        "thrift",
        "tablegen",
        "antlr",
        "ragel",
        "awk (c-like?)",
    ):
        return "//", "/*", "*/"
    if n in {"c", "c amkes", "camkes"} or n.startswith("c "):
        return "//", "/*", "*/"

    # Go
    if n == "go" or "golang" in n:
        return "//", "/*", "*/"

    # Rust
    if "rust" in n:
        return "//", "/*", "*/"

    # Lua / variants
    if "lua" in n:
        return "--", "--[[", "]]"

    # Pascal / Delphi / Modula-like
    if any_in("delphi", "pascal", "objectpascal", "modula-2"):
        # Delphi supports // and (* *), also { } as block comments.
        return "//", "(*", "*)"

    # Ada
    if n.startswith("ada"):
        return "--", None, None

    # Haskell / Agda / Idris
    if any_in("haskell", "agda", "idris"):
        return "--", "{-", "-}"

    # F# (ML-style with // and (* *))
    if n.strip() == "f#" or "fsharp" in n:
        return "//", "(*", "*)"

    # OCaml / ReasonML / SML
    if any_in("ocaml", "standard ml", "sml"):
        return None, "(*", "*)"
    if any_in("reasonml", "reason"):
        return "//", "/*", "*/"

    # Coq (ML-like)
    if "coq" in n:
        return None, "(*", "*)"

    # Common Lisp
    if any_in("common lisp"):
        return ";", "#|", "|#"

    # Scheme (varies, common is ; for line, #| |# for block with R6RS)
    if "scheme" in n:
        return ";", "#|", "|#"

    # Lisp-like (Clojure / ClojureScript / NewLisp / EmacsLisp)
    if any_in("clojure"):
        return ";", None, None
    if any_in("emacs", "elisp"):
        return ";", None, None
    if any_in("newlisp"):
        return ";", None, None
    if any_in("lisp") and "common" not in n:
        return ";", None, None

    # Python / Ruby / Shell family / Make / Config-ish
    if any_in(
        "python",
        "pycon",
        "pytb",
        "ruby",
        "makefile",
        "make ",
        "meson",
        "cmake",
        "docker",
        "ini",
        "cfg",
        "desktop file",
        "properties",
        "toml",
        "yaml",
        "ldif",
        "nginx",
        "pacmanconf",
        "procfile",
        "bash",
        "shell",
        "zsh",
        "ksh",
        "fish",
        "tcsh",
        "tcl",
        "awk",
        "sed",
        "rex",
        "fennel",
        "mako",
        "jinja",
        "django",
        "twig",
        "velocity",
        "mustache",
        "erb",
        "handlebars",
        "sass",
        "scss",
        "less",
        "hcl",
        "terraform",
        "npmrc",
    ):
        return "#", None, None

    # PowerShell
    if "powershell" in n:
        return "#", "<#", "#>"

    # MATLAB / Octave
    if "matlab" in n or "octave" in n:
        return "%", "%{", "%}"

    # R
    if n == "s" or n == "r" or "splus" in n:
        return "#", None, None

    # SQL*Plus-like (Stata uses * and //? but most use * for line)
    if "stata" in n:
        return "*", "/*", "*/"

    # Prolog / Erlang
    if "prolog" in n:
        return "%", "/*", "*/"
    if "erlang" in n:
        return "%", "/*", "*/"

    # PostScript
    if "postscript" in n:
        return "%", None, None

    # AppleScript
    if "applescript" in n:
        return "--", "(*", "*)"

    # VB / VBScript
    if "vbscript" in n or "vb.net" in n or "visual basic" in n or n.strip() == "vb.net":
        return "'", None, None

    # YAML+Jinja etc -> treat as YAML plus template; choose YAML line comments
    if n.startswith("yaml+"):
        return "#", None, None

    # JSON* has no comments
    if n.startswith("json"):
        return None, None, None

    # SQL-like configs (*.cfg) already handled by '#'
    # INI handled

    # Assembly
    if any_in("nasm", "amdgpu", "ptx", "asm", "mips", "gas", "ca65"):
        # GAS often uses '#', NASM uses ';', many others ';'
        if "gas" in n:
            return "#", None, None
        return ";", None, None

    # VHDL
    if "vhdl" in n:
        return "--", None, None

    # YAML/TOML/INI already handled
    # Org-mode
    if "org mode" in n or n.strip() == "org":
        return "#", None, None

    # Markdown / reStructuredText / plain text: no real comments
    if any_in(
        "markdown", "restructuredtext", "text only", "bbcode", "wiki", "wikitext"
    ):
        return None, None, None

    # GraphQL
    if "graphql" in n:
        return "#", None, None

    # HAML/Slim/Pug (templating) - use Ruby-like? Most have -# in HAML for comments, Slim uses /
    if "haml" in n:
        return "-#", None, None
    if "slim" in n:
        return "/", None, None
    if any_in("pug", "jade"):
        return "//-", None, None

    # Default fallback to C-style
    return "//", "/*", "*/"


def build_entry(name: str, exts: list[str]) -> dict[str, Any]:
    single, mstart, mend = comments_for(name)
    _exts = [
        e for ext in exts for e in ext.split(",")
    ]  # Normalize extensions to lowercase

    return {
        "name": name,
        "single_line_comment": single,
        "multi_line_comment_start": mstart,
        "multi_line_comment_end": mend,
        "file_extensions": list(
            {
                "." + ext.lower().strip().split(".")[-1]
                for ext in _exts
                if ext.strip()  # Normalize and filter
            }
        ),  # Filter out empty extensions
    }


def generate_comments() -> list[dict[str, Any]]:
    raw = ""
    for name, aliases, filename, _ in get_all_lexers():
        raw += f"{name} ({', '.join(aliases)}) ('{', '.join([f'*.{ext}' for ext in filename])}')\n"

    line_re = re.compile(r"^(?P<name>.+?)\s+\([^)]+\)\s+\((?P<exts>.*)\)$")
    entries: list[tuple[str, list[str]]] = []
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        m = line_re.match(line)
        if not m:
            continue
        name = m.group("name").strip()
        exts_raw = m.group("exts").strip()
        exts: list[Any] = []

        if exts_raw != "":
            parts = [p.strip() for p in re.split(r",(?![^']*')", exts_raw)]
            for p in parts:
                p = p.strip()
                if p.startswith("'") and p.endswith("'"):
                    p = p[1:-1]
                exts.append(p)

        # reveal_type(exts)

        entries.append((name, exts))

    data = {"languages": [build_entry(name, exts) for name, exts in entries]}

    config_path = get_config_dir()
    out_path = config_path / "language_comments.pkl"

    with open(out_path, "wb") as f:
        pickle.dump(data["languages"], f)

    return data["languages"]


def main():
    generate_comments()


if __name__ == "__main__":
    main()
