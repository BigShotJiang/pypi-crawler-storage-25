import heapq
import math
from difflib import SequenceMatcher
from typing import Any, Optional

NEG_INF = float("-inf")


def fzf_score(pattern: str, text: str) -> float:
    """
    Returns the fuzzy match score using an FZF-like algorithm.
    Higher score = better.
    Returns -inf for no match.
    """

    plen = len(pattern)
    tlen = len(text)
    if plen == 0:
        return float("-inf")

    p = pattern.lower()
    s = text.lower()

    prev = [-1e9] * (tlen + 1)
    curr = [-1e9] * (tlen + 1)

    def is_word_start(t: str, i: int) -> bool:
        if i == 0:
            return True
        return (
            t[i].isalnum()
            and not t[i - 1].isalnum()
            or t[i].isupper()
            and t[i - 1].islower()
        )

    for pi in range(plen):
        c = p[pi]
        best = -1e9
        for ti in range(tlen):
            if c == s[ti]:
                score = 1.0

                if ti > 0 and pi > 0:
                    if pattern[pi - 1].lower() == s[ti - 1]:
                        score += 1.0

                if is_word_start(text, ti):
                    score += 2.0

                if text[ti].isupper():
                    score += 0.5

                score += prev[ti] if pi > 0 else 0

                curr[ti + 1] = score
                best = max(best, score)

            else:
                curr[ti + 1] = curr[ti]

        prev, curr = curr, [-1e9] * (tlen + 1)

    final_score = best

    final_score -= math.log2(tlen + 2)

    return final_score


def fzf_fuzzy_find(query: str, choices: list[str], limit: int = 80) -> list[Any]:
    """
    Fuzzy search with multi-word scoring.
    May return fewer than `limit` results if prefilter removes many choices,
    exactly like the original behavior.
    """

    if not query:
        return choices[:limit]

    words = [w.lower() for w in query.split() if w.strip()]
    if not words:
        return choices[:limit]

    heap: list[Any] = []
    heap_push = heapq.heappush
    heap_replace = heapq.heapreplace

    for choice in choices:
        text_lower = choice.lower()

        failed = False
        for w in words:
            it = iter(text_lower)
            if not all(c in it for c in w):
                failed = True
                break

        if failed:
            continue

        total_score = 0.0
        valid = True

        for w in words:
            score = fzf_score(w, text_lower)
            if score == NEG_INF:
                valid = False
                break
            total_score += score

        if not valid:
            continue

        if len(heap) < limit or limit == -1:
            heap_push(heap, (total_score, choice))
        else:
            if total_score > heap[0][0]:
                heap_replace(heap, (total_score, choice))

    heap.sort(key=lambda x: x[0], reverse=True)

    return [c for _, c in heap]


def fuzzy_find_ignore_case(
    query: str,
    choices: list[str],
    min_score: Optional[float] = None,
    limit: int = 80,
) -> list[Any]:
    total = len(choices)

    if min_score is None:
        if total < 100:
            min_score = 0.45
        else:
            min_score = 0.45 * (100 / total) ** 0.3
            min_score = max(0.15, min_score)

    query_lower = query.lower().strip()
    heap: list[Any] = []

    for choice in choices:
        choice_lower = choice.lower().strip()

        sequence = SequenceMatcher(None, query_lower, choice_lower)

        score = sequence.quick_ratio()

        if query_lower in choice_lower:
            score = max(score, 0.85)

        if score >= min_score:
            heapq.heappush(heap, (score, choice))
            if len(heap) > limit and limit >= 0:
                heapq.heappop(heap)

    return [choice for _, choice in sorted(heap, key=lambda x: -x[0])]
