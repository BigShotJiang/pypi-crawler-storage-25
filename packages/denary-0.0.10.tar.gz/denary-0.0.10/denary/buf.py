from __future__ import annotations

import asyncio
import hashlib
import locale
import math
import os
import sys
import tempfile
import time
from collections import Counter
from enum import Enum, auto
from functools import lru_cache
from pathlib import Path
from typing import Any, Generator, NamedTuple, Optional, Protocol, TypedDict, cast

from pygments.lexer import Lexer, RegexLexer
from pygments.lexers import guess_lexer

from denary import config, events
from denary.chunked_lines import ChunkedLines
from denary.events import Event, EventType
from denary.lsp.client import LSPClient
from denary.syntax.hilighing import (
    Diagnostic,
    HilightedLine,
    TextLexer,
    _Lexer,
    get_lexer,
    get_suffix_from_filename,
    get_suffix_from_lexer,
)
from denary.undo_utils import UndoManager


class BufferSession(TypedDict):
    """
    Represents a buffer session with buffer metadata.
    """

    file_name: str
    cursor_x: int
    cursor_y: int
    scroll: int
    h_scroll: int
    markers: dict[str, tuple[int, int]]


class CursorPosition(NamedTuple):
    y: int
    x: int


class BufferActionTypeEnum(Enum):
    INSERT = auto()
    DELETE = auto()
    REPLACE = auto()


class BufferAction(NamedTuple):
    action_type: BufferActionTypeEnum
    content: str | tuple[str, str]
    cursor_position: CursorPosition


class BufferActionGroup(NamedTuple):
    actions: list[BufferAction]


type Change = BufferAction | BufferActionGroup


class UndoManagerProtocol(Protocol):
    def store_change(self, change: Change) -> None:
        """Store a change in the undo history."""
        ...

    def undo(self) -> Change | None:
        """Undo the last change and return it."""
        ...

    def redo(self) -> Change | None:
        """Redo the last undone change and return it."""
        ...

    def cleanup(self) -> None:
        """Clean up any temporary files used for undo/redo."""
        ...


class RichString(str):
    __slots__ = ("state", "tokens", "_width_cache", "_bracket_cache")

    state: Optional[Any]
    tokens: Optional[Any]
    _width_cache: Optional[Any]
    _bracket_cache: Optional[Any]

    def __new__(
        cls, value="", state=None, tokens=None, _width_cache=None, _bracket_cache=None
    ):
        obj = super().__new__(cls, value)
        obj.state = state
        obj.tokens = tokens
        obj._width_cache = _width_cache
        obj._bracket_cache = _bracket_cache
        return obj

    def _wrap(self, value):
        if isinstance(value, str):
            return RichString(value)
        return value

    def __add__(self, other):
        return self._wrap(super().__add__(other))

    def __radd__(self, other):
        return self._wrap(other + str(self))

    def __mul__(self, n):
        return self._wrap(super().__mul__(n))

    def __rmul__(self, n):
        return self._wrap(super().__mul__(n))

    def __getitem__(self, key):
        return self._wrap(super().__getitem__(key))

    # --- common string methods ---
    def replace(self, *a, **k):
        return self._wrap(super().replace(*a, **k))

    def strip(self, *a, **k):
        return self._wrap(super().strip(*a, **k))

    def lstrip(self, *a, **k):
        return self._wrap(super().lstrip(*a, **k))

    def rstrip(self, *a, **k):
        return self._wrap(super().rstrip(*a, **k))

    def lower(self):
        return self._wrap(super().lower())

    def upper(self):
        return self._wrap(super().upper())

    def capitalize(self):
        return self._wrap(super().capitalize())

    def title(self):
        return self._wrap(super().title())

    def swapcase(self):
        return self._wrap(super().swapcase())

    def join(self, iterable):
        return self._wrap(super().join(iterable))

    def format(self, *a, **k):
        return self._wrap(super().format(*a, **k))

    def format_map(self, mapping):
        return self._wrap(super().format_map(mapping))

    def expandtabs(self, *a, **k):
        return self._wrap(super().expandtabs(*a, **k))

    def center(self, *a, **k):
        return self._wrap(super().center(*a, **k))

    def ljust(self, *a, **k):
        return self._wrap(super().ljust(*a, **k))

    def rjust(self, *a, **k):
        return self._wrap(super().rjust(*a, **k))

    def zfill(self, *a, **k):
        return self._wrap(super().zfill(*a, **k))

    def removeprefix(self, *a, **k):
        return self._wrap(super().removeprefix(*a, **k))

    def removesuffix(self, *a, **k):
        return self._wrap(super().removesuffix(*a, **k))


def detect_encoding_from_bom(path, default_encoding):
    with open(path, "rb") as f:
        start = f.read(4)

    if start.startswith(b"\xef\xbb\xbf"):
        return "utf-8-sig"
    elif start.startswith((b"\xff\xfe", b"\xfe\xff")):
        return "utf-16"
    elif start.startswith((b"\x00\x00\xfe\xff", b"\xff\xfe\x00\x00")):
        return "utf-32"
    else:
        return default_encoding


def detect_indentation(lines, max_lines=200) -> tuple[bool, int]:
    """
    Detect indentation style from file content.
    """
    tab_lines = 0
    space_lines = 0
    space_counts = []

    for line in lines[:max_lines]:
        if not line.strip():
            continue

        stripped = line.lstrip(" \t")
        indent = line[: len(line) - len(stripped)]

        if not indent:
            continue

        if indent.startswith("\t"):
            tab_lines += 1
        elif indent.startswith(" "):
            space_lines += 1
            space_counts.append(len(indent))

    if tab_lines > space_lines:
        return False, 4

    if space_counts:
        common = Counter(space_counts).most_common(1)
        if common:
            size = common[0][0]

            if size < 4:
                return True, size

    return True, 4


@lru_cache(maxsize=1)
def get_terminal_encoding() -> str:

    enc = sys.stdout.encoding

    if not enc:
        enc = os.environ.get("PYTHONIOENCODING")

    if not enc:
        enc = locale.getpreferredencoding(False)

    if not enc or enc.lower() in ("ascii", "cp437", "cp1252"):
        enc = "utf-8"

    return enc


def get_uri_from_name(file_name: str | None = None) -> str:
    try:
        if file_name is None or file_name.startswith("Untitled"):
            uri = f"inmemory://buffer/{file_name}"
            return uri

    except Exception:
        pass

    if file_name is None:
        file_name = ""

    uri = (config.WORKING_DIR / file_name).absolute().as_uri()
    return uri


async def load_lsp(suffix: str) -> None:
    lang = config.EXT_TO_LANG.get(suffix)
    if lang is None:
        return

    if lang in config.LOADED_LSPS:
        config.LOADING_LSPS.discard(lang)
        return

    if lang in config.LOADING_LSPS:
        return

    config.LOADING_LSPS.add(lang)

    try:
        lsp_client_config = config.LSP_CONFIG.get(lang)
        if lsp_client_config is None:
            return

        lsp_client_cmd = lsp_client_config.get("cmd")
        if not lsp_client_cmd:
            return

        lsp_config = lsp_client_config.get("settings", {})

        config.LOADED_LSPS[lang] = await LSPClient.create(
            lsp_client_cmd,
            root_uri=get_uri_from_name(),
            initialize_settings=lsp_config,
        )
    finally:
        config.LOADING_LSPS.discard(lang)


def get_lsp(suffix: str) -> LSPClient | None:
    lang = config.EXT_TO_LANG.get(suffix)
    if lang is None:
        return None

    lsp = config.LOADED_LSPS.get(lang)

    if lsp is not None and not lsp.is_dead():
        return lsp

    if lang in config.LOADING_LSPS:
        return None

    try:
        # config.LOADING_LSPS.add(lang)
        events.EVENT_QUEUE.put_nowait(
            Event(
                EventType.LOAD_LSP,
                {
                    "suffix": suffix,
                    "lang": lang,
                    "reload": lsp is not None and lsp.is_dead(),
                },
            )
        )
    except asyncio.QueueFull:
        config.LOADING_LSPS.discard(lang)

    return None


def to_utf16_len(s: str) -> int:
    return len(s.encode("utf-16-le", "surrogatepass")) // 2


def compute_lsp_change_from_action(action: BufferAction, buffer: Buffer):
    """
    Compute a minimal LSP content change (single range) for a BufferAction.
    Must be called **before** applying the action to the buffer.

    Returns:
      [
        {
          "range": {
            "start": {"line": int, "character": int},
            "end":   {"line": int, "character": int},
          },
          "text": str  # replacement text
        }
      ]
    or [] if there's no change.
    """
    at = action.action_type
    cur = action.cursor_position

    if at == BufferActionTypeEnum.INSERT:
        if not isinstance(action.content, str):
            return []

        old_text = ""
        new_text = action.content

    elif at == BufferActionTypeEnum.DELETE:
        if not isinstance(action.content, str):
            return []

        old_text = action.content
        new_text = ""

    elif at == BufferActionTypeEnum.REPLACE:
        if not isinstance(action.content, tuple):
            return []

        old_text, new_text = action.content

    else:
        return []

    if old_text == new_text:
        return []

    base_line = cur.y

    line_text = buffer.lines[base_line] if 0 <= base_line < len(buffer.lines) else ""
    base_char = to_utf16_len(line_text[: cur.x])

    min_len = min(len(old_text), len(new_text))
    start_idx = 0
    while start_idx < min_len and old_text[start_idx] == new_text[start_idx]:
        start_idx += 1

    end_old = len(old_text)
    end_new = len(new_text)
    while (
        end_old > start_idx
        and end_new > start_idx
        and old_text[end_old - 1] == new_text[end_new - 1]
    ):
        end_old -= 1
        end_new -= 1

    replacement = new_text[start_idx:end_new]

    prefix = old_text[:start_idx]
    pre_nl = prefix.count("\n")
    if pre_nl == 0:
        start_line = base_line
        start_char = base_char + to_utf16_len(prefix)
    else:
        start_line = base_line + pre_nl
        after_last_nl = prefix[prefix.rfind("\n") + 1 :]
        start_char = to_utf16_len(after_last_nl)

    deleted_part = old_text[start_idx:end_old]
    del_nl = deleted_part.count("\n")
    if del_nl == 0:
        end_line = start_line
        end_char = start_char + to_utf16_len(deleted_part)
    else:
        end_line = start_line + del_nl
        after_last_nl = deleted_part[deleted_part.rfind("\n") + 1 :]
        end_char = to_utf16_len(after_last_nl)

    return [
        {
            "range": {
                "start": {"line": start_line, "character": start_char},
                "end": {"line": end_line, "character": end_char},
            },
            "text": replacement,
        }
    ]


class Buffer:
    """
    Class to represent a single buffer in the text editor.
    """

    file_name: Optional[str]
    suffix: Optional[str] = None
    lines: ChunkedLines[RichString]
    cursor_x: int
    cursor_y: int
    scroll: int
    h_scroll: int
    modified: bool
    temp_dir: Optional[str]
    file_time_stamp: Optional[float] = None
    file_sha256: Optional[str] = None
    first: bool
    lexer: Optional[Lexer]
    file_path: Path
    markers: dict[str, tuple[int, int]]
    buffer_changes: dict[int, str]
    git_changes: dict[int, str]
    is_aux_buffer: bool
    new_buffer_untitled: bool
    encoding: str = "utf-8"
    last_cursor_x: int
    search_spans: list[HilightedLine]
    diagnostics: list[Diagnostic]
    ai_completions: list[Diagnostic]
    undo_manager: UndoManagerProtocol
    _cursor_position_cache: Optional[CursorPosition] = None

    last_action_applyed: Optional[BufferAction] = None
    last_action_applyed_timestamp: Optional[float] = None

    last_action_when_saved: Optional[BufferAction] = None
    action_count: int = 0

    deverge_state: int = 0

    insert_spaces: bool = True
    tab_size: int = 4
    new_line: str = "\n"

    current_gutter_width: int = 0

    def __init__(
        self,
        file_name: Optional[str] = None,
        aux_buffer: bool = False,
        temp_dir: Optional[str] = None,
        new_buffer_untitled: bool = False,
        lexer: Optional[Lexer] = None,
    ):
        self.file_name = file_name
        self.new_buffer_untitled = new_buffer_untitled
        self.first = True
        self.temp_dir = temp_dir
        self.modified = False
        self.is_aux_buffer = aux_buffer
        self.last_action_applyed = None
        self.last_action_when_saved = None

        self.cursor_x = 0
        self.cursor_y = 0

        self.last_cursor_x = self.cursor_x

        self.scroll = 0
        self.h_scroll = 0

        self.lexer = lexer

        if aux_buffer:
            self.load()
            self.first = False

    def load(self):
        if self.first:
            self.buffer_changes = {}
            self.git_changes = {}
            self.diagnostics = []
            self.search_spans = []
            self.ai_completions = []

            if getattr(self, "markers", None) is None:
                self.markers = {}

            if self.file_name is not None and not self.new_buffer_untitled:

                self.lines, self.file_sha256 = self.load_file(self.file_name)

                self.file_time_stamp = (
                    os.path.getmtime(self.file_name)
                    if os.path.exists(self.file_name)
                    else None
                )

            else:
                self.lines = ChunkedLines([RichString()])
                self.file_time_stamp = None

            self.load_lexer()

            if not self.suffix and self.lexer:
                if len(s := get_suffix_from_lexer(self.lexer)) > 0:
                    self.suffix = s[0]

            self.undo_manager = UndoManager(
                memory_threshold=config.MAX_UNDO,
                dump_size=math.ceil(config.MAX_UNDO / 2),
                temp_dir=self.temp_dir,
            )

            num_lines = len(self.lines) - 1

            self.cursor_y = self.cursor_y if self.cursor_y <= num_lines else 0
            self.cursor_x = (
                self.cursor_x
                if (
                    self.cursor_x < len(self.lines[self.cursor_y])
                    and self.cursor_x >= 0
                )
                else 0
            )
            self.scroll = self.scroll if self.scroll <= num_lines else num_lines
            self.h_scroll = (
                self.h_scroll
                if self.h_scroll < len(self.lines[self.cursor_y]) and self.h_scroll >= 0
                else 0
            )

    def load_lexer(self) -> None:
        if self.file_name is None:
            self.lexer = TextLexer()
            return None

        self.suffix = get_suffix_from_filename(self.file_name)

        if self.lexer is None:
            self.lexer = get_lexer(self.suffix)

            if isinstance(self.lexer, TextLexer):
                code = "\n".join(self.lines[:500])
                try:
                    self.lexer = guess_lexer(code)
                except Exception:
                    pass

        if self.lexer is None:
            self.lexer = TextLexer()

    def load_file(self, fname) -> tuple[ChunkedLines[RichString], Optional[str]]:

        if self.is_aux_buffer or not fname:
            return ChunkedLines([RichString()]), None

        self.file_path = Path(os.getcwd()) / fname
        default_encoding = get_terminal_encoding()

        try:
            self.encoding = detect_encoding_from_bom(fname, default_encoding)

            newline_counts = {"\r\n": 0, "\n": 0, "\r": 0}
            indent_sample = []

            sha256 = hashlib.sha256()
            lines: Optional[ChunkedLines[RichString]] = None

            last_had_newline = False

            def line_generator() -> Generator[RichString, None, None]:
                with open(
                    fname,
                    "r",
                    encoding=self.encoding,
                    errors="replace",
                    newline="",
                ) as f:
                    rs = RichString

                    last_had_newline = False

                    for i, line in enumerate(f):
                        sha256.update(line.encode())
                        last_had_newline = False

                        if line.endswith("\n"):
                            last_had_newline = True
                            if line.endswith("\r\n"):
                                newline_counts["\r\n"] += 1
                                content = line[:-2]
                            else:
                                newline_counts["\n"] += 1
                                content = line[:-1]

                        elif line.endswith("\r"):
                            last_had_newline = True
                            newline_counts["\r"] += 1
                            content = line[:-1]
                        else:
                            content = line

                        if i < 500:
                            indent_sample.append(content)

                        yield rs(content)

                    if last_had_newline:
                        yield rs("")

            lines = ChunkedLines(line_generator())

            if not lines:
                lines = ChunkedLines([RichString()])

            self.new_line = max(newline_counts, key=lambda k: newline_counts[k])

            self.insert_spaces, self.tab_size = detect_indentation(indent_sample)
            self.file_sha256 = sha256.hexdigest()

            return lines, sha256.hexdigest()

        except FileNotFoundError:
            return ChunkedLines([RichString()]), None

    def update_file_hash(self, lines: Optional[list[RichString]] = None) -> str:
        sha256 = hashlib.sha256()

        if lines is None:
            lines = self.get_lines()

        for line in lines:
            sha256.update(line.encode())

        self.file_sha256 = sha256.hexdigest()

        return self.file_sha256

    def save_file(self) -> None:
        """
        Write self.lines back to disk.  If no filename yet, prompt for 'Save as'.
        """
        if self.is_aux_buffer:
            return

        self.lines.normalize()

        if self.file_name is None:
            return

        dir_name = os.path.dirname(self.file_name) or "."

        with tempfile.NamedTemporaryFile(
            "w", dir=dir_name, delete=False, encoding=self.encoding, newline=""
        ) as tf:
            temp_name = tf.name

            self.update_file_hash()

            tf.write(self.new_line.join(self.get_lines()))

        os.replace(temp_name, self.file_name)

        self.modified = False
        self.new_buffer_untitled = False

        self.file_time_stamp = (
            os.path.getmtime(self.file_name) if os.path.exists(self.file_name) else None
        )

        self.last_action_when_saved = self.last_action_applyed
        self.action_count = 0

    def get_lines(self) -> list[RichString]:
        if self.lines:
            return self.lines.to_list()
        else:
            return []

    def set_lines(self, text: list[RichString]):
        """
        Set the buffer text from a string, splitting into lines.
        """
        self.lines = ChunkedLines(text)

    def get_cursor_position(self) -> CursorPosition:
        if (
            self._cursor_position_cache is None
            or self._cursor_position_cache.y != self.cursor_y
            or self._cursor_position_cache.x != self.cursor_x
        ):
            self._cursor_position_cache = CursorPosition(
                y=self.cursor_y, x=self.cursor_x
            )

        return self._cursor_position_cache

    def get_cursor_position_display(self) -> CursorPosition:
        return CursorPosition(
            y=self.cursor_y - self.scroll + 1,
            x=self.cursor_x - self.h_scroll + self.current_gutter_width,
        )

    def set_cursor_position(self, position: CursorPosition):
        self.cursor_y = max(0, min(position.y, len(self.lines) - 1))
        self.cursor_x = max(0, min(position.x, len(self.lines[self.cursor_y])))
        self.last_cursor_x = self.cursor_x

    def adjust_cursor_position(self):
        self.cursor_y = max(0, min(self.cursor_y, len(self.lines) - 1))
        self.cursor_x = max(0, min(self.cursor_x, len(self.lines[self.cursor_y])))
        self.last_cursor_x = self.cursor_x

    def is_modified(self):
        return self.modified

    def _normalize_lines(self, lines):
        norm = [l if isinstance(l, str) else getattr(l, "text", str(l)) for l in lines]
        norm = [l.rstrip("\r\n") for l in norm]
        return norm

    def get_line_diffs_from_action(self, action: BufferAction) -> dict[int, str]:
        """
        Compute a lightweight per-line diff map directly from a BufferAction.

        Returns a dict: { line_number (1-based) -> 'added' | 'deleted' | 'modified' }

        This avoids expensive difflib comparisons by inferring affected lines
        from the type and content of the BufferAction.
        """

        diffs: dict[int, str] = {}
        start_line = action.cursor_position.y
        action_type = action.action_type
        text = action.content

        if action_type == BufferActionTypeEnum.INSERT:
            added_lines = text.count("\n") + 1
            for i in range(added_lines):
                diffs[start_line + i + 1] = "added"

        elif action_type == BufferActionTypeEnum.DELETE:
            deleted_lines = max(1, text.count("\n") + 1)
            for i in range(deleted_lines):
                diffs[start_line + i + 1] = "deleted"

        elif action_type == BufferActionTypeEnum.REPLACE:
            if not isinstance(text, tuple):
                raise

            old_text, new_text = text

            old_lines = old_text.split("\n")
            new_lines = new_text.split("\n")

            old_count = len(old_lines)
            new_count = len(new_lines)

            if old_count == new_count:
                for i in range(new_count):
                    if old_lines[i] != new_lines[i]:
                        diffs[start_line + i + 1] = "modified"

            elif new_count > old_count:
                for i in range(new_count):
                    diffs[start_line + i + 1] = (
                        "added" if i >= old_count else "modified"
                    )

            else:
                for i in range(old_count):
                    if i >= new_count:
                        diffs[start_line + i + 1] = "deleted"
                    elif old_lines[i] != new_lines[i]:
                        diffs[start_line + i + 1] = "modified"

        else:
            raise ValueError(f"Unknown BufferActionType: {action_type}")

        return diffs

    def _delete(self, length: int):
        """
        Forward-delete with batch offset updates.
        """
        remaining = length

        while remaining > 0:
            line = self.lines[self.cursor_y]
            line_len = len(line)

            if self.cursor_y == len(self.lines) - 1 and self.cursor_x == line_len:
                return

            if self.cursor_x < line_len:
                can_delete = min(line_len - self.cursor_x, remaining)

                new_line = line[: self.cursor_x] + line[self.cursor_x + can_delete :]
                self.lines[self.cursor_y] = new_line

                remaining -= can_delete
                continue

            next_line = self.lines[self.cursor_y + 1]

            merged = line + next_line

            merged.state = None
            merged.tokens = None

            self.lines[self.cursor_y] = merged
            del self.lines[self.cursor_y + 1]

            remaining -= 1

        self.last_cursor_x = self.cursor_x

    def _insert(self, chars: str):
        """
        Insert multiple characters efficiently by batching all offset updates.
        """
        line = self.lines[self.cursor_y]
        cursor_start = self.cursor_x

        if "\n" not in chars:
            new_line = line[:cursor_start] + chars + line[cursor_start:]
            self.lines[self.cursor_y] = new_line

            self.cursor_x = cursor_start + len(chars)
            self.last_cursor_x = self.cursor_x
            return

        before = line[:cursor_start]
        after = line[cursor_start:]

        parts = [RichString(p) for p in chars.split("\n")]

        for part in parts:
            part.state = None
            part.tokens = None

        first = before + parts[0]
        last = parts[-1] + after
        middle = parts[1:-1]

        self.lines[self.cursor_y] = first

        insert_y = self.cursor_y
        for mid in middle:
            self.lines.insert(insert_y + 1, mid)

            insert_y += 1

        self.lines.insert(insert_y + 1, last)

        self.cursor_y = insert_y + 1
        self.cursor_x = len(parts[-1])
        self.last_cursor_x = self.cursor_x

    def apply_action(
        self, action: BufferAction | BufferActionGroup, store_action: bool = True
    ):
        """
        Apply a BufferAction (INSERT, DELETE, REPLACE).
        Offsets are maintained incrementally inside _insert/_delete,
        so no rebuild logic is needed here.
        """
        if isinstance(action, BufferAction):
            self.action_count += 1

            self.set_cursor_position(action.cursor_position)
            action_type = action.action_type
            payload = action.content

            start_line = self.cursor_y

            old_len = len(self.lines)

            if action_type == BufferActionTypeEnum.INSERT:
                if not isinstance(payload, str):
                    raise

                self._insert(payload)

            elif action_type == BufferActionTypeEnum.DELETE:
                if not isinstance(payload, str):
                    raise

                self._delete(len(payload))

            elif action_type == BufferActionTypeEnum.REPLACE:
                if not isinstance(payload, tuple):
                    raise

                old_text, new_text = payload
                start_y, start_x = self.cursor_y, self.cursor_x

                self._delete(len(old_text))
                self._insert(new_text)

                if "\n" not in new_text:
                    self.cursor_y = start_y
                    self.cursor_x = start_x + len(new_text)
                else:
                    added = new_text.count("\n")
                    self.cursor_y = start_y + added
                    self.cursor_x = len(new_text.splitlines()[-1])

            else:
                raise ValueError(f"Unknown action type: {action_type}")

            self.deverge_state = min(self.deverge_state, start_line)
            line = self.lines[self.deverge_state]
            line.state = None
            line.tokens = None

            delta = len(self.lines) - old_len

            if delta != 0:
                for marker, (m_line, m_col) in self.markers.items():
                    m_line += delta
                    m_line = max(0, m_line)

                    self.markers[marker] = (m_line, m_col)

            self.last_action_applyed = action
            self.last_action_applyed_timestamp = time.monotonic()

            self.modified = (
                self.last_action_when_saved is None
                or self.last_action_applyed != self.last_action_when_saved
            )

            if config.STATIC_CONFIG.get("gch", False):
                self.buffer_changes |= self.get_line_diffs_from_action(action)

            if (
                self.suffix is not None
                and (lsp_client := get_lsp(self.suffix)) is not None
            ):
                try:
                    uri = get_uri_from_name(self.file_name)
                    if lsp_client.textDocumentSync == 1:
                        lsp_client.did_change(uri=uri, text="\n".join(self.get_lines()))
                    else:
                        changes = compute_lsp_change_from_action(action, self)
                        if changes:
                            lsp_client.did_change_diffs(uri=uri, changes=changes)
                except Exception:
                    pass

            if store_action:
                self.undo_manager.store_change(action)

        else:
            group = action
            for action in group.actions:
                self.action_count += 1
                self.set_cursor_position(action.cursor_position)
                action_type = action.action_type
                payload = action.content

                start_line = self.cursor_y

                old_len = len(self.lines)

                if action_type == BufferActionTypeEnum.INSERT:
                    if not isinstance(payload, str):
                        raise

                    self._insert(payload)

                elif action_type == BufferActionTypeEnum.DELETE:
                    if not isinstance(payload, str):
                        raise

                    self._delete(len(payload))

                elif action_type == BufferActionTypeEnum.REPLACE:
                    if not isinstance(payload, tuple):
                        raise

                    old_text, new_text = payload
                    start_y, start_x = self.cursor_y, self.cursor_x

                    self._delete(len(old_text))
                    self._insert(new_text)

                    if "\n" not in new_text:
                        self.cursor_y = start_y
                        self.cursor_x = start_x + len(new_text)
                    else:
                        added = new_text.count("\n")
                        self.cursor_y = start_y + added
                        self.cursor_x = len(new_text.splitlines()[-1])

                else:
                    raise ValueError(f"Unknown action type: {action_type}")

                delta = len(self.lines) - old_len
                self.deverge_state = min(self.deverge_state, start_line)
                line = self.lines[self.deverge_state]
                line.state = None
                line.tokens = None

                if delta != 0:
                    for marker, (m_line, m_col) in self.markers.items():
                        m_line += delta
                        m_line = max(0, m_line)

                        self.markers[marker] = (m_line, m_col)

                self.last_action_applyed = action

                self.modified = (
                    self.last_action_when_saved is None
                    or self.last_action_applyed != self.last_action_when_saved
                )

                if config.STATIC_CONFIG.get("gch", False):
                    self.buffer_changes |= self.get_line_diffs_from_action(action)

                if (
                    self.suffix is not None
                    and (lsp_client := get_lsp(self.suffix)) is not None
                ):
                    try:
                        uri = get_uri_from_name(self.file_name)
                        if lsp_client.textDocumentSync == 1:
                            lsp_client.did_change(
                                uri=uri, text="\n".join(self.get_lines())
                            )
                        else:
                            changes = compute_lsp_change_from_action(action, self)
                            if changes:
                                lsp_client.did_change_diffs(uri=uri, changes=changes)
                    except Exception:
                        pass

            if store_action:
                self.undo_manager.store_change(group)

        self.adjust_cursor_position()

        if self.action_count >= config.MAX_UNDO:
            if len(self.lines.chunks) > 50:
                self.lines.normalize()
            self.action_count = 0

    def undo_action(self) -> None:
        """
        Apply the inverse of a BufferAction (for undo).
        """
        action = self.undo_manager.undo()

        if action is None:
            return

        if isinstance(action, BufferAction):
            t = action.action_type

            if t == BufferActionTypeEnum.INSERT:
                inverse_type = BufferActionTypeEnum.DELETE
                content = action.content

            elif t == BufferActionTypeEnum.DELETE:
                inverse_type = BufferActionTypeEnum.INSERT
                content = action.content

            elif t == BufferActionTypeEnum.REPLACE:
                inverse_type = BufferActionTypeEnum.REPLACE
                old_text, new_text = cast(tuple[str, str], action.content)
                content = (new_text, old_text)

            else:
                raise ValueError(f"Unknown action type: {t}")

            inverse = BufferAction(
                action_type=inverse_type,
                content=content,
                cursor_position=action.cursor_position,
            )

            self.apply_action(inverse, store_action=False)
        else:
            group = action

            inverse_actions = []

            for action in reversed(group.actions):
                t = action.action_type

                if t == BufferActionTypeEnum.INSERT:
                    inverse_type = BufferActionTypeEnum.DELETE
                    content = action.content

                elif t == BufferActionTypeEnum.DELETE:
                    inverse_type = BufferActionTypeEnum.INSERT
                    content = action.content

                elif t == BufferActionTypeEnum.REPLACE:
                    inverse_type = BufferActionTypeEnum.REPLACE
                    old_text, new_text = cast(tuple[str, str], action.content)
                    content = (new_text, old_text)

                else:
                    raise ValueError(f"Unknown action type: {t}")

                inverse = BufferAction(
                    action_type=inverse_type,
                    content=content,
                    cursor_position=action.cursor_position,
                )

                inverse_actions.append(inverse)

            inverse_group = BufferActionGroup(actions=inverse_actions)
            self.apply_action(inverse_group, store_action=False)

    def redo_action(self):
        """
        Apply the inverse of a BufferAction (for undo).
        """
        action = self.undo_manager.redo()

        if action is None:
            return

        self.apply_action(action, store_action=False)

    # cursor movement
    def move_cursor(self, key: str, screen_height: int, screen_width: int):

        if key == "Left":
            if self.cursor_x > 0:
                self.cursor_x -= 1

            self.last_cursor_x = self.cursor_x

        elif key == "Right" and self.cursor_x < len(self.lines[self.cursor_y]):
            self.cursor_x += 1
            self.last_cursor_x = self.cursor_x

        elif key == "Up" and self.cursor_y > 0:
            self.cursor_y -= 1
            self.cursor_x = min(self.last_cursor_x, len(self.lines[self.cursor_y]))

        elif key == "Down" and self.cursor_y < len(self.lines) - 1:
            self.cursor_y += 1
            self.cursor_x = min(self.last_cursor_x, len(self.lines[self.cursor_y]))

        if self.cursor_x < self.h_scroll:
            self.h_scroll = self.cursor_x
        elif self.cursor_x >= self.h_scroll + screen_width:
            self.h_scroll = self.cursor_x - screen_width + 1

        content_height = screen_height - 1
        half = content_height // 2
        max_scroll = max(0, len(self.lines) - content_height)

        if self.cursor_y < self.scroll:
            self.scroll = max(0, self.cursor_y - half)

        elif self.cursor_y > self.scroll + content_height - 1:
            self.scroll = min(max_scroll, self.cursor_y - half)

        self.scroll = max(0, min(self.scroll, max_scroll))

    def move_cursor_end_of_line(self):

        position = self.get_cursor_position()

        new_position = CursorPosition(y=position.y, x=len(self.lines[position.y]))

        self.set_cursor_position(new_position)

    def move_cursor_start_of_line(self):

        position = self.get_cursor_position()

        new_position = CursorPosition(y=position.y, x=0)

        self.set_cursor_position(new_position)

    def move_cursor_by_word(self, direction):
        """Ctrl+Arrow word-wise navigation."""

        line = self.lines[self.cursor_y]
        pos = self.cursor_x

        if direction == "right":
            # Skip over non-space then spaces
            while pos < len(line) and not line[pos].isspace():
                pos += 1
            while pos < len(line) and line[pos].isspace():
                pos += 1
        else:
            while pos > 0 and line[pos - 1].isspace():
                pos -= 1
            while pos > 0 and not line[pos - 1].isspace():
                pos -= 1

        self.cursor_x = pos
        self.last_cursor_x = pos

    def move_cursor_by_punctuation(self, direction):
        """VSCode-like Ctrl+Arrow navigation: stop at word/punctuation boundaries."""
        line = self.lines[self.cursor_y]
        pos = self.cursor_x
        length = len(line)

        def classify(ch):
            if ch.isspace():
                return "whitespace"
            elif ch.isalnum() or ch == "_":
                return "word"
            else:
                return "punct"

        if direction == "right":
            if pos >= length:
                return  # Already at end

            current_type = classify(line[pos])

            # Step over this group
            while pos < length and classify(line[pos]) == current_type:
                pos += 1

            # Step over any whitespace
            while pos < length and line[pos].isspace():
                pos += 1

        elif direction == "left":
            if pos == 0:
                return  # Already at start

            # Look at char before the cursor
            current_type = classify(line[pos - 1])

            # Step back over this group
            while pos > 0 and classify(line[pos - 1]) == current_type:
                pos -= 1

        self.cursor_x = pos
        self.last_cursor_x = pos

    def move_cursor_by_empty_line(self, direction: int, height: int):
        """
        Fast VSCode-style paragraph movement: jump to the next/previous blank line
        *before* a non-blank line, then center that line in the viewport and preserve column.
        """
        lines = self.lines
        n = len(lines)

        is_blank = [not line.strip() for line in lines]

        start = self.cursor_y + direction
        target = None

        y = start
        while 0 <= y < n:
            if is_blank[y]:
                if (direction > 0 and y + 1 < n and not is_blank[y + 1]) or (
                    direction < 0 and y - 1 >= 0 and not is_blank[y - 1]
                ):
                    target = y
                    break
            y += direction

        if target is None:
            target = (n - 1) if direction > 0 else 0

        self.cursor_y = target
        self.cursor_x = min(self.cursor_x, len(lines[target]))

        max_scroll = max(0, n - height)
        ideal_top = target - (height // 2)
        self.scroll = max(0, min(ideal_top, max_scroll))

    def find_char(self, target_char: str, forward: bool = True):
        """
        Implements:
            f{char}  -> forward
            F{char}  -> backward
            ;        -> repeat same direction
            ,        -> repeat opposite direction
        """
        line = self.lines[self.cursor_y]
        pos = self.cursor_x

        if forward:
            idx = line.find(target_char, pos + 1)
            if idx != -1:
                self.cursor_x = idx

        else:
            idx = line.rfind(target_char, 0, pos)
            if idx != -1:
                self.cursor_x = idx

        self.last_cursor_x = self.cursor_x

    def ensure_cursor_visible(self):
        """
        Adjust self.scroll_offset so that cursor_y is within the visible window.
        You'll need to know your window height (e.g. self.num_rows).
        """

        self.set_cursor_position(self.get_cursor_position())

        top = self.scroll
        bottom = top + len(self.lines) - 1

        if self.cursor_y < top:
            self.scroll = self.cursor_y
        elif self.cursor_y > bottom:
            self.scroll = self.cursor_y - (len(self.lines) - 1)

    def move_scroll(self, direction: int, height: int, move_cursor: bool = True):
        """
        Scroll buffer by `direction`, but only move the cursor if scrolling
        would put it OUTSIDE the scrolloff=8 safe region.

        This fully respects adjust_scroll() freeze zones.
        """

        SCROLLOFF = config.STATIC_CONFIG.get("scrolloff", 0)

        n_lines = len(self.lines)

        content_height = height - 1
        max_scroll = max(0, n_lines - content_height)

        old_scroll = self.scroll

        self.scroll = max(0, min(self.scroll + direction, max_scroll))

        if not move_cursor:
            return

        if self.scroll == old_scroll:
            return

        top = self.scroll
        bottom = top + content_height - 1

        safe_top = top + SCROLLOFF
        safe_bottom = bottom - SCROLLOFF

        y = self.cursor_y

        if y < safe_top:
            self.cursor_y = safe_top
        elif y > safe_bottom:
            self.cursor_y = safe_bottom

        self.cursor_y = max(0, min(self.cursor_y, n_lines - 1))

        self.cursor_x = min(self.cursor_x, len(self.lines[self.cursor_y]))

    def page_up(self, height: int):
        """
        Scroll up one page (height-2 lines), moving the cursor up the same amount,
        and never above line 0.
        """
        page = height - 2

        self.cursor_y = max(0, self.cursor_y - page)
        self.cursor_x = max(
            0, min(self.last_cursor_x, len(self.lines[self.cursor_y]) - 1)
        )
        self.scroll = max(0, self.scroll - page)

        self.ensure_cursor_visible()

    def page_down(self, height: int):
        """
        Scroll down one page (height-2 lines), moving the cursor down the same amount,
        and never past the last line.
        """
        page = height - 2
        last_line = len(self.lines) - 1
        max_scroll = max(0, len(self.lines) - height + 2)

        self.cursor_y = min(last_line, self.cursor_y + page)
        self.cursor_x = max(
            0, min(self.last_cursor_x, len(self.lines[self.cursor_y]) - 1)
        )
        self.scroll = min(max_scroll, self.scroll + page)

        self.ensure_cursor_visible()

    def go_to_file_start(self):
        """
        Jump to line 0, column 0 and scroll it into view.
        """
        self.cursor_y = 0
        self.cursor_x = 0
        self.last_cursor_x = 0

    def go_to_file_end(self):
        """
        Jump to the last line at its last column and scroll it into view.
        """
        self.cursor_y = len(self.lines) - 1
        self.cursor_x = len(self.lines[self.cursor_y])
        self.last_cursor_x = self.cursor_x
