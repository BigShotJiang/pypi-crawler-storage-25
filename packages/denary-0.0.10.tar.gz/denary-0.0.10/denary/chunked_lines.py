from bisect import bisect_left
from itertools import accumulate
from typing import Iterable, Iterator, Optional, Sequence, overload

CHUNK_SIZE = 2048
DEBUG_INVARIANTS = False


class ChunkedLines[T](Sequence[T]):
    __slots__ = (
        "chunks",
        "_prefix",
        "_total",
        "_cache_ci",
        "_cache_start",
        "_cache_end",
    )

    def __init__(self, lines: Optional[Iterable[T]] = None) -> None:
        self.chunks = []

        if lines:
            chunk = []
            for line in lines:
                chunk.append(line)
                if len(chunk) == CHUNK_SIZE:
                    self.chunks.append(chunk)
                    chunk = []

            if chunk:
                self.chunks.append(chunk)

        if not self.chunks:
            self.chunks = [[]]

        self._rebuild_prefix()
        self._invalidate_cache()

    def normalize(self) -> None:
        """
        Normalize chunk structure:
        - remove empty chunks
        - merge small neighbors
        - ensure at least one chunk
        - rebuild prefix + invalidate cache
        """
        new_chunks = [c for c in self.chunks if c]

        if not new_chunks:
            new_chunks = [[]]

        merged_chunks: list[list[T]] = []
        for c in new_chunks:
            if merged_chunks and len(merged_chunks[-1]) + len(c) <= CHUNK_SIZE:
                merged_chunks[-1].extend(c)
            else:
                merged_chunks.append(c)

        self.chunks = merged_chunks
        self._rebuild_prefix()
        self._invalidate_cache()

    def _trim_empty_chunks(self) -> None:
        """
        Remove all empty chunks except *one* at the end.
        Keeps the structure consistent for functions that expect
        no unnecessary empty lists.
        """
        self.chunks = [c for c in self.chunks if len(c) > 0]

        if not self.chunks:
            self.chunks = [[]]

        self._rebuild_prefix()
        self._invalidate_cache()

    def _invalidate_cache(self) -> None:
        self._cache_ci = 0
        self._cache_start = 0
        self._cache_end = self._prefix[0] if self._prefix else 0

    def _reset_cache_to_ci(self, ci: int) -> None:
        start = self._prefix[ci - 1] if ci > 0 else 0
        self._cache_ci = ci
        self._cache_start = start
        self._cache_end = self._prefix[ci]

    def _rebuild_prefix(self) -> None:
        chunks = self.chunks

        if not chunks:
            self.chunks = [[]]
            self._prefix = [0]
            self._total = 0
            return

        sizes = (len(c) for c in chunks)
        pref = list(accumulate(sizes))

        self._prefix = pref
        self._total = pref[-1]

    def _bump_prefix_from(self, start: int, delta: int) -> None:
        if delta == 0:
            return

        pref = self._prefix
        pref[start:] = [x + delta for x in pref[start:]]
        self._total += delta

    def _locate(self, index: int) -> tuple[int, int]:
        if index < 0:
            index += self._total
        if index < 0 or index >= self._total:
            raise IndexError("ChunkedLines index out of range")

        # 1) Fast cached range
        if self._cache_start <= index < self._cache_end:
            off = index - self._cache_start
            ci = self._cache_ci
            if DEBUG_INVARIANTS:
                assert 0 <= off < len(self.chunks[ci])
            return ci, off

        ci = self._cache_ci

        # 2) Try left neighbor
        if ci > 0:
            left_ci = ci - 1
            left_start = self._prefix[left_ci - 1] if left_ci > 0 else 0
            left_end = self._prefix[left_ci]
            if left_start <= index < left_end:
                self._cache_ci = left_ci
                self._cache_start = left_start
                self._cache_end = left_end
                off = index - left_start
                return left_ci, off

        # 3) Try right neighbor
        if ci < len(self.chunks) - 1:
            right_ci = ci + 1
            right_start = self._prefix[right_ci - 1]
            right_end = self._prefix[right_ci]
            if right_start <= index < right_end:
                self._cache_ci = right_ci
                self._cache_start = right_start
                self._cache_end = right_end
                off = index - right_start
                return right_ci, off

        # 4) Fallback — binary search
        ci = bisect_left(self._prefix, index + 1)
        start = self._prefix[ci - 1] if ci > 0 else 0
        off = index - start

        self._cache_ci = ci
        self._cache_start = start
        self._cache_end = self._prefix[ci]
        return ci, off

    def _split_if_needed(self, ci: int) -> None:
        chunk = self.chunks[ci]
        if len(chunk) > CHUNK_SIZE * 2:
            mid = len(chunk) // 2
            right = chunk[mid:]
            del chunk[mid:]

            self.chunks.insert(ci + 1, right)

            left_size = len(chunk)
            right_size = len(right)

            prev = self._prefix[ci - 1] if ci > 0 else 0
            self._prefix[ci] = prev + left_size
            self._prefix.insert(ci + 1, self._prefix[ci] + right_size)

            self._invalidate_cache()

    def _can_merge_tail(self, chunk_size: int) -> bool:
        return chunk_size < CHUNK_SIZE // 4

    def _merge_neighbors_if_small(self, ci: int) -> bool:
        total_chunks = len(self.chunks)
        is_last = ci == total_chunks - 1

        if is_last and not self._can_merge_tail(len(self.chunks[ci])):
            return False

        # Merge with next
        if ci < total_chunks - 1:
            left = self.chunks[ci]
            right = self.chunks[ci + 1]
            if len(left) + len(right) <= CHUNK_SIZE:
                size_r = len(right)
                left.extend(right)
                del self.chunks[ci + 1]
                self._prefix[ci] += size_r
                del self._prefix[ci + 1]
                self._invalidate_cache()
                return True

        # Merge with prev
        if ci > 0:
            prev = self.chunks[ci - 1]
            curr = self.chunks[ci]
            if len(prev) + len(curr) <= CHUNK_SIZE:
                size_c = len(curr)
                prev.extend(curr)
                del self.chunks[ci]
                self._prefix[ci - 1] += size_c
                del self._prefix[ci]
                self._invalidate_cache()
                return True

        return False

    def __len__(self) -> int:
        return self._total

    def __iter__(self) -> Iterator[T]:
        for c in self.chunks:
            yield from c

    @overload
    def __getitem__(self, index: int) -> T: ...

    @overload
    def __getitem__(self, index: slice) -> list[T]: ...

    def __getitem__(self, index: int | slice) -> T | list[T]:
        if isinstance(index, slice):
            start, stop, step = index.indices(self._total)
            if step != 1:
                return [self[i] for i in range(start, stop, step)]
            if start >= stop:
                return []

            ci1, off1 = self._locate(start)
            ci2, off2 = self._locate(stop - 1)
            off2 += 1

            if ci1 == ci2:
                return self.chunks[ci1][off1:off2]

            out = []
            out.extend(self.chunks[ci1][off1:])
            for ci in range(ci1 + 1, ci2):
                out.extend(self.chunks[ci])
            out.extend(self.chunks[ci2][:off2])
            return out

        ci, off = self._locate(index)
        return self.chunks[ci][off]

    def __setitem__(self, index: int, value: T) -> None:
        ci, off = self._locate(index)
        self.chunks[ci][off] = value

    def __delitem__(self, index: int) -> None:
        ci, off = self._locate(index)
        chunk = self.chunks[ci]

        del chunk[off]
        self._bump_prefix_from(ci, -1)

        if len(chunk) == 0 and len(self.chunks) > 1:
            del self.chunks[ci]
            del self._prefix[ci]
            self._invalidate_cache()
            return

        merged = self._merge_neighbors_if_small(ci)
        if not merged:
            self._invalidate_cache()

    def insert(self, index: int, value: T) -> None:
        if index < 0:
            index += self._total
        if index < 0:
            index = 0
        if index > self._total:
            index = self._total

        if index == self._total:
            ci = len(self.chunks) - 1
            self.chunks[ci].append(value)
            self._bump_prefix_from(ci, +1)
            self._invalidate_cache()
            self._split_if_needed(ci)
            return

        ci, off = self._locate(index)
        self.chunks[ci].insert(off, value)
        self._bump_prefix_from(ci, +1)
        self._invalidate_cache()
        self._split_if_needed(ci)

    def to_list(self) -> list[T]:
        out = []
        for c in self.chunks:
            out.extend(c)
        return out
