import os
import pickle
import tempfile
import zlib
from collections import deque


class UndoManager[T]:
    def __init__(
        self,
        memory_threshold: int = 2000,
        dump_size: int = 1000,
        temp_dir: str | None = None,
    ) -> None:
        self.temp_dir = temp_dir
        self.memory_threshold = memory_threshold
        self.dump_size = dump_size

        self.undo_history: deque[T] = deque()
        self.redo_history: deque[T] = deque()

        self._undo_files: list[str] = []
        self._redo_files: list[str] = []

    def _create_tempfile(self) -> str:
        tmp = tempfile.NamedTemporaryFile(delete=False, dir=self.temp_dir)
        path = tmp.name
        tmp.close()
        return path

    def _serialize_batch_to_new_file(self, changes: list[T]) -> str:
        """Create a new temp file and dump batch to it."""
        path = self._create_tempfile()
        with open(path, "wb") as f:
            f.write(zlib.compress(pickle.dumps(changes)))
        return path

    def _load_last_file(self, files_list: list[str]) -> list[T]:
        """Load last batch from file and delete file."""
        if not files_list:
            return []

        path = files_list.pop()
        try:
            with open(path, "rb") as f:
                changes = pickle.loads(zlib.decompress(f.read()))
        finally:
            os.remove(path)
        return changes

    def store_change(self, change: T) -> None:
        self.undo_history.append(change)

        if len(self.undo_history) > self.memory_threshold:
            batch = [self.undo_history.popleft() for _ in range(self.dump_size)]
            file_path = self._serialize_batch_to_new_file(batch)
            self._undo_files.append(file_path)

        self.redo_history.clear()

        while self._redo_files:
            os.remove(self._redo_files.pop())

    def undo(self) -> T | None:
        if not self.undo_history:
            batch = self._load_last_file(self._undo_files)
            if batch:
                self.undo_history.extend(batch)
            else:
                return None

        change = self.undo_history.pop()

        self.redo_history.append(change)

        if len(self.redo_history) > self.memory_threshold:
            batch = [self.redo_history.popleft() for _ in range(self.dump_size)]
            file_path = self._serialize_batch_to_new_file(batch)
            self._redo_files.append(file_path)

        return change

    def redo(self) -> T | None:
        if not self.redo_history:
            batch = self._load_last_file(self._redo_files)
            if batch:
                self.redo_history.extend(batch)
            else:
                return None

        change = self.redo_history.pop()

        self.undo_history.append(change)
        if len(self.undo_history) > self.memory_threshold:
            batch = [self.undo_history.popleft() for _ in range(self.dump_size)]
            file_path = self._serialize_batch_to_new_file(batch)
            self._undo_files.append(file_path)

        return change

    def cleanup(self) -> None:
        for path in self._undo_files + self._redo_files:
            if os.path.exists(path):
                os.remove(path)
        self._undo_files.clear()
        self._redo_files.clear()
