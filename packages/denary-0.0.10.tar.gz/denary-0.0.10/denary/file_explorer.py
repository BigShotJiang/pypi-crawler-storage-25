from __future__ import annotations

import curses
import os
import shutil
import traceback
from pathlib import Path
from typing import TYPE_CHECKING, Optional

from denary.key_mappings import get_key_mapping
from denary.notifications import send_notification
from denary.prompts import send_prompt, send_prompt_confirm

if TYPE_CHECKING:
    from denary.editor import SimpleEditor


def show_explorer(editor: SimpleEditor, start_dir: Optional[str] = None):
    """
    Vim-style :Ex file explorer with create, delete, rename, move operations + search.
    Keys:
      /k, /j  move
      Enter     open/descend
      a         new file/dir (dir ends with '/')
      d         delete
      r         rename
      m         move
      /         search (case-insensitive). Empty query clears search
      n         next match (wraps)
      N         previous match (wraps)
      q or Esc  quit
    """

    buffer = editor.get_current_buffer()
    file_path = (
        buffer.file_path.parent
        if getattr(buffer, "file_name", None) and getattr(buffer, "file_path", None)
        else os.getcwd()
    )
    cwd = Path(start_dir or file_path).resolve()
    _base = Path(start_dir or os.getcwd()).resolve()

    cursor = 0
    scroll = 0
    search_query = ""

    def _is_relative_to(p: Path, base: Path) -> bool:
        try:
            p.relative_to(base)
            return True
        except Exception:
            return False

    def _safe_join(base: Path, child_name: str) -> Path:
        clean = child_name[:-1] if child_name.endswith("/") else child_name
        target = (base / clean).resolve()
        return target if _is_relative_to(target, _base) else base

    def _safe_is_dir(p: Path) -> bool:
        try:
            return p.is_dir()
        except (PermissionError, FileNotFoundError, OSError):
            return False

    def _exists_safe(p: Path) -> bool:
        try:
            return p.exists()
        except Exception:
            return False

    def _has_access_dir(p: Path) -> bool:
        try:
            return os.access(p, os.R_OK | os.X_OK)
        except Exception:
            return False

    def _has_access_file(p: Path) -> bool:
        try:
            return os.access(p, os.R_OK)
        except Exception:
            return False

    def list_entries_full():
        """Return the full, safe entry list for cwd (no search applied)."""
        items = []
        if cwd != _base:
            items.append("../")
        try:
            with os.scandir(cwd) as it:
                bucket = []
                for entry in it:
                    try:
                        is_dir = entry.is_dir(follow_symlinks=False)
                    except (PermissionError, FileNotFoundError, OSError):
                        continue
                    name = entry.name + ("/" if is_dir else "")
                    bucket.append((not is_dir, entry.name.lower(), name))
            items.extend(n for _, __, n in sorted(bucket))
        except PermissionError:
            pass
        return items

    def apply_search(all_items, q):
        """Filter by case-insensitive substring q (empty -> identity)."""
        if not q:
            return list(all_items)
        ql = q.lower()
        out = []
        for name in all_items:
            if name == "../":
                out.append(name)
                continue
            if ql in name.lower():
                out.append(name)
        return out

    def jump_to_first_match(display_items, q):
        """Position cursor on first matching item (keep scroll sane)."""
        nonlocal cursor, scroll
        if not q:
            return
        ql = q.lower()
        for i, name in enumerate(display_items):
            if name != "../" and ql in name.lower():
                cursor = i
                if cursor < scroll or cursor >= scroll + win_h:
                    scroll = max(0, min(cursor, max(0, len(display_items) - win_h)))
                return

    def next_match(display_items, q, backwards=False):
        """Move cursor to next/prev match, wrapping."""
        nonlocal cursor, scroll
        if not q or not display_items:
            return
        ql = q.lower()
        n = len(display_items)
        if n <= 1:
            return
        step = -1 if backwards else 1
        i = cursor
        for _ in range(n - 1):
            i = (i + step) % n
            name = display_items[i]
            if name != "../" and ql in name.lower():
                cursor = i
                # keep visible
                if cursor < scroll:
                    scroll = cursor
                elif cursor >= scroll + win_h:
                    scroll = cursor - win_h + 1
                return

    entries_full = list_entries_full()
    display_entries = apply_search(entries_full, search_query)

    h, w = editor.stdscr.getmaxyx()
    win_h, win_w = h - 3, w - 4
    win_y, win_x = 1, 2

    current_buffer_path = None

    try:
        current_buffer_path = editor.get_current_buffer().file_path.resolve()
    except Exception:
        pass

    if current_buffer_path:
        for index, entry in enumerate(display_entries):
            if entry == "../":
                continue

            entry_path = _safe_join(cwd, entry).resolve()

            if entry_path == current_buffer_path:
                cursor = index

                if cursor < scroll:
                    scroll = cursor
                elif cursor >= scroll + win_h:
                    scroll = max(0, cursor - win_h + 1)

                break

    attr_normal = curses.A_NORMAL
    attr_sel = curses.A_REVERSE
    attr_match = curses.A_BOLD

    def draw_row(y, name, selected):
        """Draw an entry; highlight search match span if active."""
        attr = attr_sel if selected else attr_normal

        if not search_query or name == "../":
            editor.stdscr.addnstr(y, win_x, name.ljust(win_w), win_w, attr)
            return

        low = name.lower()
        ql = search_query.lower()
        k = low.find(ql)
        if k < 0:
            editor.stdscr.addnstr(y, win_x, name.ljust(win_w), win_w, attr)
            return

        left = name[:k]
        mid = name[k : k + len(ql)]
        right = name[k + len(ql) :]

        x = win_x
        seg = left[: max(0, win_w)]
        editor.stdscr.addnstr(y, x, seg, win_w, attr)
        x += len(seg)

        if x < win_x + win_w:
            seg = mid[: (win_x + win_w - x)]
            editor.stdscr.addnstr(y, x, seg, len(seg), attr | attr_match)
            x += len(seg)

        if x < win_x + win_w:
            seg = right[: (win_x + win_w - x)]
            editor.stdscr.addnstr(y, x, seg, len(seg), attr)
            x += len(seg)

        if x < win_x + win_w:
            editor.stdscr.addnstr(
                y, x, " " * (win_x + win_w - x), (win_x + win_w - x), attr
            )

    # this is here because when the file_viewer is open the key of the macro that started it should be consume
    if (
        editor.current_macro_playing_index is not None
        and editor.current_macro_playing_name is not None
    ):
        editor.current_macro_playing_index += 1

    while True:
        max_scroll = max(0, len(display_entries) - win_h)
        scroll = min(scroll, max_scroll)
        cursor = max(0, min(cursor, max(0, len(display_entries) - 1)))

        editor.stdscr.erase()
        editor.stdscr.border()
        title = f" Current Path:  {cwd} "
        editor.stdscr.addnstr(0, 2, title, w - 4, curses.A_REVERSE)

        for idx in range(scroll, scroll + win_h):
            if idx >= len(display_entries):
                break
            y = win_y + idx - scroll
            name = display_entries[idx]
            draw_row(y, name, selected=(idx == cursor))

        if search_query:
            status = f"[/] Search: {search_query}   [n] Next  [N] Prev [a] New [d] Delete [r] Rename [m] Move  [c] Copy  [q] Quit"
        else:
            status = "[/] Search  [n] Next  [N] Prev  [a] New  [d] Delete  [r] Rename  [m] Move  [c] Copy  [q] Quit"
        editor.stdscr.addnstr(h - 2, 2, status.ljust(win_w), win_w, curses.A_REVERSE)

        editor.stdscr.refresh()

        if (
            editor.current_macro_playing_index is not None
            and editor.current_macro_playing_name is not None
        ):
            key = editor.macros.get(editor.current_macro_playing_name, [])[
                editor.current_macro_playing_index
            ]
            editor.current_macro_playing_index += 1
        else:
            try:
                key = editor.stdscr.get_wch()
            except curses.error:
                key = None

            key = get_key_mapping(editor.stdscr, key)

            if (
                editor.recording_macro
                and editor.current_macro_recording is not None
                and key is not None
            ):
                editor.macros[editor.current_macro_recording].append(key)

        curses.flushinp()

        if key in ("Up", "k"):
            cursor -= 1
            if cursor < scroll:
                scroll = max(0, scroll - 1)

        elif key in ("Down", "j"):
            cursor += 1
            if cursor >= scroll + win_h:
                scroll = min(max_scroll, scroll + 1)

        elif key == "g":
            cursor = 0
            scroll = 0

        elif key == "G":
            cursor = len(entries_full)
            scroll = max_scroll

        elif key in ("Enter", 10, 13, "Ctrl+J", "Ctrl+M"):
            if not display_entries:
                continue

            choice = display_entries[cursor]

            if choice == "../":
                parent = cwd.parent
                cwd = parent if _is_relative_to(parent, _base) else _base
                entries_full = list_entries_full()
                display_entries = apply_search(entries_full, search_query)
                cursor = scroll = 0
                continue

            target = _safe_join(cwd, choice)

            if choice.endswith("/"):
                if _safe_is_dir(target) and _has_access_dir(target):
                    cwd = target
                    entries_full = list_entries_full()
                    display_entries = apply_search(entries_full, search_query)
                    cursor = scroll = 0
                else:
                    send_notification(
                        window=editor.stdscr,
                        message=f"Permission denied: {choice}",
                        duration=2000,
                        editor=editor,
                    )
                continue

            if not _has_access_file(target):

                send_notification(
                    window=editor.stdscr,
                    message=f"Permission denied: {choice}",
                    duration=2000,
                    editor=editor,
                )

                continue

            try:
                rel = str(target.relative_to(_base))
            except Exception:
                rel = str(target)

            for b_i, buf in enumerate(editor.buffers):
                try:
                    if buf.file_name and (
                        buf.file_name == rel or Path(buf.file_name).resolve() == target
                    ):
                        editor.current_buffer = b_i

                        send_notification(
                            window=editor.stdscr,
                            message=f"Switched to buffer: {choice}",
                            editor=editor,
                        )

                        break
                except Exception:
                    continue
            else:
                try:
                    editor.open_buffer(rel)

                    send_notification(
                        window=editor.stdscr,
                        message=f"Opened file: {choice}",
                        editor=editor,
                    )

                except Exception as e:
                    send_notification(
                        window=editor.stdscr,
                        message=f"Open failed: {e}",
                        duration=0,
                        editor=editor,
                    )

                    continue
            break

        elif key == "/":
            prompt = "Search (empty to clear): "
            q_in = send_prompt(
                window=editor.stdscr,
                prompt_message=prompt,
                editor=editor,
            )

            search_query = q_in
            display_entries = apply_search(entries_full, search_query)

            jump_to_first_match(display_entries, search_query)

            max_scroll = max(0, len(display_entries) - win_h)
            scroll = min(scroll, max_scroll)

        elif key == "n":
            next_match(display_entries, search_query, backwards=False)

        elif key == "N":
            next_match(display_entries, search_query, backwards=True)

        elif key == "a":
            prompt = "New name (file or dir/): "

            name = send_prompt(
                window=editor.stdscr,
                prompt_message=prompt,
                editor=editor,
            )

            if name:
                new_path = _safe_join(cwd, name)
                try:
                    if name.endswith("/"):
                        new_path.mkdir(parents=True, exist_ok=True)
                    else:
                        new_path.parent.mkdir(parents=True, exist_ok=True)
                        if not _exists_safe(new_path):
                            new_path.touch(exist_ok=False)
                        else:
                            send_notification(
                                window=editor.stdscr,
                                message="File already exists.",
                                duration=1200,
                                editor=editor,
                            )
                except FileExistsError:
                    send_notification(
                        window=editor.stdscr,
                        message="File already exists.",
                        duration=1200,
                        editor=editor,
                    )

                except Exception as e:
                    send_notification(
                        window=editor.stdscr,
                        message=f"Create failed: {e}",
                        duration=2000,
                        editor=editor,
                    )

                entries_full = list_entries_full()
                display_entries = apply_search(entries_full, search_query)

            editor.fuzzy_changed = True

        elif key == "d":
            if not display_entries:
                continue
            choice = display_entries[cursor]
            if choice in ("../",):
                continue
            target = _safe_join(cwd, choice)
            if not _exists_safe(target):

                send_notification(
                    window=editor.stdscr,
                    message="Target does not exist.",
                    duration=1500,
                    editor=editor,
                )

                continue

            prompt = f"Delete '{choice}'?"

            if send_prompt_confirm(
                window=editor.stdscr,
                prompt_message=prompt,
                color_p=15,
                editor=editor,
            ):
                try:
                    if _safe_is_dir(target):
                        shutil.rmtree(target)
                    else:
                        target.unlink()
                except Exception as e:
                    send_notification(
                        window=editor.stdscr,
                        message=f"Delete failed: {e}",
                        duration=2000,
                        editor=editor,
                    )

            entries_full = list_entries_full()
            display_entries = apply_search(entries_full, search_query)
            cursor = min(cursor, max(0, len(display_entries) - 1))
            editor.fuzzy_changed = True

        elif key == "r":
            if not display_entries:
                continue
            choice = display_entries[cursor]
            if choice in ("../",):
                continue
            target = _safe_join(cwd, choice)
            if not _exists_safe(target):
                send_notification(
                    window=editor.stdscr,
                    message="Target does not exist.",
                    duration=1500,
                )
                continue

            clean_choice = choice[:-1] if choice.endswith("/") else choice

            new_name = send_prompt(
                window=editor.stdscr,
                prompt_message="Rename: ",
                current_value=clean_choice,
                editor=editor,
            )

            if new_name:
                dest = _safe_join(target.parent, new_name)
                if not _is_relative_to(dest, _base):
                    send_notification(
                        window=editor.stdscr,
                        message="Operation blocked outside base dir.",
                        duration=2000,
                        editor=editor,
                    )
                else:
                    try:
                        target.rename(dest)
                        for buf in editor.buffers:
                            try:
                                if (
                                    buf.file_name
                                    and Path(buf.file_name).resolve() == target
                                ):
                                    try:
                                        buf.file_name = str(dest.relative_to(_base))
                                    except Exception:
                                        buf.file_name = str(dest)
                                    break
                            except Exception:
                                continue
                    except Exception as e:
                        send_notification(
                            window=editor.stdscr,
                            message=f"Rename failed: {e}",
                            duration=2000,
                            editor=editor,
                        )

                entries_full = list_entries_full()
                display_entries = apply_search(entries_full, search_query)

            editor.fuzzy_changed = True

        elif key == "c":
            if not display_entries:
                continue

            choice = display_entries[cursor]
            if choice in ("../",):
                continue

            source = _safe_join(cwd, choice)
            if not _exists_safe(source):
                send_notification(
                    window=editor.stdscr,
                    message="Source does not exist.",
                    duration=1500,
                    editor=editor,
                )
                continue

            prompt = f"Copy '{choice}' to (path): "
            dest_in = send_prompt(
                window=editor.stdscr,
                prompt_message=prompt,
                editor=editor,
            )

            if not dest_in:
                continue

            dest_path_typed = Path(dest_in)
            dest = (
                _safe_join(cwd, dest_in).resolve()
                if not dest_path_typed.is_absolute()
                else dest_path_typed.resolve()
            )

            if source.is_dir():
                dest = dest / source.name

            if not _is_relative_to(dest, _base):
                send_notification(
                    window=editor.stdscr,
                    message="Operation blocked outside base dir.",
                    duration=2000,
                    editor=editor,
                )

                continue

            try:
                if dest.exists():
                    prompt = f"'{dest.name}' exists. Overwrite?"

                    if not send_prompt_confirm(
                        window=editor.stdscr,
                        prompt_message=prompt,
                        editor=editor,
                    ):
                        send_notification(
                            window=editor.stdscr,
                            message="Copy cancelled.",
                            duration=1500,
                            editor=editor,
                        )

                        continue

                    if dest.is_dir():
                        shutil.rmtree(dest)
                    else:
                        dest.unlink()

                if source.is_dir():
                    shutil.copytree(source, dest)
                else:
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(source, dest)

                send_notification(
                    window=editor.stdscr,
                    message=f"Copied to {dest}",
                    duration=1800,
                    editor=editor,
                )

            except Exception as e:
                send_notification(
                    window=editor.stdscr,
                    message=f"Copy failed: {e}",
                    duration=2500,
                    editor=editor,
                )

            entries_full = list_entries_full()
            display_entries = apply_search(entries_full, search_query)
            cursor = min(cursor, max(0, len(display_entries) - 1))
            editor.fuzzy_changed = True

        elif key == "m":
            if not display_entries:
                continue

            choice = display_entries[cursor]
            if choice in ("../",):
                continue

            target = _safe_join(cwd, choice)
            if not _exists_safe(target):
                send_notification(
                    window=editor.stdscr,
                    message="Target does not exist.",
                    duration=1500,
                    editor=editor,
                )

                continue

            prompt = f"Move '{choice}' to (path): "

            dest_in = send_prompt(
                window=editor.stdscr,
                prompt_message=prompt,
                editor=editor,
            )

            def _abs(p: str | Path) -> Path:
                p = Path(p)
                if p.is_absolute():
                    return p.resolve()
                return (Path(editor.working_dir) / p).resolve()

            def _rel_to_base(p: Path) -> str:
                base = Path(editor.working_dir).resolve()
                try:
                    return str(p.resolve().relative_to(base))
                except Exception:
                    return str(p.resolve())

            def rel_smart(p: Path) -> str:
                p = p.resolve()

                work = Path(editor.working_dir).resolve()
                cwd_base = Path(cwd).resolve()

                try:
                    return str(p.relative_to(work))
                except ValueError:
                    pass

                try:
                    return str(p.relative_to(cwd_base))
                except ValueError:
                    pass

                return str(p)

            def rebase_path(path: Path, old_root: Path, new_root: Path) -> Path:
                """If `path` lies under `old_root`, return equivalent path under `new_root`."""
                path = path.resolve()
                old_root = old_root.resolve()
                new_root = new_root.resolve()
                try:
                    sub = path.relative_to(old_root)
                except ValueError:
                    return path
                else:
                    return (new_root / sub).resolve()

            def remap_after_move(path: Path, old: Path, new: Path) -> Path:
                """Remap `path` after moving old->new (dir = rebase; file = exact swap)."""
                path = path.resolve()
                old = old.resolve()
                new = new.resolve()
                if old.is_dir():
                    return rebase_path(path, old, new)
                else:
                    return new if path == old else path

            if dest_in:
                dest_path_typed = Path(dest_in)
                dest = (
                    _safe_join(cwd, dest_in).resolve()
                    if not dest_path_typed.is_absolute()
                    else dest_path_typed.resolve()
                )

                if target.is_dir():
                    dest = dest / target.name

                if not _is_relative_to(dest, _base):
                    send_notification(
                        window=editor.stdscr,
                        message="Operation blocked outside base dir.",
                        duration=2000,
                        editor=editor,
                    )

                else:
                    try:
                        dest.parent.mkdir(parents=True, exist_ok=True)

                        old_abs = target.resolve()
                        new_abs = dest.resolve()
                        base_abs = Path(editor.working_dir).resolve()

                        if old_abs.is_dir():
                            for buf in editor.buffers:
                                fn = getattr(buf, "file_name", None)
                                if not fn:
                                    continue
                                buf_abs = _abs(fn)
                                try:
                                    buf_abs.relative_to(old_abs)
                                except ValueError:
                                    continue
                                new_buf_abs = remap_after_move(
                                    buf_abs, old_abs, new_abs
                                )
                                buf.file_path = new_buf_abs
                                buf.file_name = _rel_to_base(new_buf_abs)
                        else:

                            if dest.exists() and dest.is_dir():
                                dest = dest / target.name

                            old_abs = target.resolve()
                            new_abs = dest.resolve()

                            for buf in editor.buffers:
                                fn = getattr(buf, "file_name", None)
                                if not fn:
                                    continue

                                buf_abs = _abs(fn)

                                if buf_abs == old_abs:
                                    buf.file_path = new_abs
                                    buf.file_name = rel_smart(new_abs)
                                    break

                        shutil.move(str(old_abs), str(new_abs))

                    except Exception as e:
                        send_notification(
                            window=editor.stdscr,
                            message=f"Move failed: {e}",
                            duration=2000,
                            editor=editor,
                        )

                entries_full = list_entries_full()
                display_entries = apply_search(entries_full, search_query)
                cursor = min(cursor, max(0, len(display_entries) - 1))
                editor.fuzzy_changed = True

        elif key in (27, "q", "Ctrl+C", "ESC"):
            break

    editor.adjust_scroll()
