from __future__ import annotations

import curses
import time
from typing import TYPE_CHECKING, Any, Callable, Optional

from denary import notifications
from denary.key_mappings import SHIFT_TAB_KEY, TAB_KEY_FUNC, get_key_mapping

if TYPE_CHECKING:
    from denary.editor import SimpleEditor


def show_picker_display(
    window: curses.window,
    entries: list[Any],
    display_func: Optional[Callable[[Any], str]] = None,
    compare_func: Optional[Callable[[Any, str], bool]] = None,
    external_filter: Optional[
        Callable[[str, list[dict[str, Any]]], list[dict[str, Any]]]
    ] = None,
    selection_change: Optional[Callable[[Optional[Any]], None]] = None,
    debounce_ms: Optional[int] = None,
    increment_macro_start: bool = True,
    position: Optional[tuple[int, int]] = None,
    max_height: Optional[int] = None,
    return_query: bool = False,
    break_chars: Optional[set[str]] = None,
    initial_query: Optional[str] = None,
    editor: Optional[SimpleEditor] = None,
) -> Optional[Any]:
    """
    Dynamic picker UI (scrollable, searchable).
    Supports initial_query correctly and keeps display prefix separate
    from the actual filter query.
    """

    if not display_func:

        def display_func(obj):
            return str(obj) or "[No Name]"

    if not compare_func:

        def compare_func(obj, query):
            if not query:
                return True
            return query.lower() in display_func(obj).lower()

    if not entries:
        notifications.send_notification(
            window=window, message="There is nothing to display.", duration=1000
        )
        return None

    curses.curs_set(0)

    height, width = window.getmaxyx()

    wrapped = [{"display": display_func(e), "value": e} for e in entries]
    matches = wrapped[:]

    query = str(initial_query) if initial_query is not None else ""
    query_prefix = "> "

    # available number of result rows
    visible_rows = min(len(entries), max(1, height - 4))
    if max_height is not None:
        visible_rows = min(visible_rows, max_height, len(entries))

    max_entry_w = max((len(item["display"]) for item in wrapped), default=0)
    max_query_w = len(query_prefix + query)

    # +2 padding inside box, capped to terminal width
    max_w = min(max(max_entry_w, max_query_w) + 2, width - 4)

    # border top + query row + result rows + border bottom
    win_h = visible_rows + 3
    win_w = max_w + 2

    if position is not None:
        pos_y, pos_x = position

        start_y = pos_y
        if start_y + win_h > height:
            start_y = height - win_h
        start_y = max(0, start_y)

        preferred_x = pos_x + 1

        if preferred_x + win_w <= width:
            start_x = preferred_x
        else:
            start_x = max(pos_x, width - win_w)
    else:
        start_y = max(0, (height - win_h) // 2)
        start_x = max(0, (width - win_w) // 2)

    popup = curses.newwin(win_h, win_w, start_y, start_x)
    popup.keypad(True)
    popup.timeout(200)

    idx = 0
    scroll = 0

    last_update_time = time.time() if query else None
    last_filter_query = None
    first_keystroke = False if query else True

    if (
        editor is not None
        and editor.current_macro_playing_index is not None
        and editor.current_macro_playing_name is not None
    ):
        if increment_macro_start:
            editor.current_macro_playing_index += 1

        debounce_ms = None

    try:
        while True:
            now = time.time()
            should_filter = False

            if debounce_ms is None:
                should_filter = query != last_filter_query
            else:
                if query != last_filter_query:
                    if first_keystroke:
                        should_filter = False
                    elif last_update_time is None:
                        should_filter = True
                    else:
                        elapsed_ms = (now - last_update_time) * 1000
                        if elapsed_ms >= debounce_ms:
                            should_filter = True

            if should_filter:
                last_filter_query = query

                if external_filter:
                    result = external_filter(query, wrapped) or []

                    if result and isinstance(result[0], str):
                        result_set = set(result)
                        matches = [e for e in wrapped if e["display"] in result_set]
                    else:
                        obj_set = set(result)
                        matches = [e for e in wrapped if e["value"] in obj_set]
                else:
                    if not query:
                        matches = wrapped[:]
                    else:
                        matches = [
                            e for e in wrapped if compare_func(e["value"], query)
                        ]

                if not matches:
                    matches = [{"display": "<no matches>", "value": None}]

                idx = 0
                scroll = 0

            idx = max(0, min(idx, len(matches) - 1))

            if idx < scroll:
                scroll = idx
            elif idx >= scroll + visible_rows:
                scroll = idx - visible_rows + 1

            popup.erase()
            popup.box()

            max_text_width = win_w - 4

            shown_query = query_prefix + query
            popup.addnstr(1, 1, shown_query[:max_text_width], max_text_width)

            cursor_x = min(len(shown_query), max_text_width)
            popup.move(1, 1 + cursor_x)

            visible = matches[scroll : scroll + visible_rows]

            for i, entry in enumerate(visible):
                y = 2 + i
                attr = curses.A_REVERSE if (scroll + i) == idx else curses.A_NORMAL
                popup.addnstr(
                    y,
                    1,
                    entry["display"].ljust(max_w)[:max_text_width],
                    max_text_width,
                    attr,
                )

            popup.refresh()

            ch: Optional[int | str] = None

            if (
                editor is not None
                and editor.current_macro_playing_index is not None
                and editor.current_macro_playing_name is not None
            ):
                ch = editor.macros.get(editor.current_macro_playing_name, [])[
                    editor.current_macro_playing_index
                ]
                editor.current_macro_playing_index += 1
            else:
                key: Optional[int | str] = None

                try:
                    key = popup.get_wch()
                except curses.error:
                    key = None

                ch = get_key_mapping(popup, key)

                popup.timeout(200)

                if (
                    ch is not None
                    and editor is not None
                    and editor.recording_macro
                    and editor.current_macro_recording is not None
                ):
                    editor.macros[editor.current_macro_recording].append(ch)

            if ch in ("Ctrl+C", "ESC", 27):
                if return_query and query:
                    return query

                return None

            elif ch == 0 or ch == "\x00":
                continue

            elif ch == "Ctrl+P":
                if editor is not None and editor.clipboard is not None:
                    clipboard_text = "\n".join(editor.clipboard)
                    if clipboard_text:
                        query += clipboard_text
                        last_update_time = time.time()
                        first_keystroke = False

            elif ch in (10, 13, "Ctrl+J", "Enter", "Ctrl+M"):
                choice = matches[idx]

                if choice["value"] is not None:
                    return choice["value"]

                if return_query and query:
                    return query

                return None

            elif ch in ("Backspace", 127, 8, "Ctrl+H"):
                if query:
                    query = query[:-1]
                    last_update_time = time.time()
                    first_keystroke = False

                elif return_query:
                    return None

            elif ch in ("Down", 9) or TAB_KEY_FUNC(ch):
                idx = (idx + 1) % len(matches)
                if selection_change:
                    selection_change(matches[idx].get("value"))

            elif ch in ("Up", 353) or ch == SHIFT_TAB_KEY:
                idx = (idx - 1) % len(matches)
                if selection_change:
                    selection_change(matches[idx].get("value"))

            elif isinstance(ch, str) and len(ch) == 1:
                if break_chars is not None and ch in break_chars:
                    if return_query and query:
                        return query

                    return None

                query += ch
                last_update_time = time.time()
                first_keystroke = False

    finally:
        del popup
        curses.curs_set(0)
        curses.flushinp()

        if editor is not None:
            editor.adjust_scroll()
            editor.draw()
