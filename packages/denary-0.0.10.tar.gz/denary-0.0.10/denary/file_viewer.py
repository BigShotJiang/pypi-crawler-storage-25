from __future__ import annotations

import curses
from typing import IO, TYPE_CHECKING, AnyStr, Iterator, Optional

from denary.prompts import send_prompt

if TYPE_CHECKING:
    from denary.editor import SimpleEditor


def open_file_in_less_mode(
    window: curses.window,
    file_handle: IO[AnyStr],
    editor: Optional[SimpleEditor] = None,
    cursor_pos: Optional[tuple[int, int]] = None,
):
    """
    Stream file content like `less`, with SLIDING WINDOW:
    - Never loads whole file into memory
    - File is kept OPEN at all times
    - True forward/backwards search with wrap-around once
    - g/G, /, n, N, horizontal scroll, highlighting
    - Window sizing EXACTLY like original code
    """

    # if there is a macro playing just return and augment the macro index
    if (
        editor is not None
        and editor.current_macro_playing_index is not None
        and editor.current_macro_playing_name is not None
    ):
        editor.current_macro_playing_index += 1
        return

    height, width = window.getmaxyx()

    if cursor_pos is None:
        cursor_y, cursor_x = window.getyx()
    else:
        cursor_y, cursor_x = cursor_pos

    WINDOW_SIZE = max(height * 3, 2000)

    file_offsets: list[int] = []
    line_count = 0
    eof = False
    stream_pos = file_handle.tell()

    _window: list[str] = []
    window_start = 0

    scroll_line = 0
    h_scroll = 0

    last_search = None
    last_search_lower = None
    last_search_results: list[tuple[int, int]] = []
    last_search_index = 0

    highlight_attr = curses.A_REVERSE | curses.A_BOLD
    normal_attr = curses.A_NORMAL

    def safe_decode(line):
        if isinstance(line, str):
            return line.replace("\x00", "�")
        for enc in ("utf-8", "latin1"):
            try:
                return line.decode(enc).replace("\x00", "�")
            except:
                pass
        return line.decode("utf-8", errors="replace").replace("\x00", "�")

    def read_next_line() -> bool:
        nonlocal eof, line_count, stream_pos

        if eof:
            return False

        file_handle.seek(stream_pos)
        offset = stream_pos
        raw = file_handle.readline()
        if not raw:
            eof = True
            return False

        text = safe_decode(raw).rstrip("\n")
        file_offsets.append(offset)
        line_count += 1
        stream_pos = file_handle.tell()
        return True

    def ensure_lines_up_to(target_line: int):
        if target_line < 0:
            return
        while not eof and line_count <= target_line:
            if not read_next_line():
                break

    def ensure_window_for(top_line: int):
        nonlocal _window, window_start, scroll_line

        if line_count == 0 and not eof:
            read_next_line()

        ensure_lines_up_to(top_line + height)

        if line_count == 0:
            _window = []
            window_start = 0
            scroll_line = 0
            return

        max_scroll = max(0, line_count - 1)
        if top_line > max_scroll:
            top_line = max_scroll

        if _window and window_start <= top_line < window_start + len(_window):
            end_needed = top_line + (height - 2)
            if end_needed <= window_start + len(_window):
                scroll_line = top_line
                return

        _window = []
        window_start = top_line

        saved = file_handle.tell()
        file_handle.seek(file_offsets[top_line])

        limit = min(line_count, top_line + WINDOW_SIZE)

        for line_idx in range(top_line, limit):
            raw = file_handle.readline()
            if not raw:
                break
            text = safe_decode(raw).rstrip("\n")
            _window.append(text)

        file_handle.seek(saved)
        scroll_line = top_line

    def get_line(idx: int) -> str:
        if idx < 0 or idx >= line_count:
            return ""
        if window_start <= idx < window_start + len(_window):
            return _window[idx - window_start]

        saved = file_handle.tell()
        file_handle.seek(file_offsets[idx])
        raw = file_handle.readline()
        file_handle.seek(saved)
        return safe_decode(raw).rstrip("\n") if raw else ""

    def compute_max_hscroll() -> int:
        if not _window:
            return 0
        m = max((len(l) for l in _window), default=0)
        return max(0, m - (win_width - 2))

    def center_horizontally_on_match(text, hit):
        nonlocal h_scroll
        max_h = compute_max_hscroll()
        if max_h <= 0:
            h_scroll = 0
            return
        ideal = hit - (win_width // 2)
        ideal = max(0, min(ideal, max_h))
        h_scroll = ideal

    def perform_search(pattern: str) -> list[tuple[int, int]]:
        nonlocal last_search, last_search_lower

        last_search = pattern
        last_search_lower = pattern.lower()

        res: list[tuple[int, int]] = []

        if line_count > 0:
            saved = file_handle.tell()

            for idx in range(line_count):
                file_handle.seek(file_offsets[idx])
                raw = file_handle.readline()
                if not raw:
                    break

                text = safe_decode(raw).rstrip("\n")
                lo = text.lower()

                start = 0
                while True:
                    hit = lo.find(last_search_lower, start)
                    if hit == -1:
                        break

                    res.append((idx, hit))
                    start = hit + 1

            file_handle.seek(saved)

        if not eof:
            while not eof:
                if not read_next_line():
                    break

                idx = line_count - 1
                text = get_line(idx)
                lo = text.lower()

                start = 0
                while True:
                    hit = lo.find(last_search_lower, start)
                    if hit == -1:
                        break

                    res.append((idx, hit))
                    start = hit + 1

        return res

    def jump_to_search_index(i):
        nonlocal scroll_line

        if not last_search_results:
            return

        i = i % len(last_search_results)
        target_line, target_col = last_search_results[i]

        ensure_window_for(target_line)
        scroll_line = target_line

        text = get_line(target_line)
        center_horizontally_on_match(text, target_col)

    scroll_line = 0
    ensure_window_for(scroll_line)

    max_line_len: int = max((len(line) for line in _window), default=1)
    win_height: int = min(height - 2, len(_window) + 2)
    win_width: int = min(width - 1, max_line_len + 2)

    start_y = cursor_y + 1
    start_x = cursor_x

    if start_y + win_height > height:
        start_y = max(0, cursor_y - win_height)
    if start_x + win_width > width:
        start_x = max(0, width - win_width)

    win = curses.newwin(win_height, win_width, start_y, start_x)
    win.keypad(True)
    win.nodelay(True)
    curses.curs_set(0)

    max_visible = win_height - 2

    def draw():
        nonlocal scroll_line, h_scroll
        ensure_window_for(scroll_line)

        win.erase()
        win.box()

        max_scroll = max(0, line_count - 1)
        if scroll_line < 0:
            scroll_line = 0
        elif scroll_line > max_scroll:
            scroll_line = max_scroll

        max_h = compute_max_hscroll()
        if h_scroll < 0:
            h_scroll = 0
        elif h_scroll > max_h:
            h_scroll = max_h

        pat = last_search_lower
        plen = len(pat) if pat else 0

        for row in range(max_visible):
            idx = scroll_line + row
            if idx >= line_count:
                break

            text = get_line(idx)
            segment = text[h_scroll : h_scroll + (win_width - 2)]

            if pat and plen > 0:
                lo = text.lower()
                seg_lower = lo[h_scroll : h_scroll + (win_width - 2)]
                col = 1
                i = 0
                while i < len(seg_lower):
                    hit = seg_lower.find(pat, i)
                    if hit == -1:
                        try:
                            win.addstr(row + 1, col + i, segment[i:], normal_attr)
                        except curses.error:
                            pass
                        break

                    if hit > i:
                        pre = segment[i:hit]
                        try:
                            win.addstr(row + 1, col + i, pre, normal_attr)
                        except curses.error:
                            pass

                    hit_end = hit + plen
                    highlight = segment[hit:hit_end]
                    try:
                        win.addstr(row + 1, col + hit, highlight, highlight_attr)
                    except curses.error:
                        pass

                    i = hit_end
            else:
                try:
                    win.addstr(row + 1, 1, segment, normal_attr)
                except curses.error:
                    pass

        border_y = win_height - 1
        if scroll_line == 0:
            marker = "[TOP]"
        elif eof and scroll_line >= max_scroll:
            marker = "[END]"
        else:
            marker = "[More]"

        search_tag = " (search)" if last_search else ""
        status = f"{marker} q to quit{search_tag}"
        msg = " " + status + " "
        msg = msg[: win_width - 2]

        try:
            win.addstr(border_y, 1, msg)
        except curses.error:
            pass

        win.refresh()

    draw()

    while True:
        key = win.getch()
        curses.flushinp()

        if key in (curses.KEY_ENTER, 10, 13, 27, ord("q")):
            break

        max_scroll = max(0, line_count - 1)

        if key in (curses.KEY_DOWN, ord("j")):
            if scroll_line < max_scroll or not eof:
                scroll_line += 1
                draw()

        elif key in (curses.KEY_UP, ord("k")):
            if scroll_line > 0:
                scroll_line -= 1
                draw()

        elif key in (curses.KEY_NPAGE, ord(" ")):
            scroll_line += max_visible
            ensure_lines_up_to(scroll_line + max_visible)
            draw()

        elif key in (curses.KEY_PPAGE, ord("b")):
            scroll_line = max(scroll_line - max_visible, 0)
            draw()

        elif key in (curses.KEY_RIGHT, ord("l")):
            h_scroll += 4
            draw()

        elif key == ord("0"):
            h_scroll = 0
            draw()

        elif key == ord("$"):
            h_scroll = compute_max_hscroll()
            draw()

        elif key in (curses.KEY_LEFT, ord("h")):
            h_scroll -= 4
            draw()

        elif key == ord("g"):
            scroll_line = 0
            draw()

        elif key == ord("G"):
            while not eof:
                read_next_line()
            scroll_line = max(0, line_count - 1)
            draw()

        elif key == ord("/"):
            pat = send_prompt(
                window=window,
                prompt_message="/",
                editor=editor,
            )
            if pat:
                last_search_results = perform_search(pat)
                last_search_index = 0
                if last_search_results:
                    jump_to_search_index(0)

            draw()

        elif key == ord("n"):
            if last_search_results:
                last_search_index += 1
                jump_to_search_index(last_search_index)
                draw()

        elif key == ord("N"):
            if last_search_results:
                last_search_index -= 1
                jump_to_search_index(last_search_index)
                draw()

        curses.napms(15)

    curses.flushinp()
    win.clear()
    win.refresh()

    if editor is not None:
        editor.draw()


def open_in_floating_window(editor, text: str) -> None:
    """
    Open text in a scrollable floating window positioned near the cursor.
    Use arrow keys to scroll; press any other key to close.
    """
    lines = text.splitlines()
    if not lines:
        return

    height, width = editor.stdscr.getmaxyx()
    cursor_y, cursor_x = editor.stdscr.getyx()

    win_height = min(height - 2, len(lines) + 2)
    win_width = min(width - 1, max(len(line) for line in lines) + 2)

    start_y = cursor_y + 1
    start_x = cursor_x

    if start_y + win_height > height:
        start_y = max(0, cursor_y - win_height)
    if start_x + win_width > width:
        start_x = max(0, width - win_width)

    win = curses.newwin(win_height, win_width, start_y, start_x)
    win.keypad(True)

    max_scroll = max(0, len(lines) - (win_height - 2))
    scroll = 0

    def draw():
        win.erase()
        win.box()
        for i in range(win_height - 2):
            line_index = scroll + i
            if line_index < len(lines):
                try:
                    win.addstr(i + 1, 1, lines[line_index][: win_width - 2])
                except curses.error:
                    pass
        win.refresh()

    draw()
    while True:
        key = win.getch()
        if key == curses.KEY_UP or key == ord("k"):
            if scroll > 0:
                scroll -= 1
                draw()
        elif key == curses.KEY_DOWN or key == ord("j"):
            if scroll < max_scroll:
                scroll += 1
                draw()
        else:
            break

    curses.flushinp()
    win.clear()
    win.refresh()


def open_streaming_window(editor, line_source: Iterator[str]):
    height, width = editor.stdscr.getmaxyx()
    cursor_y, cursor_x = editor.stdscr.getyx()

    win_height = 5
    win_width = 40

    buffer: list[str] = []
    scroll = 0

    start_y = cursor_y + 1
    start_x = cursor_x

    def clamp_position():
        nonlocal start_y, start_x, win_height, win_width

        if start_y + win_height > height:
            start_y = max(0, height - win_height)

        if start_x + win_width > width:
            start_x = max(0, width - win_width)

    clamp_position()

    win = curses.newwin(win_height, win_width, start_y, start_x)
    win.keypad(True)
    win.nodelay(True)

    def redraw_window():
        nonlocal win, win_height, win_width, scroll

        if buffer:
            longest = max(len(line.rstrip("\n")) for line in buffer)
            win_width = min(width - 1, longest + 2)
            win_height = min(height - 2, len(buffer) + 2)

        clamp_position()

        win.resize(win_height, win_width)
        win.mvwin(start_y, start_x)

        max_visible = win_height - 2
        visible_lines = buffer[scroll : scroll + max_visible]

        win.erase()
        win.box()

        for i, line in enumerate(visible_lines):
            try:
                win.addstr(i + 1, 1, line[: win_width - 2])
            except curses.error:
                pass

        win.refresh()

    redraw_window()

    while True:
        try:
            line = next(line_source)
            if isinstance(line, bytes):
                line = line.decode("utf-8", "replace")

            buffer.append(line)
            scroll = max(0, len(buffer) - (win_height - 2))

            redraw_window()

        except StopIteration:
            pass

        key = win.getch()

        max_scroll = max(0, len(buffer) - (win_height - 2))

        if key in (curses.KEY_UP, ord("k")) and scroll > 0:
            scroll -= 1
            redraw_window()
        elif key in (curses.KEY_DOWN, ord("j")) and scroll < max_scroll:
            scroll += 1
            redraw_window()
        elif key != -1:
            break

        curses.napms(30)

    win.clear()
    win.refresh()
    curses.flushinp()
