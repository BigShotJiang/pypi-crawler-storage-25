"""
This module was getted from the babi text editor:
https://github.com/asottile/babi/blob/main/babi/horizontal_scrolling.py
"""

from __future__ import annotations

import curses
from functools import cached_property


def line_x(x: int, width: int) -> int:
    if x + 1 < width:
        return 0
    elif width == 1:
        return x
    else:
        margin = min(width - 3, 6)
        return (
            width
            - margin
            - 2
            + (x + 1 - width) // (width - margin - 2) * (width - margin - 2)
        )


class _CalcWidth:
    @cached_property
    def _window(self) -> curses.window:
        return curses.newwin(1, 10)

    def wcwidth(self, c: str) -> int:
        self._window.addstr(0, 0, c)
        return self._window.getyx()[1]


wcwidth = _CalcWidth().wcwidth
del _CalcWidth
