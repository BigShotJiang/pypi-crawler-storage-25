from __future__ import annotations

import curses
import time
from typing import TYPE_CHECKING, Callable, Optional

from denary import key_mappings

if TYPE_CHECKING:
    from denary.editor import SimpleEditor


def send_prompt(
    window: curses.window,
    prompt_message: str,
    history: Optional[list[str]] = None,
    current_value: Optional[str] = None,
    on_change: Optional[Callable[[str], None]] = None,
    debounce_ms: int = 0,
    max_buffer_len: int = -1,
    increment_macro_start: bool = True,
    editor: Optional[SimpleEditor] = None,
) -> str:
    """
    Prompt on the status line with LEFT/RIGHT movement, mid-line insert/delete,
    history browsing, and safe handling of an initial `current_value`.
    If the input is wider than the available space, it scrolls horizontally.
    """

    if history is None:
        history = []

    height, width = window.getmaxyx()

    y = height - 1

    prompt_len = min(len(prompt_message), width - 1)

    window.keypad(True)

    window.move(y, 0)
    padded = prompt_message + " " * (width - len(prompt_message))
    window.addstr(y, 0, padded[: width - 1], curses.A_REVERSE)
    window.move(y, prompt_len)
    window.refresh()

    buf: list[str] = []
    history_index = len(history)
    cursor = 0
    left = 0

    area = max(1, width - prompt_len)

    def clamp_view():
        nonlocal left, cursor

        cursor = max(0, min(cursor, len(buf)))

        if cursor < left:
            left = cursor

        elif cursor >= left + area:
            left = cursor - area + 1

        left = max(0, min(left, max(0, len(buf) - 1)))

        if len(buf) == 0:
            left = 0

    def redraw_input():
        window.move(y, prompt_len)
        window.clrtoeol()

        clamp_view()

        vis = "".join(buf[left : left + area])
        if len(vis) < area:
            vis = vis + " " * (area - len(vis))

        try:
            window.addstr(y, 0, prompt_message + vis[:area], curses.A_REVERSE)
        except curses.error:
            pass

        window.move(y, prompt_len + (cursor - left))

    if current_value is not None:
        buf = list(current_value)
        cursor = len(buf)
        left = max(0, cursor - area + 1)
        redraw_input()

    last_state = "".join(buf)
    current_state = "".join(buf)

    last_change_time: float = 0
    callback_fired = False

    if (
        editor is not None
        and editor.current_macro_playing_index is not None
        and editor.current_macro_playing_name is not None
        and increment_macro_start
    ):
        editor.current_macro_playing_index += 1

    window.nodelay(True)

    while True:
        if max_buffer_len != -1 and len(buf) >= max_buffer_len:
            break

        current_state = "".join(buf)

        if current_state != last_state:
            last_state = current_state
            last_change_time = time.time()
            callback_fired = False

        if not callback_fired and on_change is not None:
            elapsed_ms = (time.time() - last_change_time) * 1000
            if elapsed_ms >= debounce_ms:
                on_change(current_state)
                callback_fired = True
                redraw_input()
                window.refresh()

        ch: int | str | None
        if (
            editor is not None
            and editor.current_macro_playing_index is not None
            and editor.current_macro_playing_name is not None
        ):
            ch = editor.macros.get(editor.current_macro_playing_name, [])[
                editor.current_macro_playing_index
            ]
            editor.current_macro_playing_index += 1
        else:
            try:
                key = window.get_wch()
            except curses.error:
                key = None

            ch = key_mappings.get_key_mapping(window, key)
            window.nodelay(True)

            if (
                editor is not None
                and editor.recording_macro
                and editor.current_macro_recording is not None
                and ch is not None
            ):
                editor.macros[editor.current_macro_recording].append(ch)

        if ch in ("Ctrl+C", "ESC", 27):
            buf = []
            break

        if ch == "Ctrl+P":
            if editor is not None and editor.clipboard is not None:
                clipboard_text = "\\n".join(editor.clipboard)

                for ch in clipboard_text:
                    buf.insert(cursor, ch)
                    cursor += 1

                redraw_input()

            continue

        if ch == "Ctrl+Left":
            if cursor > 0:
                i = cursor - 1
                while i > 0 and buf[i].isspace():
                    i -= 1
                while i > 0 and not buf[i - 1].isspace():
                    i -= 1
                cursor = i
            redraw_input()
            continue

        if ch == "Ctrl+Right":
            if cursor < len(buf):
                i = cursor
                n = len(buf)
                while i < n and not buf[i].isspace():
                    i += 1
                while i < n and buf[i].isspace():
                    i += 1
                cursor = i
            redraw_input()
            continue

        if ch in (10, 13, "Ctrl+J", "Enter", "Ctrl+M"):
            break

        if ch == "Left":
            if cursor > 0:
                cursor -= 1
                redraw_input()
            continue

        if ch == "Right":
            if cursor < len(buf):
                cursor += 1
                redraw_input()
            continue

        if ch in ("Backspace", 127, 8, "Ctrl+H"):
            if cursor > 0:
                del buf[cursor - 1]
                cursor -= 1
                redraw_input()
            continue

        if ch == "Delete":
            if cursor < len(buf):
                del buf[cursor]
                redraw_input()
            continue

        if ch == "Up" or (ch == key_mappings.SHIFT_TAB_KEY and history):
            if history_index > 0:
                history_index -= 1
                buf = list(history[history_index])
                cursor = len(buf)
                left = max(0, cursor - area + 1)
                redraw_input()
            continue

        if ch == "Down" or (key_mappings.TAB_KEY_FUNC(ch) and history):
            if history_index < len(history) - 1:
                history_index += 1
                buf = list(history[history_index])
            else:
                history_index = len(history)
                buf = []
            cursor = len(buf)
            left = max(0, cursor - area + 1)
            redraw_input()
            continue

        if isinstance(ch, str) and len(ch) == 1:
            buf.insert(cursor, ch)
            cursor += 1
            redraw_input()
            continue

    window.move(y, 0)
    window.clrtoeol()
    window.refresh()
    curses.flushinp()

    return "".join(buf)


def send_prompt_confirm(
    window: curses.window,
    prompt_message: str,
    color_p: int = -1,
    editor: Optional[SimpleEditor] = None,
) -> bool:

    height, width = window.getmaxyx()

    # height -= 1

    if (
        editor is not None
        and editor.current_macro_playing_index is not None
        and editor.current_macro_playing_name is not None
    ):
        editor.current_macro_playing_index += 1

    while True:
        prompt_message = prompt_message + " (y/n): " + (" " * width)
        if color_p != -1:
            color = curses.color_pair(color_p)
            window.addstr(height - 1, 0, prompt_message[: width - 1], color)
        else:
            window.addstr(height - 1, 0, prompt_message[: width - 1])

        if (
            editor is not None
            and editor.current_macro_playing_index is not None
            and editor.current_macro_playing_name is not None
        ):
            key = editor.macros.get(editor.current_macro_playing_name, [])[
                editor.current_macro_playing_index
            ]
            editor.current_macro_playing_index += 1
        else:
            try:
                key = window.get_wch()
            except curses.error:
                key = None

            if (
                editor is not None
                and editor.recording_macro
                and editor.current_macro_recording is not None
                and key is not None
            ):
                editor.macros[editor.current_macro_recording].append(key)

        if key in ("y", "Y"):
            return True

        elif key in ("n", "N"):
            return False


def send_multiline_prompt(
    window: curses.window,
    multiline_message: str,
    prompt_message: str,
    editor: Optional[SimpleEditor] = None,
) -> str:
    height, width = window.getmaxyx()

    height -= 1

    lines = multiline_message.split("\n")

    for i, line in enumerate(list(reversed(lines))[: height - 1]):
        line += " " * width
        window.addstr(height - (1 + i), 0, line[: width - 1], curses.A_REVERSE)
        window.clrtoeol()

    window.refresh()

    return send_prompt(
        window=window,
        prompt_message=prompt_message,
        editor=editor,
    )


def send_prompt_confirm_multiline(
    window: curses.window,
    multiline_message: str,
    prompt_message: str,
    editor: Optional[SimpleEditor] = None,
) -> bool:
    height, width = window.getmaxyx()

    height -= 1

    lines = multiline_message.split("\n")

    for i, line in enumerate(list(reversed(lines))[: height - 1]):
        line += " " * width
        window.addstr(height - (1 + i), 0, line[: width - 1], curses.A_REVERSE)
        window.clrtoeol()

    window.refresh()

    return send_prompt_confirm(
        window=window,
        prompt_message=prompt_message,
        editor=editor,
    )
