import curses


# ---- Color Conversion Helpers -----------------------------------
def xterm_to_rgb(index: int) -> tuple[int, int, int]:
    # First 16 system colors
    system_palette = [
        (0, 0, 0),
        (205, 0, 0),
        (0, 205, 0),
        (205, 205, 0),
        (0, 0, 238),
        (205, 0, 205),
        (0, 205, 205),
        (229, 229, 229),
        (127, 127, 127),
        (255, 0, 0),
        (0, 255, 0),
        (255, 255, 0),
        (92, 92, 255),
        (255, 0, 255),
        (0, 255, 255),
        (255, 255, 255),
    ]

    if index < 16:
        return system_palette[index]

    # Color cube 16–231
    if 16 <= index <= 231:
        idx = index - 16
        r = (idx // 36) % 6
        g = (idx // 6) % 6
        b = idx % 6
        return (r * 51, g * 51, b * 51)

    # Grayscale 232–255
    if 232 <= index <= 255:
        v = (index - 232) * 10 + 8
        return (v, v, v)

    return (0, 0, 0)


def rgb_to_hex(r: int, g: int, b: int) -> str:
    return f"#{r:02X}{g:02X}{b:02X}"


# ---- Main UI -----------------------------------------------------
def display_colors(stdscr: curses.window) -> None:
    curses.start_color()
    curses.use_default_colors()
    curses.curs_set(0)

    max_colors = min(curses.COLORS, 256)

    rows = []
    for i in range(max_colors):
        r, g, b = xterm_to_rgb(i)
        hex_code = rgb_to_hex(r, g, b)
        rows.append((i, r, g, b, hex_code))

    # init curses color pairs
    for i in range(max_colors):
        try:
            curses.init_pair(i + 1, i, -1)
        except curses.error:
            pass

    scroll = 0
    cursor = 0
    query = ""
    filtered = rows.copy()

    while True:
        stdscr.erase()
        h, w = stdscr.getmaxyx()
        visible = h - 3

        scroll = max(0, min(scroll, len(filtered) - visible))
        cursor = max(0, min(cursor, len(filtered) - 1))

        # Adjust scroll to keep cursor in view
        if cursor < scroll:
            scroll = cursor
        elif cursor >= scroll + visible:
            scroll = cursor - visible + 1

        # Render rows
        for idx in range(scroll, scroll + visible):
            if idx >= len(filtered):
                break

            i, r, g, b, hx = filtered[idx]
            line = f"{i:3d} | RGB({r:3},{g:3},{b:3}) | {hx}"

            mode = curses.color_pair(i + 1)
            if idx == cursor:
                mode |= curses.A_REVERSE | curses.A_BOLD

            try:
                stdscr.addstr(idx - scroll, 0, line[: w - 1], mode)
            except curses.error:
                pass

        # Footer and search
        stdscr.addstr(
            h - 2,
            0,
            f"[↑↓ PgUp/PgDn j/k g/G q] {cursor+1}/{len(filtered)}  Search: /",
            curses.A_REVERSE,
        )

        stdscr.addstr(h - 1, 0, f"Filter: {query}"[: w - 1], curses.A_BOLD)

        stdscr.refresh()
        key = stdscr.getch()

        # --- Quit ---
        if key in (ord("q"), 27):
            break

        # --- Navigation ---
        elif key in (curses.KEY_DOWN, ord("j")):
            cursor += 1
        elif key in (curses.KEY_UP, ord("k")):
            cursor -= 1
        elif key == curses.KEY_NPAGE:
            cursor += visible
        elif key == curses.KEY_PPAGE:
            cursor -= visible
        elif key in (curses.KEY_HOME, ord("g")):
            cursor = 0
        elif key in (curses.KEY_END, ord("G")):
            cursor = len(filtered) - 1

        # --- Search ---
        elif key == ord("/"):
            query = ""
            filtered = rows.copy()
            cursor = scroll = 0

        elif key in (curses.KEY_BACKSPACE, 127, 8):
            query = query[:-1]
            filtered = [
                r
                for r in rows
                if query.lower() in r[4].lower() or query.lower() in str(r[0])
            ]
            cursor = scroll = 0

        elif 33 <= key <= 126:
            query += chr(key)
            filtered = [
                r for r in rows if query.lower() in r[4].lower() or query in str(r[0])
            ]
            cursor = scroll = 0

        # --- Preview Truecolor ---
        elif key == ord("c") and filtered:
            i, r, g, b, hx = filtered[cursor]
            print(f"\nANSI Truecolor Sequence for {hx}:\n")
            print(f"\033[38;2;{r};{g};{b}m{hx} Sample Text\033[0m\n")
            input("Press Enter to return...")
            curses.flash()


def main() -> None:
    curses.wrapper(display_colors)


if __name__ == "__main__":
    main()
