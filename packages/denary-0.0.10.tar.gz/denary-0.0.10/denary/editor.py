#     ,gggggggggggg,
#    dP"""88""""""Y8b,
#    Yb,  88       `8b,
#     `"  88        `8b
#         88         Y8
#         88         d8  ,ggg,    ,ggg,,ggg,     ,gggg,gg   ,gggggg,  gg     gg
#         88        ,8P i8" "8i  ,8" "8P" "8,   dP"  "Y8I   dP""""8I  I8     8I
#         88       ,8P' I8, ,8I  I8   8I   8I  i8'    ,8I  ,8'    8I  I8,   ,8I
#         88______,dP'  `YbadP' ,dP   8I   Yb,,d8,   ,d8b,,dP     Y8,,d8b, ,d8I
#        888888888P"   888P"Y8888P'   8I   `Y8P"Y8888P"`Y88P      `Y8P""Y88P"888
#                                                                          ,d8I'
#                                                                        ,dP'8I
#                                                                       ,8"  8I
#                                                                       I8   8I
#                                                                       `8, ,8I
#                                                                        `Y8P"

"""
A modal terminal editor built on curses with a command-driven,
event-based architecture and chunked text storage.

Includes syntax highlighting, multi-buffer management,
registers and markers, undo/redo history, Git integration,
async LSP support, subprocess execution, and HTTP requests.
"""

from __future__ import annotations

import argparse
import asyncio
import curses
import itertools
import json
import os
import re
import shutil
import signal
import string
import subprocess
import sys
import tempfile
import textwrap
import time
import traceback
import uuid
from bisect import bisect_left, bisect_right
from collections import defaultdict, deque
from datetime import datetime
from functools import lru_cache
from io import StringIO
from pathlib import Path
from queue import Queue
from typing import (
    Any,
    Callable,
    Iterable,
    NamedTuple,
    Optional,
    Sequence,
    TypedDict,
    cast,
)
from urllib.parse import urlparse

from pathspec import PathSpec
from pygments.lexers import (
    DiffLexer,
    MarkdownLexer,
    TextLexer,
    get_lexer_by_name,
    guess_lexer,
)

from denary import (
    buf_actions,
    config,
    events,
    file_explorer,
    git_utils,
    http_client,
    key_mappings,
    notifications,
    prompts,
    themes,
)
from denary.ai import completions
from denary.buf import (
    Buffer,
    BufferAction,
    BufferActionTypeEnum,
    BufferSession,
    CursorPosition,
    RichString,
    get_lsp,
    get_uri_from_name,
    load_lsp,
)
from denary.chunked_lines import ChunkedLines
from denary.config import CURRENT_PLATFORM, MAX_SCAN_LINES, save_static_config
from denary.displays import show_picker_display
from denary.events import Event, EventType, LSPEventType
from denary.file_viewer import open_file_in_less_mode
from denary.fzf_search import fzf_fuzzy_find
from denary.horizontal_scrolling import line_x, wcwidth
from denary.key_mappings import (
    BRACKET_PAIRS,
    BRACKETS,
    FUNC_KEYS,
    REVERSE_BRACKET_PAIRS,
)
from denary.replacements import expand_replacement
from denary.syntax import hilighing
from denary.syntax.hilighing import (
    Diagnostic,
    get_suffix_from_lexer,
)


class Session(TypedDict):
    """
    Represents a session with a list of buffers and the index of the current buffer.
    """

    buffers: list[BufferSession]
    current_buffer_name: str | None
    # Store global markers by name
    global_markers: dict[str, tuple[int, int, str]]
    fuzzy_search: list[str]  # Store fuzzy search results
    working_dir_mtime: float
    command_history: list[str]
    search_history: list[str]
    eval_history: list[str]


class Jump(NamedTuple):
    buffer_name: str
    position: CursorPosition
    timestamp: float


async def make_request_with_cancel_async(
    method: http_client.HttpVerbs,
    url: str,
    headers: dict[str, str],
    body: str,
    task_id: str,
) -> None:
    cancelled = False

    await events.EVENT_QUEUE.put(
        Event(
            EventType.HTTP_REQUEST_STARTED,
            {
                "task_id": task_id,
            },
        )
    )

    try:
        response = await http_client.ahttp_client(
            url=url,
            verb=method,
            headers=headers,
            body=body,
        )

    except asyncio.CancelledError:
        cancelled = True

    if cancelled:
        await events.EVENT_QUEUE.put(
            Event(
                EventType.HTTP_REQUEST_CANCELLED,
                {
                    "task_id": task_id,
                },
            )
        )
    else:
        await events.EVENT_QUEUE.put(
            Event(
                EventType.HTTP_REQUEST_COMPLETED,
                {
                    "response": response,
                    "task_id": task_id,
                },
            )
        )


async def run_with_cancel_async(command: str, task_id: str, cep: bool = False) -> None:
    cancelled = False

    temp = tempfile.SpooledTemporaryFile()

    proc = await asyncio.create_subprocess_shell(
        command,
        stdout=temp,
        stderr=temp,
        start_new_session=True,  # important for killing process group
    )

    await events.EVENT_QUEUE.put(
        Event(EventType.SUBPROCESS_STARTED, {"command": command, "task_id": task_id})
    )

    try:
        await proc.wait()

    except asyncio.CancelledError:
        cancelled = True
        # kill entire process group
        os.killpg(proc.pid, signal.SIGTERM)

        try:
            await asyncio.wait_for(proc.wait(), timeout=1.5)
        except asyncio.TimeoutError:
            os.killpg(proc.pid, signal.SIGKILL)
            await proc.wait()

    size = temp.seek(0, os.SEEK_END)
    temp.seek(0)

    await events.EVENT_QUEUE.put(
        Event(
            (
                EventType.SUBPROCESS_CANCELLED
                if cancelled
                else EventType.SUBPROCESS_COMPLETED
            ),
            {
                "file": temp,
                "size": size,
                "return_code": proc.returncode,
                "command": command,
                "cep": cep,
                "task_id": task_id,
            },
        )
    )


def _run_code(code: str, queue: Queue) -> None:
    import contextlib
    import io

    buf = io.StringIO()

    with contextlib.redirect_stdout(buf):
        try:
            result = eval(code)
        except SyntaxError:
            exec(code)
            result = None

    queue.put((result, buf.getvalue()))


def get_offsets(line: RichString, tab_size: int) -> tuple[int, ...]:
    if line._width_cache is not None:
        return line._width_cache

    offsets = [0]
    x = 0

    for c in line:
        if c == "\t":
            spaces = tab_size - (x % tab_size)
            x += spaces
        else:
            w = wcwidth(c)
            if w < 0:
                w = 0
            x += w

        offsets.append(x)

    line._width_cache = tuple(offsets)
    return line._width_cache


def render_slice(
    line: RichString, start: int, end: int, offsets: tuple[int, ...], tab_size: int
) -> str:
    if "\t" not in line:
        return line[start:end]
    return expand_tabs_for_render(line, start, end, offsets, tab_size)


def expand_tabs_for_render(
    line: RichString, start: int, end: int, offsets: tuple[int, ...], tab_size: int
) -> str:
    result = []

    if start >= len(offsets):
        return ""

    x = offsets[start]

    end = min(end, len(line))

    for i in range(start, end):
        c = line[i]

        if c == "\t":
            spaces = tab_size - (x % tab_size)
            result.append(" " * spaces)
            x += spaces
        else:
            result.append(c)
            w = wcwidth(c)
            if w > 0:
                x += w

    return "".join(result)


def get_brackets(line: RichString) -> list[tuple[int, str]]:
    if line._bracket_cache is None:
        line._bracket_cache = [(i, c) for i, c in enumerate(line) if c in BRACKETS]
    return line._bracket_cache


def find_matching_bracket(
    lines, y, x
) -> Optional[tuple[tuple[int, int], tuple[int, int]]]:
    if y < 0 or y >= len(lines):
        return None

    line = lines[y]
    if not line:
        return None

    if x <= 0 or x > len(line):
        return None

    c = line[x - 1]
    cx = x - 1

    if c not in BRACKETS:
        return None

    bracket_pairs = BRACKET_PAIRS
    reverse_pairs = REVERSE_BRACKET_PAIRS
    getb = get_brackets
    lines_len = len(lines)

    if c in bracket_pairs:
        target = bracket_pairs[c]
        depth = 1

        max_y = min(lines_len, y + MAX_SCAN_LINES)

        yy = y
        xx = cx + 1

        while yy < max_y:
            line = lines[yy]
            brackets = getb(line)

            if brackets:
                for pos, ch in brackets:
                    if yy == y and pos < xx:
                        continue

                    if ch == c:
                        depth += 1
                    elif ch == target:
                        depth -= 1
                        if depth == 0:
                            return (y, cx), (yy, pos)

            yy += 1
            xx = 0

    else:
        target = reverse_pairs[c]
        depth = 1

        min_y = max(0, y - MAX_SCAN_LINES)

        yy = y
        xx = cx - 1

        while yy >= min_y:
            line = lines[yy]
            brackets = getb(line)

            if brackets:
                i = len(brackets) - 1

                if yy == y:
                    while i >= 0 and brackets[i][0] > xx:
                        i -= 1

                while i >= 0:
                    pos, ch = brackets[i]

                    if ch == c:
                        depth += 1
                    elif ch == target:
                        depth -= 1
                        if depth == 0:
                            return (yy, pos), (y, cx)

                    i -= 1

            yy -= 1
            if yy >= 0:
                xx = len(lines[yy]) - 1

    return None


def split_requests(text: str) -> list[str]:
    """
    Split a .http file into multiple request blocks using '###' separator.
    """
    blocks = []
    current: list[str] = []

    for line in text.splitlines():
        if line.strip().startswith("###"):
            if current:
                block = "\n".join(current).strip()
                if block:
                    blocks.append(block)
                current = []
            continue
        current.append(line)

    if current:
        block = "\n".join(current).strip()
        if block:
            blocks.append(block)

    return blocks


def parse_request_block(
    block: str,
) -> tuple[http_client.HttpVerbs, str, dict[str, str], str]:
    lines = block.splitlines()

    while lines and (not lines[0].strip() or lines[0].strip().startswith(("#", "//"))):
        lines.pop(0)

    if not lines:
        raise ValueError("No request line found")

    first_line = lines.pop(0).split("#", 1)[0].strip()
    method_str, url = first_line.split(maxsplit=1)
    method = http_client.HttpVerbs[method_str.upper()]

    headers = {}
    while lines:
        line = lines.pop(0)
        stripped = line.strip()

        if stripped == "":
            break

        if stripped.startswith(("#", "//")):
            continue

        if ":" not in line:
            raise ValueError(f"Invalid header format: {line}")

        k, v = line.split(":", 1)
        headers[k.strip()] = v.strip()

    body = "\n".join(lines).strip()

    return method, url, headers, body


def _safe_get_wch(window: curses.window) -> str | int | None:
    try:
        return window.get_wch()
    except curses.error:
        return None


def render_line_numbers(
    stdscr: curses.window,
    screen_row: int,
    line_no: int,
    buffer: Buffer,
    num_lines: Optional[int] = None,
) -> int:
    if num_lines is None:
        num_lines = len(str(len(buffer.lines)))

    cp = curses.color_pair
    ln = line_no + 1

    number_str = f"{ln:{num_lines}} "
    number_color = cp(2)

    stdscr.addstr(screen_row, 1, number_str, number_color)

    return 1 + len(number_str)


def render_git_gutter(
    stdscr: curses.window,
    screen_row: int,
    line_no: int,
    buffer: Buffer,
    num_lines: Optional[int] = None,
) -> int:
    cp = curses.color_pair
    ln = line_no + 1

    change_type = buffer.buffer_changes.get(ln)
    if change_type is None:
        change_type = buffer.git_changes.get(ln)

    if change_type == "added":
        mark = "+"
        mark_color = cp(40)
    elif change_type == "deleted":
        mark = "-"
        mark_color = cp(41)
    elif change_type == "modified":
        mark = "~"
        mark_color = cp(42)
    else:
        mark = " "
        mark_color = cp(0)

    stdscr.addstr(screen_row, 0, mark, mark_color)

    return 1


def render_line_numbers_and_git(
    stdscr: curses.window,
    screen_row: int,
    line_no: int,
    buffer: Buffer,
    num_lines: Optional[int] = None,
) -> int:
    if num_lines is None:
        num_lines = len(str(len(buffer.lines)))

    cp = curses.color_pair
    ln = line_no + 1

    change_type = buffer.buffer_changes.get(ln)
    if change_type is None:
        change_type = buffer.git_changes.get(ln)

    if change_type == "added":
        mark = "+"
        mark_color = cp(40)
    elif change_type == "deleted":
        mark = "-"
        mark_color = cp(41)
    elif change_type == "modified":
        mark = "~"
        mark_color = cp(42)
    else:
        mark = " "
        mark_color = cp(0)

    number_str = f"{ln:{num_lines}} "
    number_color = cp(2)

    stdscr.addstr(screen_row, 0, mark, mark_color)
    stdscr.addstr(screen_row, 1, number_str, number_color)

    return 1 + len(number_str)


def load_gitignore_patterns(root: str) -> Optional[PathSpec]:
    gitignore_path = os.path.join(root, ".gitignore")
    if os.path.exists(gitignore_path):
        with open(gitignore_path, "r", encoding="utf-8") as f:
            patterns = f.read().splitlines()
        return PathSpec.from_lines("gitwildmatch", patterns)
    return None


def collect_files_with_gitignore(
    root: str, cached_files=None, changed=True
) -> list[str]:
    spec = load_gitignore_patterns(root)

    if not cached_files or changed:
        all_files = []
        for dirpath, _, filenames in os.walk(root):
            for fn in filenames:
                rel = os.path.relpath(os.path.join(dirpath, fn), root)

                if rel.startswith(".") or "/." in rel:
                    continue

                if spec and spec.match_file(rel):
                    continue

                all_files.append(rel)

        all_files.sort()
        return all_files
    else:
        return cached_files


class SimpleEditor:
    """
    Core editor class handling buffer storage, rendering, and input.
    """

    tg: Optional[asyncio.TaskGroup] = None

    def __init__(
        self,
        stdscr: curses.window,
        file_names: list[str],
        theme: str,
        debug: bool = False,
        temp_dir: str | None = None,
        without_session: bool = False,
        as_text: bool = False,
    ) -> None:
        self.stdscr = stdscr
        self.debug = debug
        self.without_session = without_session
        self.as_text = as_text
        self.temp_dir = temp_dir
        self.disable_record_jump = False
        self.input_timeout = False

        self.gutter_render: Optional[
            Callable[[curses.window, int, int, Buffer, Optional[int]], int]
        ] = None

        self.buffers: list[Buffer] = []
        self.current_buffer = 0
        self.new_buffer_count = 0
        self.global_markers = {}

        self.fuzzy_search = []
        self.command_history = []
        self.search_history = []
        self.eval_history = []

        self.task_running: list[dict[str, Any]] = []

        self.working_dir = Path(".")
        self.working_dir_mtime = self.get_working_dir_mtime()
        self.color_support = curses.COLORS >= 256

        self.macros: dict[str, list[int | str]] = {}
        self.recording_macro: bool = False
        self.current_macro_recording: Optional[str] = None
        self.current_macro_playing_name: Optional[str] = None
        self.current_macro_playing_index: Optional[int] = None

        self.ai_completion_manager = completions.CompletionManager()

        self.jump_list: list[Jump] = []
        self.last_jump: Optional[Jump] = None
        self.jump_index: int = 0

        session_path = Path("editor_session.json")
        session_exists = session_path.exists()

        if session_exists and not self.without_session:
            try:
                with open(session_path, "r") as f:
                    session_data = json.load(f)

                self.global_markers = session_data.get("global_markers", {})

                session_mtime = session_data.get("working_dir_mtime", -1)

                if session_mtime >= self.working_dir_mtime:
                    self.fuzzy_search = session_data.get("fuzzy_search", [])

                self.search_history = session_data.get("search_history", [])

                self.command_history = session_data.get("command_history", [])

                self.eval_history = session_data.get("eval_history", [])

            except Exception:
                session_data = None
                pass

        base_lexer = None

        if self.as_text:
            base_lexer = TextLexer()

        if session_exists and not self.without_session and session_data is not None:
            try:
                error_log = []

                for buf in session_data["buffers"]:
                    try:

                        if not Path(buf["file_name"]).exists():
                            continue

                        new_buffer = Buffer(buf["file_name"], temp_dir=self.temp_dir)

                        new_buffer.cursor_y = buf["cursor_y"]
                        new_buffer.cursor_x = buf["cursor_x"]
                        new_buffer.scroll = buf["scroll"]
                        new_buffer.h_scroll = buf["h_scroll"]

                        new_buffer.markers = buf.get("markers", {})

                        new_buffer.lexer = base_lexer

                        self.buffers.append(new_buffer)

                    except FileNotFoundError:
                        error_log.append(f"Error loading buffer '{buf['file_name']}'")

                current_buffer_index = 0

                for i, buf in enumerate(self.buffers):
                    if buf.file_name == session_data["current_buffer_name"]:
                        current_buffer_index = i
                        break

                self.current_buffer = current_buffer_index

                if error_log:
                    self.send_multiline_notification("\n".join(error_log), 5000)

            except json.JSONDecodeError:
                self.send_notification("Error loading session data. Starting fresh.")

                self.buffers.clear()
                self.buffers.append(Buffer(temp_dir=self.temp_dir))

        if file_names:
            stdin_read = False

            for file in file_names:
                res = file.split(":")

                if len(res) == 4:
                    file_name, _line, _col, message = res
                    file = file_name.strip()
                    line = int(_line.strip())
                    col = int(_col.strip())

                elif len(res) == 3:
                    file_name, _line, _col = res
                    file = file_name.strip()
                    line = int(_line.strip())
                    col = int(_col.strip())
                    message = ""
                elif len(res) == 2:
                    file_name, _line = res
                    file = file_name.strip()
                    line = int(_line.strip())
                    col = 1
                    message = ""
                else:
                    file = res[0].strip()
                    line = 1
                    col = 1
                    message = ""

                is_stdin = file == "-"

                if is_stdin and stdin_read:
                    continue

                if (
                    not is_stdin
                    and (buffer_index := self.get_buffer_by_file_name(file_name=file))
                    != -1
                ):
                    new_buffer = self.buffers[buffer_index]
                    self.current_buffer = buffer_index
                else:
                    if is_stdin:
                        self.new_buffer_count += 1
                        file = f"Untitled-{self.new_buffer_count}"

                    new_buffer = Buffer(
                        file,
                        temp_dir=self.temp_dir,
                        new_buffer_untitled=is_stdin,
                        lexer=base_lexer,
                    )

                    self.buffers.append(new_buffer)
                    self.current_buffer = len(self.buffers) - 1

                if len(res) >= 2:
                    new_buffer.cursor_y = line - 1
                    new_buffer.cursor_x = col - 1
                    new_buffer.last_cursor_x = new_buffer.cursor_x

                if message:
                    new_buffer.diagnostics.append(
                        hilighing.Diagnostic(
                            line=new_buffer.cursor_y,
                            char=new_buffer.cursor_x,
                            code="E",
                            message=message,
                            severity=1,
                        )
                    )

                if is_stdin:
                    new_buffer.load()
                    new_buffer.first = False

                    stdin = sys.stdin.buffer.read().decode()
                    os.dup2(
                        os.open(
                            (
                                "CONIN$"
                                if CURRENT_PLATFORM.startswith("win")
                                else "/dev/tty"
                            ),
                            os.O_RDONLY,
                        ),
                        sys.stdin.fileno(),
                    )
                    stdin_read = True

                    stdin = stdin.replace("\r\n", "\n").replace("\r", "\n")
                    stdin = stdin.replace("\x00", "�")

                    new_buffer.lines = ChunkedLines(
                        [RichString(line) for line in stdin.splitlines()]
                    )

        if len(self.buffers) == 0:
            self.open_untitled_buffer(
                text='''\
 ,gggggggggggg,
dP"""88""""""Y8b,
Yb,  88       `8b,
 `"  88        `8b
     88         Y8
     88         d8  ,ggg,    ,ggg,,ggg,     ,gggg,gg   ,gggggg,  gg     gg
     88        ,8P i8" "8i  ,8" "8P" "8,   dP"  "Y8I   dP""""8I  I8     8I
     88       ,8P' I8, ,8I  I8   8I   8I  i8'    ,8I  ,8'    8I  I8,   ,8I
     88______,dP'  `YbadP' ,dP   8I   Yb,,d8,   ,d8b,,dP     Y8,,d8b, ,d8I
    888888888P"   888P"Y8888P'   8I   `Y8P"Y8888P"`Y88P      `Y8P""Y88P"888
                                                                      ,d8I'
                                                                    ,dP'8I
                                                                   ,8"  8I
                                                                   I8   8I
                                                                   `8, ,8I
                                                                    `Y8P"
''' + ("\n" * (50 - 16)),
                lexer=TextLexer(),
            )
            # self.buffers.append(Buffer(temp_dir=self.temp_dir))

        self.last_buffer = self.current_buffer
        self.clipboard: list[str] = []

        self.registers: dict[str, list[str]] = {}
        self.copy_history: deque[list[str]] = deque(maxlen=10)

        self.last_search: str | None = None
        self.last_search_re: re.Pattern | None = None

        self.mouse_button_down = False
        self.mouse_x = -1
        self.mouse_y = -1
        self.last_mouse_click = 0.0

        self.disable_search = True

        self.selection_start: tuple[int, int] | None = (
            None  # (row, col) of selection origin
        )

        self.fuzzy_changed = False  # to know if you need to refresh the fuzzy

        # self.current_branch = git_utils.get_current_branch()
        self.current_branch = "--"

        self.mode = "NORMAL"

        config.load_static_config()

        self.keymap_normal = {
            "Right": self._key_right,
            "Left": self._key_left,
            "Up": self._key_up,
            "Down": self._key_down,
            "l": self._key_l,
            "h": self._key_h,
            "k": self._key_k,
            "j": self._key_j,
            "i": self._key_i,
            "a": self._key_a,
            "A": self._key_A,
            "o": self._key_o,
            "O": self._key_O,
            "s": self._key_s,
            "c": self._key_c,
            "x": self._key_x,
            "d": self._key_d,
            ":": self._key_colon,
            "v": self._key_v,
            "V": self._key_V,
            "y": self._key_y,
            "u": self._key_u,
            "U": self._key_U,
            ">": self._key_gt,
            "<": self._key_lt,
            "Alt+/": self._key_alt_slash,
            "K": self._key_K,
            ";": self._key_semicolon,
            "T": self._key_T,
            "0": self._key_0,
            "$": self._key_dollar,
            "Ctrl+A": self._key_ctrl_a,
            "n": self._key_n,
            "N": self._key_N,
            "*": self._key_star,
            "p": self._key_p,
            "P": self._key_P,
            "Ctrl+P": self._key_ctrl_p,
            "Alt+r": self._key_alt_r,
            "Alt+w": self._key_alt_w,
            "Alt+i": self._key_alt_i,
            "Alt+o": self._key_alt_o,
            "m": self._key_m,
            "M": self._key_M,
            "'": self._key_tick,
            "`": self._key_backtick,
            "PageUp": self._key_pageup,
            "PageDown": self._key_pagedown,
            "g": self._key_g,
            "G": self._key_G,
            "H": self._key_H,
            "L": self._key_L,
            "Ctrl+Up": self._key_ctrl_up,
            "Ctrl+Down": self._key_ctrl_down,
            "J": self._key_J,
            "Ctrl+X": self._key_ctrl_x,
            "Q": self._key_Q,
            "q": self._key_q,
            "@": self._key_at,
            "Alt+k": self._key_alt_k,
            "Alt+j": self._key_alt_j,
            "e": self._key_e,
            "w": self._key_w,
            "W": self._key_W,
            "E": self._key_E,
            "b": self._key_b,
            "B": self._key_B,
            "f": self._key_f,
            "F": self._key_F,
            "[": self._key_open_bracket,
            "]": self._key_close_bracket,
            "Ctrl+Right": self._key_ctrl_right,
            "Ctrl+Left": self._key_ctrl_left,
            "Ctrl+I": self._key_ctrl_i,
            353: self._key_353,
            "Ctrl+D": self._key_ctrl_d,
            "Ctrl+O": self._key_ctrl_o,
            "/": self._key_slash,
            "%": self._key_percent,
        }

        self.keymap: dict[int | str, Callable[[], None]] = {
            "Right": self._key_right,
            "Left": self._key_left,
            "Up": self._key_up,
            "Down": self._key_down,
            "Alt+;": self._key_alt_semicolon,
            "Alt+Right": self._key_alt_indent_right,
            "Alt+Left": self._key_alt_indent_left,
            "Alt+.": self._key_alt_indent_right,
            "Alt+,": self._key_alt_indent_left,
            "Alt+/": self._key_alt_slash,
            "Alt+h": self._key_alt_h,
            "Alt+j": self._key_alt_j_move,
            "Alt+k": self._key_alt_k_move,
            "Alt+l": self._key_alt_l,
            "Alt+9": self._key_alt_9,
            "Alt+0": self._key_alt_0,
            "Ctrl+O": self._key_ctrl_o,
            "Ctrl+A": self._key_ctrl_a,
            "Alt+w": self._key_alt_w,
            "Alt+[": self._key_alt_open_bracket,
            "Alt+'": self._key_alt_quote,
            "PageUp": self._key_pageup,
            "PageDown": self._key_pagedown,
            "Alt+Up": self._key_alt_up_scroll,
            "Alt+Down": self._key_alt_down_scroll,
            "Ctrl+Right": self._key_ctrl_right,
            "Ctrl+Left": self._key_ctrl_left,
            "Ctrl+Up": self._key_ctrl_up_empty,
            "Ctrl+Down": self._key_ctrl_down_empty,
            "Ctrl+Alt+Right": self._key_ctrl_alt_right,
            "Ctrl+Alt+Left": self._key_ctrl_alt_left,
            "Shift+Right": self._key_shift_right,
            "Shift+Left": self._key_shift_left,
            "Shift+Up": self._key_shift_up,
            "Shift+Down": self._key_shift_down,
            "Ctrl+Shift+Right": self._key_ctrl_shift_right,
            "Ctrl+Shift+Left": self._key_ctrl_shift_left,
            "Alt+o": self._key_alt_o_punc,
            "Alt+i": self._key_alt_i_punc,
        }

        if theme == "current":
            theme = config.STATIC_CONFIG.get("current_theme", "default")

        config.STATIC_CONFIG["current_theme"] = theme

    # Arrow keys
    def _key_right(self) -> None:
        self.end_selection()
        self.move_cursor("Right")

    def _key_left(self) -> None:
        self.end_selection()
        self.move_cursor("Left")

    def _key_up(self) -> None:
        self.end_selection()
        self.move_cursor("Up")

    def _key_down(self) -> None:
        self.end_selection()
        self.move_cursor("Down")

    # Vim movement
    def _key_l(self) -> None:
        self.move_cursor("Right")

    def _key_h(self) -> None:
        self.move_cursor("Left")

    def _key_k(self) -> None:
        self.move_cursor("Up")

    def _key_j(self) -> None:
        self.move_cursor("Down")

    def _key_i(self) -> None:
        self.change_modes("INSERT")

    def _key_a(self) -> None:
        self.end_selection()
        self.move_cursor("Right")
        self.change_modes("INSERT")

    def _key_A(self) -> None:
        self.end_selection()
        self.move_cursor_start_of_line()
        self.move_cursor_by_punctuation("right")
        self.change_modes("INSERT")

    def _key_o(self) -> None:
        if self.selection_start:
            self.toggle_selection_start()
        else:
            self.change_modes(mode="INSERT")
            self.move_cursor_end_of_line()
            self.newline()

    def _key_O(self) -> None:
        self.end_selection()
        self.move_cursor("Up")
        self.change_modes(mode="INSERT")

        if self.buffers[self.current_buffer].cursor_y == 0:
            self.move_cursor_start_of_line()
            self.newline()
            self.move_cursor("Up")

        else:
            self.move_cursor_end_of_line()
            self.newline()

    def _key_s(self) -> None:
        self.select_text_object_prefix()

    def _key_c(self) -> None:
        self.change_modes("INSERT")
        self.delete()

    def _key_x(self) -> None:
        self.change_modes("INSERT")
        self.cut()

    def _key_d(self) -> None:
        self.cut()

    def _key_colon(self) -> None:
        self.command_mode_mappings()

    def _key_v(self) -> None:
        self.toggle_selection()

    def _key_V(self) -> None:
        if not self.selection_start:
            if (
                self.get_current_buffer().cursor_y
                != len(self.get_current_buffer().lines) - 1
            ):
                self.move_cursor_start_of_line()
                self.toggle_selection()
                self.move_cursor("Down")
            else:
                self.move_cursor_end_of_line()
                self.toggle_selection()
                self.move_cursor_start_of_line()
        else:
            if (
                self.get_current_buffer().cursor_y
                != len(self.get_current_buffer().lines) - 1
            ):
                self.toggle_selection()
                self.move_cursor_start_of_line()
                self.move_cursor("Up")
            else:
                self.toggle_selection()
                self.move_cursor_start_of_line()

    def _key_y(self) -> None:
        self.copy()
        self.end_selection()

    def _key_u(self) -> None:
        self.end_selection()
        self.undo()

    def _key_U(self) -> None:
        self.end_selection()
        self.redo()

    def _key_gt(self) -> None:
        self.change_indentation(direction=1)

    def _key_lt(self) -> None:
        self.change_indentation(direction=-1)

    def _key_alt_slash(self) -> None:
        self.toggle_comment_selection()

    def _key_K(self) -> None:
        self.end_selection()
        self.lsp_hover()

    def _key_semicolon(self) -> None:
        self.end_selection()
        self.lsp_definition()

    def _key_T(self) -> None:
        self.command_mode_mappings(command=self.command_history[-1])

    def _key_0(self) -> None:
        self.move_cursor_start_of_line()

    def _key_dollar(self) -> None:
        self.move_cursor_end_of_line()

    def _key_ctrl_a(self) -> None:
        self.select_hole_file()

    def _key_n(self) -> None:
        self.search_re()

    def _key_N(self) -> None:
        self.search_re(backwards=True)

    def _key_star(self) -> None:
        self.search_word_under_cursor()
        self.end_selection()

    def _key_p(self) -> None:
        self.paste()

    def _key_P(self) -> None:
        self.end_selection()
        self.move_cursor_start_of_line()
        self.move_cursor("Down")
        self.newline()
        self.move_cursor("Up")
        self.paste()

    def _key_ctrl_p(self) -> None:
        self.paste_from_system_clipboard()

    def _key_alt_r(self) -> None:
        self.lsp_references()

    def _key_alt_w(self) -> None:
        self.end_selection()
        self.change_modes("NORMAL")
        self.show_file_picker()

    def _key_alt_i(self) -> None:
        self.go_to_jump(direction=-1)

    def _key_alt_o(self) -> None:
        self.go_to_jump(direction=1)

    def _key_m(self) -> None:
        self.end_selection()
        self.set_marker()

    def _key_M(self) -> None:
        self.end_selection()
        self.pick_markers()

    def _key_tick(self) -> None:
        self.manage_registers()

    def _key_backtick(self) -> None:
        self.end_selection()
        self.go_to_last_buffer()

    def _key_pageup(self) -> None:
        self.page_up()

    def _key_pagedown(self) -> None:
        self.page_down()

    def _key_g(self) -> None:
        self.go_to_file_start()

    def _key_G(self) -> None:
        self.go_to_file_end()

    def _key_H(self) -> None:
        self.page_up()

    def _key_L(self) -> None:
        self.page_down()

    def _key_ctrl_up(self) -> None:
        self.page_up()

    def _key_ctrl_down(self) -> None:
        self.page_down()

    def _key_J(self) -> None:
        self.end_selection()
        self.merge_lines()

    def _key_ctrl_x(self) -> None:
        self.show_command_picker()

    def _key_Q(self) -> None:
        self.show_line_diagnostics()

    def _key_q(self) -> None:
        self.record_macro()

    def _key_at(self) -> None:
        self.exec_macro()

    def _key_alt_k(self) -> None:
        self.move_scroll(-1)

    def _key_alt_j(self) -> None:
        self.move_scroll(1)

    def _key_e(self) -> None:
        self.move_cursor_by_punctuation("right")

    def _key_w(self) -> None:
        self.move_cursor_by_punctuation("right")

    def _key_W(self) -> None:
        self.move_cursor_by_word("right")

    def _key_E(self) -> None:
        self.move_cursor_by_word("right")

    def _key_b(self) -> None:
        self.move_cursor_by_punctuation("left")

    def _key_B(self) -> None:
        self.move_cursor_by_word("left")

    def _key_f(self) -> None:
        self.find_char()

    def _key_F(self) -> None:
        self.find_char(forward=False)

    def _key_open_bracket(self) -> None:
        self.move_cursor_by_empty_line(-1)

    def _key_close_bracket(self) -> None:
        self.move_cursor_by_empty_line(1)

    def _key_ctrl_right(self) -> None:
        self.move_cursor_by_punctuation("right")

    def _key_ctrl_left(self) -> None:
        self.move_cursor_by_punctuation("left")

    def _key_ctrl_i(self) -> None:
        self.end_selection()
        self.go_next_buffer()

    def _key_353(self) -> None:
        self.end_selection()
        self.go_prev_buffer()

    def _key_ctrl_d(self) -> None:
        self.end_selection()
        self.close_buffer()

    def _key_ctrl_o(self) -> None:
        self.end_selection()
        self.open_buffer_prompt()

    def _key_slash(self) -> None:
        self.end_selection()
        self.search_prompt()

    def _key_percent(self) -> None:
        self.go_to_matching_bracket()

    # Selection toggle (Alt+;)
    def _key_alt_semicolon(self) -> None:
        self.toggle_selection()

    # Indentation (Alt+Right / Alt+. etc)
    def _key_alt_indent_right(self) -> None:
        self.change_indentation(direction=1)

    def _key_alt_indent_left(self) -> None:
        self.change_indentation(direction=-1)

    # Alt+h/j/k/l navigation (no end_selection here)
    def _key_alt_h(self) -> None:
        self.move_cursor("Left")

    def _key_alt_j_move(self) -> None:
        self.move_cursor("Down")

    def _key_alt_k_move(self) -> None:
        self.move_cursor("Up")

    def _key_alt_l(self) -> None:
        self.move_cursor("Right")

    # Line start/end
    def _key_alt_9(self) -> None:
        self.move_cursor_start_of_line()

    def _key_alt_0(self) -> None:
        self.move_cursor_end_of_line()

    # Alt+[ set marker (with end_selection)
    def _key_alt_open_bracket(self) -> None:
        self.end_selection()
        self.set_marker()

    # Alt+' registers
    def _key_alt_quote(self) -> None:
        self.manage_registers()

    # Scroll
    def _key_alt_up_scroll(self) -> None:
        self.move_scroll(-1)

    def _key_alt_down_scroll(self) -> None:
        self.move_scroll(1)

    # Ctrl+Up/Down empty line navigation
    def _key_ctrl_up_empty(self) -> None:
        self.end_selection()
        self.move_cursor_by_empty_line(-1)

    def _key_ctrl_down_empty(self) -> None:
        self.end_selection()
        self.move_cursor_by_empty_line(1)

    # Ctrl+Alt word movement
    def _key_ctrl_alt_right(self) -> None:
        self.end_selection()
        self.move_cursor_by_word("right")

    def _key_ctrl_alt_left(self) -> None:
        self.end_selection()
        self.move_cursor_by_word("left")

    # Shift selection arrows
    def _key_shift_right(self) -> None:
        self.start_selection()
        self.move_cursor("Right")

    def _key_shift_left(self) -> None:
        self.start_selection()
        self.move_cursor("Left")

    def _key_shift_up(self) -> None:
        self.start_selection()
        self.move_cursor("Up")

    def _key_shift_down(self) -> None:
        self.start_selection()
        self.move_cursor("Down")

    # Ctrl+Shift punctuation selection
    def _key_ctrl_shift_right(self) -> None:
        self.start_selection()
        self.move_cursor_by_punctuation("right")

    def _key_ctrl_shift_left(self) -> None:
        self.start_selection()
        self.move_cursor_by_punctuation("left")

    # Alt+o / Alt+i punctuation movement
    def _key_alt_o_punc(self) -> None:
        self.move_cursor_by_punctuation("right")

    def _key_alt_i_punc(self) -> None:
        self.move_cursor_by_punctuation("left")

    # ================ END KEYS ==================

    def get_path_from_uri(self, uri: str) -> Path | None:
        parsed = urlparse(uri)

        if parsed.scheme == "file":
            return Path(parsed.path)

        if parsed.scheme == "inmemory":
            return None

        raise ValueError(f"Unsupported URI scheme: {parsed.scheme}")

    def change_modes(self, mode: str) -> None:
        if mode == "NORMAL" and self.mode == "INSERT":
            buffer = self.get_current_buffer()

            if (action := buf_actions.change_modes(buffer)) is not None:
                self.apply_action_to_buffer(action)

        self.mode = mode

    def toggle_selection_start(self) -> None:
        if self.selection_start:
            buffer = self.get_current_buffer()
            sy, sx = self.selection_start
            cy = buffer.cursor_y
            cx = buffer.cursor_x

            buffer.cursor_x = sx
            buffer.cursor_y = sy
            self.selection_start = (cy, cx)

    def process_ai_completions(self, buffer: Buffer, job_id: str) -> None:
        status = self.ai_completion_manager.get_status(job_id)

        if status is None:
            return None

        for i in range(len(buffer.ai_completions)):
            if buffer.ai_completions[i].code != job_id:
                continue

            c = buffer.ai_completions.pop(i)

            severity = 2

            if status == "RUNNING":
                severity = 3

            elif status == "ERROR" or status == "CANCELED":
                severity = 1

            elif status == "COMPLETED":
                severity = 4

            buffer.ai_completions.append(
                Diagnostic(
                    line=min(c.line, len(buffer.lines) - 1),
                    char=c.char,
                    code=c.code,
                    message=status,
                    severity=severity,
                )
            )

    def process_diagnostics(self, buffer: Buffer, diagnostics: list[dict]) -> None:
        """
        Process diagnostics from LSP and update buffer lines.
        """
        if not buffer or buffer.first:
            return

        buffer.diagnostics.clear()

        if not diagnostics:
            return

        buf_lines = len(buffer.lines)
        for diag in diagnostics:
            match diag:
                case {
                    "source": _,
                    "range": {"start": {"line": line, "character": char}, "end": _},
                    "code": code,
                    "message": message,
                    "severity": severity,
                }:
                    if buf_lines > line:
                        buffer.diagnostics.append(
                            hilighing.Diagnostic(
                                line=line,
                                char=char,
                                code=code,
                                message=message,
                                severity=severity,
                            )
                        )

                case {
                    "source": _,
                    "range": {"start": {"line": line, "character": char}, "end": _},
                    "message": message,
                    "severity": severity,
                }:
                    if buf_lines > line:
                        buffer.diagnostics.append(
                            hilighing.Diagnostic(
                                line=line,
                                char=char,
                                code="",
                                message=message,
                                severity=severity,
                            )
                        )

                case {
                    "message": message,
                    "range": {"start": {"line": line, "character": char}, "end": _},
                    "severity": severity,
                }:
                    if buf_lines > line:
                        buffer.diagnostics.append(
                            hilighing.Diagnostic(
                                line=line,
                                char=char,
                                code="",
                                message=message,
                                severity=severity,
                            )
                        )

                case _:
                    self.open_aux_buffer(json.dumps(diag, indent=4))
                    break

    def draw(self) -> None:
        stdscr = self.stdscr
        cp = curses.color_pair

        normal = cp(1)
        red_trailing = cp(15)
        sel_attr = cp(31)

        buffer = self.get_current_buffer()
        top = buffer.scroll
        len_buffer_lines = len(buffer.lines)
        bottom = min(len_buffer_lines, top + self.height - 1)
        max_width = self.width - 1

        buffer_tab_size = buffer.tab_size

        _get_offsets = get_offsets
        _render_slice = render_slice

        match = None

        width_len_buffer_lines = len(str(len_buffer_lines))

        if config.STATIC_CONFIG.get("brkm", False):
            match = find_matching_bracket(
                buffer.lines, buffer.cursor_y, buffer.cursor_x
            )

        current_gutter = 0

        if top <= buffer.cursor_y < bottom:
            line = buffer.lines[buffer.cursor_y]
            offsets = _get_offsets(line, buffer_tab_size)

            cursor_vis_col = (
                offsets[buffer.cursor_x]
                if buffer.cursor_x < len(offsets)
                else offsets[-1]
            )

            cursor_y_screen = buffer.cursor_y - buffer.scroll

            current_gutter = 0
            if self.gutter_render and 0 <= cursor_y_screen < self.height - 1:
                current_gutter = self.gutter_render(
                    stdscr,
                    cursor_y_screen,
                    buffer.cursor_y,
                    buffer,
                    width_len_buffer_lines,
                )

            buffer.current_gutter_width = (
                0 if current_gutter <= 0 else current_gutter - 2
            )

            visible_width = max(1, (self.width - 1) - current_gutter - 1)

            buffer.h_scroll = line_x(cursor_vis_col, visible_width)

        h_scroll = buffer.h_scroll

        hilighing.highlight_with_pygments(
            code_lines=buffer.lines,
            lexer=buffer.lexer,
            start_line=top,
            end_line=bottom,
            width=max_width,
            height=self.height,
            buffer=buffer,
        )

        search_by_line = None
        if not self.disable_search and self.last_search:
            search_by_line = defaultdict(list)

            use_regex = self.last_search_re is not None
            needle = self.last_search.lower() if not use_regex else None

            for y in range(top, bottom):
                line = buffer.lines[y]
                offsets = _get_offsets(line, buffer_tab_size)
                visual_width = offsets[-1]

                if h_scroll >= visual_width:
                    continue

                matches: Iterable[Any] | None = None
                if self.last_search_re is not None:
                    matches = self.last_search_re.finditer(line)
                else:
                    matches = []
                    text = line.lower()
                    i = 0

                    if needle is None:
                        needle = ""

                    while True:
                        pos = text.find(needle, i)
                        if pos < 0:
                            break
                        matches.append((pos, pos + len(needle)))
                        i = pos + len(needle)

                for m in matches:
                    if use_regex:
                        a = m.start()
                        b = m.end()
                    else:
                        a, b = cast(tuple[int, int], m)

                    s = offsets[a] if a < len(offsets) else visual_width
                    e = offsets[b] if b < len(offsets) else visual_width

                    if e <= h_scroll or s >= h_scroll + max_width:
                        continue

                    start_i = a
                    end_i = b

                    start_i = max(0, min(start_i, len(line)))
                    end_i = max(start_i, min(end_i, len(line)))

                    seg = _render_slice(line, start_i, end_i, offsets, buffer_tab_size)

                    if not seg:
                        continue

                    search_by_line[y].append(
                        hilighing.HilightedLine(
                            y=y,
                            start=a,
                            end=b,
                            attr=21,
                        )
                    )

        best_diag = None
        if buffer.diagnostics:
            diags_by_line = defaultdict(list)
            for d in buffer.diagnostics:
                if top <= d.line < bottom:
                    diags_by_line[d.line].append(d)

            best_diag = {}
            for ln, _ds in diags_by_line.items():
                _ds.sort(key=lambda d: d.severity, reverse=True)
                best_diag[ln] = (_ds[0], len(_ds))

        completions_by_line = None
        if buffer.ai_completions:
            completions_by_line = {
                c.line: c for c in buffer.ai_completions if top <= c.line < bottom
            }

        stdscr.erase()

        if not self.input_timeout:
            curses.curs_set(0)
        else:
            curses.curs_set(1)

        sel_active = self.selection_start is not None

        if self.selection_start is not None:
            sy, sx = self.selection_start
            ey, ex = buffer.cursor_y, buffer.cursor_x
            if (sy, sx) > (ey, ex):
                sy, sx, ey, ex = ey, ex, sy, sx

        for screen_row, line_no in enumerate(range(top, bottom)):
            line = buffer.lines[line_no]
            offsets = _get_offsets(line, buffer_tab_size)
            visual_width = offsets[-1]

            gutter_width = current_gutter

            if self.gutter_render:
                gutter_width = self.gutter_render(
                    stdscr, screen_row, line_no, buffer, width_len_buffer_lines
                )

            line_width = max_width - gutter_width - 1
            if line_width <= 0:
                continue

            start_i = bisect_left(offsets, h_scroll)
            end_i = bisect_right(offsets, h_scroll + line_width)

            slice_text = _render_slice(line, start_i, end_i, offsets, buffer_tab_size)
            visible_cells_used = len(slice_text)
            marker_x = gutter_width + line_width

            # base text
            if slice_text:
                stdscr.addnstr(
                    screen_row,
                    gutter_width,
                    slice_text.ljust(line_width),
                    line_width,
                    normal,
                )

            # trailing spaces
            trail_idx = len(line.rstrip())
            if trail_idx < len(line):
                trail_col = offsets[trail_idx]
                vis_start = trail_col - h_scroll

                trail_end_col = offsets[len(line)]
                trail_len = trail_end_col - trail_col

                if 0 <= vis_start < line_width:
                    stdscr.chgat(
                        screen_row,
                        gutter_width + vis_start,
                        min(trail_len, line_width - vis_start),
                        red_trailing,
                    )

            # syntax highlight
            if line.tokens:
                for span in line.tokens:
                    if span is None or span.start >= len(offsets):
                        continue

                    s = offsets[span.start] - h_scroll
                    e = (
                        offsets[span.end] - h_scroll
                        if span.end < len(offsets)
                        else visual_width - h_scroll
                    )

                    if e <= 0 or s >= line_width:
                        continue

                    ds = max(s, 0)
                    de = min(e, line_width)

                    stdscr.chgat(
                        screen_row,
                        gutter_width + ds,
                        de - ds,
                        cp(span.attr),
                    )

            # bracket highlight
            if match:
                cursor_pos = (buffer.cursor_y, buffer.cursor_x)

                for by, bx in match:

                    if line_no != by:
                        continue

                    if bx < len(offsets):
                        col = offsets[bx] - h_scroll
                    else:
                        col = offsets[-1] - h_scroll

                    if not (0 <= col < line_width):
                        continue

                    try:
                        # Skip the bracket under the cursor
                        if (by, bx) == cursor_pos:
                            continue

                        # Detect if this position already has syntax highlighting
                        attr = cp(1)  # default normal color

                        if line.tokens:
                            for span in line.tokens:
                                if span and span.start <= bx < span.end:
                                    attr = cp(span.attr)
                                    break

                        stdscr.chgat(
                            screen_row,
                            gutter_width + col,
                            1,
                            attr | curses.A_REVERSE,
                        )

                    except Exception:
                        pass

            # search highlight
            if search_by_line is not None:
                for span in search_by_line.get(line_no, ()):
                    s = offsets[span.start] - h_scroll
                    e = (
                        offsets[span.end] - h_scroll
                        if span.end < len(offsets)
                        else visual_width - h_scroll
                    )

                    if e <= 0 or s >= line_width:
                        continue

                    ds = max(s, 0)
                    de = min(e, line_width)

                    stdscr.chgat(
                        screen_row,
                        gutter_width + ds,
                        de - ds,
                        cp(span.attr),
                    )

            # selection
            if sel_active and sy <= line_no <= ey:
                start_col = sx if line_no == sy else 0
                end_col = ex if line_no == ey else len(line)

                if len(line) == 0:
                    draw_start = max(0, -h_scroll)
                    draw_end = max(draw_start + 1, 1)

                    if draw_start < line_width:
                        draw_end = min(draw_end, line_width)

                        stdscr.chgat(
                            screen_row,
                            gutter_width + draw_start,
                            draw_end - draw_start,
                            sel_attr,
                        )
                else:
                    s = (
                        offsets[start_col] - h_scroll
                        if start_col < len(offsets)
                        else visual_width - h_scroll
                    )
                    e = (
                        offsets[end_col] - h_scroll
                        if end_col < len(offsets)
                        else visual_width - h_scroll
                    )

                    ds = max(s, 0)
                    de = min(e, line_width)

                    if de <= ds and start_col != end_col:
                        de = min(ds + 1, line_width)

                    if de > ds:
                        stdscr.chgat(
                            screen_row,
                            gutter_width + ds,
                            de - ds,
                            sel_attr,
                        )

            # 8) Diagnostics / AI
            if best_diag is not None:
                if line_no in best_diag:
                    diag, count = best_diag[line_no]
                    char_pos = min(visible_cells_used + 1, line_width - 1)
                    if (
                        0 <= char_pos < line_width
                        and gutter_width + char_pos < marker_x
                    ):
                        sev_color = hilighing.SEVERITY_COLORS.get(diag.severity, 1)
                        diag_text = f"{diag.code}{f'+{count - 1}' if count > 1 else ''}: {diag.message}"
                        try:
                            stdscr.addnstr(
                                screen_row,
                                gutter_width + char_pos,
                                diag_text,
                                max(0, marker_x - (gutter_width + char_pos)),
                                cp(sev_color),
                            )
                        except Exception:
                            pass

            if completions_by_line is not None:
                if line_no in completions_by_line:
                    diag = completions_by_line[line_no]
                    char_pos = min(visible_cells_used + 1, line_width - 1)
                    if (
                        0 <= char_pos < line_width
                        and gutter_width + char_pos < marker_x
                    ):
                        sev_color = hilighing.SEVERITY_COLORS.get(diag.severity, 1)
                        diag_text = f"{diag.code}: {diag.message}"
                        try:
                            stdscr.addnstr(
                                screen_row,
                                gutter_width + char_pos,
                                diag_text,
                                max(0, marker_x - (gutter_width + char_pos)),
                                cp(sev_color),
                            )
                        except Exception:
                            pass

            # overflow marker
            if visual_width > h_scroll + line_width:
                stdscr.addch(screen_row, marker_x, "»", red_trailing)

        # status bar
        status_left = (
            f"{self.current_branch}\u2387 "
            f"({self.current_buffer + 1}/{len(self.buffers)}) -- "
            f"{self.mode} -- "
            f"{'*' if buffer.modified else ' '}"
            f"{buffer.file_name or '[No Name]'} "
        )

        if self.recording_macro:
            status_left += f" @{self.current_macro_recording} "

        if self.last_search and not self.disable_search:
            status_left += f"search: [{self.last_search}] "

        lines_selected = (
            abs(buffer.cursor_y - self.selection_start[0]) + 1
            if self.selection_start
            else 0
        )

        sel_text = (
            f"selected: [{lines_selected}, {len(''.join(self.get_selected_text(move_cursor=False)))}] "
            if lines_selected
            else ""
        )

        lsp_info = ""
        if buffer.diagnostics:
            sev_map = {1: "E", 2: "W", 3: "I", 4: "H"}
            sev_counts: dict[int, int] = {}
            for d in buffer.diagnostics:
                sev_counts[d.severity] = sev_counts.get(d.severity, 0) + 1

            sev_str = ", ".join(
                f"{sev_map.get(sev, sev)}:{count}"
                for sev, count in sorted(sev_counts.items())
            )
            lsp_info = f"LSP[{sev_str}] "

        ai_info = ""
        if buffer.ai_completions:
            completed = sum(
                1 for c in buffer.ai_completions if c.message == "COMPLETED"
            )
            total = len(buffer.ai_completions)
            ai_info = f"AI[{completed}/{total}] "

        if buffer.cursor_y == 0:
            line_porcentage = "Top"
        elif buffer.cursor_y == len_buffer_lines - 1:
            line_porcentage = "Bot"
        else:
            line_porcentage = f"{int(buffer.cursor_y / len_buffer_lines * 100)}%"

        line_porcentage = line_porcentage.rjust(5)

        lang_info = (
            f"({buffer.lexer.name if buffer.lexer else 'Text'}) "
            f"{buffer.encoding} "
            f"[{buffer.cursor_y + 1}, {buffer.cursor_x}]" + line_porcentage
        )

        right_chunk = f"{sel_text}{ai_info}{lsp_info}{lang_info}"

        usable = self.width - 1
        max_left = max(0, usable - len(right_chunk))

        left_part = status_left[:max_left]
        status_line = left_part.ljust(max_left) + right_chunk

        stdscr.move(self.height - 1, 0)
        stdscr.clrtoeol()

        stdscr.addnstr(
            self.height - 1,
            0,
            status_line,
            usable,
            curses.color_pair(20),
        )

        try:
            stdscr.addstr(self.height - 1, usable, " ", curses.color_pair(20))
        except Exception:
            pass

        # cursor
        if top <= buffer.cursor_y < bottom:
            line = buffer.lines[buffer.cursor_y]
            offsets = _get_offsets(line, buffer_tab_size)

            cursor_vis_col = (
                offsets[buffer.cursor_x]
                if buffer.cursor_x < len(offsets)
                else offsets[-1]
            )

            cursor_y = buffer.cursor_y - buffer.scroll

            # if self.gutter_render:
            #     current_gutter = self.gutter_render(
            #         stdscr, cursor_y, buffer.cursor_y, buffer
            #     )

            visible_width = max(1, (self.width - 1) - current_gutter - 1)

            cursor_x_screen = cursor_vis_col - buffer.h_scroll
            cursor_x_screen = max(0, min(cursor_x_screen, visible_width - 1))

            stdscr.move(cursor_y, current_gutter + cursor_x_screen)

        stdscr.noutrefresh()
        curses.doupdate()
        curses.curs_set(1)

    async def file_watcher(self, interval: float = 1.0) -> None:
        try:
            while True:
                await asyncio.sleep(interval)

                buffer = self.get_current_buffer()

                if (
                    buffer.first
                    or buffer.is_aux_buffer
                    or buffer.file_time_stamp is None
                ):
                    continue

                try:
                    current_time_stamp = os.path.getmtime(str(buffer.file_name))
                except FileNotFoundError:
                    continue

                if current_time_stamp != buffer.file_time_stamp:
                    await events.EVENT_QUEUE.put(
                        Event(
                            type=EventType.FILE_CHANGED_ON_DISK, data=buffer.file_name
                        )
                    )

        except asyncio.CancelledError:
            return

    def handle_external_file_change(self, file_name: str) -> None:
        buffer_index = self.get_buffer_by_file_name(file_name)

        if buffer_index == -1:
            return

        buffer = self.buffers[buffer_index]

        if buffer.is_aux_buffer or buffer.file_time_stamp is None:
            return

        try:
            if buffer.file_name is not None:
                current_time_stamp = os.path.getmtime(str(buffer.file_name))
        except FileNotFoundError:
            return

        if current_time_stamp == buffer.file_time_stamp:
            return

        tmp_buffer = Buffer()
        _, new_sha256 = tmp_buffer.load_file(buffer.file_name)
        del tmp_buffer

        if buffer.file_sha256 == new_sha256:
            buffer.file_time_stamp = current_time_stamp
            return

        if not buffer.modified:
            self._reload_buffer_from_disk(buffer, current_time_stamp)
            self.send_notification(f"File '{buffer.file_name}' reloaded from disk.")
            return

        if self.send_prompt_confirm(
            f"File '{buffer.file_name}' modified externally. Reload?"
        ):
            self._reload_buffer_from_disk(buffer, current_time_stamp)
            self.send_notification(f"File '{buffer.file_name}' reloaded from disk.")

    def _reload_buffer_from_disk(self, buffer, new_timestamp) -> None:
        old_lines = buffer.get_lines()

        new_lines, new_sha256 = buffer.load_file(buffer.file_name)

        buffer.file_time_stamp = new_timestamp
        buffer.file_sha256 = new_sha256

        cursor_before = buffer.get_cursor_position()

        action_group = buf_actions.generate_buffer_actions(
            old_lines=old_lines,
            new_lines=new_lines,
        )

        buffer.apply_action(action_group)

        buffer.set_cursor_position(cursor_before)
        buffer.modified = False

    async def git_branch_watcher(self, path: str = ".", interval: float = 5.0) -> None:
        """
        Periodically checks current git branch.
        Updates cached value only if changed.
        """
        try:
            await asyncio.sleep(0.2)

            while True:
                branch = git_utils.get_current_branch_cached(path)

                if branch != self.current_branch:
                    await events.EVENT_QUEUE.put(
                        Event(type=EventType.GIT_BRANCH_UPDATED, data=branch)
                    )

                await asyncio.sleep(interval)

        except asyncio.CancelledError:
            # Clean shutdown
            raise

    async def tick(self) -> None:
        try:
            await asyncio.sleep(0.1)

            while True:
                buffer = self.get_current_buffer()

                if buffer.deverge_state < (buffer.scroll + self.height - 1):
                    await events.EVENT_QUEUE.put(Event(EventType.TICK))
                    await asyncio.sleep(0.01)
                else:
                    await asyncio.sleep(0.5)

        except asyncio.CancelledError:
            return

    async def input_watcher(self) -> None:
        try:
            while True:
                try:
                    key = self.stdscr.get_wch()
                except curses.error:
                    await asyncio.sleep(0.016)
                    continue

                await events.EVENT_QUEUE.put(Event(type=EventType.KEY, data=key))

                if key == "\x1b":  # ESC
                    await asyncio.sleep(0.01)

        except asyncio.CancelledError:
            return

    def handle_lsp_event(self, event: Event) -> None:
        _data = cast(dict[str, Any], event.data)

        request_type, request_data, _result = (
            _data["request_type"],
            _data["request_data"],
            _data["result"],
        )

        match request_type:
            case LSPEventType.TEXT_DOCUMENT_HOVER:
                if _result:
                    match _result:
                        case {"result": {"contents": {"value": value}}}:
                            open_file_in_less_mode(
                                window=self.stdscr,
                                file_handle=StringIO(value),
                                editor=self,
                            )
                        case _:
                            self.send_notification("Hover information not available.")
                else:
                    self.send_notification("No hover information available.")

            case LSPEventType.TEXT_DOCUMENT_DEFINITION:

                match _result:
                    case {"result": results} if isinstance(results, list):
                        for result in results:
                            match result:
                                case {
                                    "uri": uri,
                                    "range": {
                                        "start": {
                                            "line": start_line,
                                            "character": start_char,
                                        },
                                        "end": _,
                                    },
                                }:

                                    file_path = self.get_path_from_uri(uri)

                                    if file_path is None:
                                        return

                                    file_name = file_path.relative_to(Path.cwd())

                                    buf_index = self.get_buffer_by_file_name(
                                        str(file_name)
                                    )

                                    if buf_index == -1:
                                        new_buffer = Buffer(
                                            file_name=str(file_name),
                                            temp_dir=self.temp_dir,
                                        )
                                        self.buffers.append(new_buffer)
                                        self.current_buffer = len(self.buffers) - 1
                                    else:
                                        self.current_buffer = buf_index

                                    buffer = self.get_current_buffer()

                                    buffer.cursor_y = start_line
                                    buffer.cursor_x = start_char
                                case _:
                                    self.send_notification(
                                        "Error: Invalid definition result format."
                                    )
                    case {
                        "result": {
                            "uri": uri,
                            "range": {
                                "start": {
                                    "line": start_line,
                                    "character": start_char,
                                },
                                "end": _,
                            },
                        }
                    }:

                        file_path = self.get_path_from_uri(uri)

                        if file_path is None:
                            return

                        file_name = file_path.relative_to(Path.cwd())
                        buf_index = self.get_buffer_by_file_name(str(file_name))

                        if buf_index == -1:
                            new_buffer = Buffer(
                                file_name=str(file_name),
                                temp_dir=self.temp_dir,
                            )
                            self.buffers.append(new_buffer)
                            self.current_buffer = len(self.buffers) - 1
                        else:
                            self.current_buffer = buf_index

                        buffer = self.get_current_buffer()

                        buffer.cursor_y = start_line
                        buffer.cursor_x = start_char

                    case _:
                        self.send_notification(
                            "Definition result is not a list." + str(_result)
                        )

            case LSPEventType.TEXT_DOCUMENT_REFERENCES:

                references_info = _result

                if references_info:
                    match references_info:
                        case {"result": references, **rest} if isinstance(
                            references, list
                        ):
                            self.show_references_picker(references)

                        case {"error": {"message": msg, **error_rest}, **rest}:
                            self.send_notification(f"References not avilable {msg}.")

                        case _:
                            self.open_aux_buffer(json.dumps(references_info, indent=4))
                else:
                    self.send_notification("References not avilable.")

            case LSPEventType.TEXT_DOCUMENT_COMPLETION:

                lsp_completions = _result

                if lsp_completions:

                    lsp_matches = set()

                    match lsp_completions:
                        case {"result": {"items": items}} if isinstance(items, list):
                            for item in items:
                                label = item.get("insertText") or item.get("label")
                                if label:
                                    lsp_matches.add(label)

                        case {"result": items} if isinstance(items, list):
                            for item in items:
                                label = item.get("insertText") or item.get("label")
                                if label:
                                    lsp_matches.add(label)

                        case {"error": {"message": _message}} if isinstance(
                            _message, str
                        ):
                            self.send_notification("Error: " + _message)
                            return

                        case _:
                            self.open_aux_buffer(str(lsp_completions))
                            return

                    self.show_suggestions(lsp_matches)

    def handle_subprocess_event(self, event) -> None:
        try:
            match event.type:
                case EventType.SUBPROCESS_STARTED:
                    self.send_notification(
                        f"Command started: {event.data["command"].split("\n")[0]}"
                    )

                    task_id = event.data["task_id"]

                    for t in self.task_running:
                        if t["task_id"] == task_id:
                            t["status"] = "STARTED"
                            break

                case EventType.SUBPROCESS_COMPLETED:
                    self.send_notification_nowait(
                        f"Command Completed: {event.data["command"].split("\n")[0]}"
                    )
                    self._process_subprocess_output(event)

                case EventType.SUBPROCESS_CANCELLED:
                    self.send_notification_nowait(
                        f"Command cancelled or error, exited with code ({event.data["return_code"]}): {event.data["command"].split("\n")[0]}"
                    )
                    self._process_subprocess_output(event)

        except Exception as e:
            self.send_notification(
                f"An eror has ocour {e}]\n{traceback.format_exc()}", 0
            )

    def _process_subprocess_output(self, event: Event) -> None:
        _data = cast(dict[str, Any], event.data)

        stdout = _data["file"]
        size = _data["size"]
        exit_code = _data["return_code"]
        CEP = _data["cep"]
        task_id = _data["task_id"]

        try:
            output = None

            if CEP:
                output = stdout.read().decode("utf-8", "replace").strip()
                self.parse_compiler_diagnostics(output)
                return None

            open_file_in_less_mode(
                window=self.stdscr,
                file_handle=stdout,
                editor=self,
                cursor_pos=(self.height - 2, 0),
            )

            stdout.seek(0)

            if size >= 500_000:
                if not self.send_prompt_confirm(
                    f"Output is very large ({size:,} bytes). continue?",
                    color_p=15,
                ):
                    return None

            if self.send_prompt_confirm(
                f"Do you want to open the output ({size} bytes) in a new buffer?"
            ):
                output = stdout.read().decode("utf-8", "replace").strip()
                self.open_untitled_buffer(output)

            elif self.send_prompt_confirm(
                f"Do you want to paste the output ({size} bytes) into the current buffer?"
            ):
                if not output:
                    output = (
                        "\n" + stdout.read().decode("utf-8", "replace").strip() + "\n"
                    )
                    output = output.replace("\r\n", "\n").replace("\r", "\n")
                    output = output.expandtabs()
                    output = output.replace("\x00", "�")

                self.insert_char(output, disable_autocomplete=True)

        except Exception as e:
            self.send_multiline_notification(
                f"Command failed: {e} \n{traceback.format_exc()}", 0
            )

            with open("errors.pytb", "a") as f:
                f.write(f"\n\n{e}\n{traceback.format_exc()}\n")

        finally:
            stdout.close()

            for t in self.task_running:
                if t["task_id"] == task_id:
                    self.task_running.remove(t)
                    break

    def handle_http_request_event(self, event) -> None:
        try:
            match event.type:
                case EventType.HTTP_REQUEST_STARTED:
                    task_id = event.data["task_id"]

                    for t in self.task_running:
                        if t["task_id"] == task_id:

                            t["status"] = "STARTED"
                            self.send_notification_nowait(
                                f"HTTP request started: {t["method"]} {t["url"]}"
                            )

                            break

                case EventType.HTTP_REQUEST_COMPLETED:
                    task_id = event.data["task_id"]

                    for t in self.task_running:
                        if t["task_id"] == task_id:
                            self.send_notification_nowait(
                                f"HTTP request Completed: {t["method"]} {t["url"]}"
                            )
                            break

                    self._process_http_request(event)

                case EventType.HTTP_REQUEST_CANCELLED:
                    task_id = event.data["task_id"]

                    for t in self.task_running:
                        if t["task_id"] == task_id:
                            self.task_running.remove(t)
                            break

                    self.send_notification_nowait(f"HTTP request Canceled id={task_id}")

        except Exception as e:
            self.send_notification(
                f"An eror has ocour {e}]\n{traceback.format_exc()}", 0
            )

    def _process_http_request(self, event: Event) -> None:
        _data = cast(dict[str, Any], event.data)

        response = _data["response"]
        task_id = _data["task_id"]

        try:
            header_text = "\n".join(f"{k}: {v}" for k, v in response.headers.items())

            output = f"HTTP {response.status}\n"
            output += header_text
            output += "\n\n"
            output += response.text(errors="replace")

            open_file_in_less_mode(
                window=self.stdscr,
                file_handle=StringIO(output),
                editor=self,
            )
            size = len(output)

            if size >= 500_000:
                if not self.send_prompt_confirm(
                    f"Output is very large ({size:,} bytes). continue?",
                    color_p=15,
                ):
                    return None

            if self.send_prompt_confirm(
                f"Do you want to open the output ({size} bytes) in a new buffer?"
            ):
                self.open_untitled_buffer(output)

            elif self.send_prompt_confirm(
                f"Do you want to paste the output ({size} bytes) into the current buffer?"
            ):
                output = (
                    output.replace("\r\n", "\n")
                    .replace("\r", "\n")
                    .expandtabs()
                    .replace("\x00", "�")
                )
                self.insert_char(output, disable_autocomplete=True)

        finally:
            response.close()

            for t in self.task_running:
                if t["task_id"] == task_id:
                    self.task_running.remove(t)
                    break

    async def run(self, tg) -> None:
        """
        Main loop: initialize curses modes, render screen, handle keypresses.
        Supports a gutter_render callback for line numbers, git lens, etc.
        """

        # store the task group somewhere
        self.tg = tg

        curses.raw()
        curses.noecho()

        if hasattr(curses, "set_escdelay"):
            curses.set_escdelay(25)
        else:
            os.environ.setdefault("ESCDELAY", "25")

        self.stdscr.keypad(True)
        curses.mousemask(curses.ALL_MOUSE_EVENTS | curses.REPORT_MOUSE_POSITION)
        curses.mouseinterval(40)

        normal = curses.color_pair(1)
        hilighing.init_256_color_pairs()

        if config.STATIC_CONFIG.get("ln", False) and config.STATIC_CONFIG.get("gch"):
            self.gutter_render = render_line_numbers_and_git
        else:
            if config.STATIC_CONFIG.get("ln", False):
                self.gutter_render = render_line_numbers

            elif config.STATIC_CONFIG.get("gch", False):
                self.gutter_render = render_git_gutter

        self.stdscr.bkgd(" ", normal)
        last_current_buffer = self.current_buffer

        self.height, self.width = self.stdscr.getmaxyx()

        hilighing.MAX_LINE_LIMIT = self.height * 2

        try:
            theme = config.STATIC_CONFIG.get("current_theme", "default")
            themes.default.BUILDIN_THEMES[theme].apply_theme()
            self.syntax_enable = True
        except RuntimeError as e:
            self.send_multiline_notification(
                f"Error applying theme '{theme}': {e}\nReverting to no syntax highlighting.",
                0,
            )
            self.syntax_enable = False

        self.tg.create_task(self.tick())
        self.tg.create_task(self.input_watcher())
        self.tg.create_task(self.file_watcher())
        self.tg.create_task(self.git_branch_watcher())

        while True:

            buffer = self.get_current_buffer()

            if last_current_buffer != self.current_buffer:
                self.last_buffer = last_current_buffer
                last_current_buffer = self.current_buffer

            if buffer.first:
                # lazy loading of buffers for when the editor is actualy going to see them
                buffer.load()

                if config.STATIC_CONFIG.get("gch", False):
                    buffer.git_changes = git_utils.get_file_changes(buffer.file_name)

                if buffer.suffix:
                    lsp_client = get_lsp(buffer.suffix)

                    if lsp_client:
                        lsp_client.did_open(
                            get_uri_from_name(buffer.file_name),
                            "\n".join(buffer.get_lines()),
                        )

                buffer.adjust_cursor_position()
                buffer.last_cursor_x = buffer.cursor_x
                buffer.first = False

            self.height, self.width = self.stdscr.getmaxyx()

            self.adjust_scroll()

            self.stdscr.nodelay(True)  # Non-blocking

            self.draw()

            self.input_timeout = False

            try:
                event = await events.EVENT_QUEUE.get()
            except Exception:
                pass

            key = None
            event_type = event.type

            if event_type == EventType.QUIT:
                break

            elif event_type == EventType.TICK:
                self.input_timeout = True

            elif event_type == EventType.KEY:
                key = event.data

                if buffer.file_name is not None:
                    jump = Jump(
                        buffer_name=buffer.file_name,
                        position=buffer.get_cursor_position(),
                        timestamp=time.monotonic(),
                    )

                    if self.should_record_jump(
                        buffer_name=buffer.file_name, pos=jump.position
                    ):

                        self.jump_list.append(jump)

                        while len(self.jump_list) > 500:
                            self.jump_list.pop(0)

                        self.jump_index = len(self.jump_list)

                    self.last_jump = jump

            elif event_type == EventType.FILE_CHANGED_ON_DISK:
                file_name = str(event.data)
                self.handle_external_file_change(file_name)
                self.input_timeout = True

            elif event_type == EventType.NOTIFICATION:
                _data = cast(tuple[str, int], event.data)
                message, duration = _data
                self.send_notification_nowait(message, duration)

            elif event_type == EventType.GIT_BRANCH_UPDATED:
                old_branch = self.current_branch
                new_branch = cast(str, event.data)

                if old_branch != "--" and old_branch is not None:
                    self.send_notification(
                        f"Git branch was updated from {old_branch} to {new_branch}."
                    )

                self.current_branch = new_branch

            elif event_type == EventType.LSP_DIAGNOSTICS_UPDATED:
                _data_diag = cast(dict[str, Any], event.data)
                uri_buffer = self.get_buffer_from_uri(cast(str, _data_diag["uri"]))

                if uri_buffer is not None:
                    _diags = cast(list[dict[str, Any]], _data_diag["diagnostics"])
                    self.process_diagnostics(uri_buffer, _diags)

                self.input_timeout = True

            elif event_type == EventType.LSP_REQUEST_COMPLETED:
                self.handle_lsp_event(event)

            elif event_type == EventType.LOAD_LSP:
                data = event.data or {}
                suffix = data.get("suffix")
                reload = data.get("reload", False)
                lang = data.get("lang", None)

                if suffix is not None:
                    try:
                        if reload:
                            lang = data.get("lang")
                            if lang:
                                existing = config.LOADED_LSPS.get(lang)
                                if existing is not None:
                                    try:
                                        await existing.shutdown_async()
                                    except Exception:
                                        pass

                                    config.LOADED_LSPS.pop(lang, None)

                        await load_lsp(suffix)

                        lsp_client = get_lsp(suffix)

                        if lsp_client:
                            for b in self.buffers:
                                if not b.first and b.suffix == suffix:
                                    lsp_client.did_open(
                                        get_uri_from_name(b.file_name),
                                        "\n".join(b.get_lines()),
                                    )

                    except Exception as ex:
                        self.send_notification(
                            f"LSP load failed ({suffix}): {ex}", 1000
                        )

                    finally:
                        if lang:
                            config.LOADING_LSPS.discard(lang)

                self.input_timeout = True

            elif event_type in (
                EventType.SUBPROCESS_STARTED,
                EventType.SUBPROCESS_COMPLETED,
                EventType.SUBPROCESS_CANCELLED,
            ):
                self.handle_subprocess_event(event)

            elif event_type in (
                EventType.HTTP_REQUEST_STARTED,
                EventType.HTTP_REQUEST_COMPLETED,
                EventType.HTTP_REQUEST_CANCELLED,
            ):
                try:
                    self.handle_http_request_event(event)
                except Exception:
                    self.send_notification(traceback.format_exc())

            elif event_type == EventType.AI_COMPLETION:
                job_id = str(event.data)

                for b in self.buffers:
                    if b.first == False and any(
                        c.code == job_id for c in b.ai_completions
                    ):
                        self.process_ai_completions(b, job_id)
                        break
                else:
                    self.send_notification(f"Could not process {job_id=}", 1000)

            # mark task as done
            events.EVENT_QUEUE.task_done()

            try:
                if key is not None:
                    self.process_key(key)
            except Exception as e:
                self.send_notification(message=f"Error Processing key {key}: {e}.")

                with open("error.log", "a") as f:
                    f.write(f"{e}, {traceback.format_exc()}")

        await self.ai_completion_manager.shutdown()

        for v in config.LOADED_LSPS.values():
            if v._init_started:
                await v.shutdown_async()

        for buffer in self.buffers:
            if buffer.first:
                continue

            try:
                buffer.undo_manager.cleanup()
            except Exception as e:
                with open("error.log" "a") as f:
                    f.write(f"{e}, {traceback.format_exc()}")

        raise asyncio.CancelledError

    def command_mode_mappings(self, command: Optional[str] = None) -> None:
        buffer = self.get_current_buffer()
        if not self.disable_search:
            self.disable_search = True

        arg = None

        if command is not None:
            res = command
            self.send_notification(f"Running last command: ({command})")
        else:
            res = self.send_prompt("cmd: ", self.command_history)

        if not res.startswith("!"):
            res, *args = res.split(" ")
            arg = " ".join(args)

        if res == "h" or res == "help":
            message = r"""
## Editor Documentation

A modal terminal editor built on curses with a command-driven,
event-based architecture and chunked text storage.

Includes syntax highlighting, multi-buffer management,
registers and markers, undo/redo history, Git integration,
async LSP support, subprocess execution, and HTTP requests.

## Key Bindings

## Arrow & Basic Movement

| Shortcut       | Action                              |
| -------------- | ----------------------------------- |
| **Right**      | Move cursor right                   |
| **Left**       | Move cursor left                    |
| **Up**         | Move cursor up                      |
| **Down**       | Move cursor down                    |
| **PageUp**     | Page up                             |
| **PageDown**   | Page down                           |
| **Ctrl+Right** | Jump right (word/semantic move)     |
| **Ctrl+Left**  | Jump left (word/semantic move)      |
| **Ctrl+Up**    | Scroll / move up (mode dependent)   |
| **Ctrl+Down**  | Scroll / move down (mode dependent) |

---

## Vim-Style Normal Mode Navigation

| Shortcut  | Action                           |
| --------- | -------------------------------- |
| **h**     | Move left                        |
| **j**     | Move down                        |
| **k**     | Move up                          |
| **l**     | Move right                       |
| **0**     | Jump to start of line            |
| **$**     | Jump to end of line              |
| **w / W** | Move forward by word             |
| **b / B** | Move backward by word            |
| **e / E** | Move to end of word              |
| **f / F** | Find character forward/backward  |
| **g**     | Go command prefix                |
| **G**     | Go to bottom                     |
| **H**     | Jump to top of visible window    |
| **L**     | Jump to bottom of visible window |
| **%**     | Jump to matching bracket         |

---

## Insert & Editing (Normal Mode)

| Shortcut | Action                    |
| -------- | ------------------------- |
| **i**    | Enter insert mode         |
| **a**    | Append after cursor       |
| **A**    | Append at end of line     |
| **o**    | Insert new line below     |
| **O**    | Insert new line above     |
| **x**    | Delete character          |
| **d**    | Delete (operator)         |
| **c**    | Change (operator)         |
| **y**    | Yank (copy)               |
| **p**    | Paste after               |
| **P**    | Paste before              |
| **u**    | Undo                      |
| **U**    | Undo line / extended undo |
| **J**    | Join lines                |
| **>**    | Indent right              |
| **<**    | Indent left               |

---

## Search & Repeat

| Shortcut | Action                   |
| -------- | ------------------------ |
| **/**    | Search forward           |
| **n**    | Next match               |
| **N**    | Previous match           |
| *****    | Search word under cursor |

---

## Marks & Registers

| Shortcut | Action                          |
| -------- | ------------------------------- |
| **m**    | Set marker                      |
| **'**    | Jump to marker (linewise)       |
| **`**    | Jump to marker (exact position) |
| **@**    | Execute macro                   |
| **q**    | Start/stop macro recording      |

---

## LSP / Diagnostics (Normal Mode)

| Shortcut   | Action                      |
| ---------- | --------------------------- |
| **K**      | Show LSP hover / definition |
| **;**      | LSP-related navigation      |
| **Ctrl+D** | Diagnostics-related action  |

(Exact behavior depends on your handler implementations.)

---

## Alt-Based Commands

| Shortcut              | Action                      |
| --------------------- | --------------------------- |
| **Alt+;**             | Toggle selection mode       |
| **Alt+Right / Alt+.** | Indent right                |
| **Alt+Left / Alt+,**  | Indent left                 |
| **Alt+/**             | Alternative slash action    |
| **Alt+h / Alt+l**     | Alternative horizontal move |
| **Alt+j / Alt+k**     | Move lines or cursor        |
| **Alt+Up / Alt+Down** | Scroll view                 |
| **Alt+9 / Alt+0**     | Jump line start/end         |
| **Alt+w**             | File search                 |
| **Alt+r**             | Custom action               |
| **Alt+i / Alt+o**     | Punctuation jump            |
| **Alt+[**             | Bracket-related action      |
| **Alt+'**             | Quote-related action        |

---

## Shift Selection

| Shortcut             | Action                   |
| -------------------- | ------------------------ |
| **Shift+Right**      | Expand selection right   |
| **Shift+Left**       | Expand selection left    |
| **Shift+Up**         | Expand selection up      |
| **Shift+Down**       | Expand selection down    |
| **Ctrl+Shift+Right** | Expand selection by word |
| **Ctrl+Shift+Left**  | Expand selection by word |

---

## Misc

| Shortcut              | Action                    |
| --------------------- | ------------------------- |
| **Ctrl+A**            | Select all                |
| **Ctrl+P**            | Previous buffer           |
| **Ctrl+X**            | Cut / special action      |
| **Ctrl+O**            | Open file                 |
| **Ctrl+I**            | Jump forward in jump list |
| **Q**                 | Quit variant              |
| **PageUp / PageDown** | Scroll                    |

## Commands

### Buffer Actions

| Command                           | Description         |
| --------------------------------- | ------------------- |
| `h` / `help`                      | Show help           |
| `q`                               | Exit editor         |
| `w`                               | Save current buffer |
| `ls`                              | List open buffers   |
| `open`                            | Open a file         |
| `bufnew`                          | Create new buffer   |
| `nbuf` / `nextbuf` / `next` / `n` | Next buffer         |
| `pbuf` / `prevbuf` / `prev` / `p` | Previous buffer     |
| `delbuf` / `d`                    | Delete buffer       |
| `ff`                              | File search         |
| `ffr`                             | New file search     |
| `fb`                              | Buffer picker       |
| `ex`                              | File explorer       |

---

### UI & Behavior

| Command         | Description          |
| --------------- | -------------------- |
| `themes`        | Change editor theme  |
| `ln`            | Toggle line numbers  |
| `gch`           | Toggle Git highlight |
| `scrolloff <n>` | Set scroll offset    |

---

### Markers

| Command        | Description                   |
| -------------- | ----------------------------- |
| `m` / `marker` | Add local/global marker       |
| `pm`           | Pick marker                   |
| `dm`           | Delete markers in this buffer |
| `dgm`          | Delete global markers         |
| `dpm`          | Delete specific marker        |
| `dam`          | Delete all markers            |

---

### Text Utilities

| Command                          | Description        |
| -------------------------------- | ------------------ |
| `clear_registers`                | Reset registers    |
| `reset_h_matches`                | Reset highlighting |
| `replace`                        | Replace text       |
| `comment`                        | Toggle comment     |
| `upper` / `lower` / `capitalize` | Change case        |
| `filetype <type>`                | Set syntax mode    |

---

## Utilities

| Command                          | Description                                                       |
|----------------------------------|-------------------------------------------------------------------|
| `align`                          | Align text by a delimiter (e.g. `=`, `:`, `,`, `|`)               |
| `column_edit`                    | Insert, replace, or delete text within column ranges per line     |
| `date`                           | Copy date                                                         |
| `datetime`                       | Copy current date & time                                          |
| `file_path`                      | Copy current file path                                            |
| `json_format`                    | Format JSON in selection or entire file                           |
| `number_lines`                   | Add line numbers to each line                                     |
| `rejoin`                         | Split and rejoin selection or entire file using a delimiter       |
| `remove_empty_lines`             | Remove blank or whitespace-only lines                             |
| `reverse_lines`                  | Reverse the order of lines                                        |
| `shuffle_lines`                  | Randomly shuffle lines                                            |
| `slugify`                        | Convert text to URL-friendly slug format                          |
| `sort` / `sort_r`                | Sort selection or entire file by lines (normal or reverse)        |
| `trim` / `trim_l` / `trim_r`     | Trim whitespace (both, left, or right) per line                   |
| `unique_lines` / `dedup`         | Remove duplicate lines (keep first occurrence)                    |
| `uuid`                           | Copy random UUID                                                  |
| `wrap`                           | Wrap text to a specified width                                    |
| `json_format`                    | formats json with indentation                                     |

---

## Git Commands

| Command          | Description                           |
| ---------------- | ------------------------------------- |
| `git_status`     | Show Git status                       |
| `git_diff`       | Show diff                             |
| `git_commit_all` | Commit all                            |
| `git_blame`      | Show blame                            |
| `git_log`        | Show history                          |
| `git_refresh`    | Refresh state                         |
| `git_hunk`       | Show previous version of changed code |

---

## LSP Commands

| Command                         | Description                        |
| ------------------------------- | ---------------------------------- |
| `lsp_diagnostics`               | Show buffer diagnostics            |
| `lsp_hover`                     | Show hover info                    |
| `lsp_definition`                | Go to definition                   |
| `lsp_refresh`                   | Restart LSP for buffer             |
| `lsp_references`                | References picker                  |
| `lsp_line_diagnostics`          | Show diagnostics for current line  |
| `lsp_clear_diagnostics`         | Clear diagnostics                  |
| `lsp_clear_line_diag` / `clrld` | Clear diagnostics for current line |

---

## AI Commands

| Command             | Description                               |
| ------------------- | ----------------------------------------- |
| `ai`                | Send a custom instruction to the AI       |
| `ai_gen`            | Generate code at the cursor               |
| `ai_review`         | Review Git diff for issues                |
| `ai_commit_message` | Generate a commit message from Git diff   |
| `ai_get`            | Retrieve AI result at the cursor          |
| `ai_show`           | Show AI completion picker                 |
| `ai_remove`         | Cancel/remove AI completion at the cursor |
| `change_ai_model`   | Change the active AI model                |

---

## HTTP Request Execution

Select a block and run:

| Command                     | Description                        |
| --------------------------- | ---------------------------------- |
| `req`                       | Make http request                  |

### Request Format

```
<HTTP_METHOD> <URL>
<Header>: <Value>
<Header>: <Value>

<Optional Body>
```

### Examples

#### GET:

```
GET https://jsonplaceholder.typicode.com/todos/1
Accept: application/json
```

#### POST:

```
POST https://jsonplaceholder.typicode.com/posts
Content-Type: application/json

{
    "title": "Hello world",
    "body": "Testing request from editor",
    "userId": 1
}
```


## Regex Replacement

Perform regex-based find and replace in the current buffer.

| Command   | Description                    |
| --------- | ------------------------------ |
| `replace` | Run a regex search and replace |

---

## Capture Groups

Parentheses create **capture groups** that can be reused in the replacement.

| Syntax | Meaning      |
| ------ | ------------ |
| `\0`   | Entire match |
| `\1`   | First group  |
| `\2`   | Second group |
| `\3`   | Third group  |

Example

Find

```
(\w+)\s+(\w+)
```

Replace

```
\2 \1
```

Result

```
hello world → world hello
```

---

## Named Capture Groups

Groups can also be named.

```
(?P<name>pattern)
```

Named groups are referenced in the replacement using:

```
\g<name>
```

Example

Find

```
(?P<first>\w+)\s+(?P<last>\w+)
```

Replace

```
\g<last> \g<first>
```

Result

```
john doe → doe john
```

---

## Case Transformations

The replacement string supports case modifiers.

| Syntax | Effect                   |
| ------ | ------------------------ |
| `\U`   | Uppercase until `\E`     |
| `\L`   | Lowercase until `\E`     |
| `\u`   | Uppercase next character |
| `\l`   | Lowercase next character |
| `\E`   | End transformation       |

Example

Find

```
select
```

Replace

```
\U\0\E
```

Result

```
select → SELECT
```

---

## Word Boundaries

`\b` matches the boundary between a word and a non-word character.

Example

Find

```
\bselect\b
```

Matches

```
select
```

Does not match

```
selected
```

---

## Example: SQL Keyword Formatting

Find

```
\b(select|from|where|join|group\s+by|order\s+by)\b
```

Replace

```
\U\0\E
```

Result

```
select name from users where id = 1
↓
SELECT name FROM users WHERE id = 1
```
"""

            help_buffer_name = "__help__"

            self.open_aux_buffer(message, help_buffer_name, lexer=MarkdownLexer())

            return None

        elif res == "q":
            self.close_buffer()
            return None

        elif res == "qa":
            self.confirm_quit()

        elif res == "w":
            self.save_file()

        elif res == "open":
            self.end_selection()
            self.open_buffer_prompt()

        elif res == "ls":
            message = "Choose Buffer:\n" + "\n".join(
                f"#{i + 1} - {"*" if b.modified else " "}{b.file_name}{" <-" if i == self.current_buffer else ""}"
                for i, b in enumerate(self.buffers)
            )
            res = self.send_multiline_prompt(message, "Choose buffer or press enter:")
            if res and res.isdigit():
                res_int = int(res) - 1

                if 0 <= res_int < len(self.buffers):
                    self.current_buffer = res_int
                    self.send_notification(
                        f"Switched to buffer #{self.current_buffer + 1}", 200
                    )

        elif res in ("cancel_tasks", "ctasks"):
            message = "Tasks Pending:\n" + "\n".join(
                f"#{i + 1} - {task["task_id"]}: {task["command"]}"
                for i, task in enumerate(self.task_running)
            )

            res = self.send_multiline_prompt(
                message, "Choose the task to cancel or press enter:"
            )

            if res and res.isdigit():
                res_int = int(res) - 1

                if 0 <= res_int < len(self.task_running):
                    task = self.task_running[res_int]

                    try:
                        task["task"].cancel()

                        self.send_notification(
                            f"Task {task["task_id"]} cancelled successfully.", 200
                        )

                    except Exception as e:
                        self.send_notification(
                            f"Could not cancel the task ({task["task_id"]}): {e}\n{traceback.format_exc}"
                        )

        elif res == "bufnew":
            self.new_buffer_count += 1
            self.buffers.append(
                Buffer(
                    f"Untitled-{self.new_buffer_count}",
                    new_buffer_untitled=True,
                    temp_dir=self.temp_dir,
                )
            )
            self.current_buffer = len(self.buffers) - 1
            self.send_notification("New buffer created")

        elif res == "nbuf" or res == "nextbuf" or res == "next" or res == "n":
            self.go_next_buffer()
            self.send_notification(f"Switched to buffer #{self.current_buffer + 1}", 10)

        elif res == "pbuf" or res == "prevbuf" or res == "prev" or res == "p":
            self.go_prev_buffer()
            self.send_notification(f"Switched to buffer #{self.current_buffer + 1}", 10)

        elif res == "delbuf" or res == "deletebuf" or res == "del" or res == "d":
            self.close_buffer()
            self.send_notification("Buffer deleted")

        elif res == "ff":
            self.show_file_picker()

        elif res == "ffr":
            self.fuzzy_changed = True
            self.show_file_picker()

        elif res == "fb":
            self.show_buffer_picker()

        elif res in ("themes", "th"):
            self.show_theme_picker()

        elif res == "ex":
            file_explorer.show_explorer(editor=self)

        elif res in ("ln", "gch"):
            self.toggle_line_number(option=res)
            save_static_config()

        elif res == "brkm":
            self.toggle_bracket_match()
            save_static_config()

        elif res == "change_ai_model":
            self.show_ai_model_picker()
            save_static_config()

        elif res == "commands":
            self.show_command_picker()

        elif res == "scrolloff":
            try:
                if arg:
                    scrolloff_value = int(arg)
                else:
                    scrolloff_value = int(self.send_prompt("Scrolloff: "))
            except Exception:
                scrolloff_value = 0

            config.STATIC_CONFIG["scrolloff"] = scrolloff_value
            save_static_config()

        elif res in ("m", "marker"):
            self.set_marker()

        elif res == ("pickmarker", "pm"):
            self.end_selection()
            self.pick_markers()

        elif res == "dm":
            buffer.markers.clear()

        elif res == "dgm":
            self.global_markers.clear()

        elif res == "dpm":
            marker = self.send_prompt("Marker to delete: ")

            if not marker:
                return None

            marker_found = False

            if marker in self.global_markers:
                self.global_markers.pop(marker)
                marker_found = True

            elif marker in buffer.markers:
                buffer.markers.pop(marker)
                marker_found = True

            if marker_found:
                self.send_notification("Marker deleted.")
            else:
                self.send_notification("Marker not found.")

        elif res == "dam":
            for buffer in self.buffers:
                buffer.markers.clear()

            self.global_markers.clear()

        elif res == "lexing_info":
            buffer = self.get_current_buffer()
            line = buffer.lines[buffer.cursor_y]
            info = json.dumps(
                {
                    "text": line,
                    "state": line.state,
                    "tokens": line.tokens,
                    "_width_cache": line._width_cache,
                    "_bracket_cache": line._bracket_cache,
                },
                indent=4,
            )
            open_file_in_less_mode(
                window=self.stdscr, file_handle=StringIO(info), editor=self
            )

            if info:
                if self.send_prompt_confirm("open in new buffer?:"):
                    self.end_selection()
                    self.open_untitled_buffer(info)

        elif res in ("jump_list", "jl"):
            self.show_jump_picker()

        elif res == "clear_registers":
            self.registers.clear()

        elif res == "replace":
            self.end_selection()
            self.interactive_replace_in_buffer()
            self.end_selection()

        elif res == "comment":
            if arg is None:
                res = self.send_prompt(
                    "Comment prefix (enter for default): ",
                )
            else:
                res = arg

            prefix = res if res else None

            self.toggle_comment_selection(prefix=prefix)

        elif res == "filetype":
            self.change_lexer(arg)

        elif res == "filepath":
            abs_path = self.send_prompt_confirm("Get absolute path? y/n")

            if (action := buf_actions.get_filepath(buffer, abs_path)) is not None:
                self.apply_action_to_buffer(action)

        elif res == "datetime":
            for ch in str(datetime.now()):
                self.insert_char(ch, disable_autocomplete=True)

        elif res == "date":
            for ch in str(datetime.now().date()):
                self.insert_char(ch, disable_autocomplete=True)

        elif res == "uuid":
            for ch in str(uuid.uuid4()):
                self.insert_char(ch, disable_autocomplete=True)

        elif res == "record_macro":
            self.record_macro()

        elif res == "exec_macro":
            self.exec_macro()

        elif res == "req":

            def action_function(text) -> None:
                if self.tg is None:
                    return None

                for block in split_requests(text):
                    response = None
                    try:
                        method, url, headers, body = parse_request_block(block)

                        task_id = str(uuid.uuid4())

                        task = self.tg.create_task(
                            make_request_with_cancel_async(
                                method, url, headers, body, task_id
                            )
                        )

                        self.task_running.append(
                            {
                                "task": task,
                                "type": "HTTP",
                                "task_id": task_id,
                                "method": method,
                                "url": url,
                                "headers": headers,
                                "body": body,
                            }
                        )

                    except Exception as e:
                        self.send_multiline_notification(
                            f"Request failed: {e}\n{traceback.format_exc()}", 0
                        )

            self.apply_action_on_selection_or_file(
                action_function=action_function, action_title="HTTP Requests"
            )

        elif res == "json_format":
            if arg is None:
                indent = 2
            else:
                try:
                    indent = int(arg)
                except Exception:
                    indent = 2

            self.apply_action_on_selection_or_file(
                action_function=lambda text: buf_actions.json_format(
                    self.get_current_buffer(), text, indent
                ),
                action_title="JSON format",
            )

        elif res == "ai":
            try:
                prompt = self.send_prompt("AI instruction:")

                if not prompt:
                    return None

                code_example = None

                if self.selection_start is not None:
                    code_example = "\n".join(self.get_selected_text())

                    code_example = code_example[:12000]

                    prompt = (
                        f"{prompt}\n\n"
                        f"Here is the related code:\n"
                        f"```\n{code_example}\n```"
                    )

                    self.end_selection()

                job_id = self.ai_completion_manager.submit(prompt=prompt, prompt_type=2)

                y, x = self.get_current_buffer().get_cursor_position()

                buffer.ai_completions.append(
                    Diagnostic(
                        line=y,
                        char=x,
                        code=job_id,
                        message="PENDING",
                        severity=4,
                    )
                )

            except Exception as e:
                self.send_multiline_notification(
                    f"AI request failed: {e}\n{traceback.format_exc()}", 0
                )

        elif res == "ai_gen":

            try:
                buffer = self.get_current_buffer()

                MAX_TOTAL_LINES = 10000

                cursor_y = buffer.cursor_y
                cursor_x = buffer.cursor_x
                total_lines = len(buffer.lines)

                half_window = MAX_TOTAL_LINES // 2

                start_line = max(0, cursor_y - half_window)
                end_line = min(total_lines, start_line + MAX_TOTAL_LINES)

                start_line = max(0, end_line - MAX_TOTAL_LINES)

                visible_lines = buffer.lines[start_line:end_line]

                relative_cursor_y = cursor_y - start_line

                current_line = visible_lines[relative_cursor_y]
                current_line_before_cursor = current_line[:cursor_x]
                current_line_after_cursor = current_line[cursor_x:]

                before_lines = visible_lines[:relative_cursor_y]
                after_lines = visible_lines[relative_cursor_y + 1 :]

                before_cursor = "\n".join(before_lines + [current_line_before_cursor])
                after_cursor = "\n".join([current_line_after_cursor] + after_lines)

                prompt = textwrap.dedent(f"""\
                Complete the code at the marker.

                Return ONLY the missing code.
                No explanations.
                No repetition.

                {before_cursor}
                {current_line_before_cursor}>>> COMPLETE HERE <<<{current_line_after_cursor}
                {after_cursor}
                """)

                job_id = self.ai_completion_manager.submit(prompt=prompt, prompt_type=1)

                buffer.ai_completions.append(
                    Diagnostic(
                        line=buffer.cursor_y,
                        char=buffer.cursor_x,
                        code=job_id,
                        message="PENDING",
                        severity=4,
                    )
                )

            except Exception as e:
                self.send_multiline_notification(
                    f"Completion failed: {e}\n{traceback.format_exc()}", 0
                )

        elif res == "ai_review":
            try:
                buffer = self.get_current_buffer()

                diff_branch = self.send_prompt_confirm("diff branch?")
                diff_commited = False

                if diff_branch:
                    branch = self.send_multiline_prompt(
                        multiline_message=str(git_utils.git_branches()),
                        prompt_message="choose branch: ",
                    )

                    if not branch:
                        self.send_notification("No branch seleced.")
                        return None
                else:
                    diff_commited = self.send_prompt_confirm("diff commited?")
                    branch = None

                match (buffer.lexer.name if buffer.lexer else "Text").lower():
                    case "mcs":
                        exclude_patterns = ["*Designer.cs", "bin/*", "obj/*"]
                    case _:
                        exclude_patterns = []

                if branch:
                    diff_text = git_utils.get_diff(
                        compare_branch=branch, exclude_patterns=exclude_patterns
                    )
                else:
                    diff_text = git_utils.get_diff(
                        staged=diff_commited, exclude_patterns=exclude_patterns
                    )

                if not diff_text:
                    self.send_notification("No diff output.")
                    return None

                prompt = textwrap.dedent(f"""\
                You are an automated code review engine.

                Review ONLY the provided git diff.

                Output STRICT JSON only.
                Do NOT include markdown.
                Do NOT include explanations outside JSON.

                If no issues are found, return:

                {{
                  "summary": "CLEAN",
                  "severity_max": 0,
                  "issues": []
                }}

                Severity levels:
                5 = Critical bug or security vulnerability
                4 = High-risk bug
                3 = Logic or performance issue
                2 = Minor issue
                1 = Style suggestion

                Each issue must follow this structure:

                {{
                  "file": "filename",
                  "line": 123,
                  "severity": 3,
                  "type": "bug|performance|security|style|other",
                  "title": "Short issue title",
                  "message": "Detailed explanation",
                  "suggestion": "Concrete fix suggestion"
                }}

                Return only JSON.

                Here is the diff:

                {diff_text}
                """)

                job_id = self.ai_completion_manager.submit(prompt=prompt, prompt_type=3)

                buffer.ai_completions.append(
                    Diagnostic(
                        line=buffer.cursor_y,
                        char=buffer.cursor_x,
                        code=job_id,
                        message="PENDING",
                        severity=4,
                    )
                )

            except Exception as e:
                self.send_multiline_notification(
                    f"Review failed: {e}\n{traceback.format_exc()}", 0
                )

        elif res == "ai_commit_message":
            try:
                buffer = self.get_current_buffer()

                diff_branch = self.send_prompt_confirm("diff branch?")
                diff_commited = False

                if diff_branch:
                    branch = self.send_multiline_prompt(
                        multiline_message=str(git_utils.git_branches()),
                        prompt_message="choose branch: ",
                    )

                    if not branch:
                        self.send_notification("No branch seleced.")
                        return None
                else:
                    diff_commited = self.send_prompt_confirm("diff commited?")
                    branch = None

                match (buffer.lexer.name if buffer.lexer else "Text").lower():
                    case "mcs":
                        exclude_patterns = ["*Designer.cs", "bin/*", "obj/*"]
                    case _:
                        exclude_patterns = []

                if branch:
                    diff_text = git_utils.get_diff(
                        compare_branch=branch, exclude_patterns=exclude_patterns
                    )
                else:
                    diff_text = git_utils.get_diff(
                        staged=diff_commited, exclude_patterns=exclude_patterns
                    )

                if not diff_text:
                    self.send_notification("No diff output.")
                    return None

                prompt = textwrap.dedent(f"""\
                Write a detailed Git commit message based on the following diff.

                Structure:
                1. A short summary line (conventional commit style if applicable).
                2. A blank line.
                3. A detailed explanation describing:
                   - What changed
                   - Why it changed
                   - Important implementation details
                   - Possible side effects or impact
                   - Any breaking changes

                Be precise and technical.
                Do not repeat the entire diff.
                Do not use markdown formatting.

                Diff:
                {diff_text}
                """)

                job_id = self.ai_completion_manager.submit(prompt=prompt, prompt_type=4)

                buffer.ai_completions.append(
                    Diagnostic(
                        line=buffer.cursor_y,
                        char=buffer.cursor_x,
                        code=job_id,
                        message="PENDING",
                        severity=4,
                    )
                )

            except Exception as e:
                self.send_multiline_notification(
                    f"Review failed: {e}\n{traceback.format_exc()}", 0
                )

        elif res == "ai_get":
            try:
                buffer = self.get_current_buffer()

                codes_consumed = []

                for i, c in enumerate(buffer.ai_completions):
                    if c.line == buffer.cursor_y and c.message == "COMPLETED":

                        output = self.ai_completion_manager.get_result(c.code)

                        if output:
                            output = output.strip("\n")

                            open_file_in_less_mode(
                                window=self.stdscr,
                                file_handle=StringIO(output),
                                editor=self,
                            )

                            if self.send_prompt_confirm("insert completion?:"):
                                self.insert_char(output, disable_autocomplete=True)
                                codes_consumed.append(i)

                            elif self.send_prompt_confirm("open in new buffer?:"):
                                self.open_untitled_buffer(output, lexer=MarkdownLexer())
                                codes_consumed.append(i)

                    elif c.message == "CANCELED":
                        codes_consumed.append(i)

                for i in sorted(codes_consumed, reverse=True):
                    buffer.ai_completions.pop(i)

            except Exception as e:
                self.send_multiline_notification(
                    f"Completion failed: {e}\n{traceback.format_exc()}", 0
                )

        elif res == "ai_show":
            try:
                self.show_ai_completion_picker()

            except Exception as e:
                self.send_multiline_notification(
                    f"Completion failed: {e}\n{traceback.format_exc()}", 0
                )

        elif res == "ai_remove":
            try:
                buffer = self.get_current_buffer()

                codes_consumed = []

                for i, c in enumerate(buffer.ai_completions):
                    if c.line == buffer.cursor_y:
                        self.ai_completion_manager.cancel(c.code)
                        codes_consumed.append(i)

                for i in sorted(codes_consumed, reverse=True):
                    buffer.ai_completions.pop(i)

            except Exception as e:
                self.send_multiline_notification(
                    f"Completion failed: {e}\n{traceback.format_exc()}", 0
                )

        elif res == "rejoin":
            split_by = self.send_prompt("split by (default: newline):")
            if not split_by:
                split_by = "\n"

            join_by = buf_actions.parse_basic_escapes(
                self.send_prompt("join by (default: newline):")
            )
            if not join_by:
                join_by = "\n"

            self.apply_action_on_selection_or_file(
                action_function=lambda text: buf_actions.rejoin(
                    self.get_current_buffer(), text, split_by, join_by
                ),
                action_title="Rejoin",
            )

        elif res == "align":
            separator = self.send_prompt("align by (default: =):")
            if not separator:
                separator = "="

            add_spaces = self.send_prompt(
                "Add spaces around separator? (y/n, default: y):"
            )

            _add_spaces = (
                False if add_spaces and add_spaces.lower().startswith("n") else True
            )

            self.apply_action_on_selection_or_file(
                action_function=lambda text: buf_actions.align(
                    self.get_current_buffer(), text, separator, _add_spaces
                ),
                action_title="Align Columns",
            )

        elif res in ("unique_lines", "dedup"):

            self.apply_action_on_selection_or_file(
                action_function=lambda text: buf_actions.unique_lines(
                    self.get_current_buffer(), text
                ),
                action_title="Remove Duplicate Lines",
            )

        elif res == "reverse_lines":

            self.apply_action_on_selection_or_file(
                action_function=lambda text: buf_actions.reverse_lines(
                    self.get_current_buffer(), text
                ),
                action_title="Reverse Lines",
            )

        elif res in ("trim", "trim_l", "trim_r"):

            self.apply_action_on_selection_or_file(
                action_function=lambda text: buf_actions.trim_lines(
                    self.get_current_buffer(), text, res
                ),
                action_title=f"Trim ({res})",
            )

        elif res == "number_lines":
            _start = self.send_prompt("start from (default 1):")
            start = int(_start) if _start and _start.isdigit() else 1

            separator = self.send_prompt("separator (default '.'):")
            if not separator:
                separator = "."

            _pad = self.send_prompt("zero pad width (optional):")
            pad = int(_pad) if _pad and _pad.isdigit() else 0

            skip_empty = self.send_prompt("skip empty lines? (y/N):").lower() == "y"

            self.apply_action_on_selection_or_file(
                action_function=lambda text: buf_actions.number_lines(
                    self.get_current_buffer(), text, start, separator, pad, skip_empty
                ),
                action_title="Number Lines (Advanced)",
            )

        elif res == "remove_empty_lines":

            self.apply_action_on_selection_or_file(
                action_function=lambda text: buf_actions.remove_empty_lines(
                    self.get_current_buffer(), text
                ),
                action_title="Remove Empty Lines",
            )

        elif res == "wrap":
            width_input = self.send_prompt("wrap width (default 80):")
            width = int(width_input) if width_input and width_input.isdigit() else 80

            break_long_words = (
                self.send_prompt("break long words? (y/N):").lower() == "y"
            )

            self.apply_action_on_selection_or_file(
                action_function=lambda text: buf_actions.wrap(
                    self.get_current_buffer(), text, width, break_long_words
                ),
                action_title="Wrap Lines (Advanced)",
            )

        elif res == "shuffle_lines":

            self.apply_action_on_selection_or_file(
                action_function=lambda text: buf_actions.shuffle_lines(
                    self.get_current_buffer(), text
                ),
                action_title="Shuffle Lines",
            )

        elif res == "slugify":

            self.apply_action_on_selection_or_file(
                action_function=lambda text: buf_actions.slugify(
                    self.get_current_buffer(), text
                ),
                action_title="Slugify",
            )

        elif res == "column_edit":
            if self.selection_start is not None:
                _selection_start = self.selection_start
                mode = (
                    (
                        self.send_prompt(
                            "mode: insert / replace / delete (default insert):"
                        )
                        or "insert"
                    )
                    .strip()
                    .lower()
                )

                if mode not in ("insert", "replace", "delete"):
                    mode = "insert"

                start_col = end_col = 0

                if mode == "insert":
                    start_col = buf_actions._to_int(self.send_prompt("column:"), 0)

                elif mode in ("replace", "delete"):
                    start_col = buf_actions._to_int(
                        self.send_prompt("start column:"), 0
                    )
                    end_col = buf_actions._to_int(
                        self.send_prompt("end column:"), start_col
                    )

                insert_text = ""

                if mode != "delete":
                    insert_text = self.send_prompt("text to insert:") or ""

                self.apply_action_on_selection_or_file(
                    action_function=lambda text: buf_actions.column_edit(
                        self.get_current_buffer(),
                        text,
                        mode,
                        start_col,
                        end_col,
                        insert_text,
                        _selection_start,
                    ),
                    action_title="Column Edit (Per Line)",
                )

        elif res in ("sort", "sort_r"):
            reverse = res == "sort_r"

            self.apply_action_on_selection_or_file(
                action_function=lambda text: buf_actions.sort_lines(
                    self.get_current_buffer(), text, reverse
                ),
                action_title="Sort",
            )

        elif res in ("lazygit", "gg"):
            if shutil.which("lazygit"):
                from denary import external_tui

                external_tui.run_external_tui(editor=self, command=["lazygit"])

                if config.STATIC_CONFIG.get("gch", False):
                    buffer.git_changes = git_utils.get_file_changes(buffer.file_name)
            else:
                self.send_notification("Could not find lazygit executable.")

        elif res == "fzf":
            selected = self.fzf_tui_search()

            if selected:
                root = os.getcwd()

                full_path = os.path.abspath(os.path.join(root, selected))
                cwd = os.getcwd()

                rel = os.path.relpath(full_path, cwd)

                for buffer_index, buf in enumerate(self.buffers):
                    if buf.file_name and buf.file_name == rel:
                        self.current_buffer = buffer_index
                        self.send_notification(f"Switched to buffer: {selected}")
                        break
                else:
                    self.open_buffer(rel)
                    self.send_notification(f"Opened file: {selected}")

        elif res == "eval":
            try:
                if self.selection_start is not None:
                    code = "\n".join(self.get_selected_text())
                else:
                    code = self.send_prompt("code:", history=self.eval_history)

                self.end_selection()

                if code:
                    self.eval_history.append(code)
                    _output = self.run_code_with_eval(code)

                    if _output is None:
                        return None

                    result, stdout = _output

                    output = "\n" + "\n".join(str(i) for i in _output) + "\n"

                    open_file_in_less_mode(
                        window=self.stdscr, file_handle=StringIO(output), editor=self
                    )

                    if output:
                        size = len(output)

                        if self.send_prompt_confirm(
                            f"Do you want to open the output ({size} bytes) in a new buffer?"
                        ):
                            self.open_untitled_buffer(output)

                        elif self.send_prompt_confirm(
                            f"Do you want to paste the output ({size} bytes) into the current buffer?"
                        ):
                            self.insert_char(output, disable_autocomplete=True)

            except Exception as e:
                self.send_multiline_notification(
                    f"Eval failed: {e} \n{traceback.format_exc()}", 0
                )

        elif res == "paste_sys":
            self.paste_from_system_clipboard()

        # run command like vim
        elif res.startswith("!"):

            if res in self.command_history:
                self.command_history.remove(res)

            self.command_history.append(res)

            command = res[1:].strip()
            CEP = False
            if command:
                try:
                    original_command = command
                    if "$CEP" in command:
                        CEP = True
                        command = command.replace("$CEP", "").strip()

                    if "$SEL" in command:
                        selected_text = ""

                        if self.selection_start is not None:
                            selected_text = "\n".join(self.get_selected_text())

                        command = command.replace("$SEL", selected_text)

                    if "$SBUF" in command:
                        if self.selection_start is not None:
                            selected_text = "\n".join(self.get_selected_text())

                            command = command.replace("$SBUF", selected_text)
                        else:
                            command = command.replace(
                                "$SBUF", "\n".join(buffer.get_lines())
                            )

                    command = command.replace("$PWD", str(Path(".").absolute()))
                    command = command.replace("$HOME", str(Path.home()))
                    command = command.replace("$BUF", "\n".join(buffer.get_lines()))

                    if buffer.file_name:
                        command = command.replace("%f", buffer.file_name)
                        command = command.replace(
                            "%F", str(Path(buffer.file_name).absolute())
                        )

                    if self.tg is not None:
                        task_id = str(uuid.uuid4())
                        _task = self.tg.create_task(
                            run_with_cancel_async(command=command, task_id=task_id)
                        )
                        self.task_running.append(
                            {
                                "task": _task,
                                "type": "SUBPROCESS",
                                "command": command,
                                "cep": CEP,
                                "task_id": task_id,
                                "status": "PENDING",
                            }
                        )

                except Exception as e:
                    self.send_multiline_notification(
                        f"Command failed: {e} \n{traceback.format_exc()}", 0
                    )

                    with open("errors.pytb", "a") as f:
                        f.write(f"\n\n{e}\n{traceback.format_exc()}\n")

            else:
                self.send_notification("No command provided.")

            self.end_selection()

            return None

        elif res in (
            "lsp_diagnostics",
            "lsp_hover",
            "lsp_definition",
            "lsp_references",
            "lsp_refresh",
            "lsp_code_action",
            "lsp_line_diagnostics",
            "lsp_clear_diagnostics",
            "lsp_clear_line_diag",
            "clrld",
        ):

            if res == "lsp_hover":
                self.lsp_hover()

            elif res == "lsp_definition":
                self.lsp_definition()

            elif res == "lsp_diagnostics":
                diags = getattr(buffer, "diagnostics", [])
                if diags:
                    self.show_all_lsp_diagnostics()
                    if self.send_prompt_confirm(
                        "Do you want to open the output in a separate aux buffer?"
                    ):
                        self.open_aux_buffer(
                            json.dumps(diags, indent=4), "__lsp_diagnostics__"
                        )

            elif res == "lsp_refresh":
                self.lsp_refresh()

            elif res == "lsp_references":
                self.lsp_references()

            elif res == "lsp_code_action":
                self.lsp_code_action()

            elif res == "lsp_line_diagnostics":
                self.show_line_diagnostics()

            elif res == "lsp_clear_diagnostics":
                buffer.diagnostics.clear()

            elif res in ("lsp_clear_line_diag", "clrld"):
                buffer.diagnostics = [
                    d for d in buffer.diagnostics if d.line != buffer.cursor_y
                ]

        elif res in (
            "git_status",
            "git_diff",
            "git_hunk",
            "git_commit_all",
            "git_blame",
            "git_log",
            "git_refresh",
        ):
            if not git_utils.is_inside_git_repo():
                self.send_notification("Not inside a Git repository.")
                return None

            if res == "git_status":
                status = git_utils.get_status()
                if status:
                    open_file_in_less_mode(
                        window=self.stdscr, file_handle=StringIO(status), editor=self
                    )

            elif res == "git_diff":

                file_path = None

                if arg is not None:
                    file_path = arg

                else:
                    if not buffer.file_name and not buffer.is_aux_buffer:
                        self.send_notification("No file to show diff for.")
                        return None

                    file_path = buffer.file_name

                diff = git_utils.get_diff(file_path)

                if diff:
                    self.open_aux_buffer(diff, "__git_diff__", lexer=DiffLexer())
                else:
                    self.send_notification("No changes to show.")

            elif res == "git_commit_all":
                message = self.send_prompt("Commit message: ")
                if message:
                    try:
                        git_utils.commit_all(message)

                        if config.STATIC_CONFIG.get("gch", False):
                            buffer.git_changes = git_utils.get_file_changes(
                                buffer.file_name
                            )
                        self.send_notification("Changes committed successfully.")
                    except Exception as e:
                        self.send_notification(f"Error committing changes: {e}")
                else:
                    self.send_notification("Commit aborted.")
            elif res == "git_blame":
                if not buffer.file_name and not buffer.is_aux_buffer:
                    self.send_notification("No file to show blame for.")
                    return None
                try:
                    blame = git_utils.get_blame_line(
                        buffer.file_name, buffer.cursor_y + 1
                    )
                    if blame:
                        self.send_notification(f"Blame: {blame}", 0)

                except Exception as e:
                    self.send_notification(f"Error getting blame: {e}")
            elif res == "git_hunk":
                if not buffer.file_name and not buffer.is_aux_buffer:
                    self.send_notification("No file to show hunk for.")
                    return None

                try:
                    if buffer.file_name is not None and (
                        hunk := git_utils.find_previous_hunk_for_line(
                            buffer.file_name, buffer.cursor_y + 1
                        )
                    ):
                        lines = "\n".join(hunk["lines"])
                        open_file_in_less_mode(
                            window=self.stdscr,
                            file_handle=StringIO(
                                f"Hunk at line {buffer.cursor_y + 1}:\n{lines}"
                            ),
                            editor=self,
                        )
                    else:
                        self.send_notification("No hunk found at this line.")
                except Exception as e:
                    self.send_notification(f"Error getting hunk: {e}")

            elif res == "git_log":
                try:
                    log = git_utils.get_log()
                    open_file_in_less_mode(
                        window=self.stdscr, file_handle=StringIO(log), editor=self
                    )
                except Exception as e:
                    self.send_notification(f"Error getting log: {e}")
            elif res == "git_refresh":
                try:
                    if not buffer.file_name and not buffer.is_aux_buffer:
                        self.send_notification("No file to refresh.")
                        return None

                    if config.STATIC_CONFIG.get("gch", False):
                        buffer.git_changes = git_utils.get_file_changes(
                            buffer.file_name
                        )

                    self.send_notification("Buffer refreshed with Git changes.")
                except Exception as e:
                    self.send_notification(f"Error refreshing buffer: {e}")

        elif res in ("upper", "lower", "capitalize"):
            self.change_selection_case(mode=res)

        return None

    def get_key_mapping(
        self, key: int | str | None, stdscr: Optional[curses.window] = None
    ) -> int | str | None:
        return key_mappings.get_key_mapping(
            self.stdscr if stdscr is None else stdscr, key
        )

    def process_key(self, key: int | str | None) -> None:
        try:
            if self.debug:
                with open("seq.txt", "a", encoding="utf-8") as f:
                    f.write(f"{key}\n")

            if (
                self.current_macro_playing_index is not None
                and self.current_macro_playing_name is not None
            ) == False:

                key = self.get_key_mapping(key)

                if (
                    self.recording_macro
                    and self.current_macro_recording is not None
                    and key is not None
                ):
                    self.macros[self.current_macro_recording].append(key)

            if self.debug:
                with open("seq.txt", "a", encoding="utf-8") as f:
                    f.write(f"Processed key: {key}\n")

            if key in ("Ctrl+C", "ESC", 27):  # Escape key
                self.change_modes(mode="NORMAL")

            elif key == curses.KEY_MOUSE:
                try:
                    _, mx, my, _, bstate = curses.getmouse()
                except Exception:
                    return None

                buf = self.buffers[self.current_buffer]

                # wheel
                if bstate & curses.BUTTON4_PRESSED:
                    self.move_scroll(-3)
                    if not self.mouse_button_down:
                        self.end_selection()
                    return None

                if bstate & curses.BUTTON5_PRESSED:
                    self.move_scroll(3)
                    if not self.mouse_button_down:
                        self.end_selection()
                    return None

                # gutter width for line
                y = buf.scroll + my
                if 0 <= y < len(buf.lines):
                    gutter_width = 0
                    if self.gutter_render:
                        gutter_width = self.gutter_render(self.stdscr, my, y, buf, None)
                else:
                    gutter_width = 0

                mx_buf = mx - gutter_width
                if mx_buf < 0:
                    mx_buf = 0

                y = max(0, min(y, len(buf.lines) - 1))
                line_len = len(buf.lines[y])
                x = buf.h_scroll + mx_buf
                x = max(0, min(x, line_len))

                self.mouse_x = x
                self.mouse_y = y

                if bstate & curses.BUTTON1_PRESSED:
                    buf.cursor_y, buf.cursor_x = y, x

                    if not self.mouse_button_down:
                        self.mouse_button_down = True
                        self.selection_start = None
                        self.start_selection()

                    if my < 0:
                        self.move_scroll(-1)
                    elif my >= self.height - 1:
                        self.move_scroll(1)

                    self.buffers[self.current_buffer] = buf

                    return None

                if bstate & curses.BUTTON1_RELEASED:
                    self.mouse_button_down = False

                    buf.cursor_x = x
                    buf.last_cursor_x = x
                    buf.cursor_y = y

                    if (
                        self.selection_start is not None
                        and y == self.selection_start[0]
                        and x == self.selection_start[1]
                    ):
                        self.end_selection()

                        time_elapse = time.time() - self.last_mouse_click  # in seconds

                        if time_elapse < 0.25:
                            line = buf.lines[y]
                            sel_start = sel_end = None

                            if sel_start is None:
                                left = line[:x]
                                right = line[x:]
                                m1 = re.search(r"\w+$", left)
                                m2 = re.match(r"\w+", right)
                                if m1 or m2:
                                    s = m1.start() if m1 else x
                                    e = x + m2.end() if m2 else x
                                    sel_start, sel_end = s, e

                            if sel_start is None:
                                return None

                            self.selection_start = (y, sel_start)
                            buf.cursor_y, buf.cursor_x = y, (
                                sel_end if sel_end is not None else 0
                            )

                    self.last_mouse_click = time.time()

                    return None

            elif key == 0 or key == "\x00":  # control + space (ASCII 0)
                self.lsp_completion()

            elif key == "Ctrl+W":
                # self.stdscr.nodelay(False)
                self.stdscr.nodelay(True)
                file_explorer.show_explorer(editor=self)

            elif key == "Ctrl+L":
                self.show_buffer_picker()

            elif key == "Home":
                self.go_to_file_start()

            elif key == "End":
                self.go_to_file_end()

            elif key == "Delete":
                if self.mode == "INSERT":
                    self.delete()
                else:
                    self.move_cursor("Left")

            elif key == "Ctrl+G":
                if self.mode == "NORMAL":
                    self.go_to_line_prompt()

            elif key in (31, "\x1f"):
                self.show_file_picker()

            elif key == "Ctrl+Q":
                self.confirm_quit()

            elif key == "Ctrl+S":
                self.save_file()

            elif key == "Ctrl+Z":
                if not CURRENT_PLATFORM.startswith("win"):
                    curses.cbreak()
                    os.kill(os.getpid(), signal.SIGTSTP)
                else:
                    self.send_notification("SIGTSTP not supported on Windows.", 2000)

            elif key in ("Backspace", 127, 8, "Ctrl+H"):
                if self.mode == "INSERT":
                    self.backspace()

            elif key in ("Enter", 10, 13, "Ctrl+J", "Ctrl+M"):

                if self.mode == "INSERT":
                    if self.selection_start:
                        self.backspace()
                        self.end_selection()

                    self.newline()

            elif (self.mode == "INSERT" and key in self.keymap) or (
                self.mode == "NORMAL" and key in self.keymap_normal
            ):
                action = None

                if key is not None:
                    if self.mode == "INSERT":
                        action = self.keymap.get(key)
                    elif self.mode == "NORMAL":
                        action = self.keymap_normal.get(key)

                # Call the action associated with the key
                if action:
                    curses.flushinp()  # Ensure output is flushed before action

                    action_res = action()

                    if action_res is None:
                        action_res = True

                    if not action_res:
                        return None

            elif key in (9, "\t", "Ctrl+I"):

                if self.mode == "INSERT":
                    buffer = self.get_current_buffer()
                    line = buffer.lines[buffer.cursor_y]

                    # get visual column tab-aware
                    offsets = get_offsets(line, buffer.tab_size)
                    visual_col = (
                        offsets[buffer.cursor_x]
                        if buffer.cursor_x < len(offsets)
                        else offsets[-1]
                    )

                    if buffer.insert_spaces:
                        spaces = buffer.tab_size - (visual_col % buffer.tab_size)
                        for _ in range(spaces):
                            self.insert_char(" ")
                    else:
                        self.insert_char("\t")

            elif key in FUNC_KEYS:
                pass

            elif isinstance(key, str) and len(key) == 1:
                # Handle single character input

                if self.mode == "INSERT":
                    if self.selection_start:
                        # If selection is active, replace selection with the character
                        self.backspace()

                    self.end_selection()
                    self.insert_char(key)

        except Exception as e:
            self.open_untitled_buffer(f"Error: {e},\n\n{traceback.format_exc()}")

        return None  # continue main loop

    def apply_action_on_selection_or_file(
        self,
        action_title: str,
        action_function: Callable[[str], Optional[BufferAction]],
    ):
        try:
            if self.selection_start is not None:
                ss, es = self.selection_start
                sc, ec = self.get_current_buffer().get_cursor_position()

                if (ss, es) < (sc, ec):
                    self.toggle_selection_start()

                selected_text = "\n".join(self.get_selected_text(move_cursor=False))
                action = action_function(selected_text)

                if action is None:
                    return

                self.apply_action_to_buffer(action)
                self.end_selection()

            else:
                self.get_current_buffer().set_cursor_position(CursorPosition(y=0, x=0))
                full_text = "\n".join(self.get_current_buffer().get_lines())
                action = action_function(full_text)

                if action is None:
                    return

                self.apply_action_to_buffer(action)

        except Exception as e:
            self.send_multiline_notification(
                f"{action_title} failed: {e}\n{traceback.format_exc()}", 0
            )

    def toggle_line_number(self, option: str = "ln") -> None:
        if option == "ln":
            if config.STATIC_CONFIG.get("gch", False):
                if config.STATIC_CONFIG.get("ln", False):
                    self.gutter_render = render_git_gutter
                else:
                    self.gutter_render = render_line_numbers_and_git
            else:
                if config.STATIC_CONFIG.get("ln", False):
                    self.gutter_render = None
                else:
                    self.gutter_render = render_line_numbers

            config.STATIC_CONFIG["ln"] = not config.STATIC_CONFIG.get("ln", False)

        elif option == "gch":
            if config.STATIC_CONFIG.get("ln", False):
                if config.STATIC_CONFIG.get("gch", False):
                    self.gutter_render = render_line_numbers
                else:
                    self.gutter_render = render_line_numbers_and_git
            else:
                if config.STATIC_CONFIG.get("gch", False):
                    self.gutter_render = None
                else:
                    self.gutter_render = render_git_gutter

            config.STATIC_CONFIG["gch"] = not config.STATIC_CONFIG.get("gch", False)

        else:
            self.gutter_render = None
            self.send_notification("Wrong Toggle Param.")

    def toggle_bracket_match(self) -> None:
        config.STATIC_CONFIG["brkm"] = not config.STATIC_CONFIG.get("brkm", False)

    def merge_lines(self) -> None:
        buffer = self.get_current_buffer()

        action = buf_actions.merge_lines(buffer)

        if action is not None:
            self.apply_action_to_buffer(action)

            buffer.set_cursor_position(
                CursorPosition(y=buffer.cursor_y, x=len(buffer.lines[buffer.cursor_y]))
            )

    def parse_compiler_diagnostics(self, file_names) -> None:
        for b in self.buffers:
            b.diagnostics.clear()

        if file_names:

            for file in (
                f.replace('"', "").strip()
                for f in file_names.split('"')
                if f.strip() != ""
            ):
                res = file.split(":")
                if len(res) == 4:
                    file_name, line, col, message = res
                    file = file_name.strip()
                    line = int(line.strip())
                    col = int(col.strip())

                elif len(res) == 3:
                    file_name, line, col = res
                    file = file_name.strip()
                    line = int(line.strip())
                    col = int(col.strip())
                    message = ""
                elif len(res) == 2:
                    file_name, line = res
                    file = file_name.strip()
                    line = int(line.strip())
                    col = 1
                    message = ""
                else:
                    file = res[0].strip()
                    line = 1
                    col = 1
                    message = ""

                if (buf_index := self.get_buffer_by_file_name(file)) != -1:
                    buffer = self.buffers[buf_index]
                    self.current_buffer = buf_index
                else:
                    buffer = Buffer(file, temp_dir=self.temp_dir)
                    self.buffers.append(buffer)
                    self.current_buffer = len(self.buffers) - 1

                buffer.cursor_y = line - 1 if line <= len(buffer.lines) else 0
                buffer.cursor_x = (
                    col - 1 if col <= len(buffer.lines[buffer.cursor_y]) else 0
                )

                if message:
                    buffer.diagnostics.append(
                        hilighing.Diagnostic(
                            line=buffer.cursor_y,
                            char=buffer.cursor_x,
                            code="E",
                            message=message,
                            severity=1,
                        )
                    )

    def get_current_buffer(self) -> Buffer:
        if self.current_buffer >= len(self.buffers):
            self.current_buffer = len(self.buffers) - 1

        self.buffers[self.current_buffer].load()

        return self.buffers[self.current_buffer]

    def get_buffer_by_file_name(self, file_name: str) -> int:
        buf = -1

        for i, b in enumerate(self.buffers):
            if file_name == b.file_name:
                buf = i
                b.load()
                break

        return buf

    def get_buffer_from_uri(self, uri: str) -> Buffer | None:
        for b in self.buffers:
            if get_uri_from_name(b.file_name) == uri:
                return b

        return None

    def fzf_tui_search(self, options: Optional[list[str]] = None) -> Optional[str]:
        try:
            if shutil.which("fzf"):

                from denary import external_tui

                return_code, output = external_tui.run_external_tui_raw(
                    editor=self,
                    command=["fzf"],
                    input_data="\n".join(options) if options is not None else None,
                )

                if return_code == 0:
                    choice = (
                        [l for l in (l.strip() for l in output.split("\r")) if l][-1]
                        .split("[?1000l")[-1]
                        .split("[?25h")[-1]
                    )

                    return choice

            else:
                self.send_notification("Could not find fzf executable.")

        except Exception as e:
            self.send_notification(f"Error while executing fzf: {e}.")

        return None

    def lsp_hover(self) -> None:
        buffer = self.get_current_buffer()

        if not buffer.file_name and not buffer.is_aux_buffer:
            self.send_notification("No file to show hover for.")
            return None

        if buffer.suffix is None:
            return None

        lsp_client = get_lsp(buffer.suffix)
        if lsp_client:
            try:
                lsp_client.hover(
                    get_uri_from_name(buffer.file_name),
                    buffer.cursor_y,
                    buffer.cursor_x,
                )

            except Exception as e:
                self.send_notification(f"Error getting hover info: {e}")

        else:
            self.send_notification("LSP client not found for this file type.")

        return None

    def lsp_completion(self, trigger: str = "") -> None:
        buf = self.get_current_buffer()

        if buf.suffix is None:
            return None

        lsp_client = get_lsp(buf.suffix)

        if lsp_client is not None:
            try:
                lsp_client.completion(
                    get_uri_from_name(buf.file_name),
                    buf.cursor_y,
                    buf.cursor_x,
                    trigger,
                )
            except Exception as e:
                self.send_notification(f"Error getting hover info: {e}")
        else:
            self.show_suggestions()

    def lsp_refresh(self) -> None:
        """
        Refresh the LSP client for the current buffer.
        """
        buffer = self.get_current_buffer()

        if not buffer.file_name and not buffer.is_aux_buffer:
            self.send_notification("No file to refresh LSP for.")
            return None

        if buffer.suffix is None:
            return None

        lsp_client = get_lsp(buffer.suffix)
        if lsp_client:
            try:
                uri = get_uri_from_name(buffer.file_name)

                lsp_client.did_close(uri)

                time.sleep(1)

                lsp_client.did_open(
                    uri,
                    "\n".join(buffer.get_lines()),
                )
                self.send_notification("LSP client refreshed successfully.")
            except Exception as e:
                self.send_notification(f"Error refreshing LSP client: {e}")
        else:
            self.send_notification("LSP client not found for this file type.")

    def lsp_definition(self) -> None:
        buffer = self.get_current_buffer()

        if not buffer.file_name and not buffer.is_aux_buffer:
            self.send_notification("No file to show definition for.")
            return None

        if buffer.suffix is None:
            return None

        lsp_client = get_lsp(buffer.suffix)
        if lsp_client:
            try:
                lsp_client.definition(
                    get_uri_from_name(buffer.file_name),
                    buffer.cursor_y,
                    buffer.cursor_x,
                )

            except Exception as e:
                self.send_notification(f"Error getting definition: {e}")

        else:
            self.send_notification("LSP client not found for this file type.")

    def show_all_lsp_diagnostics(self) -> None:
        """
        Collect all LSP diagnostics from the current buffer and display them
        in a floating window, grouped by severity.
        """
        buffer = self.get_current_buffer()
        diags = getattr(buffer, "diagnostics", [])

        if not diags:
            open_file_in_less_mode(
                window=self.stdscr,
                file_handle=StringIO("No diagnostics available."),
                editor=self,
            )
            return

        # Severity mapping: smaller number = higher priority in LSP
        severity_labels = {1: "Error", 2: "Warning", 3: "Info", 4: "Hint"}
        severity_order = [1, 2, 3, 4]  # display order

        grouped = defaultdict(list)
        for d in diags:
            grouped[d.severity].append(d)

        lines = []
        for sev in severity_order:
            if sev in grouped:
                lines.append(
                    f"=== {severity_labels.get(sev, sev)} ({len(grouped[sev])}) ==="
                )
                for diag in grouped[sev]:
                    # Show: line:col  CODE: message
                    lines.append(
                        f"Line {diag.line + 1}, Col {getattr(diag, 'char', 0) + 1} "
                        f"{diag.code or ''}: {diag.message}"
                    )
                lines.append("")

        text = "\n".join(lines).strip()
        open_file_in_less_mode(
            window=self.stdscr, file_handle=StringIO(text), editor=self
        )

    def lsp_references(self) -> None:
        buffer = self.get_current_buffer()

        if not buffer.file_name and not buffer.is_aux_buffer:
            self.send_notification("No references found.")
            return None

        if buffer.suffix is None:
            return None

        lsp_client = get_lsp(buffer.suffix)
        if lsp_client:
            try:
                lsp_client.references(
                    get_uri_from_name(buffer.file_name),
                    buffer.cursor_y,
                    buffer.cursor_x,
                )
            except Exception as e:
                self.send_notification(f"Error getting references info: {e}")

        else:
            self.send_notification("LSP client not found for this file type.")

    def lsp_code_action(self) -> None:
        buffer = self.get_current_buffer()

        if not buffer.file_name and not buffer.is_aux_buffer:
            self.send_notification("No references found.")
            return None

        if buffer.suffix is None:
            return None

        lsp_client = get_lsp(buffer.suffix)
        if lsp_client:
            try:
                lsp_client.code_action(
                    uri=get_uri_from_name(buffer.file_name),
                    line=buffer.cursor_y,
                    character=buffer.cursor_x,
                    only=["quickfix"],
                )
                # if code_action_info:
                #     # match code_action_info:
                #     #     case {"result": references, **rest} if isinstance(references, list):
                #     #         self.show_references_picker(references)

                #     #     case { "error": { "message": msg, **error_rest }, **rest }:
                #     #         self.send_notification(f"References not avilable {msg}.")

                #     #     case _:
                #     #         self.open_aux_buffer(json.dumps(hover_info, indent=4))
                #     # self.open_aux
                #     self.open_aux_buffer(json.dumps(code_action_info, indent=4))
                # else:
                #     self.send_notification("References not avilable.")
            except Exception as e:
                self.send_multiline_notification(
                    f"Error getting references info: {e}\n{traceback.format_exc()}", 0
                )

        else:
            self.send_notification("LSP client not found for this file type.")

    def open_aux_buffer(
        self, text: str, title: str = "__auxiliary__", lexer=None
    ) -> None:
        """
        Open an auxiliary buffer with the given lines and title.
        """
        aux_buffer_id = self.get_buffer_by_file_name(title)
        text = (
            text.replace("\r\n", "\n")
            .replace("\r", "\n")
            .expandtabs(4)
            .replace("\x00", "�")
        )

        if aux_buffer_id != -1:
            aux_buffer = self.buffers[aux_buffer_id]
            aux_buffer.set_lines([RichString(s) for s in text.splitlines()])
            aux_buffer.file_name = title
            self.current_buffer = aux_buffer_id

        else:
            aux_buffer = Buffer(aux_buffer=True, temp_dir=self.temp_dir)
            aux_buffer.set_lines([RichString(s) for s in text.splitlines()])
            aux_buffer.file_name = title

            if lexer is not None:
                aux_buffer.lexer = lexer
            else:
                code = "\n".join(aux_buffer.lines[:500])
                try:
                    aux_buffer.lexer = guess_lexer(code)
                except Exception:
                    pass

            self.buffers.append(aux_buffer)
            self.current_buffer = len(self.buffers) - 1

        self.get_current_buffer().adjust_cursor_position()
        self.send_notification(f"Opened auxiliary buffer: {title}")

    def open_untitled_buffer(self, text: str, lexer=None) -> None:
        """
        Open an auxiliary buffer with the given lines and title.
        """
        text = (
            text.replace("\r\n", "\n")
            .replace("\r", "\n")
            .expandtabs(4)
            .replace("\x00", "�")
        )

        self.new_buffer_count += 1

        aux_buffer = Buffer(
            f"Untitled-{self.new_buffer_count}",
            new_buffer_untitled=True,
            temp_dir=self.temp_dir,
        )
        aux_buffer.load()
        aux_buffer.first = False

        aux_buffer.set_lines([RichString(s) for s in text.splitlines()])

        if lexer is not None:
            aux_buffer.lexer = lexer
        else:
            code = "\n".join(aux_buffer.lines[:500])
            try:
                aux_buffer.lexer = guess_lexer(code)
            except Exception:
                pass

        if aux_buffer.lexer:
            aux_buffer.suffix = self.get_suffix_from_buffer_lexer(aux_buffer.lexer)

        self.buffers.append(aux_buffer)
        self.current_buffer = len(self.buffers) - 1

        self.get_current_buffer().adjust_cursor_position()

        if len(self.buffers) != 1:
            self.send_notification(f"Opened new buffer: {aux_buffer.file_name}")

    def set_marker(self) -> None:
        """
        Set a marker at the current cursor position.
        """
        buffer = self.get_current_buffer()
        all_markers = [
            marker[0]
            for marker in itertools.chain(
                buffer.markers.items(), self.global_markers.items()
            )
        ]

        marker_name = self.send_prompt("Set marker name: ", history=all_markers)

        if not marker_name:
            return None

        if marker_name.startswith("_"):
            # Store the marker globally
            if not buffer.file_name:
                self.send_notification(
                    "Error, cannot set global markers to unsave files."
                )
                return None

            if marker_name in self.global_markers:
                self.send_notification(
                    f"Global marker '{marker_name}' already exists. Overwriting."
                )

            self.global_markers[marker_name] = (
                buffer.cursor_y,
                buffer.cursor_x,
                buffer.file_name,
            )

            self.send_notification(
                f"Global marker '{marker_name}' set at ({buffer.cursor_y}, {buffer.cursor_x}, buffer {self.current_buffer})"
            )
            return None

        else:

            # Store the marker with the current cursor position
            buffer.markers[marker_name] = (buffer.cursor_y, buffer.cursor_x)
            self.send_notification(
                f"Marker '{marker_name}' set at ({buffer.cursor_y}, {buffer.cursor_x})"
            )

    def pick_markers(self) -> None:
        """
        Show a list of markers and allow the user to jump to one.
        """
        buffer = self.get_current_buffer()

        if not buffer.markers and not self.global_markers:
            self.send_notification("No markers set.")
            return

        def display(entry: tuple[str, tuple]) -> str:
            if len(entry[1]) == 2:
                y, x = entry[1]
                return f"{entry[0]},{" " * max(0, 10- len(entry[0]))} at [{y},{x}]: {buffer.lines[max(0, min(y, len(buffer.lines) - 1))].strip()[:80]}"
            else:
                y, x, buf_name = entry[1]
                return f"{entry[0]},{" " * max(0, 10- len(entry[0]))} at [{y},{x}]: {buf_name}"

        def compare(entry: tuple[str, tuple], query: str) -> bool:
            return query.lower() in entry[0].lower()

        all_markers = [
            marker
            for marker in itertools.chain(
                buffer.markers.items(), self.global_markers.items()
            )
        ]

        res = self.show_picker_display(
            entries=all_markers, display_func=display, compare_func=compare
        )

        try:
            if res is None:
                res = ""
            else:
                res = res[0]

        except Exception as e:
            self.send_notification(f"An error has ocour: {e}\n{traceback.format_exc()}")
            return None

        if res.startswith("_"):

            if res in self.global_markers:
                y, x, file_name = self.global_markers[res]

                buf = self.get_buffer_by_file_name(file_name=file_name)

                if buf < 0:
                    path_new_buffer = Path(file_name)

                    if not path_new_buffer.exists():
                        self.send_notification(
                            f"Global marker '{res}' buffer not found."
                        )
                        self.global_markers.pop(res)
                        return

                    new_buffer = Buffer(file_name, temp_dir=self.temp_dir)
                    self.buffers.append(new_buffer)
                    buf = len(self.buffers) - 1

                buffer = self.buffers[buf]

                pos = CursorPosition(y=y, x=x)

                buffer.set_cursor_position(pos)
                self.current_buffer = buf
                self.send_notification(
                    f"Jumped to global marker '{res}' at ({pos.y}, {pos.x}) in buffer {buf}"
                )
                return None

        else:
            if res in buffer.markers:
                pos = CursorPosition(*buffer.markers[res])

                buffer.set_cursor_position(pos)

                self.send_notification(
                    f"Jumped to marker '{res}' at ({pos.y}, {pos.x})"
                )

                return None

        if res != "":
            self.send_notification(f"No marker found with name '{res}'")

    def interactive_replace_in_buffer(self) -> None:
        """
        Regex interactive replace with:
        - Start searching from cursor
        - Forward search
        - Wrap-around ONCE at EOF
        - Replace-all
        - Zero-length match protection
        - No infinite loops
        - Uses only (before, after) like your engine expects
        """
        _history = list(self.search_history)
        if self.last_search:
            _history.append(self.last_search)

        pattern = self.send_prompt("Pattern to replace: ", history=_history)
        if not pattern:
            return None

        replacement = self.send_prompt("Replace with: ")
        if replacement is None:
            replacement = ""

        try:
            regex = re.compile(pattern, re.IGNORECASE)
        except Exception:
            self.send_notification(f"Invalid regex: {pattern}")
            return None

        buffer = self.get_current_buffer()

        self.last_search = pattern
        self.last_search_re = regex
        self.disable_search = False

        cur_y, cur_x = buffer.get_cursor_position()
        lines = buffer.get_lines()

        absolute_cursor_index = sum(len(line) + 1 for line in lines[:cur_y]) + cur_x
        text = "\n".join(lines)

        search_pos = max(0, min(len(text), absolute_cursor_index))
        wrapped = False

        replace_all = False
        replacements_made = 0
        MAX_REPLACEMENTS = sum(
            1 for _ in (re.compile(pattern, re.IGNORECASE)).finditer(text)
        )

        while True:
            self.adjust_scroll()
            self.draw()

            if replacements_made + 1 > MAX_REPLACEMENTS:
                self.send_notification(
                    "Stopped: too many replacements (loop protection)."
                )
                break

            text = "\n".join(buffer.get_lines())
            match = regex.search(text, search_pos)

            if not match:
                if wrapped:
                    break  # already wrapped once → fully done
                # wrap-around once only
                search_pos = 0
                wrapped = True
                continue

            start, end = match.span()

            if start == end:
                search_pos = max(end + 1, start + 1)
                continue

            matched_text = text[start:end]

            line_num = text.count("\n", 0, start)
            last_nl = text.rfind("\n", 0, start)
            col_num = start - (last_nl + 1) if last_nl != -1 else start
            col_num = max(0, col_num)

            buffer.set_cursor_position(CursorPosition(y=line_num, x=col_num))

            self.selection_start = (line_num, col_num + len(matched_text))
            self.adjust_scroll()
            self.draw()

            if not replace_all:
                choice = self.send_prompt(
                    f"Replace '{matched_text}'? [y]es / [n]o / [a]ll / [q]uit: "
                )
                choice = (choice or "").strip().lower()
            else:
                choice = "y"

            if choice == "q":
                break

            if choice == "a":
                replace_all = True
                choice = "y"

            if choice != "y":
                search_pos = end
                continue

            try:
                # smart replacement
                new_text = expand_replacement(match, replacement)
            except Exception as e:
                self.send_multiline_notification(
                    f"Invalid replacement: {e}\n{traceback.format_exc()}", -1
                )
                break

            action = BufferAction(
                action_type=BufferActionTypeEnum.REPLACE,
                content=(matched_text, new_text),
                cursor_position=CursorPosition(y=line_num, x=col_num),
            )

            self.apply_action_to_buffer(action)
            replacements_made += 1

            search_pos = start + len(replacement)

        self.send_notification(
            f"Interactive replace finished. {replacements_made} replacements made."
        )
        self.last_search = pattern

    def send_notification_nowait(self, message: str, duration: int = 500) -> None:
        if "\n" in message:
            notifications.send_multiline_notification(
                window=self.stdscr,
                message=message,
                duration=duration,
                editor=self,
            )
        else:
            notifications.send_notification(
                window=self.stdscr,
                message=message,
                duration=duration,
                editor=self,
            )

    def send_notification(self, message: str, duration: int = 500) -> None:
        events.EVENT_QUEUE.put_nowait(
            Event(type=EventType.NOTIFICATION, data=(message, duration))
        )

    def send_multiline_notification(self, message: str, duration: int = 500) -> None:

        events.EVENT_QUEUE.put_nowait(
            Event(type=EventType.NOTIFICATION, data=(message, duration))
        )

    def send_multiline_prompt(self, multiline_message: str, prompt_message: str) -> str:
        return prompts.send_multiline_prompt(
            window=self.stdscr,
            multiline_message=multiline_message,
            prompt_message=prompt_message,
            editor=self,
        )

    def send_prompt(
        self,
        prompt_message: str,
        history: Optional[list[str]] = None,
        current_value: Optional[str] = None,
        on_change: Optional[Callable[[str], None]] = None,
        debounce_ms: int = 0,
        max_buffer_len: int = -1,
        increment_macro_start: bool = True,
    ) -> str:
        return prompts.send_prompt(
            window=self.stdscr,
            prompt_message=prompt_message,
            history=history,
            current_value=current_value,
            on_change=on_change,
            debounce_ms=debounce_ms,
            max_buffer_len=max_buffer_len,
            increment_macro_start=increment_macro_start,
            editor=self,
        )

    def send_prompt_confirm(self, prompt_message: str, color_p: int = -1) -> bool:
        return prompts.send_prompt_confirm(
            window=self.stdscr,
            prompt_message=prompt_message,
            color_p=color_p,
            editor=self,
        )

    def send_prompt_confirm_multiline(
        self, multiline_message: str, prompt_message: str
    ) -> bool:
        return prompts.send_prompt_confirm_multiline(
            window=self.stdscr,
            multiline_message=multiline_message,
            prompt_message=prompt_message,
            editor=self,
        )

    def show_filetype_picker(self) -> None:
        from pygments.lexers import get_all_lexers, get_lexer_by_name

        lexers = list(get_all_lexers())

        if not lexers:
            self.send_notification("Could not load list of lexers")
            return None

        selected = self.show_picker_display(
            entries=lexers,
            display_func=lambda x: x[0],  # lexer name
            compare_func=lambda x, q: True,
            external_filter=lambda q, c: (
                fzf_fuzzy_find(q, [el["display"] for el in c])
                if q
                else [el["display"] for el in c]
            ),
            debounce_ms=400,
        )

        if not selected:
            return None

        lexer_name, aliases, *_ = selected

        # direct resolution (no loops)
        lexer = get_lexer_by_name(aliases[0] if aliases else lexer_name)
        suffix = self.get_suffix_from_buffer_lexer(lexer)

        buffer = self.get_current_buffer()

        if (
            buffer.suffix is not None
            and (lsp_client := get_lsp(buffer.suffix)) is not None
        ):
            lsp_client.did_close(get_uri_from_name(buffer.file_name))

        buffer.lexer = lexer
        buffer.suffix = suffix

        if (
            buffer.suffix is not None
            and (lsp_client := get_lsp(buffer.suffix)) is not None
        ):
            lsp_client.did_open(
                get_uri_from_name(buffer.file_name), "\n".join(buffer.get_lines())
            )

        buffer.deverge_state = 0

        for line in buffer.lines:
            line.state = None
            line.tokens = None

        self.send_notification(f"Lexer set: {lexer_name}")

    def change_lexer(self, arg: Optional[str] = None) -> None:
        buffer = self.buffers[self.current_buffer]
        first_line = buffer.lines[0]

        if arg is None or not arg:
            # new_filetype = self.send_prompt(
            #     prompt_message="change filetype example (python or py or .py for python): "
            # )
            self.show_filetype_picker()
            return None
        else:
            new_filetype = arg

        if not new_filetype:
            self.send_notification("filetype not supplied.")
            return None

        if not new_filetype.startswith("."):
            new_filetype = "." + new_filetype

        lexer = TextLexer()
        suffix = buffer.suffix

        try:
            lexer = hilighing.get_lexer(suffix=new_filetype)
            suffix = new_filetype

        except Exception as e:
            self.send_multiline_notification(
                f"No se pudo cargar el lexer, {e}\n{traceback.format_exc()}.", 0
            )
            try:
                lexer = get_lexer_by_name(new_filetype)

                if lexer:
                    suffix = self.get_suffix_from_buffer_lexer(lexer)

            except Exception:
                pass

        if lexer and not suffix:
            suffix = self.get_suffix_from_buffer_lexer(lexer)

        if (
            buffer.suffix is not None
            and (lsp_client := get_lsp(buffer.suffix)) is not None
        ):
            lsp_client.did_close(get_uri_from_name(buffer.file_name))

        buffer.lexer = lexer
        buffer.suffix = suffix

        if (
            buffer.suffix is not None
            and (lsp_client := get_lsp(buffer.suffix)) is not None
        ):
            lsp_client.did_open(
                get_uri_from_name(buffer.file_name), "\n".join(buffer.get_lines())
            )

        first_line.state = None
        first_line.tokens = None

        buffer.deverge_state = 0

        if isinstance(lexer, TextLexer):
            for line in buffer.lines:
                line.state = None
                line.tokens = None

    def get_suffix_from_buffer_lexer(self, lexer) -> str | None:
        suffixes = get_suffix_from_lexer(lexer)
        suffixes_supported = set(config.EXT_TO_LANG.keys())

        for suffix in suffixes:
            if suffix in suffixes_supported:
                return suffix

        return None

    def save_file(self) -> None:
        """
        Write self.lines back to disk.  If no filename yet, prompt for 'Save as'.
        """

        buffer = self.get_current_buffer()

        if buffer.is_aux_buffer:
            self.send_notification("Cannot save auxiliary buffers.")
            return

        is_new = False

        if buffer.file_name is None or (
            buffer.file_name.startswith("Untitled") and buffer.file_time_stamp is None
        ):
            prompt = "Save as: "
            name = self.send_prompt(prompt)

            if not name:
                return None

            lexer_suffix = self.get_suffix_from_buffer_lexer(buffer.lexer)

            if (
                lexer_suffix is not None
                and buffer.file_name is not None
                and (lsp_client_before := get_lsp(lexer_suffix)) is not None
            ):
                lsp_client_before.did_close(uri=get_uri_from_name(buffer.file_name))

            buffer.file_name = name
            buffer.load_lexer()

            is_new = True

        try:
            buffer.save_file()
            self.working_dir_mtime = self.get_working_dir_mtime()

        except Exception as e:
            self.send_notification(f"File could not be saved correctly ({e}).", 1000)
            return None

        if config.STATIC_CONFIG.get("gch", False):
            buffer.git_changes = git_utils.get_file_changes(buffer.file_name)
            buffer.buffer_changes.clear()  # Clear buffer changes after saving

        if buffer.suffix is None:
            return None

        lsp_client = get_lsp(buffer.suffix)

        if lsp_client is not None:

            if is_new:
                try:
                    lsp_client.did_open(
                        get_uri_from_name(buffer.file_name),
                        "\n".join(buffer.get_lines()),
                    )
                except Exception as e:
                    self.send_notification(f"Error opening file in LSP: {e}")
            else:
                try:
                    lsp_client.did_save(
                        get_uri_from_name(buffer.file_name),
                    )
                except Exception as e:
                    self.send_notification(f"Error updating file in LSP: {e}")

        fpath = Path(buffer.file_name)

        # self.current_branch = git_utils.get_current_branch()

        self.send_notification(
            f"File '{buffer.file_name}' saved successfully. Writen: {fpath.stat().st_size} Bytes."
        )

        self.buffers[self.current_buffer] = buffer

    def get_working_dir_mtime(self) -> float:
        return os.stat(str(self.working_dir)).st_mtime

    def save_editor_session(self) -> None:
        """
        Save the current session state to a file.
        This includes the list of buffers and their content.
        """
        if self.without_session == False:
            if any(b.file_name is not None for b in self.buffers):
                session_file = "editor_session.json"
                session = Session(
                    current_buffer_name=self.buffers[self.current_buffer].file_name,
                    global_markers=self.global_markers,
                    command_history=self.command_history,
                    search_history=self.search_history,
                    eval_history=self.eval_history,
                    working_dir_mtime=self.working_dir_mtime,
                    buffers=[
                        BufferSession(
                            file_name=b.file_name,
                            cursor_x=b.cursor_x if b.cursor_x >= 0 else 0,
                            cursor_y=b.cursor_y if b.cursor_y >= 0 else 0,
                            scroll=b.scroll if b.scroll >= 0 else 0,
                            h_scroll=b.h_scroll if b.h_scroll >= 0 else 0,
                            markers=b.markers,
                        )
                        for b in self.buffers
                        if b.file_name and not b.is_aux_buffer
                    ],
                    fuzzy_search=self.fuzzy_search if self.fuzzy_search else [],
                )

                with open(session_file, "w") as f:
                    json.dump(session, f, indent=4)

            elif os.path.exists("editor_session.json"):
                os.remove("editor_session.json")

    def confirm_quit(self) -> None:
        """
        If buffer is modified, ask user to confirm quitting without saving.
        Returns True if safe to quit, False to continue editing.
        """
        try:

            documents_with_changes = sum(1 for b in self.buffers if b.modified)

            if documents_with_changes > 0:
                prompt = f"UNSAVED CHANGES!!!, buffers ({documents_with_changes}). Quit without saving?"
            else:
                prompt = "Are you sure you want to close the editor?"

            if self.send_prompt_confirm(prompt, color_p=15):
                # return True
                events.EVENT_QUEUE.put_nowait(Event(EventType.QUIT))
            else:
                for i, b in enumerate(self.buffers):
                    if b.modified:
                        self.current_buffer = i
                        break

                # return False

        finally:
            # Save the session before quitting
            self.save_editor_session()

    def start_selection(self) -> None:
        """
        Start a new selection at the current cursor position.
        """

        buffer = self.get_current_buffer()

        if self.selection_start is None:
            self.selection_start = (buffer.cursor_y, buffer.cursor_x)

    def end_selection(self) -> None:
        self.selection_start = None
        return None

    def toggle_selection(self) -> None:

        if self.selection_start is None:
            self.start_selection()
        else:
            self.end_selection()

    def manage_registers(self) -> None:
        multiline_message = "\n".join(
            f"{index}) {item[0]}:{" " * max(0, 10 - len(item[0]))} {"".join(item[1]).strip()[:50]} | ({len("".join(item[1]))}) Chars."
            for index, item in enumerate(
                itertools.chain(
                    self.registers.items(),
                    [(str(_i), _v) for _i, _v in enumerate(self.copy_history)],
                ),
                start=1,
            )
        )

        multiline_message = "Registers:\n" + multiline_message + "\n"

        register_name = self.send_multiline_prompt(
            multiline_message=multiline_message, prompt_message="Register name: "
        )

        if not register_name:
            return None

        clipboard_before = list(self.clipboard) if len(self.clipboard) else None

        if self.selection_start is not None:
            if register_name.isdigit():
                self.end_selection()
                self.send_notification(
                    f"Numbers cannot be set as register names, but the text was copied and added to the copy history.",
                    1000,
                )
                return None

            self.registers[register_name] = self.get_selected_text()
            self.end_selection()

        else:

            history_len = self.copy_history.maxlen or 0

            if register_name.isdigit():

                register_index = int(register_name)
                try:
                    if (
                        register_index < history_len
                        and len(self.copy_history) > register_index
                    ):
                        self.clipboard = list(self.copy_history[register_index])

                        self.paste()
                        self.clipboard = []

                except Exception as e:
                    self.send_notification(f"Error: {e}.")

            else:
                if register_name not in self.registers:
                    self.send_notification(
                        f"There isn't a register named: {register_name}."
                    )
                    return None

                self.clipboard = list(self.registers[register_name])

                self.paste()
                self.clipboard = []

        if clipboard_before is not None:
            self.clipboard = clipboard_before

    def get_selected_text(self, move_cursor: bool = True) -> list[str]:
        buffer = self.buffers[self.current_buffer]

        res: list[str] = []

        if not self.selection_start:
            return res

        start_row, start_col = self.selection_start
        end_row, end_col = buffer.cursor_y, buffer.cursor_x

        # Normalize order
        if (start_row, start_col) > (end_row, end_col):
            start_row, start_col, end_row, end_col = (
                end_row,
                end_col,
                start_row,
                start_col,
            )

        max_row = len(buffer.lines) - 1
        if max_row < 0:
            return res

        start_row = max(0, min(start_row, max_row))
        end_row = max(0, min(end_row, max_row))

        start_col = max(0, min(start_col, len(buffer.lines[start_row])))
        end_col = max(0, min(end_col, len(buffer.lines[end_row])))

        if move_cursor:
            buffer.cursor_y = start_row
            buffer.cursor_x = start_col
            buffer.last_cursor_x = buffer.cursor_x

        for r in range(start_row, end_row + 1):
            line = buffer.lines[r]

            if start_row == end_row:
                res.append(line[start_col:end_col])
            elif r == start_row:
                res.append(line[start_col:])
            elif r == end_row:
                res.append(line[:end_col])
            else:
                res.append(line)

        return res

    def copy(self) -> None:
        """
        Copy selected region or current line if no selection.
        """
        buffer = self.buffers[self.current_buffer]

        if self.selection_start:
            self.clipboard = self.get_selected_text()
        else:
            self.clipboard = [buffer.lines[buffer.cursor_y]]

        self.copy_history.append(self.clipboard)

        self._set_clipboard_text("\n".join(self.clipboard))

    def cut(self) -> None:
        """
        VSCode-style cut:
          • With a selection: remove that region (possibly multi-line) and copy it to clipboard.
          • Without a selection: remove the entire current line.
        Implemented as a single DELETE BufferAction.
        """
        buf = self.get_current_buffer()
        lines = buf.lines
        clip: list[str] = []

        without_selection = False

        if self.selection_start:
            sr, sc = self.selection_start
            er, ec = buf.cursor_y, buf.cursor_x
            if (sr, sc) > (er, ec):
                sr, sc, er, ec = er, ec, sr, sc
        else:
            # treat current line as selected
            sr = er = buf.cursor_y if buf.cursor_y < len(lines) else len(lines) - 1
            sc = 0
            ec = len(lines[sr])
            without_selection = True

        if sr == er:
            # single-line
            text = lines[sr]
            clip_text = text[sc:ec]
            clip = [clip_text]
            old_text = clip_text
        else:
            # multi-line selection
            first, last = lines[sr], lines[er]
            clip = [first[sc:]] + lines[sr + 1 : er] + [last[:ec]]
            old_text = "\n".join(clip)

        self.clipboard = clip

        action = BufferAction(
            action_type=BufferActionTypeEnum.DELETE,
            content=old_text,
            cursor_position=CursorPosition(y=sr, x=sc),
        )

        self.apply_action_to_buffer(action)

        if without_selection:
            if sr == 0:
                self.delete()
            else:
                self.backspace()
                if sr >= len(buf.lines):
                    sr -= 1

        buf.cursor_y = sr
        buf.cursor_x = sc
        buf.last_cursor_x = sc
        self.selection_start = None

        curses.flushinp()
        self.buffers[self.current_buffer] = buf

    def paste(self) -> None:
        """
        VSCode-style paste:
          • If there's a selection, replaces it (REPLACE action).
          • Otherwise, inserts clipboard content at the cursor (INSERT action).
          • Clipboard is a list[str], each entry one line of text.
        """
        buf = self.get_current_buffer()

        if not self.clipboard:
            return None

        if self.selection_start is not None:

            old_text = "\n".join(self.get_selected_text())
            self.selection_start = None

            # build new pasted text
            paste_text = "\n".join(self.clipboard)

            action = BufferAction(
                action_type=BufferActionTypeEnum.REPLACE,
                content=(old_text, paste_text),
                cursor_position=buf.get_cursor_position(),
            )

            self.apply_action_to_buffer(action)

            buf.last_cursor_x = buf.cursor_x
            curses.flushinp()
            return None

        paste_text = "\n".join(self.clipboard)

        # build action
        action = BufferAction(
            action_type=BufferActionTypeEnum.INSERT,
            content=paste_text,
            cursor_position=buf.get_cursor_position(),
        )

        self.apply_action_to_buffer(action)

        curses.flushinp()
        self.ensure_cursor_visible()

    def _set_clipboard_text(self, text: str) -> bool:
        """
        Try pyperclip.copy() first; if that fails, fall back to a platform-specific
        clipboard command. Returns True on success.
        """
        is_wsl = check_is_wsl()
        is_ssh = check_is_ssh()

        if is_wsl:
            # Use Windows' clipboard via PowerShell
            cmd = ["/mnt/c/Windows/System32/clip.exe"]
            try:
                p = subprocess.Popen(cmd, stdin=subprocess.PIPE, shell=True)
                p.communicate(text.encode("utf-16le"))

                return p.returncode == 0
            except Exception:
                pass

        if is_ssh:
            try:
                import base64

                b64 = base64.b64encode(text.encode()).decode()
                osc52 = f"\033]52;c;{b64}\a"
                sys.stdout.write(osc52)
                sys.stdout.flush()
                return True
            except Exception:
                pass

        # 2) macOS pbcopy
        if sys.platform.lower() == "darwin":
            try:
                p = subprocess.Popen(["pbcopy"], stdin=subprocess.PIPE)
                p.communicate(text.encode("utf-8"))
                return p.returncode == 0
            except Exception:
                return False

        # 3) Linux xclip / xsel
        if sys.platform.startswith("linux"):
            has_gui = os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")

            if not has_gui:
                return False

            for cmd in (
                ["xclip", "-selection", "clipboard"],
                ["xsel", "--clipboard", "--input"],
            ):
                try:
                    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
                    p.communicate(text.encode("utf-8"))
                    if p.returncode == 0:
                        return True
                except Exception:
                    continue
            return False

        # 4) Windows clip.exe
        if sys.platform.startswith("win"):
            try:
                p = subprocess.Popen(["clip"], stdin=subprocess.PIPE, shell=True)
                p.communicate(text.encode("utf-8"))
                return p.returncode == 0
            except Exception:
                return False

        return False

    def _get_clipboard_text(self) -> str:
        """
        Retrieve text from the system clipboard by trying multiple methods
        until one returns non-empty text.
        """
        # 2) Try a sequence of commands in order
        commands = [
            [
                "powershell.exe",
                "-NoProfile",
                "-Command",
                "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; Get-Clipboard",
            ],
            [
                "/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe",
                "-NoProfile",
                "-Command",
                "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; Get-Clipboard",
            ],
            ["pbpaste"],
            ["xclip", "-selection", "clipboard", "-o"],
            ["xsel", "--clipboard", "--output"],
            [
                "powershell",
                "-NoProfile",
                "-Command",
                "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; Get-Clipboard",
            ],
        ]

        for i, cmd in enumerate(commands):
            if shutil.which(cmd[0]):
                try:
                    result = subprocess.run(
                        cmd,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.DEVNULL,
                        check=True,
                    )

                    text = result.stdout.decode("utf-8", errors="ignore")

                    text = text.replace("\r\n", "\n")
                    text = text.expandtabs(4)
                    text = text.replace("\x00", "�")

                    if text:
                        return text
                except Exception as e:
                    self.send_notification(str(e), 0)
                    continue

        return ""

    def paste_from_system_clipboard(self) -> None:
        """
        Paste text from the system clipboard into the current buffer.
        """
        try:
            text = self._get_clipboard_text()
            if not text:
                self.send_notification("Clipboard is empty", 1000)
                return None

            previous_clipboard = self.clipboard

            lines = text.splitlines()

            self.clipboard = lines if lines else [""]

            self.paste()

            self.clipboard = previous_clipboard

        except Exception as e:
            self.send_notification(
                f"pyperclip module not installed or clipboard unavailable. {e}",
                1000,
            )

    def change_selection_case(self, mode: str = "upper") -> None:
        """
        Change the selected text case using a single REPLACE BufferAction.
        Only the selected span is replaced (not whole lines).
        """
        buffer = self.get_current_buffer()

        if not self.selection_start:
            return None

        # Normalize selection
        start_row, start_col = self.selection_start
        end_row, end_col = buffer.cursor_y, buffer.cursor_x
        if (start_row, start_col) > (end_row, end_col):
            start_row, start_col, end_row, end_col = (
                end_row,
                end_col,
                start_row,
                start_col,
            )

        def apply_case(text: str) -> str:
            if mode == "upper":
                return text.upper()
            if mode == "lower":
                return text.lower()
            if mode == "capitalize":
                return text.title()
            return text

        # Build the EXACT selected text (old_text)
        lines = buffer.lines
        if start_row == end_row:
            # single-line selection
            old_text = lines[start_row][start_col:end_col]
        else:
            first_part = lines[start_row][start_col:]
            middle = lines[start_row + 1 : end_row]
            last_part = lines[end_row][:end_col]
            parts = [first_part]
            if middle:
                parts.append("\n".join(middle))
            parts.append(last_part)
            old_text = "\n".join(p for p in parts if p is not None)

        new_text = apply_case(old_text)

        action = BufferAction(
            action_type=BufferActionTypeEnum.REPLACE,
            content=(old_text, new_text),
            cursor_position=CursorPosition(y=start_row, x=start_col),
        )
        self.apply_action_to_buffer(action)

        self.selection_start = None
        buffer.cursor_y = end_row
        buffer.cursor_x = end_col
        buffer.last_cursor_x = buffer.cursor_x
        curses.flushinp()

    def undo(self) -> None:
        buffer = self.get_current_buffer()
        buffer.undo_action()
        curses.flushinp()

    def redo(self) -> None:
        buffer = self.get_current_buffer()
        buffer.redo_action()
        curses.flushinp()

    def apply_action_to_buffer(
        self, action: BufferAction, buf_index: Optional[int] = None
    ) -> None:
        if buf_index is None:
            buf_index = self.current_buffer

        buffer = self.buffers[buf_index]
        buffer.apply_action(action)

    def adjust_scroll(self) -> None:
        """
        scrolloff = 8, but do NOTHING when approaching:
            - the first   8 lines of the file
            - the last    8 lines of the file

        Only apply scrolloff behavior when cursor is outside these zones.
        """

        SCROLLOFF = config.STATIC_CONFIG.get("scrolloff", 0)

        buffer = self.get_current_buffer()

        screen_height, screen_width = self.stdscr.getmaxyx()

        visible_rows = self.height - 1
        total_lines = len(buffer.lines)
        max_scroll = max(0, total_lines - visible_rows)

        y = buffer.cursor_y

        if y < SCROLLOFF:
            buffer.scroll = 0

        elif y >= total_lines - SCROLLOFF:
            buffer.scroll = max_scroll

        else:
            if y < buffer.scroll + SCROLLOFF:
                buffer.scroll = y - SCROLLOFF

            bottom_visible = buffer.scroll + visible_rows - 1
            if y > bottom_visible - SCROLLOFF:
                buffer.scroll = y + SCROLLOFF - visible_rows + 1

            buffer.scroll = max(0, min(buffer.scroll, max_scroll))

        gutter_width = 0
        if self.gutter_render:
            screen_row = buffer.cursor_y - buffer.scroll
            if 0 <= screen_row < screen_height - 1:
                gutter_width = self.gutter_render(
                    self.stdscr, screen_row, buffer.cursor_y, buffer, None
                )

        usable_width = screen_width - 1 - gutter_width

        if buffer.cursor_x < buffer.h_scroll:
            buffer.h_scroll = buffer.cursor_x
        elif buffer.cursor_x >= buffer.h_scroll + usable_width:
            buffer.h_scroll = buffer.cursor_x - usable_width + 1

    def move_cursor(self, key) -> None:
        buffer = self.get_current_buffer()
        buffer.move_cursor(key, self.height, self.width)

    def move_cursor_end_of_line(self) -> None:
        buffer = self.get_current_buffer()
        buffer.move_cursor_end_of_line()

    def move_cursor_start_of_line(self) -> None:
        buffer = self.get_current_buffer()
        buffer.move_cursor_start_of_line()

    def move_cursor_by_word(self, direction) -> None:
        buffer = self.get_current_buffer()
        buffer.move_cursor_by_word(direction)

    def move_cursor_by_punctuation(self, direction) -> None:
        buffer = self.get_current_buffer()
        buffer.move_cursor_by_punctuation(direction)

    def move_cursor_by_empty_line(self, direction: int) -> None:
        buffer = self.get_current_buffer()
        buffer.move_cursor_by_empty_line(direction, self.height)

    def find_char(
        self, target_char: Optional[str] = None, forward: bool = True
    ) -> None:
        buffer = self.get_current_buffer()

        if not target_char:
            target_char = self.send_prompt("f: " if forward else "F: ")

        buffer.find_char(target_char, forward)

    def ensure_cursor_visible(self) -> None:
        buffer = self.get_current_buffer()
        buffer.ensure_cursor_visible()

    def move_cursor_with_mouse_click(self, my: int, mx: int, bstate) -> None:

        buf = self.get_current_buffer()

        if bstate & curses.BUTTON1_PRESSED:
            self.start_selection()
            new_y = buf.scroll + my
            new_x = buf.h_scroll + mx

            # clamp
            buf.cursor_y = max(0, min(new_y, len(buf.lines) - 1))
            buf.cursor_x = max(0, min(new_x, len(buf.lines[buf.cursor_y])))
            return None

        if bstate & curses.BUTTON1_PRESSED and (mx or my):
            new_y = buf.scroll + my
            new_x = buf.h_scroll + mx
            buf.cursor_y = max(0, min(new_y, len(buf.lines) - 1))
            buf.cursor_x = max(0, min(new_x, len(buf.lines[buf.cursor_y])))
            return None

        if bstate & curses.BUTTON1_RELEASED:
            return None

    def should_record_jump(
        self,
        buffer_name: str,
        pos: CursorPosition,
        *,
        line_threshold: int = 20,
        big_jump_threshold: int = 200,
        min_time_delta: float = 0.30,
    ) -> bool:

        if self.disable_record_jump:
            self.disable_record_jump = False
            return False

        if not self.jump_list:
            return True

        if self.last_jump is None:
            return False

        if time.monotonic() - self.last_jump.timestamp < min_time_delta:
            return False

        if buffer_name != self.last_jump.buffer_name:
            return True

        line_distance = abs(pos.y - self.last_jump.position.y)

        if line_distance == 0:
            return False

        if line_distance >= big_jump_threshold:
            return True

        if line_distance >= line_threshold:
            return True

        return False

    def change_indentation(self, direction: int) -> None:
        buffer = self.get_current_buffer()
        y, x = buffer.get_cursor_position()

        if self.selection_start is not None:
            start_row, start_col = self.selection_start
            end_row, end_col = buffer.cursor_y, buffer.cursor_x

            if (start_row, start_col) > (end_row, end_col):
                start_row, start_col, end_row, end_col = (
                    end_row,
                    end_col,
                    start_row,
                    start_col,
                )
        else:
            start_row = end_row = buffer.cursor_y

        old_lines = buffer.lines[start_row : end_row + 1]
        old_lines_len = len(old_lines)
        old_text = "\n".join(old_lines)

        indent_unit = " " * buffer.tab_size if buffer.insert_spaces else "\t"
        new_lines = []

        for line in old_lines:
            is_blank = line.strip() == ""

            if direction > 0:
                if is_blank and old_lines_len > 1:
                    new_lines.append(line)
                    continue

                new_lines.append(indent_unit + line)

            else:
                if line.startswith("\t"):
                    new_lines.append(line[1:])
                else:
                    remove_count = 0
                    for ch in line[: buffer.tab_size]:
                        if ch == " ":
                            remove_count += 1
                        else:
                            break
                    new_lines.append(line[remove_count:])

        new_text = "\n".join(new_lines)

        if new_text == old_text:
            return None

        action = BufferAction(
            action_type=BufferActionTypeEnum.REPLACE,
            content=(old_text, new_text),
            cursor_position=CursorPosition(y=start_row, x=0),
        )

        self.apply_action_to_buffer(action)

        indent_width = buffer.tab_size if buffer.insert_spaces else 1

        if start_row <= y <= end_row:
            if direction > 0:
                buffer.cursor_x = min(x + indent_width, len(buffer.lines[y]))
            else:
                buffer.cursor_x = max(x - indent_width, 0)

        buffer.cursor_y = y
        buffer.last_cursor_x = buffer.cursor_x
        buffer.adjust_cursor_position()

    def toggle_comment_selection(
        self, prefix: str | tuple[str, str] | None = None
    ) -> None:
        """
        Toggle comment on the selected lines (or current line) like VS Code.
        Works with:
          - single-line token: str (includes trailing space, e.g. "# ")
          - multi-line tokens: (start_with_space, end)
        Empty lines are never commented or uncommented.
        """
        buffer = self.get_current_buffer()

        tok = (
            prefix
            if prefix is not None
            else (
                hilighing.lookup_prefix(buffer.file_name or "")
                if buffer.suffix is None
                else hilighing.lookup_prefix(f"filename{buffer.suffix}")
            )
        )
        single: str | None = None
        mstart: str | None = None
        mend: str | None = None

        if isinstance(tok, tuple):
            mstart, mend = tok
        else:
            single = tok

        has_single = bool(single)
        has_multi = bool(mstart) and bool(mend)
        if not has_single and not has_multi:
            return None

        if self.selection_start:
            sr, sc = self.selection_start
            er, ec = buffer.cursor_y, buffer.cursor_x
            if (sr, sc) > (er, ec):
                sr, sc, er, ec = er, ec, sr, sc
        else:
            sr = er = buffer.cursor_y

        block = buffer.lines[sr : er + 1]

        indents = [len(ln) - len(ln.lstrip()) for ln in block if ln.strip()]
        min_indent = min(indents) if indents else 0

        def is_single_commented(ln: RichString) -> bool:
            if not single:
                return False
            s = ln.lstrip()
            return s.startswith(single) or s.startswith(single.rstrip())

        def unwrap_single(txt: RichString) -> RichString:
            assert single is not None
            indent = len(txt) - len(txt.lstrip())
            s = txt.lstrip()
            if s.startswith(single):
                core = s[len(single) :]
            elif s.startswith(single.rstrip()):
                core = s[len(single.rstrip()) :]
                if core.startswith(" "):
                    core = core[1:]
            else:
                core = s
            return txt[:indent] + core

        def wrap_single(txt: RichString) -> RichString:
            assert single is not None
            before = txt[:min_indent]
            after = txt[min_indent:]
            return RichString(f"{before}{single}{after}")

        def is_multi_wrapped(ln: RichString) -> bool:
            if not has_multi:
                return False
            s = ln.lstrip()
            if mstart is not None and not s.startswith(mstart):
                return False

            body = s[len(mstart or "") :]

            if mend is not None and body.endswith(mend):
                return True
            pos = body.rfind(mend or "")
            if pos == -1:
                return False
            return body[pos + len(mend or "") :].strip() == ""

        def unwrap_multi(txt: RichString) -> RichString:
            assert has_multi
            indent = len(txt) - len(txt.lstrip())
            rest = txt[indent:]
            if mstart is not None and not rest.startswith(mstart):
                return txt
            body = rest[len(mstart or "") :]
            if mend is not None and body.endswith(mend):
                inner = body[: -len(mend)]
                inner = inner[:-1] if inner.endswith(" ") else inner
            else:
                pos = body.rfind(mend or "")
                if pos == -1:
                    return txt
                inner = body[:pos].rstrip()
            return txt[:indent] + inner

        def wrap_multi(txt: RichString) -> RichString:
            assert has_multi
            before = txt[:min_indent]
            inner = txt[min_indent:]
            sep_before_end = "" if (not inner or inner.endswith(" ")) else " "
            return RichString(f"{before}{mstart}{inner}{sep_before_end}{mend}")

        if has_single:
            uncomment = all(is_single_commented(ln) for ln in block if ln.strip())

            new_lines = []
            for ln in block:
                if not ln.strip():
                    new_lines.append(ln)
                    continue
                new_lines.append(unwrap_single(ln) if uncomment else wrap_single(ln))
        else:
            uncomment = all(is_multi_wrapped(ln) for ln in block if ln.strip())

            new_lines = []
            for ln in block:
                if not ln.strip():
                    new_lines.append(ln)
                    continue
                new_lines.append(unwrap_multi(ln) if uncomment else wrap_multi(ln))

        old_text = "\n".join(block)
        new_text = "\n".join(new_lines)

        action = BufferAction(
            action_type=BufferActionTypeEnum.REPLACE,
            content=(old_text, new_text),
            cursor_position=CursorPosition(y=sr, x=0),
        )
        y, x = buffer.get_cursor_position()

        self.apply_action_to_buffer(action)

        tok_len = len(tok)
        new_line = buffer.lines[buffer.cursor_y]
        buffer.cursor_y = y
        buffer.cursor_x = max(
            0, min(x + (tok_len if not uncomment else (-1 * tok_len)), len(new_line))
        )
        buffer.last_cursor_x = buffer.cursor_x
        buffer.adjust_cursor_position()

    def go_to_file_start(self) -> None:
        buffer = self.get_current_buffer()
        buffer.go_to_file_start()

    def go_to_file_end(self) -> None:
        buffer = self.get_current_buffer()
        buffer.go_to_file_end()

    def go_to_matching_bracket(self) -> None:
        buffer = self.get_current_buffer()
        current_buffer_position = buffer.get_cursor_position()

        bks = find_matching_bracket(
            buffer.lines, current_buffer_position.y, current_buffer_position.x
        )

        if bks is not None:
            bk1, bk2 = bks

            if (
                bk1[0] == current_buffer_position.y
                and bk1[1] + 1 == current_buffer_position.x
            ):
                new_pos = CursorPosition(y=bk2[0], x=bk2[1] + 1)
            else:
                new_pos = CursorPosition(y=bk1[0], x=bk1[1] + 1)

            buffer.set_cursor_position(position=new_pos)

    def delete(self) -> None:
        """
        Delete the character *at* the cursor position (Delete key behavior).
        Uses BufferAction instead of directly modifying the buffer lines.
        """

        buffer = self.get_current_buffer()

        if self.selection_start is not None:
            _clipboard = self.clipboard
            self.cut()  # delete selected region
            self.clipboard = _clipboard
            return None

        y, x = buffer.cursor_y, buffer.cursor_x
        lines = buffer.lines

        delete_text = ""

        if x < len(lines[y]):
            line = lines[y]
            delete_text = line[x]

            if x + 1 < len(line):
                left = line[x]
                right = line[x + 1]
                if key_mappings.PAIRS.get(left) == right:
                    delete_text = left + right

            cursor_pos = CursorPosition(y=y, x=x)

        elif y < len(lines) - 1:
            delete_text = "\n"
            cursor_pos = CursorPosition(y=y, x=len(lines[y]))

        else:
            curses.beep()
            return None

        action = BufferAction(
            action_type=BufferActionTypeEnum.DELETE,
            content=delete_text,
            cursor_position=cursor_pos,
        )

        self.apply_action_to_buffer(action)

        buffer.last_cursor_x = buffer.cursor_x
        buffer.adjust_cursor_position()

    def backspace(self) -> None:
        """
        Delete the character before the cursor (Backspace behavior).
        Uses BufferAction instead of directly modifying lines.
        """

        buf = self.get_current_buffer()

        if self.selection_start is not None:
            _clipboard = self.clipboard
            self.cut()
            self.clipboard = _clipboard
            return None

        y, x = buf.cursor_y, buf.cursor_x
        lines = buf.lines

        if y == 0 and x == 0:
            curses.beep()
            return None

        if x > 0:
            line = lines[y]

            if buf.insert_spaces:
                offsets = get_offsets(line, buf.tab_size)
                visual_col = offsets[x]

                prev_tab_stop = visual_col - (visual_col % buf.tab_size or buf.tab_size)
                spaces_to_delete = visual_col - prev_tab_stop

                start = x
                count = 0

                while start > 0 and count < spaces_to_delete and line[start - 1] == " ":
                    start -= 1
                    count += 1

                if count > 0:
                    delete_text = line[start:x]
                    cursor_pos = CursorPosition(y=y, x=start)

                    action = BufferAction(
                        action_type=BufferActionTypeEnum.DELETE,
                        content=delete_text,
                        cursor_position=cursor_pos,
                    )
                    self.apply_action_to_buffer(action)
                    return None

            left = line[x - 1]

            if x < len(line):
                right = line[x]

                if key_mappings.PAIRS.get(left) == right:
                    self.apply_action_to_buffer(
                        BufferAction(
                            action_type=BufferActionTypeEnum.DELETE,
                            content=right,
                            cursor_position=CursorPosition(y=y, x=x),
                        )
                    )

                    self.apply_action_to_buffer(
                        BufferAction(
                            action_type=BufferActionTypeEnum.DELETE,
                            content=left,
                            cursor_position=CursorPosition(y=y, x=x - 1),
                        )
                    )

                    curses.flushinp()
                    self.ensure_cursor_visible()
                    return None

            start = x - 1
            delete_text = line[start:x]
            cursor_pos = CursorPosition(y=y, x=start)

            action = BufferAction(
                action_type=BufferActionTypeEnum.DELETE,
                content=delete_text,
                cursor_position=cursor_pos,
            )
            self.apply_action_to_buffer(action)

        elif y > 0:
            delete_text = "\n"
            cursor_pos = CursorPosition(y=y - 1, x=len(lines[y - 1]))

            action = BufferAction(
                action_type=BufferActionTypeEnum.DELETE,
                content=delete_text,
                cursor_position=cursor_pos,
            )
            self.apply_action_to_buffer(action)

        curses.flushinp()
        self.ensure_cursor_visible()

    def newline(self, disable_auto_indent: bool = False) -> None:
        """
        Split current line at cursor into two lines and move cursor to the new line.
        Implemented as a single REPLACE BufferAction for undo/redo support.
        Prevents duplicated closing symbols (e.g. ')', '}', ']' or 'end').
        """
        buffer = self.get_current_buffer()
        y, x = buffer.cursor_y, buffer.cursor_x
        line = buffer.lines[y]
        before, after = line[:x], line[x:]

        _m = re.match(r"\s*", before)
        indent = _m.group(0) if _m is not None else ""
        extra = ""
        moved_closers = ""
        remainder_tail = after

        def one_indent() -> str:
            if buffer.insert_spaces:
                return " " * buffer.tab_size
            else:
                return "\t"

        if disable_auto_indent:
            indent = ""
            extra = ""
        else:
            opener = before.strip().lower().endswith(("{", "[", "(", ":", "begin"))
            if opener:
                extra = one_indent()

                m = re.match(
                    r"(\s*)(?:([)\]\}]+)|(end\b))(.*)$",
                    after,
                    flags=re.IGNORECASE,
                )
                if m:
                    leading_ws, closers_run, end_kw, rest = m.groups()

                    if closers_run:
                        moved_closers = closers_run
                        remainder_tail = leading_ws + rest
                    elif end_kw:
                        moved_closers = end_kw
                        remainder_tail = leading_ws + rest

        old_text = after

        if moved_closers:
            new_text = (
                "\n" + indent + extra + "\n" + indent + moved_closers + remainder_tail
            )
        else:
            new_text = "\n" + indent + extra + remainder_tail

        action = BufferAction(
            action_type=BufferActionTypeEnum.REPLACE,
            content=(old_text, new_text),
            cursor_position=CursorPosition(y=y, x=x),
        )

        self.apply_action_to_buffer(action)

        buffer.cursor_y = y + 1
        buffer.cursor_x = len(indent + extra)
        buffer.last_cursor_x = buffer.cursor_x
        buffer.adjust_cursor_position()

        curses.flushinp()

    def insert_char(self, ch: str, disable_autocomplete: bool = False) -> None:
        buffer = self.get_current_buffer()

        original_ch = ch

        action = buf_actions.insert_char(buffer, ch, disable_autocomplete)

        self.apply_action_to_buffer(action)

        if isinstance(action.content, str):
            ch = action.content

        if len(ch) > 1:
            buffer.cursor_x -= 1

        buffer.adjust_cursor_position()

        if not disable_autocomplete:
            if (
                buffer.suffix is not None
                and (lsp_client := get_lsp(buffer.suffix)) is not None
            ):
                if original_ch in lsp_client.triggerCharacters and original_ch not in (
                    " ",
                    "\t",
                    "\n",
                ):
                    self.lsp_completion(trigger=original_ch)

            elif original_ch == ".":
                self.show_suggestions()

    def search_prompt(self) -> None:
        """
        Prompt user for search term.
        """
        buffer = self.get_current_buffer()

        current_cur_position = buffer.get_cursor_position()
        current_scroll = buffer.scroll

        current_last_search = self.last_search
        current_last_search_re = self.last_search_re

        def on_change(pattern: str) -> None:
            try:
                buffer.set_cursor_position(current_cur_position)
                if pattern:
                    self.last_search = pattern
                    self.last_search_re = None
                    self.search_re(silent=True)
                    self.adjust_scroll()
                    self.draw()
                else:
                    self.last_search = None
                    self.last_search_re = None
                    self.adjust_scroll()
                    self.draw()

            except Exception:
                pass

        scrolloff_old = config.STATIC_CONFIG.get("scrolloff", 0)
        config.STATIC_CONFIG["scrolloff"] = 8
        try:
            search_term = self.send_prompt(
                "Search: ",
                history=self.search_history,
                on_change=on_change,
                debounce_ms=100,
            )

        finally:
            config.STATIC_CONFIG["scrolloff"] = scrolloff_old

        buffer.set_cursor_position(current_cur_position)
        buffer.scroll = current_scroll

        self.last_search = current_last_search
        self.last_search_re = current_last_search_re

        if search_term:
            if search_term not in self.search_history:
                self.search_history.append(search_term)
            else:
                self.search_history.remove(search_term)
                self.search_history.append(search_term)

            self.last_search = search_term
            self.last_search_re = None
            self.search_re()

    def search_word_under_cursor(self) -> None:
        """
        Grab the word under the cursor (or selected text if single-line),
        set it as last_search, and invoke search().
        """

        buf = self.get_current_buffer()
        self.last_search_re = None

        if self.selection_start:
            start_row, start_col = self.selection_start
            end_row, end_col = buf.cursor_y, buf.cursor_x

            if (start_row, start_col) > (end_row, end_col):
                start_row, start_col, end_row, end_col = (
                    end_row,
                    end_col,
                    start_row,
                    start_col,
                )

            if start_row == end_row:
                line = buf.lines[start_row]
                selected_text = line[start_col:end_col]

                if selected_text:
                    if selected_text not in self.search_history:
                        self.search_history.append(selected_text)
                    else:
                        self.search_history.remove(selected_text)
                        self.search_history.append(selected_text)

                    self.last_search = re.escape(selected_text)
                    self.search_re()
                    return None

        line = buf.lines[buf.cursor_y]
        x = buf.cursor_x

        left = line[:x]
        right = line[x:]

        m1 = re.search(r"\w+$", left)
        m2 = re.match(r"\w+", right)

        word = ""
        if m1:
            word += m1.group(0)
        if m2:
            word += m2.group(0)

        if not word:
            self.send_notification("No word under cursor", 800)
            return None

        if word not in self.search_history:
            self.search_history.append(word)
        else:
            self.search_history.remove(word)
            self.search_history.append(word)

        self.last_search = word
        self.search_re()

    def search(self, silent: bool = False) -> None:
        """
        Search for `self.last_search` in the current buffer, _excluding_
        any match that covers the cursor position on the current line.
        Wraps around once to the top if needed.
        """
        buf = self.get_current_buffer()
        term = self.last_search

        if not term:
            if silent == False:
                self.send_notification("No search term provided", 500)
            return None

        term = term.lower()

        y, x = buf.cursor_y, buf.cursor_x
        n = len(buf.lines)

        self.disable_search = False

        try:
            line = buf.lines[y].lower()
            idx = line.find(term, x + 1)
            if idx != -1:
                buf.cursor_y = y
                buf.cursor_x = idx
                return None

            for i in range(y + 1, n):
                line = buf.lines[i].lower()
                idx = line.find(term)
                if idx != -1:
                    buf.cursor_y = i
                    buf.cursor_x = idx
                    return None

            for i in range(0, y):
                line = buf.lines[i].lower()
                idx = line.find(term)
                if idx != -1:
                    buf.cursor_y = i
                    buf.cursor_x = idx
                    return None
        finally:
            buf.last_cursor_x = buf.cursor_x

        if silent == False:
            self.send_notification("No match found")

    def search_re(self, backwards: bool = False, silent: bool = False) -> None:
        """
        Search for `self.last_search` in the current buffer using `re` (regex),
        excluding matches that include the cursor position.
        Supports forward (default) and backward search with wrapping.
        """
        buf = self.get_current_buffer()
        pattern = self.last_search

        if not pattern:
            if silent == False:
                self.send_notification("No search term provided", 500)
            return None

        y, x = buf.cursor_y, buf.cursor_x
        n = len(buf.lines)
        self.disable_search = False

        if self.last_search_re is None:
            try:
                regex = re.compile(pattern, re.IGNORECASE)
                self.last_search_re = regex
            except Exception:
                self.last_search_re = None
                self.search(silent=silent)
                return None
        else:
            regex = self.last_search_re

        try:

            if not backwards:
                line_text = buf.lines[y]
                for match in regex.finditer(line_text):
                    if match.start() > x:
                        buf.cursor_y = y
                        buf.cursor_x = match.start()
                        return None

                for i in range(y + 1, n):
                    line_text = buf.lines[i]
                    match_s = regex.search(line_text)
                    if match_s:
                        buf.cursor_y = i
                        buf.cursor_x = match_s.start()
                        return None

                for i in range(0, y):
                    line_text = buf.lines[i]
                    match_s = regex.search(line_text)
                    if match_s:
                        buf.cursor_y = i
                        buf.cursor_x = match_s.start()
                        return None
            else:
                line_text = buf.lines[y]
                prev_match = None
                for match in regex.finditer(line_text):
                    if match.start() < x:
                        prev_match = match
                    else:
                        break
                if prev_match:
                    buf.cursor_y = y
                    buf.cursor_x = prev_match.start()
                    return None

                for i in range(y - 1, -1, -1):
                    line_text = buf.lines[i]
                    matches = list(regex.finditer(line_text))
                    if matches:
                        buf.cursor_y = i
                        buf.cursor_x = matches[-1].start()
                        return None

                for i in range(n - 1, y, -1):
                    line_text = buf.lines[i]
                    matches = list(regex.finditer(line_text))
                    if matches:
                        buf.cursor_y = i
                        buf.cursor_x = matches[-1].start()
                        return None
        finally:
            buf.last_cursor_x = buf.cursor_x

        if silent == False:
            self.send_notification("No match found")

    def go_to_line_prompt(self) -> None:
        """
        Prompt user for line number to jump to.
        """
        buffer = self.get_current_buffer()

        _line_number = self.send_prompt("Goto: ")

        if _line_number.isdigit():

            bufffer_len = len(buffer.lines)
            line_number = int(_line_number) - 1

            if line_number < 0:
                line_number = 0
            elif line_number >= bufffer_len:
                line_number = bufffer_len - 1

            if 0 <= line_number < bufffer_len:
                buffer.cursor_y = line_number
                buffer.cursor_x = max(
                    0,
                    min(
                        buffer.cursor_x,
                        len(buffer.lines[buffer.cursor_y]) - 1,
                    ),
                )
        else:

            self.send_notification("Invalid line number")

    def open_buffer(self, file_name: str) -> None:
        res = file_name.split(":")

        if len(res) == 4:
            file_name, _line, _col, message = res
            file = file_name.strip()
            line = int(_line.strip())
            col = int(_col.strip())

        elif len(res) == 3:
            file_name, _line, _col = res
            file = file_name.strip()
            line = int(_line.strip())
            col = int(_col.strip())
            message = ""
        elif len(res) == 2:
            file_name, _line = res
            file = file_name.strip()
            line = int(_line.strip())
            col = 1
            message = ""
        else:
            file = res[0].strip()
            line = 1
            col = 1
            message = ""

        buf_index = self.get_buffer_by_file_name(str(file))

        if buf_index != -1:
            buffer = self.buffers[buf_index]

        else:
            file_path = Path(file_name)

            if not file_path.exists():
                raise FileNotFoundError(f"File '{file_name}' does not exist.")

            buffer = Buffer(str(file_path), temp_dir=self.temp_dir)
            self.buffers.append(buffer)
            buf_index = len(self.buffers) - 1

        buffer.cursor_y = line - 1
        buffer.cursor_x = col - 1

        if message:
            buffer.diagnostics.append(
                hilighing.Diagnostic(
                    line=buffer.cursor_y,
                    char=buffer.cursor_x,
                    code="E",
                    message=message,
                    severity=1,
                )
            )

        self.current_buffer = buf_index

    def open_buffer_prompt(self) -> None:
        """
        Prompt user for a file to open.
        """
        file_name = self.send_prompt("Open file: ")

        if file_name:
            try:
                self.open_buffer(file_name)
            except Exception as e:
                self.send_notification(f"Error opening file: {e}", 2000)

    def select_text_object_prefix(self) -> None:
        scope = self.send_prompt(
            prompt_message="action (a|i): ",
            max_buffer_len=1,
        )

        if not scope or scope not in ("a", "i"):
            return None

        obj = self.send_prompt(
            prompt_message="text object (w|\"|'|(|{|[|<|p): ",
            max_buffer_len=1,
            increment_macro_start=False,
        )

        if not obj:
            return None

        self.select_text_object(scope, obj)

    def select_text_object(self, scope: str, obj: str) -> None:
        if obj == "w":
            self._select_word(scope)
            return None

        if obj == "p":
            self._select_paragraph(scope)
            return None

        pairs = {
            "(": ("(", ")"),
            "{": ("{", "}"),
            "[": ("[", "]"),
            '"': ('"', '"'),
            "'": ("'", "'"),
            "<": ("<", ">"),
        }

        if obj in pairs:
            left, right = pairs[obj]
            self._select_delimited(scope, left, right)

    def _get_selection_bounds(self) -> tuple[tuple[int, int], tuple[int, int]] | None:
        buf = self.get_current_buffer()

        if self.selection_start is None:
            return None

        sy, sx = self.selection_start
        ey, ex = buf.cursor_y, buf.cursor_x

        if (ey, ex) < (sy, sx):
            sy, sx, ey, ex = ey, ex, sy, sx

        return (sy, sx), (ey, ex)

    def _has_selection(self) -> bool:
        bounds = self._get_selection_bounds()
        if not bounds:
            return False

        (sy, sx), (ey, ex) = bounds
        return (sy, sx) != (ey, ex)

    def _range_contains(
        self,
        outer: tuple[tuple[int, int], tuple[int, int]],
        inner: tuple[tuple[int, int], tuple[int, int]],
    ) -> bool:
        (osy, osx), (oey, oex) = outer
        (isy, isx), (iey, iex) = inner
        return (osy, osx) <= (isy, isx) and (iey, iex) <= (oey, oex)

    def _range_strictly_contains(
        self,
        outer: tuple[tuple[int, int], tuple[int, int]],
        inner: tuple[tuple[int, int], tuple[int, int]],
    ) -> bool:
        return self._range_contains(outer, inner) and outer != inner

    def _range_size_key(self, r) -> tuple[int, int, int, int, int, int]:
        (sy, sx), (ey, ex) = r
        return (ey - sy, ex - sx, sy, sx, ey, ex)

    def _set_selection_absolute(
        self, start: tuple[int, int], end: tuple[int, int]
    ) -> None:
        buf = self.get_current_buffer()
        self.selection_start = start
        buf.cursor_y, buf.cursor_x = end
        buf.last_cursor_x = buf.cursor_x

    def _make_selection_bounds(
        self, scope: str, sy: int, sx: int, ey: int, ex: int
    ) -> tuple[tuple[int, int], tuple[int, int]]:
        if scope == "i":
            sx += 1
        else:
            ex += 1
        return (sy, sx), (ey, ex)

    def _apply_delimited_selection(
        self, scope: str, sy: int, sx: int, ey: int, ex: int
    ) -> None:
        start, end = self._make_selection_bounds(scope, sy, sx, ey, ex)
        self._set_selection_absolute(start, end)

    def _is_escaped(self, line: str, i: int) -> bool:
        backslashes = 0
        j = i - 1
        while j >= 0 and line[j] == "\\":
            backslashes += 1
            j -= 1
        return (backslashes % 2) == 1

    def _is_word_char(self, ch: str) -> bool:
        return ch.isalnum() or ch == "_"

    def _select_word(self, scope: str) -> None:
        buf = self.get_current_buffer()
        line = buf.lines[buf.cursor_y]
        x = buf.cursor_x

        for m in re.finditer(r"\w+", line):
            start, end = m.span()

            if start <= x < end:
                if scope == "a":
                    if start > 0 and line[start - 1].isspace():
                        start -= 1
                    if end < len(line) and line[end].isspace():
                        end += 1

                self.selection_start = (buf.cursor_y, start)
                buf.cursor_x = end
                buf.last_cursor_x = buf.cursor_x
                return None

    def _select_paragraph(self, scope: str) -> None:
        buf = self.get_current_buffer()
        y = buf.cursor_y
        lines = buf.lines
        n = len(lines)

        start = y
        end = y

        while start > 0 and lines[start].strip():
            start -= 1

        if not lines[start].strip():
            start += 1

        while end < n and lines[end].strip():
            end += 1

        if scope == "a":
            if start > 0:
                start -= 1
            if end < n:
                end += 1

        self.selection_start = (start, 0)
        buf.cursor_y = max(start, min(end, n - 1))
        buf.cursor_x = 0
        buf.last_cursor_x = 0

    def _select_delimited(self, scope: str, left: str, right: str) -> None:
        buf = self.get_current_buffer()
        lines = buf.lines

        if not lines:
            return None

        selection_bounds = (
            self._get_selection_bounds() if self._has_selection() else None
        )

        if selection_bounds:
            expanded = self._find_expanded_delimited(
                scope, left, right, selection_bounds
            )
            if expanded:
                self._set_selection_absolute(expanded[0], expanded[1])
                return None

        y = buf.cursor_y
        x = buf.cursor_x

        result = self._find_delimited_same_line(lines[y], x, left, right)
        if result:
            sx, ex = result
            self._apply_delimited_selection(scope, y, sx, y, ex)
            return None

        if left == right:
            return None

        result_m = self._find_delimited_multiline(lines, y, x, left, right)
        if result_m:
            (sy, sx), (ey, ex) = result_m
            self._apply_delimited_selection(scope, sy, sx, ey, ex)

    def _find_expanded_delimited(
        self,
        scope: str,
        left: str,
        right: str,
        current_selection: tuple[tuple[int, int], tuple[int, int]],
    ) -> tuple[tuple[int, int], tuple[int, int]] | None:
        buf = self.get_current_buffer()
        lines = buf.lines
        inner = current_selection
        (csy, csx), (cey, cex) = inner

        candidates = []

        if left == right:
            if csy != cey:
                return None

            line = lines[csy]
            pairs = self._find_all_same_line_pairs(line, left, right)

            for a, b in pairs:
                sel = self._make_selection_bounds(scope, csy, a, csy, b)
                if self._range_strictly_contains(sel, inner):
                    candidates.append(sel)

            if not candidates:
                return None

            return min(candidates, key=self._range_size_key)

        for (sy, sx), (ey, ex) in self._find_all_multiline_pairs(lines, left, right):
            sel = self._make_selection_bounds(scope, sy, sx, ey, ex)
            if self._range_strictly_contains(sel, inner):
                candidates.append(sel)

        if not candidates:
            return None

        return min(candidates, key=self._range_size_key)

    def _find_delimited_same_line(
        self, line: str, x: int, left: str, right: str
    ) -> tuple[int, int] | None:
        """
        Search the whole current line and choose the best candidate:
        1) smallest pair containing cursor
        2) nearest pair to the left
        3) nearest pair to the right
        """
        if not line:
            return None

        x = max(0, min(x, len(line) - 1))

        pairs = self._find_all_same_line_pairs(line, left, right)
        if not pairs:
            return None

        if left == right:
            containing = [(a, b) for a, b in pairs if a < x < b]
        else:
            containing = [(a, b) for a, b in pairs if a <= x <= b]

        if containing:
            return min(containing, key=lambda t: (t[1] - t[0], t[0]))

        exact = [(a, b) for a, b in pairs if a == x or b == x]
        if exact:
            return min(exact, key=lambda t: (t[1] - t[0], t[0]))

        left_side = [(a, b) for a, b in pairs if b < x]
        if left_side:
            return max(left_side, key=lambda t: (t[1], t[0]))

        right_side = [(a, b) for a, b in pairs if a > x]
        if right_side:
            return min(right_side, key=lambda t: (t[0], t[1]))

        return None

    def _find_all_same_line_pairs(
        self, line: str, left: str, right: str
    ) -> list[tuple[int, int]]:
        if not line:
            return []

        if left == right:
            quote_positions = []

            for i, c in enumerate(line):
                if c != left:
                    continue

                if self._is_escaped(line, i):
                    continue

                if left == "'":
                    prev_ch = line[i - 1] if i > 0 else ""
                    next_ch = line[i + 1] if i + 1 < len(line) else ""
                    if self._is_word_char(prev_ch) and self._is_word_char(next_ch):
                        continue

                quote_positions.append(i)

            pairs = []
            i = 0
            while i + 1 < len(quote_positions):
                pairs.append((quote_positions[i], quote_positions[i + 1]))
                i += 2

            return pairs

        stack = []
        pairs = []

        for i, c in enumerate(line):
            if c == left:
                stack.append(i)
            elif c == right and stack:
                start = stack.pop()
                pairs.append((start, i))

        return pairs

    def _find_delimited_multiline(
        self, lines: Sequence[str | RichString], y: int, x: int, left: str, right: str
    ) -> tuple[tuple[int, int], tuple[int, int]] | None:
        start = None
        depth = 0

        for row in range(y, -1, -1):
            line = lines[row]

            if not line:
                continue

            if row == y:
                i = min(x, len(line) - 1)
            else:
                i = len(line) - 1

            while i >= 0:
                c = line[i]

                if c == left:
                    if depth == 0:
                        start = (row, i)
                        break
                    depth -= 1
                elif c == right:
                    depth += 1

                i -= 1

            if start:
                break

        if not start:
            return None

        sy, sx = start
        depth = 0
        end = None

        for row in range(sy, len(lines)):
            line = lines[row]

            if row == sy:
                i = sx + 1
            else:
                i = 0

            while i < len(line):
                c = line[i]

                if c == right:
                    if depth == 0:
                        end = (row, i)
                        break
                    depth -= 1
                elif c == left:
                    depth += 1

                i += 1

            if end:
                break

        if not end:
            return None

        return start, end

    def _find_all_multiline_pairs(
        self, lines: Sequence[str | RichString], left: str, right: str
    ) -> list[tuple[tuple[int, int], tuple[int, int]]]:
        pairs = []
        stack = []

        for row, line in enumerate(lines):
            for col, c in enumerate(line):
                if c == left:
                    stack.append((row, col))
                elif c == right and stack:
                    start = stack.pop()
                    pairs.append((start, (row, col)))

        return pairs

    def page_up(self) -> None:
        buffer = self.get_current_buffer()
        buffer.page_up(self.height)

    def page_down(self) -> None:
        buffer = self.get_current_buffer()
        buffer.page_down(self.height)

    def move_scroll(self, direction: int, move_cursor: bool = True) -> None:
        buffer = self.get_current_buffer()
        buffer.move_scroll(direction, self.height, move_cursor)

    def run_code_with_eval(
        self, code: str, timeout: int = 20
    ) -> tuple[Any, str] | None:
        from concurrent import interpreters

        interp = interpreters.create()
        interp_queue = cast(Queue[Any], interpreters.create_queue())

        try:
            t = interp.call_in_thread(_run_code, code, interp_queue)
            t.join(timeout=timeout)

            result = interp_queue.get(timeout=10)

            return result

        except Exception as e:
            self.send_multiline_notification(f"{e}\n{traceback.format_exc()}", -1)

        finally:
            interp.close()

        return None

    def show_line_diagnostics(self) -> None:
        buffer = self.get_current_buffer()

        y, x = buffer.get_cursor_position()

        diags = []

        for d in getattr(buffer, "diagnostics", []):
            if d.line == y:
                diags.extend(
                    textwrap.wrap(f"{d.code}:{d.message}", int(self.width / 2))
                )

        text = "\n".join(diags)

        open_file_in_less_mode(
            window=self.stdscr, file_handle=StringIO(text), editor=self
        )

    def get_prefix(self) -> str:
        buf = self.get_current_buffer()

        prefix = ""

        try:
            left = buf.lines[buf.cursor_y][: buf.cursor_x]
            m_obj = re.search(r"(\w+)\.$", left)
            if not m_obj:
                m_pref = re.search(r"\b\w+$", left)
                if m_pref:
                    prefix = m_pref.group(0)
        except Exception as e:
            self.send_notification(
                f"Error getting the prefix, \n{traceback.format_exc()}"
            )

        return prefix

    def show_suggestions(self, lsp_matches: Optional[set[str]] = None) -> None:
        buf = self.get_current_buffer()

        if lsp_matches is None:
            lsp_matches = set()

            full_text = "\n".join(
                line
                for buffer in self.buffers
                if not buffer.first
                for line in buffer.get_lines()
            )
        else:
            full_text = "\n".join(buf.get_lines())

        line = buf.lines[buf.cursor_y]
        left = line[: buf.cursor_x]

        prefix = ""

        text_matches = set()
        file_matches = set()

        m_obj = re.search(r"(\w+)\.$", left)
        if m_obj:
            obj_name = m_obj.group(1)
            members = set(re.findall(rf"\b{re.escape(obj_name)}\.(\w+)\b", full_text))
            text_matches = members
        else:
            m_pref = re.search(r"\b\w+$", left)
            if m_pref:
                prefix = m_pref.group(0)

            words = set(re.findall(r"\b\w+\b", full_text))
            text_matches = {w for w in words if w.startswith(prefix) and w != prefix}

        in_string = re.search(r'(["\'])([^"\']*)$', left)

        if in_string:
            file_prefix = in_string.group(2)

            working_dir = str(config.WORKING_DIR)

            base_dir = None

            buffer_dir = None

            if hasattr(buf, "file_path"):
                if getattr(buf, "file_path", None):
                    buffer_dir = str(buf.file_path.parent)

            if file_prefix.startswith("./") and buffer_dir:
                base_dir = buffer_dir

            else:
                dirpart = os.path.dirname(file_prefix)

                if dirpart:
                    if os.path.isabs(dirpart):
                        base_dir = dirpart

                    else:
                        base_dir = os.path.abspath(os.path.join(working_dir, dirpart))
                else:
                    base_dir = working_dir

            if not os.path.isdir(base_dir):
                base_dir = working_dir

            try:
                for name in os.listdir(base_dir):
                    if name.startswith("."):
                        continue

                    path = os.path.join(base_dir, name)

                    if name.startswith(os.path.basename(file_prefix)):
                        if os.path.isdir(path):
                            file_matches.add(name + "/")
                        else:
                            file_matches.add(name)
            except Exception:
                pass

        lsp_matches = {f"{m} - lsp" for m in lsp_matches}
        file_matches = {f"{m} - file" for m in file_matches}
        text_matches = {f"{m} - text" for m in text_matches}

        matches = [*lsp_matches, *file_matches, *text_matches]

        if not matches or len(matches) == 0 or not any(bool(m) for m in matches):
            return

        def filtering_controller(
            query: str, choises: list[dict[str, Any]]
        ) -> list[dict[str, Any]]:
            """
            Custom filtering callback used by the picker.
            Unlike compare_func-based filtering, this preserves fuzzy behavior and caching.
            """
            _choises = [el["display"] for el in choises]

            if not query:
                return _choises

            return fzf_fuzzy_find(query=query, choices=_choises, limit=-1)

        break_chars = None

        if buf.suffix is not None and (lsp_client := get_lsp(buf.suffix)) is not None:
            break_chars = lsp_client.triggerCharacters.copy()

            for ch in string.punctuation:
                if ch == "_":
                    continue

                break_chars.add(ch)

        selected = self.show_picker_display(
            entries=matches,
            display_func=lambda x: x,
            compare_func=lambda x, q: True,
            position=buf.get_cursor_position_display(),
            max_height=15,
            initial_query=prefix if prefix else None,
            return_query=True,
            break_chars=break_chars,
            external_filter=filtering_controller,
        )

        if selected is not None:
            choice = selected.split("-")[0].strip()

            if len(prefix) > 0:
                cur_pos = buf.get_cursor_position()

                rep_pos = CursorPosition(y=cur_pos.y, x=cur_pos.x - len(prefix))

                action = BufferAction(
                    action_type=BufferActionTypeEnum.REPLACE,
                    content=(prefix, choice),
                    cursor_position=rep_pos,
                )
            else:
                action = BufferAction(
                    action_type=BufferActionTypeEnum.INSERT,
                    content=choice,
                    cursor_position=buf.get_cursor_position(),
                )

            self.apply_action_to_buffer(action)

        self.adjust_scroll()

    def show_file_picker(self) -> None:
        """
        Interactive fuzzy file picker using the improved generic picker.
        Behavior matches original:
            - Search updates with debounce
            - Fuzzy file search
            - <no matches> placeholder
            - Switches to existing buffer if open
            - Otherwise opens file
        """

        root = os.getcwd()

        needs_rescan = (
            self.fuzzy_changed or self.working_dir_mtime != self.get_working_dir_mtime()
        )

        if needs_rescan:
            self.send_notification(
                f"Scanning for {self.working_dir.absolute()} for changes...", 200
            )
            self.working_dir_mtime = self.get_working_dir_mtime()

        all_files = collect_files_with_gitignore(root, self.fuzzy_search, needs_rescan)

        self.fuzzy_search = all_files
        self.fuzzy_changed = False

        def filtering_controller(
            query: str, choises: list[dict[str, Any]]
        ) -> list[dict[str, Any]]:
            """
            Custom filtering callback used by the picker.
            Unlike compare_func-based filtering, this preserves fuzzy behavior and caching.
            """
            _choises = [el["display"] for el in choises]

            if not query:
                return _choises

            return fzf_fuzzy_find(query=query, choices=_choises)

        selected = self.show_picker_display(
            entries=all_files,
            display_func=lambda x: x,
            compare_func=lambda x, q: True,
            external_filter=filtering_controller,
            debounce_ms=400,
        )

        if not selected or selected == "<no matches>":
            return None

        full_path = os.path.abspath(os.path.join(root, selected))
        cwd = os.getcwd()

        rel = os.path.relpath(full_path, cwd)

        for buffer_index, buf in enumerate(self.buffers):
            if buf.file_name and buf.file_name == rel:
                self.current_buffer = buffer_index
                self.send_notification(f"Switched to buffer: {selected}")
                return None

        self.open_buffer(rel)
        self.send_notification(f"Opened file: {selected}")

    def show_theme_picker(self) -> None:
        """
        Use the generic picker to select buffers.
        """

        if not self.syntax_enable or len(themes.default.BUILDIN_THEMES.keys()) <= 0:
            self.send_notification("Can not apply themes.")
            return

        def display(theme_name: Any) -> str:
            return str(theme_name)

        def compare(theme_name: Any, query: str) -> bool:
            if not query:
                return True
            return query.lower() in display(theme_name).lower()

        def selection_change(theme_name: Optional[Any] = None) -> None:
            if (
                theme_name is not None
                and isinstance(theme_name, str)
                and theme_name != "random"
            ):
                themes.default.BUILDIN_THEMES[theme_name].apply_theme()

        prev_theme = config.STATIC_CONFIG.get("current_theme", "default")

        choice = self.show_picker_display(
            entries=[*sorted(list(themes.default.BUILDIN_THEMES.keys())), "random"],
            display_func=display,
            compare_func=compare,
            selection_change=selection_change,
        )

        if choice is not None and choice:
            if choice == "random":
                choice = themes.default.pick_random_theme(name_only=True)

            config.STATIC_CONFIG["current_theme"] = choice
            themes.default.BUILDIN_THEMES[str(choice)].apply_theme()
            save_static_config()

        else:
            themes.default.BUILDIN_THEMES[prev_theme].apply_theme()

    def show_buffer_picker(self) -> None:
        """
        Use the generic picker to select buffers.
        """

        if not self.buffers:
            self.send_notification("No buffers open.", 1000)
            return

        def display(buf):
            return buf.file_name or "[No Name]"

        choice = self.show_picker_display(
            entries=self.buffers,
            display_func=display,
        )

        if choice is not None:
            for i, buf in enumerate(self.buffers):
                if buf is choice:
                    self.current_buffer = i
                    self.send_notification(f"Switched to: {display(buf)}")
                    break

    def show_ai_completion_picker(self) -> None:
        all_ai_completions = list(
            itertools.chain.from_iterable(
                buf.ai_completions for buf in self.buffers if not buf.first
            )
        )

        if not all_ai_completions:
            self.send_notification("There is no ai completions to show", 1000)
            return None

        def display(c):
            return (
                str(self.ai_completion_manager.get_job(c.code))[: self.width]
                or "[No Name]"
            )

        choice = self.show_picker_display(
            entries=all_ai_completions,
            display_func=display,
        )

        if choice is not None:
            self.draw()

            output = self.ai_completion_manager.get_result(choice.code)

            found = False

            for i, b in enumerate(self.buffers):
                if b.first:
                    continue

                for bc in b.ai_completions:
                    if bc.code == choice.code:
                        self.current_buffer = i
                        b.set_cursor_position(
                            CursorPosition(y=choice.line, x=choice.char)
                        )
                        found = True
                        break

                if found:
                    break

            if output:
                output = output.strip("\n")

                open_file_in_less_mode(
                    window=self.stdscr, file_handle=StringIO(output), editor=self
                )

                if self.send_prompt_confirm("insert completion?:"):
                    self.insert_char(output, disable_autocomplete=True)

                elif self.send_prompt_confirm("open in new buffer?:"):
                    self.open_untitled_buffer(output, lexer=MarkdownLexer())

    def show_ai_model_picker(self) -> None:
        models = completions.get_available_models()

        if not models:
            self.send_notification("There is no ai models install.", 1000)
            return None

        choice = self.show_picker_display(entries=models)

        if choice is not None:
            config.STATIC_CONFIG["model"] = choice

    def show_command_picker(self) -> None:

        def _display(cmd):
            alt_names = cmd["alt_names"]

            if alt_names is not None and len(alt_names) > 0:
                str_alt_names = ",".join(alt_names)
                return (
                    f"{cmd["name"]}: {cmd["description"]}, alt names =({str_alt_names})"
                )
            else:
                return f"{cmd["name"]}: {cmd["description"]}"

        choice = self.show_picker_display(
            entries=config.COMMANDS, display_func=_display
        )

        if choice is not None and isinstance(choice, dict):
            self.command_mode_mappings(command=choice["name"])

    def show_jump_picker(self) -> None:
        if not self.jump_list:
            self.send_notification("There is not jumps recorded.")

        def _display(j):
            return f"{j.buffer_name}, y={j.position.y}, x={j.position.x}, timestamp={int(j.timestamp)}"

        jump = self.show_picker_display(
            entries=list(reversed(self.jump_list)), display_func=_display
        )

        if jump is not None:
            self.disable_record_jump = True

            buffer_index = self.get_buffer_by_file_name(jump.buffer_name)

            if buffer_index == -1:
                self.send_notification("Buffer not found.")
                return None

            self.current_buffer = buffer_index

            buffer = self.buffers[buffer_index]
            buffer.set_cursor_position(position=jump.position)

    def go_to_jump(self, direction: int) -> None:
        if not self.jump_list:
            self.send_notification("There is not jumps recorded.")

        jump = None

        if direction > 0:
            if self.jump_index >= len(self.jump_list) - 1:
                return None

            self.jump_index += 1

            jump = self.jump_list[self.jump_index]

        else:
            if self.jump_index <= 0:
                return None

            if (
                self.jump_index == len(self.jump_list)
                and self.last_jump is not None
                and self.last_jump != self.jump_list[self.jump_index - 1]
            ):
                self.jump_list.append(self.last_jump)
                self.jump_index -= 2
            else:
                self.jump_index -= 1

            jump = self.jump_list[self.jump_index]

        if jump is not None:
            self.disable_record_jump = True

            buffer_index = self.get_buffer_by_file_name(jump.buffer_name)

            if buffer_index == -1:
                self.send_notification("Buffer not found.")
                return None

            self.current_buffer = buffer_index

            buffer = self.buffers[buffer_index]
            buffer.set_cursor_position(position=jump.position)

    def show_references_picker(self, references: list[dict]) -> None:
        """
        Use the generic picker to select buffers.
        """
        if not references:
            return None

        if not self.buffers:
            self.send_notification("No buffers open.", 1000)
            return

        def display(buf: dict[str, Any]) -> str:
            display_line = "[No Name]"
            match buf:
                case {
                    "uri": uri,
                    "range": {
                        "start": {
                            "line": start_line,
                            "character": start_char,
                        },
                        "end": _,
                    },
                }:

                    file_path = self.get_path_from_uri(uri)

                    if file_path is None:
                        return display_line

                    file_name = file_path.relative_to(Path.cwd())

                    buf_index = self.get_buffer_by_file_name(str(file_name))

                    if buf_index != -1:
                        buffer = self.buffers[buf_index]
                        display_line = f"{buffer.file_name}[{start_line}] - {buffer.lines[start_line]}"

                case _:
                    pass

            return display_line

        def compare(buf, query):
            if not query:
                return True
            return query.lower() in display(buf).lower()

        choice = self.show_picker_display(
            entries=references,
            display_func=display,
            compare_func=compare,
        )

        if choice is not None:
            for i, ref in enumerate(references):
                if ref is choice:
                    match ref:
                        case {
                            "uri": uri,
                            "range": {
                                "start": {
                                    "line": start_line,
                                    "character": start_char,
                                },
                                "end": _,
                            },
                        }:

                            _file_path = self.get_path_from_uri(uri)

                            if _file_path is None:
                                self.send_notification("Could not find the reference.")
                                return None

                            file_name = _file_path.relative_to(Path.cwd())
                            buf_index = self.get_buffer_by_file_name(str(file_name))

                            if buf_index == -1:
                                new_buffer = Buffer(
                                    file_name=str(file_name),
                                    temp_dir=self.temp_dir,
                                )
                                self.buffers.append(new_buffer)
                                self.current_buffer = len(self.buffers) - 1
                            else:
                                self.current_buffer = buf_index

                            buffer = self.get_current_buffer()

                            buffer.cursor_y = start_line
                            buffer.cursor_x = start_char
                        case _:
                            self.send_notification(
                                "Error: Invalid definition result format."
                            )

                    break

    def show_picker_display(
        self,
        entries: list[Any],
        display_func: Optional[Callable[[Any], str]] = None,
        compare_func: Optional[Callable[[Any, str], bool]] = None,
        external_filter: Optional[
            Callable[[str, list[dict[str, Any]]], list[dict[str, Any]]]
        ] = None,
        selection_change: Optional[Callable[[Optional[Any]], None]] = None,
        debounce_ms: Optional[int] = None,
        increment_macro_start: bool = True,
        position: Optional[tuple[int, int]] = None,
        max_height: Optional[int] = None,
        return_query: bool = False,
        break_chars: Optional[set[str]] = None,
        initial_query: Optional[str] = None,
    ) -> Optional[Any]:
        """
        Dynamic picker UI (scrollable, searchable).
        Debounce DOES NOT trigger immediately on the first keystroke.
        """

        return show_picker_display(
            window=self.stdscr,
            entries=entries,
            display_func=display_func,
            compare_func=compare_func,
            external_filter=external_filter,
            selection_change=selection_change,
            debounce_ms=debounce_ms,
            increment_macro_start=increment_macro_start,
            position=position,
            max_height=max_height,
            return_query=return_query,
            break_chars=break_chars,
            initial_query=initial_query,
            editor=self,
        )

    def go_next_buffer(self) -> None:
        if len(self.buffers) <= 1:
            self.send_notification("No more buffers")

        if (self.current_buffer + 1) >= len(self.buffers):
            self.current_buffer = 0
        else:
            self.current_buffer += 1

    def go_prev_buffer(self) -> None:
        if len(self.buffers) <= 1:
            self.send_notification("No more buffers")

        if (self.current_buffer - 1) < 0:
            self.current_buffer = len(self.buffers) - 1
        else:
            self.current_buffer -= 1

    def go_to_last_buffer(self) -> None:
        self.change_modes(mode="NORMAL")

        if self.last_buffer < 0 or self.last_buffer >= len(self.buffers):
            self.last_buffer = self.current_buffer

        self.current_buffer = self.last_buffer
        self.get_current_buffer().adjust_cursor_position()

    def close_buffer(self) -> None:
        buffer = self.get_current_buffer()

        if not self.send_prompt_confirm(
            (
                "This buffer have unsave changes, are you sure you want to close it?"
                if buffer.modified
                else "Do you want o close this buffer?"
            ),
            color_p=15,
        ):
            return None

        buffer.undo_manager.cleanup()

        if len(self.buffers) > 1:
            if buffer.suffix is not None:
                lsp_client = get_lsp(buffer.suffix)

                if lsp_client:
                    lsp_client.did_close(get_uri_from_name(buffer.file_name))

            del self.buffers[self.current_buffer]

            self.current_buffer = min(self.current_buffer, len(self.buffers) - 1)
        else:
            self.new_buffer_count += 1

            new_buffer = Buffer(
                f"Untitled-{self.new_buffer_count}",
                new_buffer_untitled=True,
                temp_dir=self.temp_dir,
            )

            self.buffers[self.current_buffer] = new_buffer

    def select_hole_file(self) -> None:
        buf = self.get_current_buffer()

        self.selection_start = (0, 0)

        buf.cursor_x = len(buf.lines[-1])
        buf.cursor_y = len(buf.lines) - 1

    def record_macro(self) -> None:
        if self.recording_macro and self.current_macro_recording is not None:
            self.recording_macro = False
            self.macros[self.current_macro_recording].pop()
            self.current_macro_recording = None
            return None

        macro_name = self.send_prompt("record macro: ")

        if not macro_name:
            return None

        if len(macro_name.split()) > 1:
            self.send_notification("Not a valid name")
            return None

        self.macros[macro_name] = []
        self.recording_macro = True
        self.current_macro_recording = macro_name

    def exec_macro(self) -> None:
        macro_name = self.send_prompt("exec macro: ")

        if not macro_name:
            return None

        args = macro_name.split()

        if len(args) > 1:
            macro_name = args[0]
            times = int(args[1])
        else:
            macro_name = args[0]
            times = 1

        def check_cancel() -> bool:
            # self.stdscr.timeout(0)
            self.stdscr.nodelay(True)
            ch = self.stdscr.getch()

            if ch == 27:  # ESC
                return True

            return False

        if macro_name in self.macros:
            steps = self.macros.get(macro_name, [])
            self.current_macro_playing_name = macro_name
            step_count = len(steps)

            original_escdelay = curses.get_escdelay()
            curses.set_escdelay(1)

            try:
                if (
                    self.send_prompt_confirm_multiline(
                        "\n".join(
                            f"{i}. {str(s)}" for i, s in enumerate(steps, start=1)
                        ),
                        f"Macro {macro_name=}, {step_count=} will be executed {times=}, Press ESC to stop execution after it has started, continue?",
                    )
                    == False
                ):
                    return None

                for _ in range(times):

                    self.current_macro_playing_index = None

                    for index, step in enumerate(steps):

                        if check_cancel():
                            return None

                        if (
                            self.current_macro_playing_index is not None
                            and self.current_macro_playing_name is not None
                            and index < self.current_macro_playing_index
                        ):
                            continue

                        self.current_macro_playing_index = index
                        self.process_key(step)
                        self.adjust_scroll()
                        self.draw()

            except Exception as e:
                self.send_multiline_notification(
                    f"Error: {e},\n{traceback.format_exc()}", 0
                )

            finally:
                self.current_macro_playing_name = None
                self.current_macro_playing_index = None
                curses.set_escdelay(original_escdelay)


@lru_cache(maxsize=1)
def check_is_wsl() -> bool:
    is_wsl = False
    if sys.platform.startswith("linux"):
        try:
            with open("/proc/version", "r") as f:
                is_wsl = "microsoft" in f.read().lower()
        except Exception:
            pass

    return is_wsl


@lru_cache(maxsize=1)
def check_is_ssh() -> bool:
    return any(k in os.environ for k in ("SSH_CONNECTION", "SSH_CLIENT", "SSH_TTY"))


async def arun_editor(editor: SimpleEditor) -> None:
    try:
        async with asyncio.TaskGroup() as tg:
            await editor.run(tg)
    except asyncio.CancelledError:
        return None


def run_editor(
    stdscr,
    file_names: list[str],
    theme: str,
    debug=False,
    without_session: bool = False,
    as_text: bool = False,
) -> None:
    with tempfile.TemporaryDirectory() as temp_dir:
        editor = SimpleEditor(
            stdscr,
            file_names,
            theme,
            debug=debug,
            temp_dir=temp_dir,
            without_session=without_session,
            as_text=as_text,
        )
        asyncio.run(arun_editor(editor))


def main() -> None:

    config.load_user_lsp_config()

    parser = argparse.ArgumentParser(
        prog="denary",
        description="""
            A modal terminal editor built on curses with a command-driven,
            event-based architecture and chunked text storage.

            Includes syntax highlighting, multi-buffer management,
            registers and markers, undo/redo history, Git integration,
            async LSP support, subprocess execution, and HTTP requests.
            """,
    )

    parser.add_argument("file_names", nargs="*")

    parser.add_argument(
        "-p",
        "--profile",
        action="store_true",
        help="Enable profiling",
    )

    parser.add_argument(
        "-d",
        "--debug",
        action="store_true",
        help="Enable debug mode, it will store the codes of the key pressed in a file",
    )

    parser.add_argument(
        "--without-session",
        action="store_true",
        help="this disable storing a session json",
    )

    VISIBLE_THEMES = list(themes.default.BUILDIN_THEMES.keys())[:10]

    parser.add_argument(
        "-t",
        "--theme",
        default="current",
        metavar="THEME",
        help=f"Select theme (examples: {', '.join(VISIBLE_THEMES)})",
    )

    parser.add_argument(
        "--list-themes",
        action="store_true",
        help="Show all available themes and exit",
    )

    parser.add_argument(
        "--colors",
        action="store_true",
        help="shows the colors default colors in terminal and their number siminar to less",
    )

    parser.add_argument(
        "--as-text", action="store_true", help="disables hilighting for buffers"
    )

    parser.add_argument(
        "--version",
        action="store_true",
        help="Show Denary version and exit",
    )

    args = parser.parse_args()

    if args.list_themes:
        print("Available themes:")
        for index, name in enumerate(
            sorted(themes.default.BUILDIN_THEMES.keys()), start=1
        ):
            print(f"{index}) ", name)
        raise SystemExit(0)

    if args.colors:
        from denary import display_colors

        display_colors.main()
        exit(0)

    if args.version:
        from importlib.metadata import PackageNotFoundError, version

        try:
            print(f"denary {version('denary')}")
        except PackageNotFoundError:
            print("denary (development version)")
        sys.exit(0)

    if args.debug:
        with open("seq.txt", "w", encoding="utf-8") as f:
            f.write("")

    if args.profile:

        import cProfile

        with cProfile.Profile() as pr:
            if not CURRENT_PLATFORM.startswith("win"):
                signal.signal(signal.SIGCONT, handle_cont)

            curses.wrapper(
                lambda s: run_editor(
                    s,
                    args.file_names,
                    args.theme,
                    debug=args.debug,
                    without_session=args.without_session,
                    as_text=args.as_text,
                )
            )

            pr.print_stats()
            pr.dump_stats("editor.prof")

    else:
        if not CURRENT_PLATFORM.startswith("win"):
            signal.signal(signal.SIGCONT, handle_cont)

        curses.wrapper(
            lambda s: run_editor(
                s,
                args.file_names,
                args.theme,
                debug=args.debug,
                without_session=args.without_session,
                as_text=args.as_text,
            )
        )


def handle_cont(signum, frame) -> None:
    curses.raw()


if __name__ == "__main__":
    main()
