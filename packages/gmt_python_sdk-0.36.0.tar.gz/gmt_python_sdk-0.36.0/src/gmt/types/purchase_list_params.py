# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

__all__ = ["PurchaseListParams"]


class PurchaseListParams(TypedDict, total=False):
    page: Required[int]
    """Page number."""

    page_size: Required[int]
    """Number of items per page."""

    sort: Required[Literal["date_asc", "date_desc"]]
    """Sort purchases by creation date"""

    phone_number: str
    """Filter purchases by phone number fragment (partial match).

    Example: '123' matches '+71234567890'.
    """

    status: Literal["PENDING", "SUCCESS", "ERROR", "REFUND", "EXPIRED"]
    """
    **Purchase Status Lifecycle.** `PENDING` (initial) → `SUCCESS` (after code
    request) or `ERROR` (provider failure). Any status can transition to `REFUND`
    via admin action.

    **Important.** Status is immutable once set to `SUCCESS`, `ERROR`, or `REFUND`.

    **Filter options**

    - `PENDING` - code not requested.
    - `SUCCESS` - code ready.
    - `ERROR` - provider failed.
    - `REFUND` - money returned.
    """
