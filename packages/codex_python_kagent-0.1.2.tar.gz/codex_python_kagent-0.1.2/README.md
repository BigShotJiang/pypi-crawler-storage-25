# kagent

Async Python SDK for running Codex-backed coding-agent tasks with a small, memorable thread API.

The PyPI distribution is `codex-python-kagent`; the import package is `kagent`.

```python
import asyncio

from kagent import kagent


async def main() -> None:
    agent = kagent()
    run = await agent.thread("main").run("Create hello.txt with exactly: hello")
    print(run.text)


asyncio.run(main())
```

## Status

`kagent` is experimental. It wraps the local Codex CLI/app-server flow and currently depends on
the experimental OpenAI Codex Python SDK for `runner="sdk"`.

The package itself has no required runtime dependencies so it can be built and published cleanly.
The default runner uses the Codex CLI. The experimental Codex Python SDK is kept in a local uv
dependency group instead of PyPI metadata.

## Install

In a uv project:

```bash
uv add codex-python-kagent
kagent login
```

For API-key auth instead of ChatGPT subscription auth:

```bash
export OPENAI_API_KEY="sk-..."
kagent login --api-key-env OPENAI_API_KEY
```

For local development in this repo:

```bash
uv sync --group dev --group codex --group examples
```

The local machine must also have the Codex CLI installed and authenticated:

```bash
codex login status
```

## API

Use `kagent(...)` when you already authenticated with `kagent login` or `codex login`.

```python
from kagent import kagent

agent = kagent(workspace=".", model="gpt-5.5")
thread = agent.thread("refactor-auth")
await thread.run("Refactor auth.py without changing behavior.")
await thread.run("Now run the tests and fix any failures.")
```

Or trigger Codex auth from Python, inspired by OpenHands-style login constructors:

```python
import os

from kagent import kagent

agent = kagent.login(model="gpt-5.5")
api_agent = kagent.login(model="gpt-5.5", api_key=os.environ["OPENAI_API_KEY"])
```

Options:

```python
kagent(
    workspace=".",
    model="gpt-5.5",
    runner="cli",
    ask_for_approval="never",
    sandbox="danger-full-access",
    skip_git_repo_check=True,
    yolo=True,
    codex_bin=None,
    store_path=None,
)
```

`agent.thread(id, ...)` requires a human-readable id. `kagent` maps that id to Codex's generated
session id using a local `shelve` store at `.kagent/threads` inside the workspace.

`runner="cli"` uses `codex exec` through an async subprocess. It stores Codex's generated
session id in `.kagent/threads`, then uses `codex exec resume` on later runs with the same
human-readable `Thread` id.

`runner="sdk"` uses the experimental Codex app-server SDK and persistent threads. It requires the
local development `codex` dependency group.

```python
agent = kagent(model="gpt-5.5", runner="cli", yolo=True)

await agent.thread("goal-test").run(
    "Create hello.txt with exactly the text hello.",
    goal=True,
)
```

There is no native `codex exec --goal` flag. `goal=True` translates to a prompt beginning with
`/goal ...`, which is the behavior verified locally. Goal runs use the CLI runner, not app-server
SDK thread persistence.

`yolo=True` maps to Codex's `--dangerously-bypass-approvals-and-sandbox` flag.

## Examples

Run the Codex example:

```bash
uv run --group codex python examples/codex_thread.py
```

Run the OpenHands comparison example:

```bash
uv run --group examples python examples/openhands_thread.py
```

OpenHands may require interactive ChatGPT subscription login on first run.

## Development

```bash
uv sync --group dev --group codex --group examples
uv run pytest
uv run ruff check .
uv run mypy
uv build
```

Publish:

```bash
export UV_PUBLISH_TOKEN="pypi-..."
uv build
uv publish
```

The package uses:

- `src/` layout
- `hatchling` build backend
- MIT license
- `py.typed` for typed package consumers
- `uv.lock` committed for reproducible local development
- pytest, ruff, and mypy for validation

## License

MIT
