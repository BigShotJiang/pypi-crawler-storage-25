"""Small command line helpers for kagent."""

from __future__ import annotations

import argparse
import sys
from collections.abc import Sequence
from typing import cast

from kagent import KagentError, kagent


def main(argv: Sequence[str] | None = None) -> int:
    """Run the kagent command line interface."""

    parser = _parser()
    args = parser.parse_args(argv)

    if args.command == "login":
        return _login(args)
    if args.command == "status":
        return _status(args)
    if args.command == "logout":
        return _logout(args)

    parser.print_help()
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="kagent")
    parser.add_argument("--codex-bin", default=None, help="Path to the Codex CLI executable.")

    subparsers = parser.add_subparsers(dest="command")

    login = subparsers.add_parser("login", help="Log in through the Codex CLI.")
    login.add_argument(
        "--api-key",
        default=None,
        help="Persist an OpenAI API key through `codex login --with-api-key`.",
    )
    login.add_argument(
        "--api-key-env",
        default=None,
        help="Read an API key from this environment variable.",
    )

    subparsers.add_parser("status", help="Show Codex login status.")
    subparsers.add_parser("logout", help="Remove Codex login credentials.")

    return parser


def _login(args: argparse.Namespace) -> int:
    try:
        kagent.login(
            api_key=cast("str | None", args.api_key),
            api_key_env=cast("str | None", args.api_key_env),
            codex_bin=cast("str | None", args.codex_bin),
        )
    except KagentError as exc:
        sys.stderr.write(f"{exc}\n")
        return 2

    return 0


def _status(args: argparse.Namespace) -> int:
    try:
        status = kagent.status(codex_bin=cast("str | None", args.codex_bin))
    except KagentError as exc:
        sys.stderr.write(f"{exc}\n")
        return 2

    print(status, end="")
    return 0


def _logout(args: argparse.Namespace) -> int:
    try:
        kagent.logout(codex_bin=cast("str | None", args.codex_bin))
    except KagentError as exc:
        sys.stderr.write(f"{exc}\n")
        return 2

    return 0
