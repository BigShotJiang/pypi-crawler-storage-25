from pathlib import Path

import pytest
from pytest import MonkeyPatch

from kagent import DEFAULT_MODEL, DEFAULT_RUNNER, KagentError, Thread, kagent
from kagent.kagent import _api_key


def test_thread_requires_non_empty_id() -> None:
    with pytest.raises(ValueError):
        Thread("")


def test_thread_uses_default_runner(tmp_path: Path) -> None:
    thread = Thread("main", workspace=tmp_path)

    assert thread.id == "main"
    assert thread.workspace == tmp_path.resolve()
    assert thread.model == DEFAULT_MODEL
    assert thread.runner == DEFAULT_RUNNER


def test_goal_true_wraps_prompt() -> None:
    assert Thread._build_prompt("Create hello.txt", True) == "/goal Create hello.txt"


def test_goal_text_wraps_prompt() -> None:
    assert (
        Thread._build_prompt("Write the file", "Create hello.txt")
        == "/goal Create hello.txt\n\nWrite the file"
    )


def test_cli_output_parser_reads_thread_and_message() -> None:
    thread_id, text = Thread._parse_cli_output(
        "\n".join(
            [
                '{"type":"thread.started","thread_id":"abc"}',
                '{"type":"item.completed","item":{"type":"agent_message","text":"done"}}',
            ]
        )
    )

    assert thread_id == "abc"
    assert text == "done"


def test_kagent_creates_threads_with_defaults(tmp_path: Path) -> None:
    agent = kagent(workspace=tmp_path, codex_bin="/bin/codex")

    thread = agent.thread("main")

    assert thread.id == "main"
    assert thread.workspace == tmp_path.resolve()
    assert thread.codex_bin == "/bin/codex"


def test_api_key_reads_environment(monkeypatch: MonkeyPatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")

    assert _api_key(None, "OPENAI_API_KEY") == "sk-test"


def test_api_key_missing_environment_raises(monkeypatch: MonkeyPatch) -> None:
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    with pytest.raises(KagentError):
        _api_key(None, "OPENAI_API_KEY")
