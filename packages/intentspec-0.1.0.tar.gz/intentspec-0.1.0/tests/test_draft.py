"""Tests for the enhanced heuristic draft generator."""

from __future__ import annotations

from pathlib import Path

import yaml
from intentspec.cli import app
from intentspec_core.draft import heuristic_draft_payload
from intentspec_core.imports.resolver import resolve_imports
from intentspec_core.spec.parser import load_spec
from intentspec_core.validator import validate_spec
from typer.testing import CliRunner

runner = CliRunner()


# ---------------------------------------------------------------------------
# Language detection
# ---------------------------------------------------------------------------


def test_detect_language_chinese() -> None:
    result = heuristic_draft_payload("\u5e2e\u6211\u5199\u4e00\u4efd\u7b80\u62a5")
    assert result["output"].get("language") == "zh-CN"


def test_detect_language_english() -> None:
    result = heuristic_draft_payload("Review this repository")
    assert result["output"].get("language") == "en"


def test_detect_language_mixed_mostly_chinese() -> None:
    result = heuristic_draft_payload("\u5e2e\u6211\u505a Python \u9879\u76ee\u5ba1\u67e5")
    assert result["output"].get("language") == "zh-CN"


def test_detect_language_mixed_mostly_english() -> None:
    result = heuristic_draft_payload(
        "Generate a market analysis report for the APAC region"
    )
    assert result["output"].get("language") == "en"


# ---------------------------------------------------------------------------
# Profile detection
# ---------------------------------------------------------------------------


def test_profile_review_english() -> None:
    result = heuristic_draft_payload("Review this repository without modifying code")
    assert "review" in result["task"]["goal"].lower()


def test_profile_review_chinese() -> None:
    result = heuristic_draft_payload("Review this code repository")
    assert (
        "review" in result["task"]["goal"].lower()
        or "code" in result["task"]["goal"].lower()
    )


def test_profile_brief() -> None:
    result = heuristic_draft_payload("Write a customer meeting brief")
    assert "brief" in result["task"]["goal"].lower()


def test_profile_brief_chinese() -> None:
    result = heuristic_draft_payload("Write a customer brief")
    assert (
        "brief" in result["task"]["goal"].lower()
        or "customer" in result["task"]["goal"].lower()
    )


def test_profile_deploy() -> None:
    result = heuristic_draft_payload("Deploy the app to staging environment")
    assert "deploy" in result["task"]["goal"].lower()


def test_profile_test_plan() -> None:
    result = heuristic_draft_payload("Generate a test plan for the login module")
    assert "test" in result["task"]["goal"].lower()


def test_profile_translate() -> None:
    result = heuristic_draft_payload("Translate this document to Japanese")
    assert "translate" in result["task"]["goal"].lower()


def test_profile_summarize() -> None:
    result = heuristic_draft_payload("Summarize the meeting notes")
    assert "summar" in result["task"]["goal"].lower()


def test_profile_summarize_chinese() -> None:
    result = heuristic_draft_payload("Summarize this article")
    assert (
        "summarize" in result["task"]["goal"].lower()
        or "article" in result["task"]["goal"].lower()
    )


def test_profile_default_is_analysis() -> None:
    result = heuristic_draft_payload("Do something interesting with data")
    assert result["kind"] == "IntentSpec"
    assert result["task"]["goal"]


# ---------------------------------------------------------------------------
# Priority detection
# ---------------------------------------------------------------------------


def test_priority_high_english() -> None:
    result = heuristic_draft_payload("Urgent: review the security logs immediately")
    assert result["task"]["priority"] == "high"


def test_priority_high_chinese() -> None:
    result = heuristic_draft_payload("Urgent: analyze this bug")
    assert result["task"]["priority"] == "high"


def test_priority_low_english() -> None:
    result = heuristic_draft_payload("When you have time, review the docs")
    assert result["task"]["priority"] == "low"


def test_priority_low_chinese() -> None:
    result = heuristic_draft_payload("Low priority: review the code when possible")
    assert result["task"]["priority"] == "low"


def test_priority_default_medium() -> None:
    result = heuristic_draft_payload("Generate a report on sales data")
    assert result["task"]["priority"] == "medium"


# ---------------------------------------------------------------------------
# Output format detection
# ---------------------------------------------------------------------------


def test_format_json_english() -> None:
    result = heuristic_draft_payload("Generate a JSON report with verdict and risks")
    assert result["output"]["format"] == "json"
    assert "schema" in result["output"]


def test_format_json_chinese() -> None:
    result = heuristic_draft_payload("Produce structured output with analysis results")
    assert result["output"]["format"] == "json"


def test_format_json_structured_output() -> None:
    result = heuristic_draft_payload("Produce a structured output with schema")
    assert result["output"]["format"] == "json"


def test_format_json_generates_schema_test() -> None:
    result = heuristic_draft_payload("Generate JSON output")
    assert any(t["name"] == "Must match JSON schema" for t in result["tests"])


def test_format_default_markdown() -> None:
    result = heuristic_draft_payload("Write a report about the project")
    assert result["output"]["format"] == "markdown"


# ---------------------------------------------------------------------------
# Permission inference
# ---------------------------------------------------------------------------


def test_permissions_default_safe() -> None:
    result = heuristic_draft_payload("Generate a simple report")
    p = result["permissions"]
    assert p["web"] is False
    assert p["network"] is False
    assert p["filesystem"]["read"] is True
    assert p["filesystem"]["write"] is False


def test_permissions_web_allowed_english() -> None:
    result = heuristic_draft_payload("Browse the web and fetch latest news")
    assert result["permissions"]["web"] is True


def test_permissions_web_allowed_chinese() -> None:
    result = heuristic_draft_payload("Browse the web and fetch latest market data")
    assert result["permissions"]["web"] is True
    assert result["permissions"]["network"] is True


def test_permissions_write_allowed() -> None:
    result = heuristic_draft_payload("Write files to the output directory")
    assert result["permissions"]["filesystem"]["write"] is True


def test_permissions_write_allowed_chinese() -> None:
    result = heuristic_draft_payload("Create files in the output directory")
    assert result["permissions"]["tools"]["create_file"] is True


def test_permissions_no_modify_english() -> None:
    result = heuristic_draft_payload("Do not modify any existing files")
    assert result["permissions"]["filesystem"]["write"] is False


def test_permissions_no_modify_chinese() -> None:
    result = heuristic_draft_payload("Do not modify any files")
    assert result["permissions"]["filesystem"]["write"] is False


def test_permissions_send_email_allowed() -> None:
    result = heuristic_draft_payload("Send an email summary to the team")
    assert result["permissions"]["tools"]["send_email"] is True


def test_permissions_purchase_allowed() -> None:
    result = heuristic_draft_payload("Purchase the listed items from the supplier")
    assert result["permissions"]["tools"]["purchase"] is True


def test_permissions_calendar_allowed() -> None:
    result = heuristic_draft_payload("Check my calendar for conflicts")
    assert result["permissions"]["tools"]["read_calendar"] is True


# ---------------------------------------------------------------------------
# Constraint inference
# ---------------------------------------------------------------------------


def test_constraints_always_includes_no_fabricate() -> None:
    result = heuristic_draft_payload("Do something")
    assert "Do not fabricate facts." in result["constraints"]


def test_constraints_privacy() -> None:
    result = heuristic_draft_payload("Analyze data but protect privacy")
    assert any("private" in c.lower() or "personal" in c.lower()
               for c in result["constraints"])


def test_constraints_privacy_chinese() -> None:
    result = heuristic_draft_payload("Analyze data and protect privacy")
    assert any("private" in c.lower() or "personal" in c.lower()
               for c in result["constraints"])


def test_constraints_no_modify() -> None:
    result = heuristic_draft_payload("Review code, do not modify anything")
    assert any("modify" in c.lower() for c in result["constraints"])


def test_constraints_no_delete() -> None:
    result = heuristic_draft_payload("Do not delete any files")
    assert any("delete" in c.lower() for c in result["constraints"])


def test_constraints_confidential() -> None:
    result = heuristic_draft_payload("Handle this confidential document")
    assert any("confidential" in c.lower() for c in result["constraints"])


# ---------------------------------------------------------------------------
# Human gate inference
# ---------------------------------------------------------------------------


def test_gates_privacy() -> None:
    result = heuristic_draft_payload("Analyze data with privacy considerations")
    gates = result["human_gates"]
    assert any("privacy" in g["when"].lower() for g in gates)


def test_gates_confirm_chinese() -> None:
    result = heuristic_draft_payload("Analyze data and ask me before important actions")
    gates = result["human_gates"]
    assert any(g["action"] == "ask_confirmation" for g in gates)


def test_gates_web_access() -> None:
    result = heuristic_draft_payload("Browse the internet for information")
    gates = result["human_gates"]
    assert any("network" in g["when"].lower() or "external" in g["when"].lower()
               for g in gates)


def test_gates_delete_operation() -> None:
    result = heuristic_draft_payload("Clean up old files by deleting them")
    gates = result["human_gates"]
    assert any("destructive" in g["when"].lower() for g in gates)


def test_gates_purchase() -> None:
    result = heuristic_draft_payload("Purchase office supplies from the vendor")
    gates = result["human_gates"]
    assert any("financial" in g["when"].lower() for g in gates)


def test_gates_high_risk_tool_auto_gate() -> None:
    result = heuristic_draft_payload("Send an email to the client with the report")
    gates = result["human_gates"]
    assert any("send_email" in g["when"] for g in gates)


def test_gates_no_duplicates() -> None:
    result = heuristic_draft_payload(
        "Privacy is important; protect privacy; privacy analysis"
    )
    when_texts = [g["when"] for g in result["human_gates"]]
    assert len(when_texts) == len(set(when_texts))


# ---------------------------------------------------------------------------
# Section extraction
# ---------------------------------------------------------------------------


def test_sections_extracted_chinese() -> None:
    result = heuristic_draft_payload(
        "Write a report including conclusions, risks, and recommendations"
    )
    sections = result["output"]["sections"]
    assert "conclusions" in sections
    assert "risks" in sections
    assert "recommendations" in sections


def test_sections_extracted_english() -> None:
    result = heuristic_draft_payload(
        "Generate a report including summary, risks, and recommendations"
    )
    sections = result["output"]["sections"]
    assert "summary" in [s.lower() for s in sections]
    assert "risks" in [s.lower() for s in sections]
    assert "recommendations" in [s.lower() for s in sections]


def test_sections_with_colon() -> None:
    result = heuristic_draft_payload("Report sections: overview, analysis, conclusions")
    sections = result["output"]["sections"]
    assert len(sections) == 3
    assert "overview" in sections


def test_sections_fallback_to_profile() -> None:
    result = heuristic_draft_payload("Review the code")
    sections = result["output"]["sections"]
    assert len(sections) >= 2


# ---------------------------------------------------------------------------
# Goal extraction
# ---------------------------------------------------------------------------


def test_goal_extracted_from_prompt() -> None:
    result = heuristic_draft_payload("Analyze the quarterly sales data for trends")
    assert "quarterly sales" in result["task"]["goal"].lower()


def test_goal_extracted_chinese() -> None:
    result = heuristic_draft_payload("Write a customer meeting brief and protect privacy")
    assert "customer meeting brief" in result["task"]["goal"].lower()


def test_goal_not_empty() -> None:
    result = heuristic_draft_payload("x")
    assert result["task"]["goal"]


# ---------------------------------------------------------------------------
# Title extraction
# ---------------------------------------------------------------------------


def test_title_from_prompt() -> None:
    result = heuristic_draft_payload("Generate a security audit report")
    assert result["metadata"]["title"]
    assert len(result["metadata"]["title"]) <= 80


def test_title_truncated_for_long_prompt() -> None:
    long_prompt = "A" * 200
    result = heuristic_draft_payload(long_prompt)
    assert len(result["metadata"]["title"]) <= 80


# ---------------------------------------------------------------------------
# End-to-end: draft → validate
# ---------------------------------------------------------------------------


def _draft_and_validate(prompt: str, tmp_path: Path) -> None:
    payload = heuristic_draft_payload(prompt)
    draft_path = tmp_path / "draft.intent.yaml"
    draft_path.write_text(
        yaml.safe_dump(payload, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )
    spec = resolve_imports(load_spec(draft_path))
    report = validate_spec(spec)
    assert report.ok, f"Validation failed for '{prompt}': {report.errors}"


def test_e2e_chinese_brief(tmp_path: Path) -> None:
    _draft_and_validate(
        "Write a customer meeting brief, protect privacy, and ask me first if needed",
        tmp_path,
    )


def test_e2e_english_review(tmp_path: Path) -> None:
    _draft_and_validate("Review this repository without modifying code", tmp_path)


def test_e2e_json_output(tmp_path: Path) -> None:
    _draft_and_validate("Generate a JSON report with verdict and risks", tmp_path)


def test_e2e_web_access(tmp_path: Path) -> None:
    _draft_and_validate(
        "Browse the web for latest market information and ask me first if needed",
        tmp_path,
    )


def test_e2e_deploy(tmp_path: Path) -> None:
    _draft_and_validate("Deploy the application to staging", tmp_path)


def test_e2e_translate(tmp_path: Path) -> None:
    _draft_and_validate("Translate this README to Japanese", tmp_path)


def test_e2e_summarize(tmp_path: Path) -> None:
    _draft_and_validate("Summarize the key points of this paper", tmp_path)


def test_e2e_high_priority(tmp_path: Path) -> None:
    _draft_and_validate("Urgent: fix the production bug", tmp_path)


def test_e2e_with_sections(tmp_path: Path) -> None:
    _draft_and_validate(
        "Write a report including conclusions, risks, and recommendations",
        tmp_path,
    )


def test_e2e_send_email(tmp_path: Path) -> None:
    _draft_and_validate("Send an email summary to the team", tmp_path)


def test_e2e_purchase(tmp_path: Path) -> None:
    _draft_and_validate("Purchase office supplies from the vendor", tmp_path)


# ---------------------------------------------------------------------------
# CLI: intent draft (backward compatibility + new features)
# ---------------------------------------------------------------------------


def test_cli_draft_backward_compat(tmp_path: Path) -> None:
    output_file = tmp_path / "draft.intent.yaml"
    result = runner.invoke(
        app,
        [
            "draft",
            "Write a customer meeting brief, protect privacy, and ask me first if needed",
            "--out",
            str(output_file),
        ],
    )
    assert result.exit_code == 0
    validate_result = runner.invoke(app, ["validate", str(output_file)])
    assert validate_result.exit_code == 0


def test_cli_draft_english_review(tmp_path: Path) -> None:
    output_file = tmp_path / "draft.intent.yaml"
    result = runner.invoke(
        app,
        ["draft", "Review this repo without modifying code", "--out", str(output_file)],
    )
    assert result.exit_code == 0
    data = yaml.safe_load(output_file.read_text(encoding="utf-8"))
    assert data["output"]["language"] == "en"


def test_cli_draft_json_format(tmp_path: Path) -> None:
    result = runner.invoke(app, ["draft", "Generate a JSON structured output"])
    assert result.exit_code == 0
    data = yaml.safe_load(result.stdout)
    assert data["output"]["format"] == "json"


def test_cli_draft_high_priority() -> None:
    result = runner.invoke(app, ["draft", "Urgent security review needed"])
    assert result.exit_code == 0
    data = yaml.safe_load(result.stdout)
    assert data["task"]["priority"] == "high"


def test_cli_draft_with_sections() -> None:
    result = runner.invoke(
        app,
        ["draft", "Write a report including conclusions, risks, and recommendations"],
    )
    assert result.exit_code == 0
    data = yaml.safe_load(result.stdout)
    assert "conclusions" in data["output"]["sections"]
    assert "risks" in data["output"]["sections"]
    assert "recommendations" in data["output"]["sections"]
