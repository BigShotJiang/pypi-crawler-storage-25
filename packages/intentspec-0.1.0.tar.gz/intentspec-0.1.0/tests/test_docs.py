from __future__ import annotations

import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_readme_intentpack_example_matches_pack_name() -> None:
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    assert 'name: "privacy_pack"' in readme


def test_readme_python_sdk_documents_document_level_api() -> None:
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    for symbol in (
        "load_document",
        "resolve_document_imports",
        "inspect_document",
        "validate_document",
    ):
        assert symbol in readme


def test_readme_clarifies_offline_scope_and_mcp_surface() -> None:
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    assert "offline contract compiler" in readme
    assert "intentspec-mcp" in readme


def test_public_technical_docs_are_present() -> None:
    for relative_path in (
        "docs/technical-guide.md",
        "docs/integrations.md",
        "docs/iir.md",
        "docs/migration-v0.1.md",
        "docs/zh/README.md",
        "benchmark.md",
        "failure-cases.md",
    ):
        assert (ROOT / relative_path).is_file(), relative_path


def test_benchmark_runner_reports_constraint_loss() -> None:
    result = subprocess.run(
        ["python", "benchmark/run_benchmark.py", "--format", "json"],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr or result.stdout
    payload = json.loads(result.stdout)
    assert "constraint_loss_count" in payload
    assert payload["constraint_loss_count"] >= 0
    assert all("constraint_loss" in item for item in payload["results"])


def test_ci_workflow_builds_node_packages() -> None:
    workflow = (ROOT / ".github" / "workflows" / "ci.yml").read_text(encoding="utf-8")
    for snippet in (
        "node-build:",
        "actions/setup-node@v4",
        "packages/intentspec-ts",
        "packages/intentspec-vscode",
        "npm run build",
    ):
        assert snippet in workflow


def test_manifest_excludes_node_modules_and_frontend_dist() -> None:
    manifest = (ROOT / "MANIFEST.in").read_text(encoding="utf-8")
    for snippet in (
        "prune packages/intentspec-ts/node_modules",
        "prune packages/intentspec-vscode/node_modules",
        "prune packages/intentspec-ts/dist",
        "prune packages/intentspec-vscode/dist",
    ):
        assert snippet in manifest
