# Benchmark 说明

英文原文：[benchmark.md](../../benchmark.md)

## 目标

benchmark 用来记录 IntentSpec 在固定任务、固定输出和固定评估规则下的行为。它不是外部 agent 的在线评测，而是本地 artifact 级评估。

## 范围

benchmark 通常覆盖 contract 编译、输出验证、约束损失记录和失败案例归档。它帮助维护者判断一次改动是否破坏了已有行为。

## 数据集

基础 benchmark 使用仓库内的任务和输出样本。可复现 artifact benchmark 使用 `benchmark/reproducible_artifact/` 下的 contracts、outputs、artifacts、labels、scripts 和 results。

## 指标

常见指标包括编译是否成功、输出格式是否符合目标、离线断言是否命中预期、约束是否在 target 中保留，以及失败案例是否被清楚记录。

## 命令

运行基础 benchmark：

```bash
python benchmark/run_benchmark.py
```

运行可复现 artifact benchmark：

```bash
python benchmark/reproducible_artifact/scripts/run_all.py
```

## 结果使用方式

benchmark 结果适合用于回归检查、工具行为说明和文档示例。它不应被解释为真实在线 agent 的性能排名。
