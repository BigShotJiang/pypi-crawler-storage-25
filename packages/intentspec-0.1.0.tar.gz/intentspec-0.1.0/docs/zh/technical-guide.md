# IntentSpec 技术指南

英文原文：[docs/technical-guide.md](../technical-guide.md)

## 面向对象

IntentSpec 面向需要把 AI 任务标准化、复用和验证的用户。典型使用者包括软件工程师、agent 工具开发者、研究者、技术负责人和希望把提示词从临时文本升级为可维护契约的团队。

## 系统边界

IntentSpec 是本地工具链，不调用真实 LLM API，不自动执行高风险动作，也不要求测试联网。它负责描述、编译、导入和离线验证 AI 任务 contract。实际 agent 是否调用外部工具，由用户在目标平台中自行控制。

## 核心工作流

1. 用 `.intent.yaml` 写出任务 contract。
2. 运行 `intent inspect` 检查 contract 结构、权限和风险信号。
3. 运行 `intent compile` 生成目标平台需要的 artifact。
4. 把 artifact 交给对应 agent 或平台使用。
5. 收集输出后运行 `intent test` 做离线验收。

## Contract 模型

一个 contract 通常包括 `goal`、`permissions`、`constraints`、`human_gates`、`output` 和 `tests`。这些字段共同说明任务要做什么、允许做什么、不允许做什么、何时需要人工确认、输出应长什么样，以及如何验证结果。

## 编译目标

IntentSpec 支持把同一个 contract 编译到多种 target。文档型 target 适合 agent 提示和规则文件，结构化 target 适合 API 输出 schema，`mcp-plan` 则适合把 contract 暴露给 MCP 侧的计划和检查流程。

## Reverse Import

Reverse import 用来从已有 artifact 中恢复 contract 草稿。它适合迁移老的 `AGENTS.md`、Claude 风格说明、Cursor Rules、OpenAI structured output 和 Gemini structured output。导入结果应由人审查后再作为正式 contract 使用。

## 离线测试

`intent test` 对已有输出运行断言，不调用模型。它可以检查必须包含的内容、禁止出现的内容、正则匹配、章节结构、字数、字符数、JSON schema、语言和引用要求。

## Benchmark

仓库包含基础 benchmark 和可复现 artifact benchmark。基础 benchmark 用来演示常规任务，可复现 benchmark 用来生成实验数据、表格和摘要数字。

## 开发检查

常用验证命令：

```bash
pytest -q
ruff check .
mypy
```

## 实际限制

IntentSpec 不能证明 agent 一定安全，也不能保证外部平台完全遵守生成的 artifact。它提供的是本地、透明、可审查的 contract 层，让团队更容易发现约束缺失和输出偏差。

## 预期收益

使用 IntentSpec 后，团队可以把 AI 任务从一次性提示词沉淀为可版本化、可审查、可复现的工程资产。它尤其适合多 agent、多平台和需要离线质量门禁的场景。
