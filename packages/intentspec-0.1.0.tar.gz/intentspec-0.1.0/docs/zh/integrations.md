# IntentSpec 集成说明

英文原文：[docs/integrations.md](../integrations.md)

## 概览

IntentSpec 的集成方式分为三类：编译到目标 artifact、从已有 artifact reverse import、通过 MCP 暴露本地能力。

## 编译目标

常见 target 包括：

- `agents-md`：生成适合 `AGENTS.md` 风格的 agent 指令。
- `claude-md`：生成 Claude 风格的 Markdown 指令。
- `skill`：生成可嵌入 skill 的说明。
- `cursor-rules`：生成 Cursor Rules 风格规则。
- `antigravity-rules`：生成 Antigravity 风格规则。
- `openai-structured`：生成 OpenAI structured output schema。
- `gemini-structured`：生成 Gemini structured output schema。
- `mcp-plan`：生成 MCP 侧计划和约束说明。

## Reverse Import

Reverse import 可以把已有文档或 structured output 配置导回 contract 草稿。它适合迁移旧规则，但导入结果应由人工审查，因为启发式导入可能丢失上下文或误判意图。

## MCP 集成

MCP server 暴露轻量工具，让连接的 MCP client 可以读取受控 contract、编译 artifact 或运行离线测试。使用 MCP 时应特别注意本地文件访问边界和输入路径限制。

## 使用建议

如果你刚开始使用，建议先使用 `agents-md` 或 `claude-md`，确认 contract 表达稳定后再扩展到 structured target。对需要严格 JSON 输出的任务，可以优先测试 `openai-structured` 和 `gemini-structured`。

