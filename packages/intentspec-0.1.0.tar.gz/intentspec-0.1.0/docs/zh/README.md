# IntentSpec 中文文档

英文原文：[README.md](../../README.md)

IntentSpec 是一个本地优先的 CLI 和契约格式，用来把 AI 任务写成明确、可编译、可测试的 contract。它的目标不是替代现有 agent，而是让团队在使用 Codex、Claude、Cursor、OpenAI structured output、Gemini structured output 等工具时，可以先把任务目标、权限、约束、输出格式和验收规则写清楚，再生成各平台需要的提示词、规则文件或结构化 schema。

## 适合谁使用

- 经常把同一类 AI 任务交给多个 agent 或多个平台的开发者。
- 希望把 AI 输出要求固化成可审查 contract 的团队。
- 需要在本地、离线环境中验证 AI 输出是否满足格式和内容要求的用户。
- 正在研究 AI agent 工具链、提示词治理、离线验收测试或可复现实验的研究者。

## 你能得到什么

- 一个 `.intent.yaml` 契约文件，用来描述任务目标、权限、约束、输出格式和测试规则。
- 多种 target 的编译输出，例如 `agents-md`、`claude-md`、`cursor-rules`、`openai-structured`、`gemini-structured` 和 `mcp-plan`。
- 一个 reverse import 能力，可以从已有 `AGENTS.md`、Claude 风格文档、Cursor Rules 或 structured output 片段导回 contract。
- 一个离线测试器，可以用 `contains`、`not_contains`、`regex`、`no_regex`、`required_sections`、`max_words`、`max_chars`、`json_schema`、`language`、`references` 等断言验证输出。

## 快速开始

安装开发版本：

```bash
pip install -e ".[dev]"
```

查看 CLI：

```bash
intent --help
```

生成一个 contract 草稿：

```bash
intent draft --prompt "Write a customer brief with risks and next steps" --out customer_brief.intent.yaml
```

编译到 agent 文档：

```bash
intent compile customer_brief.intent.yaml --target agents-md --out AGENTS.md
```

验证输出：

```bash
intent test customer_brief.intent.yaml --output customer_brief.output.md
```

## 中文文档目录

这些文件是英文核心文档的中文读者版。命令、路径、target 名称、API 字段名和格式标识符保持英文原样。

| 中文文档 | 对应英文文档 | 内容 |
|---|---|---|
| [technical-guide.md](technical-guide.md) | [docs/technical-guide.md](../technical-guide.md) | 技术总览、使用对象、工作流、边界和限制。 |
| [benchmark.md](benchmark.md) | [benchmark.md](../../benchmark.md) | benchmark 模板和结果说明。 |
| [failure-cases.md](failure-cases.md) | [failure-cases.md](../../failure-cases.md) | 失败案例记录方式。 |
| [iir.md](iir.md) | [docs/iir.md](../iir.md) | Intent Intermediate Representation。 |
| [integrations.md](integrations.md) | [docs/integrations.md](../integrations.md) | 各类 target 和 reverse import 集成。 |
| [migration-v0.1.md](migration-v0.1.md) | [docs/migration-v0.1.md](../migration-v0.1.md) | v0.1 迁移指南。 |
| [vscode-extension.md](vscode-extension.md) | [packages/intentspec-vscode/README.md](../../packages/intentspec-vscode/README.md) | VS Code 扩展说明。 |
| [benchmark/reproducible-benchmark.md](benchmark/reproducible-benchmark.md) | [benchmark/reproducible_artifact/README.md](../../benchmark/reproducible_artifact/README.md) | 可复现 benchmark 说明。 |
| [benchmark/benchmark-numbers.md](benchmark/benchmark-numbers.md) | [benchmark/reproducible_artifact/results/numbers.md](../../benchmark/reproducible_artifact/results/numbers.md) | 实验数字说明。 |
| [benchmark/benchmark-tables.md](benchmark/benchmark-tables.md) | [benchmark/reproducible_artifact/results/tables.md](../../benchmark/reproducible_artifact/results/tables.md) | 实验表格说明。 |
