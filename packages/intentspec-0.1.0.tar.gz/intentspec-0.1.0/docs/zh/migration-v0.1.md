# 迁移到 IntentSpec 0.1

英文原文：[docs/migration-v0.1.md](../migration-v0.1.md)

## 摘要

IntentSpec 0.1 固定了早期 contract 结构、导入合并规则、输出 schema、断言类型和主要 compile target。迁移时应重点检查字段名、`imports`、`output.schema` 和测试断言。

## 顶层字段

contract 应显式声明版本和类型。推荐保持字段结构清晰，避免把权限、约束和输出要求混在自由文本中。

## Imports

`imports` 用来复用 pack 或共享规则。迁移时要确认导入后的合并结果是否符合预期，尤其是 tests、constraints、human gates 和 permissions。

## Output schema

结构化输出应放在 `output.schema` 中。迁移旧 contract 时，需要确认 schema 是否能被目标平台接受，并在编译后检查 target capability notes。

## Assertions

0.1 支持多种离线断言。迁移时建议为每个重要输出要求增加至少一个测试，避免只依赖自然语言约束。

## Inspect 命令

`intent inspect` 可以帮助查看解析和合并后的 contract。迁移过程中建议先运行 inspect，再编译到具体 target。

## Compile targets

不同 target 能表达的语义不同。Markdown target 更适合完整说明，structured target 更适合严格输出形状。迁移后应至少对核心 target 做一次编译和人工检查。

