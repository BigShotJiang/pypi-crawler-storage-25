# Intent Intermediate Representation

英文原文：[docs/iir.md](../iir.md)

## 概览

IIR 是 IntentSpec 的中间表示层。它把输入 contract 规范化为稳定结构，让不同 target 的编译器可以基于同一份意图信息工作。

## 为什么需要 IIR

不同 agent 平台接受的格式不同。有的需要 Markdown，有的需要规则文件，有的需要 JSON schema。IIR 的作用是把 contract 中的目标、权限、约束、输出和测试规则统一成可分析、可编译的内部结构。

## 稳定规范化

IIR 会尽量把输入字段转成稳定形态，减少不同 YAML 写法造成的输出差异。这让编译结果更适合版本控制和回归测试。

## 导入合并

当 contract 使用 `imports` 时，IIR 会基于解析后的结果工作。这样编译器看到的是完整 contract，而不是分散的 pack 和本地覆盖片段。

## 风险信号

IIR 可以暴露权限和风险信号，例如网络访问、文件访问、机密输入、人工确认点等。target 可以根据这些信号生成更明确的提醒。

## Target capability notes

有些 target 无法表达 contract 中的全部语义。此时编译结果可以记录 capability notes，说明哪些约束被弱化、需要人工检查，或只能作为文本提示保留。

## CLI 表面

用户通常不需要直接编辑 IIR。`intent inspect` 可以帮助查看规范化后的 contract 信息，并用于调试导入、合并和编译行为。

