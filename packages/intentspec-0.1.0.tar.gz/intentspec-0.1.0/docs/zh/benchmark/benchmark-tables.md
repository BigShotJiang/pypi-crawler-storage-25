# Benchmark 实验表格说明

英文原文：[benchmark/reproducible_artifact/results/tables.md](../../../benchmark/reproducible_artifact/results/tables.md)

`tables.md` 是由实验结果渲染出的 Markdown 表格草稿，方便用户快速查看 benchmark 结果。

## 表格类型

该文件至少包含：

- target coverage table。
- round-trip fidelity table。
- assertion effectiveness table。

## 使用方式

运行完整实验后重新生成表格：

```bash
python benchmark/reproducible_artifact/scripts/run_all.py
```

引用表格时，应确认表格内容和 `summary.json` 一致。

## 解释边界

表格描述的是 IntentSpec 工具链在固定 benchmark 上的 artifact 级行为，不是外部 agent 在线运行结果。
