# 可复现 Artifact Benchmark

英文原文：[benchmark/reproducible_artifact/README.md](../../../benchmark/reproducible_artifact/README.md)

## 目标

`benchmark/reproducible_artifact/` 是一个本地可复现的 artifact 级实验包，用于评估 IntentSpec 的编译、反向导入和离线断言行为。它不调用真实外部 agent，也不依赖在线 API。

## 目录结构

- `contracts/` 存放实验 contract。
- `outputs/valid/` 存放预期通过的输出。
- `outputs/defects/` 存放预期失败的缺陷输出。
- `artifacts/handwritten/` 存放手写 artifact。
- `labels/` 存放公开标签。
- `results/` 存放生成结果。
- `scripts/` 存放实验 runner。

## 主要脚本

```bash
python benchmark/reproducible_artifact/scripts/run_compile_matrix.py
python benchmark/reproducible_artifact/scripts/run_roundtrip.py
python benchmark/reproducible_artifact/scripts/run_assertion_eval.py
python benchmark/reproducible_artifact/scripts/render_tables.py
python benchmark/reproducible_artifact/scripts/run_all.py
```

## 结果文件

主要结果包括 `compile_matrix.json`、`roundtrip_fidelity.json`、`assertion_eval.json`、`summary.json`、`tables.md` 和 `numbers.md`。

## 解释边界

这些结果展示 IntentSpec 在本地 artifact 层面的可行性，不代表真实 agent 在线执行能力，也不应被解释为跨平台模型性能排名。
