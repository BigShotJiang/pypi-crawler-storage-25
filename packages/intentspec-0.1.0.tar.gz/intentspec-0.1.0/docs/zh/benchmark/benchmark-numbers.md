# Benchmark 实验数字说明

英文原文：[benchmark/reproducible_artifact/results/numbers.md](../../../benchmark/reproducible_artifact/results/numbers.md)

`numbers.md` 是 benchmark 数字的文本化摘要。它由实验脚本生成，目的是避免手工填写临时百分比或计数。

## 包含内容

该文件通常包含：

- compile success rate。
- round-trip field fidelity。
- valid pass rate。
- targeted defect catch rate。
- per-assertion summary。

## 使用方式

引用 benchmark 数字时应从 `numbers.md` 或 `summary.json` 获取。修改 benchmark 数据或脚本后，需要重新运行：

```bash
python benchmark/reproducible_artifact/scripts/run_all.py
```

## 注意事项

如果 `numbers.md` 和其他说明文档不一致，应以重新生成后的 `summary.json` 和 `numbers.md` 为准，并同步修改相关说明。
