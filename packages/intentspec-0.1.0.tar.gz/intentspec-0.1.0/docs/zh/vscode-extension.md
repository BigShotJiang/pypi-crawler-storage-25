# IntentSpec VS Code 扩展

英文原文：[packages/intentspec-vscode/README.md](../../packages/intentspec-vscode/README.md)

## 目标

VS Code 扩展用于改善编辑 IntentSpec contract 时的本地体验。它适合希望在编辑器内查看 schema、提示和项目文件的用户。

## 当前定位

扩展仍处于早期阶段，主要作为项目集成方向的占位和基础说明。核心能力仍由 Python CLI 和 `intentspec_core` 提供。

## 使用建议

如果你主要想试用 IntentSpec，建议先从 CLI 开始：

```bash
intent --help
```

等 contract 格式和团队工作流稳定后，再把 VS Code 扩展纳入日常编辑流程。

