# IntentSpec Technical Guide

IntentSpec is a local-first tool for AI task contracts. It does not introduce a new
agent runtime. Instead, it gives teams one structured source for requirements that
are often scattered across `AGENTS.md`, `CLAUDE.md`, Cursor Rules, structured output
schemas, and MCP-oriented plans.

In one sentence: IntentSpec lets a team define goals, permissions, constraints,
human confirmation gates, output formats, and acceptance tests once, then compile
that contract to multiple AI tool artifacts and test the final output offline.

## Intended Users

AI application developers can use IntentSpec when they need stable output schemas,
explicit permissions, local validation, and deterministic post-run checks.

Engineering teams that use Cursor, Codex, Claude Code, or similar tools can use
IntentSpec as an upstream rule source. One contract can compile into repository
instructions, project memory, Cursor rules, structured output payloads, and MCP plan
artifacts.

Security, governance, and compliance reviewers can use IntentSpec to make agent
permissions, privacy expectations, and manual approval points visible in version
control.

Researchers can use IntentSpec as a small artifact-level testbed for studying
contract portability, target capability limits, reverse import fidelity, and offline
acceptance checks.

## System Boundary

IntentSpec provides artifact-level governance. It validates contracts, compiles
artifacts, imports existing artifacts, and tests outputs after an agent run. It does
not enforce runtime behavior, sandbox a model, intercept tool calls, or verify the
truth of generated claims.

This boundary is deliberate. Many teams need low-friction governance artifacts that
fit existing tools without replacing their current editor, model API, or agent
runtime.

## Core Workflow

1. Write an `intent.yaml` contract.
2. Validate it locally with `intent validate`.
3. Inspect the normalized intermediate representation with `intent inspect`.
4. Compile it to one or more targets with `intent compile`.
5. Use the generated artifact in the downstream tool.
6. Run `intent test` against the final output.

The workflow is deterministic and does not require network access or API keys.

## Contract Model

An IntentSpec contract includes these major areas:

- `metadata`: name, title, owner, and optional description.
- `task`: goal, audience, and priority.
- `context`: facts, assumptions, and glossary terms.
- `inputs`: local files or references used by the task.
- `permissions`: web, network, filesystem, and tool access flags.
- `constraints`: behavioral and safety boundaries.
- `evidence`: requirements for sources and uncertainty marking.
- `output`: markdown or JSON output expectations.
- `quality`: tone, required content, and avoided content.
- `human_gates`: conditions that require manual confirmation.
- `tests`: deterministic checks for final outputs.

## Compilation Targets

Instruction-style targets emit markdown that can be committed into a repository.
Structured-output targets emit JSON payloads that include schema constraints.
The MCP plan target emits a structured plan for MCP-capable workflows.

Not every target can represent every contract field. IntentSpec reports capability
notes when information cannot be fully represented by a target format.

## Reverse Import

Reverse import helps teams migrate existing artifacts into draft contracts. The
importers are deterministic and conservative. They can recover common goals,
permissions, constraints, output hints, and tests from generated or handwritten
artifacts, but they do not guarantee semantic equivalence with the original author
intent.

## Offline Testing

IntentSpec supports deterministic output checks such as required markdown sections,
required text, forbidden text, regex checks, word and character limits, JSON Schema
validation, JSON path existence, and minimum JSON array sizes.

These tests are not semantic evaluators. They are local guardrails for properties
that a team can state before an agent run and verify after receiving an output.

## Benchmark

The repository includes two benchmark entry points:

```bash
python benchmark/run_benchmark.py
python benchmark/reproducible_artifact/scripts/run_all.py
```

The reproducible benchmark evaluates local artifacts only. It does not call real external
agent APIs. The generated result files live under
`benchmark/reproducible_artifact/results/`.

## Development Checks

Use these commands before submitting changes:

```bash
pytest
ruff check .
mypy
python -m build
twine check dist/*
```

The project targets Python 3.11 or newer and keeps tests offline and deterministic.

## Practical Limitations

Compiled instruction files are advisory artifacts. Downstream tools may ignore,
misread, or partially follow them. IntentSpec makes expectations explicit and easier
to review, but it does not make a model safe by itself.

Structured-output targets are most useful for JSON contracts. Markdown-only
contracts may not compile into schema-constrained structured-output payloads.

Reverse import is heuristic for natural-language artifacts. Use imported drafts as
starting points for review, not as proof of complete recovery.

## Expected Result

After adopting IntentSpec, a project should have a reviewable contract, generated
artifacts for target tools, explicit permission and confirmation boundaries, local
output checks, and a reproducible record of target capability limitations.
