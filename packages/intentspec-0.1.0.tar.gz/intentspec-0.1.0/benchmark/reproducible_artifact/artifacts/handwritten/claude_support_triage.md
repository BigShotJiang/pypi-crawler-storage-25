# CLAUDE.md

## Project Goal
Triage customer support tickets, identify risks, next steps, and items requiring manual confirmation.

## Working Constraints
- Do not output customer phone numbers, email addresses, or order IDs.
- Do not promise refunds.

## Human Confirmation Rules
- Refunds, compensation, or customer identity information are involved -> ask_confirmation

## Output Expectations
- Format: markdown
- Language: zh-CN
- Max words: 140
- Section: Ticket Level
- Section: Risk Signals
- Section: Next Steps
- Section: Manual Confirmation

## Verification
- All sections must be present

