# Reproducible benchmark numbers

- The compile matrix contains 120 contract-target pairs across 20 contracts and 6 representative targets; 94 compiled successfully (78.33%).
- Compiled round-trip import succeeded for 74 of 100 attempted artifacts (74.0%).
- Successful compiled round trips had an average core-field fidelity of 71.85%.
- Handwritten artifact import succeeded for 20 of 20 artifacts (100.0%).
- All 19 of 20 valid outputs passed offline acceptance tests (95.0%).
- The targeted defect suite caught 32 of 32 labeled defects (100.0%).
