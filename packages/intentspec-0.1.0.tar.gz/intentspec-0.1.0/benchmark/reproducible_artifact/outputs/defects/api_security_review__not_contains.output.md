## Risk Rating
Risk rating: high.

## Authentication
The draft includes example-secret-marker and must be corrected.

## Authorization
Role checks are incomplete.

## Data Exposure
The example leaks a raw secret.

## Required Follow-up
Remove secret material and re-review.
