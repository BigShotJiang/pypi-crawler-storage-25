# Reproducible artifact benchmark

This directory contains the local, reproducible artifact-level benchmark used by the
IntentSpec project. It includes a fixed local dataset for evaluating compilation,
round-trip import fidelity, and deterministic offline assertion behavior.

Run all experiments from the repository root:

```bash
python benchmark/reproducible_artifact/scripts/run_all.py
```

The benchmark intentionally avoids external agent execution. It measures compilation,
round-trip import fidelity, and deterministic offline assertion behavior using the
current IntentSpec implementation.

Current dataset size:

- 20 contracts
- 52 output samples, including 20 valid outputs and 32 targeted defects
- 20 handwritten artifacts

Current generated results:

| Metric | Result |
| --- | ---: |
| Compile matrix | 94 / 120 successful target compilations |
| Compiled round-trip imports | 74 / 100 successful imports |
| Handwritten artifact imports | 20 / 20 successful imports |
| Valid output pass rate | 19 / 20 |
| Targeted defect catch rate | 32 / 32 |

Generated summaries:

- [results/summary.json](results/summary.json)
- [results/numbers.md](results/numbers.md)
- [results/tables.md](results/tables.md)
