"""Intent Intermediate Representation."""

