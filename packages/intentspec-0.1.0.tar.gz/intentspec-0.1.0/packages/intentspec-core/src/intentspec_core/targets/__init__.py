"""IntentSpec compilation targets."""

