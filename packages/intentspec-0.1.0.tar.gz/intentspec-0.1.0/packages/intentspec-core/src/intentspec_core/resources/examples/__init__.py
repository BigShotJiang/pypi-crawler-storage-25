"""Packaged IntentSpec examples."""
