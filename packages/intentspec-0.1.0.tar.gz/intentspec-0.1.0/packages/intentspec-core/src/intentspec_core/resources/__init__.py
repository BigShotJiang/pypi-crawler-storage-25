"""Packaged core resources."""
