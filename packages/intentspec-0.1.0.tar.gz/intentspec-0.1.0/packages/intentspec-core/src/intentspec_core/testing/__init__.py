"""IntentSpec output testing."""

