"""Best-effort client-IP extraction for audit logging.

Lives here, not in ``parbaked.logging``, because the FastAPI ``Request``
dependency shouldn't leak into the logging module — the logger needs to be
usable from non-HTTP contexts (e.g. background hooks) too.
"""

from __future__ import annotations

from fastapi import Request

from parbaked.config import ParbakedConfig


def client_ip(request: Request, config: ParbakedConfig) -> str | None:
    """Return the originating client IP for use in audit log records.

    When ``config.trust_proxy_headers`` is True, the leftmost entry of
    ``X-Forwarded-For`` wins — that's the original client when the app is
    behind fly.io, Cloudflare, or any HTTP reverse proxy. Falls back to
    ``request.client.host`` if the header is absent or proxy trust is off.
    """
    if config.trust_proxy_headers:
        fwd = request.headers.get("x-forwarded-for")
        if fwd:
            first = fwd.split(",", 1)[0].strip()
            if first:
                return first
    if request.client is not None:
        return request.client.host
    return None
