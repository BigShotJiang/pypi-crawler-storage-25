"""Defence-in-depth HTTP response headers for HTML-serving endpoints (#200, #262).

Modern browsers honour a small bouquet of response headers that turn off
implicit behaviours that hurt more than they help:

- ``X-Content-Type-Options: nosniff`` — disables MIME sniffing so a
  ``text/plain`` response can never be re-interpreted as ``text/html``.
- ``X-Frame-Options: DENY`` — blocks iframe embedding (clickjacking).
- ``Referrer-Policy: strict-origin-when-cross-origin`` — magic-link URLs
  in the ``Referer`` header don't leak across origins.
- ``Content-Security-Policy`` — restricts the origins from which the
  page may load scripts, styles, images.

CSP nonce contract (#262)
-------------------------

The middleware mints a fresh, cryptographically-random nonce per
response and:

1. exposes it on ``request.state.csp_nonce`` so HTML renderers (and the
   SPA static-files mount) can stamp ``nonce="..."`` onto inline
   ``<script>`` tags;
2. emits ``script-src 'self' 'nonce-{nonce}'`` in the CSP, so the
   browser only executes inline scripts that carry the matching nonce.

The starter ``web/index.html`` ships ``<script nonce="{{__CSP_NONCE__}}">``
and the SPA mount substitutes that placeholder with the per-request
nonce at serve-time. ``style-src 'self' 'unsafe-inline'`` is preserved
for now — admin pages inline their CSS and a nonce-for-stylesheets sweep
is out of scope for this fix; see the follow-up issue.

The middleware only stamps the headers when the response's
``Content-Type`` starts with ``text/html`` — JSON API responses don't
need (and shouldn't carry) a CSP. The :func:`add_security_headers`
helper is wired into :class:`parbaked.app.Parbaked` so every parbaked
app gets the headers for free.
"""

from __future__ import annotations

import secrets
from collections.abc import Awaitable, Callable

from fastapi import FastAPI, Request, Response

#: Placeholder that starter HTML (and any other parbaked-served HTML)
#: uses for ``nonce="..."`` attributes on inline ``<script>`` tags. The
#: SPA static-files mount substitutes this with the per-response nonce
#: at serve-time.
CSP_NONCE_PLACEHOLDER = "{{__CSP_NONCE__}}"

_STATIC_HTML_HEADERS: dict[str, str] = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "strict-origin-when-cross-origin",
}


def _build_csp(nonce: str) -> str:
    """Build the CSP header value for a given per-response nonce.

    ``script-src`` is locked to same-origin + the nonce — inline
    ``<script>`` blocks must carry ``nonce="{nonce}"`` to execute.
    ``style-src`` keeps ``'unsafe-inline'`` because the admin
    dashboard's CSS lives inline; tightening that is a separate ticket.
    """
    return (
        "default-src 'self'; "
        f"script-src 'self' 'nonce-{nonce}'; "
        "style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data:; "
        "frame-ancestors 'none'"
    )


def add_security_headers(app: FastAPI) -> None:
    """Attach the HTML-response security-header middleware to ``app``.

    Mints a fresh CSP nonce on every request (stored on
    ``request.state.csp_nonce``) and stamps the CSP / X-Frame-Options /
    Referrer-Policy / X-Content-Type-Options bouquet onto HTML
    responses on the way out.

    Idempotent in spirit — calling twice would double-stamp the headers,
    which is harmless but pointless. :class:`parbaked.app.Parbaked.install`
    guards against double-install at the call site.
    """

    @app.middleware("http")
    async def _security_headers(
        request: Request,
        call_next: Callable[[Request], Awaitable[Response]],
    ) -> Response:
        # Mint a fresh nonce per request. ``token_urlsafe(16)`` is 22
        # base64-url chars — well above the CSP-recommended 128 bits of
        # entropy and short enough to keep header bloat trivial.
        nonce = secrets.token_urlsafe(16)
        request.state.csp_nonce = nonce
        response = await call_next(request)
        content_type = response.headers.get("content-type", "")
        if content_type.lower().startswith("text/html"):
            for key, value in _STATIC_HTML_HEADERS.items():
                # Don't clobber headers a route already set explicitly —
                # consumer code wins on conflict.
                response.headers.setdefault(key, value)
            response.headers.setdefault(
                "Content-Security-Policy", _build_csp(nonce)
            )
        return response
