"""Structured logging.

parbaked logs every auth-lifecycle event (signup / verify / approve / reject /
login success / login failure) to the ``parbaked`` logger. Two output formats:

- **plain text** (default) — readable in dev terminals
- **JSON one-line-per-event** — gated by ``PARBAKED_LOG_FORMAT=json``; pipe
  into your aggregator (CloudWatch, Datadog, Logflare, fly.io's log shipper)

Each event carries: event name, user_id, email, IP, timestamp.

To customise:
- Replace handlers on the ``parbaked`` logger to send elsewhere
- Adjust level: ``logging.getLogger("parbaked").setLevel(logging.WARNING)``
- Disable entirely: ``logging.getLogger("parbaked").disabled = True``
"""

from __future__ import annotations

import json
import logging
import sys
from datetime import UTC, datetime
from typing import Any

_PARBAKED_LOGGER_NAME = "parbaked"
_AUDIT_LOGGER_NAME = "parbaked.audit"

# Sentinel so we only install handlers once even if Parbaked() runs twice.
_INSTALLED = False


class _JsonFormatter(logging.Formatter):
    """One JSON object per line.

    Includes any extra keys passed via ``logger.info(..., extra={...})``.
    """

    _IGNORE = {
        "name", "msg", "args", "levelname", "levelno", "pathname", "filename",
        "module", "exc_info", "exc_text", "stack_info", "lineno", "funcName",
        "created", "msecs", "relativeCreated", "thread", "threadName",
        "processName", "process", "taskName",
    }

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": datetime.fromtimestamp(record.created, UTC).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        for key, value in record.__dict__.items():
            if key in self._IGNORE or key.startswith("_"):
                continue
            if key == "message":
                continue
            payload[key] = value
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


def configure_logging(format: str | None = None, level: int = logging.INFO) -> None:
    """Install a handler on the ``parbaked`` logger.

    ``format`` may be ``"json"`` for one-JSON-object-per-line or anything else
    (or ``None``) for plain text. The canonical knob is the ``log_format``
    field on :class:`ParbakedConfig` (env var ``PARBAKED_LOG_FORMAT``);
    :meth:`Parbaked.__init__` forwards it here.

    Idempotent — calling this twice doesn't double-install handlers.
    """
    global _INSTALLED
    if _INSTALLED:
        return

    fmt = (format or "").lower()
    handler = logging.StreamHandler(sys.stdout)
    if fmt == "json":
        handler.setFormatter(_JsonFormatter())
    else:
        handler.setFormatter(
            logging.Formatter(
                fmt="%(asctime)s %(levelname)s %(name)s: %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )
        )

    logger = logging.getLogger(_PARBAKED_LOGGER_NAME)
    logger.addHandler(handler)
    logger.setLevel(level)
    # We leave propagation on so a consumer's root logging config also sees
    # parbaked records (Sentry/CloudWatch/Datadog/etc.). If the consumer
    # *does* have a root StreamHandler, that means a duplicate line per event.
    # That's the lesser of two evils — losing log visibility is worse than
    # double-logging.

    _INSTALLED = True


def audit_logger() -> logging.Logger:
    """The logger every auth-lifecycle event goes through."""
    return logging.getLogger(_AUDIT_LOGGER_NAME)


def log_event(
    event: str,
    *,
    user_id: str | None = None,
    email: str | None = None,
    ip: str | None = None,
    success: bool = True,
    extra: dict[str, Any] | None = None,
) -> None:
    """Emit one structured audit event.

    ``event`` examples: "signup", "verify", "approve", "reject", "login.success",
    "login.fail". Extra fields land on the LogRecord and end up in the JSON
    payload when JSON formatting is on.
    """
    payload: dict[str, Any] = {"event": event, "success": success}
    if user_id is not None:
        payload["user_id"] = user_id
    if email is not None:
        payload["email"] = email
    if ip is not None:
        payload["ip"] = ip
    if extra:
        payload.update(extra)
    audit_logger().info(event, extra=payload)
