"""Resend email transport — parbaked's one prod transport.

Resend is the recommended path because:
- 3,000 emails/month free, no credit card
- The ``onboarding@resend.dev`` sandbox lets you send mail without setting up
  any DNS records — perfect for weekend projects
- One env var (`PARBAKED_RESEND_KEY`) is all parbaked needs

For domain verification + your own from-address, see Resend's docs at
https://resend.com/docs/dashboard/domains/introduction. Once verified, set
``PARBAKED_MAIL_FROM=hello@yourdomain.com`` and you're done.
"""

from __future__ import annotations

import json
import logging

from parbaked.config import ParbakedConfig
from parbaked.email._http import HTTPEmailError, post_json
from parbaked.email.base import EmailMessage

logger = logging.getLogger("parbaked.email")


class ResendEmail:
    """Sends via Resend's REST API.

    Requires:
    - ``PARBAKED_RESEND_KEY`` (the ``re_xxx`` API key from resend.com)

    Optional:
    - ``PARBAKED_MAIL_FROM`` (defaults to ``onboarding@resend.dev``, Resend's
      sandbox sender that works without DNS setup)
    """

    def __init__(self, config: ParbakedConfig) -> None:
        if not config.resend_key:
            # ``ParbakedConfigError`` subclasses ``ValueError`` so any
            # existing ``except ValueError`` callers still work (#221).
            # Email transport init is a configuration concern: a real
            # transport was requested but the env var that drives it
            # wasn't set.
            from parbaked.exceptions import ParbakedConfigError

            raise ParbakedConfigError(
                "ResendEmail requires PARBAKED_RESEND_KEY. "
                "Get a free key at https://resend.com/api-keys, or run "
                "`parbaked email setup` for an interactive walkthrough."
            )
        self.config = config

    def send(self, message: EmailMessage) -> None:
        payload: dict = {
            "from": self.config.effective_mail_from_header(),
            "to": [message.to],
            "subject": message.subject,
            "text": message.body,
        }
        if message.html:
            payload["html"] = message.html
        try:
            raw = post_json(
                "https://api.resend.com/emails",
                payload,
                headers={"Authorization": f"Bearer {self.config.resend_key}"},
            )
        except HTTPEmailError as exc:
            # WARNING so operators chasing "did my mail go out?" can grep
            # for it. The exception message already carries the upstream
            # status + body excerpt from ``post_json`` — we deliberately
            # do NOT log the request payload or the API key. (#343)
            logger.warning(
                "email.send_failed provider=resend to=%s subject=%r error=%s",
                message.to,
                message.subject,
                exc,
            )
            raise

        # Resend returns ``{"id": "<uuid>"}`` on success. Capture and log
        # the message id at INFO so operators can correlate parbaked-side
        # signups with the Resend dashboard's delivery records — without
        # it, the success path is invisible in logs and the message id
        # (the durable handle for bounce / delivery / deletion / audit)
        # gets thrown away. (#343)
        message_id: str | None = None
        try:
            data = json.loads(raw.decode() or "{}")
        except (ValueError, UnicodeDecodeError):
            data = {}
        if isinstance(data, dict):
            raw_id = data.get("id")
            if isinstance(raw_id, str):
                message_id = raw_id
        logger.info(
            "email.sent provider=resend message_id=%s to=%s subject=%r",
            message_id or "<missing>",
            message.to,
            message.subject,
        )
