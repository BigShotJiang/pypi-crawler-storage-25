"""Console email transport — prints to stdout. Useful in dev and tests."""

from __future__ import annotations

import sys
from io import StringIO
from typing import TYPE_CHECKING

from parbaked.email.base import EmailMessage

if TYPE_CHECKING:
    from parbaked.config import ParbakedConfig


class ConsoleEmail:
    """Prints sent messages to stdout (or a provided file-like).

    In tests, pass ``buffer=StringIO()`` to capture messages for assertions.

    When ``config`` is supplied, the printed output includes a ``From:`` line
    matching what real transports (e.g. ResendEmail) would send. This makes
    dev / test output a faithful preview of production mail headers (#224).
    """

    def __init__(
        self,
        buffer: StringIO | None = None,
        config: ParbakedConfig | None = None,
    ) -> None:
        self._buffer = buffer
        self._config = config
        self.sent: list[EmailMessage] = []

    def send(self, message: EmailMessage) -> None:
        self.sent.append(message)
        stream = self._buffer if self._buffer is not None else sys.stdout
        divider = "─" * 60
        parts: list[str] = ["", divider]
        if self._config is not None:
            parts.append(f"From:    {self._config.effective_mail_from_header()}")
        parts.extend(
            [
                f"To:      {message.to}",
                f"Subject: {message.subject}",
                divider,
                message.body.rstrip(),
            ]
        )
        if message.html:
            parts.extend(
                [
                    "─" * 24 + " (html) " + "─" * 28,
                    message.html.rstrip(),
                ]
            )
        parts.extend([divider, ""])
        stream.write("\n".join(parts) + "\n")
        if hasattr(stream, "flush"):
            stream.flush()
