"""Plain-text + HTML email templates for the approval flow.

Each renderer returns an :class:`EmailMessage` with both ``body`` (text) and
``html`` set. The HTML version uses inline styles and a single ``<a>`` button
so it renders in every major email client without external CSS.

To override copy or styling, build a custom :class:`Templates` and pass it to
:func:`build_auth_router` / :class:`Parbaked`.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from html import escape as _esc

from parbaked.auth.models import User
from parbaked.config import ParbakedConfig
from parbaked.email.base import EmailMessage


class _SafePlaceholders(dict):
    """``str.format_map`` helper that leaves unknown ``{keys}`` intact (#144).

    Subject overrides ship from ``parbaked.toml`` / env so a typo like
    ``"Hi {weirdo}"`` shouldn't blow up the entire send. Unknown
    placeholders re-render as the literal ``{weirdo}`` instead of raising
    ``KeyError``. Known placeholders behave exactly like ``str.format``.
    """

    def __missing__(self, key: str) -> str:  # type: ignore[override]
        return "{" + key + "}"


def _apply_subject(template: str, **placeholders: str) -> str:
    """Render a subject-line template, swallowing unknown placeholders."""
    return template.format_map(_SafePlaceholders(placeholders))


def _subject_for(
    config: ParbakedConfig,
    field: str,
    default_suffix: str,
    **placeholders: str,
) -> str:
    """Resolve the per-template subject, applying the override if set.

    Every renderer used to inline this two-step dance — pick the
    operator-supplied override on ``config.email.subjects.<field>`` if
    present, fall back to ``f"[{app_name}] <default>"``, then run
    ``_apply_subject`` with ``app_name`` plus any per-template
    placeholders (user_name, user_email). Centralised so adding a new
    transactional email doesn't copy the pattern again.
    """
    template = (
        getattr(config.email.subjects, field)
        or f"[{config.app_name}] {default_suffix}"
    )
    return _apply_subject(template, app_name=config.app_name, **placeholders)

# ---------------------------------------------------------------------------
# Shared HTML chrome — one place to tweak the look
# ---------------------------------------------------------------------------

_HTML_SHELL = """\
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
</head>
<body style="margin:0;padding:0;background:#f6f7f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;color:#1a1a1a;">
  <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background:#f6f7f9;">
    <tr><td align="center" style="padding:32px 16px;">
      <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="480" style="max-width:480px;background:#ffffff;border-radius:8px;border:1px solid #e5e7eb;">
        <tr><td style="padding:32px;">
          <h1 style="margin:0 0 12px 0;font-size:18px;font-weight:600;color:#111;">{heading}</h1>
          {content}
        </td></tr>
      </table>
      <p style="margin:16px 0 0 0;font-size:12px;color:#9ca3af;">Sent by {app_name}</p>
    </td></tr>
  </table>
</body>
</html>
"""

_BUTTON = """\
<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:24px 0;">
  <tr><td>
    <a href="{url}" style="display:inline-block;padding:10px 20px;background:#111;color:#ffffff;text-decoration:none;border-radius:6px;font-weight:500;font-size:14px;">{label}</a>
  </td></tr>
</table>"""


def _shell(title: str, heading: str, app_name: str, content: str) -> str:
    return _HTML_SHELL.format(
        title=title, heading=heading, app_name=app_name, content=content
    )


# ---------------------------------------------------------------------------
# 1. Verify email — sent to user on signup
# ---------------------------------------------------------------------------


def render_user_verify_email(
    user: User, verify_url: str, config: ParbakedConfig
) -> EmailMessage:
    subject = _subject_for(
        config, "user_verify", "Confirm your email", user_name=user.name
    )
    body = (
        f"Hi {user.name},\n\n"
        f"Welcome to {config.app_name}! Please confirm your email address by "
        "clicking the link below:\n\n"
        f"  {verify_url}\n\n"
        f"The link expires in {config.approval_token_expiry_hours} hours.\n\n"
        "If you didn't sign up, you can ignore this email.\n"
    )
    # HTML escape every interpolated value — user.name/email are user-controlled
    # (attacker can set them at signup) and app_name is config but could contain
    # & or <. URLs are constructed from config + base64url tokens (safe alphabet)
    # but we escape them too as defence-in-depth.
    html = _shell(
        title=f"Confirm your email — {_esc(config.app_name)}",
        heading=f"Welcome to {_esc(config.app_name)}",
        app_name=_esc(config.app_name),
        content=(
            f'<p style="margin:0 0 12px 0;line-height:1.5;color:#374151;">Hi {_esc(user.name)}, please confirm your email address to finish signing up.</p>'
            + _BUTTON.format(url=_esc(verify_url, quote=True), label="Confirm email")
            + f'<p style="margin:24px 0 0 0;line-height:1.5;color:#6b7280;font-size:13px;">'
            f"The link expires in {config.approval_token_expiry_hours} hours. "
            "If you didn't sign up, you can ignore this email."
            "</p>"
        ),
    )
    return EmailMessage(to=user.email, subject=subject, body=body, html=html)


# ---------------------------------------------------------------------------
# 2. Admin approval request — sent to admin after user verifies
# ---------------------------------------------------------------------------


def render_admin_approval_request(
    user: User, approve_url: str, reject_url: str, config: ParbakedConfig
) -> EmailMessage:
    if config.admin_email is None:
        raise RuntimeError(
            "Cannot render admin approval email: PARBAKED_ADMIN_EMAIL is unset. "
            "Either set it, or stop calling this template directly — the router "
            "only invokes it when admin_email is set."
        )
    subject = _subject_for(
        config,
        "admin_approval_request",
        f"New signup: {user.name} ({user.email})",
        user_name=user.name,
        user_email=user.email,
    )
    body = (
        f"A new user just signed up for {config.app_name}.\n\n"
        f"  Name:  {user.name}\n"
        f"  Email: {user.email}\n\n"
        "Approve:\n"
        f"  {approve_url}\n\n"
        "Reject:\n"
        f"  {reject_url}\n\n"
        f"Links expire in {config.approval_token_expiry_hours} hours.\n"
    )

    # Two-button HTML — approve is the primary, reject is a secondary text link
    # so the admin doesn't fat-finger the wrong one on mobile.
    # All user-controlled values are HTML-escaped — an attacker can set their
    # signup `name` / `email` arbitrarily, so embedding either un-escaped would
    # let them phish the admin (e.g. inject a fake "Approve" link to evil.com).
    html = _shell(
        title=f"New signup — {_esc(config.app_name)}",
        heading=f"New signup: {_esc(user.name)}",
        app_name=_esc(config.app_name),
        content=(
            f'<p style="margin:0 0 4px 0;color:#6b7280;font-size:13px;">Name</p>'
            f'<p style="margin:0 0 16px 0;line-height:1.5;color:#111;">{_esc(user.name)}</p>'
            f'<p style="margin:0 0 4px 0;color:#6b7280;font-size:13px;">Email</p>'
            f'<p style="margin:0 0 16px 0;line-height:1.5;color:#111;">{_esc(user.email)}</p>'
            + _BUTTON.format(url=_esc(approve_url, quote=True), label="Approve")
            + f'<p style="margin:8px 0 0 0;font-size:13px;color:#6b7280;">'
            f'Not them? <a href="{_esc(reject_url, quote=True)}" style="color:#b91c1c;text-decoration:underline;">Reject this signup</a>.'
            "</p>"
            f'<p style="margin:24px 0 0 0;line-height:1.5;color:#9ca3af;font-size:12px;">'
            f"Links expire in {config.approval_token_expiry_hours} hours."
            "</p>"
        ),
    )
    return EmailMessage(to=str(config.admin_email), subject=subject, body=body, html=html)


# ---------------------------------------------------------------------------
# 3. User approved — sent to user when admin approves
# ---------------------------------------------------------------------------


def render_user_approved(user: User, login_url: str, config: ParbakedConfig) -> EmailMessage:
    subject = _subject_for(
        config, "user_approved", "You're in", user_name=user.name
    )
    body = (
        f"Hi {user.name},\n\n"
        f"Your {config.app_name} account has been approved. "
        f"You can sign in at:\n\n  {login_url}\n\n"
        "— The team\n"
    )
    first_name = user.name.split()[0] if user.name.split() else user.name
    html = _shell(
        title=f"You're in — {_esc(config.app_name)}",
        heading=f"You're in, {_esc(first_name)}",
        app_name=_esc(config.app_name),
        content=(
            f'<p style="margin:0 0 12px 0;line-height:1.5;color:#374151;">'
            f"Your {_esc(config.app_name)} account is active. Sign in below to get started."
            "</p>"
            + _BUTTON.format(url=_esc(login_url, quote=True), label="Sign in")
        ),
    )
    return EmailMessage(to=user.email, subject=subject, body=body, html=html)


# ---------------------------------------------------------------------------
# 5. Password reset — sent in response to /auth/forgot-password
# ---------------------------------------------------------------------------


def render_password_reset_email(
    user: User, reset_url: str, config: ParbakedConfig
) -> EmailMessage:
    subject = _subject_for(
        config, "password_reset", "Reset your password", user_name=user.name
    )
    hours = config.password_reset_expiry_hours
    hour_unit = "hour" if hours == 1 else "hours"
    body = (
        f"Hi {user.name},\n\n"
        f"Someone requested a password reset for your {config.app_name} account. "
        "If that was you, click the link below to choose a new password:\n\n"
        f"  {reset_url}\n\n"
        f"This link expires in {hours} {hour_unit} and "
        "can only be used once.\n\n"
        "If you didn't request this, you can safely ignore this email — your "
        "password won't change.\n"
    )
    html = _shell(
        title=f"Reset your password — {_esc(config.app_name)}",
        heading="Reset your password",
        app_name=_esc(config.app_name),
        content=(
            f'<p style="margin:0 0 12px 0;line-height:1.5;color:#374151;">'
            f"Hi {_esc(user.name)}, someone requested a password reset for your "
            f"{_esc(config.app_name)} account. Click the button below to choose a new password."
            "</p>"
            + _BUTTON.format(url=_esc(reset_url, quote=True), label="Reset password")
            + f'<p style="margin:24px 0 0 0;line-height:1.5;color:#6b7280;font-size:13px;">'
            f"This link expires in {hours} {hour_unit} "
            "and can only be used once. If you didn't request this, you can "
            "safely ignore this email — your password won't change."
            "</p>"
        ),
    )
    return EmailMessage(to=user.email, subject=subject, body=body, html=html)


# ---------------------------------------------------------------------------
# 6. Admin sign-in — sent in email mode when the admin requests a login link (#130)
# ---------------------------------------------------------------------------


def render_admin_signin(signin_url: str, config: ParbakedConfig) -> EmailMessage:
    """Magic sign-in link sent to ``config.admin_email`` in email mode.

    Whoever reads the admin inbox is the admin. The link is short-lived
    (15 minutes by default) and genuinely one-shot — landing on the GET
    route verifies the token, rotates the per-admin signin nonce (#205),
    sets the admin session cookie, and redirects to the dashboard. A
    second click of the same URL fails the rotated-nonce check and
    bounces with a 400.
    """
    if config.admin_email is None:
        raise RuntimeError(
            "Cannot render admin sign-in email: PARBAKED_ADMIN_EMAIL is unset. "
            "The login form only requests this template when admin_email is set."
        )
    subject = _subject_for(config, "admin_signin", "Sign in to admin")
    body = (
        f"Hi,\n\n"
        f"Click the link below to sign in to the {config.app_name} admin "
        "dashboard. The link expires in 15 minutes.\n\n"
        f"  {signin_url}\n\n"
        "If you didn't request this, you can ignore the email.\n"
    )
    html = _shell(
        title=f"Sign in to admin — {_esc(config.app_name)}",
        heading=f"Sign in to {_esc(config.app_name)} admin",
        app_name=_esc(config.app_name),
        content=(
            '<p style="margin:0 0 12px 0;line-height:1.5;color:#374151;">'
            "Click the button below to sign in to the admin dashboard."
            "</p>"
            + _BUTTON.format(url=_esc(signin_url, quote=True), label="Sign in")
            + '<p style="margin:24px 0 0 0;line-height:1.5;color:#6b7280;font-size:13px;">'
            "This link expires in 15 minutes. "
            "If you didn't request it, you can ignore this email."
            "</p>"
        ),
    )
    return EmailMessage(to=str(config.admin_email), subject=subject, body=body, html=html)


# ---------------------------------------------------------------------------
# 7. Email change verify — sent to NEW address when user requests an email
#    change (#275, GDPR Article 16). Going to the new address (not the old)
#    is the GDPR-correct flow: prove you can read the destination inbox
#    before we move the account onto it.
# ---------------------------------------------------------------------------


def render_email_change_verify(
    user: User, new_email: str, verify_url: str, config: ParbakedConfig
) -> EmailMessage:
    subject = _subject_for(
        config,
        "email_change_verify",
        "Confirm your new email",
        user_name=user.name,
    )
    hours = config.password_reset_expiry_hours
    hour_unit = "hour" if hours == 1 else "hours"
    body = (
        f"Hi {user.name},\n\n"
        f"You asked to change the email on your {config.app_name} account to "
        f"{new_email}. Click the link below to confirm — until you do, your "
        "account stays on the current address.\n\n"
        f"  {verify_url}\n\n"
        f"This link expires in {hours} {hour_unit} and can only be used "
        "once.\n\n"
        "If you didn't request this, you can safely ignore this email — no "
        "change happens until the link is clicked.\n"
    )
    html = _shell(
        title=f"Confirm your new email — {_esc(config.app_name)}",
        heading="Confirm your new email",
        app_name=_esc(config.app_name),
        content=(
            f'<p style="margin:0 0 12px 0;line-height:1.5;color:#374151;">'
            f"Hi {_esc(user.name)}, you asked to change the email on your "
            f"{_esc(config.app_name)} account to "
            f"<strong>{_esc(new_email)}</strong>. Click the button below to "
            "confirm."
            "</p>"
            + _BUTTON.format(url=_esc(verify_url, quote=True), label="Confirm new email")
            + f'<p style="margin:24px 0 0 0;line-height:1.5;color:#6b7280;font-size:13px;">'
            f"This link expires in {hours} {hour_unit} "
            "and can only be used once. If you didn't request this, you can "
            "safely ignore this email."
            "</p>"
        ),
    )
    return EmailMessage(to=new_email, subject=subject, body=body, html=html)


# ---------------------------------------------------------------------------
# 8. Email change notice — sent to the OLD address after the swap completes
#    (#275). Courtesy notification so the previous-inbox owner notices an
#    unauthorised change and can contact the admin.
# ---------------------------------------------------------------------------


def render_email_changed_notice(
    user: User, old_email: str, new_email: str, config: ParbakedConfig
) -> EmailMessage:
    subject = _subject_for(
        config,
        "email_changed_notice",
        "Your email address was changed",
        user_name=user.name,
    )
    body = (
        f"Hi {user.name},\n\n"
        f"The email address on your {config.app_name} account was just "
        f"changed to {new_email}. Your existing sessions have been signed "
        "out as a precaution.\n\n"
        "If this wasn't you, contact your admin right away — they can "
        "freeze the account.\n"
    )
    html = _shell(
        title=f"Your email was changed — {_esc(config.app_name)}",
        heading="Your email address was changed",
        app_name=_esc(config.app_name),
        content=(
            f'<p style="margin:0 0 12px 0;line-height:1.5;color:#374151;">'
            f"Hi {_esc(user.name)}, the email address on your "
            f"{_esc(config.app_name)} account was just changed to "
            f"<strong>{_esc(new_email)}</strong>. Your existing sessions have "
            "been signed out as a precaution."
            "</p>"
            f'<p style="margin:24px 0 0 0;line-height:1.5;color:#6b7280;font-size:13px;">'
            "If this wasn't you, contact your admin right away — they can "
            "freeze the account."
            "</p>"
        ),
    )
    return EmailMessage(to=old_email, subject=subject, body=body, html=html)


# ---------------------------------------------------------------------------
# 4. User rejected — sent to user when admin rejects
# ---------------------------------------------------------------------------


def render_user_rejected(user: User, config: ParbakedConfig) -> EmailMessage:
    subject = _subject_for(
        config, "user_rejected", "About your signup", user_name=user.name
    )
    body = (
        f"Hi {user.name},\n\n"
        f"Thanks for your interest in {config.app_name}. "
        "Unfortunately we weren't able to approve your account at this time.\n\n"
        "— The team\n"
    )
    html = _shell(
        title=f"About your signup — {_esc(config.app_name)}",
        heading="About your signup",
        app_name=_esc(config.app_name),
        content=(
            f'<p style="margin:0 0 12px 0;line-height:1.5;color:#374151;">'
            f"Hi {_esc(user.name)}, thanks for your interest in {_esc(config.app_name)}. "
            "Unfortunately we weren't able to approve your account at this time."
            "</p>"
        ),
    )
    return EmailMessage(to=user.email, subject=subject, body=body, html=html)


# ---------------------------------------------------------------------------
# Templates bundle — override individual renderers if you want custom copy
# ---------------------------------------------------------------------------


@dataclass
class Templates:
    """Bundle of renderers. Pass a customised instance to override copy."""

    user_verify_email: Callable[[User, str, ParbakedConfig], EmailMessage] = field(
        default=render_user_verify_email
    )
    admin_approval_request: Callable[[User, str, str, ParbakedConfig], EmailMessage] = field(
        default=render_admin_approval_request
    )
    user_approved: Callable[[User, str, ParbakedConfig], EmailMessage] = field(
        default=render_user_approved
    )
    user_rejected: Callable[[User, ParbakedConfig], EmailMessage] = field(
        default=render_user_rejected
    )
    password_reset: Callable[[User, str, ParbakedConfig], EmailMessage] = field(
        default=render_password_reset_email
    )
    admin_signin: Callable[[str, ParbakedConfig], EmailMessage] = field(
        default=render_admin_signin
    )
    email_change_verify: Callable[[User, str, str, ParbakedConfig], EmailMessage] = field(
        default=render_email_change_verify
    )
    email_changed_notice: Callable[[User, str, str, ParbakedConfig], EmailMessage] = field(
        default=render_email_changed_notice
    )
