"""Email transport protocol."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable


@dataclass(frozen=True, slots=True)
class EmailMessage:
    to: str
    subject: str
    body: str
    """Plain-text body. Always present — fallback for clients that don't render HTML."""

    html: str | None = None
    """Optional HTML body. When set, transports send a multipart message so the
    recipient's client picks whichever it prefers (almost always HTML)."""


@runtime_checkable
class EmailTransport(Protocol):
    def send(self, message: EmailMessage) -> None: ...
