"""Kernel runtime — ``create_app()`` finds your routes instead of you wiring them (#45).

Convention::

    routes/index.py         → /
    routes/dashboard.py     → /dashboard
    routes/api/users.py     → /api/users

Each file must expose a module-level ``router: APIRouter``. Files without
one (or files starting with ``_``) are skipped quietly. Import errors
abort startup with a diagnostic that names the offending file — no
silent skipping of broken modules.

User routes that want the authenticated active user::

    from fastapi import APIRouter, Depends
    from parbaked.runtime import current_user

    router = APIRouter()

    @router.get("")
    def view(user = Depends(current_user)):
        return {"email": user.email}

The dependency resolves to the active Parbaked instance set up by
``create_app()``.
"""

from __future__ import annotations

import contextlib
import importlib.util
import logging
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Any

from fastapi import APIRouter, Depends, FastAPI
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlmodel import Session

from parbaked.app import Parbaked
from parbaked.config import ParbakedConfig

if TYPE_CHECKING:
    from parbaked.auth.models import User

logger = logging.getLogger("parbaked.runtime")

_active: Parbaked | None = None
_bearer = HTTPBearer(auto_error=False)


def _get_active() -> Parbaked:
    if _active is None:
        raise RuntimeError(
            "parbaked.runtime has no active instance — call create_app() "
            "before issuing requests."
        )
    return _active


def current_user(
    creds: HTTPAuthorizationCredentials | None = Depends(_bearer),
) -> User:
    """FastAPI dependency for the authenticated active user.

    Late-binds to the active Parbaked instance so route files can import
    this at module load — before ``create_app()`` has run.

    Plain ``def`` (not ``async def``) — none of the underlying work
    awaits. FastAPI routes sync dependencies through the threadpool so
    the bcrypt / DB calls don't stall the event loop (#206).
    """
    pb = _get_active()
    with Session(pb.engine) as session:
        return pb.current_user(creds=creds, session=session)


def get_session():
    """FastAPI dependency that yields a SQLModel ``Session`` against
    parbaked's database — the same engine ``current_user`` and the auth
    routes use, so foreign keys to ``users.id`` resolve correctly.

    Use this in consumer routes that read or write tables::

        from sqlmodel import Session, select
        from parbaked import current_user, get_session
        from models import Note

        @router.get("")
        def list_notes(
            user = Depends(current_user),
            session: Session = Depends(get_session),
        ):
            return session.exec(
                select(Note).where(Note.user_id == user.id)
            ).all()

    Late-binds the engine to the active Parbaked instance so route files
    can import this at module load — before ``create_app()`` has run.
    """
    pb = _get_active()
    with Session(pb.engine) as session:
        yield session


def _path_to_prefix(rel: Path) -> str:
    """Convert ``routes/api/users.py`` → ``/api/users``, ``index.py`` → ``""``."""
    parts = list(rel.with_suffix("").parts)
    if parts and parts[-1] == "index":
        parts = parts[:-1]
    if not parts:
        return ""
    return "/" + "/".join(parts)


def _load_route_module(file_path: Path, module_name: str) -> Any:
    """Import a routes/*.py file. Raises on import failure with the file path."""
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot build import spec for {file_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def _collides_with_parbaked(path: str, parbaked_paths: set[str]) -> str | None:
    """Return the offending parbaked path if ``path`` shadows it, else None.

    Two collision shapes (#190):
      1. Exact match — user route ``/auth/login`` vs parbaked ``/auth/login``.
      2. Namespace overlap — user route ``/health`` vs parbaked ``/health``,
         or any user path under ``/auth/`` (parbaked owns the whole subtree).

    The ``/auth/`` namespace is treated as a reserved subtree because
    parbaked also mounts ``/auth/admin/*`` and may add more routes there
    in future versions. Dropping a ``routes/auth/anything.py`` is almost
    certainly a mistake.
    """
    if path in parbaked_paths:
        return path
    # Subtree check: any parbaked path that starts with /auth/ means the
    # /auth namespace is reserved. A user path of /auth or /auth/<x>
    # collides.
    if path == "/auth" or path.startswith("/auth/"):
        return "/auth/*"
    return None


def _discover_routes(app: FastAPI, routes_dir: Path) -> tuple[int, dict[str, int]]:
    """Walk ``routes_dir``, mount any module-level ``router`` onto ``app``.

    Returns a tuple of ``(total_mounted, by_subdir)``. ``by_subdir`` maps
    each top-level subdirectory under ``routes_dir`` to the number of
    route files mounted from it; files mounted directly under
    ``routes_dir`` (no subdirectory) are bucketed under ``""``. The
    banner uses this to summarise the route surface as e.g.
    ``5 (/api × 3, /webhooks × 2)`` so a consumer can confirm a
    ``routes/webhooks/foo.py`` actually got picked up (#306).

    Raises ``RuntimeError`` with the offending path on the first import
    failure — partial discovery is worse than a clear stop.

    Also raises ``RuntimeError`` if a user route shadows (or is shadowed by)
    a parbaked-owned path (``/health``, anything under ``/auth/*``). Same
    loud-error pattern as the import-failure branch: silently overwriting
    parbaked's ``/auth/login`` (or having yours overwritten) is worse than
    a clear startup stop (#190).
    """
    by_subdir: dict[str, int] = {}
    if not routes_dir.exists():
        logger.debug("routes_dir %s does not exist — skipping discovery.", routes_dir)
        return 0, by_subdir

    # Snapshot the set of paths parbaked has already mounted on ``app``
    # so we can detect user routes that collide with them. ``app.routes``
    # at this point contains everything ``Parbaked(...)`` installed:
    # /health, /auth/*, /auth/admin/*, plus FastAPI's docs/openapi.
    parbaked_paths: set[str] = {
        getattr(r, "path", None) for r in app.routes if getattr(r, "path", None)
    }
    parbaked_paths.discard(None)  # type: ignore[arg-type]

    count = 0
    for file_path in sorted(routes_dir.rglob("*.py")):
        if file_path.name.startswith("_"):
            continue
        rel = file_path.relative_to(routes_dir)
        module_name = "parbaked_routes." + ".".join(
            p.replace("-", "_") for p in rel.with_suffix("").parts
        )
        try:
            module = _load_route_module(file_path, module_name)
        except Exception as exc:
            raise RuntimeError(
                f"Failed to import route file {file_path}: {exc}"
            ) from exc

        router = getattr(module, "router", None)
        if not isinstance(router, APIRouter):
            logger.debug(
                "Skipping %s — no module-level `router: APIRouter`.", file_path
            )
            continue
        prefix = _path_to_prefix(rel)

        # Compute the full paths this router would mount BEFORE calling
        # include_router. Each route inside the user's APIRouter has its
        # own ``.path`` (e.g. ``""`` or ``"/sub"``); the effective path is
        # ``prefix + route.path``. Checking before include_router keeps the
        # error message precise and avoids leaving partial state on app.
        for route in router.routes:
            sub_path = getattr(route, "path", None)
            if sub_path is None:
                continue
            full_path = prefix + sub_path
            # FastAPI normalises trailing slashes (``""`` becomes the
            # prefix itself); collapse to be safe.
            if full_path.endswith("/") and len(full_path) > 1:
                full_path = full_path.rstrip("/")
            if not full_path:
                full_path = "/"
            offender = _collides_with_parbaked(full_path, parbaked_paths)
            if offender is not None:
                raise RuntimeError(
                    f"Route file {file_path} mounts {full_path!r}, which "
                    f"collides with parbaked-owned path {offender!r}. "
                    f"Rename or move the file — parbaked reserves /health "
                    f"and the /auth/* namespace."
                )

        app.include_router(router, prefix=prefix)
        count += 1
        # Bucket by top-level subdirectory for the banner's "routes" row.
        # ``rel.parts[0]`` is either the first directory name (e.g.
        # ``"api"``, ``"webhooks"``) or, for a file directly under
        # ``routes/``, the filename — distinguished by ``len > 1``.
        bucket = rel.parts[0] if len(rel.parts) > 1 else ""
        by_subdir[bucket] = by_subdir.get(bucket, 0) + 1
        logger.info("Mounted %s at %s", file_path, prefix or "/")
    return count, by_subdir


def create_app(
    *,
    config_path: Path | str | None = None,
    routes_dir: Path | str | None = None,
    config: ParbakedConfig | None = None,
    **parbaked_kwargs: Any,
) -> FastAPI:
    """Build a FastAPI app with parbaked wired up + routes auto-discovered.

    This is the v1.0-stable entry point — the same code path
    ``parbaked dev`` invokes. Use it from a ``wsgi.py`` / ``asgi.py``
    when you want to run under a different ASGI server (Gunicorn,
    Hypercorn, Granian, …)::

        # wsgi.py
        from parbaked.runtime import create_app
        app = create_app()

        # then: gunicorn -k uvicorn.workers.UvicornWorker wsgi:app

    Parameters:

    ``config_path``
        Optional path to a non-default ``parbaked.toml`` location
        (the directory containing it, or the file itself). Used for
        monorepo layouts where the parbaked project root isn't the
        cwd. Ignored when ``config=`` is passed explicitly.

    ``routes_dir``
        Override the auto-discovery directory. Defaults to
        ``config.routes_dir`` (set in ``parbaked.toml`` or via
        ``PARBAKED_ROUTES_DIR``).

    ``config``
        A pre-built :class:`ParbakedConfig`. Takes precedence over
        ``config_path``.

    ``**parbaked_kwargs``
        Forwarded verbatim to :class:`Parbaked` — pass ``email=``,
        ``database_url=``, hooks, etc.

    Returns a fresh :class:`fastapi.FastAPI` instance. Calling
    ``create_app()`` twice returns two independent apps (the
    module-level ``current_user`` dependency tracks the most-recent
    instance — fine for the production "one process, one app" shape).
    """
    global _active

    if config is None:
        if config_path is not None:
            import os
            prev_cwd = Path.cwd()
            target = Path(config_path)
            if target.is_file():
                target = target.parent
            try:
                os.chdir(target)
                config = ParbakedConfig()
            finally:
                os.chdir(prev_cwd)
        else:
            config = ParbakedConfig()

    # Best-effort import of the project's ``models.py`` BEFORE Parbaked
    # runs ``SQLModel.metadata.create_all``. Without this, any
    # SQLModel table the consumer defines doesn't get registered with
    # metadata until ``_discover_routes`` later imports a route file
    # that imports the model — by which time create_all has run and
    # the table never exists. See issue #122.
    consumer_tables = _autoload_consumer_models()

    # Auto-discover lifecycle hooks from ``hooks.py`` at the project
    # root (#288). Without this, ``parbaked dev`` users have no way to
    # wire hooks since ``parbaked dev`` invokes ``create_app()`` with no
    # kwargs — the documented surface (``on_signup`` / ``on_verify`` /
    # ``on_approve`` / ``on_reject`` / ``on_delete``) becomes
    # unreachable. Explicit kwargs in ``create_app(on_signup=...)``
    # still win (precedence: explicit kwargs > hooks.py); tests and
    # advanced wiring keep the direct-kwarg path.
    hooks_kwargs = _autoload_consumer_hooks(Path.cwd())
    # Merge so explicit ``parbaked_kwargs`` overrides ``hooks.py``-
    # discovered callables for the same hook name. This lets
    # ``create_app(on_signup=mock)`` in a test fixture trump a stale
    # ``hooks.py`` that the test workspace happens to have on disk.
    merged_kwargs = {**hooks_kwargs, **parbaked_kwargs}

    # Set OpenAPI title/version/description from config + parbaked version
    # so ``/openapi.json`` shows the consumer's app_name and the kernel
    # version rather than FastAPI's default "FastAPI" / "0.1.0" (#186).
    # Consumers wiring their own FastAPI() can still override at install
    # time, but the create_app() path — which is what the docs steer
    # everyone toward — gets a sensible OpenAPI banner for free.
    #
    # In production we also disable the auto-generated Swagger UI
    # (``/docs``) and ReDoc (``/redoc``) endpoints (#220). They leak the
    # full route surface (including admin routes) to anonymous viewers
    # — not a hard CVE since the routes are still auth-gated, but a
    # needless information disclosure. Dev still gets them so the
    # explorer-driven workflow keeps working. ``/openapi.json`` stays
    # reachable in both envs: the OpenAPI contract is the API contract,
    # and existing tests/external clients depend on it.
    from parbaked import __version__ as _pb_version
    _is_prod = config.env == "production"
    app = FastAPI(
        title=config.app_name,
        version=_pb_version,
        description=(
            f"{config.app_name} — API surface (auth, admin, user routes). "
            f"Built on parbaked v{_pb_version}."
        ),
        docs_url=None if _is_prod else "/docs",
        redoc_url=None if _is_prod else "/redoc",
    )
    # ``Parbaked(app, ...)`` runs ``Parbaked.install`` which in turn
    # runs ``apply_migrations`` → ``SQLModel.metadata.create_all`` against
    # whatever's currently registered on metadata. That means: the
    # parbaked-owned tables (``users``, ``_parbaked_schema_version``)
    # plus whatever the consumer's ``models.py`` declared above. Tables
    # defined INSIDE ``routes/*.py`` files won't be picked up — the route
    # files haven't been imported yet, so their ``SQLModel`` subclasses
    # aren't on metadata at this point. The kernel-runtime convention is
    # "tables live in models.py" (#233; see AGENTS.md "Wiring a per-user
    # table"). Previously there was a second ``create_all`` after
    # ``_discover_routes`` as a safety net — that masked the convention
    # and was removed; if you need a route-defined table to exist, move
    # it to ``models.py``.
    # Defer the boot banner until AFTER ``_discover_routes`` so the
    # banner can report the route surface alongside the models/hooks
    # discovery (#306). Otherwise the banner prints before routes have
    # been mounted and the consumer can't tell from a single line of
    # output whether ``routes/webhooks/foo.py`` was actually picked up.
    # The caller's ``banner=False`` request (if any) still wins.
    show_banner = merged_kwargs.pop("banner", True)

    # ``parbaked --quiet dev`` exports ``PARBAKED_VERBOSITY=quiet`` into
    # the uvicorn child process so the banner + ``parbaked.runtime``
    # INFO logs that the parent's ``set_verbosity`` adjusted can't
    # reach this re-imported process (#387, fix for #384 regression).
    # We honour the env var here so the same suppression lands whether
    # ``create_app`` is invoked by ``parbaked dev`` or directly from a
    # consumer's ``wsgi.py``. ``--verbose`` symmetrically bumps the
    # ``parbaked`` logger to DEBUG. Default (env unset, or set to
    # ``"normal"``) preserves pre-#387 behaviour exactly — banner on,
    # logger at INFO.
    import os as _os
    _verbosity = _os.environ.get("PARBAKED_VERBOSITY", "").strip().lower()
    if _verbosity == "quiet":
        show_banner = False
    pb = Parbaked(app, config=config, banner=False, **merged_kwargs)
    # Set the parbaked logger level AFTER ``Parbaked.__init__`` runs —
    # its ``configure_logging()`` call resets the logger to INFO on the
    # first invocation in this process (the uvicorn child is fresh).
    # Setting it before would be silently overridden. ``show_banner`` is
    # set earlier because it's a local variable, not a logger level.
    if _verbosity == "quiet":
        logging.getLogger("parbaked").setLevel(logging.WARNING)
    elif _verbosity == "verbose":
        logging.getLogger("parbaked").setLevel(logging.DEBUG)
    _active = pb

    resolved_routes_dir = (
        Path(routes_dir) if routes_dir is not None else Path(config.routes_dir)
    )
    route_count, route_breakdown = _discover_routes(app, resolved_routes_dir)

    _mount_frontend(app, config)

    if show_banner:
        # Stash the discovery snapshot on the instance so the banner
        # builder can read it without a wider signature change. Only the
        # banner consumes this — it isn't part of the public ``Parbaked``
        # surface.
        pb._discovered = {
            "models": list(consumer_tables),
            "hooks": sorted(hooks_kwargs.keys()),
            "routes_total": route_count,
            "routes_by_subdir": dict(route_breakdown),
        }
        pb._print_banner()
    return app


#: Tables that parbaked owns. Used to subtract parbaked's own metadata
#: from a snapshot taken after the consumer's ``models.py`` imports, so
#: the banner can report "N consumer tables" without counting the auth /
#: schema-version tables the kernel installs unconditionally.
_PARBAKED_OWNED_TABLES = frozenset({
    "users",
    "_parbaked_schema_version",
    "_parbaked_admin_signin_nonce",
    "_parbaked_admin_revocations",
})


#: URL prefixes the SPA fallback must refuse — anything under these is a
#: documented backend surface (#331). ``/auth/*`` is parbaked's own auth
#: API, ``/api/*`` is the consumer's API namespace (``routes/api/*.py``),
#: ``/webhooks/*`` is the consumer's webhook surface. A typo'd path
#: under any of these (``/auth/loginz``, ``/api/userz``) must return the
#: natural FastAPI 404 JSON, not get silently rewritten to a 200 + HTML
#: ``index.html`` body — that would make a JSON consumer think their
#: request succeeded and is part of the wider "SPA mount eats API
#: 404s" family of bugs (#132 fixed the bare-path JSON-consumer case;
#: #304 fixed the static-asset case; this fixes the prefix case).
_BACKEND_PREFIXES = ("/auth/", "/api/", "/webhooks/")

#: Exact-match backend paths the SPA fallback must refuse alongside the
#: prefix set above. ``/health`` is parbaked-owned and the route resolves
#: before the SPA mount in normal operation — this guard is a
#: belt-and-suspenders so even if a future refactor reorders mounts the
#: fallback can't silently hand back ``index.html`` for it.
#:
#: The bare ``/auth``, ``/api``, ``/webhooks`` entries close the
#: trailing-slash gap (#357): the prefix tuple above only catches
#: ``/auth/`` (with slash), so a bare ``GET /auth`` would fall through
#: to the SPA and return 200 HTML — the same JSON-consumer-corruption
#: bug #331 fixed for typo'd subpaths, just at the segment boundary.
#: Lookalikes like ``/apidocs`` / ``/authentic`` are NOT matched because
#: they're neither exact-equal nor under the trailing-slash prefix.
_BACKEND_EXACT = frozenset({"/health", "/auth", "/api", "/webhooks"})


def _autoload_consumer_models() -> list[str]:
    """Import ``models`` from cwd if it exists, so consumer SQLModel
    tables register with metadata before Parbaked's create_all runs.

    No ``models.py`` / ``models/`` → silent no-op (truly nothing to
    say); returns ``[]``. Otherwise the file exists and we MUST be able
    to import it, or the consumer will hit ``no such table`` on first
    query — abort boot with a clear, file-named ``RuntimeError``
    instead, matching ``_discover_routes``' contract for broken route
    files (#181).

    Returns the sorted list of consumer-side tables the import added to
    ``SQLModel.metadata`` (#306). The banner uses this to confirm that
    ``models.py`` was picked up and which tables it declared.
    """
    import importlib
    import sys
    from pathlib import Path as _P

    from sqlmodel import SQLModel

    models_file = _P("models.py")
    models_pkg = _P("models")
    if not models_file.exists() and not models_pkg.is_dir():
        return []
    offender = models_file if models_file.exists() else models_pkg
    # Make cwd importable in case the consumer's project isn't an
    # installed package.
    cwd = str(_P.cwd())
    added = False
    if cwd not in sys.path:
        sys.path.insert(0, cwd)
        added = True
    # Pop any cached models module from a different cwd (test/dev
    # scenarios that boot multiple parbaked apps in one process).
    # Production sees this branch on second-and-onwards reloads.
    sys.modules.pop("models", None)
    before = set(SQLModel.metadata.tables)
    try:
        importlib.import_module("models")
    except Exception as exc:
        raise RuntimeError(
            f"Failed to import models file {offender}: {exc!r}. "
            "Fix the import error above — leaving it in place would "
            "let boot succeed but produce 'no such table' SQL errors "
            "the first time a route queries a table this file should "
            "have defined."
        ) from exc
    finally:
        if added:
            with contextlib.suppress(ValueError):
                sys.path.remove(cwd)
    # Compute consumer-side additions: tables registered during the
    # import that aren't parbaked-owned. Subtracting the ``before`` set
    # too means a test that imports ``models.py`` twice in one process
    # still reports the tables on the second boot — the second import
    # is a no-op for sys.modules but the metadata snapshot already
    # contains them. (Tests that need a fresh snapshot pop the cached
    # module from sys.modules; see test_models_autoload.)
    after = set(SQLModel.metadata.tables)
    new_consumer = sorted(
        name for name in after
        if name not in _PARBAKED_OWNED_TABLES and name not in before
    )
    if new_consumer:
        return new_consumer
    # Second-boot case: ``models`` is already in sys.modules from a
    # prior call in the same process, ``before`` already contained the
    # tables, so the subtraction-against-before came up empty. Fall
    # back to "everything in metadata that isn't parbaked-owned" so the
    # banner still reflects what the consumer has declared.
    return sorted(
        name for name in after if name not in _PARBAKED_OWNED_TABLES
    )


#: Lifecycle hook names auto-discovered from ``hooks.py`` (#288). Mirrors
#: the surface ``Parbaked.__init__`` accepts and matches the dataclass
#: fields on :class:`parbaked.hooks.Hooks`. Keep in sync if a new hook
#: lands.
_KNOWN_HOOK_NAMES = ("on_signup", "on_verify", "on_approve", "on_reject", "on_delete")


def _autoload_consumer_hooks(project_root: Path) -> dict[str, Any]:
    """Import ``hooks.py`` from ``project_root`` if it exists; return a
    dict of hook name → callable suitable for forwarding to
    :class:`Parbaked` via ``create_app``'s ``**parbaked_kwargs`` (#288).

    Looks for module-level names matching the hook API:
    ``on_signup`` / ``on_verify`` / ``on_approve`` / ``on_reject`` /
    ``on_delete``. Missing names are silently fine — consumers wire only
    the events they care about. Anything else in the module (helper
    functions, constants, imports) is ignored.

    Missing ``hooks.py`` → silent no-op (returns ``{}``), exactly like
    the ``_autoload_consumer_models`` ``no models.py`` branch — a
    consumer who hasn't written any hooks shouldn't see noise.

    Broken ``hooks.py`` (syntax error, ImportError) → loud ``RuntimeError``
    naming the file, mirroring the ``_autoload_consumer_models`` contract
    from #181. Silently swallowing the failure would leave the consumer
    with documented-but-non-firing hooks — a worse debug experience than
    a clear boot stop.

    Non-callable hook symbols (e.g. ``on_signup = "literal"``) → log a
    WARNING naming the offending symbol and skip it. The module imported
    fine, the typo is recoverable, and crashing boot for a stale symbol
    a dev forgot to delete would feel punishing.

    Adds ``project_root`` to ``sys.path`` so hook bodies can resolve
    sibling-module imports (``from models import Link``,
    ``from utils import slack_ping``) regardless of caller surface
    (#409). The HTTP path got this implicitly via uvicorn's cwd default;
    the CLI / MCP surfaces (#332 / #356) did not, so hooks "fired" but
    silently raised ``ModuleNotFoundError`` inside the swallowed
    traceback. Idempotent on repeated calls.
    """
    hooks_file = project_root / "hooks.py"
    if not hooks_file.exists():
        return {}

    # Unlike ``_autoload_consumer_models`` (which removes its sys.path
    # entry once tables are registered), we deliberately leave the
    # project root on sys.path: hook bodies can lazy-import siblings
    # at fire time (#409 repro: ``from models import Link`` inside
    # ``on_approve``), which happens after this helper returns. CLI /
    # MCP processes exit shortly after the command runs and the HTTP
    # path already has cwd on sys.path via uvicorn, so the mutation
    # matches what every other surface already lives with.
    root_str = str(project_root.resolve())
    if root_str not in sys.path:
        sys.path.insert(0, root_str)

    module_name = "parbaked_consumer_hooks"
    # Pop any cached module from a prior boot (test scenarios that
    # build multiple parbaked apps in one process — same pattern as the
    # models autoload).
    sys.modules.pop(module_name, None)
    try:
        spec = importlib.util.spec_from_file_location(module_name, hooks_file)
        if spec is None or spec.loader is None:
            raise ImportError(f"Cannot build import spec for {hooks_file}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
    except Exception as exc:
        # Drop the half-imported module so a later retry doesn't pick
        # up a partially-initialised module object.
        sys.modules.pop(module_name, None)
        raise RuntimeError(
            f"Failed to import hooks file {hooks_file}: {exc!r}. "
            "Fix the import error above — leaving it in place would "
            "let boot succeed but produce silently-non-firing lifecycle "
            "hooks the consumer has documented in hooks.py."
        ) from exc

    discovered: dict[str, Any] = {}
    for name in _KNOWN_HOOK_NAMES:
        candidate = getattr(module, name, None)
        if candidate is None:
            continue
        if not callable(candidate):
            logger.warning(
                "hooks.py exposes %r but it is not callable (got %r) — "
                "skipping. Lifecycle hooks must be module-level functions.",
                name,
                type(candidate).__name__,
            )
            continue
        discovered[name] = candidate
    return discovered


def _mount_frontend(app: FastAPI, config: ParbakedConfig) -> None:
    """Mount the user's frontend at ``/`` if a ``[frontend]`` block is
    configured (#115).

    When ``build_command`` is set, the runtime image holds the build
    output at ``source_dir/dist_subpath`` (see ``deploy_gen``); we
    serve that. Otherwise the raw ``source_dir`` is the static root.

    Skipped silently when the directory doesn't exist — that way a
    dev who hasn't run their frontend build yet can still hit the API
    while iterating.

    ``html=True`` gives SPA fallback: any unmatched path (that the
    earlier auth/user routers also didn't claim) serves ``index.html``
    so HTML5 history routing works for React Router / Vue Router /
    etc. without server changes.

    Replacing the starter ``web/index.html`` with your own framework?
    The starter quietly satisfies a contract with the auth API (CSP
    nonce on inline scripts, label-for pairing, ``autocomplete=``
    tokens password managers expect, 422 detail array rendering, the
    three-state ``/auth/me`` machine, etc.). See AGENTS.md →
    "Replacing the starter — what you take on" for the full list (#316).
    """
    if not config.frontend or not config.frontend.source_dir:
        return
    from fastapi import HTTPException
    from fastapi.responses import HTMLResponse
    from fastapi.staticfiles import StaticFiles
    from starlette.exceptions import HTTPException as StarletteHTTPException
    from starlette.responses import FileResponse

    from parbaked.security_headers import CSP_NONCE_PLACEHOLDER

    serve_root = Path(config.frontend.source_dir)
    if config.frontend.build_command:
        serve_root = serve_root / config.frontend.dist_subpath
    if not serve_root.is_dir():
        logger.warning(
            "frontend mount: %s does not exist — frontend will not be served. "
            "Check ``source_dir`` in parbaked.toml, or remove the [frontend] "
            "block if you don't want a frontend mounted.",
            serve_root,
        )
        return
    # Directory exists but index.html is missing → StaticFiles would still
    # mount, but the SPA fallback (html=True) plus the SPAStaticFiles 404
    # rewrite would just return 404s with no diagnostic. Warn loudly so a
    # vibe-coder who emptied web/ by accident doesn't burn 20 minutes
    # chasing a phantom routing bug (#171).
    if not (serve_root / "index.html").is_file():
        logger.warning(
            "frontend mount: %s/index.html not found — frontend will 404. "
            "Drop an index.html into %s, or remove the [frontend] block "
            "from parbaked.toml.",
            serve_root,
            serve_root,
        )

    class SPAStaticFiles(StaticFiles):
        """``StaticFiles`` with SPA history-routing fallback.

        Starlette's ``html=True`` serves ``index.html`` for directory
        roots but 404s for arbitrary unmatched paths like
        ``/dashboard/settings``. SPAs that use HTML5 history routing
        (React Router, Vue Router) need those to serve ``index.html``
        too so the client-side router can pick up the path. Catch the
        404 and rewrite.

        Gate the rewrite on the ``Accept`` header so that JSON-explicit
        API clients (``Accept: application/json``) still get a 404
        instead of being silently handed an HTML body. Browsers send
        ``Accept: text/html,...`` (or ``*/*``) and continue to get the
        SPA fallback. Missing ``Accept`` is treated as ``*/*`` because
        that's what most clients default to. (#132)

        Also gate on the request *path*: a request for any path that
        ends in a non-``.html`` file extension (``/favicon.ico``,
        ``/robots.txt``, ``/apple-touch-icon.png``, ``/manifest.json``,
        ``/static/main.js``) is the browser asking for a specific
        asset — if it isn't on disk, the honest answer is 404.
        Returning ``index.html``'s body for ``GET /favicon.ico``
        (#304) is actively misleading: the browser tries to render
        10KB of HTML as an icon, silently fails, and the developer's
        Network tab shows ``favicon.ico`` served as ``text/html`` with
        no console error. Paths with no extension (``/dashboard``,
        ``/profile``) are still treated as client-side routes and
        fall back to ``index.html``.
        """

        @staticmethod
        def _path_looks_like_static_asset(path: str) -> bool:
            """True if ``path`` ends in a non-HTML file extension —
            i.e. the browser is asking for a specific static asset,
            not a client-side SPA route.

            ``.html`` / ``.htm`` (and the empty extension) are
            deliberately excluded: a hand-typed ``/about.html`` from a
            developer mid-migration should still fall back to the SPA
            (the SPA is itself HTML — the fallback isn't lying about
            the content type), and a bare path like ``/dashboard`` is
            unambiguously a route.

            We don't bother with an explicit allowlist of asset
            extensions (.ico/.png/.js/.css/...). Any extension that
            isn't ``.html``/``.htm`` is, by convention, a file the
            browser expects to receive verbatim. New asset types
            (.avif, .webmanifest, .woff3) get covered for free.
            """
            last_segment = path.rsplit("/", 1)[-1]
            if "." not in last_segment:
                return False
            ext = last_segment.rsplit(".", 1)[-1].lower()
            # An empty extension (``foo.``) isn't an asset request.
            if not ext:
                return False
            return ext not in ("html", "htm")

        @staticmethod
        def _path_is_backend_reserved(scope) -> bool:
            """True if the request URL targets a documented backend
            surface — anything under ``/auth/``, ``/api/``, ``/webhooks/``
            or the exact ``/health`` route (#331).

            The SPA fallback must refuse to rewrite 404s for these
            paths: ``/auth/loginz`` is a typo'd parbaked auth route,
            ``/api/userz`` is a typo'd consumer API route, and the
            JSON consumer that issued the request expects a 4xx JSON
            body — handing them ``index.html`` and a 200 silently
            corrupts the API contract.

            We read the URL path off the scope rather than the
            normalised ``path`` argument ``StaticFiles`` produces
            (which has stripped its leading ``/`` and applied OS
            separators). Keeping the prefix list in real-URL shape
            (``"/auth/"``) keeps it greppable next to the docs.
            """
            url_path = scope.get("path", "") or ""
            if url_path in _BACKEND_EXACT:
                return True
            return any(url_path.startswith(p) for p in _BACKEND_PREFIXES)

        @staticmethod
        def _accepts_html(scope) -> bool:
            accept = ""
            for raw_key, raw_value in scope.get("headers", []):
                # ASGI guarantees lower-case header names, but be
                # defensive: some test clients are sloppy.
                if raw_key.lower() == b"accept":
                    accept = raw_value.decode("latin-1")
                    break
            if not accept:
                # No Accept header → treat as */* (curl, most stdlib
                # clients). Serve the SPA so a copy-pasted URL still
                # works.
                return True
            tokens = [tok.split(";", 1)[0].strip().lower() for tok in accept.split(",")]
            return "text/html" in tokens or "*/*" in tokens or "text/*" in tokens

        @staticmethod
        def _stamp_csp_nonce(response, scope):
            """If ``response`` is an HTML ``FileResponse`` carrying the
            CSP-nonce placeholder, read its body, substitute the real
            per-request nonce, and return an :class:`HTMLResponse` with
            the rewritten body. Non-HTML / non-FileResponse responses
            (and HTML responses without the placeholder) pass through.

            The nonce lives on ``scope["state"]["csp_nonce"]`` — the
            ``SecurityHeadersMiddleware`` mints it per request before
            the static mount runs (#262).
            """
            if not isinstance(response, FileResponse):
                return response
            media_type = (response.media_type or "").lower()
            if not media_type.startswith("text/html"):
                return response
            # ``request.state`` lives at ``scope["state"]`` in Starlette.
            state = scope.get("state") or {}
            nonce = state.get("csp_nonce")
            if not nonce:
                # No nonce on the scope (security middleware not wired,
                # or this path bypasses it). Leave the placeholder
                # in-place rather than ship broken HTML — the route is
                # already broken and silent substitution would mask it.
                return response
            file_path = getattr(response, "path", None)
            if file_path is None:
                return response
            try:
                body = Path(file_path).read_bytes()
            except OSError:
                return response
            if body is None or CSP_NONCE_PLACEHOLDER.encode() not in body:
                return response
            rewritten = body.replace(
                CSP_NONCE_PLACEHOLDER.encode(), nonce.encode()
            )
            html_response = HTMLResponse(
                rewritten, status_code=response.status_code
            )
            # The body changes on every response because the substituted
            # nonce is per-request. The FileResponse's ETag /
            # Last-Modified are stat-derived (inode, mtime, size) and
            # would tell the browser "the response hasn't changed" —
            # triggering a 304 on conditional requests and pinning the
            # nonce to whatever was minted at first fetch. That would
            # collapse per-request rotation back to a static value,
            # making the nonce equivalent to ``'unsafe-inline'`` for
            # return visitors (#262, Devin). Force ``no-store`` so the
            # browser always re-fetches and gets a fresh nonce.
            html_response.headers["cache-control"] = "no-store"
            return html_response

        async def get_response(self, path, scope):
            try:
                response = await super().get_response(path, scope)
            except (HTTPException, StarletteHTTPException) as exc:
                # SPA fallback fires only when ALL of these hold:
                #   - it's a 404 (other errors propagate verbatim)
                #   - the client accepts HTML (#132 — JSON consumers
                #     get the honest 404)
                #   - the path doesn't look like a static-asset
                #     request (#304 — a missing /favicon.ico should
                #     404, not get handed index.html and rendered as a
                #     broken icon)
                #   - the URL path isn't under a documented backend
                #     prefix (#331 — a typo'd /auth/loginz or
                #     /api/userz must surface as 404 JSON, not get
                #     rewritten to a 200 + index.html and silently
                #     break the JSON-API contract for consumers)
                if (
                    exc.status_code == 404
                    and self._accepts_html(scope)
                    and not self._path_looks_like_static_asset(path)
                    and not self._path_is_backend_reserved(scope)
                ):
                    response = await super().get_response("index.html", scope)
                else:
                    raise
            return self._stamp_csp_nonce(response, scope)

    app.mount(
        "/",
        SPAStaticFiles(directory=str(serve_root), html=True),
        name="frontend",
    )
    logger.info("Mounted frontend from %s at /", serve_root)


def _reset_for_tests() -> None:
    """Clear the module-level active instance. Test-only."""
    global _active
    _active = None
