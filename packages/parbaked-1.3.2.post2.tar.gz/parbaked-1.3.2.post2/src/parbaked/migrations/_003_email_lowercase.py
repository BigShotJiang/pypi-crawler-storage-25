"""Migration 0003: lower-case existing emails + recreate the email index
with ``COLLATE NOCASE`` (#261 item 5).

Pre-#164 emails were stored in whatever case the user typed. #164
introduced application-level normalisation (``.lower()`` at every
write/read site), but the DB column itself had no case-insensitive
collation — so anything that bypassed the service layer (a future
``parbaked admin create-user`` CLI, a hand-written SQL migration, a
direct script) could insert mixed-case rows that the lookup queries
couldn't find. Belt only, not belt-and-braces.

This migration:

1. Lower-cases every existing ``users.email`` row. Pre-#164 deployments
   may have stored mixed-case addresses; bring them to the canonical
   lower-case form so the index can enforce uniqueness across case
   variants without colliding with stored values.
2. Drops the existing ``ix_users_email`` unique index and recreates it
   with ``COLLATE NOCASE``. From then on the DB itself rejects a
   collision between ``Foo@x.com`` and ``foo@x.com`` regardless of
   what wrote them — the application-level ``.lower()`` becomes
   defence-in-depth, not the sole guard.

Forward-only / additive contract: no DROP COLUMN, no data loss. The
lower-casing step is idempotent — running it twice produces the same
result. The index drop+recreate is guarded with ``DROP INDEX IF
EXISTS`` so re-running is safe.

A theoretical edge case: two pre-#164 rows that differ only in email
case (``Foo@x.com`` and ``foo@x.com``) would collide once both are
lower-cased. Since #164 shipped well before v1.0 and the application
always normalised at signup, such a pair can only exist in a DB that
was hand-edited. We surface this loudly: collision is caught when the
new unique index is created and the migration raises, with the offending
emails identifiable from the SQLite error. Operators with such data
must dedupe manually before re-running ``parbaked admin migrate``.
"""

from __future__ import annotations

from sqlalchemy import text
from sqlalchemy.engine import Connection


def up(conn: Connection) -> None:
    # 1. Lower-case every email row. SQLite's ``lower()`` is ASCII-only,
    #    which matches Python's ``str.lower()`` semantics for the email
    #    characters we care about (the local-part / domain are restricted
    #    by RFC 5321 to ASCII once stored — internationalised addresses
    #    pre-encode their non-ASCII bytes).
    conn.execute(text("UPDATE users SET email = lower(email) WHERE email != lower(email)"))

    # 2. Drop the existing case-sensitive unique index, then recreate it
    #    with COLLATE NOCASE so the DB enforces case-insensitive
    #    uniqueness. SQLModel's ``Field(unique=True, index=True)``
    #    produces the index named ``ix_users_email`` (verified against
    #    metadata.create_all output); the IF EXISTS guard makes the
    #    DROP idempotent in case a future schema rev renames it.
    conn.execute(text("DROP INDEX IF EXISTS ix_users_email"))
    conn.execute(
        text(
            "CREATE UNIQUE INDEX ix_users_email ON users (email COLLATE NOCASE)"
        )
    )
