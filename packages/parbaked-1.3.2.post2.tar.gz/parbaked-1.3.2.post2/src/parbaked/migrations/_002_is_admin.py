"""Migration 0002: add ``users.is_admin`` (#38).

Brings v0.8 (and earlier) DBs up to the v0.9 schema with the
admins-as-Users flag. Idempotent — PRAGMA-guarded so it's safe against
DBs where ``create_all`` already added the column on a fresh install.
"""

from __future__ import annotations

from sqlalchemy import text
from sqlalchemy.engine import Connection

from parbaked.migrations._runner import existing_columns


def up(conn: Connection) -> None:
    cols = existing_columns(conn)
    if "is_admin" not in cols:
        # SQLite ALTER TABLE only takes literal defaults — ``0`` for boolean.
        conn.execute(
            text("ALTER TABLE users ADD COLUMN is_admin BOOLEAN NOT NULL DEFAULT 0")
        )
