"""Migration 0005: add ``_parbaked_admin_revocations`` (#424).

The admin-session JTI revocation set added by #200 lived in module-local
memory (``parbaked.admin._revoked_jtis``). A parbaked restart cleared
the dict, so a previously-stolen cookie could be replayed for up to 12
hours after the legitimate operator's logout — for the rest of the
JWT's TTL.

The fix is a tiny SQLite table that holds ``(jti, exp)`` rows. The
admin router writes to it on logout and queries it on every request;
GC happens lazily on every query (rows whose ``exp`` has passed are
deleted, keeping the table bounded by the live-token population). See
:class:`parbaked.auth.models.AdminRevocation` for the model and
``parbaked.admin._is_revoked`` / ``_revoke_jti`` for the wiring.

Idempotent — CREATE IF NOT EXISTS so the same script is safe against:

- a brand-new DB where ``create_all`` already planted the empty table
  (this migration is a no-op).
- a v1.3 DB that booted before this migration shipped (this migration
  creates the table).
- a DB that already ran this migration (the statement no-ops).
"""

from __future__ import annotations

from sqlalchemy import text
from sqlalchemy.engine import Connection


def up(conn: Connection) -> None:
    # The table is created by ``SQLModel.metadata.create_all`` on a fresh
    # DB; the CREATE IF NOT EXISTS here is the explicit-step path for
    # upgrades that have an existing v1.3 DB without the new table.
    conn.execute(
        text(
            "CREATE TABLE IF NOT EXISTS _parbaked_admin_revocations ("
            "jti VARCHAR(64) PRIMARY KEY, "
            "exp FLOAT NOT NULL"
            ")"
        )
    )
