"""Migration 0001: add the columns v0.8 introduced.

Brings a v0.7 ``users`` table up to the v0.8 schema:

- ``revoked_at TIMESTAMP`` (#37)

Note: this migration previously also added ``google_sub VARCHAR``
(#41) + a unique index. The Google OAuth feature was removed entirely
in v1.2; the ``google_sub`` add is no longer applied on fresh DBs.
v1.1 deployments that already have the column keep it as an orphaned
unused column — SQLAlchemy + the post-strip model are tolerant. We
deliberately don't ship a destructive DROP COLUMN migration: the
forward-only contract says additive changes only between major
versions, and dropping a column qualifies as breaking.

Idempotent — safe to run against a DB that already has the columns
(virgin v0.9+ installs, or v0.8 deployments upgrading). We check
``PRAGMA table_info`` rather than catching duplicate-column errors so
the operation is observable to anyone tailing the migration log.
"""

from __future__ import annotations

from sqlalchemy import text
from sqlalchemy.engine import Connection

from parbaked.migrations._runner import existing_columns


def up(conn: Connection) -> None:
    cols = existing_columns(conn)
    if "revoked_at" not in cols:
        conn.execute(text("ALTER TABLE users ADD COLUMN revoked_at TIMESTAMP"))
