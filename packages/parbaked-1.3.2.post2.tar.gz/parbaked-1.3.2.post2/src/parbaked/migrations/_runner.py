"""Migration runner — applies any pending migrations, records the version.

Called from :meth:`Parbaked.install` in place of the bare ``create_all``
that v0.8 and earlier used. Behaviour:

- A virgin DB gets ``SQLModel.metadata.create_all`` (creates ``users`` +
  ``_parbaked_schema_version`` at the latest shape), then migrations run
  idempotently and the version row is stamped.
- An existing v0.7/v0.8 DB has ``users`` already but no version table.
  ``create_all`` adds the version table; the migration's PRAGMA-guarded
  ALTERs add any missing columns.
- An up-to-date DB short-circuits — version row equals LATEST, no
  migrations run, no SQL emitted.

If any migration raises, the runner re-raises so :class:`Parbaked` can
refuse to boot. Failed migrations should never silently leave a
partially-migrated DB.
"""

from __future__ import annotations

from sqlalchemy import text
from sqlalchemy.engine import Connection, Engine
from sqlmodel import Session, SQLModel, select


def existing_columns(conn: Connection) -> set[str]:
    """Return the column names of the ``users`` table.

    PRAGMA-based — used by migrations to guard ``ALTER TABLE ADD
    COLUMN`` calls so they're idempotent against DBs where
    ``create_all`` already added the column (fresh v0.9+ installs) and
    DBs where a prior boot already ran the migration.

    Lives here rather than in each migration module so every
    PRAGMA-guarded migration shares one helper.
    """
    rows = conn.execute(text("PRAGMA table_info(users)")).fetchall()
    return {row[1] for row in rows}


def _latest_version_const() -> int:
    """Late-import to avoid circular: migrations.__init__ imports this module."""
    from parbaked.migrations import MIGRATIONS

    return len(MIGRATIONS)


def _current_version(session: Session) -> int:
    """Read the recorded version, or 0 if no row exists yet."""
    from parbaked.auth.models import SchemaVersion

    row = session.exec(select(SchemaVersion)).first()
    if row is None:
        return 0
    return row.version


def _set_version(session: Session, version: int) -> None:
    from parbaked.auth.models import SchemaVersion

    row = session.exec(select(SchemaVersion)).first()
    if row is None:
        row = SchemaVersion(id=1, version=version)
    else:
        row.version = version
    session.add(row)
    session.commit()


def _users_table_exists(engine: Engine) -> bool:
    """Tells "fresh DB" from "existing v0.7/v0.8 DB" so we can pick the
    right starting version for the migration loop."""
    with engine.connect() as conn:
        row = conn.execute(
            text(
                "SELECT name FROM sqlite_master "
                "WHERE type='table' AND name='users'"
            )
        ).first()
    return row is not None


def apply_migrations(engine: Engine) -> None:
    """Bring the parbaked DB up to the latest schema. Forward-only."""
    from parbaked.migrations import MIGRATIONS

    # If this is a fresh DB, ``create_all`` does the right thing and the
    # migrations below become idempotent no-ops. If users exists already
    # (v0.7/v0.8 upgrade) ``create_all`` only adds the version table —
    # then the migrations bring the users table up to date.
    was_fresh = not _users_table_exists(engine)
    SQLModel.metadata.create_all(engine)

    with Session(engine) as session:
        current = _current_version(session)
        latest = _latest_version_const()

        if was_fresh and current == 0:
            # Brand-new DB — create_all gave us the latest schema. Most
            # migrations would be no-ops, but ``_003`` (email
            # COLLATE NOCASE) DOES need to run: ``create_all`` builds the
            # email index without the collation clause, and we want fresh
            # v1.3+ DBs to have the same case-insensitive uniqueness
            # guarantee as upgraded ones (#261 item 5). The migration is
            # idempotent (DROP INDEX IF EXISTS + CREATE UNIQUE INDEX),
            # so calling it here is safe. Other migrations stay skipped
            # to preserve the v1.3 orphan-column contract (_002).
            _run_fresh_db_post_create_steps(engine)
            _set_version(session, latest)
            return

        if current >= latest:
            return  # already up to date

        for idx in range(current, latest):
            migration = MIGRATIONS[idx]
            # New transaction per migration so a failure halfway down the
            # list still records what completed.
            with engine.begin() as conn:
                migration(conn)
            _set_version(session, idx + 1)


def _run_fresh_db_post_create_steps(engine: Engine) -> None:
    """Idempotent migrations that must apply even when ``create_all``
    just produced the latest schema.

    ``create_all`` honours SQLModel field declarations but cannot
    express SQLite's per-index ``COLLATE NOCASE`` clause without leaking
    a SQLite-only column collation into the model (which breaks the
    Postgres-compatible eject DDL — #165). So the COLLATE clause lives
    in migration _003, and we call it here so fresh DBs get the same
    case-insensitive uniqueness guarantee as upgraded ones.

    Other migrations (_001 revoked_at, _002 is_admin) are deliberately
    NOT invoked on fresh DBs: _001 is subsumed by ``create_all``, and
    _002 would add an orphan ``is_admin`` column to a fresh v1.3+ DB
    that the User model no longer maps (the orphan contract is "kept on
    upgrade, absent on fresh" — see #157 / migrations.__init__).
    """
    from parbaked.migrations._003_email_lowercase import up as _003

    with engine.begin() as conn:
        _003(conn)


# Re-export for tests + the parbaked admin migrate CLI.
LATEST_VERSION = _latest_version_const
