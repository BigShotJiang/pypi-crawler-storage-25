"""Migration 0004: add ``_parbaked_admin_signin_nonce`` (#205).

The admin sign-in magic-link from #130 was advertised as "one-shot"
in three docstrings and in the email body — but the implementation
only checked signature + audience + expiry, so the same URL was
replayable for the full 15-minute TTL (#205, supersedes the
documentation-only #180 patch).

The fix is a single-row table holding the current admin-signin nonce.
Every minted token embeds the row's current value as a ``nonce`` claim;
a successful verify rotates the value, which invalidates the just-used
token AND any other outstanding signin links. See
:class:`parbaked.auth.models.AdminSigninNonce` for the data model and
:func:`parbaked.auth.tokens.verify_admin_signin_token` for the
compare-and-swap.

Idempotent — CREATE IF NOT EXISTS + INSERT OR IGNORE so the same script
is safe against:

- a brand-new DB where ``create_all`` already planted the empty table
  (this migration just seeds the row).
- a v1.3 DB that booted before this migration shipped (this migration
  creates the table AND seeds the row).
- a DB that already ran this migration (both statements no-op).
"""

from __future__ import annotations

import secrets as _secrets

from sqlalchemy import text
from sqlalchemy.engine import Connection


def _fresh_nonce() -> str:
    """Cryptographically random nonce for the admin signin row.

    32 bytes of urlsafe base64 → ~43 chars of entropy. Plenty for a
    single-row table that rotates on every successful signin.
    """
    return _secrets.token_urlsafe(32)


def up(conn: Connection) -> None:
    # The table is created by ``SQLModel.metadata.create_all`` on a fresh
    # DB; the CREATE IF NOT EXISTS here is the explicit-step path for
    # upgrades that have an existing v1.3 DB without the new table.
    conn.execute(
        text(
            "CREATE TABLE IF NOT EXISTS _parbaked_admin_signin_nonce ("
            "id INTEGER PRIMARY KEY, "
            "nonce VARCHAR(64) NOT NULL"
            ")"
        )
    )
    # INSERT OR IGNORE: if a row already exists (because a prior boot
    # lazily seeded it via the runtime helper), don't clobber it — that
    # would silently invalidate every outstanding magic link the admin
    # might be holding.
    conn.execute(
        text(
            "INSERT OR IGNORE INTO _parbaked_admin_signin_nonce (id, nonce) "
            "VALUES (1, :nonce)"
        ),
        {"nonce": _fresh_nonce()},
    )
