"""Runtime configuration for parbaked.

Settings load in this precedence (highest wins):

1. Explicit kwargs to ``ParbakedConfig(...)`` / ``Parbaked(...)``
2. ``PARBAKED_*`` environment variables
3. ``.env`` file (via pydantic-settings)
4. ``parbaked.toml`` at the project root
5. Hard-coded field defaults

``parbaked.toml`` is the v0.9 single source of truth (#44). Env vars override
file values so secrets stay out of git in prod. Existing v0.7 projects with no
``parbaked.toml`` keep working — the loader is fully backwards-compatible.
"""

from __future__ import annotations

import logging
import re
import tomllib
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, EmailStr, Field, model_validator
from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
    TomlConfigSettingsSource,
)

logger = logging.getLogger("parbaked.config")

Environment = Literal["development", "production"]


class _StrictTomlConfigSettingsSource(TomlConfigSettingsSource):
    """TOML source that rejects unknown top-level keys (#191).

    The model itself stays ``extra="ignore"`` because env vars share the same
    namespace and operators routinely set ``PARBAKED_*`` env vars that aren't
    parbaked settings (fly.io sets its own ``PARBAKED_DEPLOY_*`` for example).
    Forbidding extras at the model level would refuse to boot on any of those.

    A TOML typo is different — the file IS parbaked's config, nothing else
    writes to it, so an unknown key is unambiguously a bug. We validate
    ``toml_data`` against the model's declared field names at source-
    construction time and raise loudly before pydantic ever sees the dict.
    """

    def __init__(self, settings_cls: type[BaseSettings]) -> None:
        super().__init__(settings_cls)
        self._reject_unknown_keys(settings_cls, self.toml_data)

    def _read_file(self, file_path: Path) -> dict[str, Any]:
        """Catch ``tomllib.TOMLDecodeError`` and re-raise as a clean
        ``ParbakedConfigError`` (#335).

        Mirrors the loud-fail pedagogy of the ``hooks.py`` / ``models.py``
        autoload paths (see ``_autoload_consumer_hooks`` /
        ``_autoload_consumer_models`` in :mod:`parbaked.runtime`): name
        the file, include the underlying error type, AND explain why the
        loud fail is what the operator wants. Without this, a single
        missing quote in ``parbaked.toml`` dumps a 30-line ``tomllib``
        traceback through four stdlib frames and the operator has to
        guess that the failure is in their config file, not a parbaked
        bug.

        ``PermissionError`` (rare — a file present in ``is_file()`` but
        unreadable by the parbaked process) flows through the same
        catch with the same friendly shape, so a root-owned config in a
        non-root container doesn't surface as a bare ``PermissionError``
        traceback either.
        """
        try:
            return super()._read_file(file_path)
        except tomllib.TOMLDecodeError as exc:
            from parbaked.exceptions import ParbakedConfigError

            raise ParbakedConfigError(
                f"Failed to parse parbaked.toml: {exc!r}. "
                "Fix the TOML syntax above — leaving it in place would "
                "let boot succeed with default config and silently miss "
                "your app_name, ratelimits, and [frontend] block."
            ) from exc
        except PermissionError as exc:
            from parbaked.exceptions import ParbakedConfigError

            raise ParbakedConfigError(
                f"Failed to read parbaked.toml at {file_path}: {exc!r}. "
                "Fix the file permissions above — leaving it unreadable "
                "would let boot succeed with default config and silently "
                "miss your app_name, ratelimits, and [frontend] block."
            ) from exc

    @staticmethod
    def _reject_unknown_keys(
        settings_cls: type[BaseSettings], data: dict[str, Any] | None
    ) -> None:
        if not data:
            return
        allowed = set(settings_cls.model_fields.keys())
        unknown = sorted(k for k in data if k not in allowed)
        if unknown:
            # Surface a hint about the closest valid key so typos like
            # ``app_nmae`` → ``app_name`` are one glance away from the fix.
            import difflib

            hints = []
            for key in unknown:
                close = difflib.get_close_matches(key, allowed, n=1, cutoff=0.6)
                if close:
                    hints.append(f"{key!r} (did you mean {close[0]!r}?)")
                else:
                    hints.append(repr(key))
            # ``ParbakedConfigError`` subclasses ``ValueError`` so the
            # existing ``except ValueError`` clauses in the CLI + MCP
            # server still catch it (#221). New callers should catch
            # the specific parbaked type.
            from parbaked.exceptions import ParbakedConfigError

            raise ParbakedConfigError(
                "parbaked.toml contains unknown key(s): "
                + ", ".join(hints)
                + ". Remove or rename — silently ignoring typos means a "
                "setting you thought you'd configured never takes effect."
            )


class FrontendConfig(BaseModel):
    """``[frontend]`` block in parbaked.toml (#115).

    Absence of the block = backend-only mode (today's behaviour, no
    changes). When present, the runtime mounts ``source_dir`` (or its
    ``dist_subpath`` if a build is configured) at ``/`` so the SPA
    ships from the same origin as the API. parbaked has no opinion on
    *what* lives in ``source_dir`` — Vite, Next, Astro, vanilla HTML.
    """

    source_dir: str = Field(
        default="web",
        description=(
            "Project-root-relative path holding the frontend. Defaults "
            "to ``web``. Mounted at ``/`` by the runtime after all auth + "
            "user routers, so HTML5 history routing falls back to "
            "index.html via ``StaticFiles(html=True)``."
        ),
    )
    build_command: str = Field(
        default="",
        description=(
            "Shell command run inside the build stage of the generated "
            "Dockerfile (e.g. ``npm ci && npm run build``). Empty (the "
            "default) → static-only: ``source_dir`` is served as-is from "
            "the runtime image, no Node build stage."
        ),
    )
    dist_subpath: str = Field(
        default="dist",
        description=(
            "Where the build output lands inside ``source_dir`` (e.g., "
            "Vite → ``dist``, Next static export → ``out``). Ignored when "
            "``build_command`` is empty."
        ),
    )
    build_image: str = Field(
        default="node:20-alpine",
        description=(
            "Base image for the build stage. Override for bun "
            "(``oven/bun:1``), pnpm, or a pinned Node version."
        ),
    )


class EmailSubjects(BaseModel):
    """Per-template subject-line overrides (#144).

    Each field maps to one of the ``render_*`` functions in
    :mod:`parbaked.email.templates`. ``None`` (the default) keeps the
    hard-coded subject built into the template; setting a string replaces
    it. The string supports ``str.format``-style placeholders:

    * ``{app_name}`` — always available.
    * ``{user_name}`` — where a ``User`` is in scope (every template
      except ``admin_signin`` exposes this).
    * ``{user_email}`` — only in ``admin_approval_request``.

    Unknown placeholders are left intact rather than crashing, so a typo
    like ``"Hi {weird}"`` renders verbatim instead of breaking the send.

    Unknown *field names* (e.g. ``verify = "..."`` instead of
    ``user_verify``) are rejected at config-load time rather than silently
    dropped (#203). The top-level :class:`ParbakedConfig` keeps
    ``extra="ignore"`` because the env-var namespace is shared with
    fly/Docker tooling, but this nested block has a fixed schema — an
    unknown key is unambiguously a typo.
    """

    model_config = ConfigDict(extra="forbid")

    user_verify: str | None = None
    user_approved: str | None = None
    user_rejected: str | None = None
    admin_approval_request: str | None = None
    password_reset: str | None = None
    admin_signin: str | None = None
    email_change_verify: str | None = None
    email_changed_notice: str | None = None

    # Known placeholder set per template (#212). Mirrors the
    # ``_subject_for`` call sites in :mod:`parbaked.email.templates` —
    # every renderer passes ``app_name`` plus zero or more per-template
    # placeholders. Keep this dict in sync if a new renderer grows a
    # placeholder, or the typo-warning will misfire.
    _KNOWN_PLACEHOLDERS: dict[str, frozenset[str]] = {
        "user_verify": frozenset({"app_name", "user_name"}),
        "admin_approval_request": frozenset(
            {"app_name", "user_name", "user_email"}
        ),
        "user_approved": frozenset({"app_name", "user_name"}),
        "user_rejected": frozenset({"app_name", "user_name"}),
        "password_reset": frozenset({"app_name", "user_name"}),
        "admin_signin": frozenset({"app_name"}),
        "email_change_verify": frozenset({"app_name", "user_name"}),
        "email_changed_notice": frozenset({"app_name", "user_name"}),
    }

    _PLACEHOLDER_RE = re.compile(r"\{([a-z_][a-z0-9_]*)\}")

    @model_validator(mode="after")
    def _warn_unknown_placeholders(self) -> EmailSubjects:
        """Warn at config-load when an override uses an unknown placeholder.

        ``_SafePlaceholders`` (in :mod:`parbaked.email.templates`)
        deliberately renders unknown ``{keys}`` verbatim so a typo
        doesn't blow up the entire email send — that's a forward-compat
        feature, not a bug. But it means a dev typo'ing ``{user_emial}``
        only finds out when their own verify email arrives with the
        literal placeholder in the subject.

        Catch it at boot instead: walk every user-supplied subject and
        log a WARNING if it references a placeholder that doesn't exist
        for that template. Don't raise — silent-fallback is the point.

        Also catches the case where a real placeholder is used in the
        wrong template (e.g. ``{user_email}`` is admin_approval_request-
        only; using it in ``user_verify`` will render verbatim).
        """
        for field_name, allowed in self._KNOWN_PLACEHOLDERS.items():
            value = getattr(self, field_name, None)
            if not value:
                continue
            used = set(self._PLACEHOLDER_RE.findall(value))
            unknown = used - allowed
            if unknown:
                logger.warning(
                    "email.subjects.%s references unknown placeholder(s) %s "
                    "— they'll render verbatim in the email subject. "
                    "Valid placeholders for this template: %s.",
                    field_name,
                    sorted(unknown),
                    sorted(allowed),
                )
        return self


class _EmailConfig(BaseModel):
    """``[email]`` block in parbaked.toml.

    Currently exposes only :class:`EmailSubjects` under ``[email.subjects]``;
    grows later for ``[email.bodies]`` once the body-templating story is
    nailed down (#144).
    """

    subjects: EmailSubjects = Field(default_factory=EmailSubjects)


class ParbakedConfig(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="PARBAKED_",
        env_file=".env",
        # Nested-block env-var support (#144). Delimiter is a single ``_`` so
        # ``PARBAKED_EMAIL_SUBJECTS_USER_VERIFY`` flows naturally through to
        # ``config.email.subjects.user_verify``. ``env_nested_max_split=2``
        # bounds the split to the two outer levels (``email`` → ``subjects``)
        # — without it, pydantic-settings would try every underscore split
        # and never land on a leaf field that itself contains underscores
        # (e.g. ``user_verify``). It also stops the parser from misreading
        # legacy flat keys like ``PARBAKED_JWT_SECRET`` as nested.
        env_nested_delimiter="_",
        env_nested_max_split=2,
        toml_file="parbaked.toml",
        extra="ignore",
        case_sensitive=False,
    )

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        # Tuple order is precedence — earlier wins.
        # Kwargs > env > .env > parbaked.toml > Docker secrets.
        return (
            init_settings,
            env_settings,
            dotenv_settings,
            _StrictTomlConfigSettingsSource(settings_cls),
            file_secret_settings,
        )

    # ---- Environment ----------------------------------------------------
    env: Environment = Field(
        default="development",
        description=(
            "Deployment environment. Defaults to ``development`` — auto-"
            "generates secrets, prints them in the banner, no extra guard"
            "rails. Set ``PARBAKED_ENV=production`` and parbaked refuses "
            "to start if any required secret was auto-generated (rather "
            "than provided via env), warns loudly if it detects more than "
            "one worker / instance, and suppresses the admin password in "
            "the banner."
        ),
    )

    # ---- Branding -------------------------------------------------------
    app_name: str = Field(default="My App", description="Used in email subjects and bodies")
    app_url: str = Field(
        default="http://localhost:8000",
        description="Public base URL — used to build approval magic links",
    )
    login_path: str = Field(
        default="/",
        description=(
            "Path on your app where users sign in. Used in welcome emails so "
            "the 'sign in here' link points at YOUR login page (an HTML form), "
            "not parbaked's POST-only /auth/login API endpoint. Defaults to "
            "/, which matches the parbaked starter template — the starter "
            "serves an HTML page with login + signup forms at the root mount. "
            "Override to /login (or wherever) if your app has a dedicated "
            "login page. Closes #166."
        ),
    )

    # ---- Auth secrets ---------------------------------------------------
    jwt_secret: str = Field(
        default="",
        description=(
            "HMAC secret for JWT signing. MUST be set in production. "
            "If empty, a random key is generated at startup (sessions reset on restart)."
        ),
    )
    jwt_expiry_days: int = Field(default=7)

    approval_token_secret: str = Field(
        default="",
        description=(
            "HMAC secret for admin approval magic links. Falls back to "
            "``jwt_secret`` if unset, but a separate secret is recommended."
        ),
    )
    approval_token_expiry_hours: int = Field(
        default=72,
        description=(
            "Shared TTL for two distinct magic links: the admin "
            "approve/reject email (``create_approval_token``) AND the "
            "user-facing email-verification link (``create_verify_token``). "
            "The name predates the verify flow; both audiences live on the "
            "same knob today because their threat models are near-identical "
            "(intercepted-inbox replay over a bounded window). If you ever "
            "need different TTLs for the two, split this into "
            "``verify_token_expiry_hours`` + a renamed approval field — "
            "``password_reset_expiry_hours`` is the precedent."
        ),
    )
    password_reset_expiry_hours: int = Field(
        default=1,
        description=(
            "How long a password-reset magic link is valid. Short by design — "
            "reset emails are the highest-value phishing target. One hour is "
            "long enough for a real user to switch devices and finish the flow."
        ),
    )

    @property
    def email_enabled(self) -> bool:
        """Dashboard-only mode detector (#74).

        parbaked operates in no-email mode when neither ``resend_key``
        nor ``admin_email`` is configured. In that mode the signup
        flow skips email verification entirely (admin's manual triage
        is the bot filter), forgot-password returns 202 with a
        "contact your admin" body, and the boot banner reads
        ``Email: disabled (dashboard-only)``.

        Setting either flips parbaked back into the full email path.
        """
        return bool(self.resend_key) or bool(self.admin_email)

    # ---- Admin ----------------------------------------------------------
    admin_email: EmailStr | None = Field(
        default=None,
        description="Where signup-approval emails are sent. Required for the approval flow.",
    )

    # ---- Email transport -----------------------------------------------
    # parbaked has one prod email path: Resend. If `resend_key` is set,
    # ResendEmail is used. Otherwise ConsoleEmail (prints to stdout) is used.
    # For anything else, pass your own EmailTransport into Parbaked(email=...).

    resend_key: str = Field(
        default="",
        description=(
            "Resend API key (re_xxx). Env var: PARBAKED_RESEND_KEY. Get one free "
            "at https://resend.com/api-keys or run `parbaked email setup`. When "
            "set, parbaked sends real email via Resend."
        ),
    )
    mail_from: str = Field(
        default="",
        description=(
            "From address for outbound emails. Defaults to onboarding@resend.dev "
            "(Resend's sandbox sender — works with no DNS setup). For your own "
            "domain, verify it at resend.com/domains and set this to hello@yourdomain.com."
        ),
    )

    # ---- Migrations -----------------------------------------------------
    auto_migrate: bool = Field(
        default=True,
        description=(
            "When True (the default), parbaked runs pending schema "
            "migrations against its own DB on every boot, before serving "
            "the first request. Failed migrations refuse to boot. Set to "
            "False to gate migrations behind ``parbaked admin migrate`` "
            "instead — useful when you want migration changes to be a "
            "deliberate, separate deploy step. Env var: "
            "``PARBAKED_AUTO_MIGRATE``."
        ),
    )

    # ---- Database -------------------------------------------------------
    database_url: str = Field(
        default="sqlite:///./parbaked.db",
        description=(
            "Where parbaked's own tables live (#47). Separate from any DB "
            "the user's app code uses — parbaked stops mixing its schema "
            "into the consumer's models. SQLite is the only supported "
            "engine; technically other SQLAlchemy URLs work but they are "
            "unsupported (no docs, no test matrix). TOML key: "
            "``database_url`` (the file is already called parbaked.toml so "
            "no prefix needed). Env var: ``PARBAKED_DATABASE_URL``."
        ),
    )

    # ---- Routes ---------------------------------------------------------
    routes_dir: str = Field(
        default="routes",
        description=(
            "Directory walked by ``parbaked.runtime.create_app()`` for "
            "convention-based route discovery (#45). Every ``.py`` file "
            "with a module-level ``router: APIRouter`` is mounted; file "
            "path becomes URL prefix (``routes/api/users.py`` → "
            "``/api/users``, ``routes/index.py`` → ``/``). Relative paths "
            "resolve from the current working directory. Env var: "
            "``PARBAKED_ROUTES_DIR``."
        ),
    )

    # ---- Logging --------------------------------------------------------
    log_format: str = Field(
        default="",
        description=(
            "Audit-log format. ``json`` emits one JSON object per line, ready "
            "for shipping to CloudWatch / Datadog / Logflare / fly.io's log "
            "shipper. ``text`` prints human-readable lines for dev terminals. "
            "When unset (the default), parbaked picks the right value for "
            "the environment: ``json`` in production (operators almost "
            "always have a log shipper expecting structured input), ``text`` "
            "in development. Set explicitly to override. Env var: "
            "``PARBAKED_LOG_FORMAT``."
        ),
    )

    # ---- Networking / proxy ---------------------------------------------
    trust_proxy_headers: bool = Field(
        default=False,
        description=(
            "When True, parbaked uses the leftmost entry of "
            "``X-Forwarded-For`` as the client IP in audit logs AND as the "
            "rate-limiter bucket key. Defaults to False — safe-by-default "
            "for apps exposed directly to the public internet, where "
            "clients can otherwise spoof that header to poison audit logs "
            "and bypass per-IP rate limits. ``parbaked deploy`` flips this "
            "on automatically in the generated ``fly.toml`` (fly's edge "
            "strips inbound XFF), and ``parbaked tunnel`` flips it on for "
            "the cloudflared session. Set explicitly to True when you've "
            "put your own proxy (Cloudflare, nginx, etc.) in front that "
            "strips inbound XFF before forwarding."
        ),
    )

    # ---- fly.io deploy --------------------------------------------------
    # Used by ``parbaked deploy`` (#48) when generating fly.toml. Only
    # consulted when no hand-written ``fly.toml`` exists at project root.

    fly_region: str = Field(
        default="lhr",
        description=(
            "fly.io primary region for generated ``fly.toml`` (e.g., "
            "``lhr``, ``ord``, ``syd``). Only consulted when ``parbaked "
            "deploy`` generates fly.toml — ignored if you have one at "
            "project root. Env var: ``PARBAKED_FLY_REGION``."
        ),
    )
    fly_max_machines: int = Field(
        default=2,
        description=(
            "Cost cap: ``max_machines_running`` in generated fly.toml. "
            "Default 2 — enough to ride out a traffic spike, not enough "
            "to autoscale your way to a bill. Bump deliberately."
        ),
    )
    fly_memory: str = Field(
        default="256mb",
        description=(
            "VM memory size in generated fly.toml (e.g., ``256mb``, "
            "``512mb``, ``1gb``). Cheapest fly tier is 256mb — bump only "
            "if you actually need it."
        ),
    )

    # ---- Email subjects (optional) -------------------------------------
    email: _EmailConfig = Field(
        default_factory=_EmailConfig,
        description=(
            "``[email]`` block in parbaked.toml (#144). Currently houses "
            "``[email.subjects]`` for 1-line subject-line overrides per "
            "template — see :class:`EmailSubjects`. Heavier-weight "
            "reskinning of bodies still goes through "
            ":class:`parbaked.email.templates.Templates`."
        ),
    )

    # ---- Frontend (optional) -------------------------------------------
    frontend: FrontendConfig | None = Field(
        default=None,
        description=(
            "Optional ``[frontend]`` block in parbaked.toml (#115). When "
            "present, the deploy generator emits a multi-stage Dockerfile "
            "(if ``build_command`` is set) and the runtime mounts the "
            "frontend at ``/``. Absent = backend-only mode (no behaviour "
            "change). See :class:`FrontendConfig` for the field shape."
        ),
    )

    # ---- Rate limiting --------------------------------------------------
    ratelimit_signup: str = Field(default="5/minute", description="Per-IP limit on /auth/signup")
    ratelimit_login: str = Field(default="10/minute", description="Per-IP limit on /auth/login")
    ratelimit_password_reset: str = Field(
        default="3/minute",
        description=(
            "Per-IP limit on /auth/forgot-password. Tight by default — the "
            "endpoint sends real email + always returns 202, so it's a free "
            "email-flood weapon if left unlimited."
        ),
    )
    ratelimit_admin_login: str = Field(
        default="5/minute",
        description=(
            "Per-IP limit on POST /auth/admin/login. Without this the "
            "endpoint sits under the global cap (100/minute) — wide "
            "enough to brute-force a short admin password before any "
            "human notices (#167). Mirrors ``ratelimit_login`` by "
            "default; tighten further if you operate from a small set "
            "of admin IPs."
        ),
    )
    ratelimit_global: str = Field(
        default="100/minute",
        description="Default per-IP limit applied to all parbaked routes",
    )

    # ---- Body size limit ------------------------------------------------
    max_body_kb: int = Field(
        default=8,
        ge=1,
        description=(
            "Cap on the declared Content-Length for POST/PUT/PATCH "
            "requests, in kilobytes (#167, #261). 8KB is comfortable for "
            "parbaked's own auth payloads (longest legit body is ~1KB). "
            "Bump this if your consumer routes accept larger user "
            "content (image uploads, long markdown bodies, CSV imports) "
            "— for image-size uploads, prefer scoping the middleware "
            "off those routes or using a presigned-URL pattern, since "
            "8KB → many MB is a much wider DoS surface."
        ),
    )

    def effective_approval_secret(self) -> str:
        """Return the secret used to sign approval tokens (fallback chain)."""
        return self.approval_token_secret or self.jwt_secret

    def effective_log_format(self) -> str:
        """Resolve ``log_format`` against the env when no explicit value.

        Production deploys almost always sit behind a log shipper that
        expects structured input — defaulting to ``json`` there saves the
        operator the "why aren't my logs parsing?" round-trip. Dev keeps
        ``text`` because that's what humans want to read in a terminal.
        """
        if self.log_format:
            return self.log_format
        return "json" if self.env == "production" else "text"

    def effective_mail_from(self) -> str:
        """From address — falls back to Resend's sandbox if unset."""
        return self.mail_from or "onboarding@resend.dev"

    def effective_mail_from_header(self) -> str:
        """Full ``From:`` header value — ``"App Name <addr@example.com>"`` (#224).

        Including the display name keeps inboxes from flagging the mail as
        spam ("from no-name@onboarding.resend.dev"). The app_name comes from
        config and is rendered verbatim — operators picking a name with weird
        characters (commas, angle brackets) will produce a malformed header,
        but that's a config-time problem, not a runtime one.
        """
        return f"{self.app_name} <{self.effective_mail_from()}>"
