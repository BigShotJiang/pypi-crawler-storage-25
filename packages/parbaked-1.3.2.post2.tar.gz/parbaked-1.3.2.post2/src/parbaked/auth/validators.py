"""Shared input validators + sanitizing validation-error handler (#414, #430).

A JSON body containing a lone Unicode surrogate (e.g. ``"\\ud800"``)
or a non-finite float (``NaN``, ``Infinity``, ``-Infinity``) used to
crash any auth route with HTTP 500 instead of the usual 422. Both have
the same shape: Python's ``json.loads`` happily accepts the malformed
value (the JSON parser is lenient about surrogates AND has
``allow_nan=True`` by default), pydantic then echoes the offending
input back inside :class:`pydantic.ValidationError`'s ``errors()``
payload, FastAPI's default ``request_validation_exception_handler``
hands that to :func:`fastapi.encoders.jsonable_encoder`, and Starlette's
:class:`JSONResponse.render` finally tries to JSON-encode + UTF-8-encode
the result — which can't represent either class of value:

* Lone surrogates (D800-DFFF) have no valid UTF-8 byte sequence:
  ``.encode("utf-8")`` raises ``UnicodeEncodeError: surrogates not
  allowed``.
* Non-finite floats: Starlette's :class:`JSONResponse` calls
  ``json.dumps(..., allow_nan=False)``, which raises ``ValueError: Out
  of range float values are not JSON compliant`` on ``NaN``/``inf``.

Either path results in an unhandled exception mid-response: HTTP 500 +
traceback in stderr.

Public-API impact: any unauthenticated client could trip the 500 + log
spam by POSTing ``$'{"email":"a@b.com","password":"Pw12345!","name":"\\xed\\xa0\\x80"}'``
or ``'{"name": NaN, "email":"a@b.com", "password":"Pw12345!"}'`` to
``/auth/signup`` (and ditto for every other auth endpoint with a
JSON body). Low-cost log-pollution DoS; violates parbaked's contract
that malformed bodies always 422.

Two-layer fix:

1. :func:`reject_lone_surrogates` — a ``mode="before"`` field validator
   used on user-controlled string fields on the auth request models.
   Catches surrogate-bearing values up front with a clear error message
   before any downstream str-to-bytes encoder runs (audit-log writer,
   email-template renderer, JSON response builder).

2. :func:`install_validation_error_handler` — a sanitizing
   :class:`fastapi.exceptions.RequestValidationError` handler that
   scrubs from the echoed ``input`` value the two classes of values
   :class:`JSONResponse` can't render: lone surrogates (replaced with
   U+FFFD) and non-finite floats (replaced with ``None``). The field
   validator is the right answer when the bad value is in a known
   string field; the sanitizing handler is the belt-and-braces that
   catches any other shape (e.g. pydantic's own internal validators
   echoing back, or future numeric / non-str-typed bodies a contributor
   forgets to gate). Same 422-with-clean-detail response shape every
   other malformed body gets.
"""

from __future__ import annotations

import math
from typing import Any

from fastapi import FastAPI, Request
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse


def reject_lone_surrogates(v: Any) -> Any:
    """``mode="before"`` field validator that rejects lone-surrogate strings.

    Returns ``v`` unchanged for non-str inputs (pydantic will then run
    its usual type coercion / refusal) and for valid UTF-8-encodable
    strings. Raises ``ValueError`` — pydantic's documented protocol for
    "this value is bad" — for strings that contain at least one lone
    surrogate code point (U+D800-U+DFFF without a matching pair), because
    those can't be ``.encode("utf-8")``'d and would later blow up in any
    of: the welcome-email template renderer, the audit-log JSON writer,
    or the JSON response builder for the eventual error path.

    Apply via ``@field_validator(..., mode="before")`` on auth request
    models — see :class:`parbaked.auth.router.SignupRequest`,
    :class:`LoginRequest`, :class:`ChangeEmailRequest`,
    :class:`ForgotPasswordRequest`.
    """
    if not isinstance(v, str):
        return v
    try:
        v.encode("utf-8")
    except UnicodeEncodeError as exc:
        # Be specific about *what* is wrong without echoing the bad
        # input back in the ValueError message — the same encoding
        # problem would re-trip on the way out otherwise.
        raise ValueError(
            "contains characters that cannot be encoded as UTF-8 "
            "(lone surrogate)"
        ) from exc
    return v


def _scrub_for_json(obj: Any) -> Any:
    """Recursively scrub a JSON-able tree of values the stdlib encoder rejects.

    Walks dicts / lists / tuples / strings / floats; anything else is
    returned verbatim. Used to sanitize the ``exc.errors()`` payload
    before :class:`JSONResponse` tries to render it.

    Two classes of values are substituted (each documented at the call
    site):

    * **Lone surrogates in strings** (#414) → U+FFFD. Starlette's
      ``JSONResponse.render`` calls ``.encode("utf-8")`` on the dumped
      string, which can't represent a lone surrogate (no valid UTF-8
      byte sequence encodes a code point in D800-DFFF). U+FFFD is the
      Unicode replacement character — operators eyeballing the 422
      response see a visible "something's wrong here" glyph instead of
      ``\\ud800``. ``encode("utf-8", "replace")`` substitutes with ``?``
      (U+003F), not U+FFFD as docs reserve the latter for the DECODE
      direction (Devin caught this — #414 review). Walk the string
      explicitly so the observable substitute matches the documented
      glyph (``"\\ufffd"`` / ``"�"``).
    * **Non-finite floats** (#430) → ``None``. Starlette's
      ``JSONResponse`` calls ``json.dumps(..., allow_nan=False)``, which
      raises ``ValueError`` on ``NaN``/``+inf``/``-inf``. We substitute
      ``None`` rather than a string repr (``"NaN"``) so the response
      stays type-honest — pydantic's error ``msg`` already names the
      offending field, and the field having been a non-representable
      numeric is what ``input: null`` conveys. Same precedent as how
      missing fields look in 422 payloads.

    Pydantic's error ``msg`` already names the problem so the user-
    facing message stays clear without us quoting the raw bad value.
    """
    if isinstance(obj, str):
        # Fast-path: if the string encodes cleanly, no work to do. Pay
        # the per-character substitute cost only on bad input.
        try:
            obj.encode("utf-8")
        except UnicodeEncodeError:
            return "".join(
                "�" if "\ud800" <= ch <= "\udfff" else ch
                for ch in obj
            )
        return obj
    if isinstance(obj, bool):
        # ``bool`` is a subclass of ``int`` in Python; without this
        # early exit a future change to the float branch (e.g. coercing
        # to ``float`` for the isfinite check) could accidentally
        # rewrite booleans. Return verbatim.
        return obj
    if isinstance(obj, float) and not math.isfinite(obj):
        return None
    if isinstance(obj, dict):
        return {_scrub_for_json(k): _scrub_for_json(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_scrub_for_json(x) for x in obj]
    return obj


async def _validation_error_handler(
    request: Request,  # noqa: ARG001 — FastAPI handler signature
    exc: Exception,
) -> JSONResponse:
    """Sanitizing replacement for FastAPI's default
    ``request_validation_exception_handler`` (#414, #430).

    Same 422 + ``{"detail": [...]}`` response shape FastAPI's stock
    handler produces — we only walk the ``errors()`` payload through
    :func:`_scrub_for_json` first so any echoed-back lone surrogate or
    non-finite float can't trip :class:`JSONResponse.render`'s
    ``json.dumps(..., allow_nan=False)`` /
    ``.encode("utf-8")`` pipeline. Fast-path: clean payloads are
    returned byte-identically to the default handler.
    """
    # ``exc`` is typed Exception so the registered handler signature
    # matches FastAPI's contract; in practice this is always a
    # RequestValidationError because that's what we register against.
    assert isinstance(exc, RequestValidationError)
    errors = jsonable_encoder(exc.errors())
    sanitized = _scrub_for_json(errors)
    return JSONResponse(
        status_code=422,
        content={"detail": sanitized},
    )


def install_validation_error_handler(app: FastAPI) -> None:
    """Register the sanitizing :class:`RequestValidationError` handler on ``app``.

    Idempotent for the common "called once per app" use case; calling it
    twice on the same app just re-binds the handler to the same callable.
    Safe to install before or after routers are mounted — exception
    handlers are looked up at request-handling time.

    Both :class:`parbaked.app.Parbaked` (the production install path)
    and the test ``app`` fixture wire this. Consumers building a
    FastAPI app directly without going through ``create_app`` /
    ``Parbaked`` can call this themselves to get the same defence —
    though they would normally just use ``create_app``.
    """
    app.add_exception_handler(RequestValidationError, _validation_error_handler)
