"""HMAC-signed magic links.

Six audiences:

- ``parbaked-approval`` — admin clicks approve/reject from the signup email
- ``parbaked-verify`` — user clicks the link confirming they own the address
- ``parbaked-admin-session`` — cookie issued by the admin login form
- ``parbaked-password-reset`` — user clicks the reset link from forgot-password
- ``parbaked-admin-signin`` — admin clicks the sign-in magic link sent to the
  configured ``admin_email`` in email mode (#130)
- ``parbaked-email-change`` — user clicks the verify link sent to the NEW
  address when requesting an email change via POST /auth/me/email (#275, GDPR
  Article 16). Replay-defended by ``user.email`` mutation: completing the
  change moves the user onto ``new_email``, so a second click of the same
  token fails the stored-state check in the service layer.

Audience-scoping means a session JWT can never be replayed as a magic link, an
approval link can never verify an email, and so on.
"""

from __future__ import annotations

import secrets as _secrets
from datetime import UTC, datetime, timedelta
from typing import Literal
from uuid import UUID, uuid4

import jwt
from sqlalchemy import text
from sqlmodel import Session

from parbaked.config import ParbakedConfig

ApprovalAction = Literal["approve", "reject"]
_AUDIENCE = "parbaked-approval"
_VERIFY_AUDIENCE = "parbaked-verify"
_ADMIN_SESSION_AUDIENCE = "parbaked-admin-session"
_PASSWORD_RESET_AUDIENCE = "parbaked-password-reset"
_ADMIN_SIGNIN_AUDIENCE = "parbaked-admin-signin"
_EMAIL_CHANGE_AUDIENCE = "parbaked-email-change"

# Admin sign-in magic links are short-lived by design — the admin clicks
# through within a few minutes, and the shorter the TTL the smaller the
# window for a stolen-inbox replay attack. 15 minutes matches the GitHub
# / Vercel / Fly sign-in-link convention.
_ADMIN_SIGNIN_TTL_MINUTES = 15


class InvalidApprovalToken(Exception):
    """Raised when an approval magic link is forged, malformed, or expired."""


class InvalidVerifyToken(Exception):
    """Raised when an email-verification link is forged, malformed, or expired."""


class InvalidAdminSession(Exception):
    """Raised when the admin session cookie is forged, malformed, or expired."""


class InvalidPasswordResetToken(Exception):
    """Raised when a password-reset link is forged, expired, or already-used.

    "Already-used" applies because each token is bound to the user's current
    ``password_hash`` — once the password changes, every outstanding reset
    link for that account fails validation. (Same defence Django uses.)
    """


class InvalidAdminSigninToken(Exception):
    """Raised when an admin sign-in magic link is forged, malformed, or expired.

    Admin sign-in tokens are emitted by ``POST /auth/admin/login`` in email
    mode (#130). The admin clicks the link from their inbox; the GET route
    verifies the token, sets the admin session cookie, and redirects to
    the dashboard.
    """


class InvalidEmailChangeToken(Exception):
    """Raised when an email-change verify link is forged, expired, or already-used.

    Tokens are bound to ``_hash_fingerprint(password_hash)`` so a password reset
    after the change request was minted invalidates the outstanding link — same
    one-shot defence the password-reset flow uses. The "already-used" case is
    enforced at the service layer (`complete_email_change`) by checking the
    user's stored email against the token's ``new_email`` claim (#275).
    """


def create_approval_token(user_id: UUID, action: ApprovalAction, config: ParbakedConfig) -> str:
    secret = config.effective_approval_secret()
    if not secret:
        raise RuntimeError(
            "Cannot sign approval token: set PARBAKED_APPROVAL_TOKEN_SECRET "
            "(or PARBAKED_JWT_SECRET as a fallback)."
        )
    payload = {
        "sub": str(user_id),
        "action": action,
        "aud": _AUDIENCE,
        "iat": datetime.now(UTC),
        "exp": datetime.now(UTC)
        + timedelta(hours=config.approval_token_expiry_hours),
    }
    return jwt.encode(payload, secret, algorithm="HS256")


def verify_approval_token(token: str, config: ParbakedConfig) -> tuple[UUID, ApprovalAction]:
    secret = config.effective_approval_secret()
    try:
        payload = jwt.decode(
            token, secret, algorithms=["HS256"], audience=_AUDIENCE
        )
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError) as exc:
        raise InvalidApprovalToken(str(exc)) from exc

    action = payload.get("action")
    if action not in ("approve", "reject"):
        raise InvalidApprovalToken(f"Unknown approval action: {action!r}")

    try:
        user_id = UUID(payload["sub"])
    except (KeyError, ValueError) as exc:
        raise InvalidApprovalToken("Missing or malformed subject") from exc

    return user_id, action  # type: ignore[return-value]


def create_verify_token(user_id: UUID, config: ParbakedConfig) -> str:
    """Mint a magic link the user clicks to prove they own the email."""
    secret = config.effective_approval_secret()
    if not secret:
        raise RuntimeError(
            "Cannot sign verify token: set PARBAKED_APPROVAL_TOKEN_SECRET "
            "(or PARBAKED_JWT_SECRET as a fallback)."
        )
    payload = {
        "sub": str(user_id),
        "aud": _VERIFY_AUDIENCE,
        "iat": datetime.now(UTC),
        "exp": datetime.now(UTC)
        + timedelta(hours=config.approval_token_expiry_hours),
    }
    return jwt.encode(payload, secret, algorithm="HS256")


def verify_verify_token(token: str, config: ParbakedConfig) -> UUID:
    """Validate a verification link, returning the user_id it's for."""
    secret = config.effective_approval_secret()
    try:
        payload = jwt.decode(
            token, secret, algorithms=["HS256"], audience=_VERIFY_AUDIENCE
        )
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError) as exc:
        raise InvalidVerifyToken(str(exc)) from exc
    try:
        return UUID(payload["sub"])
    except (KeyError, ValueError) as exc:
        raise InvalidVerifyToken("Missing or malformed subject") from exc


def create_admin_session_token(config: ParbakedConfig, *, ttl_hours: int) -> str:
    """Mint a signed cookie value for an authenticated admin session.

    Audience-scoped so it can never be replayed as a verify or approval link.

    Each token carries a random ``jti`` claim so :func:`POST /auth/admin/logout`
    can revoke it server-side (see :mod:`parbaked.admin`). Without ``jti``,
    a captured cookie would remain replayable until ``exp``.

    ``ttl_hours`` is required (no default): the admin router owns the
    canonical value (``_COOKIE_TTL_HOURS`` in :mod:`parbaked.admin`) so
    the cookie's ``max_age`` and the JWT's ``exp`` can never drift apart
    by being changed in one place and not the other.
    """
    secret = config.effective_approval_secret()
    if not secret:
        raise RuntimeError(
            "Cannot sign admin session: set PARBAKED_APPROVAL_TOKEN_SECRET "
            "(or PARBAKED_JWT_SECRET as a fallback)."
        )
    payload = {
        "sub": "admin",
        "aud": _ADMIN_SESSION_AUDIENCE,
        "jti": str(uuid4()),
        "iat": datetime.now(UTC),
        "exp": datetime.now(UTC) + timedelta(hours=ttl_hours),
    }
    return jwt.encode(payload, secret, algorithm="HS256")


def verify_admin_session_token(token: str, config: ParbakedConfig) -> dict:
    """Validate a cookie value. Raises InvalidAdminSession if not OK.

    Returns the decoded payload on success so the caller can inspect the
    ``jti`` (for the in-memory revocation set #200) and ``exp`` (for
    TTL-bounded cleanup of that set).
    """
    secret = config.effective_approval_secret()
    try:
        return jwt.decode(
            token, secret, algorithms=["HS256"], audience=_ADMIN_SESSION_AUDIENCE
        )
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError) as exc:
        raise InvalidAdminSession(str(exc)) from exc


def _fresh_admin_signin_nonce() -> str:
    """Cryptographically random nonce for the admin signin row (#205).

    32 bytes of urlsafe base64 → ~43 chars of entropy. Plenty for a
    single-row table that rotates on every successful signin.
    """
    return _secrets.token_urlsafe(32)


def _load_or_seed_admin_signin_nonce(session: Session) -> str:
    """Return the current admin-signin nonce, seeding the row if missing (#205).

    The runtime path that mints magic links can run before the migration
    that plants the row has had a chance to run on this DB: fresh DBs
    skip migrations entirely (``SQLModel.metadata.create_all`` makes an
    empty table and the runner stamps the version to LATEST), so the
    first ``create_admin_signin_token`` call has to do its own seeding.

    Idempotent: if a row already exists this just returns its nonce.
    The seed write uses ``INSERT OR IGNORE`` so two concurrent first-time
    callers can't both insert; the loser reads the winner's value on the
    follow-up SELECT.
    """
    row = session.exec(
        text("SELECT nonce FROM _parbaked_admin_signin_nonce WHERE id = 1")
    ).first()
    if row is not None:
        return row[0]

    seeded = _fresh_admin_signin_nonce()
    session.exec(
        text(
            "INSERT OR IGNORE INTO _parbaked_admin_signin_nonce (id, nonce) "
            "VALUES (1, :nonce)"
        ).bindparams(nonce=seeded)
    )
    session.commit()
    row = session.exec(
        text("SELECT nonce FROM _parbaked_admin_signin_nonce WHERE id = 1")
    ).first()
    # The row must exist now — either we won the insert, or a concurrent
    # caller did. If it's still missing the DB is in a state we can't
    # reason about; surface a clear error rather than silently minting a
    # token that won't verify.
    if row is None:
        raise RuntimeError(
            "Failed to seed _parbaked_admin_signin_nonce — "
            "run `parbaked admin migrate` and retry."
        )
    return row[0]


def create_admin_signin_token(
    config: ParbakedConfig,
    session: Session,
    *,
    ttl_minutes: int = _ADMIN_SIGNIN_TTL_MINUTES,
) -> str:
    """Mint a one-shot admin sign-in magic link (#130, #205).

    Sent to ``config.admin_email`` in email mode after the operator submits
    their address on the admin login form. Clicking the link verifies the
    token, sets the admin session cookie, and redirects to the dashboard.
    Short TTL on purpose — see module docstring.

    The token carries the current per-admin nonce from
    :class:`parbaked.auth.models.AdminSigninNonce` as a ``nonce`` claim.
    :func:`verify_admin_signin_token` rotates that nonce on success, so
    any second use of this token (or any peer token minted off the same
    prior nonce) fails the rotation check (#205). Without the nonce, the
    token was replayable for the full 15-minute TTL — see issue.

    The token has no ``sub`` claim because there's only one admin in
    parbaked. Audience + nonce gate use: anyone reading the admin inbox
    who clicks the link within the TTL becomes admin — but only once.

    ``session`` must be live (not closed). Same DB the running app uses;
    CLI callers obtain it via :func:`parbaked.cli._db.open_engine` + a
    :class:`sqlmodel.Session`.
    """
    secret = config.effective_approval_secret()
    if not secret:
        raise RuntimeError(
            "Cannot sign admin signin token: set PARBAKED_APPROVAL_TOKEN_SECRET "
            "(or PARBAKED_JWT_SECRET as a fallback)."
        )
    nonce = _load_or_seed_admin_signin_nonce(session)
    payload = {
        "sub": "admin",
        "aud": _ADMIN_SIGNIN_AUDIENCE,
        "nonce": nonce,
        "iat": datetime.now(UTC),
        "exp": datetime.now(UTC) + timedelta(minutes=ttl_minutes),
    }
    return jwt.encode(payload, secret, algorithm="HS256")


def verify_admin_signin_token(
    token: str, config: ParbakedConfig, session: Session
) -> None:
    """Validate an admin sign-in magic link, burning the one-shot nonce (#205).

    Raises :class:`InvalidAdminSigninToken` if the signature is bad, the
    token is expired, it doesn't carry the admin-signin audience, or its
    embedded ``nonce`` claim no longer matches the row in
    ``_parbaked_admin_signin_nonce`` — i.e. the token (or a peer minted
    off the same prior nonce) has already been verified once.

    On success returns ``None`` after rotating the nonce — the caller
    mints the session cookie. The rotation is implemented as a single
    conditional UPDATE (``WHERE nonce = :expected``); SQLite executes
    each statement atomically, so two concurrent verifies of the same
    token can't both succeed: the loser sees ``rowcount == 0`` and
    raises. That's the compare-and-swap that makes one-shot real.
    """
    secret = config.effective_approval_secret()
    try:
        payload = jwt.decode(
            token, secret, algorithms=["HS256"], audience=_ADMIN_SIGNIN_AUDIENCE
        )
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError) as exc:
        raise InvalidAdminSigninToken(str(exc)) from exc

    claimed = payload.get("nonce")
    if not isinstance(claimed, str) or not claimed:
        # Pre-#205 tokens (or anything we minted that somehow lost the
        # claim) shouldn't be honoured: the absence of the claim means
        # we can't prove one-shot, which is the entire point of the
        # verify path. Same defence the password-reset link applies
        # when the ``fp`` claim is missing.
        raise InvalidAdminSigninToken("Token is missing the one-shot nonce claim.")

    new_nonce = _fresh_admin_signin_nonce()
    # Atomic compare-and-swap. SQLite runs each statement in an implicit
    # transaction with the right serialised-writer semantics, so the
    # second concurrent verify either sees the old nonce (and wins,
    # rotating it — but then the first verify sees a mismatch and
    # raises) or sees the new nonce (and raises immediately). Either
    # way exactly one verify succeeds. Don't replace this with a
    # SELECT-then-UPDATE without thinking through the race window.
    result = session.exec(
        text(
            "UPDATE _parbaked_admin_signin_nonce "
            "SET nonce = :new "
            "WHERE id = 1 AND nonce = :expected"
        ).bindparams(new=new_nonce, expected=claimed)
    )
    session.commit()
    if result.rowcount != 1:
        raise InvalidAdminSigninToken(
            "Token already used or superseded by a newer sign-in request."
        )


def _hash_fingerprint(password_hash: str) -> str:
    """Stable, opaque marker for the user's current credential.

    Embedded in reset tokens so any successful reset invalidates every other
    outstanding reset link. The first 16 chars of a bcrypt hash include the
    salt — different per user, regenerated on each change — so this is
    enough entropy without leaking the full hash into the token claims.
    """
    return password_hash[:16]


def create_password_reset_token(
    user_id: UUID, password_hash: str, config: ParbakedConfig
) -> str:
    """Mint a one-shot reset link for the user.

    Binding the token to ``_hash_fingerprint(password_hash)`` means the link
    can only be used while the password hasn't changed — a successful reset
    rotates the hash and invalidates every outstanding reset email.
    """
    secret = config.effective_approval_secret()
    if not secret:
        raise RuntimeError(
            "Cannot sign password-reset token: set PARBAKED_APPROVAL_TOKEN_SECRET "
            "(or PARBAKED_JWT_SECRET as a fallback)."
        )
    payload = {
        "sub": str(user_id),
        "aud": _PASSWORD_RESET_AUDIENCE,
        "fp": _hash_fingerprint(password_hash),
        "iat": datetime.now(UTC),
        "exp": datetime.now(UTC)
        + timedelta(hours=config.password_reset_expiry_hours),
    }
    return jwt.encode(payload, secret, algorithm="HS256")


def verify_password_reset_token(
    token: str, password_hash: str, config: ParbakedConfig
) -> UUID:
    """Validate a reset link against the user's *current* password_hash.

    Raises :class:`InvalidPasswordResetToken` if the signature is bad, the
    token is expired, or the user's password has rotated since it was minted.
    """
    secret = config.effective_approval_secret()
    try:
        payload = jwt.decode(
            token, secret, algorithms=["HS256"], audience=_PASSWORD_RESET_AUDIENCE
        )
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError) as exc:
        raise InvalidPasswordResetToken(str(exc)) from exc
    if payload.get("fp") != _hash_fingerprint(password_hash):
        raise InvalidPasswordResetToken("Token already used or password changed.")
    try:
        return UUID(payload["sub"])
    except (KeyError, ValueError) as exc:
        raise InvalidPasswordResetToken("Missing or malformed subject") from exc


def create_email_change_token(
    user_id: UUID,
    new_email: str,
    password_hash: str,
    config: ParbakedConfig,
) -> str:
    """Mint a verify link for an email-change request (#275, GDPR Article 16).

    The token carries:

    - ``sub`` — the requesting user's UUID (binds the link to one account)
    - ``new_email`` — the destination address the user wants to move to
    - ``fp`` — fingerprint of the user's current ``password_hash``, so a
      password reset between mint and click invalidates the outstanding
      link (same one-shot trick :func:`verify_password_reset_token` uses)

    Replay defence is layered:

    1. The ``fp`` claim rejects clicks after a password reset.
    2. The service layer (:func:`parbaked.auth.service.complete_email_change`)
       rejects clicks where ``user.email`` already equals ``new_email`` —
       i.e. the swap already happened. Mutating the email IS the burn.
    """
    secret = config.effective_approval_secret()
    if not secret:
        raise RuntimeError(
            "Cannot sign email-change token: set PARBAKED_APPROVAL_TOKEN_SECRET "
            "(or PARBAKED_JWT_SECRET as a fallback)."
        )
    payload = {
        "sub": str(user_id),
        "aud": _EMAIL_CHANGE_AUDIENCE,
        "new_email": new_email,
        "fp": _hash_fingerprint(password_hash),
        "iat": datetime.now(UTC),
        "exp": datetime.now(UTC)
        + timedelta(hours=config.password_reset_expiry_hours),
    }
    return jwt.encode(payload, secret, algorithm="HS256")


def verify_email_change_token(
    token: str, password_hash: str, config: ParbakedConfig
) -> tuple[UUID, str]:
    """Validate an email-change verify link against the user's current password_hash.

    Returns ``(user_id, new_email)`` on success. Raises
    :class:`InvalidEmailChangeToken` for forged, expired, or fingerprint-
    mismatched links — a password reset between mint and click invalidates
    every outstanding email-change link for that user.

    Per-token one-shot replay is enforced one layer up
    (:func:`parbaked.auth.service.complete_email_change` checks
    ``user.email == new_email``).
    """
    secret = config.effective_approval_secret()
    try:
        payload = jwt.decode(
            token, secret, algorithms=["HS256"], audience=_EMAIL_CHANGE_AUDIENCE
        )
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError) as exc:
        raise InvalidEmailChangeToken(str(exc)) from exc
    if payload.get("fp") != _hash_fingerprint(password_hash):
        raise InvalidEmailChangeToken("Token already used or password changed.")
    new_email = payload.get("new_email")
    if not isinstance(new_email, str) or not new_email:
        raise InvalidEmailChangeToken("Missing or malformed new_email claim")
    try:
        user_id = UUID(payload["sub"])
    except (KeyError, ValueError) as exc:
        raise InvalidEmailChangeToken("Missing or malformed subject") from exc
    return user_id, new_email
