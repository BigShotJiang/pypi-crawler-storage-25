"""Auth orchestration service (#35, #227).

The HTTP routes in :mod:`parbaked.auth.router` are thin translators: they
parse the request body, call into here, then format the response. The
business logic — duplicate-email checks, password hashing, token mint,
audit event shape, hook firing — lives in this module so that CLI / MCP /
direct tests can reuse it without spinning up an HTTP client.

Functions in here raise :class:`fastapi.HTTPException` where the route
they replaced did. The caller decides whether to translate that into an
HTTP body, a CLI exit code, or a structured JSON response — the
exceptions just carry the status / detail consistently across surfaces.
"""

from __future__ import annotations

import enum
import functools
import logging
import secrets as _secrets
from collections.abc import Callable
from datetime import UTC, datetime
from uuid import UUID

import bcrypt
import jwt
from fastapi import status
from fastapi.exceptions import HTTPException
from sqlalchemy.exc import IntegrityError
from sqlmodel import Session, select

from parbaked.auth.jwt import create_jwt
from parbaked.auth.models import User, UserStatus
from parbaked.auth.passwords import hash_password, verify_password
from parbaked.auth.tokens import (
    InvalidEmailChangeToken,
    InvalidPasswordResetToken,
    InvalidVerifyToken,
    create_admin_signin_token,
    create_approval_token,
    create_email_change_token,
    create_password_reset_token,
    create_verify_token,
    verify_email_change_token,
    verify_password_reset_token,
    verify_verify_token,
)
from parbaked.config import ParbakedConfig
from parbaked.email.base import EmailMessage, EmailTransport
from parbaked.email.templates import Templates
from parbaked.hooks import Hooks
from parbaked.logging import log_event

logger = logging.getLogger("parbaked.auth")


# bcrypt silently truncates input past 72 bytes — a user typing a 100-char
# passphrase would only have the first 72 bytes hashed, so the remaining
# entropy is wasted and any prefix-match passphrase logs in. We reject up
# front rather than pre-hashing with SHA-256, because the upper bound is
# unambiguous and avoids quietly changing the hashing pipeline (#167).
_BCRYPT_MAX_BYTES = 72


# Pre-computed bcrypt hash used to equalise login response time when an email
# isn't registered. Without this, the "unknown user" branch returns in <1ms
# while the "known user, wrong password" branch spends ~100ms in bcrypt — an
# attacker can probe /auth/login to enumerate which emails have accounts (#133).
#
# Lazy-initialised via ``functools.cache`` so the ~100ms bcrypt cost is paid
# at most once per process AND only on the first call site that needs it
# (the first /auth/login against an unknown email). Eager module-level
# computation taxed every CLI invocation — ``parbaked --help`` imports
# :mod:`parbaked.cli.users` which imports this module, so the dummy hash
# fired even when no auth flow ran (#261).
@functools.cache
def _dummy_password_hash() -> str:
    return bcrypt.hashpw(b"x", bcrypt.gensalt()).decode()


def _reject_if_too_long_for_bcrypt(password: str) -> None:
    """Raise 422 if ``password`` would be truncated by bcrypt.

    The limit is on the UTF-8 byte length, not the character count — a
    72-character passphrase made of 4-byte emoji would still bust the
    cap. Mirror bcrypt's own check so the user gets a real error instead
    of a silently-shortened hash.
    """
    if len(password.encode("utf-8")) > _BCRYPT_MAX_BYTES:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Password is too long (max {_BCRYPT_MAX_BYTES} bytes).",
        )


def user_from_unverified_token(token: str, session: Session) -> User | None:
    """Resolve the User a token claims to be for, *without* verifying the token.

    Some flows (currently password reset, historically admin-invite/claim before
    #130) need the live User row to perform the real verification — e.g. the
    password-reset fingerprint must be checked against the user's current
    ``password_hash``, which means we have to look the user up before we can
    fully verify the token. We peek at the ``sub`` claim with every JWT check
    disabled, coerce it to a UUID, and look the user up.

    Using ``verify_signature=False`` here is intentional and safe: the caller
    is REQUIRED to perform the real signature/exp/audience verification in a
    second step against the resolved user. If the signature is bad or the
    token is stale, that second step rejects it — this helper only narrows
    "which user is this token addressed to?" so the caller can hand the right
    fingerprint to the real verifier. A token with a forged ``sub`` claim
    still fails the signature check; an unsigned token returning ``None``
    here would have failed the verifier too.
    """
    try:
        # Peek-only: disable every check. Real verification (signature, exp,
        # audience, and the per-user fingerprint) runs in the caller's second
        # pass against the resolved user.
        payload = jwt.decode(
            token,
            options={
                "verify_signature": False,
                "verify_exp": False,
                "verify_aud": False,
                "verify_iat": False,
            },
        )
    except jwt.InvalidTokenError:
        return None
    subject = payload.get("sub")
    if not subject:
        return None
    try:
        user_uuid = UUID(subject)
    except (TypeError, ValueError):
        return None
    return session.get(User, user_uuid)


def safe_send(email: EmailTransport, message: EmailMessage) -> bool:
    """Send an email best-effort. Failures are logged but never propagate
    so DB state changes and hook firings downstream of the send still happen.

    Returns ``True`` if the transport accepted the message, ``False`` if it
    raised. Callers that need to surface delivery status to a user-facing
    response (signup #88 — "Check your inbox" lies if Resend was 403'd by
    sandbox / rate limit / bad key) can branch on the boolean. Existing
    callers that ignore it stay correct since the success/no-op path is
    unchanged.

    Unified replacement for the prior ``_safe_send`` (auth router) and inline
    ``contextlib.suppress(Exception)`` (admin) — #36.
    """
    try:
        email.send(message)
    except Exception:  # noqa: BLE001 — best-effort by design
        logger.exception("Email send failed; continuing with auth flow.")
        return False
    return True


def approve_user(
    user: User,
    session: Session,
    *,
    config: ParbakedConfig,
    email: EmailTransport,
    templates: Templates,
    hooks: Hooks,
    via: str,
    ip: str | None = None,
) -> bool:
    """Approve a user. Idempotent — re-approving an active user is a no-op.

    Returns True if the user was newly approved (DB write + side-effects
    fired), False if they were already active.

    ``via`` is recorded as ``extra={"via": via}`` on the audit event so the
    operator can see which entry point triggered the action (magic_link,
    dashboard, cli).

    Side-effects (welcome email, audit event, ``on_approve`` hook) ONLY fire
    on a real transition. The early-return False below is the load-bearing
    line: it sits BEFORE the email send / log_event / hooks.fire so a
    duplicate call (admin clicks Approve twice, or the CLI is re-run after
    the row already flipped) does not re-mail the user, double-log, or
    re-fire downstream hooks. Without this gating a "you're in!" welcome
    email would re-send on every duplicate call — confusing for the user
    and bad for sender reputation at Resend / SendGrid (#336).
    """
    if user.status == UserStatus.active:
        # No-op. Side-effects intentionally skipped — see docstring.
        return False

    now = datetime.now(UTC)
    user.status = UserStatus.active
    user.approved_at = now
    # Safety net: a human clicking approve implicitly attests to the email.
    # The magic-link path also enforces this — having it here means CLI and
    # dashboard get the same forgiveness.
    if user.email_verified_at is None:
        user.email_verified_at = now
    session.add(user)
    session.commit()
    session.refresh(user)

    login_url = f"{config.app_url.rstrip('/')}{config.login_path}"
    safe_send(email, templates.user_approved(user, login_url, config))

    log_event(
        "approve",
        user_id=str(user.id),
        email=user.email,
        ip=ip,
        extra={"via": via},
    )
    hooks.fire("approve", user)
    return True


def reject_user(
    user: User,
    session: Session,
    *,
    config: ParbakedConfig,
    email: EmailTransport,
    templates: Templates,
    hooks: Hooks,
    via: str,
    ip: str | None = None,
) -> bool:
    """Reject a user. Idempotent — re-rejecting is a no-op.

    Returns True if the user was newly rejected, False if already rejected.

    Sets ``revoked_at = now()`` so any outstanding JWT for the user is
    immediately invalidated (#37).

    Side-effects (rejection email, audit event, ``on_reject`` hook) ONLY
    fire on a real transition. The early-return False below is the
    load-bearing line: it sits BEFORE the email send / log_event /
    hooks.fire so re-running ``parbaked users reject bob@example.com``
    against an already-rejected user does not re-mail Bob a second
    "About your signup" notice (#336).
    """
    if user.status == UserStatus.rejected:
        # No-op. Side-effects intentionally skipped — see docstring.
        return False

    user.status = UserStatus.rejected
    user.revoked_at = datetime.now(UTC)
    session.add(user)
    session.commit()
    session.refresh(user)

    safe_send(email, templates.user_rejected(user, config))

    log_event(
        "reject",
        user_id=str(user.id),
        email=user.email,
        ip=ip,
        extra={"via": via},
    )
    hooks.fire("reject", user)
    return True


def _resend_verify_for_pending(
    user: User,
    *,
    config: ParbakedConfig,
    email_transport: EmailTransport,
    templates: Templates,
    verify_url_prefix: str,
) -> Callable[[], None] | None:
    """Build a verify-email send callable for a duplicate-signup against an
    existing pending+unverified user (#314).

    Returns the same kind of zero-arg callable :func:`signup_user` returns
    on a fresh signup (caller threads it through ``BackgroundTasks.add_task``
    so timing matches the fresh path) — or ``None`` when no resend should
    fire. The gate is intentionally tight:

    - ``config.email_enabled`` must be True. Dashboard-only deployments
      (#74) have no transport to send through and no enumeration risk
      worth the cost (single-operator PoCs); the issue explicitly carves
      this out as out-of-scope.
    - ``user.status`` must be :attr:`UserStatus.pending`. Re-sending a
      verify link to an ``active`` user would email a useless link they
      already clicked. ``rejected`` users were declined by the admin —
      the user should contact the admin, not get another verify mail.
    - ``user.email_verified_at`` must be ``None``. A ``pending``-but-
      ``verified`` user clicked their original verify link and is waiting
      on admin approval; their email already got through, and re-sending
      a stale verify link would only confuse them.

    The mint reuses ``create_verify_token`` so the link carries the same
    JWT shape as a fresh signup's. The token's TTL restarts from now,
    which is the whole point of the resend: a user who let the original
    link expire gets a working one by retrying signup.
    """
    if not config.email_enabled:
        return None
    if user.status != UserStatus.pending:
        return None
    if user.email_verified_at is not None:
        return None

    verify_token = create_verify_token(user.id, config)
    verify_url = (
        f"{config.app_url.rstrip('/')}{verify_url_prefix}/verify/{verify_token}"
    )
    verify_message = templates.user_verify_email(user, verify_url, config)

    def send_verify_email() -> None:
        safe_send(email_transport, verify_message)

    return send_verify_email


def signup_user(
    email: str,
    name: str,
    password: str,
    *,
    session: Session,
    config: ParbakedConfig,
    email_transport: EmailTransport,
    templates: Templates,
    hooks: Hooks,
    verify_url_prefix: str,
    ip: str | None = None,
) -> tuple[User, UserStatus, bool, Callable[[], None] | None]:
    """Create a pending user.

    Returns ``(user, reported_status, email_sent, send_verify_email)``.

    ``reported_status`` is what the API/CLI should claim back to the
    caller. For a fresh signup it equals ``user.status`` (always
    ``pending`` initially); for a duplicate signup it is hardcoded to
    ``pending`` regardless of the existing user's real status, so the
    response shape can't be used to distinguish active / rejected /
    unknown accounts (#179).

    ``email_sent`` reflects whether the deployment is in email mode
    (``config.email_enabled``), NOT whether the transport actually
    succeeded — that decoupling is what keeps the response from leaking
    "this address is registered" through a broken transport (#179).

    ``send_verify_email`` is a zero-arg callable the caller is expected
    to dispatch — ``None`` when no email needs sending (dashboard-only
    mode, OR a duplicate signup against an already-verified / active /
    rejected account). For duplicate signups against an account that's
    still ``pending`` and unverified, the callable re-mints + re-sends
    the verify link (#314) — fixing the "forgot I signed up, retry, see
    'Check your inbox' with nothing arriving" UX wart the #179
    no-enumeration defence created. HTTP routes wrap the callable in
    ``background_tasks.add_task(send_verify_email)`` so the response
    returns before the ~200-500ms Resend HTTP call completes — without
    backgrounding, the fresh-signup branch would be ~300ms while the
    duplicate branch is ~100ms, a timing oracle that defeats the
    bcrypt-equalised closure (#179). The resend rides the SAME queue
    for the same reason — a duplicate-resend taking 300ms while the
    no-resend duplicate (active/rejected user) returned in 100ms would
    re-introduce the side channel. CLI / MCP callers — which don't have
    an attacker probing response times — can invoke it synchronously.
    Returning the dispatch as a callable keeps ``BackgroundTasks`` (a
    FastAPI type) out of the service layer so non-HTTP surfaces don't
    have to fabricate one (#261 item 2).

    Raises :class:`HTTPException` 422 if the password would be truncated
    by bcrypt. Duplicate-email signups return the existing user with the
    same response shape as a fresh signup so the API doesn't enumerate
    accounts (#179, #189).

    ``verify_url_prefix`` is the absolute path the verify magic link
    should be built under (typically ``"/auth"`` matching the router
    prefix). The route handler supplies it; the CLI / MCP can pass
    whatever maps to their deployment.
    """
    # bcrypt truncates past 72 bytes — reject before hashing so a
    # long passphrase doesn't silently drop entropy (#167).
    _reject_if_too_long_for_bcrypt(password)

    # Normalise email at signup so case variants of the same address
    # ("Foo@x.com" and "foo@x.com") can't both create accounts (#164).
    # All lookup sites (login, forgot-password, etc.) also lower-case
    # their query, so a user signing up as "FOO@x.com" can log in with
    # "foo@x.com".
    email_normalised = email.lower()

    # Duplicate-email branch: return the SAME response shape as a fresh
    # signup so an attacker probing /auth/signup with arbitrary addresses
    # can't tell which ones already have accounts (#179). We don't touch
    # the existing row, BUT in email mode we re-mint + re-send the verify
    # link to the legitimate owner when they're still ``pending`` and
    # haven't verified yet (#314) — that's the "I forgot I signed up,
    # retry, see 'Check your inbox' with no email arriving" UX wart the
    # no-enumeration defence created. The resend never fires for
    # already-verified / active / rejected accounts: those users either
    # don't need a verify link (active, rejected) or already received one
    # they clicked through (status==pending AND email_verified_at set
    # means "awaiting admin approval", not "never got the email"). The
    # response shape stays identical regardless — see ``send_verify_email``
    # plumbing below for how the resend rides the same BackgroundTasks
    # queue as the fresh-signup send so timing stays equalised.
    existing = session.exec(
        select(User).where(User.email == email_normalised)
    ).first()
    if existing is not None:
        # Burn a bcrypt hash so the duplicate-email response time matches
        # the fresh-signup path (which hashes below). Without this,
        # the duplicate branch returns in <1ms while the fresh path takes
        # ~100ms in bcrypt — an attacker measuring response time can still
        # enumerate registered emails despite the identical response shape
        # (#179, mirrors the login _DUMMY_PASSWORD_HASH burn at #133).
        hash_password(password)
        send_verify_email = _resend_verify_for_pending(
            existing,
            config=config,
            email_transport=email_transport,
            templates=templates,
            verify_url_prefix=verify_url_prefix,
        )
        log_event(
            "signup.duplicate_suppressed",
            user_id=str(existing.id),
            email=existing.email,
            ip=ip,
            extra={
                "reason": (
                    "pre_check_pending_resend"
                    if send_verify_email is not None
                    else "pre_check"
                ),
            },
        )
        # ``email_sent`` mirrors what a fresh signup would have returned:
        # True iff email mode is enabled. Hardcoding True here would leak
        # no-email-mode accounts via the response (fresh signups in
        # no-email mode return email_sent=False — see #74). Same goes for
        # the status: report ``pending`` regardless of the actual stored
        # status so the response shape can't distinguish active/rejected
        # accounts from unknown ones.
        return existing, UserStatus.pending, config.email_enabled, send_verify_email

    user = User(
        email=email_normalised,
        name=name,
        password_hash=hash_password(password),
        status=UserStatus.pending,
    )

    if not config.email_enabled:
        # Dashboard-only mode (#74). The verify step exists to filter
        # bot signups out of the admin queue using a possess-the-email
        # check; without email there's no way to perform that check,
        # so the admin's manual triage IS the filter. Mark the user
        # verified at signup time so they show up in the pending
        # queue immediately.
        user.email_verified_at = datetime.now(UTC)

    session.add(user)
    try:
        session.commit()
    except IntegrityError:
        # Concurrent signup with the same email — the pre-check above
        # is racy under load, but the UNIQUE constraint on users.email
        # is not. Both racing requests pass the SELECT, the slower
        # INSERT fails here. Roll back so the session is usable, then
        # look up the race winner and return the same non-enumerating
        # response shape the pre-check path returns (#179, #189). If
        # the lookup somehow still misses (genuinely unexpected) fall
        # through and let the original IntegrityError surface.
        session.rollback()
        winner = session.exec(
            select(User).where(User.email == email_normalised)
        ).first()
        if winner is not None:
            # No bcrypt burn needed here — hash_password already ran
            # before the failing commit, so this path's timing
            # naturally matches the fresh-signup path's bcrypt cost.
            # Re-send the verify link if the winner is still pending +
            # unverified — same #314 logic as the pre-check branch above.
            send_verify_email = _resend_verify_for_pending(
                winner,
                config=config,
                email_transport=email_transport,
                templates=templates,
                verify_url_prefix=verify_url_prefix,
            )
            log_event(
                "signup.duplicate_suppressed",
                user_id=str(winner.id),
                email=winner.email,
                ip=ip,
                extra={
                    "reason": (
                        "race_pending_resend"
                        if send_verify_email is not None
                        else "race"
                    ),
                },
            )
            return winner, UserStatus.pending, config.email_enabled, send_verify_email
        raise
    session.refresh(user)

    # Email the user a verification magic link. The admin doesn't get
    # notified until the user actually clicks through — that's how we
    # filter out junk signups before they reach the admin queue. In
    # no-email mode we already marked the user verified above and
    # skip this send entirely.
    #
    # We construct the message + send callable here (so the caller never
    # sees ``email_transport`` / ``templates``) but DO NOT dispatch — the
    # caller decides whether to background it (HTTP) or run it inline
    # (CLI / MCP). HTTP keeps the timing-equalisation invariant by
    # threading the callable through ``BackgroundTasks.add_task`` so the
    # response returns before the ~200-500ms Resend HTTP call completes
    # — otherwise the fresh path would take ~300ms (bcrypt + HTTP) while
    # the duplicate path takes ~100ms (bcrypt only), an attacker-
    # measurable difference that defeats the bcrypt-equalised timing
    # closure (#179, Devin). Returning the callable instead of taking a
    # ``BackgroundTasks`` parameter keeps the service framework-agnostic
    # (#261 item 2). Transport failures inside ``safe_send`` land in the
    # warning log; the audit event below records dispatch intent only.
    send_verify_email: Callable[[], None] | None = None
    if config.email_enabled:
        verify_token = create_verify_token(user.id, config)
        verify_url = (
            f"{config.app_url.rstrip('/')}{verify_url_prefix}/verify/{verify_token}"
        )
        verify_message = templates.user_verify_email(user, verify_url, config)

        def send_verify_email() -> None:
            safe_send(email_transport, verify_message)

    log_event(
        "signup",
        user_id=str(user.id),
        email=user.email,
        ip=ip,
        extra={
            "email_dispatched": config.email_enabled,
            "email_enabled": config.email_enabled,
        },
    )
    hooks.fire("signup", user)
    # ``email_sent`` reflects email-mode, not the transport's actual
    # success — otherwise a broken Resend key would let an attacker
    # enumerate accounts by probing one fresh address first (fresh →
    # False, duplicate → True). The real outcome is in the audit event
    # above + the warning log.
    return user, user.status, config.email_enabled, send_verify_email


class VerifyOutcome(enum.StrEnum):
    """Result of :func:`verify_email` — what page/response the caller should render.

    The orchestration lives in the service; HTML rendering / JSON
    formatting is the caller's job. Each variant maps 1:1 to the
    branches the old route handler emitted directly.
    """

    invalid_token = "invalid_token"
    user_not_found = "user_not_found"
    already_verified = "already_verified"
    verified = "verified"


def verify_email(
    token: str,
    *,
    session: Session,
    config: ParbakedConfig,
    email_transport: EmailTransport,
    templates: Templates,
    hooks: Hooks,
    approval_url_prefix: str,
    ip: str | None = None,
) -> tuple[VerifyOutcome, User | None]:
    """Verify a signup-token. Returns ``(outcome, user)``.

    ``user`` is the User row on the ``already_verified`` and
    ``verified`` outcomes (so callers can name them in the response
    page), and ``None`` on the failure outcomes.

    On a fresh verification, the user's ``email_verified_at`` is set
    and the admin is notified out-of-band via the approval-request
    email (#130). Tokens that don't decode, don't match a live user,
    or were already burned each have a distinct outcome so the caller
    can render the right message — but no flow leaks "this email is
    registered" because callers funnel both invalid_token and
    user_not_found into the same generic error UX.
    """
    try:
        user_id = verify_verify_token(token, config)
    except InvalidVerifyToken as exc:
        logger.info("verify rejected: %s", exc)
        log_event(
            "verify.fail",
            ip=ip,
            success=False,
            extra={"reason": "invalid_token", "detail": str(exc)},
        )
        return VerifyOutcome.invalid_token, None

    user = session.get(User, user_id)
    if user is None:
        return VerifyOutcome.user_not_found, None
    if user.email_verified_at is not None:
        return VerifyOutcome.already_verified, user

    user.email_verified_at = datetime.now(UTC)
    session.add(user)
    session.commit()
    session.refresh(user)

    # Now that we've proven the email is real, notify the admin.
    if config.admin_email:
        approve = create_approval_token(user.id, "approve", config)
        reject = create_approval_token(user.id, "reject", config)
        approve_url = f"{config.app_url.rstrip('/')}{approval_url_prefix}/approve/{approve}"
        reject_url = f"{config.app_url.rstrip('/')}{approval_url_prefix}/reject/{reject}"
        safe_send(
            email_transport,
            templates.admin_approval_request(user, approve_url, reject_url, config),
        )

    log_event("verify", user_id=str(user.id), email=user.email, ip=ip)
    hooks.fire("verify", user)
    return VerifyOutcome.verified, user


def authenticate_user(
    email: str,
    password: str,
    *,
    session: Session,
    config: ParbakedConfig,
    ip: str | None = None,
) -> tuple[str, User]:
    """Authenticate an email + password. Returns ``(jwt_token, user)``.

    Raises :class:`HTTPException`:
    - 401 ``Invalid credentials`` for unknown email or wrong password.
      Both branches burn a bcrypt hash so the response times match —
      otherwise the unknown-email branch returns in <1ms while the
      wrong-password branch takes ~100ms, leaking which addresses are
      registered (#133).
    - 403 ``Email not yet verified — ...`` if the user signed up but
      hasn't clicked the verify magic link yet (the recovery path is
      user-actionable, so the message stays explicit).
    - 403 ``Account not active`` if the user is pending or rejected.
      Both states share the message (#136 option 3): exposing the
      precise admin decision offers no recovery to the user and leaks
      internal moderation state.

    The hooks/email/templates dependencies aren't taken because login
    has no side-effects beyond the audit log and the JWT mint — a
    successful login doesn't email anyone or fire a hook.
    """
    # Lookup is case-insensitive — emails are stored lower-cased at
    # signup (#164) so "Foo@X.com" and "foo@x.com" resolve to the same
    # account.
    user = session.exec(select(User).where(User.email == email.lower())).first()
    # Same response for "no user" and "wrong password" to avoid
    # enumeration. When the email is unknown we still run bcrypt against
    # a fixed dummy hash so the response time matches the wrong-password
    # path — otherwise a timing side channel reveals which emails are
    # registered (#133).
    if user is None:
        verify_password(password, _dummy_password_hash())  # constant-time burn
        log_event(
            "login.fail",
            email=email,
            ip=ip,
            success=False,
            extra={"reason": "invalid_credentials"},
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials"
        )
    if not verify_password(password, user.password_hash):
        log_event(
            "login.fail",
            email=email,
            ip=ip,
            success=False,
            extra={"reason": "invalid_credentials"},
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials"
        )
    # Account-state branches below run only on a correct-password request,
    # which means the caller already proved they own the account — so
    # surfacing "unverified" vs "not active" doesn't help an enumerator.
    # We keep the "email not verified" message distinct because it is
    # user-actionable (the verify magic link is the recovery path). We
    # deliberately collapse `pending` and `rejected` into a single generic
    # "Account not active" response (#136 option 3): exposing the precise
    # admin-decision state to the user offers no recovery path and leaks
    # internal moderation status. Future security passes: this is
    # intentional, do not split the messages back out.
    if user.email_verified_at is None:
        log_event(
            "login.fail",
            user_id=str(user.id),
            email=user.email,
            ip=ip,
            success=False,
            extra={"reason": "unverified"},
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Email not yet verified — check your inbox for the verification link.",
        )
    if user.status == UserStatus.pending:
        log_event(
            "login.fail",
            user_id=str(user.id),
            email=user.email,
            ip=ip,
            success=False,
            extra={"reason": "pending_approval"},
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Account not active"
        )
    if user.status == UserStatus.rejected:
        log_event(
            "login.fail",
            user_id=str(user.id),
            email=user.email,
            ip=ip,
            success=False,
            extra={"reason": "rejected"},
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Account not active"
        )

    token = create_jwt(user.id, config)
    log_event("login.success", user_id=str(user.id), email=user.email, ip=ip)
    return token, user


def request_password_reset(
    email: str,
    *,
    session: Session,
    config: ParbakedConfig,
    email_transport: EmailTransport,
    templates: Templates,
    reset_url_prefix: str,
    ip: str | None = None,
) -> bool:
    """Send a password-reset email if the address is registered. Returns
    ``email_enabled`` — True in normal mode, False in dashboard-only mode.

    Always returns successfully (no exception) regardless of whether the
    address exists, so the endpoint can't be used to discover which
    addresses are registered. The audit log records the precise reason
    (no_email_configured / unknown_email / sent) — that's where the
    admin sees what actually happened.

    In dashboard-only mode (#74) the function is a no-op for sending
    purposes; the boolean lets the caller (HTTP route / CLI) surface
    "ask your admin for a reset link" instead of lying about an inbox.
    """
    if not config.email_enabled:
        # Dashboard-only mode (#74). No transport configured — the
        # endpoint still pretends success to preserve the no-enumeration
        # invariant, but the boolean lets the front-end surface the
        # "ask your admin for a reset link" message instead of
        # "check your inbox" gaslighting.
        log_event(
            "password_reset.request",
            email=email,
            ip=ip,
            success=False,
            extra={"reason": "no_email_configured"},
        )
        return False

    # Case-insensitive lookup — signup stores lower-cased (#164).
    user = session.exec(select(User).where(User.email == email.lower())).first()
    if user is None:
        log_event(
            "password_reset.request",
            email=email,
            ip=ip,
            success=False,
            extra={"reason": "unknown_email"},
        )
        return True

    reset_token = create_password_reset_token(user.id, user.password_hash, config)
    reset_url = f"{config.app_url.rstrip('/')}{reset_url_prefix}/reset/{reset_token}"
    safe_send(email_transport, templates.password_reset(user, reset_url, config))
    log_event(
        "password_reset.request",
        user_id=str(user.id),
        email=user.email,
        ip=ip,
    )
    return True


class ResetOutcome(enum.StrEnum):
    """Result of :func:`complete_password_reset` — what the caller should render.

    Mirrors the branches the old route emitted directly: a bad
    token / unknown user goes to the generic "Link invalid or expired"
    error page; a password-mismatch or oversize-password re-renders the
    form with an inline error; the happy path updates the hash, kicks
    every JWT (#37), and returns ``success``.
    """

    invalid_token = "invalid_token"
    password_mismatch = "password_mismatch"
    password_too_long = "password_too_long"
    success = "success"


def complete_password_reset(
    token: str,
    password: str,
    confirm: str,
    *,
    session: Session,
    config: ParbakedConfig,
    ip: str | None = None,
) -> tuple[ResetOutcome, User | None]:
    """Verify a password-reset token and rotate the user's password.

    Returns ``(outcome, user)``. ``user`` is the resolved row on every
    outcome where one was identified (mismatch / too_long / success) so
    the caller can re-render the reset form with the user's email
    pre-filled. On ``invalid_token`` ``user`` may still be ``None`` if
    the token didn't even decode to a known sub.

    Forgot-password is the canonical "I think my account is
    compromised" signal — on success we rotate the hash AND set
    ``revoked_at`` to now() so every outstanding JWT is invalidated
    server-side (#37).
    """
    user = user_from_unverified_token(token, session)
    if user is None:
        log_event(
            "password_reset.fail",
            ip=ip,
            success=False,
            extra={"reason": "unknown_user"},
        )
        return ResetOutcome.invalid_token, None

    try:
        verify_password_reset_token(token, user.password_hash, config)
    except InvalidPasswordResetToken as exc:
        log_event(
            "password_reset.fail",
            user_id=str(user.id),
            email=user.email,
            ip=ip,
            success=False,
            extra={"reason": "invalid_token", "detail": str(exc)},
        )
        return ResetOutcome.invalid_token, user

    if password != confirm:
        return ResetOutcome.password_mismatch, user

    # bcrypt truncates past 72 bytes — reject in the password-change path
    # too, otherwise a user resetting from a 100-char password would have
    # their tail silently dropped (#167).
    if len(password.encode("utf-8")) > _BCRYPT_MAX_BYTES:
        return ResetOutcome.password_too_long, user

    user.password_hash = hash_password(password)
    # Forgot-password is the canonical "I think my account is compromised"
    # signal. Revoke every existing session at the same time we rotate
    # the password (#37) so the attacker holding a stolen JWT is kicked.
    user.revoked_at = datetime.now(UTC)
    session.add(user)
    session.commit()
    # Rotating the hash invalidates this token and any other outstanding
    # reset links for the same user. No state to clean up.

    log_event(
        "password_reset.success",
        user_id=str(user.id),
        email=user.email,
        ip=ip,
    )
    return ResetOutcome.success, user


def admin_signin_request(
    submitted_email: str | None,
    session: Session,
    *,
    config: ParbakedConfig,
    email_transport: EmailTransport,
    templates: Templates,
    signin_url_prefix: str,
    ip: str | None = None,
) -> bool:
    """Process an email-mode admin sign-in request. Returns whether the
    submitted address matched the configured ``admin_email``.

    The boolean is for the audit/observability path only — callers MUST
    NOT echo it in the response, because doing so would let an attacker
    enumerate the admin address (same no-enumeration discipline the
    forgot-password endpoint has used since v0.8, see #130). The route
    handler renders the same "If that's the admin address, a sign-in
    link is on its way" page regardless.

    Only a matching address ever triggers a token mint + email send.
    The configured admin email is the *only* destination; we never mail
    whatever the operator typed in.

    ``session`` is threaded through to :func:`create_admin_signin_token`
    so the minted token embeds the current per-admin signin nonce — see
    #205 and the model docstring for the one-shot mechanics.
    """
    submitted = (submitted_email or "").strip().lower()
    expected = (
        str(config.admin_email).strip().lower() if config.admin_email else ""
    )
    matched = bool(expected) and _secrets.compare_digest(submitted, expected)
    if matched:
        token = create_admin_signin_token(config, session)
        signin_url = f"{config.app_url.rstrip('/')}{signin_url_prefix}/signin/{token}"
        # ``safe_send`` returns False when the transport raises (Resend
        # 403, bad key, network blip). Thread that result into the audit
        # event so operators reading logs later can see when no email
        # left the building — mirrors signup's email_sent shape (#206
        # item 4, ported into the service function during #227 rebase).
        sent = safe_send(email_transport, templates.admin_signin(signin_url, config))
        log_event(
            "admin.signin.request",
            ip=ip,
            success=sent,
            extra={"matched": True, "email_sent": sent},
        )
    else:
        # Don't leak which email is configured. Don't send a magic link
        # to whoever the operator typed in either — only the address
        # baked into config gets messages.
        log_event(
            "admin.signin.request",
            ip=ip,
            success=False,
            extra={"reason": "no_match"},
        )
    return matched


# ---------------------------------------------------------------------------
# GDPR account self-service (#275)
# ---------------------------------------------------------------------------

# Sentinel password_hash value written to the row by :func:`delete_user`.
# Picked so :func:`verify_password` can never accept any submitted password
# — bcrypt's ``checkpw`` raises ``ValueError`` for non-2b-formatted hashes,
# which is converted to ``False`` in :func:`parbaked.auth.passwords.verify_password`.
# Don't pick the empty string here: that's the default for newly-instantiated
# rows in a few migration code paths, and conflating "deleted" with "uninitialised"
# would let a half-migrated row pass the deletion check.
_DELETED_PASSWORD_HASH = "!deleted!"

# Reserved domain for scrubbed email addresses (#275). RFC 6761 §6.4 carves
# out ``.invalid`` as a name that "is intended for use in online construction
# of domain names that are sure to be invalid" — no DNS resolver will ever
# return an A/MX record for it, no mail transport will ever route a message
# to it. Safe to write into the UNIQUE-constrained ``email`` column without
# any chance of colliding with a real user later.
_DELETED_EMAIL_DOMAIN = "parbaked.invalid"


def _scrubbed_email_for(user_id: UUID) -> str:
    """Deterministic per-user scrubbed email (#275).

    Uses the user's UUID so two deleted accounts can't collide on the
    UNIQUE(email) index — important because soft-delete leaves the row
    in place forever, and we'd otherwise hit a second-deletion conflict
    the moment the same scrubbed value was reused.
    """
    return f"deleted-{user_id}@{_DELETED_EMAIL_DOMAIN}"


def delete_user(
    user: User,
    *,
    session: Session,
    config: ParbakedConfig,  # noqa: ARG001 — kept for symmetry + future config hooks
    hooks: Hooks,
    ip: str | None = None,
) -> User:
    """Soft-delete the authenticated user (#275, GDPR Article 17).

    Cascade scrub on the parbaked-owned row:

    - ``revoked_at = now()`` — kills every outstanding JWT for this account
      (the ``current_user`` dependency rejects tokens whose ``iat`` is at
      or before ``revoked_at``).
    - ``status = rejected`` — reuses the existing "blocked from login" path
      so downstream UX stays consistent. Login attempts after delete hit
      the same 403 "Account not active" branch a rejected signup would.
    - ``email = deleted-{uuid}@parbaked.invalid`` — frees the original
      email slot for re-signup. ``.invalid`` is RFC 6761 reserved so the
      scrubbed value can never route real mail.
    - ``name = ""`` — wipes the display name from any audit/exports that
      surface user-facing strings.
    - ``password_hash = "!deleted!"`` — poisoned value; bcrypt's
      ``checkpw`` rejects non-2b hashes so no password matches.

    Audit event ``user.deleted`` is emitted AFTER the scrub commits, with
    the (scrubbed) UUID as ``user_id``. The ``on_delete`` hook fires
    AFTER the audit log — same ordering as ``on_signup`` / ``on_verify``
    / ``on_approve`` / ``on_reject``.

    The row is NOT removed: foreign keys from consumer tables onto
    ``users.id`` would otherwise be orphaned. parbaked's contract (see
    AGENTS.md "GDPR account self-service") tells consumers to register
    an ``on_delete`` hook to cascade-clean their own tables.

    Returns the scrubbed :class:`User` so callers can pass it into
    additional logging / response bodies. The hook receives the same
    scrubbed instance.
    """
    user.revoked_at = datetime.now(UTC)
    user.status = UserStatus.rejected
    user.email = _scrubbed_email_for(user.id)
    user.name = ""
    user.password_hash = _DELETED_PASSWORD_HASH
    session.add(user)
    session.commit()
    session.refresh(user)

    log_event(
        "user.deleted",
        user_id=str(user.id),
        ip=ip,
    )
    hooks.fire("delete", user)
    return user


class EmailChangeOutcome(enum.StrEnum):
    """Result of :func:`request_email_change` — what the caller should render.

    pydantic catches malformed emails at the HTTP boundary, so this enum
    only carries the post-validation branches: collision, same-as-current,
    no-email-mode refusal, or success.
    """

    sent = "sent"
    """Verify link minted + sent to the new address. 202 Accepted."""

    same_email = "same_email"
    """The user submitted their current email. No-op; 400 at the HTTP layer."""

    conflict = "conflict"
    """Another active user already owns this email. 409 Conflict."""

    email_disabled = "email_disabled"
    """No email transport configured — the verify-the-new-inbox round-trip
    can't happen, so the flow is refused at the HTTP layer (#305).

    Unlike forgot-password, email-change has no useful "ask your admin
    for a link" fallback: the whole point is to prove the user can read
    the destination inbox before we move the account onto it, and no
    out-of-band channel can substitute for that. The admin must rotate
    the row directly (``parbaked users`` CLI / DB edit). Surfaces as
    409 Conflict with explicit copy at the HTTP layer.
    """


def request_email_change(
    user: User,
    new_email: str,
    *,
    session: Session,
    config: ParbakedConfig,
    email_transport: EmailTransport,
    templates: Templates,
    change_url_prefix: str,
    ip: str | None = None,
) -> tuple[EmailChangeOutcome, Callable[[], None] | None]:
    """Mint + send a verify link for an email-change request (#275).

    Returns ``(outcome, send_verify)``. ``send_verify`` is a zero-arg
    callable the caller is expected to dispatch (HTTP wraps it in
    ``BackgroundTasks.add_task``); ``None`` on the non-sending branches
    (same_email / conflict).

    The verify link is sent to the NEW address — GDPR-correct flow: prove
    you can read the destination inbox before we move the account onto it.
    The current email is unchanged until the user clicks through.

    Uniqueness is case-insensitive (same normalisation rule as signup,
    #164). The ``same_email`` branch is kept distinct from ``conflict``
    so the HTTP layer can return 400 "no change needed" instead of a
    misleading 409 when a user submits their own current address.

    In dashboard-only / no-email mode (``config.email_enabled`` is False,
    i.e. neither ``resend_key`` nor ``admin_email`` is configured) the
    function refuses up front with :attr:`EmailChangeOutcome.email_disabled`
    rather than minting a verify token nobody will receive (#305). The
    parallel forgot-password flow has a "ask your admin for a reset link"
    fallback, but email-change has no such fallback — the verify-the-new-
    inbox proof is the whole point of the flow.
    """
    if not config.email_enabled:
        # Dashboard-only mode: no transport to send the verify-new-inbox
        # email through. Refuse the request rather than minting a token
        # that lands in the dev server's stdout but nowhere the user can
        # see it. The pre-#305 code returned ``sent`` here and made the
        # API lie about a "verify_sent" status when nothing was sent.
        log_event(
            "user.email_change.request",
            user_id=str(user.id),
            email=user.email,
            ip=ip,
            success=False,
            extra={"reason": "no_email_configured"},
        )
        return EmailChangeOutcome.email_disabled, None

    normalised = new_email.lower()
    if normalised == user.email.lower():
        log_event(
            "user.email_change.request",
            user_id=str(user.id),
            email=user.email,
            ip=ip,
            success=False,
            extra={"reason": "same_email"},
        )
        return EmailChangeOutcome.same_email, None

    # Uniqueness check. The unique constraint on ``users.email`` would
    # ultimately catch this too, but failing here means the user gets a
    # clear 409 instead of a 500 on the eventual swap.
    collision = session.exec(
        select(User).where(User.email == normalised)
    ).first()
    if collision is not None:
        log_event(
            "user.email_change.request",
            user_id=str(user.id),
            email=user.email,
            ip=ip,
            success=False,
            extra={"reason": "conflict", "new_email": normalised},
        )
        return EmailChangeOutcome.conflict, None

    token = create_email_change_token(
        user.id, normalised, user.password_hash, config
    )
    verify_url = (
        f"{config.app_url.rstrip('/')}{change_url_prefix}"
        f"/me/email/verify/{token}"
    )
    message = templates.email_change_verify(user, normalised, verify_url, config)

    def send_verify() -> None:
        safe_send(email_transport, message)

    log_event(
        "user.email_change.request",
        user_id=str(user.id),
        email=user.email,
        ip=ip,
        extra={"new_email": normalised},
    )
    return EmailChangeOutcome.sent, send_verify


class EmailChangeCompleteOutcome(enum.StrEnum):
    """Result of :func:`complete_email_change` — what page the caller should render.

    Token problems share the generic ``invalid_token`` outcome so the
    rendered HTML doesn't leak which user the link was for. ``conflict``
    handles the rare race where another user grabbed the destination
    address between mint and click.
    """

    invalid_token = "invalid_token"
    user_not_found = "user_not_found"
    already_completed = "already_completed"
    conflict = "conflict"
    changed = "changed"


def complete_email_change(
    token: str,
    *,
    session: Session,
    config: ParbakedConfig,
    email_transport: EmailTransport,
    templates: Templates,
    ip: str | None = None,
) -> tuple[EmailChangeCompleteOutcome, User | None]:
    """Verify the email-change token and swap the user's email (#275).

    Returns ``(outcome, user)``. ``user`` is the affected row on the
    ``already_completed``, ``conflict``, and ``changed`` outcomes (so the
    route handler can name the user in the response page); ``None`` on
    the invalid-token / user-not-found branches.

    On the happy path:

    - The user's ``email`` is replaced with the new address.
    - ``revoked_at`` is set to ``now()`` so every outstanding JWT for the
      account is invalidated — a stolen device cookie can't follow the
      account onto the new address.
    - A courtesy notice is sent to the OLD email so the previous-inbox
      owner notices an unauthorised change and can ping their admin.
    - Audit event ``user.email_changed`` records both addresses in
      ``extra``.

    One-shot replay: a second click against the same token sees the
    user's ``email`` already equal to the token's ``new_email`` claim
    and returns ``already_completed`` (400 at the HTTP layer).
    """
    # Peek at the subject without verifying so we can fetch the live
    # ``password_hash`` for the fingerprint check (same pattern as the
    # password-reset flow).
    user = user_from_unverified_token(token, session)
    if user is None:
        log_event(
            "user.email_change.fail",
            ip=ip,
            success=False,
            extra={"reason": "unknown_user"},
        )
        return EmailChangeCompleteOutcome.invalid_token, None

    try:
        _, claimed_new_email = verify_email_change_token(
            token, user.password_hash, config
        )
    except InvalidEmailChangeToken as exc:
        log_event(
            "user.email_change.fail",
            user_id=str(user.id),
            email=user.email,
            ip=ip,
            success=False,
            extra={"reason": "invalid_token", "detail": str(exc)},
        )
        return EmailChangeCompleteOutcome.invalid_token, user

    normalised_new = claimed_new_email.lower()

    # Replay defence: if the user's current email already matches the
    # token's destination, the change has happened. A second click is
    # treated as a 400 rather than silently no-op'ing.
    if user.email.lower() == normalised_new:
        log_event(
            "user.email_change.fail",
            user_id=str(user.id),
            email=user.email,
            ip=ip,
            success=False,
            extra={"reason": "already_completed"},
        )
        return EmailChangeCompleteOutcome.already_completed, user

    # Race: another user may have grabbed the destination address
    # between mint and click. The DB unique constraint would also catch
    # this on commit, but checking up-front means the route returns a
    # readable 409 instead of a 500.
    collision = session.exec(
        select(User).where(User.email == normalised_new)
    ).first()
    if collision is not None and collision.id != user.id:
        log_event(
            "user.email_change.fail",
            user_id=str(user.id),
            email=user.email,
            ip=ip,
            success=False,
            extra={"reason": "conflict", "new_email": normalised_new},
        )
        return EmailChangeCompleteOutcome.conflict, user

    old_email = user.email
    user.email = normalised_new
    # Kick every outstanding JWT — the user just proved control of a new
    # inbox; anything that authenticated under the old address should
    # have to re-login.
    user.revoked_at = datetime.now(UTC)
    session.add(user)
    try:
        session.commit()
    except IntegrityError:
        # TOCTOU: another user grabbed the destination email between
        # the pre-check SELECT above and this commit. The DB UNIQUE
        # constraint won the race; return the same 409 outcome the
        # pre-check would have produced (mirrors signup_user's pattern
        # for the same race — #275 Devin).
        session.rollback()
        log_event(
            "user.email_change.fail",
            user_id=str(user.id),
            email=old_email,
            ip=ip,
            success=False,
            extra={
                "reason": "conflict_race",
                "new_email": normalised_new,
            },
        )
        return EmailChangeCompleteOutcome.conflict, user
    session.refresh(user)

    # Courtesy notification to the OLD inbox so the previous-address
    # owner notices an unauthorised change and can ping the admin.
    safe_send(
        email_transport,
        templates.email_changed_notice(user, old_email, user.email, config),
    )

    log_event(
        "user.email_changed",
        user_id=str(user.id),
        email=user.email,
        ip=ip,
        extra={"old_email": old_email, "new_email": user.email},
    )
    return EmailChangeCompleteOutcome.changed, user
