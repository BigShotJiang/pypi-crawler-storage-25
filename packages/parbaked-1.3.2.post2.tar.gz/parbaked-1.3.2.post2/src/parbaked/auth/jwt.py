"""JWT issuance and verification.

Stateless session tokens keyed on the JWT secret from :class:`ParbakedConfig`.
"""

from __future__ import annotations

import secrets
from datetime import UTC, datetime, timedelta
from uuid import UUID

import jwt

from parbaked.config import ParbakedConfig


class InvalidTokenError(Exception):
    """Raised when a JWT can't be decoded or is expired."""


_EPHEMERAL_SECRET: str | None = None


def _resolve_secret(config: ParbakedConfig) -> str:
    """Return the JWT secret, generating an ephemeral one if unset.

    A warning-worthy fallback: when no secret is configured, sessions reset
    on every process restart. Callers should set ``PARBAKED_JWT_SECRET`` in
    production.
    """
    global _EPHEMERAL_SECRET
    if config.jwt_secret:
        return config.jwt_secret
    # In-process fallback so dev works out of the box.
    if _EPHEMERAL_SECRET is None:
        _EPHEMERAL_SECRET = secrets.token_urlsafe(32)
    return _EPHEMERAL_SECRET


def create_jwt(user_id: UUID, config: ParbakedConfig) -> str:
    """Mint a session JWT for ``user_id``.

    The claim set is exactly ``{sub, iat, exp}`` — the contract pinned in
    ``docs/data-format-guarantees.md`` (#198). Profile fields like email
    and name are intentionally NOT carried in the token; consumers that
    need them should call ``GET /auth/me`` or look the user up in the DB
    by ``sub``.
    """
    payload = {
        "sub": str(user_id),
        "iat": datetime.now(UTC),
        "exp": datetime.now(UTC) + timedelta(days=config.jwt_expiry_days),
    }
    return jwt.encode(payload, _resolve_secret(config), algorithm="HS256")


def decode_jwt(token: str, config: ParbakedConfig) -> dict:
    try:
        return jwt.decode(token, _resolve_secret(config), algorithms=["HS256"])
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError) as exc:
        raise InvalidTokenError(str(exc)) from exc
