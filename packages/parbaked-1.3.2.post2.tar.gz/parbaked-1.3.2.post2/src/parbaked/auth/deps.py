"""FastAPI dependency factory for authenticating requests.

Usage::

    from parbaked.auth import make_current_user

    current_user = make_current_user(config, get_session)

    @app.get("/me")
    def me(user: User = Depends(current_user)):
        return user
"""

from __future__ import annotations

from collections.abc import Callable
from uuid import UUID

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlmodel import Session

from parbaked.auth.jwt import InvalidTokenError, decode_jwt
from parbaked.auth.models import User, UserStatus
from parbaked.config import ParbakedConfig

_bearer = HTTPBearer(auto_error=False)


def make_current_user(
    config: ParbakedConfig, get_session: Callable[..., Session]
) -> Callable[..., User]:
    """Return a FastAPI dependency that resolves the authenticated active User.

    Raises 401 for missing/invalid tokens or deleted users.
    Raises 403 if the user exists but isn't ``active``.
    """

    def _current_user(
        creds: HTTPAuthorizationCredentials | None = Depends(_bearer),
        session: Session = Depends(get_session),
    ) -> User:
        if creds is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated"
            )

        try:
            payload = decode_jwt(creds.credentials, config)
            user_id = UUID(payload["sub"])
            issued_at = int(payload["iat"])
        except (InvalidTokenError, KeyError, ValueError, TypeError) as exc:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token"
            ) from exc

        user = session.get(User, user_id)
        if user is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, detail="User no longer exists"
            )

        # Token revocation: if the user's ``revoked_at`` is at or after this
        # token's ``iat``, the token was minted before the revocation event
        # (admin reject, password reset, future "log out everywhere" button)
        # and must be refused. SQLite returns naive datetimes — treat any
        # missing tzinfo as UTC, which is how we always write them.
        if user.revoked_at is not None:
            rev = user.revoked_at
            if rev.tzinfo is None:
                from datetime import UTC
                rev = rev.replace(tzinfo=UTC)
            if rev.timestamp() >= issued_at:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Session was revoked — sign in again.",
                )

        if user.status != UserStatus.active:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN, detail=f"Account is {user.status.value}"
            )
        return user

    return _current_user
