"""HMAC-verified webhook primitive (#273).

The inverse of ``current_user``: where the auth router takes "HTTP request
→ JWT → User", this module takes "HTTP request → HMAC signature → trust".
GitHub, Stripe, Twilio, Linear, Resend, fly.io all use this shape — every
consumer was hand-rolling the same ``hmac.compare_digest`` + replay-window
boilerplate. Here it is once.

Two pieces:

- :func:`verify_hmac` — pure function. Takes ``body``, ``signature_header_value``,
  ``secret``. Handles GitHub-style ``sha256=<hex>`` and Stripe-style
  ``t=<ts>,v1=<hex>`` headers. Returns ``True`` on match, ``False``
  otherwise. Constant-time via :func:`hmac.compare_digest`.

- :func:`webhook` — FastAPI route decorator. Reads the secret from the
  named env var (boot-time crash if unset — better than 401-on-every-request),
  reads the body, verifies the signature, returns 401 on mismatch, otherwise
  invokes the wrapped handler.

Conventional discovery: ``routes/webhooks/github.py`` mounts at
``/webhooks/github`` — that's the generic ``_path_to_prefix`` behaviour,
no special-casing. The ``routes/webhooks/`` prefix is convention only, to
keep the recognisable shape distinct from user routes; nothing here cares
where the route file lives.

No external deps — stdlib ``hmac`` + ``hashlib``. Works in both sync and
async handlers (the decorator awaits the body but invokes the wrapper via
the appropriate path).
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import inspect
import logging
import os
import time
from collections.abc import Callable
from dataclasses import dataclass
from functools import wraps
from typing import Any

from fastapi import HTTPException, Request

logger = logging.getLogger("parbaked.webhook")

# Body of the 401 response. Constant so consumers writing integration
# tests can match against it without re-deriving the string.
_INVALID_SIGNATURE_DETAIL = "invalid signature"


@dataclass(frozen=True)
class WebhookConfig:
    """Config bundle for a webhook endpoint.

    Held as a frozen dataclass rather than kwargs so callers introspecting
    a decorated handler (tests, future admin tooling) can read back the
    declared shape — ``handler.__parbaked_webhook__`` is set to a
    :class:`WebhookConfig` instance on every decorated route.

    Attributes:
        secret_env: Name of the env var holding the shared secret. The
            secret is read at decoration time, so a missing env var
            crashes boot — preferable to a silent 401 on every request.
        signature_header: Header name carrying the signature. e.g.
            ``"X-Hub-Signature-256"`` (GitHub),
            ``"Stripe-Signature"`` (Stripe).
        algorithm: ``hashlib`` algorithm name. ``"sha256"`` is the only
            one most providers use; ``"sha1"`` exists for legacy GitHub
            but is not recommended.
        max_age_seconds: Replay window. ``0`` disables the check.
            Ignored unless ``timestamp_header`` is set OR the signature
            header itself carries a ``t=`` field (Stripe).
        timestamp_header: Optional separate header carrying a unix
            timestamp. Twilio uses ``X-Twilio-Request-Timestamp``;
            Stripe inlines it in the signature header so this stays
            ``None`` for Stripe.
    """

    secret_env: str
    signature_header: str
    algorithm: str = "sha256"
    max_age_seconds: int = 300
    timestamp_header: str | None = None


def _parse_signature_header(
    header_value: str,
) -> tuple[str | None, str | None]:
    """Parse a webhook signature header into ``(signature_hex, timestamp)``.

    Handles three header shapes:

    1. GitHub style: ``sha256=<hex>`` → ``(<hex>, None)``.
    2. Stripe style: ``t=<ts>,v1=<hex>`` → ``(<hex>, <ts>)``. Multiple
       ``v1=`` entries are tolerated; the first match wins.
    3. Bare hex: ``<hex>`` → ``(<hex>, None)``. Some providers (Twilio
       on the legacy auth path, custom internal webhooks) ship the
       signature without a prefix.

    Returns ``(None, None)`` on a malformed header so the caller's
    ``False`` path stays the same as a wrong-signature reject — we don't
    raise here because the decorator translates both to 401.
    """
    if not header_value:
        return None, None
    value = header_value.strip()
    # Stripe-style comma-separated key=value list. Detect by the comma:
    # GitHub's ``sha256=<hex>`` has no comma.
    if "," in value:
        ts: str | None = None
        sig: str | None = None
        for part in value.split(","):
            part = part.strip()
            if "=" not in part:
                continue
            key, _, val = part.partition("=")
            key = key.strip()
            val = val.strip()
            if key == "t" and ts is None:
                ts = val
            elif key in ("v1", "sha256") and sig is None:
                sig = val
        return sig, ts
    # GitHub-style ``algo=hex`` (also handles ``sha1=hex``).
    if "=" in value:
        _, _, sig = value.partition("=")
        return sig.strip() or None, None
    # Bare hex.
    return value, None


def verify_hmac(
    body: bytes,
    signature_header_value: str,
    secret: str,
    *,
    algorithm: str = "sha256",
    timestamp_header_value: str | None = None,
    max_age_seconds: int = 300,
) -> bool:
    """Constant-time HMAC verification.

    Returns ``True`` on a valid signature, ``False`` otherwise. Malformed
    inputs (missing header, unparseable signature) return ``False`` too —
    the caller only needs the boolean to drive a 401/200 split. The one
    exception is an unsupported algorithm name, which raises ``ValueError``
    at decoration / call time so a typo doesn't silently let every request
    through.

    For Stripe-style headers carrying ``t=<ts>`` inline, the timestamp is
    pulled from the signature header itself and ``timestamp_header_value``
    can be left ``None``. For Twilio-style separate-header timestamps,
    pass the timestamp header value via ``timestamp_header_value``.

    The signed-payload shape:

    - GitHub: ``HMAC(secret, body)``.
    - Stripe: ``HMAC(secret, f"{ts}.{body}")`` — the timestamp from the
      header is prepended to the body, dot-separated.

    We auto-detect Stripe shape by the presence of a ``t=`` field in the
    signature header. That's the only signal the wire format gives us;
    GitHub never ships a comma.
    """
    if not signature_header_value:
        return False
    if not isinstance(body, bytes):
        # Defensive: a caller passing ``str`` would still verify if we
        # encoded it here, but silently re-encoding hides bugs in the
        # caller's request-body handling. Be explicit.
        raise TypeError(
            f"verify_hmac body must be bytes, got {type(body).__name__}"
        )

    try:
        digestmod = getattr(hashlib, algorithm)
    except AttributeError as exc:
        raise ValueError(
            f"unsupported HMAC algorithm: {algorithm!r}"
        ) from exc

    sig_hex, inline_ts = _parse_signature_header(signature_header_value)
    if sig_hex is None:
        return False

    # Pick the timestamp to use for the replay-window check + the signed
    # payload. Stripe-style inline ``t=`` wins; otherwise fall back to
    # the separately-passed header value.
    ts_value = inline_ts if inline_ts is not None else timestamp_header_value

    # If the header carries an inline timestamp (Stripe), we sign
    # ``f"{ts}.{body}"``. If the timestamp came via a separate header
    # (Twilio), we still only sign the body — Twilio's spec signs the
    # URL, not a timestamp-prefixed body, and supporting that is out of
    # scope here. For now the rule is simple: inline ``t=`` ⇒ prepend.
    signed_payload = (
        f"{inline_ts}.".encode() + body if inline_ts is not None else body
    )

    expected = hmac.new(
        secret.encode("utf-8"), signed_payload, digestmod
    ).hexdigest()

    if not hmac.compare_digest(expected, sig_hex):
        return False

    # Replay-window check. ``0`` disables. We only enforce when we
    # actually have a timestamp to check against — missing-timestamp on
    # a Stripe-style flow is itself a sign-mismatch (header was malformed),
    # but for non-Stripe flows there may be no timestamp at all, and
    # that's the caller's choice.
    if max_age_seconds and ts_value is not None:
        try:
            ts_int = int(ts_value)
        except ValueError:
            return False
        now = int(time.time())
        if abs(now - ts_int) > max_age_seconds:
            return False

    return True


def webhook(
    secret_env: str,
    signature_header: str,
    *,
    algorithm: str = "sha256",
    max_age_seconds: int = 300,
    timestamp_header: str | None = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Route decorator for HMAC-verified webhook endpoints.

    Reads the shared secret from ``os.environ[secret_env]`` at decoration
    time. A missing env var raises :class:`RuntimeError` immediately —
    the boot-time crash is the loud-fail signal; the silent-401-forever
    failure mode is much worse to debug.

    On every request, the decorator:

    1. Reads the raw body via ``await request.body()``.
    2. Pulls the signature header. Missing → 401.
    3. Calls :func:`verify_hmac`. ``False`` → 401.
    4. On match, invokes the wrapped handler with the original args.

    The 401 response body is ``{"detail": "invalid signature"}``. We
    deliberately don't include a more specific reason (timestamp out of
    window vs digest mismatch) — that's information an attacker can use
    to probe whether their replay is timely or their secret is close.

    Usage::

        from fastapi import APIRouter, Request
        from parbaked import webhook

        router = APIRouter()

        @router.post("")
        @webhook(
            secret_env="GITHUB_WEBHOOK_SECRET",
            signature_header="X-Hub-Signature-256",
        )
        async def github_webhook(request: Request):
            payload = await request.json()
            return {"received": payload["zen"]}

    The decorator works on both ``async def`` and ``def`` handlers. The
    body read is always async (``request.body()`` is async-only in
    Starlette); the wrapper itself is always ``async def`` because of
    that. FastAPI handles dispatch correctly — a sync wrapper around an
    async handler would block the event loop.

    The handler must accept ``request: Request`` as one of its
    parameters (positional or keyword); the decorator finds it by type
    annotation, falling back to a parameter literally named ``request``.
    Without a ``Request``, the decorator can't read the body.
    """
    # Validate the algorithm at decoration time so a typo crashes boot
    # rather than every request.
    try:
        getattr(hashlib, algorithm)
    except AttributeError as exc:
        raise ValueError(
            f"@webhook: unsupported HMAC algorithm {algorithm!r}"
        ) from exc

    if not os.environ.get(secret_env):
        raise RuntimeError(
            f"@webhook: required env var {secret_env!r} is not set "
            f"(or is empty). "
            f"Set it before importing the route file — otherwise every "
            f"request would 401 silently."
        )

    cfg = WebhookConfig(
        secret_env=secret_env,
        signature_header=signature_header,
        algorithm=algorithm,
        max_age_seconds=max_age_seconds,
        timestamp_header=timestamp_header,
    )

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        @wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            request = _find_request(args, kwargs)
            if request is None:
                # Boot-time misuse: decorator can't do its job without
                # access to the request body + headers. Surface this as
                # a 500 with a precise message — the route is broken.
                raise RuntimeError(
                    f"@webhook: handler {func.__name__!r} must accept a "
                    f"fastapi.Request parameter so the decorator can "
                    f"read the body and signature header."
                )

            # Re-read the secret on every call. Yes, the boot-time check
            # already proved it exists; reading here covers the edge
            # case where the env was unset between boot and request
            # (rare, but cheap to defend against). os.environ access is
            # a dict lookup.
            secret = os.environ.get(cfg.secret_env)
            if not secret:
                raise HTTPException(
                    status_code=401, detail=_INVALID_SIGNATURE_DETAIL
                )

            sig = request.headers.get(cfg.signature_header)
            if not sig:
                raise HTTPException(
                    status_code=401, detail=_INVALID_SIGNATURE_DETAIL
                )

            ts_value: str | None = None
            if cfg.timestamp_header:
                ts_value = request.headers.get(cfg.timestamp_header)

            body = await request.body()
            ok = verify_hmac(
                body,
                sig,
                secret,
                algorithm=cfg.algorithm,
                timestamp_header_value=ts_value,
                max_age_seconds=cfg.max_age_seconds,
            )
            if not ok:
                raise HTTPException(
                    status_code=401, detail=_INVALID_SIGNATURE_DETAIL
                )

            # Dispatch to the wrapped handler. Support both async and
            # sync handlers — sync ones are run in the same loop via
            # ``asyncio.to_thread`` so a blocking body parse doesn't
            # stall the event loop.
            if inspect.iscoroutinefunction(func):
                return await func(*args, **kwargs)
            return await asyncio.to_thread(func, *args, **kwargs)

        # Attach the config to the wrapper so tests / future tooling can
        # introspect the declared webhook shape.
        wrapper.__parbaked_webhook__ = cfg  # type: ignore[attr-defined]
        return wrapper

    return decorator


def _find_request(args: tuple[Any, ...], kwargs: dict[str, Any]) -> Request | None:
    """Locate the :class:`fastapi.Request` in the call args.

    FastAPI injects ``Request`` by type annotation, so the parameter can
    be named anything. We check (1) every positional arg, (2) every kwarg
    by value, and as a last resort (3) ``kwargs["request"]`` even if it
    isn't a ``Request`` instance (e.g. mocked in a test).
    """
    for arg in args:
        if isinstance(arg, Request):
            return arg
    for val in kwargs.values():
        if isinstance(val, Request):
            return val
    return kwargs.get("request")
