"""``parbaked completions <shell>`` subcommand.

Prints the bash / zsh / fish / powershell completion script for parbaked
to stdout. Mirrors the ``docker completion``, ``gh completion``, and
``fly completion`` convention — a named verb is the discoverable
surface, even though ``--show-completion`` (registered by typer when
``add_completion=True``) emits the same script under the hood.

The auto-complete machinery itself works fine without the named verb
(typer ships ``--install-completion`` / ``--show-completion`` for free);
this subcommand exists because users grep for ``$tool completion`` /
``$tool completions`` in install-guide territory and we want them to
land somewhere instead of bouncing off "No such command 'completions'"
(#318 partial — companion to #376).

Implementation note: we shell out to typer's own
``get_completion_script`` so this stays one script generator, not two.
The shells we accept are the ones typer's renderer supports today —
bash, zsh, fish, powershell. Anything else exits 1 with a friendly
error listing the valid choices.
"""

from __future__ import annotations

from typing import Annotated

import typer
from typer.completion import get_completion_script

from parbaked.cli._console import error

# Shells typer's bundled completion renderer supports. Kept in sync
# with ``typer.completion`` — if a future typer release adds e.g.
# ``nushell`` we can grow this set without changing the call site.
# ``pwsh`` is intentionally omitted: typer treats it as an alias for
# ``powershell`` and exposing both would just confuse the help text.
_VALID_SHELLS = ("bash", "zsh", "fish", "powershell")


def completions(
    shell: Annotated[
        str,
        typer.Argument(
            help=(
                "Shell to generate completion for: "
                "bash, zsh, fish, powershell."
            ),
        ),
    ],
) -> None:
    """Print the shell completion script for the given shell.

    Pipe into your shell's completion directory::

        parbaked completions zsh > ~/.zsh/completions/_parbaked
        parbaked completions bash > /etc/bash_completion.d/parbaked
        parbaked completions fish > ~/.config/fish/completions/parbaked.fish

    The script enables tab-completion for every ``parbaked`` subcommand,
    option, and argument. After installing, restart your shell (or
    ``source`` the file) and tab-completion will discover commands as
    the CLI grows.

    Equivalent to ``parbaked --show-completion <shell>`` — both wrap the
    same typer engine. The named subcommand exists because that's the
    convention every Unix CLI (docker, gh, fly, kubectl, …) ships.
    """
    if shell not in _VALID_SHELLS:
        error(
            f"Unsupported shell: {shell!r}. "
            f"Choose one of: {', '.join(_VALID_SHELLS)}."
        )
        raise typer.Exit(1)

    # typer derives the completion env-var name from the prog name
    # (``parbaked`` → ``_PARBAKED_COMPLETE``); we hard-code "parbaked"
    # here so the script is identical regardless of how the CLI was
    # invoked (e.g. ``python -m parbaked.cli.main``, where ``info_name``
    # would otherwise leak ``main`` into the generated script).
    script = get_completion_script(
        prog_name="parbaked",
        complete_var="_PARBAKED_COMPLETE",
        shell=shell,
    )
    typer.echo(script)
