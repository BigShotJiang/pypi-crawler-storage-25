"""parbaked CLI.

Commands:

- ``parbaked new <name>`` — scaffold a kernel-runtime PoC (parbaked.toml +
  routes/ + models.py + vanilla-JS web/index.html, ready for ``parbaked dev``).
- ``parbaked dev`` / ``tunnel`` / ``deploy`` / ``logs`` /
  ``push-secrets`` — dev and deploy entry points.
- ``parbaked status`` — print a one-screen summary of the current project.
- ``parbaked version`` — print the installed version.
"""

from __future__ import annotations

import contextlib
import os
import re
import shutil
import sys
from pathlib import Path

import typer

from parbaked import __version__
from parbaked.cli import ops
from parbaked.cli._console import console, error, info, set_verbosity, success, warn
from parbaked.cli.admin import admin_app
from parbaked.cli.completions import _VALID_SHELLS
from parbaked.cli.completions import completions as _completions
from parbaked.cli.email import email_app
from parbaked.cli.users import users_app
from parbaked.operations.scaffold import (
    _starter_templates_dir,
    scaffold_project,
    scaffold_template_manifest,
)


def _ensure_utf8_stdout() -> None:
    """Reconfigure stdout/stderr to UTF-8 on legacy Windows consoles.

    The parbaked CLI prints Unicode glyphs (``✓``, ``✗``, ``⚠``, ``→``)
    throughout its output. On Windows consoles that default to
    ``cp1252`` these characters cause ``UnicodeEncodeError`` at write
    time. Calling ``reconfigure(encoding="utf-8", errors="replace")``
    on Python 3.7+ flips the stream to UTF-8 in place, fixes the crash,
    and is a no-op on macOS/Linux where stdout is already UTF-8.

    Wrapped in a defensive try/except because ``reconfigure`` is only
    available on real ``TextIOWrapper`` streams — if stdout has been
    redirected to e.g. a ``StringIO`` (in tests) the attribute is
    missing, and we simply leave the stream as-is.

    See issue #192.
    """
    for stream in (sys.stdout, sys.stderr):
        encoding = (getattr(stream, "encoding", None) or "").lower()
        if encoding.replace("-", "") in {"utf8", ""}:
            continue
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is None:
            continue
        # If reconfigure raises (rare — e.g. a detached console), give up
        # silently rather than crash the CLI before it has even started.
        with contextlib.suppress(OSError, ValueError):
            reconfigure(encoding="utf-8", errors="replace")


_ensure_utf8_stdout()


# ``context_settings={"help_option_names": [...]}`` makes ``-h`` an alias
# for ``--help`` at every level — the de-facto Unix convention every dev
# tool a vibe-coder reaches for already honours (git, docker, fly, uv,
# gh, ruff). Typer/click ships this for free; we just had to enable it
# (#318 partial).
#
# ``add_completion=False`` because we replace typer's built-in
# ``--install-completion`` / ``--show-completion`` callbacks with our
# own (#392): typer's detection relies on ``shellingham``, which on
# many setups can't see the parent shell (``$SHELL=/bin/zsh`` is set
# but the process tree doesn't reveal it) and falls back to ``None``
# — so the flags would print the infamous ``Shell None is not
# supported.`` error from #392. Our callbacks read ``$SHELL`` directly,
# basename it (``/bin/zsh`` → ``zsh``), and map to the canonical
# ``bash`` / ``zsh`` / ``fish`` / ``powershell`` keys that typer's
# script generator accepts. On unrecognised / missing ``$SHELL`` we
# print a friendly error pointing at ``parbaked completions <shell>``
# (the dedicated subcommand added in #381) rather than leaking
# typer's internal ``None``.
_HELP_OPTION_NAMES = ["-h", "--help"]

app = typer.Typer(
    name="parbaked",
    help="Signup + admin approval + fly.io deploy for indie FastAPI PoCs. Agent-friendly.",
    add_completion=False,
    no_args_is_help=True,
    context_settings={"help_option_names": _HELP_OPTION_NAMES},
)


# Shell-basename mapping (#392). ``$SHELL`` on macOS / Linux is a full
# path like ``/bin/zsh`` or ``/usr/local/bin/fish``; typer's script
# generator only accepts the bare names. ``pwsh`` (PowerShell Core's
# Linux/macOS binary) is deliberately omitted: typer's
# ``install_powershell`` shells out to a literal ``[shell, ...]``
# subprocess, so mapping ``pwsh`` → ``"powershell"`` would crash with
# ``FileNotFoundError`` on boxes where the binary is named ``pwsh``
# (Devin caught the regression — #392, PR #399). Users running
# PowerShell Core can still invoke
# ``parbaked completions powershell > $PROFILE`` explicitly.
_SHELL_BASENAME_TO_CANONICAL: dict[str, str] = {
    "bash": "bash",
    "zsh": "zsh",
    "fish": "fish",
    "powershell": "powershell",
}


def _detect_shell_from_env() -> str | None:
    """Return the canonical shell name parsed from ``$SHELL``, or ``None``.

    ``$SHELL`` on macOS / Linux is the user's login shell as a full
    path (e.g. ``/bin/zsh``, ``/usr/local/bin/fish``). We take the
    basename and map it through ``_SHELL_BASENAME_TO_CANONICAL`` — so
    ``/bin/zsh`` becomes ``zsh`` (the key typer's script generator
    accepts). Returns ``None`` when ``$SHELL`` is unset, empty, or
    points at a shell we don't generate scripts for (e.g. ``csh``,
    ``tcsh``, ``ksh``) so the caller can print a friendly error
    instead of leaking ``None`` into the output the way typer's
    built-in detection did in #392.
    """
    raw = os.environ.get("SHELL", "").strip()
    if not raw:
        return None
    basename = os.path.basename(raw).lower()
    return _SHELL_BASENAME_TO_CANONICAL.get(basename)


def _shell_detection_error() -> str:
    """Friendly error for ``--install-completion`` / ``--show-completion``
    when we can't auto-detect the user's shell from ``$SHELL`` (#392).

    Points the user at the dedicated ``parbaked completions <shell>``
    subcommand added in #381 — which takes the shell name explicitly
    and so works regardless of environment.
    """
    return (
        "Cannot auto-detect your shell from $SHELL. "
        "Run `parbaked completions <shell>` with your shell name "
        f"({', '.join(_VALID_SHELLS)}) — see `parbaked completions --help`."
    )


def _show_completion_callback(value: bool) -> None:
    """Print the shell completion script for the user's current shell.

    Replaces typer's built-in ``show_callback`` (#392). Reads
    ``$SHELL`` via :func:`_detect_shell_from_env` instead of relying
    on ``shellingham`` (which silently returns ``None`` in many
    sandboxed / nested-shell environments and produces the
    ``Shell  not supported`` error from the bug report).

    Delegates the actual script generation to typer's
    ``get_completion_script`` so the output is byte-for-byte
    identical to ``parbaked completions <shell>``.
    """
    if not value:
        return
    shell = _detect_shell_from_env()
    if shell is None:
        error(_shell_detection_error())
        raise typer.Exit(1)
    from typer.completion import get_completion_script

    script = get_completion_script(
        prog_name="parbaked",
        complete_var="_PARBAKED_COMPLETE",
        shell=shell,
    )
    typer.echo(script)
    raise typer.Exit(0)


def _install_completion_callback(value: bool) -> None:
    """Install the shell completion script for the user's current shell.

    Replaces typer's built-in ``install_callback`` (#392). Same
    detection path as :func:`_show_completion_callback`: read
    ``$SHELL``, basename, canonicalise. On unrecognised shell we
    print a friendly error pointing at
    ``parbaked completions <shell>`` rather than leaking typer's
    ``Shell None is not supported`` error.

    The actual install (write completion script + append source line
    to the user's rc-file) is delegated to typer's
    ``_completion_shared.install`` so we share install logic with the
    upstream — only the shell-detection layer differs.
    """
    if not value:
        return
    shell = _detect_shell_from_env()
    if shell is None:
        error(_shell_detection_error())
        raise typer.Exit(1)
    # typer's ``install()`` knows where each shell's rc file lives and
    # how to source the completion script. We pass the canonicalised
    # shell name so its internal dispatch ("if shell == 'bash': …")
    # works.
    from typer._completion_shared import install

    installed_shell, installed_path = install(
        shell=shell,
        prog_name="parbaked",
        complete_var="_PARBAKED_COMPLETE",
    )
    typer.secho(
        f"{installed_shell} completion installed in {installed_path}",
        fg=typer.colors.GREEN,
    )
    typer.echo("Completion will take effect once you restart the terminal")
    raise typer.Exit(0)


def _version_callback(value: bool) -> None:
    """Print the parbaked version and exit when ``--version`` / ``-V`` is passed.

    Wired as an eager typer ``Option`` callback so it fires before any
    subcommand parsing — ``parbaked --version`` shouldn't require a
    project on disk, a DB, or any other context the subcommands assume.

    The existing ``parbaked version`` subcommand stays (it's free to grow
    extra context like python version / install path later); this flag
    just prints the bare version string for parity with ``git``,
    ``python``, ``uv``, ``ruff``, etc. (#317).
    """
    if value:
        typer.echo(f"parbaked {__version__}")
        raise typer.Exit()


@app.callback()
def _root_callback(
    version: bool = typer.Option(  # noqa: ARG001 — consumed by the callback
        None,
        "--version",
        "-V",
        callback=_version_callback,
        is_eager=True,
        help="Show the parbaked version and exit.",
    ),
    install_completion: bool = typer.Option(  # noqa: ARG001 — eager callback
        False,
        "--install-completion",
        callback=_install_completion_callback,
        is_eager=True,
        help=(
            "Install shell tab-completion for parbaked. Auto-detects the "
            "shell from $SHELL (bash, zsh, fish, powershell). If "
            "detection fails, use `parbaked completions <shell>` instead."
        ),
    ),
    show_completion: bool = typer.Option(  # noqa: ARG001 — eager callback
        False,
        "--show-completion",
        callback=_show_completion_callback,
        is_eager=True,
        help=(
            "Print the shell completion script to stdout. Auto-detects "
            "the shell from $SHELL (bash, zsh, fish, powershell). If "
            "detection fails, use `parbaked completions <shell>` instead."
        ),
    ),
    quiet: bool = typer.Option(
        False,
        "--quiet",
        "-q",
        help=(
            "Suppress INFO-level CLI output; only WARN/ERROR survive. "
            "On long-running commands (`dev`, `tunnel`, `logs`) also "
            "skips the boot banner and passes `--log-level=warning` to "
            "the uvicorn child. Mutually exclusive with --verbose."
        ),
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help=(
            "Emit DEBUG-level CLI output for diagnosing obscure issues. "
            "On `dev` also passes `--log-level=debug` to uvicorn and "
            "bumps the `parbaked.runtime` logger to DEBUG. Mutually "
            "exclusive with --quiet."
        ),
    ),
) -> None:
    """Top-level options for ``parbaked``.

    Registers ``--version`` / ``-V`` (#317) and the
    ``--quiet`` / ``-q`` / ``--verbose`` / ``-v`` verbosity pair
    (#318 partial) as root-level flags. Subcommands are dispatched
    as before — the verbosity sentinel lives on a module-level
    singleton in ``parbaked.cli._console`` so individual subcommand
    signatures don't need to grow a parameter.
    """
    # Mutually exclusive — ``parbaked -q -v anything`` is a usage error.
    # Convention every dev tool that ships both flags honours (git,
    # docker, fly, uv) — the operator can't simultaneously want less and
    # more output, and silently picking one would mask the typo.
    if quiet and verbose:
        raise typer.BadParameter(
            "--quiet/-q and --verbose/-v are mutually exclusive."
        )
    if quiet:
        set_verbosity("quiet")
    elif verbose:
        set_verbosity("verbose")
    else:
        # Explicit reset to ``"normal"`` rather than "leave whatever the
        # last call set". The verbosity sentinel lives at module scope
        # so a long-running Python process (tests, REPL, embedded
        # ``app()`` invocations) that ran ``parbaked -q ...`` first and
        # ``parbaked ...`` second would otherwise carry the quiet state
        # forward into the second call. Pre-#318 behaviour was "every
        # invocation prints normally" — preserve that exactly.
        set_verbosity("normal")


# --------------------------------------------------------------------- helpers
# (defined before commands so the decorated functions below can reference them
# without forward-declaration acrobatics)
#
# The template-walk lives in ``parbaked.operations.scaffold.scaffold_project``
# (#228) — shared between this command and the MCP ``tool_scaffold`` entry
# point. ``_starter_templates_dir`` is re-exported above for the precondition
# check in :func:`new`.


def _bootstrap_project_venv(target: Path) -> None:
    """Run ``uv sync`` in the freshly-scaffolded project so the first
    ``parbaked dev`` is instant and pins exactly the parbaked the CLI
    came from (via the ``parbaked=={{PARBAKED_VERSION}}`` line written
    into ``pyproject.toml``).

    Also runs ``uv lock`` to materialise ``uv.lock`` next to
    ``pyproject.toml``. The generated Dockerfile does
    ``uv sync --frozen`` against the lockfile, so projects need
    to *ship* with one — otherwise the first ``parbaked deploy`` would
    silently float versions and reintroduce the "deploy broke on a
    Tuesday because a transitive dep cut a release" footgun.

    Silent when ``uv`` isn't on PATH — the user clearly installed
    parbaked some other way; we surface a hint they can run later.
    """
    import subprocess as _sp

    if shutil.which("uv") is None:
        info(
            "ℹ uv not found on PATH — skipping ``uv sync``. "
            "Run ``uv sync`` (or ``pip install -e .``) "
            f"in {target} before ``parbaked dev``."
        )
        return
    info("Installing project dependencies (uv sync)…")
    rc = _sp.run(["uv", "sync"], cwd=target, check=False).returncode
    if rc != 0:
        # Non-fatal — the scaffold is still on disk, the user can rerun.
        warn(
            "uv sync failed. Scaffold is in place; "
            f"run ``uv sync`` manually in {target} before ``parbaked dev``."
        )
        return
    # Belt-and-braces: ``uv sync`` already writes uv.lock on a fresh
    # project, but explicit ``uv lock`` makes the contract obvious and
    # is a no-op when the lock is already in sync. Failure here is
    # non-fatal — the project still works, just without a pinned lock.
    if not (target / "uv.lock").exists():
        _sp.run(["uv", "lock"], cwd=target, check=False)
    success("dependencies installed")


# Conservative-safe-everywhere subset . Names must work as:
#  - a directory name on every supported FS
#  - a fly.io app name (lowercase, hyphen-separated, leading letter,
#    no trailing hyphen — fly's exact rules)
#  - a shell argument that is NEVER parseable as a flag (no leading "-")
#  - a Python model name fragment via MCP scaffolds (lowercase tokens)
#  - a Docker image tag fragment (no dots, no spaces, no uppercase)
_APP_NAME_RE = re.compile(r"[a-z][a-z0-9-]*[a-z0-9]")


def _validate_app_name(name: str) -> None:
    """Reject names that would break fly / Dockerfile / shell tooling .

    The pre-v1.3 check only blocked path traversal (``..``, ``/``, leading
    ``.``) which let through names like ``"with space"`` (breaks the
    Dockerfile + shell tooling) and ``"-leadinghyphen"`` (parsed as a
    flag by ``cd``, ``git``, ``fly``). We tighten to the
    conservative-safe-everywhere subset: lowercase, leading letter,
    letters/digits/hyphens only, no trailing hyphen. Length must be
    ≥ 2 (the regex requires both a leading letter AND a trailing
    letter/digit) so single-character names also get rejected — fly
    refuses them anyway.

    Also re-used by the MCP ``tool_scaffold`` path so the same rules
    apply whether a human or an agent runs the scaffold.
    """
    if not name:
        raise typer.BadParameter("Project name required")
    if not _APP_NAME_RE.fullmatch(name):
        raise typer.BadParameter(
            "Project name must be lowercase, start with a letter, "
            "use only letters/digits/hyphens, no trailing hyphen."
        )


# Top-level commands are registered in user-journey order :
# scaffold → run → onboard → ship → operate → wind down. Typer renders
# `--help` in definition order, so this order is what users see.


@app.command()
def new(
    name: str = typer.Argument(..., help="Project name (becomes the directory)"),
    parent: Path = typer.Option(
        Path("."), "--parent", "-p", help="Parent directory for the new project"
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help=(
            "Overwrite scaffold-owned files in an existing parbaked "
            "scaffold (parbaked.toml + the rest of the template manifest). "
            "Files the user added that aren't in the template manifest "
            "(notes, scratch dirs, custom modules) are preserved — "
            "``--force`` is non-destructive at the directory level. "
            "Only honoured when the target contains a ``parbaked.toml`` "
            "sentinel; refused on directories with non-scaffold files."
        ),
    ),
    deploy: bool = typer.Option(
        False,
        "--deploy",
        help=(
            "After scaffolding, walk through the first-run fly.io onboarding "
            "wizard: install flyctl, sign in, claim the app, push secrets, "
            "deploy. Use ``parbaked init`` from an existing project."
        ),
    ),
    skip_onboarding: bool = typer.Option(
        False,
        "--skip-onboarding",
        help=(
            "Requires ``--deploy``. Scaffolds the project but skips the "
            "deploy wizard. Passing this without ``--deploy`` is a usage "
            "error and exits non-zero."
        ),
    ),
    open_browser: bool = typer.Option(
        False,
        "--open",
        help="With ``--deploy``: open the live URL when deploy completes.",
    ),
    no_install: bool = typer.Option(
        False,
        "--no-install",
        help=(
            "Don't run ``uv sync`` after scaffolding. Useful for offline "
            "scaffolds or CI scenarios where you'll install separately."
        ),
    ),
) -> None:
    """Scaffold a complete runnable PoC under PARENT/NAME.

    Creates a kernel-runtime project with ``parbaked.toml``, ``routes/``,
    ``models.py``, a vanilla-JS ``web/index.html`` placeholder, and
    ``pyproject.toml``. After running:

        cd NAME && parbaked dev

    working signup + admin approval at http://localhost:8000.
    """
    _validate_app_name(name)
    # ``--skip-onboarding`` only makes sense in tandem with ``--deploy`` —
    # without the deploy wizard there's nothing to skip. Typer can't express
    # this conditional in its option declarations, so we validate at command
    # entry. Without this guard, ``parbaked new myapp --skip-onboarding``
    # silently behaved as if the flag weren't there (#178/3).
    if skip_onboarding and not deploy:
        raise typer.BadParameter(
            "--skip-onboarding requires --deploy (the flag suppresses the "
            "post-scaffold deploy wizard; without --deploy there's no wizard "
            "to skip)."
        )
    target = (parent / name).resolve()
    # Sentinel-or-force gating (#389), mirroring eject's #290 model;
    # extended in #402 to be non-destructive at the directory level.
    #
    # Three accepted shapes for the target directory:
    #
    #   1. target doesn't exist OR exists-but-empty → proceed without any
    #      destructive call (scaffold writes directly into the path).
    #   2. target exists, has files, AND contains a ``parbaked.toml``
    #      sentinel → the path is owned by a previous parbaked scaffold.
    #      ``--force`` overwrites the scaffold-owned files in place
    #      (parbaked.toml, models.py, hooks.py, routes/_example.py,
    #      web/index.html, pyproject.toml, README.md, .gitignore,
    #      .env.example) and leaves everything else alone. Files the
    #      user has added — ``my-notes.md``, ``scratch/``, custom
    #      modules — survive (#402).
    #   3. target exists, has files, but no ``parbaked.toml`` → refuse
    #      loudly regardless of ``--force``. The path holds the user's
    #      own work, not a prior scaffold (#389 guard).
    #
    # ``--force`` without the sentinel is the wrong-tool moment from
    # #389: the operator typoed the project name into a directory that
    # already had work in it. Refuse and point them at manual cleanup.
    #
    # ``--force`` with the sentinel is the wrong-tool moment from #402:
    # the operator wants to refresh the scaffold but has been editing
    # files in the project. The #396 fix kept ``shutil.rmtree(target)``
    # for this branch, which wiped any user-added files outside the
    # template manifest. #402 drops the rmtree entirely — per-file
    # render means anything outside the manifest survives. The operator
    # can still ``rm -rf <dir>`` manually if they want a clean slate;
    # ``--force`` no longer does the rm for them.
    if target.exists():
        if not target.is_dir():
            error(f"{target} exists but is not a directory.")
            raise typer.Exit(1)
        is_empty = next(target.iterdir(), None) is None
        if not is_empty:
            sentinel_present = (target / "parbaked.toml").is_file()
            if not force and sentinel_present:
                # Prior scaffold present — ``--force`` is a real recovery
                # path, so tell the user about it.
                error(f"{target} already exists. Use --force to overwrite.")
                raise typer.Exit(1)
            if not force:
                # Non-scaffold user files — pointing the user at ``--force``
                # would send them into a retry loop, because the
                # sentinel-or-force check below also refuses. Tell them
                # the correct recovery directly.
                error(
                    f"{target} already exists and is not a parbaked scaffold "
                    "(no parbaked.toml). Delete it manually if you're sure, "
                    "or pick a different --parent / app name."
                )
                raise typer.Exit(1)
            if not sentinel_present:
                # ``--force`` was set, but the directory holds non-scaffold
                # files. Refuse rather than overwrite (#389).
                error(
                    f"Refusing to --force on {target}: contains files that "
                    "aren't from a parbaked scaffold (no parbaked.toml). "
                    "Delete it manually if you're sure."
                )
                raise typer.Exit(1)
            # ``--force`` + sentinel present + non-empty: this is the
            # #402 case. Print the list of scaffold-owned files we're
            # about to overwrite — gives the operator a chance to
            # ctrl-c before models.py / hooks.py get reset, while
            # reassuring them that user-added files (notes, scratch
            # dirs, custom modules) won't be touched. The list comes
            # from the template manifest — same source the per-file
            # render below uses, so the INFO line and the actual
            # overwrites can't drift.
            manifest_paths = [
                str(p) for p in scaffold_template_manifest()
                if (target / p).exists()
            ]
            if manifest_paths:
                info(
                    f"Overwriting scaffold files in {target}: "
                    + ", ".join(sorted(manifest_paths))
                )

    src = _starter_templates_dir()
    if not src.exists():
        error(f"Starter templates not found at {src}. parbaked install is broken?")
        raise typer.Exit(1)

    # No rmtree (#402). The per-file render in ``scaffold_project``
    # below overwrites scaffold-owned files in place and never touches
    # anything outside the template manifest, so user-added files
    # survive ``--force`` against a prior scaffold. Empty / non-existent
    # targets just need the directory; ``mkdir(parents=True,
    # exist_ok=True)`` is idempotent and non-destructive.
    target.mkdir(parents=True, exist_ok=True)

    # Template walk (#188 item 3, #228) — shared with mcp.tool_scaffold via
    # ``parbaked.operations.scaffold.scaffold_project``.
    scaffold_project(target, name)

    success(f"created {target}")

    if not no_install:
        _bootstrap_project_venv(target)

    if deploy and not skip_onboarding:
        # Hand off to the onboarding wizard from inside the new project
        # dir so .parbaked/deploy.json + the generated build files land
        # next to parbaked.toml.
        import os as _os

        from parbaked.cli.deploy_wizard import pick_fly_app_name, run_wizard
        prev_cwd = Path.cwd()
        try:
            _os.chdir(target)
            run_wizard(pick_fly_app_name(name), open_browser=open_browser)
        finally:
            _os.chdir(prev_cwd)
        return

    info("")
    info("[bold]Next:[/bold]")
    info(f"  cd {name}")
    info("  parbaked dev")
    info("")
    info("Open [cyan]http://localhost:8000/auth/admin[/cyan] and sign in")
    info("with the password from the terminal banner.")
    info("")
    info("Add routes in routes/. Add SQLModel tables in models.py.")
    info("Replacing [cyan]web/[/cyan]? See AGENTS.md → \"Replacing the starter\" (#316).")
    info("Ship to fly.io when ready: `parbaked init` walks you through it.")


# `dev` runs the kernel runtime via uvicorn. Defined in ops.py so it can
# share helpers with the other ops commands.
app.command(name="dev", help="Run the app locally with uvicorn auto-reload.")(ops.dev)


@app.command()
def init(
    open_browser: bool = typer.Option(
        False,
        "--open",
        help="Open the live URL in the browser once the deploy completes.",
    ),
) -> None:
    """Walk through the first-run fly.io onboarding wizard.

    Run this from inside an existing parbaked project that wasn't
    scaffolded with ``parbaked new --deploy``. The wizard detects
    flyctl, drives ``fly auth`` / ``fly launch``, pushes secrets, and
    deploys. After the first successful run, ``parbaked deploy`` is the
    one-shot redeploy command — no prompts.
    """
    if not Path("parbaked.toml").exists():
        error("No parbaked.toml found. Run `parbaked init` at your project root.")
        raise typer.Exit(1)

    from parbaked.cli.deploy_wizard import pick_fly_app_name, run_wizard
    from parbaked.config import ParbakedConfig

    config = ParbakedConfig()
    # First init: build a globally-unique fly app name from app_name +
    # 5-char random suffix. Subsequent inits (state file present) re-use
    # the cached name so the redeploy targets the same app.
    candidate = pick_fly_app_name(config.app_name)
    run_wizard(candidate, open_browser=open_browser)


# ``parbaked deploy`` is the headline verb (``parbaked deploy`` with no
# args runs the actual ``fly deploy``), but it also needs to grow a
# ``status`` subcommand mirroring the MCP ``tool_deploy_status`` so the
# CLI surface stays aligned with the MCP surface (#318). Typer's
# ``invoke_without_command=True`` pattern lets a group's own callback
# run when no subcommand is given — so ``parbaked deploy`` keeps doing
# the deploy and ``parbaked deploy status`` is the new structural
# read-out.
deploy_app = typer.Typer(
    invoke_without_command=True,
    # ``-h`` mirrors ``--help`` on this group too (#318 partial).
    context_settings={"help_option_names": _HELP_OPTION_NAMES},
)


@deploy_app.callback(invoke_without_command=True)
def _deploy_callback(ctx: typer.Context) -> None:
    """Run ``fly deploy``, generating Dockerfile + fly.toml from parbaked.toml.

    Running ``parbaked deploy`` with no subcommand runs the deploy itself.
    Add ``status`` (``parbaked deploy status``) for a structural read-out
    of whether the project has been deployed yet — mirrors the MCP
    ``tool_deploy_status``.

    If neither ``Dockerfile`` nor ``fly.toml`` exists at project root,
    parbaked renders both from templates into ``.parbaked/build/`` (driven
    by ``parbaked.toml``) and points ``fly deploy`` at them. The generated
    ``fly.toml`` carries the volume mount + env vars for SQLite persistence.

    If you have a hand-written ``Dockerfile`` or ``fly.toml`` at project
    root (v0.7-era projects, or post-eject custom setups), parbaked defers
    to your files — never clobbers them.

    Orchestration lives in ``parbaked.operations.deploy.run_deploy``;
    this command is the typer wrapper that prints progress banners and
    translates exceptions to ``typer.Exit``. The MCP ``tool_deploy``
    tool calls the same operation directly so the two surfaces don't drift.
    """
    if ctx.invoked_subcommand is None:
        ops.deploy()


@deploy_app.command("status")
def deploy_status(
    as_json: bool = typer.Option(
        False,
        "--json",
        help="Emit the same JSON structure the MCP `deploy_status` tool returns.",
    ),
) -> None:
    """Report whether ``parbaked deploy`` has been run for this project.

    Mirrors the MCP ``tool_deploy_status`` so the agent and human
    surfaces answer the same question with the same data source —
    ``.parbaked/deploy.json``, the cache the deploy wizard writes on
    first deploy. Default output is a human-readable summary;
    ``--json`` emits the exact dict the MCP tool returns
    (``{"ok": true, "deployed": <bool>, "fly_app_name": "...", "url":
    "...", "first_deploy_at": "..."}``) so shell pipelines and agents
    that don't speak MCP can read deploy state structurally.

    On not-in-a-project ``--json`` writes the same envelope shape the
    MCP tool does on error (``{"ok": false, "error": "not in a
    parbaked project (no parbaked.toml)"}``) to stderr with exit 1,
    keeping stdout empty so ``parbaked deploy status --json | jq``
    doesn't parse human prose by accident. ANSI styling is suppressed
    in JSON mode.
    """
    import json as _json

    if as_json:
        # Delegate to the canonical MCP tool implementation so the CLI
        # JSON surface and the MCP tool surface stay lockstep — same
        # keys, same value types, byte-for-byte interchangeable. Use
        # plain ``print`` rather than ``console.print`` so rich's
        # terminal-width line-wrapping doesn't break
        # ``parbaked deploy status --json | jq`` on narrow terminals /
        # CI.
        from parbaked.mcp.server import tool_deploy_status as _tool_deploy_status

        payload = _tool_deploy_status()
        if not payload.get("ok"):
            # Error envelope (``{"ok": false, "error": "..."}``) — same
            # shape ``tool_deploy_status`` returns on missing
            # parbaked.toml, mirrored to stderr per the precedent set
            # by ``users show --json`` (#380) and ``status --json``
            # (#383): error payload to stderr, stdout empty, exit 1,
            # so a consumer branching on ``payload["ok"]`` against
            # either surface works.
            print(_json.dumps(payload), file=sys.stderr)
            raise typer.Exit(1)
        print(_json.dumps(payload, indent=2))
        return

    if not Path("parbaked.toml").exists():
        error(
            "No parbaked.toml found. Run `parbaked deploy status` at your project root."
        )
        raise typer.Exit(1)

    state_path = Path(".parbaked/deploy.json")
    if not state_path.exists():
        info("not yet deployed (no .parbaked/deploy.json)")
        info("Run `parbaked init` to walk through the first-deploy wizard.")
        return
    try:
        state = _json.loads(state_path.read_text())
    except (OSError, _json.JSONDecodeError):
        info("not yet deployed (could not read .parbaked/deploy.json)")
        return
    fly_app_name = state.get("fly_app_name")
    if not fly_app_name:
        info("not yet deployed (no fly_app_name cached)")
        return

    # ``markup=False`` because the fly app name comes from the wizard
    # cache and could in principle contain brackets — render it as the
    # literal string rather than parsing as rich markup.
    def _row(label: str, value: str) -> None:
        console.print(f"{label:14s}{value}", markup=False, highlight=False)

    _row("deployed:", "yes")
    _row("fly app:", fly_app_name)
    _row("url:", f"https://{fly_app_name}.fly.dev")
    first = state.get("first_deploy_at")
    if first:
        _row("first deploy:", str(first))


app.add_typer(deploy_app, name="deploy")
app.command(name="logs", help="Tail `fly logs`.")(ops.logs)
app.command(
    name="push-secrets",
    help="Push .env entries to fly secrets (one-way local → fly).",
)(ops.secrets)


# Deprecation alias for the old `parbaked secrets` name . Kept
# hidden from --help so tutorials migrate, but still functional for one
# release so any existing scripts / docs that call ``parbaked secrets``
# keep working. Emits a deprecation notice on stderr so the user
# notices the rename.
@app.command(
    name="secrets",
    hidden=True,
    help="Deprecated alias for `parbaked push-secrets`.",
)
def secrets_alias(
    env_file: Path = typer.Option(
        Path(".env"), "--env-file", "-e", help="Path to env file (default ./.env)"
    ),
) -> None:
    """Forward to ``parbaked push-secrets`` after printing a deprecation
    notice on stderr.

    The rename is verb-first : ``push-secrets`` is honest about
    being one-way local → fly, ``secrets`` reads like a subcommand
    group (compare ``parbaked users``) that doesn't exist. Kept hidden
    so the rename actually lands in tab-completion + ``--help``.
    """
    warn("`parbaked secrets` is deprecated — use `parbaked push-secrets` instead.")
    ops.secrets(env_file=env_file)


app.command(name="tunnel", help="Expose localhost via a cloudflared quick tunnel.")(
    ops.tunnel
)
app.command(name="destroy", help="Permanently destroy this project's fly.io app.")(
    ops.destroy
)


@app.command(name="eject", help="Export parbaked data + deploy files (off-board).")
def eject_cmd(
    output: Path = typer.Option(
        Path("parbaked-export"),
        "--output", "-o",
        help=(
            "Directory to write the export into. Refuses to overwrite "
            "a non-empty directory unless it's a prior parbaked-export "
            "or --force is passed."
        ),
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help=(
            "Overwrite a non-empty output directory even when it isn't "
            "a prior parbaked-export. Files are still written by name "
            "(no rmtree)."
        ),
    ),
) -> None:
    """Produce a self-contained export the operator can take anywhere.

    Writes schema.sql + data/*.csv + Dockerfile + fly.toml + .env.example
    + MANIFEST.md. The MANIFEST points at the Data Format Guarantees
    doc — the contract every byte in the export is built against.

    Idempotent over a prior export — running ``parbaked eject`` again
    against the default ``parbaked-export/`` directory recognises the
    prior MANIFEST.md sentinel and overwrites in place. Pointing at a
    non-empty arbitrary directory is refused unless you pass
    ``--force`` (#290).
    """
    from parbaked.config import ParbakedConfig
    from parbaked.eject import eject as _eject
    from parbaked.exceptions import EjectError

    if not Path("parbaked.toml").exists():
        error("No parbaked.toml found. parbaked eject must run at the project root.")
        raise typer.Exit(1)

    config = ParbakedConfig()
    try:
        out = _eject(output, config=config, force=force)
    except EjectError as exc:
        error(str(exc))
        raise typer.Exit(1) from exc
    success(f"exported parbaked data to {out}")
    info("")
    info("Read MANIFEST.md inside for the file map + format details.")


@app.command()
def status(
    as_json: bool = typer.Option(
        False,
        "--json",
        help="Emit the same JSON structure the MCP `tool_status` returns.",
    ),
) -> None:
    """Print a one-screen summary of the current parbaked project .

    Pulls config + deploy state + migration status + secrets presence into
    a single text screen so the operator can answer "is everything wired
    up?" without grepping three files. Reuses the same data sources the
    MCP server's ``email_setup_status`` / ``deploy_status`` tools return,
    so the human read-out matches what the agent sees.

    Default output is human-readable rows. ``--json`` emits the exact
    dict the MCP ``tool_status`` returns — same field names, same value
    types — so shell pipelines and agents that don't speak MCP can read
    parbaked deploy / runtime state structurally. On
    not-in-a-project ``--json`` writes the same envelope shape the MCP
    tool does on error (``{"ok": false, "error": "not in a parbaked
    project (no parbaked.toml)"}``) to stderr with exit 1, keeping
    stdout empty so ``parbaked status --json | jq`` doesn't parse human
    prose by accident. ANSI styling is suppressed in JSON mode.

    Names of secrets in ``.parbaked.json`` are listed, but values are
    never printed — even partial values give attackers a head start on
    brute-forcing the rest, and admin tooling that prints secrets is
    how secrets leak into shell history / screenshots / pair sessions.
    """
    import json as _json

    if as_json:
        # Delegate to the canonical MCP tool implementation so the CLI
        # JSON surface and the MCP tool surface can't drift — same keys,
        # same value types, byte-for-byte interchangeable. Use ``print``
        # rather than ``console.print`` so rich's terminal-width
        # line-wrapping doesn't insert newlines mid-string and break
        # ``parbaked status --json | jq`` on narrow terminals / CI.
        from parbaked.mcp.server import tool_status as _tool_status

        payload = _tool_status()
        if not payload.get("ok"):
            # Error envelope (``{"ok": false, "error": "..."}``) — same
            # shape ``tool_status`` returns on missing parbaked.toml,
            # mirrored to stderr per the precedent set by
            # ``users show --json`` (#380): error payload to stderr,
            # stdout empty, exit 1, so a consumer branching on
            # ``payload["ok"]`` against either surface works.
            print(_json.dumps(payload), file=sys.stderr)
            raise typer.Exit(1)
        print(_json.dumps(payload, indent=2))
        return

    if not Path("parbaked.toml").exists():
        error("No parbaked.toml found. Run `parbaked status` at your project root.")
        raise typer.Exit(1)

    from parbaked.cli._db import load_config

    config = load_config()

    # ``markup=False`` because user-supplied values (database URLs with
    # square-bracketed IPv6 hosts, app names containing brackets, etc.)
    # must not be parsed as rich markup.
    def _row(label: str, value: str) -> None:
        console.print(f"{label:13s}{value}", markup=False, highlight=False)

    _row("parbaked", str(__version__))
    _row("app_name", config.app_name)
    _row("app_url", config.app_url)
    _row("env", config.env)
    _row("database", str(config.database_url))
    info("")

    # Email mode — mirrors mcp.tool_email_setup_status.
    if not config.email_enabled:
        _row("email", "disabled (dashboard-only)")
    elif config.resend_key:
        _row("email", "resend")
        _row("  from", str(config.effective_mail_from()))
        _row("  admin", str(config.admin_email))
    else:
        _row("email", "console (stdout)")
        _row("  admin", str(config.admin_email))
    info("")

    # Deploy state — mirrors mcp.tool_deploy_status.
    state_path = Path(".parbaked/deploy.json")
    if state_path.exists():
        try:
            state = _json.loads(state_path.read_text())
        except (OSError, _json.JSONDecodeError):
            state = {}
        fly_app_name = state.get("fly_app_name")
        if fly_app_name:
            _row("deploy", "onboarded")
            _row("  fly app", fly_app_name)
            _row("  url", f"https://{fly_app_name}.fly.dev")
            first = state.get("first_deploy_at")
            if first:
                _row("  first", first)
        else:
            _row("deploy", "not yet (no fly_app_name cached)")
    else:
        _row("deploy", "not yet (no .parbaked/deploy.json)")
    info("")

    # Migration status — read SchemaVersion if the DB exists. Best-effort:
    # a brand-new project that hasn't booted yet has no DB, and that's
    # fine — we just say "no DB yet" rather than crashing.
    try:
        from parbaked.migrations import LATEST_VERSION

        latest = LATEST_VERSION() if callable(LATEST_VERSION) else LATEST_VERSION
    except ImportError:
        latest = None
    try:
        from sqlalchemy import inspect as _sa_inspect
        from sqlmodel import select

        from parbaked.auth.models import SchemaVersion
        from parbaked.cli._db import open_engine

        engine = open_engine()
        inspector = _sa_inspect(engine)
        if inspector.has_table("_parbaked_schema_version"):
            from sqlmodel import Session

            with Session(engine) as session:
                row = session.exec(select(SchemaVersion)).first()
                current = row.version if row else 0
            if latest is None:
                _row("migrations", f"applied version {current}")
            else:
                _row(
                    "migrations",
                    f"applied {current} / latest {latest}"
                    + ("  (up to date)" if current == latest else "  (pending)"),
                )
        else:
            _row("migrations", "no DB yet (run `parbaked dev` once)")
    except Exception as exc:  # noqa: BLE001 — status must never crash
        _row("migrations", f"unknown ({exc.__class__.__name__})")
    info("")

    # Local secrets — names only, never values .
    secrets_path = Path(".parbaked.json")
    if secrets_path.exists():
        try:
            stored = _json.loads(secrets_path.read_text())
        except (OSError, _json.JSONDecodeError):
            stored = {}
        names = sorted(stored.keys())
        if names:
            _row("secrets", ".parbaked.json")
            for n in names:
                _row("", f"  - {n}")
        else:
            _row("secrets", ".parbaked.json (empty)")
    else:
        _row("secrets", "no .parbaked.json")


# Subcommand groups: scoped by domain, ordered after the top-level
# verbs so users see the journey commands first.
app.add_typer(users_app, name="users", help="Inspect and manage users.")
app.add_typer(
    admin_app,
    name="admin",
    help="Manage the admin password, invite admins, run pending DB migrations.",
)
app.add_typer(email_app, name="email", help="Set up real email delivery.")


@app.command()
def mcp() -> None:
    """Run the parbaked MCP server (AI tool surface).

    Speaks the Model Context Protocol over stdio so AI agents (Claude
    Desktop, Cursor, Codex, etc.) can scaffold, develop, and deploy a
    parbaked project as tool calls. Requires the ``mcp`` extra::

        pip install 'parbaked[mcp]'

    See AGENTS.md for the Claude Desktop config snippet.
    """
    try:
        from parbaked.mcp.server import run as _run
    except ImportError:
        error(
            "parbaked MCP server requires the optional 'mcp' extra.\n"
            "  Install with: uv add 'parbaked[mcp]'\n"
            "  Or, for a tool install: uv tool install 'parbaked[mcp]' --prerelease=allow"
        )
        raise typer.Exit(1) from None
    try:
        _run()
    except ImportError:
        # build_server() raises ImportError when ``mcp`` isn't installed
        # — same friendly hint as the top-level import failure.
        error(
            "parbaked MCP server requires the optional 'mcp' extra.\n"
            "  Install with: uv add 'parbaked[mcp]'\n"
            "  Or, for a tool install: uv tool install 'parbaked[mcp]' --prerelease=allow"
        )
        raise typer.Exit(1) from None


@app.command()
def version(
    as_json: bool = typer.Option(
        False,
        "--json",
        help=(
            "Emit a structured JSON envelope with parbaked version, "
            "python version, and install path — useful for CI / agents "
            "that want to verify the install without parsing the "
            "human-readable string."
        ),
    ),
) -> None:
    """Print the installed parbaked version.

    Default output is the bare version string for parity with
    ``parbaked --version`` and the existing subcommand behaviour.
    ``--json`` emits a structured envelope (``{"ok": true,
    "parbaked_version": "...", "python_version": "...", "install_path":
    "..."}``) for symmetry with ``parbaked status --json`` /
    ``email setup status --json`` / ``deploy status --json`` so shell
    pipelines and agents that don't speak MCP can verify the install
    structurally rather than parsing the unstructured text.
    """
    if as_json:
        import json as _json
        import platform as _platform
        from pathlib import Path as _Path

        # ``install_path`` is the parbaked package directory on disk —
        # the natural answer to "where did this CLI come from?" that
        # ``uv tool install`` users and CI scripts ask. Resolved via
        # the loaded module's ``__file__`` so it tracks editable
        # installs / tool-installs / system installs equally.
        import parbaked as _parbaked

        install_path = (
            str(_Path(_parbaked.__file__).resolve().parent)
            if getattr(_parbaked, "__file__", None)
            else None
        )
        payload = {
            "ok": True,
            "parbaked_version": __version__,
            "python_version": _platform.python_version(),
            "install_path": install_path,
        }
        # Plain ``print`` rather than ``console.print`` so rich's
        # terminal-width line-wrapping doesn't break
        # ``parbaked version --json | jq`` on narrow terminals / CI.
        print(_json.dumps(payload, indent=2))
        return

    # ``markup=False`` so any future version string containing brackets
    # round-trips verbatim.
    console.print(__version__, markup=False, highlight=False)


# ``parbaked completions <shell>`` — named verb mirroring the
# ``docker completion`` / ``gh completion`` / ``fly completion``
# convention every Unix CLI ships (#318 partial). Wraps the same typer
# engine as the ``--show-completion`` flag from #376, just under a
# discoverable subcommand name. Defined in cli/completions.py so the
# main module stays under the 700-line implicit budget.
app.command(name="completions")(_completions)


def _argv_check_verbosity_mutex() -> None:
    """Pre-flight ``--quiet`` / ``--verbose`` mutex check (#401, second
    iteration of #393 part 1).

    The root callback already enforces the mutex (see
    :func:`_root_callback`) — but eager option callbacks
    (``--version``, ``--install-completion``, ``--show-completion``)
    are wired with ``is_eager=True``, which means typer/click fires
    them and calls ``raise typer.Exit(...)`` *before* the root callback
    body runs. So pre-#401, ``parbaked --quiet --verbose --version``
    printed the version with both flags accepted, contradicting the
    help-text "mutually exclusive" claim.

    Scanning ``sys.argv`` before ``app()`` makes the constraint a
    real invariant rather than a per-callback dance: any future eager
    flag inherits the check for free.

    Caveat — false positives if ``-v`` appears as a *value* to some
    other option (e.g. a hypothetical ``--name -v``). The POSIX ``--``
    terminator is the operator's documented escape hatch and is
    honoured here: tokens after ``--`` are not scanned. The
    ``--flag=value`` form keeps the value glued to the flag with
    ``=``, so it never appears as a bare ``-v`` / ``--verbose``
    either.
    """
    argv = sys.argv[1:]
    # ``--`` terminates option parsing per POSIX — everything after
    # is a positional value, never an option, so we must not scan it.
    try:
        end = argv.index("--")
    except ValueError:
        end = len(argv)
    head = argv[:end]
    has_q = False
    has_v = False
    for token in head:
        if token in ("--quiet", "-q"):
            has_q = True
        elif token in ("--verbose", "-v"):
            has_v = True
        elif (
            len(token) >= 2
            and token.startswith("-")
            and not token.startswith("--")
        ):
            # Combined short flags (Devin caught — #401 review): click
            # parses ``-qv`` as ``-q -v``, but as a single argv token
            # neither equality check above matches. Scan the
            # character set so ``-qv`` / ``-vq`` / ``-qvh`` trip the
            # mutex like the spaced form. Skip the leading ``-``.
            chars = set(token[1:])
            if "q" in chars:
                has_q = True
            if "v" in chars:
                has_v = True
    if has_q and has_v:
        # Match typer's ``BadParameter`` user-visible shape (``Error:
        # ...\n`` on stderr, exit 2) so the behaviour is byte-identical
        # to the existing root-callback path — the only difference is
        # which code paths it now also covers.
        sys.stderr.write(
            "Error: --quiet/-q and --verbose/-v are mutually exclusive.\n"
        )
        sys.exit(2)


def _argv_hint_leading_hyphen_name() -> None:
    """Pre-flight check for ``parbaked new -<…>`` (#393 part 3).

    typer/click parses leading-hyphen tokens as short flags before
    ``_validate_app_name`` ever runs, so ``parbaked new -leading-hyphen``
    crashes with the unhelpful ``No such option '-l'`` (the parser sees
    ``-l`` + ``eading-hyphen``-as-value, not a project name).
    ``_validate_app_name`` already rejects leading-hyphen names with a
    clear rules-cite — it just never gets the chance.

    Workaround: scan ``sys.argv`` before typer dispatches. If the
    operator typed ``parbaked new`` followed by a token starting with
    ``-`` that isn't one of the known ``new`` long-option names, emit
    the project-name rules error directly and exit 2. The known-flag
    short-list mirrors ``new``'s typer.Option declarations above —
    keep in sync if a flag is added there.
    """
    argv = sys.argv[1:]
    # Skip the root-level flags (``-q`` / ``-v`` / ``-V`` / ``-h``) to
    # find the subcommand. ``--`` terminates option parsing per POSIX
    # convention and is the operator's documented escape hatch
    # (``parbaked new -- -leading-hyphen``), so a literal ``--`` token
    # means we're already in the right shape — bail out.
    if "--" in argv:
        return
    try:
        new_idx = argv.index("new")
    except ValueError:
        return
    rest = argv[new_idx + 1:]
    if not rest:
        return
    first = rest[0]
    if not first.startswith("-"):
        return
    # Known ``new`` flags — long form only, since the misparse case is
    # exactly "the operator passed a short-flag-looking token". Keep
    # in sync with the typer.Option declarations above.
    known_new_flags = {
        "--parent", "-p",
        "--force", "-f",
        "--deploy",
        "--skip-onboarding",
        "--open",
        "--no-install",
        "-h", "--help",
    }
    # Tolerate ``--flag=value`` form by splitting on the first ``=``.
    bare = first.split("=", 1)[0]
    if bare in known_new_flags:
        return
    # Looks like a project-name with a leading hyphen — emit the same
    # rules-cite ``_validate_app_name`` would, plus a ``--`` separator
    # hint so the operator knows the escape hatch.
    error(
        "Project name must be lowercase, start with a letter, "
        "use only letters/digits/hyphens, no trailing hyphen. "
        f"(Got {first!r}.) If you really meant a leading-hyphen "
        f"name, use the POSIX ``--`` separator: "
        f"``parbaked new -- {first!r}``."
    )
    sys.exit(2)


def cli_entry() -> None:
    """Console-script entry point — wraps ``app()`` with pre-flight guards.

    The ``parbaked`` console script (see ``pyproject.toml``) points
    here rather than at ``app`` directly, so we can run argv-level
    guards before typer/click starts dispatching:

    - :func:`_argv_check_verbosity_mutex` (#401) — enforce
      ``--quiet`` / ``--verbose`` mutex before any eager option
      callback (``--version`` / ``--install-completion`` /
      ``--show-completion``) gets a chance to short-circuit
      ``raise typer.Exit(...)`` past the root callback's mutex check.
    - :func:`_argv_hint_leading_hyphen_name` (#393 part 3) — emit
      the project-name rules error for ``parbaked new -<bareword>``
      before typer's parser misreads the leading-hyphen token as a
      short flag and crashes with ``No such option '-l'``.

    Everything else is identical to invoking ``app()`` directly — the
    typer ``Typer`` object stays the test-and-MCP-discoverable surface.
    """
    _argv_check_verbosity_mutex()
    _argv_hint_leading_hyphen_name()
    app()


if __name__ == "__main__":
    cli_entry()
