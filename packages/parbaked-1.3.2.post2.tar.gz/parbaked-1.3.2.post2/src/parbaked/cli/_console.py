"""Shared rich Console singletons + thin helpers for the CLI (#221).

Every parbaked CLI command imports ``console`` / ``stderr_console`` from
this module rather than constructing its own ``rich.Console`` so the
output style (theme, width, force-terminal, etc.) stays consistent across
the CLI surface. Tests + the typer ``CliRunner`` capture rich output
identically to ``typer.echo`` — rich detects a non-TTY stream and turns
off colour automatically, so plain assertions like ``"✓ approved" in
output`` keep working.

Helpers are intentionally minimal — ``success`` / ``error`` / ``warn`` /
``info`` / ``plain`` cover the three or four shapes the CLI actually
emits. Anything fancier (tables, panels, prompts) imports rich directly
in the command module so this file stays under "thin abstraction".

The success/error/warn helpers PREPEND the project's house glyph
(``✓`` / ``✗`` / ``⚠``) so callers can pass the message body alone —
the few existing call sites that already include the glyph have been
trimmed to match.

Verbosity (#318 partial)
------------------------
The global ``--quiet`` / ``-q`` and ``--verbose`` / ``-v`` flags on the
root CLI flip a module-level verbosity sentinel that ``info`` /
``success`` honour. ``error`` / ``warn`` always emit — they're how the
operator finds out something went wrong, and silencing them would make
``-q`` a footgun. ``plain`` / direct ``console.print`` calls are
considered DATA (e.g. the ``parbaked version`` output, JSON payloads)
and stay untouched in any mode — ``parbaked -q version`` still prints
the version string, just not the INFO chatter around it.

The verbosity also drives the ``parbaked`` logger level so
``logging.getLogger("parbaked.foo").info(...)`` calls inside subcommands
(deploy gen, eject, runtime helpers) follow the same knob — DEBUG on
``-v``, WARNING on ``-q``, otherwise unchanged.
"""

from __future__ import annotations

import logging

from rich.console import Console

# Singletons. ``stderr=True`` swaps the underlying stream — ``rich``
# still picks up the same TTY/non-TTY detection so colour falls off
# cleanly when the operator pipes the output somewhere.
console = Console()
stderr_console = Console(stderr=True)


# --------------------------------------------------------------------- verbosity
# Three-state singleton driven by the root callback in cli/main.py:
#
#   "quiet"   — ``-q`` / ``--quiet``: suppress INFO (info, success);
#               WARN/ERROR survive.
#   "normal"  — default; behaviour unchanged from pre-#318.
#   "verbose" — ``-v`` / ``--verbose``: bump the ``parbaked`` logger to
#               DEBUG so subcommands emit their extra context.
#
# Stored as a module-level string rather than an int so the intent is
# legible at the call site (``_VERBOSITY == "quiet"`` reads better than
# ``_VERBOSITY < 0``) and so tests can pin it via the public setter.
_VERBOSITY: str = "normal"


def set_verbosity(level: str) -> None:
    """Set the CLI verbosity. Called by the root typer callback (#318).

    ``level`` ∈ ``{"quiet", "normal", "verbose"}``. Also pushes the
    matching level onto the ``parbaked`` logger so non-CLI modules
    (runtime, deploy gen, eject) follow the same knob without having to
    import this singleton.
    """
    global _VERBOSITY
    if level not in {"quiet", "normal", "verbose"}:
        raise ValueError(f"unknown verbosity {level!r}")
    _VERBOSITY = level

    # Wire into the standard library logger too. The ``parbaked`` logger
    # is configured by :func:`parbaked.logging.configure_logging` at
    # ``Parbaked()`` boot for the runtime; setting the level here is
    # cheap and idempotent even when the runtime hasn't booted yet (e.g.
    # ``parbaked new`` / ``parbaked --version``) — ``setLevel`` on a
    # stdlib logger is just a slot write.
    pkg_logger = logging.getLogger("parbaked")
    if level == "quiet":
        pkg_logger.setLevel(logging.WARNING)
    elif level == "verbose":
        pkg_logger.setLevel(logging.DEBUG)
    else:
        pkg_logger.setLevel(logging.INFO)


def get_verbosity() -> str:
    """Return the current verbosity. Mostly for tests."""
    return _VERBOSITY


def _print_with_glyph(
    target: Console, glyph: str, style: str, message: str
) -> None:
    """Render ``<colored-glyph> <message>`` with markup parsing OFF.

    Critical: parbaked CLI messages routinely contain literal square
    brackets — ``parbaked[mcp]``, JSON paths, pip extras, regex
    snippets — that would silently get parsed as rich markup tags and
    eaten if we just ``print(f"... {message}")``. Render the message as
    plain text and use ``Console.print`` directly for the glyph so we
    can colour it.
    """
    # ``end=""`` joins the glyph and the message on one logical line.
    # ``markup=False`` on the message side keeps brackets in user-facing
    # strings (extras, JSON keys) verbatim. ``soft_wrap=True`` so long
    # single-line messages (URLs in hints, paths) don't get reflowed by
    # rich's terminal-width detection — the CI gotcha in #221.
    target.print(f"[{style}]{glyph}[/{style}]", end=" ", soft_wrap=True)
    target.print(message, markup=False, highlight=False, soft_wrap=True)


def success(message: str) -> None:
    """Print a green ✓ + the message to stdout.

    Treated as INFO-level: suppressed under ``--quiet`` (#318 partial).
    ``parbaked -q approve …`` should produce no chatter on success —
    the exit code is the contract. The ``✗`` / ``⚠`` paths still emit
    so failures aren't silently swallowed.
    """
    if _VERBOSITY == "quiet":
        return
    _print_with_glyph(console, "✓", "green", message)


def error(message: str) -> None:
    """Print a red ✗ + the message to stderr.

    Does NOT exit — the caller decides whether to ``raise typer.Exit(1)``
    after surfacing the error (the same pattern the pre-rich code used
    with ``typer.echo(..., err=True)``).

    Always emits — ``--quiet`` only suppresses INFO chatter, never the
    diagnostic paths the operator needs to debug a failure (#318).
    """
    _print_with_glyph(stderr_console, "✗", "red", message)


def warn(message: str) -> None:
    """Print a yellow ⚠ + the message to stderr.

    Always emits — ``--quiet`` only suppresses INFO chatter, not WARN
    or ERROR (#318).
    """
    _print_with_glyph(stderr_console, "⚠", "yellow", message)


def info(message: str) -> None:
    """Print an uncoloured info line to stdout.

    Use for plain status messages that don't carry a ✓/✗/⚠ semantic —
    "Pushing .env → fly secrets…" and friends. Kept as a helper so the
    CLI codepath has a single import surface even for the boring case.

    Renders with rich markup enabled — callers that need bracketed
    literal text in their message (rare; e.g. ``parbaked[mcp]``) should
    use ``console.print(..., markup=False)`` directly.

    Suppressed under ``--quiet`` (#318 partial) — that's the whole
    point of the flag. Pure-data commands (``parbaked version``,
    ``parbaked users list --json``) print via ``console.print`` and so
    pass through untouched.
    """
    if _VERBOSITY == "quiet":
        return
    console.print(message)


def plain(message: str = "") -> None:
    """Print a literal line with rich's markup parsing disabled.

    Used for fixed-width banner/divider lines and for any user-supplied
    text that might contain rich markup tokens (``[foo]``) — we want
    them rendered verbatim, not interpreted.
    """
    console.print(message, markup=False, highlight=False)
