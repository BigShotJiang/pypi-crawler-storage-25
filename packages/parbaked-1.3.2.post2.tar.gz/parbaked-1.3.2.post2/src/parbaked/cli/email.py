"""parbaked email <sub-command> — opinionated email setup, Resend-first."""

from __future__ import annotations

import json as _json
import sys as _sys
from pathlib import Path

import typer

from parbaked.cli._console import console, error, info, success
from parbaked.email._http import HTTPEmailError, post_json
from parbaked.email.base import EmailMessage

email_app = typer.Typer(
    help="Set up real email delivery.",
    no_args_is_help=True,
    # ``-h`` mirrors ``--help`` on this group too (#318 partial).
    context_settings={"help_option_names": ["-h", "--help"]},
)


_SETUP_BANNER = """\
─────────────────────────────────────────────────────────────
parbaked recommends Resend (https://resend.com)
  ✓ 3,000 emails/month free, no credit card
  ✓ Send from onboarding@resend.dev — no DNS setup needed
  ✓ Upgrade to your own domain later (one DNS record)

1. Open https://resend.com/signup (signs you up with email or GitHub)
2. Create an API key at https://resend.com/api-keys
3. Paste it below — anything starting with re_
─────────────────────────────────────────────────────────────
"""


def _write_env(env_path: Path, key: str, mail_from: str | None) -> None:
    """Append or update PARBAKED_RESEND_KEY + optional PARBAKED_MAIL_FROM in .env."""
    lines: list[str] = []
    existing = env_path.read_text().splitlines() if env_path.exists() else []
    seen_key = seen_from = False
    for line in existing:
        if line.startswith("PARBAKED_RESEND_KEY="):
            lines.append(f"PARBAKED_RESEND_KEY={key}")
            seen_key = True
        elif line.startswith("PARBAKED_MAIL_FROM=") and mail_from is not None:
            lines.append(f"PARBAKED_MAIL_FROM={mail_from}")
            seen_from = True
        else:
            lines.append(line)
    if not seen_key:
        lines.append(f"PARBAKED_RESEND_KEY={key}")
    if mail_from and not seen_from:
        lines.append(f"PARBAKED_MAIL_FROM={mail_from}")
    env_path.write_text("\n".join(lines) + "\n")


@email_app.command("setup")
def setup(
    key: str = typer.Option(
        None,
        "--key",
        help="Resend API key. If omitted, you'll be prompted interactively.",
    ),
    mail_from: str = typer.Option(
        None,
        "--from",
        help="From address. Defaults to onboarding@resend.dev (sandbox).",
    ),
    env_file: Path = typer.Option(
        Path(".env"),
        "--env-file",
        help="Target .env file (default: ./.env).",
    ),
) -> None:
    """Set up Resend for real email delivery. Writes PARBAKED_RESEND_KEY to .env."""
    if key is None:
        # Banner contains URLs + glyphs but no rich markup — print it
        # verbatim so braces / brackets in any future copy don't get
        # accidentally parsed as markup.
        info(_SETUP_BANNER)
        key = typer.prompt("Resend API key", hide_input=False).strip()

    if not key.startswith("re_"):
        error(
            "that doesn't look like a Resend API key (should start with 're_')."
        )
        raise typer.Exit(1)

    _write_env(env_file, key, mail_from)
    success(f"wrote PARBAKED_RESEND_KEY to {env_file.resolve()}")
    if mail_from:
        success(f"wrote PARBAKED_MAIL_FROM={mail_from}")
    else:
        info("  (using Resend's sandbox sender: onboarding@resend.dev)")
        info("  Set PARBAKED_MAIL_FROM for your own domain later.")
    info("")
    info("To send a test email and confirm it works:")
    info("  parbaked email test you@example.com")


@email_app.command("test")
def test(
    recipient: str = typer.Argument(..., help="Where to send the test email"),
    key: str = typer.Option(
        None,
        "--key",
        envvar="PARBAKED_RESEND_KEY",
        help="Resend API key. Defaults to PARBAKED_RESEND_KEY env var.",
    ),
    mail_from: str = typer.Option(
        "onboarding@resend.dev",
        "--from",
        envvar="PARBAKED_MAIL_FROM",
        help="From address. Defaults to Resend's sandbox sender.",
    ),
) -> None:
    """Send a one-off test email. Useful to verify Resend is wired up."""
    if not key:
        error(
            "no API key. Set PARBAKED_RESEND_KEY or pass --key. "
            "Run `parbaked email setup` for an interactive walkthrough."
        )
        raise typer.Exit(1)

    msg = EmailMessage(
        to=recipient,
        subject="parbaked test email",
        body=(
            "This is a test email from parbaked.\n\n"
            "If you're seeing this, your Resend setup is working.\n"
        ),
    )
    info(f"→ sending test email to {recipient}...")
    try:
        post_json(
            "https://api.resend.com/emails",
            {
                "from": mail_from,
                "to": [msg.to],
                "subject": msg.subject,
                "text": msg.body,
            },
            headers={"Authorization": f"Bearer {key}"},
        )
    except HTTPEmailError as exc:
        error(f"Resend rejected the send:\n  {exc}")
        raise typer.Exit(1) from exc

    success(f"sent. Check {recipient}'s inbox.")


@email_app.command("status")
def status(
    as_json: bool = typer.Option(
        False,
        "--json",
        help="Emit the same JSON structure the MCP tool returns.",
    ),
) -> None:
    """Report the current email transport, sender, and key state.

    Mirrors the MCP ``email_setup_status`` tool so the agent surface
    and the human CLI surface answer the same question with the same
    data sources. The default output is a human-readable summary;
    ``--json`` emits the exact dict the MCP tool returns — useful for
    piping into ``jq`` or letting an agent parse the output of a CLI
    invocation.

    Never prints the Resend API key value, only whether one is
    configured — admin tooling that prints secrets is how secrets
    end up in shell history.

    ``--json`` mode delegates to the MCP ``tool_email_setup_status``
    function so the CLI JSON surface and the MCP tool surface can't
    drift — same keys, same value types, byte-for-byte
    interchangeable. On not-in-a-project ``--json`` writes the same
    envelope shape the MCP tool does on error
    (``{"ok": false, "error": "not in a parbaked project (no
    parbaked.toml)"}``) to stderr with exit 1, keeping stdout empty so
    ``parbaked email status --json | jq`` doesn't parse human prose by
    accident. ANSI styling is suppressed in JSON mode.
    """
    if as_json:
        # Delegate to the canonical MCP tool implementation so the CLI
        # JSON surface and the MCP tool surface stay lockstep — same
        # keys, same value types, byte-for-byte interchangeable. Use
        # plain ``print`` rather than ``console.print`` so rich's
        # terminal-width line-wrapping doesn't insert newlines mid-
        # string and break ``parbaked email status --json | jq`` on
        # narrow terminals / CI.
        from parbaked.mcp.server import (
            tool_email_setup_status as _tool_email_setup_status,
        )

        payload = _tool_email_setup_status()
        if not payload.get("ok"):
            # Error envelope (``{"ok": false, "error": "..."}``) — same
            # shape ``tool_email_setup_status`` returns on missing
            # parbaked.toml, mirrored to stderr per the precedent set
            # by ``users show --json`` (#380) and ``status --json``
            # (#383): error payload to stderr, stdout empty, exit 1,
            # so a consumer branching on ``payload["ok"]`` against
            # either surface works.
            print(_json.dumps(payload), file=_sys.stderr)
            raise typer.Exit(1)
        print(_json.dumps(payload, indent=2))
        return

    if not Path("parbaked.toml").exists():
        error(
            "No parbaked.toml found. Run `parbaked email status` at your project root."
        )
        raise typer.Exit(1)

    from parbaked.cli._db import load_config
    from parbaked.operations.email_status import get_email_status

    config = load_config()

    status = get_email_status(config)

    # ``markup=False`` because user-supplied values (mail_from with
    # angle brackets, etc.) must not be parsed as rich markup.
    def _row(label: str, value: str) -> None:
        console.print(f"{label:18s}{value}", markup=False, highlight=False)

    _row("Mode:", "enabled" if status.enabled else "disabled")
    _row("Transport:", status.transport)
    if status.sender is not None:
        sender_display = status.sender
        if status.sandbox_sender:
            sender_display += "  (Resend sandbox)"
        _row("From:", sender_display)
    if status.admin_email:
        _row("Admin email:", str(status.admin_email))
    _row("Resend key:", "configured" if status.key_configured else "not set")

    # Next-step hint per mode — the single most useful field for a
    # vibe-coding operator wondering "why isn't my email working?"
    info("")
    if not status.enabled:
        info("Dashboard-only mode. Run `parbaked email setup` to enable real email.")
    elif status.mode == "console":
        info(
            "Emails print to stdout (no Resend key). "
            "Run `parbaked email setup` for real delivery."
        )
    elif status.sandbox_sender:
        info(
            "Resend sandbox sender — only delivers to your Resend account owner. "
            "Verify a domain at resend.com/domains and set PARBAKED_MAIL_FROM."
        )
    else:
        success("Email is configured for real delivery.")
