"""parbaked users <sub-command> — inspect and manage users from the shell.

Useful when:
- An agent is debugging "user X can't log in" — they `parbaked users show X` to
  inspect lifecycle state without needing the admin dashboard.
- You want to manually approve someone without clicking through the UI.
- You want to scan the user list (e.g. for a beta).
"""

from __future__ import annotations

import json as _json
import sys as _sys

import typer
from rich.markup import escape as _rich_escape
from rich.table import Table
from sqlmodel import select

from parbaked.auth.models import User
from parbaked.auth.service import approve_user, reject_user
from parbaked.cli._console import console, error, info, stderr_console
from parbaked.cli._db import load_config, make_email_transport, open_session
from parbaked.email.templates import Templates
from parbaked.hooks import load_consumer_hooks as _load_consumer_hooks

users_app = typer.Typer(
    help="Inspect and manage users.",
    no_args_is_help=True,
    # ``-h`` mirrors ``--help`` on this group too (#318 partial).
    context_settings={"help_option_names": ["-h", "--help"]},
)


def _find_user(session, email: str) -> User:
    # Emails are stored lower-cased at signup (#164) — lower-case the
    # argument so `parbaked users show Foo@x.com` resolves the same row
    # the user would log in with.
    user = session.exec(select(User).where(User.email == email.lower())).first()
    if user is None:
        error(f"no user with email {email!r}")
        raise typer.Exit(1)
    return user


@users_app.command("list")
def list_users(
    as_json: bool = typer.Option(
        False,
        "--json",
        help="Emit the same JSON structure the MCP `users_list` tool returns.",
    ),
) -> None:
    """Print every user with status + verification + signup time.

    Default output is a rich table. ``--json`` emits the exact list of
    user dicts the MCP ``tool_users_list`` returns (id, email, name,
    status, email_verified, created_at) so shell pipelines and agents
    that don't speak MCP get the same structural data — pipe through
    ``jq``. ANSI styling is suppressed in JSON mode.
    """
    from parbaked.operations.users import list_users as _list_users

    session = next(open_session())
    rows = _list_users(session)
    if as_json:
        # Match ``tool_users_list``'s envelope shape exactly:
        # ``{"ok": true, "users": [...]}`` — same key, same per-row
        # field names, same value types. The CLI and MCP surfaces are
        # byte-for-byte interchangeable so a consumer's ``jq`` query
        # works against either. Use ``print`` rather than
        # ``console.print`` so rich's terminal-width line-wrapping
        # doesn't insert newlines mid-string and break
        # ``parbaked users list --json | jq`` on narrow terminals / CI.
        payload = {
            "ok": True,
            "users": [
                {
                    "id": str(u.id),
                    "email": u.email,
                    "name": u.name,
                    "status": u.status.value,
                    "email_verified": u.email_verified_at is not None,
                    "created_at": u.created_at.isoformat(),
                }
                for u in rows
            ],
        }
        print(_json.dumps(payload, indent=2))
        return
    if not rows:
        info("(no users yet)")
        return
    # Rich table for legibility — colour-codes status, right-aligns the
    # signup date, and lets terminals reflow gracefully. Falls back to
    # plain ASCII automatically when stdout is piped (the CliRunner used
    # by tests captures non-TTY output, so substring assertions like
    # ``"alice@example.com" in output`` keep working).
    table = Table(
        title=None,
        header_style="bold",
        show_lines=False,
        # Padding keeps individual cells from running together when
        # rich falls back to ASCII borders (pipe characters) in non-TTY mode.
        pad_edge=False,
    )
    table.add_column("V", width=1, justify="center")
    table.add_column("STATUS", style="cyan")
    table.add_column("EMAIL")
    table.add_column("NAME")
    table.add_column("SIGNED UP")
    for u in rows:
        verified = "[green]✓[/green]" if u.email_verified_at else " "
        # Colour the status so "active" / "pending" / "rejected" are
        # visually distinct at a glance — same intent as the old plain
        # text, just easier to scan.
        status_value = u.status.value
        if status_value == "active":
            status_cell = f"[green]{status_value}[/green]"
        elif status_value == "rejected":
            status_cell = f"[red]{status_value}[/red]"
        else:
            status_cell = f"[yellow]{status_value}[/yellow]"
        signup = u.created_at.strftime("%Y-%m-%d %H:%M")
        # Rich parses cell values as markup by default — a user name like
        # ``[red]Evil[/red]`` would be rendered as styled "Evil" rather
        # than the literal string. Escape user-supplied fields so the
        # display matches what's actually in the DB (#221 Devin).
        table.add_row(
            verified,
            status_cell,
            _rich_escape(u.email),
            _rich_escape(u.name[:25]),
            signup,
        )
    console.print(table)


@users_app.command("show")
def show_user(
    email: str = typer.Argument(..., help="Email of the user to look up"),
    as_json: bool = typer.Option(
        False,
        "--json",
        help="Emit the same JSON structure the MCP `users_show` tool returns.",
    ),
) -> None:
    """Print full details for a single user.

    Default output is human-readable key/value rows. ``--json`` emits
    the exact dict the MCP ``tool_users_show`` returns — same field
    names, same value types — so the two surfaces are interchangeable.
    On user-not-found ``--json`` writes the same envelope shape the MCP
    ``tool_users_show`` does on error
    (``{"ok": false, "error": "no user with email <x>"}``) to stderr
    with exit 1, keeping stdout empty so
    ``parbaked users show X --json | jq`` doesn't parse human prose by
    accident. A consumer branching on ``payload["ok"]`` works against
    both surfaces.
    """
    session = next(open_session())
    # In --json mode we must NOT let _find_user's rich ✗-prefixed
    # stderr leak — replace the human error with a JSON object on
    # stderr and exit 1, matching ``tool_users_show``'s error envelope
    # (`{"ok": false, "error": "no user with email ..."}`).
    if as_json:
        user = session.exec(select(User).where(User.email == email.lower())).first()
        if user is None:
            print(
                _json.dumps({"ok": False, "error": f"no user with email {email}"}),
                file=_sys.stderr,
            )
            raise typer.Exit(1)
        payload = {
            "ok": True,
            "user": {
                "id": str(user.id),
                "email": user.email,
                "name": user.name,
                "status": user.status.value,
                "email_verified": user.email_verified_at is not None,
                "email_verified_at": (
                    user.email_verified_at.isoformat()
                    if user.email_verified_at is not None
                    else None
                ),
                "created_at": user.created_at.isoformat(),
                "approved_at": (
                    user.approved_at.isoformat()
                    if user.approved_at is not None
                    else None
                ),
                "revoked_at": (
                    user.revoked_at.isoformat()
                    if user.revoked_at is not None
                    else None
                ),
            },
        }
        print(_json.dumps(payload, indent=2))
        return

    user = _find_user(session, email)
    # Plain key/value rows — the value can be a user-supplied display
    # name with rich-markup-looking characters, so disable markup parsing
    # to render them verbatim.
    for label, value in (
        ("id", user.id),
        ("email", user.email),
        ("name", user.name),
        ("status", user.status.value),
        ("verified", user.email_verified_at or "(not yet)"),
        ("created", user.created_at),
        ("approved", user.approved_at or "(not yet)"),
    ):
        console.print(f"{label + ':':14s}{value}", markup=False, highlight=False)


@users_app.command("approve")
def approve(
    email: str = typer.Argument(..., help="Email of the user to approve"),
    no_email: bool = typer.Option(
        False, "--no-email", help="Skip the welcome email"
    ),
) -> None:
    """Flip a user to active. Sends them the welcome email by default."""
    config = load_config()
    transport = make_email_transport(config)
    session = next(open_session())
    user = _find_user(session, email)

    # ``--no-email`` swaps in a do-nothing transport; otherwise we wrap the
    # real transport so we can tell the operator whether the send actually
    # landed (``safe_send`` swallows the exception inside ``approve_user``).
    recorder = _RecordingEmail(_NullEmail() if no_email else transport)
    changed = approve_user(
        user, session,
        config=config, email=recorder,
        templates=Templates(), hooks=_load_consumer_hooks(), via="cli",
    )
    if not changed:
        # ``·`` bullet has no color semantic — render as plain info.
        info(f"  · {user.email} is already active")
        return
    # Mirror the pre-rich format so test assertions like
    # ``"✓ approved alice@example.com" in result.output`` still match —
    # the helper prepends "✓ ", we just add the leading two-space indent.
    console.print(f"  [green]✓[/green] approved {user.email}")
    if no_email:
        return
    if recorder.sent:
        console.print(f"  [green]✓[/green] welcome email sent to {user.email}")
    else:
        stderr_console.print(
            f"  [yellow]⚠[/yellow] welcome email failed for {user.email} — see log"
        )


@users_app.command("issue-reset")
def issue_reset(
    email: str = typer.Argument(..., help="Email of the user needing a reset"),
) -> None:
    """Mint a one-shot password-reset link and print it to stdout.

    The intended path for dashboard-only deploys: a user can't
    reach ``/auth/forgot-password`` because no email transport is
    configured, so the admin runs this command and shares the URL
    out-of-band (Slack, in-person, etc).

    Works in email-enabled mode too — useful for "I see in the logs
    that the reset email bounced; let me hand them a link directly."
    """
    from parbaked.auth.tokens import create_password_reset_token
    from parbaked.cli.ops import (
        _read_dev_port,
        _user_set_app_url,
        resolved_localhost_base_url,
    )

    config = load_config()
    session = next(open_session())
    user = _find_user(session, email)

    reset_token = create_password_reset_token(user.id, user.password_hash, config)
    # ``resolved_localhost_base_url`` first prefers an explicit user-set
    # ``app_url``, then a sibling ``parbaked dev``'s actual bound port
    # via ``.parbaked/dev_port`` (#333) — covers the
    # ``parbaked dev --port 8765`` case automatically. Only warn when
    # NEITHER an explicit ``app_url`` nor a running dev is detectable
    # (the operator's link target is genuinely ambiguous then).
    base_url = resolved_localhost_base_url(config)
    reset_url = f"{base_url}/auth/reset/{reset_token}"

    if not _user_set_app_url() and _read_dev_port() is None:
        # Yellow ! prefix — same intent as the old typer.secho yellow.
        stderr_console.print(
            f"[yellow]  ! Generating reset URL for {base_url}. If your dev server is "
            f"running on a different host/port, set "
            f"PARBAKED_APP_URL=http://localhost:<port> before this command.[/yellow]"
        )

    info(f"One-shot reset link for {user.email}:")
    info("")
    # ``soft_wrap=True`` so the long token-bearing URL prints on one line
    # even when the captured stream pretends to be 80 cols wide — same
    # CI gotcha as the admin-signin URL above (#221).
    console.print(f"    [cyan]{reset_url}[/cyan]", soft_wrap=True)
    info("")
    hours = config.password_reset_expiry_hours
    hour_unit = "hour" if hours == 1 else "hours"
    info(
        f"Valid for {hours} {hour_unit}. "
        "Share it via a channel you trust — anyone who clicks it can set "
        f"a new password for {user.email}."
    )


@users_app.command("reject")
def reject(
    email: str = typer.Argument(..., help="Email of the user to reject"),
    no_email: bool = typer.Option(False, "--no-email", help="Skip the rejection email"),
) -> None:
    """Flip a user to rejected."""
    config = load_config()
    transport = make_email_transport(config)
    session = next(open_session())
    user = _find_user(session, email)

    recorder = _RecordingEmail(_NullEmail() if no_email else transport)
    changed = reject_user(
        user, session,
        config=config, email=recorder,
        templates=Templates(), hooks=_load_consumer_hooks(), via="cli",
    )
    if not changed:
        info(f"  · {user.email} is already rejected")
        return
    console.print(f"  [green]✓[/green] rejected {user.email}")
    if no_email:
        return
    if recorder.sent:
        console.print(f"  [green]✓[/green] rejection email sent to {user.email}")
    else:
        stderr_console.print(
            f"  [yellow]⚠[/yellow] rejection email failed for {user.email} — see log"
        )


class _NullEmail:
    """``--no-email`` plumbing — accepts ``send(...)`` and does nothing."""

    def send(self, message):  # noqa: ARG002 — protocol stub
        return None


class _RecordingEmail:
    """Wraps a transport; sets ``self.sent`` only if the underlying send
    succeeded. Lets the CLI report accurately even though ``safe_send`` in
    ``approve_user`` / ``reject_user`` swallows the exception.
    """

    def __init__(self, inner) -> None:
        self.inner = inner
        self.sent = False

    def send(self, message) -> None:
        self.inner.send(message)  # may raise → safe_send catches; sent stays False
        self.sent = True
