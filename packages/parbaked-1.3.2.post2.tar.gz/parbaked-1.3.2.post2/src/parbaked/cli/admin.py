"""parbaked admin <sub-command> — manage the admin password / dashboard."""

from __future__ import annotations

import json
import secrets as _secrets
from pathlib import Path

import typer

from parbaked.cli._console import console, error, info, success

# ``-h`` mirrors ``--help`` at every subcommand level (#318 partial) —
# Typer/click doesn't automatically propagate the root ``context_settings``
# to sub-Typer groups, so each group repeats the same opt-in.
admin_app = typer.Typer(
    help="Manage the admin password, invite admins, run pending DB migrations.",
    no_args_is_help=True,
    context_settings={"help_option_names": ["-h", "--help"]},
)


@admin_app.command("reset-password")
def reset_password(
    secrets_file: Path = typer.Option(
        Path(".parbaked.json"),
        "--secrets-file",
        help="Path to the secrets JSON file (default: ./.parbaked.json)",
    ),
) -> None:
    """Generate a new admin password and write it to .parbaked.json.

    The new password is NEVER printed to stdout — printing would leak
    it to terminal scrollback, tmux/screen capture buffers,
    asciinema/script recordings, and pair-programming screenshots.
    Read it back from the secrets file when you need it:

        jq -r .admin_password .parbaked.json

    This matches how ``parbaked init`` handles the auto-generated
    admin password: write to ``.parbaked.json`` (0600), print only
    the path. ``parbaked status`` lists secret *names* but never
    *values* for the same reason — admin tooling exists to prevent
    secrets-in-terminal-output, not to commit it.
    """
    # Project-context guard (#390): without this, running the command
    # outside a parbaked project silently writes ``.parbaked.json``
    # into the operator's cwd — leaking a fresh admin password into
    # whatever directory they happened to be in (e.g. ``/tmp``) while
    # the real project keeps the old password. Mirror the same guard
    # every other long-running command uses (``dev``, ``init``,
    # ``deploy``, ``status``, ``admin migrate``, …).
    if not Path("parbaked.toml").exists():
        error(
            "No parbaked.toml in this directory.\n"
            "  Run `parbaked new <name>` to scaffold a project, "
            "or cd into one."
        )
        raise typer.Exit(1)

    data: dict = {}
    if secrets_file.exists():
        try:
            data = json.loads(secrets_file.read_text())
        except json.JSONDecodeError:
            error(
                f"{secrets_file} is corrupt — refusing to overwrite. "
                "Delete it manually or pass --secrets-file pointing elsewhere."
            )
            raise typer.Exit(1) from None

    new_password = _secrets.token_urlsafe(18)
    data["admin_password"] = new_password
    secrets_file.write_text(json.dumps(data, indent=2) + "\n")

    # Do NOT print ``new_password`` here, ever. The whole point of #337
    # was that we used to. The user reads it back from the secrets file.
    success(f"New admin password written to {secrets_file.resolve()}")
    info(f"Read it with:  jq -r .admin_password {secrets_file}")
    info("Restart your app (or set PARBAKED_ADMIN_PASSWORD) for the change to take effect.")


@admin_app.command("signin")
def signin() -> None:
    """Print a one-time admin sign-in URL — break-glass recovery.

    Mints a short-lived ``parbaked-admin-signin`` token using the
    project's local JWT secret and prints the URL. Visiting it sets
    the admin session cookie and lands on the dashboard.

    Two intended uses:

    - **Local dev** with a real ``admin_email`` set but no Resend
      transport — the magic link normally prints to stdout, but if
      you've lost the terminal you can re-mint one here.
    - **Production recovery** when the admin inbox is unreachable
      (DNS broke, Resend bouncing, you lost access). Shell into the
      machine — ``fly ssh console -C "parbaked admin signin"`` —
      print a URL, click it, you're in. Shell access IS the recovery
      path; there is no shadow password.

    The token uses the configured secret so it's verifiable by the
    running app without any additional state. It also embeds the
    current per-admin signin nonce from the project's DB (#205); the
    first verify of the printed URL rotates that nonce, invalidating
    the URL for any future replay. Re-running ``parbaked admin
    signin`` mints a fresh URL bound to the same nonce — outstanding
    URLs minted earlier this session still work UNTIL one of them is
    used, at which point all peers are invalidated together.
    """
    from sqlmodel import Session

    from parbaked.auth.tokens import create_admin_signin_token
    from parbaked.cli._db import load_config, open_engine
    from parbaked.cli.ops import resolved_localhost_base_url

    config = load_config()
    if not config.effective_approval_secret():
        error(
            "No JWT / approval-token secret configured. Set "
            "PARBAKED_JWT_SECRET (or PARBAKED_APPROVAL_TOKEN_SECRET) "
            "and try again."
        )
        raise typer.Exit(1)

    engine = open_engine()
    with Session(engine) as session:
        token = create_admin_signin_token(config, session)
    # ``resolved_localhost_base_url`` honours an explicit user-set
    # ``app_url`` (env / .env / parbaked.toml), and otherwise falls back
    # to the port a sibling ``parbaked dev`` is bound to via
    # ``.parbaked/dev_port`` (#333) — fixes the regression where
    # ``parbaked dev --port 8765`` + ``parbaked admin signin`` produced
    # a link at ``localhost:8000`` that 404'd.
    base = resolved_localhost_base_url(config)
    url = f"{base}/auth/admin/signin/{token}"
    info("One-time admin sign-in URL (valid 15 minutes):")
    info("")
    # Use ``soft_wrap=True`` so the long URL prints on a single line even
    # if the captured stream pretends to be 80 columns wide — without it,
    # rich line-wraps the URL mid-token and consumers can't copy/paste
    # the link in one go (and regex-extracting it from the captured
    # output breaks). #221 CI gotcha.
    console.print(f"    [cyan]{url}[/cyan]", soft_wrap=True)
    info("")
    info("Open it in your browser to land directly in the dashboard.")


@admin_app.command("migrate")
def migrate() -> None:
    """Run pending schema migrations against parbaked's DB.

    Normally migrations run automatically on boot — this command is the
    explicit-step escape hatch for operators who set
    ``auto_migrate = false`` in parbaked.toml.
    """
    from parbaked.cli._db import load_config, open_engine
    from parbaked.migrations import apply_migrations

    # ``load_config()`` so the log line shows the same URL ``open_engine`` is
    # about to use (the helper resolves identically — they both call
    # ``load_config().database_url`` under the hood). Going through
    # ``open_engine`` keeps the sqlite ``check_same_thread`` dance in one
    # place (#188 item 2).
    config = load_config()
    engine = open_engine()
    info(f"Running migrations against {config.database_url}…")
    apply_migrations(engine)
    success("schema is up to date")
