"""Example route. Files starting with _ are skipped by route discovery.
Rename to ``me.py`` (or anything without a leading _) to mount at /me/.
"""

from fastapi import APIRouter, Depends

from parbaked import current_user

router = APIRouter()


@router.get("")
def view(user = Depends(current_user)):
    return {"email": user.email, "name": user.name}
