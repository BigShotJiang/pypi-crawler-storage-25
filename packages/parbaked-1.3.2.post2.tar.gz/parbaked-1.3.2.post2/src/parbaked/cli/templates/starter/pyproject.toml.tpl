[project]
name = "{{APP_NAME}}"
version = "0.0.1"
description = "{{APP_NAME}} — built with parbaked"
requires-python = ">=3.11"
dependencies = [
    "{{PARBAKED_DEP}}",
]
