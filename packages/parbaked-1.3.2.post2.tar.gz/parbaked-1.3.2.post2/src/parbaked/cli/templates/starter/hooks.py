"""Lifecycle hooks fire after the relevant DB commit. See AGENTS.md.

Drop a module-level callable named ``on_signup`` / ``on_verify`` /
``on_approve`` / ``on_reject`` / ``on_delete`` here and ``parbaked dev``
will pick it up at boot — no other wiring needed.

Hooks run on the request path. A 200ms network call inside ``on_signup``
adds 200ms to every signup response. Keep hooks fast, or wrap slow work
in ``threading.Thread(target=..., daemon=True).start()`` for
fire-and-forget. Exceptions are logged and swallowed so a broken hook
can't crash the auth flow.
"""

# Example — uncomment and edit:
#
# def on_signup(user):
#     print(f"[analytics] {user.email} signed up")
#
# def on_approve(user):
#     # Welcome DM, Slack notification, whatever — keep it quick.
#     pass
#
# def on_delete(user):
#     # GDPR cascade — drop the user's rows from your tables.
#     # `user` is the *scrubbed* row; `user.id` is stable.
#     pass
