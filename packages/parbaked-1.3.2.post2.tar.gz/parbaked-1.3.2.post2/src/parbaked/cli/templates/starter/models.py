"""Your app's SQLModel tables go here.

parbaked owns the ``users`` table — don't try to extend it. To add
user-scoped data (display name, avatar, per-user settings, notes,
etc.), create a related table keyed on ``users.id`` as the example
below shows. See AGENTS.md "Wiring a per-user table" for the
canonical pattern and the rationale.
"""

# Example — uncomment and edit:
#
# from uuid import UUID
# from sqlmodel import Field, SQLModel
#
# class Note(SQLModel, table=True):
#     id: int | None = Field(default=None, primary_key=True)
#     # Related-to-users pattern: store extra per-user data in a separate
#     # table, not in users. See AGENTS.md "Wiring a per-user table".
#     user_id: UUID = Field(foreign_key="users.id")
#     body: str
