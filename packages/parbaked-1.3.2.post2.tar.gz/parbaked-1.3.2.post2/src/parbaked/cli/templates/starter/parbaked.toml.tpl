# {{APP_NAME}} — parbaked configuration.
# Every PARBAKED_* env var also works here as a toml key.
# Full list: https://github.com/saml7n/parbaked/blob/main/AGENTS.md
# ──────────────────────────────────────────────────────────────────────────

app_name = "{{APP_NAME}}"

# Optional [frontend] block. When present, parbaked mounts ``source_dir``
# (or its ``dist_subpath`` after a build) at /. Delete this block for
# backend-only mode.
[frontend]
source_dir = "web"
# build_command = "npm ci && npm run build"
# dist_subpath = "dist"
