# {{APP_NAME}}

Built with [parbaked](https://github.com/saml7n/parbaked).

```bash
parbaked dev       # run locally
parbaked deploy    # ship to fly.io
```

Add routes in `routes/`. Add SQLModel tables in `models.py`. Tune config in `parbaked.toml`. Admin dashboard at <http://localhost:8000/auth/admin>.

Docs: <https://github.com/saml7n/parbaked/blob/main/AGENTS.md>
