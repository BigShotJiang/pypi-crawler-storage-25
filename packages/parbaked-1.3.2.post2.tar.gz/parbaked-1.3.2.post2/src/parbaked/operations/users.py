"""User-listing operation (#228).

The single Python entry point for "give me every user, newest first."
Shared by the CLI ``parbaked users list`` command and the MCP
``tool_users_list`` tool — pre-#228 each surface re-implemented the
``select(User).order_by(...)`` query and then formatted it (typer
table vs JSON-able dict).

Contract:

- :func:`list_users` takes an injected ``Session`` and returns a
  ``list[User]``. It does NOT open its own DB connection — the caller
  picks the session source (CLI shells via ``cli/_db.py``, the MCP
  tool does the same, an HTTP route would use FastAPI ``Depends``).
- The operation NEVER prints, NEVER returns formatted strings, and
  NEVER catches DB exceptions. Surfaces format the rows and translate
  errors (the MCP tool maps ``OperationalError("no such table")`` to
  a friendly "run parbaked dev once" hint, for instance).
"""

from __future__ import annotations

from sqlmodel import Session, select

from parbaked.auth.models import User


def list_users(session: Session) -> list[User]:
    """Return every user, newest signup first.

    The ordering matches what an admin scanning a beta wants — most
    recent activity at the top. Surfaces that need a different shape
    (the MCP JSON dict, the typer table) format the rows themselves.
    """
    return list(session.exec(select(User).order_by(User.created_at.desc())).all())
