"""Email-status operation (#338, shape per #228).

The single Python entry point for "what email transport is this project
configured for, and how would mail behave right now?" Shared by the
CLI ``parbaked email status`` command and the MCP
``tool_email_setup_status`` tool — pre-#338 the MCP server had the
logic inline and the CLI had no equivalent at all (issue #338).

Why this lives in ``operations/``: the CLI ``status`` row, the MCP
tool, and the new ``parbaked email status`` subcommand all answer the
same question with the same data sources (``ParbakedConfig``,
``effective_mail_from``, sandbox-sender detection). Centralising the
logic keeps the three surfaces in lockstep — the bug where one
surface says "console" and another says "resend" for the same project
becomes impossible.

Contract:

- :func:`get_email_status` takes an injected :class:`ParbakedConfig`
  and returns a structured :class:`EmailStatus` dataclass. It does
  NOT read module-level state, NOT print, NOT raise.
- :func:`email_status_dict` returns the same data as a JSON-able
  ``dict[str, Any]``. The shape preserves backward compatibility with
  the existing MCP ``tool_email_setup_status`` consumers — the
  legacy ``mode`` / ``detail`` / ``from`` / ``admin_email`` keys are
  unchanged, with new descriptive fields added alongside.
"""

from __future__ import annotations

from dataclasses import dataclass

from parbaked.config import ParbakedConfig

# Resend's sandbox sender — sending from this address works without
# domain verification, but Resend will only deliver to the account
# owner's own email until you set up a real domain. We surface this
# explicitly so an operator who left ``PARBAKED_MAIL_FROM`` empty
# isn't surprised when their test signups don't reach beta users.
SANDBOX_SENDER = "onboarding@resend.dev"


@dataclass(frozen=True)
class EmailStatus:
    """Structured snapshot of the project's email configuration.

    Surfaces project the fields they need: the CLI prints a
    human-readable summary, the MCP tool returns
    :func:`email_status_dict`, and any future HTTP route can use the
    same dataclass.

    Attributes:
        enabled: True iff parbaked is in any email-sending mode at
            all (i.e. ``resend_key`` or ``admin_email`` is set). False
            means dashboard-only mode (#74) — signups land in pending
            immediately and the admin triages via ``/auth/admin``.
        mode: Legacy enum preserved for MCP backward compat —
            ``"disabled"`` / ``"console"`` / ``"resend"``. Matches
            what ``tool_email_setup_status`` has always returned.
        transport: Human-readable transport name —
            ``"Disabled"`` / ``"Console"`` / ``"Resend"``. The CLI
            displays this; the MCP tool exposes it under the
            ``transport`` key for agents that want a stable
            descriptive label rather than the legacy enum.
        sender: The from-address parbaked would use right now via
            :meth:`ParbakedConfig.effective_mail_from`. ``None`` only
            when email is fully disabled.
        sandbox_sender: True iff ``sender`` is Resend's sandbox
            address (``onboarding@resend.dev``). Surfaces use this
            to add a "sandbox: only delivers to account owner" hint.
        key_configured: True iff a Resend API key is present. The
            key value itself is NEVER returned — even a prefix +
            suffix leak gives attackers a head start, and admin
            tooling that prints secrets is how secrets end up in
            shell history.
        admin_email: The configured admin email (the address that
            receives signup-approval notifications), or ``None``.
    """

    enabled: bool
    mode: str
    transport: str
    sender: str | None
    sandbox_sender: bool
    key_configured: bool
    admin_email: str | None


def get_email_status(config: ParbakedConfig) -> EmailStatus:
    """Inspect ``config`` and return the current email-transport snapshot.

    The three modes parbaked recognises:

    - ``disabled`` — neither ``resend_key`` nor ``admin_email`` is set.
      Dashboard-only mode; no outbound mail. ``sender`` is ``None``.
    - ``console`` — ``admin_email`` is set but ``resend_key`` is not.
      Emails print to stdout via :class:`ConsoleEmail`. The sender
      defaults to the Resend sandbox address so the boot banner /
      log lines have something sensible to display.
    - ``resend`` — ``resend_key`` is set. Real outbound mail via
      Resend. ``sandbox_sender`` is True if the from-address is still
      the default ``onboarding@resend.dev`` (only delivers to the
      account owner), False once the operator has set
      ``PARBAKED_MAIL_FROM`` to a verified domain.
    """
    if not config.email_enabled:
        return EmailStatus(
            enabled=False,
            mode="disabled",
            transport="Disabled",
            sender=None,
            sandbox_sender=False,
            key_configured=False,
            admin_email=None,
        )

    sender = config.effective_mail_from()
    sandbox = sender == SANDBOX_SENDER

    if config.resend_key:
        return EmailStatus(
            enabled=True,
            mode="resend",
            transport="Resend",
            sender=sender,
            sandbox_sender=sandbox,
            key_configured=True,
            admin_email=config.admin_email,
        )

    return EmailStatus(
        enabled=True,
        mode="console",
        transport="Console",
        sender=sender,
        sandbox_sender=sandbox,
        key_configured=False,
        admin_email=config.admin_email,
    )


def email_status_dict(config: ParbakedConfig) -> dict[str, object]:
    """JSON-able view of :func:`get_email_status`.

    Returned by the MCP ``tool_email_setup_status`` tool and by the
    CLI's ``--json`` flag, so the two surfaces stay in lockstep.

    The shape preserves backward compatibility with the pre-#338 MCP
    tool: ``mode`` / ``from`` / ``admin_email`` / ``detail`` are
    unchanged where present, with new descriptive fields
    (``enabled``, ``transport``, ``sandbox_sender``,
    ``key_configured``) added alongside.
    """
    status = get_email_status(config)
    if status.mode == "disabled":
        return {
            "ok": True,
            "mode": "disabled",
            "enabled": False,
            "transport": "Disabled",
            "sandbox_sender": False,
            "key_configured": False,
            "detail": (
                "Dashboard-only mode (no resend_key, no admin_email). Users "
                "land in pending immediately; admin triages via /auth/admin."
            ),
        }
    if status.mode == "resend":
        return {
            "ok": True,
            "mode": "resend",
            "enabled": True,
            "transport": "Resend",
            "from": status.sender,
            "sandbox_sender": status.sandbox_sender,
            "key_configured": True,
            "admin_email": status.admin_email,
        }
    # console
    return {
        "ok": True,
        "mode": "console",
        "enabled": True,
        "transport": "Console",
        "from": status.sender,
        "sandbox_sender": status.sandbox_sender,
        "key_configured": False,
        "admin_email": status.admin_email,
        "detail": "Emails print to stdout. Set PARBAKED_RESEND_KEY for real delivery.",
    }
