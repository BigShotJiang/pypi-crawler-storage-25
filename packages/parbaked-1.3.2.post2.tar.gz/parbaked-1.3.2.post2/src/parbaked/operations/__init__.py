"""Cross-surface operations (#228).

The three entry surfaces parbaked exposes — HTTP routes, the typer CLI,
and the MCP server — all share certain operations: scaffolding a
project, deploying to fly, listing users, and so on. Pre-#228 each
surface either re-implemented the operation, or one surface shelled out
to another (the canonical case being ``mcp.tool_deploy`` invoking
``subprocess.run(["parbaked", "deploy"])``).

Functions in this package are the single Python-API home for those
cross-surface operations. Conventions:

- Inputs are passed explicitly as kwargs (config, session, etc.); the
  functions never read module-level state.
- Outputs are structured (a dataclass, ``TypedDict``, ``Path``, or
  primitive) — never printed, logged, or returned via exit codes.
- Failures raise plain exceptions; the calling surface translates them
  to ``typer.Exit`` / FastAPI ``HTTPException`` / MCP ``{"ok": False}``
  dicts as appropriate.
- No imports of typer / FastAPI / mcp inside ``operations/`` — the
  package must remain framework-agnostic so any surface can call it.

Auth-domain orchestration (signup, verify, login, password reset,
approve, reject, admin signin) lives in :mod:`parbaked.auth.service`
after PR #227 and intentionally does NOT move into ``operations/`` —
that keeps the service-layer lift coherent and avoids a second large
move.
"""
