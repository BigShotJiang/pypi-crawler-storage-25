"""Deploy operation (#228).

Renders ``Dockerfile`` + ``fly.toml`` from ``parbaked.toml`` and shells
out to ``fly deploy``. Shared by the CLI ``parbaked deploy`` command
and the MCP ``tool_deploy`` tool.

Pre-#228 the MCP server didn't have a Python entry point for "deploy"
and instead shelled out to the CLI binary::

    rc = subprocess.run(["parbaked", "deploy"], check=False).returncode

That was the canary the issue called out — the cross-surface
duplication this module closes (``mcp/server.py:475``). Both surfaces
now call :func:`run_deploy` directly.

Contract:

- Functions take an explicit :class:`ParbakedConfig` — never read
  module-level state.
- :func:`generate_deploy_files` writes the build artifacts and is pure
  bytes-on-disk + the existing fly-volume probe inside ``deploy_gen``.
  It does NOT invoke ``fly deploy``.
- :func:`run_deploy` runs the ``fly deploy`` subprocess and returns its
  exit code. Callers decide what to do with a non-zero code.
- Preconditions that depend on the CWD ( ``parbaked.toml`` exists, the
  project has been onboarded via ``parbaked init`` ) are the caller's
  job. Operations do the operation; surfaces decide the policy / UX.
"""

from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path

from parbaked.cli.deploy_gen import (
    BUILD_DIR,
    ensure_volume,
    generate,
    write_dockerignore_if_missing,
)
from parbaked.config import ParbakedConfig


@dataclass(frozen=True)
class DeployFiles:
    """The build artifacts :func:`generate_deploy_files` produced.

    Surfaces use the structured fields to render their own progress
    output — the CLI prints typer banners, the MCP server returns a
    JSON-able dict — without needing to redo the bookkeeping each time.

    Attributes:
        dockerfile: Path to the rendered ``Dockerfile`` inside the
            build directory.
        fly_toml: Path to the rendered ``fly.toml``.
        dockerignore_written: Path to the ``.dockerignore`` if this
            call wrote one; ``None`` if a user-owned ``.dockerignore``
            was already present and we left it alone (#248).
        volume_ready: True iff :func:`ensure_volume` confirmed the
            ``parbaked_data`` fly volume exists (or just created it).
            ``False`` means we couldn't verify — non-fatal, fly itself
            will surface a clearer error at deploy time.
    """

    dockerfile: Path
    fly_toml: Path
    dockerignore_written: Path | None
    volume_ready: bool


def generate_deploy_files(
    config: ParbakedConfig,
    *,
    build_dir: Path = BUILD_DIR,
) -> DeployFiles:
    """Render ``Dockerfile`` + ``fly.toml`` into ``build_dir`` and ensure
    the SQLite-persistence fly volume exists.

    Returns a :class:`DeployFiles` capturing every artifact the deploy
    needs so callers can print their own progress banner. Always
    attempts to write a ``.dockerignore`` at the build-context root
    (CWD) — Docker reads ``.dockerignore`` from there, not from next
    to the Dockerfile — but leaves a user-owned ``.dockerignore``
    untouched (#248).

    May raise :class:`parbaked.exceptions.ParbakedDeployError` if
    ``frontend.source_dir`` resolves outside the project root (#121);
    the caller translates that to its native error format (typer-style
    err-echo, MCP ``{"ok": False}`` dict, etc.). The exception subclasses
    ``ValueError`` so legacy ``except ValueError`` clauses keep working.
    """
    dockerfile, fly_toml = generate(build_dir, config)
    # ``.dockerignore`` lands at the build-context root (CWD), not in
    # ``build_dir``. Only the deploy path needs this — ``eject`` shares
    # ``generate`` but must not touch the project root (#248).
    dockerignore = write_dockerignore_if_missing()
    # Ensure the SQLite volume exists. Non-fatal if this fails — fly
    # itself will surface a clearer error when the deploy hits the
    # missing volume, so we capture the boolean and let the caller
    # decide whether to surface it.
    volume_ready = ensure_volume(config)
    return DeployFiles(
        dockerfile=dockerfile,
        fly_toml=fly_toml,
        dockerignore_written=dockerignore,
        volume_ready=volume_ready,
    )


def run_deploy(config: ParbakedConfig) -> int:
    """Generate build artifacts and invoke ``fly deploy``.

    Returns the ``fly deploy`` exit code. Does not raise on a non-zero
    code — the caller (CLI / MCP) decides whether to map that to
    ``typer.Exit`` or to an ``{"ok": False}`` dict.

    If the project root carries a hand-written ``Dockerfile`` or
    ``fly.toml`` (v0.7 projects, post-eject setups), defer to them and
    invoke plain ``fly deploy`` — no generated files, no
    ``--config``/``--dockerfile`` flags. This matches the documented
    "your files always win" contract in AGENTS.md and keeps the CLI +
    MCP surfaces in lockstep (#228 Devin: pre-refactor the MCP shelled
    out to the CLI and inherited this check; centralising it here is
    the fix).

    May raise :class:`parbaked.exceptions.ParbakedDeployError` (or
    :class:`parbaked.exceptions.ParbakedConfigError`) from
    :func:`generate_deploy_files` — malformed ``parbaked.toml`` /
    out-of-context frontend source dir (#121, #193, #221). Both subclass
    ``ValueError``, so legacy ``except ValueError`` clauses still
    catch them. The caller is also responsible for preconditions like
    "``parbaked init`` has been run" — operations do the operation;
    surfaces decide the policy / UX.
    """
    from parbaked.cli.deploy_gen import user_owns_deploy_files

    if user_owns_deploy_files():
        return subprocess.run(["fly", "deploy"], check=False).returncode

    files = generate_deploy_files(config)
    return subprocess.run(
        [
            "fly", "deploy",
            "--config", str(files.fly_toml),
            "--dockerfile", str(files.dockerfile),
        ],
        check=False,
    ).returncode
