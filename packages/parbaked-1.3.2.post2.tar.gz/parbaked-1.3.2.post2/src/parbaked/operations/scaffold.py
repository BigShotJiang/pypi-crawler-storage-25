"""Project-scaffolding operation (#228).

Walks the packaged starter templates and renders them into a target
directory. Shared by the CLI ``parbaked new`` command and the MCP
``tool_scaffold`` tool — pre-#228 the CLI had the canonical
implementation and MCP imported a private helper from
``parbaked.cli.main``. After #228 both surfaces import from here.

The caller is responsible for everything around the walk: validating
the project name, deciding whether the target directory already exists,
creating ``target`` itself, printing banners, and any post-scaffold
work (deploy wizard, ``uv sync``). This function only renders the tree.
"""

from __future__ import annotations

import importlib.metadata
import json
from importlib import resources
from pathlib import Path

from parbaked import __version__


def _starter_templates_dir() -> Path:
    """Return the directory containing starter templates (packaged data)."""
    # importlib.resources.files gives a Traversable, but for shutil we
    # need a real Path.
    pkg = resources.files("parbaked.cli.templates")
    return Path(str(pkg / "starter"))


def _parbaked_install_spec() -> str:
    """Return the dependency spec to pin in the scaffolded ``pyproject.toml``.

    Default is ``parbaked[mcp]==<self-version>`` — pins the deployed
    image to the same parbaked the CLI came from when that CLI was
    installed from PyPI (#187).

    When parbaked itself was installed from a git URL (e.g.
    ``uv tool install ... @ git+https://github.com/saml7n/parbaked.git@main``),
    the PyPI pin lies: the CLI has commits that aren't in the named PyPI
    release, but the scaffolded project's venv would pull stale code from
    PyPI and the deployed app diverges from the developer's local install
    (#355). We detect that case via the PEP 610 ``direct_url.json`` that
    pip / uv write alongside the dist-info — if it has a ``vcs_info``
    block we pin to the same git URL + ref instead.

    Editable installs (``dir_info.editable == True``) and plain local-dir
    installs fall back to the PyPI pin — there's no remotely-installable
    spec we can write into the consumer's pyproject for those, and
    silently writing a local path would make the scaffold non-portable.
    """
    try:
        dist = importlib.metadata.distribution("parbaked")
    except importlib.metadata.PackageNotFoundError:
        # Running from a non-installed checkout (unusual, but possible
        # under ``python -m parbaked`` from a source tree). Fall back to
        # the PyPI pin — the version string is still authoritative.
        return f"parbaked[mcp]=={__version__}"

    raw = dist.read_text("direct_url.json")
    if raw:
        try:
            info = json.loads(raw)
        except (ValueError, TypeError):
            info = None
        if isinstance(info, dict):
            url = info.get("url")
            vcs = info.get("vcs_info")
            if vcs and isinstance(vcs, dict) and url:
                # Prefer the resolved commit SHA — it's the only ref that
                # can't drift. Fall back to the requested branch / tag if
                # the installer didn't record a commit (older pip), and
                # finally to ``main`` if even that's missing.
                ref = (
                    vcs.get("commit_id")
                    or vcs.get("requested_revision")
                    or "main"
                )
                return f"parbaked[mcp] @ git+{url}@{ref}"

    return f"parbaked[mcp]=={__version__}"


def _render_template(content: str, app_name: str) -> str:
    return (
        content.replace("{{APP_NAME}}", app_name)
        .replace("{{PARBAKED_DEP}}", _parbaked_install_spec())
        # ``{{PARBAKED_VERSION}}`` kept for any consumer template that
        # wants the bare version string (e.g. README badges). The
        # ``pyproject.toml`` dependency line uses ``{{PARBAKED_DEP}}``
        # so #355's git-install pinning works.
        .replace("{{PARBAKED_VERSION}}", __version__)
    )


def scaffold_template_manifest() -> list[Path]:
    """Return the list of scaffold-owned output paths (relative to target).

    Mirrors the rename logic in :func:`scaffold_project` so callers can
    answer "which files would ``parbaked new`` write?" without actually
    writing them. Used by the CLI ``new`` command (#402) to print the
    list of scaffold-owned files about to be overwritten when
    ``--force`` lands on a directory the operator has been working in
    — gives them a chance to ctrl-c before scaffold-owned files like
    ``models.py`` / ``hooks.py`` get reset, while reassuring them that
    user-added files (``my-notes.md``, ``scratch/``, etc.) won't be
    touched.

    Keep in lockstep with :func:`scaffold_project`'s rename maps — both
    walk the same packaged-templates tree.
    """
    src = _starter_templates_dir()
    rename_map = {".tpl": ""}
    renamed_files = {
        "gitignore.tpl": ".gitignore",
        "pyproject.toml.tpl": "pyproject.toml",
        "parbaked.toml.tpl": "parbaked.toml",
    }

    manifest: list[Path] = []
    for src_path in src.rglob("*"):
        if src_path.is_dir():
            continue
        rel = src_path.relative_to(src)
        if rel.name in renamed_files:
            out_rel = rel.parent / renamed_files[rel.name]
        else:
            out_name = rel.name
            for old, new in rename_map.items():
                if out_name.endswith(old):
                    out_name = out_name[: -len(old)] + new
            out_rel = rel.parent / out_name
        manifest.append(out_rel)
    return manifest


def scaffold_project(target: Path, name: str) -> None:
    """Render the starter templates into ``target`` with ``name`` baked in.

    Walks :func:`_starter_templates_dir`, renaming files per the suffix
    and explicit-rename maps, and calls :func:`_render_template` on each
    file so ``{{APP_NAME}}`` / ``{{PARBAKED_VERSION}}`` placeholders
    resolve.

    **Per-file render, no directory wipe** (#402): each scaffold-owned
    file is written via :meth:`Path.write_text`, which overwrites in
    place. The walk never touches files that aren't in the template
    manifest — user-added files (``my-notes.md``, ``scratch/``,
    custom modules the user dropped in alongside ``models.py``) survive
    untouched. The caller does NOT need to rmtree the target first;
    in fact doing so would be the v1.3.1a3 data-loss bug from #402.

    Extracted in #228 so the MCP ``tool_scaffold`` path and the CLI
    ``new`` command share one implementation of the walk (previously
    each surface had its own near-identical copy at
    ``cli/main.py:_scaffold_into``; that helper now wraps this).
    """
    src = _starter_templates_dir()

    # ``rename_map`` strips the ``.tpl`` suffix from every templated
    # file by default; ``renamed_files`` overrides that for the handful
    # of files where the on-disk name differs from a simple suffix strip
    # (``gitignore.tpl`` → ``.gitignore``, etc.) because git, pip, and
    # toml parsers all key off the exact filename.
    rename_map = {".tpl": ""}
    renamed_files = {
        "gitignore.tpl": ".gitignore",
        "pyproject.toml.tpl": "pyproject.toml",
        "parbaked.toml.tpl": "parbaked.toml",
    }

    # safety: file-allowlist (scaffold template manifest)
    # Per-file render — overwrites scaffold-owned files in place but
    # never touches anything outside the manifest. Replaces the
    # ``shutil.rmtree(target)`` + recreate dance that wiped user files
    # in #402 (second iteration of the #389 data-loss bug). Convention
    # comment per #397's destructive-call audit rule.
    for src_path in src.rglob("*"):
        if src_path.is_dir():
            continue
        rel = src_path.relative_to(src)

        # Explicit renames first.
        if rel.name in renamed_files:
            out_rel = rel.parent / renamed_files[rel.name]
        else:
            # Generic .tpl stripping.
            out_name = rel.name
            for old, new in rename_map.items():
                if out_name.endswith(old):
                    out_name = out_name[: -len(old)] + new
            out_rel = rel.parent / out_name

        out_path = target / out_rel
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(_render_template(src_path.read_text(), name))
