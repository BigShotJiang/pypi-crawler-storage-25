"""Rate limiting wrapper around slowapi.

Sets sensible defaults on signup/login that block credential-stuffing and the
sort of accidental DDOS that runs up a fly.io bill. Per-route overrides come
straight from :class:`ParbakedConfig` so you can dial them per environment.
"""

from __future__ import annotations

from fastapi import FastAPI, Request
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request as StarletteRequest
from starlette.responses import Response

from parbaked._clientip import client_ip
from parbaked.config import ParbakedConfig


def _format_policy(limit_item: object) -> str:
    """Render a slowapi/limits ``RateLimitItem`` back into a human-readable
    policy string like ``"10/minute"`` or ``"5/2 minutes"``.

    slowapi's ``x-ratelimit-limit`` response header reports the count
    (``10``) without the window (``minute``), so two apps with very
    different effective rates can look identical from headers — see #360.
    We reconstruct the configured policy string from the matched
    ``RateLimitItem`` rather than threading the original literal through
    the call stack, because slowapi only hands the middleware the parsed
    item via ``request.state.view_rate_limit``.
    """
    amount = getattr(limit_item, "amount", None)
    multiples = getattr(limit_item, "multiples", 1) or 1
    granularity = getattr(limit_item, "GRANULARITY", None)
    gran_name = getattr(granularity, "name", None)
    if amount is None or gran_name is None:
        # Be defensive — if slowapi/limits ever changes shape we'd rather
        # omit the header than 500 the response.
        return ""
    if multiples == 1:
        return f"{amount}/{gran_name}"
    # Pluralise — matches the parser's accepted input form ("5/2 minutes").
    return f"{amount}/{multiples} {gran_name}s"


class _RateLimitPolicyHeaderMiddleware(BaseHTTPMiddleware):
    """Attach an ``x-ratelimit-policy`` response header on rate-limited
    endpoints so consumers can interpret the existing
    ``x-ratelimit-limit`` count alongside the window (#360).

    The header is only set when slowapi actually matched a limit for the
    endpoint — unrate-limited routes don't get the header (no point
    polluting them).
    """

    async def dispatch(
        self,
        request: StarletteRequest,
        call_next,  # noqa: ANN001 — Starlette signature
    ) -> Response:
        response = await call_next(request)
        # slowapi sets ``request.state.view_rate_limit`` to a
        # ``(RateLimitItem, [keys])`` tuple on limited endpoints, or
        # ``None`` otherwise.
        view_rate_limit = getattr(request.state, "view_rate_limit", None)
        if view_rate_limit is not None:
            policy = _format_policy(view_rate_limit[0])
            if policy:
                response.headers["x-ratelimit-policy"] = policy
        return response


def install_rate_limiting(app: FastAPI, config: ParbakedConfig) -> Limiter:
    """Wire a per-IP rate limiter onto ``app``. Idempotent.

    Returns the configured :class:`Limiter` so the caller can pass it into
    :func:`build_auth_router` for the per-route signup/login overrides.

    The bucket key is :func:`parbaked._clientip.client_ip`, which honours
    ``X-Forwarded-For`` when ``config.trust_proxy_headers`` is True. Without
    this, every request behind fly.io / Cloudflare / nginx shares one bucket
    (the proxy's IP) and ``ratelimit_signup`` becomes a global cap rather
    than per-client (#131).

    Also installs a tiny middleware that adds an ``x-ratelimit-policy``
    header (e.g. ``"20/hour"``) alongside slowapi's ``x-ratelimit-limit``
    on every rate-limited response, so the count is interpretable without
    consulting the server config (#360).
    """
    limiter = getattr(app.state, "limiter", None)
    if limiter is None:
        def key_func(request: Request) -> str:
            # Fall back to the proxy's IP rather than None — slowapi keys must
            # be strings. An anonymous "unknown" bucket is still safer than
            # crashing the limiter or letting un-IP'd requests bypass it.
            return client_ip(request, config) or "unknown"

        limiter = Limiter(
            key_func=key_func,
            default_limits=[config.ratelimit_global],
            headers_enabled=True,
        )
        app.state.limiter = limiter
        app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
        app.add_middleware(_RateLimitPolicyHeaderMiddleware)
    return limiter
