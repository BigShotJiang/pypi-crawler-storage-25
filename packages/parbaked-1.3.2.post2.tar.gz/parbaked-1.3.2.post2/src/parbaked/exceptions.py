"""Public exception hierarchy for parbaked-raised errors (#221, item 4).

Mirrors the shape httpx uses (``HTTPError`` base, narrow subclasses for
specific failure modes): consumers who want to catch "any parbaked
business-logic error" do ``except ParbakedError``; consumers who care
about a specific failure mode (``parbaked.toml`` is malformed, the
deploy file generator rejected a layout) catch the narrower subclass.

Scope and non-goals:

- Only covers non-HTTP code paths. The auth routes / service still raise
  :class:`fastapi.HTTPException` because that's how FastAPI carries
  status + detail across the request boundary, and surfacing those as
  ``ParbakedError`` would force every route handler to do a manual
  translation. HTTP errors are FastAPI's hierarchy, not parbaked's.
- Pydantic field validators (``@field_validator`` on the request
  models) keep raising ``ValueError`` because that's pydantic's
  documented protocol — pydantic wraps the ValueError into a 422
  response, swapping the exception type would break the schema.
- Existing call sites that catch ``ValueError`` still work: every
  ``ParbakedDeployError`` / ``ParbakedConfigError`` subclasses
  ``ValueError`` via the mixin below so the historical
  ``except ValueError as exc:`` clauses in the CLI + MCP server stay
  green during the transition. New code should catch the specific
  parbaked-typed subclass — the CLI ``deploy`` command and the MCP
  ``tool_deploy`` already do.
"""

from __future__ import annotations


class ParbakedError(Exception):
    """Base for all parbaked-raised exceptions.

    Catch this when you want to handle any parbaked-business-logic
    failure uniformly — e.g. in a ``try:`` around a programmatic
    deploy pipeline that calls into ``parbaked.operations`` and wants
    one ``except`` clause for "parbaked rejected the input."

    Subclasses are deliberately few — see :class:`ParbakedConfigError`
    and :class:`ParbakedDeployError`. We don't introduce a class per
    distinct error message; the message body carries the user-facing
    detail, the class carries the category.
    """


# Historically these errors were raised as plain ``ValueError`` (the CLI
# and MCP server both catch ``ValueError`` from
# ``generate_deploy_files``, ``ParbakedConfig()`` construction, and
# ``ResendEmail()`` init — see #121, #193). Subclassing ``ValueError``
# alongside ``ParbakedError`` keeps every existing ``except ValueError``
# call site green while letting new code catch the more specific type.
# The cost of the multiple inheritance is one extra MRO entry per
# exception class, which the Python type machinery is happy with.


class ParbakedConfigError(ParbakedError, ValueError):
    """Raised when parbaked rejects its own configuration.

    Covers ``parbaked.toml`` with unknown keys (typo guard, see
    :mod:`parbaked.config`) and the email-transport init errors
    where a required env var (e.g. ``PARBAKED_RESEND_KEY``) is
    missing.
    """


class ParbakedDeployError(ParbakedError, ValueError):
    """Raised when ``parbaked deploy`` can't render the build artifacts.

    Today the only case is ``frontend.source_dir`` resolving outside
    the project root (#121) — a layout the generated ``Dockerfile``
    can't actually COPY because the docker build context is the project
    root. Surface that to the operator with a layout pointer rather
    than crashing inside ``docker build`` with a cryptic
    "forbidden path outside the build context" error.
    """


class EjectError(ParbakedError):
    """Raised when ``parbaked eject`` refuses to write into the output dir.

    Eject's output directory used to be wiped with ``shutil.rmtree``
    before being repopulated. That made an unbounded path a footgun —
    a misbehaving caller (CLI user typo, MCP agent with a bad
    ``target_dir`` argument) could delete arbitrary files the user
    happened to keep alongside the eject. #290 closed the design.

    Eject now refuses to write into a non-empty directory unless the
    caller passes ``force=True`` OR the directory already contains a
    ``MANIFEST.md`` with the parbaked-export sentinel as its first
    line — proving it's a prior eject the caller is intentionally
    re-running over. Anything else raises this error.

    Not a ``ValueError`` subclass — the historical ``except ValueError``
    call sites in the CLI / MCP server cover deploy + config init
    failures, not eject (which never used to fail this way). New code
    catches :class:`EjectError` directly.
    """
