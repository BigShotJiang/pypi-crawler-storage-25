"""parbaked MCP server — AI-native tool surface (#81, v1.1).

Exposes parbaked's CLI as MCP tools so Claude / Cursor / Codex / any
MCP-aware agent can scaffold, develop, and deploy a parbaked project
without the user typing a single command.

Run as a standalone server::

    parbaked mcp

Or wire into Claude Desktop with the snippet in AGENTS.md.

The ``mcp`` Python SDK is an *optional* extra — install with
``pip install parbaked[mcp]`` so the kernel stays slim for users who
just want auth + approval. The CLI command surfaces a clean
"install parbaked[mcp]" error when the dep is missing.
"""

from parbaked.mcp.server import build_server

__all__ = ["build_server"]
