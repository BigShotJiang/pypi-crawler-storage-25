"""Shared CSS for parbaked's full-page form shells.

Three forms in the kernel used to ship near-identical card / label / input
/ button / .err CSS inline:

- ``admin.py``'s ``_LOGIN_FORM_HTML`` (admin sign-in: password or email).
- ``auth/router.py``'s ``_RESET_FORM_HTML`` (password reset).
- A now-removed ``_ADMIN_CLAIM_FORM_HTML`` (admin-invite, deleted in #130).

The CSS was byte-for-byte identical except for two cosmetic deltas: the
reset form had ``margin-top: 12px`` on ``label`` (because it stacks two
inputs and needs the breathing room), and the admin login form carried
an extra ``.ok`` class for its "check your inbox" message. Both deltas
were harmless to harmonise, so this module exports a single
``_FORM_CSS`` constant covering both rules. The reset form's label
spacing is now applied to admin login too — visible only as a slightly
larger gap between the sub-text and the single password input on the
admin login page, no functional impact (#188 item 5).

This is a one-time shared constant, not an extensible theming layer.
Consumers wanting custom-styled forms should ship their own HTML; this
module exists solely to keep the kernel's three (now two) forms from
drifting.

Token alignment with the starter (#294): the font stack, body text
colour, button colour, and ``.err`` red are kept in sync with
``cli/templates/starter/web/index.html`` so a user clicking a magic
link in their inbox lands on a page that visually belongs to the same
product they signed up on. The kernel pages keep a "card on a tinted
background" layout (the starter is card-less, but the kernel sits in
its own browser tab with no surrounding app chrome — the card gives
it some shape). Everything _inside_ the card uses the starter's
tokens.
"""

from __future__ import annotations

# Two-brace ``{{`` / ``}}`` are kept literal so the constant can be
# spliced into a ``str.format`` template without re-escaping every CSS
# rule. Callers do:
#
#     _FORM_HTML = "... <style>" + _FORM_CSS + "</style> ..."
#
# and the ``str.format`` placeholders in the surrounding HTML still
# resolve correctly because the CSS contributes no ``{x}``-style
# placeholders of its own.
#
# Font stack matches the starter (``system-ui, -apple-system, sans-serif``)
# so the handoff from inbox-click to back-to-the-app is visually seamless
# (#294). ``.err`` uses the starter's ``#b00`` red for the same reason;
# ``.ok`` keeps its semantic green for admin-login info messages — it
# never appears on the same page as ``.err`` so the palette mismatch
# doesn't show.
_FORM_CSS = """\
  body {{ font-family: system-ui, -apple-system, sans-serif;
          background: #f6f7f9; color: #111; margin: 0; padding: 0;
          min-height: 100vh; display: flex; align-items: center;
          justify-content: center; line-height: 1.5; }}
  .card {{ background: white; padding: 32px; border-radius: 8px;
           border: 1px solid #e5e7eb; max-width: 24rem; width: 100%;
           box-sizing: border-box; }}
  h1 {{ margin: 0 0 6px 0; font-size: 1.5rem; }}
  .sub {{ margin: 0 0 24px 0; font-size: 0.875rem; color: #555; }}
  label {{ display: block; font-size: 0.875rem; margin-bottom: 4px;
           margin-top: 12px; color: #555; }}
  input {{ width: 100%; padding: 0.5rem; border: 1px solid #ccc;
           border-radius: 4px; font: inherit; box-sizing: border-box; }}
  button {{ width: 100%; padding: 0.5rem 1rem; background: #111; color: white;
            border: 0; border-radius: 4px; font: inherit; cursor: pointer;
            margin-top: 16px; }}
  .err {{ color: #b00; font-size: 0.875rem; margin: 8px 0 0 0; }}
  .ok {{ color: #166534; font-size: 0.875rem; margin: 8px 0 0 0; }}\
"""
