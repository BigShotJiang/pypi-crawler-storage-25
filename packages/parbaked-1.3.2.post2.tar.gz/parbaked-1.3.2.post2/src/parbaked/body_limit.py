"""Request-body size limit middleware (#167).

FastAPI does not cap incoming JSON bodies by default — an attacker can
POST a multi-MB body to any endpoint (``/auth/signup``, ``/auth/login``,
``/auth/forgot-password``, …) and tie up server memory while parbaked's
JSON parser walks the buffer.

parbaked's largest legitimate payload is the magic-link claim body
(a token, an email, maybe a CSRF cookie) — well under 1KB. 8KB gives
plenty of headroom for a long user name plus a long password and any
future addition without leaving the door open to body-flood DoS.

Rejection is based on the declared ``Content-Length`` header. As a
belt-and-braces, requests without a ``Content-Length`` (chunked /
streamed) are also rejected on body methods — parbaked never serves
streaming endpoints, so legitimate clients always declare the length.
"""

from __future__ import annotations

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.types import ASGIApp

# 8KB is comfortably larger than every parbaked payload (longest is the
# magic-link claim body, under 1KB) yet small enough that a flood can't
# pin memory. Methods that never carry a body (GET, HEAD, DELETE,
# OPTIONS) skip the check.
MAX_BODY_BYTES = 8 * 1024

_BODY_METHODS = frozenset({"POST", "PUT", "PATCH"})


class BodySizeLimitMiddleware(BaseHTTPMiddleware):
    """Reject requests whose body exceeds ``max_bytes``.

    Inspects the ``Content-Length`` header on POST / PUT / PATCH and
    returns ``413 Request Entity Too Large`` if it's over the cap.
    A missing ``Content-Length`` on a body-bearing method (POST/PUT/PATCH)
    is rejected with 411. parbaked serves no streaming endpoints — every
    legitimate client declares a content length. Without this guard a
    ``Transfer-Encoding: chunked`` POST would bypass the size limit
    entirely and Starlette would buffer it fully into memory (Devin
    Review on #167 / #210).
    """

    def __init__(self, app: ASGIApp, max_bytes: int = MAX_BODY_BYTES) -> None:
        super().__init__(app)
        self.max_bytes = max_bytes

    async def dispatch(self, request: Request, call_next):
        if request.method in _BODY_METHODS:
            raw = request.headers.get("content-length")
            if raw is None:
                # Chunked / streamed body on a body-bearing method:
                # reject outright (411 Length Required). See class
                # docstring for the DoS rationale.
                return JSONResponse(
                    {"detail": "Content-Length header is required."},
                    status_code=411,
                )
            try:
                declared = int(raw)
            except ValueError:
                return JSONResponse(
                    {"detail": "Invalid Content-Length header."},
                    status_code=400,
                )
            if declared > self.max_bytes:
                return JSONResponse(
                    {
                        "detail": (
                            f"Request body too large "
                            f"(max {self.max_bytes} bytes)."
                        )
                    },
                    status_code=413,
                )
        return await call_next(request)
