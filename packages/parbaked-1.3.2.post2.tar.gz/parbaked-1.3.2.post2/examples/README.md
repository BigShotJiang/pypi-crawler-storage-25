# parbaked examples

**The canonical starting point is `parbaked new <name>`** — that scaffolds the
recommended layout (`parbaked.toml`, `routes/`, `models.py`, `pyproject.toml`)
and runs under `parbaked dev` with zero further wiring.

The directories here are **reference implementations**, one per concept. Each
is a self-contained kernel-runtime project — same shape `parbaked new`
produces, same `parbaked dev` UX. Use them to look up "how do I do X?" once
your own project is up and running.

```bash
cd examples/<name>
parbaked dev
```

`with_hooks/` and `custom_emails/` add a `wsgi.py` (parbaked's kernel runtime
doesn't auto-discover hooks or template overrides — those live on the
`create_app(...)` call). Run those examples directly via uvicorn:

```bash
cd examples/with_hooks
uv run uvicorn wsgi:app --reload
```

The `pyproject.toml` in each directory pins `parbaked==<version>` so the
example always matches a specific release. Bump them in lockstep with the
top-level `__version__`.

| Directory | What it teaches |
|---|---|
| [`minimal/`](minimal/) | The smallest useful project: one gated route, no extras. |
| [`protected_routes/`](protected_routes/) | Public and protected routes side by side via `Depends(current_user)`. |
| [`with_resend/`](with_resend/) | `parbaked.toml` for Resend email — `resend_key` / `mail_from`. |
| [`per_user_data/`](per_user_data/) | Sidecar `UserProfile` table FK'd to `users.id`, read/write via `get_session`. |
| [`with_hooks/`](with_hooks/) | `on_signup` / `on_verify` / `on_approve` / `on_reject` callbacks wired through `create_app(...)` in `wsgi.py`. |
| [`custom_emails/`](custom_emails/) | Override the `Templates` dataclass; wire it in via `wsgi.py` calling `create_app(templates=...)`. |

Everything in this directory uses the v1.0+ kernel runtime
(`parbaked.runtime.create_app`). The deprecated `Parbaked(app)` library-mode
shape is no longer in any example — see [`AGENTS.md`](../AGENTS.md) for why.
