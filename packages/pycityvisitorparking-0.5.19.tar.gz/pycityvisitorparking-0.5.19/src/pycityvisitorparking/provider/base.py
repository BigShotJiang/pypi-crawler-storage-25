"""Provider base class and shared behavior."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from collections.abc import Awaitable, Callable, Iterable, Mapping
from datetime import datetime
from importlib.metadata import PackageNotFoundError, version
from typing import Any, Literal, Protocol, TypeVar, overload
from urllib.parse import urlparse

import aiohttp

from ..exceptions import AuthError, NetworkError, ProviderError, ValidationError
from ..models import Favorite, Permit, ProviderInfo, Reservation, ZoneValidityBlock
from ..util import (
    ensure_utc_timestamp,
    filter_chargeable_zone_validity,
    format_utc_timestamp,
    normalize_datetime,
    normalize_license_plate,
    validate_reservation_times,
)
from .loader import ProviderManifest

_DEFAULT_TIMEOUT = aiohttp.ClientTimeout(total=30)
_LOGGER = logging.getLogger(__name__)
_T = TypeVar("_T")

try:
    PACKAGE_VERSION = version("pycityvisitorparking")
except PackageNotFoundError:  # pragma: no cover - source tree fallback
    PACKAGE_VERSION = "0.0.0"


class _HttpSession(Protocol):
    """Minimal interface required from an HTTP session."""

    def request(self, method: str, url: str, **kwargs: Any) -> Any: ...


class BaseProvider(ABC):
    """Base class for provider implementations."""

    class _RetryRequest(Exception):
        """Internal signal to retry a request."""

    def __init__(
        self,
        session: _HttpSession,
        manifest: ProviderManifest,
        *,
        base_url: str | None = None,
        api_uri: str | None = None,
        timeout: aiohttp.ClientTimeout | None = None,
        retry_count: int = 0,
    ) -> None:
        if session is None:
            raise ValidationError("Session is required.")
        self._session = session
        self._manifest = manifest
        self._base_url = self._normalize_base_url(base_url)
        self._api_uri = self._normalize_api_uri(api_uri)
        self._timeout = timeout or _DEFAULT_TIMEOUT
        self._retry_count = max(0, retry_count)
        self._request_context_name: str | None = None

    def set_request_context(self, context_name: str | None) -> None:
        """Set a human-readable context label for request diagnostics."""
        if context_name is None:
            self._request_context_name = None
            return
        value = context_name.strip()
        self._request_context_name = value or None

    def _request_target_label(self) -> str:
        """Return a stable target label for diagnostics and logs."""
        if self._base_url is None:
            return "unknown"
        parsed = urlparse(self._base_url)
        return parsed.netloc or self._base_url

    def _request_context_label(self) -> str:
        """Return city/context label for diagnostics and logs."""
        if self._request_context_name:
            return self._request_context_name
        return self._request_target_label()

    def _request_log_details(self) -> tuple[str, str, str]:
        """Return (context, target, package_version) for consistent error logging."""
        return (
            self._request_context_label(),
            self._request_target_label(),
            PACKAGE_VERSION,
        )

    @property
    def provider_id(self) -> str:
        return self._manifest.id

    @property
    def provider_name(self) -> str:
        return self._manifest.name

    @property
    def favorite_update_possible(self) -> bool:
        return bool(self._manifest.favorite_update_fields)

    @property
    def favorite_update_fields(self) -> tuple[str, ...]:
        return self._manifest.favorite_update_fields

    @property
    def reservation_update_possible(self) -> bool:
        return bool(self._manifest.reservation_update_fields)

    @property
    def reservation_update_fields(self) -> tuple[str, ...]:
        return self._manifest.reservation_update_fields

    @property
    def info(self) -> ProviderInfo:
        return ProviderInfo(
            id=self._manifest.id,
            favorite_update_fields=self._manifest.favorite_update_fields,
            reservation_update_fields=self._manifest.reservation_update_fields,
        )

    def _normalize_license_plate(self, plate: str) -> str:
        return normalize_license_plate(plate)

    def _ensure_utc_timestamp(self, value: str) -> str:
        return ensure_utc_timestamp(value)

    def _normalize_datetime(self, value: datetime) -> datetime:
        return normalize_datetime(value)

    def _format_utc_timestamp(self, value: datetime) -> str:
        return format_utc_timestamp(value)

    def _build_url(self, path: str) -> str:
        if not isinstance(path, str) or not path:
            raise ValidationError("Path must be a non-empty string.")
        if path.startswith("http://") or path.startswith("https://"):
            raise ValidationError("Use relative paths when building provider requests.")
        if self._base_url is None:
            raise ValidationError("base_url is required to build provider requests.")
        normalized_path = path if path.startswith("/") else f"/{path}"
        return f"{self._base_url}{self._api_uri}{normalized_path}"

    @overload
    def _validate_reservation_times(
        self,
        start_time: datetime,
        end_time: datetime,
        *,
        require_both: Literal[True],
    ) -> tuple[datetime, datetime]:
        pass

    @overload
    def _validate_reservation_times(
        self,
        start_time: datetime | None,
        end_time: datetime | None,
        *,
        require_both: Literal[False],
    ) -> tuple[datetime | None, datetime | None]:
        pass

    def _validate_reservation_times(
        self,
        start_time: datetime | None,
        end_time: datetime | None,
        *,
        require_both: bool,
    ) -> tuple[datetime | None, datetime | None]:
        if require_both:
            if start_time is None or end_time is None:
                raise ValidationError("start_time and end_time are required.")
            return validate_reservation_times(start_time, end_time, require_both=True)
        return validate_reservation_times(start_time, end_time, require_both=False)

    def _filter_chargeable_zone_validity(
        self,
        entries: list[tuple[ZoneValidityBlock, bool]],
    ) -> list[ZoneValidityBlock]:
        filtered = filter_chargeable_zone_validity(entries)
        normalized: list[ZoneValidityBlock] = []
        for block in filtered:
            try:
                start = self._ensure_utc_timestamp(block.start_time)
                end = self._ensure_utc_timestamp(block.end_time)
            except ValidationError as exc:
                raise ProviderError("Provider returned invalid zone validity data.") from exc
            normalized.append(ZoneValidityBlock(start_time=start, end_time=end))
        return normalized

    def _parse_int(self, value: Any) -> int:
        if value is None or isinstance(value, bool):
            return 0
        if isinstance(value, int):
            return value
        if isinstance(value, str):
            stripped = value.strip()
            if not stripped:
                return 0
            try:
                return int(stripped)
            except ValueError:
                return 0
        return 0

    def _require_id(self, value: Any, field: str) -> str:
        if value is None:
            raise ValidationError(f"{field} is required.")
        text = str(value).strip()
        if not text:
            raise ValidationError(f"{field} is required.")
        return text

    def _coerce_response_id(self, value: Any, field: str) -> str:
        if value is None:
            raise ProviderError(f"Provider response missing {field}.")
        text = str(value).strip()
        if not text:
            raise ProviderError(f"Provider response missing {field}.")
        return text

    def _coerce_id(self, value: Any) -> str:
        if value is None:
            return ""
        return str(value)

    def _find_by_id(self, items: Iterable[_T], item_id: str) -> _T | None:
        for item in items:
            if getattr(item, "id", None) == item_id:
                return item
        return None

    def _merge_credentials(
        self,
        credentials: Mapping[str, str] | None,
        **kwargs: str,
    ) -> dict[str, str]:
        merged: dict[str, str] = {}
        if credentials is not None:
            if not isinstance(credentials, Mapping):
                raise ValidationError("credentials must be a mapping of strings.")
            for key, value in credentials.items():
                if not isinstance(key, str) or not isinstance(value, str):
                    raise ValidationError("credentials must be a mapping of strings.")
                merged[key] = value
        for key, value in kwargs.items():
            if value is None:
                continue
            if not isinstance(value, str):
                raise ValidationError("credentials must be a mapping of strings.")
            merged[key] = value
        return merged

    async def _request_with_retries(
        self,
        method: str,
        url: str,
        *,
        request_kwargs: dict[str, Any],
        response_handler: Callable[[aiohttp.ClientResponse, int, int], Awaitable[Any]],
    ) -> Any:
        retries = self._retry_count if method.upper() == "GET" else 0
        attempts = retries + 1
        last_error: Exception | None = None
        for attempt in range(attempts):
            _LOGGER.debug(
                "Provider %s request %s (attempt %s/%s)",
                self.provider_id,
                method.upper(),
                attempt + 1,
                attempts,
            )
            try:
                timeout = request_kwargs.get("timeout", self._timeout)
                if timeout is None:
                    timeout = self._timeout
                merged_kwargs = dict(request_kwargs)
                merged_kwargs.setdefault("ssl", True)
                merged_kwargs["timeout"] = timeout
                async with self._session.request(method, url, **merged_kwargs) as response:
                    return await response_handler(response, attempt, attempts)
            except self._RetryRequest:
                if attempt >= attempts - 1:
                    raise ProviderError("Request failed.") from None
                continue
            except (aiohttp.ClientError, TimeoutError) as exc:
                last_error = exc
                _LOGGER.warning(
                    ("Provider %s request error: %s (context=%s, target=%s, package_version=%s)"),
                    self.provider_id,
                    exc.__class__.__name__,
                    self._request_context_label(),
                    self._request_target_label(),
                    PACKAGE_VERSION,
                )
                if attempt >= attempts - 1:
                    raise NetworkError("Network request failed.") from exc
        if last_error is not None:
            raise NetworkError("Network request failed.") from last_error
        raise ProviderError("Request failed.")

    async def _request_json(self, method: str, path: str, **kwargs: Any) -> Any:
        url = self._build_url(path)
        return await self._request(method, url, expect_json=True, **kwargs)

    async def _request_text(self, method: str, path: str, **kwargs: Any) -> str:
        url = self._build_url(path)
        return await self._request(method, url, expect_json=False, **kwargs)

    async def _request(self, method: str, url: str, *, expect_json: bool, **kwargs: Any) -> Any:
        async def handle_response(
            response: aiohttp.ClientResponse,
            _attempt: int,
            _attempts: int,
        ) -> Any:
            _LOGGER.debug(
                "Provider %s response status=%s",
                self.provider_id,
                response.status,
            )
            self._raise_for_status(response)
            if expect_json:
                try:
                    return await response.json()
                except (aiohttp.ContentTypeError, ValueError) as exc:
                    raise ProviderError("Response did not contain valid JSON.") from exc
            return await response.text()

        return await self._request_with_retries(
            method,
            url,
            request_kwargs=kwargs,
            response_handler=handle_response,
        )

    def _raise_for_status(self, response: aiohttp.ClientResponse) -> None:
        if 200 <= response.status < 300:
            return
        _LOGGER.warning(
            (
                "Provider %s request failed with status %s "
                "(context=%s, target=%s, package_version=%s)"
            ),
            self.provider_id,
            response.status,
            self._request_context_label(),
            self._request_target_label(),
            PACKAGE_VERSION,
        )
        if response.status in (401, 403):
            raise AuthError("Authentication failed.")
        raise ProviderError(f"Provider request failed with status {response.status}.")

    def _normalize_base_url(self, base_url: str | None) -> str | None:
        if base_url is None:
            return None
        if not isinstance(base_url, str) or not base_url.strip():
            raise ValidationError("base_url must be a non-empty string.")
        return base_url.strip().rstrip("/")

    def _normalize_api_uri(self, api_uri: str | None) -> str:
        if api_uri is None:
            return ""
        if not isinstance(api_uri, str):
            raise ValidationError("api_uri must be a string.")
        normalized = api_uri.strip().strip("/")
        if not normalized:
            return ""
        return f"/{normalized}"

    @abstractmethod
    async def login(self, credentials: Mapping[str, str] | None = None, **kwargs: str) -> None:
        """Authenticate against the provider."""

    @abstractmethod
    async def get_permit(self) -> Permit:
        """Return the active permit for the account."""

    @abstractmethod
    async def list_reservations(self) -> list[Reservation]:
        """Return active reservations."""

    @abstractmethod
    async def start_reservation(
        self,
        license_plate: str,
        start_time: datetime,
        end_time: datetime,
        name: str | None = None,
    ) -> Reservation:
        """Start a reservation for a license plate."""

    @abstractmethod
    async def update_reservation(
        self,
        reservation_id: str,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
        name: str | None = None,
    ) -> Reservation:
        """Update a reservation."""

    @abstractmethod
    async def end_reservation(
        self,
        reservation_id: str,
        end_time: datetime,
    ) -> Reservation:
        """End a reservation."""

    @abstractmethod
    async def list_favorites(self) -> list[Favorite]:
        """Return stored favorites."""

    @abstractmethod
    async def add_favorite(self, license_plate: str, name: str | None = None) -> Favorite:
        """Add a favorite."""

    async def update_favorite(
        self,
        favorite_id: str,
        license_plate: str | None = None,
        name: str | None = None,
    ) -> Favorite:
        """Update a favorite."""
        if not self.favorite_update_possible:
            _LOGGER.info(
                "Provider %s favorite update requested but not supported",
                self.provider_id,
            )
            raise ProviderError("Favorite updates are not supported.")
        if license_plate is not None and "license_plate" not in self.favorite_update_fields:
            raise ValidationError("license_plate updates are not supported.")
        if name is not None and "name" not in self.favorite_update_fields:
            raise ValidationError("name updates are not supported.")
        _LOGGER.debug("Provider %s update_favorite started", self.provider_id)
        return await self._update_favorite_native(
            favorite_id,
            license_plate=license_plate,
            name=name,
        )

    @abstractmethod
    async def _update_favorite_native(
        self,
        favorite_id: str,
        license_plate: str | None = None,
        name: str | None = None,
    ) -> Favorite:
        """Native favorite update implementation for providers that support it."""

    @abstractmethod
    async def remove_favorite(self, favorite_id: str) -> None:
        """Remove a favorite."""
