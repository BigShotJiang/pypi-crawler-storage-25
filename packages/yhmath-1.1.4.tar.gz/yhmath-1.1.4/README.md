# yhmath
yhmath is a Python package specialized in mathematics. This is version 1.1.4.

Install
-
You can install yhmath by typing pip install yhmath in the command line: use CMD on Windows, Bash on Linux, or Zsh on macOS/Unix.

features
-
So far, yhmath can perform addition of numbers.

Usage
-
```python
import yhmath
result = yhmath.add([2, 3, 7])
print(result)
```
contact
-
mail: yusuffanpage13@gmail.com

yhmath github repo
-
https://github.com/YoussefHussein449/yhmath



