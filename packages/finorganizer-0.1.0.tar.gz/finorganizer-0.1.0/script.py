import os
import shutil
from mutagen import File
from mutagen.easyid3 import EasyID3
from mutagen.mp3 import MP3

AUDIO_EXTENSIONS = {".mp3", ".flac", ".opus", ".ogg", ".m4a", ".wav"}


class Track:
    def __init__(self, title, path):
        self.title = title
        self.path = path


class Album:
    def __init__(self, name):
        self.name = name
        self.tracks: list[Track] = []

    def add_track(self, track: Track):
        if any(t.title == track.title for t in self.tracks):
            return
        self.tracks.append(track)


class Artist:
    def __init__(self, name):
        self.name = name
        self.albums: dict[str, Album] = {}

    def add_track(self, album_name: str, track: Track):
        if album_name not in self.albums:
            self.albums[album_name] = Album(album_name)
        self.albums[album_name].add_track(track)


def read_tags(path):
    if path.lower().endswith(".mp3"):
        audio = MP3(path, ID3=EasyID3)
    else:
        audio = File(path)
    artist = audio.get("artist", ["Unknown Artist"])[0]
    album = audio.get("album", ["Unknown Album"])[0]
    title = audio.get("title", [os.path.basename(path)])[0]
    return artist, album, title


def scan_folders(folders: list[str]) -> dict[str, Artist]:
    artists: dict[str, Artist] = {}
    seen_paths: set[str] = set()

    for folder in folders:
        for root, _, files in os.walk(folder):
            for filename in files:
                if os.path.splitext(filename)[1].lower() not in AUDIO_EXTENSIONS:
                    continue
                path = os.path.realpath(os.path.join(root, filename))
                if path in seen_paths:
                    continue
                seen_paths.add(path)
                try:
                    artist_name, album_name, title = read_tags(path)
                    if artist_name == "Unknown Artist" or album_name == "Unknown Album":
                        continue
                    if artist_name not in artists:
                        artists[artist_name] = Artist(artist_name)
                    artists[artist_name].add_track(album_name, Track(title, path))
                except Exception:
                    pass

    return artists


def prompt_folders() -> list[str]:
    folders = []
    print("Enter source folders one by one (blank line when done):")
    while True:
        path = input("  Folder: ").strip()
        if not path:
            break
        if not os.path.isdir(path):
            print(f"  Not a valid directory: {path}")
            continue
        if path not in folders:
            folders.append(path)
    return folders


def print_library(artists: dict[str, Artist]) -> None:
    total = sum(
        len(album.tracks)
        for artist in artists.values()
        for album in artist.albums.values()
    )
    print(f"\nFound {len(artists)} artists, {total} tracks:\n")
    for artist_name in sorted(artists.keys()):
        print(f"  {artist_name}")
        for album_name in sorted(artists[artist_name].albums.keys()):
            tracks = artists[artist_name].albums[album_name].tracks
            print(f"    {album_name} ({len(tracks)} tracks)")


def copy_files(artists: dict[str, Artist], output_dir: str) -> None:
    all_tracks = [
        (artist, album, track)
        for artist in artists.values()
        for album in artist.albums.values()
        for track in album.tracks
    ]
    total = len(all_tracks)
    for i, (artist, album, track) in enumerate(all_tracks, 1):
        dest_dir = os.path.join(output_dir, artist.name, album.name)
        os.makedirs(dest_dir, exist_ok=True)
        ext = os.path.splitext(track.path)[1]
        dest = os.path.join(dest_dir, track.title + ext)
        shutil.copy2(track.path, dest)
        print(f"  [{i}/{total}] {track.title}")
    print(f"\nDone. {total} tracks copied to {output_dir}")


if __name__ == "__main__":
    folders = prompt_folders()
    if not folders:
        print("No folders provided, exiting.")
        raise SystemExit

    print("\nScanning...")
    artists = scan_folders(folders)

    if not artists:
        print("No tracks with complete metadata found.")
        raise SystemExit

    print_library(artists)

    output_dir = input("\nOutput directory [/home/toprak/Music]: ").strip() or "/home/toprak/Music"

    confirm = input(f"Copy to {output_dir}? [y/N]: ").strip().lower()
    if confirm == "y":
        copy_files(artists, output_dir)
