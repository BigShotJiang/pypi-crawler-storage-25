import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from cpsl.clients.capsule import ClaimTaskResponse, TaskDelivery
from cpsl.runner import Runner


class RunnerTaskDeliveryTests(unittest.IsolatedAsyncioTestCase):
    def runner(self) -> Runner:
        r = Runner.__new__(Runner)
        r._version_id = "serve-new"
        r._app_id = "app-1"
        r._tasks = {}

        async def track_start():
            r._tracked_start = True

        async def track_end():
            r._tracked_end = True

        r._track_start = track_start
        r._track_end = track_end
        return r

    async def test_stale_task_delivery_is_skipped_before_claim(self):
        r = self.runner()
        r._claim_called = False

        async def claim_task(_task_id):
            r._claim_called = True
            return True

        async def complete_task(*_args, **_kwargs):
            raise AssertionError("stale tasks must not be completed")

        r._claim_task = claim_task
        r._complete_task = complete_task

        await r._handle_task(
            TaskDelivery(
                task_id="task-old",
                task_name="work",
                version_id="serve-old",
            )
        )

        self.assertFalse(r._claim_called)
        self.assertTrue(r._tracked_start)
        self.assertTrue(r._tracked_end)

    async def test_versionless_task_delivery_is_skipped_for_serve_runner(self):
        r = self.runner()
        r._version_type = "serve"
        r._claim_called = False

        async def claim_task(_task_id):
            r._claim_called = True
            return True

        r._claim_task = claim_task
        await r._handle_task(TaskDelivery(task_id="legacy-task", task_name="work"))

        self.assertFalse(r._claim_called)

    async def test_claim_failure_skips_execution(self):
        r = self.runner()
        r._executed = False

        async def claim_task(_task_id):
            return False

        async def complete_task(*_args, **_kwargs):
            raise AssertionError("unclaimed tasks must not be completed")

        r._claim_task = claim_task
        r._complete_task = complete_task
        r._tasks["work"] = lambda: setattr(r, "_executed", True)

        await r._handle_task(
            TaskDelivery(
                task_id="task-1",
                task_name="work",
                version_id="serve-new",
            )
        )

        self.assertFalse(r._executed)

    async def test_claim_task_returns_false_when_server_rejects(self):
        r = self.runner()
        r._task_stub = type(
            "TaskStub",
            (),
            {"claim_task": staticmethod(lambda _req: ClaimTaskResponse(ok=False))},
        )()

        self.assertFalse(await r._claim_task("task-1"))


if __name__ == "__main__":
    unittest.main()
