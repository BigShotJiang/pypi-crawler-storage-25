import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import cpsl
from cpsl.utils import build_filesystem_mount_specs


class FileSystemConfigTests(unittest.TestCase):
    def test_filesystem_serializes_sources_and_tools(self):
        fs = (
            cpsl.FileSystem("customer-data")
            .smart_source("gmail", "priority-mail", guidance="Important customers")
            .source_query("gdrive", "contracts", filter={"mimeType": "application/pdf"})
            .mcp("browser", command="npx", args=["browser-mcp"], env={"TOKEN": "secret"})
        )

        data = fs.to_dict()

        self.assertEqual(data["name"], "customer-data")
        self.assertEqual(data["sources"][0]["mode"], "smart")
        self.assertEqual(data["sources"][1]["mode"], "query")
        self.assertEqual(data["sources"][1]["filter"], {"mimeType": "application/pdf"})
        self.assertEqual(data["tools"][0]["kind"], "mcp")

    def test_build_filesystem_mount_specs(self):
        fs = cpsl.FileSystem("customer-data").source_query(
            "gmail",
            "vip-mail",
            filter={"q": "from:vip@example.com"},
            cache_ttl=60,
        )

        mounts = build_filesystem_mount_specs({"/data": fs.to_dict()})

        self.assertEqual(len(mounts), 1)
        self.assertEqual(mounts[0].mount_path, "/data")
        self.assertEqual(mounts[0].name, "customer-data")
        self.assertEqual(mounts[0].sources[0].filter, '{"q": "from:vip@example.com"}')
        self.assertEqual(mounts[0].sources[0].cache_ttl, 60)


if __name__ == "__main__":
    unittest.main()
