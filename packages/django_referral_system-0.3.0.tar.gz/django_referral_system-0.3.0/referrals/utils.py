from typing import Any
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse


def append_query_params(url: str, params: dict[str, Any]) -> str:
    """
    Appends query parameters to a given URL.

    Args:
        url (str): The base URL to which query parameters will be added.
        params (dict[str, Any]): A dictionary of query parameters to add to the URL.

    Returns:
        str: The modified URL with the new query parameters appended.
    """
    url_parts = list(urlparse(url))
    query = dict(parse_qs(url_parts[4]))
    for key, value in params.items():
        if key in query:
            query[key].extend([value] if not isinstance(value, list) else value)
        else:
            query[key] = [value] if not isinstance(value, list) else value

    url_parts[4] = urlencode(query, doseq=True)
    return urlunparse(url_parts)
