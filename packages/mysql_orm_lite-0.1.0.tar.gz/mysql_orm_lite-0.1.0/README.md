# MySQL ORM

Simple mysql orm

High Abstraction. Uses MySQL Connector/Python (Database Driver), connects with sql server.

## Features

- CRUD Operations (`update()`, `updateAll()`)
- `where(column, value)` Filter results based on specific conditions (chainable).
- Relationshp
- Handles Security (less risky) Principle of Least Privilege
- Handle Transactions & Pooling (TODO: `DatabaseManager` _pool = None)

## Example

call Python methods: `User.find_all()`. It translates that method call into SQL, executes it via the driver, and turns the results into `User` objects automatically.

## TODO

- Implement `pytest`

<!-- 

```bash
# Local testing of a package
pip install -e <relative path>

# Publish
python3 -m pip install --upgrade build
python3 -m build
twine upload dist/*
``` 
# resolve path with

CTRL shift P > select Interpreter

> .vscode/settings.json
  "python.analysis.extraPaths": ["../mysql-orm"]

-->