"""Integration test: MCP server handshake."""

from __future__ import annotations

from fovea.core.tool_registry import list_tool_names
from fovea.server import mcp


def test_mcp_server_has_name() -> None:
    """MCP server should have the correct name."""
    assert mcp.name == "fovea"


def test_mcp_server_has_version() -> None:
    """MCP server should report a version."""
    from fovea import __version__

    assert mcp.version == __version__


def test_mcp_server_has_tools() -> None:
    """MCP server should register every release tool with basic metadata."""
    tools = list_tool_names()

    assert len(tools) == 28
    for tool_name in tools:
        assert tool_name
        assert "_" in tool_name or tool_name.startswith("fovea")
    assert mcp.name == "fovea"
