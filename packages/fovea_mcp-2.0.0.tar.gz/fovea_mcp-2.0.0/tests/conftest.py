"""Shared pytest fixtures and configuration."""

from __future__ import annotations

from pathlib import Path

import pytest


@pytest.fixture()
def tmp_fovea_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Provide a temporary FOVEA_HOME directory for tests."""
    fovea_home = tmp_path / ".fovea"
    fovea_home.mkdir()
    monkeypatch.setenv("FOVEA_HOME", str(fovea_home))
    return fovea_home


@pytest.fixture()
def mini_yolo_path() -> Path:
    """Return path to the mini YOLO fixture dataset."""
    return Path(__file__).parent / "fixtures" / "mini_yolo"


@pytest.fixture()
def mini_coco_path() -> Path:
    """Return path to the mini COCO fixture dataset."""
    return Path(__file__).parent / "fixtures" / "mini_coco"


@pytest.fixture()
def corrupt_samples_path() -> Path:
    """Return path to the corrupt samples fixture."""
    return Path(__file__).parent / "fixtures" / "corrupt_samples"
