"""Unit tests for fovea.core.errors."""

from __future__ import annotations

from fovea.core.errors import (
    FoveaCheckpointNotFoundError,
    FoveaDatasetEmptyError,
    FoveaDatasetFormatError,
    FoveaDatasetNotFoundError,
    FoveaError,
    FoveaExportParityError,
    FoveaRtspConnectionError,
)


def test_base_error_str() -> None:
    """FoveaError __str__ should include code and message."""
    err = FoveaError("something went wrong")
    assert "FOVEA_000" in str(err)
    assert "something went wrong" in str(err)


def test_base_error_with_hint() -> None:
    """FoveaError with hint should include the hint."""
    err = FoveaError("bad input", hint="try this instead")
    assert "try this instead" in str(err)


def test_dataset_not_found_code() -> None:
    """FoveaDatasetNotFoundError should have the right code."""
    err = FoveaDatasetNotFoundError("/nonexistent/path")
    assert err.code == "FOVEA_DATASET_001"
    assert "/nonexistent/path" in str(err)


def test_dataset_empty_code() -> None:
    """FoveaDatasetEmptyError should have the right code."""
    err = FoveaDatasetEmptyError("/empty/path")
    assert err.code == "FOVEA_DATASET_003"


def test_checkpoint_not_found_code() -> None:
    """FoveaCheckpointNotFoundError should have the right code."""
    err = FoveaCheckpointNotFoundError("/missing/best.pt")
    assert err.code == "FOVEA_EVAL_001"


def test_rtsp_error_code() -> None:
    """FoveaRtspConnectionError should have the right code."""
    err = FoveaRtspConnectionError("rtsp://192.168.1.1/stream")
    assert err.code == "FOVEA_INFER_001"
    assert "rtsp://" in str(err)


def test_error_hierarchy() -> None:
    """All errors should be subclasses of FoveaError."""
    for cls in [
        FoveaDatasetNotFoundError,
        FoveaDatasetFormatError,
        FoveaDatasetEmptyError,
        FoveaCheckpointNotFoundError,
        FoveaExportParityError,
        FoveaRtspConnectionError,
    ]:
        assert issubclass(cls, FoveaError)
