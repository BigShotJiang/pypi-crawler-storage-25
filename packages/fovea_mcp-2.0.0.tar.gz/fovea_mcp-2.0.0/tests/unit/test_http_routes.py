"""Tests for HTTP routes and SSE metric streaming."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from fovea.core.errors import FoveaDatasetNotFoundError
from fovea.core.paths import ensure_fovea_dirs
from fovea.core.runs import RunRegistry
from fovea.http.app import create_app
from fovea.http.routes import (
    _load_metric_payload_delta,
    _load_metric_payloads,
    _load_metrics_jsonl,
    _metric_event_stream,
    _resolve_run_dir,
)


def _seed_run(tmp_fovea_home: Path, run_id: str = "run_stream") -> tuple[Path, RunRegistry]:
    paths = ensure_fovea_dirs(tmp_fovea_home)
    registry = RunRegistry(paths.runs_db)
    run_dir = paths.runs / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    registry.create_run(
        run_id=run_id,
        run_path=run_dir,
        model="yolov8n.pt",
        dataset_path=tmp_fovea_home / "dataset",
        task="detect",
        epochs=2,
        tags=[],
    )
    registry.update_status(run_id, "running", pid=1234)
    return run_dir, registry


def _auth_headers(client: TestClient) -> dict[str, str]:
    token = str(client.app.state.auth_token)
    return {"Authorization": f"Bearer {token}"}


def test_metrics_sse_streams_appended_rows(tmp_fovea_home: Path) -> None:
    """Metric event stream should emit newly appended rows."""
    run_dir, _registry = _seed_run(tmp_fovea_home)
    metrics_jsonl = run_dir / "metrics.jsonl"
    metrics_jsonl.write_text(
        '{"run_id": "run_stream", "epoch": 1, "metrics": {"metrics/mAP50(B)": 0.42}}\n',
        encoding="utf-8",
    )

    async def disconnected() -> bool:
        return False

    async def consume_stream() -> list[dict[str, object]]:
        shutdown_event = asyncio.Event()
        payloads: list[dict[str, object]] = []
        initial_size = metrics_jsonl.stat().st_size

        stream = _metric_event_stream(
            run_id="run_stream",
            run_dir=run_dir,
            disconnect_check=disconnected,
            shutdown_event=shutdown_event,
        )
        retry = await anext(stream)
        assert retry == "retry: 5000\n\n"
        first = await anext(stream)
        payloads.append(json.loads(first.split("data: ", maxsplit=1)[1]))
        with metrics_jsonl.open("a", encoding="utf-8") as handle:
            handle.write(
                '{"run_id": "run_stream", "epoch": 2, "metrics": {"metrics/mAP50(B)": 0.55}}\n'
            )
        _, _, delta_payloads = _load_metric_payload_delta(
            "run_stream",
            run_dir,
            emitted_count=1,
            previous_offset=initial_size,
        )
        payloads.extend(delta_payloads)
        shutdown_event.set()
        await stream.aclose()
        return payloads

    payloads = asyncio.run(consume_stream())
    assert [payload["epoch"] for payload in payloads] == [1, 2]
    assert payloads[-1]["runId"] == "run_stream"


def test_metrics_sse_missing_run_returns_404(tmp_fovea_home: Path) -> None:
    """Unknown run IDs should return 404 from the metrics endpoint."""
    with TestClient(create_app()) as client:
        response = client.get("/runs/does-not-exist/metrics", headers=_auth_headers(client))
    assert response.status_code == 404


def test_tool_proxy_invokes_local_tool(tmp_fovea_home: Path) -> None:
    """POST /tools/{name} should proxy to the local tool implementation."""
    with TestClient(create_app()) as client:
        response = client.post("/tools/model_list", json={}, headers=_auth_headers(client))
    assert response.status_code == 200
    payload = response.json()
    assert payload["total"] == 0


def test_health_endpoint_returns_version(tmp_fovea_home: Path) -> None:
    """The health endpoint should advertise a healthy server and package version."""
    with TestClient(create_app()) as client:
        response = client.get("/health")

    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_vscode_webview_origin_can_preflight_authenticated_routes(
    tmp_fovea_home: Path,
) -> None:
    """VS Code webviews should be allowed to call the local authenticated API."""
    with TestClient(create_app()) as client:
        response = client.options(
            "/runs",
            headers={
                "Origin": "vscode-webview://fovea-demo",
                "Access-Control-Request-Method": "GET",
                "Access-Control-Request-Headers": "authorization,content-type",
            },
        )

    assert response.status_code == 200
    assert response.headers["access-control-allow-origin"] == "vscode-webview://fovea-demo"
    assert "Authorization" in response.headers["access-control-allow-headers"]


def test_prometheus_metrics_requires_explicit_enable(tmp_fovea_home: Path) -> None:
    """The Prometheus snapshot endpoint should be opt-in."""
    with TestClient(create_app()) as client:
        disabled = client.get("/metrics", headers=_auth_headers(client))

    assert disabled.status_code == 404

    _seed_run(tmp_fovea_home, run_id="run_metrics_endpoint")
    with TestClient(create_app(enable_metrics=True)) as client:
        enabled = client.get("/metrics", headers=_auth_headers(client))

    assert enabled.status_code == 200
    assert "fovea_active_runs 1" in enabled.text


def test_list_runs_returns_seeded_records(tmp_fovea_home: Path) -> None:
    """Run listing should surface seeded registry records."""
    _seed_run(tmp_fovea_home, run_id="run_listed")

    with TestClient(create_app()) as client:
        response = client.get("/runs", headers=_auth_headers(client))

    assert response.status_code == 200
    payload = response.json()[0]
    assert payload["id"] == "run_listed"
    assert "current_epoch" in payload
    assert "best_map50" in payload


def test_list_runs_prefers_worker_status_file(tmp_fovea_home: Path) -> None:
    """Run listing should not show stale SQLite status when the worker wrote a terminal state."""
    run_dir, _registry = _seed_run(tmp_fovea_home, run_id="run_failed")
    (run_dir / "status.json").write_text('{"status": "failed"}', encoding="utf-8")

    with TestClient(create_app()) as client:
        response = client.get("/runs", headers=_auth_headers(client))

    assert response.status_code == 200
    payload = response.json()
    assert payload[0]["id"] == "run_failed"
    assert payload[0]["status"] == "failed"


def test_get_run_returns_current_epoch_and_metrics(tmp_fovea_home: Path) -> None:
    """Single-run metadata should include the most recent epoch and mAP value."""
    run_dir, _registry = _seed_run(tmp_fovea_home, run_id="run_details")
    (run_dir / "results.csv").write_text(
        "epoch,metrics/mAP50(B)\n0,0.40\n1,0.62\n",
        encoding="utf-8",
    )

    with TestClient(create_app()) as client:
        response = client.get("/runs/run_details", headers=_auth_headers(client))

    assert response.status_code == 200
    payload = response.json()
    assert payload["id"] == "run_details"
    assert payload["current_epoch"] == 2
    assert payload["best_map50"] == pytest.approx(0.62)


def test_get_run_missing_returns_404(tmp_fovea_home: Path) -> None:
    """Unknown runs should surface a not-found response."""
    with TestClient(create_app()) as client:
        response = client.get("/runs/ghost", headers=_auth_headers(client))

    assert response.status_code == 404


def test_tool_proxy_unknown_tool_returns_404(tmp_fovea_home: Path) -> None:
    """Unknown tool names should list the available HTTP-proxied tools."""
    with TestClient(create_app()) as client:
        response = client.post("/tools/ghost_tool", json={}, headers=_auth_headers(client))

    assert response.status_code == 404
    payload = response.json()["detail"]
    assert "available_tools" in payload
    assert "model_list" in payload["available_tools"]


def test_tool_proxy_fovea_error_returns_400(tmp_fovea_home: Path) -> None:
    """Fovea errors should be serialized as HTTP 400 responses."""
    with (
        patch(
            "fovea.http.tool_proxy.invoke_tool",
            side_effect=FoveaDatasetNotFoundError("/missing/dataset"),
        ),
        TestClient(create_app()) as client,
    ):
        response = client.post("/tools/model_list", json={}, headers=_auth_headers(client))

    assert response.status_code == 400
    detail = response.json()["detail"]
    assert detail["code"].startswith("FOVEA_DATASET_")


def test_resolve_run_dir_returns_registered_path(tmp_fovea_home: Path) -> None:
    """Internal run resolution should point to the registered run directory."""
    run_dir, _registry = _seed_run(tmp_fovea_home, run_id="run_dir")

    assert _resolve_run_dir("run_dir") == run_dir


def test_load_metrics_jsonl_skips_invalid_rows(tmp_path: Path) -> None:
    """JSONL metric loading should ignore blank and malformed lines."""
    run_dir = tmp_path / "run_jsonl"
    run_dir.mkdir()
    (run_dir / "metrics.jsonl").write_text(
        (
            '\n{"run_id": "run_jsonl", "epoch": 1, "metrics": {"metrics/mAP50(B)": 0.33}}\n'
            'not-json\n{"metrics": {"metrics/precision(B)": 0.71}}\n'
        ),
        encoding="utf-8",
    )

    payloads = _load_metrics_jsonl("run_jsonl", run_dir)

    assert payloads == [
        {
            "runId": "run_jsonl",
            "epoch": 1,
            "metrics": {"metrics/mAP50(B)": 0.33},
            "wall_time_s": 0.0,
            "eta_s": 0.0,
        },
    ]


def test_load_metric_payloads_falls_back_to_metrics_jsonl(tmp_path: Path) -> None:
    """When CSV metrics are absent, the SSE loader should fall back to metrics.jsonl."""
    run_dir = tmp_path / "run_metrics"
    run_dir.mkdir()
    (run_dir / "metrics.jsonl").write_text(
        '{"run_id": "run_metrics", "epoch": 2, "metrics": {"metrics/mAP50(B)": 0.48}}\n'
    )

    payloads = _load_metric_payloads("run_metrics", run_dir)

    assert payloads == [
        {
            "runId": "run_metrics",
            "epoch": 2,
            "metrics": {"metrics/mAP50(B)": 0.48},
            "wall_time_s": 0.0,
            "eta_s": 0.0,
        },
    ]


def test_metric_event_stream_emits_keepalive_when_idle(tmp_path: Path) -> None:
    """Idle metric streams should emit heartbeat comments to keep SSE clients alive."""
    run_dir = tmp_path / "run_keepalive"
    run_dir.mkdir()

    async def disconnected() -> bool:
        return False

    async def immediate_timeout(awaitable: object, timeout: float) -> object:
        del timeout
        close = getattr(awaitable, "close", None)
        if callable(close):
            close()
        raise TimeoutError

    async def consume_stream() -> str:
        shutdown_event = asyncio.Event()
        stream = _metric_event_stream(
            run_id="run_keepalive",
            run_dir=run_dir,
            disconnect_check=disconnected,
            shutdown_event=shutdown_event,
        )
        with patch("fovea.http.routes.asyncio.wait_for", side_effect=immediate_timeout):
            retry = await anext(stream)
            assert retry == "retry: 5000\n\n"
            heartbeat = await anext(stream)
        shutdown_event.set()
        await stream.aclose()
        return heartbeat

    heartbeat = asyncio.run(consume_stream())
    assert heartbeat == ": keep-alive\n\n"


def test_metric_event_stream_stops_on_disconnect(tmp_path: Path) -> None:
    """Disconnected clients should stop the async metric stream cleanly."""
    run_dir = tmp_path / "run_disconnect"
    run_dir.mkdir()

    async def disconnected() -> bool:
        return True

    async def consume_stream() -> None:
        shutdown_event = asyncio.Event()
        stream = _metric_event_stream(
            run_id="run_disconnect",
            run_dir=run_dir,
            disconnect_check=disconnected,
            shutdown_event=shutdown_event,
        )
        retry = await anext(stream)
        assert retry == "retry: 5000\n\n"
        with pytest.raises(StopAsyncIteration):
            await anext(stream)

    asyncio.run(consume_stream())
