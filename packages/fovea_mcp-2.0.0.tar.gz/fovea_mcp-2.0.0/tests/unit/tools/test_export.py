"""Tests for export and quantization tools."""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np
import pytest

from fovea.core.errors import (
    FoveaCheckpointNotFoundError,
    FoveaDatasetNotFoundError,
    FoveaExportParityError,
)
from fovea.schemas.export import (
    ExportOnnxInput,
    ExportTfliteInput,
    QuantizeInt8Input,
    QuantizeReportInput,
)
from fovea.tools import export_onnx as export_onnx_module
from fovea.tools.export_onnx import (
    _check_parity,
    _run_export_onnx,
    _yolo_export_onnx,
)
from fovea.tools.export_tflite import _run_export_tflite
from fovea.tools.quantize_int8 import _run_quantize_int8
from fovea.tools.quantize_report import _run_quantize_report

FIXTURES = Path(__file__).parent.parent.parent / "fixtures"


def _make_pt(tmp_path: Path, name: str = "best.pt", size: int = 1024) -> Path:
    pt = tmp_path / name
    pt.write_bytes(b"x" * size)
    return pt


def _make_onnx(tmp_path: Path, name: str = "best.onnx", size: int = 512) -> Path:
    onnx = tmp_path / name
    onnx.write_bytes(b"o" * size)
    return onnx


# ── export_onnx ───────────────────────────────────────────────────────────────


def test_export_onnx_missing_checkpoint_raises(tmp_path, monkeypatch):
    monkeypatch.setenv("FOVEA_HOME", str(tmp_path))
    with pytest.raises(FoveaCheckpointNotFoundError):
        _run_export_onnx(ExportOnnxInput(checkpoint="/no/model.pt", parity_check=False))


def test_export_onnx_returns_output(tmp_path, monkeypatch):
    monkeypatch.setenv("FOVEA_HOME", str(tmp_path))
    pt = _make_pt(tmp_path)
    onnx = _make_onnx(tmp_path)

    with patch("fovea.tools.export_onnx._yolo_export_onnx", return_value=onnx):
        out = _run_export_onnx(ExportOnnxInput(checkpoint=str(pt), parity_check=False))

    assert out.onnx_path == onnx
    assert out.model_size_bytes == 512
    assert out.parity_passed is None


def test_export_onnx_parity_check_passes(tmp_path, monkeypatch):
    monkeypatch.setenv("FOVEA_HOME", str(tmp_path))
    pt = _make_pt(tmp_path)
    onnx = _make_onnx(tmp_path)

    with (
        patch("fovea.tools.export_onnx._yolo_export_onnx", return_value=onnx),
        patch("fovea.tools.export_onnx._check_parity", return_value=(True, 1e-5)),
    ):
        out = _run_export_onnx(ExportOnnxInput(checkpoint=str(pt), parity_check=True))

    assert out.parity_passed is True


def test_export_onnx_parity_failure_raises(tmp_path, monkeypatch):
    monkeypatch.setenv("FOVEA_HOME", str(tmp_path))
    pt = _make_pt(tmp_path)
    onnx = _make_onnx(tmp_path)

    with (
        patch("fovea.tools.export_onnx._yolo_export_onnx", return_value=onnx),
        patch("fovea.tools.export_onnx._check_parity", return_value=(False, 0.5)),
    ):
        with pytest.raises(FoveaExportParityError):
            _run_export_onnx(ExportOnnxInput(checkpoint=str(pt), parity_check=True))


def test_yolo_export_onnx_moves_result_to_requested_output(tmp_path, monkeypatch):
    monkeypatch.setenv("FOVEA_HOME", str(tmp_path))
    pt = _make_pt(tmp_path)
    exported = _make_onnx(tmp_path, "raw.onnx")
    target = tmp_path / "exports" / "model.onnx"
    fake_model = SimpleNamespace(export=lambda **_kwargs: exported)

    with patch("fovea.tools.export_onnx.load_yolo_model", return_value=fake_model):
        output = _yolo_export_onnx(
            pt,
            ExportOnnxInput(checkpoint=str(pt), output_path=target, parity_check=False),
        )

    assert output == target
    assert target.exists()
    assert not exported.exists()


def test_check_parity_compares_outputs(tmp_path, monkeypatch):
    monkeypatch.setenv("FOVEA_HOME", str(tmp_path))
    pt = _make_pt(tmp_path)
    onnx = _make_onnx(tmp_path)

    class _RawModel:
        def eval(self) -> None:
            return None

        def __call__(self, tensor: object) -> np.ndarray:
            return np.ones((1, 3, 640, 640), dtype=np.float32)

    raw_model = _RawModel()
    pt_model = SimpleNamespace(model=raw_model)
    session = SimpleNamespace(
        get_inputs=lambda: [SimpleNamespace(name="images")],
        run=lambda *_args, **_kwargs: [np.ones((1, 3, 640, 640), dtype=np.float32)],
    )
    fake_ort = SimpleNamespace(InferenceSession=lambda *_args, **_kwargs: session)

    with (
        patch("importlib.import_module", return_value=fake_ort),
        patch.object(export_onnx_module, "load_yolo_model", return_value=pt_model),
    ):
        passed, max_diff = _check_parity(
            pt,
            onnx,
            ExportOnnxInput(checkpoint=str(pt), parity_tolerance=1e-4),
        )

    assert passed is True
    assert max_diff == pytest.approx(0.0)


def test_check_parity_runtime_error_raises(tmp_path, monkeypatch):
    monkeypatch.setenv("FOVEA_HOME", str(tmp_path))
    pt = _make_pt(tmp_path)
    onnx = _make_onnx(tmp_path)

    with patch("importlib.import_module", side_effect=RuntimeError("boom")):
        with pytest.raises(FoveaExportParityError, match="could not be executed"):
            _check_parity(
                pt,
                onnx,
                ExportOnnxInput(checkpoint=str(pt), parity_tolerance=1e-4),
            )


# ── export_tflite ─────────────────────────────────────────────────────────────


def test_export_tflite_returns_output(tmp_path, monkeypatch):
    monkeypatch.setenv("FOVEA_HOME", str(tmp_path))
    pt = _make_pt(tmp_path)
    tflite = tmp_path / "best.tflite"
    tflite.write_bytes(b"t" * 256)

    with patch("fovea.tools.export_tflite._yolo_export_tflite", return_value=tflite):
        out = _run_export_tflite(ExportTfliteInput(checkpoint=str(pt)))

    assert out.tflite_path == tflite
    assert out.model_size_bytes == 256


def test_export_tflite_missing_checkpoint_raises(tmp_path, monkeypatch):
    monkeypatch.setenv("FOVEA_HOME", str(tmp_path))
    with pytest.raises(FoveaCheckpointNotFoundError):
        _run_export_tflite(ExportTfliteInput(checkpoint="/no/model.pt"))


# ── quantize_int8 ─────────────────────────────────────────────────────────────


def test_quantize_int8_missing_dataset_raises(tmp_path, monkeypatch):
    monkeypatch.setenv("FOVEA_HOME", str(tmp_path))
    pt = _make_pt(tmp_path)
    with pytest.raises(FoveaDatasetNotFoundError):
        _run_quantize_int8(
            QuantizeInt8Input(
                checkpoint=str(pt),
                calibration_dataset=Path("/no/dataset"),
            )
        )


def test_quantize_int8_returns_output(tmp_path, monkeypatch):
    monkeypatch.setenv("FOVEA_HOME", str(tmp_path))
    pt = _make_pt(tmp_path, size=2048)
    quant = tmp_path / "quant.onnx"
    quant.write_bytes(b"q" * 512)

    with patch("fovea.tools.quantize_int8._yolo_quantize_int8", return_value=quant):
        out = _run_quantize_int8(
            QuantizeInt8Input(
                checkpoint=str(pt),
                calibration_dataset=FIXTURES / "mini_yolo",
            )
        )

    assert out.quantized_path == quant
    assert out.size_reduction_pct == pytest.approx(75.0)


# ── quantize_report ───────────────────────────────────────────────────────────


def test_quantize_report_computes_delta(tmp_path, monkeypatch):
    monkeypatch.setenv("FOVEA_HOME", str(tmp_path))
    pt_orig = _make_pt(tmp_path, "orig.pt", size=4096)
    pt_quant = _make_pt(tmp_path, "quant.pt", size=1024)

    from types import SimpleNamespace

    def _fake_eval(inp):
        map50 = 0.75 if "orig" in inp.checkpoint else 0.72
        return SimpleNamespace(
            map50=map50,
            map50_95=map50 - 0.1,
            precision=0.8,
            recall=0.75,
            per_class=[],
            eval_duration_seconds=0.1,
        )

    with patch("fovea.tools.quantize_report._run_eval", side_effect=_fake_eval):
        out = _run_quantize_report(
            QuantizeReportInput(
                original_checkpoint=str(pt_orig),
                quantized_checkpoint=str(pt_quant),
                dataset_path=FIXTURES / "mini_yolo",
            )
        )

    assert abs(out.map50_delta - (-0.03)) < 1e-6
    assert out.size_reduction_pct == pytest.approx(75.0)
