"""Unit tests for fovea.core.paths."""

from __future__ import annotations

from pathlib import Path

import pytest

from fovea.core.paths import FoveaPaths, ensure_fovea_dirs, get_fovea_home


def test_get_fovea_home_from_env(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """FOVEA_HOME env var should take priority."""
    custom = tmp_path / "custom_fovea"
    monkeypatch.setenv("FOVEA_HOME", str(custom))
    result = get_fovea_home()
    assert result == custom.resolve()


def test_get_fovea_home_default(monkeypatch: pytest.MonkeyPatch) -> None:
    """Without env var, should default to ~/.fovea."""
    monkeypatch.delenv("FOVEA_HOME", raising=False)
    result = get_fovea_home()
    assert result.name == ".fovea"


def test_fovea_paths_structure(tmp_path: Path) -> None:
    """FoveaPaths should expose the expected subdirectory attributes."""
    paths = FoveaPaths(tmp_path)
    assert paths.runs == tmp_path / "runs"
    assert paths.models == tmp_path / "models"
    assert paths.cache == tmp_path / "cache"
    assert paths.exports == tmp_path / "exports"
    assert paths.datasets == tmp_path / "datasets"
    assert paths.runs_db == tmp_path / "runs.db"
    assert paths.config_file == tmp_path / "config.toml"


def test_ensure_fovea_dirs_creates_directories(tmp_path: Path) -> None:
    """ensure_fovea_dirs should create all required subdirectories."""
    paths = ensure_fovea_dirs(home=tmp_path)
    assert paths.runs.is_dir()
    assert paths.models.is_dir()
    assert paths.cache.is_dir()
    assert paths.exports.is_dir()
    assert paths.datasets.is_dir()


def test_run_dir(tmp_path: Path) -> None:
    """run_dir should return the correct path for a run."""
    paths = FoveaPaths(tmp_path)
    run_dir = paths.run_dir("run_2026-04-20_142301")
    assert run_dir == tmp_path / "runs" / "run_2026-04-20_142301"
