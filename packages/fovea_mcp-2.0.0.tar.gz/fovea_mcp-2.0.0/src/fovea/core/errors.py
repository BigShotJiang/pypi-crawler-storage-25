"""Fovea exception hierarchy.

All exceptions raised by Fovea tools are subclasses of FoveaError.
External library exceptions (ultralytics, cv2, onnx) must never bubble up raw.
"""

from __future__ import annotations


class FoveaError(Exception):
    """Base exception for all Fovea errors.

    Attributes:
        code: Stable error code string (e.g. FOVEA_DATASET_001).
        message: Human-readable description.
        hint: Optional remediation hint for the user.
    """

    code: str = "FOVEA_000"

    def __init__(self, message: str, hint: str | None = None) -> None:
        """Initialize FoveaError.

        Args:
            message: Human-readable error description.
            hint: Optional remediation hint.
        """
        super().__init__(message)
        self.message = message
        self.hint = hint

    def __str__(self) -> str:
        """Return formatted error string."""
        base = f"[{self.code}] {self.message}"
        if self.hint:
            return f"{base}\nHint: {self.hint}"
        return base


# Dataset errors (FOVEA_DATASET_*)


class FoveaDatasetError(FoveaError):
    """Base class for dataset-related errors."""

    code = "FOVEA_DATASET_000"


class FoveaDatasetNotFoundError(FoveaDatasetError):
    """Dataset path does not exist."""

    code = "FOVEA_DATASET_001"

    def __init__(self, path: str) -> None:
        """Initialize with the missing path."""
        super().__init__(
            f"Dataset path not found: {path}",
            hint="Check that the path exists and is accessible.",
        )


class FoveaDatasetFormatError(FoveaDatasetError):
    """Dataset format cannot be detected or is malformed."""

    code = "FOVEA_DATASET_002"


class FoveaDatasetEmptyError(FoveaDatasetError):
    """Dataset contains zero images."""

    code = "FOVEA_DATASET_003"

    def __init__(self, path: str) -> None:
        """Initialize with the empty dataset path."""
        super().__init__(
            f"Dataset at {path} contains no images.",
            hint="Ensure the dataset root contains image files (jpg, png, bmp, webp).",
        )


# Training errors (FOVEA_TRAIN_*)


class FoveaTrainingError(FoveaError):
    """Base class for training-related errors."""

    code = "FOVEA_TRAIN_000"


class FoveaTrainingRunNotFoundError(FoveaTrainingError):
    """Run ID does not exist in the registry."""

    code = "FOVEA_TRAIN_001"

    def __init__(self, run_id: str) -> None:
        """Initialize with the missing run_id."""
        super().__init__(
            f"Run not found: {run_id}",
            hint="Use `model_list` to see available runs.",
        )


class FoveaTrainingAlreadyRunningError(FoveaTrainingError):
    """Attempt to start training on an already-running run."""

    code = "FOVEA_TRAIN_002"


class FoveaTrainingSubprocessError(FoveaTrainingError):
    """Training subprocess exited with non-zero code."""

    code = "FOVEA_TRAIN_003"


# Evaluation errors (FOVEA_EVAL_*)


class FoveaEvalError(FoveaError):
    """Base class for evaluation-related errors."""

    code = "FOVEA_EVAL_000"


class FoveaCheckpointNotFoundError(FoveaEvalError):
    """Checkpoint file does not exist."""

    code = "FOVEA_EVAL_001"

    def __init__(self, path: str) -> None:
        """Initialize with the missing checkpoint path."""
        super().__init__(
            f"Checkpoint not found: {path}",
            hint="Provide a valid .pt file path or a run_id with a best.pt.",
        )


# Export errors (FOVEA_EXPORT_*)


class FoveaExportError(FoveaError):
    """Base class for export-related errors."""

    code = "FOVEA_EXPORT_000"


class FoveaExportParityError(FoveaExportError):
    """Roundtrip parity check failed after export."""

    code = "FOVEA_EXPORT_001"


# Inference errors (FOVEA_INFER_*)


class FoveaInferenceError(FoveaError):
    """Base class for inference-related errors."""

    code = "FOVEA_INFER_000"


class FoveaRtspConnectionError(FoveaInferenceError):
    """RTSP stream could not be opened."""

    code = "FOVEA_INFER_001"

    def __init__(self, url: str) -> None:
        """Initialize with the failing RTSP URL."""
        super().__init__(
            f"Could not open RTSP stream: {url}",
            hint="Verify the stream URL, network connectivity, and credentials.",
        )


# Config errors (FOVEA_CONFIG_*)


class FoveaConfigError(FoveaError):
    """Base class for configuration errors."""

    code = "FOVEA_CONFIG_000"


class FoveaPathValidationError(FoveaConfigError):
    """Raised when a filesystem path violates local safety checks."""

    code = "FOVEA_CONFIG_001"

    def __init__(self, path: str, reason: str, hint: str | None = None) -> None:
        """Initialize the path validation error."""
        super().__init__(
            f"Path validation failed for {path}: {reason}",
            hint=hint or "Use a path inside the intended project or dataset root.",
        )
