"""Local-first telemetry configuration helpers.

Telemetry is disabled by default and never sends data unless explicitly enabled.
"""

from __future__ import annotations

import os
import tomllib
from pathlib import Path
from typing import Any

import tomli_w

from fovea.config import clear_config_cache, load_config
from fovea.core.paths import get_fovea_home


def telemetry_status() -> dict[str, object]:
    """Return effective telemetry status without sending network traffic."""
    config = load_config()
    return {
        "enabled": config.telemetry_enabled,
        "configured_enabled": config.telemetry.enabled,
        "endpoint": config.telemetry.endpoint,
        "hard_disabled": bool(os.environ.get("FOVEA_NO_TELEMETRY", "").strip()),
    }


def set_telemetry(*, enabled: bool, endpoint: str | None = None) -> dict[str, object]:
    """Persist telemetry configuration under FOVEA_HOME/config.toml."""
    config_path = get_fovea_home() / "config.toml"
    raw = _read_config(config_path)
    fovea = raw.setdefault("fovea", {})
    if not isinstance(fovea, dict):
        fovea = {}
        raw["fovea"] = fovea
    telemetry = fovea.setdefault("telemetry", {})
    if not isinstance(telemetry, dict):
        telemetry = {}
        fovea["telemetry"] = telemetry
    telemetry["enabled"] = enabled
    if endpoint is not None:
        telemetry["endpoint"] = endpoint

    config_path.parent.mkdir(parents=True, exist_ok=True)
    with config_path.open("wb") as handle:
        tomli_w.dump(raw, handle)
    clear_config_cache()
    return telemetry_status()


def _read_config(config_path: Path) -> dict[str, Any]:
    if not config_path.exists():
        return {}
    with config_path.open("rb") as handle:
        return dict(tomllib.load(handle))
