"""Shared environment diagnostics for the CLI and MCP tool surface."""

from __future__ import annotations

import importlib
import shutil
import sys
from pathlib import Path

import httpx

from fovea.core.paths import FoveaPaths, ensure_fovea_dirs, get_fovea_home
from fovea.schemas.diagnostics import (
    FoveaDoctorOutput,
    FoveaHomeHealth,
    GpuHealth,
    HttpHealth,
    PackageHealth,
)


def collect_doctor_report() -> FoveaDoctorOutput:
    """Collect a shared Fovea environment report for CLI and MCP usage."""
    paths = ensure_fovea_dirs(get_fovea_home())
    warnings: list[str] = []
    errors: list[str] = []

    python_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    gpu = _detect_gpu()
    ultralytics = _import_health("ultralytics")
    onnxruntime = _onnxruntime_health()
    onnx = _import_health("onnx")
    fastmcp = _import_health("fastmcp")
    http = _probe_http_transport(paths)
    home = _inspect_fovea_home(paths)

    if not gpu.available:
        warnings.append(
            "No hardware accelerator was detected; training and inference will use CPU."
        )
    if ultralytics.status != "ok":
        errors.append("Ultralytics is unavailable, so training/evaluation tools cannot run.")
    if onnxruntime.status != "ok":
        warnings.append("onnxruntime is unavailable; ONNX benchmarking and parity checks may fail.")
    if not http.reachable:
        warnings.append("The local HTTP transport is offline; Studio live views require it.")

    return FoveaDoctorOutput(
        python=python_version,
        gpu=gpu,
        ultralytics=ultralytics,
        onnxruntime=onnxruntime,
        onnx=onnx,
        fastmcp=fastmcp,
        http=http,
        fovea_home=home,
        warnings=warnings,
        errors=errors,
    )


def _import_health(module_name: str) -> PackageHealth:
    try:
        module = importlib.import_module(module_name)
    except ImportError as exc:
        return PackageHealth(status="missing", version=None, detail=str(exc))
    version = getattr(module, "__version__", None)
    return PackageHealth(status="ok", version=str(version) if version is not None else "unknown")


def _onnxruntime_health() -> PackageHealth:
    try:
        module = importlib.import_module("onnxruntime")
    except ImportError as exc:
        return PackageHealth(status="missing", version=None, detail=str(exc))
    providers = []
    get_available_providers = getattr(module, "get_available_providers", None)
    if callable(get_available_providers):
        providers = [str(item) for item in get_available_providers()]
    detail = ", ".join(providers) if providers else "No providers reported"
    version = getattr(module, "__version__", None)
    return PackageHealth(
        status="ok",
        version=str(version) if version is not None else "unknown",
        detail=detail,
    )


def _detect_gpu() -> GpuHealth:
    try:
        torch = importlib.import_module("torch")
    except ImportError:
        return GpuHealth(available=False, accelerator="cpu", detail="torch is not installed")

    cuda = getattr(torch, "cuda", None)
    if cuda is not None and callable(getattr(cuda, "is_available", None)) and cuda.is_available():
        device_name = (
            cuda.get_device_name(0) if callable(getattr(cuda, "get_device_name", None)) else None
        )
        return GpuHealth(
            available=True,
            accelerator="cuda",
            device=str(device_name) if device_name is not None else None,
            detail="CUDA is available",
        )

    backends = getattr(torch, "backends", None)
    mps_backend = getattr(backends, "mps", None) if backends is not None else None
    if (
        mps_backend is not None
        and callable(getattr(mps_backend, "is_available", None))
        and mps_backend.is_available()
    ):
        return GpuHealth(
            available=True,
            accelerator="mps",
            device="Apple Silicon GPU",
            detail="Metal Performance Shaders is available",
        )

    return GpuHealth(
        available=False,
        accelerator="cpu",
        detail="No CUDA or MPS accelerator detected",
    )


def _probe_http_transport(paths: FoveaPaths) -> HttpHealth:
    socket_path = paths.home / "fovea.sock"
    base_url = "http://127.0.0.1:7823/health"
    try:
        response = httpx.get(base_url, timeout=1.5)
        if response.is_success:
            return HttpHealth(
                reachable=True,
                base_url=base_url,
                socket_path=socket_path,
                socket_exists=socket_path.exists(),
                detail="TCP health check succeeded",
            )
        return HttpHealth(
            reachable=False,
            base_url=base_url,
            socket_path=socket_path,
            socket_exists=socket_path.exists(),
            detail=f"Health endpoint returned HTTP {response.status_code}",
        )
    except Exception as exc:
        detail = "Unix socket present" if socket_path.exists() else str(exc)
        return HttpHealth(
            reachable=False,
            base_url=base_url,
            socket_path=socket_path,
            socket_exists=socket_path.exists(),
            detail=detail,
        )


def _inspect_fovea_home(paths: FoveaPaths) -> FoveaHomeHealth:
    usage = shutil.disk_usage(paths.home)
    run_count = len(list(paths.runs.glob("*"))) if paths.runs.exists() else 0
    model_count = (
        len([path for path in paths.models.glob("*") if path.is_file()])
        if paths.models.exists()
        else 0
    )
    writable = _is_writable(paths.home)
    return FoveaHomeHealth(
        path=paths.home,
        writable=writable,
        disk_free_gb=round(usage.free / (1024**3), 2),
        run_count=run_count,
        model_count=model_count,
    )


def _is_writable(path: Path) -> bool:
    try:
        probe = path / ".write-test"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        return True
    except OSError:
        return False
