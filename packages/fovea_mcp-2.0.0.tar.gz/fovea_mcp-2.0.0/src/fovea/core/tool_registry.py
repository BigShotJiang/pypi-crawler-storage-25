"""Central tool registry used by the MCP server and HTTP proxy."""

from __future__ import annotations

import importlib
from collections.abc import Callable
from typing import Any, cast

from fovea.core.logging import get_logger

ToolCallable = Callable[..., dict[str, Any]]

_TOOL_SPECS: dict[str, str] = {
    "annotation_quality_check": "fovea.tools.annotation_quality_check:annotation_quality_check",
    "benchmark_latency": "fovea.tools.benchmark_latency:benchmark_latency",
    "dataset_convert": "fovea.tools.dataset_convert:dataset_convert",
    "dataset_find_duplicates": "fovea.tools.dataset_find_duplicates:dataset_find_duplicates",
    "dataset_inspect": "fovea.tools.dataset_inspect:dataset_inspect",
    "dataset_split": "fovea.tools.dataset_split:dataset_split",
    "dataset_validate": "fovea.tools.dataset_validate:dataset_validate",
    "eval_compare": "fovea.tools.eval_compare:eval_compare",
    "eval_error_analysis": "fovea.tools.eval_error_analysis:eval_error_analysis",
    "eval_per_class": "fovea.tools.eval_per_class:eval_per_class",
    "eval_run": "fovea.tools.eval_run:eval_run",
    "export_onnx": "fovea.tools.export_onnx:export_onnx",
    "export_tflite": "fovea.tools.export_tflite:export_tflite",
    "fovea_doctor": "fovea.tools.fovea_doctor:fovea_doctor",
    "infer_batch": "fovea.tools.infer_batch:infer_batch",
    "infer_image": "fovea.tools.infer_image:infer_image",
    "infer_rtsp": "fovea.tools.infer_rtsp:infer_rtsp",
    "model_list": "fovea.tools.model_list:model_list",
    "model_profile": "fovea.tools.model_profile:model_profile",
    "quantize_int8": "fovea.tools.quantize_int8:quantize_int8",
    "quantize_report": "fovea.tools.quantize_report:quantize_report",
    "run_compare": "fovea.tools.run_compare:run_compare",
    "run_delete": "fovea.tools.run_delete:run_delete",
    "run_tag": "fovea.tools.run_tag:run_tag",
    "train_resume": "fovea.tools.train_resume:train_resume",
    "train_start": "fovea.tools.train_start:train_start",
    "train_status": "fovea.tools.train_status:train_status",
    "train_stop": "fovea.tools.train_stop:train_stop",
}


def register_all() -> None:
    """Import every tool module so FastMCP decorators register against the singleton."""
    for target in _TOOL_SPECS.values():
        module_name, _ = target.split(":", maxsplit=1)
        importlib.import_module(module_name)
    get_logger(__name__).info("tool_registry_loaded", total_tools=len(_TOOL_SPECS))


def available_tools() -> list[str]:
    """Return all HTTP-exposed tool names."""
    return sorted(_TOOL_SPECS)


def list_tool_names() -> list[str]:
    """Return all registered Fovea tool names in stable sorted order."""
    return available_tools()


def resolve_tool(name: str) -> ToolCallable:
    """Resolve a tool name to its callable."""
    target = _TOOL_SPECS.get(name)
    if target is None:
        raise KeyError(name)
    module_name, attr_name = target.split(":", maxsplit=1)
    module = importlib.import_module(module_name)
    return cast(ToolCallable, getattr(module, attr_name))
