"""Run the Fovea CLI with ``python -m fovea``."""

from __future__ import annotations

from fovea.cli import app

if __name__ == "__main__":
    app()
