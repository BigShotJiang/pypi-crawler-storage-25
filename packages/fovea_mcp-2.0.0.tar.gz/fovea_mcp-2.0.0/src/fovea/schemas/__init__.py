"""Pydantic schemas for all Fovea tool inputs and outputs."""
