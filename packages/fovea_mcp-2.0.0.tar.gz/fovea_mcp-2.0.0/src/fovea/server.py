"""Fovea MCP server bootstrap.

Initializes a FastMCP server instance and registers the tool registry.
"""

from __future__ import annotations

from fastmcp import FastMCP

from fovea import __version__
from fovea.core.tool_registry import register_all

mcp: FastMCP = FastMCP(
    name="fovea",
    version=__version__,
    instructions=(
        "Fovea is an edge-AI computer vision workbench. "
        "Use these tools to inspect datasets, train YOLO models, evaluate checkpoints, "
        "export to ONNX/TFLite, quantize, benchmark latency, and run live RTSP inference. "
        "All operations are local — nothing leaves your machine."
    ),
)
register_all()
