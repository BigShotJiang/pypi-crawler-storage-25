"""Fovea MCP — professional-grade edge-AI computer vision workbench."""

__version__ = "2.0.0"
__all__ = ["__version__"]
