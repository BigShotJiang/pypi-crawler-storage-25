"""HTTP route definitions for fovea-studio integration.

Endpoints:
  GET  /runs                   — list all runs
  GET  /runs/{run_id}          — single run metadata
  GET  /runs/{run_id}/metrics  — SSE stream of metrics.jsonl lines
  POST /tools/{name}           — proxy to MCP tool call
"""

from __future__ import annotations

import asyncio
import json
import time
from collections.abc import AsyncIterator, Awaitable, Callable
from pathlib import Path
from typing import cast

from fastapi import APIRouter, Body, HTTPException, Request
from fastapi.responses import JSONResponse, PlainTextResponse, StreamingResponse
from pydantic import BaseModel
from watchfiles import Change, awatch

from fovea.core.checkpoints import (
    load_metrics_jsonl,
    normalize_metric_row,
    read_metric_rows,
    read_metrics_summary,
)
from fovea.core.errors import FoveaError
from fovea.core.logging import get_logger
from fovea.core.runs import RunRecord

router = APIRouter()
_EMPTY_PAYLOAD = Body(default_factory=dict)


@router.get("/health")
async def health() -> dict[str, str]:
    """Health check endpoint."""
    from fovea import __version__

    return {"status": "ok", "version": __version__}


@router.get("/runs")
async def list_runs() -> JSONResponse:
    """List all training runs."""
    from fovea.core.paths import ensure_fovea_dirs

    paths = ensure_fovea_dirs()
    from fovea.core.runs import get_registry

    registry = get_registry(paths.runs_db)
    records = registry.list_runs()
    return JSONResponse([_run_summary(record) for record in records])


def _run_summary(record: RunRecord) -> dict[str, object]:
    run_path = Path(str(record.run_path))
    status_payload = _read_status_payload(run_path)
    status = str(status_payload.get("status") or record.status)
    current_epoch, best_map50 = read_metrics_summary(run_path)
    return {
        "id": str(record.id),
        "status": status,
        "model": str(record.model),
        "epochs": int(record.epochs),
        "run_path": str(record.run_path),
        "current_epoch": current_epoch,
        "best_map50": best_map50,
        "created_at": record.created_at.isoformat() if record.created_at else None,
    }


def _read_status_payload(run_dir: Path) -> dict[str, object]:
    status_file = run_dir / "status.json"
    if not status_file.exists():
        return {}
    try:
        payload = json.loads(status_file.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}
    if not isinstance(payload, dict):
        return {}
    return cast(dict[str, object], payload)


@router.get("/metrics")
async def prometheus_metrics(request: Request) -> PlainTextResponse:
    """Expose a small Prometheus-compatible metrics snapshot when enabled."""
    if not bool(getattr(request.app.state, "metrics_enabled", False)):
        raise HTTPException(status_code=404, detail="Metrics endpoint is disabled.")

    from fovea.core.paths import ensure_fovea_dirs
    from fovea.core.runs import get_registry

    paths = ensure_fovea_dirs()
    registry = get_registry(paths.runs_db)
    records = registry.list_runs(limit=10000)
    active_runs = sum(1 for record in records if record.status == "running")
    total_runs = len(records)
    lines = [
        "# HELP fovea_active_runs Number of currently running Fovea training runs.",
        "# TYPE fovea_active_runs gauge",
        f"fovea_active_runs {active_runs}",
        "# HELP fovea_runs_total Number of runs tracked by the local registry.",
        "# TYPE fovea_runs_total gauge",
        f"fovea_runs_total {total_runs}",
    ]
    return PlainTextResponse("\n".join(lines) + "\n")


@router.get("/runs/{run_id}")
async def get_run(run_id: str) -> JSONResponse:
    """Get metadata for a single run."""
    from fovea.core.paths import ensure_fovea_dirs
    from fovea.core.runs import get_registry

    paths = ensure_fovea_dirs()
    registry = get_registry(paths.runs_db)
    record = registry.get_run(run_id)
    if record is None:
        raise HTTPException(status_code=404, detail=f"Run {run_id} not found.")
    run_path = Path(record.run_path)
    status_payload = _read_status_payload(run_path)
    status = str(status_payload.get("status") or record.status)
    current_epoch, best_map50 = read_metrics_summary(run_path)
    return JSONResponse(
        {
            "id": record.id,
            "status": status,
            "model": record.model,
            "dataset_path": record.dataset_path,
            "task": record.task,
            "epochs": record.epochs,
            "pid": record.pid,
            "run_path": record.run_path,
            "current_epoch": current_epoch,
            "best_map50": best_map50,
            "created_at": record.created_at.isoformat() if record.created_at else None,
            "started_at": record.started_at.isoformat() if record.started_at else None,
            "finished_at": record.finished_at.isoformat() if record.finished_at else None,
        }
    )


class RunsSearchInput(BaseModel):
    query: str | None = None
    tags: list[str] = []
    status: list[str] = []
    min_map50: float | None = None
    limit: int = 50


@router.post("/runs/search")
async def search_runs(body: RunsSearchInput) -> JSONResponse:
    """Search runs by text, tags, status, and minimum mAP50."""
    from fovea.core.paths import ensure_fovea_dirs
    from fovea.core.runs import get_registry

    paths = ensure_fovea_dirs()
    registry = get_registry(paths.runs_db)
    records = registry.list_runs(limit=max(body.limit, 1) * 4)

    matched: list[dict[str, object]] = []
    lowered_query = body.query.lower() if body.query else None
    required_statuses = {status.lower() for status in body.status}
    required_tags = {tag.lower() for tag in body.tags}

    for record in records:
        raw_tags = cast(str, record.tags_json or "[]")
        record_tags = {str(tag).lower() for tag in json.loads(raw_tags)}
        haystack = " ".join(
            [
                str(record.id),
                str(record.model),
                str(record.dataset_path),
                str(record.task),
                " ".join(record_tags),
                str(record.extra_json or ""),
            ]
        ).lower()
        if lowered_query and lowered_query not in haystack:
            continue
        if required_statuses and str(record.status).lower() not in required_statuses:
            continue
        if required_tags and not required_tags.issubset(record_tags):
            continue
        _, best_map50 = read_metrics_summary(Path(record.run_path))
        if body.min_map50 is not None and (best_map50 is None or best_map50 < body.min_map50):
            continue
        matched.append(
            {
                "id": record.id,
                "status": record.status,
                "model": record.model,
                "dataset_path": record.dataset_path,
                "task": record.task,
                "epochs": record.epochs,
                "created_at": record.created_at.isoformat() if record.created_at else None,
                "best_map50": best_map50,
                "tags": sorted(record_tags),
            }
        )
        if len(matched) >= body.limit:
            break
    return JSONResponse(matched)


@router.get("/runs/{run_id}/metrics")
async def stream_run_metrics(run_id: str, request: Request) -> StreamingResponse:
    """Stream normalized metric rows for a run over server-sent events."""
    run_dir = _resolve_run_dir(run_id)
    shutdown_event = cast(asyncio.Event, request.app.state.shutdown_event)

    return StreamingResponse(
        _metric_event_stream(
            run_id=run_id,
            run_dir=run_dir,
            disconnect_check=request.is_disconnected,
            shutdown_event=shutdown_event,
        ),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@router.post("/tools/{name}")
async def proxy_tool(
    name: str,
    payload: dict[str, object] = _EMPTY_PAYLOAD,
) -> JSONResponse:
    """Invoke a local Fovea tool through the HTTP transport."""
    from fovea.http.tool_proxy import available_tools, invoke_tool

    try:
        result = await asyncio.to_thread(invoke_tool, name, payload)
    except KeyError as exc:
        raise HTTPException(
            status_code=404,
            detail={
                "message": f"Tool '{name}' is not available over HTTP.",
                "available_tools": available_tools(),
            },
        ) from exc
    except FoveaError as exc:
        raise HTTPException(
            status_code=400,
            detail={"code": exc.code, "message": exc.message, "hint": exc.hint},
        ) from exc

    return JSONResponse(result)


def _resolve_run_dir(run_id: str) -> Path:
    from fovea.core.paths import ensure_fovea_dirs
    from fovea.core.runs import get_registry

    paths = ensure_fovea_dirs()
    registry = get_registry(paths.runs_db)
    record = registry.get_run(run_id)
    if record is None:
        raise HTTPException(status_code=404, detail=f"Run {run_id} not found.")
    return Path(record.run_path)


async def _metric_event_stream(
    *,
    run_id: str,
    run_dir: Path,
    disconnect_check: Callable[[], Awaitable[bool]],
    shutdown_event: asyncio.Event,
) -> AsyncIterator[str]:
    yield "retry: 5000\n\n"

    metrics_jsonl = run_dir / "metrics.jsonl"
    jsonl_offset = 0
    emitted_count = 0
    snapshot = _load_metric_payloads(run_id, run_dir)
    for payload in snapshot:
        yield f"event: metric\ndata: {json.dumps(payload)}\n\n"
    emitted_count = len(snapshot)
    if metrics_jsonl.exists():
        jsonl_offset = metrics_jsonl.stat().st_size

    watcher = awatch(run_dir, stop_event=shutdown_event, debounce=150)
    last_heartbeat = time.monotonic()

    while not shutdown_event.is_set():
        if await disconnect_check():
            get_logger(__name__).info("metrics_stream_disconnected", run_id=run_id)
            break

        try:
            changes = await asyncio.wait_for(watcher.__anext__(), timeout=15.0)
        except TimeoutError:
            yield ": keep-alive\n\n"
            last_heartbeat = time.monotonic()
            continue
        except StopAsyncIteration:
            break

        delta_payloads: list[dict[str, object]]
        if _contains_metrics_jsonl_change(changes):
            emitted_count, jsonl_offset, delta_payloads = _load_metric_payload_delta(
                run_id, run_dir, emitted_count, jsonl_offset
            )
        else:
            delta_payloads = _load_metric_payloads(run_id, run_dir)[emitted_count:]
            emitted_count += len(delta_payloads)

        for payload in delta_payloads:
            yield f"event: metric\ndata: {json.dumps(payload)}\n\n"
            last_heartbeat = time.monotonic()

        if time.monotonic() - last_heartbeat >= 15.0:
            yield ": keep-alive\n\n"
            last_heartbeat = time.monotonic()


def _load_metric_payloads(run_id: str, run_dir: Path) -> list[dict[str, object]]:
    payloads = load_metrics_jsonl(run_dir)
    if payloads:
        return payloads
    rows = read_metric_rows(run_dir)
    return [normalize_metric_row(run_id, row) for row in rows]


def _load_metrics_jsonl(run_id: str, run_dir: Path) -> list[dict[str, object]]:
    del run_id
    return load_metrics_jsonl(run_dir)


def _contains_metrics_jsonl_change(changes: set[tuple[Change, str]]) -> bool:
    for _, changed_path in changes:
        if Path(changed_path).name == "metrics.jsonl":
            return True
    return False


def _load_metric_payload_delta(
    run_id: str,
    run_dir: Path,
    emitted_count: int,
    previous_offset: int,
) -> tuple[int, int, list[dict[str, object]]]:
    metrics_path = run_dir / "metrics.jsonl"
    if not metrics_path.exists():
        full_payloads = _load_metric_payloads(run_id, run_dir)
        new_payloads = full_payloads[emitted_count:]
        return emitted_count + len(new_payloads), previous_offset, new_payloads

    current_size = metrics_path.stat().st_size
    if current_size < previous_offset:
        refreshed_payloads = load_metrics_jsonl(run_dir)
        return len(refreshed_payloads), current_size, refreshed_payloads

    if current_size == previous_offset:
        return emitted_count, previous_offset, []

    with metrics_path.open("r", encoding="utf-8") as handle:
        handle.seek(previous_offset)
        lines = handle.read().splitlines()

    delta_payloads: list[dict[str, object]] = []
    for line in lines:
        if not line.strip():
            continue
        try:
            raw = cast(dict[str, object], json.loads(line))
        except json.JSONDecodeError:
            continue
        metrics = raw.get("metrics", {})
        if not isinstance(metrics, dict):
            metrics = {}
        epoch_value = raw.get("epoch", emitted_count + len(delta_payloads) + 1)
        delta_payloads.append(
            {
                "runId": str(raw.get("run_id", run_id)),
                "epoch": int(epoch_value) if isinstance(epoch_value, (int, float, str)) else 0,
                "metrics": {
                    str(key): float(value)
                    for key, value in metrics.items()
                    if isinstance(value, (int, float))
                },
            }
        )
    return emitted_count + len(delta_payloads), current_size, delta_payloads
