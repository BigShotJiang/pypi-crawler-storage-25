"""Optional HTTP transport for fovea-studio integration."""
