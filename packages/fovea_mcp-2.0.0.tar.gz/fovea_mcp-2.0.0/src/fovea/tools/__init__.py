"""Fovea MCP tool implementations — one file per tool."""
