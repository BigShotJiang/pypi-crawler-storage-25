"""fovea_doctor — shared environment diagnostics for local Fovea installs."""

from __future__ import annotations

from typing import Any

from fovea.core.doctor import collect_doctor_report
from fovea.core.tooling import tool_event
from fovea.server import mcp


@mcp.tool()
def fovea_doctor() -> dict[str, Any]:
    """Report the local Fovea environment health, including GPU and HTTP status."""
    with tool_event("fovea_doctor"):
        return collect_doctor_report().model_dump(mode="json")
