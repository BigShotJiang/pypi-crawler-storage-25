"""train_start — launch a non-blocking YOLO training subprocess."""

from __future__ import annotations

import os
import subprocess
import sys
import uuid
from pathlib import Path
from typing import Any

from fovea.core.dataset_config import validate_yolo_data_yaml
from fovea.core.errors import FoveaDatasetNotFoundError, FoveaTrainingAlreadyRunningError
from fovea.core.json_io import write_json_atomically
from fovea.core.paths import FoveaPaths, get_fovea_home
from fovea.core.runs import get_registry
from fovea.core.tooling import tool_event
from fovea.schemas.training import TrainStartInput, TrainStartOutput
from fovea.server import mcp


@mcp.tool()
def train_start(
    dataset_path: str,
    model: str = "yolov8n.pt",
    epochs: int = 100,
    batch: int = 16,
    imgsz: int = 640,
    device: str = "auto",
    task: str = "detect",
    name: str | None = None,
    tags: list[str] | None = None,
    extra_args: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Launch a YOLO training run as a non-blocking background subprocess.

    Returns immediately with a run_id for monitoring via train_status.
    """
    inp = TrainStartInput(
        dataset_path=Path(dataset_path),
        model=model,
        epochs=epochs,
        batch=batch,
        imgsz=imgsz,
        device=device,
        task=task,  # type: ignore[arg-type]
        name=name,
        tags=tags or [],
        extra_args=extra_args or {},
    )
    with tool_event(
        "train_start",
        dataset_path=dataset_path,
        model=model,
        requested_run_id=name,
    ) as logger:
        output = _run_train_start(inp)
        logger.info("train_start_spawned", run_id=output.run_id, pid=output.pid)
        return output.model_dump(mode="json")


def _run_train_start(inp: TrainStartInput) -> TrainStartOutput:
    dataset_path = inp.dataset_path.expanduser().resolve()
    if not dataset_path.exists():
        raise FoveaDatasetNotFoundError(str(dataset_path))
    validate_yolo_data_yaml(dataset_path)

    paths = FoveaPaths(get_fovea_home())
    registry = get_registry(paths.runs_db)

    run_id = inp.name or f"run_{uuid.uuid4().hex[:8]}"
    run_dir = paths.runs / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    existing = registry.get_run(run_id)
    if existing and existing.status == "running":
        raise FoveaTrainingAlreadyRunningError(run_id)

    params: dict[str, Any] = {
        "model": inp.model,
        "dataset_path": str(dataset_path),
        "epochs": inp.epochs,
        "batch": inp.batch,
        "imgsz": inp.imgsz,
        "device": inp.device,
        "task": inp.task,
        "extra_args": inp.extra_args,
    }
    write_json_atomically(run_dir / "params.json", params)

    stdout_log = run_dir / "stdout.log"
    stderr_log = run_dir / "stderr.log"
    with (
        stdout_log.open("w", encoding="utf-8") as stdout_fh,
        stderr_log.open("w", encoding="utf-8") as stderr_fh,
    ):
        proc = subprocess.Popen(  # noqa: S603 - fixed local module execution only
            [sys.executable, "-m", "fovea.core.train_worker", str(run_dir)],
            stdout=stdout_fh,
            stderr=stderr_fh,
            close_fds=True,
            env={**os.environ, "FOVEA_RUN_DIR": str(run_dir)},
        )
    (run_dir / "pid.txt").write_text(str(proc.pid), encoding="utf-8")

    if existing:
        registry.update_status(run_id, "running", pid=proc.pid)
    else:
        registry.create_run(
            run_id=run_id,
            run_path=run_dir,
            model=inp.model,
            dataset_path=dataset_path,
            task=inp.task,
            epochs=inp.epochs,
            tags=inp.tags,
        )
        registry.update_status(run_id, "running", pid=proc.pid)

    return TrainStartOutput(
        run_id=run_id,
        status="running",
        pid=proc.pid,
        run_path=run_dir,
    )
