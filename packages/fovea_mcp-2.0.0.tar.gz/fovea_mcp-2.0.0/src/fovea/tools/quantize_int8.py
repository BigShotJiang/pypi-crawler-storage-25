"""quantize_int8 — INT8 post-training quantization via ONNX export."""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any

from fovea.core.checkpoints import resolve_checkpoint
from fovea.core.dataset_config import validate_yolo_data_yaml
from fovea.core.errors import FoveaDatasetNotFoundError
from fovea.core.export_history import record_export_history
from fovea.core.tooling import tool_event
from fovea.core.ultralytics_adapter import load_yolo_model
from fovea.core.validation import ensure_writable_output
from fovea.schemas.export import QuantizeInt8Input, QuantizeInt8Output
from fovea.server import mcp


@mcp.tool()
def quantize_int8(
    checkpoint: str,
    calibration_dataset: str,
    output_path: str | None = None,
    imgsz: int = 640,
    device: str = "auto",
) -> dict[str, Any]:
    """Produce an INT8-quantized ONNX model using a calibration dataset."""
    inp = QuantizeInt8Input(
        checkpoint=checkpoint,
        calibration_dataset=Path(calibration_dataset),
        output_path=Path(output_path) if output_path else None,
        imgsz=imgsz,
        device=device,
    )
    with tool_event(
        "quantize_int8",
        checkpoint=checkpoint,
        calibration_dataset=calibration_dataset,
    ):
        return _run_quantize_int8(inp).model_dump(mode="json")


def _run_quantize_int8(inp: QuantizeInt8Input) -> QuantizeInt8Output:
    calib_path = inp.calibration_dataset.expanduser().resolve()
    if not calib_path.exists():
        raise FoveaDatasetNotFoundError(str(calib_path))
    validate_yolo_data_yaml(calib_path)

    ckpt_path = resolve_checkpoint(inp.checkpoint)
    orig_size = ckpt_path.stat().st_size

    t0 = time.perf_counter()
    quantized_path = _yolo_quantize_int8(ckpt_path, calib_path, inp)
    elapsed = time.perf_counter() - t0

    quant_size = quantized_path.stat().st_size if quantized_path.exists() else 0
    reduction = ((orig_size - quant_size) / orig_size * 100) if orig_size > 0 else 0.0

    record_export_history(
        source_checkpoint=ckpt_path,
        artifact_path=quantized_path,
        format="onnx-int8",
        duration_s=elapsed,
        metadata={"imgsz": inp.imgsz, "size_reduction_pct": reduction},
    )

    return QuantizeInt8Output(
        checkpoint=str(ckpt_path),
        quantized_path=quantized_path,
        quantize_duration_seconds=elapsed,
        model_size_bytes=quant_size,
        size_reduction_pct=reduction,
    )


def _yolo_quantize_int8(
    ckpt_path: Path,
    calib_path: Path,
    inp: QuantizeInt8Input,
) -> Path:
    model = load_yolo_model(ckpt_path)
    export_path = model.export(
        format="onnx",
        imgsz=inp.imgsz,
        int8=True,
        data=str(calib_path / "data.yaml"),
        device=inp.device,
    )
    result_path = Path(str(export_path))
    if inp.output_path is not None and inp.output_path != result_path:
        target_path = ensure_writable_output(inp.output_path)
        target_path.parent.mkdir(parents=True, exist_ok=True)
        result_path.rename(target_path)
        result_path = target_path
    return result_path
