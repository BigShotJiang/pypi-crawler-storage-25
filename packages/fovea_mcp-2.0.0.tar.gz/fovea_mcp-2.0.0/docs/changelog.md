# Changelog

The canonical changelog for the MCP package lives here:

`fovea-mcp/CHANGELOG.md`
