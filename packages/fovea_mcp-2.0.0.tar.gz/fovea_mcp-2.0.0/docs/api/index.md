# API Reference

The API reference is generated from the public Python modules.

## Core

::: fovea.config

::: fovea.core.errors

::: fovea.core.paths

::: fovea.core.runs

::: fovea.core.logging

::: fovea.http.routes

## Schemas

::: fovea.schemas.dataset

::: fovea.schemas.training

::: fovea.schemas.eval

::: fovea.schemas.export

::: fovea.schemas.inference

::: fovea.schemas.management
