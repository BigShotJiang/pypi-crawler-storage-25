# Errors

Fovea surfaces only `FoveaError` subclasses at tool boundaries.

## Common Codes

- `FOVEA_DATASET_001`: dataset path not found
- `FOVEA_DATASET_002`: malformed or unsupported dataset format
- `FOVEA_DATASET_003`: dataset contains zero images
- `FOVEA_TRAIN_001`: run not found
- `FOVEA_EVAL_001`: checkpoint not found
- `FOVEA_INFER_001`: RTSP connection failed
- `FOVEA_CONFIG_001`: path validation failed

## Error Shape

Each error includes:

- a stable code
- a short human-readable message
- an optional remediation hint

## Debugging Tip

Set `FOVEA_LOG_FORMAT=json` and `FOVEA_LOG_LEVEL=DEBUG` when reproducing tool failures from the CLI or HTTP transport.
