# Integrations

## Cursor and Windsurf

Use the standard MCP server configuration with `command: "fovea-mcp"`. Fovea is designed to be called by an existing coding or assistant workflow rather than acting as its own chat UI.

## VS Code

There are two layers:

- MCP client integration for conversational tool use
- Fovea Studio for local dashboards and inspections

Run the local HTTP transport when Studio needs live run metrics:

```bash
fovea-mcp serve --http --host 127.0.0.1 --port 7823
```

## Codex CLI

Use Fovea as a standard MCP server entry in Codex CLI and keep the filesystem local.
