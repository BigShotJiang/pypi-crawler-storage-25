import re
import os
import pymysql
from elasticsearch import Elasticsearch
from elasticsearch.helpers import bulk
from pymysql.cursors import DictCursor
from typing import Dict, List, Generator, Any
from pypinyin import lazy_pinyin, Style


# 写入章节或者栏目
class lanmu:
    # 初始化数据
    def __init__(self, user_json):
        self.connection = pymysql.connect(host=user_json['host'],
                                          user=user_json['user'],
                                          password=user_json['password'],
                                          database=user_json['user'],
                                          port=user_json['port'],
                                          charset="utf8mb4",
                                          cursorclass=DictCursor)
        # 连接 Elasticsearch
        username = os.getenv('ES_USERNAME', user_json['es_user'])
        password = os.getenv('ES_PASSWORD', user_json['es_password'])
        self.es_db = Elasticsearch(
            hosts=[f"http://{user_json['host']}:9200"],
            basic_auth=(username, password),  # 使用basic_auth替换http_auth
            verify_certs=False,
            max_retries=3,
            retry_on_timeout=True
        ).options(ignore_status=404)
        self.cursor = self.connection.cursor()
        self.max_id = 0
        self.category_map = {}  # 用于存储name到id的映射
        self.next_id = 1  # 本地自增ID计数器
        self.dirname_map = {}  # 记录已生成的目录名，避免重复
        # 判断es索引是否创建
        self.if_es_suoyin()

    # 判断是否为题库
    def lanmu_id_pd(self):
        query = "SELECT" + " child FROM dr_exam_category WHERE id = " + str(self.lanmu_id)
        self.cursor.execute(query)
        result = self.cursor.fetchone()
        if result['child'] == 1:
            print('此栏目非题库，请检查！')
            exit()

    # 获取表中当前最大ID
    def _get_max_id(self):
        query = "SELECT MAX(id) as max_id FROM " + self.biao_name
        self.cursor.execute(query)
        result = self.cursor.fetchone()
        if result and result['max_id']:
            self.max_id = result['max_id']
            self.next_id = self.max_id + 1
        else:
            self.max_id = 0
            self.next_id = 1
        print(f"当前最大ID: {self.max_id}, 下一个ID: {self.next_id}")

    # 根据栏目名称生成目录名
    def _generate_dirname(self, name: str, parent_dirname: str = "") -> str:
        # 步骤1: 过滤特殊字符，只保留汉字、字母、数字
        # 正则表达式：匹配汉字、字母、数字
        pattern = re.compile(r'[\u4e00-\u9fa5a-zA-Z0-9]+')
        matches = pattern.findall(name)
        cleaned_name = ''.join(matches)

        # 步骤2: 检查是否是纯字母数字
        if re.match(r'^[a-zA-Z0-9]+$', cleaned_name):
            # 纯字母数字，直接转换为小写
            base_dirname = cleaned_name.lower()
        else:
            # 检查是否是纯汉字
            if re.match(r'^[\u4e00-\u9fa5]+$', cleaned_name):
                # 纯汉字
                if len(cleaned_name) > 3:
                    # 大于3个字：取拼音首字母
                    pinyin_list = lazy_pinyin(cleaned_name, style=Style.FIRST_LETTER)
                    base_dirname = ''.join(pinyin_list).lower()
                else:
                    # 不大于3个字：全拼
                    pinyin_list = lazy_pinyin(cleaned_name)
                    base_dirname = ''.join(pinyin_list).lower()
            else:
                # 混合类型（汉字+字母数字），分别处理
                result = []
                for char in cleaned_name:
                    if re.match(r'[\u4e00-\u9fa5]', char):
                        # 汉字
                        if len(cleaned_name) > 3:
                            pinyin = lazy_pinyin(char, style=Style.FIRST_LETTER)[0]
                        else:
                            pinyin = lazy_pinyin(char)[0]
                        result.append(pinyin)
                    else:
                        # 字母数字
                        result.append(char.lower())
                base_dirname = ''.join(result)

        # 步骤3: 确保目录名只包含字母、数字、下划线、连字符
        base_dirname = re.sub(r'[^a-z0-9_-]', '', base_dirname)

        # 步骤4: 避免重复
        dirname = base_dirname
        counter = 1

        # 生成完整的目录路径用于检查
        full_dirname = parent_dirname + dirname if parent_dirname else dirname

        while full_dirname in self.dirname_map:
            # 如果目录名已存在，添加数字后缀
            dirname = f"{base_dirname}_{counter}"
            full_dirname = parent_dirname + dirname if parent_dirname else dirname
            counter += 1

        # 记录已使用的目录名
        self.dirname_map[full_dirname] = True

        return dirname

    # 获取父级ID和所有上级ID
    def _get_parent_ids(self, parent_name) -> tuple:
        if not parent_name or parent_name == "":
            return 0, "0"  # 没有父级

        if parent_name in self.category_map:
            parent_id = self.category_map[parent_name]["id"]
            parent_pids = self.category_map[parent_name]["pids"]
            pids = f"{parent_pids},{parent_id}" if parent_pids != "0" else f"0,{parent_id}"
            return parent_id, pids

        return 0, "0"  # 父级不存在，设为顶级

    # 获取上级目录路径
    def _get_pdirname(self, parent_name: str) -> str:
        if parent_name in self.category_map:
            parent = self.category_map[parent_name]
            parent_dirname = parent["dirname"]
            parent_pdirname = parent["pdirname"]

            if parent_pdirname:
                return f"{parent_pdirname}{parent_dirname}/"
            else:
                return f"{parent_dirname}/"

        return ""

    # 获取上级目录路径
    def _build_category_tree(self, categories: List[Dict], parent_name: str = "") -> List[Dict]:
        result = []
        for category in categories:
            category_data = category.copy()
            name = category_data.get("name", "")

            # 处理当前栏目
            current_id = self.next_id
            self.next_id += 1

            # 获取父级信息
            pid, pids = self._get_parent_ids(parent_name)

            # 获取上级目录路径
            pdirname = self._get_pdirname(parent_name)

            # 生成目录名
            dirname = category_data.get("dirname")
            if not dirname:
                dirname = self._generate_dirname(name, pdirname)

            # 是否有子级
            has_children = "children" in category_data and len(category_data["children"]) > 0

            # 构建栏目数据
            processed_category = {}
            if self.biao_name == "dr_exam_category":
                processed_category = {
                    "id": current_id,
                    "pid": pid,
                    "pids": pids,
                    "name": name,
                    "dirname": dirname,
                    "pdirname": pdirname,
                    "child": 1 if has_children else 0,
                    "disabled": 0,  # 默认不禁用
                    "childids": "",  # 初始为空，稍后更新
                    "show": 1,  # 默认显示
                    "setting": "",  # 属性配置，可根据需要设置
                    "displayorder": 0,  # 显示顺序
                    "group": '["1"]'  # 用户组，默认为1
                }
            elif self.biao_name == "dr_exam_chapter":
                processed_category = {
                    "id": current_id,
                    "pid": pid,
                    "pids": pids,
                    "name": name,
                    "dirname": dirname,
                    "pdirname": pdirname,
                    "child": 1 if has_children else 0,
                    "disabled": 0,  # 默认不禁用
                    "childids": "",  # 初始为空，稍后更新
                    "show": 1,  # 默认显示
                    "setting": "",  # 属性配置，可根据需要设置
                    "displayorder": 0,  # 显示顺序
                    "catid": self.lanmu_id  # 用户组，默认为1
                }

            # 存储到映射表
            self.category_map[name] = {
                "id": current_id,
                "pids": pids,
                "dirname": dirname,
                "pdirname": pdirname
            }

            result.append(processed_category)

            # 递归处理子栏目
            if has_children:
                children = self._build_category_tree(category_data["children"], name)
                result.extend(children)

                # 更新childids
                child_ids = ",".join([str(child["id"]) for child in children if "id" in child])
                if child_ids:
                    processed_category["childids"] = child_ids

        return result

    # 更新所有父级栏目的childids字段
    def _update_childids(self, categories: List[Dict]):
        # 按pid分组
        children_by_parent = {}
        for category in categories:
            pid = category["pid"]
            if pid not in children_by_parent:
                children_by_parent[pid] = []
            children_by_parent[pid].append(category["id"])

        # 更新每个父级栏目的childids
        for pid, child_ids in children_by_parent.items():
            if pid > 0:  # 跳过顶级栏目
                child_ids_str = ",".join(map(str, child_ids))
                # 找到对应的栏目并更新
                for category in categories:
                    if category["id"] == pid:
                        category["childids"] = child_ids_str
                        break

    # 将栏目数据插入数据库
    def _insert_categories(self, categories: List[Dict]):
        if not categories:
            print("没有数据需要插入")
            return

        # SQL插入语句
        if self.biao_name == 'dr_exam_category':
            insert_query = "INSERT INTO " + self.biao_name + " (id, pid, pids, name, dirname, pdirname, child, disabled, childids, `show`, setting, displayorder, `group`) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        else:
            insert_query = "INSERT INTO " + self.biao_name + " (id, pid, pids, name, dirname, pdirname, child, disabled, childids, `show`, setting, displayorder,catid) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        # 准备数据
        values = []
        for category in categories:
            if self.biao_name == 'dr_exam_category':
                values.append((
                    category["id"],
                    category["pid"],
                    category["pids"],
                    category["name"],
                    category["dirname"],
                    category["pdirname"],
                    category["child"],
                    category["disabled"],
                    category["childids"],
                    category["show"],
                    category["setting"],
                    category["displayorder"],
                    category["group"]
                ))
            elif self.biao_name == 'dr_exam_chapter':
                insert_query = "INSERT INTO " + self.biao_name + " (id, pid, pids, name, dirname, pdirname, child, disabled, childids, `show`, setting, displayorder,catid) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
                values.append((
                    category["id"],
                    category["pid"],
                    category["pids"],
                    category["name"],
                    category["dirname"],
                    category["pdirname"],
                    category["child"],
                    category["disabled"],
                    category["childids"],
                    category["show"],
                    category["setting"],
                    category["displayorder"],
                    category["catid"]
                ))
        # 批量插入
        self.cursor.executemany(insert_query, values)
        self.connection.commit()
        print(f"成功插入 {len(categories)} 条记录")

    # 递归删除子节点的catid，只保留顶层节点的catid
    def _remove_child_catids(self, tree_nodes):
        for node in tree_nodes:
            if 'children' in node and node['children']:
                # 递归处理子节点
                self._remove_child_catids(node['children'])
                # 遍历子节点，删除它们的catid字段
                for child in node['children']:
                    if 'catid' in child:
                        del child['catid']

    # 检查索引是否存在，如果不存在则创建
    def if_es_suoyin(self):
        # 试题表
        mapping = {
            "mappings": {
                "properties": {
                    "tid": {"type": "integer"},
                    "title": {"type": "text", "analyzer": "ik_max_word", "search_analyzer": "ik_smart"},
                    "value": {"type": "text", "index": False},
                    "tips": {"type": "text", "index": False},
                    "answer": {"type": "text", "index": False},
                    "inputtime": {"type": "integer"},
                    "cid": {"type": "integer"},
                    "group": {"type": "text", "index": False},
                }
            },
            "settings": {
                "number_of_shards": 1,
                "number_of_replicas": 0
            }
        }
        if not self.es_db.indices.exists(index="es_exam_question"):
            self.es_db.indices.create(index="es_exam_question", body=mapping)
        # 题目归属表
        mapping = {
            "mappings": {
                "properties": {
                    "qid": {"type": "text", "index": False},
                    "catid": {"type": "integer"},
                    "cid": {"type": "integer"},
                }
            },
            "settings": {
                "number_of_shards": 1,
                "number_of_replicas": 0
            }
        }
        if not self.es_db.indices.exists(index="es_exam_category_question"):
            self.es_db.indices.create(index="es_exam_category_question", body=mapping)
        # 试卷表
        mapping = {
            "mappings": {
                "properties": {
                    "title": {"type": "text", "analyzer": "ik_max_word", "search_analyzer": "ik_smart"},
                    "paper": {"type": "text", "index": False},
                }
            },
            "settings": {
                "number_of_shards": 1,
                "number_of_replicas": 0
            }
        }
        if not self.es_db.indices.exists(index="es_exam_paper"):
            self.es_db.indices.create(index="es_exam_paper", body=mapping)
        # 材料表
        mapping = {
            "mappings": {
                "properties": {
                    "title": {"type": "text", "analyzer": "ik_max_word", "search_analyzer": "ik_smart"},
                    "qids": {"type": "text", "index": False},
                    "inputtime": {"type": "integer"},
                    "cid": {"type": "text", "index": False}
                }
            },
            "settings": {
                "number_of_shards": 1,
                "number_of_replicas": 0
            }
        }
        if not self.es_db.indices.exists(index="es_exam_composite"):
            self.es_db.indices.create(index="es_exam_composite", body=mapping)

    # 试题生成es器函数 格式化文档
    def shiti_generator(self, data_list: List[Dict]) -> Generator[Dict[str, Any], None, None]:
        for item in data_list:
            # 生成文档操作
            yield {
                "tid": item[0],
                "title": item[1],
                "value": item[2],
                "tips": item[3],
                "answer": item[4],
                "inputtime": item[5],
                "cid": item[6],
                "group": item[7],
            }

    # 试卷生成es器函数 格式化文档
    def shijuan_generator(self, data_list: List[Dict]) -> Generator[Dict[str, Any], None, None]:
        for item in data_list:
            # 生成文档操作
            yield {
                "title": item[0],
                "paper": item[1],
            }

    # 归属生成es器函数 格式化文档
    def guishu_generator(self, data_list: List[Dict]) -> Generator[Dict[str, Any], None, None]:
        for item in data_list:
            # 生成文档操作
            yield {
                "qid": item[0],
                "catid": item[1],
                "cid": item[2],
            }

    # 材料生成es器函数 格式化文档
    def cailiao_generator(self, data_list: List[Dict]) -> Generator[Dict[str, Any], None, None]:
        for item in data_list:
            # 生成文档操作
            yield {
                "title": item[0],
                "qids": item[1],
                "inputtime": item[2],
                "cid": item[3]
            }

    # 从JSON文件导入数据
    def post_lanmu(self, leibie, data_json, lanmu_id=0):
        if leibie == "栏目":
            self.biao_name = 'dr_exam_category'
        else:
            self.biao_name = 'dr_exam_chapter'
            self.lanmu_id = lanmu_id
            # 判断栏目是否为题库
            self.lanmu_id_pd()
        # 获取最大id
        self._get_max_id()
        # 重置目录名映射
        self.dirname_map = {}

        # 构建栏目数据
        all_categories = self._build_category_tree(data_json)

        # 更新所有栏目的childids
        self._update_childids(all_categories)

        # 插入数据到数据库
        self._insert_categories(all_categories)

        print(f"成功导入 {len(all_categories)} 个栏目")

    # 导出为JSON
    def get_lanmu(self, leibie):
        if leibie == "栏目":
            biao_name = 'dr_exam_category'
        else:
            biao_name = 'dr_exam_chapter'
        # 获取数据
        if biao_name == 'dr_exam_category':
            query = "SELECT" + f" id, pid, name FROM `{biao_name}` ORDER BY pid, id"
        else:  # 章节表需要catid字段
            query = "SELECT" + f" id, pid, name, catid FROM `{biao_name}` ORDER BY pid, id"
        self.cursor.execute(query)
        data = self.cursor.fetchall()
        # 构建映射字典
        node_dict = {}
        for row in data:
            if leibie == "栏目":
                node = {"id": row['id'], "name": row['name'], "children": []}
            else:
                node = {"id": row['id'], "catid": row['catid'], "name": row['name'], "children": []}
            node_dict[row['id']] = node

        # 构建树
        tree_data = []
        for row in data:
            node = node_dict[row['id']]
            if row['pid'] == 0 or row['pid'] not in node_dict:
                tree_data.append(node)
            else:
                parent = node_dict.get(row['pid'])
                if parent:
                    parent["children"].append(node)

        # 对于章节数据，删除子节点的catid，只保留顶层节点的catid
        if biao_name == 'dr_exam_chapter':
            self._remove_child_catids(tree_data)
        return tree_data

    # 试题发布
    def post_shiti(self, data_list: List[Dict]):
        # 获取生成器
        doc_generator = self.shiti_generator(data_list)
        # 执行批量插入
        bulk(self.es_db, doc_generator, chunk_size=5000, stats_only=False, raise_on_error=False)

    # 试卷发布
    def post_shijuan(self, data_list: List[Dict]):
        # 获取生成器
        doc_generator = self.shijuan_generator(data_list)
        # 执行批量插入
        bulk(self.es_db, doc_generator, chunk_size=5000, stats_only=False, raise_on_error=False)
        values = []
        insert_query = "INSERT INTO " + "dr_exam_paper (title,paper) VALUES (%s, %s)"
        for data in data_list:
            values.append((
                data[0],
                data[1]
            ))
        # 批量插入
        self.cursor.executemany(insert_query, values)
        self.connection.commit()

    # 试题归属发布
    def post_guishu(self, data_list: List[Dict]):
        # 获取生成器
        doc_generator = self.guishu_generator(data_list)
        # 执行批量插入
        bulk(self.es_db, doc_generator, chunk_size=5000, stats_only=False, raise_on_error=False)
        values = []
        insert_query = "INSERT INTO " + "dr_exam_category_question (qid,catid,cid) VALUES (%s, %s, %s)"
        for data in data_list:
            values.append((
                data[0],
                data[1],
                data[2]
            ))
        # 批量插入
        self.cursor.executemany(insert_query, values)
        self.connection.commit()

    # 材料题发布
    def post_cailiao(self, data_list: List[Dict]):
        # 获取生成器
        doc_generator = self.cailiao_generator(data_list)
        # 执行批量插入
        bulk(self.es_db, doc_generator, chunk_size=5000, stats_only=False, raise_on_error=False)
        values = []
        insert_query = "INSERT INTO " + "dr_exam_composite (title,qids,inputtime,cid) VALUES (%s, %s, %s, %s)"
        for data in data_list:
            values.append((
                data[0],
                data[1],
                data[2],
                data[3]
            ))
        # 批量插入
        self.cursor.executemany(insert_query, values)
        self.connection.commit()
