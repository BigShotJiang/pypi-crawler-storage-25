"""Core llm-orc functionality."""
