import importlib


class _FakeStdout:
    def __init__(self):
        self.chunks = []

    def write(self, text):
        self.chunks.append(str(text))
        return len(str(text))

    def flush(self):
        return None

    def isatty(self):
        return True

    def getvalue(self) -> str:
        return "".join(self.chunks)


def make_cli():
    cli_mod = importlib.import_module("cli")
    return cli_mod.ChatCLI(
        server="http://127.0.0.1:8000/api",
        model="gpt-5.4",
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
    )


def _usage_payload():
    return {
        "model": "gpt-5.4",
        "usage": {
            "prompt_tokens": 50,
            "completion_tokens": 5,
            "total_tokens": 55,
            "turn": {"input_tokens": 50, "output_tokens": 5, "total_tokens": 55},
            "context": {"input_tokens": 50, "output_tokens": 5, "total_tokens": 55},
            "cumulative": {"input_tokens": 50, "output_tokens": 5, "total_tokens": 55},
        },
        "provider_step": {
            "provider": "openai",
            "stage": "turn",
            "input_tokens": 50,
            "output_tokens": 5,
            "total_tokens": 55,
        },
    }


def test_context_meter_bar_omits_empty_rich_fill_markup():
    cli = make_cli()
    cli.ui.rich = True

    bar = cli._context_meter_bar(0, 5)

    assert bar == "░" * 5
    assert "[orange1]" not in bar
    assert "[/orange1]" not in bar


def test_format_live_usage_update_line_is_plain_text_without_rich_markup():
    cli = make_cli()

    line = cli._format_live_usage_update_line(_usage_payload())

    assert isinstance(line, str)
    assert "usage/openai/turn" in line
    assert "Context: 50 [" in line
    assert "[orange1]" not in line
    assert "[/orange1]" not in line


def test_render_live_usage_update_payload_uses_transient_colored_status(monkeypatch):
    cli_mod = importlib.import_module("cli")
    cli = make_cli()
    fake_stdout = _FakeStdout()
    monkeypatch.setattr(cli_mod.sys, "stdout", fake_stdout)

    shown = cli._render_live_usage_update_payload(_usage_payload(), reserve_next_line=True)

    assert shown is True
    assert cli._live_usage_status_active is True
    output = fake_stdout.getvalue()
    assert "[orange1]" not in output
    assert "[/orange1]" not in output
    assert "\x1b[38;5;214m" in output
    assert "usage/openai/turn" in output

    cli._clear_live_usage_status()
    assert cli._live_usage_status_active is False
