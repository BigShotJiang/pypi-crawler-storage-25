from app.routers import chat as chat_router


def test_gemini_thinking_config_enables_level_and_thoughts_for_gemini_35_flash():
    cfg = chat_router._gemini_effective_thinking_config(
        "gemini-3.5-flash",
        "high",
        include_thoughts=True,
    )
    assert cfg == {"thinking_level": "high", "include_thoughts": True}

    rest_cfg = chat_router._gemini_rest_thinking_config_payload(cfg)
    assert rest_cfg == {"thinkingLevel": "HIGH", "includeThoughts": True}


def test_gemini_thinking_config_ignored_for_non_gemini3_models():
    assert chat_router._gemini_effective_thinking_config(
        "gemini-1.5-flash-latest",
        "high",
        include_thoughts=True,
    ) is None


def test_gemini_thinking_config_can_request_thoughts_without_overriding_level():
    cfg = chat_router._gemini_effective_thinking_config(
        "gemini-3-flash-preview",
        None,
        include_thoughts=True,
    )
    assert cfg == {"include_thoughts": True}
