import importlib


def make_cli():
    cli_mod = importlib.import_module("cli")
    return cli_mod.ChatCLI(
        server="http://127.0.0.1:8000/api",
        model=None,
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
    )


def test_stats_full_year_chart_payload_uses_calendar_days_without_extra_fetch():
    cli = make_cli()
    bundle = {
        "year": 2025,
        "calendar_days": [
            {"date": "2025-01-01", "calls": 2, "total_tokens": 100},
            {"date": "2025-01-02", "calls": 0, "total_tokens": 0},
            {"date": "2025-01-03", "calls": 1, "total_tokens": 40},
        ],
    }

    payload = cli._stats_full_year_chart_payload(bundle)

    assert payload["year"] == 2025
    assert payload["window_days"] == 3
    assert len(payload["rolling_days"]) == 3
    assert payload["rolling_days"][0]["date"] == "2025-01-01"
    assert payload["rolling_days"][2]["date"] == "2025-01-03"
    assert payload["rolling_days"][0]["by_model"]["Total"]["total_tokens"] == 100
    assert payload["top4_models"][0]["model"] == "Total"
    assert payload["top4_models"][0]["total_tokens"] == 140
    assert payload["top4_models"][0]["calls"] == 3
