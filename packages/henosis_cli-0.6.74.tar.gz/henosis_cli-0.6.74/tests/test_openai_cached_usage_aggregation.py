import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from starlette.testclient import TestClient


_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from app.main import app
from app.settings import settings


class FakeEvent:
    def __init__(self, typ: str, delta: Optional[Any] = None):
        self.type = typ
        self.delta = delta


class FakeUsage:
    def __init__(
        self,
        *,
        input_tokens: int,
        output_tokens: int,
        cached_tokens: int,
        total_tokens: Optional[int] = None,
    ):
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens
        self.total_tokens = total_tokens if total_tokens is not None else (input_tokens + output_tokens)

        class _InputTokensDetails:
            def __init__(self, cached_tokens: int) -> None:
                self.cached_tokens = cached_tokens

        class _OutputTokensDetails:
            def __init__(self) -> None:
                self.reasoning_tokens = 0

        self.input_tokens_details = _InputTokensDetails(cached_tokens)
        self.output_tokens_details = _OutputTokensDetails()


class FakeFinal:
    def __init__(self, *, response_id: str, text: str, usage: FakeUsage, output_items: List[Dict[str, Any]]):
        self.id = response_id
        self.output_text = text
        self.usage = usage
        self.output = output_items


class FakeResponsesStreamTurn:
    def __init__(self, recorded: List[Dict[str, Any]], kwargs: Dict[str, Any], script: Dict[str, Any]):
        self._recorded = recorded
        self._kwargs = kwargs
        self._script = script
        self._recorded.append(dict(kwargs))

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def __iter__(self):
        for event in list(self._script.get("events") or []):
            yield event

    def get_final_response(self):
        return self._script["final"]


class FakeResponses:
    def __init__(self, scripts: List[Dict[str, Any]]):
        self._scripts = list(scripts)
        self._recorded: List[Dict[str, Any]] = []
        self._call_index = 0

    def stream(self, **kwargs):
        script = self._scripts[self._call_index]
        self._call_index += 1
        return FakeResponsesStreamTurn(self._recorded, kwargs, script)

    @property
    def recorded_calls(self) -> List[Dict[str, Any]]:
        return self._recorded


class FakeOpenAI:
    def __init__(self, api_key: Optional[str] = None, scripts: Optional[List[Dict[str, Any]]] = None):
        self.api_key = api_key
        self.responses = FakeResponses(list(scripts or []))


def _collect_sse_events(client: TestClient, payload: Dict[str, Any]) -> List[Dict[str, Any]]:
    response = client.post("/v0/chat/stream", json=payload)
    assert response.status_code == 200
    current_event: Optional[str] = None
    out: List[Dict[str, Any]] = []
    for line in response.iter_lines():
        text = line.decode("utf-8") if isinstance(line, (bytes, bytearray)) else str(line)
        if text.startswith("event:"):
            current_event = text[len("event:") :].strip()
            continue
        if not text.startswith("data:"):
            continue
        data_raw = text[len("data:") :].strip()
        try:
            data = json.loads(data_raw)
        except Exception:
            data = data_raw
        out.append({"event": current_event, "data": data})
    return out


def _collect_completed_payload(client: TestClient, payload: Dict[str, Any]) -> Dict[str, Any]:
    response = client.post("/v0/chat/stream", json=payload)
    assert response.status_code == 200
    current_event: Optional[str] = None
    completed: Optional[Dict[str, Any]] = None
    for line in response.iter_lines():
        text = line.decode("utf-8") if isinstance(line, (bytes, bytearray)) else str(line)
        if text.startswith("event:"):
            current_event = text[len("event:") :].strip()
            continue
        if not text.startswith("data:"):
            continue
        data_raw = text[len("data:") :].strip()
        try:
            data = json.loads(data_raw)
        except Exception:
            data = None
        if current_event == "message.completed" and isinstance(data, dict):
            completed = data
    assert completed is not None, "Did not receive message.completed payload"
    return completed


def test_openai_message_completed_aggregates_cached_tokens_across_tool_turns(monkeypatch):
    monkeypatch.setattr(settings, "OPENAI_API_KEY", "sk-test")
    monkeypatch.setattr(settings, "DISABLE_V0_ROUTES", False)
    monkeypatch.setattr(settings, "TOOLS_EXECUTION_MODE", "server")

    import app.routers.chat as chat_router

    try:
        app.include_router(chat_router.router, prefix="/v0")
    except Exception:
        pass

    scripts = [
        {
            "events": [],
            "final": FakeFinal(
                response_id="resp_step_1",
                text="",
                usage=FakeUsage(input_tokens=1000, output_tokens=10, cached_tokens=700),
                output_items=[
                    {
                        "type": "function_call",
                        "call_id": "call_read_1",
                        "name": "read_file",
                        "arguments": json.dumps({"path": "alpha.txt"}),
                    }
                ],
            ),
        },
        {
            "events": [FakeEvent("response.output_text.delta", delta="done")],
            "final": FakeFinal(
                response_id="resp_step_2",
                text="done",
                usage=FakeUsage(input_tokens=1000, output_tokens=20, cached_tokens=900),
                output_items=[
                    {
                        "type": "message",
                        "role": "assistant",
                        "content": [{"type": "output_text", "text": "done"}],
                    }
                ],
            ),
        },
    ]

    fake_holder: Dict[str, Any] = {}

    def _openai_factory(api_key: Optional[str] = None):
        inst = FakeOpenAI(api_key=api_key, scripts=scripts)
        fake_holder["inst"] = inst
        return inst

    def _fake_execute_tool(name: str, args_json: Any, policy: Any) -> Dict[str, Any]:
        return {"ok": True, "data": {"path": "alpha.txt", "content": "alpha"}}

    monkeypatch.setattr(chat_router, "OpenAI", _openai_factory)  # type: ignore[attr-defined]
    monkeypatch.setattr(chat_router, "execute_tool", _fake_execute_tool)  # type: ignore[attr-defined]
    monkeypatch.setattr(
        chat_router,
        "available_tools_for",
        lambda level, enabled: [
            {
                "type": "function",
                "name": "read_file",
                "description": "Read a file",
                "parameters": {
                    "type": "object",
                    "properties": {"path": {"type": "string"}},
                    "required": ["path"],
                },
            }
        ]
        if enabled
        else [],
    )

    client = TestClient(app)
    completed = _collect_completed_payload(
        client,
        {
            "model": "gpt-5",
            "messages": [{"role": "user", "content": "read the file and summarize it"}],
            "enable_tools": True,
            "control_level": 3,
        },
    )

    usage = completed.get("usage") or {}
    assert int(usage.get("prompt_tokens") or 0) == 2000
    assert int(usage.get("completion_tokens") or 0) == 30
    assert int(usage.get("total_tokens") or 0) == 2030

    itd = usage.get("input_tokens_details") or {}
    assert int(itd.get("cached_tokens") or 0) == 1600
    assert int(usage.get("cached_input_tokens") or 0) == 1600
    assert int(usage.get("non_cached_input_tokens") or 0) == 400

    provider_steps = usage.get("provider_steps") or []
    cached_sum = sum(int((step or {}).get("cached_input_tokens", 0) or 0) for step in provider_steps if isinstance(step, dict))
    assert cached_sum == 1600

    from app.routers.chat_adapter import _compute_cost_usd

    assert _compute_cost_usd("gpt-5", usage) > 0.0

    fake = fake_holder["inst"]
    assert len(fake.responses.recorded_calls) == 2


def test_openai_usage_update_arrives_before_tools_and_completion(monkeypatch):
    monkeypatch.setattr(settings, "OPENAI_API_KEY", "sk-test")
    monkeypatch.setattr(settings, "DISABLE_V0_ROUTES", False)
    monkeypatch.setattr(settings, "TOOLS_EXECUTION_MODE", "server")

    import app.routers.chat as chat_router

    try:
        app.include_router(chat_router.router, prefix="/v0")
    except Exception:
        pass

    scripts = [
        {
            "events": [],
            "final": FakeFinal(
                response_id="resp_step_1",
                text="",
                usage=FakeUsage(input_tokens=1000, output_tokens=10, cached_tokens=700),
                output_items=[
                    {
                        "type": "function_call",
                        "call_id": "call_read_1",
                        "name": "read_file",
                        "arguments": json.dumps({"path": "alpha.txt"}),
                    }
                ],
            ),
        },
        {
            "events": [FakeEvent("response.output_text.delta", delta="done")],
            "final": FakeFinal(
                response_id="resp_step_2",
                text="done",
                usage=FakeUsage(input_tokens=20, output_tokens=5, cached_tokens=10),
                output_items=[
                    {
                        "type": "message",
                        "role": "assistant",
                        "content": [{"type": "output_text", "text": "done"}],
                    }
                ],
            ),
        },
    ]

    def _openai_factory(api_key: Optional[str] = None):
        return FakeOpenAI(api_key=api_key, scripts=scripts)

    def _fake_execute_tool(name: str, args_json: Any, policy: Any) -> Dict[str, Any]:
        return {"ok": True, "data": {"path": "alpha.txt", "content": "alpha"}}

    monkeypatch.setattr(chat_router, "OpenAI", _openai_factory)  # type: ignore[attr-defined]
    monkeypatch.setattr(chat_router, "execute_tool", _fake_execute_tool)  # type: ignore[attr-defined]
    monkeypatch.setattr(
        chat_router,
        "available_tools_for",
        lambda level, enabled: [
            {
                "type": "function",
                "name": "read_file",
                "description": "Read a file",
                "parameters": {
                    "type": "object",
                    "properties": {"path": {"type": "string"}},
                    "required": ["path"],
                },
            }
        ]
        if enabled
        else [],
    )

    client = TestClient(app)
    events = _collect_sse_events(
        client,
        {
            "model": "gpt-5",
            "messages": [{"role": "user", "content": "read the file and summarize it"}],
            "enable_tools": True,
            "control_level": 3,
        },
    )

    event_names = [str(item.get("event") or "") for item in events]
    assert event_names.count("usage.update") >= 2
    first_usage_index = event_names.index("usage.update")
    first_tool_call_index = event_names.index("tool.call")
    final_usage_index = max(i for i, name in enumerate(event_names) if name == "usage.update")
    completed_index = event_names.index("message.completed")

    assert first_usage_index < first_tool_call_index
    assert final_usage_index < completed_index


def test_openai_replay_debug_logs_prefix_and_replay_shapes(monkeypatch):
    monkeypatch.setattr(settings, "OPENAI_API_KEY", "sk-test")
    monkeypatch.setattr(settings, "DISABLE_V0_ROUTES", False)
    monkeypatch.setattr(settings, "TOOLS_EXECUTION_MODE", "server")

    import app.routers.chat as chat_router

    try:
        app.include_router(chat_router.router, prefix="/v0")
    except Exception:
        pass

    scripts = [
        {
            "events": [],
            "final": FakeFinal(
                response_id="resp_step_1",
                text="",
                usage=FakeUsage(input_tokens=1000, output_tokens=10, cached_tokens=700),
                output_items=[
                    {
                        "type": "function_call",
                        "call_id": "call_read_1",
                        "name": "read_file",
                        "arguments": json.dumps({"path": "alpha.txt"}),
                    }
                ],
            ),
        },
        {
            "events": [FakeEvent("response.output_text.delta", delta="done")],
            "final": FakeFinal(
                response_id="resp_step_2",
                text="done",
                usage=FakeUsage(input_tokens=1000, output_tokens=20, cached_tokens=900),
                output_items=[
                    {
                        "type": "message",
                        "role": "assistant",
                        "content": [{"type": "output_text", "text": "done"}],
                    }
                ],
            ),
        },
    ]

    captured_logs: List[Dict[str, Any]] = []

    def _openai_factory(api_key: Optional[str] = None):
        return FakeOpenAI(api_key=api_key, scripts=scripts)

    def _fake_execute_tool(name: str, args_json: Any, policy: Any) -> Dict[str, Any]:
        return {"ok": True, "data": {"path": "alpha.txt", "content": "alpha"}}

    def _fake_log_event(filename: str, payload: Dict[str, Any]) -> None:
        captured_logs.append({"filename": filename, **dict(payload or {})})

    monkeypatch.setattr(chat_router, "OpenAI", _openai_factory)  # type: ignore[attr-defined]
    monkeypatch.setattr(chat_router, "execute_tool", _fake_execute_tool)  # type: ignore[attr-defined]
    monkeypatch.setattr(chat_router, "_log_event", _fake_log_event)  # type: ignore[attr-defined]
    monkeypatch.setattr(
        chat_router,
        "available_tools_for",
        lambda level, enabled: [
            {
                "type": "function",
                "name": "read_file",
                "description": "Read a file",
                "parameters": {
                    "type": "object",
                    "properties": {"path": {"type": "string"}},
                    "required": ["path"],
                },
            }
        ]
        if enabled
        else [],
    )

    client = TestClient(app)
    completed = _collect_completed_payload(
        client,
        {
            "model": "gpt-5",
            "messages": [{"role": "user", "content": "read the file and summarize it"}],
            "enable_tools": True,
            "control_level": 3,
        },
    )

    assert completed.get("openai_delta_items")

    kinds = [entry.get("kind") for entry in captured_logs]
    assert "openai.request.items" in kinds
    assert "openai.request.prefix_compare" in kinds
    assert "openai.output_items" in kinds
    assert "openai.replay_output_items" in kinds
    assert "openai.delta_items" in kinds

    prefix_event = next(entry for entry in captured_logs if entry.get("kind") == "openai.request.prefix_compare")
    assert prefix_event.get("previous_items_count") == 1
    assert prefix_event.get("current_items_count") == 3
    assert prefix_event.get("matching_prefix_items") == 1
    assert prefix_event.get("previous_fully_matches_prefix") is True

    replay_events = [entry for entry in captured_logs if entry.get("kind") == "openai.replay_output_items"]
    assert any(int(entry.get("items_count") or 0) == 1 for entry in replay_events)
    assert all(isinstance(entry.get("items_sha256"), str) and len(entry.get("items_sha256")) == 64 for entry in replay_events)
