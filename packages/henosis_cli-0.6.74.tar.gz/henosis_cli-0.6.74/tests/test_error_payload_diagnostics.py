import importlib


class _FakeResponse:
    def __init__(self, *, status_code=400, text="", json_data=None):
        self.status_code = status_code
        self.text = text
        self._json_data = json_data

    def json(self):
        if isinstance(self._json_data, Exception):
            raise self._json_data
        return self._json_data


class _FakeError(Exception):
    def __init__(self, response):
        super().__init__()
        self.response = response

    def __str__(self):
        return ""


def test_extract_exact_error_response_prefers_response_json():
    cli_mod = importlib.import_module("cli")

    payload = {"response_json": {"error": {"message": "provider said no"}}}

    text = cli_mod.extract_exact_error_response(payload)

    assert text is not None
    assert "provider said no" in text


def test_extract_exact_error_response_falls_back_to_nested_response_text():
    cli_mod = importlib.import_module("cli")

    payload = {"error": {"response_text": "raw upstream body"}}

    assert cli_mod.extract_exact_error_response(payload) == "raw upstream body"


def test_error_payload_includes_response_text_and_json():
    chat_mod = importlib.import_module("app.routers.chat")
    response = _FakeResponse(
        status_code=429,
        text="raw provider body",
        json_data={"error": {"message": "quota exceeded"}},
    )
    error = _FakeError(response)

    payload = chat_mod._error_payload(error)

    assert payload["status_code"] == 429
    assert payload["response_text"] == "raw provider body"
    assert payload["response_json"] == {"error": {"message": "quota exceeded"}}
