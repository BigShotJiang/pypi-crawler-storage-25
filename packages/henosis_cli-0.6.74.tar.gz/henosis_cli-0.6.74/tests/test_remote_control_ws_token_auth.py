from __future__ import annotations

from fastapi.testclient import TestClient

from app.main import app
from app.routers import remote_control as remote_control_router
from app.routers.auth import (
    authenticate_remote_control_ws_token,
    create_remote_control_ws_token,
    get_current_user_with_refresh,
)


client = TestClient(app)


class _DummyDb:
    def close(self):
        return None


def test_remote_control_ws_token_round_trip():
    token = create_remote_control_ws_token('mobile-agent-user')
    assert token
    assert authenticate_remote_control_ws_token(token) == 'mobile-agent-user'


def test_remote_control_ws_token_endpoint_issues_query_token():
    app.dependency_overrides[get_current_user_with_refresh] = lambda: 'mobile-agent-user'
    try:
        response = client.post('/api/remote-control/ws-token')
    finally:
        app.dependency_overrides.pop(get_current_user_with_refresh, None)

    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload['auth_mode'] == 'query_token'
    assert payload['user'] == 'mobile-agent-user'
    assert authenticate_remote_control_ws_token(payload['token']) == 'mobile-agent-user'


def test_remote_control_ws_accepts_query_token(monkeypatch):
    token = create_remote_control_ws_token('mobile-agent-user')
    monkeypatch.setattr(remote_control_router, '_open_websocket_db', lambda: _DummyDb())

    with client.websocket_connect(f'/api/remote-control/ws?token={token}') as websocket:
        first = websocket.receive_json()
        assert first['type'] == 'remote.connected'
        assert first['data']['connected'] is False
        second = websocket.receive_json()
        assert second['type'] == 'remote.terminals'
        third = websocket.receive_json()
        assert third['type'] == 'remote.selected'
