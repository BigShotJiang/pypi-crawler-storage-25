import asyncio
import importlib


def make_cli():
    cli_mod = importlib.import_module("cli")
    return cli_mod.ChatCLI(
        server="http://127.0.0.1:8000/api",
        model=None,
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
    )


def test_goal_command_sets_goal_and_prepares_immediate_user_message():
    cli = make_cli()
    text = "ship the feature and verify tests pass"
    assert asyncio.run(cli.handle_command(f"/goal {text}")) is False
    assert isinstance(cli.active_goal, dict)
    assert cli.active_goal["goal"] == text
    assert cli.active_goal["task"] == text
    assert cli.active_goal["success_criteria"] == ""
    assert text in cli._pending_command_user_input
    assert "New active goal" in cli._pending_command_user_input


def test_goal_command_status_and_clear_are_local_only():
    cli = make_cli()
    cli.active_goal = {"active": True, "completed": False, "goal": "ship it"}
    assert asyncio.run(cli.handle_command("/goal status")) is True
    assert cli._pending_command_user_input is None

    assert asyncio.run(cli.handle_command("/goal clear")) is True
    assert cli.active_goal is None
    assert cli._pending_command_user_input is None
