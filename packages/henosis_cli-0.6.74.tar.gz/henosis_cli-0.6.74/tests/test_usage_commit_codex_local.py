from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool

from app.routers import usage as usage_router


def _build_usage_app():
    engine = create_engine(
        "sqlite://",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
    with engine.begin() as conn:
        conn.execute(
            text(
                """
                CREATE TABLE model_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT,
                    model_id TEXT,
                    tokens_input INTEGER,
                    tokens_output INTEGER,
                    cost REAL,
                    status TEXT,
                    billing_source TEXT,
                    cached_input_tokens INTEGER,
                    non_cached_input_tokens INTEGER,
                    advisor_cost_usd REAL,
                    advisor_status TEXT,
                    advisor_billing_source TEXT,
                    advisor_input_tokens INTEGER,
                    advisor_output_tokens INTEGER,
                    advisor_total_tokens INTEGER,
                    session_id TEXT,
                    thread_uid TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
        )
        conn.execute(
            text(
                """
                CREATE TABLE users (
                    username TEXT PRIMARY KEY,
                    credits REAL,
                    subscription_tier TEXT,
                    subscription_status TEXT
                )
                """
            )
        )
        conn.execute(
            text("INSERT INTO users (username, credits, subscription_tier, subscription_status) VALUES ('henosis', 10.0, 'free', 'none')")
        )

    app = FastAPI()
    app.include_router(usage_router.router)

    def override_db():
        db = SessionLocal()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[usage_router.get_db] = override_db
    app.dependency_overrides[usage_router.get_current_user] = lambda: "henosis"
    return app, engine


def test_codex_local_commit_inserts_analytics_row_without_credit_deduction():
    app, engine = _build_usage_app()
    client = TestClient(app)

    payload = {
        "session_id": "sess-codex-local-1",
        "model": "gpt-5.4",
        "usage": {"prompt_tokens": 120, "completion_tokens": 30, "total_tokens": 150},
        "meta": {"billing_source": "codex_local"},
    }
    response = client.post("/api/usage/commit", json=payload)
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["ok"] is True
    assert body["remaining_credits"] == 10.0

    with Session(engine) as db:
        row = db.execute(
            text(
                "SELECT status, billing_source, tokens_input, tokens_output FROM model_logs LIMIT 1"
            )
        ).mappings().first()
        assert row is not None
        assert row["status"] == "codex_local"
        assert row["billing_source"] == "codex_local"
        credits = db.execute(text("SELECT credits FROM users WHERE username = 'henosis'")).scalar_one()
        assert float(credits) == 10.0


def test_codex_local_commit_persists_advisor_usage_columns():
    app, engine = _build_usage_app()
    client = TestClient(app)

    payload = {
        "session_id": "sess-codex-local-advisor-1",
        "model": "gpt-5.5",
        "usage": {
            "prompt_tokens": 120,
            "completion_tokens": 30,
            "total_tokens": 150,
            "advisor_enabled": True,
            "advisor_calls": 1,
            "advisor_cost_usd": 0.123456,
            "advisor_usage": {
                "input_tokens": 1000,
                "output_tokens": 200,
                "total_tokens": 1200,
            },
        },
        "meta": {"billing_source": "codex_local"},
    }
    response = client.post("/api/usage/commit", json=payload)
    assert response.status_code == 200, response.text

    with Session(engine) as db:
        row = db.execute(
            text(
                """
                SELECT advisor_cost_usd, advisor_status, advisor_billing_source,
                       advisor_input_tokens, advisor_output_tokens, advisor_total_tokens
                FROM model_logs
                LIMIT 1
                """
            )
        ).mappings().first()
        assert row is not None
        assert float(row["advisor_cost_usd"] or 0.0) == 0.123456
        assert row["advisor_status"] == "codex_local"
        assert row["advisor_billing_source"] == "codex_local"
        assert int(row["advisor_input_tokens"] or 0) == 1000
        assert int(row["advisor_output_tokens"] or 0) == 200
        assert int(row["advisor_total_tokens"] or 0) == 1200


def test_codex_local_commit_not_suppressed_by_nearby_backend_row():
    app, engine = _build_usage_app()
    client = TestClient(app)

    with engine.begin() as conn:
        conn.execute(
            text(
                """
                INSERT INTO model_logs (
                    user_id, model_id, tokens_input, tokens_output, cost, status, billing_source, cached_input_tokens, non_cached_input_tokens, created_at
                ) VALUES (
                    'henosis', 'gpt-5.4', 120, 30, 0.5, 'success', 'backend_openai', 0, 120, CURRENT_TIMESTAMP
                )
                """
            )
        )

    payload = {
        "session_id": "sess-codex-local-2",
        "model": "gpt-5.4",
        "usage": {"prompt_tokens": 120, "completion_tokens": 30, "total_tokens": 150},
        "meta": {"billing_source": "codex_local"},
    }
    response = client.post("/api/usage/commit", json=payload)
    assert response.status_code == 200, response.text

    with Session(engine) as db:
        rows = db.execute(
            text(
                "SELECT status, billing_source FROM model_logs ORDER BY id ASC"
            )
        ).mappings().all()
        assert len(rows) == 2
        assert rows[0]["billing_source"] == "backend_openai"
        assert rows[1]["billing_source"] == "codex_local"


def test_subscription_billed_commit_inserts_log_without_credit_deduction():
    app, engine = _build_usage_app()
    client = TestClient(app)

    payload = {
        "session_id": "sess-sub-gh-1",
        "model": "gpt-5.4",
        "usage": {"prompt_tokens": 120, "completion_tokens": 30, "total_tokens": 150},
        "meta": {"billing_source": "sub_github_copilot"},
    }
    response = client.post("/api/usage/commit", json=payload)
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["ok"] is True
    assert body["remaining_credits"] == 10.0

    with Session(engine) as db:
        row = db.execute(
            text("SELECT status, billing_source FROM model_logs LIMIT 1")
        ).mappings().first()
        assert row is not None
        assert row["status"] == "success"
        assert row["billing_source"] == "sub_github_copilot"
        credits = db.execute(text("SELECT credits FROM users WHERE username = 'henosis'")).scalar_one()
        assert float(credits) == 10.0


def test_subscription_commit_not_suppressed_by_nearby_codex_local_row():
    app, engine = _build_usage_app()
    client = TestClient(app)

    with engine.begin() as conn:
        conn.execute(
            text(
                """
                INSERT INTO model_logs (
                    user_id, model_id, tokens_input, tokens_output, cost, status, billing_source, cached_input_tokens, non_cached_input_tokens, created_at
                ) VALUES (
                    'henosis', 'gpt-5.4', 120, 30, 0.5, 'codex_local', 'codex_local', 0, 120, CURRENT_TIMESTAMP
                )
                """
            )
        )

    payload = {
        "session_id": "sess-sub-droid-2",
        "model": "gpt-5.4",
        "usage": {"prompt_tokens": 120, "completion_tokens": 30, "total_tokens": 150},
        "meta": {"billing_source": "sub_droid"},
    }
    response = client.post("/api/usage/commit", json=payload)
    assert response.status_code == 200, response.text

    with Session(engine) as db:
        rows = db.execute(
            text("SELECT status, billing_source FROM model_logs ORDER BY id ASC")
        ).mappings().all()
        assert len(rows) == 2
        assert rows[0]["billing_source"] == "codex_local"
        assert rows[1]["billing_source"] == "sub_droid"


def test_usage_commit_persists_thread_uid():
    app, engine = _build_usage_app()
    client = TestClient(app)

    payload = {
        "session_id": "sess-thread-1",
        "thread_uid": "thread-abc",
        "model": "gpt-5.4",
        "usage": {"prompt_tokens": 120, "completion_tokens": 30, "total_tokens": 150},
        "meta": {"billing_source": "codex_local"},
    }
    response = client.post("/api/usage/commit", json=payload)
    assert response.status_code == 200, response.text

    with Session(engine) as db:
        row = db.execute(
            text("SELECT session_id, thread_uid FROM model_logs LIMIT 1")
        ).mappings().first()
        assert row is not None
        assert row["session_id"] == "sess-thread-1"
        assert row["thread_uid"] == "thread-abc"


def test_usage_commit_backfills_thread_uid_on_existing_matching_row():
    app, engine = _build_usage_app()
    client = TestClient(app)

    with engine.begin() as conn:
        conn.execute(
            text(
                """
                INSERT INTO model_logs (
                    user_id, model_id, tokens_input, tokens_output, cost, status,
                    billing_source, cached_input_tokens, non_cached_input_tokens,
                    session_id, thread_uid, created_at
                ) VALUES (
                    'henosis', 'gpt-5.4', 120, 30, 0.5, 'codex_local',
                    'codex_local', 0, 120,
                    NULL, NULL, CURRENT_TIMESTAMP
                )
                """
            )
        )

    payload = {
        "session_id": "sess-thread-2",
        "thread_uid": "thread-backfill",
        "model": "gpt-5.4",
        "usage": {"prompt_tokens": 120, "completion_tokens": 30, "total_tokens": 150},
        "meta": {"billing_source": "codex_local"},
    }
    response = client.post("/api/usage/commit", json=payload)
    assert response.status_code == 200, response.text

    with Session(engine) as db:
        rows = db.execute(
            text("SELECT session_id, thread_uid FROM model_logs ORDER BY id ASC")
        ).mappings().all()
        assert len(rows) == 1
        assert rows[0]["session_id"] == "sess-thread-2"
        assert rows[0]["thread_uid"] == "thread-backfill"
