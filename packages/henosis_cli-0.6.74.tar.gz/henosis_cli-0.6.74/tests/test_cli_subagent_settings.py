import asyncio
import importlib
import json
from pathlib import Path


def make_cli(tmp_path=None):
    cli_mod = importlib.import_module("cli")
    cli = cli_mod.ChatCLI(
        server="http://127.0.0.1:8000/api",
        model=None,
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
        workspace_dir=(str(tmp_path) if tmp_path is not None else None),
    )
    if tmp_path is not None:
        cli.local_workspace_dir = str(tmp_path)
    return cli


def test_subagent_settings_round_trip(tmp_path):
    cli = make_cli(tmp_path)
    cli.subagent_tool_enabled = False
    cli.subagent_allowed_models = ["gpt-5.4", "gpt-5.5"]
    cli.subagent_allowed_reasoning_levels = ["low", "medium", "xhigh"]

    data = cli._collect_settings_dict()
    assert data["subagent_tool_enabled"] is False
    assert data["subagent_allowed_models"] == ["gpt-5.4", "gpt-5.5"]
    assert data["subagent_allowed_reasoning_levels"] == ["low", "medium", "xhigh"]

    cli2 = make_cli(tmp_path)
    cli2._apply_settings_dict(data)
    assert cli2.subagent_tool_enabled is False
    assert cli2.subagent_allowed_models == ["gpt-5.4", "gpt-5.5"]
    assert cli2.subagent_allowed_reasoning_levels == ["low", "medium", "xhigh"]


def test_subagent_tool_schemas_obey_enable_and_worker_mode(tmp_path):
    cli = make_cli(tmp_path)
    tool_names = {
        tool.get("name")
        for tool in cli._codex_local_tool_schemas(level=3, tools_enabled=True, browser_tools_enabled=False, advisor_enabled=False)
        if isinstance(tool, dict)
    }
    assert {"subagent_spawn", "subagent_check", "subagent_list", "subagent_kill", "subagent_message"}.issubset(tool_names)

    cli.subagent_tool_enabled = False
    tool_names_disabled = {
        tool.get("name")
        for tool in cli._codex_local_tool_schemas(level=3, tools_enabled=True, browser_tools_enabled=False, advisor_enabled=False)
        if isinstance(tool, dict)
    }
    assert "subagent_spawn" not in tool_names_disabled

    cli.subagent_tool_enabled = True
    cli._subagent_worker_mode = True
    tool_names_worker = {
        tool.get("name")
        for tool in cli._codex_local_tool_schemas(level=3, tools_enabled=True, browser_tools_enabled=False, advisor_enabled=False)
        if isinstance(tool, dict)
    }
    assert "subagent_spawn" not in tool_names_worker


def test_subagent_choice_from_reply_matches_values_and_indices(tmp_path):
    cli = make_cli(tmp_path)
    choices = [("retry_once", "Retry once"), ("keep_failure", "Keep failure")]
    assert cli._subagent_choice_from_reply("retry_once", choices, "keep_failure") == "retry_once"
    assert cli._subagent_choice_from_reply("1", choices, "keep_failure") == "retry_once"
    assert cli._subagent_choice_from_reply("keep failure", choices, "keep_failure") == "keep_failure"
    assert cli._subagent_choice_from_reply("", choices, "keep_failure") == "keep_failure"


def test_subagent_check_returns_unseen_events_only(tmp_path):
    cli = make_cli(tmp_path)
    subagent_id = "sub_test"
    paths = cli._subagent_paths(subagent_id)
    paths["root"].mkdir(parents=True, exist_ok=True)
    manifest = {
        "subagent_id": subagent_id,
        "name": "test-subagent",
        "status": "completed",
        "model": "gpt-5.4",
        "reasoning_level": "medium",
        "queued_messages": 0,
        "pending_runtime_prompt": None,
    }
    paths["manifest"].write_text(json.dumps(manifest), encoding="utf-8")
    paths["events"].write_text(
        "\n".join(
            [
                json.dumps({"seq": 1, "type": "status_change", "status": "running"}),
                json.dumps({"seq": 2, "type": "assistant_message", "text": "hello"}),
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    first = asyncio.run(cli._subagent_check_tool({"subagent_id": subagent_id}))
    assert first["ok"] is True
    first_events = first["data"]["events"]
    assert [event["seq"] for event in first_events] == [1, 2]

    second = asyncio.run(cli._subagent_check_tool({"subagent_id": subagent_id}))
    assert second["ok"] is True
    assert second["data"]["events"] == []
