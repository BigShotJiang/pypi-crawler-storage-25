from types import SimpleNamespace

import henosis_cli_tools.browser_impl as client_browser
from app.tools import browser_tools as server_browser


class _FakePage:
    def __init__(self):
        self.url = "https://example.com"

    def title(self):
        return "Example"


class _FakeManager:
    def __init__(self):
        self.page = _FakePage()
        self.state = SimpleNamespace(
            session_key="sess_1",
            active_tab_id="tab_1",
            allowed_domains=(),
            tabs={"tab_1": self.page},
        )
        self.default_session_key_calls = 0
        self.ensure_session_calls = []
        self.get_page_calls = []

    def get_default_session_key(self):
        self.default_session_key_calls += 1
        return "sess_1"

    def ensure_session(self, session_key, allowed_domains, create=True):
        self.ensure_session_calls.append((session_key, tuple(allowed_domains), bool(create)))
        if session_key != "sess_1":
            raise AssertionError(f"unexpected session_key {session_key!r}")
        return self.state

    def get_session(self, session_key):
        if session_key != "sess_1":
            raise AssertionError(f"unexpected session_key {session_key!r}")
        return self.state

    def get_page(self, state, tab_id=None):
        self.get_page_calls.append((state.session_key, tab_id))
        if state is not self.state:
            raise AssertionError("unexpected state")
        if tab_id not in (None, "tab_1"):
            raise server_browser.BrowserPolicyError(f"unknown tab_id {tab_id!r}")
        return "tab_1", self.page

    def list_tabs(self, state):
        if state is None:
            return []
        return [{"tab_id": "tab_1", "url": self.page.url, "title": self.page.title(), "active": True}]

    def invalidate_tab_snapshots(self, state, tab_id):
        if state is not self.state or tab_id != "tab_1":
            raise AssertionError("unexpected invalidate call")


def test_client_browser_tabs_select_reuses_remembered_default_session(monkeypatch):
    manager = _FakeManager()
    monkeypatch.setattr(client_browser, "_get_browser_manager", lambda: manager)

    out = client_browser._execute_browser_tool_sync(
        "browser_tabs",
        {"action": "select", "tab_id": "tab_1"},
        policy=None,
    )

    assert out["ok"] is True
    assert out["data"]["session_key"] == "sess_1"
    assert out["data"]["active_tab"]["tab_id"] == "tab_1"
    assert manager.default_session_key_calls == 1
    assert manager.ensure_session_calls[0][0] == "sess_1"
    assert manager.get_page_calls == [("sess_1", "tab_1")]


def test_server_browser_tabs_select_reuses_remembered_default_session(monkeypatch):
    manager = _FakeManager()
    monkeypatch.setattr(server_browser, "_get_browser_manager", lambda: manager)
    monkeypatch.setattr(server_browser.settings, "ENABLE_BROWSER_TOOLS", True)

    out = server_browser._execute_browser_tool_sync(
        "browser_tabs",
        {"action": "select", "tab_id": "tab_1"},
        policy=None,
    )

    assert out["ok"] is True
    assert out["data"]["session_key"] == "sess_1"
    assert out["data"]["active_tab"]["tab_id"] == "tab_1"
    assert manager.default_session_key_calls == 1
    assert manager.ensure_session_calls[0][0] == "sess_1"
    assert manager.get_page_calls == [("sess_1", "tab_1")]
