import asyncio
import importlib
import json

import pytest


def make_cli():
    cli_mod = importlib.import_module("cli")
    return cli_mod.ChatCLI(
        server="http://127.0.0.1:8000/api",
        model=None,
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
    )


def test_turn_elapsed_freezes_after_finalize(monkeypatch):
    cli_mod = importlib.import_module("cli")
    cli = make_cli()
    values = iter([10.0, 14.25, 99.0])
    monkeypatch.setattr(cli_mod.time, "perf_counter", lambda: next(values))

    assert cli._begin_turn_timer() == pytest.approx(10.0)
    assert cli._turn_elapsed_seconds(finalize=True) == pytest.approx(4.25)
    assert cli._turn_elapsed_seconds() == pytest.approx(4.25)


def test_stream_once_starts_turn_timer_for_local_codex(monkeypatch):
    cli_mod = importlib.import_module("cli")
    cli = make_cli()
    seen = {}

    monkeypatch.setattr(cli_mod.time, "perf_counter", lambda: 123.0)
    monkeypatch.setattr(cli, "_should_use_local_codex_for_model", lambda model: True)

    async def fake_stream(user_input: str) -> str:
        seen["started_at"] = cli._turn_started_at
        seen["cached_duration"] = cli._last_turn_duration_secs
        return "ok"

    monkeypatch.setattr(cli, "_stream_codex_local_once", fake_stream)

    assert asyncio.run(cli._stream_once("hello")) == "ok"
    assert seen["started_at"] == pytest.approx(123.0)
    assert seen["cached_duration"] is None


def test_remote_control_timing_payload_exposes_legacy_and_nested_aliases():
    cli = make_cli()
    cli._session_started_at_ms = 12000
    cli._turn_started_at_ms = 34000

    payload = cli._build_remote_control_timing_payload(
        turn_secs=4.25,
        session_secs=12.5,
        tool_calls=3,
        formatter=lambda secs: f"{secs:.2f}s",
    )

    assert payload["timing_ms"] == 4250
    assert payload["duration_ms"] == 4250
    assert payload["elapsed_ms"] == 4250
    assert payload["turn_duration_ms"] == 4250
    assert payload["turn_time_ms"] == 4250
    assert payload["session_elapsed_ms"] == 12500
    assert payload["session_duration_ms"] == 12500
    assert payload["turn_started_at_ms"] == 34000
    assert payload["session_started_at_ms"] == 12000
    assert payload["tool_calls"] == 3
    assert payload["timing_line"] == "Time: 4.25s (turn) | 12.50s (session) | Tools: 3 call(s)"
    assert payload["timing"] == {
        "ms": 4250,
        "duration_ms": 4250,
        "elapsed_ms": 4250,
        "turn_duration_ms": 4250,
        "turn_time_ms": 4250,
        "session_elapsed_ms": 12500,
        "session_duration_ms": 12500,
        "turn_started_at_ms": 34000,
        "session_started_at_ms": 12000,
        "tool_calls": 3,
    }


def test_remote_control_snapshot_includes_live_timing_timestamps():
    cli = make_cli()
    cli._session_started_at_ms = 1111
    cli._turn_started_at_ms = 2222
    cli._busy = True
    cli._current_turn = cli._empty_current_turn()
    cli._current_turn.update({
        "active": True,
        "session_id": "sess-live",
        "model": "gpt-5.4",
        "turn_started_at_ms": 2222,
        "session_started_at_ms": 1111,
    })

    snapshot = cli._build_remote_control_snapshot()
    snapshot_meta = cli._build_remote_control_snapshot_meta()

    assert snapshot["session_started_at_ms"] == 1111
    assert snapshot["current_turn"]["turn_started_at_ms"] == 2222
    assert snapshot["current_turn"]["session_started_at_ms"] == 1111
    assert snapshot["terminal"]["session_started_at_ms"] == 1111
    assert snapshot["terminal"]["turn_started_at_ms"] == 2222
    assert snapshot_meta["session_started_at_ms"] == 1111
    assert snapshot_meta["terminal"]["session_started_at_ms"] == 1111
    assert snapshot_meta["terminal"]["turn_started_at_ms"] == 2222


def test_backend_message_completed_uses_remote_control_timing_payload(monkeypatch):
    cli_mod = importlib.import_module("cli")
    cli = make_cli()
    cli.model = "gpt-5.4"
    cli.auth_user = "user@example.com"
    cli.codex_access_token = None
    cli.codex_refresh_token = None
    cli.codex_expiry_date = None
    cli.codex_route_all_openai_models = False

    events = []
    timing_payload = {
        "timing_ms": 777,
        "duration_ms": 777,
        "elapsed_ms": 777,
        "turn_duration_ms": 777,
        "turn_time_ms": 777,
        "session_elapsed_ms": 1888,
        "session_duration_ms": 1888,
        "tool_calls": 9,
        "timing_line": "Time: 0.78s (turn) | 1.89s (session) | Tools: 9 call(s)",
        "timing": {
            "ms": 777,
            "duration_ms": 777,
            "elapsed_ms": 777,
            "turn_duration_ms": 777,
            "turn_time_ms": 777,
            "session_elapsed_ms": 1888,
            "session_duration_ms": 1888,
            "tool_calls": 9,
        },
    }

    monkeypatch.setattr(cli, "_build_remote_control_timing_payload", lambda **kwargs: dict(timing_payload))
    monkeypatch.setattr(cli, "_ensure_thread", lambda client: asyncio.sleep(0))
    monkeypatch.setattr(cli, "_save_conversation", lambda *args, **kwargs: asyncio.sleep(0))
    monkeypatch.setattr(cli, "_commit_usage", lambda *args, **kwargs: asyncio.sleep(0))
    monkeypatch.setattr(cli, "_render_status_info_force_billing", lambda ctx: None)
    monkeypatch.setattr(cli, "_build_remote_control_context_info", lambda *args, **kwargs: {})
    monkeypatch.setattr(cli, "_build_remote_control_billing_info", lambda *args, **kwargs: {})
    monkeypatch.setattr(cli.ui, "print", lambda *args, **kwargs: None)
    monkeypatch.setattr(cli.ui, "warn", lambda *args, **kwargs: None)
    monkeypatch.setattr(cli.ui, "ensure_newline", lambda text: None)

    async def fake_ws_broadcast(event_type, data):
        events.append((event_type, dict(data or {})))

    monkeypatch.setattr(cli, "_ws_broadcast", fake_ws_broadcast)

    class _FakeStreamResp:
        status_code = 200
        headers = {"content-type": "text/event-stream"}
        text = ""

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def raise_for_status(self):
            return None

        async def aiter_lines(self):
            payload_completed = {
                "model": "gpt-5.4",
                "usage": {"prompt_tokens": 5, "completion_tokens": 2, "total_tokens": 7},
                "text": "Hello world",
            }
            lines = [
                "event: message.completed",
                "data: " + json.dumps(payload_completed),
                "",
            ]
            for line in lines:
                yield line

    class _FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def stream(self, method, url, json=None, headers=None, follow_redirects=None):
            return _FakeStreamResp()

    monkeypatch.setattr(cli_mod.httpx, "AsyncClient", _FakeAsyncClient)

    assert asyncio.run(cli._stream_once("hello")) == "Hello world"
    completed = next(payload for event_type, payload in events if event_type == "message.completed")
    for key, expected in timing_payload.items():
        assert completed[key] == expected
