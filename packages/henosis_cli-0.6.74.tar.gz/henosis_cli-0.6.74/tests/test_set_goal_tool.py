from types import SimpleNamespace

from app.controls import L1, L3, available_tools_for
from app.routers import chat as chat_router
from app.tools.file_tools import FILE_TOOLS, FileToolPolicy
from henosis_cli_tools.advisor import _extract_json_object, invoke_goal_evaluator, AdvisorConfig


def _names(tools):
    return {t.get("name") for t in tools if isinstance(t, dict)}


def test_set_goal_tool_schema_is_exposed_with_advisor():
    names = _names(available_tools_for(L1, tools_enabled=False, browser_tools_enabled=False, advisor_enabled=True))
    assert "set_goal" in names
    names_l3 = _names(available_tools_for(L3, tools_enabled=True, browser_tools_enabled=False, advisor_enabled=True))
    assert "set_goal" in names_l3


def test_set_goal_is_server_only_and_strict_schema_valid():
    assert chat_router._is_server_only_tool("set_goal") is True
    tool = next(t for t in FILE_TOOLS if t.get("name") == "set_goal")
    props = set((tool.get("parameters") or {}).get("properties") or {})
    assert set((tool.get("parameters") or {}).get("required") or []) == props


def test_execute_server_only_set_goal_updates_state(tmp_path):
    goal_state = chat_router._new_goal_state()
    policy = FileToolPolicy(workspace_base=tmp_path, scope="workspace")
    out = chat_router._execute_server_only_tool_result(
        name="set_goal",
        args_payload={"goal": "ship feature and make tests pass"},
        file_policy=policy,
        advisor_config=SimpleNamespace(enabled=True),
        advisor_state=chat_router._new_advisor_state(),
        goal_state=goal_state,
        system_prompt="",
        conversation_items=[],
        model_name="gpt-test",
        provider_name="openai",
        tools_enabled=True,
        control_level=3,
    )
    assert out["ok"] is True
    assert goal_state["active"] is True
    assert goal_state["goal"] == "ship feature and make tests pass"


def test_goal_evaluator_parses_json(monkeypatch):
    def fake_invoke(config, transcript, api_key=None):
        return SimpleNamespace(
            ok=True,
            text='{"complete": false, "reason": "missing tests", "feedback_to_executor": "run tests"}',
            advisor_model="gpt-test",
            reasoning_effort="low",
            usage={"input_tokens": 1, "output_tokens": 2, "total_tokens": 3},
            cost_usd=0.01,
        )

    monkeypatch.setattr("henosis_cli_tools.advisor.invoke_advisor", fake_invoke)
    result = invoke_goal_evaluator(
        AdvisorConfig(enabled=True, advisor_model="gpt-test", reasoning_effort="low", auth_mode="byok", max_uses=1, timeout_sec=10),
        [{"role": "user", "content": "hi"}],
        api_key="sk-test",
    )
    assert result.ok is True
    assert result.complete is False
    assert result.feedback_to_executor == "run tests"


def test_extract_json_object_tolerates_wrapped_text():
    assert _extract_json_object('prefix {"complete": true, "reason": "ok"} suffix')["complete"] is True


def test_goal_state_can_seed_from_client_carried_active_goal():
    state = chat_router._seed_goal_state_from_body(
        chat_router._new_goal_state(),
        SimpleNamespace(active_goal={"active": True, "goal": "multi day until done", "evaluator_calls": 2}),
    )
    assert state["active"] is True
    assert state["goal"] == "multi day until done"
    assert state["evaluator_calls"] == 2


def test_completed_payload_echoes_active_goal_for_client_carry():
    payload = {}
    state = chat_router._new_goal_state()
    state.update({"active": True, "goal": "carry me until ok", "task": "carry me until ok", "evaluator_calls": 1})
    chat_router._apply_goal_state_to_completed_payload(payload, state)
    assert payload["active_goal"]["goal"] == "carry me until ok"
    assert payload["active_goal"]["active"] is True


def test_set_goal_does_not_replace_active_incomplete_goal(tmp_path):
    goal_state = chat_router._new_goal_state()
    goal_state.update(
        {
            "active": True,
            "completed": False,
            "goal": "current goal",
            "task": "current goal",
            "success_criteria": "current criteria",
        }
    )
    policy = FileToolPolicy(workspace_base=tmp_path, scope="workspace")

    out = chat_router._execute_server_only_tool_result(
        name="set_goal",
        args_payload={"goal": "new goal with new criteria"},
        file_policy=policy,
        advisor_config=SimpleNamespace(enabled=True),
        advisor_state=chat_router._new_advisor_state(),
        goal_state=goal_state,
        system_prompt="",
        conversation_items=[],
        model_name="gpt-test",
        provider_name="openai",
        tools_enabled=True,
        control_level=3,
    )

    assert out["ok"] is False
    assert out["error_code"] == "active_goal_exists"
    assert goal_state["active"] is True
    assert goal_state["completed"] is False
    assert goal_state["goal"] == "current goal"


def test_set_goal_can_set_new_goal_after_previous_completed(tmp_path):
    goal_state = chat_router._new_goal_state()
    goal_state.update(
        {
            "active": False,
            "completed": True,
            "goal": "old goal",
            "task": "old goal",
            "success_criteria": "old criteria",
        }
    )
    policy = FileToolPolicy(workspace_base=tmp_path, scope="workspace")

    out = chat_router._execute_server_only_tool_result(
        name="set_goal",
        args_payload={"goal": "new goal with new criteria"},
        file_policy=policy,
        advisor_config=SimpleNamespace(enabled=True),
        advisor_state=chat_router._new_advisor_state(),
        goal_state=goal_state,
        system_prompt="",
        conversation_items=[],
        model_name="gpt-test",
        provider_name="openai",
        tools_enabled=True,
        control_level=3,
    )

    assert out["ok"] is True
    assert goal_state["active"] is True
    assert goal_state["completed"] is False
    assert goal_state["goal"] == "new goal with new criteria"
    assert goal_state["task"] == "new goal with new criteria"
    assert goal_state["success_criteria"] == ""


def test_set_goal_accepts_legacy_task_success_criteria_payload(tmp_path):
    goal_state = chat_router._new_goal_state()
    policy = FileToolPolicy(workspace_base=tmp_path, scope="workspace")

    out = chat_router._execute_server_only_tool_result(
        name="set_goal",
        args_payload={"task": "legacy task", "success_criteria": "legacy criteria"},
        file_policy=policy,
        advisor_config=SimpleNamespace(enabled=True),
        advisor_state=chat_router._new_advisor_state(),
        goal_state=goal_state,
        system_prompt="",
        conversation_items=[],
        model_name="gpt-test",
        provider_name="openai",
        tools_enabled=True,
        control_level=3,
    )

    assert out["ok"] is True
    assert goal_state["goal"] == "legacy task\n\nlegacy criteria"
    assert goal_state["success_criteria"] == ""


def test_goal_evaluator_config_matches_selected_model(monkeypatch):
    seen = {}

    def fake_build_goal_evaluator_input_items(**kwargs):
        return [{"role": "user", "content": "evaluate"}]

    def fake_invoke_goal_evaluator(config, transcript):
        seen["model"] = config.advisor_model
        return SimpleNamespace(
            usage={"input_tokens": 0, "output_tokens": 0, "total_tokens": 0},
            cost_usd=0.0,
            reason="complete",
            complete=True,
        )

    monkeypatch.setattr(chat_router, "build_goal_evaluator_input_items", fake_build_goal_evaluator_input_items)
    monkeypatch.setattr(chat_router, "invoke_goal_evaluator", fake_invoke_goal_evaluator)

    state = chat_router._new_goal_state()
    state.update({"active": True, "goal": "reply done", "task": "reply done"})
    cfg = AdvisorConfig(enabled=True, advisor_model="advisor-default", reasoning_effort="low", auth_mode="byok", max_uses=1, timeout_sec=10)

    result = chat_router._evaluate_goal_candidate(
        goal_state=state,
        advisor_config=cfg,
        system_prompt="",
        conversation_items=[],
        candidate_final_response="done",
        model_name="selected-chat-model",
        provider_name="openai",
    )

    assert result.complete is True
    assert seen["model"] == "selected-chat-model"
