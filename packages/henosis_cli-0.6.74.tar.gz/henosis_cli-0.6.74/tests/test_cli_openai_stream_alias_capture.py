import asyncio
import importlib
import json


def _make_cli():
    cli_mod = importlib.import_module("cli")
    cli = cli_mod.ChatCLI(
        server="http://127.0.0.1:8000/api",
        model="gpt-5.4",
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
    )
    cli.auth_user = "user@example.com"
    # Force backend/non-Codex path for this regression test.
    cli.codex_route_all_openai_models = False
    cli.codex_access_token = None
    cli.codex_refresh_token = None
    cli.codex_expiry_date = None
    return cli


def test_openai_response_alias_events_are_captured(monkeypatch):
    cli_mod = importlib.import_module("cli")
    cli = _make_cli()

    class _FakeStreamResp:
        status_code = 200
        headers = {"content-type": "text/event-stream"}
        text = ""

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def raise_for_status(self):
            return None

        async def aiter_lines(self):
            payload_completed = {
                "response": {
                    "id": "resp_alias_1",
                    "model": "gpt-5.4",
                    "usage": {"input_tokens": 5, "output_tokens": 2, "total_tokens": 7},
                    "output": [
                        {
                            "type": "message",
                            "role": "assistant",
                            "content": [{"type": "output_text", "text": "Hello world"}],
                        }
                    ],
                }
            }
            lines = [
                "event: response.output_text.delta",
                'data: {"delta":"Hello "}',
                "",
                "event: response.output_text.delta",
                'data: {"delta":"world"}',
                "",
                "event: response.completed",
                "data: " + json.dumps(payload_completed),
                "",
            ]
            for line in lines:
                yield line

    class _FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def stream(self, method, url, json=None, headers=None, follow_redirects=None):
            return _FakeStreamResp()

    monkeypatch.setattr(cli_mod.httpx, "AsyncClient", _FakeAsyncClient)

    out = asyncio.run(cli._stream_once("say hello"))

    assert out == "Hello world"
    assert cli._openai_previous_response_id == "resp_alias_1"
    assert "resp_alias_1" in cli._openai_response_id_history
    assert isinstance(cli._openai_input_items, list) and cli._openai_input_items


def test_message_completed_with_openai_delta_items_is_captured(monkeypatch):
    cli_mod = importlib.import_module("cli")
    cli = _make_cli()

    class _FakeStreamResp:
        status_code = 200
        headers = {"content-type": "text/event-stream"}
        text = ""

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def raise_for_status(self):
            return None

        async def aiter_lines(self):
            payload_completed = {
                "model": "gpt-5.4",
                "usage": {"prompt_tokens": 5, "completion_tokens": 2, "total_tokens": 7},
                "openai_previous_response_id": "resp_msg_1",
                "openai_response_ids": ["resp_msg_1"],
                "openai_delta_items": [
                    {
                        "type": "message",
                        "role": "assistant",
                        "content": [{"type": "output_text", "text": "Recovered from delta items"}],
                    }
                ],
            }
            lines = [
                "event: message.completed",
                "data: " + json.dumps(payload_completed),
                "",
            ]
            for line in lines:
                yield line

    class _FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def stream(self, method, url, json=None, headers=None, follow_redirects=None):
            return _FakeStreamResp()

    monkeypatch.setattr(cli_mod.httpx, "AsyncClient", _FakeAsyncClient)

    out = asyncio.run(cli._stream_once("say hello"))

    assert out == "Recovered from delta items"
    assert cli._openai_previous_response_id == "resp_msg_1"
    assert "resp_msg_1" in cli._openai_response_id_history
    assert isinstance(cli._openai_input_items, list) and cli._openai_input_items


def test_xai_message_completed_with_response_content_alias_is_captured(monkeypatch):
    cli_mod = importlib.import_module("cli")
    cli = _make_cli()
    cli.model = "grok-4.3"

    class _FakeStreamResp:
        status_code = 200
        headers = {"content-type": "text/event-stream"}
        text = ""

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def raise_for_status(self):
            return None

        async def aiter_lines(self):
            payload_completed = {
                "model": "grok-4.3",
                "usage": {"prompt_tokens": 5, "completion_tokens": 2, "total_tokens": 7},
                "xai_previous_response_id": "resp_xai_alias_1",
                "xai_response_ids": ["resp_xai_alias_1"],
                "response": {
                    "id": "resp_xai_alias_1",
                    "content": "Recovered from xAI response.content",
                    "output": [
                        {"type": "message", "role": "assistant", "content": []}
                    ],
                },
            }
            lines = [
                "event: message.completed",
                "data: " + json.dumps(payload_completed),
                "",
            ]
            for line in lines:
                yield line

    class _FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def stream(self, method, url, json=None, headers=None, follow_redirects=None):
            return _FakeStreamResp()

    monkeypatch.setattr(cli_mod.httpx, "AsyncClient", _FakeAsyncClient)

    out = asyncio.run(cli._stream_once("say hello"))

    assert out == "Recovered from xAI response.content"
    assert cli._xai_previous_response_id == "resp_xai_alias_1"
    assert "resp_xai_alias_1" in cli._xai_response_id_history


def test_xai_completion_text_is_visibly_rendered_to_stdout(monkeypatch):
    cli_mod = importlib.import_module("cli")
    cli = _make_cli()
    cli.model = "grok-4.3"

    class _StdoutCapture:
        def __init__(self):
            self.parts = []

        def write(self, s):
            self.parts.append(str(s))
            return len(str(s))

        def flush(self):
            return None

        def getvalue(self):
            return "".join(self.parts)

    class _FakeStreamResp:
        status_code = 200
        headers = {"content-type": "text/event-stream"}
        text = ""

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def raise_for_status(self):
            return None

        async def aiter_lines(self):
            payload_completed = {
                "model": "grok-4.3",
                "usage": {"prompt_tokens": 5, "completion_tokens": 2, "total_tokens": 7},
                "response": {
                    "id": "resp_xai_visible_1",
                    "content": "Visible Grok answer",
                    "output": [{"type": "message", "role": "assistant", "content": []}],
                },
                "xai_previous_response_id": "resp_xai_visible_1",
                "xai_response_ids": ["resp_xai_visible_1"],
            }
            lines = [
                "event: message.completed",
                "data: " + json.dumps(payload_completed),
                "",
            ]
            for line in lines:
                yield line

    class _FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def stream(self, method, url, json=None, headers=None, follow_redirects=None):
            return _FakeStreamResp()

    stdout_capture = _StdoutCapture()
    monkeypatch.setattr(cli_mod.httpx, "AsyncClient", _FakeAsyncClient)
    monkeypatch.setattr(cli_mod.sys, "stdout", stdout_capture)

    out = asyncio.run(cli._stream_once("say hello"))

    visible = stdout_capture.getvalue()
    assert out == "Visible Grok answer"
    assert "grok-4.3: " in visible
    assert "Visible Grok answer" in visible


def test_openai_delta_web_search_items_are_sanitized(monkeypatch):
    cli_mod = importlib.import_module("cli")
    cli = _make_cli()

    class _FakeStreamResp:
        status_code = 200
        headers = {"content-type": "text/event-stream"}
        text = ""

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def raise_for_status(self):
            return None

        async def aiter_lines(self):
            payload_completed = {
                "model": "gpt-5.4",
                "usage": {"prompt_tokens": 8, "completion_tokens": 3, "total_tokens": 11},
                "openai_previous_response_id": "resp_msg_ws_1",
                "openai_response_ids": ["resp_msg_ws_1"],
                "openai_delta_items": [
                    {
                        "type": "web_search_call",
                        "id": "ws_123",
                        "status": "completed",
                        "action": {"type": "search", "query": "latest ai news"},
                    }
                ],
            }
            lines = [
                "event: message.completed",
                "data: " + json.dumps(payload_completed),
                "",
            ]
            for line in lines:
                yield line

    class _FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def stream(self, method, url, json=None, headers=None, follow_redirects=None):
            return _FakeStreamResp()

    monkeypatch.setattr(cli_mod.httpx, "AsyncClient", _FakeAsyncClient)

    asyncio.run(cli._stream_once("search something"))

    ws_items = [x for x in cli._openai_input_items if isinstance(x, dict) and x.get("type") == "web_search_call"]
    assert ws_items
    ws_item = ws_items[0]
    assert ws_item.get("id") == "ws_123"
    assert "action" not in ws_item
    assert "status" not in ws_item


def test_backend_stream_renders_thinking_empty_status_when_enabled(monkeypatch):
    cli_mod = importlib.import_module("cli")
    cli = _make_cli()
    cli.thinking_insight_enabled = True
    printed = []
    monkeypatch.setattr(
        cli.ui,
        "print",
        lambda *args, **kwargs: printed.append(str(args[0]) if args else ""),
    )

    class _FakeStreamResp:
        status_code = 200
        headers = {"content-type": "text/event-stream"}
        text = ""

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def raise_for_status(self):
            return None

        async def aiter_lines(self):
            payload_completed = {
                "model": "gpt-5.4",
                "usage": {"prompt_tokens": 5, "completion_tokens": 2, "total_tokens": 7},
                "text": "Hello world",
            }
            lines = [
                "event: message.completed",
                "data: " + json.dumps(payload_completed),
                "",
            ]
            for line in lines:
                yield line

    class _FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def stream(self, method, url, json=None, headers=None, follow_redirects=None):
            return _FakeStreamResp()

    monkeypatch.setattr(cli_mod.httpx, "AsyncClient", _FakeAsyncClient)

    out = asyncio.run(cli._stream_once("say hello"))

    assert out == "Hello world"
    assert any("Thinking (summary):" in line for line in printed)
    assert any("none emitted by provider for this turn" in line.lower() for line in printed)

