import os
import signal
import shutil
import subprocess
import tempfile
import threading
import time
from pathlib import Path
from types import SimpleNamespace

from henosis_cli_tools import tool_impl as ti


def _make_workspace() -> Path:
    root = Path(os.getcwd()) / "workspace" / ".tmp_tests"
    root.mkdir(parents=True, exist_ok=True)
    return Path(tempfile.mkdtemp(prefix="managed-proc-", dir=str(root)))


def test_spawn_process_status_output_wait_and_terminate():
    workspace = _make_workspace()
    try:
        pol = ti.FileToolPolicy(scope="workspace", workspace_base=workspace)
        script = workspace / "emit.py"
        script.write_text(
            "import time\nprint('start')\ntime.sleep(0.3)\nprint('end')\n",
            encoding="utf-8",
        )
        spawned = ti.spawn_command(
            cmd="python emit.py",
            policy=pol,
            cwd=".",
            allow_commands_csv="*",
        )
        assert spawned["ok"] is True
        process_id = spawned["data"]["process_id"]
        assert isinstance(process_id, str) and process_id.startswith("proc_")

        status_initial = ti.process_status(process_id)
        assert status_initial["ok"] is True
        assert status_initial["data"]["status"] in {"running", "exited"}

        for _ in range(20):
            time.sleep(0.05)
            output_mid = ti.process_output(process_id, after_seq=0, stream="stdout", max_chars=2000)
            if output_mid["data"]["chunks"]:
                break
        output_mid = ti.process_output(process_id, after_seq=0, stream="stdout", max_chars=2000)
        assert output_mid["ok"] is True
        assert output_mid["data"]["process_id"] == process_id
        assert isinstance(output_mid["data"]["chunks"], list)
        assert any("start" in str(chunk.get("text") or "") for chunk in output_mid["data"]["chunks"])
        assert all("timestamp" in chunk for chunk in output_mid["data"]["chunks"])
        if "end" in output_mid["data"]["text"]:
            last_seq = 0
        else:
            last_seq = int(output_mid["data"]["last_output_seq"] or 0)

        waited = ti.wait_process(process_id, timeout=2.0)
        assert waited["ok"] is True
        assert waited["data"]["status"] in {"running", "exited", "failed"}

        for _ in range(20):
            time.sleep(0.05)
            output_tail = ti.process_output(process_id, after_seq=last_seq, stream="stdout", max_chars=2000)
            if output_tail["data"]["text"]:
                break
        output_tail = ti.process_output(process_id, after_seq=last_seq, stream="stdout", max_chars=2000)
        assert output_tail["ok"] is True
        assert "end" in output_tail["data"]["text"]

        terminated = ti.terminate_process(process_id)
        assert terminated["ok"] is True
        assert terminated["data"]["status"] in {"exited", "failed", "killed"}
    finally:
        shutil.rmtree(workspace, ignore_errors=True)


def test_process_list_and_missing_process_errors():
    workspace = _make_workspace()
    try:
        pol = ti.FileToolPolicy(scope="workspace", workspace_base=workspace)
        script = workspace / "simple.py"
        script.write_text("print(123)\n", encoding="utf-8")
        spawned = ti.spawn_command(
            cmd="python simple.py",
            policy=pol,
            cwd=".",
            allow_commands_csv="*",
        )
        assert spawned["ok"] is True
        process_id = spawned["data"]["process_id"]

        listed = ti.process_list(limit=10)
        assert listed["ok"] is True
        assert any(item.get("process_id") == process_id for item in listed["data"]["items"])

        missing_status = ti.process_status("proc_missing")
        assert missing_status["ok"] is False
        assert "process not found" in str(missing_status["error"])

        missing_output = ti.process_output("proc_missing")
        assert missing_output["ok"] is False
        assert "process not found" in str(missing_output["error"])
    finally:
        shutil.rmtree(workspace, ignore_errors=True)


def test_wait_for_output_matches_buffered_output_with_line_context():
    workspace = _make_workspace()
    try:
        pol = ti.FileToolPolicy(scope="workspace", workspace_base=workspace)
        script = workspace / "emit_ready.py"
        script.write_text(
            "import sys\n"
            "print('booting', flush=True)\n"
            "print('SERVER READY', flush=True)\n"
            "print('listening on 8000', flush=True)\n"
            "sys.stdout.flush()\n"
            "",
            encoding="utf-8",
        )
        spawned = ti.spawn_command(
            cmd="python emit_ready.py",
            policy=pol,
            cwd=".",
            allow_commands_csv="*",
        )
        assert spawned["ok"] is True
        process_id = spawned["data"]["process_id"]

        time.sleep(0.2)
        matched = ti.wait_for_output(
            process_id,
            "server ready",
            ignore_case=True,
            timeout=1.0,
            context_lines_before=1,
            context_lines_after=1,
            max_chars=4000,
        )
        assert matched["ok"] is True
        data = matched["data"]
        assert data["matched"] is True
        assert data["timed_out"] is False
        assert "booting" in str(data.get("text") or "")
        assert "SERVER READY" in str(data.get("text") or "")
        assert "listening on 8000" in str(data.get("text") or "")
        assert int(data.get("context_line_count") or 0) >= 3
        assert isinstance(data.get("match"), dict)
        assert "SERVER READY" in str(data["match"].get("text") or "")
    finally:
        shutil.rmtree(workspace, ignore_errors=True)


def test_wait_for_output_waits_for_future_match():
    workspace = _make_workspace()
    try:
        pol = ti.FileToolPolicy(scope="workspace", workspace_base=workspace)
        script = workspace / "emit_later.py"
        script.write_text(
            "import time\n"
            "print('booting', flush=True)\n"
            "time.sleep(0.3)\n"
            "print('ready on port 9000', flush=True)\n"
            "time.sleep(0.2)\n",
            encoding="utf-8",
        )
        spawned = ti.spawn_command(
            cmd="python emit_later.py",
            policy=pol,
            cwd=".",
            allow_commands_csv="*",
        )
        assert spawned["ok"] is True
        process_id = spawned["data"]["process_id"]

        matched = ti.wait_for_output(
            process_id,
            r"ready on port \d+",
            is_regex=True,
            timeout=2.0,
            context_lines_before=1,
            context_lines_after=0,
            max_chars=4000,
        )
        assert matched["ok"] is True
        data = matched["data"]
        assert data["matched"] is True
        assert data["timed_out"] is False
        assert "ready on port 9000" in str(data.get("text") or "")
        assert "booting" in str(data.get("text") or "")
    finally:
        shutil.rmtree(workspace, ignore_errors=True)


def test_wait_for_output_returns_no_match_when_process_exits():
    workspace = _make_workspace()
    try:
        pol = ti.FileToolPolicy(scope="workspace", workspace_base=workspace)
        script = workspace / "emit_once.py"
        script.write_text(
            "print('finished quickly', flush=True)\n",
            encoding="utf-8",
        )
        spawned = ti.spawn_command(
            cmd="python emit_once.py",
            policy=pol,
            cwd=".",
            allow_commands_csv="*",
        )
        assert spawned["ok"] is True
        process_id = spawned["data"]["process_id"]

        result = ti.wait_for_output(
            process_id,
            "never appears",
            timeout=1.0,
            context_lines_before=1,
            context_lines_after=1,
            max_chars=4000,
        )
        assert result["ok"] is True
        data = result["data"]
        assert data["matched"] is False
        assert data["timed_out"] is False
        assert data["status"] in {"exited", "failed"}
        assert "finished quickly" in str(data.get("text") or "")
    finally:
        shutil.rmtree(workspace, ignore_errors=True)


def test_wait_for_output_times_out_when_no_match_yet():
    workspace = _make_workspace()
    try:
        pol = ti.FileToolPolicy(scope="workspace", workspace_base=workspace)
        script = workspace / "sleepy.py"
        script.write_text(
            "import time\n"
            "print('booting', flush=True)\n"
            "time.sleep(1.0)\n",
            encoding="utf-8",
        )
        spawned = ti.spawn_command(
            cmd="python sleepy.py",
            policy=pol,
            cwd=".",
            allow_commands_csv="*",
        )
        assert spawned["ok"] is True
        process_id = spawned["data"]["process_id"]

        result = ti.wait_for_output(
            process_id,
            "not there",
            timeout=0.1,
            context_lines_before=1,
            context_lines_after=0,
            max_chars=4000,
        )
        assert result["ok"] is True
        data = result["data"]
        assert data["matched"] is False
        assert data["timed_out"] is True
        assert data["status"] in {"running", "exited", "failed"}
        terminated = ti.terminate_process(process_id)
        assert terminated["ok"] is True
    finally:
        shutil.rmtree(workspace, ignore_errors=True)


def test_spawn_terminal_returns_clear_error_when_unsupported():
    workspace = _make_workspace()
    try:
        pol = ti.FileToolPolicy(scope="workspace", workspace_base=workspace)
        spawned = ti.spawn_terminal(
            cmd="python -c \"print('hi')\"",
            policy=pol,
            cwd=".",
            allow_commands_csv="*",
            cols=100,
            rows=30,
        )
        if os.name == "nt":
            try:
                import winpty  # type: ignore  # noqa: F401
                have_winpty = True
            except Exception:
                have_winpty = False
            if not have_winpty:
                assert spawned["ok"] is False
                assert ("pywinpty" in str(spawned["error"]).lower()) or ("conpty" in str(spawned["error"]).lower())
                return
        assert spawned["ok"] is True
        terminal_id = spawned["data"]["terminal_id"]
        snap = ti.terminal_snapshot(terminal_id, after_seq=0, stream="all", max_chars=2000)
        assert snap["ok"] is True
        assert snap["data"]["terminal_id"] == terminal_id
        closed = ti.terminal_close(terminal_id)
        assert closed["ok"] is True
    finally:
        shutil.rmtree(workspace, ignore_errors=True)


def test_terminal_keys_to_text_uses_carriage_return_for_windows_enter(monkeypatch):
    monkeypatch.setattr(ti.os, "name", "nt", raising=False)

    assert ti._terminal_keys_to_text(["ENTER"]) == "\r"
    assert ti._terminal_keys_to_text(["RETURN"]) == "\r"


def test_terminal_input_append_newline_uses_windows_carriage_return(monkeypatch):
    monkeypatch.setattr(ti.os, "name", "nt", raising=False)

    writes = []

    class _FakeProc:
        def write(self, payload: str) -> None:
            writes.append(payload)

    record = SimpleNamespace(
        terminal_id="term_test",
        output_lock=threading.Lock(),
        status="running",
        proc=_FakeProc(),
    )

    monkeypatch.setattr(ti, "_managed_terminal_get", lambda terminal_id: record)

    result = ti.terminal_input("term_test", text="echo HI", append_newline=True)

    assert result["ok"] is True
    assert writes == ["echo HI\r"]


def test_terminal_reader_windows_suppresses_expected_close_abort(monkeypatch):
    monkeypatch.setattr(ti.os, "name", "nt", raising=False)

    class _FakeProc:
        def read(self):
            raise ConnectionAbortedError(10053, "An established connection was aborted by the software in your host machine")

    record = ti.ManagedTerminalRecord(
        terminal_id="term_test",
        cmd="cmd /Q",
        argv=["cmd", "/Q"],
        parse_method="windows.CommandLineToArgvW",
        argv_sanitized=False,
        cwd=".",
        pid=1,
        started_at="now",
        status="running",
        cols=80,
        rows=24,
        proc=_FakeProc(),
        close_requested=True,
    )

    ti._managed_terminal_reader_windows(record, record.proc)

    assert record.error is None


def test_terminal_monitor_marks_close_requested_windows_session_as_killed(monkeypatch):
    monkeypatch.setattr(ti.os, "name", "nt", raising=False)
    monkeypatch.setattr(ti, "_managed_terminal_wait", lambda proc, timeout=None: 2)

    record = ti.ManagedTerminalRecord(
        terminal_id="term_test",
        cmd="cmd /Q",
        argv=["cmd", "/Q"],
        parse_method="windows.CommandLineToArgvW",
        argv_sanitized=False,
        cwd=".",
        pid=1,
        started_at="now",
        status="running",
        cols=80,
        rows=24,
        proc=object(),
        close_requested=True,
        error="terminal reader error: ConnectionAbortedError: [WinError 10053] An established connection was aborted by the software in your host machine",
    )

    ti._managed_terminal_monitor(record)

    assert record.status == "killed"
    assert record.exit_code == 2
    assert record.error is None


def test_terminal_close_windows_reports_killed_for_expected_forced_close(monkeypatch):
    monkeypatch.setattr(ti.os, "name", "nt", raising=False)

    class _FakeProc:
        def __init__(self):
            self.closed = False

        def isalive(self):
            return not self.closed

        def get_exitstatus(self):
            return 2 if self.closed else None

        def close(self, *_args, **_kwargs):
            self.closed = True

    record = ti.ManagedTerminalRecord(
        terminal_id="term_test",
        cmd="cmd /Q",
        argv=["cmd", "/Q"],
        parse_method="windows.CommandLineToArgvW",
        argv_sanitized=False,
        cwd=".",
        pid=1,
        started_at="now",
        status="running",
        cols=80,
        rows=24,
        proc=_FakeProc(),
        error="terminal reader error: ConnectionAbortedError: [WinError 10053] An established connection was aborted by the software in your host machine",
    )

    monkeypatch.setattr(ti, "_managed_terminal_get", lambda terminal_id: record)

    closed = ti.terminal_close("term_test")

    assert closed["ok"] is True
    assert closed["data"]["status"] == "killed"
    assert closed["data"]["exit_code"] == 2
    assert closed["data"]["error"] is None
    assert closed["data"]["terminated"] is True
    assert record.close_requested is True


def test_terminal_round_trip_input_snapshot_and_resize_posix_only():
    if os.name == "nt":
        return
    workspace = _make_workspace()
    try:
        pol = ti.FileToolPolicy(scope="workspace", workspace_base=workspace)
        spawned = ti.spawn_terminal(
            cmd="python -i",
            policy=pol,
            cwd=".",
            allow_commands_csv="*",
            cols=80,
            rows=24,
        )
        assert spawned["ok"] is True
        terminal_id = spawned["data"]["terminal_id"]

        got_prompt = False
        last_seq = 0
        for _ in range(30):
            time.sleep(0.1)
            snap = ti.terminal_snapshot(terminal_id, after_seq=last_seq, stream="all", max_chars=4000)
            assert snap["ok"] is True
            last_seq = int(snap["data"]["last_output_seq"] or last_seq)
            screen_text = str(snap["data"].get("screen_text") or "")
            if ">>>" in screen_text:
                got_prompt = True
                break
        assert got_prompt is True

        sent = ti.terminal_input(terminal_id, text="print('hello from terminal')", append_newline=True)
        assert sent["ok"] is True

        saw_output = False
        for _ in range(30):
            time.sleep(0.1)
            snap = ti.terminal_snapshot(terminal_id, after_seq=0, stream="all", max_chars=8000)
            assert snap["ok"] is True
            if "hello from terminal" in str(snap["data"].get("screen_text") or ""):
                saw_output = True
                break
        assert saw_output is True

        resized = ti.terminal_resize(terminal_id, cols=100, rows=20)
        assert resized["ok"] is True
        assert int(resized["data"]["cols"] or 0) == 100
        assert int(resized["data"]["rows"] or 0) == 20

        interrupted = ti.terminal_input(terminal_id, keys=["CTRL_C"])
        assert interrupted["ok"] is True

        closed = ti.terminal_close(terminal_id)
        assert closed["ok"] is True
        assert closed["data"]["status"] in {"exited", "failed", "killed"}
    finally:
        shutil.rmtree(workspace, ignore_errors=True)


def test_run_command_timeout_terminates_child_process_tree():
    workspace = _make_workspace()
    try:
        pol = ti.FileToolPolicy(scope="workspace", workspace_base=workspace)
        pid_file = workspace / "child_pid.txt"
        script = workspace / "spawn_child.py"
        script.write_text(
            "import os\n"
            "import subprocess\n"
            "import sys\n"
            "import time\n"
            f"pid_file = r'{str(pid_file)}'\n"
            "child_code = \"import time; time.sleep(60)\"\n"
            "kwargs = {}\n"
            "if os.name == 'nt':\n"
            "    kwargs['creationflags'] = getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0)\n"
            "else:\n"
            "    kwargs['start_new_session'] = True\n"
            "child = subprocess.Popen([sys.executable, '-c', child_code], stdout=sys.stdout, stderr=sys.stderr, **kwargs)\n"
            "with open(pid_file, 'w', encoding='utf-8') as f:\n"
            "    f.write(str(child.pid))\n"
            "    f.flush()\n"
            "time.sleep(60)\n",
            encoding="utf-8",
        )

        started = time.time()
        result = ti.run_command(
            cmd="python spawn_child.py",
            policy=pol,
            cwd=".",
            timeout=1,
            allow_commands_csv="*",
        )
        elapsed = time.time() - started

        assert result["ok"] is True
        assert result["data"]["timed_out"] is True
        assert elapsed < 10.0

        child_pid = None
        deadline = time.time() + 3.0
        while time.time() < deadline and child_pid is None:
            if pid_file.exists():
                try:
                    child_pid = int(pid_file.read_text(encoding="utf-8").strip())
                except Exception:
                    child_pid = None
            if child_pid is None:
                time.sleep(0.05)

        assert isinstance(child_pid, int) and child_pid > 0

        def _pid_alive(pid: int) -> bool:
            if os.name == "nt":
                probe = subprocess.run(
                    ["tasklist", "/FI", f"PID eq {pid}"],
                    capture_output=True,
                    text=True,
                    timeout=10.0,
                    check=False,
                )
                return str(pid) in (probe.stdout or "")
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                return False
            except PermissionError:
                return True
            return True

        grace_deadline = time.time() + 5.0
        while time.time() < grace_deadline and _pid_alive(child_pid):
            time.sleep(0.1)

        assert _pid_alive(child_pid) is False
    finally:
        shutil.rmtree(workspace, ignore_errors=True)
