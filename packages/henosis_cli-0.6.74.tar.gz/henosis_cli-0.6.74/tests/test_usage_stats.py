from datetime import datetime, timedelta, timezone

from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.routers import usage as usage_router


def _build_stats_app(with_logs: bool = False):
    engine = create_engine(
        "sqlite://",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
    with engine.begin() as conn:
        conn.execute(
            text(
                """
                CREATE TABLE model_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT,
                    model_id TEXT,
                    tokens_input INTEGER,
                    tokens_output INTEGER,
                    cost REAL,
                    status TEXT,
                    billing_source TEXT,
                    cached_input_tokens INTEGER,
                    non_cached_input_tokens INTEGER,
                    advisor_cost_usd REAL,
                    advisor_status TEXT,
                    advisor_billing_source TEXT,
                    advisor_input_tokens INTEGER,
                    advisor_output_tokens INTEGER,
                    advisor_total_tokens INTEGER,
                    requested_service_tier TEXT,
                    effective_service_tier TEXT,
                    service_tier_downgraded INTEGER,
                    session_id TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
        )
        conn.execute(
            text(
                """
                CREATE TABLE users (
                    username TEXT PRIMARY KEY,
                    credits REAL,
                    subscription_tier TEXT,
                    subscription_status TEXT
                )
                """
            )
        )
        conn.execute(
            text("INSERT INTO users (username, credits, subscription_tier, subscription_status) VALUES ('henosis', 10.0, 'free', 'none')")
        )
        if with_logs:
            now = datetime.now(timezone.utc)
            current_year = now.year
            today = now.date()
            rows = [
                {
                    "created_at": datetime.combine(today - timedelta(days=2), datetime.min.time(), tzinfo=timezone.utc).isoformat(),
                    "model_id": "gpt-5.4",
                    "tokens_input": 100,
                    "tokens_output": 50,
                    "cached_input_tokens": 25,
                    "cost": 0.1,
                    "session_id": "sess-a",
                },
                {
                    "created_at": datetime.combine(today - timedelta(days=1), datetime.min.time(), tzinfo=timezone.utc).replace(hour=13).isoformat(),
                    "model_id": "gpt-5.4",
                    "tokens_input": 120,
                    "tokens_output": 60,
                    "cached_input_tokens": 0,
                    "cost": 0.2,
                    "session_id": "sess-b",
                },
                {
                    "created_at": datetime.combine(today, datetime.min.time(), tzinfo=timezone.utc).replace(hour=13).isoformat(),
                    "model_id": "kimi-k2.6",
                    "tokens_input": 80,
                    "tokens_output": 20,
                    "cached_input_tokens": 40,
                    "cost": 0.05,
                    "session_id": "sess-c",
                },
                {
                    "created_at": datetime(current_year, 1, 5, 9, 0, tzinfo=timezone.utc).isoformat(),
                    "model_id": "kimi-k2.6",
                    "tokens_input": 40,
                    "tokens_output": 10,
                    "cached_input_tokens": 0,
                    "cost": 0.02,
                    "session_id": "sess-year",
                },
            ]
            for row in rows:
                conn.execute(
                    text(
                        """
                        INSERT INTO model_logs (
                            user_id, model_id, tokens_input, tokens_output, cost, status,
                            billing_source, cached_input_tokens, non_cached_input_tokens,
                            advisor_input_tokens, advisor_output_tokens, advisor_total_tokens,
                            session_id, created_at
                        ) VALUES (
                            'henosis', :model_id, :tokens_input, :tokens_output, :cost, 'success',
                            'backend_henosis', :cached_input_tokens, (:tokens_input - :cached_input_tokens),
                            0, 0, 0,
                            :session_id, :created_at
                        )
                        """
                    ),
                    row,
                )

    app = FastAPI()
    app.include_router(usage_router.router)

    def override_db():
        db = SessionLocal()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[usage_router.get_db] = override_db
    app.dependency_overrides[usage_router.get_current_user] = lambda: "henosis"
    return app


def test_stats_endpoints_return_empty_valid_payloads():
    app = _build_stats_app(with_logs=False)
    client = TestClient(app)

    summary = client.get("/api/stats/summary")
    assert summary.status_code == 200, summary.text
    body = summary.json()
    assert body["ok"] is True
    assert body["summary"]["total_tokens"] == 0
    assert body["summary"]["current_streak_days"] == 0

    calendar = client.get("/api/stats/calendar")
    assert calendar.status_code == 200, calendar.text
    cal_body = calendar.json()
    assert cal_body["ok"] is True
    assert len(cal_body["calendar_days"]) >= 365

    daily = client.get("/api/stats/tokens_daily?days=30")
    assert daily.status_code == 200, daily.text
    daily_body = daily.json()
    assert daily_body["ok"] is True
    assert len(daily_body["rolling_days"]) == 30

    breakdown = client.get("/api/stats/models_breakdown?days=30&limit=4")
    assert breakdown.status_code == 200, breakdown.text
    breakdown_body = breakdown.json()
    assert breakdown_body["ok"] is True
    assert breakdown_body["top_models"] == []


def test_stats_bundle_computes_streaks_sessions_and_fills_rolling_days():
    app = _build_stats_app(with_logs=True)
    client = TestClient(app)

    response = client.get("/api/stats/cli?days=30")
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["ok"] is True
    assert body["summary"]["sessions"] == 4
    assert body["summary"]["sessions_exact"] is True
    assert body["summary"]["current_streak_days"] == 3
    assert body["summary"]["longest_streak_days"] >= 3
    assert body["summary"]["favorite_model"] == "gpt-5.4"
    assert body["summary"]["peak_work_hour"] == 13
    assert body["summary"]["cached_input_tokens"] == 65
    assert body["summary"]["non_cached_input_tokens"] == 275
    assert round(float(body["summary"]["cached_input_percent"]), 2) == 19.12
    assert len(body["rolling_days"]) == 30
    assert any(day["total_tokens"] == 0 for day in body["rolling_days"])

    top_models = body["top4_models"]
    assert top_models[0]["model"] == "gpt-5.4"
    assert top_models[0]["total_tokens"] == 330
    assert top_models[0]["cached_input_tokens"] == 25


def test_stats_detail_endpoints_match_bundle_shapes():
    app = _build_stats_app(with_logs=True)
    client = TestClient(app)

    summary = client.get("/api/stats/summary")
    assert summary.status_code == 200, summary.text
    assert summary.json()["summary"]["favorite_model"] == "gpt-5.4"

    daily = client.get("/api/stats/tokens_daily?days=30")
    assert daily.status_code == 200, daily.text
    daily_body = daily.json()
    assert daily_body["window_days"] == 30
    assert len(daily_body["rolling_days"]) == 30

    breakdown = client.get("/api/stats/models_breakdown?days=30&limit=1")
    assert breakdown.status_code == 200, breakdown.text
    models = breakdown.json()["top_models"]
    assert len(models) == 1
    assert models[0]["model"] == "gpt-5.4"

    full_year = client.get("/api/stats/tokens_daily?days=365")
    assert full_year.status_code == 200, full_year.text
    full_year_body = full_year.json()
    assert full_year_body["window_days"] == 365
    assert len(full_year_body["rolling_days"]) == 365
