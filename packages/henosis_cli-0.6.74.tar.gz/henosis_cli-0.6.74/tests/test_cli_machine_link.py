import asyncio
import importlib
import json
from pathlib import Path


def _make_cli():
    cli_mod = importlib.import_module("cli")
    cli = cli_mod.ChatCLI(
        server="http://127.0.0.1:8000/api",
        model="gpt-5.4",
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
        machine_link_mode=True,
    )
    cli.auth_user = "user@example.com"
    cli.device_id = "machine-a"
    cli.device_name = "Windows PC"
    return cli


def test_spawn_remote_agent_process_starts_child_cli(monkeypatch, tmp_path):
    cli = _make_cli()
    cli.log_dir = tmp_path / "logs"
    spawn_dir = tmp_path / "project"
    spawn_dir.mkdir()

    popen_calls = []

    class _Proc:
        pid = 12345

    def fake_popen(cmd, **kwargs):
        popen_calls.append((cmd, kwargs))
        return _Proc()

    monkeypatch.setattr("cli.subprocess.Popen", fake_popen)
    monkeypatch.setattr(cli, "_resolve_spawn_cli_base_command", lambda: ["python", "cli.py"])

    result = cli._spawn_remote_agent_process(
        cwd=str(spawn_dir),
        terminal_id="term-spawned",
        model="gpt-5.4",
    )

    assert result["ok"] is True
    assert result["pid"] == 12345
    assert result["terminal_id"] == "term-spawned"
    assert len(popen_calls) == 1
    cmd, kwargs = popen_calls[0]
    assert cmd == [
        "python",
        "cli.py",
        "--server",
        "http://127.0.0.1:8000/api",
        "--agent-mode",
        "--terminal-id",
        "term-spawned",
        "--workspace-dir",
        str(spawn_dir),
        "--agent-scope",
        str(spawn_dir),
        "--model",
        "gpt-5.4",
    ]
    assert kwargs["cwd"] == str(spawn_dir)


def test_list_machine_link_directories_returns_parent_and_child_dirs(monkeypatch, tmp_path):
    cli = _make_cli()
    root = tmp_path / "repo"
    child = root / "src"
    root.mkdir()
    child.mkdir()
    monkeypatch.chdir(root)
    cli.local_workspace_dir = str(root)
    cli.host_base = str(root)

    listing = cli._list_machine_link_directories(str(root))

    assert listing["ok"] is True
    assert listing["current_path"] == str(root.resolve())
    entries = listing["entries"]
    assert entries[0]["kind"] == "parent"
    assert any(entry["name"] == "src" and entry["path"] == str(child.resolve()) for entry in entries)


def test_machine_link_info_uses_current_device_identity(tmp_path):
    cli = _make_cli()
    cli.local_workspace_dir = str(tmp_path)
    cli.host_base = None
    info = cli._build_machine_link_info()

    assert info["machine_id"] == "machine-a"
    assert info["device_name"] == "Windows PC"
    assert info["default_start_dir"] == str(Path(tmp_path).resolve())
    assert info["auth_user"] == "user@example.com"


def test_list_machine_link_managed_sessions_updates_exited_process_state():
    cli = _make_cli()

    class _Proc:
        pid = 2468

        def poll(self):
            return 0

    cli._machine_link_managed_sessions["term-spawned"] = {
        "terminal_id": "term-spawned",
        "pid": 2468,
        "cwd": "C:/repo/project",
        "model": "gpt-5.4",
        "status": "running",
        "started_at": "2026-03-30T00:00:00Z",
        "stopped_at": None,
        "exit_code": None,
        "restart_count": 0,
        "last_error": None,
        "command": ["python", "cli.py"],
        "_process": _Proc(),
    }

    result = cli._list_machine_link_managed_sessions()

    assert result["ok"] is True
    assert result["sessions"][0]["terminal_id"] == "term-spawned"
    assert result["sessions"][0]["status"] == "exited"
    assert result["sessions"][0]["exit_code"] == 0


def test_stop_machine_link_managed_session_terminates_registered_child():
    cli = _make_cli()

    class _Proc:
        def __init__(self):
            self.pid = 1357
            self.returncode = None

        def poll(self):
            return self.returncode

        def terminate(self):
            self.returncode = 0

        def wait(self, timeout=None):
            return self.returncode

        def kill(self):
            self.returncode = -9

    proc = _Proc()
    cli._machine_link_managed_sessions["term-spawned"] = {
        "terminal_id": "term-spawned",
        "pid": proc.pid,
        "cwd": "C:/repo/project",
        "model": "gpt-5.4",
        "status": "running",
        "started_at": "2026-03-30T00:00:00Z",
        "stopped_at": None,
        "exit_code": None,
        "restart_count": 0,
        "last_error": None,
        "command": ["python", "cli.py"],
        "_process": proc,
    }

    result = cli._stop_machine_link_managed_session("term-spawned")

    assert result["ok"] is True
    assert result["terminal_id"] == "term-spawned"
    assert result["session"]["status"] == "stopped"
    assert result["session"]["exit_code"] == 0


def test_restart_machine_link_managed_session_stops_then_respawns(monkeypatch):
    cli = _make_cli()

    class _Proc:
        def __init__(self, pid):
            self.pid = pid
            self.returncode = None

        def poll(self):
            return self.returncode

        def terminate(self):
            self.returncode = 0

        def wait(self, timeout=None):
            return self.returncode

        def kill(self):
            self.returncode = -9

    old_proc = _Proc(1111)
    new_proc = _Proc(2222)
    cli._machine_link_managed_sessions["term-spawned"] = {
        "terminal_id": "term-spawned",
        "pid": old_proc.pid,
        "cwd": "C:/repo/project",
        "model": "gpt-5.4",
        "status": "running",
        "started_at": "2026-03-30T00:00:00Z",
        "stopped_at": None,
        "exit_code": None,
        "restart_count": 0,
        "last_error": None,
        "command": ["python", "cli.py"],
        "_process": old_proc,
    }

    spawn_calls = []

    def fake_spawn_remote_agent_process(*, cwd, terminal_id, model=None):
        spawn_calls.append({"cwd": cwd, "terminal_id": terminal_id, "model": model})
        cli._machine_link_managed_sessions[terminal_id] = {
            "terminal_id": terminal_id,
            "pid": new_proc.pid,
            "cwd": cwd,
            "model": model,
            "status": "running",
            "started_at": "2026-03-30T00:05:00Z",
            "stopped_at": None,
            "exit_code": None,
            "restart_count": 1,
            "last_error": None,
            "command": ["python", "cli.py"],
            "_process": new_proc,
        }
        return {
            "ok": True,
            "terminal_id": terminal_id,
            "pid": new_proc.pid,
            "cwd": cwd,
            "session": cli._machine_link_session_view(cli._machine_link_managed_sessions[terminal_id]),
        }

    monkeypatch.setattr(cli, "_spawn_remote_agent_process", fake_spawn_remote_agent_process)

    result = cli._restart_machine_link_managed_session("term-spawned")

    assert spawn_calls == [{"cwd": "C:/repo/project", "terminal_id": "term-spawned", "model": "gpt-5.4"}]
    assert result["ok"] is True
    assert result["terminal_id"] == "term-spawned"
    assert result["pid"] == 2222
    assert result["session"]["status"] == "running"


def test_remove_machine_link_managed_session_drops_stale_entry(monkeypatch):
    cli = _make_cli()
    saved = []
    monkeypatch.setattr(cli, "_save_auth_state_to_disk", lambda: saved.append(True))
    cli._machine_link_managed_sessions["term-stale"] = {
        "terminal_id": "term-stale",
        "pid": 0,
        "cwd": "C:/repo/project",
        "model": "gpt-5.4",
        "status": "stale",
        "started_at": "2026-03-30T00:00:00Z",
        "stopped_at": "2026-03-30T00:10:00Z",
        "exit_code": None,
        "restart_count": 0,
        "last_error": "PID no longer matches",
        "command": ["python", "cli.py"],
        "_process": None,
    }

    result = cli._machine_link_remove_managed_session("term-stale")

    assert result["ok"] is True
    assert result["removed"] is True
    assert "term-stale" not in cli._machine_link_managed_sessions
    assert saved == [True]


def test_remove_all_stale_sessions_removes_only_stale_entries(monkeypatch):
    cli = _make_cli()
    saved = []
    monkeypatch.setattr(cli, "_save_auth_state_to_disk", lambda: saved.append(True))
    cli._machine_link_managed_sessions["term-stale"] = {
        "terminal_id": "term-stale",
        "pid": 0,
        "cwd": "C:/repo/project",
        "model": "gpt-5.4",
        "status": "stale",
        "started_at": "2026-03-30T00:00:00Z",
        "stopped_at": "2026-03-30T00:10:00Z",
        "exit_code": None,
        "restart_count": 0,
        "last_error": "PID no longer matches",
        "command": ["python", "cli.py"],
        "_process": None,
    }
    cli._machine_link_managed_sessions["term-running"] = {
        "terminal_id": "term-running",
        "pid": 9999,
        "cwd": "C:/repo/project",
        "model": "gpt-5.4",
        "status": "running",
        "started_at": "2026-03-30T00:00:00Z",
        "stopped_at": None,
        "exit_code": None,
        "restart_count": 0,
        "last_error": None,
        "command": ["python", "cli.py"],
        "_process": None,
    }
    monkeypatch.setattr(cli, "_machine_link_pid_exists", lambda pid: pid == 9999)
    monkeypatch.setattr(cli, "_machine_link_pid_matches_session", lambda pid, session: True)

    result = cli._machine_link_remove_all_stale_sessions()

    assert result["ok"] is True
    assert result["removed_count"] == 1
    assert result["removed_terminal_ids"] == ["term-stale"]
    assert "term-stale" not in cli._machine_link_managed_sessions
    assert "term-running" in cli._machine_link_managed_sessions
    assert saved == [True]


def test_read_session_output_returns_tail_of_log_file(tmp_path):
    cli = _make_cli()
    cli.log_dir = tmp_path
    cli._machine_link_managed_sessions["term-spawned"] = {
        "terminal_id": "term-spawned",
        "pid": 0,
        "cwd": "C:/repo/project",
        "model": "gpt-5.4",
        "status": "stopped",
        "started_at": "2026-03-30T00:00:00Z",
        "stopped_at": "2026-03-30T00:10:00Z",
        "exit_code": 0,
        "restart_count": 1,
        "last_error": None,
        "command": ["python", "cli.py"],
        "_process": None,
    }
    log_path = cli._machine_link_log_path("term-spawned")
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_path.write_text(("alpha\n" * 300) + "charlie\n", encoding="utf-8")

    result = cli._machine_link_read_session_output("term-spawned", max_chars=1000)

    assert result["ok"] is True
    assert result["terminal_id"] == "term-spawned"
    assert result["truncated"] is True
    assert result["log_path"] == str(log_path)
    assert result["output"].endswith("charlie\n")


def test_auth_state_persists_and_restores_machine_link_sessions(tmp_path):
    cli = _make_cli()
    cli.auth_state_file = tmp_path / "auth-state.json"
    cli._machine_link_managed_sessions["term-spawned"] = {
        "terminal_id": "term-spawned",
        "pid": 4242,
        "cwd": "C:/repo/project",
        "model": "gpt-5.4",
        "status": "stopped",
        "started_at": "2026-03-30T00:00:00Z",
        "stopped_at": "2026-03-30T00:10:00Z",
        "exit_code": 0,
        "restart_count": 1,
        "last_error": None,
        "command": ["python", "cli.py"],
        "_process": None,
    }

    cli._save_auth_state_to_disk()
    payload = json.loads(cli.auth_state_file.read_text(encoding="utf-8"))

    assert payload["machine_link_managed_sessions"] == [
        {
            "terminal_id": "term-spawned",
            "pid": 4242,
            "cwd": "C:/repo/project",
            "model": "gpt-5.4",
            "status": "stopped",
            "started_at": "2026-03-30T00:00:00Z",
            "stopped_at": "2026-03-30T00:10:00Z",
            "exit_code": 0,
            "restart_count": 1,
            "last_error": None,
            "command": ["python", "cli.py"],
        }
    ]

    restored_cli = _make_cli()
    restored_cli.auth_state_file = cli.auth_state_file

    assert restored_cli._load_auth_state_from_disk() is False
    assert restored_cli._machine_link_managed_sessions["term-spawned"]["terminal_id"] == "term-spawned"
    assert restored_cli._machine_link_managed_sessions["term-spawned"]["status"] == "stopped"
    assert restored_cli._machine_link_managed_sessions["term-spawned"]["pid"] == 4242


def test_remote_control_machine_link_settings_round_trip():
    cli = _make_cli()
    cli.agent_mode = True
    cli.machine_link_mode = True
    cli.machine_spawn_enabled = False
    cli.agent_host = "0.0.0.0"
    cli.agent_port = 8765
    cli.agent_allow_remote = True

    settings = cli._collect_settings_dict()

    assert settings["agent_mode_enabled"] is True
    assert settings["machine_link_enabled"] is True
    assert settings["machine_spawn_enabled"] is False
    assert settings["agent_host"] == "0.0.0.0"
    assert settings["agent_port"] == 8765
    assert settings["agent_allow_remote"] is True

    restored = _make_cli()
    restored.agent_mode = False
    restored.machine_link_mode = False
    restored.machine_spawn_enabled = True
    restored.agent_host = "127.0.0.1"
    restored.agent_port = 8700
    restored.agent_allow_remote = False

    restored._apply_settings_dict(settings)

    assert restored.agent_mode is True
    assert restored.machine_link_mode is True
    assert restored.machine_spawn_enabled is False
    assert restored.agent_host == "0.0.0.0"
    assert restored.agent_port == 8765
    assert restored.agent_allow_remote is True


def test_machine_link_info_advertises_link_and_spawn_settings(tmp_path):
    cli = _make_cli()
    cli.local_workspace_dir = str(tmp_path)
    cli.machine_link_mode = True
    cli.machine_spawn_enabled = False

    info = cli._build_machine_link_info()

    assert info["machine_link_enabled"] is True
    assert info["machine_spawn_enabled"] is False


def test_machine_spawn_request_rejects_when_spawn_setting_disabled(monkeypatch):
    cli = _make_cli()
    cli.machine_spawn_enabled = False
    sent = []

    def fail_spawn(**kwargs):
        raise AssertionError("spawn should not be called when machine_spawn_enabled is false")

    async def fake_send(message_type, data):
        sent.append((message_type, data))
        return True

    monkeypatch.setattr(cli, "_spawn_remote_agent_process", fail_spawn)
    monkeypatch.setattr(cli, "_machine_link_send", fake_send)

    asyncio.run(
        cli._machine_link_handle_message(
            {
                "type": "machine.spawn.request",
                "data": {"request_id": "req-1", "terminal_id": "term-a", "cwd": "C:/repo"},
            }
        )
    )

    assert sent == [
        (
            "machine.spawn.response",
            {
                "ok": False,
                "error": "Website-spawned henosis-cli sessions are disabled in this CLI's settings. Enable /machinespawn on to allow spawning.",
                "request_id": "req-1",
            },
        )
    ]


def test_remote_control_and_machine_link_slash_commands_toggle_runtime_services(monkeypatch):
    cli = _make_cli()
    cli.agent_mode = False
    cli.machine_link_mode = False
    cli.machine_spawn_enabled = False
    saved = []
    events = []

    async def ensure_services():
        events.append("ensure")

    async def stop_bridge():
        events.append("stop_bridge")

    async def stop_hub():
        events.append("stop_hub")

    async def stop_machine_link():
        events.append("stop_machine_link")
        cli.machine_link_mode = False

    async def send_hello():
        events.append("hello")
        return True

    monkeypatch.setattr(cli, "save_settings", lambda: saved.append(cli._collect_settings_dict()))
    monkeypatch.setattr(cli, "_ensure_remote_runtime_services", ensure_services)
    monkeypatch.setattr(cli, "_stop_remote_control_bridge", stop_bridge)
    monkeypatch.setattr(cli, "_stop_ws_hub", stop_hub)
    monkeypatch.setattr(cli, "_stop_machine_link", stop_machine_link)
    monkeypatch.setattr(cli, "_machine_link_send_hello", send_hello)

    assert asyncio.run(cli.handle_command("/agent on")) is True
    assert cli.agent_mode is True
    assert events[-1] == "ensure"

    assert asyncio.run(cli.handle_command("/remote off")) is True
    assert cli.agent_mode is False
    assert events[-2:] == ["stop_bridge", "stop_hub"]

    assert asyncio.run(cli.handle_command("/machinelink on")) is True
    assert cli.machine_link_mode is True
    assert events[-1] == "ensure"

    assert asyncio.run(cli.handle_command("/machine-link off")) is True
    assert cli.machine_link_mode is False
    assert events[-1] == "stop_machine_link"

    assert asyncio.run(cli.handle_command("/machinespawn on")) is True
    assert cli.machine_spawn_enabled is True
    assert events[-1] == "hello"

    assert asyncio.run(cli.handle_command("/spawnlink off")) is True
    assert cli.machine_spawn_enabled is False
    assert events[-1] == "hello"
    assert len(saved) == 6


def test_settings_ui_exposes_remote_control_and_machine_link_controls(monkeypatch):
    cli_mod = importlib.import_module("cli")
    cli = _make_cli()
    captured = {}

    class FakeSettingsUI:
        def __init__(self, title, items, initial, defaults, footer=None, on_change=None):
            captured["items"] = items
            captured["initial"] = initial
            self.working = dict(initial)

        def run(self):
            return True, dict(self.working)

    async def fake_save_server_settings(updated):
        return True

    monkeypatch.setattr(cli_mod, "HAS_SETTINGS_UI", True)
    monkeypatch.setattr(cli_mod, "SettingsUI", FakeSettingsUI)
    monkeypatch.setattr(cli, "save_settings", lambda: None)
    monkeypatch.setattr(cli, "_save_server_settings", fake_save_server_settings)

    asyncio.run(cli.open_settings())

    groups = {g.get("label"): g for g in captured["items"] if isinstance(g, dict)}
    remote_group = groups.get("Remote Control & Machine Link")
    assert remote_group is not None
    row_ids = [row.get("id") for row in remote_group.get("items", [])]
    assert row_ids == [
        "agent_mode_enabled",
        "machine_link_enabled",
        "machine_spawn_enabled",
        "agent_host",
        "agent_port",
        "agent_allow_remote",
    ]


def test_settings_remote_control_toggle_refreshes_runtime_services(monkeypatch):
    cli_mod = importlib.import_module("cli")
    cli = _make_cli()
    cli.agent_mode = False
    events = []

    class FakeSettingsUI:
        def __init__(self, title, items, initial, defaults, footer=None, on_change=None):
            self.working = dict(initial)
            self.working["agent_mode_enabled"] = True
            if on_change is not None:
                on_change("agent_mode_enabled", True, self.working)

        def run(self):
            return True, dict(self.working)

    async def fake_save_server_settings(updated):
        return True

    async def fake_ensure_services():
        events.append("ensure")

    async def fake_stop_bridge():
        events.append("stop_bridge")

    async def fake_stop_hub():
        events.append("stop_hub")

    monkeypatch.setattr(cli_mod, "HAS_SETTINGS_UI", True)
    monkeypatch.setattr(cli_mod, "SettingsUI", FakeSettingsUI)
    monkeypatch.setattr(cli, "save_settings", lambda: None)
    monkeypatch.setattr(cli, "_save_server_settings", fake_save_server_settings)
    monkeypatch.setattr(cli, "_ensure_remote_runtime_services", fake_ensure_services)
    monkeypatch.setattr(cli, "_stop_remote_control_bridge", fake_stop_bridge)
    monkeypatch.setattr(cli, "_stop_ws_hub", fake_stop_hub)

    asyncio.run(cli.open_settings())

    assert cli.agent_mode is True
    assert "ensure" in events


def test_settings_machine_spawn_toggle_sends_machine_link_hello(monkeypatch):
    cli_mod = importlib.import_module("cli")
    cli = _make_cli()
    cli.machine_link_mode = True
    cli.machine_spawn_enabled = False
    events = []

    class FakeSettingsUI:
        def __init__(self, title, items, initial, defaults, footer=None, on_change=None):
            self.working = dict(initial)
            self.working["machine_spawn_enabled"] = True
            if on_change is not None:
                on_change("machine_spawn_enabled", True, self.working)

        def run(self):
            return True, dict(self.working)

    async def fake_save_server_settings(updated):
        return True

    async def fake_send_hello():
        events.append("hello")
        return True

    monkeypatch.setattr(cli_mod, "HAS_SETTINGS_UI", True)
    monkeypatch.setattr(cli_mod, "SettingsUI", FakeSettingsUI)
    monkeypatch.setattr(cli, "save_settings", lambda: None)
    monkeypatch.setattr(cli, "_save_server_settings", fake_save_server_settings)
    monkeypatch.setattr(cli, "_machine_link_send_hello", fake_send_hello)

    asyncio.run(cli.open_settings())

    assert cli.machine_spawn_enabled is True
    assert "hello" in events
