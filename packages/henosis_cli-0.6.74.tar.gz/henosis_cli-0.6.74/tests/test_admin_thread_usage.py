from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.routers import admin as admin_router


def _build_admin_app():
    engine = create_engine(
        "sqlite://",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
    with engine.begin() as conn:
        conn.execute(
            text(
                """
                CREATE TABLE model_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT,
                    model_id TEXT,
                    tokens_input INTEGER,
                    tokens_output INTEGER,
                    cost REAL,
                    status TEXT,
                    billing_source TEXT,
                    cached_input_tokens INTEGER,
                    non_cached_input_tokens INTEGER,
                    thread_uid TEXT,
                    created_at TEXT
                )
                """
            )
        )
        conn.execute(
            text(
                """
                CREATE TABLE threads (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    thread_uid TEXT,
                    user_id TEXT,
                    name TEXT,
                    title TEXT,
                    created_at TEXT
                )
                """
            )
        )
        conn.execute(
            text(
                """
                CREATE TABLE messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    thread_uid TEXT,
                    role TEXT,
                    content TEXT,
                    model TEXT,
                    input_tokens INTEGER,
                    output_tokens INTEGER,
                    total_tokens INTEGER,
                    created_at TEXT
                )
                """
            )
        )
        conn.execute(
            text(
                """
                INSERT INTO threads (thread_uid, user_id, name, title, created_at)
                VALUES
                    ('thread-1', 'henosis', 'Alpha thread', 'Alpha thread', '2026-05-01 00:00:00'),
                    ('thread-2', 'henosis', 'Beta thread', 'Beta thread', '2026-05-02 00:00:00')
                """
            )
        )
        conn.execute(
            text(
                """
                INSERT INTO model_logs (
                    user_id, model_id, tokens_input, tokens_output, cost, status,
                    billing_source, cached_input_tokens, non_cached_input_tokens, thread_uid, created_at
                ) VALUES
                    ('henosis', 'claude-sonnet-4-6', 100, 40, 0.11, 'success', 'backend_henosis', 30, 70, 'thread-1', '2026-05-01 10:00:00'),
                    ('henosis', 'claude-sonnet-4-6', 60, 20, 0.07, 'success', 'backend_henosis', 10, 50, 'thread-1', '2026-05-01 10:05:00'),
                    ('henosis', 'gpt-5.4', 50, 25, 0.05, 'success', 'backend_henosis', 5, 45, 'thread-2', '2026-05-02 09:00:00')
                """
            )
        )
        conn.execute(
            text(
                """
                INSERT INTO messages (
                    thread_uid, role, content, model, input_tokens, output_tokens, total_tokens, created_at
                ) VALUES
                    ('thread-1', 'user', 'hello', NULL, 0, 0, 0, '2026-05-01 09:59:00'),
                    ('thread-1', 'assistant', 'response one', 'claude-sonnet-4-6', 100, 40, 140, '2026-05-01 10:00:01'),
                    ('thread-1', 'assistant', 'response two', 'claude-sonnet-4-6', 60, 20, 80, '2026-05-01 10:05:01'),
                    ('thread-2', 'assistant', 'other thread', 'gpt-5.4', 50, 25, 75, '2026-05-02 09:00:01')
                """
            )
        )

    app = FastAPI()
    app.include_router(admin_router.router)

    def override_db():
        db = SessionLocal()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[admin_router.get_db] = override_db
    app.dependency_overrides[admin_router._require_admin] = lambda: True
    return app


def test_admin_threads_by_user_returns_thread_cache_stats():
    app = _build_admin_app()
    client = TestClient(app)

    response = client.get("/api/admin/stats/threads_by_user/henosis")
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["username"] == "henosis"
    assert len(body["threads"]) == 2
    first = body["threads"][0]
    assert first["thread_uid"] == "thread-2"
    second = body["threads"][1]
    assert second["thread_uid"] == "thread-1"
    assert second["thread_name"] == "Alpha thread"
    assert second["call_count"] == 2
    assert second["total_input_tokens"] == 160
    assert second["total_output_tokens"] == 60
    assert second["total_cached_input_tokens"] == 40
    assert second["total_non_cached_input_tokens"] == 120
    assert round(float(second["cached_input_percent"]), 2) == 25.0



def test_admin_thread_messages_returns_message_tokens_and_thread_cache_summary():
    app = _build_admin_app()
    client = TestClient(app)

    response = client.get("/api/admin/thread_messages/thread-1")
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["thread_uid"] == "thread-1"
    assert body["thread_name"] == "Alpha thread"
    assert body["thread_owner"] == "henosis"
    assert body["message_totals"]["message_count"] == 3
    assert body["message_totals"]["total_input_tokens"] == 160
    assert body["message_totals"]["total_output_tokens"] == 60
    assert body["message_totals"]["total_tokens"] == 220
    assert len(body["messages"]) == 3
    assert body["messages"][1]["model"] == "claude-sonnet-4-6"
    assert body["thread_usage"]["call_count"] == 2
    assert body["thread_usage"]["total_cached_input_tokens"] == 40
    assert round(float(body["thread_usage"]["cached_input_percent"]), 2) == 25.0
