"""Palace calculation: 命宫/身宫, 五行局, 十二宫名, 大限."""

from ziwei.calendar_utils import solar_to_lunar, get_stems_and_branches
from ziwei.data.constants import (
    EARTHLY_BRANCHES,
    HEAVENLY_STEMS,
    PALACES,
    TIGER_RULE,
    FIVE_ELEMENTS_CLASS,
)
from ziwei.data.stems import EARTHLY_BRANCH_INFO
from ziwei.utils import fix_index


def _get_lunar_month_index(solar_date: str, time_index: int, fix_leap: bool = True) -> int:
    """Compute the lunar month index with 寅=0 as the starting position.

    Args:
        solar_date:  Solar date as 'YYYY-M-D'.
        time_index:  Earthly branch index of the birth hour (0=子…11=亥, 12=晚子时).
        fix_leap:    Whether to adjust for leap months.

    Returns:
        Integer 0-11 where 0 represents the 寅 month (lunar month 1).
    """
    lunar = solar_to_lunar(solar_date)
    month = lunar["month"]
    is_leap = lunar["is_leap"]
    day = lunar["day"]
    yin_idx = EARTHLY_BRANCHES.index("寅")  # = 2
    need_add = is_leap and fix_leap and day > 15 and time_index != 12
    return fix_index(month + 1 - yin_idx + (1 if need_add else 0))


def get_soul_and_body(solar_date: str, time_index: int, fix_leap: bool = True) -> dict:
    """Calculate 命宫 (soul palace) and 身宫 (body palace) positions.

    Algorithm:
        1. Use 五虎遁 (TIGER_RULE) with year stem to find the heavenly stem
           of the 寅宫 (first palace).
        2. Compute the lunar month index (寅=0 based).
        3. soul_index = fix_index(month_index - time_branch_index)   # 逆数生时
        4. body_index = fix_index(month_index + time_branch_index)   # 顺数生时
        5. Derive soul stem and branches from the above indices.

    Args:
        solar_date:  Solar date as 'YYYY-M-D'.
        time_index:  Earthly branch index of birth hour (0=子, 1=丑, 2=寅 …).
        fix_leap:    Whether to adjust for leap months.

    Returns:
        dict with keys:
            soul_index   – palace index (寅=0) of 命宫
            body_index   – palace index (寅=0) of 身宫
            soul_stem    – heavenly stem of 命宫 (str)
            soul_branch  – earthly branch of 命宫 (str)
            body_branch  – earthly branch of 身宫 (str)
            year_branch  – earthly branch of the birth year (str)
    """
    sab = get_stems_and_branches(solar_date, time_index)
    year_stem = sab["yearly"][0]
    year_branch = sab["yearly"][1]

    # 五虎遁: starting heavenly stem for 寅宫
    start_stem = TIGER_RULE[year_stem]

    yin_idx = EARTHLY_BRANCHES.index("寅")  # = 2

    month_index = _get_lunar_month_index(solar_date, time_index, fix_leap)

    # time_index is already in EARTHLY_BRANCHES order (0=子, 1=丑, 2=寅…)
    # For 晚子时 (time_index=12) treat as 子時 (index 0)
    time_branch_idx = time_index % 12

    # 命宫: from 寅月 count forward to birth month, then count *back* birth hour
    soul_index = fix_index(month_index - time_branch_idx)

    # 身宫: from 寅月 count forward to birth month, then count *forward* birth hour
    body_index = fix_index(month_index + time_branch_idx)

    # Soul palace heavenly stem (cycles every 10 stems)
    start_stem_idx = HEAVENLY_STEMS.index(start_stem)
    soul_stem_idx = fix_index(start_stem_idx + soul_index, 10)
    soul_stem = HEAVENLY_STEMS[soul_stem_idx]

    # Soul / body palace earthly branches (shift back to EARTHLY_BRANCHES absolute index)
    soul_branch = EARTHLY_BRANCHES[fix_index(soul_index + yin_idx)]
    body_branch = EARTHLY_BRANCHES[fix_index(body_index + yin_idx)]

    return {
        "soul_index": soul_index,
        "body_index": body_index,
        "soul_stem": soul_stem,
        "soul_branch": soul_branch,
        "body_branch": body_branch,
        "year_branch": year_branch,
    }


def get_five_elements_class(heavenly_stem: str, earthly_branch: str) -> str:
    """Determine the 五行局 (Five Elements Class) from 命宫 stem and branch.

    口诀:
        甲乙丙丁一到五；子午丑未一来数，
        寅卯申酉二上走，辰巳戌亥三为足。
        干支相加多减五，五行木金水火土。

    Args:
        heavenly_stem:   Heavenly stem of 命宫 (e.g. "壬").
        earthly_branch:  Earthly branch of 命宫 (e.g. "午").

    Returns:
        One of: "水二局", "木三局", "金四局", "土五局", "火六局".
    """
    table = ["木三局", "金四局", "水二局", "火六局", "土五局"]

    stem_idx = HEAVENLY_STEMS.index(heavenly_stem)
    branch_idx = EARTHLY_BRANCHES.index(earthly_branch)

    stem_num = stem_idx // 2 + 1
    branch_num = fix_index(branch_idx, 6) // 2 + 1

    total = stem_num + branch_num
    while total > 5:
        total -= 5

    return table[total - 1]


def get_palace_names(soul_index: int) -> list:
    """Return the 12 palace names ordered from 寅宫, given the 命宫 palace index.

    Position 0 in the returned list is 寅宫.  The 命宫 will be at ``soul_index``.

    Args:
        soul_index: Palace index (寅=0) of 命宫.

    Returns:
        List of 12 palace-name strings.
    """
    soul_index = fix_index(soul_index)
    names = []
    for i in range(12):
        idx = fix_index(i - soul_index)
        names.append(PALACES[idx])
    return names


def get_horoscope(
    solar_date: str,
    time_index: int,
    gender: str,
    soul_index: int,
    five_elements_class: str,
) -> list:
    """Compute 大限 (decadal horoscope) for each of the 12 palaces.

    Direction rule:
        - 阳男阴女 → 顺行 (forward from soul palace)
        - 阴男阳女 → 逆行 (backward from soul palace)

    "Yang/Yin" of the person:
        - 男 (male)   → 阳
        - 女 (female) → 阴

    The direction is *forward* when the person's yinyang matches the year
    branch's yinyang (both yang or both yin), otherwise *reverse*.

    Args:
        solar_date:          Solar date as 'YYYY-M-D'.
        time_index:          Earthly branch index of birth hour.
        gender:              "男" or "女".
        soul_index:          Palace index (寅=0) of 命宫.
        five_elements_class: One of the 五行局 strings (e.g. "木三局").

    Returns:
        List of 12 dicts (one per palace, ordered from 寅宫), each containing:
            range        – [start_age, end_age] (10-year span)
            heavenly_stem – heavenly stem of that decade palace
            earthly_branch – earthly branch of that decade palace
    """
    sab = get_stems_and_branches(solar_date, time_index)
    year_stem = sab["yearly"][0]
    year_branch = sab["yearly"][1]

    # 五虎遁 starting stem for 寅宫
    start_stem = TIGER_RULE[year_stem]
    start_stem_idx = HEAVENLY_STEMS.index(start_stem)
    yin_idx = EARTHLY_BRANCHES.index("寅")

    # Determine direction: forward if gender yinyang == year branch yinyang
    person_yinyang = "阳" if gender == "男" else "阴"
    year_branch_yinyang = EARTHLY_BRANCH_INFO[year_branch]["yinyang"]
    forward = person_yinyang == year_branch_yinyang

    # Starting age (水二局=2, 木三局=3, 金四局=4, 土五局=5, 火六局=6)
    start_age = FIVE_ELEMENTS_CLASS[five_elements_class]

    # Build horoscope: 12 entries indexed by palace position (寅=0)
    horoscope = [None] * 12
    for i in range(12):
        if forward:
            idx = fix_index(soul_index + i)
        else:
            idx = fix_index(soul_index - i)

        start = start_age + 10 * i
        stem_idx = fix_index(start_stem_idx + idx, 10)
        branch_idx = fix_index(yin_idx + idx)

        horoscope[idx] = {
            "range": [start, start + 9],
            "heavenly_stem": HEAVENLY_STEMS[stem_idx],
            "earthly_branch": EARTHLY_BRANCHES[branch_idx],
        }

    return horoscope
