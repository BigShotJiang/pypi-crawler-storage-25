"""Calendar utilities using sxtwl for solar/lunar conversion and GanZhi calculation."""

import sxtwl

from ziwei.data.constants import EARTHLY_BRANCHES, HEAVENLY_STEMS, ZODIAC

# Maps branch index (0=子, 1=丑, ..., 11=亥) to representative 24-hour time
# used by sxtwl.getShiGz. Each 时辰 spans 2 hours:
#   子(0)=0:00, 丑(1)=1:00, 寅(2)=3:00, 卯(3)=5:00, ...
_BRANCH_TO_HOUR = [0, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21]


def _parse_solar_date(solar_date: str):
    """Parse 'YYYY-M-D' string into (year, month, day) ints."""
    parts = solar_date.split("-")
    return int(parts[0]), int(parts[1]), int(parts[2])


def solar_to_lunar(solar_date: str) -> dict:
    """Convert solar date string 'YYYY-M-D' to lunar date components.

    Returns:
        dict with keys: year (int), month (int), day (int), is_leap (bool)
    """
    y, m, d = _parse_solar_date(solar_date)
    day = sxtwl.fromSolar(y, m, d)
    return {
        "year": day.getLunarYear(),
        "month": day.getLunarMonth(),
        "day": day.getLunarDay(),
        "is_leap": bool(day.isLunarLeap()),
    }


def lunar_to_solar(year: int, month: int, day: int, is_leap: bool = False) -> str:
    """Convert lunar date to solar date string 'YYYY-M-D'.

    Args:
        year:    Lunar year
        month:   Lunar month (1-12)
        day:     Lunar day (1-30)
        is_leap: Whether this is a leap month

    Returns:
        Solar date as 'YYYY-M-D' string
    """
    d = sxtwl.fromLunar(year, month, day, is_leap)
    return f"{d.getSolarYear()}-{d.getSolarMonth()}-{d.getSolarDay()}"


def get_stems_and_branches(solar_date: str, time_index: int) -> dict:
    """Get the four pillars (四柱) GanZhi for a given solar date and hour.

    Args:
        solar_date:  Solar date as 'YYYY-M-D'
        time_index:  Earthly branch index of the hour (0=子, 1=丑, ..., 11=亥)

    Returns:
        dict with keys: yearly, monthly, daily, hourly — each a (stem, branch) tuple
    """
    y, m, d = _parse_solar_date(solar_date)
    day = sxtwl.fromSolar(y, m, d)

    ygz = day.getYearGZ()
    mgz = day.getMonthGZ()
    dgz = day.getDayGZ()

    hour_24 = _BRANCH_TO_HOUR[time_index % 12]
    hgz = sxtwl.getShiGz(dgz.tg, hour_24)

    return {
        "yearly": (HEAVENLY_STEMS[ygz.tg], EARTHLY_BRANCHES[ygz.dz]),
        "monthly": (HEAVENLY_STEMS[mgz.tg], EARTHLY_BRANCHES[mgz.dz]),
        "daily": (HEAVENLY_STEMS[dgz.tg], EARTHLY_BRANCHES[dgz.dz]),
        "hourly": (HEAVENLY_STEMS[hgz.tg], EARTHLY_BRANCHES[hgz.dz]),
    }


def get_zodiac(solar_date: str) -> str:
    """Return the zodiac animal for the lunar year of the given solar date.

    Args:
        solar_date: Solar date as 'YYYY-M-D'

    Returns:
        Chinese zodiac animal character (e.g. '龙')
    """
    y, m, d = _parse_solar_date(solar_date)
    day = sxtwl.fromSolar(y, m, d)
    ygz = day.getYearGZ()
    return ZODIAC[ygz.dz]


def get_lunar_month_days(solar_date: str) -> int:
    """Return the total number of days in the lunar month containing the given solar date.

    Args:
        solar_date: Solar date as 'YYYY-M-D'

    Returns:
        Number of days in the lunar month (29 or 30)
    """
    y, m, d = _parse_solar_date(solar_date)
    day = sxtwl.fromSolar(y, m, d)
    lunar_year = day.getLunarYear()
    lunar_month = day.getLunarMonth()
    is_leap = bool(day.isLunarLeap())
    return sxtwl.getLunarMonthNum(lunar_year, lunar_month, is_leap)


def time_name_to_index(branch_or_name: str) -> int:
    """Convert a time name or numeric string to a branch index (0-11).

    Accepts:
        - Earthly branch character: '子', '丑', '寅', ...
        - Branch with 时 suffix: '子时', '丑时', '寅时', ...
        - Numeric string: '0', '1', '2', ...

    Returns:
        Integer 0-11 representing the branch index
    """
    name = branch_or_name.strip()

    # Numeric string
    if name.isdigit():
        return int(name)

    # Strip 时 suffix if present
    if name.endswith("时"):
        name = name[:-1]

    # Look up branch character
    if name in EARTHLY_BRANCHES:
        return EARTHLY_BRANCHES.index(name)

    raise ValueError(f"Unrecognized time name: {branch_or_name!r}")
