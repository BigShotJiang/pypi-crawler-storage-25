"""Static data tables for ziwei."""
