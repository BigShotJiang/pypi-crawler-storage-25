"""天干四化表、地支属性表"""

HEAVENLY_STEM_INFO = {
    "甲": {"yinyang": "阳", "element": "木", "mutagen": ["廉贞", "破军", "武曲", "太阳"]},
    "乙": {"yinyang": "阴", "element": "木", "mutagen": ["天机", "天梁", "紫微", "太阴"]},
    "丙": {"yinyang": "阳", "element": "火", "mutagen": ["天同", "天机", "文昌", "廉贞"]},
    "丁": {"yinyang": "阴", "element": "火", "mutagen": ["太阴", "天同", "天机", "巨门"]},
    "戊": {"yinyang": "阳", "element": "土", "mutagen": ["贪狼", "太阴", "右弼", "天机"]},
    "己": {"yinyang": "阴", "element": "土", "mutagen": ["武曲", "贪狼", "天梁", "文曲"]},
    "庚": {"yinyang": "阳", "element": "金", "mutagen": ["太阳", "武曲", "太阴", "天同"]},
    "辛": {"yinyang": "阴", "element": "金", "mutagen": ["巨门", "太阳", "文曲", "文昌"]},
    "壬": {"yinyang": "阳", "element": "水", "mutagen": ["天梁", "紫微", "左辅", "武曲"]},
    "癸": {"yinyang": "阴", "element": "水", "mutagen": ["破军", "巨门", "太阴", "贪狼"]},
}

EARTHLY_BRANCH_INFO = {
    "子": {"yinyang": "阳", "element": "水", "soul": "贪狼", "body": "火星"},
    "丑": {"yinyang": "阴", "element": "土", "soul": "巨门", "body": "天相"},
    "寅": {"yinyang": "阳", "element": "木", "soul": "禄存", "body": "天梁"},
    "卯": {"yinyang": "阴", "element": "木", "soul": "文曲", "body": "天同"},
    "辰": {"yinyang": "阳", "element": "土", "soul": "廉贞", "body": "文昌"},
    "巳": {"yinyang": "阴", "element": "火", "soul": "武曲", "body": "天机"},
    "午": {"yinyang": "阳", "element": "火", "soul": "破军", "body": "火星"},
    "未": {"yinyang": "阴", "element": "土", "soul": "武曲", "body": "天相"},
    "申": {"yinyang": "阳", "element": "金", "soul": "廉贞", "body": "天梁"},
    "酉": {"yinyang": "阴", "element": "金", "soul": "文曲", "body": "天同"},
    "戌": {"yinyang": "阳", "element": "土", "soul": "禄存", "body": "文昌"},
    "亥": {"yinyang": "阴", "element": "水", "soul": "巨门", "body": "天机"},
}
