"""CLI entry point using click."""

import click
from ziwei.astro import generate_astrolabe
from ziwei.calendar_utils import time_name_to_index
from ziwei.formatter import print_astrolabe


@click.command()
@click.argument("date")
@click.option("--time", "-t", "time_str", required=True, help="时辰 (寅/2/寅时)")
@click.option("--gender", "-g", required=True, type=click.Choice(["男", "女"]), help="性别")
@click.option("--lunar", is_flag=True, default=False, help="输入为农历日期")
@click.option("--leap", is_flag=True, default=False, help="农历闰月")
@click.option("--no-color", is_flag=True, default=False, help="禁用彩色输出")
def main(date: str, time_str: str, gender: str, lunar: bool, leap: bool, no_color: bool):
    """紫微斗数命令行排盘工具

    DATE: 日期，格式 YYYY-M-D (如 2000-8-16)
    """
    time_index = time_name_to_index(time_str)
    astrolabe = generate_astrolabe(
        date_str=date,
        time_index=time_index,
        gender=gender,
        is_lunar=lunar,
        is_leap_month=leap,
    )
    print_astrolabe(astrolabe, use_color=not no_color)


if __name__ == "__main__":
    main()
