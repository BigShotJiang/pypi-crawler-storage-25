"""Main astrolabe generation logic."""

from dataclasses import dataclass, field
from ziwei.data.constants import HEAVENLY_STEMS, EARTHLY_BRANCHES, CHINESE_TIME, TIME_RANGE, TIGER_RULE
from ziwei.data.stems import EARTHLY_BRANCH_INFO
from ziwei.calendar_utils import get_stems_and_branches, solar_to_lunar, lunar_to_solar, get_zodiac
from ziwei.palace import get_soul_and_body, get_five_elements_class, get_palace_names, get_horoscope
from ziwei.star import (
    get_major_stars, get_minor_stars, get_adjective_stars,
    get_changsheng12, get_boshi12, get_yearly12, get_start_index,
)
from ziwei.utils import fix_index


@dataclass
class Star:
    name: str
    type: str
    brightness: str | None = None
    mutagen: str | None = None


@dataclass
class Palace:
    index: int
    name: str
    heavenly_stem: str
    earthly_branch: str
    major_stars: list[Star] = field(default_factory=list)
    minor_stars: list[Star] = field(default_factory=list)
    adjective_stars: list[Star] = field(default_factory=list)
    changsheng12: str = ""
    boshi12: str = ""
    jiangqian12: str = ""
    suiqian12: str = ""
    is_body_palace: bool = False
    decadal_range: tuple[int, int] = (0, 0)
    decadal_stem: str = ""
    decadal_branch: str = ""


@dataclass
class Astrolabe:
    gender: str
    solar_date: str
    lunar_date: str
    chinese_date: str
    time_name: str
    time_range: str
    zodiac: str
    soul_palace: str
    body_palace: str
    soul_star: str
    body_star: str
    five_elements_class: str
    palaces: list[Palace] = field(default_factory=list)


def generate_astrolabe(
    date_str: str,
    time_index: int,
    gender: str,
    fix_leap: bool = True,
    is_lunar: bool = False,
    is_leap_month: bool = False,
) -> Astrolabe:
    if is_lunar:
        parts = date_str.split("-")
        solar_date = lunar_to_solar(int(parts[0]), int(parts[1]), int(parts[2]), is_leap_month)
    else:
        solar_date = date_str

    stems = get_stems_and_branches(solar_date, time_index)
    year_stem, year_branch = stems["yearly"]
    lunar = solar_to_lunar(solar_date)

    sb = get_soul_and_body(solar_date, time_index, fix_leap)
    # get five_elements_class from start_index result (it uses same algorithm)
    start_info = get_start_index(solar_date, time_index, fix_leap)
    fec = start_info["five_elements_class"]

    palace_names = get_palace_names(sb["soul_index"])
    major = get_major_stars(solar_date, time_index, fix_leap)
    minor = get_minor_stars(solar_date, time_index, fix_leap)
    adjective = get_adjective_stars(solar_date, time_index, gender, fix_leap)
    changsheng12 = get_changsheng12(solar_date, time_index, gender, fix_leap)
    boshi12 = get_boshi12(solar_date, gender)
    yearly12 = get_yearly12(solar_date)
    horoscope = get_horoscope(solar_date, time_index, gender, sb["soul_index"], fec)

    yin_idx = EARTHLY_BRANCHES.index("寅")
    soul_eb = EARTHLY_BRANCHES[fix_index(sb["soul_index"] + yin_idx)]
    body_eb = EARTHLY_BRANCHES[fix_index(sb["body_index"] + yin_idx)]

    soul_star = EARTHLY_BRANCH_INFO[soul_eb]["soul"]
    body_star = EARTHLY_BRANCH_INFO[year_branch]["body"]

    # Build palaces
    soul_stem_palace_idx = HEAVENLY_STEMS.index(sb["soul_stem"])
    palaces = []
    for i in range(12):
        stem_idx = fix_index(soul_stem_palace_idx - sb["soul_index"] + i, max_val=10)
        branch_idx = fix_index(yin_idx + i)

        dec = horoscope[i]
        dec_range = tuple(dec["range"]) if dec else (0, 0)
        dec_stem = dec["heavenly_stem"] if dec else ""
        dec_branch = dec["earthly_branch"] if dec else ""

        palaces.append(Palace(
            index=i,
            name=palace_names[i],
            heavenly_stem=HEAVENLY_STEMS[stem_idx],
            earthly_branch=EARTHLY_BRANCHES[branch_idx],
            major_stars=[Star(**s) for s in major[i]],
            minor_stars=[Star(**s) for s in minor[i]],
            adjective_stars=[Star(**s) for s in adjective[i]],
            changsheng12=changsheng12[i],
            boshi12=boshi12[i],
            jiangqian12=yearly12["jiangqian12"][i],
            suiqian12=yearly12["suiqian12"][i],
            is_body_palace=(sb["body_index"] == i),
            decadal_range=dec_range,
            decadal_stem=dec_stem,
            decadal_branch=dec_branch,
        ))

    lunar_display = f"{_stem_branch_year(stems)}年{'闰' if lunar['is_leap'] else ''}{_month_cn(lunar['month'])}月{_day_cn(lunar['day'])}"
    chinese_date = f"{stems['yearly'][0]}{stems['yearly'][1]} {stems['monthly'][0]}{stems['monthly'][1]} {stems['daily'][0]}{stems['daily'][1]} {stems['hourly'][0]}{stems['hourly'][1]}"

    return Astrolabe(
        gender=gender,
        solar_date=solar_date,
        lunar_date=lunar_display,
        chinese_date=chinese_date,
        time_name=CHINESE_TIME[time_index],
        time_range=TIME_RANGE[time_index],
        zodiac=get_zodiac(solar_date),
        soul_palace=soul_eb,
        body_palace=body_eb,
        soul_star=soul_star,
        body_star=body_star,
        five_elements_class=fec,
        palaces=palaces,
    )


def _stem_branch_year(stems: dict) -> str:
    return f"{stems['yearly'][0]}{stems['yearly'][1]}"


def _month_cn(month: int) -> str:
    names = ["正", "二", "三", "四", "五", "六", "七", "八", "九", "十", "十一", "十二"]
    return names[month - 1]


def _day_cn(day: int) -> str:
    units = "一二三四五六七八九十"
    if day <= 10:
        return "初" + units[day - 1]
    elif day < 20:
        return "十" + units[day - 11]
    elif day == 20:
        return "二十"
    elif day < 30:
        return "廿" + units[day - 21]
    elif day == 30:
        return "三十"
    return str(day)
