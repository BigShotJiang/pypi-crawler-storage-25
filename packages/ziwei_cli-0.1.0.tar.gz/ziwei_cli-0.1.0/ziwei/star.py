"""Star placement functions for Ziwei Doushu chart."""

from ziwei.calendar_utils import solar_to_lunar, get_stems_and_branches
from ziwei.data.constants import (
    EARTHLY_BRANCHES,
    HEAVENLY_STEMS,
    PALACES,
    FIVE_ELEMENTS_CLASS,
)
from ziwei.data.stems import EARTHLY_BRANCH_INFO
from ziwei.palace import (
    get_soul_and_body,
    get_five_elements_class,
    _get_lunar_month_index,
)
from ziwei.utils import fix_index, fix_earthly_branch_index, get_brightness, get_mutagen


def _init_stars():
    return [[] for _ in range(12)]


# ---------------------------------------------------------------------------
# 1. get_start_index
# ---------------------------------------------------------------------------

def get_start_index(solar_date, time_index, fix_leap=True):
    """Calculate ziwei and tianfu starting palace indices."""
    soul_info = get_soul_and_body(solar_date, time_index, fix_leap)
    fec = get_five_elements_class(soul_info["soul_stem"], soul_info["soul_branch"])
    fec_value = FIVE_ELEMENTS_CLASS[fec]

    lunar = solar_to_lunar(solar_date)
    day = lunar["day"]
    # Adjust for late rat hour
    if time_index >= 12:
        day += 1

    offset = 0
    while (day + offset) % fec_value != 0:
        offset += 1

    quotient = (day + offset) // fec_value
    quotient = quotient % 12
    ziwei_index = quotient - 1
    if offset % 2 == 0:
        ziwei_index += offset
    else:
        ziwei_index -= offset
    ziwei_index = fix_index(ziwei_index)
    tianfu_index = fix_index(12 - ziwei_index)

    return {
        "ziwei_index": ziwei_index,
        "tianfu_index": tianfu_index,
        "five_elements_class": fec,
    }


# ---------------------------------------------------------------------------
# 2. get_major_stars
# ---------------------------------------------------------------------------

def get_major_stars(solar_date, time_index, fix_leap=True):
    """Place 14 major stars."""
    stars = _init_stars()
    start = get_start_index(solar_date, time_index, fix_leap)
    ziwei_idx = start["ziwei_index"]
    tianfu_idx = start["tianfu_index"]

    sab = get_stems_and_branches(solar_date, time_index)
    year_stem = sab["yearly"][0]

    ziwei_group = ["紫微", "天机", "", "太阳", "武曲", "天同", "", "", "廉贞"]
    tianfu_group = ["天府", "太阴", "贪狼", "巨门", "天相", "天梁", "七杀", "", "", "", "破军"]

    for i, name in enumerate(ziwei_group):
        if name:
            idx = fix_index(ziwei_idx - i)
            stars[idx].append({
                "name": name,
                "type": "major",
                "brightness": get_brightness(name, idx),
                "mutagen": get_mutagen(name, year_stem),
            })

    for i, name in enumerate(tianfu_group):
        if name:
            idx = fix_index(tianfu_idx + i)
            stars[idx].append({
                "name": name,
                "type": "major",
                "brightness": get_brightness(name, idx),
                "mutagen": get_mutagen(name, year_stem),
            })

    return stars


# ---------------------------------------------------------------------------
# 3. get_minor_stars - helpers
# ---------------------------------------------------------------------------

def _get_lu_yang_tuo_ma_index(stem, branch):
    """Get indices for 禄存, 擎羊, 陀罗, 天马."""
    lu_map = {
        "甲": "寅", "乙": "卯", "丙": "巳", "戊": "巳",
        "丁": "午", "己": "午", "庚": "申", "辛": "酉",
        "壬": "亥", "癸": "子",
    }
    lu = fix_earthly_branch_index(lu_map[stem])
    yang = fix_index(lu + 1)
    tuo = fix_index(lu - 1)

    ma_map = {
        "寅": "申", "午": "申", "戌": "申",
        "申": "寅", "子": "寅", "辰": "寅",
        "巳": "亥", "酉": "亥", "丑": "亥",
        "亥": "巳", "卯": "巳", "未": "巳",
    }
    ma = fix_earthly_branch_index(ma_map[branch])

    return {"禄存": lu, "擎羊": yang, "陀罗": tuo, "天马": ma}


def _get_kui_yue_index(stem):
    """Get indices for 天魁, 天钺."""
    kui_yue_map = {
        "甲": ("丑", "未"), "戊": ("丑", "未"), "庚": ("丑", "未"),
        "乙": ("子", "申"), "己": ("子", "申"),
        "辛": ("午", "寅"),
        "丙": ("亥", "酉"), "丁": ("亥", "酉"),
        "壬": ("卯", "巳"), "癸": ("卯", "巳"),
    }
    kui_branch, yue_branch = kui_yue_map[stem]
    return {
        "天魁": fix_earthly_branch_index(kui_branch),
        "天钺": fix_earthly_branch_index(yue_branch),
    }


def _get_zuo_you_index(lunar_month):
    """Get indices for 左辅, 右弼 by lunar month (1-based)."""
    zuo = fix_index(fix_earthly_branch_index("辰") + (lunar_month - 1))
    you = fix_index(fix_earthly_branch_index("戌") - (lunar_month - 1))
    return {"左辅": zuo, "右弼": you}


def _get_chang_qu_index(time_index):
    """Get indices for 文昌, 文曲 by time."""
    chang = fix_index(fix_earthly_branch_index("戌") - fix_index(time_index))
    qu = fix_index(fix_earthly_branch_index("辰") + fix_index(time_index))
    return {"文昌": chang, "文曲": qu}


def _get_kong_jie_index(time_index):
    """Get indices for 地空, 地劫."""
    hai_idx = fix_earthly_branch_index("亥")
    kong = fix_index(hai_idx - fix_index(time_index))
    jie = fix_index(hai_idx + fix_index(time_index))
    return {"地空": kong, "地劫": jie}


def _get_huo_ling_index(year_branch, time_index):
    """Get indices for 火星, 铃星."""
    fire_map = {
        "寅": "丑", "午": "丑", "戌": "丑",
        "申": "寅", "子": "寅", "辰": "寅",
        "巳": "卯", "酉": "卯", "丑": "卯",
        "亥": "酉", "卯": "酉", "未": "酉",
    }
    spark_map = {
        "寅": "卯", "午": "卯", "戌": "卯",
        "申": "戌", "子": "戌", "辰": "戌",
        "巳": "戌", "酉": "戌", "丑": "戌",
        "亥": "戌", "卯": "戌", "未": "戌",
    }
    fire_start = fix_earthly_branch_index(fire_map[year_branch])
    spark_start = fix_earthly_branch_index(spark_map[year_branch])
    return {
        "火星": fix_index(fire_start + fix_index(time_index)),
        "铃星": fix_index(spark_start + fix_index(time_index)),
    }


def get_minor_stars(solar_date, time_index, fix_leap=True):
    """Place 14 minor stars."""
    stars = _init_stars()

    sab = get_stems_and_branches(solar_date, time_index)
    year_stem = sab["yearly"][0]
    year_branch = sab["yearly"][1]

    month_index = _get_lunar_month_index(solar_date, time_index, fix_leap)
    lunar_month = month_index + 1  # convert back to 1-based

    indices = {}
    indices.update(_get_lu_yang_tuo_ma_index(year_stem, year_branch))
    indices.update(_get_kui_yue_index(year_stem))
    indices.update(_get_zuo_you_index(lunar_month))
    indices.update(_get_chang_qu_index(time_index))
    indices.update(_get_kong_jie_index(time_index))
    indices.update(_get_huo_ling_index(year_branch, time_index))

    # Stars with mutagen check
    mutagen_stars = {"左辅", "右弼", "文昌", "文曲"}

    for name, idx in indices.items():
        star = {
            "name": name,
            "type": "minor",
            "brightness": get_brightness(name, idx),
            "mutagen": get_mutagen(name, year_stem) if name in mutagen_stars else None,
        }
        stars[idx].append(star)

    return stars


# ---------------------------------------------------------------------------
# 4. get_adjective_stars - helpers
# ---------------------------------------------------------------------------

def _get_luan_xi_index(year_branch):
    """Get indices for 红鸾, 天喜."""
    luan = fix_index(fix_earthly_branch_index("卯") - EARTHLY_BRANCHES.index(year_branch))
    xi = fix_index(luan + 6)
    return {"红鸾": luan, "天喜": xi}


def _get_monthly_star_index(solar_date, time_index, fix_leap=True):
    """Get indices for monthly stars."""
    month_index = _get_lunar_month_index(solar_date, time_index, fix_leap)

    jieshen_branches = ["申", "戌", "子", "寅", "辰", "午"]
    jieshen = fix_earthly_branch_index(jieshen_branches[month_index // 2])

    tianyao = fix_index(fix_earthly_branch_index("丑") + month_index)
    tianxing = fix_index(fix_earthly_branch_index("酉") + month_index)

    yinsha_branches = ["寅", "子", "戌", "申", "午", "辰"]
    yinsha = fix_earthly_branch_index(yinsha_branches[month_index % 6])

    tianyue_branches = ["戌", "巳", "辰", "寅", "未", "卯", "亥", "未", "寅", "午", "戌", "寅"]
    tianyue = fix_earthly_branch_index(tianyue_branches[month_index])

    tianwu_branches = ["巳", "申", "寅", "亥"]
    tianwu = fix_earthly_branch_index(tianwu_branches[month_index % 4])

    return {
        "解神": jieshen,
        "天姚": tianyao,
        "天刑": tianxing,
        "阴煞": yinsha,
        "天月": tianyue,
        "天巫": tianwu,
    }


def _get_daily_star_index(solar_date, time_index, fix_leap=True):
    """Get indices for daily stars (三台, 八座, 恩光, 天贵)."""
    month_index = _get_lunar_month_index(solar_date, time_index, fix_leap)
    lunar_month = month_index + 1

    zuo_you = _get_zuo_you_index(lunar_month)
    zuo_idx = zuo_you["左辅"]
    you_idx = zuo_you["右弼"]

    chang_qu = _get_chang_qu_index(time_index)
    chang_idx = chang_qu["文昌"]
    qu_idx = chang_qu["文曲"]

    lunar = solar_to_lunar(solar_date)
    lunar_day = lunar["day"]
    day_index = lunar_day - 1
    if time_index >= 12:
        day_index = lunar_day

    santai = fix_index((zuo_idx + day_index) % 12)
    bazuo = fix_index((you_idx - day_index) % 12)
    enguang = fix_index(((chang_idx + day_index) % 12) - 1)
    tiangui = fix_index(((qu_idx + day_index) % 12) - 1)

    return {
        "三台": santai,
        "八座": bazuo,
        "恩光": enguang,
        "天贵": tiangui,
    }


def _get_timely_star_index(time_index):
    """Get indices for 台辅, 封诰."""
    taifu = fix_index(fix_earthly_branch_index("午") + fix_index(time_index))
    fenggao = fix_index(fix_earthly_branch_index("寅") + fix_index(time_index))
    return {"台辅": taifu, "封诰": fenggao}


def _get_yearly_star_index(solar_date, time_index, gender, fix_leap=True):
    """Get indices for yearly adjective stars."""
    sab = get_stems_and_branches(solar_date, time_index)
    year_stem = sab["yearly"][0]
    year_branch = sab["yearly"][1]
    yb_idx = EARTHLY_BRANCHES.index(year_branch)

    soul_info = get_soul_and_body(solar_date, time_index, fix_leap)
    soul_index = soul_info["soul_index"]
    body_index = soul_info["body_index"]

    result = {}

    # Basic yearly stars
    result["天才"] = fix_index(soul_index + yb_idx)
    result["天寿"] = fix_index(body_index + yb_idx)
    result["龙池"] = fix_index(fix_earthly_branch_index("辰") + yb_idx)
    result["凤阁"] = fix_index(fix_earthly_branch_index("戌") - yb_idx)
    result["天哭"] = fix_index(fix_earthly_branch_index("午") - yb_idx)
    result["天虚"] = fix_index(fix_earthly_branch_index("午") + yb_idx)
    result["天空"] = fix_index(fix_earthly_branch_index(year_branch) + 1)
    result["天德"] = fix_index(fix_earthly_branch_index("酉") + yb_idx)
    result["月德"] = fix_index(fix_earthly_branch_index("巳") + yb_idx)

    # 华盖/咸池
    huagai_xianchi_map = {
        "寅": ("戌", "卯"), "午": ("戌", "卯"), "戌": ("戌", "卯"),
        "申": ("辰", "酉"), "子": ("辰", "酉"), "辰": ("辰", "酉"),
        "巳": ("丑", "午"), "酉": ("丑", "午"), "丑": ("丑", "午"),
        "亥": ("未", "子"), "卯": ("未", "子"), "未": ("未", "子"),
    }
    hg, xc = huagai_xianchi_map[year_branch]
    result["华盖"] = fix_earthly_branch_index(hg)
    result["咸池"] = fix_earthly_branch_index(xc)

    # 孤辰/寡宿
    guchen_guasu_map = {
        "寅": ("巳", "丑"), "卯": ("巳", "丑"), "辰": ("巳", "丑"),
        "巳": ("申", "辰"), "午": ("申", "辰"), "未": ("申", "辰"),
        "申": ("亥", "未"), "酉": ("亥", "未"), "戌": ("亥", "未"),
        "亥": ("寅", "戌"), "子": ("寅", "戌"), "丑": ("寅", "戌"),
    }
    gc, gs = guchen_guasu_map[year_branch]
    result["孤辰"] = fix_earthly_branch_index(gc)
    result["寡宿"] = fix_earthly_branch_index(gs)

    # 破碎
    posui_branches = ["巳", "丑", "酉"]
    result["破碎"] = fix_earthly_branch_index(posui_branches[yb_idx % 3])

    # 蜚蠊
    feilian_branches = ["申", "酉", "戌", "巳", "午", "未", "寅", "卯", "辰", "亥", "子", "丑"]
    result["蜚蠊"] = fix_earthly_branch_index(feilian_branches[yb_idx])

    # By year stem
    stem_idx = HEAVENLY_STEMS.index(year_stem)

    tianchu_branches = ["巳", "午", "子", "巳", "午", "申", "寅", "午", "酉", "亥"]
    result["天厨"] = fix_earthly_branch_index(tianchu_branches[stem_idx])

    tianguan_branches = ["未", "辰", "巳", "寅", "卯", "酉", "亥", "酉", "戌", "午"]
    result["天官"] = fix_earthly_branch_index(tianguan_branches[stem_idx])

    tianfu_branches = ["酉", "申", "子", "亥", "卯", "寅", "午", "巳", "午", "巳"]
    result["天福"] = fix_earthly_branch_index(tianfu_branches[stem_idx])

    # 截路空亡
    jielu_branches = ["申", "午", "辰", "寅", "子"]
    kongwang_branches = ["酉", "未", "巳", "卯", "丑"]
    jielu_idx = stem_idx % 5
    result["截路"] = fix_earthly_branch_index(jielu_branches[jielu_idx])
    result["空亡"] = fix_earthly_branch_index(kongwang_branches[jielu_idx])

    # 旬空
    xunkong_idx = fix_index(fix_earthly_branch_index(year_branch) + 9 - stem_idx + 1)
    # Adjust by yinyang
    year_yinyang = EARTHLY_BRANCH_INFO[year_branch]["yinyang"]
    person_yinyang = "阳" if gender == "男" else "阴"
    if person_yinyang == year_yinyang:
        # 阳男阴女 - use as is
        result["旬空"] = xunkong_idx
    else:
        # 阴男阳女 - use the other one (+ 1)
        result["旬空"] = fix_index(xunkong_idx + 1)

    # 天伤/天使
    result["天伤"] = fix_index(PALACES.index("仆役") + soul_index)
    result["天使"] = fix_index(PALACES.index("疾厄") + soul_index)

    # 年解
    nianjie_branches = ["戌", "酉", "申", "未", "午", "巳", "辰", "卯", "寅", "丑", "子", "亥"]
    result["年解"] = fix_earthly_branch_index(nianjie_branches[yb_idx])

    return result


def get_adjective_stars(solar_date, time_index, gender, fix_leap=True):
    """Place 30+ adjective stars."""
    stars = _init_stars()

    indices = {}
    sab = get_stems_and_branches(solar_date, time_index)
    year_branch = sab["yearly"][1]

    indices.update(_get_luan_xi_index(year_branch))
    indices.update(_get_monthly_star_index(solar_date, time_index, fix_leap))
    indices.update(_get_daily_star_index(solar_date, time_index, fix_leap))
    indices.update(_get_timely_star_index(time_index))
    indices.update(_get_yearly_star_index(solar_date, time_index, gender, fix_leap))

    for name, idx in indices.items():
        stars[idx].append({
            "name": name,
            "type": "adjective",
            "brightness": None,
            "mutagen": None,
        })

    return stars


# ---------------------------------------------------------------------------
# 5. get_changsheng12
# ---------------------------------------------------------------------------

def get_changsheng12(solar_date, time_index, gender, fix_leap=True):
    """Place 12 life-stage stars."""
    names = ["长生", "沐浴", "冠带", "临官", "帝旺", "衰", "病", "死", "墓", "绝", "胎", "养"]

    start_info = get_start_index(solar_date, time_index, fix_leap)
    fec = start_info["five_elements_class"]

    start_map = {
        "水二局": "申", "木三局": "亥", "金四局": "巳",
        "土五局": "申", "火六局": "寅",
    }
    start_idx = fix_earthly_branch_index(start_map[fec])

    sab = get_stems_and_branches(solar_date, time_index)
    year_branch = sab["yearly"][1]
    year_yinyang = EARTHLY_BRANCH_INFO[year_branch]["yinyang"]
    person_yinyang = "阳" if gender == "男" else "阴"
    forward = person_yinyang == year_yinyang

    result = [None] * 12
    for i, name in enumerate(names):
        if forward:
            idx = fix_index(start_idx + i)
        else:
            idx = fix_index(start_idx - i)
        result[idx] = name

    return result


# ---------------------------------------------------------------------------
# 6. get_boshi12
# ---------------------------------------------------------------------------

def get_boshi12(solar_date, gender):
    """Place 12 scholar stars starting from 禄存 position."""
    names = ["博士", "力士", "青龙", "小耗", "将军", "奏书", "飞廉", "喜神", "病符", "大耗", "伏兵", "官府"]

    sab = get_stems_and_branches(solar_date, 0)
    year_stem = sab["yearly"][0]
    year_branch = sab["yearly"][1]

    lu_info = _get_lu_yang_tuo_ma_index(year_stem, year_branch)
    start_idx = lu_info["禄存"]

    year_yinyang = EARTHLY_BRANCH_INFO[year_branch]["yinyang"]
    person_yinyang = "阳" if gender == "男" else "阴"
    forward = person_yinyang == year_yinyang

    result = [None] * 12
    for i, name in enumerate(names):
        if forward:
            idx = fix_index(start_idx + i)
        else:
            idx = fix_index(start_idx - i)
        result[idx] = name

    return result


# ---------------------------------------------------------------------------
# 7. get_yearly12
# ---------------------------------------------------------------------------

def get_yearly12(solar_date):
    """Get 岁前12神 and 将前12神."""
    sab = get_stems_and_branches(solar_date, 0)
    year_branch = sab["yearly"][1]

    suiqian_names = ["岁建", "晦气", "丧门", "贯索", "官符", "小耗", "大耗", "龙德", "白虎", "天德", "吊客", "病符"]
    jiangqian_names = ["将星", "攀鞍", "岁驿", "息神", "华盖", "劫煞", "灾煞", "天煞", "指背", "咸池", "月煞", "亡神"]

    # 岁前 starts from year branch index, forward
    suiqian_start = fix_earthly_branch_index(year_branch)
    suiqian = [None] * 12
    for i, name in enumerate(suiqian_names):
        idx = fix_index(suiqian_start + i)
        suiqian[idx] = name

    # 将前 start position by year branch
    jiang_start_map = {
        "寅": "午", "午": "午", "戌": "午",
        "申": "子", "子": "子", "辰": "子",
        "巳": "酉", "酉": "酉", "丑": "酉",
        "亥": "卯", "卯": "卯", "未": "卯",
    }
    jiangqian_start = fix_earthly_branch_index(jiang_start_map[year_branch])
    jiangqian = [None] * 12
    for i, name in enumerate(jiangqian_names):
        idx = fix_index(jiangqian_start + i)
        jiangqian[idx] = name

    return {
        "suiqian12": suiqian,
        "jiangqian12": jiangqian,
    }
