"""CLI output formatting with rich."""

from ziwei.astro import Astrolabe, Palace, Star
from ziwei.utils import fix_index


def _get_surrounded_palaces(palace: Palace, all_palaces: list[Palace]) -> list[str]:
    """Get 三方四正: 对宫 + two 三合宫."""
    idx = palace.index
    indices = [fix_index(idx + 6), fix_index(idx + 4), fix_index(idx + 8)]
    return [f"{all_palaces[i].name}({all_palaces[i].earthly_branch})" for i in indices]


def _format_star(star: Star) -> str:
    parts = [star.name]
    if star.brightness:
        parts.append(star.brightness)
    if star.mutagen:
        parts.append(f"[{star.mutagen}]")
    return " ".join(parts)


def format_astrolabe(astrolabe: Astrolabe, use_color: bool = True) -> str:
    lines = []
    lines.append("=" * 45)
    lines.append("  紫微斗数命盘")
    lines.append(f"  阳历: {astrolabe.solar_date}  农历: {astrolabe.lunar_date}")
    lines.append(f"  干支: {astrolabe.chinese_date}")
    lines.append(f"  性别: {astrolabe.gender}  生肖: {astrolabe.zodiac}  {astrolabe.time_name}")
    lines.append(f"  命主: {astrolabe.soul_star}  身主: {astrolabe.body_star}  五行局: {astrolabe.five_elements_class}")
    lines.append("=" * 45)
    lines.append("")

    # Display from 命宫
    soul_idx = next(i for i, p in enumerate(astrolabe.palaces) if p.name == "命宫")
    palace_order = [(soul_idx + i) % 12 for i in range(12)]

    for pi in palace_order:
        p = astrolabe.palaces[pi]
        name_display = f"{p.name}·身宫" if p.is_body_palace else p.name
        dec_display = f" | 大限 {p.decadal_range[0]}-{p.decadal_range[1]}" if p.decadal_range[0] else ""
        lines.append(f"【{name_display}】{p.earthly_branch} | {p.heavenly_stem}{dec_display}")

        if p.major_stars:
            lines.append(f"  主星: {', '.join(_format_star(s) for s in p.major_stars)}")
        if p.minor_stars:
            lines.append(f"  辅星: {', '.join(_format_star(s) for s in p.minor_stars)}")
        if p.adjective_stars:
            lines.append(f"  杂曜: {', '.join(s.name for s in p.adjective_stars)}")

        surrounded = _get_surrounded_palaces(p, astrolabe.palaces)
        lines.append(f"  三方四正: {', '.join(surrounded)}")
        lines.append("")

    return "\n".join(lines)


def print_astrolabe(astrolabe: Astrolabe, use_color: bool = True):
    if not use_color:
        print(format_astrolabe(astrolabe, use_color=False))
        return
    try:
        from rich.console import Console
        from rich.text import Text
        console = Console()
        text = format_astrolabe(astrolabe, use_color=False)
        rich_text = Text(text)
        rich_text.highlight_regex(r"\[禄\]", style="bold green")
        rich_text.highlight_regex(r"\[权\]", style="bold yellow")
        rich_text.highlight_regex(r"\[科\]", style="bold blue")
        rich_text.highlight_regex(r"\[忌\]", style="bold red")
        rich_text.highlight_regex(r"【[^】]+】", style="bold")
        rich_text.highlight_regex(r"·身宫", style="bold magenta")
        console.print(rich_text)
    except ImportError:
        print(format_astrolabe(astrolabe, use_color=False))
