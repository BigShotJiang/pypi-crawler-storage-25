"""Utility functions for index cycling, brightness and mutagen lookup."""

from ziwei.data.constants import EARTHLY_BRANCHES
from ziwei.data.stars import STARS_INFO, MUTAGEN
from ziwei.data.stems import HEAVENLY_STEM_INFO


def fix_index(index: int, max_val: int = 12) -> int:
    """Normalize index to 0..max_val-1 range."""
    return index % max_val


def fix_earthly_branch_index(branch: str) -> int:
    """Convert earthly branch name to palace index (寅=0, 卯=1, ..., 丑=11)."""
    yin_idx = EARTHLY_BRANCHES.index("寅")
    branch_idx = EARTHLY_BRANCHES.index(branch)
    return fix_index(branch_idx - yin_idx)


def get_brightness(star_name: str, palace_index: int) -> str | None:
    """Get star brightness at a given palace index."""
    info = STARS_INFO.get(star_name)
    if not info:
        return None
    b = info["brightness"][fix_index(palace_index)]
    return b if b else None


def get_mutagen(star_name: str, heavenly_stem: str) -> str | None:
    """Get the 四化 mutation type for a star given a heavenly stem."""
    stem_info = HEAVENLY_STEM_INFO.get(heavenly_stem)
    if not stem_info:
        return None
    mutagen_stars = stem_info["mutagen"]
    if star_name in mutagen_stars:
        return MUTAGEN[mutagen_stars.index(star_name)]
    return None
