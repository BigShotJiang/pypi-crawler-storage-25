# ziwei-cli

紫微斗数命令行排盘工具。

## 安装

```bash
pip install ziwei-cli
```

## 使用

```bash
ziwei --help
```

## 许可证

[AGPL-3.0](LICENSE)
