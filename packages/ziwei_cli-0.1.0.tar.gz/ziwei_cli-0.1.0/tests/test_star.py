from ziwei.star import (
    get_start_index, get_major_stars, get_minor_stars,
    get_adjective_stars, get_changsheng12, get_boshi12, get_yearly12,
)


def test_get_start_index():
    result = get_start_index("2000-8-16", 2)
    assert "ziwei_index" in result
    assert "tianfu_index" in result
    assert result["tianfu_index"] == (12 - result["ziwei_index"]) % 12


def test_get_major_stars():
    stars = get_major_stars("2000-8-16", 2)
    assert len(stars) == 12
    total = sum(len(p) for p in stars)
    assert total == 14
    major_names = {"紫微", "天机", "太阳", "武曲", "天同", "廉贞",
                   "天府", "太阴", "贪狼", "巨门", "天相", "天梁", "七杀", "破军"}
    placed = {s["name"] for p in stars for s in p}
    assert placed == major_names


def test_get_minor_stars():
    stars = get_minor_stars("2000-8-16", 2)
    assert len(stars) == 12
    total = sum(len(p) for p in stars)
    assert total == 14
    minor_names = {"左辅", "右弼", "文昌", "文曲", "天魁", "天钺",
                   "禄存", "天马", "擎羊", "陀罗", "火星", "铃星", "地空", "地劫"}
    placed = {s["name"] for p in stars for s in p}
    assert placed == minor_names


def test_get_adjective_stars():
    stars = get_adjective_stars("2000-8-16", 2, "女")
    assert len(stars) == 12
    total = sum(len(p) for p in stars)
    assert total >= 30
    all_names = {s["name"] for p in stars for s in p}
    assert "红鸾" in all_names
    assert "天喜" in all_names
    assert "华盖" in all_names
    assert "天官" in all_names


def test_get_changsheng12():
    result = get_changsheng12("2000-8-16", 2, "女")
    assert len(result) == 12
    expected = {"长生", "沐浴", "冠带", "临官", "帝旺", "衰", "病", "死", "墓", "绝", "胎", "养"}
    assert set(result) == expected


def test_get_boshi12():
    result = get_boshi12("2000-8-16", "女")
    assert len(result) == 12
    expected = {"博士", "力士", "青龙", "小耗", "将军", "奏书", "飞廉", "喜神", "病符", "大耗", "伏兵", "官府"}
    assert set(result) == expected


def test_get_yearly12():
    result = get_yearly12("2000-8-16")
    assert len(result["suiqian12"]) == 12
    assert len(result["jiangqian12"]) == 12
    assert "岁建" in result["suiqian12"]
    assert "将星" in result["jiangqian12"]
