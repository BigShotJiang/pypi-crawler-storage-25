from ziwei.astro import generate_astrolabe
from ziwei.formatter import format_astrolabe


def test_generate_astrolabe_solar():
    result = generate_astrolabe("2000-8-16", 2, "女")
    assert result.solar_date == "2000-8-16"
    assert result.zodiac == "龙"
    assert result.five_elements_class == "木三局"
    assert result.soul_star == "破军"
    assert result.body_star == "文昌"
    assert len(result.palaces) == 12

    soul_palace = next(p for p in result.palaces if p.name == "命宫")
    assert soul_palace.earthly_branch == "午"
    body_palace = next(p for p in result.palaces if p.is_body_palace)
    assert body_palace.earthly_branch == "戌"


def test_generate_astrolabe_has_mutagen():
    result = generate_astrolabe("2000-8-16", 2, "女")
    all_stars = []
    for p in result.palaces:
        all_stars.extend(p.major_stars)
        all_stars.extend(p.minor_stars)

    taiyang = next(s for s in all_stars if s.name == "太阳")
    assert taiyang.mutagen == "禄"
    wuqu = next(s for s in all_stars if s.name == "武曲")
    assert wuqu.mutagen == "权"


def test_generate_astrolabe_lunar():
    result = generate_astrolabe("2000-7-17", 2, "女", is_lunar=True)
    assert result.five_elements_class == "木三局"
    assert result.zodiac == "龙"


def test_format_output_contains_key_elements():
    astrolabe = generate_astrolabe("2000-8-16", 2, "女")
    output = format_astrolabe(astrolabe, use_color=False)
    assert "紫微斗数命盘" in output
    assert "2000-8-16" in output
    assert "龙" in output
    assert "木三局" in output
    assert "命宫" in output
    assert "三方四正" in output
    assert "[禄]" in output
    assert "身宫" in output
