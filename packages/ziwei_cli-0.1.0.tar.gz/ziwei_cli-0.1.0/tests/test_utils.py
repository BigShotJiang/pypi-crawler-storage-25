from ziwei.utils import fix_index, fix_earthly_branch_index, get_brightness, get_mutagen


def test_fix_index_normal():
    assert fix_index(0) == 0
    assert fix_index(11) == 11


def test_fix_index_overflow():
    assert fix_index(12) == 0
    assert fix_index(13) == 1
    assert fix_index(24) == 0


def test_fix_index_negative():
    assert fix_index(-1) == 11
    assert fix_index(-12) == 0
    assert fix_index(-13) == 11


def test_fix_index_custom_max():
    assert fix_index(10, max_val=10) == 0
    assert fix_index(-1, max_val=10) == 9


def test_fix_earthly_branch_index():
    assert fix_earthly_branch_index("寅") == 0
    assert fix_earthly_branch_index("卯") == 1
    assert fix_earthly_branch_index("子") == 10
    assert fix_earthly_branch_index("丑") == 11


def test_get_brightness():
    assert get_brightness("紫微", 0) == "旺"
    assert get_brightness("紫微", 4) == "庙"
    assert get_brightness("天空", 0) is None


def test_get_mutagen():
    assert get_mutagen("廉贞", "甲") == "禄"
    assert get_mutagen("破军", "甲") == "权"
    assert get_mutagen("武曲", "甲") == "科"
    assert get_mutagen("太阳", "甲") == "忌"
    assert get_mutagen("紫微", "甲") is None
