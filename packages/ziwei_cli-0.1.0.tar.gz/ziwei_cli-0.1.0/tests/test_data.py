from ziwei.data.constants import (
    HEAVENLY_STEMS, EARTHLY_BRANCHES, PALACES, CHINESE_TIME,
    TIME_RANGE, TIGER_RULE, RAT_RULE, ZODIAC,
)
from ziwei.data.stems import HEAVENLY_STEM_INFO, EARTHLY_BRANCH_INFO
from ziwei.data.stars import STARS_INFO, MUTAGEN


def test_heavenly_stems():
    assert len(HEAVENLY_STEMS) == 10
    assert HEAVENLY_STEMS[0] == "甲"
    assert HEAVENLY_STEMS[9] == "癸"


def test_earthly_branches():
    assert len(EARTHLY_BRANCHES) == 12
    assert EARTHLY_BRANCHES[0] == "子"
    assert EARTHLY_BRANCHES[11] == "亥"


def test_palaces():
    assert len(PALACES) == 12
    assert PALACES[0] == "命宫"


def test_tiger_rule():
    assert TIGER_RULE["甲"] == "丙"
    assert TIGER_RULE["乙"] == "戊"
    assert TIGER_RULE["壬"] == "壬"


def test_rat_rule():
    assert RAT_RULE["甲"] == "甲"
    assert RAT_RULE["乙"] == "丙"


def test_mutagen_table():
    assert HEAVENLY_STEM_INFO["甲"]["mutagen"] == ["廉贞", "破军", "武曲", "太阳"]
    assert HEAVENLY_STEM_INFO["庚"]["mutagen"] == ["太阳", "武曲", "太阴", "天同"]


def test_stars_info():
    assert len(STARS_INFO["紫微"]["brightness"]) == 12
    assert STARS_INFO["紫微"]["brightness"][0] == "旺"


def test_mutagen_names():
    assert MUTAGEN == ["禄", "权", "科", "忌"]


def test_zodiac():
    assert len(ZODIAC) == 12
    assert ZODIAC[0] == "鼠"
    assert ZODIAC[4] == "龙"


def test_earthly_branch_info():
    assert EARTHLY_BRANCH_INFO["子"]["soul"] == "贪狼"
    assert EARTHLY_BRANCH_INFO["子"]["body"] == "火星"
