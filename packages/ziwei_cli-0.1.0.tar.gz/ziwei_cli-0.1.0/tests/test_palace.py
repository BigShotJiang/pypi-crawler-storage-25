from ziwei.palace import get_soul_and_body, get_five_elements_class, get_palace_names, get_horoscope


def test_get_soul_and_body():
    result = get_soul_and_body("2000-8-16", 2)
    assert result["soul_branch"] == "午"
    assert result["body_branch"] == "戌"


def test_get_five_elements_class():
    result = get_soul_and_body("2000-8-16", 2)
    fec = get_five_elements_class(result["soul_stem"], result["soul_branch"])
    assert fec == "木三局"


def test_get_palace_names():
    result = get_soul_and_body("2000-8-16", 2)
    names = get_palace_names(result["soul_index"])
    assert len(names) == 12
    assert names[result["soul_index"]] == "命宫"


def test_get_horoscope():
    result = get_soul_and_body("2000-8-16", 2)
    fec = get_five_elements_class(result["soul_stem"], result["soul_branch"])
    horoscope = get_horoscope("2000-8-16", 2, "女", result["soul_index"], fec)
    assert len(horoscope) == 12
    for h in horoscope:
        assert h is not None
        assert len(h["range"]) == 2
        assert h["range"][1] - h["range"][0] == 9
