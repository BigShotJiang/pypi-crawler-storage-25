"""Tests for calendar_utils module."""

import pytest

from ziwei.calendar_utils import (
    get_lunar_month_days,
    get_stems_and_branches,
    get_zodiac,
    lunar_to_solar,
    solar_to_lunar,
    time_name_to_index,
)


def test_solar_to_lunar():
    result = solar_to_lunar("2000-8-16")
    assert result["year"] == 2000
    assert result["month"] == 7
    assert result["day"] == 17
    assert result["is_leap"] is False


def test_lunar_to_solar():
    result = lunar_to_solar(2000, 7, 17, is_leap=False)
    assert result == "2000-8-16"


def test_get_stems_and_branches():
    result = get_stems_and_branches("2000-8-16", 2)
    assert result["yearly"] == ("庚", "辰")
    assert result["monthly"] == ("甲", "申")
    assert result["daily"] == ("丙", "午")
    assert result["hourly"] == ("庚", "寅")


def test_get_zodiac():
    assert get_zodiac("2000-8-16") == "龙"


def test_get_lunar_month_days():
    # 农历庚辰年七月 has 29 days
    days = get_lunar_month_days("2000-8-16")
    assert days in (29, 30)  # valid lunar month length


def test_time_name_to_index():
    assert time_name_to_index("寅") == 2
    assert time_name_to_index("子") == 0
    assert time_name_to_index("丑") == 1
    assert time_name_to_index("寅时") == 2
    assert time_name_to_index("2") == 2


def test_time_name_to_index_all_branches():
    branches = ["子", "丑", "寅", "卯", "辰", "巳", "午", "未", "申", "酉", "戌", "亥"]
    for i, branch in enumerate(branches):
        assert time_name_to_index(branch) == i
        assert time_name_to_index(branch + "时") == i
        assert time_name_to_index(str(i)) == i


def test_time_name_to_index_invalid():
    with pytest.raises(ValueError):
        time_name_to_index("unknown")
