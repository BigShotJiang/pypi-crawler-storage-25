"""Symlink-aware path validation."""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .exceptions import PathValidationError
from .validators import GuardOutcome, ValidatorResult

ReturnType = Literal["preserve", "str", "path"]


def _normalize_extensions(values: list[str]) -> list[str]:
    return [value.lower() if value.startswith(".") else f".{value.lower()}" for value in values]


def canonicalize_path(path: str | os.PathLike[str], *, root: str | Path) -> Path:
    """Resolve a user path against a root while following existing symlinks."""

    root_path = Path(root).expanduser().resolve(strict=False)
    if os.name != "nt" and isinstance(path, str):
        if re.match(r"^[A-Za-z]:[\\/]", path) or path.startswith("\\\\"):
            raise PathValidationError("Windows-style absolute paths are not valid on this platform")
    candidate = Path(path).expanduser()
    if not candidate.is_absolute():
        candidate = root_path / candidate
    return candidate.resolve(strict=False)


def is_relative_to(child: Path, parent: Path) -> bool:
    """Python 3.10 compatible Path.is_relative_to wrapper."""

    try:
        child.relative_to(parent)
        return True
    except ValueError:
        return False


class PathGuard(BaseModel):
    """Constrain path arguments to an explicit root and access mode."""

    model_config = ConfigDict(extra="forbid")

    root: str | Path
    read: bool = False
    write: bool = False
    allowed_extensions: list[str] = Field(default_factory=list)
    denied_extensions: list[str] = Field(default_factory=list)
    must_exist: bool | None = None
    return_type: ReturnType = "preserve"

    @field_validator("allowed_extensions", "denied_extensions")
    @classmethod
    def _extensions_with_dot(cls, value: list[str]) -> list[str]:
        return _normalize_extensions(value)

    @property
    def resolved_root(self) -> Path:
        return Path(self.root).expanduser().resolve(strict=False)

    def validate_value(
        self, value: Any, *, field: str, mode: Literal["read", "write"] | None = None
    ) -> GuardOutcome:
        if not isinstance(value, (str, os.PathLike)):
            raise PathValidationError(f"{field} must be a filesystem path")

        requested_mode = mode or ("read" if self.read else "write")
        if requested_mode == "read" and not self.read:
            raise PathValidationError(f"{field} is not allowed for read access")
        if requested_mode == "write" and not self.write:
            raise PathValidationError(f"{field} is not allowed for write access")

        root = self.resolved_root
        resolved = canonicalize_path(value, root=root)
        if not is_relative_to(resolved, root):
            raise PathValidationError(f"{field} escapes configured root")

        suffix = resolved.suffix.lower()
        if self.allowed_extensions and suffix not in self.allowed_extensions:
            raise PathValidationError(f"{field} extension is not allowed")
        if self.denied_extensions and suffix in self.denied_extensions:
            raise PathValidationError(f"{field} extension is denied")

        must_exist = self.must_exist if self.must_exist is not None else requested_mode == "read"
        if must_exist and not resolved.exists():
            raise PathValidationError(f"{field} does not exist")
        if requested_mode == "read" and resolved.exists() and not resolved.is_file():
            raise PathValidationError(f"{field} is not a file")
        if requested_mode == "write":
            parent = resolved.parent.resolve(strict=False)
            if not is_relative_to(parent, root):
                raise PathValidationError(f"{field} parent escapes configured root")

        output: Any
        if self.return_type == "str" or (self.return_type == "preserve" and isinstance(value, str)):
            output = str(resolved)
        elif self.return_type == "path" or isinstance(value, os.PathLike):
            output = resolved
        else:
            output = str(resolved)

        return GuardOutcome(
            value=output,
            result=ValidatorResult(
                field=field,
                validator="PathGuard",
                allowed=True,
                reason="path accepted",
                metadata={
                    "root": str(root),
                    "mode": requested_mode,
                    "extension": suffix,
                },
            ),
        )
