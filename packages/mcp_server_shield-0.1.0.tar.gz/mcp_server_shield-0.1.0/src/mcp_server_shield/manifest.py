"""Lockfile generation and verification for MCP tool descriptors."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, ConfigDict, Field

from .exceptions import ManifestVerificationError

LOCKFILE_NAME = "mcp-shield.lock.json"


class ToolDescriptor(BaseModel):
    """Stable descriptor fields included in manifest hashes."""

    model_config = ConfigDict(extra="allow")

    name: str
    description: str = ""
    input_schema: dict[str, Any] = Field(default_factory=dict)
    annotations: dict[str, Any] = Field(default_factory=dict)
    policy_id: str = "unknown"


class ManifestEntry(BaseModel):
    """One locked descriptor hash."""

    model_config = ConfigDict(extra="forbid")

    name_hash: str
    descriptor_hash: str
    policy_id: str


class ShieldManifest(BaseModel):
    """Contents of ``mcp-shield.lock.json``."""

    model_config = ConfigDict(extra="forbid")

    version: int = 1
    generated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    entries: dict[str, ManifestEntry]


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_json(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def descriptor_payload(descriptor: ToolDescriptor) -> dict[str, Any]:
    return {
        "name": descriptor.name,
        "description": descriptor.description,
        "input_schema": descriptor.input_schema,
        "annotations": descriptor.annotations,
        "policy_id": descriptor.policy_id,
    }


def generate_manifest(descriptors: list[ToolDescriptor]) -> ShieldManifest:
    """Generate a deterministic manifest from tool descriptors."""

    entries: dict[str, ManifestEntry] = {}
    for descriptor in sorted(descriptors, key=lambda item: item.name):
        payload = descriptor_payload(descriptor)
        entries[descriptor.name] = ManifestEntry(
            name_hash=sha256_json({"name": descriptor.name}),
            descriptor_hash=sha256_json(payload),
            policy_id=descriptor.policy_id,
        )
    return ShieldManifest(entries=entries)


def verify_manifest(descriptors: list[ToolDescriptor], manifest: ShieldManifest) -> None:
    """Raise if descriptors have drifted from the lockfile."""

    current = generate_manifest(descriptors)
    errors: list[str] = []

    locked_names = set(manifest.entries)
    current_names = set(current.entries)
    for missing in sorted(locked_names - current_names):
        errors.append(f"missing tool: {missing}")
    for added in sorted(current_names - locked_names):
        errors.append(f"new tool: {added}")
    for name in sorted(locked_names & current_names):
        locked = manifest.entries[name]
        actual = current.entries[name]
        if locked.descriptor_hash != actual.descriptor_hash:
            if locked.policy_id != actual.policy_id:
                errors.append(f"policy drift: {name}")
            else:
                errors.append(f"descriptor drift: {name}")

    if errors:
        raise ManifestVerificationError("; ".join(errors))


def load_descriptors(path: str | Path) -> list[ToolDescriptor]:
    """Load descriptors from a JSON or YAML file."""

    source = Path(path)
    raw = source.read_text(encoding="utf-8")
    if source.suffix.lower() in {".yaml", ".yml"}:
        data = yaml.safe_load(raw)
    else:
        data = json.loads(raw)

    tools = data.get("tools") if isinstance(data, dict) else data
    if not isinstance(tools, list):
        raise ManifestVerificationError("descriptor file must contain a tool list")
    return [ToolDescriptor(**tool) for tool in tools]


def write_manifest(manifest: ShieldManifest, path: str | Path = LOCKFILE_NAME) -> None:
    Path(path).write_text(
        json.dumps(manifest.model_dump(), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def read_manifest(path: str | Path = LOCKFILE_NAME) -> ShieldManifest:
    return ShieldManifest(**json.loads(Path(path).read_text(encoding="utf-8")))
