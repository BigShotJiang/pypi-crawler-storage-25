"""General-purpose input validators for MCP tool arguments."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, ConfigDict, Field

from .exceptions import StringValidationError

if TYPE_CHECKING:
    from .paths import PathGuard
    from .urls import URLGuard


class ValidatorResult(BaseModel):
    """Sanitized validator outcome suitable for audit logs."""

    model_config = ConfigDict(extra="forbid")

    field: str
    validator: str
    allowed: bool
    reason: str
    metadata: dict[str, Any] = Field(default_factory=dict)
    waiver_id: str | None = None


class GuardOutcome(BaseModel):
    """Internal result returned by guards."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    value: Any
    result: ValidatorResult


class StringGuard(BaseModel):
    """Validate untrusted string arguments before tool execution."""

    model_config = ConfigDict(extra="forbid")

    max_len: int | None = None
    min_len: int | None = None
    deny_substrings: list[str] = Field(default_factory=list)
    allow_pattern: str | None = None
    deny_pattern: str | None = None
    strip: bool = False
    case_sensitive: bool = False

    def validate_value(self, value: Any, *, field: str) -> GuardOutcome:
        if not isinstance(value, str):
            raise StringValidationError(f"{field} must be a string")

        candidate = value.strip() if self.strip else value
        length = len(candidate)
        metadata: dict[str, Any] = {"length": length}

        if self.max_len is not None and length > self.max_len:
            raise StringValidationError(f"{field} exceeds maximum length")
        if self.min_len is not None and length < self.min_len:
            raise StringValidationError(f"{field} is shorter than minimum length")

        haystack = candidate if self.case_sensitive else candidate.lower()
        for denied in self.deny_substrings:
            needle = denied if self.case_sensitive else denied.lower()
            if needle in haystack:
                raise StringValidationError(f"{field} contains a denied phrase")

        flags = 0 if self.case_sensitive else re.IGNORECASE
        if self.allow_pattern and re.fullmatch(self.allow_pattern, candidate, flags=flags) is None:
            raise StringValidationError(f"{field} does not match allowed pattern")
        if self.deny_pattern and re.search(self.deny_pattern, candidate, flags=flags):
            raise StringValidationError(f"{field} matches denied pattern")

        return GuardOutcome(
            value=candidate,
            result=ValidatorResult(
                field=field,
                validator="StringGuard",
                allowed=True,
                reason="string accepted",
                metadata=metadata,
            ),
        )


def __getattr__(name: str) -> Any:
    """Lazy re-exports to support ``from mcp_server_shield.validators import PathGuard``."""

    if name == "PathGuard":
        from .paths import PathGuard

        return PathGuard
    if name == "URLGuard":
        from .urls import URLGuard

        return URLGuard
    raise AttributeError(name)


__all__ = ["GuardOutcome", "StringGuard", "ValidatorResult", "PathGuard", "URLGuard"]
