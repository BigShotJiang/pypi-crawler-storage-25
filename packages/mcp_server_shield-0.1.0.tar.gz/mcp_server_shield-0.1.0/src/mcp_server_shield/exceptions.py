"""Typed exceptions raised by mcp-server-shield."""

from __future__ import annotations


class ShieldError(Exception):
    """Base class for all public mcp-server-shield exceptions."""


class PolicyError(ShieldError):
    """Raised when a policy is malformed or cannot be applied safely."""


class PolicyLoadError(PolicyError):
    """Raised when a YAML or JSON policy file cannot be loaded."""


class WaiverError(PolicyError):
    """Raised for invalid, expired, or unsafe waivers."""


class WaiverExpiredError(WaiverError):
    """Raised when a configured waiver is past its expiry date."""


class ShieldValidationError(ShieldError):
    """Raised when an input guard denies a tool call."""


class PathValidationError(ShieldValidationError):
    """Raised when a path argument violates its guard."""


class URLValidationError(ShieldValidationError):
    """Raised when a URL argument violates its guard."""


class StringValidationError(ShieldValidationError):
    """Raised when a string argument violates its guard."""


class CommandPolicyError(ShieldValidationError):
    """Raised when a subprocess invocation violates command policy."""


class CommandExecutionError(ShieldError):
    """Raised when a safe subprocess execution fails."""


class OutputBlockedError(ShieldError):
    """Raised when an output filter blocks a tool response."""


class DescriptionLintError(ShieldError):
    """Raised when tool description linting cannot complete."""


class ManifestVerificationError(ShieldError):
    """Raised when a manifest lockfile does not match current descriptors."""
