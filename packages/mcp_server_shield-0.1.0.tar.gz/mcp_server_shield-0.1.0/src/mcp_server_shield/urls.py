"""SSRF-aware URL validation."""

from __future__ import annotations

import ipaddress
import socket
from typing import Any
from urllib.parse import urlsplit, urlunsplit

from pydantic import BaseModel, ConfigDict, Field

from .exceptions import URLValidationError
from .validators import GuardOutcome, ValidatorResult


def _host_matches(host: str, allowed: str) -> bool:
    host = host.lower().rstrip(".")
    allowed = allowed.lower().rstrip(".")
    if allowed.startswith("*."):
        suffix = allowed[1:]
        return host.endswith(suffix) and host != allowed[2:]
    return host == allowed


def _is_local_name(host: str) -> bool:
    normalized = host.lower().rstrip(".")
    return normalized in {"localhost", "localhost.localdomain"} or normalized.endswith(".localhost")


def _parse_ip(host: str) -> ipaddress.IPv4Address | ipaddress.IPv6Address | None:
    try:
        return ipaddress.ip_address(host.strip("[]"))
    except ValueError:
        return None


def _is_blocked_ip(address: ipaddress.IPv4Address | ipaddress.IPv6Address) -> bool:
    return not address.is_global


class URLGuard(BaseModel):
    """Validate outbound URLs before network-capable tools use them."""

    model_config = ConfigDict(extra="forbid")

    allowed_schemes: list[str] = Field(default_factory=lambda: ["https"])
    allowed_hosts: list[str] = Field(default_factory=list)
    allow_localhost: bool = False
    allow_private_ips: bool = False
    resolve_dns: bool = True
    require_host: bool = True

    def validate_value(self, value: Any, *, field: str) -> GuardOutcome:
        if not isinstance(value, str):
            raise URLValidationError(f"{field} must be a URL string")

        parsed = urlsplit(value)
        scheme = parsed.scheme.lower()
        if scheme not in {item.lower() for item in self.allowed_schemes}:
            raise URLValidationError(f"{field} uses a denied URL scheme")
        if parsed.username or parsed.password:
            raise URLValidationError(f"{field} must not contain embedded credentials")
        if self.require_host and not parsed.hostname:
            raise URLValidationError(f"{field} must include a host")

        host = (parsed.hostname or "").lower()
        if self.allowed_hosts and not any(
            _host_matches(host, allowed) for allowed in self.allowed_hosts
        ):
            raise URLValidationError(f"{field} host is not in the allowlist")

        if _is_local_name(host) and not self.allow_localhost:
            raise URLValidationError(f"{field} points to localhost")

        direct_ip = _parse_ip(host)
        if direct_ip is not None:
            self._check_ip(direct_ip, field=field)
        elif self.resolve_dns:
            self._check_dns(host, parsed.port, field=field)

        normalized = urlunsplit(
            (scheme, parsed.netloc, parsed.path or "/", parsed.query, parsed.fragment)
        )
        return GuardOutcome(
            value=normalized,
            result=ValidatorResult(
                field=field,
                validator="URLGuard",
                allowed=True,
                reason="url accepted",
                metadata={"scheme": scheme, "host": host},
            ),
        )

    def _check_ip(
        self, address: ipaddress.IPv4Address | ipaddress.IPv6Address, *, field: str
    ) -> None:
        if address.is_loopback and not self.allow_localhost:
            raise URLValidationError(f"{field} resolves to localhost")
        if _is_blocked_ip(address) and not self.allow_private_ips:
            raise URLValidationError(f"{field} resolves to a non-public IP address")

    def _check_dns(self, host: str, port: int | None, *, field: str) -> None:
        try:
            answers = socket.getaddrinfo(host, port or 443, type=socket.SOCK_STREAM)
        except socket.gaierror as exc:
            raise URLValidationError(f"{field} host could not be resolved") from exc

        seen: set[str] = set()
        for answer in answers:
            address_text = str(answer[4][0])
            if address_text in seen:
                continue
            seen.add(address_text)
            self._check_ip(ipaddress.ip_address(address_text), field=field)
