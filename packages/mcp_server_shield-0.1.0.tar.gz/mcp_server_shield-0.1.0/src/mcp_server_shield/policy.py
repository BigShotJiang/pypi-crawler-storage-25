"""Pydantic policy model and policy-file loading."""

from __future__ import annotations

import json
from datetime import date
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator

from .audit import AuditSink, JSONLAuditSink
from .exceptions import PolicyLoadError, WaiverExpiredError
from .output_filters import PromptInjectionFilter, SecretRedactor
from .paths import PathGuard
from .urls import URLGuard
from .validators import StringGuard


class Waiver(BaseModel):
    """Explicit, expiring waiver for a named control or field."""

    model_config = ConfigDict(extra="forbid")

    id: str
    reason: str
    expires_on: date
    evidence: dict[str, str]
    applies_to: list[str] = Field(default_factory=lambda: ["*"])

    @field_validator("reason")
    @classmethod
    def _reason_required(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("waiver reason is required")
        return value

    @field_validator("evidence")
    @classmethod
    def _evidence_required(cls, value: dict[str, str]) -> dict[str, str]:
        if not value:
            raise ValueError("waiver evidence is required")
        return value

    def is_active(self, today: date | None = None) -> bool:
        return (today or date.today()) <= self.expires_on

    def applies(self, *, field: str, validator: str) -> bool:
        targets = {"*", field, validator, f"{validator}:{field}", f"{field}:{validator}"}
        return any(target in targets for target in self.applies_to)


class ShieldPolicy(BaseModel):
    """Policy object consumed by the ``@shield`` decorator."""

    model_config = ConfigDict(arbitrary_types_allowed=True, extra="forbid")

    policy_id: str = "strict"
    paths: dict[str, PathGuard] = Field(default_factory=dict)
    urls: dict[str, URLGuard] = Field(default_factory=dict)
    strings: dict[str, StringGuard] = Field(default_factory=dict)
    output_filters: list[Any] = Field(default_factory=list)
    waivers: list[Waiver] = Field(default_factory=list)
    audit_sink: Any = Field(default_factory=JSONLAuditSink)
    fail_closed: bool = True

    @classmethod
    def strict(
        cls,
        *,
        paths: dict[str, PathGuard] | None = None,
        urls: dict[str, URLGuard] | None = None,
        strings: dict[str, StringGuard] | None = None,
        output_filters: list[Any] | None = None,
        waivers: list[Waiver] | None = None,
        audit_sink: AuditSink | None = None,
        policy_id: str = "strict",
    ) -> ShieldPolicy:
        """Create a fail-closed policy with explicit controls."""

        return cls(
            policy_id=policy_id,
            paths=paths or {},
            urls=urls or {},
            strings=strings or {},
            output_filters=output_filters or [],
            waivers=waivers or [],
            audit_sink=audit_sink or JSONLAuditSink(),
            fail_closed=True,
        )

    @classmethod
    def permissive_for_tests(cls, *, audit_sink: AuditSink | None = None) -> ShieldPolicy:
        """Create a policy intended only for local tests."""

        return cls(
            policy_id="permissive-tests",
            audit_sink=audit_sink or JSONLAuditSink("mcp-shield-test-audit.jsonl"),
            fail_closed=False,
        )

    @classmethod
    def from_file(cls, path: str | Path, *, audit_sink: AuditSink | None = None) -> ShieldPolicy:
        """Load a policy from YAML or JSON."""

        policy_path = Path(path)
        try:
            raw = policy_path.read_text(encoding="utf-8")
            if policy_path.suffix.lower() in {".yaml", ".yml"}:
                data = yaml.safe_load(raw)
            elif policy_path.suffix.lower() == ".json":
                data = json.loads(raw)
            else:
                raise PolicyLoadError("policy files must be .json, .yaml, or .yml")
        except (OSError, json.JSONDecodeError, yaml.YAMLError) as exc:
            raise PolicyLoadError(f"could not load policy file {policy_path}") from exc

        if not isinstance(data, dict):
            raise PolicyLoadError("policy file must contain an object")
        return cls.from_mapping(data, audit_sink=audit_sink)

    @classmethod
    def from_mapping(
        cls, data: dict[str, Any], *, audit_sink: AuditSink | None = None
    ) -> ShieldPolicy:
        filters: list[Any] = []
        for item in data.get("output_filters", []):
            if not isinstance(item, dict):
                raise PolicyLoadError("output_filters entries must be objects")
            filter_type = str(item.get("type", "")).lower()
            config = {key: value for key, value in item.items() if key != "type"}
            if filter_type in {"secret_redactor", "secrets", "secretredactor"}:
                filters.append(SecretRedactor(**config))
            elif filter_type in {"prompt_injection", "promptinjectionfilter"}:
                filters.append(PromptInjectionFilter(**config))
            else:
                raise PolicyLoadError(f"unknown output filter type {filter_type!r}")

        return cls(
            policy_id=data.get("policy_id", "file-policy"),
            paths={key: PathGuard(**value) for key, value in data.get("paths", {}).items()},
            urls={key: URLGuard(**value) for key, value in data.get("urls", {}).items()},
            strings={key: StringGuard(**value) for key, value in data.get("strings", {}).items()},
            output_filters=filters,
            waivers=[Waiver(**item) for item in data.get("waivers", [])],
            audit_sink=audit_sink
            or JSONLAuditSink(data.get("audit_log", "mcp-shield-audit.jsonl")),
            fail_closed=bool(data.get("fail_closed", True)),
        )

    def active_waiver(self, *, field: str, validator: str) -> Waiver | None:
        expired: list[str] = []
        for waiver in self.waivers:
            if not waiver.applies(field=field, validator=validator):
                continue
            if waiver.is_active():
                return waiver
            expired.append(waiver.id)
        if expired and self.fail_closed:
            raise WaiverExpiredError(f"expired waiver(s): {', '.join(expired)}")
        return None

    def check(self) -> None:
        """Validate policy safety invariants."""

        for waiver in self.waivers:
            if not waiver.is_active():
                raise WaiverExpiredError(
                    f"waiver {waiver.id!r} expired on {waiver.expires_on.isoformat()}"
                )
