"""Python-first hardening primitives for MCP server authors."""

from __future__ import annotations

from .audit import AuditEvent, JSONLAuditSink, MemoryAuditSink, NullAuditSink
from .decorators import shield
from .exceptions import (
    CommandExecutionError,
    CommandPolicyError,
    DescriptionLintError,
    ManifestVerificationError,
    OutputBlockedError,
    PathValidationError,
    PolicyError,
    PolicyLoadError,
    ShieldError,
    ShieldValidationError,
    StringValidationError,
    URLValidationError,
    WaiverError,
    WaiverExpiredError,
)
from .output_filters import PromptInjectionFilter, SecretRedactor
from .policy import ShieldPolicy, Waiver

__all__ = [
    "AuditEvent",
    "CommandExecutionError",
    "CommandPolicyError",
    "DescriptionLintError",
    "JSONLAuditSink",
    "ManifestVerificationError",
    "MemoryAuditSink",
    "NullAuditSink",
    "OutputBlockedError",
    "PathValidationError",
    "PolicyError",
    "PolicyLoadError",
    "PromptInjectionFilter",
    "SecretRedactor",
    "ShieldError",
    "ShieldPolicy",
    "ShieldValidationError",
    "StringValidationError",
    "URLValidationError",
    "Waiver",
    "WaiverError",
    "WaiverExpiredError",
    "shield",
]
