"""Structured audit events and sinks."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal, Protocol

from pydantic import BaseModel, ConfigDict, Field

Decision = Literal["allowed", "denied", "redacted", "errored"]


class AuditEvent(BaseModel):
    """A single shield decision, safe to persist as JSON."""

    model_config = ConfigDict(extra="forbid")

    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    tool_name: str
    decision: Decision
    policy_id: str
    validator_results: list[dict[str, Any]] = Field(default_factory=list)
    redaction_counts: dict[str, int] = Field(default_factory=dict)
    waiver_id: str | None = None
    duration_ms: float
    exception_type: str | None = None


class AuditSink(Protocol):
    """Protocol implemented by audit sinks."""

    def emit(self, event: AuditEvent) -> None:
        """Persist or export an audit event."""


class NullAuditSink:
    """Audit sink for tests or embedding environments that collect events themselves."""

    def emit(self, event: AuditEvent) -> None:
        _ = event


class MemoryAuditSink:
    """In-memory audit sink useful for tests and examples."""

    def __init__(self) -> None:
        self.events: list[AuditEvent] = []

    def emit(self, event: AuditEvent) -> None:
        self.events.append(event)


class JSONLAuditSink:
    """Append-only JSONL audit sink.

    The event model intentionally does not include raw arguments or raw exception
    messages, which keeps accidental secrets out of the audit stream.
    """

    def __init__(self, path: str | Path = "mcp-shield-audit.jsonl") -> None:
        self.path = Path(path)

    def emit(self, event: AuditEvent) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(event.model_dump(), sort_keys=True) + "\n")


class OpenTelemetryAuditSink:
    """Optional OpenTelemetry exporter interface.

    This class imports OpenTelemetry lazily so the base package has no OTel
    dependency. Install with ``mcp-server-shield[otel]`` to use it.
    """

    def __init__(self, event_name: str = "mcp_server_shield.audit") -> None:
        self.event_name = event_name

    def emit(self, event: AuditEvent) -> None:
        try:
            from opentelemetry import trace
        except ImportError as exc:  # pragma: no cover - exercised only without optional extra
            raise RuntimeError("Install mcp-server-shield[otel] to use OpenTelemetry") from exc

        tracer = trace.get_tracer("mcp_server_shield")
        with tracer.start_as_current_span(self.event_name) as span:
            for key, value in event.model_dump().items():
                if isinstance(value, (str, int, float, bool)) or value is None:
                    span.set_attribute(key, "" if value is None else value)
                else:
                    span.set_attribute(key, json.dumps(value, sort_keys=True))
