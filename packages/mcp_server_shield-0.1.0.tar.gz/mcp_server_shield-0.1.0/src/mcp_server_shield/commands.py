"""Safe subprocess execution helpers for MCP tools."""

from __future__ import annotations

import os
import shutil
import subprocess
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from .exceptions import CommandExecutionError, CommandPolicyError
from .paths import is_relative_to


class CommandPolicy(BaseModel):
    """Policy for argv-only subprocess execution."""

    model_config = ConfigDict(arbitrary_types_allowed=True, extra="forbid")

    allowed_executables: list[str] = Field(default_factory=list)
    cwd_root: str | Path | None = None
    env_allowlist: list[str] = Field(default_factory=lambda: ["PATH", "SystemRoot", "WINDIR"])
    timeout: float | None = 30
    user_args_start: int | None = None
    insert_separator: bool = False
    reject_flag_args: bool = False


def _validate_argv(argv: Sequence[str]) -> list[str]:
    if isinstance(argv, (str, bytes)):
        raise CommandPolicyError("safe_run requires argv as a list of strings, not a shell string")
    if not argv:
        raise CommandPolicyError("safe_run requires at least one argv element")
    output = list(argv)
    if not all(isinstance(part, str) and part for part in output):
        raise CommandPolicyError("safe_run argv elements must be non-empty strings")
    return output


def _resolve_executable(executable: str, allowed: list[str]) -> str:
    if not allowed:
        raise CommandPolicyError("allowed_executables must be explicit")

    executable_path = Path(executable)
    executable_name = executable_path.name.lower()
    normalized_allowed = set()
    for item in allowed:
        normalized_allowed.add(item.lower())
        item_path = Path(item)
        if item_path.is_absolute():
            normalized_allowed.add(str(item_path.resolve(strict=False)).lower())
    allowed_names = {Path(item).name.lower() for item in allowed}

    if executable.lower() not in normalized_allowed and executable_name not in allowed_names:
        raise CommandPolicyError("executable is not allowlisted")

    if executable_path.is_absolute():
        resolved = executable_path.resolve(strict=False)
        if (
            str(resolved).lower() not in normalized_allowed
            and resolved.name.lower() not in allowed_names
        ):
            raise CommandPolicyError("resolved executable is not allowlisted")
        return str(resolved)

    found = shutil.which(executable)
    if found is None:
        raise CommandPolicyError("allowlisted executable was not found on PATH")
    return found


def _apply_user_arg_policy(argv: list[str], policy: CommandPolicy) -> list[str]:
    if policy.user_args_start is None:
        return argv
    if policy.user_args_start < 0 or policy.user_args_start > len(argv):
        raise CommandPolicyError("user_args_start is outside argv bounds")

    before = argv[: policy.user_args_start]
    user_args = argv[policy.user_args_start :]

    if policy.reject_flag_args:
        for arg in user_args:
            if arg.startswith("-") and arg != "-":
                raise CommandPolicyError(
                    "flag-like user argument rejected by positional-only policy"
                )

    if policy.insert_separator and "--" not in before:
        return before + ["--"] + user_args
    return argv


def _build_env(env: dict[str, str] | None, allowlist: list[str]) -> dict[str, str]:
    allowed = set(allowlist)
    output: dict[str, str] = {}
    for key in allowed:
        if key in os.environ:
            output[key] = os.environ[key]
    if env:
        for key, value in env.items():
            if key not in allowed:
                raise CommandPolicyError(f"environment variable {key!r} is not allowlisted")
            output[key] = value
    return output


def _validate_cwd(cwd: str | Path | None, cwd_root: str | Path | None) -> str | None:
    if cwd is None:
        return None
    resolved = Path(cwd).expanduser().resolve(strict=False)
    if cwd_root is not None:
        root = Path(cwd_root).expanduser().resolve(strict=False)
        if not is_relative_to(resolved, root):
            raise CommandPolicyError("working directory escapes configured root")
    if not resolved.exists() or not resolved.is_dir():
        raise CommandPolicyError("working directory must exist and be a directory")
    return str(resolved)


def safe_run(
    argv: Sequence[str],
    *,
    policy: CommandPolicy | None = None,
    allowed_executables: list[str] | None = None,
    cwd: str | Path | None = None,
    cwd_root: str | Path | None = None,
    env: dict[str, str] | None = None,
    env_allowlist: list[str] | None = None,
    timeout: float | None = None,
    user_args_start: int | None = None,
    insert_separator: bool | None = None,
    reject_flag_args: bool | None = None,
    check: bool = True,
    capture_output: bool = True,
    text: bool = True,
    shell: bool = False,
    **kwargs: Any,
) -> subprocess.CompletedProcess[str]:
    """Run a subprocess with explicit argv and conservative defaults."""

    if shell:
        raise CommandPolicyError("safe_run never permits shell=True")
    if "shell" in kwargs:
        raise CommandPolicyError("safe_run never permits shell=True")

    base_policy = policy or CommandPolicy(allowed_executables=allowed_executables or [])
    if allowed_executables is not None:
        base_policy.allowed_executables = allowed_executables
    if cwd_root is not None:
        base_policy.cwd_root = cwd_root
    if env_allowlist is not None:
        base_policy.env_allowlist = env_allowlist
    if timeout is not None:
        base_policy.timeout = timeout
    if user_args_start is not None:
        base_policy.user_args_start = user_args_start
    if insert_separator is not None:
        base_policy.insert_separator = insert_separator
    if reject_flag_args is not None:
        base_policy.reject_flag_args = reject_flag_args

    safe_argv = _validate_argv(argv)
    safe_argv[0] = _resolve_executable(safe_argv[0], base_policy.allowed_executables)
    safe_argv = _apply_user_arg_policy(safe_argv, base_policy)
    safe_env = _build_env(env, base_policy.env_allowlist)
    safe_cwd = _validate_cwd(cwd, base_policy.cwd_root)

    try:
        return subprocess.run(
            safe_argv,
            cwd=safe_cwd,
            env=safe_env,
            timeout=base_policy.timeout,
            check=check,
            capture_output=capture_output,
            text=text,
            shell=False,
            **kwargs,
        )
    except subprocess.CalledProcessError as exc:
        raise CommandExecutionError(f"command exited with status {exc.returncode}") from exc
    except subprocess.TimeoutExpired as exc:
        raise CommandExecutionError("command timed out") from exc
