"""FastMCP integration helpers."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any, TypeVar

from ..decorators import shield
from ..policy import ShieldPolicy

F = TypeVar("F", bound=Callable[..., Any])


def shielded_tool(mcp: Any, policy: ShieldPolicy, **tool_kwargs: Any) -> Callable[[F], Any]:
    """Register a FastMCP tool with the safe decorator order.

    Equivalent to:

    .. code-block:: python

       @mcp.tool()
       @shield(policy)
       def tool_name(...):
           ...
    """

    def decorate(func: F) -> Any:
        return mcp.tool(**tool_kwargs)(shield(policy)(func))

    return decorate
