"""Official MCP Python SDK integration helpers."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any, TypeVar

from ..decorators import shield
from ..policy import ShieldPolicy

F = TypeVar("F", bound=Callable[..., Any])


def shield_handler(func: F, policy: ShieldPolicy) -> F:
    """Wrap a Python MCP SDK handler or callable with a shield policy."""

    return shield(policy)(func)


def shield_tool_callback(policy: ShieldPolicy) -> Callable[[F], F]:
    """Decorator form for SDK callback registration."""

    return shield(policy)
