"""Framework integration helpers for mcp-server-shield."""
