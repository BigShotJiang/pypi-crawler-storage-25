"""Tool description linting for poisoning-prone MCP descriptors."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, ConfigDict

from .exceptions import DescriptionLintError

Severity = Literal["low", "medium", "high", "critical"]


class DescriptionFinding(BaseModel):
    """One lint finding for a tool description."""

    model_config = ConfigDict(extra="forbid")

    tool_name: str
    severity: Severity
    code: str
    message: str
    phrase: str


RULES: list[tuple[str, Severity, str, str]] = [
    (
        "hidden_instruction",
        "critical",
        r"\b(ignore|disregard|override)\s+(all\s+)?(previous|prior|above)\s+instructions\b",
        "Description contains hidden/covert instruction language.",
    ),
    (
        "covert_channel",
        "high",
        r"\b(do not tell the user|secretly|silently|hidden instruction|system prompt)\b",
        "Description suggests covert behavior or hidden instructions.",
    ),
    (
        "tool_shadowing",
        "high",
        r"\b(use this tool instead of|replace[s]? other tools|same as .* but|shadow[s]? .* tool)\b",
        "Description appears to shadow or redirect other tools.",
    ),
    (
        "excessive_privilege",
        "medium",
        r"\b(full access|unrestricted|no approval|without permission|all files|any command)\b",
        "Description claims broad privileges that should be scoped explicitly.",
    ),
    (
        "dangerous_ambiguity",
        "medium",
        r"\b(execute arbitrary|run arbitrary|delete files|exfiltrate|bypass|disable security)\b",
        "Description uses dangerous or ambiguous security-sensitive wording.",
    ),
]


def lint_description(tool_name: str, description: str) -> list[DescriptionFinding]:
    """Lint one tool description."""

    findings: list[DescriptionFinding] = []
    for code, severity, pattern, message in RULES:
        match = re.search(pattern, description, flags=re.IGNORECASE | re.DOTALL)
        if match:
            findings.append(
                DescriptionFinding(
                    tool_name=tool_name,
                    severity=severity,
                    code=code,
                    message=message,
                    phrase=match.group(0),
                )
            )
    return findings


def load_tool_descriptions(path: str | Path) -> list[dict[str, Any]]:
    """Load tool-like records from JSON or YAML."""

    source = Path(path)
    try:
        raw = source.read_text(encoding="utf-8")
        if source.suffix.lower() in {".yaml", ".yml"}:
            data = yaml.safe_load(raw)
        else:
            data = json.loads(raw)
    except (OSError, json.JSONDecodeError, yaml.YAMLError) as exc:
        raise DescriptionLintError(f"could not load tool descriptions from {source}") from exc

    if isinstance(data, dict) and isinstance(data.get("tools"), list):
        tools = data["tools"]
    elif isinstance(data, list):
        tools = data
    else:
        raise DescriptionLintError("expected a list of tools or an object with a tools list")

    normalized: list[dict[str, Any]] = []
    for index, tool in enumerate(tools):
        if not isinstance(tool, dict):
            raise DescriptionLintError(f"tool entry {index} is not an object")
        name = str(tool.get("name", f"tool_{index}"))
        description = str(tool.get("description", ""))
        normalized.append({"name": name, "description": description, **tool})
    return normalized


def lint_tool_descriptions(tools: list[dict[str, Any]]) -> list[DescriptionFinding]:
    """Lint many tool descriptions."""

    findings: list[DescriptionFinding] = []
    for tool in tools:
        findings.extend(
            lint_description(
                str(tool.get("name", "unknown")),
                str(tool.get("description", "")),
            )
        )
    return findings
