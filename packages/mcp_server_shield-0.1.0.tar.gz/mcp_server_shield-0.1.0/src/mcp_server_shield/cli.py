"""Command line interface for mcp-server-shield."""

from __future__ import annotations

import argparse
import json
import sys
from importlib import metadata
from pathlib import Path
from typing import Any

from .description_lint import lint_tool_descriptions, load_tool_descriptions
from .exceptions import ManifestVerificationError, ShieldError
from .manifest import (
    generate_manifest,
    load_descriptors,
    read_manifest,
    verify_manifest,
    write_manifest,
)
from .policy import ShieldPolicy


def _print_json(value: Any) -> None:
    print(json.dumps(value, indent=2, sort_keys=True))


def _cmd_lint_descriptions(args: argparse.Namespace) -> int:
    tools = load_tool_descriptions(args.path)
    findings = lint_tool_descriptions(tools)
    payload = {
        "findings": [finding.model_dump() for finding in findings],
        "count": len(findings),
    }
    if args.json:
        _print_json(payload)
    else:
        for finding in findings:
            print(
                f"{finding.severity.upper()} {finding.tool_name} {finding.code}: {finding.message}"
            )
        if not findings:
            print("No description lint findings.")
    return 1 if findings and args.fail_on_findings else 0


def _cmd_manifest_generate(args: argparse.Namespace) -> int:
    descriptors = load_descriptors(args.descriptors)
    manifest = generate_manifest(descriptors)
    write_manifest(manifest, args.output)
    if args.json:
        _print_json(manifest.model_dump())
    else:
        print(f"Wrote {args.output}")
    return 0


def _cmd_manifest_verify(args: argparse.Namespace) -> int:
    descriptors = load_descriptors(args.descriptors)
    manifest = read_manifest(args.lockfile)
    verify_manifest(descriptors, manifest)
    if args.json:
        _print_json({"ok": True})
    else:
        print("Manifest verified.")
    return 0


def _cmd_policy_check(args: argparse.Namespace) -> int:
    policy = ShieldPolicy.from_file(args.path)
    policy.check()
    payload = {
        "ok": True,
        "policy_id": policy.policy_id,
        "paths": sorted(policy.paths),
        "urls": sorted(policy.urls),
        "strings": sorted(policy.strings),
        "output_filters": [
            getattr(item, "name", type(item).__name__) for item in policy.output_filters
        ],
        "waivers": [waiver.id for waiver in policy.waivers],
    }
    if args.json:
        _print_json(payload)
    else:
        print(f"Policy {policy.policy_id!r} is valid.")
    return 0


def _cmd_doctor(args: argparse.Namespace) -> int:
    try:
        version = metadata.version("mcp-server-shield")
    except metadata.PackageNotFoundError:
        version = "editable-or-source"
    payload = {
        "ok": True,
        "python": sys.version.split()[0],
        "package_version": version,
        "cwd": str(Path.cwd()),
        "pydantic": metadata.version("pydantic"),
        "pyyaml": metadata.version("PyYAML"),
    }
    if args.json:
        _print_json(payload)
    else:
        print("mcp-server-shield doctor")
        for key, value in payload.items():
            print(f"{key}: {value}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mcp-shield", description="MCP server hardening utilities"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    lint_parser = subparsers.add_parser("lint-descriptions", help="lint MCP tool descriptions")
    lint_parser.add_argument("path", help="JSON/YAML file containing tool descriptors")
    lint_parser.add_argument("--json", action="store_true", help="emit JSON")
    lint_parser.add_argument(
        "--fail-on-findings",
        action="store_true",
        help="exit non-zero when findings are present",
    )
    lint_parser.set_defaults(func=_cmd_lint_descriptions)

    manifest_parser = subparsers.add_parser(
        "manifest", help="generate or verify descriptor lockfiles"
    )
    manifest_subparsers = manifest_parser.add_subparsers(dest="manifest_command", required=True)
    generate_parser = manifest_subparsers.add_parser(
        "generate", help="generate mcp-shield.lock.json"
    )
    generate_parser.add_argument("descriptors", help="JSON/YAML descriptor file")
    generate_parser.add_argument("--output", default="mcp-shield.lock.json", help="lockfile path")
    generate_parser.add_argument("--json", action="store_true", help="emit generated manifest JSON")
    generate_parser.set_defaults(func=_cmd_manifest_generate)

    verify_parser = manifest_subparsers.add_parser("verify", help="verify mcp-shield.lock.json")
    verify_parser.add_argument("descriptors", help="JSON/YAML descriptor file")
    verify_parser.add_argument("--lockfile", default="mcp-shield.lock.json", help="lockfile path")
    verify_parser.add_argument("--json", action="store_true", help="emit JSON")
    verify_parser.set_defaults(func=_cmd_manifest_verify)

    policy_parser = subparsers.add_parser("policy", help="policy utilities")
    policy_subparsers = policy_parser.add_subparsers(dest="policy_command", required=True)
    check_parser = policy_subparsers.add_parser("check", help="validate a policy file")
    check_parser.add_argument("path", help="YAML/JSON policy file")
    check_parser.add_argument("--json", action="store_true", help="emit JSON")
    check_parser.set_defaults(func=_cmd_policy_check)

    doctor_parser = subparsers.add_parser("doctor", help="show local installation diagnostics")
    doctor_parser.add_argument("--json", action="store_true", help="emit JSON")
    doctor_parser.set_defaults(func=_cmd_doctor)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except ManifestVerificationError as exc:
        print(f"manifest verification failed: {exc}", file=sys.stderr)
        return 2
    except ShieldError as exc:
        print(f"mcp-shield error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
