"""Decorator that enforces shield policies around MCP tool functions."""

from __future__ import annotations

import functools
import inspect
import time
from collections.abc import Awaitable, Callable
from typing import Any, TypeVar, cast

from .audit import AuditEvent, Decision
from .exceptions import ShieldError, ShieldValidationError
from .output_filters import apply_output_filters
from .policy import ShieldPolicy
from .validators import GuardOutcome, ValidatorResult

F = TypeVar("F", bound=Callable[..., Any])


def _validator_name(guard: Any) -> str:
    return type(guard).__name__


def _denied_result(
    field: str, guard: Any, exc: Exception, waiver_id: str | None = None
) -> ValidatorResult:
    return ValidatorResult(
        field=field,
        validator=_validator_name(guard),
        allowed=waiver_id is not None,
        reason="waived denial" if waiver_id else type(exc).__name__,
        metadata={},
        waiver_id=waiver_id,
    )


def _validate_bound_arguments(
    policy: ShieldPolicy,
    bound: inspect.BoundArguments,
) -> tuple[list[ValidatorResult], str | None]:
    results: list[ValidatorResult] = []
    waiver_id: str | None = None

    guard_groups: list[tuple[dict[str, Any], str]] = [
        (policy.paths, "PathGuard"),
        (policy.urls, "URLGuard"),
        (policy.strings, "StringGuard"),
    ]
    for guards, validator_name in guard_groups:
        for field, guard in guards.items():
            if field not in bound.arguments:
                if policy.fail_closed:
                    exc = ShieldValidationError(f"required shielded argument {field!r} is missing")
                    waiver = policy.active_waiver(field=field, validator=validator_name)
                    if waiver is None:
                        raise exc
                    waiver_id = waiver.id
                    results.append(_denied_result(field, guard, exc, waiver.id))
                continue
            try:
                outcome = cast(
                    GuardOutcome, guard.validate_value(bound.arguments[field], field=field)
                )
                bound.arguments[field] = outcome.value
                results.append(outcome.result)
            except Exception as exc:
                waiver = policy.active_waiver(field=field, validator=validator_name)
                if waiver is None:
                    raise
                waiver_id = waiver.id
                results.append(_denied_result(field, guard, exc, waiver.id))
    return results, waiver_id


def _emit(
    policy: ShieldPolicy,
    *,
    tool_name: str,
    decision: Decision,
    started: float,
    validator_results: list[ValidatorResult],
    redaction_counts: dict[str, int] | None = None,
    waiver_id: str | None = None,
    exception_type: str | None = None,
) -> None:
    policy.audit_sink.emit(
        AuditEvent(
            tool_name=tool_name,
            decision=decision,
            policy_id=policy.policy_id,
            validator_results=[result.model_dump() for result in validator_results],
            redaction_counts=redaction_counts or {},
            waiver_id=waiver_id,
            duration_ms=(time.perf_counter() - started) * 1000,
            exception_type=exception_type,
        )
    )


def _finalize_output(
    policy: ShieldPolicy,
    output: Any,
) -> tuple[Any, dict[str, int], bool]:
    if not policy.output_filters:
        return output, {}, False
    return apply_output_filters(output, policy.output_filters)


def shield(policy: ShieldPolicy) -> Callable[[F], F]:
    """Apply pre-execution validators, post-execution filters, and audit logging."""

    def decorate(func: F) -> F:
        signature = inspect.signature(func)
        tool_name = getattr(func, "__name__", "unknown_tool")

        if inspect.iscoroutinefunction(func):

            @functools.wraps(func)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                started = time.perf_counter()
                validator_results: list[ValidatorResult] = []
                waiver_id: str | None = None
                try:
                    bound = signature.bind(*args, **kwargs)
                    bound.apply_defaults()
                    validator_results, waiver_id = _validate_bound_arguments(policy, bound)
                    result = await cast(Callable[..., Awaitable[Any]], func)(
                        *bound.args, **bound.kwargs
                    )
                    filtered, counts, changed = _finalize_output(policy, result)
                    _emit(
                        policy,
                        tool_name=tool_name,
                        decision="redacted" if changed else "allowed",
                        started=started,
                        validator_results=validator_results,
                        redaction_counts=counts,
                        waiver_id=waiver_id,
                    )
                    return filtered
                except ShieldError as exc:
                    _emit(
                        policy,
                        tool_name=tool_name,
                        decision="denied",
                        started=started,
                        validator_results=validator_results,
                        waiver_id=waiver_id,
                        exception_type=type(exc).__name__,
                    )
                    raise
                except Exception as exc:
                    _emit(
                        policy,
                        tool_name=tool_name,
                        decision="errored",
                        started=started,
                        validator_results=validator_results,
                        waiver_id=waiver_id,
                        exception_type=type(exc).__name__,
                    )
                    raise

            async_wrapper.__signature__ = signature  # type: ignore[attr-defined]
            return cast(F, async_wrapper)

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            started = time.perf_counter()
            validator_results: list[ValidatorResult] = []
            waiver_id: str | None = None
            try:
                bound = signature.bind(*args, **kwargs)
                bound.apply_defaults()
                validator_results, waiver_id = _validate_bound_arguments(policy, bound)
                result = func(*bound.args, **bound.kwargs)
                filtered, counts, changed = _finalize_output(policy, result)
                _emit(
                    policy,
                    tool_name=tool_name,
                    decision="redacted" if changed else "allowed",
                    started=started,
                    validator_results=validator_results,
                    redaction_counts=counts,
                    waiver_id=waiver_id,
                )
                return filtered
            except ShieldError as exc:
                _emit(
                    policy,
                    tool_name=tool_name,
                    decision="denied",
                    started=started,
                    validator_results=validator_results,
                    waiver_id=waiver_id,
                    exception_type=type(exc).__name__,
                )
                raise
            except Exception as exc:
                _emit(
                    policy,
                    tool_name=tool_name,
                    decision="errored",
                    started=started,
                    validator_results=validator_results,
                    waiver_id=waiver_id,
                    exception_type=type(exc).__name__,
                )
                raise

        sync_wrapper.__signature__ = signature  # type: ignore[attr-defined]
        return cast(F, sync_wrapper)

    return decorate
