from __future__ import annotations

import os
from pathlib import Path

import pytest

from mcp_server_shield.exceptions import PathValidationError
from mcp_server_shield.validators import PathGuard


def test_path_guard_accepts_file_inside_root(tmp_path: Path) -> None:
    target = tmp_path / "note.txt"
    target.write_text("hello", encoding="utf-8")
    guard = PathGuard(root=tmp_path, read=True, allowed_extensions=["txt"])

    outcome = guard.validate_value("note.txt", field="file_path")

    assert Path(outcome.value) == target.resolve()
    assert outcome.result.allowed is True


def test_path_guard_blocks_traversal(tmp_path: Path) -> None:
    outside = tmp_path.parent / "outside.txt"
    outside.write_text("secret", encoding="utf-8")
    guard = PathGuard(root=tmp_path, read=True)

    with pytest.raises(PathValidationError):
        guard.validate_value("../outside.txt", field="file_path")


def test_path_guard_blocks_absolute_path_outside_root(tmp_path: Path) -> None:
    outside = tmp_path.parent / "outside-absolute.txt"
    outside.write_text("secret", encoding="utf-8")
    guard = PathGuard(root=tmp_path, read=True)

    with pytest.raises(PathValidationError):
        guard.validate_value(str(outside), field="file_path")


def test_path_guard_blocks_symlink_escape(tmp_path: Path) -> None:
    outside = tmp_path.parent / "outside-symlink.txt"
    outside.write_text("secret", encoding="utf-8")
    link = tmp_path / "link.txt"
    try:
        link.symlink_to(outside)
    except (OSError, NotImplementedError) as exc:
        pytest.skip(f"symlink creation unavailable: {exc}")

    guard = PathGuard(root=tmp_path, read=True)

    with pytest.raises(PathValidationError):
        guard.validate_value("link.txt", field="file_path")


def test_path_guard_blocks_windows_style_escape(tmp_path: Path) -> None:
    guard = PathGuard(root=tmp_path, read=True, must_exist=False)
    candidate = "C:\\Windows\\system32\\drivers\\etc\\hosts"

    if os.name == "nt":
        with pytest.raises(PathValidationError):
            guard.validate_value(candidate, field="file_path")
    else:
        with pytest.raises(PathValidationError):
            guard.validate_value(candidate, field="file_path")


def test_path_guard_enforces_extension_denylist(tmp_path: Path) -> None:
    target = tmp_path / "payload.py"
    target.write_text("print('no')", encoding="utf-8")
    guard = PathGuard(root=tmp_path, read=True, denied_extensions=[".py"])

    with pytest.raises(PathValidationError):
        guard.validate_value("payload.py", field="file_path")
