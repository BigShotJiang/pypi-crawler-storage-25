from __future__ import annotations

import json
from pathlib import Path

import pytest

from mcp_server_shield import JSONLAuditSink, MemoryAuditSink, ShieldPolicy
from mcp_server_shield.audit import AuditEvent, NullAuditSink, OpenTelemetryAuditSink
from mcp_server_shield.integrations.fastmcp import shielded_tool
from mcp_server_shield.integrations.mcp_sdk import shield_handler, shield_tool_callback


def test_jsonl_audit_sink_writes_event(tmp_path: Path) -> None:
    path = tmp_path / "audit.jsonl"
    sink = JSONLAuditSink(path)
    sink.emit(
        AuditEvent(
            tool_name="tool",
            decision="allowed",
            policy_id="p",
            duration_ms=1.0,
        )
    )

    payload = json.loads(path.read_text(encoding="utf-8"))
    assert payload["tool_name"] == "tool"
    assert "exception_type" in payload


def test_null_audit_sink_accepts_event() -> None:
    NullAuditSink().emit(
        AuditEvent(
            tool_name="tool",
            decision="allowed",
            policy_id="p",
            duration_ms=1.0,
        )
    )


def test_otel_sink_requires_optional_dependency(monkeypatch: pytest.MonkeyPatch) -> None:
    import builtins

    real_import = builtins.__import__

    def fake_import(name: str, *args: object, **kwargs: object) -> object:
        if name == "opentelemetry":
            raise ImportError("missing")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", fake_import)
    with pytest.raises(RuntimeError):
        OpenTelemetryAuditSink().emit(
            AuditEvent(
                tool_name="tool",
                decision="allowed",
                policy_id="p",
                duration_ms=1.0,
            )
        )


def test_fastmcp_helper_uses_safe_decorator_order() -> None:
    class FakeMCP:
        def tool(self, **kwargs: object):
            def decorate(func):
                func._tool_kwargs = kwargs
                return func

            return decorate

    policy = ShieldPolicy.permissive_for_tests(audit_sink=MemoryAuditSink())

    @shielded_tool(FakeMCP(), policy, name="demo")
    def demo(value: str) -> str:
        return value

    assert demo("ok") == "ok"
    assert demo._tool_kwargs == {"name": "demo"}


def test_mcp_sdk_helpers_wrap_callable() -> None:
    policy = ShieldPolicy.permissive_for_tests(audit_sink=MemoryAuditSink())

    def echo(value: str) -> str:
        return value

    assert shield_handler(echo, policy)("x") == "x"
    assert shield_tool_callback(policy)(echo)("y") == "y"
