from __future__ import annotations

import socket

import pytest

from mcp_server_shield.exceptions import URLValidationError
from mcp_server_shield.validators import URLGuard


def test_url_guard_accepts_allowed_https_host() -> None:
    guard = URLGuard(
        allowed_schemes=["https"],
        allowed_hosts=["api.github.com"],
        resolve_dns=False,
    )

    outcome = guard.validate_value("https://api.github.com/repos/openai/openai", field="url")

    assert outcome.value == "https://api.github.com/repos/openai/openai"
    assert outcome.result.metadata["host"] == "api.github.com"


def test_url_guard_blocks_embedded_credentials() -> None:
    guard = URLGuard(allowed_hosts=["example.com"], resolve_dns=False)

    with pytest.raises(URLValidationError):
        guard.validate_value("https://user:pass@example.com/", field="url")


def test_url_guard_blocks_localhost() -> None:
    guard = URLGuard(resolve_dns=False)

    with pytest.raises(URLValidationError):
        guard.validate_value("https://localhost/", field="url")


def test_url_guard_blocks_private_ip() -> None:
    guard = URLGuard(resolve_dns=False)

    with pytest.raises(URLValidationError):
        guard.validate_value("https://127.0.0.1/admin", field="url")


def test_url_guard_blocks_dns_rebinding_to_private_ip(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_getaddrinfo(
        *args: object, **kwargs: object
    ) -> list[tuple[int, int, int, str, tuple[str, int]]]:
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("10.0.0.5", 443))]

    monkeypatch.setattr(socket, "getaddrinfo", fake_getaddrinfo)
    guard = URLGuard(allowed_hosts=["safe.example"])

    with pytest.raises(URLValidationError):
        guard.validate_value("https://safe.example/data", field="url")


def test_url_guard_can_allow_private_ip_explicitly() -> None:
    guard = URLGuard(allow_private_ips=True, allow_localhost=True, resolve_dns=False)

    outcome = guard.validate_value("https://127.0.0.1/status", field="url")

    assert outcome.result.allowed is True
