from __future__ import annotations

import sys
from pathlib import Path

import pytest

from mcp_server_shield.commands import safe_run
from mcp_server_shield.exceptions import CommandPolicyError


def test_safe_run_executes_allowlisted_argv(tmp_path: Path) -> None:
    completed = safe_run(
        [sys.executable, "-c", "print('ok')"],
        allowed_executables=[sys.executable],
        cwd=tmp_path,
        cwd_root=tmp_path,
        timeout=5,
    )

    assert completed.stdout.strip() == "ok"


def test_safe_run_rejects_shell_string() -> None:
    with pytest.raises(CommandPolicyError):
        safe_run("echo unsafe", allowed_executables=["echo"])  # type: ignore[arg-type]


def test_safe_run_rejects_shell_true() -> None:
    with pytest.raises(CommandPolicyError):
        safe_run(
            [sys.executable, "-c", "print('x')"],
            allowed_executables=[sys.executable],
            shell=True,
        )


def test_safe_run_rejects_unallowlisted_executable() -> None:
    with pytest.raises(CommandPolicyError):
        safe_run(
            [sys.executable, "-c", "print('x')"],
            allowed_executables=["definitely-not-python"],
        )


def test_safe_run_rejects_flag_like_user_argument() -> None:
    with pytest.raises(CommandPolicyError):
        safe_run(
            [sys.executable, "-c", "print('x')", "--danger"],
            allowed_executables=[sys.executable],
            user_args_start=3,
            reject_flag_args=True,
        )


def test_safe_run_inserts_separator_for_user_args() -> None:
    completed = safe_run(
        [sys.executable, "-c", "import sys; print(sys.argv[1:])", "path.txt"],
        allowed_executables=[sys.executable],
        user_args_start=3,
        insert_separator=True,
        timeout=5,
    )

    assert "['--', 'path.txt']" in completed.stdout


def test_safe_run_rejects_unallowlisted_env() -> None:
    with pytest.raises(CommandPolicyError):
        safe_run(
            [sys.executable, "-c", "print('x')"],
            allowed_executables=[sys.executable],
            env={"SECRET_TOKEN": "nope"},
        )
