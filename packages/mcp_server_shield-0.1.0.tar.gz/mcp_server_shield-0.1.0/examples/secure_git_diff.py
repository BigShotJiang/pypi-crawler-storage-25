from pathlib import Path

from mcp_server_shield.commands import safe_run

REPO_ROOT = Path(__file__).resolve().parents[1]


def git_diff_for_path(pathspec: str) -> str:
    completed = safe_run(
        ["git", "diff", pathspec],
        allowed_executables=["git"],
        cwd=REPO_ROOT,
        cwd_root=REPO_ROOT,
        user_args_start=2,
        insert_separator=True,
        reject_flag_args=True,
    )
    return completed.stdout
