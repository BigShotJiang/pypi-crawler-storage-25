from fastmcp import FastMCP

from mcp_server_shield import ShieldPolicy, shield
from mcp_server_shield.validators import PathGuard

mcp = FastMCP("shielded-files")

policy = ShieldPolicy.strict(
    paths={"file_path": PathGuard(root="./workspace", read=True, write=False)}
)


@mcp.tool()
@shield(policy)
def read_file(file_path: str) -> str:
    with open(file_path, encoding="utf-8") as handle:
        return handle.read()
