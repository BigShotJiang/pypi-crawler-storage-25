from urllib.request import Request, urlopen

from mcp_server_shield import ShieldPolicy, shield
from mcp_server_shield.output_filters import PromptInjectionFilter, SecretRedactor
from mcp_server_shield.validators import URLGuard

policy = ShieldPolicy.strict(
    urls={
        "url": URLGuard(
            allowed_schemes=["https"],
            allowed_hosts=["api.github.com"],
        )
    },
    output_filters=[SecretRedactor(), PromptInjectionFilter()],
)


@shield(policy)
def fetch_github_api(url: str) -> str:
    request = Request(url, headers={"User-Agent": "mcp-server-shield-example"})
    with urlopen(request, timeout=10) as response:
        return response.read().decode("utf-8", errors="replace")
