from pathlib import Path

from mcp_server_shield import ShieldPolicy, shield
from mcp_server_shield.output_filters import SecretRedactor
from mcp_server_shield.validators import PathGuard

WORKSPACE = Path(__file__).parent / "workspace"

policy = ShieldPolicy.strict(
    paths={
        "file_path": PathGuard(
            root=WORKSPACE,
            read=True,
            write=False,
            allowed_extensions=[".txt", ".md"],
        )
    },
    output_filters=[SecretRedactor()],
)


@shield(policy)
def read_workspace_file(file_path: str) -> str:
    with open(file_path, encoding="utf-8") as handle:
        return handle.read()
