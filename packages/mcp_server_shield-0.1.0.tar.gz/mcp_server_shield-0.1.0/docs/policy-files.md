# Policy Files

Policies can be stored as YAML or JSON and loaded with:

```python
from mcp_server_shield import ShieldPolicy

policy = ShieldPolicy.from_file("mcp-shield-policy.yaml")
```

The top-level sections are `paths`, `urls`, `strings`, `output_filters`, and `waivers`.
Each key under `paths`, `urls`, or `strings` must match a function argument name.

Waivers are intentionally verbose. A waiver without a reason, expiry date, and evidence
is rejected because exception handling must be visible in audit logs.
