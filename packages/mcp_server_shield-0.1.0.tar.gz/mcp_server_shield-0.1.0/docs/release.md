# Release Process

This project is designed for PyPI releases through GitHub Actions and PyPI Trusted
Publishing.

## One-Time Setup

1. Create or claim the `mcp-server-shield` project on PyPI.
2. Configure a PyPI Trusted Publisher:
   - owner: `Trihedron1240`
   - repository: `mcp-server-shield`
   - workflow: `release.yml`
   - environment: `pypi`
3. In GitHub, create the `pypi` environment if you want manual approval before publishing.
4. Enable private vulnerability reporting in the repository security settings.
5. Add branch protection for `main`, requiring CI before merge.

## Release

1. Update `src/mcp_server_shield/__init__.py` exports if the public API changed.
2. Update the version in `pyproject.toml`.
3. Update `CHANGELOG.md`.
4. Run:

   ```bash
   ruff check .
   mypy src
   pytest
   python -m build
   ```

5. Commit the release prep.
6. Create a GitHub release tagged `vX.Y.Z`.
7. The `release.yml` workflow builds the package and publishes to PyPI.
