# OWASP MCP Top 10 Mapping

The OWASP MCP Top 10 is currently a moving target. `mcp-server-shield` maps to the
recurring risk classes that appear in the current MCP hardening research:

| Risk theme | Shield control |
| --- | --- |
| Tool poisoning | Description linting, manifest locking |
| Secret exposure | SecretRedactor, safe audit events |
| Command injection | safe_run argv enforcement |
| Argument injection | separator insertion and positional-only argument checks |
| Path traversal | PathGuard canonical root checks |
| SSRF | URLGuard scheme, host, IP, and DNS checks |
| Insufficient auth/policy exceptions | explicit waivers with expiry and evidence |
| Audit gaps | JSONL audit sink and optional OTel interface |
| Context over-sharing | recursive output filtering |
