# mcp-server-shield Specification

## Goals

- Provide Python-first hardening primitives inside MCP tool implementations.
- Feel natural for FastMCP and the official Python MCP SDK.
- Validate named arguments before tool execution.
- Filter model-facing outputs before they return to the client.
- Provide safe wrappers for subprocess execution.
- Lint and lock tool descriptions and schemas to detect poisoning and drift.
- Emit structured audit events without logging raw secrets.
- Use deterministic local enforcement with no cloud calls.

## Non-Goals

- This is not a scanner, gateway, hosted firewall, or proxy.
- This is not a replacement for application authentication or authorization.
- This does not provide OS sandboxing or container isolation.
- This does not perform LLM-based runtime classification.
- This does not guarantee that every secret or prompt-injection phrase is detected.

## Architecture

The core enforcement point is the `@shield(policy)` decorator. The decorator preserves
function metadata and the Python signature for MCP framework compatibility, binds incoming
arguments by name, runs configured guards, calls the underlying function, applies output
filters, and emits an audit event.

Core modules:

- `policy.py`: Pydantic policy and waiver models, plus YAML/JSON loading.
- `decorators.py`: sync and async function boundary enforcement.
- `paths.py`: symlink-aware path containment.
- `urls.py`: scheme, host, private IP, localhost, and DNS checks.
- `commands.py`: argv-only subprocess wrapper.
- `output_filters.py`: secret, PII, and prompt-injection output filters.
- `description_lint.py`: local linting for poisoning-prone descriptions.
- `manifest.py`: lockfile generation and verification.
- `audit.py`: JSONL audit sink and optional OpenTelemetry interface.
- `integrations/`: FastMCP and Python MCP SDK helper adapters.

## Threat Model Mapped to OWASP MCP Top 10

The OWASP MCP Top 10 is still evolving, so this mapping uses stable risk themes rather
than exact numbering.

- Tool poisoning and descriptor drift: `lint-descriptions` detects covert instructions,
  shadowing language, and dangerous ambiguity; `manifest generate/verify` detects changes
  to names, descriptions, schemas, annotations, and policy IDs.
- Secret exposure: `SecretRedactor` redacts common API keys, GitHub tokens, OpenAI-style
  keys, AWS-style keys, private keys, bearer tokens, and optional PII.
- Command injection and argument injection: `safe_run` rejects shell strings and
  `shell=True`, requires executable allowlists, supports `--` separator insertion, and can
  reject flag-like user arguments.
- Path traversal and filesystem overreach: `PathGuard` resolves canonical paths with
  symlink awareness and blocks traversal outside a declared root.
- SSRF and local network exposure: `URLGuard` blocks localhost, private, reserved, and
  otherwise non-public IPs by default, including DNS-resolved addresses.
- Insufficient authorization and policy waivers: policies fail closed, and waivers require
  an ID, reason, expiry date, target, and evidence.
- Audit gaps: every decorated call emits a JSON-safe event containing timestamp, tool name,
  decision, policy ID, validator results, redaction counts, waiver ID, duration, and
  exception type.
- Context over-sharing: output filters operate recursively over common JSON-like response
  shapes before data returns to the MCP client.

## Public API

```python
from mcp_server_shield import ShieldPolicy, Waiver, shield
from mcp_server_shield.validators import PathGuard, StringGuard, URLGuard
from mcp_server_shield.output_filters import PromptInjectionFilter, SecretRedactor
from mcp_server_shield.commands import CommandPolicy, safe_run
```

`ShieldPolicy` constructors:

- `ShieldPolicy.strict(...)`
- `ShieldPolicy.permissive_for_tests(...)`
- `ShieldPolicy.from_file(path)`

CLI:

- `mcp-shield lint-descriptions`
- `mcp-shield manifest generate`
- `mcp-shield manifest verify`
- `mcp-shield policy check`
- `mcp-shield doctor`

## Security Defaults

- Guards deny unsafe input with typed exceptions.
- Paths are constrained to explicit roots.
- URL validation allows `https` by default and blocks localhost and non-public IPs.
- `safe_run` never permits shell strings or `shell=True`.
- Command execution requires an explicit executable allowlist.
- Environment inheritance is allowlist-based.
- Waivers are explicit, expiring, and audit-visible.
- Audit events do not contain raw arguments or raw exception messages.

## Testing Strategy

The test suite uses pytest and includes unit tests for every guard and filter, async and
sync decorator behavior, CLI-relevant manifest behavior, and regressions for path
traversal, symlink escape, command argument injection, shell invocation rejection,
SSRF/private IP blocking, secret leakage, prompt-injection output, and manifest drift.

CI runs on Python 3.10, 3.11, and 3.12 with ruff, mypy, pytest coverage, package build,
and a pip install smoke test.

## Roadmap v0.1 to v1.0

v0.1 establishes the local enforcement core for Python MCP servers.

Planned v0.x work:

- More built-in validators for auth context and tenant boundaries.
- Richer policy composition and per-tool policy registries.
- Additional descriptor importers for live FastMCP and MCP SDK servers.
- SARIF output for description linting.
- More secret patterns with documented false-positive tradeoffs.

v1.0 readiness criteria:

- Stable public API.
- Backward-compatible policy file format.
- Cross-platform path and command regression coverage.
- Documented integrations with major Python MCP server frameworks.
- Production user feedback on audit event shape and manifest workflows.
