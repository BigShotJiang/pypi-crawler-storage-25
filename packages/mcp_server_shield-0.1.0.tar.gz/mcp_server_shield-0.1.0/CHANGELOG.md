# Changelog

All notable changes to this project will be documented in this file.

## 0.1.0 - 2026-04-25

- Initial Python-first MCP tool boundary hardening library.
- Added `@shield(policy)` for sync and async tool functions.
- Added path, URL, and string guards.
- Added argv-only `safe_run` command wrapper.
- Added secret, PII, and prompt-injection output filters.
- Added description linting and manifest lockfile CLI commands.
- Added JSONL audit logging and optional OpenTelemetry sink interface.
- Added FastMCP and official MCP Python SDK helper integrations.
