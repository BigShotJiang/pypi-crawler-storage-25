# Security Policy

## Supported Versions

`mcp-server-shield` is pre-1.0. Security fixes will target the latest released minor
version.

## Reporting a Vulnerability

Please do not file public issues for exploitable vulnerabilities.

Use GitHub private vulnerability reporting if it is enabled for this repository. If it is
not enabled yet, email the maintainer address listed on the repository profile or open a
minimal public issue asking for a private disclosure channel without including exploit
details.

Helpful reports include:

- affected version or commit
- vulnerable API or CLI command
- minimal reproduction
- expected and actual behavior
- whether secrets, command execution, filesystem access, URL fetching, or audit logs are
  involved

## Scope

Security reports are especially relevant for:

- path traversal or symlink escape bypasses
- SSRF or private network URL validation bypasses
- command or argument injection bypasses
- secret redaction failures
- audit log secret leakage
- policy waiver or fail-closed bypasses
- manifest verification drift bypasses
