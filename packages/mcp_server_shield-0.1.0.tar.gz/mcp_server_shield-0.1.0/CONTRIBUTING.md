# Contributing

Thanks for helping improve `mcp-server-shield`.

## Development

```bash
python -m pip install -e ".[dev]"
ruff check .
mypy src
pytest
```

The test suite enforces at least 85% coverage.

## Security-Sensitive Changes

This library is intended to sit directly on MCP tool execution boundaries. Changes to
validators, output filters, command execution, policy loading, or audit logging should
include regression tests for both allowed and denied behavior.

Prefer deterministic local enforcement. Do not add cloud or LLM calls to hot-path security
decisions.

## Pull Requests

- Keep changes focused.
- Add or update tests for behavior changes.
- Update `README.md` or `SPEC.md` when public API or security defaults change.
- Run `ruff check .`, `mypy src`, and `pytest` before submitting.
