"""Example: Fetching sentiment data from YUKKA APIs.

This example demonstrates how to:
1. Create a session with authentication
2. Create Asset objects from YUKKA IDs
3. Fetch sentiment scores for assets
"""

from dotenv import load_dotenv

from yukka import Asset, Session
from yukka.data import stoxx600

load_dotenv()


def main():
    """Fetch sentiment data for BMW."""
    with Session() as session:
        # Create an asset from a YUKKA ID
        assets = Asset.from_yukka_id(stoxx600()["yukka_id"].to_list())

        # Fetch sentiment data (date_to defaults to today)
        df = session.events(assets, date_from="2026-01-01")
        mapped_df = df.map()
        print(mapped_df)


if __name__ == "__main__":
    main()
