"""Integration tests for YukkaClient (require YUKKA_TOKEN environment variable)."""

import importlib
import os
from importlib.metadata import PackageNotFoundError
from unittest.mock import patch

import pytest
from dotenv import load_dotenv

from yukka import YukkaClient


@pytest.fixture(scope="session")
def yukka() -> YukkaClient:
    """Create a YukkaClient from the YUKKA_TOKEN environment variable."""
    load_dotenv()
    return YukkaClient.from_token(os.environ["YUKKA_TOKEN"])


@pytest.fixture
def entities() -> list[str]:
    """Return a list of entity IDs for testing."""
    return ["company:bmw", "company:apple"]


@pytest.fixture
def time_range() -> tuple[str, str]:
    """Return a time range tuple for testing."""
    return ("2026-01-01", "2026-01-07")


def test_version_fallback_when_package_not_installed():
    """__version__ should fall back to '0.0.0+dev' when package metadata is unavailable."""
    import yukka

    with patch("importlib.metadata.version", side_effect=PackageNotFoundError("yukka")):
        importlib.reload(yukka)
        assert yukka.__version__ == "0.0.0+dev"


@pytest.mark.skip(reason="Integration test - requires YUKKA_TOKEN environment variable")
def test_sentiment(yukka: YukkaClient, entities: list[str], time_range: tuple[str, str]):
    """Test sentiment fetching for a list of entities over a time range."""
    date_from, date_to = time_range
    df = yukka.sentiment(entities, date_from=date_from, date_to=date_to)
    # Polars backend includes 'date' column plus entity columns
    assert set(df.columns) == {"date", *entities}
    assert len(df) == 6
    assert "date" in df.columns
