"""Tests for yukka.data universe loaders."""

import polars as pl

from yukka.data import ftse100, nasdaq100, sp500, stoxx600


class TestUniverseLoaders:
    """Tests for pre-validated universe loader functions."""

    def test_stoxx600_returns_dataframe(self):
        """STOXX 600 loader should return a non-empty DataFrame."""
        df = stoxx600()
        assert isinstance(df, pl.DataFrame)
        assert len(df) > 0

    def test_sp500_returns_dataframe(self):
        """S&P 500 loader should return a non-empty DataFrame."""
        df = sp500()
        assert isinstance(df, pl.DataFrame)
        assert len(df) > 0

    def test_nasdaq100_returns_dataframe(self):
        """NASDAQ 100 loader should return a non-empty DataFrame."""
        df = nasdaq100()
        assert isinstance(df, pl.DataFrame)
        assert len(df) > 0

    def test_ftse100_returns_dataframe(self):
        """FTSE 100 loader should return a non-empty DataFrame."""
        df = ftse100()
        assert isinstance(df, pl.DataFrame)
        assert len(df) > 0

    def test_stoxx600_has_expected_columns(self):
        """STOXX 600 DataFrame should contain isin and yukka_id columns."""
        df = stoxx600()
        assert "isin" in df.columns
        assert "yukka_id" in df.columns

    def test_sp500_unique_isin(self):
        """S&P 500 DataFrame should have unique ISINs."""
        df = sp500()
        assert df["isin"].n_unique() == len(df)

    def test_stoxx600_no_null_yukka_id(self):
        """STOXX 600 DataFrame should have no null yukka_id values."""
        df = stoxx600()
        assert df["yukka_id"].null_count() == 0

    def test_nasdaq100_no_null_yukka_id(self):
        """NASDAQ 100 DataFrame should have no null yukka_id values."""
        df = nasdaq100()
        assert df["yukka_id"].null_count() == 0

    def test_interval_columns_dropped(self):
        """date, interval, obser, org_permid, index columns should be removed."""
        df = stoxx600()
        for col in df.columns:
            col_lower = col.lower()
            assert not any(kw in col_lower for kw in ["interval", "obser", "date", "org_permid", "index"]), (
                f"Column {col!r} should have been dropped"
            )
