"""Events logic — EventsFrame wrapper and EventsMixin for YukkaClient."""

from __future__ import annotations

import io

import polars as pl

from .models import EventsFrame
from .utils import IntoDateTime


class EventsMixin:
    """Mixin providing event-related methods for YukkaClient."""

    def event_names(self) -> dict[str, str]:
        """Return mapping of event IDs to human-readable names.

        Fetches the event hierarchy from the Metadata API on first call,
        then caches for the client lifetime.

        Returns:
            Dict mapping event IDs (e.g. "E6_B") to names (e.g. "Acquisition")
        """
        if self._event_names:
            return self._event_names

        resp = self._client.get(
            str(self._metadata_api_url / "v2" / "hierarchy" / "event"),
            headers=self._auth_headers,
        )
        resp.raise_for_status()
        data = resp.json()

        for super_event in data["super_events"]:
            for category in super_event.get("children", []):
                for event in category.get("children", []):
                    self._event_names[event["id"]] = event["name"]
                    for role_entry in event.get("event_participant_roles", []):
                        participant_id = role_entry.get("participant_id", "")
                        en_name = next(
                            (n["name"] for n in role_entry.get("name", []) if n["lang"] == "en"),
                            role_entry["role"],
                        )
                        self._event_participant_roles[(event["id"], participant_id)] = en_name

        return self._event_names

    def event_participant_roles(self) -> dict[tuple[str, str], str]:
        """Return mapping of (event_id, role) to human-readable role names.

        Fetches the event hierarchy from the Metadata API on first call (shared with event_names),
        then caches for the client lifetime.

        Returns:
            Dict mapping (event_id, role) tuples to English role names,
            e.g. ("E6_B", "ARG1") → "Acquirer"
        """
        if not self._event_participant_roles:
            self.event_names()  # populates both caches
        return self._event_participant_roles

    def events(
        self, entities: list[str], date_from: IntoDateTime, date_to: IntoDateTime, batch_size: int = 50
    ) -> EventsFrame:
        """Fetch events for entities over a time range.

        Args:
            entities: List of entity IDs in format "type:alpha_id" (e.g., "company:bmw")
            date_from: Start date
            date_to: End date
            batch_size: Number of entities per API request (default 50)

        Returns:
            EventsFrame wrapping the raw DataFrame. Call .map() for translated columns.

        Raises:
            httpx.HTTPStatusError: If API request fails
        """
        if len(entities) == 0:
            return EventsFrame(pl.DataFrame(), self.event_names, self.event_participant_roles)

        all_dfs: list[pl.DataFrame] = []

        for i in range(0, len(entities), batch_size):
            batch = entities[i : i + batch_size]
            print(f"Fetching events for batch {i // batch_size + 1} ({len(batch)} entities)...")

            resp = self._client.post(
                str(self._data_api_url / "api" / "exports" / "events"),
                json={
                    "time_range": self._build_time_range(date_from, date_to),
                    "event_filter": {
                        "event_participants": {"include": batch, "exclude": []},
                    },
                },
                headers=self._auth_headers,
            )
            resp.raise_for_status()

            df = pl.read_parquet(io.BytesIO(resp.content))
            # Cast binary columns to strings and convert publish_time to date
            df = df.cast(
                {col: pl.Utf8 for col, dtype in zip(df.columns, df.dtypes, strict=False) if dtype == pl.Binary}
            )
            df = df.with_columns(pl.from_epoch(pl.col("publish_time"), time_unit="d").alias("publish_time"))
            all_dfs.append(df)

        return EventsFrame(pl.concat(all_dfs), self.event_names, self.event_participant_roles)
