"""Response models for YUKKA APIs."""

from __future__ import annotations

from collections.abc import Callable

import polars as pl


class EventsFrame:
    """Thin wrapper around a Polars DataFrame that adds a .map() method for translation.

    Behaves exactly like a pl.DataFrame — all attribute access is delegated to the
    underlying frame. Call .map() to translate event_id, factuality, and time to
    human-readable labels.

    Usage:
        >>> df = session.events(asset, "2026-01-01")
        >>> df.head()          # regular DataFrame operations work
        >>> df.map()           # translated view
    """

    def __init__(
        self,
        df: pl.DataFrame,
        event_names_fn: Callable[[], dict[str, str]],
        event_roles_fn: Callable[[], dict[tuple[str, str], str]],
    ) -> None:
        """Initialize with a DataFrame and lazy lookup functions for event translation."""
        self._df = df
        self._event_names_fn = event_names_fn
        self._event_roles_fn = event_roles_fn

    def map(self) -> pl.DataFrame:
        """Translate event_id, factuality, and time to human-readable labels.

        Returns:
            DataFrame with columns: publish_time, event_participant_id, event_id,
            event_participant_role, factuality, time
        """
        if self._df.is_empty():
            return pl.DataFrame(
                schema={
                    "publish_time": pl.Date,
                    "event_participant_id": pl.Utf8,
                    "event_id": pl.Utf8,
                    "event_participant_role": pl.Utf8,
                    "factuality": pl.Utf8,
                    "time": pl.Utf8,
                }
            )

        # Cast join key columns to strings to match lookup frames.
        # Raw event_participant_role is numeric (e.g. 1, 2); hierarchy uses "P1", "P2" —
        # prepend "P" to align with the hierarchy's participant_id format.
        df = self._df.cast({"event_id": pl.Utf8, "event_participant_role": pl.Utf8})
        df = df.with_columns(("P" + pl.col("event_participant_role")).alias("event_participant_role"))

        # Translate participant_role via compound lookup — must run before event_id is replaced
        roles = self._event_roles_fn()
        if roles:
            role_keys = list(roles.keys())
            role_lookup = pl.DataFrame(
                {
                    "eid": [k[0] for k in role_keys],
                    "pid": [k[1] for k in role_keys],
                    "role_name": list(roles.values()),
                }
            )
            df = (
                df.join(
                    role_lookup, left_on=["event_id", "event_participant_role"], right_on=["eid", "pid"], how="left"
                )
                .drop("event_participant_role")
                .rename({"role_name": "event_participant_role"})
            )

        # Translate event_id via event_names() lookup
        names = self._event_names_fn()
        event_lookup = pl.DataFrame({"event_id_raw": list(names.keys()), "event_name": list(names.values())})
        df = (
            df.join(event_lookup, left_on="event_id", right_on="event_id_raw", how="left")
            .drop("event_id")
            .rename({"event_name": "event_id"})
        )

        temporality = {0: "past", 1: "present", 2: "future", 3: "unknown", 4: "none"}
        factuality = {
            0: "fact",
            1: "counterfact",
            2: "possible",
            3: "counterpossible",
            4: "probable",
            5: "counterprobable",
            6: "unknown",
            7: "none",
        }

        df = df.with_columns(
            pl.col("factuality").replace_strict(factuality, default="unknown").alias("factuality"),
            pl.col("time").replace_strict(temporality, default="unknown").alias("time"),
        )

        return df.select(
            "publish_time", "event_participant_id", "event_id", "event_participant_role", "factuality", "time"
        )

    def __getattr__(self, name):
        """Delegate attribute access to the underlying DataFrame."""
        return getattr(self._df, name)

    def __len__(self):
        """Return number of rows in the underlying DataFrame."""
        return len(self._df)

    def __repr__(self):
        """Return repr of the underlying DataFrame."""
        return repr(self._df)

    def __str__(self):
        """Return string representation of the underlying DataFrame."""
        return str(self._df)

    def __getitem__(self, key):
        """Index into the underlying DataFrame."""
        return self._df[key]
