"""Sentiment logic — SentimentMixin for YukkaClient."""

from __future__ import annotations

import io

import polars as pl

from .utils import IntoDateTime


class SentimentMixin:
    """Mixin providing sentiment-related methods for YukkaClient."""

    def sentiment(
        self, entities: list[str], date_from: IntoDateTime, date_to: IntoDateTime, batch_size: int = 50
    ) -> pl.DataFrame:
        """Fetch sentiment counts for entities over a time range.

        Args:
            entities: List of entity IDs in format "type:alpha_id" (e.g., "company:bmw")
            date_from: Start date
            date_to: End date
            batch_size: Number of entities per API request (default 50)

        Returns:
            DataFrame with columns: date, entity, positive, neutral, negative

        Raises:
            httpx.HTTPStatusError: If API request fails
        """
        if len(entities) == 0:
            return pl.DataFrame()

        all_dfs: list[pl.DataFrame] = []

        # Batch entities to avoid API limits
        for i in range(0, len(entities), batch_size):
            batch = entities[i : i + batch_size]
            print(f"Fetching sentiment for batch {i // batch_size + 1} ({len(batch)} entities)...")

            data: list[bytes] = []
            with self._client.stream(
                "POST",
                str(self._data_api_url / "api" / "exports" / "sentiment_matches"),
                json={
                    "time_range": self._build_time_range(date_from, date_to),
                    "sentiment_filter": {"entities": batch},
                    "language_filter": ["en", "de"],
                },
                headers=self._auth_headers,
            ) as resp:
                resp.raise_for_status()
                for chunk in resp.iter_bytes(chunk_size=10_000):
                    data.append(chunk)

            df = pl.read_parquet(io.BytesIO(b"".join(data)))
            all_dfs.append(df)

        # Combine all batches
        df = pl.concat(all_dfs)

        # Pivot the data: one row per date/entity with positive, neutral, negative columns
        return (
            df.with_columns(
                pl.from_epoch(pl.col("publish_time"), time_unit="d").alias("date"),
                pl.col("entity_compound_key").cast(pl.Utf8).alias("entity"),
            )
            .pivot(on="sentiment", index=["date", "entity"], values="count()", aggregate_function="sum")
            .rename({"1": "positive", "0": "neutral", "-1": "negative"})
            .select(["date", "entity", "positive", "neutral", "negative"])
            .sort("date", "entity")
        )
