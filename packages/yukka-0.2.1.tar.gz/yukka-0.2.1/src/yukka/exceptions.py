"""YUKKA API exceptions."""


class ExpiredToken(ValueError):
    """Raised when JWT token has expired and cannot be renewed."""

    pass
