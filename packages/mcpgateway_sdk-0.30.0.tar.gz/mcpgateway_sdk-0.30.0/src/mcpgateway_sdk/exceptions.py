"""Exception hierarchy for MCPGateway SDK.

Public module as of v0.29.0 (renamed from ``_exceptions``). Typed exception
classes for skill-upload error codes are exported from here and re-exported
at the package root.
"""

from __future__ import annotations

from typing import Any, ClassVar, Protocol


class GatewayError(Exception):
    """Base exception for all MCPGateway API errors.

    The optional ``code`` kwarg carries the server-side ``error.code``
    discriminator (kebab-case, populated from ``body['error']['code']``).
    Always a string when present; ``None`` when the response body did not
    include a code (e.g., legacy non-coded errors).
    """

    def __init__(
        self,
        status_code: int,
        message: str,
        *,
        code: str | None = None,
    ) -> None:
        self.status_code = status_code
        self.message = message
        self.code = code
        super().__init__(f"[{status_code}] {message}")


class AuthError(GatewayError):
    """Raised on HTTP 401 Unauthorized."""

    def __init__(self, message: str = "Unauthorized", *, code: str | None = None) -> None:
        super().__init__(status_code=401, message=message, code=code)


class ForbiddenError(GatewayError):
    """Raised on HTTP 403 Forbidden."""

    def __init__(self, message: str = "Forbidden", *, code: str | None = None) -> None:
        super().__init__(status_code=403, message=message, code=code)


class NotFoundError(GatewayError):
    """Raised on HTTP 404 Not Found."""

    def __init__(self, message: str = "Not found", *, code: str | None = None) -> None:
        super().__init__(status_code=404, message=message, code=code)


class ConflictError(GatewayError):
    """Raised on HTTP 409 Conflict."""

    def __init__(self, message: str = "Conflict", *, code: str | None = None) -> None:
        super().__init__(status_code=409, message=message, code=code)


class ValidationError(GatewayError):
    """Raised on HTTP 422 Unprocessable Entity."""

    def __init__(
        self,
        message: str = "Validation error",
        *,
        code: str | None = None,
    ) -> None:
        super().__init__(status_code=422, message=message, code=code)


class RateLimitError(GatewayError):
    """Raised on HTTP 429 Too Many Requests."""

    def __init__(self, message: str = "Rate limited", *, code: str | None = None) -> None:
        super().__init__(status_code=429, message=message, code=code)


# ---------------------------------------------------------------------------
# Typed skill-upload validation errors (v0.29.0; codes locked by ADR
# ``docs/architecture/adr-vivi-app-contract-alignment.md`` Decision 1+3).
# ---------------------------------------------------------------------------


class SkillFileMissing(ValidationError):
    """Raised when a skill ZIP contains no ``SKILL.md`` (any case).

    Server response:
        ``{"error": {"code": "skill-file-missing", "message": "...", "details": {}}}``
    """

    CODE: ClassVar[str] = "skill-file-missing"

    def __init__(
        self,
        message: str = "ZIP must contain SKILL.md (case-insensitive); none found",
        *,
        code: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message=message, code=code if code is not None else self.CODE)
        # No structured detail fields for this code; ``details`` accepted for symmetry.
        _ = details


class SkillFileAmbiguous(ValidationError):
    """Raised when a skill ZIP contains multiple ``SKILL.md`` files (case-insensitive collision).

    Server response:
        ``{"error": {"code": "skill-file-ambiguous", "message": "...",
                      "details": {"found_paths": ["dir1/SKILL.md", "dir2/SKILL.md"]}}}``
    """

    CODE: ClassVar[str] = "skill-file-ambiguous"

    def __init__(
        self,
        message: str = "Multiple SKILL.md files found",
        *,
        code: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message=message, code=code if code is not None else self.CODE)
        det = details or {}
        raw_paths = det.get("found_paths", [])
        self.found_paths: list[str] = (
            [str(p) for p in raw_paths] if isinstance(raw_paths, list) else []
        )


class SkillMalformedFrontmatter(ValidationError):
    """Raised when ``SKILL.md`` YAML frontmatter cannot be parsed.

    Server response:
        ``{"error": {"code": "skill-malformed-frontmatter", "message": "...",
                      "details": {"parse_error": "<YAML error>"}}}``
    """

    CODE: ClassVar[str] = "skill-malformed-frontmatter"

    def __init__(
        self,
        message: str = "SKILL.md YAML frontmatter is malformed",
        *,
        code: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message=message, code=code if code is not None else self.CODE)
        det = details or {}
        parse_err = det.get("parse_error", "")
        self.parse_error: str = parse_err if isinstance(parse_err, str) else ""


class SkillFrontmatterMissingField(ValidationError):
    """Raised when ``SKILL.md`` YAML frontmatter is missing required fields.

    Required fields per ADR Decision 7: ``name`` and ``description``.

    Server response:
        ``{"error": {"code": "skill-frontmatter-missing-field", "message": "...",
                      "details": {"missing_fields": ["name", "description"]}}}``
    """

    CODE: ClassVar[str] = "skill-frontmatter-missing-field"

    def __init__(
        self,
        message: str = "SKILL.md frontmatter is missing required field(s)",
        *,
        code: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message=message, code=code if code is not None else self.CODE)
        det = details or {}
        raw_missing = det.get("missing_fields", [])
        self.missing_fields: list[str] = (
            [str(f) for f in raw_missing] if isinstance(raw_missing, list) else []
        )


# ---------------------------------------------------------------------------
# Dispatch maps
# ---------------------------------------------------------------------------


class _ErrorFactory(Protocol):
    """Callable that creates a GatewayError from message + optional code."""

    def __call__(self, message: str, *, code: str | None = ...) -> GatewayError: ...


class _TypedErrorFactory(Protocol):
    """Callable that creates a typed ValidationError from message + code + details.

    All four typed skill-upload exceptions (``SkillFileMissing`` etc.) satisfy
    this protocol; ``_CODE_MAP`` is typed against it so the dispatch site in
    ``error_from_response`` can pass ``details=...`` under ``mypy --strict``.
    """

    def __call__(
        self,
        message: str,
        *,
        code: str | None = ...,
        details: dict[str, Any] | None = ...,
    ) -> ValidationError: ...


_STATUS_MAP: dict[int, _ErrorFactory] = {
    401: AuthError,
    403: ForbiddenError,
    404: NotFoundError,
    409: ConflictError,
    422: ValidationError,
    429: RateLimitError,
}


# A parallel-to-_STATUS_MAP dispatch for HTTP 422 + ``error.code`` discriminators.
# Conceptually ``dict[str, type[ValidationError]]``; typed via ``_TypedErrorFactory``
# so the dispatch site can forward ``details=...`` under ``mypy --strict``.
_CODE_MAP: dict[str, _TypedErrorFactory] = {
    SkillFileMissing.CODE: SkillFileMissing,
    SkillFileAmbiguous.CODE: SkillFileAmbiguous,
    SkillMalformedFrontmatter.CODE: SkillMalformedFrontmatter,
    SkillFrontmatterMissingField.CODE: SkillFrontmatterMissingField,
}


# ---------------------------------------------------------------------------
# Body extractors
# ---------------------------------------------------------------------------


def _extract_message(body: dict[str, Any]) -> str:
    """Extract a human-readable error message from an API response body."""
    if "detail" in body:
        detail = body["detail"]
        if isinstance(detail, str):
            return detail
        if isinstance(detail, dict) and "message" in detail:
            return str(detail["message"])
        return str(detail)
    if "error" in body and isinstance(body["error"], dict):
        msg: str = body["error"].get("message", str(body["error"]))
        return msg
    return str(body)


def _extract_code(body: dict[str, Any]) -> str | None:
    """Extract the ``error.code`` discriminator from an API response body."""
    if "error" in body and isinstance(body["error"], dict):
        code = body["error"].get("code")
        return code if isinstance(code, str) else None
    return None


def _extract_details(body: dict[str, Any]) -> dict[str, Any]:
    """Extract the ``error.details`` dict from an API response body."""
    if "error" in body and isinstance(body["error"], dict):
        details = body["error"].get("details")
        return details if isinstance(details, dict) else {}
    return {}


# ---------------------------------------------------------------------------
# Dispatch entry point
# ---------------------------------------------------------------------------


def error_from_response(status_code: int, body: dict[str, Any]) -> GatewayError:
    """Create the appropriate exception from an HTTP status code and response body.

    Dispatch order:
      1. ``(status==422, code in _CODE_MAP)`` -> instantiate the typed class with
         ``code`` and ``details`` so typed attributes are populated.
      2. ``status in _STATUS_MAP`` -> instantiate the status-mapped class with ``code``.
      3. Otherwise -> return ``GatewayError(status_code, message, code=code)``.

    The ``.code`` attribute is always populated when the response body included
    one -- even for unmapped codes -- to support forward-compatible branching.
    """
    message = _extract_message(body)
    code = _extract_code(body)

    if status_code == 422 and code is not None and code in _CODE_MAP:
        details = _extract_details(body)
        typed_cls = _CODE_MAP[code]
        return typed_cls(message=message, code=code, details=details)

    cls = _STATUS_MAP.get(status_code)
    if cls is not None:
        return cls(message=message, code=code)
    return GatewayError(status_code=status_code, message=message, code=code)
