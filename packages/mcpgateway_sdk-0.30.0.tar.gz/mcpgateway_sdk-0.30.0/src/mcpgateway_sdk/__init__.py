"""MCPGateway Python SDK."""

from importlib.metadata import PackageNotFoundError, version

from mcpgateway_sdk._client import MCPGateway
from mcpgateway_sdk.exceptions import (
    AuthError,
    ConflictError,
    ForbiddenError,
    GatewayError,
    NotFoundError,
    RateLimitError,
    SkillFileAmbiguous,
    SkillFileMissing,
    SkillFrontmatterMissingField,
    SkillMalformedFrontmatter,
    ValidationError,
)

try:
    __version__ = version("mcpgateway-sdk")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"

__all__ = [
    "MCPGateway",
    "__version__",
    "AuthError",
    "ConflictError",
    "ForbiddenError",
    "GatewayError",
    "NotFoundError",
    "RateLimitError",
    "SkillFileAmbiguous",
    "SkillFileMissing",
    "SkillFrontmatterMissingField",
    "SkillMalformedFrontmatter",
    "ValidationError",
]
