"""Deprecated: use ``mcpgateway_sdk.exceptions`` instead.

This module is retained for backwards compatibility with internal imports
that have not yet been migrated. Scheduled for removal in mcpgateway-sdk 0.30.

Note: No runtime warning is emitted here. The ADR
(``docs/architecture/adr-vivi-app-contract-alignment.md`` Decision 4b)
established a "no deprecation theatre" culture for v0.29.0; this shim
exists purely as defense-in-depth for any external code we may have
missed.
"""

from __future__ import annotations

from mcpgateway_sdk.exceptions import (
    AuthError,
    ConflictError,
    ForbiddenError,
    GatewayError,
    NotFoundError,
    RateLimitError,
    SkillFileAmbiguous,
    SkillFileMissing,
    SkillFrontmatterMissingField,
    SkillMalformedFrontmatter,
    ValidationError,
    error_from_response,
)

__all__ = [
    "AuthError",
    "ConflictError",
    "ForbiddenError",
    "GatewayError",
    "NotFoundError",
    "RateLimitError",
    "SkillFileAmbiguous",
    "SkillFileMissing",
    "SkillFrontmatterMissingField",
    "SkillMalformedFrontmatter",
    "ValidationError",
    "error_from_response",
]
