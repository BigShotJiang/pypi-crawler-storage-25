# SDK Breaking Changes — v0.29.0

> See ADR `docs/architecture/adr-vivi-app-contract-alignment.md` for the
> full rationale on each decision below.

## Sandboxes API

### `Sandboxes.upload`/`Sandboxes.download` removed; use `upload_file`/`download_file` instead

The bare `upload()` and `download()` methods are removed. Use `upload_file(...)`
and `download_file(...)` — same parameters and same HTTP semantics.

**Before (v0.28.0):**

```python
await client.sandboxes.upload(sandbox_id, "data.csv", b"a,b\n1,2")
content = await client.sandboxes.download(sandbox_id, "data.csv")
```

**After (v0.29.0):**

```python
await client.sandboxes.upload_file(sandbox_id, "data.csv", b"a,b\n1,2")
content = await client.sandboxes.download_file(sandbox_id, "data.csv")
```

Bare-name calls now raise `AttributeError` — there is no alias and no
`DeprecationWarning`. See ADR `docs/architecture/adr-vivi-app-contract-alignment.md`
Decision 4b for the rationale (no deprecation theatre when the only
internal consumer is controlled).

### `Sandboxes.acquire_or_create` convenience method (additive)

New `acquire_or_create(session_key, skill_ids=None, **create_kwargs) -> Sandbox`
composes `create` + `install_skills`. Server-side dedup on `session_key`
means concurrent calls with the same key return the same sandbox.

```python
sandbox = await client.sandboxes.acquire_or_create(
    session_key="user-123-conversation-abc",
    skill_ids=["doc-reader-uuid"],
    image="mcpgateway/sandbox-runtime:latest",
)
```

If `install_skills` fails, the exception propagates unchanged and the
sandbox remains alive — caller is responsible for cleanup. Empty list and
`None` for `skill_ids` both skip the `install_skills` call.

## Exception Surface

### `mcpgateway_sdk._exceptions` module renamed to `mcpgateway_sdk.exceptions`

Public-facing exception classes now live at `mcpgateway_sdk.exceptions`. The
leading underscore was retained from when the module was internal; with
v0.29.0's typed exception classes (below) it becomes part of the public API.

A backwards-compat shim is retained at `mcpgateway_sdk._exceptions` for
v0.29.x only. **It will be removed in v0.30.** Migrate imports now:

**Before:**

```python
from mcpgateway_sdk._exceptions import GatewayError
```

**After:**

```python
from mcpgateway_sdk.exceptions import GatewayError
# or
from mcpgateway_sdk import GatewayError    # also exported at package root
```

The shim emits no `DeprecationWarning` — by ADR Decision 4b convention,
v0.29.0 prefers documentation over runtime warnings.

### `GatewayError.code` attribute added (additive)

All `GatewayError` instances now carry a `.code: str | None` attribute
populated from the server's `error.code` field when present. Existing
`GatewayError(...)` constructor calls continue to work — `code` is a new
keyword-only kwarg with default `None`.

```python
try:
    await client.skills.upload(zip_bytes)
except GatewayError as exc:
    if exc.code == "skill-too-many-files":
        ...  # branch on code without parsing the message
```

### Four new typed exception classes for skill-upload errors (additive)

| Class                          | Code (HTTP 422)                   | Typed attribute              |
| ------------------------------ | --------------------------------- | ---------------------------- |
| `SkillFileMissing`             | `skill-file-missing`              | —                            |
| `SkillFileAmbiguous`           | `skill-file-ambiguous`            | `.found_paths: list[str]`    |
| `SkillMalformedFrontmatter`    | `skill-malformed-frontmatter`     | `.parse_error: str`          |
| `SkillFrontmatterMissingField` | `skill-frontmatter-missing-field` | `.missing_fields: list[str]` |

All four inherit from `ValidationError`, which inherits from `GatewayError`.
Existing `except ValidationError:` and `except GatewayError:` callers see
no change.

```python
from mcpgateway_sdk import SkillFileAmbiguous

try:
    await client.skills.upload(zip_bytes)
except SkillFileAmbiguous as exc:
    for path in exc.found_paths:
        print(f"  - {path}")
```

Each class exposes its locked code as a `CODE: ClassVar[str]` constant
(e.g., `SkillFileAmbiguous.CODE == "skill-file-ambiguous"`).

## Backward Compatibility Statement

v0.28.0 callers see one breaking change:

- `Sandboxes.upload`/`Sandboxes.download` raise `AttributeError` — must
  migrate to `upload_file`/`download_file`.

And one scheduled deprecation (compatible through v0.29.x, removal in v0.30):

- `mcpgateway_sdk._exceptions` is renamed to `mcpgateway_sdk.exceptions`.
  The old import path continues to work via a warning-free re-export
  shim throughout v0.29.x; callers should migrate to
  `mcpgateway_sdk.exceptions` before v0.30.

All other public API surfaces are unchanged. The `GatewayError.code`
attribute and four new typed exception classes are additive.

---

# SDK Breaking Changes — v0.23.0

## Servers API

### `ServersResource.configure_oauth()` removed

The `configure_oauth()` method is removed. The corresponding backend endpoint
(`POST /api/v1/servers/{server_id}/oauth-config`) was never functional and has
been removed in the same release. Use the OAuth apps endpoints
(`POST /api/v1/oauth-apps` + `POST /api/v1/oauth-apps/{app_id}/servers/{server_id}`)
to link a reusable OAuth app to a server instead. (#624)

`ServersResource.get_oauth_config()` and `ServersResource.delete_oauth_config()`
are unchanged.

## Connections API

### `connections.revoke()` renamed to `connections.delete()`

The `revoke()` method has been renamed to `delete()` to reflect the new behavior:
connections are now permanently deleted from the database instead of soft-deleted.

**Before (v0.22.x):**

```python
await client.connections.revoke(connection_id)
# Connection still in DB with is_valid=False, revoked_at set
```

**After (v0.23.0):**

```python
await client.connections.delete(connection_id)
# Connection permanently removed from DB
```

### `connections.list()` parameter rename

`include_revoked` parameter renamed to `include_invalid`.

**Before:**

```python
connections = await client.connections.list(include_revoked=True)
```

**After:**

```python
connections = await client.connections.list(include_invalid=True)
```

`include_invalid=True` now returns connections that failed token refresh
(consecutive failures). Revoked connections no longer exist in the database.

### `Connection` model fields removed

The following fields have been removed from the `Connection` response model:

- `revoked_at: datetime | None` -- removed (connections are hard-deleted)
- `revoke_reason: str | None` -- removed (connections are hard-deleted)

### Multiple connections per server

The unique constraint on `(user_id, server_id)` has been removed. A user can
now have multiple connections to the same server (e.g., personal Gmail +
work Gmail). This means:

- `POST /api/v1/connections` no longer returns 409 for duplicate server
- Each connection has its own `id` -- use the `id` to manage specific connections
- Assign specific connections to bundles via the bundle connections API

### Migration guide for vivi-app

1. Replace `client.connections.revoke(id)` with `client.connections.delete(id)`
2. Replace `include_revoked=True` with `include_invalid=True` in list calls
3. Remove references to `connection.revoked_at` and `connection.revoke_reason`
4. If creating connections: no longer need to handle 409 for same-server duplicates
