"""Tests for MCPGateway SDK exception hierarchy."""

from __future__ import annotations

import pytest

from mcpgateway_sdk.exceptions import (
    AuthError,
    ConflictError,
    ForbiddenError,
    GatewayError,
    NotFoundError,
    RateLimitError,
    SkillFileAmbiguous,
    SkillFileMissing,
    SkillFrontmatterMissingField,
    SkillMalformedFrontmatter,
    ValidationError,
    _extract_message,
    error_from_response,
)


class TestGatewayError:
    """Tests for the base GatewayError class."""

    def test_has_status_code_and_message(self) -> None:
        err = GatewayError(status_code=500, message="Internal error")
        assert err.status_code == 500
        assert err.message == "Internal error"

    def test_str_includes_status_code_and_message(self) -> None:
        err = GatewayError(status_code=502, message="Bad gateway")
        assert str(err) == "[502] Bad gateway"

    def test_is_exception(self) -> None:
        err = GatewayError(status_code=500, message="fail")
        assert isinstance(err, Exception)


class TestSubclasses:
    """Tests for named exception subclasses."""

    @pytest.mark.parametrize(
        ("cls", "expected_code", "default_msg"),
        [
            (AuthError, 401, "Unauthorized"),
            (ForbiddenError, 403, "Forbidden"),
            (NotFoundError, 404, "Not found"),
            (ConflictError, 409, "Conflict"),
            (ValidationError, 422, "Validation error"),
            (RateLimitError, 429, "Rate limited"),
        ],
    )
    def test_default_status_code_and_message(
        self,
        cls: type[GatewayError],
        expected_code: int,
        default_msg: str,
    ) -> None:
        err = cls()
        assert err.status_code == expected_code
        assert err.message == default_msg

    @pytest.mark.parametrize(
        ("cls", "expected_code"),
        [
            (AuthError, 401),
            (ForbiddenError, 403),
            (NotFoundError, 404),
            (ConflictError, 409),
            (ValidationError, 422),
            (RateLimitError, 429),
        ],
    )
    def test_custom_message_preserves_status_code(
        self,
        cls: type[GatewayError],
        expected_code: int,
    ) -> None:
        err = cls(message="custom message")
        assert err.status_code == expected_code
        assert err.message == "custom message"

    def test_all_subclasses_are_gateway_errors(self) -> None:
        for cls in (
            AuthError,
            ForbiddenError,
            NotFoundError,
            ConflictError,
            ValidationError,
            RateLimitError,
        ):
            assert issubclass(cls, GatewayError)


class TestErrorFromResponse:
    """Tests for error_from_response factory function."""

    @pytest.mark.parametrize(
        ("status_code", "expected_cls"),
        [
            (401, AuthError),
            (403, ForbiddenError),
            (404, NotFoundError),
            (409, ConflictError),
            (422, ValidationError),
            (429, RateLimitError),
        ],
    )
    def test_maps_known_status_codes(
        self, status_code: int, expected_cls: type[GatewayError]
    ) -> None:
        err = error_from_response(status_code, {"detail": "test msg"})
        assert isinstance(err, expected_cls)
        assert err.message == "test msg"

    def test_unknown_status_code_returns_gateway_error(self) -> None:
        err = error_from_response(500, {"detail": "server error"})
        assert type(err) is GatewayError
        assert err.status_code == 500
        assert err.message == "server error"

    def test_unknown_status_code_418(self) -> None:
        err = error_from_response(418, {"detail": "I'm a teapot"})
        assert type(err) is GatewayError
        assert err.status_code == 418


class TestExtractMessage:
    """Tests for _extract_message helper."""

    def test_detail_string(self) -> None:
        assert _extract_message({"detail": "simple string"}) == "simple string"

    def test_detail_dict_with_message(self) -> None:
        body = {"detail": {"message": "inner message", "code": "ERR"}}
        assert _extract_message(body) == "inner message"

    def test_detail_dict_without_message(self) -> None:
        body = {"detail": {"code": "ERR", "info": "something"}}
        result = _extract_message(body)
        assert "code" in result  # Falls back to str(detail)

    def test_error_dict_with_message(self) -> None:
        body = {"error": {"message": "error msg", "code": "VALIDATION_ERROR"}}
        assert _extract_message(body) == "error msg"

    def test_error_dict_without_message(self) -> None:
        body = {"error": {"code": "UNKNOWN"}}
        result = _extract_message(body)
        assert "code" in result

    def test_fallback_to_str_body(self) -> None:
        body = {"unexpected_key": "value"}
        result = _extract_message(body)
        assert "unexpected_key" in result

    def test_detail_list(self) -> None:
        body = {"detail": [{"loc": ["body", "email"], "msg": "invalid"}]}
        result = _extract_message(body)
        assert "invalid" in result or "loc" in result  # str(detail)


class TestCodeMapDispatch:
    """Tests for the 422+code dispatch surface introduced in v0.29.0 (REQ-ERR-02)."""

    def test_skill_file_missing_dispatched_by_code(self) -> None:
        # Arrange
        body = {
            "error": {
                "code": "skill-file-missing",
                "message": "ZIP must contain SKILL.md (case-insensitive); none found",
                "details": {},
            }
        }
        # Act
        err = error_from_response(422, body)
        # Assert
        assert isinstance(err, SkillFileMissing)
        assert isinstance(err, ValidationError)
        assert isinstance(err, GatewayError)
        assert err.code == "skill-file-missing"
        assert SkillFileMissing.CODE == "skill-file-missing"

    def test_skill_file_ambiguous_populates_found_paths(self) -> None:
        body = {
            "error": {
                "code": "skill-file-ambiguous",
                "message": "Multiple SKILL.md files found",
                "details": {"found_paths": ["dir1/SKILL.md", "dir2/SKILL.md"]},
            }
        }
        err = error_from_response(422, body)
        assert isinstance(err, SkillFileAmbiguous)
        assert err.found_paths == ["dir1/SKILL.md", "dir2/SKILL.md"]
        assert err.code == "skill-file-ambiguous"
        assert SkillFileAmbiguous.CODE == "skill-file-ambiguous"

    def test_skill_malformed_frontmatter_populates_parse_error(self) -> None:
        body = {
            "error": {
                "code": "skill-malformed-frontmatter",
                "message": "YAML parse error",
                "details": {"parse_error": "while scanning a quoted scalar"},
            }
        }
        err = error_from_response(422, body)
        assert isinstance(err, SkillMalformedFrontmatter)
        assert err.parse_error == "while scanning a quoted scalar"
        assert err.code == "skill-malformed-frontmatter"
        assert SkillMalformedFrontmatter.CODE == "skill-malformed-frontmatter"

    def test_skill_frontmatter_missing_field_populates_missing_fields(self) -> None:
        body = {
            "error": {
                "code": "skill-frontmatter-missing-field",
                "message": "Required field(s) missing",
                "details": {"missing_fields": ["name", "description"]},
            }
        }
        err = error_from_response(422, body)
        assert isinstance(err, SkillFrontmatterMissingField)
        assert err.missing_fields == ["name", "description"]
        assert err.code == "skill-frontmatter-missing-field"
        assert SkillFrontmatterMissingField.CODE == "skill-frontmatter-missing-field"

    def test_unmapped_422_code_falls_back_to_validation_error(self) -> None:
        body = {
            "error": {
                "code": "skill-too-many-files",
                "message": "too many",
            }
        }
        err = error_from_response(422, body)
        # Plain ValidationError, NOT a typed subclass
        assert type(err) is ValidationError
        # But the .code attribute is still populated for forward-compat branching
        assert err.code == "skill-too-many-files"

    def test_legacy_422_without_code_returns_validation_error_with_code_none(self) -> None:
        err = error_from_response(422, {"detail": "validation failed"})
        assert type(err) is ValidationError
        assert err.code is None
        assert err.message == "validation failed"

    def test_non_422_with_code_attaches_code_attribute(self) -> None:
        body = {"error": {"code": "RESOURCE_NOT_FOUND", "message": "missing"}}
        err = error_from_response(404, body)
        assert isinstance(err, NotFoundError)
        assert err.code == "RESOURCE_NOT_FOUND"

    def test_empty_string_code_is_preserved(self) -> None:
        # Regression: a falsy check (`code or self.CODE`) would silently drop
        # an empty-string code from the server. The dispatcher must distinguish
        # `""` (sent + meaningful) from `None` (absent).
        body = {"error": {"code": "", "message": "validation failed"}}
        err = error_from_response(422, body)
        assert type(err) is ValidationError
        assert err.code == ""
        assert err.message == "validation failed"
