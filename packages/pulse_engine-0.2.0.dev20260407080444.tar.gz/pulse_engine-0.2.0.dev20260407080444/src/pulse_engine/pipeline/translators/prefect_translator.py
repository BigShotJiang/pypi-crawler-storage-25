from __future__ import annotations

import base64
from typing import Any

import httpx

from pulse_engine.pipeline.schemas import PipelineConfig
from pulse_engine.pipeline.translators.base import BaseTranslator


class PrefectTranslator(BaseTranslator):
    """Translates a PipelineConfig into a Prefect flow run submission."""

    FLOW_ENTRYPOINT = "pulse_engine.runners.prefect_pipeline_flow:pipeline_flow"

    def __init__(
        self,
        prefect_api_url: str,
        prefect_api_key: str,
        work_pool_name: str,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._api_url = prefect_api_url.rstrip("/")
        self._api_key = prefect_api_key
        self._work_pool_name = work_pool_name
        self._client = http_client

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is not None:
            return self._client
        auth_header = base64.b64encode(f":{self._api_key}".encode()).decode()
        return httpx.AsyncClient(
            headers={"Authorization": f"Basic {auth_header}"},
            timeout=30.0,
        )

    def _serialize_dag(self, config: PipelineConfig) -> list[dict[str, Any]]:
        """Serialize the DAG into a JSON-friendly format for Prefect parameters."""
        module_map = {m.name: m for m in config.modules}
        steps = []
        for s in config.dag:
            module = module_map[s.module]
            step_dict: dict[str, Any] = {
                "step": s.step,
                "module": s.module,
                "compute": module.compute.value,
                "retries": module.retries,
                "retry_delay": module.retry_delay,
                "timeout": module.timeout,
                "input_mode": s.input.value,
            }
            if s.fan_out:
                step_dict["fan_out"] = {
                    "from": s.fan_out.from_,
                    "of": s.fan_out.of,
                    "each_receives": s.fan_out.each_receives,
                }
            if s.depends_on:
                step_dict["depends_on"] = [
                    {"step": d.step, "wait": d.wait.value} for d in s.depends_on
                ]
            steps.append(step_dict)
        return steps

    async def submit(
        self,
        pipeline_run_id: str,
        parsed_config: PipelineConfig,
        module_images: dict[str, str],
        input_data: list[dict[str, Any]],
        global_config: dict[str, Any],
        tenant_id: str,
        pulse_engine_url: str,
        pulse_api_token: str,
    ) -> str:
        """Submit a pipeline as a Prefect flow run."""
        client = self._get_client()

        parameters = {
            "pipeline_run_id": pipeline_run_id,
            "tenant_id": tenant_id,
            "dag": self._serialize_dag(parsed_config),
            "module_images": module_images,
            "input_data": input_data,
            "global_config": global_config,
            "pulse_engine_url": pulse_engine_url,
            "pulse_api_token": pulse_api_token,
        }

        body = {
            "parameters": parameters,
            "state": {"type": "SCHEDULED"},
            "tags": [f"product:{parsed_config.name}", f"pipeline:{pipeline_run_id}"],
        }

        try:
            # Prefect 3.x requires deployment ID in URL, so resolve name → ID first
            deployment_name = self._get_deployment_name(parsed_config.name)
            deployment_id = await self._resolve_deployment_id(client, deployment_name)

            response = await client.post(
                f"{self._api_url}/deployments/{deployment_id}/create_flow_run",
                json=body,
            )
            response.raise_for_status()
            data = response.json()
            return str(data["id"])
        finally:
            if self._client is None:
                await client.aclose()

    async def _resolve_deployment_id(
        self, client: httpx.AsyncClient, deployment_name: str
    ) -> str:
        """Look up a Prefect deployment ID by name."""
        response = await client.post(
            f"{self._api_url}/deployments/filter",
            json={
                "deployments": {"name": {"any_": [deployment_name]}},
                "limit": 1,
            },
        )
        response.raise_for_status()
        deployments = response.json()
        if not deployments:
            raise RuntimeError(
                f"Prefect deployment '{deployment_name}' not found. "
                f"Create it first with: prefect deployment build ..."
            )
        return str(deployments[0]["id"])

    def _get_deployment_name(self, pipeline_name: str) -> str:
        """Deployment name for the generic pipeline flow."""
        return f"pulse-pipeline-{pipeline_name}"
