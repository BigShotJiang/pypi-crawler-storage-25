# Changelog

## 0.1.0

- Initial release.
- Container with `bind`, `singleton`, `instance`, `make`, `has`, `flush`, `bound_to`.
- Autowiring from `__init__` type hints.
- Contextual bindings via `when().needs().give()`.
- Aliases, tagging, and container events.
- Method injection via `call()`.
- Service providers with two-phase `register`/`boot` lifecycle.
- `DriverManager` base class for swappable backends.
- Scoped (child) containers.
- Circular dependency detection.

## 0.1.1

- Updated pyproject.toml

## 0.1.2

- Updated pyproject.toml
