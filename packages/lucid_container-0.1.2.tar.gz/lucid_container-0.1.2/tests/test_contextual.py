from abc import ABC, abstractmethod

from lucid_container import Container


class StorageContract(ABC):
    @abstractmethod
    def store(self, data: str) -> None: ...


class S3Storage(StorageContract):
    def store(self, data: str) -> None:
        pass


class LocalStorage(StorageContract):
    def store(self, data: str) -> None:
        pass


class PhotoController:
    def __init__(self, storage: StorageContract):
        self.storage = storage


class ReportController:
    def __init__(self, storage: StorageContract):
        self.storage = storage


class GenericController:
    def __init__(self, storage: StorageContract):
        self.storage = storage


# Nested resolution test classes
class InnerService:
    def __init__(self, storage: StorageContract):
        self.storage = storage


class OuterService:
    def __init__(self, inner: InnerService):
        self.inner = inner


class TestContextualBinding:
    def test_different_concretes_per_consumer(self):
        app = Container()
        app.bind(StorageContract, LocalStorage)
        app.when(PhotoController).needs(StorageContract).give(S3Storage)
        app.when(ReportController).needs(StorageContract).give(LocalStorage)

        photo = app.make(PhotoController)
        report = app.make(ReportController)

        assert isinstance(photo.storage, S3Storage)
        assert isinstance(report.storage, LocalStorage)

    def test_global_binding_without_contextual(self):
        app = Container()
        app.bind(StorageContract, LocalStorage)
        app.when(PhotoController).needs(StorageContract).give(S3Storage)

        generic = app.make(GenericController)
        assert isinstance(generic.storage, LocalStorage)

    def test_contextual_with_factory(self):
        app = Container()
        app.bind(StorageContract, LocalStorage)
        app.when(PhotoController).needs(StorageContract).give(
            lambda c: S3Storage()
        )
        photo = app.make(PhotoController)
        assert isinstance(photo.storage, S3Storage)

    def test_contextual_through_nested_resolution(self):
        app = Container()
        app.bind(StorageContract, LocalStorage)
        app.when(OuterService).needs(StorageContract).give(S3Storage)

        outer = app.make(OuterService)
        # InnerService is built while OuterService is on the build stack,
        # so the contextual binding should apply.
        assert isinstance(outer.inner.storage, S3Storage)
