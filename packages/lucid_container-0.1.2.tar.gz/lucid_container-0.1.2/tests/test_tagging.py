from lucid_container import Container


class DailyReport:
    name = "daily"


class WeeklyReport:
    name = "weekly"


class MonthlyReport:
    name = "monthly"


class TestTagging:
    def test_tagged_resolves_all(self):
        app = Container()
        app.bind("reports.daily", DailyReport)
        app.bind("reports.weekly", WeeklyReport)
        app.bind("reports.monthly", MonthlyReport)
        app.tag(["reports.daily", "reports.weekly", "reports.monthly"], "reports")

        reports = app.tagged("reports")
        assert len(reports) == 3
        names = [r.name for r in reports]
        assert "daily" in names
        assert "weekly" in names
        assert "monthly" in names

    def test_tagged_unknown_tag_returns_empty(self):
        app = Container()
        assert app.tagged("nonexistent") == []

    def test_multiple_tags_on_same_abstract(self):
        app = Container()
        app.bind("reports.daily", DailyReport)
        app.tag(["reports.daily"], "reports")
        app.tag(["reports.daily"], "daily-jobs")

        reports = app.tagged("reports")
        daily_jobs = app.tagged("daily-jobs")
        assert len(reports) == 1
        assert len(daily_jobs) == 1
        assert isinstance(reports[0], DailyReport)
        assert isinstance(daily_jobs[0], DailyReport)
