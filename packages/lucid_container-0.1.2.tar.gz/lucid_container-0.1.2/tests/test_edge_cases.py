from abc import ABC, abstractmethod

import pytest

from lucid_container import (
    CircularDependencyError,
    Container,
    ResolutionError,
)


class CacheContract(ABC):
    @abstractmethod
    def get(self, key: str) -> str: ...


class MemoryCache(CacheContract):
    def get(self, key: str) -> str:
        return key


# Circular dependency classes
class ServiceA:
    def __init__(self, b: "ServiceB"):
        self.b = b


class ServiceB:
    def __init__(self, a: ServiceA):
        self.a = a


# Three-way circular
class X:
    def __init__(self, y: "Y"):
        self.y = y


class Y:
    def __init__(self, z: "Z"):
        self.z = z


class Z:
    def __init__(self, x: X):
        self.x = x


class SelfOnly:
    def __init__(self):
        self.ready = True


class NoneHint:
    def __init__(self, value: None):
        self.value = value


class ContainerUser:
    def __init__(self, container: Container):
        self.container = container


class TestCircularDependency:
    def test_two_way_circular(self):
        app = Container()
        with pytest.raises(CircularDependencyError) as exc_info:
            app.make(ServiceA)
        assert "ServiceA" in str(exc_info.value) or "ServiceB" in str(exc_info.value)
        assert len(exc_info.value.cycle) >= 2

    def test_three_way_circular(self):
        app = Container()
        with pytest.raises(CircularDependencyError):
            app.make(X)


class TestSelfBinding:
    def test_bind_abstract_to_itself(self):
        app = Container()
        app.bind(MemoryCache, MemoryCache)
        result = app.make(MemoryCache)
        assert isinstance(result, MemoryCache)


class TestPlainConcreteAutowire:
    def test_make_on_plain_concrete(self):
        app = Container()
        result = app.make(SelfOnly)
        assert result.ready is True


class TestPrimitiveHints:
    def test_str_int_none_not_autowired(self):
        app = Container()
        with pytest.raises(ResolutionError):
            app.make(NoneHint)


class TestEmptyContainer:
    def test_make_raises_on_abstract(self):
        app = Container()
        with pytest.raises(ResolutionError):
            app.make(CacheContract)


class TestContainerSelfInjection:
    def test_container_as_dependency(self):
        app = Container()
        user = app.make(ContainerUser)
        assert user.container is app


class TestProviderRegisterException:
    def test_failed_register_does_not_break_container(self):
        from lucid_container import ServiceProvider

        class BadProvider(ServiceProvider):
            def register(self):
                raise ValueError("oops")

        class GoodProvider(ServiceProvider):
            def register(self):
                self.app.singleton(CacheContract, MemoryCache)

        app = Container()
        with pytest.raises(ValueError):
            app.register_provider(BadProvider)
        # Container is still usable
        app.register_provider(GoodProvider)
        assert isinstance(app.make(CacheContract), MemoryCache)


class TestScopedContainers:
    def test_scoped_returns_child(self):
        app = Container()
        child = app.scoped()
        assert child is not app

    def test_child_resolves_parent_bindings(self):
        app = Container()
        app.bind(CacheContract, MemoryCache)
        child = app.scoped()
        result = child.make(CacheContract)
        assert isinstance(result, MemoryCache)

    def test_child_singletons_independent(self):
        app = Container()
        app.singleton(CacheContract, MemoryCache)
        parent_cache = app.make(CacheContract)
        child = app.scoped()
        child_cache = child.make(CacheContract)
        assert parent_cache is not child_cache

    def test_child_bindings_dont_leak(self):
        app = Container()
        child = app.scoped()

        class Unique:
            pass

        child.bind("unique", Unique)
        assert child.has("unique") is True
        assert app.has("unique") is False

    def test_parent_changes_after_scope_dont_affect_child(self):
        app = Container()
        app.bind(CacheContract, MemoryCache)
        child = app.scoped()

        class OtherCache(CacheContract):
            def get(self, key: str) -> str:
                return "other"

        app.bind(CacheContract, OtherCache)
        # Child still uses original binding
        result = child.make(CacheContract)
        assert isinstance(result, MemoryCache)

    def test_instance_carries_over_to_child(self):
        app = Container()
        config = {"debug": True}
        app.instance("config", config)
        child = app.scoped()
        assert child.make("config") is config
