from abc import ABC, abstractmethod

from lucid_container import Container


class CacheContract(ABC):
    @abstractmethod
    def get(self, key: str) -> str: ...


class RedisCache(CacheContract):
    def get(self, key: str) -> str:
        return key


class TestFlush:
    def test_flush_clears_bindings(self):
        app = Container()
        app.bind(CacheContract, RedisCache)
        assert app.has(CacheContract) is True
        app.flush()
        assert app.has(CacheContract) is False

    def test_flush_clears_singletons(self):
        app = Container()
        app.singleton(CacheContract, RedisCache)
        first = app.make(CacheContract)
        app.flush()
        assert app.has(CacheContract) is False

    def test_flush_clears_aliases(self):
        app = Container()
        app.bind(CacheContract, RedisCache)
        app.alias("cache", CacheContract)
        app.flush()
        assert app.has("cache") is False

    def test_rebind_after_flush(self):
        app = Container()
        app.singleton(CacheContract, RedisCache)
        first = app.make(CacheContract)
        app.flush()
        app.singleton(CacheContract, RedisCache)
        second = app.make(CacheContract)
        assert first is not second
