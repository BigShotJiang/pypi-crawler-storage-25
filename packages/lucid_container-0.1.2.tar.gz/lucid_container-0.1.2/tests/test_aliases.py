from abc import ABC, abstractmethod

import pytest

from lucid_container import Container


class CacheContract(ABC):
    @abstractmethod
    def get(self, key: str) -> str: ...


class RedisCache(CacheContract):
    def get(self, key: str) -> str:
        return key


class TestAliases:
    def test_alias_resolves(self):
        app = Container()
        app.singleton(CacheContract, RedisCache)
        app.alias("cache", CacheContract)
        result = app.make("cache")
        assert isinstance(result, RedisCache)

    def test_chained_aliases(self):
        app = Container()
        app.singleton(CacheContract, RedisCache)
        app.alias("cache", CacheContract)
        app.alias("c", "cache")
        result = app.make("c")
        assert isinstance(result, RedisCache)

    def test_has_returns_true_for_alias(self):
        app = Container()
        app.singleton(CacheContract, RedisCache)
        app.alias("cache", CacheContract)
        assert app.has("cache") is True

    def test_alias_and_direct_return_same_singleton(self):
        app = Container()
        app.singleton(CacheContract, RedisCache)
        app.alias("cache", CacheContract)
        direct = app.make(CacheContract)
        via_alias = app.make("cache")
        assert direct is via_alias
