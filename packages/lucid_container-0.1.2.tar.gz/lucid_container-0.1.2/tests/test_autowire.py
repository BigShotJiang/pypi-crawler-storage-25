from abc import ABC, abstractmethod

import pytest

from lucid_container import Container, ResolutionError


class LoggerContract(ABC):
    @abstractmethod
    def log(self, msg: str) -> None: ...


class ConsoleLogger(LoggerContract):
    def log(self, msg: str) -> None:
        pass


class CacheContract(ABC):
    @abstractmethod
    def get(self, key: str) -> str: ...


class MemoryCache(CacheContract):
    def get(self, key: str) -> str:
        return key


class NoInit:
    """Class with no custom __init__."""
    pass


class WithDefaults:
    def __init__(self, logger: LoggerContract, retries: int = 3):
        self.logger = logger
        self.retries = retries


class FullyTyped:
    def __init__(self, logger: LoggerContract, cache: CacheContract):
        self.logger = logger
        self.cache = cache


class MixedParams:
    def __init__(self, logger: LoggerContract, cache: CacheContract, retries: int = 5):
        self.logger = logger
        self.cache = cache
        self.retries = retries


class Nested:
    def __init__(self, service: FullyTyped):
        self.service = service


class VarArgs:
    def __init__(self, logger: LoggerContract, *args: str, **kwargs: int):
        self.logger = logger


class PrimitiveOnly:
    def __init__(self, name: str, count: int):
        self.name = name
        self.count = count


class SelfOnly:
    def __init__(self):
        self.value = 42


class TestAutowire:
    def test_no_init_class(self):
        app = Container()
        obj = app.make(NoInit)
        assert isinstance(obj, NoInit)

    def test_typed_dependencies_resolved(self):
        app = Container()
        app.singleton(LoggerContract, ConsoleLogger)
        app.singleton(CacheContract, MemoryCache)
        obj = app.make(FullyTyped)
        assert isinstance(obj.logger, ConsoleLogger)
        assert isinstance(obj.cache, MemoryCache)

    def test_default_values_used(self):
        app = Container()
        app.singleton(LoggerContract, ConsoleLogger)
        obj = app.make(WithDefaults)
        assert isinstance(obj.logger, ConsoleLogger)
        assert obj.retries == 3

    def test_mixed_bound_and_default(self):
        app = Container()
        app.singleton(LoggerContract, ConsoleLogger)
        app.singleton(CacheContract, MemoryCache)
        obj = app.make(MixedParams)
        assert isinstance(obj.logger, ConsoleLogger)
        assert isinstance(obj.cache, MemoryCache)
        assert obj.retries == 5

    def test_unbound_no_default_raises(self):
        app = Container()
        with pytest.raises(ResolutionError):
            app.make(FullyTyped)

    def test_recursive_autowiring(self):
        app = Container()
        app.singleton(LoggerContract, ConsoleLogger)
        app.singleton(CacheContract, MemoryCache)
        obj = app.make(Nested)
        assert isinstance(obj.service, FullyTyped)
        assert isinstance(obj.service.logger, ConsoleLogger)

    def test_concrete_not_bound_is_autowired(self):
        app = Container()
        app.singleton(LoggerContract, ConsoleLogger)
        app.singleton(CacheContract, MemoryCache)
        # FullyTyped is never explicitly bound
        obj = app.make(FullyTyped)
        assert isinstance(obj, FullyTyped)

    def test_varargs_ignored(self):
        app = Container()
        app.singleton(LoggerContract, ConsoleLogger)
        obj = app.make(VarArgs)
        assert isinstance(obj.logger, ConsoleLogger)

    def test_primitives_not_autowired(self):
        app = Container()
        with pytest.raises(ResolutionError):
            app.make(PrimitiveOnly)

    def test_self_only_init(self):
        app = Container()
        obj = app.make(SelfOnly)
        assert obj.value == 42
