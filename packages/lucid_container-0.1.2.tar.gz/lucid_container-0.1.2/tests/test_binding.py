from abc import ABC, abstractmethod

import pytest

from lucid_container import BindingError, Container


class CacheContract(ABC):
    @abstractmethod
    def get(self, key: str) -> str: ...


class RedisCache(CacheContract):
    def get(self, key: str) -> str:
        return f"redis:{key}"


class MemoryCache(CacheContract):
    def get(self, key: str) -> str:
        return f"memory:{key}"


class TestBind:
    def test_bind_returns_new_instance_each_time(self):
        app = Container()
        app.bind(CacheContract, RedisCache)
        a = app.make(CacheContract)
        b = app.make(CacheContract)
        assert isinstance(a, RedisCache)
        assert a is not b

    def test_bind_with_factory(self):
        app = Container()
        app.bind(CacheContract, lambda c: MemoryCache())
        cache = app.make(CacheContract)
        assert isinstance(cache, MemoryCache)

    def test_factory_receives_container(self):
        app = Container()
        app.instance("prefix", "test")
        app.bind(
            CacheContract,
            lambda c: MemoryCache() if c.make("prefix") == "test" else RedisCache(),
        )
        cache = app.make(CacheContract)
        assert isinstance(cache, MemoryCache)


class TestSingleton:
    def test_singleton_returns_same_instance(self):
        app = Container()
        app.singleton(CacheContract, RedisCache)
        a = app.make(CacheContract)
        b = app.make(CacheContract)
        assert a is b

    def test_rebinding_singleton_clears_cache(self):
        app = Container()
        app.singleton(CacheContract, RedisCache)
        first = app.make(CacheContract)
        app.singleton(CacheContract, MemoryCache)
        second = app.make(CacheContract)
        assert isinstance(first, RedisCache)
        assert isinstance(second, MemoryCache)
        assert first is not second


class TestInstance:
    def test_instance_returns_exact_object(self):
        app = Container()
        obj = {"key": "value"}
        app.instance("config", obj)
        assert app.make("config") is obj

    def test_instance_with_type_abstract(self):
        app = Container()
        cache = MemoryCache()
        app.instance(CacheContract, cache)
        assert app.make(CacheContract) is cache


class TestRebinding:
    def test_rebind_overwrites_previous(self):
        app = Container()
        app.bind(CacheContract, RedisCache)
        app.bind(CacheContract, MemoryCache)
        assert isinstance(app.make(CacheContract), MemoryCache)


class TestHas:
    def test_has_bound(self):
        app = Container()
        app.bind(CacheContract, RedisCache)
        assert app.has(CacheContract) is True

    def test_has_unbound(self):
        app = Container()
        assert app.has(CacheContract) is False

    def test_has_instance(self):
        app = Container()
        app.instance("config", {})
        assert app.has("config") is True


class TestBoundTo:
    def test_bound_to_returns_concrete(self):
        app = Container()
        app.bind(CacheContract, RedisCache)
        assert app.bound_to(CacheContract) is RedisCache

    def test_bound_to_returns_none(self):
        app = Container()
        assert app.bound_to(CacheContract) is None


class TestBindingError:
    def test_bind_non_callable_raises(self):
        app = Container()
        with pytest.raises(BindingError):
            app.bind(CacheContract, 42)

    def test_singleton_non_callable_raises(self):
        app = Container()
        with pytest.raises(BindingError):
            app.singleton(CacheContract, "not callable")
