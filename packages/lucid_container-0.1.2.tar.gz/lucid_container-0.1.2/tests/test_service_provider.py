from abc import ABC, abstractmethod

from lucid_container import Container, ServiceProvider


class CacheContract(ABC):
    @abstractmethod
    def get(self, key: str) -> str: ...


class MemoryCache(CacheContract):
    def get(self, key: str) -> str:
        return key


class LoggerContract(ABC):
    @abstractmethod
    def log(self, msg: str) -> None: ...


class ConsoleLogger(LoggerContract):
    def log(self, msg: str) -> None:
        pass


class CacheProvider(ServiceProvider):
    def register(self):
        self.app.singleton(CacheContract, MemoryCache)

    def boot(self):
        cache = self.app.make(CacheContract)
        cache.booted = True  # type: ignore[attr-defined]


class LogProvider(ServiceProvider):
    def register(self):
        self.app.singleton(LoggerContract, ConsoleLogger)


class BootResolvesOtherProvider(ServiceProvider):
    """Provider that resolves a binding from another provider during boot."""

    def register(self):
        pass

    def boot(self):
        # Should be able to resolve CacheContract registered by CacheProvider
        self.app.make(CacheContract)


class TestServiceProvider:
    def test_register_called_immediately(self):
        app = Container()
        app.register_provider(CacheProvider)
        assert app.has(CacheContract)

    def test_boot_calls_all_providers(self):
        app = Container()
        app.register_provider(CacheProvider)
        app.boot()
        cache = app.make(CacheContract)
        assert getattr(cache, "booted", False) is True

    def test_provider_has_app_reference(self):
        app = Container()
        provider = CacheProvider(app)
        assert provider.app is app

    def test_multiple_providers_no_conflict(self):
        app = Container()
        app.register_provider(CacheProvider)
        app.register_provider(LogProvider)
        assert app.has(CacheContract)
        assert app.has(LoggerContract)

    def test_boot_resolves_other_providers(self):
        app = Container()
        app.register_provider(CacheProvider)
        app.register_provider(BootResolvesOtherProvider)
        app.boot()  # Should not raise
