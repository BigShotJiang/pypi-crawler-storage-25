import pytest

from lucid_container import Container, DriverManager, ResolutionError


class MemoryCache:
    name = "memory"


class RedisCache:
    def __init__(self, host: str = "localhost"):
        self.host = host
        self.name = "redis"


class FileCache:
    def __init__(self, path: str = "/tmp"):
        self.path = path
        self.name = "file"


class CacheManager(DriverManager):
    def create_memory_driver(self, config: dict):
        return MemoryCache()

    def create_redis_driver(self, config: dict):
        return RedisCache(host=config.get("host", "localhost"))

    def create_file_driver(self, config: dict):
        return FileCache(path=config.get("path", "/tmp"))

    def get_default_driver(self) -> str:
        return self.config.get("default", "memory")


class TestDriverManager:
    def test_creates_driver_by_name(self):
        app = Container()
        manager = CacheManager(app, {"default": "memory"})
        driver = manager.driver("memory")
        assert isinstance(driver, MemoryCache)

    def test_default_driver(self):
        app = Container()
        manager = CacheManager(app, {"default": "redis", "drivers": {"redis": {"host": "redis.local"}}})
        driver = manager.driver()
        assert isinstance(driver, RedisCache)
        assert driver.host == "redis.local"

    def test_driver_cached_on_second_call(self):
        app = Container()
        manager = CacheManager(app, {"default": "memory"})
        first = manager.driver("memory")
        second = manager.driver("memory")
        assert first is second

    def test_extend_registers_custom_driver(self):
        app = Container()
        manager = CacheManager(app, {"default": "memory"})

        class DynamoCache:
            name = "dynamo"

        manager.extend("dynamo", lambda config: DynamoCache())
        driver = manager.driver("dynamo")
        assert isinstance(driver, DynamoCache)

    def test_unknown_driver_raises(self):
        app = Container()
        manager = CacheManager(app, {"default": "memory"})
        with pytest.raises(ResolutionError, match="not supported"):
            manager.driver("postgres")
