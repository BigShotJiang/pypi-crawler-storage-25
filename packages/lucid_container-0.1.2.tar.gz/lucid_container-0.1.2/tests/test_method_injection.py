from abc import ABC, abstractmethod

import pytest

from lucid_container import Container, ResolutionError


class MailerContract(ABC):
    @abstractmethod
    def send(self, to: str, body: str) -> None: ...


class FakeMailer(MailerContract):
    def __init__(self):
        self.sent: list[tuple[str, str]] = []

    def send(self, to: str, body: str) -> None:
        self.sent.append((to, body))


class CacheContract(ABC):
    @abstractmethod
    def get(self, key: str) -> str: ...


class MemoryCache(CacheContract):
    def get(self, key: str) -> str:
        return key


def send_welcome(user_id: int, mailer: MailerContract) -> str:
    mailer.send(f"user-{user_id}@test.com", "Welcome!")
    return "sent"


class Greeter:
    def greet(self, name: str, mailer: MailerContract) -> str:
        mailer.send(f"{name}@test.com", "Hello!")
        return f"greeted {name}"


class TestMethodInjection:
    def test_call_injects_from_container(self):
        app = Container()
        mailer = FakeMailer()
        app.instance(MailerContract, mailer)
        result = app.call(send_welcome, {"user_id": 42})
        assert result == "sent"
        assert mailer.sent == [("user-42@test.com", "Welcome!")]

    def test_call_explicit_args_override(self):
        app = Container()
        mailer = FakeMailer()
        app.instance(MailerContract, mailer)
        custom_mailer = FakeMailer()
        result = app.call(send_welcome, {"user_id": 1, "mailer": custom_mailer})
        assert result == "sent"
        assert len(custom_mailer.sent) == 1
        assert len(mailer.sent) == 0

    def test_call_with_bound_method(self):
        app = Container()
        mailer = FakeMailer()
        app.instance(MailerContract, mailer)
        greeter = Greeter()
        result = app.call(greeter.greet, {"name": "Alice"})
        assert result == "greeted Alice"
        assert mailer.sent == [("Alice@test.com", "Hello!")]

    def test_call_unresolvable_raises(self):
        app = Container()
        with pytest.raises(ResolutionError):
            app.call(send_welcome, {})  # no user_id, no mailer
