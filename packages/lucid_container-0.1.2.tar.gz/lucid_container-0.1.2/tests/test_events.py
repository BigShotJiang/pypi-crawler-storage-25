from abc import ABC, abstractmethod

from lucid_container import Container


class LoggerContract(ABC):
    @abstractmethod
    def log(self, msg: str) -> None: ...


class ConsoleLogger(LoggerContract):
    def __init__(self):
        self.tag = None

    def log(self, msg: str) -> None:
        pass


class TestResolvingCallbacks:
    def test_resolving_fires_with_instance_and_container(self):
        app = Container()
        app.bind(LoggerContract, ConsoleLogger)
        received = []

        def cb(instance, container):
            received.append((instance, container))
            return instance

        app.resolving(LoggerContract, cb)
        logger = app.make(LoggerContract)

        assert len(received) == 1
        assert received[0][0] is logger
        assert received[0][1] is app

    def test_resolving_return_value_replaces_instance(self):
        app = Container()
        app.bind(LoggerContract, ConsoleLogger)

        def decorate(instance, container):
            instance.tag = "decorated"
            return instance

        app.resolving(LoggerContract, decorate)
        logger = app.make(LoggerContract)
        assert logger.tag == "decorated"

    def test_after_resolving_fires(self):
        app = Container()
        app.bind(LoggerContract, ConsoleLogger)
        called = []

        app.after_resolving(LoggerContract, lambda inst, c: called.append(inst))
        logger = app.make(LoggerContract)

        assert len(called) == 1
        assert called[0] is logger

    def test_resolving_any_fires_for_every_resolution(self):
        app = Container()
        app.bind(LoggerContract, ConsoleLogger)
        app.instance("config", {"debug": True})
        resolved_types = []

        app.resolving_any(lambda inst, c: resolved_types.append(type(inst).__name__))

        app.make(LoggerContract)
        app.make("config")

        assert "ConsoleLogger" in resolved_types
        assert "dict" in resolved_types

    def test_multiple_callbacks_fire_in_order(self):
        app = Container()
        app.bind(LoggerContract, ConsoleLogger)
        order = []

        app.resolving(LoggerContract, lambda i, c: order.append("first") or i)
        app.resolving(LoggerContract, lambda i, c: order.append("second") or i)

        app.make(LoggerContract)
        assert order == ["first", "second"]
