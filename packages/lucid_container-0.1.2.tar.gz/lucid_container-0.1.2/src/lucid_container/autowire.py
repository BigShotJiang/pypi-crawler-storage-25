from __future__ import annotations

import inspect
import typing

PRIMITIVES = frozenset({str, int, float, bool, bytes, type(None)})


def get_dependencies(cls: type) -> list[tuple[str, type | None, bool]]:
    """Inspect cls.__init__ and return (name, type_hint, has_default) tuples.

    Skips ``self``, ``*args``, and ``**kwargs``.
    """
    try:
        hints = typing.get_type_hints(cls.__init__)
    except Exception:
        hints = {}

    try:
        sig = inspect.signature(cls.__init__)
    except (ValueError, TypeError):
        return []

    deps: list[tuple[str, type | None, bool]] = []
    for name, param in sig.parameters.items():
        if name == "self":
            continue
        if param.kind in (param.VAR_POSITIONAL, param.VAR_KEYWORD):
            continue
        hint = hints.get(name)
        has_default = param.default is not param.empty
        deps.append((name, hint, has_default))
    return deps
