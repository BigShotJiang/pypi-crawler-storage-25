from __future__ import annotations

import inspect
import typing
from typing import Any, Callable

from .autowire import PRIMITIVES, get_dependencies
from .contextual_binding import ContextualBindingBuilder
from .exceptions import BindingError, CircularDependencyError, ResolutionError


class Container:
    """IoC container with autowiring, contextual bindings, and scoped children."""

    def __init__(self) -> None:
        self._bindings: dict[Any, Callable[..., Any]] = {}
        self._singleton_keys: set[Any] = set()
        self._singletons: dict[Any, Any] = {}
        self._instance_keys: set[Any] = set()
        self._aliases: dict[str, Any] = {}
        self._tags: dict[str, list[Any]] = {}
        self._contextual: dict[type, dict[Any, Any]] = {}
        self._resolving_callbacks: dict[Any, list[Callable[..., Any]]] = {}
        self._after_resolving_callbacks: dict[Any, list[Callable[..., Any]]] = {}
        self._global_resolving_callbacks: list[Callable[..., Any]] = []
        self._providers: list[Any] = []
        self._build_stack: list[type] = []

    # ------------------------------------------------------------------
    # Binding
    # ------------------------------------------------------------------

    def bind(self, abstract: Any, concrete: Any) -> None:
        """Register a binding. Every ``make(abstract)`` creates a new instance."""
        if not callable(concrete):
            raise BindingError(
                f"Concrete must be callable, got {type(concrete).__name__}"
            )
        self._bindings[abstract] = concrete
        self._singleton_keys.discard(abstract)
        self._singletons.pop(abstract, None)
        self._instance_keys.discard(abstract)

    def singleton(self, abstract: Any, concrete: Any) -> None:
        """Like ``bind()``, but the instance is created once and cached."""
        if not callable(concrete):
            raise BindingError(
                f"Concrete must be callable, got {type(concrete).__name__}"
            )
        self._bindings[abstract] = concrete
        self._singleton_keys.add(abstract)
        self._singletons.pop(abstract, None)
        self._instance_keys.discard(abstract)

    def instance(self, abstract: Any, obj: Any) -> None:
        """Register an existing object as a singleton."""
        self._singletons[abstract] = obj
        self._instance_keys.add(abstract)
        self._bindings.pop(abstract, None)
        self._singleton_keys.discard(abstract)

    # ------------------------------------------------------------------
    # Aliases
    # ------------------------------------------------------------------

    def alias(self, name: str, abstract: Any) -> None:
        """Create a shorthand *name* for *abstract*."""
        self._aliases[name] = abstract

    def _resolve_alias(self, abstract: Any) -> Any:
        seen: set[Any] = set()
        while abstract in self._aliases:
            if abstract in seen:
                raise ResolutionError(f"Circular alias detected: {abstract}")
            seen.add(abstract)
            abstract = self._aliases[abstract]
        return abstract

    # ------------------------------------------------------------------
    # Resolution
    # ------------------------------------------------------------------

    def make(self, abstract: Any) -> Any:
        """Resolve *abstract* to a fully constructed instance."""
        abstract = self._resolve_alias(abstract)

        # Self-reference
        if abstract is Container:
            return self

        # Singleton cache (fire global callbacks even for cached instances)
        if abstract in self._singletons:
            instance = self._singletons[abstract]
            for cb in self._global_resolving_callbacks:
                cb(instance, self)
            return instance

        # Determine concrete
        contextual = self._get_contextual(abstract)
        if contextual is not None:
            concrete = contextual
        elif abstract in self._bindings:
            concrete = self._bindings[abstract]
        elif inspect.isclass(abstract) and not inspect.isabstract(abstract):
            concrete = abstract
        else:
            raise ResolutionError(f"Cannot resolve {abstract!r}: no binding found")

        # Build instance
        if inspect.isclass(concrete):
            instance = self._autowire(concrete)
        elif callable(concrete):
            instance = concrete(self)
        else:
            instance = concrete

        # Fire callbacks
        instance = self._fire_callbacks(abstract, instance)

        # Cache singleton
        if abstract in self._singleton_keys:
            self._singletons[abstract] = instance

        return instance

    def _get_contextual(self, abstract: Any) -> Any | None:
        for consumer in reversed(self._build_stack):
            ctx = self._contextual.get(consumer)
            if ctx is not None and abstract in ctx:
                return ctx[abstract]
        return None

    def _autowire(self, concrete: type) -> Any:
        if concrete in self._build_stack:
            cycle = self._build_stack[self._build_stack.index(concrete) :] + [concrete]
            raise CircularDependencyError(cycle)

        self._build_stack.append(concrete)
        try:
            deps = get_dependencies(concrete)
            kwargs: dict[str, Any] = {}

            for name, hint, has_default in deps:
                if hint is None or hint in PRIMITIVES:
                    if has_default:
                        continue
                    if hint is None:
                        raise ResolutionError(
                            f"Cannot resolve parameter '{name}' of "
                            f"{concrete.__name__}: no type hint"
                        )
                    raise ResolutionError(
                        f"Cannot resolve parameter '{name}' of "
                        f"{concrete.__name__}: primitive type "
                        f"{hint.__name__} with no default"
                    )

                # Try resolving via make (handles contextual, bindings, autowire)
                try:
                    kwargs[name] = self.make(hint)
                except CircularDependencyError:
                    raise
                except ResolutionError:
                    if has_default:
                        continue
                    raise ResolutionError(
                        f"Cannot resolve parameter '{name}' of "
                        f"{concrete.__name__}: no binding for {hint!r}"
                    ) from None

            return concrete(**kwargs)
        finally:
            self._build_stack.pop()

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def has(self, abstract: Any) -> bool:
        """Return ``True`` if *abstract* is bound, aliased, or has a cached singleton."""
        if abstract in self._bindings or abstract in self._singletons:
            return True
        if abstract in self._aliases:
            return True
        return False

    def bound_to(self, abstract: Any) -> Any | None:
        """Return the concrete bound to *abstract*, or ``None``."""
        return self._bindings.get(abstract)

    def flush(self) -> None:
        """Clear all bindings, singletons, and aliases."""
        self._bindings.clear()
        self._singleton_keys.clear()
        self._singletons.clear()
        self._instance_keys.clear()
        self._aliases.clear()
        self._tags.clear()
        self._contextual.clear()
        self._resolving_callbacks.clear()
        self._after_resolving_callbacks.clear()
        self._global_resolving_callbacks.clear()
        self._providers.clear()
        self._build_stack.clear()

    # ------------------------------------------------------------------
    # Contextual binding
    # ------------------------------------------------------------------

    def when(self, consumer: type) -> ContextualBindingBuilder:
        """Begin a contextual binding definition."""
        return ContextualBindingBuilder(self, consumer)

    def _add_contextual(self, consumer: type, abstract: Any, concrete: Any) -> None:
        self._contextual.setdefault(consumer, {})[abstract] = concrete

    # ------------------------------------------------------------------
    # Tagging
    # ------------------------------------------------------------------

    def tag(self, abstracts: list[Any], tag: str) -> None:
        """Group *abstracts* under *tag*."""
        self._tags.setdefault(tag, []).extend(abstracts)

    def tagged(self, tag: str) -> list[Any]:
        """Resolve all abstracts grouped under *tag*."""
        return [self.make(a) for a in self._tags.get(tag, [])]

    # ------------------------------------------------------------------
    # Events
    # ------------------------------------------------------------------

    def resolving(self, abstract: Any, callback: Callable[..., Any]) -> None:
        """Register a callback fired every time *abstract* is resolved.

        If the callback returns a non-``None`` value it replaces the instance.
        """
        self._resolving_callbacks.setdefault(abstract, []).append(callback)

    def after_resolving(self, abstract: Any, callback: Callable[..., Any]) -> None:
        """Register a callback fired after *abstract* is resolved (side-effects only)."""
        self._after_resolving_callbacks.setdefault(abstract, []).append(callback)

    def resolving_any(self, callback: Callable[..., Any]) -> None:
        """Register a callback fired for **every** resolution."""
        self._global_resolving_callbacks.append(callback)

    def _fire_callbacks(self, abstract: Any, instance: Any) -> Any:
        for cb in self._resolving_callbacks.get(abstract, []):
            result = cb(instance, self)
            if result is not None:
                instance = result
        for cb in self._global_resolving_callbacks:
            cb(instance, self)
        for cb in self._after_resolving_callbacks.get(abstract, []):
            cb(instance, self)
        return instance

    # ------------------------------------------------------------------
    # Method injection
    # ------------------------------------------------------------------

    def call(self, fn: Callable[..., Any], args: dict[str, Any] | None = None) -> Any:
        """Call *fn*, injecting dependencies from the container.

        Explicit *args* take priority over injected values.
        """
        args = args or {}
        try:
            hints = typing.get_type_hints(fn)
        except Exception:
            hints = {}
        sig = inspect.signature(fn)
        kwargs: dict[str, Any] = {}

        for name, param in sig.parameters.items():
            if param.kind in (param.VAR_POSITIONAL, param.VAR_KEYWORD):
                continue
            if name in args:
                kwargs[name] = args[name]
                continue

            hint = hints.get(name)
            if hint is not None and hint not in PRIMITIVES:
                try:
                    kwargs[name] = self.make(hint)
                    continue
                except ResolutionError:
                    pass

            if param.default is not param.empty:
                continue

            raise ResolutionError(f"Cannot resolve parameter '{name}' for {fn!r}")

        return fn(**kwargs)

    # ------------------------------------------------------------------
    # Service providers
    # ------------------------------------------------------------------

    def register_provider(self, provider_cls: type) -> None:
        """Instantiate *provider_cls* and call its ``register()`` method."""
        provider = provider_cls(self)
        self._providers.append(provider)
        provider.register()

    def boot(self) -> None:
        """Call ``boot()`` on every registered provider, in order."""
        for provider in self._providers:
            provider.boot()

    # ------------------------------------------------------------------
    # Scoped (child) containers
    # ------------------------------------------------------------------

    def scoped(self) -> Container:
        """Return a child container that inherits bindings but has its own singleton cache."""
        child = Container()
        child._bindings = dict(self._bindings)
        child._singleton_keys = set(self._singleton_keys)
        child._aliases = dict(self._aliases)
        child._tags = {k: list(v) for k, v in self._tags.items()}
        child._contextual = {k: dict(v) for k, v in self._contextual.items()}
        child._resolving_callbacks = {
            k: list(v) for k, v in self._resolving_callbacks.items()
        }
        child._after_resolving_callbacks = {
            k: list(v) for k, v in self._after_resolving_callbacks.items()
        }
        child._global_resolving_callbacks = list(self._global_resolving_callbacks)
        # Carry over instance() objects, but NOT resolved singletons
        for key in self._instance_keys:
            child._singletons[key] = self._singletons[key]
            child._instance_keys.add(key)
        return child
