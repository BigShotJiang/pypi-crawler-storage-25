from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable

from .exceptions import ResolutionError

if TYPE_CHECKING:
    from .container import Container


class DriverManager:
    """Base class for subsystems with swappable backends.

    Subclasses define ``create_{name}_driver(self, config)`` methods and
    override ``get_default_driver()`` to return the default driver name.
    """

    def __init__(self, container: Container, config: dict[str, Any] | None = None) -> None:
        self._container = container
        self.config = config or {}
        self._drivers: dict[str, Any] = {}
        self._custom_creators: dict[str, Callable[[dict[str, Any]], Any]] = {}

    def driver(self, name: str | None = None) -> Any:
        """Return a cached driver instance. *name* defaults to ``get_default_driver()``."""
        name = name or self.get_default_driver()
        if name not in self._drivers:
            self._drivers[name] = self._create_driver(name)
        return self._drivers[name]

    def _create_driver(self, name: str) -> Any:
        driver_config = self.config.get("drivers", {}).get(name, {})

        if name in self._custom_creators:
            return self._custom_creators[name](driver_config)

        method_name = f"create_{name}_driver"
        creator = getattr(self, method_name, None)
        if creator is not None:
            return creator(driver_config)

        raise ResolutionError(f"Driver '{name}' is not supported.")

    def extend(self, name: str, creator: Callable[[dict[str, Any]], Any]) -> None:
        """Register a custom driver creator at runtime."""
        self._custom_creators[name] = creator

    def get_default_driver(self) -> str:
        """Return the name of the default driver. Must be overridden."""
        raise NotImplementedError("Subclasses must implement get_default_driver()")
