class ResolutionError(Exception):
    """Cannot resolve an abstract - no binding, no autowiring possible."""


class BindingError(Exception):
    """Invalid binding (e.g., binding to a non-callable)."""


class CircularDependencyError(ResolutionError):
    """A depends on B depends on A. Includes the cycle path."""

    def __init__(self, cycle: list[type]):
        path = " -> ".join(
            t.__name__ if hasattr(t, "__name__") else str(t) for t in cycle
        )
        super().__init__(f"Circular dependency detected: {path}")
        self.cycle = cycle
