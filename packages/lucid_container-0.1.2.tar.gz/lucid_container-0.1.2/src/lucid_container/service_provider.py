from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .container import Container


class ServiceProvider:
    """Base class for service providers.

    Subclasses implement ``register()`` to bind services and ``boot()``
    to perform post-registration setup.
    """

    def __init__(self, app: Container) -> None:
        self.app = app

    def register(self) -> None:
        """Bind services into the container. Called immediately on registration."""

    def boot(self) -> None:
        """Called after ALL providers have registered. Safe to resolve."""
