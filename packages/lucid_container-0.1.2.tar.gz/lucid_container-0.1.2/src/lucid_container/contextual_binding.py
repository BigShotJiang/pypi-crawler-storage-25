from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .container import Container


class ContextualBindingBuilder:
    """Fluent builder for contextual bindings: container.when(A).needs(X).give(Y)."""

    def __init__(self, container: Container, consumer: type) -> None:
        self._container = container
        self._consumer = consumer
        self._abstract: Any = None

    def needs(self, abstract: Any) -> ContextualBindingBuilder:
        self._abstract = abstract
        return self

    def give(self, concrete: Any) -> None:
        self._container._add_contextual(self._consumer, self._abstract, concrete)
