"""Report generators for Rosetta."""
