from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.budget_window_batch_status_response_child_jobs import BudgetWindowBatchStatusResponseChildJobs
    from ..models.budget_window_result import BudgetWindowResult
    from ..models.policy_engine_bundle import PolicyEngineBundle


T = TypeVar("T", bound="BudgetWindowBatchStatusResponse")


@_attrs_define
class BudgetWindowBatchStatusResponse:
    """Response model for budget-window batch polling.

    Attributes:
        status (str):
        progress (int | None | Unset):
        completed_years (list[str] | Unset):
        running_years (list[str] | Unset):
        queued_years (list[str] | Unset):
        failed_years (list[str] | Unset):
        child_jobs (BudgetWindowBatchStatusResponseChildJobs | Unset):
        result (BudgetWindowResult | None | Unset):
        error (None | str | Unset):
        resolved_app_name (None | str | Unset):
        policyengine_bundle (None | PolicyEngineBundle | Unset):
        run_id (None | str | Unset):
    """

    status: str
    progress: int | None | Unset = UNSET
    completed_years: list[str] | Unset = UNSET
    running_years: list[str] | Unset = UNSET
    queued_years: list[str] | Unset = UNSET
    failed_years: list[str] | Unset = UNSET
    child_jobs: BudgetWindowBatchStatusResponseChildJobs | Unset = UNSET
    result: BudgetWindowResult | None | Unset = UNSET
    error: None | str | Unset = UNSET
    resolved_app_name: None | str | Unset = UNSET
    policyengine_bundle: None | PolicyEngineBundle | Unset = UNSET
    run_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.budget_window_result import BudgetWindowResult
        from ..models.policy_engine_bundle import PolicyEngineBundle

        status = self.status

        progress: int | None | Unset
        if isinstance(self.progress, Unset):
            progress = UNSET
        else:
            progress = self.progress

        completed_years: list[str] | Unset = UNSET
        if not isinstance(self.completed_years, Unset):
            completed_years = self.completed_years

        running_years: list[str] | Unset = UNSET
        if not isinstance(self.running_years, Unset):
            running_years = self.running_years

        queued_years: list[str] | Unset = UNSET
        if not isinstance(self.queued_years, Unset):
            queued_years = self.queued_years

        failed_years: list[str] | Unset = UNSET
        if not isinstance(self.failed_years, Unset):
            failed_years = self.failed_years

        child_jobs: dict[str, Any] | Unset = UNSET
        if not isinstance(self.child_jobs, Unset):
            child_jobs = self.child_jobs.to_dict()

        result: dict[str, Any] | None | Unset
        if isinstance(self.result, Unset):
            result = UNSET
        elif isinstance(self.result, BudgetWindowResult):
            result = self.result.to_dict()
        else:
            result = self.result

        error: None | str | Unset
        if isinstance(self.error, Unset):
            error = UNSET
        else:
            error = self.error

        resolved_app_name: None | str | Unset
        if isinstance(self.resolved_app_name, Unset):
            resolved_app_name = UNSET
        else:
            resolved_app_name = self.resolved_app_name

        policyengine_bundle: dict[str, Any] | None | Unset
        if isinstance(self.policyengine_bundle, Unset):
            policyengine_bundle = UNSET
        elif isinstance(self.policyengine_bundle, PolicyEngineBundle):
            policyengine_bundle = self.policyengine_bundle.to_dict()
        else:
            policyengine_bundle = self.policyengine_bundle

        run_id: None | str | Unset
        if isinstance(self.run_id, Unset):
            run_id = UNSET
        else:
            run_id = self.run_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "status": status,
            }
        )
        if progress is not UNSET:
            field_dict["progress"] = progress
        if completed_years is not UNSET:
            field_dict["completed_years"] = completed_years
        if running_years is not UNSET:
            field_dict["running_years"] = running_years
        if queued_years is not UNSET:
            field_dict["queued_years"] = queued_years
        if failed_years is not UNSET:
            field_dict["failed_years"] = failed_years
        if child_jobs is not UNSET:
            field_dict["child_jobs"] = child_jobs
        if result is not UNSET:
            field_dict["result"] = result
        if error is not UNSET:
            field_dict["error"] = error
        if resolved_app_name is not UNSET:
            field_dict["resolved_app_name"] = resolved_app_name
        if policyengine_bundle is not UNSET:
            field_dict["policyengine_bundle"] = policyengine_bundle
        if run_id is not UNSET:
            field_dict["run_id"] = run_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.budget_window_batch_status_response_child_jobs import BudgetWindowBatchStatusResponseChildJobs
        from ..models.budget_window_result import BudgetWindowResult
        from ..models.policy_engine_bundle import PolicyEngineBundle

        d = dict(src_dict)
        status = d.pop("status")

        def _parse_progress(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        progress = _parse_progress(d.pop("progress", UNSET))

        completed_years = cast(list[str], d.pop("completed_years", UNSET))

        running_years = cast(list[str], d.pop("running_years", UNSET))

        queued_years = cast(list[str], d.pop("queued_years", UNSET))

        failed_years = cast(list[str], d.pop("failed_years", UNSET))

        _child_jobs = d.pop("child_jobs", UNSET)
        child_jobs: BudgetWindowBatchStatusResponseChildJobs | Unset
        if isinstance(_child_jobs, Unset):
            child_jobs = UNSET
        else:
            child_jobs = BudgetWindowBatchStatusResponseChildJobs.from_dict(_child_jobs)

        def _parse_result(data: object) -> BudgetWindowResult | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                result_type_0 = BudgetWindowResult.from_dict(data)

                return result_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(BudgetWindowResult | None | Unset, data)

        result = _parse_result(d.pop("result", UNSET))

        def _parse_error(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error = _parse_error(d.pop("error", UNSET))

        def _parse_resolved_app_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        resolved_app_name = _parse_resolved_app_name(d.pop("resolved_app_name", UNSET))

        def _parse_policyengine_bundle(data: object) -> None | PolicyEngineBundle | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                policyengine_bundle_type_0 = PolicyEngineBundle.from_dict(data)

                return policyengine_bundle_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PolicyEngineBundle | Unset, data)

        policyengine_bundle = _parse_policyengine_bundle(d.pop("policyengine_bundle", UNSET))

        def _parse_run_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        run_id = _parse_run_id(d.pop("run_id", UNSET))

        budget_window_batch_status_response = cls(
            status=status,
            progress=progress,
            completed_years=completed_years,
            running_years=running_years,
            queued_years=queued_years,
            failed_years=failed_years,
            child_jobs=child_jobs,
            result=result,
            error=error,
            resolved_app_name=resolved_app_name,
            policyengine_bundle=policyengine_bundle,
            run_id=run_id,
        )

        budget_window_batch_status_response.additional_properties = d
        return budget_window_batch_status_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
