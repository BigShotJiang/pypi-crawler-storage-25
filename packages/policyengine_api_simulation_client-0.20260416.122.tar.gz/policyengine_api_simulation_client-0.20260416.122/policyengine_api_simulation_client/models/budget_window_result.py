from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.budget_window_annual_impact import BudgetWindowAnnualImpact
    from ..models.budget_window_totals import BudgetWindowTotals


T = TypeVar("T", bound="BudgetWindowResult")


@_attrs_define
class BudgetWindowResult:
    """Completed budget-window output.

    Attributes:
        start_year (str):
        end_year (str):
        window_size (int):
        totals (BudgetWindowTotals): Aggregate totals for a completed budget-window response.
        kind (Literal['budgetWindow'] | Unset):  Default: 'budgetWindow'.
        annual_impacts (list[BudgetWindowAnnualImpact] | Unset):
    """

    start_year: str
    end_year: str
    window_size: int
    totals: BudgetWindowTotals
    kind: Literal["budgetWindow"] | Unset = "budgetWindow"
    annual_impacts: list[BudgetWindowAnnualImpact] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        start_year = self.start_year

        end_year = self.end_year

        window_size = self.window_size

        totals = self.totals.to_dict()

        kind = self.kind

        annual_impacts: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.annual_impacts, Unset):
            annual_impacts = []
            for annual_impacts_item_data in self.annual_impacts:
                annual_impacts_item = annual_impacts_item_data.to_dict()
                annual_impacts.append(annual_impacts_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "startYear": start_year,
                "endYear": end_year,
                "windowSize": window_size,
                "totals": totals,
            }
        )
        if kind is not UNSET:
            field_dict["kind"] = kind
        if annual_impacts is not UNSET:
            field_dict["annualImpacts"] = annual_impacts

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.budget_window_annual_impact import BudgetWindowAnnualImpact
        from ..models.budget_window_totals import BudgetWindowTotals

        d = dict(src_dict)
        start_year = d.pop("startYear")

        end_year = d.pop("endYear")

        window_size = d.pop("windowSize")

        totals = BudgetWindowTotals.from_dict(d.pop("totals"))

        kind = cast(Literal["budgetWindow"] | Unset, d.pop("kind", UNSET))
        if kind != "budgetWindow" and not isinstance(kind, Unset):
            raise ValueError(f"kind must match const 'budgetWindow', got '{kind}'")

        _annual_impacts = d.pop("annualImpacts", UNSET)
        annual_impacts: list[BudgetWindowAnnualImpact] | Unset = UNSET
        if _annual_impacts is not UNSET:
            annual_impacts = []
            for annual_impacts_item_data in _annual_impacts:
                annual_impacts_item = BudgetWindowAnnualImpact.from_dict(annual_impacts_item_data)

                annual_impacts.append(annual_impacts_item)

        budget_window_result = cls(
            start_year=start_year,
            end_year=end_year,
            window_size=window_size,
            totals=totals,
            kind=kind,
            annual_impacts=annual_impacts,
        )

        budget_window_result.additional_properties = d
        return budget_window_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
