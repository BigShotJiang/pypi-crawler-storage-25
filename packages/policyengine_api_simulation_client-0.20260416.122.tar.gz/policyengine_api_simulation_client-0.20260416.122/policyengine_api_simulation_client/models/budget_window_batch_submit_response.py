from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.policy_engine_bundle import PolicyEngineBundle


T = TypeVar("T", bound="BudgetWindowBatchSubmitResponse")


@_attrs_define
class BudgetWindowBatchSubmitResponse:
    """Response model for budget-window batch submission.

    Attributes:
        batch_job_id (str):
        status (str):
        poll_url (str):
        country (str):
        version (str):
        resolved_app_name (str):
        policyengine_bundle (PolicyEngineBundle): Resolved runtime provenance returned by the gateway.
        run_id (None | str | Unset):
    """

    batch_job_id: str
    status: str
    poll_url: str
    country: str
    version: str
    resolved_app_name: str
    policyengine_bundle: PolicyEngineBundle
    run_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        batch_job_id = self.batch_job_id

        status = self.status

        poll_url = self.poll_url

        country = self.country

        version = self.version

        resolved_app_name = self.resolved_app_name

        policyengine_bundle = self.policyengine_bundle.to_dict()

        run_id: None | str | Unset
        if isinstance(self.run_id, Unset):
            run_id = UNSET
        else:
            run_id = self.run_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "batch_job_id": batch_job_id,
                "status": status,
                "poll_url": poll_url,
                "country": country,
                "version": version,
                "resolved_app_name": resolved_app_name,
                "policyengine_bundle": policyengine_bundle,
            }
        )
        if run_id is not UNSET:
            field_dict["run_id"] = run_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.policy_engine_bundle import PolicyEngineBundle

        d = dict(src_dict)
        batch_job_id = d.pop("batch_job_id")

        status = d.pop("status")

        poll_url = d.pop("poll_url")

        country = d.pop("country")

        version = d.pop("version")

        resolved_app_name = d.pop("resolved_app_name")

        policyengine_bundle = PolicyEngineBundle.from_dict(d.pop("policyengine_bundle"))

        def _parse_run_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        run_id = _parse_run_id(d.pop("run_id", UNSET))

        budget_window_batch_submit_response = cls(
            batch_job_id=batch_job_id,
            status=status,
            poll_url=poll_url,
            country=country,
            version=version,
            resolved_app_name=resolved_app_name,
            policyengine_bundle=policyengine_bundle,
            run_id=run_id,
        )

        budget_window_batch_submit_response.additional_properties = d
        return budget_window_batch_submit_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
