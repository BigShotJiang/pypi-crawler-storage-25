from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="BudgetWindowTotals")


@_attrs_define
class BudgetWindowTotals:
    """Aggregate totals for a completed budget-window response.

    Attributes:
        tax_revenue_impact (float):
        federal_tax_revenue_impact (float):
        state_tax_revenue_impact (float):
        benefit_spending_impact (float):
        budgetary_impact (float):
        year (Literal['Total'] | Unset):  Default: 'Total'.
    """

    tax_revenue_impact: float
    federal_tax_revenue_impact: float
    state_tax_revenue_impact: float
    benefit_spending_impact: float
    budgetary_impact: float
    year: Literal["Total"] | Unset = "Total"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        tax_revenue_impact = self.tax_revenue_impact

        federal_tax_revenue_impact = self.federal_tax_revenue_impact

        state_tax_revenue_impact = self.state_tax_revenue_impact

        benefit_spending_impact = self.benefit_spending_impact

        budgetary_impact = self.budgetary_impact

        year = self.year

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "taxRevenueImpact": tax_revenue_impact,
                "federalTaxRevenueImpact": federal_tax_revenue_impact,
                "stateTaxRevenueImpact": state_tax_revenue_impact,
                "benefitSpendingImpact": benefit_spending_impact,
                "budgetaryImpact": budgetary_impact,
            }
        )
        if year is not UNSET:
            field_dict["year"] = year

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        tax_revenue_impact = d.pop("taxRevenueImpact")

        federal_tax_revenue_impact = d.pop("federalTaxRevenueImpact")

        state_tax_revenue_impact = d.pop("stateTaxRevenueImpact")

        benefit_spending_impact = d.pop("benefitSpendingImpact")

        budgetary_impact = d.pop("budgetaryImpact")

        year = cast(Literal["Total"] | Unset, d.pop("year", UNSET))
        if year != "Total" and not isinstance(year, Unset):
            raise ValueError(f"year must match const 'Total', got '{year}'")

        budget_window_totals = cls(
            tax_revenue_impact=tax_revenue_impact,
            federal_tax_revenue_impact=federal_tax_revenue_impact,
            state_tax_revenue_impact=state_tax_revenue_impact,
            benefit_spending_impact=benefit_spending_impact,
            budgetary_impact=budgetary_impact,
            year=year,
        )

        budget_window_totals.additional_properties = d
        return budget_window_totals

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
