from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.budget_window_batch_status_response import BudgetWindowBatchStatusResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    batch_job_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/budget-window-jobs/{batch_job_id}".format(
            batch_job_id=quote(str(batch_job_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | BudgetWindowBatchStatusResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = BudgetWindowBatchStatusResponse.from_dict(response.json())

        return response_200

    if response.status_code == 202:
        response_202 = cast(Any, None)
        return response_202

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = cast(Any, None)
        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | BudgetWindowBatchStatusResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    batch_job_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[Any | BudgetWindowBatchStatusResponse | HTTPValidationError]:
    """Get Budget Window Job Status

     Poll for budget-window batch status.

    Args:
        batch_job_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | BudgetWindowBatchStatusResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        batch_job_id=batch_job_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    batch_job_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Any | BudgetWindowBatchStatusResponse | HTTPValidationError | None:
    """Get Budget Window Job Status

     Poll for budget-window batch status.

    Args:
        batch_job_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | BudgetWindowBatchStatusResponse | HTTPValidationError
    """

    return sync_detailed(
        batch_job_id=batch_job_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    batch_job_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[Any | BudgetWindowBatchStatusResponse | HTTPValidationError]:
    """Get Budget Window Job Status

     Poll for budget-window batch status.

    Args:
        batch_job_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | BudgetWindowBatchStatusResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        batch_job_id=batch_job_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    batch_job_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Any | BudgetWindowBatchStatusResponse | HTTPValidationError | None:
    """Get Budget Window Job Status

     Poll for budget-window batch status.

    Args:
        batch_job_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | BudgetWindowBatchStatusResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            batch_job_id=batch_job_id,
            client=client,
        )
    ).parsed
