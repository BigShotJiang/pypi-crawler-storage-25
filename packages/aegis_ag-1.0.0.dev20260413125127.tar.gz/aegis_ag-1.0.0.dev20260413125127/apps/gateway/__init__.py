"""Gateway application bootstrap."""

from .catalog import (
    CHAT_BOT_ADAPTER_ID,
    TELEGRAM_ADAPTER_ID,
    WEBHOOK_ADAPTER_ID,
)
from .factory import build_gateway_app
from .runtime import (
    ChatBotMessagingAdapter,
    GatewayApp,
    GatewayVoiceExchange,
    TelegramMessagingAdapter,
    WebhookMessagingAdapter,
)

__all__ = [
    "CHAT_BOT_ADAPTER_ID",
    "TELEGRAM_ADAPTER_ID",
    "WEBHOOK_ADAPTER_ID",
    "ChatBotMessagingAdapter",
    "GatewayApp",
    "GatewayVoiceExchange",
    "TelegramMessagingAdapter",
    "WebhookMessagingAdapter",
    "build_gateway_app",
]
