"""Procedural skill packages for Aegis."""

from .builtins import builtin_skill_definitions
from .hub import (
    SkillHub,
    SkillHubEntry,
    SkillHubSource,
    builtin_aegis_skill_source_root,
    default_aegis_skill_source_root,
    default_skill_hub_sources,
)
from .inventory import SKILL_SURFACES
from .runtime import (
    InMemorySkillCatalog,
    JsonSkillLoader,
    SkillPackageLoader,
    SkillActivationContext,
    SkillActivationRecord,
    SkillCatalog,
    SkillDefinition,
    SkillDependency,
    SkillLoader,
    SkillManifest,
    SkillManifestLoadRecord,
    SkillRuntime,
    SkillScope,
    load_skill_package_definition,
)

__all__ = [
    "InMemorySkillCatalog",
    "JsonSkillLoader",
    "SKILL_SURFACES",
    "SkillHub",
    "SkillHubEntry",
    "SkillHubSource",
    "SkillActivationContext",
    "SkillActivationRecord",
    "SkillCatalog",
    "SkillDefinition",
    "SkillDependency",
    "SkillLoader",
    "SkillManifest",
    "SkillManifestLoadRecord",
    "SkillPackageLoader",
    "SkillRuntime",
    "SkillScope",
    "builtin_skill_definitions",
    "builtin_aegis_skill_source_root",
    "default_aegis_skill_source_root",
    "default_skill_hub_sources",
    "load_skill_package_definition",
]
