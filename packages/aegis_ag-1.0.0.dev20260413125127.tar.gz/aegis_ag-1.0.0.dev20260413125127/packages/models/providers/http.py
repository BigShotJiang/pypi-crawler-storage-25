"""Shared JSON-over-HTTP execution helpers for provider adapters."""

from __future__ import annotations

from dataclasses import dataclass
import json
import shutil
import ssl
import subprocess
from typing import Any, Mapping, Protocol, runtime_checkable
from urllib import error, request


@dataclass(frozen=True, slots=True)
class JSONHTTPResponse:
    status_code: int
    headers: Mapping[str, str]
    payload: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class JSONHTTPStreamChunk:
    event: str | None
    payload: Mapping[str, Any]


@runtime_checkable
class JSONHTTPTransport(Protocol):
    def post_json(
        self,
        *,
        url: str,
        headers: Mapping[str, str],
        payload: Mapping[str, Any],
    ) -> JSONHTTPResponse:
        """Send a JSON POST request and return the decoded JSON body."""

    def post_json_stream(
        self,
        *,
        url: str,
        headers: Mapping[str, str],
        payload: Mapping[str, Any],
    ):
        """Send a JSON POST request and yield decoded SSE payloads."""


class UrllibJSONHTTPTransport:
    """Standard-library JSON transport for deterministic local and live use."""

    def __init__(self, *, timeout_seconds: float = 30.0) -> None:
        self.timeout_seconds = timeout_seconds

    def post_json(
        self,
        *,
        url: str,
        headers: Mapping[str, str],
        payload: Mapping[str, Any],
    ) -> JSONHTTPResponse:
        body = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
        request_headers = dict(headers)
        request_headers.setdefault("Content-Type", "application/json")
        http_request = request.Request(
            url,
            data=body,
            headers=request_headers,
            method="POST",
        )
        try:
            with request.urlopen(http_request, timeout=self.timeout_seconds) as response:
                raw_body = response.read().decode("utf-8")
                parsed = json.loads(raw_body) if raw_body else {}
                if not isinstance(parsed, dict):
                    raise RuntimeError("provider response must be a JSON object")
                return JSONHTTPResponse(
                    status_code=response.status,
                    headers={str(key).lower(): str(value) for key, value in response.headers.items()},
                    payload=parsed,
                )
        except error.HTTPError as exc:  # pragma: no cover - exercised by callers
            message = self._error_message(exc)
            raise RuntimeError(message) from exc
        except error.URLError as exc:  # pragma: no cover - exercised by callers
            if self._should_retry_with_curl(exc):
                return self._post_json_with_curl(
                    url=url,
                    headers=request_headers,
                    body=body,
                )
            raise RuntimeError(f"provider request failed for {url}: {exc.reason}") from exc

    def _error_message(self, exc: error.HTTPError) -> str:
        try:
            body = exc.read().decode("utf-8", errors="replace").strip()
        except Exception:  # pragma: no cover - defensive fallback
            body = ""
        detail = f" {body[:200]}" if body else ""
        return f"provider request failed with status {exc.code}.{detail}".strip()

    def _should_retry_with_curl(self, exc: error.URLError) -> bool:
        reason = exc.reason
        if isinstance(reason, ssl.SSLError):
            return "WRONG_VERSION_NUMBER" in str(reason)
        return "WRONG_VERSION_NUMBER" in str(reason)

    def _post_json_with_curl(
        self,
        *,
        url: str,
        headers: Mapping[str, str],
        body: bytes,
    ) -> JSONHTTPResponse:
        curl = shutil.which("curl")
        if curl is None:
            raise RuntimeError(
                f"provider request failed for {url}: curl is unavailable for TLS fallback"
            )
        status_marker = "__AEGIS_STATUS__:"
        max_time = max(1, int(round(self.timeout_seconds)))
        connect_timeout = max(1, min(10, max_time))
        command = [
            curl,
            "--silent",
            "--show-error",
            "--location",
            "--connect-timeout",
            str(connect_timeout),
            "--max-time",
            str(max_time),
            "--request",
            "POST",
            url,
            "--data-binary",
            "@-",
            "--write-out",
            f"\n{status_marker}%{{http_code}}",
        ]
        for key, value in headers.items():
            command.extend(["--header", f"{key}: {value}"])
        result = subprocess.run(
            command,
            input=body,
            capture_output=True,
            check=False,
        )
        if result.returncode != 0:
            stderr = result.stderr.decode("utf-8", errors="replace").strip()
            raise RuntimeError(f"provider request failed for {url}: {stderr or 'curl fallback failed'}")
        raw_output = result.stdout.decode("utf-8", errors="replace")
        raw_body, separator, raw_status = raw_output.rpartition(f"\n{status_marker}")
        if not separator:
            raise RuntimeError(f"provider request failed for {url}: curl fallback missing status marker")
        try:
            status_code = int(raw_status.strip())
        except ValueError as exc:  # pragma: no cover - defensive fallback
            raise RuntimeError(f"provider request failed for {url}: invalid curl status marker") from exc
        payload = json.loads(raw_body) if raw_body else {}
        if not isinstance(payload, dict):
            raise RuntimeError("provider response must be a JSON object")
        if status_code >= 400:
            detail = raw_body[:200].strip()
            raise RuntimeError(f"provider request failed with status {status_code}.{(' ' + detail) if detail else ''}".strip())
        return JSONHTTPResponse(
            status_code=status_code,
            headers={},
            payload=payload,
        )

    def post_json_stream(
        self,
        *,
        url: str,
        headers: Mapping[str, str],
        payload: Mapping[str, Any],
    ):
        body = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
        request_headers = dict(headers)
        request_headers.setdefault("Content-Type", "application/json")
        request_headers.setdefault("Accept", "text/event-stream")
        http_request = request.Request(
            url,
            data=body,
            headers=request_headers,
            method="POST",
        )
        try:
            with request.urlopen(http_request, timeout=self.timeout_seconds) as response:
                event_name: str | None = None
                data_lines: list[str] = []
                for raw_line in response:
                    line = raw_line.decode("utf-8", errors="replace").rstrip("\r\n")
                    if not line:
                        if not data_lines:
                            event_name = None
                            continue
                        raw_payload = "\n".join(data_lines)
                        data_lines = []
                        if raw_payload.strip() == "[DONE]":
                            return
                        parsed = json.loads(raw_payload) if raw_payload else {}
                        if isinstance(parsed, dict):
                            yield JSONHTTPStreamChunk(
                                event=event_name,
                                payload={str(key): value for key, value in parsed.items()},
                            )
                        event_name = None
                        continue
                    if line.startswith("event:"):
                        event_name = line[6:].strip() or None
                        continue
                    if line.startswith("data:"):
                        data_lines.append(line[5:].lstrip())
        except error.HTTPError as exc:  # pragma: no cover - exercised by callers
            message = self._error_message(exc)
            raise RuntimeError(message) from exc
        except error.URLError as exc:  # pragma: no cover - exercised by callers
            raise RuntimeError(f"provider request failed for {url}: {exc.reason}") from exc
