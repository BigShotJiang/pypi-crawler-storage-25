from setuptools import setup
setup(
    name="tktl_genai",
    version="0.0.0",
    py_modules=[],
)
