/* Filter Component JavaScript */

(function($) {
    'use strict';
    
    // 初始化所有过滤器组件
    function initFilterComponents() {
        const filterComponents = document.querySelectorAll('.filter-component');
        filterComponents.forEach(component => {
            initFilterComponent(component);
        });
    }
    
    // 初始化单个过滤器组件
    function initFilterComponent(filterComponent) {
        const filterId = filterComponent.id;
        if (!filterId) return;
        
        // 获取下拉面板元素
        const triggerBtn = filterComponent.querySelector('.filter-trigger-btn');
        const dropdown = filterComponent.querySelector('.filter-dropdown');
        const closeBtn = filterComponent.querySelector('.filter-dropdown-close');
        const filterCount = filterComponent.querySelector('.filter-count');
        const triggerContainer = filterComponent.querySelector('.filter-trigger-container');
        
        // Select2下拉菜单状态标志
        let select2DropdownOpen = false;
        
        // 检查必需的元素是否存在
        if (!triggerBtn || !dropdown) return;
        
        // 尝试将过滤器触发按钮移动到dashboard标题行的右侧
        function moveFilterTriggerToHeader() {
            // 查找dashboard容器
            const dashboard = filterComponent.closest('.dashboard');
            if (!dashboard) return;
            
            // 查找dashboard-header
            const dashboardHeader = dashboard.querySelector('.dashboard-header');
            if (!dashboardHeader) return;
            
            // 查找dashboard-filter-trigger-container
            let triggerTarget = dashboardHeader.querySelector('.dashboard-filter-trigger-container');
            if (!triggerTarget) {
                // 如果不存在，创建一个
                triggerTarget = document.createElement('div');
                triggerTarget.className = 'dashboard-filter-trigger-container';
                dashboardHeader.appendChild(triggerTarget);
            }
            
            // 移动触发器按钮到标题行
            if (triggerContainer && triggerBtn) {
                triggerTarget.appendChild(triggerBtn);
                // 隐藏原始触发器容器
                triggerContainer.style.display = 'none';
                
                // 将下拉面板移动到body，避免被dashboard-row隐藏
                document.body.appendChild(dropdown);
                
                // 更新dropdown定位为fixed，相对于按钮
                // 清除任何可能被CSS设置的位置值
                dropdown.style.position = 'fixed';
                dropdown.style.top = '';
                dropdown.style.left = '';
                dropdown.style.right = '';
                dropdown.style.bottom = '';
                dropdown.style.zIndex = '1001';
                
                // 隐藏filter component所在的dashboard-row，避免占用高度
                const dashboardRow = filterComponent.closest('.dashboard-row');
                if (dashboardRow) {
                    dashboardRow.style.display = 'none';
                }
                
                return true;
            }
            
            return false;
        }
        
        // 尝试移动按钮到标题行
        const movedToHeader = moveFilterTriggerToHeader();
        
        // 立即初始化Select2，避免面板显示时的高度变化闪烁
        initSelect2Filters();
        
        // 更新dropdown位置函数
        function updateDropdownPosition() {
            if (!movedToHeader || !triggerBtn || !dropdown) return;
            
            const btnRect = triggerBtn.getBoundingClientRect();
            dropdown.style.top = (btnRect.bottom + 8) + 'px';
            dropdown.style.left = 'auto';
            dropdown.style.right = (window.innerWidth - btnRect.right) + 'px';
        }
        
        // 切换下拉面板显示/隐藏
        function toggleDropdown(show) {
            const isExpanded = show !== undefined ? show : !dropdown.classList.contains('show');
            
            if (isExpanded) {
                dropdown.classList.add('show');
                triggerBtn.setAttribute('aria-expanded', 'true');
                // 更新dropdown位置
                if (movedToHeader) {
                    updateDropdownPosition();
                    // 监听窗口大小变化和滚动
                    window.addEventListener('resize', updateDropdownPosition);
                    window.addEventListener('scroll', updateDropdownPosition);
                }
                // 添加点击外部关闭监听器
                document.addEventListener('click', handleClickOutside);
            } else {
                // 关闭面板时，确保Select2下拉菜单状态标志重置
                select2DropdownOpen = false;
                
                dropdown.classList.remove('show');
                triggerBtn.setAttribute('aria-expanded', 'false');
                if (movedToHeader) {
                    window.removeEventListener('resize', updateDropdownPosition);
                    window.removeEventListener('scroll', updateDropdownPosition);
                }
                document.removeEventListener('click', handleClickOutside);
                
                // 关闭所有打开的Select2下拉菜单
                const select2Elements = dropdown.querySelectorAll('.select2-filter');
                select2Elements.forEach(select => {
                    if ($(select).data('select2')) {
                        $(select).select2('close');
                    }
                });
            }
        }
        
        // 处理点击外部关闭下拉面板
        function handleClickOutside(event) {
            // 检查点击目标是否是触发器按钮或其子元素
            const isTriggerOrChild = triggerBtn && (triggerBtn === event.target || triggerBtn.contains(event.target));
            // 检查点击目标是否在下拉面板内
            const isInDropdown = dropdown && (dropdown === event.target || dropdown.contains(event.target));
            // 检查点击目标是否在过滤器组件内（不包括已移动的按钮）
            const isInFilterComponent = filterComponent.contains(event.target);
            
            // 检查点击目标是否在Select2下拉菜单内
            let isInSelect2Dropdown = false;
            let currentElement = event.target;
            while (currentElement && currentElement !== document.body) {
                if (currentElement.classList && (
                    currentElement.classList.contains('select2-dropdown') ||
                    currentElement.classList.contains('select2-container') ||
                    currentElement.classList.contains('select2-results') ||
                    currentElement.classList.contains('select2-selection') ||
                    currentElement.classList.contains('select2-selection__rendered') ||
                    currentElement.classList.contains('select2-selection__choice') ||
                    currentElement.classList.contains('select2-selection__choice__remove') ||
                    currentElement.classList.contains('select2-search__field')
                )) {
                    isInSelect2Dropdown = true;
                    break;
                }
                currentElement = currentElement.parentElement;
            }
            
            // 如果Select2下拉菜单正在打开，则不关闭过滤器面板
            if (select2DropdownOpen) {
                return;
            }
            
            // 如果点击目标不在触发器、下拉面板、过滤器组件或Select2下拉菜单内，则关闭下拉面板
            if (!isTriggerOrChild && !isInDropdown && !isInFilterComponent && !isInSelect2Dropdown) {
                toggleDropdown(false);
            }
        }
        
        // 处理日期范围选择器变化（显示/隐藏自定义日期范围）
        function handleDateRangeChange(selectElement) {
            const dateRangeFilter = selectElement.closest('.date-range-filter');
            const customRangeDiv = dateRangeFilter.querySelector('.custom-date-range');
            if (selectElement.value === 'custom') {
                customRangeDiv.style.display = 'block';
            } else {
                customRangeDiv.style.display = 'none';
                // 清除自定义日期输入框的值，避免旧值被提交
                const dateInputs = customRangeDiv.querySelectorAll('input[type="date"]');
                dateInputs.forEach(input => {
                    input.value = '';
                });
            }
        }
        
        // 初始化Select2选择框
        function initSelect2Filters() {
            // 立即初始化Select2，避免面板显示时的高度变化闪烁
            // 从dropdown中查找select元素，因为dropdown可能被移动到body
            const selectElements = dropdown.querySelectorAll('.select2-filter');
            selectElements.forEach(select => {
                    // 检查是否是日期范围选择器
                    const isDateRange = select.classList.contains('filter-date-range');
                    
                      // 初始化Select2
                      $(select).select2({
                          width: '100%',
                          minimumResultsForSearch: 0, // 总是显示搜索框
                          dropdownParent: document.body, // 确保下拉菜单在body内，避免被overflow:hidden裁剪
                          theme: 'default',
                          closeOnSelect: !select.multiple  // 多选时不关闭下拉菜单，单选时关闭
                      });
                     
                     // 监听Select2变化事件
                     $(select).on('change', function(e) {
                         // 更新过滤器计数
                         updateFilterCount();
                         
                         // 如果是日期范围选择器，处理自定义日期范围显示
                         if (isDateRange) {
                             handleDateRangeChange(select);
                         }
                     });
                     
                     // 监听Select2下拉菜单打开/关闭事件
                     $(select).on('select2:opening', function(e) {
                         select2DropdownOpen = true;
                     });
                     
                     $(select).on('select2:closing', function(e) {
                         select2DropdownOpen = false;
                     });
                     
                     // 对于日期范围选择器，确保初始状态正确
                     if (isDateRange && select.value === 'custom') {
                         handleDateRangeChange(select);
                     }
                
            });
        }
        
        // Select2已在组件初始化时完成初始化，无需等待面板显示
        
        // 触发器按钮点击事件
        if (triggerBtn) {
            triggerBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                toggleDropdown();
            });
        }
        
        // 关闭按钮点击事件
        if (closeBtn) {
            closeBtn.addEventListener('click', function() {
                toggleDropdown(false);
            });
        }
        
        // 更新过滤器计数
        function updateFilterCount() {
            if (!filterCount) return;
            
            let count = 0;
            const form = dropdown.querySelector('.filter-form');
            if (!form) return;
            
            // 计算非空的过滤器值（排除空值：空字符串、null、undefined、"all"、空数组）
            const inputs = form.querySelectorAll('select, input[type="text"], input[type="number"], input[type="date"], input[type="checkbox"]:checked, input.number-range-min, input.number-range-max');
            inputs.forEach(input => {
                if (input.type === 'checkbox' && input.checked) {
                    count++;
                } else if (input.type === 'text' || input.type === 'number') {
                    // 文本和数字输入：非空字符串才计数
                    if (input.value.trim() !== '') count++;
                } else if (input.type === 'date') {
                    // 日期输入：非空值才计数
                    if (input.value) count++;
                } else if (input.tagName === 'SELECT') {
                    // 处理多选和单选
                    if (input.multiple) {
                        // 多选：排除空数组
                        const selectedCount = input.selectedOptions.length;
                        count += selectedCount;
                    } else {
                        // 单选：排除空字符串和特定空值（"all"、"all_time"等）
                        const value = input.value;
                        // 检查是否是日期范围选择器
                        const isDateRange = input.classList.contains('filter-date-range');
                        if (value && value !== '' && value !== 'all' && !(isDateRange && value === 'all_time')) {
                            count++;
                        }
                    }
                } else if (input.classList.contains('number-range-min') || input.classList.contains('number-range-max')) {
                    // 数值范围输入框：非空值才计数
                    if (input.value && input.value.trim() !== '') count++;
                }
            });
            
            filterCount.textContent = count;
            filterCount.setAttribute('data-filter-count', count);
            
            // 如果没有过滤器，隐藏计数
            if (count === 0) {
                filterCount.style.display = 'none';
            } else {
                filterCount.style.display = 'inline-flex';
            }
        }
        
        // 初始化过滤器计数
        updateFilterCount();
        
        // 处理日期范围选择器切换
        const dateRangeSelects = dropdown.querySelectorAll('.filter-date-range');
        dateRangeSelects.forEach(select => {
            select.addEventListener('change', function() {
                handleDateRangeChange(this);
                updateFilterCount();
            });
            
            // 触发初始状态
            if (select.value === 'custom') {
                handleDateRangeChange(select);
            }
        });
        
        // 监听所有过滤器变化以更新计数
        const filterInputs = dropdown.querySelectorAll('.filter-select, .filter-multi-select, .filter-text, .filter-number, .filter-date-range, input[type="date"], input[type="checkbox"], .number-range-min, .number-range-max');
        filterInputs.forEach(input => {
            input.addEventListener('change', updateFilterCount);
            input.addEventListener('input', function() {
                if (this.type === 'text' || this.type === 'number') {
                    updateFilterCount();
                }
            });
        });
        
        // 处理重置按钮
        const resetBtn = dropdown.querySelector('.filter-reset');
        if (resetBtn) {
            resetBtn.addEventListener('click', function() {
                const form = this.closest('.filter-form');
                
                // 重置所有输入字段
                // 1. 重置所有原生表单字段
                form.reset();
                
                // 2. 重置所有Select2选择框（单选和多选）
                const selectElements = dropdown.querySelectorAll('.select2-filter');
                selectElements.forEach(select => {
                        if (select.multiple) {
                            // 多选选择框：清空所有选择
                            $(select).val([]).trigger('change');
                        } else {
                            // 单选选择框：重置到第一个选项或默认选项
                            // form.reset()应该已经设置了原生选择框的值
                            // 我们需要手动触发Select2更新
                            $(select).trigger('change');
                        }
                    
                });
                
                // 3. 特别处理日期范围选择器的自定义日期输入框
                dateRangeSelects.forEach(select => {
                    const customRangeDiv = select.closest('.date-range-filter').querySelector('.custom-date-range');
                    const dateInputs = customRangeDiv.querySelectorAll('input[type="date"]');
                    dateInputs.forEach(input => {
                        input.value = '';
                    });
                    
                    // 触发日期范围选择器change事件以更新UI状态
                    select.dispatchEvent(new Event('change'));
                });
                
                // 4. 重置所有文本、数字输入框
                const textInputs = dropdown.querySelectorAll('input[type="text"], input[type="number"]');
                textInputs.forEach(input => {
                    input.value = '';
                });
                
                // 5. 重置复选框
                const checkboxes = dropdown.querySelectorAll('input[type="checkbox"]');
                checkboxes.forEach(checkbox => {
                    checkbox.checked = false;
                });
                
                // 6. 更新过滤器计数
                updateFilterCount();
                
                // 7. 触发过滤器重置事件
                filterComponent.dispatchEvent(new CustomEvent('filterReset', {
                    detail: { filterId: filterId }
                }));
                
                // 8. 重定向到没有过滤器参数的URL
                // 获取当前URL路径
                const currentUrl = window.location.pathname;
                
                // 获取当前URL的所有查询参数
                const currentParams = new URLSearchParams(window.location.search);
                
                // 移除所有过滤器参数（以filter_开头的参数）
                // 以及可能的多选参数（以[]结尾的）
                const filterInputs = form.querySelectorAll('select, input');
                filterInputs.forEach(input => {
                    const name = input.name;
                    if (name) {
                        // 移除参数
                        currentParams.delete(name);
                        // 对于多选参数，也需要移除name[]格式
                        if (name.endsWith('[]')) {
                            const baseName = name.slice(0, -2);
                            currentParams.delete(baseName);
                        } else {
                            currentParams.delete(`${name}[]`);
                        }
                    }
                });
                
                // 构建新URL
                const newQueryString = currentParams.toString();
                let newUrl = currentUrl;
                if (newQueryString) {
                    newUrl = `${currentUrl}?${newQueryString}`;
                }
                
                // 重定向
                window.location.href = newUrl;
            });
        }
        
        // 构建干净的URL参数，排除空值
        function buildCleanQueryParams(form) {
            const params = new URLSearchParams();
            const formData = new FormData(form);
            
            for (let [key, value] of formData.entries()) {
                // 排除空值：空字符串、null、undefined、"all"
                if (value === null || value === undefined || value === '') {
                    continue;
                }
                
                // 排除特定空值标识
                if (value === 'all') {
                    continue;
                }
                
                // 对于数组参数（多选），需要特殊处理
                if (key.endsWith('[]')) {
                    // 如果当前值是空字符串，跳过
                    if (value === '') continue;
                    // 对于数组参数，使用相同的key添加
                    params.append(key, value);
                } else {
                    params.append(key, value);
                }
            }
            
            return params.toString();
        }
        
        // 处理表单提交
        const form = dropdown.querySelector('.filter-form');
        if (form) {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // 构建干净的URL参数
                const queryParams = buildCleanQueryParams(this);
                
                // 获取当前URL（不带查询参数）
                const currentUrl = window.location.pathname;
                
                // 构建新URL
                let newUrl = currentUrl;
                if (queryParams) {
                    newUrl = `${currentUrl}?${queryParams}`;
                }
                
                // 触发过滤器更改事件（供AJAX组件使用）
                const formData = new FormData(this);
                const filters = {};
                for (let [key, value] of formData.entries()) {
                    // 查找对应的输入元素以确定过滤器类型
                    let inputElement = form.querySelector(`[name="${key}"], [name="${key}[]"]`);
                    if (!inputElement && key.endsWith('[]')) {
                        const baseName = key.slice(0, -2);
                        inputElement = form.querySelector(`[name="${baseName}"], [name="${baseName}[]"]`);
                    }
                    
                    // 检查是否是日期范围过滤器
                    const isDateRange = inputElement && inputElement.classList.contains('filter-date-range');
                    
                    // 对于日期范围过滤器，空字符串是有效值（表示"全部时间"）
                    if (isDateRange) {
                        filters[key] = value;
                    } else if (value && value !== '' && value !== 'all') {
                        // 其他过滤器排除空值
                        filters[key] = value;
                    }
                }
                
                filterComponent.dispatchEvent(new CustomEvent('filterChange', {
                    detail: { 
                        filterId: filterId,
                        filters: filters
                    }
                }));
                
                // 重定向到新URL
                window.location.href = newUrl;
                
                // 关闭下拉面板
                toggleDropdown(false);
            });
        }
    }
    
    // DOM加载完成后初始化过滤器组件
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initFilterComponents);
    } else {
        initFilterComponents();
    }
})(jQuery);