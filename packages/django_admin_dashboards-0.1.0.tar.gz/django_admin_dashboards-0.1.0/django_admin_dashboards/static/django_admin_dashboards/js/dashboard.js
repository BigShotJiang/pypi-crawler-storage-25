/**
 * AJAX data loading for Django Admin Dashboards
 */

(function() {
    'use strict';
    
    // Function to get URL parameter
    function getUrlParameter(name) {
        name = name.replace(/[\[\]]/g, '\\$&');
        const regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)');
        const results = regex.exec(window.location.href);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, ' '));
    }
    
    // Handle dark mode via URL parameter _dark_mode_on
    // This runs before Django's theme.js to override localStorage
    (function() {
        const darkModeParam = getUrlParameter('_dark_mode_on');
        if (darkModeParam) {
            const paramValue = darkModeParam.toLowerCase();
            let themeValue = '';
            if (paramValue === 'true') {
                themeValue = 'dark';
            } else if (paramValue === 'false') {
                themeValue = 'light';
            } else if (paramValue === 'auto') {
                themeValue = 'auto';
            }
            
            if (themeValue) {
                // Set theme in localStorage before Django's theme.js initializes
                localStorage.setItem('theme', themeValue);
                // Also set data-theme attribute immediately for dark/light
                // For 'auto', let Django's theme.js handle it completely
                if (themeValue === 'dark' || themeValue === 'light') {
                    document.documentElement.setAttribute('data-theme', themeValue);
                }
                // For 'auto', do not touch data-theme attribute, let theme.js handle it
            }
        }
    })();
    
    const DashboardAsync = {
        endpoint: '/dashboard/fetch-data/',
        
        // Utility function to get URL parameter
        getUrlParameter: function(name) {
            name = name.replace(/[\[\]]/g, '\\$&');
            const regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)');
            const results = regex.exec(window.location.href);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, ' '));
        },
        
        init: function() {
            this.initDashboardConfig();
            this.loadAsyncCards();
            this.loadAsyncCharts();
            this.loadAsyncTables();
        },
        
        initDashboardConfig: function() {
            const configEl = document.getElementById('dashboard-config');
            if (!configEl) return;
            
            // Handle force hide others
            const forceHideOthers = configEl.dataset.forceHideOthers === 'true';
            if (forceHideOthers) {
                document.body.classList.add('dashboard-force-hide-others');
            }
            
            // Handle hide others in fullscreen
            const hideOthersInFullscreen = configEl.dataset.hideOthersInFullscreen === 'true';
            if (hideOthersInFullscreen) {
                this.initFullscreenMode();
            }
            
            // Handle show admin title
            const showAdminTitle = configEl.dataset.showAdminTitle === 'true';
            if (!showAdminTitle) {
                // Hide Django admin title if show_admin_title is false
                const style = document.createElement('style');
                style.textContent = '#content > h1 { display: none !important; }';
                document.head.appendChild(style);
            }
        },
        
        initFullscreenMode: function() {
            const dashboardElement = document.querySelector('.dashboard');
            if (!dashboardElement) return;
            
            // Function to check if we're in fullscreen mode
            function isFullScreen() {
                return document.fullscreenElement || 
                       document.webkitFullscreenElement || 
                       document.mozFullScreenElement || 
                       document.msFullscreenElement;
            }
            
            // Function to toggle fullscreen class
            function toggleFullscreenClass() {
                if (isFullScreen()) {
                    document.documentElement.classList.add('dashboard-fullscreen-mode');
                } else {
                    document.documentElement.classList.remove('dashboard-fullscreen-mode');
                }
            }
            
            // Listen for fullscreen change events
            document.addEventListener('fullscreenchange', toggleFullscreenClass);
            document.addEventListener('webkitfullscreenchange', toggleFullscreenClass);
            document.addEventListener('mozfullscreenchange', toggleFullscreenClass);
            document.addEventListener('MSFullscreenChange', toggleFullscreenClass);
            
            // Initial check
            toggleFullscreenClass();
        },
        
        loadAsyncCards: function() {
            const cards = document.querySelectorAll('.card-async');
            cards.forEach(card => {
                const componentId = card.dataset.componentId;
                const dataSource = JSON.parse(card.dataset.dataSource);
                this.fetchData(componentId, dataSource)
                    .then(data => this.updateCard(card, data))
                    .catch(error => this.handleError(card, error));
            });
        },
        
        loadAsyncCharts: function() {
            const charts = document.querySelectorAll('.chart-async');
            charts.forEach(chart => {
                const componentId = chart.dataset.componentId;
                const dataSource = JSON.parse(chart.dataset.dataSource);
                const canvas = chart.querySelector('canvas');
                this.fetchData(componentId, dataSource)
                    .then(data => this.updateChart(chart, canvas, data))
                    .catch(error => this.handleError(chart, error));
            });
        },
        
        loadAsyncTables: function() {
            const tables = document.querySelectorAll('.table-async');
            tables.forEach(table => {
                const componentId = table.dataset.componentId;
                const dataSource = JSON.parse(table.dataset.dataSource);
                this.fetchData(componentId, dataSource)
                    .then(data => this.updateTable(table, data))
                    .catch(error => this.handleError(table, error));
            });
        },
        
        fetchData: function(componentId, dataSource) {
            // 包含当前页面的查询参数，以便数据源可以访问过滤器参数
            const url = this.endpoint + window.location.search;
            return fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                },
                body: JSON.stringify({
                    component_id: componentId,
                    data_source: dataSource,
                }),
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }
                return response.json();
            })
            .then(result => {
                if (result.error) {
                    throw new Error(result.error);
                }
                return result.data;
            });
        },
        
        updateCard: function(card, data) {
            const loadingEl = card.querySelector('.card-value-loading');
            if (!loadingEl) return;
            
            // Remove loading element
            loadingEl.remove();
            
            const cardContent = card.querySelector('.card-content');
            const link = card.dataset.link;
            
            // Create value element
            const valueEl = document.createElement('div');
            valueEl.className = 'card-value';
            
            // Handle different data types
            if (typeof data === 'number' || typeof data === 'string') {
                valueEl.textContent = data;
            } else if (Array.isArray(data) && data.length === 1) {
                valueEl.textContent = data[0];
            } else {
                // Fallback
                valueEl.textContent = data;
            }
            
            // Wrap with link if available
            if (link) {
                const linkEl = document.createElement('a');
                linkEl.href = link;
                linkEl.className = 'card-value-link';
                linkEl.appendChild(valueEl);
                cardContent.insertBefore(linkEl, card.querySelector('.card-change') || null);
            } else {
                cardContent.insertBefore(valueEl, card.querySelector('.card-change') || null);
            }
            
            card.classList.remove('card-async');
        },
        
        updateChart: function(chart, canvas, data) {
            const loadingEl = chart.querySelector('.chart-loading');
            if (loadingEl) {
                loadingEl.remove();
            }
            
            // Initialize chart with fetched data
            const ctx = canvas.getContext('2d');
            // Get chart type from data or default to 'line'
            const chartType = data.chart_type || 'line';
            const chartData = data.data || data;
            const options = data.options || {};
            
            new Chart(ctx, {
                type: chartType,
                data: chartData,
                options: options,
            });
            
            chart.classList.remove('chart-async');
            canvas.dataset.pending = 'false';
        },
        
        updateTable: function(table, data) {
            const tbody = table.querySelector('tbody');
            if (!tbody) return;
            
            // Clear loading row
            tbody.innerHTML = '';
            
            // Data should be array of rows
            if (Array.isArray(data)) {
                data.forEach(row => {
                    const tr = document.createElement('tr');
                    if (Array.isArray(row)) {
                        row.forEach(cell => {
                            const td = document.createElement('td');
                            td.textContent = cell;
                            tr.appendChild(td);
                        });
                    } else if (typeof row === 'object') {
                        // Handle object rows - use values in order of columns
                        const columns = table.dataset.columns ? JSON.parse(table.dataset.columns) : [];
                        columns.forEach(col => {
                            const td = document.createElement('td');
                            td.textContent = row[col] || '';
                            tr.appendChild(td);
                        });
                    }
                    tbody.appendChild(tr);
                });
            }
            
            if (!data || data.length === 0) {
                const tr = document.createElement('tr');
                const td = document.createElement('td');
                td.className = 'no-data';
                td.colSpan = table.querySelectorAll('thead th').length || 1;
                td.textContent = 'No data available';
                tr.appendChild(td);
                tbody.appendChild(tr);
            }
            
            table.classList.remove('table-async');
        },
        
        handleError: function(element, error) {
            console.error('Failed to load async data:', error);
            
            const errorEl = document.createElement('div');
            errorEl.className = 'async-error';
            errorEl.textContent = 'Failed to load data';
            errorEl.style.color = '#dc3545';
            errorEl.style.fontSize = '14px';
            errorEl.style.padding = '10px';
            errorEl.style.textAlign = 'center';
            
            const loadingEl = element.querySelector('.card-value-loading, .chart-loading, .table-loading');
            if (loadingEl) {
                loadingEl.replaceWith(errorEl);
            }
        }
    };
    
    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => DashboardAsync.init());
    } else {
        DashboardAsync.init();
    }
    
    // Export for debugging
    window.DashboardAsync = DashboardAsync;
})();