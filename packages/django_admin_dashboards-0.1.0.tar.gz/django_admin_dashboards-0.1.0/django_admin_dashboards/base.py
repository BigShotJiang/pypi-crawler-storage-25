"""
Django Admin Dashboards 的基础数据看板类
"""

from django.utils.module_loading import import_string
from django.conf import settings
from django.forms.widgets import Media
from django.core.exceptions import PermissionDenied
import json
import uuid


class Component:
    """基础组件类"""

    component_type = None
    template_name = None

    def __init__(self, component_id=None, **kwargs):
        self.kwargs = kwargs
        self.component_id = component_id or f"comp_{uuid.uuid4().hex}"
        for key, value in kwargs.items():
            setattr(self, key, value)

    @property
    def data_source_json(self):
        """如果存在数据源，返回其 JSON 表示"""
        if hasattr(self, "data_source") and self.data_source is not None:
            return json.dumps(self.data_source.to_json())
        return None

    def get_context_data(self, request):
        """获取组件渲染的上下文数据"""
        return {
            "component": self,
            "component_type": self.component_type,
        }

    def render(self, request):
        """将组件渲染为 HTML（在模板中实现）"""
        return (
            f'<div class="component {self.component_type}">{self.component_type}</div>'
        )


class DataSource:
    """安全的数据源基类

    新的数据源设计不允许用户指定任意模型和操作符。
    所有数据源必须预定义并注册，每个数据源都有唯一标识符。
    数据源实现中必须包含权限检查逻辑。

    属性:
        source_id: 数据源唯一标识符
        description: 数据源描述
        filters_manager_class: 过滤器管理器类，用于统一管理过滤器配置和逻辑
    """

    _registry = {}  # 数据源注册表 {source_id: DataSource subclass}

    source_id = None  # 数据源唯一标识符
    description = None  # 数据源描述
    filters_manager_class = None  # 过滤器管理器类

    def __init__(self, **kwargs):
        self.kwargs = kwargs

    def to_json(self):
        """返回数据源配置的 JSON 可序列化表示"""
        return {
            "source_id": self.source_id,
            "kwargs": self.kwargs,
        }

    def fetch(self, request):
        """获取此数据源的数据，返回 JSON 可序列化数据"""
        raise NotImplementedError("Subclasses must implement fetch method")

    @classmethod
    def register(cls, source_class):
        """注册数据源类"""
        if not source_class.source_id:
            raise ValueError(
                f"Data source class {source_class.__name__} must have a source_id"
            )
        cls._registry[source_class.source_id] = source_class
        return source_class

    @classmethod
    def get_source(cls, source_id):
        """根据 source_id 获取数据源类"""
        source_class = cls._registry.get(source_id)
        if not source_class:
            raise ValueError(f"Unknown data source: {source_id}")
        return source_class

    @classmethod
    def create_from_json(cls, data):
        """从 JSON 表示创建数据源实例"""
        source_id = data.get("source_id")
        if not source_id:
            raise ValueError("Missing source_id in data source configuration")

        kwargs = data.get("kwargs", {})
        source_class = cls.get_source(source_id)
        return source_class(**kwargs)

    @classmethod
    def get_available_sources(cls):
        """获取所有已注册的数据源"""
        return cls._registry

    def get_filters_manager(self, request):
        """获取过滤器管理器实例

        Args:
            request: Django HttpRequest 对象

        Returns:
            FiltersManager 实例，如果 filters_manager_class 为 None 则返回 None
        """
        if self.filters_manager_class and request:
            return self.filters_manager_class(request)
        return None


class SecurityCheckedDataSource(DataSource):
    """具有权限检查的安全数据源基类

    子类必须实现：
    1. source_id: 数据源唯一标识符
    2. description: 数据源描述
    3. permission_required: 所需的权限字符串（例如 "auth.view_user"）
    4. _fetch_data(request): 实际获取数据的方法
    """

    permission_required = None

    def fetch(self, request):
        """检查权限后获取数据"""
        if self.permission_required:
            # 检查用户是否具有所需权限
            if not request.user.has_perm(self.permission_required):
                raise PermissionDenied(f"缺少权限: {self.permission_required}")
        return self._fetch_data(request)

    def _fetch_data(self, request):
        """子类必须实现的获取数据方法"""
        raise NotImplementedError("Subclasses must implement _fetch_data method")


class CardComponent(Component):
    """卡片组件"""

    component_type = "card"
    template_name = "admin/components/card.html"

    class Media:
        css = {"all": ("django_admin_dashboards/css/card.css",)}
        # 卡片组件通常不需要额外的JavaScript

    def __init__(
        self,
        title,
        value=None,
        change=None,
        trend=None,
        color="primary",
        icon_class=None,
        values=None,
        value_labels=None,
        link=None,
        links=None,
        data_source=None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.title = title
        self.value = value  # 主值（用于向后兼容）
        self.change = change
        self.trend = trend
        self.color = color
        self.icon_class = icon_class or "ri-bar-chart-2-line"  # 完整的图标类名
        # 支持多值显示
        if values is not None:
            self.values = values
        else:
            self.values = [value] if value is not None else []
        self.value_labels = value_labels or []
        self.link = link  # 主值或单值显示的单链接
        self.links = links or []  # 对应值的链接列表
        self.data_source = data_source  # 用于异步加载的 DataSource 实例


class ChartComponent(Component):
    """图表组件"""

    component_type = "chart"
    template_name = "admin/components/chart.html"

    class Media:
        css = {"all": ("django_admin_dashboards/css/chart.css",)}
        js = ("django_admin_dashboards/js/chart.umd.js",)

    def __init__(
        self,
        title,
        chart_type,
        data=None,
        options=None,
        height=400,
        data_source=None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.title = title
        self.chart_type = chart_type
        self.data = data
        self.options = options or {}
        self.height = height
        self.data_source = data_source  # 用于异步加载的 DataSource 实例

    def get_context_data(self, request):
        context = super().get_context_data(request)
        context["chart_id"] = f"chart_{id(self)}"
        context["data_json"] = json.dumps(self.data)
        context["options_json"] = json.dumps(self.options)
        return context


class FilterComponent(Component):
    """过滤器组件"""

    component_type = "filter"
    template_name = "admin/components/filter.html"

    class Media:
        css = {
            "all": (
                "django_admin_dashboards/css/filter.css",
                "admin/css/vendor/select2/select2.min.css",
            )
        }
        js = (
            "admin/js/vendor/jquery/jquery.min.js",
            "admin/js/vendor/select2/select2.full.min.js",
            "django_admin_dashboards/js/filter.js",
            "admin/js/jquery.init.js",
        )

    def __init__(self, title, filters=None, **kwargs):
        super().__init__(**kwargs)
        self.title = title
        self.filters = filters or []

    def get_context_data(self, request):
        """获取过滤器组件的上下文数据"""
        context = super().get_context_data(request)

        # 增强过滤器配置，添加当前值
        enhanced_filters = []
        for filter_config in self.filters:
            enhanced_filter = filter_config.copy()
            filter_name = filter_config["name"]
            filter_type = filter_config.get("type")

            # 从请求参数获取当前值
            if request and request.GET:
                if filter_type == "checkbox":
                    # 多值复选框：获取列表值
                    values = request.GET.getlist(filter_name)
                    if values:
                        enhanced_filter["current_value"] = values
                    else:
                        # 确保default是列表
                        default = filter_config.get("default")
                        if isinstance(default, list):
                            enhanced_filter["current_value"] = default
                        elif default:
                            enhanced_filter["current_value"] = [default]
                        else:
                            enhanced_filter["current_value"] = []
                elif filter_type == "multi_select":
                    # 多选过滤器：获取列表值，参数名包含[]
                    values = request.GET.getlist(f"{filter_name}[]")
                    if values:
                        enhanced_filter["current_value"] = values
                    else:
                        # 确保default是列表
                        default = filter_config.get("default")
                        if isinstance(default, list):
                            enhanced_filter["current_value"] = default
                        elif default:
                            enhanced_filter["current_value"] = [default]
                        else:
                            enhanced_filter["current_value"] = []
                elif filter_type == "date_range":
                    # 日期范围过滤器
                    value = request.GET.get(filter_name)
                    if value is not None:
                        enhanced_filter["current_value"] = value
                    else:
                        enhanced_filter["current_value"] = filter_config.get("default")

                    # 添加自定义日期范围值
                    start_date = request.GET.get(f"{filter_name}_start")
                    end_date = request.GET.get(f"{filter_name}_end")
                    if start_date:
                        enhanced_filter["start_date"] = start_date
                    if end_date:
                        enhanced_filter["end_date"] = end_date
                else:
                    # 单值过滤器
                    value = request.GET.get(filter_name)
                    if value is not None:
                        enhanced_filter["current_value"] = value
                    else:
                        enhanced_filter["current_value"] = filter_config.get("default")
            else:
                enhanced_filter["current_value"] = filter_config.get("default")

            enhanced_filters.append(enhanced_filter)

        context.update(
            {
                "filter_id": f"filter_{id(self)}",
                "filters": enhanced_filters,
            }
        )
        return context


class FilterHelper:
    """过滤器辅助工具类，用于解析和应用过滤器参数"""

    def __init__(self, request=None, filters_config=None):
        """
        初始化过滤器辅助工具

        Args:
            request: Django HttpRequest 对象
            filters_config: 过滤器配置列表，与 FilterComponent 使用的格式相同
        """
        self.request = request
        self.filters_config = filters_config or []
        self.filter_values = self._parse_filter_values()

    def _parse_filter_values(self):
        """从请求参数解析过滤器值，排除空值（空字符串、'all'等）"""
        values = {}
        if not self.request or not self.request.GET:
            return values

        for filter_config in self.filters_config:
            filter_name = filter_config["name"]
            filter_type = filter_config.get("type")

            if filter_type == "checkbox":
                # 复选框：获取列表值，排除空字符串
                checkbox_values = self.request.GET.getlist(filter_name)
                non_empty_values = [
                    v for v in checkbox_values if v and v.strip() and v != "all"
                ]
                if non_empty_values:
                    values[filter_name] = non_empty_values
            elif filter_type == "multi_select":
                # 多选过滤器：获取列表值，参数名包含[]
                multi_select_values = self.request.GET.getlist(f"{filter_name}[]")
                non_empty_values = [
                    v for v in multi_select_values if v and v.strip() and v != "all"
                ]
                if non_empty_values:
                    values[filter_name] = non_empty_values
            elif filter_type == "date_range":
                value = self.request.GET.get(filter_name)
                # 排除空值、'all'和'all_time'
                if value and value.strip() and value != "all" and value != "all_time":
                    values[filter_name] = value
                    # 添加自定义日期范围值
                    start_date = self.request.GET.get(f"{filter_name}_start")
                    end_date = self.request.GET.get(f"{filter_name}_end")
                    if start_date and start_date.strip():
                        values[f"{filter_name}_start"] = start_date
                    if end_date and end_date.strip():
                        values[f"{filter_name}_end"] = end_date
            else:
                value = self.request.GET.get(filter_name)
                # 排除空字符串和特定空值标识
                if value is not None and value.strip() and value != "all":
                    values[filter_name] = value

        return values

    def get_value(self, filter_name, default=None):
        """获取过滤器值"""
        return self.filter_values.get(filter_name, default)

    def get_date_range(self, filter_name="date_range"):
        """
        获取日期范围过滤器的开始和结束日期

        Returns:
            tuple: (start_date, end_date) 作为 datetime.date 对象，或 (None, None)
        """
        from django.utils import timezone
        import datetime

        range_type = self.get_value(filter_name)
        if not range_type or range_type == "all_time":
            return None, None

        today = timezone.now().date()

        if range_type == "today":
            return today, today
        elif range_type == "yesterday":
            yesterday = today - datetime.timedelta(days=1)
            return yesterday, yesterday
        elif range_type == "last_7_days":
            start_date = today - datetime.timedelta(days=7)
            return start_date, today
        elif range_type == "last_30_days":
            start_date = today - datetime.timedelta(days=30)
            return start_date, today
        elif range_type == "this_month":
            start_date = today.replace(day=1)
            return start_date, today
        elif range_type == "last_month":
            first_day_of_this_month = today.replace(day=1)
            last_month = first_day_of_this_month - datetime.timedelta(days=1)
            start_date = last_month.replace(day=1)
            end_date = last_month
            return start_date, end_date
        elif range_type == "this_year":
            start_date = today.replace(month=1, day=1)
            return start_date, today
        elif range_type == "last_year":
            start_date = today.replace(year=today.year - 1, month=1, day=1)
            end_date = today.replace(year=today.year - 1, month=12, day=31)
            return start_date, end_date
        elif range_type == "custom":
            # 尝试从自定义字段获取日期
            start_str = self.get_value(f"{filter_name}_start")
            end_str = self.get_value(f"{filter_name}_end")
            if start_str and end_str:
                try:
                    start_date = datetime.datetime.strptime(
                        start_str, "%Y-%m-%d"
                    ).date()
                    end_date = datetime.datetime.strptime(end_str, "%Y-%m-%d").date()
                    return start_date, end_date
                except ValueError:
                    pass

        return None, None

    def apply_to_queryset(self, queryset, field_mappings=None):
        """
        将过滤器应用于查询集

        Args:
            queryset: Django QuerySet
            field_mappings: 字典，映射过滤器名称到模型字段名

        Returns:
            过滤后的 QuerySet
        """
        from django.db.models import Q

        if not field_mappings:
            field_mappings = {}

        q_objects = Q()

        for filter_config in self.filters_config:
            filter_name = filter_config["name"]
            filter_type = filter_config.get("type")

            if filter_name not in self.filter_values:
                continue

            value = self.filter_values[filter_name]
            if not value or (isinstance(value, list) and not value):
                continue

            # 获取模型字段名
            field_name = field_mappings.get(filter_name, filter_name)

            if filter_type == "checkbox" or filter_type == "multi_select":
                # 多值过滤：OR 条件
                if isinstance(value, list):
                    q = Q()
                    for v in value:
                        q |= Q(**{field_name: v})
                    q_objects &= q
                else:
                    q_objects &= Q(**{field_name: value})
            elif filter_type == "date_range" and filter_name in self.filter_values:
                # 日期范围过滤
                start_date, end_date = self.get_date_range(filter_name)
                if start_date and end_date:
                    date_field = field_mappings.get(f"{filter_name}_field", "date")
                    q_objects &= Q(**{f"{date_field}__gte": start_date}) & Q(
                        **{f"{date_field}__lte": end_date}
                    )
            else:
                # 精确匹配或包含匹配
                if filter_type == "text":
                    # 文本搜索：包含
                    q_objects &= Q(**{f"{field_name}__icontains": value})
                elif filter_type == "number":
                    # 数字过滤
                    try:
                        num_value = float(value)
                        q_objects &= Q(**{field_name: num_value})
                    except ValueError:
                        pass
                else:
                    # 精确匹配
                    q_objects &= Q(**{field_name: value})

        if q_objects:
            return queryset.filter(q_objects)
        return queryset


class FiltersManager:
    """抽象过滤器管理器基类，用于简化业务过滤器的定义"""

    def __init__(self, request=None):
        self.request = request
        self.filter_helper = None
        if request:
            self._init_filter_helper()

    def _init_filter_helper(self):
        """初始化FilterHelper实例"""
        filters_config = self.get_filters_config()
        self.filter_helper = FilterHelper(self.request, filters_config)

    def get_filter_helper(self):
        """获取FilterHelper实例"""
        if self.filter_helper is None and self.request:
            self._init_filter_helper()
        return self.filter_helper

    @classmethod
    def get_filters_config(cls):
        """子类必须实现：返回过滤器配置列表

        Returns:
            list: 过滤器配置字典列表，格式与FilterComponent兼容
        """
        raise NotImplementedError("Subclasses must implement get_filters_config method")

    def apply_filters(self, queryset, filter_helper=None):
        """将过滤器应用到查询集

        Args:
            queryset: Django QuerySet
            filter_helper: 可选，FilterHelper实例。如果未提供，使用自身的filter_helper

        Returns:
            过滤后的查询集
        """
        raise NotImplementedError("Subclasses must implement apply_filters method")

    @staticmethod
    def create_select_filter(name, label, options, default="all"):
        """创建选择型过滤器配置"""
        return {
            "name": name,
            "label": label,
            "type": "select",
            "options": options,
            "default": default,
        }

    @staticmethod
    def create_multi_select_filter(name, label, options, default=[]):
        """创建多选型过滤器配置"""
        return {
            "name": name,
            "label": label,
            "type": "multi_select",
            "options": options,
            "default": default,
        }

    @staticmethod
    def create_date_range_filter(
        name="date_range", label="日期范围", default="last_30_days"
    ):
        """创建日期范围过滤器配置"""
        return {
            "name": name,
            "label": label,
            "type": "date_range",
            "default": default,
        }

    @staticmethod
    def create_number_filter(name, label, default=0, placeholder=""):
        """创建数字型过滤器配置"""
        return {
            "name": name,
            "label": label,
            "type": "number",
            "default": default,
            "placeholder": placeholder,
        }

    @staticmethod
    def create_text_filter(name, label, default="", placeholder=""):
        """创建文本型过滤器配置"""
        return {
            "name": name,
            "label": label,
            "type": "text",
            "default": default,
            "placeholder": placeholder,
        }


class TableComponent(Component):
    """表格组件"""

    component_type = "table"
    template_name = "admin/components/table.html"

    class Media:
        css = {"all": ("django_admin_dashboards/css/table.css",)}

    def __init__(self, title, columns=None, data=None, data_source=None, **kwargs):
        super().__init__(**kwargs)
        self.title = title
        self.columns = columns or []
        self.data = data or []
        self.data_source = data_source  # 用于异步加载的 DataSource 实例

    def get_context_data(self, request):
        context = super().get_context_data(request)
        context.update(
            {
                "table_id": f"table_{id(self)}",
                "columns": self.columns,
                "data": self.data,
            }
        )
        return context


class Layout:
    """Layout manager for dashboard"""

    def __init__(self, columns=12):
        self.columns = columns
        self.rows = []

    def add_row(self, components, height="auto"):
        """Add a row of components"""
        self.rows.append(
            {
                "components": components,
                "height": height,
            }
        )
        return self

    def add_component(self, component, width=12):
        """Add a single component as a row"""
        self.add_row([(component, width)])
        return self


class Dashboard:
    """具有灵活布局的数据看板基类

    属性:
        title: 数据看板标题（可选，默认为 None - 为空时不显示）
        template_name: 渲染模板路径
        layout: 布局管理器实例
        show_dashboard_title: 是否显示数据看板标题
        show_admin_title: 是否显示 Django 管理员的默认标题
        hide_others_in_fullscreen: 是否在全屏模式下隐藏周围元素
        force_hide_others: 是否始终隐藏周围元素
        auto_refresh: 页面自动刷新间隔（秒），0 表示不刷新
        filters_manager_class: 过滤器管理器类，用于统一管理过滤器配置和逻辑
    """

    title = None
    template_name = "admin/dashboard.html"
    layout = None
    show_dashboard_title = True
    show_admin_title = False
    hide_others_in_fullscreen = (
        False  # 是否在全屏模式下隐藏周围元素（可被子类覆盖）  # noqa: F811
    )
    force_hide_others = False  # 是否始终隐藏周围元素（可被子类覆盖）  # noqa: F811
    auto_refresh = 0  # 页面自动刷新间隔（秒），0 表示不刷新
    filters_manager_class = None  # 过滤器管理器类

    class Media:
        css = {
            "all": (
                "remixicon/remixicon.css",
                "admin/css/vendor/select2/select2.min.css",
                "django_admin_dashboards/css/dashboard.css",
            )
        }
        js = (
            "django_admin_dashboards/js/chart.umd.js",
            "admin/js/vendor/jquery/jquery.min.js",
            "admin/js/vendor/select2/select2.full.min.js",
            "admin/js/jquery.init.js",
            "django_admin_dashboards/js/dashboard.js",
        )

    @property
    def media(self):
        """返回数据看板的媒体资源，聚合所有子组件的 Media"""
        # 从 Dashboard 自身的 Media 类开始
        media = Media(self.Media)

        # 聚合所有组件的 Media 资源
        if self.layout and self.layout.rows:
            for row in self.layout.rows:
                for component, width in row["components"]:
                    if hasattr(component, "Media"):
                        component_media = Media(component.Media)
                        media += component_media

        return media

    def __init__(self, request=None):
        self._request = request
        # 初始化过滤器管理器
        self.filters_manager = None
        if self.filters_manager_class and request:
            self.filters_manager = self.filters_manager_class(request)

        if self.layout is None:
            self.layout = self.get_layout()

    def _get_hide_others_in_fullscreen_param(self, request=None):
        """内部方法：从请求参数获取是否在全屏模式下隐藏周围元素"""
        req = request or self._request
        if req:
            # 检查是否通过请求参数启用了全屏隐藏选项
            hide_in_fullscreen_param = req.GET.get(
                "_hide_others_in_fullscreen", ""
            ).lower()
            return hide_in_fullscreen_param in ("true", "1", "yes")
        return False

    def _get_force_hide_others_param(self, request=None):
        """内部方法：从请求参数获取是否始终隐藏周围元素"""
        req = request or self._request
        if req:
            # 检查是否通过请求参数启用了强制隐藏选项
            force_hide_param = req.GET.get("_force_hide_others", "").lower()
            return force_hide_param in ("true", "1", "yes")
        return False

    @property
    def hide_others_in_fullscreen(self):  # noqa: F811
        """模板访问属性：是否在全屏模式下隐藏周围元素"""
        # 仅当URL参数显式设置为true时才启用
        # 数据看板类设置 hide_others_in_fullscreen = True 表示支持此功能
        # 但实际激活需要 URL 参数 ?_hide_others_in_fullscreen=true
        if not self.__class__.hide_others_in_fullscreen:
            return False
        if self._request:
            return self._get_hide_others_in_fullscreen_param()
        return False

    @property
    def force_hide_others(self):  # noqa: F811
        """模板访问属性：是否始终隐藏周围元素，无论是否全屏模式"""
        # 仅当URL参数显式设置为true时才启用
        # 数据看板类设置 force_hide_others = True 表示支持此功能
        # 但实际激活需要 URL 参数 ?_force_hide_others=true
        if not self.__class__.force_hide_others:
            return False
        if self._request:
            return self._get_force_hide_others_param()
        return False

    def get_context_data(self, request, **kwargs):
        """获取数据看板渲染的上下文数据"""
        # 准备组件上下文并合并到组件对象中
        if self.layout and self.layout.rows:
            for row in self.layout.rows:
                for component, width in row["components"]:
                    if hasattr(component, "get_context_data"):
                        component_context = component.get_context_data(request)
                        # 合并上下文数据到组件对象，供模板访问
                        if component_context:
                            for key, value in component_context.items():
                                setattr(component, key, value)

        context = {
            "title": self.title,
            "dashboard": self,
            "request": request,
            "layout": self.layout,
            "show_dashboard_title": self.show_dashboard_title,
            "show_admin_title": self.show_admin_title,
            "hide_others_in_fullscreen": self.hide_others_in_fullscreen,
            "force_hide_others": self.force_hide_others,
            "auto_refresh": self.auto_refresh,
        }
        return context


def get_dashboard_for_view(view_name, app_label=None):
    """
    Get dashboard class for specific view based on settings.DJANGO_ADMIN_DASHBOARDS
    """
    dashboards_config = getattr(settings, "DJANGO_ADMIN_DASHBOARDS", {})

    if app_label:
        app_dashboards = dashboards_config.get("admin:app_list", {})
        dashboard_path = app_dashboards.get(app_label)
    else:
        dashboard_path = dashboards_config.get(view_name)

    if dashboard_path:
        try:
            return import_string(dashboard_path)
        except ImportError:
            pass

    return None
