from django.apps import AppConfig


class DjangoAdminDashboardsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_admin_dashboards"
