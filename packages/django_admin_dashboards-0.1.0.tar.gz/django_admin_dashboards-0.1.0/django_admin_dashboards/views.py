# from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
import json

from .base import DataSource


@csrf_exempt
@require_http_methods(["GET", "POST"])
def fetch_data(request):
    """
    用于获取带有 DataSource 的组件数据的 AJAX 端点。
    期望包含 component_id 和 data_source 配置的 JSON 负载。
    """
    try:
        if request.method == "POST":
            data = json.loads(request.body)
        else:
            # 带有查询参数的 GET 请求
            data = {
                "component_id": request.GET.get("component_id"),
                "data_source": json.loads(request.GET.get("data_source", "{}")),
            }

        component_id = data.get("component_id")
        data_source_config = data.get("data_source")

        if not component_id or not data_source_config:
            return JsonResponse(
                {"error": "Missing component_id or data_source"}, status=400
            )

        # 从配置创建 DataSource 实例（使用新的安全模式）
        data_source = DataSource.create_from_json(data_source_config)
        # 获取数据
        result = data_source.fetch(request)

        return JsonResponse(
            {
                "component_id": component_id,
                "data": result,
            }
        )

    except json.JSONDecodeError:
        return JsonResponse({"error": "Invalid JSON"}, status=400)
    except ValueError as e:
        return JsonResponse({"error": str(e)}, status=400)
    except Exception as e:
        return JsonResponse({"error": f"Internal error: {str(e)}"}, status=500)
