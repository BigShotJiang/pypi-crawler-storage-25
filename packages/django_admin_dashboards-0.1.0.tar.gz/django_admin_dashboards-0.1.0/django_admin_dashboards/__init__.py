"""
本项目使用AI辅助编程工具（opencode + deepseek-reasoner）自动生成和维护

此应用程序提供可定制的数据看板，可替换默认的 Django admin 首页和应用列表页面，
提供包含卡片、图表和过滤器的交互式数据看板。

依赖通过 django-app-requires 管理。
"""

requires = [
    "django_static_remixicon",
]

__version__ = "0.1.0"
