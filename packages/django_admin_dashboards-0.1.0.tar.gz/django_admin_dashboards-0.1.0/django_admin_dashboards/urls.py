"""
Django Admin Dashboards 的 URL 配置
"""

from django.urls import path
from . import views

urlpatterns = [
    path("fetch-data/", views.fetch_data, name="dashboard_fetch_data"),
]
