"""
Django Admin Dashboards 贡献模块

此包包含针对特定 Django 贡献应用（如 auth、contenttypes 等）的预定义数据看板。
这些数据看板可直接在配置中使用，或作为自定义数据看板的参考实现。
"""
