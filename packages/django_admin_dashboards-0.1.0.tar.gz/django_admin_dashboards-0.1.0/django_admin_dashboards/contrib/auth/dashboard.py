"""
Django Admin Dashboards 的身份验证应用数据看板
"""

from datetime import timedelta
from django.db.models import Count
from django.contrib.auth.models import User, Group
from django.contrib.admin.models import LogEntry
from django.utils import timezone
from django.utils.translation import gettext
from django.urls import reverse

from django_admin_dashboards.base import (
    Dashboard,
    CardComponent,
    ChartComponent,
    Layout,
    TableComponent,
)


class AuthAppDashboard(Dashboard):
    """身份验证应用特定数据看板（用于管理首页和身份验证应用列表）"""

    title = gettext("首页")
    show_dashboard_title = True
    show_admin_title = False
    hide_others_in_fullscreen = True
    auto_refresh = 300  # 5分钟自动刷新页面

    def get_layout(self):
        """创建包含卡片和图表的布局"""
        layout = Layout(columns=12)

        # 卡片 - 总共始终显示6张卡片
        cards = self.get_cards()
        # 前两张卡片（启用/禁用/总计 和 普通/员工/超级用户）各占6列
        layout.add_row([(cards[0], 6), (cards[1], 6)], height="auto")
        # 剩余4张卡片每行各占3列
        layout.add_row(
            [
                (cards[2], 3),
                (cards[3], 3),
                (cards[4], 3),
                (cards[5], 3),
            ],
            height="auto",
        )

        # 图表 - 始终显示3个图表
        charts = self.get_charts()
        # 前两个图表并排显示（各占6列）
        layout.add_row([(charts[0], 6), (charts[1], 6)], height="400px")
        # 第三个图表全宽显示（12列）
        layout.add_row([(charts[2], 12)], height="400px")

        # 表格 - 最近注册和最近登录用户
        tables = self.get_tables()
        # 两个表格并排显示（各占6列）
        layout.add_row([(tables[0], 6), (tables[1], 6)], height="auto")

        return layout

    def get_cards(self):
        """创建卡片组件"""
        # 获取用户统计数据
        total_users = User.objects.count()
        active_users = User.objects.filter(is_active=True).count()
        disabled_users = User.objects.filter(is_active=False).count()

        # 用户角色细分
        staff_users = User.objects.filter(is_staff=True, is_superuser=False).count()
        superusers = User.objects.filter(is_superuser=True).count()
        normal_users = User.objects.filter(is_staff=False, is_superuser=False).count()

        # 计算活跃用户（最近30天登录）
        thirty_days_ago = timezone.now() - timedelta(days=30)
        active_recent_users = User.objects.filter(
            last_login__gte=thirty_days_ago, is_active=True
        ).count()

        # 计算沉默用户（最近90天未登录但账户仍启用）
        ninety_days_ago = timezone.now() - timedelta(days=90)
        silent_users = User.objects.filter(
            is_active=True, last_login__lt=ninety_days_ago
        ).count()

        # 生成管理页面URL
        user_admin_url = reverse("admin:auth_user_changelist")
        group_admin_url = reverse("admin:auth_group_changelist")
        logentry_admin_url = reverse("admin:admin_logentry_changelist")

        # 日期字符串用于过滤条件
        thirty_days_ago_str = thirty_days_ago.strftime("%Y-%m-%d")
        ninety_days_ago_str = ninety_days_ago.strftime("%Y-%m-%d")

        return [
            CardComponent(
                title=gettext("User Status"),
                values=[active_users, disabled_users, total_users],
                value_labels=[
                    gettext("Enabled"),
                    gettext("Disabled"),
                    gettext("Total"),
                ],
                links=[
                    f"{user_admin_url}?is_active__exact=1",  # 启用用户
                    f"{user_admin_url}?is_active__exact=0",  # 禁用用户
                    user_admin_url,  # 所有用户
                ],
                change=None,
                color="primary",
                icon_class="ri-user-2-line",
            ),
            CardComponent(
                title=gettext("User Roles"),
                values=[normal_users, staff_users, superusers],
                value_labels=[
                    gettext("Employee"),
                    gettext("Admin"),
                    gettext("Super Admin"),
                ],
                links=[
                    f"{user_admin_url}?is_staff__exact=0&is_superuser__exact=0",  # 普通员工
                    f"{user_admin_url}?is_staff__exact=1&is_superuser__exact=0",  # 管理员
                    f"{user_admin_url}?is_superuser__exact=1",  # 超级管理员
                ],
                change=None,
                color="success",
                icon_class="ri-group-line",
            ),
            CardComponent(
                title=gettext("Recent Active (30d)"),
                value=active_recent_users,
                link=f"{user_admin_url}?last_login__gte={thirty_days_ago_str}&is_active__exact=1",
                change=None,
                color="success",
                icon_class="ri-time-line",
            ),
            CardComponent(
                title=gettext("Silent Users (90d)"),
                value=silent_users,
                link=f"{user_admin_url}?last_login__lt={ninety_days_ago_str}&is_active__exact=1",
                change=None,
                color="warning",
                icon_class="ri-user-unfollow-line",
            ),
            CardComponent(
                title=gettext("Groups"),
                value=Group.objects.count(),
                link=group_admin_url,
                change=None,
                color="info",
                icon_class="ri-group-line",
            ),
            CardComponent(
                title=gettext("Admin Logs"),
                value=LogEntry.objects.count(),
                link=logentry_admin_url,
                change=None,
                color="secondary",
                icon_class="ri-history-line",
            ),
        ]

    def get_charts(self):
        """创建图表组件"""
        # 用户注册趋势（最近30天）
        thirty_days_ago = timezone.now() - timedelta(days=30)

        # 每日用户注册
        user_registrations = (
            User.objects.filter(date_joined__gte=thirty_days_ago)
            .extra({"date": "date(date_joined)"})
            .values("date")
            .annotate(count=Count("id"))
            .order_by("date")
        )

        # 准备图表数据
        dates = []
        counts = []

        for item in user_registrations:
            date_value = item["date"]
            # date_value 可能是字符串或日期对象
            if hasattr(date_value, "strftime"):
                dates.append(date_value.strftime("%Y-%m-%d"))
            else:
                dates.append(str(date_value))
            counts.append(item["count"])

        # 如果没有数据，创建模拟数据
        if not dates:
            dates = [
                (timezone.now() - timedelta(days=i)).strftime("%Y-%m-%d")
                for i in range(29, -1, -1)
            ]
            counts = [0] * 30

        # 用户角色分布
        user_roles = {
            gettext("Employees"): User.objects.filter(
                is_staff=False, is_superuser=False
            ).count(),
            gettext("Admins"): User.objects.filter(
                is_staff=True, is_superuser=False
            ).count(),
            gettext("Super Admins"): User.objects.filter(is_superuser=True).count(),
        }

        # 获取最近30天的用户登录和操作数据
        thirty_days_ago = timezone.now() - timedelta(days=30)

        # 每日用户登录计数（每天登录的用户）
        # 注意：这统计的是last_login在该天的用户
        user_logins = (
            User.objects.filter(last_login__gte=thirty_days_ago)
            .extra({"date": "date(last_login)"})
            .values("date")
            .annotate(count=Count("id"))
            .order_by("date")
        )

        # 每日用户操作计数（LogEntry 操作）
        user_actions = (
            LogEntry.objects.filter(action_time__gte=thirty_days_ago)
            .extra({"date": "date(action_time)"})
            .values("date")
            .annotate(count=Count("id"))
            .order_by("date")
        )

        # 为双轴图表准备数据
        # 生成最近30天的所有日期
        all_dates = [
            (timezone.now() - timedelta(days=i)).strftime("%Y-%m-%d")
            for i in range(29, -1, -1)
        ]

        # 用零初始化数组
        login_counts = [0] * 30
        action_counts = [0] * 30

        # 填充登录计数
        for item in user_logins:
            date_str = (
                item["date"].strftime("%Y-%m-%d")
                if hasattr(item["date"], "strftime")
                else str(item["date"])
            )
            if date_str in all_dates:
                index = all_dates.index(date_str)
                login_counts[index] = item["count"]

        # 填充操作计数
        for item in user_actions:
            date_str = (
                item["date"].strftime("%Y-%m-%d")
                if hasattr(item["date"], "strftime")
                else str(item["date"])
            )
            if date_str in all_dates:
                index = all_dates.index(date_str)
                action_counts[index] = item["count"]

        # 为用户活动创建双轴线图
        dual_axis_chart = ChartComponent(
            title=gettext("User Activity (Last 30 Days)"),
            chart_type="line",
            data={
                "labels": all_dates,
                "datasets": [
                    {
                        "label": gettext("User Logins"),
                        "data": login_counts,
                        "borderColor": "rgb(75, 192, 192)",
                        "backgroundColor": "rgba(75, 192, 192, 0.1)",
                        "yAxisID": "y",
                        "fill": True,
                    },
                    {
                        "label": gettext("User Actions"),
                        "data": action_counts,
                        "borderColor": "rgb(255, 99, 132)",
                        "backgroundColor": "rgba(255, 99, 132, 0.1)",
                        "yAxisID": "y1",
                        "fill": True,
                    },
                ],
            },
            options={
                "responsive": True,
                "maintainAspectRatio": False,
                "interaction": {
                    "mode": "index",
                    "intersect": False,
                },
                "plugins": {
                    "legend": {
                        "display": True,
                        "position": "top",
                    },
                    "tooltip": {"mode": "index", "intersect": False},
                },
                "scales": {
                    "x": {"title": {"display": True, "text": gettext("Date")}},
                    "y": {
                        "type": "linear",
                        "display": True,
                        "position": "left",
                        "title": {"display": True, "text": gettext("User Logins")},
                        "beginAtZero": True,
                        "suggestedMax": max(login_counts) * 1.2 if login_counts else 10,
                    },
                    "y1": {
                        "type": "linear",
                        "display": True,
                        "position": "right",
                        "title": {"display": True, "text": gettext("User Actions")},
                        "beginAtZero": True,
                        "suggestedMax": (
                            max(action_counts) * 1.2 if action_counts else 100
                        ),
                        "grid": {
                            "drawOnChartArea": False,
                        },
                    },
                },
            },
            height=300,
        )

        return [
            ChartComponent(
                title=gettext("User Registrations (Last 30 Days)"),
                chart_type="line",
                data={
                    "labels": dates,
                    "datasets": [
                        {
                            "label": gettext("New Users"),
                            "data": counts,
                            "borderColor": "rgb(75, 192, 192)",
                            "backgroundColor": "rgba(75, 192, 192, 0.1)",
                            "fill": True,
                        }
                    ],
                },
                options={
                    "responsive": True,
                    "maintainAspectRatio": False,
                    "plugins": {
                        "legend": {
                            "display": True,
                            "position": "top",
                        }
                    },
                    "scales": {
                        "y": {
                            "beginAtZero": True,
                            "title": {
                                "display": True,
                                "text": gettext("Number of Users"),
                            },
                        },
                        "x": {"title": {"display": True, "text": gettext("Date")}},
                    },
                },
                height=300,
            ),
            ChartComponent(
                title=gettext("User Role Distribution"),
                chart_type="pie",
                data={
                    "labels": list(user_roles.keys()),
                    "datasets": [
                        {
                            "data": list(user_roles.values()),
                            "backgroundColor": [
                                "rgb(54, 162, 235)",  # 员工
                                "rgb(255, 205, 86)",  # 管理员
                                "rgb(255, 99, 132)",  # 超级管理员
                            ],
                        }
                    ],
                },
                options={
                    "responsive": True,
                    "maintainAspectRatio": False,
                    "plugins": {
                        "legend": {
                            "display": True,
                            "position": "right",
                        }
                    },
                },
                height=300,
            ),
            dual_axis_chart,
        ]

    def get_tables(self):
        """为最近用户创建表格组件"""
        from django.utils.translation import gettext

        # 获取最近注册用户（最近10个）
        recent_registered = User.objects.order_by("-date_joined")[:10]
        # 获取最近登录用户（最近10个）
        recent_login = User.objects.filter(last_login__isnull=False).order_by(
            "-last_login"
        )[:10]

        # 为注册用户表格准备列
        registered_columns = [
            gettext("Username"),
            gettext("Email"),
            gettext("Date Joined"),
            gettext("Status"),
        ]
        registered_data = []
        for user in recent_registered:
            registered_data.append(
                [
                    user.username,
                    user.email,
                    (
                        user.date_joined.strftime("%Y-%m-%d %H:%M")
                        if user.date_joined
                        else ""
                    ),
                    gettext("Enabled") if user.is_active else gettext("Disabled"),
                ]
            )

        # 为登录用户表格准备列
        login_columns = [
            gettext("Username"),
            gettext("Email"),
            gettext("Last Login"),
            gettext("Status"),
        ]
        login_data = []
        for user in recent_login:
            login_data.append(
                [
                    user.username,
                    user.email,
                    (
                        user.last_login.strftime("%Y-%m-%d %H:%M")
                        if user.last_login
                        else ""
                    ),
                    gettext("Enabled") if user.is_active else gettext("Disabled"),
                ]
            )

        return [
            TableComponent(
                title=gettext("Recent Registered Users (Last 10)"),
                columns=registered_columns,
                data=registered_data,
            ),
            TableComponent(
                title=gettext("Recent Login Users (Last 10)"),
                columns=login_columns,
                data=login_data,
            ),
        ]
