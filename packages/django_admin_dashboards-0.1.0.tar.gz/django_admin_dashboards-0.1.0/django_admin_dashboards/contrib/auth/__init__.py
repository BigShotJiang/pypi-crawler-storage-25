"""
Django Admin Dashboards 身份验证应用数据看板

此模块提供针对 Django 身份验证应用（django.contrib.auth）的预定义数据看板。
包含用户统计、角色分布、登录活动等数据展示组件。
"""

from .dashboard import AuthAppDashboard

__all__ = ["AuthAppDashboard"]
