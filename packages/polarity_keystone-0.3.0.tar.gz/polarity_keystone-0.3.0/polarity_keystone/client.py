"""Main Polarity client (legacy name: Keystone)."""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

from ._compat import DEFAULT_BASE_URL, get_env
from ._http import HTTPClient
from .agents import AgentService
from .alerts import AlertService
from .behaviors import BehaviorsService
from .datasets import DatasetService
from .experiments import ExperimentService
from .export import ExportService
from .judges import JudgesService
from .paragon import ParagonService
from .prompts import PromptService
from .sandboxes import SandboxService
from .scoring import ScoringService
from .specs import SpecService


class Keystone:
    """Client for the Polarity API (legacy class name).

    Prefer :class:`Polarity` for new code — they're the same class.

    Example::

        from polarity import Polarity

        plr = Polarity(api_key="plr_live_…")

        # Upload a spec and run an experiment.
        spec = plr.specs.create_from_file("eval.yaml")
        exp = plr.experiments.create("nightly", spec.id)
        results = plr.experiments.run_and_wait(exp.id)

        print(f"Pass rate: {results.metrics.pass_rate:.0%}")

    Args:
        api_key: API key for authentication. Falls back to the
            ``POLARITY_API_KEY`` env var (legacy: ``KEYSTONE_API_KEY``).
        base_url: Base URL of the Polarity server (default
            ``https://plr.sh``). Override via ``POLARITY_BASE_URL`` /
            ``KEYSTONE_BASE_URL``.
        timeout: HTTP request timeout in seconds (default 30).
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = 30,
    ) -> None:
        resolved_key = api_key or get_env("POLARITY_API_KEY", "KEYSTONE_API_KEY")
        base_url = base_url or get_env("POLARITY_BASE_URL", "KEYSTONE_BASE_URL", DEFAULT_BASE_URL)
        http = HTTPClient(base_url, resolved_key, timeout)
        self._http = http

        self.sandboxes = SandboxService(http)
        self.specs = SpecService(http)
        self.experiments = ExperimentService(http)
        self.alerts = AlertService(http)
        self.agents = AgentService(http)
        self.datasets = DatasetService(http)
        self.scoring = ScoringService(http)
        self.export = ExportService(http)
        self.prompts = PromptService(http)
        # Judges, behaviors, and the Paragon copilot — mirror the
        # Judgment Labs SDK feel: ``ks.judges.create(...)``,
        # ``ks.behaviors.create_binary(...)``, ``ks.paragon.chat(...)``.
        self.judges = JudgesService(http)
        self.behaviors = BehaviorsService(http)
        self.paragon = ParagonService(http)

    def wrap(
        self,
        client: object,
        sandbox_id: Optional[str] = None,
        *,
        tracing: bool = True,
        auto_instrument: bool = True,
    ) -> object:
        """Wrap an LLM client and turn on full Keystone observability.

        ``wrap()`` is the one-call default for "track everything". It:

        1. Monkey-patches the client's ``create()`` method so every
           LLM call sends trace events to Keystone (Anthropic
           ``messages.create`` / OpenAI ``chat.completions.create``,
           sync + async).
        2. Initialises :func:`traced` span reporting on the current
           thread so every ``@traced`` function emits start/end spans.
        3. Auto-instruments any other LLM stack you have installed
           (Anthropic, OpenAI, Mistral, Google GenAI, LiteLLM,
           LangChain, Claude Agent SDK, DSPy) — failures per provider
           are silent.

        Sandbox routing is automatic. With ``KEYSTONE_SANDBOX_ID`` set,
        events nest under the sandbox run; without it, events post to
        ``/v1/traces`` and are scoped to the API key server-side
        (agent mode). If neither a sandbox id nor an API key are
        available, the wrapper still patches ``create()`` but
        emissions silently no-op at the HTTP layer.

        The original response is always returned unchanged. Trace
        reporting failures are swallowed.

        Args:
            client: An Anthropic or OpenAI client instance.
            sandbox_id: Optional. Falls back to ``KEYSTONE_SANDBOX_ID``.
            tracing: Initialise ``@traced`` span reporting. Default
                True. Pass False to wrap *only* the LLM client.
            auto_instrument: Patch other importable LLM stacks.
                Default True. Requires a sandbox id (or env var) —
                skipped silently otherwise.

        Returns:
            The same client object, instrumented.

        Example::

            from anthropic import Anthropic
            from polarity_keystone import Keystone, traced

            ks = Keystone()                     # picks up KEYSTONE_API_KEY
            anthropic = ks.wrap(Anthropic())    # full observability — one line

            @traced
            def step(): ...                     # auto-reports because of wrap()
        """
        resolved = sandbox_id or get_env("POLARITY_SANDBOX_ID", "KEYSTONE_SANDBOX_ID") or ""

        # 1. Wrap the explicit client.
        # ``resolved`` may be an empty string — that's agent mode. Trace
        # events post to /v1/traces instead of /v1/sandboxes/:id/trace and
        # are scoped to the API key server-side. wrap_client still patches
        # .create() so LLM + tool spans flow either way.
        from .wrap import wrap_client
        wrapped = wrap_client(client, resolved, self._http)

        # 2. Initialise span tracing for any @traced functions in the
        # caller's module. Idempotent (overwrites thread-local state).
        if tracing:
            from .tracing import init_tracing
            init_tracing(self._http, resolved)

        # 3. Auto-instrument everything else that's importable. Only
        # runs when we have a sandbox id — auto_instrument requires
        # one. In agent mode (no sandbox), step 1 already covered the
        # explicit client, and any new clients can be wrap()'d
        # individually.
        if auto_instrument and resolved:
            try:
                from .auto_instrument import auto_instrument as _ai
                _ai(sandbox_id=resolved)
            except Exception:
                # auto_instrument failures must never break the
                # caller's main code path.
                pass

        return wrapped

    @classmethod
    def from_sandbox(cls) -> tuple["Keystone", "Sandbox"]:
        """Create a client from the environment variables that Keystone injects
        into agent processes and return the current sandbox with its services.

        Reads ``KEYSTONE_BASE_URL``, ``KEYSTONE_API_KEY``, and
        ``KEYSTONE_SANDBOX_ID`` from the environment.

        Example::

            from polarity_keystone import Keystone

            ks, sb = Keystone.from_sandbox()
            db = sb.services["db"]  # ServiceInfo(host, port, ready)

        Raises:
            KeystoneError: If ``KEYSTONE_SANDBOX_ID`` is not set.
        """
        from .types import KeystoneError, Sandbox

        sandbox_id = get_env("POLARITY_SANDBOX_ID", "KEYSTONE_SANDBOX_ID")
        if not sandbox_id:
            raise KeystoneError(0, "POLARITY_SANDBOX_ID not set — not running inside a sandbox")
        base_url = get_env("POLARITY_BASE_URL", "KEYSTONE_BASE_URL", DEFAULT_BASE_URL)
        ks = cls(base_url=base_url)
        sb = ks.sandboxes.get(sandbox_id)
        return ks, sb

    def init_tracing(self, sandbox_id: Optional[str] = None) -> None:
        """Initialize tracing for the current thread.

        After this call, any function decorated with ``@traced`` auto-reports
        spans (start, end, duration, errors) to the sandbox.

        ``sandbox_id`` is optional — if omitted, the SDK reads
        ``KEYSTONE_SANDBOX_ID`` from the environment (Keystone injects it
        inside sandboxes). If neither is present, this call is a no-op,
        which is what you want for local dev / CI.

        Args:
            sandbox_id: Optional. Falls back to ``KEYSTONE_SANDBOX_ID`` env.

        Example::

            from polarity_keystone import Keystone, traced

            ks = Keystone()
            ks.init_tracing()   # picks up KEYSTONE_SANDBOX_ID from env

            @traced
            def write_file(path, content):
                ...  # duration + errors auto-captured
        """
        resolved = sandbox_id or get_env("POLARITY_SANDBOX_ID", "KEYSTONE_SANDBOX_ID") or ""
        # Always init — when ``resolved`` is empty we're in agent mode and
        # spans post to /v1/traces (scoped by API key). Unauth'd batches
        # are dropped server-side, so a Keystone instance with no api key
        # and no sandbox is still a network-layer no-op.
        from .tracing import init_tracing
        init_tracing(self._http, resolved)

    def observe(
        self,
        *,
        clients: Optional[List[Any]] = None,
        tracing: bool = True,
        auto_instrument: bool = True,
        sandbox_id: Optional[str] = None,
    ) -> List[str]:
        """One-call observability bootstrap.

        Combines :meth:`wrap`, :meth:`init_tracing`, and
        :func:`auto_instrument` so every common path ("trace my LLM
        calls + my @traced functions + every framework I have
        installed") collapses to a single line.

        Args:
            clients: LLM client instances to wrap explicitly (Anthropic,
                OpenAI, etc.). Each is passed through :meth:`wrap`.
            tracing: Initialise :func:`traced` span reporting. Default True.
            auto_instrument: Patch every importable provider (OpenAI,
                Anthropic, Mistral, Google GenAI, LiteLLM, LangChain,
                Claude Agent SDK, DSPy). Failures are silent. Default True.
            sandbox_id: Optional. Falls back to ``KEYSTONE_SANDBOX_ID``;
                if unset, the SDK runs in agent mode (events scoped by
                API key server-side).

        Returns:
            List of instrumentation labels that were applied — useful
            for logging at startup. Examples: ``["openai-client",
            "anthropic-client", "tracing", "openai", "langchain"]``.

        Example::

            from anthropic import Anthropic
            from openai import OpenAI
            from polarity_keystone import Keystone

            ks = Keystone()  # picks up KEYSTONE_API_KEY
            anthropic = Anthropic()
            openai = OpenAI()
            ks.observe(clients=[anthropic, openai])
            # All three of: anthropic.messages.create, openai.chat.completions.create,
            # and any @traced function now report to Keystone.
        """
        resolved_sandbox = sandbox_id or get_env("POLARITY_SANDBOX_ID", "KEYSTONE_SANDBOX_ID") or ""
        applied: List[str] = []

        # 1. Wrap any explicit clients.
        if clients:
            from .wrap import wrap_client
            for client in clients:
                if client is None:
                    continue
                try:
                    wrap_client(client, resolved_sandbox, self._http)
                    applied.append(_client_label(client))
                except Exception:
                    pass

        # 2. Initialise span tracing for @traced functions.
        if tracing:
            from .tracing import init_tracing
            init_tracing(self._http, resolved_sandbox)
            applied.append("tracing")

        # 3. Auto-detect and patch every importable provider.
        # auto_instrument requires a sandbox id — skip silently in
        # agent mode (no sandbox env var) since wrap() above already
        # covers explicit-client usage.
        if auto_instrument and resolved_sandbox:
            from .auto_instrument import auto_instrument as _auto_instrument
            try:
                names = _auto_instrument(sandbox_id=resolved_sandbox)
                applied.extend(names)
            except Exception:
                pass

        return applied

    def record_llm_call(
        self,
        *,
        provider: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
        duration_ms: int,
        requested_model: Optional[str] = None,
        cache_tokens: int = 0,
        reasoning_tokens: int = 0,
        input_messages: Any = None,
        output_text: str = "",
        tool_calls: Optional[List[Dict[str, str]]] = None,
        status: str = "ok",
        error_type: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        span_id: Optional[str] = None,
        parent_span_id: Optional[str] = None,
        sandbox_id: Optional[str] = None,
    ) -> None:
        """Record an LLM call as a Keystone trace event.

        Mirrors the shape :meth:`wrap` emits internally. The escape hatch
        for callers that don't have an Anthropic / OpenAI SDK *object* to
        wrap — multi-provider gateways, proxies, custom ``urllib`` /
        ``httpx`` routing layers — but already extract the data
        :meth:`wrap` would.

        Fire-and-forget — never raises. Sandbox routing follows the same
        rules as :meth:`wrap` / :meth:`init_tracing`: explicit
        ``sandbox_id``, then ``KEYSTONE_SANDBOX_ID`` env, then agent mode
        (``/v1/traces`` scoped by API key).

        Args:
            provider: Provider label, e.g. ``"anthropic"``, ``"openai"``,
                ``"openrouter"``, ``"gemini"``, ``"xai"``. Free-form. Lands
                in the event's ``tool`` field (``<provider>.create``) and
                in OTel ``gen_ai.system``.
            model: Resolved upstream model id. Lands in ``cost.model`` and
                ``gen_ai.response.model``.
            input_tokens: Prompt-side token count.
            output_tokens: Completion-side token count.
            duration_ms: Wall-clock duration of the upstream call.
            requested_model: Original model the caller asked for, when it
                differs from the resolved ``model`` (e.g. gateway routing
                ``polarity/paragon-fast`` → ``moonshotai/kimi-k2.6``).
                Defaults to ``model``. Sets ``gen_ai.request.model``.
            cache_tokens: Cache-read token count (0 = unknown).
            reasoning_tokens: Reasoning / thinking token count.
            input_messages: Raw input — typically the request body's
                ``messages`` array. Stringified with ``json.dumps`` and
                truncated to ~4KB before being attached.
            output_text: Aggregated assistant text.
            tool_calls: Tool calls the model invoked. Each item is a dict
                with ``name``, ``arguments`` (and optionally ``id``).
                Emitted as child ``tool_use`` events.
            status: ``"ok"`` (default) or ``"error"`` for upstream
                failures / timeouts.
            error_type: Free-form error tag (e.g. ``"upstream_5xx"``,
                ``"timeout"``).
            metadata: Custom OTel-style attributes merged into the event
                metadata — e.g. ``{"gen_ai.proxy.feature": "review"}``.
                Round-trips through OTel exports unchanged.
            span_id: Override the auto-generated ``llm_call`` span id.
                Pass a request id from upstream to correlate client +
                gateway spans into one trace tree.
            parent_span_id: Link this ``llm_call`` under a parent span
                (an outer agent step).
            sandbox_id: Override sandbox routing for just this event.
                ``None`` → use ``KEYSTONE_SANDBOX_ID`` env. ``""`` → force
                agent mode.

        Example::

            ks = Keystone()
            start = time.time()
            resp = httpx.post(upstream_url, json=payload)
            data = resp.json()
            ks.record_llm_call(
                provider="openrouter",
                model=data["model"],
                requested_model=payload["model"],
                input_tokens=data["usage"]["prompt_tokens"],
                output_tokens=data["usage"]["completion_tokens"],
                duration_ms=int((time.time() - start) * 1000),
                input_messages=payload["messages"],
                output_text=data["choices"][0]["message"]["content"],
            )
        """
        from .wrap import record_llm_call as _record_llm_call_impl
        resolved = (
            sandbox_id if sandbox_id is not None
            else (get_env("POLARITY_SANDBOX_ID", "KEYSTONE_SANDBOX_ID") or "")
        )
        _record_llm_call_impl(
            self._http,
            resolved,
            provider=provider,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            duration_ms=duration_ms,
            requested_model=requested_model,
            cache_tokens=cache_tokens,
            reasoning_tokens=reasoning_tokens,
            input_messages=input_messages,
            output_text=output_text,
            tool_calls=tool_calls,
            status=status,
            error_type=error_type,
            metadata=metadata,
            span_id=span_id,
            parent_span_id=parent_span_id,
        )

    def health(self) -> dict:
        """Check server health.

        Returns:
            A dict like ``{"status": "ok"}``.
        """
        return self._http.get("/health")


def _client_label(client: Any) -> str:
    """Heuristic label for clients passed to observe()."""
    if hasattr(client, "messages") and hasattr(client.messages, "create"):
        return "anthropic-client"
    if hasattr(client, "chat") and hasattr(getattr(client, "chat"), "completions"):
        return "openai-client"
    return f"{type(client).__module__}.{type(client).__name__}"


class Polarity(Keystone):
    """Public Polarity API client. ``Keystone`` is kept as a backwards-compatible alias.

    Identical behavior to :class:`Keystone`; the rename is brand-only.
    Existing code using ``Keystone`` continues to work unchanged.
    """
    pass
