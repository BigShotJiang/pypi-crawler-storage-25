"""Tracing primitives — ``@traced`` decorator and context manager.

Wrap any function with ``@traced`` to auto-capture input, output, duration,
and errors as a trace span. Nesting is automatic via thread-local context.

Usage::

    from polarity_keystone import Keystone, traced

    ks = Keystone()
    ks.init_tracing(sandbox_id="sb-xxx")

    @traced
    def write_file(path: str, content: str):
        with open(path, "w") as f:
            f.write(content)

    @traced
    def run_command(cmd: str) -> str:
        import subprocess
        return subprocess.check_output(cmd, shell=True).decode()

    # Context manager form:
    with traced(name="custom-step"):
        do_work()
"""

from __future__ import annotations

import functools
import json
import threading
import time
import traceback
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Callable, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ._http import HTTPClient

# Thread-local storage for span context propagation.
_context = threading.local()


def _get_http() -> "Optional[HTTPClient]":
    return getattr(_context, "http", None)


def _get_sandbox_id() -> Optional[str]:
    return getattr(_context, "sandbox_id", None)


def _get_parent_span() -> Optional[str]:
    return getattr(_context, "current_span_id", None)


def _set_parent_span(span_id: Optional[str]) -> Optional[str]:
    prev = getattr(_context, "current_span_id", None)
    _context.current_span_id = span_id
    return prev


def _get_root_span() -> Optional[str]:
    """Top of the current workflow tree.

    The first ``@traced`` (or ``with traced(...)``) call on a thread is the
    root. Nested traced calls reuse the same root. ``plr.wrap_openai`` and
    friends read this to stamp ``root_span_id`` on the LLM-call events
    they emit, so the dashboard can render the whole workflow as one
    trace tree instead of a flat list of LLM calls.
    """
    return getattr(_context, "root_span_id", None)


def _set_root_span_if_unset(span_id: str) -> bool:
    """If no root span is active for this thread, claim this as the root.

    Returns True if this call set the root (caller is responsible for
    clearing it on exit); False if a root was already set (caller is a
    nested span and should leave the root alone).
    """
    if getattr(_context, "root_span_id", None):
        return False
    _context.root_span_id = span_id
    return True


def _clear_root_span() -> None:
    _context.root_span_id = None


def init_tracing(http: "HTTPClient", sandbox_id: str, *, otel_tracer: Any = None) -> None:
    """Initialize tracing for the current thread. Called by :meth:`Keystone.init_tracing`.

    Args:
        http: Keystone HTTP client (internal).
        sandbox_id: Sandbox to report spans to.
        otel_tracer: Optional ``opentelemetry.trace.Tracer`` instance. When
            supplied, every ``@traced`` span additionally becomes an OTel
            span with ``gen_ai.*`` semantic-convention attributes, so the
            trace is visible in both Keystone's UI and any OTel backend the
            caller's OTel SDK is configured to export to.
    """

    _context.http = http
    _context.sandbox_id = sandbox_id
    _context.current_span_id = None
    _context.otel_tracer = otel_tracer


_otel_flush_callbacks: list = []


def register_otel_flush(callback: Callable[[], None]) -> None:
    """Register a callback to run when the SDK flushes traces.

    Equivalent to Braintrust's ``register_otel_flush`` — lets OTel exporters
    piggy-back on Keystone's flush lifecycle so you don't need a separate
    atexit handler.
    """

    _otel_flush_callbacks.append(callback)


def flush_otel() -> None:
    """Invoke every registered OTel flush callback (best-effort)."""

    for cb in list(_otel_flush_callbacks):
        try:
            cb()
        except Exception:
            pass


def _post_event(event: dict) -> None:
    """Fire-and-forget post of a single trace event.

    Sandbox mode (``sandbox_id`` set) → ``/v1/sandboxes/:id/trace``.
    Agent mode (empty / None sandbox_id) → ``/v1/traces``, scoped by API key
    server-side. Callers with neither a sandbox nor an HTTP client (never
    called ``init_tracing``) stay no-ops.
    """
    http = _get_http()
    sandbox_id = _get_sandbox_id()
    if http is None:
        return

    def _send():
        try:
            if sandbox_id:
                http.post(f"/v1/sandboxes/{sandbox_id}/trace", {"events": [event]})
            else:
                http.post("/v1/traces", {"events": [event]})
        except Exception:
            pass

    t = threading.Thread(target=_send, daemon=True)
    t.start()


def _make_span_id() -> str:
    import uuid
    return uuid.uuid4().hex[:16]


class _TracedContextManager:
    """Context manager that captures a span."""

    def __init__(self, name: str) -> None:
        self.name = name
        self.span_id = _make_span_id()
        self.parent_span_id: Optional[str] = None
        self._prev_span: Optional[str] = None
        self._start: float = 0
        self._output: Any = None
        self._owns_root: bool = False
        self.root_span_id: Optional[str] = None

    def set_output(self, output: Any) -> None:
        """Manually set the span output."""
        self._output = output

    def __call__(self, fn: Callable) -> Callable:
        """Allow `traced(name="x")` to also be used as a decorator, not just
        a context manager. This makes ``@traced(name="my-tool")`` work the
        way the docstring documents. Without this, Python hits the expression
        ``@_TracedContextManager(...)`` which requires the returned object
        to be callable with the decorated function.
        """
        import functools
        import inspect
        span_name = self.name

        if inspect.iscoroutinefunction(fn):
            @functools.wraps(fn)
            async def async_wrapper(*args, **kwargs):
                with _TracedContextManager(span_name) as span:
                    result = await fn(*args, **kwargs)
                    span.set_output(result)
                    return result
            return async_wrapper

        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            with _TracedContextManager(span_name) as span:
                result = fn(*args, **kwargs)
                span.set_output(result)
                return result
        return wrapper

    def __enter__(self) -> "_TracedContextManager":
        self.parent_span_id = _get_parent_span()
        self._prev_span = _set_parent_span(self.span_id)
        # The first traced block on this thread becomes the root of the
        # workflow. Nested traced blocks inherit the same root so the whole
        # tree threads back to one row in the dashboard.
        self._owns_root = _set_root_span_if_unset(self.span_id)
        self.root_span_id = _get_root_span()
        self._start = time.time()

        _post_event({
            "ts": datetime.now(timezone.utc).isoformat(),
            "event_type": "tool_call",
            "tool": self.name,
            "phase": "start",
            "span_id": self.span_id,
            "parent_span_id": self.parent_span_id or "",
            "root_span_id": self.root_span_id or "",
            "status": "ok",
        })
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        duration_ms = int((time.time() - self._start) * 1000)
        _set_parent_span(self._prev_span)

        status = "ok"
        error_type = ""
        output = ""
        if exc_val is not None:
            status = "error"
            error_type = "tool_error"
            output = f"{type(exc_val).__name__}: {exc_val}"
        elif self._output is not None:
            try:
                output = json.dumps(self._output) if not isinstance(self._output, str) else self._output
            except (TypeError, ValueError):
                output = str(self._output)

        _post_event({
            "ts": datetime.now(timezone.utc).isoformat(),
            "event_type": "tool_call",
            "tool": self.name,
            "phase": "end",
            "span_id": self.span_id,
            "parent_span_id": self.parent_span_id or "",
            "root_span_id": self.root_span_id or "",
            "duration_ms": duration_ms,
            "status": status,
            "error_type": error_type,
            "output": output,
        })
        # Only the call that claimed the root clears it. This protects
        # workflows that intentionally span multiple decorator calls on
        # the same thread (rare, but safe to handle).
        if self._owns_root:
            _clear_root_span()
        return None  # don't suppress exceptions


def traced(fn: Optional[Callable] = None, fn2: Optional[Callable] = None, *, name: Optional[str] = None):
    """Decorator, context manager, and direct wrapper for tracing function calls.

    As a decorator::

        @traced
        def my_tool(arg):
            return result

    With a custom name::

        @traced(name="custom-name")
        def my_tool(arg):
            return result

    As a context manager::

        with traced(name="step-name") as span:
            result = do_work()
            span.set_output(result)

    As a direct wrapper (TypeScript-parity form)::

        result = traced("step-name", lambda: do_work())
        result = await traced("step-name", async_work)  # async supported
    """
    # Direct-call form: traced("name", fn) or traced("name", async_fn)
    # Matches the TS ``traced(name, fn)`` API so cross-language code reads
    # identically. For async fns, returns the coroutine so the caller
    # awaits naturally.
    if isinstance(fn, str) and callable(fn2):
        label = fn
        target = fn2
        import inspect
        if inspect.iscoroutinefunction(target):
            async def _run():
                with _TracedContextManager(label) as span:
                    result = await target()
                    span.set_output(result)
                    return result
            return _run()
        with _TracedContextManager(label) as span:
            result = target()
            span.set_output(result)
            return result

    # Called as @traced (no parens) — fn is the decorated function.
    if fn is not None and callable(fn):
        tool_name = name or fn.__name__

        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            with _TracedContextManager(tool_name) as span:
                result = fn(*args, **kwargs)
                span.set_output(result)
                return result

        @functools.wraps(fn)
        async def async_wrapper(*args, **kwargs):
            with _TracedContextManager(tool_name) as span:
                result = await fn(*args, **kwargs)
                span.set_output(result)
                return result

            return result

        import inspect
        if inspect.iscoroutinefunction(fn):
            return async_wrapper
        return wrapper

    # Called as @traced(name="...") or traced(name="...") context manager.
    if fn is None:
        if name is not None:
            # Context manager: traced(name="step")
            return _TracedContextManager(name)
        # @traced() with empty parens — return decorator factory.
        def decorator(f: Callable) -> Callable:
            return traced(f, name=name)
        return decorator

    raise TypeError(f"traced() got unexpected argument: {fn!r}")
