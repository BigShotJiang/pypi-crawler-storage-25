# -*- coding: utf-8 -*-
"""
:Date: 2022-09-06 15:17:12
:LastEditTime: 2023-02-21 15:47:49
:Description: 
"""

#此文件由rigger自动生成
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import CacheModel
from enum import Enum


class TradeOrderExcludeModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp_member', sub_table=None, db_transaction=None, context=None, is_auto=False):
        super(TradeOrderExcludeModel, self).__init__(TradeOrderExclude, sub_table)
        self.db = MySQLHelper(config.get_value(db_connect_key))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    #方法扩展请继承此类
    
class TradeOrderExclude:

    def __init__(self):
        super(TradeOrderExclude, self).__init__()
        self.id = 0  # id
        self.app_id = ""  # app_id
        self.user_id = ""  # 客户ID
        self.business_id = 0  # 商家标识
        self.store_id = 0  # 店铺标识
        self.main_pay_order_no = ""  # 主订单号
        self.sub_pay_order_no = ""  # 子订单号
        self.goods_id = ""  # 商品ID
        self.is_give_integral = 0  # 是否赠送积分(1-是 0-否)
        self.is_give_growth = 0  # 是否赠送成长值(1-是 0-否)
        self.create_date = "1970-01-01 00:00:00.000"  # 创建时间

    @classmethod
    def get_field_list(self):
        return ['id','app_id','user_id','business_id','store_id','main_pay_order_no','sub_pay_order_no','goods_id','is_give_integral','is_give_growth','create_date']
        
    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "trade_order_exclude_tb"
    
