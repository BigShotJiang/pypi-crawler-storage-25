# -*- coding: utf-8 -*-
"""
:Date: 2022-09-06 15:17:12
:LastEditTime: 2023-02-21 15:47:49
:Description: 
"""

#此文件由rigger自动生成
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import CacheModel
from enum import Enum


class TradeStatusInfoModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp_member', sub_table=None, db_transaction=None, context=None, is_auto=False):
        super(TradeStatusInfoModel, self).__init__(TradeStatusInfo, sub_table)
        self.db = MySQLHelper(config.get_value(db_connect_key))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    #方法扩展请继承此类
    
class TradeStatusInfo:

    def __init__(self):
        super(TradeStatusInfo, self).__init__()
        self.id = 0  # id
        self.app_id = ""  # app_id
        self.user_id = ""  # 客户ID
        self.business_id = 0  # 商家标识
        self.store_id = 0  # 店铺标识
        self.main_pay_order_no = ""  # 主订单号
        self.order_status = ""  # 订单状态
        self.platform_id = 0  # 平台标识(1-淘宝 2-抖音 3-京东 4-微信)
        self.change_date = "1970-01-01 00:00:00.000"  # 状态变更时间
        self.is_sync = 0  # 是否同步(0-否 1-是 2-不同步)
        self.sync_date = "1970-01-01 00:00:00.000"  # 同步时间

    @classmethod
    def get_field_list(self):
        return ['id','app_id','user_id','business_id','store_id','main_pay_order_no','order_status','platform_id','change_date','is_sync','sync_date']
        
    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "trade_status_info_tb"
    
