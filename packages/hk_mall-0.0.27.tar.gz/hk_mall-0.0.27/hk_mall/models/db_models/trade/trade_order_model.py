# -*- coding: utf-8 -*-
"""
:Date: 2022-09-06 15:17:12
:LastEditTime: 2023-02-21 15:47:49
:Description: 
"""

#此文件由rigger自动生成
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import CacheModel
from enum import Enum


class TradeOrderModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp_member', sub_table=None, db_transaction=None, context=None, is_auto=False):
        super(TradeOrderModel, self).__init__(TradeOrder, sub_table)
        self.db = MySQLHelper(config.get_value(db_connect_key))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    #方法扩展请继承此类
    
class TradeOrder:

    def __init__(self):
        super(TradeOrder, self).__init__()
        self.id = 0  # id
        self.app_id = ""  # app_id
        self.business_id = 0  # 商家标识
        self.store_id = 0  # 店铺标识
        self.plat_store_id = ""  # 平台店铺标识
        self.user_id = ""  # 客户ID
        self.ouid = ""  # 平台用户标识（ouid）
        self.platform_id = 0  # 平台标识(1-淘宝 2-抖音 3-京东 4-微信)
        self.main_pay_order_no = ""  # 主订单号
        self.sub_pay_order_no = ""  # 子订单号
        self.goods_code = ""  # 商家编码
        self.goods_name = ""  # 商品名称
        self.goods_pic = ""  # 商品图片
        self.goods_id = ""  # 商品ID
        self.sku_id = ""  # sku_id
        self.buy_num = 0  # 商品件数
        self.goods_price = "0.0000"  # 商品价格
        self.order_price = "0.0000"  # 子订单金额(不含邮费)
        self.pay_price = "0.0000"  # 子支付金额
        self.discount_price = "0.0000"  # 优惠金额
        self.divide_order_price = "0.0000"  # 分摊后子订单实付金额(淘宝未支付的都是0)
        self.order_status = ""  # 订单状态
        self.refund_status = ""  # 退款状态
        self.refund_id = ""  # 退款单号
        self.refund_price = "0.0000"  # 退款金额

    @classmethod
    def get_field_list(self):
        return ['id','app_id','business_id','store_id','plat_store_id','user_id','ouid','platform_id','main_pay_order_no','sub_pay_order_no','goods_code','goods_name','goods_pic','goods_id','sku_id','buy_num','goods_price','order_price','pay_price','discount_price','divide_order_price','order_status','refund_status','refund_id','refund_price']
        
    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "trade_order_tb"
    
