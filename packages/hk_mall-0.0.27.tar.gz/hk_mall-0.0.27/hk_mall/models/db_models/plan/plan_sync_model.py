# -*- coding: utf-8 -*-
"""
:Date: 2022-09-06 15:17:12
:LastEditTime: 2023-02-21 15:47:49
:Description: 
"""

#此文件由rigger自动生成
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import CacheModel
from enum import Enum


class PlanSyncModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp_member', sub_table=None, db_transaction=None, context=None, is_auto=False):
        super(PlanSyncModel, self).__init__(PlanSync, sub_table)
        self.db = MySQLHelper(config.get_value(db_connect_key))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    #方法扩展请继承此类
    
class PlanSync:

    def __init__(self):
        super(PlanSync, self).__init__()
        self.id = 0  # id
        self.app_id = ""  # 程序标识
        self.act_id = 0  # 活动标识
        self.sync_type = 0  # 同步类型(1-商品 2-订单)
        self.last_sync_date = "1900-01-01 00:00:00"  # 上次同步时间
        self.now_sync_date = "1900-01-01 00:00:00"  # 计划同步时间
        self.sync_info = ""  # 同步信息
        self.retry_times = 0  # 重试次数
        self.status = 0  # 更新状态(0-待执行 1-执行中 2-失败重试 3-更新失败 4-更新成功 5-手动重试)
        self.message = ""  # 失败说明
        self.create_date = "1900-01-01 00:00:00"  # 创建时间
        self.modify_date = "1900-01-01 00:00:00"  # 修改时间

    @classmethod
    def get_field_list(self):
        return ['id','app_id','act_id','sync_type','last_sync_date','now_sync_date','sync_info','retry_times','status','message','create_date','modify_date']
        
    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "plan_sync_tb"
    
