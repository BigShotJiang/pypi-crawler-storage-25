# -*- coding: utf-8 -*-
"""
:Date: 2022-09-06 15:17:12
:LastEditTime: 2023-02-21 15:47:49
:Description: 
"""

#此文件由rigger自动生成
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import CacheModel
from enum import Enum


class UserTrendsModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp_member', sub_table=None, db_transaction=None, context=None, is_auto=False):
        super(UserTrendsModel, self).__init__(UserTrends, sub_table)
        self.db = MySQLHelper(config.get_value(db_connect_key))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    #方法扩展请继承此类
    
class UserTrends:

    def __init__(self):
        super(UserTrends, self).__init__()
        self.id = 0  # id
        self.app_id = ""  # app_id
        self.business_id = 0  # 商家标识
        self.user_id = ""  # 客户标识
        self.source_type = 0  # 来源类型(1-互动 2-订单 3-营销)
        self.trends_desc = ""  # 动态描述
        self.create_date = "1970-01-01 00:00:00.000"  # 创建时间
        self.create_day = 0  # 创建天

    @classmethod
    def get_field_list(self):
        return ['id','app_id','business_id','user_id','source_type','trends_desc','create_date','create_day']
        
    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "user_trends_tb"
    
