# -*- coding: utf-8 -*-
"""
:Date: 2022-09-06 15:17:12
:LastEditTime: 2023-02-21 15:47:49
:Description: 
"""

#此文件由rigger自动生成
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import CacheModel
from enum import Enum


class MemberAssetIntegralModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp_member', sub_table=None, db_transaction=None, context=None, is_auto=False):
        super(MemberAssetIntegralModel, self).__init__(MemberAssetIntegral, sub_table)
        self.db = MySQLHelper(config.get_value(db_connect_key))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    #方法扩展请继承此类
    
class MemberAssetIntegral:

    def __init__(self):
        super(MemberAssetIntegral, self).__init__()
        self.id = 0  # id
        self.app_id = ""  # app_id
        self.id_md5 = ""  # id_md5
        self.business_id = 0  # 商家标识
        self.one_id = ""  # one_id
        self.asset_type = 0  # 资产类型(1-积分 2-成长值)
        self.asset_object_id = ""  # 资产对象标识
        self.asset_value = 0  # 资产值
        self.asset_check_code = ""  # 资产检验码(id+asset_value+加密签名)md5生成
        self.total_incr_value = 0  # 累计获得资产值
        self.total_decr_value = 0  # 累计消耗资产值
        self.total_expire_value = 0  # 累计过期资产值
        self.create_date = "1970-01-01 00:00:00.000"  # 创建时间
        self.modify_date = "1970-01-01 00:00:00.000"  # 修改时间

    @classmethod
    def get_field_list(self):
        return ['id','app_id','id_md5','business_id','one_id','asset_type','asset_object_id','asset_value','asset_check_code','total_incr_value','total_decr_value','total_expire_value','create_date','modify_date']
        
    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "member_asset_integral_tb"
    
