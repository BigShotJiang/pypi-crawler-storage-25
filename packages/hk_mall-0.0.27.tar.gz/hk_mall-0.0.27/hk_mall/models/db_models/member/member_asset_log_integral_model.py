# -*- coding: utf-8 -*-
"""
:Date: 2022-09-06 15:17:12
:LastEditTime: 2023-02-21 15:47:49
:Description: 
"""

#此文件由rigger自动生成
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import CacheModel
from enum import Enum


class MemberAssetLogIntegralModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp_member', sub_table=None, db_transaction=None, context=None, is_auto=False):
        super(MemberAssetLogIntegralModel, self).__init__(MemberAssetLogIntegral, sub_table)
        self.db = MySQLHelper(config.get_value(db_connect_key))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    #方法扩展请继承此类
    
class MemberAssetLogIntegral:

    def __init__(self):
        super(MemberAssetLogIntegral, self).__init__()
        self.id = 0  # id
        self.app_id = ""  # app_id
        self.business_id = 0  # 商家标识
        self.scheme_id = 0  # 体系标识
        self.change_no = ""  # 变更流水号
        self.one_id = ""  # one_id
        self.user_id = ""  # 客户ID
        self.log_title = ""  # 标题
        self.asset_type = 0  # 资产类型(1-积分 2-成长值)
        self.asset_object_id = ""  # 资产对象标识
        self.store_id = 0  # 店铺标识
        self.business_type = 0  # 业务类型(0-初始化 1-订单赠送 2-退单扣减 3-人工调整 4-互动 5-官方直发 6-积分兑换)
        self.source_type = 0  # 来源类型(1-好客会员 2-忠诚度管理 3-淘宝会员通 4-抖音会员通 5-京东会员通)
        self.source_object_id = ""  # 来源对象标识(订单奖励来源为订单号)
        self.source_object_name = ""  # 来源对象名称
        self.operate_type = 0  # 变更类型 （0-发放 1-消费 2-过期 3-作废）
        self.operate_value = 0  # 操作值
        self.surplus_value = 0  # 剩余值
        self.history_value = 0  # 历史值
        self.processed_price = "0"  # 已处理金额
        self.valid_type = 0  # 有效期类型(1-永久有效 2-指定时间)
        self.valid_end_date = "1970-01-01 00:00:00.000"  # 有效期结束时间
        self.remark = ""  # 备注
        self.operate_user_id = ""  # 操作用户标识
        self.operate_user_name = ""  # 操作用户名称
        self.create_date = "1970-01-01 00:00:00.000"  # 创建时间
        self.info_json = ""  # 扩展信息json
        self.source_sub_type = 0  # 来源子类型(27-发放 29-店铺签到发放 30-关注店铺发放 31-互动发放 32-其他渠道发放 26-消费 33-兑换优惠劵消耗 34-兑换红包消耗 35-兑换京豆消耗 36-兑换其他权益消耗 37-互动消耗 38-手动调整)

    @classmethod
    def get_field_list(self):
        return ['id','app_id','business_id','scheme_id','change_no','one_id','user_id','log_title','asset_type','asset_object_id','store_id','business_type','source_type','source_object_id','source_object_name','operate_type','operate_value','surplus_value','history_value','processed_price','valid_type','valid_end_date','remark','operate_user_id','operate_user_name','create_date','info_json','source_sub_type']
        
    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "member_asset_log_integral_tb"
    
