"""
LangGraph OpenTelemetry Instrumentor

A custom OpenTelemetry instrumentor that captures LangGraph-specific telemetry:
- Full graph topology (nodes, edges, conditional edges)
- State snapshots before/after each node execution
- Conditional edge evaluation results
- Graph transitions and routing decisions

Usage:
    from langgraph_otel_instrumentor import LangGraphInstrumentor

    # After setting up your OTel tracer provider:
    LangGraphInstrumentor().instrument()

    # Then use LangGraph as normal — all telemetry is captured automatically.
"""

from langgraph_otel_instrumentor.instrumentor import LangGraphInstrumentor

__all__ = ["LangGraphInstrumentor"]
__version__ = "0.1.0"
