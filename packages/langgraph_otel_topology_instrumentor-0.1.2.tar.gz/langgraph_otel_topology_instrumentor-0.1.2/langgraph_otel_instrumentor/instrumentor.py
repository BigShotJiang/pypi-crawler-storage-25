"""
Core LangGraph OpenTelemetry Instrumentor.

Patches LangGraph's CompiledGraph to emit spans capturing:
- Graph topology at compile time
- Node executions with state before/after
- Edge transitions with conditional routing decisions
- Full execution flow for visual reconstruction
"""

import json
import copy
import logging
import functools
from typing import Any, Optional

from opentelemetry import trace, context
from opentelemetry.trace import StatusCode
from opentelemetry.instrumentation.instrumentor import BaseInstrumentor
from opentelemetry.instrumentation.utils import unwrap

logger = logging.getLogger(__name__)

# Attributes namespace
_NS = "langgraph"

# ──────────────────────────────────────────────
# Utility: safe JSON serialization of state
# ──────────────────────────────────────────────

def _safe_serialize(obj: Any, max_depth: int = 6, max_str_len: int = 2000) -> str:
    """Serialize an object to JSON, handling non-serializable types gracefully."""

    def _sanitize(o, depth=0):
        if depth > max_depth:
            return "<max_depth_exceeded>"
        if o is None or isinstance(o, (bool, int, float)):
            return o
        if isinstance(o, str):
            return o[:max_str_len] + "..." if len(o) > max_str_len else o
        if isinstance(o, bytes):
            return f"<bytes len={len(o)}>"
        if isinstance(o, dict):
            return {str(k): _sanitize(v, depth + 1) for k, v in o.items()}
        if isinstance(o, (list, tuple, set, frozenset)):
            items = [_sanitize(i, depth + 1) for i in o]
            return items
        # LangChain message objects
        if hasattr(o, "to_json"):
            try:
                return _sanitize(o.to_json(), depth + 1)
            except Exception:
                pass
        if hasattr(o, "dict"):
            try:
                return _sanitize(o.dict(), depth + 1)
            except Exception:
                pass
        if hasattr(o, "__dict__"):
            return _sanitize(vars(o), depth + 1)
        return str(o)[:max_str_len]

    try:
        return json.dumps(_sanitize(obj), default=str, ensure_ascii=False)
    except Exception:
        return json.dumps({"error": "serialization_failed", "type": str(type(obj))})


def _shallow_state_summary(state: Any) -> dict:
    """Create a lightweight summary of state for span attributes."""
    if not isinstance(state, dict):
        return {"_type": type(state).__name__, "_value": str(state)[:500]}

    summary = {}
    for k, v in state.items():
        if isinstance(v, list):
            summary[k] = f"<list len={len(v)}>"
        elif isinstance(v, dict):
            summary[k] = f"<dict keys={list(v.keys())[:10]}>"
        elif isinstance(v, str) and len(v) > 200:
            summary[k] = v[:200] + "..."
        else:
            summary[k] = v
    return summary


# ──────────────────────────────────────────────
# Graph topology extraction
# ──────────────────────────────────────────────

_START = "__start__"
_END = "__end__"


def _extract_topology(graph, builder=None) -> dict:
    """
    Extract the full graph topology.

    In modern LangGraph, the authoritative source of graph structure is the
    StateGraph *builder*, not the CompiledGraph. Edges, conditional branches,
    and the entry/finish points live on the builder; the compiled graph
    transforms them into a Pregel runtime structure where they're no longer
    directly introspectable as a graph.

    So we prefer `builder` (the pre-compile StateGraph) when available and
    fall back to best-effort introspection of the compiled graph.
    """
    topology = {
        "nodes": [],
        "edges": [],
        "conditional_edges": [],
    }

    # Prefer the builder — it has the real structure
    source = builder if builder is not None else graph

    # ─── Nodes ───
    nodes_attr = getattr(source, "nodes", None)
    if isinstance(nodes_attr, dict):
        for name, node in nodes_attr.items():
            node_info = {"name": name}
            if name == _START:
                node_info["type"] = "entry"
            elif name == _END:
                node_info["type"] = "exit"
            else:
                node_info["type"] = "node"
                # Builder stores nodes as StateNodeSpec with .runnable
                runnable = getattr(node, "runnable", None) or node
                func = getattr(runnable, "func", None) or getattr(runnable, "bound", None) or runnable
                func_name = getattr(func, "__name__", None)
                if func_name:
                    node_info["func"] = func_name
            topology["nodes"].append(node_info)

    # Always ensure __start__ and __end__ are present
    existing_names = {n["name"] for n in topology["nodes"]}
    if _START not in existing_names:
        topology["nodes"].insert(0, {"name": _START, "type": "entry"})
    if _END not in existing_names:
        topology["nodes"].append({"name": _END, "type": "exit"})

    # ─── Static edges ───
    # StateGraph.edges is a set of (source, target) tuples
    edges_attr = getattr(source, "edges", None)
    if edges_attr is not None:
        try:
            for edge in edges_attr:
                if isinstance(edge, tuple) and len(edge) == 2:
                    topology["edges"].append({"source": edge[0], "target": edge[1]})
                elif isinstance(edge, dict) and "source" in edge:
                    topology["edges"].append({"source": edge["source"], "target": edge.get("target")})
        except TypeError:
            # edges might be a dict in some versions
            if isinstance(edges_attr, dict):
                for src, targets in edges_attr.items():
                    if isinstance(targets, (list, set, tuple)):
                        for t in targets:
                            topology["edges"].append({"source": src, "target": t})
                    else:
                        topology["edges"].append({"source": src, "target": targets})

    # ─── Conditional edges / branches ───
    # Builder.branches is a dict[source_node, dict[branch_key, Branch]]
    branches_attr = getattr(source, "branches", None)
    if isinstance(branches_attr, dict):
        for src, branch_map in branches_attr.items():
            if not isinstance(branch_map, dict):
                continue
            for branch_key, branch in branch_map.items():
                cond_edge = {"source": src}

                # The routing function
                path_fn = getattr(branch, "path", None)
                if path_fn is not None:
                    # It may be a Runnable wrapping the actual function
                    raw = getattr(path_fn, "func", None) or getattr(path_fn, "bound", None) or path_fn
                    cond_edge["condition_func"] = getattr(raw, "__name__", str(branch_key))
                else:
                    cond_edge["condition_func"] = str(branch_key)

                # The path_map: return value → target node
                ends = getattr(branch, "ends", None)
                if ends:
                    cond_edge["path_map"] = {str(k): str(v) for k, v in ends.items()}
                else:
                    # Without an explicit mapping, we can only note the source
                    cond_edge["path_map"] = {}

                then = getattr(branch, "then", None)
                if then:
                    cond_edge["then"] = then

                topology["conditional_edges"].append(cond_edge)

    # ─── Entry / finish ───
    entry = getattr(source, "entry_point", None) or getattr(source, "_entry_point", None)
    finish = getattr(source, "finish_point", None) or getattr(source, "_finish_point", None)
    if entry:
        topology["entry_point"] = entry
        # Synthesize __start__ → entry edge if not already there
        if not any(e["source"] == _START and e["target"] == entry for e in topology["edges"]):
            topology["edges"].append({"source": _START, "target": entry})
    if finish:
        topology["finish_point"] = finish
        if not any(e["source"] == finish and e["target"] == _END for e in topology["edges"]):
            topology["edges"].append({"source": finish, "target": _END})

    return topology


# ──────────────────────────────────────────────
# Wrappers
# ──────────────────────────────────────────────

def _wrap_invoke(original_invoke, tracer):
    """Wrap CompiledGraph.invoke to create a root span with topology."""

    @functools.wraps(original_invoke)
    def patched_invoke(self, input, config=None, **kwargs):
        topology = getattr(self, "_lg_otel_topology", None) or _extract_topology(self)

        with tracer.start_as_current_span(
            "langgraph.graph.invoke",
            attributes={
                f"{_NS}.graph.topology": json.dumps(topology, default=str),
                f"{_NS}.graph.node_count": len(topology["nodes"]),
                f"{_NS}.graph.edge_count": len(topology["edges"]),
                f"{_NS}.graph.conditional_edge_count": len(
                    topology["conditional_edges"]
                ),
                f"{_NS}.graph.input": _safe_serialize(input),
                "langsmith.span.kind": "chain",
            },
        ) as span:
            try:
                result = original_invoke(self, input, config=config, **kwargs)
                span.set_attribute(
                    f"{_NS}.graph.output", _safe_serialize(result)
                )
                span.set_status(StatusCode.OK)
                return result
            except Exception as e:
                span.set_status(StatusCode.ERROR, str(e))
                span.record_exception(e)
                raise

    return patched_invoke


def _wrap_ainvoke(original_ainvoke, tracer):
    """Wrap CompiledGraph.ainvoke (async version)."""

    @functools.wraps(original_ainvoke)
    async def patched_ainvoke(self, input, config=None, **kwargs):
        topology = getattr(self, "_lg_otel_topology", None) or _extract_topology(self)

        with tracer.start_as_current_span(
            "langgraph.graph.invoke",
            attributes={
                f"{_NS}.graph.topology": json.dumps(topology, default=str),
                f"{_NS}.graph.node_count": len(topology["nodes"]),
                f"{_NS}.graph.edge_count": len(topology["edges"]),
                f"{_NS}.graph.conditional_edge_count": len(
                    topology["conditional_edges"]
                ),
                f"{_NS}.graph.input": _safe_serialize(input),
                "langsmith.span.kind": "chain",
            },
        ) as span:
            try:
                result = await original_ainvoke(self, input, config=config, **kwargs)
                span.set_attribute(
                    f"{_NS}.graph.output", _safe_serialize(result)
                )
                span.set_status(StatusCode.OK)
                return result
            except Exception as e:
                span.set_status(StatusCode.ERROR, str(e))
                span.record_exception(e)
                raise

    return patched_ainvoke


def _wrap_stream(original_stream, tracer):
    """Wrap CompiledGraph.stream to capture streaming execution."""

    @functools.wraps(original_stream)
    def patched_stream(self, input, config=None, **kwargs):
        topology = getattr(self, "_lg_otel_topology", None) or _extract_topology(self)

        with tracer.start_as_current_span(
            "langgraph.graph.stream",
            attributes={
                f"{_NS}.graph.topology": json.dumps(topology, default=str),
                f"{_NS}.graph.node_count": len(topology["nodes"]),
                f"{_NS}.graph.edge_count": len(topology["edges"]),
                f"{_NS}.graph.conditional_edge_count": len(
                    topology["conditional_edges"]
                ),
                f"{_NS}.graph.input": _safe_serialize(input),
                "langsmith.span.kind": "chain",
            },
        ) as span:
            step_counter = 0
            last_node = None
            try:
                for event in original_stream(self, input, config=config, **kwargs):
                    step_counter += 1

                    # Stream events are typically dicts of {node_name: state_update}
                    if isinstance(event, dict):
                        for node_name, state_update in event.items():
                            # Record transition
                            transition = {
                                "step": step_counter,
                                "from_node": last_node,
                                "to_node": node_name,
                                "state_update_keys": list(state_update.keys())
                                if isinstance(state_update, dict)
                                else None,
                            }
                            span.add_event(
                                "langgraph.transition",
                                attributes={
                                    f"{_NS}.transition": json.dumps(
                                        transition, default=str
                                    ),
                                    f"{_NS}.node.name": node_name,
                                    f"{_NS}.node.output": _safe_serialize(
                                        state_update
                                    ),
                                    f"{_NS}.step": step_counter,
                                },
                            )
                            last_node = node_name

                    yield event

                span.set_attribute(f"{_NS}.graph.total_steps", step_counter)
                span.set_status(StatusCode.OK)
            except Exception as e:
                span.set_status(StatusCode.ERROR, str(e))
                span.record_exception(e)
                raise

    return patched_stream


def _wrap_node_action(original_action, node_name, tracer):
    """Wrap an individual node's action to capture state before/after."""

    @functools.wraps(original_action)
    def patched_action(*args, **kwargs):
        state = args[0] if args else None
        with tracer.start_as_current_span(
            f"langgraph.node.{node_name}",
            attributes={
                f"{_NS}.node.name": node_name,
                f"{_NS}.node.type": "node",
                f"{_NS}.node.state_before": _safe_serialize(
                    _shallow_state_summary(state)
                ),
                "langsmith.span.kind": "chain",
            },
        ) as span:
            try:
                result = original_action(*args, **kwargs)

                span.set_attribute(
                    f"{_NS}.node.state_after",
                    _safe_serialize(_shallow_state_summary(result)),
                )
                span.set_attribute(
                    f"{_NS}.node.output", _safe_serialize(result)
                )

                # Compute state diff
                if isinstance(state, dict) and isinstance(result, dict):
                    added = set(result.keys()) - set(state.keys())
                    removed = set(state.keys()) - set(result.keys())
                    modified = {
                        k
                        for k in set(state.keys()) & set(result.keys())
                        if state.get(k) != result.get(k)
                    }
                    diff = {
                        "added_keys": list(added),
                        "removed_keys": list(removed),
                        "modified_keys": list(modified),
                    }
                    span.set_attribute(
                        f"{_NS}.node.state_diff", json.dumps(diff)
                    )

                span.set_status(StatusCode.OK)
                return result
            except Exception as e:
                span.set_status(StatusCode.ERROR, str(e))
                span.record_exception(e)
                raise

    return patched_action


def _wrap_node_action_async(original_action, node_name, tracer):
    """Wrap an async node action."""

    @functools.wraps(original_action)
    async def patched_action(*args, **kwargs):
        state = args[0] if args else None
        with tracer.start_as_current_span(
            f"langgraph.node.{node_name}",
            attributes={
                f"{_NS}.node.name": node_name,
                f"{_NS}.node.type": "node",
                f"{_NS}.node.state_before": _safe_serialize(
                    _shallow_state_summary(state)
                ),
                "langsmith.span.kind": "chain",
            },
        ) as span:
            try:
                result = await original_action(*args, **kwargs)

                span.set_attribute(
                    f"{_NS}.node.state_after",
                    _safe_serialize(_shallow_state_summary(result)),
                )
                span.set_attribute(
                    f"{_NS}.node.output", _safe_serialize(result)
                )

                if isinstance(state, dict) and isinstance(result, dict):
                    added = set(result.keys()) - set(state.keys())
                    removed = set(state.keys()) - set(result.keys())
                    modified = {
                        k
                        for k in set(state.keys()) & set(result.keys())
                        if state.get(k) != result.get(k)
                    }
                    diff = {
                        "added_keys": list(added),
                        "removed_keys": list(removed),
                        "modified_keys": list(modified),
                    }
                    span.set_attribute(
                        f"{_NS}.node.state_diff", json.dumps(diff)
                    )

                span.set_status(StatusCode.OK)
                return result
            except Exception as e:
                span.set_status(StatusCode.ERROR, str(e))
                span.record_exception(e)
                raise

    return patched_action


def _wrap_conditional_edge(original_func, edge_name, source_node, path_map, tracer):
    """Wrap a conditional edge function to capture routing decisions."""

    @functools.wraps(original_func)
    def patched_func(state, *args, **kwargs):
        with tracer.start_as_current_span(
            f"langgraph.edge.conditional.{edge_name}",
            attributes={
                f"{_NS}.edge.type": "conditional",
                f"{_NS}.edge.source": source_node,
                f"{_NS}.edge.condition_func": edge_name,
                f"{_NS}.edge.path_map": json.dumps(path_map, default=str)
                if path_map
                else "{}",
                "langsmith.span.kind": "chain",
            },
        ) as span:
            try:
                result = original_func(state, *args, **kwargs)

                # result is the routing decision (typically a string)
                target = result
                if path_map and result in path_map:
                    target = path_map[result]

                span.set_attribute(f"{_NS}.edge.routing_decision", str(result))
                span.set_attribute(f"{_NS}.edge.target", str(target))
                span.set_status(StatusCode.OK)
                return result
            except Exception as e:
                span.set_status(StatusCode.ERROR, str(e))
                span.record_exception(e)
                raise

    return patched_func


# ──────────────────────────────────────────────
# Patch the compile step to intercept graph building
# ──────────────────────────────────────────────

def _wrap_compile(original_compile, tracer):
    """Wrap StateGraph.compile to snapshot topology and patch the CompiledGraph."""

    @functools.wraps(original_compile)
    def patched_compile(self, *args, **kwargs):
        # ─── Snapshot topology from the builder BEFORE compile ───
        # This is the authoritative source — the compiled graph transforms
        # edges into a Pregel runtime structure that's hard to introspect.
        try:
            topology = _extract_topology(None, builder=self)
        except Exception as e:
            logger.warning("Failed to extract topology from builder: %s", e)
            topology = {"nodes": [], "edges": [], "conditional_edges": []}

        # ─── Patch conditional-edge routing functions on the builder ───
        # We do this before compile so the compiled graph picks up the wrapped
        # versions. This gives us the `routing_decision` attribute at runtime.
        try:
            branches = getattr(self, "branches", None)
            if isinstance(branches, dict):
                for src, branch_map in branches.items():
                    if not isinstance(branch_map, dict):
                        continue
                    for branch_key, branch in branch_map.items():
                        path_fn = getattr(branch, "path", None)
                        if path_fn is None or getattr(path_fn, "_lg_otel_wrapped", False):
                            continue
                        raw = getattr(path_fn, "func", None) or path_fn
                        fn_name = getattr(raw, "__name__", str(branch_key))
                        path_map = (
                            {str(k): str(v) for k, v in branch.ends.items()}
                            if getattr(branch, "ends", None)
                            else None
                        )
                        wrapped = _wrap_conditional_edge(
                            path_fn, fn_name, src, path_map, tracer
                        )
                        wrapped._lg_otel_wrapped = True
                        try:
                            branch.path = wrapped
                        except Exception:
                            pass
        except Exception as e:
            logger.warning("Failed to wrap conditional edges: %s", e)

        # ─── Patch node functions on the builder ───
        # _wrap_node_action / _wrap_node_action_async are defined above but
        # were never wired in — this is the missing piece that produces
        # per-node child spans with state_before / state_after / state_diff.
        try:
            import asyncio as _asyncio
            nodes = getattr(self, "nodes", {})
            if isinstance(nodes, dict):
                for node_name, node_spec in nodes.items():
                    if node_name in (_START, _END):
                        continue
                    runnable = getattr(node_spec, "runnable", None)
                    if runnable is None:
                        continue

                    # Patch sync function (RunnableLambda stores it as .func)
                    func = getattr(runnable, "func", None)
                    if func is not None and not getattr(func, "_lg_otel_wrapped", False):
                        wrapped = _wrap_node_action(func, node_name, tracer)
                        wrapped._lg_otel_wrapped = True
                        try:
                            runnable.func = wrapped
                        except Exception:
                            pass

                    # Patch async function (RunnableLambda stores it as .afunc)
                    afunc = getattr(runnable, "afunc", None)
                    if afunc is not None and not getattr(afunc, "_lg_otel_wrapped", False):
                        wrapped_async = _wrap_node_action_async(afunc, node_name, tracer)
                        wrapped_async._lg_otel_wrapped = True
                        try:
                            runnable.afunc = wrapped_async
                        except Exception:
                            pass
        except Exception as e:
            logger.warning("Failed to wrap node actions: %s", e)

        # ─── Compile ───
        compiled = original_compile(self, *args, **kwargs)

        # ─── Attach the snapshotted topology to the compiled instance ───
        try:
            compiled._lg_otel_topology = topology
        except Exception:
            pass

        # ─── Patch invoke/ainvoke/stream on the instance ───
        # We bind instance-level methods so we don't affect the class globally
        # (multiple compiled graphs may coexist).
        cls = compiled.__class__
        if not getattr(cls, "_lg_otel_methods_patched", False):
            orig_invoke = cls.invoke
            orig_ainvoke = cls.ainvoke
            orig_stream = cls.stream

            cls.invoke = _wrap_invoke(orig_invoke, tracer)
            cls.ainvoke = _wrap_ainvoke(orig_ainvoke, tracer)
            cls.stream = _wrap_stream(orig_stream, tracer)

            cls._lg_otel_orig_invoke = orig_invoke
            cls._lg_otel_orig_ainvoke = orig_ainvoke
            cls._lg_otel_orig_stream = orig_stream
            cls._lg_otel_methods_patched = True

        return compiled

    return patched_compile


# ──────────────────────────────────────────────
# Main Instrumentor class
# ──────────────────────────────────────────────

class LangGraphInstrumentor(BaseInstrumentor):
    """
    OpenTelemetry Instrumentor for LangGraph.

    Captures:
    - Graph topology (nodes, edges, conditional edges)
    - State snapshots before/after each node
    - Conditional edge routing decisions
    - Full execution flow with transitions

    Usage:
        LangGraphInstrumentor().instrument()
    """

    _original_compile = None
    _tracer = None

    def instrumentation_dependencies(self):
        return ["langgraph >= 0.2.0"]

    def _instrument(self, **kwargs):
        tracer_provider = kwargs.get("tracer_provider")
        self._tracer = trace.get_tracer(
            "langgraph-otel-instrumentor",
            "0.1.0",
            tracer_provider=tracer_provider,
        )

        try:
            from langgraph.graph.state import StateGraph

            self._original_compile = StateGraph.compile
            StateGraph.compile = _wrap_compile(StateGraph.compile, self._tracer)
            logger.info("LangGraph instrumentation enabled.")
        except ImportError:
            logger.warning(
                "langgraph not found. LangGraphInstrumentor has no effect."
            )

    def _uninstrument(self, **kwargs):
        if self._original_compile is not None:
            try:
                from langgraph.graph.state import StateGraph

                StateGraph.compile = self._original_compile
                self._original_compile = None
                logger.info("LangGraph instrumentation disabled.")
            except ImportError:
                pass
