"""FastMCP server singleton for the twilize MCP server.

This module creates the single FastMCP `server` instance that all tool and
resource modules register against via @server.tool() and @server.resource().

Import order matters: app.py must be imported before tools_*.py and resources.py
so that `server` exists when the decorators run.  The entry point (typically
run via `mcp run` or `python -m twilize.mcp`) imports all tool modules, which
self-register, and then starts the server transport.

The `instructions` string is what AI agents read when they first connect —
it summarises the required call order and points agents to skill resources.
"""

import functools
import logging
from typing import Any

from pydantic import create_model
from mcp.server.fastmcp.utilities import func_metadata as _fm
from mcp.server.fastmcp import FastMCP

_log = logging.getLogger(__name__)

# Monkey-patch: MCP SDK 1.26.0 calls create_model(name, result=type) which
# Pydantic v2 rejects — it needs create_model(name, result=(type, ...)).
_original_create_wrapped = _fm._create_wrapped_model


def _patched_create_wrapped(func_name: str, annotation: Any) -> type:
    model_name = f"{func_name}Output"
    return create_model(model_name, result=(annotation, ...))


_fm._create_wrapped_model = _patched_create_wrapped


class _SafeFastMCP(FastMCP):
    """FastMCP subclass that wraps every tool function with error handling."""

    def tool(self, *args, **kwargs):
        decorator = super().tool(*args, **kwargs)

        def wrapping_decorator(func):
            @functools.wraps(func)
            def safe_wrapper(*a, **kw):
                try:
                    return func(*a, **kw)
                except Exception as exc:
                    _log.error("Tool %s failed: %s", func.__name__, exc, exc_info=True)
                    return f"Error in {func.__name__}: {exc}"
            return decorator(safe_wrapper)
        return wrapping_decorator


server = _SafeFastMCP(
    "twilize",
    instructions=(
        "Tableau Workbook (.twb/.twbx) generation MCP Server.\n\n"
        "CRITICAL: You MUST use the provided tools to build workbooks. "
        "NEVER write Tableau XML directly — hand-written XML will fail to "
        "open in Tableau Desktop. The tools handle all XML generation.\n\n"
        "Required workflow:\n"
        "  1. create_workbook() or open_workbook() — start a session\n"
        "  2. list_fields() — see available datasource fields\n"
        "  3. get_active_rules() — read enforced dashboard creation rules\n"
        "  4. profile_data_source() — profile the connected data source\n"
        "  5. recommend_template() — pick the best layout template\n"
        "  6. add_worksheet() + configure_chart() — build each chart\n"
        "  7. add_dashboard() — combine worksheets into a dashboard\n"
        "  8. save_workbook() — write the .twb or .twbx file\n\n"
        "RULES ENGINE: configure_chart and add_dashboard enforce rules "
        "automatically.  Violations are returned as errors (blocking) or "
        "warnings (advisory).  Call get_active_rules() to see all rules.\n\n"
        "INTELLIGENCE TOOLS:\n"
        "  - get_active_rules() — see enforced creation rules\n"
        "  - profile_data_source() — profile ANY connected data source\n"
        "  - profile_csv() — profile a CSV before connecting\n"
        "  - recommend_template() — pick the best layout template\n"
        "  - list_gallery_templates() — see all available templates\n\n"
        "For end-to-end dashboards from data:\n"
        "  - CSV:   csv_to_dashboard()\n"
        "  - Hyper: hyper_to_dashboard()\n"
        "  - MySQL: mysql_to_dashboard()\n"
        "  - MSSQL: mssql_to_dashboard()\n"
        "Or use csv_to_hyper() + set_hyper_connection() for manual control.\n\n"
        "Use list_capabilities or describe_capability to check whether a "
        "chart type or feature is supported before attempting it."
    ),
)
