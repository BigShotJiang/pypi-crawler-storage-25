"""Dual-branch emotion classifier with Fusion Transformer."""

from __future__ import annotations

import torch
import torch.nn as nn

from eemoclas.model.trial_cnn_transformer import TrialCNNTransformer
from eemoclas.model.transformer_blocks import TransformerEncoderBlock
from eemoclas.model.classification_head import ClassificationHead


# 30 standard 10-20 EEG channel names (same order as ChannelBandTokenEmbedding)
_RAW_CHANNEL_NAMES = [
    "FP1", "FP2", "F7", "F3", "FZ", "F4", "F8",
    "FC5", "FC1", "FC2", "FC6", "T7", "C3", "CZ", "C4", "T8",
    "TP9", "CP5", "CP1", "CP2", "CP6", "TP10", "P7",
    "P3", "PZ", "P4", "P8", "PO9", "O1", "O2",
]


def _make_raw_token_meta():
    """Generate synthetic token_meta for the raw 30-channel branch.

    Only ``source_channel`` is needed because ``use_band_embedding=False``
    skips the band lookup entirely.
    """
    return [{"source_channel": ch} for ch in _RAW_CHANNEL_NAMES]


def _build_trial_encoder(cfg: dict) -> TrialCNNTransformer:
    """Instantiate a TrialCNNTransformer from a config sub-dict."""
    return TrialCNNTransformer(
        input_channels=cfg.get("input_channels", 30),
        input_length=cfg.get("input_length", 2500),
        projection_dim=cfg.get("projection_dim", 128),
        cnn_channels=cfg.get("cnn_channels", [16, 32, 64]),
        kernel_sizes=cfg.get("kernel_sizes", [15, 9, 5]),
        strides=cfg.get("strides", [2, 2, 2]),
        cnn_dropout=cfg.get("cnn_dropout", 0.1),
        transformer_num_layers=cfg.get("transformer_num_layers", 2),
        transformer_num_heads=cfg.get("transformer_num_heads", 4),
        transformer_dim_feedforward=cfg.get("transformer_dim_feedforward", 256),
        transformer_dropout=cfg.get("transformer_dropout", 0.1),
        use_cls_token=cfg.get("use_cls_token", True),
        pooling=cfg.get("pooling", "cls"),
        use_channel_embedding=cfg.get("use_channel_embedding", True),
        use_band_embedding=cfg.get("use_band_embedding", True),
        channel_names=cfg.get("channel_names", None),
        band_names=cfg.get("band_names", None),
    )


class DualBranchEmotionCNNTransformer(nn.Module):
    """Dual-branch emotion classifier with Fusion Transformer.

    Two independent TrialCNNTransformer branches (raw + preprocessed)
    encode their respective inputs into D-dim vectors. These are stacked,
    annotated with learnable branch embeddings, and fed through a Fusion
    Transformer. The CLS output drives a classification head.

    Input:  ``x`` [B, C_eff, 2500] (PP), ``x_raw`` [B, 30, 2500] (raw)
    Output: [B, 2] logits
    """

    def __init__(self, config: dict) -> None:
        super().__init__()

        # Support both flat config and nested "model" sub-dict
        model_cfg = config.get("model", config)
        raw_cfg = model_cfg.get("raw_trial_encoder", {})
        pp_cfg = model_cfg.get("pp_trial_encoder", {})
        fusion_cfg = model_cfg.get("fusion_transformer", {})
        head_cfg = model_cfg.get("classification_head", {})

        D = raw_cfg.get("projection_dim", 128)

        # --- Two independent trial encoders ---
        self.raw_encoder = _build_trial_encoder(raw_cfg)
        self.pp_encoder = _build_trial_encoder(pp_cfg)

        # --- Synthetic token_meta for raw branch ---
        self._raw_token_meta = _make_raw_token_meta()

        # --- Branch embedding (0=raw, 1=pp) ---
        self.branch_embedding = nn.Embedding(2, D)

        # --- CLS token for fusion ---
        self.cls_token = nn.Parameter(torch.zeros(1, 1, D))
        nn.init.trunc_normal_(self.cls_token, std=0.02)

        # --- Fusion Transformer ---
        self.fusion_transformer = TransformerEncoderBlock(
            d_model=fusion_cfg.get("d_model", D),
            num_layers=fusion_cfg.get("num_layers", 2),
            num_heads=fusion_cfg.get("num_heads", 4),
            dim_feedforward=fusion_cfg.get("dim_feedforward", 256),
            dropout=fusion_cfg.get("dropout", 0.1),
            activation=fusion_cfg.get("activation", "gelu"),
            batch_first=fusion_cfg.get("batch_first", True),
            norm_first=fusion_cfg.get("norm_first", True),
        )

        # --- Classification head ---
        self.classification_head = ClassificationHead(
            input_dim=head_cfg.get("input_dim", D),
            num_classes=head_cfg.get("num_classes", 2),
            hidden_dims=head_cfg.get("hidden_dims", [128]),
            dropout=head_cfg.get("dropout", 0.3),
        )

        self.embedding_dim = D

    def forward(
        self,
        x: torch.Tensor,
        token_meta: list[dict] | None = None,
        x_raw: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """
        Args:
            x:       ``[B, C_eff, 2500]`` (preprocessed)
            token_meta: channel/band metadata for PP branch.
            x_raw:   ``[B, 30, 2500]`` (raw, required)

        Returns:
            logits ``[B, 2]``
        """
        if x_raw is None:
            raise ValueError("DualBranchEmotionCNNTransformer requires x_raw")

        B = x.size(0)

        # --- Encode both branches ---
        raw_feat = self.raw_encoder(x_raw, token_meta=self._raw_token_meta)   # [B, D]
        pp_feat = self.pp_encoder(x, token_meta=token_meta)                   # [B, D]

        # --- Stack + branch embedding ---
        stacked = torch.stack([raw_feat, pp_feat], dim=1)          # [B, 2, D]
        branch_ids = torch.tensor([0, 1], device=stacked.device)
        stacked = stacked + self.branch_embedding(branch_ids)      # [B, 2, D]

        # --- Prepend CLS token ---
        cls = self.cls_token.expand(B, -1, -1)                    # [B, 1, D]
        tokens = torch.cat([cls, stacked], dim=1)                  # [B, 3, D]

        # --- Fusion Transformer ---
        fused = self.fusion_transformer(tokens)                    # [B, 3, D]

        # --- CLS pool + classify ---
        out = fused[:, 0, :]                                       # [B, D]
        return self.classification_head(out)                       # [B, 2]
