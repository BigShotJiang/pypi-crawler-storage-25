"""YAML configuration loader that produces typed dataclass Config instances.

Loads YAML files (with ``include`` directive resolution and circular-detection),
auto-detects *unified* vs *legacy* format, and converts the raw dict into a
nested :class:`~eemoclas.config.dataclasses.Config` dataclass.

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

import copy
from dataclasses import dataclass, fields
from pathlib import Path
from typing import Any, Optional

import yaml

from eemoclas.config.dataclasses import (
    AugmentationConfig,
    BandConfig,
    ChannelDropoutConfig,
    ChannelsConfig,
    ClassificationHeadConfig,
    Config,
    DataConfig,
    ExperimentConfig,
    GaussianNoiseConfig,
    GaussianSamplingConfig,
    InferenceConfig,
    InferenceModelConfig,
    LoggingConfig,
    MetricConfig,
    ModelConfig,
    ModelGroupConfig,
    OptimizerConfig,
    ProjectConfig,
    ResampleConfig,
    SamplingConfig,
    SchedulerConfig,
    SeedingConfig,
    SignalConfig,
    SplittingConfig,
    SubjectTransformerConfig,
    TaskConfig,
    TimeMaskConfig,
    TokenEmbeddingConfig,
    TrainingConfig,
    TransformerConfig,
    TrialEncoderConfig,
    ZscoreConfig,
)


# ---------------------------------------------------------------------------
# YAML loading with include resolution
# ---------------------------------------------------------------------------

def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge *override* into *base* (in-place) and return *base*."""
    for key, value in override.items():
        if key in base and isinstance(base[key], dict) and isinstance(value, dict):
            _deep_merge(base[key], value)
        else:
            base[key] = value
    return base


def load_yaml(path: str | Path, *, _seen: set[str] | None = None) -> dict[str, Any]:
    """Load a YAML file and recursively resolve ``include`` directives.

    Parameters
    ----------
    path:
        Path to the YAML configuration file.
    _seen:
        Internal guard against circular includes.  Callers should leave this
        as ``None``.

    Returns
    -------
    dict[str, Any]
        Merged configuration dictionary.

    Raises
    ------
    FileNotFoundError
        If *path* does not exist.
    ValueError
        If a circular include is detected.
    """
    path = Path(path).resolve()
    if _seen is None:
        _seen = set()

    key = str(path)
    if key in _seen:
        raise ValueError(f"Circular include detected: {path}")
    _seen.add(key)

    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    with open(path, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}

    # Resolve includes (relative to current file's parent)
    includes = data.pop("include", [])
    if isinstance(includes, str):
        includes = [includes]

    merged: dict[str, Any] = {}
    for inc in includes:
        inc_path = path.parent / inc
        inc_data = load_yaml(inc_path, _seen=_seen)
        _deep_merge(merged, inc_data)

    # Current file overrides anything pulled from includes
    _deep_merge(merged, data)
    return merged


# ---------------------------------------------------------------------------
# Format detection
# ---------------------------------------------------------------------------

def detect_config_format(data: dict) -> str:
    """Return ``"unified"`` or ``"legacy"`` based on top-level keys.

    A config is considered *unified* if it has a top-level ``"models"`` key
    whose value is a dict (i.e. a multi-model routing / inference-style
    config).  Otherwise it is treated as *legacy* (single-model training
    config with top-level ``training``, ``model``, etc.).
    """
    models = data.get("models")
    if isinstance(models, dict):
        return "unified"
    return "legacy"


# ---------------------------------------------------------------------------
# Generic builder helpers
# ---------------------------------------------------------------------------

def _build(cls: type, data: dict) -> Any:
    """Create a dataclass instance from *data*, ignoring unknown keys.

    Only keys that correspond to actual fields of *cls* are forwarded to the
    constructor.  Nested dict values that match a dataclass field type are
    *not* auto-converted here -- use :func:`_build_nested` for that.
    """
    valid_keys = {f.name for f in fields(cls)}
    kwargs: dict[str, Any] = {}
    for k, v in data.items():
        if k in valid_keys:
            kwargs[k] = v
    return cls(**kwargs)


def _build_nested(data: dict, parent_cls: type, nested_specs: dict[str, type]) -> Any:
    """Build a dataclass that contains nested dataclass fields.

    Parameters
    ----------
    data:
        Raw dict to convert.
    parent_cls:
        The top-level dataclass type.
    nested_specs:
        Mapping of field name -> expected nested dataclass type.
        For each key in *nested_specs*, if the corresponding value in *data*
        is a plain dict, it is recursively built via :func:`_build`.
    """
    valid_keys = {f.name for f in fields(parent_cls)}
    kwargs: dict[str, Any] = {}
    for k, v in data.items():
        if k not in valid_keys:
            continue
        if k in nested_specs and isinstance(v, dict):
            nested_cls = nested_specs[k]
            kwargs[k] = _build(nested_cls, v)
        else:
            kwargs[k] = v
    return parent_cls(**kwargs)


# ---------------------------------------------------------------------------
# Section-specific builders
# ---------------------------------------------------------------------------

def _build_band(band_defs: dict, cb_cfg: dict) -> BandConfig:
    """Build a :class:`BandConfig` from separate top-level YAML sections."""
    return BandConfig(
        band_definitions=band_defs if band_defs else BandConfig().band_definitions,
        default_bands=cb_cfg.get("default_bands", list(band_defs.keys()) if band_defs else []),
        per_channel=cb_cfg.get("per_channel", {}),
    )


def _build_resample(data: dict) -> ResampleConfig:
    """Build a :class:`ResampleConfig` from the ``resampling`` / ``resample`` section."""
    nested_specs: dict[str, type] = {
        "sampling": SamplingConfig,
    }
    return _build_nested(data, ResampleConfig, nested_specs)


def _build_model(data: dict) -> ModelConfig:
    """Build a :class:`ModelConfig` from the ``model`` section."""
    nested_specs: dict[str, type] = {
        "trial_encoder": TrialEncoderConfig,
        "subject_transformer": SubjectTransformerConfig,
        "classification_head": ClassificationHeadConfig,
    }

    # Shallow copy to avoid mutating the caller's dict
    data = dict(data)

    # trial_encoder has further nesting
    if "trial_encoder" in data and isinstance(data["trial_encoder"], dict):
        te_data = data["trial_encoder"]
        if "token_embedding" in te_data and isinstance(te_data["token_embedding"], dict):
            te_data["token_embedding"] = _build(TokenEmbeddingConfig, te_data["token_embedding"])
        if "transformer" in te_data and isinstance(te_data["transformer"], dict):
            te_data["transformer"] = _build(TransformerConfig, te_data["transformer"])

    # subject_transformer is optional (may be None)
    if "subject_transformer" in data and isinstance(data["subject_transformer"], dict):
        data["subject_transformer"] = _build(SubjectTransformerConfig, data["subject_transformer"])

    return _build_nested(data, ModelConfig, nested_specs)


def _build_training(data: dict) -> TrainingConfig:
    """Build a :class:`TrainingConfig` from the ``training`` section.

    Handles legacy format where ``optimizer`` / ``scheduler`` can be plain
    strings (e.g. ``"adamw"``, ``"cosine"``).
    """
    d = dict(data)  # shallow copy so we don't mutate caller

    # optimizer: string -> OptimizerConfig(type=...), inherit lr/weight_decay from top level
    opt = d.get("optimizer")
    if isinstance(opt, str):
        opt_kwargs: dict[str, Any] = {"type": opt}
        if "lr" in d:
            opt_kwargs["lr"] = d.pop("lr")
        if "weight_decay" in d:
            opt_kwargs["weight_decay"] = d.pop("weight_decay")
        d["optimizer"] = OptimizerConfig(**opt_kwargs)
    elif isinstance(opt, dict):
        # Promote top-level lr/weight_decay if not in optimizer dict
        if "lr" in d and "lr" not in opt:
            opt["lr"] = d.pop("lr")
        if "weight_decay" in d and "weight_decay" not in opt:
            opt["weight_decay"] = d.pop("weight_decay")
        d["optimizer"] = _build(OptimizerConfig, opt)

    # scheduler: string -> SchedulerConfig(type=...)
    sched = d.get("scheduler")
    if isinstance(sched, str):
        d["scheduler"] = SchedulerConfig(type=sched)
    elif isinstance(sched, dict):
        d["scheduler"] = _build(SchedulerConfig, sched)

    # preload: dict -> PreloadConfig
    preload = d.get("preload")
    if isinstance(preload, dict):
        from eemoclas.config.dataclasses import PreloadConfig
        d["preload"] = _build(PreloadConfig, preload)

    return _build(TrainingConfig, d)


def _build_seeding(data: dict) -> SeedingConfig:
    """Build a :class:`SeedingConfig`.

    In legacy configs ``init_seed`` can be a dict like
    ``{subject_state: 42}``; we take the first value.
    """
    d = dict(data)
    init_seed = d.get("init_seed")
    if isinstance(init_seed, dict):
        # Take the first value from the dict
        vals = list(init_seed.values())
        d["init_seed"] = vals[0] if vals else 42
    return _build(SeedingConfig, d)


def _build_augmentation(data: dict) -> AugmentationConfig:
    """Build an :class:`AugmentationConfig`."""
    nested_specs: dict[str, type] = {
        "gaussian_noise": GaussianNoiseConfig,
        "time_mask": TimeMaskConfig,
        "channel_dropout": ChannelDropoutConfig,
    }
    return _build_nested(data, AugmentationConfig, nested_specs)


def _build_inference(data: dict, *, top_level_models: dict | None = None) -> InferenceConfig:
    """Build an :class:`InferenceConfig` from the ``inference`` section.

    Parameters
    ----------
    data:
        The ``inference`` sub-dict from the YAML.
    top_level_models:
        The top-level ``models`` dict (used when the inference section
        does not contain its own ``models`` key).
    """
    d = dict(data)
    models_raw = d.get("models")
    if models_raw is None and top_level_models is not None:
        models_raw = top_level_models
    if isinstance(models_raw, dict):
        built_models: dict[str, InferenceModelConfig] = {}
        for name, mdata in models_raw.items():
            if isinstance(mdata, dict):
                built_models[name] = _build(InferenceModelConfig, mdata)
            else:
                built_models[name] = InferenceModelConfig()
        d["models"] = built_models
    return _build(InferenceConfig, d)


# ---------------------------------------------------------------------------
# Unified-format builder
# ---------------------------------------------------------------------------

def _build_models(data: dict) -> dict[str, ModelGroupConfig]:
    """Build the ``models`` mapping for unified configs.

    In unified format, each entry under ``models`` may contain ``task``,
    ``model``, ``training``, etc. sub-sections, or may be a flat inference
    entry (with ``checkpoint`` / ``config`` keys).
    """
    models_raw = data.get("models", {})
    if not isinstance(models_raw, dict):
        return {}

    result: dict[str, ModelGroupConfig] = {}
    for name, mdata in models_raw.items():
        if not isinstance(mdata, dict):
            continue
        group = _build_model_group(mdata)
        result[name] = group
    return result


def _build_model_group(data: dict) -> ModelGroupConfig:
    """Build a single :class:`ModelGroupConfig`."""
    task = _build(TaskConfig, data.get("task", {})) if isinstance(data.get("task"), dict) else TaskConfig()
    model = _build_model(data.get("model", {})) if isinstance(data.get("model"), dict) else ModelConfig()
    training = _build_training(data.get("training", {})) if isinstance(data.get("training"), dict) else TrainingConfig()
    augmentation = _build_augmentation(data.get("augmentation", {})) if isinstance(data.get("augmentation"), dict) else AugmentationConfig()
    splitting = _build(SplittingConfig, data.get("splitting", {})) if isinstance(data.get("splitting"), dict) else SplittingConfig()
    seeding = _build_seeding(data.get("seeding", {})) if isinstance(data.get("seeding"), dict) else SeedingConfig()
    model_data = data.get("data", {})
    if not isinstance(model_data, dict):
        model_data = {}

    return ModelGroupConfig(
        task=task,
        model=model,
        training=training,
        augmentation=augmentation,
        splitting=splitting,
        seeding=seeding,
        data=model_data,
    )


def _dict_to_config(data: dict) -> Config:
    """Convert a unified-format dict to a :class:`Config` dataclass."""
    # Project
    project = _build(ProjectConfig, data.get("project", {})) if isinstance(data.get("project"), dict) else ProjectConfig()

    # Signal (has nested zscore)
    signal_data = data.get("signal", {})
    if isinstance(signal_data, dict):
        signal = _build_nested(signal_data, SignalConfig, {"zscore": ZscoreConfig})
    else:
        signal = SignalConfig()

    # Channels
    channels = _build(ChannelsConfig, data.get("channels", {})) if isinstance(data.get("channels"), dict) else ChannelsConfig()

    # Band
    band_defs = data.get("band_definitions", {})
    cb_cfg = data.get("channel_band_config", {})
    band = _build_band(band_defs if isinstance(band_defs, dict) else {}, cb_cfg if isinstance(cb_cfg, dict) else {})

    # Resample
    resample_data = data.get("resampling", data.get("resample", {}))
    resample = _build_resample(resample_data) if isinstance(resample_data, dict) else ResampleConfig()

    # Data
    raw_data = data.get("data", {})
    data_cfg = _build(DataConfig, raw_data) if isinstance(raw_data, dict) else DataConfig()

    # Models (unified format)
    models = _build_models(data)

    # Logging
    logging_cfg = _build(LoggingConfig, data.get("logging", {})) if isinstance(data.get("logging"), dict) else LoggingConfig()

    # Experiment
    experiment = _build(ExperimentConfig, data.get("experiment", {})) if isinstance(data.get("experiment"), dict) else ExperimentConfig()

    # Inference -- top-level models may carry inference model entries
    inference_data = data.get("inference", {})
    top_models = data.get("models") if isinstance(data.get("models"), dict) else None
    inference = _build_inference(inference_data, top_level_models=top_models) if isinstance(inference_data, dict) else InferenceConfig()

    # Metrics
    metrics = _build(MetricConfig, data.get("metrics", {})) if isinstance(data.get("metrics"), dict) else MetricConfig()

    return Config(
        project=project,
        signal=signal,
        channels=channels,
        band=band,
        resample=resample,
        data=data_cfg,
        models=models,
        logging=logging_cfg,
        experiment=experiment,
        inference=inference,
        metrics=metrics,
    )


# ---------------------------------------------------------------------------
# Legacy-format builder
# ---------------------------------------------------------------------------

def _legacy_to_config(data: dict) -> Config:
    """Wrap a legacy single-model dict into a unified :class:`Config`.

    Legacy configs have top-level ``task``, ``model``, ``training``,
    ``augmentation``, ``splitting``, ``seeding`` sections but no ``models``
    dict.  This builder wraps them into a single model-group entry keyed
    by the task name (or ``"default"``).
    """
    # Determine the model group name from the task section
    task_data = data.get("task", {})
    group_name = task_data.get("name", "default") if isinstance(task_data, dict) else "default"

    # Build the shared sections (project, signal, channels, band, etc.)
    # using the same logic as _dict_to_config
    project = _build(ProjectConfig, data.get("project", {})) if isinstance(data.get("project"), dict) else ProjectConfig()

    signal_data = data.get("signal", {})
    if isinstance(signal_data, dict):
        signal = _build_nested(signal_data, SignalConfig, {"zscore": ZscoreConfig})
    else:
        signal = SignalConfig()

    channels = _build(ChannelsConfig, data.get("channels", {})) if isinstance(data.get("channels"), dict) else ChannelsConfig()

    band_defs = data.get("band_definitions", {})
    cb_cfg = data.get("channel_band_config", {})
    band = _build_band(band_defs if isinstance(band_defs, dict) else {}, cb_cfg if isinstance(cb_cfg, dict) else {})

    resample_data = data.get("resampling", data.get("resample", {}))
    resample = _build_resample(resample_data) if isinstance(resample_data, dict) else ResampleConfig()

    raw_data = data.get("data", {})
    data_cfg = _build(DataConfig, raw_data) if isinstance(raw_data, dict) else DataConfig()

    logging_cfg = _build(LoggingConfig, data.get("logging", {})) if isinstance(data.get("logging"), dict) else LoggingConfig()

    experiment = _build(ExperimentConfig, data.get("experiment", {})) if isinstance(data.get("experiment"), dict) else ExperimentConfig()

    inference_data = data.get("inference", {})
    inference = _build_inference(inference_data) if isinstance(inference_data, dict) else InferenceConfig()

    metrics = _build(MetricConfig, data.get("metrics", {})) if isinstance(data.get("metrics"), dict) else MetricConfig()

    # Build the single model group
    model_group = _build_model_group(data)
    models = {group_name: model_group}

    return Config(
        project=project,
        signal=signal,
        channels=channels,
        band=band,
        resample=resample,
        data=data_cfg,
        models=models,
        logging=logging_cfg,
        experiment=experiment,
        inference=inference,
        metrics=metrics,
    )


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def load_config(path: str | Path) -> Config:
    """Load a YAML config file and return a typed :class:`Config` dataclass.

    Auto-detects whether the file is in *unified* format (has a top-level
    ``models`` dict) or *legacy* format (has top-level ``training`` /
    ``model`` sections).  Legacy configs are wrapped into a single-model
    unified Config.

    Parameters
    ----------
    path:
        Path to the YAML configuration file.

    Returns
    -------
    Config
        Fully-typed configuration dataclass.

    Raises
    ------
    FileNotFoundError
        If *path* does not exist.
    ValueError
        If a circular include is detected.
    """
    raw = load_yaml(path)
    fmt = detect_config_format(raw)
    if fmt == "unified":
        cfg = _dict_to_config(raw)
    else:
        cfg = _legacy_to_config(raw)
    # Store source path for later file-copy snapshot (preserves comments & ordering).
    cfg._source_yaml_path = str(Path(path).resolve())
    return cfg
