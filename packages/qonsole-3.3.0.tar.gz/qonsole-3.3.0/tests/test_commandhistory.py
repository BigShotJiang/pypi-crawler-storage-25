"""Test command history functionality."""

from unittest.mock import Mock

import pytest
from qtpy.QtCore import QObject

from qonsole.commandhistory import CommandHistory


class TestCommandHistory:
    """Test command history."""

    @pytest.fixture
    def console(self):
        """Create a mock console."""

        class MockConsole(QObject):
            def __init__(self):
                super().__init__()
                self.edit = Mock()
                self.edit.toPlainText = Mock(return_value="")
                self.edit.setPlainText = Mock()

            def clear_input_buffer(self):
                pass

            def insert_input_text(self, text):
                pass

        return MockConsole()

    @pytest.fixture
    def history(self, console):
        """Create a CommandHistory instance."""
        return CommandHistory(console)

    def test_add_command(self, history):
        """Test adding commands."""
        history.add("print('hello')")
        history.add("x = 42")
        assert len(history._cmd_history) == 2

    def test_add_empty_not_stored(self, history):
        """Test that empty commands are not stored."""
        history.add("")
        assert len(history._cmd_history) == 0

    def test_navigation(self, history, console):
        """Test navigation through history."""
        history.add("cmd1")
        history.add("cmd2")
        history.add("cmd3")

        # dec() moves backward and requires current input
        history.dec("")
        assert history._idx == 2  # Should be at cmd3

        history.dec("")
        assert history._idx == 1  # Should be at cmd2

    def test_inc_forward_navigation(self, history, console):
        """Test inc() moves forward in history."""
        history.add("cmd1")
        history.add("cmd2")
        history.add("cmd3")

        # Navigate backward first
        history.dec("")
        history.dec("")
        assert history._idx == 1

        # Now navigate forward with inc()
        history.inc()
        assert history._idx == 2

        # Should not go beyond the end
        history.inc()
        assert history._idx == 3  # len(history)

    def test_current_returns_pending_at_end(self, history):
        """Test current() returns pending input when at end of history."""
        history.add("cmd1")
        history.add("cmd2")

        # Navigate to end (idx == len)
        assert history._idx == 2  # At end
        history.dec("my pending input")
        assert history._idx == 1

        # Navigate back to end
        history.inc()
        assert history._idx == 2

        # Should return pending input
        result = history.current()
        assert result == "my pending input"

    def test_current_returns_history_item(self, history):
        """Test current() returns history item when not at end."""
        history.add("cmd1")
        history.add("cmd2")

        # Navigate backward
        history.dec("")
        assert history._idx == 1

        # Should return cmd2
        result = history.current()
        assert result == "cmd2"

    def test_clear(self, history):
        """Test clear() resets history to empty state."""
        # Add some commands
        history.add("cmd1")
        history.add("cmd2")
        history.add("cmd3")

        # Navigate and set pending input
        history.dec("pending")
        history._pending_input = "pending"

        # Clear the history
        history.clear()

        # Verify everything is reset
        assert len(history._cmd_history) == 0
        assert history._idx == 0
        assert history._pending_input == ""
