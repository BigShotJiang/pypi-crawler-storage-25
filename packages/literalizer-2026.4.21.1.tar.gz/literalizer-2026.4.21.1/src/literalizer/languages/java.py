"""Java language specification."""

import dataclasses
import datetime
import enum
import functools
from collections import OrderedDict
from collections.abc import Callable, Sequence
from functools import cached_property
from types import MappingProxyType
from typing import Any, ClassVar, assert_never

from beartype import beartype
from ruamel.yaml.compat import ordereddict

from literalizer._formatters.collection_openers import (
    TypedOpenerConfig,
    fixed_dict_open,
    fixed_sequence_open,
    fixed_set_open,
    typed_collection_open,
)
from literalizer._formatters.format_dates import (
    date_ymd_formatter,
    datetime_iso_formatter,
    format_date_iso,
    format_datetime_iso,
)
from literalizer._formatters.format_entries import (
    dict_entry_with_template,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    passthrough_set_entry,
    variable_declaration_formatter,
    variable_formatter,
)
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    data_has_out_of_range_int,
    format_integer_binary,
    format_integer_hex,
    format_integer_octal_c_style,
    format_integer_underscore,
    make_long_suffix_formatter,
    make_overflow_fallback_formatter,
    make_overflow_suffix_formatter,
)
from literalizer._formatters.format_strings import format_string_backslash
from literalizer._language import (
    CallStyle,
    CommentConfig,
    DateFormatConfig,
    DatetimeFormatConfig,
    DeclarationStyleConfig,
    DictFormatConfig,
    FloatSpecialsMixin,
    LanguageCls,
    ModifierCombination,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    body_preamble_from_scalars,
    date_scalar_preamble,
    no_call_stub,
    no_type_hint_preamble,
    no_validate_spec_for_data,
    prepend_body_preamble,
)
from literalizer._types import Value
from literalizer.exceptions import NullInCollectionError


class _JavaModifiers(enum.Enum):
    """Declaration modifiers supported by Java.

    Each member's value is the Java keyword it renders to.  Declaration
    order matches canonical Java modifier order
    (visibility, storage, finality).

    Exposed as :attr:`Java.Modifiers` / :attr:`Java.modifiers`.
    """

    PUBLIC = "public"
    """Visibility: publicly accessible."""

    PRIVATE = "private"
    """Visibility: private to the enclosing class."""

    PROTECTED = "protected"
    """Visibility: protected (accessible from subclasses)."""

    STATIC = "static"
    """Storage: associated with the enclosing class rather than an
    instance.
    """

    FINAL = "final"
    """Immutability: cannot be reassigned."""


def _java_call_stub(
    name: str,
    _params: Sequence[str],
    _stub_return: StubReturn,
    /,
) -> tuple[str, ...]:
    """Return Java stub declarations for a call name."""
    parts = name.split(sep=".")
    if len(parts) == 1:
        return (
            f"static Object {parts[0]}(Object... args) {{ return null; }}",
        )
    root = parts[0]
    method = parts[-1]
    fields = parts[1:-1]
    if not fields:
        type_name = f"{root.title()}Type_"
        return (
            f"static class {type_name} {{"
            f" Object {method}(Object... args) {{ return null; }} }}",
            f"static {type_name} {root} = new {type_name}();",
        )
    lines: list[str] = []
    inner_type = f"{fields[-1].title()}Type_"
    lines.append(
        f"static class {inner_type} {{"
        f" Object {method}(Object... args) {{ return null; }} }}"
    )
    prev_type = inner_type
    for i in range(len(fields) - 2, -1, -1):
        curr_type = f"{fields[i].title()}Type_"
        lines.append(
            f"static class {curr_type} {{"
            f" {prev_type} {fields[i + 1]} = new {prev_type}(); }}"
        )
        prev_type = curr_type
    root_type = f"{root.title()}Type_"
    lines.append(
        f"static class {root_type} {{"
        f" {prev_type} {fields[0]} = new {prev_type}(); }}"
    )
    lines.append(f"static {root_type} {root} = new {root_type}();")
    return tuple(lines)


@beartype
def _format_java_biginteger_literal(value: int) -> str:
    """Format a value outside signed 64-bit range as a Java
    ``new BigInteger(...)`` expression.

    Java's ``long`` is signed 64-bit; values outside that range must
    use ``java.math.BigInteger``.
    """
    return f'new BigInteger("{value}")'


@beartype
def _java_biginteger_preamble(data: Value, /) -> tuple[str, ...]:
    """Return ``import java.math.BigInteger;`` if *data* contains a
    very-large integer.
    """
    if data_has_out_of_range_int(data=data):
        return ("import java.math.BigInteger;",)
    return ()


@beartype
def _format_datetime_java_zoned(value: datetime.datetime) -> str:
    """Format a datetime as a Java ``ZonedDateTime.of(...)`` call."""
    timezone_name = value.tzname() or "UTC"
    nanoseconds = value.microsecond * 1000
    return (
        f"ZonedDateTime.of({value.year}, {value.month}, {value.day}, "
        f"{value.hour}, {value.minute}, {value.second}, "
        f'{nanoseconds}, ZoneId.of("{timezone_name}"))'
    )


@beartype
def _list_of_open(items: list[Any]) -> str:
    """Return ``List.of(`` after checking for null elements.

    Java's ``List.of()`` throws ``NullPointerException`` on null elements.
    """
    if any(item is None for item in items):
        msg = (
            f"Java's List.of() does not accept null elements"
            f" (got {len(items)} items, including null). "
            "Use sequence_format=ARRAY instead."
        )
        raise NullInCollectionError(msg)
    return "List.of("


@beartype
def _java_box(type_name: str) -> str:
    """Return the boxed wrapper type for a Java primitive, or the type
    itself for reference types.
    """
    match type_name:
        case "boolean":
            return "Boolean"
        case "int":
            return "Integer"
        case "long":
            return "Long"
        case "double":
            return "Double"
        case _:
            return type_name


@beartype
def _java_common_element_type(
    elements: list[Value],
    *,
    boxed: bool,
    int_type: str,
    date_hint: str,
    datetime_hint: str,
    seq_is_array: bool,
    dict_outer: str,
    set_outer: str,
) -> str:
    """Find the common Java type for a collection's elements.

    Returns ``"Object"`` when elements are empty or have mixed types.
    """
    if not elements:
        return "Object"
    recurse = functools.partial(
        _java_type_hint,
        int_type=int_type,
        date_hint=date_hint,
        datetime_hint=datetime_hint,
        seq_is_array=seq_is_array,
        dict_outer=dict_outer,
        set_outer=set_outer,
    )
    types: list[str] = [recurse(data=e) for e in elements]
    unique = set(types)
    if len(unique) == 1:
        result = unique.pop()
        return _java_box(type_name=result) if boxed else result
    # int + double → double (widening)
    double_t = "double"
    if unique == {int_type, double_t}:
        return "Double" if boxed else "double"
    return "Object"


@beartype
def _java_type_hint(  # pylint: disable=too-complex,too-many-branches  # noqa: C901, PLR0911, PLR0912
    data: Value,
    *,
    int_type: str,
    date_hint: str,
    datetime_hint: str,
    seq_is_array: bool,
    dict_outer: str,
    set_outer: str,
) -> str:
    """Derive a Java type from *data*."""
    match data:
        case bool():
            return "boolean"
        case int():
            return int_type
        case float():
            return "double"
        case str():
            return "String"
        case bytes():
            return "String"
        case datetime.datetime():
            return datetime_hint
        case datetime.date():
            return date_hint
        case None:
            return "Object"
        case dict():
            val_type = _java_common_element_type(
                elements=list(data.values()),
                boxed=True,
                int_type=int_type,
                date_hint=date_hint,
                datetime_hint=datetime_hint,
                seq_is_array=seq_is_array,
                dict_outer=dict_outer,
                set_outer=set_outer,
            )
            outer = (
                dict_outer
                if not isinstance(data, (ordereddict, OrderedDict))
                else "Map"
            )
            return f"{outer}<String, {val_type}>"
        case set():
            elem_type = _java_common_element_type(
                elements=list(data),
                boxed=True,
                int_type=int_type,
                date_hint=date_hint,
                datetime_hint=datetime_hint,
                seq_is_array=seq_is_array,
                dict_outer=dict_outer,
                set_outer=set_outer,
            )
            return f"{set_outer}<{elem_type}>"
        case list():
            if seq_is_array:
                elem_type = _java_common_element_type(
                    elements=data,
                    boxed=False,
                    int_type=int_type,
                    date_hint=date_hint,
                    datetime_hint=datetime_hint,
                    seq_is_array=seq_is_array,
                    dict_outer=dict_outer,
                    set_outer=set_outer,
                )
                # Java cannot create arrays of generic types, so fall
                # back to Object[] when the element type is generic.
                if "<" in elem_type:
                    elem_type = "Object"
                return f"{elem_type}[]"
            elem_type = _java_common_element_type(
                elements=data,
                boxed=True,
                int_type=int_type,
                date_hint=date_hint,
                datetime_hint=datetime_hint,
                seq_is_array=seq_is_array,
                dict_outer=dict_outer,
                set_outer=set_outer,
            )
            return f"List<{elem_type}>"
        case _ as unreachable:
            assert_never(unreachable)


@beartype
def _java_modifier_prefix(modifiers: frozenset[enum.Enum]) -> str:
    """Return the ``public static final `` prefix for a Java
    declaration, including a trailing space when non-empty.

    Values that are not :class:`_JavaModifiers` members are ignored.
    """
    keywords = [m.value for m in _JavaModifiers if m in modifiers]
    if not keywords:
        return ""
    return " ".join(keywords) + " "


@beartype
def _format_java_typed_declaration(
    name: str,
    value: str,
    data: Value,
    modifiers: frozenset[enum.Enum],
    *,
    int_type: str,
    date_hint: str,
    datetime_hint: str,
    seq_is_array: bool,
    dict_outer: str,
    set_outer: str,
) -> str:
    """Format a Java variable declaration with an explicit type."""
    hint = _java_type_hint(
        data=data,
        int_type=int_type,
        date_hint=date_hint,
        datetime_hint=datetime_hint,
        seq_is_array=seq_is_array,
        dict_outer=dict_outer,
        set_outer=set_outer,
    )
    prefix = _java_modifier_prefix(modifiers=modifiers)
    return f"{prefix}{hint} {name} = {value};"


@beartype
def _apply_java_object_nil_declaration(
    name: str,
    value: str,
    data: Value,
    modifiers: frozenset[enum.Enum],
    *,
    base_formatter: Callable[[str, str, Value, frozenset[enum.Enum]], str],
    typed_formatter: Callable[[str, str, Value, frozenset[enum.Enum]], str],
) -> str:
    """Format a Java variable declaration, guarding top-level ``null``
    and switching to the typed form whenever modifiers are present.
    """
    if modifiers:
        return typed_formatter(name, value, data, modifiers)
    if data is None:
        return f"Object {name} = {value};"
    return base_formatter(name, value, data, modifiers)


@beartype
def _object_nil_declaration(
    base_formatter: Callable[[str, str, Value, frozenset[enum.Enum]], str],
    *,
    typed_formatter: Callable[[str, str, Value, frozenset[enum.Enum]], str],
) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
    """Wrap *base_formatter* so top-level ``null`` gets a typed form.

    Java cannot infer a type from ``null``, so ``var {name} = null;``
    fails to compile.  Emit ``Object {name} = null;`` when the value is
    ``None``.  Modifiers force the typed form because Java class-field
    syntax (e.g. ``public static final``) cannot be combined with
    ``var``.
    """

    def _format(
        name: str,
        value: str,
        data: Value,
        modifiers: frozenset[enum.Enum],
    ) -> str:
        """Delegate to module-level implementation."""
        return _apply_java_object_nil_declaration(
            name=name,
            value=value,
            data=data,
            modifiers=modifiers,
            base_formatter=base_formatter,
            typed_formatter=typed_formatter,
        )

    return _format


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Java(metaclass=LanguageCls):
    """Java language specification.

    Args:
        date_format: How to format :class:`datetime.date` values.

            * ``date_formats.JAVA`` — ``LocalDate.of(...)`` call,
              e.g. ``LocalDate.of(2024, 1, 15)``.
            * ``date_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15"``.

        datetime_format: How to format :class:`datetime.datetime` values.

            * ``datetime_formats.INSTANT`` — ``Instant.parse(...)`` call,
              e.g. ``Instant.parse("2024-01-15T12:30:00")``.
            * ``datetime_formats.ZONED`` — ``ZonedDateTime.of(...)`` call,
              e.g. ``ZonedDateTime.of(2024, 1, 15, 12, 30, 0, 0,
              ZoneId.of("UTC"))``.
            * ``datetime_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15T12:30:00"``.

        sequence_format: How to format sequences.

            * ``sequence_formats.ARRAY`` — Java array literal,
              e.g. ``new Object[]{1, 2, 3}``.
            * ``sequence_formats.LIST`` — ``List.of(...)`` call,
              e.g. ``List.of(1, 2, 3)``.
    """

    extension = ".java"
    pygments_name = "java"
    supports_default_set_element_type = False
    supports_default_sequence_element_type = False
    supports_default_dict_value_type = False
    supports_default_dict_key_type = False
    supports_default_ordered_map_value_type = False
    supports_non_printable_ascii_dict_keys = True
    supports_variable_names = True
    supports_dotted_calls = True

    _opener_config = TypedOpenerConfig(
        str_type="String",
        bool_type="boolean",
        int_type="int",
        float_type="double",
        mixed_numeric_type="double",
        bytes_type="String",
        date_type="LocalDate",
        datetime_type=None,
        list_template="{inner}[]",
        sequence_opener_template="new {type_name}[]{{",
        dict_opener_template="new {type_name}[]{{",
        set_opener_template="Set.of(",
        dict_type_template=None,
        fallback_value_type=None,
    )

    _opener_config_long = TypedOpenerConfig(
        str_type="String",
        bool_type="boolean",
        int_type="long",
        float_type="double",
        mixed_numeric_type="double",
        bytes_type="String",
        date_type="LocalDate",
        datetime_type=None,
        list_template="{inner}[]",
        sequence_opener_template="new {type_name}[]{{",
        dict_opener_template="new {type_name}[]{{",
        set_opener_template="Set.of(",
        dict_type_template=None,
        fallback_value_type=None,
    )

    class DateFormats(enum.Enum):
        """Date formatting options for Java."""

        JAVA = DateFormatConfig(
            formatter=date_ymd_formatter(
                template="LocalDate.of({year}, {month}, {day})",
            ),
            preamble_lines=("import java.time.LocalDate;",),
        )
        ISO = DateFormatConfig(formatter=format_date_iso, type_produced=str)

        def __call__(self, date_value: datetime.date, /) -> str:
            """Format a date."""
            return self.value.formatter(date_value)

    class DatetimeFormats(enum.Enum):
        """Datetime formatting options for Java."""

        INSTANT = DatetimeFormatConfig(
            formatter=datetime_iso_formatter(
                template='Instant.parse("{iso}")',
            ),
            preamble_lines=("import java.time.Instant;",),
        )
        ZONED = DatetimeFormatConfig(
            formatter=_format_datetime_java_zoned,
            preamble_lines=(
                "import java.time.ZoneId;",
                "import java.time.ZonedDateTime;",
            ),
        )
        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            type_produced=str,
        )

        def __call__(self, dt_value: datetime.datetime, /) -> str:
            """Format a datetime."""
            return self.value.formatter(dt_value)

    class BytesFormats(enum.Enum):
        """Bytes formatting options."""

        HEX = enum.member(value=format_bytes_hex)
        BASE64 = enum.member(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self.value(value=data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for Java."""

        ARRAY = SequenceFormatConfig(
            sequence_open=fixed_sequence_open(open_str="new Object[]{"),
            close="}",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            supports_trailing_comma=True,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback="new Object[]{",
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
        )
        LIST = SequenceFormatConfig(
            sequence_open=_list_of_open,
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            close=")",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            supports_trailing_comma=False,
            empty_sequence="List.of()",
            preamble_lines=("import java.util.List;",),
            declared_type=None,
        )

    class SetFormats(enum.Enum):
        """Set type options for Java."""

        SET = SetFormatConfig(
            set_open=fixed_set_open(open_str="Set.of("),
            close=")",
            empty_set=None,
            preamble_lines=("import java.util.Set;",),
            set_opener_template="",
            supports_heterogeneity=True,
        )
        TREE_SET = SetFormatConfig(
            set_open=fixed_set_open(open_str="new TreeSet<>(Set.of("),
            close="))",
            empty_set="new TreeSet<>()",
            preamble_lines=(
                "import java.util.Set;",
                "import java.util.TreeSet;",
            ),
            set_opener_template="",
            supports_heterogeneity=True,
        )

    class CommentFormats(enum.Enum):
        """Comment style options."""

        DOUBLE_SLASH = CommentConfig(
            prefix="//",
            suffix="",
        )
        BLOCK = CommentConfig(
            prefix="/*",
            suffix=" */",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        VAR = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="var {name} = {value};",
            ),
            supports_redefinition=True,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        MAP_OF_ENTRIES = DictFormatConfig(
            dict_open=fixed_dict_open(open_str="Map.ofEntries("),
            close=")",
            format_entry=dict_entry_with_template(
                template="Map.entry({key}, {value})",
                format_value=passthrough_sequence_entry,
            ),
            empty_dict=None,
            preamble_lines=("import java.util.Map;",),
            narrowed_open=None,
        )
        HASH_MAP = DictFormatConfig(
            dict_open=fixed_dict_open(open_str="new HashMap<>(Map.ofEntries("),
            close="))",
            format_entry=dict_entry_with_template(
                template="Map.entry({key}, {value})",
                format_value=passthrough_sequence_entry,
            ),
            empty_dict="new HashMap<>()",
            preamble_lines=(
                "import java.util.HashMap;",
                "import java.util.Map;",
            ),
            narrowed_open=None,
        )

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="Double.POSITIVE_INFINITY",
        negative_infinity="Double.NEGATIVE_INFINITY",
        nan="Double.NaN",
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=format_float_fixed)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = MappingProxyType(
            mapping={
                "NONE": str,
                "UNDERSCORE": format_integer_underscore,
            }
        )
        HEX = MappingProxyType(
            mapping={
                "NONE": format_integer_hex,
                "UNDERSCORE": format_integer_hex,
            }
        )
        OCTAL = MappingProxyType(
            mapping={
                "NONE": format_integer_octal_c_style,
                "UNDERSCORE": format_integer_octal_c_style,
            }
        )
        BINARY = MappingProxyType(
            mapping={
                "NONE": format_integer_binary,
                "UNDERSCORE": format_integer_binary,
            }
        )

        def get_formatter(
            self,
            numeric_separator: enum.Enum,
        ) -> Callable[[int], str]:
            """Return the integer formatter for the given separator."""
            formatter: Callable[[int], str] = self.value[
                numeric_separator.name
            ]
            return formatter

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()
        AUTO = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()
        UNDERSCORE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(enum.Enum):
        """String format options."""

        DOUBLE = "double"

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        YES = TrailingCommaConfig(multiline_trailing_comma=True)
        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    Modifiers = _JavaModifiers

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats
    modifiers = _JavaModifiers
    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = (
        ModifierCombination(
            name="public_static_final",
            modifiers=frozenset(
                {
                    _JavaModifiers.PUBLIC,
                    _JavaModifiers.STATIC,
                    _JavaModifiers.FINAL,
                },
            ),
        ),
    )
    validate_spec_for_data = no_validate_spec_for_data

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        AUTO = enum.auto()
        ALWAYS = enum.auto()

        def formatter(
            self,
            *,
            auto_formatter: Callable[
                [str, str, Value, frozenset[enum.Enum]], str
            ],
            int_type: str,
            date_hint: str,
            datetime_hint: str,
            seq_is_array: bool,
            dict_outer: str,
            set_outer: str,
        ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
            """Return the variable declaration formatter."""
            typed = functools.partial(
                _format_java_typed_declaration,
                int_type=int_type,
                date_hint=date_hint,
                datetime_hint=datetime_hint,
                seq_is_array=seq_is_array,
                dict_outer=dict_outer,
                set_outer=set_outer,
            )
            if self is type(self).AUTO:
                return _object_nil_declaration(
                    base_formatter=auto_formatter,
                    typed_formatter=typed,
                )
            return typed

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class LineEndings(enum.Enum):
        """Line ending options."""

        SEMICOLON = "semicolon"

    line_endings = LineEndings

    class CallStyles(enum.Enum):
        """Java call style options."""

        POSITIONAL = PositionalCallStyle()

    call_styles = CallStyles

    @staticmethod
    def wrap_in_file(
        content: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap a Java declaration in a ``class Check`` scope.

        When *content* starts with a class-field modifier keyword
        (``public``, ``private``, ``protected``, ``static``) the
        declaration is placed at class-field scope, which is the only
        context where those modifiers are valid.  Otherwise the
        declaration goes inside ``public static void check()`` so that
        local-only forms like ``var x = 42;`` compile.
        """
        del variable_name
        first_token = (
            content.lstrip().split(sep=" ", maxsplit=1)[0]
            if content.strip()
            else ""
        )
        is_class_field = first_token in {
            "public",
            "private",
            "protected",
            "static",
        }
        # Lines starting with "static " are class-level declarations
        # (call stubs); everything else goes inside the method body.
        class_lines = [
            line for line in body_preamble if line.startswith("static ")
        ]
        method_lines = tuple(
            line for line in body_preamble if not line.startswith("static ")
        )
        class_block = "\n".join(class_lines) + "\n" if class_lines else ""
        if is_class_field:
            field_preamble = (
                "\n".join(method_lines) + "\n" if method_lines else ""
            )
            return (
                f"class Check {{\n{class_block}{field_preamble}{content}\n}}"
            )
        content = prepend_body_preamble(
            content=content,
            body_preamble=method_lines,
        )
        return (
            "class Check {\n"
            f"{class_block}"
            "    public static void check() {\n"
            f"{content}\n"
            "    }\n"
            "}"
        )

    @staticmethod
    def wrap_combined_in_file(
        declaration: str,
        assignment: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap Java declaration + assignment in a static method."""
        return Java.wrap_in_file(
            content=declaration + "\n" + assignment,
            variable_name=variable_name,
            body_preamble=body_preamble,
        )

    date_format: DateFormats = DateFormats.JAVA
    datetime_format: DatetimeFormats = DatetimeFormats.INSTANT
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.ARRAY
    set_format: SetFormats = SetFormats.SET
    variable_type_hints: VariableTypeHints = VariableTypeHints.AUTO
    comment_format: CommentFormats = CommentFormats.DOUBLE_SLASH
    declaration_style: DeclarationStyles = DeclarationStyles.VAR
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.MAP_OF_ENTRIES
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.NO
    line_ending: LineEndings = LineEndings.SEMICOLON
    call_style: CallStyles = CallStyles.POSITIONAL
    indent: str = "    "

    null_literal: ClassVar[str] = "null"
    true_literal: ClassVar[str] = "true"
    false_literal: ClassVar[str] = "false"
    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = True
    supports_collection_comments: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = False
    supports_scalar_inline_comments: ClassVar[bool] = False
    statement_terminator: ClassVar[str] = ";"
    static_preamble: ClassVar[Sequence[str]] = ()
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()

    @cached_property
    def format_string(self) -> Callable[[str], str]:
        """Format a string value as a quoted literal."""
        return format_string_backslash

    @cached_property
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return passthrough_sequence_entry

    @cached_property
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return passthrough_set_entry

    @cached_property
    def format_variable_assignment(self) -> Callable[[str, str, Value], str]:
        """Format an assignment to an existing variable."""
        return variable_formatter(template="{name} = {value};")

    @cached_property
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines."""
        return _java_biginteger_preamble

    @cached_property
    def type_hint_collection_preamble_lines(
        self,
    ) -> Callable[[frozenset[type]], tuple[str, ...]]:
        """Return preamble lines for empty-collection type hints."""
        return no_type_hint_preamble

    @cached_property
    def format_call_stub(
        self,
    ) -> Callable[[str, Sequence[str], StubReturn], tuple[str, ...]]:
        """Return stub declarations for a call expression."""
        return _java_call_stub

    @cached_property
    def format_call_preamble_stub(
        self,
    ) -> Callable[[str, Sequence[str], StubReturn], tuple[str, ...]]:
        """Return file-scope stubs for a call expression."""
        return no_call_stub

    @cached_property
    def _suffix_is_auto(self) -> bool:
        """Whether the numeric-literal suffix is AUTO (long suffix)."""
        return self.numeric_literal_suffix.name == "AUTO"

    @cached_property
    def _java_dict_entry(self) -> Callable[[str, Value, str], str]:
        """Shared dict-entry formatter used by dict and ordered-map."""
        return dict_entry_with_template(
            template="Map.entry({key}, {value})",
            format_value=passthrough_sequence_entry,
        )

    @cached_property
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        return self.sequence_format.value

    @cached_property
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        return self.set_format.value

    @cached_property
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        fmt = self.sequence_format.value
        if fmt.typed_opener_fallback is None:
            return fmt.sequence_open
        cfg = (
            self._opener_config_long
            if self._suffix_is_auto
            else self._opener_config
        )
        openers = cfg.build(
            date_type=cfg.type_name(
                py_type=self.date_format.value.type_produced
            ),
            datetime_type=cfg.type_name(
                py_type=self.datetime_format.value.type_produced,
            ),
            set_opener_template=None,
            narrow_dict_values=False,
        )
        return typed_collection_open(
            type_to_opener=openers.seq,
            fallback=fmt.typed_opener_fallback,
        )

    @cached_property
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        return self.dict_format.value

    @cached_property
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    def format_date(self) -> Callable[[datetime.date], str]:
        """Callable that formats a date as a string literal."""
        return self.date_format

    @cached_property
    def format_datetime(self) -> Callable[[datetime.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        return self.datetime_format

    @cached_property
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal."""
        base_int_formatter = self.integer_format.get_formatter(
            numeric_separator=self.numeric_separator,
        )
        suffixed: Callable[[int], str] = (
            make_long_suffix_formatter(base=base_int_formatter)
            if self._suffix_is_auto
            else make_overflow_suffix_formatter(
                base=base_int_formatter,
                min_value=-(2**31),
                max_value=2**31 - 1,
                suffix="L",
            )
        )
        return make_overflow_fallback_formatter(
            base=suffixed,
            fallback=_format_java_biginteger_literal,
        )

    @cached_property
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_dict_open(
                open_str=(
                    "new java.util.ArrayList<>(java.util.Arrays.asList("
                ),
            ),
            close="))",
            preamble_lines=("import java.util.Map;",),
        )

    @cached_property
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return self._java_dict_entry

    @cached_property
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        if self.datetime_format.value.type_produced is str:
            datetime_hint = "String"
        elif self.datetime_format.name == "ZONED":
            datetime_hint = "ZonedDateTime"
        else:
            datetime_hint = "Instant"
        return self.variable_type_hints.formatter(
            auto_formatter=self.declaration_style.value.formatter,
            int_type="long" if self._suffix_is_auto else "int",
            date_hint=(
                "String"
                if self.date_format.value.type_produced is str
                else "LocalDate"
            ),
            datetime_hint=datetime_hint,
            seq_is_array=(self.sequence_format.name == "ARRAY"),
            dict_outer=(
                "HashMap" if self.dict_format.name == "HASH_MAP" else "Map"
            ),
            set_outer=(
                "TreeSet" if self.set_format.name == "TREE_SET" else "Set"
            ),
        )

    @cached_property
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble computed from date/datetime format."""
        return date_scalar_preamble(
            date_format=self.date_format,
            datetime_format=self.datetime_format,
        )

    @cached_property
    def scalar_body_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar body preamble (Java needs none)."""
        return {}

    @cached_property
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )

    @cached_property
    def call_style_config(self) -> CallStyle | None:
        """Configuration for the chosen call style."""
        return self.call_style.value
