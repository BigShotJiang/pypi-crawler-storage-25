"""Haskell language specification."""

import dataclasses
import datetime
import enum
import functools
import textwrap
from collections.abc import Callable, Sequence
from functools import cached_property
from typing import ClassVar

from beartype import beartype
from ruamel.yaml.compat import ordereddict

from literalizer._formatters.collection_openers import (
    fixed_dict_open,
    fixed_sequence_open,
    fixed_set_open,
)
from literalizer._formatters.format_dates import (
    date_ymd_formatter,
    format_date_iso,
    format_datetime_iso,
)
from literalizer._formatters.format_entries import (
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    passthrough_set_entry,
    tuple_dict_entry,
    variable_declaration_formatter,
    variable_formatter,
)
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    format_integer_binary,
    format_integer_hex,
    format_integer_octal,
)
from literalizer._formatters.format_strings import (
    format_string_backslash_control,
)
from literalizer._language import (
    CallStyle,
    CommentConfig,
    DateFormatConfig,
    DatetimeFormatConfig,
    DeclarationStyleConfig,
    DictFormatConfig,
    FloatSpecialsMixin,
    LanguageCls,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    date_scalar_preamble,
    no_data_preamble,
    no_type_hint_preamble,
    no_validate_spec_for_data,
)
from literalizer._types import Value


@beartype
def _haskell_call_preamble_stub(
    name: str,
    _params: Sequence[str],
    _stub_return: StubReturn,
    /,
) -> tuple[str, ...]:
    """Emit ``OverloadedRecordDot`` when the call target contains dots."""
    if "." in name:
        return ("{-# LANGUAGE OverloadedRecordDot #-}",)
    return ()


@beartype
def _build_haskell_call_stub_lines(
    name: str,
    params: Sequence[str],
    _stub_return: StubReturn,
    type_name: str,
) -> tuple[str, ...]:
    """Return Haskell stub declarations for a call name."""
    ret = "IO ()"
    body = "return ()"
    parts = name.split(sep=".")
    if len(parts) == 1:
        return (f"{parts[0]} _ = {body}",)
    root = parts[0]
    method = parts[-1]
    fields = parts[1:-1]
    if len(params) == 1:
        arg_type = type_name
    else:
        arg_type = "(" + ", ".join(type_name for _ in params) + ")"
    field_type = f"{arg_type} -> {ret}"
    if not fields:
        cls = root.capitalize() + "Type_"
        return (
            f"data {cls} = {cls} {{ {method} :: {field_type} }}",
            f"{root} = {cls} {{ {method} = \\_ -> {body} }}",
        )
    lines: list[str] = []
    inner_cls = fields[-1].capitalize() + "Type_"
    lines.append(
        f"data {inner_cls} = {inner_cls} {{ {method} :: {field_type} }}",
    )
    prev_cls = inner_cls
    for i in range(len(fields) - 2, -1, -1):
        cls = fields[i].capitalize() + "Type_"
        lines.append(
            f"data {cls} = {cls} {{ {fields[i + 1]} :: {prev_cls} }}",
        )
        prev_cls = cls
    root_cls = root.capitalize() + "Type_"
    lines.append(
        f"data {root_cls} = {root_cls} {{ {fields[0]} :: {prev_cls} }}",
    )
    construction = f"{inner_cls} {{ {method} = \\_ -> {body} }}"
    for i in range(len(fields) - 2, -1, -1):
        cls = fields[i].capitalize() + "Type_"
        construction = f"{cls} {{ {fields[i + 1]} = {construction} }}"
    construction = f"{root_cls} {{ {fields[0]} = {construction} }}"
    lines.append(f"{root} = {construction}")
    return tuple(lines)


def _build_haskell_call_stub(
    type_name: str,
) -> Callable[[str, Sequence[str], StubReturn], tuple[str, ...]]:
    """Build a call stub function that uses *type_name* for field
    types.
    """

    def _haskell_call_stub(
        name: str,
        params: Sequence[str],
        _stub_return: StubReturn,
        /,
    ) -> tuple[str, ...]:
        """Delegate to module-level implementation."""
        return _build_haskell_call_stub_lines(
            name=name,
            params=params,
            _stub_return=_stub_return,
            type_name=type_name,
        )

    return _haskell_call_stub


@beartype
def _format_haskell_datetime(value: datetime.datetime, prefix: str) -> str:
    """Format a datetime as a Haskell datetime constructor.

    Timezone-aware datetimes are converted to UTC first, since
    ``UTCTime`` represents a point in time in UTC.
    """
    if value.tzinfo is not None:
        value = value.astimezone(tz=datetime.UTC)
    total_seconds = value.hour * 3600 + value.minute * 60 + value.second
    if value.microsecond:
        picos = total_seconds * 10**12 + value.microsecond * 10**6
        time_part = f"picosecondsToDiffTime {picos}"
    else:
        time_part = f"secondsToDiffTime {total_seconds}"
    return (
        f"{prefix}Datetime (UTCTime "
        f"(fromGregorian {value.year} {value.month} {value.day}) "
        f"({time_part}))"
    )


def _build_haskell_datetime_formatter(
    prefix: str,
) -> Callable[[datetime.datetime], str]:
    """Build a datetime formatter that produces ``{prefix}Datetime``
    constructors.
    """

    def _format(value: datetime.datetime) -> str:
        """Delegate to module-level implementation."""
        return _format_haskell_datetime(value=value, prefix=prefix)

    return _format


_format_datetime_haskell = _build_haskell_datetime_formatter(prefix="H")


@dataclasses.dataclass(frozen=True)
class _DateTimeFormatters:
    """Resolved date and datetime formatters."""

    format_date: Callable[[datetime.date], str]
    format_datetime: Callable[[datetime.datetime], str]


@beartype
def _wrap_with_str_constructor_date(
    value: datetime.date,
    str_prefix: str,
    formatter: Callable[[datetime.date], str],
) -> str:
    """Wrap an ISO date string with the HStr constructor."""
    return f"{str_prefix}{formatter(value)}"


@beartype
def _wrap_with_str_constructor_datetime(
    value: datetime.datetime,
    str_prefix: str,
    formatter: Callable[[datetime.datetime], str],
) -> str:
    """Wrap an ISO datetime string with the HStr constructor."""
    return f"{str_prefix}{formatter(value)}"


@beartype
def _build_date_formatters(
    *,
    date_format_name: str,
    date_formatter: Callable[[datetime.date], str],
    datetime_format_name: str,
    datetime_formatter: Callable[[datetime.datetime], str],
    constructor_prefix: str,
    is_explicit: bool,
) -> _DateTimeFormatters:
    """Build date and datetime formatters based on format settings."""
    if date_format_name == "HASKELL":
        fmt_date: Callable[[datetime.date], str] = date_ymd_formatter(
            template=(
                f"{constructor_prefix}Date "
                f"(fromGregorian {{year}} {{month}} {{day}})"
            ),
        )
    elif is_explicit:
        _str_pfx = f"{constructor_prefix}Str "

        def _explicit_date(value: datetime.date) -> str:
            """Delegate to module-level implementation."""
            return _wrap_with_str_constructor_date(
                value=value, str_prefix=_str_pfx, formatter=date_formatter
            )

        fmt_date = _explicit_date
    else:
        fmt_date = date_formatter

    if datetime_format_name == "HASKELL":
        fmt_datetime: Callable[[datetime.datetime], str] = (
            _build_haskell_datetime_formatter(prefix=constructor_prefix)
        )
    elif is_explicit:
        _str_pfx_dt = f"{constructor_prefix}Str "

        def _explicit_datetime(value: datetime.datetime) -> str:
            """Delegate to module-level implementation."""
            return _wrap_with_str_constructor_datetime(
                value=value,
                str_prefix=_str_pfx_dt,
                formatter=datetime_formatter,
            )

        fmt_datetime = _explicit_datetime
    else:
        fmt_datetime = datetime_formatter

    return _DateTimeFormatters(
        format_date=fmt_date,
        format_datetime=fmt_datetime,
    )


@dataclasses.dataclass(frozen=True)
class _StringFormatters:
    """String, bytes, and dict-entry formatters."""

    format_string: Callable[[str], str]
    format_bytes: Callable[[bytes], str]
    format_dict_entry: Callable[[str, Value, str], str]
    is_explicit: bool


@beartype
def _wrap_str_with_constructor(
    value: str,
    string_constructor: str,
    base_format_string: Callable[[str], str],
) -> str:
    """Wrap a formatted string with the constructor prefix."""
    return f"{string_constructor}{base_format_string(value)}"


@beartype
def _wrap_bytes_with_constructor(
    data: bytes,
    string_constructor: str,
    base_format_bytes: Callable[[bytes], str],
) -> str:
    """Wrap formatted bytes with the constructor prefix."""
    return f"{string_constructor}{base_format_bytes(data)}"


@beartype
def _format_explicit_dict_entry(
    key: str,
    _raw_value: Value,
    formatted_value: str,
    string_constructor: str,
) -> str:
    """Format a dict entry, stripping the constructor from the key."""
    clean_key = key.removeprefix(string_constructor)
    return f"({clean_key}, {formatted_value})"


@beartype
def _build_string_formatters(
    *,
    string_format_name: str,
    constructor_prefix: str,
    base_format_bytes: Callable[[bytes], str],
) -> _StringFormatters:
    """Build string/bytes/dict-entry formatters.

    For ``EXPLICIT`` format, string and bytes values are wrapped with the
    constructor prefix (e.g. ``HStr "hello"``), and dict keys are
    unwrapped since they are ``String``, not ``Val``.

    For ``DOUBLE`` format, values pass through unmodified, and dict
    entries use tuple formatting.
    """
    base_format_string: Callable[[str], str] = functools.partial(
        format_string_backslash_control,
        control_char_fmt="\\x{:02x}",
    )

    if string_format_name != "EXPLICIT":
        return _StringFormatters(
            format_string=base_format_string,
            format_bytes=base_format_bytes,
            format_dict_entry=tuple_dict_entry(
                format_value=passthrough_sequence_entry,
            ),
            is_explicit=False,
        )

    string_constructor = f"{constructor_prefix}Str "

    def _format_string(value: str) -> str:
        """Delegate to module-level implementation."""
        return _wrap_str_with_constructor(
            value=value,
            string_constructor=string_constructor,
            base_format_string=base_format_string,
        )

    def _format_bytes(data: bytes) -> str:
        """Delegate to module-level implementation."""
        return _wrap_bytes_with_constructor(
            data=data,
            string_constructor=string_constructor,
            base_format_bytes=base_format_bytes,
        )

    def _format_dict_entry(
        key: str,
        _raw_value: Value,
        formatted_value: str,
    ) -> str:
        """Delegate to module-level implementation."""
        return _format_explicit_dict_entry(
            key=key,
            _raw_value=_raw_value,
            formatted_value=formatted_value,
            string_constructor=string_constructor,
        )

    return _StringFormatters(
        format_string=_format_string,
        format_bytes=_format_bytes,
        format_dict_entry=_format_dict_entry,
        is_explicit=True,
    )


def _num_instance(
    *,
    has_int: bool,
    has_float: bool,
    type_name: str,
    constructor_prefix: str,
) -> str:
    """Build the ``Num`` instance with only relevant constructors."""
    if has_int:
        from_integer = f"    fromInteger = {constructor_prefix}Int"
    else:
        from_integer = (
            f"    fromInteger n = {constructor_prefix}Float (fromIntegral n)"
        )
    negate_parts: list[str] = []
    if has_int:
        negate_parts.append(
            f"    negate ({constructor_prefix}Int n) = "
            f"{constructor_prefix}Int (negate n)"
        )
    if has_float:
        negate_parts.append(
            f"    negate ({constructor_prefix}Float f) = "
            f"{constructor_prefix}Float (negate f)"
        )
    negate_parts.append('    negate _ = error "not implemented"')
    return "\n".join(
        [
            f"instance Num {type_name} where",
            from_integer,
            '    a + b = error "not implemented"',
            '    a * b = error "not implemented"',
            '    abs a = error "not implemented"',
            '    signum a = error "not implemented"',
            *negate_parts,
        ]
    )


def _has_microsecond_datetime(*, data: Value) -> bool:
    """Return whether *data* contains any datetime with microseconds."""
    if isinstance(data, datetime.datetime):
        return bool(data.microsecond)
    if isinstance(data, datetime.date):
        return False
    if isinstance(data, (ordereddict, dict)):
        return any(
            _has_microsecond_datetime(data=v)  # pyright: ignore[reportUnknownArgumentType]
            for v in data.values()  # pyright: ignore[reportUnknownMemberType,reportUnknownVariableType]
        )
    if isinstance(data, (list, set)):
        return any(_has_microsecond_datetime(data=v) for v in data)
    return False


def _datetime_import_items(
    *,
    has_from_gregorian: bool,
    has_microsecond: bool,
) -> list[str]:
    """Return ``Data.Time`` import names needed for datetime values."""
    items = ["UTCTime(..)"]
    if not has_from_gregorian:
        items.append("fromGregorian")
    items.append("secondsToDiffTime")
    if has_microsecond:
        items.append("picosecondsToDiffTime")
    return items


@beartype
def _build_scalar_body_preamble(
    *,
    date_format: enum.Enum,
    datetime_format: enum.Enum,
    is_string_import: str,
    is_string_instance: str,
    type_name: str,
    constructor_prefix: str,
    emit_is_string: bool,
    emit_num: bool,
) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
    """Build a callable that computes body-preamble lines for Haskell.

    The callable receives the set of types present in the data and the
    original data value, and returns only the imports, the type
    declaration, and typeclass instances that are actually needed.

    The returned lines are ordered: imports first, then the data type,
    then typeclass instances.

    When *emit_is_string* is ``False``, the ``IsString`` import and
    instance are suppressed (used by the ``EXPLICIT`` string format).

    When *emit_num* is ``False``, the ``Num`` and ``Fractional``
    instances are suppressed (used by the ``EXPLICIT`` numeric style).
    """
    include_hdate = date_format.value.type_produced is datetime.date
    include_hdatetime = (
        datetime_format.value.type_produced is datetime.datetime
    )
    date_needs_is_string = bool(
        emit_is_string and date_format.value.preamble_lines
    )
    datetime_needs_is_string = bool(
        emit_is_string and datetime_format.value.preamble_lines
    )
    # In EXPLICIT mode, ISO dates/datetimes produce HStr-wrapped strings,
    # so HStr String must appear in the data type.
    date_needs_str_explicit = bool(not emit_is_string and not include_hdate)
    datetime_needs_str_explicit = bool(
        not emit_is_string and not include_hdatetime
    )

    def _compute(types: frozenset[type], data: Value, /) -> tuple[str, ...]:
        """Return body-preamble lines for the given *types*."""
        p = constructor_prefix
        data_val_parts = [
            constructor
            for type_set, constructor in (
                (frozenset({type(None)}), f"{p}Null"),
                (frozenset({bool}), f"{p}Bool Bool"),
                (frozenset({int}), f"{p}Int Integer"),
                (frozenset({float}), f"{p}Float Double"),
                (frozenset({str, bytes}), f"{p}Str String"),
                (frozenset({list}), f"{p}List [{type_name}]"),
                (
                    frozenset({dict, ordereddict}),
                    f"{p}Map [(String, {type_name})]",
                ),
                (frozenset({set}), f"{p}Set [{type_name}]"),
            )
            if types & type_set
        ]
        import_items: list[str] = []
        if include_hdate and datetime.date in types:
            data_val_parts.append(f"{p}Date Day")
            import_items.extend(["Day", "fromGregorian"])
        if include_hdatetime and datetime.datetime in types:
            data_val_parts.append(f"{p}Datetime UTCTime")
            import_items.extend(
                _datetime_import_items(
                    has_from_gregorian="fromGregorian" in import_items,
                    has_microsecond=_has_microsecond_datetime(data=data),
                ),
            )

        needs_is_string = emit_is_string and (
            bool(types & {str, bytes})
            or (date_needs_is_string and datetime.date in types)
            or (datetime_needs_is_string and datetime.datetime in types)
        )
        needs_str_constructor = (
            bool(types & {str, bytes})
            or (date_needs_is_string and datetime.date in types)
            or (datetime_needs_is_string and datetime.datetime in types)
            or (date_needs_str_explicit and datetime.date in types)
            or (datetime_needs_str_explicit and datetime.datetime in types)
        )
        if needs_str_constructor and f"{p}Str String" not in data_val_parts:
            data_val_parts.append(f"{p}Str String")

        # Emit imports first, then data declaration, then instances.
        imports: list[str] = []
        if import_items:
            imports.append(
                "import Data.Time (" + ", ".join(import_items) + ")"
            )
        if needs_is_string:
            imports.append(is_string_import)

        instances: list[str] = []
        if needs_is_string:
            instances.append(is_string_instance)

        has_float = float in types
        has_int = int in types
        if emit_num and (has_float or has_int):
            instances.append(
                _num_instance(
                    has_int=has_int,
                    has_float=has_float,
                    type_name=type_name,
                    constructor_prefix=constructor_prefix,
                ),
            )
        if emit_num and has_float:
            instances.append(
                f"instance Fractional {type_name} where\n"
                f"    fromRational r = {p}Float (realToFrac r)\n"
                '    a / b = error "not implemented"'
            )

        lines: list[str] = imports
        lines.append(f"data {type_name} = " + " | ".join(data_val_parts))
        lines.extend(instances)
        return tuple(lines)

    return _compute


@dataclasses.dataclass(frozen=True)
class _SequenceSetup:
    """Sequence format configuration and opener."""

    format_config: SequenceFormatConfig
    sequence_open: Callable[[list[Value]], str]


@beartype
def _build_sequence_setup(
    *,
    sequence_format: enum.Enum,
    constructor_prefix: str,
) -> _SequenceSetup:
    """Build sequence format config, customizing the opener for LIST."""
    fmt: SequenceFormatConfig = sequence_format.value
    if sequence_format.name == "LIST":
        seq_open = fixed_sequence_open(
            open_str=f"{constructor_prefix}List [",
        )
        return _SequenceSetup(
            format_config=dataclasses.replace(fmt, sequence_open=seq_open),
            sequence_open=seq_open,
        )
    return _SequenceSetup(
        format_config=fmt,
        sequence_open=fmt.sequence_open,
    )


@dataclasses.dataclass(frozen=True)
class _DeclarationFormatters:
    """Variable declaration and assignment formatters."""

    format_variable_declaration: Callable[
        [str, str, Value, frozenset[enum.Enum]], str
    ]
    format_variable_assignment: Callable[[str, str, Value], str]


@beartype
def _format_haskell_declaration(
    name: str,
    value: str,
    data: Value,
    modifiers: frozenset[enum.Enum],
    *,
    base_declaration: Callable[[str, str, Value, frozenset[enum.Enum]], str],
    sequence_declared_type: str | None,
    type_name: str,
) -> str:
    """Format a variable declaration with type annotation."""
    base = base_declaration(name, value, data, modifiers)
    if isinstance(data, list):
        if sequence_declared_type is None:
            return base
        return f"{name} :: {sequence_declared_type}\n{base}"
    return f"{name} :: {type_name}\n{base}"


@beartype
def _build_declaration_formatters(
    *,
    declaration_style: enum.Enum,
    sequence_format: enum.Enum,
    type_name: str,
) -> _DeclarationFormatters:
    """Build declaration/assignment formatters with type annotations."""
    base_declaration: Callable[
        [str, str, Value, frozenset[enum.Enum]], str
    ] = declaration_style.value.formatter
    raw_declared = sequence_format.value.declared_type
    sequence_declared_type = (
        raw_declared.replace("Val", type_name)
        if raw_declared is not None
        else None
    )

    def _haskell_declaration(
        name: str,
        value: str,
        data: Value,
        modifiers: frozenset[enum.Enum],
    ) -> str:
        """Delegate to module-level implementation."""
        return _format_haskell_declaration(
            name=name,
            value=value,
            data=data,
            modifiers=modifiers,
            base_declaration=base_declaration,
            sequence_declared_type=sequence_declared_type,
            type_name=type_name,
        )

    return _DeclarationFormatters(
        format_variable_declaration=_haskell_declaration,
        format_variable_assignment=variable_formatter(
            template="{name} = {value}",
        ),
    )


@dataclasses.dataclass(frozen=True)
class _PreambleSetup:
    """Preamble configuration for Haskell output."""

    scalar_preamble: dict[type, tuple[str, ...]]
    compute_body_preamble: Callable[[frozenset[type], Value], tuple[str, ...]]


@beartype
def _build_preamble_setup(
    *,
    date_format: enum.Enum,
    datetime_format: enum.Enum,
    is_explicit: bool,
    type_name: str,
    constructor_prefix: str,
    emit_num: bool,
) -> _PreambleSetup:
    """Build scalar preamble and body-preamble computation."""
    _overloaded_strings = ("{-# LANGUAGE OverloadedStrings #-}",)
    if is_explicit:
        # EXPLICIT mode wraps dates/datetimes with HStr, so no
        # OverloadedStrings pragma is needed for ISO formats.
        scalar_preamble: dict[type, tuple[str, ...]] = {}
    else:
        str_extra: dict[type, tuple[str, ...]] = {
            str: _overloaded_strings,
            bytes: _overloaded_strings,
        }
        scalar_preamble = date_scalar_preamble(
            date_format=date_format,
            datetime_format=datetime_format,
            extra=str_extra,
        )
    return _PreambleSetup(
        scalar_preamble=scalar_preamble,
        compute_body_preamble=_build_scalar_body_preamble(
            date_format=date_format,
            datetime_format=datetime_format,
            is_string_import="import Data.String (IsString(fromString))",
            is_string_instance=(
                f"instance IsString {type_name} where\n"
                f"    fromString = {constructor_prefix}Str"
            ),
            type_name=type_name,
            constructor_prefix=constructor_prefix,
            emit_is_string=not is_explicit,
            emit_num=emit_num,
        ),
    )


@beartype
def _wrap_integer_with_constructor(
    value: int,
    int_prefix: str,
    base_format_integer: Callable[[int], str],
) -> str:
    """Wrap an integer with the constructor prefix."""
    formatted = base_format_integer(value)
    if value < 0:
        return f"{int_prefix}({formatted})"
    return f"{int_prefix}{formatted}"


@beartype
def _wrap_float_with_constructor(
    value: float,
    float_prefix: str,
    base_format_float: Callable[[float], str],
) -> str:
    """Wrap a float with the constructor prefix."""
    formatted = base_format_float(value)
    return f"{float_prefix}({formatted})"


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Haskell(metaclass=LanguageCls):
    """Haskell language specification.

    The generated output uses custom constructors (``HNull``, ``HBool``,
    ``HList``, ``HMap``, ``HSet``) that are **not** built-in Haskell types.
    To compile the generated code, define a ``Val`` ADT and typeclass
    instances in the consuming module:

    .. code-block:: haskell

       data Val
         = HNull
         | HBool Bool
         | HInt Integer
         | HFloat Double
         | HStr String
         | HList [Val]
         | HMap [(String, Val)]
         | HSet [Val]

       instance Num Val where
           fromInteger = HInt
           negate (HInt n)   = HInt (negate n)
           negate (HFloat f) = HFloat (negate f)
           ...

       instance Fractional Val where
           fromRational r = HFloat (realToFrac r)
           ...

    The ``Num`` / ``Fractional`` instances let numeric literals resolve to
    ``HInt`` / ``HFloat``.

    With the default ``EXPLICIT`` string format, strings are wrapped
    explicitly (e.g. ``HStr "hi"``).  The ``DOUBLE`` format instead uses
    ``OverloadedStrings`` so bare ``"hi"`` literals resolve to ``HStr "hi"``
    via an ``IsString`` instance.

    Args:
        date_format: How to format :class:`datetime.date` values.

            * ``date_formats.HASKELL`` — ``fromGregorian`` call,
              e.g. ``fromGregorian 2024 1 15``.
              Requires the ``time`` package.
            * ``date_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15"``.

        datetime_format: How to format :class:`datetime.datetime` values.

            * ``datetime_formats.HASKELL`` — ``UTCTime`` constructor,
              e.g. ``UTCTime (fromGregorian 2024 1 15)
              (secondsToDiffTime 45000)``.
              Requires the ``time`` package.
            * ``datetime_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15T12:30:00"``.

        type_name: Name of the generated custom type.  Defaults to
            ``"Val"``.

        constructor_prefix: Prefix for generated constructor names.
            Defaults to ``"H"``, producing constructors like ``HNull``,
            ``HBool``, ``HInt``, etc.

        numeric_style: How numeric literals are represented.

            * ``numeric_styles.OVERLOADED`` — emit ``Num`` and
              ``Fractional`` typeclass instances so that bare literals
              like ``42`` and ``3.14`` resolve to the custom type.
            * ``numeric_styles.EXPLICIT`` — wrap every numeric literal
              with its constructor (``HInt 42``, ``HFloat (3.14)``)
              and omit the typeclass instances.
    """

    extension = ".hs"
    pygments_name = "haskell"
    supports_default_set_element_type = False
    supports_default_sequence_element_type = False
    supports_default_dict_value_type = False
    supports_default_dict_key_type = False
    supports_default_ordered_map_value_type = False
    supports_non_printable_ascii_dict_keys = True
    supports_variable_names = True
    supports_dotted_calls = True

    class DateFormats(enum.Enum):
        """Date format options for Haskell."""

        HASKELL = DateFormatConfig(
            formatter=date_ymd_formatter(
                template="HDate (fromGregorian {year} {month} {day})",
            ),
        )
        ISO = DateFormatConfig(
            formatter=format_date_iso,
            preamble_lines=("{-# LANGUAGE OverloadedStrings #-}",),
            type_produced=str,
        )

        def __call__(self, date_value: datetime.date, /) -> str:
            """Format a date."""
            return self.value.formatter(date_value)

    class DatetimeFormats(enum.Enum):
        """Datetime format options for Haskell."""

        HASKELL = DatetimeFormatConfig(formatter=_format_datetime_haskell)
        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            preamble_lines=("{-# LANGUAGE OverloadedStrings #-}",),
            type_produced=str,
        )

        def __call__(self, dt_value: datetime.datetime, /) -> str:
            """Format a datetime."""
            return self.value.formatter(dt_value)

    class BytesFormats(enum.Enum):
        """Bytes formatting options."""

        HEX = enum.member(value=format_bytes_hex)
        BASE64 = enum.member(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self.value(value=data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for Haskell."""

        LIST = SequenceFormatConfig(
            sequence_open=fixed_sequence_open(open_str="HList ["),
            close="]",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            supports_trailing_comma=True,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type="Val",
        )
        TUPLE = SequenceFormatConfig(
            sequence_open=fixed_sequence_open(open_str="("),
            close=")",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            supports_trailing_comma=False,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
        )

    class SetFormats(enum.Enum):
        """Set type options for Haskell."""

        SET = SetFormatConfig(
            set_open=fixed_set_open(open_str="HSet ["),
            close="]",
            empty_set=None,
            preamble_lines=(),
            set_opener_template="",
            supports_heterogeneity=True,
        )

    class CommentFormats(enum.Enum):
        """Comment style options."""

        DOUBLE_DASH = CommentConfig(
            prefix="--",
            suffix="",
        )
        BLOCK = CommentConfig(
            prefix="{-",
            suffix=" -}",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        ASSIGN = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="{name} = {value}"
            ),
            supports_redefinition=False,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="(1/0)",
        negative_infinity="(-1/0)",
        nan="(0/0)",
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=format_float_fixed)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = enum.member(value=str)
        HEX = enum.member(value=format_integer_hex)
        OCTAL = enum.member(value=format_integer_octal)
        BINARY = enum.member(value=format_integer_binary)

        def __call__(self, value: int, /) -> str:
            """Format an integer."""
            formatter: Callable[[int], str] = self.value
            return formatter(value)

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options.

        ``OVERLOADED`` emits ``Num`` and ``Fractional`` typeclass
        instances so that bare numeric literals (``42``, ``3.14``)
        resolve to the custom type via ``fromInteger`` /
        ``fromRational``.

        ``EXPLICIT`` wraps every numeric literal with its constructor
        (``HInt 42``, ``HFloat 3.14``) and omits the typeclass
        instances.
        """

        OVERLOADED = "overloaded"
        EXPLICIT = "explicit"

    numeric_styles = NumericStyles

    class StringFormats(enum.Enum):
        """String format options."""

        DOUBLE = "double"
        EXPLICIT = "explicit"

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        AUTO = enum.auto()

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class LineEndings(enum.Enum):
        """Line ending options."""

        SEMICOLON = "semicolon"

    line_endings = LineEndings

    class CallStyles(enum.Enum):
        """Haskell call style options."""

        POSITIONAL = PositionalCallStyle()

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers
    validate_spec_for_data = no_validate_spec_for_data

    @staticmethod
    def wrap_in_file(
        content: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap a Haskell variable binding in a module."""
        preamble = "\n".join(body_preamble)
        if not variable_name:
            # Call mode: bare expressions are not valid at module
            # top level in Haskell, so wrap them in ``main``.
            indented = textwrap.indent(text=content, prefix="    ")
            return (
                "module Check where\n"
                + preamble
                + "\nmain :: IO ()\nmain = do\n"
                + indented
                + "\n    pure ()"
            )
        return "module Check where\n" + preamble + "\n" + content

    @staticmethod
    def wrap_combined_in_file(
        declaration: str,
        assignment: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Unsupported: literalize() rejects BothVariableForms
        upstream.
        """
        del declaration, assignment, variable_name, body_preamble
        raise NotImplementedError

    date_format: DateFormats = DateFormats.HASKELL
    datetime_format: DatetimeFormats = DatetimeFormats.HASKELL
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.LIST
    set_format: SetFormats = SetFormats.SET
    variable_type_hints: VariableTypeHints = VariableTypeHints.AUTO
    comment_format: CommentFormats = CommentFormats.DOUBLE_DASH
    declaration_style: DeclarationStyles = DeclarationStyles.ASSIGN
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.EXPLICIT
    trailing_comma: TrailingCommas = TrailingCommas.NO
    line_ending: LineEndings = LineEndings.SEMICOLON
    call_style: CallStyles = CallStyles.POSITIONAL
    indent: str = "    "
    type_name: str = "Val"
    constructor_prefix: str = "H"

    indent_closing_delimiter: ClassVar[bool] = True
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = False
    supports_collection_comments: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = False
    supports_scalar_inline_comments: ClassVar[bool] = True
    statement_terminator: ClassVar[str] = ""
    static_preamble: ClassVar[Sequence[str]] = ()
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()

    @cached_property
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return passthrough_sequence_entry

    @cached_property
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return passthrough_set_entry

    @cached_property
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines."""
        return no_data_preamble

    @cached_property
    def type_hint_collection_preamble_lines(
        self,
    ) -> Callable[[frozenset[type]], tuple[str, ...]]:
        """Return preamble lines for empty-collection type hints."""
        return no_type_hint_preamble

    @cached_property
    def null_literal(self) -> str:
        """Literal representing ``None``."""
        return f"{self.constructor_prefix}Null"

    @cached_property
    def true_literal(self) -> str:
        """Literal representing ``True``."""
        return f"{self.constructor_prefix}Bool True"

    @cached_property
    def false_literal(self) -> str:
        """Literal representing ``False``."""
        return f"{self.constructor_prefix}Bool False"

    @cached_property
    def _seq_setup(self) -> _SequenceSetup:
        """Shared sequence format setup."""
        return _build_sequence_setup(
            sequence_format=self.sequence_format,
            constructor_prefix=self.constructor_prefix,
        )

    @cached_property
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        return self._seq_setup.format_config

    @cached_property
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        return self._seq_setup.sequence_open

    @cached_property
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        return dataclasses.replace(
            self.set_format.value,
            set_open=fixed_set_open(
                open_str=f"{self.constructor_prefix}Set [",
            ),
        )

    @cached_property
    def _string_fmts(self) -> _StringFormatters:
        """Shared string/bytes/dict-entry formatters."""
        return _build_string_formatters(
            string_format_name=self.string_format.name,
            constructor_prefix=self.constructor_prefix,
            base_format_bytes=self.bytes_format,
        )

    @cached_property
    def format_string(self) -> Callable[[str], str]:
        """Callable that formats a string value as a quoted literal."""
        return self._string_fmts.format_string

    @cached_property
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self._string_fmts.format_bytes

    @cached_property
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        map_open = f"{self.constructor_prefix}Map ["
        return DictFormatConfig(
            dict_open=fixed_dict_open(open_str=map_open),
            close="]",
            format_entry=self._string_fmts.format_dict_entry,
            empty_dict=None,
            preamble_lines=(),
            narrowed_open=None,
        )

    @cached_property
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        map_open = f"{self.constructor_prefix}Map ["
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_dict_open(open_str=map_open),
            close="]",
            preamble_lines=(),
        )

    @cached_property
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return self._string_fmts.format_dict_entry

    @cached_property
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    def _date_fmts(self) -> _DateTimeFormatters:
        """Shared date/datetime formatter bundle."""
        return _build_date_formatters(
            date_format_name=self.date_format.name,
            date_formatter=self.date_format,
            datetime_format_name=self.datetime_format.name,
            datetime_formatter=self.datetime_format,
            constructor_prefix=self.constructor_prefix,
            is_explicit=self._string_fmts.is_explicit,
        )

    @cached_property
    def format_date(self) -> Callable[[datetime.date], str]:
        """Callable that formats a date as a string literal."""
        return self._date_fmts.format_date

    @cached_property
    def format_datetime(self) -> Callable[[datetime.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        return self._date_fmts.format_datetime

    @cached_property
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        if self.numeric_style.name == "EXPLICIT":
            _float_prefix = f"{self.constructor_prefix}Float "
            _base_format_float: Callable[[float], str] = self.float_format

            def _wrap_float(value: float) -> str:
                """Delegate to module-level implementation."""
                return _wrap_float_with_constructor(
                    value=value,
                    float_prefix=_float_prefix,
                    base_format_float=_base_format_float,
                )

            return _wrap_float
        return self.float_format

    @cached_property
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal."""
        if self.numeric_style.name == "EXPLICIT":
            _int_prefix = f"{self.constructor_prefix}Int "
            _base_format_integer: Callable[[int], str] = self.integer_format

            def _wrap_integer(value: int) -> str:
                """Delegate to module-level implementation."""
                return _wrap_integer_with_constructor(
                    value=value,
                    int_prefix=_int_prefix,
                    base_format_integer=_base_format_integer,
                )

            return _wrap_integer
        return self.integer_format

    @cached_property
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    def _decl_fmts(self) -> _DeclarationFormatters:
        """Shared declaration/assignment formatter bundle."""
        return _build_declaration_formatters(
            declaration_style=self.declaration_style,
            sequence_format=self.sequence_format,
            type_name=self.type_name,
        )

    @cached_property
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        return self._decl_fmts.format_variable_declaration

    @cached_property
    def format_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Callable that formats an assignment to an existing variable."""
        return self._decl_fmts.format_variable_assignment

    @cached_property
    def _preamble(self) -> _PreambleSetup:
        """Shared preamble setup bundle."""
        return _build_preamble_setup(
            date_format=self.date_format,
            datetime_format=self.datetime_format,
            is_explicit=self._string_fmts.is_explicit,
            type_name=self.type_name,
            constructor_prefix=self.constructor_prefix,
            emit_num=self.numeric_style.name != "EXPLICIT",
        )

    @cached_property
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble for Haskell imports."""
        return self._preamble.scalar_preamble

    @cached_property
    def scalar_body_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar body preamble (Haskell needs none)."""
        return {}

    @cached_property
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines for Haskell data declarations."""
        return self._preamble.compute_body_preamble

    @cached_property
    def call_style_config(self) -> CallStyle | None:
        """Configuration for the chosen call style."""
        return self.call_style.value

    @cached_property
    def format_call_stub(
        self,
    ) -> Callable[[str, Sequence[str], StubReturn], tuple[str, ...]]:
        """Callable that returns Haskell stub declarations for a call."""
        return _build_haskell_call_stub(type_name=self.type_name)

    @cached_property
    def format_call_preamble_stub(
        self,
    ) -> Callable[[str, Sequence[str], StubReturn], tuple[str, ...]]:
        """Callable that returns preamble stub declarations."""
        return _haskell_call_preamble_stub
