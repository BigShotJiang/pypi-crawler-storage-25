"""Fortran language specification."""

import dataclasses
import datetime
import enum
import textwrap
from collections.abc import Callable, Sequence
from functools import cached_property
from typing import ClassVar

from beartype import beartype

from literalizer._formatters.collection_openers import (
    fixed_dict_open,
    fixed_sequence_open,
    fixed_set_open,
)
from literalizer._formatters.format_dates import (
    format_date_iso,
    format_datetime_iso,
)
from literalizer._formatters.format_entries import (
    dict_entry_with_template,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
)
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    make_overflow_fallback_formatter,
    raise_for_unrepresentable_int,
)
from literalizer._formatters.format_strings import format_string_concat_control
from literalizer._language import (
    CallStyle,
    CommentConfig,
    DateFormatConfig,
    DatetimeFormatConfig,
    DeclarationStyleConfig,
    DictFormatConfig,
    FloatSpecialsMixin,
    LanguageCls,
    OrderedMapFormatConfig,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    body_preamble_from_scalars,
    no_call_stub,
    no_data_preamble,
    no_type_hint_preamble,
    no_validate_spec_for_data,
    prepend_body_preamble,
)
from literalizer._types import Value


@beartype
def _apply_fortran_entry(
    original: Value,
    formatted: str,
    *,
    int_name: str,
    real_name: str,
    str_name: str,
) -> str:
    """Wrap a formatted entry in its constructor call."""
    match original:
        case bool():
            return formatted
        case int():
            return f"{int_name}({formatted})"
        case float():
            return f"{real_name}({formatted})"
        case str() | bytes() | datetime.date():
            return f"{str_name}({formatted})"
        case _:
            return formatted


@beartype
def _build_format_fortran_entry(
    *,
    int_name: str,
    real_name: str,
    str_name: str,
) -> Callable[[Value, str], str]:
    """Build a formatter that wraps values in the appropriate
    constructor.
    """

    def _format_fortran_entry(original: Value, formatted: str) -> str:
        """Delegate to module-level implementation."""
        return _apply_fortran_entry(
            original=original,
            formatted=formatted,
            int_name=int_name,
            real_name=real_name,
            str_name=str_name,
        )

    return _format_fortran_entry


@beartype
def _fortran_comment_pos(line: str) -> int | None:
    """Return the index of the ``!`` comment character in *line* that
    lies outside any string literal, or ``None`` if there is no comment.
    """
    in_single_quote = False
    in_double_quote = False
    i = 0
    while i < len(line):
        c = line[i]
        if c == "'" and not in_double_quote:
            if in_single_quote and i + 1 < len(line) and line[i + 1] == "'":
                i += 2
                continue
            in_single_quote = not in_single_quote
        elif c == '"' and not in_single_quote:
            in_double_quote = not in_double_quote
        elif c == "!" and not in_single_quote and not in_double_quote:
            return i
        i += 1
    return None


@beartype
def _add_continuation(value: str) -> str:
    """Add Fortran ``&`` line-continuation to non-comment, non-last
    lines.

    In Fortran free-form source a logical line may span multiple physical
    lines.  The ``&`` continuation character must be the last
    non-whitespace, non-comment character on the physical line.  Pure
    comment lines (blank or starting with ``!``) are transparent to the
    continuation mechanism and receive no ``&``.
    """
    lines = value.splitlines()
    if len(lines) <= 1:
        return value
    result: list[str] = []
    for i, line in enumerate(iterable=lines):
        is_last = i == len(lines) - 1
        stripped = line.strip()
        is_pure_comment = not stripped or stripped.startswith("!")
        if is_last or is_pure_comment:
            result.append(line)
        else:
            pos = _fortran_comment_pos(line=line)
            if pos is not None:
                result.append(line[:pos].rstrip() + " &  " + line[pos:])
            else:
                result.append(line + " &")
    return "\n".join(result)


@beartype
def _apply_fortran_variable_declaration(
    name: str,
    value: str,
    data: Value,
    format_entry: Callable[[Value, str], str],
) -> str:
    """Format a variable declaration and initialisation."""
    fval = format_entry(data, value)
    continued = _add_continuation(value=fval)
    return f"type(fval_t) :: {name}\n{name} = {continued}"


@beartype
def _build_format_variable_declaration(
    *,
    format_entry: Callable[[Value, str], str],
) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
    """Build a variable declaration formatter."""

    def _format_variable_declaration(
        name: str,
        value: str,
        data: Value,
        _modifiers: frozenset[enum.Enum],
    ) -> str:
        """Delegate to module-level implementation."""
        return _apply_fortran_variable_declaration(
            name=name, value=value, data=data, format_entry=format_entry
        )

    return _format_variable_declaration


@beartype
def _apply_fortran_variable_assignment(
    name: str,
    value: str,
    data: Value,
    format_entry: Callable[[Value, str], str],
) -> str:
    """Format an assignment to an existing variable."""
    fval = format_entry(data, value)
    continued = _add_continuation(value=fval)
    return f"{name} = {continued}"


@beartype
def _build_format_variable_assignment(
    *,
    format_entry: Callable[[Value, str], str],
) -> Callable[[str, str, Value], str]:
    """Build a variable assignment formatter."""

    def _format_variable_assignment(name: str, value: str, data: Value) -> str:
        """Delegate to module-level implementation."""
        return _apply_fortran_variable_assignment(
            name=name, value=value, data=data, format_entry=format_entry
        )

    return _format_variable_assignment


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Fortran(metaclass=LanguageCls):
    """Fortran language specification."""

    extension = ".f90"
    pygments_name = "fortran"
    supports_default_set_element_type = False
    supports_default_sequence_element_type = False
    supports_default_dict_value_type = False
    supports_default_dict_key_type = False
    supports_default_ordered_map_value_type = False
    supports_non_printable_ascii_dict_keys = True
    supports_variable_names = True
    supports_dotted_calls = True

    class DateFormats(enum.Enum):
        """Date format options for Fortran."""

        ISO = DateFormatConfig(formatter=format_date_iso, type_produced=str)

        def __call__(self, date_value: datetime.date, /) -> str:
            """Format a date."""
            return self.value.formatter(date_value)

    class DatetimeFormats(enum.Enum):
        """Datetime format options for Fortran."""

        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            type_produced=str,
        )

        def __call__(self, dt_value: datetime.datetime, /) -> str:
            """Format a datetime."""
            return self.value.formatter(dt_value)

    class BytesFormats(enum.Enum):
        """Bytes formatting options."""

        HEX = enum.member(value=format_bytes_hex)
        BASE64 = enum.member(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self.value(value=data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for Fortran."""

        LIST = SequenceFormatConfig(
            sequence_open=fixed_sequence_open(open_str="flist([fval_t :: "),
            close="])",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            supports_trailing_comma=False,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
        )

    class SetFormats(enum.Enum):
        """Set type options for Fortran."""

        SET = SetFormatConfig(
            set_open=fixed_set_open(open_str="fset([fval_t :: "),
            close="])",
            empty_set=None,
            preamble_lines=(),
            set_opener_template="",
            supports_heterogeneity=True,
        )

    class CommentFormats(enum.Enum):
        """Comment style options."""

        EXCLAMATION = CommentConfig(
            prefix="!",
            suffix="",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        TYPED = DeclarationStyleConfig(
            formatter=_build_format_variable_declaration(
                format_entry=_build_format_fortran_entry(
                    int_name="fint",
                    real_name="freal",
                    str_name="fstr",
                ),
            ),
            supports_redefinition=True,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="ieee_value(0.0, ieee_positive_inf)",
        negative_infinity="ieee_value(0.0, ieee_negative_inf)",
        nan="ieee_value(0.0, ieee_quiet_nan)",
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=format_float_fixed)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = "decimal"

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(enum.Enum):
        """String format options."""

        DOUBLE = "double"

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        AUTO = enum.auto()

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class LineEndings(enum.Enum):
        """Line ending options."""

        SEMICOLON = "semicolon"

    line_endings = LineEndings

    class CallStyles(enum.Enum):
        """Fortran call style options."""

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers
    validate_spec_for_data = no_validate_spec_for_data

    @staticmethod
    def wrap_in_file(
        content: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap a Fortran variable declaration in a program."""
        del variable_name
        content = prepend_body_preamble(
            content=content,
            body_preamble=body_preamble,
        )
        indented = textwrap.indent(text=content, prefix="  ")
        return (
            "program check\n"
            "  use fval_m\n"
            "  implicit none\n"
            f"{indented}\n"
            "end program check"
        )

    @staticmethod
    def wrap_combined_in_file(
        declaration: str,
        assignment: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap Fortran declaration + assignment in separate
        subroutines.
        """
        declaration = prepend_body_preamble(
            content=declaration,
            body_preamble=body_preamble,
        )
        decl_indented = textwrap.indent(text=declaration, prefix="  ")
        assign_indented = textwrap.indent(text=assignment, prefix="  ")
        return (
            "subroutine check_declaration()\n"
            "  use fval_m\n"
            "  implicit none\n"
            f"{decl_indented}\n"
            "end subroutine check_declaration\n"
            "\n"
            "subroutine check_assignment()\n"
            "  use fval_m\n"
            "  implicit none\n"
            f"  type(fval_t) :: {variable_name}\n"
            f"{assign_indented}\n"
            "end subroutine check_assignment\n"
            "\n"
            "program main\n"
            "  call check_declaration()\n"
            "  call check_assignment()\n"
            "end program main"
        )

    date_format: DateFormats = DateFormats.ISO
    datetime_format: DatetimeFormats = DatetimeFormats.ISO
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.LIST
    set_format: SetFormats = SetFormats.SET
    variable_type_hints: VariableTypeHints = VariableTypeHints.AUTO
    comment_format: CommentFormats = CommentFormats.EXCLAMATION
    declaration_style: DeclarationStyles = DeclarationStyles.TYPED
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.NO
    line_ending: LineEndings = LineEndings.SEMICOLON
    indent: str = "    "
    null_name: str = "fnull"
    bool_name: str = "fbool"
    int_name: str = "fint"
    real_name: str = "freal"
    str_name: str = "fstr"
    list_name: str = "flist"
    map_name: str = "fmap"
    set_name: str = "fset"
    entry_name: str = "fentry"

    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = False
    supports_collection_comments: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = False
    supports_scalar_inline_comments: ClassVar[bool] = False
    statement_terminator: ClassVar[str] = ""
    special_float_preamble: ClassVar[tuple[str, ...]] = (
        "  use, intrinsic :: ieee_arithmetic",
    )
    call_style_config: ClassVar[CallStyle | None] = None

    @cached_property
    def format_integer(self) -> Callable[[int], str]:
        """Format an int value as an int64 Fortran literal."""
        return make_overflow_fallback_formatter(
            base=lambda value: f"{value}_int64",
            fallback=raise_for_unrepresentable_int(language_name="Fortran"),
        )

    @cached_property
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines."""
        return no_data_preamble

    @cached_property
    def type_hint_collection_preamble_lines(
        self,
    ) -> Callable[[frozenset[type]], tuple[str, ...]]:
        """Return preamble lines for empty-collection type hints."""
        return no_type_hint_preamble

    @cached_property
    def format_call_stub(
        self,
    ) -> Callable[[str, Sequence[str], StubReturn], tuple[str, ...]]:
        """Return stub declarations for a call expression."""
        return no_call_stub

    @cached_property
    def format_call_preamble_stub(
        self,
    ) -> Callable[[str, Sequence[str], StubReturn], tuple[str, ...]]:
        """Return file-scope stubs for a call expression."""
        return no_call_stub

    @cached_property
    def _format_entry(self) -> Callable[[Value, str], str]:
        """Shared entry formatter for Fortran values."""
        return _build_format_fortran_entry(
            int_name=self.int_name,
            real_name=self.real_name,
            str_name=self.str_name,
        )

    @cached_property
    def null_literal(self) -> str:
        """Literal representing ``None``."""
        return f"{self.null_name}()"

    @cached_property
    def true_literal(self) -> str:
        """Literal representing ``True``."""
        return f"{self.bool_name}(.true.)"

    @cached_property
    def false_literal(self) -> str:
        """Literal representing ``False``."""
        return f"{self.bool_name}(.false.)"

    @cached_property
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        fmt = self.sequence_format.value
        return SequenceFormatConfig(
            sequence_open=fixed_sequence_open(
                open_str=f"{self.list_name}([fval_t :: ",
            ),
            close="])",
            supports_heterogeneity=fmt.supports_heterogeneity,
            single_element_trailing_comma=(fmt.single_element_trailing_comma),
            supports_trailing_comma=fmt.supports_trailing_comma,
            empty_sequence=fmt.empty_sequence,
            preamble_lines=fmt.preamble_lines,
            format_entry=fmt.format_entry,
            typed_opener_fallback=fmt.typed_opener_fallback,
            uses_typed_literal_for_scalars=(
                fmt.uses_typed_literal_for_scalars
            ),
            requires_uniform_record_shapes=(
                fmt.requires_uniform_record_shapes
            ),
            declared_type=fmt.declared_type,
        )

    @cached_property
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        return SetFormatConfig(
            set_open=fixed_set_open(
                open_str=f"{self.set_name}([fval_t :: ",
            ),
            close="])",
            empty_set=self.set_format.value.empty_set,
            preamble_lines=self.set_format.value.preamble_lines,
            set_opener_template=self.set_format.value.set_opener_template,
            supports_heterogeneity=self.set_format.value.supports_heterogeneity,
        )

    @cached_property
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        return self.sequence_format_config.sequence_open

    @cached_property
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        return DictFormatConfig(
            dict_open=fixed_dict_open(
                open_str=f"{self.map_name}([fval_t :: ",
            ),
            close="])",
            format_entry=dict_entry_with_template(
                template=f"{self.entry_name}({{key}}, {{value}})",
                format_value=self._format_entry,
            ),
            empty_dict=None,
            preamble_lines=(),
            narrowed_open=None,
        )

    @cached_property
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    def format_date(self) -> Callable[[datetime.date], str]:
        """Callable that formats a date as a string literal."""
        return self.date_format

    @cached_property
    def format_datetime(self) -> Callable[[datetime.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        return self.datetime_format

    @cached_property
    def format_string(self) -> Callable[[str], str]:
        """Callable that formats a string value as a quoted literal."""
        return format_string_concat_control(
            quote_char="'",
            quote_escape="''",
            control_char_template="achar({})",
            concat_operator=" // ",
            escape_backslash=False,
        )

    @cached_property
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Callable that formats one sequence entry."""
        return self._format_entry

    @cached_property
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Callable that formats one set entry."""
        return self._format_entry

    @cached_property
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_dict_open(
                open_str=f"{self.map_name}([fval_t :: ",
            ),
            close="])",
            preamble_lines=(),
        )

    @cached_property
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return dict_entry_with_template(
            template=f"{self.entry_name}({{key}}, {{value}})",
            format_value=self._format_entry,
        )

    @cached_property
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        return _build_format_variable_declaration(
            format_entry=self._format_entry,
        )

    @cached_property
    def format_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Callable that formats an assignment to an existing variable."""
        return _build_format_variable_assignment(
            format_entry=self._format_entry,
        )

    @cached_property
    def static_preamble(self) -> Sequence[str]:
        """Static preamble lines emitted once per file."""
        return ("module fval_m",)

    @cached_property
    def static_body_preamble(self) -> Sequence[str]:
        """Static body-preamble lines emitted once per file."""
        return (
            "  use, intrinsic :: iso_fortran_env, only: int64",
            "  implicit none",
            "  type :: fval_t",
            "    integer :: t = 0",
            "  end type fval_t",
            "contains",
            f"  function {self.null_name}() result(v)"
            "; type(fval_t) :: v; end function",
            f"  function {self.bool_name}(b) result(v)"
            "; logical, intent(in) :: b"
            "; type(fval_t) :: v; end function",
            f"  function {self.int_name}(n) result(v)"
            "; integer(kind=int64), intent(in) :: n"
            "; type(fval_t) :: v; end function",
            f"  function {self.real_name}(x) result(v)"
            "; real, intent(in) :: x"
            "; type(fval_t) :: v; end function",
            f"  function {self.str_name}(s) result(v)"
            "; character(len=*), intent(in) :: s"
            "; type(fval_t) :: v; end function",
            f"  function {self.list_name}(a) result(v)"
            "; type(fval_t), intent(in) :: a(:)"
            "; type(fval_t) :: v; end function",
            f"  function {self.map_name}(a) result(v)"
            "; type(fval_t), intent(in) :: a(:)"
            "; type(fval_t) :: v; end function",
            f"  function {self.set_name}(a) result(v)"
            "; type(fval_t), intent(in) :: a(:)"
            "; type(fval_t) :: v; end function",
            f"  function {self.entry_name}(k, u) result(v)"
            "; character(len=*), intent(in) :: k"
            "; type(fval_t), intent(in) :: u"
            "; type(fval_t) :: v; end function",
            "end module fval_m",
        )

    @cached_property
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble (Fortran needs none)."""
        return {}

    @cached_property
    def scalar_body_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar body preamble (Fortran needs none)."""
        return {}

    @cached_property
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )
