from typing import Dict, List, Any, Optional, Union
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
import json
import uuid


class TaskType(Enum):
    PERCEPTION = "perception"
    REASONING = "reasoning"
    DECISION = "decision"
    LEARNING = "learning"
    DIALOGUE = "dialogue"
    COLLABORATION = "collaboration"
    PLANNING = "planning"
    MEMORY = "memory"
    CREATIVITY = "creativity"
    VALUE = "value"


class Confidence(Enum):
    CERTAIN = 1.0
    LIKELY = 0.8
    POSSIBLE = 0.6
    UNCERTAIN = 0.4
    GUESS = 0.2


@dataclass
class UnifiedRequest:
    """统一请求格式"""
    task_type: TaskType
    input: Any
    context: Dict[str, Any] = field(default_factory=dict)
    user_id: Optional[str] = None
    priority: int = 5


@dataclass
class UnifiedResponse:
    """统一响应格式"""
    success: bool
    result: Any
    confidence: float
    explanation: str
    task_type: TaskType
    processing_time: float
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


class UniversalReasoning:
    """
    通用推理模块 (0.70.0)
    能力：统一接口、能力路由、结果融合、异常处理、自我优化
    整合所有0.58-0.69的能力
    """
    
    def __init__(self):
        self.version = "0.70.0"
        self.capabilities = self._init_capabilities()
        self.request_history: List[UnifiedResponse] = []
        self.fallback_strategies = self._init_fallback_strategies()
        
        # 延迟导入各模块
        self._modules = {}
        self._init_modules()
    
    def _init_capabilities(self) -> Dict[str, bool]:
        """初始化能力清单"""
        return {
            "logical_reasoning": True,
            "common_sense": True,
            "decision_reasoning": True,
            "metacognition": True,
            "active_learning": True,
            "error_reflection": True,
            "knowledge_update": True,
            "transfer_learning": True,
            "dialogue": True,
            "swarm": True,
            "human_robot": True,
            "strategy": True,
        }
    
    def _init_fallback_strategies(self) -> Dict:
        """初始化降级策略"""
        return {
            "module_not_available": "使用基础规则替代",
            "timeout": "返回部分结果",
            "low_confidence": "请求用户确认",
            "unknown_task": "尝试通用处理方法",
        }
    
    def _init_modules(self):
        """延迟初始化各模块"""
        try:
            from .logical import LogicalReasoning
            self._modules["logical"] = LogicalReasoning()
        except ImportError:
            self._modules["logical"] = None
        
        try:
            from .common_sense import CommonSense
            self._modules["common_sense"] = CommonSense()
        except ImportError:
            self._modules["common_sense"] = None
        
        try:
            from .decision import DecisionReasoning
            self._modules["decision"] = DecisionReasoning()
        except ImportError:
            self._modules["decision"] = None
        
        try:
            from .metacognition import MetaCognition
            self._modules["metacognition"] = MetaCognition()
        except ImportError:
            self._modules["metacognition"] = None
        
        try:
            from .active_learning import ActiveLearning
            self._modules["active_learning"] = ActiveLearning()
        except ImportError:
            self._modules["active_learning"] = None
        
        try:
            from .error_reflection import ErrorReflection
            self._modules["error_reflection"] = ErrorReflection()
        except ImportError:
            self._modules["error_reflection"] = None
        
        try:
            from .knowledge_update import KnowledgeUpdate
            self._modules["knowledge_update"] = KnowledgeUpdate()
        except ImportError:
            self._modules["knowledge_update"] = None
        
        try:
            from .transfer_learning import TransferLearning
            self._modules["transfer_learning"] = TransferLearning()
        except ImportError:
            self._modules["transfer_learning"] = None
        
        try:
            from .dialogue import DialogueManager
            self._modules["dialogue"] = DialogueManager()
        except ImportError:
            self._modules["dialogue"] = None
        
        try:
            from .swarm import SwarmIntelligence
            self._modules["swarm"] = SwarmIntelligence()
        except ImportError:
            self._modules["swarm"] = None
        
        try:
            from .human_robot import HumanRobotCollaboration
            self._modules["human_robot"] = HumanRobotCollaboration()
        except ImportError:
            self._modules["human_robot"] = None
        
        try:
            from .strategy import StrategyGeneration
            self._modules["strategy"] = StrategyGeneration()
        except ImportError:
            self._modules["strategy"] = None
    
    # ========== 1. 统一入口 ==========
    def reason(self, request: UnifiedRequest) -> UnifiedResponse:
        """
        统一推理入口
        
        参数：
            request: 统一请求
            
        返回：
            统一响应
        """
        import time
        start_time = time.time()
        
        try:
            # 路由到对应能力
            result = self._route(request)
            confidence = self._calculate_confidence(result, request)
            explanation = self._generate_explanation(result, request)
            success = True
            
        except Exception as e:
            result = {"error": str(e)}
            confidence = 0.0
            explanation = self._handle_error(e, request)
            success = False
        
        processing_time = time.time() - start_time
        
        response = UnifiedResponse(
            success=success,
            result=result,
            confidence=confidence,
            explanation=explanation,
            task_type=request.task_type,
            processing_time=processing_time
        )
        
        self.request_history.append(response)
        
        return response
    
    def _route(self, request: UnifiedRequest) -> Any:
        """路由到对应的能力模块"""
        
        if request.task_type == TaskType.PERCEPTION:
            return self._handle_perception(request)
        
        elif request.task_type == TaskType.REASONING:
            return self._handle_reasoning(request)
        
        elif request.task_type == TaskType.DECISION:
            return self._handle_decision(request)
        
        elif request.task_type == TaskType.LEARNING:
            return self._handle_learning(request)
        
        elif request.task_type == TaskType.DIALOGUE:
            return self._handle_dialogue(request)
        
        elif request.task_type == TaskType.COLLABORATION:
            return self._handle_collaboration(request)
        
        elif request.task_type == TaskType.PLANNING:
            return self._handle_planning(request)
        
        elif request.task_type == TaskType.MEMORY:
            return self._handle_memory(request)
        
        elif request.task_type == TaskType.CREATIVITY:
            return self._handle_creativity(request)
        
        elif request.task_type == TaskType.VALUE:
            return self._handle_value(request)
        
        else:
            return self._handle_unknown(request)
    
    # ========== 2. 各能力处理 ==========
    def _handle_perception(self, request: UnifiedRequest) -> Dict:
        """处理感知类任务"""
        input_data = request.input
        
        # 模拟感知处理
        return {
            "type": "perception_result",
            "input": input_data,
            "interpretation": f"感知到: {input_data}",
            "confidence": 0.9
        }
    
    def _handle_reasoning(self, request: UnifiedRequest) -> Dict:
        """处理推理类任务"""
        input_data = request.input
        
        # 优先使用逻辑推理模块
        if self._modules.get("logical"):
            if isinstance(input_data, dict) and "syllogism" in input_data:
                result = self._modules["logical"].syllogism(
                    input_data.get("major", ""),
                    input_data.get("minor", ""),
                    input_data.get("conclusion", "")
                )
                return result
        
        # 使用常识推理
        if self._modules.get("common_sense") and isinstance(input_data, str):
            result = self._modules["common_sense"].daily(input_data)
            return result
        
        return {
            "type": "reasoning_result",
            "input": input_data,
            "conclusion": f"基于已有知识推理: {input_data}",
            "confidence": 0.7
        }
    
    def _handle_decision(self, request: UnifiedRequest) -> Dict:
        """处理决策类任务"""
        input_data = request.input
        
        if self._modules.get("decision"):
            if isinstance(input_data, dict) and "options" in input_data:
                result = self._modules["decision"].compare_options(input_data["options"])
                return result
        
        return {
            "type": "decision_result",
            "input": input_data,
            "decision": "已做出决策",
            "confidence": 0.7
        }
    
    def _handle_learning(self, request: UnifiedRequest) -> Dict:
        """处理学习类任务"""
        input_data = request.input
        
        if self._modules.get("active_learning"):
            if isinstance(input_data, dict) and "question" in input_data:
                result = self._modules["active_learning"].learn_from_answer(
                    input_data.get("question", ""),
                    input_data.get("answer", "")
                )
                return result
        
        return {
            "type": "learning_result",
            "input": input_data,
            "learned": True,
            "message": "已学习新知识"
        }
    
    def _handle_dialogue(self, request: UnifiedRequest) -> Dict:
        """处理对话类任务"""
        input_data = request.input
        
        if self._modules.get("dialogue") and isinstance(input_data, str):
            result = self._modules["dialogue"].generate_response(input_data)
            return result
        
        return {
            "type": "dialogue_result",
            "input": input_data,
            "response": f"收到: {input_data}",
            "confidence": 0.8
        }
    
    def _handle_collaboration(self, request: UnifiedRequest) -> Dict:
        """处理协作类任务"""
        input_data = request.input
        
        if self._modules.get("swarm"):
            if isinstance(input_data, dict) and "task" in input_data:
                task_id = self._modules["swarm"].add_task(
                    input_data["task"],
                    input_data.get("capabilities", ["通用"])
                )
                return {"task_id": task_id, "status": "assigned"}
        
        if self._modules.get("human_robot"):
            if isinstance(input_data, str):
                result = self._modules["human_robot"].understand_instruction(input_data)
                return result
        
        return {
            "type": "collaboration_result",
            "input": input_data,
            "status": "协作处理中"
        }
    
    def _handle_planning(self, request: UnifiedRequest) -> Dict:
        """处理规划类任务"""
        input_data = request.input
        
        if self._modules.get("strategy"):
            if isinstance(input_data, str):
                strategies = self._modules["strategy"].generate_strategy(input_data)
                if strategies:
                    return {
                        "strategies": [s.name for s in strategies],
                        "best": strategies[0].name if strategies else None
                    }
        
        return {
            "type": "planning_result",
            "input": input_data,
            "plan": f"规划完成: {input_data}",
            "steps": ["分析", "执行", "验证"]
        }
    
    def _handle_memory(self, request: UnifiedRequest) -> Dict:
        """处理记忆类任务"""
        input_data = request.input
        
        return {
            "type": "memory_result",
            "input": input_data,
            "memory": "记忆功能已就绪",
            "recalled": None
        }
    
    def _handle_creativity(self, request: UnifiedRequest) -> Dict:
        """处理创造类任务"""
        input_data = request.input
        
        return {
            "type": "creativity_result",
            "input": input_data,
            "ideas": [f"关于{input_data}的新想法"],
            "confidence": 0.6
        }
    
    def _handle_value(self, request: UnifiedRequest) -> Dict:
        """处理价值判断类任务"""
        input_data = request.input
        
        return {
            "type": "value_result",
            "input": input_data,
            "judgment": "基于通用价值观判断",
            "is_good": True,
            "confidence": 0.7
        }
    
    def _handle_unknown(self, request: UnifiedRequest) -> Dict:
        """处理未知任务"""
        return {
            "type": "unknown",
            "input": request.input,
            "suggestion": "无法识别任务类型，请使用明确的任务类型",
            "available_types": [t.value for t in TaskType]
        }
    
    # ========== 3. 辅助方法 ==========
    def _calculate_confidence(self, result: Any, request: UnifiedRequest) -> float:
        """计算置信度"""
        if isinstance(result, dict) and "confidence" in result:
            return result["confidence"]
        return 0.7
    
    def _generate_explanation(self, result: Any, request: UnifiedRequest) -> str:
        """生成解释"""
        return f"处理了{request.task_type.value}任务，结果: {str(result)[:100]}"
    
    def _handle_error(self, error: Exception, request: UnifiedRequest) -> str:
        """处理错误"""
        strategy = self.fallback_strategies.get("module_not_available", "基础处理")
        return f"处理出错: {str(error)}，使用降级策略: {strategy}"
    
    # ========== 4. 便捷方法 ==========
    def reason_text(self, text: str, task_type: str = "reasoning") -> UnifiedResponse:
        """
        便捷方法：直接输入文本
        
        参数：
            text: 输入文本
            task_type: 任务类型
            
        返回：
            统一响应
        """
        task_map = {
            "perception": TaskType.PERCEPTION,
            "reasoning": TaskType.REASONING,
            "decision": TaskType.DECISION,
            "learning": TaskType.LEARNING,
            "dialogue": TaskType.DIALOGUE,
            "collaboration": TaskType.COLLABORATION,
            "planning": TaskType.PLANNING,
        }
        ttype = task_map.get(task_type, TaskType.REASONING)
        
        request = UnifiedRequest(
            task_type=ttype,
            input=text
        )
        return self.reason(request)
    
    def reason_dict(self, data: Dict, task_type: str = "reasoning") -> UnifiedResponse:
        """
        便捷方法：直接输入字典
        
        参数：
            data: 输入字典
            task_type: 任务类型
            
        返回：
            统一响应
        """
        task_map = {
            "perception": TaskType.PERCEPTION,
            "reasoning": TaskType.REASONING,
            "decision": TaskType.DECISION,
            "learning": TaskType.LEARNING,
            "collaboration": TaskType.COLLABORATION,
            "planning": TaskType.PLANNING,
        }
        ttype = task_map.get(task_type, TaskType.REASONING)
        
        request = UnifiedRequest(
            task_type=ttype,
            input=data
        )
        return self.reason(request)
    
    # ========== 5. 能力查询 ==========
    def get_capabilities(self) -> Dict[str, bool]:
        """获取所有可用能力"""
        return self.capabilities
    
    def get_available_modules(self) -> Dict[str, bool]:
        """获取可用模块"""
        return {name: module is not None for name, module in self._modules.items()}
    
    # ========== 6. 统计报告 ==========
    def get_statistics(self) -> Dict:
        """获取统计信息"""
        success_count = sum(1 for r in self.request_history if r.success)
        
        return {
            "version": self.version,
            "total_requests": len(self.request_history),
            "success_rate": success_count / len(self.request_history) if self.request_history else 1.0,
            "avg_confidence": sum(r.confidence for r in self.request_history) / len(self.request_history) if self.request_history else 0,
            "capabilities_count": len([v for v in self.capabilities.values() if v]),
            "modules_loaded": len([v for v in self.get_available_modules().values() if v])
        }
