from typing import Annotated, Literal
from pathlib import Path
import subprocess
import sys
import os

from cyclopts import App, Parameter

from . import __version__
from .get_matrix import read_counts
from .primer_info import get_read_stats
from .summary import summary_stats
from .utils import expand_path_to_list

app = App(help="Foli Tools CLI")
FASTQ_EXTENSIONS = ["fq", "fastq", "fq.gz", "fastq.gz"]
BAM_EXTENSIONS = ["bam", "sam", "sam.gz", "sam.bz2"]


def run(script_name: str, args: tuple) -> None:
    script_path = Path(__file__).parent / "scripts" / script_name
    if not script_path.exists():
        sys.exit(f"ERROR: script not found: {script_path}")
    try:
        subprocess.run(["bash", str(script_path), *list(map(str, args))], check=True)
    except subprocess.CalledProcessError as e:
        sys.exit(
            f"ERROR: Script failed with exit code {e.returncode}\n{e.stderr or ''}"
        )


@app.command(help="Run fastp preprocessing")
def qc(
    *,
    input_: Annotated[
        list[str],
        Parameter(
            consume_multiple=True,
            help="File path, glob pattern, or list of file paths for R1 FASTQ files",
        ),
    ],
    output_dir: Annotated[str, Parameter(help="Output directory for trimmed files")],
    cores: Annotated[int, Parameter(help="Number of cores to use")] = 8,
    skip: Annotated[int, Parameter(help="Number of samples to skip")] = 0,
    delete: Annotated[
        bool, Parameter(help="Delete input files after processing")
    ] = False,
) -> None:
    """
    Run fastp preprocessing.

    Args:
        input_: File path, glob pattern, or list of file paths for R1 FASTQ files.
        output_dir: Output directory for trimmed files.
        cores: Number of CPU cores to allocate for fastp.
    """
    # Expand patterns to actual file paths
    file_paths = expand_path_to_list(input_, suffix=FASTQ_EXTENSIONS)
    # Convert list to space-separated string for shell script
    input_patterns = " ".join(file_paths)
    run(
        f"{os.path.dirname(__file__)}/scripts/foli_01_fastp.sh",
        (input_patterns, output_dir, cores, skip, delete),
    )


@app.command(help="Run cutadapt demultiplexing")
def assign_probes(
    *,
    input_: Annotated[
        list[str],
        Parameter(
            consume_multiple=True,
            help="File path, glob pattern, or list of file paths for R1 FASTQ files",
        ),
    ],
    output_dir: Annotated[str, Parameter(help="Output directory for UMI-tagged files")],
    i5: Annotated[Path, Parameter(help="Path to i5 adapter FASTA file")],
    i7: Annotated[Path, Parameter(help="Path to i7 adapter FASTA file")],
    cores: Annotated[int, Parameter(help="Number of cores to use")] = 8,
    skip: Annotated[int, Parameter(help="Number of samples to skip")] = 0,
    skip_seqkit: Annotated[
        bool, Parameter(help="Skip running seqkit stats on the output directory")
    ] = False,
    delete: Annotated[
        bool, Parameter(help="Delete input files after processing")
    ] = False,
):
    """Run the cutadapt step of the pipeline."""
    # Expand patterns to actual file paths
    file_paths = expand_path_to_list(input_, suffix=FASTQ_EXTENSIONS)
    # Convert list to space-separated string for shell script
    input_patterns = " ".join(file_paths)
    run(
        "foli_02_cutadapt.sh",
        (
            input_patterns,
            output_dir,
            str(i5),
            str(i7),
            str(cores),
            str(skip),
            str(skip_seqkit),
            str(delete),
        ),
    )


@app.command(help="Run mapping step")
def map_(
    *,
    input_: Annotated[
        list[str],
        Parameter(
            consume_multiple=True,
            help="File path, glob pattern, or list of file paths for R1 FASTQ or BAM/SAM files.",
        ),
    ],
    output_bam: Annotated[str, Parameter(help="Output directory for BAM files")],
    output_star: Annotated[
        str | None,
        Parameter(
            help="Output directory for STAR alignment files (required if any FASTQ inputs)"
        ),
    ] = None,
    star_index: Annotated[
        Path | None,
        Parameter(
            "--star-index",
            help="Path to the STAR genome index directory (required if any FASTQ inputs).",
        ),
    ] = None,
    gtf: Annotated[
        Path,
        Parameter(
            "--gtf",
            help="Path to the GTF annotation file for featureCounts.",
        ),
    ],
    cores: Annotated[
        int,
        Parameter(
            "--cores",
            help="Total number of cores to allocate for the pipeline.",
        ),
    ] = 8,
    strand: Annotated[
        Literal[0, 1, 2],
        Parameter(
            "--strand",
            help="Strand specificity for featureCounts (0=unstranded, 1=stranded, 2=reversely stranded). Defaults to 1 because foli-seq is forward-stranded.",
        ),
    ] = 1,
    allow_overlap: Annotated[
        bool,
        Parameter(
            "--allow-overlap",
            help="Allow reads to be assigned to overlapping features (default true). Pass --no-allow-overlap to disable. When enabled, passes -O and --fraction to featureCounts.",
        ),
    ] = True,
    allow_multimapping: Annotated[
        bool,
        Parameter(
            "--allow-multimapping",
            help="Allow multi-mapping reads to be counted (default true). Pass --no-allow-multimapping to disable. When enabled, passes -M and --fraction to featureCounts.",
        ),
    ] = True,
    skip: Annotated[int, Parameter(help="Number of samples to skip")] = 0,
    delete: Annotated[
        bool, Parameter(help="Delete input files after processing")
    ] = False,
):
    """Run the mapping step of the pipeline. Supports both FASTQ (.fq/.fastq/.fq.gz/.fastq.gz) and BAM/SAM inputs. For FASTQ files, includes read filtering to remove short reads (primer dimers) and STAR alignment. For BAM/SAM files, skips alignment and goes directly to featureCounts."""
    # Expand patterns to actual file paths
    file_paths = expand_path_to_list(input_, suffix=FASTQ_EXTENSIONS + BAM_EXTENSIONS)
    # Convert list to space-separated string for shell script
    input_patterns = " ".join(file_paths)
    run(
        "foli_03_map.sh",
        (
            input_patterns,
            output_bam,
            output_star or "",
            str(star_index) if star_index else "",
            str(gtf),
            str(cores),
            str(skip),
            str(delete),
            str(strand),
            str(allow_overlap),
            str(allow_multimapping),
        ),
    )


@app.command(help="Count UMI with umi_tools")
def count(
    *,
    input_: Annotated[
        list[str],
        Parameter(
            consume_multiple=True,
            help="File path, glob pattern, or list of file paths for BAM files",
        ),
    ],
    output_dir: Annotated[str, Parameter(help="Output directory for count results")],
    cores: Annotated[int, Parameter(help="Number of cores to use")] = 8,
    skip: Annotated[int, Parameter(help="Number of samples to skip")] = 0,
):
    """Run the counting step of the pipeline."""
    # Expand patterns to actual file paths
    file_paths = expand_path_to_list(input_, suffix=BAM_EXTENSIONS)
    # Convert list to space-separated string for shell script
    input_patterns = " ".join(file_paths)
    run("foli_04_count.sh", (input_patterns, output_dir, str(cores), str(skip)))


def _separator_for(path: str) -> str:
    if any(path.endswith(ext) for ext in [".tsv", ".txt", ".tsv.gz", ".txt.gz"]):
        return "\t"
    if any(path.endswith(ext) for ext in [".csv", ".csv.gz"]):
        return ","
    raise ValueError(
        f"Output file must end with .tsv, .txt, .tsv.gz, or .txt.gz: {path!r}"
    )


@app.command(help="Generate count matrix")
def get_count_mtx(
    *,
    input_: list[str],
    output: Annotated[
        str | None,
        Parameter(help="Output path for the UMI-deduplicated count matrix"),
    ] = None,
    output_raw: Annotated[
        str | None,
        Parameter(help="Output path for the pre-dedup (raw read count) matrix"),
    ] = None,
    gtf: str | None = None,
) -> None:
    """
    Args:
        input_: A file path, glob pattern, or list of file paths.
        output: Optional output path for the UMI-deduplicated matrix.
        output_raw: Optional output path for the pre-dedup read-count matrix.
        gtf: Optional path to a GTF file for gene_id→gene_symbol mapping.
    """
    if output is None and output_raw is None:
        raise ValueError("At least one of --output or --output-raw must be set")

    if output is not None:
        df = read_counts(input_, gtf, dedup_umi=True)
        df.to_csv(
            output,
            sep=_separator_for(output),
            index_label=f"folitools {__version__}",
            header=True,
        )
    if output_raw is not None:
        df = read_counts(input_, gtf, dedup_umi=False)
        df.to_csv(
            output_raw,
            sep=_separator_for(output_raw),
            index_label=f"folitools {__version__}",
            header=True,
        )


@app.command(help="Aggregate per-sample pipeline-stage read counts")
def summary(
    *,
    output: Annotated[
        str,
        Parameter(help="Output path for the sample × metric table (.tsv/.csv/.txt, .gz ok)"),
    ],
    fastq_stats: Annotated[
        str | None,
        Parameter(help="seqkit --tabular stats file over raw input FASTQs (foli qc input)"),
    ] = None,
    fastp_stats: Annotated[
        str | None,
        Parameter(help="seqkit --tabular stats file over fastp-trimmed FASTQs (foli qc output)"),
    ] = None,
    star_logs: Annotated[
        list[str] | None,
        Parameter(
            consume_multiple=True,
            help="Glob/path/list of STAR Log.final.out files (parent dir name = sample)",
        ),
    ] = None,
    add_tags_logs: Annotated[
        list[str] | None,
        Parameter(
            consume_multiple=True,
            help=(
                "Glob/path/list of foli_add_tags --log files (SUMMARY lines "
                "keyed by cell_tag). Drives not_na_adapter / good_umi / "
                "mapped / assigned / counted / counted_assigned columns."
            ),
        ),
    ] = None,
    group_tsvs: Annotated[
        list[str] | None,
        Parameter(
            consume_multiple=True,
            help=(
                "Glob/path/list of umi_tools group output files "
                "(<sample>.group.tsv.gz). Used only with --strict to "
                "sanity-check counted_depth against the actual TSV row "
                "counts."
            ),
        ),
    ] = None,
    count_matrix_raw: Annotated[
        str | None,
        Parameter(help="Pre-dedup count matrix from foli get-count-mtx --output-raw"),
    ] = None,
    count_matrix_dedup: Annotated[
        str | None,
        Parameter(help="UMI-dedup count matrix from foli get-count-mtx --output"),
    ] = None,
    strict: Annotated[
        bool,
        Parameter(
            "--strict",
            help=(
                "In addition to the always-on DAG check, assert that "
                "counted_depth and counted_assigned_depth from the "
                "add_tags log match the row counts in --group-tsvs and "
                "the row sum of --count-matrix-raw on every sample where "
                "both sources are present."
            ),
        ),
    ] = False,
) -> None:
    """Aggregate per-sample read counts from each pipeline stage into one table.

    Any source left unset yields an all-NA column. Columns form a DAG; each
    edge (parent ≥ child) is asserted on present-value pairs so pipeline
    regressions surface immediately.
    """
    df = summary_stats(
        fastq_stats=fastq_stats,
        fastp_stats=fastp_stats,
        star_logs=star_logs,
        add_tags_logs=add_tags_logs,
        group_tsvs=group_tsvs,
        count_matrix_raw=count_matrix_raw,
        count_matrix_dedup=count_matrix_dedup,
        strict=strict,
    )
    df.to_csv(
        output,
        sep=_separator_for(output),
        index_label=f"folitools {__version__}",
        header=True,
    )


@app.command(help="Get read statistics from FASTQ files after primer assignment")
def get_read_stats_(
    *,
    input_: Annotated[
        list[str],
        Parameter(
            consume_multiple=True,
            help="File path, glob pattern, or list of file paths for R1 FASTQ files",
        ),
    ],
    output_dir: str,
    cores: int = 1,
    overwrite: bool = False,
    skip: Annotated[int, Parameter(help="Number of samples to skip")] = 0,
) -> None:
    """
    Process FASTQ files to extract read statistics and write to parquet files.

    Args:
        input_: A file path, glob pattern, or list of file paths for R1 FASTQ files.
        output_dir: Directory to save the output parquet files.
        cores: Number of CPU cores to use for parallel processing.
        overwrite: If True, overwrite existing parquet files.
    """
    get_read_stats(
        read1_pattern=input_,
        output_dir=output_dir,
        cores=cores,
        overwrite=overwrite,
        skip=skip,
    )


if __name__ == "__main__":
    app()
