# Changelog

## 0.1.0 - 2026-04-25

Initial release.

- Add `ToolGuardMiddleware` for per-tool input validation and output policy processing.
- Add `guard_tool()` for wrapping LangChain tools outside middleware contexts.
- Add URL, path, substring, and string-length input policies.
- Add JSON key redaction, output truncation, and prompt-injection phrase flagging.
- Add hardened URL checks for userinfo, IPs, CIDRs, prefixes, and IDNA hostnames.
- Add optional tainted-output blocking for sensitive later tool calls.
- Add file path helper functions and adversarial tests.
