from urllib.request import urlopen

from langchain_core.tools import tool

from langchain_tool_guard import InputPolicy, ToolPolicy, guard_tool


@tool
def fetch_url(url: str) -> str:
    """Fetch a URL as text."""

    with urlopen(url, timeout=10) as response:
        return response.read().decode("utf-8")


safe_fetch_url = guard_tool(
    fetch_url,
    policy=ToolPolicy(
        input=InputPolicy(
            allowed_domains=["api.github.com"],
            allowed_cidrs=["10.0.0.0/8"],
            allowed_schemes=["https"],
            block_userinfo=True,
        ),
    ),
)
