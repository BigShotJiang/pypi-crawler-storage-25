from langchain_core.tools import tool

from langchain_tool_guard import OutputPolicy, ToolPolicy, guard_tool


@tool
def get_account(account_id: str) -> str:
    """Return account data as JSON."""

    return '{"account_id": "acct_123", "token": "sk-abc123", "name": "Acme"}'


safe_get_account = guard_tool(
    get_account,
    policy=ToolPolicy(
        output=OutputPolicy(redact_keys=["token"]),
    ),
)
