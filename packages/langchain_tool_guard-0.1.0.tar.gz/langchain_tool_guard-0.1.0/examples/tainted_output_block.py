from langchain.agents import create_agent

from langchain_tool_guard import OutputPolicy, ToolGuardMiddleware


def build_agent(model, tools):
    return create_agent(
        model=model,
        tools=tools,
        middleware=[
            ToolGuardMiddleware(
                default_output_policy=OutputPolicy(flag_injection_phrases=True),
                block_tools_after_output_flag=[
                    "send_email",
                    "write_file",
                    "run_shell",
                ],
            )
        ],
    )
