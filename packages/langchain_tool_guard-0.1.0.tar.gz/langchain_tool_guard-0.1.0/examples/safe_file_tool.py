from pathlib import Path

from langchain_core.tools import tool

from langchain_tool_guard import InputPolicy, ToolPolicy, guard_tool


@tool
def read_file(path: str) -> str:
    """Read a text file."""

    return Path(path).read_text(encoding="utf-8")


safe_read_file = guard_tool(
    read_file,
    policy=ToolPolicy(
        input=InputPolicy(
            root_dir="./workspace",
            deny_substrings=[".env", ".ssh", "credentials"],
        ),
    ),
)
