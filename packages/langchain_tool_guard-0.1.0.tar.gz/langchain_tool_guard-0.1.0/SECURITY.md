# Security Notes

`langchain-tool-guard` is a deterministic boundary helper. It reduces common mistakes in tool calls, but it is not a sandbox, not a web security gateway, and not a prompt-injection prevention system.

## Known v0.1 Limitations

- URL validation parses string arguments with `urllib.parse.urlparse`. Nested dict/list scanning is available with `inspect_nested_strings=True`, bounded by `max_nested_depth`, but defaults off to avoid false positives in arbitrary JSON payloads. URL validation blocks embedded userinfo by default, supports exact domains, IPs, CIDR ranges, URL prefixes, and IDNA host normalization.
- Filesystem validation uses `os.path.realpath()` before tool execution. The check and the tool's later file access are not atomic, so time-of-check/time-of-use races are a known limitation. Tool authors can use `resolve_path_under_root()` or `open_text_under_root()` to keep path resolution consistent at the actual file-access boundary.
- Filesystem validation does not expand `~`; a literal tilde path is resolved relative to the current process directory unless the operating system treats it specially.
- Prompt-injection phrase flagging is an English substring heuristic. It catches obvious plain-text phrases across normal whitespace and strips zero-width format characters. Base64 scanning and simple leetspeak normalization are available as opt-in settings because they can add noise on arbitrary tool output. Translated or heavily modified instructions still require custom phrases or a model-based detector.
- Output key redaction only applies to JSON-parseable tool output. It intentionally does not use regex over raw text.
- The tainted-output feature is per middleware instance and resets at the start of each agent run. It is useful for simple workflows, but it is not a full trace policy engine.

The test suite includes adversarial and known-bypass cases to keep these tradeoffs explicit.
