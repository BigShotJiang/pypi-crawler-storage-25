"""Helpers for ToolMessage construction and output policy application."""

from __future__ import annotations

from typing import Any

from langchain.messages import ToolMessage

from langchain_tool_guard.decisions import BoundaryDecision
from langchain_tool_guard.policies import OutputPolicy
from langchain_tool_guard.processors import process_output

DECISIONS_METADATA_KEY = "tool_guard_decisions"


def blocked_tool_message(
    decision: BoundaryDecision, tool_call_id: str | None, tool_name: str
) -> ToolMessage:
    """Build a ToolMessage for a blocked input policy."""

    return ToolMessage(
        content=decision.to_json(),
        tool_call_id=tool_call_id,
        name=tool_name,
        status="error",
        response_metadata={DECISIONS_METADATA_KEY: [decision.to_dict()]},
    )


def blocked_direct_output(
    decision: BoundaryDecision, tool_call_id: str | None, tool_name: str
) -> str | ToolMessage:
    """Return a direct-call block result, preserving ToolMessage when possible."""

    if tool_call_id is None:
        return decision.to_json()
    return blocked_tool_message(decision, tool_call_id, tool_name)


def apply_output_policy_to_message(
    message: ToolMessage, tool: str, policy: OutputPolicy | None
) -> ToolMessage:
    """Apply output policy to a LangChain ToolMessage."""

    if policy is None or message.content is None or message.content == "":
        return message

    result = process_output(tool, policy, message.content)
    if not result.decisions and isinstance(message.content, str):
        return message

    metadata = _with_decisions(message.response_metadata, result.decisions)
    update: dict[str, Any] = {
        "content": result.content,
        "response_metadata": metadata,
    }
    if result.blocked:
        update["status"] = "error"
    return message.model_copy(update=update)


def apply_output_policy_to_direct_result(
    result: Any, tool: str, policy: OutputPolicy | None
) -> Any:
    """Apply output policy to a direct tool wrapper result."""

    if (
        policy is None
        or isinstance(result, ToolMessage)
        or result is None
        or result == ""
    ):
        if isinstance(result, ToolMessage):
            return apply_output_policy_to_message(result, tool, policy)
        return result

    processed = process_output(tool, policy, result)
    if not processed.decisions and isinstance(result, str):
        return result
    return processed.content


def _with_decisions(
    metadata: dict[str, Any], decisions: list[BoundaryDecision]
) -> dict[str, Any]:
    next_metadata = dict(metadata or {})
    existing = list(next_metadata.get(DECISIONS_METADATA_KEY, []))
    existing.extend(decision.to_dict() for decision in decisions)
    next_metadata[DECISIONS_METADATA_KEY] = existing
    return next_metadata
