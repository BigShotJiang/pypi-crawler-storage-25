"""Structured boundary decisions returned by tool guard policies."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from enum import Enum
from typing import Any


class BoundaryAction(str, Enum):
    """Actions a boundary policy can report."""

    ALLOW = "allowed"
    BLOCK = "blocked"
    FLAG = "flagged"


class Boundary(str, Enum):
    """The side of a tool call where a policy ran."""

    INPUT = "input"
    OUTPUT = "output"


@dataclass
class BoundaryDecision:
    """A structured explanation of a tool boundary policy decision."""

    status: BoundaryAction
    tool: str
    boundary: Boundary
    policy: str
    message: str
    suggestion: str | None = None
    details: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable representation of the decision."""

        data = asdict(self)
        data["status"] = self.status.value
        data["boundary"] = self.boundary.value
        return data

    def to_json(self) -> str:
        """Return the decision as stable JSON."""

        return json.dumps(self.to_dict(), ensure_ascii=False, sort_keys=True)
