"""Standalone tool wrapper for non-middleware contexts."""

from __future__ import annotations

from typing import Any

from langchain_core.tools import BaseTool

from langchain_tool_guard._messages import (
    apply_output_policy_to_direct_result,
    blocked_direct_output,
)
from langchain_tool_guard.policies import ToolPolicy
from langchain_tool_guard.validators import validate_input


class GuardedTool(BaseTool):
    """A BaseTool that applies a ToolPolicy around another tool."""

    wrapped_tool: BaseTool
    policy: ToolPolicy

    def run(
        self,
        tool_input: str | dict[str, Any],
        verbose: bool | None = None,
        start_color: str | None = "green",
        color: str | None = "green",
        callbacks: Any = None,
        *,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        run_name: str | None = None,
        run_id: Any = None,
        config: Any = None,
        tool_call_id: str | None = None,
        **kwargs: Any,
    ) -> Any:
        decision = validate_input(self.name, self.policy.input, tool_input)
        if decision is not None:
            return blocked_direct_output(decision, tool_call_id, self.name)

        result = self.wrapped_tool.run(
            tool_input,
            verbose=verbose,
            start_color=start_color,
            color=color,
            callbacks=callbacks,
            tags=tags,
            metadata=metadata,
            run_name=run_name,
            run_id=run_id,
            config=config,
            tool_call_id=tool_call_id,
            **kwargs,
        )
        return apply_output_policy_to_direct_result(
            result, self.name, self.policy.output
        )

    async def arun(
        self,
        tool_input: str | dict,
        verbose: bool | None = None,
        start_color: str | None = "green",
        color: str | None = "green",
        callbacks: Any = None,
        *,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        run_name: str | None = None,
        run_id: Any = None,
        config: Any = None,
        tool_call_id: str | None = None,
        **kwargs: Any,
    ) -> Any:
        decision = validate_input(self.name, self.policy.input, tool_input)
        if decision is not None:
            return blocked_direct_output(decision, tool_call_id, self.name)

        result = await self.wrapped_tool.arun(
            tool_input,
            verbose=verbose,
            start_color=start_color,
            color=color,
            callbacks=callbacks,
            tags=tags,
            metadata=metadata,
            run_name=run_name,
            run_id=run_id,
            config=config,
            tool_call_id=tool_call_id,
            **kwargs,
        )
        return apply_output_policy_to_direct_result(
            result, self.name, self.policy.output
        )

    def _run(self, *args: Any, **kwargs: Any) -> Any:
        return self.run(_tool_input_from_args(args, kwargs))

    async def _arun(self, *args: Any, **kwargs: Any) -> Any:
        return await self.arun(_tool_input_from_args(args, kwargs))


def guard_tool(tool: BaseTool, *, policy: ToolPolicy | None = None) -> GuardedTool:
    """Return a tool that applies boundary checks around another LangChain tool."""

    if not isinstance(tool, BaseTool):
        msg = "guard_tool expects a langchain_core.tools.BaseTool instance"
        raise TypeError(msg)

    return GuardedTool(
        wrapped_tool=tool,
        policy=policy or ToolPolicy(),
        name=tool.name,
        description=tool.description,
        args_schema=tool.args_schema,
        return_direct=tool.return_direct,
        verbose=tool.verbose,
        callbacks=tool.callbacks,
        tags=tool.tags,
        metadata=tool.metadata,
        handle_tool_error=tool.handle_tool_error,
        handle_validation_error=tool.handle_validation_error,
        response_format=tool.response_format,
        extras=getattr(tool, "extras", None),
    )


def _tool_input_from_args(args: tuple[Any, ...], kwargs: dict[str, Any]) -> Any:
    kwargs = {
        key: value
        for key, value in kwargs.items()
        if key not in {"config", "run_manager"}
    }
    if kwargs:
        return kwargs
    if len(args) == 1:
        return args[0]
    if not args:
        return {}
    return {"args": list(args)}
