"""Small filesystem helpers for tool authors."""

from __future__ import annotations

import os
from pathlib import Path
from typing import IO


class PathEscapeError(ValueError):
    """Raised when a path cannot be resolved safely under a root directory."""


def resolve_path_under_root(root_dir: str | os.PathLike[str], path: str) -> Path:
    """Resolve a path under root_dir, rejecting null bytes and root escapes.

    This helper centralizes the same realpath/commonpath check used by the middleware.
    It is deterministic and cross-platform, but file access still is not atomic with
    the check. Use least-privilege directories for sensitive tools.
    """

    if "\x00" in path:
        msg = "Path contains an embedded null byte"
        raise PathEscapeError(msg)

    root = os.path.realpath(os.path.abspath(os.fspath(root_dir)))
    resolved = os.path.realpath(os.path.abspath(os.fspath(path)))
    try:
        common = os.path.commonpath([os.path.normcase(resolved), os.path.normcase(root)])
    except ValueError as exc:
        msg = "Path resolves on a different drive or root"
        raise PathEscapeError(msg) from exc

    if common != os.path.normcase(root):
        msg = "Path resolves outside the configured root directory"
        raise PathEscapeError(msg)

    return Path(resolved)


def open_text_under_root(
    root_dir: str | os.PathLike[str],
    path: str,
    *,
    encoding: str = "utf-8",
) -> IO[str]:
    """Open a text file after resolving it under root_dir."""

    return resolve_path_under_root(root_dir, path).open("r", encoding=encoding)
