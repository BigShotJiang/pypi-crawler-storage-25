"""Policy dataclasses for langchain-tool-guard."""

from __future__ import annotations

import os
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Literal


@dataclass
class InputPolicy:
    """Deterministic validators for tool call arguments."""

    allowed_domains: Sequence[str] | None = None
    allowed_ips: Sequence[str] | None = None
    allowed_cidrs: Sequence[str] | None = None
    allowed_url_prefixes: Sequence[str] | None = None
    allowed_schemes: Sequence[str] | None = None
    allow_subdomains: bool = False
    block_userinfo: bool = True
    root_dir: str | None = None
    path_arg_names: Sequence[str] | None = None
    deny_substrings: Sequence[str] | None = None
    max_string_length: int | None = None
    inspect_nested_strings: bool = False
    max_nested_depth: int = 3
    resolved_root_dir: str | None = field(default=None, init=False, repr=False)

    def __post_init__(self) -> None:
        if self.max_string_length is not None and self.max_string_length < 0:
            msg = "max_string_length must be non-negative"
            raise ValueError(msg)
        if self.max_nested_depth < 0:
            msg = "max_nested_depth must be non-negative"
            raise ValueError(msg)

        if self.root_dir is not None:
            root = os.path.realpath(os.path.abspath(os.fspath(self.root_dir)))
            self.resolved_root_dir = root


@dataclass
class OutputPolicy:
    """Deterministic processors for tool output before it re-enters the agent."""

    redact_keys: Sequence[str] | None = None
    max_output_chars: int | None = None
    flag_injection_phrases: bool | Sequence[str] = False
    on_injection_flag: Literal["flag", "block"] = "flag"
    scan_encoded_injection_phrases: bool = False
    normalize_leetspeak_injection_phrases: bool = False

    def __post_init__(self) -> None:
        if self.max_output_chars is not None and self.max_output_chars < 0:
            msg = "max_output_chars must be non-negative"
            raise ValueError(msg)

        if self.on_injection_flag not in {"flag", "block"}:
            msg = "on_injection_flag must be 'flag' or 'block'"
            raise ValueError(msg)


@dataclass
class ToolPolicy:
    """Input and output policies for one tool."""

    input: InputPolicy | None = None
    output: OutputPolicy | None = None
