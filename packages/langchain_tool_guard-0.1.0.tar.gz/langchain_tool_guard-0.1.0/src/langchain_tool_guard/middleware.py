"""LangChain agent middleware for tool boundary policies."""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable, Mapping
from typing import Any

from langchain.agents.middleware import AgentMiddleware, ModelRequest, ToolCallRequest
from langchain.messages import ToolMessage

from langchain_tool_guard._messages import (
    DECISIONS_METADATA_KEY,
    apply_output_policy_to_message,
    blocked_tool_message,
)
from langchain_tool_guard.decisions import Boundary, BoundaryAction, BoundaryDecision
from langchain_tool_guard.policies import OutputPolicy, ToolPolicy
from langchain_tool_guard.validators import validate_input

logger = logging.getLogger(__name__)


class ToolGuardMiddleware(AgentMiddleware):
    """Validate tool inputs and process tool outputs with per-tool policies."""

    def __init__(
        self,
        *,
        policies: Mapping[str, ToolPolicy] | None = None,
        default_output_policy: OutputPolicy | None = None,
        block_tools_after_output_flag: set[str] | list[str] | tuple[str, ...] | None = None,
        taint_on_output_policies: set[str] | list[str] | tuple[str, ...] = (
            "injection_phrases",
        ),
    ) -> None:
        self.policies = dict(policies or {})
        self.default_output_policy = default_output_policy
        self.block_tools_after_output_flag = set(block_tools_after_output_flag or ())
        self.taint_on_output_policies = set(taint_on_output_policies)
        self._warned_unknown_policies = False
        self._tainted_output_decisions: list[dict[str, Any]] = []

    def before_agent(self, state: Any, runtime: Any) -> None:
        """Reset per-run taint tracking."""

        self._tainted_output_decisions = []

    async def abefore_agent(self, state: Any, runtime: Any) -> None:
        """Async version of before_agent."""

        self._tainted_output_decisions = []

    def wrap_model_call(self, request: ModelRequest, handler: Callable[..., Any]) -> Any:
        """Warn once when configured policies do not match visible tool names."""

        self._warn_for_unknown_policies(getattr(request, "tools", ()))
        return handler(request)

    async def awrap_model_call(
        self, request: ModelRequest, handler: Callable[..., Awaitable[Any]]
    ) -> Any:
        """Async version of wrap_model_call."""

        self._warn_for_unknown_policies(getattr(request, "tools", ()))
        return await handler(request)

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage | Any],
    ) -> ToolMessage | Any:
        """Validate input before execution and process output after execution."""

        blocked = self._validate_request_input(request)
        if blocked is not None:
            return blocked

        result = handler(request)
        return self._process_result(request, result)

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[ToolMessage | Any]],
    ) -> ToolMessage | Any:
        """Async version of wrap_tool_call."""

        blocked = self._validate_request_input(request)
        if blocked is not None:
            return blocked

        result = await handler(request)
        return self._process_result(request, result)

    def _validate_request_input(self, request: ToolCallRequest) -> ToolMessage | None:
        tool_name = _tool_name(request)
        taint_decision = self._tainted_tool_decision(tool_name)
        if taint_decision is not None:
            return blocked_tool_message(
                decision=taint_decision,
                tool_call_id=request.tool_call.get("id"),
                tool_name=tool_name,
            )

        tool_policy = self.policies.get(tool_name)
        if tool_policy is None:
            return None

        decision = validate_input(
            tool_name,
            tool_policy.input,
            request.tool_call.get("args", {}),
        )
        if decision is None:
            return None

        return blocked_tool_message(
            decision=decision,
            tool_call_id=request.tool_call.get("id"),
            tool_name=tool_name,
        )

    def _process_result(self, request: ToolCallRequest, result: ToolMessage | Any) -> Any:
        if not isinstance(result, ToolMessage):
            return result

        tool_name = _tool_name(request)
        output_policy = self._output_policy_for(tool_name)
        processed = apply_output_policy_to_message(result, tool_name, output_policy)
        self._record_taint_from_message(processed)
        return processed

    def _output_policy_for(self, tool_name: str) -> OutputPolicy | None:
        tool_policy = self.policies.get(tool_name)
        if tool_policy is not None and tool_policy.output is not None:
            return tool_policy.output
        return self.default_output_policy

    def _warn_for_unknown_policies(self, tools: object) -> None:
        if self._warned_unknown_policies or not self.policies:
            return

        tool_names = {
            name
            for tool in tools or ()
            if (name := getattr(tool, "name", None)) is not None
        }
        if not tool_names:
            return

        unknown = sorted(set(self.policies) - tool_names)
        if unknown:
            logger.warning(
                "ToolGuardMiddleware policies reference unknown tool(s): %s",
                ", ".join(unknown),
            )
            self._warned_unknown_policies = True

    def _tainted_tool_decision(self, tool_name: str) -> BoundaryDecision | None:
        if not self._tainted_output_decisions:
            return None
        if tool_name not in self.block_tools_after_output_flag:
            return None

        return BoundaryDecision(
            status=BoundaryAction.BLOCK,
            tool=tool_name,
            boundary=Boundary.INPUT,
            policy="tainted_output",
            message="A prior tool output in this agent run was flagged, so this tool is blocked.",
            suggestion="Review the flagged tool output or retry in a fresh run before using sensitive tools.",
            details={"prior_decisions": self._tainted_output_decisions},
        )

    def _record_taint_from_message(self, message: ToolMessage) -> None:
        decisions = message.response_metadata.get(DECISIONS_METADATA_KEY, [])
        for decision in decisions:
            policy = decision.get("policy") if isinstance(decision, dict) else None
            if policy in self.taint_on_output_policies:
                self._tainted_output_decisions.append(decision)


def _tool_name(request: ToolCallRequest) -> str:
    if request.tool is not None:
        return request.tool.name
    return request.tool_call["name"]
