"""Output processing helpers."""

from __future__ import annotations

from dataclasses import dataclass

from langchain_tool_guard.decisions import BoundaryDecision
from langchain_tool_guard.policies import OutputPolicy
from langchain_tool_guard.processors.injection_flag import detect_injection_phrases
from langchain_tool_guard.processors.redact_keys import redact_configured_keys
from langchain_tool_guard.processors.truncate import truncate_output


@dataclass
class OutputProcessingResult:
    """Processed output content and associated decisions."""

    content: str
    decisions: list[BoundaryDecision]
    blocked: bool = False


def process_output(
    tool: str, policy: OutputPolicy | None, content: object
) -> OutputProcessingResult:
    """Apply output processors to string content."""

    content_text = str(content)
    decisions: list[BoundaryDecision] = []

    if policy is None or content_text == "":
        return OutputProcessingResult(content=content_text, decisions=decisions)

    content_text, redaction_decision = redact_configured_keys(tool, policy, content_text)
    if redaction_decision is not None:
        decisions.append(redaction_decision)

    injection_decision = detect_injection_phrases(tool, policy, content_text)
    if injection_decision is not None:
        decisions.append(injection_decision)

    content_text, truncation_decision = truncate_output(tool, policy, content_text)
    if truncation_decision is not None:
        decisions.append(truncation_decision)

    if injection_decision is not None and policy.on_injection_flag == "block":
        return OutputProcessingResult(
            content=injection_decision.to_json(),
            decisions=decisions,
            blocked=True,
        )

    if injection_decision is not None:
        content_text = f"{content_text}\n\n[TOOL GUARD FLAG]\n{injection_decision.to_json()}"

    return OutputProcessingResult(content=content_text, decisions=decisions)


__all__ = ["OutputProcessingResult", "process_output"]
