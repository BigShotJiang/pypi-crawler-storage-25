"""Output truncation."""

from __future__ import annotations

from langchain_tool_guard.decisions import (
    Boundary,
    BoundaryAction,
    BoundaryDecision,
)
from langchain_tool_guard.policies import OutputPolicy


def truncate_output(
    tool: str, policy: OutputPolicy, content: str
) -> tuple[str, BoundaryDecision | None]:
    """Truncate content that exceeds the configured character limit."""

    if policy.max_output_chars is None:
        return content, None

    original_length = len(content)
    if original_length <= policy.max_output_chars:
        return content, None

    suffix = f"[TRUNCATED - original length: {original_length} chars]"
    keep = max(policy.max_output_chars - len(suffix), 0)
    truncated = f"{content[:keep]}{suffix}"
    decision = BoundaryDecision(
        status=BoundaryAction.FLAG,
        tool=tool,
        boundary=Boundary.OUTPUT,
        policy="max_output_chars",
        message="Tool output exceeded the configured maximum length and was truncated.",
        suggestion="Use the truncated output, or call a narrower tool query.",
        details={
            "original_length": original_length,
            "limit": policy.max_output_chars,
        },
    )
    return truncated, decision
