"""Prompt-injection phrase flagging for tool outputs."""

from __future__ import annotations

import base64
import binascii
import re
import unicodedata

from langchain_tool_guard.decisions import (
    Boundary,
    BoundaryAction,
    BoundaryDecision,
)
from langchain_tool_guard.policies import OutputPolicy

DEFAULT_INJECTION_PHRASES = (
    "ignore previous instructions",
    "ignore your instructions",
    "ignore all previous",
    "disregard your system prompt",
    "disregard previous instructions",
    "override your instructions",
    "reveal your prompt",
    "reveal your system",
    "reveal the system prompt",
    "you are now",
    "you must now",
    "new instructions:",
    "system: ",
    "[system]",
    "<system>",
    "assistant: ignore",
)


def detect_injection_phrases(
    tool: str, policy: OutputPolicy, content: str
) -> BoundaryDecision | None:
    """Flag or block obvious prompt-injection-like phrases."""

    phrases = _configured_phrases(policy.flag_injection_phrases)
    if not phrases:
        return None

    normalized_phrases = [
        _normalize_for_matching(
            phrase,
            normalize_leetspeak=policy.normalize_leetspeak_injection_phrases,
        )
        for phrase in phrases
    ]
    normalized_content = _normalize_for_matching(
        content,
        normalize_leetspeak=policy.normalize_leetspeak_injection_phrases,
    )
    matched = _matched_phrases(phrases, normalized_phrases, normalized_content)
    if not matched and policy.scan_encoded_injection_phrases:
        matched = _matched_encoded_phrases(
            content,
            phrases,
            normalized_phrases,
            normalize_leetspeak=policy.normalize_leetspeak_injection_phrases,
        )
    if not matched:
        return None

    status = (
        BoundaryAction.BLOCK
        if policy.on_injection_flag == "block"
        else BoundaryAction.FLAG
    )
    return BoundaryDecision(
        status=status,
        tool=tool,
        boundary=Boundary.OUTPUT,
        policy="injection_phrases",
        message="Tool output contains phrases that may attempt to manipulate the agent.",
        suggestion="Treat this tool output with caution.",
        details={"matched_phrases": matched},
    )


def _configured_phrases(config: bool | list[str] | tuple[str, ...]) -> tuple[str, ...]:
    if config is False:
        return ()
    if config is True:
        return DEFAULT_INJECTION_PHRASES
    return tuple(dict.fromkeys((*DEFAULT_INJECTION_PHRASES, *config)))


def _matched_phrases(
    phrases: tuple[str, ...] | list[str],
    normalized_phrases: list[str],
    normalized_content: str,
) -> list[str]:
    compact_content = _compact_for_matching(normalized_content)
    return [
        phrase
        for phrase, normalized_phrase in zip(phrases, normalized_phrases, strict=True)
        if normalized_phrase in normalized_content
        or _compact_for_matching(normalized_phrase) in compact_content
    ]


def _matched_encoded_phrases(
    content: str,
    phrases: tuple[str, ...],
    normalized_phrases: list[str],
    *,
    normalize_leetspeak: bool,
) -> list[str]:
    for token in _base64_candidates(content):
        decoded = _decode_base64_text(token)
        if decoded is None:
            continue
        matched = _matched_phrases(
            phrases,
            normalized_phrases,
            _normalize_for_matching(
                decoded,
                normalize_leetspeak=normalize_leetspeak,
            ),
        )
        if matched:
            return matched
    return []


def _normalize_for_matching(value: str, *, normalize_leetspeak: bool = False) -> str:
    value = unicodedata.normalize("NFKC", value)
    value = "".join(
        " " if unicodedata.category(character) == "Cf" else character
        for character in value
    )
    value = value.lower()
    if normalize_leetspeak:
        value = value.translate(str.maketrans({"0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t"}))
    return re.sub(r"\s+", " ", value)


def _compact_for_matching(value: str) -> str:
    return re.sub(r"\s+", "", value)


def _base64_candidates(content: str) -> list[str]:
    return re.findall(r"(?<![A-Za-z0-9+/=])[A-Za-z0-9+/]{16,}={0,2}(?![A-Za-z0-9+/=])", content)


def _decode_base64_text(token: str) -> str | None:
    try:
        decoded = base64.b64decode(token, validate=True)
    except (binascii.Error, ValueError):
        return None
    if len(decoded) > 4096:
        return None
    try:
        return decoded.decode("utf-8")
    except UnicodeDecodeError:
        return None
