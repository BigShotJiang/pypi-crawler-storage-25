"""JSON key redaction for tool outputs."""

from __future__ import annotations

import json
from typing import Any

from langchain_tool_guard.decisions import (
    Boundary,
    BoundaryAction,
    BoundaryDecision,
)
from langchain_tool_guard.policies import OutputPolicy

REDACTED = "[REDACTED]"


def redact_configured_keys(
    tool: str, policy: OutputPolicy, content: str
) -> tuple[str, BoundaryDecision | None]:
    """Redact configured keys from JSON-parseable output."""

    keys = set(policy.redact_keys or ())
    if not keys:
        return content, None

    try:
        parsed = json.loads(content)
    except json.JSONDecodeError:
        return content, None

    redacted_keys: set[str] = set()
    redacted = _redact(parsed, keys, redacted_keys)
    if not redacted_keys:
        return content, None

    decision = BoundaryDecision(
        status=BoundaryAction.FLAG,
        tool=tool,
        boundary=Boundary.OUTPUT,
        policy="redact_keys",
        message="Tool output JSON contained configured keys and their values were redacted.",
        suggestion="Use the redacted structure; do not rely on removed secret values.",
        details={"redacted_keys": sorted(redacted_keys)},
    )
    return json.dumps(redacted, ensure_ascii=False), decision


def _redact(value: Any, keys: set[str], redacted_keys: set[str]) -> Any:
    if isinstance(value, dict):
        result = {}
        for key, child in value.items():
            if key in keys:
                result[key] = REDACTED
                redacted_keys.add(key)
            else:
                result[key] = _redact(child, keys, redacted_keys)
        return result

    if isinstance(value, list):
        return [_redact(item, keys, redacted_keys) for item in value]

    return value
