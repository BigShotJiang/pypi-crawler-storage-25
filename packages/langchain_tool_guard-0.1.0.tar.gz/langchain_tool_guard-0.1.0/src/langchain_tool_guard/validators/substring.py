"""Denied substring validation."""

from __future__ import annotations

import unicodedata

from langchain_tool_guard.decisions import (
    Boundary,
    BoundaryAction,
    BoundaryDecision,
)
from langchain_tool_guard.policies import InputPolicy


def validate_deny_substrings(
    tool: str, policy: InputPolicy, tool_input: object
) -> BoundaryDecision | None:
    """Block string arguments containing configured substrings."""

    from langchain_tool_guard.validators import iter_policy_strings

    denied = [_normalize(value) for value in policy.deny_substrings or ()]
    if not denied:
        return None

    for argument, value in iter_policy_strings(policy, tool_input):
        normalized_value = _normalize(value)
        for substring in denied:
            if substring in normalized_value:
                return BoundaryDecision(
                    status=BoundaryAction.BLOCK,
                    tool=tool,
                    boundary=Boundary.INPUT,
                    policy="deny_substrings",
                    message="Tool argument contains a denied substring.",
                    suggestion="Remove the denied content before calling this tool.",
                    details={"argument": argument, "matched_substring": substring},
                )

    return None


def _normalize(value: str) -> str:
    return unicodedata.normalize("NFC", value).lower()
