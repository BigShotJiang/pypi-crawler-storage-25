"""Input validation helpers."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from langchain_tool_guard.decisions import BoundaryDecision
from langchain_tool_guard.policies import InputPolicy
from langchain_tool_guard.validators.length import validate_max_string_length
from langchain_tool_guard.validators.path import validate_root_dir
from langchain_tool_guard.validators.substring import validate_deny_substrings
from langchain_tool_guard.validators.url import validate_url_allowlist


def iter_top_level_strings(tool_input: Any) -> Iterable[tuple[str | None, str]]:
    """Yield top-level string values from a LangChain tool input."""

    if isinstance(tool_input, str):
        yield None, tool_input
        return

    if isinstance(tool_input, dict):
        for key, value in tool_input.items():
            if isinstance(value, str):
                yield str(key), value


def iter_policy_strings(
    policy: InputPolicy, tool_input: Any
) -> Iterable[tuple[str | None, str]]:
    """Yield strings according to the policy's traversal mode."""

    if not policy.inspect_nested_strings:
        yield from iter_top_level_strings(tool_input)
        return

    yield from _iter_nested_strings(tool_input, None, policy.max_nested_depth)


def _iter_nested_strings(
    value: Any, path: str | None, depth_remaining: int
) -> Iterable[tuple[str | None, str]]:
    if isinstance(value, str):
        yield path, value
        return

    if depth_remaining <= 0:
        return

    if isinstance(value, dict):
        for key, child in value.items():
            child_path = str(key) if path is None else f"{path}.{key}"
            yield from _iter_nested_strings(child, child_path, depth_remaining - 1)
        return

    if isinstance(value, (list, tuple)):
        for index, child in enumerate(value):
            child_path = str(index) if path is None else f"{path}.{index}"
            yield from _iter_nested_strings(child, child_path, depth_remaining - 1)


def validate_input(
    tool: str, policy: InputPolicy | None, tool_input: Any
) -> BoundaryDecision | None:
    """Return the first blocking input decision, if any."""

    if policy is None:
        return None

    validators = (
        validate_url_allowlist,
        validate_root_dir,
        validate_deny_substrings,
        validate_max_string_length,
    )
    for validator in validators:
        decision = validator(tool, policy, tool_input)
        if decision is not None:
            return decision
    return None


__all__ = ["iter_policy_strings", "iter_top_level_strings", "validate_input"]
