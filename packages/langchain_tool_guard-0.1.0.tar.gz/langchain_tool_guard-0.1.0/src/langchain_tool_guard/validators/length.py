"""Max string length validation."""

from __future__ import annotations

from langchain_tool_guard.decisions import (
    Boundary,
    BoundaryAction,
    BoundaryDecision,
)
from langchain_tool_guard.policies import InputPolicy


def validate_max_string_length(
    tool: str, policy: InputPolicy, tool_input: object
) -> BoundaryDecision | None:
    """Block string arguments longer than the configured limit."""

    from langchain_tool_guard.validators import iter_policy_strings

    if policy.max_string_length is None:
        return None

    for argument, value in iter_policy_strings(policy, tool_input):
        actual_length = len(value)
        if actual_length > policy.max_string_length:
            return BoundaryDecision(
                status=BoundaryAction.BLOCK,
                tool=tool,
                boundary=Boundary.INPUT,
                policy="max_string_length",
                message="Tool argument exceeds the configured maximum length.",
                suggestion=f"Shorten the argument to {policy.max_string_length} characters or fewer.",
                details={
                    "argument": argument,
                    "actual_length": actual_length,
                    "limit": policy.max_string_length,
                },
            )

    return None
