"""Filesystem root restriction validation."""

from __future__ import annotations

import os

from langchain_tool_guard.decisions import (
    Boundary,
    BoundaryAction,
    BoundaryDecision,
)
from langchain_tool_guard.policies import InputPolicy

PATH_ARGUMENT_NAMES = {
    "path",
    "file",
    "filepath",
    "file_path",
    "filename",
    "dir",
    "directory",
    "folder",
    "root",
    "target_file",
    "target_path",
}


def validate_root_dir(
    tool: str, policy: InputPolicy, tool_input: object
) -> BoundaryDecision | None:
    """Validate path-like arguments against an allowed root directory."""

    from langchain_tool_guard.validators import iter_top_level_strings

    if policy.resolved_root_dir is None:
        return None

    root = policy.resolved_root_dir
    path_arg_names = {
        name.lower()
        for name in (
            PATH_ARGUMENT_NAMES if policy.path_arg_names is None else policy.path_arg_names
        )
    }
    for argument, value in iter_top_level_strings(tool_input):
        if argument is not None and argument.lower() not in path_arg_names:
            continue

        if "\x00" in value:
            return BoundaryDecision(
                status=BoundaryAction.BLOCK,
                tool=tool,
                boundary=Boundary.INPUT,
                policy="root_dir",
                message="Path contains an embedded null byte and cannot be safely resolved.",
                suggestion=f"Use a valid path inside {policy.root_dir}.",
                details={
                    "argument": argument,
                    "path": value,
                    "root_dir": root,
                    "error": "embedded null byte",
                },
            )

        try:
            resolved_path = os.path.realpath(os.path.abspath(os.fspath(value)))
        except (OSError, ValueError) as exc:
            return BoundaryDecision(
                status=BoundaryAction.BLOCK,
                tool=tool,
                boundary=Boundary.INPUT,
                policy="root_dir",
                message="Path could not be safely resolved against the configured root directory.",
                suggestion=f"Use a valid path inside {policy.root_dir}.",
                details={
                    "argument": argument,
                    "path": value,
                    "root_dir": root,
                    "error": str(exc),
                },
            )

        if not _is_within_root(resolved_path, root):
            return BoundaryDecision(
                status=BoundaryAction.BLOCK,
                tool=tool,
                boundary=Boundary.INPUT,
                policy="root_dir",
                message="Path resolves outside the configured root directory.",
                suggestion=f"Use a path inside {policy.root_dir}.",
                details={
                    "argument": argument,
                    "resolved_path": resolved_path,
                    "root_dir": root,
                },
            )

    return None


def _is_within_root(path: str, root: str) -> bool:
    try:
        common = os.path.commonpath([os.path.normcase(path), os.path.normcase(root)])
    except ValueError:
        return False
    return common == os.path.normcase(root)
