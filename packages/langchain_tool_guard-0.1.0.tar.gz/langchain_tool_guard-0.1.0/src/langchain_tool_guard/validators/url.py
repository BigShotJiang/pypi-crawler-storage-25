"""URL domain and scheme allowlist validation."""

from __future__ import annotations

import ipaddress
from urllib.parse import urlparse

from langchain_tool_guard.decisions import (
    Boundary,
    BoundaryAction,
    BoundaryDecision,
)
from langchain_tool_guard.policies import InputPolicy


def validate_url_allowlist(
    tool: str, policy: InputPolicy, tool_input: object
) -> BoundaryDecision | None:
    """Validate URL-like string arguments against configured allowlists."""

    from langchain_tool_guard.validators import iter_policy_strings

    allowed_schemes = {scheme.lower() for scheme in policy.allowed_schemes or ()}
    allowed_domains = {
        _canonicalize_host(domain) for domain in policy.allowed_domains or ()
    }
    allowed_ips = {ipaddress.ip_address(address) for address in policy.allowed_ips or ()}
    allowed_networks = [
        ipaddress.ip_network(network, strict=False)
        for network in policy.allowed_cidrs or ()
    ]
    allowed_prefixes = tuple(policy.allowed_url_prefixes or ())

    if not (
        allowed_schemes
        or allowed_domains
        or allowed_ips
        or allowed_networks
        or allowed_prefixes
    ):
        return None

    for argument, value in iter_policy_strings(policy, tool_input):
        parsed = urlparse(value)
        if not parsed.scheme:
            continue

        if policy.block_userinfo and (parsed.username or parsed.password):
            return BoundaryDecision(
                status=BoundaryAction.BLOCK,
                tool=tool,
                boundary=Boundary.INPUT,
                policy="url_userinfo",
                message="URL contains embedded userinfo credentials.",
                suggestion="Remove credentials from the URL and pass them through a safer channel.",
                details={"argument": argument},
            )

        scheme = parsed.scheme.lower()
        if allowed_schemes and scheme not in allowed_schemes:
            return BoundaryDecision(
                status=BoundaryAction.BLOCK,
                tool=tool,
                boundary=Boundary.INPUT,
                policy="allowed_schemes",
                message="URL scheme is not allowed for this tool.",
                suggestion=f"Use one of: {', '.join(sorted(allowed_schemes))}.",
                details={
                    "argument": argument,
                    "scheme": parsed.scheme,
                    "allowed_schemes": sorted(allowed_schemes),
                },
            )

        if allowed_prefixes and not value.startswith(allowed_prefixes):
            return BoundaryDecision(
                status=BoundaryAction.BLOCK,
                tool=tool,
                boundary=Boundary.INPUT,
                policy="allowed_url_prefixes",
                message="URL does not start with an allowed prefix.",
                suggestion=f"Use one of: {', '.join(sorted(allowed_prefixes))}.",
                details={
                    "argument": argument,
                    "allowed_url_prefixes": sorted(allowed_prefixes),
                },
            )

        hostname = _canonicalize_host(parsed.hostname) if parsed.hostname else None
        if _host_policy_configured(allowed_domains, allowed_ips, allowed_networks) and (
            hostname is None
            or not _host_allowed(
                hostname,
                allowed_domains,
                allowed_ips,
                allowed_networks,
                policy.allow_subdomains,
            )
        ):
            return BoundaryDecision(
                status=BoundaryAction.BLOCK,
                tool=tool,
                boundary=Boundary.INPUT,
                policy=_host_policy_name(allowed_ips, allowed_networks),
                message="URL host is not allowed for this tool.",
                suggestion="Use a configured allowed domain, IP address, or CIDR range.",
                details={
                    "argument": argument,
                    "host": hostname,
                    "domain": hostname,
                    "allowed_domains": sorted(allowed_domains),
                    "allowed_ips": sorted(str(address) for address in allowed_ips),
                    "allowed_cidrs": sorted(str(network) for network in allowed_networks),
                    "allow_subdomains": policy.allow_subdomains,
                },
            )

    return None


def _domain_allowed(
    hostname: str, allowed_domains: set[str], allow_subdomains: bool
) -> bool:
    for domain in allowed_domains:
        if hostname == domain:
            return True
        if allow_subdomains and hostname.endswith(f".{domain}"):
            return True
    return False


def _host_policy_configured(
    allowed_domains: set[str],
    allowed_ips: set[ipaddress.IPv4Address | ipaddress.IPv6Address],
    allowed_networks: list[ipaddress.IPv4Network | ipaddress.IPv6Network],
) -> bool:
    return bool(allowed_domains or allowed_ips or allowed_networks)


def _host_policy_name(
    allowed_ips: set[ipaddress.IPv4Address | ipaddress.IPv6Address],
    allowed_networks: list[ipaddress.IPv4Network | ipaddress.IPv6Network],
) -> str:
    if allowed_ips or allowed_networks:
        return "allowed_hosts"
    return "allowed_domains"


def _host_allowed(
    hostname: str,
    allowed_domains: set[str],
    allowed_ips: set[ipaddress.IPv4Address | ipaddress.IPv6Address],
    allowed_networks: list[ipaddress.IPv4Network | ipaddress.IPv6Network],
    allow_subdomains: bool,
) -> bool:
    try:
        address = ipaddress.ip_address(hostname)
    except ValueError:
        return _domain_allowed(hostname, allowed_domains, allow_subdomains)

    if address in allowed_ips:
        return True
    if str(address) in allowed_domains:
        return True
    return any(address in network for network in allowed_networks)


def _canonicalize_host(hostname: str | None) -> str:
    if hostname is None:
        return ""
    hostname = hostname.rstrip(".").lower()
    try:
        return hostname.encode("idna").decode("ascii")
    except UnicodeError:
        return hostname
