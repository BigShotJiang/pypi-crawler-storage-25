from langchain_tool_guard.policies import InputPolicy
from langchain_tool_guard.validators import validate_input


def test_max_string_length_blocks_long_argument():
    decision = validate_input(
        "tool",
        InputPolicy(max_string_length=4),
        {"query": "abcde"},
    )

    assert decision is not None
    assert decision.policy == "max_string_length"
    assert decision.details == {"argument": "query", "actual_length": 5, "limit": 4}


def test_max_string_length_is_per_argument():
    assert (
        validate_input(
            "tool",
            InputPolicy(max_string_length=4),
            {"left": "abcd", "right": "wxyz"},
        )
        is None
    )


def test_input_policy_rejects_negative_length():
    try:
        InputPolicy(max_string_length=-1)
    except ValueError as exc:
        assert "max_string_length" in str(exc)
    else:
        raise AssertionError("expected ValueError")


def test_max_string_length_allows_exact_boundary():
    assert (
        validate_input("tool", InputPolicy(max_string_length=5), {"query": "abcde"})
        is None
    )


def test_max_string_length_allows_one_below_boundary():
    assert (
        validate_input("tool", InputPolicy(max_string_length=5), {"query": "abcd"})
        is None
    )


def test_max_string_length_nested_string_can_be_validated_when_enabled():
    decision = validate_input(
        "tool",
        InputPolicy(max_string_length=3, inspect_nested_strings=True),
        {"payload": ["abcd"]},
    )

    assert decision is not None
    assert decision.details["argument"] == "payload.0"
