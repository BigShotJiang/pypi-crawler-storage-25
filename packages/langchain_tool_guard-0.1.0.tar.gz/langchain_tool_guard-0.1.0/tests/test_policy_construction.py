import json

from langchain_tool_guard import (
    Boundary,
    BoundaryAction,
    BoundaryDecision,
    InputPolicy,
    ToolPolicy,
)


def test_boundary_decision_serializes_lowercase_values():
    decision = BoundaryDecision(
        status=BoundaryAction.BLOCK,
        tool="read_file",
        boundary=Boundary.INPUT,
        policy="root_dir",
        message="blocked",
    )

    parsed = json.loads(decision.to_json())

    assert parsed["status"] == "blocked"
    assert parsed["boundary"] == "input"


def test_empty_tool_policy_is_inert():
    policy = ToolPolicy()

    assert policy.input is None
    assert policy.output is None


def test_input_policy_rejects_negative_nested_depth():
    try:
        InputPolicy(max_nested_depth=-1)
    except ValueError as exc:
        assert "max_nested_depth" in str(exc)
    else:
        raise AssertionError("expected ValueError")
