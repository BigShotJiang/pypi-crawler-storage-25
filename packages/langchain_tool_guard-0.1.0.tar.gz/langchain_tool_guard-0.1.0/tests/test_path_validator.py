import os

import pytest

from langchain_tool_guard.policies import InputPolicy
from langchain_tool_guard.validators import validate_input


def test_path_allows_named_path_inside_root(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()
    target = root / "notes.txt"
    target.write_text("ok")

    assert (
        validate_input("read_file", InputPolicy(root_dir=str(root)), {"path": str(target)})
        is None
    )


def test_path_blocks_traversal_outside_root(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()
    outside = tmp_path / "secret.txt"
    outside.write_text("no")

    decision = validate_input(
        "read_file",
        InputPolicy(root_dir=str(root)),
        {"path": str(root / ".." / outside.name)},
    )

    assert decision is not None
    assert decision.policy == "root_dir"
    assert decision.details["resolved_path"] == os.path.realpath(outside)


def test_path_uses_named_argument_convention(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()

    assert (
        validate_input(
            "search",
            InputPolicy(root_dir=str(root)),
            {"query": str(tmp_path / "outside.txt")},
        )
        is None
    )


def test_path_arg_names_can_be_configured(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()
    outside = tmp_path / "outside.txt"

    decision = validate_input(
        "read_file",
        InputPolicy(root_dir=str(root), path_arg_names=["source"]),
        {"source": str(outside)},
    )

    assert decision is not None
    assert decision.policy == "root_dir"


def test_configured_path_arg_names_override_default_names(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()

    assert (
        validate_input(
            "read_file",
            InputPolicy(root_dir=str(root), path_arg_names=["source"]),
            {"path": str(tmp_path / "outside.txt")},
        )
        is None
    )


def test_path_resolves_relative_root_from_cwd(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    root = tmp_path / "workspace"
    root.mkdir()
    target = root / "notes.txt"
    target.write_text("ok")

    assert (
        validate_input(
            "read_file",
            InputPolicy(root_dir="workspace"),
            {"path": "workspace/notes.txt"},
        )
        is None
    )


def test_path_single_string_wrapper_input_is_path(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()
    outside = tmp_path / "secret.txt"
    outside.write_text("no")

    decision = validate_input("read_file", InputPolicy(root_dir=str(root)), str(outside))

    assert decision is not None
    assert decision.policy == "root_dir"


def test_path_blocks_symlink_escape(tmp_path):
    root = tmp_path / "workspace"
    outside = tmp_path / "outside"
    root.mkdir()
    outside.mkdir()
    outside_target = outside / "secret.txt"
    outside_target.write_text("no")
    link = root / "link.txt"
    try:
        link.symlink_to(outside_target)
    except OSError as exc:
        pytest.skip(f"symlink creation unavailable: {exc}")

    decision = validate_input("read_file", InputPolicy(root_dir=str(root)), {"path": str(link)})

    assert decision is not None
    assert decision.policy == "root_dir"


def test_path_blocks_parent_traversal_string(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()

    decision = validate_input(
        "read_file",
        InputPolicy(root_dir=str(root)),
        {"path": "../../etc/passwd"},
    )

    assert decision is not None
    assert decision.policy == "root_dir"


def test_path_blocks_traversal_that_starts_inside_root_then_escapes(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()

    decision = validate_input(
        "read_file",
        InputPolicy(root_dir=str(root)),
        {"path": str(root / ".." / ".." / "etc" / "passwd")},
    )

    assert decision is not None
    assert decision.policy == "root_dir"


def test_path_blocks_absolute_path_outside_root(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()
    outside = tmp_path / "outside.txt"

    decision = validate_input(
        "read_file",
        InputPolicy(root_dir=str(root)),
        {"file_path": str(outside)},
    )

    assert decision is not None
    assert decision.policy == "root_dir"


@pytest.mark.skipif(os.name != "nt", reason="Windows separator behavior is platform native")
def test_path_blocks_windows_style_traversal_on_windows(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()

    decision = validate_input(
        "read_file",
        InputPolicy(root_dir=str(root)),
        {"path": str(root) + "\\..\\..\\etc\\passwd"},
    )

    assert decision is not None
    assert decision.policy == "root_dir"


def test_path_blocks_null_byte_path(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()

    decision = validate_input(
        "read_file",
        InputPolicy(root_dir=str(root)),
        {"path": f"{root}{os.sep}\x00{os.sep}..{os.sep}etc{os.sep}passwd"},
    )

    assert decision is not None
    assert decision.policy == "root_dir"


def test_path_allows_trailing_space_inside_root(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()

    assert (
        validate_input(
            "read_file",
            InputPolicy(root_dir=str(root)),
            {"path": str(root / "notes ")},
        )
        is None
    )


def test_path_allows_unicode_dot_lookalikes_inside_root(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()

    assert (
        validate_input(
            "read_file",
            InputPolicy(root_dir=str(root)),
            {"path": str(root / "．．" / "file.txt")},
        )
        is None
    )


def test_path_blocks_symlink_chain_escape(tmp_path):
    root = tmp_path / "workspace"
    outside = tmp_path / "outside"
    root.mkdir()
    outside.mkdir()
    outside_target = outside / "secret.txt"
    outside_target.write_text("no")
    link_two = root / "link-two.txt"
    link_one = root / "link-one.txt"
    try:
        link_two.symlink_to(outside_target)
        link_one.symlink_to(link_two)
    except OSError as exc:
        pytest.skip(f"symlink creation unavailable: {exc}")

    decision = validate_input(
        "read_file", InputPolicy(root_dir=str(root)), {"path": str(link_one)}
    )

    assert decision is not None
    assert decision.policy == "root_dir"


def test_path_literal_tilde_is_not_expanded(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    root = tmp_path / "workspace"
    root.mkdir()

    decision = validate_input(
        "read_file",
        InputPolicy(root_dir=str(root)),
        {"path": "~/secret.txt"},
    )

    assert decision is not None
    assert decision.policy == "root_dir"


def test_path_allows_dot_components_inside_root(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()

    assert (
        validate_input(
            "read_file",
            InputPolicy(root_dir=str(root)),
            {"path": str(root / "." / "nested" / "." / "file.txt")},
        )
        is None
    )


def test_path_blocks_dot_components_that_escape_root(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()

    decision = validate_input(
        "read_file",
        InputPolicy(root_dir=str(root)),
        {"path": str(root / "." / ".." / ".." / "etc" / "passwd")},
    )

    assert decision is not None
    assert decision.policy == "root_dir"
