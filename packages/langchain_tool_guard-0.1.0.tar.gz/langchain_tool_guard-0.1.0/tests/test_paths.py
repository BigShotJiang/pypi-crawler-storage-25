import pytest

from langchain_tool_guard import (
    PathEscapeError,
    open_text_under_root,
    resolve_path_under_root,
)


def test_resolve_path_under_root_allows_inside_path(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()
    target = root / "notes.txt"
    target.write_text("ok", encoding="utf-8")

    assert resolve_path_under_root(root, str(target)) == target.resolve()


def test_resolve_path_under_root_blocks_escape(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()
    outside = tmp_path / "secret.txt"

    with pytest.raises(PathEscapeError):
        resolve_path_under_root(root, str(outside))


def test_resolve_path_under_root_blocks_null_byte(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()

    with pytest.raises(PathEscapeError):
        resolve_path_under_root(root, str(root) + "\x00")


def test_open_text_under_root_reads_inside_file(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()
    target = root / "notes.txt"
    target.write_text("ok", encoding="utf-8")

    with open_text_under_root(root, str(target)) as file:
        assert file.read() == "ok"
