from langchain_tool_guard.policies import InputPolicy
from langchain_tool_guard.validators import validate_input


def test_deny_substrings_blocks_case_insensitively():
    decision = validate_input(
        "read_file",
        InputPolicy(deny_substrings=[".ENV"]),
        {"path": "configs/.env"},
    )

    assert decision is not None
    assert decision.policy == "deny_substrings"
    assert decision.details["matched_substring"] == ".env"


def test_deny_substrings_normalizes_unicode_to_nfc():
    decomposed_e_acute = "e\u0301"

    decision = validate_input(
        "tool",
        InputPolicy(deny_substrings=["é"]),
        {"value": decomposed_e_acute},
    )

    assert decision is not None
    assert decision.policy == "deny_substrings"


def test_deny_substrings_skips_non_strings():
    assert (
        validate_input(
            "tool",
            InputPolicy(deny_substrings=["secret"]),
            {"count": 3, "nested": {"value": "secret"}},
        )
        is None
    )


def test_deny_substrings_matches_inside_longer_word():
    decision = validate_input(
        "tool",
        InputPolicy(deny_substrings=["credentials"]),
        {"path": "credentials_backup.json"},
    )

    assert decision is not None
    assert decision.policy == "deny_substrings"


def test_deny_substrings_empty_deny_list_is_inert():
    assert validate_input("tool", InputPolicy(deny_substrings=[]), {"path": ".env"}) is None


def test_deny_substrings_empty_argument_is_inert():
    assert (
        validate_input("tool", InputPolicy(deny_substrings=[".env"]), {"path": ""})
        is None
    )


def test_deny_substrings_exact_argument_match():
    decision = validate_input(
        "tool",
        InputPolicy(deny_substrings=["credentials"]),
        {"path": "credentials"},
    )

    assert decision is not None
    assert decision.details["matched_substring"] == "credentials"


def test_deny_substrings_nested_string_can_be_validated_when_enabled():
    decision = validate_input(
        "tool",
        InputPolicy(deny_substrings=["secret"], inspect_nested_strings=True),
        {"payload": {"note": "secret"}},
    )

    assert decision is not None
    assert decision.details["argument"] == "payload.note"
