from langchain_tool_guard.policies import OutputPolicy
from langchain_tool_guard.processors import process_output


def test_truncate_appends_original_length_suffix():
    result = process_output("tool", OutputPolicy(max_output_chars=20), "x" * 50)

    assert "[TRUNCATED - original length: 50 chars]" in result.content
    assert result.decisions[0].policy == "max_output_chars"
    assert result.decisions[0].details == {"original_length": 50, "limit": 20}


def test_truncate_preserves_output_under_limit():
    result = process_output("tool", OutputPolicy(max_output_chars=5), "hello")

    assert result.content == "hello"
    assert result.decisions == []


def test_output_policy_rejects_negative_limit():
    try:
        OutputPolicy(max_output_chars=-1)
    except ValueError as exc:
        assert "max_output_chars" in str(exc)
    else:
        raise AssertionError("expected ValueError")


def test_truncate_allows_exact_boundary():
    result = process_output("tool", OutputPolicy(max_output_chars=5), "abcde")

    assert result.content == "abcde"
    assert result.decisions == []


def test_truncate_blocks_one_above_boundary():
    result = process_output("tool", OutputPolicy(max_output_chars=5), "abcdef")

    assert result.content == "[TRUNCATED - original length: 6 chars]"
    assert result.decisions[0].policy == "max_output_chars"
