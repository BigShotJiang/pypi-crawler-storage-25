import pytest

from langchain_tool_guard.policies import InputPolicy
from langchain_tool_guard.validators import validate_input


def test_url_allows_configured_scheme_and_domain():
    policy = InputPolicy(
        allowed_domains=["api.github.com"],
        allowed_schemes=["https"],
    )

    assert (
        validate_input(
            "fetch_url", policy, {"url": "https://api.github.com/repos/octocat/hello"}
        )
        is None
    )


def test_url_blocks_unconfigured_scheme():
    policy = InputPolicy(allowed_schemes=["https"])

    decision = validate_input("fetch_url", policy, {"url": "http://api.github.com"})

    assert decision is not None
    assert decision.status.value == "blocked"
    assert decision.policy == "allowed_schemes"
    assert decision.details["scheme"] == "http"


def test_url_blocks_unconfigured_domain():
    policy = InputPolicy(allowed_domains=["api.github.com"])

    decision = validate_input("fetch_url", policy, {"url": "https://example.com"})

    assert decision is not None
    assert decision.policy == "allowed_domains"
    assert decision.details["domain"] == "example.com"


def test_url_exact_domain_matching_by_default():
    policy = InputPolicy(allowed_domains=["github.com"])

    decision = validate_input("fetch_url", policy, {"url": "https://api.github.com"})

    assert decision is not None
    assert decision.policy == "allowed_domains"


def test_url_allows_subdomains_when_configured():
    policy = InputPolicy(allowed_domains=["github.com"], allow_subdomains=True)

    assert validate_input("fetch_url", policy, {"url": "https://api.github.com"}) is None


def test_url_skips_strings_without_url_scheme():
    policy = InputPolicy(allowed_domains=["api.github.com"])

    assert validate_input("fetch_url", policy, {"query": "api.github.com/repos"}) is None


def test_url_nested_string_is_skipped_by_default():
    policy = InputPolicy(allowed_domains=["api.github.com"])

    assert (
        validate_input(
            "fetch_url",
            policy,
            {"payload": {"url": "https://evil.com"}},
        )
        is None
    )


def test_url_nested_string_can_be_validated_when_enabled():
    policy = InputPolicy(
        allowed_domains=["api.github.com"],
        inspect_nested_strings=True,
    )

    decision = validate_input(
        "fetch_url",
        policy,
        {"payload": {"url": "https://evil.com"}},
    )

    assert decision is not None
    assert decision.details["argument"] == "payload.url"


def test_url_allows_exact_domain_with_port_number():
    policy = InputPolicy(
        allowed_domains=["api.github.com"],
        allowed_schemes=["https"],
    )

    assert (
        validate_input("fetch_url", policy, {"url": "https://api.github.com:443/repos"})
        is None
    )


def test_url_auth_credentials_do_not_confuse_hostname():
    policy = InputPolicy(allowed_domains=["api.github.com"])

    decision = validate_input(
        "fetch_url",
        policy,
        {"url": "https://user:pass@evil.com/resource"},
    )

    assert decision is not None
    assert decision.policy == "url_userinfo"


def test_url_auth_credentials_can_be_allowed_explicitly_but_host_still_checked():
    policy = InputPolicy(allowed_domains=["api.github.com"], block_userinfo=False)

    decision = validate_input(
        "fetch_url",
        policy,
        {"url": "https://user:pass@evil.com/resource"},
    )

    assert decision is not None
    assert decision.policy == "allowed_domains"
    assert decision.details["domain"] == "evil.com"


def test_url_encoded_domain_name_does_not_match_decoded_allowlist():
    policy = InputPolicy(allowed_domains=["evil.com"])

    decision = validate_input("fetch_url", policy, {"url": "https://evil%2ecom"})

    assert decision is not None
    assert decision.policy == "allowed_domains"
    assert decision.details["domain"] == "evil%2ecom"


def test_url_blocks_ip_address_when_not_allowlisted():
    policy = InputPolicy(allowed_domains=["api.github.com"])

    decision = validate_input("fetch_url", policy, {"url": "https://192.168.1.1"})

    assert decision is not None
    assert decision.policy == "allowed_domains"
    assert decision.details["domain"] == "192.168.1.1"


def test_url_allows_exact_ip_address_when_configured():
    policy = InputPolicy(
        allowed_ips=["192.168.1.1"],
        allowed_schemes=["https"],
    )

    assert validate_input("fetch_url", policy, {"url": "https://192.168.1.1"}) is None


def test_url_allows_ip_address_in_configured_cidr():
    policy = InputPolicy(
        allowed_cidrs=["192.168.1.0/24"],
        allowed_schemes=["https"],
    )

    assert validate_input("fetch_url", policy, {"url": "https://192.168.1.42"}) is None


def test_url_blocks_ip_address_outside_configured_cidr():
    policy = InputPolicy(allowed_cidrs=["10.0.0.0/8"])

    decision = validate_input("fetch_url", policy, {"url": "https://192.168.1.42"})

    assert decision is not None
    assert decision.policy == "allowed_hosts"


def test_url_allows_configured_unicode_domain_via_idna_normalization():
    policy = InputPolicy(allowed_domains=["bücher.example"])

    assert validate_input("fetch_url", policy, {"url": "https://xn--bcher-kva.example"}) is None


def test_url_blocks_unicode_homoglyph_domain():
    policy = InputPolicy(allowed_domains=["github.com"])

    decision = validate_input("fetch_url", policy, {"url": "https://gith\u0443b.com"})

    assert decision is not None
    assert decision.policy == "allowed_domains"


def test_url_allows_configured_url_prefix():
    policy = InputPolicy(
        allowed_url_prefixes=["https://api.example.com/v1/"],
        allowed_schemes=["https"],
        allowed_domains=["api.example.com"],
    )

    assert (
        validate_input(
            "fetch_url",
            policy,
            {"url": "https://api.example.com/v1/users"},
        )
        is None
    )


def test_url_blocks_unconfigured_url_prefix():
    policy = InputPolicy(
        allowed_url_prefixes=["https://api.example.com/v1/"],
        allowed_schemes=["https"],
        allowed_domains=["api.example.com"],
    )

    decision = validate_input(
        "fetch_url",
        policy,
        {"url": "https://api.example.com/v2/users"},
    )

    assert decision is not None
    assert decision.policy == "allowed_url_prefixes"


@pytest.mark.parametrize("url", ["file:///etc/passwd", "ftp://api.github.com/file"])
def test_url_blocks_disallowed_schemes(url):
    policy = InputPolicy(
        allowed_domains=["api.github.com"],
        allowed_schemes=["https"],
    )

    decision = validate_input("fetch_url", policy, {"url": url})

    assert decision is not None
    assert decision.policy == "allowed_schemes"


@pytest.mark.parametrize("value", ["", "not a URL", "api.github.com/path"])
def test_url_skips_empty_or_non_url_strings(value):
    policy = InputPolicy(
        allowed_domains=["api.github.com"],
        allowed_schemes=["https"],
    )

    assert validate_input("fetch_url", policy, {"url": value}) is None
