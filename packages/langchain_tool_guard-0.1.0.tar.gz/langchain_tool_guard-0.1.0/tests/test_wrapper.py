import json

import pytest
from langchain.agents.middleware import ToolCallRequest
from langchain_core.tools import StructuredTool

from langchain_tool_guard import (
    InputPolicy,
    OutputPolicy,
    ToolGuardMiddleware,
    ToolPolicy,
    guard_tool,
)


def make_echo_tool():
    def echo(path: str) -> str:
        """Echo a path."""

        return path

    return StructuredTool.from_function(
        echo,
        name="read_file",
        description="Read a file.",
        return_direct=True,
    )


def test_guard_tool_preserves_public_tool_metadata():
    tool = make_echo_tool()
    tool.tags = ["files"]
    tool.metadata = {"scope": "test"}

    guarded = guard_tool(tool, policy=ToolPolicy())

    assert guarded.name == tool.name
    assert guarded.description == tool.description
    assert guarded.args_schema == tool.args_schema
    assert guarded.return_direct == tool.return_direct
    assert guarded.tags == ["files"]
    assert guarded.metadata == {"scope": "test"}


def test_guard_tool_blocks_before_inner_tool_executes():
    called = False

    def read_file(path: str) -> str:
        """Read a file."""

        nonlocal called
        called = True
        return path

    tool = StructuredTool.from_function(
        read_file, name="read_file", description="Read a file."
    )
    guarded = guard_tool(
        tool,
        policy=ToolPolicy(input=InputPolicy(deny_substrings=[".env"])),
    )

    result = guarded.run({"path": "configs/.env"}, tool_call_id="call-1")

    assert called is False
    assert result.status == "error"
    assert json.loads(result.content)["policy"] == "deny_substrings"


def test_guard_tool_processes_direct_string_output():
    def fetch(value: str) -> str:
        """Fetch a value."""

        return '{"token": "sk-abc", "value": "ok"}'

    tool = StructuredTool.from_function(fetch, name="fetch", description="Fetch.")
    guarded = guard_tool(
        tool,
        policy=ToolPolicy(output=OutputPolicy(redact_keys=["token"])),
    )

    result = guarded.run({"value": "x"})

    assert json.loads(result) == {"token": "[REDACTED]", "value": "ok"}


@pytest.mark.asyncio
async def test_guard_tool_supports_async_tools():
    async def fetch(value: str) -> str:
        """Fetch a value asynchronously."""

        return f"async:{value}"

    tool = StructuredTool.from_function(
        coroutine=fetch,
        name="fetch",
        description="Fetch.",
    )
    guarded = guard_tool(tool, policy=ToolPolicy())

    assert await guarded.arun({"value": "x"}) == "async:x"


def test_guard_tool_and_middleware_can_compose():
    def fetch(value: str) -> str:
        """Fetch a value."""

        return '{"token": "sk-abc", "details": "abcdefghijklmnopqrstuvwxyz"}'

    inner = StructuredTool.from_function(fetch, name="fetch", description="Fetch.")
    guarded = guard_tool(
        inner,
        policy=ToolPolicy(output=OutputPolicy(redact_keys=["token"])),
    )
    middleware = ToolGuardMiddleware(
        default_output_policy=OutputPolicy(max_output_chars=40)
    )
    req = ToolCallRequest(
        tool_call={"name": "fetch", "args": {"value": "x"}, "id": "call-1"},
        tool=guarded,
        state={},
        runtime=None,
    )

    def handler(_request):
        return guarded.run({"value": "x"}, tool_call_id="call-1")

    result = middleware.wrap_tool_call(req, handler)

    policies = [
        decision["policy"]
        for decision in result.response_metadata["tool_guard_decisions"]
    ]
    assert policies == ["redact_keys", "max_output_chars"]
