import json

from langchain_tool_guard.policies import OutputPolicy
from langchain_tool_guard.processors import process_output


def test_redact_keys_recurses_through_json_objects_and_lists():
    content = json.dumps(
        {
            "token": "sk-abc",
            "items": [{"api_key": "key-1", "name": "visible"}],
            "safe": "ok",
        }
    )

    result = process_output(
        "tool",
        OutputPolicy(redact_keys=["token", "api_key"]),
        content,
    )

    parsed = json.loads(result.content)
    assert parsed["token"] == "[REDACTED]"
    assert parsed["items"][0]["api_key"] == "[REDACTED]"
    assert parsed["items"][0]["name"] == "visible"
    assert result.decisions[0].policy == "redact_keys"
    assert result.decisions[0].details["redacted_keys"] == ["api_key", "token"]


def test_redact_keys_skips_invalid_json():
    result = process_output("tool", OutputPolicy(redact_keys=["token"]), "token=abc")

    assert result.content == "token=abc"
    assert result.decisions == []


def test_redact_keys_matches_exact_key_names():
    result = process_output(
        "tool",
        OutputPolicy(redact_keys=["token"]),
        '{"access_token": "abc"}',
    )

    assert json.loads(result.content)["access_token"] == "abc"
    assert result.decisions == []


def test_redact_keys_handles_keys_at_multiple_depths():
    result = process_output(
        "tool",
        OutputPolicy(redact_keys=["secret"]),
        '{"secret": "a", "nested": {"secret": "b"}, "items": [{"secret": "c"}]}',
    )

    parsed = json.loads(result.content)
    assert parsed["secret"] == "[REDACTED]"
    assert parsed["nested"]["secret"] == "[REDACTED]"
    assert parsed["items"][0]["secret"] == "[REDACTED]"


def test_redact_keys_skips_malformed_json():
    result = process_output("tool", OutputPolicy(redact_keys=["token"]), '{"token":')

    assert result.content == '{"token":'
    assert result.decisions == []


def test_redact_keys_supports_unicode_keys():
    result = process_output(
        "tool",
        OutputPolicy(redact_keys=["秘密"]),
        '{"秘密": "hidden", "visible": "ok"}',
    )

    parsed = json.loads(result.content)
    assert parsed["秘密"] == "[REDACTED]"
    assert parsed["visible"] == "ok"


def test_redact_keys_empty_key_list_is_inert():
    result = process_output("tool", OutputPolicy(redact_keys=[]), '{"token": "abc"}')

    assert result.content == '{"token": "abc"}'
    assert result.decisions == []
