"""Autoloop package."""
