"""
Test-environment helpers for MCP Proxy Adapter **examples**.

Purpose
-------
Expose a small, importable API used by the ``setup_test_environment`` console
script: create a workspace, optionally generate dev certificates, and run
lightweight sanity checks.

Scenario
--------
Typical flow: install the package in a virtualenv, run
``setup_test_environment`` (see ``pyproject.toml`` scripts), then start servers
from the copied ``examples/`` tree with configs under ``configs/``.

Prerequisites
-------------
Same as ``environment_setup.setup_test_environment`` and
``certificate_manager.generate_certificates_with_framework``.

Public API
----------
Exports only symbols that are implemented in this package. For filesystem setup,
prefer ``setup_test_environment`` from ``environment_setup`` or import it from
this package as shown in the console entry module.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from .certificate_manager import generate_certificates_with_framework
from .config_validator import ConfigurationValidator
from .environment_setup import setup_test_environment
from .test_runner import run_full_test_suite, test_proxy_registration

__all__ = [
    "ConfigurationValidator",
    "generate_certificates_with_framework",
    "run_full_test_suite",
    "setup_test_environment",
    "test_proxy_registration",
]
