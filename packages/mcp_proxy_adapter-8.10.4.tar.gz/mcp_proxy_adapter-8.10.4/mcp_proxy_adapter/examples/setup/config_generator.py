"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Configuration generator for MCP Proxy Adapter test environment setup.
"""
