"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Test files generator for MCP Proxy Adapter test environment setup.
"""
