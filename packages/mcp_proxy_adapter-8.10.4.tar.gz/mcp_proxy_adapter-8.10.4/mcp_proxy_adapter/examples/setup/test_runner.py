"""
Lightweight checks after a **local example workspace** has been created.

Purpose
-------
``run_full_test_suite`` runs quick, non-network-dependent validations (and a
best-effort certificate file check) with the process cwd temporarily set to the
workspace root so relative paths like ``certs/`` resolve as in the examples.

Scenario
--------
Invoked when ``setup_test_environment`` is run with ``--run-tests``.

Relationship to the framework
-----------------------------
Does not run pytest or spin up the adapter; see repository ``tests/`` and
``run_security_tests_fixed`` for integration-style checks.

Caveats
-------
``test_proxy_registration`` is a placeholder: full proxy registration demos live
under other example modules.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import os
from pathlib import Path


def _test_basic_connectivity() -> bool:
    """Test basic network connectivity."""
    try:
        import socket

        # Test if we can create a socket
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1)
            # This is a basic connectivity test
            print("✅ Basic connectivity test passed")
            return True

    except Exception as e:
        print(f"❌ Basic connectivity test failed: {e}")
        return False


def _test_configuration_validation() -> bool:
    """Test configuration validation."""
    try:
        from .config_validator import ConfigurationValidator

        validator = ConfigurationValidator()

        # Test valid configuration (SSL disabled so file paths are not required)
        valid_config = {
            "protocols": {"enabled": True, "allowed_protocols": ["https"]},
            "security": {"ssl": {"enabled": False}},
        }

        is_valid, errors, warnings = validator.validate_config(valid_config, "test")

        if is_valid:
            print("✅ Configuration validation test passed")
            return True
        else:
            print(f"❌ Configuration validation test failed: {errors}")
            return False

    except Exception as e:
        print(f"❌ Configuration validation test failed: {e}")
        return False


def _test_certificates() -> bool:
    """Test certificate files."""
    try:
        certs_dir = Path("certs")
        keys_dir = Path("keys")

        if not certs_dir.exists() or not keys_dir.exists():
            print("⚠️ Certificate directories not found, skipping certificate test")
            return True

        # Check for required certificate files
        required_files = [
            certs_dir / "ca_cert.pem",
            certs_dir / "localhost_server.crt",
            keys_dir / "server_key.pem",
        ]

        missing_files = [f for f in required_files if not f.exists()]

        if missing_files:
            print(f"⚠️ Missing certificate files: {missing_files}")
            return False

        print("✅ Certificate test passed")
        return True

    except Exception as e:
        print(f"❌ Certificate test failed: {e}")
        return False


def test_proxy_registration(output_dir: Path | None = None) -> bool:
    """
    Placeholder for proxy registration automation.

    Full flows are documented alongside ``proxy_registration`` examples; this
    hook exists so the setup package exports a stable name without implying a
    live server test here.
    """
    _ = output_dir
    print(
        "ℹ️ test_proxy_registration: skipped in setup package; "
        "see proxy registration examples for a live demo."
    )
    return True


def run_full_test_suite(output_dir: Path) -> bool:
    """
    Run sanity checks with cwd set to ``output_dir``.

    Returns:
        True if all executed checks passed.
    """
    root = Path(output_dir).resolve()
    previous = Path.cwd()
    try:
        os.chdir(root)
        results = [
            _test_basic_connectivity(),
            _test_configuration_validation(),
            _test_certificates(),
        ]
        return all(results)
    finally:
        os.chdir(previous)
