#!/usr/bin/env python3
"""Reference: wait for a queue job terminal via WebSocket ``/ws`` (push path).

What this demonstrates
----------------------
``JsonRpcClient.wait_for_job_via_websocket`` after submitting a job with
``embed_queue``: one-shot subscribe to ``queue_job`` for the returned
``job_id``, then print the terminal event payload (no manual polling loop).

Prerequisites
-------------
- A running adapter with the WebSocket endpoint enabled and ``/ws`` allowed
  for your client (e.g. listed in security public paths where applicable).
- JSON-RPC ``embed_queue`` available with a command that returns a ``job_id``
  (this example uses the ``echo`` command).
- Environment or defaults matching your server:
  * ``MCP_HOST`` (default ``127.0.0.1``)
  * ``MCP_PORT`` (default ``8080``)
  * ``MCP_TOKEN`` (default ``admin-secret-key``) sent as ``X-API-Key``
  * ``MCP_HTTPS`` set to ``1`` / ``true`` / ``yes`` for ``https``; otherwise HTTP

Requires: ``aiohttp`` (dependency of mcp-proxy-adapter).

How to run
----------
From repository root with the package on ``PYTHONPATH`` or editable install::

    python -m mcp_proxy_adapter.examples.websocket_examples.client_websocket_job_status

The script submits ``embed_queue`` with ``echo``, then blocks up to 60 seconds
waiting for completion over ``/ws``. Exit code ``0`` on success, ``1`` on
timeout or error.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

# Add project root for imports when run as script
_root = Path(__file__).resolve().parent
while _root != _root.parent and not (_root / "pyproject.toml").exists():
    _root = _root.parent
if (_root / "pyproject.toml").exists():
    sys.path.insert(0, str(_root))

from mcp_proxy_adapter.client.jsonrpc_client import JsonRpcClient


async def main() -> int:
    host = os.getenv("MCP_HOST", "127.0.0.1")
    port = int(os.getenv("MCP_PORT", "8080"))
    token = os.getenv("MCP_TOKEN", "admin-secret-key")
    use_https = os.getenv("MCP_HTTPS", "").lower() in ("1", "true", "yes")

    client = JsonRpcClient(
        protocol="https" if use_https else "http",
        host=host,
        port=port,
        token_header="X-API-Key",
        token=token,
    )
    try:
        # 1. Submit a job (example: embed_queue with echo)
        print("Submitting job (embed_queue echo)...")
        r = await client.jsonrpc_call(
            "embed_queue",
            {"command": "echo", "params": {"message": "Hello via WS"}},
        )
        out = client._extract_result(r)
        job_id = out.get("data", {}).get("job_id")
        if not job_id:
            print("No job_id in response:", out)
            return 1
        print("Job submitted:", job_id)

        # 2. Wait for completion via WebSocket
        print("Waiting for completion via WebSocket /ws (timeout 60s)...")
        ev = await client.wait_for_job_via_websocket(job_id, timeout=60.0)
        print("Event:", ev.get("event"), "| Payload:", ev)
        return 0
    except asyncio.TimeoutError as e:
        print("Timeout:", e)
        return 1
    except Exception as e:
        print("Error:", e)
        return 1
    finally:
        await client.close()


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
