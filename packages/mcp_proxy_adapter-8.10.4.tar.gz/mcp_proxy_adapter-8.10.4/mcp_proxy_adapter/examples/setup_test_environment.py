#!/usr/bin/env python3
"""
Console entry: scaffold a **local MCP Proxy Adapter example workspace**.

Purpose
-------
Interactive CLI registered in ``pyproject.toml`` as ``setup_test_environment``.
Creates directories, copies packaged ``mcp_proxy_adapter.examples`` into
``<output>/examples/``, optionally generates development certificates, and can
run the lightweight post-setup checks from ``setup.test_runner``.

Scenario
--------
After ``pip install`` (editable or not), run from any cwd:

.. code-block:: bash

   setup_test_environment
   setup_test_environment -o /path/to/workspace --no-certs
   setup_test_environment --run-tests

Or, equivalently:

.. code-block:: bash

   python -m mcp_proxy_adapter.examples.setup_test_environment

Prerequisites
-------------
- Writable destination; the tool prompts if the directory is non-empty.
- Optional: ``mcp_security_framework`` or ``openssl`` for certificate steps
  (see ``setup.certificate_manager``).
- Ports 8080, 8443, 20005, 3005 are checked by default; conflicts only warn
  after confirmation.

Security assumptions
--------------------
All generated keys and copied configs are **non-production** samples.

Caveats
-------
This does **not** install Python dependencies beyond what you already have; it
only prepares files on disk.

Relationship to the framework
-----------------------------
Delegates core layout to ``mcp_proxy_adapter.examples.setup.environment_setup``
and tests to ``mcp_proxy_adapter.examples.setup.test_runner``.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import argparse
import os
import sys
from pathlib import Path

from mcp_proxy_adapter.examples.setup.environment_setup import setup_test_environment
from mcp_proxy_adapter.examples.setup.test_runner import run_full_test_suite


def validate_output_directory(output_dir: Path) -> bool:
    """
    Validate that the output directory is suitable for setup.

    Args:
        output_dir: Directory to validate

    Returns:
        True if valid, False otherwise
    """
    try:
        # Check if directory exists
        if not output_dir.exists():
            print(f"📁 Creating output directory: {output_dir}")
            output_dir.mkdir(parents=True, exist_ok=True)
            return True

        # Check if directory is writable
        if not os.access(output_dir, os.W_OK):
            print(f"❌ Error: Directory {output_dir} is not writable")
            return False

        # Check if directory is empty (optional warning)
        contents = list(output_dir.iterdir())
        if contents:
            print(f"⚠️ Warning: Directory {output_dir} is not empty")
            print(f"   Found {len(contents)} items")
            response = input("   Continue anyway? (y/N): ").strip().lower()
            if response not in ["y", "yes"]:
                print("   Setup cancelled")
                return False

        return True

    except Exception as e:
        print(f"❌ Error validating output directory: {e}")
        return False


def check_ports_available() -> bool:
    """
    Check if required ports are available.

    Returns:
        True if ports are available, False otherwise
    """
    import socket

    ports_to_check = [8080, 8443, 20005, 3005]
    unavailable_ports = []

    for port in ports_to_check:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(1)
                result = s.connect_ex(("localhost", port))
                if result == 0:
                    unavailable_ports.append(port)
        except Exception:
            # If we can't check, assume it's available
            pass

    if unavailable_ports:
        print(f"⚠️ Warning: The following ports are in use: {unavailable_ports}")
        print("   This may cause issues when running the examples")
        response = input("   Continue anyway? (y/N): ").strip().lower()
        return response in ["y", "yes"]

    return True


def main() -> int:
    """
    Main function to set up the test environment.

    Returns:
        Exit code (0 for success, 1 for failure)
    """
    parser = argparse.ArgumentParser(
        description="Set up test environment for MCP Proxy Adapter",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m mcp_proxy_adapter.examples.setup_test_environment
  setup_test_environment -o /path/to/test
  setup_test_environment --no-certs
  setup_test_environment --run-tests
        """,
    )

    parser.add_argument(
        "-o",
        "--output-dir",
        type=Path,
        default=Path.cwd(),
        help="Output directory for test environment (default: current directory)",
    )

    parser.add_argument(
        "--no-certs",
        action="store_true",
        help="Skip certificate generation",
    )

    parser.add_argument(
        "--run-tests",
        action="store_true",
        help="Run tests after setup",
    )

    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose output",
    )

    args = parser.parse_args()

    print("🚀 MCP Proxy Adapter Test Environment Setup")
    print("=" * 50)

    # Validate output directory
    if not validate_output_directory(args.output_dir):
        print("❌ Setup failed: Invalid output directory")
        return 1

    # Check ports
    if not check_ports_available():
        print("❌ Setup cancelled: Port conflicts detected")
        return 1

    try:
        # Run setup
        success = setup_test_environment(
            args.output_dir, generate_certs=not args.no_certs
        )

        if not success:
            print("❌ Setup failed")
            return 1

        print("✅ Test environment setup completed successfully!")
        print(f"📁 Output directory: {args.output_dir.absolute()}")

        # Run tests if requested
        if args.run_tests:
            print("\n🧪 Running tests...")
            test_success = run_full_test_suite(args.output_dir)
            if not test_success:
                print("⚠️ Some tests failed, but setup completed")
                return 1

        print("\n🎉 Setup complete! You can now run the examples.")
        return 0

    except KeyboardInterrupt:
        print("\n⚠️ Setup interrupted by user")
        return 1
    except Exception as e:
        print(f"\n❌ Setup failed with error: {e}")
        if args.verbose:
            import traceback

            traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
