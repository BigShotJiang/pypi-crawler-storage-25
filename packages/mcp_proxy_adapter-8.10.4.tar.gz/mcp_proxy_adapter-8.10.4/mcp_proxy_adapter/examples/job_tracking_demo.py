#!/usr/bin/env python3
"""Reference: JsonRpcClient job tracking (snapshots, message history, WS wait).

What this demonstrates
----------------------
In order, the demo runs ``get_job_status(..., sync_from_queue=True)``,
``get_job_messages(...)``, and (unless skipped) ``wait_for_job(...)``, which
wraps ``wait_for_job_via_websocket`` and records inbound events to the client
registry.

Prerequisites (live server)
-----------------------------
- A running mcp-proxy-adapter with JSON-RPC and WebSocket ``/ws`` enabled for
  queue-job subscription.
- Network reachability to the configured host and port.
- Transport and auth aligned with your deployment:
  * ``--protocol http`` — plain HTTP (typical local dev).
  * ``--protocol https`` — TLS; set token or certificate options if your server
    requires them (same as ``JsonRpcClient`` constructor).
  * ``--protocol mtls`` — mutual TLS; pass ``cert``, ``key``, and ``ca`` via
    code if you extend this script (CLI here uses the default client without
    extra TLS file paths).

This module does not start a server.

Non-interactive CI / offline path
--------------------------------
Run with ``--mock-flow`` to execute the same call sequence against a
``JsonRpcClient`` with ``queue_get_job_status`` and
``wait_for_job_via_websocket`` patched (no network I/O).

How to run
----------
Show CLI help::

    python -m mcp_proxy_adapter.examples.job_tracking_demo --help

Offline mock sequence (copy-paste)::

    python -m mcp_proxy_adapter.examples.job_tracking_demo --mock-flow

Live adapter: replace ``<job-id>`` with a real queued job id from your server::

    python -m mcp_proxy_adapter.examples.job_tracking_demo \\
        --host 127.0.0.1 --port 8080 --protocol http --job-id <job-id>

Skip the blocking ``wait_for_job`` step (snapshots and message list only)::

    python -m mcp_proxy_adapter.examples.job_tracking_demo \\
        --job-id <job-id> --no-wait

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from typing import Any, Dict

from mcp_proxy_adapter.client.jsonrpc_client.client import JsonRpcClient


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8080)
    p.add_argument("--protocol", default="http", choices=("http", "https", "mtls"))
    p.add_argument(
        "--job-id",
        default="",
        help="Live server: job id for status, messages, and (unless --no-wait) wait.",
    )
    p.add_argument(
        "--no-wait",
        action="store_true",
        help="With --job-id only: run get_job_status and get_job_messages; skip wait_for_job.",
    )
    p.add_argument(
        "--mock-flow",
        action="store_true",
        help="Run the demo sequence with mocked queue/WS methods (no network).",
    )
    return p.parse_args(argv)


async def run_job_tracking_demo_sequence(
    client: JsonRpcClient,
    job_id: str,
    *,
    include_wait: bool = True,
    wait_timeout: float = 60.0,
) -> None:
    """
    Run ``get_job_status``, ``get_job_messages``, and optionally ``wait_for_job``.

    Intended for reuse from tests and the CLI; prints human-readable lines to stdout.
    """
    jid = job_id.strip()
    if not jid:
        raise ValueError("job_id must be non-empty")

    snap = await client.get_job_status(jid, sync_from_queue=True)
    print("get_job_status(sync_from_queue=True):")
    print(json.dumps(snap.summary, default=str, indent=2))

    msgs = await client.get_job_messages(jid, limit=10)
    print("get_job_messages(limit=10):", len(msgs), "message(s)")

    if not include_wait:
        return

    async def on_event(msg: Dict[str, Any]) -> None:
        print("event:", msg.get("event") or msg.get("type"))

    result = await client.wait_for_job(jid, timeout=wait_timeout, on_event=on_event)
    print("terminal:", json.dumps(result, default=str, indent=2))


async def _run_mock_flow() -> None:
    """Execute the tracking sequence with patched queue/WS (no live I/O)."""
    from unittest.mock import AsyncMock, patch

    client = JsonRpcClient(protocol="http", host="127.0.0.1", port=9)
    job_id = "mock-job-id"

    async def fake_queue_status(jid: str) -> Dict[str, Any]:
        return {"status": "completed", "data": {"job_id": jid}}

    async def fake_wait(
        jid: str,
        timeout: float = 1.0,
        *,
        on_inbound_message: Any = None,
    ) -> Dict[str, Any]:
        if on_inbound_message is not None:
            await on_inbound_message({"event": "running", "job_id": jid})
        return {"event": "job_completed", "job_id": jid, "result": {"ok": True}}

    try:
        with patch.object(
            client,
            "queue_get_job_status",
            new=AsyncMock(side_effect=fake_queue_status),
        ):
            with patch.object(
                client,
                "wait_for_job_via_websocket",
                new=AsyncMock(side_effect=fake_wait),
            ):
                await run_job_tracking_demo_sequence(
                    client,
                    job_id,
                    include_wait=True,
                    wait_timeout=30.0,
                )
    finally:
        await client.close()


async def main_async(argv: list[str] | None = None) -> None:
    """Entry point for tests and ``main()``; *argv* is token list only (no ``sys.argv[0]``)."""
    args = _parse_args(argv)
    if args.mock_flow:
        await _run_mock_flow()
        return

    if args.job_id:
        client = JsonRpcClient(protocol=args.protocol, host=args.host, port=args.port)
        try:
            await run_job_tracking_demo_sequence(
                client,
                args.job_id.strip(),
                include_wait=not args.no_wait,
                wait_timeout=60.0,
            )
        finally:
            await client.close()
        return

    print(
        "No --job-id and no --mock-flow: no network calls.\n"
        "  Offline / CI:\n"
        "    python -m mcp_proxy_adapter.examples.job_tracking_demo --mock-flow\n"
        "  Live server (replace <job-id>):\n"
        "    python -m mcp_proxy_adapter.examples.job_tracking_demo "
        "--host 127.0.0.1 --port 8080 --job-id <job-id>\n"
        "  Snapshot + messages only (no wait_for_job):\n"
        "    python -m mcp_proxy_adapter.examples.job_tracking_demo "
        "--job-id <job-id> --no-wait\n",
        file=sys.stderr,
    )


def main() -> None:
    asyncio.run(main_async())


if __name__ == "__main__":
    main()
