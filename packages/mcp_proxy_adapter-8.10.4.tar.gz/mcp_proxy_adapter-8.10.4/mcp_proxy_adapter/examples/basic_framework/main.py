#!/usr/bin/env python3
"""
Minimal entrypoint using ``create_and_run_server`` (application factory).

Overview
--------
This script is the smallest **runnable** path that loads a JSON configuration file,
validates it through the factory's loader, builds the FastAPI application via
`mcp_proxy_adapter.api.app.create_app`, and starts the HTTP server using the same
runner stack as larger examples. It exists to show how little boilerplate is
required once a config file is in place.

When to use
-----------
- First-time bring-up: verify install, config shape, and listening port without
  custom commands or proxy registration.
- Smoke tests and tutorials where the reader should focus on **config + factory**
  rather than command registration or integrations.

Components
----------
- **CLI:** ``--config`` / ``-c`` (required), optional ``--host``, ``--port``,
  ``--debug``. The factory accepts ``host`` and ``log_level``; **port is read from
  the configuration file**—the ``--port`` argument is parsed for display only unless
  you extend this script to patch the loaded config (see inline note in ``main``).
- **Factory:** `create_and_run_server` from `mcp_proxy_adapter.core.app_factory`
  (package: `mcp_proxy_adapter.core.app_factory.factory`). It validates config,
  sets up logging, creates the app, and runs the configured engine (default port
  from ``server.port`` in JSON, typically 8000).
- **Path hack:** ``sys.path`` insertion is only for running the file directly from
  a checkout; prefer editable installs for real use.

Prerequisites
-------------
- A valid adapter JSON config path (schema expected by `load_and_validate_config`).
- Virtual environment with project dependencies installed per project rules.

How to run
----------

    python mcp_proxy_adapter/examples/basic_framework/main.py -c /path/to/config.json

Optional: ``--host 0.0.0.0``, ``--debug`` (maps to log level ``debug``).

Extension points
----------------
- Register commands **before** or **after** factory entry by importing the global
  `registry` in a fork of this script (this minimal example does not register extras).
- Replace ``create_and_run_server`` with explicit ``create_app`` + engine wiring if you
  need middleware, lifespan hooks, or SSL logic not covered by the factory helper.

Caveats
-------
- Factory output notes that simplified startup may skip some built-in registration
  paths; read `core/app_factory/factory.py` for current behavior.
- Do not assume ``--port`` changes the listen port without code changes.

Framework relationship
----------------------
Demonstrates the **factory layer** (`core.app_factory`) on top of `create_app`;
contrasts with `examples/full_application/main.py`, which performs fuller command
registration and validation in-process.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""
import sys
import argparse
from pathlib import Path

# Add the framework to the path
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))
from mcp_proxy_adapter.core.app_factory import create_and_run_server


def main():
    """Main entry point for the basic framework example."""
    parser = argparse.ArgumentParser(description="Basic Framework Example")
    parser.add_argument(
        "--config", "-c", required=True, help="Path to configuration file"
    )
    parser.add_argument("--host", help="Server host")
    parser.add_argument("--port", type=int, help="Server port")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    args = parser.parse_args()
    print("🚀 Starting Basic Framework Example")
    print(f"📋 Configuration: {args.config}")
    if args.host:
        print(f"🌐 Host override: {args.host}")
    if args.port:
        print(f"🔌 Port override: {args.port}")
    if args.debug:
        print("🔧 Debug mode: enabled")
    print("=" * 50)

    # Note: Host and port overrides should be handled in configuration file
    # or by modifying the configuration before passing to create_and_run_server
    import asyncio
    asyncio.run(create_and_run_server(
        config_path=args.config,
        title="Basic Framework Example",
        description="Basic MCP Proxy Adapter with minimal configuration",
        version="1.0.0",
        host=args.host or "0.0.0.0",
        log_level="debug" if args.debug else "info"
    ))


if __name__ == "__main__":
    main()
