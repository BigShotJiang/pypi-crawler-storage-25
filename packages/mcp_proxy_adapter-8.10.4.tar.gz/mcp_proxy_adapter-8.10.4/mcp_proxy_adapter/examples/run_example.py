#!/usr/bin/env python3
"""
CLI wrapper to spawn the **basic** or **full** non-WebSocket example servers.

Purpose
-------
Delegate to another Python entrypoint with a selected JSON config name, instead of
typing paths manually.

What it delegates to
--------------------
- ``basic`` → ``mcp_proxy_adapter/examples/basic_framework/main.py`` with config
  ``mcp_proxy_adapter/examples/basic_framework/configs/<config>.json``.
- ``full`` → ``mcp_proxy_adapter/examples/full_application/main.py`` with config
  ``mcp_proxy_adapter/examples/full_application/configs/<config>.json``.

Configuration (JSON paths)
--------------------------
The ``config`` argument is a **basename** (no ``.json``). Allowed values are fixed
in code:
``http_simple``, ``https_simple``, ``http_auth``, ``https_auth``,
``mtls_no_roles``, ``mtls_with_roles``.
Each must exist as ``<name>.json`` under the **chosen** example’s ``configs/``
directory (the ``basic_framework`` tree contains these names; ``full_application``
uses partly different filenames—ensure the file exists before running).

CLI
---
- Positional: ``example`` = ``basic`` | ``full``, ``config`` = one of the names above.
- Optional: ``--port`` → forwarded as ``--port`` to the child ``main.py``.

How to run
----------

.. code-block:: bash

   python -m mcp_proxy_adapter.examples.run_example basic http_simple
   python -m mcp_proxy_adapter.examples.run_example full http_simple --port 9000

Relationship to the framework
-----------------------------
This is a thin ``subprocess`` launcher; the real adapter startup lives in the
target ``main.py`` files (``create_and_run_server`` / ``create_app`` + Hypercorn).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""
import sys
import subprocess
import argparse
from pathlib import Path


def run_basic_example(config_name: str, port: int = None):
    """Run basic framework example."""
    config_path = (
        Path(__file__).parent / "basic_framework" / "configs" / f"{config_name}.json"
    )
    main_script = Path(__file__).parent / "basic_framework" / "main.py"
    if not config_path.exists():
        print(f"❌ Configuration file not found: {config_path}")
        return False
    cmd = [sys.executable, str(main_script), "--config", str(config_path)]
    if port:
        cmd.extend(["--port", str(port)])
    print(f"🚀 Running basic framework example with {config_name} configuration...")
    return subprocess.run(cmd).returncode == 0


def run_full_example(config_name: str, port: int = None):
    """Run full application example."""
    config_path = (
        Path(__file__).parent / "full_application" / "configs" / f"{config_name}.json"
    )
    main_script = Path(__file__).parent / "full_application" / "main.py"
    if not config_path.exists():
        print(f"❌ Configuration file not found: {config_path}")
        return False
    cmd = [sys.executable, str(main_script), "--config", str(config_path)]
    if port:
        cmd.extend(["--port", str(port)])
    print(f"🚀 Running full application example with {config_name} configuration...")
    return subprocess.run(cmd).returncode == 0


def main():
    """Main function."""
    parser = argparse.ArgumentParser(description="Run MCP Proxy Adapter Examples")
    parser.add_argument("example", choices=["basic", "full"], help="Example type")
    parser.add_argument(
        "config", help="Configuration name (e.g., http_simple, https_auth)"
    )
    parser.add_argument("--port", type=int, help="Override port")
    args = parser.parse_args()
    # Available configurations
    configs = [
        "http_simple",
        "https_simple",
        "http_auth",
        "https_auth",
        "mtls_no_roles",
        "mtls_with_roles",
    ]
    if args.config not in configs:
        print(f"❌ Unknown configuration: {args.config}")
        print(f"Available configurations: {', '.join(configs)}")
        return 1
    # Run the appropriate example
    if args.example == "basic":
        success = run_basic_example(args.config, args.port)
    else:
        success = run_full_example(args.config, args.port)
    return 0 if success else 1


if __name__ == "__main__":
    sys.exit(main())
