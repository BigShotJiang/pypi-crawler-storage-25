"""
Reference HTTP/aiohttp client for exercising security modes against an adapter server.

Overview
--------
`UniversalClient` is a **demo and integration helper**: it builds an `aiohttp`
session, optionally wires optional `mcp_security_framework` managers (auth,
permissions, certificates), and performs GET/POST calls including JSON-RPC payloads.
It is intended to show how different client-side auth styles map to headers, TLS,
and token flows—not to be a production SDK.

When to use
-----------
- Local experiments: iterate on API key, JWT, mutual TLS, or basic auth against
  a running `create_app` instance.
- Regression demos: `demo_all_connection_methods` walks a matrix of auth modes.
- Ad-hoc JSON-RPC: CLI ``--config`` builds a URL from server JSON and can call a
  method (e.g. ``help``) over ``POST /api/jsonrpc``.

Connection modes
--------------
- **Transport:** HTTP or HTTPS `base_url`; optional custom SSL context from
  `mcp_proxy_adapter.core.ssl_utils.SSLUtils` and per-mode ``security.ssl`` settings.
- **auth_method ``none``:** plain session, no extra headers after connect.
- **``api_key``:** stores key for `X-API-Key` (or configured header) on requests.
- **``jwt``:** uses framework helpers to mint JWT when `mcp_security_framework` is
  importable; otherwise behavior degrades (see limitations).
- **``certificate``:** client certificate paths for TLS client auth.
- **``basic``:** HTTP Basic credentials when framework path is used.

Security framework relationship
-------------------------------
- If ``mcp_security_framework`` imports succeed, `SecurityManager`, `AuthManager`,
  `CertificateManager`, and `PermissionManager` are constructed from the nested
  ``security`` dict. If the dependency is missing, a warning is printed and the
  client operates in a reduced **HTTP-only** mode (still useful for plain JSON-RPC).
- `SSLUtils` supplies helper loading for trust/client material when building SSL
  contexts for aiohttp.

Typical flows
-------------
1. Build a config dict (see `create_client_config` or load JSON in ``__main__``).
2. ``async with UniversalClient(config) as client:`` → ``connect`` runs auth side
   effects, then ``get``/``post``/``test_connection``/``test_security_features``.
3. **CLI without args:** runs `demo_all_connection_methods` against localhost URLs
   hardcoded in the demo (expect failures unless matching servers are up).
4. **CLI with auth method name:** `demo_specific_connection` targets
  ``http://localhost:8000`` with demo credentials.
5. **CLI ``--config``:** derives ``server_url`` from ``server`` + ``ssl`` sections,
  then optional ``--method`` / ``--params`` JSON-RPC call.

Configuration
-------------
- Top-level keys: ``server_url``, ``timeout``, ``retry_attempts``, ``retry_delay``,
  ``security`` (must include ``auth_method`` and mode-specific nested blocks).
- File-based CLI path expects conventional ``server.host`` / ``server.port`` and
  optional ``ssl`` block; protocol is inferred from ``ssl.enabled``.

Limitations
-----------
- **Not a full MCP client** over stdio; HTTP JSON-RPC and REST-style paths only (no
  WebSocket job channel); for bidirectional ``/ws`` and queue completion via WebSocket
  use ``scripts/example_bidirectional_ws_mtls.py``.
- Demos assume services and certificates exist at hardcoded paths; failures are
  printed and swallowed in places for illustration.
- Without `mcp_security_framework`, JWT/basic/certificate paths may be incomplete;
  install the framework package for the full behavior described in class docstrings.
- Retry logic exists on the object but not every code path applies it uniformly.

Framework relationship
----------------------
Complements server-side `create_app` and unified security middleware: use it to
reproduce how external callers attach API keys, tokens, or certs. Pair with
`examples/full_application` or your own config that enables matching auth.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import asyncio
import json
import os
import time
from pathlib import Path
from types import TracebackType
from urllib.parse import urljoin
from typing import TYPE_CHECKING, Any, Dict, List, Optional, cast
import aiohttp

# Add project root to path
import sys

project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

from mcp_proxy_adapter.core.ssl_utils import SSLUtils

if TYPE_CHECKING:
    from ssl import SSLContext

# Import security framework components
try:
    from mcp_security_framework import (
        SecurityManager,
        AuthManager,
        CertificateManager,
        PermissionManager,
    )
    from mcp_security_framework.utils.auth_utils import (
        create_jwt_token,
    )
    from mcp_security_framework.utils.cert_utils import (
        extract_roles_from_cert,
    )

    SECURITY_FRAMEWORK_AVAILABLE = True
except ImportError:
    SECURITY_FRAMEWORK_AVAILABLE = False
    print("Warning: mcp_security_framework not available. Using basic HTTP client.")


class UniversalClient:
    """
    Universal client that demonstrates all possible secure connection methods.
    Supports:
    - HTTP/HTTPS connections
    - API Key authentication
    - JWT token authentication
    - Certificate-based authentication
    - SSL/TLS with custom certificates
    - Role-based access control
    - Rate limiting awareness
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize universal client with configuration.
        Args:
            config: Client configuration with security settings
        """
        self.config = config
        self.base_url = config.get("server_url", "http://localhost:8000")
        self.timeout = config.get("timeout", 30)
        self.retry_attempts = config.get("retry_attempts", 3)
        self.retry_delay = config.get("retry_delay", 1)
        # Security configuration
        self.security_config = config.get("security", {})
        self.auth_method = self.security_config.get("auth_method", "none")
        # Initialize security managers if framework is available
        self.security_manager: Optional[Any] = None
        self.auth_manager: Optional[Any] = None
        self.cert_manager: Optional[Any] = None
        self.permission_manager: Optional[Any] = None
        if SECURITY_FRAMEWORK_AVAILABLE:
            self._initialize_security_managers()
        # Session management
        self.session: Optional[aiohttp.ClientSession] = None
        self.current_token: Optional[str] = None
        self.token_expiry: Optional[float] = None
        print(f"Universal client initialized with auth method: {self.auth_method}")

    def _initialize_security_managers(self) -> None:
        """Initialize security framework managers."""
        try:
            # Initialize security manager
            self.security_manager = SecurityManager(self.security_config)
            # Initialize permission manager first
            permissions_config = self.security_config.get("permissions", {})
            self.permission_manager = PermissionManager(permissions_config)
            # Initialize auth manager with permission_manager
            auth_config = self.security_config.get("auth", {})
            self.auth_manager = AuthManager(auth_config, self.permission_manager)
            # Initialize certificate manager
            cert_config = self.security_config.get("certificates", {})
            self.cert_manager = CertificateManager(cert_config)
            print("Security framework managers initialized successfully")
        except Exception as e:
            print(f"Warning: Failed to initialize security managers: {e}")

    async def __aenter__(self) -> "UniversalClient":
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(
        self,
        exc_type: Optional[type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[TracebackType],
    ) -> None:
        """Async context manager exit."""
        await self.disconnect()

    async def connect(self) -> None:
        """Establish connection with authentication."""
        print(
            f"Connecting to {self.base_url} with {self.auth_method} authentication..."
        )
        # Create SSL context
        ssl_context = self._create_ssl_context()
        # Create connector with SSL context
        connector = None
        if ssl_context:
            connector = aiohttp.TCPConnector(ssl=ssl_context)
        # Create session
        self.session = aiohttp.ClientSession(connector=connector)
        # Perform authentication based on method
        if self.auth_method == "api_key":
            await self._authenticate_api_key()
        elif self.auth_method == "jwt":
            await self._authenticate_jwt()
        elif self.auth_method == "certificate":
            await self._authenticate_certificate()
        elif self.auth_method == "basic":
            await self._authenticate_basic()
        else:
            print("No authentication required")
        print("Connection established successfully")

    async def disconnect(self) -> None:
        """Close connection and cleanup."""
        if self.session:
            await self.session.close()
            self.session = None
        print("Connection closed")

    async def _authenticate_api_key(self) -> None:
        """Authenticate using API key."""
        api_key_config = self.security_config.get("api_key", {})
        api_key = api_key_config.get("key")
        if not api_key:
            raise ValueError("API key not provided in configuration")
        # Store API key for requests
        self.current_token = api_key
        print(f"Authenticated with API key: {api_key[:8]}...")

    async def _authenticate_jwt(self) -> None:
        """Authenticate using JWT token."""
        jwt_config = self.security_config.get("jwt", {})
        # Check if we have a stored token that's still valid
        if self.current_token and self.token_expiry and time.time() < self.token_expiry:
            print("Using existing JWT token")
            return
        # Get credentials for JWT
        username = jwt_config.get("username")
        password = jwt_config.get("password")
        secret = jwt_config.get("secret")
        if not all([username, password, secret]):
            raise ValueError("JWT credentials not provided in configuration")
        # Create JWT token
        if SECURITY_FRAMEWORK_AVAILABLE:
            self.current_token = create_jwt_token(
                username, secret, expiry_hours=jwt_config.get("expiry_hours", 24)
            )
        else:
            try:
                import jwt
            except ImportError as exc:
                raise RuntimeError(
                    "JWT authentication requires mcp_security_framework (preferred) "
                    "or the PyJWT package (pip install PyJWT)."
                ) from exc
            payload = {
                "username": username,
                "exp": time.time() + (jwt_config.get("expiry_hours", 24) * 3600),
            }
            self.current_token = jwt.encode(payload, secret, algorithm="HS256")
        self.token_expiry = time.time() + (jwt_config.get("expiry_hours", 24) * 3600)
        print(f"Authenticated with JWT token: {self.current_token[:20]}...")

    async def _authenticate_certificate(self) -> None:
        """Authenticate using client certificate."""
        cert_config = self.security_config.get("certificate", {})
        cert_file = cert_config.get("cert_file")
        key_file = cert_config.get("key_file")
        if not cert_file or not key_file:
            raise ValueError("Certificate files not provided in configuration")
        # Validate certificate
        if SECURITY_FRAMEWORK_AVAILABLE and self.cert_manager:
            try:
                cert_info = self.cert_manager.validate_certificate(cert_file, key_file)
                print(f"Certificate validated: {cert_info.get('subject', 'Unknown')}")
                # Extract roles from certificate
                roles = extract_roles_from_cert(cert_file)
                if roles:
                    print(f"Certificate roles: {roles}")
            except Exception as e:
                print(f"Warning: Certificate validation failed: {e}")
        print("Certificate authentication prepared")

    async def _authenticate_basic(self) -> None:
        """Authenticate using basic authentication."""
        basic_config = self.security_config.get("basic", {})
        username = basic_config.get("username")
        password = basic_config.get("password")
        if not username or not password:
            raise ValueError("Basic auth credentials not provided in configuration")
        import base64

        credentials = base64.b64encode(f"{username}:{password}".encode()).decode()
        self.current_token = f"Basic {credentials}"
        print(f"Authenticated with basic auth: {username}")

    def _get_auth_headers(self) -> Dict[str, str]:
        """Get authentication headers for requests."""
        headers = {"Content-Type": "application/json"}
        if not self.current_token:
            return headers
        if self.auth_method == "api_key":
            api_key_config = self.security_config.get("api_key", {})
            header_name = api_key_config.get("header", "X-API-Key")
            headers[header_name] = self.current_token
        elif self.auth_method == "jwt":
            headers["Authorization"] = f"Bearer {self.current_token}"
        elif self.auth_method == "basic":
            headers["Authorization"] = self.current_token
        return headers

    def _create_ssl_context(self) -> Optional["SSLContext"]:
        """Create SSL context for secure connections using security framework."""
        ssl_config = self.security_config.get("ssl", {})
        if not ssl_config.get("enabled", False):
            return None
        try:
            # Get certificate configuration
            cert_config = self.security_config.get("certificate", {})
            cert_file = (
                cert_config.get("cert_file")
                if cert_config.get("enabled", False)
                else None
            )
            key_file = (
                cert_config.get("key_file")
                if cert_config.get("enabled", False)
                else None
            )

            # Get CA certificate
            ca_cert_file = ssl_config.get("ca_cert_file") or ssl_config.get("ca_cert")

            # Get verification settings
            verify = ssl_config.get("verify", True)
            check_hostname = ssl_config.get("check_hostname", True)

            # Create SSL context using security framework
            # Try security manager first if available
            if self.security_manager and hasattr(
                self.security_manager, "create_client_ssl_context"
            ):
                try:
                    return cast(
                        "SSLContext",
                        self.security_manager.create_client_ssl_context(),
                    )
                except Exception:
                    pass  # Fall through to SSLUtils

            # Use SSLUtils from mcp_proxy_adapter (always uses security framework)
            return cast(
                "SSLContext",
                SSLUtils.create_client_ssl_context(
                    ca_cert=ca_cert_file,
                    client_cert=cert_file,
                    client_key=key_file,
                    verify=verify,
                    check_hostname=check_hostname,
                ),
            )
        except Exception as e:
            print(f"Warning: Failed to create SSL context: {e}")
            return None

    async def request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Make authenticated request to server.
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint
            data: Request data
            headers: Additional headers
        Returns:
            Response data
        """
        url = urljoin(self.base_url, endpoint)
        # Prepare headers
        request_headers = self._get_auth_headers()
        if headers:
            request_headers.update(headers)
        session = self.session
        if session is None:
            raise RuntimeError("Client session not established; call connect() first")
        try:
            for attempt in range(self.retry_attempts):
                try:
                    async with session.request(
                        method,
                        url,
                        json=data,
                        headers=request_headers,
                        timeout=aiohttp.ClientTimeout(total=self.timeout),
                    ) as response:
                        text = await response.text()
                        ct = (
                            response.headers.get("Content-Type", "")
                            .split(";")[0]
                            .strip()
                            .lower()
                        )
                        result: Dict[str, Any]
                        looks_json = not ct or "json" in ct
                        if looks_json:
                            try:
                                parsed = json.loads(text) if text else {}
                            except json.JSONDecodeError:
                                result = {
                                    "raw": text,
                                    "status": response.status,
                                    "parse_error": "invalid_json",
                                }
                            else:
                                result = (
                                    parsed
                                    if isinstance(parsed, dict)
                                    else {"data": parsed}
                                )
                        else:
                            try:
                                parsed = json.loads(text) if text else {}
                            except json.JSONDecodeError:
                                result = {"raw": text, "status": response.status}
                            else:
                                result = (
                                    parsed
                                    if isinstance(parsed, dict)
                                    else {"data": parsed}
                                )
                        # Validate response if security framework available
                        if SECURITY_FRAMEWORK_AVAILABLE and self.security_manager:
                            self.security_manager.validate_server_response(
                                dict(response.headers)
                            )
                        if response.status >= 400:
                            print(
                                f"Request failed with status {response.status}: {result}"
                            )
                            return {"error": result, "status": response.status}
                        return result
                except Exception as e:
                    print(f"Request attempt {attempt + 1} failed: {e}")
                    if attempt < self.retry_attempts - 1:
                        await asyncio.sleep(self.retry_delay)
                    else:
                        raise
            raise RuntimeError(
                "Request did not complete (retry_attempts may be zero or exhausted)"
            )
        except Exception as e:
            print(f"Request failed: {e}")
            raise

    async def get(self, endpoint: str, **kwargs: Any) -> Dict[str, Any]:
        """Make GET request."""
        return await self.request("GET", endpoint, **kwargs)

    async def post(
        self, endpoint: str, data: Dict[str, Any], **kwargs: Any
    ) -> Dict[str, Any]:
        """Make POST request."""
        return await self.request("POST", endpoint, data=data, **kwargs)

    async def put(
        self, endpoint: str, data: Dict[str, Any], **kwargs: Any
    ) -> Dict[str, Any]:
        """Make PUT request."""
        return await self.request("PUT", endpoint, data=data, **kwargs)

    async def delete(self, endpoint: str, **kwargs: Any) -> Dict[str, Any]:
        """Make DELETE request."""
        return await self.request("DELETE", endpoint, **kwargs)

    async def test_connection(self) -> bool:
        """Test connection to server."""
        try:
            result = await self.get("/health")
            if "error" not in result:
                print("✅ Connection test successful")
                return True
            else:
                print(f"❌ Connection test failed: {result}")
                return False
        except Exception as e:
            print(f"❌ Connection test failed: {e}")
            return False

    async def test_security_features(self) -> Dict[str, bool]:
        """Test various security features."""
        results = {}
        # Test basic connectivity
        results["connectivity"] = await self.test_connection()
        # Test authentication
        if self.auth_method != "none":
            try:
                result = await self.get("/api/auth/status")
                results["authentication"] = "error" not in result
            except Exception:
                results["authentication"] = False
        # Test SSL/TLS
        if self.base_url.startswith("https"):
            results["ssl_tls"] = True
        else:
            results["ssl_tls"] = False
        # Test certificate validation
        if self.auth_method == "certificate" and SECURITY_FRAMEWORK_AVAILABLE:
            results["certificate_validation"] = True
        else:
            results["certificate_validation"] = False
        return results


def create_client_config(
    server_url: str, auth_method: str = "none", **kwargs: Any
) -> Dict[str, Any]:
    """
    Create client configuration for different authentication methods.
    Args:
        server_url: Server URL
        auth_method: Authentication method (none, api_key, jwt, certificate, basic)
        **kwargs: Additional configuration parameters
    Returns:
        Client configuration dictionary
    """
    security: Dict[str, Any] = {"auth_method": auth_method}
    config: Dict[str, Any] = {
        "server_url": server_url,
        "timeout": 30,
        "retry_attempts": 3,
        "retry_delay": 1,
        "security": security,
    }
    if auth_method == "api_key":
        security["api_key"] = {
            "key": kwargs.get("api_key", "your_api_key_here"),
            "header": kwargs.get("header", "X-API-Key"),
        }
    elif auth_method == "jwt":
        security["jwt"] = {
            "username": kwargs.get("username", "user"),
            "password": kwargs.get("password", "password"),
            "secret": kwargs.get("secret", "your_jwt_secret"),
            "expiry_hours": kwargs.get("expiry_hours", 24),
        }
    elif auth_method == "certificate":
        security["certificate"] = {
            "enabled": True,
            "cert_file": kwargs.get("cert_file", "./certs/client.crt"),
            "key_file": kwargs.get("key_file", "./keys/client.key"),
            "ca_cert_file": kwargs.get("ca_cert_file", "./certs/ca.crt"),
        }
        security["ssl"] = {
            "enabled": True,
            "check_hostname": kwargs.get("check_hostname", True),
            "ca_cert_file": kwargs.get("ca_cert_file", "./certs/ca.crt"),
        }
    elif auth_method == "basic":
        security["basic"] = {
            "username": kwargs.get("username", "user"),
            "password": kwargs.get("password", "password"),
        }
    return config


async def demo_all_connection_methods() -> None:
    """Demonstrate all possible connection methods."""
    print("🚀 Universal Client Demo - All Connection Methods")
    print("=" * 60)
    # Test configurations for different auth methods
    test_configs: List[Dict[str, Any]] = [
        {
            "name": "No Authentication",
            "config": create_client_config("http://localhost:8000", "none"),
        },
        {
            "name": "API Key Authentication",
            "config": create_client_config(
                "http://localhost:8000", "api_key", api_key="demo_api_key_123"
            ),
        },
        {
            "name": "JWT Authentication",
            "config": create_client_config(
                "http://localhost:8000",
                "jwt",
                username="demo_user",
                password="demo_password",
                secret="demo_jwt_secret",
            ),
        },
        {
            "name": "Basic Authentication",
            "config": create_client_config(
                "http://localhost:8000",
                "basic",
                username="demo_user",
                password="demo_password",
            ),
        },
        {
            "name": "Certificate Authentication (HTTPS)",
            "config": create_client_config(
                "https://localhost:8443",
                "certificate",
                cert_file="./certs/client.crt",
                key_file="./keys/client.key",
                ca_cert_file="./certs/ca.crt",
            ),
        },
    ]
    for test_config in test_configs:
        print(f"\n📋 Testing: {test_config['name']}")
        print("-" * 40)
        try:
            async with UniversalClient(test_config["config"]) as client:
                # Test connection
                success = await client.test_connection()
                if success:
                    # Test security features
                    security_results = await client.test_security_features()
                    print("Security Features:")
                    for feature, status in security_results.items():
                        status_icon = "✅" if status else "❌"
                        print(f"  {status_icon} {feature}: {status}")
                    # Make a test API call
                    try:
                        result = await client.get("/api/status")
                        print(f"API Status: {result}")
                    except Exception as e:
                        print(f"API call failed: {e}")
                else:
                    print("❌ Connection failed")
        except Exception as e:
            print(f"❌ Test failed: {e}")
    print("\n🎉 Demo completed!")


async def demo_specific_connection(auth_method: str, **kwargs: Any) -> None:
    """
    Demo specific connection method.
    Args:
        auth_method: Authentication method to test
        **kwargs: Configuration parameters
    """
    print(f"🚀 Testing {auth_method} connection")
    print("=" * 40)
    config = create_client_config("http://localhost:8000", auth_method, **kwargs)
    async with UniversalClient(config) as client:
        # Test connection
        success = await client.test_connection()
        if success:
            print("✅ Connection successful!")
            # Make some API calls
            try:
                # Get server status
                status = await client.get("/api/status")
                print(f"Server Status: {status}")
                # Test command execution
                command_data = {
                    "jsonrpc": "2.0",
                    "method": "test_command",
                    "params": {"message": "Hello from universal client!"},
                    "id": 1,
                }
                result = await client.post("/api/jsonrpc", command_data)
                print(f"Command Result: {result}")
            except Exception as e:
                print(f"API calls failed: {e}")
        else:
            print("❌ Connection failed")


if __name__ == "__main__":
    import sys
    import argparse
    import json

    parser = argparse.ArgumentParser(
        description="Universal Client for MCP Proxy Adapter"
    )
    parser.add_argument("--config", help="Path to configuration file")
    parser.add_argument("--method", help="JSON-RPC method to call")
    parser.add_argument("--params", help="JSON-RPC parameters (JSON string)")
    parser.add_argument("--auth-method", help="Authentication method")
    parser.add_argument("--server-url", help="Server URL")
    args = parser.parse_args()
    if args.config:
        # Load configuration from file
        try:
            with open(args.config, "r") as f:
                config_data = json.load(f)
            # Extract server configuration
            server_config = config_data.get("server", {})
            host = server_config.get("host", "127.0.0.1")
            port = server_config.get("port", 8000)
            # Determine protocol
            ssl_config = config_data.get("ssl", {})
            ssl_enabled = ssl_config.get("enabled", False)
            protocol = "https" if ssl_enabled else "http"
            server_url = f"{protocol}://{host}:{port}"
            print("🚀 Testing --config connection")
            print("=" * 40)
            print("Universal client initialized with auth method: --config")
            print(f"Connecting to {server_url} with --config authentication...")
            # Create client configuration
            security_cfg: Dict[str, Any] = {"auth_method": "none"}
            client_config: Dict[str, Any] = {
                "server_url": server_url,
                "timeout": 30,
                "retry_attempts": 3,
                "retry_delay": 1,
                "security": security_cfg,
            }
            # Add SSL configuration if needed
            if ssl_enabled:
                ssl_nested: Dict[str, Any] = {
                    "enabled": True,
                    "check_hostname": False,
                    "verify": False,
                }
                security_cfg["ssl"] = ssl_nested
                # Add CA certificate if available
                ca_cert = ssl_config.get("ca_cert")
                if ca_cert and os.path.exists(ca_cert):
                    ssl_nested["ca_cert_file"] = ca_cert

            async def test_config_connection() -> None:
                async with UniversalClient(client_config) as client:
                    # Test connection
                    success = await client.test_connection()
                    if success:
                        print("No authentication required")
                        print("Connection established successfully")
                        if args.method:
                            # Execute JSON-RPC method
                            params = {}
                            if args.params:
                                try:
                                    params = json.loads(args.params)
                                except json.JSONDecodeError:
                                    print("❌ Invalid JSON parameters")
                                    return
                            command_data = {
                                "jsonrpc": "2.0",
                                "method": args.method,
                                "params": params,
                                "id": 1,
                            }
                            try:
                                result = await client.post("/api/jsonrpc", command_data)
                                print(
                                    f"✅ Method '{args.method}' executed successfully:"
                                )
                                print(json.dumps(result, indent=2))
                            except Exception as e:
                                print(f"❌ Method execution failed: {e}")
                        else:
                            # Default to help command
                            command_data = {
                                "jsonrpc": "2.0",
                                "method": "help",
                                "params": {},
                                "id": 1,
                            }
                            try:
                                result = await client.post("/api/jsonrpc", command_data)
                                print("✅ Help command executed successfully:")
                                print(json.dumps(result, indent=2))
                            except Exception as e:
                                print(f"❌ Help command failed: {e}")
                    else:
                        print("❌ Connection failed")
                    print("Connection closed")

            asyncio.run(test_config_connection())
        except FileNotFoundError:
            print(f"❌ Configuration file not found: {args.config}")
        except json.JSONDecodeError:
            print(f"❌ Invalid JSON in configuration file: {args.config}")
        except Exception as e:
            print(f"❌ Error loading configuration: {e}")
    elif len(sys.argv) > 1:
        # Test specific auth method (legacy mode)
        auth_method = sys.argv[1]
        kwargs = {}
        if auth_method == "api_key":
            kwargs["api_key"] = "demo_key_123"
        elif auth_method == "jwt":
            kwargs.update(
                {
                    "username": "demo_user",
                    "password": "demo_password",
                    "secret": "demo_secret",
                }
            )
        elif auth_method == "certificate":
            kwargs.update(
                {
                    "cert_file": "./certs/client.crt",
                    "key_file": "./keys/client.key",
                    "ca_cert_file": "./certs/ca.crt",
                }
            )
        elif auth_method == "basic":
            kwargs.update({"username": "demo_user", "password": "demo_password"})
        asyncio.run(demo_specific_connection(auth_method, **kwargs))
    else:
        # Demo all connection methods
        asyncio.run(demo_all_connection_methods())
