#!/usr/bin/env python3
"""
Async **smoke client** for example MCP Proxy Adapter servers (health on many URLs).

Purpose
-------
Demonstrates driving ``SecurityTestClient`` from ``mcp_proxy_adapter.examples.security_test``
against a list of base URLs (HTTP/HTTPS/mTLS ports used in sample configs).
Each URL is probed with its **own** client instance so TLS settings match the
scheme (the shared-session design would mis-handle mixed HTTP/HTTPS).

Optional dependencies (checked at import)
-----------------------------------------
- **aiohttp** — required; used by ``SecurityTestClient`` for HTTP(S) calls.
- **cryptography** — optional at this layer; lower-level SSL helpers may use it
  indirectly via ``mcp_proxy_adapter.core.ssl_utils`` when HTTPS/mTLS runs.

This module does **not** import ``mcp_security_framework``; certificate
generation for the workspace is handled by ``setup.certificate_manager`` when
you run ``setup_test_environment``.

How to run
----------

.. code-block:: bash

   python -m mcp_proxy_adapter.examples.security_test_client

vs executing the file directly: both work if the package is installed; the
``-m`` form avoids ``sys.path`` surprises when the cwd is not the repo root.

Prerequisites
-------------
- Example servers listening on the URLs listed in ``main()`` (adjust if your
  ports differ).

Security assumptions
--------------------
Example endpoints and dev certificates only; not a production scanner.

Relationship to the framework
-----------------------------
Calls the same JSON-RPC and ``/health`` routes the adapter exposes in examples.

Caveats
-------
The URL list in ``main()`` is a static demo; edit it to match your running
configs.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import asyncio

try:
    import aiohttp  # noqa: F401 — required by SecurityTestClient stack
except ImportError as e:
    raise ImportError(
        "security_test_client requires aiohttp; install with: pip install aiohttp"
    ) from e

try:
    import cryptography  # noqa: F401

    _CRYPTOGRAPHY_AVAILABLE = True
except ImportError:
    _CRYPTOGRAPHY_AVAILABLE = False

if not _CRYPTOGRAPHY_AVAILABLE:
    print("⚠️ cryptography not installed; some SSL operations in dependencies may fail")

from mcp_proxy_adapter.examples.security_test import SecurityTestClient


async def main() -> None:
    """Run a minimal health check per configured example base URL."""
    print("🚀 Starting MCP Proxy Adapter Security Tests")
    print("=" * 50)

    test_servers = [
        "http://localhost:8080",
        "http://localhost:8080",
        "https://localhost:8443",
        "https://localhost:8443",
        "https://localhost:20006",
        "https://localhost:20007",
        "https://localhost:20008",
    ]

    for url in test_servers:
        async with SecurityTestClient(url) as client:
            result = await client.test_health_check(url)
            status = "✅" if result.success else "❌"
            print(f"{status} {result.test_name} {url} — {result.error_message or 'ok'}")

    print("\n🎉 Security tests completed!")


if __name__ == "__main__":
    asyncio.run(main())
