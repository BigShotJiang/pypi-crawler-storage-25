"""
``aiohttp``-based client for **example** HTTP/HTTPS/mTLS probes.

Purpose
-------
Holds a ``ClientSession`` with optional TLS connector (HTTPS vs mTLS heuristic by
port), and exposes ``test_health_check`` / ``test_echo_command`` helpers that
return ``TestResult`` rows. Used by ``security_test_client`` and may be extended
for richer runners (e.g. ``run_security_tests_fixed``).

Prerequisites
-------------
``aiohttp`` installed; for HTTPS, ``SSLContextManager`` delegates to
``mcp_proxy_adapter.core.ssl_utils``.

Caveats
-------
mTLS detection uses substring checks on default example ports (20006–20008);
override SSL behavior if you use custom ports.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import time
from pathlib import Path
from types import TracebackType
from typing import Any, Dict, List, Optional, Type

from aiohttp import ClientSession, ClientTimeout, TCPConnector

from .test_result import TestResult
from .ssl_context_manager import SSLContextManager
from .auth_manager import AuthManager


class SecurityTestClient:
    """Security test client for comprehensive testing."""

    def __init__(self, base_url: str = "http://localhost:8000"):
        """
        Initialize security test client.

        Args:
            base_url: Base URL for the server
        """
        self.base_url = base_url
        self.session: Optional[ClientSession] = None
        self.test_results: List[TestResult] = []

        # Initialize managers
        project_root = Path(__file__).parent.parent.parent.parent
        self.ssl_manager = SSLContextManager(project_root)
        self.auth_manager = AuthManager()
        # Optional fields used by example runners (e.g. ``run_security_tests_fixed``).
        self.auth_enabled: bool = False
        self.auth_methods: List[str] = []
        self.api_keys: Dict[str, Any] = {}
        self.roles_file: Optional[str] = None
        self.roles: Dict[str, Any] = {}

    async def __aenter__(self) -> "SecurityTestClient":
        """Async context manager entry."""
        timeout = ClientTimeout(total=30)
        # Create SSL context only for HTTPS URLs
        if self.base_url.startswith("https://"):
            # Check if this is mTLS (ports 20006, 20007, 20008 are mTLS test ports)
            if any(port in self.base_url for port in ["20006", "20007", "20008"]):
                # Use mTLS context with client certificates
                ssl_context = self.ssl_manager.create_ssl_context_for_mtls()
            else:
                # Use regular HTTPS context
                ssl_context = self.ssl_manager.create_ssl_context()
            connector = TCPConnector(ssl=ssl_context)
        else:
            # For HTTP URLs, use default connector without SSL
            connector = TCPConnector()

        # Create session
        self.session = ClientSession(timeout=timeout, connector=connector)
        return self

    async def __aexit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[TracebackType],
    ) -> None:
        """Async context manager exit."""
        if self.session:
            await self.session.close()

    def _require_session(self) -> ClientSession:
        if self.session is None:
            raise RuntimeError(
                "SecurityTestClient must be entered via async context manager"
            )
        return self.session

    async def test_health_check(
        self, server_url: str, auth_type: str = "none", **kwargs: Any
    ) -> TestResult:
        """Test health check endpoint."""
        start_time = time.time()
        test_name = f"Health Check ({auth_type})"
        try:
            session = self._require_session()
            headers = self.auth_manager.create_auth_headers(auth_type, **kwargs)
            async with session.get(f"{server_url}/health", headers=headers) as response:
                duration = time.time() - start_time
                if response.status == 200:
                    data = await response.json()
                    return TestResult(
                        test_name=test_name,
                        server_url=server_url,
                        auth_type=auth_type,
                        success=True,
                        status_code=response.status,
                        response_data=data,
                        duration=duration,
                    )
                else:
                    error_text = await response.text()
                    return TestResult(
                        test_name=test_name,
                        server_url=server_url,
                        auth_type=auth_type,
                        success=False,
                        status_code=response.status,
                        error_message=f"HTTP {response.status}: {error_text}",
                        duration=duration,
                    )
        except Exception as e:
            duration = time.time() - start_time
            return TestResult(
                test_name=test_name,
                server_url=server_url,
                auth_type=auth_type,
                success=False,
                error_message=str(e),
                duration=duration,
            )

    async def test_echo_command(
        self, server_url: str, auth_type: str = "none", **kwargs: Any
    ) -> TestResult:
        """Test echo command endpoint."""
        start_time = time.time()
        test_name = f"Echo Command ({auth_type})"
        try:
            session = self._require_session()
            headers = self.auth_manager.create_auth_headers(auth_type, **kwargs)
            payload = {
                "jsonrpc": "2.0",
                "method": "echo",
                "params": {"message": "Hello from security test client"},
                "id": 1,
            }
            async with session.post(
                f"{server_url}/api/jsonrpc", json=payload, headers=headers
            ) as response:
                duration = time.time() - start_time
                if response.status == 200:
                    data = await response.json()
                    return TestResult(
                        test_name=test_name,
                        server_url=server_url,
                        auth_type=auth_type,
                        success=True,
                        status_code=response.status,
                        response_data=data,
                        duration=duration,
                    )
                else:
                    error_text = await response.text()
                    return TestResult(
                        test_name=test_name,
                        server_url=server_url,
                        auth_type=auth_type,
                        success=False,
                        status_code=response.status,
                        error_message=f"HTTP {response.status}: {error_text}",
                        duration=duration,
                    )
        except Exception as e:
            duration = time.time() - start_time
            return TestResult(
                test_name=test_name,
                server_url=server_url,
                auth_type=auth_type,
                success=False,
                error_message=str(e),
                duration=duration,
            )
