"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

SSL context manager for security testing.
Uses security framework through SSLUtils.
"""

from pathlib import Path
from ssl import SSLContext
from typing import Optional, cast

# Imports require ``mcp_proxy_adapter`` on sys.path (editable install or
# ``python -m ...`` from an environment where the package is discoverable).

from mcp_proxy_adapter.core.ssl_utils import SSLUtils


class SSLContextManager:
    """Manager for SSL contexts in security testing."""

    def __init__(self, project_root: Optional[Path] = None) -> None:
        """
        Initialize SSL context manager.

        Args:
            project_root: Root directory of the project (optional)
        """
        if project_root is None:
            project_root = Path(__file__).parent.parent.parent.parent
        self.project_root = project_root

    def create_server_context(
        self,
        cert_file: str,
        key_file: str,
        ca_cert: Optional[str] = None,
        verify_client: bool = False,
    ) -> SSLContext:
        """
        Create server SSL context using security framework.

        Args:
            cert_file: Path to server certificate
            key_file: Path to server private key
            ca_cert: Optional CA certificate path
            verify_client: Require client certificates (mTLS)

        Returns:
            SSL context for server
        """
        return cast(
            SSLContext,
            SSLUtils.create_ssl_context(
                cert_file=cert_file,
                key_file=key_file,
                ca_cert=ca_cert,
                verify_client=verify_client,
                min_tls_version="TLSv1.2",
            ),
        )

    def create_client_context(
        self,
        ca_cert: Optional[str] = None,
        client_cert: Optional[str] = None,
        client_key: Optional[str] = None,
        verify: bool = True,
        check_hostname: bool = True,
    ) -> SSLContext:
        """
        Create client SSL context using security framework.

        Args:
            ca_cert: Path to CA certificate
            client_cert: Path to client certificate
            client_key: Path to client private key
            verify: Whether to verify server certificate
            check_hostname: Whether to check hostname

        Returns:
            SSL context for client
        """
        return cast(
            SSLContext,
            SSLUtils.create_client_ssl_context(
                ca_cert=ca_cert,
                client_cert=client_cert,
                client_key=client_key,
                verify=verify,
                check_hostname=check_hostname,
            ),
        )

    def _examples_dir(self) -> Path:
        """Directory containing example ``certs/`` and ``keys/`` (dev assets)."""
        return self.project_root / "mcp_proxy_adapter" / "examples"

    def create_ssl_context(self) -> SSLContext:
        """
        Client SSL context for HTTPS example servers (verify with dev CA).

        Thin wrapper over :meth:`create_client_context` using default example paths.
        """
        base = self._examples_dir()
        ca_cert = str(base / "certs" / "ca_cert.pem")
        return self.create_client_context(
            ca_cert=ca_cert,
            client_cert=None,
            client_key=None,
            verify=True,
            check_hostname=True,
        )

    def create_ssl_context_for_mtls(self) -> SSLContext:
        """
        Client SSL context for mTLS example ports (client cert + dev CA).

        Uses the same admin client cert/key paths as sample configs under
        ``mcp_proxy_adapter/examples/``.
        """
        base = self._examples_dir()
        return self.create_client_context(
            ca_cert=str(base / "certs" / "ca_cert.pem"),
            client_cert=str(base / "certs" / "admin_cert.pem"),
            client_key=str(base / "keys" / "admin_key.pem"),
            verify=True,
            check_hostname=True,
        )
