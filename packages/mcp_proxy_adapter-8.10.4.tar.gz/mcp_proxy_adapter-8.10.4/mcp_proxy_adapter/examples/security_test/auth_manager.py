"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Authentication manager for security testing.
"""

from typing import Any, Dict


class AuthManager:
    """Manager for authentication in security testing."""

    def create_auth_headers(self, auth_type: str, **kwargs: Any) -> Dict[str, str]:
        """
        Build HTTP headers for the given example auth style.

        Supported ``auth_type`` values match :class:`SecurityTestClient` probes:

        - ``none`` — no auth headers
        - ``api_key`` — ``X-API-Key`` and ``Authorization: Bearer …`` when
          ``api_key`` is passed (aligned with ``client_security`` conventions)
        - ``token`` / ``jwt`` — ``Authorization: Bearer …`` when ``token`` is passed
        - ``certificate`` — marker header only; mTLS is handled via SSL context
        """
        headers: Dict[str, str] = {}
        normalized = (auth_type or "none").lower()

        if normalized in ("none", ""):
            return headers

        if normalized == "api_key":
            api_key = kwargs.get("api_key")
            if api_key:
                headers["X-API-Key"] = str(api_key)
                headers["Authorization"] = f"Bearer {api_key}"
            return headers

        if normalized in ("token", "jwt", "token_roles", "bearer"):
            token = kwargs.get("token") or kwargs.get("api_key")
            if token:
                headers["Authorization"] = f"Bearer {token}"
            return headers

        if normalized == "certificate":
            headers["X-Auth-Method"] = "certificate"
            return headers

        return headers
