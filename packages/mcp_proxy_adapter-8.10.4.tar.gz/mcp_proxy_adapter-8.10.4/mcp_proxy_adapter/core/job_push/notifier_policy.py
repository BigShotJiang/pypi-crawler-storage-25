"""
Job-push notifier policy helpers for bounded legacy compatibility.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from mcp_proxy_adapter.core.logging import get_global_logger


def read_legacy_unified_terminal_dedup(
    job_push_section: Optional[Dict[str, Any]],
) -> bool:
    """
    Read legacy_unified_terminal_dedup flag from job_push config section.

    Args:
        job_push_section: Optional dict from config with job_push settings.

    Returns:
        True if flag is set to True, False otherwise (default).
    """
    if job_push_section is None:
        return False
    if "legacy_unified_terminal_dedup" not in job_push_section:
        return False
    raw = job_push_section["legacy_unified_terminal_dedup"]
    if isinstance(raw, bool):
        return raw
    get_global_logger().warning(
        "job_push.legacy_unified_terminal_dedup invalid type %r; treating as False",
        raw,
    )
    return False
