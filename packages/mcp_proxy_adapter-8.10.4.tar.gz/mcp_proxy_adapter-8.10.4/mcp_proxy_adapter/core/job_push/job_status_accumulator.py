"""Adapter-side accumulation of WebSocket-bound job status for snapshot reads.

Holds the latest (and optional short history) of push payloads for registered job_id
and/or ws_id keys. Wired from notifier listener, queue custom push, and WS delivery
terminal fan-out.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import asyncio
import copy
import time
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, TypedDict

from mcp_proxy_adapter.core.errors import ValidationError
from mcp_proxy_adapter.core.job_push.events import (
    EVENT_DELIVERY_COMPLETED,
    EVENT_DELIVERY_FAILED,
    EVENT_DELIVERY_STOPPED,
    EVENT_JOB_COMPLETED,
    EVENT_JOB_FAILED,
    EVENT_JOB_STOPPED,
)

_TERMINAL_QUEUE_EVENTS: Set[str] = {
    EVENT_JOB_COMPLETED,
    EVENT_JOB_FAILED,
    EVENT_JOB_STOPPED,
}
_TERMINAL_DELIVERY_EVENTS: Set[str] = {
    EVENT_DELIVERY_COMPLETED,
    EVENT_DELIVERY_FAILED,
    EVENT_DELIVERY_STOPPED,
}


class JobStatusSnapshot(TypedDict, total=False):
    """Serializable snapshot of async job / delivery status."""

    job_id: str
    ws_id: str
    phase: str
    latest_message: Dict[str, Any]
    error: Optional[str]
    last_update_unix: float
    terminal: bool
    history: List[Dict[str, Any]]


Predicate = Callable[[JobStatusSnapshot], bool]


def _event_terminal(payload: Dict[str, Any]) -> bool:
    ev = str(payload.get("event") or "")
    return ev in _TERMINAL_QUEUE_EVENTS or ev in _TERMINAL_DELIVERY_EVENTS


def _payload_error(payload: Dict[str, Any]) -> Optional[str]:
    err = payload.get("error")
    if err is None:
        return None
    return str(err)


def _phase_from_payload(payload: Dict[str, Any]) -> str:
    ev = payload.get("event")
    if isinstance(ev, str) and ev.strip():
        return ev.strip()
    return "unknown"


class JobStatusAccumulator:
    """In-memory snapshots for registered job_id / ws_id keys."""

    def __init__(
        self,
        max_history: int = 32,
        terminal_ttl_seconds: float = 3600.0,
    ) -> None:
        self._lock = asyncio.Lock()
        self._max_history = max(0, int(max_history))
        self._terminal_ttl = float(terminal_ttl_seconds)
        self._active: Set[str] = set()
        self._snapshots: Dict[str, JobStatusSnapshot] = {}
        self._job_to_ws: Dict[str, str] = {}
        self._ws_to_job: Dict[str, str] = {}
        self._cleanup_tasks: Dict[str, asyncio.Task[None]] = {}
        self._wait_events: Dict[str, asyncio.Event] = {}

    def _wait_event_for(self, key: str) -> asyncio.Event:
        ev = self._wait_events.get(key)
        if ev is None:
            ev = asyncio.Event()
            self._wait_events[key] = ev
        return ev

    def _canonical_record_key(
        self, job_id: Optional[str], ws_id: Optional[str]
    ) -> Optional[str]:
        """Resolve storage key for a queue_job or ws_delivery record."""
        if job_id:
            j = job_id.strip()
            jkey = f"job:{j}"
            if jkey in self._active:
                return jkey
        if ws_id:
            w = ws_id.strip()
            j_from_ws = self._ws_to_job.get(w)
            if j_from_ws:
                jkey2 = f"job:{j_from_ws}"
                if jkey2 in self._active:
                    return jkey2
            wkey = f"ws:{w}"
            if wkey in self._active:
                return wkey
        return None

    async def register(
        self,
        job_id: Optional[str] = None,
        ws_id: Optional[str] = None,
        ws_delivery_manager: Any = None,
    ) -> Dict[str, Any]:
        """Mark job_id and/or ws_id for accumulation; optional dual mapping in WsDeliveryManager."""
        jid = str(job_id).strip() if job_id is not None else ""
        wid = str(ws_id).strip() if ws_id is not None else ""
        if not jid and not wid:
            raise ValidationError("job_status_register requires job_id and/or ws_id")
        async with self._lock:
            if jid:
                self._active.add(f"job:{jid}")
            if wid:
                self._active.add(f"ws:{wid}")
            if jid and wid:
                self._job_to_ws[jid] = wid
                self._ws_to_job[wid] = jid
        if jid and wid and ws_delivery_manager is not None:
            await ws_delivery_manager.register_queue_job_mapping(jid, wid)
        return {"registered": True, "job_id": jid or None, "ws_id": wid or None}

    async def unregister(
        self, job_id: Optional[str] = None, ws_id: Optional[str] = None
    ) -> None:
        """Stop tracking; cancel pending cleanup for removed keys."""
        keys: List[str] = []
        if job_id and str(job_id).strip():
            keys.append(f"job:{str(job_id).strip()}")
        if ws_id and str(ws_id).strip():
            keys.append(f"ws:{str(ws_id).strip()}")
        async with self._lock:
            for k in keys:
                self._active.discard(k)
                t = self._cleanup_tasks.pop(k, None)
                if t is not None and not t.done():
                    t.cancel()
                self._snapshots.pop(k, None)
            for j, w in list(self._job_to_ws.items()):
                if f"job:{j}" not in self._active and f"ws:{w}" not in self._active:
                    self._job_to_ws.pop(j, None)
                    self._ws_to_job.pop(w, None)

    def _apply_payload_locked(self, key: str, payload: Dict[str, Any]) -> None:
        now = time.time()
        phase = _phase_from_payload(payload)
        err = _payload_error(payload)
        terminal = _event_terminal(payload)
        jid = ""
        wid = ""
        if "job_id" in payload and payload["job_id"] is not None:
            jid = str(payload["job_id"]).strip()
        if "ws_id" in payload and payload["ws_id"] is not None:
            wid = str(payload["ws_id"]).strip()
        if not jid and key.startswith("job:"):
            jid = key[4:]
        if not wid and key.startswith("ws:"):
            wid = key[3:]
        if jid and not wid:
            wid = self._job_to_ws.get(jid, "") or wid
        if wid and not jid:
            jid = self._ws_to_job.get(wid, "") or jid

        snap: JobStatusSnapshot = {
            "phase": phase,
            "latest_message": copy.deepcopy(payload),
            "error": err,
            "last_update_unix": now,
            "terminal": terminal,
        }
        if jid:
            snap["job_id"] = jid
        if wid:
            snap["ws_id"] = wid

        prev = self._snapshots.get(key)
        history: List[Dict[str, Any]] = []
        if prev and "history" in prev and isinstance(prev["history"], list):
            history = list(prev["history"])
        if self._max_history > 0:
            history.append(copy.deepcopy(payload))
            if len(history) > self._max_history:
                drop = len(history) - self._max_history
                history = history[drop:]
            snap["history"] = history

        self._snapshots[key] = snap
        ev = self._wait_events.get(key)
        if ev is not None:
            ev.set()

        if terminal:
            t_old = self._cleanup_tasks.pop(key, None)
            if t_old is not None and not t_old.done():
                t_old.cancel()

            async def _delayed_drop() -> None:
                await asyncio.sleep(self._terminal_ttl)
                async with self._lock:
                    self._snapshots.pop(key, None)
                    self._active.discard(key)
                    self._cleanup_tasks.pop(key, None)

            self._cleanup_tasks[key] = asyncio.create_task(_delayed_drop())

    async def record_queue_job(self, job_id: str, payload: Dict[str, Any]) -> None:
        """Record one queue_job-family payload (after hooks)."""
        async with self._lock:
            key = self._canonical_record_key(job_id, None)
            if key is None:
                return
            self._apply_payload_locked(key, payload)

    async def record_ws_delivery(self, ws_id: str, payload: Dict[str, Any]) -> None:
        """Record one ws_delivery payload (e.g. execute_async terminal)."""
        async with self._lock:
            key = self._canonical_record_key(None, ws_id)
            if key is None:
                return
            self._apply_payload_locked(key, payload)

    async def get_snapshot(
        self, job_id: Optional[str] = None, ws_id: Optional[str] = None
    ) -> Optional[JobStatusSnapshot]:
        """Return a deep copy of the snapshot for job_id or ws_id, if any."""
        key = self._canonical_record_key(job_id, ws_id)
        if key is None:
            return None
        async with self._lock:
            snap = self._snapshots.get(key)
            if snap is None:
                return None
            return copy.deepcopy(snap)

    async def wait_for(
        self,
        job_id: Optional[str] = None,
        ws_id: Optional[str] = None,
        predicate: Optional[Predicate] = None,
        timeout: Optional[float] = None,
    ) -> Tuple[Optional[JobStatusSnapshot], bool]:
        """Wait until predicate(snapshot) or timeout; default predicate = terminal.

        Returns (snapshot_or_none, timed_out).
        """
        deadline = None if timeout is None else (time.monotonic() + float(timeout))

        def default_pred(s: JobStatusSnapshot) -> bool:
            return bool(s.get("terminal"))

        pred = predicate or default_pred

        while True:
            snap = await self.get_snapshot(job_id=job_id, ws_id=ws_id)
            if snap is not None and pred(snap):
                return (snap, False)
            key = self._canonical_record_key(job_id, ws_id)
            if key is None:
                await asyncio.sleep(0.05)
                if deadline is not None and time.monotonic() >= deadline:
                    s = await self.get_snapshot(job_id=job_id, ws_id=ws_id)
                    return (s, True)
                continue
            ev = self._wait_event_for(key)
            ev.clear()
            remaining = None
            if deadline is not None:
                remaining = max(0.0, deadline - time.monotonic())
            try:
                await asyncio.wait_for(ev.wait(), timeout=remaining)
            except asyncio.TimeoutError:
                s = await self.get_snapshot(job_id=job_id, ws_id=ws_id)
                return (s, True)

    async def shutdown(self) -> None:
        """Cancel pending TTL cleanup tasks."""
        async with self._lock:
            for t in list(self._cleanup_tasks.values()):
                if not t.done():
                    t.cancel()
            self._cleanup_tasks.clear()
