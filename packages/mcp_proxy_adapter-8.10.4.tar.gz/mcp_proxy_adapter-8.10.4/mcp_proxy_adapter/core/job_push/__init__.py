"""
Job push: event schema, typed subscriber registry, notifier, and hooks.

Single source of truth for job-push event names and payload schema (events.py).
Registry uses SubscriptionCategory to separate queue_job, ws_delivery, and transfer_session domains.
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from mcp_proxy_adapter.core.job_push.events import (
    EVENT_ARTIFACT_READY,
    EVENT_DELIVERY_COMPLETED,
    EVENT_DELIVERY_FAILED,
    EVENT_DELIVERY_PROGRESS,
    EVENT_DELIVERY_STOPPED,
    SUBSCRIPTION_TYPE_TRANSFER_SESSION,
    EVENT_TRANSFER_ACCEPTED,
    EVENT_TRANSFER_COMPLETED,
    EVENT_TRANSFER_EXPIRED,
    EVENT_TRANSFER_FAILED,
    EVENT_TRANSFER_PROGRESS,
    EVENT_TRANSFER_RELEASED,
    EVENT_JOB_QUEUED,
    EVENT_JOB_PROGRESS,
    EVENT_JOB_COMPLETED,
    EVENT_JOB_FAILED,
    EVENT_JOB_STOPPED,
    EVENT_JOB_INPUT_ACCEPTED,
    EVENT_JOB_PROCESSING_STEP,
    build_delivery_push_message,
    build_push_message,
)
from mcp_proxy_adapter.core.job_push.subscriptions import (
    Subscriber,
    SubscriberRegistry,
    SubscriptionCategory,
)
from mcp_proxy_adapter.core.job_push.notifier import (
    NotificationDomain,
    notify_job_state_changed,
)
from mcp_proxy_adapter.core.job_push.transfer_push import (
    coerce_ws_push_enabled,
    notify_transfer_state_changed,
    set_transfer_push_app,
)
from mcp_proxy_adapter.transfer.progress_percent import (
    compute_transfer_progress_percent,
)
from mcp_proxy_adapter.core.job_push.hooks import (
    register_job_push_handler,
    get_job_push_handlers,
    run_job_push_handlers,
)
from mcp_proxy_adapter.core.job_push.queue_custom_push import (
    job_processing_step_should_emit,
    push_queue_job_ws_payload,
)
from mcp_proxy_adapter.core.job_push.job_status_accumulator import (
    JobStatusAccumulator,
    JobStatusSnapshot,
)

__all__ = [
    "EVENT_DELIVERY_COMPLETED",
    "EVENT_DELIVERY_FAILED",
    "EVENT_DELIVERY_PROGRESS",
    "EVENT_DELIVERY_STOPPED",
    "SUBSCRIPTION_TYPE_TRANSFER_SESSION",
    "EVENT_TRANSFER_ACCEPTED",
    "EVENT_TRANSFER_COMPLETED",
    "EVENT_TRANSFER_EXPIRED",
    "EVENT_TRANSFER_FAILED",
    "EVENT_TRANSFER_PROGRESS",
    "EVENT_TRANSFER_RELEASED",
    "EVENT_ARTIFACT_READY",
    "EVENT_JOB_INPUT_ACCEPTED",
    "EVENT_JOB_PROCESSING_STEP",
    "EVENT_JOB_QUEUED",
    "EVENT_JOB_PROGRESS",
    "EVENT_JOB_COMPLETED",
    "EVENT_JOB_FAILED",
    "EVENT_JOB_STOPPED",
    "build_delivery_push_message",
    "build_push_message",
    "coerce_ws_push_enabled",
    "compute_transfer_progress_percent",
    "Subscriber",
    "SubscriberRegistry",
    "SubscriptionCategory",
    "NotificationDomain",
    "notify_job_state_changed",
    "notify_transfer_state_changed",
    "set_transfer_push_app",
    "register_job_push_handler",
    "get_job_push_handlers",
    "run_job_push_handlers",
    "job_processing_step_should_emit",
    "push_queue_job_ws_payload",
    "JobStatusAccumulator",
    "JobStatusSnapshot",
]
