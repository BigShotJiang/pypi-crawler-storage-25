"""
CommandRecord dataclass for orchestration catalog.

Stores command name, summary, parameter definitions, metadata, JSON schema,
and the derived required-parameter set. Used by the orchestration layer
for in-memory command catalog (TZ section 7).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from dataclasses import dataclass
from typing import Any, Dict, Optional, Sequence


@dataclass(frozen=True)
class CommandRecord:
    """
    Immutable record for a single command in the orchestration catalog.

    Holds all in-memory data needed for discovery, validation, and
    model tool context: name, summary, parameter definitions, metadata,
    full JSON schema, and the derived set of required parameter names.
    No lazy fetch; all fields are resolved at construction time.
    """

    command_name: str
    """Command identifier (e.g. method name)."""

    summary: Optional[str]
    """Short human-readable description of the command."""

    parameter_definitions: Dict[str, Any]
    """Parameter definitions (e.g. name -> type/constraint info)."""

    metadata: Optional[Dict[str, Any]]
    """Optional command metadata (author, version, category, etc.)."""

    schema: Dict[str, Any]
    """Full JSON schema for the command (type, properties, required, etc.)."""

    required_parameters: Sequence[str]
    """Derived set of required parameter names (from schema/graph)."""
