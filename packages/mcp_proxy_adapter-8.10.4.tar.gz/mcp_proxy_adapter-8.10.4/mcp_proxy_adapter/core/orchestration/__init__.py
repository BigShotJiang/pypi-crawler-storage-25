"""
Orchestration layer: candidate validation, polling, catalog (TZ remote server orchestration).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from mcp_proxy_adapter.core.orchestration.catalog_builder import (
    build_catalog_and_tool_context,
)
from mcp_proxy_adapter.core.orchestration.catalog_snapshot import CatalogSnapshot
from mcp_proxy_adapter.core.orchestration.discovery_client import (
    DiscoveryCandidate,
    run_discovery,
)
from mcp_proxy_adapter.core.orchestration.candidate_validator import (
    validate_candidate,
    ValidationResult,
)
from mcp_proxy_adapter.core.orchestration.command_record import CommandRecord
from mcp_proxy_adapter.core.orchestration.orchestration_errors import (
    CommandNotFoundError,
    InvalidParameterError,
    MissingRequiredParametersError,
    OrchestrationError,
    ProxyDiscoveryError,
    SchemaUnavailableError,
    ServerNotFoundError,
    StaleCatalogError,
    ToolContextBuildError,
)
from mcp_proxy_adapter.core.orchestration.parameter_graph import build_parameter_graph
from mcp_proxy_adapter.core.orchestration.polling_loop import (
    run_one_cycle,
    run_one_cycle_sync,
    run_polling_loop,
)
from mcp_proxy_adapter.core.orchestration.orchestration_api import (
    get_command_schema,
    get_required_parameters,
    get_server,
    get_server_commands,
    get_servers,
    invoke_remote_command,
    validate_call,
)
from mcp_proxy_adapter.core.orchestration.server_record import ServerRecord
from mcp_proxy_adapter.core.orchestration.snapshot_holder import SnapshotHolder
from mcp_proxy_adapter.core.orchestration.tool_context_snapshot import (
    ToolContextSnapshot,
    ToolDescriptor,
)
from mcp_proxy_adapter.core.orchestration.tool_context_exposure import (
    get_tool_descriptors,
)

__all__ = [
    "build_catalog_and_tool_context",
    "CatalogSnapshot",
    "run_one_cycle",
    "run_one_cycle_sync",
    "run_polling_loop",
    "get_command_schema",
    "get_required_parameters",
    "get_server",
    "get_server_commands",
    "get_servers",
    "invoke_remote_command",
    "validate_call",
    "DiscoveryCandidate",
    "run_discovery",
    "SnapshotHolder",
    "build_parameter_graph",
    "validate_candidate",
    "ValidationResult",
    "CommandRecord",
    "ServerRecord",
    "OrchestrationError",
    "ServerNotFoundError",
    "CommandNotFoundError",
    "SchemaUnavailableError",
    "MissingRequiredParametersError",
    "InvalidParameterError",
    "StaleCatalogError",
    "ProxyDiscoveryError",
    "ToolContextBuildError",
    "ToolContextSnapshot",
    "ToolDescriptor",
    "get_tool_descriptors",
]
