"""
Default constants for WebSocket, timeout, and polling configuration.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

All timeout values are in seconds.
A value of 0 means "no timeout" (wait indefinitely).
"""

from typing import Optional


# ---------------------------------------------------------------------------
# WebSocket defaults
# ---------------------------------------------------------------------------

WS_HEARTBEAT_INTERVAL: float = 30.0
"""WebSocket heartbeat (ping/pong) interval in seconds. 0 = disabled."""

WS_RECEIVE_TIMEOUT: float = 60.0
"""WebSocket receive timeout in seconds. 0 = no timeout."""

WS_RECEIVE_TIMEOUT_BUFFER: float = 5.0
"""Extra seconds added to receive_timeout for aiohttp ws_connect."""

WS_SUBSCRIBE_SETTLE_DELAY: float = 0.5
"""Delay (seconds) after WS subscribe task creation before sending RPC."""

WS_JOB_WAIT_TIMEOUT: float = 60.0
"""Default timeout for waiting for job completion via WebSocket. 0 = no timeout."""

# ---------------------------------------------------------------------------
# Command execution defaults
# ---------------------------------------------------------------------------

SYNC_COMMAND_TIMEOUT: float = 30.0
"""Timeout for synchronous command execution via JSON-RPC handler. 0 = no timeout."""

ASYNC_COMMAND_TIMEOUT: float = 300.0
"""Timeout for asynchronous command execution (delivered via WS push). 0 = no timeout."""

# ---------------------------------------------------------------------------
# Job push defaults
# ---------------------------------------------------------------------------

JOB_PUSH_POLL_INTERVAL: float = 1.0
"""Interval between poll loop iterations for subscribed job_ids (seconds)."""

TRANSFER_SESSION_EXPIRY_POLL_INTERVAL: float = 60.0
"""Interval between TTL scans for transfer sessions (seconds)."""

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_INFINITE_TIMEOUT_SECONDS: float = 21_600_000.0
"""Fallback for APIs that require a positive float (6000 hours ≈ 250 days)."""


def resolve_timeout(value: float) -> Optional[float]:
    """Convert timeout: 0 (or negative) → ``None`` (no timeout), positive → seconds.

    Use for APIs that accept ``Optional[float]`` (e.g. ``asyncio.wait_for``,
    aiohttp ``heartbeat``, ``receive_timeout``).
    """
    return None if value <= 0 else value


def resolve_timeout_strict(value: float) -> float:
    """Convert timeout: 0 (or negative) → very large value, positive → seconds.

    Use when the API requires a positive ``float`` and does not accept ``None``.
    The fallback is ``_INFINITE_TIMEOUT_SECONDS`` (6 000 hours).
    """
    return _INFINITE_TIMEOUT_SECONDS if value <= 0 else value
