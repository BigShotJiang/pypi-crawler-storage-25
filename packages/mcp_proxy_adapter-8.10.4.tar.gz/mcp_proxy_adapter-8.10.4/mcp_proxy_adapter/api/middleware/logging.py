"""
Middleware for request logging.
"""

from typing import Dict, Any


from .base import BaseMiddleware


class LoggingMiddleware(BaseMiddleware):
    """
    Middleware for logging requests and responses.
    """

    def __init__(self, app, config: Dict[str, Any] = None):
        """
        Initialize logging middleware.

        Args:
            app: FastAPI application
            config: Application configuration (optional)
        """
        super().__init__(app)
        self.config = config or {}
