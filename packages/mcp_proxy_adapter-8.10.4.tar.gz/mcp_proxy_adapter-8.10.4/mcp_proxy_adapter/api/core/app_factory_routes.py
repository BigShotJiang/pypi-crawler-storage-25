"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Route registration helper for AppFactory.
FastAPI route registration for the MCP proxy adapter application factory.
Registers JSON-RPC, tools, WebSocket, and transfer HTTP endpoints.
"""

from typing import Any, Dict, List, Union, cast

from fastapi import Body, FastAPI, Query, Request, WebSocket
from fastapi.responses import JSONResponse

from mcp_proxy_adapter.api.handlers import (
    complete_upload_session,
    create_download_session,
    create_upload_session,
    download_chunk,
    execute_command_async,
    get_commands_list,
    get_download_status,
    get_server_health,
    get_upload_status,
    handle_batch_json_rpc,
    handle_heartbeat,
    handle_json_rpc,
    upload_chunk,
)
from mcp_proxy_adapter.core.errors import (
    InvalidRequestError,
    MethodNotFoundError,
    ValidationError,
)

try:
    from mcp_proxy_adapter.api.schemas import (
        JsonRpcRequest,
        JsonRpcSuccessResponse,
        JsonRpcErrorResponse,
        HealthResponse,
        CommandListResponse,
        AsyncExecuteRequest,
    )
except Exception:  # pragma: no cover - fallback for simplified environments
    JsonRpcRequest = Dict[str, Any]  # type: ignore
    JsonRpcSuccessResponse = Dict[str, Any]  # type: ignore
    JsonRpcErrorResponse = Dict[str, Any]  # type: ignore
    HealthResponse = Dict[str, Any]  # type: ignore
    CommandListResponse = Dict[str, Any]  # type: ignore
    AsyncExecuteRequest = Dict[str, Any]  # type: ignore

try:
    from mcp_proxy_adapter.api.tools import get_tool_description, execute_tool
except Exception:  # pragma: no cover - optional dependency
    get_tool_description = None
    execute_tool = None

try:
    from mcp_proxy_adapter.api.ws_endpoint import handle_websocket_job_push
except ImportError:  # pragma: no cover
    handle_websocket_job_push = None


def setup_routes(app: FastAPI) -> None:
    """
    Register built-in API routes.

    /ws is always registered when the handler is available. WS is the way
    the server pushes job results to the client (no polling). No config.
    """

    @app.get("/health", response_model=HealthResponse)
    async def health():  # type: ignore
        return await get_server_health()  # type: ignore[misc]

    @app.get("/commands", response_model=CommandListResponse)
    async def commands():  # type: ignore
        return await get_commands_list()  # type: ignore[misc]

    @app.get("/heartbeat")
    async def heartbeat():  # type: ignore
        """Built-in heartbeat endpoint for proxy health checks."""
        return await handle_heartbeat()  # type: ignore[misc]

    @app.post(
        "/api/jsonrpc",
        response_model=Union[JsonRpcSuccessResponse, JsonRpcErrorResponse],
    )
    async def jsonrpc(http_request: Request, body: JsonRpcRequest):  # type: ignore
        request_id = getattr(http_request.state, "request_id", None)
        body_dict = (
            body.model_dump()
            if hasattr(body, "model_dump")
            else cast(Dict[str, Any], body)
        )
        return await handle_json_rpc(body_dict, request_id, http_request)  # type: ignore[misc]

    @app.post(
        "/api/jsonrpc/batch",
        response_model=List[Union[JsonRpcSuccessResponse, JsonRpcErrorResponse]],
    )
    async def jsonrpc_batch(http_request: Request, requests: List[JsonRpcRequest]):  # type: ignore
        payload = [
            (
                req.model_dump()
                if hasattr(req, "model_dump")
                else cast(Dict[str, Any], req)
            )
            for req in requests
        ]
        return await handle_batch_json_rpc(payload, http_request)  # type: ignore[misc]

    @app.post("/api/async")
    async def api_async(request: Request, body: AsyncExecuteRequest) -> Any:
        """
        Accept async command execution; return immediately.
        Response includes server-generated ws_id, job_id null for in-process
        async, and nested delivery; result is delivered via WebSocket to
        subscribers for that ws_id.
        """
        cmd = body.command or ""
        params = body.params or {}
        if not cmd.strip():
            return JSONResponse(
                status_code=400,
                content={"error": "command is required"},
            )
        request_id = getattr(request.state, "request_id", None)
        try:
            result = await execute_command_async(cmd, params, None, request_id, request)
            return result
        except MethodNotFoundError as e:
            return JSONResponse(
                status_code=404,
                content={"error": e.message, "code": e.code, "data": e.data},
            )
        except (ValidationError, InvalidRequestError) as e:
            return JSONResponse(
                status_code=400,
                content={"error": e.message, "code": e.code, "data": e.data},
            )

    @app.post("/tools/{tool_name}")
    async def execute_tool_endpoint(
        tool_name: str,
        request: Request,
        payload: Dict[str, Any] = Body(default_factory=dict),
    ):
        if execute_tool is None:
            raise ValueError("Tool execution is not available in this environment")
        return await execute_tool(tool_name, request, payload)

    @app.get("/tools/{tool_name}")
    async def get_tool_endpoint(tool_name: str):
        if get_tool_description is None:
            raise ValueError("Tool description is not available in this environment")
        return await get_tool_description(tool_name)

    # Transfer HTTP API — registered paths:
    # POST /api/transfer/uploads
    # GET /api/transfer/uploads/{transfer_id}
    # PUT /api/transfer/uploads/{transfer_id}/chunks
    # POST /api/transfer/uploads/{transfer_id}/complete
    # POST /api/transfer/downloads
    # GET /api/transfer/downloads/{transfer_id}
    # GET /api/transfer/downloads/{transfer_id}/chunks

    @app.post("/api/transfer/uploads")
    async def transfer_uploads_create(payload: dict[str, object] = Body(...)):
        return await create_upload_session(payload)

    @app.get("/api/transfer/uploads/{transfer_id}")
    async def transfer_uploads_status(transfer_id: str):
        return await get_upload_status(transfer_id)

    @app.put("/api/transfer/uploads/{transfer_id}/chunks")
    async def transfer_uploads_chunks(
        transfer_id: str,
        request: Request,
        offset: int = Query(..., ge=0),
    ):
        return await upload_chunk(transfer_id, offset, request)

    @app.post("/api/transfer/uploads/{transfer_id}/complete")
    async def transfer_uploads_complete(transfer_id: str):
        return await complete_upload_session(transfer_id)

    @app.post("/api/transfer/downloads")
    async def transfer_downloads_create(payload: dict[str, object] = Body(...)):
        return await create_download_session(payload)

    @app.get("/api/transfer/downloads/{transfer_id}")
    async def transfer_downloads_status(transfer_id: str):
        return await get_download_status(transfer_id)

    @app.get("/api/transfer/downloads/{transfer_id}/chunks")
    async def transfer_downloads_chunks(
        transfer_id: str,
        offset: int = Query(..., ge=0),
        limit: int = Query(..., ge=1),
    ):
        return await download_chunk(transfer_id, offset, limit)

    if handle_websocket_job_push is not None:

        @app.websocket("/ws")
        async def websocket_job_push(websocket: WebSocket) -> None:
            await handle_websocket_job_push(websocket, app)
