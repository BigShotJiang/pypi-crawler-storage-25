"""JSON-RPC handlers for adapter-side job status snapshot API.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from fastapi import Request

from mcp_proxy_adapter.core.errors import InternalError, ValidationError
from mcp_proxy_adapter.core.job_push.job_status_accumulator import JobStatusAccumulator


def _opt_str(params: Dict[str, Any], key: str) -> str:
    raw = params.get(key)
    if raw is None:
        return ""
    return str(raw).strip()


def _get_accumulator(request: Optional[Request]) -> JobStatusAccumulator:
    if request is None or not hasattr(request, "app"):
        raise InternalError("job status API requires request context")
    acc = getattr(request.app.state, "job_status_accumulator", None)
    if not isinstance(acc, JobStatusAccumulator):
        raise InternalError(
            "Job status accumulation is not enabled (job_push not started or missing accumulator)"
        )
    return acc


async def jsonrpc_job_status_register(
    params: Dict[str, Any], request: Optional[Request] = None
) -> Dict[str, Any]:
    """Register tracking for job_id and/or ws_id; optional WsDeliveryManager mapping."""
    acc = _get_accumulator(request)
    jid = _opt_str(params, "job_id") or None
    wid = _opt_str(params, "ws_id") or None
    manager = None
    if request is not None and hasattr(request, "app"):
        manager = getattr(request.app.state, "ws_delivery_manager", None)
    return await acc.register(job_id=jid, ws_id=wid, ws_delivery_manager=manager)


async def jsonrpc_job_status_get(
    params: Dict[str, Any], request: Optional[Request] = None
) -> Dict[str, Any]:
    """Return current snapshot dict or success wrapper with null data if none."""
    acc = _get_accumulator(request)
    jid = _opt_str(params, "job_id") or None
    wid = _opt_str(params, "ws_id") or None
    if not jid and not wid:
        raise ValidationError("job_status_get requires job_id and/or ws_id")
    snap = await acc.get_snapshot(job_id=jid, ws_id=wid)
    if snap is None:
        return {"success": True, "data": None}
    return {"success": True, "data": dict(snap)}


async def jsonrpc_job_status_wait(
    params: Dict[str, Any], request: Optional[Request] = None
) -> Dict[str, Any]:
    """Wait until terminal snapshot or timeout (default predicate: terminal flag)."""
    acc = _get_accumulator(request)
    jid = _opt_str(params, "job_id") or None
    wid = _opt_str(params, "ws_id") or None
    if not jid and not wid:
        raise ValidationError("job_status_wait requires job_id and/or ws_id")
    raw_timeout = params.get("timeout_seconds")
    timeout: Optional[float]
    if raw_timeout is None:
        timeout = 300.0
    else:
        try:
            timeout = float(raw_timeout)
        except (TypeError, ValueError) as exc:
            raise ValidationError("timeout_seconds must be a number") from exc
        if timeout < 0:
            raise ValidationError("timeout_seconds must be non-negative")
    snap, timed_out = await acc.wait_for(job_id=jid, ws_id=wid, timeout=timeout)
    if snap is None:
        return {"success": True, "data": None, "timed_out": timed_out}
    return {"success": True, "data": dict(snap), "timed_out": timed_out}


async def jsonrpc_job_status_unregister(
    params: Dict[str, Any], request: Optional[Request] = None
) -> Dict[str, Any]:
    """Explicitly stop tracking (optional cleanup)."""
    acc = _get_accumulator(request)
    jid = _opt_str(params, "job_id") or None
    wid = _opt_str(params, "ws_id") or None
    if not jid and not wid:
        raise ValidationError("job_status_unregister requires job_id and/or ws_id")
    await acc.unregister(job_id=jid, ws_id=wid)
    return {"success": True}
