"""In-process bounded job event history and TTL cleanup for client tracking.

Per-job_id deques of recent WebSocket/job messages and a latest JobStatusSnapshot.
After a queue-job terminal event, state is retained for *post_terminal_ttl_sec*
then dropped on next access to that job_id (lazy eviction).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import asyncio
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Deque, Dict, List, Mapping, Optional

from mcp_proxy_adapter.client.jsonrpc_client.job_tracking_types import (
    JobCoarsePhase,
    JobStatusSnapshot,
    TerminalDomain,
    classify_terminal_event,
    execution_status_to_coarse_phase,
)


def _extract_execution_status(raw: Mapping[str, Any]) -> Optional[str]:
    st = raw.get("status")
    if isinstance(st, str) and st.strip():
        return st.strip()
    data = raw.get("data")
    if isinstance(data, dict):
        inner = data.get("status")
        if isinstance(inner, str) and inner.strip():
            return inner.strip()
    return None


@dataclass
class _JobTrackState:
    events: Deque[Dict[str, Any]] = field(default_factory=deque)
    snapshot_version: int = 0
    last_updated_monotonic: float = 0.0
    execution_status: Optional[str] = None
    last_ws_event: Optional[str] = None
    is_terminal: bool = False
    terminal_domain: str = TerminalDomain.NONE.value
    normalized_terminal: Optional[str] = None
    coarse_phase: str = JobCoarsePhase.UNKNOWN.value
    terminal_seen_at_monotonic: Optional[float] = None
    summary: Dict[str, Any] = field(default_factory=dict)

    def to_snapshot(self, job_id: str) -> JobStatusSnapshot:
        return JobStatusSnapshot(
            job_id=job_id,
            coarse_phase=self.coarse_phase,
            is_terminal=self.is_terminal,
            terminal_domain=self.terminal_domain,
            normalized_terminal=self.normalized_terminal,
            snapshot_version=self.snapshot_version,
            last_updated_monotonic=self.last_updated_monotonic,
            execution_status=self.execution_status,
            last_ws_event=self.last_ws_event,
            summary=dict(self.summary),
        )


class JobEventRegistry:
    """
    Asyncio-safe registry: bounded deque per job_id + latest snapshot + TTL.

    Default *max_events* is 64 per job. After a queue-job terminal is recorded,
    the bucket is kept for *post_terminal_ttl_sec* (default 300s), then removed
    on the next touch (append, read, or merge).
    """

    def __init__(
        self,
        *,
        max_events: int = 64,
        post_terminal_ttl_sec: float = 300.0,
    ) -> None:
        if max_events < 1:
            raise ValueError("max_events must be >= 1")
        if post_terminal_ttl_sec < 0:
            raise ValueError("post_terminal_ttl_sec must be >= 0")
        self._max_events = max_events
        self._post_terminal_ttl_sec = post_terminal_ttl_sec
        self._lock = asyncio.Lock()
        self._jobs: Dict[str, _JobTrackState] = {}
        self._listeners: Dict[str, List[Any]] = {}

    async def append_message(
        self,
        job_id: str,
        message: Mapping[str, Any],
        *,
        for_queue_job_domain: bool = True,
    ) -> None:
        """Append a structured message and update snapshot; notify listeners."""
        jid = job_id.strip()
        if not jid:
            raise ValueError("job_id must be non-empty")
        payload = dict(message)
        async with self._lock:
            self._prune_expired_unlocked(jid)
            state = self._jobs.get(jid)
            if state is None:
                state = _JobTrackState()
                self._jobs[jid] = state
            state.events.append(payload)
            while len(state.events) > self._max_events:
                state.events.popleft()
            self._apply_ws_payload_unlocked(state, payload, for_queue_job_domain)
            listeners = list(self._listeners.get(jid, ()))

        for cb in listeners:
            res = cb(payload)
            if asyncio.iscoroutine(res):
                await res

    def _apply_ws_payload_unlocked(
        self,
        state: _JobTrackState,
        payload: Mapping[str, Any],
        for_queue_job_domain: bool,
    ) -> None:
        now = time.monotonic()
        state.last_updated_monotonic = now
        state.snapshot_version += 1
        ev_raw = payload.get("event") if "event" in payload else payload.get("type")
        if isinstance(ev_raw, str):
            state.last_ws_event = ev_raw.strip() or state.last_ws_event
        domain, norm = classify_terminal_event(ev_raw)
        if for_queue_job_domain and domain == TerminalDomain.QUEUE_JOB:
            state.is_terminal = True
            state.terminal_domain = TerminalDomain.QUEUE_JOB.value
            state.normalized_terminal = norm
            state.coarse_phase = JobCoarsePhase.TERMINAL.value
            state.terminal_seen_at_monotonic = now
        elif domain == TerminalDomain.DELIVERY:
            state.is_terminal = True
            state.terminal_domain = TerminalDomain.DELIVERY.value
            state.normalized_terminal = norm
            state.coarse_phase = JobCoarsePhase.TERMINAL.value
            state.terminal_seen_at_monotonic = now
        elif domain == TerminalDomain.NONE:
            if state.coarse_phase not in (JobCoarsePhase.TERMINAL.value,):
                if state.coarse_phase == JobCoarsePhase.UNKNOWN.value:
                    state.coarse_phase = JobCoarsePhase.RUNNING.value
        state.summary["last_message"] = dict(payload)

    async def merge_queue_poll(self, job_id: str, raw: Mapping[str, Any]) -> None:
        """Merge queue_get_job_status / embed response into snapshot."""
        jid = job_id.strip()
        if not jid:
            raise ValueError("job_id must be non-empty")
        async with self._lock:
            self._prune_expired_unlocked(jid)
            state = self._jobs.get(jid)
            if state is None:
                state = _JobTrackState()
                self._jobs[jid] = state
            ex = _extract_execution_status(raw)
            if ex is not None:
                state.execution_status = ex
            phase = execution_status_to_coarse_phase(state.execution_status)
            if phase == JobCoarsePhase.TERMINAL:
                state.coarse_phase = JobCoarsePhase.TERMINAL.value
                state.is_terminal = True
                if state.terminal_domain == TerminalDomain.NONE.value:
                    state.terminal_domain = TerminalDomain.QUEUE_JOB.value
                if state.terminal_seen_at_monotonic is None:
                    state.terminal_seen_at_monotonic = time.monotonic()
            elif phase == JobCoarsePhase.QUEUED:
                if state.coarse_phase == JobCoarsePhase.UNKNOWN.value:
                    state.coarse_phase = JobCoarsePhase.QUEUED.value
            elif phase == JobCoarsePhase.RUNNING:
                if state.coarse_phase not in (JobCoarsePhase.TERMINAL.value,):
                    state.coarse_phase = JobCoarsePhase.RUNNING.value
            state.last_updated_monotonic = time.monotonic()
            state.snapshot_version += 1
            state.summary["last_queue_poll"] = dict(raw)

    async def get_snapshot(self, job_id: str) -> JobStatusSnapshot:
        """Return current snapshot or *unknown* for unseen/expired jobs."""
        jid = job_id.strip()
        if not jid:
            raise ValueError("job_id must be non-empty")
        async with self._lock:
            self._prune_expired_unlocked(jid)
            state = self._jobs.get(jid)
            if state is None:
                return JobStatusSnapshot.unknown(jid)
            return state.to_snapshot(jid)

    async def get_messages(
        self, job_id: str, *, limit: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """Return recent messages oldest-to-newest, optionally truncated tail."""
        jid = job_id.strip()
        if not jid:
            raise ValueError("job_id must be non-empty")
        async with self._lock:
            self._prune_expired_unlocked(jid)
            state = self._jobs.get(jid)
            if state is None:
                return []
            items = list(state.events)
            if limit is not None and limit >= 0 and len(items) > limit:
                return items[-limit:]
            return items

    async def clear_job(self, job_id: str) -> None:
        """Explicitly remove tracking state for *job_id*."""
        jid = job_id.strip()
        if not jid:
            raise ValueError("job_id must be non-empty")
        async with self._lock:
            self._jobs.pop(jid, None)
            self._listeners.pop(jid, None)

    async def add_listener(
        self,
        job_id: str,
        callback: Callable[[Mapping[str, Any]], Any],
    ) -> Callable[[], Awaitable[None]]:
        """
        Register *callback* invoked after each append for *job_id*.

        *callback* may be sync or async (coroutine). Returns ``unsubscribe`` coroutine
        function: ``await unsubscribe()`` removes the listener.
        """
        jid = job_id.strip()
        if not jid:
            raise ValueError("job_id must be non-empty")

        async def _unsub() -> None:
            async with self._lock:
                lst = self._listeners.get(jid)
                if not lst:
                    return
                try:
                    lst.remove(callback)
                except ValueError:
                    return
                if not lst:
                    self._listeners.pop(jid, None)

        async with self._lock:
            self._listeners.setdefault(jid, []).append(callback)
        return _unsub

    def _prune_expired_unlocked(self, job_id: str) -> None:
        state = self._jobs.get(job_id)
        if state is None:
            return
        if self._is_expired_unlocked(state):
            self._jobs.pop(job_id, None)
            self._listeners.pop(job_id, None)

    def _is_expired_unlocked(self, state: _JobTrackState) -> bool:
        if state.terminal_seen_at_monotonic is None:
            return False
        if self._post_terminal_ttl_sec == 0:
            return True
        return (
            time.monotonic() - state.terminal_seen_at_monotonic
            >= self._post_terminal_ttl_sec
        )


__all__ = ["JobEventRegistry"]
