"""Thin accessors for transfer upload/download integrity fields on the client.

Surfaces digest and verification fields already present on receipt models; does
not perform cryptographic verification locally.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

from typing import Any

from mcp_proxy_adapter.transfer.models import TransferDownloadReceipt, TransferReceipt


def summarize_upload_receipt(receipt: TransferReceipt) -> dict[str, Any]:
    """
    Structured source-digest summary for an upload receipt.

    Command or queue JSON-RPC payloads generally do not include these fields.
    """
    return {
        "transfer_id": receipt.transfer_id,
        "filename": receipt.filename,
        "size_bytes": receipt.size_bytes,
        "checksum_algorithm": receipt.checksum_algorithm,
        "checksum_value": receipt.checksum_value,
        "compression": receipt.compression,
        "status": receipt.status,
        "completed": receipt.completed,
        "plaintext_size_bytes": receipt.plaintext_size_bytes,
    }


def summarize_download_receipt(receipt: TransferDownloadReceipt) -> dict[str, Any]:
    """
    Structured digest and verification summary for a download receipt.

    ``checksum_verified`` reflects server-side verification outcome already
    encoded in the receipt.
    """
    return {
        "transfer_id": receipt.transfer_id,
        "destination_path": receipt.destination_path,
        "offset": receipt.offset,
        "size_bytes": receipt.size_bytes,
        "checksum_algorithm": receipt.checksum_algorithm,
        "checksum_value": receipt.checksum_value,
        "compression": receipt.compression,
        "status": receipt.status,
        "completed": receipt.completed,
        "checksum_verified": receipt.checksum_verified,
    }


__all__ = ["summarize_download_receipt", "summarize_upload_receipt"]
