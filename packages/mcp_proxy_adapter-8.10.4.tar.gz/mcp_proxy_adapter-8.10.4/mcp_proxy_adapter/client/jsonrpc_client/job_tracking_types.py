"""Normalized terminal semantics and job status snapshot types for client tracking.

Single adapter-level vocabulary for queue-job WebSocket terminals vs delivery
terminals, and a stable snapshot shape for ``get_job_status(job_id)``.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping, Optional

# Queue job WS terminals (subscription_type queue_job) — aligned with ws_job_status.
QUEUE_JOB_TERMINAL_EVENTS = frozenset({"job_completed", "job_failed", "job_stopped"})

# Delivery WS terminals (subscription_type ws_delivery) — aligned with ws_job_status.
DELIVERY_TERMINAL_EVENTS = frozenset(
    {"delivery_completed", "delivery_failed", "delivery_cancelled"}
)


class TerminalDomain(str, Enum):
    """Whether a terminal event belongs to queue execution or delivery channel."""

    NONE = "none"
    QUEUE_JOB = "queue_job"
    DELIVERY = "delivery"


class JobCoarsePhase(str, Enum):
    """Coarse lifecycle phase for a tracked job (client-side view)."""

    UNKNOWN = "unknown"
    QUEUED = "queued"
    RUNNING = "running"
    TERMINAL = "terminal"


def classify_terminal_event(
    event: Any,
) -> tuple[TerminalDomain, Optional[str]]:
    """
    Map a raw event/type string to terminal domain and normalized name.

    Returns:
        (TerminalDomain.NONE, None) when the event is not a known terminal.
    """
    if not isinstance(event, str):
        return TerminalDomain.NONE, None
    ev = event.strip()
    if ev in QUEUE_JOB_TERMINAL_EVENTS:
        return TerminalDomain.QUEUE_JOB, ev
    if ev in DELIVERY_TERMINAL_EVENTS:
        return TerminalDomain.DELIVERY, ev
    return TerminalDomain.NONE, None


def is_queue_terminal_event(event: Any) -> bool:
    """True if *event* is a queue-job terminal (job_completed, job_failed, job_stopped)."""
    domain, _ = classify_terminal_event(event)
    return domain == TerminalDomain.QUEUE_JOB


def execution_status_to_coarse_phase(status: Optional[str]) -> JobCoarsePhase:
    """Best-effort coarse phase from queue/embed execution *status* string."""
    if status is None or not str(status).strip():
        return JobCoarsePhase.UNKNOWN
    s = str(status).strip().lower()
    if s in {"pending", "queued"}:
        return JobCoarsePhase.QUEUED
    if s in {"running", "in_progress"}:
        return JobCoarsePhase.RUNNING
    if s in {
        "completed",
        "success",
        "failed",
        "error",
        "timeout",
        "stopped",
        "cancelled",
    }:
        return JobCoarsePhase.TERMINAL
    return JobCoarsePhase.RUNNING


@dataclass(frozen=True)
class JobStatusSnapshot:
    """
    Immutable snapshot for ``get_job_status(job_id)``.

    *summary* holds a shallow, JSON-adjacent summary (e.g. last WS payload keys);
    extend with new keys additively without breaking callers.
    """

    job_id: str
    coarse_phase: str
    is_terminal: bool
    terminal_domain: str
    normalized_terminal: Optional[str]
    snapshot_version: int
    last_updated_monotonic: float
    execution_status: Optional[str]
    last_ws_event: Optional[str]
    summary: Mapping[str, Any] = field(default_factory=dict)

    @staticmethod
    def unknown(job_id: str) -> "JobStatusSnapshot":
        """Snapshot for a job_id the client has never observed."""
        return JobStatusSnapshot(
            job_id=job_id,
            coarse_phase=JobCoarsePhase.UNKNOWN.value,
            is_terminal=False,
            terminal_domain=TerminalDomain.NONE.value,
            normalized_terminal=None,
            snapshot_version=0,
            last_updated_monotonic=0.0,
            execution_status=None,
            last_ws_event=None,
            summary={},
        )


__all__ = [
    "DELIVERY_TERMINAL_EVENTS",
    "QUEUE_JOB_TERMINAL_EVENTS",
    "JobCoarsePhase",
    "JobStatusSnapshot",
    "TerminalDomain",
    "classify_terminal_event",
    "execution_status_to_coarse_phase",
    "is_queue_terminal_event",
]
