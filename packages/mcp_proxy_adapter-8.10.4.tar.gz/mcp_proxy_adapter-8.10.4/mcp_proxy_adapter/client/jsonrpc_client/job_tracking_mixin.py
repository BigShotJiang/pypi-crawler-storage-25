"""High-level async job tracking: snapshots, bounded history, WS iteration, wait.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, AsyncIterator, Awaitable, Callable, Dict, Optional, Union

from mcp_proxy_adapter.client.jsonrpc_client.job_event_registry import JobEventRegistry
from mcp_proxy_adapter.client.jsonrpc_client.job_tracking_types import JobStatusSnapshot
from mcp_proxy_adapter.client.jsonrpc_client.transport import JsonRpcTransport
from mcp_proxy_adapter.client.jsonrpc_client.ws_job_status import WS_TERMINAL_EVENTS
from mcp_proxy_adapter.core.constants import WS_JOB_WAIT_TIMEOUT

logger = logging.getLogger(__name__)

JobEventCallback = Union[
    Callable[[Dict[str, Any]], None],
    Callable[[Dict[str, Any]], Awaitable[None]],
]


class JobTrackingMixin(JsonRpcTransport):
    """
    Client-side job tracking registry and helpers.

    Uses an in-process :class:`JobEventRegistry` (bounded history + TTL after
    terminal). Mixed into :class:`JsonRpcClient` after queue APIs so
    ``queue_get_job_status`` / ``wait_for_job_via_websocket`` resolve correctly.
    """

    _job_event_registry: JobEventRegistry

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._job_event_registry = JobEventRegistry()

    async def _record_queue_job_ws_message(
        self,
        job_id: str,
        message: Dict[str, Any],
    ) -> None:
        """Append a queue-job WebSocket payload to the tracking registry."""
        await self._job_event_registry.append_message(
            job_id,
            message,
            for_queue_job_domain=True,
        )

    async def get_job_status(
        self,
        job_id: str,
        *,
        sync_from_queue: bool = False,
    ) -> JobStatusSnapshot:
        """
        Return the normalized status snapshot for *job_id*.

        If *sync_from_queue* is True, call ``queue_get_job_status`` (including
        embed fallback) and merge the result into the snapshot. WS-derived
        fields take precedence for events already recorded; queue poll fills
        execution_status when the server does not push granular WS updates.

        When *sync_from_queue* is False, only the in-process registry is used;
        unseen jobs yield ``JobStatusSnapshot.unknown``.
        """
        jid = job_id.strip()
        if not jid:
            raise ValueError("job_id must be non-empty")
        if sync_from_queue:
            raw = await self.queue_get_job_status(jid)  # type: ignore[attr-defined]
            await self._job_event_registry.merge_queue_poll(jid, raw)
        return await self._job_event_registry.get_snapshot(jid)

    async def get_job_messages(
        self,
        job_id: str,
        *,
        limit: Optional[int] = None,
    ) -> list[Dict[str, Any]]:
        """Return bounded recent WS/job messages for *job_id* (oldest first)."""
        jid = job_id.strip()
        if not jid:
            raise ValueError("job_id must be non-empty")
        return await self._job_event_registry.get_messages(jid, limit=limit)

    async def add_job_event_listener(
        self,
        job_id: str,
        callback: JobEventCallback,
    ) -> Callable[[], Awaitable[None]]:
        """
        Register *callback* for each recorded message for *job_id*.

        Async contract: *callback* may be synchronous or async; it is invoked
        after the message is stored. Returns ``unsubscribe`` such that
        ``await unsubscribe()`` removes the listener.
        """
        return await self._job_event_registry.add_listener(job_id, callback)

    async def clear_job_tracking(self, job_id: str) -> None:
        """Remove registry state and listeners for *job_id*."""
        await self._job_event_registry.clear_job(job_id)

    async def wait_for_job(
        self,
        job_id: str,
        *,
        timeout: Optional[float] = None,
        on_event: Optional[Callable[[Dict[str, Any]], Any]] = None,
    ) -> Dict[str, Any]:
        """
        Wait for a queue-job terminal over ``/ws``, recording events to the registry.

        Wraps :func:`wait_for_job_via_websocket` with optional *on_event* hook
        (sync or async) invoked for each inbound message after recording.
        """
        jid = job_id.strip()
        if not jid:
            raise ValueError("job_id must be non-empty")

        async def _hook(msg: Dict[str, Any]) -> None:
            await self._record_queue_job_ws_message(jid, msg)
            if on_event is not None:
                out = on_event(msg)
                if asyncio.iscoroutine(out):
                    await out

        eff = timeout if timeout is not None else WS_JOB_WAIT_TIMEOUT
        return await self.wait_for_job_via_websocket(  # type: ignore[attr-defined]
            jid,
            timeout=eff,
            on_inbound_message=_hook,
        )

    async def iter_job_ws_events(
        self,
        job_id: str,
    ) -> AsyncIterator[Dict[str, Any]]:
        """
        Subscribe to ``queue_job`` events for *job_id* and yield each message.

        Records every message to the tracking registry. Stops after a terminal
        queue event for this *job_id* (or when the connection ends). Unsubscribes
        best-effort before exiting the context.
        """
        jid = job_id.strip()
        if not jid:
            raise ValueError("job_id must be non-empty")

        async def _hook(msg: Dict[str, Any]) -> None:
            await self._record_queue_job_ws_message(jid, msg)

        channel = self.open_bidirectional_ws_channel(  # type: ignore[attr-defined]
            on_inbound_message=_hook,
        )
        async with channel:
            await channel.send_json(
                {
                    "action": "subscribe",
                    "subscription_type": "queue_job",
                    "job_id": jid,
                }
            )
            try:
                async for msg in channel.receive_iter():
                    yield msg
                    ev = msg.get("event") or msg.get("type")
                    if ev in WS_TERMINAL_EVENTS:
                        mid = msg.get("job_id")
                        if mid is None or mid == jid:
                            break
            finally:
                try:
                    await channel.send_json(
                        {
                            "action": "unsubscribe",
                            "subscription_type": "queue_job",
                            "job_id": jid,
                        }
                    )
                except Exception as exc:  # pragma: no cover - best-effort
                    logger.debug("iter_job_ws_events: unsubscribe failed: %s", exc)


__all__ = ["JobTrackingMixin", "JobEventCallback"]
