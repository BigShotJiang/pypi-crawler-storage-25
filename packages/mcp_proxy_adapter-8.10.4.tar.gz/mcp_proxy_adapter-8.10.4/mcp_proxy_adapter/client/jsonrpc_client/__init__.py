"""JSON-RPC client package facade.

Tracking API entry points (async jobs / WebSocket):

- :class:`JsonRpcClient` — ``get_job_status``, ``get_job_messages``,
  ``iter_job_ws_events``, ``wait_for_job``, ``add_job_event_listener``,
  ``clear_job_tracking``, and transfer integrity helpers on upload/download
  receipts.
- Types: :class:`JobStatusSnapshot`, :class:`JobCoarsePhase`,
  :class:`TerminalDomain`, helpers in :mod:`job_tracking_types`.
- WebSocket wait helpers: ``wait_for_job_via_websocket``,
  ``wait_for_terminal_delivery_via_websocket``, bidirectional channel
  factories.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from mcp_proxy_adapter.client.jsonrpc_client.client import JsonRpcClient
from mcp_proxy_adapter.client.jsonrpc_client.exceptions import (
    ClientConnectionError,
    ClientError,
    ClientRequestError,
    InvalidParameterTypeError,
    InvalidParameterValueError,
    MethodNotFoundError,
    RequiredParameterMissingError,
    SchemaGeneratorError,
    SchemaValidationError,
    TransferChecksumMismatchClientError,
)
from mcp_proxy_adapter.client.jsonrpc_client.job_tracking_types import (
    JobCoarsePhase,
    JobStatusSnapshot,
    TerminalDomain,
    classify_terminal_event,
)
from mcp_proxy_adapter.client.jsonrpc_client.openapi_validator import OpenAPIValidator
from mcp_proxy_adapter.client.jsonrpc_client.queue_status import QueueJobStatus
from mcp_proxy_adapter.client.jsonrpc_client.schema_generator import (
    MethodInfo,
    ParameterInfo,
    SchemaRequestGenerator,
)
from mcp_proxy_adapter.client.jsonrpc_client.transfer_integrity import (
    summarize_download_receipt,
    summarize_upload_receipt,
)
from mcp_proxy_adapter.client.jsonrpc_client.ws_job_status import (
    BidirectionalWsChannel,
    open_bidirectional_ws_channel,
    wait_for_job_via_websocket,
    wait_for_terminal_delivery_via_websocket,
)

__all__ = [
    "BidirectionalWsChannel",
    "ClientConnectionError",
    "ClientError",
    "ClientRequestError",
    "InvalidParameterTypeError",
    "InvalidParameterValueError",
    "JobCoarsePhase",
    "JobStatusSnapshot",
    "JsonRpcClient",
    "MethodInfo",
    "MethodNotFoundError",
    "OpenAPIValidator",
    "ParameterInfo",
    "QueueJobStatus",
    "RequiredParameterMissingError",
    "SchemaGeneratorError",
    "SchemaRequestGenerator",
    "SchemaValidationError",
    "TerminalDomain",
    "TransferChecksumMismatchClientError",
    "classify_terminal_event",
    "open_bidirectional_ws_channel",
    "summarize_download_receipt",
    "summarize_upload_receipt",
    "wait_for_job_via_websocket",
    "wait_for_terminal_delivery_via_websocket",
]
