"""Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Shared transfer progress_percent computation for WS and HTTP (parent spec §7).
"""

from __future__ import annotations


def compute_transfer_progress_percent(
    offset: int,
    size_bytes: int,
    *,
    terminal: bool = False,
) -> int:
    """Return progress_percent in 0..100 per control_plane_websocket_events spec §7."""
    off = int(offset)
    off_clamped = max(0, off)
    size = int(size_bytes)
    if size > 0:
        raw = (100 * off_clamped) // size
        return min(100, max(0, raw))
    if terminal:
        return 100
    return 0
