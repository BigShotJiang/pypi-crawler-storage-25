"""
Tests: queue manager fail-fast on lifespan startup when enabled.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import logging
from unittest.mock import AsyncMock, patch

import pytest
from fastapi import FastAPI

from mcp_proxy_adapter.api.core.lifespan_manager import LifespanManager


@pytest.mark.asyncio
async def test_lifespan_queue_enabled_init_failure_aborts_startup(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """When queue_manager.enabled is True and init fails, lifespan startup must raise."""
    app = FastAPI()
    mgr = LifespanManager()
    lifespan_factory = mgr.create_lifespan(
        current_config={"queue_manager": {"enabled": True}},
    )
    ctx = lifespan_factory(app)
    with caplog.at_level(logging.ERROR):
        with patch(
            "mcp_proxy_adapter.integrations.queuemgr_integration.init_global_queue_manager",
            new_callable=AsyncMock,
            side_effect=RuntimeError("queue init failed"),
        ):
            with pytest.raises(RuntimeError, match="queue init failed"):
                async with ctx:
                    pass
    assert "queue_manager.enabled to false" in caplog.text


@pytest.mark.asyncio
async def test_lifespan_queue_disabled_does_not_call_init_startup_completes() -> None:
    """When queue_manager.enabled is False, startup completes without calling init."""
    app = FastAPI()
    mgr = LifespanManager()
    lifespan_factory = mgr.create_lifespan(
        current_config={"queue_manager": {"enabled": False}},
    )
    ctx = lifespan_factory(app)
    mock_init = AsyncMock(side_effect=RuntimeError("init should not run"))
    with patch(
        "mcp_proxy_adapter.integrations.queuemgr_integration.init_global_queue_manager",
        mock_init,
    ):
        async with ctx:
            pass
    mock_init.assert_not_called()
