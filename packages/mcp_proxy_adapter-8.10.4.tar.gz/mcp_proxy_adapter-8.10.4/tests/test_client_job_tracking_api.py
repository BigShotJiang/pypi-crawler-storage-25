"""Tests for JsonRpcClient job tracking API and unified status_hook."""

from __future__ import annotations

from typing import Any, Dict
from unittest.mock import AsyncMock, patch

import pytest

from mcp_proxy_adapter.client.jsonrpc_client.client import JsonRpcClient
from mcp_proxy_adapter.client.jsonrpc_client.job_tracking_types import JobCoarsePhase


@pytest.mark.asyncio
async def test_get_job_status_unknown_without_sync() -> None:
    client = JsonRpcClient(protocol="http", host="127.0.0.1", port=9)
    snap = await client.get_job_status("missing-job")
    assert snap.coarse_phase == JobCoarsePhase.UNKNOWN.value
    assert snap.snapshot_version == 0


@pytest.mark.asyncio
async def test_get_job_status_sync_from_queue_merges() -> None:
    client = JsonRpcClient(protocol="http", host="127.0.0.1", port=9)
    with patch.object(
        client,
        "queue_get_job_status",
        new=AsyncMock(return_value={"status": "completed", "data": {}}),
    ):
        snap = await client.get_job_status("jq", sync_from_queue=True)
    assert snap.execution_status == "completed"
    assert snap.is_terminal is True


@pytest.mark.asyncio
async def test_wait_for_job_records_and_hook() -> None:
    client = JsonRpcClient(protocol="http", host="127.0.0.1", port=9)
    hook_calls: list[Dict[str, Any]] = []

    async def fake_wait(
        job_id: str,
        timeout: float = 1.0,
        *,
        on_inbound_message: Any = None,
    ) -> Dict[str, Any]:
        assert on_inbound_message is not None
        await on_inbound_message({"event": "running", "job_id": job_id})
        return {"event": "job_completed", "job_id": job_id, "result": {"ok": True}}

    async def on_event(msg: Dict[str, Any]) -> None:
        hook_calls.append(msg)

    client.wait_for_job_via_websocket = AsyncMock(side_effect=fake_wait)

    out = await client.wait_for_job("j1", on_event=on_event)

    assert out["event"] == "job_completed"
    msgs = await client.get_job_messages("j1")
    assert len(msgs) == 1
    assert msgs[0]["event"] == "running"
    assert len(hook_calls) == 1


@pytest.mark.asyncio
async def test_execute_command_unified_status_hook_ws_path() -> None:
    client = JsonRpcClient(protocol="http", host="127.0.0.1", port=9)
    stages: list[str] = []

    async def fake_wait(
        transport: object,
        job_id: str,
        timeout: float = 1.0,
        heartbeat: float = 1.0,
        *,
        on_inbound_message: Any = None,
    ) -> Dict[str, Any]:
        if on_inbound_message:
            await on_inbound_message({"event": "progress", "job_id": job_id})
        return {"event": "job_completed", "job_id": job_id, "result": {"x": 1}}

    async def hook(msg: Dict[str, Any]) -> None:
        ev = str(msg.get("event") or msg.get("status") or "")
        stages.append(ev)

    with patch.object(client, "execute_command", new_callable=AsyncMock) as em:
        em.return_value = {"job_id": "q1", "status": "queued"}
        with patch(
            "mcp_proxy_adapter.client.jsonrpc_client.command_api.wait_for_job_via_websocket",
            new=fake_wait,
        ):
            result = await client.execute_command_unified(
                "demo",
                {},
                auto_poll=True,
                status_hook=hook,
            )

    assert result["mode"] == "queued"
    assert "queued" in stages
    assert "progress" in stages


@pytest.mark.asyncio
async def test_transfer_integrity_summaries() -> None:
    from mcp_proxy_adapter.transfer.models import (
        TransferDownloadReceipt,
        TransferReceipt,
    )

    client = JsonRpcClient(protocol="http", host="127.0.0.1", port=9)
    up = TransferReceipt(
        transfer_id="t1",
        filename="f.bin",
        size_bytes=3,
        checksum_algorithm="sha256",
        checksum_value="a" * 64,
        compression="identity",
        chunk_size=1024,
        offset=3,
        status="uploaded",
        completed=True,
        expires_at=None,
    )
    d = TransferDownloadReceipt(
        transfer_id="t1",
        destination_path="/tmp/f.bin",
        offset=3,
        size_bytes=3,
        checksum_algorithm="sha256",
        checksum_value="b" * 64,
        compression="identity",
        status="completed",
        completed=True,
        checksum_verified=True,
    )
    assert client.describe_transfer_upload_integrity(up)["checksum_value"] == "a" * 64
    assert client.describe_transfer_download_integrity(d)["checksum_verified"] is True


def test_transfer_checksum_mismatch_exportable() -> None:
    from mcp_proxy_adapter.client.jsonrpc_client import (
        TransferChecksumMismatchClientError,
    )

    assert issubclass(TransferChecksumMismatchClientError, Exception)


def test_job_tracking_demo_module_importable() -> None:
    import mcp_proxy_adapter.examples.job_tracking_demo as demo

    assert demo.__doc__
    assert hasattr(demo, "main")
