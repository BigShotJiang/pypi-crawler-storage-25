"""
Unit tests for JsonRpcClient.help parameter mapping (cmdname vs server schema).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from mcp_proxy_adapter.client.jsonrpc_client.client import JsonRpcClient


@pytest.mark.asyncio
async def test_help_with_command_name_sends_cmdname_param() -> None:
    """Detailed help must use cmdname, matching HelpCommand / JSON-RPC schema."""
    client = JsonRpcClient(host="127.0.0.1", port=8080)
    with patch.object(client, "jsonrpc_call", new_callable=AsyncMock) as mock_rpc:
        mock_rpc.return_value = {
            "jsonrpc": "2.0",
            "result": {"success": True, "data": {}},
            "id": 1,
        }
        await client.help("echo")
        mock_rpc.assert_awaited_once_with("help", {"cmdname": "echo"})


@pytest.mark.asyncio
async def test_help_without_command_name_sends_empty_params() -> None:
    """Compact listing uses empty params."""
    client = JsonRpcClient(host="127.0.0.1", port=8080)
    with patch.object(client, "jsonrpc_call", new_callable=AsyncMock) as mock_rpc:
        mock_rpc.return_value = {
            "jsonrpc": "2.0",
            "result": {"success": True, "data": {}},
            "id": 1,
        }
        await client.help()
        mock_rpc.assert_awaited_once_with("help", {})
