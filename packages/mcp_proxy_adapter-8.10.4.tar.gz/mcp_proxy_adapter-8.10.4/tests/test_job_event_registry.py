"""Tests for JobEventRegistry (bounded history, TTL, listeners)."""

from __future__ import annotations

import asyncio

import pytest

from mcp_proxy_adapter.client.jsonrpc_client.job_event_registry import JobEventRegistry
from mcp_proxy_adapter.client.jsonrpc_client.job_tracking_types import JobCoarsePhase


@pytest.mark.asyncio
async def test_registry_max_events_overflow() -> None:
    reg = JobEventRegistry(max_events=3)
    for i in range(5):
        await reg.append_message("job-a", {"event": "tick", "n": i})
    msgs = await reg.get_messages("job-a")
    assert [m["n"] for m in msgs] == [2, 3, 4]


@pytest.mark.asyncio
async def test_registry_ttl_eviction_after_terminal() -> None:
    reg = JobEventRegistry(post_terminal_ttl_sec=0.05)
    await reg.append_message(
        "job-b",
        {"event": "job_completed", "job_id": "job-b"},
    )
    snap = await reg.get_snapshot("job-b")
    assert snap.is_terminal is True
    await asyncio.sleep(0.15)
    snap2 = await reg.get_snapshot("job-b")
    assert snap2.snapshot_version == 0
    assert snap2.coarse_phase == JobCoarsePhase.UNKNOWN.value


@pytest.mark.asyncio
async def test_merge_queue_poll_sets_execution() -> None:
    reg = JobEventRegistry()
    await reg.merge_queue_poll("job-c", {"status": "running"})
    snap = await reg.get_snapshot("job-c")
    assert snap.execution_status == "running"


@pytest.mark.asyncio
async def test_listener_invoked() -> None:
    reg = JobEventRegistry()
    seen: list[object] = []

    def cb(msg: object) -> None:
        seen.append(msg)

    unsub = await reg.add_listener("job-d", cb)
    await reg.append_message("job-d", {"event": "ping"})
    assert len(seen) == 1
    await unsub()
    await reg.append_message("job-d", {"event": "pong"})
    assert len(seen) == 1
