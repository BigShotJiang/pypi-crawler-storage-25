"""
Unit tests for build_delivery_push_message function.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import pytest

from mcp_proxy_adapter.core.job_push.events import (
    EVENT_DELIVERY_COMPLETED,
    EVENT_DELIVERY_FAILED,
    EVENT_DELIVERY_STOPPED,
    build_delivery_push_message,
)


def test_build_delivery_push_message_completed() -> None:
    """Test build_delivery_push_message for completed status."""
    out = build_delivery_push_message("w1", "completed", result={"ok": True})
    assert out["event"] == EVENT_DELIVERY_COMPLETED
    assert out["ws_id"] == "w1"
    assert out["result"] == {"ok": True}


def test_build_delivery_push_message_empty_ws_id_raises() -> None:
    """Test build_delivery_push_message raises ValueError for empty ws_id."""
    with pytest.raises(ValueError, match="non-empty ws_id"):
        build_delivery_push_message("", "completed", result={})


def test_build_delivery_push_message_failed_includes_error() -> None:
    """Test build_delivery_push_message for failed status includes error."""
    out = build_delivery_push_message(
        "w2", "failed", result={"error": "test"}, error="Test error"
    )
    assert out["event"] == EVENT_DELIVERY_FAILED
    assert out["ws_id"] == "w2"
    assert out["error"] == "Test error"
    assert out["result"] == {"error": "test"}


def test_build_delivery_push_message_stopped() -> None:
    """Test build_delivery_push_message for stopped status."""
    out = build_delivery_push_message("w3", "stopped", result={"status": "cancelled"})
    assert out["event"] == EVENT_DELIVERY_STOPPED
    assert out["ws_id"] == "w3"
    assert out["result"] == {"status": "cancelled"}


def test_build_delivery_push_message_whitespace_ws_id_raises() -> None:
    """Test build_delivery_push_message raises ValueError for whitespace-only ws_id."""
    with pytest.raises(ValueError, match="non-empty ws_id"):
        build_delivery_push_message("   ", "completed", result={})
