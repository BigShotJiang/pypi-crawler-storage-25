"""Tests for adapter-side job status accumulation and JSON-RPC API."""

from __future__ import annotations

import asyncio
from unittest.mock import MagicMock

import pytest
from fastapi import FastAPI
from fastapi import Request

from mcp_proxy_adapter.api.jsonrpc_job_status import (
    jsonrpc_job_status_get,
    jsonrpc_job_status_register,
)
from mcp_proxy_adapter.core.delivery.terminal_replay_store import TerminalReplayStore
from mcp_proxy_adapter.core.delivery.ws_delivery_manager import WsDeliveryManager
from mcp_proxy_adapter.core.job_push.events import (
    EVENT_JOB_COMPLETED,
    EVENT_JOB_PROGRESS,
    build_push_message,
)
from mcp_proxy_adapter.core.job_push.job_status_accumulator import JobStatusAccumulator
from mcp_proxy_adapter.core.job_push.subscriptions import SubscriberRegistry


@pytest.mark.asyncio
async def test_accumulator_records_queue_payload_after_register() -> None:
    acc = JobStatusAccumulator(max_history=5, terminal_ttl_seconds=60.0)
    await acc.register(job_id="j1")
    p = build_push_message("j1", status="running", progress=50, description="half")
    await acc.record_queue_job("j1", p)
    snap = await acc.get_snapshot(job_id="j1")
    assert snap is not None
    assert snap["phase"] == EVENT_JOB_PROGRESS
    assert snap["terminal"] is False
    assert snap["latest_message"]["job_id"] == "j1"


@pytest.mark.asyncio
async def test_dual_registration_merges_ws_into_job_key() -> None:
    acc = JobStatusAccumulator(max_history=3, terminal_ttl_seconds=60.0)
    await acc.register(job_id="job-a", ws_id="ws-a")
    d = {
        "event": "delivery_completed",
        "ws_id": "ws-a",
        "result": {"ok": True},
    }
    await acc.record_ws_delivery("ws-a", d)
    snap = await acc.get_snapshot(job_id="job-a")
    assert snap is not None
    assert snap["terminal"] is True
    assert snap["latest_message"]["event"] == "delivery_completed"


@pytest.mark.asyncio
async def test_wait_for_terminal() -> None:
    acc = JobStatusAccumulator(terminal_ttl_seconds=60.0)
    await acc.register(ws_id="ws-only")

    async def _late() -> None:
        await asyncio.sleep(0.05)
        await acc.record_ws_delivery(
            "ws-only",
            {
                "event": "delivery_completed",
                "ws_id": "ws-only",
                "result": {},
            },
        )

    asyncio.create_task(_late())
    out, timed_out = await acc.wait_for(ws_id="ws-only", timeout=2.0)
    assert not timed_out
    assert out is not None
    assert out.get("terminal") is True


@pytest.mark.asyncio
async def test_jsonrpc_register_and_get() -> None:
    app = FastAPI()
    reg = SubscriberRegistry()
    replay = TerminalReplayStore()
    acc = JobStatusAccumulator(terminal_ttl_seconds=60.0)
    app.state.job_status_accumulator = acc
    app.state.ws_delivery_manager = WsDeliveryManager(
        reg, replay, job_status_accumulator=acc
    )
    req = MagicMock(spec=Request)
    req.app = app

    await jsonrpc_job_status_register({"job_id": "x1", "ws_id": "w1"}, req)
    await acc.record_queue_job(
        "x1",
        build_push_message("x1", status="completed", result={"r": 1}),
    )
    res = await jsonrpc_job_status_get({"job_id": "x1"}, req)
    assert res["success"] is True
    assert res["data"]["terminal"] is True
    assert res["data"]["phase"] == EVENT_JOB_COMPLETED
