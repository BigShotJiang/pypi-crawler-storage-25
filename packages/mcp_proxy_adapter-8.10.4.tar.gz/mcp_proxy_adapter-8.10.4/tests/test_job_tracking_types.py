"""Unit tests for job_tracking_types (normalized terminals and snapshots)."""

from __future__ import annotations

import pytest

from mcp_proxy_adapter.client.jsonrpc_client.job_tracking_types import (
    JobCoarsePhase,
    JobStatusSnapshot,
    TerminalDomain,
    classify_terminal_event,
    execution_status_to_coarse_phase,
    is_queue_terminal_event,
)


def test_classify_queue_terminal() -> None:
    domain, norm = classify_terminal_event("job_completed")
    assert domain == TerminalDomain.QUEUE_JOB
    assert norm == "job_completed"


def test_classify_delivery_terminal() -> None:
    domain, norm = classify_terminal_event("delivery_failed")
    assert domain == TerminalDomain.DELIVERY
    assert norm == "delivery_failed"


def test_classify_non_terminal() -> None:
    domain, norm = classify_terminal_event("progress")
    assert domain == TerminalDomain.NONE
    assert norm is None


def test_is_queue_terminal_event() -> None:
    assert is_queue_terminal_event("job_failed") is True
    assert is_queue_terminal_event("delivery_completed") is False


@pytest.mark.parametrize(
    "status,expected",
    [
        ("pending", JobCoarsePhase.QUEUED),
        ("running", JobCoarsePhase.RUNNING),
        ("completed", JobCoarsePhase.TERMINAL),
        ("", JobCoarsePhase.UNKNOWN),
    ],
)
def test_execution_status_to_coarse_phase(
    status: str, expected: JobCoarsePhase
) -> None:
    assert execution_status_to_coarse_phase(status) == expected


def test_job_status_snapshot_unknown() -> None:
    snap = JobStatusSnapshot.unknown("j1")
    assert snap.job_id == "j1"
    assert snap.coarse_phase == JobCoarsePhase.UNKNOWN.value
    assert snap.is_terminal is False
    assert snap.snapshot_version == 0
