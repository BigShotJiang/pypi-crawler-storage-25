"""
Unit tests for orchestration.command_record (Step 02).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import pytest

from mcp_proxy_adapter.core.orchestration.command_record import CommandRecord


class TestCommandRecord:
    """Tests for CommandRecord dataclass."""

    def test_minimal_construction(self) -> None:
        """CommandRecord can be created with minimal required fields."""
        rec = CommandRecord(
            command_name="echo",
            summary=None,
            parameter_definitions={},
            metadata=None,
            schema={"type": "object", "properties": {}},
            required_parameters=(),
        )
        assert rec.command_name == "echo"
        assert rec.summary is None
        assert rec.parameter_definitions == {}
        assert rec.metadata is None
        assert rec.schema == {"type": "object", "properties": {}}
        assert rec.required_parameters == ()

    def test_full_construction(self) -> None:
        """CommandRecord stores all fields correctly."""
        rec = CommandRecord(
            command_name="chunk",
            summary="Chunk text",
            parameter_definitions={
                "text": {"type": "string"},
                "window": {"type": "integer"},
            },
            metadata={"author": "test", "version": "0.1"},
            schema={
                "type": "object",
                "properties": {
                    "text": {"type": "string"},
                    "window": {"type": "integer"},
                },
                "required": ["text"],
            },
            required_parameters=("text",),
        )
        assert rec.command_name == "chunk"
        assert rec.summary == "Chunk text"
        assert rec.parameter_definitions["text"] == {"type": "string"}
        assert rec.metadata is not None
        assert rec.metadata["author"] == "test"
        assert rec.schema["required"] == ["text"]
        assert list(rec.required_parameters) == ["text"]

    def test_required_parameters_sequence(self) -> None:
        """required_parameters accepts tuple or list (Sequence)."""
        rec = CommandRecord(
            command_name="x",
            summary=None,
            parameter_definitions={},
            metadata=None,
            schema={"type": "object", "properties": {}},
            required_parameters=["a", "b"],
        )
        assert list(rec.required_parameters) == ["a", "b"]

    def test_frozen_immutability(self) -> None:
        """CommandRecord is immutable (frozen dataclass)."""
        rec = CommandRecord(
            command_name="echo",
            summary=None,
            parameter_definitions={"msg": {}},
            metadata=None,
            schema={"type": "object", "properties": {"msg": {}}},
            required_parameters=(),
        )
        with pytest.raises(AttributeError):
            rec.command_name = "other"  # type: ignore[misc]
        with pytest.raises(AttributeError):
            rec.schema = {}  # type: ignore[misc]
