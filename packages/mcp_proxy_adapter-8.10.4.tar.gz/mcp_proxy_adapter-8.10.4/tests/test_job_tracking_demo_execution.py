"""Execute job_tracking_demo paths (mock + helpers), not import-only."""

from __future__ import annotations

import asyncio
import sys
from io import StringIO
from typing import Any, Dict
from unittest.mock import AsyncMock, patch

import pytest

from mcp_proxy_adapter.client.jsonrpc_client.client import JsonRpcClient
from mcp_proxy_adapter.examples import job_tracking_demo


@pytest.mark.asyncio
async def test_run_job_tracking_demo_sequence_with_mocks() -> None:
    """Covers get_job_status, get_job_messages, and wait_for_job in one sequence."""
    client = JsonRpcClient(protocol="http", host="127.0.0.1", port=9)
    job_id = "j-demo"

    async def fake_queue_status(jid: str) -> Dict[str, Any]:
        return {"status": "completed", "data": {"job_id": jid}}

    async def fake_wait(
        jid: str,
        timeout: float = 1.0,
        *,
        on_inbound_message: Any = None,
    ) -> Dict[str, Any]:
        if on_inbound_message is not None:
            await on_inbound_message({"event": "running", "job_id": jid})
        return {"event": "job_completed", "job_id": jid, "result": {"ok": True}}

    buf = StringIO()
    try:
        with patch.object(
            client,
            "queue_get_job_status",
            new=AsyncMock(side_effect=fake_queue_status),
        ):
            with patch.object(
                client,
                "wait_for_job_via_websocket",
                new=AsyncMock(side_effect=fake_wait),
            ):
                with patch("sys.stdout", buf):
                    await job_tracking_demo.run_job_tracking_demo_sequence(
                        client,
                        job_id,
                        include_wait=True,
                        wait_timeout=5.0,
                    )
    finally:
        await client.close()

    out = buf.getvalue()
    assert "get_job_status(sync_from_queue=True):" in out
    assert "get_job_messages(limit=10):" in out
    assert "event:" in out
    assert "terminal:" in out
    assert "job_completed" in out


@pytest.mark.asyncio
async def test_main_async_mock_flow_cli() -> None:
    buf = StringIO()
    with patch("sys.stdout", buf):
        await job_tracking_demo.main_async(["--mock-flow"])
    out = buf.getvalue()
    assert "get_job_status(sync_from_queue=True):" in out
    assert "terminal:" in out


def test_main_async_help_exits_zero() -> None:
    with pytest.raises(SystemExit) as excinfo:
        asyncio.run(job_tracking_demo.main_async(["--help"]))
    assert excinfo.value.code == 0


def test_job_tracking_demo_main_help_exits_zero() -> None:
    """``python -m ...job_tracking_demo --help`` entrypoint uses sys.argv."""
    with pytest.raises(SystemExit) as excinfo:
        with patch.object(sys, "argv", ["job_tracking_demo", "--help"]):
            job_tracking_demo.main()
    assert excinfo.value.code == 0
