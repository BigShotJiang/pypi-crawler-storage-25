"""
Unit tests for HelpCommand: compact listing without cmdname, full detail with cmdname.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import asyncio
from typing import Any, Dict

from mcp_proxy_adapter.commands.help_command import HelpCommand


def _run(coro: Any) -> Any:
    return asyncio.run(coro)


def test_help_without_cmdname_returns_tool_info_help_usage_and_string_command_map() -> (
    None
):
    result = _run(HelpCommand().execute())
    payload: Dict[str, Any] = result.to_dict()["data"]
    assert "tool_info" in payload
    assert "help_usage" in payload
    assert "commands" in payload
    cmds = payload["commands"]
    assert isinstance(cmds, dict)
    for name, desc in cmds.items():
        assert isinstance(name, str)
        assert isinstance(desc, str)
    assert cmds.get("echo") == "Echo command for testing"
    assert (
        cmds.get("long_task")
        == "Enqueue a long-running task that sleeps for given seconds"
    )


def test_help_with_cmdname_returns_detailed_command_info() -> None:
    result = _run(HelpCommand().execute(cmdname="echo"))
    payload: Dict[str, Any] = result.to_dict()["data"]
    assert "metadata" in payload
    assert "schema" in payload
    assert isinstance(payload["schema"], dict)
    assert "properties" in payload["schema"]
    assert payload["metadata"].get("summary") == "Echo command for testing"
