#!/usr/bin/env python3
"""
Backward-compatible setuptools entry point.

Canonical packaging metadata and entry points live in pyproject.toml (PEP 517).
This file remains so editable installs and older tooling can invoke setuptools
without duplicating version or console_scripts.
"""

from setuptools import setup  # type: ignore[import-untyped]

setup()
