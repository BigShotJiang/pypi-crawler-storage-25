"""Tests for layr8.client — uses an in-process mock Phoenix WebSocket server."""

from __future__ import annotations

import asyncio
import json
from typing import Any

import pytest
import websockets
import websockets.asyncio.server

from layr8 import Client, Config, Message, PASS, ProblemReportError, ServerRejectError, ErrorKind, SDKError, log_errors


def _discard_errors(err: SDKError) -> None:
    """Error handler that silently discards all SDK errors."""
    pass


class MockPhoenixServer:
    """Minimal Phoenix Channel V2 mock server for testing."""

    def __init__(self) -> None:
        self._server: websockets.asyncio.server.Server | None = None
        self._client_ws: websockets.asyncio.server.ServerConnection | None = None
        self._received: list[dict[str, Any]] = []
        self.on_msg: Any = None
        self.port = 0

    async def start(self) -> None:
        self._server = await websockets.asyncio.server.serve(
            self._handler,
            "127.0.0.1",
            0,
        )
        # Get the bound port
        sock = list(self._server.sockets)[0]
        self.port = sock.getsockname()[1]

    async def _handler(
        self, ws: websockets.asyncio.server.ServerConnection
    ) -> None:
        self._client_ws = ws
        try:
            async for raw in ws:
                arr = json.loads(raw)
                msg = {
                    "join_ref": arr[0],
                    "ref": arr[1],
                    "topic": arr[2],
                    "event": arr[3],
                    "payload": arr[4],
                }
                self._received.append({"event": msg["event"], "payload": msg["payload"]})
                if self.on_msg:
                    self.on_msg(msg)
        except websockets.exceptions.ConnectionClosed:
            pass

    async def send_to_client(
        self,
        join_ref: str | None,
        ref: str | None,
        topic: str,
        event: str,
        payload: Any,
    ) -> None:
        if self._client_ws:
            await self._client_ws.send(
                json.dumps([join_ref, ref, topic, event, payload])
            )

    def get_received(self) -> list[dict[str, Any]]:
        return list(self._received)

    def clear_received(self) -> None:
        self._received.clear()

    async def close(self) -> None:
        if self._server:
            self._server.close()
            await self._server.wait_closed()


@pytest.fixture
async def mock_server():
    """Create and start a mock Phoenix WebSocket server."""
    server = MockPhoenixServer()
    await server.start()

    # Default: auto-reply to phx_join AND ack all other messages
    def default_handler(msg: dict[str, Any]) -> None:
        if msg["event"] == "phx_join":
            asyncio.ensure_future(
                server.send_to_client(
                    msg["ref"],
                    msg["ref"],
                    msg["topic"],
                    "phx_reply",
                    {"status": "ok", "response": {"did": "did:web:node:test"}},
                )
            )
            return
        # Reply "ok" to all other messages (server ack)
        if msg.get("ref"):
            asyncio.ensure_future(
                server.send_to_client(
                    None,
                    msg["ref"],
                    msg["topic"],
                    "phx_reply",
                    {"status": "ok", "response": {}},
                )
            )

    server.on_msg = default_handler
    yield server
    await server.close()


def ws_url(server: MockPhoenixServer) -> str:
    return f"ws://127.0.0.1:{server.port}/plugin_socket/websocket"


class TestClient:
    async def test_creates_with_valid_config(self) -> None:
        client = Client(Config(
            node_url="ws://localhost:4000/plugin_socket/websocket",
            api_key="test-key",
            agent_did="did:web:test",
        ), _discard_errors)
        assert client is not None

    async def test_raises_when_node_url_missing(self) -> None:
        with pytest.raises(Exception, match="node_url is required"):
            Client(Config(api_key="test-key"), _discard_errors)

    async def test_raises_when_api_key_missing(self) -> None:
        with pytest.raises(Exception, match="api_key is required"):
            Client(Config(node_url="ws://localhost:4000"), _discard_errors)

    async def test_connects_and_closes(self, mock_server: MockPhoenixServer) -> None:
        client = Client(Config(
            node_url=ws_url(mock_server),
            api_key="test-key",
            agent_did="did:web:test",
        ), _discard_errors)
        await client.connect()
        await client.close()

    async def test_assigns_did_from_node(self, mock_server: MockPhoenixServer) -> None:
        client = Client(Config(
            node_url=ws_url(mock_server),
            api_key="test-key",
            agent_did="",
        ), _discard_errors)
        await client.connect()
        assert client.did == "did:web:node:test"
        await client.close()

    async def test_handle_before_connect(self) -> None:
        client = Client(Config(
            node_url="ws://localhost:4000",
            api_key="test-key",
            agent_did="did:web:test",
        ), _discard_errors)

        @client.handle("https://layr8.io/protocols/echo/1.0/request")
        async def handler(msg: Message) -> None:
            return None

        # Should not raise

    async def test_handle_after_connect_raises(
        self, mock_server: MockPhoenixServer
    ) -> None:
        client = Client(Config(
            node_url=ws_url(mock_server),
            api_key="test-key",
            agent_did="did:web:test",
        ), _discard_errors)

        @client.handle("https://layr8.io/protocols/echo/1.0/request")
        async def handler(msg: Message) -> None:
            return None

        await client.connect()
        try:
            with pytest.raises(Exception, match="already connected"):
                client.handle(
                    "https://layr8.io/protocols/echo/1.0/response",
                    handler,
                )
        finally:
            await client.close()

    async def test_send(self, mock_server: MockPhoenixServer) -> None:
        client = Client(Config(
            node_url=ws_url(mock_server),
            api_key="test-key",
            agent_did="did:web:alice",
        ), _discard_errors)

        @client.handle("https://layr8.io/protocols/echo/1.0/request")
        async def handler(msg: Message) -> None:
            return None

        await client.connect()

        await client.send(Message(
            type="https://didcomm.org/basicmessage/2.0/message",
            to=["did:web:bob"],
            body={"content": "hello"},
        ))

        await asyncio.sleep(0.2)
        received = mock_server.get_received()
        msg_events = [r for r in received if r["event"] == "message"]
        assert len(msg_events) > 0

        await client.close()

    async def test_send_not_connected_raises(self) -> None:
        client = Client(Config(
            node_url="ws://localhost:4000",
            api_key="test-key",
            agent_did="did:web:test",
        ), _discard_errors)
        with pytest.raises(Exception, match="not connected"):
            await client.send(Message(type="test", to=["did:web:bob"]))

    async def test_request_response_correlation(
        self, mock_server: MockPhoenixServer
    ) -> None:
        def handler(msg: dict[str, Any]) -> None:
            if msg["event"] == "phx_join":
                asyncio.ensure_future(
                    mock_server.send_to_client(
                        msg["ref"], msg["ref"], msg["topic"],
                        "phx_reply", {"status": "ok", "response": {}},
                    )
                )
            elif msg["event"] == "message":
                payload = msg["payload"]
                # First, send server ack for the message send
                if msg.get("ref"):
                    asyncio.ensure_future(
                        mock_server.send_to_client(
                            None, msg["ref"], msg["topic"],
                            "phx_reply", {"status": "ok", "response": {}},
                        )
                    )
                # Then send the DIDComm response
                asyncio.ensure_future(
                    mock_server.send_to_client(
                        None, None, "plugins:did:web:alice", "message",
                        {
                            "plaintext": {
                                "id": "resp-1",
                                "type": "https://layr8.io/protocols/echo/1.0/response",
                                "from": "did:web:bob",
                                "to": [payload.get("from", "")],
                                "thid": payload.get("thid", ""),
                                "body": {"echo": "hello"},
                            }
                        },
                    )
                )
            else:
                # Ack any other messages (e.g., ack events)
                if msg.get("ref"):
                    asyncio.ensure_future(
                        mock_server.send_to_client(
                            None, msg["ref"], msg["topic"],
                            "phx_reply", {"status": "ok", "response": {}},
                        )
                    )

        mock_server.on_msg = handler

        client = Client(Config(
            node_url=ws_url(mock_server),
            api_key="test-key",
            agent_did="did:web:alice",
        ), _discard_errors)

        @client.handle("https://layr8.io/protocols/echo/1.0/request")
        async def echo(msg: Message) -> None:
            return None

        await client.connect()

        resp = await client.request(
            Message(
                type="https://layr8.io/protocols/echo/1.0/request",
                to=["did:web:bob"],
                body={"message": "hello"},
            ),
            timeout=5.0,
        )

        assert resp.type == "https://layr8.io/protocols/echo/1.0/response"
        body = resp.unmarshal_body()
        assert body["echo"] == "hello"

        await client.close()

    async def test_request_timeout(self, mock_server: MockPhoenixServer) -> None:
        # Server acks the message but does NOT send a DIDComm response,
        # so the timeout comes from waiting for the DIDComm response.
        client = Client(Config(
            node_url=ws_url(mock_server),
            api_key="test-key",
            agent_did="did:web:alice",
        ), _discard_errors)

        @client.handle("https://layr8.io/protocols/echo/1.0/request")
        async def handler(msg: Message) -> None:
            return None

        await client.connect()

        with pytest.raises(asyncio.TimeoutError):
            await client.request(
                Message(
                    type="https://layr8.io/protocols/echo/1.0/request",
                    to=["did:web:nobody"],
                    body={"message": "hello"},
                ),
                timeout=0.2,
            )

        await client.close()

    async def test_request_problem_report(
        self, mock_server: MockPhoenixServer
    ) -> None:
        def handler(msg: dict[str, Any]) -> None:
            if msg["event"] == "phx_join":
                asyncio.ensure_future(
                    mock_server.send_to_client(
                        msg["ref"], msg["ref"], msg["topic"],
                        "phx_reply", {"status": "ok", "response": {}},
                    )
                )
            elif msg["event"] == "message":
                payload = msg["payload"]
                # First, send server ack for the message send
                if msg.get("ref"):
                    asyncio.ensure_future(
                        mock_server.send_to_client(
                            None, msg["ref"], msg["topic"],
                            "phx_reply", {"status": "ok", "response": {}},
                        )
                    )
                # Then send the problem report DIDComm response
                asyncio.ensure_future(
                    mock_server.send_to_client(
                        None, None, "plugins:did:web:alice", "message",
                        {
                            "plaintext": {
                                "id": "err-1",
                                "type": "https://didcomm.org/report-problem/2.0/problem-report",
                                "from": "did:web:bob",
                                "thid": payload.get("thid", ""),
                                "body": {
                                    "code": "e.p.xfer.cant-process",
                                    "comment": "database unavailable",
                                },
                            }
                        },
                    )
                )
            else:
                # Ack any other messages
                if msg.get("ref"):
                    asyncio.ensure_future(
                        mock_server.send_to_client(
                            None, msg["ref"], msg["topic"],
                            "phx_reply", {"status": "ok", "response": {}},
                        )
                    )

        mock_server.on_msg = handler

        client = Client(Config(
            node_url=ws_url(mock_server),
            api_key="test-key",
            agent_did="did:web:alice",
        ), _discard_errors)

        @client.handle("https://layr8.io/protocols/echo/1.0/request")
        async def echo(msg: Message) -> None:
            return None

        await client.connect()

        with pytest.raises(ProblemReportError) as exc_info:
            await client.request(
                Message(
                    type="https://layr8.io/protocols/echo/1.0/request",
                    to=["did:web:bob"],
                    body={"message": "hello"},
                ),
                timeout=5.0,
            )

        assert exc_info.value.code == "e.p.xfer.cant-process"
        await client.close()

    async def test_inbound_handler_dispatched(
        self, mock_server: MockPhoenixServer
    ) -> None:
        client = Client(Config(
            node_url=ws_url(mock_server),
            api_key="test-key",
            agent_did="did:web:alice",
        ), _discard_errors)

        received_msg: asyncio.Future[Message] = asyncio.get_running_loop().create_future()

        @client.handle("https://didcomm.org/basicmessage/2.0/message")
        async def handler(msg: Message) -> None:
            if not received_msg.done():
                received_msg.set_result(msg)
            return None

        await client.connect()

        await mock_server.send_to_client(
            None, None, "plugin:lobby", "message",
            {
                "context": {
                    "recipient": "did:web:alice",
                    "authorized": True,
                    "sender_credentials": [
                        {"credential_subject": {"id": "did:web:bob", "name": "Bob"}}
                    ],
                },
                "plaintext": {
                    "id": "inbound-1",
                    "type": "https://didcomm.org/basicmessage/2.0/message",
                    "from": "did:web:bob",
                    "to": ["did:web:alice"],
                    "body": {"content": "hello alice"},
                },
            },
        )

        msg = await asyncio.wait_for(received_msg, timeout=2)
        assert msg.from_ == "did:web:bob"
        assert msg.context is not None
        assert msg.context.authorized is True
        assert msg.context.sender_credentials[0].name == "Bob"
        body = msg.unmarshal_body()
        assert body["content"] == "hello alice"

        # Verify ack was sent
        await asyncio.sleep(0.2)
        received = mock_server.get_received()
        assert any(r["event"] == "ack" for r in received)

        await client.close()

    async def test_handler_error_sends_problem_report(
        self, mock_server: MockPhoenixServer
    ) -> None:
        client = Client(Config(
            node_url=ws_url(mock_server),
            api_key="test-key",
            agent_did="did:web:alice",
        ), _discard_errors)

        @client.handle("https://layr8.io/protocols/echo/1.0/request")
        async def handler(msg: Message) -> Message:
            raise RuntimeError("something went wrong")

        await client.connect()

        await mock_server.send_to_client(
            None, None, "plugin:lobby", "message",
            {
                "plaintext": {
                    "id": "req-1",
                    "type": "https://layr8.io/protocols/echo/1.0/request",
                    "from": "did:web:bob",
                    "to": ["did:web:alice"],
                    "body": {"message": "ping"},
                },
            },
        )

        await asyncio.sleep(0.5)
        received = mock_server.get_received()
        reports = [
            r for r in received
            if r["event"] == "message"
            and isinstance(r["payload"], dict)
            and r["payload"].get("type") == "https://didcomm.org/report-problem/2.0/problem-report"
        ]
        assert len(reports) == 1

        await client.close()

    async def test_join_rejected_includes_reason(self, mock_server: MockPhoenixServer) -> None:
        def handler(msg: dict[str, Any]) -> None:
            if msg["event"] == "phx_join":
                asyncio.ensure_future(
                    mock_server.send_to_client(
                        msg["ref"],
                        msg["ref"],
                        msg["topic"],
                        "phx_reply",
                        {
                            "status": "error",
                            "response": {
                                "reason": "e.connect.plugin.failed: protocols_already_bound",
                            },
                        },
                    )
                )

        mock_server.on_msg = handler

        client = Client(Config(
            node_url=ws_url(mock_server),
            api_key="test-key",
            agent_did="did:web:test",
        ), _discard_errors)

        @client.handle("https://layr8.io/protocols/echo/1.0/request")
        async def echo(msg: Message) -> None:
            return None

        with pytest.raises(Exception, match="protocols_already_bound"):
            await client.connect()

    async def test_async_context_manager(
        self, mock_server: MockPhoenixServer
    ) -> None:
        client = Client(Config(
            node_url=ws_url(mock_server),
            api_key="test-key",
            agent_did="did:web:test",
        ), _discard_errors)

        async with client:
            assert client.did  # should be connected

    # --- Poka-yoke error handling tests ---

    async def test_raises_without_on_error(self) -> None:
        with pytest.raises(TypeError):
            Client(Config(node_url="ws://localhost", api_key="key"))  # type: ignore[call-arg]

    async def test_on_error_parse_failure(self, mock_server: MockPhoenixServer) -> None:
        errors: list[SDKError] = []
        client = Client(Config(node_url=ws_url(mock_server), api_key="test-key", agent_did="did:web:test"), errors.append)

        @client.handle("https://layr8.io/protocols/echo/1.0/request")
        async def handler(msg: Message) -> None:
            return None

        await client.connect()
        await mock_server.send_to_client(None, None, "plugin:lobby", "message", "not-a-didcomm-message")
        await asyncio.sleep(0.2)

        assert len(errors) > 0
        assert errors[0].kind == ErrorKind.PARSE_FAILURE
        await client.close()

    async def test_on_error_no_handler(self, mock_server: MockPhoenixServer) -> None:
        errors: list[SDKError] = []
        client = Client(Config(node_url=ws_url(mock_server), api_key="test-key", agent_did="did:web:test"), errors.append)

        @client.handle("https://layr8.io/protocols/echo/1.0/request")
        async def handler(msg: Message) -> None:
            return None

        await client.connect()
        await mock_server.send_to_client(None, None, "plugin:lobby", "message", {
            "plaintext": {"id": "msg-1", "type": "https://unknown.org/protocol/1.0/unknown", "from": "did:web:other", "body": {}},
        })
        await asyncio.sleep(0.2)

        assert len(errors) == 1
        assert errors[0].kind == ErrorKind.NO_HANDLER
        await client.close()

    async def test_on_error_handler_exception(self, mock_server: MockPhoenixServer) -> None:
        errors: list[SDKError] = []
        client = Client(Config(node_url=ws_url(mock_server), api_key="test-key", agent_did="did:web:alice"), errors.append)

        @client.handle("https://layr8.io/protocols/echo/1.0/request")
        async def handler(msg: Message) -> Message:
            raise RuntimeError("boom")

        await client.connect()
        await mock_server.send_to_client(None, None, "plugin:lobby", "message", {
            "plaintext": {"id": "req-1", "type": "https://layr8.io/protocols/echo/1.0/request", "from": "did:web:bob", "body": {}},
        })
        await asyncio.sleep(0.5)

        assert any(e.kind == ErrorKind.HANDLER_EXCEPTION for e in errors)
        await client.close()

    async def test_send_fire_and_forget(self, mock_server: MockPhoenixServer) -> None:
        client = Client(Config(node_url=ws_url(mock_server), api_key="test-key", agent_did="did:web:alice"), _discard_errors)

        @client.handle("https://layr8.io/protocols/echo/1.0/request")
        async def handler(msg: Message) -> None:
            return None

        await client.connect()

        # fire_and_forget=True should succeed even without server ack
        await client.send(
            Message(type="https://didcomm.org/basicmessage/2.0/message", to=["did:web:bob"], body={"content": "hi"}),
            fire_and_forget=True,
        )

        await client.close()

    async def test_send_server_reject(self, mock_server: MockPhoenixServer) -> None:
        # Override to reject messages
        def handler(msg: dict[str, Any]) -> None:
            if msg["event"] == "phx_join":
                asyncio.ensure_future(mock_server.send_to_client(msg["ref"], msg["ref"], msg["topic"], "phx_reply", {"status": "ok", "response": {}}))
                return
            if msg.get("ref"):
                asyncio.ensure_future(mock_server.send_to_client(None, msg["ref"], msg["topic"], "phx_reply", {"status": "error", "response": {"reason": "not_authorized"}}))
        mock_server.on_msg = handler

        client = Client(Config(node_url=ws_url(mock_server), api_key="test-key", agent_did="did:web:alice"), _discard_errors)

        @client.handle("https://layr8.io/protocols/echo/1.0/request")
        async def echo(msg: Message) -> None:
            return None

        await client.connect()

        with pytest.raises(ServerRejectError, match="not_authorized"):
            await client.send(Message(type="https://didcomm.org/basicmessage/2.0/message", to=["did:web:bob"], body={}))

        await client.close()


def _reply_protocol_handler(mock_server: MockPhoenixServer):
    """Server handler that returns capabilities with reply_protocol/1."""
    def handler(msg: dict[str, Any]) -> None:
        if msg["event"] == "phx_join":
            asyncio.ensure_future(
                mock_server.send_to_client(
                    msg["ref"], msg["ref"], msg["topic"],
                    "phx_reply",
                    {
                        "status": "ok",
                        "response": {
                            "did": "did:web:node:test",
                            "capabilities": ["reply_protocol/1"],
                        },
                    },
                )
            )
        else:
            if msg.get("ref"):
                asyncio.ensure_future(
                    mock_server.send_to_client(
                        None, msg["ref"], msg["topic"],
                        "phx_reply", {"status": "ok", "response": {}},
                    )
                )
    return handler


class TestReplyProtocol:
    async def test_handler_returns_message_sends_handled(
        self, mock_server: MockPhoenixServer
    ) -> None:
        mock_server.on_msg = _reply_protocol_handler(mock_server)

        client = Client(Config(
            node_url=ws_url(mock_server),
            api_key="test-key",
            agent_did="did:web:alice",
        ), _discard_errors)

        @client.handle("https://layr8.io/protocols/echo/1.0/request")
        async def handler(msg: Message) -> Message:
            return Message(
                type="https://layr8.io/protocols/echo/1.0/response",
                body={"echo": msg.unmarshal_body().get("message")},
            )

        await client.connect()
        mock_server.clear_received()

        await mock_server.send_to_client(
            None, None, "plugins:did:web:alice", "message",
            {
                "plaintext": {
                    "id": "req-1",
                    "type": "https://layr8.io/protocols/echo/1.0/request",
                    "from": "did:web:bob",
                    "to": ["did:web:alice"],
                    "body": {"message": "ping"},
                },
            },
        )
        await asyncio.sleep(0.5)

        received = mock_server.get_received()
        reply_events = [r for r in received if r["event"] == "dispatch_reply"]
        assert len(reply_events) == 1
        assert reply_events[0]["payload"]["status"] == "handled"
        assert reply_events[0]["payload"]["message_id"] == "req-1"

        # Response message should have been sent
        msg_events = [r for r in received if r["event"] == "message"]
        assert len(msg_events) == 1

        # NO ack should be sent in new mode
        ack_events = [r for r in received if r["event"] == "ack"]
        assert len(ack_events) == 0

        await client.close()

    async def test_handler_returns_none_sends_handled(
        self, mock_server: MockPhoenixServer
    ) -> None:
        mock_server.on_msg = _reply_protocol_handler(mock_server)

        client = Client(Config(
            node_url=ws_url(mock_server),
            api_key="test-key",
            agent_did="did:web:alice",
        ), _discard_errors)

        @client.handle("https://layr8.io/protocols/echo/1.0/request")
        async def handler(msg: Message) -> None:
            return None

        await client.connect()
        mock_server.clear_received()

        await mock_server.send_to_client(
            None, None, "plugins:did:web:alice", "message",
            {
                "plaintext": {
                    "id": "req-2",
                    "type": "https://layr8.io/protocols/echo/1.0/request",
                    "from": "did:web:bob",
                    "to": ["did:web:alice"],
                    "body": {"message": "ping"},
                },
            },
        )
        await asyncio.sleep(0.5)

        received = mock_server.get_received()
        reply_events = [r for r in received if r["event"] == "dispatch_reply"]
        assert len(reply_events) == 1
        assert reply_events[0]["payload"]["status"] == "handled"

        await client.close()

    async def test_handler_returns_pass_sends_pass(
        self, mock_server: MockPhoenixServer
    ) -> None:
        mock_server.on_msg = _reply_protocol_handler(mock_server)

        client = Client(Config(
            node_url=ws_url(mock_server),
            api_key="test-key",
            agent_did="did:web:alice",
        ), _discard_errors)

        @client.handle("https://layr8.io/protocols/echo/1.0/request")
        async def handler(msg: Message) -> Message | None:
            return PASS  # type: ignore[return-value]

        await client.connect()
        mock_server.clear_received()

        await mock_server.send_to_client(
            None, None, "plugins:did:web:alice", "message",
            {
                "plaintext": {
                    "id": "req-3",
                    "type": "https://layr8.io/protocols/echo/1.0/request",
                    "from": "did:web:bob",
                    "to": ["did:web:alice"],
                    "body": {"message": "ping"},
                },
            },
        )
        await asyncio.sleep(0.5)

        received = mock_server.get_received()
        reply_events = [r for r in received if r["event"] == "dispatch_reply"]
        assert len(reply_events) == 1
        assert reply_events[0]["payload"]["status"] == "pass"

        await client.close()

    async def test_handler_raises_sends_error(
        self, mock_server: MockPhoenixServer
    ) -> None:
        mock_server.on_msg = _reply_protocol_handler(mock_server)

        errors: list[SDKError] = []
        client = Client(Config(
            node_url=ws_url(mock_server),
            api_key="test-key",
            agent_did="did:web:alice",
        ), errors.append)

        @client.handle("https://layr8.io/protocols/echo/1.0/request")
        async def handler(msg: Message) -> Message:
            raise ValueError("bad input")

        await client.connect()
        mock_server.clear_received()

        await mock_server.send_to_client(
            None, None, "plugins:did:web:alice", "message",
            {
                "plaintext": {
                    "id": "req-4",
                    "type": "https://layr8.io/protocols/echo/1.0/request",
                    "from": "did:web:bob",
                    "to": ["did:web:alice"],
                    "body": {"message": "ping"},
                },
            },
        )
        await asyncio.sleep(0.5)

        received = mock_server.get_received()
        reply_events = [r for r in received if r["event"] == "dispatch_reply"]
        assert len(reply_events) == 1
        assert reply_events[0]["payload"]["status"] == "error"
        assert reply_events[0]["payload"]["code"] == "ValueError"
        assert reply_events[0]["payload"]["message"] == "bad input"

        # Problem report should also have been sent
        msg_events = [r for r in received if r["event"] == "message"]
        assert len(msg_events) == 1

        # Error callback should have been called
        assert any(e.kind == ErrorKind.HANDLER_EXCEPTION for e in errors)

        await client.close()

    async def test_no_handler_sends_pass(
        self, mock_server: MockPhoenixServer
    ) -> None:
        mock_server.on_msg = _reply_protocol_handler(mock_server)

        errors: list[SDKError] = []
        client = Client(Config(
            node_url=ws_url(mock_server),
            api_key="test-key",
            agent_did="did:web:alice",
        ), errors.append)

        @client.handle("https://layr8.io/protocols/echo/1.0/request")
        async def handler(msg: Message) -> None:
            return None

        await client.connect()
        mock_server.clear_received()

        # Send a message type that has no handler
        await mock_server.send_to_client(
            None, None, "plugins:did:web:alice", "message",
            {
                "plaintext": {
                    "id": "req-5",
                    "type": "https://unknown.org/protocol/1.0/unknown",
                    "from": "did:web:bob",
                    "to": ["did:web:alice"],
                    "body": {},
                },
            },
        )
        await asyncio.sleep(0.5)

        received = mock_server.get_received()
        reply_events = [r for r in received if r["event"] == "dispatch_reply"]
        assert len(reply_events) == 1
        assert reply_events[0]["payload"]["status"] == "pass"

        # NO_HANDLER error should have been reported
        assert any(e.kind == ErrorKind.NO_HANDLER for e in errors)

        await client.close()

    async def test_catch_all_invoked(
        self, mock_server: MockPhoenixServer
    ) -> None:
        mock_server.on_msg = _reply_protocol_handler(mock_server)

        client = Client(Config(
            node_url=ws_url(mock_server),
            api_key="test-key",
            agent_did="did:web:alice",
        ), _discard_errors)

        received_msg: asyncio.Future[Message] = asyncio.get_running_loop().create_future()

        @client.handle_all
        async def catch_all(msg: Message) -> None:
            if not received_msg.done():
                received_msg.set_result(msg)
            return None

        await client.connect()
        mock_server.clear_received()

        await mock_server.send_to_client(
            None, None, "plugins:did:web:alice", "message",
            {
                "plaintext": {
                    "id": "req-6",
                    "type": "https://unknown.org/protocol/1.0/unknown",
                    "from": "did:web:bob",
                    "to": ["did:web:alice"],
                    "body": {"data": "test"},
                },
            },
        )

        msg = await asyncio.wait_for(received_msg, timeout=2)
        assert msg.type == "https://unknown.org/protocol/1.0/unknown"

        await asyncio.sleep(0.3)
        received = mock_server.get_received()
        reply_events = [r for r in received if r["event"] == "dispatch_reply"]
        assert len(reply_events) == 1
        assert reply_events[0]["payload"]["status"] == "handled"

        await client.close()

    async def test_legacy_mode_sends_ack(
        self, mock_server: MockPhoenixServer
    ) -> None:
        # Default mock_server handler does NOT return capabilities,
        # so reply_protocol will be False (legacy mode).
        client = Client(Config(
            node_url=ws_url(mock_server),
            api_key="test-key",
            agent_did="did:web:alice",
        ), _discard_errors)

        @client.handle("https://layr8.io/protocols/echo/1.0/request")
        async def handler(msg: Message) -> None:
            return None

        await client.connect()
        mock_server.clear_received()

        await mock_server.send_to_client(
            None, None, "plugins:did:web:alice", "message",
            {
                "plaintext": {
                    "id": "req-7",
                    "type": "https://layr8.io/protocols/echo/1.0/request",
                    "from": "did:web:bob",
                    "to": ["did:web:alice"],
                    "body": {"message": "ping"},
                },
            },
        )
        await asyncio.sleep(0.5)

        received = mock_server.get_received()

        # Legacy mode should send ack
        ack_events = [r for r in received if r["event"] == "ack"]
        assert len(ack_events) == 1

        # Legacy mode should NOT send dispatch_reply
        reply_events = [r for r in received if r["event"] == "dispatch_reply"]
        assert len(reply_events) == 0

        await client.close()
