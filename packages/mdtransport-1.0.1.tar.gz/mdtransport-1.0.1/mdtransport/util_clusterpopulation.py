#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Wed Nov 19 15:21:36 2025

@author: Shah Research Group, Oklahoma State University <jindal.shah@okstate.edu>

MDTransport: GROMACS & LAMMPS Transport Analysis Tools
Copyright (C) 2026  Ashutosh Kumar Verma, Amey Thorat and Jindal Shah

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
"""

import gc
import ctypes
import numpy as np
import pandas as pd
import multiprocessing
from scipy.spatial import cKDTree
from .util import BaseAnalysis, tqdm

# Global dictionary for shared worker data
_cluster_shared = {}

def init_cluster_worker(pos_buf, pos_shape, box_buf, box_shape, idx_ref, idx_target, r_cut, is_same):
    """Initialize worker."""
    global _cluster_shared
    _cluster_shared['pos'] = np.frombuffer(pos_buf, dtype=np.float32).reshape(pos_shape)
    _cluster_shared['box'] = np.frombuffer(box_buf, dtype=np.float32).reshape(box_shape)
    _cluster_shared['idx_ref'] = idx_ref
    _cluster_shared['idx_target'] = idx_target
    _cluster_shared['r_cut'] = r_cut
    _cluster_shared['is_same'] = is_same

def cal_cage_population(t_idx):
    """Function to calculate neighbor counts with cKDTree."""
    pos = _cluster_shared['pos']
    boxes = _cluster_shared['box']
    idx_ref = _cluster_shared['idx_ref']
    idx_target = _cluster_shared['idx_target']
    r_cut = _cluster_shared['r_cut']
    is_same = _cluster_shared['is_same']

    box_t = boxes[t_idx]
    
    pos_ref = pos[t_idx, idx_ref, :] % box_t
    pos_target = pos[t_idx, idx_target, :] % box_t

    for i in range(3):
        pos_ref[pos_ref[:, i] >= box_t[i], i] = 0.0
        pos_target[pos_target[:, i] >= box_t[i], i] = 0.0

    tree_target = cKDTree(pos_target, boxsize=box_t)
    indices_within_rcut = tree_target.query_ball_point(pos_ref, r=r_cut)
    
    neighbor_counts = np.array([len(indices) for indices in indices_within_rcut], dtype=np.int32)

    if is_same:
        neighbor_counts -= 1 

    return neighbor_counts

def init_rdf_worker(pos_buf, pos_shape, box_buf, box_shape, idx1, idx2, bins, is_same):
    """Initialize global variables for RDF calculations."""
    global _cluster_shared
    _cluster_shared['pos'] = np.frombuffer(pos_buf, dtype=np.float32).reshape(pos_shape)
    _cluster_shared['box'] = np.frombuffer(box_buf, dtype=np.float32).reshape(box_shape)
    _cluster_shared['idx1'] = idx1
    _cluster_shared['idx2'] = idx2
    _cluster_shared['bins'] = bins
    _cluster_shared['is_same'] = is_same

def rdf_process_frame(t_idx):
    """Process frame for RDF with cKDTree."""
    pos = _cluster_shared['pos']
    boxes = _cluster_shared['box']
    idx1 = _cluster_shared['idx1']
    idx2 = _cluster_shared['idx2']
    bins = _cluster_shared['bins']
    is_same = _cluster_shared['is_same']

    box_t = boxes[t_idx]
    
    c1 = pos[t_idx, idx1, :] % box_t
    c2 = pos[t_idx, idx2, :] % box_t

    for i in range(3):
        c1[c1[:, i] >= box_t[i], i] = 0.0
        c2[c2[:, i] >= box_t[i], i] = 0.0

    tree2 = cKDTree(c2, boxsize=box_t)
    neighbors = tree2.query_ball_point(c1, r=bins[-1])
    
    all_dists = []
    for i, idx_list in enumerate(neighbors):
        if not idx_list: continue
        diff = c1[i] - c2[idx_list]
        diff -= box_t * np.round(diff / box_t) 
        dists = np.linalg.norm(diff, axis=1)
        if is_same: dists = dists[dists > 1e-4]
        all_dists.extend(dists)

    hist, _ = np.histogram(all_dists, bins=bins)
    return hist

class Util_ClusterPopulation(BaseAnalysis):
        
    """
    Class to perform cluster-population analysis.
    """
    def __init__(self, args):
        super().__init__(args)
        self.n_cores = self.args.n_cores
        
    def calculate_solvation_radius(self, pos_buf, pos_shape, box_buf, box_shape, species_counts, species_i, species_j):
        """Calculates first solvation radius."""
        all_species = list(species_counts.keys())
        def get_idx_range(name):
            curr = 0
            for s in all_species:
                if s == name: return (curr, curr + species_counts[s])
                curr += species_counts[s]
            return None

        idx1 = np.arange(*get_idx_range(species_i))
        idx2 = np.arange(*get_idx_range(species_j))
        is_same = (species_i == species_j)

        box_arr = np.frombuffer(box_buf, dtype=np.float32).reshape(box_shape)
        bins = np.arange(0, np.min(box_arr) / 2.0 + 0.1, 0.1)
        
        frame_step = int(self.args.steps)
        frames_to_process = range(0, pos_shape[0], frame_step)

        ctx = multiprocessing.get_context(self.args.get_context)
        init_args = (pos_buf, pos_shape, box_buf, box_shape, idx1, idx2, bins, is_same)
        
        with ctx.Pool(processes=self.n_cores, initializer=init_rdf_worker, initargs=init_args) as pool:
            results = list(tqdm(pool.imap(rdf_process_frame, frames_to_process), 
                                total=len(frames_to_process), desc="Calculating RDF"))

        total_hist = np.sum(results, axis=0).astype(np.float64)
        shell_volumes = (4.0 / 3.0) * np.pi * (bins[1:] ** 3 - bins[:-1] ** 3)
        avg_volume = np.mean(np.prod(box_arr[::frame_step], axis=1))
        ideal_density = (len(idx2) - (1 if is_same else 0)) / avg_volume
        g_r = (total_hist / (len(frames_to_process) * len(idx1))) / (shell_volumes * ideal_density)
        
        p1_idx = np.argmax(g_r[:len(g_r)//2])
        r_cut = bins[:-1][p1_idx + np.argmin(g_r[p1_idx:p1_idx+50])]
        self.log_message("INFO", f"RDF Complete. r_cut detected: {r_cut:.2f} Å")
        
        return r_cut

    def run_clusterpopulation(self, COM_data, box_df, species_counts, dt_md, drift, wrap_requested, charge_requested):
        """Calculates the average coordination number."""
        if len(self.args.resname) < 2:
            self.log_message("ERROR", "Please provide two species names: --resname REF TARGET")
            return
            
        ref_spec_name, target_spec_name = self.args.resname[0], self.args.resname[1]
        self.generate_folders("results_cluster_populations")

        num_steps = COM_data.shape[0]
        total_mols = COM_data.shape[1]
        is_lammps = getattr(self.args, 'LAM', False)
        c_slice = slice(0, 3) if is_lammps else slice(1, 4)
        box_lengths = box_df[["Lx", "Ly", "Lz"]].values.astype(np.float32)

        pos_buf = multiprocessing.RawArray(ctypes.c_float, num_steps * total_mols * 3)
        box_buf = multiprocessing.RawArray(ctypes.c_float, num_steps * 3)
        
        shared_pos = np.frombuffer(pos_buf, dtype=np.float32).reshape((num_steps, total_mols, 3))
        shared_box = np.frombuffer(box_buf, dtype=np.float32).reshape((num_steps, 3))
        np.copyto(shared_box, box_lengths)
        
        shared_pos[0] = COM_data[0, :, c_slice].astype(np.float32)
        
        for t in tqdm(range(1, num_steps), desc="Loading Trajectory"):
            curr_pos = COM_data[t, :, c_slice].astype(np.float32)
            
            diff = curr_pos - shared_pos[t-1]
            curr_pos -= box_lengths[t] * np.round(diff / box_lengths[t])
            
            if drift is not None:
                shared_pos[t] = curr_pos - drift[t]
            else:
                shared_pos[t] = curr_pos

        if self.args.RCUT:
            r_cut = float(self.args.RCUT[0])
        else:
            r_cut = self.calculate_solvation_radius(pos_buf, shared_pos.shape, box_buf, shared_box.shape, species_counts, ref_spec_name, target_spec_name)

        species_idx_map = {}
        curr = 0
        for name, count in species_counts.items():
            species_idx_map[name] = np.arange(curr, curr + count)
            curr += count

        indices_ref = species_idx_map[ref_spec_name]
        indices_target = species_idx_map[target_spec_name]
        frame_step = int(getattr(self.args, 'steps', 1))
        t_indices = range(0, num_steps, frame_step)

        is_same = (ref_spec_name == target_spec_name)
        init_args = (pos_buf, shared_pos.shape, box_buf, shared_box.shape, indices_ref, indices_target, r_cut, is_same)
        
        all_population_counts = []
        ctx = multiprocessing.get_context(self.args.get_context)
        with ctx.Pool(processes=self.n_cores, initializer=init_cluster_worker, initargs=init_args) as pool:
            results = list(tqdm(pool.imap_unordered(cal_cage_population, t_indices), 
                                total=len(t_indices), desc="Analyzing Cage Populations"))
            for counts_at_t in results:
                all_population_counts.extend(counts_at_t)
    
        all_populations_flat = np.array(all_population_counts, dtype=np.int32)
        species_str = f"{ref_spec_name}-{target_spec_name}"
        pd.DataFrame(all_populations_flat, columns=["population_count"]).to_csv(
            f"results_cluster_populations/cluster_dist_{species_str}_r{r_cut:.2f}.csv", index=False)

        self.log_message("INFO", "\n" + "=" * 65 + "\n         Cluster Population Analysis Summary \n" + "=" * 65)
        self.log_message("INFO", f" {'Cage search radius used':<40} : {r_cut:.2f} Å")
        self.log_message("INFO", f" {'Avg ' + target_spec_name + ' around ' + ref_spec_name:<40} : {np.mean(all_populations_flat):.3f}")
        self.log_message("INFO", f" {'Std Dev population':<40} : {np.std(all_populations_flat):.3f}")
        self.log_message("INFO", "=" * 65 + "\n")
        
        del shared_pos
        gc.collect()