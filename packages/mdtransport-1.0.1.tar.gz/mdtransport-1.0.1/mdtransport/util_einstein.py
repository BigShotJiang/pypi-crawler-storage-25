#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Wed Nov 19 15:21:36 2025

@author: Shah Research Group, Oklahoma State University <jindal.shah@okstate.edu>

MDTransport: GROMACS & LAMMPS Transport Analysis Tools
Copyright (C) 2026  Ashutosh Kumar Verma, Amey Thorat and Jindal Shah

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
"""
import sys
import numpy as np
import pandas as pd
from .util import BaseAnalysis, tqdm

def process_msd_fft_array(args):
    
    """
    FFT-based MSD calculation.
    """
    coords, directions = args
    if coords is None or coords.shape[0] < 2: return None

    try:
        import scipy.fft
        fft_module = scipy.fft
        using_scipy = True
    except ImportError:
        fft_module = np.fft
        using_scipy = False

    coords = coords.astype(np.float64, copy=False)
    
    dir_map = {"x": 0, "y": 1, "z": 2}
    cols = [dir_map[d] for d in sorted(directions)]
    coords = np.ascontiguousarray(coords[:, cols])
    
    n_steps, n_dirs = coords.shape
    
    target = 2 * n_steps
    if using_scipy:
        fast_len = fft_module.next_fast_len(target)
    else:
        fast_len = 1 << (target - 1).bit_length()

    # FFT
    if using_scipy:
        fft_coords = fft_module.rfft(coords, n=fast_len, axis=0, workers=-1)
    else:
        fft_coords = fft_module.rfft(coords, n=fast_len, axis=0)

    fft_coords *= np.conj(fft_coords)

    if using_scipy:
        autocorr_sum = fft_module.irfft(fft_coords, n=fast_len, axis=0, workers=-1)
    else:
        autocorr_sum = fft_module.irfft(fft_coords, n=fast_len, axis=0)
    
    autocorr_sum = autocorr_sum[:n_steps]
    del fft_coords
    
    # MSD Calculation
    Q = np.empty((n_steps + 1, n_dirs), np.float64)
    Q[0] = 0.0
    
    sq_coords = np.square(coords)
    np.cumsum(sq_coords, axis=0, out=Q[1:])
    
    del sq_coords
    del coords

    deltas = np.arange(1, n_steps, dtype=np.int32)
    
    sum_sq_end = Q[n_steps] - Q[deltas]
    sum_sq_start = Q[n_steps - deltas]
    
    ssd = sum_sq_start + sum_sq_end - 2 * autocorr_sum[deltas]
    
    n_samples = (n_steps - deltas).astype(np.float64)
    
    return np.column_stack([deltas.astype(np.float64), ssd.astype(np.float64), n_samples])

class UTIL_EN(BaseAnalysis):
                
    """
    This is a UTIL_EN class which perform Einstein analysis
    """
    def __init__(self, args):
                                        
        """
        Initialize class with input arguments and class objects
        
        """
        super().__init__(args)

    def cal_einstein(self, COM_data, box_df, species_counts, species_charges, dt, K_multi, drift, wrap_requested, charge_requested):
        """
        Calculates Einstein conductivity using the system dipole displacement.
        """
        # Identify species with non-zero charge
        keep_indices = []
        mol_charges = []
        current_offset = 0
        
        for resname, count in species_counts.items():
            # Get charge for this species; default to 1.0 if not found
            c = species_charges.get(resname, 1.0)
            for _ in range(count):
                if c != 0.0:
                    keep_indices.append(current_offset)
                    mol_charges.append(c)
                current_offset += 1
    
        if not keep_indices:
            self.log_message("WARNING", "No charged species found with non-zero charge.")
            self.log_message("WARNING", "Skipping Einstein conductivity analysis.")
            sys.exit(1)
    
        # Setup Dimensions and Folders
        self.generate_folders("results_einstein")
        num_snapshots = COM_data.shape[0]
        boxes = box_df[["Lx", "Ly", "Lz"]].values.astype(np.float32)
        
        # Handle LAMMPS vs Gromacs indexing
        is_lammps = getattr(self.args, 'LAM', False)
        c_slice = slice(0, 3) if is_lammps else slice(1, 4)
        
        total_dipole = np.zeros((num_snapshots, 3), dtype=np.float64)
    
        for i, global_idx in enumerate(tqdm(keep_indices, desc="Aggregating Dipole", unit="mol")):
            coords = COM_data[:, global_idx, c_slice].astype(np.float32)
            if not wrap_requested:
                coords = self.unwrap_on_the_fly(coords, boxes)
                if drift is not None:
                    coords -= drift
            else:
                if is_lammps:
                    lb, bl = self.args.lower_bounds, self.args.box_lengths
                    coords = (coords - lb) % bl + lb
                else:
                    coords %= boxes
            q = mol_charges[i] if charge_requested else 1.0
            total_dipole += (coords.astype(np.float64) * q)
    
        total_dipole -= total_dipole[0]
    
        directions = list(self.args.DIR) if (hasattr(self.args, 'DIR') and self.args.DIR) else ["x", "y", "z"]
        self.log_message("INFO", f"Calculating Ionic Conductivity for directions: {directions}")
        dim = len(directions)
        result = process_msd_fft_array((total_dipole, directions))
        
        if result is None:
            self.log_message("ERROR", "FFT MSD calculation returned None.")
            return
        
        deltas_steps_raw = result[:, 0]
        n_samples_raw = result[:, -1]
        msd_components = result[:, 1:-1]
        ssd_total = np.sum(msd_components, axis=1)
        
        valid = n_samples_raw > 0
        mean_msd_raw = np.zeros_like(ssd_total)
        mean_msd_raw[valid] = ssd_total[valid] / n_samples_raw[valid]
        
        delt_time = np.concatenate(([0.0], deltas_steps_raw * dt))
        mean_msd = np.concatenate(([0.0], mean_msd_raw))
        
        # Save results
        final_data = np.column_stack((delt_time, mean_msd))
        pd.DataFrame(data=final_data, columns=["delta (ps)", "product (10⁻²⁰ m²)"]).to_csv("results_einstein/einstein_conductivity.csv", index=False)
        
        try:
            max_index = int(self.args.t_window / dt + 1)
            end_idx = min(len(delt_time), max_index)
            if end_idx <= 2:
                raise ValueError("Not enough points for slope calculation.")
        
            # Extract the time and msd windows
            x = delt_time[1:end_idx]
            y = mean_msd[1:end_idx]

            popt, pcov = np.polyfit(x, y, 1, cov=True)
            slope_raw = popt[0]
            slope_error_raw = np.sqrt(pcov[0, 0])

            # Apply scaling factor
            slope_einstein = round(slope_raw * K_multi / dim, 4)
            std_error_einstein = round(slope_error_raw * K_multi / dim, 4)
        
            self.log_message("INFO", "\n" + "=" * 65) 
            self.log_message("INFO", "         Einstein Conductivity Results")
            self.log_message("INFO", "=" * 65)
            self.log_message("INFO", f"Einstein Conductivity: {slope_einstein:.4f} ± {std_error_einstein:.4f} (S/m)")
            self.log_message("INFO", "=" * 65 + "\n")
            
            pd.DataFrame({
                "Einstein Conductivity (S/m)": [slope_einstein],
                "Std_Error (S/m)": [std_error_einstein]
            }).to_csv("results_einstein/summary_einstein_conductivity.csv", index=False)
            
        except Exception as e:
            self.log_message("ERROR", f"Einstein slope calculation failed: {e}")

        return