#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Wed Nov 19 15:21:36 2025

@author: Shah Research Group, Oklahoma State University <jindal.shah@okstate.edu>

MDTransport: GROMACS & LAMMPS Transport Analysis Tools
Copyright (C) 2026  Ashutosh Kumar Verma, Amey Thorat and Jindal Shah

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
"""

import ctypes
import numpy as np
import pandas as pd
import multiprocessing
from .util import BaseAnalysis, tqdm

_transport_shared_data = {}

def init_transport_EH(dipole_buf, dipole_shape, self_msd_buf, self_msd_shape):
    """
    Initialize global shared data in each worker using Shared Memory.
    """
    global _transport_shared_data
    _transport_shared_data['dipoles'] = np.frombuffer(dipole_buf, dtype=np.float64).reshape(dipole_shape)
    _transport_shared_data['self_msd'] = np.frombuffer(self_msd_buf, dtype=np.float64).reshape(self_msd_shape)
    
def init_transport_EN(shared_buf, shape, species_map):
    """
    Initialize global shared data in each worker using Shared Memory.
    """
    global _transport_shared_data
    _transport_shared_data['coords'] = np.frombuffer(shared_buf, dtype=np.float64).reshape(shape)
    _transport_shared_data['species_map'] = species_map

def get_msd_fft(coords):
    """FFT-based MSD."""
    N = len(coords)
    coords = coords.astype(np.float64)
    sq_coords = np.sum(coords**2, axis=1)
    s1 = np.zeros(N, dtype=np.float64)
    sq_cum = np.cumsum(np.insert(sq_coords, 0, 0))
    for m in range(N):
        s1[m] = (sq_cum[N] - sq_cum[m]) + (sq_cum[N-m])
    s2 = np.zeros(N, dtype=np.float64)
    n_fft = 2**int(np.ceil(np.log2(2*N-1)))
    for d in range(coords.shape[1]):
        f = np.fft.fft(coords[:, d], n=n_fft)
        ac = np.fft.ifft(f * np.conjugate(f))[:N].real
        s2 += ac
    return (s1 - 2 * s2) / np.arange(N, 0, -1)

def process_delta_EN(args):
    """
    Calculates Einstein, Species-specific, Self, and Cross terms.
    """
    delta, dt = args
    all_coords = _transport_shared_data['coords']
    species_map = _transport_shared_data['species_map']
    n_mols, n_steps, dim = all_coords.shape
    n_frames = n_steps - delta
    current_time = delta * dt
    if delta == 0:
        res = [('einstein', 0, 0, 0.0, 0.0)]
        for i in range(len(species_map)):
            res.extend([('self', i, i, 0.0, 0.0), ('spec_total', i, i, 0.0, 0.0)])
            for j in range(i, len(species_map)): res.append(('cross', i, j, 0.0, 0.0))
        return res

    self_acc = np.zeros(len(species_map), dtype=np.float64)
    sum_dr_species = np.zeros((len(species_map), n_frames, dim), dtype=np.float64)
    for s_idx, indices in enumerate(species_map):
        for m in indices:
            dr_m = all_coords[m, delta:] - all_coords[m, :-delta]
            self_acc[s_idx] += np.sum(dr_m**2)
            sum_dr_species[s_idx] += dr_m
    total_dr_frame = np.sum(sum_dr_species, axis=0)
    results = [('einstein', 0, 0, current_time, np.sum(total_dr_frame**2) / n_frames)]
    for i in range(len(species_map)):
        s_val = self_acc[i] / n_frames
        results.append(('self', i, i, current_time, s_val))
        results.append(('spec_total', i, i, current_time, np.sum(sum_dr_species[i] * total_dr_frame) / n_frames))
        for j in range(i, len(species_map)):
            dot_ij = np.sum(sum_dr_species[i] * sum_dr_species[j]) / n_frames
            results.append(('cross', i, j, current_time, (dot_ij - s_val) if i == j else (2.0 * dot_ij)))
    return results

def process_delta_EH(args):
    """
    Calculates Einstein-Helfand, Species-specific, Self, and Cross terms.
    """
    delta, dt = args
    dipoles = _transport_shared_data['dipoles']
    self_msds = _transport_shared_data['self_msd']
    num_species, n_steps, dim = dipoles.shape
    n_frames = n_steps - delta
    current_time = delta * dt
    if delta == 0: return [('einstein',0,0,0,0)] # Simplified for brevity, same logic as EN 0
    
    delta_D = dipoles[:, delta:] - dipoles[:, :-delta]
    total_delta_D = np.sum(delta_D, axis=0) 
    results = [('einstein', 0, 0, current_time, np.sum(total_delta_D**2) / n_frames)]
    for i in range(num_species):
        s_val = self_msds[i, delta]
        results.append(('self', i, i, current_time, s_val))
        results.append(('spec_total', i, i, current_time, np.sum(delta_D[i] * total_delta_D) / n_frames))
        for j in range(i, num_species):
            dot_ij = np.sum(delta_D[i] * delta_D[j]) / n_frames
            results.append(('cross', i, j, current_time, (dot_ij - s_val) if i == j else (2.0 * dot_ij)))
    return results

class UTIL_TRANSPORT(BaseAnalysis):
            
    """
    This is a UTIL_TRANSPORT class which perform transport analysis
    
    """
    def __init__(self, args):
                                
        """
        Initialize class with input arguments and class objects
        
        """
        super().__init__(args)
        self.n_cores = self.args.n_cores
        
    def perform_final_analysis(self, charged_species, dt, K_multi, res_store, dim):
        """
        Calculates final conductivity terms with uncertainty.
        """
        slopes_data = {} 
        max_idx = int(self.args.t_window / dt + 1)
        for key, data in res_store.items():
            arr = np.array(data)
            if len(arr) < 3: continue
            arr = arr[arr[:, 0].argsort()] 
            end = min(len(arr), max_idx)
            x, y = arr[1:end, 0], arr[1:end, 1]
            popt, pcov = np.polyfit(x, y, 1, cov=True)
            slopes_data[key] = (popt[0] * K_multi / dim, np.sqrt(pcov[0, 0]) * K_multi / dim)

        self.log_message("INFO", "=" * 60)
        self.log_message("INFO", "         Transport Coefficients Summary")
        self.log_message("INFO", "=" * 60)
        for key in sorted(slopes_data.keys(), key=lambda x: (x != "Einstein", x)):
            val, err = slopes_data[key]
            self.log_message("INFO", f"{key:<32} : {val:>8.4f} ± {err:<8.4f} (S/m)")

        if "Einstein" in slopes_data:
            total_v = slopes_data["Einstein"][0]
            self.log_message("INFO", "=" * 60)
            self.log_message("INFO", "         Transference Numbers Summary")
            self.log_message("INFO", "=" * 60)
            for name in charged_species:
                if f"{name}_term" in slopes_data:
                    self.log_message("INFO", f"{name:<32} : {slopes_data[f'{name}_term'][0]/total_v:.4f}")
        self.log_message("INFO", "=" * 60 + "\n")

    def calculate_einstein_conductivity(self, COM_data, box_df, dt, species_counts, species_charges, n_delta, K_multi, drift, wrap_requested, charge_requested):
        """
        Calculates Transport coefficients using Einstein formalism for specific directions.
        """
        directions = list(self.args.DIR) if (hasattr(self.args, 'DIR') and self.args.DIR) else ["x", "y", "z"]
        dir_indices = [{"x":0,"y":1,"z":2}[d.lower()] for d in directions]
        dim, n_steps = len(dir_indices), COM_data.shape[0]
        charged_species = [s for s in species_counts.keys() if species_charges.get(s, 0) != 0]
        boxes = box_df[["Lx", "Ly", "Lz"]].values.astype(np.float64)[:, dir_indices]
        c_slice = slice(0, 3) if getattr(self.args, 'LAM', False) else slice(1, 4)

        if self.args.EH:
            dipole_arr = np.zeros((len(charged_species), n_steps, dim), dtype=np.float64)
            self_msd_arr = np.zeros((len(charged_species), n_steps), dtype=np.float64)
            current_offset = 0
            for s_idx, resname in enumerate(charged_species):
                count = species_counts[resname]
                q = species_charges.get(resname, 1.0)
                for i in tqdm(range(count), desc=f"Aggregating {resname} Dipole"):
                    coords = self.unwrap_on_the_fly(COM_data[:, current_offset+i, c_slice][:, dir_indices], boxes)
                    if drift is not None: coords -= (drift[:, dir_indices] if drift.ndim > 1 else drift[dir_indices])
                    dipole_arr[s_idx] += coords * q
                    self_msd_arr[s_idx] += (q**2) * get_msd_fft(coords)
                current_offset += count
            shm_args = (multiprocessing.RawArray(ctypes.c_double, dipole_arr.size), dipole_arr.shape, 
                        multiprocessing.RawArray(ctypes.c_double, self_msd_arr.size), self_msd_arr.shape)
            np.frombuffer(shm_args[0], dtype=np.float64)[:] = dipole_arr.flatten()
            np.frombuffer(shm_args[2], dtype=np.float64)[:] = self_msd_arr.flatten()
            worker_init, worker_func = init_transport_EH, process_delta_EH
            max_delta = int(n_steps)
        else:
            total_mols = sum(species_counts[s] for s in charged_species)
            shm_buf = multiprocessing.RawArray(ctypes.c_double, total_mols * n_steps * dim)
            shared_arr = np.frombuffer(shm_buf, dtype=np.float64).reshape((total_mols, n_steps, dim))
            species_map, current_offset, shared_idx = [], 0, 0
            for resname in charged_species:
                count = species_counts[resname]; q = species_charges.get(resname, 1.0); start_idx = shared_idx
                for i in range(count):
                    coords = self.unwrap_on_the_fly(COM_data[:, current_offset+i, c_slice][:, dir_indices], boxes)
                    if drift is not None: coords -= (drift[:, dir_indices] if drift.ndim > 1 else drift[dir_indices])
                    shared_arr[shared_idx] = coords * q
                    shared_idx += 1
                species_map.append(list(range(start_idx, shared_idx))); current_offset += count
            shm_args = (shm_buf, shared_arr.shape, species_map)
            worker_init, worker_func = init_transport_EN, process_delta_EN
            max_delta = min(int(max(n_delta, 1000)/dt+1), n_steps)

        tasks = [(d, dt) for d in range(0, max_delta, self.args.steps)]
        res_store = {"Einstein": []}
        for n in charged_species:
            res_store[f"self_{n}"], res_store[f"{n}_term"] = [], []
            for n2 in charged_species:
                if charged_species.index(n2) >= charged_species.index(n): res_store[f"cross_{n}_{n2}"] = []

        ctx = multiprocessing.get_context(self.args.get_context)
        with ctx.Pool(processes=self.n_cores, initializer=worker_init, initargs=shm_args) as pool:
            for delta_data in tqdm(pool.imap_unordered(worker_func, tasks), total=len(tasks), desc="Calculating Transport Coeff."):
                for r_type, i, j, t, val in delta_data:
                    if r_type == 'einstein': key = "Einstein"
                    elif r_type == 'self': key = f"self_{charged_species[i]}"
                    elif r_type == 'spec_total': key = f"{charged_species[i]}_term"
                    else: key = f"cross_{charged_species[i]}_{charged_species[j]}"
                    res_store[key].append([t, val])

        self.generate_folders("results_transport")
        for key, vals in res_store.items():
            if vals: pd.DataFrame(sorted(vals), columns=["delta", "product"]).to_csv(f"results_transport/{key}.csv", index=False)
        self.perform_final_analysis(charged_species, dt, K_multi, res_store, dim=dim)