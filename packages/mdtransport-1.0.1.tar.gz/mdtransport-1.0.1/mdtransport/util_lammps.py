#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Wed Nov 19 15:21:36 2025

@author: Shah Research Group, Oklahoma State University <jindal.shah@okstate.edu>

MDTransport: GROMACS & LAMMPS Transport Analysis Tools
Copyright (C) 2026  Ashutosh Kumar Verma, Amey Thorat and Jindal Shah

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
"""

import io
import os
import gc
import re
import sys
import glob
import ctypes
import warnings
import numpy as np
import collections
import pandas as pd
import multiprocessing
from functools import partial
from .util import BaseAnalysis, tqdm

# Global variable to hold the shared memory reference in each worker process
atom_masses_global = None
atom_charges_global = None
mol_indices_global = None
mol_masses_global = None
time_factor_global = None
worker_shared_buffer = None
worker_shared_shape = None

def init_worker(shared_buffer, shape):
    """This runs once when each child process starts."""
    global worker_shared_buffer, worker_shared_shape
    worker_shared_buffer = shared_buffer
    worker_shared_shape = shape
    
def process_mdanalysis(task_info, return_atoms=False):
        
    """
    Function to processes a small chunk of frames.
    """
    (data_file, traj_file, frame_indices, global_indices, 
     mol_indices, start_indices, masses_expanded, 
     mol_mass_divisor, dump_frame, fallback_box, fallback_lower, 
     kept_indices, data_mode, mmap_opts) = task_info

    import MDAnalysis as mda
    warnings.filterwarnings("ignore", message=".*Reader has no dt information.*", category=UserWarning)

    if data_mode == "disk":
        target_arr = np.memmap(mmap_opts['filename'], dtype=np.float32, mode='r+', shape=mmap_opts['shape'])
    else:
        global worker_shared_buffer, worker_shared_shape
        target_arr = np.frombuffer(worker_shared_buffer, dtype=np.float32).reshape(worker_shared_shape)

    ext = os.path.splitext(traj_file)[1].lower()

    try:
        if ext in [".lammpstrj"]:
            u = mda.Universe(data_file, traj_file, format="LAMMPSDUMP", topology_format="DATA", in_memory=False)

        elif ext == ".xyz":
            u = mda.Universe(data_file, traj_file, format="XYZ", topology_format="DATA", in_memory=False)

        elif ext == ".xtc":
            u = mda.Universe(data_file, traj_file, format="XTC", topology_format="DATA", in_memory=False)

        elif ext == ".dcd":
            u = mda.Universe(data_file, traj_file, format="DCD", topology_format="DATA", in_memory=False)

        elif ext in [".nc", ".ncdf", ".netcdf"]:
            u = mda.Universe(data_file, traj_file, format="NETCDF", topology_format="DATA", in_memory=False)

        else:
            with open(traj_file, 'r') as f:
                first_line = f.readline().strip()
                
            if first_line.startswith("ITEM: TIMESTEP"):
                u = mda.Universe(data_file, traj_file, format="LAMMPSDUMP", topology_format="DATA", in_memory=False)

            elif first_line.isdigit():
                u = mda.Universe(data_file, traj_file, format="XYZ", topology_format="DATA", in_memory=False)

    except Exception:
        sys.exit(1)
    
    num_frames = len(frame_indices)
    metadata_chunk = np.zeros((num_frames, 8), dtype=np.float32)

    for idx, f_idx in enumerate(frame_indices):
        g_idx = global_indices[idx]
        ts = u.trajectory[f_idx]
        
        box = ts.dimensions[:3].astype(np.float32) if (ts.dimensions is not None and ts.dimensions[0] > 1e-5) else np.array(fallback_box, dtype=np.float32)
        low_bound = getattr(ts, 'origin', fallback_lower)[:3].astype(np.float32)
        time_val = ts.frame * dump_frame
        
        pos = ts.positions
        
        if return_atoms:
            target_arr[g_idx] = pos[kept_indices].astype(np.float32)
        else:
            ref_pos_expanded = pos[start_indices][mol_indices]
            delta = pos - ref_pos_expanded
            delta -= box * np.round(delta / box)
            unwrapped_pos = ref_pos_expanded + delta
            
            weighted_pos = unwrapped_pos * masses_expanded
            n_mols = len(mol_mass_divisor)
            mol_wpos_sum = np.zeros((n_mols, 3))
            for i in range(3):
                np.add.at(mol_wpos_sum[:, i], mol_indices, weighted_pos[:, i])
            
            target_arr[g_idx] = (mol_wpos_sum / mol_mass_divisor).astype(np.float32)

        metadata_chunk[idx] = [g_idx, time_val, box[0], box[1], box[2], low_bound[0], low_bound[1], low_bound[2]]

    u.trajectory.close()
    if data_mode == "disk": del target_arr

    return metadata_chunk

def process_chemfiles(task_info, return_atoms=False):

    """
    Function to processes a small chunk of frames.
    """
    (traj_file, frame_indices, global_indices, mol_indices, 
     start_indices, masses_expanded, mol_mass_divisor, dump_frame,
     fallback_box, fallback_lower, kept_indices, data_mode, mmap_opts) = task_info

    import chemfiles
    
    if data_mode == "disk":
        target_arr = np.memmap(mmap_opts['filename'], dtype=np.float32, mode='r+', shape=mmap_opts['shape'])
    else:
        global worker_shared_buffer, worker_shared_shape
        target_arr = np.frombuffer(worker_shared_buffer, dtype=np.float32).reshape(worker_shared_shape)
    
    ext = os.path.splitext(traj_file)[1].lower()
    try:
        if ext in [".lammpstrj"]:
            traj = chemfiles.Trajectory(traj_file, mode='r', format="LAMMPS")
        elif ext == ".xyz":
            traj = chemfiles.Trajectory(traj_file, mode='r', format="XYZ")
        elif ext == ".xtc":
            traj = chemfiles.Trajectory(traj_file, mode='r', format="XTC")
        else:
            with open(traj_file, 'r') as f:
                first_line = f.readline().strip()
            if first_line.startswith("ITEM: TIMESTEP"):
                traj = chemfiles.Trajectory(traj_file, mode='r', format="LAMMPS")
            elif first_line.isdigit():
                traj = chemfiles.Trajectory(traj_file, mode='r', format="XYZ")
    except Exception:
        sys.exit(1)
    
    num_chunk_frames = len(frame_indices)
    metadata_chunk = np.zeros((num_chunk_frames, 8), dtype=np.float32)

    for idx, fi in enumerate(frame_indices):
        g_idx = global_indices[idx]
        frame = traj.read_step(fi)
        
        lens = np.array(frame.cell.lengths, dtype=np.float32)
        if lens[0] < 1e-5:
            lens = np.array(fallback_box, dtype=np.float32)
            low_bound = np.array(fallback_lower, dtype=np.float32)
        else:
            low_bound = np.zeros(3, dtype=np.float32) 
        
        pos = frame.positions 

        if return_atoms:
            target_arr[g_idx] = pos[kept_indices].astype(np.float32)
        else:
            ref_pos_expanded = pos[start_indices][mol_indices]
            delta = pos - ref_pos_expanded
            delta -= lens * np.round(delta / lens)
            
            unwrapped_pos = ref_pos_expanded + delta
            weighted_pos = unwrapped_pos * masses_expanded
            
            n_mols = len(mol_mass_divisor)
            mol_wpos_sum = np.zeros((n_mols, 3))
            for d in range(3):
                np.add.at(mol_wpos_sum[:, d], mol_indices, weighted_pos[:, d])
            
            target_arr[g_idx] = (mol_wpos_sum / mol_mass_divisor).astype(np.float32)

        metadata_chunk[idx] = [g_idx, fi * dump_frame, lens[0], lens[1], lens[2], low_bound[0], low_bound[1], low_bound[2]]

    traj.close()
    if data_mode == "disk": del target_arr

    return metadata_chunk

def process_lammps_manual_worker(task_args, return_atoms=False):
    """
    Function to extracts positions AND charges per frame for polarizable/fluctuating charge systems.
    """
    
    (file_path, frame_tasks, column_names, atom_to_reindexed_mol, type_map, 
     mass_map, charge_map, kept_indices, n_mols_total, mol_start_indices, 
     is_xyz, data_mode, mmap_opts) = task_args
    
    results = []
    col_set = set(column_names)
    has_dynamic_q = "q" in col_set
    
    if is_xyz: c_cols = ["type", "x", "y", "z"]
    elif {"xu", "yu", "zu"}.issubset(col_set): c_cols = ["xu", "yu", "zu"]
    elif {"xsu", "ysu", "zsu"}.issubset(col_set): c_cols = ["xsu", "ysu", "zsu"]
    elif {"xs", "ys", "zs"}.issubset(col_set): c_cols = ["xs", "ys", "zs"]
    else: c_cols = ["x", "y", "z"]
    is_scaled = not is_xyz and any(c in col_set for c in ["xs", "ys", "zs", "xsu", "ysu", "zsu"])

    mmap_arr = None
    if data_mode == "disk":
        mmap_arr = np.memmap(mmap_opts['filename'], dtype=mmap_opts['dtype'], 
                             mode='r+', shape=mmap_opts['shape'])

    with open(file_path, 'r') as f:
        for offset_start, offset_end, sys_dt, box, lower, g_idx in frame_tasks:
            f.seek(offset_start)
            atom_data = f.read(offset_end - offset_start)
            df = pd.read_csv(io.StringIO(atom_data), sep=r"\s+", header=None, 
                             names=column_names if not is_xyz else c_cols)
            
            # Coordinate Scaling
            if is_scaled:
                for i in range(3):
                    df[c_cols[i]] = (df[c_cols[i]] * box[i]) + lower[i]

            pos = df[["x", "y", "z"] if is_xyz else c_cols].values.astype(np.float64)
            
            # Charge Handling
            if has_dynamic_q:
                atom_charges = df["q"].values.astype(np.float32)
            else:
                ids = df["id"].values if "id" in df.columns else np.arange(1, len(df)+1)
                atom_charges = np.array([charge_map.get(i, 0.0) for i in ids], dtype=np.float32)

            if return_atoms:
                final_data = pos[kept_indices].astype(np.float32)
                final_q = atom_charges[kept_indices]
            else:
                # COM Mode: Unwrap
                ids = df["id"].values if "id" in df.columns else np.arange(1, len(df)+1)
                mols = np.array([atom_to_reindexed_mol.get(i, 0) for i in ids], dtype=np.int32)
                types = np.array([type_map.get(i, 1) for i in ids], dtype=np.int32)
                masses = np.array([mass_map.get(t, 1.0) for t in types], dtype=np.float64)
                
                ref_pos = pos[mol_start_indices][mols]
                delta = pos - ref_pos
                delta -= box * np.round(delta / box)
                unwrapped_pos = ref_pos + delta
                
                sum_w = np.zeros((n_mols_total, 3))
                sum_m = np.bincount(mols, weights=masses, minlength=n_mols_total)
                final_q = np.bincount(mols, weights=atom_charges, minlength=n_mols_total).astype(np.float32)
                
                for d in range(3):
                    sum_w[:, d] = np.bincount(mols, weights=(unwrapped_pos[:, d] * masses), minlength=n_mols_total)
                
                final_data = (sum_w / np.where(sum_m == 0, 1.0, sum_m)[:, np.newaxis]).astype(np.float32)

            # Storage handling
            if data_mode == "disk":
                mmap_arr[g_idx] = final_data
                results.append((g_idx, None, final_q, box, lower, sys_dt))
            else:
                results.append((g_idx, final_data, final_q, box, lower, sys_dt))
                
    if mmap_arr is not None:
        mmap_arr.flush()
        del mmap_arr
    return results

def process_ovito_frame_worker(task_args, return_atoms=False):
    """
    Worker to process a chunk of frames using OVITO.
    """
    from ovito.io import import_file
    warnings.filterwarnings('ignore')

    (traj_file, chunk_frame_indices, chunk_global_indices, has_ids, 
     mol_indices, start_indices, masses_expanded, mol_mass_divisor, 
     dump_frame, fallback_box, fallback_lower, kept_indices, 
     data_mode, mmap_opts) = task_args

    if data_mode == "disk":
        target_arr = np.memmap(mmap_opts['filename'], dtype=np.float32, mode='r+', shape=mmap_opts['shape'])
    else:
        global worker_shared_buffer, worker_shared_shape
        target_arr = np.frombuffer(worker_shared_buffer, dtype=np.float32).reshape(worker_shared_shape)

    pipeline = import_file(traj_file)
    n_mols = len(mol_mass_divisor)
    
    num_frames = len(chunk_frame_indices)
    metadata_chunk = np.zeros((num_frames, 8), dtype=np.float32)

    for i, fi in enumerate(chunk_frame_indices):
        g_idx = chunk_global_indices[i]
        data = pipeline.compute(fi)
        
        if data.cell is None or np.linalg.norm(data.cell[:3, :3]) < 1e-5:
            lens = np.array(fallback_box, dtype=np.float32)
            low_bound = np.array(fallback_lower, dtype=np.float32)
        else:
            cell_matrix = np.array(data.cell)
            lens = np.array([np.linalg.norm(cell_matrix[:, 0]), 
                             np.linalg.norm(cell_matrix[:, 1]), 
                             np.linalg.norm(cell_matrix[:, 2])], dtype=np.float32)
            low_bound = cell_matrix[:, 3].astype(np.float32)
        
        pos = np.array(data.particles.positions)

        if has_ids:
            ids = np.array(data.particles['Particle Identifier'])
            pos = pos[np.argsort(ids)]
        
        if return_atoms:
            target_arr[g_idx] = pos[kept_indices].astype(np.float32)
        else:
            ref_pos_expanded = pos[start_indices][mol_indices]
            delta = pos - ref_pos_expanded
            delta -= lens * np.round(delta / lens)
            unwrapped_pos = ref_pos_expanded + delta
            
            weighted_pos = unwrapped_pos * masses_expanded
            mol_wpos_sum = np.zeros((n_mols, 3))
            for dim in range(3):
                np.add.at(mol_wpos_sum[:, dim], mol_indices, weighted_pos[:, dim])
            
            target_arr[g_idx] = (mol_wpos_sum / mol_mass_divisor).astype(np.float32)

        metadata_chunk[i] = [g_idx, fi * dump_frame, lens[0], lens[1], lens[2], low_bound[0], low_bound[1], low_bound[2]]

    del data
    del pipeline
    if data_mode == "disk": del target_arr
    
    return metadata_chunk

def create_array_backend(filename, shape, dtype, mode, data_mode):
    if data_mode == "disk":
        arr = np.memmap(filename, dtype=dtype, mode=mode, shape=shape)
        return arr
    else:
        if mode == "w+" or mode == "r+":
            return np.zeros(shape, dtype=dtype)
        elif mode == "full_nan":
            arr = np.empty(shape, dtype=dtype)
            arr[:] = np.nan
            return arr
        
class UTIL_LAMMPS(BaseAnalysis):
        
    """
    This is a UTIL_LAMMPS class which generate species data for LAMMPS analysis
    
    """
    def __init__(self, args):
                        
        """
        Initialize class with input arguments and class objects
        
        """
        super().__init__(args)
        
        self.mass_map = None
        self.charge_map = None
        self.mass_map = None        
        self.charge_map = None
        self.box_lengths = None   
        self.lower_bounds = None 
        self.n_cores = self.args.n_cores

    def parse_lammps_input_for_charges(self, input_filepath):
        """
        Scans a LAMMPS input script for 'set type X charge Y' commands.
        """
        type_charges = {}
        try:
            with open(input_filepath, "r") as f:
                for line in f:
                    line = line.strip()
                    # Skip comments
                    if line.startswith("#"): continue
                    
                    # Look for lines like: set type 1 charge -0.8
                    if line.startswith("set") and "type" in line and "charge" in line:
                        parts = line.split()
                        try:
                            # Dynamically find the indices of 'type' and 'charge'
                            t_idx = parts.index("type") + 1
                            c_idx = parts.index("charge") + 1
                            t_id = int(parts[t_idx])
                            q_val = float(parts[c_idx])
                            type_charges[t_id] = q_val
                        except (ValueError, IndexError):
                            continue
        except Exception as e:
            self.log_message("ERROR", f"Could not read LAMMPS input script: {e}")
            
        return type_charges
                           
    def load_and_parse_data_file(self):
        
        """
        Parser for LAMMPS data file. Auto-detects atom_style based on column count (atomic, molecular, charge, or full).
        Allows overriding charges from a LAMMPS input script if provided via args.
        """
        if not self.args.DATA or not os.path.exists(self.args.DATA):
            self.log_message("ERROR", "Topology missing or file not found.")
            sys.exit(0)

        masses = {}
        id_to_charge = {}
        id_to_mol = {}
        id_to_type = {}
        
        # Temporary variables for box parsing
        xlo, xhi = 0.0, 0.0
        ylo, yhi = 0.0, 0.0
        zlo, zhi = 0.0, 0.0
        
        current_section = None
        atom_style_detected = "unknown"
        
        # Check against this list to know when a previous section has ended.
        LAMMPS_SECTIONS = [
            "Masses", "Atoms", "Velocities", "Ellipsoids", "Lines", "Triangles", "Bodies",
            "Bonds", "Angles", "Dihedrals", "Impropers",
            "Pair Coeffs", "PairIJ Coeffs",
            "Bond Coeffs", "Angle Coeffs", "Dihedral Coeffs", "Improper Coeffs",
            "BondBond Coeffs", "BondAngle Coeffs",
            "MiddleBondTorsion Coeffs", "EndBondTorsion Coeffs",
            "AngleTorsion Coeffs", "AngleAngleTorsion Coeffs",
            "BondBond13 Coeffs", "AngleAngle Coeffs",
            "Atom Type Labels", "Bond Type Labels",
            "Angle Type Labels", "Dihedral Type Labels",
            "Improper Type Labels",
        ]

        self.log_message("DEBUG", f"Parsing topology from: {self.args.DATA}")
        
        with open(self.args.DATA, "r") as f:
            for line in f:
                # Remove comments and whitespace
                line = line.partition('#')[0].strip()
                if not line:
                    continue
                
                if "xlo xhi" in line:
                    parts = line.split()
                    xlo, xhi = float(parts[0]), float(parts[1])
                    continue
                if "ylo yhi" in line:
                    parts = line.split()
                    ylo, yhi = float(parts[0]), float(parts[1])
                    continue
                if "zlo zhi" in line:
                    parts = line.split()
                    zlo, zhi = float(parts[0]), float(parts[1])
                    continue
                
                # Check if the current line matches ANY known LAMMPS section header.
                found_new_section = False
                for header in LAMMPS_SECTIONS:
                    if line.startswith(header):
                        current_section = header
                        found_new_section = True
                        break
                
                # If found a header, skip processing this line as data
                if found_new_section:
                    continue

                parts = line.split()

                # PARSE MASSES
                if current_section == "Masses":
                    if len(parts) >= 2 and parts[0].isdigit():
                        masses[int(parts[0])] = float(parts[1])

                # PARSE ATOMS
                elif current_section == "Atoms":
                    if not parts[0].isdigit(): 
                        continue 
                    
                    num_cols = len(parts)
                    
                    # Defaults
                    a_id = int(parts[0])
                    m_id = 0    
                    t_id = 1    
                    q_val = 0.0 
                    
                    # atom_style full (ID Mol Type q x y z ...)
                    if num_cols >= 7:
                        atom_style_detected = "full"
                        m_id = int(parts[1])
                        t_id = int(parts[2])
                        q_val = float(parts[3])

                    # atom_style atomic ( ID Type x y z ...)
                    elif num_cols == 5:
                        atom_style_detected = "atomic"
                        t_id = int(parts[1])

                    elif num_cols == 6:
                        # Check 3rd column to distinguish molecular vs charge
                        col_2 = parts[2]
                        if "." in col_2:
                            atom_style_detected = "charge"
                            t_id = int(parts[1])
                            q_val = float(parts[2])
                        else:
                            atom_style_detected = "molecular"
                            m_id = int(parts[1])
                            t_id = int(parts[2])

                    # Save to Dictionaries
                    id_to_mol[a_id] = m_id
                    id_to_type[a_id] = t_id
                    id_to_charge[a_id] = q_val
        
        # Check if charges from DATA file are basically zero
        total_charge_magnitude = sum(abs(q) for q in id_to_charge.values())
        charges_are_zero = total_charge_magnitude < 1e-5
        
        if charges_are_zero:
            self.log_message("WARNING", f"All atomic charges in the DATA file are zero (or atom_style is '{atom_style_detected}').")
            self.log_message("WARNING", "If charges were set in the LAMMPS input script, please provide it using the appropriate argument (e.g., --lam_in <path/to/script.in>).")

        # Check if a LAMMPS input script was provided via command line arguments
        lammps_input_script = getattr(self.args, 'LAM_IN', None)

        if lammps_input_script and os.path.exists(lammps_input_script):
            self.log_message("INFO", f"Parsing LAMMPS input script for charges: {lammps_input_script}")
            extracted_charges = self.parse_lammps_input_for_charges(lammps_input_script)
            
            if extracted_charges:
                self.log_message("INFO", f"Successfully extracted charges for types: {extracted_charges}")
                # Apply extracted charges to id_to_charge mapping
                for a_id, t_id in id_to_type.items():
                    if t_id in extracted_charges:
                        id_to_charge[a_id] = extracted_charges[t_id]
                self.log_message("INFO", "Charges overridden successfully from input script.")
            else:
                self.log_message("WARNING", "No valid 'set type X charge Y' commands found in the provided script.")

        # Validation
        if not masses:
            self.log_message("WARNING", "No Masses found in data file.")
        
        if not id_to_mol:
            self.log_message("ERROR", "No Atoms found. Check data file format.")
            sys.exit(1)
        
        # Box lengths
        Lx = xhi - xlo
        Ly = yhi - ylo
        Lz = zhi - zlo
        
        # Return outputs
        self.mass_map = masses    
        self.charge_map = id_to_charge
        self.mol_map = id_to_mol
        self.type_map = id_to_type
        self.box_lengths = (Lx, Ly, Lz)
        self.lower_bounds = np.array([xlo, ylo, zlo])
        
        self.log_message("DEBUG", f"Topology Loaded (Style: {atom_style_detected}): {len(id_to_mol)} atoms.")

    def prepare_for_processing(self, file_path):
                        
        """
        Function to create snapshots and process them
        
        """
        if not os.path.exists(file_path):
            self.log_message("ERROR", f"File {file_path} not found.")
            sys.exit(1)

        try:
            with open(file_path, 'r') as f:
                first_line = f.readline().strip()
        except Exception:
            self.log_message("ERROR", "Unsupported format. This option accepts LAMMPS custom or XYZ files. Use --mda or other flags if using xtc or other formats.")
            sys.exit(1)

        if first_line.startswith("ITEM: TIMESTEP"):
            self.log_message("DEBUG", "Detected format: LAMMPS custom trajectory (.lammpstrj)")

        if first_line.isdigit():
            self.log_message("DEBUG", "Detected format: XYZ trajectory (.xyz)")
            
        first_snapshot_gen = self.extract_snapshots(file_path, 1, 0, 0)
        try:
            _, _, column_names, _ = next(first_snapshot_gen)
        except StopIteration:
            self.log_message("ERROR", f"\nCould not read a single snapshot from '{file_path}'. Is the file empty or corrupt?")
            sys.exit(1)

        needs_data_file = "mass" not in column_names or "q" not in column_names

        if needs_data_file:

            self.load_and_parse_data_file()


    def parse_species_counts(self):
        """
        Function to Detects actual species and counts from the DATA file .
        """
        user_aliases = []
        resname_input = getattr(self.args, "LAMP_SPECIES", None)
        if resname_input:
            tokens = " ".join(resname_input).replace(',', ' ').split()
            user_aliases = [t.strip() for t in tokens if t.strip()]
    
        mol_to_types = collections.defaultdict(list)
        for a_id, m_id in self.mol_map.items():
            mol_to_types[m_id].append(self.type_map[a_id])
    
        sig_order = [] 
        sig_counts = {}
    
        # Handle Atomic vs Molecular
        if len(mol_to_types) == 1 and 0 in mol_to_types:
            for a_id in sorted(self.type_map.keys()):
                sig = (self.type_map[a_id],)
                if sig not in sig_counts:
                    sig_order.append(sig); sig_counts[sig] = 1
                else:
                    sig_counts[sig] += 1
        else:
            for m_id in sorted(mol_to_types.keys()):
                if m_id == 0: continue
                sig = tuple(sorted(mol_to_types[m_id]))
                if sig not in sig_counts:
                    sig_order.append(sig); sig_counts[sig] = 1
                else:
                    sig_counts[sig] += 1
    
        species_counts = {}
        new_species_list = [] 
        
        for i, sig in enumerate(sig_order):
            count = sig_counts[sig]
            if i < len(user_aliases):
                name = user_aliases[i]
            else:
                name = f"species_{i+1}"
            
            species_counts[name] = count
            
            new_species_list.append(name)
            new_species_list.append(str(count)) 
    
        self.args.SPECIES = new_species_list
        
        total_mols = sum(species_counts.values())
        self.log_message("DEBUG", f"Detected Composition: {species_counts}")
        
        return species_counts, total_mols

    def unbreak_molecules_in_frame(self, df, box_lengths, coord_cols):
                        
        """
        Function to fix broken molecules
        
        """
        corrected_dfs = []
        for mol_id, group in df.groupby("mol"):
            if len(group) > 1:
                coords = group[coord_cols].values
                ref_pos = coords[0, :]
                displacements = coords - ref_pos
                displacements -= box_lengths * np.rint(displacements / box_lengths)
                corrected_coords = ref_pos + displacements
                corrected_group = group.copy()
                corrected_group[coord_cols] = corrected_coords
                corrected_dfs.append(corrected_group)
            else:
                corrected_dfs.append(group)
        return pd.concat(corrected_dfs)
    
    def unwrap_trajectories(self, com_snapshots, box_lengths, desc, lower_bounds=None):
        
        """
        Function to unwrap trajectory
        """
    
        n_frames, n_mols, _ = com_snapshots.shape
        unwrapped_coords = com_snapshots.copy()
        half_box = box_lengths / 2.0
    
        for i in tqdm(range(n_mols), desc=desc, unit="mol"):
            traj = unwrapped_coords[:, i, :]
            displacements = np.diff(traj, axis=0, prepend=traj[0:1])
            image_jumps = np.zeros_like(displacements, dtype=int)
            image_jumps[displacements > half_box] = -1
            image_jumps[displacements < -half_box] = 1
            image_flags = np.cumsum(image_jumps, axis=0)
            unwrapped_coords[:, i, :] = traj + image_flags * box_lengths
    
        return unwrapped_coords

    def wrap_trajectories(self, com_snapshots, box_lengths, lower_bounds=None):
        
        """
        Function to wrap trajectory
        """
    
        n_frames, _, _ = com_snapshots.shape
    
        if lower_bounds is None:
            lower_bounds = np.zeros_like(box_lengths)
    
        box_len_reshaped = box_lengths.reshape(n_frames, 1, 3)
        lower_b_reshaped = lower_bounds.reshape(n_frames, 1, 3)
    
        wrapped_coords = (com_snapshots - lower_b_reshaped) % box_len_reshaped + lower_b_reshaped
    
        return wrapped_coords

    def process_single_snapshot(self, snapshot_data):
                        
        """
        Function to process snapshots and generate species data
        """

        sys_dt, snapshot, column_names, box_bounds = snapshot_data

        if box_bounds:
            lower_x, upper_x = map(float, box_bounds[0].split())
            lower_y, upper_y = map(float, box_bounds[1].split())
            lower_z, upper_z = map(float, box_bounds[2].split())
            Lx, Ly, Lz = upper_x - lower_x, upper_y - lower_y, upper_z - lower_z
            lower_bounds_np = np.array([lower_x, lower_y, lower_z])
        else:
            if hasattr(self, 'box_lengths'):
                Lx, Ly, Lz = self.box_lengths 
                lower_bounds_np = getattr(self, 'lower_bounds', np.array([0.0, 0.0, 0.0]))
            else:
                self.log_message("WARNING", "Could not parse box lengths. Using dummy large box.")
                Lx, Ly, Lz = 10000.0, 10000.0, 10000.0
                lower_bounds_np = np.array([0.0, 0.0, 0.0])
            
        Volume = Lx * Ly * Lz * 1e-30
        box_lengths_np = np.array([Lx, Ly, Lz])

        col_set = set(column_names)
        is_scaled = False
        using_unwrapped = False
        coord_cols = []

        if {"xu", "yu", "zu"}.issubset(col_set):
            coord_cols = ["xu", "yu", "zu"]
            using_unwrapped = True
            is_scaled = False
        elif {"xsu", "ysu", "zsu"}.issubset(col_set):
            coord_cols = ["xsu", "ysu", "zsu"]
            using_unwrapped = True
            is_scaled = True
        elif {"x", "y", "z"}.issubset(col_set):
            coord_cols = ["x", "y", "z"]
            using_unwrapped = False
            is_scaled = False
        elif {"xs", "ys", "zs"}.issubset(col_set):
            coord_cols = ["xs", "ys", "zs"]
            using_unwrapped = False
            is_scaled = True
        else:
            error_msg = f"No valid coordinate columns found in: {column_names}"
            self.log_message("ERROR", error_msg)
            sys.exit(1)

        coord_map = {c: f"{ax}_coord" for c, ax in zip(coord_cols, "xyz")}

        snapshot_str = "\n".join(snapshot)
        df = pd.read_csv(
            io.StringIO(snapshot_str), sep=r"\s+", header=None, names=column_names
        )
        df = df.rename(columns=coord_map)

        if is_scaled:
            df["x_coord"] = (df["x_coord"] * Lx) + lower_bounds_np[0]
            df["y_coord"] = (df["y_coord"] * Ly) + lower_bounds_np[1]
            df["z_coord"] = (df["z_coord"] * Lz) + lower_bounds_np[2]

        if "id" not in df.columns:
            sorted_ids = sorted(self.mol_map.keys())
            if len(df) != len(sorted_ids):
                error_msg = f"Mismatch: Snapshot has {len(df)} atoms, but Topology has {len(sorted_ids)} atoms."
                self.log_message("ERROR", error_msg)
                raise ValueError(error_msg)
            df["id"] = sorted_ids

        df["id"] = df["id"].astype(int)
        
        if "mol" not in df.columns:
            df["mol"] = df["id"].map(self.mol_map)
        if "type" not in df.columns:
            df["type"] = df["id"].map(self.type_map)
        if "mass" not in df.columns:
            df["mass"] = df["type"].map(self.mass_map)
        if "q" not in df.columns:
            df["q"] = df["id"].map(self.charge_map).fillna(0.0)

        df = df.astype({"mol": int, "mass": float, "q": float})
        
        # If the coordinates were wrapped (x,y,z or xs,ys,zs), we must unbreak molecules
        if not using_unwrapped:
            df = self.unbreak_molecules_in_frame(
                df, box_lengths_np, ["x_coord", "y_coord", "z_coord"]
            )

        # COM Calculation
        coords = df[["x_coord", "y_coord", "z_coord"]].values
        masses = df["mass"].values.reshape(-1, 1)
        
        # Multiply physical coords by mass for weighted average
        df[["x_weighted", "y_weighted", "z_weighted"]] = coords * masses
        
        mol_groups = df.groupby("mol")[["mass", "q", "x_weighted", "y_weighted", "z_weighted"]].sum()
        
        com_coords = mol_groups[["x_weighted", "y_weighted", "z_weighted"]].div(mol_groups["mass"], axis=0)

        return {
            "sys_dt": sys_dt,
            "com_coords": com_coords.values,
            "charges": mol_groups["q"].values,
            "masses": mol_groups["mass"].values,
            "volume": Volume,
            "box_lengths": (Lx, Ly, Lz),
            "lower_bounds": lower_bounds_np,
        }

    def get_dt_from_trajectory(self, file_path):
                        
        """
        Function to get snapshots frequency
        
        """
        is_xyz = file_path.lower().endswith(".xyz")
        
        if not is_xyz:
            timesteps = []
            with open(file_path, "r") as f:
                for line in f:
                    if "ITEM: TIMESTEP" in line:
                        ts = int(next(f).strip())
                        timesteps.append(ts)
                        if len(timesteps) == 2:
                            break
            if len(timesteps) < 2:
                raise ValueError(f"Could not find two timesteps in '{file_path}'.")
            
            results = (timesteps[1] - timesteps[0]) / 1000
        else:
            results = (self.args.dump_frame * self.args.N / 1000)
        return results

    def extract_snapshots(self, file_path, snapshot_interval, max_snapshot, min_snapshot):
                        
        """
        Function to extract snapsots
        """
        is_xyz = file_path.lower().endswith(".xyz")
        
        with open(file_path, "r") as f:
            total_snapshot_count = -1
    
            if is_xyz:
                while True:
                    line = f.readline()
                    if not line: break 
                    
                    try:
                        n_atoms = int(line.strip())
                    except ValueError:
                        break 
                    
                    comment = f.readline().strip()
                    
                    ts_match = re.search(r"Timestep:\s*(\d+)", comment)
                    sys_dt = int(ts_match.group(1)) if ts_match else (total_snapshot_count + 1)
                    
                    atom_lines = []
                    corrupted = False
                    for _ in range(n_atoms):
                        l = f.readline()
                        if not l:
                            corrupted = True
                            break
                        atom_lines.append(l.strip())
                    
                    if corrupted:
                        self.log_message("WARNING",f"Warning: Snapshot {total_snapshot_count + 1} is incomplete. Stopping.")
                        break
    
                    total_snapshot_count += 1
                    
                    if min_snapshot <= total_snapshot_count <= max_snapshot and (
                        total_snapshot_count % snapshot_interval == 0
                        or total_snapshot_count == max_snapshot
                    ):
                        yield sys_dt, atom_lines, ["type", "x", "y", "z"], None
                    
                    if max_snapshot and total_snapshot_count >= max_snapshot:
                        break
        
            else:
                lines, column_names, n_atoms, box_bounds = [], None, None, []
                collecting_snapshot, total_snapshot_count = False, -1
                for line in f:
                    line = line.strip()
                    if "ITEM: TIMESTEP" in line:
                        sys_dt, collecting_snapshot = int(next(f).strip()), False
                    elif "ITEM: NUMBER OF ATOMS" in line:
                        n_atoms = int(next(f).strip())
                    elif "ITEM: BOX BOUNDS" in line:
                        box_bounds = [next(f).strip() for _ in range(3)]
                    elif "ITEM: ATOMS" in line:
                        column_names, lines, collecting_snapshot = (
                            line.split()[2:],
                            [],
                            True,
                        )
                        continue
                    if collecting_snapshot:
                        lines.append(line)
                        if len(lines) == n_atoms:
                            total_snapshot_count += 1
                            if min_snapshot <= total_snapshot_count <= max_snapshot and (
                                total_snapshot_count % snapshot_interval == 0
                                or total_snapshot_count == max_snapshot
                            ):
                                yield sys_dt, lines, column_names, box_bounds
                            lines, collecting_snapshot = [], False
                    if max_snapshot and total_snapshot_count >= max_snapshot:

                        break

    def build_species_map(self, unique_mols):
        """
        Build mapping: mol_id -> species name using --SPECIES input
        """
        species_input = getattr(self.args, "SPECIES", [])
        
        if not species_input:
            return {}
    
        if len(species_input) % 2 != 0:
            self.log_message("INFO","SPECIES must be provided as pairs: NAME COUNT")
            sys.exit(1)
    
        pairs = []
        for i in range(0, len(species_input), 2):
            name = species_input[i]
            count = int(species_input[i + 1])
            pairs.append((name, count))
    
        mol_ids_sorted = np.sort(unique_mols)
    
        species_map = {}
        cursor = 0
    
        for name, count in pairs:
            for mol_id in mol_ids_sorted[cursor:cursor + count]:
                species_map[int(mol_id)] = name
            cursor += count
    
        if cursor != len(mol_ids_sorted):
            self.log_message("WARNING", "SPECIES count does not match number of molecules")
    
        return species_map
    
    def build_species_map_from_reindexed(self, n_mols_total):
        """
        Build mapping: reindexed mol_id (1..N) -> species
        """
        species_input = getattr(self.args, "SPECIES", [])
        
        if not species_input:
            return {}
    
        if len(species_input) % 2 != 0:
            self.log_message("INFO","SPECIES must be provided as pairs: NAME COUNT")
            sys.exit(1)
    
        pairs = []
        for i in range(0, len(species_input), 2):
            name = species_input[i]
            count = int(species_input[i + 1])
            pairs.append((name, count))
    
        species_map = {}
        cursor = 1  # mol_id starts from 1
    
        for name, count in pairs:
            for mol_id in range(cursor, cursor + count):
                species_map[mol_id] = name
            cursor += count
    
        if cursor - 1 != n_mols_total:
            self.log_message("WARNING", "SPECIES count does not match total molecules")
    
        return species_map
    
    def process_and_save_data(self, file_path, t_steps, n_steps, snapshot_interval, return_atoms=False):
        """
        Trajectory parser for LAMMPS (.lammpstrj) and XYZ (.xyz) trajectories.
        """
        self.prepare_for_processing(file_path)

        is_xyz = file_path.lower().endswith(".xyz")
        self.log_message("INFO", f"Indexing {('XYZ' if is_xyz else 'LAMMPS')} trajectory file...")
        
        all_frames = []
        fb_box_val = getattr(self, 'box_lengths', (100.0, 100.0, 100.0))
        fb_low_val = getattr(self, 'lower_bounds', (0.0, 0.0, 0.0))
        
        box, lower = np.array(fb_box_val), np.array(fb_low_val)
        column_names = []

        with open(file_path, "rb") as f:
            curr_ts, n_atoms = 0, 0
            while True:
                line = f.readline()
                if not line: break
                ls = line.decode('ascii', errors='ignore').strip()
                if not ls: continue

                if is_xyz:
                    try:
                        n_atoms = int(ls)
                        comment = f.readline().decode('ascii', errors='ignore')
                        ts_match = re.search(r"Timestep:\s*(\d+)", comment)
                        curr_ts = int(ts_match.group(1)) if ts_match else len(all_frames)
                        start_off = f.tell()
                        for _ in range(n_atoms): f.readline()
                        all_frames.append({'start': start_off, 'end': f.tell(), 'ts': curr_ts, 'box': box.copy(), 'lower': lower.copy()})
                    except: break
                else:
                    if "ITEM: TIMESTEP" in ls: curr_ts = int(f.readline().strip())
                    elif "ITEM: NUMBER OF ATOMS" in ls: n_atoms = int(f.readline().strip())
                    elif "ITEM: BOX BOUNDS" in ls:
                        bx = [f.readline().split() for _ in range(3)]
                        lower = np.array([float(bx[0][0]), float(bx[1][0]), float(bx[2][0])])
                        upper = np.array([float(bx[0][1]), float(bx[1][1]), float(bx[2][1])])
                        box = upper - lower
                    elif "ITEM: ATOMS" in ls:
                        column_names = ls.split()[2:]
                        start_off = f.tell()
                        for _ in range(n_atoms): f.readline()
                        all_frames.append({'start': start_off, 'end': f.tell(), 'ts': curr_ts, 'box': box.copy(), 'lower': lower.copy()})

        dt_traj = (all_frames[1]['ts'] - all_frames[0]['ts']) / 1000.0 if len(all_frames) > 1 else 1.0
        dt_physical = dt_traj * t_steps
        min_time, max_time = n_steps if n_steps else (0, float("inf"))
        valid_frames = [f for i, f in enumerate(all_frames) if min_time <= i * dt_physical <= max_time and i % snapshot_interval == 0]
        num_to_process = len(valid_frames)
        if num_to_process == 0: 
            return ({}, pd.DataFrame(), pd.DataFrame(), 0) if return_atoms else (None,)*10

        orig_unique_mols = sorted(list(set(self.mol_map.values())))
        n_mols_total = len(orig_unique_mols)
        species_map = self.build_species_map_from_reindexed(n_mols_total)
        mol_reindex_map = {old: new for new, old in enumerate(orig_unique_mols)}
        atom_to_reindexed_mol = {a_id: mol_reindex_map[m_id] for a_id, m_id in self.mol_map.items()}

        sorted_atom_ids = sorted(self.mol_map.keys())
        mol_first_atom_map = {}
        for i, a_id in enumerate(sorted_atom_ids):
            m_id = atom_to_reindexed_mol[a_id]
            if m_id not in mol_first_atom_map: mol_first_atom_map[m_id] = i
        mol_start_indices = np.array([mol_first_atom_map[m] for m in range(n_mols_total)], dtype=np.int32)

        k_idx = []
        atom_metadata_list = []
        system_mass = 0.0
        
        msd_selections = getattr(self.args, 'MSD_SELECTIONS', None)
        user_resnames = getattr(self.args, 'resname', []) or []

        for i, a_id in enumerate(sorted_atom_ids):
            t_id = self.type_map.get(a_id, 1)
            a_type_str = str(t_id)
            mass = self.mass_map.get(t_id, 1.0)
            system_mass += mass
        
            reindexed_mol_id = mol_reindex_map[self.mol_map[a_id]] + 1
            resname = species_map.get(reindexed_mol_id, f"Type_{t_id}")

            keep_atom = False

            if msd_selections:
                for group in msd_selections:
                    if resname.upper() == group['resname'].upper():
                        
                        has_filters = (len(group['type']) > 0 or len(group['name']) > 0)
                        
                        if not has_filters:
                            keep_atom = True
                            break
                        
                        t_match = (a_type_str.upper() in [str(t).upper() for t in group['type']])
                        n_match = (a_type_str.upper() in [str(n).upper() for n in group['name']])
                        
                        if t_match or n_match:
                            keep_atom = True
                            break

            else:
                keep_atom = (not user_resnames) or (resname in user_resnames)

            if keep_atom:
                k_idx.append(i)
                if return_atoms:
                    atom_metadata_list.append({
                        'atom_index': a_id,
                        'mol_id': reindexed_mol_id,
                        'resname': resname,
                        'atom_name': a_type_str, 
                        'atom_type': a_type_str,
                        'charge': self.charge_map.get(a_id, 0.0),
                        'mass': float(mass)
                    })

        kept_indices = np.array(k_idx, dtype=np.int32)
        atom_metadata = pd.DataFrame(atom_metadata_list) if return_atoms else pd.DataFrame()

        data_mode = "disk" if self.args.USE_DISK else "memory"
        pos_file = "POS_data.dat"
        com_file = "COM_data.dat"
        
        if return_atoms:
            shape_data = (num_to_process, len(kept_indices), 3)
            data_storage = create_array_backend(pos_file, shape_data, np.float32, "w+", data_mode)
            charge_storage = np.zeros((num_to_process, len(kept_indices)), dtype=np.float32)
        else:
            shape_data = (num_to_process, n_mols_total, 3)
            data_storage = create_array_backend(com_file, shape_data, np.float32, "w+", data_mode)
            charge_storage = np.zeros((num_to_process, n_mols_total), dtype=np.float32)
        mmap_opts = {
            'filename': pos_file if return_atoms else com_file,
            'shape': shape_data,
            'dtype': np.float32
        }
        box_lengths = np.zeros((num_to_process, 3), dtype=np.float32)
        lower_bounds = np.zeros((num_to_process, 3), dtype=np.float32)
        results_dt = np.zeros(num_to_process)
        volumes = np.zeros(num_to_process)

        chunk_size = 200
        tasks = []
        for i in range(0, num_to_process, chunk_size):
            chunk_frames = valid_frames[i : i + chunk_size]
            frame_tasks = [(f['start'], f['end'], f['ts'], f['box'], f['lower'], i + j) for j, f in enumerate(chunk_frames)]
            tasks.append((file_path, frame_tasks, column_names, atom_to_reindexed_mol, 
                          self.type_map, self.mass_map, self.charge_map, kept_indices, 
                          n_mols_total, mol_start_indices, is_xyz, data_mode, mmap_opts))

        worker_func = partial(process_lammps_manual_worker, return_atoms=return_atoms)
        if self.n_cores > 1:
            ctx = multiprocessing.get_context(getattr(self.args, 'get_context', 'spawn'))
            with ctx.Pool(processes=self.n_cores) as pool:
                with tqdm(total=num_to_process, desc="Processing Snapshots") as pbar:
                    for chunk_results in pool.imap_unordered(worker_func, tasks):
                        for g_idx, data, q_data, box, lower, dt in chunk_results:
                            if data_mode == "memory":
                                data_storage[g_idx] = data
                            charge_storage[g_idx] = q_data
                            box_lengths[g_idx] = box
                            lower_bounds[g_idx] = lower
                            results_dt[g_idx] = dt
                            volumes[g_idx] = np.prod(box)
                        pbar.update(len(chunk_results))
        else:
            with tqdm(total=num_to_process, desc="Processing Snapshots") as pbar:
                for task in tasks:
                    for g_idx, data, q_data, box, lower, dt in worker_func(task):
                        data_storage[g_idx] = data
                        charge_storage[g_idx] = q_data
                        box_lengths[g_idx] = box
                        lower_bounds[g_idx] = lower
                        results_dt[g_idx] = dt
                        volumes[g_idx] = np.prod(box)
                        pbar.update(1)

        if data_mode == "disk":
            data_storage.flush()

        df_box = pd.DataFrame(box_lengths, columns=["Lx", "Ly", "Lz"])
        df_box.insert(0, "t", results_dt)

        if return_atoms:
            self.atom_metadata = atom_metadata
            self.charge_storage = charge_storage 
            return data_storage, df_box, atom_metadata, system_mass
        else:
            Volume = np.mean(volumes) * 1e-30 
            mol_mass_sum = np.zeros(n_mols_total)
            for a_id, old_m_id in self.mol_map.items():
                mol_mass_sum[mol_reindex_map[old_m_id]] += self.mass_map.get(self.type_map.get(a_id), 1.0)
            
            # Static charges_df (average across frames if charges were dynamic)
            avg_charges = np.mean(charge_storage, axis=0)
            charges_df, masses_df = pd.DataFrame(avg_charges, columns=["q"]), pd.DataFrame(mol_mass_sum, columns=["masses"])
            
            species_masses, idx_s, species_args = {}, 0, getattr(self.args, 'SPECIES', [])
            for i in range(0, len(species_args), 2):
                res_name, count = species_args[i], int(species_args[i + 1])
                species_masses[res_name] = round(float(mol_mass_sum[idx_s]), 4)
                idx_s += count
            
            gc.collect()
            return data_storage, box_lengths, lower_bounds, charge_storage, df_box, results_dt.tolist(), Volume, charges_df, masses_df, species_masses
        
    def process_and_save_data_mda(self, return_atoms=False):
        
        """
        Function to process LAMMPS trajectory and save species data using MDAnalysis
        """
        warnings.filterwarnings("ignore", message=".*Reader has no dt information.*", category=UserWarning)
        
        data_file = self.args.DATA
        traj_file = self.args.TRAJ
        dump_frame = self.args.dump_frame
        step = self.args.N
        
        self.load_and_parse_data_file()
        u = self.load_universe(data_file, traj_file)
        atoms = u.atoms
        n_atoms = len(atoms)
        n_total_frames = u.trajectory.n_frames
        system_mass = atoms.total_mass()
        
        raw_mol_ids = atoms.resids if hasattr(atoms, 'resids') else np.arange(n_atoms)
        unique_mols, mol_indices = np.unique(raw_mol_ids, return_inverse=True)
        species_map = self.build_species_map(unique_mols)
        _, start_indices = np.unique(raw_mol_ids, return_index=True)
        
        mol_indices = mol_indices.astype(np.int32)
        start_indices = start_indices.astype(np.int32)
        n_mols = len(unique_mols)

        # Identify msd_selections and global resname filter
        msd_selections = getattr(self.args, 'MSD_SELECTIONS', None)
        user_resnames = getattr(self.args, 'resname', []) or []

        k_idx = []
        atom_metadata_list = []

        atom_types_array = atoms.types
        atom_charges_array = atoms.charges if hasattr(atoms, 'charges') else np.zeros(n_atoms)
        atom_masses_array = atoms.masses if hasattr(atoms, 'masses') else np.zeros(n_atoms)

        for i in range(n_atoms):
            a_type = str(atom_types_array[i])
            mol_id = int(raw_mol_ids[i])
            resname = species_map.get(mol_id, f"Type_{a_type}")
            
            keep_atom = False

            if msd_selections:
                for group in msd_selections:
                    if resname.upper() == group['resname'].upper():
                        
                        has_filters = (len(group['type']) > 0 or len(group['name']) > 0)
                        
                        if not has_filters:
                            keep_atom = True
                            break
                        else:
                            t_match = (a_type.upper() in [str(t).upper() for t in group['type']])
                            n_match = (a_type.upper() in [str(n).upper() for n in group['name']])
                            if t_match or n_match:
                                keep_atom = True
                                break
            
            else:
                keep_atom = (not user_resnames) or (resname in user_resnames)

            if keep_atom:
                k_idx.append(i)
                if return_atoms:
                    atom_metadata_list.append({
                        'atom_index': i + 1,
                        'mol_id': mol_id,
                        'resname': resname,
                        'atom_name': a_type,
                        'atom_type': a_type,
                        'charge': float(atom_charges_array[i]),
                        'mass': float(atom_masses_array[i])
                    })

        kept_indices = np.array(k_idx, dtype=np.int32)
        atom_metadata = pd.DataFrame(atom_metadata_list) if return_atoms else pd.DataFrame()
        
        if getattr(self.args, 'n_steps', None):
            start_f = max(0, int((self.args.n_steps[0] / dump_frame) * 1000))
            end_f = min(n_total_frames, int((self.args.n_steps[1] / dump_frame) * 1000 + 1))
        else:
            start_f, end_f = 0, n_total_frames
    
        frame_indices = list(range(start_f, end_f, step))
        num_to_process = len(frame_indices)
        
        if num_to_process == 0: 
             return ({}, pd.DataFrame(), pd.DataFrame(), 0) if return_atoms else (None,)*10

        data_mode = "disk" if self.args.USE_DISK else "memory"
        pos_file = "POS_data.dat"
        com_file = "COM_data.dat"
        
        if return_atoms:
            shape = (num_to_process, len(kept_indices), 3)
            if data_mode == "disk":
                data_storage = create_array_backend(pos_file, shape, np.float32, "w+", "disk")
                shared_buffer = None
            else:
                size = int(np.prod(shape))
                shared_buffer = multiprocessing.RawArray(ctypes.c_float, size)
                data_storage = np.frombuffer(shared_buffer, dtype=np.float32).reshape(shape)
        else:
            shape = (num_to_process, n_mols, 3)
            if data_mode == "disk":
                data_storage = create_array_backend(com_file, shape, np.float32, "w+", "disk")
                shared_buffer = None
            else:
                size = int(np.prod(shape))
                shared_buffer = multiprocessing.RawArray(ctypes.c_float, size)
                data_storage = np.frombuffer(shared_buffer, dtype=np.float32).reshape(shape)
        
        mmap_opts = {'filename': pos_file if return_atoms else com_file, 'shape': shape, 'dtype': np.float32}
        
        box_lengths = np.zeros((num_to_process, 3), dtype=np.float32)
        lower_bounds = np.zeros((num_to_process, 3), dtype=np.float32)
        results_dt = [0] * num_to_process
        volumes = np.zeros(num_to_process)

        chunk_size = max(1, num_to_process // max(1, 4 * self.n_cores))
        maxtasksperchild = None

        if self.n_cores > 1:
            chunks = [
                (50000, 100000, 100),
                (20000,  50000,  200),
                (10000,  20000,  500),
                (2000,   20000, 1000),
            ]
        
            chunk_size = None
            for min_mol, min_atom, size in chunks:
                if n_mols > min_mol or n_atoms > min_atom:
                    chunk_size = size
                    break
        
            # Default for small systems
            if chunk_size is None:
                chunk_size = max(1, num_to_process // max(1, 8 * self.n_cores))
                
            maxtasks = [
                (20000, 50000, 1),
                (10000, 30000, 5),
                (5000,  20000, 10),
                (2000,  20000, 20),
            ]
            for min_mol, min_atom, tasks in maxtasks:
                if n_mols > min_mol or n_atoms > min_atom:
                    maxtasksperchild = tasks
                    break

        fb_box = getattr(self, 'box_lengths', (100.0, 100.0, 100.0))
        fb_low = getattr(self, 'lower_bounds', np.zeros(3))
        atom_masses = atoms.masses[:, np.newaxis]
        
        # Prepare COM mass divisor
        mol_mass_sum = np.zeros(n_mols)
        np.add.at(mol_mass_sum, mol_indices, atoms.masses)
        mol_mass_divisor = mol_mass_sum[:, np.newaxis]
        mol_mass_divisor[mol_mass_divisor == 0] = 1.0
        
        tasks = []
        for i in range(0, num_to_process, chunk_size):
            f_chunk = frame_indices[i : i + chunk_size]
            g_chunk = list(range(i, min(i + chunk_size, num_to_process)))
            tasks.append((
                data_file, traj_file, f_chunk, g_chunk,
                mol_indices, start_indices, atom_masses, mol_mass_divisor, 
                dump_frame, fb_box, fb_low, kept_indices, data_mode, mmap_opts
            ))

        worker_func = partial(process_mdanalysis, return_atoms=return_atoms)
        if self.n_cores > 1:
            ctx = multiprocessing.get_context(getattr(self.args, 'get_context', 'spawn'))
            with ctx.Pool(processes=self.n_cores, initializer=init_worker, initargs=(shared_buffer, shape), maxtasksperchild=maxtasksperchild) as pool:
                with tqdm(total=num_to_process, desc="Processing Snapshots") as pbar:
                    for metadata_chunk in pool.imap_unordered(worker_func, tasks):
                        if metadata_chunk is None: continue
                        for row in metadata_chunk:
                            g_idx = int(row[0])
                            results_dt[g_idx] = row[1]
                            box_lengths[g_idx] = row[2:5]
                            lower_bounds[g_idx] = row[5:8]
                            volumes[g_idx] = np.prod(row[2:5])
                        pbar.update(len(metadata_chunk))
        else:
            init_worker(shared_buffer, shape)
            with tqdm(total=num_to_process, desc="Processing Snapshots") as pbar:
                for task in tasks:
                    metadata_chunk = worker_func(task)
                    if metadata_chunk is not None:
                        for row in metadata_chunk:
                            g_idx = int(row[0])
                            results_dt[g_idx] = row[1]
                            box_lengths[g_idx] = row[2:5]
                            lower_bounds[g_idx] = row[5:8]
                            volumes[g_idx] = np.prod(row[2:5])
                        pbar.update(len(metadata_chunk))

        if data_mode == "disk":
            data_storage.flush()

        df_box = pd.DataFrame(box_lengths, columns=["Lx", "Ly", "Lz"])
        df_box.insert(0, "t", results_dt)

        if return_atoms:
            self.atom_metadata = atom_metadata
            return data_storage, df_box, atom_metadata, system_mass
        else:
            Volume = np.mean(volumes) * 1e-30 
            mol_charge_sum = np.zeros(n_mols)
            np.add.at(mol_charge_sum, mol_indices, atom_charges_array)
            
            charges_df = pd.DataFrame(mol_charge_sum, columns=["q"])
            masses_df = pd.DataFrame(mol_mass_sum, columns=["masses"])
            charges_reshaped = mol_charge_sum.reshape(-1, 1)
            
            species_masses = {}
            species_counts = {}
            idx_s, species_args = 0, getattr(self.args, 'SPECIES', [])
            for i in range(0, len(species_args), 2):
                res_name, count = species_args[i], int(species_args[i + 1])
                species_counts[res_name] = count
                species_masses[res_name] = round(float(mol_mass_sum[idx_s]), 4)
                idx_s += count

            del u
            gc.collect()
            for f in glob.glob(".*.npz") + glob.glob(".*.lock"):
                try: os.remove(f)
                except OSError: pass

            return data_storage, box_lengths, lower_bounds, charges_reshaped, df_box, results_dt, Volume, charges_df, masses_df, species_masses

    def process_and_save_data_chemfile(self, return_atoms=False):
        
        """
        Function to process Trajectory using Chemfiles.
        """
        if self.args.CHEM:
            try:
                import chemfiles
            except ImportError:
                self.log_message("ERROR","Error: Chemfiles is required for this feature (--chem) but is not installed.")
                self.log_message("INFO","Please install it to proceed.")
                self.log_message("INFO","\nTo install using pip:")
                self.log_message("INFO","  pip install chemfiles")
                self.log_message("INFO","\nTo install using conda:")
                self.log_message("INFO","  conda install -c conda-forge chemfiles")
                self.log_message("INFO","-------------------------------------")
                sys.exit(1)
                
        self.load_and_parse_data_file()
        traj_file = self.args.TRAJ
        
        with chemfiles.Trajectory(traj_file, mode='r') as tmp_traj:
            n_total_frames = tmp_traj.nsteps
            first_frame = tmp_traj.read_step(0)
            n_atoms = len(first_frame.atoms)

        global_mol_ids = np.zeros(n_atoms, dtype=np.int32)
        global_masses = np.ones(n_atoms, dtype=np.float32)
        global_charges = np.zeros(n_atoms, dtype=np.float32)
        system_mass = 0.0
        
        for i in range(n_atoms):
            a_id = i + 1 
            global_mol_ids[i] = self.mol_map.get(a_id, i + 1)
            global_charges[i] = self.charge_map.get(a_id, 0.0)
            t_id = self.type_map.get(a_id)
            m = self.mass_map.get(t_id, 1.0) if t_id else 1.0
            global_masses[i] = m
            system_mass += m

        msd_selections = getattr(self.args, 'MSD_SELECTIONS', None)
        user_resnames = getattr(self.args, 'resname', []) or []

        k_idx = []
        atom_metadata_list = []

        unique_mols = np.unique(global_mol_ids)
        species_map = self.build_species_map(unique_mols)
        
        for i in range(n_atoms):
            a_id = i + 1
            t_id = self.type_map.get(a_id, 1)
            a_type_str = str(t_id)
            mol_id = int(global_mol_ids[i])
            resname = species_map.get(mol_id, f"Type_{a_type_str}")

            keep_atom = False

            if msd_selections:
                for group in msd_selections:
                    if resname.upper() == group['resname'].upper():
                        
                        has_filters = (len(group['type']) > 0 or len(group['name']) > 0)
                        
                        if not has_filters:
                            keep_atom = True
                            break
                        else:
                            target_filters = [str(t).upper() for t in (group['type'] + group['name'])]
                            if a_type_str.upper() in target_filters:
                                keep_atom = True
                                break
            
            else:
                keep_atom = (not user_resnames) or (resname in user_resnames)

            if keep_atom:
                k_idx.append(i)
                if return_atoms:
                    atom_metadata_list.append({
                        'atom_index': a_id,
                        'mol_id': mol_id,
                        'resname': resname,
                        'atom_name': a_type_str, 
                        'atom_type': a_type_str,
                        'charge': float(global_charges[i]),
                        'mass': float(global_masses[i])
                    })

        kept_indices = np.array(k_idx, dtype=np.int32)
        atom_metadata = pd.DataFrame(atom_metadata_list) if return_atoms else pd.DataFrame()

        dump_frame = getattr(self.args, 'dump_frame', 1)
        step = getattr(self.args, 'N', 1)
    
        if getattr(self.args, 'n_steps', None):
            start_f = max(0, int((self.args.n_steps[0] / dump_frame) * 1000))
            end_f = min(n_total_frames, int((self.args.n_steps[1] / dump_frame) * 1000 + 1))
        else:
            start_f, end_f = 0, n_total_frames
    
        frame_indices = list(range(start_f, end_f, step))
        num_to_process = len(frame_indices)
        if num_to_process == 0: 
            return ({}, pd.DataFrame(), pd.DataFrame(), 0) if return_atoms else (None,)*10

        unique_mols, mol_indices = np.unique(global_mol_ids, return_inverse=True)
        _, start_indices = np.unique(global_mol_ids, return_index=True)
        n_mols = len(unique_mols)
        
        data_mode = "disk" if self.args.USE_DISK else "memory"
        pos_file = "POS_data.dat"
        com_file = "COM_data.dat"
        
        if return_atoms:
            shape = (num_to_process, len(kept_indices), 3)
            if data_mode == "disk":
                data_storage = create_array_backend(pos_file, shape, np.float32, "w+", "disk")
                shared_buffer = None
            else:
                size = int(np.prod(shape))
                shared_buffer = multiprocessing.RawArray(ctypes.c_float, size)
                data_storage = np.frombuffer(shared_buffer, dtype=np.float32).reshape(shape)
        else:
            shape = (num_to_process, n_mols, 3)
            if data_mode == "disk":
                data_storage = create_array_backend(com_file, shape, np.float32, "w+", "disk")
                shared_buffer = None
            else:
                size = int(np.prod(shape))
                shared_buffer = multiprocessing.RawArray(ctypes.c_float, size)
                data_storage = np.frombuffer(shared_buffer, dtype=np.float32).reshape(shape)
                
        box_lengths = np.zeros((num_to_process, 3), dtype=np.float32)
        lower_bounds = np.zeros((num_to_process, 3), dtype=np.float32)
        results_dt = [0.0] * num_to_process
        volumes = np.zeros(num_to_process)

        chunk_size = max(1, num_to_process // max(1, 4 * self.n_cores))
        maxtasksperchild = None

        if self.n_cores > 1:
            chunks = [
                (50000, 100000, 100),
                (20000,  50000,  200),
                (10000,  20000,  500),
                (2000,   20000, 1000),
            ]
        
            chunk_size = None
            for min_mol, min_atom, size in chunks:
                if n_mols > min_mol or n_atoms > min_atom:
                    chunk_size = size
                    break
        
            # Default for small systems
            if chunk_size is None:
                chunk_size = max(1, num_to_process // max(1, 4 * self.n_cores))
                
            maxtasks = [
                (20000, 50000, 1),
                (10000, 30000, 5),
                (5000,  20000, 10),
                (2000,  20000, 20),
            ]
        
            for min_mol, min_atom, tasks in maxtasks:
                if n_mols > min_mol or n_atoms > min_atom:
                    maxtasksperchild = tasks
                    break

        fb_box = getattr(self, 'box_lengths', (100.0, 100.0, 100.0))
        fb_low = getattr(self, 'lower_bounds', np.zeros(3))
        
        # Prepare COM mass arrays
        mol_mass_sum = np.zeros(n_mols)
        np.add.at(mol_mass_sum, mol_indices, global_masses)
        mol_mass_divisor = mol_mass_sum[:, np.newaxis]
        mol_mass_divisor[mol_mass_divisor == 0] = 1.0
        masses_expanded = global_masses[:, np.newaxis]
        mmap_opts = {'filename': pos_file if return_atoms else com_file, 'shape': shape, 'dtype': np.float32}
        tasks = []
        for i in range(0, num_to_process, chunk_size):
            f_chunk = frame_indices[i : i + chunk_size]
            g_chunk = list(range(i, min(i + chunk_size, num_to_process)))
            tasks.append((
                traj_file, f_chunk, g_chunk, mol_indices, 
                start_indices, masses_expanded, mol_mass_divisor, dump_frame,
                fb_box, fb_low, kept_indices, data_mode, mmap_opts
            ))

        worker_func = partial(process_chemfiles, return_atoms=return_atoms)
        
        if self.n_cores > 1:
            ctx = multiprocessing.get_context(getattr(self.args, 'get_context', 'spawn'))
            with ctx.Pool(processes=self.n_cores, initializer=init_worker, initargs=(shared_buffer, shape),maxtasksperchild=maxtasksperchild) as pool:
                with tqdm(total=num_to_process, desc="Processing Snapshots") as pbar:
                    for metadata_chunk in pool.imap_unordered(worker_func, tasks):
                        if metadata_chunk is None: continue
                        for row in metadata_chunk:
                            g_idx = int(row[0])
                            results_dt[g_idx] = row[1]
                            box_lengths[g_idx] = row[2:5]
                            lower_bounds[g_idx] = row[5:8]
                            volumes[g_idx] = np.prod(row[2:5])
                        pbar.update(len(metadata_chunk))
        else:
            init_worker(shared_buffer, shape)
            with tqdm(total=num_to_process, desc="Processing Snapshots") as pbar:
                for task in tasks:
                    metadata_chunk = worker_func(task)
                    if metadata_chunk is not None:
                        for row in metadata_chunk:
                            g_idx = int(row[0])
                            results_dt[g_idx] = row[1]
                            box_lengths[g_idx] = row[2:5]
                            lower_bounds[g_idx] = row[5:8]
                            volumes[g_idx] = np.prod(row[2:5])
                    pbar.update(len(metadata_chunk))

        if data_mode == "disk":
            data_storage.flush()
    
        df_box = pd.DataFrame(box_lengths, columns=["Lx", "Ly", "Lz"])
        df_box.insert(0, "t", results_dt)
        
        if return_atoms:
            self.atom_metadata = atom_metadata
            return data_storage, df_box, atom_metadata, system_mass
        else:
            Volume = np.mean(volumes) * 1e-30 
            mol_charge_sum = np.zeros(n_mols)
            np.add.at(mol_charge_sum, mol_indices, global_charges)
            
            charges_df = pd.DataFrame(mol_charge_sum, columns=["q"])
            masses_df = pd.DataFrame(mol_mass_sum, columns=["masses"])
            charges_reshaped = mol_charge_sum.reshape(-1, 1)
            
            species_masses = {}
            species_counts = {}
            idx_s, species_args = 0, getattr(self.args, 'SPECIES', [])
            for i in range(0, len(species_args), 2):
                res_name, count = species_args[i], int(species_args[i + 1])
                species_counts[res_name] = count
                species_masses[res_name] = round(float(mol_mass_sum[idx_s]), 4)
                idx_s += count

            gc.collect()

            return data_storage, box_lengths, lower_bounds, charges_reshaped, df_box, results_dt, Volume, charges_df, masses_df, species_masses

    def process_and_save_data_ovito(self, return_atoms=False):
        
        """
        Function to process Trajectory using OVITO.
        """
        if self.args.OVITO:
            try:
                warnings.filterwarnings('ignore', message='.*OVITO.*PyPI')
                from ovito.io import import_file
            except ImportError:
                self.log_message("ERROR","Error: OVITO is required for this feature (--ovito) but is not installed.")
                self.log_message("INFO","Please install it to proceed.")
                self.log_message("INFO","\nTo install using pip:")
                self.log_message("INFO","  pip install ovito")
                self.log_message("INFO","\nTo install using conda:")
                self.log_message("INFO","  conda install --strict-channel-priority -c https://conda.ovito.org -c conda-forge ovito=3.14.1")
                self.log_message("INFO","-------------------------------------")
                sys.exit(1)

        self.load_and_parse_data_file()

        traj_file = self.args.TRAJ
        pipeline = import_file(traj_file)
        n_total_frames = pipeline.source.num_frames
        
        # Initial frame to check system size and IDs
        first_data = pipeline.compute(0)
        n_atoms = first_data.particles.count
        has_ids = 'Particle Identifier' in first_data.particles

        global_mol_ids = np.zeros(n_atoms, dtype=int)
        global_masses = np.ones(n_atoms, dtype=float)
        global_charges = np.zeros(n_atoms, dtype=float)
        system_mass = 0.0
        
        # Map indices to topology values
        for i in range(n_atoms):
            a_id = i + 1 # 1-based LAMMPS ID
            global_mol_ids[i] = self.mol_map.get(a_id, i + 1)
            global_charges[i] = self.charge_map.get(a_id, 0.0)
            t_id = self.type_map.get(a_id)
            m = self.mass_map.get(t_id, 1.0) if t_id else 1.0
            global_masses[i] = m
            system_mass += m

        # Identify msd_selections and global resname filter
        msd_selections = getattr(self.args, 'MSD_SELECTIONS', None)
        user_resnames = getattr(self.args, 'resname', []) or []

        k_idx = []
        atom_metadata_list = []

        unique_mols = np.unique(global_mol_ids)
        species_map = self.build_species_map(unique_mols)
        
        for i in range(n_atoms):
            a_id = i + 1
            t_id = self.type_map.get(a_id, 1)
            a_type_str = str(t_id)
            mol_id = int(global_mol_ids[i])
            resname = species_map.get(mol_id, f"Type_{a_type_str}")

            keep_atom = False
            if msd_selections:
                for group in msd_selections:
                    if resname.upper() == group['resname'].upper():
                        if not group['type'] and not group['name']:
                            keep_atom = True
                            break
                        target_filters = [str(t).upper() for t in (group['type'] + group['name'])]
                        if a_type_str.upper() in target_filters:
                            keep_atom = True
                            break
            
            else:
                keep_atom = (not user_resnames) or (resname in user_resnames)

            if keep_atom:
                k_idx.append(i)
                if return_atoms:
                    atom_metadata_list.append({
                        'atom_index': a_id,
                        'mol_id': mol_id,
                        'resname': resname,
                        'atom_name': a_type_str, 
                        'atom_type': a_type_str,
                        'charge': float(global_charges[i]),
                        'mass': float(global_masses[i])
                    })

        kept_indices = np.array(k_idx, dtype=np.int32)
        atom_metadata = pd.DataFrame(atom_metadata_list) if return_atoms else pd.DataFrame()

        dump_frame = getattr(self.args, 'dump_frame', 1)
        step = getattr(self.args, 'N', 1)

        if getattr(self.args, 'n_steps', None):
             start_frame = int((self.args.n_steps[0] / dump_frame) * 1000)
             end_f = int((self.args.n_steps[1] / dump_frame) * 1000 + 1)
             start_f = max(0, start_frame)
             end_f = min(n_total_frames, end_f)
        else:
             start_f, end_f = 0, n_total_frames
        
        frame_indices = list(range(start_f, end_f, step))
        num_to_process = len(frame_indices)
        if num_to_process == 0: 
            return ({}, pd.DataFrame(), pd.DataFrame(), 0) if return_atoms else (None,)*10

        unique_mols, mol_indices = np.unique(global_mol_ids, return_inverse=True)
        _, start_indices = np.unique(global_mol_ids, return_index=True)
        n_mols = len(unique_mols)
        
        data_mode = "disk" if self.args.USE_DISK else "memory"
        pos_file = "POS_data.dat"
        com_file = "COM_data.dat"
        
        if return_atoms:
            shape = (num_to_process, len(kept_indices), 3)
            if data_mode == "disk":
                data_storage = create_array_backend(pos_file, shape, np.float32, "w+", "disk")
                shared_buffer = None
            else:
                size = int(np.prod(shape))
                shared_buffer = multiprocessing.RawArray(ctypes.c_float, size)
                data_storage = np.frombuffer(shared_buffer, dtype=np.float32).reshape(shape)
        else:
            shape = (num_to_process, n_mols, 3)
            if data_mode == "disk":
                data_storage = create_array_backend(com_file, shape, np.float32, "w+", "disk")
                shared_buffer = None
            else:
                size = int(np.prod(shape))
                shared_buffer = multiprocessing.RawArray(ctypes.c_float, size)
                data_storage = np.frombuffer(shared_buffer, dtype=np.float32).reshape(shape)

        mmap_opts = {'filename': pos_file if return_atoms else com_file, 'shape': shape, 'dtype': np.float32}        

        results_box = np.zeros((num_to_process, 3), dtype=np.float32)
        results_lower = np.zeros((num_to_process, 3), dtype=np.float32)
        results_dt = np.zeros(num_to_process)
        results_vol = np.zeros(num_to_process)

        mol_mass_sum = np.zeros(n_mols)
        np.add.at(mol_mass_sum, mol_indices, global_masses)
        mol_mass_divisor = mol_mass_sum[:, np.newaxis]
        mol_mass_divisor[mol_mass_divisor == 0] = 1.0
        masses_expanded = global_masses[:, np.newaxis]
        atom_count = len(mol_indices)
        if traj_file.lower().endswith(".pdb") or traj_file.lower().endswith(".gro"):
            chunk_size = num_to_process // max(1, self.n_cores -1)
        else:
            chunks = [
                (50000, 100000, 100),
                (20000,  50000,  200),
                (10000,  20000,  500),
                (2000,   20000, 1000),
            ]
        
            chunk_size = None
            for min_mol, min_atom, size in chunks:
                if n_mols > min_mol or atom_count > min_atom:
                    chunk_size = size
                    break
        
            # Default for small systems
            if chunk_size is None:
                chunk_size = max(1, num_to_process // max(1, self.n_cores -1))
                
        fb_box = getattr(self, 'box_lengths', [100.0, 100.0, 100.0])
        fb_low = getattr(self, 'lower_bounds', [0.0, 0.0, 0.0])

        tasks = []
        for i in range(0, num_to_process, chunk_size):
            c_indices = frame_indices[i : i + chunk_size]
            g_indices = list(range(i, min(i + chunk_size, num_to_process)))
            tasks.append((
                traj_file, c_indices, g_indices, has_ids, 
                mol_indices, start_indices, masses_expanded, mol_mass_divisor, 
                dump_frame, fb_box, fb_low, kept_indices, 
                data_mode, mmap_opts
            ))

        worker_func = partial(process_ovito_frame_worker, return_atoms=return_atoms)
        
        if self.n_cores > 1:
            ctx = multiprocessing.get_context(getattr(self.args, 'get_context', 'spawn'))
            with ctx.Pool(processes=self.n_cores, initializer=init_worker, initargs=(shared_buffer, shape), maxtasksperchild=10) as pool:
                with tqdm(total=num_to_process, desc="Processing Snapshots") as pbar:
                    for metadata_chunk in pool.imap_unordered(worker_func, tasks):
                        if metadata_chunk is None: continue
                        for row in metadata_chunk:
                            g_idx = int(row[0])
                            results_dt[g_idx] = row[1]
                            results_box[g_idx] = row[2:5]
                            results_lower[g_idx] = row[5:8]
                            results_vol[g_idx] = np.prod(row[2:5])
                        pbar.update(len(metadata_chunk))
        else:
            init_worker(shared_buffer, shape)
            with tqdm(total=num_to_process, desc="Processing Snapshots") as pbar:
                for task in tasks:
                    metadata_chunk = worker_func(task)
                    for row in metadata_chunk:
                        g_idx = int(row[0])
                        results_dt[g_idx] = row[1]
                        results_box[g_idx] = row[2:5]
                        results_lower[g_idx] = row[5:8]
                        results_vol[g_idx] = np.prod(row[2:5])
                    pbar.update(len(metadata_chunk))

        if data_mode == "disk":
            data_storage.flush()

        df_box = pd.DataFrame(results_box, columns=["Lx", "Ly", "Lz"])
        df_box.insert(0, "t", results_dt)
        
        if return_atoms:
            self.atom_metadata = atom_metadata
            return data_storage, df_box, atom_metadata, system_mass
        else:
            Volume = np.mean(results_vol) * 1e-30 
            mol_charge_sum = np.zeros(n_mols)
            np.add.at(mol_charge_sum, mol_indices, global_charges)
            
            charges_df = pd.DataFrame(mol_charge_sum, columns=["q"])
            masses_df = pd.DataFrame(mol_mass_sum, columns=["masses"])
            charges_reshaped = mol_charge_sum.reshape(-1, 1)
            
            species_masses = {}
            species_counts = {}
            idx_s, species_args = 0, getattr(self.args, 'SPECIES', [])
            for j in range(0, len(species_args), 2):
                res_name, count = species_args[j], int(species_args[j+1])
                species_counts[res_name] = count
                species_masses[res_name] = round(float(mol_mass_sum[idx_s]), 4)
                idx_s += count

            del pipeline
            gc.collect()

            return data_storage, np.array(results_box), np.array(results_lower), charges_reshaped, df_box, results_dt, Volume, charges_df, masses_df, species_masses