#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Wed Nov 19 15:21:36 2025

@author: Shah Research Group, Oklahoma State University <jindal.shah@okstate.edu>

MDTransport: GROMACS & LAMMPS Transport Analysis Tools
Copyright (C) 2026  Ashutosh Kumar Verma, Amey Thorat and Jindal Shah

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
"""

import os
import sys
import numpy as np
import pandas as pd
from .util import BaseAnalysis, tqdm

class UTIL_LAMMPS_COM(BaseAnalysis):
        
    """
    This is a UTIL_LAMMPS_COM class which extract COM data for LAMMPS analysis.
    It uses the LAMMPS data file for initial box dimensions and charges,
    and the com file for the center-of-mass trajectory.
    """
    def __init__(self, args):
        
        """
        Initialize class with input arguments and class objects
        """
        super().__init__(args)

    def extract_info_from_datafile(self):
        
        """
        Parses the LAMMPS data file to extract initial box dimensions and atomic charges.
        """
        data_filepath = self.args.DATA
        if not os.path.exists(data_filepath):
            self.log_message("ERROR", f"LAMMPS data file not found: '{data_filepath}'")
            sys.exit(1)
        mass_by_type = {}
        box_bounds = {}
        atoms_data = []
        current_section = None
        
        # Check against this list to know when a previous section has ended.
        LAMMPS_SECTIONS = [
            "Masses", "Atoms", "Velocities", "Ellipsoids", "Lines", "Triangles", "Bodies",
            "Bonds", "Angles", "Dihedrals", "Impropers",
            "Pair Coeffs", "PairIJ Coeffs",
            "Bond Coeffs", "Angle Coeffs", "Dihedral Coeffs", "Improper Coeffs",
            "BondBond Coeffs", "BondAngle Coeffs",
            "MiddleBondTorsion Coeffs", "EndBondTorsion Coeffs",
            "AngleTorsion Coeffs", "AngleAngleTorsion Coeffs",
            "BondBond13 Coeffs", "AngleAngle Coeffs",
            "Atom Type Labels", "Bond Type Labels",
            "Angle Type Labels", "Dihedral Type Labels",
            "Improper Type Labels",
        ]

        self.log_message("DEBUG", f"Reading topology from: {data_filepath}")

        with open(data_filepath, "r") as f:
            for line in f:
                # Clean comments and whitespace
                line = line.partition('#')[0].strip()
                if not line:
                    continue

                # BOX DIMENSIONS
                if 'xlo xhi' in line:
                    box_bounds['x'] = list(map(float, line.split()[:2]))
                    continue
                if 'ylo yhi' in line:
                    box_bounds['y'] = list(map(float, line.split()[:2]))
                    continue
                if 'zlo zhi' in line:
                    box_bounds['z'] = list(map(float, line.split()[:2]))
                    continue

                # If the line matches ANY standard header, update section
                found_new_section = False
                for header in LAMMPS_SECTIONS:
                    if line.startswith(header):
                        current_section = header
                        found_new_section = True
                        break
                
                if found_new_section:
                    continue

                # PARSE MASSES
                if current_section == "Masses":
                    parts = line.split()
                    if len(parts) >= 2 and parts[0].isdigit():
                        atom_type = int(parts[0])
                        mass_val = float(parts[1])
                        mass_by_type[atom_type] = mass_val

                # PARSE ATOMS
                if current_section == "Atoms":
                    parts = line.split()
                    
                    # Ensure it's a data line (starts with integer ID)
                    if not parts[0].isdigit(): 
                        continue

                    num_cols = len(parts)
                    
                    # Defaults
                    a_id = int(parts[0])
                    m_id = a_id # Default: each atom is its own molecule
                    q_val = 0.0
                    a_type = None

                    # atom_style full (ID Mol Type q x y z)
                    if num_cols >= 7:
                        m_id = int(parts[1])
                        a_type = int(parts[2])
                        q_val = float(parts[3])

                    # atom_style atomic (ID Type x y z)
                    elif num_cols == 5:
                        a_type = int(parts[1])

                    # molecular (ID Mol Type x y z) vs charge (ID Type q x y z)
                    elif num_cols == 6:
                        a_type = int(parts[1])
                        # Charges can be negative, 0.0, or floats.
                        col_2_str = parts[2]
                        
                        try:
                            val_col_2 = float(col_2_str)
                            # If it has a decimal point OR is negative, likely a charge
                            if "." in col_2_str or val_col_2 < 0:
                                # Style: Charge
                                q_val = val_col_2
                            else:
                                # Style: Molecular (Col 2 is Type, Col 1 is Mol)
                                m_id = int(parts[1])
                        except ValueError:
                             pass

                    atoms_data.append({'mol': m_id, 'q': q_val, 'type': a_type})

        # VALIDATION
        if len(box_bounds) != 3:
            self.log_message("ERROR", "Failed to find all box dimensions (xlo/xhi, ylo/yhi, zlo/zhi).")
            sys.exit(1)

        if not atoms_data:
            self.log_message("ERROR", "No Atoms found in data file. Check section headers.")
            sys.exit(1)
        
        # Box Volume Calculation
        lx_lo, lx_hi = box_bounds['x']
        ly_lo, ly_hi = box_bounds['y']
        lz_lo, lz_hi = box_bounds['z']
        
        Lx, Ly, Lz = lx_hi - lx_lo, ly_hi - ly_lo, lz_hi - lz_lo
        Volume = Lx * Ly * Lz * 1e-30  # m^3

        # Molecular Charges Aggregation
        df_atoms = pd.DataFrame(atoms_data)
        
        # Calculate net charge per molecule
        net_charges_per_mol = df_atoms.groupby("mol")["q"].sum()
        
        # Sort by molecule ID
        net_charges_per_mol = net_charges_per_mol.sort_index()

        # Prepare Return Objects
        charges_df = pd.DataFrame(net_charges_per_mol.values, columns=["q"])
        
        # Map atom types → masses
        df_atoms["mass"] = df_atoms["type"].map(mass_by_type).fillna(0.0)

        # Sum mass per molecule
        mass_per_mol = df_atoms.groupby("mol")["mass"].sum().sort_index()

        masses_df = pd.DataFrame(mass_per_mol.values, columns=["masses"])

        box_info = {
            "lx": lx_lo, "ux": lx_hi, "Lx": Lx,
            "ly": ly_lo, "uy": ly_hi, "Ly": Ly,
            "lz": lz_lo, "uz": lz_hi, "Lz": Lz,
        }
        initial_box_df = pd.DataFrame([box_info])

        self.log_message("DEBUG", f"Datafile parsed: {len(charges_df)} molecules detected. Box Volume: {Volume:.2e} m^3")

        return charges_df, initial_box_df, Volume, masses_df

    def process_snapshots(self, file_path, n_steps):

        return self.extract_info_from_datafile()

    def extract_com_snapshots_generator(self, file_path, snapshots_interval, max_snapshot, min_snapshot):
        
        """
        Function to extract COM data from LAMMPS com.txt file
        """
        with open(file_path, "r") as f:
            lines_iterator = iter(f)
            try:
                for _ in range(3):
                    next(lines_iterator)
            except StopIteration:
                return
            snapshot_counter, n_mol = -1, None
            while True:
                try:
                    header_line = ""
                    while not header_line:
                        header_line = next(lines_iterator).strip()
                    snapshot_counter += 1
                    header_parts = header_line.split()
                    timestep = float(header_parts[0])
                    if n_mol is None:
                        n_mol = int(header_parts[1])
                    data_lines = [next(lines_iterator) for _ in range(n_mol)]
                    if snapshot_counter > max_snapshot:
                        break
                    if (
                        min_snapshot <= snapshot_counter
                        and snapshot_counter % snapshots_interval == 0
                    ):
                        yield timestep, data_lines
                except StopIteration:
                    break

    def get_dt_from_trajectory(self, file_path):
        
        """
        Function to get snapshot frequency from LAMMPS com.txt file
        """
        timesteps = []
        with open(file_path, "r") as f:
            lines_iterator = iter(f)
            try:
                for _ in range(3):
                    next(lines_iterator)

                # Read snapshot 1
                header1 = next(lines_iterator).strip()
                ts1 = float(header1.split()[0])
                n_mol1 = int(header1.split()[1])
                for _ in range(n_mol1):
                    next(lines_iterator)  # Skip data lines
                timesteps.append(ts1)

                # Read snapshot 2
                header2 = next(lines_iterator).strip()
                ts2 = float(header2.split()[0])
                timesteps.append(ts2)

            except StopIteration:
                raise ValueError(
                    f"Could not find two snapshots in '{file_path}' to determine dt."
                )
        dt_ps = (timesteps[1] - timesteps[0]) / 1000.0
        return dt_ps
    
    def process_lammps_trajectory_to_dataframes(self, file_path, t_steps, n_steps, snapshots_interval):
        
        """
        Processes a LAMMPS trajectory and returns species data as in-memory pandas DataFrames.
        """
        charges_df, initial_box_df, Volume, masses_df = self.extract_info_from_datafile()
    
        try:
            dt_per_frame_lammps = self.get_dt_from_trajectory(file_path)
        except ValueError as e:
            self.log_message("ERROR", str(e))
            return None, None, None, None, None, None 
    
        dt_physical = dt_per_frame_lammps * t_steps
        min_time, max_time = n_steps if n_steps else (0, float("inf"))
        min_snapshot = int(min_time / dt_physical)
        max_snapshot = int(max_time / dt_physical) if max_time != float("inf") else float("inf")
    
        com_generator = self.extract_com_snapshots_generator(
            file_path, snapshots_interval, max_snapshot, min_snapshot
        )
        data_raw_snapshots, total_dt_steps = [], []
        for timestep, data_lines in tqdm(com_generator, desc="Reading COM file"):
            total_dt_steps.append(timestep)
            snapshot_data = np.loadtxt(data_lines, usecols=(1, 2, 3))
            data_raw_snapshots.append(snapshot_data)
            
        if not data_raw_snapshots:
            self.log_message("WARNING", "No COM snapshots were processed.")
            return None, None, None, None, None, None
    
        com_snapshots = np.array(data_raw_snapshots)
        num_snapshots, num_molecules, _ = com_snapshots.shape
    

        if len(initial_box_df) == num_snapshots:
            box_df = initial_box_df
        else: 
            first_row = initial_box_df.iloc[[0]] # Use [[0]] to keep it a DataFrame
            box_df = pd.concat([first_row] * num_snapshots, ignore_index=True)
        
        assert len(box_df) == num_snapshots, "Box DataFrame length mismatch after expansion."
        
        box_lengths = box_df[["Lx", "Ly", "Lz"]].values
        lower_bounds = box_df[["lx", "ly", "lz"]].values
        
        charges_reshaped = charges_df.values.reshape(-1, 1)
        mass_array = masses_df["masses"].values
        species_masses = {}
        species_counts = {}
        idx = 0
        species_args = self.args.SPECIES
        for i in range(0, len(species_args), 2):
            res_name = species_args[i]
            count = int(species_args[i + 1])
            species_counts[res_name] = count
            species_masses[res_name] = round(float(mass_array[idx]), 4)
            idx += count

        return com_snapshots, box_lengths, lower_bounds, charges_reshaped, box_df, dt_per_frame_lammps, Volume, charges_df, species_masses