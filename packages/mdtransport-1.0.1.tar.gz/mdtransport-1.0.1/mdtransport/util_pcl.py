#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Wed Nov 19 15:21:36 2025

@author: Shah Research Group, Oklahoma State University <jindal.shah@okstate.edu>

MDTransport: GROMACS & LAMMPS Transport Analysis Tools
Copyright (C) 2026  Ashutosh Kumar Verma, Amey Thorat and Jindal Shah

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
"""

import gc
import ctypes
import numpy as np
import pandas as pd
import multiprocessing
from scipy.integrate import simpson
from scipy.optimize import curve_fit
from .util import BaseAnalysis, tqdm

# Global dictionary for shared worker data
_pcl_shared = {}

def triple_exponential(t, a1, b1, a2, b2, b3):
    """Three terms exponential fit."""
    a3 = 1.0 - a1 - a2
    return a1 * np.exp(-t / b1) + a2 * np.exp(-t / b2) + a3 * np.exp(-t / b3)

def init_pcl_worker(pos_buf, pos_shape, box_buf, box_shape, idx1, idx2, n_steps):
    """Initialize worker using Shared Memory."""
    global _pcl_shared
    _pcl_shared['pos'] = np.frombuffer(pos_buf, dtype=np.float64).reshape(pos_shape)
    _pcl_shared['box'] = np.frombuffer(box_buf, dtype=np.float64).reshape(box_shape)
    _pcl_shared['idx1'] = idx1
    _pcl_shared['idx2'] = idx2
    _pcl_shared['n_steps'] = n_steps

def cal_pcl_lifetime(t0_idx):
    """Calculates survival of the closest pair from t0."""
    pos = _pcl_shared['pos']
    boxes = _pcl_shared['box']
    idx1 = _pcl_shared['idx1']
    idx2 = _pcl_shared['idx2']
    n_total_steps = _pcl_shared['n_steps']
    
    is_same_species = np.array_equal(idx1, idx2)

    # Frame t0 data
    # pos shape is (Time, Total_Mols, Dims)
    pos_central_t0 = pos[t0_idx, idx1, :]
    pos_neighbor_all_t0 = pos[t0_idx, idx2, :]
    box_t0 = boxes[t0_idx]

    # Calculate distances at t0
    # Use broadcasting for Speed (N1, 1, D) - (1, N2, D)
    delta_t0 = pos_neighbor_all_t0[np.newaxis, :, :] - pos_central_t0[:, np.newaxis, :]
    delta_t0 -= box_t0 * np.round(delta_t0 / box_t0) # MIC
    sqd_t0 = np.sum(delta_t0**2, axis=2)

    if is_same_species:
        np.fill_diagonal(sqd_t0, np.inf)

    # Identify the specific partner index (global) for each particle in species 1
    initial_closest_local_idx = np.argmin(sqd_t0, axis=1)
    initial_partners_global_indices = idx2[initial_closest_local_idx]

    num_steps_from_t0 = n_total_steps - t0_idx
    survival_counts = np.zeros(num_steps_from_t0, dtype=np.int64)
    survival_counts[0] = len(idx1)

    # Evolution loop
    for dt_step, t_idx in enumerate(range(t0_idx + 1, n_total_steps), 1):
        pos_central_t = pos[t_idx, idx1, :]
        pos_neighbor_all_t = pos[t_idx, idx2, :]
        box_t = boxes[t_idx]

        # Calculate ALL distances for this frame to see if partners changed
        delta_t = pos_neighbor_all_t[np.newaxis, :, :] - pos_central_t[:, np.newaxis, :]
        delta_t -= box_t * np.round(delta_t / box_t)
        sqd_t = np.sum(delta_t**2, axis=2)

        if is_same_species:
            np.fill_diagonal(sqd_t, np.inf)

        # Find current closest neighbor
        current_closest_local_idx = np.argmin(sqd_t, axis=1)
        current_closest_global_indices = idx2[current_closest_local_idx]

        # Pair is "alive" if the same global particle is still the closest
        is_alive_mask = (current_closest_global_indices == initial_partners_global_indices)
        survival_counts[dt_step] = np.sum(is_alive_mask)

    return survival_counts

class Util_PairLifetime(BaseAnalysis):
    def __init__(self, args):
        super().__init__(args)
        self.n_cores = self.args.n_cores

    def run_pcl(self, COM_data, box_df, species_counts, species_charges, species1, species2, dt_md, drift, wrap_requested, charge_requested):
        """Perform pair-correlation lifetime analysis."""
        dir_mapping = {"x": 0, "y": 1, "z": 2}
        directions = list(self.args.DIR) if (hasattr(self.args, 'DIR') and self.args.DIR) else ["x", "y", "z"]
        dir_indices = [dir_mapping[d.lower()] for d in directions if d.lower() in dir_mapping]
        
        self.log_message("INFO", f"Analyzing Pair-correlation Lifetime for {species1}-{species2} in {directions}")

        species_idx_map = {}
        curr = 0
        for name, count in species_counts.items():
            species_idx_map[name] = np.arange(curr, curr + count)
            curr += count

        indices1 = species_idx_map[species1]
        indices2 = species_idx_map[species2]

        num_snapshots = COM_data.shape[0]
        total_mols = COM_data.shape[1]
        is_lammps = getattr(self.args, 'LAM', False)
        c_slice = slice(0, 3) if is_lammps else slice(1, 4)
        dim = len(dir_indices)

        pos_elements = num_snapshots * total_mols * dim
        box_elements = num_snapshots * dim
        
        pos_buf = multiprocessing.RawArray(ctypes.c_double, pos_elements)
        box_buf = multiprocessing.RawArray(ctypes.c_double, box_elements)
        
        shared_pos = np.frombuffer(pos_buf, dtype=np.float64).reshape((num_snapshots, total_mols, dim))
        shared_box = np.frombuffer(box_buf, dtype=np.float64).reshape((num_snapshots, dim))

        raw_boxes = box_df[["Lx", "Ly", "Lz"]].values[:, dir_indices].astype(np.float64)
        np.copyto(shared_box, raw_boxes)

        for m_idx in tqdm(range(total_mols), desc="Preparing PCL Data"):
            coords = COM_data[:, m_idx, c_slice][:, dir_indices].astype(np.float64)
            coords = self.unwrap_on_the_fly(coords, raw_boxes)
            if drift is not None:
                coords -= drift[:, dir_indices] if drift.ndim > 1 else drift[dir_indices]
            
            shared_pos[:, m_idx, :] = coords

        t_origin_step = int(self.args.steps)
        t0_indices = range(0, num_snapshots, t_origin_step)
        
        total_survival_counts = np.zeros(num_snapshots, dtype=np.float64)
        num_observations = np.zeros(num_snapshots, dtype=np.int64)

        ctx = multiprocessing.get_context(self.args.get_context)
        init_args = (pos_buf, shared_pos.shape, box_buf, shared_box.shape, indices1, indices2, num_snapshots)
        
        with ctx.Pool(processes=self.n_cores, initializer=init_pcl_worker, initargs=init_args) as pool:
            results_iterator = pool.imap_unordered(cal_pcl_lifetime, t0_indices)
            
            pbar_desc = f"PCL {species1}-{species2}"
            for survival_counts_from_t0 in tqdm(results_iterator, total=len(t0_indices), desc=pbar_desc):
                n_p = len(survival_counts_from_t0)
                total_survival_counts[:n_p] += survival_counts_from_t0
                num_observations[:n_p] += len(indices1)

        valid = num_observations > 0
        C_t = np.zeros_like(total_survival_counts)
        C_t[valid] = total_survival_counts[valid] / num_observations[valid]

        last_idx = np.max(np.where(valid)[0])
        C_t = C_t[:last_idx+1]
        time_axis = np.arange(len(C_t)) * dt_md
        n_fit = int(0.8 * len(C_t))
        lifetime_integral = simpson(C_t, x=time_axis)
        
        C_t_fit = np.full_like(C_t, np.nan)
        try:
            p0 = [0.4, 2.0, 0.3, 20.0, min(lifetime_integral, time_axis[-1])]
            bounds = ([0.0, 1e-6, 0.0, 1e-6, 1e-6], [1.0, np.inf, 1.0, np.inf, np.inf])
        
            results, _ = curve_fit(triple_exponential, time_axis[1:n_fit], C_t[1:n_fit], p0=p0, bounds=bounds, maxfev=200000)
            a1, b1, a2, b2, b3 = results
            lifetime_fit = (a1 * b1) + (a2 * b2) + ((1.0 - a1 - a2) * b3)
            C_t_fit = triple_exponential(time_axis, *results)
            
            if lifetime_fit > 10 * time_axis[-1]: lifetime_fit = lifetime_integral
        except Exception:
            lifetime_fit = lifetime_integral
            
        self.generate_folders("results_ion_pairs_lifetime")
        pd.DataFrame({"time_ps": time_axis, "C(t)_raw": C_t, "C(t)_fit": C_t_fit}).to_csv(
            f"results_ion_pairs_lifetime/correlation_{species1}-{species2}.csv", index=False
        )

        self.log_message("INFO","\n" + "=" * 65) 
        self.log_message("INFO",f"         {species1}-{species2} pair lifetime Summary")
        self.log_message("INFO","=" * 65)
        self.log_message("INFO", f" {species1}-{species2} Lifetime : {lifetime_fit:.3f} ps")
        self.log_message("INFO","=" * 65 + "\n")
        
        gc.collect()
        return
