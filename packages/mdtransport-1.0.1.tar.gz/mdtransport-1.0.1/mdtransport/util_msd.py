#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Wed Nov 19 15:21:36 2025

@author: Shah Research Group, Oklahoma State University <jindal.shah@okstate.edu>

MDTransport: GROMACS & LAMMPS Transport Analysis Tools
Copyright (C) 2026  Ashutosh Kumar Verma, Amey Thorat and Jindal Shah

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
"""

import numpy as np
from .util_gromacs import UTIL_GROMACS
from .util import BaseAnalysis, tqdm
from .util_diffusion import UTIL_DIFFUSION

def process_window(args):
    """Linear regression window search logic."""
    (t1, t2), species_data_local = args
    total_abs_dev = 0.0
    valid_species = 0

    for key in sorted(species_data_local.keys()):
        data = species_data_local[key]
        i1, i2 = t1, t2 - 1
        n = (i2 - i1 + 1) - (data[i2, 4] - (data[i1 - 1, 4] if i1 > 0 else 0))
        if n < 2: continue

        Sx = data[i2, 0] - (data[i1 - 1, 0] if i1 > 0 else 0)
        Sy = data[i2, 1] - (data[i1 - 1, 1] if i1 > 0 else 0)
        Sxx = data[i2, 2] - (data[i1 - 1, 2] if i1 > 0 else 0)
        Sxy = data[i2, 3] - (data[i1 - 1, 3] if i1 > 0 else 0)

        denom = (n * Sxx) - (Sx * Sx)
        if denom == 0: continue

        slope = (n * Sxy - Sx * Sy) / denom
        total_abs_dev += abs(slope - 1.0)
        valid_species += 1

    if valid_species == 0:
        return (float("inf"), float("inf"), t1, t2)
    return (total_abs_dev / valid_species, 0.0, t1, t2)

def process_msd_fft_array(args):
    """
    Function to compute MSD using FFT method.
    """
    coords, directions = args
    if directions is None:
        directions = ["x", "y", "z"]
    
    if coords is None or coords.shape[0] < 2: 
        return None

    try:
        import scipy.fft
        fft_module = scipy.fft
        using_scipy = True
    except ImportError:
        fft_module = np.fft
        using_scipy = False

    coords = coords.astype(np.float32, copy=False)
    dir_map = {"x": 0, "y": 1, "z": 2}
    cols = [dir_map[d] for d in sorted(directions) if d in dir_map]
    coords = np.ascontiguousarray(coords[:, cols])
    
    n_steps, n_dirs = coords.shape
    target = 2 * n_steps
    fast_len = fft_module.next_fast_len(target) if using_scipy else 1 << (target - 1).bit_length()

    if using_scipy:
        fft_coords = fft_module.rfft(coords, n=fast_len, axis=0, workers=1)
    else:
        fft_coords = fft_module.rfft(coords, n=fast_len, axis=0)

    fft_coords *= np.conj(fft_coords)

    if using_scipy:
        autocorr_sum = fft_module.irfft(fft_coords, n=fast_len, axis=0, workers=1)
    else:
        autocorr_sum = fft_module.irfft(fft_coords, n=fast_len, axis=0)
    
    autocorr_sum = autocorr_sum[:n_steps]
    del fft_coords
    
    sq_coords = np.square(coords)
    Q = np.empty((n_steps + 1, n_dirs), dtype=np.float32)
    Q[0] = 0.0
    np.cumsum(sq_coords, axis=0, out=Q[1:])
    del sq_coords

    deltas = np.arange(1, n_steps, dtype=np.int32)
    sum_sq_end = Q[n_steps] - Q[deltas]
    sum_sq_start = Q[n_steps - deltas]
    
    # MSD per direction
    ssd = sum_sq_start + sum_sq_end - 2 * autocorr_sum[deltas]
    n_samples = (n_steps - deltas).astype(np.float32)
    
    # Returns [Time_Index, MSD_Cols..., Samples]
    return np.column_stack([deltas.astype(np.float32), ssd, n_samples])

class UTIL_MSD(BaseAnalysis):
    def __init__(self, args):
        super().__init__(args)
        self.util_gromacs = UTIL_GROMACS(args)
        self.util_diffusion = UTIL_DIFFUSION(args)

    def unwrap_and_group(self, coords_slice, box_df, meta_slice, msd_mode):
        """
        Unwrapping and center-of-mass calculation.
        """
        n_frames, n_atoms, _ = coords_slice.shape
        boxes = box_df[['Lx', 'Ly', 'Lz']].values.astype(np.float32)

        # Masses
        masses = meta_slice['mass'].values.astype(np.float32)
        if np.all(masses == 0):
            self.log_message("WARNING", "atomic masses are zero, using Center of Geometry instead of Center of Mass")
            masses = np.ones(n_atoms, dtype=np.float32)
        
        masses_reshaped = masses[np.newaxis, :, np.newaxis]

        unwrapped = coords_slice.copy()
        for f in range(1, n_frames):
            shift = np.round((unwrapped[f] - unwrapped[f - 1]) / boxes[f]) * boxes[f]
            unwrapped[f] -= shift 

        total_mass = np.sum(masses)
        selection_com = np.sum(unwrapped * masses_reshaped, axis=1) / total_mass
        drift_vector = selection_com - selection_com[0]
        unwrapped -= drift_vector[:, np.newaxis, :]

        if msd_mode == "com":
            mol_ids = meta_slice['mol_id'].values
            unique_mols, inverse = np.unique(mol_ids, return_inverse=True)
            n_mols = len(unique_mols)
            com_coords = np.zeros((n_frames, n_mols, 3), dtype=np.float32)
            mol_mass_sums = np.bincount(inverse, weights=masses)

            for axis in range(3):
                for f in range(n_frames):
                    com_coords[f, :, axis] = np.bincount(
                        inverse,
                        weights=unwrapped[f, :, axis] * masses,
                        minlength=n_mols
                    ) / mol_mass_sums

            return com_coords

        return unwrapped

    def run_fft_on_coords(self, coords, dt, directions, label):
        """Processes 3D NumPy array."""
        n_frames, n_particles, _ = coords.shape
        deltas = np.arange(1, n_frames, dtype=np.float32)
        
        # Determine number of directions
        actual_dirs = directions if directions else ["x", "y", "z"]
        n_dirs = len(actual_dirs)
        
        msd_accum = np.zeros((len(deltas), n_dirs), dtype=np.float32)
        n_samples_accum = np.zeros(len(deltas), dtype=np.float32)

        for i in tqdm(range(n_particles), desc=f"MSD: {label}", leave=False):
            res = process_msd_fft_array((coords[:, i, :], directions))
            if res is not None:
                msd_accum += res[:, 1:-1]
                n_samples_accum += res[:, -1]

        valid = n_samples_accum > 0
        product = np.zeros_like(deltas)
        product[valid] = msd_accum.sum(axis=1)[valid] / n_samples_accum[valid]
        output = np.column_stack([deltas * dt, product])
        np.savetxt(f"results_msd/msd_{label}.csv", output, delimiter=",", header="delta,product", comments="", fmt="%.4f")

    def calculate_msd(self, COM_data, box_df, species_counts, dt, DIR, drift, wrap_requested, charge_requested):
        """
        Calculate MSD using COM_data array for specific directions.
        """
        directions = list(DIR) if DIR else ["x", "y", "z"]
        num_dirs = len(directions)
        
        self.generate_folders("results_msd")
        self.log_message("INFO", f"Running {num_dirs}D MSD in directions: {directions}")
    
        num_snapshots = COM_data.shape[0]
        is_lammps = getattr(self.args, 'LAM', False)
        c_slice = slice(0, 3) if is_lammps else slice(1, 4)
        
        boxes_all = box_df[["Lx", "Ly", "Lz"]].values.astype(np.float32)
    
        species_names = list(species_counts.keys())
        current_mol_offset = 0 
    
        for species_name in tqdm(species_names, desc="Calculating MSD", unit="species"):
            count = species_counts.get(species_name, 0)
            if count == 0:
                continue
            
            species_indices = range(current_mol_offset, current_mol_offset + count)
            current_mol_offset += count
    
            deltas = np.arange(1, num_snapshots, dtype=np.float32)
            msd_accum = np.zeros(len(deltas), dtype=np.float32)
            n_samples_accum = np.zeros(len(deltas), dtype=np.float32)
    
            for m_idx in tqdm(species_indices, desc=f"  ↳ {species_name}", leave=False):
                coords = COM_data[:, m_idx, c_slice].astype(np.float32)
                if not wrap_requested:
                    coords = self.unwrap_on_the_fly(coords, boxes_all)
                    if drift is not None:
                        coords -= drift
                else:
                    coords = self.unwrap_on_the_fly(coords, boxes_all)
                
                result = process_msd_fft_array((coords, directions))
                
                if result is not None:
                    msd_val = result[:, 1:-1].sum(axis=1) 
                    counts = result[:, -1]
                    
                    msd_accum += msd_val
                    n_samples_accum += counts
    
            valid_samples = n_samples_accum > 0
            final_msd = np.zeros_like(deltas)
            final_msd[valid_samples] = msd_accum[valid_samples] / n_samples_accum[valid_samples]
            
            output = np.column_stack([deltas * dt, final_msd])
            np.savetxt(f"results_msd/msd_{species_name}.csv", output, delimiter=",", header="delta,product", comments="", fmt="%.4f")
    
        self.util_diffusion.calculate_diffusivity(species_counts, dt, directions)
        
    def calculate_atomic_msd(self, POS_data, box_df, atom_metadata, dt):
        """Calculate MSD using atomic coordinates."""
        selections = self.parse_msd_selection_logic(self.args.msd_species)
        
        mode = str(self.args.msd_mode).lower()
        mode_upper = mode.upper()
            
        self.generate_folders("results_msd")
        msd_labels_counts = {}
        
        for sel in selections:
            mask = (atom_metadata['resname'].str.upper() == sel['resname'].upper())
            
            if sel.get('type'):
                mask &= (atom_metadata['atom_type'].astype(str).str.upper().isin([t.upper() for t in sel['type']]))
            if sel.get('name'):
                mask &= (atom_metadata['atom_name'].astype(str).str.upper().isin([n.upper() for n in sel['name']]))
            
            indices = np.where(mask)[0]
            if len(indices) == 0: 
                self.log_message("WARNING", f"No atoms found for {sel['resname']}. Skipping.")
                continue
    
            coords = self.unwrap_and_group(POS_data[:, indices, :], box_df, atom_metadata.iloc[indices], mode)
            
            label_parts = [str(sel['resname'])]
            if sel.get('name'):
                label_parts.append("_".join(sel['name']))
            if sel.get('type'):
                label_parts.append("_".join(sel['type']))
            
            label_parts.append(mode_upper)
            
            label = "_".join(label_parts)
            
            self.log_message("INFO", f"Calculating MSD for: {label}")
            
            self.run_fft_on_coords(coords, dt, self.args.DIR, label)
            msd_labels_counts[label] = coords.shape[1]
            del coords
            
        self.util_diffusion.calculate_diffusivity(msd_labels_counts, dt, self.args.DIR)