#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Wed Nov 19 15:21:36 2025

@author: Shah Research Group, Oklahoma State University <jindal.shah@okstate.edu>

MDTransport: GROMACS & LAMMPS Transport Analysis Tools
Copyright (C) 2026  Ashutosh Kumar Verma, Amey Thorat and Jindal Shah

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
"""

import os
import re
import textwrap
import logging
import sys
import shutil
import glob
import numpy as np
import tempfile
import subprocess
from scipy.constants import k, e
from tqdm import tqdm as original_tqdm

LOG_LEVEL_MAP = {
    'DEBUG': logging.DEBUG,
    'INFO': logging.INFO,
    'WARNING': logging.WARNING,
    'ERROR': logging.ERROR,
    'CRITICAL': logging.CRITICAL
}

RED = "\033[91m"
YELLOW = "\033[93m"
RESET = "\033[0m"

class CustomFormatter(logging.Formatter):
    """Removes ANSI colors for file logging and provides default 'caller'."""
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')

    def format(self, record):
        if not hasattr(record, 'caller'):
            record.caller = "MDTransport"
        
        original_msg = record.msg
        record.msg = self.ansi_escape.sub('', str(original_msg))
        formatted_message = super().format(record)
        record.msg = original_msg
        return formatted_message

class ColorFormatter(logging.Formatter):
    """Adds colors to console output only."""
    FORMATS = {
        logging.WARNING: f"{YELLOW}%(message)s{RESET}",
        logging.ERROR: f"{RED}%(message)s{RESET}",
        logging.CRITICAL: f"{RED}%(message)s{RESET}",
        logging.INFO: "%(message)s",  
    }

    def format(self, record):
        log_fmt = self.FORMATS.get(record.levelno, self._fmt)
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)

def setup_logging():
    logger = logging.getLogger("UTILLogger")
    if logger.handlers:
        return logger
    
    logger.setLevel(logging.DEBUG)

    file_handler = logging.FileHandler("MDTransport.log", mode='a', encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(CustomFormatter("%(asctime)s [%(levelname)s] [%(caller)s] - %(message)s"))
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(ColorFormatter())
    logger.addHandler(console_handler)
    
    logger.propagate = False
    return logger

logger = setup_logging()

def logged_input(prompt):
    """Writes prompt to real terminal and logs the interaction."""
    sys.__stdout__.write(prompt)
    sys.__stdout__.flush()
    user_response = input()
    logger.debug(f"PROMPT: {prompt.strip()} | USER INPUT: {user_response.strip()}", extra={'caller': 'MDTransport'})
    return user_response

def tqdm(*args, **kwargs):
    """Wrapper to ensure tqdm progress bars use the real terminal."""
    kwargs['file'] = sys.__stdout__
    if 'ncols' not in kwargs:
        try:
            kwargs['ncols'] = shutil.get_terminal_size().columns
        except OSError:
            pass
    return original_tqdm(*args, **kwargs)

class BaseAnalysis:
    """Base class to automate logging with class-name context."""
    def __init__(self, args):
        self.args = args
        self.logger = logger
        self._cached_drift = None

    def log_message(self, level, message):
        """Standardizes logging: e.g., self.log_message('INFO', 'Running MDTransport...')"""
        lvl = LOG_LEVEL_MAP.get(level.upper(), logging.INFO)
        caller = self.__class__.__name__
        self.logger.log(lvl, message, extra={'caller': caller})
        
    def compute_K_multi(self, Volume):
                                
        """
        Calculate multiplication factor for conductivity terms
        
        """
        k1 = 10 ** (-20)
        k2 = 10 ** (-12)

        K_multi = (k1 * e**2) / (2 * float(Volume) * k * self.args.Temp * k2)
        return K_multi

    def compute_K_Onsg(self, Volume):
                                
        """
        Calculate multiplication factor for Onsager coefficients
        
        """
        k1 = 10 ** (-20)
        k2 = 10 ** (-12)

        K_Onsg = (k1) / (2 * float(Volume) * k * self.args.Temp * k2)
        return K_Onsg
    
    def compute_K_m(self, Volume):
                        
        """
        Calculate multiplication factor for Nernst-Einsten conductivity
        
        """

        K_m = (e**2) / (float(Volume) * k * self.args.Temp)
        return K_m

    def parse_msd_selection_logic(self, selection_args):
        """
        Splits selection args into structured dictionaries.
        """
        if not selection_args: return []
        
        selections = []
        current_sel = None
        
        i = 0
        while i < len(selection_args):
            arg = str(selection_args[i]).lower()
            if arg == "resname":
                if current_sel: selections.append(current_sel)
                res_val = selection_args[i+1] if i+1 < len(selection_args) else "Unknown"
                current_sel = {"resname": res_val, "type": [], "name": []}
                i += 2
            elif arg in ["type", "name"]:
                if not current_sel: # If user forgot 'resname' at the start
                    current_sel = {"resname": "All", "type": [], "name": []}
                key = arg
                i += 1
                while i < len(selection_args) and str(selection_args[i]).lower() not in ["resname", "type", "name"]:
                    current_sel[key].append(selection_args[i])
                    i += 1
            else:
                i += 1
                
        if current_sel: selections.append(current_sel)
        return selections

    def update_filters_for_msd_extraction(self):
        """
        Scans --msd_species and updates global filters.
        """
        msd_args = getattr(self.args, 'msd_species', None)
        if not msd_args:
            return
        
        selections = self.parse_msd_selection_logic(msd_args)
        self.args.MSD_SELECTIONS = selections  

        sel_resnames = [s['resname'] for s in selections]
        
        existing = getattr(self.args, 'resname', [])
        if existing is None: existing = []
        self.args.resname = list(set(existing + sel_resnames))

    def parse_rdf_selection_logic(self, selection_args):
        if not selection_args: return []
        selections, current_sel, i = [], None, 0
        while i < len(selection_args):
            arg = str(selection_args[i]).lower()
            if arg == "resname":
                if current_sel: selections.append(current_sel)
                current_sel = {"resname": selection_args[i+1], "type": [], "name": []}
                i += 2
            elif arg in ["type", "name"]:
                i += 1
                while i < len(selection_args) and str(selection_args[i]).lower() not in ["resname", "type", "name"]:
                    current_sel[arg].append(selection_args[i]); i += 1
            else: i += 1
        if current_sel: selections.append(current_sel)
        return selections
            
    def print_gromacs_not_found_error(self, gmx_executable, command_list):
                
        """
        Function to print GROMACS Error if it not find GROMACS executable file (e.g., gmx or gmx_mpi).
        
        """
        full_command = ' '.join(command_list)
        
        RED = '\033[91m'
        BLUE = '\033[94m'
        CYAN = '\033[96m'
        RESET = '\033[0m'
    
        console_message = textwrap.dedent(f"""
            {RED}==============================================={RESET}
            {RED}    ERROR: GROMACS Executable Not Found        {RESET}
            {RED}==============================================={RESET}
    
            The script tried to run GROMACS but could not find the executable '{CYAN}{gmx_executable}{RESET}'.
            Failed command: {CYAN}{full_command}{RESET}
    
            {BLUE}This usually happens for one of the following reasons:{RESET}
    
              1. GROMACS is not installed or not in your system's PATH.
                 - To check, run this in your terminal: {CYAN}which {gmx_executable}{RESET}
                 - If nothing is returned, you may need to install GROMACS or
                   load the correct module on your cluster (e.g., {CYAN}module load gromacs{RESET}).
    
              2. The wrong GROMACS executable name was used.
                 - You specified '{CYAN}{gmx_executable}{RESET}', but the parallel version is often named '{CYAN}gmx_mpi{RESET}'.
                 - {BLUE}Suggestion:{RESET} Try running the script again with the flag: {CYAN}--EXE gmx_mpi{RESET}
    
              3. The executable is in a non-standard location.
                 - If GROMACS is installed but not in your PATH, provide the full path.
                 - {BLUE}Suggestion:{RESET} Find the full path and use the flag, e.g.:
                   {CYAN}--EXE /path/to/your/gromacs/bin/{gmx_executable}{RESET}
        """).strip()
        self.logger.error(console_message)

    def validate_species(self, provided_species, arg_name):
        
        """
        Validates species names against system topology, re-prompting the user
        on failure and logging all interactions correctly.
        """
        known_species = list(self.species_counts.keys())
        validated_species = provided_species

        while any(sp not in known_species for sp in validated_species):
            invalid_species = [sp for sp in validated_species if sp not in known_species]
            
            prompt_message = (
                f"ERROR: Species {invalid_species} for --{arg_name} not found.\n"
                f"       Available species are: {known_species}\n"
                f"Please enter the correct species, separated by spaces: "
            )

            try:
                user_input = logged_input(prompt_message).strip()

            except (KeyboardInterrupt, EOFError):
                self.log_message("ERROR", "User aborted during species validation.")
                sys.exit(1)

            validated_species = re.sub(r"[,\s]+", " ", user_input).strip().split()

        self.log_message("INFO", f"Species for --{arg_name} validated successfully: {validated_species}")
        return validated_species
        
    def find_unique_file(self, search_patterns, file_description, show_hint=False):
        
        """
        Finds a unique file. If multiple files are found, it interactively
        prompts the user to select one by number or by name.
        """
        if not hasattr(self, "_file_cache"):
            self._file_cache = {}

        if file_description in self._file_cache:
            return self._file_cache[file_description]

        # Search for files using all provided patterns and sort for consistent display
        found_files = sorted([f for pattern in search_patterns for f in glob.glob(pattern)])

        # No files found
        if len(found_files) == 0:
            search_dir = os.path.dirname(search_patterns[0])
            error_msg = (
                f"No {file_description} file(s) were found in '{os.path.abspath(search_dir)}'."
            )
            help_msg = (
                "Please ensure the correct files exist or specify the path "
                "using the --tpr flag."
            )
            self.log_message("ERROR", error_msg)
            self.log_message("INFO", help_msg)
            sys.exit(1)

        # Multiple files found - enter interactive selection loop
        while len(found_files) > 1:
            self.log_message("WARNING", f"Multiple {file_description} files were found.")
            self.log_message("INFO", "\nPlease select one of the following files:")

            # Display a clean, numbered list of options
            for i, file_path in enumerate(found_files):
                self.log_message("INFO", f"  [{i+1}] {os.path.basename(file_path)}")

            try:
                prompt_msg = "\nEnter the number or the name of the file to use: "
                user_input = input(prompt_msg).strip()
            except (KeyboardInterrupt, EOFError):
                self.log_message("INFO", "\n\nUser cancelled input. Exiting.")
                sys.exit(1)

            selected_file = None

            if user_input.isdigit():
                try:
                    choice_index = int(user_input) - 1
                    if 0 <= choice_index < len(found_files):
                        selected_file = found_files[choice_index]
                except (ValueError, IndexError):
                    pass 

            else:
                for file_path in found_files:
                    if user_input == os.path.basename(file_path) or user_input == file_path:
                        selected_file = file_path
                        break 

            if selected_file:
                found_files = [selected_file]
                self.log_message("INFO", f"User selected file: {selected_file}")
            else:
                self.log_message("ERROR", f"Invalid selection: '{user_input}'. Please try again.")
                self.log_message("INFO", "-" * 40)

        final_file = found_files[0]
        self._file_cache[file_description] = final_file

        return final_file
    
    def get_gromacs_files(self):
                        
        """
        Function to determine GROMACS trajectory and topology files.
        
        """
        search_dir = self.args.GRO_PATH or "."
        # Determine the Topology (.tpr) File
        if self.args.OVITO:
            if self.args.TPR:
                self.log_message(
                    "DEBUG",
                    f"Using user-provided topology file via --TPR: {self.args.TPR}",
                    )
                if not os.path.exists(self.args.TPR):
                    self.log_message("ERROR",f"Provided topology file (--TPR) does not exist: {self.args.TPR}")
                    sys.exit(1)
                tpr_file = self.args.TPR
            else:
                # No file provided. Search for one automatically.
                self.log_message(
                    "DEBUG",
                    f"GROMACS topology file was not provided. Searching for a unique .tpr file in {self.args.GRO_PATH}...",
                    )
                tpr_patterns = [os.path.join(search_dir, "*.gro")]
                tpr_file = self.find_unique_file(
                    tpr_patterns, "topology (.gro)", show_hint=True)
        else:
            if self.args.TPR:
                self.log_message(
                    "DEBUG",
                    f"Using user-provided topology file via --TPR: {self.args.TPR}",
                    )
                if not os.path.exists(self.args.TPR):
                    self.log_message("ERROR",f"Provided topology file (--TPR) does not exist: {self.args.TPR}")
                    sys.exit(1)
                tpr_file = self.args.TPR
            else:
                # No file provided. Search for one automatically.
                self.log_message(
                    "DEBUG",
                    f"GROMACS topology file was not provided. Searching for a unique .tpr file in {self.args.GRO_PATH}...",
                    )
                tpr_patterns = [os.path.join(search_dir, "*.tpr")]
                tpr_file = self.find_unique_file(
                    tpr_patterns, "topology (.tpr)", show_hint=True)

        # Determine the Trajectory (.xtc/.trr) File
        if self.args.TRAJ:
            self.log_message(
                "DEBUG",
                f"Using user-provided trajectory file via --TRAJ: {self.args.TRAJ}",
                )
            if not os.path.exists(self.args.TRAJ):
                sys.exit(
                    f"Provided trajectory file (--TRAJ) does not exist: {self.args.TRAJ}")
            traj_file = self.args.TRAJ
        else:
            # No file provided. Search for one automatically.
            self.log_message(
                "DEBUG",
                f"GROMACS trajectory file was not provided. Searching for a unique .trr/.xtc file in {self.args.GRO_PATH}...",
                )
            traj_patterns = [
                os.path.join(search_dir, "*.xtc"),
                os.path.join(search_dir, "*.trr"),
            ]
            traj_file = self.find_unique_file(
                traj_patterns, "trajectory (.xtc or .trr)", show_hint=True)

        self.log_message(
            "DEBUG",
            f"Final GROMACS topology file for analysis: {tpr_file}",
            )
        self.log_message(
            "DEBUG",
            f"Final GROMACS .trr/.xtc file for analysis: {traj_file}",
            )
        return tpr_file, traj_file
    
    def get_system_info(self, t_start, t_end, valid_species=False, return_atoms=False):
                
        """
        Function to get information of GROMACS files and run gmx command to generate pdb file and process pdb file to extract species coordinates
        
        """
        result = None
        tpr_file = None
        traj_file = None
                        
        dt = int(self.args.t_steps)

        if self.args.EXE or self.args.MDA:
            exe_file = str(self.args.EXE)
            tpr_file, traj_file = self.get_gromacs_files()

            if self.args.EXE:
    
                RED = '\033[91m'
                BLUE = '\033[34m'
                CYAN = '\033[96m'
                RESET = '\033[0m'
                
                try:
                    with tempfile.NamedTemporaryFile(prefix=".atom_info_", suffix=".xvg", delete=False) as tmp:
                        hidden_dump_file = tmp.name  
                
                    command = f"{exe_file} dump -s {tpr_file}"
                    with open(hidden_dump_file, "w") as outfile:
                        subprocess.run(
                            command,
                            shell=True,
                            check=True,
                            stdout=outfile,          
                            stderr=subprocess.PIPE   
                        )
                except subprocess.CalledProcessError as e:

                    if e.returncode == 127 or "command not found" in e.stderr.decode().lower():
                        self.print_gromacs_not_found_error(exe_file, command.split())
                        self.log_message("ERROR", f"{RED}GROMACS executable '{exe_file}' not found. Aborting.{RESET}")
                        sys.exit(1)
                
                    else:
                
                        error_details = e.stderr.decode().strip()
                
                        self.log_message("INFO",f"\n{RED}==============================================={RESET}")
                        self.log_message("INFO",f"{RED}==============================================={RESET}\n")
                        self.log_message("INFO",f"The command '{CYAN}{command}{RESET}' failed to execute properly.\n")
                        self.log_message("INFO",f"{BLUE}This often means there is an issue with your input TPR file ('{tpr_file}').{RESET}")
                        self.log_message("INFO","Please review the GROMACS error message below for details.\n")
                        self.log_message("INFO",f"{RED}--- GROMACS Error Output ---{RESET}")
                        self.log_message("INFO",error_details, file=sys.stderr)
                        self.log_message("INFO",f"{RED}----------------------------{RESET}\n")
                        self.log_message("ERROR", f"GROMACS stderr: {error_details}")
                        sys.exit(1)
    
                command_list = [
                    exe_file,
                    "trjconv",
                    "-f",
                    traj_file,
                    "-s",
                    tpr_file,
                    "-dt",
                    str(dt),
                    "-o",
                    "traj.pdb",
                    "-pbc",
                    "mol",
                ]
    
                if valid_species:
                    command_list.extend(["-b", str(t_start), "-e", str(t_end)])
                    
                if self.args.n_steps and not valid_species:
                    command_list.extend(["-b", str(t_start), "-e", str(t_end)])
                        
                display_command_list = [
                os.path.basename(arg) if arg in [tpr_file, traj_file, exe_file] else arg
                for arg in command_list]

                try:
                    self.log_message("DEBUG", f"\nRunning GROMACS command: {' '.join(display_command_list)}")
    
                    total_duration = 0
                    if t_end is not None and t_start is not None:
                        total_duration = t_end - t_start
                    elif t_end is not None:
                        total_duration = t_end
    
                    process = subprocess.Popen(
                        command_list,
                        stdin=subprocess.PIPE,   
                        stdout=subprocess.DEVNULL, 
                        stderr=subprocess.PIPE,  
                        text=True,
                        bufsize=1                
                    )
    
                    try:
                        process.stdin.write("0\n")
                        process.stdin.flush()
                        process.stdin.close() 
                    except (OSError, BrokenPipeError):
                        pass
    
                    last_time_seen = t_start if t_start else 0
                    error_buffer = []
                    
                    with tqdm(total=total_duration, unit="ps", desc="Generating PDB", leave=True) as pbar:
                        while True:
                            line = process.stderr.readline()
                            
                            # Break if process finished and no lines left
                            if not line and process.poll() is not None:
                                break
                            
                            if line:
                                error_buffer.append(line)
                                if len(error_buffer) > 20:
                                    error_buffer.pop(0)
    
                                time_match = re.search(r"time\s+([\d\.]+)", line, re.IGNORECASE)
                                if time_match:
                                    try:
                                        current_time = float(time_match.group(1))
                                        increment = current_time - last_time_seen
                                        if increment > 0:
                                            pbar.update(increment)
                                            last_time_seen = current_time
                                    except ValueError:
                                        pass
    
                    if process.returncode != 0:
                        err_rest = "".join(error_buffer)
                        raise subprocess.CalledProcessError(process.returncode, command_list, stderr=err_rest)
    
                except FileNotFoundError:
                    gmx_executable = command_list[0]
                    self.print_gromacs_not_found_error(gmx_executable, display_command_list)
                    sys.exit(1)
                
                except subprocess.CalledProcessError as e:
                    self.log_message("INFO",f"\n{RED}--- ERROR: GROMACS command failed with an internal error! ---{RESET}\n")
                    self.log_message("INFO",f"The command '{CYAN}{' '.join(display_command_list)}{RESET}' ran but reported an error.\n")
                    self.log_message("INFO",f"{RED}--- GROMACS Error Output (stderr) ---{RESET}")
                    self.log_message("INFO", e.stderr) 
                    self.log_message("INFO",f"{RED}------------------------------------{RESET}\n")
                    
                    self.log_message("ERROR", f"GROMACS stderr: {e.stderr.strip()}")
                    sys.exit(1)
    
                result = self.util_gromacs.from_pdb_and_itp(t_start, t_end, valid_species, return_atoms, hidden_dump_file)
                if os.path.exists("traj.pdb"):
                    os.remove("traj.pdb")
                if os.path.exists(hidden_dump_file):
                    os.remove(hidden_dump_file) 
            else:
                result = self.util_gromacs.from_gromacs_to_species_files(tpr_file, traj_file, t_start, t_end, valid_species, return_atoms)

        elif self.args.CHEM:
            result = self.util_gromacs.from_gromacs_to_cheme_files(t_start, t_end, valid_species, return_atoms)

        elif self.args.OVITO:
            result = self.util_gromacs.from_gromacs_to_ovito(t_start, t_end, valid_species, return_atoms)
                
        elif self.args.PDB:
            result = self.util_gromacs.from_pdb_and_itp(t_start, t_end, valid_species, return_atoms)
            
        if result is None:
            self.log_message("INFO",
                "\n\033[91mFATAL ERROR: The system info utility function did not return a value.\033[0m"
            )
            self.log_message("INFO",
                "Please check the implementation in 'src/util_gromacs.py' and ensure it has a 'return' statement.\n"
            )
            self.log_message(
                "FATAL",
                "A 'util_gromacs' method returned None. Aborting.",
                )
            sys.exit(1)

        return result

    def unwrap_on_the_fly(self, coords, boxes):
        """Unwrapping of a single molecule."""
        diffs = np.diff(coords, axis=0)
        half = boxes[1:] * 0.5
        
        shifts = np.zeros_like(diffs)
        shifts[diffs < -half] = 1.0
        shifts[diffs > half] = -1.0
        
        # Apply shifts: (cumsum * box_length)
        cumulative_shifts = np.cumsum(shifts * boxes[1:], axis=0)
        
        # Create the result
        unwrapped = coords.copy()
        unwrapped[1:] += cumulative_shifts
        return unwrapped

    def calculate_system_drift(self):
        """
        Calculates the system-wide center-of-mass drift.
        """
        num_snapshots = self.COM_data.shape[0]
        boxes = self.box_df[["Lx", "Ly", "Lz"]].values.astype(np.float32)
        is_lammps = getattr(self.args, 'LAM', False)
        c_slice = slice(0, 3) if is_lammps else slice(1, 4)
    
        weighted_path = np.zeros((num_snapshots, 3), dtype=np.float64)
        total_mass = 0.0
        
        total_mols = sum(self.species_counts.values())
        current_offset = 0
    
        # Initialize the Progress Bar
        with tqdm(total=total_mols, desc="Calculating System Drift", unit="mol") as pbar:
            for resname, count in self.species_counts.items():
                m = self.species_masses.get(resname, 1.0)
                
                for _ in range(count):
                    coords = self.COM_data[:, current_offset, c_slice].astype(np.float32)
                    unwrapped = self.unwrap_on_the_fly(coords, boxes)
                    weighted_path += (unwrapped.astype(np.float64) * m)
                    total_mass += m
                    current_offset += 1
                    pbar.update(1)
        if total_mass == 0:
            self.log_message("WARNING", "Total mass is zero, drift calculation skipped.")
            return np.zeros((num_snapshots, 3), dtype=np.float32)
    
        system_com = weighted_path / total_mass
        drift = (system_com - system_com[0]).astype(np.float32)

        return drift
        
    def generate_folders(self, folder_name):
        
        """
        Create a clean folder for output.

        """
        if not os.path.exists(folder_name):
            os.makedirs(folder_name)

        else:
    
            if os.path.isdir(folder_name):
                parent_dir = os.path.dirname(folder_name) or "."
                base_name = os.path.basename(folder_name)
    
                # Base backup name
                backup_base_name = f"#{base_name}#"
                backup_base_path = os.path.join(parent_dir, backup_base_name)
                final_backup_path = backup_base_path
    
                # Find unique backup name if needed
                if os.path.exists(final_backup_path):
                    counter = 1
                    while True:
                        numbered_backup_path = f"{backup_base_path}{counter}"
                        if not os.path.exists(numbered_backup_path):
                            final_backup_path = numbered_backup_path
                            break
                        counter += 1
    
                os.rename(folder_name, final_backup_path)
    
                os.makedirs(folder_name)
    
        return folder_name
 
    def load_universe(self, data_file, traj_file):
                        
        """
        Load MDAnalysis based on trajectory formats.
        """
        if self.args.MDA:
            try:
                import MDAnalysis as mda
            except ImportError:
                self.log_message("ERROR","Error: MDAnalysis is required for this feature (--mda) but is not installed.")
                self.log_message("INFO","Please install it to proceed.")
                self.log_message("INFO","\nTo install using pip:")
                self.log_message("INFO","  pip install MDAnalysis")
                self.log_message("INFO","\nTo install using conda:")
                self.log_message("INFO","  conda install -c conda-forge mdanalysis")
                self.log_message("INFO","-------------------------------------")
                sys.exit(1) 
        
        # Standardize extension for checking
        ext = os.path.splitext(traj_file)[1].lower()
    
        try:
            if ext in [".lammpstrj"]:
                u = mda.Universe(data_file, traj_file, format="LAMMPSDUMP", topology_format="DATA", in_memory=False)

            elif ext == ".xyz":
                u = mda.Universe(data_file, traj_file, format="XYZ", topology_format="DATA", in_memory=False)
    
            elif ext == ".xtc":
                if self.args.LAM:
                    u = mda.Universe(data_file, traj_file, format="XTC", topology_format="DATA", in_memory=False)
                else:
                    u = mda.Universe(data_file, traj_file, format="XTC", in_memory=False)
                
            elif ext == ".trr":
                u = mda.Universe(data_file, traj_file, format="TRR", in_memory=False)
    
            elif ext == ".dcd":
                u = mda.Universe(data_file, traj_file, format="DCD", topology_format="DATA", in_memory=False)
    
            elif ext in [".nc", ".ncdf", ".netcdf"]:
                u = mda.Universe(data_file, traj_file, format="NETCDF", topology_format="DATA", in_memory=False)
    
            elif ext == ".pdb":
                self.log_message("INFO", f"Please use --pdb flag when using {traj_file} file.")
                sys.exit(1)
    
            elif ext == ".bin":
                self.log_message("ERROR", "MDAnalysis does not support the native LAMMPS binary dump format (.bin).")
                self.log_message("INFO", f"Please use --ovito flag when using {traj_file} file.")
                sys.exit(1)
    
            else:
                with open(traj_file, 'r') as f:
                    first_line = f.readline().strip()
                    
                if first_line.startswith("ITEM: TIMESTEP"):
                    u = mda.Universe(data_file, traj_file, format="LAMMPSDUMP", topology_format="DATA", in_memory=False)
    
                elif first_line.isdigit():
                    u = mda.Universe(data_file, traj_file, format="XYZ", topology_format="DATA", in_memory=False)
    
        except Exception as e:
            self.log_message("ERROR", f"Failed to load trajectory: {str(e)}")
            sys.exit(1)

        return u