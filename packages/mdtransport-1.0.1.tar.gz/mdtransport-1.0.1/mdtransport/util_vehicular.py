#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Wed Nov 19 15:21:36 2025

@author: Shah Research Group, Oklahoma State University <jindal.shah@okstate.edu>

MDTransport: GROMACS & LAMMPS Transport Analysis Tools
Copyright (C) 2026  Ashutosh Kumar Verma, Amey Thorat and Jindal Shah

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
"""

import ctypes
import numpy as np
import pandas as pd
import multiprocessing
from scipy.special import gamma
from scipy.integrate import simpson
from scipy.optimize import curve_fit
from scipy.spatial import cKDTree
from .util import BaseAnalysis, tqdm
from .util_diffusion import UTIL_DIFFUSION

# Global variable for workers to access shared memory without duplication
_veh_shared = {}

def init_msd_worker(ci_buf, ci_shape):
    """Initializer for MSD FFT calculation"""
    global _veh_shared
    _veh_shared['ci'] = np.frombuffer(ci_buf, dtype=np.float32).reshape(ci_shape)

def process_msd_fft_array(m):
    """FFT for self-diffusion coefficients calculation."""
    coords = _veh_shared['ci'][:, m, :]
    n_steps, n_dims = coords.shape
    fft_coords = np.fft.rfft(coords, n=2 * n_steps, axis=0)
    autocorr = np.fft.irfft(fft_coords * np.conj(fft_coords), n=2 * n_steps, axis=0)[:n_steps]
    Q = np.zeros((n_steps + 1, n_dims))
    Q[1:] = np.cumsum(coords**2, axis=0)
    deltas = np.arange(1, n_steps)
    sum_sq = Q[n_steps] - Q[deltas] + Q[n_steps - deltas]
    ssd = np.sum(sum_sq - 2 * autocorr[deltas], axis=1)
    return np.column_stack([deltas.astype(np.float32), ssd, (n_steps - deltas).astype(np.float32)])

def init_rdf_worker(c1_buf, c1_shape, c2_buf, c2_shape, box_buf, box_shape, bins, is_same):
    """Initializer for RDF calculation"""
    global _veh_shared
    _veh_shared['c1'] = np.frombuffer(c1_buf, dtype=np.float32).reshape(c1_shape)
    _veh_shared['c2'] = np.frombuffer(c2_buf, dtype=np.float32).reshape(c2_shape)
    _veh_shared['boxes'] = np.frombuffer(box_buf, dtype=np.float32).reshape(box_shape)
    _veh_shared['bins'] = bins
    _veh_shared['is_same'] = is_same

def process_rdfs(f):
    """KD-Tree for radial distribution calculation."""
    # Convert to float64 to prevent extreme rounding errors
    c1_raw = _veh_shared['c1'][f].astype(np.float64)
    c2_raw = _veh_shared['c2'][f].astype(np.float64)
    box_l = _veh_shared['boxes'][f].astype(np.float64)
    bins = _veh_shared['bins']
    is_same = _veh_shared['is_same']
    
    c1 = np.mod(c1_raw, box_l)
    c2 = np.mod(c2_raw, box_l)
    
    c1[c1 >= box_l] = 0.0
    c1[c1 < 0.0] = 0.0
    c2[c2 >= box_l] = 0.0
    c2[c2 < 0.0] = 0.0
    
    tree = cKDTree(c2, boxsize=box_l)
    tree1 = cKDTree(c1, boxsize=box_l)
    indices = tree1.query_ball_tree(tree, bins[-1])
    
    all_dists = []
    for i, neighbors in enumerate(indices):
        if not neighbors: continue
        diff = c1[i] - c2[neighbors]
        diff -= box_l * np.round(diff / box_l) 
        dists = np.sqrt(np.sum(diff**2, axis=1))
        if is_same: dists = dists[dists > 1e-4] 
        all_dists.extend(dists)
    return np.histogram(all_dists, bins=bins)[0]

def init_res_worker(ci_buf, ci_shape, cj_buf, cj_shape, box_buf, box_shape, rcut_sq, is_same):
    """Initializer for Residence Time calculation"""
    global _veh_shared
    _veh_shared['ci'] = np.frombuffer(ci_buf, dtype=np.float32).reshape(ci_shape)
    _veh_shared['cj'] = np.frombuffer(cj_buf, dtype=np.float32).reshape(cj_shape)
    _veh_shared['boxes'] = np.frombuffer(box_buf, dtype=np.float32).reshape(box_shape)
    _veh_shared['rcut_sq'] = rcut_sq
    _veh_shared['is_same'] = is_same

def residence_time_corr(t0_idx):
    """Intermittent Residence Time Correlation."""
    ci = _veh_shared['ci']
    cj = _veh_shared['cj']
    boxes = _veh_shared['boxes']
    box_t0 = boxes[t0_idx].astype(np.float64)
    rcut_sq = _veh_shared['rcut_sq']
    is_same = _veh_shared['is_same']
    
    p1_wrap = np.mod(ci[t0_idx].astype(np.float64), box_t0)
    p2_wrap = np.mod(cj[t0_idx].astype(np.float64), box_t0)
    
    p1_wrap[p1_wrap >= box_t0] = 0.0
    p1_wrap[p1_wrap < 0.0] = 0.0
    p2_wrap[p2_wrap >= box_t0] = 0.0
    p2_wrap[p2_wrap < 0.0] = 0.0
    
    tree1 = cKDTree(p1_wrap, boxsize=box_t0)
    tree2 = cKDTree(p2_wrap, boxsize=box_t0)
    
    pairs = tree1.query_ball_tree(tree2, np.sqrt(rcut_sq))
    
    p1_list, p2_list = [], []
    for i, neighbors in enumerate(pairs):
        for j in neighbors:
            if is_same and i >= j: continue 
            p1_list.append(i)
            p2_list.append(j)
    
    if not p1_list: 
        return np.zeros(ci.shape[0] - t0_idx), 0
        
    p1 = np.array(p1_list)
    p2 = np.array(p2_list)
    
    survival_counts = []
    for t in range(t0_idx, ci.shape[0]):
        box = boxes[t]
        diff = ci[t, p1, :] - cj[t, p2, :]
        diff -= box * np.round(diff / box) # MIC
        survival_counts.append(np.sum(np.sum(diff**2, axis=1) < rcut_sq))
        
    return np.array(survival_counts), len(p1)

def exponential_fit_func(t, a, tau1, tau2, beta):
    """Stretched exponential fit."""
    return a * np.exp(-((t / tau1) ** beta)) + (1 - a) * np.exp(-(t / tau2))

class UTIL_Vehicular(BaseAnalysis):
    def __init__(self, args):
        super().__init__(args)
        self.util_diffusion = UTIL_DIFFUSION(args)
        self.n_cores = getattr(self.args, 'n_cores', multiprocessing.cpu_count())

    def get_coords_shared(self, name, COM_data, species_counts, c_slice, boxes, drift, wrap_requested):
        """Extracts coordinates directly to Shared C-Memory."""
        offset = 0
        for n, c in species_counts.items():
            if n == name:
                dat = COM_data[:, offset:offset+c, c_slice].astype(np.float32)
                
                if not wrap_requested:
                    for m in range(dat.shape[1]):
                        dat[:, m, :] = self.unwrap_on_the_fly(dat[:, m, :], boxes)
                    
                    if drift is not None: 
                        dat -= drift[:, np.newaxis, :]
                else: 
                    dat %= boxes[:, np.newaxis, :]
                
                buf = multiprocessing.RawArray(ctypes.c_float, dat.size)
                arr = np.frombuffer(buf, dtype=np.float32).reshape(dat.shape)
                np.copyto(arr, dat)
                return buf, dat.shape, arr
            offset += c

    def calculate_self_diffusion_coefficient(self, ci_buf, ci_shape, dt_md, species_i):
        """Perform self-diffusion coefficients calculation."""
        num_frames, n_mols, _ = ci_shape
        msd_accum, n_samples = None, None
        
        ctx = multiprocessing.get_context(self.args.get_context)
        tasks = list(range(n_mols)) 
        init_args = (ci_buf, ci_shape)
        
        with ctx.Pool(self.n_cores, initializer=init_msd_worker, initargs=init_args) as pool:
            for arr in tqdm(pool.imap_unordered(process_msd_fft_array, tasks, chunksize=20), 
                            total=len(tasks), desc=f"  Calculating MSD ({species_i})", leave=True):
                if arr is not None:
                    if msd_accum is None:
                        msd_accum = np.zeros(arr.shape[0], dtype=np.float64)
                        n_samples = np.zeros(arr.shape[0], dtype=np.float64)
                    msd_accum += arr[:, 1]
                    n_samples += arr[:, 2]
        
        avg_msd = msd_accum / np.where(n_samples > 0, n_samples, 1)
        time_ax = np.arange(1, len(avg_msd) + 1) * dt_md
        msd_map = {species_i: pd.DataFrame({"delta": time_ax, "product": avg_msd})}
        _, t1, t2 = self.util_diffusion.find_best_time_window(msd_map, dt_md)
        slope, _ = np.polyfit(time_ax[t1:t2], avg_msd[t1:t2], 1)
        return (slope / 6.0) * 1e-4

    def calculate_solvation_radius(self, c1_buf, c1_shape, c2_buf, c2_shape, box_buf, box_shape, species_i, species_j):
        """Perform radial distribution function to obtain solvation shell radius."""
        dr = self.args.RBIN
        box_arr = np.frombuffer(box_buf, dtype=np.float32).reshape(box_shape)
        bins = np.arange(0, (np.min(box_arr) / 2.0) + dr, dr)
        
        is_same = (species_i == species_j)
        tasks = list(range(0, c1_shape[0], self.args.steps)) 
        
        init_args = (c1_buf, c1_shape, c2_buf, c2_shape, box_buf, box_shape, bins, is_same)
        ctx = multiprocessing.get_context(self.args.get_context)
        
        with ctx.Pool(self.n_cores, initializer=init_rdf_worker, initargs=init_args) as pool:
            hists = list(tqdm(pool.imap(process_rdfs, tasks), total=len(tasks), 
                              desc=f"  Calculating RDF ({species_i}-{species_j})", leave=True))
            
        g_r = np.sum(hists, axis=0).astype(np.float64)
        vol = np.mean(np.prod(box_arr[::self.args.steps], axis=1))
        shell_v = (4.0/3.0) * np.pi * (bins[1:]**3 - bins[:-1]**3)
        density = (c2_shape[1] - (1 if is_same else 0)) / vol
        g_r /= (len(tasks) * c1_shape[1] * shell_v * density)
        p1 = np.argmax(g_r[:len(g_r)//2])
        return bins[:-1][p1 + np.argmin(g_r[p1:])]

    def calculate_residence_time(self, ci_buf, ci_shape, cj_buf, cj_shape, box_buf, box_shape, L_s, dt_md, t_origin_step, species_i, species_j):
        """Performs residence time analysis using KD-Tree."""
        is_same = (species_i == species_j)
        init_args = (ci_buf, ci_shape, cj_buf, cj_shape, box_buf, box_shape, float(L_s**2), is_same)
        t0_indices = range(0, ci_shape[0], t_origin_step)
        
        total_c = np.zeros(ci_shape[0])
        total_n = np.zeros(ci_shape[0])

        ctx = multiprocessing.get_context(self.args.get_context)
        with ctx.Pool(self.n_cores, initializer=init_res_worker, initargs=init_args) as pool:
            for res, n_in in tqdm(pool.imap_unordered(residence_time_corr, t0_indices), 
                                  total=len(t0_indices), desc=f"  Calculating Residence Time ({species_i}-{species_j})", leave=True):
                if n_in > 0:
                    total_c[:len(res)] += res
                    total_n[:len(res)] += n_in

        C_t = total_c[total_n > 0] / total_n[total_n > 0]
        time_ax = np.arange(len(C_t)) * dt_md
        integral = simpson(C_t, x=time_ax)
        try:
            p, _ = curve_fit(exponential_fit_func, time_ax, C_t, p0=[0.8, integral, 1.0, 0.8], 
                             bounds=([0, 0.1, 0.1, 0.05], [1, 1e7, 1e6, 1.0]))
            tau_res = p[0] * (p[1]/p[3]) * gamma(1/p[3]) + (1-p[0]) * p[2]
            if tau_res > 10 * integral: tau_res = integral
        except: tau_res = integral
        return tau_res, C_t[-1]

    def run_vehicular_analysis(self, COM_data, box_df, species_counts, species_i, species_j, dt_md, drift, wrap_requested, charge_requested):
        """Performs transport mechanism analysis."""
        self.generate_folders("results_transport_mechanism")
        is_lam = getattr(self.args, 'LAM', False)
        c_slice = slice(0, 3) if is_lam else slice(1, 4)
        
        boxes = box_df[["Lx", "Ly", "Lz"]].to_numpy().astype(np.float32)
        box_buf = multiprocessing.RawArray(ctypes.c_float, boxes.size)
        np.copyto(np.frombuffer(box_buf, dtype=np.float32).reshape(boxes.shape), boxes)
        
        ci_buf, ci_shape, _ = self.get_coords_shared(species_i, COM_data, species_counts, c_slice, boxes, drift, wrap_requested)
        if species_i == species_j:
            cj_buf, cj_shape = ci_buf, ci_shape 
        else:
            cj_buf, cj_shape, _ = self.get_coords_shared(species_j, COM_data, species_counts, c_slice, boxes, drift, wrap_requested)
        
        if self.args.RCUT:
            L_s = self.args.RCUT[0]
        else:
            L_s = self.calculate_solvation_radius(ci_buf, ci_shape, cj_buf, cj_shape, box_buf, boxes.shape, species_i, species_j)
            
        D_i = self.calculate_self_diffusion_coefficient(ci_buf, ci_shape, dt_md, species_i)
        
        tau_res, final_ct = self.calculate_residence_time(ci_buf, ci_shape, cj_buf, cj_shape, box_buf, boxes.shape, L_s, dt_md, self.args.steps, species_i, species_j)
        
        is_reliable = True
        quality_warnings = []
        if final_ct > 0.5:
            is_reliable = False
            quality_warnings.append(f"Correlation function did not decay (final value: {final_ct:.2f})")

        L_d = np.sqrt(6 * D_i * 1e4 * tau_res)
        ratio = L_d / L_s if L_s > 0 else 0
        
        if not is_reliable: mechanism = "Indeterminate (Unconverged)"
        elif ratio > 1.1: mechanism = "Vehicular"
        elif ratio < 0.9: mechanism = "Structural"
        else: mechanism = "Hopping"

        KEY_WIDTH = 28 
        self.log_message("INFO","\n")         
        self.log_message("INFO","=" * 65) 
        self.log_message("INFO",f"         Transport Mechanism Summary for {species_i}-{species_j}")
        self.log_message("INFO","=" * 65)
        
        if quality_warnings:
            for warn in quality_warnings:
                self.log_message("WARNING", f"  ! {warn}")
            self.log_message("INFO", "-" * 65)

        self.log_message("INFO",f"  {'Self-Diffusion of '+species_i:<{KEY_WIDTH}} : {D_i:.4e} cm²/s")
        self.log_message("INFO",f"  {'Solvation Radius (L_s)':<{KEY_WIDTH}} : {L_s:.2f} Å")
        self.log_message("INFO",f"  {'Residence Time (τ_res)':<{KEY_WIDTH}} : {tau_res:.2e} ps")
        self.log_message("INFO",f"  {'Diffusional Length (L_d)':<{KEY_WIDTH}} : {L_d:.2f} Å")
        self.log_message("INFO",f"  {'Ratio (L_d / L_s)':<{KEY_WIDTH}} : {ratio:.2f} -> {mechanism}")
        self.log_message("INFO","=" * 65 + "\n")

        summary_data = pd.DataFrame([{"D_i (cm^2/s)": D_i, "tau_res (ps)": tau_res, "L_s (A)": L_s, "L_d (A)": L_d, "Mechanism": mechanism}])
        summary_data.to_csv(f"results_transport_mechanism/summary_transport_mechanism_{species_i}-{species_j}.csv", index=False, float_format="%.4e")