#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Wed Nov 19 15:21:36 2025

@author: Shah Research Group, Oklahoma State University <jindal.shah@okstate.edu>

MDTransport: GROMACS & LAMMPS Transport Analysis Tools
Copyright (C) 2026  Ashutosh Kumar Verma, Amey Thorat and Jindal Shah

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
"""
            
import os
import ctypes
import numpy as np
import pandas as pd
import multiprocessing
from functools import partial
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from itertools import combinations_with_replacement
from .util import BaseAnalysis, tqdm

# Global dictionary to hold shared memory references in workers
_rdf_shared_data = {}

def init_rdf_process(c1_buf, c1_shape, c2_buf, c2_shape, boxes, bins, is_same):
    """
    Initialize process using shared memory buffers.
    """
    global _rdf_shared_data
    _rdf_shared_data['c1'] = np.frombuffer(c1_buf, dtype=np.float32).reshape(c1_shape)
    _rdf_shared_data['c2'] = np.frombuffer(c2_buf, dtype=np.float32).reshape(c2_shape)
    _rdf_shared_data['boxes'] = boxes
    _rdf_shared_data['bins'] = bins
    _rdf_shared_data['is_same'] = is_same

def process_frame_rdf(frame_index):
    """
    Process frames for rdf calculations using on-the-fly MIC.
    """
    c1 = _rdf_shared_data['c1'][frame_index]
    c2 = _rdf_shared_data['c2'][frame_index]
    box_l = _rdf_shared_data['boxes'][frame_index]
    bins = _rdf_shared_data['bins']
    is_same = _rdf_shared_data['is_same']

    diffs = c1[:, np.newaxis, :] - c2[np.newaxis, :, :]
    diffs -= box_l * np.round(diffs / box_l)
    dists = np.linalg.norm(diffs, axis=2)
    
    if is_same:
        final_dists = dists[~np.eye(dists.shape[0], dtype=bool)]
    else:
        final_dists = dists.flatten()
        
    hist, _ = np.histogram(final_dists, bins=bins)
    return hist

def process_coords_chunk(task_args, POS_data, indices, all_boxes, inverse, n_mols, mode, masses=None):
    """
    Process coordinates in chunks.
    """
    chunk_indices, out_idx_start = task_args
    
    coords = POS_data[chunk_indices][:, indices, :].copy()
    boxes = all_boxes[chunk_indices][:, np.newaxis, :] 
    n_frames = coords.shape[0]

    if mode == "com":
        mol_mass_sums = np.bincount(inverse, weights=masses).astype(np.float32)
        _, first_atom_indices = np.unique(inverse, return_index=True)
        
        ref_coords = coords[:, first_atom_indices, :][:, inverse, :]
        
        diff = coords - ref_coords
        diff -= boxes * np.round(diff / boxes)
        
        whole_mol_coords = ref_coords + diff
        weighted_coords = whole_mol_coords * masses[np.newaxis, :, np.newaxis]
        
        mol_coms = np.zeros((n_frames, n_mols, 3), dtype=np.float32)
        for dim in range(3):
            for f in range(n_frames):
                mol_coms[f, :, dim] = np.bincount(inverse, weights=weighted_coords[f, :, dim], minlength=n_mols)
        
        final_coords = mol_coms / mol_mass_sums[np.newaxis, :, np.newaxis]
        return out_idx_start, final_coords
    
    else:
        return out_idx_start, coords
    
class UTIL_RDF(BaseAnalysis):
    
    """
    This class computes RDF.
    """
    def __init__(self, args):
        super().__init__(args)
        self.n_cores = self.args.n_cores
        
    def get_atomic_coords(self, POS_data, meta, all_boxes, sel, mode):
        """
        Slices POS_data and applies grouping using Center of Mass.
        """
        mask = (meta['resname'].str.upper() == sel['resname'].upper())
        if sel['type']:
            mask &= (meta['atom_type'].astype(str).str.upper().isin([t.upper() for t in sel['type']]))
        if sel['name']:
            mask &= (meta['atom_name'].astype(str).str.upper().isin([n.upper() for n in sel['name']]))
        
        indices = np.where(mask)[0]
        if len(indices) == 0: return None
        
        masses = meta.iloc[indices]['mass'].values.astype(np.float32)
        if np.all(masses == 0):
            masses = np.ones(len(indices), dtype=np.float32)

        n_total_frames = POS_data.shape[0]
        
        inverse, n_mols = None, 0
        if mode == "com":
            mol_ids = meta.iloc[indices]['mol_id'].values
            unique_mols, inverse = np.unique(mol_ids, return_inverse=True)
            n_mols = len(unique_mols)
            out_shape = (n_total_frames, n_mols, 3)
        else:
            out_shape = (n_total_frames, len(indices), 3)

        final_coords = np.empty(out_shape, dtype=np.float32)

        if self.n_cores > 1:
            chunk_size = max(1, n_total_frames // (self.n_cores * 2))
            tasks = []
            for i in range(0, n_total_frames, chunk_size):
                end = min(i + chunk_size, n_total_frames)
                tasks.append((list(range(i, end)), i))

            ctx = multiprocessing.get_context(getattr(self.args, 'get_context', 'spawn'))
            worker = partial(process_coords_chunk, 
                             POS_data=POS_data, indices=indices, all_boxes=all_boxes, 
                             inverse=inverse, n_mols=n_mols, mode=mode, masses=masses) 

            with ctx.Pool(processes=self.n_cores) as pool:
                for start_idx, result_chunk in pool.imap_unordered(worker, tasks):
                    final_coords[start_idx : start_idx + result_chunk.shape[0]] = result_chunk
        else:
            _, result = process_coords_chunk((list(range(n_total_frames)), 0), 
                                             POS_data, indices, all_boxes, 
                                             inverse, n_mols, mode, masses=masses) 
            final_coords = result

        return final_coords

    def perform_rdf_atomic(self, POS_data, atom_metadata, box_df, rdf_pairs, rdf_modes):
        """Function to compute RDF using atomic coordinates."""
        self.generate_folders("results_rdf")
        selections = self.parse_rdf_selection_logic(rdf_pairs)
        
        if len(selections) % 2 != 0:
            self.log_message("ERROR", "RDF requires an even number of selections.")
            return

        m1 = rdf_modes[0].lower() if len(rdf_modes) > 0 else 'atom'
        m2 = rdf_modes[1].lower() if len(rdf_modes) > 1 else 'atom'

        all_box_lengths = box_df[['Lx', 'Ly', 'Lz']].values.astype(np.float32)
        dr = self.args.RBIN if self.args.RBIN else 0.02
        r_max = np.min(all_box_lengths) / 2.0
        bins = np.arange(0, r_max + dr, dr)
        
        sample_step = int(getattr(self.args, 'steps', 1))
        frames_to_process = range(0, POS_data.shape[0], sample_step)

        rdf_results_list = []

        def get_sel_label(sel_dict, mode):
            parts = []
            for key in ['resname', 'name', 'type']:
                val = sel_dict.get(key, '')
                if val:
                    parts.append("_".join(val) if isinstance(val, list) else str(val))
            parts.append(mode.upper())
            return "_".join(parts)

        for i in range(0, len(selections), 2):
            sel1, sel2 = selections[i], selections[i+1]
            label1 = get_sel_label(sel1, m1)
            label2 = get_sel_label(sel2, m2)
            pair_label = f"{label1}-{label2}"
            
            self.log_message("INFO", f"Calculating RDF: {label1} - {label2}")
            
            c1 = self.get_atomic_coords(POS_data, atom_metadata, all_box_lengths, sel1, m1)
            c2 = self.get_atomic_coords(POS_data, atom_metadata, all_box_lengths, sel2, m2)
            
            if c1 is None or c2 is None: continue
            
            is_same = (sel1 == sel2 and m1 == m2)
            
            output_df = self.compute_and_save_rdf(
                c1, c2, all_box_lengths, bins,
                is_same, pair_label, "results_rdf", frames_to_process
            )
            
            if self.args.ANA:
                res = self.extract_solvation_radii(output_df, pair_label)
                if res[0] is not None:
                    rdf_results_list.append({
                        "Pair": pair_label, "Peak Radius (Å)": res[0],
                        "Peak Height": res[2], "Solvation Radius (Å)": res[1],
                        "Coordination Number": res[3]
                    })

        if rdf_results_list:
            self.summarize_rdf_analysis(rdf_results_list, "results_rdf")
    
    def compute_and_save_rdf(self, coords1, coords2, all_box_lengths, bins, is_same_species, pair_name, output_dir, frames_to_process):
        """Calculate and save RDFs for requested pairs pairs."""
        n_p1, n_p2 = coords1.shape[1], coords2.shape[1]

        c1_buf = multiprocessing.RawArray(ctypes.c_float, coords1.size)
        c1_shared = np.frombuffer(c1_buf, dtype=np.float32).reshape(coords1.shape)
        np.copyto(c1_shared, coords1)

        if is_same_species:
            c2_buf = c1_buf
        else:
            c2_buf = multiprocessing.RawArray(ctypes.c_float, coords2.size)
            c2_shared = np.frombuffer(c2_buf, dtype=np.float32).reshape(coords2.shape)
            np.copyto(c2_shared, coords2)

        ctx = multiprocessing.get_context(self.args.get_context)
            
        init_args = (c1_buf, coords1.shape, c2_buf, coords2.shape, all_box_lengths, bins, is_same_species)
        
        with ctx.Pool(processes=self.n_cores, initializer=init_rdf_process, initargs=init_args) as pool:
            results = list(tqdm(
                pool.imap(process_frame_rdf, frames_to_process, chunksize=10),
                total=len(frames_to_process),
                desc="     Calculating RDF"
            ))

        total_hist = np.sum(results, axis=0).astype(np.float64)
        
        shell_volumes = (4.0 / 3.0) * np.pi * (bins[1:]**3 - bins[:-1]**3)
        processed_boxes = all_box_lengths[list(frames_to_process), :]
        avg_vol = np.mean(processed_boxes[:, 0] * processed_boxes[:, 1] * processed_boxes[:, 2])
        
        norm_fac = len(frames_to_process) * n_p1
        num_neighbors = n_p2 - 1 if is_same_species else n_p2
        ideal_rho = num_neighbors / avg_vol

        with np.errstate(divide="ignore", invalid="ignore"):
            g_r = (total_hist / norm_fac) / (shell_volumes * ideal_rho)
        g_r[np.isnan(g_r) | np.isinf(g_r)] = 0

        avg_neighbors_per_shell = total_hist / norm_fac
        coordination_number_curve = np.cumsum(avg_neighbors_per_shell)

        dr = bins[1] - bins[0]
        output_df = pd.DataFrame({
            "r (Ang.)": bins[:-1] + dr/2.0, 
            "g_r": g_r,
            "coordination_number": coordination_number_curve
        })
        
        output_file = os.path.join(output_dir, f"rdf_{pair_name}.csv")
        output_df.to_csv(output_file, index=False, float_format="%.6f")
        
        if self.args.ANA:
            self.plot_rdf(output_df["r (Ang.)"], output_df["g_r"], pair_name, output_dir)
        
        return output_df

    def cal_rdf(self, COM_data, box_df, species_counts, dt_md, drift, wrap_requested, charge_requested):
        """Calculate COM-COM RDFs for every possible pair using COM_data."""
        output_dir = "results_rdf"
        self.generate_folders(output_dir)
        frame_step = self.args.steps
        
        is_lammps = getattr(self.args, 'LAM', False)
        c_slice = slice(0, 3) if is_lammps else slice(1, 4)
        all_box_lengths = box_df[["Lx", "Ly", "Lz"]].to_numpy().astype(np.float32)
        n_snapshots = COM_data.shape[0]
    
        species_slices = {}
        current_offset = 0
        for resname, count in species_counts.items():
            species_slices[resname] = (current_offset, current_offset + count)
            current_offset += count
    
        target_resnames = getattr(self.args, 'resname', None)
        if target_resnames is None:
            pairs_to_compute = list(combinations_with_replacement(species_counts.keys(), 2))
        else:
            if isinstance(target_resnames, str):
                target_resnames = [target_resnames]
            if len(target_resnames) % 2 != 0:
                self.log_message("ERROR", "resname must be provided in pairs for RDF (e.g., --resname EMI EMI)")
                return
            pairs_to_compute = [(target_resnames[i], target_resnames[i+1]) 
                                for i in range(0, len(target_resnames), 2)]
    
        needed_species = set(s for pair in pairs_to_compute for s in pair)
        species_data = {}
        
        for species in tqdm(needed_species, desc="Assembling species data"):
            if species not in species_slices:
                self.log_message("WARNING", f"No data found for species: {species}")
                continue
            
            start, end = species_slices[species]
            coords = COM_data[:, start:end, c_slice].astype(np.float32)
            
            if not wrap_requested:
                if drift is not None:
                    coords -= drift
            else:
                coords %= all_box_lengths[:, np.newaxis, :]
    
            species_data[species] = coords
    
        dr = self.args.RBIN
        r_max = np.min(all_box_lengths) / 2.0
        bins = np.arange(0, r_max + dr, dr)
        frames_to_process = range(0, n_snapshots, int(frame_step))
        
        rdf_results_list = []
        
        for spec1, spec2 in pairs_to_compute:
            if spec1 not in species_data or spec2 not in species_data:
                continue
    
            self.log_message("INFO", f"\n--- Calculating RDF for {spec1}-{spec2} ---")
            pair_name = f"{spec1}-{spec2}"
            
            output_df = self.compute_and_save_rdf(
                species_data[spec1], species_data[spec2], all_box_lengths, bins,
                is_same_species=(spec1 == spec2), pair_name=pair_name,
                output_dir=output_dir, frames_to_process=frames_to_process
            )
            
            if self.args.ANA:
                peak_radius, solv_radius, peak_h, coord_num = self.extract_solvation_radii(output_df, pair_name)
                if peak_radius is not None:
                    rdf_results_list.append({
                        "Pair": pair_name.replace("_", "-"), 
                        "Peak Radius (Å)": peak_radius,
                        "Peak Height": peak_h,
                        "Solvation Radius (Å)": solv_radius,
                        "Coordination Number": coord_num
                    })
        
        self.summarize_rdf_analysis(rdf_results_list, output_dir)
        
    def extract_solvation_radii(self, rdf_dataframe, pair_name="rdf"):
        
        """
        Extract solvation radii, peak height and coordination number.
        """
        try:
            r = rdf_dataframe["r (Ang.)"].values
            g_r = rdf_dataframe["g_r"].values
            cn = rdf_dataframe["coordination_number"].values
    
            if r.size < 20: raise ValueError(f"Not enough data points ({r.size}) for analysis.")
            
            p1_idx = np.argmax(g_r)
    
            search_after_p1_idx = p1_idx + 5
            if search_after_p1_idx >= len(r):
                raise ValueError("No data exists after the first peak to find the first minimum.")
                
            rf_idx_rel = np.argmin(g_r[search_after_p1_idx:])
            rf_idx = search_after_p1_idx + rf_idx_rel
    
            return (
                round(float(r[p1_idx]), 3),
                round(float(r[rf_idx]), 3),
                round(float(g_r[p1_idx]), 3),
                round(float(cn[rf_idx]), 3)
                )
    
        except (ValueError, IndexError) as e:
            self.log_message("ERROR", f"  > Solvation analysis failed for pair '{pair_name}': {e}")
            return None, None, None, None
    
    def summarize_rdf_analysis(self, rdf_results_list, output_dir):
                
        """
        Summarize solvation radii
        """
        if not self.args.ANA: return
        
        if rdf_results_list:
            summary_df = pd.DataFrame(rdf_results_list)
            self.log_message("INFO", "\n\n" + "="*80 + "\n           RDF Analysis Summary\n" + "="*80)
            self.log_message("INFO", summary_df.to_string(index=False))
            self.log_message("INFO", "="*80)
            summary_file = os.path.join(output_dir, "rdf_summary.csv")
            summary_df.to_csv(summary_file, index=False, float_format='%.4f')
        else:
            self.log_message("WARNING", "\n--ANA flag was used, but no valid RDF analysis data was generated. Summary file not created.")

    def setup_plot(self, figsize=(12, 9)):
                
        """
        Setep for plotting
        """
        plt.rc("font", size=28)
        plt.rcParams["axes.edgecolor"] = "black"
        plt.rcParams["axes.linewidth"] = 3.0
        fig, ax = plt.subplots(figsize=figsize)
        ax.tick_params(
            which="both", direction="in", length=12, width=3,
            top=True, bottom=True, left=True, right=True,
            labelsize=32)
        ax.tick_params(which="minor", length=6)
        ax.minorticks_on()
        return fig, ax

    def plot_rdf(self, r, g_r, pair_name, output_dir):
                
        """
        Plot RDFs
        """
        fig, ax = self.setup_plot()
        ax.plot(r, g_r, label="g(r)", color="royalblue", linewidth=3)
        ax.set_xlabel("r (Å)")
        ax.set_ylabel("g(r)")
        ax.set_xlim(left=0)
        ax.set_ylim(bottom=0)
        ax.xaxis.set_minor_locator(ticker.AutoMinorLocator(n=5))
        ax.yaxis.set_minor_locator(ticker.AutoMinorLocator(n=5))
        output_plot_file = os.path.join(output_dir, f"{pair_name}_rdf_analysis.png")
        plt.savefig(output_plot_file, dpi=300, bbox_inches="tight")
        plt.close(fig)