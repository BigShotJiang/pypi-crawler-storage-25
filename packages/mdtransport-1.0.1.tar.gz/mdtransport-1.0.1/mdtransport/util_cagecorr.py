#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Wed Nov 19 15:21:36 2025

@author: Shah Research Group, Oklahoma State University <jindal.shah@okstate.edu>

MDTransport: GROMACS & LAMMPS Transport Analysis Tools
Copyright (C) 2026  Ashutosh Kumar Verma, Amey Thorat and Jindal Shah

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
"""

import gc
import ctypes
import warnings
import numpy as np
import pandas as pd
import multiprocessing
from .util import BaseAnalysis, tqdm
from scipy.integrate import simpson
from scipy.optimize import curve_fit

# Global shared memory dictionaries to prevent RAM duplication in workers
_rdf_shared_data = {}
_cage_shared_data = {}

def triple_exponential(t, a1, b1, a2, b2, b3):
    """Three terms exponential fit."""
    a3 = 1.0 - a1 - a2
    return a1 * np.exp(-t / b1) + a2 * np.exp(-t / b2) + a3 * np.exp(-t / b3)


def init_rdf_variables(c1_buf, c1_shape, c2_buf, c2_shape, box_lengths, bins, is_same):
    """Initialize global variables for RDF calculations."""
    global _rdf_shared_data
    _rdf_shared_data['c1'] = np.frombuffer(c1_buf, dtype=np.float32).reshape(c1_shape)
    _rdf_shared_data['c2'] = np.frombuffer(c2_buf, dtype=np.float32).reshape(c2_shape)
    _rdf_shared_data['box_lengths'] = box_lengths
    _rdf_shared_data['bins'] = bins
    _rdf_shared_data['is_same'] = is_same


def rdf_process_frame(frame_index):
    """Function to process each frame for RDF calculations using MIC."""
    c1 = _rdf_shared_data['c1'][frame_index]
    c2 = _rdf_shared_data['c2'][frame_index]
    box_l = _rdf_shared_data['box_lengths'][frame_index]
    
    diffs = c1[:, np.newaxis, :] - c2[np.newaxis, :, :]
    diffs -= box_l * np.round(diffs / box_l)
    dists = np.linalg.norm(diffs, axis=2)
    
    if _rdf_shared_data['is_same']:
        final_dists = dists[~np.eye(c1.shape[0], dtype=bool)]
    else:
        final_dists = dists.flatten()
        
    hist, _ = np.histogram(final_dists, bins=_rdf_shared_data['bins'])
    return hist

def init_cage_corr(pos_buf, pos_shape, box_lengths, center_indices, cage_indices, num_total_steps, r_cut):
    """Initialize global variables."""
    global _cage_shared_data
    _cage_shared_data['positions'] = np.frombuffer(pos_buf, dtype=np.float32).reshape(pos_shape)
    _cage_shared_data['box_lengths'] = box_lengths
    _cage_shared_data['center_indices'] = center_indices
    _cage_shared_data['cage_indices'] = cage_indices
    _cage_shared_data['num_total_steps'] = num_total_steps
    _cage_shared_data['r_cut_sq'] = np.float32(r_cut**2)

def cal_cage_lifetime(t0_idx):
    """Function to process survival."""
    positions = _cage_shared_data['positions']
    box_lengths = _cage_shared_data['box_lengths']
    center_indices = _cage_shared_data['center_indices']
    cage_indices = _cage_shared_data['cage_indices']
    num_total_steps = _cage_shared_data['num_total_steps']
    r_cut_sq = _cage_shared_data['r_cut_sq']

    pos_center_t0 = positions[t0_idx, center_indices, :]
    pos_cage_all_t0 = positions[t0_idx, cage_indices, :]
    box_t0 = box_lengths[t0_idx]

    delta_t0 = pos_cage_all_t0[np.newaxis, :, :] - pos_center_t0[:, np.newaxis, :]
    delta_t0 -= box_t0 * np.round(delta_t0 / box_t0)
    sqd_t0 = np.einsum("ijk,ijk->ij", delta_t0, delta_t0)

    in_cage_mask_t0 = sqd_t0 < r_cut_sq

    original_cages = [
        frozenset(cage_indices[in_cage_mask_t0[i]])
        for i in range(len(center_indices))
    ]

    num_steps_from_t0 = num_total_steps - t0_idx
    survival_counts = np.zeros(num_steps_from_t0, dtype=np.int64)
    survival_counts[0] = len(center_indices)

    for dt_step, t_idx in enumerate(range(t0_idx + 1, num_total_steps), 1):
        pos_center_t = positions[t_idx, center_indices, :]
        pos_cage_all_t = positions[t_idx, cage_indices, :]
        box_t = box_lengths[t_idx]

        delta_t = pos_cage_all_t[np.newaxis, :, :] - pos_center_t[:, np.newaxis, :]
        delta_t -= box_t * np.round(delta_t / box_t)
        sqd_t = np.einsum("ijk,ijk->ij", delta_t, delta_t)
        in_cage_mask_t = sqd_t < r_cut_sq

        alive_count = 0
        for i in range(len(center_indices)):
            current_cage = frozenset(cage_indices[in_cage_mask_t[i]])
            if current_cage == original_cages[i]:
                alive_count += 1
        survival_counts[dt_step] = alive_count

    return survival_counts


class Util_CageCorrelation(BaseAnalysis):
    
    """
    This is a Util_CageCorrelation class which perform cage-correlation analysis
    """
    def __init__(self, args):
        """Initialize class with input arguments and class objects"""
        super().__init__(args)
        self.n_cores = self.args.n_cores

    def calculate_solvation_radius(self, COM_data, box_lengths, species_counts, species_i, species_j):
        """
        Function to get first solvation radius from COM-COM RDF of species_i and species_j.
        """
        all_species = list(species_counts.keys())
        def get_slice(name):
            curr = 0
            for s in all_species:
                if s == name: return slice(curr, curr + species_counts[s])
                curr += species_counts[s]
            return None

        is_lammps = getattr(self.args, 'LAM', False)
        c_slice = slice(0, 3) if is_lammps else slice(1, 4)
        
        num_snapshots = COM_data.shape[0]
        step = int(self.args.steps)
        frames_to_process = list(range(0, num_snapshots, step))
        n_selected_frames = len(frames_to_process)

        is_same = (species_i == species_j)
        slice_i = get_slice(species_i)
        slice_j = get_slice(species_j)
        
        n_p1 = species_counts[species_i]
        n_p2 = species_counts[species_j]

        c1_buf = multiprocessing.RawArray(ctypes.c_float, n_selected_frames * n_p1 * 3)
        c1_shared = np.frombuffer(c1_buf, dtype=np.float32).reshape((n_selected_frames, n_p1, 3))
        
        for idx, f_idx in enumerate(frames_to_process):
            c1_shared[idx] = COM_data[f_idx, slice_i, c_slice].astype(np.float32)

        if is_same:
            c2_buf = c1_buf
            c2_shape = c1_shared.shape
        else:
            c2_buf = multiprocessing.RawArray(ctypes.c_float, n_selected_frames * n_p2 * 3)
            c2_shared = np.frombuffer(c2_buf, dtype=np.float32).reshape((n_selected_frames, n_p2, 3))
            for idx, f_idx in enumerate(frames_to_process):
                c2_shared[idx] = COM_data[f_idx, slice_j, c_slice].astype(np.float32)
            c2_shape = c2_shared.shape

        sub_box_lengths = box_lengths[frames_to_process]
        
        dr = 0.1
        r_max = np.min(box_lengths) / 2.0
        bins = np.arange(0, r_max + dr, dr)

        init_args = (c1_buf, c1_shared.shape, c2_buf, c2_shape, sub_box_lengths, bins, is_same)
        
        ctx = multiprocessing.get_context(self.args.get_context)
        with ctx.Pool(processes=self.n_cores, initializer=init_rdf_variables, initargs=init_args) as pool:
            # We now only loop over the selection indices (0 to n_selected_frames)
            results = list(tqdm(
                pool.imap(rdf_process_frame, range(n_selected_frames)),
                total=n_selected_frames,
                desc="Calculating RDF"
            ))

        total_hist = np.sum(results, axis=0).astype(np.float64)
        shell_volumes = (4.0 / 3.0) * np.pi * (bins[1:] ** 3 - bins[:-1] ** 3)
        avg_volume = np.mean(np.prod(sub_box_lengths, axis=1))
        
        num_neighbors = n_p2 - 1 if is_same else n_p2
        ideal_density = num_neighbors / avg_volume
        norm_factor = n_selected_frames * n_p1
        
        with np.errstate(divide="ignore", invalid="ignore"):
            g_r_full = (total_hist / norm_factor) / (shell_volumes * ideal_density)
        g_r_full[np.isnan(g_r_full) | np.isinf(g_r_full)] = 0
        r_full = bins[:-1]

        cutoff_index = int(len(r_full) * 0.90)
        r, g_r = r_full[:cutoff_index], g_r_full[:cutoff_index]
        p1_idx = np.argmax(g_r)
        rf_idx_relative = np.argmin(g_r[p1_idx + 1:])
        r_cut = r[p1_idx + 1 + rf_idx_relative]

        self.log_message("DEBUG", f"Solvation radius r_cut = {r_cut:.2f} Å (Sampled {n_selected_frames} frames).")
        return r_cut

    def run_cage_lifetime(self, COM_data, box_df, species_counts, cation_list, anion_list, dt_md, drift, wrap_requested, charge_requested):
        """
        Function to perform cage-correlation.
        """
        self.generate_folders("results_cage_correlation")
        t_origin_step = int(self.args.steps)
        num_snapshots = COM_data.shape[0]
        box_lengths = box_df[["Lx", "Ly", "Lz"]].to_numpy(dtype=np.float32)

        if hasattr(self.args, 'RCUT') and self.args.RCUT:
            r_cut = float(self.args.RCUT[0])
        else:
            r_cut = self.calculate_solvation_radius(COM_data, box_lengths, species_counts, cation_list[0], anion_list[0])

        species_idx_map = {}
        curr = 0
        for name, count in species_counts.items():
            species_idx_map[name] = np.arange(curr, curr + count)
            curr += count

        center_indices = np.concatenate([species_idx_map[s] for s in cation_list if s in species_idx_map])
        cage_indices = np.concatenate([species_idx_map[s] for s in anion_list if s in species_idx_map])

        is_lammps = getattr(self.args, 'LAM', False)
        c_slice = slice(0, 3) if is_lammps else slice(1, 4)
        
        total_mols = COM_data.shape[1]
        pos_buf = multiprocessing.RawArray(ctypes.c_float, num_snapshots * total_mols * 3)
        pos_shared = np.frombuffer(pos_buf, dtype=np.float32).reshape((num_snapshots, total_mols, 3))
        
        for f in tqdm(range(num_snapshots), desc="Loading Trajectory"):
            pos_shared[f] = COM_data[f, :, c_slice].astype(np.float32)

        t0_indices = range(0, num_snapshots, t_origin_step)
        init_args = (pos_buf, pos_shared.shape, box_lengths, center_indices, cage_indices, num_snapshots, r_cut)

        total_survival_counts = np.zeros(num_snapshots, dtype=np.float64)
        num_observations = np.zeros(num_snapshots, dtype=np.int64)

        ctx = multiprocessing.get_context(self.args.get_context)
        with ctx.Pool(processes=self.n_cores, initializer=init_cage_corr, initargs=init_args) as pool:
            results = pool.imap_unordered(cal_cage_lifetime, t0_indices)
            for survival in tqdm(results, total=len(t0_indices), desc="Cage Correlation"):
                n_p = len(survival)
                total_survival_counts[:n_p] += survival
                num_observations[:n_p] += len(center_indices)

        valid = num_observations > 0
        C_t = np.zeros_like(total_survival_counts)
        C_t[valid] = total_survival_counts[valid] / num_observations[valid]
        
        last_idx = np.max(np.where(valid)[0])
        C_t = C_t[:last_idx+1]
        time_axis = np.arange(len(C_t)) * dt_md

        n = int(0.8 * len(C_t))
        
        lifetime_integral = simpson(C_t, x=time_axis)
        method_str = f"Direct Integration (τ={lifetime_integral:.3f} ps)"
        
        C_t_fit = np.full_like(C_t, np.nan)
        
        try:
            p0 = [0.4, 2.0, 0.3, 20.0, min(lifetime_integral, time_axis[-1])]
            bounds = (
                [0.0, 1e-6, 0.0, 1e-6, 1e-6],      
                [1.0, np.inf, 1.0, np.inf, np.inf] 
            )
        
            with warnings.catch_warnings(record=True) as wlist:
                warnings.simplefilter("always")
        
                results_fit, pcov = curve_fit(
                    triple_exponential,
                    time_axis[1:n],
                    C_t[1:n],
                    p0=p0,
                    bounds=bounds,
                    maxfev=200000,
                )
        
                a1, b1, a2, b2, b3 = results_fit
                a3 = 1.0 - a1 - a2
                
                # Analytical Lifetime Calculation: τ = Σ (ai * bi)
                lifetime_fit = (a1 * b1) + (a2 * b2) + (a3 * b3)
                
                # Calculate the fit curve for plotting
                C_t_fit = triple_exponential(time_axis, *results_fit)
                
                method_str += f" | Full Exp. Fit (τ={lifetime_fit:.3f} ps)"
        
                for warn in wlist:
                    self.log_message("WARNING", f"{warn.category.__name__}: {warn.message}")
                
            if lifetime_fit > 10 * time_axis[-1]:
                self.log_message("WARNING", "Unphysical lifetime from fit, Using direct integration")
                lifetime_fit = lifetime_integral
        
        except Exception as e:
            self.log_message("WARNING", f"Fitting failed. Error: {e}")
            lifetime_fit = lifetime_integral

        cation_str = "-".join(cation_list)
        anion_str = "-".join(anion_list)
        output_name = f"cage_lifetime_cat_{cation_str}_an_{anion_str}_rcut{r_cut:.2f}"

        pd.DataFrame(
            {"time_ps": time_axis, "C(t)_raw": C_t, "C(t)_fit": C_t_fit}
        ).to_csv(
            f"results_cage_correlation/correlation_{output_name}.csv", index=False, float_format="%.6e"
        )

        pd.DataFrame(
            {
                "lifetime_ps": [
                    lifetime_fit if "lifetime_fit" in locals() else np.nan
                ],
            }
        ).to_csv(
            f"results_cage_correlation/lifetime_{output_name}.csv", index=False, float_format="%.4f"
        )
        
        self.log_message("INFO","\n") 
        self.log_message("INFO","=" * 65) 
        self.log_message("INFO",f"         Cage Correlation Lifetime Summary (Rcut: {r_cut:.2f} A) ")
        self.log_message("INFO","=" * 65)

        key_fit = "Cage Lifetime"
        KEY_WIDTH = len(key_fit) + 2
        
        if lifetime_fit is not None:
            self.log_message("INFO", f" {key_fit:<{KEY_WIDTH}} : {lifetime_fit:.3f} ps")
            
        self.log_message("INFO","=" * 65 + "\n")

        gc.collect()