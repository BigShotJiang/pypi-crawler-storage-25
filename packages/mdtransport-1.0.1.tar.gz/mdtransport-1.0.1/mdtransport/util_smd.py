#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Wed Nov 19 15:21:36 2025

@author: Shah Research Group, Oklahoma State University <jindal.shah@okstate.edu>

MDTransport: GROMACS & LAMMPS Transport Analysis Tools
Copyright (C) 2026  Ashutosh Kumar Verma, Amey Thorat and Jindal Shah

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
"""

import gc
import ctypes
import numpy as np
import pandas as pd
from itertools import combinations
import multiprocessing
from scipy import constants as const
from .util import BaseAnalysis, tqdm
from .util_diffusion import UTIL_DIFFUSION

# Global for worker access
_sm_shared = {}

def get_dir_indices(dir_arg):
    mapping = {'x': [0], 'y': [1], 'z': [2]}
    if isinstance(dir_arg, str):
        requested = [char for char in dir_arg.lower() if char in mapping]
    elif isinstance(dir_arg, list):
        requested = [str(d).lower() for d in dir_arg if str(d).lower() in mapping]
    else:
        requested = ['x', 'y', 'z']
    if not requested: requested = ['x', 'y', 'z']
    indices = [mapping[d][0] for d in requested]
    scale_factor = 1.0 / (2.0 * len(indices))
    return indices, scale_factor, requested

def init_sm_worker(shared_buf, shape):
    """Initializer to rebuild the numpy view in each worker."""
    global _sm_shared
    _sm_shared['coords'] = np.frombuffer(shared_buf, dtype=np.float32).reshape(shape)

def compute_msd_fft_shared(atom_data, deltas):
    """FFT MSD for a slice of the shared array."""
    n_steps, n_particles, n_dims = atom_data.shape
    total_msd = np.zeros(len(deltas), dtype=float)

    for p in range(n_particles):
        disp = atom_data[:, p, :] - atom_data[0, p, :]
        fft_coords = np.fft.rfft(disp, n=2*n_steps, axis=0)
        acf = np.fft.irfft(fft_coords * np.conj(fft_coords), n=2*n_steps, axis=0)[:n_steps]
        Q = np.concatenate([np.zeros((1, n_dims)), np.cumsum(disp**2, axis=0)], axis=0)
        ssd = (Q[n_steps] - Q[deltas]) + (Q[n_steps - deltas] - 0) - 2*acf[deltas]
        total_msd += np.sum(ssd, axis=1)

    n_samples = n_steps - deltas
    return total_msd / n_samples

def process_pair_sm_msd_worker(args):
    """
    Worker for SM-MSD using indices to slice the global shared array.
    """
    sp_i, sp_j, slice_i, slice_j, dt_md, xi, xj, Ni, Nj, STEPS = args
    
    coords = _sm_shared['coords']
    n_steps = coords.shape[0]
    
    # Create views (Zero-Copy)
    data_i = coords[:, slice_i[0]:slice_i[1], :]
    data_j = coords[:, slice_j[0]:slice_j[1], :]
    
    deltas = np.arange(1, n_steps, STEPS)

    term_i = compute_msd_fft_shared(data_i, deltas)
    term_j = compute_msd_fft_shared(data_j, deltas)
    
    R_i = np.sum(data_i - data_i[0, :, :], axis=1)
    R_j = np.sum(data_j - data_j[0, :, :], axis=1)
    
    fft_i = np.fft.rfft(R_i, n=2*n_steps, axis=0)
    fft_j = np.fft.rfft(R_j, n=2*n_steps, axis=0)
    
    corr_ij = np.fft.irfft(fft_i * np.conj(fft_j), n=2*n_steps, axis=0)[:n_steps]
    corr_ji = np.fft.irfft(fft_j * np.conj(fft_i), n=2*n_steps, axis=0)[:n_steps]
    
    Q_ij = np.concatenate([np.zeros((1, R_i.shape[1])), np.cumsum(R_i * R_j, axis=0)], axis=0)
    cross_ss = (Q_ij[n_steps] - Q_ij[deltas]) + (Q_ij[n_steps - deltas] - 0) - (corr_ij[deltas] + corr_ji[deltas])
    
    term_cross = np.sum(cross_ss, axis=1) / (n_steps - deltas)
    
    msd_values = (xj**2 * term_i / Ni) + (xi**2 * term_j / Nj) - (2 * xi * xj * term_cross / (Ni * Nj))

    return sp_i, sp_j, pd.DataFrame({"delta": deltas * dt_md, "product": msd_values})

class UTIL_SMD(BaseAnalysis):
    def __init__(self, args):
        super().__init__(args)
        self.n_cores = self.args.n_cores
        self.util_diffusion = UTIL_DIFFUSION(args)

    def run_stefan_maxwell(self, COM_data, box_df, dt_md, species_counts, species_charges, volume_m3, temp_k, drift, wrap_requested, charge_requested):
        """
        Calculates Stefan-Maxwell diffusivity using COM_data and directional slicing.
        """
        all_species_names = list(species_counts.keys())
        charged_species = [s for s in all_species_names if abs(species_charges.get(s, 0)) > 1e-6]
        
        self.dir_indices, self.msd_scale, directions = get_dir_indices(self.args.DIR)
        dim = len(self.dir_indices)
        
        if not charged_species:
            self.log_message("WARNING", "No charged species found. Skipping Stefan-Maxwell.")
            return

        all_pairs = [p for p in combinations(all_species_names, 2) 
                     if not (p[0] not in charged_species and p[1] not in charged_species)]
        
        num_snapshots = COM_data.shape[0]
        total_mols = sum(species_counts.values())
        is_lammps = getattr(self.args, 'LAM', False)
        c_slice = slice(0, 3) if is_lammps else slice(1, 4)
        boxes = box_df[["Lx", "Ly", "Lz"]].values.astype(np.float32)

        total_elements = num_snapshots * total_mols * dim
        shared_buf = multiprocessing.RawArray(ctypes.c_float, total_elements)
        shared_arr = np.frombuffer(shared_buf, dtype=np.float32).reshape((num_snapshots, total_mols, dim))

        species_slices = {}
        current_offset = 0
        for name, count in species_counts.items():
            data = COM_data[:, current_offset : current_offset + count, c_slice].astype(np.float32)
            
            for m_idx in tqdm(range(count), desc=f"Unwrapping {name}", leave=False):
                mol_coords = data[:, m_idx, :]
                mol_coords = self.unwrap_on_the_fly(mol_coords, boxes)
                if drift is not None:
                    mol_coords -= drift
                
                shared_arr[:, current_offset + m_idx, :] = mol_coords[:, self.dir_indices]
            
            species_slices[name] = (current_offset, current_offset + count)
            current_offset += count

        args_list = []
        STEPS = getattr(self.args, 'steps', 1)
        for sp_i, sp_j in all_pairs:
            Ni, Nj = species_counts[sp_i], species_counts[sp_j]
            xi, xj = Ni / total_mols, Nj / total_mols
            args_list.append((sp_i, sp_j, species_slices[sp_i], species_slices[sp_j], dt_md, xi, xj, Ni, Nj, STEPS))

        msd_curves = {}
        self.generate_folders("results_stefan_maxwell")

        ctx = multiprocessing.get_context(self.args.get_context)
        init_args = (shared_buf, shared_arr.shape)
        
        with ctx.Pool(processes=self.n_cores, initializer=init_sm_worker, initargs=init_args) as pool:
            with tqdm(total=len(args_list), desc=f"SM-MSD ({''.join(directions)})", unit="pair") as pbar:
                for sp_i, sp_j, df in pool.imap_unordered(process_pair_sm_msd_worker, args_list):
                    if df is not None:
                        msd_curves[(sp_i, sp_j)] = df
                    pbar.set_postfix({"pair": f"{sp_i}-{sp_j}"})
                    pbar.update(1)

        gc.collect()

        msd_data_for_fitting = {pair: df[(df["delta"] > 0) & (df["product"] > 0)].reset_index(drop=True) 
                                for pair, df in msd_curves.items() if not df.empty}

        if not msd_data_for_fitting:
            self.log_message("ERROR", "No valid MSD data found for fitting.")
            return

        avg_diff, s_idx, e_idx = self.util_diffusion.find_best_time_window(msd_data_for_fitting, dt_md)
        
        dij_results, dij_errors = {}, {}
        physical_scale = self.msd_scale * 1e-8 # A^2 to m^2

        for pair, df in msd_data_for_fitting.items():
            df_win = df.iloc[s_idx:e_idx]
            if len(df_win) < 3: continue
            
            popt, pcov = np.polyfit(df_win["delta"], df_win["product"], 1, cov=True)
            dij_results[pair] = popt[0] * physical_scale
            dij_errors[pair] = np.sqrt(pcov[0,0]) * physical_scale
            df.to_csv(f"results_stefan_maxwell/sm_{pair[0]}_{pair[1]}.csv", index=False)

        d_matrix = {s: {} for s in all_species_names}
        for (sp_i, sp_j), val in dij_results.items():
            d_matrix[sp_i][sp_j] = d_matrix[sp_j][sp_i] = val

        concentrations = {s: (species_counts[s] / 6.022e23) / volume_m3 for s in all_species_names}
        kappa = self.compute_conductivity(all_species_names, species_charges, concentrations, d_matrix, temp_k)
        
        self.log_message("INFO", "\n" + "=" * 85) 
        self.log_message("INFO", f"Stefan-Maxwell Summary (Directions: {directions})")
        self.log_message("INFO", "=" * 85)
        self.log_message("INFO", f"{'Ionic Conductivity':<35} : {kappa:.4f} S/m")
        self.log_message("INFO", "-" * 85)
        
        summary_data = [{"Parameter": "Conductivity (S/m)", "Value": f"{kappa:.4f}", "Std_Error": "N/A"}]
        
        for pair in dij_results:
            val = dij_results[pair]
            err = dij_errors[pair]
            pair_name = f"D_{pair[0]}_{pair[1]}"
            self.log_message("INFO", f"{pair_name:<35} : {val/1e-11:.3f} ± {err/1e-11:.3f} (10⁻¹¹ m²/s)")
            summary_data.append({"Parameter": pair_name, "Value": f"{val:.3e}", "Std_Error": f"{err:.3e}"})
            
        self.log_message("INFO", "=" * 85 + "\n")
        pd.DataFrame(summary_data).to_csv("results_stefan_maxwell/stefan_maxwell_summary.csv", index=False)

    def compute_conductivity(self, species, charges, concentrations, d_matrix, temp_k):
        
        """
        Ionic conductivity using Stefan-Maxwell diffusivity.
        """
        F = const.physical_constants['Faraday constant'][0]
        R = const.R
    
        num_species = len(species)
        if num_species < 2:
            return 0.0
    
        z_vec = np.array([charges[s] for s in species])
        c_vec = np.array([concentrations[s] for s in species])
        
        # Calculate total concentration and mole fractions
        c_total = np.sum(c_vec)
        if c_total < 1e-9: # Avoid division by zero for empty systems
            return 0.0
        x_vec = c_vec / c_total
    
        # Build SM resistance matrix M'
        M_prime = np.zeros((num_species, num_species))
        for i in range(num_species - 1):
            species_i = species[i]
            diag_sum = 0
            for k in range(num_species):
                if i == k:
                    continue
                try:
                    D_ik = d_matrix[species_i][species[k]]
                except KeyError:
                    D_ik = d_matrix[species[k]][species_i]
                diag_sum += x_vec[k] / D_ik
            M_prime[i, i] = diag_sum
            for j in range(num_species):
                if i == j:
                    continue
                try:
                    D_ij = d_matrix[species_i][species[j]]
                except KeyError:
                    D_ij = d_matrix[species[j]][species_i]
                M_prime[i, j] = -x_vec[i] / D_ij
    
        M_prime[-1, :] = 1.0
    
        # Driving force vector
        d_prime = x_vec * z_vec
        d_prime[-1] = 0.0
    
        try:
            N_scaled = np.linalg.solve(M_prime, d_prime)
        except np.linalg.LinAlgError:
            self.log_message("WARNING","singular SM matrix")
            return 0.0
    
        kappa = c_total * (F**2 / (R * temp_k)) * np.dot(z_vec, N_scaled)
        
        return kappa