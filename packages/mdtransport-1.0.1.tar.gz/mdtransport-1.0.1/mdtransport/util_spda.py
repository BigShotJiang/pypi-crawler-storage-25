#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Wed Nov 19 15:21:36 2025

@author: Shah Research Group, Oklahoma State University <jindal.shah@okstate.edu>

MDTransport: GROMACS & LAMMPS Transport Analysis Tools
Copyright (C) 2026  Ashutosh Kumar Verma, Amey Thorat and Jindal Shah

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
"""

import ctypes
import numpy as np
import pandas as pd
import multiprocessing
from itertools import combinations_with_replacement
from collections import defaultdict
from .util import BaseAnalysis, tqdm
from .util_rdf import UTIL_RDF
from scipy.spatial import cKDTree
from scipy.signal import savgol_filter, find_peaks

_worker_data = None

def worker_init(shared_buffer, shape, times, box, species_map, cutoff_lookup, max_cutoff, n_species, max_dt, dir_indices):
    global _worker_data
    coords = np.frombuffer(shared_buffer, dtype=np.float32).reshape(shape)
    
    spec_indices = [np.where(species_map == s)[0] for s in range(n_species)]
    
    _worker_data = {
        'coords_unwrapped': coords, 
        'times': times,
        'box': box,
        'species_map': species_map,
        'spec_indices': spec_indices, 
        'cutoff_lookup': cutoff_lookup,
        'max_cutoff': max_cutoff,
        'n_species': n_species,
        'max_dt': max_dt,
        'dir_indices': dir_indices   
    }

def get_neighbors(pos_unwrapped, box_dims, species_map, cutoff_lookup, max_r):
    """Neighbor detection."""
    box_dims = np.asarray(box_dims, dtype=np.float64)
    pos_wrapped = pos_unwrapped % box_dims
    pos_wrapped[pos_wrapped >= box_dims] = 0.0

    pos_wrapped[pos_wrapped < 0.0] = 0.0
    tree = cKDTree(pos_wrapped, boxsize=box_dims)
    potential_pairs = tree.query_pairs(r=max_r, output_type='ndarray')

    if potential_pairs.size == 0:
        return np.empty((0, 2), dtype=np.int32)

    idx_i, idx_j = potential_pairs[:, 0], potential_pairs[:, 1]
    pair_cutoffs = cutoff_lookup[species_map[idx_i], species_map[idx_j]]
    
    diff = pos_wrapped[idx_i] - pos_wrapped[idx_j]
    diff -= box_dims * np.round(diff / box_dims)
    dist_sq = np.sum(diff**2, axis=1)
    
    return potential_pairs[dist_sq <= (pair_cutoffs**2)]

def compute_cross_correlation(t0_idx):
    """SPDA calculation."""
    d = _worker_data
    coords_unwrapped = d['coords_unwrapped']
    n_species = d['n_species']
    species_map = d['species_map']
    spec_indices = d['spec_indices']
    dir_indices = d['dir_indices']
    dim = len(dir_indices)
    
    num_total_steps = coords_unwrapped.shape[1]
    end_t_idx = min(t0_idx + d['max_dt'], num_total_steps)
    
    pos_t0 = coords_unwrapped[:, t0_idx, :]
    pos_t0_corr = pos_t0[:, dir_indices]
    pairs_t0 = get_neighbors(pos_t0, d['box'][t0_idx], species_map, d['cutoff_lookup'], d['max_cutoff'])

    packed_t0 = (pairs_t0[:, 0].astype(np.int64) << 32) | pairs_t0[:, 1]
    
    results = []

    for t_idx in range(t0_idx, end_t_idx):
        dt = d['times'][t_idx] - d['times'][t0_idx]
        pos_t = coords_unwrapped[:, t_idx, :]
        disp_t = (pos_t[:, dir_indices] - pos_t0_corr).astype(np.float64)
        
        spec_disp_sums = np.zeros((n_species, dim))
        spec_self_dot = np.zeros(n_species)
        for s in range(n_species):
            m_idx = spec_indices[s]
            s_disp = disp_t[m_idx]
            spec_disp_sums[s] = np.sum(s_disp, axis=0)
            spec_self_dot[s] = np.sum(s_disp**2)

        pairs_t = get_neighbors(pos_t, d['box'][t_idx], species_map, d['cutoff_lookup'], d['max_cutoff'])
        packed_t = (pairs_t[:, 0].astype(np.int64) << 32) | pairs_t[:, 1]

        is_in_t0 = np.isin(packed_t, packed_t0)
        is_in_t = np.isin(packed_t0, packed_t)

        stayed_in_packed = packed_t[is_in_t0]   
        entered_packed   = packed_t[~is_in_t0]  
        escaped_packed   = packed_t0[~is_in_t]  
        
        def get_category_sums(packed_array):
            sums = np.zeros((n_species, n_species))
            if packed_array.size == 0: return sums
            i_idx = (packed_array >> 32).astype(np.int32)
            j_idx = (packed_array & 0xFFFFFFFF).astype(np.int32)
            
            dots = np.sum(disp_t[i_idx] * disp_t[j_idx], axis=1)
            s_i, s_j = species_map[i_idx], species_map[j_idx]
            
            s_min, s_max = np.minimum(s_i, s_j), np.maximum(s_i, s_j)
            np.add.at(sums, (s_min, s_max), dots)
            return sums * 2.0

        dots_stayed_in = get_category_sums(stayed_in_packed)
        dots_escaped   = get_category_sums(escaped_packed)
        dots_entered   = get_category_sums(entered_packed)
        
        # Union = Stayed + Entered + Escaped
        dots_union = dots_stayed_in + dots_entered + dots_escaped

        f_sums = np.zeros((4, n_species, n_species))
        for s1 in range(n_species):
            for s2 in range(s1, n_species):
                if s1 == s2:
                    tot_cross = np.dot(spec_disp_sums[s1], spec_disp_sums[s1]) - spec_self_dot[s1]
                else:
                    tot_cross = 2.0 * np.dot(spec_disp_sums[s1], spec_disp_sums[s2])

                f_sums[0, s1, s2] = dots_stayed_in[s1, s2]
                f_sums[1, s1, s2] = tot_cross - dots_union[s1, s2] 
                f_sums[2, s1, s2] = dots_escaped[s1, s2]
                f_sums[3, s1, s2] = dots_entered[s1, s2]

        results.append((dt, f_sums))
    return results

class UTIL_SPDA(BaseAnalysis):
            
    """
    This is a UTIL_SPDA class which perform spatial decomposition analysis
    
    """
    def __init__(self, args):
                                
        """
        Initialize class with input arguments and class objects
        
        """
        super().__init__(args)
        self.util_rdf = UTIL_RDF(args)
        self.n_cores = self.args.n_cores

    def auto_calculate_rcuts(self, coords_unwrapped, boxes, charged_species, species_counts):
        """
        Calculates RDFs for all charged species pairs and extracts the 1st or 2nd solvation shell radius.
        """
        output_dir = "results_rdf"
        self.generate_folders(output_dir)
        
        sub_boxes = boxes[::self.args.steps]
        species_indices = {}
        current_pos = 0
        for s_name in charged_species:
            count = species_counts[s_name]
            species_indices[s_name] = slice(current_pos, current_pos + count)
            current_pos += count
    
        dr = getattr(self.args, 'RBIN', 0.02)
        r_max = np.min(boxes) / 2.0
        bins = np.arange(0, r_max + dr, dr)
        
        rcut_list = []
        shell_choice = (getattr(self.args, 'shell', None) or 'second').lower()
        
        for spec1, spec2 in combinations_with_replacement(charged_species, 2):
            self.log_message("INFO", f"Calculating RDF for {spec1}-{spec2} to find {shell_choice} shell...")
            
            d1_unwrapped = coords_unwrapped[species_indices[spec1], ::self.args.steps, :].transpose(1, 0, 2)
            d2_unwrapped = coords_unwrapped[species_indices[spec2], ::self.args.steps, :].transpose(1, 0, 2)
            
            d1_wrapped = d1_unwrapped % sub_boxes[:, np.newaxis, :]
            d2_wrapped = d2_unwrapped % sub_boxes[:, np.newaxis, :]
            
            pair_name = f"{spec1}-{spec2}"
            output_df = self.util_rdf.compute_and_save_rdf(
                d1_wrapped, d2_wrapped, sub_boxes, bins,
                is_same_species=(spec1 == spec2), 
                pair_name=pair_name,
                output_dir=output_dir, 
                frames_to_process=range(len(sub_boxes))
            )
            
            del d1_wrapped, d2_wrapped, d1_unwrapped, d2_unwrapped
            
            r_f = self.extract_solvation_radii_from_rdf(output_df, pair_name=pair_name)
            
            if r_f is not None:
                rcut_list.append(r_f)
            else:
                fallback = 10.0
                self.log_message("WARNING", f"Could not determine radius for {pair_name}. Using fallback {fallback} Å")
                rcut_list.append(fallback)
                
        return rcut_list

    def extract_solvation_radii_from_rdf(self, rdf_dataframe, pair_name="rdf"):
        """
        Extracts 1st or 2nd solvation shell radius by identifying successive peaks and minima in the RDF.
        """
        try:
            r = rdf_dataframe["r (Ang.)"].values
            g_r = rdf_dataframe["g_r"].values
            shell_choice = (getattr(self.args, 'shell', None) or 'second').lower()
    
            g_r_smooth = savgol_filter(g_r, window_length=11, polyorder=3) if len(g_r) > 15 else g_r
            peaks, _ = find_peaks(g_r_smooth, height=1.0, distance=10)
            
            if len(peaks) == 0:
                self.log_message("WARNING", f"No peaks found for {pair_name}. Fallback to 5.0Å")
                return 5.0
    
            found_minima = []
            p1_idx = peaks[0]

            if len(peaks) > 1:
                p2_idx = peaks[1]
                m1_relative = np.argmin(g_r_smooth[p1_idx:p2_idx])
                found_minima.append(r[p1_idx + m1_relative])
                
                search_end = peaks[2] if len(peaks) > 2 else len(r)
                m2_relative = np.argmin(g_r_smooth[p2_idx:search_end])
                found_minima.append(r[p2_idx + m2_relative])
            else:
                m1_relative = np.argmin(g_r_smooth[p1_idx:])
                found_minima.append(r[p1_idx + m1_relative])
    
            if shell_choice == 'first':
                result_radius = found_minima[0]
            else:
                if len(found_minima) >= 2:
                    result_radius = found_minima[1]
                else:
                    result_radius = found_minima[0]
                    self.log_message("WARNING", f"Second shell not detectable for {pair_name}. Using first shell ({result_radius:.2f}Å).")
    
            self.log_message("INFO", f"  > {pair_name}: {shell_choice} shell boundary at {result_radius:.2f} Å")
            return result_radius
    
        except Exception as e:
            self.log_message("ERROR", f"Failed to extract shell for {pair_name}: {e}")
            self.log_message("WARNING", "Taking rcut value equal to 7.5.")
            return 7.5

    def run_spatial_decomposition_analysis(self, COM_data, box_df, species_counts, species_charges, dt_md, K_multi, n_delta, drift, wrap_requested, charge_requested):
        
        """
        Function to perform spatial decomposition analysis from data.
        """
        dir_mapping = {"x": 0, "y": 1, "z": 2}
        directions = list(self.args.DIR) if (hasattr(self.args, 'DIR') and self.args.DIR) else ["x", "y", "z"]
        dim = len(directions)
        dir_indices = [dir_mapping[d.lower()] for d in directions if d.lower() in dir_mapping]
        
        all_species = list(species_counts.keys())
        charged_species = [s for s in all_species if species_charges.get(s, 0) != 0]
        n_species = len(charged_species)

        num_snapshots = COM_data.shape[0]
        is_lammps = getattr(self.args, 'LAM', False)
        c_slice = slice(0, 3) if is_lammps else slice(1, 4)
        boxes = box_df[["Lx", "Ly", "Lz"]].values.astype(np.float32)

        total_charged_mols = sum(species_counts[s] for s in charged_species)
        
        total_elements = total_charged_mols * num_snapshots * 3
        shared_buffer = multiprocessing.RawArray(ctypes.c_float, total_elements)
        coords_unwrapped = np.frombuffer(shared_buffer, dtype=np.float32).reshape((total_charged_mols, num_snapshots, 3))

        mol_ptr = 0
        current_offset = 0
        for name in all_species:
            count = species_counts[name]
            if name in charged_species:
                raw_slice = COM_data[:, current_offset : current_offset + count, c_slice]
                for m_idx in range(count):
                    m_coords = raw_slice[:, m_idx, :].astype(np.float32)
                    unwrapped = self.unwrap_on_the_fly(m_coords, boxes)
                    if drift is not None:
                        unwrapped -= drift
                    
                    coords_unwrapped[mol_ptr] = unwrapped
                    mol_ptr += 1
            current_offset += count

        if self.args.RCUT:
            rcut_values = [float(x) for x in self.args.RCUT]
        else:
            rcut_values = self.auto_calculate_rcuts(coords_unwrapped, boxes, charged_species, species_counts)

        cutoff_lookup = np.zeros((n_species, n_species))
        rc_idx = 0
        for s1 in range(n_species):
            for s2 in range(s1, n_species):
                val = rcut_values[rc_idx] if rc_idx < len(rcut_values) else rcut_values[-1]
                cutoff_lookup[s1, s2] = cutoff_lookup[s2, s1] = val
                rc_idx += 1

        max_dt = min(num_snapshots, int(n_delta / dt_md + 1))
        species_map = np.concatenate([np.full(species_counts[s], i) for i, s in enumerate(charged_species)])

        init_args = (
            shared_buffer, 
            coords_unwrapped.shape,
            np.arange(num_snapshots) * dt_md,
            boxes,
            species_map,
            cutoff_lookup,
            np.max(cutoff_lookup),
            n_species,
            max_dt,
            dir_indices
        )

        t0_indices = range(0, num_snapshots, int(self.args.steps))
        agg_msd_sum = defaultdict(lambda: np.zeros((4, n_species, n_species)))
        agg_origins_cnt = defaultdict(int)

        ctx = multiprocessing.get_context(self.args.get_context)
        with ctx.Pool(processes=self.n_cores, initializer=worker_init, initargs=init_args) as pool:
            for t0_results in tqdm(pool.imap_unordered(compute_cross_correlation, t0_indices), 
                                  total=len(t0_indices), desc="Decomposing Cross-Correlation"):
                for dt, f_sums in t0_results:
                    dtr = round(dt, 4)
                    agg_msd_sum[dtr] += f_sums
                    agg_origins_cnt[dtr] += 1

        folder = "results_spatial_decomposition"
        self.generate_folders(folder)
        time_multiplier = dt_md if self.args.LAM else 1.0 
        max_idx = int(self.args.t_window / dt_md + 1)
        sorted_dts = sorted(agg_msd_sum.keys())

        final_summary_int = []
        final_summary_init = []
        
        for s1 in range(n_species):
            q1 = species_charges[charged_species[s1]]
            for s2 in range(s1, n_species):
                q2 = species_charges[charged_species[s2]]
                pair_label = f"{charged_species[s1]}_{charged_species[s2]}"
                charge_prod = q1 * q2
                scaling_factor = charge_prod * K_multi / dim

                sigmas = {}
                sigma_errs = {}
                file_names = ["stayed_in", "stayed_out", "escaped", "entered"]
                
                for cat_idx, cat_name in enumerate(file_names):
                    t_vals, msd_vals = [], []
                    for dt_val in sorted_dts:
                        n_orig = agg_origins_cnt[dt_val]
                        avg_val = agg_msd_sum[dt_val][cat_idx, s1, s2] / n_orig
                        t_vals.append(dt_val * time_multiplier)
                        msd_vals.append(avg_val)
                    
                    pd.DataFrame({"t": t_vals, "msd": msd_vals}).to_csv(f"{folder}/{cat_name}_{pair_label}.csv", index=False)
                    
                    if len(msd_vals) > 2: 
                        end = min(len(msd_vals), max_idx)
                        x, y = np.array(t_vals[1:end]), np.array(msd_vals[1:end])
                        
                        popt, pcov = np.polyfit(x, y, 1, cov=True)
                        slope = popt[0]
                        stderr = np.sqrt(pcov[0,0])
                        
                        sigmas[cat_name] = slope * scaling_factor
                        sigma_errs[cat_name] = stderr * abs(scaling_factor)
                    else:
                        sigmas[cat_name] = 0.0
                        sigma_errs[cat_name] = 0.0

                def get_combined_error(keys):
                    return np.sqrt(sum(sigma_errs[k]**2 for k in keys))

                sigma_total = sum(sigmas.values())
                err_total = get_combined_error(file_names)
                
                sigma_exchange = sigmas["escaped"] + sigmas["entered"]
                err_exchange = get_combined_error(["escaped", "entered"])
                
                sigma_stayed_in_init = sigmas["stayed_in"] + sigmas["escaped"]
                err_stayed_in_init = get_combined_error(["stayed_in", "escaped"])
                
                sigma_stayed_out_init = sigmas["stayed_out"] + sigmas["entered"]
                err_stayed_out_init = get_combined_error(["stayed_out", "entered"])

                def fmt(val, err): return f"{val:.3f} ± {err:.3f}"

                final_summary_int.append({
                    "Pairs": pair_label,
                    "Total (S/m)": fmt(sigma_total, err_total),
                    "Stayed-in (S/m)": fmt(sigmas['stayed_in'], sigma_errs['stayed_in']),
                    "Exchange (S/m)": fmt(sigma_exchange, err_exchange),
                    "Stayed-out (S/m)": fmt(sigmas['stayed_out'], sigma_errs['stayed_out'])
                })
                
                final_summary_init.append({
                    "Pairs": pair_label,
                    "Total (S/m)": fmt(sigma_total, err_total),
                    "Stayed-in (S/m)": fmt(sigma_stayed_in_init, err_stayed_in_init),
                    "Stayed-out (S/m)": fmt(sigma_stayed_out_init, err_stayed_out_init)
                })

        for summary_data, label, filename in [
            (final_summary_int, "Spatial Decomposition Summary (Intermittent)", "summary_spatial_decomposition_intermittent.csv"),
            (final_summary_init, "Spatial Decomposition Summary (Initial)", "summary_spatial_decomposition_initial.csv")
        ]:
            df = pd.DataFrame(summary_data)
            df.to_csv(f"{folder}/{filename}", index=False)
            
            summary_str = df.to_string(index=False)
            max_width = max(max(len(line) for line in summary_str.splitlines()), len(label) + 2)
            separator = "=" * max_width
            
            self.log_message("INFO", "\n" + separator)
            self.log_message("INFO", label.center(max_width))
            self.log_message("INFO", separator)
            self.log_message("INFO", summary_str)
            self.log_message("INFO", separator + "\n")
        
        return