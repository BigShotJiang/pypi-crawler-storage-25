#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Wed Nov 19 15:21:36 2025

@author: Shah Research Group, Oklahoma State University <jindal.shah@okstate.edu>

MDTransport: GROMACS & LAMMPS Transport Analysis Tools
Copyright (C) 2026  Ashutosh Kumar Verma, Amey Thorat and Jindal Shah

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
"""
import os
import re
import gc
import sys
import mmap
import ctypes 
import warnings
import pandas as pd
import numpy as np
from functools import partial
import multiprocessing
from collections import defaultdict
from .util import BaseAnalysis, tqdm

# Global variable to hold the shared memory reference in each worker process
worker_shared_buffer = None
worker_shared_shape = None
worker_universe = None
worker_valid_atoms = None 
worker_trajectory = None
worker_kept_atom_indices = None
worker_atom_masses = None
worker_mol_ids = None
worker_pipeline = None
worker_kept_idx = None
worker_masses = None
worker_unique_mols = None
worker_start_indices = None
worker_mol_indices = None
worker_n_mols = None
worker_mol_mass_sum = None
worker_pdb_file_handle = None
worker_atom_mask = None
worker_atom_masses = None
worker_current_pos = None

def init_worker_mda(shared_buffer, shape, tpr_file, traj_file, sel_str):
    """Initializes the shared memory and MDAnalysis Universe ONCE per worker."""
    global worker_shared_buffer, worker_shared_shape
    global worker_universe, worker_valid_atoms
    import MDAnalysis as mda
    
    worker_shared_buffer = shared_buffer
    worker_shared_shape = shape
    worker_universe = mda.Universe(tpr_file, traj_file)
    worker_valid_atoms = worker_universe.select_atoms(sel_str)

def init_worker_chemfiles(shared_buffer, shape, traj_path, kept_atom_indices, atom_masses, mol_ids, mol_mass_divisor, start_indices):
    """Initializes shared memory and opens file once per worker."""
    global worker_shared_buffer, worker_shared_shape, worker_trajectory
    global worker_kept_atom_indices, worker_atom_masses, worker_mol_ids, worker_mol_mass_divisor, worker_start_indices
    import chemfiles
    
    worker_shared_buffer = shared_buffer
    worker_shared_shape = shape
    worker_trajectory = chemfiles.Trajectory(traj_path, 'r')
    worker_kept_atom_indices = kept_atom_indices
    worker_atom_masses = atom_masses
    worker_mol_ids = mol_ids
    worker_mol_mass_divisor = mol_mass_divisor
    worker_start_indices = start_indices

def init_worker_pdb(shared_buffer, shape, pdb_file, n_atoms_per_frame, atom_mask, atom_masses, mol_indices):
    """Initializes shared memory, file handles, and static arrays ONCE per worker."""
    global worker_shared_buffer, worker_shared_shape, worker_pdb_file_handle
    global worker_atom_mask, worker_atom_masses, worker_mol_indices, worker_current_pos
    
    worker_shared_buffer = shared_buffer
    worker_shared_shape = shape
    worker_pdb_file_handle = open(pdb_file, 'rb')
    worker_atom_mask = atom_mask
    worker_atom_masses = atom_masses
    worker_mol_indices = mol_indices
    worker_current_pos = np.zeros((n_atoms_per_frame, 3), dtype=np.float32)
    
def init_worker_ovito(shared_buffer, shape, traj_path, kept_idx, masses, mol_ids, return_atoms):
    """Initializes shared memory, OVITO pipeline, and pre-computes COM arrays ONCE per worker."""
    global worker_shared_buffer, worker_shared_shape, worker_pipeline
    global worker_kept_idx, worker_masses, worker_mol_ids
    global worker_unique_mols, worker_start_indices, worker_mol_indices, worker_n_mols, worker_mol_mass_sum
    
    import warnings
    warnings.filterwarnings("ignore", category=UserWarning)
    from ovito.io import import_file
    
    worker_shared_buffer = shared_buffer
    worker_shared_shape = shape
    
    worker_pipeline = import_file(traj_path)
    
    worker_kept_idx = kept_idx
    worker_masses = masses.astype(np.float32, copy=False) if masses is not None else None
    worker_mol_ids = mol_ids
    
    if not return_atoms and mol_ids is not None:
        worker_unique_mols, worker_start_indices, worker_mol_indices = np.unique(
            worker_mol_ids, return_index=True, return_inverse=True
        )
        worker_n_mols = len(worker_unique_mols)
        worker_mol_mass_sum = np.bincount(worker_mol_indices, weights=worker_masses)
        
def calculate_com_pbc(positions, masses, mol_ids, box_lengths):
    """
    Computes COM by applying PBC. 
    """
    pos = positions.astype(np.float32, copy=False)
    box_arr = np.array(box_lengths, dtype=np.float32)

    unique_mols, start_indices, mol_indices = np.unique(
        mol_ids, return_index=True, return_inverse=True
    )
    n_mols = len(unique_mols)
    
    ref_pos_expanded = pos[start_indices[mol_indices]]
    
    delta = pos - ref_pos_expanded
    delta -= box_arr * np.round(delta / box_arr)
    unwrapped_pos = ref_pos_expanded + delta
    
    weighted_pos = unwrapped_pos * masses[:, None]
    
    mol_mass_sum = np.bincount(mol_indices, weights=masses)
    
    coms = np.empty((n_mols, 3), dtype=np.float64)
    coms[:, 0] = np.bincount(mol_indices, weights=weighted_pos[:, 0])
    coms[:, 1] = np.bincount(mol_indices, weights=weighted_pos[:, 1])
    coms[:, 2] = np.bincount(mol_indices, weights=weighted_pos[:, 2])

    coms /= mol_mass_sum[:, None]
    
    return unique_mols, coms
    
def process_mdanalysis(task_info, return_atoms=False):
    """
    Processes a chunk of frames using MDAnalysis.
    """
    (chunk_start, chunk_stop, step, chunk_col_indices, 
     data_mode, mmap_opts, dt_pdb, atom_masses, mol_indices) = task_info
    
    global worker_shared_buffer, worker_shared_shape
    global worker_universe, worker_valid_atoms

    if data_mode == "disk":
        target_arr = np.memmap(mmap_opts['filename'], dtype=np.float32, mode='r+', shape=mmap_opts['shape'])
    else:
        target_arr = np.frombuffer(worker_shared_buffer, dtype=np.float32).reshape(worker_shared_shape)

    num_chunk_frames = len(chunk_col_indices)
    metadata_chunk = np.zeros((num_chunk_frames, 5), dtype=np.float32)

    traj_slice = worker_universe.trajectory[chunk_start:chunk_stop:step]
    
    for i, ts in enumerate(traj_slice):
        col_idx = chunk_col_indices[i]
        dims = ts.dimensions[:3]
        time_val_scaled = ts.time * dt_pdb
        
        if return_atoms:
            # np.copyto is slightly faster and more memory efficient than direct assignment
            np.copyto(target_arr[col_idx], worker_valid_atoms.positions)
        else:
            curr_indices, data = calculate_com_pbc(
                worker_valid_atoms.positions, atom_masses, mol_indices, dims
            )
            target_arr[col_idx, curr_indices, 0] = time_val_scaled
            target_arr[col_idx, curr_indices, 1:4] = data
        
        metadata_chunk[i] = [col_idx, time_val_scaled, dims[0], dims[1], dims[2]]
    
    if data_mode == "disk": 
        del target_arr

    return metadata_chunk

def process_chemfiles(task_info, return_atoms=False):
    """Processes frames with sequential read optimization and fast array math."""
    (first_frame, step_stride, chunk_col_indices, data_mode, mmap_opts, dt_pdb, t0, dt_traj) = task_info
    global worker_shared_buffer, worker_shared_shape, worker_trajectory
    global worker_kept_atom_indices, worker_atom_masses, worker_mol_ids, worker_mol_mass_divisor, worker_start_indices
    
    if data_mode == "disk":
        target_arr = np.memmap(mmap_opts['filename'], dtype=np.float32, mode='r+', shape=mmap_opts['shape'])
    else:
        target_arr = np.frombuffer(worker_shared_buffer, dtype=np.float32).reshape(worker_shared_shape)

    num_chunk_frames = len(chunk_col_indices)
    metadata_chunk = np.zeros((num_chunk_frames, 5), dtype=np.float32)

    for i, col_idx in enumerate(chunk_col_indices):
        step_i = first_frame + i * step_stride
        
        if i == 0 or step_stride > 1:
            frame = worker_trajectory.read_step(step_i)
        else:
            frame = worker_trajectory.read()
            
        scaled_t = (t0 + step_i * dt_traj) * dt_pdb
        
        lens = np.array(frame.cell.lengths, dtype=np.float32)
        if lens[0] < 1e-5: lens[:] = 100.0 
        
        pos = frame.positions[worker_kept_atom_indices].astype(np.float32)
        del frame  
        
        if return_atoms:
            np.copyto(target_arr[col_idx], pos)
        else:
            ref_pos = pos[worker_start_indices][worker_mol_ids]
            delta = np.subtract(pos, ref_pos)
            
            np.divide(delta, lens, out=delta)
            np.round(delta, out=delta)
            np.multiply(delta, lens, out=delta)
            
            np.subtract(pos, delta, out=pos)
            np.multiply(pos, worker_atom_masses, out=pos)
            
            n_mols = len(worker_mol_mass_divisor)
            mol_wpos_sum = np.zeros((n_mols, 3), dtype=np.float32)
            
            for d in range(3):
                np.add.at(mol_wpos_sum[:, d], worker_mol_ids, pos[:, d])
            
            target_arr[col_idx, :, 0] = scaled_t
            np.divide(mol_wpos_sum, worker_mol_mass_divisor, out=mol_wpos_sum)
            target_arr[col_idx, :, 1:4] = mol_wpos_sum

        metadata_chunk[i] = [col_idx, scaled_t, lens[0], lens[1], lens[2]]
            
    if data_mode == "disk": del target_arr
    return metadata_chunk

def process_pdb(task_info, return_atoms=False):
    """
    Processes a chunk of frames using PDB parser.
    """
    (frame_offsets, col_indices, data_mode, mmap_opts) = task_info

    global worker_shared_buffer, worker_shared_shape, worker_pdb_file_handle
    global worker_atom_mask, worker_atom_masses, worker_mol_indices, worker_current_pos

    if data_mode == "disk":
        target_arr = np.memmap(
            mmap_opts['filename'], 
            dtype=mmap_opts['dtype'], 
            mode='r+', 
            shape=mmap_opts['shape']
        )
    else:
        target_arr = np.frombuffer(worker_shared_buffer, dtype=np.float32).reshape(worker_shared_shape)

    num_chunk_frames = len(col_indices)
    metadata_chunk = np.zeros((num_chunk_frames, 5), dtype=np.float32)

    f = worker_pdb_file_handle
    current_pos = worker_current_pos
    n_atoms_per_frame = current_pos.shape[0]
    
    for i, ((start_byte, end_byte), col_idx) in enumerate(zip(frame_offsets, col_indices)):
        f.seek(start_byte)
        frame_bytes = f.read(end_byte - start_byte)
        
        atom_cursor, current_t, current_box = 0, 0.0, np.zeros(3, dtype=np.float32)
        
        for line in frame_bytes.split(b'\n'):
            if line.startswith(b"ATOM") or line.startswith(b"HETATM"):
                if atom_cursor < n_atoms_per_frame:
                    current_pos[atom_cursor, 0] = float(line[30:38])
                    current_pos[atom_cursor, 1] = float(line[38:46])
                    current_pos[atom_cursor, 2] = float(line[46:54])
                    atom_cursor += 1
            elif line.startswith(b"TITLE"):
                idx = line.find(b"t=")
                if idx != -1:
                    try: current_t = float(line[idx+2:].split()[0])
                    except: pass
            elif line.startswith(b"CRYST1"):
                try:
                    current_box[0] = float(line[6:15])
                    current_box[1] = float(line[15:24])
                    current_box[2] = float(line[24:33])
                except: pass
        
        pos_filtered = current_pos[worker_atom_mask]
        
        if return_atoms:
            np.copyto(target_arr[col_idx], pos_filtered)
        else:
            u_mols, data = calculate_com_pbc(pos_filtered, worker_atom_masses, worker_mol_indices, current_box)
            target_arr[col_idx, :, 0] = current_t
            target_arr[col_idx, :, 1:4] = data

        metadata_chunk[i] = [col_idx, current_t, current_box[0], current_box[1], current_box[2]]
                
    if data_mode == "disk": del target_arr
    
    return metadata_chunk

def process_ovito(task_info, return_atoms=False):
    """
    Processes a chunk of frames using OVITO.
    """
    frame_indices, offset, dt_traj, dt_pdb, data_mode, mmap_opts = task_info

    global worker_shared_buffer, worker_shared_shape, worker_pipeline
    global worker_kept_idx, worker_masses, worker_mol_ids
    global worker_unique_mols, worker_start_indices, worker_mol_indices, worker_n_mols, worker_mol_mass_sum

    if data_mode == "disk":
        target_arr = np.memmap(mmap_opts['filename'], dtype=np.float32, mode='r+', shape=mmap_opts['shape'])
    else:
        target_arr = np.frombuffer(worker_shared_buffer, dtype=np.float32).reshape(worker_shared_shape)

    num_local = len(frame_indices)
    metadata_chunk = np.zeros((num_local, 5), dtype=np.float32)

    for i, f_idx in enumerate(frame_indices):
        data = worker_pipeline.compute(f_idx)
        global_idx = offset + i
        
        pos = np.asarray(data.particles.positions)[worker_kept_idx].astype(np.float32, copy=False)
        time_ps = data.attributes.get("Time", float(f_idx * dt_traj)) * dt_pdb
        
        cell_matrix = np.array(data.cell, copy=False)
        lens = np.array([
            np.linalg.norm(cell_matrix[:, 0]),
            np.linalg.norm(cell_matrix[:, 1]),
            np.linalg.norm(cell_matrix[:, 2])
        ], dtype=np.float32)
        
        if return_atoms:
            np.copyto(target_arr[global_idx], pos)
        else:
            ref_pos_expanded = pos[worker_start_indices[worker_mol_indices]]
            delta = pos - ref_pos_expanded
            delta -= lens * np.round(delta / lens)
            unwrapped_pos = ref_pos_expanded + delta
            weighted_pos = unwrapped_pos * worker_masses[:, None]
            
            coms = np.empty((worker_n_mols, 3), dtype=np.float32)
            for d in range(3):
                coms[:, d] = np.bincount(worker_mol_indices, weights=weighted_pos[:, d])
            coms /= worker_mol_mass_sum[:, None]
            
            target_arr[global_idx, worker_unique_mols, 0] = time_ps
            target_arr[global_idx, worker_unique_mols, 1:] = coms
        
        metadata_chunk[i] = [global_idx, time_ps, lens[0], lens[1], lens[2]]

    if data_mode == "disk": del target_arr

    return metadata_chunk

def create_array_backend(filename, shape, dtype, mode, data_mode):
    if data_mode == "disk":
        arr = np.memmap(filename, dtype=dtype, mode=mode, shape=shape)
        return arr
    else:
        if mode == "w+" or mode == "r+":
            return np.zeros(shape, dtype=dtype)
        elif mode == "full_nan":
            arr = np.empty(shape, dtype=dtype)
            arr[:] = np.nan
            return arr
        
class UTIL_GROMACS(BaseAnalysis):
        
    """
    This is a UTIL_GROMACS class which extract species data for GROMACS analysis
    
    """
    def __init__(self, args):
                        
        """
        Initialize class with input arguments and class objects
        
        """
        super().__init__(args)
        self.n_cores = self.args.n_cores
            
    def calculate_charges_from_itp_files(self, directory):
        
        """
        Function to extracts charges and masses from ITP files.
        """
        if not os.path.isdir(directory):
            self.log_message("ERROR", f"The directory {directory} does not exist.")
            return pd.DataFrame(), {}, {}
    
        # Build a comprehensive library of atomtype masses
        atomtype_mass_library = {}
        for filename in os.listdir(directory):
            if not filename.endswith(".itp"): continue
            filepath = os.path.join(directory, filename)
            try:
                with open(filepath, "r") as file:
                    in_atomtypes = False
                    for line in file:
                        line = line.strip()
                        if not line or line.startswith(";"): continue
                        if line.startswith("["):
                            in_atomtypes = "atomtypes" in line.lower()
                            continue
                        if in_atomtypes:
                            parts = line.split()
                            if len(parts) >= 2:
                                try:
                                    mass_val = float(parts[2]) if len(parts) > 2 else float(parts[1])
                                    atomtype_mass_library[parts[0]] = mass_val
                                except (ValueError, IndexError): pass
            except Exception as e:
                self.log_message("WARNING", f"Error parsing atomtypes in {filename}: {e}")
    
        # Parse Atoms and Molecule structure
        all_atoms_data = []
        for filename in os.listdir(directory):
            if not filename.endswith(".itp"): continue
            filepath = os.path.join(directory, filename)
            try:
                with open(filepath, "r") as file:
                    current_mol_name = "unknown"
                    in_atoms = False
                    in_moltype = False
                    
                    for line in file:
                        line = line.strip()
                        if not line or line.startswith(";"): continue
                        
                        if line.startswith("["):
                            in_moltype = "moleculetype" in line.lower()
                            in_atoms = "atoms" in line.lower()
                            continue
    
                        if in_moltype:
                            current_mol_name = line.split()[0]
                            in_moltype = False
                            continue
    
                        if in_atoms:
                            parts = line.split()
                            if len(parts) < 7: continue
                            
                            # ITP Column indices: 0:nr, 1:type, 2:resnr, 3:resname, 4:atom, 5:cgnr, 6:charge, 7:mass
                            atom_type = parts[1]
                            res_nr    = parts[2]
                            res_name  = parts[3]
                            atom_name = parts[4]
                            charge    = float(parts[6])
                            
                            # Get Mass
                            try:
                                mass = float(parts[7])
                            except (IndexError, ValueError):
                                mass = atomtype_mass_library.get(atom_type, 1.0)
    
                            all_atoms_data.append({
                                "mol_name": current_mol_name,
                                "res_nr": res_nr,
                                "res_name": res_name,
                                "atom": atom_name,
                                "type": atom_type,
                                "q": charge,
                                "mass": mass,
                            })
            except Exception as e:
                self.log_message("ERROR", f"Failed to process {filename}: {e}")
    
        if not all_atoms_data:
            return pd.DataFrame(), {}, {}
    
        df = pd.DataFrame(all_atoms_data)
        
        # First, calculate the total charge/mass of every unique residue instance
        res_instances = df.groupby(["mol_name", "res_nr", "res_name"]).agg({
            "q": "sum",
            "mass": "sum"
        }).reset_index()
    
        # Pick the FIRST occurrence of each residue name as the representative.
        species_charges = res_instances.groupby("res_name")["q"].first().to_dict()
        species_mass = res_instances.groupby("res_name")["mass"].first().to_dict()
        df["res_name"] = df["res_name"].str[:4]
    
        return df, species_charges, species_mass

    def calculate_charges(self, input_file):
                                            
        """
        Function to extract charges from GROMACS dump file
        
        """
        if not os.path.exists(input_file):
            self.log_message("ERROR", f"Input file {input_file} not found.")
            return pd.DataFrame(), {}, {}
    
        all_atoms_data = []
        current_mol_atoms = {}
        current_res_map = {}
        current_mol_name = "unknown"
    
        def flush_moltype_data():
            if current_mol_atoms:
                for idx in sorted(current_mol_atoms.keys()):
                    atom_info = current_mol_atoms[idx]
                    res_idx = atom_info.get('resind', 0)
                    atom_info['res_name'] = current_res_map.get(res_idx, "UNKNOWN")
                    atom_info['mol_name'] = current_mol_name
                    
                    for key in ["atom", "type", "q", "mass"]:
                        if key not in atom_info: atom_info[key] = None
                            
                    all_atoms_data.append(atom_info)
    
        try:
            with open(input_file, "r") as f:
                for line in f:
                    line = line.strip()
                    if line.startswith("moltype ("):
                        flush_moltype_data()
                        current_mol_atoms = {}
                        current_res_map = {}
                        continue
                    
                    if line.startswith('name="'):
                        m = re.search(r'name="([^"]+)"', line)
                        if m: current_mol_name = m.group(1)
                        continue
    
                    num_match = re.search(
                        r"atom\[\s*(\d+)\s*\].*m=\s*([-\d.e+]+).*q=\s*([-\d.e+]+).*resind=\s*(\d+)", 
                        line
                    )
                    if num_match:
                        idx = int(num_match.group(1))
                        if idx not in current_mol_atoms: current_mol_atoms[idx] = {}
                        current_mol_atoms[idx].update({
                            "mass": float(num_match.group(2)), 
                            "q": float(num_match.group(3)), 
                            "resind": int(num_match.group(4))
                        })
                        continue
    
                    name_match = re.search(r'atom\[\s*(\d+)\s*\]={name="([^"]+)"}', line)
                    if name_match:
                        idx = int(name_match.group(1))
                        if idx not in current_mol_atoms: current_mol_atoms[idx] = {}
                        current_mol_atoms[idx]["atom"] = name_match.group(2)
                        continue
    
                    type_match = re.search(r'type\[\s*(\d+)\s*\]={name="([^"]+)"', line)
                    if type_match:
                        idx = int(type_match.group(1))
                        if idx not in current_mol_atoms: current_mol_atoms[idx] = {}
                        current_mol_atoms[idx]["type"] = type_match.group(2)
                        continue
    
                    res_match = re.search(r'residue\[\s*(\d+)\s*\]={name="([^"]+)"', line)
                    if res_match:
                        current_res_map[int(res_match.group(1))] = res_match.group(2)
                        continue
    
                flush_moltype_data()
        except Exception as e:
            self.log_message("ERROR", f"Failed to process file: {e}")
            return pd.DataFrame(), {}, {}
    
        if not all_atoms_data:
            return pd.DataFrame(), {}, {}
    
        df = pd.DataFrame(all_atoms_data)
    
        # Sum atoms by residue index to get total charge of each individual residue instance
        res_instances = df.groupby(["mol_name", "resind", "res_name"]).agg({
            "q": "sum", 
            "mass": "sum"
        }).reset_index()
    
        # Pick the FIRST occurrence of each residue name
        species_charges = res_instances.groupby("res_name")["q"].first().to_dict()
        species_mass = res_instances.groupby("res_name")["mass"].first().to_dict()
    
        return df, species_charges, species_mass

    def unwrap_trajectory(self, com_df, box_df):
                                    
        """
        Function to unwrap trajectory
        
        """
        df = com_df.sort_values("t").reset_index(drop=True)
        box_info = box_df.sort_values("t").reset_index(drop=True)

        # Merge to get box dimensions for each timestep
        merged_df = pd.merge(df, box_info[["t", "Lx", "Ly", "Lz"]], on="t", how="left")

        coords = merged_df[["xu", "yu", "zu"]].values
        box_lengths_np = merged_df[["Lx", "Ly", "Lz"]].values

        # Calculate displacements between consecutive frames
        displacements = np.diff(coords, axis=0, prepend=coords[0:1])
        half_box = box_lengths_np / 2.0

        # Detect jumps across periodic boundaries
        image_jumps = np.zeros_like(displacements, dtype=int)
        image_jumps[displacements < -half_box] = 1
        image_jumps[displacements > half_box] = -1

        # Cumulatively sum jumps to get the correct image flag
        image_flags = np.cumsum(image_jumps, axis=0)

        # Apply correction to get unwrapped coordinates
        unwrapped_coords = coords + image_flags * box_lengths_np

        merged_df[["xu", "yu", "zu"]] = unwrapped_coords
        return merged_df

    def wrap_trajectory(self, com_df, box_df):
                                            
        """
        Function to wrap trajectory
        
        """
        df = com_df.sort_values("t").reset_index(drop=True)
        box_info = box_df.sort_values("t").reset_index(drop=True)

        merged_df = pd.merge(df, box_info[["t", "Lx", "Ly", "Lz"]], on="t", how="left")
        merged_df[["Lx", "Ly", "Lz"]] = merged_df[["Lx", "Ly", "Lz"]].ffill().bfill()

        coords = merged_df[["xu", "yu", "zu"]].values
        box_lengths_np = merged_df[["Lx", "Ly", "Lz"]].values

        # Use modulo operator to wrap coordinates into [0, L)
        wrapped_coords = coords % box_lengths_np

        merged_df[["xu", "yu", "zu"]] = wrapped_coords
        return merged_df

    def get_mappings_from_snapshot(self, snapshot_lines):
        
        """Creates molecule ID and species count maps from a single snapshot."""

        atom_lines = [l for l in snapshot_lines if l.startswith("ATOM") or l.startswith("HETATM")]
        if not atom_lines:
            return {}, [], {}
        data = {"res_name": [l[17:20].strip() for l in atom_lines], "res_id": [int(l[22:26]) for l in atom_lines]}
        df = pd.DataFrame(data)
        df["mol_key"] = list(zip(df["res_name"], df["res_id"]))
        # Get species order based on first appearance
        pdb_species_order = list(df["res_name"].unique())
        # Get molecule order based on first appearance
        unique_mol_keys = list(df["mol_key"].unique())
        # The mol_id_map is a map from (resname, resid) -> unique index
        mol_id_map = {key: i for i, key in enumerate(unique_mol_keys)}
        # Get counts for each species
        temp_df = df.drop_duplicates(subset=["mol_key"])
        species_counts = temp_df["res_name"].value_counts().to_dict()
        # Ensure counts dictionary follows the species order
        species_counts = {k: species_counts.get(k, 0) for k in pdb_species_order}
        return mol_id_map, pdb_species_order, species_counts

    def get_system_topology(self, tpr_file):
        """
        Extracts topology from GROMACS TPR files using Chemfiles.
        """
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            try:
                import chemfiles
                traj = chemfiles.Trajectory(tpr_file)
                frame = traj.read()
            except chemfiles.ChemfilesError as e:
                tpr_warning = next((str(warn.message) for warn in w if "TPR" in str(warn.message)), None)
                if tpr_warning:
                    print("ERROR: INCOMPATIBLE TPR FILE DETECTED")
                    print(f"File: {tpr_file}")
                    print(f"{tpr_warning}")
                    print("To fix this, please use other options such as --mda for MDAnalysis.")
                else:
                    print(f"ERROR: Chemfiles internal error: {e}")
                sys.exit(1)
                
        topo = frame.topology
        atoms = list(frame.atoms)
        n_atoms = len(atoms)

        atom_names = [a.name.strip() for a in atoms]
        atom_types = [a.type.strip() for a in atoms]
        charges = np.array([a.charge for a in atoms], dtype=np.float32)
        masses = np.array([a.mass for a in atoms], dtype=np.float32)

        res_names = ["UNK"] * n_atoms
        for res in topo.residues:
            r_name = res.name.strip()
            for idx in res.atoms:
                res_names[idx] = r_name

        df_mass_full = pd.DataFrame({
            "atom_index": range(n_atoms), 
            "res_name": res_names,
            "atom": atom_names,
            "type": atom_types,
            "q": charges,
            "mass": masses
        })
        
        del frame
        traj.close()
        return df_mass_full
    
    def snapshot_generator(self, PDB, t_start, t_end):
        
        """Generates snapshots from a PDB file within a time range."""
        
        with open(PDB, "r") as file:
            snapshot_lines = []
            for line in file:
                snapshot_lines.append(line)
                if line.startswith("ENDMDL"):
                    current_t = -1
                    for s_line in snapshot_lines:
                        if s_line.startswith("TITLE"):
                            t_match = re.search(r"t\s*=\s*([\d\.Ee+-]+)", s_line)
                            if t_match:
                                current_t = float(t_match.group(1))
                                break
                    if t_start <= current_t <= t_end:
                        yield snapshot_lines
                    snapshot_lines = []
        return

    def get_pdb_dt(self, file_path):
        
        """Get timesteps from pdb file."""
        
        times = []
        with open(file_path, 'r') as f:
            for line in f:
                if line.startswith("TITLE"):
                    if "t=" in line:
                        try:
                            time_val = float(line.split("t=")[1].split()[0])
                            times.append(time_val)
                        except (IndexError, ValueError):
                            continue
                
                if len(times) >= 2:
                    break
        
        if len(times) >= 2:
            return times[1] - times[0]
        else:
            self.log_message("INFO","Could not find multiple frames with timestamps.")
            sys.exit(1) 

    def from_pdb_and_itp(self, t_start, t_end, valid_species=False, return_atoms=False, hidden_dump_file=None):
        """
        Processes PDB file to generate species or atomic data with optimized selective extraction.
        """
        pdb_file = "traj.pdb" if self.args.EXE else self.args.PDB
        itp_dir = self.args.ITP if not self.args.EXE else None
        
        # Filtering parameters
        skip_resname = getattr(self.args, 'SKIP_SPECIES', []) or []
        user_resnames = getattr(self.args, 'resname', []) or []
        msd_selections = getattr(self.args, 'MSD_SELECTIONS', None)

        if not pdb_file.lower().endswith(".pdb"):
            self.log_message("ERROR", f"Found {pdb_file} file. Please provide a PDB file when using the --pdb flag.")
            sys.exit(1)

        if self.args.EXE:
            df_mass_full, species_charges_raw, species_mass = self.calculate_charges(input_file=hidden_dump_file)
        else:
            df_mass_full, species_charges_raw, species_mass = self.calculate_charges_from_itp_files(itp_dir)

        # Build map for masses and types
        mass_lookup = df_mass_full.set_index(["res_name", "atom"])["mass"].to_dict()
        type_lookup = df_mass_full.set_index(["res_name", "atom"])["type"].to_dict()
        charge_lookup = df_mass_full.set_index(["res_name", "atom"])["q"].to_dict()

        raw_atom_masses, raw_mol_indices = [], []
        atom_metadata_list = []
        inv_mol_id_map, species_counts = {}, defaultdict(int)
        unique_resnames_list, seen_resnames = [], set()
        current_mol_index, last_resid, last_resname = -1, -1000, ""
        n_atoms_per_frame = 0
        atom_mask = []
        
        self.log_message("INFO", "Indexing pdb file...")
        
        with open(pdb_file, 'r') as f:
            for line in f:
                if line.startswith("ENDMDL"): break
                if not (line.startswith("ATOM") or line.startswith("HETATM")): continue
                
                res_name = line[17:20].strip()
                res_id = int(line[22:26])
                atom_name = line[12:16].strip()
                
                if (res_name, atom_name) not in mass_lookup:
                    for itp_r, itp_a in mass_lookup.keys():
                        if itp_r.startswith(res_name) and itp_a == atom_name:
                            res_name = itp_r
                            break
                
                if res_id != last_resid or res_name != last_resname:
                    current_mol_index += 1
                    last_resid, last_resname = res_id, res_name
                    if res_name not in seen_resnames:
                        seen_resnames.add(res_name)
                        unique_resnames_list.append(res_name)
                    inv_mol_id_map[current_mol_index] = (res_name, species_counts[res_name])
                    species_counts[res_name] += 1

                atom_type = type_lookup.get((res_name, atom_name), "Unknown")
                atom_mass = mass_lookup.get((res_name, atom_name), 0.0)
                atom_charge = charge_lookup.get((res_name, atom_name), 0.0)
                keep = False

                if msd_selections:
                    for group in msd_selections:
                        if res_name.upper() == group['resname'].upper():
                            has_filters = (len(group['type']) > 0 or len(group['name']) > 0)
                            
                            if not has_filters:
                                keep = True
                                break
                            else:
                                t_match = (str(atom_type).upper() in [t.upper() for t in group['type']])
                                n_match = (str(atom_name).upper() in [n.upper() for n in group['name']])
                                if t_match or n_match:
                                    keep = True
                                    break
                
                else:
                    if not return_atoms:
                        keep = (res_name not in skip_resname)
                    else:
                        keep = (not user_resnames) or (res_name in user_resnames)
                
                atom_mask.append(keep)
                raw_atom_masses.append(atom_mass)
                raw_mol_indices.append(current_mol_index)

                if keep and return_atoms:
                    atom_metadata_list.append({
                        'atom_index': n_atoms_per_frame,
                        'mol_id': current_mol_index + 1,
                        'resname': res_name,
                        'atom_name': atom_name,
                        'atom_type': atom_type,
                        'charge': atom_charge,
                        'mass': atom_mass
                    })
                
                n_atoms_per_frame += 1

        atom_mask = np.array(atom_mask, dtype=bool)
        global_atom_masses = np.array(raw_atom_masses, dtype=np.float32)[atom_mask]
        gapped_mol_indices = np.array(raw_mol_indices, dtype=np.int32)[atom_mask]
        system_mass = np.sum(raw_atom_masses)

        unique_gapped_indices = sorted(list(np.unique(gapped_mol_indices)))
        reindex_map = {old_idx: new_idx for new_idx, old_idx in enumerate(unique_gapped_indices)}
        global_mol_indices = np.array([reindex_map[old_idx] for old_idx in gapped_mol_indices], dtype=np.int32)
        
        inv_mol_id_map = {new_idx: inv_mol_id_map[old_idx] for old_idx, new_idx in reindex_map.items()}
        if return_atoms:
            for item in atom_metadata_list:
                item['mol_id'] = reindex_map[item['mol_id'] - 1] + 1

        frame_byte_offsets = []
        with open(pdb_file, "r+b") as f: 
            with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
                start_byte = 0
                while True:
                    pos = mm.find(b"ENDMDL", start_byte)
                    if pos == -1: break
                    eol = mm.find(b"\n", pos)
                    end_byte = eol + 1 if eol != -1 else pos + 6
                    frame_byte_offsets.append((start_byte, end_byte))
                    start_byte = end_byte

        t_low = t_start if (t_start is not None and not np.isinf(t_start)) else -1e20
        t_high = t_end if (t_end is not None and not np.isinf(t_end)) else 1e20
        filtered_offsets = []
        with open(pdb_file, "rb") as f:
            for start, end in frame_byte_offsets:
                f.seek(start)
                header = f.read(min(500, end - start)).decode('ascii', errors='ignore')
                if 't=' in header:
                    try:
                        t_val = float(header.split('t=')[1].split()[0])
                        if t_low <= t_val <= t_high: filtered_offsets.append((start, end))
                    except: filtered_offsets.append((start, end))
                else: filtered_offsets.append((start, end))
        
        frame_byte_offsets = filtered_offsets
        n_frames = len(frame_byte_offsets)
        if n_frames == 0: return ({}, pd.DataFrame(), {}, {}, 0, [], {}, 0, {}) if not return_atoms else (None, None, None, 0)

        box_info = np.zeros((n_frames, 4), dtype=np.float32)
        data_mode = "disk" if self.args.USE_DISK else "memory"
        pos_file = "POS_data.dat"
        com_file = "COM_data.dat"

        atom_metadata = pd.DataFrame() 
        
        if return_atoms:
            shape = (n_frames, len(global_atom_masses), 3)
            if data_mode == "disk":
                POS_data = create_array_backend(pos_file, shape, np.float32, "w+", "disk")
                shared_buffer = None
            else:
                size = int(np.prod(shape))
                shared_buffer = multiprocessing.RawArray(ctypes.c_float, size)
                POS_data = np.frombuffer(shared_buffer, dtype=np.float32).reshape(shape)
            COM_data = None

            if atom_metadata_list:
                atom_metadata = pd.DataFrame(atom_metadata_list)
        else:
            shape = (n_frames, len(unique_gapped_indices), 4)
            if data_mode == "disk":
                COM_data = create_array_backend(com_file, shape, np.float32, "w+", "disk")
                shared_buffer = None
            else:
                size = int(np.prod(shape))
                shared_buffer = multiprocessing.RawArray(ctypes.c_float, size)
                COM_data = np.frombuffer(shared_buffer, dtype=np.float32).reshape(shape)
            POS_data = None

        mmap_opts = {'filename': pos_file if return_atoms else com_file, 'shape': shape, 'dtype': np.float32}

        chunk_size = max(1, n_frames // (4 * self.n_cores))
        tasks = []
        for i in range(0, n_frames, chunk_size):
            chunk_offs = frame_byte_offsets[i : i + chunk_size]
            chunk_cols = list(range(i, i + len(chunk_offs)))
            tasks.append((chunk_offs, chunk_cols, data_mode, mmap_opts))
            
        worker_func = partial(process_pdb, return_atoms=return_atoms)
        desc = "Validating Species" if valid_species else "Processing Snapshots"
        
        init_args = (
            shared_buffer, 
            shape, 
            pdb_file, 
            n_atoms_per_frame, 
            atom_mask, 
            None if return_atoms else global_atom_masses, 
            None if return_atoms else global_mol_indices
        )
        
        if self.n_cores > 1:
            ctx = multiprocessing.get_context(self.args.get_context) 
            
            with ctx.Pool(processes=self.n_cores, initializer=init_worker_pdb, initargs=init_args, maxtasksperchild=10) as pool:
                with tqdm(total=n_frames, desc=desc, unit=" frames") as pbar:
                    for metadata_chunk in pool.imap_unordered(worker_func, tasks):
                        for row in metadata_chunk:
                            c_idx = int(row[0])
                            box_info[c_idx] = row[1:] 
                        pbar.update(len(metadata_chunk))
        else:
            init_worker_pdb(*init_args)
            
            with tqdm(total=n_frames, desc=desc, unit=" frames") as pbar:
                for task in tasks:
                    metadata_chunk = worker_func(task)
                    for row in metadata_chunk:
                        c_idx = int(row[0])
                        box_info[c_idx] = row[1:]
                    pbar.update(len(metadata_chunk))
            
            global worker_pdb_file_handle
            if worker_pdb_file_handle is not None:
                worker_pdb_file_handle.close()

        box_df = pd.DataFrame(box_info, columns=["t", "Lx", "Ly", "Lz"])
        
        if data_mode == "disk":
            if POS_data is not None:
                POS_data.flush()
        
            if COM_data is not None:
                COM_data.flush()
                    
        if return_atoms:
            return POS_data, box_df, atom_metadata, system_mass
        else:
            unique_resnames_final = [r for r in unique_resnames_list if r not in skip_resname]
            final_charges = {k: species_charges_raw.get(k, 0.0) for k in unique_resnames_final}
            final_counts = {k: species_counts[k] for k in unique_resnames_final}
            dt_final = box_df['t'].diff().median() if len(box_df) > 1 else 1.0
            
            final_species_masses = {}
            for m_idx, (r_name, _) in inv_mol_id_map.items():
                if r_name not in final_species_masses:
                    m_mask = (global_mol_indices == m_idx)
                    final_species_masses[r_name] = round(float(np.sum(global_atom_masses[m_mask])), 4)

            return COM_data, box_df, final_charges, final_counts, dt_final, unique_resnames_final, inv_mol_id_map, system_mass, final_species_masses

    def from_gromacs_to_species_files(self, tpr_file, traj_file, t_start, t_end, valid_species=False, return_atoms=False):

        """
        Processes GROMACS files to generate species files.
        """
        if self.args.MDA:
            try:
                import MDAnalysis as mda
            except ImportError:
                self.log_message("ERROR","Error: MDAnalysis is required for this feature (--mda) but is not installed.")
                self.log_message("INFO","Please install it to proceed.")
                self.log_message("INFO","\nTo install using pip:")
                self.log_message("INFO","  pip install MDAnalysis")
                self.log_message("INFO","\nTo install using conda:")
                self.log_message("INFO","  conda install -c conda-forge mdanalysis")
                self.log_message("INFO","-------------------------------------")
                sys.exit(1) 

        try:
            warnings.filterwarnings("ignore", category=UserWarning, module="MDAnalysis")
            warnings.filterwarnings("ignore", message="Reader has no dt information, set to 1.0 ps", category=UserWarning)
            u = mda.Universe(tpr_file, traj_file)
        except Exception as e:
            self.log_message("ERROR", f"Failed to load Universe: {e}")
            return ({}, pd.DataFrame(), {}, {}, 0, [], {}, 0, {}) if not return_atoms else (None, None, None, None)

        system_mass = u.atoms.masses.sum()
        all_resnames_ordered = list(dict.fromkeys(u.residues.resnames))
        skip_resname = getattr(self.args, 'SKIP_SPECIES', []) or []

        if return_atoms:
            res_list = getattr(self.args, 'resname', []) or []
            complex_sel = getattr(self.args, 'MSD_COMPLEX_SELECTION', None)
            
            if complex_sel:
                sel_str = complex_sel
            else:
                if res_list:
                    sel_str = "resname " + " ".join(res_list)
                else:
                    sel_str = "all"
                
            valid_atoms = u.select_atoms(sel_str)
            atom_indices = valid_atoms.indices
            
            atom_charges = valid_atoms.charges if hasattr(valid_atoms, 'charges') else np.zeros(len(valid_atoms))
            atom_masses = valid_atoms.masses if hasattr(valid_atoms, 'masses') else np.zeros(len(valid_atoms))

            atom_metadata = pd.DataFrame({
                'atom_index': valid_atoms.indices,
                'mol_id': valid_atoms.resindices + 1,
                'resname': valid_atoms.resnames,
                'atom_name': valid_atoms.names,
                'atom_type': valid_atoms.types if hasattr(valid_atoms, 'types') else valid_atoms.names,
                'charge': atom_charges.astype(np.float32),
                'mass': atom_masses.astype(np.float32)
            })
            max_mol_id = valid_atoms.resindices.max() if len(valid_atoms) > 0 else -1          
        else:
            unique_resnames = [res for res in all_resnames_ordered if res not in skip_resname]
            species_charges, species_counts, species_masses = {}, {}, {}
            for resname in unique_resnames:
                res_group = u.residues[u.residues.resnames == resname]
                if len(res_group) > 0:
                    species_counts[resname] = len(res_group)
                    species_charges[resname] = np.sum(res_group[0].atoms.charges).round(4) if hasattr(res_group[0].atoms, 'charges') else 0.0
                    species_masses[resname] = np.sum(res_group[0].atoms.masses).round(4) if hasattr(res_group[0].atoms, 'masses') else 0.0

            sel_str = " or ".join([f"resname {name}" for name in unique_resnames])
            valid_atoms = u.select_atoms(sel_str)
            atom_indices = valid_atoms.indices
            
            global_atom_masses = valid_atoms.masses.astype(np.float32)
            gapped_mol_indices = valid_atoms.resindices.astype(np.int32)
            unique_gapped_indices = np.sort(np.unique(gapped_mol_indices))
            reindex_map = {old: new for new, old in enumerate(unique_gapped_indices)}
            global_mol_indices = np.array([reindex_map[idx] for idx in gapped_mol_indices], dtype=np.int32)

            inv_mol_id_map = {}
            species_counter = defaultdict(int)
            for old_idx, new_idx in reindex_map.items():
                r_name = u.residues[old_idx].resname
                inv_mol_id_map[new_idx] = (r_name, species_counter[r_name])
                species_counter[r_name] += 1
            max_mol_id = global_mol_indices.max() if len(global_mol_indices) > 0 else -1

        dt_traj = u.trajectory.dt if hasattr(u.trajectory, 'dt') and u.trajectory.dt > 0 else 1.0
        total_frames_in_traj = len(u.trajectory)
            
        if traj_file.lower().endswith(".gro"):
            self.log_message("WARNING", f"Please use other parsing methods (e.g., --chem, --ovito) to process {traj_file} file.")
            sys.exit(1)
        if traj_file.lower().endswith(".pdb"):
            dt_pdb = self.get_pdb_dt(traj_file)
            req_dt = 1
            start_frame = int(round(t_start / dt_pdb)) if (t_start is not None and not np.isinf(t_start)) else 0
            if t_end is None or np.isinf(t_end):
                end_frame = total_frames_in_traj
            else:
                end_frame = min(int(round(t_end / dt_pdb)) + 1, total_frames_in_traj)
        else:
            dt_pdb = 1
            req_dt = self.args.t_steps if self.args.t_steps > 0 else 1
            start_frame = int(round(t_start / dt_traj)) if (t_start is not None and not np.isinf(t_start)) else 0
            if t_end is None or np.isinf(t_end):
                end_frame = total_frames_in_traj
            else:
                end_frame = min(int(round(t_end / dt_traj)) + 1, total_frames_in_traj)
        
        step = max(1, int(round(req_dt / dt_traj)))
        frame_indices = [f for f in range(start_frame, end_frame, step) if f < total_frames_in_traj]
        num_frames = len(frame_indices)
        
        ratio = self.args.t_steps / dt_traj
        is_integer = abs(ratio - round(ratio)) < 1e-5
        if not (is_integer and ratio >= 1.0):
            self.log_message("WARNING", 
                f"Trajectory does not contain data at the requested interval of {self.args.t_steps} ps. "
                f"Using Trajectory steps of {dt_traj * step} ps. "
            )
        
        if num_frames == 0:
            return ({}, pd.DataFrame(), {}, {}, 0, [], {}, 0, {}) if not return_atoms else (None, None, None, None)

        box_data = np.zeros((num_frames, 4), dtype=np.float32)
        data_mode = "disk" if self.args.USE_DISK else "memory"
        
        pos_file = "POS_data.dat"
        com_file = "COM_data.dat"
        
        if return_atoms:
            shape = (num_frames, len(atom_indices), 3)
            if data_mode == "disk":
                POS_data = create_array_backend(pos_file, shape, np.float32, "w+", "disk")
                shared_buffer = None
            else:
                size = int(np.prod(shape))
                shared_buffer = multiprocessing.RawArray(ctypes.c_float, size)
                POS_data = np.frombuffer(shared_buffer, dtype=np.float32).reshape(shape)
            COM_data = None
        else:
            shape = (num_frames, max_mol_id + 1, 4)
            if data_mode == "disk":
                COM_data = create_array_backend(com_file, shape, np.float32, "w+", "disk")
                shared_buffer = None
            else:
                size = int(np.prod(shape))
                shared_buffer = multiprocessing.RawArray(ctypes.c_float, size)
                COM_data = np.frombuffer(shared_buffer, dtype=np.float32).reshape(shape)
            POS_data = None

        desc = "Validating Species" if valid_species else "Processing Snapshots"
        if self.n_cores > 1:
            ctx = multiprocessing.get_context(self.args.get_context)
            atom_count = len(atom_indices)
            if traj_file.lower().endswith(".pdb"):
                chunk_size = num_frames // max(1, self.n_cores -1)
            else:
                chunks = [
                    (50000, 100000, 100),
                    (20000,  50000,  200),
                    (10000,  20000,  500),
                    (2000,   20000, 1000),
                ]
            
                chunk_size = None
                for min_mol, min_atom, size in chunks:
                    if max_mol_id > min_mol or atom_count > min_atom:
                        chunk_size = size
                        break
            
                if chunk_size is None:
                    chunk_size = max(1, num_frames // (8 * self.n_cores))
            
            mmap_opts = {'filename': pos_file if return_atoms else com_file, 'shape': shape, 'dtype': np.float32}
            
            tasks = []
            for i in range(0, num_frames, chunk_size):
                c_frames = frame_indices[i : i + chunk_size]
                c_cols = list(range(i, min(i + chunk_size, num_frames)))
                tasks.append((
                    c_frames[0], c_frames[-1] + 1, step, c_cols, 
                    data_mode, mmap_opts, dt_pdb,
                    None if return_atoms else global_atom_masses,
                    None if return_atoms else global_mol_indices
                ))
            
            worker = partial(process_mdanalysis, return_atoms=return_atoms)
            init_args = (shared_buffer, shape, tpr_file, traj_file, sel_str)
            with ctx.Pool(processes=self.n_cores, initializer=init_worker_mda, initargs=init_args, maxtasksperchild=10) as pool:
                with tqdm(total=num_frames, desc=desc) as pbar:
                    for metadata_chunk in pool.imap_unordered(worker, tasks):
                        for row in metadata_chunk:
                            c_idx = int(row[0])
                            box_data[c_idx] = row[1:] 
                        pbar.update(len(metadata_chunk))

        else:
            with tqdm(total=num_frames, desc=desc) as pbar:
                traj_slice = u.trajectory[frame_indices[0] : frame_indices[-1] + 1 : step]
                for i, ts in enumerate(traj_slice):
                    scaled_time = ts.time * dt_pdb
                    box_data[i] = [scaled_time, ts.dimensions[0], ts.dimensions[1], ts.dimensions[2]]
                    
                    if return_atoms:
                        POS_data[i] = valid_atoms.positions.copy()
                    else:
                        curr_indices, coms = calculate_com_pbc(
                            valid_atoms.positions, global_atom_masses, global_mol_indices, ts.dimensions[:3]
                        )
                        COM_data[i, curr_indices, 0] = scaled_time
                        COM_data[i, curr_indices, 1:4] = coms
                    pbar.update(1)

        u.trajectory.close()
        box_df = pd.DataFrame(box_data, columns=["t", "Lx", "Ly", "Lz"])
        
        all_res = list(dict.fromkeys(u.residues.resnames))
        species_charges = {}
        for resname in all_res:
            res_group = u.residues[u.residues.resnames == resname]
            if len(res_group) > 0:
                species_charges[resname] = np.sum(res_group[0].atoms.charges).round(4) if hasattr(res_group[0].atoms, 'charges') else 0.0
        
        if data_mode == "disk":
            if POS_data is not None:
                POS_data.flush()
            if COM_data is not None:
                COM_data.flush()       
        
        if return_atoms:
            return POS_data, box_df, atom_metadata, system_mass
        else:
            return COM_data, box_df, species_charges, species_counts, dt_traj * step * dt_pdb, unique_resnames, inv_mol_id_map, system_mass, species_masses
        
    def from_gromacs_to_cheme_files(self, t_start, t_end, valid_species=False, return_atoms=False):
        """
        Extracts data from GROMACS files using Chemfiles.
        """
        if self.args.CHEM:
            try:
                import chemfiles
                from collections import Counter
            except ImportError:
                self.log_message("ERROR","Error: Chemfiles is required for this feature (--chem) but is not installed.")
                self.log_message("INFO","Please install it to proceed.")
                self.log_message("INFO","\nTo install using pip:")
                self.log_message("INFO","  pip install chemfiles")
                self.log_message("INFO","\nTo install using conda:")
                self.log_message("INFO","  conda install -c conda-forge chemfiles")
                self.log_message("INFO","-------------------------------------")
                sys.exit(1)

        tpr_file, traj_path = self.get_gromacs_files()
        df_topo = self.get_system_topology(tpr_file)
        
        if df_topo.empty:
            self.log_message("ERROR", "System topology parsed as empty.")
            return ({}, pd.DataFrame(), {}, {}, 0, [], {}, 0, {})

        res_names_arr = df_topo["res_name"].values
        res_change = res_names_arr != np.roll(res_names_arr, 1)
        res_change[0] = False
        block_starts = np.where(res_change)[0]
        block_ends = np.append(block_starts, len(df_topo))
        block_starts = np.insert(block_starts, 0, 0)
        
        mol_ids_full = np.zeros(len(df_topo), dtype=np.int32)
        curr_mol_id = 0
        atom_names_arr = df_topo["atom"].values
        
        for start, end in zip(block_starts, block_ends):
            block_atoms = atom_names_arr[start:end]
            first_atom = block_atoms[0]
            name_matches = np.where(block_atoms == first_atom)[0]
            atoms_per_mol = name_matches[1] if len(name_matches) > 1 else len(block_atoms)
            n_mols = len(block_atoms) // atoms_per_mol
            mol_ids_full[start:end] = np.repeat(np.arange(n_mols), atoms_per_mol) + curr_mol_id
            curr_mol_id += n_mols
        
        df_topo['mol_id'] = mol_ids_full
        df_topo['atom_idx'] = np.arange(len(df_topo))

        msd_selections = getattr(self.args, 'MSD_SELECTIONS', None)
        user_resnames = getattr(self.args, 'resname', []) or []
        skip_resname = getattr(self.args, 'SKIP_SPECIES', []) or []
        
        keep_mask = np.zeros(len(df_topo), dtype=bool)
        if msd_selections:
            res_upper = df_topo['res_name'].str.upper()
            type_upper = df_topo['type'].str.upper()
            atom_upper = df_topo['atom'].str.upper()
            for group in msd_selections:
                res_mask = res_upper == group['resname'].upper()
                if not group['type'] and not group['name']:
                    keep_mask |= res_mask
                else:
                    target_filters = [str(t).upper() for t in (group['type'] + group['name'])]
                    atom_mask = (type_upper.isin(target_filters)) | (atom_upper.isin(target_filters))
                    keep_mask |= (res_mask & atom_mask)
        else:
            if user_resnames:
                keep_mask = df_topo['res_name'].isin(user_resnames)
            else:
                keep_mask = ~df_topo['res_name'].isin(skip_resname)

        df_kept = df_topo[keep_mask].copy()
        if df_kept.empty:
            self.log_message("ERROR", "No atoms found for selection.")
            return ({}, pd.DataFrame(), {}, {}, 0, [], {}, 0, {})

        unique_orig_mols, inv_indices = np.unique(df_kept['mol_id'], return_inverse=True)
        global_mol_ids = inv_indices.astype(np.int32)
        kept_atom_indices = df_kept['atom_idx'].values.astype(np.int32)
        global_atom_masses = df_kept['mass'].values.astype(np.float32)
        current_continuous_mol_id = len(unique_orig_mols)

        m_sum = np.zeros(current_continuous_mol_id, dtype=np.float32)
        np.add.at(m_sum, global_mol_ids, global_atom_masses)
        m_sum[m_sum == 0] = 1.0
        mol_mass_divisor = m_sum.reshape(-1, 1)
        
        _, start_indices = np.unique(global_mol_ids, return_index=True)
        atom_masses_reshaped = global_atom_masses.reshape(-1, 1)

        resnames_per_mol = df_kept['res_name'].values[start_indices]
        final_species_counts = dict(Counter(resnames_per_mol))
        species_masses = {res: round(float(m_sum[np.where(resnames_per_mol == res)[0][0]]), 4) for res in final_species_counts}
        
        species_charges_raw = {}
        for res in final_species_counts:
            first_mol_idx = np.where(resnames_per_mol == res)[0][0]
            orig_mol_id = unique_orig_mols[first_mol_idx]
            species_charges_raw[res] = round(float(df_topo[df_topo['mol_id'] == orig_mol_id]['q'].sum()), 4)

        inv_mol_id_map = {i: (resnames_per_mol[i], 0) for i in range(len(resnames_per_mol))}

        temp_traj = chemfiles.Trajectory(traj_path)
        n_total_frames = temp_traj.nsteps
        t0, dt_traj, has_time_prop = 0.0, 1.0, False
        try:
            f0 = temp_traj.read_step(0)
            if "time" in f0.list_properties():
                t0, has_time_prop = f0["time"], True
            if n_total_frames > 1:
                f1 = temp_traj.read_step(1)
                dt_traj = f1["time"] - t0 if has_time_prop else 1.0
        except: pass
        temp_traj.close()

        dt_pdb = self.get_pdb_dt(traj_path) if traj_path.lower().endswith(".pdb") else 1.0
        req_dt = self.args.t_steps if self.args.t_steps else dt_traj
        step_stride = max(1, int(round(req_dt / dt_traj)))
    
        ratio = self.args.t_steps / dt_traj
        is_integer = abs(ratio - round(ratio)) < 1e-5
        if not (is_integer and ratio >= 1.0):
            self.log_message("WARNING", 
                f"Trajectory does not contain data at the requested interval of {self.args.t_steps} ps. "
                f"Using Trajectory steps of {dt_traj * step_stride} ps. "
            )
        
        start_idx = max(0, int(np.ceil((t_start - t0) / dt_traj))) if (t_start is not None and not np.isinf(t_start)) else 0
        end_idx = min(n_total_frames, int(np.floor((t_end - t0) / dt_traj)) + 1) if (t_end is not None and not np.isinf(t_end)) else n_total_frames
            
        frames_to_read = list(range(start_idx, end_idx, step_stride))
        n_frames = len(frames_to_read)

        data_mode = "disk" if self.args.USE_DISK else "memory"
        shape = (n_frames, current_continuous_mol_id, 4) if not return_atoms else (n_frames, len(kept_atom_indices), 3)
        mmap_file = "POS_data.dat" if return_atoms else "COM_data.dat"
        
        if data_mode == "disk":
            data_storage = create_array_backend(mmap_file, shape, np.float32, "w+", "disk")
            shared_buffer = None
        else:
            shared_buffer = multiprocessing.RawArray(ctypes.c_float, int(np.prod(shape)))
            data_storage = np.frombuffer(shared_buffer, dtype=np.float32).reshape(shape)

        tasks = []
        atom_count = len(kept_atom_indices)
        max_mol_id = current_continuous_mol_id
        if traj_path.lower().endswith(".pdb") or traj_path.lower().endswith(".gro"):
            chunk_size = n_frames // max(1, self.n_cores -1)
        else:
            chunks = [
                (50000, 100000, 100),
                (20000,  50000,  200),
                (10000,  20000,  500),
                (2000,   20000, 1000),
            ]
        
            chunk_size = None
            for min_mol, min_atom, size in chunks:
                if max_mol_id > min_mol or atom_count > min_atom:
                    chunk_size = size
                    break
        
            if chunk_size is None:
                chunk_size = max(1, n_frames // (8 * self.n_cores))

        mmap_opts = {'filename': mmap_file, 'shape': shape, 'dtype': np.float32}
        
        for i in range(0, n_frames, chunk_size):
            col_chunk = list(range(i, min(i + chunk_size, n_frames)))
            first_frame_in_chunk = frames_to_read[i]
            tasks.append((first_frame_in_chunk, step_stride, col_chunk, data_mode, mmap_opts, dt_pdb, t0, dt_traj))

        init_args = (shared_buffer, shape, traj_path, kept_atom_indices, 
                     atom_masses_reshaped, global_mol_ids, mol_mass_divisor, start_indices)

        box_info = np.zeros((n_frames, 4), dtype=np.float32)
        worker_func = partial(process_chemfiles, return_atoms=return_atoms)
        desc = "Validating Species" if valid_species else "Processing Snapshots"
        if self.n_cores > 1:
            ctx = multiprocessing.get_context(getattr(self.args, 'get_context', 'spawn'))
            with ctx.Pool(processes=self.n_cores, initializer=init_worker_chemfiles, initargs=init_args, maxtasksperchild=10) as pool:
                with tqdm(total=n_frames, desc=desc) as pbar:
                    for metadata_chunk in pool.imap_unordered(worker_func, tasks):
                        for row in metadata_chunk:
                            box_info[int(row[0])] = row[1:]
                        pbar.update(len(metadata_chunk))
        else:
            init_worker_chemfiles(*init_args)
            with tqdm(total=n_frames, desc=desc) as pbar:
                for task in tasks:
                    metadata_chunk = worker_func(task)
                    for row in metadata_chunk:
                        box_info[int(row[0])] = row[1:]
                    pbar.update(len(metadata_chunk))

        if return_atoms:
            atom_metadata = df_kept[['atom_index', 'mol_id', 'res_name', 'atom', 'type', 'q', 'mass']].copy()
            atom_metadata.columns = ['atom_index', 'mol_id', 'resname', 'atom_name', 'atom_type', 'charge', 'mass']
            return data_storage, pd.DataFrame(box_info, columns=["t", "Lx", "Ly", "Lz"]), atom_metadata, df_topo["mass"].sum()
        
        return data_storage, pd.DataFrame(box_info, columns=["t", "Lx", "Ly", "Lz"]), species_charges_raw, final_species_counts, dt_traj*step_stride*dt_pdb, sorted(list(final_species_counts.keys())), inv_mol_id_map, df_topo["mass"].sum(), species_masses
    
    def from_gromacs_to_ovito(self, t_start, t_end, valid_species=False, return_atoms=False):
        """
        Extracts data from GROMACS files using OVITO.
        """
        if self.args.OVITO:
            try:
                warnings.filterwarnings('ignore', message='.*OVITO.*PyPI.*')  
                from ovito.io import import_file
            except ImportError:
                self.log_message("ERROR","Error: OVITO is required for this feature (--ovito) but is not installed.")
                self.log_message("INFO","Please install it to proceed.")
                self.log_message("INFO","\nTo install using pip:")
                self.log_message("INFO","  pip install ovito")
                self.log_message("INFO","\nTo install using conda:")
                self.log_message("INFO","  conda install --strict-channel-priority -c https://conda.ovito.org -c conda-forge ovito=3.14.1")
                self.log_message("INFO","-------------------------------------")
                sys.exit(1)
                
        warnings.filterwarnings("ignore", category=UserWarning)
        topo_file, traj_path = self.get_gromacs_files()
        
        itp_dir = self.args.ITP
        if itp_dir is None or not os.path.isdir(itp_dir):
            self.log_message("ERROR", "Valid ITP directory required for OVITO mass/charge mapping.")
            sys.exit(1)
            
        df_itp_lib, species_charges_raw, _ = self.calculate_charges_from_itp_files(itp_dir)
        itp_lookup = {}
        if not df_itp_lib.empty:
            for _, row in df_itp_lib.iterrows():
                itp_lookup[(str(row['res_name'])[:4].upper(), str(row['atom']).upper())] = (
                    float(row['mass']), float(row['q']), str(row['type']).upper()
                )
    
        res_names, atom_names, res_ids = [], [], []
        with open(topo_file, 'r') as f:
            if topo_file.lower().endswith('.gro'):
                lines = f.readlines()
                num_atoms = int(lines[1].strip())
                for line in lines[2 : 2 + num_atoms]:
                    res_ids.append(line[0:5].strip())
                    res_names.append(line[5:10].strip())
                    atom_names.append(line[10:15].strip())
            elif topo_file.lower().endswith('.pdb'):
                for line in f:
                    if line.startswith("ATOM") or line.startswith("HETATM"):
                        res_ids.append(line[22:26].strip())
                        res_names.append(line[17:20].strip())
                        atom_names.append(line[12:16].strip())
            else:
                self.log_message("ERROR", "A gro or PDB file as topology file required for OVITO. Please provide it using --tpr flag.")
                sys.exit(1)
    
        res_ids_arr = np.array(res_ids)
        res_names_arr = np.array(res_names)
        diff_res = (res_ids_arr[:-1] != res_ids_arr[1:]) | (res_names_arr[:-1] != res_names_arr[1:])
        global_mol_ids = np.concatenate(([0], np.cumsum(diff_res)))
    
        skip_resname = [s.upper() for s in (getattr(self.args, 'SKIP_SPECIES', []) or [])]
        user_resnames = [u.upper() for u in (getattr(self.args, 'resname', []) or [])]
        msd_selections = getattr(self.args, 'MSD_SELECTIONS', None)
    
        kept_atom_mask = []
        global_masses = []
        all_atoms_info = []
    
        for i in range(len(atom_names)):
            r_full, a_name = res_names[i], atom_names[i]
            m, q, a_type = itp_lookup.get((r_full[:4].upper(), a_name.upper()), (1.0, 0.0, "UNK"))
            global_masses.append(m)
    
            keep = False
            if msd_selections:
                for group in msd_selections:
                    if r_full.upper() == group['resname'].upper():
                        if not group['type'] and not group['name']:
                            keep = True; break
                        t_match = (a_type.upper() in [t.upper() for t in group['type']])
                        n_match = (a_name.upper() in [n.upper() for n in group['name']])
                        if t_match or n_match:
                            keep = True; break
            else:
                if not return_atoms:
                    keep = r_full.upper() not in skip_resname
                else:
                    keep = (not user_resnames) or (r_full.upper() in user_resnames)
            
            kept_atom_mask.append(keep)
            all_atoms_info.append({'m': m, 'q': q, 'type': a_type})
    
        kept_atom_mask = np.array(kept_atom_mask, dtype=bool)
        global_masses = np.array(global_masses, dtype=np.float32)
        system_mass = np.sum(global_masses)
    
        original_kept_mol_ids = global_mol_ids[kept_atom_mask]
        unique_old_ids, first_indices = np.unique(original_kept_mol_ids, return_index=True)
        unique_old_ids = [original_kept_mol_ids[idx] for idx in sorted(first_indices)]
        
        reindex_map = {old_id: new_id for new_id, old_id in enumerate(unique_old_ids)}
        global_mol_ids_filtered = np.array([reindex_map[m] for m in original_kept_mol_ids], dtype=np.int32)
        global_masses_filtered = global_masses[kept_atom_mask]
        kept_atom_indices = np.flatnonzero(kept_atom_mask).astype(np.int32)
    
        inv_mol_id_map = {}
        final_species_counts = defaultdict(int)
        species_masses = {}
        atom_metadata = None 
        
        for old_id in unique_old_ids:
            mol_mask = (global_mol_ids == old_id)
            mol_idx = np.where(mol_mask)[0][0]
            r_name = res_names[mol_idx]
            
            m_sum = np.sum(global_masses[mol_mask])
            species_masses[r_name] = round(float(m_sum), 4)
            
            new_id = reindex_map[old_id]
            inv_mol_id_map[new_id] = (r_name, final_species_counts[r_name])
            final_species_counts[r_name] += 1
    
        if return_atoms:
            atom_metadata_list = []
            cursor = 0
            for i in range(len(atom_names)):
                if kept_atom_mask[i]:
                    info = all_atoms_info[i]
                    atom_metadata_list.append({
                        'atom_index': i, 
                        'mol_id': int(global_mol_ids_filtered[cursor]) + 1,
                        'resname': res_names[i],
                        'atom_name': atom_names[i],
                        'atom_type': info['type'],
                        'charge': info['q'],
                        'mass': info['m'] 
                    })
                    cursor += 1
            atom_metadata = pd.DataFrame(atom_metadata_list)
    
        self.log_message("DEBUG", f"Opening trajectory {traj_path}...")
        pipeline = import_file(traj_path)
        n_total_frames = pipeline.source.num_frames
        if n_total_frames == 0: return {}, pd.DataFrame(), {}, {}, 0, [], {}, 0
    
        try:
            d0 = pipeline.compute(0)
            t0 = d0.attributes.get("Time", 0.0)
            
            dt_traj = 1.0
            if n_total_frames > 1:
                d1 = pipeline.compute(1)
                t1 = d1.attributes.get("Time", 0.0)
                dt_traj = t1 - t0
                if dt_traj <= 0: dt_traj = 1.0 
        except Exception:
            t0 = 0.0
            dt_traj = 1.0
        
        step_stride = 1
        if traj_path.lower().endswith(".pdb"):
            dt_pdb = self.get_pdb_dt(traj_path)
            req_dt = 1
            start_idx = 0
            if t_start is not None and t_start > t0 and not np.isinf(t_start):
                start_idx = int(np.ceil((t_start - t0) / dt_pdb))
                start_idx = max(0, min(start_idx, n_total_frames - 1))
            end_idx = n_total_frames
            if t_end is not None and not np.isinf(t_end):
                calc_end = int(np.floor((t_end - t0) / dt_pdb)) + 1
                end_idx = min(n_total_frames, calc_end)
        elif traj_path.lower().endswith(".gro"):
            dt_pdb = self.args.t_steps if self.args.t_steps else 1.0
            req_dt = 1
            start_idx = 0
            if t_start is not None and t_start > t0 and not np.isinf(t_start):
                start_idx = int(np.ceil((t_start - t0) / dt_pdb))
                start_idx = max(0, min(start_idx, n_total_frames - 1))
            end_idx = n_total_frames
            if t_end is not None and not np.isinf(t_end):
                calc_end = int(np.floor((t_end - t0) / dt_pdb)) + 1
                end_idx = min(n_total_frames, calc_end)
        else:
            dt_pdb = 1
            req_dt = self.args.t_steps if self.args.t_steps else 1.0
            start_idx = 0
            if t_start is not None and t_start > t0 and not np.isinf(t_start):
                start_idx = int(np.ceil((t_start - t0) / dt_traj))
                start_idx = max(0, min(start_idx, n_total_frames - 1))
            end_idx = n_total_frames
            if t_end is not None and not np.isinf(t_end):
                calc_end = int(np.floor((t_end - t0) / dt_traj)) + 1
                end_idx = min(n_total_frames, calc_end)
                
        if req_dt > 0:
            step_stride = int(round(req_dt / dt_traj))
            if step_stride < 1: step_stride = 1

        ratio = self.args.t_steps / dt_traj
        is_integer = abs(ratio - round(ratio)) < 1e-5
        if not (is_integer and ratio >= 1.0):
            self.log_message("WARNING", 
                f"Trajectory does not contain data at the requested interval of {self.args.t_steps} ps. "
                f"Using Trajectory steps of {dt_traj * step_stride} ps. "
            )

        frames_to_read = list(range(start_idx, end_idx, step_stride))
        n_frames = len(frames_to_read)
        if n_frames == 0: return {}, pd.DataFrame(), {}, {}, 0, [], {}, 0
    
        max_mol_id = global_mol_ids_filtered.max() if len(global_mol_ids_filtered) > 0 else -1
        box_info = np.zeros((n_frames, 4), dtype=np.float32)
        data_mode = "disk" if self.args.USE_DISK else "memory"
        pos_file = "POS_data.dat"
        com_file = "COM_data.dat"
    
        if return_atoms:
            shape = (n_frames, len(kept_atom_indices), 3)
            if data_mode == "disk":
                POS_data = create_array_backend(pos_file, shape, np.float32, "w+", "disk")
                shared_buffer = None
            else:
                size = int(np.prod(shape))
                shared_buffer = multiprocessing.RawArray(ctypes.c_float, size)
                POS_data = np.frombuffer(shared_buffer, dtype=np.float32).reshape(shape)
            COM_data = None
        else:
            shape = (n_frames, max_mol_id + 1, 4)
            if data_mode == "disk":
                COM_data = create_array_backend(com_file, shape, np.float32, "w+", "disk")
                shared_buffer = None
            else:
                size = int(np.prod(shape))
                shared_buffer = multiprocessing.RawArray(ctypes.c_float, size)
                COM_data = np.frombuffer(shared_buffer, dtype=np.float32).reshape(shape)
            POS_data = None
    
        mmap_opts = {'filename': pos_file if return_atoms else com_file, 'shape': shape, 'dtype': np.float32}
        
        desc = "Validating Species" if valid_species else "Processing Snapshots"
        atom_count = len(kept_atom_indices)
        if traj_path.lower().endswith(".pdb") or traj_path.lower().endswith(".gro"):
            chunk_size = n_frames // max(1, self.n_cores -1)
        else:
            chunks = [
                (50000, 100000, 100),
                (20000,  50000,  200),
                (10000,  20000,  500),
                (2000,   20000, 1000),
            ]
        
            chunk_size = None
            for min_mol, min_atom, size in chunks:
                if max_mol_id > min_mol or atom_count > min_atom:
                    chunk_size = size
                    break
        
            # Default for small systems
            if chunk_size is None:
                chunk_size = max(1, n_frames // max(1, self.n_cores -1))

        tasks = []
        for i in range(0, n_frames, chunk_size):
            c_frames = frames_to_read[i : i + chunk_size]
            tasks.append((
                c_frames, i, dt_traj, dt_pdb, data_mode, mmap_opts
            ))

        worker_func = partial(process_ovito, return_atoms=return_atoms)

        init_args = (
            shared_buffer, 
            shape, 
            traj_path, 
            kept_atom_indices, 
            None if return_atoms else global_masses_filtered, 
            None if return_atoms else global_mol_ids_filtered,
            return_atoms
        )
            
        if self.n_cores > 1:
            ctx = multiprocessing.get_context(getattr(self.args, 'get_context', 'spawn'))
            with ctx.Pool(processes=self.n_cores, initializer=init_worker_ovito, initargs=init_args, maxtasksperchild=10) as pool:
                with tqdm(total=n_frames, desc=desc) as pbar:
                    for metadata_chunk in pool.imap_unordered(worker_func, tasks):
                        for row in metadata_chunk:
                            idx = int(row[0])
                            box_info[idx] = row[1:]
                        pbar.update(len(metadata_chunk))
        else:
            init_worker_ovito(*init_args)
            with tqdm(total=n_frames, desc=desc, unit=" frames") as pbar:
                for task in tasks:
                    metadata_chunk = worker_func(task)
                    for row in metadata_chunk:
                        idx = int(row[0])
                        box_info[idx] = row[1:]
                        
                    pbar.update(len(metadata_chunk))
    
        box_df = pd.DataFrame(box_info, columns=["t", "Lx", "Ly", "Lz"])
        
        if data_mode == "disk":
            if POS_data is not None:
                POS_data.flush()
            if COM_data is not None:
                COM_data.flush()
        
        if return_atoms:
            return POS_data, box_df, atom_metadata, system_mass
        else:
            dt_final = dt_traj * step_stride * dt_pdb
            return COM_data, box_df, species_charges_raw, dict(final_species_counts), dt_final, sorted(list(final_species_counts.keys())), inv_mol_id_map, system_mass, species_masses