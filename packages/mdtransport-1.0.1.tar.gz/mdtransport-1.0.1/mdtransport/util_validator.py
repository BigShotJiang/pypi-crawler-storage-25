#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Wed Nov 19 15:21:36 2025

@author: Shah Research Group, Oklahoma State University <jindal.shah@okstate.edu>

MDTransport: GROMACS & LAMMPS Transport Analysis Tools
Copyright (C) 2026  Ashutosh Kumar Verma, Amey Thorat and Jindal Shah

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
"""

import os
import re
import sys
import glob
import tempfile
import logging
import warnings
import subprocess
import collections
import numpy as np
import pandas as pd
from .util import tqdm
from collections import defaultdict
from .util_gromacs import UTIL_GROMACS
from .util_lammps import UTIL_LAMMPS
from .util_lammps_com import UTIL_LAMMPS_COM

LOG_LEVEL_MAP = {
    'DEBUG': logging.DEBUG,
    'INFO': logging.INFO,
    'WARNING': logging.WARNING,
    'ERROR': logging.ERROR
}

original_stdout = None
original_stdout = sys.stdout

RED = "\033[91m"
YELLOW = "\033[93m"
RESET = "\033[0m"

def logged_input(prompt):
    
    """
    Handles prompts and logs the user's response to the file only.
    """
    logger = logging.getLogger("UTILLogger")
    logger.debug(f"{prompt.strip()}", extra={'caller': 'MDTransport'})
    original_stdout.write(prompt)
    original_stdout.flush()

    user_response = input()

    logger.debug(f"USER INPUT: {user_response.strip()}", extra={'caller': 'MDTransport'})
    return user_response

class CustomFormatter(logging.Formatter):
    
    """
    A custom formatter
    """
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')

    def format(self, record):
        if not hasattr(record, 'caller'):
            record.caller = 'stderr' if record.levelno >= logging.ERROR else 'stdout'
        
        original_msg = record.msg
        record.msg = self.ansi_escape.sub('', str(original_msg))
        formatted_message = super().format(record)
        record.msg = original_msg
        
        return formatted_message

class ColorFormatter(logging.Formatter):
    """
    A formatter that adds color to log messages based on their level.
    Only intended for console output.
    """
    FORMATS = {
        logging.WARNING: f"{YELLOW}%(message)s{RESET}",
        logging.ERROR: f"{RED}%(message)s{RESET}",
        logging.CRITICAL: f"{RED}%(message)s{RESET}",
        logging.INFO: "%(message)s",  
    }

    def format(self, record):
        log_fmt = self.FORMATS.get(record.levelno, self._fmt)
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)
    
def setup_logging():
    
    """Sets up a logger that handles BOTH console and file output."""
    logger = logging.getLogger("UTILLogger")
    if logger.handlers:
        return logger
    
    logger.setLevel(logging.DEBUG)

    file_handler = logging.FileHandler("MDTransport.log", mode='a')
    file_handler.setLevel(logging.DEBUG)
    file_formatter = CustomFormatter("%(asctime)s [%(levelname)s] [%(caller)s] - %(message)s")
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    
    console_formatter = ColorFormatter() 

    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    
    logger.propagate = False
    return logger

def parse_selection_pairs(raw_tokens, modes, context="Selection"):
    """
    Parses raw command-line tokens into selection strings, and pairs each with a mode (COM or ATOM).
    """

    VALID_KEYWORDS = {'resname', 'name', 'type', 'resid', 'segid', 'protein', 'backbone'}
    PRIMARY_KEYWORD = 'resname'

    if not raw_tokens:
        return []
    if raw_tokens[0] not in VALID_KEYWORDS:
        logger.error(f"The {context} argument must begin with a valid keyword (e.g., 'resname'). Got '{raw_tokens[0]}' instead.", extra={'caller': 'Validator'})
        sys.exit(1)
    groups = []
    current_group = []
    for token in raw_tokens:
        if token == PRIMARY_KEYWORD and current_group:
            groups.append(current_group)
            current_group = []
        current_group.append(token)
    if current_group:
        groups.append(current_group)

    selections = []
    for grp in groups:
        keyword_values = defaultdict(list)
        i = 0
        while i < len(grp):
            key = grp[i]
            if key not in VALID_KEYWORDS:
                logger.error(f"Invalid keyword '{key}' in {context} group: {' '.join(grp)}", extra={'caller': 'Validator'})
                sys.exit(1)

            i += 1
            while i < len(grp) and grp[i] not in VALID_KEYWORDS:
                keyword_values[key].append(grp[i])
                i += 1

            if not keyword_values[key]:
                logger.error(f"Keyword '{key}' in {context} must have at least one value.", extra={'caller': 'Validator'})
                sys.exit(1)

        clause_list = [f"{k} {' '.join(v)}" for k, v in keyword_values.items()]
        selections.append(" and ".join(sorted(clause_list)))

    if isinstance(modes, str):
        modes = [modes]

    modes = [m.upper() for m in modes]

    if len(modes) == 1 and len(selections) > 1:
        modes = modes * len(selections)

    if len(modes) != len(selections):
        msg = f"Mismatch: Number of {context} modes ({len(modes)}) does not match number of species/pairs ({len(selections)})."
        logger.error(msg, extra={'caller': 'Validator'})
        sys.exit(1)

    final_pairs = []
    for sel, mode in zip(selections, modes):
        if mode not in ("COM", "ATOM"):
            logger.error(f"Invalid mode '{mode}' for {context}. Must be 'COM' or 'ATOM'.", extra={'caller': 'Validator'})
            sys.exit(1)
        final_pairs.append((sel, mode == "COM"))

    return final_pairs

def search_in_directory(directory, patterns):
    """Return sorted list of files matching basename of patterns in directory."""
    matches = []
    for pattern in patterns:
        basename = os.path.basename(pattern)
        matches.extend(glob.glob(os.path.join(directory, basename)))
    return sorted(matches)


def select_from_multiple(files, logger, file_description):
    """Prompt user to select one file from multiple options."""
    while True:
        logger.warning(f"\nMultiple {file_description} files were found:")
        for i, f in enumerate(files, 1):
            logger.info(f"  [{i}] {os.path.basename(f)}")

        try:
            selection = input("Enter number or file name to select: ").strip()
        except (KeyboardInterrupt, EOFError):
            logger.error("\nUser cancelled input. Exiting.")
            sys.exit(1)

        # Number selection
        if selection.isdigit():
            idx = int(selection) - 1
            if 0 <= idx < len(files):
                return files[idx]

        # Name selection
        for f in files:
            if selection == os.path.basename(f) or selection == f:
                return f

        logger.error(f"Invalid selection '{selection}'. Please try again.\n")


def find_unique_gromacs_file(search_patterns, file_description):
    
    """
    Find a unique file matching patterns. If none found, prompt user.
    If multiple found, ask user to choose.
    """
    logger = logging.getLogger("UTILLogger")

    # Extract initial search directory
    search_dir = os.path.dirname(search_patterns[0]) or "."

    found_files = search_in_directory(search_dir, search_patterns)

    if len(found_files) == 1:
        return found_files[0]

    if len(found_files) > 1:
        return select_from_multiple(found_files, logger, file_description)

    # No files found → interactive mode
    logger.warning(
        f"No {file_description} file(s) found in '{os.path.abspath(search_dir)}'."
    )

    while True:
        try:
            user_input = input(
                f"Please enter the path for the {file_description} file (directory or file): "
            ).strip()
        except (KeyboardInterrupt, EOFError):
            logger.error("\nUser cancelled input. Exiting.")
            sys.exit(1)

        if os.path.isdir(user_input):
            matches = search_in_directory(user_input, search_patterns)

        elif os.path.isfile(user_input):
            return user_input

        else:
            matches = sorted(glob.glob(user_input))

        if len(matches) == 1:
            return matches[0]

        if len(matches) > 1:
            return select_from_multiple(matches, logger, file_description)

        logger.error(f"No matching files found in '{user_input}'. Please try again.\n")
  
class Validator:
    
    def __init__(self, args):
        self.args = args
        self.util_gromacs = UTIL_GROMACS(args)
        self.util_lammps = UTIL_LAMMPS(args)
        self.util_lammps_com = UTIL_LAMMPS_COM(args)
        self.logger = logging.getLogger("UTILLogger")
        self.final_pdb_file = None
    
    def locate_gromacs_files(self):
        """
        Locates GROMACS files and updates self.args.TPR, self.args.TRAJ, and self.args.PDB
        """
        search_dir = self.args.GRO_PATH or "."
    
        # Topology file (.tpr)
        if self.args.TPR:
            if not os.path.exists(self.args.TPR):
                self.log_message("ERROR", f"Provided topology file (--TPR) does not exist: {self.args.TPR}")
                sys.exit(1)
        else:
            self.args.TPR = find_unique_gromacs_file(
                [os.path.join(search_dir, "*.tpr")],
                "topology (.tpr)"
            )
    
        # Trajectory files (.xtc, .trr)
        if self.args.TRAJ:
            if not os.path.exists(self.args.TRAJ):
                self.log_message("ERROR", f"Provided trajectory file (--TRAJ) does not exist: {self.args.TRAJ}")
                sys.exit(1)
        else:
            self.args.TRAJ = find_unique_gromacs_file(
                [
                    os.path.join(search_dir, "*.xtc"),
                    os.path.join(search_dir, "*.trr"),
                ],
                "trajectory (.xtc or .trr)"
            )

    def locate_pdb_file(self):
        
        """
        Locate a .pdb structure file in GRO_PATH (or current directory)
        """
        if self.args.TRAJ:
            if os.path.isfile(self.args.TRAJ) and self.args.TRAJ.endswith(".pdb"):
                final_pdb_file = self.args.TRAJ
                self.log_message("DEBUG", f"Using user-provided PDB: {os.path.basename(final_pdb_file)}")
                self.args.PDB = final_pdb_file
                return final_pdb_file
            else:
                self.log_message("ERROR", f"Invalid PDB file: {self.args.TRAJ}")
                sys.exit(1)
        
        else:
            search_dir = os.path.abspath(self.args.GRO_PATH or ".")
        
            pdb_files = sorted(glob.glob(os.path.join(search_dir, "*.pdb")))
        
            if not pdb_files or self.args.PDB is None:
                # Prompt user interactively if no files found
                while True:
                    user_input = input(
                        f"No .pdb files found in '{search_dir}'. "
                        "Please enter a directory or file path: "
                    ).strip()
        
                    if os.path.isdir(user_input):
                        pdb_files = sorted(glob.glob(os.path.join(user_input, "*.pdb")))
                    elif os.path.isfile(user_input) and user_input.endswith(".pdb"):
                        pdb_files = [user_input]
                    else:
                        self.log_message("INFO", f"No .pdb files found at '{user_input}'. Try again.")
                        continue
        
                    if pdb_files:
                        break
        
            # If multiple files found, let the user select
            if len(pdb_files) > 1:
                self.log_message("INFO", "\nMultiple .pdb files found:")
                for i, f in enumerate(pdb_files, 1):
                    self.log_message("INFO", f"  [{i}] {os.path.basename(f)}")
                while True:
                    choice = input("Select file number: ").strip()
                    if choice.isdigit():
                        idx = int(choice) - 1
                        if 0 <= idx < len(pdb_files):
                            final_pdb_file = pdb_files[idx]
                            break
                    self.log_message("INFO", "Invalid selection. Try again.")
            else:
                final_pdb_file = pdb_files[0]
        
            self.args.PDB = final_pdb_file
            self.log_message("INFO", f"Using PDB file: {os.path.basename(final_pdb_file)}")
            return final_pdb_file

    def log_message(self, level, message):
        
        """
        Logs a message with a specific level, automatically using the
        class's name (e.g., 'GROMACS') as the caller context.
        """
        # Convert the string level to the corresponding integer level
        log_level_int = LOG_LEVEL_MAP.get(level.upper(), logging.INFO)
        
        # that is calling this method (e.g., GROMACS).
        caller_name = self.__class__.__name__
        
        # Prepare the 'extra' dictionary with the dynamic class name
        extra_context = {'caller': caller_name}
        
        # Call the logger with the level, message, and extra context
        self.logger.log(log_level_int, message, extra=extra_context)
        
    def validate_species_system(self, provided_species, arg_name):
        
        """
        Validates species names against system topology.
        """
        if self.args.LAM:
            self.util_lammps.load_and_parse_data_file()
            species_counts, _ = self.util_lammps.parse_species_counts()
            known_species = list(species_counts.keys())
        else:
            known_species = list(self.species_counts.keys())
        validated_species = provided_species
        
        # Mapping argument names to labels
        label_map = {
            "CA": "Reference",
            "AN": "Cage"
        }

        while any(sp not in known_species for sp in validated_species):
            invalid_species = [sp for sp in validated_species if sp not in known_species]
            sp_name = label_map.get(arg_name, "Unknown")
            prompt_message = (
                f"\n{RED}ERROR: {sp_name} species {invalid_species} not found.{RESET}\n"
                f"       Available species are: {known_species}\n"
                f"Please enter the correct {sp_name} species, separated by spaces: "
            )

            try:
                user_input = logged_input(prompt_message).strip()

            except (KeyboardInterrupt, EOFError):
                self.log_message("ERROR", "User aborted during species validation.")
                sys.exit(1)

            validated_species = re.sub(r"[,\s]+", " ", user_input).strip().split()

            self.log_message("INFO", f"{sp_name} species validated successfully: {validated_species}")
            
        return validated_species
    
    def guess_element(self, mass):
        
        """Simple lookup to guess element from mass for LAMMPS analysis."""
        common_elements = [
            (1.008, 'H'), (4.003, 'He'), (6.941, 'Li'), (9.012, 'Be'),
            (10.811, 'B'), (12.011, 'C'), (14.007, 'N'), (15.999, 'O'),
            (18.998, 'F'), (20.180, 'Ne'), (22.990, 'Na'), (24.305, 'Mg'),
            (26.982, 'Al'), (28.086, 'Si'), (30.974, 'P'), (32.065, 'S'),
            (35.453, 'Cl'), (39.948, 'Ar'), (39.098, 'K'), (40.078, 'Ca'),
            (44.956, 'Sc'), (47.867, 'Ti'), (50.942, 'V'), (51.996, 'Cr'),
            (54.938, 'Mn'), (55.845, 'Fe'), (58.933, 'Co'), (58.693, 'Ni'),
            (63.546, 'Cu'), (65.380, 'Zn'), (69.723, 'Ga'), (72.640, 'Ge'),
            (74.922, 'As'), (78.960, 'Se'), (79.904, 'Br'), (83.798, 'Kr'),
            (85.468, 'Rb'), (87.620, 'Sr'), (88.906, 'Y'), (91.224, 'Zr'),
            (92.906, 'Nb'), (95.960, 'Mo'), (98.000, 'Tc'), (101.070, 'Ru'),
            (102.906, 'Rh'), (106.420, 'Pd'), (107.868, 'Ag'), (112.411, 'Cd'),
            (114.818, 'In'), (118.710, 'Sn'), (121.760, 'Sb'), (127.600, 'Te'),
            (126.904, 'I'), (131.293, 'Xe'), (132.905, 'Cs'), (137.327, 'Ba'),
            (138.905, 'La'), (140.116, 'Ce'), (140.908, 'Pr'), (144.242, 'Nd'),
            (145.000, 'Pm'), (150.360, 'Sm'), (151.964, 'Eu'), (157.250, 'Gd'),
            (158.925, 'Tb'), (162.500, 'Dy'), (164.930, 'Ho'), (167.259, 'Er'),
            (168.934, 'Tm'), (173.054, 'Yb'), (174.967, 'Lu'), (178.490, 'Hf'),
            (180.948, 'Ta'), (183.840, 'W'), (186.207, 'Re'), (190.230, 'Os'),
            (192.217, 'Ir'), (195.084, 'Pt'), (196.967, 'Au'), (200.590, 'Hg'),
            (204.383, 'Tl'), (207.200, 'Pb'), (208.980, 'Bi'), (209.000, 'Po'),
            (210.000, 'At'), (222.000, 'Rn'), (223.000, 'Fr'), (226.000, 'Ra'),
            (227.000, 'Ac'), (232.038, 'Th'), (231.036, 'Pa'), (238.029, 'U'),
            (237.000, 'Np'), (244.000, 'Pu'), (243.000, 'Am'), (247.000, 'Cm'),
            (247.000, 'Bk'), (251.000, 'Cf'), (252.000, 'Es'), (257.000, 'Fm'),
            (258.000, 'Md'), (259.000, 'No'), (262.000, 'Lr'), (267.000, 'Rf'),
            (268.000, 'Db'), (271.000, 'Sg'), (272.000, 'Bh'), (270.000, 'Hs'),
            (276.000, 'Mt'), (281.000, 'Ds'), (280.000, 'Rg'), (285.000, 'Cn'),
            (284.000, 'Nh'), (289.000, 'Fl'), (288.000, 'Mc'), (293.000, 'Lv'),
            (294.000, 'Ts'), (294.000, 'Og')
        ]
        closest_el = "?"
        min_diff = 0.6 
        for m, el in common_elements:
            if abs(mass - m) < min_diff:
                closest_el = el
                min_diff = abs(mass - m)
        return closest_el

    def validate_lammps_data_file(self, manual_path=None):
        """
        Validates a provided LAMMPS DATA file or scans the directory to find one.
        """
        if self.args.LAM_PATH is not None:
            directory = self.args.LAM_PATH
        else:
            directory = os.getcwd()
    
        def is_lammps_data(lines):
            """Check if lines look like a LAMMPS DATA file."""
            lower_lines = [l.lower() for l in lines]
            has_atoms = any("atoms" in l for l in lower_lines)
            has_types = any("atom types" in l for l in lower_lines)
            has_box = any("xlo xhi" in l for l in lower_lines)
            return (has_atoms or has_types) and has_box
    
        def read_head(filepath, num_lines=20):
            try:
                with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                    return [f.readline() for _ in range(num_lines)]
            except Exception:
                return []
    
        # If user provided manual path (via --DATA or function argument), just validate it
        manual_path = manual_path or getattr(self.args, "DATA", None)
        if manual_path:
            if os.path.exists(manual_path) and is_lammps_data(read_head(manual_path)):
                self.args.DATA = os.path.abspath(manual_path)
                return self.args.DATA
            else:
                self.log_message("WARNING", f"Provided DATA file is invalid: {manual_path}")
                # Only ask for manual path if the provided one is invalid
                while True:
                    new_path = input("Please provide a valid LAMMPS DATA file path: ").strip()
                    if os.path.exists(new_path) and is_lammps_data(read_head(new_path)):
                        self.args.DATA = os.path.abspath(new_path)
                        return self.args.DATA
                    self.log_message("ERROR", "Invalid path provided.")
    
        # Auto-scan directory if no manual path provided
        while True:
            n_files = []
            if os.path.exists(directory):
                for filename in os.listdir(directory):
                    filepath = os.path.join(directory, filename)
                    if os.path.isfile(filepath) and is_lammps_data(read_head(filepath)):
                        n_files.append(filepath)
    
            if len(n_files) == 1:
                self.args.DATA = os.path.abspath(n_files[0])
                self.log_message("INFO", f"Found LAMMPS DATA file: {os.path.basename(self.args.DATA)}")
                return self.args.DATA
    
            elif len(n_files) > 1:
                self.log_message("INFO", "Multiple LAMMPS DATA files detected:")
                for i, f in enumerate(n_files, 1):
                    self.log_message("INFO", f"{i}. {os.path.basename(f)}")
    
                choice = input("Enter number, filename, or provide a full path: ").strip()
                if not choice:
                    continue
    
                if choice.isdigit() and 1 <= int(choice) <= len(n_files):
                    self.args.DATA = os.path.abspath(n_files[int(choice) - 1])
                    return self.args.DATA
    
                for cand in n_files:
                    if choice == os.path.basename(cand):
                        self.args.DATA = os.path.abspath(cand)
                        return self.args.DATA
    
                if os.path.exists(choice) and is_lammps_data(read_head(choice)):
                    self.args.DATA = os.path.abspath(choice)
                    return self.args.DATA
    
                self.log_message("ERROR", "Invalid input. Please try again.")
    
            else:
                self.log_message("INFO", "No LAMMPS DATA file detected.")
                new_path = input("Please provide a file path or file name: ").strip()
                if new_path and os.path.exists(new_path) and is_lammps_data(read_head(new_path)):
                    self.args.DATA = os.path.abspath(new_path)
                    return self.args.DATA
                else:
                    self.log_message("ERROR", "Invalid path provided.")

    def load_and_print_system_info_from_lammps_data_file(self):
        
        """
        Prints available atoms/residues for LAMMPS.
        """
        self.validate_lammps_data_file()
                
        self.util_lammps.load_and_parse_data_file()
        
        mass_map   = self.util_lammps.mass_map    
        charge_map = self.util_lammps.charge_map  
        mol_map    = self.util_lammps.mol_map     
        type_map   = self.util_lammps.type_map    
    
        species_counts, total_mols = self.util_lammps.parse_species_counts()
        
        type_to_resname = {}
        
        user_aliases = []
        resname_input = getattr(self.args, "LAMP_SPECIES", None)
        if resname_input:
            tokens = " ".join(resname_input).replace(',', ' ').split()
            user_aliases = [t.strip() for t in tokens if t.strip()]
    
        mol_to_types = collections.defaultdict(list)
        for a_id, m_id in mol_map.items():
            mol_to_types[m_id].append(type_map[a_id])
    
        sig_order = []
        if len(mol_to_types) == 1 and 0 in mol_to_types:
            for a_id in sorted(type_map.keys()):
                sig = (type_map[a_id],)
                if sig not in sig_order: sig_order.append(sig)
        else:
            for m_id in sorted(mol_to_types.keys()):
                if m_id == 0: continue
                sig = tuple(sorted(mol_to_types[m_id]))
                if sig not in sig_order: sig_order.append(sig)
    
        for i, sig in enumerate(sig_order):
            name = user_aliases[i] if i < len(user_aliases) else f"species_{i+1}"
            for t_id in sig:
                type_to_resname[t_id] = name
    
        from collections import Counter

        atom_type_counts = Counter(type_map.values())
        sorted_types = sorted(atom_type_counts.keys())
    
        self.log_message("INFO", "\n" + "="*105)
        self.log_message("INFO", "SYSTEM TOPOLOGY SUMMARY")
        self.log_message("INFO", "="*105)
        
        header = f"{'Resname':<10} | {'Type':<6} | {'Count':<8} | {'Mass':<10} | {'Charge':<8} | {'Atom':<6} | {'Selection'}"
        self.log_message("INFO", header)
        self.log_message("INFO", "-" * 105)
    
        for t in sorted_types:
            count = atom_type_counts[t]
            mass = mass_map.get(t, 0.0)
            resname = type_to_resname.get(t, "Unknown")
            
            example_charge = 0.0
            for a_id, t_id in type_map.items():
                if t_id == t:
                    example_charge = charge_map.get(a_id, 0.0)
                    break
            
            element = self.guess_element(mass) if hasattr(self, 'guess_element') else "?"
            
            selection_str = f"resname {resname} type {t}"
            
            row = f"{resname:<10} | {str(t):<6} | {count:<8} | {mass:<10.3f} | {example_charge:<8.3f} | {element:<6} | {selection_str}"
            self.log_message("INFO", row)
            
        self.log_message("INFO", "="*105 + "\n")

    def check_and_print_system_info(self, universe):
        
        """
        Prints available atoms/residues for GROMACS.
        """
        atoms = universe.atoms
        self.log_message("INFO","\n" + "="*85)
        self.log_message("INFO", f"SYSTEM TOPOLOGY ({'GROMACS'})")
        self.log_message("INFO","="*85)
    
        unique_resnames = np.unique(atoms.resnames)
        
        self.log_message("INFO",f"{'Resname':<10} | {'Type':<8} | {'Name(s)':<15} | {'Count':<8} | {'Mass':<8} | {'Selection Example'}")
        self.log_message("INFO","-" * 85)
        
        for res in unique_resnames:
            res_group = atoms[atoms.resnames == res]
            unique_types = np.unique(res_group.types)
            
            for t in unique_types:
                type_group = res_group[res_group.types == t]
                
                # Get the specific atom names associated with this type (e.g. N1, N2)
                unique_names = np.unique(type_group.names)
                names_str = ",".join(unique_names[:3]) # Show first 3 if many
                if len(unique_names) > 3: names_str += "..."
                
                mass = np.mean(type_group.masses) if hasattr(type_group, 'masses') else 0.0
                
                sel_str = f"resname {res} type {t}"
                self.log_message("INFO", f"{res:<10} | {str(t):<8} | {names_str:<15} | {len(type_group):<8} | {mass:<8.2f} | {sel_str}")

        self.log_message("INFO","="*85 + "\n")

    def validate_system_selections(self, selection_strings, source, context="--rdf_pairs"):
        """
        Validator for advanced MSD and RDF calculations.
        """
        if hasattr(source, 'atoms'):  
            available_resnames = set(map(str, source.residues.resnames))
            available_atomnames = set(map(str, source.atoms.names))
            try: available_atomtypes = set(map(str, source.atoms.types))
            except: available_atomtypes = set()
        elif isinstance(source, pd.DataFrame): 
            if 'type' in source.columns and 'atom_type' not in source.columns:
                source = source.rename(columns={'type': 'atom_type'})
            if 'atom' in source.columns and 'atom_name' not in source.columns:
                source = source.rename(columns={'atom': 'atom_name'})
    
            available_resnames = set(source['res_name'].dropna().astype(str).unique()) if 'res_name' in source.columns else set()
            available_atomnames = set(source['atom_name'].dropna().astype(str).unique()) if 'atom_name' in source.columns else set()
            available_atomtypes = set(source['atom_type'].dropna().astype(str).unique()) if 'atom_type' in source.columns else set()
        else:
            raise ValueError("Source must be an MDA Universe or a Pandas DataFrame")
    
        VALID_KEYWORDS = {'resname', 'name', 'type', 'resid', 'segid', 'protein', 'backbone'}
        error_messages = []
    
        for sel_tuple in selection_strings:
            sel_str = sel_tuple[0] 
            clauses = sel_str.split(' and ')
            
            keyword_errors = False
            for clause in clauses:
                parts = clause.strip().split()
                if len(parts) < 2: continue
                kw, vals = parts[0], [v.strip("'\"") for v in parts[1:]]
                
                if kw not in VALID_KEYWORDS:
                    error_messages.append(f"  Invalid keyword '{kw}' in selection '{sel_str}'.")
                    keyword_errors = True
                    continue
    
                checks = {'resname': available_resnames, 'name': available_atomnames, 'type': available_atomtypes}
                if kw in checks:
                    if not checks[kw]:
                        error_messages.append(f"  System data does not contain '{kw}' info to validate '{clause}'.")
                        keyword_errors = True
                    else:
                        missing = [v for v in vals if v not in checks[kw]]
                        if missing:
                            error_messages.append(f"  {kw.capitalize()} '{', '.join(missing)}' not found in system.")
                            keyword_errors = True
    
            if not keyword_errors:
                matches_found = False
                if hasattr(source, 'atoms'):
                    matches_found = source.select_atoms(sel_str).n_atoms > 0
                elif isinstance(source, pd.DataFrame):
                    mask = pd.Series(True, index=source.index)
                    for clause in clauses:
                        parts = clause.strip().split()
                        if len(parts) < 2: continue
                        kw, vals = parts[0], [v.strip("'\"") for v in parts[1:]]
                        if kw == 'resname': mask &= source['res_name'].astype(str).isin(vals)
                        elif kw == 'name': mask &= source['atom_name'].astype(str).isin(vals)
                        elif kw == 'type': mask &= source['atom_type'].astype(str).isin(vals)
                    matches_found = mask.any()
    
                if not matches_found:
                    error_messages.append(f"  Selection '{sel_str}' matches 0 atoms. "
                                         f"Check if those atom names/types actually belong to that residue.")
    
        if error_messages:
            for msg in sorted(list(set(error_messages))):
                self.log_message("ERROR", msg)
            
            if available_resnames:
                self.log_message("INFO", f"Available Residues: {', '.join(sorted(list(available_resnames))[:20])}...")
            if available_atomtypes:
                self.log_message("INFO", f"Available Types: {', '.join(sorted(list(available_atomtypes))[:20])}...")
    
            self.log_message("INFO", f"\nPlease correct the {context} argument and re-run.\n")
            sys.exit(1)
               
    def validate_species_for_analysis(self):
        """
        Read a single frame to validates resnames for GROMACS or LAMMPS analysis
        """
        needs_rdf = self.args.rdf_mode or self.args.rdf_pairs
        needs_msd = self.args.msd_mode or self.args.msd_species

        if self.args.GRO:
            if self.args.PCL:
                pcl_species1, pcl_species2 = self.args.resname
                validated = self.validate_species_system([pcl_species1, pcl_species2], 'PCL')
                self.args.resname = (validated[0], validated[1])
        
            if self.args.CAGE:
                ca_valid = self.validate_species_system(self.args.CA, 'CA')
                an_valid = self.validate_species_system(self.args.AN, 'AN')
                self.args.CA = ca_valid
                self.args.AN = an_valid
        
            if self.args.CAGE_P:
                cluster_species1, cluster_species2 = self.args.resname
                validated = self.validate_species_system([cluster_species1, cluster_species2], 'CAGE_P')
                self.args.resname = (validated[0], validated[1])
        
            if self.args.VEH:
                species_i, species_j = self.args.resname
                validated = self.validate_species_system([species_i, species_j], 'VEH')
                self.args.resname = (validated[0], validated[1])
                
            if not (needs_rdf or needs_msd):
                return
        
            deps = [(self.args.MDA, "MDAnalysis", "mdanalysis"),
                    (self.args.CHEM, "chemfiles", "chemfiles"),
                    (self.args.OVITO, "ovito", "ovito")]
            
            for flag, pkg_name, install_name in deps:
                if flag:
                    try:
                        __import__(pkg_name if pkg_name != "ovito" else "ovito.io")
                    except ImportError:
                        self.log_message("ERROR", f"{pkg_name} is required but not installed. pip install {install_name}")
                        sys.exit(1)
        
            self.locate_gromacs_files()
            validation_source = None
        
            if self.args.MDA:
                try:
                    import MDAnalysis as mda
                    u = mda.Universe(self.args.TPR, self.args.TRAJ)
                    if u.dimensions is None or np.all(u.dimensions[:3] == 0):
                        self.log_message("WARNING", "Input file(s) lack box dimension information.")
                    validation_source = u
                except ImportError:
                    self.log_message("ERROR", "MDAnalysis is required for --mda but not installed.")
                    sys.exit(1)

            elif self.args.CHEM:
                try:
                    import chemfiles
                    topo_path = self.args.TPR if self.args.TPR else self.args.TRAJ
                    
                    with chemfiles.Trajectory(topo_path) as traj:
                        frame = traj.read()
                        
                        full_res_names = []
                        full_atom_names = []
                        full_atom_types = []

                        atom_to_res = {}
                        for res in frame.topology.residues:
                            name = str(res.name).strip()
                            for atom_idx in res.atoms:
                                atom_to_res[atom_idx] = name

                        for i, atom in enumerate(frame.atoms):
                            a_name = str(atom.name).strip()
                            a_type = str(atom.type).strip() if atom.type else a_name
                            r_name = atom_to_res.get(i, "UNKNOWN")
                            
                            full_atom_names.append(a_name)
                            full_atom_types.append(a_type)
                            full_res_names.append(r_name)

                        validation_source = pd.DataFrame({
                            'res_name': full_res_names,
                            'atom_name': full_atom_names,
                            'atom_type': full_atom_types
                        })

                except ImportError:
                    self.log_message("ERROR", "Chemfiles is required for --chem but not installed.")
                    sys.exit(1)
                except Exception as e:
                    self.log_message("ERROR", f"Chemfiles failed to read topology: {e}")
                    sys.exit(1)
        
            elif self.args.OVITO or self.args.PDB:
                df_mass_full, _, _ = self.util_gromacs.calculate_charges_from_itp_files(self.args.ITP)
                validation_source = df_mass_full
        
            elif self.args.EXE:
                with tempfile.NamedTemporaryFile(prefix=".atom_info_", suffix=".xvg", delete=False) as tmp:
                    hidden_dump_file = tmp.name
                try:
                    command = f"{self.args.EXE} dump -s {self.args.TPR}"
                    with open(hidden_dump_file, "w") as outfile:
                        subprocess.run(command, shell=True, check=True, stdout=outfile, stderr=subprocess.PIPE)
                    df, _, _ = self.util_gromacs.calculate_charges(input_file=hidden_dump_file)
                    validation_source = df
                finally:
                    if os.path.exists(hidden_dump_file): os.remove(hidden_dump_file)

            if validation_source is not None:
                if needs_rdf:
                    sels = parse_selection_pairs(self.args.rdf_pairs, self.args.rdf_mode, context="RDF")
                    self.validate_system_selections(sels, validation_source, context="--rdf_pairs")
                if needs_msd:
                    sels = parse_selection_pairs(self.args.msd_species, self.args.msd_mode, context="MSD")
                    self.validate_system_selections(sels, validation_source, context="--msd_mode")

        elif self.args.LAM:
            if self.args.PCL:
                pcl_species1, pcl_species2 = self.args.resname
                validated = self.validate_species_system([pcl_species1, pcl_species2], 'PCL')
                self.args.resname = (validated[0], validated[1])
        
            if self.args.CAGE:
                ca_valid = self.validate_species_system(self.args.CA, 'CA')
                an_valid = self.validate_species_system(self.args.AN, 'AN')
                self.args.CA = ca_valid
                self.args.AN = an_valid
        
            if self.args.CAGE_P:
                cluster_species1, cluster_species2 = self.args.resname
                validated = self.validate_species_system([cluster_species1, cluster_species2], 'CAGE_P')
                self.args.resname = (validated[0], validated[1])
        
            if self.args.VEH:
                species_i, species_j = self.args.resname
                validated = self.validate_species_system([species_i, species_j], 'VEH')
                self.args.resname = (validated[0], validated[1])

            if needs_rdf or needs_msd:
                self.util_lammps.load_and_parse_data_file()
                species_counts, _ = self.util_lammps.parse_species_counts()
                
                mol_to_types = collections.defaultdict(list)
                for a_id, m_id in self.util_lammps.mol_map.items():
                    mol_to_types[m_id].append(str(self.util_lammps.type_map[a_id]))
                
                sig_to_name = {}
                sig_order = []
                m_ids_sorted = sorted(mol_to_types.keys())
                for m_id in m_ids_sorted:
                    if m_id == 0 and len(mol_to_types) > 1: continue
                    sig = tuple(sorted(mol_to_types[m_id]))
                    if sig not in sig_to_name:
                        sig_to_name[sig] = f"species_{len(sig_order)+1}"
                        sig_order.append(sig)
                
                user_aliases = []
                if getattr(self.args, "LAMP_SPECIES", None):
                    user_aliases = [t.strip() for t in " ".join(self.args.LAMP_SPECIES).replace(',', ' ').split() if t.strip()]
                
                mapping_rows = []
                for sig, default_name in sig_to_name.items():
                    idx = int(default_name.split('_')[1]) - 1
                    final_name = user_aliases[idx] if idx < len(user_aliases) else default_name
                    for t_id in sig:
                        mapping_rows.append({'res_name': final_name, 'atom_type': t_id})
                
                validation_source = pd.DataFrame(mapping_rows).drop_duplicates()

                if needs_rdf:
                    sels = parse_selection_pairs(self.args.rdf_pairs, self.args.rdf_mode, context="RDF")
                    self.validate_system_selections(sels, validation_source, context="--rdf_pairs")
                
                if needs_msd:
                    msd_data = parse_selection_pairs(self.args.msd_species, self.args.msd_mode, context="MSD")
                    sels = [sel for sel, com in msd_data]
                    self.validate_system_selections(sels, validation_source, context="--msd_mode")
        
        return

    def species_for_analysis(self):
                
        """
        Read a single frame to show availaible resnames for GROMACS analysis
        """
        if self.args.PCL or self.args.CAGE or self.args.CAGE_P or self.args.VEH:
            t_start = 0
            t_end = 1
            self.preallocated_data, self.box_df, self.species_charges, self.species_counts, self.dt, self.unique_resnames, self.inv_mol_id_map, self.system_mass, self.species_masses = self.get_system_info(t_start, t_end, valid_species=True)
            known_species = list(self.species_counts.keys())
            self.log_message("INFO", f"       Available species are: {known_species}\n")
        return
    
    def get_system_info(self, t_start, t_end, valid_species=False, return_atoms=False):
                
        """
        Function to get information of GROMACS files and run gmx command to generate pdb file and process pdb file to extract species coordinates
        
        """
        result = None
        tpr_file = None
        traj_file = None
                        
        dt = int(self.args.t_steps)

        if self.args.EXE or self.args.MDA:
            exe_file = str(self.args.EXE)
            self.locate_gromacs_files()
            tpr_file, traj_file = self.args.TPR, self.args.TRAJ

            if self.args.EXE:
    
                RED = '\033[91m'
                BLUE = '\033[34m'
                CYAN = '\033[96m'
                RESET = '\033[0m'
                
                try:
                    with tempfile.NamedTemporaryFile(prefix=".atom_info_", suffix=".xvg", delete=False) as tmp:
                        hidden_dump_file = tmp.name  
                
                    command = f"{exe_file} dump -s {tpr_file}"
                    with open(hidden_dump_file, "w") as outfile:
                        subprocess.run(
                            command,
                            shell=True,
                            check=True,
                            stdout=outfile,          
                            stderr=subprocess.PIPE   
                        )
                except subprocess.CalledProcessError as e:

                    if e.returncode == 127 or "command not found" in e.stderr.decode().lower():
                        self.print_gromacs_not_found_error(exe_file, command.split())
                        self.log_message("ERROR", f"{RED}GROMACS executable '{exe_file}' not found. Aborting.{RESET}")
                        sys.exit(1)
                
                    else:
                
                        error_details = e.stderr.decode().strip()
                
                        self.log_message("INFO",f"\n{RED}==============================================={RESET}")
                        self.log_message("INFO",f"{RED}==============================================={RESET}\n")
                        self.log_message("INFO",f"The command '{CYAN}{command}{RESET}' failed to execute properly.\n")
                        self.log_message("INFO",f"{BLUE}This often means there is an issue with your input TPR file ('{tpr_file}').{RESET}")
                        self.log_message("INFO","Please review the GROMACS error message below for details.\n")
                        self.log_message("INFO",f"{RED}--- GROMACS Error Output ---{RESET}")
                        self.log_message("INFO",error_details, file=sys.stderr)
                        self.log_message("INFO",f"{RED}----------------------------{RESET}\n")
                        self.log_message("ERROR", f"GROMACS stderr: {error_details}")
                        sys.exit(1)
    
                command_list = [
                    exe_file,
                    "trjconv",
                    "-f",
                    traj_file,
                    "-s",
                    tpr_file,
                    "-dt",
                    str(dt),
                    "-o",
                    "traj.pdb",
                    "-pbc",
                    "mol",
                ]
    
                if valid_species:
                    command_list.extend(["-b", str(t_start), "-e", str(t_end)])
                    
                if self.args.n_steps and not valid_species:
                    command_list.extend(["-b", str(t_start), "-e", str(t_end)])
                        
                display_command_list = [
                os.path.basename(arg) if arg in [tpr_file, traj_file, exe_file] else arg
                for arg in command_list]

                try:
                    self.log_message("DEBUG", f"\nRunning GROMACS command: {' '.join(display_command_list)}")
    
                    total_duration = 0
                    if t_end is not None and t_start is not None:
                        total_duration = t_end - t_start
                    elif t_end is not None:
                        total_duration = t_end
    
                    process = subprocess.Popen(
                        command_list,
                        stdin=subprocess.PIPE,   
                        stdout=subprocess.DEVNULL, 
                        stderr=subprocess.PIPE,  
                        text=True,
                        bufsize=1                
                    )
    
                    try:
                        process.stdin.write("0\n")
                        process.stdin.flush()
                        process.stdin.close() 
                    except (OSError, BrokenPipeError):
                        pass
    
                    last_time_seen = t_start if t_start else 0
                    error_buffer = []
                    
                    with tqdm(total=total_duration, unit="ps", desc="Generating PDB", leave=True) as pbar:
                        while True:
                            line = process.stderr.readline()
                            
                            # Break if process finished and no lines left
                            if not line and process.poll() is not None:
                                break
                            
                            if line:
                                error_buffer.append(line)
                                if len(error_buffer) > 20:
                                    error_buffer.pop(0)
    
                                time_match = re.search(r"time\s+([\d\.]+)", line, re.IGNORECASE)
                                if time_match:
                                    try:
                                        current_time = float(time_match.group(1))
                                        increment = current_time - last_time_seen
                                        if increment > 0:
                                            pbar.update(increment)
                                            last_time_seen = current_time
                                    except ValueError:
                                        pass
    
                    if process.returncode != 0:
                        err_rest = "".join(error_buffer)
                        raise subprocess.CalledProcessError(process.returncode, command_list, stderr=err_rest)
    
                except FileNotFoundError:
                    gmx_executable = command_list[0]
                    self.print_gromacs_not_found_error(gmx_executable, display_command_list)
                    sys.exit(1)
                
                except subprocess.CalledProcessError as e:
                    self.log_message("INFO",f"\n{RED}--- ERROR: GROMACS command failed with an internal error! ---{RESET}\n")
                    self.log_message("INFO",f"The command '{CYAN}{' '.join(display_command_list)}{RESET}' ran but reported an error.\n")
                    self.log_message("INFO",f"{RED}--- GROMACS Error Output (stderr) ---{RESET}")
                    self.log_message("INFO", e.stderr) 
                    self.log_message("INFO",f"{RED}------------------------------------{RESET}\n")
                    
                    self.log_message("ERROR", f"GROMACS stderr: {e.stderr.strip()}")
                    sys.exit(1)
    
                result = self.util_gromacs.from_pdb_and_itp(t_start, t_end, valid_species, return_atoms, hidden_dump_file)
                if os.path.exists("traj.pdb"):
                    os.remove("traj.pdb")
                if os.path.exists(hidden_dump_file):
                    os.remove(hidden_dump_file) 
            else:
                result = self.util_gromacs.from_gromacs_to_species_files(tpr_file, traj_file, t_start, t_end, valid_species, return_atoms)

        elif self.args.CHEM:
            result = self.util_gromacs.from_gromacs_to_cheme_files(t_start, t_end, valid_species, return_atoms)
            
        elif self.args.OVITO:
            result = self.util_gromacs.from_gromacs_to_ovito(t_start, t_end, valid_species, return_atoms)
                                        
        elif self.args.PDB:
            result = self.util_gromacs.from_pdb_and_itp(t_start, t_end, valid_species, return_atoms)
            
        if result is None:
            self.log_message("INFO",
                "\n\033[91mFATAL ERROR: The system info utility function did not return a value.\033[0m"
            )
            self.log_message("INFO",
                "Please check the implementation in 'src/util_gromacs.py' and ensure it has a 'return' statement.\n"
            )
            self.log_message(
                "FATAL",
                "A 'util_gromacs' method returned None. Aborting.",
                )
            sys.exit(1)

        return result

    def check_and_print_system_info_from_pdb_and_itp(self):
        
        """
        Extracts and prints system topology information.
        """
        if self.args.PDB:
            pdb_file =self.locate_pdb_file()
        itp_dir = self.args.ITP
        t_start, t_end = 0, 1
        
        dump_file = None
        final_ordered_names = []
        df_mass_full = pd.DataFrame()
            
        if not (self.args.OVITO or self.args.CHEM):
            if self.args.EXE:
                exe_file = str(self.args.EXE)
                self.locate_gromacs_files()
                tpr, traj = self.args.TPR, self.args.TRAJ

                try:
                    with tempfile.NamedTemporaryFile(prefix=".atom_info_", suffix=".xvg", delete=False) as tmp:
                        dump_file = tmp.name

                    cmd = f"{exe_file} dump -s {tpr}"
                    subprocess.run(cmd, shell=True, check=True,
                                   stdout=open(dump_file, "w"), stderr=subprocess.PIPE)

                except subprocess.CalledProcessError as e:
                    err = e.stderr.decode().strip().lower()
                    if e.returncode == 127 or "command not found" in err:
                        self.log_message("ERROR", f"GROMACS executable '{exe_file}' not found.")
                    else:
                        self.log_message("INFO", f"TPR dump failed:\n{err}", file=sys.stderr)
                    sys.exit(1)
                    
                cmd = [
                    exe_file, "trjconv",
                    "-f", traj, "-s", tpr,
                    "-o", "traj.pdb",
                    "-pbc", "mol",
                    "-b", str(t_start),
                    "-e", str(t_end)
                ]
                try:
                    subprocess.run(cmd, input="0\n", check=True, text=True, capture_output=True)
                    pdb_file = "traj.pdb"
                except FileNotFoundError:
                    self.log_message("ERROR", f"GROMACS executable '{exe_file}' not found.")
                    sys.exit(1)
                except subprocess.CalledProcessError as e:
                    self.log_message("ERROR", f"trjconv failed: {e.stderr}")
                    sys.exit(1)

            # Parse PDB for species order
            if not pdb_file.lower().endswith(".pdb"):
                self.log_message("ERROR", f"Found {pdb_file} file. Please provide a PDB file when using the --pdb flag.")
                sys.exit(1)
            full_snapshot_generator = self.util_gromacs.snapshot_generator(pdb_file, t_start, t_end)
            try:
                first_snapshot = next(full_snapshot_generator)
            except StopIteration:
                self.log_message("ERROR", "No snapshots found. Exiting.")
                return 

            _, pdb_species_order, _ = self.util_gromacs.get_mappings_from_snapshot(first_snapshot)

            # Get Masses
            if self.args.EXE:
                df_mass_full, _, _ = self.util_gromacs.calculate_charges(input_file=dump_file)
                if os.path.exists("traj.pdb"):
                    os.remove("traj.pdb")
            else:
                df_mass_full, _, _ = self.util_gromacs.calculate_charges_from_itp_files(itp_dir)

            # Match PDB names to Mass Table names
            itp_names = df_mass_full["res_name"].unique()
            for pdb_name in pdb_species_order:
                found = False
                for itp_name in itp_names:
                    if itp_name.startswith(pdb_name):
                        final_ordered_names.append(itp_name)
                        found = True
                        break
                if not found:
                    self.log_message("WARNING", f"PDB residue '{pdb_name}' not found in ITP/Dump.")

            if df_mass_full.empty:
                raise ValueError("Could not load mass information.")
    
            # Filter df_mass_full to only include identified species
            df_mass_full = df_mass_full[df_mass_full['res_name'].isin(final_ordered_names)].copy()
            
            # Sort according to discovery order
            df_mass_full["res_name"] = pd.Categorical(
                df_mass_full["res_name"], categories=final_ordered_names, ordered=True
            )
            df_mass_full = df_mass_full.sort_values("res_name").reset_index(drop=True)
            df_mass_full.drop_duplicates(subset=["res_name", "atom"], inplace=True)
            
            # Group for printing
            df_grouped = df_mass_full.groupby(['res_name', 'type'], observed=True).agg({
                'atom': lambda x: ', '.join(x.astype(str)), 
                'mass': 'first',
                'q': 'first'
            }).reset_index()
    
            df_grouped.dropna(subset=['mass'], inplace=True)
    
            self.log_message("INFO", "="*85)
            self.log_message("INFO", "SYSTEM TOPOLOGY")
            self.log_message("INFO", "="*85)
            
            self.log_message("INFO",f"{'Resname':<8} | {'Type':<6} | {'Name (s)':<15} | {'Mass':<10} | {'Charge':<10} | {'Selection Example'}")
            self.log_message("INFO","-" * 85)
    
            for i, row in df_grouped.iterrows():
                sel_str = f"resname {row['res_name']} type {row['type']}"
                self.log_message("INFO", 
                      f"{row['res_name']:<8} | "
                      f"{row['type']:<6} | "
                      f"{row['atom']:<15} | "
                      f"{row['mass']:<10.3f} | "
                      f"{row['q']:<10.3f} | "
                      f"{sel_str}"
                )
            self.log_message("INFO","="*85)
            
            # Cleanup
            if dump_file and os.path.exists(dump_file):
                os.remove(dump_file)
          
        elif self.args.CHEM:
            try:
                import chemfiles
            except ImportError:
                self.log_message("ERROR","Error: Chemfiles is required for this feature (--chem) but is not installed.")
                self.log_message("INFO","Please install it to proceed.")
                self.log_message("INFO","\nTo install using pip:")
                self.log_message("INFO","  pip install chemfiles")
                self.log_message("INFO","\nTo install using conda:")
                self.log_message("INFO","  conda install -c conda-forge chemfiles")
                self.log_message("INFO","-------------------------------------")
                sys.exit(1)

            self.locate_gromacs_files()
            tpr_file = self.args.TPR
            self.log_message("DEBUG", f"Reading topology directly from TPR: {tpr_file}")
            
            df_mass_full = self.util_gromacs.get_system_topology(tpr_file)

            if df_mass_full.empty:
                self.log_message("ERROR", "Could not load topology information.")
                if dump_file and os.path.exists(dump_file): os.remove(dump_file)
                return
    
            self.log_message("INFO", "="*85)
            self.log_message("INFO", "SYSTEM TOPOLOGY")
            self.log_message("INFO", "="*85)
    
            h_res, h_charge, h_name = "Resname", "Charge", "Name(s)"
            h_count, h_mass, h_sel = "Count", "Mass", "Selection Example"
            
            self.log_message("INFO", f"{h_res:<10} | {h_name:<15} | {h_count:<8} | {h_mass:<8} | {h_charge:<8} | {h_sel}")
            self.log_message("INFO", "-"*85)
    
            unique_resnames = df_mass_full['res_name'].unique()
    
            for res_name in unique_resnames:
                res_df = df_mass_full[df_mass_full['res_name'] == res_name]
                
                grouped = res_df.groupby('atom', sort=True)
                
                for atom_name, group in grouped:
                    count = len(group)
                    mass = group.iloc[0]['mass']
                    charge = group.iloc[0]['q']  # CHANGED: Get Charge
                    
                    names_str = atom_name 
                    sel_example = f"resname {res_name} name {atom_name}"
                    
                    self.log_message("INFO", 
                        f"{res_name:<10} | "
                        f"{names_str:<15} | "
                        f"{count:<8} | "
                        f"{mass:<8.2f} | "
                        f"{charge:<8.4f} | "  
                        f"{sel_example}"
                    )
    
            self.log_message("INFO", "="*85)
                
        return
            
    def print_species_for_analysis(self):
                    
        """
        Print resname, atoms, types for GROMACS and LAMMPS
        """
        if self.args.MDA and self.args.GRO:
            try:
                import MDAnalysis as mda
            except ImportError:
                self.log_message("ERROR", "MDAnalysis is required when using --mda.")
                self.log_message("INFO","Please install it to proceed or use other available options.")
                self.log_message("INFO","\nTo install using pip:")
                self.log_message("INFO","  pip install MDAnalysis")
                self.log_message("INFO","\nTo install using conda:")
                self.log_message("INFO","  conda install -c conda-forge mdanalysis")
                self.log_message("INFO","-------------------------------------")
                sys.exit(1)
            
            if self.args.GRO:
                self.locate_gromacs_files()
                topology_file = self.args.TPR
                trajectory_file = self.args.TRAJ
            else:
                topology_file = self.args.DATA
                trajectory_file = self.args.TRAJ
    
            # Load Universe with Warning Suppression for LAMMPS
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                
                u = mda.Universe(topology_file, trajectory_file)
    
            self.check_and_print_system_info(u)
        
        elif self.args.LAM:
            self.load_and_print_system_info_from_lammps_data_file()
            
        elif self.args.CHEM and self.args.GRO:
            self.check_and_print_system_info_from_pdb_and_itp()
            
        elif self.args.PDB and self.args.GRO:
            self.check_and_print_system_info_from_pdb_and_itp()

        elif self.args.OVITO and self.args.GRO:
            self.check_and_print_system_info_from_pdb_and_itp()
            
        elif self.args.EXE and self.args.GRO:
            self.check_and_print_system_info_from_pdb_and_itp()
