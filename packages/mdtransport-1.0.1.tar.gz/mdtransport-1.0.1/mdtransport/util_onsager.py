#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Wed Nov 19 15:21:36 2025

@author: Shah Research Group, Oklahoma State University <jindal.shah@okstate.edu>

MDTransport: GROMACS & LAMMPS Transport Analysis Tools
Copyright (C) 2026 Ashutosh Kumar Verma, Amey Thorat and Jindal Shah

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
"""

import ctypes
import numpy as np
import pandas as pd
import multiprocessing
from .util import BaseAnalysis, tqdm

# Global dictionary for workers
_onsager_shared_data = {}

def init_onsager_EH(dipole_buf, dipole_shape, self_msd_buf, self_msd_shape):
    """
    Initialize global shared data in each worker using Shared Memory.
    """
    global _onsager_shared_data
    _onsager_shared_data['dipoles'] = np.frombuffer(dipole_buf, dtype=np.float64).reshape(dipole_shape)
    _onsager_shared_data['self_msd'] = np.frombuffer(self_msd_buf, dtype=np.float64).reshape(self_msd_shape)

def init_onsager_EN(shared_buf, shape, species_map, ref_indices, ref_masses):
    """
    Initialize global shared data in each worker using Shared Memory.
    """
    global _onsager_shared_data
    _onsager_shared_data['coords'] = np.frombuffer(shared_buf, dtype=np.float64).reshape(shape)
    _onsager_shared_data['species_map'] = species_map
    _onsager_shared_data['ref_indices'] = ref_indices
    _onsager_shared_data['ref_masses'] = ref_masses

def get_msd_fft(coords):
    """FFT-based sliding window MSD."""
    N = len(coords)
    sq_coords = np.sum(coords**2, axis=1)
    s1 = np.zeros(N, dtype=np.float64)
    sq_cum = np.cumsum(np.insert(sq_coords, 0, 0))
    for m in range(N):
        s1[m] = (sq_cum[N] - sq_cum[m]) + (sq_cum[N-m])
    s2 = np.zeros(N, dtype=np.float64)
    n_fft = 2**int(np.ceil(np.log2(2*N-1)))
    for d in range(coords.shape[1]):
        f = np.fft.fft(coords[:, d], n=n_fft)
        ac = np.fft.ifft(f * np.conjugate(f))[:N].real
        s2 += ac
    return (s1 - 2 * s2) / np.arange(N, 0, -1)

def calculate_delta_EN(args):
    """
    Function to process one delta at a time using a Mass-Weighted Reference Frame.
    """
    delta, dt = args
    coords = _onsager_shared_data['coords']
    species_map = _onsager_shared_data['species_map']
    ref_idx = _onsager_shared_data['ref_indices']
    ref_mass = _onsager_shared_data['ref_masses']
    
    num_mols, n_steps, dim = coords.shape
    current_time = delta * dt

    if delta == 0:
        results = []
        for i in range(len(species_map)):
            results.append(('self', i, i, 0.0, 0.0))
            for j in range(i, len(species_map)):
                results.append(('cross', i, j, 0.0, 0.0))
        return results

    n_frames = n_steps - delta
    
    avg_ref_dr = np.zeros((n_frames, dim), dtype=np.float64)
    if ref_idx is not None:
        for i, m in enumerate(ref_idx):
            dr_m = coords[m, delta:] - coords[m, :n_frames]
            avg_ref_dr += dr_m * ref_mass[i]
        avg_ref_dr /= np.sum(ref_mass)

    sum_dr_species = np.zeros((len(species_map), n_frames, dim), dtype=np.float64)
    self_acc = np.zeros(len(species_map), dtype=np.float64)

    for s_idx, indices in enumerate(species_map):
        for m in indices:
            # Correct slicing: delta: and :n_frames (which is n_steps - delta)
            dr_m = (coords[m, delta:] - coords[m, :n_frames]) - avg_ref_dr
            self_acc[s_idx] += np.sum(dr_m**2)
            sum_dr_species[s_idx] += dr_m

    results = []
    for i in range(len(species_map)):
        s_val = self_acc[i] / n_frames
        results.append(('self', i, i, current_time, s_val))
        for j in range(i, len(species_map)):
            dot_ij = np.sum(sum_dr_species[i] * sum_dr_species[j]) / n_frames
            val = (dot_ij - s_val) if i == j else 2.0 * dot_ij
            results.append(('cross', i, j, current_time, val))
    return results

def calculate_delta_EH(args):
    """
    Function to process one delta at a time using a Mass-Weighted Reference Frame and EH.
    """
    delta, dt = args
    dipoles = _onsager_shared_data['dipoles']
    self_msds = _onsager_shared_data['self_msd']
    num_species, n_steps, dim = dipoles.shape
    current_time = delta * dt

    if delta == 0:
        results = []
        for i in range(num_species):
            results.append(('self', i, i, 0.0, 0.0))
            for j in range(i, num_species):
                results.append(('cross', i, j, 0.0, 0.0))
        return results

    n_frames = n_steps - delta
    delta_D = dipoles[:, delta:] - dipoles[:, :n_frames]
    
    results = []
    for i in range(num_species):
        s_val = self_msds[i, delta]
        results.append(('self', i, i, current_time, s_val))
        for j in range(i, num_species):
            dot_ij = np.sum(delta_D[i] * delta_D[j]) / n_frames
            val = (dot_ij - s_val) if i == j else 2.0 * dot_ij
            results.append(('cross', i, j, current_time, val))
    return results

class UTIL_ONSAGER(BaseAnalysis):
            
    """
    This is a UTIL_ONSAGER class which perform Onsager transport coefficients analysis
    """
    def __init__(self, args):
                                
        """
        Initialize class with input arguments and class objects
        """
        super().__init__(args)
        self.n_cores = self.args.n_cores
        
    def slope_calculations(self, species_names, K_Onsg, dt, results_data, dim):
        """
        Calculates slopes and their standard errors.
        """
        max_index = int(self.args.t_window / dt + 1)
        scale_factor = K_Onsg * (10 ** 11) / dim
        slopes_data = {}

        self.log_message("INFO", "=" * 80)
        self.log_message("INFO", "         Onsager Transport Coefficients Summary")
        self.log_message("INFO", "=" * 80)
        for key, values in results_data.items():
            data = np.array(values)
            if len(data) < 3: continue
            data = data[data[:, 0].argsort()]
            end = min(len(data), max_index)
            popt, pcov = np.polyfit(data[1:end, 0], data[1:end, 1], 1, cov=True)
            val, err = popt[0] * scale_factor, np.sqrt(pcov[0,0]) * scale_factor
            slopes_data[key] = (val, err)
            self.log_message("INFO", f" {key:<25} : {val:.6f} ± {err:.6f} (10⁻¹¹ mol²·s/(kg·m³))")
            
        self.log_message("INFO", "=" * 80 + "\n")
        pd.DataFrame([{"Term": k, "Val (10⁻¹¹ mol²·s/(kg·m³))": v[0], "Err (10⁻¹¹ mol²·s/(kg·m³))": v[1]} for k, v in slopes_data.items()]).to_csv("results_onsager_coefficients/summary_onsager.csv", index=False)

    def calculate_onsager(self, COM_data, box_df, dt, species_counts, species_charges, n_delta, K_ONSG, drift, wrap_requested, charge_requested):
        """
        Calculates Onsager transport coefficients for specific directions.
        """
        directions = list(self.args.DIR) if (hasattr(self.args, 'DIR') and self.args.DIR) else ["x", "y", "z"]
        dir_indices = [{"x":0,"y":1,"z":2}[d.lower()] for d in directions]
        dim, n_steps, num_mols = len(dir_indices), COM_data.shape[0], COM_data.shape[1]
        species_names = list(species_counts.keys())
        boxes = box_df[["Lx", "Ly", "Lz"]].values.astype(np.float64)[:, dir_indices]
        c_slice = slice(0, 3) if getattr(self.args, 'LAM', False) else slice(1, 4)

        ref_indices, ref_masses = None, None
        if hasattr(self.args, 'CA') and self.args.CA and self.args.CA[0] in species_names:
            ref_idx_in_map = species_names.index(self.args.CA[0])
            start_pos = sum(list(species_counts.values())[:ref_idx_in_map])
            ref_indices = list(range(start_pos, start_pos + species_counts[self.args.CA[0]]))
            m_val = getattr(self, 'species_masses', {}).get(self.args.CA[0], 1.0)
            ref_masses = np.full(len(ref_indices), m_val, dtype=np.float64)

        if self.args.EH:
            ref_dr_total = np.zeros((n_steps, dim))
            if ref_indices:
                for idx in ref_indices:
                    r = self.unwrap_on_the_fly(COM_data[:, idx, c_slice][:, dir_indices], boxes)
                    ref_dr_total += r * getattr(self, 'species_masses', {}).get(self.args.CA[0], 1.0)
                ref_dr_total /= (len(ref_indices) * getattr(self, 'species_masses', {}).get(self.args.CA[0], 1.0))

            dipole_arr = np.zeros((len(species_names), n_steps, dim), dtype=np.float64)
            self_msd_arr = np.zeros((len(species_names), n_steps), dtype=np.float64)
            
            curr = 0
            for s_idx, s_name in enumerate(species_names):
                for i in tqdm(range(species_counts[s_name]), desc=f"Aggregating {s_name} Dipole"):
                    r = self.unwrap_on_the_fly(COM_data[:, curr+i, c_slice][:, dir_indices], boxes)
                    r_rel = r - ref_dr_total if ref_indices else r
                    dipole_arr[s_idx] += r_rel
                    self_msd_arr[s_idx] += get_msd_fft(r_rel)
                curr += species_counts[s_name]

            shm_args = (multiprocessing.RawArray(ctypes.c_double, dipole_arr.size), dipole_arr.shape,
                        multiprocessing.RawArray(ctypes.c_double, self_msd_arr.size), self_msd_arr.shape)
            np.frombuffer(shm_args[0], dtype=np.float64)[:] = dipole_arr.flatten()
            np.frombuffer(shm_args[2], dtype=np.float64)[:] = self_msd_arr.flatten()
            w_init, w_func = init_onsager_EH, calculate_delta_EH
            max_delta = int(n_steps)
        else:
            shm_buf = multiprocessing.RawArray(ctypes.c_double, num_mols * n_steps * dim)
            shared_arr = np.frombuffer(shm_buf, dtype=np.float64).reshape((num_mols, n_steps, dim))
            for m in tqdm(range(num_mols), desc="Loading DATA"):
                r = self.unwrap_on_the_fly(COM_data[:, m, c_slice][:, dir_indices], boxes)
                if drift is not None: r -= (drift[:, dir_indices] if drift.ndim > 1 else drift[dir_indices])
                shared_arr[m] = r
            species_map, curr = [], 0
            for count in species_counts.values():
                species_map.append(list(range(curr, curr+count))); curr += count
            shm_args = (shm_buf, shared_arr.shape, species_map, ref_indices, ref_masses)
            w_init, w_func = init_onsager_EN, calculate_delta_EN
            max_delta = min(int(max(n_delta, 1000)/dt+1), n_steps)

        tasks = [(d, dt) for d in range(0, max_delta, self.args.steps)]
        res_store = {} 
        
        ctx = multiprocessing.get_context(self.args.get_context)
        with ctx.Pool(processes=self.n_cores, initializer=w_init, initargs=shm_args) as pool:
            for delta_res in tqdm(pool.imap_unordered(w_func, tasks), total=len(tasks), desc="Calculating Onsager Coeff."):
                for r_type, i, j, t, val in delta_res:
                    key = f"self_{species_names[i]}" if r_type == 'self' else f"cross_{species_names[i]}_{species_names[j]}"
                    if key not in res_store: res_store[key] = []
                    res_store[key].append([t, val])

        self.generate_folders("results_onsager_coefficients")
        for key, vals in res_store.items():
            pd.DataFrame(sorted(vals), columns=["delta", "product"]).to_csv(f"results_onsager_coefficients/{key}.csv", index=False)
        self.slope_calculations(species_names, K_ONSG, dt, res_store, dim=dim)