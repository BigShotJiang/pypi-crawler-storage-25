#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Wed Nov 19 15:21:36 2025

@author: Shah Research Group, Oklahoma State University <jindal.shah@okstate.edu>

MDTransport: GROMACS & LAMMPS Transport Analysis Tools
Copyright (C) 2026  Ashutosh Kumar Verma, Amey Thorat and Jindal Shah

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
"""
import os
import sys
import shutil
import argparse
import multiprocessing
from functools import wraps
from .gromacs import GROMACS
from .lammps import LAMMPS
from .util import logger, logged_input
from .util_validator import Validator

class ScriptState:
    had_interactive_input = False

class MDTransportParser(argparse.ArgumentParser):
    def error(self, message):
        logger.error(f"Argument Error: {message}", extra={'caller': 'MDTransport'})
        sys.exit(2)

class CaseInsensitiveArgumentParser(MDTransportParser):
    def get_option_tuples(self, option_string):
        if option_string.startswith('--'): option_string = option_string.lower()
        return super().get_option_tuples(option_string)

class ValidateArgs(argparse.Action):
    def __init__(self, option_strings, dest, nargs=None, type=None, on_dash_error=None, **kwargs):
        self._type = type
        self._on_dash_error_msg = on_dash_error
        if nargs is None: raise ValueError("nargs is required for this action")
        super().__init__(option_strings, dest, nargs=nargs, **kwargs)

    def __call__(self, parser, namespace, values, option_string=None):
        for value in values:
            if str(value).startswith("--"):
                msg = self._on_dash_error_msg.format(option_string=option_string) if self._on_dash_error_msg else f"Missing valid values after {option_string}"
                parser.error(msg)
        try:
            converted = [self._type(v) for v in values] if self._type else values
            setattr(namespace, self.dest, converted)
        except ValueError:
            parser.error(f"Invalid type after {option_string}")

def print_banner():
    msg = (
        "MDTransport: GROMACS & LAMMPS Transport Analysis Tools\n"
        "Copyright (C) 2026  Ashutosh Kumar Verma, Amey Thorat and Jindal Shah\n\n"
        "Oklahoma State University, Stillwater, OK 74078.\n"
        "This is free software, and you are welcome to redistribute it\n"
        "under certain conditions. See the GNU GPL for details.\n"
    )
    separator = "=" * 80
    logger.info(separator, extra={'caller': 'MDTransport'})
    logger.info(msg.rstrip(), extra={'caller': 'MDTransport'})
    logger.info(separator, extra={'caller': 'MDTransport'})

def handle_user_cancel(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        try: return func(*args, **kwargs)
        except (KeyboardInterrupt, EOFError):
            logger.error("\nUser cancelled input. Exiting...", extra={'caller': 'MDTransport'})
            sys.exit(0)
    return wrapper

@handle_user_cancel
def get_input(prompt_msg, expected_type=str, default=None, allow_blank=False, min_len=None, max_len=None, positive=False, options_dict=None, expect_value=False):
    """A unified input prompt for selection, numeric, and list."""
    ScriptState.had_interactive_input = True
    while True:
        logger.info(prompt_msg, extra={'caller': 'MDTransport'})
        user_input = logged_input("Enter number: " if options_dict else ">> " if expected_type == "tasks" else "").strip()
        
        if not user_input:
            if allow_blank or default is not None: return default
            logger.error("No input provided. Please try again.", extra={'caller': 'MDTransport'})
            continue

        # Menu Selection mode
        if options_dict:
            parts = user_input.split(maxsplit=1)
            if not parts[0].isdigit() or parts[0] not in options_dict:
                logger.error("Invalid selection. Please enter a valid number.", extra={'caller': 'MDTransport'})
                continue
            selected = options_dict[parts[0]]
            return (selected, parts[1] if len(parts) > 1 else None) if expect_value else selected

        # List mode
        if min_len is not None or max_len is not None or expected_type == list:
            target_type = expected_type if expected_type != list else str
            try:
                values = [target_type(x) for x in user_input.split()]
                if min_len and len(values) < min_len:
                    logger.error(f"You must provide at least {min_len} values.", extra={'caller': 'MDTransport'})
                    continue
                if max_len and len(values) > max_len:
                    logger.error(f"You can provide at most {max_len} values.", extra={'caller': 'MDTransport'})
                    continue
                return values
            except ValueError:
                logger.error("Invalid input. Enter space-separated values.", extra={'caller': 'MDTransport'})
                continue

        # Tasks specific mode ('1 4', '1-3', 'all')
        if expected_type == "tasks":
            return user_input.lower()

        # Numeric/Scalar mode
        try:
            val = expected_type(user_input)
            if positive and val <= 0:
                logger.error("Value must be positive.", extra={'caller': 'MDTransport'})
                continue
            return val
        except ValueError:
            logger.error("Invalid input type.", extra={'caller': 'MDTransport'})

@handle_user_cancel
def prompt_for_path(path, path_type, arg_name, description):
    is_valid = os.path.isdir if path_type == "folder" else os.path.exists
    while not path or not is_valid(path):
        if path: logger.error(f"\nERROR: {arg_name} {path_type} not found.", extra={'caller': 'MDTransport'})
        path = logged_input(f"Enter valid {arg_name} {path_type} name or full path ({description}): ").strip()
    return path

VALID_SELECTION_KEYWORDS = {'resname', 'type', 'name', 'resid', 'segid', 'atom'}

def get_one_selection_group(prompt_message):
    while True:
        user_input = input(f" {prompt_message}: ").strip()
        if not user_input:
            logger.error("ERROR: Input cannot be empty. Please try again.", extra={'caller': 'MDTransport'})
            continue
        parts = user_input.split()
        if len(parts) % 2 != 0:
            logger.error(f"ERROR: Incomplete pair found in '{user_input}'. Please provide a value for every key.", extra={'caller': 'MDTransport'})
            continue
        
        if all(parts[i] in VALID_SELECTION_KEYWORDS for i in range(0, len(parts), 2)):
            return parts
        logger.error(f"ERROR: Invalid keyword. Please use one of: {', '.join(sorted(VALID_SELECTION_KEYWORDS))}", extra={'caller': 'MDTransport'})

def prompt_for_advanced_pairs(prompt_text, num_groups, is_lammps=False):
    logger.info("prompt_text", extra={'caller': 'MDTransport'})
    logger.info(f"Valid keywords are: {', '.join(sorted(VALID_SELECTION_KEYWORDS))}", extra={'caller': 'MDTransport'})
    ex1 = "resname EMI type 1" if is_lammps else "resname EMI type HR"
    ex2 = "resname BF type 2" if is_lammps else "resname BF type B"
    
    group1 = get_one_selection_group(f"Enter the FIRST selection group (e.g., {ex1})")
    if num_groups == 1: return group1
    group2 = get_one_selection_group(f"Enter the SECOND selection group (e.g., {ex2})")
    return group1 + group2

def prompt_for_msd_pairs(prompt_text, num_groups, is_lammps=False):
    logger.info("prompt_text", extra={'caller': 'MDTransport'})
    logger.info(f"Valid keywords are: {', '.join(sorted(VALID_SELECTION_KEYWORDS))}", extra={'caller': 'MDTransport'})
    ex1 = "resname EMI type 1" if is_lammps else "resname EMI type HR"
    
    group = get_one_selection_group(f"Enter the selection group (e.g., {ex1})")

    return group

def prompt_for_lammps_species(prompt_text="Enter species names", allow_empty=False):
    logger.info(prompt_text, extra={'caller': 'MDTransport'})
    
    while True:
        response = logged_input(
            f"{prompt_text} (space-separated, e.g., EMI BF THO): "
        ).strip()
        
        if not response:
            if allow_empty:
                return []
            logger.info("Please enter at least one species name or press Ctrl+C to cancel.")
            continue
        
        species = [s.strip() for s in response.split() if s.strip()]
        
        if not species:
            logger.info("Invalid input. Try again.")
            continue
        
        return species
    
def find_itp_folder(search_dir):
    for root, dirs, files in os.walk(search_dir):
        if any(f.endswith(".itp") for f in files): return os.path.relpath(root)
    return None

def validate_lammps_files(args):
    """
    Scans the directory for valid LAMMPS TRAJ and DATA files.
    """
    if args.LAM_PATH is not None:
        directory = args.LAM_PATH
    else:
        directory = os.getcwd()

    def read_head(filepath, num_lines=50):
        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                return [f.readline().lower() for _ in range(num_lines)]
        except Exception:
            return []

    def is_lammps_traj(lines, ext, mode):
    
        if mode == "TRAJ":
            # Only text lammpstrj trajectories
            return any(l.startswith("item: timestep") for l in lines)
    
        elif mode in {"MDA", "CHEM", "OVITO"}:
            # Allow binary formats supported by external libraries
            if ext in ['.xtc', '.dcd', '.nc', '.netcdf']: return True
            return any(l.startswith("item: timestep") for l in lines)
    
        return False

    def _find_and_assign(file_type, current_val, mode):
        """Helper to loop until a specific file type is found."""
        if current_val and os.path.isfile(current_val):
            return os.path.abspath(current_val)

        while True:
            # Scan directory for candidates
            candidates = []
            for filename in os.listdir(directory):
                filepath = os.path.join(directory, filename)
                if not os.path.isfile(filepath):
                    continue
                
                ext = os.path.splitext(filename)[1].lower()
                lines = read_head(filepath)
                
                is_valid = False
                if file_type == "TRAJ":
                    is_valid = is_lammps_traj(lines, ext, mode)
                
                if is_valid:
                    candidates.append(filepath)

            # Exactly one file found: Auto-select and return immediately
            if len(candidates) == 1:
                logger.info(f"Found LAMMPS {file_type} file: {os.path.basename(candidates[0])}")
                return os.path.abspath(candidates[0])

            # ultiple files found: Show menu and prompt
            if len(candidates) > 1:
                logger.info(f"Multiple LAMMPS {file_type} files detected:", extra={'caller': 'MDTransport'})
                for i, f in enumerate(candidates, 1):
                    logger.info(f"{i}. {os.path.basename(f)}", extra={'caller': 'MDTransport'})
                
                prompt = f"Enter number, filename, or full path for {file_type} and press Enter: "
                choice = input(prompt).strip()
                
                if not choice: continue # Rescan on empty Enter
                
                # Check index, name, or path
                if choice.isdigit() and 1 <= int(choice) <= len(candidates):
                    return os.path.abspath(candidates[int(choice) - 1])
                
                for cand in candidates:
                    if choice == os.path.basename(cand):
                        return os.path.abspath(cand) 
                
                if os.path.isfile(choice):
                    return os.path.abspath(choice)
                
                logger.info("Invalid input. Please try again.", extra={'caller': 'MDTransport'})
                continue

            # No files found: Wait for user upload
            logger.error(f"No {file_type} file detected. Please provide a file path or file name and press Enter.", extra={'caller': 'MDTransport'})
            input()
    
    mode = "TRAJ" if args.TRAJ else (
           "MDA" if args.MDA else
           "CHEM" if args.CHEM else
           "OVITO")
    
    args.TRAJ = _find_and_assign("TRAJ", args.TRAJ, mode)

def validate_gromacs_inputs(args):
    gro_opts = {"1": "PDB", "2": "EXE", "3": "MDA", "4": "CHEM", "5": "OVITO"}

    if not any([args.PDB, args.EXE, args.MDA, args.CHEM, args.OVITO]):
        selected, value = get_input("\nSelect GROMACS Trajectory Parser:\n 1. PDB file\n 2. gmx trjconv\n 3. MDAnalysis\n 4. Chemfiles\n 5. OVITO\n", options_dict=gro_opts, expect_value=True)
        setattr(args, selected, 1)

        if selected == "EXE":
            args.EXE = value or logged_input("Enter GROMACS executable name (e.g., gmx): ").strip()
            if shutil.which(args.EXE) is None:
                logger.error("Error: GROMACS is not installed or not in PATH. \nExiting...", extra={'caller': 'MDTransport'})
                sys.exit(1)
        if selected == "OVITO":
            args.TPR = value or logged_input("Enter name or full path of gro file (e.g., nvt.gro): ").strip()
            args.TPR = prompt_for_path(args.TPR, "file", "GRO", "e.g., nvt.gro")

    args = validate_analysis_tasks(args)
    if (args.PDB or args.OVITO) and args.ITP is None:
        args.ITP = find_itp_folder(args.GRO_PATH or ".")
        if not args.ITP:
            logger.error("ITP directory is missing. Plese provide it using --itp.", extra={'caller': 'MDTransport'})
            sys.exit(1)

    Validator(args).print_species_for_analysis()

    if args.TPR: args.TPR = prompt_for_path(args.TPR, "file", "topology file", "nvt.tpr")
    if args.TRAJ: args.TRAJ = prompt_for_path(args.TRAJ, "file", "trajectory file", "e.g., traj.xtc")
    if args.GRO_PATH is not None: args.GRO_PATH = prompt_for_path(args.GRO_PATH, "folder", "GROMACS files", "e.g., /path/to/files_directory")
    
    if args.t_steps is None and not args.PDB:
        args.t_steps = get_input("Enter t_steps for analysis (or press Enter for default 1) (e.g., 1): ", int, default=1, allow_blank=True)
        logger.info(f"t_steps = {args.t_steps} ps", extra={'caller': 'MDTransport'})
    if args.t_steps is None and args.PDB:
        args.t_steps = 1

    return args

def validate_lammps_inputs(args):
    lam_opts = {"1": "LAMP", "2": "COM", "3": "MDA", "4": "CHEM", "5": "OVITO"}
    
    if not any([args.LAMP, args.COM, args.MDA, args.CHEM, args.OVITO]):
        selected, value = get_input("\nSelect LAMMPS Trajectory Parser:\n 1. lammpstrj\n 2. com file\n 3. MDAnalysis\n 4. Chemfiles\n 5. OVITO\n", options_dict=lam_opts, expect_value=True)
        setattr(args, selected, 1)
        
        args.parser = selected

        if args.parser == "COM":
            args.COM = prompt_for_path(None, "file", "COM", "e.g., com.lmp")
        
            if args.DATA is None:
                args.DATA = prompt_for_path(None, "file", "DATA", "e.g., lammps.data")

    if not args.COM: validate_lammps_files(args)
    if args.COM and args.t_steps is None: args.t_steps = 1
    args = validate_analysis_tasks(args)
    Validator(args).print_species_for_analysis()
    
    if args.TRAJ: args.TRAJ = prompt_for_path(args.TRAJ, "file", "trajectory file", "e.g., traj.xtc")

    if ScriptState.had_interactive_input:
        args.N = get_input("Enter the frame stride (process every N-th frame, press Enter for default 1): ", int, default=1, allow_blank=True)
        logger.info(f"N = {args.N}", extra={'caller': 'MDTransport'})
        
        if args.t_steps is None:
            args.t_steps = get_input("Enter t_steps for analysis (or press Enter for default 1) (e.g., 1): ", int, default=1, allow_blank=True)
            logger.info(f"t_steps = {args.t_steps} ps", extra={'caller': 'MDTransport'})

    if not args.COM and args.dump_frame is None:
        args.dump_frame = get_input("Enter dump_frame of LAMMPS trajectory (or press Enter for default 1000): ", int, default=1000, allow_blank=True)
        logger.info(f"dump_frame = {args.dump_frame} steps", extra={'caller': 'MDTransport'})
    if args.t_steps is None and not args.COM:
        args.t_steps = get_input("Enter t_steps for analysis (or press Enter for default 1) (e.g., 1): ", int, default=1, allow_blank=True)
        logger.info(f"t_steps = {args.t_steps} ps", extra={'caller': 'MDTransport'})
    if args.N is None:
        args.N = 1
        logger.warning("WARNING: N not specified, using default: 1", extra={'caller': 'MDTransport'})
        
    return args

def validate_analysis_tasks(args):
    analysis_map = {
        'ONSG': "Onsager Transport Coefficients Calculation", 'MSD': "Mean Square Displacement & Self-diffusion Calculation",
        'NE': "Nernst-Einstein Conductivity Calculation", 'SPDA': "Spatial Decomposition Analysis",
        'TRA': "Einstein, Self- & Cross-correlation Calculation", 'EN': "Einstein Conductivity Calculation",
        'PCL': "Pair Correlation Lifetime Calculation", 'CAGE': "Cage Correlation Lifetime Calculation",
        'CAGE_P': "Cage Population (Cluster) Analysis", 'RDF': "Radial Distribution Function Calculation",
        'SMD': "Stefan-Maxwell Diffusivity Calculation", 'VEH': "Vehicular Transport Mechanism Analysis",
        'GET_CSV': "Extract and save coordinates to csv file.",
    }
    tasks = list(analysis_map.keys())
    
    if any(getattr(args, t, False) for t in tasks): 
        return args

    labels = [f"{i+1:2d}. --{t}" for i, t in enumerate(tasks)]
    prompt_lines = [f"{labels[i]:<20}   {analysis_map[t]}" for i, t in enumerate(tasks)]
    prompt = "\nSelect one or more analysis tasks:\n" + "\n".join(prompt_lines) + "\n\nEnter selection(s) (e.g., '1 4', '1-3,5', or '--msd --rdf').\n(Enter 'all' to select all tasks)"
    
    while True:
        user_input = get_input(prompt, expected_type="tasks")
        if user_input == 'all':
            selected_tasks = tasks
            break
            
        task_map = {str(i + 1): t for i, t in enumerate(tasks)}
        task_map.update({f"--{t.lower()}": t for t in tasks})
        selected_tasks, is_valid = [], True

        for token in user_input.replace(",", " ").split():
            if '-' in token and not token.startswith('--'):
                try:
                    start, end = map(int, token.split('-', 1))
                    if start < 1 or end > len(tasks) or start > end: raise ValueError
                    selected_tasks.extend([task_map[str(i)] for i in range(start, end + 1)])
                except (ValueError, KeyError):
                    logger.error(f"Error: Invalid range '{token}'.", extra={'caller': 'MDTransport'})
                    is_valid = False; break
            else:
                task = task_map.get(token)
                if task: selected_tasks.append(task)
                else:
                    logger.error(f"Error: Unknown selection '{token}'.", extra={'caller': 'MDTransport'})
                    is_valid = False; break
        
        if is_valid: 
            selected_tasks = list(dict.fromkeys(selected_tasks))
            break

    for task in selected_tasks: setattr(args, task, True)
    return args

def validate_task_specific_args(args):
    # Time window settings for correlations
    if any(getattr(args, t) for t in ["TRA", "SPDA", "ONSG"]):
        if args.n_delta is None:
            args.n_delta = get_input("Enter time window (in ps) for time origin shifting (default: 1000): ", int, default=1000, allow_blank=True) if ScriptState.had_interactive_input else 1000
        if args.t_window is None:
            args.t_window = get_input("Enter time window (in ps) for slope calculations (default: 1000): ", int, default=1000, allow_blank=True) if ScriptState.had_interactive_input else 1000
        if getattr(args, 'n_delta', 0) < getattr(args, 't_window', 0):
            logger.error(f"n_delta ({args.n_delta}) is less than t_window ({args.t_window}). Aborting.", extra={'caller': 'MDTransport'})
            sys.exit(1)

    if args.EN and args.t_window is None:
        args.t_window = get_input("Enter time window (in ps) for slope calculations (default: 1000): ", int, default=1000, allow_blank=True) if ScriptState.had_interactive_input else 1000

    # Temperature
    if any(getattr(args, t) for t in ["TRA", "EN", "NE", "SMD", "SPDA", "ONSG"]):
        if args.Temp is None:
            if ScriptState.had_interactive_input:
                args.Temp = get_input("Enter temperature in Kelvin (or press Enter for default 298.0) (e.g., 298.15): ", float, default=298.0, allow_blank=True)
                logger.info(f"Temp = {args.Temp} K", extra={'caller': 'MDTransport'})
            else:
                logger.error("Error: temperature is required for the selected analysis.", extra={'caller': 'MDTransport'})
                sys.exit(1)

    # Lifetime / Clustering Analyses Grouped
    tasks_cfg = [
        ("CAGE", "cage correlation", False), ("CAGE_P", "cluster population", True),
        ("PCL", "pair correlation lifetime", True), ("VEH", "vehicular", True)
    ]
    for flag, name, req_species in tasks_cfg:
        if getattr(args, flag) and ScriptState.had_interactive_input:
            if req_species and args.resname is None:
                args.resname = get_input(f"Enter two species for {name} analysis (e.g., EMI BF): ", str, min_len=2, max_len=2)
            if flag == "CAGE":
                if not args.CA: args.CA = [get_input("Enter the reference species for cage correlation (e.g., EMI): ", str)]
                if not args.AN: args.AN = [get_input("Enter the target species for cage correlation (e.g., BF): ", str)]
            args.steps = get_input(f"Enter time origin steps for {name} analysis (or press Enter for default 1) (e.g., 10): ", int, default=1, allow_blank=True)
            logger.info(f"steps= {args.steps}", extra={'caller': 'MDTransport'})

    if args.n_steps is None and ScriptState.had_interactive_input:
        args.n_steps = get_input("Enter start and end frames in ps (or press Enter to use full trajectory) (e.g., 0 2000): ", int, min_len=2, max_len=2, allow_blank=True)

    if args.GET_CSV and ScriptState.had_interactive_input:
        args.GET_CSV = get_input("Enter coordinate type for data loading, 1 values (com or atom, default: com): ", str, default=["com"], allow_blank=True)
        
    # MSD Setup
    if args.MSD and ScriptState.had_interactive_input:
        response = logged_input("Enable advanced MSD settings? (Y/N) or press Enter for default to N:").lower().strip()
        if response in ["", "n", "no"]:
            logger.info(">> COM-based MSD calculations only.", extra={'caller': 'MDTransport'})
        elif response in ["", "y", "yes"]:
            logger.info(">> Advanced MSD analysis has been enabled.", extra={'caller': 'MDTransport'})
            if args.LAM:
                response = logged_input(
                    "Advanced MSD (LAMMPS mode):\n"
                    "Do you want to specify custom species names?\n"
                    "Press Enter to use defaults (species_1, species_2, ...), or type 'y' to enter them: "
                ).lower().strip()
            
                if response in ["", "n", "no"]:
                    logger.info(">> Using default species labels.", extra={'caller': 'MDTransport'})
                else:
                    logger.info(">> Custom species labels will be used.", extra={'caller': 'MDTransport'})
                    
                    if not args.LAMP_SPECIES:
                        args.LAMP_SPECIES = prompt_for_lammps_species()
            if args.msd_mode is None:
                args.msd_mode = get_input("Enter MSD mode, 1 values (com or atoms, default: com): ", str, default=["com"], allow_blank=True)
            if not args.msd_species:
                args.msd_species = prompt_for_msd_pairs("Enter selection for MSD analysis.", num_groups=1, is_lammps=args.LAM)

        if args.resname is None and not args.msd_mode:
            args.resname = get_input("Enter resnames to compute MSD (e.g., EMI BF). Press Enter to process all resname: ", list, allow_blank=True)
        if not args.DIR:
            args.DIR = get_input("Enter directions for MSD analysis (or press Enter for all) (e.g., x y z): ", list, default=["x", "y", "z"], allow_blank=True)

        if args.fit_method is None:
            args.fit_method = get_input("Enter fitting method for diffusion analysis, 1 values (ols or gls or wls, default: ols): ", str, default=["ols"], allow_blank=True)
    # Skipping Species
    if ScriptState.had_interactive_input and not args.LAM and not (args.MSD and args.msd_mode) and not (args.RDF and args.rdf_mode) and not args.SMD:
        if not args.SKIP_SPECIES:
            args.SKIP_SPECIES = get_input("Enter resnames to skip (e.g., SOL GRA). Press Enter to process all resname: ", list, default=[], allow_blank=True)

    if args.SPDA and ScriptState.had_interactive_input:
        args.steps = get_input("Enter time origin steps for SPDA (or press Enter for default 1) (e.g., 10): ", int, default=1, allow_blank=True)

    # RDF Setup
    if args.RDF and ScriptState.had_interactive_input:
        args.steps = get_input("Enter time origin steps for RDFs calculation (or press Enter for default 1) (e.g., 10): ", int, default=1, allow_blank=True)
        
        response = logged_input("Enable advanced RDF settings? (Y/N) or press Enter for default to N: ").lower().strip()
        if response in ["", "n", "no"]:
            logger.info(">> COM-COM RDF calculations only.", extra={'caller': 'MDTransport'})
        else:
            logger.info(">> Advanced RDF analysis has been enabled.", extra={'caller': 'MDTransport'})
            if args.LAM:
                response = logged_input(
                    "Advanced RDF (LAMMPS mode):\n"
                    "Do you want to specify custom species names?\n"
                    "Press Enter to use defaults (species_1, species_2, ...), or type 'y' to enter them: "
                ).lower().strip()
            
                if response in ["", "n", "no"]:
                    logger.info(">> Using default species labels.", extra={'caller': 'MDTransport'})
                else:
                    logger.info(">> Custom species labels will be used.", extra={'caller': 'MDTransport'})
                    
                    if not args.LAMP_SPECIES:
                        args.LAMP_SPECIES = prompt_for_lammps_species()
            if args.rdf_mode is None:
                 args.rdf_mode = get_input("Enter RDF mode, 2 values (default: 'com com'): ", str, default=['com', 'com'], allow_blank=True, min_len=2, max_len=2)
            if not args.rdf_pairs:
                args.rdf_pairs = prompt_for_advanced_pairs("Enter selection pairs for RDF analysis.", num_groups=2, is_lammps=args.LAM)

        if not getattr(args, 'RBIN', None):
            args.RBIN = get_input("Enter Bins Width for RDF analysis (or press Enter for default 0.1) (e.g., 0.2): ", float, default=0.1, allow_blank=True)
        if args.resname is None and not args.rdf_mode:
            args.resname = get_input("Enter pairs of resnames to computes RDF (e.g., EMI BF). Press Enter to process all resname: ", list, allow_blank=True)
        if not args.ANA:
            ans = logged_input("You are running RDF analysis. Want to find peaks and solvation radius? (Y/N): ").lower().strip()
            args.ANA = ans in ["", "y", "yes"]

    # RCUT Logic
    tasks_using_rcut = ["SPDA", "CAGE", "CAGE_P", "PCL", "VEH"]
    if args.RCUT is None:
        if ScriptState.had_interactive_input and any(getattr(args, t) for t in tasks_using_rcut):
            args.RCUT = get_input("Enter solvation radius for analysis (or press Enter to use it from RDF): ", float, allow_blank=True, min_len=1)
        if any(getattr(args, t) for t in tasks_using_rcut):
            logger.warning("WARNING: The RCUT value estimated from the RDF calculation may be inaccurate and should be used with caution.\nFor accurate results, it is strongly recommended to verify the value and provide your own RCUT input.", extra={'caller': 'MDTransport'})

    return args

@handle_user_cancel
def confirm_inputs():
    while True:
        choice = logged_input("Proceed with these inputs? (Y/N) or press Enter to continue: ").strip().lower()
        if choice in ("", "y", "yes"): return True
        if choice in ("n", "no"):
            logger.error("User aborted execution.", extra={'caller': 'MDTransport'})
            sys.exit(0)

def print_summary(args):
    COLOR_RESET, COLOR_YELLOW, COLOR_CYAN, COLOR_BLUE = "\033[0m", "\033[33m", "\033[36m", "\033[34m"
    KEY_WIDTH = 40

    def log(k, v, v_type="other"):
        v_str = " ".join(map(str, v)) if isinstance(v, list) else str(v)
        if v_type == "numeric": v_str = f"{COLOR_YELLOW}{v_str}{COLOR_RESET}"
        elif v_type == "species": v_str = f"{COLOR_CYAN}{v_str}{COLOR_RESET}"
        elif v_type == "other": v_str = f"{COLOR_BLUE}{v_str}{COLOR_RESET}"
        logger.info(f"{k:<{KEY_WIDTH}} : {v_str}", extra={'caller': 'MDTransport'})

    logger.info("\n" + "=" * 55 + "\n             MDTransport: Input Summary\n" + "=" * 55, extra={'caller': 'MDTransport'})
    log("Analysis Mode", "GROMACS" if args.GRO else "LAMMPS" if args.LAM else "UNKNOWN", "other")

    # Grouped attribute checking
    gro_checks = [("PDB", "PDB"), ("EXE", "EXE"), ("MDA", "MDAnalysis"), ("CHEM", "Chemfiles"), ("OVITO", "OVITO")]
    if args.GRO:
        for attr, name in gro_checks:
            if getattr(args, attr, None): log("GROMACS Mode", name, "other")
        for attr, label in [("ITP", "ITP Folder"), ("EXE", "EXE"), ("TPR", "topology file"), ("TRAJ", "trajectory file")]:
            if getattr(args, attr, None): log(label, getattr(args, attr), "other")
    elif args.LAM:
        if args.COM:
            log("LAMMPS Mode", "COM File", "other"); log("COM File", args.COM, "other"); log("DATA File", args.DATA, "other")
        elif args.MDA or args.CHEM or args.OVITO:
            log("LAMMPS Mode", "MDAnalysis" if args.MDA else "Chemfiles" if args.CHEM else "OVITO", "other")
            log("lammpstrj file", args.TRAJ, "other"); log("DATA File", args.DATA, "other"); log("dump_frame", f"{args.dump_frame} steps", "numeric")
        else:
            log("LAMMPS Mode", "lammpstrj file", "other"); log("lammpstrj file", args.TRAJ, "other")
            if args.DATA: log("DATA File", args.DATA, "other")
        if args.LAMP_SPECIES: log("Species", args.LAMP_SPECIES, "species")
        log("N", args.N, "numeric")

    # Compile the list of active tasks
    task_names = []
    for t in ["PCL", "CAGE", "CAGE_P", "RDF", "VEH", "ONSG", "MSD", "NE", "SMD", "SPDA", "TRA", "EN"]:
        if getattr(args, t, False):
            task_names.append(t)

    log("Analysis Task(s)", ", ".join(task_names) if task_names else "None", "other")

    if args.CAGE:
        if args.CA: log("Reference species", args.CA, "species")
        if args.AN: log("Cage species", args.AN, "species")

    # Print all the variables, including t_window and steps!
    props = [
        (args.Temp, "Temperature", f"{args.Temp} K", "numeric"), 
        (args.resname, "Requested species", args.resname, "other"),
        (args.SKIP_SPECIES, "Skipped species", args.SKIP_SPECIES, "other"),
        (args.t_steps, "t_steps", f"{args.t_steps} ps", "numeric"), 
        (args.n_steps, "n_steps", f"{args.n_steps} ps", "numeric"),
        (args.n_delta, "n_delta", f"{args.n_delta} ps", "numeric"), 
        (args.t_window, "t_window", f"{args.t_window} ps", "numeric"), 
        (getattr(args, 'steps', None), "Time origin steps", getattr(args, 'steps', None), "numeric"),
        (args.RCUT, "rcut", f"{args.RCUT} Å", "numeric"),
        (args.RBIN, "rbin", f"{args.RBIN} Å", "numeric"),
        (getattr(args, 'ANA', False) or None, "RDF analysis", "yes", "other"),
        (args.print_core, "Number of cores", args.print_core, "numeric")
    ]
    
    for check, label, val, ptype in props:
        if check is not None: log(label, val, ptype)
        
    logger.info("=" * 55 + "\n", extra={'caller': 'MDTransport'})

def validate_arguments(args):
    logger.info("=" * 55 + "\n          MDTransport: Validating Inputs\n" + "=" * 55, extra={'caller': 'MDTransport'})
        
    avail_cores = len(os.sched_getaffinity(0)) if hasattr(os, 'sched_getaffinity') else multiprocessing.cpu_count()
    if args.n_cores is None or not (1 <= args.n_cores <= avail_cores):
        args.n_cores, args.print_core = max(1, avail_cores - 1), max(1, avail_cores)
    else: args.print_core = args.n_cores

    if args.GRO and args.LAM:
        logger.error("ERROR: Both GRO and LAM inputs provided. Exiting...", extra={'caller': 'MDTransport'}); sys.exit(0)
    if not (args.GRO or args.LAM):
        setattr(args, get_input("\nSelect analysis mode:\n 1. GROMACS\n 2. LAMMPS\n ", options_dict={"1": "GRO", "2": "LAM"}), 1)

    args = validate_gromacs_inputs(args) if args.GRO else validate_lammps_inputs(args)
    args = validate_task_specific_args(args)
    
    val_inst = Validator(args)

    if any(getattr(args, t) for t in ["PCL", "CAGE", "CAGE_P", "VEH"]) or (args.RDF and args.rdf_mode) or (args.MSD and args.msd_mode):
        if args.GRO: val_inst.species_for_analysis()
        val_inst.validate_species_for_analysis()

    print_summary(args)
    if ScriptState.had_interactive_input: confirm_inputs()
    else: logger.info("All arguments provided. Proceeding with analysis automatically...\n", extra={'caller': 'MDTransport'})
    return args

examples = {
    1: """MSD & Diffusion Analysis

# Calculate MSD & Diffusion from a GROMACS simulation.

mdt --gro --msd --pdb --traj traj.pdb --itp itp_files 

mdt --gro --msd --exe gmx --t_steps 1 

mdt --gro --msd --mda --t_steps 1 

mdt --gro --msd --chem --t_steps 1 

mdt --gro --msd --ovito --t_steps 1 --itp itp_files --tpr nvt.gro

mdt --gro --msd --mda --t_steps 1 --msd_mode com --msd_species resname EMI type HR resname BF type F

mdt --gro --msd --chem --t_steps 1 --msd_mode com --msd_species resname EMI type HR resname BF type F

# Calculate MSD & Diffusion from a LAMMPS simulation.

mdt --lam --msd --lamp --t_steps 1  

mdt --lam --msd --com com.lmp --data lammps.data --t_steps 1  

mdt --lam --msd --mda --t_steps 1 --dump_frame 2000  

mdt --lam --msd --chem --t_steps 1 --dump_frame 2000  

mdt --lam --msd --ovito --t_steps 1 --dump_frame 2000  

mdt --lam --msd --lamp --t_steps 1 --dump_frame 2000 --msd_mode com --msd_species resname species_1 type 1 2 resname species_2 type 3 4

mdt --lam --msd --mda --t_steps 1 --dump_frame 2000 --msd_mode com --msd_species resname species_1 type 1 2 resname species_2 type 3 4

mdt --lam --msd --chem --t_steps 1 --dump_frame 2000 --msd_mode com --msd_species resname species_1 type 1 2 resname species_2 type 3 4

mdt --lam --msd --ovito --t_steps 1 --dump_frame 2000 --msd_mode com --msd_species resname species_1 type 1 2 resname species_2 type 3 4

""",

    2: """Onsager Transport Coefficients

# Calculate Onsager Transport Coefficients from a GROMACS simulation.

mdt --gro --onsg --temp 298 --pdb --traj traj.pdb --itp itp_files 

mdt --gro --onsg --temp 298 --exe gmx --t_steps 1 

mdt --gro --onsg --temp 298 --mda --t_steps 1 

mdt --gro --onsg --temp 298 --chem --t_steps 1 

mdt --gro --onsg --temp 298 --ovito --t_steps 1 --itp itp_files --tpr nvt.gro

# Calculate Onsager Transport Coefficients from a LAMMPS simulation.

mdt --lam --onsg --temp 298 --lamp --t_steps 1  

mdt --lam --onsg --temp 298 --com com.lmp --data lammps.data --t_steps 1  

mdt --lam --onsg --temp 298 --mda --t_steps 1 --dump_frame 2000  

mdt --lam --onsg --temp 298 --chem --t_steps 1 --dump_frame 2000  

mdt --lam --onsg --temp 298 --ovito --t_steps 1 --dump_frame 2000  
""",

    3: """Einstein, Self- and Cross-correlations terms

# Calculate Transport Coefficients such as Einstein, Self- and Cross-correlations from a GROMACS simulation.

mdt --gro --tra --temp 298 --pdb --traj traj.pdb --itp itp_files 

mdt --gro --tra --temp 298 --exe gmx --t_steps 1 

mdt --gro --tra --temp 298 --mda --t_steps 1 

mdt --gro --tra --temp 298 --chem --t_steps 1 

mdt --gro --tra --temp 298 --ovito --t_steps 1  --itp itp_files --tpr nvt.gro

# Calculate Transport Coefficients such as Einstein, Self- and Cross-correlations from a LAMMPS simulation.

mdt --lam --tra --temp 298 --lamp --t_steps 1  

mdt --lam --tra --temp 298 --com com.lmp --data lammps.data --t_steps 1  

mdt --lam --tra --temp 298 --mda --t_steps 1 --dump_frame 2000 

mdt --lam --tra --temp 298 --chem--t_steps 1 --dump_frame 2000 

mdt --lam --tra --temp 298 --ovito --t_steps 1 --dump_frame 2000 
""",

    4: """Einstein Conductivity

# Calculate Einstein Conductivity from a GROMACS simulation.

mdt --gro --en --temp 298 --pdb --traj traj.pdb --itp itp_files 

mdt --gro --en --temp 298 --exe gmx --t_steps 1 

mdt --gro --en --temp 298 --mda --t_steps 1 

mdt --gro --en --temp 298 --chem --t_steps 1 

mdt --gro --en --temp 298 --ovito --t_steps 1  --itp itp_files --tpr nvt.gro

# Calculate Einstein Conductivity from a LAMMPS simulation.

mdt --lam --en --temp 298 --lamp --t_steps 1  

mdt --lam --en --temp 298 --com com.lmp --data lammps.data --t_steps 1 

mdt --lam --en --temp 298 --mda --t_steps 1 --dump_frame 2000 

mdt --lam --en --temp 298 --chem --t_steps 1 --dump_frame 2000 

mdt --lam --en --temp 298 --ovito --t_steps 1 --dump_frame 2000 
""",

    5: """Nernst-Einstein Conductivity

# Calculate Nernst-Einstein Conductivity from a GROMACS simulation.

mdt --gro --ne --temp 298 --pdb --traj traj.pdb --itp itp_files 

mdt --gro --ne --temp 298 --exe gmx --t_steps 1 

mdt --gro --ne --temp 298 --mda --t_steps 1 

mdt --gro --ne --temp 298 --chem --t_steps 1 

mdt --gro --ne --temp 298 --ovito --t_steps 1 --itp itp_files --tpr nvt.gro

# Calculate Nernst-Einstein Conductivity from a LAMMPS simulation.

mdt --lam --ne --temp 298 --lamp --t_steps 1  

mdt --lam --ne --temp 298 --com com.lmp --data lammps.data --t_steps 1 

mdt --lam --ne --temp 298 --mda --t_steps 1 --dump_frame 2000 

mdt --lam --ne --temp 298 --chem --t_steps 1 --dump_frame 2000 

mdt --lam --ne --temp 298 --ovito --t_steps 1 --dump_frame 2000 
""",

    6: """Stefan-Maxwell Conductivity

# Calculate Stefan-Maxwell Conductivity from a GROMACS simulation.

mdt --gro --smd --temp 298 --pdb --traj traj.pdb --itp itp_files 

mdt --gro --smd --temp 298 --exe gmx --t_steps 1 

mdt --gro --smd --temp 298 --mda --t_steps 1 

mdt --gro --smd --temp 298 --chem --t_steps 1

mdt --gro --smd --temp 298 --ovito --t_steps 1 --itp itp_files --tpr nvt.gro

# Calculate Stefan-Maxwell Conductivity from a LAMMPS simulation.

mdt --lam --smd --temp 298 --lamp --t_steps 1  

mdt --lam --smd --temp 298 --com com.lmp --data lammps.data --t_steps 1  

mdt --lam --smd --temp 298 --mda --t_steps 1 --dump_frame 2000 

mdt --lam --smd --temp 298 --chem --t_steps 1 --dump_frame 2000 

mdt --lam --smd --temp 298 --ovito --t_steps 1 --dump_frame 2000 
""",

    7: """Spatial Decomposition Analysis

# Perform Spatial Decomposition Analysis from a GROMACS simulation.

mdt --gro --spda --temp 298 --pdb --traj traj.pdb --itp itp_files

mdt --gro --spda --temp 298 --exe gmx --t_steps 1 

mdt --gro --spda --temp 298 --mda --t_steps 1 

mdt --gro --spda --temp 298 --chem --t_steps 1 

mdt --gro --spda --temp 298 --ovito --t_steps 1 --itp itp_files --tpr nvt.gro

# Perform Spatial Decomposition Analysis from a LAMMPS simulation.

mdt --lam --spda --temp 298 --lamp --t_steps 1  

mdt --lam --spda --temp 298 --com com.lmp --data lammps.data --t_steps 1  

mdt --lam --spda --temp 298 --mda --t_steps 1 --dump_frame 2000  

mdt --lam --spda --temp 298 --chem --t_steps 1 --dump_frame 2000  

mdt --lam --spda --temp 298 --ovito --t_steps 1 --dump_frame 2000  
""",

    8: """Pair Correlation Lifetime

# Calculate Pair Correlation Lifetime from a GROMACS simulation.

mdt --gro --pcl --resname emi bf --pdb --traj traj.pdb --itp itp_files --n_steps 0 10000

mdt --gro --pcl --resname emi bf --exe gmx --t_steps 1 --n_steps 0 10000

mdt --gro --pcl --resname emi bf --mda --t_steps 1 --n_steps 0 10000

mdt --gro --pcl --resname emi bf --chem --t_steps 1 --n_steps 0 10000

mdt --gro --pcl --resname emi bf --ovito --t_steps 1 --n_steps 0 10000 --itp itp_files --tpr nvt.gro

# Calculate Pair Correlation Lifetime from a LAMMPS simulation.

mdt --lam --pcl --resname emi bf --lamp --t_steps 1  --n_steps 0 10000

mdt --lam --pcl --resname emi bf --com com.lmp --data lammps.data --t_steps 1  --n_steps 0 10000

mdt --lam --pcl --resname emi bf --mda --t_steps 1 --dump_frame 2000  --n_steps 0 10000

mdt --lam --pcl --resname emi bf --chem --t_steps 1 --dump_frame 2000  --n_steps 0 10000

mdt --lam --pcl --resname emi bf --ovito --t_steps 1 --dump_frame 2000  --n_steps 0 10000
""",

    9: """Cage Correlation Lifetime

# Calculate Cage Correlation Lifetime from a GROMACS simulation.

mdt --gro --cage --ref_species emi --cage_species bf --pdb --traj traj.pdb --itp itp_files --n_steps 0 10000

mdt --gro --cage --ref_species emi --cage_species bf --exe gmx --t_steps 1 --n_steps 0 10000

mdt --gro --cage --ref_species emi --cage_species bf --mda --t_steps 1 --n_steps 0 10000

mdt --gro --cage --ref_species emi --cage_species bf --chem --t_steps 1 --n_steps 0 10000

mdt --gro --cage --ref_species emi --cage_species bf --ovito --t_steps 1 --n_steps 0 10000 --itp itp_files --tpr nvt.gro

# Calculate Cage Correlation Lifetime from a LAMMPS simulation.

mdt --lam --cage --ref_species emi --cage_species bf --lamp --t_steps 1  --n_steps 0 10000

mdt --lam --cage --ref_species emi --cage_species bf --com com.lmp --data lammps.data --t_steps 1  --n_steps 0 10000

mdt --lam --cage --ref_species emi --cage_species bf --mda --t_steps 1 --dump_frame 2000  --n_steps 0 10000

mdt --lam --cage --ref_species emi --cage_species bf --chem --t_steps 1 --dump_frame 2000  --n_steps 0 10000

mdt --lam --cage --ref_species emi --cage_species bf --ovito --t_steps 1 --dump_frame 2000  --n_steps 0 10000
""",

    10: """Cluster Population

# Perform Cluster Population Analysis from a GROMACS simulation.

mdt --gro --cage_p --resname emi bf --pdb --traj traj.pdb --itp itp_files 

mdt --gro --cage_p --resname emi bf --exe gmx --t_steps 1 

mdt --gro --cage_p --resname emi bf --mda --t_steps 1 

mdt --gro --cage_p --resname emi bf --chem --t_steps 1 

mdt --gro --cage_p --resname emi bf --ovito --t_steps 1 --itp itp_files --tpr nvt.gro

# Perform Cluster Population Analysis from a LAMMPS simulation.

mdt --lam --cage_p --resname emi bf --lamp --t_steps 1  

mdt --lam --cage_p --resname emi bf --com com.lmp --data lammps.data --t_steps 1 

mdt --lam --cage_p --resname emi bf --mda --t_steps 1 --dump_frame 2000 

mdt --lam --cage_p --resname emi bf --chem --t_steps 1 --dump_frame 2000 

mdt --lam --cage_p --resname emi bf --ovito --t_steps 1 --dump_frame 2000 
""",

    11: """Transport Mechanism

# Perform Transport Mechanism Analysis from a GROMACS simulation.

mdt --gro --veh --resname emi bf --pdb --traj traj.pdb --itp itp_files --n_steps 0 10000

mdt --gro --veh --resname emi bf --exe gmx --t_steps 1 --n_steps 0 10000

mdt --gro --veh --resname emi bf --mda --t_steps 1 --n_steps 0 10000

mdt --gro --veh --resname emi bf --chem --t_steps 1 --n_steps 0 10000

mdt --gro --veh --resname emi bf --ovito --t_steps 1 --n_steps 0 10000 --itp itp_files --tpr nvt.gro

# Perform Transport Mechanism Analysis from a LAMMPS simulation.

mdt --lam --veh --resname emi bf --lamp --t_steps 1  --n_steps 0 10000

mdt --lam --veh --resname emi bf --com com.lmp --data lammps.data --t_steps 1  --n_steps 0 10000

mdt --lam --veh --resname emi bf --mda --traj.lammpstrj --data lammps.data --t_steps 1 --dump_frame 2000  --n_steps 0 10000

mdt --lam --veh --resname emi bf --chem --traj.lammpstrj --data lammps.data --t_steps 1 --dump_frame 2000  --n_steps 0 10000

mdt --lam --veh --resname emi bf --ovito --traj.lammpstrj --data lammps.data --t_steps 1 --dump_frame 2000  --n_steps 0 10000
""",

    12: """Radial Distribution Function

# Perform RDF Analysis from a GROMACS simulation.

mdt --gro --rdf --pdb --traj traj.pdb --itp itp_files 

mdt --gro --rdf --exe gmx --t_steps 1 

mdt --gro --rdf --mda --t_steps 1 

mdt --gro --rdf --chem --t_steps 1 

mdt --gro --rdf --ovito --t_steps 1 --itp itp_files --tpr nvt.gro

mdt --gro --rdf --mda --t_steps 1 --rdf_mode atom atom --rdf_pairs resname EMI type HR resname BF type F

# Perform RDF Analysis from a LAMMPS simulation.

mdt --lam --rdf --lamp --t_steps 1  

mdt --lam --rdf --com com.lmp --data lammps.data --t_steps 1  

mdt --lam --rdf --mda --t_steps 1 --dump_frame 2000  

mdt --lam --rdf --chem --t_steps 1 --dump_frame 2000  

mdt --lam --rdf --ovito --t_steps 1 --dump_frame 2000  

mdt --lam --rdf --mda --t_steps 1 --dump_frame 2000  --rdf_mode atom atom --rdf_pairs resname species_1 type 1 resname species_2 type 7


""",   

    13: """Save Coordinates to CSV file

# Perform RDF Analysis from a GROMACS simulation.

mdt --gro --get_csv com --pdb --traj traj.pdb --itp itp_files 

mdt --gro --get_csv com --exe gmx --t_steps 1 

mdt --gro --get_csv com --mda --t_steps 1 

mdt --gro --get_csv com --chem --t_steps 1 

mdt --gro --get_csv com --ovito --t_steps 1 --itp itp_files --tpr nvt.gro

mdt --gro --get_csv com --mda --t_steps 1 --rdf_mode atom atom --rdf_pairs resname EMI type HR resname BF type F

# Perform RDF Analysis from a LAMMPS simulation.

mdt --lam --get_csv com --lamp --t_steps 1  

mdt --lam --get_csv com --com com.lmp --data lammps.data --t_steps 1  

mdt --lam --get_csv com --mda --t_steps 1 --dump_frame 2000  

mdt --lam --get_csv com --chem --t_steps 1 --dump_frame 2000  

mdt --lam --get_csv com --ovito --t_steps 1 --dump_frame 2000  

mdt --lam --get_csv com --lamp --t_steps 1 --dump_frame 2000  --rdf_mode atom atom --rdf_pairs resname species_1 type 1 resname species_2 type 2

mdt --lam --get_csv com --mda --t_steps 1 --dump_frame 2000  --rdf_mode atom atom --rdf_pairs resname species_1 type 1 resname species_2 type 2

mdt --lam --get_csv com --chem --t_steps 1 --dump_frame 2000  --rdf_mode atom atom --rdf_pairs resname species_1 type 1 resname species_2 type 2

mdt --lam --get_csv com --ovito --t_steps 1 --dump_frame 2000  --rdf_mode atom atom --rdf_pairs resname species_1 type 1 resname species_2 type 2
""",
 
}

@handle_user_cancel
def show_examples(selected=None):
    
    """Displays usage examples"""
    example_list = {
        1: "MSD & Diffusion Analysis", 2: "Onsager Transport Coefficients",
        3: "Einstein, Self- and Cross-correlations", 4: "Einstein Conductivity",
        5: "Nernst-Einstein Conductivity", 6: "Stefan-Maxwell Conductivity",
        7: "Spatial Decomposition Analysis", 8: "Pair Correlation Lifetime",
        9: "Cage Correlation Lifetime", 10: "Cluster Population",
        11: "Transport Mechanism", 12: "Radial Distribution Function",
        13: "Save Coordinates to CSV file",
    }

    if selected is None or selected == "":
        logger.info("Available examples:\n" + "=" * 80, extra={'caller': 'MDTransport'})
        for key, desc in sorted(example_list.items()):
            logger.info(f"{key}: {desc}", extra={'caller': 'MDTransport'})
        selected = logged_input(
            "\nEnter example numbers to view (e.g., 1 or 1-3,5):\n>> "
        ).strip()

    indices = set()
    for part in selected.replace(" ", "").split(","):
        if "-" in part:
            try:
                start, end = map(int, part.split("-"))
                indices.update(range(start, end + 1))
            except ValueError:
                logger.info(f"Invalid range: {part}", extra={'caller': 'MDTransport'})
        elif part:
            try:
                indices.add(int(part))
            except ValueError:
                logger.info(f"Invalid number: {part}", extra={'caller': 'MDTransport'})
    logger.info("\nReplace mdt with python mdt.py if running without installation\n" + "=" * 80, extra={'caller': 'MDTransport'})
    logger.info("Selected example(s):\n" + "=" * 80, extra={'caller': 'MDTransport'})
    for i in sorted(list(indices)):
        if i in examples:
            logger.info(f"{examples[i]}", extra={'caller': 'MDTransport'})
        else:
            logger.info(f"{i}: No such example.", extra={'caller': 'MDTransport'})
    logger.info("=" * 80 + "\n", extra={'caller': 'MDTransport'})

def parse_arguments(argv=None):
    if argv is None:
        argv = sys.argv[1:]

    # Handle Configuration File Input
    file_args = []
    if '--in' in argv:
        idx = argv.index('--in')
        if idx + 1 < len(argv):
            in_file = argv[idx + 1]
            argv.pop(idx) 
            argv.pop(idx) 
            if os.path.exists(in_file):
                with open(in_file, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if not line or line.startswith('#'): continue
                        file_args.extend(line.split())
            else:
                logger.error(f"Input configuration file '{in_file}' not found.", extra={'caller': 'MDTransport'})
                sys.exit(1)
    
    # Prepend file arguments so CLI arguments override them
    argv = file_args + argv

    CUSTOM_ERROR = "Missing values, please provide valid values after {option_string}"
    parser = CaseInsensitiveArgumentParser(
        prog="MDTransport", 
        description="MDTransport: GROMACS & LAMMPS Transport Analysis Tools",
        formatter_class=argparse.RawTextHelpFormatter, 
        add_help=False
    )
    
    # Define Groups (Names from Code-2)
    groups = {
        "PARSER": parser.add_argument_group("GROMACS Analysis Modes"),
        "Mode":   parser.add_argument_group("Analysis Modes"),
        "File":   parser.add_argument_group("File & Path Arguments"),
        "Path":   parser.add_argument_group("Path Arguments"),
        "Gen":    parser.add_argument_group("General Parameters"),
        "Calc":   parser.add_argument_group("Properties Calculations"),
        "Spec":   parser.add_argument_group("Analysis-Specific Parameters"),
    }
    
    # Trajectory Parsers (Mutually Exclusive)
    parser_ex = groups["PARSER"].add_mutually_exclusive_group(required=False)
    parsers = [
        ("--ovito", "OVITO", "Use OVITO to extract species data from GROMACS and LAMMPS files."),
        ("--chem", "CHEM", "Use Chemfiles to extract species data from GROMACS and LAMMPS files."),
        ("--mda", "MDA", "Use MDAnalysis to extract species data from GROMACS files."),
        ("--pdb", "PDB", "Use PDB parser to extract species data from PDB files."),
        ("--lamp", "LAMP", "Use LAMP parser to extract species data from lammpstrj files."),
    ]
    for flag, dest, hlp in parsers:
        parser_ex.add_argument(flag, dest=dest, action="store_true", help=hlp)
    parser_ex.add_argument("--exe", dest="EXE", type=str, metavar="EXECUTABLE", help="Use gmx trjconv to extract species data. Example: --exe gmx")
        
    # Analysis Modes
    groups["Mode"].add_argument("--gro", dest="GRO", action="store_true", help="Run GROMACS analysis.")
    groups["Mode"].add_argument("--lam", dest="LAM", action="store_true", help="Run LAMMPS analysis.")

    # File & Path Arguments
    file_configs = [
        ("--itp", "ITP", "Directory containing GROMACS ITP files."),
        ("--traj", "TRAJ", "Path to trajectory file."),
        ("--tpr", "TPR", "Path to GROMACS TPR file."),
        ("--com", "COM", "Path to COM file."),
        ("--lam_in", "LAM_IN", "Path to LAMMPS input file."),
        ("--data", "DATA", "Path to LAMMPS data file."),
    ]
    for flag, dest, hlp in file_configs:
        groups["File"].add_argument(flag, dest=dest, type=str, help=hlp)
        
    groups["Path"].add_argument("--gro_path", dest="GRO_PATH", type=str, default=None, help="Path to GROMACS files directory (default: current dir).")
    groups["Path"].add_argument("--lam_path", dest="LAM_PATH", type=str, default=None, help="Path to LAMMPS files directory (default: current dir).")

    # General Parameters
    gen_configs = [
        ("--temp", "Temp", float, "Temperature in Kelvin (e.g., --temp 298.0)."),
        ("--t_steps", "t_steps", int, "Time steps in ps (e.g., --t_steps 1)."),
        ("--n_delta", "n_delta", int, "Time window (in ps) for time origins shifting."),
        ("--steps", "steps", int, "Steps for time origins shifting (default: 1)."),
        ("--t_window", "t_window", int, "Time window (in ps) for slope calculations."),
        ("--min_window", "min_window", int, "Min time window (in ps) for diffusivity (default: 1000)."),
        ("--n", "N", int, "Frame stride for LAMMPS analysis."),
        ("--dump_frame", "dump_frame", int, "LAMMPS trajectory dumping frame."),
        ("--n_cores", "n_cores", int, "Number of CPU cores for parallel processing.")
    ]
    for flag, dest, typ, hlp in gen_configs:
        d_val = 1 if flag == "--steps" else None
        groups["Gen"].add_argument(flag, dest=dest, type=typ, default=d_val, help=hlp)
    
    groups["Gen"].add_argument("--dir", dest="DIR", nargs="+", choices=["x", "y", "z"], help="Specify directions (e.g., --dir x z).")
    groups["Gen"].add_argument("--n_steps", dest="n_steps", nargs=2, type=int, action=ValidateArgs, on_dash_error=CUSTOM_ERROR, help="Snapshots range in ps (e.g., --n_steps 0 10000).")
    groups["Gen"].add_argument("--mp_mode", dest="get_context", choices=["spawn", "fork", "forkserver"], default="spawn", help="Multiprocessing start method.")
    groups["Gen"].add_argument("--get_csv", dest="GET_CSV", choices=["atom", "com"], default=None, type=str.lower, help="Extract and save coordinates to csv file.")

    # Properties Calculations
    calc_map = {
        "msd": "Compute mean squared displacement and diffusion.",
        "tra": "Calculate ion-ion correlations.",
        "onsg": "Calculate Onsager transport coefficients.",
        "spda": "Spatial decomposition of ion-ion correlations.",
        "en": "Calculate Einstein conductivity.",
        "ne": "Calculate Nernst-Einstein conductivity.",
        "smd": "Calculate Stefan-Maxwell diffusivity.",
        "pcl": "Calculate pair correlation lifetime.",
        "cage_p": "Cage population analysis.",
        "cage": "Run cage correlation analysis.",
        "veh": "Transport mechanism analysis.",
        "rdf": "Calculate radial distribution functions.",
    }
    for flag, hlp in calc_map.items():
        groups["Calc"].add_argument(f"--{flag}", dest=flag.upper(), action="store_true", help=hlp)

    # Analysis-Specific Parameters
    groups["Spec"].add_argument("--resname", dest="resname", nargs="+", type=str, help="List of residue names to process.")
    groups["Spec"].add_argument("--species", dest="LAMP_SPECIES", nargs="+", help="Override species names in LAMMPS (e.g., --species EMI BF).")
    groups["Spec"].add_argument("--ref_species", dest="CA", nargs="+", help="Reference species for cage correlation.")
    groups["Spec"].add_argument("--cage_species", dest="AN", nargs="+", help="Cage species for cage correlation.")
    groups["Spec"].add_argument("--skip_species", dest="SKIP_SPECIES", nargs='+', help="Resnames to exclude from COM generation.")
    groups["Spec"].add_argument("--msd_species", dest="msd_species", nargs='+', help="Specific groups for MSD (e.g., resname EMI type HR).")
    groups["Spec"].add_argument("--rdf_pairs", dest="rdf_pairs", nargs='+', help="Specific pairs for RDF.")
    groups["Spec"].add_argument("--rcut", dest="RCUT", type=float, nargs="+", help="Solvation radius for analysis.")
    groups["Spec"].add_argument("--rbin", dest="RBIN", type=float, default=0.1, help="RDF bin width (default: 0.1).")
    groups["Spec"].add_argument("--rdf_mode", dest="rdf_mode", nargs=2, choices=['ATOM', 'COM', 'atom', 'com'], help="RDF mode: 'atom' or 'com'.")
    groups["Spec"].add_argument("--msd_mode", dest="msd_mode", choices=['atom', 'com'], help="MSD mode: 'atom' or 'com'.")
    groups["Spec"].add_argument("--fit_method", dest="fit_method", choices=['ols', 'gls', 'wls'], help="MSD fitting method: 'ols' or 'gls' or 'wls'.")
    groups["Spec"].add_argument("--shell", dest="shell", choices=['first', 'second'], help="Solvation shell choice for SPDA: 'first' or 'second'.")
    groups["Spec"].add_argument("--species_charges", dest="species_charges", nargs="+", default=None, help=("Override species charges. "
                                                                                                          "Provide a single value (e.g., 1.0) to scale all species by sign, "
                                                                                                          "or provide pairs (e.g., EMI 0.8 BF 0.9) to set specific values."))
    spec_bools = [
        ("--ana", "ANA", "Run optional RDFs analysis."),
        ("--eh", "EH", "Enable Einstein-Helfand formalism."),
        ("--disk", "USE_DISK", "Use disk storage for extracting coordinates."),
    ]
    for flag, dest, hlp in spec_bools:
        groups["Spec"].add_argument(flag, dest=dest, action="store_true", help=hlp)

    # Help & Examples
    parser.add_argument("-h", "--help", action="store_true", help="Show this help message.")
    parser.add_argument("-e", "--example", nargs="?", const="", help="Show examples. Use numbers like '1-3,5'.")
    
    # Case-Insensitive Logic
    valid_lowercase_options = {act.option_strings[0].lower() for act in parser._actions if act.option_strings and act.option_strings[0].startswith('--')}
    processed_argv = []
    for arg in argv:
        if arg.startswith('--'):
            base_arg = arg.split('=')[0].lower()
            if base_arg in valid_lowercase_options:
                processed_argv.append(base_arg + ('=' + arg.split('=', 1)[1] if '=' in arg else ''))
            else: processed_argv.append(arg)
        else: processed_argv.append(arg)

    args = parser.parse_args(processed_argv)
        
    if args.help: parser.print_help(); sys.exit(0)
    if args.example is not None: show_examples(args.example); sys.exit(0)
    
    # Validation Logic
    active_modes = [f for f in calc_map.keys() if getattr(args, f.upper())]
    if ((args.RDF and args.rdf_mode) or (args.MSD and args.msd_mode)) and len(active_modes) >= 2:
        logger.error("Advanced RDF/MSD mode cannot be combined with other active modes.")
        sys.exit(1)
    
    args._dest_map = {a.dest: (a.option_strings[0], isinstance(a, argparse._StoreTrueAction)) 
                     for a in parser._actions if a.option_strings}

    return args

def generate_input_file(args, filename="input.txt"):
    """Generates a text file containing all flags used during the run."""
    try:
        with open(filename, "w") as f:
            f.write("# MDTransport Input Configuration\n")
            f.write("# Auto-generated from recent run.\n")
            f.write("# To reuse this file, run: mdt --in input.txt\n\n")
            
            dest_map = getattr(args, '_dest_map', {})
            for dest, val in vars(args).items():
                if dest.startswith('_') or dest in ['help', 'example', 'input_file']: continue
                
                mapping = dest_map.get(dest)
                if not mapping: continue
                flag, is_bool = mapping
                
                # Treat empty strings or "None" strings as None
                if val is False or val is None or val == [] or val == "":
                    f.write(f"# {flag}\n")
                elif is_bool:
                    if val: f.write(f"{flag}\n")
                    else: f.write(f"# {flag}\n")
                else:
                    val_str = " ".join(map(str, val)) if isinstance(val, (list, tuple)) else str(val)
                    f.write(f"{flag} {val_str}\n")
                    
        logger.info(f"Input configuration saved to '{filename}'. You can reuse it with: --in {filename}", extra={'caller': 'MDTransport'})
        
        if not args.USE_DISK:
            logger.info("\nCoordinate data is currently being stored in memory. " "To reduce memory usage, enable disk storage with the '--disk' flag.", extra={'caller': 'MDTransport'})
        
    except Exception as e:
        logger.error(f"Failed to write input file: {e}", extra={'caller': 'MDTransport'})

def run(**kwargs):
    """
    MDTransport Jupyter Runner.
    """
    try:
        args = parse_arguments([])
        
        arg_map = {
            "species": "SPECIES",
            "rcut": "RCUT",
            "skip_species": "SKIP_SPECIES",
            "ref_species": "CA",
            "cage_species": "AN",
            "dir": "DIR",
            "rdf_pairs": "rdf_pairs",
            "msd_species": "msd_species",
            "resname": "resname",
            "n_steps": "n_steps",
            "use_disk": "USE_DISK",
            "gro": "GRO",
            "lam": "LAM",
            "traj": "TRAJ",
            "tpr": "TPR",
            "t_steps": "t_steps",
            "n_cores": "n_cores",
            "temp": "Temp",
            "species_charges": "species_charges",
        }

        list_type_flags = [
            "msd_species", "resname", "SKIP_SPECIES", "DIR", 
            "rdf_pairs", "SPECIES", "CA", "AN", "RCUT", "n_steps", "species_charges"
        ]

        for key, value in kwargs.items():
            target_key = arg_map.get(key.lower(), key)
            
            if target_key in list_type_flags and isinstance(value, str):
                import re
                # Split by whitespace, matching how a Shell/Terminal passes arguments
                value = [item.strip() for item in re.split(r'\s+', value) if item.strip()]
            
            if key.lower() == "species":
                setattr(args, "resname", value)
                setattr(args, "msd_species", value)

            setattr(args, target_key, value)
            
        args = validate_arguments(args) 
        generate_input_file(args)
        
        engine = None
        if getattr(args, 'GRO', False): 
            engine = GROMACS(args)
        elif getattr(args, 'LAM', False): 
            engine = LAMMPS(args)
        else:
            print("ERROR: Must specify either GRO=True or LAM=True")
            return None

        engine.run_analysis()
        return engine

    except Exception as e:
        import traceback
        traceback.print_exc()
        return None

def main():
    
    try:
        print_banner()
        
        args = validate_arguments(parse_arguments())
        
        generate_input_file(args)
        
        if args.GRO: 
            GROMACS(args).run_analysis()
        elif args.LAM: 
            LAMMPS(args).run_analysis()
            
    except KeyboardInterrupt:
        logger.error("Execution cancelled by user. Exiting...", extra={'caller': 'MDTransport'})
        sys.exit(1)
    except SystemExit:
        pass 
    except Exception:
        logger.exception("An unexpected error occurred.", extra={'caller': 'MDTransport'})

if __name__ == "__main__":
    main()