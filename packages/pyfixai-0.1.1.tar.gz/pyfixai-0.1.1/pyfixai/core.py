import os
import subprocess
import sys

from .fixer import get_fix
from .utils import backup_file, show_diff


def run_python_file(file_path):
    try:
        result = subprocess.run(
            [sys.executable, file_path],
            capture_output=True,
            text=True,
            timeout=10
        )

        return {
            "success": result.returncode == 0,
            "stdout": result.stdout,
            "stderr": result.stderr
        }

    except Exception as e:
        return {
            "success": False,
            "stdout": "",
            "stderr": str(e)
        }


def clean_code(code):
    if not code:
        return None

    if "```" in code:
        code = code.replace("```python", "").replace("```", "")

    return code.strip()


def autofix(file_path, max_retries=10, auto_apply=True):
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"{file_path} not found")

    backup_path = backup_file(file_path)
    print(f"📁 Backup created: {backup_path}")

    for attempt in range(max_retries):
        print(f"\n🔁 Attempt {attempt+1}")

        result = run_python_file(file_path)

        output = result["stdout"] + "\n" + result["stderr"]

        has_error = any(e in output for e in [
            "Traceback", "Error", "Exception", "SyntaxError",
            "TypeError", "NameError", "IndexError", "KeyError",
            "ValueError", "AttributeError", "RecursionError",
            "FileNotFoundError",
        ])

        if result["success"] and not has_error:
            print("✅ Code ran successfully!")
            print(result["stdout"])
            return True

        print("❌ Error detected:")
        print(output)

        with open(file_path, "r", encoding="utf-8") as f:
            code = f.read()

        fixed_raw = get_fix(code, output, previous_output=output)

        if not fixed_raw:
            print("⚠️ No fix returned — stopping.")
            break

        fixed_code = clean_code(fixed_raw)

        if not fixed_code or fixed_code.strip() == code.strip():
            print("⚠️ No meaningful changes — stopping.")
            break

        print("\n🔍 Diff:")
        print(show_diff(code, fixed_code))

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(fixed_code)

        print("✅ Fix applied!")

    print("\n❌ Max retries reached.")
    return False