import typer
from .core import pyfixai

app = typer.Typer()

@app.command()
def run(file: str):
    pyfixai(file)

if __name__ == "__main__":
    app()