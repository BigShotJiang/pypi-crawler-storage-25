"""CLI handler for `efterlev readiness`. Renders the ReadinessReport."""

from __future__ import annotations

import json
from pathlib import Path

import typer

from efterlev.frmr import FrmrDocument
from efterlev.primitives.readiness import compute_readiness


def _identify_procedural_ksis(frmr_doc: FrmrDocument) -> set[str]:
    """KSIs in the AFR / CED / INR themes are procedural by nature.

    These are the themes whose KSIs scanner code can't evidence — they
    cover personnel security, training, incident response, etc. The
    Gap Agent will typically classify them as `evidence_layer_inapplicable`;
    the customer needs to author a signed Evidence Manifest to "really
    cover" them.

    Heuristic by theme prefix. Could be refined later by checking the
    actual `varies_by_level.moderate.evidence_type` field in the FRMR
    catalog, but theme prefix is a useful first pass.
    """
    procedural_prefixes = ("KSI-AFR-", "KSI-CED-", "KSI-INR-")
    return {ksi_id for ksi_id in frmr_doc.indicators if ksi_id.startswith(procedural_prefixes)}


def run_readiness(target: Path, *, json_output: bool = False) -> int:
    """Execute the readiness command. Returns the process exit code (0 = success)."""
    root = target.resolve()
    frmr_cache = root / ".efterlev" / "cache" / "frmr_document.json"
    if not frmr_cache.is_file():
        typer.echo(
            f"error: FRMR cache missing at {frmr_cache}. Run `efterlev init` first.",
            err=True,
        )
        return 1

    frmr_doc = FrmrDocument.model_validate_json(frmr_cache.read_text(encoding="utf-8"))
    baseline_ksi_ids = list(frmr_doc.indicators.keys())
    procedural_ksi_ids = _identify_procedural_ksis(frmr_doc)

    report = compute_readiness(
        root,
        baseline_ksi_ids=baseline_ksi_ids,
        procedural_ksi_ids=procedural_ksi_ids,
    )

    if json_output:
        # Stable JSON shape; downstream tools consume this.
        typer.echo(
            json.dumps(
                {
                    "score": {
                        "overall_pct": report.score.overall_pct,
                        "ksi_coverage_pct": report.score.ksi_coverage_pct,
                        "manifest_coverage_pct": report.score.manifest_coverage_pct,
                        "severity_penalty_pct": report.score.severity_penalty_pct,
                        "band_label": report.score.band_label,
                    },
                    "ksi_classifications_total": report.ksi_classifications_total,
                    "ksis_in_baseline": report.ksis_in_baseline,
                    "open_poam": {
                        "high": report.open_poam_high,
                        "medium": report.open_poam_medium,
                        "low": report.open_poam_low,
                    },
                    "detectors_fired": report.detectors_fired,
                    "manifests_loaded": report.manifests_loaded,
                    "top_blockers": [
                        {
                            "ksi_id": b.ksi_id,
                            "reason": b.reason,
                            "suggested_action": b.suggested_action,
                        }
                        for b in report.top_blockers
                    ],
                },
                indent=2,
            )
        )
        return 0

    # Human-readable scorecard.
    _render_scorecard(report)
    return 0


def _render_scorecard(report) -> None:
    """Print the scorecard in the format the README mocks."""
    score = report.score

    # Progress bar — 10 cells, ▰ filled, ▱ empty.
    filled = round(score.overall_pct / 10)
    bar = "▰" * filled + "▱" * (10 - filled)

    typer.echo("")
    typer.echo("  Readiness for FedRAMP 20x Moderate")
    typer.echo("")
    typer.echo(f"  Score      {bar}  {score.overall_pct:.0f}%  {score.band_label}")
    typer.echo("")

    # Coverage sub-scores
    typer.echo(
        f"  KSI coverage      "
        f"{report.ksi_classifications_total} / {report.ksis_in_baseline} ksis classified"
    )
    typer.echo(
        f"  Open POA&M items  "
        f"{report.open_poam_high + report.open_poam_medium}  "
        f"({report.open_poam_high} HIGH, {report.open_poam_medium} MEDIUM)"
    )
    typer.echo(f"  Detector firings  {report.detectors_fired} evidence records in the store")
    typer.echo(f"  Manifests         {report.manifests_loaded} procedural attestations loaded")
    typer.echo("")

    if report.top_blockers:
        typer.echo("  Top blockers")
        for i, b in enumerate(report.top_blockers, start=1):
            typer.echo(f"    {i}. {b.ksi_id}  {b.reason}")
        typer.echo("")
        typer.echo("  Suggested next")
        for b in report.top_blockers:
            typer.echo(f"    • {b.suggested_action}")
        typer.echo("")
    else:
        if report.ksi_classifications_total == 0:
            typer.echo("  Suggested next")
            typer.echo("    • efterlev scan && efterlev agent gap     to get classifications")
            typer.echo("")
        else:
            typer.echo("  No HIGH-severity blockers — ready to package and engage a 3PAO.")
            typer.echo("")

    typer.echo("  When ready")
    typer.echo("    • efterlev submission package     to bundle for your 3PAO")
    typer.echo("")
