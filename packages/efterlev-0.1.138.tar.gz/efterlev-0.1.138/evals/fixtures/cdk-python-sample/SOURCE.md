# cdk-python-sample fixture

A minimal hand-authored AWS CDK Python project. Used by
`tests/test_cdk_python_scan.py` to validate that the CDK source-mode
scan pipeline (parser → adapter → detector dispatch) works end-to-end
and that emitted Evidence carries `.py` file:line citations.

This is a **synthetic fixture**. The CDK code is realistic in shape but
contains no proprietary or sensitive content; it covers the constructs
the v0.1.126 Stage 1 parser supports (`aws_cdk.aws_s3.Bucket`).

Stage 2+ batches will expand the fixture as more constructs are
supported. The CFN-side equivalent fixture
(`evals/fixtures/csp-starter-cfn/`) is the maturity target; this CDK
fixture starts smaller because the construct support starts smaller.
