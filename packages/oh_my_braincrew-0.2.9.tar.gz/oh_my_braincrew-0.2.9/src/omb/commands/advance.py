"""CLI command for advancing pipeline state within a single turn.

`omb advance <session_id> --result APPROVED` marks the active task as done,
activates the next ready task, and prints a JSON status line.
"""
# BCRW-PLAN-000087

from __future__ import annotations

import json
import logging
import os
import sys
from typing import TYPE_CHECKING

import click

from omb.pipeline.storage import PipelineStorage
from omb.pipeline.types import PipelineStatus, ResultStatus
from omb.services.paths import resolve_project_root

if TYPE_CHECKING:
    from pathlib import Path

logger = logging.getLogger(__name__)


def _project_root() -> Path:
    """Resolve project root."""
    return resolve_project_root()


@click.command("advance")
@click.argument("session_id")
@click.option(
    "--result",
    type=click.Choice(["APPROVED", "REJECT", "FAILED", "NONE"], case_sensitive=False),
    default="APPROVED",
    help="Result status for the active task.",
)
def advance_cmd(session_id: str, result: str) -> None:
    """Advance pipeline state: mark active task done, activate next task.

    SESSION_ID is the pipeline session identifier.
    Outputs a single JSON line: {"pipeline_status", "active_task", "message"}
    """
    root = _project_root()
    storage = PipelineStorage(root)

    if not storage.exists(session_id):
        click.echo(f"[advance] session {session_id!r} not found", err=True)
        sys.exit(1)

    try:
        state = storage.load(session_id)
    except Exception as exc:  # noqa: BLE001
        click.echo(f"[advance] session {session_id!r} state is corrupted: {exc}", err=True)
        sys.exit(1)

    if state is None:
        click.echo(f"[advance] failed to load session {session_id!r}", err=True)
        sys.exit(1)

    # Bind claude_session_id from env or file fallback
    claude_uuid = os.environ.get("CLAUDE_SESSION_ID", "")
    if not claude_uuid:
        uuid_file = root / ".omb" / "sessions" / ".claude-uuid"
        if uuid_file.exists():
            claude_uuid = uuid_file.read_text().strip()
    if claude_uuid and state.claude_session_id is None:
        state.claude_session_id = claude_uuid

    if state.status != PipelineStatus.ACTIVE:
        click.echo(
            f"[advance] pipeline {session_id!r} is {state.status}, not active",
            err=True,
        )
        sys.exit(1)

    if state.active_task() is None:
        click.echo(f"[advance] pipeline {session_id!r} has no active task", err=True)
        sys.exit(1)

    try:
        status = ResultStatus(result.upper())
    except ValueError:
        click.echo(f"[advance] invalid result {result!r}", err=True)
        sys.exit(1)

    from omb.hook.types import EventType, HookInput  # noqa: PLC0415
    from omb.services.notification import load_config as load_slack_config  # noqa: PLC0415
    from omb.session.handler import SessionHandler  # noqa: PLC0415

    slack_config = load_slack_config()
    handler = SessionHandler(storage, notification_config=slack_config)

    hook_input = HookInput(
        session_id=session_id,
        cwd=str(root),
        hook_event_name="Stop",
    )

    try:
        output = handler.handle(state, EventType.STOP, hook_input, status)
    except Exception as exc:  # noqa: BLE001
        logger.exception("[advance] handler error")
        click.echo(f"[advance] handler error: {exc}", err=True)
        sys.exit(1)

    # Archive session and clean up lock file when pipeline reaches a terminal state
    if state.status in {PipelineStatus.COMPLETED, PipelineStatus.STALLED, PipelineStatus.CANCELLED}:
        try:
            storage.archive(session_id)
            logger.info("[advance] archived session %s to finished/", session_id)
        except Exception as exc:  # noqa: BLE001
            logger.warning("[advance] failed to archive session %s: %s", session_id, exc)

    active = state.active_task()
    result_json = {
        "pipeline_status": str(state.status),
        "active_task": active.task_name if active else None,
        "message": output.message or "",
    }
    click.echo(json.dumps(result_json))
