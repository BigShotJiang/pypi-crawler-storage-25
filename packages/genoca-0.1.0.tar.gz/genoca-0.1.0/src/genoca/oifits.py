import datetime
import numpy as np
from astropy.io import fits
from astropy.time import Time
from astroquery.vizier import Vizier
import math
import copy
from scipy import signal
import pandas
from urllib.parse import quote_plus

from genoca import utils
from genoca import dic_catalog, dic_objname, TOOL_NAME

##
# @brief Oifits constructor
#
class Oifits:
    def __init__(self):
        self.hdu = fits.PrimaryHDU()
        self.oitarget = Oitarget()
        self.oiarray = Oiarray()
        self.oiwavelength = Oiwavelength()
        self.oivis2 = Oivis2()
        self.oivis = Oivis()
        self.oit3 = Oit3()
        self.oiflux = Oiflux()
    # --------------------------------------------------------------
    #   Public Methods
    # --------------------------------------------------------------
    ##
    # @brief ...
    # 
    def flagBaseline(self,badBase):
        for iBase in badBase:
            self.oivis2.setFlagBaseline(iBase)
            self.oivis.setFlagBaseline(iBase)
            self.oit3.setFlagBaseline(self.oivis2.getStaindex()[iBase])

    ##
    # @brief ...
    # 
    def flagWavelength(self,lmin,lmax):
        wave=self.oiwavelength.getWavelength()
        nband=len(lmin)
        for iband in range(nband):
            for iWave in range(len(wave)):
                if ( wave[iWave] >= lmin[iband] and wave[iWave] <= lmax[iband] ):
                    self.oivis2.setFlagWavelength(iWave)
                    self.oivis.setFlagWavelength(iWave)
                    self.oit3.setFlagWavelength(iWave)

    ##
    # @brief ...
    # @param hdr ...
    #
    def fillFromHeader(self, hdr):
        self.hdu.header = hdr
        currentDT = datetime.datetime.now()
        self.hdu.header['DATE'] = currentDT.strftime("%Y-%m-%dT%H:%M:%S")
        self.hdu.header['AUTHOR'] = TOOL_NAME

    ##
    # @brief ...
    # @param filename ...
    #
    def save(self,filename):
        oitarget_binary_hdu=self.oitarget.createTable()
        oiarray_binary_hdu=self.oiarray.createTable()
        oiwavelength_binary_hdu=self.oiwavelength.createTable()
        oivis2_binary_hdu=self.oivis2.createTable()
        oivis_binary_hdu=self.oivis.createTable()
        oit3_binary_hdu=self.oit3.createTable()
        oiflux_binary_hdu=self.oiflux.createTable()
        hdul = fits.HDUList([self.hdu,oitarget_binary_hdu,oiarray_binary_hdu, \
                             oiwavelength_binary_hdu,oivis2_binary_hdu, \
                             oivis_binary_hdu,oit3_binary_hdu,oiflux_binary_hdu])
        hdul.writeto(filename,overwrite=True)
        del hdul

    ##
    # @brief ...
    # @param filename ...
    #
    def load(self,filename):
        hdu=fits.open(filename)
        self.fillFromHeader(hdu[0].header)
        del hdu
        self.oitarget.load(filename)
        self.oiarray.load(filename)
        self.oiwavelength.load(filename)
        self.oivis2.load(filename)
        self.oivis.load(filename)
        self.oit3.load(filename)
        self.oiflux.load(filename)

    ##
    # @brief ...
    # @param tf2 ...
    # @param tf2inverr ...
    # @param tfamp ...
    # @param tfamperr ...
    # @param tfphi ...
    # @param tfphierr ...
    # @param tfdphi ...
    # @param tfdphierr ...
    #
    def calibrate(self,tf2,tf2err,tfamp,tfamperr,tfphi,tfphierr,tfdphi,tfdphierr):
        m,v = utils.ratio_mean(np.nan_to_num(self.oivis2.getVis2(),nan=0.0), \
                               np.nan_to_num(self.oivis2.getVis2err(),nan=1.E5),tf2,tf2err)
        self.oivis2.setVis2err(np.sqrt(v))
        self.oivis2.setVis2(m)
        
      
        self.oit3.setT3amp(self.oit3.getT3amp()/tfamp)
        self.oit3.setT3amperr(self.oit3.getT3amperr()/tfamp)

        #No Calibration of the Closure Phase
        #self.oit3.setT3phi(self.oit3.getT3phi()-tfphi)
        #self.oit3.setT3phierr(np.sqrt(self.oit3.getT3phierr()**2+tfphierr**2))

        self.oivis.setVisphi(self.oivis.getVisphi()-tfdphi)
        self.oivis.setVisphierr(np.sqrt(self.oivis.getVisphierr()**2+tfdphierr**2))

##
# @class Oitarget
# ...
#

class Oitarget:
    def __init__(self):
        self.__targetid=[]
        self.__target=[]
        self.__raep0=[]
        self.__decep0=[]
        self.__equinox=[]
        self.__raerr=[]
        self.__decerr=[]
        self.__sysvel=[]
        self.__veltyp=[]
        self.__veldef=[]
        self.__pmra=[]
        self.__pmdec=[]
        self.__pmraerr=[]
        self.__pmdecerr=[]
        self.__parallax=[]
        self.__paraerr=[]
        self.__spetyp=[]
        self.__category=[]
    # --------------------------------------------------------------
    # Private Methods
    # --------------------------------------------------------------
    def __eq__(self,other):
        return True
    
    # --------------------------------------------------------------
    #   Public Methods
    # --------------------------------------------------------------
    ##
    # @brief ...
    # @param hdr ...
    #
    def getTargetId(self):
        print(self.__targetid,self.__target,len(self.__targetid))
        
    def getTargetName(self):
        return self.__target[0]
    ##
    # @brief ...
    # @return ...
    #
    def createTable(self):
        col1 = fits.Column(name='TARGET_ID', format='I', array=self.__targetid)
        col2 = fits.Column(name='TARGET', format='A16', array=self.__target)
        col3 = fits.Column(name='RAEP0', format='D', unit='deg', array=self.__raep0)
        col4 = fits.Column(name='DECEP0', format='D', unit='deg', array=self.__decep0)
        col5 = fits.Column(name='EQUINOX', format='E', unit='yr', array=self.__equinox)
        col6 = fits.Column(name='RA_ERR', format='D', unit='deg', array=self.__raerr)
        col7 = fits.Column(name='DEC_ERR', format='D', unit='deg', array=self.__decerr)
        col8 = fits.Column(name='SYSVEL', format='D', unit='m/s', array=self.__sysvel)
        col9 = fits.Column(name='VELTYP', format='A8', array=self.__veltyp)
        col10 = fits.Column(name='VELDEF', format='A8', array=self.__veldef)
        col11 = fits.Column(name='PMRA', format='D', unit='deg/yr', array=self.__pmra)
        col12 = fits.Column(name='PMDEC', format='D', unit='deg/yr', array=self.__pmdec)
        col13 = fits.Column(name='PMRA_ERR', format='D', unit='deg/yr', array=self.__pmraerr)
        col14 = fits.Column(name='PMDEC_ERR', format='D', unit='deg/yr', array=self.__pmdecerr)
        col15 = fits.Column(name='PARALLAX', format='E', unit='deg', array=self.__parallax)
        col16 = fits.Column(name='PARA_ERR', format='E', unit='deg', array=self.__paraerr)
        col17 = fits.Column(name='SPECTYP', format='A16', array=self.__spetyp)
        col18 = fits.Column(name='CATEGORY', format='A3', array=self.__category)
        coldefs = fits.ColDefs([col1, col2, col3, col4, col5, col6 , \
                                col7, col8, col9, col10, col11, col12 , \
                                col13, col14, col15, col16, col17, col18])
        binary_hdu = fits.BinTableHDU.from_columns(coldefs)
        binary_hdu.header.set('OI_REVN',2,'Revision Number')
        binary_hdu.header.set('EXTNAME','OI_TARGET')
        return binary_hdu

    ##
    # @brief ...
    # @param filename Name of the file to read
    #
    def load (self,filename):
        hdu=fits.open(filename)
        for iRow in range(hdu['OI_TARGET'].header['NAXIS2']):
            self.__targetid.append(hdu['OI_TARGET'].data['TARGET_ID'][iRow])
            self.__target.append(hdu['OI_TARGET'].data['TARGET'][iRow])
            self.__raep0.append(hdu['OI_TARGET'].data['RAEP0'][iRow])
            self.__decep0.append(hdu['OI_TARGET'].data['DECEP0'][iRow])
            self.__equinox.append(hdu['OI_TARGET'].data['EQUINOX'][iRow])
            self.__raerr.append(hdu['OI_TARGET'].data['RA_ERR'][iRow])
            self.__decerr.append(hdu['OI_TARGET'].data['DEC_ERR'][iRow])
            self.__sysvel.append(hdu['OI_TARGET'].data['SYSVEL'][iRow])
            self.__veltyp.append(hdu['OI_TARGET'].data['VELTYP'][iRow])
            self.__veldef.append(hdu['OI_TARGET'].data['VELDEF'][iRow])
            self.__pmra.append(hdu['OI_TARGET'].data['PMRA'][iRow])
            self.__pmdec.append(hdu['OI_TARGET'].data['PMDEC'][iRow])
            self.__pmraerr.append(hdu['OI_TARGET'].data['PMRA_ERR'][iRow])
            self.__pmdecerr.append(hdu['OI_TARGET'].data['PMDEC_ERR'][iRow])
            self.__parallax.append(hdu['OI_TARGET'].data['PARALLAX'][iRow])
            self.__paraerr.append(hdu['OI_TARGET'].data['PARA_ERR'][iRow])
            self.__spetyp.append(hdu['OI_TARGET'].data['SPECTYP'][iRow])
            if 'CATEGORY' in hdu['OI_TARGET'].columns.names:
                 self.__category.append(hdu['OI_TARGET'].data['CATEGORY'][iRow])
        hdu.close()

##
# @class Oiarray
# ...
#
class Oiarray:
    ##
    # @brief Oiarray constructor
    #
    def __init__(self):
        self.__telname=[]
        self.__staname=[]
        self.__staindex=[]
        self.__diameter=[]
        self.__staxyz=[]
        self.__fov=[]
        self.__fovtype=[]
        self.__arrname = ""
        self.__frame = ""
        self.__arraycoord = [0., 0., 0.]
        
    ##
    # @brief ...
    # @return ...
    #
    def createTable(self):
        col1 = fits.Column(name='TEL_NAME', format='A16', array=self.__telname)
        col2 = fits.Column(name='STA_NAME', format='A16', array=self.__staname)
        col3 = fits.Column(name='STA_INDEX', format='I', array=self.__staindex)
        col4 = fits.Column(name='DIAMETER', format='E', unit='m', array=self.__diameter)
        col5 = fits.Column(name='STAXYZ', format='3D', unit='m', array=self.__staxyz)
        col6 = fits.Column(name='FOV', format='D', unit='as', array=self.__fov)
        col7 = fits.Column(name='FOVTYPE', format='A6', array=self.__fovtype)
        coldefs = fits.ColDefs([col1, col2, col3, col4, col5, col6 , col7])
        binary_hdu = fits.BinTableHDU.from_columns(coldefs)
        binary_hdu.header.set('OI_REVN',2,'Revision Number')
        binary_hdu.header.set('EXTNAME','OI_ARRAY')
        binary_hdu.header.set('ARRNAME', self.__arrname, 'Array name')
        binary_hdu.header.set('FRAME', self.__frame, 'Coordinate frame')
        binary_hdu.header.set('ARRAYX', self.__arraycoord[0], 'Array center coordinates X (m)')
        binary_hdu.header.set('ARRAYY', self.__arraycoord[1], 'Array center coordinates Y (m)')
        binary_hdu.header.set('ARRAYZ', self.__arraycoord[2], 'Array center coordinates Z (m)')
        return binary_hdu

    ##
    # @brief ...
    # @param filename ...
    #
    def load (self,filename):
        hdu=fits.open(filename)
        self.__arrname = hdu['OI_ARRAY'].header['ARRNAME']
        self.__frame = hdu['OI_ARRAY'].header['FRAME']
        self.__arraycoord[0] = hdu['OI_ARRAY'].header['ARRAYX']
        self.__arraycoord[1] = hdu['OI_ARRAY'].header['ARRAYY']
        self.__arraycoord[2] = hdu['OI_ARRAY'].header['ARRAYZ']
        
        for iRow in range(hdu['OI_ARRAY'].header['NAXIS2']):
            self.__telname.append(hdu['OI_ARRAY'].data['TEL_NAME'][iRow])
            self.__staname.append(hdu['OI_ARRAY'].data['STA_NAME'][iRow])
            self.__staindex.append(hdu['OI_ARRAY'].data['STA_INDEX'][iRow])
            self.__diameter.append(hdu['OI_ARRAY'].data['DIAMETER'][iRow])
            self.__staxyz.append(hdu['OI_ARRAY'].data['STAXYZ'][iRow])
            if 'GRAVITY' in hdu[0].header['INSTRUME']:
                self.__fov.append(1.0)
                self.__fovtype.append('RADIUS')
            else:
                self.__fov.append(hdu['OI_ARRAY'].data['FOV'][iRow])
                self.__fovtype.append(hdu['OI_ARRAY'].data['FOVTYPE'][iRow])
        hdu.close()

##
# @class Oiwavelength
# ...
#
class Oiwavelength:
    ##
    # @brief Oiwavelength constructor
    #
    def __init__(self):
        self.__wavelength = []
        self.__bandwidth = []
        self.__insname = ""
    # --------------------------------------------------------------
    # Private Methods
    # --------------------------------------------------------------
    def __eq__(self,other):
        return True
    # --------------------------------------------------------------
    #   Public Methods
    # --------------------------------------------------------------
    
    ##
    # @brief Sets the wavelength value
    # @param w The wavelength value
    #
    def setWavelength(self,w):
        self.__wavelength = w

    ##
    # @brief ...
    # @param b ...
    #
    def setBandwidth(self,b):
        self.__bandwidth = b

    ##
    # @brief Gives the wavelength value 
    # @return The wavelength value
    #
    def getWavelength(self):
        return self.__wavelength

    ##
    # @brief ...
    # @return ...
    #
    def getBandwidth(self):
        return self.__bandwidth

    ##
    # @brief ...
    # @return ...
    #
    def createTable(self):
        col1 = fits.Column(name='EFF_WAVE', format='E', unit='m', array=self.__wavelength)
        col2 = fits.Column(name='EFF_BAND', format='E', unit='m', array=self.__bandwidth)
        coldefs = fits.ColDefs([col1, col2])
        binary_hdu = fits.BinTableHDU.from_columns(coldefs)
        binary_hdu.header.set('OI_REVN',2,'Revision Number')
        binary_hdu.header.set('INSNAME',self.__insname,'Name of detector')
        binary_hdu.header.set('EXTNAME','OI_WAVELENGTH')
        return binary_hdu

    ##
    # @brief ...
    # @param filename The file to read
    #
    def load (self,filename):
        hdul=fits.open(filename)
        instrume = hdul[0].header['INSTRUME']
        if 'GRAVITY' in instrume:
            tbl = utils.getHdu(hdul, 'OI_WAVELENGTH', 'GRAVITY_SC')
        else:
            tbl = hdul['OI_WAVELENGTH']
        self.__insname = tbl.header['INSNAME']
        self.__wavelength = tbl.data['EFF_WAVE']
        self.__bandwidth = tbl.data['EFF_BAND']
        hdul.close()

##
# @class Oivis2
# ...
#
class Oivis2:
    ##
    # @brief Oivis2 constructor
    #
    def __init__(self):
        self.__mjd = []
        self.__dit = []
        self.__vis2 = []
        self.__vis2err = []
        self.__u = []
        self.__v = []
        self.__staindex = []
        self.__flag = []
        self.__dateobs = ''
        self.__arrname = ''
        self.__insname = ''

    def setDateObsfromHeader(self, hdr):
        if 'DATE-OBS' in hdr:
            self.__dateobs=hdr['DATE-OBS']
        else:
            print('OI_VIS2: No DATE-OBS keyword in Input Header')

    def setMjd(self,v):
        self.__mjd=v
    def setIntTime(self,v):
        """setIntTime method"""
        self.__dit=v
    def setVis2(self,v):
        """setVis2 method"""
        self.__vis2=v
    def setVis2err(self,v):
        """setVis2err method"""
        self.__vis2err=v
    def setUcoord(self,v):
        """setUcoord method"""
        self.__u=v
    def setVcoord(self,v):
        """setVcoord method"""
        self.__v=v
    def setStaindex(self,v):
        """setStaindex method"""
        self.__staindex=v
    def setFlagBaseline(self,iBase):
        self.__flag[iBase,:]=True
        
    def setFlagWavelength(self,iWave):
        self.__flag[:,iWave]=True

    def getMjd(self):
        """getMjd method"""
        return self.__mjd
    def getIntTime(self):
        """getIntTime method"""
        return self.__dit
    def getVis2(self):
        """getVis2 method"""
        return self.__vis2
    def getVis2err(self):
        """getVis2err method"""
        return self.__vis2err
    def getUcoord(self):
        """getUcoord method"""
        return self.__u
    def getVcoord(self):
        """getVcoord method"""
        return self.__v
    def getStaindex(self):
        """getStaindex method"""
        return self.__staindex
    def getFlag(self):
        """getFlag method"""
        return self.__flag

    def createTable(self):
        """createTable method"""
        nBase, nWave = np.shape(self.__vis2)
        col1 = fits.Column(name='TARGET_ID', format='I', array=np.ones(nBase))
        col2 = fits.Column(name='TIME', format='D', unit='s', array=np.zeros(nBase))
        col3 = fits.Column(name='MJD', format='D', unit='d', array=self.__mjd)
        col4 = fits.Column(name='INT_TIME', format='D', unit='s', array=self.__dit)
        col5 = fits.Column(name='VIS2DATA', format=str(nWave)+'D', array=self.__vis2)
        col6 = fits.Column(name='VIS2ERR', format=str(nWave)+'D', array=self.__vis2err)
        col7 = fits.Column(name='UCOORD', format='D', unit='m', array=self.__u)
        col8 = fits.Column(name='VCOORD', format='D', unit='m', array=self.__v)
        col9 = fits.Column(name='STA_INDEX', format='2I', array=self.__staindex)
        col10 = fits.Column(name='FLAG', format=str(nWave)+'L', array=self.__flag)
        coldefs = fits.ColDefs([col1, col2, col3, col4, col5, col6 , col7, col8, col9, col10])
        binary_hdu = fits.BinTableHDU.from_columns(coldefs)
        binary_hdu.header.set('OI_REVN',2, 'Revision number')
        binary_hdu.header.set('DATE-OBS',self.__dateobs, 'UTC start date of observations')
        binary_hdu.header.set('ARRNAME',self.__arrname, 'Array name')
        binary_hdu.header.set('INSNAME',self.__insname, 'Name of detector')
        binary_hdu.header.set('EXTNAME','OI_VIS2')
        return binary_hdu

    def load (self,filename):
        """load method"""
        hdul=fits.open(filename)
        instrume = hdul[0].header['INSTRUME']
        if 'GRAVITY' in instrume:
            tbl = utils.getHdu(hdul, 'OI_VIS2', 'GRAVITY_SC')
        else:
            tbl = hdul['OI_VIS2']
        self.__arrname = tbl.header['ARRNAME']
        self.__insname = tbl.header['INSNAME']
        self.__mjd = tbl.data['MJD']
        self.__dit = tbl.data['INT_TIME']
        self.__vis2 = tbl.data['VIS2DATA']
        self.__vis2err = tbl.data['VIS2ERR']
        self.__u = tbl.data['UCOORD']
        self.__v = tbl.data['VCOORD']
        self.__staindex = tbl.data['STA_INDEX']
        self.__flag = tbl.data['FLAG']
        self.__dateobs = tbl.header['DATE-OBS']

        idx=np.where(self.__mjd != 0)
        mjdmean=np.mean(self.__mjd[idx[0]])
        nb,nw=np.shape(self.__vis2)
        for i in range(nb):
            if self.__mjd[i] == 0 :
                self.__mjd[i]=mjdmean
                self.__u[i]=1.
                self.__v[i]=1.
                for j in range(nw):
                    self.__vis2[i,j]=1.
                    self.__vis2err[i,j]=1.E10
                    
        hdul.close()
        
        

class Oivis:
    """Oivis class"""
    def __init__(self):
        self.__mjd = []
        self.__dit = []
        self.__visamp = []
        self.__visamperr = []
        self.__visphi = []
        self.__visphierr = []
        self.__u = []
        self.__v = []
        self.__staindex = []
        self.__flag = []
        self.__dateobs = ''
        self.__arrname = ''
        self.__insname = ''

    def setDateObsfromHeader(self, hdr):
        """setDateObsfromHeader method"""
        if 'DATE-OBS' in hdr:
            self.__dateobs=hdr['DATE-OBS']
        else:
            print('OI_VIS: No DATE-OBS keyword in Input Header')

    def setMjd(self,v):
        """setMjd method"""
        self.__mjd=v
    def setIntTime(self,v):
        """setIntTime method"""
        self.__dit=v
    def setVisamp(self,v):
        """setVisamp method"""
        self.__visamp=v
    def setVisamperr(self,v):
        """setVisamperr method"""
        self.__visamperr=v
    def setVisphi(self,v):
        """setVisphi method"""
        self.__visphi=v
    def setVisphierr(self,v):
        """setVisphierr method"""
        self.__visphierr=v
    def setUcoord(self,v):
        """setUcoord method"""
        self.__u=v
    def setVcoord(self,v):
        """setVcoord method"""
        self.__v=v
    def setStaindex(self,v):
        """setStaindex method"""
        self.__staindex=v
    def setFlagBaseline(self,iBase):
        self.__flag[iBase,:]=True
        
    def setFlagWavelength(self,iWave):
        self.__flag[:,iWave]=True

    def getMjd(self):
        """getMjd method"""
        return self.__mjd
    def getIntTime(self):
        """getIntTime method"""
        return self.__dit
    def getVisamp(self):
        """getVisamp method"""
        return self.__visamp
    def getVisamperr(self):
        """getVisamperr method"""
        return self.__visamperr
    def getVisphi(self):
        """getVisphi method"""
        return self.__visphi
    def getVisphierr(self):
        """getVisphierr method"""
        return self.__visphierr
    def getUcoord(self):
        """getUcoord method"""
        return self.__u
    def getVcoord(self):
        """getVcoord method"""
        return self.__v
    def getStaindex(self):
        """getStaindex method"""
        return self.__staindex
    def getFlag(self):
        """getFlagmethod"""
        return self.__flag

    def createTable(self):
        """createTable method"""
        nBase, nWave = np.shape(self.__visamp)
        col1 = fits.Column(name='TARGET_ID', format='I', array=np.ones(nBase))
        col2 = fits.Column(name='TIME', format='D', unit='s', array=np.zeros(nBase))
        col3 = fits.Column(name='MJD', format='D', unit='d', array=self.__mjd)
        col4 = fits.Column(name='INT_TIME', format='D', unit='s', array=self.__dit)
        col5 = fits.Column(name='VISAMP', format=str(nWave)+'D', array=self.__visamp)
        col6 = fits.Column(name='VISAMPERR', format=str(nWave)+'D', array=self.__visamperr)
        col7 = fits.Column(name='VISPHI', format=str(nWave)+'D', unit='deg', array=self.__visphi)
        col8 = fits.Column(
            name='VISPHIERR',
            format=str(nWave)+'D',
            unit='deg',
            array=self.__visphierr
            )
        col9 = fits.Column(name='UCOORD', format='D', unit='m', array=self.__u)
        col10 = fits.Column(name='VCOORD', format='D', unit='m', array=self.__v)
        col11 = fits.Column(name='STA_INDEX', format='2I', array=self.__staindex)
        col12 = fits.Column(name='FLAG', format=str(nWave)+'L', array=self.__flag)
        coldefs = fits.ColDefs([col1, col2, col3, col4, col5, col6 , col7, \
                                col8, col9, col10, col11, col12])
        binary_hdu = fits.BinTableHDU.from_columns(coldefs)
        binary_hdu.header.set('OI_REVN',2, 'Revision number')
        binary_hdu.header.set('DATE-OBS',self.__dateobs, 'UTC start date of observations')
        binary_hdu.header.set('ARRNAME',self.__arrname, 'Array name')
        binary_hdu.header.set('INSNAME',self.__insname, 'Name of detector')
        binary_hdu.header.set('AMPTYPE','differential', 'type of visamp')
        binary_hdu.header.set('PHITYPE','differential', 'type of visphi')
        binary_hdu.header.set('EXTNAME','OI_VIS')
        return binary_hdu

    def load (self,filename):
        """load method"""
        hdul=fits.open(filename)
        instrume = hdul[0].header['INSTRUME']
        if 'GRAVITY' in instrume:
            tbl = utils.getHdu(hdul, 'OI_VIS', 'GRAVITY_SC')
        else:
            tbl = hdul['OI_VIS']
        self.__arrname = tbl.header['ARRNAME']
        self.__insname = tbl.header['INSNAME']
        self.__mjd = tbl.data['MJD']
        self.__dit = tbl.data['INT_TIME']
        self.__visamp = tbl.data['VISAMP']
        self.__visamperr = tbl.data['VISAMPERR']
        self.__visphi = tbl.data['VISPHI']
        self.__visphierr = tbl.data['VISPHIERR']
        self.__u = tbl.data['UCOORD']
        self.__v = tbl.data['VCOORD']
        self.__staindex = tbl.data['STA_INDEX']
        self.__flag = tbl.data['FLAG']
        self.__dateobs = tbl.header['DATE-OBS']
        
        idx=np.where(self.__mjd != 0)
        mjdmean=np.mean(self.__mjd[idx[0]])
        nb,nw=np.shape(self.__visamp)
        for i in range(nb):
            if self.__mjd[i] == 0 :
                self.__mjd[i]=mjdmean
                self.__u[i]=1.
                self.__v[i]=1.
                for j in range(nw):
                    self.__visamp[i,j]=1.
                    self.__visamperr[i,j]=1.E10
                    self.__visphi[i,j]=0.
                    self.__visphierr[i,j]=1.E10
        hdul.close()


class Oit3:
    """Oit3 class"""
    def __init__(self):
        self.__mjd = []
        self.__dit = []
        self.__t3amp = []
        self.__t3amperr = []
        self.__t3phi = []
        self.__t3phierr = []
        self.__u1 = []
        self.__v1 = []
        self.__u2 = []
        self.__v2 = []
        self.__staindex = []
        self.__flag = []
        self.__dateobs = ''
        self.__arrname = ''
        self.__insname = ''

    def setDateObsfromHeader(self, hdr):
        """setDateObsfromHeader method"""
        if 'DATE-OBS' in hdr:
            self.__dateobs=hdr['DATE-OBS']
        else:
            print('OI_T3: No DATE-OBS keyword in Input Header')
            
    def setFlagBaseline(self,staindex):
        nTriplet=len(self.__mjd)
        for iTriplet in range(nTriplet):
            if (staindex[0] in self.__staindex[iTriplet] and staindex[1] in self.__staindex[iTriplet]):
                self.__flag[iTriplet,:]=True
        
    def setFlagWavelength(self,iWave):
        self.__flag[:,iWave]=True

    def setMjd(self,v):
        """setMjd method"""
        self.__mjd=v
    def setIntTime(self,v):
        """setIntTime method"""
        self.__dit=v
    def setT3amp(self,v):
        """setT3amp method"""
        self.__t3amp=v
    def setT3amperr(self,v):
        """setT3amperr method"""
        self.__t3amperr=v
    def setT3phi(self,v):
        """setT3phi method"""
        self.__t3phi=v
    def setT3phierr(self,v):
        """setT3phierr method"""
        self.__t3phierr=v
    def setU1coord(self,v):
        """setU1coord method"""
        self.__u1=v
    def setV1coord(self,v):
        """setV1coord method"""
        self.__v1=v
    def setU2coord(self,v):
        """setU2coord method"""
        self.__u2=v
    def setV2coord(self,v):
        """setV2coord method"""
        self.__v2=v
    def setStaindex(self,v):
        """setStaindex method"""
        self.__staindex=v
    def setFlagTriplet(self,iTriplet):
        self.__flag[iTriplet,:]=True
        
    def setFlagWavelength(self,iWave):
        self.__flag[:,iWave]=True
        
    def getMjd(self):
        """getMjd method"""
        return self.__mjd
    def getIntTime(self):
        """getIntTime method"""
        return self.__dit
    def getT3amp(self):
        """getT3amp method"""
        return self.__t3amp
    def getT3amperr(self):
        """getT3amperr method"""
        return self.__t3amperr
    def getT3phi(self):
        """getT3phi method"""
        return self.__t3phi
    def getT3phierr(self):
        """getT3phierr method"""
        return self.__t3phierr
    def getU1coord(self):
        """getU1coord method"""
        return self.__u1
    def getV1coord(self):
        """getV1coord method"""
        return self.__v1
    def getU2coord(self):
        """getU2coord method"""
        return self.__u2
    def getV2coord(self):
        """getV2coord method"""
        return self.__v2
    def getStaindex(self):
        """getStaindex method"""
        return self.__staindex
    def getFlag(self):
        """getFlag method"""
        return self.__flag

    def createTable(self):
        """createTable method"""
        nTriplet, nWave = np.shape(self.__t3amp)
        col1 = fits.Column(name='TARGET_ID', format='I', array=np.ones(nTriplet))
        col2 = fits.Column(name='TIME', format='D', unit='s', array=np.zeros(nTriplet))
        col3 = fits.Column(name='MJD', format='D', unit='d', array=self.__mjd)
        col4 = fits.Column(name='INT_TIME', format='D', unit='s', array=self.__dit)
        col5 = fits.Column(name='T3AMP', format=str(nWave)+'D', array=self.__t3amp)
        col6 = fits.Column(name='T3AMPERR', format=str(nWave)+'D', array=self.__t3amperr)
        col7 = fits.Column(name='T3PHI', format=str(nWave)+'D', unit='deg', array=self.__t3phi)
        col8 = fits.Column(
            name='T3PHIERR',
            format=str(nWave)+'D',
            unit='deg',
            array=self.__t3phierr
            )
        col9 = fits.Column(name='U1COORD', format='D', unit='m', array=self.__u1)
        col10 = fits.Column(name='V1COORD', format='D', unit='m', array=self.__v1)
        col11 = fits.Column(name='U2COORD', format='D', unit='m', array=self.__u2)
        col12 = fits.Column(name='V2COORD', format='D', unit='m', array=self.__v2)
        col13 = fits.Column(name='STA_INDEX', format='3I', array=self.__staindex)
        col14 = fits.Column(name='FLAG', format=str(nWave)+'L', array=self.__flag)
        coldefs = fits.ColDefs([col1, col2, col3, col4, col5, col6 , col7, \
                                col8, col9, col10, col11, col12, col13, col14])
        binary_hdu = fits.BinTableHDU.from_columns(coldefs)
        binary_hdu.header.set('OI_REVN',2, 'Revision number')
        binary_hdu.header.set('DATE-OBS',self.__dateobs, 'UTC start date of observations')
        binary_hdu.header.set('ARRNAME',self.__arrname, 'Array name')
        binary_hdu.header.set('INSNAME',self.__insname, 'Name of detector')
        binary_hdu.header.set('EXTNAME','OI_T3')
        return binary_hdu

    def load (self,filename):
        """load method"""
        hdul=fits.open(filename)
        instrume = hdul[0].header['INSTRUME']
        if 'GRAVITY' in instrume:
            tbl = utils.getHdu(hdul, 'OI_T3', 'GRAVITY_SC')
        else:
            tbl = hdul['OI_T3']
        self.__arrname = tbl.header['ARRNAME']
        self.__insname = tbl.header['INSNAME']
        self.__mjd = tbl.data['MJD']
        self.__dit = tbl.data['INT_TIME']
        self.__t3amp = tbl.data['T3AMP']
        self.__t3amperr = tbl.data['T3AMPERR']
        self.__t3phi = tbl.data['T3PHI']
        self.__t3phierr = tbl.data['T3PHIERR']
        self.__u1 = tbl.data['U1COORD']
        self.__v1 = tbl.data['V1COORD']
        self.__u2 = tbl.data['U2COORD']
        self.__v2 = tbl.data['V2COORD']
        self.__staindex = tbl.data['STA_INDEX']
        self.__flag = tbl.data['FLAG']
        self.__dateobs = tbl.header['DATE-OBS']
        
        idx=np.where(self.__mjd != 0)
        mjdmean=np.mean(self.__mjd[idx[0]])
        nb,nw=np.shape(self.__t3amp)
        for i in range(nb):
            if self.__mjd[i] == 0 :
                self.__mjd[i]=mjdmean
                self.__u1[i]=1.
                self.__v1[i]=1.
                self.__u2[i]=1.
                self.__v2[i]=1.
                for j in range(nw):
                    self.__t3amp[i,j]=1.
                    self.__t3amperr[i,j]=1.E10
                    self.__t3phi[i,j]=0.
                    self.__t3phierr[i,j]=1.E10
        hdul.close()

class Oiflux:
    """Oiflux class"""
    def __init__(self):
        self.__mjd = []
        self.__dit = []
        self.__fluxdata = []
        self.__fluxerr = []
        self.__staindex = []
        self.__flag = []
        self.__dateobs = ''
        self.__arrname = ''
        self.__insname = ''

    def setDateObsfromHeader(self, hdr):
        """setDateObsfromHeader method"""
        if 'DATE-OBS' in hdr:
            self.__dateobs=hdr['DATE-OBS']
        else:
            print('OI_FLUX: No DATE-OBS keyword in Input Header')

    def setMjd(self,v):
        """setMjd method"""
        self.__mjd=v
    def setIntTime(self,v):
        """setIntTime method"""
        self.__dit=v
    def setFluxdata(self,v):
        """setFluxdata method"""
        self.__fluxdata=v
    def setFluxerr(self,v):
        """setFluxerr method"""
        self.__fluxerr=v
    def setStaindex(self,v):
        """setStaindex method"""
        self.__staindex=v
    def getTime(self):
        """getTime method"""
        return self.__time
    def getMjd(self):
        """getMjd method"""
        return self.__mjd
    def getIntTime(self):
        """getIntTime method"""
        return self.__dit
    def getFluxdata(self):
        """getFluxdata method"""
        return self.__fluxdata
    def getFluxerr(self):
        """getFluxerr method"""
        return self.__fluxerr
    def getStaindex(self):
        """getStaindex method"""
        return self.__staindex
    def getFlag(self):
        """getFlag method"""
        return self.__flag

    def createTable(self):
        """createTable method"""
        nTel, nWave = np.shape(self.__fluxdata)
        col1 = fits.Column(name='TARGET_ID', format='I', array=np.ones(nTel))
        col2 = fits.Column(name='MJD', format='D', unit='d', array=self.__mjd)
        col3 = fits.Column(name='INT_TIME', format='D', unit='s', array=self.__dit)
        col4 = fits.Column(name='FLUXDATA',format=str(nWave)+'D',unit='ADU',array=self.__fluxdata)
        col5 = fits.Column(name='FLUXERR', format=str(nWave)+'D', unit='ADU', array=self.__fluxerr)
        col6 = fits.Column(name='STA_INDEX', format='I', array=self.__staindex)
        col7 = fits.Column(name='FLAG', format=str(nWave)+'L', array=self.__flag)
        coldefs = fits.ColDefs([col1, col2, col3, col4, col5, col6 , col7])
        binary_hdu = fits.BinTableHDU.from_columns(coldefs)
        binary_hdu.header.set('OI_REVN',1, 'Revision number')
        binary_hdu.header.set('DATE-OBS',self.__dateobs, 'UTC start date of observations')
        binary_hdu.header.set('ARRNAME',self.__arrname, 'Array name')
        binary_hdu.header.set('INSNAME',self.__insname, 'Name of detector')
        binary_hdu.header.set('EXTNAME','OI_FLUX')
        binary_hdu.header.set('CALSTAT','U','C: Spectrum is calibrated, U: uncalibrated')
        return binary_hdu

    def load (self,filename):
        """load method"""
        hdul=fits.open(filename)
        instrume = hdul[0].header['INSTRUME']
        if 'GRAVITY' in instrume:
            tbl = utils.getHdu(hdul, 'OI_FLUX', 'GRAVITY_SC')
        else:
            tbl = hdul['OI_FLUX']
        self.__arrname = tbl.header['ARRNAME']
        self.__insname = tbl.header['INSNAME']
        self.__mjd = tbl.data['MJD']
        self.__dit = tbl.data['INT_TIME']
        if "FLUXDATA" in tbl.columns.names:
            self.__fluxdata = tbl.data['FLUXDATA']
        else:
            self.__fluxdata = tbl.data['FLUX']
        self.__fluxerr = tbl.data['FLUXERR']
        self.__staindex = tbl.data['STA_INDEX']
        self.__flag = tbl.data['FLAG']
        self.__dateobs = tbl.header['DATE-OBS']
        
        idx=np.where(self.__mjd != 0)
        mjdmean=np.mean(self.__mjd[idx[0]])
        nb,nw=np.shape(self.__fluxdata)
        for i in range(nb):
            if self.__mjd[i] == 0 :
                self.__mjd[i]=mjdmean
                for j in range(nw):
                    self.__fluxdata[i,j]=1.
                    self.__fluxdataerr[i,j]=1.E10
        hdul.close()

class OifitsTransfunc(Oifits):
    """OifitsTransfunc class"""
    def __init__(self,filename):
        Oifits.__init__(self)
        self.load(filename)
        self.nBase,self.nWave=np.shape(self.oivis2.getVis2())
        self.nTriplet,self.nWave=np.shape(self.oit3.getT3phi())
        self.tf2=np.zeros((self.nBase,self.nWave),dtype=float)
        self.tf2err=np.zeros((self.nBase,self.nWave),dtype=float)
        self.tfamp=np.zeros((self.nTriplet,self.nWave),dtype=float)
        self.tfamperr=np.zeros((self.nTriplet,self.nWave),dtype=float)
        instrume = self.hdu.header['INSTRUME']
        if 'MATISSE' in instrume:
            instrume = self.hdu.header['ESO DET NAME']
        kjsdc, kgcal = dic_catalog[instrume]
        
        if 'JSDC DIAMETER' in self.hdu.header:
            self.diam=self.hdu.header['JSDC DIAMETER']
            self.diamerr=self.hdu.header['JSDC DIAMETER ERROR']
            self.diamtype="JSDC"
        else:
            instrume = self.hdu.header['INSTRUME']
            if 'MATISSE' in instrume:
                instrume = self.hdu.header['ESO DET NAME']
            knam = dic_objname[instrume]
            name = utils.replaceByHD(self.hdu.header[knam])
            try:
                v = Vizier(columns=[kjsdc,'e_LDD'])
                result = v.query_object(name, catalog=["jsdc"])
                if result == []:
                    result = v.query_object(name.replace("_"," "), catalog=["jsdc"])
                # Query getsart
                if result == []:
                    result=utils.getstar(name)
                    self.diam=result.loc[0,kgcal]
                    self.diamerr= result.loc[0,'e_LDD']
                    self.diamtype="GETSTAR"
                else:
                    self.diam=result['II/346/jsdc_v2'][0][0]
                    self.diamerr=result['II/346/jsdc_v2'][0][1]
                    self.diamtype="JSDC"
            except:
                self.diam=1.E-5
                self.diamerr=1.E5
                self.diamtype="NOT FOUND"
        #print(self.hdu.header['OBJECT'],self.diam,self.diamerr)
        self.__computeTF2()
        self.__computeTFamp()


    # --------------------------------------------------------------
    # Private Methods
    # --------------------------------------------------------------
    def __computeTFamp(self):
        """__computeTFamp method"""
        wave=self.oiwavelength.getWavelength()
        for iTriplet in range(self.nTriplet):
            for iWave in range(self.nWave):
                self.tfamp[iTriplet,iWave]=(
                    self.oit3.getT3amp()[iTriplet,iWave]/
                    abs(utils.disk(self.oit3.getU1coord()[iTriplet],
                                    self.oit3.getU2coord()[iTriplet],
                                    wave[iWave]*1.E9,self.diam))
                    )
                self.tfamp[iTriplet,iWave]/=abs(utils.disk(self.oit3.getU2coord()[iTriplet],
                                                           self.oit3.getV2coord()[iTriplet],
                                                           wave[iWave]*1.E9,self.diam))
                self.tfamp[iTriplet,iWave]/=abs(utils.disk(self.oit3.getU1coord()[iTriplet]+
                                                           self.oit3.getU2coord()[iTriplet],
                                                           self.oit3.getV1coord()[iTriplet]+
                                                           self.oit3.getV2coord()[iTriplet],
                                                           wave[iWave]*1.E9,self.diam))
                self.tfamperr[iTriplet,iWave]=(
                    self.oit3.getT3amperr()[iTriplet,iWave]/
                    abs(utils.disk(self.oit3.getU1coord()[iTriplet],
                                   self.oit3.getV1coord()[iTriplet],
                                   wave[iWave]*1.E9,self.diam))
                    )
                self.tfamperr[iTriplet,iWave]/=abs(utils.disk(self.oit3.getU2coord()[iTriplet],
                                                              self.oit3.getV2coord()[iTriplet],
                                                              wave[iWave]*1.E9,self.diam))
                self.tfamperr[iTriplet,iWave]/=abs(utils.disk(self.oit3.getU1coord()[iTriplet]+
                                                              self.oit3.getU2coord()[iTriplet],
                                                              self.oit3.getV1coord()[iTriplet]+
                                                              self.oit3.getV2coord()[iTriplet],
                                                              wave[iWave]*1.E9,self.diam))

    def __computeTF2(self):
        """__computeTF2 method"""
        wave=self.oiwavelength.getWavelength()
        for iBase in range(self.nBase):
            for iWave in range(self.nWave):
                dis=utils.disk(self.oivis2.getUcoord()[iBase],
                               self.oivis2.getVcoord()[iBase],
                               wave[iWave]*1.E9,self.diam)
                diserr=utils.diskerr(self.oivis2.getUcoord()[iBase],
                                     self.oivis2.getVcoord()[iBase],
                                     wave[iWave]*1.E9,self.diam,self.diamerr)
                alpha=self.oivis2.getVis2()[iBase,iWave]/self.oivis2.getVis2err()[iBase,iWave]
                beta=dis**2/diserr
                ratio=self.oivis2.getVis2()[iBase,iWave]/dis**2
                self.tf2[iBase,iWave]=ratio*(1+beta**(-2))
                self.tf2err[iBase,iWave]=np.sqrt(np.abs(ratio**2*(alpha**(-2)+beta**(-2)-beta**(-4)+ \
                                                        3*alpha**(-2)*beta**(-2))))
                if math.isnan(self.tf2err[iBase,iWave]) or math.isnan(self.tf2[iBase,iWave]) or \
                   self.diamerr >= 2 :
                    self.tf2[iBase,iWave]=1.
                    self.tf2err[iBase,iWave]=1.E10
                
                
                
    # --------------------------------------------------------------
    #   Public Methods
    # --------------------------------------------------------------
    def filterV2(self):
        sk=9
        for iBase in range(self.nBase):
            self.tf2[iBase,:]=signal.medfilt(self.tf2[iBase,:],kernel_size=sk)
            self.tf2err[iBase,:]/=np.sqrt(sk)
           
