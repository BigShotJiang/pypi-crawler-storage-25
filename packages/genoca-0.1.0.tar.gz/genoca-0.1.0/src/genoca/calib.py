from __future__ import annotations
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[2]))
sys.path.append(str(Path(__file__).resolve().parents[1]))

import datetime
import glob
import logging
import os
import tempfile
import matplotlib.pyplot as plt
import numpy as np
from astropy.io import fits
from fpdf import FPDF
import importlib.resources as res
import math

from genoca import utils, oifits
from genoca.cli.cli import parse_cli
from genoca import dic_logo, dic_ob, dic_type, dic_obj_type, dic_objname

# Silence irrelevant warnings from upstream libs
import warnings
warnings.simplefilter("ignore")
# Configure basic logging
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger("genoca")

import matplotlib
matplotlib.use("QtAgg")

# ----------------------------- PDF class ----------------------------------

class GENOCAPDF(FPDF):
    def __init__(self, instrument="None", *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.instrume = instrument
        
    def header(self):
        STANDARD_WIDTH = 40        
        # Use images only if available; ignore missing images
        try:
            file = dic_logo[self.instrume][1]
            logo = str(res.files("genoca.assets") / file)
            self.image(logo, 10, 8, 15)
        except Exception:
            pass
        self.set_font('Helvetica', 'B', 15)
        self.cell(40)
        self.cell(100, 10, 'GenOCA Report', border=1, align="C")
        try:
            file = dic_logo[self.instrume][0]
            logo = str(res.files("genoca.assets") / file)
            self.image(logo, 180, 8, 15)
        except Exception:
            pass
        self.ln(20)

    def footer(self):
        self.set_y(-15)
        self.set_font('Helvetica', 'I', 8)
        self.cell(0, 10, f'Page {self.page_no()}/{{nb}}', border=0, align="C")


# --------------------------- Core functions -------------------------------


def find_oifits_files(prodir: Path, exclude_patterns: Optional[List[str]] = None) -> List[Path]:
    pattern = str(prodir / "*.fits")
    files = sorted([Path(p) for p in glob.glob(pattern)])
    if exclude_patterns:
        files = [f for f in files if not any(pat in f.name for pat in exclude_patterns)]
    filtered_files = []
    for f in files:
        try:
            with fits.open(f) as hdul:
                header = hdul[0].header
                if header.get("PRO CATG") != "TARGET_CAL_INT":
                    filtered_files.append(f)
        except Exception as e:
            pass
    return filtered_files


def load_inputs(cfg: RunConfig) -> Tuple[List[Path], np.ndarray, np.ndarray, List[str]]:
    """Load OIFITS files from product directory and return filtered file list,
    mjdAll, and list of science target names."""
    files = find_oifits_files(cfg.prodir)
    files_oifits: List[Path] = []
    mjd_all: List[float] = []
    science_names: List[str] = []

    for f in files:
        try:
            with fits.open(f) as hdu:
                hdr = hdu[0].header
                instrume = hdr.get('INSTRUME', '')
                if 'MATISSE' in instrume:
                    instrume = hdr.get('ESO DET NAME', '')
                if 'CONTENT' in hdr:
                    typ, ltyp = dic_type[instrume]
                    sci, vsci = dic_obj_type[instrume]
                    nam = dic_objname[instrume]
                    if (hdr.get('CONTENT') == 'OIFITS2' and hdr.get(typ) in ltyp ) and \
                       ( "SPICA" not in instrume or ("SPICA" in instrume and hdr.get('INS STS ST') is False)):
                        name = utils.replaceByHD(hdr.get(nam))
                        tplStart = hdr.get(dic_ob[instrume], "").split('.')[0]
                        if name not in cfg.discarded_star and tplStart not in cfg.discarded_tplstart:
                            mjd_all.append(utils.getKeyword(str(f), "MJD-OBS"))
                            files_oifits.append(f)
                            if hdr.get(sci) == vsci:
                                science_names.append(name)
        except Exception as exc:
            logger.warning("Failed to open %s: %s", f, exc)

    if not science_names:
        logger.error("No science targets found in directory %s", cfg.prodir)
        sys.exit(1)

    science_names = list(np.unique(np.array(science_names)))

    logger.info("Found %d oifits files and %d science targets", len(files_oifits), len(science_names))
    return files_oifits, np.array(mjd_all), science_names


def list_instrumental_configurations(files_oifits: List[Path]) -> List[str]:
    ins_conf: List[str] = []
    for f in files_oifits:
        conf = utils.getInsConf(str(f))
        if conf not in ins_conf:
            ins_conf.append(conf)
    logger.info("Number of Instrumental Configurations: %d", len(ins_conf))
    return ins_conf


# Helper to set user-provided diameters on an OifitsTransfunc object
def apply_user_diameters(transfunc: oifits.OifitsTransfunc, diameter_list: List[Tuple[str, float, float]]):
    if not diameter_list:
        return
    name = transfunc.oitarget.getTargetName()
    for (nm, diam, err) in diameter_list:
        if nm == name:
            transfunc.diam = diam
            transfunc.diamerr = err
            transfunc.diamtype = "USER"
            logger.debug("Applied user diameter for %s: %s +- %s", name, diam, err)


def load_calibrators(files_cal: List[Path], cfg: RunConfig) -> Tuple[List[oifits.OifitsTransfunc], List[str], \
                                                                     List[str], List[float], List[float]]:
    """Load calibrator OIFITS into OifitsTransfunc objects and collect diameter info."""
    oifits_cal_all: List[oifits.OifitsTransfunc] = []
    cal_names: List[str] = []
    cal_diameters: List[float] = []
    cal_diam_err: List[float] = []
    cal_diam_type: List[str] = []

    for filename in files_cal:
        try:
            # create transfunc (this will compute TF internally as in original script)
            tmp = oifits.OifitsTransfunc(str(filename))
            apply_user_diameters(tmp, cfg.diameter_cal_list)
            if cfg.filter_calib:
                tmp.filterV2()
            oifits_cal_all.append(tmp)
            name = tmp.oitarget.getTargetName()
            if name not in cal_names:
                cal_names.append(name)
                cal_diameters.append(tmp.diam)
                cal_diam_err.append(tmp.diamerr)
                cal_diam_type.append(tmp.diamtype)
                logger.info("Calibrator: %s diam= %s err=%s type=%s", name, tmp.diam, tmp.diamerr, tmp.diamtype)
        except Exception as exc:
            logger.warning("Failed to load calibrator %s: %s", filename, exc)

    return oifits_cal_all, cal_names, cal_diam_type, cal_diameters, cal_diam_err


def compute_tf_interpolation_grid(mjd_all: np.ndarray, oifits_cal_all, nbpt: int = 100):

    if mjd_all.size == 0:
        raise ValueError("mjd_all is empty")

    mjd_min = np.min(mjd_all) - 1/24
    mjd_max = np.max(mjd_all) + 1/24

    mjdvec = np.linspace(mjd_min, mjd_max, nbpt, endpoint=False)

    # Get dimensions from first calibrator
    nBase, nWave = oifits_cal_all[0].oivis2.getVis2().shape
    nTriplet, nWave = oifits_cal_all[0].oit3.getT3amp().shape

    # Allocate output arrays
    tf2vec = np.zeros((nbpt, nBase, nWave))
    tf2errvec = np.zeros((nbpt, nBase, nWave))

    mjdV = np.empty(nBase)
    mjdP = np.empty(nTriplet)

    for i, mjd in enumerate(mjdvec):
        mjdV[:] = mjd
        mjdP[:] = mjd

        tf2Interp, tf2InterpErr, *_ = utils.interpolateTf(
            mjdV, mjdP, mjdV, oifits_cal_all, "Full"
        )

        tf2vec[i] = tf2Interp            # (nBase, nWave)
        tf2errvec[i] = tf2InterpErr      # (nBase, nWave)

    return mjdvec, tf2vec, tf2errvec
'''def compute_tf_interpolation_grid(mjd_all: np.ndarray, oifits_cal_all: List[oifits.OifitsTransfunc], nbpt: int = 100):
    """Interpolate TF on a regular mjd grid and return mjdvec, tf2vec, tf2errvec"""
    if mjd_all.size == 0:
        raise ValueError("mjd_all is empty")
    mjd_min = np.min(mjd_all) - 1. / 24.
    mjd_max = np.max(mjd_all) + 1. / 24.

    mjdvec = []
    tf2vec = []
    tf2errvec = []

    for i in range(nbpt):
        mjd = mjd_min + i * (mjd_max - mjd_min) / nbpt
        mjdvec.append(mjd)
        # utils.interpolateTf accepts arrays for mjd times; create small arrays
        mjdV = np.full(15, mjd)
        mjdP = np.full(20, mjd)
        tf2Interp, tf2InterpErr, *_ = utils.interpolateTf(mjdV, mjdP, mjdV, oifits_cal_all, "Full")
        tf2vec.append(tf2Interp)
        tf2errvec.append(tf2InterpErr)

    return np.array(mjdvec), np.array(tf2vec), np.array(tf2errvec)'''


def find_mjd0(oifits_cal_all: List[oifits.OifitsTransfunc], mjd_target: List[float]) -> float:
    mjd0 = 1e10
    for idx in range(len(oifits_cal_all)):
        try:
            mjd_val = oifits_cal_all[idx].oivis2.getMjd()[0]
            if mjd_val != 0 and mjd_val < mjd0:
                mjd0 = mjd_val
        except Exception:
            continue
    if mjd_target:
        mjd0 = min(mjd0, min([m for m in mjd_target if m != 0.]))
    return mjd0


def build_basename_from_hdu(hdu: fits.HDUList) -> List[str]:
    staindex = hdu['OI_VIS2'].data['STA_INDEX']
    telname = hdu['OI_ARRAY'].data['TEL_NAME']
    idxname = hdu['OI_ARRAY'].data['STA_INDEX']
    base_names = []
    for p in staindex:
        base_names.append([telname[np.where(idxname == p[0])[0][0]],telname[np.where(idxname == p[1])[0][0]]])
    #base_names = [telname[p[0] - 1] + telname[p[1] - 1] for p in staindex]
    return base_names


# --------------------------- Main processing ------------------------------

def process_configuration(conf: str, files_oifits: List[Path], cfg: RunConfig, mjd_all: np.ndarray, science_names: List[str]):
    logger.info("Processing configuration: %s", conf)

    # select calibrator files for this configuration
    files_calib = []
    tpl_calib = []
    for f in files_oifits:
        instrume = utils.getKeyword(str(f), "INSTRUME")
        if 'MATISSE' in instrume:
            instrume = utils.getKeyword(str(f), "ESO DET NAME")
        if not utils.isScience(str(f)) and utils.getInsConf(str(f)) == conf:
            files_calib.append(f)
            tpl_calib.append(utils.getKeyword(str(f), dic_ob[instrume]))

    if not files_calib:
        logger.info("No calibrators for configuration %s", conf)
        return
    logger.info("%d calibrators found for %s", len(files_calib), conf)

    # determine baselines from first calibrator
    try:
        with fits.open(files_calib[0]) as hdu0:
            base_names = build_basename_from_hdu(hdu0)
    except Exception as exc:
        logger.error("Failed to determine baselines: %s", exc)
        return

    # load calibrator transfunc objects
    oifits_cal_all, cal_names, cal_types, cal_diams, cal_diam_err = load_calibrators(files_calib, cfg)

    # compute interpolation grid
    mjdvec, tf2vec, tf2errvec = compute_tf_interpolation_grid(mjd_all, oifits_cal_all, nbpt=100)

    # For storing plot values across targets
    mjd_target_list: List[float] = []
    v_target_list: List[float] = []
    verr_target_list: List[float] = []
    vraw_target_list: List[float] = []
    verrraw_target_list: List[float] = []
    tfinterp_list: List[float] = []
    tferrinterp_list: List[float] = []
    list_target_names: List[str] = []

    out_figs: List[Path] = []

    # Loop over science targets
    for target in science_names:
        logger.info("TARGET: %s", target)

        # gather science files for this target and configuration
        files_science = []
        tpl_science = []
        for f in files_oifits:
            instrume = utils.getKeyword(str(f), "INSTRUME")
            if 'MATISSE' in instrume:
                instrume = utils.getKeyword(str(f), "ESO DET NAME")
            nam = dic_objname[instrume]
            ob = dic_ob[instrume]
            if utils.isKeywordEqualValue(str(f), nam, target) and utils.getInsConf(str(f)) == conf:
                tpl_science.append(utils.getKeyword(str(f), ob))
                files_science.append(f)

        # process each science OB for this target
        for sciob, scitime in zip(files_science, tpl_science):
            logger.info("Processing science OB %s (%s)", sciob.name, scitime)

            # select calibrators within timespan
            idx_selected = []
            selected_names = []
            for i, (calfile, caltime) in enumerate(zip(files_calib, tpl_calib)):
                datetimeFormat = '%Y-%m-%dT%H:%M:%S'
                diff = datetime.datetime.strptime(scitime.split('.')[0], datetimeFormat) - \
                    datetime.datetime.strptime(caltime.split('.')[0], datetimeFormat)
                diffhour = abs(diff.days * 24.0 + (diff.seconds + diff.microseconds * 1.0e-6) / 3600.)
                if diffhour < cfg.timespan:
                    idx_selected.append(i)
                    tmp = oifits.OifitsTransfunc(str(calfile))
                    selected_names.append(tmp.oitarget.getTargetName())

            logger.info("Selected %d calibrators for this OB", len(idx_selected))

            # create list of selected calibrator transfuncs (pointer into oifits_cal_all)
            selected_oifits_cal = [oifits_cal_all[i] for i in idx_selected]

            # load target
            oif_target = oifits.Oifits()
            oif_target.load(str(sciob))

            # interpolate TF for target times
            tf2Interp, tf2InterpErr, tfampInterp, tfampInterpErr, tfphiInterp, tfphiInterpErr, tfdphiInterp, \
                tfdphiInterpErr = utils.interpolateTf(oif_target.oivis2.getMjd(), oif_target.oit3.getMjd(), \
                                                      oif_target.oivis.getMjd(), selected_oifits_cal, "Full")

            # keep raw visibility for plotting
            nBase = len(oif_target.oivis2.getVis2()[:, 0])
            nWave = len(oif_target.oivis2.getVis2()[0, :])
            for iBase in range(nBase):
                v2 = oif_target.oivis2.getVis2()[iBase, :]
                v2err = oif_target.oivis2.getVis2err()[iBase, :]
                valmed = np.sign(np.median(v2)) * np.sqrt(np.abs(np.median(v2)))
                vraw_target_list.append(valmed)
                verrraw_target_list.append((np.median(v2err)) / (2 * np.abs(valmed)) / np.sqrt(nWave))

            # Calibrate science
            oif_target.calibrate(tf2Interp, tf2InterpErr, tfampInterp, tfampInterpErr, tfphiInterp, tfphiInterpErr, \
                                 tfdphiInterp, tfdphiInterpErr)
            oif_target.hdu.header['PRO CATG'] = "TARGET_CAL_INT"

            # Flags and param injections
            oif_target.flagBaseline(cfg.discarded_baselines)
            oif_target.flagWavelength(cfg.discarded_wavelength_min, cfg.discarded_wavelength_max)

            # Add processing metadata
            add_processing_metadata(oif_target, cfg)

            # Add calibrator diameter info
            for i, name in enumerate(cal_names):
                if name in selected_names:
                    oif_target.hdu.header[f'HIERARCH PRO CAL{i+1} NAME'] = name
                    oif_target.hdu.header[f'HIERARCH PRO CAL{i+1} DIAMETER'] = cal_diams[i]
                    oif_target.hdu.header[f'HIERARCH PRO CAL{i+1} DIAM ERR'] = cal_diam_err[i]
                    oif_target.hdu.header[f'HIERARCH PRO CAL{i+1} TYPE'] = cal_types[i]

            # Build output filename
            out_fname = build_output_filename(oif_target)
            oif_target.save(str(cfg.wdir / out_fname))

            # store calibrated vals for plotting
            instrume = oif_target.hdu.header['INSTRUME']
            if 'MATISSE' in instrume:
                instrume = oif_target.hdu.header['ESO DET NAME']
            knam = dic_objname[instrume]
            name = oif_target.hdu.header[knam]
            list_target_names.append(utils.replaceByHD(name))
            for iBase in range(nBase):
                v2 = oif_target.oivis2.getVis2()[iBase, :]
                v2err = oif_target.oivis2.getVis2err()[iBase, :]
                valmed = np.sign(np.median(v2)) * np.sqrt(np.abs(np.median(v2)))
                v_target_list.append(valmed)
                verr_target_list.append((np.median(v2err)) / (2 * np.abs(valmed)) / np.sqrt(nWave))
                mjd_target_list.append(oif_target.oivis2.getMjd()[iBase])
                valmed_tf = np.sign(np.median(tf2Interp[iBase])) * np.sqrt(np.abs(np.median(tf2Interp[iBase])))
                tfinterp_list.append(valmed_tf)
                valmed_tf_err = np.sign(np.median(tf2InterpErr[iBase])) * np.sqrt(np.abs(np.median(tf2InterpErr[iBase])))
                tferrinterp_list.append(valmed_tf_err)




    BASES_PER_FIG = 4
    nBase = len(base_names)
    nFig = math.ceil(nBase / BASES_PER_FIG)

    if cfg.save_pdf:
        tmpdir = Path(tempfile.mkdtemp(prefix="spica_plots_", dir=str(cfg.wdir)))
    out_figs = []
    
    mjd0 = find_mjd0(oifits_cal_all, mjd_target_list)

    figures = []  

    for fig_index in range(nFig):
             
        fig, axes = plt.subplots(
            BASES_PER_FIG, 1, 
            figsize=(15, 10), 
            sharex=True
        )

        # si moins de 5 baselines restent → axes sera un seul objet
        if BASES_PER_FIG == 1:
            axes = [axes]

        figures.append(fig)

        # baselines de cette figure
        for k in range(BASES_PER_FIG):
            iBase = fig_index * BASES_PER_FIG + k
            if iBase >= nBase:
                break
            if iBase in cfg.discarded_baselines:
                continue

            ax = axes[k]
            xplot = []

            # --- calibrators TF ---
            for idx, fname in enumerate(files_calib):
                try:
                    v2_tf = oifits_cal_all[idx].tf2[iBase, :]
                    v2_tf_err = oifits_cal_all[idx].tf2err[iBase, :]
                    valmed = np.sign(np.median(v2_tf)) * np.sqrt(np.abs(np.median(v2_tf)))
                    sigmed = np.abs((np.median(v2_tf_err))/(2*valmed)/np.sqrt(nWave))
                    t = (oifits_cal_all[idx].oivis2.getMjd()[iBase] - mjd0) * 24.
                    ax.errorbar([t], [valmed], yerr=[sigmed], fmt='.', color='red')
                    xplot.append(t)
                    
                    # raw vis²
                    v2 = oifits_cal_all[idx].oivis2.getVis2()[iBase, :]
                    v2err = oifits_cal_all[idx].oivis2.getVis2err()[iBase, :]
                    valmed_raw = np.sign(np.median(v2)) * np.sqrt(np.abs(np.median(v2)))
                    sigmed_raw = np.abs((np.median(v2err))/(2*valmed_raw)/np.sqrt(nWave))
                    ax.errorbar([t], [valmed_raw], yerr=[sigmed_raw], fmt='.', color='blue')
                    
                    name = getattr(oifits_cal_all[idx].oitarget, 'getTargetName', lambda: 'Unknown')()
                    if name != 'None':
                        if k == 0:
                            ax.text(t, 1.2, name, rotation='vertical', fontsize='small')
                except Exception:
                    continue

            # --- interpolated TF grid ---
            for i_pt in range(len(mjdvec)):
                try:
                    valmed = np.sign(np.median(tf2vec[i_pt][iBase,:])) * np.sqrt(np.abs(np.median(tf2vec[i_pt][iBase,:])))
                    sigmed = np.sign(np.median(tf2errvec[i_pt][iBase,:])) * np.sqrt(np.abs(np.median(tf2errvec[i_pt][iBase,:]) / nWave))
                    ax.errorbar([(mjdvec[i_pt] - mjd0)*24.], [valmed], yerr=[sigmed], fmt='.', color='orange')
                except Exception:
                    continue

            # --- science points ---
            nbTarget = int(len(v_target_list) / nBase)
            for iTarget in range(nbTarget):
                try:
                    t = (mjd_target_list[iTarget*nBase + iBase] - mjd0) * 24.
                    ax.errorbar([t], [v_target_list[iTarget*nBase + iBase]],
                                yerr=[verr_target_list[iTarget*nBase + iBase]], fmt='.', color='green')
                    ax.errorbar([t], [vraw_target_list[iTarget*nBase + iBase]],
                                yerr=[verrraw_target_list[iTarget*nBase + iBase]], fmt='.', color='cyan')
                    xplot.append(t)

                    if list_target_names[iTarget] != 'None':
                        if k == 0:
                            ax.text(t, 1.2, list_target_names[iTarget], rotation='vertical', fontsize='small')
                except Exception:
                    continue

            # --- cosmetics ---
            if xplot:
                ax.set_xlim(min(xplot)-0.5, max(xplot)+0.5)

            ax.set_ylim(-0.2, 1.3)
            ax.set_ylabel("Vis")
            ax.set_title(f"Baseline {base_names[iBase]} (#{iBase})")
            ax.grid()

        # xlabel uniquement sur le dernier subplot
        axes[-1].set_xlabel("Time (hours)")

        if cfg.save_pdf:
            figfile = tmpdir / f"VIS_BASE_{iBase + 1}.png"
            plt.savefig(str(figfile), format="png")
            out_figs.append(figfile)

        if not cfg.show_plot:
            plt.close(fig)

    # affichage final si demandé
    if cfg.show_plot:
        plt.show()

    if cfg.save_pdf:
        write_pdf_report(cfg, conf, out_figs, list(science_names), tpl_calib, files_calib)



    # cleanup generated images
    for f in out_figs:
        try:
            os.remove(f)
        except Exception:
            pass


def add_processing_metadata(oif_target: oifits.Oifits, cfg: RunConfig):
    h = oif_target.hdu.header
    h['PRO PARAM1 NAME'] = "Products Directory"
    h['PRO PARAM1 VAL'] = str(cfg.prodir)
    h['PRO PARAM2 NAME'] = "Working Directory"
    h['PRO PARAM2 VAL'] = str(cfg.wdir)
    h['PRO PARAM3 NAME'] = "Time span"
    h['PRO PARAM3 VAL'] = cfg.timespan
    h['PRO PARAM4 NAME'] = "Discarded Baselines"
    h['PRO PARAM4 VAL'] = str(cfg.discarded_baselines)

    # Discarded Wavelengths
    h['PRO PARAM5 NAME'] = "Discarded Wavelengths"
    fmt = "{:.1f}"
    lmi = cfg.discarded_wavelength_min*1.E9
    lma = cfg.discarded_wavelength_max*1.E9
    discarded_min = lmi.tolist() if hasattr(lmi, 'tolist') else []
    discarded_max = lma.tolist() if hasattr(lma, 'tolist') else []
    formatted_pairs = [
        (fmt.format(a), fmt.format(b)) for a, b in zip(discarded_min, discarded_max)
    ]
    formatted_pairs = [float(x) for pair in formatted_pairs for x in pair]
    h['PRO PARAM5 VAL'] = str(formatted_pairs)

    h['PRO PARAM6 NAME'] = "Calibrator Filtering"
    h['PRO PARAM6 VAL'] = str(cfg.filter_calib)

    # Discarded TPLSTART
    if len(cfg.discarded_tplstart) == 0:
        h['PRO PARAM10 NAME'] = "Discarded TPL START1"
        h['PRO PARAM10 VAL'] = ""
    for i in range(len(cfg.discarded_tplstart)):
        h['PRO PARAM'+str(10+i)+' NAME'] = "Discarded TPL START"+str(i+1)
        h['PRO PARAM'+str(10+i)+' VAL'] = str(cfg.discarded_tplstart[i])
        
    # Discarded Stars
    if len(cfg.discarded_star) == 0:
        h['PRO PARAM20 NAME'] = "Discarded Stars1"
        h['PRO PARAM20 VAL'] = ""
    for i in range(len(cfg.discarded_star)):
        h['PRO PARAM'+str(20+i)+' NAME'] = "Discarded Stars"+str(i+1)
        h['PRO PARAM'+str(20+i)+' VAL'] = str(cfg.discarded_star[i])
    
    # Diameter Calibrator
    if len(cfg.diameter_cal_list) == 0:
        h['PRO PARAM30 NAME'] = "Discarded Calibrator1"
        h['PRO PARAM30 VAL'] = ""
    for i in range(len(cfg.diameter_cal_list)):
        s = str(cfg.diameter_cal_list[i])
        h['PRO PARAM'+str(30+i)+' NAME'] = "Diameter Calibrator"+str(i+1)
        h['PRO PARAM'+str(30+i)+' VAL'] = str(s.translate(str.maketrans("", "", "()")))


def build_output_filename(oif_target: oifits.Oifits) -> str:
    instrume = oif_target.hdu.header["INSTRUME"]
    if 'MATISSE' in instrume:
        instrume = oif_target.hdu.header["ESO DET NAME"]
    knam = dic_objname[instrume]
    name = utils.replaceByHD(oif_target.hdu.header[knam])
    kob = dic_ob[instrume]
    ob = oif_target.hdu.header[kob]
    if '.' in ob:
        ob = ob.split('.')[0]
    ob = ob.replace(":","-")
    if "TPL EXPNO" in oif_target.hdu.header:
        expno = str(oif_target.hdu.header["TPL EXPNO"])
        filename = f"{instrume}_{expno}_{ob}_{name.replace(' ', '')}_L2.fits"
    else:
        filename = f"{instrume}_{ob}_{name.replace(' ', '')}_L2.fits"
    return filename


def write_pdf_report(cfg: RunConfig, conf: str, images: List[Path], science_targets: List[str], tpl_calib: List[str], files_calib: List[Path]):
    # determine night and instrument from first calibrator file if possible
    try:
        night = utils.getKeyword(str(files_calib[0]), "DATE-OBS")
        instrume = utils.getKeyword(str(files_calib[0]), "INSTRUME")
        if 'MATISSE' in instrume:
            instrume = utils.getKeyword(str(files_calib[0]), "ESO DET NAME")
    except Exception:
        night = 'Unknown'
        instrume = 'Unknown'

    # build a PDF similar to original
    pdf = GENOCAPDF(instrume)
    pdf.alias_nb_pages()
    pdf.add_page()

    pdf.set_font('Helvetica', '', 10)
    pdf.cell(0, 10, f"Processing Date : {datetime.date.today()}", 0, ln=1)

    pdf.cell(0, 10, f"Night of Observation : {night}", 0, ln=1)
    pdf.cell(0, 10, f"Instrument : {instrume}", 0, ln=1)
    pdf.cell(0, 10, f"Configuration : {conf}", 0, ln=1)

    pdf.set_font('Helvetica', 'B', 12)
    pdf.cell(0, 10, "Science Targets : ", border=0, ln=1)
    pdf.set_font('Helvetica', '', 8)
    pdf.multi_cell(0, 10, "  ".join(science_targets), border=0)
    pdf.cell(0, 10, "", border=0, ln=1)

    pdf.set_font('Helvetica', 'B', 12)
    pdf.cell(0, 10, "Calibrators : ", border=0, ln=1)
    for elt in np.unique(tpl_calib):
        pdf.set_font('Helvetica', '', 10)
        indexTpl = np.where(np.array(tpl_calib) == elt)
        try:
            if "M" in instrume:
                calName = utils.getKeyword(np.array(files_calib)[indexTpl][0], 'OBJECT')
            else:
                calName = utils.getKeyword(np.array(files_calib)[indexTpl][0], 'OBS TARG NAME')
        except Exception:
            calName = 'Unknown'
        pdf.cell(0, 10, f"     {calName}", border=0, ln=1)
        pdf.set_font('Helvetica', '', 8)
        txt = ""
        for file in np.array(files_calib)[indexTpl]:
            txt += os.path.basename(file) + " --- "
        pdf.multi_cell(0, 10, txt, border=0)
        pdf.cell(0, 10, "", border=0, ln=1)

    pdf.add_page()
    pdf.set_font('Helvetica', 'B', 12)
    pdf.cell(0, 10, "VISIBILITY - TRANSFER FUNCTION ", border=0, ln=1)
    for img in images:
        try:
            pdf.image(str(img), w=200, h=150)
        except Exception:
            logger.warning("Failed to attach image %s to PDF", img)

    out_pdf = cfg.wdir / f"{conf}_{night.replace(':', '-')}.pdf"
    pdf.output(str(out_pdf))
    logger.info("Saved PDF report to %s", out_pdf)


# ------------------------------- Main ------------------------------------

def main(argv: Optional[Sequence[str]] = None):
    cfg = parse_cli(argv)
    if cfg.nverbose:
        logging.disable(logging.CRITICAL)
        
    # ensure working dir exists
    cfg.wdir.mkdir(parents=True, exist_ok=True)
    files_oifits, mjd_all, science_names = load_inputs(cfg)
    ins_confs = list_instrumental_configurations(files_oifits)

    for conf in ins_confs:
        process_configuration(conf, files_oifits, cfg, mjd_all, science_names)


if __name__ == '__main__':
    main()
