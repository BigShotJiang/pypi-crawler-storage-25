#pylint:disable=no-member
# -*- coding: utf-8 -*-
"""
Created on Fri Oct 16 10:57:36 2020
"""
##
# @author pbe
# @brief ...
#
import logging
from astropy.io import fits
from astropy.time import Time
import numpy as np
from scipy.special import jv
import os
from scipy import stats
import matplotlib.pyplot as plt
import math
from astroquery.simbad import Simbad
import pandas
from urllib.parse import quote_plus

from genoca import oifits
from genoca import dic_obj_type, dic_resolution, \
    dic_wavelength, dic_dit, dic_gain



##
# @brief ...
# @param u ...
# @param v ...
# @param wave ...
# @param diameterStar ...
# @return ...
#
def disk(u,v,wave,diameterStar):
    zStar=np.pi*(np.sqrt(u**2+v**2)/wave)*diameterStar* \
        (1.E-3*np.pi/(3600.*180.))*1.E9
    if (np.sqrt(u**2+v**2) == 0.):
        return 1.
    else:
        return 2*jv(1,zStar)/zStar

##
# @brief ...
# @param u ...
# @param v ...
# @param wave ...
# @param diameterStar ...
# @return ...
#
def diskerr(u,v,wave,diameterStar,diameterStarErr):
    zStar=np.pi*(np.sqrt(u**2+v**2)/wave)*diameterStar* \
        (1.E-3*np.pi/(3600.*180.))*1.E9
    if (np.sqrt(u**2+v**2) == 0.):
        return 1.E10
    else:
        return 8*(diameterStarErr/diameterStar)*np.abs(jv(2,zStar)*jv(1,zStar)/zStar)

##
# @brief ...
# @param mjdtf2 ...
# @param mjdtfamp ...
# @param mjdtfdphi ...
# @param oifitsCal ...
# @return ...
#
def interpolateTf(mjdtf2, mjdtfamp, mjdtfdphi, oifitsCal, mode):
    degFit = 0
    # nombre de calibrateurs
    nCal = len(oifitsCal)
    if nCal == 0:
        raise ValueError("oifitsCal is empty")

    # récupérer dimensions depuis le premier fichier
    nBase, nWave = np.shape(oifitsCal[0].oivis2.getVis2())
    nTriplet, nWave2 = np.shape(oifitsCal[0].oit3.getT3amp())
    assert nWave == nWave2, "Mismatch in nWave between oivis2 and oit3"

    # Pré-allocation des tableaux rassemblant les calibrateurs
    # tf2_all: (nCal, nBase, nWave)
    tf2_all = np.empty((nCal, nBase, nWave), dtype=float)
    tf2err_all = np.empty((nCal, nBase, nWave), dtype=float)
    mjd_oivis2 = np.empty((nCal, nBase), dtype=float)

    # Pour OIT3 (tfamp / tfamperr / tfphi / tfphierr)
    tfamp_all = np.empty((nCal, nTriplet, nWave), dtype=float)
    tfamperr_all = np.empty((nCal, nTriplet, nWave), dtype=float)
    tfphi_all = np.empty((nCal, nTriplet, nWave), dtype=float)
    tfphierr_all = np.empty((nCal, nTriplet, nWave), dtype=float)
    mjd_oit3 = np.empty((nCal, nTriplet), dtype=float)

    # For OIVIS (phase)
    tfphi_vis_all = np.empty((nCal, nBase, nWave), dtype=float)
    tfphierr_vis_all = np.empty((nCal, nBase, nWave), dtype=float)
    mjd_oivis = np.empty((nCal, nBase), dtype=float)

    # Fill arrays from calibrator objects in one pass
    for idx, cal in enumerate(oifitsCal):
        # OIVIS2: tf2, tf2err, mjd
        # assume cal.tf2, cal.tf2err arrays shaped (nBase, nWave)
        tf2 = np.array(cal.tf2, dtype=float)
        tf2err = np.array(cal.tf2err, dtype=float)
        # Replace NaNs like in original
        nan_mask = np.isnan(tf2)
        tf2[nan_mask] = 1.0
        # original sets tferr to max(0.02, tf2err) when not NaN, and 1e10 when tf is NaN
        tf2err_fixed = np.where(np.isnan(cal.tf2) , 1e10, np.maximum(0.02, tf2err))
        # store
        tf2_all[idx, :, :] = tf2
        tf2err_all[idx, :, :] = tf2err_fixed
        mjd_oivis2[idx, :] = np.asarray(cal.oivis2.getMjd(), dtype=float)

        # OIT3: tfamp, tfamperr, tfphi, tfphierr
        tfamp = np.array(cal.tfamp, dtype=float)
        tfamperr = np.array(cal.tfamperr, dtype=float)
        # handle NaNs exactly like original
        nan_mask_amp = np.isnan(tfamp)
        tfamp[nan_mask_amp] = 1.0
        tfamperr_fixed = np.where(np.isnan(cal.tfamp), 1e10, np.maximum(0.02, tfamperr))
        tfamp_all[idx, :, :] = tfamp
        tfamperr_all[idx, :, :] = tfamperr_fixed

        # tfphi from oit3
        tfphi = np.array(cal.oit3.getT3phi(), dtype=float)
        tfphierr = np.array(cal.oit3.getT3phierr(), dtype=float)
        nan_mask_phi = np.isnan(tfphi)
        tfphi[nan_mask_phi] = 0.0
        tfphierr_fixed = np.where(np.isnan(tfphierr), 1e10, tfphierr)
        tfphi_all[idx, :, :] = tfphi
        tfphierr_all[idx, :, :] = tfphierr_fixed
        mjd_oit3[idx, :] = np.asarray(cal.oit3.getMjd(), dtype=float)

        # OIVIS phases
        visphi = np.array(cal.oivis.getVisphi(), dtype=float)
        visphierr = np.array(cal.oivis.getVisphierr(), dtype=float)
        nan_mask_visphi = np.isnan(visphi)
        visphi[nan_mask_visphi] = 0.0
        visphierr_fixed = np.where(np.isnan(visphierr), 1e10, visphierr)
        tfphi_vis_all[idx, :, :] = visphi
        tfphierr_vis_all[idx, :, :] = visphierr_fixed
        mjd_oivis[idx, :] = np.asarray(cal.oivis.getMjd(), dtype=float)

    # --- OIVIS2: calcul vectorisé de tf2Interp et tf2InterpErr ---
    # mjdtf2 shape (nBase,)
    # mjd_oivis2 shape (nCal, nBase)
    # poids gaussien basé sur différence de MJD entre mjdtf2 per base et mjd calibrateurs per base
    # forme diff: (nCal, nBase)
    mjd_diff = mjdtf2[None, :] - mjd_oivis2  # (nCal, nBase)
    sigma_days = 2.0 / 24.0  # note: original used (2./24.)**2 in denom inside exp: exp(-diff**2 / sigma^2)
    # compute gaussian term (nCal, nBase)
    if mode == "Full":
        gauss = np.exp(- (mjd_diff ** 2) / (sigma_days ** 2))
    else:
        gauss = np.ones_like(mjd_diff)
    # but tf2err_all varies with wave; we want per (nCal,nBase,nWave)
    # create weight array per wave:
    w_full = (1.0 / (tf2err_all ** 2 + 1e-30)) * gauss[:, :, None]  # (nCal, nBase, nWave)

    # normalize weights along calibrator axis
    wsum = np.sum(w_full, axis=0)  # (nBase, nWave)
    # avoid division by zero
    nz = wsum == 0
    wsum[nz] = 1.0

    a = w_full / wsum[None, :, :]  # normalized weights (nCal, nBase, nWave)

    # weighted mean over calibrators
    tf2Interp = np.sum(a * tf2_all, axis=0)  # (nBase, nWave)

    # compute error:
    # if nCal > 1: tf2InterpErr = sqrt(sum(a**2 * var(tf) ))
    # var(tf) computed across calibrators for each base,wave
    if nCal > 1:
        var_tf = np.var(tf2_all, axis=0)  # (nBase, nWave)
        tf2InterpErr = np.sqrt(np.sum(a**2 * var_tf[None, :, :], axis=0))
    else:
        # single calibrator: use its tf2err
        tf2InterpErr = np.sqrt(np.sum(a**2 * (tf2err_all ** 2), axis=0))

    # for entries where all mjd calibrators were zero (original: set to 1. and 1e10)
    # detect if mjd_oivis2 column is all zeros for a given base
    mjd_all_zero_base = np.all(mjd_oivis2 == 0, axis=0)  # (nBase,)
    if np.any(mjd_all_zero_base):
        # set all waves for those bases to defaults
        tf2Interp[mjd_all_zero_base, :] = 1.0
        tf2InterpErr[mjd_all_zero_base, :] = 1e10

    # --- OIT3: tfampInterp and tfampInterpErr, tfphiInterp and tfphiInterpErr ---
    # For degFit == 0, polynomial fit reduces to weighted mean. We'll compute weighted means.
    # mjd used for tfamp fitting = mjd_oivis2 (nCal, nBase) in original code; but p(mjdtfamp[iTriplet]) uses mjdtfamp
    # per triplet
    tfampInterp = np.zeros((nTriplet, nWave), dtype=float)
    tfampInterpErr = np.zeros((nTriplet, nWave), dtype=float)
    tfphiInterp = np.zeros((nTriplet, nWave), dtype=float)
    tfphiInterpErr = np.zeros((nTriplet, nWave), dtype=float)

    mjd_diff = mjdtfamp[None, :] - mjd_oit3  # (nCal, nTriplet)
    # Compute gaussian weights base-wise for OIT3 using mjdtf2 and mjd_oivis2 (nCal, nBase)
    if mode == "Full":
        gauss_o3 = np.exp(- (mjd_diff ** 2) / (sigma_days ** 2))  # (nCal, nBase)
    else:
        gauss_o3 = np.ones_like(mjd_diff)

    # We'll compute weighted mean for tfamp and tfphi across calibrators using these scalar weights combined with (1/tferr^2)
    # For tfamp: tfamperr_all (nCal, nTriplet, nWave)
    # Build per-calibrator weights across triplet/wave:
    w_tfamp_raw = (1.0 / (tfamperr_all ** 2 + 1e-30)) * gauss_o3[:, :, None]
    wsum_amp = np.sum(w_tfamp_raw, axis=0)
    # avoid zeros
    wsum_amp[wsum_amp == 0] = 1.0
    a_amp = w_tfamp_raw / wsum_amp[None, :, :]

    tfampInterp = np.sum(a_amp * tfamp_all, axis=0)  # (nTriplet, nWave)

    # error: for degFit==0 we approximate variance of the mean as 1 / sum(w) if w are (1/err^2)
    # so sigma^2_est = 1 / sum(1/err^2)  when using only 1/err^2 weights. Using our a_amp normalization, recover unnormalized sum:
    sum_w_un = np.sum((1.0 / (tfamperr_all ** 2 + 1e-30)) * gauss_o3[:, :, None], axis=0)
    tfampInterpErr = np.sqrt(1.0 / (sum_w_un + 1e-30))

    # Where all mjd calibrators are zero for the base(s) used -> set defaults
    # We'll check if all mjd_oit3 rows are zero (per calibrator) and if so set defaults broadly if necessary
    if np.all(mjd_oit3 == 0):
        tfampInterp[:, :] = 1.0
        tfampInterpErr[:, :] = 1e10
        tfphiInterp[:, :] = 0.0
        tfphiInterpErr[:, :] = 1e10
    else:
        # tfphi: similar process but use tfphi_all and tfphierr_all
        w_tfphi_raw = (1.0 / (tfphierr_all ** 2 + 1e-30)) * gauss_o3[:, :, None]
        wsum_phi = np.sum(w_tfphi_raw, axis=0)
        wsum_phi[wsum_phi == 0] = 1.0
        a_phi = w_tfphi_raw / wsum_phi[None, :, :]
        tfphiInterp = np.sum(a_phi * tfphi_all, axis=0)
        sum_w_phi_un = np.sum((1.0 / (tfphierr_all ** 2 + 1e-30)) * gauss_o3[:, :, None], axis=0)
        tfphiInterpErr = np.sqrt(1.0 / (sum_w_phi_un + 1e-30))

    # --- OIVIS (phase) tfdphiInterp and tfdphiInterpErr ---
    # Use mjdtfdphi which is shape (nBase,)
    # weights per calibrator per base
    mjd_diff_vis = mjdtfdphi[None, :] - mjd_oivis  # (nCal, nBase)
    if mode == "Full":
        gauss_vis = np.exp(- (mjd_diff_vis ** 2) / (sigma_days ** 2))
    else:
        gauss_vis = np.ones_like(mjd_diff_vis)

    # tfphi_vis_all (nCal, nBase, nWave), tfphierr_vis_all (nCal, nBase, nWave)
    w_vis_raw = (1.0 / (tfphierr_vis_all ** 2 + 1e-30)) * gauss_vis[:, :, None]  # (nCal, nBase, nWave)
    wsum_vis = np.sum(w_vis_raw, axis=0)
    wsum_vis[wsum_vis == 0] = 1.0
    a_vis = w_vis_raw / wsum_vis[None, :, :]

    tfdphiInterp = np.sum(a_vis * tfphi_vis_all, axis=0)  # (nBase, nWave)

    if nCal > 1:
        var_vis = np.var(tfphi_vis_all, axis=0)
        tfdphiInterpErr = np.sqrt(np.sum(a_vis**2 * var_vis[None, :, :], axis=0))
    else:
        tfdphiInterpErr = np.sqrt(np.sum(a_vis**2 * (tfphierr_vis_all ** 2), axis=0))

    # where mjd_oivis all zeros for a base -> set defaults
    mjd_all_zero_vis_base = np.all(mjd_oivis == 0, axis=0)
    if np.any(mjd_all_zero_vis_base):
        tfdphiInterp[mjd_all_zero_vis_base, :] = 0.0
        tfdphiInterpErr[mjd_all_zero_vis_base, :] = 1e10

    return (tf2Interp, tf2InterpErr,
            tfampInterp, tfampInterpErr,
            tfphiInterp, tfphiInterpErr,
            tfdphiInterp, tfdphiInterpErr)

##
# @brief ...
# @param file ...
# @param key ...
# @param value ...
# @return ...
#
def isKeywordEqualValue(file,key,value):
    """isKeywordEqualValue function"""
    hdu=fits.open(file)
    if key in hdu[0].header:
        if hdu[0].header[key] == value:
            hdu.close()
            return True
        hdu.close()
        return False
    hdu.close()
    return False

##
# @brief ...
# @param file ...
# @return ...
#
def isScience(file):
    """isScience function"""
    hdu=fits.open(file)
    instrume = hdu[0].header["INSTRUME"]
    if 'MATISSE' in instrume:
        instrume = hdu[0].header["ESO DET NAME"]
    key, val = dic_obj_type[instrume] 
    if hdu[0].header[key] == val:
        hdu.close()
        return True
    return False


##
# @brief ...
# @param file ...
# @return ...
#
def getInsConf(file):
    """getInsConf function"""
    hdu=fits.open(file)

    inst = hdu[0].header["INSTRUME"]
    if 'MATISSE' in inst:
        inst = hdu[0].header["ESO DET NAME"]
    kres = dic_resolution[inst]
    kwav = dic_wavelength[inst]
    kdit = dic_dit[inst]
    kgai = dic_gain[inst]
    conf = inst + "--" + hdu[0].header[kres] + "--" + "{:.2f}".format(hdu[0].header[kwav]) + \
        "--" + "{:.2f}".format(hdu[0].header[kdit]) + "--" + "{:.2f}".format(hdu[0].header[kgai]) 
    hdu.close()
    return conf

##
# @brief ...
# @param file ...
# @param key ...
# @return ...
#
def getKeyword(file,key):
    """getKeyword function"""
    hdu=fits.open(file)
    value=hdu[0].header[key]
    hdu.close()
    return value


def replaceByHD(name):
    res = Simbad.query_objectids(name)
    if 'ID' in res.colnames:
        key = 'ID'
    else:
        key = 'id'
    for i in range(len(res)):
        if 'HD' in res[key][i]:
            return res[key][i].replace('HD','HD_').replace(" ","")
    return name

###############################################################################
# Computing mean and variance of ratio of 2 indep. random variables Z=X/Y using :
#
# 1. the 4th order approx. of Winzer (Rev. of Sci. Instr., 2000)  if SNR(Y) > 4
#   E(Z)=Mode(Z)*(1+1/SNR(Y)**2)
#   Var(Z)=Mode(Z)^2*(1/SNR(X)^2+1/SNR(Y)^2-1/SNR(Y)^4+3/SNR(X)^2/SNR(Y)^2)  
#   or Var(Z)=Mode(Z)^2*(1/SNR(X)^2+1/SNR(Y)^2-1/SNR(X)^2/SNR(Y)^2)/(1-1/SNR(Y)^2)^2 (Fieller 1956)
#   where SNR(X)=E(X)/Sig(X), SNR(Y)=E(Y)/Sig(Y), Sig(X)=sqrt(Var(X)), Sig(Y)=sqrt(Var(Y)), 
#         and Mode(Z)=E(X)/E(Y)
# 
# 2. the asymmetric "modified-triangular" distribution if Snr(Y) < 2
#   E(Z)=Mode(Z) instead of (Min(Z)+Max(Z)+Mode(Z))/3
#   Var(Z)=((Max(Z)-Min(Z))/2)^2 = (Max(Z)^2+Min(Z)^2-2*Max(Z)*Min(Z))/4
#   instead of (Max(Z)^2+Min(Z)^2+Mode(Z)^2-Max(Z)*Min(Z)-Max(Z)*Mode(Z)-Min(Z)*Mode(Z))/18
#   where Min(Z)=(E(X)-Sig(X))/(E(Y)+Sig(Y)) and Max(Z)=(E(X)+Sig(X))/(E(Y)-Sig(Y))
#
# 3. a linear combination of both methods if 2 < Snr(Y) < 4 
#
# default output is the mean
###############################################################################
def ratio_mean(xMean,xSig,yMean,ySig):
    lowRelerr=0.25    # Winzer (or Fieller for ratio) applies for Relerr<lowRelerr (SNR>4)
    upRelerr=0.5     # triangular applies for Relerr>upRelerr (SNR<2)
    zMean=np.zeros_like(xMean)
    zVar=np.zeros_like(xSig)

    if (np.sum(np.abs(xMean)) >0.) and (np.sum(np.abs(xSig)) >0.) and (np.sum(np.abs(yMean)) >0.) and (np.sum(np.abs(ySig)) >0.):
        zMode=xMean/yMean
        xRelerr=np.abs(xSig/xMean)
        yRelerr=np.abs(ySig/yMean)
        
# Winzer approximations of mean and variance
        winzMean=zMode*(1.+yRelerr*yRelerr)
        winzVar=zMode*zMode*(xRelerr*xRelerr+yRelerr*yRelerr-yRelerr*yRelerr*yRelerr*yRelerr+3.*xRelerr*xRelerr*yRelerr*yRelerr)
    
# Fieller's variance for 68% confidence interval assuming ratio of normal v.a. 
        fielVar=zMode*zMode*(xRelerr*xRelerr+yRelerr*yRelerr-xRelerr*xRelerr*yRelerr*yRelerr)/(1.-yRelerr*yRelerr)/(1.-yRelerr*yRelerr)
    
# mean and variance of triangular distribution 
        xMin=xMean-xSig
        xMax=xMean+xSig
        yMin=yMean-ySig
        yMax=yMean+ySig

        zMin=xMin/yMax
        zMax=xMax/yMin
        
        triMean=zMode
        triVar=(zMax-zMin)*(zMax-zMin)/4.
    
        deltaRelerr=upRelerr-lowRelerr
        alfa=(yRelerr-lowRelerr)/deltaRelerr # linear combin. of Winzer/Fieller and triang. applies for 0.25<Relerr<0.5
        beta=(upRelerr-yRelerr)/deltaRelerr       
    
        zMean=np.copy(triMean)  # defaults values
        zVar=np.copy(triVar)
        
        iWinz=np.where((yRelerr < lowRelerr) & (winzVar > 0.))
        if np.size(iWinz[0])> 0:
            zMean[iWinz]=winzMean[iWinz]
            zVar[iWinz]=winzVar[iWinz]
    
        iFiel=np.where((yRelerr < lowRelerr) & (winzVar < 0.) & (fielVar > 0.))
        if np.size(iFiel[0])> 0:
            zMean[iFiel]=triMean[iFiel]
            zVar[iFiel]=fielVar[iFiel]
    
        iCombW=np.where((yRelerr > lowRelerr) & (yRelerr < upRelerr) & (winzVar > 0.) )
        if np.size(iCombW[0])> 0:
            zMean[iCombW]=alfa[iCombW]*winzMean[iCombW]+beta[iCombW]*triMean[iCombW]
            zVar[iCombW]=alfa[iCombW]*winzVar[iCombW]+beta[iCombW]*triVar[iCombW]

        iCombF=np.where((yRelerr > lowRelerr) & (yRelerr < upRelerr) & (winzVar < 0.) & (fielVar > 0.)  )
        if np.size(iCombF[0])> 0:
            zMean[iCombF]=triMean[iCombF]
            zVar[iCombF]=alfa[iCombF]*fielVar[iCombF]+beta[iCombF]*triVar[iCombF]
    
        if (np.size(iWinz[0])+np.size(iFiel[0])+np.size(iCombW[0])+np.size(iCombF[0]) > np.size(zMean)):
            print("zMean:{} iWinz:{} iFiel:{} iCombW:{} iCombF:{}".format(np.size(zMean),np.size(iWinz[0]), \
                                                                          np.size(iFiel[0]),np.size(iCombW[0]),np.size(iCombF[0])))
            print("Error: function ratio_mean() in utils.py" )       
               
    return zMean, zVar

def getstar(stars, version="public"): 
    if not isinstance(stars, list): stars=[stars]        
    if "beta" in version: 
        ssep="|"
        account="bourgesl"
    else:
        ssep=","
        account="sclws"    
    star = ssep.join([quote_plus(n) for n in stars])
    url="http://apps.jmmc.fr/~%s/getstar/sclwsGetStarProxy.php?star=%s&format=tsv"%(account, star)
    return pandas.read_csv(url, comment='#', sep="\t")

def getHdu(hdul, extname, insname):
    for hdu in hdul:
        if isinstance(hdu, fits.BinTableHDU) and extname in hdu.name:
            if insname in hdu.header.get("INSNAME"):
                hdutbl = hdu
                break
        else:
            hdutbl = None
    return hdutbl
