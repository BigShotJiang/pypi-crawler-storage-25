import argparse
from typing import List, Sequence, Tuple, Optional
import numpy as np
from dataclasses import dataclass
from pathlib import Path

def parse_bracket_list(text: Optional[str], cast=str) -> List:
    """Parse a string representing a Python-like list such as "[a,b,c]".
    Returns an empty list for None or empty string.
    """
    if not text:
        return []
    s = text.strip()
    if s.startswith("[") and s.endswith("]"):
        s = s[1:-1]
    if not s:
        return []
    return [cast(item.strip()) for item in s.split(',') if item.strip()]

def parse_wavelength_ranges(text: Optional[str]) -> Tuple[np.ndarray, np.ndarray]:
    """Parse wavelength ranges given as [lmin1,lmax1,lmin2,lmax2,...]
    and return lmin,lmax in meters (float arrays)."""
    vals = parse_bracket_list(text, float)
    if not vals:
        return np.zeros(0), np.zeros(0)
    if len(vals) % 2 != 0:
        #logger.warning("Odd number of wavelength values provided; truncating last value.")
        vals = vals[:-1]
    vals = np.array(vals, dtype=float)
    lmin = vals[0::2] * 1e-9
    lmax = vals[1::2] * 1e-9
    return lmin, lmax

@dataclass
class RunConfig:
    prodir: Path
    wdir: Path
    timespan: float
    discarded_baselines: List[int]
    discarded_wavelength_min: np.ndarray
    discarded_wavelength_max: np.ndarray
    discarded_tplstart: List[str]
    discarded_star: List[str]
    save_pdf: bool
    show_plot: bool
    filter_calib: bool
    diameter_cal_list: List[Tuple[str, float, float]]
    nverbose: bool

def parse_cli(argv: Optional[Sequence[str]] = None) -> RunConfig:
    parser = argparse.ArgumentParser(description="GenOCA Pipeline")
    parser.add_argument('prodir', type=str, help='Product Directory (your_path)')
    parser.add_argument('--wdir', type=str, default='.', help='Working Directory')
    parser.add_argument('--timspan', type=float, default=12., help='Time span (hours) for selecting calibrators')
    parser.add_argument('--filbase', type=str, default='[]', help='Discarded Baseline list, e.g. [1,3]')
    parser.add_argument('--filwave', type=str, default='[]', help='Discarded wavelength ranges [lmin,lmax,...] (nm)')
    parser.add_argument('--filob', type=str, default='[]', help='Discarded OBs by TPL START list')
    parser.add_argument('--filstar', type=str, default='[]', help='Discarded Stars by name list')
    parser.add_argument('--pdf', dest='pdf', action='store_true', help='Create PDF report')
    parser.add_argument('--plot', dest='plot', action='store_true', help='Show plots')
    parser.add_argument('--medfilt', dest='medfilt', action='store_true', help='Apply median filter to calibrators')
    parser.add_argument('--diamcal', type=str, default='[]', help='List of calibrator diameters: [name,diam,err,...].The name of the calibrator should be of the form HD_123456.')
    parser.add_argument('--notverb', dest='notverb', action='store_true', help='Not Verbose')

    args = parser.parse_args(argv)
    
    discarded_baselines = parse_bracket_list(args.filbase, int)
    discarded_tplstart = parse_bracket_list(args.filob, str)
    discarded_tplstart=[s.strip("'") for s in discarded_tplstart]
    discarded_star = parse_bracket_list(args.filstar, str)
    discarded_star=[s.strip("'") for s in discarded_star]
    lmin, lmax = parse_wavelength_ranges(args.filwave)
    
    # diameterCal: groups of three values (name, diam, err)
    diam_vals = parse_bracket_list(args.diamcal, str)
    diameter_cal_list: List[Tuple[str, float, float]] = []
    if diam_vals:
        if len(diam_vals) % 3 != 0:
            raise ValueError("--diameterCal expects triples of (name,diam,err)")
        for i in range(0, len(diam_vals), 3):
            name = diam_vals[i]
            diam = float(diam_vals[i + 1])
            err = float(diam_vals[i + 2])
            diameter_cal_list.append((name, diam, err))

    cfg = RunConfig(
        prodir=Path(args.prodir),
        wdir=Path(args.wdir),
        timespan=float(args.timspan),
        discarded_baselines=discarded_baselines,
        discarded_wavelength_min=lmin,
        discarded_wavelength_max=lmax,
        discarded_tplstart=discarded_tplstart,
        discarded_star=discarded_star,
        save_pdf=args.pdf,
        show_plot=args.plot,
        filter_calib=args.medfilt,
        diameter_cal_list=diameter_cal_list,
        nverbose=args.notverb
    )

    #logger.debug("Parsed CLI config: %s", cfg)
    return cfg

