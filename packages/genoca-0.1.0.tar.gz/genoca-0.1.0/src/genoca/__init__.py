TOOL_NAME = 'Generic Oifits CAlibration GenOCA'

dic_obj_type = {
    "MIRC-X": ["OBJTYPE", "TARGET"],
    "MYSTIC": ["OBJTYPE", "TARGET"],
    "SPICA": ["PRO SCIENCE", True],
    "MATISSE-LM": ["ESO PRO SCIENCE", True],
    "MATISSE-N": ["ESO PRO SCIENCE", True],
    "GRAVITY": ["ESO PRO SCIENCE", True]
    }
dic_resolution = {
    "MIRC-X": "CONF_NA",
    "MYSTIC": "CONF_NA",
    "SPICA": "INS RESOL",
    "MATISSE-LM": "ESO QC INS DISP",
    "MATISSE-N": "ESO QC INS DISP",
    "GRAVITY": "ESO INS SPEC RES"
    }
dic_wavelength = {
    "MIRC-X": "WAVELEN",
    "MYSTIC": "WAVELEN",
    "SPICA": "INS CENTRAL WL",
    "MATISSE-LM": "ESO SEQ DIL WL0",
    "MATISSE-N": "ESO SEQ DIN WL0",
    "GRAVITY": "ESO INS SLC1 WAVELENG"
   }
dic_dit = {
    "MIRC-X": "EXPOSURE",
    "MYSTIC": "EXPOSURE",
    "SPICA": "DET DIT",
    "MATISSE-LM": "ESO DET SEQ1 DIT",
    "MATISSE-N": "ESO DET SEQ1 DIT",
    "GRAVITY": "ESO DET1 SEQ1 DIT"
    }
dic_gain = {
    "MIRC-X": "GAIN",
    "MYSTIC": "GAIN",
    "SPICA": "DET GAIN",
    "MATISSE-LM": "ESO DET CHIP GAIN",
    "MATISSE-N": "ESO DET CHIP GAIN",
    "GRAVITY": "ESO INS DET2 GAIN"
    }
dic_catalog = {
    "MIRC-X": ["UDDK", "UD_K"],
    "MYSTIC": ["UDDH", "UD_H"],
    "SPICA": ["UDDR", "UD_R"],
    "MATISSE-LM": ["UDDL", "UD_L"],
    "MATISSE-N": ["UDDN", "UD_N"],
    "GRAVITY": ["UDDK", "UD_K"]
    }

dic_logo = {
    "MIRC-X": ["chara_logo.png", "mircx_logo.png"],
    "MYSTIC": ["chara_logo.png", "mystic_logo.png"],
    "SPICA": ["chara_logo.png", "issp_logo.png"],
    "MATISSE-LM": ["eso_logo.png", "matisse_logo.png"],
    "MATISSE-N": ["eso_logo.png", "matisse_logo.png"],
    "GRAVITY": ["eso_logo.png", "gravity_logo.png"]
    }

dic_ob = {
    "MIRC-X": "MIRC SEQ START TIME",
    "MYSTIC": "MIRC SEQ START TIME",
    "SPICA": "TPL START",
    "MATISSE-LM": "ESO TPL START",
    "MATISSE-N": "ESO TPL START",
    "GRAVITY": "ESO TPL START"
    }

dic_type = {
    "MIRC-X": ["OBJTYPE",["REFERENCE", "TARGET"]],
    "MYSTIC": ["OBJTYPE",["REFERENCE", "TARGET"]],
    "SPICA": ["PRO CATG",["CALIB_RAW_INT", "TARGET_RAW_INT"]],
    "MATISSE-LM": ["ESO PRO CATG",["CALIB_RAW_INT", "TARGET_RAW_INT"]],
    "MATISSE-N": ["ESO PRO CATG",["CALIB_RAW_INT", "TARGET_RAW_INT"]],
    "GRAVITY": ["ESO PRO CATG",["SINGLE_CAL_VIS", "SINGLE_SCI_VIS"]]
    }

dic_objname = {
    "MIRC-X": "OBJECT",
    "MYSTIC": "OBJECT",
    "SPICA": "OBS TARG NAME",
    "MATISSE-LM": "ESO OBS TARG NAME",
    "MATISSE-N": "ESO OBS TARG NAME",
    "GRAVITY": "ESO OBS TARG NAME"
    }
    
