# GenOCA
Generic OIFITS calibration tool
