"""Tests for the fluent pipeline builder (pipeline.add(name=..., id=...).node_type(...))."""

import warnings

import pytest

from vectorshift.pipeline.node import Node
from vectorshift.pipeline.node_adder import NodeAdder
from vectorshift.pipeline.node_output import NodeOutput, TypeCompatibilityWarning
from vectorshift.pipeline.object import Pipeline
from vectorshift.pipeline.nodes import (
    InputNode,
    OutputNode,
    LlmNode,
)

# ---------------------------------------------------------------------------
# Basic creation
# ---------------------------------------------------------------------------


class TestNodeAdderCreation:
    def test_add_returns_node_adder(self):
        pipeline = Pipeline(nodes=[])
        assert isinstance(pipeline.add, NodeAdder)

    def test_add_is_cached(self):
        pipeline = Pipeline(nodes=[])
        assert pipeline.add is pipeline.add

    def test_add_callable_returns_node_adder(self):
        pipeline = Pipeline(nodes=[])
        primed = pipeline.add(name='x', id='y')
        assert isinstance(primed, NodeAdder)

    def test_add_primed_name_and_id(self):
        pipeline = Pipeline(nodes=[])
        inp = pipeline.add(name='my_input', id='inp_1').input(
            input_type='string', use_default_value=False
        )
        assert inp.name == 'my_input'
        assert inp.id == 'inp_1'

    def test_add_input_node(self):
        pipeline = Pipeline(nodes=[])
        inp = pipeline.add(name='inp').input(
            input_type='string', use_default_value=False
        )
        assert isinstance(inp, InputNode)
        assert inp in pipeline.nodes
        assert len(pipeline.nodes) == 1

    def test_add_llm_node(self):
        pipeline = Pipeline(nodes=[])
        llm = pipeline.add(name='llm').llm(
            provider='openai', model='gpt-4', stream=False
        )
        assert isinstance(llm, LlmNode)
        assert llm in pipeline.nodes

    def test_add_output_node(self):
        pipeline = Pipeline(nodes=[])
        out = pipeline.add(name='out').output(output_type='string')
        assert isinstance(out, OutputNode)
        assert out in pipeline.nodes

    def test_add_without_name_raises(self):
        """Calling pipeline.add() without name= must raise TypeError."""
        pipeline = Pipeline(nodes=[])
        with pytest.raises(TypeError):
            pipeline.add()


# ---------------------------------------------------------------------------
# Auto-registration & ordering
# ---------------------------------------------------------------------------


class TestNodeAdderAutoRegistration:
    def test_multiple_nodes_registered(self):
        pipeline = Pipeline(nodes=[])
        pipeline.add(name='inp').input(input_type='string', use_default_value=False)
        pipeline.add(name='llm').llm(provider='openai', model='gpt-4', stream=False)
        pipeline.add(name='out').output(output_type='string')
        assert len(pipeline.nodes) == 3

    def test_nodes_retain_order(self):
        pipeline = Pipeline(nodes=[])
        inp = pipeline.add(name='inp', id='inp').input(
            input_type='string', use_default_value=False
        )
        llm = pipeline.add(name='llm', id='llm').llm(
            provider='openai', model='gpt-4', stream=False
        )
        out = pipeline.add(name='out', id='out').output(output_type='string')
        assert pipeline.nodes[0] is inp
        assert pipeline.nodes[1] is llm
        assert pipeline.nodes[2] is out

    def test_mixed_add_and_manual(self):
        """Builder-added and manually-added nodes coexist."""
        pipeline = Pipeline(nodes=[])
        inp = pipeline.add(name='inp', id='inp').input(
            input_type='string', use_default_value=False
        )
        manual = LlmNode(id='manual', provider='openai', model='gpt-4', stream=False)
        pipeline.add_node(manual)
        out = pipeline.add(name='out', id='out').output(output_type='string')
        assert pipeline.nodes == [inp, manual, out]


# ---------------------------------------------------------------------------
# Wiring through builder
# ---------------------------------------------------------------------------


class TestNodeAdderWiring:
    def test_basic_chain(self):
        pipeline = Pipeline(nodes=[])
        inp = pipeline.add(name='inp', id='inp').input(
            input_type='string', use_default_value=False
        )
        llm = pipeline.add(name='llm', id='llm').llm(
            provider='openai',
            model='gpt-4',
            stream=False,
            prompt=inp.text,
        )
        out = pipeline.add(name='out', id='out').output(
            output_type='string', value=llm.response
        )
        assert llm.inputs['prompt'] == '{{ inp.text }}'
        assert out.inputs['value'] == '{{ llm.response }}'

    def test_llm_chain(self):
        pipeline = Pipeline(nodes=[])
        inp = pipeline.add(name='inp', id='inp').input(
            input_type='string', use_default_value=False
        )
        llm1 = pipeline.add(name='llm1', id='llm1').llm(
            provider='openai', model='gpt-4', stream=False, prompt=inp.text
        )
        llm2 = pipeline.add(name='llm2', id='llm2').llm(
            provider='openai',
            model='gpt-4',
            stream=False,
            prompt=llm1.response,
        )
        assert llm2.inputs['prompt'] == '{{ llm1.response }}'

    def test_file_chain(self):
        pipeline = Pipeline(nodes=[])
        inp = pipeline.add(name='inp_f', id='inp_f').input(
            input_type='file', use_default_value=False
        )
        csv = pipeline.add(name='csv_r', id='csv_r').csv_reader(
            selected_file=inp.file, file_type='CSV', is_file_variable=True
        )
        assert csv.inputs['selected_file'] == '{{ inp_f.file }}'

    def test_multi_dependency(self):
        pipeline = Pipeline(nodes=[])
        inp1 = pipeline.add(name='inp1', id='inp1').input(
            input_type='string', use_default_value=False
        )
        inp2 = pipeline.add(name='inp2', id='inp2').input(
            input_type='string', use_default_value=False
        )
        cl = pipeline.add(name='cl', id='cl').create_list(
            type='string', list=[inp1.text, inp2.text]
        )
        _, all_deps = cl.get_dependencies()
        assert ('inp1', 'text') in all_deps
        assert ('inp2', 'text') in all_deps


# ---------------------------------------------------------------------------
# name sets display name
# ---------------------------------------------------------------------------


class TestNodeAdderNodeName:
    def test_node_name_sets_display_name(self):
        pipeline = Pipeline(nodes=[])
        inp = pipeline.add(name='my_input').input(
            input_type='string', use_default_value=False
        )
        assert inp.name == 'my_input'


# ---------------------------------------------------------------------------
# Error cases
# ---------------------------------------------------------------------------


class TestNodeAdderErrors:
    def test_unknown_node_type_raises(self):
        pipeline = Pipeline(nodes=[])
        with pytest.raises(AttributeError, match='Unknown node type'):
            pipeline.add(name='bad').nonexistent_node_type()

    def test_private_attr_raises(self):
        pipeline = Pipeline(nodes=[])
        with pytest.raises(AttributeError):
            pipeline.add._private()


# ---------------------------------------------------------------------------
# Type compatibility through builder
# ---------------------------------------------------------------------------


class TestNodeAdderTypeCompatibility:
    def test_full_compatibility_no_warning(self):
        pipeline = Pipeline(nodes=[])
        inp = pipeline.add(name='inp', id='inp').input(
            input_type='string', use_default_value=False
        )
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter('always')
            pipeline.add(name='llm', id='llm').llm(
                provider='openai',
                model='gpt-4',
                stream=False,
                prompt=inp.text,
            )
            type_warnings = [
                x for x in w if issubclass(x.category, TypeCompatibilityWarning)
            ]
            assert len(type_warnings) == 0

    def test_incompatible_raises(self):
        """int64 (tokens_used) is incompatible with stream<string> output."""
        pipeline = Pipeline(nodes=[])
        llm = pipeline.add(name='llm', id='llm').llm(
            provider='openai', model='gpt-4', stream=True
        )
        with pytest.raises(TypeError, match='Type error'):
            pipeline.add(name='out', id='out').output(
                output_type='stream<string>', value=llm.tokens_used
            )


# ---------------------------------------------------------------------------
# Backwards compatibility
# ---------------------------------------------------------------------------


class TestNodeAdderBackwardsCompat:
    def test_old_constructor_api(self):
        inp = InputNode(id='inp', input_type='string', use_default_value=False)
        llm = LlmNode(
            id='llm', provider='openai', model='gpt-4', stream=False, prompt=inp.text
        )
        pipeline = Pipeline(nodes=[inp, llm])
        assert len(pipeline.nodes) == 2
        assert llm.inputs['prompt'] == '{{ inp.text }}'

    def test_add_node_method(self):
        pipeline = Pipeline(nodes=[])
        inp = InputNode(id='inp', input_type='string', use_default_value=False)
        pipeline.add_node(inp)
        assert inp in pipeline.nodes


# ---------------------------------------------------------------------------
# Smoke test: all registered node types are accessible
# ---------------------------------------------------------------------------


class TestNodeAdderCoverage:
    @pytest.mark.parametrize('node_type', sorted(Node._node_registry.keys()))
    def test_adder_has_attr(self, node_type):
        """Every registered node type should be callable via the builder."""
        pipeline = Pipeline(nodes=[])
        factory = getattr(pipeline.add, node_type)
        assert callable(factory)


# ---------------------------------------------------------------------------
# Stub accuracy tests
# ---------------------------------------------------------------------------


class TestNodeAdderStubAccuracy:
    """Verify the generated node_adder.pyi is syntactically valid and complete."""

    @staticmethod
    def _stub_path():
        import pathlib

        return (
            pathlib.Path(__file__).resolve().parents[2]
            / 'vectorshift'
            / 'pipeline'
            / 'node_adder.pyi'
        )

    def test_stub_file_exists(self):
        assert self._stub_path().is_file(), 'node_adder.pyi not found'

    def test_stub_parses_as_valid_python(self):
        """The .pyi must be syntactically valid Python (parseable by ast)."""
        import ast

        source = self._stub_path().read_text()
        tree = ast.parse(source)
        assert isinstance(tree, ast.Module)

    def test_stub_has_node_adder_class(self):
        import ast

        source = self._stub_path().read_text()
        tree = ast.parse(source)
        class_names = [
            node.name for node in ast.walk(tree) if isinstance(node, ast.ClassDef)
        ]
        assert 'NodeAdder' in class_names

    def test_stub_has_call_method(self):
        import ast

        source = self._stub_path().read_text()
        tree = ast.parse(source)

        adder_class = None
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and node.name == 'NodeAdder':
                adder_class = node
                break
        assert adder_class is not None

        method_names = [
            item.name for item in adder_class.body if isinstance(item, ast.FunctionDef)
        ]
        assert '__call__' in method_names, 'NodeAdder stub is missing __call__'

    def test_every_registry_type_has_stub_attribute(self):
        """Every node type in the runtime registry must have an attribute in the stub."""
        import ast

        source = self._stub_path().read_text()
        tree = ast.parse(source)

        adder_class = None
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and node.name == 'NodeAdder':
                adder_class = node
                break
        assert adder_class is not None

        # Collect node names from class attributes (input = InputNode)
        # and @property defs (def input(self) -> type[InputNode])
        stub_attrs = set()
        for item in adder_class.body:
            if isinstance(item, ast.Assign):
                for target in item.targets:
                    if isinstance(target, ast.Name):
                        stub_attrs.add(target.id)
            elif isinstance(item, ast.FunctionDef) and not item.name.startswith('_'):
                stub_attrs.add(item.name)

        registry_types = set(Node._node_registry.keys())
        missing = registry_types - stub_attrs
        assert not missing, f'Registry types missing from stub: {sorted(missing)}'

    def test_no_phantom_attributes(self):
        """Stub should not contain attributes that don't exist in the registry."""
        import ast

        source = self._stub_path().read_text()
        tree = ast.parse(source)

        adder_class = None
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and node.name == 'NodeAdder':
                adder_class = node
                break
        assert adder_class is not None

        stub_attrs = set()
        for item in adder_class.body:
            if isinstance(item, ast.Assign):
                for target in item.targets:
                    if isinstance(target, ast.Name):
                        stub_attrs.add(target.id)
            elif isinstance(item, ast.FunctionDef) and not item.name.startswith('_'):
                stub_attrs.add(item.name)

        registry_types = set(Node._node_registry.keys())
        phantom = stub_attrs - registry_types
        assert not phantom, f'Phantom attributes in stub: {sorted(phantom)}'

    def test_stub_attributes_reference_node_classes(self):
        """Each stub attribute should reference a node class (e.g. input = InputNode or @property -> type[InputNode])."""
        import ast

        source = self._stub_path().read_text()
        tree = ast.parse(source)

        adder_class = None
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and node.name == 'NodeAdder':
                adder_class = node
                break
        assert adder_class is not None

        for item in adder_class.body:
            if isinstance(item, ast.Assign):
                for target in item.targets:
                    if isinstance(target, ast.Name):
                        # Value should be a Name referencing a class
                        assert isinstance(
                            item.value, ast.Name
                        ), f'{target.id} does not reference a class name'
                        assert item.value.id.endswith(
                            'Node'
                        ), f'{target.id} = {item.value.id} does not end with "Node"'


# ---------------------------------------------------------------------------
# Overwrite on name collision
# ---------------------------------------------------------------------------


class TestNodeAdderOverwrite:
    def test_add_same_name_overwrites(self):
        """Adding a node with the same name replaces the existing one."""
        pipeline = Pipeline(nodes=[])
        pipeline.add(name='llm').llm(provider='openai', model='gpt-4', stream=False)
        llm2 = pipeline.add(name='llm').llm(
            provider='openai', model='gpt-4o', stream=True
        )
        assert len(pipeline.nodes) == 1
        assert pipeline.nodes[0] is llm2

    def test_overwrite_preserves_position(self):
        """Overwritten node keeps its position in the list."""
        pipeline = Pipeline(nodes=[])
        inp = pipeline.add(name='inp').input(
            input_type='string', use_default_value=False
        )
        pipeline.add(name='llm').llm(provider='openai', model='gpt-4', stream=False)
        out = pipeline.add(name='out').output(output_type='string')
        llm2 = pipeline.add(name='llm').llm(
            provider='openai', model='gpt-4o', stream=True
        )
        assert pipeline.nodes == [inp, llm2, out]

    def test_overwrite_updates_io_tracking(self):
        """Overwriting an input node updates pipeline.inputs."""
        pipeline = Pipeline(nodes=[])
        pipeline.add(name='query').input(input_type='string', use_default_value=False)
        assert pipeline.inputs['query']['io_type'] == 'string'
        pipeline.add(name='query').input(input_type='file', use_default_value=False)
        assert pipeline.inputs['query']['io_type'] == 'file'
        assert len(pipeline.nodes) == 1

    def test_no_name_always_appends(self):
        """Nodes without names never collide — always appended."""
        pipeline = Pipeline(nodes=[])
        llm1 = LlmNode(provider='openai', model='gpt-4', stream=False)
        llm2 = LlmNode(provider='openai', model='gpt-4', stream=False)
        pipeline.add_node(llm1)
        pipeline.add_node(llm2)
        assert len(pipeline.nodes) == 2

    def test_add_node_method_overwrites(self):
        """pipeline.add_node() also overwrites on name collision."""
        pipeline = Pipeline(nodes=[])
        node1 = LlmNode(
            node_name='llm', id='llm_1', provider='openai', model='gpt-4', stream=False
        )
        node2 = LlmNode(
            node_name='llm', id='llm_2', provider='openai', model='gpt-4o', stream=True
        )
        pipeline.add_node(node1)
        pipeline.add_node(node2)
        assert len(pipeline.nodes) == 1
        assert pipeline.nodes[0] is node2

    def test_add_batch_overwrites(self):
        """add_batch also overwrites on name collision."""
        pipeline = Pipeline(nodes=[])
        pipeline.add_batch(name='llm').llm(
            provider='openai', model='gpt-4', stream=False
        )
        llm2 = pipeline.add_batch(name='llm').llm(
            provider='openai', model='gpt-4o', stream=True
        )
        assert len(pipeline.nodes) == 1
        assert pipeline.nodes[0] is llm2
