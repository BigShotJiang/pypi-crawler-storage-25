"""Tests for pipeline.add_batch fluent builder."""

from vectorshift.pipeline.object import Pipeline
from vectorshift.pipeline.node_adder import NodeAdder
from vectorshift.pipeline.nodes import LlmNode, ConditionNode


class TestAddBatchProperty:
    def test_returns_node_adder(self):
        p = Pipeline()
        assert isinstance(p.add_batch, NodeAdder)

    def test_execution_mode_is_batch(self):
        p = Pipeline()
        assert p.add_batch._execution_mode == "batch"

    def test_cached(self):
        p = Pipeline()
        assert p.add_batch is p.add_batch

    def test_regular_add_is_separate(self):
        p = Pipeline()
        assert p.add._execution_mode is None
        assert p.add_batch._execution_mode == "batch"


class TestAddBatchNodeCreation:
    def test_llm_gets_batch_mode(self):
        p = Pipeline()
        llm = p.add_batch(name="batch_llm").llm(
            provider="openai",
            model="gpt-4o",
            stream=False,
        )
        assert llm.execution_mode == "batch"
        assert len(p.nodes) == 1

    def test_explicit_override(self):
        """User can override execution_mode even with add_batch."""
        p = Pipeline()
        llm = p.add_batch.llm(
            provider="openai",
            model="gpt-4o",
            stream=False,
            execution_mode="normal",
        )
        assert llm.execution_mode == "normal"

    def test_priming_preserves_batch(self):
        p = Pipeline()
        adder = p.add_batch(name="test", id="t1")
        assert adder._execution_mode == "batch"
        assert adder._name == "test"
        assert adder._id == "t1"


class TestAddBatchRuntime:
    def test_outputs_vectorized(self):
        p = Pipeline()
        llm = p.add_batch.llm(
            provider="openai",
            model="gpt-4o",
            stream=False,
        )
        # Runtime: batch mode should vectorize outputs
        assert llm.response.semantic_type == "vec<string>"

    def test_complete_not_vectorized(self):
        p = Pipeline()
        llm = p.add_batch.llm(
            provider="openai",
            model="gpt-4o",
            stream=False,
        )
        assert not llm.complete.semantic_type.startswith("vec<")

    def test_inputs_vectorized(self):
        p = Pipeline()
        llm = p.add_batch.llm(
            provider="openai",
            model="gpt-4o",
            stream=False,
        )
        valid = llm._get_valid_inputs_for_params()
        prompt_type = valid.get("prompt", {}).get("type", "")
        assert prompt_type == "vec<string>"
