import pytest
from vectorshift.pipeline.nodes import (
    OutputNode,
    LlmNode,
)

# ---------------------------------------------------------------------------
# Tests for base-class mechanics (not covered by smoke test)
# ---------------------------------------------------------------------------


class TestLlmNode:
    def test_set_prompt_via_constructor(self):
        node = LlmNode(
            id='llm_p',
            provider='openai',
            model='gpt-4',
            stream=False,
            prompt='hello',
        )
        assert node.inputs['prompt'] == 'hello'

    def test_update_inputs(self):
        node = LlmNode(id='llm_u', provider='openai', model='gpt-4', stream=False)
        node.update_inputs(prompt='new')
        assert node.inputs['prompt'] == 'new'

    def test_invalid_input_rejected(self):
        node = LlmNode(id='llm_inv', provider='openai', model='gpt-4', stream=False)
        with pytest.raises(ValueError, match='Invalid input'):
            node.update_inputs(nonexistent='x')


class TestOutputNode:
    def test_value_input_type_changes(self):
        node_file = OutputNode(id='out_file', output_type='file')
        node_str = OutputNode(id='out_str', output_type='string')
        file_inputs = node_file._get_valid_inputs_for_params()  # type: ignore[attr-defined]
        str_inputs = node_str._get_valid_inputs_for_params()  # type: ignore[attr-defined]
        assert file_inputs['value']['type'] == 'file'
        assert str_inputs['value']['type'] == 'string'


# ---------------------------------------------------------------------------
# Parametrized smoke test: instantiate every node type from TOML
# ---------------------------------------------------------------------------


class TestAllNodeTypesInstantiate:
    """Smoke test: every registered node type can be instantiated."""

    @staticmethod
    def _all_registered_types():
        """Collect all node types registered via @Node.register_node_type."""
        from vectorshift.pipeline.node import Node

        return sorted(Node._node_registry.keys())

    @pytest.mark.parametrize(
        'node_type',
        _all_registered_types.__func__(),
    )
    def test_instantiate_defaults(self, node_type):
        from vectorshift.pipeline.node import Node

        cls = Node._node_registry.get(node_type)
        assert cls is not None, f"No class registered for {node_type}"
        try:
            node = cls(id=f'smoke_{node_type}')
        except (TypeError, ValueError):
            # Some nodes require specific constructor args; skip gracefully
            pytest.skip(f'{cls.__name__} requires specific constructor args')
        assert node is not None
        assert node.node_type == node_type
