import pytest
from vectorshift.integrations.integration import Integration
from vectorshift.pipeline.node_output import NodeOutput
from vectorshift.pipeline.nodes import (
    TimeNode,
    InputNode,
    OutputNode,
    LlmNode,
    CategorizerNode,
    ReadJsonValuesNode,
    ConditionNode,
    CodeExecutionNode,
    IntegrationGmailNode,
    KnowledgeBaseNode,
    DataCollectorNode,
)

INTEGRATION = Integration(object_id='test')


def _all_smokepack_nodes():
    return [
        TimeNode(id='t'),
        InputNode(id='i', input_type='string', use_default_value=False),
        OutputNode(id='o', output_type='string'),
        LlmNode(id='l', provider='openai', model='gpt-4', stream=False),
        CategorizerNode(id='c', justification=False, provider='openai', text=''),
    ]


class TestCompleteAlwaysPresent:
    def test_all_smokepack_nodes_have_complete(self):
        for node in _all_smokepack_nodes():
            assert (
                'complete' in node.outputs
            ), f'{node.__class__.__name__} missing complete'


class TestLlmOutputs:
    def test_stream_true_response_is_stream(self):
        node = LlmNode(id='llm_s', provider='openai', model='gpt-4', stream=True)
        assert node.response.semantic_type == 'stream<string>'

    def test_stream_false_response_is_string(self):
        node = LlmNode(id='llm_ns', provider='openai', model='gpt-4', stream=False)
        assert node.response.semantic_type == 'string'


class TestCategorizerOutputs:
    def test_justification_true_adds_output(self):
        node = CategorizerNode(
            id='cat_t',
            justification=True,
            provider='openai',
            text='',
        )
        assert 'justification' in node.outputs

    def test_justification_false_no_justification(self):
        node = CategorizerNode(
            id='cat_f',
            justification=False,
            provider='openai',
            text='',
        )
        assert 'justification' not in node.outputs


class TestReadJsonValuesOutputs:
    def test_dynamic_outputs(self):
        node = ReadJsonValuesNode(
            id='rjv_dyn',
            json_string='',
            keys=[],
            processed_outputs={
                'first_name': 'string',
                'user_age': 'int32',
            },
        )
        assert 'first_name' in node.outputs
        assert 'user_age' in node.outputs


class TestConditionOutputs:
    def test_dynamic_outputs(self):
        node = ConditionNode(
            id='cond',
            outputs={'path_1': 'string', 'path_2': 'string'},
        )
        assert 'path_1' in node.outputs
        assert 'path_2' in node.outputs


class TestCodeExecutionOutputs:
    def test_dynamic_outputs(self):
        node = CodeExecutionNode(
            id='ce', code='', processed_outputs={'result': 'string'}
        )
        assert 'result' in node.outputs


class TestKnowledgeBaseOutputs:
    def test_chunks_by_default(self):
        node = KnowledgeBaseNode(
            id='kb',
            knowledge_base='test_kb',
            query='test',
            retrieval_unit='chunks',
        )
        assert 'chunks' in node.outputs
        assert 'documents' not in node.outputs

    def test_documents_retrieval_unit(self):
        from vectorshift.pipeline.config_objects import RetrievalConfig

        node = KnowledgeBaseNode(
            id='kb_doc',
            knowledge_base='test_kb',
            query='test',
            retrieval=RetrievalConfig(unit='documents'),
        )
        assert 'documents' in node.outputs
        assert 'chunks' not in node.outputs

    def test_format_context_adds_formatted_text(self):
        node = KnowledgeBaseNode(
            id='kb_fmt',
            knowledge_base='test_kb',
            query='test',
            format_context_for_llm=True,
        )
        assert 'formatted_text' in node.outputs

    def test_format_context_false_no_formatted_text(self):
        node = KnowledgeBaseNode(
            id='kb_nofmt',
            knowledge_base='test_kb',
            query='test',
            format_context_for_llm=False,
        )
        assert 'formatted_text' not in node.outputs

    def test_stream_response_changes_type(self):
        node_stream = KnowledgeBaseNode(
            id='kb_s',
            knowledge_base='test_kb',
            query='test',
            set_response_format=True,
            stream_response=True,
        )
        node_no_stream = KnowledgeBaseNode(
            id='kb_ns',
            knowledge_base='test_kb',
            query='test',
            set_response_format=True,
            stream_response=False,
        )
        assert 'response' in node_stream.outputs
        assert 'response' in node_no_stream.outputs
        assert node_stream.response.semantic_type == 'stream<string>'
        assert node_no_stream.response.semantic_type == 'string'


class TestDataCollectorOutputs:
    def test_auto_generate_false(self):
        node = DataCollectorNode(id='dc_f', query='test', auto_generate=False)
        assert 'collected_data' in node.outputs

    def test_auto_generate_true(self):
        node = DataCollectorNode(id='dc_t', query='test', auto_generate=True)
        assert 'question' in node.outputs


class TestGmailOutputs:
    def test_actions_produce_different_outputs(self):
        send = IntegrationGmailNode(
            id='g_s',
            action='send_email',
            integration=INTEGRATION,
            body='',
            format='text',
            recipients='',
            subject='',
        )
        read = IntegrationGmailNode(
            id='g_r',
            action='read_message',
            integration=INTEGRATION,
            format='full',
            message_id='',
        )
        read_only = set(read.outputs) - set(send.outputs)
        assert len(read_only) > 0
        assert 'subject' in read_only
        assert 'body' in read_only


class TestTemplateFormat:
    def test_output_is_template_string(self):
        llm = LlmNode(id='llm_tpl', provider='openai', model='gpt-4', stream=False)
        assert llm.response == '{{ llm_tpl.response }}'


class TestNodeOutputType:
    def test_output_is_node_output(self):
        llm = LlmNode(id='llm_no', provider='openai', model='gpt-4', stream=False)
        assert isinstance(llm.response, NodeOutput)

    def test_output_carries_semantic_type(self):
        llm = LlmNode(id='llm_st', provider='openai', model='gpt-4', stream=False)
        assert hasattr(llm.response, 'semantic_type')
        assert isinstance(llm.response.semantic_type, str)


class TestInvalidOutputAccess:
    def test_invalid_raises_attribute_error(self):
        llm = LlmNode(id='llm_ae', provider='openai', model='gpt-4', stream=False)
        with pytest.raises(AttributeError):
            _ = llm.nonexistent
