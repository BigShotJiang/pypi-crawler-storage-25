import ast
from pathlib import Path
import pytest

from vectorshift.types import get_output_type_name
from vectorshift.integrations.integration import Integration
from vectorshift.pipeline.nodes import (
    TimeNode,
    InputNode,
    LlmNode,
    KnowledgeBaseNode,
    TransformationNode,
    ConditionNode,
    CodeExecutionNode,
    CsvReaderNode,
    IntegrationGmailNode,
)

INTEGRATION = Integration(object_id='test')


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _parse_stub_return_class(stub_path: Path, class_name: str):
    """Parse a stub class and return {property_name: type_annotation}."""
    tree = ast.parse(stub_path.read_text())
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef) and node.name == class_name:
            props = {}
            for item in node.body:
                if isinstance(item, ast.FunctionDef) and item.name != '__init__':
                    for decorator in item.decorator_list:
                        if (
                            isinstance(decorator, ast.Name)
                            and decorator.id == 'property'
                        ):
                            if item.returns:
                                props[item.name] = ast.unparse(item.returns)
            return props
    return None


def _get_runtime_output_types(node_instance):
    """Get {output_name: semantic_type} from a live node instance."""
    result = {}
    for output_name in node_instance.outputs:
        out = getattr(node_instance, output_name)
        result[output_name] = out.semantic_type
    return result


def _assert_stub_matches_runtime(stub_props, runtime, label=''):
    """Bidirectional: stub props == runtime outputs, no extras."""
    prefix = f'[{label}] ' if label else ''
    missing_from_stub = set(runtime) - set(stub_props)
    assert (
        not missing_from_stub
    ), f'{prefix}Runtime outputs missing from stub: {missing_from_stub}'
    phantom_in_stub = set(stub_props) - set(runtime)
    assert (
        not phantom_in_stub
    ), f'{prefix}Phantom stub properties not in runtime: {phantom_in_stub}'


def _qualify_type(type_name: str) -> str:
    """Prefix type names with vst. to match stub annotations.

    Object reference types (Agent, Pipeline, etc.) are imported directly
    and don't need the vst. prefix.
    """
    _DIRECT_IMPORT_TYPES = {
        "Agent",
        "Pipeline",
        "KnowledgeBase",
        "Transformation",
        "Integration",
    }
    if type_name in _DIRECT_IMPORT_TYPES:
        return type_name
    result = []
    token = ""
    for ch in type_name:
        if ch in ",[] ":
            if token:
                if token in _DIRECT_IMPORT_TYPES:
                    result.append(token)
                else:
                    result.append(f"vst.{token}")
                token = ""
            result.append(ch)
        else:
            token += ch
    if token:
        if token in _DIRECT_IMPORT_TYPES:
            result.append(token)
        else:
            result.append(f"vst.{token}")
    return "".join(result)


def _assert_annotations_match_runtime(stub_props, runtime, label='', skip_complete=True):
    """Verify each stub annotation matches get_output_type_name()."""
    prefix = f'[{label}] ' if label else ''
    for output_name, semantic_type in runtime.items():
        if output_name not in stub_props:
            continue
        if skip_complete and output_name == 'complete':
            continue
        expected_annotation = _qualify_type(get_output_type_name(semantic_type))
        actual_annotation = stub_props[output_name]
        assert actual_annotation == expected_annotation, (
            f'{prefix}Annotation mismatch for {output_name}: '
            f'stub has {actual_annotation!r}, '
            f'expected {expected_annotation!r} '
            f'(from semantic_type={semantic_type!r})'
        )


def _stub_has_getattr(stub_path: Path, class_name: str) -> bool:
    tree = ast.parse(stub_path.read_text())
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef) and node.name == class_name:
            for item in node.body:
                if isinstance(item, ast.FunctionDef) and item.name == '__getattr__':
                    return True
    return False


# ---------------------------------------------------------------------------
# 1. Generated code syntax
# ---------------------------------------------------------------------------


class TestGeneratedCodeValidity:
    def test_all_py_files_parse(self, nodes_dir):
        errors = []
        for py_file in sorted(nodes_dir.glob('_*.py')):
            try:
                ast.parse(py_file.read_text())
            except SyntaxError as e:
                errors.append(f'{py_file.name}: {e}')
        assert not errors, 'Syntax errors:\n' + '\n'.join(errors)

    def test_all_pyi_files_parse(self, nodes_dir):
        errors = []
        for pyi_file in sorted(nodes_dir.glob('_*.pyi')):
            try:
                ast.parse(pyi_file.read_text())
            except SyntaxError as e:
                errors.append(f'{pyi_file.name}: {e}')
        assert not errors, 'Syntax errors:\n' + '\n'.join(errors)


# ---------------------------------------------------------------------------
# 1b. Init sync -- __init__.py and __init__.pyi export the same classes
# ---------------------------------------------------------------------------


class TestInitSync:
    def _extract_py_exports(self, nodes_dir):
        """Extract class names exported by __init__.py."""
        init_py = nodes_dir / '__init__.py'
        tree = ast.parse(init_py.read_text())
        names = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                for alias in node.names:
                    real_name = alias.asname or alias.name
                    if real_name.endswith('Node'):
                        names.add(real_name)
        return names

    def _extract_pyi_exports(self, nodes_dir):
        """Extract class names exported by __init__.pyi."""
        init_pyi = nodes_dir / '__init__.pyi'
        if not init_pyi.exists():
            return set()
        tree = ast.parse(init_pyi.read_text())
        names = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                for alias in node.names:
                    real_name = alias.asname or alias.name
                    if real_name.endswith('Node'):
                        names.add(real_name)
        return names

    def test_pyi_covers_all_py_exports(self, nodes_dir):
        py_names = self._extract_py_exports(nodes_dir)
        pyi_names = self._extract_pyi_exports(nodes_dir)
        missing = py_names - pyi_names
        assert (
            not missing
        ), f'Nodes in __init__.py but missing from __init__.pyi: {missing}'

    def test_no_phantom_pyi_exports(self, nodes_dir):
        py_names = self._extract_py_exports(nodes_dir)
        pyi_names = self._extract_pyi_exports(nodes_dir)
        phantom = pyi_names - py_names
        assert (
            not phantom
        ), f'Nodes in __init__.pyi but missing from __init__.py: {phantom}'


# ---------------------------------------------------------------------------
# 1c. Generation completeness
# ---------------------------------------------------------------------------


class TestGenerationCompleteness:
    def test_py_and_pyi_counts_match(self, nodes_dir):
        py = {f.stem for f in nodes_dir.glob('_*.py') if f.stem != '__init__'}
        pyi = {f.stem for f in nodes_dir.glob('_*.pyi') if f.stem != '__init__'}
        assert py == pyi, f'Mismatch: py-only={py - pyi}, pyi-only={pyi - py}'

    def test_init_pyi_exists(self, nodes_dir):
        assert (nodes_dir / '__init__.pyi').exists(), '__init__.pyi not generated'


# ---------------------------------------------------------------------------
# 2. Bidirectional stub-to-runtime matching + type annotations
#    Representative nodes: one boolean-overloaded, one enum-overloaded,
#    one integration action-overloaded.
# ---------------------------------------------------------------------------


class TestLlmStubAccuracy:
    def test_stream_false_outputs_match(self, nodes_dir):
        stub_path = nodes_dir / '_llm.pyi'
        stub_props = _parse_stub_return_class(stub_path, '_LlmNode_StreamFalse')
        assert stub_props is not None
        llm = LlmNode(id='test', provider='openai', model='gpt-4', stream=False)
        runtime = _get_runtime_output_types(llm)
        _assert_stub_matches_runtime(stub_props, runtime, 'LlmNode stream=False')
        _assert_annotations_match_runtime(stub_props, runtime, 'LlmNode stream=False')

    def test_stream_true_outputs_match(self, nodes_dir):
        stub_path = nodes_dir / '_llm.pyi'
        stub_props = _parse_stub_return_class(stub_path, '_LlmNode_StreamTrue')
        assert stub_props is not None
        llm = LlmNode(id='test', provider='openai', model='gpt-4', stream=True)
        runtime = _get_runtime_output_types(llm)
        _assert_stub_matches_runtime(stub_props, runtime, 'LlmNode stream=True')
        _assert_annotations_match_runtime(stub_props, runtime, 'LlmNode stream=True')


class TestInputStubAccuracy:
    @pytest.mark.parametrize(
        'input_type,class_suffix',
        [
            ('string', 'InputTypeString'),
            ('file', 'InputTypeFile'),
            ('image', 'InputTypeImage'),
        ],
    )
    def test_each_type_matches(
        self,
        input_type,
        class_suffix,
        nodes_dir,
    ):
        stub_path = nodes_dir / '_input.pyi'
        class_name = f'_InputNode_{class_suffix}'
        stub_props = _parse_stub_return_class(stub_path, class_name)
        assert stub_props is not None, f'{class_name} not in stub'
        inp = InputNode(
            id='test',
            input_type=input_type,
            use_default_value=False,
        )
        runtime = _get_runtime_output_types(inp)
        _assert_stub_matches_runtime(stub_props, runtime, f'InputNode {input_type}')
        _assert_annotations_match_runtime(stub_props, runtime, f'InputNode {input_type}')


class TestGmailStubAccuracy:
    def test_list_messages_outputs_match(self, nodes_dir):
        stub_path = nodes_dir / '_integration_gmail.pyi'
        stub_props = _parse_stub_return_class(
            stub_path, '_IntegrationGmailNode_ActionListMessages'
        )
        assert stub_props is not None
        node = IntegrationGmailNode(
            id='test',
            action='list_messages',
            integration=INTEGRATION,
            num_messages=10,
        )
        runtime = _get_runtime_output_types(node)
        _assert_stub_matches_runtime(stub_props, runtime, 'Gmail list_messages')
        _assert_annotations_match_runtime(stub_props, runtime, 'Gmail list_messages')

    def test_read_message_outputs_match(self, nodes_dir):
        stub_path = nodes_dir / '_integration_gmail.pyi'
        stub_props = _parse_stub_return_class(
            stub_path, '_IntegrationGmailNode_ActionReadMessage'
        )
        assert stub_props is not None
        node = IntegrationGmailNode(
            id='test',
            action='read_message',
            integration=INTEGRATION,
            format='full',
            message_id='',
        )
        runtime = _get_runtime_output_types(node)
        # 'from' is a Python keyword so the stub renames it to 'from_'.
        keyword_renames = {'from': 'from_'}
        normalized_runtime = {keyword_renames.get(k, k): v for k, v in runtime.items()}
        _assert_stub_matches_runtime(
            stub_props, normalized_runtime, 'Gmail read_message'
        )
        _assert_annotations_match_runtime(
            stub_props, normalized_runtime, 'Gmail read_message'
        )


class TestKnowledgeBaseStubAccuracy:
    """Representative KnowledgeBase stub tests."""

    def _cls(self, *parts):
        return '_KnowledgeBaseNode_' + '_'.join(parts)

    def test_chunks_no_format_no_stream_runtime_subset(self, nodes_dir):
        cls = self._cls(
            'DoAdvancedQaFalse',
            'FormatContextForLlmFalse',
            'RetrievalUnitChunks',
            'StreamResponseFalse',
        )
        stub_path = nodes_dir / '_knowledge_base.pyi'
        stub_props = _parse_stub_return_class(stub_path, cls)
        node = KnowledgeBaseNode(
            id='test',
            knowledge_base='kb',
            query='q',
            do_advanced_qa=False,
            format_context_for_llm=False,
            retrieval_unit='chunks',
            stream_response=False,
        )
        runtime = _get_runtime_output_types(node)
        missing = set(runtime) - set(stub_props)
        assert not missing, f'Runtime outputs missing from stub: {missing}'
        _assert_annotations_match_runtime(
            stub_props, runtime, 'KB chunks/noFmt/noStream'
        )

    def test_retrieval_unit_changes_output_name(self):
        from vectorshift.pipeline.config_objects import RetrievalConfig

        chunks = KnowledgeBaseNode(
            id='t1',
            knowledge_base='kb',
            query='q',
            do_advanced_qa=False,
            retrieval=RetrievalConfig(unit='chunks'),
        )
        docs = KnowledgeBaseNode(
            id='t2',
            knowledge_base='kb',
            query='q',
            do_advanced_qa=False,
            retrieval=RetrievalConfig(unit='documents'),
        )
        pages = KnowledgeBaseNode(
            id='t3',
            knowledge_base='kb',
            query='q',
            do_advanced_qa=False,
            retrieval=RetrievalConfig(unit='pages'),
        )
        assert 'chunks' in chunks.outputs
        assert 'documents' in docs.outputs
        assert 'pages' in pages.outputs
        assert 'documents' not in chunks.outputs
        assert 'chunks' not in docs.outputs


# ---------------------------------------------------------------------------
# 2b. Verify 'complete' has a typed annotation in stubs
# ---------------------------------------------------------------------------


class TestCompleteAnnotation:
    @pytest.mark.parametrize(
        'stub_file,class_name',
        [
            ('_time.pyi', 'TimeNode'),
            ('_llm.pyi', '_LlmNode_StreamFalse'),
        ],
    )
    def test_complete_typed_as_pipeline_path(
        self,
        stub_file,
        class_name,
        nodes_dir,
    ):
        stub_path = nodes_dir / stub_file
        stub_props = _parse_stub_return_class(stub_path, class_name)
        assert stub_props is not None, f'{class_name} not found'
        assert stub_props.get('complete') == 'vst.Path', (
            f'{class_name}.complete should be vst.Path, '
            f'got {stub_props.get("complete")!r}'
        )


# ---------------------------------------------------------------------------
# 3. Overload structure
# ---------------------------------------------------------------------------


class TestOverloadStructure:
    def test_time_no_overloads(self, nodes_dir):
        stub_content = (nodes_dir / '_time.pyi').read_text()
        assert '@overload' not in stub_content

    def test_llm_has_stream_overloads(self, nodes_dir):
        stub_content = (nodes_dir / '_llm.pyi').read_text()
        assert '@overload' in stub_content
        has_true = (
            'stream: Literal[True]' in stub_content
            or 'stream: Literal[true]' in stub_content
        )
        has_false = (
            'stream: Literal[False]' in stub_content
            or 'stream: Literal[false]' in stub_content
        )
        assert has_true
        assert has_false

    def test_gmail_has_action_overloads(self, nodes_dir):
        stub_content = (nodes_dir / '_integration_gmail.pyi').read_text()
        assert '@overload' in stub_content
        assert 'action: Literal[' in stub_content


# ---------------------------------------------------------------------------
# 4. Dynamic node stubs have __getattr__
# ---------------------------------------------------------------------------


class TestDynamicNodeStubs:
    @pytest.mark.parametrize(
        'stub_file,class_name',
        [
            ('_transformation.pyi', 'TransformationNode'),
            ('_condition.pyi', 'ConditionNode'),
            ('_csv_reader.pyi', 'CsvReaderNode'),
        ],
    )
    def test_has_getattr(
        self,
        stub_file,
        class_name,
        nodes_dir,
    ):
        stub_path = nodes_dir / stub_file
        assert _stub_has_getattr(
            stub_path, class_name
        ), f'{class_name} stub missing __getattr__'

    def test_transformation_only_complete_without_ref(self):
        node = TransformationNode(id='tfm')
        assert 'complete' in node.outputs
        with pytest.raises(AttributeError):
            _ = node.nonexistent_field

    def test_code_execution_dynamic_output_works(self):
        node = CodeExecutionNode(
            id='ce',
            code='',
            processed_outputs={'result': 'string'},
        )
        assert '{{ ce.result }}' == node.result


# ---------------------------------------------------------------------------
# 5. LLM dropdown Literals in stubs
# ---------------------------------------------------------------------------


class TestLlmDropdownLiterals:
    """Verify LLM dropdown options appear as Literal types, not plain str."""

    def _get_all_overload_params(self, stub_path, class_name):
        """Get param annotations from all @overload __new__/__init__ methods."""
        tree = ast.parse(stub_path.read_text())
        results = []
        for node in ast.iter_child_nodes(tree):
            if isinstance(node, ast.ClassDef) and node.name == class_name:
                for item in node.body:
                    if isinstance(item, ast.FunctionDef) and item.name in (
                        '__init__',
                        '__new__',
                    ):
                        is_overload = any(
                            (isinstance(d, ast.Name) and d.id == 'overload')
                            or (isinstance(d, ast.Attribute) and d.attr == 'overload')
                            for d in item.decorator_list
                        )
                        if is_overload:
                            params = {}
                            for arg in item.args.args + item.args.kwonlyargs:
                                if arg.arg in ('self', 'cls'):
                                    continue
                                if arg.annotation:
                                    params[arg.arg] = ast.unparse(arg.annotation)
                            results.append(params)
        return results

    def test_llm_provider_has_literal(self, nodes_dir):
        stub_path = nodes_dir / '_llm.pyi'
        overloads = self._get_all_overload_params(stub_path, 'LlmNode')
        assert len(overloads) > 0, 'LlmNode should have overloads'
        has_literal_provider = any(
            'Literal' in params.get('provider', '') for params in overloads
        )
        assert (
            has_literal_provider
        ), 'At least one LlmNode overload should have provider as Literal'


class TestIntegrationActionLiterals:
    """Verify integration node stubs have action as Literal type."""

    def test_gmail_action_literal(self, nodes_dir):
        stub_content = (nodes_dir / '_integration_gmail.pyi').read_text()
        assert (
            "action: Literal[" in stub_content
        ), 'Gmail stub should have action as Literal type'
        assert "'send_email'" in stub_content
        assert "'read_message'" in stub_content
        assert "'list_messages'" in stub_content


# ---------------------------------------------------------------------------
# 6. Required field enforcement in stubs
# ---------------------------------------------------------------------------


class TestRequiredFieldsInStubs:
    """Verify required fields are non-optional in stubs."""

    def test_table_read_columns_required(self, nodes_dir):
        """dataframe, column_name, column_type should be required."""
        stub_path = nodes_dir / '_table_read_columns.pyi'
        stub_content = stub_path.read_text()
        assert 'dataframe' in stub_content
        assert 'column_name' in stub_content
        assert 'column_type' in stub_content
