"""Tests for auto-inferred batchModeConfig in canvas_metadata.

Verifies that:
- _compute_batch_mode_config returns True for list inputs, False for scalars
- _compute_batch_mode_config returns {} for non-batch nodes
- _prepare_pipeline_data merges batchModeConfig into canvas_metadata for batch nodes
- _prepare_pipeline_data does NOT add batchModeConfig for normal-mode nodes
- batchModeConfig field exists on NodeCanvasMetadata model
- Round-trip: batchModeConfig survives model_dump / parse
"""

import pytest
from typing import Any, cast

from vectorshift.pipeline.graph import NodeCanvasMetadata, NodeCoordinates
from vectorshift.pipeline.node import Node
from vectorshift.pipeline.nodes import (
    InputNode,
    LlmNode,
    OutputNode,
)
from vectorshift.pipeline.object import Pipeline


class NestedVecBatchNode(Node):
    _COMMON_INPUTS = [{"field": "documents", "type": "vec<vec<string>>", "value": None}]
    _COMMON_OUTPUTS = []
    _CONFIGS = {}
    _PARAMS = []
    _list_mode_fields = ["documents"]

    def __init__(self, id="nested", execution_mode="batch"):
        cast(Any, Node.__init__)(
            self,
            "nested_vec_batch",
            {},
            id=id,
            execution_mode=execution_mode,
        )


# ---------------------------------------------------------------------------
# _compute_batch_mode_config
# ---------------------------------------------------------------------------


class TestComputeBatchModeConfig:
    def test_list_input_marked_true(self):
        llm = LlmNode(
            id="llm",
            provider="openai",
            model="gpt-4",
            stream=False,
            execution_mode="batch",
        )
        llm.update_inputs(prompt=["Hello", "World"])
        config = Pipeline._compute_batch_mode_config(llm)
        assert config["prompt"] is True

    def test_scalar_input_marked_false(self):
        llm = LlmNode(
            id="llm",
            provider="openai",
            model="gpt-4",
            stream=False,
            execution_mode="batch",
        )
        config = Pipeline._compute_batch_mode_config(llm)
        # model is a scalar string param set via constructor
        assert config.get("model") is False or "model" not in config
        # prompt defaults to a scalar
        assert config.get("prompt") is False

    def test_mixed_inputs(self):
        llm = LlmNode(
            id="llm",
            provider="openai",
            model="gpt-4",
            stream=False,
            execution_mode="batch",
        )
        llm.update_inputs(prompt=["a", "b", "c"])
        config = Pipeline._compute_batch_mode_config(llm)
        # LLM's list_mode_fields are: prompt, system
        assert config["prompt"] is True
        assert config["system"] is False
        # Only list_mode_fields should appear in the config
        assert set(config.keys()) == {"prompt", "system"}

    def test_normal_mode_returns_empty(self):
        llm = LlmNode(
            id="llm",
            provider="openai",
            model="gpt-4",
            stream=False,
            execution_mode="normal",
        )
        config = Pipeline._compute_batch_mode_config(llm)
        assert config == {}

    def test_no_execution_mode_returns_empty(self):
        llm = LlmNode(
            id="llm",
            provider="openai",
            model="gpt-4",
            stream=False,
        )
        config = Pipeline._compute_batch_mode_config(llm)
        assert config == {}

    def test_empty_list_counts_as_list(self):
        """An empty list should still be marked as vectorized."""
        llm = LlmNode(
            id="llm",
            provider="openai",
            model="gpt-4",
            stream=False,
            execution_mode="batch",
        )
        llm.update_inputs(prompt=[])
        config = Pipeline._compute_batch_mode_config(llm)
        assert config["prompt"] is True

    def test_nested_vec_shared_value_marked_false(self):
        node = NestedVecBatchNode()
        node.update_inputs(documents=[["a", "b"], ["c"]])
        config = Pipeline._compute_batch_mode_config(node)
        assert config["documents"] is False

    def test_nested_vec_batched_value_marked_true(self):
        node = NestedVecBatchNode()
        node.update_inputs(documents=[[["a", "b"]], [["c"]]])
        config = Pipeline._compute_batch_mode_config(node)
        assert config["documents"] is True


# ---------------------------------------------------------------------------
# _prepare_pipeline_data integration
# ---------------------------------------------------------------------------


class TestPrepareDataBatchModeConfig:
    def _make_batch_pipeline(self):
        """Build a simple pipeline with a batch-mode LLM."""
        pipeline = Pipeline()
        pipeline.add(name="inp", id="inp").input(
            input_type="string", use_default_value=False
        )
        llm = pipeline.add_batch(name="llm", id="llm").llm(
            provider="openai",
            model="gpt-4",
            stream=False,
        )
        llm.update_inputs(prompt=["Hello", "World"])
        pipeline.add(name="out", id="out").output(
            output_type="string", value=llm.response
        )
        return pipeline

    def _make_normal_pipeline(self):
        """Build a simple pipeline with normal-mode nodes only."""
        pipeline = Pipeline()
        inp = pipeline.add(name="inp", id="inp").input(
            input_type="string", use_default_value=False
        )
        llm = pipeline.add(name="llm", id="llm").llm(
            provider="openai",
            model="gpt-4",
            stream=False,
            prompt=inp.text,
        )
        pipeline.add(name="out", id="out").output(
            output_type="string", value=llm.response
        )
        return pipeline

    def test_batch_node_has_batch_mode_config(self):
        pipeline = self._make_batch_pipeline()
        data = pipeline._prepare_pipeline_data()
        llm_metadata = data["canvas_metadata"]["nodes"]["llm"]
        assert "batchModeConfig" in llm_metadata
        assert llm_metadata["batchModeConfig"]["prompt"] is True

    def test_normal_node_no_batch_mode_config(self):
        pipeline = self._make_normal_pipeline()
        data = pipeline._prepare_pipeline_data()
        for node_id, metadata in data["canvas_metadata"]["nodes"].items():
            assert (
                "batchModeConfig" not in metadata
                or metadata.get("batchModeConfig") == {}
            )

    def test_input_output_nodes_no_batch_config(self):
        """Input and output nodes should never get batchModeConfig."""
        pipeline = self._make_batch_pipeline()
        data = pipeline._prepare_pipeline_data()
        inp_meta = data["canvas_metadata"]["nodes"]["inp"]
        out_meta = data["canvas_metadata"]["nodes"]["out"]
        assert "batchModeConfig" not in inp_meta or inp_meta.get("batchModeConfig") == {}
        assert "batchModeConfig" not in out_meta or out_meta.get("batchModeConfig") == {}

    def test_batch_config_values_match_input_types(self):
        """List inputs → True, scalar inputs → False."""
        pipeline = self._make_batch_pipeline()
        data = pipeline._prepare_pipeline_data()
        batch_config = data["canvas_metadata"]["nodes"]["llm"]["batchModeConfig"]
        assert batch_config["prompt"] is True
        assert batch_config["system"] is False
        # Only list_mode_fields should appear in the config
        assert set(batch_config.keys()) == {"prompt", "system"}

    def test_execution_mode_set_in_node_data(self):
        """Verify execution_mode is 'batch' in the node data."""
        pipeline = self._make_batch_pipeline()
        data = pipeline._prepare_pipeline_data()
        assert data["nodes"]["llm"]["execution_mode"] == "batch"


# ---------------------------------------------------------------------------
# NodeCanvasMetadata model
# ---------------------------------------------------------------------------


class TestNodeCanvasMetadataModel:
    def test_default_empty(self):
        meta = NodeCanvasMetadata(
            advancedOutputs=False,
            position=NodeCoordinates(x=0, y=0),
            zIndex=0,
            sidePanelOpen=True,
            input_mode="inputs",
        )
        assert meta.batchModeConfig == {}

    def test_with_values(self):
        meta = NodeCanvasMetadata(
            advancedOutputs=False,
            position=NodeCoordinates(x=0, y=0),
            zIndex=0,
            sidePanelOpen=True,
            input_mode="inputs",
            batchModeConfig={"prompt": True, "model": False},
        )
        assert meta.batchModeConfig["prompt"] is True
        assert meta.batchModeConfig["model"] is False

    def test_round_trip(self):
        """model_dump → parse should preserve batchModeConfig."""
        meta = NodeCanvasMetadata(
            advancedOutputs=False,
            position=NodeCoordinates(x=0, y=0),
            zIndex=0,
            sidePanelOpen=True,
            input_mode="inputs",
            batchModeConfig={"text": True, "temperature": False},
        )
        dumped = meta.model_dump()
        restored = NodeCanvasMetadata(**dumped)
        assert restored.batchModeConfig == {"text": True, "temperature": False}

    def test_model_dump_includes_field(self):
        meta = NodeCanvasMetadata(
            advancedOutputs=False,
            position=NodeCoordinates(x=0, y=0),
            zIndex=0,
            sidePanelOpen=True,
            input_mode="inputs",
            batchModeConfig={"a": True},
        )
        d = meta.model_dump()
        assert "batchModeConfig" in d
        assert d["batchModeConfig"] == {"a": True}
