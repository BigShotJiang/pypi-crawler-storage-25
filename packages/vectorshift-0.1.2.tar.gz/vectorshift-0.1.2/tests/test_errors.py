"""Tests for the VectorShift SDK error hierarchy."""

import asyncio
import json
import pytest
from unittest.mock import patch, MagicMock, AsyncMock
import requests as req_lib
import aiohttp

from vectorshift.request import (
    VectorShiftError,
    VectorShiftAPIError,
    APIStatusError,
    BadRequestError,
    AuthenticationError,
    PermissionDeniedError,
    NotFoundError,
    UnprocessableEntityError,
    RateLimitError,
    InternalServerError,
    APIConnectionError,
    APITimeoutError,
    _make_status_error,
    RequestClient,
    AsyncRequestClient,
)


# ---------------------------------------------------------------------------
# Hierarchy / isinstance tests
# ---------------------------------------------------------------------------


class TestErrorHierarchy:
    def test_vectorshift_error_is_exception(self):
        assert issubclass(VectorShiftError, Exception)

    def test_api_error_is_vectorshift_error(self):
        assert issubclass(VectorShiftAPIError, VectorShiftError)

    def test_api_status_error_is_same_as_api_error(self):
        assert APIStatusError is VectorShiftAPIError

    @pytest.mark.parametrize(
        "cls",
        [
            BadRequestError,
            AuthenticationError,
            PermissionDeniedError,
            NotFoundError,
            UnprocessableEntityError,
            RateLimitError,
            InternalServerError,
        ],
    )
    def test_http_subclasses_inherit_api_error(self, cls):
        assert issubclass(cls, VectorShiftAPIError)
        assert issubclass(cls, VectorShiftError)
        assert issubclass(cls, Exception)

    def test_connection_error_is_vectorshift_error(self):
        assert issubclass(APIConnectionError, VectorShiftError)

    def test_connection_error_is_not_api_error(self):
        assert not issubclass(APIConnectionError, VectorShiftAPIError)

    def test_timeout_error_is_connection_error(self):
        assert issubclass(APITimeoutError, APIConnectionError)
        assert issubclass(APITimeoutError, VectorShiftError)


# ---------------------------------------------------------------------------
# Factory tests
# ---------------------------------------------------------------------------


class TestMakeStatusError:
    @pytest.mark.parametrize(
        "status_code,expected_cls",
        [
            (400, BadRequestError),
            (401, AuthenticationError),
            (403, PermissionDeniedError),
            (404, NotFoundError),
            (422, UnprocessableEntityError),
            (429, RateLimitError),
            (500, InternalServerError),
            (502, InternalServerError),
            (503, InternalServerError),
        ],
    )
    def test_maps_status_to_correct_class(self, status_code, expected_cls):
        err = _make_status_error(status_code, "GET", "/test", '{"error":"oops"}')
        assert type(err) is expected_cls

    def test_unknown_4xx_falls_back_to_base(self):
        err = _make_status_error(418, "GET", "/test", '{"error":"teapot"}')
        assert type(err) is VectorShiftAPIError

    def test_factory_result_is_catchable_as_api_error(self):
        err = _make_status_error(401, "POST", "/auth", '{"error":"bad key"}')
        with pytest.raises(VectorShiftAPIError):
            raise err


# ---------------------------------------------------------------------------
# Backwards compatibility tests
# ---------------------------------------------------------------------------


class TestBackwardsCompatibility:
    def _make(self, status_code=400):
        return _make_status_error(
            status_code=status_code,
            method="POST",
            endpoint="/pipeline",
            raw_response='{"error":"something went wrong"}',
        )

    def test_except_vectorshift_api_error_catches_subclass(self):
        err = self._make(401)
        assert isinstance(err, AuthenticationError)
        with pytest.raises(VectorShiftAPIError):
            raise err

    def test_attributes_preserved(self):
        err = self._make(404)
        assert err.status_code == 404
        assert err.method == "POST"
        assert err.endpoint == "/pipeline"
        assert err.raw_response == '{"error":"something went wrong"}'
        assert err.error_message == "something went wrong"

    def test_str_format_preserved(self):
        err = self._make(401)
        s = str(err)
        assert "Unauthorized" in s
        assert "401" in s
        assert "POST /pipeline" in s
        assert "Hint:" in s

    def test_500_hint(self):
        err = self._make(500)
        assert "server-side error" in str(err)

    def test_404_hint(self):
        err = self._make(404)
        assert "resource ID exists" in str(err)


# ---------------------------------------------------------------------------
# Error message parsing tests
# ---------------------------------------------------------------------------


class TestErrorParsing:
    def test_json_error_field(self):
        err = _make_status_error(400, "GET", "/x", '{"error":"bad input"}')
        assert err.error_message == "bad input"

    def test_json_detail_field(self):
        err = _make_status_error(400, "GET", "/x", '{"detail":"not allowed"}')
        assert err.error_message == "not allowed"

    def test_json_errors_list(self):
        err = _make_status_error(400, "GET", "/x", '{"errors":["a","b"]}')
        assert err.error_message == "a; b"

    def test_plain_text(self):
        err = _make_status_error(400, "GET", "/x", "plain text error")
        assert err.error_message == "plain text error"

    def test_empty_string(self):
        err = _make_status_error(400, "GET", "/x", "")
        assert err.error_message == ""


# ---------------------------------------------------------------------------
# Helpers for forging HTTP responses
# ---------------------------------------------------------------------------


def _sync_client():
    client = RequestClient()
    client.api_key = "test-key"
    return client


def _async_client():
    client = AsyncRequestClient()
    client.api_key = "test-key"
    return client


def _mock_sync_response(status_code: int, body: str):
    """Create a mock requests.Response with the given status and body."""
    resp = MagicMock()
    resp.ok = 200 <= status_code < 400
    resp.status_code = status_code
    resp.text = body
    resp.json.return_value = json.loads(body) if body.startswith("{") else body
    resp.iter_lines.return_value = iter([])
    return resp


class _FakeAsyncContextManager:
    """A non-coroutine async context manager wrapping a mock response."""

    def __init__(self, resp):
        self._resp = resp

    async def __aenter__(self):
        return self._resp

    async def __aexit__(self, *args):
        return False


def _mock_async_response(status_code: int, body: str):
    """Create a mock aiohttp response wrapped in an async context manager."""
    resp = MagicMock()
    resp.ok = 200 <= status_code < 400
    resp.status = status_code
    resp.text = AsyncMock(return_value=body)
    resp.json = AsyncMock(
        return_value=json.loads(body) if body.startswith("{") else body
    )
    return _FakeAsyncContextManager(resp)


# ---------------------------------------------------------------------------
# Sync client: HTTP status → correct error subclass
# ---------------------------------------------------------------------------

# Response bodies traced from the actual Go API source code.
# Each entry includes the source file and line number where the response is produced.
#
# The Go API uses three distinct response formats:
#   FORMAT 1: {"error": "message"}                      — auth middleware, user/agent handlers
#   FORMAT 2: {"status": "failed", "error": "message"}  — pipeline, chatbot, form, KB, search, voicebot, transformation, update handlers
#   FORMAT 3: {"detail": {"message": "message"}}        — org handler only
#   FORMAT 4: plain text (SendString)                    — MCP handler only
#
# Engine errors (from protobuf TaskResult.error, ExecutorTaskFailure.error_message, etc.)
# are surfaced as the "error" string in FORMAT 2 via result.GetError().

_API_RESPONSES = [
    # (status_code, response_body, expected_class, description)
    # ── FORMAT 2: {"status": "failed", "error": ...} ────────────────────────
    # pipeline_handler.go:56-59 — missing required ID
    (
        400,
        '{"status":"failed","error":"Pipeline ID is required"}',
        BadRequestError,
        "pipeline missing id",
    ),
    # pipeline_handler.go:76-79 — invalid JSON body
    (
        400,
        '{"status":"failed","error":"Invalid JSON body"}',
        BadRequestError,
        "pipeline invalid json",
    ),
    # pipeline_handler.go:115-118 — invalid version string
    (
        400,
        '{"status":"failed","error":"Invalid pipeline version: invalid format"}',
        BadRequestError,
        "pipeline invalid version",
    ),
    # chatbot_handler.go:39-42 — missing chatbot ID
    (
        400,
        '{"status":"failed","error":"Chatbot ID is required"}',
        BadRequestError,
        "chatbot missing id",
    ),
    # chatbot_handler.go:90-93 — invalid JSON body
    (
        400,
        '{"status":"failed","error":"Invalid JSON body"}',
        BadRequestError,
        "chatbot invalid json",
    ),
    # chatbot_handler.go:118-121 — invalid form data
    (
        400,
        '{"status":"failed","error":"Invalid form data"}',
        BadRequestError,
        "chatbot invalid form",
    ),
    # chatbot_handler.go:163-166 — unsupported content type
    (
        400,
        '{"status":"failed","error":"Unsupported content type. Use application/json or multipart/form-data"}',
        BadRequestError,
        "chatbot unsupported content type",
    ),
    # chatbot_handler.go:174-177 — missing input name
    (
        400,
        '{"status":"failed","error":"Input name not found"}',
        BadRequestError,
        "chatbot missing input",
    ),
    # knowledge_base_handler.go:37-39 — missing KB ID
    (
        400,
        '{"status":"failed","error":"Knowledge base ID is required"}',
        BadRequestError,
        "kb missing id",
    ),
    # knowledge_base_handler.go:70-72 — missing document IDs
    (
        400,
        '{"status":"failed","error":"Document IDs are required"}',
        BadRequestError,
        "kb missing doc ids",
    ),
    # search_handler.go:37-40 — missing search ID
    (
        400,
        '{"status":"failed","error":"Search ID is required"}',
        BadRequestError,
        "search missing id",
    ),
    # voicebot_handler.go:38-41 — missing voicebot ID
    (
        400,
        '{"status":"failed","error":"Voicebot ID is required"}',
        BadRequestError,
        "voicebot missing id",
    ),
    # form_handler.go:37-40 — missing form ID
    (
        400,
        '{"status":"failed","error":"Form ID is required"}',
        BadRequestError,
        "form missing id",
    ),
    # transformation_handler.go:37-40 — missing transformation ID
    (
        400,
        '{"status":"failed","error":"Transformation ID is required"}',
        BadRequestError,
        "transformation missing id",
    ),
    # ── Engine errors surfaced via result.GetError() (FORMAT 2, 500) ─────────
    # chatbot_handler.go:62-65 — Kafka send failure (err.Error() from KafkaClient)
    (
        500,
        '{"status":"failed","error":"kafka: client has run out of available brokers"}',
        InternalServerError,
        "engine kafka broker failure",
    ),
    # chatbot_handler.go:72-75 — bson unmarshal failure
    (
        500,
        '{"status":"failed","error":"Failed to unmarshal document: invalid BSON"}',
        InternalServerError,
        "engine unmarshal failure",
    ),
    # agent_handler.go:88-91 — agent Kafka send failure
    (
        500,
        '{"status":"failed","error":"Failed to run agent: context deadline exceeded"}',
        InternalServerError,
        "engine agent timeout",
    ),
    # agent_handler.go:97-100 — channel closed without result (engine didn't respond)
    (
        500,
        '{"status":"failed","error":"Failed to receive agent result"}',
        InternalServerError,
        "engine channel closed",
    ),
    # knowledge_base_handler.go:97-100 — TaskResult.status=Failure, error from engine
    # (engine sets TaskResult.error via protos/result.proto:67 oneof string error)
    (
        500,
        '{"status":"failed","error":"document loading failed: unsupported file type .xyz"}',
        InternalServerError,
        "engine task failure",
    ),
    # knowledge_base_handler.go:655 — delete result.GetError() from engine
    # (engine sets delete_pb.CompleteDeleteResult.error via protos/delete.proto:52)
    (
        500,
        '{"status":"failed","error":"failed to delete knowledge base: document still referenced"}',
        InternalServerError,
        "engine delete failure",
    ),
    # search_handler.go:149-152 — TaskResult status != Success, engine error
    (
        500,
        '{"status":"failed","error":"search execution failed: embedding service unavailable"}',
        InternalServerError,
        "engine search failure",
    ),
    # update_handler.go:170-173 — merge result failure from engine
    # (engine sets result.proto TaskResult.error on merge failure)
    (
        500,
        '{"status":"failed","error":"merge failed: conflicting node definitions"}',
        InternalServerError,
        "engine merge failure",
    ),
    # search_handler.go:460-463 — create result error from engine
    # (engine sets create_pb.TaskCreateResult.error via protos/create.proto:103)
    (
        500,
        '{"status":"failed","error":"failed to create search: invalid configuration"}',
        InternalServerError,
        "engine create failure",
    ),
    # stream.go:241-249 — SSE error response (same JSON format, sent over SSE)
    (
        500,
        '{"status":"failed","error":"pipeline execution timed out after 300s"}',
        InternalServerError,
        "engine sse pipeline timeout",
    ),
    # ── FORMAT 1: {"error": ...} — auth middleware (main.go) ─────────────────
    # main.go:186-188 — missing authorization header
    (
        401,
        '{"error":"Missing authorization header"}',
        AuthenticationError,
        "auth missing header",
    ),
    # main.go:193-195 — malformed Bearer token
    (
        401,
        '{"error":"Invalid authorization header format"}',
        AuthenticationError,
        "auth bad format",
    ),
    # main.go:212-214 — API key validation failed via Kafka
    (
        401,
        '{"error":"Invalid API key: verification failed"}',
        AuthenticationError,
        "auth invalid key",
    ),
    # main.go:228-230 — cached API key failed to deserialize from Redis
    (
        401,
        '{"error":"Invalid API key: failed to parse cached key"}',
        AuthenticationError,
        "auth cached key invalid",
    ),
    # main.go:234-236 — MCP server key used on non-MCP endpoint
    (
        401,
        '{"error":"MCP server API keys can only be used with MCP server endpoints"}',
        AuthenticationError,
        "auth mcp key restriction",
    ),
    # ── FORMAT 1: {"error": ...} — agent handler ────────────────────────────
    # agent_handler.go:36 — missing agent ID
    (400, '{"error":"Agent ID is required"}', BadRequestError, "agent missing id"),
    # agent_handler.go:47 — invalid request body
    (400, '{"error":"Invalid request body"}', BadRequestError, "agent invalid body"),
    # ── FORMAT 1: {"error": ...} — user handler ─────────────────────────────
    # user_handler.go:27-29 — missing access token
    (
        400,
        '{"error":"Access token not found in context"}',
        BadRequestError,
        "user missing token",
    ),
    # ── CORS middleware (main.go:120-128) ────────────────────────────────────
    (
        403,
        '{"error":"Origin not allowed"}',
        PermissionDeniedError,
        "cors origin blocked",
    ),
    # ── FORMAT 3: {"detail": {"message": ...}} — org handler ────────────────
    # org_handler.go:35-39 — missing access token
    (
        400,
        '{"detail":{"message":"Access token not found in context"}}',
        BadRequestError,
        "org missing token",
    ),
    # org_handler.go:45-49 — invalid request body
    (
        400,
        '{"detail":{"message":"Invalid request body: unexpected EOF"}}',
        BadRequestError,
        "org invalid body",
    ),
    # org_handler.go:58-62 — DB failure getting user info
    (
        500,
        '{"detail":{"message":"Failed to get user info: connection refused"}}',
        InternalServerError,
        "org db failure",
    ),
    # org_handler.go:71-75 — DB failure getting subscriptions
    (
        500,
        '{"detail":{"message":"Failed to get owned org subscriptions: timeout"}}',
        InternalServerError,
        "org subscription query failure",
    ),
    # org_handler.go:92-96 — subscription requirement not met
    (
        403,
        '{"detail":{"message":"Cannot create a new organization. No currently owned organizations have a subscription."}}',
        PermissionDeniedError,
        "org no subscription",
    ),
    # ── FORMAT 4: plain text (SendString) — MCP handler ─────────────────────
    # mcp_routes.go:40 — missing MCP server ID
    (
        400,
        "MCP server ID is required in path: /v1/mcp/{mcp-server-id}",
        BadRequestError,
        "mcp plain text missing id",
    ),
    # mcp_routes.go:52 — API key not in context
    (401, "API key not found in context", AuthenticationError, "mcp plain text no key"),
    # mcp_routes.go:57 — wrong API key type
    (
        401,
        "Invalid API key type in context",
        AuthenticationError,
        "mcp plain text bad key type",
    ),
    # mcp_routes.go:73 — server creation failed
    (
        500,
        "Failed to create MCP server",
        InternalServerError,
        "mcp plain text server failure",
    ),
    # ── Unmapped/unusual status codes ────────────────────────────────────────
    (502, '{"error":"Bad Gateway"}', InternalServerError, "502 proxy error"),
    (
        503,
        '{"error":"Service Unavailable"}',
        InternalServerError,
        "503 service unavailable",
    ),
    (429, '{"error":"Rate limit exceeded"}', RateLimitError, "rate limited"),
]


class TestSyncClientHTTPErrors:
    """Forge HTTP responses through the sync RequestClient and verify correct error types."""

    @pytest.mark.parametrize(
        "status_code,body,expected_cls,desc",
        _API_RESPONSES,
        ids=[r[3] for r in _API_RESPONSES],
    )
    @patch("vectorshift.request.requests.request")
    def test_request_raises_correct_subclass(
        self, mock_req, status_code, body, expected_cls, desc
    ):
        mock_req.return_value = _mock_sync_response(status_code, body)
        client = _sync_client()

        with pytest.raises(expected_cls) as exc_info:
            client.request("POST", "/pipeline")

        err = exc_info.value
        assert err.status_code == status_code
        assert err.method == "POST"
        assert err.endpoint == "/pipeline"
        assert err.raw_response == body
        # All subclasses must be catchable as VectorShiftAPIError
        assert isinstance(err, VectorShiftAPIError)

    @pytest.mark.parametrize(
        "status_code,body,expected_cls,desc",
        _API_RESPONSES,
        ids=[r[3] for r in _API_RESPONSES],
    )
    @patch("vectorshift.request.requests.request")
    def test_stream_request_raises_correct_subclass(
        self, mock_req, status_code, body, expected_cls, desc
    ):
        mock_req.return_value = _mock_sync_response(status_code, body)
        client = _sync_client()

        with pytest.raises(expected_cls) as exc_info:
            # Must consume the generator to trigger the error
            list(client.stream_request("POST", "/pipeline/run"))

        assert exc_info.value.status_code == status_code
        assert isinstance(exc_info.value, VectorShiftAPIError)


class TestSyncClientNetworkErrors:
    """Forge network-level failures through the sync RequestClient."""

    @patch("vectorshift.request.requests.request")
    def test_timeout_wraps_to_api_timeout_error(self, mock_req):
        mock_req.side_effect = req_lib.Timeout("connect timed out")
        client = _sync_client()
        with pytest.raises(APITimeoutError) as exc_info:
            client.request("GET", "/pipeline")
        assert "timed out" in str(exc_info.value)
        assert exc_info.value.request_info == {"method": "GET", "endpoint": "/pipeline"}
        assert exc_info.value.__cause__ is not None

    @patch("vectorshift.request.requests.request")
    def test_connection_refused_wraps(self, mock_req):
        mock_req.side_effect = req_lib.ConnectionError("Connection refused")
        client = _sync_client()
        with pytest.raises(APIConnectionError) as exc_info:
            client.request("POST", "/chatbot")
        assert exc_info.value.request_info == {"method": "POST", "endpoint": "/chatbot"}
        assert exc_info.value.__cause__ is not None

    @patch("vectorshift.request.requests.request")
    def test_dns_failure_wraps(self, mock_req):
        mock_req.side_effect = req_lib.ConnectionError(
            "HTTPSConnectionPool: Max retries exceeded (Caused by NameResolutionError)"
        )
        client = _sync_client()
        with pytest.raises(APIConnectionError):
            client.request("GET", "/pipeline")

    @patch("vectorshift.request.requests.request")
    def test_stream_timeout_wraps(self, mock_req):
        mock_req.side_effect = req_lib.Timeout("read timed out")
        client = _sync_client()
        with pytest.raises(APITimeoutError):
            list(client.stream_request("POST", "/pipeline/run"))

    @patch("vectorshift.request.requests.request")
    def test_stream_connection_error_wraps(self, mock_req):
        mock_req.side_effect = req_lib.ConnectionError("reset by peer")
        client = _sync_client()
        with pytest.raises(APIConnectionError):
            list(client.stream_request("POST", "/pipeline/run"))

    @patch("vectorshift.request.requests.request")
    def test_timeout_catchable_as_vectorshift_error(self, mock_req):
        mock_req.side_effect = req_lib.Timeout("timed out")
        client = _sync_client()
        with pytest.raises(VectorShiftError):
            client.request("GET", "/test")

    @patch("vectorshift.request.requests.request")
    def test_timeout_not_catchable_as_api_error(self, mock_req):
        """Network errors must NOT be caught by `except VectorShiftAPIError`."""
        mock_req.side_effect = req_lib.Timeout("timed out")
        client = _sync_client()
        with pytest.raises(APITimeoutError):
            try:
                client.request("GET", "/test")
            except VectorShiftAPIError:
                pytest.fail(
                    "APITimeoutError should NOT be caught by VectorShiftAPIError"
                )


# ---------------------------------------------------------------------------
# Async client: HTTP status → correct error subclass
# ---------------------------------------------------------------------------


def _make_mock_async_session(response_or_exc):
    """Create a mock aiohttp session where .request() returns an async ctx manager or raises."""
    mock_session = MagicMock()
    mock_session.closed = False
    mock_session.close = AsyncMock()
    if isinstance(response_or_exc, BaseException):
        mock_session.request = MagicMock(side_effect=response_or_exc)
    else:
        mock_session.request = MagicMock(return_value=response_or_exc)
    return mock_session


class TestAsyncClientHTTPErrors:
    """Forge HTTP responses through the async client and verify correct error types."""

    @pytest.mark.parametrize(
        "status_code,body,expected_cls,desc",
        _API_RESPONSES,
        ids=[r[3] for r in _API_RESPONSES],
    )
    @pytest.mark.asyncio
    async def test_arequest_raises_correct_subclass(
        self, status_code, body, expected_cls, desc
    ):
        mock_session = _make_mock_async_session(_mock_async_response(status_code, body))

        client = _async_client()
        client._session = mock_session

        with pytest.raises(expected_cls) as exc_info:
            await client.arequest("POST", "/pipeline")

        err = exc_info.value
        assert err.status_code == status_code
        assert err.method == "POST"
        assert err.endpoint == "/pipeline"
        assert err.raw_response == body
        assert isinstance(err, VectorShiftAPIError)


class TestAsyncClientNetworkErrors:
    """Forge network-level failures through the async client."""

    @pytest.mark.asyncio
    async def test_timeout_wraps(self):
        mock_session = _make_mock_async_session(asyncio.TimeoutError())

        client = _async_client()
        client._session = mock_session

        with pytest.raises(APITimeoutError) as exc_info:
            await client.arequest("GET", "/pipeline")
        assert exc_info.value.request_info == {"method": "GET", "endpoint": "/pipeline"}

    @pytest.mark.asyncio
    async def test_connection_error_wraps(self):
        mock_session = _make_mock_async_session(aiohttp.ClientConnectionError("refused"))

        client = _async_client()
        client._session = mock_session

        with pytest.raises(APIConnectionError) as exc_info:
            await client.arequest("POST", "/chatbot")
        assert exc_info.value.request_info == {"method": "POST", "endpoint": "/chatbot"}


# ---------------------------------------------------------------------------
# Error message parsing: realistic Go API response formats
# ---------------------------------------------------------------------------


class TestGoAPIResponseParsing:
    """Verify _parse_error handles every distinct response format the Go API returns.

    The Go API has 4 response formats (see comments in _API_RESPONSES).
    Engine errors are surfaced as the "error" string in FORMAT 2.
    """

    # FORMAT 2: {"status": "failed", "error": "..."} — most handlers
    # Source: pipeline_handler.go, chatbot_handler.go, kb_handler.go, etc.
    def test_format2_status_error(self):
        body = '{"status":"failed","error":"Pipeline ID is required"}'
        err = _make_status_error(400, "GET", "/pipeline", body)
        assert err.error_message == "Pipeline ID is required"

    # FORMAT 2 with engine error surfaced via result.GetError()
    # Source: kb_handler.go:97-100, result.proto:67 (oneof string error)
    def test_format2_engine_task_failure(self):
        body = '{"status":"failed","error":"document loading failed: unsupported file type .xyz"}'
        err = _make_status_error(500, "POST", "/knowledge-base/index", body)
        assert err.error_message == "document loading failed: unsupported file type .xyz"

    # FORMAT 2 with engine Kafka send error (err.Error())
    # Source: chatbot_handler.go:62-65
    def test_format2_engine_kafka_error(self):
        body = '{"status":"failed","error":"kafka: client has run out of available brokers"}'
        err = _make_status_error(500, "POST", "/chatbot/run", body)
        assert err.error_message == "kafka: client has run out of available brokers"

    # FORMAT 2 with engine executor failure
    # Source: executor.proto:20-22 (ExecutorTaskFailure.error_message)
    def test_format2_engine_executor_failure(self):
        body = '{"status":"failed","error":"executor task failed: out of memory"}'
        err = _make_status_error(500, "POST", "/pipeline/run", body)
        assert err.error_message == "executor task failed: out of memory"

    # FORMAT 1: {"error": "..."} — auth middleware (main.go:186-236)
    def test_format1_auth_error(self):
        body = '{"error":"Invalid API key: verification failed"}'
        err = _make_status_error(401, "GET", "/pipeline", body)
        assert err.error_message == "Invalid API key: verification failed"

    # FORMAT 1: {"error": "..."} — agent handler (agent_handler.go:36)
    def test_format1_agent_error(self):
        body = '{"error":"Agent ID is required"}'
        err = _make_status_error(400, "GET", "/agent", body)
        assert err.error_message == "Agent ID is required"

    # FORMAT 3: {"detail": {"message": "..."}} — org handler (org_handler.go:35-96)
    def test_format3_org_detail_message(self):
        body = '{"detail":{"message":"Cannot create a new organization. No currently owned organizations have a subscription."}}'
        err = _make_status_error(403, "POST", "/org", body)
        # "detail" is a dict — _parse_error calls str() on it
        assert "Cannot create a new organization" in err.error_message

    # FORMAT 3: {"detail": {"message": "..."}} — org handler DB error
    # Source: org_handler.go:58-62
    def test_format3_org_db_error(self):
        body = '{"detail":{"message":"Failed to get user info: connection refused"}}'
        err = _make_status_error(500, "POST", "/org", body)
        assert "Failed to get user info" in err.error_message

    # FORMAT 4: plain text (SendString) — MCP handler (mcp_routes.go:40,52,57,73)
    def test_format4_mcp_plain_text(self):
        body = "MCP server ID is required in path: /v1/mcp/{mcp-server-id}"
        err = _make_status_error(400, "GET", "/mcp", body)
        assert err.error_message == body

    def test_format4_mcp_plain_text_auth(self):
        body = "API key not found in context"
        err = _make_status_error(401, "GET", "/mcp/server-123", body)
        assert err.error_message == body

    # SSE error: same as FORMAT 2, sent over SSE event
    # Source: stream.go:241-249 (writeErrorResponse)
    def test_sse_error_format(self):
        body = '{"status":"failed","error":"pipeline execution timed out after 300s"}'
        err = _make_status_error(500, "POST", "/pipeline/run", body)
        assert err.error_message == "pipeline execution timed out after 300s"

    # Edge case: empty JSON body
    def test_empty_json_body(self):
        body = "{}"
        err = _make_status_error(500, "POST", "/test", body)
        assert err.error_message == "{}"

    # Edge case: JSON with "message" key (used by some error wrappers)
    def test_message_key(self):
        body = '{"message":"internal error occurred"}'
        err = _make_status_error(500, "POST", "/test", body)
        assert err.error_message == "internal error occurred"


# ---------------------------------------------------------------------------
# Catch semantics: verify except-block behavior matches expectations
# ---------------------------------------------------------------------------


class TestCatchSemantics:
    """Verify that except blocks work correctly with the hierarchy."""

    def test_broad_catch_gets_specific_error(self):
        err = _make_status_error(401, "GET", "/test", '{"error":"bad"}')
        caught_by = None
        try:
            raise err
        except VectorShiftError as e:
            caught_by = type(e)
        assert caught_by is AuthenticationError

    def test_specific_catch_before_broad(self):
        err = _make_status_error(429, "GET", "/test", '{"error":"slow down"}')
        caught_by = None
        try:
            raise err
        except RateLimitError:
            caught_by = "rate_limit"
        except VectorShiftAPIError:
            caught_by = "api_error"
        assert caught_by == "rate_limit"

    def test_connection_error_not_caught_by_api_error(self):
        err = APIConnectionError("no network")
        caught_by = None
        try:
            raise err
        except VectorShiftAPIError:
            caught_by = "api_error"
        except VectorShiftError:
            caught_by = "base_error"
        assert caught_by == "base_error"

    def test_timeout_caught_by_connection_error(self):
        err = APITimeoutError("timed out")
        caught_by = None
        try:
            raise err
        except APIConnectionError:
            caught_by = "connection"
        except VectorShiftError:
            caught_by = "base"
        assert caught_by == "connection"


# ---------------------------------------------------------------------------
# Export tests
# ---------------------------------------------------------------------------


class TestExports:
    def test_all_errors_importable_from_vectorshift(self):
        import vectorshift

        assert vectorshift.VectorShiftError is VectorShiftError
        assert vectorshift.VectorShiftAPIError is VectorShiftAPIError
        assert vectorshift.APIStatusError is APIStatusError
        assert vectorshift.BadRequestError is BadRequestError
        assert vectorshift.AuthenticationError is AuthenticationError
        assert vectorshift.PermissionDeniedError is PermissionDeniedError
        assert vectorshift.NotFoundError is NotFoundError
        assert vectorshift.UnprocessableEntityError is UnprocessableEntityError
        assert vectorshift.RateLimitError is RateLimitError
        assert vectorshift.InternalServerError is InternalServerError
        assert vectorshift.APIConnectionError is APIConnectionError
        assert vectorshift.APITimeoutError is APITimeoutError
