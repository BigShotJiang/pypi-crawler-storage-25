import pytest
from pathlib import Path


@pytest.fixture(scope="session")
def sdk_root():
    """SDK root directory."""
    return Path(__file__).parent.parent


@pytest.fixture(scope="session")
def nodes_dir(sdk_root):
    """Generated nodes directory."""
    return sdk_root / "vectorshift" / "pipeline" / "nodes"
