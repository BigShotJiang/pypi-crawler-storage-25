from vectorshift.object import ObjectInfo, ObjectType
from typing import Literal


class Integration(ObjectInfo):
    object_type: Literal[ObjectType.INTEGRATION] = ObjectType.INTEGRATION
