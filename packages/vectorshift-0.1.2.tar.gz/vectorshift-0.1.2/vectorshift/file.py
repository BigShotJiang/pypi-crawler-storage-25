from __future__ import annotations

from typing import Any, Optional

from vectorshift.object import ObjectType
from vectorshift.request import request_client, async_request_client


class File:
    """Represents a VectorShift File object.

    Use ``File.fetch()`` to retrieve a single file by ID or name,
    and ``File.list()`` to list files.
    """

    def __init__(
        self,
        id: str,
        name: Optional[str] = None,
        **kwargs: Any,
    ):
        self.id = id
        self.name = name
        self._data = kwargs

    # ------------------------------------------------------------------
    # fetch / afetch
    # ------------------------------------------------------------------

    @classmethod
    def fetch(
        cls,
        id: Optional[str] = None,
        name: Optional[str] = None,
        username: Optional[str] = None,
        org_name: Optional[str] = None,
    ) -> "File":
        """Fetch a file by ID or name.

        Args:
            id: The unique identifier of the file.
            name: The name of the file.
            username: Owner username (name-based lookup only).
            org_name: Organization name (name-based lookup only).

        Returns:
            File: The fetched file instance.

        Raises:
            ValueError: If neither ``id`` nor ``name`` is provided.
        """
        if id is None and name is None:
            raise ValueError("Either id or name must be provided")

        query: dict[str, Any] = {}
        if id is not None:
            query["id"] = id
        if name is not None:
            query["name"] = name
        if username is not None:
            query["username"] = username
        if org_name is not None:
            query["org_name"] = org_name

        response = request_client.request("GET", "/file", query=query)
        obj = response["object"]
        return cls.from_json(obj)

    @classmethod
    async def afetch(
        cls,
        id: Optional[str] = None,
        name: Optional[str] = None,
        username: Optional[str] = None,
        org_name: Optional[str] = None,
    ) -> "File":
        """Async version of :meth:`fetch`."""
        if id is None and name is None:
            raise ValueError("Either id or name must be provided")

        query: dict[str, Any] = {}
        if id is not None:
            query["id"] = id
        if name is not None:
            query["name"] = name
        if username is not None:
            query["username"] = username
        if org_name is not None:
            query["org_name"] = org_name

        response = await async_request_client.arequest("GET", "/file", query=query)
        obj = response["object"]
        return cls.from_json(obj)

    # ------------------------------------------------------------------
    # list / alist
    # ------------------------------------------------------------------

    @classmethod
    def list(
        cls,
        include_shared: Optional[bool] = None,
        verbose: Optional[bool] = None,
        offset: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> list["File"]:
        """List files.

        By default, returned ``File`` objects contain only ``id``; other
        attributes (e.g. ``name``) will be ``None``. Pass ``verbose=True``
        to return fully-hydrated objects, or call :meth:`fetch` on
        individual files afterwards.

        Args:
            include_shared: Include files shared with the user.
            verbose: When ``True``, the API returns full file details and
                the returned ``File`` objects will have all attributes
                populated (``name``, etc.).
            offset: Pagination offset.
            limit: Maximum number of files to return.

        Returns:
            A list of File instances (ID-only unless *verbose* is ``True``).
        """
        query: dict[str, Any] = {}
        if include_shared is not None:
            query["include_shared"] = include_shared
        if verbose is not None:
            query["verbose"] = verbose
        if offset is not None:
            query["offset"] = offset
        if limit is not None:
            query["limit"] = limit

        response = request_client.request("GET", "/files", query=query)
        if verbose and "objects" in response:
            return [cls.from_json(obj) for obj in response["objects"]]
        return [cls(id=obj_id) for obj_id in response.get("object_ids", [])]

    @classmethod
    async def alist(
        cls,
        include_shared: Optional[bool] = None,
        verbose: Optional[bool] = None,
        offset: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> list["File"]:
        """Async version of :meth:`list`.

        See :meth:`list` for details on returned objects.
        """
        query: dict[str, Any] = {}
        if include_shared is not None:
            query["include_shared"] = include_shared
        if verbose is not None:
            query["verbose"] = verbose
        if offset is not None:
            query["offset"] = offset
        if limit is not None:
            query["limit"] = limit

        response = await async_request_client.arequest("GET", "/files", query=query)
        if verbose and "objects" in response:
            return [cls.from_json(obj) for obj in response["objects"]]
        return [cls(id=obj_id) for obj_id in response.get("object_ids", [])]

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    @classmethod
    def from_json(cls, data: dict) -> "File":
        """Create a File from an API response dict."""
        file_id = str(data.get("_id", data.get("id", "")))
        name = data.get("name")
        return cls(
            id=file_id,
            name=name,
            **{k: v for k, v in data.items() if k not in ("_id", "id", "name")},
        )

    def to_dict(self) -> dict:
        """Return an ObjectInfo-compatible dict."""
        return {
            "object_id": self.id,
            "object_type": ObjectType.FILE,
        }

    def __repr__(self) -> str:
        return f"File(id={self.id!r}, name={self.name!r})"
