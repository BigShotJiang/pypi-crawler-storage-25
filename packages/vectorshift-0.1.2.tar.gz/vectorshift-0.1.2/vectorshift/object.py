from enum import IntEnum

from pydantic import BaseModel, Field, model_validator
from typing import Union, Optional


class ObjectType(IntEnum):
    """Numeric object-type identifiers used by the VectorShift API."""

    PIPELINE = 0
    KNOWLEDGE_BASE = 1
    TABLE = 3
    TRANSFORMATION = 14
    FILE = 15
    PORTAL = 19
    INTEGRATION = 20
    VARIABLE_SET = 23
    AGENT = 25
    PROJECT = 29
    SKILL = 35


class ObjectVersion(BaseModel):
    major: int
    minor: int
    patch: int

    def to_dict(self) -> dict[str, int]:
        return {'major': self.major, 'minor': self.minor, 'patch': self.patch}


class ObjectInfo(BaseModel):
    object_type: Union[str, int]
    object_id: str = ""
    branch_id: Optional[str] = None
    version: Optional[ObjectVersion] = None
    state_id: Optional[str] = None

    @model_validator(mode="before")
    @classmethod
    def _accept_id_alias(cls, data):
        """Allow ``id`` as a convenient alias for ``object_id``."""
        if isinstance(data, dict) and "id" in data and "object_id" not in data:
            data["object_id"] = data.pop("id")
        return data

    def to_dict(self) -> dict:
        return {
            'object_id': self.object_id,
            'object_type': self.object_type,
            'branch_id': self.branch_id,
            'version': self.version,
            'state_id': self.state_id,
        }
