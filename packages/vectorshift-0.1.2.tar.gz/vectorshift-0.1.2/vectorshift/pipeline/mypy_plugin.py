"""
Mypy plugin for VectorShift SDK node constructor validation.

Intercepts calls to node constructors (TalkNode, LlmNode, etc.) and emits
custom error messages when:
1. Required fields are missing for a variant
2. Sig param values are invalid (e.g., variant='foo')
3. Argument types don't match expected types (using VectorShift compatibility)
4. Batch mode type violations (execution_mode='batch' allows List[T] too)

Uses VectorShift's type compatibility system:
- FULL compatibility: pass silently
- PARTIAL compatibility: pass silently (may require conversion at runtime)
- NONE compatibility: red error

Reads validation rules from a generated manifest JSON file.
"""

from __future__ import annotations

import json
import os
from enum import Enum
from typing import Callable, Optional

from mypy.nodes import (
    Decorator,
    ListExpr,
    IntExpr,
    StrExpr,
    FloatExpr,
    NameExpr,
    OverloadedFuncDef,
)
from mypy.plugin import FunctionContext, Plugin
from mypy.types import AnyType, Type, LiteralType, Instance, UnionType, get_proper_type

# --- VectorShift type compatibility ---
# Uses canonical compatibility table from data_type.toml (embedded in manifest
# as __compatibility__). Can't import the SDK directly because it triggers
# pydantic/etc side effects that crash mypy's process.


class Compatibility(Enum):
    FULL = "Full"
    PARTIAL = "Partial"
    NONE = "None"


# SDK-specific compatibility additions (on top of canonical TOML table).
# VS object types accept string IDs in the SDK.
_SDK_COMPAT: dict[str, dict[str, str]] = {
    "string": {
        "knowledge_base": "full",
        "pipeline": "full",
        "agent": "full",
        "transformation": "full",
        "integration": "full",
    },
}

# SDK-specific compatibility RESTRICTIONS for Python builtins.
# These override the canonical TOML table to prevent semantically
# incorrect Python literal usage. Only applied when the source is
# a Python builtin type (not a pipeline output type like vst.Bool).
_SDK_RESTRICT_BUILTINS: dict[str, set[str]] = {
    "bool": {"float", "int32", "int64"},  # True/False not valid as numbers
    "int32": {"bool"},  # 42 not valid as a boolean
    "float": {"bool"},  # 3.14 not valid as a boolean
}


def _get_compat(
    source: str,
    target: str,
    compat_table: dict[str, dict[str, str]],
    is_builtin_source: bool = False,
) -> Compatibility:
    """Determine compatibility using the canonical TOML table + SDK additions.

    Stream types are unwrapped to their inner type (string) since SDK streams
    are always stream<string>. This gives PARTIAL compatibility (allowed for
    pipeline output types only).

    When *is_builtin_source* is True, SDK-specific restrictions are applied
    to prevent semantically wrong Python literal usage (e.g., temperature=True).
    """
    if not source or not target:
        return Compatibility.NONE
    if source == target:
        return Compatibility.FULL
    if target == "any":
        return Compatibility.FULL
    if source == "any":
        return Compatibility.PARTIAL

    # SDK builtin restrictions: prevent semantically wrong Python literal usage
    if is_builtin_source and target in _SDK_RESTRICT_BUILTINS.get(source, set()):
        return Compatibility.NONE

    # Stream unwrap: stream → treat as inner type (string) for compat lookup
    if source == "stream":
        source = "string"

    # Canonical TOML table lookup
    level = compat_table.get(source, {}).get(target)
    if level == "full":
        return Compatibility.FULL
    if level == "partial":
        return Compatibility.PARTIAL

    # SDK-specific additions
    sdk_level = _SDK_COMPAT.get(source, {}).get(target)
    if sdk_level == "full":
        return Compatibility.FULL
    if sdk_level == "partial":
        return Compatibility.PARTIAL

    return Compatibility.NONE


# Map mypy fullnames to VectorShift base type names
_MYPY_TO_VS_TYPE: dict[str, str] = {
    # Python builtins
    "builtins.str": "string",
    "builtins.int": "int32",
    "builtins.float": "float",
    "builtins.bool": "bool",
    "builtins.bytes": "bytes",
    "builtins.dict": "json",
    # Pipeline output types (vectorshift.types module)
    "vectorshift.types.Output": "any",
    "vectorshift.types.Str": "string",
    "vectorshift.types.Int32": "int32",
    "vectorshift.types.Int64": "int64",
    "vectorshift.types.Float": "float",
    "vectorshift.types.Bool": "bool",
    "vectorshift.types.Timestamp": "timestamp",
    "vectorshift.types.Json": "json",
    "vectorshift.types.BucketKey": "bucket_key",
    "vectorshift.types.Path": "path",
    "vectorshift.types.Bytes": "bytes",
    "vectorshift.types.File": "file",
    "vectorshift.types.Image": "image",
    "vectorshift.types.Audio": "audio",
    "vectorshift.types.Stream": "stream",
    "vectorshift.types.Dataframe": "dataframe",
    "vectorshift.types.Table": "table",
    "vectorshift.types.Chart": "chart",
    "vectorshift.types.AnyType": "any",
    # VS object types (accept string IDs too)
    "vectorshift.types.KnowledgeBase": "knowledge_base",
    "vectorshift.knowledge_base.KnowledgeBase": "knowledge_base",
    "vectorshift.types.Pipeline": "pipeline",
    "vectorshift.pipeline.object.Pipeline": "pipeline",
    "vectorshift.types.Agent": "agent",
    "vectorshift.agent.object.Agent": "agent",
    "vectorshift.types.Transformation": "transformation",
    "vectorshift.transformation.Transformation": "transformation",
    "vectorshift.types.Integration": "integration",
    "vectorshift.integrations.integration.Integration": "integration",
    # Legacy pipeline_types mappings (backward compat)
    "vectorshift.pipeline.pipeline_types.PipelineStr": "string",
    "vectorshift.pipeline.pipeline_types.PipelineInt32": "int32",
    "vectorshift.pipeline.pipeline_types.PipelineInt64": "int64",
    "vectorshift.pipeline.pipeline_types.PipelineFloat": "float",
    "vectorshift.pipeline.pipeline_types.PipelineBool": "bool",
    "vectorshift.pipeline.pipeline_types.PipelineTimestamp": "timestamp",
    "vectorshift.pipeline.pipeline_types.PipelineJson": "json",
    "vectorshift.pipeline.pipeline_types.PipelineBucketKey": "bucket_key",
    "vectorshift.pipeline.pipeline_types.PipelinePath": "path",
    "vectorshift.pipeline.pipeline_types.PipelineBytes": "bytes",
    "vectorshift.pipeline.pipeline_types.PipelineFile": "file",
    "vectorshift.pipeline.pipeline_types.PipelineImage": "image",
    "vectorshift.pipeline.pipeline_types.PipelineAudio": "audio",
    "vectorshift.pipeline.pipeline_types.PipelineStream": "stream",
    "vectorshift.pipeline.pipeline_types.PipelineDataframe": "dataframe",
    "vectorshift.pipeline.pipeline_types.PipelineTable": "table",
    "vectorshift.pipeline.pipeline_types.PipelineChart": "chart",
    "vectorshift.pipeline.pipeline_types.PipelineKnowledgeBase": "knowledge_base",
    "vectorshift.pipeline.pipeline_types.PipelinePipeline": "pipeline",
    "vectorshift.pipeline.pipeline_types.PipelineAgent": "agent",
    "vectorshift.pipeline.pipeline_types.PipelineTransformation": "transformation",
    "vectorshift.pipeline.pipeline_types.PipelineIntegration": "integration",
    "vectorshift.pipeline.pipeline_types.PipelineAny": "any",
}

# Reverse map for AST literal types (from _infer_list_elem_type_name)
_LITERAL_TO_VS_TYPE: dict[str, str] = {
    "int": "int32",
    "str": "string",
    "float": "float",
    "bool": "bool",
    "bytes": "bytes",
}


def _is_pipeline_output_type(arg_type: Type) -> bool:
    """Check if a mypy type is a VectorShift pipeline output type (not a Python builtin).

    Returns True for types like vectorshift.types.File, vectorshift.types.Stream, etc.
    Returns False for builtins like str, int, float, bool, list, dict.
    """
    arg_type = get_proper_type(arg_type)
    if isinstance(arg_type, Instance):
        fullname = arg_type.type.fullname
        return fullname in _MYPY_TO_VS_TYPE and not fullname.startswith("builtins.")
    return False


def _extract_literal_str(typ: Type) -> Optional[str]:
    """Extract a string literal value from a mypy Type, if possible.

    Also handles boolean literals (stream=False → "false") for sig params
    whose manifest values use lowercase strings.
    """
    typ = get_proper_type(typ)
    if isinstance(typ, LiteralType):
        if isinstance(typ.value, str):
            return typ.value
        if isinstance(typ.value, bool):
            return str(typ.value).lower()  # False → "false", True → "true"
    if isinstance(typ, Instance):
        last_known = typ.last_known_value
        if last_known is not None and isinstance(last_known, LiteralType):
            if isinstance(last_known.value, str):
                return last_known.value
            if isinstance(last_known.value, bool):
                return str(last_known.value).lower()
    return None


def _extract_literal_str_from_ast(
    ctx: FunctionContext, field_name: str
) -> Optional[str]:
    """Extract literal string value from AST when catch-all matched (types are Any)."""
    for names_list, args_list in zip(ctx.arg_names, ctx.args):
        for name, expr in zip(names_list, args_list):
            if name == field_name:
                if isinstance(expr, StrExpr):
                    return expr.value
                if isinstance(expr, NameExpr):
                    if expr.name == "True":
                        return "true"
                    if expr.name == "False":
                        return "false"
                return None
    return None


# Cache for _collect_valid_literal_values — stubs don't change during a run.
_literal_values_cache: dict[tuple[str, str], set[str] | None] = {}


def _collect_valid_literal_values(
    ctx: FunctionContext, param_name: str
) -> set[str] | None:
    """Collect all valid Literal string values for a param across overloads.

    Introspects the __new__ overload signatures from the .pyi stubs.
    Returns None if the param isn't Literal-constrained in any overload.
    """
    from mypy.types import CallableType

    return_type = get_proper_type(ctx.default_return_type)
    if not isinstance(return_type, Instance):
        return None

    type_info = return_type.type

    # The __new__ overloads live on the base class (e.g. DataCollectorNode).
    # Variant classes (e.g. _DataCollectorNode_Default) inherit from it.
    # Use the base class name for cache key to share across variant types.
    node: OverloadedFuncDef | None = None
    base_class_name = type_info.name
    for base in type_info.mro:
        if "__new__" in base.names:
            sym_node = base.names["__new__"].node
            if isinstance(sym_node, OverloadedFuncDef):
                node = sym_node
                base_class_name = base.name
                break

    cache_key = (base_class_name, param_name)
    if cache_key in _literal_values_cache:
        return _literal_values_cache[cache_key]

    if node is None:
        _literal_values_cache[cache_key] = None
        return None

    values: set[str] = set()
    found_literal = False

    for item in node.items:
        if not isinstance(item, Decorator):
            continue
        func = item.func
        if not isinstance(func.type, CallableType):
            continue
        callable_type = func.type
        for i, name in enumerate(callable_type.arg_names):
            if name == param_name:
                arg_type = get_proper_type(callable_type.arg_types[i])
                if isinstance(arg_type, LiteralType) and isinstance(arg_type.value, str):
                    values.add(arg_type.value)
                    found_literal = True
                elif isinstance(arg_type, UnionType):
                    for member in arg_type.items:
                        member = get_proper_type(member)
                        if isinstance(member, LiteralType) and isinstance(
                            member.value, str
                        ):
                            values.add(member.value)
                            found_literal = True
                # Note: overloads with non-Literal types (e.g. AcceptsStr
                # for custom provider) are safe to ignore here. When catch-all
                # matches, those non-Literal overloads also failed to match
                # (otherwise mypy would have picked them). So validating
                # against Literal values is always correct when catch-all fires.
                break

    result = values if found_literal else None
    _literal_values_cache[cache_key] = result
    return result


def _get_vs_type(arg_type: Type) -> Optional[str]:
    """Map a mypy type to a VectorShift base type name."""
    arg_type = get_proper_type(arg_type)
    if isinstance(arg_type, LiteralType):
        # bool MUST be checked before int (bool is a subclass of int in Python)
        if isinstance(arg_type.value, bool):
            return "bool"
        if isinstance(arg_type.value, int):
            return "int32"
        if isinstance(arg_type.value, str):
            return "string"
        if isinstance(arg_type.value, float):
            return "float"
    if isinstance(arg_type, Instance):
        mapped = _MYPY_TO_VS_TYPE.get(arg_type.type.fullname)
        if mapped:
            return mapped
        # TypedDict instances map to json
        if arg_type.type.typeddict_type is not None:
            return "json"
    return None


def _get_vs_type_from_ast(ctx: FunctionContext, field_name: str) -> Optional[str]:
    """Get VectorShift type name from a list literal's first element AST.

    When the catch-all **kwargs: Any matches, mypy infers list[Any] instead of
    list[int]. This inspects the AST expression to recover the actual type.
    """
    for names_list, args_list in zip(ctx.arg_names, ctx.args):
        for name, expr in zip(names_list, args_list):
            if name == field_name and isinstance(expr, ListExpr) and expr.items:
                first = expr.items[0]
                if isinstance(first, IntExpr):
                    return "int32"
                if isinstance(first, StrExpr):
                    return "string"
                if isinstance(first, FloatExpr):
                    return "float"
                if isinstance(first, NameExpr):
                    return _LITERAL_TO_VS_TYPE.get(first.name)
                return None
    return None


def _get_vs_type_from_scalar_ast(ctx: FunctionContext, field_name: str) -> Optional[str]:
    """Get VectorShift type name from a scalar literal AST expression.

    When the catch-all **kwargs: Any matches, mypy infers Any for all kwargs.
    This inspects the AST to recover the actual literal type (str, int, float, bool).
    """
    for names_list, args_list in zip(ctx.arg_names, ctx.args):
        for name, expr in zip(names_list, args_list):
            if name == field_name:
                if isinstance(expr, StrExpr):
                    return "string"
                if isinstance(expr, IntExpr):
                    return "int32"
                if isinstance(expr, FloatExpr):
                    return "float"
                if isinstance(expr, NameExpr):
                    if expr.name in ("True", "False"):
                        return "bool"
                    return _LITERAL_TO_VS_TYPE.get(expr.name)
                return None
    return None


def _infer_list_elem_type_name(ctx: FunctionContext, field_name: str) -> Optional[str]:
    """Get the Python type name from a list literal's first element for display."""
    for names_list, args_list in zip(ctx.arg_names, ctx.args):
        for name, expr in zip(names_list, args_list):
            if name == field_name and isinstance(expr, ListExpr) and expr.items:
                first = expr.items[0]
                if isinstance(first, IntExpr):
                    return "int"
                if isinstance(first, StrExpr):
                    return "str"
                if isinstance(first, FloatExpr):
                    return "float"
                if isinstance(first, NameExpr):
                    return first.name
                return None
    return None


def _format_arg_type(arg_type: Type, ctx: FunctionContext, field_name: str) -> str:
    """Format a mypy type for error messages."""
    arg_type = get_proper_type(arg_type)
    if isinstance(arg_type, AnyType):
        # Catch-all **kwargs: Any — try to recover actual type from AST
        for names_list, args_list in zip(ctx.arg_names, ctx.args):
            for name, expr in zip(names_list, args_list):
                if name == field_name:
                    if isinstance(expr, StrExpr):
                        return "str"
                    if isinstance(expr, IntExpr):
                        return "int"
                    if isinstance(expr, FloatExpr):
                        return "float"
                    if isinstance(expr, NameExpr) and expr.name in ("True", "False"):
                        return "bool"
        return str(arg_type)
    if isinstance(arg_type, Instance):
        if arg_type.args:
            has_any = any(isinstance(get_proper_type(a), AnyType) for a in arg_type.args)
            if has_any:
                real_elem = _infer_list_elem_type_name(ctx, field_name)
                if real_elem:
                    return f"{arg_type.type.name}[{real_elem}]"
                return arg_type.type.name
            inner = ", ".join(
                (
                    get_proper_type(a).type.name
                    if isinstance(get_proper_type(a), Instance)
                    else str(a)
                )
                for a in arg_type.args
            )
            return f"{arg_type.type.name}[{inner}]"
        return arg_type.type.name
    return str(arg_type)


class VectorShiftPlugin(Plugin):
    """Mypy plugin that validates VectorShift node constructor arguments."""

    def __init__(self, options) -> None:
        super().__init__(options)
        manifest_path = os.path.join(
            os.path.dirname(__file__), "nodes", "_validation_manifest.json"
        )
        self.manifest: dict = {}
        self.compat_table: dict[str, dict[str, str]] = {}
        if os.path.exists(manifest_path):
            with open(manifest_path, encoding="utf-8") as f:
                self.manifest = json.load(f)
            self.compat_table = self.manifest.pop("__compatibility__", {})
        self._checker_cache: dict[str, Callable[[FunctionContext], Type]] = {}

    def get_function_hook(
        self, fullname: str
    ) -> Optional[Callable[[FunctionContext], Type]]:
        """Intercept node constructor calls for validation."""
        class_name = fullname.rsplit(".", 1)[-1]
        if class_name in self.manifest:
            return self._make_checker(class_name)
        # Match _NodeClass_Suffix pattern -> map back to NodeClass
        # e.g. _LlmNode_StreamFalse → LlmNode, _TalkNode_Default → TalkNode
        if class_name.startswith("_"):
            rest = class_name[1:]  # "LlmNode_StreamFalse"
            idx = rest.find("_")
            if idx > 0:
                base = rest[:idx]  # "LlmNode"
                if base in self.manifest:
                    return self._make_checker(base)
            elif rest in self.manifest:
                return self._make_checker(rest)
        return None

    def _make_checker(self, class_name: str) -> Callable[[FunctionContext], Type]:
        """Create a checker function for a specific node class (cached)."""
        if class_name in self._checker_cache:
            return self._checker_cache[class_name]
        rules = self.manifest[class_name]
        compat_table = self.compat_table

        def checker(ctx: FunctionContext) -> Type:
            return _check_node_args(ctx, class_name, rules, compat_table)

        self._checker_cache[class_name] = checker
        return checker


def _check_node_args(
    ctx: FunctionContext,
    class_name: str,
    rules: dict,
    compat_table: dict[str, dict[str, str]],
) -> Type:
    """Validate node constructor arguments against manifest rules."""
    # Python keywords used as field names get a trailing underscore in stubs
    # (e.g., from_ -> from, in_ -> in, is_ -> is). Strip it for manifest lookup.
    _PY_KEYWORDS = {"from_", "in_", "is_", "type_", "class_", "import_", "return_"}

    # Extract keyword arguments from the call
    kwargs: dict[str, Type] = {}
    for names_list, types_list in zip(ctx.arg_names, ctx.arg_types):
        for name, typ in zip(names_list, types_list):
            if name:
                # Normalize keyword-suffixed names
                key = name.rstrip("_") if name in _PY_KEYWORDS else name
                kwargs[key] = typ

    # Detect if catch-all overload matched by checking return type.
    # When catch-all matches, return type is _NodeClass_Default.
    # (Checking AnyType on kwargs is unreliable — mypy preserves literal types
    # from expressions even through **kwargs: Any.)
    is_catch_all = False
    ret_type = get_proper_type(ctx.default_return_type)
    if isinstance(ret_type, Instance):
        ret_name = ret_type.type.name
        if ret_name.startswith("_") and ret_name.endswith("_Default"):
            is_catch_all = True

    sig_params: list[str] = rules.get("sig_params", [])
    valid_sig_values: dict[str, list[str]] = rules.get("valid_sig_values", {})
    variants: dict = rules.get("variants", {})
    user_sig_params: list[str] = rules.get("primary_sig_params", sig_params[:1])
    non_input_fields: set[str] = set(rules.get("non_input_fields", []))

    # Detect batch mode
    is_batch = False
    if "execution_mode" in kwargs:
        em_val = _extract_literal_str(kwargs["execution_mode"])
        if em_val == "batch":
            is_batch = True

    # Build the resolved sig param values
    resolved_sig: dict[str, str] = {}
    user_provided_sig: dict[str, str] = {}
    for sig_param in sig_params:
        if sig_param in kwargs:
            val = _extract_literal_str(kwargs[sig_param])
            if val is None:
                # Catch-all **kwargs: Any matched — try AST recovery
                val = _extract_literal_str_from_ast(ctx, sig_param)
            if val is not None:
                resolved_sig[sig_param] = val
                user_provided_sig[sig_param] = val
            else:
                # Sig param provided but not a string literal — error
                arg_type = get_proper_type(kwargs[sig_param])
                arg_type_str = _format_arg_type(arg_type, ctx, sig_param)
                valid = valid_sig_values.get(sig_param, [])
                if valid:
                    valid_str = ", ".join(repr(v) for v in valid)
                else:
                    valid_str = "a string literal"
                ctx.api.fail(
                    f"INVALID NODE CONFIGURATION: "
                    f"{class_name}({sig_param}={arg_type_str}) — "
                    f"{sig_param} must be one of: {valid_str}",
                    ctx.context,
                )
                return ctx.default_return_type
        else:
            default_val = rules.get("defaults", {}).get(sig_param)
            if default_val is not None:
                resolved_sig[sig_param] = default_val.lower()

    # Validate sig param values
    for sig_param, val in user_provided_sig.items():
        valid = valid_sig_values.get(sig_param, [])
        if valid and val not in valid:
            valid_str = ", ".join(repr(v) for v in valid)
            ctx.api.fail(
                f"INVALID NODE CONFIGURATION: "
                f"{class_name}({sig_param}={val!r}) is invalid. "
                f"{sig_param} must be one of: {valid_str}",
                ctx.context,
            )
            return ctx.default_return_type

    # Build variant key from resolved sig params
    if not resolved_sig and sig_params:
        # No sig params resolved — use all-wildcard key to attempt matching
        variant_key = "**".join("(*)" for _ in sig_params)
    else:
        variant_key = (
            "**".join(resolved_sig.get(p, "(*)") for p in sig_params)
            if sig_params
            else ""
        )

    # Try exact match first, then with wildcards
    variant_rules = variants.get(variant_key)
    if variant_rules is None:
        for vk, vr in variants.items():
            parts = vk.split("**")
            match = True
            for i, p in enumerate(sig_params):
                expected = parts[i] if i < len(parts) else "(*)"
                actual = resolved_sig.get(p)
                if expected != "(*)" and expected != actual:
                    match = False
                    break
            if match:
                variant_rules = vr
                break

    if variant_rules is None:
        return ctx.default_return_type

    # Build sig description for error messages
    sig_desc = ", ".join(
        f"{p}={user_provided_sig[p]!r}"
        for p in user_sig_params
        if p in user_provided_sig
    )

    # Check required fields
    required: list[str] = variant_rules.get("required", [])
    missing = [f for f in required if f not in kwargs]
    if missing:
        field_types: dict = variant_rules.get("field_types", {})
        fields_str = ", ".join(
            f"{f} ({field_types.get(f, {}).get('display', '?') if isinstance(field_types.get(f), dict) else field_types.get(f, '?')})"
            for f in missing
        )
        ctx.api.fail(
            f"INVALID NODE CONFIGURATION: "
            f"Valid {class_name}({sig_desc}) requires: {fields_str}",
            ctx.context,
        )
        return ctx.default_return_type

    # Check conditional required fields from non-sig params
    # e.g., when use_personal_api_key=true, api_key becomes required
    conditional_fields: dict = rules.get("conditional_fields", {})
    cond_missing: list[str] = []
    for cond_param, cond_rules in conditional_fields.items():
        cond_val: Optional[str] = None
        if cond_param in kwargs:
            cond_val = _extract_literal_str(kwargs[cond_param])
            if cond_val is None:
                cond_val = _extract_literal_str_from_ast(ctx, cond_param)
        # Don't use default for required check — only enforce when explicitly set
        if cond_val is not None and cond_val in cond_rules:
            rule = cond_rules[cond_val]
            for f in rule.get("requires", []):
                if f not in kwargs:
                    cond_missing.append(f)
    if cond_missing:
        fields_str = ", ".join(cond_missing)
        ctx.api.fail(
            f"INVALID NODE CONFIGURATION: "
            f"{class_name}({sig_desc}) requires: {fields_str}",
            ctx.context,
        )
        return ctx.default_return_type

    # Check for unexpected parameters.
    # Start with the resolved variant's fields, then expand with conditional
    # fields based on non-sig param values. For each conditional param, intersect
    # its field set with all_fields to get the fields valid in the current context.
    variant_field_types: dict = variant_rules.get("field_types", {})
    if variant_field_types:
        # Base: variant fields + system fields
        all_known_fields: set[str] = (
            set(variant_rules.get("required", []))
            | set(variant_rules.get("optional", []))
            | set(variant_rules.get("field_types", {}).keys())
            | non_input_fields
            | set(sig_params)
        )

        # Start with all_fields as the permissive baseline, then narrow
        # using conditional_fields rules for resolved non-sig params.
        all_known_fields |= set(rules.get("all_fields", []))
        # Also include fields from all variants (catches fields missed by
        # all_fields computation)
        for _vk, vr in variants.items():
            all_known_fields |= set(vr.get("required", []))
            all_known_fields |= set(vr.get("optional", []))
            all_known_fields |= set(vr.get("field_types", {}).keys())

        # Apply conditional_fields to narrow: remove fields that are explicitly
        # removed for the current non-sig param values. Never remove fields
        # that the resolved variant explicitly lists (variant takes precedence
        # over conditional rules for multi-param interactions).
        variant_explicit = (
            set(variant_rules.get("required", []))
            | set(variant_rules.get("optional", []))
            | set(variant_rules.get("field_types", {}).keys())
        )
        cond_field_rules: dict = rules.get("conditional_fields", {})
        for cond_param, cond_rules in cond_field_rules.items():
            cond_val: Optional[str] = None
            if cond_param in kwargs:
                cond_val = _extract_literal_str(kwargs[cond_param])
                if cond_val is None:
                    cond_val = _extract_literal_str_from_ast(ctx, cond_param)
            if cond_val is None:
                # Not provided — use default from conditional_fields
                cond_val = cond_rules.get("param_default")

            if cond_val is not None and cond_val in cond_rules:
                rule = cond_rules[cond_val]
                # Remove fields that are explicitly disallowed for this value,
                # BUT keep fields that the variant explicitly includes
                removable = set(rule.get("removes", [])) - variant_explicit
                all_known_fields -= removable

        unexpected = [f for f in kwargs if f not in all_known_fields]
        if unexpected:
            unexpected_str = ", ".join(repr(f) for f in unexpected)
            allowed_inputs = sorted(
                set(variant_rules.get("required", []))
                | set(variant_rules.get("optional", []))
            )
            allowed_str = ", ".join(allowed_inputs) if allowed_inputs else "(none)"
            ctx.api.fail(
                f"INVALID NODE CONFIGURATION: "
                f"{class_name}({sig_desc}) does not accept: {unexpected_str}. "
                f"Valid fields for this configuration: {allowed_str}",
                ctx.context,
            )

    # Check types of provided fields using VectorShift compatibility
    field_types_map: dict = variant_rules.get("field_types", {})
    for field_name, field_info in field_types_map.items():
        if field_name not in kwargs or field_name in non_input_fields:
            continue

        if not isinstance(field_info, dict):
            continue

        display_name = field_info.get("display", "?")
        vs_type = field_info.get("vs_type")
        if not vs_type:
            continue

        arg_type = get_proper_type(kwargs[field_name])

        # Determine the source VectorShift type from the argument
        source_vs_type: Optional[str] = None
        is_list_arg = (
            isinstance(arg_type, Instance) and arg_type.type.fullname == "builtins.list"
        )

        # Fields that natively accept lists (vec<X> in TOML)
        if field_info.get("is_list"):
            if not is_list_arg:
                # Scalar passed to a list field — runtime wraps it, OK
                continue
            # List arg — validate element type against the field's vs_type
            elem_vs: Optional[str] = None
            if isinstance(arg_type, Instance) and arg_type.args:
                elem_type = get_proper_type(arg_type.args[0])
                if isinstance(elem_type, AnyType):
                    elem_vs = _get_vs_type_from_ast(ctx, field_name)
                else:
                    elem_vs = _get_vs_type(elem_type)
            if not elem_vs:
                elem_vs = _get_vs_type_from_ast(ctx, field_name)
            if not elem_vs:
                continue  # Can't determine element type — skip
            elem_is_builtin = True
            if isinstance(arg_type, Instance) and arg_type.args:
                elem = get_proper_type(arg_type.args[0])
                elem_is_builtin = not _is_pipeline_output_type(elem)
            compat = _get_compat(
                elem_vs, vs_type, compat_table, is_builtin_source=elem_is_builtin
            )
            if compat != Compatibility.NONE:
                continue  # FULL or PARTIAL — allow
            # Build "expects list[X]" — prefer manifest TypedDict name
            elem_expects = field_info.get("elem_type_name")
            if not elem_expects:
                # Fallback: try formal arg_type, then vs_type
                if isinstance(arg_type, Instance) and arg_type.args:
                    formal_elem = get_proper_type(arg_type.args[0])
                    if isinstance(formal_elem, Instance):
                        elem_expects = formal_elem.type.name
                if not elem_expects:
                    elem_expects = vs_type
            # Build "got list[X]" from AST (what user actually wrote)
            real_elem = _infer_list_elem_type_name(ctx, field_name)
            if real_elem:
                arg_type_str = f"list[{real_elem}]"
            else:
                arg_type_str = _format_arg_type(arg_type, ctx, field_name)
            ctx.api.fail(
                f"INVALID NODE CONFIGURATION: "
                f"{class_name}({sig_desc}) field '{field_name}' "
                f"expects list[{elem_expects}], "
                f"got {arg_type_str}",
                ctx.context,
            )
            continue

        # Dict/interface fields — skip deep validation at mypy level
        # (TypedDict validation is handled in Fix 6; plain dicts can't be
        # introspected for key/value types)
        if field_info.get("is_dict"):
            continue

        if is_list_arg:
            # For list args, check the element type
            if isinstance(arg_type, Instance) and arg_type.args:
                elem_type = get_proper_type(arg_type.args[0])
                if isinstance(elem_type, AnyType):
                    # Catch-all made elements Any — use AST to get real type
                    source_vs_type = _get_vs_type_from_ast(ctx, field_name)
                else:
                    source_vs_type = _get_vs_type(elem_type)
            if not source_vs_type:
                source_vs_type = _get_vs_type_from_ast(ctx, field_name)

            if is_batch and source_vs_type:
                # In batch mode, check element compatibility
                batch_elem_is_builtin = True
                if isinstance(arg_type, Instance) and arg_type.args:
                    batch_elem = get_proper_type(arg_type.args[0])
                    batch_elem_is_builtin = not _is_pipeline_output_type(batch_elem)
                compat = _get_compat(
                    source_vs_type,
                    vs_type,
                    compat_table,
                    is_builtin_source=batch_elem_is_builtin,
                )
                if compat != Compatibility.NONE:
                    continue  # FULL or PARTIAL — allow
                arg_type_str = _format_arg_type(arg_type, ctx, field_name)
                ctx.api.fail(
                    f"INVALID NODE CONFIGURATION: "
                    f"{class_name}({sig_desc}) field '{field_name}' "
                    f"expects {display_name} or "
                    f"list[{display_name}] (batch mode), "
                    f"got {arg_type_str}",
                    ctx.context,
                )
                continue

            if not is_batch:
                # List passed without batch mode
                arg_type_str = _format_arg_type(arg_type, ctx, field_name)
                ctx.api.fail(
                    f"INVALID NODE CONFIGURATION: "
                    f"{class_name}({sig_desc}) field '{field_name}' expects "
                    f"{display_name}, got {arg_type_str}. "
                    f"To use list types, set execution_mode='batch'",
                    ctx.context,
                )
                continue
        else:
            # Scalar arg
            source_vs_type = _get_vs_type(arg_type)
            if not source_vs_type and isinstance(arg_type, AnyType):
                # Catch-all **kwargs: Any — inspect AST to recover actual type
                source_vs_type = _get_vs_type_from_scalar_ast(ctx, field_name)

        if not source_vs_type:
            # Can't determine source type — skip check
            continue

        compat = _get_compat(
            source_vs_type,
            vs_type,
            compat_table,
            is_builtin_source=not _is_pipeline_output_type(arg_type),
        )
        if compat != Compatibility.NONE:
            continue  # FULL or PARTIAL — allow

        arg_type_str = _format_arg_type(arg_type, ctx, field_name)

        # NONE compatibility — type mismatch error
        ctx.api.fail(
            f"INVALID NODE CONFIGURATION: "
            f"{class_name}({sig_desc}) field '{field_name}' expects "
            f"{display_name}, got {arg_type_str}",
            ctx.context,
        )

    # Fix 3: When catch-all matched, validate Literal-constrained params
    # against the stubs' overload signatures (covers model, provider, all enums).
    if is_catch_all:
        _SKIP_LITERAL_CHECK = {"node_name", "id", "execution_mode", "dependencies"}
        for field_name in kwargs:
            if field_name in _SKIP_LITERAL_CHECK or field_name in non_input_fields:
                continue
            # Already validated by sig_param check above
            if field_name in sig_params:
                continue
            user_val = _extract_literal_str(kwargs[field_name])
            if user_val is None:
                user_val = _extract_literal_str_from_ast(ctx, field_name)
            if user_val is None:
                continue  # Not a literal — can't validate statically
            valid = _collect_valid_literal_values(ctx, field_name)
            if valid is not None and user_val not in valid:
                sorted_valid = sorted(valid)
                _MAX_DISPLAY = 20
                if len(sorted_valid) > _MAX_DISPLAY:
                    shown = ", ".join(repr(v) for v in sorted_valid[:_MAX_DISPLAY])
                    valid_str = f"{shown}, ... ({len(sorted_valid)} total)"
                else:
                    valid_str = ", ".join(repr(v) for v in sorted_valid)
                ctx.api.fail(
                    f"INVALID NODE CONFIGURATION: "
                    f"{class_name}({field_name}={user_val!r}) is invalid. "
                    f"Valid values: {valid_str}",
                    ctx.context,
                )
                return ctx.default_return_type

    return ctx.default_return_type


def plugin(version: str) -> type[Plugin]:
    """Entry point for mypy plugin registration."""
    return VectorShiftPlugin
