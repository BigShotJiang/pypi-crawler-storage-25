from __future__ import annotations

from abc import ABC
import inspect
from typing import (
    Any,
    ClassVar,
    Dict,
    List,
    Type,
    Protocol,
    runtime_checkable,
    TypeVar,
    Generic,
    Optional,
    cast,
)
from bson import ObjectId
import re

from .node_output import NodeOutput, validate_input_type

# Pre-compiled regex for extracting template variable references
_VARIABLE_REGEX = re.compile(r"\{\{\s*([\w.]+)\s*\}\}")

# Batch mode constants - ported from batchModeConfigHelpers.ts
NON_BATCH_INPUT_BASE_TYPES = frozenset(
    {
        'path',
        'int32',
        'int64',
        'float',
        'bool',
        'null',
    }
)
NON_BATCH_OBJECT_TYPES = frozenset(
    {
        'pipeline',
        'transformation',
        'agent',
    }
)
ADVANCED_INPUTS = frozenset({'dependencies'})
ADVANCED_OUTPUTS = frozenset({'complete', 'success', 'failure'})


def _is_enum_type(type_str: str) -> bool:
    return type_str.startswith('enum<')


def is_vec_type(type_str: Any) -> bool:
    """Check whether *type_str* is a vec<T> type declaration."""
    return (
        isinstance(type_str, str)
        and type_str.startswith('vec<')
        and type_str.endswith('>')
    )


def unwrap_vec_type(type_str: str) -> str:
    """Remove a single outer vec<> wrapper when present."""
    if is_vec_type(type_str):
        return type_str[4:-1]
    return type_str


def get_vec_depth(type_str: Any) -> int:
    """Count how many vec<> wrappers a type declaration has."""
    depth = 0
    current = type_str
    while is_vec_type(current):
        depth += 1
        current = unwrap_vec_type(current)
    return depth


def wrap_batch_type(type_str: str) -> str:
    """Add the single batch vec<> wrapper for an input type."""
    return f'vec<{type_str}>'


def value_matches_vec_depth(value: Any, depth: int) -> bool:
    """Return True when *value* has at least the requested list nesting depth.

    Empty lists are treated as matching any positive vec depth so batch-mode
    inference preserves the existing behavior of treating ``[]`` as vectorized.
    """
    if depth <= 0:
        return not isinstance(value, list)
    if not isinstance(value, list):
        return False
    if depth == 1 or not value:
        return True
    return all(value_matches_vec_depth(item, depth - 1) for item in value)


def is_batch_vectorized_value(value: Any, batch_type: Any) -> bool:
    """Infer whether *value* uses the extra batch layer for *batch_type*."""
    batch_depth = get_vec_depth(batch_type)
    if batch_depth == 0:
        return isinstance(value, list)
    return value_matches_vec_depth(value, batch_depth)


def is_field_vectorizable(
    field: str,
    input_def: dict,
    list_mode_fields: Optional[list] = None,
) -> bool:
    """Determine if a field should be wrapped in vec<T> in batch mode."""
    if list_mode_fields:
        return any(
            (f.get('field') if isinstance(f, dict) else f) == field
            for f in list_mode_fields
        )
    if field in ADVANCED_INPUTS:
        return False
    field_type = input_def.get('type', '')
    if _is_enum_type(field_type):
        return False
    component = input_def.get('component', {})
    if isinstance(component, dict):
        comp_type = component.get('type', '')
        if comp_type in ('dropdown', 'variable_options'):
            return False
    if field_type in NON_BATCH_OBJECT_TYPES:
        return False
    if field_type in NON_BATCH_INPUT_BASE_TYPES:
        return False
    return True


@runtime_checkable
class NodeOutputs(Protocol):
    """Protocol for node outputs that can be statically type checked."""

    pass


T = TypeVar('T', bound=NodeOutputs)


class _ValidatedInputs(dict):
    """Dict that validates NodeOutput types on assignment."""

    def __init__(self, node_class_name: str, input_types: Dict[str, Any]):
        super().__init__()
        self._node_class_name = node_class_name
        self._input_types = input_types

    # IDs from proto ObjectType enum — keep in sync with backend
    _OBJECT_TYPE_MAP = {
        'pipeline': (0, 'direct'),
        'knowledge_base': (1, 'direct'),
        'table': (3, 'direct'),
        'dataframe': (3, 'nested'),
        'transformation': (14, 'direct'),
        'portal': (19, 'direct'),
        'integration': (20, 'direct'),
        'variable_set': (23, 'direct'),
        'agent': (25, 'direct'),
        'project': (29, 'direct'),
    }

    @staticmethod
    def _normalize_object_reference(expected_type: Any, value: Any) -> Any:
        """Normalize simple object references to expected wire payloads.

        For object-reference inputs, allow callers to pass a raw ID string
        and convert it to the object payload shape expected by the API.
        Supports both direct ({object_id, object_type}) and nested
        ({object_info: {object_id, object_type}}) wire shapes.
        """
        ref = _ValidatedInputs._OBJECT_TYPE_MAP.get(expected_type)
        # Handle integration<...> type patterns (e.g. integration<Cron>)
        if (
            ref is None
            and isinstance(expected_type, str)
            and expected_type.startswith('integration<')
        ):
            ref = (20, 'direct')
        if ref is None:
            return value
        obj_type_int, shape = ref
        if isinstance(value, NodeOutput):
            return value
        if isinstance(value, str):
            stripped = value.strip()
            if stripped.startswith('{{') and stripped.endswith('}}'):
                return value
            payload = {'object_id': value, 'object_type': obj_type_int}
            if shape == 'nested':
                return {'object_info': payload}
            return payload
        # Handle VS objects with an id attribute (Agent, Pipeline, KnowledgeBase, etc.)
        obj_id = getattr(value, 'id', None) or getattr(value, 'object_id', None)
        if obj_id is not None and isinstance(obj_id, str):
            payload = {'object_id': obj_id, 'object_type': obj_type_int}
            if shape == 'nested':
                return {'object_info': payload}
            return payload
        return value

    def __setitem__(self, key, value):
        expected_type = self._input_types.get(key)
        value = self._normalize_object_reference(expected_type, value)

        if isinstance(value, NodeOutput):
            if isinstance(expected_type, str) and expected_type:
                validate_input_type(
                    value,
                    key,
                    expected_type,
                    self._node_class_name,
                )
        super().__setitem__(key, value)


class Node(ABC):
    # Class-level registry for node types
    _node_registry: ClassVar[Dict[str, Type['Node']]] = {}

    # Common inputs and outputs
    _COMMON_INPUTS: ClassVar[List[Dict[str, Any]]] = []
    _COMMON_OUTPUTS: ClassVar[List[Dict[str, Any]]] = []

    # Configuration patterns and their associated inputs/outputs - to be overridden by subclasses
    _CONFIGS: ClassVar[Dict[str, Dict[str, Any]]] = {}

    # List of parameters that affect configuration - to be overridden by subclasses
    _PARAMS: ClassVar[List[str]] = []

    _advanced_inputs: ClassVar[bool] = True
    _batch_mode_allowed: ClassVar[bool] = True
    _list_mode_fields: ClassVar[Optional[list]] = None
    _REQUIRED_FIELDS: ClassVar[List[str]] = []

    def __init__(
        self,
        node_type: str,
        params: Dict[str, Any],
        id: Optional[str] = None,
        node_name: Optional[str] = None,
        execution_mode: Optional[str] = None,
    ):
        """Initialize a node with its type and configuration parameters.

        Args:
            node_type: The type of node (e.g., "llm", "text", etc.)
            params: Dictionary of parameter values that determine the node's configuration.
                   These values are locked in for the lifetime of the node.
            id: Optional ID for the node. If not provided, one will be generated.
        """
        self.id = id if id else f"{node_type}_{str(ObjectId())}"
        self.node_type = node_type
        self.name = node_name
        self.task_name: Optional[str] = None
        self.execution_mode = execution_mode

        # Validate and store params
        self._params = {}
        for param in self._PARAMS:
            if param not in params:
                if param.startswith("endpoint_"):
                    self._params[param] = ""
                    continue
                raise ValueError(f"Missing required parameter: {param}")
            self._params[param] = params[param]

        # Initialize outputs and cyclic inputs
        self.outputs: List[str] = []
        self.cyclic_inputs: Dict[str, Any] = {}

        # Get valid inputs for these params
        valid_inputs = self._get_valid_inputs_for_params()

        # Initialize inputs with type validation
        input_types = {
            field: self._normalize_type_spec(inp.get('type', ''))
            for field, inp in valid_inputs.items()
        }
        self.inputs = _ValidatedInputs(self.__class__.__name__, input_types)

        # Set up inputs with defaults from valid inputs
        for field, input_def in valid_inputs.items():
            self.inputs[field] = input_def.get('value')

        # Get valid outputs (depends on self.inputs being set)
        valid_outputs = self._get_valid_outputs_for_params()

        # Set up outputs
        self.outputs = valid_outputs

    @classmethod
    def register_node_type(cls, node_type: str):
        """Decorator to register node types with their implementing classes."""

        def decorator(node_class: Type['Node']) -> Type['Node']:
            cls._node_registry[node_type] = node_class
            return node_class

        return decorator

    @classmethod
    def from_json(cls, data: dict) -> 'Node':
        """Create a node instance from a JSON dictionary."""
        node_type = data.get('type')
        if not node_type:
            raise ValueError("JSON data must include 'type' field")
        node_class = cls._node_registry.get(node_type)
        if not node_class:
            raise ValueError(f"Unknown node type: {node_type}")

        try:
            return node_class.from_dict(data)
        except ValueError as e:
            # Backward compatibility for persisted nodes that carry stale inputs
            # from older/other config variants.
            if "Invalid input(s) for current parameters" not in str(e):
                raise
            return cls._from_json_with_filtered_inputs(node_class, data)

    @classmethod
    def _from_json_with_filtered_inputs(
        cls, node_class: Type['Node'], data: dict
    ) -> 'Node':
        """Create a node instance while dropping stale/invalid persisted inputs."""
        raw_inputs = data.get('inputs', {}) or {}
        id = data.get('id', None)
        name = data.get('name', None)
        execution_mode = data.get('execution_mode', None)

        signature = inspect.signature(node_class.__init__)
        accepted_params = set()
        for param_name, param in signature.parameters.items():
            if param_name in {'self', 'id', 'node_name', 'execution_mode'}:
                continue
            if param.kind == inspect.Parameter.VAR_KEYWORD:
                continue
            accepted_params.add(param_name)

        constructor_kwargs = {}
        consumed_raw_keys = set()
        for key, value in raw_inputs.items():
            if key in accepted_params:
                constructor_kwargs[key] = value
                consumed_raw_keys.add(key)

        # Instantiate with constructor-compatible inputs only.
        node = node_class(
            **constructor_kwargs,
            id=cast(Any, id),
            node_name=cast(Any, name),
            execution_mode=cast(Any, execution_mode),
        )

        # Apply remaining valid dynamic/metadata inputs, drop stale invalid ones.
        remaining = {k: v for k, v in raw_inputs.items() if k not in consumed_raw_keys}
        valid_inputs = node._get_valid_inputs_for_params()
        metadata_fields = {'variant', 'is_iframe'}
        filtered_remaining = {
            k: v
            for k, v in remaining.items()
            if k in valid_inputs or k in metadata_fields
        }
        if filtered_remaining:
            node.update_inputs(**filtered_remaining)

        return node

    def __getattr__(self, name: str) -> NodeOutput:
        """Handle access to output names as attributes.

        Returns a NodeOutput wrapping the template string with type metadata.
        """
        # Get valid outputs for current params
        valid_outputs = self._get_valid_outputs_for_params()

        # Check if output is valid for current configuration
        if name in self.outputs and name in valid_outputs:
            output_type = self._get_output_type(name)
            output_type = self._maybe_vectorize_output_type(name, output_type)
            return NodeOutput(
                f"{{{{ {self.id}.{name} }}}}",
                source_type=output_type,
                source_node_id=self.id,
                source_field=name,
            )
        if self._has_unresolved_dynamic_config():
            return NodeOutput(
                f"{{{{ {self.id}.{name} }}}}",
                source_type='any',
                source_node_id=self.id,
                source_field=name,
            )
        raise AttributeError(
            f"'{self.__class__.__name__}' has no output '{name}' for current parameter values: "
            f"{', '.join(f'{k}={v!r}' for k, v in self._params.items())}\n"
            f"Available outputs: {valid_outputs}"
        )

    def _get_output_type(self, field_name: str) -> str:
        """Get the semantic type of an output field from the node config."""
        # Check config outputs first (more specific, resolves generics)
        params_set = set(self._PARAMS)

        # Collect all matching configs with their specificity
        matching_configs = []
        for config_key, config in self._CONFIGS.items():
            matches, generic_params = self._match_config_key(
                config_key, self._params, params_set
            )
            if matches and 'outputs' in config:
                specificity = self._compute_config_specificity(config_key, self._PARAMS)
                matching_configs.append(
                    (config_key, config, specificity, generic_params)
                )

        # Sort by specificity (most specific first)
        matching_configs.sort(key=lambda x: x[2], reverse=True)

        # Return type from most specific config that has this field
        for config_key, config, specificity, generic_params in matching_configs:
            for output in config['outputs']:
                if isinstance(output, dict) and output.get('field') == field_name:
                    output_type = output.get('type', 'any')
                    # Resolve generic type parameters if present
                    for generic_key, generic_value in generic_params.items():
                        output_type = output_type.replace(generic_key, generic_value)
                    return output_type

        # Fall back to common outputs
        for output in self._COMMON_OUTPUTS:
            if output.get('field') == field_name:
                return output.get('type', 'any')

        if field_name == 'complete':
            return 'path'

        return 'any'

    def _maybe_vectorize_output_type(self, field_name: str, output_type: str) -> str:
        """Wrap output type in vec<> for batch mode if appropriate."""
        if (
            self.execution_mode == 'batch'
            and self._batch_mode_allowed
            and field_name not in ADVANCED_OUTPUTS
            and not output_type.startswith('vec<')
        ):
            return f'vec<{output_type}>'
        return output_type

    @staticmethod
    def _parse_dynamic_pattern(
        config_key: str, params_set: set[str]
    ) -> tuple[Optional[str], Optional[str]]:
        """Parse a dynamic config pattern to extract object type and ID pattern.

        Handles both standalone keys (``[<A>]``) and compound keys
        where one ``**``-separated segment is dynamic
        (``true**[<A>]``, ``read_table**[endpoint_0.<A>]``).

        Args:
            config_key: The config key pattern
            params_set: The set of parameters for node
        Returns:
            Tuple of (object_type, id_pattern) or (None, None) if not
            a dynamic pattern
        """
        candidates = (
            [config_key]
            if config_key.startswith("[") and config_key.endswith("]")
            else config_key.split("**")
        )

        for segment in candidates:
            if not (segment.startswith("[") and segment.endswith("]")):
                continue

            inner = segment[1:-1]
            parts = inner.split(".")

            if len(parts) < 2:
                if not parts or not params_set:
                    continue
                if "transformation" in params_set:
                    return "transformations", "transformation"
                elif "pipeline" in params_set:
                    return "pipelines", "pipeline"
                elif "agent" in params_set:
                    return "agents", "agent"
                continue

            object_type = parts[0]
            if object_type == "pipelines":
                return "pipelines", "pipeline"
            elif object_type == "agents":
                return "agents", "agent"
            elif object_type == "transformations":
                return "transformations", "transformation"
            else:
                return object_type, f"{object_type}_id"

        return None, None

    @staticmethod
    def _fetch_object_definition(object_type: str, object_id: str) -> Dict[str, Any]:
        """Fetch object definition from the API.

        Args:
            object_type: Type of object to fetch (e.g., "pipelines", "agents")
            object_id: ID of the object to fetch

        Returns:
            Dictionary containing object definition

        Raises:
            RuntimeError: If object cannot be fetched
        """
        try:
            if object_type == "pipelines":
                from vectorshift import Pipeline

                return Pipeline.fetch(id=object_id)
            elif object_type == "agents":
                from vectorshift import Agent

                return Agent.fetch(id=object_id)
            elif object_type == "transformations":
                from vectorshift import Transformation

                return Transformation.fetch(id=object_id)
            else:
                raise ValueError(f"Unknown object type: {object_type}")
        except Exception as e:
            raise RuntimeError(
                f"Failed to fetch {object_type} definition: {str(e)}"
            ) from e

    @staticmethod
    def _compute_config_specificity(config_key: str, params: list[str]) -> int:
        """
        Compute specificity score for a config pattern.

        Higher score = more specific = higher priority when resolving conflicts.

        Scoring:
        - Dynamic pattern ([<A>], [<A>.inputs]): +1000 (highest)
        - Literal value: +10 per position
        - Generic param (<A>, <T>): +5 per position
        - Wildcard (*): +0

        Examples:
        - "openai**true**false**(*)**(*)**(*)" = 10+10+10+0+0+0 = 30
        - "(*)**true**(*)**(*)**(*)**(*)" = 0+10+0+0+0+0 = 10
        - "[<A>]" = 1000
        """
        # Dynamic patterns are most specific (for AgentNode, TransformationNode)
        if config_key.startswith("[") and config_key.endswith("]"):
            return 1000

        parts = config_key.split("**")
        score = 0

        for i, part in enumerate(parts):
            if i >= len(params):
                break

            if part.startswith("[<") and part.endswith(">]"):
                score += 15  # Dynamic reference within pattern
            elif part.startswith("<") and part.endswith(">"):
                score += 5  # Generic type parameter
            elif part != "(*)":
                score += 10  # Literal constraint
            # (*) adds 0

        return score

    @staticmethod
    def _resolve_object_id(value: Any) -> Optional[str]:
        """Extract a string object ID from a param value."""
        if isinstance(value, str):
            return value
        if hasattr(value, 'to_dict'):
            return value.to_dict().get('object_id')
        if isinstance(value, dict):
            return value.get('object_id')
        return None

    @staticmethod
    def _try_dynamic_fetch(
        segment: str,
        param_values: Dict[str, Any],
        params_set: set[str],
    ) -> bool:
        """Attempt to resolve a dynamic ``[...]`` segment.

        Returns True if the segment was successfully fetched and cached,
        False otherwise.
        """
        object_type, id_pattern = Node._parse_dynamic_pattern(segment, params_set)
        if not object_type or not id_pattern:
            return False
        object_id = Node._resolve_object_id(param_values.get(id_pattern))
        if not object_id:
            return False
        try:
            obj = Node._fetch_object_definition(object_type, object_id)
            Node._cached_definitions[object_id] = obj
            return True
        except (RuntimeError, ValueError):
            return False

    @staticmethod
    def _match_config_key(
        config_key: str,
        param_values: Dict[str, Any],
        params_set: set[str],
    ) -> tuple[bool, Dict[str, Any]]:
        """Match a config key pattern against actual parameter values.

        Segment types (separated by ``**``):
          ``(*)``   -- wildcard, matches any value
          ``<X>``   -- generic param, matches any value and captures it
          ``[...]`` -- dynamic pattern, triggers object fetch + cache
          other     -- literal, must match ``str(value).lower()``
        """
        if not config_key or not param_values:
            return (False, {})

        if config_key.startswith("[") and config_key.endswith("]"):
            if Node._try_dynamic_fetch(config_key, param_values, params_set):
                return (True, {})
            return (False, {})

        # Split compound key and match segment-by-segment
        pattern_parts = config_key.split("**")
        if len(pattern_parts) != len(param_values):
            return (False, {})

        generic_params: Dict[str, Any] = {}
        for pattern, (param, value) in zip(pattern_parts, param_values.items()):
            if pattern.startswith("[") and pattern.endswith("]"):
                if not Node._try_dynamic_fetch(pattern, param_values, params_set):
                    return (False, {})
            elif pattern.startswith("<") and pattern.endswith(">"):
                generic_params[pattern] = value
            elif pattern != "(*)" and str(value).lower() != pattern.lower():
                return (False, {})

        return (True, generic_params)

    # Cache for object definitions
    _cached_definitions: ClassVar[Dict[str, Any]] = {}

    @staticmethod
    def _normalize_type_spec(type_spec: Any) -> str:
        """Normalize type metadata from dynamic object definitions."""
        if isinstance(type_spec, str):
            return type_spec
        if isinstance(type_spec, dict):
            io_type = type_spec.get('io_type') or type_spec.get('type')
            return str(io_type) if io_type else 'any'
        io_type = getattr(type_spec, 'io_type', None) or getattr(type_spec, 'type', None)
        if io_type:
            return str(io_type)
        return str(type_spec) if type_spec is not None else 'any'

    def _has_unresolved_dynamic_config(self) -> bool:
        """Return True if any dynamic config pattern has no cached definition.

        When a node type uses dynamic inputs/outputs (e.g. PipelineNode) but the
        referenced object hasn't been fetched from the API, we can't know what
        inputs/outputs are valid. In that case, strict validation is skipped.
        """
        params_set = set(self._PARAMS)
        for config_key, config in self._CONFIGS.items():
            object_type, id_pattern = self._parse_dynamic_pattern(config_key, params_set)
            if object_type and id_pattern:
                object_id = self._resolve_object_id(self._params.get(id_pattern))
                if object_id and not self._cached_definitions.get(object_id):
                    return True
        return False

    def _get_valid_inputs_for_params(self) -> Dict[str, Dict[str, Any]]:
        """Get valid inputs based on the current parameter values."""
        valid_inputs = {input.get('field'): dict(input) for input in self._COMMON_INPUTS}
        if self._advanced_inputs:
            valid_inputs['dependencies'] = {
                'field': 'dependencies',
                'type': 'vec<path>',
                'value': [],
            }
        params_set = set(self._PARAMS)
        # Add inputs from configs
        for config_key, config in self._CONFIGS.items():
            matches, generic_params = self._match_config_key(
                config_key, self._params, params_set
            )
            if matches:
                # Check if this is a dynamic config
                object_type, id_pattern = self._parse_dynamic_pattern(
                    config_key, params_set
                )
                if object_type and id_pattern:
                    object_id = self._resolve_object_id(self._params.get(id_pattern))
                    object_def = self._cached_definitions.get(object_id)
                    if object_def:
                        for (
                            input_name,
                            input_type,
                        ) in object_def.inputs.items():
                            valid_inputs[input_name] = {
                                'field': input_name,
                                'type': self._normalize_type_spec(input_type),
                                'helper_text': f"Input from {object_type} {object_id}",
                                'value': None,
                            }
                else:
                    # Handle regular config inputs
                    for input_def in config.get('inputs', []):
                        field = input_def['field']
                        resolved_type = str(input_def['type'])

                        # Resolve all generic params in the type
                        for gk, gv in generic_params.items():
                            resolved_type = resolved_type.replace(gk, gv)
                        input_copy = dict(input_def)
                        input_copy['type'] = resolved_type

                        valid_inputs[field] = input_copy

        if 'inputs' in self.__dict__:
            fields_to_add = {}
            fields_to_remove = set()
            for field in list(valid_inputs):
                if field.startswith("[") and field.endswith("]"):
                    inputs_map = self.inputs
                    for part in field[1:-1].split("."):
                        inputs_map = inputs_map.get(part, {})
                    if isinstance(inputs_map, dict):
                        for key, type_val in inputs_map.items():
                            fields_to_add[key] = {
                                'field': key,
                                'type': str(type_val) if type_val else 'any',
                                'value': None,
                            }
                    fields_to_remove.add(field)
            for f in fields_to_remove:
                valid_inputs.pop(f, None)
            valid_inputs.update(fields_to_add)

        # Apply batch mode vectorization
        if self.execution_mode == 'batch' and self._batch_mode_allowed:
            for field, input_def in valid_inputs.items():
                if is_field_vectorizable(field, input_def, self._list_mode_fields):
                    current_type = input_def.get('type', '')
                    # Batch mode adds one extra vec<> layer, even for vec<T>.
                    input_def['type'] = wrap_batch_type(current_type)

        return valid_inputs

    def _get_valid_outputs_for_params(self) -> List[str]:
        """Get valid outputs based on the current parameter values."""
        valid_outputs = set(output.get('field') for output in self._COMMON_OUTPUTS)
        params_set = set(self._PARAMS)
        for config_key, config in self._CONFIGS.items():
            matches, _ = self._match_config_key(config_key, self._params, params_set)
            if matches:
                # Check if this is a dynamic config
                object_type, id_pattern = self._parse_dynamic_pattern(
                    config_key, params_set
                )
                if object_type and id_pattern:
                    object_id = self._resolve_object_id(self._params.get(id_pattern))
                    object_def = self._cached_definitions.get(object_id)
                    if object_def:
                        valid_outputs.update(object_def.outputs.keys())
                else:
                    # Handle regular config outputs
                    if 'outputs' in config:
                        for output_def in config['outputs']:
                            valid_outputs.add(output_def['field'])

        # handle dynamic outputs dependent on inputs
        fields_to_add = set()
        fields_to_remove = set()
        for field in valid_outputs:
            if field.startswith("[") and field.endswith("]"):
                stripped_parts = field[1:-1].split(".")
                inputs_map = self.inputs
                for part in stripped_parts:
                    inputs_map = inputs_map.get(part, {})
                fields_to_add.update(inputs_map.keys())
                fields_to_remove.add(field)

        # Add the collected fields after iteration
        valid_outputs.update(fields_to_add)
        valid_outputs -= fields_to_remove
        valid_outputs.add("complete")
        return list(valid_outputs)

    def set_output_name_attributes(self):
        """Set the output name attributes for the node."""
        self.outputs = self._get_valid_outputs_for_params()
        for output in self.outputs:
            if output in self.__dict__:
                continue

            def make_property(output_name):
                return property(lambda self, name=output_name: self.__getattr__(name))

            setattr(self.__class__, output, make_property(output))
        self._resolve_dynamic_inputs()

    def _resolve_dynamic_inputs(self):
        """Expand bracket input patterns and promote schema values to top-level inputs."""
        valid_inputs = self._get_valid_inputs_for_params()

        dynamic_names = set()
        for field, inp in valid_inputs.items():
            if field not in self.inputs._input_types:
                self.inputs._input_types[field] = self._normalize_type_spec(
                    inp.get('type', '')
                )
                dynamic_names.add(field)

        if not dynamic_names:
            return

        for val in list(self.inputs.values()):
            if not isinstance(val, list):
                continue
            for entry in val:
                if not isinstance(entry, dict):
                    continue
                for key_field in ('name', 'id', 'key'):
                    name = entry.get(key_field)
                    if name and name in dynamic_names:
                        v = entry.get('value')
                        if v is not None and v != '':
                            self.inputs[name] = v
                        break

    def update_inputs(self, **kwargs):
        """Update input values for the node.

        Args:
            **kwargs: Input values to update

        Raises:
            ValueError: If an invalid input is provided for the current configuration
        """
        # Get valid inputs for current params
        valid_inputs = self._get_valid_inputs_for_params()

        metadata_fields = {'variant', 'is_iframe'}

        if not self._has_unresolved_dynamic_config():
            invalid_inputs = []
            for key in kwargs:
                if key.startswith('[') and key.endswith(']'):
                    continue
                if key not in valid_inputs and key not in metadata_fields:
                    invalid_inputs.append(key)
            if invalid_inputs:
                param_str = ", ".join(f"{k}={v!r}" for k, v in self._params.items())
                raise ValueError(
                    f"Invalid input(s) for current parameters ({param_str}): {invalid_inputs}\n"
                    f"Available inputs: {list(valid_inputs.keys())}"
                )

        # Update valid inputs
        for key, value in kwargs.items():
            if key.startswith('[') and key.endswith(']'):
                continue
            self.inputs[key] = value

    def _check_visibility_warnings(self):
        """Warn when user sets values for inputs hidden by visibility rules.

        Iterates over matching ``_CONFIGS`` entries, evaluates ``visibility``
        rules on each input, and emits a :class:`UserWarning` when a
        user-supplied value is set on a field whose visibility condition
        evaluates to ``False``.
        """
        import warnings

        params_set = set(self._PARAMS)

        for config_key, config in self._CONFIGS.items():
            matches, _ = self._match_config_key(config_key, self._params, params_set)
            if not matches:
                continue

            for input_def in config.get('inputs', []):
                field = input_def.get('field', '')
                visibility = input_def.get('visibility')
                if not visibility or field not in self.inputs:
                    continue

                # Only warn if the user set a non-default value
                user_value = self.inputs.get(field)
                default_value = input_def.get('value')
                if user_value == default_value or user_value is None:
                    continue

                if not self._evaluate_visibility(visibility):
                    warnings.warn(
                        f"{self.__class__.__name__}: '{field}' is set but "
                        f"hidden in the current configuration "
                        f"({', '.join(f'{k}={v!r}' for k, v in self._params.items())}). "
                        f"The value may be ignored at runtime.",
                        UserWarning,
                        stacklevel=4,
                    )

    def _evaluate_visibility(self, visibility: dict) -> bool:
        """Evaluate a visibility rule against the current inputs.

        Handles simple rules::

            {"field": "use_personal_api_key", "operator": "==", "value": True}

        And compound rules::

            {"logic": "AND", "conditions": [<rule>, <rule>, ...]}
        """
        if 'logic' in visibility:
            conditions = visibility.get('conditions', [])
            if visibility['logic'] == 'AND':
                return all(self._evaluate_visibility(c) for c in conditions)
            elif visibility['logic'] == 'OR':
                return any(self._evaluate_visibility(c) for c in conditions)
            return True

        field = visibility.get('field', '')
        operator = visibility.get('operator', '==')
        expected = visibility.get('value')
        actual = self.inputs.get(field)

        if operator == '==':
            return actual == expected
        elif operator == '!=':
            return actual != expected

        return True

    def get_dependencies(
        self,
    ) -> tuple[set[tuple[str, str | None]], set[tuple[str, str | None]]]:
        """Get the dependency (node_id, field_name) pairs of the node."""
        non_cyclic_dependencies: set[tuple[str, str | None]] = set()
        dependencies: set[tuple[str, str | None]] = set()
        for input_value in self.inputs.values():
            node_input_deps = extract_dependencies_from_node_input(input_value)
            non_cyclic_dependencies.update(node_input_deps - dependencies)
            dependencies.update(node_input_deps)

        for cyclic_input_value in self.cyclic_inputs.values():
            node_input_deps = extract_dependencies_from_node_input(cyclic_input_value)
            dependencies.update(node_input_deps)

        return non_cyclic_dependencies, dependencies

    def add_cyclic_input(self, key: str, value: str):
        """Add a cyclic input to the node. This input value will be used during subsequent iterations of the node after the first iteration."""
        # Get valid inputs for current params
        valid_inputs = self._get_valid_inputs_for_params()
        if key not in valid_inputs:
            return
        self.cyclic_inputs[key] = value

    def set_node_task_name(self):
        """Set the task name based on the current parameterization."""
        if not hasattr(self, '_CONFIGS') or not hasattr(self, '_PARAMS'):
            self.task_name = self.node_type
            return

        # Get current parameter values
        current_params = []
        for param in self._PARAMS:
            if param in self.inputs:
                current_params.append(str(self.inputs[param]))
            else:
                current_params.append("(*)")

        # Find matching config
        for config_key, config_value in self._CONFIGS.items():
            config_parts = config_key.split("**")

            # Check if this config matches current parameters
            if len(config_parts) == len(current_params):
                matches = True
                for i, (config_part, current_param) in enumerate(
                    zip(config_parts, current_params)
                ):
                    # (*) matches any value, otherwise exact match required
                    if config_part != "(*)" and config_part != current_param:
                        matches = False
                        break

                if matches and "task_name" in config_value:
                    self.task_name = config_value["task_name"]
                    return

        # Fallback to node type if no matching config found
        self.task_name = self.node_type

    def __str__(self) -> str:
        """Return a string representation of the node as a constructor call.

        Returns:
            A string in the format ClassName(input1="value1", input2="value2", ...)
        """
        # Get the actual class name
        class_name = self.__class__.__name__

        # Format each input as a key=value pair, properly handling different types
        input_pairs = []
        for field, value in self.inputs.items():
            if value is not None:  # Only include non-None values
                if isinstance(value, str):
                    formatted_value = f'"{value}"'
                elif isinstance(value, (list, dict)):
                    formatted_value = repr(value)
                else:
                    formatted_value = str(value)
                input_pairs.append(f"{field}={formatted_value}")

        # Join all input pairs with commas
        inputs_str = ", ".join(input_pairs)

        return f"{class_name}({inputs_str})"

    def __repr__(self) -> str:
        """Return a detailed string representation of the node showing type, parameters, inputs, and outputs.

        Returns:
            A formatted string showing the node's type, current inputs, and available outputs.
        """
        # Get the actual class name without the module prefix
        class_name = self.__class__.__name__

        # Format inputs section
        input_lines = []
        for field, value in self.inputs.items():
            # Format the value, handling special cases
            if isinstance(value, (list, dict)):
                formatted_value = repr(value)
            elif value is None:
                formatted_value = "None"
            else:
                formatted_value = f"'{value}'" if isinstance(value, str) else str(value)
            input_lines.append(f"    {field}: {formatted_value}")
        inputs_str = "\n".join(input_lines) if input_lines else "    None"

        # Format outputs section
        output_lines = []
        for output in self.outputs:
            output_lines.append(f"    {output}")
        outputs_str = "\n".join(output_lines) if output_lines else "    None"

        # Build the complete string
        return f"""{class_name} (id: {self.id})

Inputs:
{inputs_str}

Outputs:
{outputs_str}"""


def extract_dependencies_from_node_input(node_input: Any) -> set[tuple[str, str | None]]:
    """Extract dependency (node_id, field_name) pairs from a node input."""
    dependencies: set[tuple[str, str | None]] = set()
    if isinstance(node_input, str):
        matches = _VARIABLE_REGEX.findall(node_input)

        for match in matches:
            if "." in match:
                parts = match.split(".")
                node_id = parts[0]
                field_name = parts[1] if len(parts) > 1 else None
                dependencies.add((node_id, field_name))

    elif isinstance(node_input, list):
        for item in node_input:
            dependencies.update(extract_dependencies_from_node_input(item))

    elif isinstance(node_input, dict):
        for value in node_input.values():
            dependencies.update(extract_dependencies_from_node_input(value))

    return dependencies
