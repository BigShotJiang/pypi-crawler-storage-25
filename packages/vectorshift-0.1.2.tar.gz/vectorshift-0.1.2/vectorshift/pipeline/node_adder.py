"""
Fluent builder for adding nodes to a Pipeline.

Usage::

    pipeline = Pipeline.new(name="My Pipeline")
    inp = pipeline.add(name="query").input(input_type="string")
    llm = pipeline.add(name="summarizer").llm(provider="openai", model="gpt-4o", stream=False, prompt=inp.text)
    out = pipeline.add(name="result").output(output_type="string", value=llm.response)
    pipeline.save()
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional

from .node import Node

if TYPE_CHECKING:
    from .object import Pipeline


class NodeAdder:
    """Fluent builder that creates nodes and auto-appends them to a pipeline.

    Call ``pipeline.add(name=..., id=...)`` to prime the builder with a display
    name and/or explicit ID, then call the node-type method::

        node = pipeline.add(name="my_llm", id="llm_1").llm(provider="openai", ...)

    The ``id`` argument is optional::

        node = pipeline.add(name="my_llm").llm(provider="openai", ...)

    At runtime the node-type method (e.g. ``.llm(...)``) looks up the node class
    in :attr:`Node._node_registry`, injects ``node_name`` / ``id`` from the
    primed values, creates the node, and appends it to the pipeline's node list.

    Type stubs in ``node_adder.pyi`` provide IDE autocomplete with full
    overloaded signatures and return-type narrowing.
    """

    __slots__ = ("_pipeline", "_name", "_id", "_execution_mode")

    def __init__(
        self,
        pipeline: Pipeline,
        *,
        name: Optional[str] = None,
        id: Optional[str] = None,
        execution_mode: Optional[str] = None,
    ) -> None:
        self._pipeline = pipeline
        self._name = name
        self._id = id
        self._execution_mode = execution_mode

    def __call__(
        self,
        *,
        name: str,
        id: Optional[str] = None,
    ) -> NodeAdder:
        """Prime the builder with a display name and/or explicit node ID.

        Returns a new :class:`NodeAdder` bound to the same pipeline but
        carrying ``name`` and ``id`` that will be injected into the next
        node-type call.
        """
        return NodeAdder(
            self._pipeline, name=name, id=id, execution_mode=self._execution_mode
        )

    def __getattr__(self, node_type: str) -> Any:
        if node_type.startswith("_"):
            raise AttributeError(node_type)

        node_class = Node._node_registry.get(node_type)
        if node_class is None:
            raise AttributeError(
                f"Unknown node type: {node_type!r}. "
                f"Available types: {sorted(Node._node_registry.keys())}"
            )

        pipeline = self._pipeline
        primed_name = self._name
        primed_id = self._id

        primed_execution_mode = self._execution_mode

        def _factory(**kwargs: Any) -> Any:
            if primed_name is not None:
                kwargs["node_name"] = primed_name
            if primed_id is not None:
                kwargs["id"] = primed_id
            if primed_execution_mode is not None:
                kwargs.setdefault("execution_mode", primed_execution_mode)
            node = node_class(**kwargs)
            pipeline._replace_or_append(node)
            return node

        return _factory
