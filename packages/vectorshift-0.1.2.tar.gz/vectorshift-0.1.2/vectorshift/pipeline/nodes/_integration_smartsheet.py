"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_smartsheet")
class IntegrationSmartsheetNode(Node):
    """
    Smartsheet

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your Smartsheet account
    ### When action = 'create_comment'
        text: Text of the comment
        discussion_id: ID of the discussion to retrieve
        sheet_id: Select the sheet to retrieve
    ### When action = 'edit_comment'
        text: Text of the comment
        comment_id: ID of the comment to retrieve
        sheet_id: Select the sheet to retrieve
    ### When action = 'search_sheet'
        query: Text to search for in the sheet
        sheet_id: Select the sheet to retrieve
    ### When action = 'search_everything'
        query: Text to search for in the sheet
    ### When action = 'add_rows' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'update_rows' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'add_image_to_cell'
        alt_text: Alternative text for the image for accessibility
        column_id: Select the column to sort by
        file: Upload an image file (PNG, JPG, JPEG, or GIF) to add to the cell
        row_id: Select the row to retrieve
        sheet_id: Select the sheet to retrieve
    ### When action = 'get_attachment'
        attachment_id: ID of the attachment to retrieve
        sheet_id: Select the sheet to retrieve
    ### When action = 'attach_file_or_url'
        attachment_subtype: Subtype for Google Drive attachments (DOCUMENT, SPREADSHEET, PRESENTATION, PDF, DRAWING)
        attachment_type: Type of attachment
        description: Description of the column
        name: Name of the new sheet
        sheet_id: Select the sheet to retrieve
        url: URL to attach (can be a regular link or a link to Google Drive, Dropbox, OneDrive, etc.)
    ### When action = 'sort_rows'
        column_id: Select the column to sort by
        descending: Sort in descending order (Z to A, newest first)
        sheet_id: Select the sheet to retrieve
    ### When action = 'get_column'
        column_id: Select the column to sort by
        sheet_id: Select the sheet to retrieve
    ### When action = 'update_column'
        column_id: Select the column to sort by
        description: Description of the column
        hidden: Hide this column
        index: Position to insert the column (0 = first column)
        locked: Lock this column
        options: Comma-separated options for Dropdown List or Multi-Select Dropdown types
        sheet_id: Select the sheet to retrieve
        title: Title of the new column
        type: Type of the column
    ### When action = 'delete_column'
        column_id: Select the column to sort by
        sheet_id: Select the sheet to retrieve
    ### When action = 'get_comment'
        comment_id: ID of the comment to retrieve
        sheet_id: Select the sheet to retrieve
    ### When action = 'delete_comment'
        comment_id: ID of the comment to retrieve
        sheet_id: Select the sheet to retrieve
    ### When action = 'create_discussion'
        comment_text: Initial comment text for the discussion
        row_id: Select the row to retrieve
        sheet_id: Select the sheet to retrieve
    ### When action = 'add_columns'
        description: Description of the column
        index: Position to insert the column (0 = first column)
        options: Comma-separated options for Dropdown List or Multi-Select Dropdown types
        sheet_id: Select the sheet to retrieve
        title: Title of the new column
        type: Type of the column
        width: Width of the column in pixels
    ### When action = 'create_sheet'
        destination_id: Select a workspace or folder to create the sheet in (leave empty for Home)
        name: Name of the new sheet
        primary_column_title: Title of the primary column (required for every sheet)
    ### When action = 'copy_sheet'
        destination_id: Select a workspace or folder to create the sheet in (leave empty for Home)
        new_name: Name for the copied sheet
        sheet_id: Select the sheet to retrieve
    ### When action = 'move_sheet'
        destination_id: Select a workspace or folder to create the sheet in (leave empty for Home)
        sheet_id: Select the sheet to retrieve
    ### When action = 'create_folder'
        destination_id: Select a workspace or folder to create the sheet in (leave empty for Home)
        name: Name of the new sheet
    ### When action = 'copy_folder'
        destination_id: Select a workspace or folder to create the sheet in (leave empty for Home)
        folder_id: Select the folder to retrieve
        include: Comma-separated list of elements to copy: attachments, cellLinks, data, discussions, filters, forms, ruleRecipients, rules, shares
        new_name: Name for the copied sheet
    ### When action = 'move_folder'
        destination_id: Select a workspace or folder to create the sheet in (leave empty for Home)
        folder_id: Select the folder to retrieve
    ### When action = 'copy_rows'
        destination_sheet_id: Select the sheet to copy rows to
        row_ids: Comma-separated list of row IDs to delete
        sheet_id: Select the sheet to retrieve
    ### When action = 'move_rows'
        destination_sheet_id: Select the sheet to copy rows to
        row_ids: Comma-separated list of row IDs to delete
        sheet_id: Select the sheet to retrieve
    ### When action = 'get_discussion'
        discussion_id: ID of the discussion to retrieve
        sheet_id: Select the sheet to retrieve
    ### When action = 'list_discussion_attachments'
        discussion_id: ID of the discussion to retrieve
        limit: Maximum number of sheets to return
        sheet_id: Select the sheet to retrieve
    ### When action = 'get_folder_children'
        folder_id: Select the folder to retrieve
    ### When action = 'update_folder'
        folder_id: Select the folder to retrieve
        name: Name of the new sheet
    ### When action = 'delete_folder'
        folder_id: Select the folder to retrieve
    ### When action = 'delete_rows'
        ignore_rows_not_found: If true, don't error if some row IDs don't exist
        row_ids: Comma-separated list of row IDs to delete
        sheet_id: Select the sheet to retrieve
    ### When action = 'list_discussions'
        include_all: If true, includes all comments in each discussion
        limit: Maximum number of sheets to return
        sheet_id: Select the sheet to retrieve
    ### When action = 'list_sheets'
        limit: Maximum number of sheets to return
    ### When action = 'list_workspaces'
        limit: Maximum number of sheets to return
    ### When action = 'update_sheet'
        name: Name of the new sheet
        sheet_id: Select the sheet to retrieve
    ### When action = 'create_workspace'
        name: Name of the new sheet
    ### When action = 'update_workspace'
        name: Name of the new sheet
        workspace_id: Select the workspace to retrieve
    ### When action = 'get_row'
        row_id: Select the row to retrieve
        sheet_id: Select the sheet to retrieve
    ### When action = 'update_rows'
        row_id: Select the row to retrieve
        sheet_id: Select the sheet to retrieve
    ### When action = 'get_sheet'
        sheet_id: Select the sheet to retrieve
    ### When action = 'delete_sheet'
        sheet_id: Select the sheet to retrieve
    ### When action = 'add_rows'
        sheet_id: Select the sheet to retrieve
    ### When action = 'get_columns'
        sheet_id: Select the sheet to retrieve
    ### When action = 'get_workspace_children'
        workspace_id: Select the workspace to retrieve

    ## Outputs
    ### When action = 'get_sheet' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.outputs]: The [<A>.outputs] output
    ### When action = 'get_row' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.outputs]: The [<A>.outputs] output
    ### When action = 'create_sheet'
        access_level: Your access level to this sheet
        name: Name of the created sheet
        permalink: URL to access the sheet
        raw_data: Raw API response data
        sheet_id: Unique identifier of the created sheet
    ### When action = 'get_sheet'
        access_level: Your access level to this sheet
        column_count: Number of columns in the sheet
        column_ids: List of column IDs
        column_names: List of column names
        created_at: When the sheet was created
        modified_at: When the sheet was last modified
        name: Name of the sheet
        permalink: URL to access the sheet
        raw_data: Raw API response data
        row_ids: List of row IDs
        row_numbers: List of row numbers
        sheet_id: Unique identifier of the sheet
        total_row_count: Total number of rows in the sheet
    ### When action = 'create_workspace'
        access_level: Your access level to this workspace
        name: Name of the workspace
        permalink: URL to access the workspace
        raw_data: Raw API response data
        workspace_id: ID of the created workspace
    ### When action = 'get_workspace_children'
        access_level: Your access level to this workspace
        folder_ids: IDs of folders in this workspace
        folder_names: Names of folders in this workspace
        name: Name of the workspace
        permalink: URL to access the workspace
        raw_data: Raw API response data
        sheet_ids: IDs of sheets in this workspace
        sheet_names: Names of sheets in this workspace
        workspace_id: ID of the workspace
    ### When action = 'attach_file_or_url'
        attachment_id: ID of the created attachment
        attachment_type: Type of the attachment
        name: Name of the attachment
        raw_data: Raw API response data
        url: URL of the attachment
    ### When action = 'get_attachment'
        attachment_id: ID of the attachment
        attachment_type: Type of the attachment
        created_at: When the attachment was created
        created_by_name: Name of the user who created the attachment
        mime_type: MIME type of the attachment
        name: Name of the attachment
        raw_data: Raw API response data
        size_in_kb: Size of the attachment in KB
        url: URL to download the attachment
    ### When action = 'list_discussion_attachments'
        attachment_ids: List of attachment IDs
        attachment_names: List of attachment names
        attachment_types: List of attachment types
        attachment_urls: List of attachment URLs
        raw_data: Raw API response data
        total_count: Total number of attachments
    ### When action = 'get_comment'
        attachment_ids: IDs of attachments on this comment
        attachment_names: Names of attachments on this comment
        comment_id: ID of the comment
        created_at: When the comment was created
        created_by: Email of the comment author
        discussion_id: ID of the parent discussion
        modified_at: When the comment was last modified
        modified_by: Email of who last modified the comment
        raw_data: Raw API response data
        text: Text of the comment
    ### When action = 'get_row'
        cell_column_ids: Column IDs for each cell
        cell_display_values: Display values of all cells
        cell_values: Values of all cells in the row
        created_at: When the row was created
        expanded: Whether the row is expanded
        modified_at: When the row was last modified
        raw_data: Raw API response data
        row_id: Unique identifier of the row
        row_number: Row number in the sheet
        sheet_id: ID of the sheet containing the row
    ### When action = 'add_columns'
        column_id: ID of the created column
        index: Position of the column
        raw_data: Raw API response data
        title: Title of the column
        type: Type of the column
    ### When action = 'get_column'
        column_id: ID of the column
        description: Description of the column
        hidden: Whether the column is hidden
        index: Position of the column
        locked: Whether the column is locked
        options: Dropdown options (if applicable)
        primary: Whether this is the primary column
        raw_data: Raw API response data
        title: Title of the column
        type: Type of the column
        validation: Whether validation is enabled
        width: Width of the column in pixels
    ### When action = 'update_column'
        column_id: ID of the updated column
        index: Updated position
        raw_data: Raw API response data
        title: Updated title
        type: Updated type
    ### When action = 'delete_column'
        column_id: ID of the deleted column
        message: Deletion status message
        raw_data: Raw API response data
        sheet_id: ID of the sheet
    ### When action = 'add_image_to_cell'
        column_id: ID of the column
        file_name: Name of the uploaded image file
        raw_data: Raw API response data
        row_id: ID of the row
    ### When action = 'get_columns'
        column_ids: List of column IDs
        column_indexes: List of column positions
        column_titles: List of column titles
        column_types: List of column types
        raw_data: Raw API response data
        total_count: Total number of columns
    ### When action = 'get_discussion'
        comment_count: Number of comments
        comment_created_at: When each comment was created
        comment_created_by: Emails of comment authors
        comment_ids: IDs of all comments
        comment_texts: Text of all comments
        discussion_id: ID of the discussion
        last_commented_at: When the last comment was added
        raw_data: Raw API response data
        title: Title of the discussion
    ### When action = 'list_discussions'
        comment_counts: Number of comments in each discussion
        created_by_emails: Email of who created each discussion
        discussion_ids: List of discussion IDs
        discussion_titles: List of discussion titles
        last_commented_ats: When each discussion was last commented on
        raw_data: Raw API response data
        total_count: Total number of discussions
    ### When action = 'create_discussion'
        comment_id: ID of the initial comment
        discussion_id: ID of the created discussion
        raw_data: Raw API response data
        title: Title of the discussion
    ### When action = 'create_comment'
        comment_id: ID of the created comment
        created_at: When the comment was created
        created_by: Email of the comment author
        discussion_id: ID of the parent discussion
        raw_data: Raw API response data
        text: Text of the comment
    ### When action = 'edit_comment'
        comment_id: ID of the updated comment
        modified_at: When the comment was modified
        raw_data: Raw API response data
        text: Updated text of the comment
    ### When action = 'delete_comment'
        comment_id: ID of the deleted comment
        message: Deletion status message
        raw_data: Raw API response data
    ### When action = 'add_rows'
        count: Number of rows added
        created_ats: Creation timestamps of the rows
        raw_data: Raw API response data
        row_ids: IDs of the created rows
        row_numbers: Row numbers of the created rows
    ### When action = 'copy_sheet'
        created_at: When the copied sheet was created
        name: Name of the copied sheet
        permalink: URL to access the copied sheet
        raw_data: Raw API response data
        sheet_id: ID of the new copied sheet
    ### When action = 'list_sheets'
        created_ats: List of sheet creation timestamps
        modified_ats: List of sheet modification timestamps
        raw_data: Raw API response data
        sheet_ids: List of sheet IDs
        sheet_names: List of sheet names
        sheet_permalinks: List of sheet URLs
        total_count: Total number of sheets returned
    ### When action = 'copy_rows'
        destination_sheet_id: ID of the destination sheet
        new_row_ids: IDs of the newly created rows
        raw_data: Raw API response data
    ### When action = 'move_rows'
        destination_sheet_id: ID of the destination sheet
        new_row_ids: IDs of the moved rows in the destination
        raw_data: Raw API response data
    ### When action = 'create_folder'
        folder_id: ID of the created folder
        name: Name of the folder
        permalink: URL to access the folder
        raw_data: Raw API response data
    ### When action = 'get_folder_children'
        folder_id: ID of the folder
        name: Name of the folder
        permalink: URL to access the folder
        raw_data: Raw API response data
        sheet_ids: IDs of sheets in this folder
        sheet_names: Names of sheets in this folder
        subfolder_ids: IDs of subfolders
        subfolder_names: Names of subfolders
    ### When action = 'update_folder'
        folder_id: ID of the updated folder
        name: Updated name of the folder
        raw_data: Raw API response data
    ### When action = 'delete_folder'
        folder_id: ID of the deleted folder
        message: Deletion status message
        raw_data: Raw API response data
    ### When action = 'copy_folder'
        folder_id: ID of the new copied folder
        name: Name of the copied folder
        permalink: URL to access the copied folder
        raw_data: Raw API response data
    ### When action = 'move_folder'
        folder_id: ID of the moved folder
        name: Name of the folder
        permalink: URL to access the folder
        raw_data: Raw API response data
    ### When action = 'delete_sheet'
        message: Deletion status message
        raw_data: Raw API response data
        sheet_id: ID of the deleted sheet
    ### When action = 'delete_rows'
        message: Deletion status message
        raw_data: Raw API response data
        row_ids: IDs of the deleted rows
        sheet_id: ID of the sheet
    ### When action = 'update_sheet'
        modified_at: When the sheet was last modified
        name: Updated name of the sheet
        permalink: URL to access the sheet
        raw_data: Raw API response data
        sheet_id: Unique identifier of the updated sheet
    ### When action = 'move_sheet'
        modified_at: When the sheet was last modified
        name: Name of the sheet
        permalink: URL to access the sheet
        raw_data: Raw API response data
        sheet_id: ID of the moved sheet
    ### When action = 'update_rows'
        modified_at: When the row was last modified
        raw_data: Raw API response data
        row_id: ID of the updated row
        row_number: New row number
        sheet_id: ID of the sheet
    ### When action = 'update_workspace'
        name: Updated name of the workspace
        permalink: URL to access the workspace
        raw_data: Raw API response data
        workspace_id: ID of the updated workspace
    ### When action = 'search_sheet'
        object_ids: List of IDs of matching objects
        object_types: Types of matching objects (row, cell, etc.)
        raw_data: Raw API response data
        texts: Matching text content
        total_count: Total number of matches
    ### When action = 'search_everything'
        object_ids: IDs of matching objects
        object_names: Names of matching objects
        object_types: Types of matching objects
        raw_data: Raw API response data
        texts: Matching text content
        total_count: Total number of matches
    ### When action = 'sort_rows'
        raw_data: Raw API response data
        row_ids: Row IDs in new sorted order
        row_numbers: Row numbers in new sorted order
        sheet_id: ID of the sorted sheet
    ### When action = 'list_workspaces'
        raw_data: Raw API response data
        total_count: Total number of workspaces returned
        workspace_ids: List of workspace IDs
        workspace_names: List of workspace names
        workspace_permalinks: List of workspace URLs
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Smartsheet account",
            "value": None,
            "type": "integration<Smartsheet>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)**(*)": {
            "inputs": [],
            "outputs": [],
            "variant": "common_integration_nodes",
        },
        "create_sheet**(*)": {
            "inputs": [
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Sheet Name",
                    "placeholder": "My New Sheet",
                    "helper_text": "Name of the new sheet",
                },
                {
                    "field": "destination_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Destination",
                    "helper_text": "Select a workspace or folder to create the sheet in (leave empty for Home)",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
                {
                    "field": "primary_column_title",
                    "type": "string",
                    "value": "Primary Column",
                    "label": "Primary Column Title",
                    "placeholder": "Primary Column",
                    "helper_text": "Title of the primary column (required for every sheet)",
                },
            ],
            "outputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created sheet",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Name of the created sheet",
                },
                {
                    "field": "permalink",
                    "type": "string",
                    "helper_text": "URL to access the sheet",
                },
                {
                    "field": "access_level",
                    "type": "string",
                    "helper_text": "Your access level to this sheet",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_sheet",
            "task_name": "tasks.smartsheet.create_sheet",
            "description": "Create a new sheet in Smartsheet",
            "label": "Create Sheet",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "destination_id",
                "name",
                "primary_column_title",
            ],
            "required": ["name"],
        },
        "get_sheet**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet to retrieve",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the sheet",
                },
                {"field": "name", "type": "string", "helper_text": "Name of the sheet"},
                {
                    "field": "permalink",
                    "type": "string",
                    "helper_text": "URL to access the sheet",
                },
                {
                    "field": "access_level",
                    "type": "string",
                    "helper_text": "Your access level to this sheet",
                },
                {
                    "field": "total_row_count",
                    "type": "int32",
                    "helper_text": "Total number of rows in the sheet",
                },
                {
                    "field": "column_count",
                    "type": "int32",
                    "helper_text": "Number of columns in the sheet",
                },
                {
                    "field": "column_names",
                    "type": "vec<string>",
                    "helper_text": "List of column names",
                },
                {
                    "field": "column_ids",
                    "type": "vec<string>",
                    "helper_text": "List of column IDs",
                },
                {
                    "field": "row_ids",
                    "type": "vec<string>",
                    "helper_text": "List of row IDs",
                },
                {
                    "field": "row_numbers",
                    "type": "vec<int32>",
                    "helper_text": "List of row numbers",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the sheet was created",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "When the sheet was last modified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_sheet",
            "task_name": "tasks.smartsheet.get_sheet",
            "description": "Get details of a sheet",
            "label": "Read from Sheet",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["action", "integration", "sheet_id"],
            "required": ["sheet_id"],
        },
        "get_sheet**[endpoint_0.<A>]": {
            "inputs": [],
            "outputs": [{"field": "[<A>.outputs]", "type": ""}],
        },
        "list_sheets**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of sheets to return",
                }
            ],
            "outputs": [
                {
                    "field": "sheet_ids",
                    "type": "vec<string>",
                    "helper_text": "List of sheet IDs",
                },
                {
                    "field": "sheet_names",
                    "type": "vec<string>",
                    "helper_text": "List of sheet names",
                },
                {
                    "field": "sheet_permalinks",
                    "type": "vec<string>",
                    "helper_text": "List of sheet URLs",
                },
                {
                    "field": "created_ats",
                    "type": "vec<string>",
                    "helper_text": "List of sheet creation timestamps",
                },
                {
                    "field": "modified_ats",
                    "type": "vec<string>",
                    "helper_text": "List of sheet modification timestamps",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of sheets returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_sheets",
            "task_name": "tasks.smartsheet.list_sheets",
            "description": "List all sheets in your account",
            "label": "List Sheets",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["action", "integration", "limit"],
            "required": ["limit"],
        },
        "update_sheet**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet to update",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "New Name",
                    "placeholder": "Updated Sheet Name",
                    "helper_text": "New name for the sheet",
                },
            ],
            "outputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the updated sheet",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Updated name of the sheet",
                },
                {
                    "field": "permalink",
                    "type": "string",
                    "helper_text": "URL to access the sheet",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "When the sheet was last modified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "update_sheet",
            "task_name": "tasks.smartsheet.update_sheet",
            "description": "Update a sheet's properties",
            "label": "Update Sheet",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["action", "integration", "sheet_id", "name"],
            "required": ["sheet_id", "name"],
        },
        "delete_sheet**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet to delete",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "helper_text": "ID of the deleted sheet",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Deletion status message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "delete_sheet",
            "task_name": "tasks.smartsheet.delete_sheet",
            "description": "Delete a sheet",
            "label": "Delete Sheet",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["action", "integration", "sheet_id"],
            "required": ["sheet_id"],
        },
        "copy_sheet**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet to copy",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "destination_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Destination",
                    "helper_text": "Select a workspace or folder to copy the sheet to (leave empty for Home)",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
                {
                    "field": "new_name",
                    "type": "string",
                    "value": "",
                    "label": "New Name",
                    "placeholder": "Copy of Sheet",
                    "helper_text": "Name for the copied sheet",
                },
            ],
            "outputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "helper_text": "ID of the new copied sheet",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Name of the copied sheet",
                },
                {
                    "field": "permalink",
                    "type": "string",
                    "helper_text": "URL to access the copied sheet",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the copied sheet was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "copy_sheet",
            "task_name": "tasks.smartsheet.copy_sheet",
            "description": "Copy a sheet to a new location",
            "label": "Copy Sheet",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "sheet_id",
                "destination_id",
                "new_name",
            ],
            "required": ["sheet_id", "new_name"],
        },
        "move_sheet**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet to move",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "destination_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Destination",
                    "helper_text": "Select a workspace or folder to move the sheet to (leave empty for Home)",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
            ],
            "outputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "helper_text": "ID of the moved sheet",
                },
                {"field": "name", "type": "string", "helper_text": "Name of the sheet"},
                {
                    "field": "permalink",
                    "type": "string",
                    "helper_text": "URL to access the sheet",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "When the sheet was last modified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "move_sheet",
            "task_name": "tasks.smartsheet.move_sheet",
            "description": "Move a sheet to a new location",
            "label": "Move Sheet",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "sheet_id",
                "destination_id",
            ],
            "required": ["sheet_id"],
        },
        "search_sheet**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet to search",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Search Query",
                    "placeholder": "Enter search term",
                    "helper_text": "Text to search for in the sheet",
                },
            ],
            "outputs": [
                {
                    "field": "object_ids",
                    "type": "vec<string>",
                    "helper_text": "List of IDs of matching objects",
                },
                {
                    "field": "object_types",
                    "type": "vec<string>",
                    "helper_text": "Types of matching objects (row, cell, etc.)",
                },
                {
                    "field": "texts",
                    "type": "vec<string>",
                    "helper_text": "Matching text content",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of matches",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "search_sheet",
            "task_name": "tasks.smartsheet.search_sheet",
            "description": "Search for content within a sheet",
            "label": "Search Sheet",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["action", "integration", "sheet_id", "query"],
            "required": ["sheet_id", "query"],
        },
        "add_rows**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet to add rows to",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "row_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of the created rows",
                },
                {
                    "field": "row_numbers",
                    "type": "vec<int32>",
                    "helper_text": "Row numbers of the created rows",
                },
                {
                    "field": "created_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "Creation timestamps of the rows",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of rows added",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "add_rows",
            "task_name": "tasks.smartsheet.add_rows",
            "description": "Add a new row in the selected sheet",
            "label": "Add New Row",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["action", "integration", "sheet_id"],
            "required": ["sheet_id"],
        },
        "add_rows**[endpoint_0.<A>]": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "get_row**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet containing the row",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "row_id",
                    "type": "string",
                    "value": "",
                    "label": "Row",
                    "helper_text": "Select the row to retrieve",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=row_id&sheet_id={inputs.sheet_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "row_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the row",
                },
                {
                    "field": "sheet_id",
                    "type": "string",
                    "helper_text": "ID of the sheet containing the row",
                },
                {
                    "field": "row_number",
                    "type": "int32",
                    "helper_text": "Row number in the sheet",
                },
                {
                    "field": "expanded",
                    "type": "bool",
                    "helper_text": "Whether the row is expanded",
                },
                {
                    "field": "cell_values",
                    "type": "vec<string>",
                    "helper_text": "Values of all cells in the row",
                },
                {
                    "field": "cell_column_ids",
                    "type": "vec<string>",
                    "helper_text": "Column IDs for each cell",
                },
                {
                    "field": "cell_display_values",
                    "type": "vec<string>",
                    "helper_text": "Display values of all cells",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the row was created",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "When the row was last modified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_row",
            "task_name": "tasks.smartsheet.get_row",
            "description": "Get details of a specific row",
            "label": "Get Row",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["action", "integration", "sheet_id", "row_id"],
            "required": ["sheet_id", "row_id"],
        },
        "get_row**[endpoint_0.<A>]": {
            "inputs": [],
            "outputs": [{"field": "[<A>.outputs]", "type": ""}],
        },
        "update_rows**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet containing the rows",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "row_id",
                    "type": "string",
                    "value": "",
                    "label": "Row",
                    "helper_text": "Select the row to update",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=row_id&sheet_id={inputs.sheet_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "row_id",
                    "type": "string",
                    "helper_text": "ID of the updated row",
                },
                {
                    "field": "sheet_id",
                    "type": "string",
                    "helper_text": "ID of the sheet",
                },
                {
                    "field": "row_number",
                    "type": "int32",
                    "helper_text": "New row number",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "When the row was last modified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "update_rows",
            "task_name": "tasks.smartsheet.update_rows",
            "description": "Update the row with the specified values",
            "label": "Update Row",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["action", "integration", "sheet_id", "row_id"],
            "required": ["sheet_id", "row_id"],
        },
        "update_rows**[endpoint_0.<A>]": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "delete_rows**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet containing the rows",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "row_ids",
                    "type": "string",
                    "value": "",
                    "label": "Row IDs",
                    "placeholder": "123456,789012,345678",
                    "helper_text": "Comma-separated list of row IDs to delete",
                },
                {
                    "field": "ignore_rows_not_found",
                    "type": "bool",
                    "value": True,
                    "label": "Ignore Missing Rows",
                    "helper_text": "If true, don't error if some row IDs don't exist",
                },
            ],
            "outputs": [
                {
                    "field": "row_ids",
                    "type": "string",
                    "helper_text": "IDs of the deleted rows",
                },
                {
                    "field": "sheet_id",
                    "type": "string",
                    "helper_text": "ID of the sheet",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Deletion status message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "delete_rows",
            "task_name": "tasks.smartsheet.delete_rows",
            "description": "Delete one or more rows from a sheet",
            "label": "Delete Rows",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "sheet_id",
                "row_ids",
                "ignore_rows_not_found",
            ],
            "required": ["sheet_id", "row_ids"],
        },
        "copy_rows**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Source Sheet",
                    "helper_text": "Select the sheet to copy rows from",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "destination_sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Destination Sheet",
                    "helper_text": "Select the sheet to copy rows to",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "row_ids",
                    "type": "string",
                    "value": "",
                    "label": "Row IDs",
                    "placeholder": "123456,789012,345678",
                    "helper_text": "Comma-separated list of row IDs to copy",
                },
            ],
            "outputs": [
                {
                    "field": "destination_sheet_id",
                    "type": "string",
                    "helper_text": "ID of the destination sheet",
                },
                {
                    "field": "new_row_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of the newly created rows",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "copy_rows",
            "task_name": "tasks.smartsheet.copy_rows",
            "description": "Copy rows to another sheet",
            "label": "Copy Rows To Another Sheet",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "sheet_id",
                "destination_sheet_id",
                "row_ids",
            ],
            "required": ["sheet_id", "destination_sheet_id", "row_ids"],
        },
        "move_rows**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Source Sheet",
                    "helper_text": "Select the sheet to move rows from",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "destination_sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Destination Sheet",
                    "helper_text": "Select the sheet to move rows to",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "row_ids",
                    "type": "string",
                    "value": "",
                    "label": "Row IDs",
                    "placeholder": "123456,789012,345678",
                    "helper_text": "Comma-separated list of row IDs to move",
                },
            ],
            "outputs": [
                {
                    "field": "destination_sheet_id",
                    "type": "string",
                    "helper_text": "ID of the destination sheet",
                },
                {
                    "field": "new_row_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of the moved rows in the destination",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "move_rows",
            "task_name": "tasks.smartsheet.move_rows",
            "description": "Move rows to another sheet",
            "label": "Move Rows To Another Sheet",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "sheet_id",
                "destination_sheet_id",
                "row_ids",
            ],
            "required": ["sheet_id", "destination_sheet_id", "row_ids"],
        },
        "sort_rows**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet to sort",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "column_id",
                    "type": "string",
                    "value": "",
                    "label": "Sort By Column",
                    "helper_text": "Select the column to sort by",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=column_id&sheet_id={inputs.sheet_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "descending",
                    "type": "bool",
                    "value": False,
                    "label": "Sort Descending",
                    "helper_text": "Sort in descending order (Z to A, newest first)",
                },
            ],
            "outputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "helper_text": "ID of the sorted sheet",
                },
                {
                    "field": "row_ids",
                    "type": "vec<string>",
                    "helper_text": "Row IDs in new sorted order",
                },
                {
                    "field": "row_numbers",
                    "type": "vec<int32>",
                    "helper_text": "Row numbers in new sorted order",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "sort_rows",
            "task_name": "tasks.smartsheet.sort_rows",
            "description": "Sort rows in a sheet by a column",
            "label": "Sort Rows In Sheet",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "sheet_id",
                "column_id",
                "descending",
            ],
            "required": ["sheet_id", "column_id"],
        },
        "add_columns**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet to add a column to",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "label": "Column Title",
                    "placeholder": "New Column",
                    "helper_text": "Title of the new column",
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "TEXT_NUMBER",
                    "label": "Column Type",
                    "helper_text": "Type of the column",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "smartsheet_column_type",
                    },
                },
                {
                    "field": "index",
                    "type": "int32",
                    "value": 0,
                    "label": "Position",
                    "placeholder": "0",
                    "helper_text": "Position to insert the column (0 = first column)",
                },
                {
                    "field": "options",
                    "type": "string",
                    "value": "",
                    "label": "Dropdown Options",
                    "placeholder": "Option 1, Option 2, Option 3",
                    "helper_text": "Comma-separated options for Dropdown List or Multi-Select Dropdown types",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Column description",
                    "helper_text": "Description of the column",
                },
                {
                    "field": "width",
                    "type": "int32",
                    "value": 150,
                    "label": "Width",
                    "placeholder": "150",
                    "helper_text": "Width of the column in pixels",
                },
            ],
            "outputs": [
                {
                    "field": "column_id",
                    "type": "string",
                    "helper_text": "ID of the created column",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the column",
                },
                {
                    "field": "type",
                    "type": "string",
                    "helper_text": "Type of the column",
                },
                {
                    "field": "index",
                    "type": "int32",
                    "helper_text": "Position of the column",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "add_columns",
            "task_name": "tasks.smartsheet.add_columns",
            "description": "Add a new column to a sheet",
            "label": "Add Columns to Sheet",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "sheet_id",
                "title",
                "type",
                "index",
                "options",
                "description",
                "width",
            ],
            "required": ["sheet_id", "title"],
        },
        "get_column**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet containing the column",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "column_id",
                    "type": "string",
                    "value": "",
                    "label": "Column",
                    "helper_text": "Select the column to retrieve",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=column_id&sheet_id={inputs.sheet_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "column_id",
                    "type": "string",
                    "helper_text": "ID of the column",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the column",
                },
                {
                    "field": "type",
                    "type": "string",
                    "helper_text": "Type of the column",
                },
                {
                    "field": "index",
                    "type": "int32",
                    "helper_text": "Position of the column",
                },
                {
                    "field": "primary",
                    "type": "bool",
                    "helper_text": "Whether this is the primary column",
                },
                {
                    "field": "validation",
                    "type": "bool",
                    "helper_text": "Whether validation is enabled",
                },
                {
                    "field": "width",
                    "type": "int32",
                    "helper_text": "Width of the column in pixels",
                },
                {
                    "field": "hidden",
                    "type": "bool",
                    "helper_text": "Whether the column is hidden",
                },
                {
                    "field": "locked",
                    "type": "bool",
                    "helper_text": "Whether the column is locked",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the column",
                },
                {
                    "field": "options",
                    "type": "vec<string>",
                    "helper_text": "Dropdown options (if applicable)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_column",
            "task_name": "tasks.smartsheet.get_column",
            "description": "Get details of a specific column",
            "label": "Get Column",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["action", "integration", "sheet_id", "column_id"],
            "required": ["sheet_id", "column_id"],
        },
        "get_columns**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet to get columns from",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "column_ids",
                    "type": "vec<string>",
                    "helper_text": "List of column IDs",
                },
                {
                    "field": "column_titles",
                    "type": "vec<string>",
                    "helper_text": "List of column titles",
                },
                {
                    "field": "column_types",
                    "type": "vec<string>",
                    "helper_text": "List of column types",
                },
                {
                    "field": "column_indexes",
                    "type": "vec<int32>",
                    "helper_text": "List of column positions",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of columns",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_columns",
            "task_name": "tasks.smartsheet.get_columns",
            "description": "Get all columns in a sheet",
            "label": "Get Columns",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["action", "integration", "sheet_id"],
            "required": ["sheet_id"],
        },
        "update_column**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet containing the column",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "column_id",
                    "type": "string",
                    "value": "",
                    "label": "Column",
                    "helper_text": "Select the column to update",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=column_id&sheet_id={inputs.sheet_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "index",
                    "type": "int32",
                    "value": 0,
                    "label": "Position",
                    "placeholder": "0",
                    "helper_text": "Position of the column (0-based index)",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "label": "New Title",
                    "placeholder": "Updated Column Name",
                    "helper_text": "New title for the column",
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "",
                    "label": "New Type",
                    "helper_text": "New type for the column (required when changing type or dropdown values)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "smartsheet_column_type",
                    },
                },
                {
                    "field": "options",
                    "type": "string",
                    "value": "",
                    "label": "Dropdown Options",
                    "placeholder": "Option 1, Option 2, Option 3",
                    "helper_text": "Comma-separated options for Dropdown types",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Column description",
                    "helper_text": "New description for the column",
                },
                {
                    "field": "hidden",
                    "type": "bool",
                    "value": False,
                    "label": "Hidden",
                    "helper_text": "Hide this column",
                },
                {
                    "field": "locked",
                    "type": "bool",
                    "value": False,
                    "label": "Locked",
                    "helper_text": "Lock this column",
                },
            ],
            "outputs": [
                {
                    "field": "column_id",
                    "type": "string",
                    "helper_text": "ID of the updated column",
                },
                {"field": "title", "type": "string", "helper_text": "Updated title"},
                {"field": "type", "type": "string", "helper_text": "Updated type"},
                {"field": "index", "type": "int32", "helper_text": "Updated position"},
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "update_column",
            "task_name": "tasks.smartsheet.update_column",
            "description": "Update a column's properties (index is required)",
            "label": "Update Column",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "sheet_id",
                "column_id",
                "index",
                "title",
                "type",
                "options",
                "description",
                "hidden",
                "locked",
            ],
            "required": ["sheet_id", "column_id", "index"],
        },
        "delete_column**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet containing the column",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "column_id",
                    "type": "string",
                    "value": "",
                    "label": "Column",
                    "helper_text": "Select the column to delete",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=column_id&sheet_id={inputs.sheet_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "column_id",
                    "type": "string",
                    "helper_text": "ID of the deleted column",
                },
                {
                    "field": "sheet_id",
                    "type": "string",
                    "helper_text": "ID of the sheet",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Deletion status message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "delete_column",
            "task_name": "tasks.smartsheet.delete_column",
            "description": "Delete a column from a sheet",
            "label": "Delete Column",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["action", "integration", "sheet_id", "column_id"],
            "required": ["sheet_id", "column_id"],
        },
        "add_image_to_cell**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet containing the cell",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "row_id",
                    "type": "string",
                    "value": "",
                    "label": "Row",
                    "helper_text": "Select the row containing the cell",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=row_id&sheet_id={inputs.sheet_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "column_id",
                    "type": "string",
                    "value": "",
                    "label": "Column",
                    "helper_text": "Select the column containing the cell",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=column_id&sheet_id={inputs.sheet_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "file",
                    "type": "file",
                    "value": "",
                    "label": "Image File",
                    "helper_text": "Upload an image file (PNG, JPG, JPEG, or GIF) to add to the cell",
                },
                {
                    "field": "alt_text",
                    "type": "string",
                    "value": "",
                    "label": "Image Description",
                    "placeholder": "Image description",
                    "helper_text": "Alternative text for the image for accessibility",
                },
            ],
            "outputs": [
                {"field": "row_id", "type": "string", "helper_text": "ID of the row"},
                {
                    "field": "column_id",
                    "type": "string",
                    "helper_text": "ID of the column",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the uploaded image file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "add_image_to_cell",
            "task_name": "tasks.smartsheet.add_image_to_cell",
            "description": "Add an image to a cell by uploading a file",
            "label": "Add Image To Cell",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "sheet_id",
                "row_id",
                "column_id",
                "file",
                "alt_text",
            ],
            "required": ["sheet_id", "row_id", "column_id", "file"],
        },
        "create_folder**(*)": {
            "inputs": [
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Folder Name",
                    "placeholder": "My New Folder",
                    "helper_text": "Name of the new folder",
                },
                {
                    "field": "destination_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Parent Location",
                    "helper_text": "Select a workspace or folder to create the folder in (leave empty for Home)",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the created folder",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Name of the folder",
                },
                {
                    "field": "permalink",
                    "type": "string",
                    "helper_text": "URL to access the folder",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_folder",
            "task_name": "tasks.smartsheet.create_folder",
            "description": "Create a new folder",
            "label": "Create Folder",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["action", "integration", "destination_id", "name"],
            "required": ["name"],
        },
        "get_folder_children**(*)": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Folder",
                    "helper_text": "Select the folder to retrieve",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the folder",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Name of the folder",
                },
                {
                    "field": "permalink",
                    "type": "string",
                    "helper_text": "URL to access the folder",
                },
                {
                    "field": "sheet_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of sheets in this folder",
                },
                {
                    "field": "sheet_names",
                    "type": "vec<string>",
                    "helper_text": "Names of sheets in this folder",
                },
                {
                    "field": "subfolder_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of subfolders",
                },
                {
                    "field": "subfolder_names",
                    "type": "vec<string>",
                    "helper_text": "Names of subfolders",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_folder_children",
            "task_name": "tasks.smartsheet.get_folder_children",
            "description": "Get details of a folder and its contents",
            "label": "Get Folder Children",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["action", "integration", "folder_id"],
            "required": ["folder_id"],
        },
        "update_folder**(*)": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Folder",
                    "helper_text": "Select the folder to update",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "New Name",
                    "placeholder": "Updated Folder Name",
                    "helper_text": "New name for the folder",
                },
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the updated folder",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Updated name of the folder",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "update_folder",
            "task_name": "tasks.smartsheet.update_folder",
            "description": "Update a folder's name",
            "label": "Update Folder",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["action", "integration", "folder_id", "name"],
            "required": ["folder_id", "name"],
        },
        "delete_folder**(*)": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Folder",
                    "helper_text": "Select the folder to delete",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the deleted folder",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Deletion status message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "delete_folder",
            "task_name": "tasks.smartsheet.delete_folder",
            "description": "Delete a folder",
            "label": "Delete Folder",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["action", "integration", "folder_id"],
            "required": ["folder_id"],
        },
        "copy_folder**(*)": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Folder",
                    "helper_text": "Select the folder to copy",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
                {
                    "field": "destination_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Destination",
                    "helper_text": "Select a workspace or folder to copy to (leave empty for Home)",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
                {
                    "field": "new_name",
                    "type": "string",
                    "value": "",
                    "label": "New Name",
                    "placeholder": "Copy of Folder",
                    "helper_text": "Name for the copied folder",
                },
                {
                    "field": "include",
                    "type": "string",
                    "value": "",
                    "label": "Include",
                    "placeholder": "data,attachments,discussions",
                    "helper_text": "Comma-separated list of elements to copy: attachments, cellLinks, data, discussions, filters, forms, ruleRecipients, rules, shares",
                },
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the new copied folder",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Name of the copied folder",
                },
                {
                    "field": "permalink",
                    "type": "string",
                    "helper_text": "URL to access the copied folder",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "copy_folder",
            "task_name": "tasks.smartsheet.copy_folder",
            "description": "Copy a folder to a new location",
            "label": "Copy Folder",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "folder_id",
                "destination_id",
                "new_name",
                "include",
            ],
            "required": ["folder_id", "new_name"],
        },
        "move_folder**(*)": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Folder",
                    "helper_text": "Select the folder to move",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
                {
                    "field": "destination_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Destination",
                    "helper_text": "Select a workspace or folder to move to (leave empty for Home)",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the moved folder",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Name of the folder",
                },
                {
                    "field": "permalink",
                    "type": "string",
                    "helper_text": "URL to access the folder",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "move_folder",
            "task_name": "tasks.smartsheet.move_folder",
            "description": "Move a folder to a new location",
            "label": "Move Folder",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "folder_id",
                "destination_id",
            ],
            "required": ["folder_id"],
        },
        "create_workspace**(*)": {
            "inputs": [
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Workspace Name",
                    "placeholder": "My New Workspace",
                    "helper_text": "Name of the new workspace",
                }
            ],
            "outputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "helper_text": "ID of the created workspace",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Name of the workspace",
                },
                {
                    "field": "permalink",
                    "type": "string",
                    "helper_text": "URL to access the workspace",
                },
                {
                    "field": "access_level",
                    "type": "string",
                    "helper_text": "Your access level to this workspace",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_workspace",
            "task_name": "tasks.smartsheet.create_workspace",
            "description": "Create a new workspace",
            "label": "Create Workspace",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["action", "integration", "name"],
            "required": ["name"],
        },
        "get_workspace_children**(*)": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Workspace",
                    "helper_text": "Select the workspace to retrieve",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "helper_text": "ID of the workspace",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Name of the workspace",
                },
                {
                    "field": "permalink",
                    "type": "string",
                    "helper_text": "URL to access the workspace",
                },
                {
                    "field": "access_level",
                    "type": "string",
                    "helper_text": "Your access level to this workspace",
                },
                {
                    "field": "sheet_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of sheets in this workspace",
                },
                {
                    "field": "sheet_names",
                    "type": "vec<string>",
                    "helper_text": "Names of sheets in this workspace",
                },
                {
                    "field": "folder_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of folders in this workspace",
                },
                {
                    "field": "folder_names",
                    "type": "vec<string>",
                    "helper_text": "Names of folders in this workspace",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_workspace_children",
            "task_name": "tasks.smartsheet.get_workspace_children",
            "description": "Get details of a workspace and its contents",
            "label": "Get Workspace Children",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["action", "integration", "workspace_id"],
            "required": ["workspace_id"],
        },
        "list_workspaces**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of workspaces to return",
                }
            ],
            "outputs": [
                {
                    "field": "workspace_ids",
                    "type": "vec<string>",
                    "helper_text": "List of workspace IDs",
                },
                {
                    "field": "workspace_names",
                    "type": "vec<string>",
                    "helper_text": "List of workspace names",
                },
                {
                    "field": "workspace_permalinks",
                    "type": "vec<string>",
                    "helper_text": "List of workspace URLs",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of workspaces returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_workspaces",
            "task_name": "tasks.smartsheet.list_workspaces",
            "description": "List all workspaces in your account",
            "label": "List Workspaces",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["action", "integration", "limit"],
            "required": ["limit"],
        },
        "update_workspace**(*)": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Workspace",
                    "helper_text": "Select the workspace to update",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "New Name",
                    "placeholder": "Updated Workspace Name",
                    "helper_text": "New name for the workspace",
                },
            ],
            "outputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "helper_text": "ID of the updated workspace",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Updated name of the workspace",
                },
                {
                    "field": "permalink",
                    "type": "string",
                    "helper_text": "URL to access the workspace",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "update_workspace",
            "task_name": "tasks.smartsheet.update_workspace",
            "description": "Update a workspace's name",
            "label": "Update Workspace",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["action", "integration", "workspace_id", "name"],
            "required": ["workspace_id", "name"],
        },
        "create_discussion**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet to create a discussion on",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "row_id",
                    "type": "string",
                    "value": "",
                    "label": "Row ID",
                    "placeholder": "1234567890",
                    "helper_text": "ID of the row to attach the discussion to (leave empty for sheet-level discussion)",
                },
                {
                    "field": "comment_text",
                    "type": "string",
                    "value": "",
                    "label": "Comment",
                    "multiline": True,
                    "placeholder": "Enter your comment here",
                    "helper_text": "Initial comment text for the discussion",
                },
            ],
            "outputs": [
                {
                    "field": "discussion_id",
                    "type": "string",
                    "helper_text": "ID of the created discussion",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the discussion",
                },
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "ID of the initial comment",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_discussion",
            "task_name": "tasks.smartsheet.create_discussion",
            "description": "Create a new discussion on a sheet or row",
            "label": "Create A Discussion",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "sheet_id",
                "row_id",
                "comment_text",
            ],
            "required": ["sheet_id", "comment_text"],
        },
        "get_discussion**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet containing the discussion",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "discussion_id",
                    "type": "string",
                    "value": "",
                    "label": "Discussion ID",
                    "placeholder": "1234567890",
                    "helper_text": "ID of the discussion to retrieve",
                },
            ],
            "outputs": [
                {
                    "field": "discussion_id",
                    "type": "string",
                    "helper_text": "ID of the discussion",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the discussion",
                },
                {
                    "field": "comment_count",
                    "type": "int32",
                    "helper_text": "Number of comments",
                },
                {
                    "field": "comment_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of all comments",
                },
                {
                    "field": "comment_texts",
                    "type": "vec<string>",
                    "helper_text": "Text of all comments",
                },
                {
                    "field": "comment_created_by",
                    "type": "vec<string>",
                    "helper_text": "Emails of comment authors",
                },
                {
                    "field": "comment_created_at",
                    "type": "vec<timestamp>",
                    "helper_text": "When each comment was created",
                },
                {
                    "field": "last_commented_at",
                    "type": "timestamp",
                    "helper_text": "When the last comment was added",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_discussion",
            "task_name": "tasks.smartsheet.get_discussion",
            "description": "Get details of a discussion",
            "label": "Get Discussion",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["action", "integration", "sheet_id", "discussion_id"],
            "required": ["sheet_id", "discussion_id"],
        },
        "list_discussions**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "label": "Sheet",
                    "helper_text": "Select the sheet to list discussions from",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "include_all",
                    "type": "bool",
                    "value": False,
                    "label": "Include All Comments",
                    "helper_text": "If true, includes all comments in each discussion",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of discussions to return",
                },
            ],
            "outputs": [
                {
                    "field": "discussion_ids",
                    "type": "vec<string>",
                    "helper_text": "List of discussion IDs",
                },
                {
                    "field": "discussion_titles",
                    "type": "vec<string>",
                    "helper_text": "List of discussion titles",
                },
                {
                    "field": "comment_counts",
                    "type": "vec<int32>",
                    "helper_text": "Number of comments in each discussion",
                },
                {
                    "field": "last_commented_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "When each discussion was last commented on",
                },
                {
                    "field": "created_by_emails",
                    "type": "vec<string>",
                    "helper_text": "Email of who created each discussion",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of discussions",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_discussions",
            "task_name": "tasks.smartsheet.list_discussions",
            "description": "List all discussions on a sheet",
            "label": "List Discussions",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "sheet_id",
                "include_all",
                "limit",
            ],
            "required": ["sheet_id", "include_all", "limit"],
        },
        "list_discussion_attachments**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "label": "Sheet",
                    "helper_text": "Select the sheet containing the discussion",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "discussion_id",
                    "type": "string",
                    "value": "",
                    "label": "Discussion ID",
                    "placeholder": "1234567890",
                    "helper_text": "ID of the discussion to list attachments from",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of attachments to return",
                },
            ],
            "outputs": [
                {
                    "field": "attachment_ids",
                    "type": "vec<string>",
                    "helper_text": "List of attachment IDs",
                },
                {
                    "field": "attachment_names",
                    "type": "vec<string>",
                    "helper_text": "List of attachment names",
                },
                {
                    "field": "attachment_types",
                    "type": "vec<string>",
                    "helper_text": "List of attachment types",
                },
                {
                    "field": "attachment_urls",
                    "type": "vec<string>",
                    "helper_text": "List of attachment URLs",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of attachments",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_discussion_attachments",
            "task_name": "tasks.smartsheet.list_discussion_attachments",
            "description": "List all attachments in a discussion",
            "label": "List Discussion Attachments",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "sheet_id",
                "discussion_id",
                "limit",
            ],
            "required": ["sheet_id", "discussion_id", "limit"],
        },
        "create_comment**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet containing the discussion",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "discussion_id",
                    "type": "string",
                    "value": "",
                    "label": "Discussion ID",
                    "placeholder": "1234567890",
                    "helper_text": "ID of the discussion to add a comment to",
                },
                {
                    "field": "text",
                    "type": "string",
                    "value": "",
                    "label": "Comment Text",
                    "multiline": True,
                    "placeholder": "Enter your comment here",
                    "helper_text": "Text of the comment",
                },
            ],
            "outputs": [
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "ID of the created comment",
                },
                {
                    "field": "discussion_id",
                    "type": "string",
                    "helper_text": "ID of the parent discussion",
                },
                {
                    "field": "text",
                    "type": "string",
                    "helper_text": "Text of the comment",
                },
                {
                    "field": "created_by",
                    "type": "string",
                    "helper_text": "Email of the comment author",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the comment was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_comment",
            "task_name": "tasks.smartsheet.create_comment",
            "description": "Add a comment to a discussion",
            "label": "Create A Comment",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "sheet_id",
                "discussion_id",
                "text",
            ],
            "required": ["sheet_id", "discussion_id", "text"],
        },
        "get_comment**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet containing the comment",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "comment_id",
                    "type": "string",
                    "value": "",
                    "label": "Comment ID",
                    "placeholder": "1234567890",
                    "helper_text": "ID of the comment to retrieve",
                },
            ],
            "outputs": [
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "ID of the comment",
                },
                {
                    "field": "discussion_id",
                    "type": "string",
                    "helper_text": "ID of the parent discussion",
                },
                {
                    "field": "text",
                    "type": "string",
                    "helper_text": "Text of the comment",
                },
                {
                    "field": "created_by",
                    "type": "string",
                    "helper_text": "Email of the comment author",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the comment was created",
                },
                {
                    "field": "modified_by",
                    "type": "string",
                    "helper_text": "Email of who last modified the comment",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "When the comment was last modified",
                },
                {
                    "field": "attachment_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of attachments on this comment",
                },
                {
                    "field": "attachment_names",
                    "type": "vec<string>",
                    "helper_text": "Names of attachments on this comment",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_comment",
            "task_name": "tasks.smartsheet.get_comment",
            "description": "Get details of a comment",
            "label": "Get A Comment",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["action", "integration", "sheet_id", "comment_id"],
            "required": ["sheet_id", "comment_id"],
        },
        "edit_comment**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet containing the comment",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "comment_id",
                    "type": "string",
                    "value": "",
                    "label": "Comment ID",
                    "placeholder": "1234567890",
                    "helper_text": "ID of the comment to update",
                },
                {
                    "field": "text",
                    "type": "string",
                    "value": "",
                    "label": "New Comment Text",
                    "multiline": True,
                    "placeholder": "Enter updated comment text",
                    "helper_text": "New text for the comment",
                },
            ],
            "outputs": [
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "ID of the updated comment",
                },
                {
                    "field": "text",
                    "type": "string",
                    "helper_text": "Updated text of the comment",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "When the comment was modified",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "edit_comment",
            "task_name": "tasks.smartsheet.edit_comment",
            "description": "Update a comment's text",
            "label": "Edit A Comment",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "sheet_id",
                "comment_id",
                "text",
            ],
            "required": ["sheet_id", "comment_id", "text"],
        },
        "delete_comment**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet containing the comment",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "comment_id",
                    "type": "string",
                    "value": "",
                    "label": "Comment ID",
                    "placeholder": "1234567890",
                    "helper_text": "ID of the comment to delete",
                },
            ],
            "outputs": [
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "ID of the deleted comment",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Deletion status message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "delete_comment",
            "task_name": "tasks.smartsheet.delete_comment",
            "description": "Delete a comment",
            "label": "Delete A Comment",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["action", "integration", "sheet_id", "comment_id"],
            "required": ["sheet_id", "comment_id"],
        },
        "attach_file_or_url**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "label": "Sheet",
                    "helper_text": "Select the sheet to attach the file to",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "attachment_type",
                    "type": "string",
                    "value": "LINK",
                    "label": "Attachment Type",
                    "helper_text": "Type of attachment",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "smartsheet_attachment_type",
                    },
                },
                {
                    "field": "attachment_subtype",
                    "type": "string",
                    "value": "",
                    "label": "Attachment Subtype",
                    "helper_text": "Subtype for Google Drive attachments (DOCUMENT, SPREADSHEET, PRESENTATION, PDF, DRAWING)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "smartsheet_attachment_subtype",
                    },
                },
                {
                    "field": "url",
                    "type": "string",
                    "value": "",
                    "label": "URL",
                    "placeholder": "https://example.com/document.pdf",
                    "helper_text": "URL to attach (can be a regular link or a link to Google Drive, Dropbox, OneDrive, etc.)",
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Attachment Name",
                    "placeholder": "My Document",
                    "helper_text": "Name for the attachment",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Description of the attachment",
                    "helper_text": "Description of the attachment",
                },
            ],
            "outputs": [
                {
                    "field": "attachment_id",
                    "type": "string",
                    "helper_text": "ID of the created attachment",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Name of the attachment",
                },
                {
                    "field": "url",
                    "type": "string",
                    "helper_text": "URL of the attachment",
                },
                {
                    "field": "attachment_type",
                    "type": "string",
                    "helper_text": "Type of the attachment",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "attach_file_or_url",
            "task_name": "tasks.smartsheet.attach_file_or_url",
            "description": "Attach a URL or link to a sheet (supports links to Google Drive, Dropbox, OneDrive, Box, Egnyte, Evernote)",
            "label": "Attach URL To Sheet",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": [
                "action",
                "integration",
                "sheet_id",
                "attachment_type",
                "attachment_subtype",
                "url",
                "name",
                "description",
            ],
            "required": ["sheet_id", "url", "name"],
        },
        "get_attachment**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "label": "Sheet",
                    "helper_text": "Select the sheet containing the attachment",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "attachment_id",
                    "type": "string",
                    "value": "",
                    "label": "Attachment ID",
                    "placeholder": "1234567890",
                    "helper_text": "ID of the attachment to retrieve",
                },
            ],
            "outputs": [
                {
                    "field": "attachment_id",
                    "type": "string",
                    "helper_text": "ID of the attachment",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Name of the attachment",
                },
                {
                    "field": "url",
                    "type": "string",
                    "helper_text": "URL to download the attachment",
                },
                {
                    "field": "attachment_type",
                    "type": "string",
                    "helper_text": "Type of the attachment",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the attachment",
                },
                {
                    "field": "size_in_kb",
                    "type": "int32",
                    "helper_text": "Size of the attachment in KB",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the attachment was created",
                },
                {
                    "field": "created_by_name",
                    "type": "string",
                    "helper_text": "Name of the user who created the attachment",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_attachment",
            "task_name": "tasks.smartsheet.get_attachment",
            "description": "Get details of an attachment",
            "label": "Get Attachment",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["action", "integration", "sheet_id", "attachment_id"],
            "required": ["sheet_id", "attachment_id"],
        },
        "search_everything**(*)": {
            "inputs": [
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Search Query",
                    "placeholder": "Enter search term",
                    "helper_text": "Text to search for across all sheets, reports, and dashboards",
                }
            ],
            "outputs": [
                {
                    "field": "object_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of matching objects",
                },
                {
                    "field": "object_types",
                    "type": "vec<string>",
                    "helper_text": "Types of matching objects",
                },
                {
                    "field": "object_names",
                    "type": "vec<string>",
                    "helper_text": "Names of matching objects",
                },
                {
                    "field": "texts",
                    "type": "vec<string>",
                    "helper_text": "Matching text content",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of matches",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "search_everything",
            "task_name": "tasks.smartsheet.search_everything",
            "description": "Search across all sheets, reports, and dashboards",
            "label": "Search Everything",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["action", "integration", "query"],
            "required": ["query"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "endpoint_0"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        text: str = "",
        query: str = "",
        alt_text: str = "",
        attachment_id: str = "",
        attachment_subtype: str = "",
        attachment_type: str = "LINK",
        column_id: str = "",
        comment_id: str = "",
        comment_text: str = "",
        descending: bool = False,
        description: str = "",
        destination_id: str = "",
        destination_sheet_id: str = "",
        discussion_id: str = "",
        file: str = "",
        folder_id: str = "",
        hidden: bool = False,
        ignore_rows_not_found: bool = True,
        include: str = "",
        include_all: bool = False,
        index: int = 0,
        limit: int = 10,
        locked: bool = False,
        name: str = "",
        new_name: str = "",
        options: str = "",
        primary_column_title: str = "Primary Column",
        row_id: str = "",
        row_ids: str = "",
        sheet_id: str = "",
        title: str = "",
        type: str = "TEXT_NUMBER",
        url: str = "",
        width: int = 150,
        workspace_id: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_smartsheet",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if name is not None:
            self.inputs["name"] = name
        if destination_id is not None:
            self.inputs["destination_id"] = destination_id
        if primary_column_title is not None:
            self.inputs["primary_column_title"] = primary_column_title
        if sheet_id is not None:
            self.inputs["sheet_id"] = sheet_id
        if limit is not None:
            self.inputs["limit"] = limit
        if new_name is not None:
            self.inputs["new_name"] = new_name
        if query is not None:
            self.inputs["query"] = query
        if row_id is not None:
            self.inputs["row_id"] = row_id
        if row_ids is not None:
            self.inputs["row_ids"] = row_ids
        if ignore_rows_not_found is not None:
            self.inputs["ignore_rows_not_found"] = ignore_rows_not_found
        if destination_sheet_id is not None:
            self.inputs["destination_sheet_id"] = destination_sheet_id
        if column_id is not None:
            self.inputs["column_id"] = column_id
        if descending is not None:
            self.inputs["descending"] = descending
        if title is not None:
            self.inputs["title"] = title
        if type is not None:
            self.inputs["type"] = type
        if index is not None:
            self.inputs["index"] = index
        if options is not None:
            self.inputs["options"] = options
        if description is not None:
            self.inputs["description"] = description
        if width is not None:
            self.inputs["width"] = width
        if hidden is not None:
            self.inputs["hidden"] = hidden
        if locked is not None:
            self.inputs["locked"] = locked
        if file is not None:
            self.inputs["file"] = file
        if alt_text is not None:
            self.inputs["alt_text"] = alt_text
        if folder_id is not None:
            self.inputs["folder_id"] = folder_id
        if include is not None:
            self.inputs["include"] = include
        if workspace_id is not None:
            self.inputs["workspace_id"] = workspace_id
        if comment_text is not None:
            self.inputs["comment_text"] = comment_text
        if discussion_id is not None:
            self.inputs["discussion_id"] = discussion_id
        if include_all is not None:
            self.inputs["include_all"] = include_all
        if text is not None:
            self.inputs["text"] = text
        if comment_id is not None:
            self.inputs["comment_id"] = comment_id
        if attachment_type is not None:
            self.inputs["attachment_type"] = attachment_type
        if attachment_subtype is not None:
            self.inputs["attachment_subtype"] = attachment_subtype
        if url is not None:
            self.inputs["url"] = url
        if attachment_id is not None:
            self.inputs["attachment_id"] = attachment_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationSmartsheetNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
