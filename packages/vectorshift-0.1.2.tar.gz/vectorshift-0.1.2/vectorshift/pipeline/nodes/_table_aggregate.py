"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs
from vectorshift.object import ObjectType

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("table_aggregate")
class TableAggregateNode(Node):
    """
    Aggregate data from a table.

    ## Inputs
    ### Common Inputs
        aggregation_column: Select a numeric column (integer or decimal) to perform aggregation
        aggregation_type: The aggregation to perform
        dataframe: The table to aggregate
        group_by_columns: The columns to group by

    ## Outputs
    ### Common Outputs
        dataframe: The aggregated dataframe
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "aggregation_column",
            "helper_text": "Select a numeric column (integer or decimal) to perform aggregation",
            "value": "",
            "type": "string",
        },
        {
            "field": "aggregation_type",
            "helper_text": "The aggregation to perform",
            "value": "AVG",
            "type": "string",
        },
        {
            "field": "dataframe",
            "helper_text": "The table to aggregate",
            "value": {"object_id": "", "object_type": ObjectType.TABLE},
            "type": "table",
        },
        {
            "field": "group_by_columns",
            "helper_text": "The columns to group by",
            "value": [],
            "type": "vec<string>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "dataframe",
            "helper_text": "The aggregated dataframe",
            "type": "dataframe",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = False

    _REQUIRED_FIELDS = [
        "dataframe",
        "group_by_columns",
        "aggregation_type",
        "aggregation_column",
    ]

    def __init__(
        self,
        aggregation_column: str = "",
        aggregation_type: str = "AVG",
        dataframe: Any = "",
        group_by_columns: List[str] = [],
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="table_aggregate",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if dataframe is not None:
            self.inputs["dataframe"] = dataframe
        if group_by_columns is not None:
            self.inputs["group_by_columns"] = group_by_columns
        if aggregation_type is not None:
            self.inputs["aggregation_type"] = aggregation_type
        if aggregation_column is not None:
            self.inputs["aggregation_column"] = aggregation_column
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "TableAggregateNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
