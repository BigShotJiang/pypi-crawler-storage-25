"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import DateRange, TimeRange


@Node.register_node_type("integration_salesforce")
class IntegrationSalesforceNode(Node):
    """
    Salesforce

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### When action = 'get_leads'
        query: Search query to filter leads
        annual_revenue: Annual revenue of the company
        city: City of the lead
        company: Company name for the lead
        condition: Condition operator for multiple filters (AND/OR)
        country: Country of the lead
        created_date: Filter by creation date (YYYY-MM-DD)
        description: Description of the lead
        email: Email address of the lead
        fields: Custom fields to retrieve (comma-separated)
        first_name: First name of the lead
        industry: Industry of the company
        last_name: Filter by last name
        lead_source: Source of the lead
        modified_date: Filter by modification date (YYYY-MM-DD)
        number_of_employees: Number of employees in the company
        owner_id: Filter by owner ID
        phone: Phone number of the lead
        postal_code: Postal code of the lead
        rating: Rating of the lead
        state: State of the lead
        status: Status of the lead
        street: Street address of the lead
        title: Job title of the lead
        use_date: Toggle to use dates
        website: Company website
    ### When action = 'get_contacts'
        query: Search query to filter leads
        account_id: ID of the associated account
        condition: Condition operator for multiple filters (AND/OR)
        created_date: Filter by creation date (YYYY-MM-DD)
        department: Department of the contact
        email: Email address of the lead
        fax: Fax number of the lead
        fields: Custom fields to retrieve (comma-separated)
        first_name: First name of the lead
        home_phone: Home phone number of the contact
        last_name: Filter by last name
        lead_source: Source of the lead
        mailing_city: Mailing city
        mailing_country: Mailing country
        mailing_postal_code: Mailing postal code
        mailing_state: Mailing state
        mailing_street: Mailing street address
        mobile_phone: Mobile phone number of the lead
        modified_date: Filter by modification date (YYYY-MM-DD)
        other_city: Other city
        other_country: Other country
        other_postal_code: Other postal code
        other_state: Other state
        other_street: Other street address
        owner_id: Filter by owner ID
        phone: Phone number of the lead
        record_type_id: Record type ID for the lead
        salutation: Salutation for the lead
        title: Job title of the lead
        use_date: Toggle to use dates
    ### When action = 'get_accounts'
        query: Search query to filter leads
        annual_revenue: Annual revenue of the company
        billing_city: Billing city
        billing_country: Billing country
        billing_state: Billing state
        condition: Condition operator for multiple filters (AND/OR)
        created_date: Filter by creation date (YYYY-MM-DD)
        fields: Custom fields to retrieve (comma-separated)
        industry: Industry of the company
        modified_date: Filter by modification date (YYYY-MM-DD)
        name: Name of the account
        number_of_employees: Number of employees in the company
        owner_id: Filter by owner ID
        phone: Phone number of the lead
        type: Type of account
        use_date: Toggle to use dates
        website: Company website
    ### When action = 'get_opportunities'
        query: Search query to filter leads
        account_id: ID of the associated account
        amount: Amount of the opportunity
        campaign_id: ID of the campaign to add the lead to
        close_date: Expected close date (YYYY-MM-DD)
        condition: Condition operator for multiple filters (AND/OR)
        created_date: Filter by creation date (YYYY-MM-DD)
        description: Description of the lead
        expected_revenue: Filter by expected revenue
        fields: Custom fields to retrieve (comma-separated)
        forecast_category: Filter by forecast category
        forecast_category_name: Forecast category
        has_opportunity_line_item: Whether the opportunity has line items
        is_closed: Filter by is closed
        is_won: Filter by is won
        lead_source: Source of the lead
        modified_date: Filter by modification date (YYYY-MM-DD)
        name: Name of the account
        next_step: Next step in the sales process
        owner_id: Filter by owner ID
        probability: Probability percentage (0-100)
        stage_name: Stage of the opportunity
        total_opportunity_quantity: Filter by total opportunity quantity
        type: Type of account
        use_date: Toggle to use dates
    ### When action = 'get_cases'
        query: Search query to filter leads
        account_id: ID of the associated account
        case_number: Filter by case number
        closed_date: Filter by closed date (YYYY-MM-DD)
        condition: Condition operator for multiple filters (AND/OR)
        contact_id: ID of the contact to update
        created_date: Filter by creation date (YYYY-MM-DD)
        description: Description of the lead
        engineering_req_number: Filter by engineering req number
        fields: Custom fields to retrieve (comma-separated)
        is_closed: Filter by is closed
        is_escalated: Filter by is escalated
        last_referenced_date: Filter by last referenced date (YYYY-MM-DD)
        last_viewed_date: Filter by last viewed date (YYYY-MM-DD)
        modified_date: Filter by modification date (YYYY-MM-DD)
        origin: Origin of the case
        owner_id: Filter by owner ID
        potential_liability: Filter by potential liability
        priority: Priority of the case
        product: Filter by product
        reason: Reason for the case
        sla_violation: Filter by SLA violation
        status: Status of the lead
        subject: Subject of the case
        supplied_company: Filter by supplied company
        supplied_email: Filter by supplied email
        supplied_name: Filter by supplied name
        supplied_phone: Filter by supplied phone
        type: Type of account
        use_date: Toggle to use dates
    ### When action = 'get_tasks'
        query: Search query to filter leads
        activity_date: Due date for the task (YYYY-MM-DD)
        condition: Condition operator for multiple filters (AND/OR)
        created_date: Filter by creation date (YYYY-MM-DD)
        description: Description of the lead
        fields: Custom fields to retrieve (comma-separated)
        is_recurrence: Filter by recurrence status
        is_reminder_set: Whether reminder is set
        modified_date: Filter by modification date (YYYY-MM-DD)
        owner_id: Filter by owner ID
        priority: Priority of the case
        record_type_id: Record type ID for the lead
        recurrence_activity_id: Filter by recurrence activity ID
        reminder_date_time: Filter by reminder date time
        status: Status of the lead
        subject: Subject of the case
        subject_line: Filter by subject line
        task_subtype: Subtype of task (Call, Email, etc.)
        use_date: Toggle to use dates
        what_id: Related record ID (Account, Opportunity, etc.)
        who_id: Related contact or lead ID
    ### When action = 'get_attachments'
        query: Search query to filter leads
        condition: Condition operator for multiple filters (AND/OR)
        content_type: Filter by content type
        created_date: Filter by creation date (YYYY-MM-DD)
        description: Description of the lead
        fields: Custom fields to retrieve (comma-separated)
        is_private: Whether the note is private
        modified_date: Filter by modification date (YYYY-MM-DD)
        name: Name of the account
        owner_id: Filter by owner ID
        parent_id: ID of the parent record (Lead, Contact, Account, etc.)
        use_date: Toggle to use dates
    ### When action = 'get_custom_objects'
        query: Search query to filter leads
        condition: Condition operator for multiple filters (AND/OR)
        created_by_id: Filter by created by ID
        created_date: Filter by creation date (YYYY-MM-DD)
        custom_object: API name of the custom object
        fields: Custom fields to retrieve (comma-separated)
        id: Filter by record ID
        last_modified_by_id: Filter by last modified by ID
        modified_date: Filter by modification date (YYYY-MM-DD)
        owner_id: Filter by owner ID
        system_mod_stamp: Filter by system modification stamp
        use_date: Toggle to use dates
    ### When action = 'get_users'
        query: Search query to filter leads
        condition: Condition operator for multiple filters (AND/OR)
        created_date: Filter by creation date (YYYY-MM-DD)
        email: Email address of the lead
        fields: Custom fields to retrieve (comma-separated)
        first_name: First name of the lead
        is_active: Filter by active status
        last_name: Filter by last name
        modified_date: Filter by modification date (YYYY-MM-DD)
        use_date: Toggle to use dates
        username: Filter by username
    ### When action = 'create_contact'
        account_id: ID of the associated account
        assistant_name: Name of the contact's assistant
        assistant_phone: Phone number of the contact's assistant
        birthdate: Birth date of the contact
        custom_fields: Custom fields in JSON format
        department: Department of the contact
        description: Description of the lead
        email: Email address of the lead
        fax: Fax number of the lead
        first_name: First name of the lead
        home_phone: Home phone number of the contact
        lastname: Last name of the lead
        lead_source: Source of the lead
        mailing_city: Mailing city
        mailing_country: Mailing country
        mailing_postal_code: Mailing postal code
        mailing_state: Mailing state
        mailing_street: Mailing street address
        mobile_phone: Mobile phone number of the lead
        other_city: Other city
        other_country: Other country
        other_phone: Other phone number of the contact
        other_postal_code: Other postal code
        other_state: Other state
        other_street: Other street address
        owner: Owner ID of the lead
        phone: Phone number of the lead
        record_type_id: Record type ID for the lead
        salutation: Salutation for the lead
        title: Job title of the lead
    ### When action = 'upsert_contact'
        account_id: ID of the associated account
        assistant_name: Name of the contact's assistant
        assistant_phone: Phone number of the contact's assistant
        birthdate: Birth date of the contact
        custom_fields: Custom fields in JSON format
        department: Department of the contact
        description: Description of the lead
        email: Email address of the lead
        external_id: External ID field name
        external_id_value: Value for the external ID
        fax: Fax number of the lead
        first_name: First name of the lead
        home_phone: Home phone number of the contact
        lastname: Last name of the lead
        lead_source: Source of the lead
        mailing_city: Mailing city
        mailing_country: Mailing country
        mailing_postal_code: Mailing postal code
        mailing_state: Mailing state
        mailing_street: Mailing street address
        mobile_phone: Mobile phone number of the lead
        other_city: Other city
        other_country: Other country
        other_phone: Other phone number of the contact
        other_postal_code: Other postal code
        other_state: Other state
        other_street: Other street address
        owner: Owner ID of the lead
        phone: Phone number of the lead
        record_type_id: Record type ID for the lead
        salutation: Salutation for the lead
        title: Job title of the lead
    ### When action = 'update_contact'
        account_id: ID of the associated account
        assistant_name: Name of the contact's assistant
        assistant_phone: Phone number of the contact's assistant
        birthdate: Birth date of the contact
        contact_id: ID of the contact to update
        custom_fields: Custom fields in JSON format
        department: Department of the contact
        description: Description of the lead
        email: Email address of the lead
        fax: Fax number of the lead
        first_name: First name of the lead
        home_phone: Home phone number of the contact
        lastname: Last name of the lead
        lead_source: Source of the lead
        mailing_city: Mailing city
        mailing_country: Mailing country
        mailing_postal_code: Mailing postal code
        mailing_state: Mailing state
        mailing_street: Mailing street address
        mobile_phone: Mobile phone number of the lead
        other_city: Other city
        other_country: Other country
        other_phone: Other phone number of the contact
        other_postal_code: Other postal code
        other_state: Other state
        other_street: Other street address
        owner: Owner ID of the lead
        phone: Phone number of the lead
        record_type_id: Record type ID for the lead
        salutation: Salutation for the lead
        title: Job title of the lead
    ### When action = 'update_account'
        account_id: ID of the associated account
        annual_revenue: Annual revenue of the company
        billing_city: Billing city
        billing_country: Billing country
        billing_postal_code: Billing postal code
        billing_state: Billing state
        billing_street: Billing street address
        custom_fields: Custom fields in JSON format
        description: Description of the lead
        industry: Industry of the company
        name: Name of the account
        number_of_employees: Number of employees in the company
        owner: Owner ID of the lead
        phone: Phone number of the lead
        type: Type of account
        website: Company website
    ### When action = 'read_account'
        account_id: ID of the associated account
    ### When action = 'delete_account'
        account_id: ID of the associated account
    ### When action = 'add_account_note'
        account_id: ID of the associated account
        body: Content of the note
        is_private: Whether the note is private
        title: Job title of the lead
    ### When action = 'create_opportunity'
        account_id: ID of the associated account
        amount: Amount of the opportunity
        campaign_id: ID of the campaign to add the lead to
        close_date: Expected close date (YYYY-MM-DD)
        custom_fields: Custom fields in JSON format
        description: Description of the lead
        forecast_category_name: Forecast category
        has_opportunity_line_item: Whether the opportunity has line items
        is_private: Whether the note is private
        lead_source: Source of the lead
        name: Name of the account
        next_step: Next step in the sales process
        owner: Owner ID of the lead
        probability: Probability percentage (0-100)
        record_type_id: Record type ID for the lead
        stage_name: Stage of the opportunity
        type: Type of account
    ### When action = 'upsert_opportunity'
        account_id: ID of the associated account
        amount: Amount of the opportunity
        campaign_id: ID of the campaign to add the lead to
        close_date: Expected close date (YYYY-MM-DD)
        custom_fields: Custom fields in JSON format
        description: Description of the lead
        external_id: External ID field name
        external_id_value: Value for the external ID
        forecast_category_name: Forecast category
        has_opportunity_line_item: Whether the opportunity has line items
        is_private: Whether the note is private
        lead_source: Source of the lead
        name: Name of the account
        next_step: Next step in the sales process
        owner: Owner ID of the lead
        probability: Probability percentage (0-100)
        record_type_id: Record type ID for the lead
        stage_name: Stage of the opportunity
        type: Type of account
    ### When action = 'update_opportunity'
        account_id: ID of the associated account
        amount: Amount of the opportunity
        campaign_id: ID of the campaign to add the lead to
        close_date: Expected close date (YYYY-MM-DD)
        custom_fields: Custom fields in JSON format
        description: Description of the lead
        forecast_category_name: Forecast category
        has_opportunity_line_item: Whether the opportunity has line items
        is_private: Whether the note is private
        lead_source: Source of the lead
        name: Name of the account
        next_step: Next step in the sales process
        opportunity_id: ID of the opportunity to update
        owner: Owner ID of the lead
        probability: Probability percentage (0-100)
        record_type_id: Record type ID for the lead
        stage_name: Stage of the opportunity
        type: Type of account
    ### When action = 'create_case'
        account_id: ID of the associated account
        contact_id: ID of the contact to update
        custom_fields: Custom fields in JSON format
        description: Description of the lead
        origin: Origin of the case
        owner: Owner ID of the lead
        priority: Priority of the case
        reason: Reason for the case
        record_type_id: Record type ID for the lead
        status: Status of the lead
        subject: Subject of the case
        type: Type of account
    ### When action = 'update_case'
        account_id: ID of the associated account
        case_id: ID of the case to update
        contact_id: ID of the contact to update
        custom_fields: Custom fields in JSON format
        description: Description of the lead
        origin: Origin of the case
        owner: Owner ID of the lead
        priority: Priority of the case
        reason: Reason for the case
        record_type_id: Record type ID for the lead
        status: Status of the lead
        subject: Subject of the case
        type: Type of account
    ### When action = 'create_task'
        activity_date: Due date for the task (YYYY-MM-DD)
        custom_fields: Custom fields in JSON format
        description: Description of the lead
        is_reminder_set: Whether reminder is set
        owner: Owner ID of the lead
        priority: Priority of the case
        record_type_id: Record type ID for the lead
        status: Status of the lead
        subject: Subject of the case
        task_subtype: Subtype of task (Call, Email, etc.)
        what_id: Related record ID (Account, Opportunity, etc.)
        who_id: Related contact or lead ID
    ### When action = 'update_task'
        activity_date: Due date for the task (YYYY-MM-DD)
        custom_fields: Custom fields in JSON format
        description: Description of the lead
        is_reminder_set: Whether reminder is set
        owner: Owner ID of the lead
        priority: Priority of the case
        record_type_id: Record type ID for the lead
        status: Status of the lead
        subject: Subject of the case
        task_id: ID of the task to update
        task_subtype: Subtype of task (Call, Email, etc.)
        what_id: Related record ID (Account, Opportunity, etc.)
        who_id: Related contact or lead ID
    ### When action = 'create_lead'
        annual_revenue: Annual revenue of the company
        city: City of the lead
        company: Company name for the lead
        country: Country of the lead
        custom_fields: Custom fields in JSON format
        description: Description of the lead
        email: Email address of the lead
        fax: Fax number of the lead
        first_name: First name of the lead
        industry: Industry of the company
        is_unread_by_owner: Whether the lead is unread by owner
        lastname: Last name of the lead
        lead_source: Source of the lead
        mobile_phone: Mobile phone number of the lead
        number_of_employees: Number of employees in the company
        owner: Owner ID of the lead
        phone: Phone number of the lead
        postal_code: Postal code of the lead
        rating: Rating of the lead
        record_type_id: Record type ID for the lead
        salutation: Salutation for the lead
        state: State of the lead
        status: Status of the lead
        street: Street address of the lead
        title: Job title of the lead
        website: Company website
    ### When action = 'upsert_lead'
        annual_revenue: Annual revenue of the company
        city: City of the lead
        company: Company name for the lead
        country: Country of the lead
        custom_fields: Custom fields in JSON format
        description: Description of the lead
        email: Email address of the lead
        external_id: External ID field name
        external_id_value: Value for the external ID
        fax: Fax number of the lead
        first_name: First name of the lead
        industry: Industry of the company
        is_unread_by_owner: Whether the lead is unread by owner
        lastname: Last name of the lead
        lead_source: Source of the lead
        mobile_phone: Mobile phone number of the lead
        number_of_employees: Number of employees in the company
        owner: Owner ID of the lead
        phone: Phone number of the lead
        postal_code: Postal code of the lead
        rating: Rating of the lead
        record_type_id: Record type ID for the lead
        salutation: Salutation for the lead
        state: State of the lead
        status: Status of the lead
        street: Street address of the lead
        title: Job title of the lead
        website: Company website
    ### When action = 'update_lead'
        annual_revenue: Annual revenue of the company
        city: City of the lead
        company: Company name for the lead
        country: Country of the lead
        custom_fields: Custom fields in JSON format
        description: Description of the lead
        email: Email address of the lead
        fax: Fax number of the lead
        first_name: First name of the lead
        industry: Industry of the company
        is_unread_by_owner: Whether the lead is unread by owner
        lastname: Last name of the lead
        lead_id: ID of the lead to update
        lead_source: Source of the lead
        mobile_phone: Mobile phone number of the lead
        number_of_employees: Number of employees in the company
        owner: Owner ID of the lead
        phone: Phone number of the lead
        postal_code: Postal code of the lead
        rating: Rating of the lead
        record_type_id: Record type ID for the lead
        salutation: Salutation for the lead
        state: State of the lead
        status: Status of the lead
        street: Street address of the lead
        title: Job title of the lead
        website: Company website
    ### When action = 'create_account'
        annual_revenue: Annual revenue of the company
        billing_city: Billing city
        billing_country: Billing country
        billing_postal_code: Billing postal code
        billing_state: Billing state
        billing_street: Billing street address
        custom_fields: Custom fields in JSON format
        description: Description of the lead
        industry: Industry of the company
        name: Name of the account
        number_of_employees: Number of employees in the company
        owner: Owner ID of the lead
        phone: Phone number of the lead
        type: Type of account
        website: Company website
    ### When action = 'upsert_account'
        annual_revenue: Annual revenue of the company
        billing_city: Billing city
        billing_country: Billing country
        billing_postal_code: Billing postal code
        billing_state: Billing state
        billing_street: Billing street address
        custom_fields: Custom fields in JSON format
        description: Description of the lead
        external_id: External ID field name
        external_id_value: Value for the external ID
        industry: Industry of the company
        name: Name of the account
        number_of_employees: Number of employees in the company
        owner: Owner ID of the lead
        phone: Phone number of the lead
        type: Type of account
        website: Company website
    ### When action = 'invoke_flow'
        api_name: API name of the flow to invoke
        json_parameters: Whether to use JSON parameters
        variables: Flow variables in array format
        variables_json: Flow variables in JSON format
    ### When action = 'update_attachment'
        attachment_id: ID of the attachment to update
        description: Description of the lead
        is_private: Whether the note is private
        name: Name of the account
        owner: Owner ID of the lead
        parent_id: ID of the parent record (Lead, Contact, Account, etc.)
    ### When action = 'read_attachment'
        attachment_id: ID of the attachment to update
        parent_id: ID of the parent record (Lead, Contact, Account, etc.)
    ### When action = 'delete_attachment'
        attachment_id: ID of the attachment to update
        parent_id: ID of the parent record (Lead, Contact, Account, etc.)
    ### When action = 'create_attachment'
        attachments: Files to attach
        description: Description of the lead
        is_private: Whether the note is private
        name: Name of the account
        owner: Owner ID of the lead
        parent_id: ID of the parent record (Lead, Contact, Account, etc.)
    ### When action = 'add_lead_note'
        body: Content of the note
        is_private: Whether the note is private
        lead_id: ID of the lead to update
        title: Job title of the lead
    ### When action = 'add_contact_note'
        body: Content of the note
        contact_id: ID of the contact to update
        is_private: Whether the note is private
        title: Job title of the lead
    ### When action = 'add_opportunity_note'
        body: Content of the note
        is_private: Whether the note is private
        opportunity_id: ID of the opportunity to update
        title: Job title of the lead
    ### When action = 'add_lead_to_campaign'
        campaign_id: ID of the campaign to add the lead to
        has_responded: Whether the lead has responded
        lead_id: ID of the lead to update
        status: Status of the lead
    ### When action = 'add_contact_to_campaign'
        campaign_id: ID of the campaign to add the lead to
        contact_id: ID of the contact to update
        has_responded: Whether the lead has responded
        status: Status of the lead
    ### When action = 'read_case'
        case_id: ID of the case to update
    ### When action = 'delete_case'
        case_id: ID of the case to update
    ### When action = 'add_case_comment'
        case_id: ID of the case to update
        comment_body: Content of the comment
        is_private: Whether the note is private
    ### When action = 'read_contact'
        contact_id: ID of the contact to update
    ### When action = 'delete_contact'
        contact_id: ID of the contact to update
    ### When action = 'create_custom_object'
        custom_fields: Custom fields in JSON format
        custom_object: API name of the custom object
        record_type_id: Record type ID for the lead
    ### When action = 'upsert_custom_object'
        custom_fields: Custom fields in JSON format
        custom_object: API name of the custom object
        external_id: External ID field name
        external_id_value: Value for the external ID
        record_type_id: Record type ID for the lead
    ### When action = 'update_custom_object'
        custom_fields: Custom fields in JSON format
        custom_object: API name of the custom object
        record_id: ID of the record to update
        record_type_id: Record type ID for the lead
    ### When action = 'read_custom_object'
        custom_object: API name of the custom object
        record_id: ID of the record to update
    ### When action = 'delete_custom_object'
        custom_object: API name of the custom object
        record_id: ID of the record to update
    ### When action = 'get_leads' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_contacts' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_accounts' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_opportunities' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_cases' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_tasks' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_attachments' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_custom_objects' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_users' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_leads' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_contacts' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_accounts' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_opportunities' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_cases' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_tasks' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_attachments' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_custom_objects' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_users' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'upload_document'
        file: File to upload
        file_extension: File extension (e.g., pdf, doc, txt)
        link_to_object_id: ID of the folder to link the document to
        owner_id: Filter by owner ID
        title: Job title of the lead
    ### When action = 'read_lead'
        lead_id: ID of the lead to update
    ### When action = 'delete_lead'
        lead_id: ID of the lead to update
    ### When action = 'get_leads' and use_date = False
        num_messages: Specify the number of leads to fetch
    ### When action = 'get_contacts' and use_date = False
        num_messages: Specify the number of leads to fetch
    ### When action = 'get_accounts' and use_date = False
        num_messages: Specify the number of leads to fetch
    ### When action = 'get_opportunities' and use_date = False
        num_messages: Specify the number of leads to fetch
    ### When action = 'get_cases' and use_date = False
        num_messages: Specify the number of leads to fetch
    ### When action = 'get_tasks' and use_date = False
        num_messages: Specify the number of leads to fetch
    ### When action = 'get_attachments' and use_date = False
        num_messages: Specify the number of leads to fetch
    ### When action = 'get_custom_objects' and use_date = False
        num_messages: Specify the number of leads to fetch
    ### When action = 'get_users' and use_date = False
        num_messages: Specify the number of leads to fetch
    ### When action = 'read_opportunity'
        opportunity_id: ID of the opportunity to update
    ### When action = 'delete_opportunity'
        opportunity_id: ID of the opportunity to update
    ### When action = 'run_sql_query'
        sql_query: SQL query to execute
    ### When action = 'read_task'
        task_id: ID of the task to update
    ### When action = 'delete_task'
        task_id: ID of the task to update
    ### When action = 'get_leads' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_contacts' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_accounts' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_opportunities' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_cases' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_tasks' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_attachments' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_custom_objects' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_users' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'read_user'
        user_id: ID of the user to read

    ## Outputs
    ### When action = 'read_contact'
        account_id: ID of the associated account
        contact_id: ID of the contact
        contact_name: Full name of the contact
        created_at: Creation timestamp of the contact
        department: Department of the contact
        description: Description of the contact
        email: Email address of the contact
        lead_source: Source of the contact
        mailing_city: Mailing city of the contact
        mailing_country: Mailing country of the contact
        mailing_state: Mailing state of the contact
        owner_id: Owner ID of the contact
        phone: Phone number of the contact
        raw_data: Raw API response data
        title: Job title of the contact
        updated_at: Last update timestamp of the contact
    ### When action = 'create_account'
        account_id: ID of the created account
        raw_data: Raw API response data
    ### When action = 'upsert_account'
        account_id: ID of the upserted account
        raw_data: Raw API response data
    ### When action = 'update_account'
        account_id: ID of the updated account
        raw_data: Raw API response data
    ### When action = 'read_account'
        account_id: ID of the account
        account_name: Name of the account
        annual_revenue: Annual revenue of the account
        billing_city: Billing city of the account
        billing_country: Billing country of the account
        billing_state: Billing state of the account
        created_at: Creation timestamp of the account
        description: Description of the account
        industry: Industry of the account
        number_of_employees: Number of employees
        owner_id: Owner ID of the account
        phone: Phone number of the account
        raw_data: Raw API response data
        type: Type of the account
        updated_at: Last update timestamp of the account
        website: Website of the account
    ### When action = 'delete_account'
        account_id: ID of the deleted account
        deleted: Whether the account was successfully deleted
    ### When action = 'read_opportunity'
        account_id: Associated account ID
        amount: Amount of the opportunity
        campaign_id: Associated campaign ID
        close_date: Expected close date
        created_at: Creation timestamp of the opportunity
        description: Description of the opportunity
        forecast_category_name: Forecast category
        lead_source: Source of the lead
        next_step: Next step in the sales process
        opportunity_id: ID of the opportunity
        opportunity_name: Name of the opportunity
        owner_id: Owner ID of the opportunity
        probability: Probability percentage
        raw_data: Raw API response data
        stage_name: Stage of the opportunity
        type: Type of opportunity
        updated_at: Last update timestamp of the opportunity
    ### When action = 'read_case'
        account_id: Associated account ID
        case_id: ID of the case
        case_number: Case number
        contact_id: Associated contact ID
        created_at: Creation timestamp of the case
        description: Description of the case
        origin: Origin of the case
        owner_id: Owner ID of the case
        priority: Priority of the case
        raw_data: Raw API response data
        reason: Reason for the case
        status: Status of the case
        subject: Subject of the case
        type: Type of case
        updated_at: Last update timestamp of the case
    ### When action = 'get_contacts'
        account_ids: List of associated account IDs
        contact_ids: List of contact IDs
        contact_names: List of contact names
        created_dates: List of creation dates
        departments: List of contact departments
        done: Whether the query is complete
        emails: List of contact emails
        lead_sources: List of contact lead sources
        owner_ids: List of owner IDs
        phones: List of contact phone numbers
        raw_data: Raw API response data
        titles: List of contact titles
        total_size: Total number of records returned
        updated_dates: List of update dates
    ### When action = 'get_accounts'
        account_ids: List of account IDs
        account_names: List of account names
        billing_cities: List of billing cities
        billing_countries: List of billing countries
        billing_states: List of billing states
        created_dates: List of creation dates
        done: Whether the query is complete
        industries: List of account industries
        owner_ids: List of owner IDs
        phones: List of account phone numbers
        raw_data: Raw API response data
        total_size: Total number of records returned
        types: List of account types
        updated_dates: List of update dates
        websites: List of account websites
    ### When action = 'get_opportunities'
        account_ids: List of account IDs
        amounts: List of opportunity amounts
        close_dates: List of close dates
        created_dates: List of creation dates
        done: Whether the query is complete
        lead_sources: List of lead sources
        opportunity_ids: List of opportunity IDs
        opportunity_names: List of opportunity names
        owner_ids: List of owner IDs
        probabilities: List of probability percentages
        raw_data: Raw API response data
        stage_names: List of opportunity stages
        total_size: Total number of records returned
        types: List of opportunity types
        updated_dates: List of update dates
    ### When action = 'get_cases'
        account_ids: List of account IDs
        case_ids: List of case IDs
        case_numbers: List of case numbers
        contact_ids: List of contact IDs
        created_dates: List of creation dates
        done: Whether the query is complete
        origins: List of case origins
        owner_ids: List of owner IDs
        priorities: List of case priorities
        raw_data: Raw API response data
        statuses: List of case statuses
        subjects: List of case subjects
        total_size: Total number of records returned
        types: List of case types
        updated_dates: List of update dates
    ### When action = 'read_task'
        activity_date: Due date of the task
        created_at: Creation date
        description: Description of the task
        is_reminder_set: Whether reminder is set
        owner_id: Owner ID
        priority: Priority of the task
        raw_data: Raw API response data
        status: Status of the task
        subject: Subject of the task
        task_id: ID of the task
        task_subtype: Subtype of task (Call, Email, etc.)
        updated_at: Last modified date
        what_id: Related record ID
        who_id: Related contact or lead ID
    ### When action = 'get_tasks'
        activity_dates: List of activity dates
        created_dates: List of creation dates
        done: Whether query is complete
        owner_ids: List of owner IDs
        priorities: List of task priorities
        raw_data: Raw API response data
        statuses: List of task statuses
        subjects: List of task subjects
        task_ids: List of task IDs
        task_subtypes: List of task subtypes (Call, Email, etc.)
        total_size: Total number of tasks
        updated_dates: List of last modified dates
        what_ids: List of related record IDs
        who_ids: List of related contact/lead IDs
    ### When action = 'invoke_flow'
        api_name: API name of the invoked flow
        outputs: Flow output variables
        raw_data: Raw API response data
    ### When action = 'update_attachment'
        attachment_id: ID of the updated attachment
        raw_data: Raw API response data
    ### When action = 'read_attachment'
        attachment_id: ID of the attachment
        body_length: Size of the attachment in bytes
        content_type: Content type of the attachment
        created_at: Creation date
        description: Description of the attachment
        file: Downloaded file content
        is_private: Whether the attachment is private
        name: Name of the attachment
        owner_id: Owner ID
        parent_id: Parent record ID
        raw_data: Raw API response data
        updated_at: Last modified date
    ### When action = 'delete_attachment'
        attachment_id: ID of the deleted attachment
        deleted: Whether attachment was deleted
    ### When action = 'create_attachment'
        attachment_ids: IDs of all created attachments
        raw_data: Raw API response data for each attachment
        total: Total number of attachments created
    ### When action = 'get_attachments'
        attachment_ids: List of attachment IDs
        body_lengths: List of file sizes
        content_types: List of content types
        created_dates: List of creation dates
        descriptions: List of descriptions
        done: Whether query is complete
        is_private: List of privacy flags
        names: List of attachment names
        owner_ids: List of owner IDs
        parent_ids: List of parent record IDs
        raw_data: Raw API response data
        total_size: Total number of attachments
        updated_dates: List of last modified dates
    ### When action = 'add_lead_to_campaign'
        campaign_member_id: ID of the created campaign member
        raw_data: Raw API response data
    ### When action = 'add_contact_to_campaign'
        campaign_member_id: ID of the created campaign member
        raw_data: Raw API response data
    ### When action = 'create_case'
        case_id: ID of the created case
        raw_data: Raw API response data
    ### When action = 'update_case'
        case_id: ID of the updated case
        raw_data: Raw API response data
    ### When action = 'delete_case'
        case_id: ID of the deleted case
        deleted: Whether the case was successfully deleted
    ### When action = 'read_lead'
        city: City of the lead
        company: Company name of the lead
        country: Country of the lead
        created_at: Creation timestamp of the lead
        description: Description of the lead
        email: Email address of the lead
        industry: Industry of the company
        lead_id: ID of the lead
        lead_name: Full name of the lead
        lead_source: Source of the lead
        owner_id: Owner ID of the lead
        phone: Phone number of the lead
        postal_code: Postal code of the lead
        raw_data: Raw API response data
        state: State of the lead
        status: Status of the lead
        title: Job title of the lead
        updated_at: Last update timestamp of the lead
        website: Company website
    ### When action = 'add_case_comment'
        comment_id: ID of the created comment
        raw_data: Raw API response data
    ### When action = 'get_leads'
        companies: List of lead companies
        created_dates: List of creation dates
        done: Whether the query is complete
        emails: List of lead emails
        lead_ids: List of lead IDs
        lead_names: List of lead names
        lead_sources: List of lead sources
        owner_ids: List of owner IDs
        phones: List of lead phone numbers
        raw_data: Raw API response data
        statuses: List of lead statuses
        total_size: Total number of records returned
        updated_dates: List of update dates
    ### When action = 'create_contact'
        contact_id: ID of the created contact
        raw_data: Raw API response data
    ### When action = 'upsert_contact'
        contact_id: ID of the upserted contact
        raw_data: Raw API response data
    ### When action = 'update_contact'
        contact_id: ID of the updated contact
        raw_data: Raw API response data
    ### When action = 'delete_contact'
        contact_id: ID of the deleted contact
        deleted: Whether the contact was successfully deleted
    ### When action = 'get_users'
        created_dates: List of creation dates
        done: Whether query is complete
        emails: List of email addresses
        first_names: List of first names
        is_active: List of active status flags
        last_names: List of last names
        raw_data: Raw API response data
        total_size: Total number of users
        updated_dates: List of last modified dates
        user_ids: List of user IDs
        usernames: List of usernames
    ### When action = 'create_custom_object'
        custom_object: Name of the custom object
        raw_data: Raw API response data
        record_id: ID of the created record
    ### When action = 'upsert_custom_object'
        custom_object: Name of the custom object
        raw_data: Raw API response data
        record_id: ID of the upserted record
    ### When action = 'update_custom_object'
        custom_object: Name of the custom object
        raw_data: Raw API response data
        record_id: ID of the updated record
    ### When action = 'read_custom_object'
        custom_object: Name of the custom object
        fields: All fields of the record
        raw_data: Raw API response data
        record_id: ID of the record
    ### When action = 'get_custom_objects'
        custom_object: Name of the custom object
        done: Whether query is complete
        raw_data: Raw API response data
        record_ids: List of record IDs
        records: List of record data
        total_size: Total number of records
    ### When action = 'delete_custom_object'
        custom_object: Name of the custom object
        deleted: Whether record was deleted
        record_id: ID of the deleted record
    ### When action = 'get_lead_summary'
        deletable: Whether the lead object is deletable
        fields: Available fields for the lead object
        label: Label of the lead object
        name: Name of the lead object
        queryable: Whether the lead object is queryable
        raw_data: Raw API response data
        updateable: Whether the lead object is updateable
    ### When action = 'get_contact_summary'
        deletable: Whether the contact object is deletable
        fields: Available fields for the contact object
        label: Label of the contact object
        name: Name of the contact object
        queryable: Whether the contact object is queryable
        raw_data: Raw API response data
        updateable: Whether the contact object is updateable
    ### When action = 'get_account_summary'
        deletable: Whether the account object is deletable
        fields: Available fields for the account object
        label: Label of the account object
        name: Name of the account object
        queryable: Whether the account object is queryable
        raw_data: Raw API response data
        updateable: Whether the account object is updateable
    ### When action = 'get_opportunity_summary'
        deletable: Whether the opportunity object is deletable
        fields: Available fields for the opportunity object
        label: Label of the opportunity object
        name: Name of the opportunity object
        queryable: Whether the opportunity object is queryable
        raw_data: Raw API response data
        updateable: Whether the opportunity object is updateable
    ### When action = 'get_case_summary'
        deletable: Whether the case object is deletable
        fields: Available fields for the case object
        label: Label of the case object
        name: Name of the case object
        queryable: Whether the case object is queryable
        raw_data: Raw API response data
        updateable: Whether the case object is updateable
    ### When action = 'get_task_summary'
        deletable: Whether object is deletable
        fields: Available fields
        label: Object label
        name: Object name
        queryable: Whether object is queryable
        raw_data: Raw API response data
        updateable: Whether object is updateable
    ### When action = 'get_attachment_summary'
        deletable: Whether object is deletable
        fields: Available fields
        label: Object label
        name: Object name
        queryable: Whether object is queryable
        raw_data: Raw API response data
        updateable: Whether object is updateable
    ### When action = 'delete_lead'
        deleted: Whether the lead was successfully deleted
        lead_id: ID of the deleted lead
    ### When action = 'delete_opportunity'
        deleted: Whether the opportunity was successfully deleted
        opportunity_id: ID of the deleted opportunity
    ### When action = 'delete_task'
        deleted: Whether task was deleted
        task_id: ID of the deleted task
    ### When action = 'upload_document'
        document_id: ID of the uploaded document
        raw_data: Raw API response data
        title: Title of the document
    ### When action = 'run_sql_query'
        done: Whether query is complete
        raw_data: Raw API response data
        records: Array of query results
        total_size: Total number of records
    ### When action = 'read_user'
        email: Email address of the user
        first_name: First name of the user
        is_active: Whether the user is active
        last_name: Last name of the user
        raw_data: Raw API response data
        user_id: ID of the user
        username: Username of the user
    ### When action = 'create_lead'
        lead_id: ID of the created lead
        raw_data: Raw API response data
    ### When action = 'upsert_lead'
        lead_id: ID of the upserted lead
        raw_data: Raw API response data
    ### When action = 'update_lead'
        lead_id: ID of the updated lead
        raw_data: Raw API response data
    ### When action = 'add_lead_note'
        note_id: ID of the created note
        raw_data: Raw API response data
    ### When action = 'add_contact_note'
        note_id: ID of the created note
        raw_data: Raw API response data
    ### When action = 'add_account_note'
        note_id: ID of the created note
        raw_data: Raw API response data
    ### When action = 'add_opportunity_note'
        note_id: ID of the created note
        raw_data: Raw API response data
    ### When action = 'create_opportunity'
        opportunity_id: ID of the created opportunity
        raw_data: Raw API response data
    ### When action = 'upsert_opportunity'
        opportunity_id: ID of the upserted opportunity
        raw_data: Raw API response data
    ### When action = 'update_opportunity'
        opportunity_id: ID of the updated opportunity
        raw_data: Raw API response data
    ### When action = 'create_task'
        raw_data: Raw API response data
        task_id: ID of the created task
    ### When action = 'update_task'
        raw_data: Raw API response data
        task_id: ID of the updated task
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Salesforce>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "create_lead**(*)**(*)": {
            "inputs": [
                {
                    "field": "company",
                    "type": "string",
                    "value": "",
                    "helper_text": "Company name for the lead",
                    "label": "Company",
                    "placeholder": "Acme Corporation",
                },
                {
                    "field": "lastname",
                    "type": "string",
                    "value": "",
                    "helper_text": "Last name of the lead",
                    "label": "Last Name",
                    "placeholder": "Smith",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "First name of the lead",
                    "label": "First Name",
                    "placeholder": "John",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email address of the lead",
                    "label": "Email",
                    "placeholder": "john.smith@acme.com",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Phone number of the lead",
                    "label": "Phone",
                    "placeholder": "+1-555-123-4567",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Job title of the lead",
                    "label": "Title",
                    "placeholder": "CEO",
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "helper_text": "Company website",
                    "label": "Website",
                    "placeholder": "https://acme.com",
                },
                {
                    "field": "industry",
                    "type": "string",
                    "value": "",
                    "helper_text": "Industry of the company",
                    "label": "Select Industry",
                    "placeholder": "Technology",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_industry",
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the lead",
                    "label": "Description",
                    "placeholder": "Potential customer for our services",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Status of the lead",
                    "label": "Select Status",
                    "placeholder": "Open - Not Contacted",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_lead_status",
                    },
                },
                {
                    "field": "rating",
                    "type": "string",
                    "value": "",
                    "helper_text": "Rating of the lead",
                    "label": "Select Rating",
                    "placeholder": "Hot",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_rating",
                    },
                },
                {
                    "field": "lead_source",
                    "type": "string",
                    "value": "",
                    "helper_text": "Source of the lead",
                    "label": "Select Lead Source",
                    "placeholder": "Web",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_lead_source",
                    },
                },
                {
                    "field": "city",
                    "type": "string",
                    "value": "",
                    "helper_text": "City of the lead",
                    "label": "City",
                    "placeholder": "San Francisco",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "",
                    "helper_text": "State of the lead",
                    "label": "State",
                    "placeholder": "CA",
                },
                {
                    "field": "country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Country of the lead",
                    "label": "Country",
                    "placeholder": "USA",
                },
                {
                    "field": "postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Postal code of the lead",
                    "label": "Postal Code",
                    "placeholder": "94105",
                },
                {
                    "field": "street",
                    "type": "string",
                    "value": "",
                    "helper_text": "Street address of the lead",
                    "label": "Street",
                    "placeholder": "123 Main St",
                },
                {
                    "field": "fax",
                    "type": "string",
                    "value": "",
                    "helper_text": "Fax number of the lead",
                    "label": "Fax",
                    "placeholder": "+1-555-123-4568",
                },
                {
                    "field": "mobile_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mobile phone number of the lead",
                    "label": "Mobile Phone",
                    "placeholder": "+1-555-123-4569",
                },
                {
                    "field": "salutation",
                    "type": "string",
                    "value": "",
                    "helper_text": "Salutation for the lead",
                    "label": "Select Salutation",
                    "placeholder": "Mr.",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_salutation",
                    },
                },
                {
                    "field": "annual_revenue",
                    "type": "int32",
                    "value": "",
                    "helper_text": "Annual revenue of the company",
                    "label": "Annual Revenue",
                    "placeholder": "1000000",
                },
                {
                    "field": "number_of_employees",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "Number of employees in the company",
                    "label": "Number of Employees",
                    "placeholder": "100",
                },
                {
                    "field": "is_unread_by_owner",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the lead is unread by owner",
                    "label": "Unread by Owner",
                },
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner ID of the lead",
                    "label": "Select Owner",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "record_type_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Record type ID for the lead",
                    "label": "Record Type ID",
                    "placeholder": "012XXXXXXXXXXXXXXX",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields in JSON format",
                    "label": "Custom Fields",
                    "placeholder": '{"field_name": "value"}',
                },
            ],
            "outputs": [
                {
                    "field": "lead_id",
                    "type": "string",
                    "helper_text": "ID of the created lead",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_lead",
            "task_name": "tasks.salesforce.create_lead",
            "description": "Create a new lead in Salesforce",
            "label": "Create Lead",
            "required": ["company", "lastname"],
            "ui_sort_order": [
                "integration",
                "action",
                "company",
                "lastname",
                "first_name",
                "email",
                "phone",
                "title",
                "website",
                "industry",
                "description",
                "status",
                "rating",
                "lead_source",
                "city",
                "state",
                "country",
                "postal_code",
                "street",
                "fax",
                "mobile_phone",
                "salutation",
                "annual_revenue",
                "number_of_employees",
                "is_unread_by_owner",
                "owner",
                "record_type_id",
                "custom_fields",
            ],
        },
        "upsert_lead**(*)**(*)": {
            "inputs": [
                {
                    "field": "external_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "External ID field name",
                    "label": "External ID Field",
                    "placeholder": "External_Id__c",
                },
                {
                    "field": "external_id_value",
                    "type": "string",
                    "value": "",
                    "helper_text": "Value for the external ID",
                    "label": "External ID Value",
                    "placeholder": "LEAD-001",
                },
                {
                    "field": "company",
                    "type": "string",
                    "value": "",
                    "helper_text": "Company name for the lead",
                    "label": "Company",
                    "placeholder": "Acme Corporation",
                },
                {
                    "field": "lastname",
                    "type": "string",
                    "value": "",
                    "helper_text": "Last name of the lead",
                    "label": "Last Name",
                    "placeholder": "Smith",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "First name of the lead",
                    "label": "First Name",
                    "placeholder": "John",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email address of the lead",
                    "label": "Email",
                    "placeholder": "john.smith@acme.com",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Phone number of the lead",
                    "label": "Phone",
                    "placeholder": "+1-555-123-4567",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Job title of the lead",
                    "label": "Title",
                    "placeholder": "CEO",
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "helper_text": "Company website",
                    "label": "Website",
                    "placeholder": "https://acme.com",
                },
                {
                    "field": "industry",
                    "type": "string",
                    "value": "",
                    "helper_text": "Industry of the company",
                    "label": "Select Industry",
                    "placeholder": "Technology",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_industry",
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the lead",
                    "label": "Description",
                    "placeholder": "Potential customer for our services",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Status of the lead",
                    "label": "Select Status",
                    "placeholder": "Open - Not Contacted",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_lead_status",
                    },
                },
                {
                    "field": "rating",
                    "type": "string",
                    "value": "",
                    "helper_text": "Rating of the lead",
                    "label": "Select Rating",
                    "placeholder": "Hot",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_rating",
                    },
                },
                {
                    "field": "lead_source",
                    "type": "string",
                    "value": "",
                    "helper_text": "Source of the lead",
                    "label": "Select Lead Source",
                    "placeholder": "Web",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_lead_source",
                    },
                },
                {
                    "field": "city",
                    "type": "string",
                    "value": "",
                    "helper_text": "City of the lead",
                    "label": "City",
                    "placeholder": "San Francisco",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "",
                    "helper_text": "State of the lead",
                    "label": "State",
                    "placeholder": "CA",
                },
                {
                    "field": "country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Country of the lead",
                    "label": "Country",
                    "placeholder": "USA",
                },
                {
                    "field": "postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Postal code of the lead",
                    "label": "Postal Code",
                    "placeholder": "94105",
                },
                {
                    "field": "street",
                    "type": "string",
                    "value": "",
                    "helper_text": "Street address of the lead",
                    "label": "Street",
                    "placeholder": "123 Main St",
                },
                {
                    "field": "fax",
                    "type": "string",
                    "value": "",
                    "helper_text": "Fax number of the lead",
                    "label": "Fax",
                    "placeholder": "+1-555-123-4568",
                },
                {
                    "field": "mobile_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mobile phone number of the lead",
                    "label": "Mobile Phone",
                    "placeholder": "+1-555-123-4569",
                },
                {
                    "field": "salutation",
                    "type": "string",
                    "value": "",
                    "helper_text": "Salutation for the lead",
                    "label": "Select Salutation",
                    "placeholder": "Mr.",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_salutation",
                    },
                },
                {
                    "field": "annual_revenue",
                    "type": "int32",
                    "value": "",
                    "helper_text": "Annual revenue of the company",
                    "label": "Annual Revenue",
                    "placeholder": "1000000",
                },
                {
                    "field": "number_of_employees",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "Number of employees in the company",
                    "label": "Number of Employees",
                    "placeholder": "100",
                },
                {
                    "field": "is_unread_by_owner",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the lead is unread by owner",
                    "label": "Unread by Owner",
                },
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner ID of the lead",
                    "label": "Select Owner",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "record_type_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Record type ID for the lead",
                    "label": "Record Type ID",
                    "placeholder": "012XXXXXXXXXXXXXXX",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields in JSON format",
                    "label": "Custom Fields",
                    "placeholder": '{"field_name": "value"}',
                },
            ],
            "outputs": [
                {
                    "field": "lead_id",
                    "type": "string",
                    "helper_text": "ID of the upserted lead",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "upsert_lead",
            "task_name": "tasks.salesforce.upsert_lead",
            "description": "Upsert a lead in Salesforce using external ID",
            "label": "Create or Update Lead",
            "required": ["external_id", "external_id_value", "company", "lastname"],
            "ui_sort_order": [
                "integration",
                "action",
                "external_id",
                "external_id_value",
                "company",
                "lastname",
                "first_name",
                "email",
                "phone",
                "title",
                "website",
                "industry",
                "description",
                "status",
                "rating",
                "lead_source",
                "city",
                "state",
                "country",
                "postal_code",
                "street",
                "fax",
                "mobile_phone",
                "salutation",
                "annual_revenue",
                "number_of_employees",
                "is_unread_by_owner",
                "owner",
                "record_type_id",
                "custom_fields",
            ],
        },
        "update_lead**(*)**(*)": {
            "inputs": [
                {
                    "field": "lead_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the lead to update",
                    "label": "Select Lead",
                    "placeholder": "00QXXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=lead&parent_id=leads&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "company",
                    "type": "string",
                    "value": "",
                    "helper_text": "Company name for the lead",
                    "label": "Company",
                    "placeholder": "Acme Corporation",
                },
                {
                    "field": "lastname",
                    "type": "string",
                    "value": "",
                    "helper_text": "Last name of the lead",
                    "label": "Last Name",
                    "placeholder": "Smith",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "First name of the lead",
                    "label": "First Name",
                    "placeholder": "John",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email address of the lead",
                    "label": "Email",
                    "placeholder": "john.smith@acme.com",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Phone number of the lead",
                    "label": "Phone",
                    "placeholder": "+1-555-123-4567",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Job title of the lead",
                    "label": "Title",
                    "placeholder": "CEO",
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "helper_text": "Company website",
                    "label": "Website",
                    "placeholder": "https://acme.com",
                },
                {
                    "field": "industry",
                    "type": "string",
                    "value": "",
                    "helper_text": "Industry of the company",
                    "label": "Select Industry",
                    "placeholder": "Technology",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_industry",
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the lead",
                    "label": "Description",
                    "placeholder": "Potential customer for our services",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Status of the lead",
                    "label": "Select Status",
                    "placeholder": "Open - Not Contacted",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_lead_status",
                    },
                },
                {
                    "field": "rating",
                    "type": "string",
                    "value": "",
                    "helper_text": "Rating of the lead",
                    "label": "Select Rating",
                    "placeholder": "Hot",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_rating",
                    },
                },
                {
                    "field": "lead_source",
                    "type": "string",
                    "value": "",
                    "helper_text": "Source of the lead",
                    "label": "Select Lead Source",
                    "placeholder": "Web",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_lead_source",
                    },
                },
                {
                    "field": "city",
                    "type": "string",
                    "value": "",
                    "helper_text": "City of the lead",
                    "label": "City",
                    "placeholder": "San Francisco",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "",
                    "helper_text": "State of the lead",
                    "label": "State",
                    "placeholder": "CA",
                },
                {
                    "field": "country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Country of the lead",
                    "label": "Country",
                    "placeholder": "USA",
                },
                {
                    "field": "postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Postal code of the lead",
                    "label": "Postal Code",
                    "placeholder": "94105",
                },
                {
                    "field": "street",
                    "type": "string",
                    "value": "",
                    "helper_text": "Street address of the lead",
                    "label": "Street",
                    "placeholder": "123 Main St",
                },
                {
                    "field": "fax",
                    "type": "string",
                    "value": "",
                    "helper_text": "Fax number of the lead",
                    "label": "Fax",
                    "placeholder": "+1-555-123-4568",
                },
                {
                    "field": "mobile_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mobile phone number of the lead",
                    "label": "Mobile Phone",
                    "placeholder": "+1-555-123-4569",
                },
                {
                    "field": "salutation",
                    "type": "string",
                    "value": "",
                    "helper_text": "Salutation for the lead",
                    "label": "Select Salutation",
                    "placeholder": "Mr.",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_salutation",
                    },
                },
                {
                    "field": "annual_revenue",
                    "type": "int32",
                    "value": "",
                    "helper_text": "Annual revenue of the company",
                    "label": "Annual Revenue",
                    "placeholder": "1000000",
                },
                {
                    "field": "number_of_employees",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "Number of employees in the company",
                    "label": "Number of Employees",
                    "placeholder": "100",
                },
                {
                    "field": "is_unread_by_owner",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the lead is unread by owner",
                    "label": "Unread by Owner",
                },
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner ID of the lead",
                    "label": "Select Owner",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "record_type_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Record type ID for the lead",
                    "label": "Record Type ID",
                    "placeholder": "012XXXXXXXXXXXXXXX",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields in JSON format",
                    "label": "Custom Fields",
                    "placeholder": '{"field_name": "value"}',
                },
            ],
            "outputs": [
                {
                    "field": "lead_id",
                    "type": "string",
                    "helper_text": "ID of the updated lead",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_lead",
            "task_name": "tasks.salesforce.update_lead",
            "description": "Update an existing lead in Salesforce",
            "label": "Update Lead",
            "required": ["lead_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "lead_id",
                "company",
                "lastname",
                "first_name",
                "email",
                "phone",
                "title",
                "website",
                "industry",
                "description",
                "status",
                "rating",
                "lead_source",
                "city",
                "state",
                "country",
                "postal_code",
                "street",
                "fax",
                "mobile_phone",
                "salutation",
                "annual_revenue",
                "number_of_employees",
                "is_unread_by_owner",
                "owner",
                "record_type_id",
                "custom_fields",
            ],
        },
        "read_lead**(*)**(*)": {
            "inputs": [
                {
                    "field": "lead_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the lead to read",
                    "label": "Select Lead",
                    "placeholder": "00QXXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=lead&parent_id=leads&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {"field": "lead_id", "type": "string", "helper_text": "ID of the lead"},
                {
                    "field": "lead_name",
                    "type": "string",
                    "helper_text": "Full name of the lead",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Email address of the lead",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "helper_text": "Phone number of the lead",
                },
                {
                    "field": "company",
                    "type": "string",
                    "helper_text": "Company name of the lead",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the lead",
                },
                {
                    "field": "lead_source",
                    "type": "string",
                    "helper_text": "Source of the lead",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp of the lead",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Last update timestamp of the lead",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "helper_text": "Owner ID of the lead",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Job title of the lead",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the lead",
                },
                {
                    "field": "industry",
                    "type": "string",
                    "helper_text": "Industry of the company",
                },
                {
                    "field": "website",
                    "type": "string",
                    "helper_text": "Company website",
                },
                {"field": "city", "type": "string", "helper_text": "City of the lead"},
                {
                    "field": "state",
                    "type": "string",
                    "helper_text": "State of the lead",
                },
                {
                    "field": "country",
                    "type": "string",
                    "helper_text": "Country of the lead",
                },
                {
                    "field": "postal_code",
                    "type": "string",
                    "helper_text": "Postal code of the lead",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_lead",
            "task_name": "tasks.salesforce.read_lead",
            "description": "Read details of a specific lead",
            "label": "Get Lead",
            "required": ["lead_id"],
            "ui_sort_order": ["integration", "action", "lead_id"],
        },
        "delete_lead**(*)**(*)": {
            "inputs": [
                {
                    "field": "lead_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the lead to delete",
                    "label": "Select Lead",
                    "placeholder": "00QXXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=lead&parent_id=leads&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "lead_id",
                    "type": "string",
                    "helper_text": "ID of the deleted lead",
                },
                {
                    "field": "deleted",
                    "type": "bool",
                    "helper_text": "Whether the lead was successfully deleted",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_lead",
            "task_name": "tasks.salesforce.delete_lead",
            "description": "Delete an existing lead in Salesforce",
            "label": "Delete Lead",
            "required": ["lead_id"],
            "ui_sort_order": ["integration", "action", "lead_id"],
        },
        "get_leads**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields to retrieve (comma-separated)",
                    "label": "Fields",
                    "placeholder": "Id, FirstName, LastName, Company",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Search query to filter leads",
                    "label": "Search Query",
                    "placeholder": "john@example.com",
                },
                {
                    "field": "condition",
                    "type": "string",
                    "value": "",
                    "helper_text": "Condition operator for multiple filters (AND/OR)",
                    "label": "Condition Operator",
                    "placeholder": "AND",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "AND", "value": "AND"},
                            {"label": "OR", "value": "OR"},
                        ],
                    },
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by first name",
                    "label": "First Name",
                    "placeholder": "John",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by last name",
                    "label": "Last Name",
                    "placeholder": "Doe",
                },
                {
                    "field": "company",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by company name",
                    "label": "Company",
                    "placeholder": "Acme Corp",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by email address",
                    "label": "Email",
                    "placeholder": "john@example.com",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by phone number",
                    "label": "Phone",
                    "placeholder": "+1-555-123-4567",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by lead status",
                    "label": "Status",
                    "placeholder": "New",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_lead_status",
                    },
                },
                {
                    "field": "lead_source",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by lead source",
                    "label": "Lead Source",
                    "placeholder": "Website",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_lead_source",
                    },
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by job title",
                    "label": "Title",
                    "placeholder": "Manager",
                },
                {
                    "field": "industry",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by industry",
                    "label": "Industry",
                    "placeholder": "Technology",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_industry",
                    },
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by website",
                    "label": "Website",
                    "placeholder": "www.example.com",
                },
                {
                    "field": "city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by city",
                    "label": "City",
                    "placeholder": "San Francisco",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by state",
                    "label": "State",
                    "placeholder": "CA",
                },
                {
                    "field": "country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by country",
                    "label": "Country",
                    "placeholder": "USA",
                },
                {
                    "field": "postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by postal code",
                    "label": "Postal Code",
                    "placeholder": "94105",
                },
                {
                    "field": "street",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by street address",
                    "label": "Street",
                    "placeholder": "123 Main St",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by description",
                    "label": "Description",
                    "placeholder": "Potential customer",
                },
                {
                    "field": "annual_revenue",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by annual revenue",
                    "label": "Annual Revenue",
                    "placeholder": "1000000",
                },
                {
                    "field": "number_of_employees",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by number of employees",
                    "label": "Number of Employees",
                    "placeholder": "100",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by owner ID",
                    "label": "Owner ID",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                },
                {
                    "field": "rating",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by rating",
                    "label": "Rating",
                    "placeholder": "Hot",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_rating",
                    },
                },
                {
                    "field": "created_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by creation date (YYYY-MM-DD)",
                    "label": "Created Date",
                    "placeholder": "2024-01-01",
                },
                {
                    "field": "modified_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by modification date (YYYY-MM-DD)",
                    "label": "Modified Date",
                    "placeholder": "2024-01-01",
                },
            ],
            "outputs": [
                {
                    "field": "total_size",
                    "type": "int32",
                    "helper_text": "Total number of records returned",
                },
                {
                    "field": "done",
                    "type": "bool",
                    "helper_text": "Whether the query is complete",
                },
                {
                    "field": "lead_ids",
                    "type": "vec<string>",
                    "helper_text": "List of lead IDs",
                },
                {
                    "field": "lead_names",
                    "type": "vec<string>",
                    "helper_text": "List of lead names",
                },
                {
                    "field": "emails",
                    "type": "vec<string>",
                    "helper_text": "List of lead emails",
                },
                {
                    "field": "phones",
                    "type": "vec<string>",
                    "helper_text": "List of lead phone numbers",
                },
                {
                    "field": "companies",
                    "type": "vec<string>",
                    "helper_text": "List of lead companies",
                },
                {
                    "field": "statuses",
                    "type": "vec<string>",
                    "helper_text": "List of lead statuses",
                },
                {
                    "field": "lead_sources",
                    "type": "vec<string>",
                    "helper_text": "List of lead sources",
                },
                {
                    "field": "created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "updated_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of update dates",
                },
                {
                    "field": "owner_ids",
                    "type": "vec<string>",
                    "helper_text": "List of owner IDs",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_leads",
            "task_name": "tasks.salesforce.get_leads",
            "description": "Get multiple leads",
            "label": "List Leads",
            "required": ["num_messages"],
            "inputs_sort_order": [
                "integration",
                "action",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "fields",
                "query",
                "condition",
                "first_name",
                "last_name",
                "company",
                "email",
                "phone",
                "status",
                "lead_source",
                "title",
                "industry",
                "website",
                "city",
                "state",
                "country",
                "postal_code",
                "street",
                "description",
                "annual_revenue",
                "number_of_employees",
                "owner_id",
                "rating",
                "created_date",
                "modified_date",
            ],
        },
        "get_leads**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Leads",
                    "helper_text": "Specify the number of leads to fetch",
                }
            ],
            "outputs": [],
        },
        "get_leads**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_leads**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_leads**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_lead_summary**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Name of the lead object",
                },
                {
                    "field": "label",
                    "type": "string",
                    "helper_text": "Label of the lead object",
                },
                {
                    "field": "updateable",
                    "type": "bool",
                    "helper_text": "Whether the lead object is updateable",
                },
                {
                    "field": "deletable",
                    "type": "bool",
                    "helper_text": "Whether the lead object is deletable",
                },
                {
                    "field": "queryable",
                    "type": "bool",
                    "helper_text": "Whether the lead object is queryable",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "helper_text": "Available fields for the lead object",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_lead_summary",
            "task_name": "tasks.salesforce.get_lead_summary",
            "description": "Read details of a specific lead summary",
            "label": "Get Lead Summary",
            "required": [],
            "inputs_sort_order": ["integration", "action"],
        },
        "add_lead_to_campaign**(*)**(*)": {
            "inputs": [
                {
                    "field": "lead_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the lead to add to campaign",
                    "label": "Select Lead",
                    "placeholder": "00QXXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=lead&parent_id=leads&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "campaign_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the campaign to add the lead to",
                    "label": "Campaign ID",
                    "placeholder": "701XXXXXXXXXXXXXXX",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Status of the lead in the campaign",
                    "label": "Select Status",
                    "placeholder": "Sent",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_campaign_member_status",
                    },
                },
                {
                    "field": "has_responded",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the lead has responded",
                    "label": "Has Responded",
                },
            ],
            "outputs": [
                {
                    "field": "campaign_member_id",
                    "type": "string",
                    "helper_text": "ID of the created campaign member",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "add_lead_to_campaign",
            "task_name": "tasks.salesforce.add_lead_to_campaign",
            "description": "Add a lead to a campaign in Salesforce",
            "label": "Add Lead to Campaign",
            "required": ["lead_id", "campaign_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "lead_id",
                "campaign_id",
                "status",
                "has_responded",
            ],
        },
        "add_lead_note**(*)**(*)": {
            "inputs": [
                {
                    "field": "lead_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the lead to add note to",
                    "label": "Select Lead",
                    "placeholder": "00QXXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=lead&parent_id=leads&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Title of the note",
                    "label": "Note Title",
                    "placeholder": "Follow-up call",
                },
                {
                    "field": "body",
                    "type": "string",
                    "value": "",
                    "helper_text": "Content of the note",
                    "label": "Note Body",
                    "placeholder": "Called the lead to discuss their requirements",
                },
                {
                    "field": "is_private",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the note is private",
                    "label": "Is Private",
                },
            ],
            "outputs": [
                {
                    "field": "note_id",
                    "type": "string",
                    "helper_text": "ID of the created note",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "add_lead_note",
            "task_name": "tasks.salesforce.add_lead_note",
            "description": "Add a note to a lead in Salesforce",
            "label": "Add Lead Note",
            "required": ["lead_id", "title", "body"],
            "ui_sort_order": [
                "integration",
                "action",
                "lead_id",
                "title",
                "body",
                "is_private",
            ],
        },
        "create_contact**(*)**(*)": {
            "inputs": [
                {
                    "field": "lastname",
                    "type": "string",
                    "value": "",
                    "helper_text": "Last name of the contact",
                    "label": "Last Name",
                    "placeholder": "Smith",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "First name of the contact",
                    "label": "First Name",
                    "placeholder": "John",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email address of the contact",
                    "label": "Email",
                    "placeholder": "john.smith@acme.com",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Phone number of the contact",
                    "label": "Phone",
                    "placeholder": "+1-555-123-4567",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Job title of the contact",
                    "label": "Title",
                    "placeholder": "CEO",
                },
                {
                    "field": "department",
                    "type": "string",
                    "value": "",
                    "helper_text": "Department of the contact",
                    "label": "Department",
                    "placeholder": "Executive",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the contact",
                    "label": "Description",
                    "placeholder": "Key decision maker for the company",
                },
                {
                    "field": "salutation",
                    "type": "string",
                    "value": "",
                    "helper_text": "Salutation for the contact",
                    "label": "Select Salutation",
                    "placeholder": "Mr.",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_salutation",
                    },
                },
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the associated account",
                    "label": "Account ID",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                },
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner ID of the contact",
                    "label": "Select Owner",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "record_type_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Record type ID for the contact",
                    "label": "Record Type ID",
                    "placeholder": "012XXXXXXXXXXXXXXX",
                },
                {
                    "field": "lead_source",
                    "type": "string",
                    "value": "",
                    "helper_text": "Source of the contact",
                    "label": "Select Lead Source",
                    "placeholder": "Web",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_lead_source",
                    },
                },
                {
                    "field": "fax",
                    "type": "string",
                    "value": "",
                    "helper_text": "Fax number of the contact",
                    "label": "Fax",
                    "placeholder": "+1-555-123-4568",
                },
                {
                    "field": "mobile_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mobile phone number of the contact",
                    "label": "Mobile Phone",
                    "placeholder": "+1-555-123-4569",
                },
                {
                    "field": "home_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Home phone number of the contact",
                    "label": "Home Phone",
                    "placeholder": "+1-555-123-4570",
                },
                {
                    "field": "other_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Other phone number of the contact",
                    "label": "Other Phone",
                    "placeholder": "+1-555-123-4571",
                },
                {
                    "field": "assistant_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the contact's assistant",
                    "label": "Assistant Name",
                    "placeholder": "Jane Doe",
                },
                {
                    "field": "assistant_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Phone number of the contact's assistant",
                    "label": "Assistant Phone",
                    "placeholder": "+1-555-123-4572",
                },
                {
                    "field": "mailing_street",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mailing street address",
                    "label": "Mailing Street",
                    "placeholder": "123 Main St",
                },
                {
                    "field": "mailing_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mailing city",
                    "label": "Mailing City",
                    "placeholder": "San Francisco",
                },
                {
                    "field": "mailing_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mailing state",
                    "label": "Mailing State",
                    "placeholder": "CA",
                },
                {
                    "field": "mailing_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mailing postal code",
                    "label": "Mailing Postal Code",
                    "placeholder": "94105",
                },
                {
                    "field": "mailing_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mailing country",
                    "label": "Mailing Country",
                    "placeholder": "USA",
                },
                {
                    "field": "other_street",
                    "type": "string",
                    "value": "",
                    "helper_text": "Other street address",
                    "label": "Other Street",
                    "placeholder": "456 Oak Ave",
                },
                {
                    "field": "other_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Other city",
                    "label": "Other City",
                    "placeholder": "Los Angeles",
                },
                {
                    "field": "other_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Other state",
                    "label": "Other State",
                    "placeholder": "CA",
                },
                {
                    "field": "other_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Other postal code",
                    "label": "Other Postal Code",
                    "placeholder": "90210",
                },
                {
                    "field": "other_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Other country",
                    "label": "Other Country",
                    "placeholder": "USA",
                },
                {
                    "field": "birthdate",
                    "type": "string",
                    "value": "",
                    "helper_text": "Birth date of the contact",
                    "label": "Birth Date",
                    "placeholder": "1980-01-01",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields in JSON format",
                    "label": "Custom Fields",
                    "placeholder": '{"field_name": "value"}',
                },
            ],
            "outputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "ID of the created contact",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_contact",
            "task_name": "tasks.salesforce.create_contact",
            "description": "Create a new contact in Salesforce",
            "label": "Create Contact",
            "required": ["lastname"],
            "ui_sort_order": [
                "integration",
                "action",
                "lastname",
                "first_name",
                "email",
                "phone",
                "title",
                "department",
                "description",
                "salutation",
                "account_id",
                "owner",
                "record_type_id",
                "lead_source",
                "fax",
                "mobile_phone",
                "home_phone",
                "other_phone",
                "assistant_name",
                "assistant_phone",
                "mailing_street",
                "mailing_city",
                "mailing_state",
                "mailing_postal_code",
                "mailing_country",
                "other_street",
                "other_city",
                "other_state",
                "other_postal_code",
                "other_country",
                "birthdate",
                "custom_fields",
            ],
        },
        "upsert_contact**(*)**(*)": {
            "inputs": [
                {
                    "field": "external_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "External ID field name",
                    "label": "External ID Field",
                    "placeholder": "External_Id__c",
                },
                {
                    "field": "external_id_value",
                    "type": "string",
                    "value": "",
                    "helper_text": "Value for the external ID",
                    "label": "External ID Value",
                    "placeholder": "CONTACT-001",
                },
                {
                    "field": "lastname",
                    "type": "string",
                    "value": "",
                    "helper_text": "Last name of the contact",
                    "label": "Last Name",
                    "placeholder": "Smith",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "First name of the contact",
                    "label": "First Name",
                    "placeholder": "John",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email address of the contact",
                    "label": "Email",
                    "placeholder": "john.smith@acme.com",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Phone number of the contact",
                    "label": "Phone",
                    "placeholder": "+1-555-123-4567",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Job title of the contact",
                    "label": "Title",
                    "placeholder": "CEO",
                },
                {
                    "field": "department",
                    "type": "string",
                    "value": "",
                    "helper_text": "Department of the contact",
                    "label": "Department",
                    "placeholder": "Executive",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the contact",
                    "label": "Description",
                    "placeholder": "Key decision maker for the company",
                },
                {
                    "field": "salutation",
                    "type": "string",
                    "value": "",
                    "helper_text": "Salutation for the contact",
                    "label": "Select Salutation",
                    "placeholder": "Mr.",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_salutation",
                    },
                },
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the associated account",
                    "label": "Account ID",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                },
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner ID of the contact",
                    "label": "Select Owner",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "record_type_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Record type ID for the contact",
                    "label": "Record Type ID",
                    "placeholder": "012XXXXXXXXXXXXXXX",
                },
                {
                    "field": "lead_source",
                    "type": "string",
                    "value": "",
                    "helper_text": "Source of the contact",
                    "label": "Select Lead Source",
                    "placeholder": "Web",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_lead_source",
                    },
                },
                {
                    "field": "fax",
                    "type": "string",
                    "value": "",
                    "helper_text": "Fax number of the contact",
                    "label": "Fax",
                    "placeholder": "+1-555-123-4568",
                },
                {
                    "field": "mobile_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mobile phone number of the contact",
                    "label": "Mobile Phone",
                    "placeholder": "+1-555-123-4569",
                },
                {
                    "field": "home_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Home phone number of the contact",
                    "label": "Home Phone",
                    "placeholder": "+1-555-123-4570",
                },
                {
                    "field": "other_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Other phone number of the contact",
                    "label": "Other Phone",
                    "placeholder": "+1-555-123-4571",
                },
                {
                    "field": "assistant_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the contact's assistant",
                    "label": "Assistant Name",
                    "placeholder": "Jane Doe",
                },
                {
                    "field": "assistant_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Phone number of the contact's assistant",
                    "label": "Assistant Phone",
                    "placeholder": "+1-555-123-4572",
                },
                {
                    "field": "mailing_street",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mailing street address",
                    "label": "Mailing Street",
                    "placeholder": "123 Main St",
                },
                {
                    "field": "mailing_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mailing city",
                    "label": "Mailing City",
                    "placeholder": "San Francisco",
                },
                {
                    "field": "mailing_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mailing state",
                    "label": "Mailing State",
                    "placeholder": "CA",
                },
                {
                    "field": "mailing_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mailing postal code",
                    "label": "Mailing Postal Code",
                    "placeholder": "94105",
                },
                {
                    "field": "mailing_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mailing country",
                    "label": "Mailing Country",
                    "placeholder": "USA",
                },
                {
                    "field": "other_street",
                    "type": "string",
                    "value": "",
                    "helper_text": "Other street address",
                    "label": "Other Street",
                    "placeholder": "456 Oak Ave",
                },
                {
                    "field": "other_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Other city",
                    "label": "Other City",
                    "placeholder": "Los Angeles",
                },
                {
                    "field": "other_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Other state",
                    "label": "Other State",
                    "placeholder": "CA",
                },
                {
                    "field": "other_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Other postal code",
                    "label": "Other Postal Code",
                    "placeholder": "90210",
                },
                {
                    "field": "other_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Other country",
                    "label": "Other Country",
                    "placeholder": "USA",
                },
                {
                    "field": "birthdate",
                    "type": "string",
                    "value": "",
                    "helper_text": "Birth date of the contact",
                    "label": "Birth Date",
                    "placeholder": "1980-01-01",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields in JSON format",
                    "label": "Custom Fields",
                    "placeholder": '{"field_name": "value"}',
                },
            ],
            "outputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "ID of the upserted contact",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "upsert_contact",
            "task_name": "tasks.salesforce.upsert_contact",
            "description": "Upsert a contact in Salesforce using external ID",
            "label": "Create or Update Contact",
            "required": ["external_id", "external_id_value", "lastname"],
            "ui_sort_order": [
                "integration",
                "action",
                "external_id",
                "external_id_value",
                "lastname",
                "first_name",
                "email",
                "phone",
                "title",
                "department",
                "description",
                "salutation",
                "account_id",
                "owner",
                "record_type_id",
                "lead_source",
                "fax",
                "mobile_phone",
                "home_phone",
                "other_phone",
                "assistant_name",
                "assistant_phone",
                "mailing_street",
                "mailing_city",
                "mailing_state",
                "mailing_postal_code",
                "mailing_country",
                "other_street",
                "other_city",
                "other_state",
                "other_postal_code",
                "other_country",
                "birthdate",
                "custom_fields",
            ],
        },
        "update_contact**(*)**(*)": {
            "inputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the contact to update",
                    "label": "Select Contact",
                    "placeholder": "003XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=contact&parent_id=contacts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "lastname",
                    "type": "string",
                    "value": "",
                    "helper_text": "Last name of the contact",
                    "label": "Last Name",
                    "placeholder": "Smith",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "First name of the contact",
                    "label": "First Name",
                    "placeholder": "John",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email address of the contact",
                    "label": "Email",
                    "placeholder": "john.smith@acme.com",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Phone number of the contact",
                    "label": "Phone",
                    "placeholder": "+1-555-123-4567",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Job title of the contact",
                    "label": "Title",
                    "placeholder": "CEO",
                },
                {
                    "field": "department",
                    "type": "string",
                    "value": "",
                    "helper_text": "Department of the contact",
                    "label": "Department",
                    "placeholder": "Executive",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the contact",
                    "label": "Description",
                    "placeholder": "Key decision maker for the company",
                },
                {
                    "field": "salutation",
                    "type": "string",
                    "value": "",
                    "helper_text": "Salutation for the contact",
                    "label": "Select Salutation",
                    "placeholder": "Mr.",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_salutation",
                    },
                },
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the associated account",
                    "label": "Account ID",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                },
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner ID of the contact",
                    "label": "Select Owner",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "record_type_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Record type ID for the contact",
                    "label": "Record Type ID",
                    "placeholder": "012XXXXXXXXXXXXXXX",
                },
                {
                    "field": "lead_source",
                    "type": "string",
                    "value": "",
                    "helper_text": "Source of the contact",
                    "label": "Select Lead Source",
                    "placeholder": "Web",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_lead_source",
                    },
                },
                {
                    "field": "fax",
                    "type": "string",
                    "value": "",
                    "helper_text": "Fax number of the contact",
                    "label": "Fax",
                    "placeholder": "+1-555-123-4568",
                },
                {
                    "field": "mobile_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mobile phone number of the contact",
                    "label": "Mobile Phone",
                    "placeholder": "+1-555-123-4569",
                },
                {
                    "field": "home_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Home phone number of the contact",
                    "label": "Home Phone",
                    "placeholder": "+1-555-123-4570",
                },
                {
                    "field": "other_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Other phone number of the contact",
                    "label": "Other Phone",
                    "placeholder": "+1-555-123-4571",
                },
                {
                    "field": "assistant_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the contact's assistant",
                    "label": "Assistant Name",
                    "placeholder": "Jane Doe",
                },
                {
                    "field": "assistant_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Phone number of the contact's assistant",
                    "label": "Assistant Phone",
                    "placeholder": "+1-555-123-4572",
                },
                {
                    "field": "mailing_street",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mailing street address",
                    "label": "Mailing Street",
                    "placeholder": "123 Main St",
                },
                {
                    "field": "mailing_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mailing city",
                    "label": "Mailing City",
                    "placeholder": "San Francisco",
                },
                {
                    "field": "mailing_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mailing state",
                    "label": "Mailing State",
                    "placeholder": "CA",
                },
                {
                    "field": "mailing_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mailing postal code",
                    "label": "Mailing Postal Code",
                    "placeholder": "94105",
                },
                {
                    "field": "mailing_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mailing country",
                    "label": "Mailing Country",
                    "placeholder": "USA",
                },
                {
                    "field": "other_street",
                    "type": "string",
                    "value": "",
                    "helper_text": "Other street address",
                    "label": "Other Street",
                    "placeholder": "456 Oak Ave",
                },
                {
                    "field": "other_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Other city",
                    "label": "Other City",
                    "placeholder": "Los Angeles",
                },
                {
                    "field": "other_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Other state",
                    "label": "Other State",
                    "placeholder": "CA",
                },
                {
                    "field": "other_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Other postal code",
                    "label": "Other Postal Code",
                    "placeholder": "90210",
                },
                {
                    "field": "other_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Other country",
                    "label": "Other Country",
                    "placeholder": "USA",
                },
                {
                    "field": "birthdate",
                    "type": "string",
                    "value": "",
                    "helper_text": "Birth date of the contact",
                    "label": "Birth Date",
                    "placeholder": "1980-01-01",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields in JSON format",
                    "label": "Custom Fields",
                    "placeholder": '{"field_name": "value"}',
                },
            ],
            "outputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "ID of the updated contact",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_contact",
            "task_name": "tasks.salesforce.update_contact",
            "description": "Update an existing contact in Salesforce",
            "label": "Update Contact",
            "required": ["contact_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "contact_id",
                "lastname",
                "first_name",
                "email",
                "phone",
                "title",
                "department",
                "description",
                "salutation",
                "account_id",
                "owner",
                "record_type_id",
                "lead_source",
                "fax",
                "mobile_phone",
                "home_phone",
                "other_phone",
                "assistant_name",
                "assistant_phone",
                "mailing_street",
                "mailing_city",
                "mailing_state",
                "mailing_postal_code",
                "mailing_country",
                "other_street",
                "other_city",
                "other_state",
                "other_postal_code",
                "other_country",
                "birthdate",
                "custom_fields",
            ],
        },
        "read_contact**(*)**(*)": {
            "inputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the contact to read",
                    "label": "Select Contact",
                    "placeholder": "003XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=contact&parent_id=contacts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "ID of the contact",
                },
                {
                    "field": "contact_name",
                    "type": "string",
                    "helper_text": "Full name of the contact",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Email address of the contact",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "helper_text": "Phone number of the contact",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Job title of the contact",
                },
                {
                    "field": "department",
                    "type": "string",
                    "helper_text": "Department of the contact",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the contact",
                },
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "ID of the associated account",
                },
                {
                    "field": "lead_source",
                    "type": "string",
                    "helper_text": "Source of the contact",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp of the contact",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Last update timestamp of the contact",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "helper_text": "Owner ID of the contact",
                },
                {
                    "field": "mailing_city",
                    "type": "string",
                    "helper_text": "Mailing city of the contact",
                },
                {
                    "field": "mailing_state",
                    "type": "string",
                    "helper_text": "Mailing state of the contact",
                },
                {
                    "field": "mailing_country",
                    "type": "string",
                    "helper_text": "Mailing country of the contact",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_contact",
            "task_name": "tasks.salesforce.read_contact",
            "description": "Read details of a specific contact",
            "label": "Get Contact",
            "required": ["contact_id"],
            "ui_sort_order": ["integration", "action", "contact_id"],
        },
        "delete_contact**(*)**(*)": {
            "inputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the contact to delete",
                    "label": "Select Contact",
                    "placeholder": "003XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=contact&parent_id=contacts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "ID of the deleted contact",
                },
                {
                    "field": "deleted",
                    "type": "bool",
                    "helper_text": "Whether the contact was successfully deleted",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_contact",
            "task_name": "tasks.salesforce.delete_contact",
            "description": "Delete an existing contact in Salesforce",
            "label": "Delete Contact",
            "required": ["contact_id"],
            "ui_sort_order": ["integration", "action", "contact_id"],
        },
        "get_contacts**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields to retrieve (comma-separated)",
                    "label": "Fields",
                    "placeholder": "Id, FirstName, LastName, Email",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Search query to filter contacts",
                    "label": "Search Query",
                    "placeholder": "john@example.com",
                },
                {
                    "field": "condition",
                    "type": "string",
                    "value": "",
                    "helper_text": "Condition operator for multiple filters (AND/OR)",
                    "label": "Condition Operator",
                    "placeholder": "AND",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "AND", "value": "AND"},
                            {"label": "OR", "value": "OR"},
                        ],
                    },
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by first name",
                    "label": "First Name",
                    "placeholder": "John",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by last name",
                    "label": "Last Name",
                    "placeholder": "Doe",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by email address",
                    "label": "Email",
                    "placeholder": "john@example.com",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by phone number",
                    "label": "Phone",
                    "placeholder": "+1-555-123-4567",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by job title",
                    "label": "Title",
                    "placeholder": "Manager",
                },
                {
                    "field": "department",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by department",
                    "label": "Department",
                    "placeholder": "Sales",
                },
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by account ID",
                    "label": "Account ID",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                },
                {
                    "field": "lead_source",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by lead source",
                    "label": "Lead Source",
                    "placeholder": "Website",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_lead_source",
                    },
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by owner ID",
                    "label": "Owner ID",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                },
                {
                    "field": "created_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by creation date (YYYY-MM-DD)",
                    "label": "Created Date",
                    "placeholder": "2024-01-01",
                },
                {
                    "field": "modified_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by modification date (YYYY-MM-DD)",
                    "label": "Modified Date",
                    "placeholder": "2024-01-01",
                },
                {
                    "field": "salutation",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by salutation",
                    "label": "Salutation",
                    "placeholder": "Mr.",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_salutation",
                    },
                },
                {
                    "field": "record_type_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by record type ID",
                    "label": "Record Type ID",
                    "placeholder": "012XXXXXXXXXXXXXXX",
                },
                {
                    "field": "fax",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by fax number",
                    "label": "Fax",
                    "placeholder": "+1-555-123-4568",
                },
                {
                    "field": "mobile_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by mobile phone",
                    "label": "Mobile Phone",
                    "placeholder": "+1-555-123-4569",
                },
                {
                    "field": "home_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by home phone",
                    "label": "Home Phone",
                    "placeholder": "+1-555-123-4570",
                },
                {
                    "field": "mailing_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by mailing city",
                    "label": "Mailing City",
                    "placeholder": "San Francisco",
                },
                {
                    "field": "mailing_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by mailing state",
                    "label": "Mailing State",
                    "placeholder": "CA",
                },
                {
                    "field": "mailing_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by mailing country",
                    "label": "Mailing Country",
                    "placeholder": "USA",
                },
                {
                    "field": "mailing_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by mailing postal code",
                    "label": "Mailing Postal Code",
                    "placeholder": "94105",
                },
                {
                    "field": "mailing_street",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by mailing street",
                    "label": "Mailing Street",
                    "placeholder": "123 Main St",
                },
                {
                    "field": "other_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by other city",
                    "label": "Other City",
                    "placeholder": "New York",
                },
                {
                    "field": "other_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by other state",
                    "label": "Other State",
                    "placeholder": "NY",
                },
                {
                    "field": "other_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by other country",
                    "label": "Other Country",
                    "placeholder": "USA",
                },
                {
                    "field": "other_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by other postal code",
                    "label": "Other Postal Code",
                    "placeholder": "10001",
                },
                {
                    "field": "other_street",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by other street",
                    "label": "Other Street",
                    "placeholder": "456 Oak Ave",
                },
            ],
            "outputs": [
                {
                    "field": "total_size",
                    "type": "int32",
                    "helper_text": "Total number of records returned",
                },
                {
                    "field": "done",
                    "type": "bool",
                    "helper_text": "Whether the query is complete",
                },
                {
                    "field": "contact_ids",
                    "type": "vec<string>",
                    "helper_text": "List of contact IDs",
                },
                {
                    "field": "contact_names",
                    "type": "vec<string>",
                    "helper_text": "List of contact names",
                },
                {
                    "field": "emails",
                    "type": "vec<string>",
                    "helper_text": "List of contact emails",
                },
                {
                    "field": "phones",
                    "type": "vec<string>",
                    "helper_text": "List of contact phone numbers",
                },
                {
                    "field": "titles",
                    "type": "vec<string>",
                    "helper_text": "List of contact titles",
                },
                {
                    "field": "departments",
                    "type": "vec<string>",
                    "helper_text": "List of contact departments",
                },
                {
                    "field": "account_ids",
                    "type": "vec<string>",
                    "helper_text": "List of associated account IDs",
                },
                {
                    "field": "lead_sources",
                    "type": "vec<string>",
                    "helper_text": "List of contact lead sources",
                },
                {
                    "field": "created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "updated_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of update dates",
                },
                {
                    "field": "owner_ids",
                    "type": "vec<string>",
                    "helper_text": "List of owner IDs",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_contacts",
            "task_name": "tasks.salesforce.get_contacts",
            "description": "Get multiple contacts",
            "label": "List Contacts",
            "required": ["num_messages"],
            "inputs_sort_order": [
                "integration",
                "action",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "fields",
                "query",
                "condition",
                "first_name",
                "last_name",
                "email",
                "phone",
                "title",
                "department",
                "account_id",
                "lead_source",
                "owner_id",
                "created_date",
                "modified_date",
                "salutation",
                "record_type_id",
                "fax",
                "mobile_phone",
                "home_phone",
                "mailing_city",
                "mailing_state",
                "mailing_country",
                "mailing_postal_code",
                "mailing_street",
                "other_city",
                "other_state",
                "other_country",
                "other_postal_code",
                "other_street",
            ],
        },
        "get_contacts**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Contacts",
                    "helper_text": "Specify the number of contacts to fetch",
                }
            ],
            "outputs": [],
        },
        "get_contacts**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_contacts**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_contacts**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_contact_summary**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Name of the contact object",
                },
                {
                    "field": "label",
                    "type": "string",
                    "helper_text": "Label of the contact object",
                },
                {
                    "field": "updateable",
                    "type": "bool",
                    "helper_text": "Whether the contact object is updateable",
                },
                {
                    "field": "deletable",
                    "type": "bool",
                    "helper_text": "Whether the contact object is deletable",
                },
                {
                    "field": "queryable",
                    "type": "bool",
                    "helper_text": "Whether the contact object is queryable",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "helper_text": "Available fields for the contact object",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_contact_summary",
            "task_name": "tasks.salesforce.get_contact_summary",
            "description": "Read details of a specific contact summary",
            "label": "Get Contact Summary",
            "required": [],
            "inputs_sort_order": ["integration", "action"],
        },
        "add_contact_to_campaign**(*)**(*)": {
            "inputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the contact to add to campaign",
                    "label": "Select Contact",
                    "placeholder": "003XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=contact&parent_id=contacts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "campaign_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the campaign to add the contact to",
                    "label": "Campaign ID",
                    "placeholder": "701XXXXXXXXXXXXXXX",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Status of the contact in the campaign",
                    "label": "Select Status",
                    "placeholder": "Sent",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_campaign_member_status",
                    },
                },
                {
                    "field": "has_responded",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the contact has responded",
                    "label": "Has Responded",
                },
            ],
            "outputs": [
                {
                    "field": "campaign_member_id",
                    "type": "string",
                    "helper_text": "ID of the created campaign member",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "add_contact_to_campaign",
            "task_name": "tasks.salesforce.add_contact_to_campaign",
            "description": "Add a contact to a campaign in Salesforce",
            "label": "Add Contact to Campaign",
            "required": ["contact_id", "campaign_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "contact_id",
                "campaign_id",
                "status",
                "has_responded",
            ],
        },
        "add_contact_note**(*)**(*)": {
            "inputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the contact to add note to",
                    "label": "Select Contact",
                    "placeholder": "003XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=contact&parent_id=contacts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Title of the note",
                    "label": "Note Title",
                    "placeholder": "Follow-up call",
                },
                {
                    "field": "body",
                    "type": "string",
                    "value": "",
                    "helper_text": "Content of the note",
                    "label": "Note Body",
                    "placeholder": "Called the contact to discuss their requirements",
                },
                {
                    "field": "is_private",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the note is private",
                    "label": "Is Private",
                },
            ],
            "outputs": [
                {
                    "field": "note_id",
                    "type": "string",
                    "helper_text": "ID of the created note",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "add_contact_note",
            "task_name": "tasks.salesforce.add_contact_note",
            "description": "Add a note to a contact in Salesforce",
            "label": "Add Contact Note",
            "required": ["contact_id", "title", "body"],
            "ui_sort_order": [
                "integration",
                "action",
                "contact_id",
                "title",
                "body",
                "is_private",
            ],
        },
        "create_account**(*)**(*)": {
            "inputs": [
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the account",
                    "label": "Account Name",
                    "placeholder": "Acme Corporation",
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "",
                    "helper_text": "Type of account",
                    "label": "Select Account Type",
                    "placeholder": "Customer - Direct",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_account_type",
                    },
                },
                {
                    "field": "industry",
                    "type": "string",
                    "value": "",
                    "helper_text": "Industry of the account",
                    "label": "Select Industry",
                    "placeholder": "Technology",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_industry",
                    },
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "helper_text": "Website of the account",
                    "label": "Website",
                    "placeholder": "https://acme.com",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Phone number of the account",
                    "label": "Phone",
                    "placeholder": "+1-555-123-4567",
                },
                {
                    "field": "annual_revenue",
                    "type": "int32",
                    "value": "",
                    "helper_text": "Annual revenue of the account",
                    "label": "Annual Revenue",
                    "placeholder": "1000000",
                },
                {
                    "field": "number_of_employees",
                    "type": "int32",
                    "value": "",
                    "helper_text": "Number of employees",
                    "label": "Number of Employees",
                    "placeholder": "100",
                },
                {
                    "field": "billing_street",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing street address",
                    "label": "Billing Street",
                    "placeholder": "123 Main St",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing city",
                    "label": "Billing City",
                    "placeholder": "San Francisco",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing state",
                    "label": "Billing State",
                    "placeholder": "CA",
                },
                {
                    "field": "billing_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing postal code",
                    "label": "Billing Postal Code",
                    "placeholder": "94105",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing country",
                    "label": "Billing Country",
                    "placeholder": "USA",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the account",
                    "label": "Description",
                    "placeholder": "Key customer in technology sector",
                },
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner ID of the account",
                    "label": "Select Owner",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields in JSON format",
                    "label": "Custom Fields",
                    "placeholder": '{"field_name": "value"}',
                },
            ],
            "outputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "ID of the created account",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_account",
            "task_name": "tasks.salesforce.create_account",
            "description": "Create a new account in Salesforce",
            "label": "Create Account",
            "required": ["name"],
            "ui_sort_order": [
                "integration",
                "action",
                "name",
                "type",
                "industry",
                "website",
                "phone",
                "annual_revenue",
                "number_of_employees",
                "billing_street",
                "billing_city",
                "billing_state",
                "billing_postal_code",
                "billing_country",
                "description",
                "owner",
                "custom_fields",
            ],
        },
        "upsert_account**(*)**(*)": {
            "inputs": [
                {
                    "field": "external_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "External ID field name",
                    "label": "External ID Field",
                    "placeholder": "External_Id__c",
                },
                {
                    "field": "external_id_value",
                    "type": "string",
                    "value": "",
                    "helper_text": "Value for the external ID",
                    "label": "External ID Value",
                    "placeholder": "ACCOUNT-001",
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the account",
                    "label": "Account Name",
                    "placeholder": "Acme Corporation",
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "",
                    "helper_text": "Type of account",
                    "label": "Select Account Type",
                    "placeholder": "Customer - Direct",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_account_type",
                    },
                },
                {
                    "field": "industry",
                    "type": "string",
                    "value": "",
                    "helper_text": "Industry of the account",
                    "label": "Select Industry",
                    "placeholder": "Technology",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_industry",
                    },
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "helper_text": "Website of the account",
                    "label": "Website",
                    "placeholder": "https://acme.com",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Phone number of the account",
                    "label": "Phone",
                    "placeholder": "+1-555-123-4567",
                },
                {
                    "field": "annual_revenue",
                    "type": "int32",
                    "value": "",
                    "helper_text": "Annual revenue of the account",
                    "label": "Annual Revenue",
                    "placeholder": "1000000",
                },
                {
                    "field": "number_of_employees",
                    "type": "int32",
                    "value": "",
                    "helper_text": "Number of employees",
                    "label": "Number of Employees",
                    "placeholder": "100",
                },
                {
                    "field": "billing_street",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing street address",
                    "label": "Billing Street",
                    "placeholder": "123 Main St",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing city",
                    "label": "Billing City",
                    "placeholder": "San Francisco",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing state",
                    "label": "Billing State",
                    "placeholder": "CA",
                },
                {
                    "field": "billing_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing postal code",
                    "label": "Billing Postal Code",
                    "placeholder": "94105",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing country",
                    "label": "Billing Country",
                    "placeholder": "USA",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the account",
                    "label": "Description",
                    "placeholder": "Key customer in technology sector",
                },
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner ID of the account",
                    "label": "Select Owner",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields in JSON format",
                    "label": "Custom Fields",
                    "placeholder": '{"field_name": "value"}',
                },
            ],
            "outputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "ID of the upserted account",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "upsert_account",
            "task_name": "tasks.salesforce.upsert_account",
            "description": "Upsert an account in Salesforce using external ID",
            "label": "Create or Update Account",
            "required": ["external_id", "external_id_value", "name"],
            "ui_sort_order": [
                "integration",
                "action",
                "external_id",
                "external_id_value",
                "name",
                "type",
                "industry",
                "website",
                "phone",
                "annual_revenue",
                "number_of_employees",
                "billing_street",
                "billing_city",
                "billing_state",
                "billing_postal_code",
                "billing_country",
                "description",
                "owner",
                "custom_fields",
            ],
        },
        "update_account**(*)**(*)": {
            "inputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the account to update",
                    "label": "Select Account",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account&parent_id=accounts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the account",
                    "label": "Account Name",
                    "placeholder": "Acme Corporation",
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "",
                    "helper_text": "Type of account",
                    "label": "Select Account Type",
                    "placeholder": "Customer - Direct",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_account_type",
                    },
                },
                {
                    "field": "industry",
                    "type": "string",
                    "value": "",
                    "helper_text": "Industry of the account",
                    "label": "Select Industry",
                    "placeholder": "Technology",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_industry",
                    },
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "helper_text": "Website of the account",
                    "label": "Website",
                    "placeholder": "https://acme.com",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Phone number of the account",
                    "label": "Phone",
                    "placeholder": "+1-555-123-4567",
                },
                {
                    "field": "annual_revenue",
                    "type": "int32",
                    "value": "",
                    "helper_text": "Annual revenue of the account",
                    "label": "Annual Revenue",
                    "placeholder": "1000000",
                },
                {
                    "field": "number_of_employees",
                    "type": "int32",
                    "value": "",
                    "helper_text": "Number of employees",
                    "label": "Number of Employees",
                    "placeholder": "100",
                },
                {
                    "field": "billing_street",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing street address",
                    "label": "Billing Street",
                    "placeholder": "123 Main St",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing city",
                    "label": "Billing City",
                    "placeholder": "San Francisco",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing state",
                    "label": "Billing State",
                    "placeholder": "CA",
                },
                {
                    "field": "billing_postal_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing postal code",
                    "label": "Billing Postal Code",
                    "placeholder": "94105",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Billing country",
                    "label": "Billing Country",
                    "placeholder": "USA",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the account",
                    "label": "Description",
                    "placeholder": "Key customer in technology sector",
                },
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner ID of the account",
                    "label": "Select Owner",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields in JSON format",
                    "label": "Custom Fields",
                    "placeholder": '{"field_name": "value"}',
                },
            ],
            "outputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "ID of the updated account",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_account",
            "task_name": "tasks.salesforce.update_account",
            "description": "Update an existing account in Salesforce",
            "label": "Update Account",
            "required": ["account_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "account_id",
                "name",
                "type",
                "industry",
                "website",
                "phone",
                "annual_revenue",
                "number_of_employees",
                "billing_street",
                "billing_city",
                "billing_state",
                "billing_postal_code",
                "billing_country",
                "description",
                "owner",
                "custom_fields",
            ],
        },
        "read_account**(*)**(*)": {
            "inputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the account to read",
                    "label": "Select Account",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account&parent_id=accounts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "ID of the account",
                },
                {
                    "field": "account_name",
                    "type": "string",
                    "helper_text": "Name of the account",
                },
                {
                    "field": "type",
                    "type": "string",
                    "helper_text": "Type of the account",
                },
                {
                    "field": "industry",
                    "type": "string",
                    "helper_text": "Industry of the account",
                },
                {
                    "field": "website",
                    "type": "string",
                    "helper_text": "Website of the account",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "helper_text": "Phone number of the account",
                },
                {
                    "field": "annual_revenue",
                    "type": "int32",
                    "helper_text": "Annual revenue of the account",
                },
                {
                    "field": "number_of_employees",
                    "type": "int32",
                    "helper_text": "Number of employees",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "helper_text": "Billing city of the account",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "helper_text": "Billing state of the account",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "helper_text": "Billing country of the account",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the account",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp of the account",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Last update timestamp of the account",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "helper_text": "Owner ID of the account",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_account",
            "task_name": "tasks.salesforce.read_account",
            "description": "Read details of a specific account",
            "label": "Get Account",
            "required": ["account_id"],
            "ui_sort_order": ["integration", "action", "account_id"],
        },
        "delete_account**(*)**(*)": {
            "inputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the account to delete",
                    "label": "Select Account",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account&parent_id=accounts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "ID of the deleted account",
                },
                {
                    "field": "deleted",
                    "type": "bool",
                    "helper_text": "Whether the account was successfully deleted",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_account",
            "task_name": "tasks.salesforce.delete_account",
            "description": "Delete an existing account in Salesforce",
            "label": "Delete Account",
            "required": ["account_id"],
            "ui_sort_order": ["integration", "action", "account_id"],
        },
        "get_accounts**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields to retrieve (comma-separated)",
                    "label": "Fields",
                    "placeholder": "Id, Name, Type, Industry",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Search query to filter accounts",
                    "label": "Search Query",
                    "placeholder": "Acme",
                },
                {
                    "field": "condition",
                    "type": "string",
                    "value": "",
                    "helper_text": "Condition operator for multiple filters (AND/OR)",
                    "label": "Condition Operator",
                    "placeholder": "AND",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "AND", "value": "AND"},
                            {"label": "OR", "value": "OR"},
                        ],
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by account name",
                    "label": "Account Name",
                    "placeholder": "Acme Corp",
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "helper_text": "Filter by account type",
                    "label": "Account Type",
                    "placeholder": "Customer",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_account_type",
                    },
                },
                {
                    "field": "industry",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by industry",
                    "label": "Industry",
                    "placeholder": "Technology",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_industry",
                    },
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by website",
                    "label": "Website",
                    "placeholder": "www.example.com",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by phone number",
                    "label": "Phone",
                    "placeholder": "+1-555-123-4567",
                },
                {
                    "field": "billing_city",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by billing city",
                    "label": "Billing City",
                    "placeholder": "San Francisco",
                },
                {
                    "field": "billing_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by billing state",
                    "label": "Billing State",
                    "placeholder": "CA",
                },
                {
                    "field": "billing_country",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by billing country",
                    "label": "Billing Country",
                    "placeholder": "USA",
                },
                {
                    "field": "annual_revenue",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by annual revenue",
                    "label": "Annual Revenue",
                    "placeholder": "1000000",
                },
                {
                    "field": "number_of_employees",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by number of employees",
                    "label": "Number of Employees",
                    "placeholder": "100",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by owner ID",
                    "label": "Owner ID",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                },
                {
                    "field": "created_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by creation date (YYYY-MM-DD)",
                    "label": "Created Date",
                    "placeholder": "2024-01-01",
                },
                {
                    "field": "modified_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by modification date (YYYY-MM-DD)",
                    "label": "Modified Date",
                    "placeholder": "2024-01-01",
                },
            ],
            "outputs": [
                {
                    "field": "total_size",
                    "type": "int32",
                    "helper_text": "Total number of records returned",
                },
                {
                    "field": "done",
                    "type": "bool",
                    "helper_text": "Whether the query is complete",
                },
                {
                    "field": "account_ids",
                    "type": "vec<string>",
                    "helper_text": "List of account IDs",
                },
                {
                    "field": "account_names",
                    "type": "vec<string>",
                    "helper_text": "List of account names",
                },
                {
                    "field": "types",
                    "type": "vec<string>",
                    "helper_text": "List of account types",
                },
                {
                    "field": "industries",
                    "type": "vec<string>",
                    "helper_text": "List of account industries",
                },
                {
                    "field": "websites",
                    "type": "vec<string>",
                    "helper_text": "List of account websites",
                },
                {
                    "field": "phones",
                    "type": "vec<string>",
                    "helper_text": "List of account phone numbers",
                },
                {
                    "field": "billing_cities",
                    "type": "vec<string>",
                    "helper_text": "List of billing cities",
                },
                {
                    "field": "billing_states",
                    "type": "vec<string>",
                    "helper_text": "List of billing states",
                },
                {
                    "field": "billing_countries",
                    "type": "vec<string>",
                    "helper_text": "List of billing countries",
                },
                {
                    "field": "created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "updated_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of update dates",
                },
                {
                    "field": "owner_ids",
                    "type": "vec<string>",
                    "helper_text": "List of owner IDs",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_accounts",
            "task_name": "tasks.salesforce.get_accounts",
            "description": "Get multiple accounts",
            "label": "List Accounts",
            "required": ["num_messages"],
            "inputs_sort_order": [
                "integration",
                "action",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "fields",
                "query",
                "condition",
                "name",
                "type",
                "industry",
                "website",
                "phone",
                "billing_city",
                "billing_state",
                "billing_country",
                "annual_revenue",
                "number_of_employees",
                "owner_id",
                "created_date",
                "modified_date",
            ],
        },
        "get_accounts**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Accounts",
                    "helper_text": "Specify the number of accounts to fetch",
                }
            ],
            "outputs": [],
        },
        "get_accounts**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_accounts**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_accounts**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_account_summary**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Name of the account object",
                },
                {
                    "field": "label",
                    "type": "string",
                    "helper_text": "Label of the account object",
                },
                {
                    "field": "updateable",
                    "type": "bool",
                    "helper_text": "Whether the account object is updateable",
                },
                {
                    "field": "deletable",
                    "type": "bool",
                    "helper_text": "Whether the account object is deletable",
                },
                {
                    "field": "queryable",
                    "type": "bool",
                    "helper_text": "Whether the account object is queryable",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "helper_text": "Available fields for the account object",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_account_summary",
            "task_name": "tasks.salesforce.get_account_summary",
            "description": "Get metadata information about the Account object",
            "label": "Get Account Summary",
            "required": [],
            "ui_sort_order": ["integration", "action"],
        },
        "add_account_note**(*)**(*)": {
            "inputs": [
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the account to add note to",
                    "label": "Select Account",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account&parent_id=accounts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Title of the note",
                    "label": "Note Title",
                    "placeholder": "Follow-up meeting",
                },
                {
                    "field": "body",
                    "type": "string",
                    "value": "",
                    "helper_text": "Content of the note",
                    "label": "Note Body",
                    "placeholder": "Discussed partnership opportunities",
                },
                {
                    "field": "is_private",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the note is private",
                    "label": "Is Private",
                },
            ],
            "outputs": [
                {
                    "field": "note_id",
                    "type": "string",
                    "helper_text": "ID of the created note",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "add_account_note",
            "task_name": "tasks.salesforce.add_account_note",
            "description": "Add a note to an account in Salesforce",
            "label": "Add Account Note",
            "required": ["account_id", "title", "body"],
            "ui_sort_order": [
                "integration",
                "action",
                "account_id",
                "title",
                "body",
                "is_private",
            ],
        },
        "create_opportunity**(*)**(*)": {
            "inputs": [
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the opportunity",
                    "label": "Opportunity Name",
                    "placeholder": "New Product Launch",
                },
                {
                    "field": "stage_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Stage of the opportunity",
                    "label": "Select Stage Name",
                    "placeholder": "Prospecting",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_opportunity_stage_name",
                    },
                },
                {
                    "field": "close_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Expected close date (YYYY-MM-DD)",
                    "label": "Close Date",
                    "placeholder": "2024-12-31",
                },
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Associated account ID",
                    "label": "Select Account",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account&parent_id=accounts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "amount",
                    "type": "int32",
                    "value": "",
                    "helper_text": "Amount of the opportunity",
                    "label": "Amount",
                    "placeholder": "50000",
                },
                {
                    "field": "probability",
                    "type": "int32",
                    "value": "",
                    "helper_text": "Probability percentage (0-100)",
                    "label": "Probability",
                    "placeholder": "75",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the opportunity",
                    "label": "Description",
                    "placeholder": "Opportunity to launch new product line",
                },
                {
                    "field": "lead_source",
                    "type": "string",
                    "value": "",
                    "helper_text": "Source of the lead",
                    "label": "Select Lead Source",
                    "placeholder": "Web",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_lead_source",
                    },
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "",
                    "helper_text": "Type of opportunity",
                    "label": "Select Type",
                    "placeholder": "New Customer",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_opportunity_type",
                    },
                },
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner ID of the opportunity",
                    "label": "Select Owner",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "record_type_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Record type ID for the opportunity",
                    "label": "Record Type ID",
                    "placeholder": "012XXXXXXXXXXXXXXX",
                },
                {
                    "field": "campaign_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Associated campaign ID",
                    "label": "Campaign ID",
                    "placeholder": "701XXXXXXXXXXXXXXX",
                },
                {
                    "field": "forecast_category_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Forecast category",
                    "label": "Select Forecast Category",
                    "placeholder": "Pipeline",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_forecast_category",
                    },
                },
                {
                    "field": "next_step",
                    "type": "string",
                    "value": "",
                    "helper_text": "Next step in the sales process",
                    "label": "Next Step",
                    "placeholder": "Schedule demo call",
                },
                {
                    "field": "is_private",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the opportunity is private",
                    "label": "Is Private",
                },
                {
                    "field": "has_opportunity_line_item",
                    "type": "string",
                    "value": "",
                    "helper_text": "Whether the opportunity has line items",
                    "label": "Has Opportunity Line Item",
                    "placeholder": "None",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "true", "value": "true"},
                            {"label": "false", "value": "false"},
                        ],
                    },
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields in JSON format",
                    "label": "Custom Fields",
                    "placeholder": '{"field_name": "value"}',
                },
            ],
            "outputs": [
                {
                    "field": "opportunity_id",
                    "type": "string",
                    "helper_text": "ID of the created opportunity",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_opportunity",
            "task_name": "tasks.salesforce.create_opportunity",
            "description": "Create a new opportunity in Salesforce",
            "label": "Create Opportunity",
            "required": ["name", "stage_name", "close_date"],
            "ui_sort_order": [
                "integration",
                "action",
                "name",
                "stage_name",
                "close_date",
                "account_id",
                "amount",
                "probability",
                "description",
                "lead_source",
                "type",
                "owner",
                "record_type_id",
                "campaign_id",
                "forecast_category_name",
                "next_step",
                "is_private",
                "has_opportunity_line_item",
                "custom_fields",
            ],
        },
        "upsert_opportunity**(*)**(*)": {
            "inputs": [
                {
                    "field": "external_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "External ID field name",
                    "label": "External ID Field",
                    "placeholder": "External_Id__c",
                },
                {
                    "field": "external_id_value",
                    "type": "string",
                    "value": "",
                    "helper_text": "Value for the external ID",
                    "label": "External ID Value",
                    "placeholder": "OPP-001",
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the opportunity",
                    "label": "Opportunity Name",
                    "placeholder": "New Product Launch",
                },
                {
                    "field": "stage_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Stage of the opportunity",
                    "label": "Select Stage Name",
                    "placeholder": "Prospecting",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_opportunity_stage_name",
                    },
                },
                {
                    "field": "close_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Expected close date (YYYY-MM-DD)",
                    "label": "Close Date",
                    "placeholder": "2024-12-31",
                },
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Associated account ID",
                    "label": "Select Account",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account&parent_id=accounts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "amount",
                    "type": "int32",
                    "value": "",
                    "helper_text": "Amount of the opportunity",
                    "label": "Amount",
                    "placeholder": "50000",
                },
                {
                    "field": "probability",
                    "type": "int32",
                    "value": "",
                    "helper_text": "Probability percentage (0-100)",
                    "label": "Probability",
                    "placeholder": "75",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the opportunity",
                    "label": "Description",
                    "placeholder": "Opportunity to launch new product line",
                },
                {
                    "field": "lead_source",
                    "type": "string",
                    "value": "",
                    "helper_text": "Source of the lead",
                    "label": "Select Lead Source",
                    "placeholder": "Web",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_lead_source",
                    },
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "",
                    "helper_text": "Type of opportunity",
                    "label": "Select Type",
                    "placeholder": "New Customer",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_opportunity_type",
                    },
                },
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner ID of the opportunity",
                    "label": "Select Owner",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "record_type_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Record type ID for the opportunity",
                    "label": "Record Type ID",
                    "placeholder": "012XXXXXXXXXXXXXXX",
                },
                {
                    "field": "campaign_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Associated campaign ID",
                    "label": "Campaign ID",
                    "placeholder": "701XXXXXXXXXXXXXXX",
                },
                {
                    "field": "forecast_category_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Forecast category",
                    "label": "Select Forecast Category",
                    "placeholder": "Pipeline",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_forecast_category",
                    },
                },
                {
                    "field": "next_step",
                    "type": "string",
                    "value": "",
                    "helper_text": "Next step in the sales process",
                    "label": "Next Step",
                    "placeholder": "Schedule demo call",
                },
                {
                    "field": "is_private",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the opportunity is private",
                    "label": "Is Private",
                },
                {
                    "field": "has_opportunity_line_item",
                    "type": "string",
                    "value": "",
                    "helper_text": "Whether the opportunity has line items",
                    "label": "Has Opportunity Line Item",
                    "placeholder": "None",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "true", "value": "true"},
                            {"label": "false", "value": "false"},
                        ],
                    },
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields in JSON format",
                    "label": "Custom Fields",
                    "placeholder": '{"field_name": "value"}',
                },
            ],
            "outputs": [
                {
                    "field": "opportunity_id",
                    "type": "string",
                    "helper_text": "ID of the upserted opportunity",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "upsert_opportunity",
            "task_name": "tasks.salesforce.upsert_opportunity",
            "description": "Upsert an opportunity in Salesforce using external ID",
            "label": "Create or Update Opportunity",
            "required": [
                "external_id",
                "external_id_value",
                "name",
                "stage_name",
                "close_date",
            ],
            "ui_sort_order": [
                "integration",
                "action",
                "external_id",
                "external_id_value",
                "name",
                "stage_name",
                "close_date",
                "account_id",
                "amount",
                "probability",
                "description",
                "lead_source",
                "type",
                "owner",
                "record_type_id",
                "campaign_id",
                "forecast_category_name",
                "next_step",
                "is_private",
                "has_opportunity_line_item",
                "custom_fields",
            ],
        },
        "update_opportunity**(*)**(*)": {
            "inputs": [
                {
                    "field": "opportunity_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the opportunity to update",
                    "label": "Select Opportunity",
                    "placeholder": "006XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=opportunity&parent_id=opportunities&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the opportunity",
                    "label": "Opportunity Name",
                    "placeholder": "New Product Launch",
                },
                {
                    "field": "stage_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Stage of the opportunity",
                    "label": "Select Stage Name",
                    "placeholder": "Prospecting",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_opportunity_stage_name",
                    },
                },
                {
                    "field": "close_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Expected close date (YYYY-MM-DD)",
                    "label": "Close Date",
                    "placeholder": "2024-12-31",
                },
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Associated account ID",
                    "label": "Select Account",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account&parent_id=accounts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "amount",
                    "type": "float",
                    "value": 0.0,
                    "helper_text": "Opportunity amount",
                    "label": "Amount",
                    "placeholder": "50000.00",
                },
                {
                    "field": "probability",
                    "type": "float",
                    "value": 0.0,
                    "helper_text": "Probability of closing (0-100)",
                    "label": "Probability",
                    "placeholder": "75.0",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the opportunity",
                    "label": "Description",
                    "placeholder": "New product opportunity in the enterprise market",
                },
                {
                    "field": "lead_source",
                    "type": "string",
                    "value": "",
                    "helper_text": "Source of the opportunity",
                    "label": "Lead Source",
                    "placeholder": "Web",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_lead_source",
                    },
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "",
                    "helper_text": "Type of opportunity",
                    "label": "Select Type",
                    "placeholder": "New Customer",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_opportunity_type",
                    },
                },
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner ID of the opportunity",
                    "label": "Select Owner",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "record_type_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Record type ID for the opportunity",
                    "label": "Record Type ID",
                    "placeholder": "012XXXXXXXXXXXXXXX",
                },
                {
                    "field": "campaign_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Associated campaign ID",
                    "label": "Campaign ID",
                    "placeholder": "701XXXXXXXXXXXXXXX",
                },
                {
                    "field": "forecast_category_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Forecast category",
                    "label": "Select Forecast Category",
                    "placeholder": "Pipeline",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_forecast_category",
                    },
                },
                {
                    "field": "next_step",
                    "type": "string",
                    "value": "",
                    "helper_text": "Next step for the opportunity",
                    "label": "Next Step",
                    "placeholder": "Schedule demo",
                },
                {
                    "field": "is_private",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the opportunity is private",
                    "label": "Is Private",
                },
                {
                    "field": "has_opportunity_line_item",
                    "type": "string",
                    "value": "",
                    "helper_text": "Whether the opportunity has line items",
                    "label": "Has Line Items",
                    "placeholder": "None",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "true", "value": "true"},
                            {"label": "false", "value": "false"},
                        ],
                    },
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields in JSON format",
                    "label": "Custom Fields",
                    "placeholder": '{"field_name": "value"}',
                },
            ],
            "outputs": [
                {
                    "field": "opportunity_id",
                    "type": "string",
                    "helper_text": "ID of the updated opportunity",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_opportunity",
            "task_name": "tasks.salesforce.update_opportunity",
            "description": "Update an existing opportunity in Salesforce",
            "label": "Update Opportunity",
            "required": ["opportunity_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "opportunity_id",
                "name",
                "stage_name",
                "close_date",
                "account_id",
                "amount",
                "probability",
                "description",
                "lead_source",
                "type",
                "owner",
                "record_type_id",
                "campaign_id",
                "forecast_category_name",
                "next_step",
                "is_private",
                "has_opportunity_line_item",
                "custom_fields",
            ],
        },
        "read_opportunity**(*)**(*)": {
            "inputs": [
                {
                    "field": "opportunity_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the opportunity to read",
                    "label": "Select Opportunity",
                    "placeholder": "006XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=opportunity&parent_id=opportunities&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "opportunity_id",
                    "type": "string",
                    "helper_text": "ID of the opportunity",
                },
                {
                    "field": "opportunity_name",
                    "type": "string",
                    "helper_text": "Name of the opportunity",
                },
                {
                    "field": "stage_name",
                    "type": "string",
                    "helper_text": "Stage of the opportunity",
                },
                {
                    "field": "close_date",
                    "type": "string",
                    "helper_text": "Expected close date",
                },
                {
                    "field": "amount",
                    "type": "string",
                    "helper_text": "Amount of the opportunity",
                },
                {
                    "field": "probability",
                    "type": "string",
                    "helper_text": "Probability percentage",
                },
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "Associated account ID",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the opportunity",
                },
                {
                    "field": "lead_source",
                    "type": "string",
                    "helper_text": "Source of the lead",
                },
                {
                    "field": "type",
                    "type": "string",
                    "helper_text": "Type of opportunity",
                },
                {
                    "field": "campaign_id",
                    "type": "string",
                    "helper_text": "Associated campaign ID",
                },
                {
                    "field": "forecast_category_name",
                    "type": "string",
                    "helper_text": "Forecast category",
                },
                {
                    "field": "next_step",
                    "type": "string",
                    "helper_text": "Next step in the sales process",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp of the opportunity",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Last update timestamp of the opportunity",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "helper_text": "Owner ID of the opportunity",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_opportunity",
            "task_name": "tasks.salesforce.read_opportunity",
            "description": "Get details of an existing opportunity in Salesforce",
            "label": "Get Opportunity",
            "required": ["opportunity_id"],
            "ui_sort_order": ["integration", "action", "opportunity_id"],
        },
        "delete_opportunity**(*)**(*)": {
            "inputs": [
                {
                    "field": "opportunity_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the opportunity to delete",
                    "label": "Select Opportunity",
                    "placeholder": "006XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=opportunity&parent_id=opportunities&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "opportunity_id",
                    "type": "string",
                    "helper_text": "ID of the deleted opportunity",
                },
                {
                    "field": "deleted",
                    "type": "bool",
                    "helper_text": "Whether the opportunity was successfully deleted",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_opportunity",
            "task_name": "tasks.salesforce.delete_opportunity",
            "description": "Delete an existing opportunity in Salesforce",
            "label": "Delete Opportunity",
            "required": ["opportunity_id"],
            "ui_sort_order": ["integration", "action", "opportunity_id"],
        },
        "get_opportunities**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields to retrieve (comma-separated)",
                    "label": "Fields",
                    "placeholder": "Id, Name, StageName, CloseDate",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Search query to filter opportunities",
                    "label": "Search Query",
                    "placeholder": "New Deal",
                },
                {
                    "field": "condition",
                    "type": "string",
                    "value": "",
                    "helper_text": "Condition operator for multiple filters (AND/OR)",
                    "label": "Condition Operator",
                    "placeholder": "AND",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "AND", "value": "AND"},
                            {"label": "OR", "value": "OR"},
                        ],
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by opportunity name",
                    "label": "Opportunity Name",
                    "placeholder": "New Software License",
                },
                {
                    "field": "stage_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by stage name",
                    "label": "Stage Name",
                    "placeholder": "Prospecting",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_opportunity_stage_name",
                    },
                },
                {
                    "field": "close_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by close date (YYYY-MM-DD)",
                    "label": "Close Date",
                    "placeholder": "2024-12-31",
                },
                {
                    "field": "amount",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by amount",
                    "label": "Amount",
                    "placeholder": "50000",
                },
                {
                    "field": "probability",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by probability",
                    "label": "Probability",
                    "placeholder": "75",
                },
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by account ID",
                    "label": "Account ID",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                },
                {
                    "field": "lead_source",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by lead source",
                    "label": "Lead Source",
                    "placeholder": "Website",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_lead_source",
                    },
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by opportunity type",
                    "label": "Type",
                    "placeholder": "New Business",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_opportunity_type",
                    },
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by owner ID",
                    "label": "Owner ID",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                },
                {
                    "field": "created_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by creation date (YYYY-MM-DD)",
                    "label": "Created Date",
                    "placeholder": "2024-01-01",
                },
                {
                    "field": "modified_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by modification date (YYYY-MM-DD)",
                    "label": "Modified Date",
                    "placeholder": "2024-01-01",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by description",
                    "label": "Description",
                    "placeholder": "Software license renewal",
                },
                {
                    "field": "next_step",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by next step",
                    "label": "Next Step",
                    "placeholder": "Follow up call",
                },
                {
                    "field": "campaign_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by campaign ID",
                    "label": "Campaign ID",
                    "placeholder": "701XXXXXXXXXXXXXXX",
                },
                {
                    "field": "expected_revenue",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by expected revenue",
                    "label": "Expected Revenue",
                    "placeholder": "50000",
                },
                {
                    "field": "total_opportunity_quantity",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by total opportunity quantity",
                    "label": "Total Opportunity Quantity",
                    "placeholder": "10",
                },
                {
                    "field": "is_closed",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by is closed",
                    "label": "Is Closed",
                    "placeholder": False,
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "true", "value": "true"},
                            {"label": "false", "value": "false"},
                        ],
                    },
                },
                {
                    "field": "is_won",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by is won",
                    "label": "Is Won",
                    "placeholder": False,
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "true", "value": "true"},
                            {"label": "false", "value": "false"},
                        ],
                    },
                },
                {
                    "field": "forecast_category",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by forecast category",
                    "label": "Forecast Category",
                    "placeholder": "Pipeline",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_forecast_category",
                    },
                },
                {
                    "field": "forecast_category_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by forecast category name",
                    "label": "Forecast Category Name",
                    "placeholder": "Pipeline",
                },
                {
                    "field": "has_opportunity_line_item",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by has opportunity line item",
                    "label": "Has Opportunity Line Item",
                    "placeholder": True,
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "true", "value": "true"},
                            {"label": "false", "value": "false"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "total_size",
                    "type": "int32",
                    "helper_text": "Total number of records returned",
                },
                {
                    "field": "done",
                    "type": "bool",
                    "helper_text": "Whether the query is complete",
                },
                {
                    "field": "opportunity_ids",
                    "type": "vec<string>",
                    "helper_text": "List of opportunity IDs",
                },
                {
                    "field": "opportunity_names",
                    "type": "vec<string>",
                    "helper_text": "List of opportunity names",
                },
                {
                    "field": "stage_names",
                    "type": "vec<string>",
                    "helper_text": "List of opportunity stages",
                },
                {
                    "field": "close_dates",
                    "type": "vec<string>",
                    "helper_text": "List of close dates",
                },
                {
                    "field": "amounts",
                    "type": "vec<string>",
                    "helper_text": "List of opportunity amounts",
                },
                {
                    "field": "probabilities",
                    "type": "vec<string>",
                    "helper_text": "List of probability percentages",
                },
                {
                    "field": "account_ids",
                    "type": "vec<string>",
                    "helper_text": "List of account IDs",
                },
                {
                    "field": "lead_sources",
                    "type": "vec<string>",
                    "helper_text": "List of lead sources",
                },
                {
                    "field": "types",
                    "type": "vec<string>",
                    "helper_text": "List of opportunity types",
                },
                {
                    "field": "created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "updated_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of update dates",
                },
                {
                    "field": "owner_ids",
                    "type": "vec<string>",
                    "helper_text": "List of owner IDs",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_opportunities",
            "task_name": "tasks.salesforce.get_opportunities",
            "description": "List opportunities from Salesforce with filtering options",
            "label": "List Opportunities",
            "required": ["num_messages"],
            "ui_sort_order": [
                "integration",
                "action",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "fields",
                "query",
                "condition",
                "name",
                "stage_name",
                "close_date",
                "amount",
                "probability",
                "account_id",
                "lead_source",
                "type",
                "owner_id",
                "created_date",
                "modified_date",
                "description",
                "next_step",
                "campaign_id",
                "expected_revenue",
                "total_opportunity_quantity",
                "is_closed",
                "is_won",
                "forecast_category",
                "forecast_category_name",
                "has_opportunity_line_item",
            ],
        },
        "get_opportunities**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Opportunities",
                    "helper_text": "Specify the number of opportunities to fetch",
                }
            ],
            "outputs": [],
        },
        "get_opportunities**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_opportunities**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_opportunities**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_opportunity_summary**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Name of the opportunity object",
                },
                {
                    "field": "label",
                    "type": "string",
                    "helper_text": "Label of the opportunity object",
                },
                {
                    "field": "updateable",
                    "type": "bool",
                    "helper_text": "Whether the opportunity object is updateable",
                },
                {
                    "field": "deletable",
                    "type": "bool",
                    "helper_text": "Whether the opportunity object is deletable",
                },
                {
                    "field": "queryable",
                    "type": "bool",
                    "helper_text": "Whether the opportunity object is queryable",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "helper_text": "Available fields for the opportunity object",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_opportunity_summary",
            "task_name": "tasks.salesforce.get_opportunity_summary",
            "description": "Get metadata information about the Opportunity object",
            "label": "Get Opportunity Summary",
            "required": [],
            "ui_sort_order": ["integration", "action"],
        },
        "add_opportunity_note**(*)**(*)": {
            "inputs": [
                {
                    "field": "opportunity_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the opportunity to add note to",
                    "label": "Select Opportunity",
                    "placeholder": "006XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=opportunity&parent_id=opportunities&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Title of the note",
                    "label": "Note Title",
                    "placeholder": "Follow-up call",
                },
                {
                    "field": "body",
                    "type": "string",
                    "value": "",
                    "helper_text": "Content of the note",
                    "label": "Note Body",
                    "placeholder": "Called the opportunity contact to discuss requirements",
                },
                {
                    "field": "is_private",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the note is private",
                    "label": "Is Private",
                },
            ],
            "outputs": [
                {
                    "field": "note_id",
                    "type": "string",
                    "helper_text": "ID of the created note",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "add_opportunity_note",
            "task_name": "tasks.salesforce.add_opportunity_note",
            "description": "Add a note to an opportunity in Salesforce",
            "label": "Add Opportunity Note",
            "required": ["opportunity_id", "title", "body"],
            "ui_sort_order": [
                "integration",
                "action",
                "opportunity_id",
                "title",
                "body",
                "is_private",
            ],
        },
        "create_case**(*)**(*)": {
            "inputs": [
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "helper_text": "Subject of the case",
                    "label": "Subject",
                    "placeholder": "Product Support Request",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the case",
                    "label": "Description",
                    "placeholder": "Customer needs help with product configuration",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Status of the case",
                    "label": "Select Status",
                    "placeholder": "New",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_case_status",
                    },
                },
                {
                    "field": "priority",
                    "type": "string",
                    "value": "",
                    "helper_text": "Priority of the case",
                    "label": "Select Priority",
                    "placeholder": "Medium",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_case_priority",
                    },
                },
                {
                    "field": "origin",
                    "type": "string",
                    "value": "",
                    "helper_text": "Origin of the case",
                    "label": "Select Origin",
                    "placeholder": "Web",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_case_origin",
                    },
                },
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Associated account ID",
                    "label": "Select Account",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account&parent_id=accounts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "contact_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Associated contact ID",
                    "label": "Select Contact",
                    "placeholder": "003XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=contact&parent_id=contacts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner ID of the case",
                    "label": "Select Owner",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "record_type_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Record type ID for the case",
                    "label": "Record Type ID",
                    "placeholder": "012XXXXXXXXXXXXXXX",
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "",
                    "helper_text": "Type of case",
                    "label": "Select Type",
                    "placeholder": "Problem",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_case_type",
                    },
                },
                {
                    "field": "reason",
                    "type": "string",
                    "value": "",
                    "helper_text": "Reason for the case",
                    "label": "Reason",
                    "placeholder": "Installation",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields in JSON format",
                    "label": "Custom Fields",
                    "placeholder": '{"field_name": "value"}',
                },
            ],
            "outputs": [
                {
                    "field": "case_id",
                    "type": "string",
                    "helper_text": "ID of the created case",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_case",
            "task_name": "tasks.salesforce.create_case",
            "description": "Create a new case in Salesforce",
            "label": "Create Case",
            "required": ["subject"],
            "ui_sort_order": [
                "integration",
                "action",
                "subject",
                "description",
                "status",
                "priority",
                "origin",
                "account_id",
                "contact_id",
                "owner",
                "record_type_id",
                "type",
                "reason",
                "custom_fields",
            ],
        },
        "update_case**(*)**(*)": {
            "inputs": [
                {
                    "field": "case_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the case to update",
                    "label": "Select Case",
                    "placeholder": "500XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=case&parent_id=cases&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "helper_text": "Subject of the case",
                    "label": "Subject",
                    "placeholder": "Product Support Request",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the case",
                    "label": "Description",
                    "placeholder": "Customer needs help with product configuration",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Status of the case",
                    "label": "Select Status",
                    "placeholder": "New",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_case_status",
                    },
                },
                {
                    "field": "priority",
                    "type": "string",
                    "value": "",
                    "helper_text": "Priority of the case",
                    "label": "Select Priority",
                    "placeholder": "Medium",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_case_priority",
                    },
                },
                {
                    "field": "origin",
                    "type": "string",
                    "value": "",
                    "helper_text": "Origin of the case",
                    "label": "Select Origin",
                    "placeholder": "Web",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_case_origin",
                    },
                },
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Associated account ID",
                    "label": "Select Account",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account&parent_id=accounts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "contact_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Associated contact ID",
                    "label": "Select Contact",
                    "placeholder": "003XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=contact&parent_id=contacts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner ID of the case",
                    "label": "Select Owner",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "record_type_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Record type ID for the case",
                    "label": "Record Type ID",
                    "placeholder": "012XXXXXXXXXXXXXXX",
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "",
                    "helper_text": "Type of case",
                    "label": "Select Type",
                    "placeholder": "Problem",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_case_type",
                    },
                },
                {
                    "field": "reason",
                    "type": "string",
                    "value": "",
                    "helper_text": "Reason for the case",
                    "label": "Reason",
                    "placeholder": "Installation",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields in JSON format",
                    "label": "Custom Fields",
                    "placeholder": '{"field_name": "value"}',
                },
            ],
            "outputs": [
                {
                    "field": "case_id",
                    "type": "string",
                    "helper_text": "ID of the updated case",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_case",
            "task_name": "tasks.salesforce.update_case",
            "description": "Update an existing case in Salesforce",
            "label": "Update Case",
            "required": ["case_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "case_id",
                "subject",
                "description",
                "status",
                "priority",
                "origin",
                "account_id",
                "contact_id",
                "owner",
                "record_type_id",
                "type",
                "reason",
                "custom_fields",
            ],
        },
        "read_case**(*)**(*)": {
            "inputs": [
                {
                    "field": "case_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the case to read",
                    "label": "Select Case",
                    "placeholder": "500XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=case&parent_id=cases&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {"field": "case_id", "type": "string", "helper_text": "ID of the case"},
                {
                    "field": "case_number",
                    "type": "string",
                    "helper_text": "Case number",
                },
                {
                    "field": "subject",
                    "type": "string",
                    "helper_text": "Subject of the case",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the case",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the case",
                },
                {
                    "field": "priority",
                    "type": "string",
                    "helper_text": "Priority of the case",
                },
                {
                    "field": "origin",
                    "type": "string",
                    "helper_text": "Origin of the case",
                },
                {
                    "field": "account_id",
                    "type": "string",
                    "helper_text": "Associated account ID",
                },
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "Associated contact ID",
                },
                {"field": "type", "type": "string", "helper_text": "Type of case"},
                {
                    "field": "reason",
                    "type": "string",
                    "helper_text": "Reason for the case",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp of the case",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Last update timestamp of the case",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "helper_text": "Owner ID of the case",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_case",
            "task_name": "tasks.salesforce.read_case",
            "description": "Get details of an existing case in Salesforce",
            "label": "Get Case",
            "required": ["case_id"],
            "ui_sort_order": ["integration", "action", "case_id"],
        },
        "delete_case**(*)**(*)": {
            "inputs": [
                {
                    "field": "case_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the case to delete",
                    "label": "Select Case",
                    "placeholder": "500XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=case&parent_id=cases&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "case_id",
                    "type": "string",
                    "helper_text": "ID of the deleted case",
                },
                {
                    "field": "deleted",
                    "type": "bool",
                    "helper_text": "Whether the case was successfully deleted",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_case",
            "task_name": "tasks.salesforce.delete_case",
            "description": "Delete an existing case in Salesforce",
            "label": "Delete Case",
            "required": ["case_id"],
            "ui_sort_order": ["integration", "action", "case_id"],
        },
        "get_cases**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields to retrieve (comma-separated)",
                    "label": "Fields",
                    "placeholder": "Id, CaseNumber, Subject, Status",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Search query to filter cases",
                    "label": "Search Query",
                    "placeholder": "Technical Issue",
                },
                {
                    "field": "condition",
                    "type": "string",
                    "value": "",
                    "helper_text": "Condition operator for multiple filters (AND/OR)",
                    "label": "Condition Operator",
                    "placeholder": "AND",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "AND", "value": "AND"},
                            {"label": "OR", "value": "OR"},
                        ],
                    },
                },
                {
                    "field": "case_number",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by case number",
                    "label": "Case Number",
                    "placeholder": "00001234",
                },
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by subject",
                    "label": "Subject",
                    "placeholder": "Technical Support Request",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by status",
                    "label": "Status",
                    "placeholder": "New",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_case_status",
                    },
                },
                {
                    "field": "priority",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by priority",
                    "label": "Priority",
                    "placeholder": "High",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_case_priority",
                    },
                },
                {
                    "field": "origin",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by origin",
                    "label": "Origin",
                    "placeholder": "Web",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_case_origin",
                    },
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by case type",
                    "label": "Type",
                    "placeholder": "Problem",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_case_type",
                    },
                },
                {
                    "field": "account_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by account ID",
                    "label": "Account ID",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                },
                {
                    "field": "contact_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by contact ID",
                    "label": "Contact ID",
                    "placeholder": "003XXXXXXXXXXXXXXX",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by owner ID",
                    "label": "Owner ID",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                },
                {
                    "field": "created_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by creation date (YYYY-MM-DD)",
                    "label": "Created Date",
                    "placeholder": "2024-01-01",
                },
                {
                    "field": "modified_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by modification date (YYYY-MM-DD)",
                    "label": "Modified Date",
                    "placeholder": "2024-01-01",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by description",
                    "label": "Description",
                    "placeholder": "User cannot access the system",
                },
                {
                    "field": "reason",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by reason",
                    "label": "Reason",
                    "placeholder": "Performance",
                },
                {
                    "field": "supplied_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by supplied name",
                    "label": "Supplied Name",
                    "placeholder": "John Doe",
                },
                {
                    "field": "supplied_email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by supplied email",
                    "label": "Supplied Email",
                    "placeholder": "john@example.com",
                },
                {
                    "field": "supplied_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by supplied phone",
                    "label": "Supplied Phone",
                    "placeholder": "+1-555-123-4567",
                },
                {
                    "field": "supplied_company",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by supplied company",
                    "label": "Supplied Company",
                    "placeholder": "Acme Corp",
                },
                {
                    "field": "is_escalated",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by is escalated",
                    "label": "Is Escalated",
                    "placeholder": False,
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "true", "value": "true"},
                            {"label": "false", "value": "false"},
                        ],
                    },
                },
                {
                    "field": "is_closed",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by is closed",
                    "label": "Is Closed",
                    "placeholder": False,
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "true", "value": "true"},
                            {"label": "false", "value": "false"},
                        ],
                    },
                },
                {
                    "field": "closed_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by closed date (YYYY-MM-DD)",
                    "label": "Closed Date",
                    "placeholder": "2024-01-15",
                },
                {
                    "field": "last_viewed_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by last viewed date (YYYY-MM-DD)",
                    "label": "Last Viewed Date",
                    "placeholder": "2024-01-10",
                },
                {
                    "field": "last_referenced_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by last referenced date (YYYY-MM-DD)",
                    "label": "Last Referenced Date",
                    "placeholder": "2024-01-10",
                },
                {
                    "field": "engineering_req_number",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by engineering req number",
                    "label": "Engineering Req Number",
                    "placeholder": "ENG-001",
                },
                {
                    "field": "product",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by product",
                    "label": "Product",
                    "placeholder": "Salesforce Platform",
                },
                {
                    "field": "potential_liability",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by potential liability",
                    "label": "Potential Liability",
                    "placeholder": "No",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Yes", "value": "Yes"},
                            {"label": "No", "value": "No"},
                        ],
                    },
                },
                {
                    "field": "sla_violation",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by SLA violation",
                    "label": "SLA Violation",
                    "placeholder": "No",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Yes", "value": "Yes"},
                            {"label": "No", "value": "No"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "total_size",
                    "type": "int32",
                    "helper_text": "Total number of records returned",
                },
                {
                    "field": "done",
                    "type": "bool",
                    "helper_text": "Whether the query is complete",
                },
                {
                    "field": "case_ids",
                    "type": "vec<string>",
                    "helper_text": "List of case IDs",
                },
                {
                    "field": "case_numbers",
                    "type": "vec<string>",
                    "helper_text": "List of case numbers",
                },
                {
                    "field": "subjects",
                    "type": "vec<string>",
                    "helper_text": "List of case subjects",
                },
                {
                    "field": "statuses",
                    "type": "vec<string>",
                    "helper_text": "List of case statuses",
                },
                {
                    "field": "priorities",
                    "type": "vec<string>",
                    "helper_text": "List of case priorities",
                },
                {
                    "field": "origins",
                    "type": "vec<string>",
                    "helper_text": "List of case origins",
                },
                {
                    "field": "account_ids",
                    "type": "vec<string>",
                    "helper_text": "List of account IDs",
                },
                {
                    "field": "contact_ids",
                    "type": "vec<string>",
                    "helper_text": "List of contact IDs",
                },
                {
                    "field": "types",
                    "type": "vec<string>",
                    "helper_text": "List of case types",
                },
                {
                    "field": "created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "updated_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of update dates",
                },
                {
                    "field": "owner_ids",
                    "type": "vec<string>",
                    "helper_text": "List of owner IDs",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_cases",
            "task_name": "tasks.salesforce.get_cases",
            "description": "List cases from Salesforce with filtering options",
            "label": "List Cases",
            "required": ["num_messages"],
            "ui_sort_order": [
                "integration",
                "action",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "fields",
                "query",
                "condition",
                "case_number",
                "subject",
                "status",
                "priority",
                "origin",
                "type",
                "account_id",
                "contact_id",
                "owner_id",
                "created_date",
                "modified_date",
                "description",
                "reason",
                "supplied_name",
                "supplied_email",
                "supplied_phone",
                "supplied_company",
                "is_escalated",
                "is_closed",
                "closed_date",
                "last_viewed_date",
                "last_referenced_date",
                "engineering_req_number",
                "product",
                "potential_liability",
                "sla_violation",
            ],
        },
        "get_cases**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Cases",
                    "helper_text": "Specify the number of cases to fetch",
                }
            ],
            "outputs": [],
        },
        "get_cases**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_cases**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_cases**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_case_summary**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Name of the case object",
                },
                {
                    "field": "label",
                    "type": "string",
                    "helper_text": "Label of the case object",
                },
                {
                    "field": "updateable",
                    "type": "bool",
                    "helper_text": "Whether the case object is updateable",
                },
                {
                    "field": "deletable",
                    "type": "bool",
                    "helper_text": "Whether the case object is deletable",
                },
                {
                    "field": "queryable",
                    "type": "bool",
                    "helper_text": "Whether the case object is queryable",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "helper_text": "Available fields for the case object",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_case_summary",
            "task_name": "tasks.salesforce.get_case_summary",
            "description": "Get metadata information about the Case object",
            "label": "Get Case Summary",
            "required": [],
            "ui_sort_order": ["integration", "action"],
        },
        "add_case_comment**(*)**(*)": {
            "inputs": [
                {
                    "field": "case_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the case to add comment to",
                    "label": "Select Case",
                    "placeholder": "500XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=case&parent_id=cases&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "comment_body",
                    "type": "string",
                    "value": "",
                    "helper_text": "Content of the comment",
                    "label": "Comment Body",
                    "placeholder": "Updated the customer on the resolution",
                },
                {
                    "field": "is_private",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the comment is private",
                    "label": "Is Private",
                },
            ],
            "outputs": [
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "ID of the created comment",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "add_case_comment",
            "task_name": "tasks.salesforce.add_case_comment",
            "description": "Add a comment to a case in Salesforce",
            "label": "Add Case Comment",
            "required": ["case_id", "comment_body"],
            "ui_sort_order": [
                "integration",
                "action",
                "case_id",
                "comment_body",
                "is_private",
            ],
        },
        "create_task**(*)**(*)": {
            "inputs": [
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "helper_text": "Subject of the task",
                    "label": "Subject",
                    "placeholder": "Follow up call",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the task",
                    "label": "Description",
                    "placeholder": "Call customer to discuss proposal",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Status of the task",
                    "label": "Select Status",
                    "placeholder": "Not Started",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_task_status",
                    },
                },
                {
                    "field": "priority",
                    "type": "string",
                    "value": "",
                    "helper_text": "Priority of the task",
                    "label": "Select Priority",
                    "placeholder": "Normal",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_task_priority",
                    },
                },
                {
                    "field": "activity_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Due date for the task (YYYY-MM-DD)",
                    "label": "Activity Date",
                    "placeholder": "2024-12-31",
                },
                {
                    "field": "what_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Related record ID (Account, Opportunity, etc.)",
                    "label": "Select Related Record",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account&parent_id=accounts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "who_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Related contact or lead ID",
                    "label": "Select Contact",
                    "placeholder": "003XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=contact&parent_id=contacts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner ID of the task",
                    "label": "Select Owner",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "record_type_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Record type ID for the task",
                    "label": "Record Type ID",
                    "placeholder": "012XXXXXXXXXXXXXXX",
                },
                {
                    "field": "task_subtype",
                    "type": "string",
                    "value": "",
                    "helper_text": "Subtype of task (Call, Email, etc.)",
                    "label": "Select Task Subtype",
                    "placeholder": "Call",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_task_type",
                    },
                },
                {
                    "field": "is_reminder_set",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether reminder is set",
                    "label": "Is Reminder Set",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields in JSON format",
                    "label": "Custom Fields",
                    "placeholder": '{"field_name": "value"}',
                },
            ],
            "outputs": [
                {
                    "field": "task_id",
                    "type": "string",
                    "helper_text": "ID of the created task",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_task",
            "task_name": "tasks.salesforce.create_task",
            "description": "Create a new task in Salesforce",
            "label": "Create Task",
            "required": ["subject"],
            "ui_sort_order": [
                "integration",
                "action",
                "subject",
                "description",
                "status",
                "priority",
                "activity_date",
                "what_id",
                "who_id",
                "owner",
                "record_type_id",
                "task_subtype",
                "is_reminder_set",
                "custom_fields",
            ],
        },
        "update_task**(*)**(*)": {
            "inputs": [
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the task to update",
                    "label": "Select Task",
                    "placeholder": "00TXXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task&parent_id=tasks&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "helper_text": "Subject of the task",
                    "label": "Subject",
                    "placeholder": "Follow up call",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the task",
                    "label": "Description",
                    "placeholder": "Call customer to discuss proposal",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Status of the task",
                    "label": "Select Status",
                    "placeholder": "Completed",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_task_status",
                    },
                },
                {
                    "field": "priority",
                    "type": "string",
                    "value": "",
                    "helper_text": "Priority of the task",
                    "label": "Select Priority",
                    "placeholder": "Normal",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_task_priority",
                    },
                },
                {
                    "field": "activity_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Due date for the task (YYYY-MM-DD)",
                    "label": "Activity Date",
                    "placeholder": "2024-12-31",
                },
                {
                    "field": "what_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Related record ID (Account, Opportunity, etc.)",
                    "label": "Select Related Record",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account&parent_id=accounts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "who_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Related contact or lead ID",
                    "label": "Select Contact",
                    "placeholder": "003XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=contact&parent_id=contacts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner ID of the task",
                    "label": "Select Owner",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "record_type_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Record type ID for the task",
                    "label": "Record Type ID",
                    "placeholder": "012XXXXXXXXXXXXXXX",
                },
                {
                    "field": "task_subtype",
                    "type": "string",
                    "value": "",
                    "helper_text": "Subtype of task (Call, Email, etc.)",
                    "label": "Select Task Subtype",
                    "placeholder": "Call",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_task_type",
                    },
                },
                {
                    "field": "is_reminder_set",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether reminder is set",
                    "label": "Is Reminder Set",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields in JSON format",
                    "label": "Custom Fields",
                    "placeholder": '{"field_name": "value"}',
                },
            ],
            "outputs": [
                {
                    "field": "task_id",
                    "type": "string",
                    "helper_text": "ID of the updated task",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_task",
            "task_name": "tasks.salesforce.update_task",
            "description": "Update an existing task in Salesforce",
            "label": "Update Task",
            "required": ["task_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "task_id",
                "subject",
                "description",
                "status",
                "priority",
                "activity_date",
                "what_id",
                "who_id",
                "owner",
                "record_type_id",
                "task_subtype",
                "is_reminder_set",
                "custom_fields",
            ],
        },
        "read_task**(*)**(*)": {
            "inputs": [
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the task to read",
                    "label": "Select Task",
                    "placeholder": "00TXXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task&parent_id=tasks&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {"field": "task_id", "type": "string", "helper_text": "ID of the task"},
                {
                    "field": "subject",
                    "type": "string",
                    "helper_text": "Subject of the task",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the task",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the task",
                },
                {
                    "field": "priority",
                    "type": "string",
                    "helper_text": "Priority of the task",
                },
                {
                    "field": "activity_date",
                    "type": "string",
                    "helper_text": "Due date of the task",
                },
                {
                    "field": "what_id",
                    "type": "string",
                    "helper_text": "Related record ID",
                },
                {
                    "field": "who_id",
                    "type": "string",
                    "helper_text": "Related contact or lead ID",
                },
                {
                    "field": "task_subtype",
                    "type": "string",
                    "helper_text": "Subtype of task (Call, Email, etc.)",
                },
                {
                    "field": "is_reminder_set",
                    "type": "bool",
                    "helper_text": "Whether reminder is set",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation date",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Last modified date",
                },
                {"field": "owner_id", "type": "string", "helper_text": "Owner ID"},
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_task",
            "task_name": "tasks.salesforce.read_task",
            "description": "Get a task from Salesforce",
            "label": "Get Task",
            "required": ["task_id"],
            "ui_sort_order": ["integration", "action", "task_id"],
        },
        "get_tasks**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of fields to retrieve",
                    "label": "Fields",
                    "placeholder": "Id, Subject, Status, Priority",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Search query to filter tasks",
                    "label": "Search Query",
                    "placeholder": "follow up call",
                },
                {
                    "field": "condition",
                    "type": "string",
                    "value": "",
                    "helper_text": "Condition operator for multiple filters (AND/OR)",
                    "label": "Condition Operator",
                    "placeholder": "AND",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "AND", "value": "AND"},
                            {"label": "OR", "value": "OR"},
                        ],
                    },
                },
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by task subject",
                    "label": "Subject",
                    "placeholder": "Follow up call",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by task description",
                    "label": "Description",
                    "placeholder": "Call customer to discuss proposal",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by task status",
                    "label": "Status",
                    "placeholder": "Not Started",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_task_status",
                    },
                },
                {
                    "field": "priority",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by task priority",
                    "label": "Priority",
                    "placeholder": "High",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_task_priority",
                    },
                },
                {
                    "field": "activity_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by activity date (YYYY-MM-DD)",
                    "label": "Activity Date",
                    "placeholder": "2024-12-31",
                },
                {
                    "field": "what_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by related record ID",
                    "label": "What ID",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                },
                {
                    "field": "who_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by related contact or lead ID",
                    "label": "Who ID",
                    "placeholder": "003XXXXXXXXXXXXXXX",
                },
                {
                    "field": "task_subtype",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by task subtype (Call, Email, etc.)",
                    "label": "Task Subtype",
                    "placeholder": "Call",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "salesforce_task_type",
                    },
                },
                {
                    "field": "is_reminder_set",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by reminder set status",
                    "label": "Is Reminder Set",
                    "placeholder": True,
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "true", "value": "true"},
                            {"label": "false", "value": "false"},
                        ],
                    },
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by owner ID",
                    "label": "Owner ID",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                },
                {
                    "field": "created_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by creation date (YYYY-MM-DD)",
                    "label": "Created Date",
                    "placeholder": "2024-01-01",
                },
                {
                    "field": "modified_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by modification date (YYYY-MM-DD)",
                    "label": "Modified Date",
                    "placeholder": "2024-01-01",
                },
                {
                    "field": "record_type_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by record type ID",
                    "label": "Record Type ID",
                    "placeholder": "012XXXXXXXXXXXXXXX",
                },
                {
                    "field": "subject_line",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by subject line",
                    "label": "Subject Line",
                    "placeholder": "Follow up call",
                },
                {
                    "field": "reminder_date_time",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by reminder date time",
                    "label": "Reminder Date Time",
                    "placeholder": "2024-12-31T10:00:00Z",
                },
                {
                    "field": "is_recurrence",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by recurrence status",
                    "label": "Is Recurrence",
                    "placeholder": False,
                },
                {
                    "field": "recurrence_activity_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by recurrence activity ID",
                    "label": "Recurrence Activity ID",
                    "placeholder": "00TXXXXXXXXXXXXXXX",
                },
            ],
            "outputs": [
                {
                    "field": "total_size",
                    "type": "int32",
                    "helper_text": "Total number of tasks",
                },
                {
                    "field": "done",
                    "type": "bool",
                    "helper_text": "Whether query is complete",
                },
                {
                    "field": "task_ids",
                    "type": "vec<string>",
                    "helper_text": "List of task IDs",
                },
                {
                    "field": "subjects",
                    "type": "vec<string>",
                    "helper_text": "List of task subjects",
                },
                {
                    "field": "statuses",
                    "type": "vec<string>",
                    "helper_text": "List of task statuses",
                },
                {
                    "field": "priorities",
                    "type": "vec<string>",
                    "helper_text": "List of task priorities",
                },
                {
                    "field": "activity_dates",
                    "type": "vec<string>",
                    "helper_text": "List of activity dates",
                },
                {
                    "field": "what_ids",
                    "type": "vec<string>",
                    "helper_text": "List of related record IDs",
                },
                {
                    "field": "who_ids",
                    "type": "vec<string>",
                    "helper_text": "List of related contact/lead IDs",
                },
                {
                    "field": "task_subtypes",
                    "type": "vec<string>",
                    "helper_text": "List of task subtypes (Call, Email, etc.)",
                },
                {
                    "field": "created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "updated_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of last modified dates",
                },
                {
                    "field": "owner_ids",
                    "type": "vec<string>",
                    "helper_text": "List of owner IDs",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_tasks",
            "task_name": "tasks.salesforce.get_tasks",
            "description": "List tasks from Salesforce",
            "label": "List Tasks",
            "required": ["num_messages"],
            "ui_sort_order": [
                "integration",
                "action",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "fields",
                "query",
                "condition",
                "subject",
                "description",
                "status",
                "priority",
                "activity_date",
                "what_id",
                "who_id",
                "task_subtype",
                "is_reminder_set",
                "owner_id",
                "created_date",
                "modified_date",
                "record_type_id",
                "subject_line",
                "reminder_date_time",
                "is_recurrence",
                "recurrence_activity_id",
            ],
        },
        "get_tasks**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Tasks",
                    "helper_text": "Specify the number of tasks to fetch",
                }
            ],
            "outputs": [],
        },
        "get_tasks**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_tasks**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_tasks**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "delete_task**(*)**(*)": {
            "inputs": [
                {
                    "field": "task_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the task to delete",
                    "label": "Select Task",
                    "placeholder": "00TXXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task&parent_id=tasks&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "task_id",
                    "type": "string",
                    "helper_text": "ID of the deleted task",
                },
                {
                    "field": "deleted",
                    "type": "bool",
                    "helper_text": "Whether task was deleted",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_task",
            "task_name": "tasks.salesforce.delete_task",
            "description": "Delete a task from Salesforce",
            "label": "Delete Task",
            "required": ["task_id"],
            "ui_sort_order": ["integration", "action", "task_id"],
        },
        "get_task_summary**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {"field": "name", "type": "string", "helper_text": "Object name"},
                {"field": "label", "type": "string", "helper_text": "Object label"},
                {
                    "field": "updateable",
                    "type": "bool",
                    "helper_text": "Whether object is updateable",
                },
                {
                    "field": "deletable",
                    "type": "bool",
                    "helper_text": "Whether object is deletable",
                },
                {
                    "field": "queryable",
                    "type": "bool",
                    "helper_text": "Whether object is queryable",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "helper_text": "Available fields",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_task_summary",
            "task_name": "tasks.salesforce.get_task_summary",
            "description": "Get task object metadata from Salesforce",
            "label": "Get Task Summary",
            "required": [],
            "ui_sort_order": ["integration", "action"],
        },
        "create_attachment**(*)**(*)": {
            "inputs": [
                {
                    "field": "parent_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the parent record (Lead, Contact, Account, etc.)",
                    "label": "Select Parent Record",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account&parent_id=accounts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the attachment (optional, used when uploading single file)",
                    "label": "Name",
                    "placeholder": "document.pdf",
                },
                {
                    "field": "attachments",
                    "type": "vec<file>",
                    "value": [],
                    "helper_text": "Files to attach",
                    "label": "Attachments",
                    "placeholder": "Select files to upload",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the attachment",
                    "label": "Description",
                    "placeholder": "Important document",
                },
                {
                    "field": "is_private",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the attachment is private",
                    "label": "Is Private",
                },
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner ID of the attachment",
                    "label": "Select Owner",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "attachment_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of all created attachments",
                },
                {
                    "field": "total",
                    "type": "int32",
                    "helper_text": "Total number of attachments created",
                },
                {
                    "field": "raw_data",
                    "type": "vec<string>",
                    "helper_text": "Raw API response data for each attachment",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_attachment",
            "task_name": "tasks.salesforce.create_attachment",
            "description": "Create new attachments in Salesforce",
            "label": "Create Attachments",
            "required": ["attachments", "parent_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "parent_id",
                "attachments",
                "name",
                "description",
                "is_private",
                "owner",
            ],
        },
        "update_attachment**(*)**(*)": {
            "inputs": [
                {
                    "field": "parent_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the parent record (Lead, Contact, Account, etc.)",
                    "label": "Select Parent Record",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account&parent_id=accounts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "attachment_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the attachment to update",
                    "label": "Select Attachment",
                    "placeholder": "00PXXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=attachment&parent_id={inputs.parent_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the attachment",
                    "label": "Name",
                    "placeholder": "updated_document.pdf",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the attachment",
                    "label": "Description",
                    "placeholder": "Updated important document",
                },
                {
                    "field": "is_private",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the attachment is private",
                    "label": "Is Private",
                },
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner ID of the attachment",
                    "label": "Select Owner",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "attachment_id",
                    "type": "string",
                    "helper_text": "ID of the updated attachment",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_attachment",
            "task_name": "tasks.salesforce.update_attachment",
            "description": "Update attachment metadata in Salesforce",
            "label": "Update Attachment Metadata",
            "required": ["parent_id", "attachment_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "parent_id",
                "attachment_id",
                "name",
                "description",
                "is_private",
                "owner",
            ],
        },
        "read_attachment**(*)**(*)": {
            "inputs": [
                {
                    "field": "parent_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the parent record (Lead, Contact, Account, etc.)",
                    "label": "Select Parent Record",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account&parent_id=accounts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "attachment_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the attachment to read",
                    "label": "Select Attachment",
                    "placeholder": "00PXXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=attachment&parent_id={inputs.parent_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "attachment_id",
                    "type": "string",
                    "helper_text": "ID of the attachment",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Name of the attachment",
                },
                {
                    "field": "parent_id",
                    "type": "string",
                    "helper_text": "Parent record ID",
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "helper_text": "Content type of the attachment",
                },
                {
                    "field": "body_length",
                    "type": "int32",
                    "helper_text": "Size of the attachment in bytes",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the attachment",
                },
                {
                    "field": "is_private",
                    "type": "bool",
                    "helper_text": "Whether the attachment is private",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation date",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Last modified date",
                },
                {"field": "owner_id", "type": "string", "helper_text": "Owner ID"},
                {
                    "field": "file",
                    "type": "file",
                    "helper_text": "Downloaded file content",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_attachment",
            "task_name": "tasks.salesforce.read_attachment",
            "description": "Get an attachment from Salesforce",
            "label": "Get Attachment",
            "required": ["parent_id", "attachment_id"],
            "ui_sort_order": ["integration", "action", "parent_id", "attachment_id"],
        },
        "get_attachments**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of fields to retrieve",
                    "label": "Fields",
                    "placeholder": "Id, Name, ParentId, ContentType",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Search query to filter attachments",
                    "label": "Search Query",
                    "placeholder": "document.pdf",
                },
                {
                    "field": "condition",
                    "type": "string",
                    "value": "",
                    "helper_text": "Condition operator for multiple filters (AND/OR)",
                    "label": "Condition Operator",
                    "placeholder": "AND",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "AND", "value": "AND"},
                            {"label": "OR", "value": "OR"},
                        ],
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by attachment name",
                    "label": "Name",
                    "placeholder": "document.pdf",
                },
                {
                    "field": "parent_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by parent record ID",
                    "label": "Parent ID",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by content type",
                    "label": "Content Type",
                    "placeholder": "application/pdf",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by attachment description",
                    "label": "Description",
                    "placeholder": "Important document",
                },
                {
                    "field": "is_private",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by privacy status",
                    "label": "Is Private",
                    "placeholder": False,
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "true", "value": "true"},
                            {"label": "false", "value": "false"},
                        ],
                    },
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by owner ID",
                    "label": "Owner ID",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                },
                {
                    "field": "created_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by creation date (YYYY-MM-DD)",
                    "label": "Created Date",
                    "placeholder": "2024-01-01",
                },
                {
                    "field": "modified_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by modification date (YYYY-MM-DD)",
                    "label": "Modified Date",
                    "placeholder": "2024-01-01",
                },
            ],
            "outputs": [
                {
                    "field": "total_size",
                    "type": "int32",
                    "helper_text": "Total number of attachments",
                },
                {
                    "field": "done",
                    "type": "bool",
                    "helper_text": "Whether query is complete",
                },
                {
                    "field": "attachment_ids",
                    "type": "vec<string>",
                    "helper_text": "List of attachment IDs",
                },
                {
                    "field": "names",
                    "type": "vec<string>",
                    "helper_text": "List of attachment names",
                },
                {
                    "field": "parent_ids",
                    "type": "vec<string>",
                    "helper_text": "List of parent record IDs",
                },
                {
                    "field": "content_types",
                    "type": "vec<string>",
                    "helper_text": "List of content types",
                },
                {
                    "field": "body_lengths",
                    "type": "vec<string>",
                    "helper_text": "List of file sizes",
                },
                {
                    "field": "descriptions",
                    "type": "vec<string>",
                    "helper_text": "List of descriptions",
                },
                {
                    "field": "is_private",
                    "type": "vec<string>",
                    "helper_text": "List of privacy flags",
                },
                {
                    "field": "created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "updated_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of last modified dates",
                },
                {
                    "field": "owner_ids",
                    "type": "vec<string>",
                    "helper_text": "List of owner IDs",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_attachments",
            "task_name": "tasks.salesforce.get_attachments",
            "description": "List attachments from Salesforce",
            "label": "List Attachments",
            "required": ["num_messages"],
            "ui_sort_order": [
                "integration",
                "action",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "fields",
                "query",
                "condition",
                "name",
                "parent_id",
                "content_type",
                "description",
                "is_private",
                "owner_id",
                "created_date",
                "modified_date",
            ],
        },
        "get_attachments**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Attachments",
                    "helper_text": "Specify the number of attachments to fetch",
                }
            ],
            "outputs": [],
        },
        "get_attachments**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_attachments**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_attachments**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "delete_attachment**(*)**(*)": {
            "inputs": [
                {
                    "field": "parent_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the parent record (Lead, Contact, Account, etc.)",
                    "label": "Select Parent Record",
                    "placeholder": "001XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=account&parent_id=accounts&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "attachment_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the attachment to delete",
                    "label": "Select Attachment",
                    "placeholder": "00PXXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=attachment&parent_id={inputs.parent_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "attachment_id",
                    "type": "string",
                    "helper_text": "ID of the deleted attachment",
                },
                {
                    "field": "deleted",
                    "type": "bool",
                    "helper_text": "Whether attachment was deleted",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_attachment",
            "task_name": "tasks.salesforce.delete_attachment",
            "description": "Delete an attachment from Salesforce",
            "label": "Delete Attachment",
            "required": ["parent_id", "attachment_id"],
            "ui_sort_order": ["integration", "action", "parent_id", "attachment_id"],
        },
        "get_attachment_summary**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {"field": "name", "type": "string", "helper_text": "Object name"},
                {"field": "label", "type": "string", "helper_text": "Object label"},
                {
                    "field": "updateable",
                    "type": "bool",
                    "helper_text": "Whether object is updateable",
                },
                {
                    "field": "deletable",
                    "type": "bool",
                    "helper_text": "Whether object is deletable",
                },
                {
                    "field": "queryable",
                    "type": "bool",
                    "helper_text": "Whether object is queryable",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "helper_text": "Available fields",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_attachment_summary",
            "task_name": "tasks.salesforce.get_attachment_summary",
            "description": "Get attachment object metadata from Salesforce",
            "label": "Get Attachment Summary",
            "required": [],
            "ui_sort_order": ["integration", "action"],
        },
        "upload_document**(*)**(*)": {
            "inputs": [
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Title of the document",
                    "label": "Title",
                    "placeholder": "Important Document",
                },
                {
                    "field": "file",
                    "type": "file",
                    "value": "",
                    "helper_text": "File to upload",
                    "label": "File",
                    "placeholder": "Select file to upload",
                },
                {
                    "field": "file_extension",
                    "type": "string",
                    "value": "",
                    "helper_text": "File extension (e.g., pdf, doc, txt)",
                    "label": "File Extension",
                    "placeholder": "pdf",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "pdf", "value": "pdf"},
                            {"label": "doc", "value": "doc"},
                            {"label": "txt", "value": "txt"},
                        ],
                    },
                },
                {
                    "field": "link_to_object_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the folder to link the document to",
                    "label": "Link to Object ID",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner ID of the document",
                    "label": "Owner ID",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "document_id",
                    "type": "string",
                    "helper_text": "ID of the uploaded document",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the document",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "upload_document",
            "task_name": "tasks.salesforce.upload_document",
            "description": "Upload a document to Salesforce",
            "label": "Upload Document",
            "required": ["file", "link_to_object_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "title",
                "file",
                "file_extension",
                "link_to_object_id",
                "owner_id",
            ],
        },
        "create_custom_object**(*)**(*)": {
            "inputs": [
                {
                    "field": "custom_object",
                    "type": "string",
                    "value": "",
                    "helper_text": "API name of the custom object",
                    "label": "Custom Object",
                    "placeholder": "Custom_Object__c",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=custom_object&parent_id=custom_objects&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields in JSON format",
                    "label": "Custom Fields",
                    "placeholder": '[{"field_id": "Name", "value": "Test Record"}]',
                },
                {
                    "field": "record_type_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Record type ID for the custom object",
                    "label": "Record Type ID",
                    "placeholder": "012XXXXXXXXXXXXXXX",
                },
            ],
            "outputs": [
                {
                    "field": "record_id",
                    "type": "string",
                    "helper_text": "ID of the created record",
                },
                {
                    "field": "custom_object",
                    "type": "string",
                    "helper_text": "Name of the custom object",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_custom_object",
            "task_name": "tasks.salesforce.create_custom_object",
            "description": "Create a new custom object record in Salesforce",
            "label": "Create Custom Object",
            "required": ["custom_object", "custom_fields"],
            "ui_sort_order": [
                "integration",
                "action",
                "custom_object",
                "custom_fields",
                "record_type_id",
            ],
        },
        "upsert_custom_object**(*)**(*)": {
            "inputs": [
                {
                    "field": "custom_object",
                    "type": "string",
                    "value": "",
                    "helper_text": "API name of the custom object",
                    "label": "Custom Object",
                    "placeholder": "Custom_Object__c",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=custom_object&parent_id=custom_objects&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "external_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "External ID field name",
                    "label": "External ID Field",
                    "placeholder": "External_Id__c",
                },
                {
                    "field": "external_id_value",
                    "type": "string",
                    "value": "",
                    "helper_text": "Value for the external ID",
                    "label": "External ID Value",
                    "placeholder": "EXT-001",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields in JSON format",
                    "label": "Custom Fields",
                    "placeholder": '[{"field_id": "Name", "value": "Test Record"}]',
                },
                {
                    "field": "record_type_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Record type ID for the custom object",
                    "label": "Record Type ID",
                    "placeholder": "012XXXXXXXXXXXXXXX",
                },
            ],
            "outputs": [
                {
                    "field": "record_id",
                    "type": "string",
                    "helper_text": "ID of the upserted record",
                },
                {
                    "field": "custom_object",
                    "type": "string",
                    "helper_text": "Name of the custom object",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "upsert_custom_object",
            "task_name": "tasks.salesforce.upsert_custom_object",
            "description": "Upsert a custom object record in Salesforce using external ID",
            "label": "Create or Update Custom Object",
            "required": ["custom_object", "external_id", "external_id_value"],
            "ui_sort_order": [
                "integration",
                "action",
                "custom_object",
                "external_id",
                "external_id_value",
                "custom_fields",
                "record_type_id",
            ],
        },
        "update_custom_object**(*)**(*)": {
            "inputs": [
                {
                    "field": "custom_object",
                    "type": "string",
                    "value": "",
                    "helper_text": "API name of the custom object",
                    "label": "Custom Object",
                    "placeholder": "Custom_Object__c",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=custom_object&parent_id=custom_objects&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "record_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the record to update",
                    "label": "Select Record",
                    "placeholder": "a0XXXXXXXXXXXXXXX",
                },
                {
                    "field": "custom_fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Custom fields in JSON format",
                    "label": "Custom Fields",
                    "placeholder": '[{"field_id": "Name", "value": "Updated Record"}]',
                },
                {
                    "field": "record_type_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Record type ID for the custom object",
                    "label": "Record Type ID",
                    "placeholder": "012XXXXXXXXXXXXXXX",
                },
            ],
            "outputs": [
                {
                    "field": "record_id",
                    "type": "string",
                    "helper_text": "ID of the updated record",
                },
                {
                    "field": "custom_object",
                    "type": "string",
                    "helper_text": "Name of the custom object",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_custom_object",
            "task_name": "tasks.salesforce.update_custom_object",
            "description": "Update an existing custom object record in Salesforce",
            "label": "Update Custom Object",
            "required": ["custom_object", "record_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "custom_object",
                "record_id",
                "custom_fields",
                "record_type_id",
            ],
        },
        "read_custom_object**(*)**(*)": {
            "inputs": [
                {
                    "field": "custom_object",
                    "type": "string",
                    "value": "",
                    "helper_text": "API name of the custom object",
                    "label": "Custom Object",
                    "placeholder": "Custom_Object__c",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=custom_object&parent_id=custom_objects&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "record_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the record to read",
                    "label": "Select Record",
                    "placeholder": "a0XXXXXXXXXXXXXXX",
                },
            ],
            "outputs": [
                {
                    "field": "record_id",
                    "type": "string",
                    "helper_text": "ID of the record",
                },
                {
                    "field": "custom_object",
                    "type": "string",
                    "helper_text": "Name of the custom object",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "helper_text": "All fields of the record",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_custom_object",
            "task_name": "tasks.salesforce.read_custom_object",
            "description": "Get a custom object record from Salesforce",
            "label": "Get Custom Object",
            "required": ["custom_object", "record_id"],
            "ui_sort_order": ["integration", "action", "custom_object", "record_id"],
        },
        "get_custom_objects**(*)**(*)": {
            "inputs": [
                {
                    "field": "custom_object",
                    "type": "string",
                    "value": "",
                    "helper_text": "API name of the custom object",
                    "label": "Custom Object",
                    "placeholder": "Custom_Object__c",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=custom_object&parent_id=custom_objects&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of fields to retrieve",
                    "label": "Fields",
                    "placeholder": "Id, Name, CreatedDate",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Search query to filter records",
                    "label": "Search Query",
                    "placeholder": "a0XXXXXXXXXXXXXXX",
                },
                {
                    "field": "condition",
                    "type": "string",
                    "value": "",
                    "helper_text": "Condition operator for multiple filters (AND/OR)",
                    "label": "Condition Operator",
                    "placeholder": "AND",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "AND", "value": "AND"},
                            {"label": "OR", "value": "OR"},
                        ],
                    },
                },
                {
                    "field": "id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by record ID",
                    "label": "Record ID",
                    "placeholder": "a0XXXXXXXXXXXXXXX",
                },
                {
                    "field": "created_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by creation date (YYYY-MM-DD)",
                    "label": "Created Date",
                    "placeholder": "2024-01-01",
                },
                {
                    "field": "modified_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by modification date (YYYY-MM-DD)",
                    "label": "Modified Date",
                    "placeholder": "2024-01-01",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by owner ID",
                    "label": "Owner ID",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                },
                {
                    "field": "created_by_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by created by ID",
                    "label": "Created By ID",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                },
                {
                    "field": "last_modified_by_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by last modified by ID",
                    "label": "Last Modified By ID",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                },
                {
                    "field": "system_mod_stamp",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by system modification stamp",
                    "label": "System Mod Stamp",
                    "placeholder": "2024-01-01T12:00:00Z",
                },
            ],
            "outputs": [
                {
                    "field": "total_size",
                    "type": "int32",
                    "helper_text": "Total number of records",
                },
                {
                    "field": "done",
                    "type": "bool",
                    "helper_text": "Whether query is complete",
                },
                {
                    "field": "custom_object",
                    "type": "string",
                    "helper_text": "Name of the custom object",
                },
                {
                    "field": "record_ids",
                    "type": "vec<string>",
                    "helper_text": "List of record IDs",
                },
                {
                    "field": "records",
                    "type": "vec<string>",
                    "helper_text": "List of record data",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_custom_objects",
            "task_name": "tasks.salesforce.get_custom_objects",
            "description": "List custom object records from Salesforce",
            "label": "List Custom Objects",
            "required": ["custom_object", "num_messages"],
            "ui_sort_order": [
                "integration",
                "action",
                "custom_object",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "fields",
                "query",
                "condition",
                "id",
                "created_date",
                "modified_date",
                "owner_id",
                "created_by_id",
                "last_modified_by_id",
                "system_mod_stamp",
            ],
        },
        "get_custom_objects**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Records",
                    "helper_text": "Specify the number of records to fetch",
                }
            ],
            "outputs": [],
        },
        "get_custom_objects**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_custom_objects**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_custom_objects**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "delete_custom_object**(*)**(*)": {
            "inputs": [
                {
                    "field": "custom_object",
                    "type": "string",
                    "value": "",
                    "helper_text": "API name of the custom object",
                    "label": "Custom Object",
                    "placeholder": "Custom_Object__c",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=custom_object&parent_id=custom_objects&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "record_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the record to delete",
                    "label": "Select Record",
                    "placeholder": "a0XXXXXXXXXXXXXXX",
                },
            ],
            "outputs": [
                {
                    "field": "record_id",
                    "type": "string",
                    "helper_text": "ID of the deleted record",
                },
                {
                    "field": "custom_object",
                    "type": "string",
                    "helper_text": "Name of the custom object",
                },
                {
                    "field": "deleted",
                    "type": "bool",
                    "helper_text": "Whether record was deleted",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_custom_object",
            "task_name": "tasks.salesforce.delete_custom_object",
            "description": "Delete a custom object record from Salesforce",
            "label": "Delete Custom Object",
            "required": ["custom_object", "record_id"],
            "ui_sort_order": ["integration", "action", "custom_object", "record_id"],
        },
        "read_user**(*)**(*)": {
            "inputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the user to read",
                    "label": "Select User",
                    "placeholder": "005XXXXXXXXXXXXXXX",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {"field": "user_id", "type": "string", "helper_text": "ID of the user"},
                {
                    "field": "username",
                    "type": "string",
                    "helper_text": "Username of the user",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Email address of the user",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "helper_text": "First name of the user",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "helper_text": "Last name of the user",
                },
                {
                    "field": "is_active",
                    "type": "bool",
                    "helper_text": "Whether the user is active",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_user",
            "task_name": "tasks.salesforce.read_user",
            "description": "Get a user from Salesforce",
            "label": "Get User",
            "required": ["user_id"],
            "ui_sort_order": ["integration", "action", "user_id"],
        },
        "get_users**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of fields to retrieve",
                    "label": "Fields",
                    "placeholder": "Id, Username, Email, FirstName, LastName",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Search query to filter users",
                    "label": "Search Query",
                    "placeholder": "john.doe",
                },
                {
                    "field": "condition",
                    "type": "string",
                    "value": "",
                    "helper_text": "Condition operator for multiple filters (AND/OR)",
                    "label": "Condition Operator",
                    "placeholder": "AND",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "AND", "value": "AND"},
                            {"label": "OR", "value": "OR"},
                        ],
                    },
                },
                {
                    "field": "username",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by username",
                    "label": "Username",
                    "placeholder": "john.doe",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by email address",
                    "label": "Email",
                    "placeholder": "john.doe@example.com",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by first name",
                    "label": "First Name",
                    "placeholder": "John",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by last name",
                    "label": "Last Name",
                    "placeholder": "Doe",
                },
                {
                    "field": "is_active",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by active status",
                    "label": "Is Active",
                    "placeholder": True,
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "true", "value": "true"},
                            {"label": "false", "value": "false"},
                        ],
                    },
                },
                {
                    "field": "created_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by creation date (YYYY-MM-DD)",
                    "label": "Created Date",
                    "placeholder": "2024-01-01",
                },
                {
                    "field": "modified_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by modification date (YYYY-MM-DD)",
                    "label": "Modified Date",
                    "placeholder": "2024-01-01",
                },
            ],
            "outputs": [
                {
                    "field": "total_size",
                    "type": "int32",
                    "helper_text": "Total number of users",
                },
                {
                    "field": "done",
                    "type": "bool",
                    "helper_text": "Whether query is complete",
                },
                {
                    "field": "user_ids",
                    "type": "vec<string>",
                    "helper_text": "List of user IDs",
                },
                {
                    "field": "usernames",
                    "type": "vec<string>",
                    "helper_text": "List of usernames",
                },
                {
                    "field": "emails",
                    "type": "vec<string>",
                    "helper_text": "List of email addresses",
                },
                {
                    "field": "first_names",
                    "type": "vec<string>",
                    "helper_text": "List of first names",
                },
                {
                    "field": "last_names",
                    "type": "vec<string>",
                    "helper_text": "List of last names",
                },
                {
                    "field": "is_active",
                    "type": "vec<string>",
                    "helper_text": "List of active status flags",
                },
                {
                    "field": "created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "updated_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of last modified dates",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_users",
            "task_name": "tasks.salesforce.get_users",
            "description": "List users from Salesforce",
            "label": "List Users",
            "required": ["num_messages"],
            "ui_sort_order": [
                "integration",
                "action",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "fields",
                "query",
                "condition",
                "username",
                "email",
                "first_name",
                "last_name",
                "is_active",
                "created_date",
                "modified_date",
            ],
        },
        "get_users**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Users",
                    "helper_text": "Specify the number of users to fetch",
                }
            ],
            "outputs": [],
        },
        "get_users**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_users**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_users**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "run_sql_query**(*)**(*)": {
            "inputs": [
                {
                    "field": "sql_query",
                    "type": "string",
                    "value": "",
                    "helper_text": "SQL query to execute",
                    "label": "Query",
                    "placeholder": "SELECT Id, Name FROM Account LIMIT 10",
                }
            ],
            "outputs": [
                {
                    "field": "total_size",
                    "type": "int32",
                    "helper_text": "Total number of records",
                },
                {
                    "field": "done",
                    "type": "bool",
                    "helper_text": "Whether query is complete",
                },
                {
                    "field": "records",
                    "type": "vec<string>",
                    "helper_text": "Array of query results",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "default_integration_nodes",
            "name": "run_sql_query",
            "task_name": "tasks.salesforce.run_sql_query",
            "description": "Execute a SOQL query in Salesforce",
            "label": "Search Query",
            "required": ["sql_query"],
            "ui_sort_order": ["integration", "action", "sql_query"],
        },
        "invoke_flow**(*)**(*)": {
            "inputs": [
                {
                    "field": "api_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "API name of the flow to invoke",
                    "label": "Flow API Name",
                    "placeholder": "My_Flow",
                },
                {
                    "field": "json_parameters",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to use JSON parameters",
                    "label": "Use JSON Parameters",
                },
                {
                    "field": "variables_json",
                    "type": "string",
                    "value": "",
                    "helper_text": "Flow variables in JSON format",
                    "label": "Variables JSON",
                    "placeholder": '{"inputVariable": "value"}',
                },
                {
                    "field": "variables",
                    "type": "string",
                    "value": "",
                    "helper_text": "Flow variables in array format",
                    "label": "Variables",
                    "placeholder": '[{"name": "inputVariable", "value": "value"}]',
                },
            ],
            "outputs": [
                {
                    "field": "api_name",
                    "type": "string",
                    "helper_text": "API name of the invoked flow",
                },
                {
                    "field": "outputs",
                    "type": "string",
                    "helper_text": "Flow output variables",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "invoke_flow",
            "task_name": "tasks.salesforce.invoke_flow",
            "description": "Invoke a Salesforce flow",
            "label": "Invoke Flow",
            "required": ["api_name"],
            "ui_sort_order": [
                "integration",
                "action",
                "api_name",
                "json_parameters",
                "variables_json",
                "variables",
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_date", "use_exact_date"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        use_date: bool = False,
        use_exact_date: bool = False,
        query: str = "",
        account_id: str = "",
        activity_date: str = "",
        amount: int = None,
        annual_revenue: int = None,
        api_name: str = "",
        assistant_name: str = "",
        assistant_phone: str = "",
        attachment_id: str = "",
        attachments: List[str] = [],
        billing_city: str = "",
        billing_country: str = "",
        billing_postal_code: str = "",
        billing_state: str = "",
        billing_street: str = "",
        birthdate: str = "",
        body: str = "",
        campaign_id: str = "",
        case_id: str = "",
        case_number: str = "",
        city: str = "",
        close_date: str = "",
        closed_date: str = "",
        comment_body: str = "",
        company: str = "",
        condition: str = "",
        contact_id: str = "",
        content_type: str = "",
        country: str = "",
        created_by_id: str = "",
        created_date: str = "",
        custom_fields: str = "",
        custom_object: str = "",
        date_range: DateRange = {
            "date_type": "Last",
            "date_value": 1,
            "date_period": "Months",
        },
        department: str = "",
        description: str = "",
        email: str = "",
        engineering_req_number: str = "",
        exact_date: TimeRange = {"start": "", "end": ""},
        expected_revenue: str = "",
        external_id: str = "",
        external_id_value: str = "",
        fax: str = "",
        fields: str = "",
        file: str = "",
        file_extension: str = "",
        first_name: str = "",
        forecast_category: str = "",
        forecast_category_name: str = "",
        has_opportunity_line_item: str = "",
        has_responded: bool = False,
        home_phone: str = "",
        industry: str = "",
        is_active: str = "",
        is_closed: str = "",
        is_escalated: str = "",
        is_private: bool = False,
        is_recurrence: str = "",
        is_reminder_set: bool = False,
        is_unread_by_owner: bool = False,
        is_won: str = "",
        json_parameters: bool = False,
        last_modified_by_id: str = "",
        last_name: str = "",
        last_referenced_date: str = "",
        last_viewed_date: str = "",
        lastname: str = "",
        lead_id: str = "",
        lead_source: str = "",
        link_to_object_id: str = "",
        mailing_city: str = "",
        mailing_country: str = "",
        mailing_postal_code: str = "",
        mailing_state: str = "",
        mailing_street: str = "",
        mobile_phone: str = "",
        modified_date: str = "",
        name: str = "",
        next_step: str = "",
        num_messages: int = 10,
        number_of_employees: int = 0,
        opportunity_id: str = "",
        origin: str = "",
        other_city: str = "",
        other_country: str = "",
        other_phone: str = "",
        other_postal_code: str = "",
        other_state: str = "",
        other_street: str = "",
        owner: str = "",
        owner_id: str = "",
        parent_id: str = "",
        phone: str = "",
        postal_code: str = "",
        potential_liability: str = "",
        priority: str = "",
        probability: int = None,
        product: str = "",
        rating: str = "",
        reason: str = "",
        record_id: str = "",
        record_type_id: str = "",
        recurrence_activity_id: str = "",
        reminder_date_time: str = "",
        salutation: str = "",
        sla_violation: str = "",
        sql_query: str = "",
        stage_name: str = "",
        state: str = "",
        status: str = "",
        street: str = "",
        subject: str = "",
        subject_line: str = "",
        supplied_company: str = "",
        supplied_email: str = "",
        supplied_name: str = "",
        supplied_phone: str = "",
        system_mod_stamp: str = "",
        task_id: str = "",
        task_subtype: str = "",
        title: str = "",
        total_opportunity_quantity: str = "",
        type: str = "",
        user_id: str = "",
        username: str = "",
        variables: str = "",
        variables_json: str = "",
        website: str = "",
        what_id: str = "",
        who_id: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_date"] = use_date
        params["use_exact_date"] = use_exact_date

        super().__init__(
            node_type="integration_salesforce",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if company is not None:
            self.inputs["company"] = company
        if lastname is not None:
            self.inputs["lastname"] = lastname
        if first_name is not None:
            self.inputs["first_name"] = first_name
        if email is not None:
            self.inputs["email"] = email
        if phone is not None:
            self.inputs["phone"] = phone
        if title is not None:
            self.inputs["title"] = title
        if website is not None:
            self.inputs["website"] = website
        if industry is not None:
            self.inputs["industry"] = industry
        if description is not None:
            self.inputs["description"] = description
        if status is not None:
            self.inputs["status"] = status
        if rating is not None:
            self.inputs["rating"] = rating
        if lead_source is not None:
            self.inputs["lead_source"] = lead_source
        if city is not None:
            self.inputs["city"] = city
        if state is not None:
            self.inputs["state"] = state
        if country is not None:
            self.inputs["country"] = country
        if postal_code is not None:
            self.inputs["postal_code"] = postal_code
        if street is not None:
            self.inputs["street"] = street
        if fax is not None:
            self.inputs["fax"] = fax
        if mobile_phone is not None:
            self.inputs["mobile_phone"] = mobile_phone
        if salutation is not None:
            self.inputs["salutation"] = salutation
        if annual_revenue is not None:
            self.inputs["annual_revenue"] = annual_revenue
        if number_of_employees is not None:
            self.inputs["number_of_employees"] = number_of_employees
        if is_unread_by_owner is not None:
            self.inputs["is_unread_by_owner"] = is_unread_by_owner
        if owner is not None:
            self.inputs["owner"] = owner
        if record_type_id is not None:
            self.inputs["record_type_id"] = record_type_id
        if custom_fields is not None:
            self.inputs["custom_fields"] = custom_fields
        if external_id is not None:
            self.inputs["external_id"] = external_id
        if external_id_value is not None:
            self.inputs["external_id_value"] = external_id_value
        if lead_id is not None:
            self.inputs["lead_id"] = lead_id
        if use_date is not None:
            self.inputs["use_date"] = use_date
        if fields is not None:
            self.inputs["fields"] = fields
        if query is not None:
            self.inputs["query"] = query
        if condition is not None:
            self.inputs["condition"] = condition
        if last_name is not None:
            self.inputs["last_name"] = last_name
        if owner_id is not None:
            self.inputs["owner_id"] = owner_id
        if created_date is not None:
            self.inputs["created_date"] = created_date
        if modified_date is not None:
            self.inputs["modified_date"] = modified_date
        if num_messages is not None:
            self.inputs["num_messages"] = num_messages
        if use_exact_date is not None:
            self.inputs["use_exact_date"] = use_exact_date
        if date_range is not None:
            self.inputs["date_range"] = date_range
        if exact_date is not None:
            self.inputs["exact_date"] = exact_date
        if campaign_id is not None:
            self.inputs["campaign_id"] = campaign_id
        if has_responded is not None:
            self.inputs["has_responded"] = has_responded
        if body is not None:
            self.inputs["body"] = body
        if is_private is not None:
            self.inputs["is_private"] = is_private
        if department is not None:
            self.inputs["department"] = department
        if account_id is not None:
            self.inputs["account_id"] = account_id
        if home_phone is not None:
            self.inputs["home_phone"] = home_phone
        if other_phone is not None:
            self.inputs["other_phone"] = other_phone
        if assistant_name is not None:
            self.inputs["assistant_name"] = assistant_name
        if assistant_phone is not None:
            self.inputs["assistant_phone"] = assistant_phone
        if mailing_street is not None:
            self.inputs["mailing_street"] = mailing_street
        if mailing_city is not None:
            self.inputs["mailing_city"] = mailing_city
        if mailing_state is not None:
            self.inputs["mailing_state"] = mailing_state
        if mailing_postal_code is not None:
            self.inputs["mailing_postal_code"] = mailing_postal_code
        if mailing_country is not None:
            self.inputs["mailing_country"] = mailing_country
        if other_street is not None:
            self.inputs["other_street"] = other_street
        if other_city is not None:
            self.inputs["other_city"] = other_city
        if other_state is not None:
            self.inputs["other_state"] = other_state
        if other_postal_code is not None:
            self.inputs["other_postal_code"] = other_postal_code
        if other_country is not None:
            self.inputs["other_country"] = other_country
        if birthdate is not None:
            self.inputs["birthdate"] = birthdate
        if contact_id is not None:
            self.inputs["contact_id"] = contact_id
        if name is not None:
            self.inputs["name"] = name
        if type is not None:
            self.inputs["type"] = type
        if billing_street is not None:
            self.inputs["billing_street"] = billing_street
        if billing_city is not None:
            self.inputs["billing_city"] = billing_city
        if billing_state is not None:
            self.inputs["billing_state"] = billing_state
        if billing_postal_code is not None:
            self.inputs["billing_postal_code"] = billing_postal_code
        if billing_country is not None:
            self.inputs["billing_country"] = billing_country
        if stage_name is not None:
            self.inputs["stage_name"] = stage_name
        if close_date is not None:
            self.inputs["close_date"] = close_date
        if amount is not None:
            self.inputs["amount"] = amount
        if probability is not None:
            self.inputs["probability"] = probability
        if forecast_category_name is not None:
            self.inputs["forecast_category_name"] = forecast_category_name
        if next_step is not None:
            self.inputs["next_step"] = next_step
        if has_opportunity_line_item is not None:
            self.inputs["has_opportunity_line_item"] = has_opportunity_line_item
        if opportunity_id is not None:
            self.inputs["opportunity_id"] = opportunity_id
        if expected_revenue is not None:
            self.inputs["expected_revenue"] = expected_revenue
        if total_opportunity_quantity is not None:
            self.inputs["total_opportunity_quantity"] = total_opportunity_quantity
        if is_closed is not None:
            self.inputs["is_closed"] = is_closed
        if is_won is not None:
            self.inputs["is_won"] = is_won
        if forecast_category is not None:
            self.inputs["forecast_category"] = forecast_category
        if subject is not None:
            self.inputs["subject"] = subject
        if priority is not None:
            self.inputs["priority"] = priority
        if origin is not None:
            self.inputs["origin"] = origin
        if reason is not None:
            self.inputs["reason"] = reason
        if case_id is not None:
            self.inputs["case_id"] = case_id
        if case_number is not None:
            self.inputs["case_number"] = case_number
        if supplied_name is not None:
            self.inputs["supplied_name"] = supplied_name
        if supplied_email is not None:
            self.inputs["supplied_email"] = supplied_email
        if supplied_phone is not None:
            self.inputs["supplied_phone"] = supplied_phone
        if supplied_company is not None:
            self.inputs["supplied_company"] = supplied_company
        if is_escalated is not None:
            self.inputs["is_escalated"] = is_escalated
        if closed_date is not None:
            self.inputs["closed_date"] = closed_date
        if last_viewed_date is not None:
            self.inputs["last_viewed_date"] = last_viewed_date
        if last_referenced_date is not None:
            self.inputs["last_referenced_date"] = last_referenced_date
        if engineering_req_number is not None:
            self.inputs["engineering_req_number"] = engineering_req_number
        if product is not None:
            self.inputs["product"] = product
        if potential_liability is not None:
            self.inputs["potential_liability"] = potential_liability
        if sla_violation is not None:
            self.inputs["sla_violation"] = sla_violation
        if comment_body is not None:
            self.inputs["comment_body"] = comment_body
        if activity_date is not None:
            self.inputs["activity_date"] = activity_date
        if what_id is not None:
            self.inputs["what_id"] = what_id
        if who_id is not None:
            self.inputs["who_id"] = who_id
        if task_subtype is not None:
            self.inputs["task_subtype"] = task_subtype
        if is_reminder_set is not None:
            self.inputs["is_reminder_set"] = is_reminder_set
        if task_id is not None:
            self.inputs["task_id"] = task_id
        if subject_line is not None:
            self.inputs["subject_line"] = subject_line
        if reminder_date_time is not None:
            self.inputs["reminder_date_time"] = reminder_date_time
        if is_recurrence is not None:
            self.inputs["is_recurrence"] = is_recurrence
        if recurrence_activity_id is not None:
            self.inputs["recurrence_activity_id"] = recurrence_activity_id
        if parent_id is not None:
            self.inputs["parent_id"] = parent_id
        if attachments is not None:
            self.inputs["attachments"] = attachments
        if attachment_id is not None:
            self.inputs["attachment_id"] = attachment_id
        if content_type is not None:
            self.inputs["content_type"] = content_type
        if file is not None:
            self.inputs["file"] = file
        if file_extension is not None:
            self.inputs["file_extension"] = file_extension
        if link_to_object_id is not None:
            self.inputs["link_to_object_id"] = link_to_object_id
        if custom_object is not None:
            self.inputs["custom_object"] = custom_object
        if record_id is not None:
            self.inputs["record_id"] = record_id
        if id is not None:
            self.inputs["id"] = id
        if created_by_id is not None:
            self.inputs["created_by_id"] = created_by_id
        if last_modified_by_id is not None:
            self.inputs["last_modified_by_id"] = last_modified_by_id
        if system_mod_stamp is not None:
            self.inputs["system_mod_stamp"] = system_mod_stamp
        if user_id is not None:
            self.inputs["user_id"] = user_id
        if username is not None:
            self.inputs["username"] = username
        if is_active is not None:
            self.inputs["is_active"] = is_active
        if sql_query is not None:
            self.inputs["sql_query"] = sql_query
        if api_name is not None:
            self.inputs["api_name"] = api_name
        if json_parameters is not None:
            self.inputs["json_parameters"] = json_parameters
        if variables_json is not None:
            self.inputs["variables_json"] = variables_json
        if variables is not None:
            self.inputs["variables"] = variables
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationSalesforceNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
