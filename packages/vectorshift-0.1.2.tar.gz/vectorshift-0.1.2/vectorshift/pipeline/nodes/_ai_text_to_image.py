"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("ai_text_to_image")
class AiTextToImageNode(Node):
    """
    Generate Image from Text using AI

    ## Inputs
    ### Common Inputs
        model: Select the text-to-image model
        prompt: Tell the AI model how you would like it to respond. Be as specific as possible. For example, you can instruct the model to use bright colors. Must not be empty.
        provider: Select the model provider.
        use_personal_api_key: Use your personal API key
    ### When use_personal_api_key = True
        api_key: Input your personal API key from the model provider. Note: if you do not have access to the selected model, the workflow will not run
    ### When provider = 'stabilityai'
        aspect_ratio: Select the aspect ratio.
    ### When provider = 'flux'
        aspect_ratio: Select the aspect ratio.
    ### When provider = 'openai'
        size: Select the size.
    ### When provider = 'openai' and model = 'dall-e-2'
        size: Select the size.

    ## Outputs
    ### Common Outputs
        image: The Image(s) generated from the Text.
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "Select the text-to-image model",
            "value": "gemini-2.5-flash-image",
            "type": "enum<string>",
        },
        {
            "field": "prompt",
            "helper_text": "Tell the AI model how you would like it to respond. Be as specific as possible. For example, you can instruct the model to use bright colors. Must not be empty.",
            "value": "",
            "type": "string",
        },
        {
            "field": "provider",
            "helper_text": "Select the model provider.",
            "value": "google",
            "type": "enum<string>",
        },
        {
            "field": "use_personal_api_key",
            "helper_text": "Use your personal API key",
            "value": False,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "image",
            "helper_text": "The Image(s) generated from the Text.",
            "type": "image",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "false**(*)**(*)": {"inputs": [], "outputs": []},
        "true**(*)**(*)": {
            "inputs": [
                {
                    "field": "api_key",
                    "label": "Api Key",
                    "type": "string",
                    "value": "",
                    "helper_text": "Input your personal API key from the model provider. Note: if you do not have access to the selected model, the workflow will not run",
                    "component": {
                        "type": "password",
                        "agent_field_type": "dynamic",
                        "disable_conversion": True,
                    },
                }
            ],
            "outputs": [],
        },
        "(*)**openai**(*)": {
            "inputs": [
                {
                    "field": "size",
                    "type": "string",
                    "value": "1024x1024",
                    "label": "Size",
                    "helper_text": "Select the size.",
                    "component": {
                        "type": "dropdown",
                        "source": "llm",
                        "source_key": "size",
                        "source_type": "text_to_image",
                    },
                },
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "label": "Model",
                    "helper_text": "Select the text-to-image model",
                    "component": {
                        "type": "dropdown",
                        "source": "llm",
                        "source_key": "model",
                        "source_type": "text_to_image",
                        "agent_field_type": "static",
                        "disable_conversion": False,
                    },
                },
            ],
            "outputs": [],
            "title": "OpenAI Text to Image",
        },
        "(*)**openai**dall-e-2": {
            "inputs": [
                {
                    "field": "size",
                    "type": "string",
                    "value": "",
                    "label": "Size",
                    "helper_text": "Select the size.",
                    "component": {
                        "type": "dropdown",
                        "source": "llm",
                        "source_key": "size",
                        "source_type": "text_to_image",
                    },
                }
            ],
            "outputs": [],
        },
        "(*)**stabilityai**(*)": {
            "inputs": [
                {
                    "field": "aspect_ratio",
                    "type": "string",
                    "value": "1:1",
                    "label": "Aspect Ratio",
                    "helper_text": "Select the aspect ratio.",
                    "component": {"type": "dropdown"},
                    "is_hidden_in_agent": True,
                },
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "label": "Model",
                    "helper_text": "Select the text-to-image model",
                    "component": {
                        "type": "dropdown",
                        "source": "llm",
                        "source_key": "model",
                        "source_type": "text_to_image",
                        "agent_field_type": "static",
                        "disable_conversion": False,
                    },
                },
            ],
            "outputs": [],
            "title": "Stability AI Text to Image",
        },
        "(*)**flux**(*)": {
            "inputs": [
                {
                    "field": "aspect_ratio",
                    "type": "string",
                    "value": "1:1",
                    "label": "Aspect Ratio",
                    "helper_text": "Select the aspect ratio.",
                    "component": {"type": "dropdown", "source_type": "text_to_image"},
                    "is_hidden_in_agent": True,
                },
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "label": "Model",
                    "helper_text": "Select the text-to-image model",
                    "component": {
                        "type": "dropdown",
                        "source": "llm",
                        "source_key": "model",
                        "source_type": "text_to_image",
                        "agent_field_type": "static",
                        "disable_conversion": False,
                    },
                },
            ],
            "outputs": [],
            "title": "Flux Text to Image",
        },
        "(*)**xai**(*)": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "label": "Model",
                    "helper_text": "Select the text-to-image model",
                    "component": {
                        "type": "dropdown",
                        "source": "llm",
                        "source_key": "model",
                        "source_type": "text_to_image",
                        "agent_field_type": "static",
                        "disable_conversion": False,
                    },
                }
            ],
            "outputs": [],
            "title": "XAI Text to Image",
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["use_personal_api_key", "provider", "model"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["api_key"]

    def __init__(
        self,
        use_personal_api_key: bool = False,
        provider: str = "google",
        model: str = "gemini-2.5-flash-image",
        prompt: str = "",
        api_key: str = "",
        aspect_ratio: str = "1:1",
        size: str = "1024x1024",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["use_personal_api_key"] = use_personal_api_key
        params["provider"] = provider
        params["model"] = model

        super().__init__(
            node_type="ai_text_to_image",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if provider is not None:
            self.inputs["provider"] = provider
        if model is not None:
            self.inputs["model"] = model
        if prompt is not None:
            self.inputs["prompt"] = prompt
        if use_personal_api_key is not None:
            self.inputs["use_personal_api_key"] = use_personal_api_key
        if api_key is not None:
            self.inputs["api_key"] = api_key
        if size is not None:
            self.inputs["size"] = size
        if aspect_ratio is not None:
            self.inputs["aspect_ratio"] = aspect_ratio
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "AiTextToImageNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
