"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_mailchimp")
class IntegrationMailchimpNode(Node):
    """
    Mailchimp

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your Mailchimp account
    ### get_campaign
        campaign_id: Choose the campaign to retrieve
    ### replicate_campaign
        campaign_id: Choose the campaign to retrieve
    ### create_resend_campaign
        campaign_id: Choose the campaign to retrieve
    ### send_campaign
        campaign_id: Choose the campaign to retrieve
    ### delete_campaign
        campaign_id: Choose the campaign to retrieve
    ### create_member
        email_address: Email address of the new member
        first_name: First name of the member (optional)
        last_name: Last name of the member (optional)
        list_id: Choose the list to get groups from
        status: Filter campaigns by status
    ### update_member
        email_address: Email address of the new member
        first_name: First name of the member (optional)
        last_name: Last name of the member (optional)
        list_id: Choose the list to get groups from
        member_id: Choose the member to retrieve
        status: Filter campaigns by status
    ### list_campaigns
        limit: Maximum number of campaigns to return
        status: Filter campaigns by status
        type: Filter campaigns by type
    ### list_groups
        limit: Maximum number of campaigns to return
        list_id: Choose the list to get groups from
    ### list_members
        limit: Maximum number of campaigns to return
        list_id: Choose the list to get groups from
        status: Filter campaigns by status
    ### get_member
        list_id: Choose the list to get groups from
        member_id: Choose the member to retrieve
    ### delete_member
        list_id: Choose the list to get groups from
        member_id: Choose the member to retrieve
    ### add_member_tags
        list_id: Choose the list to get groups from
        member_id: Choose the member to retrieve
        tags: List of tags to add to the member
    ### remove_member_tags
        list_id: Choose the list to get groups from
        member_id: Choose the member to retrieve
        tags: List of tags to add to the member

    ## Outputs
    ### list_campaigns
        campaign_count: Number of campaigns returned
        campaign_from_names: List of campaign sender names
        campaign_ids: Simplified list of campaign IDs
        campaign_list_names: List of associated list names
        campaign_names: List of campaign names/titles
        campaign_statuses: List of campaign statuses
        campaign_subjects: List of campaign subject lines
        campaign_titles: List of campaign titles
        campaign_types: List of campaign types
        campaigns: List of campaign IDs
        raw_data: Complete API response
        total_campaigns: Total number of campaigns available
    ### get_campaign
        campaign_id: ID of the campaign
        campaign_type: Type of campaign
        create_time: When the campaign was created
        emails_sent: Number of emails sent
        from_name: From name for the campaign
        list_id: ID of the associated list
        raw_data: Complete API response
        reply_to: Reply-to email address
        send_time: When the campaign was sent
        status: Current status of the campaign
        subject_line: Subject line of the campaign
        title: Title of the campaign
    ### send_campaign
        campaign_id: ID of the sent campaign
        raw_data: Complete API response
        send_time: When the campaign was sent
        status: New status of the campaign
    ### delete_campaign
        campaign_id: ID of the deleted campaign
        raw_data: Complete API response
    ### create_member
        email_address: Email address of the member
        member_id: ID of the created member
        raw_data: Complete API response
        status: Subscription status of the member
        timestamp_signup: When the member signed up
    ### get_member
        email_address: Email address of the member
        first_name: First name of the member
        last_name: Last name of the member
        member_id: ID of the member
        member_rating: Star rating for this member
        raw_data: Complete API response
        status: Subscription status of the member
        tags: Tags assigned to this member
        timestamp_opt: When the member confirmed opt-in
        timestamp_signup: When the member signed up
    ### update_member
        email_address: Updated email address of the member
        first_name: Updated first name of the member
        last_name: Updated last name of the member
        member_id: ID of the updated member
        raw_data: Complete API response
        status: Updated subscription status of the member
    ### delete_member
        email_address: Email address of the deleted member
        member_id: ID of the deleted member
        raw_data: Complete API response
    ### list_groups
        group_count: Number of groups returned
        group_ids: Simplified list of group IDs
        group_names: List of group names
        group_types: List of group types
        groups: List of group IDs
        raw_data: Complete API response
        total_groups: Total number of groups available
    ### list_members
        member_count: Number of members returned
        member_emails: List of member email addresses
        member_ids: Simplified list of member IDs
        member_names: List of member names (or emails if name unavailable)
        member_statuses: List of member subscription statuses
        members: List of member IDs
        raw_data: Complete API response
        total_members: Total number of members available
    ### add_member_tags
        member_id: ID of the member
        raw_data: Complete API response
        tags_added: Tags that were successfully added
    ### remove_member_tags
        member_id: ID of the member
        raw_data: Complete API response
        tags_removed: Tags that were successfully removed
    ### replicate_campaign
        new_campaign_id: ID of the newly created campaign
        new_campaign_title: Title of the new campaign
        raw_data: Complete API response
        status: Status of the new campaign
    ### create_resend_campaign
        raw_data: Complete API response
        resend_campaign_id: ID of the resend campaign
        resend_campaign_title: Title of the resend campaign
        status: Status of the resend campaign
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Mailchimp account",
            "value": None,
            "type": "integration<Mailchimp>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "get_campaign": {
            "inputs": [
                {
                    "field": "campaign_id",
                    "type": "string",
                    "value": "",
                    "label": "Campaign",
                    "placeholder": "Select campaign",
                    "helper_text": "Choose the campaign to retrieve",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=campaign_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "campaign_id",
                    "type": "string",
                    "helper_text": "ID of the campaign",
                },
                {
                    "field": "campaign_type",
                    "type": "string",
                    "helper_text": "Type of campaign",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Current status of the campaign",
                },
                {
                    "field": "subject_line",
                    "type": "string",
                    "helper_text": "Subject line of the campaign",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the campaign",
                },
                {
                    "field": "from_name",
                    "type": "string",
                    "helper_text": "From name for the campaign",
                },
                {
                    "field": "reply_to",
                    "type": "string",
                    "helper_text": "Reply-to email address",
                },
                {
                    "field": "list_id",
                    "type": "string",
                    "helper_text": "ID of the associated list",
                },
                {
                    "field": "create_time",
                    "type": "timestamp",
                    "helper_text": "When the campaign was created",
                },
                {
                    "field": "send_time",
                    "type": "timestamp",
                    "helper_text": "When the campaign was sent",
                },
                {
                    "field": "emails_sent",
                    "type": "int32",
                    "helper_text": "Number of emails sent",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_campaign",
            "task_name": "tasks.mailchimp.get_campaign",
            "description": "Read details of a specific campaign",
            "label": "Get Campaign",
            "input_sort_order": ["action", "integration", "campaign_id"],
            "required": ["campaign_id"],
        },
        "list_campaigns": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of campaigns to return",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "label": "Status Filter",
                    "helper_text": "Filter campaigns by status",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "All", "value": "*"},
                            {"label": "Save", "value": "save"},
                            {"label": "Paused", "value": "paused"},
                            {"label": "Schedule", "value": "schedule"},
                            {"label": "Sending", "value": "sending"},
                            {"label": "Sent", "value": "sent"},
                            {"label": "Canceled", "value": "canceled"},
                            {"label": "Canceling", "value": "canceling"},
                            {"label": "Archived", "value": "archived"},
                        ],
                    },
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "",
                    "label": "Type Filter",
                    "helper_text": "Filter campaigns by type",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "All", "value": ""},
                            {"label": "Regular", "value": "regular"},
                            {"label": "Plain Text", "value": "plaintext"},
                            {"label": "A/B Split", "value": "absplit"},
                            {"label": "RSS", "value": "rss"},
                            {"label": "Variate", "value": "variate"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "campaigns",
                    "type": "vec<string>",
                    "helper_text": "List of campaign IDs",
                },
                {
                    "field": "campaign_ids",
                    "type": "vec<string>",
                    "helper_text": "Simplified list of campaign IDs",
                },
                {
                    "field": "campaign_names",
                    "type": "vec<string>",
                    "helper_text": "List of campaign names/titles",
                },
                {
                    "field": "campaign_titles",
                    "type": "vec<string>",
                    "helper_text": "List of campaign titles",
                },
                {
                    "field": "campaign_statuses",
                    "type": "vec<string>",
                    "helper_text": "List of campaign statuses",
                },
                {
                    "field": "campaign_subjects",
                    "type": "vec<string>",
                    "helper_text": "List of campaign subject lines",
                },
                {
                    "field": "campaign_types",
                    "type": "vec<string>",
                    "helper_text": "List of campaign types",
                },
                {
                    "field": "campaign_from_names",
                    "type": "vec<string>",
                    "helper_text": "List of campaign sender names",
                },
                {
                    "field": "campaign_list_names",
                    "type": "vec<string>",
                    "helper_text": "List of associated list names",
                },
                {
                    "field": "campaign_count",
                    "type": "int32",
                    "helper_text": "Number of campaigns returned",
                },
                {
                    "field": "total_campaigns",
                    "type": "int32",
                    "helper_text": "Total number of campaigns available",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_campaigns",
            "task_name": "tasks.mailchimp.list_campaigns",
            "description": "Get multiple campaigns",
            "label": "List Campaigns",
            "input_sort_order": ["action", "integration", "limit", "status", "type"],
            "required": ["limit"],
        },
        "replicate_campaign": {
            "inputs": [
                {
                    "field": "campaign_id",
                    "type": "string",
                    "value": "",
                    "label": "Campaign to Replicate",
                    "placeholder": "Select campaign",
                    "helper_text": "Choose the campaign to replicate",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=campaign_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "new_campaign_id",
                    "type": "string",
                    "helper_text": "ID of the newly created campaign",
                },
                {
                    "field": "new_campaign_title",
                    "type": "string",
                    "helper_text": "Title of the new campaign",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the new campaign",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "replicate_campaign",
            "task_name": "tasks.mailchimp.replicate_campaign",
            "description": "Create a copy of an existing campaign",
            "label": "Replicate Campaign",
            "input_sort_order": ["action", "integration", "campaign_id"],
            "required": ["campaign_id"],
        },
        "create_resend_campaign": {
            "inputs": [
                {
                    "field": "campaign_id",
                    "type": "string",
                    "value": "",
                    "label": "Original Campaign",
                    "placeholder": "Select campaign",
                    "helper_text": "Choose the campaign to create a resend version for",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=campaign_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "resend_campaign_id",
                    "type": "string",
                    "helper_text": "ID of the resend campaign",
                },
                {
                    "field": "resend_campaign_title",
                    "type": "string",
                    "helper_text": "Title of the resend campaign",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Status of the resend campaign",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_resend_campaign",
            "task_name": "tasks.mailchimp.create_resend_campaign",
            "description": "Create a Resend to Non-Openers version of a campaign",
            "label": "Create Resend Campaign",
            "input_sort_order": ["action", "integration", "campaign_id"],
            "required": ["campaign_id"],
        },
        "send_campaign": {
            "inputs": [
                {
                    "field": "campaign_id",
                    "type": "string",
                    "value": "",
                    "label": "Campaign to Send",
                    "placeholder": "Select campaign",
                    "helper_text": "Choose the campaign to send",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=campaign_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "campaign_id",
                    "type": "string",
                    "helper_text": "ID of the sent campaign",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "New status of the campaign",
                },
                {
                    "field": "send_time",
                    "type": "timestamp",
                    "helper_text": "When the campaign was sent",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "send_campaign",
            "task_name": "tasks.mailchimp.send_campaign",
            "description": "Send a campaign to its audience",
            "label": "Send Campaign",
            "input_sort_order": ["action", "integration", "campaign_id"],
            "required": ["campaign_id"],
        },
        "delete_campaign": {
            "inputs": [
                {
                    "field": "campaign_id",
                    "type": "string",
                    "value": "",
                    "label": "Campaign",
                    "placeholder": "Select campaign",
                    "helper_text": "Choose the campaign to delete",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=campaign_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "campaign_id",
                    "type": "string",
                    "helper_text": "ID of the deleted campaign",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_campaign",
            "task_name": "tasks.mailchimp.delete_campaign",
            "description": "Delete a campaign from Mailchimp",
            "label": "Delete Campaign",
            "input_sort_order": ["action", "integration", "campaign_id"],
            "required": ["campaign_id"],
        },
        "list_groups": {
            "inputs": [
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "placeholder": "Select list",
                    "helper_text": "Choose the list to get groups from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of groups to return",
                },
            ],
            "outputs": [
                {
                    "field": "groups",
                    "type": "vec<string>",
                    "helper_text": "List of group IDs",
                },
                {
                    "field": "group_ids",
                    "type": "vec<string>",
                    "helper_text": "Simplified list of group IDs",
                },
                {
                    "field": "group_names",
                    "type": "vec<string>",
                    "helper_text": "List of group names",
                },
                {
                    "field": "group_types",
                    "type": "vec<string>",
                    "helper_text": "List of group types",
                },
                {
                    "field": "group_count",
                    "type": "int32",
                    "helper_text": "Number of groups returned",
                },
                {
                    "field": "total_groups",
                    "type": "int32",
                    "helper_text": "Total number of groups available",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_groups",
            "task_name": "tasks.mailchimp.list_groups",
            "description": "Get multiple groups from a list",
            "label": "List Groups",
            "input_sort_order": ["action", "integration", "list_id", "limit"],
            "required": ["list_id", "limit"],
        },
        "create_member": {
            "inputs": [
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "placeholder": "Select list",
                    "helper_text": "Choose the list to add member to",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "email_address",
                    "type": "string",
                    "value": "",
                    "label": "Email Address",
                    "placeholder": "user@example.com",
                    "helper_text": "Email address of the new member",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "subscribed",
                    "label": "Status",
                    "helper_text": "Subscription status for the member",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Subscribed", "value": "subscribed"},
                            {"label": "Unsubscribed", "value": "unsubscribed"},
                            {"label": "Cleaned", "value": "cleaned"},
                            {"label": "Pending", "value": "pending"},
                        ],
                    },
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "label": "First Name",
                    "placeholder": "John",
                    "helper_text": "First name of the member (optional)",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "value": "",
                    "label": "Last Name",
                    "placeholder": "Doe",
                    "helper_text": "Last name of the member (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "member_id",
                    "type": "string",
                    "helper_text": "ID of the created member",
                },
                {
                    "field": "email_address",
                    "type": "string",
                    "helper_text": "Email address of the member",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Subscription status of the member",
                },
                {
                    "field": "timestamp_signup",
                    "type": "timestamp",
                    "helper_text": "When the member signed up",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_member",
            "task_name": "tasks.mailchimp.create_member",
            "description": "Create a new member in a list",
            "label": "Create Member",
            "input_sort_order": [
                "action",
                "integration",
                "list_id",
                "email_address",
                "status",
                "first_name",
                "last_name",
            ],
            "required": ["list_id", "email_address", "status"],
        },
        "get_member": {
            "inputs": [
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "placeholder": "Select list",
                    "helper_text": "Choose the list containing the member",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "member_id",
                    "type": "string",
                    "value": "",
                    "label": "Member",
                    "placeholder": "Select member",
                    "helper_text": "Choose the member to retrieve",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=member_id&parent={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "member_id",
                    "type": "string",
                    "helper_text": "ID of the member",
                },
                {
                    "field": "email_address",
                    "type": "string",
                    "helper_text": "Email address of the member",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Subscription status of the member",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "helper_text": "First name of the member",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "helper_text": "Last name of the member",
                },
                {
                    "field": "timestamp_signup",
                    "type": "timestamp",
                    "helper_text": "When the member signed up",
                },
                {
                    "field": "timestamp_opt",
                    "type": "timestamp",
                    "helper_text": "When the member confirmed opt-in",
                },
                {
                    "field": "member_rating",
                    "type": "int32",
                    "helper_text": "Star rating for this member",
                },
                {
                    "field": "tags",
                    "type": "vec<string>",
                    "helper_text": "Tags assigned to this member",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_member",
            "task_name": "tasks.mailchimp.get_member",
            "description": "Read details of a specific member",
            "label": "Get Member",
            "input_sort_order": ["action", "integration", "list_id", "member_id"],
            "required": ["list_id", "member_id"],
        },
        "list_members": {
            "inputs": [
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "placeholder": "Select list",
                    "helper_text": "Choose the list to get members from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of members to return",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "label": "Status Filter",
                    "helper_text": "Filter members by status",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "All", "value": "*"},
                            {"label": "Subscribed", "value": "subscribed"},
                            {"label": "Unsubscribed", "value": "unsubscribed"},
                            {"label": "Cleaned", "value": "cleaned"},
                            {"label": "Pending", "value": "pending"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "members",
                    "type": "vec<string>",
                    "helper_text": "List of member IDs",
                },
                {
                    "field": "member_ids",
                    "type": "vec<string>",
                    "helper_text": "Simplified list of member IDs",
                },
                {
                    "field": "member_emails",
                    "type": "vec<string>",
                    "helper_text": "List of member email addresses",
                },
                {
                    "field": "member_statuses",
                    "type": "vec<string>",
                    "helper_text": "List of member subscription statuses",
                },
                {
                    "field": "member_names",
                    "type": "vec<string>",
                    "helper_text": "List of member names (or emails if name unavailable)",
                },
                {
                    "field": "member_count",
                    "type": "int32",
                    "helper_text": "Number of members returned",
                },
                {
                    "field": "total_members",
                    "type": "int32",
                    "helper_text": "Total number of members available",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_members",
            "task_name": "tasks.mailchimp.list_members",
            "description": "Get multiple members from a list",
            "label": "List Members",
            "input_sort_order": ["action", "integration", "list_id", "limit", "status"],
            "required": ["list_id", "limit"],
        },
        "update_member": {
            "inputs": [
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "placeholder": "Select list",
                    "helper_text": "Choose the list containing the member",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "member_id",
                    "type": "string",
                    "value": "",
                    "label": "Member",
                    "placeholder": "Select member",
                    "helper_text": "Choose the member to update",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=member_id&parent={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "email_address",
                    "type": "string",
                    "value": "",
                    "label": "Email Address",
                    "placeholder": "user@example.com",
                    "helper_text": "New email address for the member (optional)",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "label": "Status",
                    "helper_text": "New subscription status for the member",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "No Change", "value": "-"},
                            {"label": "Subscribed", "value": "subscribed"},
                            {"label": "Unsubscribed", "value": "unsubscribed"},
                            {"label": "Cleaned", "value": "cleaned"},
                            {"label": "Pending", "value": "pending"},
                        ],
                    },
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "label": "First Name",
                    "placeholder": "John",
                    "helper_text": "New first name for the member (optional)",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "value": "",
                    "label": "Last Name",
                    "placeholder": "Doe",
                    "helper_text": "New last name for the member (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "member_id",
                    "type": "string",
                    "helper_text": "ID of the updated member",
                },
                {
                    "field": "email_address",
                    "type": "string",
                    "helper_text": "Updated email address of the member",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Updated subscription status of the member",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "helper_text": "Updated first name of the member",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "helper_text": "Updated last name of the member",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_member",
            "task_name": "tasks.mailchimp.update_member",
            "description": "Update an existing member in a list",
            "label": "Update Member",
            "input_sort_order": [
                "action",
                "integration",
                "list_id",
                "member_id",
                "email_address",
                "status",
                "first_name",
                "last_name",
            ],
            "required": ["list_id", "member_id"],
        },
        "delete_member": {
            "inputs": [
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "placeholder": "Select list",
                    "helper_text": "Choose the list containing the member",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "member_id",
                    "type": "string",
                    "value": "",
                    "label": "Member",
                    "placeholder": "Select member",
                    "helper_text": "Choose the member to delete",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=member_id&parent={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "member_id",
                    "type": "string",
                    "helper_text": "ID of the deleted member",
                },
                {
                    "field": "email_address",
                    "type": "string",
                    "helper_text": "Email address of the deleted member",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_member",
            "task_name": "tasks.mailchimp.delete_member",
            "description": "Delete a member from a list",
            "label": "Delete Member",
            "input_sort_order": ["action", "integration", "list_id", "member_id"],
            "required": ["list_id", "member_id"],
        },
        "add_member_tags": {
            "inputs": [
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "placeholder": "Select list",
                    "helper_text": "Choose the list containing the member",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "member_id",
                    "type": "string",
                    "value": "",
                    "label": "Member",
                    "placeholder": "Select member",
                    "helper_text": "Choose the member to add tags to",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=member_id&parent={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "tags",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Tags to Add",
                    "helper_text": "List of tags to add to the member",
                },
            ],
            "outputs": [
                {
                    "field": "member_id",
                    "type": "string",
                    "helper_text": "ID of the member",
                },
                {
                    "field": "tags_added",
                    "type": "vec<string>",
                    "helper_text": "Tags that were successfully added",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "add_member_tags",
            "task_name": "tasks.mailchimp.add_member_tags",
            "description": "Add tags to a list member",
            "label": "Add Member Tags",
            "input_sort_order": [
                "action",
                "integration",
                "list_id",
                "member_id",
                "tags",
            ],
            "required": ["list_id", "member_id", "tags"],
        },
        "remove_member_tags": {
            "inputs": [
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "placeholder": "Select list",
                    "helper_text": "Choose the list containing the member",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=list_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "member_id",
                    "type": "string",
                    "value": "",
                    "label": "Member",
                    "placeholder": "Select member",
                    "helper_text": "Choose the member to remove tags from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=member_id&parent={inputs.list_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "tags",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Tags to Remove",
                    "helper_text": "List of tags to remove from the member",
                },
            ],
            "outputs": [
                {
                    "field": "member_id",
                    "type": "string",
                    "helper_text": "ID of the member",
                },
                {
                    "field": "tags_removed",
                    "type": "vec<string>",
                    "helper_text": "Tags that were successfully removed",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete API response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "remove_member_tags",
            "task_name": "tasks.mailchimp.remove_member_tags",
            "description": "Remove tags from a list member",
            "label": "Remove Member Tags",
            "input_sort_order": [
                "action",
                "integration",
                "list_id",
                "member_id",
                "tags",
            ],
            "required": ["list_id", "member_id", "tags"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        campaign_id: str = "",
        email_address: str = "",
        first_name: str = "",
        last_name: str = "",
        limit: int = 10,
        list_id: str = "",
        member_id: str = "",
        status: str = "",
        tags: List[str] = [],
        type: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_mailchimp",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if campaign_id is not None:
            self.inputs["campaign_id"] = campaign_id
        if limit is not None:
            self.inputs["limit"] = limit
        if status is not None:
            self.inputs["status"] = status
        if type is not None:
            self.inputs["type"] = type
        if list_id is not None:
            self.inputs["list_id"] = list_id
        if email_address is not None:
            self.inputs["email_address"] = email_address
        if first_name is not None:
            self.inputs["first_name"] = first_name
        if last_name is not None:
            self.inputs["last_name"] = last_name
        if member_id is not None:
            self.inputs["member_id"] = member_id
        if tags is not None:
            self.inputs["tags"] = tags
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationMailchimpNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
