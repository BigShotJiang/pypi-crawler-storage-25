"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("combine_text")
class CombineTextNode(Node):
    """
    Combine text inputs into a singular output.

    ## Inputs
    ### Common Inputs
        text: The text to combine

    ## Outputs
    ### Common Outputs
        processed_text: The combined text
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "text",
            "helper_text": "The text to combine",
            "value": ["", ""],
            "type": "vec<string>",
        }
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "processed_text",
            "helper_text": "The combined text",
            "type": "string",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["text"]

    def __init__(
        self,
        text: List[str] = ["", ""],
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="combine_text",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if text is not None:
            self.inputs["text"] = text
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "CombineTextNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
