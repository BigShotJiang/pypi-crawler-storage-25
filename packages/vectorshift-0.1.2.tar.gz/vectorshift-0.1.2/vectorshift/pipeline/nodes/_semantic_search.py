"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..config_objects import QueryEnhancementConfig, RerankConfig, RetrievalConfig


@Node.register_node_type("semantic_search")
class SemanticSearchNode(Node):
    """
    Generate a temporary vector database at run-time and retrieve the most relevant pieces from the documents based on the query.

    ## Inputs
    ### Common Inputs
        model: The model to use for the embedding
        query: The query will be used to search documents for relevant pieces semantically.
        alpha: The alpha value for the retrieval
        analyze_documents: To analyze document contents and enrich them when parsing
        answer_multiple_questions: Extract separate questions from the query and retrieve content separately for each question to improve search performance
        do_advanced_qa: Use additional LLM calls to analyze each document to improve answer correctness
        do_nl_metadata_query: Do a natural language metadata query
        documents: The text for semantic search. Note: you may add multiple upstream nodes to this field.
        enable_context: Additional context passed to advanced search and query analysis
        enable_document_db_filter: Filter the documents returned from the knowledge base
        enable_filter: Filter the content returned from the knowledge base
        expand_query: Expand query to improve semantic search
        expand_query_terms: Expand query terms to improve semantic search
        format_context_for_llm: Format the context for the LLM
        is_hybrid: Whether to create a hybrid knowledge base
        max_docs_per_query: The maximum number of relevant chunks to be returned
        rerank_documents: Refine the initial ranking of returned chunks based on relevancy
        retrieval_unit: The unit of retrieval. Chunks will return the most relevant chunks, Documents will return document metadata with snippets, and Pages will return complete pages with all chunks from pages containing relevant content
        score_cutoff: The score cutoff
        segmentation_method: The method to break text into units before chunking. 'words': splits by word; 'sentences': splits by sentence boundary; 'paragraphs': splits by blank line/paragraph.
        show_intermediate_steps: Show intermediate steps
        splitter_method: Strategy for grouping segmented text into final chunks. 'sentence': groups sentences; 'markdown': respects Markdown structure (headers, code); 'dynamic': optimizes breaks for size using chosen segmentation method.
        transform_query: Transform the query for better semantic search
    ### When do_advanced_qa = True
        advanced_search_mode: The mode to use for the advanced search
        qa_model_name: The model to use for the QA
    ### When enable_context = True
        context: Additional context to pass to the query analysis and qa steps
    ### When enable_document_db_filter = True
        document_db_filter: Filter the documents returned from the knowledge base
    ### When enable_filter = True
        filter: Filter the content returned from the knowledge base
    ### When rerank_documents = True
        rerank_model: Refine the initial ranking of returned chunks based on relevancy

    ## Outputs
    ### When do_advanced_qa = False and retrieval_unit = 'chunks' and format_context_for_llm = False
        chunks: Semantically similar chunks retrieved from the knowledge base
    ### When do_advanced_qa = False and retrieval_unit = 'chunks' and format_context_for_llm = True
        chunks: Semantically similar chunks retrieved from the knowledge base
        formatted_text: Knowledge base outputs formatted for input to a LLM
    ### When do_advanced_qa = True
        citation_metadata: Citation metadata for semantic search outputs, used for showing sources in LLM responses
        response: The response from the semantic search
    ### When do_advanced_qa = False and retrieval_unit = 'documents' and format_context_for_llm = False
        documents: Semantically similar documents retrieved from the knowledge base
    ### When do_advanced_qa = False and retrieval_unit = 'documents' and format_context_for_llm = True
        documents: Semantically similar documents retrieved from the knowledge base
        formatted_text: Knowledge base outputs formatted for input to a LLM
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "The model to use for the embedding",
            "value": "openai/text-embedding-3-small",
            "type": "string",
        },
        {
            "field": "query",
            "helper_text": "The query will be used to search documents for relevant pieces semantically.",
            "value": "",
            "type": "string",
        },
        {
            "field": "alpha",
            "helper_text": "The alpha value for the retrieval",
            "value": 0.5,
            "type": "float",
        },
        {
            "field": "analyze_documents",
            "helper_text": "To analyze document contents and enrich them when parsing",
            "value": False,
            "type": "bool",
        },
        {
            "field": "answer_multiple_questions",
            "helper_text": "Extract separate questions from the query and retrieve content separately for each question to improve search performance",
            "value": False,
            "type": "bool",
        },
        {
            "field": "do_advanced_qa",
            "helper_text": "Use additional LLM calls to analyze each document to improve answer correctness",
            "value": False,
            "type": "bool",
        },
        {
            "field": "do_nl_metadata_query",
            "helper_text": "Do a natural language metadata query",
            "value": False,
            "type": "bool",
        },
        {
            "field": "documents",
            "helper_text": "The text for semantic search. Note: you may add multiple upstream nodes to this field.",
            "value": [],
            "type": "string",
        },
        {
            "field": "enable_context",
            "helper_text": "Additional context passed to advanced search and query analysis",
            "value": False,
            "type": "bool",
        },
        {
            "field": "enable_document_db_filter",
            "helper_text": "Filter the documents returned from the knowledge base",
            "value": False,
            "type": "bool",
        },
        {
            "field": "enable_filter",
            "helper_text": "Filter the content returned from the knowledge base",
            "value": False,
            "type": "bool",
        },
        {
            "field": "expand_query",
            "helper_text": "Expand query to improve semantic search",
            "value": False,
            "type": "bool",
        },
        {
            "field": "expand_query_terms",
            "helper_text": "Expand query terms to improve semantic search",
            "value": False,
            "type": "bool",
        },
        {
            "field": "format_context_for_llm",
            "helper_text": "Format the context for the LLM",
            "value": False,
            "type": "bool",
        },
        {
            "field": "is_hybrid",
            "helper_text": "Whether to create a hybrid knowledge base",
            "value": False,
            "type": "bool",
        },
        {
            "field": "max_docs_per_query",
            "helper_text": "The maximum number of relevant chunks to be returned",
            "value": 5,
            "type": "int32",
        },
        {
            "field": "rerank_documents",
            "helper_text": "Refine the initial ranking of returned chunks based on relevancy",
            "value": False,
            "type": "bool",
        },
        {
            "field": "retrieval_unit",
            "helper_text": "The unit of retrieval. Chunks will return the most relevant chunks, Documents will return document metadata with snippets, and Pages will return complete pages with all chunks from pages containing relevant content",
            "value": "chunks",
            "type": "string",
        },
        {
            "field": "score_cutoff",
            "helper_text": "The score cutoff",
            "value": 0,
            "type": "float",
        },
        {
            "field": "segmentation_method",
            "helper_text": "The method to break text into units before chunking. 'words': splits by word; 'sentences': splits by sentence boundary; 'paragraphs': splits by blank line/paragraph.",
            "value": "words",
            "type": "string",
        },
        {
            "field": "show_intermediate_steps",
            "helper_text": "Show intermediate steps",
            "value": False,
            "type": "bool",
        },
        {
            "field": "splitter_method",
            "helper_text": "Strategy for grouping segmented text into final chunks. 'sentence': groups sentences; 'markdown': respects Markdown structure (headers, code); 'dynamic': optimizes breaks for size using chosen segmentation method.",
            "value": "markdown",
            "type": "string",
        },
        {
            "field": "transform_query",
            "helper_text": "Transform the query for better semantic search",
            "value": False,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "true**(*)**(*)**(*)**(*)**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "qa_model_name",
                    "label": "QA Model Name",
                    "type": "string",
                    "value": "gpt-4o-mini",
                    "helper_text": "The model to use for the QA",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown", "source_key": "qa_models"},
                },
                {
                    "field": "advanced_search_mode",
                    "label": "Advanced Search Mode",
                    "type": "string",
                    "value": "accurate",
                    "helper_text": "The mode to use for the advanced search",
                    "section": "advanced_settings",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Fast", "value": "fast"},
                            {"label": "Accurate", "value": "accurate"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "response",
                    "type": "string",
                    "helper_text": "The response from the semantic search",
                },
                {
                    "field": "citation_metadata",
                    "type": "vec<string>",
                    "helper_text": "Citation metadata for semantic search outputs, used for showing sources in LLM responses",
                },
            ],
        },
        "(*)**true**(*)**(*)**(*)**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "filter",
                    "label": "Filter",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter the content returned from the knowledge base",
                    "visibility": {
                        "field": "is_hybrid",
                        "operator": "==",
                        "value": False,
                    },
                }
            ],
            "outputs": [],
        },
        "(*)**(*)**true**(*)**(*)**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "rerank_model",
                    "label": "Rerank Model",
                    "type": "string",
                    "value": "cohere/rerank-english-v3.0",
                    "helper_text": "Refine the initial ranking of returned chunks based on relevancy",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown", "source_key": "rerank_models"},
                }
            ],
            "outputs": [],
        },
        "false**(*)**(*)**documents**(*)**false**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "documents",
                    "type": "vec<string>",
                    "helper_text": "Semantically similar documents retrieved from the knowledge base",
                }
            ],
        },
        "false**(*)**(*)**chunks**(*)**false**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "chunks",
                    "type": "vec<string>",
                    "helper_text": "Semantically similar chunks retrieved from the knowledge base",
                }
            ],
        },
        "false**(*)**(*)**documents**(*)**true**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "documents",
                    "type": "vec<string>",
                    "helper_text": "Semantically similar documents retrieved from the knowledge base",
                },
                {
                    "field": "formatted_text",
                    "type": "string",
                    "helper_text": "Knowledge base outputs formatted for input to a LLM",
                },
            ],
        },
        "false**(*)**(*)**chunks**(*)**true**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "chunks",
                    "type": "vec<string>",
                    "helper_text": "Semantically similar chunks retrieved from the knowledge base",
                },
                {
                    "field": "formatted_text",
                    "type": "string",
                    "helper_text": "Knowledge base outputs formatted for input to a LLM",
                },
            ],
        },
        "(*)**(*)**(*)**(*)**true**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "context",
                    "label": "Context",
                    "type": "string",
                    "value": "",
                    "helper_text": "Additional context to pass to the query analysis and qa steps",
                }
            ],
            "outputs": [],
        },
        "(*)**(*)**(*)**(*)**(*)**(*)**true**(*)": {
            "inputs": [
                {
                    "field": "document_db_filter",
                    "label": "Document DB Filter",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter the documents returned from the knowledge base",
                    "section": "advanced_settings",
                }
            ],
            "outputs": [],
        },
        "(*)**(*)**(*)**(*)**(*)**(*)**(*)**(dynamic)": {
            "inputs": [
                {
                    "field": "segmentation_method",
                    "label": "Segmentation Method",
                    "type": "string",
                    "value": "words",
                    "helper_text": "The method to break text into units before chunking. 'words': splits by word; 'sentences': splits by sentence boundary; 'paragraphs': splits by blank line/paragraph.",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = [
        "do_advanced_qa",
        "enable_filter",
        "rerank_documents",
        "retrieval_unit",
        "enable_context",
        "format_context_for_llm",
        "enable_document_db_filter",
        "splitter_method",
    ]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["query", "documents"]

    def __init__(
        self,
        do_advanced_qa: bool = False,
        enable_filter: bool = False,
        enable_context: bool = False,
        format_context_for_llm: bool = False,
        enable_document_db_filter: bool = False,
        splitter_method: str = "markdown",
        model: str = "openai/text-embedding-3-small",
        query: str = "",
        advanced_search_mode: str = "accurate",
        analyze_documents: bool = False,
        context: str = "",
        document_db_filter: str = "",
        documents: str = "[]",
        filter: str = "",
        is_hybrid: bool = False,
        qa_model_name: str = "gpt-4o-mini",
        segmentation_method: str = "words",
        show_intermediate_steps: bool = False,
        dependencies: Optional[List[str]] = None,
        retrieval: Optional[RetrievalConfig] = None,
        rerank: Optional[RerankConfig] = None,
        query_enhancement: Optional[QueryEnhancementConfig] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Unpack config objects (or apply defaults)
        _cfg_retrieval = retrieval if retrieval is not None else RetrievalConfig()
        max_docs_per_query = _cfg_retrieval.top_k
        alpha = _cfg_retrieval.alpha
        score_cutoff = _cfg_retrieval.score_cutoff
        retrieval_unit = _cfg_retrieval.unit
        _cfg_rerank = rerank if rerank is not None else RerankConfig()
        rerank_model = _cfg_rerank.model
        rerank_documents = True if rerank is not None else False
        _cfg_query_enhancement = (
            query_enhancement
            if query_enhancement is not None
            else QueryEnhancementConfig()
        )
        expand_query = _cfg_query_enhancement.expand
        expand_query_terms = _cfg_query_enhancement.expand_terms
        transform_query = _cfg_query_enhancement.transform
        answer_multiple_questions = _cfg_query_enhancement.multi_question
        do_nl_metadata_query = _cfg_query_enhancement.nl_metadata
        # Initialize with params
        params = {}
        params["do_advanced_qa"] = do_advanced_qa
        params["enable_filter"] = enable_filter
        params["rerank_documents"] = rerank_documents
        params["retrieval_unit"] = retrieval_unit
        params["enable_context"] = enable_context
        params["format_context_for_llm"] = format_context_for_llm
        params["enable_document_db_filter"] = enable_document_db_filter
        params["splitter_method"] = splitter_method

        super().__init__(
            node_type="semantic_search",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if max_docs_per_query is not None:
            self.inputs["max_docs_per_query"] = max_docs_per_query
        if alpha is not None:
            self.inputs["alpha"] = alpha
        if score_cutoff is not None:
            self.inputs["score_cutoff"] = score_cutoff
        if retrieval_unit is not None:
            self.inputs["retrieval_unit"] = retrieval_unit
        if rerank_model is not None:
            self.inputs["rerank_model"] = rerank_model
        if rerank_documents is not None:
            self.inputs["rerank_documents"] = rerank_documents
        if expand_query is not None:
            self.inputs["expand_query"] = expand_query
        if expand_query_terms is not None:
            self.inputs["expand_query_terms"] = expand_query_terms
        if transform_query is not None:
            self.inputs["transform_query"] = transform_query
        if answer_multiple_questions is not None:
            self.inputs["answer_multiple_questions"] = answer_multiple_questions
        if do_nl_metadata_query is not None:
            self.inputs["do_nl_metadata_query"] = do_nl_metadata_query
        if model is not None:
            self.inputs["model"] = model
        if query is not None:
            self.inputs["query"] = query
        if documents is not None:
            self.inputs["documents"] = documents
        if enable_filter is not None:
            self.inputs["enable_filter"] = enable_filter
        if do_advanced_qa is not None:
            self.inputs["do_advanced_qa"] = do_advanced_qa
        if show_intermediate_steps is not None:
            self.inputs["show_intermediate_steps"] = show_intermediate_steps
        if enable_context is not None:
            self.inputs["enable_context"] = enable_context
        if format_context_for_llm is not None:
            self.inputs["format_context_for_llm"] = format_context_for_llm
        if enable_document_db_filter is not None:
            self.inputs["enable_document_db_filter"] = enable_document_db_filter
        if analyze_documents is not None:
            self.inputs["analyze_documents"] = analyze_documents
        if is_hybrid is not None:
            self.inputs["is_hybrid"] = is_hybrid
        if splitter_method is not None:
            self.inputs["splitter_method"] = splitter_method
        if segmentation_method is not None:
            self.inputs["segmentation_method"] = segmentation_method
        if qa_model_name is not None:
            self.inputs["qa_model_name"] = qa_model_name
        if advanced_search_mode is not None:
            self.inputs["advanced_search_mode"] = advanced_search_mode
        if filter is not None:
            self.inputs["filter"] = filter
        if context is not None:
            self.inputs["context"] = context
        if document_db_filter is not None:
            self.inputs["document_db_filter"] = document_db_filter
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "SemanticSearchNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
